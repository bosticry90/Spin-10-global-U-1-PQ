"""Leading actual source poles, matrix bridges and canonical current controls."""
import unittest
from copy import deepcopy
from a10_e5_source_vertex import *
from audit_a10_e5_source_vertex import adjudicate,execution_matches


def typed(text):
    loc={f'k0_src{i}':s.Symbol(f'k0_src{i}',real=True) for i in range(4)}
    loc.update({f'q0_src{i}':s.Symbol(f'q0_src{i}',real=True) for i in range(4)})
    loc.update({n:s.Symbol(n,positive=True) for n in ('Msource_squared','mu_squared','Lambda_squared','cSource','cHeat')})
    return s.sympify(text,locals=loc)


class SourceVertex(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')

    def test_01_two_routes_and_bounded_pole_scope(self):
        a=adjudicate(self.P,self.R);self.assertTrue(a['actual_leading_source_poles_qualified'])
        self.assertFalse(a['complete_one_loop_restoration_proved'])

    def test_02_actual_xi_vertex_width_and_orbit_are_distinct(self):
        a=self.P['inventory'];self.assertEqual(a['literal_xi_without_g_vertex_coefficients'],276)
        self.assertEqual(a['quadratic_heavy_width_coefficients_retained'],17)
        self.assertTrue(a['orbit_has_g_xi_and_positive_mass_dimension'])
        self.assertTrue(a['one_quantum_leg_source_is_onePR_bridge_not_counted'])

    def test_03_triangle_sign_from_all_orientations(self):
        a=self.P['mixed_loop_arithmetic'];p=s.Matrix([s.Symbol(f'k0_src{i}',real=True) for i in range(4)])
        p2=(p.T*s.diag(*ETA)*p)[0];m2=s.Symbol('Msource_squared',positive=True)
        self.assertEqual(s.cancel(typed(a['triangle_before_Minkowski_integration'])+s.I/(p2*(p2-m2))),0)
        self.assertEqual(len(a['primary_walk_detail']),6);self.assertEqual(len(self.R['mixed_loop_arithmetic']['primary_walk_detail']),2)

    def test_04_all_four_source_Lorentz_outputs(self):
        p=s.Matrix([s.Symbol(f'k0_src{i}',real=True) for i in range(4)]);q=s.Matrix([s.Symbol(f'q0_src{i}',real=True) for i in range(4)])
        p2=(p.T*s.diag(*ETA)*p)[0];q2=((p+q).T*s.diag(*ETA)*(p+q))[0]
        for mu,text in enumerate(self.P['mixed_loop_arithmetic']['bubble_before_Minkowski_integration']):
            self.assertEqual(s.cancel(typed(text)-q[mu]/(2*p2*q2)),0)

    def test_05_wrong_Lorentz_contraction_survives(self):
        a=self.P['mixed_loop_arithmetic'];wrong=typed(a['wrong_Lorentz_metric_numerator'])
        self.assertNotEqual(wrong.subs({s.Symbol('k0_src1',real=True):1}),0)
        self.assertTrue(a['all_four_Lorentz_outputs_checked'])

    def test_06_mixed_and_odd_propagator_negative_controls(self):
        w=model();v=lambda n:w.var(n);G,p2=Green(w,[1,0,0,0],s.Integer(2))
        SJ=w.scale(w.mul(v('JphiExt'),v('uLoop'),v('chiLoop')),-1)
        SC=w.mul(v('Lloop'),v('ubLoop'),v('Cext'))
        VJ=matrix_Hessian(SJ,w,0,'primary');VC=matrix_Hessian(SC,w,0,'primary')
        VX=[[{} for z in w.fields] for z in w.fields];VX[1][0]=w.scale(v('xExt'),s.I);VX[0][1]=w.scale(v('xExt'),-s.I)
        def loop(G):return canonical(w.add(*(trace(mp(mp(mp(mp(mp(G,A,w),G,w),B,w),G,w),C,w),w) for A,B,C in permutations((VJ,VX,VC)))))
        correct=loop(G);self.assertTrue(correct);self.assertFalse(G[5][5])
        wrong=deepcopy(G)
        for mu in range(1,5):wrong[mu][5]={};wrong[5][mu]={}
        self.assertFalse(loop(wrong))
        wrong=deepcopy(G);wrong[7][6]=w.scale(wrong[7][6],-1)
        self.assertNotEqual(loop(wrong),correct)

    def test_07_triangle_heat_residue_and_IR_reference(self):
        i=self.P['integrals'];c=s.Symbol('cSource',positive=True);h=typed(i['triangle_positive_mass_heat_integral'])
        self.assertEqual(s.limit(-c*s.diff(h,c),c,0,dir='+'),1/(16*s.pi**2))
        self.assertTrue(i['triangle_zero_external_Taylor_IR_finite_for_M2_positive'])
        self.assertTrue(i['massless_zero_momentum_Taylor_not_admitted'])

    def test_08_finite_scheme_difference_is_local(self):
        i=self.P['integrals'];delta=typed(i['triangle_MSbar_finite'])-typed(i['triangle_heat_finite'])
        self.assertEqual(s.simplify(delta-typed(i['MSbar_minus_heat_local_difference'])),0)
        for n in ('Msource_squared','mu_squared'):
            self.assertEqual(s.diff(delta,s.Symbol(n,positive=True)),0)

    def test_09_bubble_has_nonexceptional_domain(self):
        i=self.P['integrals'];self.assertFalse(i['bubble_zero_external_momentum_admitted'])
        self.assertEqual(i['bubble_UV_residue'],'1/(16*pi**2)');self.assertFalse(i['physical_IR_limit_proved'])

    def test_10_real_nonsymmetric_heavy_tensor(self):
        A=[mat(v) for v in self.P['actual_internal_group']['heavy_cubic_tensor_matrices']]
        self.assertEqual(len(A),33);self.assertTrue(any(B.todok() for B in A))
        for B in A:self.assertEqual(cm(B+B.T),s.zeros(33));self.assertEqual(B.conjugate(),B)
        self.assertEqual(self.P['actual_internal_group']['all_33_cubic_tensor_entries'],35937)

    def test_11_actual_phi_products_match_independent_realification(self):
        group=self.P['actual_internal_group'];k=mat(group['kappa_physical'])
        E=mat(read(HERE/'frozen_a10_e5_ghost_normalization/primary.json')['ghost_metric']['real_heavy_frame'])
        rho=[s.kronecker_product(tensor(E[:,i]),s.eye(2)) for i in range(33)]
        for a,B in enumerate(group['actual_phi_triangle_group_matrices']):
            expected=cm(sum((k[c,a]*rho[c]/2 for c in range(33) if k[c,a]),s.zeros(20)))
            self.assertEqual(mat(B),expected)
        self.assertEqual(group['all_45_by_20_by_20_scalar_source_entries_including_H_zeros'],18000)

    def test_12_gauge_group_has_zero_H_and_negative_kappa(self):
        group=self.P['actual_internal_group'];B=mat(group['gauge_source_group_matrix']);k=mat(group['kappa_physical'])
        self.assertEqual(B[:12,:],s.zeros(12,33));self.assertEqual(B[12:,:],-k)

    def test_13_auxiliary_metric_is_not_ghost_endomorphism(self):
        group=self.P['actual_internal_group'];N=mat(group['ghost_endomorphism_C3'])
        Q=mat(read(HERE/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);G=cm(Q[:,12:].T*Q[:,12:])
        k=mat(read(HERE/'frozen_a10_e5_ghost_normalization/primary.json')['ghost_metric']['canonical_kappa'])
        self.assertEqual(N[12:,12:],cm(k*G));self.assertNotEqual(N[12:,12:],k)

    def test_14_H_intertwining_and_trace(self):
        group=self.P['actual_internal_group'];self.assertTrue(group['all_12_H_intertwining_identities'])
        N=mat(group['ghost_endomorphism_C3']);self.assertEqual(clean(N.trace()),132)
        self.assertEqual(N[:12,:],s.zeros(12,45));self.assertEqual(N[:,:12],s.zeros(45,12))

    def test_15_complete_current_is_required(self):
        a=self.P['canonical_normalization'];self.assertEqual(a['complete_normalization_candidate_coefficients'],54194)
        self.assertEqual(a['boundary_divergence_coefficients'],2688);self.assertTrue(any(a['boundary_current']))
        self.assertFalse(a['first_variation_residual']);self.assertTrue(a['selected_loop_poles_match_both_canonical_projections'])

    def test_16_all_scalar_projection_and_singlet_scope(self):
        a=self.P['canonical_normalization'];self.assertEqual(a['all328_scalar_source_projection_coefficients'],22626)
        self.assertTrue(self.P['actual_internal_group']['singlet_source_pole_zero'])
        self.assertIn('no fresh exhaustive Sigma',self.P['actual_internal_group']['other_scalar_sectors_extension'])
        self.assertFalse(a['complete_other_loop_poles_match_candidate_proved'])

    def test_17_formal_source_dual_inverse_preserves_evaluation(self):
        N=mat(self.P['actual_internal_group']['ghost_endomorphism_C3']);t=s.Symbol('hbar_a')
        Z=s.eye(45)+t*N;inverse=s.eye(45)-t*N
        for product in (Z*inverse,inverse*Z):
            self.assertEqual(cm(product-s.eye(45)+t*t*N*N),s.zeros(45))
        source=inverse.T;self.assertEqual(cm(source.T*Z-s.eye(45)+t*t*N*N),s.zeros(45))

    def test_18_external_sources_do_not_cancel_field_measure(self):
        a=self.P['selected_measure_transport'];self.assertTrue(a['external_source_not_counted_as_integrated_measure'])
        self.assertTrue(a['background_dependence_of_regulated_spacetime_trace_not_discarded'])
        self.assertTrue(a['effective_action_measure_term_starts_at_hbar2']);self.assertFalse(a['full_quantum_A5_or_all_contacts_proved'])

    def test_19_complete_quantum_and_adoption_overclaims_rejected(self):
        for n in ('complete_one_loop_restoration_proved','all_probe_contact_identities_proved','full_quantum_M2_M5_A1_A5_proved','full_E5_PASS',
          'physical_IR_or_anomaly_freedom_proved','sources_activated','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[n]=b[n]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_20_start_fingerprint_and_wrong_source_pole_rejected(self):
        fp=next(read(p)['fingerprint'] for p in OUT.glob('replay_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(fp);bad=deepcopy(fp);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        a=deepcopy(self.P);a['actual_internal_group']['gauge_source_group_matrix']['entries'][0][2]='0'
        with self.assertRaises(AssertionError):adjudicate(a,self.R)


if __name__=='__main__':unittest.main()
