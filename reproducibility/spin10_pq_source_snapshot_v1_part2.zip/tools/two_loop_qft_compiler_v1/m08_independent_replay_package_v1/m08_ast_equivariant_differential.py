"""Bounded odd derivation over the frozen 14-node M08 local-functional AST.

This module adds an operation, not a node type.  It deliberately does not
perform tensor/Jacobi rewriting or automatic Grassmann reordering.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from m08_local_functional_ast import (
    add,
    background,
    derivative,
    field,
    mul,
    parameter,
    parity,
    scalar,
    tensor,
)


Expr = dict[str, Any]
IMMUTABLE_NODES = {
    "ExactScalar", "Parameter", "FrozenBackground", "StructureConstant",
    "RepresentationGenerator", "KroneckerMetric",
}


def all_indices(expression: Expr) -> set[str]:
    found: set[str] = set(expression.get("indices", ()))
    if expression.get("node") == "PartialDerivative":
        found.add(expression["index"])
        found.update(all_indices(expression["argument"]))
    elif expression.get("node") == "Add":
        for term in expression["terms"]:
            found.update(all_indices(term))
    elif expression.get("node") == "OrderedProduct":
        for factor in expression["factors"]:
            found.update(all_indices(factor))
    elif expression.get("node") in {"LorentzContraction", "GroupContraction"}:
        found.update(expression.get("contracted_indices", ()))
        found.update(all_indices(expression["expression"]))
    elif expression.get("node") == "LocalActionTerm":
        found.update(all_indices(expression["density"]))
    return found


def index_occurrences(expression: Expr) -> dict[str, int]:
    counts: dict[str, int] = {}

    def add_index(index: str) -> None:
        counts[index] = counts.get(index, 0) + 1

    node = expression.get("node")
    for index in expression.get("indices", ()):
        add_index(index)
    if node == "PartialDerivative":
        add_index(expression["index"])
        child = index_occurrences(expression["argument"])
        for key, value in child.items():
            counts[key] = counts.get(key, 0) + value
    elif node == "Add":
        # An Add used as one tensor-valued factor carries the common index
        # signature of each addend, not the sum of all occurrences.
        term_counts = [index_occurrences(term) for term in expression["terms"]]
        if term_counts:
            reference = term_counts[0]
            if any(value != reference for value in term_counts[1:]):
                raise RuntimeError(
                    f"tensor-valued Add has inconsistent index counts: {term_counts}"
                )
            counts.update(reference)
    elif node == "OrderedProduct":
        for factor in expression["factors"]:
            child = index_occurrences(factor)
            for key, value in child.items():
                counts[key] = counts.get(key, 0) + value
    elif node in {"LorentzContraction", "GroupContraction"}:
        child = index_occurrences(expression["expression"])
        for key, value in child.items():
            counts[key] = counts.get(key, 0) + value
    elif node == "LocalActionTerm":
        return index_occurrences(expression["density"])
    return counts


def free_index_signature(expression: Expr) -> tuple[str, ...] | tuple[tuple[str, ...], ...]:
    """Return exact free indices; Add requires identical per-term signatures."""
    node = expression.get("node")
    if node == "Add":
        return tuple(free_index_signature(term) for term in expression["terms"])
    if node in {"GroupContraction", "LorentzContraction"}:
        contracted = set(expression.get("contracted_indices", ()))
        child = free_index_signature(expression["expression"])
        if child and isinstance(child[0], tuple):
            return tuple(tuple(index for index in term if index not in contracted)
                         for term in child)  # type: ignore[arg-type]
        return tuple(index for index in child if index not in contracted)  # type: ignore[arg-type]
    counts = index_occurrences(expression)
    return tuple(sorted(index for index, count in counts.items() if count == 1))


def assert_add_free_indices(expression: Expr) -> tuple[str, ...]:
    """Require all addends to carry one identical free-index signature."""
    if expression.get("node") != "Add":
        signature = free_index_signature(expression)
        if signature and isinstance(signature[0], tuple):
            raise RuntimeError("unexpected nested free-index signature")
        return signature  # type: ignore[return-value]
    signatures = [assert_add_free_indices(term) for term in expression["terms"]]
    if len(set(signatures)) != 1:
        raise RuntimeError(f"addends have inconsistent free indices: {signatures}")
    return signatures[0]


@dataclass
class Fresh:
    used: set[str]
    ordinal: int = 0

    def one(self, prefix: str) -> str:
        while True:
            candidate = f"_{prefix}{self.ordinal}"
            self.ordinal += 1
            if candidate not in self.used:
                self.used.add(candidate)
                return candidate


class FrozenFieldImages:
    """Action-normalized S1/S2/C4 field images."""

    def __init__(self, mode: str, expression: Expr):
        if mode not in {"ordinary_H", "full_Weil"}:
            raise ValueError("mode must be ordinary_H or full_Weil")
        self.mode = mode
        self.fresh = Fresh(all_indices(expression))
        self.g = parameter("g10")

    def image(self, node: Expr) -> Expr:
        name = node["name"]
        indices = tuple(node.get("indices", ()))
        if name == "Abar_H":
            return scalar(0)
        if name == "cbar_L":
            return mul(scalar(-1), field("lambda_L", indices=indices))
        if name == "lambda_L":
            return scalar(0)
        if name == "q_L":
            alpha, mu = indices
            beta, gamma = self.fresh.one("h"), self.fresh.one("h")
            terms = [
                derivative(mu, field("c_L", parity=1, indices=(alpha,))),
                mul(self.g, tensor("StructureConstant", "f", (alpha, beta, gamma)),
                    add(background("Abar_H", indices=(beta, mu)),
                        field("q_L", indices=(beta, mu))),
                    field("c_L", parity=1, indices=(gamma,))),
            ]
            if self.mode == "full_Weil":
                i, j = self.fresh.one("m"), self.fresh.one("m")
                terms.append(mul(
                    self.g, tensor("StructureConstant", "f", (alpha, i, j)),
                    field("V_H", indices=(i, mu)),
                    field("u_H", parity=1, indices=(j,)),
                ))
            return add(*terms)
        if name == "c_L":
            (alpha,) = indices
            beta, gamma = self.fresh.one("h"), self.fresh.one("h")
            terms = [mul(
                scalar("-1/2"), self.g,
                tensor("StructureConstant", "f", (alpha, beta, gamma)),
                field("c_L", parity=1, indices=(beta,)),
                field("c_L", parity=1, indices=(gamma,)),
            )]
            if self.mode == "full_Weil":
                terms.append(mul(self.g, field("R_H", parity=0, indices=(alpha,))))
            return add(*terms)
        if name == "V_H":
            i, mu = indices
            alpha, j, k = (self.fresh.one("h"), self.fresh.one("m"),
                           self.fresh.one("m"))
            return add(
                derivative(mu, field("u_H", parity=1, indices=(i,))),
                mul(self.g, tensor("StructureConstant", "f", (i, alpha, j)),
                    add(background("Abar_H", indices=(alpha, mu)),
                        field("q_L", indices=(alpha, mu))),
                    field("u_H", parity=1, indices=(j,))),
                mul(self.g, tensor("StructureConstant", "f", (i, j, alpha)),
                    field("V_H", indices=(j, mu)),
                    field("c_L", parity=1, indices=(alpha,))),
                mul(self.g, tensor("StructureConstant", "f", (i, j, k)),
                    field("V_H", indices=(j, mu)),
                    field("u_H", parity=1, indices=(k,))),
            )
        if name in {"phi", "eta_328"}:
            (a_index,) = indices
            b_index, alpha, i = (self.fresh.one("s"), self.fresh.one("h"),
                                 self.fresh.one("m"))
            shifted = add(background("v_328", indices=(b_index,)),
                          field(name, indices=(b_index,)))
            return add(
                mul(self.g, field("c_L", parity=1, indices=(alpha,)),
                    tensor("RepresentationGenerator", "rho_H", (alpha, a_index, b_index)),
                    shifted),
                mul(self.g, field("u_H", parity=1, indices=(i,)),
                    tensor("RepresentationGenerator", "rho_m", (i, a_index, b_index)),
                    shifted),
            )
        if name == "u_H":
            (i,) = indices
            j, k, alpha = (self.fresh.one("m"), self.fresh.one("m"),
                           self.fresh.one("h"))
            return add(
                mul(scalar("-1/2"), self.g,
                    tensor("StructureConstant", "f", (i, j, k)),
                    field("u_H", parity=1, indices=(j,)),
                    field("u_H", parity=1, indices=(k,))),
                mul(self.g, tensor("StructureConstant", "f", (alpha, i, j)),
                    field("c_L", parity=1, indices=(alpha,)),
                    field("u_H", parity=1, indices=(j,))),
            )
        if name == "ubar_H":
            (i,) = indices
            alpha, j = self.fresh.one("h"), self.fresh.one("m")
            return add(
                mul(scalar(-1), field("Lambda_H", indices=(i,))),
                mul(self.g, tensor("StructureConstant", "f", (alpha, i, j)),
                    field("c_L", parity=1, indices=(alpha,)),
                    field("ubar_H", parity=1, indices=(j,))),
            )
        if name == "Lambda_H":
            (i,) = indices
            alpha, j = self.fresh.one("h"), self.fresh.one("m")
            return add(
                mul(self.g, tensor("StructureConstant", "f", (alpha, i, j)),
                    field("c_L", parity=1, indices=(alpha,)),
                    field("Lambda_H", indices=(j,))),
                mul(self.g, self.g,
                    tensor("StructureConstant", "f", (alpha, i, j)),
                    field("R_H", indices=(alpha,)),
                    field("ubar_H", parity=1, indices=(j,))),
            )
        if name == "R_H":
            (alpha,) = indices
            beta, gamma = self.fresh.one("h"), self.fresh.one("h")
            return mul(self.g, tensor("StructureConstant", "f", (alpha, beta, gamma)),
                       field("c_L", parity=1, indices=(beta,)),
                       field("R_H", indices=(gamma,)))
        raise KeyError(f"no frozen differential image for field {name}")


def sigma_ast(expression: Expr, images: FrozenFieldImages | None = None) -> Expr:
    """Apply the odd derivation with exact graded ordered-product signs."""
    if images is None:
        images = FrozenFieldImages("full_Weil", expression)
    node = expression["node"]
    if node in IMMUTABLE_NODES:
        return scalar(0)
    if node == "Field":
        return images.image(expression)
    if node == "ExternalSource":
        raise KeyError("source images are not part of the A5 lowering alphabet")
    if node == "PartialDerivative":
        return derivative(expression["index"], sigma_ast(expression["argument"], images))
    if node == "Add":
        return add(*(sigma_ast(term, images) for term in expression["terms"]))
    if node == "OrderedProduct":
        factors = expression["factors"]
        result = []
        preceding_parity = 0
        for position, factor in enumerate(factors):
            differentiated = sigma_ast(factor, images)
            result.append(mul(scalar(-1 if preceding_parity else 1),
                              *factors[:position], differentiated,
                              *factors[position + 1:]))
            preceding_parity = (preceding_parity + parity(factor)) % 2
        return add(*result)
    if node in {"LorentzContraction", "GroupContraction"}:
        result = dict(expression)
        result["expression"] = sigma_ast(expression["expression"], images)
        result["parity"] = parity(result["expression"])
        return result
    if node == "LocalActionTerm":
        density = sigma_ast(expression["density"], images)
        return {
            "node": "LocalActionTerm",
            "term_id": "sigma(" + expression["term_id"] + ")",
            "density": density,
            "provenance": "ODD_DERIVATION_OF_" + expression["term_id"],
            "content_hash": None,
            "parity": parity(density),
        }
    raise ValueError(f"unsupported AST node for sigma: {node}")


def sigma_ast_replay(expression: Expr, images: FrozenFieldImages | None = None) -> Expr:
    """Separate recursive code path used by the future A5 component replay."""
    if images is None:
        images = FrozenFieldImages("full_Weil", expression)

    def visit(node: Expr) -> Expr:
        kind = node["node"]
        if kind in IMMUTABLE_NODES:
            return scalar(0)
        if kind == "Field":
            return images.image(node)
        if kind == "PartialDerivative":
            return derivative(node["index"], visit(node["argument"]))
        if kind == "Add":
            return add(*(visit(term) for term in node["terms"]))
        if kind == "OrderedProduct":
            out = scalar(0)
            left_parity = 0
            for slot in range(len(node["factors"])):
                factors = list(node["factors"])
                factors[slot] = visit(factors[slot])
                out = add(out, mul(scalar(-1 if left_parity else 1), *factors))
                left_parity ^= parity(node["factors"][slot])
            return out
        if kind in {"GroupContraction", "LorentzContraction"}:
            copy = dict(node)
            copy["expression"] = visit(node["expression"])
            copy["parity"] = parity(copy["expression"])
            return copy
        if kind == "LocalActionTerm":
            copy = dict(node)
            copy["density"] = visit(node["density"])
            copy["parity"] = parity(copy["density"])
            copy["content_hash"] = None
            return copy
        raise ValueError(kind)

    return visit(expression)
