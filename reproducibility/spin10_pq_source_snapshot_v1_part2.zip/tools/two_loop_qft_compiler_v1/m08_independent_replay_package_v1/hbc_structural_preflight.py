"""Necessary-condition HBC preflight; NOT an arbitrary-operator contraction table."""
from hashlib import sha256
from contextlib import contextmanager
from itertools import combinations, combinations_with_replacement
import json
from pathlib import Path
import sys
import time
import sympy as s

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'frozen_hbc_structural_contract'
BLOCKER = 'M08_C5_H_BASIC_CANDIDATE_CARTAN_LIFT_EXCLUDES_FROZEN_SIGMA'
INPUTS = [
    'frozen_c3/C3_representation_basis.json',
    'frozen_c4/C4_offshell_differential.json',
    'frozen_c4/C4_equivariant_algebra_certificate.json',
    'frozen_c5/C5_alphabet.json',
    'frozen_catalog_cat0_cat4/CAT1_module_actions.json',
    'frozen_source_seed_s3_s5/S32_graded_source_convention.json',
    'frozen_source_seed_s3_s5/S33_source_couplings.json',
    'frozen_source_seed_s3_s5/Sigma_M08_V1.json',
    'frozen_variational_s5_s8/S52_ST_identity.json',
    'frozen_variational_s5_s8/S63_equivariant_closure.json',
    'frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json',
    'frozen_rh_composite_adjudication/RH_primary_inputs.json',
    'frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json',
    'frozen_c5_c6/C51_local_functional_contract.json',
    'T5_target_catalog_checkpoint.json', 'HBC_TASK_RECORD.md',
]
STAGE_OBSERVATIONS = []


@contextmanager
def measured(name, category):
    profiler = sys.modules.get('profile_pole_blind_workflow')
    start = time.perf_counter()
    initial = profiler.process_counters() if profiler else {}
    try:
        yield
    finally:
        if profiler:
            final = profiler.process_counters()
            row = {'stage': name, 'category': category, 'wall_seconds': time.perf_counter() - start,
                   'cpu_seconds': final['cpu_seconds'] - initial['cpu_seconds'],
                   'process_peak_working_set_bytes': final['peak_working_set_bytes'],
                   'cache_hits': None, 'cache_misses': None}
            for key in ('os_io_read_transfer_bytes', 'os_io_write_transfer_bytes'):
                row[key] = final[key] - initial[key] if final[key] is not None else None
            STAGE_OBSERVATIONS.append(row)
            profiler.record_metric('hbc_stages', STAGE_OBSERVATIONS)


def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def serialized(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def seal(value):
    return dict(value, artifact_sha256=sha256(serialized(value)).hexdigest())


def bindings():
    return {name: sha256((HERE / name).read_bytes()).hexdigest() for name in INPUTS}


def code_bindings():
    names = ['hbc_structural_preflight.py', 'hbc_component_replay.py', 'execute_hbc_structural_contract.py']
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in names}


def inventory():
    alphabet = load('frozen_c5/C5_alphabet.json')['symbols']
    images = {v['identity']: v for v in load('frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json')['images']}
    modules = {v['identity']: v for v in load('frozen_catalog_cat0_cat4/CAT1_module_actions.json')['modules']}
    couplings = {v['source']: v for v in load('frozen_source_seed_s3_s5/S33_source_couplings.json')['couplings']}
    roles = []
    independent = [v for v in alphabet if v['identity'] != 'R_H']
    for v in alphabet:
        name = v['identity']; image = images[name]; module = modules[name]
        assert v['canonical_dimension'] == module['canonical_dimension'] == image['canonical_dimension_before']
        assert v['ghost_number'] == module['ghost_number'] == image['ghost_number_before']
        d, gh = v['canonical_dimension'] - 1, v['ghost_number'] - 1
        # Exhaustive grade-only upper envelope: every independent generator has d>=1.
        # Derivatives/positive-dimension parameters cannot supply a missing ghost grade.
        possible = []
        for degree in range(d + 1):
            for word in combinations_with_replacement(range(len(independent)), degree):
                if sum(independent[i]['canonical_dimension'] for i in word) <= d and sum(independent[i]['ghost_number'] for i in word) == gh:
                    possible.append([independent[i]['identity'] for i in word])
        roles.append({k: v[k] for k in ('identity', 'canonical_dimension', 'ghost_number', 'grassmann_parity', 'Lorentz_representation', 'H_representation', 'role_class')}
                     | {'independent': name != 'R_H', 'B_image_sha256': image['image_sha256'],
                        'source_couples_to': couplings[name]['target'] if name in couplings else None,
                        'H_action_binding': module['H_action'],
                        'minimal_iota_target_grade': [d, gh], 'grade_only_candidate_words': possible,
                        'iota_status': 'FORCED_ZERO_IN_MINIMAL_GRADED_POLYNOMIAL_ANSATZ' if not possible else 'NOT_YET_QUALIFIED'})
    assert len(roles) == 17 and len(independent) == 16
    assert all(not r['grade_only_candidate_words'] for r in roles if r['identity'] in couplings)
    return roles


def geometry():
    """Primary: sparse raw SO(10) coordinate bracket, full split-frame solve."""
    basis = load('frozen_c3/C3_representation_basis.json')
    pairs = list(combinations(range(10), 2)); pair_index = {p: i for i, p in enumerate(pairs)}
    def column(v):
        out = s.zeros(45, 1)
        for e in v['raw_so10_coordinates']: out[e['index']] = s.sympify(e['coefficient'])
        return out
    q = s.Matrix.hstack(*(column(v) for v in basis['h_basis'] + basis['heavy_basis']))
    inverse = q.inv(); h = q[:, :12]
    def bracket(left, right):
        result = s.zeros(45, 1)
        def add(a, b, coefficient):
            if a == b: return
            sign = 1 if a < b else -1
            result[pair_index[tuple(sorted((a, b)))]] += sign * coefficient
        for i in range(45):
            if not left[i]: continue
            a, b = pairs[i]
            for j in range(45):
                if not right[j]: continue
                c, d = pairs[j]; coefficient = left[i] * right[j] / s.sqrt(2)
                if b == c: add(a, d, coefficient)
                if b == d: add(a, c, -coefficient)
                if a == c: add(b, d, -coefficient)
                if a == d: add(b, c, coefficient)
        return result.applyfunc(s.simplify)
    f = []
    for a in range(12):
        action = s.zeros(12)
        for b in range(12):
            raw = bracket(h[:, a], h[:, b]); coordinates = (inverse * raw).applyfunc(s.simplify)
            assert coordinates[12:, :] == s.zeros(33, 1)
            assert (q * coordinates - raw).applyfunc(s.simplify) == s.zeros(45, 1)
            action[:, b] = coordinates[:12, :]
        f.append(action)
    return f


def source_polynomial(f):
    """Evaluate the actual frozen L_c source AST at its isolated c*c coefficient."""
    couplings = load('frozen_source_seed_s3_s5/S33_source_couplings.json')['couplings']
    coupling = next(v for v in couplings if v['source'] == 'L_c')
    term = coupling['coupling_AST']
    sigma = load('frozen_source_seed_s3_s5/Sigma_M08_V1.json')['Sigma_M08']
    def contains_lc(v):
        if isinstance(v, dict):
            return (v.get('node') == 'ExternalSource' and v.get('name') == 'L_c') or any(contains_lc(x) for x in v.values())
        return isinstance(v, list) and any(contains_lc(x) for x in v)
    sigma_terms = [v['term'] for v in sigma['local_terms'] if contains_lc(v)]
    assert sigma_terms == [term], 'Selected monomial must be unique in unchanged Sigma'
    product = term['density']['expression']['factors']
    assert product[0]['name'] == 'L_c' and product[0]['parity'] == 0
    cc, curvature = product[1]['terms']
    factors = cc['factors']
    assert [v['node'] for v in factors] == ['ExactScalar', 'Parameter', 'StructureConstant', 'Field', 'Field']
    assert [v['name'] for v in factors[1:]] == ['g10', 'f', 'c_L', 'c_L']
    assert factors[2]['indices'] == ['alpha', '_h0', '_h1']
    assert factors[3]['indices'] == ['_h0'] and factors[4]['indices'] == ['_h1']
    assert curvature['factors'][-1]['name'] == 'R_H'
    coefficient = s.sympify(factors[0]['value'])
    polynomial = {}
    for b in range(12):
        for c in range(12):
            if b == c: continue
            word = tuple(sorted((b, c))); sign = 1 if b < c else -1
            polynomial[word] = polynomial.get(word, 0) + sign * coefficient * f[b][4, c]
    polynomial = {w: s.simplify(v) for w, v in polynomial.items() if s.simplify(v) != 0}
    contraction = s.zeros(12, 1)
    for (b, c), value in polynomial.items():
        if b == 0: contraction[c] += value
        if c == 0: contraction[b] -= value
    contraction = contraction.applyfunc(s.simplify)
    assert contraction == (-f[0][4, :].T).applyfunc(s.simplify)
    return polynomial, contraction, sigma['canonical_action_sha256'], coupling['coupling_sha256']


def build_primary():
    with measured('primary_role_inventory', 'input_parse_and_grade_envelope'):
        roles = inventory()
    with measured('primary_H_geometry', 'exact_linear_algebra_and_symbolic_normalization'):
        f = geometry()
    with measured('primary_source_contraction', 'AST_parse_and_exact_graded_normalization'):
        polynomial, contraction, sigma_hash, coupling_hash = source_polynomial(f)
    # Coordinate derivations compose in reverse matrix order on generators.
    lie_residual_count = 0
    for a in range(12):
        for b in range(12):
            rhs = sum((f[c] * f[a][c, b] for c in range(12)), s.zeros(12))
            residual = (f[a] * f[b] - f[b] * f[a] - rhs).applyfunc(s.simplify)
            assert residual == s.zeros(12)
            lie_residual_count += 1
    assert contraction[4] != 0
    # M_c=-ad. The source action is -M_c^T in the evaluation pairing.
    m = -f[0]; dual = -m.T
    assert dual.T + m == s.zeros(12)
    # B cbar=-lambda, B lambda=0 => iota lambda=-g L cbar.
    assert -(-m) == m  # {iota,B} cbar/g = L cbar, not the zero-auxiliary guess.
    weight = load('frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json')
    return seal({'status': 'EXACT_NECESSARY_SOURCE_HORIZONTALITY_COUNTEREXAMPLE',
        'source_commits': ['c84e437', '85f2a31'], 'input_byte_sha256': bindings(), 'code_byte_sha256': code_bindings(),
        'candidate_not_promoted': True, 'candidate': {'basicness': 'intersection ker(L_alpha) and ker(iota_alpha)',
            'semantics': 'SUBSPACE_NOT_QUOTIENT', 'iota_degree': [-1, -1], 'iota_c_normalization': 'delta_alpha_beta',
            'coefficient_scope': 'Frozen local polynomial parameters/VEVs, no inverse dimensionful coefficients or new negative-ghost constants'},
        'role_inventory': roles, 'Sigma_canonical_sha256': sigma_hash, 'Lc_coupling_sha256': coupling_hash,
        'preregistered_component': {'contraction_index': 0, 'source_index': 4, 'remaining_ghost_index': 4,
            'f_4_0_4': str(f[0][4, 4]), 'coefficient_of_g10_Lc4_c4': str(contraction[4]), 'nonzero': True},
        'ghost_source_exterior_polynomial_over_g10_Lc4': [{'word': list(w), 'coefficient': str(v)} for w, v in sorted(polynomial.items())],
        'contracted_ghost_vector_over_g10_Lc4': [str(v) for v in contraction],
        'necessary_equations': {'L_cL_generator': '-ad(t_alpha)c_L', 'L_source': '-L_target_matrix_transpose_in_covector_evaluation',
            'iota_Lc': '0_by_empty_grade_envelope_(d=1,gh=-3)',
            'iota_R': 'Derived_from_u*u; contains_u_if_iota_u_is_constant; cannot_cancel_the_Lc*c_monomial',
            'iota_S_Lc_selected_sector': '-g10 Lc_a f_a_alpha_gamma c_gamma',
            'ghost_Cartan_normalization': '{iota_alpha,B_Sigma}c_L = g10 L_alpha c_L in the selected no-u sector',
            'light_auxiliary_necessary_lift': 'iota_alpha(lambda_L)=-g10 L_alpha(cbar_L), iota_alpha(cbar_L)=0'},
        'bounded_identity_checks': {'adjoint_Lie_matrix_pairs': lie_residual_count,
            'source_covector_pairing_residual': 'ZERO', 'ghost_sector_Cartan_residual': 'ZERO_BY_EXACT_CONTRACTION_VECTOR',
            'light_auxiliary_necessary_Cartan_residual': 'ZERO',
            'naive_zero_light_auxiliary_contraction': 'FAILS_NONABELIAN_CARTAN_IDENTITY'},
        'cancellation_certificate': 'All six source contractions have empty (-1,-1) grade envelopes. Only one L_c term exists in Sigma. R contains u, not c. Other source species are independent. Selected zero-derivative Lc*c coefficient cannot be IBP-zero without forbidden explicit coordinates/inverse derivatives.',
        'authority_ceiling': 'Necessary-condition obstruction in normalized minimal graded polynomial lift; NOT nonexistence of every possible extended/transported/nonpolynomial calculus',
        'formal_authority': weight['formal_authority'], 'pole_payload_read': False,
        'H_basic_dimensions': None, 'full_Cartan_table_qualified': False, 'Sigma_ST_recomputed': False})


def adjudicate(primary, replay):
    a = primary['preregistered_component']; b = replay['preregistered_component']
    assert a == b and replay['source_contraction_grade_envelopes_empty']
    assert primary['Sigma_canonical_sha256'] == replay['Sigma_canonical_sha256']
    assert primary['contracted_ghost_vector_over_g10_Lc4'] == replay['contracted_ghost_vector_over_g10_Lc4']
    return seal({'status': 'BLOCKED_HBC_SOURCE_HORIZONTALITY_INCOMPATIBLE_WITH_FROZEN_SIGMA',
        'current_blocker': 'M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING', 'localized_blocker': BLOCKER,
        'primary_sha256': primary['artifact_sha256'], 'replay_sha256': replay['artifact_sha256'],
        'primary_replay_agreement': 'EXACT', 'first_failed_acceptance_equation': 'iota_0 Sigma_M08=0; isolated g10*Lc[4]*c_L[4] coefficient is nonzero',
        'coefficient': a['coefficient_of_g10_Lc4_c4'], 'contract_promoted': False, 'HB1_authorized': False,
        'stages': {'HBC0': 'CANDIDATE_ONLY', 'HBC1': 'PASS_ROLE_INVENTORY_NOT_LIFT', 'HBC2': 'BOUNDED_GHOST_AND_SOURCE_LIE_CONTROL_ONLY',
            'HBC3': 'MINIMAL_SOURCE_GRADE_OBSTRUCTION', 'HBC6_HBC10_necessary_preflight': 'FAIL_SIGMA_HORIZONTALITY',
            'HBC12': 'PASS_BOUNDED_COUNTEREXAMPLE_REPLAY_NOT_COMPLETE_LIFT',
            **{f'HBC{i}': 'NOT_COMPLETED_FAIL_FAST' for i in (4, 5, 7, 8, 9, 11)}},
        'formal_authority': primary['formal_authority'], 'H_basic_dimensions': None,
        'unchanged_ST_authority': 'Preserved on its historical frozen domain; no new arbitrary-operator horizontality or full ST replay claimed',
        'required_disposition': 'Owner must resolve whether basicness applies to unchanged source/gauge-fixed Sigma itself, or provide an independently qualified transported/source-extended calculus compatible with it. No such change is inferred or implemented.',
        'independence_limits': 'Separate sparse Lie-coordinate/graded-AST route versus physical 10x10 matrix/pivot solve/odd-shift route. Same frozen H basis, source AST, Python and SymPy; not input/library/runtime independent.',
        'not_executed': ['HB1_HB10', 'complete_17_role_contraction_table', 'global_structural_descent', 'Cminus1_basic', 'C0_basic', 'Cplus1_basic',
            'differential_columns_or_matrices', 'differential_ranks_nullities', 'EOM', 'H0', 'C6', 'D6', 'E', 'M08_attempt2', 'M09_M13', 'Layer6', 'C1_GS', 'GPU'],
        'pole_payload_read': False, 'DISTANCE_TO_C1_GS': 'ONE_GATE_REMOVED', 'distance_semantics': 'Project-management metadata only'})
