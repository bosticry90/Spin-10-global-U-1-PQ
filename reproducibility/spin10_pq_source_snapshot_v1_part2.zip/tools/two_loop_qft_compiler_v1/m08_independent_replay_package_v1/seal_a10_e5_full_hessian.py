"""Seal complete retained-source Hessian and finite-loop prerequisites only."""
import json,subprocess,sys
from hashlib import sha256
from a10_e5_full_hessian import HERE,ROOT,OUT,read,STATUS
from seal_a10_e5_nonzero_regulator import PARENTS as OLD_PARENTS

PARENTS=(*OLD_PARENTS,'frozen_a10_e5_nonzero_regulator')
SCIENCE=('A10_E5_FULL_HESSIAN_CONTRACT_V1.md','A10_E5_FULL_HESSIAN_DERIVATION_V1.md',
 'A10_E5_FULL_HESSIAN_HEAT_SPEC_V1.md','A10_E5_FULL_HESSIAN_RESULT.md',
 'a10_e5_full_hessian.py','a10_e5_full_hessian_ref_factorization.py','a10_e5_full_hessian_heat.py',
 'run_a10_e5_full_hessian.py','run_a10_e5_full_hessian_heat.py',
 'export_a10_e5_full_hessian.py','export_a10_e5_full_hessian_heat.py','audit_a10_e5_full_hessian.py',
 'test_a10_e5_full_hessian.py','validate_a10_e5_full_hessian.py',
 'export_a10_e5_full_hessian_receipt.py','seal_a10_e5_full_hessian.py')
DOCS=('docs/A10_E5_FULL_HESSIAN_CURRENT.md','docs/RESEARCH_EXECUTION_HANDOFF_V13.md')
LIVE=('AGENTS.md',)


def files(receipt=True):
    return [HERE/n for n in SCIENCE]+[ROOT/n for n in (*DOCS,*LIVE)]+sorted(p for p in OUT.rglob('*')
      if p.is_file() and p.name!='bindings.json' and (receipt or p.name!='validation_receipt.json'))


def protected():
    sys.path.insert(0,str(ROOT/'tools'))
    from research_session_preflight import BINDING_KEYS,authenticate_bytes
    manifest=(HERE/'frozen_a10_e5_nonzero_regulator/bindings.json').relative_to(ROOT).as_posix()
    authenticate_bytes(ROOT,manifest);names=set();seen=set()
    def visit(n):
        if n in seen:return
        seen.add(n);data=read(ROOT/n)
        for key in BINDING_KEYS:names.update(data.get(key,{}))
        for child in data.get('inherited_manifest_sha256',{}):visit(child)
    visit(manifest);names.update(seen)
    return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(names)}


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists()
    if '--process-snapshot' in sys.argv:
        v={'schema':'E5_FULL_HESSIAN_EXECUTION_INSTRUCTIONS_V1','scientific_authority':False,
          'live_instructions_permanent_scientific_dependency':False,
          'files':{n:{'sha256':sha256((ROOT/n).read_bytes()).hexdigest(),'utf8':(ROOT/n).read_text(encoding='utf-8')} for n in LIVE}}
        assert not (OUT/'process_snapshot.json').exists()
        (OUT/'process_snapshot.json').write_bytes(json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n')
        print('EXPORTED execution instructions');return
    r=read(OUT/'validation_receipt.json')
    assert r['status']=='PASS_BOUNDED_FULL_HESSIAN_FINITE_LOOP_VALIDATION_ONLY' and r['scientific_gate']==STATUS
    assert r['targeted_regression_tests']==299 and r['fresh_routes_byte_identical']==2 and r['fresh_artifacts_byte_identical']==4
    assert not r['audit_time_changes'] and protected()==r['protected_byte_sha256']
    assert r['historical_custody_exit']==2 and r['unresolved_historical_references']==7
    for n,h in r['new_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,('AFTER_VALIDATION_CHANGED',n)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==r['state_sha256']
    from audit_a10_e5_full_hessian import authenticate
    assert authenticate()['scientific_gate']==STATUS
    for p in files():
        raw=p.read_bytes();raw.decode('utf-8');assert raw.endswith(b'\n'),str(p)
    for n,row in read(OUT/'process_snapshot.json')['files'].items():
        assert row['sha256']==sha256((ROOT/n).read_bytes()).hexdigest() and row['utf8'].encode()==(ROOT/n).read_bytes()
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='2f1bdf21151e173338503b878421c5f09b7e7654'
    v={'schema':'A10_E5_FULL_HESSIAN_BINDINGS_V1','base_commit':base,
      'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in files() if p.relative_to(ROOT).as_posix() not in LIVE},
      'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
      'state_sha256':r['state_sha256'],'scientific_disposition':STATUS,
      'complete_retained_Hessian_qualified':True,'finite_cutoff_one_loop_family_defined':True,
      'complete_nonzero_g_restoration_proved':False,'full_quantum_M2_M5_nonempty_proved':False,
      'all_source_insertion_and_contact_identities_proved':False,'full_anomaly_freedom_proved':False,
      'full_E5_PASS':False,'A1_A5_discharged':False,'weighted_gF_quantum_A5_equivalence_proved':False,
      'authority_changed':False,'catalog_generated':False,'sources_activated':False,'auxiliaries_eliminated':False,
      'HB1_C5_run':False,'C1_GS_calculated':False,'remote_push':False,'external_endorsement':False,
      'post_validation_finalization':'receipt export and byte seal only; no derivation edits'}
    with (OUT/'bindings.json').open('xb') as f:f.write(json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED complete Hessian and finite loop prerequisites; full quantum target remains open')


if __name__=='__main__':main()
