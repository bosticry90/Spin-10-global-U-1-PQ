"""Independent action/component replay; imports no primary HBP table or output."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def build_replay():
    rep = read('frozen_c3/C3_representation_basis.json'); pairs = list(combinations(range(10), 2))
    matrices = []
    for row in rep['h_basis'] + rep['heavy_basis']:
        mat = s.zeros(10)
        for e in row['raw_so10_coordinates']:
            a, b = pairs[e['index']]; v = s.sympify(e['coefficient']) / s.sqrt(2)
            mat[a, b] = v; mat[b, a] = -v
        matrices.append(mat)
    H, M = matrices[:12], matrices[12:]
    def pairing(a, b): return s.simplify(s.trace(a.T*b))
    gram = s.Matrix(12, 12, lambda i,j: pairing(H[i], H[j])); inverse = gram.inv()
    assert any(gram[i,j] for i in range(12) for j in range(12) if i != j), 'Do not assume a Euclidean frame'
    def coords(mat):
        out = (inverse * s.Matrix([pairing(h, mat) for h in H])).applyfunc(s.simplify)
        return out
    def bracket(a, b): return a*b-b*a
    def hbracket(a, b):
        mat = bracket(H[a], H[b]); v = coords(mat)
        assert (sum((v[i]*H[i] for i in range(12)), s.zeros(10))-mat).applyfunc(s.simplify) == s.zeros(10)
        return v
    # Deterministic first heavy exterior word with a nonzero selected residual.
    selected = None
    for j, k in combinations(range(33), 2):
        Rmat = -bracket(M[j], M[k]); R = coords(Rmat)
        first = coords(bracket(H[0], Rmat))[4]
        if first != 0:
            selected = (j, k, Rmat, R); break
    assert selected is not None
    j, k, Rmat, R = selected
    # Differentiate the ACTUAL Sigma source cc polynomial from the right:
    # the first c sees one trailing odd c; the second sees none.
    source = next(v for v in read('frozen_source_seed_s3_s5/S33_source_couplings.json')['couplings'] if v['source'] == 'L_c')
    cc = source['coupling_AST']['density']['expression']['factors'][1]['terms'][0]['factors']
    assert [v.get('name') for v in cc[1:]] == ['g10', 'f', 'c_L', 'c_L']
    factor = s.sympify(cc[0]['value']); assert factor == -s.Rational(1,2)
    sigma = read('frozen_source_seed_s3_s5/Sigma_M08_V1.json')['Sigma_M08']
    assert any(v['term'] == source['coupling_AST'] for v in sigma['local_terms'])
    source_value = s.simplify(sum(factor * (-hbracket(b,0)[4] + hbracket(0,b)[4]) * R[b] for b in range(12)))
    # Independently prolong the homogeneous H action through the u*u composite:
    # delta M_j=-[t,M_j]; vary both slots of -[M_j,M_k].
    delta_j = -bracket(H[0], M[j]); delta_k = -bracket(H[0], M[k])
    composite = -bracket(delta_j, M[k])-bracket(M[j], delta_k)
    assert (composite + bracket(H[0], Rmat)).applyfunc(s.simplify) == s.zeros(10)
    composite_value = coords(composite)[4]
    component = {'alpha': 0, 'source_component': 4, 'heavy_ghost_word': [j,k],
        'R_word_vector': [str(v) for v in R], 'source_contribution_over_g10': str(source_value),
        'composite_contribution_over_g10': str(composite_value),
        'total_over_g10': str(s.simplify(source_value+composite_value))}
    assert s.sympify(component['total_over_g10']) != 0
    f044 = hbracket(0,4)[4]
    sigma_witness = s.simplify(factor*(hbracket(0,4)[4]-hbracket(4,0)[4]))
    # Independent inequality, rather than primary word-envelope enumeration.
    alphabet = read('frozen_c5/C5_alphabet.json')['symbols']
    assert all(v['canonical_dimension'] >= max(0,-v['ghost_number']) for v in alphabet)
    lc = next(v for v in alphabet if v['identity'] == 'L_c')
    assert lc['canonical_dimension']-1 < -(lc['ghost_number']-1)
    value = {'status': 'EXACT_INDEPENDENT_ACTION_COMPONENT_PRESERVATION_COUNTEREXAMPLE',
        'algorithm': 'Physical normalized 10x10 brackets; non-Euclidean H Gram projection; right odd derivative of unchanged action; direct two-slot composite variation',
        'primary_table_or_output_imported': False, 'component': component,
        'historical_Sigma_witness': {'contraction_index': 0, 'source_index': 4, 'remaining_ghost_index': 4,
            'f_4_0_4': str(f044), 'coefficient_of_g10_Lc4_c4': str(sigma_witness), 'nonzero': True},
        'source_contraction_grade_obstruction': 'd>=-gh excludes target (1,-3)',
        'R_definition': '-1/2 P_H[u,u]; coefficient of ordered u_j u_k is -P_H[T_j,T_k]',
        'source_right_derivative_signs': [-1,1], 'source_cc_coefficient': str(factor),
        'Sigma_canonical_sha256': sigma['canonical_action_sha256'],
        'current_BR_image_imported': False, 'current_BLc_image_imported': False,
        'independence_limits': 'Shared frozen action/frame and Python/SymPy; different construction and representation, not library/runtime independence',
        'code_byte_sha256': sha256(Path(__file__).read_bytes()).hexdigest()}
    data = (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()
    return dict(value, artifact_sha256=sha256(data).hexdigest())
