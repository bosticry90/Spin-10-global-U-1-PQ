"""Adversarial controls for target changes and unsupported theorem promotion."""
import unittest
from copy import deepcopy
from a10_e5_theorem_bridge import *
from audit_a10_e5_theorem_bridge import adjudicate


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=read(OUT/'primary.json');cls.b=read(OUT/'replay.json');cls.w=alphabet()

    def test_distinct_routes_agree_on_completed_stop(self):
        self.assertEqual(adjudicate(self.a,self.b)['scientific_gate'],STATUS)

    def test_local_parameter_derivatives_detect_Ward_failure(self):
        P=decode_typed(self.a['Ward_scope_nonzero_Euler_omega0'])
        self.assertEqual(P,self.w.scale(self.w.dword(self.w.var('A0_0'),(0,0,0)),2))
        self.assertTrue(P)

    def test_constant_parameter_test_is_insufficient(self):
        _,GH,f=inputs('primary');w=self.w
        P=decode_typed(self.a['Ward_scope_control_density'])
        T={f'A{a}_{mu}':w.add(w.D(w.var(f'omega{a}'),mu),
             *(w.scale(w.mul(w.var(f'A{b}_{mu}'),w.var(f'omega{c}')),g*v)
               for (k,b,c),v in f.items() if k==a)) for a in H for mu in range(4)}
        varied=act(P,w,T,'primary')
        free=canonical({word:c.subs(g,0) for word,c in varied.items()})
        self.assertTrue(free)
        constant=projected(free,lambda n,j:not(n.startswith('omega') and j))
        self.assertFalse(constant)

    def test_free_Lorentz_sign_is_derived_from_density(self):
        P=decode_typed(self.a['background_real_spatial_density'])
        E=canonical(self.w.EL(P,'A0_1'))
        self.assertEqual(E,decode_typed(self.a['background_real_spatial_Euler']))
        self.assertNotEqual(E,self.w.scale(E,-1))

    def test_background_class_is_not_an_ordinary_divergence(self):
        P=decode_typed(self.a['background_density'])
        self.assertTrue(canonical(self.w.EL(P,'A0_1')))
        self.assertFalse(self.a['background_Ward_residual'])

    def test_backgrounds_stay_external_and_Q_inert(self):
        self.assertFalse(any(n.startswith('JA') for n in self.w.grades))
        self.assertEqual(sum(n.startswith('A') for n in self.w.external),48)
        self.assertEqual(self.a['pre_U_source_polynomial_stationary_checks'],1286)

    def test_project_to_standard_grading_is_bijective(self):
        for z,J in self.w.pairs:
            d,h,p=self.w.grades[z];D,Hh,P=self.w.grades[J]
            self.assertEqual((d-h)+(D-Hh),4)
            self.assertEqual(((d-h)+h,h,p),(d,h,p))

    def test_nonlinear_Slavnov_term_cannot_be_dropped(self):
        self.assertEqual(slavnov_orders('primary'),slavnov_orders('replay'))
        self.assertIn('B11/2',self.a['Slavnov_formal_orders'][2])

    def test_restricting_primitive_space_has_nonboundary_control(self):
        self.assertTrue(self.a['canonical_generator_scope_control_Euler_JB0_0'])
        self.assertEqual(self.a['preserved_original_horizontality_witness'],[{'word':['omega0__0'],'coefficient':'1'}])
        self.assertTrue(self.a['preserved_fixed_contraction_defect'])

    def test_faked_Ward_invariance_is_rejected(self):
        b=deepcopy(self.b);b['Ward_scope_nonzero_Euler_omega0']=[]
        with self.assertRaises(AssertionError):adjudicate(self.a,b)

    def test_shared_unsupported_theorem_promotion_is_rejected(self):
        for n in ('theorem_applicability_qualified','quantum_Ward_policy_adopted','full_E5_PASS','later_Q6_gates_executed'):
            a=deepcopy(self.a);b=deepcopy(self.b);a[n]=b[n]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_stationary_argument_does_not_authorize_inverse_couplings(self):
        self.assertIn('no inverse physical couplings',self.a['nonexactness_scope'])
        self.assertIn('not a missing class',self.a['background_scope_sensitivity'])


if __name__=='__main__':unittest.main()
