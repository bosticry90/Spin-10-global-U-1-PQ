"""Inactive four-dimensional SU(2) adjoint-Higgs BV control; stdout only.

Euler variation in an exterior algebra over a commutative polynomial ring.
No active M08 expression, source convention or historical engine is edited.
"""
from __future__ import annotations
import json
import sympy as s
from nonminimal_bv_free import Jets, ETA
from source_convention_control import Exterior, Checks, cross, dot

DISPOSITION = "QUALIFIED_INTERACTING_CONTROL_ONLY_M08_SOURCE_ARCHITECTURE_REQUIRES_REVIEW"
FIELDS = {**{f"A{a}{m}": (1,0,0) for a in range(3) for m in range(4)},
          **{f"p{a}": (1,0,0) for a in range(3)},
          **{f"c{a}": (1,1,1) for a in range(3)},
          **{f"bar{a}": (1,-1,1) for a in range(3)},
          **{f"b{a}": (2,0,0) for a in range(3)}}
PAIRS = [(z,"J"+z) for z in FIELDS]
GRADES = {**FIELDS, **{j:(3-FIELDS[z][0],-1-FIELDS[z][1],1-FIELDS[z][2]) for z,j in PAIRS}}
g,h,xi,v = s.symbols("g h xi v")


class ModelJets(Jets):
    def __init__(self):
        self.a, self.meta, self.values = Exterior(), {}, {}
        self.limit, self.max_order = 6, 0
        self._prolongations={}
        for base in GRADES: self.var(base)

    def var(self,base,indices=()):
        indices=tuple(sorted(indices))
        if len(indices)>self.limit: raise RuntimeError("JET_LIMIT_NOT_A_ZERO_RELATION")
        name=base+("__"+"".join(map(str,indices)) if indices else "")
        if name not in self.meta:
            self.meta[name]=(base,indices)
            self.values[name]=self.a.variable(name,GRADES[base][2])
            self.max_order=max(self.max_order,len(indices))
        return self.values[name]

    def bracket(self,f,k,pairs=PAIRS):
        a=self.a
        return a.add(*(a.scale(a.add(a.mul(self.euler(f,z,"right"),self.euler(k,j)),
            a.scale(a.mul(self.euler(f,j,"right"),self.euler(k,z)),-1)),(-1)**GRADES[z][2]) for z,j in pairs))

    def columns(self,action,pairs=PAIRS):
        # For even S the declared bracket gives these two LEFT Euler columns.
        return {n:self.euler(action,other) for pair in pairs for n,other in (pair,pair[::-1])}

    def Q(self,p,base_images):
        # Columns are immutable once passed here. Retain the actual mapping
        # alongside its cache so Python object-id reuse cannot alias tables.
        identity=id(base_images)
        if identity not in self._prolongations:
            self._prolongations[identity]=(base_images,{})
        owner,cache=self._prolongations[identity]
        assert owner is base_images
        for n in self.support(p):
            if n not in cache:
                base,indices=self.meta[n]
                cache[n]=self.multiD(base_images.get(base,{}),indices)
        return self.a.derive(p,{n:cache[n] for n in self.support(p)})

    def homogeneous_grade(self,p,grade):
        for word,c in p.items():
            evens=sorted((x for x in c.free_symbols if str(x) in self.meta or x==v),key=str)
            terms=s.Poly(c,*evens).terms() if evens else [((),c)]
            for powers,_ in terms:
                factors=list(word)+[str(x) for x,power in zip(evens,powers) for _ in range(power)]
                d=gh=parity=0
                for n in factors:
                    if n=="v": d+=1; continue
                    base,indices=self.meta[n]; dg,gg,pg=GRADES[base]
                    d+=dg+len(indices); gh+=gg; parity=(parity+pg)%2
                if (d,gh,parity)!=grade: return False
        return True

    def record(self,p):
        """Common canonical word serialization, including commuting fields."""
        result={}
        for word,c in p.items():
            even=sorted((x for x in c.free_symbols if str(x) in self.meta),key=str)
            terms=s.Poly(c,*even).terms() if even else [((),c)]
            sign=(-1)**sum(x>y for i,x in enumerate(word) for y in word[i+1:])
            for powers,coefficient in terms:
                factors=list(word)+[str(x) for x,power in zip(even,powers) for _ in range(power)]
                key=tuple(sorted(factors))
                result[key]=s.expand(result.get(key,0)+sign*coefficient)
        return [{"word":list(w),"coefficient":str(c)} for w,c in sorted(result.items()) if c!=0]

    def divergence_certificate(self,p):
        """Polynomial scaling homotopy, no EOM or numerical integration.

        For each homogeneous field-degree N, integrate the variation by parts
        with delta z=z and divide its boundary current by N. Parameters are
        not scaled. Euler residuals are checked by the caller and again here.
        """
        a=self.a; pieces={}
        for word,c in p.items():
            even=sorted((x for x in c.free_symbols if str(x) in self.meta),key=str)
            terms=s.Poly(c,*even).terms() if even else [((),c)]
            for powers,coefficient in terms:
                degree=len(word)+sum(powers)
                if not degree: raise AssertionError("NONZERO_CONSTANT_NOT_A_DIVERGENCE")
                term={word:coefficient*s.prod(x**power for x,power in zip(even,powers))}
                pieces[degree]=a.add(pieces.get(degree,{}),term)
        current=[{} for _ in range(4)]
        for degree,part in sorted(pieces.items()):
            for base in GRADES:
                if self.euler(part,base): raise AssertionError("HOMOTOPY_EULER_RESIDUAL "+base)
            for name in self.support(part):
                base,indices=self.meta[name]
                coeff=a.partial(part,name)
                for pos,mu in enumerate(indices):
                    term=a.mul(self.var(base,indices[pos+1:]),self.multiD(coeff,indices[:pos]))
                    current[mu]=a.add(current[mu],a.scale(term,s.Rational((-1)**pos,degree)))
        if a.add(self.div(current),a.scale(p,-1)): raise AssertionError("HOMOTOPY_DIVERGENCE_MISMATCH")
        return current


def setup(scalar_sign=-1,partner_sign=-1):
    j=ModelJets(); a=j.a; x={n:j.var(n) for n in GRADES}
    A=[[x[f"A{b}{m}"] for b in range(3)] for m in range(4)]
    phi=[x[f"p{b}"] for b in range(3)]; eta=[phi[0],phi[1],a.add(phi[2],{():v})]
    c=[x[f"c{b}"] for b in range(3)]; bar=[x[f"bar{b}"] for b in range(3)]; b=[x[f"b{k}"] for k in range(3)]
    curvature={}
    for m in range(4):
        for n in range(4):
            comm=cross(a,A[m],A[n])
            curvature[m,n]=[a.add(j.D(A[n][k],m),a.scale(j.D(A[m][k],n),-1),a.scale(comm[k],g)) for k in range(3)]
    cov=[]
    for m in range(4):
        ae=cross(a,A[m],eta)
        cov.append([a.add(j.D(eta[k],m),a.scale(ae[k],g)) for k in range(3)])
    kinetic=a.add(*(a.scale(dot(a,f,f),-s.Rational(1,4)*ETA[m]*ETA[n]) for (m,n),f in curvature.items()))
    scalar=a.add(*(a.scale(dot(a,y,y),s.Rational(1,2)*ETA[m]) for m,y in enumerate(cov)))
    radius=a.add(dot(a,eta,eta),{():-v**2}); potential=a.scale(a.mul(radius,radius),h/4)
    invariant=a.add(kinetic,scalar,a.scale(potential,-1))
    forward={}
    for m in range(4):
        ac=cross(a,A[m],c)
        for k in range(3): forward[f"A{k}{m}"]=a.add(j.D(c[k],m),a.scale(ac[k],g))
    ce,cc=cross(a,c,eta),cross(a,c,c)
    for k in range(3):
        forward[f"p{k}"]=a.scale(ce[k],scalar_sign*g)
        forward[f"c{k}"]=a.scale(cc[k],-g/2)
        forward[f"bar{k}"]=a.scale(b[k],partner_sign)
        forward[f"b{k}"]={}
    minimal=a.add(invariant,*(a.mul(x[source],forward[z]) for z,source in PAIRS))
    vev=[{}, {}, {():v}]; gold=cross(a,vev,phi)
    div=[a.add(*(a.scale(j.D(A[m][k],m),ETA[m]) for m in range(4))) for k in range(3)]
    G=[a.add(div[k],a.scale(gold[k],-xi*g)) for k in range(3)]
    psi=dot(a,bar,[a.add(G[k],a.scale(b[k],-xi/2)) for k in range(3)])
    return j,x,A,eta,c,bar,b,curvature,cov,invariant,potential,forward,minimal,psi,G


def constant_ghost_density(j,p,x):
    """Constant-vacuum Hessian diagnostic, NOT a differential restriction.

    Select roles exactly: a prefix 'b' would also delete 'bar', incorrectly
    erasing every ghost mass. Ordinary ghost jets are set to zero only here.
    """
    retain={f"{prefix}{k}" for prefix in ("c","bar") for k in range(3)}
    shifts={n:j.a.scale(x[n],-1) for n in GRADES if n not in retain}
    value=j.transport(p,shifts)
    return {word:co for word,co in value.items() if all(not j.meta[n][1] for n in word)}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda name,fn: fn()
    data=stage("model_and_invariant_action",setup)
    j,x,A,eta,c,bar,b,F,cov,S0,potential,forward,Smin,psi,G=data
    a,checks=j.a,Checks()
    Qmin=stage("minimal_Euler_columns",lambda:j.columns(Smin))
    gf=j.Q(psi,Qmin); action=a.add(Smin,gf)
    Q=stage("gauge_fixed_Euler_columns",lambda:j.columns(action))
    for n,p in Q.items():
        d,gh,par=GRADES[n]
        checks.true(j.homogeneous_grade(p,(d+1,gh+1,1-par)),"column grade "+n)
    for z in FIELDS:
        checks.equal(a,Qmin[z],forward[z],"minimal forward "+z)
        checks.equal(a,Q[z],forward[z],"gauge fixed forward "+z)
    checks.true(j.homogeneous_grade(action,(4,0,0)),"master grading")
    checks.true(j.homogeneous_grade(psi,(3,-1,1)),"fermion grading")
    for m in range(4):
        expected=cross(a,c,cov[m])
        for k in range(3): checks.equal(a,j.Q(cov[m][k],Q),a.scale(expected[k],-g),"covariant scalar derivative")
        for n in range(4):
            expected=cross(a,c,F[m,n])
            for k in range(3): checks.equal(a,j.Q(F[m,n][k],Q),a.scale(expected[k],-g),"curvature covariance")
    checks.zero(j.Q(S0,Q),"invariant action density without IBP")
    checks.zero(j.Q(potential,Q),"quartic potential invariance")
    def squares():
        count=0
        for n in GRADES:
            checks.zero(j.Q(Qmin[n],Qmin),"minimal square "+n)
            checks.zero(j.Q(Q[n],Q),"gauge fixed square "+n); count+=2
            for mu in range(4):
                checks.equal(a,j.Q(j.D(x[n],mu),Q),j.D(Q[n],mu),"derivative prolongation "+n)
                checks.zero(j.Q(j.Q(j.var(n,(mu,)),Q),Q),"first jet square "+n); count+=1
        return count
    square_count=stage("complete_base_and_first_jet_squares",squares)
    def masters():
        result={}
        for label,S in (("minimal",Smin),("gauge_fixed",action)):
            half=a.scale(j.bracket(S,S),s.Rational(1,2))
            for n in GRADES: checks.zero(j.euler(half,n),label+" master Euler "+n)
            current=j.divergence_certificate(half)
            checks.equal(a,half,j.div(current),label+" reconstructed master current")
            result[label]={"half_density":j.record(half),"current":[j.record(t) for t in current],"all_Euler_residuals_zero":True}
        return result
    master=stage("master_equations_and_explicit_divergence",masters)
    def transport():
        shifts={n:a.scale(j.bracket(psi,x[n]),-1) for n in GRADES}
        transformed=j.transport(Smin,shifts)
        difference=a.add(transformed,a.scale(action,-1))
        current=j.divergence_certificate(difference)
        for n in GRADES:
            checks.true(j.homogeneous_grade(shifts[n],GRADES[n]),"shift grade")
            checks.equal(a,j.transport(j.transport(x[n],shifts),shifts,-1),x[n],"inverse shift "+n)
            checks.equal(a,j.Q(j.transport(x[n],shifts),Q),j.transport(Qmin[n],shifts),"intertwining "+n)
            zsource=next((z for z,k in PAIRS if k==n),None)
            if zsource:
                checks.equal(a,j.bracket(Smin,x[n]),Qmin[n],"bracket Euler source agreement")
        checks.equal(a,j.transport(transformed,shifts,-1),Smin,"action inverse")
        return {"shifts":{n:j.record(shifts[n]) for n in GRADES},"action_difference_current":[j.record(t) for t in current],
                "inverse_and_all_generator_intertwining":True,"canonical_reason":"field-only fermion Hamiltonian flow in canonical variational bracket; J=zstar*(-1)^p", "full_M08_map":False}
    transport_data=stage("canonical_gauge_fixing",transport)
    # Constant-vacuum data; no auxiliary is eliminated in Q/master checks.
    vev=[{}, {}, {():v}]
    goldstone=[a.scale(t,-g) for t in cross(a,c,vev)]
    checks.true(bool(goldstone[0]) and bool(goldstone[1]) and not goldstone[2],"two broken directions")
    for k in range(3):
        vacuum=j.transport(Q[f"p{k}"],{f"p{i}":a.scale(x[f"p{i}"],-1) for i in range(3)})
        checks.equal(a,vacuum,goldstone[k],"full VEV term retained")
    # The completed-square GF cross is +g divA dot(v cross phi),
    # opposite the invariant kinetic mixing modulo IBP.
    gold=cross(a,vev,[x[f"p{k}"] for k in range(3)])
    mixing=a.add(*(a.scale(dot(a,A[m],[j.D(t,m) for t in gold]),g*ETA[m]) for m in range(4)))
    div=[a.add(*(a.scale(j.D(A[m][k],m),ETA[m]) for m in range(4))) for k in range(3)]
    gf_cross=a.scale(dot(a,div,gold),g)
    mixing_current=[a.scale(dot(a,A[m],gold),g*ETA[m]) for m in range(4)]
    checks.equal(a,a.add(mixing,gf_cross),j.div(mixing_current),"Goldstone mixing cancellation modulo divergence")
    # Read quadratic ghost mass directly from Q psi, at A=phi=b=0 and no jets.
    ghost_vac=constant_ghost_density(j,gf,x)
    # The even coefficients above contain no jets after the constant fields were substituted.
    # Q(bar G)=-b G-bar QG; QG at the vacuum is +xi g^2 v^2 c_perp.
    # Thus the density has NEGATIVE mass coefficient, just like -bar box c.
    expected_mass=a.scale(a.add(a.mul(bar[0],c[0]),a.mul(bar[1],c[1])),-xi*g**2*v**2)
    checks.equal(a,ghost_vac,expected_mass,"derived Goldstone ghost masses")
    zero_fields={n:a.scale(x[n],-1) for n in GRADES}
    gauge_mass=[]; scalar_mass=[]
    for k in range(3):
        grow=[]; srow=[]
        for l in range(3):
            gm=j.transport(a.partial(a.partial(S0,f"A{k}0"),f"A{l}0"),zero_fields)
            sm=j.transport(a.partial(a.partial(potential,f"p{k}"),f"p{l}"),zero_fields)
            checks.equal(a,gm,{():g**2*v**2} if k==l and k<2 else {},"gauge mass Hessian")
            checks.equal(a,sm,{():2*h*v**2} if k==l==2 else {},"scalar potential Hessian")
            grow.append(str(gm.get((),0))); srow.append(str(sm.get((),0)))
        gauge_mass.append(grow); scalar_mass.append(srow)
    def negatives():
        bad=dict(Q); bad.update({f"p{k}":a.scale(Q[f"p{k}"],-1) for k in range(3)})
        residual=j.Q(bad["p0"],bad)
        checks.true(bool(residual),"old scalar orientation must fail")
        broken=a.add(action,*(a.mul(x[f"Jbar{k}"],b[k]) for k in range(3)))
        pairs=[pair for pair in PAIRS if not pair[0].startswith("bar")]
        old=j.columns(broken,pairs); old.update({f"bar{k}":a.scale(b[k],-1) for k in range(3)})
        square=j.Q(old["Jb0"],old)
        free={w:s.expand(co.subs({g:0})) for w,co in square.items() if s.expand(co.subs({g:0}))!=0}
        checks.equal(a,free,a.scale(j.box(c[0]),-1),"omitted partner restores minus box c")
        checks.true(bool(Q["Jbar0"]),"new source zero is not invariant")
        flipped=a.add(action,a.scale(a.mul(x["Jbar0"],b[0]),2))
        wrong_bar=j.euler(flipped,"Jbar0")
        checks.equal(a,wrong_bar,b[0],"wrong source sign changes forward antighost rule")
        return {"wrong_positive_scalar_square":j.record(residual),"omitted_partner_free_square":j.record(free),"flipped_source_Qbar":j.record(wrong_bar),"partner_zero_is_Q_invariant":False}
    negative=stage("decisive_negative_controls",negatives)
    return {"schema":"INTERACTING_BV_PREFLIGHT_V1","disposition":DISPOSITION,"metric":list(ETA),
        "model":"four_dimensional_SU2_adjoint_Higgs_ordinary_gauge_control", "base_generator_count":48,"canonical_pair_count":24,
        "grades":{n:list(q) for n,q in GRADES.items()},"parameter_grades":{"g":[0,0,0],"h":[0,0,0],"xi":[0,0,0],"v":[1,0,0]},
        "actions":{"invariant":j.record(S0),"minimal_master":j.record(Smin),"gauge_fermion":j.record(psi),"gauge_fixing":j.record(gf),"gauge_fixed_master":j.record(action)},
        "minimal_images":{n:j.record(Qmin[n]) for n in GRADES},"images":{n:j.record(Q[n]) for n in GRADES},
        "master":master,"squares":{"minimal_base":48,"gauge_fixed_base":48,"gauge_fixed_first_jets":192,"total":square_count,"all_exact_zero":True,"higher_jets":"evolutionary prolongation theorem, not exhaustively enumerated","maximum_jet_order":j.max_order,"truncation":False},
        "gauge_fixing":{"two_broken_Goldstone_directions":True,"Goldstone_images":[j.record(t) for t in goldstone],"mixing_current":[j.record(t) for t in mixing_current],"ghost_mass_density":j.record(ghost_vac),"gauge_mass_squared_matrix":gauge_mass,"scalar_potential_Hessian":scalar_mass,"auxiliary_retained":True},
        "transport":transport_data,"negative_controls":negative,"exact_assertion_count":checks.count,
        "physical_invariance":"EXACT_POINTWISE","EOM_used":False,"M08_changed":False,"full_M08_replacement":False,
        "partial_gauge_source_domain_qualified":False,"external_specialist_review":False,"HB1_C5_authorized":False,"formal_authority":"34/39_UNCHANGED","finite_C1_GS":None}


if __name__=="__main__": print(json.dumps(build(),sort_keys=True,separators=(",",":")))
