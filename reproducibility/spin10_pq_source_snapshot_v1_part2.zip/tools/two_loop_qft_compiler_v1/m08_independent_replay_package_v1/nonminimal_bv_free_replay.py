"""Independent ordered-word/formal-variation free BV replay, stdout only.

No primary engine, primary columns or primary output is imported. The declared
model, Python/SymPy and historical input extraction are shared assumptions.
"""
import itertools
import json
import sympy as s
from source_convention_impact_replay import local_free_expression


class Words:
    def __init__(self):
        self.p = {**{f"V{m}": 0 for m in range(4)}, **{f"KV{m}": 1 for m in range(4)},
                  "u": 1, "bar": 1, "Lambda": 0, "Lu": 0, "Kbar": 0, "KL": 1}
        self.pairs = [(f"V{m}", f"KV{m}") for m in range(4)] + [("u", "Lu"), ("bar", "Kbar"), ("Lambda", "KL")]
        self.max_jet = 0

    def var(self, name, indices=()):
        return {((name, tuple(sorted(indices))),): s.Integer(1)}

    @staticmethod
    def add(*polys):
        result = {}
        for poly in polys:
            for word, c in poly.items():
                result[word] = result.get(word, 0)+c
        return {w: c for w, v in result.items() if (c := s.expand(v)) != 0}

    @staticmethod
    def scale(poly, c):
        return {w: v for w, t in poly.items() if (v := s.expand(c*t)) != 0}

    def mul(self, *polys):
        result = {(): s.Integer(1)}
        for poly in polys:
            out = {}
            for left, c in result.items():
                for right, d in poly.items():
                    word = left+right
                    odd = [z for z in word if self.p[z[0]]]
                    if len(odd) != len(set(odd)):
                        continue
                    sign = (-1)**sum(x > y for pos, x in enumerate(odd) for y in odd[pos+1:])
                    key = tuple(sorted(word))
                    out[key] = out.get(key, 0)+sign*c*d
            result = self.add(out)
        return result

    def D(self, poly, mu):
        out = {}
        for word, c in poly.items():
            for pos, (name, indices) in enumerate(word):
                new_indices = tuple(sorted(indices+(mu,)))
                self.max_jet = max(self.max_jet, len(new_indices))
                if len(new_indices) > 6:
                    raise RuntimeError("REPLAY_JET_LIMIT_NOT_A_ZERO_RELATION")
                term = self.mul({word[:pos]: c}, self.var(name, new_indices), {word[pos+1:]: 1})
                out = self.add(out, term)
        return out

    def dword(self, poly, indices):
        for mu in indices:
            poly = self.D(poly, mu)
        return poly

    def EL(self, poly, base):
        out = {}
        for word, c in poly.items():
            for pos, (name, indices) in enumerate(word):
                if name == base:
                    sign = (-1)**(self.p[name]*sum(self.p[n] for n, _ in word[:pos])+len(indices))
                    out = self.add(out, self.scale(self.dword({word[:pos]+word[pos+1:]: c}, indices), sign))
        return out

    def Q(self, poly, images):
        out = {}
        for word, c in poly.items():
            for pos, (name, indices) in enumerate(word):
                sign = (-1)**sum(self.p[n] for n, _ in word[:pos])
                out = self.add(out, self.scale(self.mul({word[:pos]: c}, self.dword(images.get(name, {}), indices), {word[pos+1:]: 1}), sign))
        return out

    def replace(self, poly, substitutions):
        out = {}
        for word, c in poly.items():
            term = {(): c}
            for name, indices in word:
                term = self.mul(term, self.dword(substitutions.get(name, self.var(name)), indices))
            out = self.add(out, term)
        return out

    @staticmethod
    def record(poly):
        return [{"word": [n+("__"+"".join(map(str, indices)) if indices else "") for n, indices in word], "coefficient": str(c)} for word, c in sorted(poly.items())]


def build():
    if not __debug__:
        raise RuntimeError("REPLAY_REQUIRES_ASSERTIONS_ENABLED")
    w, xi = Words(), s.Symbol("xi")
    x = {n: w.var(n) for n in w.p}
    metric = [1, -1, -1, -1]
    box = lambda p: w.add(*(w.scale(w.D(w.D(p, m), m), metric[m]) for m in range(4)))
    # Coefficients extracted from the frozen M08 action, not primary BV columns.
    old_free = local_free_expression()
    assert old_free == {("bar", "u2"): -1, ("Lambda", "divV"): -1, ("Lambda", "Lambda"): xi/2}
    divV = w.add(*(w.scale(w.D(x[f"V{m}"], m), metric[m]) for m in range(4)))
    gf = w.add(w.scale(w.mul(x["bar"], box(x["u"])), old_free[("bar", "u2")]),
               w.scale(w.mul(x["Lambda"], divV), old_free[("Lambda", "divV")]),
               w.scale(w.mul(x["Lambda"], x["Lambda"]), old_free[("Lambda", "Lambda")]))
    # Sum independent antisymmetric pairs once, rather than primary all indices.
    kinetic = {}
    for m in range(4):
        for n in range(m+1, 4):
            f = w.add(w.D(x[f"V{n}"], m), w.scale(w.D(x[f"V{m}"], n), -1))
            kinetic = w.add(kinetic, w.scale(w.mul(f, f), -s.Rational(1, 2)*metric[m]*metric[n]))
    minimal = w.add(kinetic, *(w.mul(x[f"KV{m}"], w.D(x["u"], m)) for m in range(4)), w.scale(w.mul(x["Kbar"], x["Lambda"]), -1))
    action = w.add(minimal, gf)
    images = {}
    for z, source in w.pairs:
        images[z], images[source] = w.EL(action, source), w.EL(action, z)
    # All Euler-derived columns; no assigned reverse source rules.
    assert images["Kbar"] == w.scale(box(x["u"]), -1)
    assert images["KL"] == w.add(w.scale(divV, -1), w.scale(x["Lambda"], xi), w.scale(x["Kbar"], -1))
    assert images["bar"] == w.scale(x["Lambda"], -1)
    square_count = 0
    for name in w.p:
        for order in range(3):
            for indices in itertools.combinations_with_replacement(range(4), order):
                assert w.Q(w.Q(w.var(name, indices), images), images) == {}
                square_count += 1
    half_master = w.add(*(w.mul(w.EL(action, z), images[z]) for z, _ in w.pairs))
    E = [w.EL(kinetic, f"V{m}") for m in range(4)]
    assert w.add(*(w.D(E[m], m) for m in range(4))) == {}
    current = [w.add(w.mul(E[m], x["u"]), w.scale(w.mul(x["Lambda"], w.D(x["u"], m)), metric[m])) for m in range(4)]
    assert half_master == w.add(*(w.D(current[m], m) for m in range(4)))
    assert all(w.EL(half_master, n) == {} for n in w.p)

    old_action = w.add(action, w.mul(x["Kbar"], x["Lambda"]))
    old_images = {n: w.EL(old_action, other) for pair in w.pairs if pair[0] != "bar" for n, other in (pair, pair[::-1])}
    old_images["bar"] = w.scale(x["Lambda"], -1)
    old_square = w.Q(old_images["KL"], old_images)
    assert old_square == w.scale(box(x["u"]), -1)
    F = w.mul(x["KL"], x["Lambda"])
    assert w.Q(w.Q(F, images), images) == {}
    old_pair = w.Q(w.Q(F, old_images), old_images)
    assert old_pair == w.scale(w.mul(x["Lambda"], box(x["u"])), -1)
    old_half = w.add(*(w.mul(w.EL(old_action, z), old_images[z]) for z, _ in w.pairs if z != "bar"))
    assert w.add(old_half, w.Q(old_action, {"bar": w.scale(x["Lambda"], -1)})) == half_master

    psi = w.mul(x["bar"], w.add(divV, w.scale(x["Lambda"], -xi/2)))
    shifts = {source: w.scale(w.EL(psi, z), -(-1)**w.p[z]) for z, source in w.pairs}
    positive = {n: w.add(x[n], shifts.get(n, {})) for n in w.p}
    negative = {n: w.add(x[n], w.scale(shifts.get(n, {}), -1)) for n in w.p}
    ungauged_images = {n: w.EL(minimal, other) for pair in w.pairs for n, other in (pair, pair[::-1])}
    for name in w.p:
        assert w.replace(w.replace(x[name], positive), negative) == x[name]
        assert w.Q(w.replace(x[name], positive), images) == w.replace(ungauged_images[name], positive)
    difference = w.add(w.replace(minimal, positive), w.scale(action, -1))
    psi_current = [w.scale(w.mul(x["bar"], w.D(x["u"], m)), metric[m]) for m in range(4)]
    assert difference == w.add(*(w.D(psi_current[m], m) for m in range(4)))
    assert w.Q(psi, ungauged_images) == gf
    return {"schema": "NONMINIMAL_BV_FREE_REPLAY_V1", "images": {n: w.record(p) for n, p in images.items()},
            "old_Q2_KL": w.record(old_square), "old_Q2_pairing": w.record(old_pair),
            "half_master_density": w.record(half_master), "master_current": [w.record(p) for p in current],
            "canonical_shifts": {n: w.record(shifts.get(n, {})) for n in w.p},
            "all_base_and_order_two_jet_squares_zero": True, "square_count": square_count,
            "maximum_jet_order_encountered": w.max_jet, "gauge_fixing_inverse_and_intertwining": True,
            "master_equation_mod_explicit_total_derivative": True, "EOM_used": False,
            "independence": {"ALGORITHM_INDEPENDENT": True, "CODE_PATH_INDEPENDENT": True,
                             "LIBRARY_INDEPENDENT": False, "RUNTIME_INDEPENDENT": False,
                             "primary_columns_imported": False, "shared_assumptions": "declared bracket, model, frozen free sector; Python and SymPy",
                             "historical_input_extractor_reused": True, "external_specialist_review": False}}


if __name__ == "__main__":
    print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
