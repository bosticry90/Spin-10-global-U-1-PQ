"""Literal promoted scalar-kinetic prerequisite, not an action repair."""
import json
from hashlib import sha256
import sympy as s
from nonminimal_bv_m08_architecture import load,matrix
from interacting_actual_h_preflight import GaugeJets
from nonminimal_bv_free import ETA


def nodes(x):
    if isinstance(x,dict):
        yield x
        for v in x.values(): yield from nodes(v)
    elif isinstance(x,list):
        for v in x: yield from nodes(v)


def build(stage=lambda n,fn:fn()):
    action=load('frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json')['action']
    terms=action['local_terms']; phi=next(t['term'] for t in terms if t['sector']=='SCALAR_KINETIC_Phi')
    components=[]
    assert phi['node']=='Add'
    for term in phi['terms']:
        k,d1,d2=term['factors']
        assert k=={'node':'ExactScalar','parity':0,'value':'1/2'} and d1==d2
        assert d1['node']=='PartialDerivative' and d1['index']=='mu' and d1['argument']['node']=='Field'
        components.append(d1['argument']['name'])
    embedding=load('frozen_action_ast_a3/A31_embeddings.json')['sectors']['Phi']
    names=['x_'+n.replace('.','_') for n in embedding['coordinate_names']]
    assert set(components)==set(names) and len(components)==len(names)==54
    rho=matrix(load('frozen_scalar_adapter_v2/SA10_physical_actions.json')['physical_H_parent'][4])[:54,:54]/s.sqrt(2)
    j=GaugeJets(0); a=j.a
    j.fields={n:(1,0,0) for n in names}; j.grades={**j.fields,'C4':(1,1,1)}; j.external={}; j.pairs=[]
    x={n:j.var(n) for n in j.grades}
    kinetic=a.add(*(a.scale(a.mul(j.D(x[n],mu),j.D(x[n],mu)),s.Rational(ETA[mu],2)) for n in components for mu in range(4)))
    forward={names[i]:a.add(*(a.scale(a.mul(x['C4'],x[names[k]]),-s.Symbol('g10')*v) for (row,k),v in rho.todok().items() if row==i)) for i in range(54)}
    residual=stage('literal_scalar_local_variation',lambda:j.Q(kinetic,forward))
    euler=stage('ghost_Euler_nondivergence',lambda:j.euler(residual,'C4'))
    records=j.record(residual); target=sorted(['C4__0','x_Phi_offdiag_0_4','x_Phi_offdiag_0_1__0'])
    selected=next(r['coefficient'] for r in records if r['word']==target)
    assert residual and euler
    inventory=[{'sector':t['sector'],'g10_occurrences':sum(n.get('node')=='Parameter' and n.get('name')=='g10' for n in nodes(t['term'])),
        'connection_fields':sorted({n['name'] for n in nodes(t['term']) if n.get('node') in ('Field','FrozenBackground') and n.get('name') in ('Abar_H','q_L','V_H')})} for t in terms]
    return {'schema':'PHASE_C_LITERAL_SCALAR_ACTION_PREREQUISITE_V1','status':'FAILED_LITERAL_SCALAR_LOCAL_GAUGE_INVARIANCE','generator':4,'scalar_sector':'Phi','coordinates':54,
        'canonical_action_sha256':action['canonical_action_sha256'],'literal_kinetic_fields':components,'kinetic_ordinary_derivatives_only':True,
        'selected_word':target,'selected_coefficient':selected,'variation':records,'ghost_Euler_residual':j.record(euler),'Euler_nonzero':True,
        'action_sector_inventory':inventory,'scope':'Literal promoted scalar kinetic AST; selected full-action coefficient has all sources, gauge fields and nonminimal fields absent. No gauge-invariant potential can supply a derivative-of-ghost coefficient.',
        'covariant_completion_adopted':False,'full_M08_reconstructed':False,'HB1_C5_authorized':False,'active_scientific_state_changed':False,'formal_authority':'34/39_UNCHANGED'}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    print('RESULT '+json.dumps(build(),sort_keys=True,separators=(',',':')))
