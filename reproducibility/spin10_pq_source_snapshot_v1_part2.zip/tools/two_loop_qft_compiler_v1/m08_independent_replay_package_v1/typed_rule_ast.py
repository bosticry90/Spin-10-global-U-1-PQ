"""Typed replay-side Feynman rules and deterministic graph lowering.

All rules are independently transcribed from immutable index-form action
operators.  Human-readable Work-Package-A formula strings are provenance
links only and are never parsed.
"""

from __future__ import annotations

from itertools import product
from typing import Any

import sympy as sp


def rat(value: str) -> dict[str, str]:
    return {"op": "rational", "value": value}


def param(name: str, power: int = 1) -> dict[str, Any]:
    return {"op": "parameter", "name": name, "power": power}


def momentum(leg: int, lorentz_leg: int | None = None) -> dict[str, Any]:
    return {"op": "momentum", "leg": leg, "lorentz_leg": lorentz_leg}


def metric(left_leg: int, right_leg: int) -> dict[str, Any]:
    return {"op": "metric", "left_leg": left_leg, "right_leg": right_leg}


def f_tensor(
    *legs: int | str,
    dummy_domains: dict[str, str] | None = None,
) -> dict[str, Any]:
    return {
        "op": "structure_constant",
        "indices": list(legs),
        "dummy_domains": dummy_domains or {},
    }


def generator(rep: str, gauge_leg: int, left_leg: int, right_leg: int) -> dict[str, Any]:
    return {
        "op": "generator",
        "representation": rep,
        "gauge_leg": gauge_leg,
        "left_leg": left_leg,
        "right_leg": right_leg,
    }


def term(
    coefficient: list[dict[str, Any]],
    lorentz: list[dict[str, Any]],
    group: list[dict[str, Any]],
    label: str,
) -> dict[str, Any]:
    return {
        "label": label,
        "coefficient_factors": coefficient,
        "lorentz_factors": lorentz,
        "group_factors": group,
    }


def propagator_rules() -> dict[str, dict[str, Any]]:
    return {
        "heavy_vector_R_xi": {
            "rule_id": "P.VH.R_xi",
            "endpoint_species": ["VH", "VH"],
            "orientation": "UNDIRECTED_REAL",
            "grassmann_parity": 0,
            "group_numerator": {"op": "delta", "space": "heavy_adjoint"},
            "components": [
                {
                    "label": "metric",
                    "coefficient_factors": [rat("1")],
                    "lorentz_numerator": [{"op": "endpoint_metric"}],
                    "denominators": [{"mass_squared": "M_V2[edge]", "power": 1}],
                },
                {
                    "label": "longitudinal",
                    "coefficient_factors": [param("xi_minus_1")],
                    "lorentz_numerator": [{"op": "endpoint_momentum_product"}],
                    "denominators": [
                        {"mass_squared": "M_V2[edge]", "power": 1},
                        {"mass_squared": "xi*M_V2[edge]", "power": 1},
                    ],
                },
            ],
            "inverse_operator_roundtrip": (
                "[(k2+M2)T+(k2/xi+M2)L]^-1="
                "T/(k2+M2)+xi*L/(k2+xi*M2)"
            ),
        },
        "light_vector_R_etaH": {
            "rule_id": "P.qL.R_etaH",
            "endpoint_species": ["qL", "qL"],
            "orientation": "UNDIRECTED_REAL",
            "grassmann_parity": 0,
            "group_numerator": {"op": "delta", "space": "light_adjoint"},
            "components": [
                {
                    "label": "metric",
                    "coefficient_factors": [rat("1")],
                    "lorentz_numerator": [{"op": "endpoint_metric"}],
                    "denominators": [{"mass_squared": "0", "power": 1}],
                },
                {
                    "label": "longitudinal",
                    "coefficient_factors": [param("eta_H_minus_1")],
                    "lorentz_numerator": [{"op": "endpoint_momentum_product"}],
                    "denominators": [{"mass_squared": "0", "power": 2}],
                },
            ],
            "inverse_operator_roundtrip": "[k2*T+(k2/eta_H)*L]^-1=T/k2+eta_H*L/k2",
        },
        "heavy_ghost_directed": {
            "rule_id": "P.ubarH_uH.directed",
            "endpoint_species": ["Hbar", "H"],
            "orientation": "DIRECTED_ANTIGHOST_TO_GHOST",
            "grassmann_parity": 1,
            "group_numerator": {"op": "delta", "space": "heavy_adjoint"},
            "components": [{
                "label": "scalar",
                "coefficient_factors": [rat("1")],
                "lorentz_numerator": [],
                "denominators": [{"mass_squared": "xi*M_V2[edge]", "power": 1}],
            }],
        },
        "light_ghost_directed": {
            "rule_id": "P.cbarL_cL.directed",
            "endpoint_species": ["Lbar", "L"],
            "orientation": "DIRECTED_ANTIGHOST_TO_GHOST",
            "grassmann_parity": 1,
            "group_numerator": {"op": "delta", "space": "light_adjoint"},
            "components": [{
                "label": "scalar",
                "coefficient_factors": [rat("1")],
                "lorentz_numerator": [],
                "denominators": [{"mass_squared": "0", "power": 1}],
            }],
        },
        "heavy_scalar_real": {
            "rule_id": "P.SH.real",
            "endpoint_species": ["S", "S"],
            "orientation": "UNDIRECTED_SELF_CONJUGATE",
            "grassmann_parity": 0,
            "group_numerator": {"op": "delta", "space": "heavy_scalar_real"},
            "components": [{
                "label": "scalar",
                "coefficient_factors": [rat("1")],
                "lorentz_numerator": [],
                "denominators": [{"mass_squared": "m_S2[edge]", "power": 1}],
            }],
        },
        "goldstone_real": {
            "rule_id": "P.XH.real",
            "endpoint_species": ["X", "X"],
            "orientation": "UNDIRECTED_SELF_CONJUGATE",
            "grassmann_parity": 0,
            "group_numerator": {"op": "delta", "space": "heavy_goldstone_real"},
            "components": [{
                "label": "scalar",
                "coefficient_factors": [rat("1")],
                "lorentz_numerator": [],
                "denominators": [{"mass_squared": "xi*M_V2[edge]", "power": 1}],
            }],
        },
    }


def vertex_rules() -> dict[str, dict[str, Any]]:
    g = param("g10")
    g2 = param("g10", 2)
    rules: dict[str, dict[str, Any]] = {}

    def add(rule_id: str, fields: list[str], terms: list[dict], order: list[int], provenance: str, symmetry: str) -> None:
        rules[rule_id] = {
            "rule_id": rule_id,
            "ordered_fields": fields,
            "incoming_momentum_convention": "ALL_INCOMING",
            "terms": terms,
            "grassmann_leg_order": order,
            "identical_leg_symmetry": symmetry,
            "action_term_provenance": provenance,
            "derived_without_display_string_parser": True,
        }

    add(
        "A.HH.VH.derivative",
        ["Hbar", "H", "VH"],
        [term([g], [momentum(1, 2)], [f_tensor(0, 1, 2)], "derivative_on_heavy_ghost")],
        [0, 1],
        "bar_u_i f_i_j_k V_k^mu d_mu u_j",
        "NONE",
    )
    add(
        "A.HH.qL.covariant_laplacian",
        ["Hbar", "H", "qL"],
        [
            term([rat("-2"), g], [momentum(1, 2)], [f_tensor(2, 0, 1)], "two_q_dot_partial"),
            term([rat("-1"), g], [momentum(2, 2)], [f_tensor(2, 0, 1)], "partial_dot_q"),
        ],
        [0, 1],
        "-bar_u d_H^2 u",
        "NONE",
    )
    add(
        "A.LL.qL.fp_current",
        ["Lbar", "L", "qL"],
        [
            term([rat("-1"), g], [momentum(2, 2)], [f_tensor(0, 2, 1)], "partial_on_q"),
            term([rat("-1"), g], [momentum(1, 2)], [f_tensor(0, 2, 1)], "partial_on_c"),
        ],
        [0, 1],
        "-bar_c_alpha partial_mu(f_alpha_beta_gamma q_beta^mu c_gamma)",
        "NONE",
    )
    add(
        "A.HH.qLqL.seagull",
        ["Hbar", "H", "qL", "qL"],
        [
            term([rat("-1/2"), g2], [metric(2, 3)], [f_tensor(2, 0, "m", dummy_domains={"m": "heavy"}), f_tensor(3, "m", 1, dummy_domains={"m": "heavy"})], "ordered_alpha_beta"),
            term([rat("-1/2"), g2], [metric(2, 3)], [f_tensor(3, 0, "m", dummy_domains={"m": "heavy"}), f_tensor(2, "m", 1, dummy_domains={"m": "heavy"})], "ordered_beta_alpha"),
        ],
        [0, 1],
        "-bar_u d_H^2 u quadratic light-vector term",
        "SWAP_LEGS_2_3",
    )
    add(
        "A.HH.VHVH.seagull",
        ["Hbar", "H", "VH", "VH"],
        [
            term([g2], [metric(2, 3)], [f_tensor(0, 2, "a", dummy_domains={"a": "light"}), f_tensor("a", 3, 1, dummy_domains={"a": "light"})], "ordered_k_l"),
            term([g2], [metric(2, 3)], [f_tensor(0, 3, "a", dummy_domains={"a": "light"}), f_tensor("a", 2, 1, dummy_domains={"a": "light"})], "ordered_l_k"),
        ],
        [0, 1],
        "bar_u_i f_i_k_alpha f_alpha_l_j V_k V_l u_j",
        "SWAP_LEGS_2_3",
    )
    add(
        "A.HH.VHqL.mixed",
        ["Hbar", "H", "VH", "qL"],
        [term([g2], [metric(2, 3)], [f_tensor(0, "m", 2, dummy_domains={"m": "heavy"}), f_tensor(3, "m", 1, dummy_domains={"m": "heavy"})], "covariant_derivative_mixed")],
        [0, 1],
        "bar_u_i f_i_m_k V_k^mu d_mu_m_j u_j",
        "NONE",
    )
    add(
        "A.HHHH.equivariant",
        ["Hbar", "H", "Hbar", "H"],
        [
            term([rat("1/2"), param("xi"), g2], [], [f_tensor(0, 1, "a", dummy_domains={"a": "light"}), f_tensor(2, 3, "a", dummy_domains={"a": "light"})], "direct"),
            term([rat("-1/2"), param("xi"), g2], [], [f_tensor(0, 3, "a", dummy_domains={"a": "light"}), f_tensor(2, 1, "a", dummy_domains={"a": "light"})], "exchange"),
        ],
        [0, 1, 2, 3],
        "xi/2 f_i_j_alpha f_k_l_alpha bar_u_i u_j bar_u_k u_l",
        "GRASSMANN_ANTISYMMETRIZED",
    )
    add(
        "A.HH.scalar",
        ["Hbar", "H", "S"],
        [term([param("xi"), g2], [], [{"op": "heavy_ghost_scalar_tensor", "legs": [0, 1, 2]}], "scalar")],
        [0, 1],
        "xi bar_u_i f_i_a x_a_j_b varphi_b u_j",
        "NONE",
    )
    add(
        "A.HH.goldstone",
        ["Hbar", "H", "X"],
        [term([param("xi"), g, param("M", 1)], [], [f_tensor(0, 1, 2)], "goldstone")],
        [0, 1],
        "xi bar_u_i f_i_j_k M_k chi_k u_j",
        "NONE",
    )
    add(
        "A.qL.VH.VH.gauge_fixing",
        ["qL", "VH", "VH"],
        [
            term([rat("-1"), g, param("xi", -1)], [momentum(1, 1), metric(0, 2)], [f_tensor(1, 0, 2)], "dV_left"),
            term([g, param("xi", -1)], [momentum(2, 2), metric(0, 1)], [f_tensor(1, 0, 2)], "dV_right"),
        ],
        [],
        "-(d_mu V_i^mu)^2/(2 xi) cross term",
        "HEAVY_LEG_ANTISYMMETRY",
    )

    ggg_terms = [
        term([g], [metric(0, 1), momentum(0, 2)], [f_tensor(0, 1, 2)], "g01_p0"),
        term([rat("-1"), g], [metric(0, 1), momentum(1, 2)], [f_tensor(0, 1, 2)], "g01_minus_p1"),
        term([g], [metric(1, 2), momentum(1, 0)], [f_tensor(0, 1, 2)], "g12_p1"),
        term([rat("-1"), g], [metric(1, 2), momentum(2, 0)], [f_tensor(0, 1, 2)], "g12_minus_p2"),
        term([g], [metric(2, 0), momentum(2, 1)], [f_tensor(0, 1, 2)], "g20_p2"),
        term([rat("-1"), g], [metric(2, 0), momentum(0, 1)], [f_tensor(0, 1, 2)], "g20_minus_p0"),
    ]
    add(
        "A.GGG.yang_mills",
        ["A", "A", "A"],
        ggg_terms,
        [],
        "-F_A_mu_nu F_A_mu_nu/4",
        "TOTAL_ANTISYMMETRY_WITH_GROUP_FACTOR",
    )
    add(
        "A.GGGG.yang_mills",
        ["A", "A", "A", "A"],
        [
            term([rat("-1"), g2], [metric(0, 2), metric(1, 3)], [f_tensor(0, 1, "e", dummy_domains={"e": "full_adjoint"}), f_tensor(2, 3, "e", dummy_domains={"e": "full_adjoint"})], "channel_s_1"),
            term([g2], [metric(0, 3), metric(1, 2)], [f_tensor(0, 1, "e", dummy_domains={"e": "full_adjoint"}), f_tensor(2, 3, "e", dummy_domains={"e": "full_adjoint"})], "channel_s_2"),
        ],
        [],
        "-F_A_mu_nu F_A_mu_nu/4 commutator squared plus channel permutations",
        "FULL_BOSONIC_PERMUTATION_COMPLETION_REQUIRED_BY_ASSIGNMENT",
    )
    add(
        "A.scalar.scalar.vector",
        ["R", "R", "A"],
        [
            term([g], [momentum(1, 2)], [generator("parent_real_scalar", 2, 0, 1)], "p1"),
            term([rat("-1"), g], [momentum(0, 2)], [generator("parent_real_scalar", 2, 0, 1)], "minus_p0"),
        ],
        [],
        "one_half (D_mu varphi)_a (D_mu varphi)_a",
        "ANTISYMMETRIC_GENERATOR_COMPENSATES_SCALAR_SWAP",
    )
    add(
        "A.scalar.scalar.vector.vector",
        ["R", "R", "A", "A"],
        [
            term([rat("1/2"), g2], [metric(2, 3)], [{"op": "generator_anticommutator", "gauge_legs": [2, 3], "scalar_legs": [0, 1]}], "seagull")
        ],
        [],
        "one_half (D_mu varphi)_a (D_mu varphi)_a quadratic vector term",
        "SCALAR_AND_VECTOR_PAIR_SYMMETRY",
    )
    return rules


def propagator_rule_for(left: str, right: str) -> str:
    pair = {left, right}
    if pair == {"VH"}:
        return "heavy_vector_R_xi"
    if pair == {"qL"}:
        return "light_vector_R_etaH"
    if pair == {"Hbar", "H"}:
        return "heavy_ghost_directed"
    if pair == {"Lbar", "L"}:
        return "light_ghost_directed"
    if pair == {"S"}:
        return "heavy_scalar_real"
    if pair == {"X"}:
        return "goldstone_real"
    raise KeyError((left, right))


def solve_routing(graph: dict[str, Any]) -> dict[str, Any]:
    edges = graph["internal_edges"]
    vertex_count = len(graph["vertex_families"])
    edge_count = len(edges)
    assert edge_count == vertex_count
    incidence = sp.zeros(vertex_count, edge_count)
    for edge_index, edge in enumerate(edges):
        left_v = int(edge["left"][0])
        right_v = int(edge["right"][0])
        incidence[left_v, edge_index] = -1
        incidence[right_v, edge_index] = 1
    reduced = incidence[:-1, :]
    null = reduced.nullspace()
    assert len(null) == 1
    cycle = null[0]
    nonzero = next(value for value in cycle if value != 0)
    cycle = sp.simplify(cycle / nonzero)

    external_coefficients = {"external_antighost": (1, 0), "external_ghost": (0, 1), "external_vector": (-1, -1)}
    ext_at_vertex = [[sp.Integer(0), sp.Integer(0)] for _ in range(vertex_count)]
    for vertex, _slot, label in graph["external_attachments"]:
        values = external_coefficients[label]
        ext_at_vertex[int(vertex)][0] += values[0]
        ext_at_vertex[int(vertex)][1] += values[1]

    def particular(component: int) -> sp.Matrix:
        variables = sp.symbols("r0:" + str(edge_count))
        equations = []
        for vertex in range(vertex_count - 1):
            equations.append(
                sum(incidence[vertex, edge] * variables[edge] for edge in range(edge_count))
                + ext_at_vertex[vertex][component]
            )
        equations.append(variables[0])
        solution = sp.solve(equations, variables, dict=True)
        assert len(solution) == 1
        return sp.Matrix([sp.simplify(solution[0][variable]) for variable in variables])

    pbar = particular(0)
    pghost = particular(1)
    conservation = incidence * sp.Matrix.hstack(cycle, pbar, pghost)
    for vertex in range(vertex_count):
        assert sp.simplify(conservation[vertex, 0]) == 0
        assert sp.simplify(conservation[vertex, 1] + ext_at_vertex[vertex][0]) == 0
        assert sp.simplify(conservation[vertex, 2] + ext_at_vertex[vertex][1]) == 0
    return {
        "incidence_matrix": [[str(incidence[row, col]) for col in range(edge_count)] for row in range(vertex_count)],
        "edge_momenta_oriented_left_to_right": [
            {
                "edge": index,
                "loop": str(cycle[index]),
                "p_antighost": str(pbar[index]),
                "p_ghost": str(pghost[index]),
            }
            for index in range(edge_count)
        ],
        "vertex_conservation_residual": "0",
    }


def _leg_group_indices(graph: dict[str, Any]) -> dict[tuple[int, int], str]:
    result: dict[tuple[int, int], str] = {}
    for vertex, slot, label in graph["external_attachments"]:
        result[(int(vertex), int(slot))] = "g_" + label
    for edge_index, edge in enumerate(graph["internal_edges"]):
        result[(int(edge["left"][0]), int(edge["left"][1]))] = f"g_e{edge_index}"
        result[(int(edge["right"][0]), int(edge["right"][1]))] = f"g_e{edge_index}"
    return result


def _leg_lorentz_indices(graph: dict[str, Any]) -> dict[tuple[int, int], str]:
    vector_species = {"VH", "qL"}
    result: dict[tuple[int, int], str] = {}
    for vertex, signature in enumerate(graph["field_assignments"]):
        for slot, species in enumerate(signature):
            if species in vector_species:
                result[(vertex, slot)] = f"mu_v{vertex}_s{slot}"
    for vertex, slot, label in graph["external_attachments"]:
        if label == "external_vector":
            result[(int(vertex), int(slot))] = "mu_external"
    return result


def _leg_momenta(graph: dict[str, Any], routing: dict[str, Any]) -> dict[tuple[int, int], dict[str, str]]:
    result: dict[tuple[int, int], dict[str, str]] = {}
    ext = {
        "external_antighost": {"loop": "0", "p_antighost": "1", "p_ghost": "0"},
        "external_ghost": {"loop": "0", "p_antighost": "0", "p_ghost": "1"},
        "external_vector": {"loop": "0", "p_antighost": "-1", "p_ghost": "-1"},
    }
    for vertex, slot, label in graph["external_attachments"]:
        result[(int(vertex), int(slot))] = ext[label]
    momenta = routing["edge_momenta_oriented_left_to_right"]
    for edge_index, edge in enumerate(graph["internal_edges"]):
        base = momenta[edge_index]
        for endpoint, sign in ((edge["left"], -1), (edge["right"], 1)):
            result[(int(endpoint[0]), int(endpoint[1]))] = {
                key: str(sign * sp.Rational(value)) for key, value in base.items() if key != "edge"
            }
    return result


def _instantiate_factor(factor: dict[str, Any], vertex: int, group_indices: dict, lorentz_indices: dict, leg_momenta: dict) -> dict[str, Any]:
    op = factor["op"]
    if op == "structure_constant":
        indices = []
        domains = {}
        for item in factor["indices"]:
            if isinstance(item, int):
                indices.append(group_indices[(vertex, item)])
            else:
                instantiated = f"g_dummy_v{vertex}_{item}"
                indices.append(instantiated)
                domains[instantiated] = factor.get("dummy_domains", {}).get(item, "UNSPECIFIED")
        return {"op": op, "indices": indices, "dummy_domains": domains}
    if op == "generator":
        return {
            "op": op,
            "representation": factor["representation"],
            "gauge_index": group_indices[(vertex, factor["gauge_leg"])],
            "left_index": group_indices[(vertex, factor["left_leg"])],
            "right_index": group_indices[(vertex, factor["right_leg"])],
        }
    if op in {"heavy_ghost_scalar_tensor", "generator_anticommutator"}:
        result = dict(factor)
        for key in ("legs", "gauge_legs", "scalar_legs"):
            if key in result:
                result[key.replace("legs", "indices")] = [group_indices[(vertex, leg)] for leg in result.pop(key)]
        return result
    if op == "metric":
        return {
            "op": op,
            "left": lorentz_indices[(vertex, factor["left_leg"])],
            "right": lorentz_indices[(vertex, factor["right_leg"])],
        }
    if op == "momentum":
        return {
            "op": op,
            "linear_combination": leg_momenta[(vertex, factor["leg"])],
            "lorentz_index": lorentz_indices[(vertex, factor["lorentz_leg"])],
        }
    return dict(factor)


def _vertex_terms_for_instance(family: str, signature: list[str], rules: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    base = [dict(item) for item in rules[family]["terms"]]
    if family == "A.GGG.yang_mills" and sorted(signature) == ["VH", "VH", "qL"]:
        # qVV is one physical vertex with independently derived YM and partial-GF source terms.
        q_slot = signature.index("qL")
        heavy_slots = [index for index, species in enumerate(signature) if species == "VH"]
        source = rules["A.qL.VH.VH.gauge_fixing"]
        remap = {0: q_slot, 1: heavy_slots[0], 2: heavy_slots[1]}
        for raw in source["terms"]:
            mapped = json_clone(raw)
            for factor in mapped["lorentz_factors"]:
                for key in ("leg", "lorentz_leg", "left_leg", "right_leg"):
                    if key in factor:
                        factor[key] = remap[factor[key]]
            for factor in mapped["group_factors"]:
                if "indices" in factor:
                    factor["indices"] = [remap.get(value, value) for value in factor["indices"]]
            mapped["label"] = "partial_gf_" + mapped["label"]
            base.append(mapped)
    return base


def json_clone(value: Any) -> Any:
    import json
    return json.loads(json.dumps(value))


def _grassmann_sign(graph: dict[str, Any]) -> dict[str, Any]:
    ghost_species = {"Hbar", "H", "Lbar", "L"}
    flattened = []
    external = {}
    for vertex, slot, label in graph["external_attachments"]:
        external[(int(vertex), int(slot))] = label
    for vertex, signature in enumerate(graph["field_assignments"]):
        for slot, species in enumerate(signature):
            if species in ghost_species:
                flattened.append((vertex, slot, species, external.get((vertex, slot))))
    internal_ghost_edges = [
        edge for edge in graph["internal_edges"]
        if edge["left"][2] in ghost_species or edge["right"][2] in ghost_species
    ]
    # The explicit permutation is retained; no topology-family sign is imported.
    labels = [f"v{v}s{s}" for v, s, _species, _external in flattened]
    target = []
    for label in ("external_antighost", "external_ghost"):
        target.extend(f"v{v}s{s}" for v, s, _species, ext in flattened if ext == label)
    pairs = []
    for edge in internal_ghost_edges:
        endpoints = [edge["left"], edge["right"]]
        endpoints.sort(key=lambda item: 0 if item[2].endswith("bar") else 1)
        pairs.extend(f"v{item[0]}s{item[1]}" for item in endpoints)
    target.extend(pairs)
    target.extend(label for label in labels if label not in target)
    positions = {label: index for index, label in enumerate(labels)}
    permutation = [positions[label] for label in target]
    inversions = sum(
        permutation[left] > permutation[right]
        for left in range(len(permutation))
        for right in range(left + 1, len(permutation))
    )
    return {
        "source_order": labels,
        "canonical_order": target,
        "permutation_inversions": inversions,
        "wick_permutation_sign": -1 if inversions % 2 else 1,
        "internal_ghost_edges": len(internal_ghost_edges),
        "sign_scope": (
            "FULL_WICK_PERMUTATION_FROM_ACTION_ORDER_TO_EXTERNAL_THEN_INTERNAL_"
            "ANTIGHOST_GHOST_PAIR_ORDER"
        ),
        "separate_imported_closed_loop_sign": False,
    }


def lower_graph(graph: dict[str, Any], process: str) -> dict[str, Any]:
    rules = vertex_rules()
    props = propagator_rules()
    routing = solve_routing(graph)
    group_indices = _leg_group_indices(graph)
    lorentz_indices = _leg_lorentz_indices(graph)
    leg_momenta = _leg_momenta(graph, routing)

    vertex_instances = []
    vertex_term_options = []
    for vertex, (family, signature) in enumerate(zip(graph["vertex_families"], graph["field_assignments"])):
        raw_terms = _vertex_terms_for_instance(family, signature, rules)
        instantiated = []
        for raw in raw_terms:
            instantiated.append({
                "label": raw["label"],
                "coefficient_factors": raw["coefficient_factors"],
                "lorentz_factors": [
                    _instantiate_factor(item, vertex, group_indices, lorentz_indices, leg_momenta)
                    for item in raw["lorentz_factors"]
                ],
                "group_factors": [
                    _instantiate_factor(item, vertex, group_indices, lorentz_indices, leg_momenta)
                    for item in raw["group_factors"]
                ],
            })
        vertex_instances.append({
            "vertex": vertex,
            "rule_id": family,
            "field_assignment": signature,
            "leg_group_indices": [group_indices[(vertex, slot)] for slot in range(len(signature))],
            "leg_lorentz_indices": [lorentz_indices.get((vertex, slot)) for slot in range(len(signature))],
            "leg_incoming_momenta": [leg_momenta[(vertex, slot)] for slot in range(len(signature))],
            "term_count": len(instantiated),
        })
        vertex_term_options.append(instantiated)

    propagator_instances = []
    propagator_options = []
    for edge_index, edge in enumerate(graph["internal_edges"]):
        rule_key = propagator_rule_for(edge["left"][2], edge["right"][2])
        rule = props[rule_key]
        components = []
        for component in rule["components"]:
            lorentz = []
            for factor in component["lorentz_numerator"]:
                if factor["op"] == "endpoint_metric":
                    lorentz.append({
                        "op": "metric",
                        "left": lorentz_indices[(int(edge["left"][0]), int(edge["left"][1]))],
                        "right": lorentz_indices[(int(edge["right"][0]), int(edge["right"][1]))],
                    })
                elif factor["op"] == "endpoint_momentum_product":
                    lorentz.extend([
                        {
                            "op": "edge_momentum",
                            "edge": edge_index,
                            "orientation": "LEFT_TO_RIGHT",
                            "lorentz_index": lorentz_indices[(int(edge["left"][0]), int(edge["left"][1]))],
                        },
                        {
                            "op": "edge_momentum",
                            "edge": edge_index,
                            "orientation": "LEFT_TO_RIGHT",
                            "lorentz_index": lorentz_indices[(int(edge["right"][0]), int(edge["right"][1]))],
                        },
                    ])
            components.append({
                "label": component["label"],
                "coefficient_factors": component["coefficient_factors"],
                "lorentz_factors": lorentz,
                "denominators": [
                    {
                        **denominator,
                        "edge": edge_index,
                        "momentum": routing["edge_momenta_oriented_left_to_right"][edge_index],
                    }
                    for denominator in component["denominators"]
                ],
            })
        propagator_instances.append({
            "edge": edge_index,
            "rule_id": rule["rule_id"],
            "left_endpoint": edge["left"],
            "right_endpoint": edge["right"],
            "group_index": f"g_e{edge_index}",
            "component_count": len(components),
        })
        propagator_options.append(components)

    integrand_terms = []
    graph_symmetry = rat(graph["symmetry_factor"])
    grassmann = _grassmann_sign(graph)
    wick_sign = rat(str(grassmann["wick_permutation_sign"]))
    for selected_vertices in product(*vertex_term_options):
        for selected_props in product(*propagator_options):
            integrand_terms.append({
                "coefficient_factors": [graph_symmetry, wick_sign] + [
                    factor
                    for selected in (*selected_vertices, *selected_props)
                    for factor in selected["coefficient_factors"]
                ],
                "lorentz_numerator_factors": [
                    factor
                    for selected in (*selected_vertices, *selected_props)
                    for factor in selected.get("lorentz_factors", [])
                ],
                "group_tensor_factors": [
                    factor
                    for selected in selected_vertices
                    for factor in selected["group_factors"]
                ],
                "denominators": [
                    denominator
                    for selected in selected_props
                    for denominator in selected["denominators"]
                ],
                "source_term_labels": [selected["label"] for selected in (*selected_vertices, *selected_props)],
            })

    return {
        "graph_identity": graph["replay_graph_sha256"],
        "process": process,
        "routing": routing,
        "vertex_instances": vertex_instances,
        "propagator_instances": propagator_instances,
        "grassmann_sign_certificate": grassmann,
        "pre_contraction_integrand_terms": integrand_terms,
        "integrand_term_count": len(integrand_terms),
        "free_lorentz_indices": ["mu_external"],
        "group_dummy_indices_are_shared_symbols": True,
        "lorentz_contraction_to_shifted_tensor_terms_complete": False,
    }
