"""Physical-matrix/ordered-word Phase C fiber replay, no primary import."""
import itertools
import json
import sympy as s
from nonabelian_m08_semantic_replay import geometry, load
from source_domain_transport_replay import DomainWords

IDS=[0,1,3,4,11,12,13,19,38,44]
H=[0,1,3,4,11]; M=[12,13,19,38,44]
g=s.Symbol('g10')


def build(stage=lambda n,fn:fn()):
    f,_,_=stage('physical_matrix_geometry',geometry)
    frame=load('frozen_c3/C3_representation_basis.json')
    B=s.Matrix.hstack(*(s.Matrix([sum(s.sympify(v['coefficient']) for v in row['raw_so10_coordinates'] if v['index']==i) for i in range(45)]) for row in frame['h_basis']+frame['heavy_basis']))
    G=B.T*B; conjugation=(B.inv()*B.conjugate()).applyfunc(s.simplify)
    selected={0,4,13}; history=[]
    while True:
        enlarged=selected|{i for i in range(45) if any(f.get((i,a,b),0) for a in selected for b in selected)}
        enlarged|={i for i in range(45) if any(G[i,j] or conjugation[i,j] for j in selected)}
        history.append(sorted(enlarged))
        if enlarged==selected: break
        selected=enlarged
    assert sorted(selected)==IDS and G.extract(IDS,IDS).det()
    assert f[12,13,44]==-4*s.sqrt(2)*s.I/5
    w=DomainWords(0)
    w.fields={**{'C'+str(i):(1,1,1) for i in IDS},**{prefix+str(i):grade for prefix,indices,grade in [('ubar',M,(1,-1,1)),('Lambda',M,(2,0,0)),('bar',H,(1,-1,1)),('b',H,(2,0,0))] for i in indices}}
    w.pairs=[(z,'J'+z) for z in w.fields]
    w.grades={**w.fields,**{J:(3-w.fields[z][0],-1-w.fields[z][1],1-w.fields[z][2]) for z,J in w.pairs}}
    w.p={n:grade[2] for n,grade in w.grades.items()}|{'omega'+str(i):0 for i in H}
    x={n:w.var(n) for n in w.p}
    R={h:w.add(*(w.scale(w.mul(x['C'+str(i)],x['C'+str(j)]),-f.get((h,i,j),0)/2) for i,j in itertools.product(M,repeat=2))) for h in H}
    q={}
    for i in IDS:
        q['C'+str(i)]=w.add(*(w.scale(w.mul(x['C'+str(j)],x['C'+str(k)]),-g*f.get((i,j,k),0)/2) for j,k in itertools.product(IDS,repeat=2)))
    for i in M:
        q['ubar'+str(i)]=w.add(w.scale(x['Lambda'+str(i)],-1),*(w.scale(w.mul(x['C'+str(h)],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for j in M for h in H))
        q['Lambda'+str(i)]=w.add(*(w.scale(w.mul(x['C'+str(h)],x['Lambda'+str(j)]),g*f.get((j,h,i),0)) for j in M for h in H),*(w.scale(w.mul(R[h],x['ubar'+str(j)]),g*g*f.get((j,h,i),0)) for j in M for h in H))
    for h in H: q['bar'+str(h)]=w.scale(x['b'+str(h)],-1); q['b'+str(h)]={}
    S=w.add(*(w.mul(x[J],q[z]) for z,J in w.pairs))
    # Reverse columns are independently left Euler derivatives, not copied.
    Q={n:w.EL(S,other) for pair in w.pairs for n,other in (pair,pair[::-1])}
    def zero(P,label):
        if P: raise Failure(label,w.record(P))
    counts={'forward':0,'Q_squares':0,'R_chain':0,'Cartan':0,'iota_squares':0,'TQ':0}
    for z in w.fields: zero(w.add(Q[z],w.scale(q[z],-1)),'forward_'+z); counts['forward']+=1
    for h in H:
        expected=w.add(*(w.scale(w.mul(x['C'+str(k)],R[j]),-g*f.get((h,k,j),0)) for j in H for k in H))
        zero(w.add(w.Q(R[h],Q),w.scale(expected,-1)),'derived_R_'+str(h)); counts['R_chain']+=1
    def squares():
        for n in w.grades: zero(w.Q(Q[n],Q),'Q_square_'+n); counts['Q_squares']+=1
    stage('complete_mixed_source_squares',squares)
    zero(w.bracket(S,S),'source_master')
    G_i=w.add(*(w.mul(x['JC'+str(h)],x['omega'+str(h)]) for h in H),*(w.scale(w.mul(x['Jb'+str(i)],x['omega'+str(h)],x['bar'+str(j)]),g*f.get((i,h,j),0)) for i,h,j in itertools.product(H,repeat=3)))
    I={n:w.EL(G_i,other) for pair in w.pairs for n,other in (pair,pair[::-1])}
    T={}
    for prefix,indices,dual in [('C',IDS,False),('ubar',M,True),('Lambda',M,True),('bar',H,False),('b',H,False)]:
        for i in indices:
            T[prefix+str(i)]=w.add(*(w.scale(w.mul(x['omega'+str(h)],x[prefix+str(j)]),g*f.get((j,h,i),0) if dual else -g*f.get((i,h,j),0)) for j in indices for h in H))
            T['J'+prefix+str(i)]=w.add(*(w.scale(w.mul(x['omega'+str(h)],x['J'+prefix+str(j)]),-g*f.get((i,h,j),0) if dual else g*f.get((j,h,i),0)) for j in indices for h in H))
    for n in w.grades:
        zero(w.add(w.Q(Q[n],I),w.Q(I[n],Q),w.scale(T[n],-1)),'Cartan_'+n); counts['Cartan']+=1
        zero(w.Q(I[n],I),'iota_square_'+n); counts['iota_squares']+=1
        zero(w.add(w.act(Q[n],T,0),w.scale(w.Q(T[n],Q),-1)),'TQ_'+n); counts['TQ']+=1
    F=w.add(*(w.mul(x['JC'+str(h)],R[h]) for h in H)); image=w.Q(F,Q)
    assert F and image
    for name,P in [('F',F),('QF',image)]: zero(w.Q(P,I),'horizontal_'+name); zero(w.act(P,T,0),'invariant_'+name)
    return {'schema':'PHASE_C_MIXED_SOURCE_PREREQUISITE_V1','status':'PASS_MIXED_SOURCE_FIBER_ONLY','ids':IDS,'closure':history,'canonical_pairs':len(w.pairs),'generators':len(w.grades),'counts':counts,
        'source_master':w.record(S),'images':{n:w.record(P) for n,P in Q.items()},'contraction':{n:w.record(P) for n,P in I.items()},'R':{str(h):w.record(P) for h,P in R.items()},'domain':{'F':w.record(F),'QF':w.record(image)},
        'derivatives_or_physical_action_tested':False,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}


class Failure(Exception):
    def __init__(self,label,rows): self.evidence={'identity':label,'residual':rows,'first_component':rows[0]}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    try: result=build(lambda n,fn:(print('STAGE '+n,flush=True),fn())[1])
    except Failure as e: result={'schema':'PHASE_C_MIXED_SOURCE_PREREQUISITE_V1','status':'FAILED_FIRST_PREREQUISITE','witness':e.evidence,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
