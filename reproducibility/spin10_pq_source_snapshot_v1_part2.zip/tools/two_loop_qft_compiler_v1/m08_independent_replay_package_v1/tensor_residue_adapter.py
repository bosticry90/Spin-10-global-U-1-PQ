"""Exact Lorentz/index lowering for the independent M08 replay.

The adapter consumes only replay-side typed integrands.  It shifts loop
momenta after Feynman parametrization, enumerates isotropic tensor pairings,
and delegates Laurent-pole extraction to the frozen B2 engine.
"""

from __future__ import annotations

from functools import lru_cache
from itertools import product
import json
from typing import Any, Iterable

import sympy as sp

from nonexceptional_feynman_parameter_engine import (
    D,
    ShiftedTensorTerm,
    feynman_delta,
    is_local_polynomial,
    shifted_tensor_term_pole,
    simplex_symbols,
)


PBAR2, PGHOST2, PBAR_PGHOST = sp.symbols(
    "p_antighost_squared p_ghost_squared p_antighost_dot_p_ghost"
)
XI, ETA_H, G10, MASS = sp.symbols("xi eta_H g10 M")


def _factor_expression(factor: dict[str, Any]) -> sp.Expr:
    if factor["op"] == "rational":
        return sp.Rational(factor["value"])
    if factor["op"] != "parameter":
        raise ValueError(f"unsupported coefficient factor: {factor}")
    name = factor["name"]
    values = {
        "xi": XI,
        "eta_H": ETA_H,
        "g10": G10,
        "M": MASS,
        "xi_minus_1": XI - 1,
        "eta_H_minus_1": ETA_H - 1,
    }
    if name not in values:
        values[name] = sp.Symbol(name)
    return values[name] ** int(factor.get("power", 1))


def coefficient_expression(factors: Iterable[dict[str, Any]]) -> sp.Expr:
    return sp.prod(_factor_expression(factor) for factor in factors)


def simplex_integrate_polynomial(
    expression: sp.Expr, parameters: tuple[sp.Symbol, ...]
) -> sp.Expr:
    """Exact Dirichlet-simplex integral without nested symbolic antiderivatives."""
    polynomial = sp.Poly(sp.expand(expression), *parameters)
    dimension_factor = len(parameters) - 1
    result = sp.Integer(0)
    for powers, coefficient in polynomial.terms():
        numerator = sp.prod(sp.factorial(power) for power in powers)
        denominator = sp.factorial(dimension_factor + sum(powers))
        result += coefficient * numerator / denominator
    return sp.cancel(result)


def _evaluate_shifted_terms_fast(
    denominator_count: int,
    terms: Iterable[ShiftedTensorTerm],
    parameters: tuple[sp.Symbol, ...],
    delta_expression: sp.Expr,
) -> dict[str, sp.Expr]:
    by_tensor: dict[str, sp.Expr] = {}
    for term in terms:
        pole = shifted_tensor_term_pole(denominator_count, term).subs(
            sp.Symbol("Delta", positive=True), delta_expression
        )
        by_tensor[term.tensor_label] = sp.expand(
            by_tensor.get(term.tensor_label, sp.Integer(0)) + pole
        )
    return {
        label: simplex_integrate_polynomial(value, parameters)
        for label, value in by_tensor.items()
    }


def _mass_expression(text: str, edge: int) -> sp.Expr:
    mass = sp.Symbol(f"M_V2_e{edge}", nonnegative=True)
    scalar_mass = sp.Symbol(f"m_S2_e{edge}", nonnegative=True)
    table = {
        "0": sp.Integer(0),
        "M_V2[edge]": mass,
        "xi*M_V2[edge]": XI * mass,
        "m_S2[edge]": scalar_mass,
    }
    if text not in table:
        raise ValueError(f"unsupported mass expression: {text}")
    return table[text]


def _routing_vector(momentum: dict[str, Any]) -> tuple[sp.Expr, sp.Expr, sp.Expr]:
    return (
        sp.Rational(momentum["loop"]),
        sp.Rational(momentum["p_antighost"]),
        sp.Rational(momentum["p_ghost"]),
    )


def _dot(left: tuple[sp.Expr, sp.Expr], right: tuple[sp.Expr, sp.Expr]) -> sp.Expr:
    lp, lg = left
    rp, rg = right
    return sp.expand(lp * rp * PBAR2 + lg * rg * PGHOST2 + (lp * rg + lg * rp) * PBAR_PGHOST)


def denominator_data(
    denominators: list[dict[str, Any]],
) -> tuple[tuple[sp.Expr, ...], tuple[tuple[sp.Expr, sp.Expr], ...]]:
    masses: list[sp.Expr] = []
    shifts: list[tuple[sp.Expr, sp.Expr]] = []
    for denominator in denominators:
        loop, pbar, pghost = _routing_vector(denominator["momentum"])
        if loop not in (sp.Integer(-1), sp.Integer(1)):
            raise ValueError(f"denominator loop coefficient must be +/-1, got {loop}")
        shift = (sp.simplify(pbar / loop), sp.simplify(pghost / loop))
        for _ in range(int(denominator["power"])):
            masses.append(_mass_expression(denominator["mass_squared"], int(denominator["edge"])))
            shifts.append(shift)
    return tuple(masses), tuple(shifts)


@lru_cache(maxsize=None)
def perfect_matchings(items: tuple[int, ...]) -> tuple[tuple[tuple[int, int], ...], ...]:
    if not items:
        return ((),)
    if len(items) % 2:
        return ()
    first = items[0]
    result = []
    for offset in range(1, len(items)):
        second = items[offset]
        rest = items[1:offset] + items[offset + 1 :]
        for matching in perfect_matchings(rest):
            result.append(((first, second),) + matching)
    return tuple(result)


class _DisjointSet:
    def __init__(self) -> None:
        self.parent: dict[str, str] = {}

    def add(self, item: str) -> None:
        self.parent.setdefault(item, item)

    def find(self, item: str) -> str:
        self.add(item)
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self.parent[right_root] = left_root


def _network_structure(
    metrics: list[tuple[str, str]],
    vector_indices: list[str],
    selected_kinds: tuple[str, ...],
    matching: tuple[tuple[int, int], ...],
) -> str:
    dsu = _DisjointSet()
    for left, right in metrics:
        dsu.union(left, right)
    for index in vector_indices:
        dsu.add(index)
    dsu.add("mu_external")
    for left, right in matching:
        dsu.union(vector_indices[left], vector_indices[right])

    terminals: dict[str, list[str]] = {}
    for position, kind in enumerate(selected_kinds):
        if kind != "L":
            terminals.setdefault(dsu.find(vector_indices[position]), []).append(kind)

    components: dict[str, set[str]] = {}
    for item in dsu.parent:
        components.setdefault(dsu.find(item), set()).add(item)

    scalar_factors: list[str] = []
    free_factor: str | None = None
    for root, indices in components.items():
        component_terminals = terminals.get(root, [])
        has_free = "mu_external" in indices
        if has_free:
            if len(component_terminals) != 1:
                if not component_terminals and len(indices) == 1:
                    continue
                raise ValueError(
                    f"free-index component requires one external vector terminal: {indices}, {component_terminals}"
                )
            if free_factor is not None:
                raise ValueError("more than one free Lorentz component")
            free_factor = "pbar_mu" if component_terminals[0] == "P" else "pghost_mu"
        elif len(component_terminals) == 2:
            pair = tuple(sorted(component_terminals))
            scalar_factors.append({
                ("P", "P"): "pbar2",
                ("P", "R"): "pbar_pghost",
                ("R", "R"): "pghost2",
            }[pair])
        elif len(component_terminals) == 0:
            scalar_factors.append("D")
        else:
            raise ValueError(
                f"closed Lorentz component requires zero or two terminals: {indices}, {component_terminals}"
            )
    if free_factor is None:
        raise ValueError("three-point vector pole lost its free Lorentz index")
    return "*".join([free_factor] + sorted(scalar_factors))


def _structure_expression(label: str) -> sp.Expr:
    values = {
        "pbar2": PBAR2,
        "pghost2": PGHOST2,
        "pbar_pghost": PBAR_PGHOST,
        "D": D,
    }
    result = sp.Integer(1)
    for item in label.split("*")[1:]:
        result *= values[item]
    return result


def _canonical_structure(label: str) -> tuple[str, sp.Expr]:
    parts = label.split("*")
    free = parts[0]
    scalars = [item for item in parts[1:] if item != "D"]
    d_power = sum(item == "D" for item in parts[1:])
    canonical = "*".join([free] + sorted(scalars))
    return canonical, D**d_power


def _vector_factors(
    lorentz_factors: list[dict[str, Any]],
    qbar: tuple[sp.Expr, sp.Expr],
    routing: list[dict[str, Any]],
) -> tuple[list[tuple[str, str]], list[str], list[tuple[sp.Expr, sp.Expr, sp.Expr]]]:
    metrics: list[tuple[str, str]] = []
    indices: list[str] = []
    vectors: list[tuple[sp.Expr, sp.Expr, sp.Expr]] = []
    for factor in lorentz_factors:
        if factor["op"] == "metric":
            metrics.append((factor["left"], factor["right"]))
            continue
        if factor["op"] == "momentum":
            loop, pbar, pghost = _routing_vector(factor["linear_combination"])
            index = factor["lorentz_index"]
        elif factor["op"] == "edge_momentum":
            loop, pbar, pghost = _routing_vector(routing[int(factor["edge"])])
            index = factor["lorentz_index"]
        else:
            raise ValueError(f"unsupported Lorentz factor: {factor}")
        # k = ell - Qbar after completing the denominator square.
        indices.append(index)
        vectors.append((loop, sp.expand(pbar - loop * qbar[0]), sp.expand(pghost - loop * qbar[1])))
    return metrics, indices, vectors


def shifted_terms_from_integrand(
    integrand: dict[str, Any],
    routing: list[dict[str, Any]],
) -> tuple[int, tuple[sp.Symbol, ...], sp.Expr, list[ShiftedTensorTerm], dict[str, Any]]:
    masses, shifts = denominator_data(integrand["denominators"])
    count = len(masses)
    parameters = simplex_symbols(count)
    qbar = (
        sp.expand(sum(parameters[index] * shifts[index][0] for index in range(count))),
        sp.expand(sum(parameters[index] * shifts[index][1] for index in range(count))),
    )
    q_dot = tuple(tuple(_dot(left, right) for right in shifts) for left in shifts)
    delta = feynman_delta(masses, q_dot, parameters)
    metrics, vector_indices, vectors = _vector_factors(
        integrand["lorentz_numerator_factors"], qbar, routing
    )
    base = coefficient_expression(integrand["coefficient_factors"])
    aggregated: dict[tuple[int, str], sp.Expr] = {}
    raw_selection_count = 0
    uv_relevant_selection_count = 0
    pairing_count = 0
    minimum_uv_tensor_rank = max(0, 2 * (count - 2))
    choices = []
    for loop, pbar, pghost in vectors:
        local = []
        if loop != 0:
            local.append(("L", loop))
        if pbar != 0:
            local.append(("P", pbar))
        if pghost != 0:
            local.append(("R", pghost))
        choices.append(local)
    for selection in product(*choices):
        raw_selection_count += 1
        kinds = tuple(item[0] for item in selection)
        loop_positions = tuple(index for index, kind in enumerate(kinds) if kind == "L")
        if len(loop_positions) % 2 or len(loop_positions) < minimum_uv_tensor_rank:
            continue
        uv_relevant_selection_count += 1
        selection_coefficient = sp.prod(item[1] for item in selection)
        for matching in perfect_matchings(loop_positions):
            pairing_count += 1
            raw_label = _network_structure(metrics, vector_indices, kinds, matching)
            label, d_factor = _canonical_structure(raw_label)
            key = (len(loop_positions), label)
            aggregated[key] = sp.expand(
                aggregated.get(key, sp.Integer(0)) + base * selection_coefficient * d_factor
            )
    terms = [
        ShiftedTensorTerm(coefficient, rank, tensor_label=label)
        for (rank, label), coefficient in aggregated.items()
        if coefficient != 0
    ]
    certificate = {
        "denominator_count_after_power_expansion": count,
        "feynman_parameters": [str(item) for item in parameters],
        "denominator_shifts": [[sp.sstr(item) for item in shift] for shift in shifts],
        "masses_squared": [sp.sstr(item) for item in masses],
        "qbar": [sp.sstr(item) for item in qbar],
        "delta": sp.sstr(delta),
        "raw_component_selections": raw_selection_count,
        "minimum_uv_tensor_rank": minimum_uv_tensor_rank,
        "uv_relevant_component_selections": uv_relevant_selection_count,
        "isotropic_pairings_emitted": pairing_count,
        "aggregated_shifted_tensor_terms": len(terms),
        "maximum_tensor_rank": max((term.tensor_rank for term in terms), default=0),
    }
    return count, parameters, delta, terms, certificate


def evaluate_integrand_term(
    integrand: dict[str, Any],
    routing: list[dict[str, Any]],
) -> dict[str, Any]:
    count, parameters, delta, terms, certificate = shifted_terms_from_integrand(integrand, routing)
    poles = _evaluate_shifted_terms_fast(count, terms, parameters, delta)
    locality = {
        label: is_local_polynomial(value, (PBAR2, PGHOST2, PBAR_PGHOST))
        for label, value in poles.items()
    }
    return {
        "source_term_labels": integrand["source_term_labels"],
        "group_tensor_ast": integrand["group_tensor_factors"],
        "group_tensor_key": json.dumps(
            integrand["group_tensor_factors"], sort_keys=True, separators=(",", ":")
        ),
        "tensor_reduction_certificate": certificate,
        "shifted_tensor_terms": [
            {
                "coefficient": sp.sstr(term.coefficient),
                "tensor_rank": term.tensor_rank,
                "tensor_label": term.tensor_label,
            }
            for term in terms
        ],
        "local_poles": {label: sp.sstr(sp.factor(value)) for label, value in poles.items()},
        "locality": locality,
        "all_poles_local": all(locality.values()),
    }


def evaluate_lowered_graph(lowered: dict[str, Any]) -> dict[str, Any]:
    routing = lowered["routing"]["edge_momenta_oriented_left_to_right"]
    records = [
        evaluate_integrand_term(term, routing)
        for term in lowered["pre_contraction_integrand_terms"]
    ]
    combined: dict[tuple[str, str], sp.Expr] = {}
    group_asts: dict[str, list[dict[str, Any]]] = {}
    maximum_rank = 0
    for record in records:
        key = record["group_tensor_key"]
        group_asts[key] = record["group_tensor_ast"]
        maximum_rank = max(
            maximum_rank,
            int(record["tensor_reduction_certificate"]["maximum_tensor_rank"]),
        )
        for label, value in record["local_poles"].items():
            combined[(key, label)] = sp.simplify(
                combined.get((key, label), sp.Integer(0)) + sp.sympify(value)
            )
    operator_terms = [
        {
            "group_tensor_ast": group_asts[group_key],
            "lorentz_structure": label,
            "coefficient": sp.sstr(sp.factor(value)),
        }
        for (group_key, label), value in sorted(combined.items())
        if value != 0
    ]
    return {
        "graph_identity": lowered["graph_identity"],
        "process": lowered["process"],
        "integrand_term_count": lowered["integrand_term_count"],
        "integrand_term_residues": records,
        "local_pole_operator": operator_terms,
        "maximum_tensor_rank_after_longitudinal_expansion": maximum_rank,
        "all_poles_local": all(record["all_poles_local"] for record in records),
        "nonlocal_pole": "ABSENT" if all(record["all_poles_local"] for record in records) else "PRESENT",
    }
