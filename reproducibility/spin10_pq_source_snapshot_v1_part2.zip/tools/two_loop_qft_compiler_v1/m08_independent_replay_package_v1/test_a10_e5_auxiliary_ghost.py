"""UV tensor, odd-source, tadpole and full reference regression obligations."""
import unittest
from audit_a10_e5_auxiliary_ghost import *


class AuxiliaryGhostTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_all2025_Box_and20250_components(self):self.assertTrue(self.c['all2025_Box_and20250_symmetric_components_compared'])
    def test_all10_unit_components(self):self.assertEqual(len(self.u['unit_residues']['a']['all10_derivative_coefficients']),10)
    def test_six_off_diagonal_zeros(self):self.assertTrue(all(self.u['unit_residues']['a']['all10_derivative_coefficients'][f'{mu},{nu}']=='0' for mu in range(4) for nu in range(mu+1,4)))
    def test_correct_Minkowski_diagonal(self):self.assertEqual([self.u['unit_residues']['a']['all10_derivative_coefficients'][f'{mu},{mu}'] for mu in range(4)],['1','-1','-1','-1'])
    def test_internal_and_external_derivative_residues(self):self.assertEqual(self.u['unit_residues']['a']['Box_coefficient'],'1');self.assertEqual(self.u['unit_residues']['c']['Box_coefficient'],'-1')
    def test_full_GF_current_kernel_not_dropped(self):self.assertTrue(self.u['omitted_GF_current_full_kernel_nonzero']);self.assertEqual(self.u['unit_residues']['B']['Box_coefficient'],'0')
    def test_missing_mixed_edge_detected(self):self.assertEqual(self.u['omitted_mixed_edge_residue']['Box_coefficient'],'0')
    def test_missing_second_denominator_Taylor_detected(self):self.assertEqual(self.u['omitted_second_inverse_Taylor_residue']['Box_coefficient'],'0')
    def test_zero_polynomial_UV_degree_control(self):self.assertEqual(angular(s.Integer(0),'primary',1),0)
    def test_source_cubic_and_quartic_retained(self):self.assertEqual(self.a['source_inventory']['raw_source_cubic_terms'],180);self.assertEqual(self.a['source_inventory']['raw_source_quartic_terms'],836)
    def test_quartic_tadpole_two_jet_zero_before_integral(self):self.assertEqual(self.a['source_inventory']['source_quartic_tadpole_two_derivative_coefficient_before_integration'],0)
    def test_tadpole_and_bubble_heat_profiles_distinct(self):self.assertEqual((self.u['bubble_heat_profile'],self.u['tadpole_heat_profile']),(4,2))
    def test_no_whole_tadpole_or_no_jet_promotion(self):self.assertFalse(self.c['mass_and_cutoff_power_no_jet_amplitudes_qualified'])
    def test_full_ghost_and_mixed_principal_reference(self):self.assertTrue(self.q['ghost_reference']['all45_H_and_M_leading_ghost_pairs_unit']);self.assertTrue(self.q['mixed_reference']['all45_mixed_principal_pairs_checked'])
    def test_scalar_Orbit_odd_edge_screening(self):self.assertEqual(self.a['other_vertex_exclusions']['scalar_Orbit_ghost_cubic_terms_screened'],6688)
    def test_source_ghost_in_cubic_zero_Hessian(self):self.assertTrue(self.a['source_inventory']['external_ghost_in_cubic_zero_integrated_Hessian_one_leg'])
    def test_no_lower_order_candidate(self):self.assertFalse(self.c['lower_candidate_residual'])
    def test_rank_and_charged_source_directions(self):self.assertEqual(self.q['heavy_Casimir_rank'],32);self.assertEqual(self.q['physical_nonzero_Box_slots'],56)
    def test_all12_homogeneous_H_only(self):self.assertEqual(self.a['all12_homogeneous_H_identities'],list(range(12)));self.assertFalse(self.a['full_local_H_jet_Ward_claimed'])
    def test_both_actual_second_jet_currents(self):self.assertTrue(self.a['full_mixed_IBP_currents']);self.assertTrue(self.a['full_source_Box_IBP_currents'])
    def test_wrong_odd_source_Euler_sign(self):self.assertEqual(self.c['odd_source_Euler_negative_control']['wrong_even_source_Euler_residual'][0]['coefficient'],'-16/5')
    def test_odd_Euler_signed_deletion(self):self.assertTrue(self.c['odd_source_Euler_negative_control']['ordered_odd_deletion_agrees']);self.assertFalse(self.c['odd_source_Euler_negative_control']['EOM_or_anomaly_conclusion'])
    def test_wrong_source_chart_residual(self):self.assertNotEqual(self.q['numeric_negative_controls']['wrong_source_chart_residual'],'0')
    def test_all4_canonical_density(self):self.assertEqual(self.q['canonical_all4_density_words'],128)
    def test_selected_candidate_matches(self):self.assertTrue(self.c['match']);self.assertFalse(self.c['full_actual_minus_candidate'])
    def test_failed_control_preserved(self):self.assertFalse(read(OUT/'controls_failure_disposition_1.json')['counted_as_PASS'])
    def test_no_fitting_higher_loop_or_adoption(self):self.assertFalse(self.c['normalization_coefficients_refitted']);self.assertFalse(self.c['g3_quartet_actual_loop_run']);self.assertFalse(self.c['normalization_adopted']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete'])


if __name__=='__main__':unittest.main()
