"""Exact necessary basicness test; no cochain spaces or differential matrices."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s
from hbc_structural_preflight import HERE, ROOT, load, serialized, seal, inventory, measured

OUT = HERE / 'frozen_hbp_structural_domain'
BLOCKER = 'M08_C5_H_BASIC_SOURCE_CARTAN_SIGN_OBSTRUCTION'
INPUTS = [
    'frozen_c3/C3_representation_basis.json', 'frozen_c4/C4_offshell_differential.json',
    'frozen_c4/C4_equivariant_algebra_certificate.json', 'frozen_c5/C5_alphabet.json',
    'frozen_catalog_cat0_cat4/CAT1_module_actions.json',
    'frozen_catalog_cat0_cat4/CAT4_signature_ledger.json',
    'frozen_jcat_global_packets/JCAT7G_class_census.json',
    'frozen_jcat_packet_catalog/JCAT11_final_counting_ledger.json',
    'frozen_source_seed_s3_s5/S32_graded_source_convention.json',
    'frozen_source_seed_s3_s5/S33_source_couplings.json',
    'frozen_source_seed_s3_s5/Sigma_M08_V1.json',
    'frozen_variational_s5_s8/S52_ST_identity.json',
    'frozen_variational_s5_s8/S63_equivariant_closure.json',
    'frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json',
    'frozen_rh_composite_adjudication/RH_primary_inputs.json',
    'frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json',
    'T5_target_catalog_checkpoint.json', 'frozen_hbc_structural_contract/HBC_primary_preflight.json',
    'HBP_TASK_RECORD.md',
]


def bindings():
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in INPUTS}


def code_bindings():
    names = ['hbp_structural_preflight.py', 'hbp_component_replay.py',
             'execute_hbp_structural_domain.py', 'hbc_structural_preflight.py']
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in names}


def split_geometry():
    """Raw sparse coordinate brackets, not physical-matrix commutators."""
    rep = load('frozen_c3/C3_representation_basis.json')
    pairs = list(combinations(range(10), 2)); lookup = {p: i for i, p in enumerate(pairs)}
    q = s.SparseMatrix(45, 45, {(e['index'], j): s.sympify(e['coefficient'])
        for j, v in enumerate(rep['h_basis'] + rep['heavy_basis']) for e in v['raw_so10_coordinates']})
    inv = s.SparseMatrix(q.inv()); assert q * inv == s.eye(45)
    cols = [[(i, v) for (i, _), v in q[:, j].todok().items()] for j in range(45)]
    def bracket(j, k):
        values = {}
        def term(a, b, v):
            if a != b:
                ix = lookup[tuple(sorted((a, b)))]; values[ix] = values.get(ix, 0) + (v if a < b else -v)
        for i, v in cols[j]:
            a, b = pairs[i]
            for h, w in cols[k]:
                c, d = pairs[h]; z = v * w / s.sqrt(2)
                if b == c: term(a, d, z)
                if b == d: term(a, c, -z)
                if a == c: term(b, d, -z)
                if a == d: term(b, c, z)
        raw = s.SparseMatrix(45, 1, {(i, 0): s.simplify(v) for i, v in values.items() if v})
        result = (inv * raw).applyfunc(s.simplify)
        assert (q * result - raw).applyfunc(s.simplify) == s.zeros(45, 1)
        return result
    light, heavy = [], []
    for a in range(12):
        h = s.MutableSparseMatrix(12, 12, {}); m = s.MutableSparseMatrix(33, 33, {})
        for b in range(45):
            v = bracket(a, b)
            if b < 12:
                assert v[12:, :] == s.zeros(33, 1); h[:, b] = v[:12, :]
            else:
                assert v[:12, :] == s.zeros(12, 1); m[:, b-12] = v[12:, :]
        light.append(s.ImmutableSparseMatrix(h)); heavy.append(s.ImmutableSparseMatrix(m))
    words = list(combinations(range(33), 2)); idx = {w: i for i, w in enumerate(words)}
    curvature = s.MutableSparseMatrix(12, len(words), {})
    for j, (a, b) in enumerate(words): curvature[:, j] = -bracket(a+12, b+12)[:12, :]
    curvature = s.ImmutableSparseMatrix(curvature)
    # R=-1/2 P[u,u]; exterior coefficients are -[e_j,e_k]_H.
    for a in range(12):
        mat = -heavy[a]; wedge = {}
        for col, (j, k) in enumerate(words):
            for h in range(33):
                for p, v in (((h, k), mat[h, j]), ((j, h), mat[h, k])):
                    if v and p[0] != p[1]:
                        row = idx[tuple(sorted(p))]; key = (row, col)
                        wedge[key] = wedge.get(key, 0) + (v if p[0] < p[1] else -v)
        W = s.ImmutableSparseMatrix(len(words), len(words), wedge)
        assert (-light[a] * curvature - curvature * W).applyfunc(s.simplify) == s.zeros(12, len(words))
    return light, heavy, curvature, words


def monomials(node):
    """Distribute only finite AST sums, retaining ordered factor signs."""
    kind = node.get('node')
    if kind == 'Add': return [w for t in node['terms'] for w in monomials(t)]
    if kind == 'OrderedProduct':
        result = [[]]
        for t in node['factors']: result = [a+b for a in result for b in monomials(t)]
        return result
    if kind in ('GroupContraction', 'LorentzContraction'): return monomials(node['expression'])
    return [[node]]


def source_coefficients(images):
    terms = [w for w in monomials(images['L_c']['B_Sigma_image'])
        if sorted(n.get('name') for n in w if n['node'] in ('Field', 'ExternalSource')) == ['L_c', 'c_L']]
    assert len(terms) == 2
    coeff = {}
    for w in terms:
        f = next(n for n in w if n['node'] == 'StructureConstant')
        d = next(n for n in w if n['node'] == 'KroneckerMetric')
        c = next(n for n in w if n.get('name') == 'c_L')
        L = next(n for n in w if n.get('name') == 'L_c')
        assert f['indices'][0] == L['indices'][0] and d['indices'][1] == 'alpha'
        z = s.prod(s.sympify(n['value']) for n in w if n['node'] == 'ExactScalar')
        if d['indices'][0] == f['indices'][1] and c['indices'][0] == f['indices'][2]: coeff['first'] = z
        elif d['indices'][0] == f['indices'][2] and c['indices'][0] == f['indices'][1]: coeff['second'] = z
        else: raise AssertionError('UNQUALIFIED_SOURCE_INDEX_PATTERN')
    r = images['R_H']['B_Sigma_image']['factors']
    assert [n.get('name') for n in r[1:]] == ['g10', 'f', 'c_L', 'R_H']
    return coeff, s.sympify(r[0]['value'])


def build_primary():
    with measured('HBP_inventory_and_AST_extraction', 'input_parse_and_symbolic_normalization'):
        roles = inventory()
        images = {v['identity']: v for v in load('frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json')['images']}
        coeff, r_sign = source_coefficients(images)
        assert images['Abar_H_mu']['B_Sigma_image']['value'] == '0'
        assert all(not v['grade_only_candidate_words'] for v in roles if v['source_couples_to'])
    with measured('HBP_geometry_and_R_covariance', 'exact_linear_algebra_and_tensor_identity'):
        f, heavy, R, words = split_geometry()
    # The contragredient evaluation lift is +ad^T when L_R=-ad R.
    # Right source image has the OPPOSITE contraction; no sign is fitted.
    source_sign = coeff['second'] - coeff['first']
    combined_sign = source_sign + r_sign
    checks = []
    for a in range(12):
        source_L = f[a].T; R_L = -f[a]
        assert source_L.T + R_L == s.zeros(12)
        checks.append({'alpha': a, 'F_L_residual': 'ZERO', 'F_iota_residual': 'ZERO',
            'source_Cartan_defect_nonzero': source_sign*f[a].T != source_L})
    assert source_sign == -1 and r_sign == -1 and combined_sign == -2
    col = next(j for j in range(R.cols) if s.simplify((combined_sign*f[0]*R[:, j])[4]) != 0)
    word = words[col]; rv = R[:, col]
    source_value = s.simplify((source_sign*f[0]*rv)[4])
    composite_value = s.simplify((r_sign*f[0]*rv)[4])
    component = {'alpha': 0, 'source_component': 4, 'heavy_ghost_word': list(word),
        'R_word_vector': [str(v) for v in rv], 'source_contribution_over_g10': str(source_value),
        'composite_contribution_over_g10': str(composite_value),
        'total_over_g10': str(s.simplify(source_value+composite_value))}
    assert s.sympify(component['total_over_g10']) != 0
    signatures = load('frozen_catalog_cat0_cat4/CAT4_signature_ledger.json')['signatures']
    sig = next(r for r in signatures if r['multiplicities'] == {'L_c': 1, 'u_H': 2})
    assert sig['base_canonical_dimension'] == 4 and sig['ghost_number'] == 0 and sig['maximum_derivative_degree'] == 0
    old = load('frozen_hbc_structural_contract/HBC_primary_preflight.json')
    assert old['preregistered_component']['coefficient_of_g10_Lc4_c4'] == 'sqrt(2)*I/2'
    sigma = load('frozen_source_seed_s3_s5/Sigma_M08_V1.json')['Sigma_M08']
    weight = load('frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json')
    return seal({'status': 'EXACT_BASIC_COCHAIN_PRESERVATION_COUNTEREXAMPLE',
        'source_commit': '91bf039', 'input_byte_sha256': bindings(), 'code_byte_sha256': code_bindings(),
        'ambient_basic': {'Sigma_in': 'A_full', 'Sigma_basic_required': False,
            'basicness': 'intersection ker L_alpha and ker iota_alpha', 'semantics': 'SUBSPACE_NOT_QUOTIENT'},
        'role_inventory': roles, 'complete_17_role_table_qualified': False,
        'candidate': {'iota_degree': [-1, -1], 'iota_c': 'delta', 'iota_u': '0 from H projection of full Weil ghost',
            'iota_Lc': '0 by empty grade envelope', 'iota_R': '0 by derivation of u*u',
            'L_R': '-ad(t_alpha) R', 'L_Lc': '+ad(t_alpha)^T Lc in evaluation dual',
            'background_distinction': 'B_Abar=0; normalized Cartan contraction gives L_q=-ad(t_alpha)(Abar+q), distinct from homogeneous background-Ward action'},
        'F': {'expression': 'integral L_c,a R_H^a = -1/2 integral L_c,a P_H[u,u]^a',
            'd': 4, 'gh': 0, 'w': 4, 'parity': 'PARITY_EVEN', 'signature': sig,
            'pairing': 'source evaluation on primal R, not an assumed Euclidean metric',
            'H_invariance_checks': checks, 'R_intertwiner_checks': 12,
            'statistics': 'antisymmetric internal heavy pair with Grassmann sign; one source occurrence',
            'IBP': 'zero derivative at full dimension 4; no explicit coordinates, inverse derivatives or EOM',
            'background': 'homogeneous H-invariant singleton, no connection'},
        'current_source_AST_coefficients': {k: str(v) for k,v in coeff.items()},
        'iota_BLc_over_g': '-ad(t_alpha)^T Lc', 'iota_BR_over_g': '-ad(t_alpha) R',
        'iota_BF': '-2*g10*L_c,a*f^a_alpha_b*R_H^b',
        'component': component,
        'negative_controls': {'hypothetical_opposite_source_sign_would_cancel': str(-source_sign+r_sign),
            'historical_Sigma_witness': old['preregistered_component'],
            'Sigma_status': 'SIGMA_NONHORIZONTAL_NEGATIVE_CONTROL'},
        'Sigma_canonical_sha256': sigma['canonical_action_sha256'],
        'historical_ST_status': load('frozen_variational_s5_s8/S52_ST_identity.json')['final_exact_status'],
        'ST_recomputed': False, 'formal_authority': weight['formal_authority'], 'pole_payload_read': False})


def adjudicate(primary, replay):
    assert primary['component'] == replay['component']
    assert primary['negative_controls']['historical_Sigma_witness'] == replay['historical_Sigma_witness']
    assert primary['Sigma_canonical_sha256'] == replay['Sigma_canonical_sha256']
    return seal({'status': 'BLOCKED_HBP_BASIC_COCHAIN_PRESERVATION',
        'current_blocker': 'M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING', 'localized_blocker': BLOCKER,
        'primary_sha256': primary['artifact_sha256'], 'replay_sha256': replay['artifact_sha256'],
        'primary_replay_agreement': 'EXACT', 'first_failed_gate': 'HBP5 source Cartan compatibility; HBP6 has an explicit basic-cochain counterexample',
        'failed_equation': 'iota_alpha B_Sigma(F)=0 for basic F=integral L_c R_H',
        'component': primary['component'], 'contract_promoted': False, 'HB1_authorized': False,
        'ambient_Sigma_revision': 'ADOPTED; Sigma horizontality is NOT an acceptance condition',
        'stages': {'HBP0': 'PASS_AMBIENT_BASIC_SEMANTICS', 'HBP1': 'PASS_NONHORIZONTAL_NEGATIVE_CONTROL',
            'HBP2_HBP4': 'NECESSARY_SOURCE_COMPOSITE_LIFTS_ONLY_NOT_COMPLETE_TABLES',
            'HBP5': 'FAIL_OPPOSITE_SOURCE_CARTAN_SIGN', 'HBP6': 'REFUTED_FOR_MINIMAL_FROZEN_LIFT',
            'HBP7_HBP9': 'NOT_REACHED_FAIL_FAST', 'HBP8': 'HISTORICAL_ST_CUSTODY_ONLY_NOT_REEVALUATED',
            'HBP10': 'PASS_INDEPENDENT_BOUNDED_COUNTEREXAMPLE_REPLAY'},
        'formal_authority': primary['formal_authority'], 'H_basic_dimensions': None,
        'independence': {'ALGORITHM_INDEPENDENT': True, 'CODE_PATH_INDEPENDENT': True,
            'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
            'limits': 'Primary current-source-image AST and raw coordinate brackets versus action right odd derivative/odd shift and physical matrix brackets. Shared frozen basis/action, Python, SymPy.'},
        'scope': 'Minimal graded polynomial contraction with frozen Weil splitting and evaluation-dual H action. Not nonexistence of every possible transported or enlarged calculus.',
        'required_disposition': 'A separately authorized source-calculus/structure-preserving transport investigation may now be considered; do not change frozen Sigma or images in this run.',
        'not_executed': ['HB1_HB10', 'complete_17_role_table', 'global_quotient_descent', 'ST_reevaluation',
            'H_basic_dimensions', 'differential_columns_matrices_ranks', 'EOM', 'H0', 'Cplus2', 'H1', 'C6', 'D6', 'E',
            'M08_attempt2', 'M09_M13', 'Layer6', 'C1_GS', 'Kalkman_source_transport', 'GPU'], 'pole_payload_read': False})
