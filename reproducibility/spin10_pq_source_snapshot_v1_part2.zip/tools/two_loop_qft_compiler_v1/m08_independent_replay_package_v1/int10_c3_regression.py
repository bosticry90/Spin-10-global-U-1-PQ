"""Exact typed C3 comparison. The first slot is a source dual, not a primal."""
from functools import lru_cache
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from int8_block_conjugation_v2 import BlockConjugation, dual_label, address_key
from int9_scalar_swap import clean, payload, dimension, pivot_solve


def c3_matrices(data, third):
    return [sp.SparseMatrix(33, 33*third,
            {(r['indices'][0], r['indices'][1]*third+r['indices'][2]): sp.sympify(r['coefficient'])
             for r in b['nonzero_entries']}) for b in data['basis']]


class C3Comparison:
    def __init__(self):
        self.cat = BlockConjugation()
        roles = br.load(br.HERE/'frozen_intertwiner_basis_int4r_int15/INT7_exact_physical_role_adapters.json')
        self.a = {f: {r['component_id']: br.matrix(r['matrix']) for r in roles['component_adapters'][f]}
                  for f in ('H', 'A')}
        self.p = {}
        for f in ('H', 'A'):
            stacked = sp.Matrix.vstack(*(self.a[f][r['component_id']] for r in self.cat.components[f]))
            inverse = stacked.inv(); offset = 0
            for r in self.cat.components[f]:
                d = dimension(r)
                self.p[r['component_id']] = inverse[:, offset:offset+d]; offset += d
            assert clean(inverse*stacked) == sp.eye(inverse.rows)

    def source_maps(self, cid):
        r = self.cat.by_id[cid]
        partner = next(x for x in self.cat.components['H']
                       if tuple(x['H_label']) == dual_label(tuple(r['H_label'])))
        pcid = partner['component_id']; j = self.cat.duals.pairing(tuple(partner['H_label'])).T
        # alpha_registry = P_primal.T alpha_physical = J_primal.T z_dual.
        a = j.inv()*self.p[pcid].T
        p = self.a['H'][pcid].T*j
        assert clean(a*p) == sp.eye(a.rows)
        return a, p

    def addresses(self, family):
        desc = self.cat.descriptors[family]
        return [a for key, _, _, _ in self.cat.blocks(desc) for a in self.cat.addresses(family, key)]

    @lru_cache(None)
    def slot_maps(self, cid0, cid1, cid2):
        a0, p0 = self.source_maps(cid0)
        a1, p1 = self.a['H'][cid1], self.p[cid1]
        r = self.cat.by_id[cid2]; f = r['family']
        a2, p2 = self.a[f][cid2], self.p[cid2]
        return tuple(sp.SparseMatrix(a) for a in (a0, a1, a2)), tuple(sp.SparseMatrix(p) for p in (p0, p1, p2))

    def local_channel(self, address):
        _, _, slots, copies, b, _, ch, _ = self.cat.address_parts(address)
        assert copies == [0, 0, 0]
        c, d = self.cat.duals.channel_objects(tuple(b['left_H_label']), tuple(b['right_H_label']),
                                             tuple(b['output_H_label']), ch)
        j = self.cat.duals.pairing(tuple(b['output_H_label'])).T
        return slots, c, d, j

    def primary(self, family, data, third):
        addresses = self.addresses(family)
        assert len(addresses) == len(data['basis']) == (49 if third == 33 else 19)
        fs = c3_matrices(data, third)
        # View the immutable intertwiner as a covector with pair (ubar,u).
        pair_fs = [sp.SparseMatrix(33*33, third,
                    {(i*33+k//third, k % third): v for (i, k), v in f.todok().items()}) for f in fs]
        coefficients = sp.zeros(len(addresses), len(fs)); certificates = []
        for ai, address in enumerate(addresses):
            slots, c, d, j = self.local_channel(address)
            _, ps = self.slot_maps(*slots)
            pair = sp.kronecker_product(ps[0], ps[1])*c
            pi, pj = sorted(j.todok())[0]
            for fi, f in enumerate(pair_fs):
                target = clean(pair.T*f*ps[2])
                scalar = sp.simplify(target[pi, pj]/j[pi, pj])
                residual = clean(target-scalar*j)
                if residual != sp.zeros(*j.shape):
                    raise RuntimeError('C3_TERMINAL_NONINVARIANT '+str((data['basis'][fi]['basis_id'], address, payload(residual))))
                coefficients[ai, fi] = scalar
            certificates.append({'address': address, 'ordered_slot_components': slots,
                                 'source_slot_type': 'REG7 dual carrier of physical primal heavy output',
                                 'projection_embedding_biorthogonality': 'ZERO_EXACT',
                                 'terminal_full_tensor_residual': 'ZERO_EXACT'})
        assert coefficients.rank() == len(addresses)
        return addresses, clean(coefficients), certificates

    def physical_channels(self, addresses, third):
        result = []
        for address in addresses:
            slots, _, d, j = self.local_channel(address)
            amap, _ = self.slot_maps(*slots)
            pair = clean(sp.kronecker_product(amap[0], amap[1]).T*d.T*j*amap[2])
            result.append(sp.SparseMatrix(33, 33*third,
                          {(i//33, (i % 33)*third+k): v for (i, k), v in pair.todok().items()}))
        return result

    def replay(self, addresses, data, third):
        fs = self.physical_channels(addresses, third)
        targets = c3_matrices(data, third)
        forward, pos, m, rhs = pivot_solve(fs, targets)
        reverse, rpos, rm, rrhs = pivot_solve(targets, fs)
        assert clean(forward*reverse) == sp.eye(len(fs))
        assert clean(reverse*forward) == sp.eye(len(fs))
        return {'C3_to_channels': payload(forward), 'channels_to_C3': payload(reverse),
                'pivot_entries': pos, 'basis_value_matrix': payload(m), 'C3_values': payload(rhs),
                'reverse_pivot_entries': rpos, 'reverse_basis_matrix': payload(rm),
                'reverse_channel_values': payload(rrhs), 'rank': len(fs),
                'full_component_mutual_span_residual': 'ZERO_EXACT', 'primary_coefficients_imported': False,
                'independence': {'ALGORITHM_INDEPENDENT': True, 'CODE_PATH_INDEPENDENT': True,
                    'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
                    'shared_inputs': 'C3 tensors, INT3/REG7/D, certified physical role columns'},
                'source_slot': 'Explicit contragredient via REG7, not Euclidean primal identification'}

    def covariance(self, addresses, third):
        # Independent direct parent Lie brackets define the physical actions.
        from execute_c3_invariant_basis import generators, coordinate_matrix, bracket_coordinates
        rep = br.load(br.HERE/'frozen_c3/C3_representation_basis.json')
        raw = generators(); pairs = [n for n, _ in raw]
        def columns(key):
            return sp.SparseMatrix(45, len(rep[key]),
                {(r['index'], j): sp.sympify(r['coefficient'])
                 for j, col in enumerate(rep[key]) for r in col['raw_so10_coordinates']})
        ph = columns('heavy_basis'); pa = columns('h_basis')
        inverse = pa.row_join(ph).inv()
        hm = [coordinate_matrix(pa[:, i], raw) for i in range(12)]
        heavy = [coordinate_matrix(ph[:, i], raw) for i in range(33)]
        adjoint = [coordinate_matrix(pa[:, i], raw) for i in range(12)]
        hs, ats = [], []
        for g in hm:
            hi = inverse*sp.Matrix.hstack(*(bracket_coordinates(g, x, pairs) for x in heavy))
            ai = inverse*sp.Matrix.hstack(*(bracket_coordinates(g, x, pairs) for x in adjoint))
            assert hi[:12, :] == sp.zeros(12, 33) and ai[12:, :] == sp.zeros(33, 12)
            hs.append(sp.SparseMatrix(hi[12:, :])); ats.append(sp.SparseMatrix(ai[:12, :]))
        fs = self.physical_channels(addresses, third)
        input_actions = [sp.kronecker_product(g, sp.SparseMatrix(sp.eye(third)))
                         +sp.kronecker_product(sp.SparseMatrix(sp.eye(33)), t)
                         for g, t in zip(hs, hs if third == 33 else ats)]
        for i, f in enumerate(fs):
            for g, input_action in zip(hs, input_actions):
                residual = clean(g*f-f*input_action)
                assert residual == sp.zeros(33, 33*third), ('C3 physical H', i)
        return {'generator_count': 12, 'channel_count': len(fs), 'covariance_residual': 'ZERO_EXACT',
                'method': 'Physical parent SO(10) Lie brackets on frozen C3 columns; source -T^T',
                'historical_C3_superseded': False}

    def conjugation(self, addresses, third):
        """Transport INT8 through the certified source/primal dictionary."""
        x = BlockConjugation.from_frozen()
        rep = br.load(br.HERE/'frozen_c3/C3_representation_basis.json')
        def physical_k(key):
            raw = sp.SparseMatrix(45, len(rep[key]),
                {(r['index'], j): sp.sympify(r['coefficient'])
                 for j, col in enumerate(rep[key]) for r in col['raw_so10_coordinates']})
            rc = sp.conjugate(raw)
            k = clean((rc.H*rc).inv()*rc.H*raw)
            assert clean(rc*k-raw) == sp.zeros(*raw.shape)
            assert clean(k*sp.conjugate(k)) == sp.eye(k.rows)
            return k
        kh = physical_k('heavy_basis'); ka = physical_k('h_basis')
        kd = clean(kh.T.inv())
        source_scales = {}; rows = []
        for r in x.components['H']:
            cid = r['component_id']; target = x.partner[cid]; label = tuple(r['H_label'])
            a, _ = self.source_maps(cid); at, _ = self.source_maps(target)
            actual = clean(sp.conjugate(a)*kd)
            expected = clean(x.k(label)*at)
            i, j = sorted(expected.todok())[0]
            w = sp.simplify(actual[i, j]/expected[i, j])
            assert clean(actual-w*expected) == sp.zeros(*actual.shape)
            source_scales[cid] = w
            rows.append({'source_component': cid, 'target_component': target,
                         'source_copy_factor': str(w), 'primal_copy_factor': str(x.w[cid][0, 0]),
                         'REG7_source_primal_transport_residual': 'ZERO_EXACT'})
        indices = {address_key(a): i for i, a in enumerate(addresses)}
        b = sp.MutableSparseMatrix(len(addresses), len(addresses), {})
        for i, a in enumerate(addresses):
            slots = x.address_parts(a)[2]; cid = slots[0]
            scale = source_scales[cid]/x.w[cid][0, 0]
            for target, v in x.image(a):
                b[indices[address_key(target)], i] = sp.simplify(scale*v)
        b = clean(b)
        assert clean(b*sp.conjugate(b)) == sp.eye(b.rows)
        fs = self.physical_channels(addresses, third)
        pair = sp.kronecker_product(kd, kh)
        for i, f in enumerate(fs):
            fp = sp.SparseMatrix(33*33, third,
                {(j*33+k//third, k % third): v for (j, k), v in f.todok().items()})
            transformed_pair = clean(pair.T*sp.conjugate(fp)*(kh if third == 33 else ka))
            transformed = sp.SparseMatrix(33, 33*third,
                {(j//33, (j % 33)*third+k): v for (j, k), v in transformed_pair.todok().items()})
            rebuilt = sum((b[j, i]*fj for j, fj in enumerate(fs) if b[j, i]), sp.zeros(33, 33*third))
            assert clean(rebuilt-transformed) == sp.zeros(33, 33*third), ('source conjugation', i)
        return {'INT8_authority': 'M08_INT8_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2',
                'source_primal_transport': rows, 'coefficient_conjugation_matrix': payload(b),
                'physical_primal_K': payload(kh), 'physical_dual_K': payload(kd),
                'physical_third_K': payload(kh if third == 33 else ka),
                'full_tensor_conjugation_residual': 'ZERO_EXACT', 'involution_residual': 'ZERO_EXACT',
                'canonical_INT8_maps_changed': False, 'canonical_basis_rotated': False}
