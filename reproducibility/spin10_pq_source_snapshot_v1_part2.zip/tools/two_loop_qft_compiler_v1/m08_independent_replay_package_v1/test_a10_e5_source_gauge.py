"""Source/Hessian, tensor, carrier and sign regression obligations."""
import unittest
from audit_a10_e5_source_gauge import *
from a10_e5_source_gauge_control import even_word_product,R,pa


class SourceGaugeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.u,cls.c,cls.q=evidence()
    def test_all1286_Q_columns_screened(self):self.assertEqual(self.a['universal_image']['all1286_Q_columns_screened'],1286)
    def test_unique_carrier_type(self):self.assertEqual(self.a['universal_image']['only_derivative_carrier_type'],[['B','JL']])
    def test_signed2025_image_and_no_projected_kernel(self):self.assertEqual(len(self.a['universal_image']['all2025_signed_image_columns']),2025);self.assertEqual(self.a['universal_image']['kernel_in_this_IBP_quotient'],0)
    def test_source_free_projection_excluded(self):self.assertFalse(self.a['universal_image']['source_free_carrier_can_supply_Ja'])
    def test_both_generator_derivative_placements_current(self):self.assertTrue(self.a['universal_image']['full_unit_IBP_current']);self.assertTrue(self.a['universal_image']['wrong_generator_sign_residual'])
    def test_full_real_ghost_reference(self):self.assertTrue(self.q['free_ghost_reference']['all45_H_and_M_leading_ghost_pairs_unit'])
    def test_source_linear_Hessians_zero(self):self.assertEqual(self.a['source_inventory']['linear_terms'],45);self.assertTrue(self.a['source_inventory']['all45_linear_sources_zero_integrated_Hessian'])
    def test_complete_source_vertices(self):self.assertEqual(self.a['source_inventory']['nonlinear_raw_source_terms'],180);self.assertTrue(self.a['source_inventory']['nonlinear_only_source_M_anti_M_ghost_H'])
    def test_two_even_externals_commute(self):self.assertEqual(even_word_product({(1,):R.one},{(0,):R.one}),{(0,1):R.one})
    def test_even_external_product_excludes_duplicate_legs(self):self.assertEqual(even_word_product({(0,):R.one},{(0,):R.one}),{})
    def test_all4_unit_axes(self):self.assertTrue(all(v==[0,1,2,3] for v in self.u['all4_axes'].values()))
    def test_full_GF_unit_IBP(self):self.assertEqual(sum(int(v) for v in self.u['unit_derivative_residues'].values()),0)
    def test_complete2025_coefficient_domain(self):self.assertEqual(self.q['complete_coefficients_compared'],2025)
    def test_Casimir_rank32_with_H_zero_channels(self):self.assertEqual(self.q['heavy_Casimir_rank'],32);self.assertEqual(self.q['physical_nonzero_coefficients'],56)
    def test_all12_homogeneous_H(self):self.assertEqual(self.a['all12_homogeneous_H_identities'],list(range(12)));self.assertFalse(self.a['full_local_jet_Ward_or_quantum_A5'])
    def test_widths_not_specialized(self):self.assertTrue(self.a['width_and_xi_independent_by_complete_ghost_edge_screening'])
    def test_full_actual_source_IBP_current(self):self.assertTrue(self.a['full_actual_IBP_currents_all4']);self.assertTrue(self.a['physical_source_derivative_alternative'])
    def test_real_source_Euler_excludes_boundary(self):self.assertEqual(self.c['real_source_Euler_witness']['selected_coefficient'],'-8/5');self.assertFalse(self.c['real_source_Euler_witness']['pure_total_derivative'])
    def test_wrong_source_map_and_generator_sign_controls(self):self.assertNotEqual(self.q['numeric_negative_controls']['wrong_dual_source_chart_residual'],'0');self.assertEqual(self.q['numeric_negative_controls']['wrong_generator_sign_actual_source_residual'],'-16/5')
    def test_missing_H_ghost_edge_control(self):self.assertEqual(self.q['numeric_negative_controls']['omit_H_ghost_pair_actual_residual'],'-8/5')
    def test_candidate_source_gate_stopped(self):self.assertFalse(self.c['candidate_match']);self.assertTrue(self.c['first_failure_stopped']);self.assertFalse(self.c['lower_candidate_residual'])
    def test_coefficients_derived_before_derivative_residual(self):self.assertFalse(self.c['old_derivative_residual_read_or_fitted']);self.assertTrue(self.c['necessary_projection_sign_identity_all2025'])
    def test_no_full_generator_or_adoption(self):self.assertFalse(self.c['full_generator_or_Q_image_constructed']);self.assertFalse(self.c['normalization_adopted']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete'])
    def test_failed_even_parity_attempt_preserved(self):self.assertFalse(read(OUT/'controls_failure_disposition_1.json')['counted_as_PASS'])
    def test_UV_only(self):self.assertEqual(self.u['UV_domain'],'k_E^2>R_UV^2>0');self.assertEqual(self.u['bubble_heat_profile'],4);self.assertFalse(self.u['finite_IR_or_whole_scaleless_calculated'])


if __name__=='__main__':unittest.main()
