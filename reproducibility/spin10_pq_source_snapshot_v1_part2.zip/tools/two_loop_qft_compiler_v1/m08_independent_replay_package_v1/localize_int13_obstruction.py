"""Bounded pole-blind diagnosis; no correction of a promoted B_Sigma law."""
from hashlib import sha256
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from execute_int9_int15 import OUT, freeze
from execute_int13_readiness import PromotedBSigma
from execute_int12_structures import inventory
from int12_structure_embedding import TreeIndexLowering, expanded_terms, expand_backgrounds
from m08_local_functional_ast import mul
from execute_scalar_adapter_v2 import physical_generators
from int9_scalar_swap import payload


BLOCKER='M08_INT13_R_H_LIGHT_GHOST_ACTION_COMPOSITE_CONVENTION_MISMATCH'


def replay_obstruction():
    lowerer=TreeIndexLowering()
    coverage=br.load(OUT/'INT13_coverage_closed.json')
    item=next(r for r in coverage['inputs'] if r['sector']=='QUARTIC_GHOST')
    original={'structure_id':'QUARTIC_GHOST_WARD_PROBE','sector':'QUARTIC_GHOST',
        'ordered_factors':next(expanded_terms(item['input'])),
        'source_AST_hash':br.canonical(item['input'])}
    frozen_image=br.load(OUT/'INT13_QUARTIC_GHOST_literal_image.json')
    assert PromotedBSigma(item['input']).apply(item['input'])==frozen_image['image']
    # This is a diagnostic consequence of the already-frozen composite
    # definition, not a replacement of the promoted R_H image.
    expanded_input=mul(*expand_backgrounds(original)['ordered_factors'])
    composite_image=PromotedBSigma(expanded_input).apply(expanded_input)
    source_row=next(r for r in inventory()
        if mul(*r['ordered_factors'])==item['input'])
    frozen_targets=br.load(OUT/'INT12R_tree_targets_closed.json')['targets'][source_row['structure_id']]
    targets=[r for r in frozen_targets if r['seed'] in (7,19,31)]
    _,fields,_,_,_,_=lowerer.prepared(original)
    raw=[m for _,m in lowerer.geometry.raw]
    transports=[]
    for g in physical_generators():
        action=sp.SparseMatrix(45,45,{(i,j):sp.trace(b.T*(g*c-c*g))/2
            for i,b in enumerate(raw) for j,c in enumerate(raw) if sp.trace(b.T*(g*c-c*g))!=0})
        cv=sp.SparseMatrix(45,1,{(i,0):sp.sqrt(2)*sp.trace(b.T*g)/2
            for i,b in enumerate(raw) if sp.trace(b.T*g)!=0})
        transports.append((action,cv))

    def light_ghost_terms(image,vectors,cv):
        values=[]
        for i,factors in enumerate(expanded_terms(image)):
            row={'structure_id':'DIAGNOSTIC_LIGHT_GHOST::'+str(i),'ordered_factors':factors}
            expanded=expand_backgrounds(row)
            live=[f for f in expanded['ordered_factors'] if f['node'] in ('Field','ExternalSource','FrozenBackground')]
            if len(live)!=5 or sum(f['name']=='c_L' for f in live)!=1:continue
            pos=next(i for i,f in enumerate(live) if f['name']=='c_L')
            assert [f['name'] for f in live if f['name']!='c_L']==[f['name'] for f in fields]
            sign=(-1)**sum(f.get('parity',0) for f in live[:pos])
            vv=list(vectors);vv.insert(pos,cv)
            value=sp.simplify(sign*lowerer.direct_physical_value(row,vv))
            values.append({'literal_term':i,'c_occurrence_position':pos,'graded_transport_sign':sign,
                'ordered_role_word':[f['name'] for f in live],'value':str(value)})
        return values

    controls=[]; first=None
    for target in targets:
        vectors=[br.matrix(v) for v in target['vectors']]
        for gi,(action,cv) in enumerate(transports):
            ward=[]
            for slot in range(4):
                vv=list(vectors);vv[slot]=action*vv[slot]
                ward.append(lowerer.direct_physical_value(original,vv))
            assert sp.simplify(sum(ward))==0
            promoted=light_ghost_terms(frozen_image['image'],vectors,cv)
            derived=light_ghost_terms(composite_image,vectors,cv)
            assert len(promoted)==3 and len(derived)==4
            promoted_sum=sp.simplify(sum(sp.sympify(r['value']) for r in promoted))
            derived_sum=sp.simplify(sum(sp.sympify(r['value']) for r in derived))
            assert derived_sum==0,(gi,target['seed'],derived)
            controls.append({'seed':target['seed'],'H_generator':gi,
                'ordinary_H_Ward_sum':'0','promoted_R_image_sum':str(promoted_sum),
                'R_definition_then_promoted_u_image_sum':str(derived_sum)})
            if first is None and promoted_sum!=0:
                first={'seed':target['seed'],'H_generator':gi,'four_original_vectors':target['vectors'],
                    'light_ghost_vector':payload(cv),'ordinary_H_slot_variations':[str(v) for v in ward],
                    'promoted_R_image_terms':promoted,'composite_R_then_u_image_terms':derived,
                    'promoted_exact_residual':str(promoted_sum),'composite_exact_residual':str(derived_sum)}
    assert first is not None and first['seed']==7 and first['H_generator']==4
    assert sp.sympify(first['promoted_exact_residual'])==-sp.Rational(411,4)
    return {'status':'BLOCKED_EXACT_PROMOTED_R_H_VS_COMPOSITE_LIGHT_GHOST_REPLAY',
        'blocker':BLOCKER,'input':item['input'],'R_composite_definition':'R_alpha=-f_alpha_ij u_i u_j/2, original ordered slots',
        'S6_B_Sigma_authority_sha256':frozen_image['B_Sigma_authority_sha256'],
        'original_INT12_frozen_witness_structure':source_row['structure_id'],
        'witnesses_selected_from_channel_output':False,'first_counterexample':first,'controls':controls,
        'localization':'Within the current Tr-normalized physical f dictionary, the promoted R_H light-ghost image does not equal the image induced by its frozen u_H composite definition. The ordinary H Ward sum and the composite-first replay vanish.',
        'unclosed_role_multiset':['A','H','H','H','H'],
        'current_internal_family_degree_bound':4,'five_occurrence_family_materialized':False,
        'graded_transport':'Only the new distinguished c moves to the front; original four occurrence slots stay fixed.',
        'upstream_law_or_pairing_modified':False,'proposed_sign_change_authority':'NONE_DIAGNOSTIC_ONLY',
        'independence':'R-law application versus composite-first application of the frozen u/bar laws; same physical f, ordered frontend and Python/SymPy runtime; no channel coefficients imported.',
        'INT14_INT15':'NOT_EXECUTED','formal_scientific_authority':'UNCHANGED_34_OF_39'}


def main():
    assert hasattr(__import__('sitecustomize'),'DENIED')
    cp=br.load(OUT/'INT9_INT15_checkpoint.json')
    assert cp['status']=='BLOCKED' and cp['failed']['gate']=='INT13'
    assert cp['failed']['coverage_sector']=='QUARTIC_GHOST'
    result=replay_obstruction()
    name='INT13_quartic_ghost_covariance_obstruction.json'
    digest=freeze(name,result)
    original=br.load(OUT/'INT13_obstruction.json')
    cp.pop('artifact_sha256');cp['artifacts'][name]=digest
    cp['failed']=dict(original,original_obstruction_artifact_sha256=original['artifact_sha256'])
    cp['failed'].pop('artifact_sha256')
    cp['failed']['blocker']=BLOCKER
    cp['failed']['exact_residual']='-411/4'
    cp['current_blocker']=BLOCKER
    freeze('INT9_INT15_checkpoint.json',cp)
    print('INT13_LOCALIZED_R_H_COMPOSITE_ACTION_MISMATCH_RESIDUAL_MINUS_411_OVER_4_STOP',flush=True)


if __name__=='__main__':main()
