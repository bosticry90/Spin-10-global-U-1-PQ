"""Adversarial E1 operation and scope tests, including all variational columns."""
from copy import deepcopy
from hashlib import sha256
import unittest
from a10_e1_fermion_common import *
from audit_a10_e1_fermion import adjudicate

class E1FermionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
        cls.c=read(OUT/'checks.json')
    def test_all_eight_terms_exact_coefficient_translation(self):
        self.assertEqual(self.p['polynomial_parts'],self.r['polynomial_parts'])
        self.assertEqual(adjudicate(self.p,self.r)['term_coefficients_compared'],1797)
        self.assertEqual(read(OUT/(NAME+'.json')),candidate(self.p))
    def test_all_643_and_48_Euler_columns_exact(self):
        self.assertEqual(self.p['Euler_columns'],self.r['Euler_columns'])
        self.assertEqual(len(self.p['Euler_columns']),691)
        self.assertEqual(adjudicate(self.p,self.r)['Euler_coefficients_compared'],4668)
    def test_induced_metrics_and_canonical_pairings_are_separate(self):
        c=self.p['charts']['blocks']['heavy_dual']
        self.assertNotEqual(mat(c['invariant_bilinear']),s.eye(33))
        self.assertEqual(mat(c['canonical_pairing']),s.eye(33))
        self.assertTrue(self.c['canonical_pairing_not_invariant_dual_bilinear'])
    def test_every_primal_dual_section_and_source_pairing(self):
        for c in self.p['charts']['blocks'].values():
            F,L,J=[mat(c[k]) for k in ('field_embedding','left_section','source_embedding')]
            self.assertEqual((L*F).applyfunc(clean),s.eye(F.cols))
            self.assertEqual((J.T*F).applyfunc(clean),s.eye(F.cols))
    def test_ambient_maps_have_projectors_and_kernels(self):
        for c in self.p['charts']['blocks'].values():
            P=mat(c['physical_projector'])
            self.assertEqual((P*P-P).applyfunc(clean),s.zeros(45))
            self.assertFalse(c['ambient_inverse_claimed'])
            self.assertEqual(c['ambient_kernel_dimension'],45-c['field_rank'])
    def test_complete_conjugation_and_all_field_source_real_structures(self):
        self.assertEqual(len(self.c['complete_fermion_real_structure_residuals']),8)
        self.assertTrue(all(not v for v in self.c['complete_fermion_real_structure_residuals'].values()))
        for c in self.p['charts']['blocks'].values():
            C,CS=mat(c['conjugation']),mat(c['source_conjugation'])
            self.assertEqual((CS.T*C).applyfunc(clean),s.eye(C.rows))
    def test_real_parameter_decoding_and_unfitted_alpha(self):
        for P in self.p['polynomial_parts'].values():
            for c in decode_typed(P).values():
                for z in c.free_symbols:
                    if str(z) in ('xi','eta_H'):self.assertTrue(z.is_real)
        self.assertEqual(self.p['charts']['parameters']['alpha'],'xi')
    def test_complete_fermion_and_Euler_Grassmann_grading(self):
        w=alphabet()
        for name,P in self.p['Euler_columns'].items():
            d,gh,par=(w.grades|w.external)[name]
            for word in decode_typed(P):
                self.assertEqual(sum((w.grades|w.external)[n][1] for n,jets in word),-1-gh)
                self.assertEqual(sum(w.p[n] for n,jets in word)%2,1-par)
        self.assertEqual(self.p['geometry']['coefficient_mass_dimensions']['OrbitPullback'],1)
    def test_local_heavy_quantum_and_background_Wards(self):
        for key in ('quantum_heavy_residual','background_heavy_residual'):
            self.assertEqual(self.p['local_Wards'][key],[])
        self.assertIn('first/second',self.p['local_Wards']['parameter_jet_scope'])
    def test_complete_local_background_Ward(self):
        self.assertEqual(self.p['local_Wards']['background_complete_residual'],[])
    def test_light_quantum_breaking_is_exact_nonboundary_control(self):
        c=self.p['local_Wards']['light_quantum_expected_breaking']
        self.assertTrue(c['Euler_bar0'] and c['not_boundary_only'])
        self.assertEqual(c,self.r['local_Wards']['light_quantum_expected_breaking'])
    def test_full_first_variation_and_explicit_boundary(self):
        a=self.p['first_variation'];self.assertEqual(a,self.r['first_variation'])
        self.assertFalse(a['residual'] or a['EOM_used'])
        self.assertTrue(a['arbitrary_graded_variations'])
        self.assertEqual(sum(map(len,a['boundary_current'])),244)
    def test_total_connection_qH_omission_is_detected_locally(self):
        self.assertTrue(self.c['omitted_qH_parameter_jet_residual'])
        self.assertTrue(all(any(n.startswith('omega') and '__' in n for n in r['word'])
          for r in self.c['omitted_qH_parameter_jet_residual']))
    def test_actual_nonsymmetric_cubic_and_changed_coefficient(self):
        self.assertTrue(self.p['polynomial_parts']['heavy_cubic'])
        self.assertTrue(self.c['changed_cubic_coefficient_rejected'])
        r=deepcopy(self.r);r['polynomial_parts']['heavy_cubic'][0]['coefficient']='0'
        with self.assertRaises(AssertionError):adjudicate(self.p,r)
    def test_full_shifted_vacuum_orbit_convention(self):
        self.assertTrue(self.p['geometry']['shifted_vacuum_used'])
        self.assertEqual(self.p['geometry']['H_vacuum_stabilizer_verified'],12)
        self.assertTrue(self.p['geometry']['O_transpose_v_zero'])
    def test_previous_bare_pairing_exact_witness_preserved(self):
        self.assertEqual(self.c['bare_pairing_Ward_coefficients'],264)
        self.assertTrue(self.c['bare_pairing_Euler_L13'])
        self.assertEqual(self.c['real_negative_control']['coefficient'],'sqrt(2)*g10*xi')
    def test_wrong_unprojected_real_plane_input_rejected(self):
        self.assertTrue(self.c['unprojected_input_rejected'])
        self.assertTrue(self.c['real_negative_control']['heavy_projection_verified'])
    def test_historical_inputs_remain_byte_bound_and_unidentified(self):
        for n,h in self.p['recovery']['historical_bytes'].items():
            self.assertEqual(sha256((HERE/n).read_bytes()).hexdigest(),h)
        self.assertFalse(self.p['recovery']['historical_nonminimal_AST_identified'])
        self.assertFalse(self.p['historical_equivalence_proved'])
    def test_false_equivalence_activation_and_later_gate_claims_rejected(self):
        for flag in self.c['false_promotion_flags_rejected']:
            p,r=deepcopy(self.p),deepcopy(self.r);p[flag]=r[flag]=True
            with self.assertRaises(AssertionError):adjudicate(p,r)
    def test_frozen_science_and_solo_policy_scopes(self):
        self.assertEqual(self.p['formal_authority'],'34/39_UNCHANGED')
        self.assertTrue(self.p['inactive'] and self.p['Stage_D_preserved'])
        for n in ('E2_E5_executed','full_fixed_master_constructed','sources_activated',
          'catalog_rebuilt','HB1_C5_run','C1_GS_calculated','external_endorsement','personal_outreach'):
            self.assertFalse(self.p[n])
if __name__=='__main__':unittest.main()
