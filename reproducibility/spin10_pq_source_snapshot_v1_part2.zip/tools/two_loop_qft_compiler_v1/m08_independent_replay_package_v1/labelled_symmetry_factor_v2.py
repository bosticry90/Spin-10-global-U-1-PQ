"""Label-fixed diagram automorphisms for the M08 independent replay.

Inventory canonicalization quotients arbitrary internal vertex names.  A
diagram symmetry factor instead uses the stabilizer of the *same externally
labelled graph*.  These operations are intentionally separate here.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import permutations
from math import factorial
from typing import Any


GHOST_SPECIES = {"H", "Hbar", "L", "Lbar"}


def _edge_key(edge: dict[str, Any], vertex_map: dict[int, int] | None = None) -> tuple:
    vertex_map = vertex_map or {}
    left = (vertex_map.get(int(edge["left"][0]), int(edge["left"][0])), int(edge["left"][1]), edge["left"][2])
    right = (vertex_map.get(int(edge["right"][0]), int(edge["right"][0])), int(edge["right"][1]), edge["right"][2])
    if left[2] in GHOST_SPECIES or right[2] in GHOST_SPECIES:
        antighost = left if left[2].endswith("bar") else right
        ghost = right if antighost is left else left
        return ("DIRECTED_GHOST", antighost, ghost)
    return ("UNDIRECTED_BOSON",) + tuple(sorted((left, right)))


def labelled_node_stabilizer(graph: dict[str, Any]) -> dict[str, Any]:
    count = len(graph["vertex_families"])
    original_families = tuple(graph["vertex_families"])
    original_assignments = tuple(tuple(value) for value in graph["field_assignments"])
    original_external = Counter(
        (int(vertex), int(slot), label)
        for vertex, slot, label in graph["external_attachments"]
    )
    original_edges = Counter(_edge_key(edge) for edge in graph["internal_edges"])
    stabilizing = []
    rejected = []
    for permutation in permutations(range(count)):
        mapping = {old: permutation[old] for old in range(count)}
        mapped_families = [None] * count
        mapped_assignments = [None] * count
        for old, new in mapping.items():
            mapped_families[new] = original_families[old]
            mapped_assignments[new] = original_assignments[old]
        family_pass = tuple(mapped_families) == original_families
        assignment_pass = tuple(mapped_assignments) == original_assignments
        external_pass = Counter(
            (mapping[int(vertex)], int(slot), label)
            for vertex, slot, label in graph["external_attachments"]
        ) == original_external
        edge_pass = Counter(
            _edge_key(edge, mapping) for edge in graph["internal_edges"]
        ) == original_edges
        record = {
            "permutation_old_to_new": list(permutation),
            "vertex_family_pass": family_pass,
            "field_assignment_pass": assignment_pass,
            "external_label_and_slot_pass": external_pass,
            "directed_edge_multiset_pass": edge_pass,
        }
        if all((family_pass, assignment_pass, external_pass, edge_pass)):
            stabilizing.append(record)
        else:
            rejected.append(record)
    return {
        "node_automorphism_order": len(stabilizing),
        "stabilizing_permutations": stabilizing,
        "rejected_permutations": rejected,
        "external_labels_fixed_pointwise": True,
        "canonical_unlabelled_graph_identity_used_as_predicate": False,
    }


def _slot_exchange_allowed(family: str, signature: list[str], left_slot: int, right_slot: int) -> bool:
    if signature[left_slot] != signature[right_slot]:
        return False
    if family == "A.GGG.yang_mills":
        return True
    if family in {"A.HH.VHVH.seagull", "A.HH.qLqL.seagull"}:
        return {left_slot, right_slot} == {2, 3}
    if family == "A.scalar.scalar.vector.vector":
        return {left_slot, right_slot} in ({0, 1}, {2, 3})
    return False


def parallel_edge_certificate(graph: dict[str, Any]) -> dict[str, Any]:
    groups: dict[tuple, list[tuple[int, dict[str, Any]]]] = defaultdict(list)
    for index, edge in enumerate(graph["internal_edges"]):
        vertices = tuple(sorted((int(edge["left"][0]), int(edge["right"][0]))))
        species = "/".join(sorted((edge["left"][2], edge["right"][2])))
        groups[(vertices, species)].append((index, edge))
    records = []
    order = 1
    for (vertices, species), entries in sorted(groups.items()):
        multiplicity = len(entries)
        candidate = factorial(multiplicity)
        if multiplicity == 1:
            accepted = 1
            reason = "SINGLE_EDGE"
        elif any(
            endpoint[2] in GHOST_SPECIES
            for _index, edge in entries
            for endpoint in (edge["left"], edge["right"])
        ):
            accepted = 1
            reason = "DIRECTED_GRASSMANN_ENDPOINTS_AND_ORDERED_VERTEX_LEGS_FORBID_EDGE_EXCHANGE"
        else:
            first, second = entries[0][1], entries[1][1]
            endpoint_checks = []
            for vertex in vertices:
                slots = []
                for edge in (first, second):
                    endpoint = edge["left"] if int(edge["left"][0]) == vertex else edge["right"]
                    slots.append(int(endpoint[1]))
                endpoint_checks.append(
                    _slot_exchange_allowed(
                        graph["vertex_families"][vertex],
                        graph["field_assignments"][vertex],
                        slots[0],
                        slots[1],
                    )
                )
            if all(endpoint_checks):
                accepted = candidate
                reason = "IDENTICAL_BOSON_LINES_AND_BOTH_DIFFERENTIATED_VERTICES_ALLOW_SLOT_EXCHANGE"
            else:
                accepted = 1
                reason = "AT_LEAST_ONE_DIFFERENTIATED_VERTEX_FIXES_THE_PARALLEL_ENDPOINT_SLOTS"
        order *= accepted
        records.append(
            {
                "vertex_pair": list(vertices),
                "species": species,
                "edge_indices": [index for index, _edge in entries],
                "multiplicity": multiplicity,
                "candidate_factorial": candidate,
                "accepted_edge_permutation_order": accepted,
                "reason": reason,
            }
        )
    return {
        "parallel_edge_permutation_order": order,
        "groups": records,
        "differentiated_vertex_multiplicity_audited_separately": True,
    }


def corrected_symmetry_data(graph: dict[str, Any]) -> dict[str, Any]:
    node = labelled_node_stabilizer(graph)
    edge = parallel_edge_certificate(graph)
    total = node["node_automorphism_order"] * edge["parallel_edge_permutation_order"]
    return {
        **node,
        **edge,
        "total_symmetry_order": total,
        "symmetry_factor": f"1/{total}" if total != 1 else "1",
        "inventory_identity_unchanged": True,
    }

