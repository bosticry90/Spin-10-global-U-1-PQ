"""Bounded exact local-functional AST primitives for the M08 amendment.

This is intentionally not a general symbolic-QFT language.  It supplies only
the canonical nodes and graded variational derivative operations needed to
freeze A1/A2.  M08 action entry is a separate gated step.
"""

from __future__ import annotations

from hashlib import sha256
import json
from typing import Any, Iterable

import sympy as sp


Expr = dict[str, Any]


SCHEMA_ID = "M08_EXACT_OFFSHELL_LOCAL_FUNCTIONAL_AST_SCHEMA_V1"
NODE_TYPES = (
    "ExactScalar",
    "Parameter",
    "Field",
    "ExternalSource",
    "FrozenBackground",
    "PartialDerivative",
    "Add",
    "OrderedProduct",
    "LorentzContraction",
    "GroupContraction",
    "StructureConstant",
    "RepresentationGenerator",
    "KroneckerMetric",
    "LocalActionTerm",
)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def content_hash(value: Any) -> str:
    return sha256(canonical_json(value).encode()).hexdigest()


def scalar(value: Any) -> Expr:
    exact = sp.sympify(value)
    if exact.free_symbols:
        raise ValueError("ExactScalar may not contain a free symbol")
    return {"node": "ExactScalar", "value": str(sp.factor(exact)), "parity": 0}


def parameter(name: str, *, mass_dimension: int = 0) -> Expr:
    return {
        "node": "Parameter",
        "name": name,
        "mass_dimension": mass_dimension,
        "parity": 0,
    }


def field(name: str, *, parity: int = 0, indices: Iterable[str] = ()) -> Expr:
    return {
        "node": "Field",
        "name": name,
        "indices": list(indices),
        "parity": parity % 2,
    }


def source(name: str, *, parity: int = 0, indices: Iterable[str] = ()) -> Expr:
    return {
        "node": "ExternalSource",
        "name": name,
        "indices": list(indices),
        "parity": parity % 2,
    }


def background(name: str, *, indices: Iterable[str] = ()) -> Expr:
    return {
        "node": "FrozenBackground",
        "name": name,
        "indices": list(indices),
        "parity": 0,
    }


def tensor(node: str, name: str, indices: Iterable[str]) -> Expr:
    if node not in {
        "StructureConstant", "RepresentationGenerator", "KroneckerMetric"
    }:
        raise ValueError(f"unsupported immutable tensor node: {node}")
    return {"node": node, "name": name, "indices": list(indices), "parity": 0}


def derivative(index: str, argument: Expr) -> Expr:
    argument = normalize(argument)
    if is_zero(argument):
        return scalar(0)
    if argument["node"] == "Add":
        return add(*(derivative(index, term) for term in argument["terms"]))
    if argument["node"] == "ExactScalar":
        return scalar(0)
    if argument["node"] == "OrderedProduct" and argument["factors"][0]["node"] == "ExactScalar":
        return mul(
            argument["factors"][0],
            derivative(index, mul(*argument["factors"][1:])),
        )
    return {
        "node": "PartialDerivative",
        "index": index,
        "argument": argument,
        "parity": parity(argument),
    }


def parity(expression: Expr) -> int:
    return int(expression.get("parity", 0)) % 2


def is_zero(expression: Expr) -> bool:
    return expression["node"] == "ExactScalar" and sp.sympify(expression["value"]) == 0


def is_one(expression: Expr) -> bool:
    return expression["node"] == "ExactScalar" and sp.sympify(expression["value"]) == 1


def split_scalar_factor(expression: Expr) -> tuple[sp.Expr, Expr | None]:
    if expression["node"] == "ExactScalar":
        return sp.sympify(expression["value"]), None
    if expression["node"] == "OrderedProduct" and expression["factors"]:
        first = expression["factors"][0]
        if first["node"] == "ExactScalar":
            rest = mul(*expression["factors"][1:])
            return sp.sympify(first["value"]), rest
    return sp.Integer(1), expression


def add(*terms: Expr) -> Expr:
    flat: list[Expr] = []
    for term in terms:
        term = normalize(term)
        if is_zero(term):
            continue
        if term["node"] == "Add":
            flat.extend(term["terms"])
        else:
            flat.append(term)
    if not flat:
        return scalar(0)
    parities = {parity(term) for term in flat}
    if len(parities) != 1:
        raise ValueError("cannot add expressions with different Grassmann parity")
    collected: dict[str, tuple[sp.Expr, Expr | None]] = {}
    for term in flat:
        coefficient, body = split_scalar_factor(term)
        key = "__SCALAR__" if body is None else canonical_json(body)
        if key in collected:
            prior, prior_body = collected[key]
            collected[key] = (sp.factor(prior + coefficient), prior_body)
        else:
            collected[key] = (coefficient, body)
    result = []
    for key in sorted(collected):
        coefficient, body = collected[key]
        if coefficient == 0:
            continue
        result.append(scalar(coefficient) if body is None else mul(scalar(coefficient), body))
    if not result:
        return scalar(0)
    if len(result) == 1:
        return result[0]
    return {"node": "Add", "terms": result, "parity": parity(result[0])}


def mul(*factors: Expr) -> Expr:
    flat: list[Expr] = []
    coefficient = sp.Integer(1)
    for factor in factors:
        factor = normalize(factor)
        if is_zero(factor):
            return scalar(0)
        if factor["node"] == "OrderedProduct":
            candidates = factor["factors"]
        else:
            candidates = [factor]
        for candidate in candidates:
            if candidate["node"] == "ExactScalar":
                coefficient *= sp.sympify(candidate["value"])
            elif not is_one(candidate):
                flat.append(candidate)
    coefficient = sp.factor(coefficient)
    if coefficient == 0:
        return scalar(0)
    if coefficient != 1 or not flat:
        flat.insert(0, scalar(coefficient))
    if len(flat) == 1:
        return flat[0]
    return {
        "node": "OrderedProduct",
        "factors": flat,
        "parity": sum(parity(factor) for factor in flat) % 2,
    }


def normalize(expression: Expr) -> Expr:
    node = expression["node"]
    if node == "Add":
        return add(*expression["terms"])
    if node == "OrderedProduct":
        return mul(*expression["factors"])
    if node == "PartialDerivative":
        return derivative(expression["index"], expression["argument"])
    return expression


def jet(expression: Expr) -> tuple[str, tuple[str, ...], tuple[str, ...], int] | None:
    indices: list[str] = []
    current = expression
    while current["node"] == "PartialDerivative":
        indices.append(current["index"])
        current = current["argument"]
    if current["node"] != "Field":
        return None
    return (
        current["name"],
        tuple(current.get("indices", ())),
        tuple(indices),
        parity(current),
    )


def occurrences(expression: Expr, field_name: str) -> set[tuple[str, ...]]:
    found: set[tuple[str, ...]] = set()
    candidate = jet(expression)
    if candidate is not None and candidate[0] == field_name:
        found.add(candidate[2])
    if expression["node"] == "Add":
        for term in expression["terms"]:
            found.update(occurrences(term, field_name))
    elif expression["node"] == "OrderedProduct":
        for factor in expression["factors"]:
            found.update(occurrences(factor, field_name))
    return found


def jet_partial(expression: Expr, field_name: str, derivative_indices: tuple[str, ...],
                *, side: str) -> Expr:
    """Derivative with respect to an unindexed jet of ``field_name``.

    Indexed action fields require exact variation projectors and are therefore
    deliberately not lowered here.  A3 is responsible for supplying those
    projectors before action entry can be promoted.
    """
    expression = normalize(expression)
    candidate = jet(expression)
    if candidate is not None:
        name, component_indices, derivatives, _field_parity = candidate
        if name == field_name and derivatives == derivative_indices:
            if component_indices:
                raise NotImplementedError(
                    "indexed functional derivatives require a frozen variation projector"
                )
            return scalar(1)
        return scalar(0)
    if expression["node"] == "Add":
        return add(*(jet_partial(term, field_name, derivative_indices, side=side)
                     for term in expression["terms"]))
    if expression["node"] != "OrderedProduct":
        return scalar(0)
    factors = expression["factors"]
    terms = []
    for position, factor in enumerate(factors):
        differentiated = jet_partial(
            factor, field_name, derivative_indices, side=side)
        if is_zero(differentiated):
            continue
        if side == "left":
            exponent = sum(parity(item) for item in factors[:position])
        elif side == "right":
            exponent = sum(parity(item) for item in factors[position + 1:])
        else:
            raise ValueError("side must be left or right")
        terms.append(mul(
            scalar(-1 if exponent % 2 else 1),
            *factors[:position], differentiated, *factors[position + 1:],
        ))
    return add(*terms)


def euler_lagrange(expression: Expr, field_name: str, *, side: str = "left") -> Expr:
    result = scalar(0)
    for derivative_indices in sorted(occurrences(expression, field_name)):
        term = jet_partial(expression, field_name, derivative_indices, side=side)
        for index in reversed(derivative_indices):
            term = derivative(index, term)
        if len(derivative_indices) % 2:
            term = mul(scalar(-1), term)
        result = add(result, term)
    return normalize(result)


def schema_payload() -> dict[str, Any]:
    return {
        "schema_id": SCHEMA_ID,
        "node_types": list(NODE_TYPES),
        "canonical_serialization": "UTF8_JSON_SORTED_KEYS_COMPACT_SEPARATORS",
        "content_hash": "SHA256_OF_CANONICAL_SERIALIZATION",
        "ordered_multiplication": True,
        "automatic_odd_reordering": False,
        "display_string_parser": False,
        "user_defined_rewrite_system": False,
        "scope": "M08_ONLY",
    }
