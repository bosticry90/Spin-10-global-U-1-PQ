"""Read-only own-byte full-space and dependent comparison runner."""
import json, sys, time
from hashlib import sha256
from a10_e5_shear_space import HERE, ROOT, OUT, read, build, s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    route, name = sys.argv[1:]; assert route in ('primary', 'replay', 'comparison')
    path = OUT / name / 'preparation.json'; prep = read(path)
    for n, h in prep['execution_bytes'].items(): assert sha256((ROOT / n).read_bytes()).hexdigest() == h, n
    assert sha256((ROOT / 'project_state.json').read_bytes()).hexdigest() == prep['state_sha256']
    assert sha256((ROOT / prep['input_manifest']).read_bytes()).hexdigest() == prep['input_manifest_sha256']
    if route == 'comparison':
        assert prep['completed_space_sha256']
        for n, h in prep['completed_space_sha256'].items(): assert sha256((OUT / (n + '.json')).read_bytes()).hexdigest() == h
    writes = []
    def hook(event, args):
        if event == 'open' and len(args) > 1 and isinstance(args[1], str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0])); raise PermissionError('SHEAR_SPACE_WORKER_WRITE_DENIED')
    sys.addaudithook(hook)
    print('EXECUTION ' + json.dumps({'route': route, 'preparation': path.relative_to(ROOT).as_posix(),
        'preparation_sha256': sha256(path.read_bytes()).hexdigest(), 'execution_bytes': prep['execution_bytes'],
        'input_manifest_sha256': prep['input_manifest_sha256'], 'state_sha256': prep['state_sha256'],
        'completed_space_sha256': prep['completed_space_sha256'], 'guard_active': True,
        'python': sys.version, 'executable': sys.executable, 'sympy': s.__version__}, sort_keys=True, separators=(',', ':')), flush=True)
    stages = []; started = time.perf_counter()
    def stage(label, fn):
        print('STAGE ' + label, flush=True); tick = time.perf_counter(); value = fn()
        stages.append({'name': label, 'seconds': time.perf_counter() - tick}); return value
    if route == 'comparison':
        from a10_e5_shear_comparison import compare
        result = compare(stage)
    else: result = build(route, stage)
    print('RESULT ' + json.dumps(result, sort_keys=True, separators=(',', ':')), flush=True)
    print('METRICS ' + json.dumps({'execution_state': 'COMPLETED', 'seconds': time.perf_counter() - started,
        'stages': stages, 'write_attempts': writes}, sort_keys=True, separators=(',', ':')), flush=True)


if __name__ == '__main__': main()
