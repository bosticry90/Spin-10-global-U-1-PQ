"""Independent four-dimensional component/monomial controls for JCAT7.

This route never calls GlobalPackets.source_polynomial, covjet, curvature,
variation, primary_candidates or imports frozen primary packet coefficients.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product, permutations
import sympy as sp
from jcat_global_packets import HERE, OUT, OLD, load, canonical, serial, matrix
from jcat_realization_v3 import polynomial_realization_columns, tup, full_covector
from jcat_lorentz_v2 import ETA, epsilon
from int8_block_conjugation_v2 import address_key


def coverage(engine,census):
    candidates=[]
    for g in census['classes']:
        if g['trivial_singleton']:continue
        for hom,sources in engine.source_blocks(g):
            nullity=engine.known_nullspace(sources).cols
            candidates.append({'class_id':g['class_id'],'homogeneous_components':hom,
                'block_id':g['class_id']+'_'+canonical(hom)[:16],
                'ordered_dimension':len(sources),'realization_nullity':nullity,
                'faithful_dimension':len(sources)-nullity,
                'participating_signatures':sorted({s['signature_id'] for s in sources})})
    largest=max(candidates,key=lambda x:(x['faithful_dimension'],x['ordered_dimension'],x['block_id']))
    widest=max(candidates,key=lambda x:(len(x['participating_signatures']),x['faithful_dimension'],x['block_id']))
    triplet=next(r for r in candidates if r['class_id']=='BGC_de08589c4371006e30e7' and
        all(engine.catalog.by_id[c]['H_label']==[0,0,2,0] and engine.catalog.by_id[c]['source_sector']=='Phi' for c,_ in r['homogeneous_components']))
    even=next(r for r in candidates if r['class_id']=='BGC_519a80e3d173dbd4c2ea')
    odd=next(r for r in candidates if r['class_id']=='BGC_dcf889a03b61e95e92eb')
    return {'status':'FROZEN_PHYSICAL_COVERAGE_BEFORE_PRIMARY_COMPARISON',
        'selection_authority':'Class/source census and immutable realization null dimensions only; no primary packet coefficients or ranks',
        'cases':{'triplet_kinetic_and_nontrivial_null':triplet,'background_curvature':even,
            'parity_odd_epsilon_curvature':odd,'largest_faithful_block':largest,
            'maximum_signature_completion':widest},
        'coefficient_route':'Direct four-dimensional carrier tensor -> component monomial coefficients; independently constructed physical curvature targets'}


def physical_columns(engine,group,hom,sources):
    columns=[]
    for source in sources:
        row=engine.rows[source['signature_id']]
        jets=tup(row['raw_Lorentz_derivative_addresses'])
        ai=source['internal_ordinal']; j=source['jet_index']
        monomials,rho=polynomial_realization_columns(engine.catalog,
            engine.addresses(row['internal_family']),jets,[ai*len(jets)+j],tuple(source['background_slots']))
        names=tuple(r['field'] for r in row['ordered_occurrences'])
        tags={}; offset=0
        for slot,name in enumerate(names):
            if name!='Abar_H_mu':tags['HOMO_TAG_'+str(slot)]='H'+str(offset);offset+=1
        p=defaultdict(lambda:0)
        for (i,_),coefficient in rho.todok().items():
            mapped=[]
            for tag,cid,copy,color,mu,derivatives in monomials[i]:
                if tag=='Abar':mapped.append(('A',engine.as_by_component[cid]+color,mu,derivatives))
                else:mapped.append((tags[tag],color,mu,derivatives))
            p[tuple(sorted(mapped))]+=coefficient
        columns.append({m:sp.expand(v) for m,v in p.items() if sp.expand(v)})
    return columns


def curvature_targets(engine,group):
    """4D physical F components with invariant pairings, no formal jet algebra."""
    assert not group['homogeneous_roles'] and group['canonical_dimension']==4
    P=matrix(engine.connection['root_coordinate_columns'])
    roots=load(HERE/'frozen_c3/C3_representation_basis.json')['h_basis']
    raw=sp.SparseMatrix(45,12,{(r['index'],j):sp.sympify(r['coefficient'])
        for j,col in enumerate(roots) for r in col['raw_so10_coordinates']})*P
    gram=(raw.T*raw).applyfunc(sp.simplify)
    assert gram.det()!=0
    # Recover brackets independently from raw SO10 matrices, not primary f.
    from execute_c3_invariant_basis import generators
    basis=[g[1] for g in generators()]
    lifted=[sum((raw[i,a]*basis[i] for i in range(45)),sp.zeros(10)) for a in range(12)]
    flat=sp.Matrix.hstack(*(sp.Matrix(100,1,list(g)) for g in lifted))
    inverse=(flat.T*flat).inv()*flat.T
    f={}
    for b,c in product(range(12),repeat=2):
        bracket=lifted[b]*lifted[c]-lifted[c]*lifted[b]
        coeff=(inverse*sp.Matrix(100,1,list(bracket))).applyfunc(sp.simplify)
        assert flat*coeff==sp.Matrix(100,1,list(bracket))
        for a in range(12):
            if coeff[a]:f[a,b,c]=coeff[a]
    def field(a,mu,nu):
        result=defaultdict(lambda:0)
        result[((('A',a,nu,(mu,))),)]+=1
        result[((('A',a,mu,(nu,))),)]-=1
        for b,c in product(range(12),repeat=2):
            if (a,b,c) in f:result[tuple(sorted((('A',b,mu,()),('A',c,nu,()))))]+=f[a,b,c]
        return {m:v for m,v in result.items() if v}
    fields={(a,mu,nu):field(a,mu,nu) for a,mu,nu in product(range(12),range(4),range(4))}
    results=[]
    for cid,label,start,size in engine.connection['labels']:
        target=defaultdict(lambda:0)
        for a,b in product(range(start,start+size),repeat=2):
            if not gram[a,b]:continue
            if group['parity']=='PARITY_EVEN':
                contractions=[(mu,nu,mu,nu,ETA[mu]*ETA[nu]) for mu,nu in product(range(4),repeat=2)]
            else:contractions=[(*indices,epsilon(indices)) for indices in permutations(range(4))]
            for mu,nu,rho,sigma,phase in contractions:
                for m,v in fields[a,mu,nu].items():
                    for n,w in fields[b,rho,sigma].items():target[tuple(sorted(m+n))]+=phase*gram[a,b]*v*w
        results.append({'physical_parent':'Fbar_'+cid+(' squared' if group['parity']=='PARITY_EVEN' else ' wedge Fbar'),
            'polynomial':{m:sp.expand(v) for m,v in target.items() if sp.expand(v)}})
    return results


def exact_solve(columns,targets):
    """Independent sparse component row-pivot solve and complete reconstruction."""
    monomials=sorted(set().union(*(set(p) for p in columns)))
    rows=defaultdict(dict)
    for j,p in enumerate(columns):
        for m,c in p.items():rows[m][j]=c
    # Incrementally choose physical monomial pivots without primary coefficients.
    pivots={}; chosen=[]
    for m in monomials:
        row=dict(rows[m])
        for j,base in sorted(pivots.items()):
            if j in row:
                c=row[j]
                for k,v in base.items():
                    row[k]=sp.expand(row.get(k,0)-c*v)
                    if not row[k]:del row[k]
        if row:
            j=min(row); c=row[j]; pivots[j]={k:sp.expand(v/c) for k,v in row.items()};chosen.append(m)
            if len(chosen)==len(columns):break
    assert len(chosen)==len(columns), 'PHYSICAL_FAITHFUL_COMPONENT_COLUMNS_NOT_INDEPENDENT'
    M=sp.Matrix([[p.get(m,0) for p in columns] for m in chosen]); inverse=M.inv()
    solutions=[]
    for target in targets:
        c=inverse*sp.Matrix([target.get(m,0) for m in chosen])
        residual=dict(target)
        for polynomial,v in zip(columns,c):
            if v:
                for m,w in polynomial.items():
                    residual[m]=sp.expand(residual.get(m,0)-v*w)
                    if not residual[m]:del residual[m]
        assert not residual,'INDEPENDENT_PHYSICAL_TARGET_OUTSIDE_COMPONENT_SPAN'
        solutions.append(c)
    return {'physical_component_rank':len(chosen),'physical_monomial_count':len(monomials),
        'independently_solved_coefficients':serial(sp.Matrix.hstack(*solutions) if solutions else sp.zeros(len(columns),0)),
        'complete_component_reconstruction':'ZERO_EXACT',
        'source_component_polynomial_hashes':[canonical([[k,str(v)] for k,v in sorted(p.items())]) for p in columns],
        'target_component_polynomial_hashes':[canonical([[k,str(v)] for k,v in sorted(p.items())]) for p in targets],
        'primary_coefficients_imported':False,'primary_formal_realization_imported':False}


def times(polynomials):
    out={():sp.S.One}
    for p in polynomials:
        nxt=defaultdict(lambda:0)
        for m,c in out.items():
            for n,v in p.items():nxt[tuple(sorted(m+n))]+=c*v
        out={m:sp.expand(v) for m,v in nxt.items() if sp.expand(v)}
    return out


@lru_cache(None)
def component_covjet(engine,hom,slot,color,vector,derivatives):
    """Literal component D and D D formula, independent of recursive primary."""
    assert len(derivatives)<=2
    out=defaultdict(lambda:0)
    field=lambda j,ds:('H'+str(slot),j,vector,tuple(sorted(ds)))
    out[(field(color,derivatives),)]+=1
    G=engine.actions(tuple(engine.catalog.by_id[hom[slot][0]]['H_label']))
    if len(derivatives)==1:
        mu=derivatives[0]
        for a,j in product(range(12),range(G[0].cols)):
            if G[a][color,j]:out[tuple(sorted((('A',a,mu,()),field(j,()))))]+=G[a][color,j]
    elif len(derivatives)==2:
        mu,nu=derivatives
        for a,j in product(range(12),range(G[0].cols)):
            v=G[a][color,j]
            if v:
                for A,H in [(('A',a,nu,(mu,)),field(j,())),
                    (('A',a,nu,()),field(j,(mu,))), (('A',a,mu,()),field(j,(nu,)))]:
                    out[tuple(sorted((A,H)))]+=v
        for a,b in product(range(12),repeat=2):
            row=(G[a]*G[b])[color,:]
            for (_,j),v in row.todok().items():
                if v:out[tuple(sorted((('A',a,mu,()),('A',b,nu,()),field(j,()))))]+=v
    return {m:sp.expand(v) for m,v in out.items() if sp.expand(v)}


def independent_covariant_targets(engine,group,hom,sources):
    from jcat_internal_permutations import coordinates
    targets=[]
    for source in sources:
        if source['background_slots']:continue
        row=engine.rows[source['signature_id']]
        degree,(parity,contraction)=tup(row['raw_Lorentz_derivative_addresses'][source['jet_index']])
        dims,tensor=full_covector(engine.catalog,source['address'])
        if parity=='PARITY_EVEN':
            assignments=[([(token,mu) for pair,mu in zip(contraction,values) for token in pair],sp.prod(ETA[mu] for mu in values)) for values in product(range(4),repeat=len(contraction))]
        else:assignments=[(list(zip(contraction,values)),epsilon(values)) for values in permutations(range(4))]
        ds_count=[sum(t==('p',i) for pair in contraction for t in pair) if parity=='PARITY_EVEN' else contraction.count(('p',i)) for i in range(len(hom))]
        orders=list(product(*(tuple(dict.fromkeys(permutations(range(count)))) for count in ds_count)))
        for order in orders:
            out=defaultdict(lambda:0)
            for tokens,phase in assignments:
                vector={}; derivatives=defaultdict(list)
                for (kind,i),mu in tokens:
                    if kind=='v':vector[i]=mu
                    else:derivatives[i].append(mu)
                for (index,_),coefficient in tensor.todok().items():
                    colors=coordinates(index,dims)
                    polys=[component_covjet(engine,hom,i,color,vector.get(i,-1),tuple(derivatives[i][j] for j in order[i])) for i,color in enumerate(colors)]
                    for m,v in times(polys).items():out[m]+=phase*coefficient*v
            targets.append({'physical_parent':'Literal component Dbar / Dbar Dbar contraction',
                'leading_source':source,'ordered_derivative_permutations':order,
                'polynomial':{m:sp.expand(v) for m,v in out.items() if sp.expand(v)}})
    return targets


def independent_F_homogeneous_targets(engine,group,hom):
    from jcat_internal_permutations import coordinates
    # The preregistered largest class consists of two vector occurrences and
    # admits F_{mu nu} X^mu Y^nu. Its curvature scalar controls are above.
    if len(hom)!=2:return []
    prototype=next((engine.rows[m['signature_id']] for m in group['members'] if m['background_count']==1),None)
    if prototype is None:return []
    names=tuple(r['field'] for r in prototype['ordered_occurrences'])
    types=engine.contract_rows[prototype['signature_id']]['field_types']
    bg=names.index('Abar_H_mu'); hslots=[i for i in range(len(names)) if i!=bg]
    if not all(types[i]['Lorentz_type']=='VECTOR' for i in hslots):return []
    out=[]
    # Curvature coefficients are independently recovered by raw SO10 matrices.
    roots=load(HERE/'frozen_c3/C3_representation_basis.json')['h_basis']
    raw=sp.SparseMatrix(45,12,{(r['index'],j):sp.sympify(r['coefficient']) for j,c in enumerate(roots) for r in c['raw_so10_coordinates']})*matrix(engine.connection['root_coordinate_columns'])
    from execute_c3_invariant_basis import generators
    basis=[g[1] for g in generators()]
    lifted=[sum((raw[i,a]*basis[i] for i in range(45)),sp.zeros(10)) for a in range(12)]
    flat=sp.Matrix.hstack(*(sp.Matrix(100,1,list(g)) for g in lifted)); inv=(flat.T*flat).inv()*flat.T
    coeff={(b,c):(inv*sp.Matrix(100,1,list(lifted[b]*lifted[c]-lifted[c]*lifted[b]))).applyfunc(sp.simplify) for b,c in product(range(12),repeat=2)}
    for address in engine.addresses(prototype['internal_family']):
        slots,copies=engine.catalog.address_parts(address)[2:4]
        if tuple((slots[i],copies[i]) for i in hslots)!=hom:continue
        dims,tensor=full_covector(engine.catalog,address); p=defaultdict(lambda:0)
        for (index,_),coefficient in tensor.todok().items():
            colors=coordinates(index,dims); a=engine.as_by_component[slots[bg]]+colors[bg]
            for mu,nu in product(range(4),repeat=2):
                h=(('H0',colors[hslots[0]],mu,()),('H1',colors[hslots[1]],nu,()))
                weight=coefficient*ETA[mu]*ETA[nu]
                p[tuple(sorted(h+(('A',a,nu,(mu,)),)))]+=weight
                p[tuple(sorted(h+(('A',a,mu,(nu,)),)))]-=weight
                for b,c in product(range(12),repeat=2):
                    v=coeff[b,c][a]
                    if v:p[tuple(sorted(h+(('A',b,mu,()),('A',c,nu,()))))]+=weight*v
        out.append({'physical_parent':'Direct 4D Fbar_mu_nu X^mu Y^nu','internal_address':address,
            'polynomial':{m:sp.expand(v) for m,v in p.items() if sp.expand(v)}})
    return out
