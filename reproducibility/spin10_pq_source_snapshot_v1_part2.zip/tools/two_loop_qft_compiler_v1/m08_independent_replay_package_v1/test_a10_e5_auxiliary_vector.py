"""Scientific controls for even auxiliary fields, Bose sums and Ward completion."""
import unittest
from audit_a10_e5_auxiliary_vector import *
from a10_e5_auxiliary_vector_control import born as unit_born,residue as unit_residue,model


class AuxiliaryVectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_full_symmetric_vector_domain(self):
        self.assertEqual(self.a['domain']['BB_symmetric_slots'],45*180*181//2);self.assertEqual(self.a['domain']['AB_slots'],45*180*48);self.assertEqual(self.a['domain']['AA_symmetric_slots'],45*48*49//2)
    def test_auxiliary_is_even_and_not_BV_source(self):
        w,P=model(0,0);self.assertEqual(w.external['Le'],(2,0,0));w.p['Le']=1;w.external['Le']=(2,0,1);self.assertFalse(w.grade(P[0],(4,0,0)))
    def test_even_identical_vector_square_survives(self):
        w=alphabet();register(w,'Bsame',(1,0,0));self.assertTrue(w.mul(w.var('Bsame'),w.var('Bsame')))
    def test_homogeneous_projection_retains_equal_vectors(self):
        one=ex.coefficient(1);self.assertEqual(product({(13,45):one},{(45,):one}),{(13,45,45):one})
    def test_all160_unit_components(self):self.assertEqual(sum(map(len,self.u['unit_pole_Lorentz_matrices'].values())),160)
    def test_each_ghost_derivative_sign_is_measured(self):
        self.assertEqual({n:V[0][2] for n,V in self.u['unit_pole_Lorentz_matrices'].items() if n in ['triangle:a:a','triangle:a:c','triangle:c:a','triangle:c:c']},
            {'triangle:a:a':'-1/2','triangle:a:c':'1/2','triangle:c:a':'1/2','triangle:c:c':'-1/2'})
    def test_external_vector_derivatives_are_calculated_zero(self):
        self.assertTrue(all(z=='0' for n,V in self.u['unit_pole_Lorentz_matrices'].items() if ':B:' in n or n.endswith(':B') for i,j,z in V))
    def test_offdiagonal_kernels_nonzero_residue_zero(self):self.assertTrue(self.u['nonzero_offdiagonal_kernels_zero_residue']);self.assertTrue(all(z=='0' for V in self.u['unit_pole_Lorentz_matrices'].values() for i,j,z in V if i!=j))
    def test_reverse_odd_orientation_omission_changes_residue(self):
        self.assertEqual(unit_residue(unit_born('bubble',0,0,omit_reverse_odd=True),'primary'),-1);self.assertEqual(self.u['unit_pole_Lorentz_matrices']['bubble:a:a'][0][2],'-2')
    def test_triangle_is_calculated_then_Bose_zero(self):
        self.assertFalse(any(self.a['family_poles']['triangle'].values()));self.assertGreater(self.a['program']['nonzero_ordered_source_G_intermediate_cells'],0)
    def test_dropping_vector_assignment_changes_ordered_tensor(self):
        b=read(OUT/'replay.json');i,j,k,x,y=b['program']['ordered_triangle_exact_witnesses'][0];self.assertNotEqual(s.sympify(x),0);self.assertEqual(s.simplify(s.sympify(x)+s.sympify(y)),0)
    def test_background_vertices_exist_before_zero_poles(self):
        self.assertFalse(self.a['actual_pole']['AB']);self.assertFalse(self.a['actual_pole']['AA'])
        self.assertTrue(all(any(any(n.startswith('Ap') for n,j in word) for word in decode_typed(self.a['vertices'][role])) for role in ['all_B_A_ghost','all_BB_AB_AA_quartic']))
    def test_altered_zero_background_channel_has_nonzero_Ward(self):
        w=alphabet();P=w.scale(w.mul(w.var(AUX[0]),w.var('A0_0'),w.var('B0_0')),g**2*xi);T={n:decode_typed(Q) for n,Q in read(HERE/'frozen_a10_e3_symmetry/primary.json')['operators']['Tb_geometric_and_transported'].items()}
        self.assertTrue(canonical(act(P,w,T,'primary',0)))
    def test_auxiliary_primal_chart_is_wrong(self):
        w,sub,back,source,anti,Cinv,Cphys=frames('primary');pullback=w.replace
        for i in IDS:back[f'Lp{i}']=w.add(*(w.scale(w.var(AUX[j]),Cphys[i,j]) for j in IDS if Cphys[i,j]))
        physical=decode_typed(self.a['physical_full_g_squared_xi_density']);wrong=pullback(physical,back);self.assertTrue(canonical(w.add(wrong,w.scale(decode_typed(self.a['canonical_full_g_squared_xi_density']),-1))))
    def test_coupling_units_are_explicit(self):self.assertTrue(all(s.Poly(z,g,xi).monoms()==[(2,1)] for z in decode_typed(self.a['canonical_full_g_squared_xi_density']).values()))
    def test_wrong_coupling_fails_old_plus_new_Ward(self):
        w=alphabet();self.assertTrue(canonical(w.add(decode_typed(self.c['original_mixing_Ward']),w.scale(decode_typed(self.c['new_auxiliary_vector_Ward']),1/g))))
    def test_all12_rigid_H_identities(self):self.assertEqual(self.a['all12_constant_H_identities'],list(range(12)))
    def test_omitting_measured_partner_leaves_nonzero_Ward(self):self.assertGreater(self.c['negative_controls']['omitted_actual_partner_Ward_terms'],0)
    def test_complete_parameter_Eulers_and_currents(self):
        w=alphabet();P=decode_typed(self.c['enlarged_mixing_Ward_raw']);A=decode_typed(self.c['enlarged_mixing_Ward_anchored']);C=[decode_typed(Q) for Q in self.c['mixing_full_IBP_currents']]
        self.assertFalse(canonical(w.add(P,w.scale(A,-1),w.scale(w.add(*(w.D(Q,mu) for mu,Q in enumerate(C))),-1))));self.assertEqual(len(self.c['all12_mixing_parameter_Eulers']),12)
    def test_omitted_parameter_jets_falsely_hide_old_obligation(self):
        w=alphabet();wave=decode_typed(read(HERE/'frozen_a10_e5_ward_reassembly/primary.json')['sectors']['mixing_g1'])
        T={n:{word:z for word,z in decode_typed(Q).items() if not any(n.startswith('omega') and j for n,j in word)} for n,Q in read(HERE/'frozen_a10_e3_symmetry/primary.json')['operators']['Tb_geometric_and_transported'].items()}
        actual=decode_typed(self.c['original_mixing_Ward']);prolonged=canonical(act(wave,w,T,'primary',0))
        self.assertFalse(canonical(w.add(actual,w.scale(prolonged,-1)))) # Homogeneous images still generate parameter jets on differentiation.
        truncated={word:z for word,z in prolonged.items() if not any(n.startswith('omega') and j for n,j in word)}
        self.assertFalse(truncated);self.assertTrue(canonical(w.add(actual,w.scale(truncated,-1))))
    def test_omitting_old_mixing_boundary_current_is_detectable(self):
        w=alphabet();raw=decode_typed(self.c['original_mixing_Ward']);anchor,curr=omega_reduce(raw,w)
        self.assertTrue(canonical(w.add(raw,w.scale(anchor,-1))));self.assertTrue(any(curr))
    def test_failed_test_harness_is_preserved_and_excluded(self):
        for i in [1,2]:
            d=read(OUT/f'engineering_attempt_{i}.json');self.assertEqual(d['execution_state'],'FAILED');self.assertFalse(d['counted_as_validation_PASS']);self.assertFalse(d['actual_routes_modified'])
            source=OUT/d['source_snapshot']/'test_a10_e5_auxiliary_vector.py.source.txt';self.assertEqual(sha256(source.read_bytes()).hexdigest(),d['source_sha256'])
    def test_previous_selected_Slavnov_scopes_unchanged(self):self.assertTrue(all(not P for P in self.c['new_node_selected_Slavnov_projections'].values()));self.assertTrue(self.c['earlier_GP_source_Ward_and_GS_Slavnov_scopes_preserved'])
    def test_unknowns_authority_and_prior_failure_preserved(self):
        self.assertFalse(self.c['unknown_Gamma_Delta_contacts_measure_IR_set_to_zero']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete']);self.assertTrue(self.c['prior_g3_candidate_failure_preserved'])
        self.assertFalse(read(HERE/'frozen_a10_e5_quartic_g3/bindings.json')['candidate_selected_quartic_g3_gate_PASS'])


if __name__=='__main__':unittest.main()
