"""General curved identities and adversarial controls for the bounded E4 scope."""
import unittest
from a10_e4_interaction_common import *
from audit_a10_e4_interaction import adjudicate


class E4InteractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
        cls.c=read(OUT/'checks.json')

    def test_independent_complete_adjudication(self):
        self.assertEqual(adjudicate(self.p,self.r),self.c['matching_result'])
        self.assertFalse(self.r['primary_outputs_imported'])

    def test_all_607_restricted_field_columns(self):
        self.assertEqual(len(self.p['restricted_fields']),607)
        self.assertEqual(self.p['restricted_fields'],self.r['restricted_fields'])
        self.assertNotIn('C0',self.p['restricted_fields'])

    def test_all_1214_canonical_source_columns(self):
        self.assertEqual(len(self.p['curved_cotangent']['source_columns']),1214)
        self.assertEqual(self.p['curved_cotangent']['source_columns'],self.r['curved_cotangent']['source_columns'])
        # Cheap typed sign check precedes expensive fresh replay in validation.
        w=alphabet();pairs=[('B0_0','JB0_0'),('C12','JC12')]
        fields={'B0_0':w.var('C13'),'C12':w.mul(w.var('C14'),w.var('C15'))}
        _,columns=cotangent(fields,pairs,w,'primary')
        self.assertEqual(columns['B0_0'],fields['B0_0'])
        self.assertEqual(columns['C12'],fields['C12'])
        self.assertTrue(self.c['initial_even_parser_error_preserved'])

    def test_curvature_has_twelve_composite_components(self):
        self.assertEqual(len(self.p['curvature']),12)
        self.assertEqual(self.p['equivariant_algebra']['delta_R_checks'],12)
        self.assertEqual(self.c['local_R_H_covariance_checks'],12)

    def test_equivariant_square_and_local_jets(self):
        a=self.p['equivariant_algebra']
        self.assertEqual(a['field_square_checks'],607)
        self.assertEqual(a['first_jet_square_checks'],1214)
        self.assertIn('-g10 T_RH',a['square'])
        self.assertTrue(self.c['false_restricted_nilpotence'])

    def test_curved_master_boundary_and_structural_source_squares(self):
        a=self.p['curved_cotangent']
        self.assertFalse(a['master_minus_curvature_and_divergence'])
        self.assertEqual(len(a['master_current']),4)
        self.assertEqual(len(a['source_square']),607)
        self.assertEqual(len(a['explicit_source_squares_checked']),4)
        self.assertEqual(len(self.c['charged_source_squares']),3)
        self.assertTrue(all(self.c['charged_source_squares'].values()))
        self.assertFalse(self.c['H_singlet_ub12_square'])
        self.assertIn('graded Jacobi',a['general_source_square_basis'])

    def test_composite_chain_rule_cannot_freeze_curvature(self):
        d=self.p['curved_cotangent']['composite_source_correction']
        self.assertTrue(any(d.values()))
        self.assertTrue(all(not P or n.startswith('JC') for n,P in d.items()))
        self.assertTrue(self.c['frozen_composite_source_derivative']['residual'])

    def test_full_BV_curvature_bridge_is_retained(self):
        self.assertTrue(self.p['full_source_bridge'])
        self.assertTrue(any(self.p['full_source_bridge_covectors'].values()))
        self.assertFalse(self.p['curved_cotangent']['canonical_restriction_is_full_BV_quotient'])

    def test_complete_heavy_light_density_and_E2_binding(self):
        self.assertEqual(len(self.p['heavy_density_parts']),5)
        self.assertTrue(self.p['light_density'])
        actual=read(HERE/'frozen_a10_e2_transport/primary.json')['gauge_fixing_density']
        self.assertEqual(self.p['complete_E2_density_sha256'],digest(rows(decode_typed(actual))))

    def test_both_quartic_structures_and_omission_controls(self):
        q=self.p['quartic_parts']
        self.assertTrue(q['heavy_auxiliary'])
        self.assertTrue(q['heavy_cubic'])
        self.assertTrue(self.c['quartic_curvature_omission_breaking'])
        self.assertTrue(self.c['quartic_nonsymmetric_omission_breaking'])

    def test_removed_curvature_is_detected(self):
        self.assertTrue(self.c['removed_curvature_square'])

    def test_symmetric_coset_substitution_is_detected(self):
        self.assertTrue(self.c['symmetric_coset_false_substitution']['residual'])

    def test_bare_pairing_fails_with_nonboundary_Euler(self):
        self.assertTrue(self.c['bare_pairing_Ward'])
        self.assertTrue(self.c['bare_pairing_Euler_L13'])

    def test_light_trivial_pairs_not_mislabeled_equivariant(self):
        self.assertEqual(self.p['equivariant_algebra']['full_BV_pairs_retained'],643)
        self.assertTrue(self.c['false_light_equivariant_extension'])
        self.assertFalse(self.p['auxiliaries_eliminated'])

    def test_parameters_and_authority_remain_bounded(self):
        self.assertIn('xi',self.p['parameter_meanings']['alpha'])
        self.assertEqual(self.p['formal_authority'],'34/39_UNCHANGED')
        for key in ('E5_executed','sources_activated','HB1_C5_run','C1_GS_calculated','candidate_adopted'):
            changed=dict(self.p);changed[key]=True
            with self.assertRaises(AssertionError):adjudicate(changed,self.r)

    def test_physical_program_dependency_and_resource_limits_explicit(self):
        self.assertEqual(self.p['curved_cotangent']['physical_Euler_programs_reused'],508)
        self.assertFalse(self.p['curved_cotangent']['physical_equations_imposed'])
        self.assertTrue(self.c['jet_cap_raises'])
        self.assertFalse(self.p['Stage_D_E3_modified'])


if __name__=='__main__':unittest.main()
