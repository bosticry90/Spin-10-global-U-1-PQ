"""Adversarial adapter checks target type, normalization and local jets."""
import unittest
from copy import deepcopy
import sympy as s
from a10_executable_action import build,read,HERE,contract
from a10_cotangent_adapter import Adapter,SORTED
from a10_cotangent_graphs import normal_graphs,directional,potential_covectors
from a10_cotangent_kinetic import normal,expected,qualify
from m08_local_functional_ast import field,mul
from audit_a10_cotangent import authenticate

class CotangentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')

    def test_all_general_replay_certificates_and_stop_gate(self):
        r=authenticate();self.assertEqual(r['raw_ordered_potential_Euler_templates'],203)
        self.assertEqual(r['independent_real_potential_parameters'],34)
        self.assertFalse(r['complete_master_action_constructed']);self.assertFalse(r['Stage_E_reached'])

    def test_nonantisymmetric_covector_refutes_blind_factorial(self):
        a=Adapter('Sigma');raw={'Sigma':{SORTED[0]:1}}
        alpha=a.pullback(raw);self.assertNotEqual(alpha,120*alpha)
        reverse=list(SORTED[0]);reverse[0],reverse[1]=reverse[1],reverse[0]
        self.assertEqual(a.pullback({'Sigma':{tuple(reverse):1}}),-alpha)

    def test_repeated_form_indices_annihilate(self):
        self.assertEqual(Adapter('Sigma').pullback({'Sigma':{(0,0,1,2,3):7}}),s.zeros(252,1))

    def test_complex_imaginary_pullback_sign(self):
        a=Adapter('S');v=a.pullback({'S':{():s.I},'SBar':{():-s.I}})
        self.assertEqual(v,s.Matrix([0,-s.sqrt(2)]))
        self.assertNotEqual(v,-v)

    def test_Riesz_metric_must_be_removed_from_covector(self):
        a=Adapter('phi');raw={'phi':{(0,):1},'phiBar':{(0,):1}}
        correct=a.pullback(raw);self.assertEqual(a.lower_riesz(a.riesz(raw)),correct)
        self.assertEqual(a.lower_riesz(a.real_covector(raw)),2*correct)

    def test_all_sector_sections_and_pairing(self):
        for sec in ('Phi','Sigma','phi','S'):
            a=Adapter(sec);v=s.zeros(a.n,1);v[0]=3;v[a.n-1]=-2
            raw=a.section(v);self.assertEqual(a.pullback(raw).applyfunc(s.simplify),v)
            h=s.Matrix([s.Symbol('h'+str(i)) for i in range(a.n)])
            alpha=a.real_covector(raw)
            self.assertEqual(s.simplify((alpha.T*a.E*h-v.T*h)[0]),0)

    def test_constrained_Phi_has_no_full_ambient_inverse(self):
        a=Adapter('Phi');raw={'Phi':{(i,i):1 for i in range(10)}}
        self.assertEqual(a.pullback(raw),s.zeros(54,1))
        self.assertNotEqual(raw,a.section(a.pullback(raw)))

    def test_wrong_minus_potential_is_detected_generally(self):
        term=next(t for t in build()['local_terms'] if t.get('coefficient_direction')=='mSigma2')
        correct=normal_graphs(directional(term));bad=deepcopy(term)
        bad['density']['factors'][0]['value']='1'
        self.assertNotEqual(correct,normal_graphs(directional(bad)))

    def test_Hermitian_imaginary_parameter_orientation_is_detected_generally(self):
        term=next(t for t in build()['local_terms'] if t.get('coefficient_direction')=='zEta')
        correct=potential_covectors(term)['differential_graph_coefficients'];bad=deepcopy(term)
        def flip(n):
            if isinstance(n,dict):
                if n.get('node')=='ExactScalar' and n.get('value') in ('I','-I'):n['value']='-I' if n['value']=='I' else 'I'
                for v in n.values():flip(v)
            elif isinstance(n,list):
                for v in n:flip(v)
        flip(bad);self.assertNotEqual(correct,normal_graphs(directional(bad)))

    def test_missing_connection_derivative_cannot_hide_at_B_zero(self):
        term=build()['local_terms'][1];correct=qualify(term)['Euler_graph_coefficients']
        e=expected('Phi');bad=deepcopy(e);bad['expression']['terms'].pop(1)
        node=contract(mul(field('h_Phi',indices=('i',)),bad),('i',))
        self.assertNotEqual(normal(node),correct)
        # Selected local jet: B=0, x'=x''=0, partial B nonzero. The remaining
        # -g rho(partial B)x is still nonzero, independently of B itself.
        R=s.Matrix([[0,1],[-1,0]]);x=s.Matrix([1,0]);self.assertEqual(-R*x,s.Matrix([0,1]))

    def test_source_bridge_requires_its_actual_pairing(self):
        r=read(HERE/'frozen_a10_cotangent_adapter/source_composition.json')
        self.assertTrue(r['negative_controls']['typed_pairing_identity_false'])
        self.assertNotEqual(r['maps']['typed_pairing']['canonical_sparse_sha256'],r['maps']['AST_evaluation_from_typed_source']['canonical_sparse_sha256'])

    def test_qualified_source_Hamiltonian_sign_is_fixed(self):
        from source_convention_control import Exterior
        a=Exterior();x=a.variable('x',0);J=a.variable('J',1)
        S=a.scale(a.mul(x,x),-s.Symbol('m'))
        self.assertEqual(a.bracket(S,J,[('x','J')]),a.scale(x,-2*s.Symbol('m')))
        self.assertNotEqual(a.bracket(S,J,[('x','J')]),a.scale(x,2*s.Symbol('m')))

    def test_bad_alias_and_rank_rejected(self):
        with self.assertRaises(AssertionError):Adapter('S').pullback({'Sigma':{():1}})
        with self.assertRaises(AssertionError):Adapter('Sigma').pullback({'Sigma':{(0,1):1}})

if __name__=='__main__':unittest.main()
