"""Direct physical/component replay; no primary decoder/table import."""
import json
from hashlib import sha256
from pathlib import Path
import sympy as s
from nonabelian_m08_semantic_replay import geometry, matrix_record as raw_matrix_record

HERE = Path(__file__).resolve().parent


def load(name): return json.loads((HERE/name).read_text(encoding="utf-8"))
def clean(m): return s.ImmutableSparseMatrix(m).applyfunc(s.simplify)
def matrix_record(m):
    r=raw_matrix_record(m)
    return {"shape":[int(v) for v in r["shape"]],"entries":[[int(i),int(j),v] for i,j,v in r["entries"]]}
def matrix(r): return s.ImmutableSparseMatrix(*r["shape"],{(i,j):s.sympify(v) for i,j,v in r["entries"]})
def matrix_digest(m):
    payload = matrix_record(m)
    payload = {"shape": [int(v) for v in payload["shape"]], "entries": [[int(i),int(j),v] for i,j,v in payload["entries"]]}
    return {"shape":payload["shape"],"nonzero_entries":len(payload["entries"]),"canonical_sparse_sha256":sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()}


def physical_triangles():
    data = load("frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json")["components"]
    reg = load("frozen_irrep_carrier_registry/REG7_dual_pairings.json")
    pair3 = {tuple(r["left"]):matrix(r["matrix"]) for r in reg["SU3_pairings"]}
    pair2 = {r["n"]:matrix(r["matrix"]) for r in reg["SU2_pairings"]}
    modules = {}; orders = {}
    for family in ("A","H","S"):
        rows = [r for r in data if r["family"] == family]; factor = s.sqrt(2) if family != "S" else 1
        orders[family] = [r["source_component"] for r in rows]
        p = {r["source_component"]:factor*matrix(r["physical_columns"]) for r in rows}
        P = s.ImmutableSparseMatrix(s.Matrix.hstack(*(p[c] for c in orders[family])))
        # Recompute the inverse/left inverse from physical primal columns,
        # without importing serialized physical extractors or primary maps.
        # Hermitian Gram is only a solver for this inverse, not a replacement
        # for the bilinear evaluation, REG7 pairing or canonical BV bracket.
        hermitian = clean(P.conjugate().T*P)
        A = clean(hermitian.inv()*P.conjugate().T)
        assert clean(A*P) == s.eye(P.cols)
        offsets = {}; start = 0
        for c in orders[family]: offsets[c]=(start,start+p[c].cols); start += p[c].cols
        d = {}; da = {}
        for r in rows:
            c, partner = r["source_component"],r["target_component"]
            label = next(x["source_label"] for x in rows if x["source_component"] == partner)
            J = s.kronecker_product(pair3[tuple(label[:2])],pair2[label[2]]).T
            JJ = s.kronecker_product(s.eye(p[c].cols//J.cols),J)
            lo,hi=offsets[partner]; d[c]=clean(A[lo:hi,:].T*JJ)
            da[c]=clean(JJ.inv()*p[partner].T)
        D = s.ImmutableSparseMatrix(s.Matrix.hstack(*(d[c] for c in orders[family])))
        DA=s.ImmutableSparseMatrix(s.Matrix.vstack(*(da[c] for c in orders[family])))
        assert clean(DA*D) == s.eye(P.cols)
        modules[family]=P,A,D,DA
    rep=load("frozen_c3/C3_representation_basis.json"); bases={}
    for family,key in (("A","h_basis"),("H","heavy_basis")):
        B=s.Matrix(45,len(rep[key]),lambda i,j: next((s.sympify(v["coefficient"]) for v in rep[key][j]["raw_so10_coordinates"] if v["index"]==i),0))
        G=clean(B.T*B); L=G.inv()*B.T; bases[family]=B,L,L.T
    bases["S"]=(s.ImmutableSparseMatrix(s.eye(328)),)*3
    result=[]
    for source,family,dual in (("K_V","H",False),("K_q","A",False),("K_phi","S",False),("L_u","H",False),("K_Lambda","H",True),("L_c","A",False)):
        P,A,D,DA=modules[family]; B,L,BD=bases[family]
        field,field_left=(BD,B.T) if dual else (B,L)
        X,XA=(D,DA) if dual else (P,A)
        Y,YA=(P,A) if dual else (D,DA)
        E=clean(field.T*Y); inverse=clean(YA*field_left.T)
        T=clean(field_left*X); Tinverse=clean(XA*field)
        for m,n in ((E,inverse),(T,Tinverse)):
            assert clean(m*n)==clean(n*m)==s.eye(m.rows)
        assert clean(field*T-X)==s.zeros(*X.shape)
        assert clean(field_left.T*E-Y)==s.zeros(*Y.shape)
        terminal=clean(Y.T*X); assert clean(E.T*T-terminal)==s.zeros(*terminal.shape)
        ceval=clean(field_left*field.conjugate()).inv().T
        ctyped=clean(YA*Y.conjugate())
        assert clean(E*ctyped-ceval*E.conjugate())==s.zeros(*E.shape)
        assert clean(ctyped*ctyped.conjugate())==s.eye(ctyped.rows)
        macro=clean(B.T*B) if source in ("K_q","L_c") else s.ImmutableSparseMatrix(s.eye(E.rows))
        K=clean(macro.inv()*E); Ki=clean(inverse*macro)
        source_frame=B if source in ("K_q","L_c","K_Lambda") else field_left.T
        assert clean(K*Ki)==clean(Ki*K)==s.eye(K.rows)
        assert clean(source_frame*K-Y)==s.zeros(*Y.shape)
        result.append({"source":source,"family":family,"field_dual":dual,"typed_source_dual":not dual,
            "channel_components":E.rows,"channel_address_order":orders[family],
            "AST_evaluation_from_typed_source":matrix_digest(E),"inverse":matrix_digest(inverse),
            "AST_field_from_typed_field":matrix_digest(T),"field_inverse":matrix_digest(Tinverse),
            "catalog_macro_from_typed_source":matrix_digest(K),"catalog_macro_inverse":matrix_digest(Ki),
            "macro_to_AST_evaluation":matrix_digest(macro),"typed_pairing":matrix_digest(terminal),
            "induced_source_only_coordinate_bracket_unsigned":matrix_digest(inverse.T),
            "evaluation_conjugation":matrix_digest(ceval),"typed_source_conjugation":matrix_digest(ctyped),
            "both_inverse_products_pairing_physical_reconstruction_conjugation":True,
            "field_and_source_varied_simultaneously_identity_pairing_assumed":False})
    return result


def build(stage=lambda name, fn: fn()):
    def source_words():
        rows = []; frozen = load("frozen_source_seed_s3_s5/S33_source_couplings.json")
        for row in frozen["couplings"]:
            value = row["coupling_AST"]["density"]
            while value["node"] in ("GroupContraction", "LorentzContraction"): value = value["expression"]
            factors = value["factors"]; assert len(factors) == 2
            source, image = factors; assert source["name"] == row["source"] and source["node"] == "ExternalSource"
            # Independent ordered-word extraction: a single undifferentiated
            # left source, no preceding odd factor and no inserted tensor.
            # Its left component derivative is precisely the second factor.
            prior = next(r for r in load("frozen_variational_s5_s8/V8_source_derivatives.json")["rows"] if r["source"] == row["source"])
            assert image == prior["recovered_image_AST"]
            rows.append({"source": row["source"], "target_AST": row["target"],
                "recovered_image_AST": image, "source_indices": source["indices"], "pairing": "IDENTITY_EVALUATION"})
        return rows
    words = stage("independent_source_word_extraction", source_words)
    _, H, physical = stage("direct_physical_parent_commutators", geometry)
    basis = load("frozen_c3/C3_representation_basis.json"); vectors = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        vectors.append({r["index"]: s.sympify(r["coefficient"]) for r in row["raw_so10_coordinates"]})
    gram = s.Matrix(12, 12, lambda i,j: s.simplify(sum(vectors[i].get(k,0)*vectors[j].get(k,0) for k in range(45))))
    inverse = gram.inv(); columns = s.Matrix(45,45,lambda i,j: vectors[j].get(i,0))
    real = (columns.inv()*columns.conjugate()).applyfunc(s.simplify)[:12,:12]; dual = real.inv().T
    assert gram*inverse == s.eye(12) and (gram*real-dual*gram.conjugate()).applyfunc(s.simplify) == s.zeros(12)
    wrong = []; checks = 0
    for a, M in enumerate(H):
        # Coefficient of J_i X_j in L(sum J_k X_k), evaluated componentwise.
        residual = s.Matrix(12,12,lambda i,j: s.simplify(M[j,i]+M[i,j]))
        for i in range(12):
            for j in range(12):
                assert s.simplify(-M[i,j]+M[i,j]) == 0
                assert s.simplify(sum(M[k,i]*gram[k,j]+gram[i,k]*M[k,j] for k in range(12))) == 0
                checks += 1
        wrong.append({"generator": a, "residual": matrix_record(residual)})
    first = next([r["generator"],*e] for r in wrong for e in r["residual"]["entries"])
    assert first == [0,4,4,"-sqrt(2)*I"]
    triangles=stage("independent_physical_column_inverse_triangles",physical_triangles)
    return {"schema": "SOURCE_COMPONENT_DECODER_REPLAY_V1", "source_words": words,
        "H_gram": matrix_record(gram), "inverse": matrix_record(inverse),
        "primal_conjugation": matrix_record(real), "evaluation_dual_conjugation": matrix_record(dual),
        "wrong_direct_primal_delta_pairing": wrong, "first_nonzero_component": first,
        "component_pairing_equations": checks, "physical_triangles": triangles,
        "conditional_induced_even_field_bracket": matrix_record(inverse.T),
        "conditional_induced_odd_field_bracket": matrix_record(-inverse.T),
        "independence": {"ALGORITHM_INDEPENDENT": True, "CODE_PATH_INDEPENDENT": True,
            "LIBRARY_INDEPENDENT": False, "RUNTIME_INDEPENDENT": False, "analyst_blind": False,
            "primary_decoder_or_output_imported": False, "physical_parent_commutators": physical["physical_parent_commutators_reconstructed"],
            "external_specialist_review": False, "shared_inputs": "S33/V8/C3 geometry and declared interpretation of same coordinates; Python/SymPy",
            "scalar_328_reconstructed": False,"scalar_328_source_decoder_checked":True,
            "serialized_extractors_imported":False}}


if __name__ == "__main__": print(json.dumps(build(),sort_keys=True,separators=(",",":")))
