"""Seal this bounded deliverable only after completed validation."""
from pathlib import Path
from hashlib import sha256
import json,subprocess

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OUT=HERE/'frozen_a10_cotangent_adapter'
FILES=('A10_COTANGENT_ADAPTER_CONTRACT_V1.md','A10_COTANGENT_ADAPTER_RESULT.md',
    'A10_COTANGENT_TECHNICAL_REVIEW_PACKET_V1.md','a10_cotangent_adapter.py',
    'a10_cotangent_graphs.py','a10_cotangent_kinetic.py','a10_cotangent_primary.py',
    'a10_cotangent_replay.py','a10_cotangent_source.py','audit_a10_cotangent.py',
    'export_a10_cotangent_evidence.py','export_a10_cotangent_receipt.py',
    'run_a10_cotangent.py','test_a10_cotangent.py','validate_a10_cotangent.py','seal_a10_cotangent.py')
def digest(path):return sha256(path.read_bytes()).hexdigest()

def main():
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    receipt=json.loads((OUT/'validation_receipt.json').read_bytes())
    assert receipt['status']=='PASS_BOUNDED_ADAPTER_EVIDENCE_VALIDATION_ONLY'
    assert receipt['targeted_regression_tests']==63 and receipt['historical_custody_exit']==2
    assert not receipt['audit_time_changes']
    state=digest(ROOT/'project_state.json');assert state==receipt['live_state_transaction_sha256']
    from audit_a10_cotangent import authenticate
    assert authenticate()['scientific_gate']=='PASS_INACTIVE_ADAPTER_GENERAL_POLYNOMIAL_AND_KINETIC_SCOPE'
    files=[HERE/name for name in FILES]+[ROOT/'docs/A10_COTANGENT_ADAPTER_CURRENT.md']
    files+=sorted(p for p in OUT.glob('*.json') if p.name!='bindings.json')
    assert all(b'\r\n' not in path.read_bytes() for path in files),'NEW_FILES_MUST_USE_LF'
    manifests=[HERE/name/'bindings.json' for name in ('frozen_source_component_decoder',
        'frozen_phase_c_scalar_action','frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation')]
    result={'schema':'A10_COTANGENT_ADAPTER_BYTE_BINDINGS_V1',
        'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'byte_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},
        'inherited_manifest_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in manifests},
        'state_sha256':state,'scientific_disposition':'PASS_INACTIVE_ADAPTER_GENERAL_POLYNOMIAL_AND_KINETIC_SCOPE',
        'authority_changed':False,'candidate_adopted':False,'sources_activated':False,
        'complete_master_action_constructed':False,'Stage_E_reached':False,
        'personal_outreach':False,'remote_push':False,
        'post_validation_finalization':'Receipt export and byte sealing only; no calculation, evidence, contract or result modifications after read-only validation.'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(files))+' new bound files, four inherited manifests; custody remains exit 2')

if __name__=='__main__':main()
