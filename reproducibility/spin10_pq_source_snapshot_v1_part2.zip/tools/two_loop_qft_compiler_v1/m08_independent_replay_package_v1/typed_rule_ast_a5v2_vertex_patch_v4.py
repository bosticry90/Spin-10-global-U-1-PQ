"""Versioned A5 V2 correction for the heavy ghost-vector derivative rule.

Historical typed-rule files remain immutable.  Consumers must opt in by
calling :func:`apply` after the older D4 patch.  The rule is derived from the
certified A5 V2 functional, not fitted to loop residues.
"""

from __future__ import annotations

from typing import Any


RULE_ID = "A.HH.VH.derivative"


def corrected_rule() -> dict[str, Any]:
    return {
        "rule_id": RULE_ID,
        "ordered_fields": ["Hbar", "H", "VH"],
        "incoming_momentum_convention": "ALL_INCOMING",
        "terms": [{
            "label": "derivative_on_complete_product_V_times_u",
            "coefficient_factors": [{
                "op": "parameter", "name": "g10", "power": 1
            }],
            "lorentz_factors": [
                {"op": "momentum", "leg": 1, "lorentz_leg": 2},
                {"op": "momentum", "leg": 2, "lorentz_leg": 2},
            ],
            "group_factors": [{
                "op": "structure_constant",
                "indices": [0, 1, 2],
                "dummy_domains": {},
            }],
        }],
        "grassmann_leg_order": [0, 1],
        "identical_leg_symmetry": "NONE",
        "action_term_provenance": (
            "-ubar_i*partial_mu(g10*f[i,k,j]*V_k^mu*u_j); "
            "-f[i,k,j]=+f[i,j,k]"
        ),
        "derived_without_display_string_parser": True,
        "historical_facade_status": "SUPERSEDED_BY_A5_V2_FUNCTIONAL",
    }


def apply(module: Any) -> None:
    base = module.vertex_rules

    def patched() -> dict[str, Any]:
        rules = base()
        rules[RULE_ID] = corrected_rule()
        return rules

    module.vertex_rules = patched
