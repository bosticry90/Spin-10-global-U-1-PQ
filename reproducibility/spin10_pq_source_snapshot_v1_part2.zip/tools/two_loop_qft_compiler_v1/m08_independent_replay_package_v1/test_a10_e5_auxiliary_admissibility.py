"""Meaningful doublet projection, canonical and preservation controls."""
import unittest
from audit_a10_e5_auxiliary_admissibility import *


class AdmissibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.p,cls.n=evidence()
    def test_complete_91125_domain(self):self.assertTrue(self.c['all91125_slots_compared']);self.assertEqual(self.a['image']['all_full_auxiliary_target_slots'],91125)
    def test_complete_heavy_ghost_projection(self):self.assertEqual(self.a['image']['projected_target_slots'],66825)
    def test_all32670_distinct_pivots(self):self.assertEqual(len({tuple(v[:3]) for v in self.a['image']['all32670_signed_image_columns']}),32670)
    def test_rank_and_cokernel_count(self):self.assertEqual(self.a['image']['image_rank']+self.a['image']['symmetric_complement_rank'],66825)
    def test_complete_carrier_types(self):self.assertEqual(self.a['type_census']['only_auxiliary_cubic_carrier_types'],[['C','a','a'],['L','a']])
    def test_all643_Q_fields_screened(self):self.assertTrue(self.a['literal_Q_columns']['all643_field_columns_screened'])
    def test_all45_doublets(self):self.assertTrue(self.a['literal_Q_columns']['all45_Qa0_minus_auxiliary'])
    def test_connection_only_H_ghost(self):self.assertTrue(self.a['literal_Q_columns']['Qa1_and_QAux1_ghosts_only_H'])
    def test_full_generic_Q_not_just_projector(self):self.assertTrue(self.a['literal_Q_columns']['higher_quartet_and_coupling_descendants_retained_in_full_columns'])
    def test_wrong_doublet_sign_detected(self):self.assertTrue(self.a['controls']['wrong_doublet_sign_residual'])
    def test_symmetric_offdiagonal_is_not_hidden(self):self.assertTrue(self.a['controls']['symmetric_offdiagonal_target']);self.assertFalse(self.a['controls']['symmetric_target_homotopy'])
    def test_source_dependent_scope_not_refuted(self):self.assertTrue(self.a['controls']['source_dependent_diagonal_scope_counterexample']);self.assertFalse(self.a['controls']['source_dependent_repair_excluded_by_theorem'])
    def test_real_ghost_charts_block_diagonal(self):self.assertTrue(self.a['controls']['H_M_ghost_chart_block_diagonal'])
    def test_wrong_primal_pairing_detected(self):self.assertTrue(self.a['controls']['wrong_primal_evaluation_pairing_residual'])
    def test_full_residual_antisymmetry(self):self.assertFalse(self.c['complete_physical_symmetric_slots']);self.assertEqual(len(self.c['complete_physical_residual_slots']),888)
    def test_both_width_monomials_retained(self):self.assertEqual(self.c['raw_antisymmetric_order_counts'],{'(1, 1)':276,'(2, 0)':256})
    def test_exact_zero_half_control(self):self.assertEqual(s.Rational(1,2)*(0-0),s.Integer(0));self.assertIsInstance((0-0)/2,float)
    def test_complete_image_routes_agree(self):self.assertTrue(self.n['complete_image_methods_agree'])
    def test_all_cubic_repaired(self):self.assertTrue(self.n['full_next_auxiliary_match_all91125'])
    def test_complete_predicted_quartet_not_omitted(self):self.assertEqual(len(self.p['physical_g3_quartet_prediction_slots']),3960);self.assertTrue(self.n['quartet_omission_full_Q_residual'])
    def test_real_quartet_coefficients(self):self.assertTrue(all(not parse(c).has(s.Float) and s.simplify(parse(c)-s.conjugate(parse(c)))==0 for i,j,k,l,c in self.p['physical_g3_quartet_prediction_slots']))
    def test_H_ghosts_canceled_after_full_Q(self):self.assertTrue(self.p['all_H_ghost_quartet_coefficients_cancel_after_full_Q'])
    def test_all12_local_H(self):self.assertEqual(len(self.p['all12_local_H']['all12_background_H_identities']),12)
    def test_all1286_generator_inverses(self):self.assertEqual(self.p['both_direction_exact_inverse_checks'],2572);self.assertTrue(self.p['all1286_canonical_generators_checked'])
    def test_all_elementary_pairs(self):self.assertFalse(self.p['all_elementary_pairing_residuals'])
    def test_source_sign_control(self):self.assertTrue(self.p['wrong_source_sign_pairing_residual'])
    def test_first_and_second_jets(self):self.assertEqual(self.p['first_jet_checks'],264);self.assertTrue(self.p['second_jet_omission_residual'])
    def test_fields_fixed_and_sources_external(self):self.assertIn('all643 fields fixed',self.p['integrated_field_Berezinian'])
    def test_no_false_combined_finite_inverse(self):self.assertFalse(self.p['combined_old_flow_exact_finite_inverse_claimed'])
    def test_all980100_old_quartet_slots_preserved(self):self.assertTrue(self.n['previous_quartet_match_all980100_preserved'])
    def test_old_source_kinetic_width_mixing_cubic_preserved(self):self.assertTrue(self.n['previous_source_kinetic_width_mixing_cubic_scopes_preserved'])
    def test_old_regulated_measure_retained(self):self.assertTrue(self.n['old_regulated_joint_measure_retained'])
    def test_wrong_g_degree_and_sign_detected(self):self.assertTrue(self.n['wrong_g_degree_previous_cubic_residual']);self.assertTrue(self.n['wrong_primitive_sign_auxiliary_residual'])
    def test_failed_image_alphabet_attempt_preserved(self):self.assertFalse(read(OUT/'image_failure_disposition_1.json')['counted_as_PASS'])
    def test_no_actual_loop_or_quantum_promotion(self):self.assertFalse(self.n['new_actual_loop_or_derivative_gauge_calculated']);self.assertFalse(self.n['normalization_adopted']);self.assertFalse(self.n['full_E5_or_quantum_A5']);self.assertFalse(self.n['whole_goal_complete'])


if __name__=='__main__':unittest.main()
