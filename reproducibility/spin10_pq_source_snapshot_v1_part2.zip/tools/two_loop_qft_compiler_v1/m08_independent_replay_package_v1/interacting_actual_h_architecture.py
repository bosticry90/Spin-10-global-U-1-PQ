"""Phase A exact candidate pairings; read-only and stdout-only."""
import itertools
import json
from hashlib import sha256
from pathlib import Path
import sympy as s
from source_component_decoder import load, clean, matrix, matrix_record, matrix_digest
from source_domain_transport import source_bridge

HERE = Path(__file__).resolve().parent


def partner_maps():
    rows = load('frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json')['components']
    registry = load('frozen_irrep_carrier_registry/REG7_dual_pairings.json')
    j3 = {tuple(r['left']): matrix(r['matrix']) for r in registry['SU3_pairings']}
    j2 = {r['n']: matrix(r['matrix']) for r in registry['SU2_pairings']}
    basis = load('frozen_c3/C3_representation_basis.json')
    out = []
    for family, key in [('A', 'h_basis'), ('H', 'heavy_basis')]:
        local = [r for r in rows if r['family'] == family]
        order = [r['source_component'] for r in local]
        p = {r['source_component']: s.sqrt(2)*matrix(r['physical_columns']) for r in local}
        a = {r['source_component']: matrix(r['physical_extractor'])/s.sqrt(2) for r in local}
        dp, da = {}, {}
        for r in local:
            cid, partner = r['source_component'], r['target_component']
            label = next(v['source_label'] for v in local if v['source_component'] == partner)
            J = s.kronecker_product(j3[tuple(label[:2])], j2[label[2]]).T
            JJ = s.kronecker_product(s.eye(p[cid].cols//J.cols), J)
            dp[cid], da[cid] = clean(a[partner].T*JJ), clean(JJ.inv()*p[partner].T)
        P = s.ImmutableSparseMatrix(s.Matrix.hstack(*(p[c] for c in order)))
        A = s.ImmutableSparseMatrix(s.Matrix.vstack(*(a[c] for c in order)))
        DP = s.ImmutableSparseMatrix(s.Matrix.hstack(*(dp[c] for c in order)))
        DA = s.ImmutableSparseMatrix(s.Matrix.vstack(*(da[c] for c in order)))
        B = s.ImmutableSparseMatrix(45,len(basis[key]),{(v['index'],j):s.sympify(v['coefficient']) for j,r in enumerate(basis[key]) for v in r['raw_so10_coordinates']})
        G = clean(B.T*B); L = G.inv()*B.T
        F, FL = (B*G.inv(), B.T) if family == 'H' else (B,L)
        T, Ti = clean(FL*DP), clean(DA*F)
        E, Ei = clean(F.T*P), clean(A*FL.T)
        assert clean(T*Ti) == clean(Ti*T) == s.eye(T.rows)
        assert clean(E*Ei) == clean(Ei*E) == s.eye(E.rows)
        assert clean(F*T-DP) == s.zeros(*DP.shape)
        assert clean(FL.T*E-P) == s.zeros(*P.shape)
        assert clean(E.T*T-P.T*DP) == s.zeros(T.rows)
        Cz, Cj, Ctyped = clean(FL*F.conjugate()), clean((FL*F.conjugate()).inv().T), clean(A*P.conjugate())
        assert clean(E*Ctyped-Cj*E.conjugate()) == s.zeros(*E.shape)
        assert clean(T*(DA*DP.conjugate())-Cz*T.conjugate()) == s.zeros(*T.shape)
        for field,source,grade in ([('ubar_H','K_ubar',[2,0,0])] if family=='H' else [('cbar_L','K_cbar',[2,0,0]),('lambda_L','K_lambda',[1,-1,1])]):
            out.append({'field':field,'source':source,'components':int(T.rows),'source_grade':grade,'active':False,
                'candidate_field_frame':'dual_C3' if family=='H' else 'primal_C3', 'typed_field_dual':True,'typed_source_dual':False,
                'address_order':order,'T':matrix_record(T),'T_inverse':matrix_record(Ti),'E':matrix_record(E),'E_inverse':matrix_record(Ei),
                'conjugation_field':matrix_record(Cz),'conjugation_source':matrix_record(Cj),
                'induced_unsigned_bracket':matrix_record(Ti*Ei.T),
                'both_inverses_physical_pairing_conjugation':True,'historical_nonminimal_AST_identified':False})
    return sorted(out,key=lambda r:r['source'])


def build():
    f,ids,G,bridge=source_bridge()
    fullC=matrix(bridge['conjugation']); assert all(not fullC[i,j] for j in ids for i in range(12) if i not in ids)
    C=fullC.extract(ids,ids); assert clean(C*C.conjugate())==s.eye(4)
    basis=load('frozen_c3/C3_representation_basis.json')
    rawpairs=list(itertools.combinations(range(10),2)); matrices=[]
    for i in ids:
        T=s.zeros(10)
        for v in basis['h_basis'][i]['raw_so10_coordinates']:
            a,b=rawpairs[v['index']]; x=s.sympify(v['coefficient'])/s.sqrt(2); T[a,b]+=x; T[b,a]-=x
        matrices.append(T)
    trace=s.Matrix(4,4,lambda a,b:s.simplify(-s.trace(matrices[a]*matrices[b])))
    assert trace==G
    for a,b in itertools.combinations(range(4),2):
        assert clean(matrices[a]*matrices[b]-matrices[b]*matrices[a]-sum((f.get((ids[k],ids[a],ids[b]),0)*matrices[k] for k in range(4)),s.zeros(10)))==s.zeros(10)
    decoder=load('frozen_source_component_decoder/primary.json')
    assert len(decoder['physical_triangles'])==6
    bindings=load('frozen_source_component_decoder/bindings.json')
    # Preserve and authenticate the inherited expected bytes, never refresh them.
    authenticated=[]
    for category,items in bindings.items():
        if not isinstance(items,dict): continue
        for relative,expected in items.items():
            root=HERE.parents[2]; path=root/relative
            actual=sha256(path.read_bytes()).hexdigest(); assert actual==expected, str(path)
            authenticated.append({'path':relative,'sha256':expected})
    assert len(authenticated)==156
    return {'schema':'INTERACTING_ACTUAL_H_ARCHITECTURE_V1','phase_A':'PASS_CANDIDATE_CONTROL_ARCHITECTURE_ONLY',
        'ids':ids,'gram':matrix_record(G),'gram_inverse':matrix_record(G.inv()),'conjugation':matrix_record(C),
        'structure_constants':[[i,a,b,str(f.get((i,a,b),0))] for i,a,b in itertools.product(ids,repeat=3) if f.get((i,a,b),0)],
        'physical_trace_normalization':True,'closed_bracket_Gram_conjugation':True,'prospective_partner_maps':partner_maps(),
        'reused_six_source_maps':decoder['physical_triangles'],'inherited_bindings_authenticated':authenticated,
        'full_M08_qualified':False,'active_sources_added':False,'phase_C_authorized':False,'formal_authority':'34/39_UNCHANGED'}


if __name__=='__main__': print(json.dumps(build(),sort_keys=True,separators=(',',':')))
