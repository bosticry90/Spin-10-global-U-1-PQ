"""Action/component and exterior-polynomial replay; no STC primary imports."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s
from hbp_component_replay import build_replay as obstruction_replay

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE/name).read_text(encoding='utf-8'))


def build_replay():
    old = obstruction_replay()  # Reconstructs from action and physical matrices, not frozen HBP output.
    rep = read('frozen_c3/C3_representation_basis.json'); pairs = list(combinations(range(10),2))
    H=[]
    for row in rep['h_basis']:
        mat=s.zeros(10)
        for entry in row['raw_so10_coordinates']:
            a,b=pairs[entry['index']]; value=s.sympify(entry['coefficient'])/s.sqrt(2)
            mat[a,b]=value; mat[b,a]=-value
        H.append(mat)
    gram=s.Matrix(12,12,lambda a,b:s.simplify(s.trace(H[a].T*H[b])))
    dual=gram.inv()
    f={}
    for a,b in combinations(range(12),2):
        bracket=H[a]*H[b]-H[b]*H[a]
        coordinates=(dual*s.Matrix([s.trace(t.T*bracket) for t in H])).applyfunc(s.simplify)
        f[a,b]=coordinates; f[b,a]=-coordinates
    def coefficient(out,a,b): return 0 if a==b else f[a,b][out]
    # Read source polynomial and differentiate its two ordered c slots FROM THE RIGHT.
    coupling=next(v for v in read('frozen_source_seed_s3_s5/S33_source_couplings.json')['couplings'] if v['source']=='L_c')
    terms=coupling['coupling_AST']['density']['expression']['factors'][1]['terms']
    cc=terms[0]['factors']; action_factor=s.sympify(cc[0]['value'])
    assert action_factor == -s.Rational(1,2)
    # Q L_b = action_factor*(-f^a_bj + f^a_jb) L_a c_j.
    BL=[]
    for b in range(12):
        BL.append({(a,(j,)):s.simplify(action_factor*(-coefficient(a,b,j)+coefficient(a,j,b)))
            for a in range(12) for j in range(12) if coefficient(a,b,j)})
    # Independently recover B c from the two source-coupling terms: Lc is even.
    Bc=[]
    for a in range(12):
        Bc.append({(i,j):s.simplify(2*action_factor*coefficient(a,i,j))
            for i,j in combinations(range(12),2) if coefficient(a,i,j)})
    def wedge(left,right):
        values=left+right
        if len(set(values))!=len(values): return (),0
        inversions=sum(x>y for i,x in enumerate(values) for y in values[i+1:])
        return tuple(sorted(values)),(-1)**inversions
    # Differentiate only the selected output L0. No primary matrix-square formula.
    source_piece={}; ghost_piece={}
    for (a,word),value in BL[0].items():
        j=word[0]
        for (d,odd),factor in BL[a].items():
            ordered,sign=wedge(odd,word)
            if sign:
                key=(d,ordered); source_piece[key]=source_piece.get(key,0)+value*factor*sign
        for odd,factor in Bc[j].items():
            key=(a,odd); ghost_piece[key]=ghost_piece.get(key,0)+value*factor
    selected=(4,(0,4))
    sv=s.simplify(source_piece.get(selected,0)); gv=s.simplify(ghost_piece.get(selected,0))
    square={'ghost_word':[0,4],'output_source_component':0,'remaining_source_component':4,
        'ghost_image_contribution':str(gv),'source_image_contribution':str(sv),'total_over_g10_squared':str(s.simplify(sv+gv))}
    assert square['total_over_g10_squared']=='1'
    # Independent coefficient solve for a hypothetical Cartan partner.
    k=s.Symbol('k'); required=s.solve(s.Eq(-1+k,1),k)
    assert required==[2]
    # Conjugacy: V=U^-1; the vanishing equation implies V U residual=residual=0.
    U,V,D,J,F=s.symbols('U V D J F',commutative=False)
    word=[U,J,V,U,D,V,U,F]
    reduced=[]
    for letter in word:
        if reduced and ((reduced[-1]==V and letter==U) or (reduced[-1]==U and letter==V)): reduced.pop()
        else: reduced.append(letter)
    assert reduced==[U,J,D,F]
    restored=[V]+reduced
    assert restored[:2]==[V,U] and restored[2:]==[J,D,F]
    # Source-free comparator replay: conjugate generator substitutions directly.
    t,rho=s.symbols('t rho'); xi,omega=s.symbols('xi omega',commutative=False)
    Uof=lambda value:s.expand(value.xreplace({xi:xi+t*omega}))
    inverse=lambda value:s.expand(value.xreplace({xi:xi-t*omega}))
    def D_linear(value):
        return s.expand(value).coeff(omega)*rho
    assert Uof(inverse(xi))==xi
    transported_x=Uof(xi)
    transported_xi=Uof(D_linear(inverse(xi)))
    transported_omega=rho
    nilpotence=s.expand(transported_xi+t*transported_omega)
    contraction_x=s.expand((1-t)+t)
    assert transported_xi==-t*rho and nilpotence==0 and contraction_x==1
    result={'status':'PASS_INDEPENDENT_BOUNDED_STC_REPLAY','component':old['component'],
        'Sigma_nonhorizontal_coefficient':old['historical_Sigma_witness']['coefficient_of_g10_Lc4_c4'],
        'source_square_selected':square,'required_partner_Lc_coefficient':[int(v) for v in required],
        'conjugacy_counterexample_cannot_vanish':True,
        'conjugacy_algorithm':'Free-word inverse cancellation plus injectivity; no primary equation imported.',
        'comparator_pass':True,'comparator_transported_xi':str(transported_xi),
        'coefficient_construction':'Physical H matrices and Gram inverse, right derivative of source action, ordered exterior-polynomial graded derivation.',
        'current_source_or_R_image_imported':False,'STC_primary_imported':False,
        'library_runtime_limits':'Shared Python/SymPy, frozen action/frame; algebra/code-path independent, not separate runtime/backend.',
        'code_byte_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
    data=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
    return dict(result,artifact_sha256=sha256(data).hexdigest())
