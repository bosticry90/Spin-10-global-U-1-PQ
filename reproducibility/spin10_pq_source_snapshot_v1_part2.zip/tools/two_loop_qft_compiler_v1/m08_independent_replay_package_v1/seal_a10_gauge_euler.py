"""Seal bounded operation evidence after all read-only checks pass."""
from hashlib import sha256
import json,subprocess
from a10_gauge_euler_common import HERE,ROOT,OUT,read

FILES=('A10_GAUGE_EULER_ADAPTER_CONTRACT_V1.md','A10_GAUGE_EULER_ADAPTER_RESULT.md',
       'A10_GAUGE_EULER_TECHNICAL_REVIEW_PACKET_V1.md','a10_gauge_euler_adapter.py',
       'a10_gauge_euler_common.py','a10_gauge_euler_primary.py','a10_gauge_euler_replay.py',
       'a10_gauge_euler_checks.py','audit_a10_gauge_euler.py','test_a10_gauge_euler.py',
       'run_a10_gauge_euler.py','export_a10_gauge_euler.py','validate_a10_gauge_euler.py',
       'export_a10_gauge_euler_receipt.py','seal_a10_gauge_euler.py')

def hashfile(p):return sha256(p.read_bytes()).hexdigest()

def main():
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['status']=='PASS_BOUNDED_CANONICAL_GAUGE_EULER_ADAPTER_EVIDENCE_ONLY'
    assert receipt['targeted_regression_tests']==92 and receipt['historical_custody_exit']==2
    assert receipt['fresh_new_routes_byte_identical']==3 and not receipt['audit_time_changes']
    state=hashfile(ROOT/'project_state.json');assert state==receipt['live_state_transaction_sha256']
    from audit_a10_gauge_euler import authenticate
    assert authenticate()['scientific_gate']==receipt['scientific_gate']
    files=[HERE/name for name in FILES]+[ROOT/'docs/A10_GAUGE_EULER_ADAPTER_CURRENT.md']
    files+=sorted(p for p in OUT.glob('*.json') if p.name!='bindings.json')
    for p in files:
        raw=p.read_bytes();assert b'\r\n' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),('BAD_LINE_ENDINGS',str(p))
    manifests=[HERE/n/'bindings.json' for n in ('frozen_source_component_decoder','frozen_phase_c_scalar_action',
       'frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation','frozen_a10_cotangent_adapter','frozen_a10_bv_master')]
    result={'schema':'A10_CANONICAL_GAUGE_EULER_BYTE_BINDINGS_V1',
       'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
       'byte_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in files},
       'inherited_manifest_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in manifests},
       'state_sha256':state,'scientific_disposition':receipt['scientific_gate'],
       'authority_changed':False,'candidate_adopted':False,'sources_activated':False,
       'full_master_action_qualified':False,'Stage_D_resumed':False,'Stage_E_reached':False,
       'personal_outreach':False,'remote_push':False,
       'post_validation_finalization':'receipt export and byte sealing only; no scientific edits after validation'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(files))+' files; historical custody remains exit 2',flush=True)
if __name__=='__main__':main()
