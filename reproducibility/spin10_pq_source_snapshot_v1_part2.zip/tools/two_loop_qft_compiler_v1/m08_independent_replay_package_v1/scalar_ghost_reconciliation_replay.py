"""Physical tensor replay: no primary code, SA10 action or primary output."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE/name).read_text(encoding="utf-8"))


def simplify(m):
    return s.SparseMatrix(m).applyfunc(lambda x:s.cancel(s.expand(x)))


def matrix_hash(m):
    rows = [[int(i),int(j),str(s.simplify(v))] for (i,j),v in sorted(m.todok().items())]
    return sha256(json.dumps(rows,separators=(",",":")).encode()).hexdigest()


def tensor_actions(generators):
    data = read("frozen_action_ast_a3/A31_embeddings.json")["sectors"]
    E, G = {}, {}
    for sector,row in data.items():
        E[sector] = s.SparseMatrix(row["ambient_real_dimension"],row["domain_dimension"],
            {(i,j):s.sympify(v) for i,j,v in row["embedding_entries"]})
        G[sector] = s.SparseMatrix(s.diag(*map(s.sympify,row["tensor_metric_diagonal"])))
        assert simplify(E[sector].T*G[sector]*E[sector]) == s.eye(row["domain_dimension"])
    indices = list(combinations(range(10),5)); where = {idx:i for i,idx in enumerate(indices)}
    rho = []
    for h in generators:
        wedge = {}
        for col,idx in enumerate(indices):
            for slot,old in enumerate(idx):
                for new in range(10):
                    value = h[new,old]
                    if not value or new in idx: continue
                    moved = idx[:slot]+(new,)+idx[slot+1:]
                    inversions = sum(x>y for n,x in enumerate(moved) for y in moved[n+1:])
                    key = where[tuple(sorted(moved))],col
                    wedge[key] = wedge.get(key,0)+(-1)**inversions*value
        W = s.SparseMatrix(252,252,wedge)
        ambient = {"Phi":s.kronecker_product(h,s.eye(10))+s.kronecker_product(s.eye(10),h),
            "Sigma":s.diag(W,W), "phi":s.diag(h,h), "S":s.zeros(2)}
        blocks = []
        for sector in ("Phi","Sigma","phi","S"):
            e = E[sector]; L = ambient[sector]
            r = simplify(e.T*G[sector]*L*e)
            assert simplify(L*e-e*r).is_zero_matrix, ("embedding covariance",sector)
            assert simplify(r.T+r).is_zero_matrix, ("kinetic metric",sector)
            blocks.append(r)
        rho.append(s.SparseMatrix(s.diag(*blocks)))
    return rho


def build():
    if not __debug__:
        raise RuntimeError("EXACT_PHYSICAL_REPLAY_REQUIRES_ASSERTIONS_ENABLED")
    rep = read("frozen_c3/C3_representation_basis.json")
    pairs = list(combinations(range(10),2))
    q = s.SparseMatrix(45,45,{(entry["index"],j):s.sympify(entry["coefficient"])
        for j,row in enumerate(rep["h_basis"]+rep["heavy_basis"]) for entry in row["raw_so10_coordinates"]})
    inverse = s.SparseMatrix(q.inv())
    assert q*inverse == s.eye(45)
    generators = []
    for j in range(45):
        h = s.SparseMatrix(10,10,{})
        for (i,_),value in q[:,j].todok().items():
            a,b = pairs[i]; h[a,b]+=value/s.sqrt(2); h[b,a]-=value/s.sqrt(2)
        generators.append(h)
    brackets = {}
    for a,b in combinations(range(45),2):
        comm = generators[a]*generators[b]-generators[b]*generators[a]
        # Action normalization: a coordinate in Eij-Eji equals sqrt(2)
        # times a coordinate in (Eij-Eji)/sqrt(2).
        coordinates = simplify(s.sqrt(2)*inverse*s.Matrix([comm[i,j] for i,j in pairs]))
        coeff = {k:v for (k,_),v in coordinates.todok().items()}
        assert simplify(comm-sum((v*generators[k] for k,v in coeff.items()),s.SparseMatrix(10,10,{}))).is_zero_matrix
        brackets[a,b] = coeff
    rho = tensor_actions(generators)
    sector_counts = {"H_H":0,"H_heavy":0,"heavy_heavy":0}
    for (a,b),coeff in brackets.items():
        comm = rho[a]*rho[b]-rho[b]*rho[a]
        represented = sum((v*rho[k] for k,v in coeff.items()),s.SparseMatrix(328,328,{}))
        # This is the COMPLETE ghost-pair coefficient of the derived square,
        # including both mixed and heavy-heavy curvature contributions.
        assert simplify(represented-comm).is_zero_matrix, (a,b)
        key = "H_H" if b<12 else "H_heavy" if a<12 else "heavy_heavy"
        sector_counts[key] += 1
    assert sector_counts == {"H_H":66,"H_heavy":396,"heavy_heavy":528}
    old = simplify(-2*(rho[0]*rho[4]-rho[4]*rho[0]))
    assert old[0,3] == 1
    # Direct physical symmetric-tensor calculation of the selected pieces.
    row = read("frozen_action_ast_a3/A31_embeddings.json")["sectors"]["Phi"]
    e = s.SparseMatrix(100,54,{(i,j):s.sympify(v) for i,j,v in row["embedding_entries"]})
    x,dual = s.Matrix(10,10,list(e[:,3])),s.Matrix(10,10,list(e[:,0]))
    def act(h,y): return h*y+y*h.T
    ghost = sum((v*act(generators[k],x) for k,v in brackets[0,4].items()),s.zeros(10))
    iteration = -act(generators[0],act(generators[4],x))+act(generators[4],act(generators[0],x))
    pieces = [s.simplify(s.trace(dual.T*z)) for z in (ghost,iteration)]
    assert pieces == [-s.Rational(1,2),s.Rational(1,2)]
    # For local parameters the derivative term alone fixes the sign: with
    # D=partial+g rho(A), delta(D eta) contains (sign+1)g d(omega)eta.
    normalization = read("frozen_normalization_orbit/N1_N4_coupling_normalization.json")
    assert normalization["action_convention"]["covariant_derivative"] == "D_action=d+g10*rho(A_action)"
    return {"schema":"M08_SCALAR_GHOST_PHYSICAL_REPLAY_V1", "derived_scalar_sign":-1,
        "full_parent_generator_count":45, "scalar_coordinates":328,
        "full_parent_scalar_pair_count":990, "pair_sectors":sector_counts,
        "complete_square_residual":"ZERO_EXACT", "all_45_embedding_intertwiners":"ZERO_EXACT",
        "all_45_kinetic_pairing_residuals":"ZERO_EXACT", "H_matrix_hashes":[matrix_hash(m) for m in rho[:12]],
        "selected_candidate_pieces":[str(v) for v in pieces], "selected_candidate_square":"0",
        "selected_historical_square":"1", "selected_physical_tensor_residual":"ZERO_EXACT",
        "route":"10x10 physical commutators, nonorthonormal inverse projection, symmetric/wedge/vector tensor actions and A3 canonical extraction",
        "primary_or_SA10_imported":False, "new_basis_constructed":False,
        "independence":{"algorithm_independent":True,"code_path_independent":True,
            "library_independent":False,"runtime_independent":False,"analyst_blind":False,
            "external_specialist_review":False,
            "limits":"Shared Python/SymPy, C3/A3 physical frame and declared gauge convention; distinct direct tensor route, not independent physics assumptions"}}


if __name__ == "__main__":
    print(json.dumps(build(),sort_keys=True,separators=(",",":")))
