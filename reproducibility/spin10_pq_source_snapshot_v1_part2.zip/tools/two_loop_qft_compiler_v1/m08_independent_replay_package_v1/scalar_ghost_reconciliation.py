"""Inactive convention derivation and finite forward checks; stdout only."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s
from nonminimal_bv_m08_architecture import load, matrix, clean
from rh_composite_primary import ghost_algebra
from source_convention_control import Exterior

HERE = Path(__file__).resolve().parent
DISPOSITION = "BOUNDED_FORWARD_CANDIDATE_NOT_ADOPTED_REQUIRES_SOURCE_AND_SPECIALIST_REVIEW"


def digest_matrix(m):
    rows = [[int(i), int(j), str(s.simplify(v))] for (i, j), v in sorted(m.todok().items())]
    return sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()


def local_convention():
    n = load("frozen_normalization_orbit/N1_N4_coupling_normalization.json")
    assert n["action_convention"]["covariant_derivative"] == "D_action=d+g10*rho(A_action)"
    seed = load("frozen_st_seed/S1_component_transformations.json")
    assert "sigma(Abar+q+V)=d(c+u)+[Abar+q+V,c+u]" in seed["incoming_convention"]
    # Free noncommutative algebra: H=rho(A), W=rho(omega).
    H, W, dW, x, dx = s.symbols("H W dW x dx", commutative=False)
    g, sign = s.symbols("g sign", commutative=True)
    delta_H = dW+g*(H*W-W*H)
    actual = sign*g*(dW*x+W*dx)+g*delta_H*x+sign*g**2*H*W*x
    target = sign*g*W*(dx+g*H*x)
    residual = s.expand(actual-target)
    derived = s.solve(s.Eq(s.expand(residual).coeff(dW*x), 0), sign)
    assert derived == [-1]
    assert s.expand(residual.subs(sign, derived[0])) == 0
    assert s.expand(residual.subs(sign, 1)) != 0
    # The finite identity is proved in the report using d(U^-1).
    return {"D": "partial+g10*rho(A)", "connection": "Q A=partial C+g10[A,C]",
        "derived_scalar_sign": -1, "derivation": "Local covariance fixes the derivative-of-parameter coefficient sign+1=0 before square tests",
        "finite_passive": "eta'=rho(U^-1)eta; A'=U^-1 A U+U^-1 partial(U)/g10; U=exp(g10 omega)",
        "active_dictionary": "theta=-g10 omega; delta eta=rho(theta)eta; delta A=[theta,A]-partial(theta)/g10",
        "candidate": "Q eta=-g10 rho(c_L+u_H)eta; eta=v+phi, Qv=0, Qphi=Qeta",
        "local_covariance_residual": "ZERO_EXACT_FREE_NONCOMMUTATIVE_POLYNOMIAL",
        "old_plus_sign_covariance": "NONZERO; 2*g10*(partial rho(omega)+g10[rho(A),rho(omega)])eta",
        "left_Leibniz": "Q(FG)=Q(F)G+(-1)^parity(F)FQ(G)",
        "ghost": "Q C=-g10[C,C]/2", "sign_fitted_to_square": False}


def H_scalar_checks():
    rho = [matrix(row)/s.sqrt(2) for row in load("frozen_scalar_adapter_v2/SA10_physical_actions.json")["physical_H_parent"]]
    rh = load("frozen_rh_composite_adjudication/RH_primary_closed.json")
    f = {(i, a, b): s.sympify(v)/s.sqrt(2) for i, a, b, v in rh["upper_index_structure_constants_raw"]}
    f.update({(i, b, a): -v for (i, a, b), v in list(f.items())})
    rows = []
    for a, b in combinations(range(12), 2):
        comm = clean(rho[a]*rho[b]-rho[b]*rho[a])
        represented = clean(sum((f.get((k,a,b),0)*rho[k] for k in range(12)), s.SparseMatrix(328,328,{})))
        assert clean(comm-represented).is_zero_matrix
        # Q(-c rho eta) = -(Qc)rho eta+c rho Qeta.
        square = clean(represented-comm)
        assert square.is_zero_matrix
        rows.append({"pair":[a,b], "representation_residual":"ZERO_EXACT", "candidate_square":"ZERO_EXACT"})
    for m in rho:
        assert clean(m.T+m).is_zero_matrix
    old = clean(-2*(rho[0]*rho[4]-rho[4]*rho[0]))
    assert old[0,3] == 1
    return {"generator_count":12, "pair_count":66, "scalar_coordinates":328,
        "complete_pair_matrices":rows, "invariant_pairing":"IDENTITY; rho^T+rho=0 for all 12",
        "historical_selected_square":"1", "candidate_selected_square":"0",
        "candidate_selected_pieces":["-1/2","1/2"],
        "H_matrix_hashes":[digest_matrix(m) for m in rho]}, f


def parent_checks(f):
    rep = load("frozen_c3/C3_representation_basis.json")
    pairs = list(combinations(range(10),2))
    q = s.SparseMatrix(45,45,{(e["index"],j):s.sympify(e["coefficient"])
        for j,row in enumerate(rep["h_basis"]+rep["heavy_basis"]) for e in row["raw_so10_coordinates"]})
    inv = s.SparseMatrix(q.inv())
    assert q*inv == s.eye(45)
    metric = q.T*q
    assert metric != s.eye(45), "NONORTHONORMAL_FRAME_NEGATIVE_CONTROL_REQUIRED"
    generators = []
    for col in range(45):
        m = s.SparseMatrix(10,10,{})
        for (k,_),v in q[:,col].todok().items():
            a,b = pairs[k]; m[a,b] += v/s.sqrt(2); m[b,a] -= v/s.sqrt(2)
        generators.append(m)
    for a,b in combinations(range(45),2):
        represented = sum((f.get((k,a,b),0)*generators[k] for k in range(45)), s.SparseMatrix(10,10,{}))
        assert clean(generators[a]*generators[b]-generators[b]*generators[a]-represented).is_zero_matrix
    raw_f = {k:s.simplify(v*s.sqrt(2)) for k,v in f.items()}
    algebra = ghost_algebra(raw_f)
    assert len(algebra["parent_nilpotence_residuals"]) == 45
    # Explicit complete parent connection square at one arbitrary derivative
    # label. Other Lorentz labels are identical copies, not separately counted.
    e = Exterior()
    c = [e.variable("C"+str(i),1) for i in range(45)]
    dc = [e.variable("dC"+str(i),1) for i in range(45)]
    A = [e.variable("A"+str(i),0) for i in range(45)]
    images = {}
    qc, qdc, qa = [], [], []
    for i in range(45):
        terms = [(a,b,v) for (k,a,b),v in f.items() if k==i]
        qc.append(e.add(*(e.scale(e.mul(c[a],c[b]),-v) for a,b,v in terms if a<b)))
        qdc.append(e.add(*(e.scale(e.mul(dc[a],c[b]),-v) for a,b,v in terms)))
        qa.append(e.add(dc[i],*(e.scale(e.mul(A[a],c[b]),v) for a,b,v in terms)))
        images["C"+str(i)], images["dC"+str(i)], images["A"+str(i)] = qc[-1],qdc[-1],qa[-1]
    for i in range(45):
        assert not e.derive(qc[i],images), ("ghost",i)
        assert not e.derive(qa[i],images), ("connection",i)
    # Heavy antighost/Lambda are evaluation-dual roles, not raw primal copies.
    ad = [s.SparseMatrix(33,33,{(i-12,j-12):v for (i,a,j),v in f.items() if a==alpha and i>=12 and j>=12}) for alpha in range(12)]
    D = [m.T for m in ad]
    for a,b in combinations(range(12),2):
        residual = D[a]*D[b]-D[b]*D[a]+sum((f.get((k,a,b),0)*D[k] for k in range(12)),s.SparseMatrix(33,33,{}))
        assert clean(residual).is_zero_matrix
    # Lie matrices on coordinate fields are an anti-representation; their
    # derivations have the required positive Lie closure. These identities,
    # Qc=gR-g[c,c]/2 and QR=-g[c,R], imply both nonminimal squares exactly.
    return {"parent_matrix_pair_count":990, "parent_matrix_dimension":10,
        "parent_ghost_square_count":45, "parent_connection_square_count":45,
        "complete_ghosts_retained":45, "ordinary_derivative_commutes_with_Q":True,
        "composite_R":"DERIVED; Q R=-g10[c_L,R]_H; no heavy-cubic residual",
        "heavy_dual_pair_count":66, "heavy_dual_dimension":33,
        "nonminimal_factorized_identity":"[D_a,D_b]=-C^k_ab D_k, D_a=ad_a^T",
        "nonminimal_candidate":"Q ubar=-Lambda+g10 D(c)ubar; Q Lambda=g10 D(c)Lambda+g10^2 D(R)ubar",
        "nonminimal_square_scope":"Algebraic consequence of the complete H anti-representation, ghost and R identities; not a reconstructed source operation",
        "light_doublet":"Q cbar=-lambda; Q lambda=0; both squares identically zero",
        "background":"Q Abar=0; Q(Abar+q+V)=D_total C; fixed-background split introduces no square residual",
        "nonorthonormal_metric_used":True, "primal_dual_round_trip":"Q^-1 Q=I; dual map Q^-T",
        "scalar_parent_coverage":"Tensor-functor extension established independently by replay; primary explicitly checks H 66x328 and parent 990x10",
        "kinetic_pairing_and_potential":"See report: tensor invariant identities, not a new loop or full scalar-potential recomputation"}


def potential_contraction_checks():
    potential = load("frozen_action_ast_a3/A38_parent_potential_ASTs.json")
    ranks = {"Phi":2,"Sigma":5,"SigmaBar":5,"phi":1,"phiBar":1,"S":0,"SBar":0}
    directions = []
    for name,row in sorted(potential["directions"].items()):
        contraction = row["density"]
        assert contraction["node"] == "GroupContraction"
        product = contraction["argument"]
        assert product["node"] == "OrderedProduct"
        indices = []
        for factor in product["factors"]:
            if factor["node"] == "ExactScalar": continue
            assert factor["node"] == "Field" and factor["parity"] == 0
            assert len(factor["indices"]) == ranks[factor["name"]]
            indices += factor["indices"]
        assert set(indices) == set(contraction["summed_indices"])
        assert all(indices.count(i)==2 for i in set(indices))
        # On every contracted vector slot, the two variations give h^T+h=0.
        # Products of these invariant delta pairings are invariant; singlets
        # have no slots. Hermitian conjugates obey the same real-compact
        # identity, then extend complex-linearly to the certified root frame.
        directions.append({"direction":name,"tensor_slot_pair_count":len(indices)//2,
            "residual":"ZERO_EXACT_BY_PAIRWISE_ANTISYMMETRIC_TENSOR_ACTION"})
    assert len(directions)==29
    return {"AST_direction_count":29,"real_direction_count":potential["real_direction_count"],
        "complex_direction_count":potential["complex_direction_count"],"complete_contraction_scan":directions,
        "new_potential_or_loop_reconstruction":False,
        "proof":"Each summed vector index occurs exactly twice; h^T+h=0 cancels its two tensor-slot variations. The candidate overall sign preserves this zero. Hermitian conjugates follow in the real compact frame.",
        "ceiling":"Exact invariant-contraction check, not a new component expansion, scalar one-loop closure calculation, stability or phenomenology result"}


def build(stage=None):
    if not __debug__:
        raise RuntimeError("EXACT_RECONCILIATION_REQUIRES_ASSERTIONS_ENABLED")
    def run(name,fn): return stage(name,fn) if stage else fn()
    convention = run("local_convention_derivation",local_convention)
    scalar, f = run("complete_H_scalar_pair_checks",H_scalar_checks)
    parent = run("parent_ghost_connection_and_dual_checks",lambda:parent_checks(f))
    potential = run("parent_potential_invariant_contraction_checks",potential_contraction_checks)
    return {"schema":"M08_SCALAR_GHOST_RECONCILIATION_V1", "disposition":DISPOSITION,
        "convention":convention, "scalar":scalar, "parent":parent,
        "potential":potential,
        "candidate_changed_forward_role":"phi (both light and heavy scalar terms)",
        "source_impacts_unqualified":["K_phi coupling", "all source Euler images depending on scalar/source pairing", "composite and shifted-VEV gauge-fixing consistency", "full master/ST relation", "H-basic structural/domain preservation", "catalog-to-new-differential descent"],
        "active_rules_changed":False, "full_M08_replacement_promoted":False,
        "HB1_C5_authorized":False, "new_source_or_catalog":False, "EOM_or_IBP_used":False,
        "external_specialist_review":False, "formal_authority":"34/39_UNCHANGED", "finite_C1_GS":None}


if __name__ == "__main__":
    print(json.dumps(build(),sort_keys=True,separators=(",",":")))
