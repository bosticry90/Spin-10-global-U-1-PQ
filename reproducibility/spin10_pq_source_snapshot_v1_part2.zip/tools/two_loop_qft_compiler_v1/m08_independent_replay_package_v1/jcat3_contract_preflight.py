"""Pure, bounded contract inspection; no catalog construction or file writes."""
from hashlib import sha256
from itertools import product
import json
from math import factorial
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'frozen_jcat3_contract_preflight'
INCOMING = 'M08_JCAT3_JCAT12_JOINT_PERMUTATION_LORENTZ_IBP_CATALOG_PENDING'
BLOCKER = 'M08_JCAT3_C5_1_LORENTZ_TENSOR_ADMISSIBILITY_UNDERSPECIFIED'
WITNESS = 'SIG_59a19fc845dd9731c0a1'
INPUTS = (
    'frozen_rh_composite_adjudication/INT9_INT15_checkpoint.json',
    'frozen_rh_composite_adjudication/M08_JCAT2_BOUNDED_RESIDUAL_H_INTERTWINER_CHANNEL_BASIS_V1.json',
    'frozen_rh_composite_adjudication/M08_R_H_COMPOSITE_ACTION_CONVENTION_V2.json',
    'frozen_rh_composite_adjudication/INT15_94_binary_factor_qualification.json',
    'frozen_rh_composite_adjudication/INT15_complete_materializer_audit.json',
    'frozen_catalog_cat0_cat4/CAT1_module_actions.json',
    'frozen_catalog_cat0_cat4/CAT4_signature_ledger.json',
    'frozen_catalog_cat0_cat4/CAT5_minimal_joint_catalog_amendment.json',
    'frozen_joint_catalog_jcat0_jcat2/JCAT1_signature_stabilizers.json',
    'frozen_jcat2_v2_projected/JCAT2_ORDERED_HPQ_MULTIPLICITIES_V2.json',
    'frozen_c5_c6/C51_local_functional_contract.json',
    'frozen_c5_c6/C52_minimal_bounded_catalog_amendment.json',
    'frozen_c5/C5_alphabet.json',
    'frozen_action_ast/A1_ast_schema.json',
    'frozen_action_ast/A2_derivative_semantics.json',
    'frozen_ast_differential_l1_l6/L1_L4_differential_contract.json',
    'frozen_source_seed_s3_s5/S32_graded_source_convention.json',
    'frozen_intertwiner_basis_int4r_int15/INT5_canonical_fusion_tree_contract.json',
    'frozen_intertwiner_basis_int4r_int15/INT6_ordered_invariant_channel_families.json',
    'frozen_intertwiner_basis_int4r_int15/INT6B_JCAT2V2_binding_audit.json',
    'frozen_intertwiner_channel_basis/INT3_binary_channel_ledger.json',
    'frozen_intertwiner_channel_basis/INT3_SU3_binary_intertwiners.json',
    'frozen_intertwiner_channel_basis/INT3_SU2_binary_intertwiners.json',
    'frozen_irrep_carrier_registry/REG5_REG6_carrier_registry.json',
    'frozen_irrep_carrier_registry/REG7_dual_pairings.json',
    'frozen_scalar_dual_bridge_v2/DUAL2_DUAL4_exact_maps.json',
    'frozen_scalar_adapter_v2/SA9_scalar_role_adapter_V2.json',
    'frozen_scalar_bridge_v3/M08_INT7_SCALAR_PHYSICAL_ROLE_ADAPTER_V2.json',
    'frozen_scalar_bridge_v3/M08_INT7_SCALAR_COVECTOR_DECOMPOSITION_CONVENTION_V2.json',
    'frozen_scalar_bridge_v3/M08_A3_SCALAR_AST_TO_FACTORIZED_CHANNEL_LOWERING_V1.json',
    'frozen_int8_block_conjugation_v2/M08_INT8_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2.json',
    'frozen_int8_block_conjugation_v2/INT8V2_factorized_family_coverage.json',
    'frozen_int8_block_conjugation_v2/INT8V2_binary_terminal_maps.json',
    'frozen_int8_block_conjugation_v2/INT8V2_carrier_maps.json',
    'frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json',
    'frozen_c3/C3_derivative_basis.json',
)
AUTHORITY = {
    'scientific_progress': '34/39', 'UVP_M08': 'BLOCKED attempt 1',
    'M08_attempt_2_authorized': False, 'E': 'NOT_EXECUTED',
    'Layer6_authorized': False, 'finite_C1_GS': None,
}


def canonical(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def byte_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    obj = json.loads(path.read_text(encoding='utf-8'))
    if 'artifact_sha256' in obj:
        assert obj['artifact_sha256'] == canonical({k: v for k, v in obj.items() if k != 'artifact_sha256'}), path
    return obj


def inputs():
    guard = __import__('sitecustomize')
    assert hasattr(guard, 'DENIED'), 'POLE_BLIND_GUARD_REQUIRED'
    assert not any({p.casefold() for p in Path(name).parts} & guard.DENIED for name in INPUTS)
    return {name: load(HERE / name) for name in INPUTS}


def conditional_tensor_probe():
    """Four-dimensional diagnostic only; no selected Lorentz catalog policy."""
    eta = (-1, 1, 1, 1)

    def metric(i, j):
        return eta[i] if i == j else 0

    def alternating(indices):
        if len(set(indices)) != 4:
            return 0
        inversions = sum(indices[i] > indices[j] for i in range(4) for j in range(i + 1, 4))
        return (-1) ** inversions

    tuples = list(product(range(4), repeat=4))
    values = [[metric(a, b) * metric(c, d), metric(a, c) * metric(b, d),
               metric(a, d) * metric(b, c), alternating((a, b, c, d))]
              for a, b, c, d in tuples]
    selected = [(0, 0, 1, 1), (0, 1, 0, 1), (0, 1, 1, 0), (0, 1, 2, 3)]
    pivot = [values[tuples.index(row)] for row in selected]
    assert pivot == [[-1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]]
    # Orientation reversal in the first coordinate preserves all metric
    # pairings and negates the alternating four-form at every component.
    reflection_residual = []
    for indices, row in zip(tuples, values):
        phase = (-1) ** indices.count(0)
        reflection_residual.extend([phase * row[j] - row[j] for j in range(3)])
        reflection_residual.append(phase * row[3] + row[3])
    assert not any(reflection_residual)
    return {
        'status': 'PASS_CONDITIONAL_ADMISSIBILITY_DIAGNOSTIC_NOT_A_JET_CATALOG',
        'signature_id': WITNESS, 'conditional_spacetime_dimension': 4,
        'conditional_metric': [-1, 1, 1, 1], 'conditional_epsilon_0123': 1,
        'structures': ['eta_01_eta_23', 'eta_02_eta_13', 'eta_03_eta_12', 'epsilon_0123'],
        'component_tuples': [list(row) for row in tuples], 'component_values': values,
        'pivot_tuples': [list(row) for row in selected], 'pivot_matrix': pivot,
        'pivot_determinant': -1, 'metric_only_rank': 3, 'metric_plus_epsilon_rank': 4,
        'reflection_metric_residual': 'ZERO_EXACT', 'reflection_epsilon_odd_residual': 'ZERO_EXACT',
        'final_statistics_count': None, 'IBP_quotient_constructed': False,
        'no_choice_adopted': True,
    }


def generate():
    data = inputs()
    incoming = data[INPUTS[0]]
    basis = data[INPUTS[1]]
    assert incoming['status'] == 'PASS_ORDERED_INTERNAL_BASIS_STOPPED'
    assert incoming['current_blocker'] == INCOMING and incoming['ordered_basis_promoted']
    assert incoming['INT7R'] == 'PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR'
    assert incoming['INT8'] == 'PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2'
    assert basis['status'] == 'PROMOTED_BOUNDED_ORDERED_INTERNAL_BASIS'
    assert basis['families'] == 74 and basis['signatures'] == 431
    assert data[INPUTS[3]]['status'] == 'PASS_ALL_94_EXACT_FACTORS'
    cat4 = data['frozen_catalog_cat0_cat4/CAT4_signature_ledger.json']
    stabilizers = data['frozen_joint_catalog_jcat0_jcat2/JCAT1_signature_stabilizers.json']
    v2 = data['frozen_jcat2_v2_projected/JCAT2_ORDERED_HPQ_MULTIPLICITIES_V2.json']
    contract = data['frozen_c5_c6/C51_local_functional_contract.json']
    modules = data['frozen_catalog_cat0_cat4/CAT1_module_actions.json']
    module_by_name = {row['identity']: row for row in modules['modules']}
    by_signature = {row['signature_id']: row for row in stabilizers['stabilizers']}
    by_v2 = {row['signature_id']: row for row in v2['rows']}
    descriptors = data['frozen_intertwiner_basis_int4r_int15/INT6_ordered_invariant_channel_families.json']['family_descriptors']
    by_family = {tuple(row['ordered_character_families']): row for row in descriptors}
    conjugation = data['frozen_int8_block_conjugation_v2/INT8V2_factorized_family_coverage.json']
    conjugation_by_id = {row['family_id']: row for row in conjugation['families']}
    assert cat4['signature_count'] == stabilizers['signature_count'] == v2['signature_count'] == 431
    ids = {row['signature_id'] for row in cat4['signatures']}
    assert len(ids) == 431 and ids == set(by_signature) == set(by_v2)
    assert contract['canonical_dimension_upper_bound'] == 4
    assert contract['ghost_number_sectors'] == [-1, 0, 1]
    assert contract['EOM_policy'] == 'NOT_QUOTIENTED_DURING_RAW_GENERATION'
    a2 = data['frozen_action_ast/A2_derivative_semantics.json']
    assert a2['IBP_boundary_convention'] == 'drop_exact_total_derivatives_of_local_densities'
    # Do not infer an operator-completeness restriction from A1's action schema.
    missing_keys = ['spacetime_dimension', 'Lorentz_group', 'Lorentz_invariant_tensor_set',
                    'epsilon_policy', 'spacetime_parity_policy']
    assert all(key not in contract for key in missing_keys), 'REVIEW_NEW_EXPLICIT_CONTRACT_BEFORE_REUSING_GAP'
    ledger = []
    for signature in cat4['signatures']:
        sid = signature['signature_id']; names = signature['ordered_symbol_names']
        slots = by_signature[sid]['canonical_slots']
        assert [row['species'] for row in slots] == names == by_v2[sid]['ordered_symbol_names']
        order = 1
        for count in signature['multiplicities'].values():
            order *= factorial(count)
        assert order == by_signature[sid]['P_signature_order']
        assert signature['maximum_derivative_degree'] == 4 - signature['base_canonical_dimension']
        expected_dimension = by_v2[sid]['ordered_HxPQ_invariant_dimension']
        family = by_family[tuple(by_v2[sid]['ordered_character_families'])]
        assert family['addressable_invariant_count'] == expected_dimension
        assert conjugation_by_id[family['family_id']]['addressable_count'] == expected_dimension
        ledger.append({
            'signature_id': sid, 'ordered_symbol_names': names,
            'P_sig': by_signature[sid]['P_signature'], 'P_sig_order': order,
            'stabilizer_factors': by_signature[sid]['factors'], 'canonical_slots': slots,
            'G_sig': {'family_id': family['family_id'], 'ordered_dimension': expected_dimension,
                      'conjugation_authority': 'M08_INT8_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2'},
            'field_types': [{'species': name, 'parity': module_by_name[name]['Grassmann_parity'],
                             'Lorentz_type': module_by_name[name]['Lorentz_type']} for name in names],
            'degree_bounds': {'base_dimension': signature['base_canonical_dimension'],
                              'maximum_derivative_degree': signature['maximum_derivative_degree'],
                              'feasible_derivative_degrees': signature['Lorentz_scalar_feasible_derivative_degrees'],
                              'ghost_number': signature['ghost_number']},
            'statistics_character': by_signature[sid]['total_statistics_character'],
            'L_raw_sig': 'NOT_CONSTRUCTED_CONTRACT_BLOCKED', 'R_IBP': 'NOT_CONSTRUCTED',
            'L_quotient_sig': 'NOT_CONSTRUCTED', 'statistics_projected': False,
        })
    witness = next(row for row in ledger if row['signature_id'] == WITNESS)
    assert witness['G_sig']['ordered_dimension'] == 71
    assert witness['ordered_symbol_names'] == ['V_H_mu', 'V_H_mu', 'q_L_mu', 'q_L_mu']
    custody = {
        'status': 'PASS_IMMUTABLE_INPUT_BINDING_431_SIGNATURES',
        'incoming_commits': ['6d9175f', 'fc2a063'], 'incoming_checkpoint': incoming['artifact_sha256'],
        'input_byte_hashes': {name: byte_hash(HERE / name) for name in INPUTS},
        'input_artifact_hashes': {name: obj.get('artifact_sha256') for name, obj in data.items()},
        'promoted_internal_bindings': basis['bindings'], 'upstream_authorities_modified': False,
        'denied_roots': sorted(__import__('sitecustomize').DENIED),
        'forbidden_payload_read': False, 'formal_authority': AUTHORITY,
    }
    gap = {
        'status': 'BLOCKED_CONTRACT_UNDERSPECIFIED_NOT_SCIENTIFIC_CALCULATION_FAIL',
        'blocker': BLOCKER, 'gate': 'JCAT3_CONTRACT_SUFFICIENCY',
        'contract_artifact_sha256': contract['artifact_sha256'],
        'exact_available_Lorentz_condition': contract['Lorentz_condition'],
        'missing_explicit_fields': missing_keys,
        'fatal_choice': 'Admit_or_exclude_oriented_four_index_Lorentz_epsilon',
        'A1_has_metric_node': 'LorentzContraction' in data['frozen_action_ast/A1_ast_schema.json']['node_types'],
        'A1_catalog_epsilon_disposition': 'NOT_SPECIFIED_ACTION_SCHEMA_NOT_A_COMPLETENESS_EXCLUSION',
        'conditional_witness_signature': WITNESS, 'internal_dimension': 71,
        'conditional_four_dimensional_metric_rank': 3,
        'conditional_four_dimensional_metric_plus_epsilon_rank': 4,
        'ambiguity_is_resolved_by_C3_one_derivative_IBP': False,
        'resolved_requirements': {'dimension_upper_bound': 4, 'ghost_sectors': [-1, 0, 1],
            'derivative_budgets': 'FROZEN_CAT4_ALL_431', 'IBP': a2['IBP_boundary_convention'],
            'EOM': 'DEFERRED_NO_EOM_QUOTIENT_HERE',
            'background_connection': contract['background_condition']},
        'needed_amendment': 'Explicit_bounded_spacetime_and_metric_epsilon_parity_contract_with_background_covariance_disposition',
        'choice_selected': None, 'internal_basis_failure': False,
    }
    checkpoint = {
        'package_id': 'M08_INDEPENDENT_REPLAY_PACKAGE_V1', 'status': 'BLOCKED_CONTRACT',
        'current_blocker': BLOCKER, 'incoming_blocker': INCOMING,
        'incoming_checkpoint_sha256': incoming['artifact_sha256'],
        'INT7R': incoming['INT7R'], 'INT8': incoming['INT8'],
        'ordered_basis_promoted': True, 'joint_catalog_promoted': False,
        'formal_authority': AUTHORITY, 'preserved_authority_links': incoming['preserved_authority_links'],
        'DISTANCE_TO_C1_GS': 'ONE_GATE_REMOVED',
        'distance_metadata_authority': 'PROJECT_MANAGEMENT_ONLY_NOT_PHYSICAL_PROGRESS',
        'stages': {'JCAT3_custody': 'PASS_431_SIGNATURES',
                   'JCAT3_contract': 'BLOCKED_LORENTZ_TENSOR_ADMISSIBILITY'},
        'not_executed': ['JCAT4', 'JCAT4R', 'JCAT5', 'JCAT6', 'JCAT7', 'JCAT8', 'JCAT9',
                        'JCAT9R', 'JCAT10', 'JCAT11', 'JCAT11R', 'JCAT12', 'C5', 'C6', 'D6',
                        'E', 'M08_attempt_2', 'M09_M13', 'Layer6', 'C1_GS'],
        'forbidden_payload_read': False,
    }
    return {'JCAT3_input_custody.json': custody,
            'JCAT3_signature_contract_ledger.json': {'signature_count': 431, 'rows': ledger},
            'JCAT3_contract_gap.json': gap, 'JCAT3_conditional_Lorentz_witness.json': conditional_tensor_probe(),
            'JCAT3_checkpoint.json': checkpoint}
