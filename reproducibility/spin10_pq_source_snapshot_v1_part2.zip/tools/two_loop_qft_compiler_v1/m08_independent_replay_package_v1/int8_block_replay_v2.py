"""Independent bounded physical-column/pivot replay; never imports primary B.

Serialized INT3/REG7/qualified D and physical columns are shared inputs.
Conjugation is reconstructed by a physical-column Gram solve, then a sparse
full-covector pivot solve. Algorithm/code-path independence only (SymPy/Python).
"""
from itertools import product
import sympy as sp
import execute_scalar_ast_channel_bridge as br


def clean(m):
    return sp.SparseMatrix(m).applyfunc(sp.simplify)


def serialize(m):
    result=br.serialize(m)
    # Kronecker-generated sparse indices can be SymPy Integers, not Python ints.
    return {'shape':[int(v) for v in result['shape']],
            'entries':[[int(i),int(j),v] for i,j,v in result['entries']]}


def physical_columns(catalog, cid):
    # Replay coverage is scalar-only; raw certified columns, not primary W/K/B.
    rows=br.load(br.HERE/'frozen_scalar_adapter_v2/SA2_SA8_copy_certificates.json')['copies']
    return sp.SparseMatrix(sp.Matrix.hstack(*(br.matrix(r['P_registry']) for r in rows if r['component_id']==cid)))


def selector(catalog, cid, copy):
    r=catalog.by_id[cid]; p,q,n,_=r['H_label']
    d=(p+1)*(q+1)*(p+q+2)//2*(n+1)
    return sp.SparseMatrix(d,d*r['copy_multiplicity'],{(i,copy*d+i):1 for i in range(d)})


def covector(catalog, address):
    desc,key,slots,copies,b,r,a,bb=catalog.address_parts(address)
    if len(slots)==1:
        return selector(catalog,slots[0],copies[0])
    left=tuple(b['left_H_label']); right=tuple(b['right_H_label']); out=tuple(b['output_H_label'])
    _,d=catalog.duals.channel_objects(left,right,out,a)
    dl=sp.SparseMatrix(d)*sp.kronecker_product(selector(catalog,slots[0],copies[0]),selector(catalog,slots[1],copies[1]))
    if len(slots)==2:
        return dl
    j=catalog.duals.pairing(out).T
    if len(slots)==3:
        return clean(dl.T*j*selector(catalog,slots[2],copies[2]))
    _,dr=catalog.duals.channel_objects(tuple(r['left_H_label']),tuple(r['right_H_label']),tuple(r['output_H_label']),bb)
    dr=sp.SparseMatrix(dr)*sp.kronecker_product(selector(catalog,slots[2],copies[2]),selector(catalog,slots[3],copies[3]))
    return clean(dl.T*j*dr)


def replay(catalog, cases):
    assert not catalog.w and not catalog.l3 and not catalog.l2, 'PRIMARY_CONJUGATION_MAPS_PRESENT_IN_REPLAY_CATALOG'
    records=[]; cached={}
    for case in cases:
        fid=case['family_id']; key=tuple(case['source_key']); targetkey=tuple(case['target_key'])
        source=list(catalog.addresses(fid,key)); target=list(catalog.addresses(fid,targetkey))
        slots=catalog.block_slots(catalog.descriptors[fid],key)
        ks=[]
        for cid in slots:
            if cid not in cached:
                p=physical_columns(catalog,cid); pt=physical_columns(catalog,catalog.partner[cid])
                pc=sp.conjugate(p)
                k=clean((pc.H*pc).inv()*pc.H*pt)
                assert clean(pc*k-pt)==sp.zeros(*pt.shape)
                cached[cid]=k
            ks.append(cached[cid])
        fs=[covector(catalog,a) for a in source]; ft=[covector(catalog,a) for a in target]
        transformed=[]
        for f in fs:
            if len(slots)==1:
                g=sp.conjugate(f)*ks[0]
            elif len(slots)==2:
                g=sp.conjugate(f)*sp.kronecker_product(*ks)
            elif len(slots)==3:
                g=sp.kronecker_product(*ks[:2]).T*sp.conjugate(f)*ks[2]
            else:
                g=sp.kronecker_product(*ks[:2]).T*sp.conjugate(f)*sp.kronecker_product(*ks[2:])
            transformed.append(clean(g))
        # Sparse flattening, never a dense 328^d tensor or global channel matrix.
        support=sorted(set().union(*(set(f.todok()) for f in ft)))
        chosen=[]; small=sp.zeros(0,len(ft)); rank=0
        for pos in support:
            row=sp.Matrix([[f[pos] for f in ft]])
            trial=small.col_join(row); rr=trial.rank()
            if rr>rank:
                chosen.append(pos); small=trial; rank=rr
            if rank==len(ft): break
        assert rank==len(ft)
        samples=sp.Matrix([[g[pos] for g in transformed] for pos in chosen])
        solution=clean(small.inv()*samples)
        for i,g in enumerate(transformed):
            reconstructed=sum((solution[j,i]*f for j,f in enumerate(ft)),sp.zeros(*g.shape))
            assert clean(reconstructed-g)==sp.zeros(*g.shape), (case['name'],'full reconstruction')
        records.append({'name':case['name'],'family_id':fid,'source_addresses':source,'target_addresses':target,
            'physical_K_from_column_Gram':[serialize(k) for k in ks],
            'pivot_entries':[[int(v) for v in p] for p in chosen],'basis_pivot_matrix':serialize(small),
            'conjugated_pivot_values':serialize(samples),'independently_solved_B':serialize(solution),
            'full_sparse_covector_shape':[int(v) for v in ft[0].shape],'full_covector_residual':'ZERO_EXACT',
            'primary_B_imported':False,'primary_copy_or_binary_conjugation_maps_imported':False,
            'independence':{'algorithm':True,'code_path':'Gram + sparse tensor pivot, versus factor Schur projections',
                'library':False,'runtime':False,'shared':'INT3/REG7/D data, physical columns and address layout'}})
        print('INT8V2_REPLAY',case['name'],rank,'ZERO_EXACT',flush=True)
    return records
