"""Bounded regressions; preserve nonzero failures rather than fit a PASS."""
import unittest
import sympy as s

import source_convention_impact as primary
import source_convention_impact_replay as replay
from m08_local_functional_ast import field, source, mul, scalar, derivative, is_zero


class VariationTests(unittest.TestCase):
    def test_even_target_between_odd_factors(self):
        k, z, c = source("K", parity=1), field("z"), field("c", parity=1)
        self.assertEqual(primary.euler(mul(k, z, c), "z"), mul(k, c))

    def test_odd_target_left_variation(self):
        a, b = field("a", parity=1), field("b", parity=1)
        self.assertEqual(primary.euler(mul(a, b), "b", target_parity=1), mul(scalar(-1), a))

    def test_ordinary_derivative_IBP_sign(self):
        a, b = field("a"), field("b")
        self.assertEqual(primary.euler(mul(a, derivative("mu", b)), "b"), mul(scalar(-1), derivative("mu", a)))

    def test_even_historical_defect_retained(self):
        self.assertTrue(primary.even_variation_control()["opposite_sign"])

    def test_unrelated_derivative_is_zero(self):
        self.assertTrue(is_zero(primary.euler(derivative("mu", field("a")), "b")))

    def test_composite_not_an_independent_variable(self):
        r = primary.expand_R(field("R_H", indices=("alpha",)))
        self.assertFalse(primary.contains(r, "R_H"))
        self.assertTrue(primary.contains(r, "u_H"))

    def test_fresh_composite_dummies(self):
        n = mul(field("R_H", indices=("alpha",)), field("R_H", indices=("beta",)))
        r = primary.expand_R(n)
        self.assertEqual(len([i for i in primary.old._all_index_names(r) if i.startswith("_compositeR")]), 4)


class CompleteCandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = primary.build()
        cls.replay = replay.build()

    def test_all_seventeen_rows_are_materialized(self):
        self.assertEqual(len(self.result["candidate"]["expressions"]), 17)
        self.assertEqual(len(self.result["candidate"]["impact"]), 17)

    def test_reverse_composite_chain_not_omitted(self):
        candidate = self.result["candidate"]
        self.assertTrue(candidate["composite_chain_rule_impact"]["L_u"]["expanded_R_changes_expression"])
        self.assertTrue(primary.contains(candidate["expressions"]["L_u"], "L_c"))
        self.assertFalse(primary.contains(candidate["expressions"]["L_u"], "R_H"))

    def test_scalar_dual_is_not_replaced(self):
        bundle = self.result["candidate"]["scalar_gradient_bundle"]
        self.assertEqual(bundle["coordinate_count"], 328)
        self.assertIn("E_dagger G", bundle["lowering"])
        self.assertTrue(self.result["candidate"]["scalar_impact"]["potential_templates_syntactically_identical"])
        self.assertTrue(self.result["candidate"]["scalar_impact"]["eta_gradient_ordered_tensor_terms_equal"])
        self.assertTrue(self.result["candidate"]["ubar_impact"]["equal_after_dummy_renaming"])

    def test_source_square_failure_is_exact(self):
        self.assertEqual(self.result["preflight"]["Q2_K_Lambda"], [{"odd_word": ["u_second_jet"], "coefficient": "-1"}])
        self.assertEqual(self.replay["selected_coefficients"]["Q2_K_Lambda_box_u"], "-1")

    def test_pairing_square_failure_is_inside_weight_window(self):
        p = self.result["preflight"]
        self.assertEqual(p["pairing_grade"], {"d": 3, "gh": -1, "w": 4})
        self.assertEqual(p["square_grade"], {"d": 5, "gh": 1, "w": 4})
        self.assertEqual(p["Q2_pairing_box_u_coefficient"], "-Lambda")
        self.assertEqual(self.replay["selected_coefficients"]["Q2_pairing_Lambda_box_u"], "-1")

    def test_action_ST_success_is_not_misclassified_as_nilpotence(self):
        self.assertEqual(self.replay["free_action_symmetry"], "EXACT_ZERO")
        self.assertEqual(self.replay["free_integrated_half_master_ST"], "EXACT_ZERO")
        self.assertEqual(self.result["preflight"]["status"], "BLOCKED_EXACT_NONMINIMAL_SOURCE_SQUARE")

    def test_noncanonical_part_is_not_bracket_derivation(self):
        self.assertEqual(self.result["preflight"]["T_antibracket_derivation_residual_ubar_KLambda"], [{"odd_word": [], "coefficient": "1"}])
        self.assertEqual(self.replay["T_antibracket_derivation_residual_ubar_KLambda"], "1")

    def test_physical_singlet_control_and_true_dual(self):
        p = self.replay["physical_control"]
        self.assertTrue(p["all_12_H_commutators_zero"])
        self.assertEqual(p["evaluation_dual_pairing"], "1")
        self.assertEqual(p["raw_bilinear_norm_not_used_as_dual"], "5")

    def test_no_unauthorized_quotient_or_promotion(self):
        p = self.result["preflight"]
        self.assertFalse(p["EOM_used"])
        self.assertFalse(p["new_source_added"])
        self.assertFalse(p["candidate_promoted"])
        self.assertEqual(p["complete_master_Cartan_basic_descent_gates"], "NOT_REACHED_AFTER_FAILED_SOURCE_SQUARE")

    def test_replay_does_not_claim_external_or_backend_review(self):
        p = self.replay["independence"]
        self.assertFalse(p["primary_columns_imported"])
        self.assertFalse(p["library_independent"])
        self.assertFalse(p["runtime_independent"])
        self.assertFalse(p["external_specialist_review"])


if __name__ == "__main__":
    unittest.main()
