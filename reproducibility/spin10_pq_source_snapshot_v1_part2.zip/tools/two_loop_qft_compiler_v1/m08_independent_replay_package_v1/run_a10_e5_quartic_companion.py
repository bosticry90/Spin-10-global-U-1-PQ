"""Read-only actual quartet/elementary routes under immutable start bindings."""
import json,sys,time
from hashlib import sha256
from a10_e5_quartic_companion import HERE,ROOT,OUT,read,build,controls,closed_trace_control,operator_symbol_control,s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==3 and sys.argv[1] in ('controls','trace_controls','trace_controls_v2','operator_controls','primary','primary_v2','primary_v3','replay','replay_v2')
    route='primary' if sys.argv[1] in ('primary_v2','primary_v3') else ('replay' if sys.argv[1]=='replay_v2' else sys.argv[1])
    path=OUT/sys.argv[2]/'preparation.json';frozen=read(path)
    for name,h in frozen['execution_bytes'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,('START_BYTES_CHANGED',name)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==frozen['state_sha256']
    assert sha256((ROOT/frozen['input_manifest']).read_bytes()).hexdigest()==frozen['input_manifest_sha256']
    if route in ('primary','replay'):
        assert frozen['controls_sha256'] is not None,'CONTROLS_MUST_BE_FROZEN_BEFORE_ACTUAL_CALCULATION'
        assert sha256((OUT/'controls.json').read_bytes()).hexdigest()==frozen['controls_sha256']
        assert frozen['trace_controls_sha256'] is not None
        assert sha256((OUT/frozen['trace_controls_path']).read_bytes()).hexdigest()==frozen['trace_controls_sha256']
        assert frozen['operator_controls_sha256'] is not None
        assert sha256((OUT/'operator_controls.json').read_bytes()).hexdigest()==frozen['operator_controls_sha256']
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('QUARTIC_WORKER_WRITE_DENIED')
    sys.addaudithook(hook)
    print('EXECUTION '+json.dumps({'schema':'E5_QUARTIC_START_V1','route':route,'output_artifact':sys.argv[1],
        'preparation':path.relative_to(ROOT).as_posix(),
        'preparation_sha256':sha256(path.read_bytes()).hexdigest(),'implementation_and_contract_sha256':frozen['execution_bytes'],
        'input_manifest_sha256':frozen['input_manifest_sha256'],'state_sha256':frozen['state_sha256'],
        'controls_sha256':frozen['controls_sha256'],'trace_controls_sha256':frozen.get('trace_controls_sha256'),
        'operator_controls_sha256':frozen.get('operator_controls_sha256'),
        'python':sys.version,'executable':sys.executable,'sympy':s.__version__,
        'guard_active':True},sort_keys=True,separators=(',',':')),flush=True)
    stages=[];started=time.perf_counter()
    def stage(name,fn):
        print('STAGE '+name,flush=True);tick=time.perf_counter();value=fn()
        stages.append({'name':name,'seconds':time.perf_counter()-tick});return value
    if route=='controls':result=controls(stage)
    elif route in ('trace_controls','trace_controls_v2'):result=stage('exact_closed_trace_associativity_and_cyclicity',closed_trace_control)
    elif route=='operator_controls':result=stage('independent_Euler_mixed_operator_symbols',operator_symbol_control)
    else:result=build(route,stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'execution_state':'COMPLETED','stages':stages,'seconds':time.perf_counter()-started,
        'write_attempts':writes},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
