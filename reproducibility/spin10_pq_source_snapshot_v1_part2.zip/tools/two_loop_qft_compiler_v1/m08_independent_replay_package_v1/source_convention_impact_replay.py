"""Independent ordered-word and formal-variation replay of the free source test.

Does not import the primary visitor, primary candidate rows or Exterior engine.
Python/SymPy and the frozen action are shared; no backend independence is claimed.
"""
import itertools
import json
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent
ODD = {"bar", "u2", "K", "u1", "KV"}
ORDER = {n: i for i, n in enumerate(("bar", "u2", "K", "u1", "KV", "Lambda", "Lambda1", "divV"))}


def product(*words):
    word = tuple(itertools.chain.from_iterable(words))
    odd = [n for n in word if n in ODD]
    if len(set(odd)) != len(odd):
        return 0, ()
    crossings = sum(ORDER[x] > ORDER[y] for i, x in enumerate(odd) for y in odd[i+1:])
    return (-1)**crossings, tuple(sorted(word, key=ORDER.__getitem__))


def clean(p):
    return {w: v for w, c in p.items() if (v := s.expand(c)) != 0}


def plus(*polys):
    p = {}
    for poly in polys:
        for w, c in poly.items():
            p[w] = p.get(w, 0) + c
    return clean(p)


def scale(poly, c):
    return clean({w: c*v for w, v in poly.items()})


def times(p, q):
    r = {}
    for w, c in p.items():
        for v, d in q.items():
            sign, key = product(w, v)
            r[key] = r.get(key, 0) + sign*c*d
    return clean(r)


def variation(poly, name):
    """Coefficient of a formal variation moved LEFT through the ordered word."""
    result = {}
    for w, c in poly.items():
        for pos, z in enumerate(w):
            if z == name:
                sign = (-1)**((name in ODD) * sum(v in ODD for v in w[:pos]))
                key = w[:pos]+w[pos+1:]
                result[key] = result.get(key, 0)+sign*c
    return clean(result)


def differential(poly, images):
    result = {}
    for w, c in poly.items():
        for pos, z in enumerate(w):
            sign = (-1)**sum(v in ODD for v in w[:pos])
            result = plus(result, scale(times(times({w[:pos]: c}, images.get(z, {})), {w[pos+1:]: 1}), sign))
    return result


def terms(n):
    t = n["node"]
    if t == "Add":
        return [v for child in n["terms"] for v in terms(child)]
    if t == "OrderedProduct":
        accum = [[]]
        for child in n["factors"]:
            accum = [a+b for a in accum for b in terms(child)]
        return accum
    if t in {"GroupContraction", "LorentzContraction", "LocalActionTerm"}:
        key = next(k for k in ("density", "expression", "argument") if k in n)
        return terms(n[key])
    return [[n]]


def local_free_expression():
    payload = json.loads((HERE/"frozen_source_seed_s3_s5/S30_offshell_source_zero_action.json").read_text())
    heavy = next(r["term"] for r in payload["action"]["local_terms"] if r["sector"] == "HEAVY_EQUIVARIANT_GAUGE_FIXING_AND_GHOST_OFFSHELL")
    result = {}
    for row in terms(heavy):
        coefficient, word = s.Integer(1), ()
        for n in row:
            kind = n["node"]
            if kind == "ExactScalar":
                coefficient *= s.sympify(n["value"])
            elif kind == "Parameter":
                coefficient *= 0 if n["name"] == "g10" else s.Symbol(n["name"])
            elif kind == "KroneckerMetric" and n["name"] == "P_m_exact":
                pass
            else:
                orders = []
                while n["node"] == "PartialDerivative":
                    orders.append(n["index"])
                    n = n["argument"]
                key = (n.get("name"), tuple(orders)) if n["node"] == "Field" else None
                label = {("ubar_H", ()): "bar", ("Lambda_H", ()): "Lambda", ("u_H", ("mu", "mu")): "u2", ("V_H", ("mu",)): "divV"}.get(key)
                if label is None:
                    coefficient = 0
                    break
                sign, word = product(word, (label,))
                coefficient *= sign
        result[word] = result.get(word, 0)+coefficient
    return clean(result)


def record(poly):
    return [{"ordered_word": list(w), "coefficient": str(c)} for w, c in sorted(poly.items())]


def build():
    if not __debug__:
        raise RuntimeError("EXACT_REPLAY_REQUIRES_ASSERTIONS_ENABLED")
    S = local_free_expression()
    xi = s.Symbol("xi")
    assert S == {("bar", "u2"): -1, ("Lambda", "divV"): -1, ("Lambda", "Lambda"): xi/2}
    qk = variation(S, "Lambda")
    images = {"K": qk, "divV": {("u2",): 1}, "bar": {("Lambda",): -1}}
    q2k = differential(qk, images)
    F = {("K", "Lambda"): 1}
    q2F = differential(differential(F, images), images)
    assert q2k == {("u2",): -1} and q2F == {("u2", "Lambda"): -1}
    assert differential(S, images) == {}
    # Independent formal variation of an even target, with odd factors on
    # either side, makes no crossing sign. Old indexed helper gives the opposite.
    assert variation({("K", "u1", "Lambda"): 1}, "Lambda") == {("K", "u1"): 1}
    # Independently derive the half-master from its sole free canonical V pair.
    # EL_V S = -d_mu(partial S/partial divV) = +partial_mu Lambda.
    partial_V1 = variation(S, "divV")
    assert partial_V1 == {("Lambda",): -1}
    EL_V = {("Lambda1",): -partial_V1[("Lambda",)]}
    half_canonical = times(EL_V, {("u1",): 1})
    assert half_canonical == {("u1", "Lambda1"): 1}
    # Integral (partial Lambda)(partial u) = -integral Lambda box u.
    half_canonical_IBP = {("u2", "Lambda"): -half_canonical[("u1", "Lambda1")]}
    noncanonical = differential(S, {"bar": {("Lambda",): -1}})
    master = plus(half_canonical_IBP, noncanonical)
    assert master == {}
    rep = json.loads((HERE/"frozen_c3/C3_representation_basis.json").read_text())
    raw_pairs = list(itertools.combinations(range(10), 2))
    def physical(row):
        m = s.zeros(10)
        for v in row["raw_so10_coordinates"]:
            i, j = raw_pairs[v["index"]]
            m[i, j] = s.sympify(v["coefficient"])/s.sqrt(2)
            m[j, i] = -m[i, j]
        return m
    heavy0 = physical(rep["heavy_basis"][0])
    assert all(physical(h)*heavy0-heavy0*physical(h) == s.zeros(10) for h in rep["h_basis"])
    # The split-coordinate inverse, not an unqualified Euclidean transpose,
    # supplies the evaluation dual and the physical heavy projector.
    columns = rep["h_basis"]+rep["heavy_basis"]
    q = s.zeros(45)
    for j, row in enumerate(columns):
        for v in row["raw_so10_coordinates"]:
            q[v["index"], j] = s.sympify(v["coefficient"])
    inverse = q.inv()
    projection = q*s.diag(*([0]*12+[1]*33))*inverse
    v = q[:, 12]
    assert projection*v == v and (inverse*v)[12] == 1
    return {"schema": "M08_SOURCE_CONVENTION_IMPACT_REPLAY_V1", "free_heavy_action": record(S),
            "Q_K_Lambda": record(qk), "Q2_K_Lambda": record(q2k), "Q2_pairing": record(q2F),
            "selected_coefficients": {"Q2_K_Lambda_box_u": "-1", "Q2_pairing_Lambda_box_u": "-1"},
            "T_antibracket_derivation_residual_ubar_KLambda": "1",
            "physical_control": {"heavy_coordinate": 0, "all_12_H_commutators_zero": True,
                                 "heavy_projector_on_selected_coordinate": "IDENTITY", "evaluation_dual_pairing": "1",
                                 "raw_bilinear_norm_not_used_as_dual": str((v.T*v)[0]),
                                 "pairing_KLambda0_Lambda0_is_H_invariant": True},
            "free_action_symmetry": "EXACT_ZERO", "free_integrated_half_master_ST": "EXACT_ZERO",
            "half_master_terms": {"canonical_before_IBP": record(half_canonical),
                                  "canonical_after_IBP": record(half_canonical_IBP), "noncanonical": record(noncanonical)},
            "interpretation": "ST scalar cancellation alone does not prove a differential for a field-dependent noncanonical sector",
            "independence": {"algorithm_independent": True, "code_path_independent": True,
                             "library_independent": False, "runtime_independent": False,
                             "primary_columns_imported": False, "external_specialist_review": False}}


if __name__ == "__main__":
    print(json.dumps(build(), indent=2, sort_keys=True))
