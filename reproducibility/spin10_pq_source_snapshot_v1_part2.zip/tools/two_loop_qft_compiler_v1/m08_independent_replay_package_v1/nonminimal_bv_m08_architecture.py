"""Inactive interacting prerequisite check; stdout only, no M08 mutation."""
from hashlib import sha256
import json
from pathlib import Path
import sympy as s
from source_convention_control import Exterior

HERE = Path(__file__).resolve().parent
BLOCKER = "M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED"


def load(name):
    return json.loads((HERE/name).read_text(encoding="utf-8"))


def matrix(row):
    return s.ImmutableSparseMatrix(*row["shape"],
        {(i, j): s.sympify(v) for i, j, v in row["entries"]})


def clean(value):
    return value.applyfunc(s.simplify)


def build():
    if not __debug__:
        raise RuntimeError("EXACT_CHECK_REQUIRES_ASSERTIONS_ENABLED")
    images = {r["identity"]: r["B_Sigma_image"] for r in
        load("frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json")["images"]}
    # Extract signs and ordering from the actual unchanged expressions.
    scalar_term = images["phi"]["terms"][0]["factors"]
    assert [r.get("name") for r in scalar_term[:3]] == ["g10", "c_L", "rho_H"]
    assert scalar_term[3]["node"] == "Add"
    assert {r["name"] for r in scalar_term[3]["terms"]} == {"eta_328", "v_328"}
    scalar_sign = s.Integer(1)  # No omitted scalar factor: AST coefficient is +1.
    ghost_term = next(t for t in images["c_L"]["terms"]
                      if any(f.get("node") == "StructureConstant" for f in t["factors"]))
    factors = ghost_term["factors"]
    assert [r.get("name") for r in factors[1:]] == ["g10", "f", "c_L", "c_L"]
    ghost_ordered_sign = s.sympify(factors[0]["value"])
    assert ghost_ordered_sign == -s.Rational(1, 2)
    action = load("frozen_scalar_adapter_v2/SA10_physical_actions.json")
    rh = load("frozen_rh_composite_adjudication/RH_primary_closed.json")
    assert rh["normalization"] == "F_action = F_raw/sqrt(2); sigma_C = -g10/2 [C,C]"
    # SA10 uses raw H columns. The action-normalized parent basis is raw/sqrt(2).
    rho = [matrix(row)/s.sqrt(2) for row in action["physical_H_parent"]]
    f = {(i, a, b): s.sympify(v)/s.sqrt(2) for i, a, b, v in
         rh["upper_index_structure_constants_raw"] if i < 12 and a < 12 and b < 12}
    f.update({(i, b, a): -v for (i, a, b), v in list(f.items())})
    a, b = 0, 4
    fc = {i: f.get((i, a, b), s.Integer(0)) for i in range(12)}
    fc = {i: v for i, v in fc.items() if v}
    assert fc == {4: -s.I/s.sqrt(2)}
    comm = clean(rho[a]*rho[b]-rho[b]*rho[a])
    represented = clean(sum((value*rho[i] for i, value in fc.items()), s.zeros(328)))
    assert clean(comm-represented) == s.zeros(328)
    # With LEFT odd Leibniz, Q(c rho eta)=(Qc)rho eta-c rho Qeta.
    # Both c_a c_b orders are retained. No c/u ghost or highest-jet truncation.
    # This extracts a polynomial coefficient at u=0, not an invariant restriction.
    ghost_piece = clean(2*ghost_ordered_sign*scalar_sign*represented)
    scalar_piece = clean(-scalar_sign**2*comm)
    square = clean(ghost_piece+scalar_piece)
    entries = sorted(square.todok().items())
    assert entries, "THE_FROZEN_FORWARD_SQUARE_WITNESS_MUST_NOT_BE_ERASED"
    (out, inp), coefficient = entries[0]
    assert (out, inp, coefficient) == (0, 3, 1)
    # Cross-check the matrix argument by applying the qualified LEFT odd
    # polynomial derivation twice. Keep all twelve light ghosts and every
    # scalar component that the first image uses, not a two-ghost truncation.
    algebra = Exterior()
    c = [algebra.variable("c"+str(i), 1) for i in range(12)]
    eta = [algebra.variable("eta"+str(i), 0) for i in range(328)]
    def scalar_image(i):
        return algebra.add(*(algebra.scale(algebra.mul(c[a], eta[j]), scalar_sign*v)
            for a, m in enumerate(rho) for (row, j), v in m.todok().items() if row == i))
    field_image = scalar_image(out)
    needed = sorted({j for m in rho for (i, j) in m.todok() if i == out})
    Q = {"eta"+str(i): scalar_image(i) for i in needed}
    for i in range(12):
        Q["c"+str(i)] = algebra.add(*(algebra.scale(algebra.mul(c[a], c[b]), 2*ghost_ordered_sign*v)
            for (k, a, b), v in f.items() if k == i and a < b))
    twice = algebra.derive(field_image, Q)
    selected_word = twice.get(("c0", "c4"), s.Integer(0))
    expected_word = sum((square[out, j]*algebra.even_symbols["eta"+str(j)] for j in range(328)), s.Integer(0))
    assert s.expand(selected_word-expected_word) == 0
    assert s.expand(selected_word).coeff(algebra.even_symbols["eta3"]) == coefficient
    # Diagnostic alternate sign ONLY: not a replacement and not fitted into M08.
    alternate = clean(-2*ghost_ordered_sign*represented-comm)
    assert alternate == s.zeros(328)
    e = load("frozen_action_ast_a3/A31_embeddings.json")["sectors"]["Phi"]
    assert e["coordinate_names"][out] == "Phi.offdiag.0.1"
    assert e["coordinate_names"][inp] == "Phi.offdiag.0.4"
    assert e["kinetic_gram"] == "IDENTITY_EXACT"
    selected = {"light_ghost_pair": [a, b], "scalar_output_coordinate": out,
                "scalar_input_coordinate": inp, "output_name": e["coordinate_names"][out],
                "input_name": e["coordinate_names"][inp],
                "monomial": "g10^2 c_L^0 c_L^4 eta_328[3]",
                "coefficient_in_Q2_eta0": str(coefficient),
                "ghost_variation_contribution": str(ghost_piece[out, inp]),
                "scalar_iteration_contribution": str(scalar_piece[out, inp])}
    return {"schema": "NONMINIMAL_BV_M08_ARCHITECTURE_PREFLIGHT_V1",
        "disposition": "BLOCKED_AT_INTERACTING_FORWARD_RULE_PREREQUISITE",
        "diagnostic_blocker": BLOCKER, "frozen_scalar_sign": str(scalar_sign),
        "frozen_ordered_ghost_quadratic_sign": str(ghost_ordered_sign),
        "H_pair_structure_coordinates": {str(i): str(v) for i, v in fc.items()},
        "physical_representation_commutator_residual": "ZERO_EXACT",
        "source_of_rho": "SA10 certified physical_H_parent transported by 1/sqrt(2)",
        "selected_component": selected,
        "selection": "First nonzero matrix entry for H pair (0,4); fixed before independent replay comparison, not analyst-blind",
        "witness_grade": {"input_d": 1, "input_gh": 0, "Q2_d": 3, "Q2_gh": 2, "weight": 1},
        "scope": "Generator-level full-Weil/off-shell prerequisite, not an H-basic cochain or full C+2 catalog",
        "alternate_scalar_sign_selected_square": "ZERO_EXACT_DIAGNOSTIC_ONLY_NOT_ADOPTED",
        "EOM_or_IBP_used": False, "source_or_auxiliary_dependent": False,
        "full_M08_master_action_constructed": False, "full_seventeen_role_rederivation_reached": False,
        "catalog_reconstruction_reached": False, "HB1_C5_authorized": False,
        "Sigma_or_frozen_images_changed": False, "full_M08_replacement_promoted": False,
        "formal_authority": "34/39_UNCHANGED", "finite_C1_GS": None,
        "external_specialist_review": False,
        "not_a_no_go_for": ["Spin(10) physics", "all BV formulations", "separately justified relative/on-shell complexes"]}


if __name__ == "__main__":
    print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
