"""Fast bounded evidence/adversarial tests; full regeneration is in the audit."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from audit_interacting_bv_preflight import compare,negative_controls
from interacting_bv_preflight import ModelJets,GRADES,PAIRS,setup,constant_ghost_density,g,xi,v
import interacting_bv_preflight_replay as replay

HERE=Path(__file__).resolve().parent


class InteractingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        folder=HERE/"frozen_interacting_bv_preflight"
        cls.p=json.loads((folder/"primary.json").read_text())
        cls.r=json.loads((folder/"replay.json").read_text())
    def test_complete_polynomial_comparison(self): compare(self.p,self.r)
    def test_nineteen_adversarial_claims(self): self.assertEqual(negative_controls(self.p,self.r),19)
    def test_all_sources_present(self): self.assertEqual(len(self.p["images"]),48)
    def test_canonical_antifield_coordinate_orientation_all_pairs(self):
        j=ModelJets()
        for z,source in PAIRS:
            star=j.a.scale(j.var(source),(-1)**GRADES[z][2])
            self.assertEqual(j.bracket(j.var(z),star),{():1})
            self.assertEqual(j.bracket(star,j.var(z)),{():-1})
    def test_two_presentations_checked(self): self.assertEqual(len(self.p["minimal_images"]),48)
    def test_nonzero_interactions_retained(self):
        rows=self.p["actions"]["invariant"]
        self.assertTrue(any("g**2" in row["coefficient"] for row in rows))
        self.assertTrue(any("h" in row["coefficient"] for row in rows))
    def test_vev_not_discarded(self): self.assertTrue(self.p["gauge_fixing"]["Goldstone_images"][0])
    def test_both_master_currents_reconstructed(self):
        for data in self.p["master"].values(): self.assertEqual(len(data["current"]),4)
    def test_exact_derivative_scope(self): self.assertEqual(self.p["squares"]["gauge_fixed_first_jets"],192)
    def test_omitted_partner_remains_failing(self): self.assertTrue(self.p["negative_controls"]["omitted_partner_free_square"])
    def test_wrong_scalar_orientation_remains_failing(self): self.assertTrue(self.p["negative_controls"]["wrong_positive_scalar_square"])
    def test_jet_limit_raises_instead_of_truncating(self):
        with self.assertRaises(RuntimeError): ModelJets().var("p0",(0,)*7)
    def test_dimensionful_vev_counted(self):
        import sympy as s
        j=ModelJets(); p=j.a.scale(j.var("c0"),s.Symbol("v"))
        self.assertTrue(j.homogeneous_grade(p,(2,1,1)))
        self.assertFalse(j.homogeneous_grade(p,(1,1,1)))
    def test_constant_auxiliary_selector_does_not_delete_antighosts(self):
        j,x,A,eta,c,bar,b,F,cov,S0,V,forward,Smin,psi,G=setup()
        actual=constant_ghost_density(j,j.Q(psi,forward),x)
        expected=j.a.scale(j.a.add(j.a.mul(bar[0],c[0]),j.a.mul(bar[1],c[1])),-xi*g*g*v*v)
        self.assertEqual(actual,expected)
        self.assertTrue(actual)
    def test_replay_does_not_import_primary_model(self):
        self.assertNotIn("from interacting_bv_preflight import",inspect.getsource(replay))
    def test_partial_gauge_domain_not_inferred(self): self.assertFalse(self.p["partial_gauge_source_domain_qualified"])
    def test_external_review_not_invented(self): self.assertFalse(self.p["external_specialist_review"])
    def test_authority_and_catalogs_not_changed(self):
        self.assertFalse(self.p["M08_changed"] or self.p["HB1_C5_authorized"])
        self.assertEqual(self.p["formal_authority"],"34/39_UNCHANGED")
        self.assertIsNone(self.p["finite_C1_GS"])
    def test_dropped_source_column_is_rejected(self):
        bad=copy.deepcopy(self.p); del bad["images"]["Jb0"]
        with self.assertRaises(AssertionError): compare(bad,self.r)


if __name__=="__main__": unittest.main()
