"""Independent pairing/matrix replay; no primary control algebra imports."""
from itertools import combinations
import json
from pathlib import Path

import sympy as s

HERE = Path(__file__).resolve().parent


def su2_replay():
    # Direct cross-product matrices, not the primary epsilon implementation.
    A = [s.Matrix([[0, 0, 0], [0, 0, -1], [0, 1, 0]]),
         s.Matrix([[0, 0, 1], [0, 0, 0], [-1, 0, 0]]),
         s.Matrix([[0, -1, 0], [1, 0, 0], [0, 0, 0]])]
    count = 0
    for a, b in combinations(range(3), 2):
        fab = s.zeros(3, 1)
        ea, eb = s.eye(3)[:, a], s.eye(3)[:, b]
        fab = ea.cross(eb)
        target = sum((fab[k] * A[k] for k in range(3)), s.zeros(3))
        assert A[a] * A[b] - A[b] * A[a] == target
        # Source self image k*g*c*A^T*L: two independent differentiated pieces.
        for k in (1, -1):
            ghost_piece = -k * target.T
            source_piece = -k**2 * (A[a].T * A[b].T - A[b].T * A[a].T)
            assert ghost_piece + source_piece == k * (k - 1) * target.T
            count += 1
        # Cotangent pairing: X has -A action, its source +A^T.
        assert A[a].T.T == A[a]
    # Independently differentiate the ordinary non-Abelian source polynomial:
    # S_L=-g*(L0*c1*c2-L1*c0*c2+L2*c0*c1).
    # The LEFT derivative of c_i c_j deletes the first with +, second with -;
    # the RIGHT derivative has exactly the opposite signs.
    source_terms = [(0, 1, 2, -1), (1, 0, 2, 1), (2, 0, 1, -1)]
    left, right = {}, {}
    for out, i, j, value in source_terms:
        left[i, out, j] = value
        left[j, out, i] = -value
        right[i, out, j] = -value
        right[j, out, i] = value
    for b in range(3):
        for out in range(3):
            for c in range(3):
                assert left.get((b, out, c), 0) == A[c].T[b, out]
                assert right.get((b, out, c), 0) == -A[c].T[b, out]
    # Independent gauge patch: dF=2g sum_i (e_i x (epsilon x e_i)).
    g, xi = s.symbols("g xi")
    patch = s.zeros(3)
    for e in (s.eye(3)[:, 0], s.eye(3)[:, 1]):
        for b in range(3):
            patch[:, b] += 2 * g * e.cross(s.eye(3)[:, b].cross(e))
    assert patch == s.diag(2 * g, 2 * g, 4 * g)
    # -delta psi contains -(xi*g^2/2) bar_i epsilon_ijk R_j bar_k.
    # R_j=-epsilon_jmn u_m u_n/2. Two antisymmetric ordered slots
    # independently contribute, producing +xi*g^2 per ordered pair.
    quartic = {}
    for m, n in combinations(range(3), 2):
        for i, k in combinations(range(3), 2):
            # Direct epsilon contractions evaluated via cross products.
            eps = lambda a, b, c: s.eye(3)[:, a].dot(s.eye(3)[:, b].cross(s.eye(3)[:, c]))
            value = -sum(eps(i, j, k) * eps(j, m, n) for j in range(3))
            if value:
                quartic[f"u{m} u{n} bar{i} bar{k}"] = str(g**2 * xi * value)
    assert quartic == {f"u{i} u{j} bar{i} bar{j}": "g**2*xi" for i, j in combinations(range(3), 2)}
    return {"source_left_sign": 1, "source_right_mixed_sign": -1, "source_square_factor": "k*(k-1)",
            "representation_square_checks": count, "gauge_fixing_Jacobian_determinant": str(patch.det()),
            "quartic_ghost_terms": quartic, "source_pair_contraction_factor": "k-1", "imports_primary_columns": False}


def m08_replay():
    rep = json.loads((HERE / "frozen_c3/C3_representation_basis.json").read_text())
    raw_pairs = list(combinations(range(10), 2))
    def matrix(row):
        out = s.zeros(10)
        for entry in row["raw_so10_coordinates"]:
            a, b = raw_pairs[entry["index"]]
            out[a, b] = s.sympify(entry["coefficient"]) / s.sqrt(2)
            out[b, a] = -out[a, b]
        return out
    H = [matrix(row) for row in rep["h_basis"]]
    gram = s.Matrix(12, 12, lambda a, b: s.simplify(s.trace(H[a].T * H[b])))
    dual = gram.inv()
    def project(mat):
        return (dual * s.Matrix([s.trace(h.T * mat) for h in H])).applyfunc(s.simplify)
    A = [s.Matrix.hstack(*(project(h * v - v * h) for v in H)) for h in H]
    heavy_a, heavy_b = (matrix(rep["heavy_basis"][i]) for i in (1, 26))
    rv = -project(heavy_a * heavy_b - heavy_b * heavy_a)
    coupling = next(v for v in json.loads((HERE / "frozen_source_seed_s3_s5/S33_source_couplings.json").read_text())["couplings"] if v["source"] == "L_c")
    terms = coupling["coupling_AST"]["density"]["expression"]["factors"][1]["terms"]
    factor = s.sympify(terms[0]["factors"][0]["value"])
    assert factor == -s.Rational(1, 2)
    # Derive BOTH source images by deleting the two ordered ghost slots.
    left, right, ghost = [], [], []
    for b in range(12):
        right.append({(out, j): s.simplify(factor * (-A[b][out, j] + A[j][out, b])) for out in range(12) for j in range(12) if A[b][out, j]})
        left.append({key: -value for key, value in right[-1].items()})
        ghost.append({(i, j): s.simplify(2 * factor * A[i][b, j]) for i, j in combinations(range(12), 2) if A[i][b, j]})
    def square(image):
        # Direct graded Leibniz expansion of one component, not matrix-square formula.
        result = 0
        for (out, j), value in image[0].items():
            for (d, k), coeff in image[out].items():
                if d == 4 and {k, j} == {0, 4}:
                    result += value * coeff * (1 if k < j else -1)
            if out == 4:
                result += value * ghost[j].get((0, 4), 0)
        return s.simplify(result)
    old_square, candidate_square = square(right), square(left)
    # iota_0(B Lc_j) R_j plus Lc_j iota_0(B R_j), selected Lc4.
    old_pair = s.simplify(sum(right[j].get((4, 0), 0) * rv[j] for j in range(12)) - (A[0] * rv)[4])
    new_pair = s.simplify(sum(left[j].get((4, 0), 0) * rv[j] for j in range(12)) - (A[0] * rv)[4])
    assert (old_square, candidate_square, old_pair, new_pair) == (1, 0, -2 * s.I, 0)
    return {"route": "DIRECT_PHYSICAL_SO10_MATRICES_GRAM_DUAL_AND_ORDERED_SOURCE_DERIVATIVES", "f_4_0_4": str(A[0][4, 4]),
            "R4_u1_u26": str(rv[4]), "frozen_reverse_source_self_sign": "-1", "left_bracket_candidate_self_sign": "1",
            "frozen_pair_residual": str(old_pair), "candidate_pair_residual": str(new_pair),
            "frozen_source_square": str(old_square), "candidate_source_square": str(candidate_square),
            "Sigma_nonhorizontal_coefficient": str(-A[0][4, 4]), "full_M08_repair_or_ST_recomputation": False}


def build():
    if not __debug__:
        raise RuntimeError("EXACT_REPLAY_REQUIRES_ASSERTIONS_ENABLED")
    return {"schema": "SOURCE_CONVENTION_REPLAY_V1", "SU2_pairing_replay": su2_replay(), "M08_bounded_comparison": m08_replay(),
            "independence": {"primary_module_imported": False, "library_independent": False, "runtime_independent": False,
                             "external_specialist_review": False, "limits": "Shared Python/SymPy, frozen physical frame and mathematical conventions; separate algebra and source derivative paths."}}


if __name__ == "__main__":
    print(json.dumps(build(), indent=2, sort_keys=True))
