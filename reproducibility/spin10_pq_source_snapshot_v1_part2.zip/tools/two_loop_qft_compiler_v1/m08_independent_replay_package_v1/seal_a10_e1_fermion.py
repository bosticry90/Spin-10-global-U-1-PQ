"""Seal completed bounded E1 replacement, preserving all historical manifests."""
from hashlib import sha256
import json,subprocess
from a10_e1_fermion_common import *

FILES=('A10_E1_FERMION_CONTRACT_V1.md','A10_E1_FERMION_RESULT.md','A10_E1_FERMION_TECHNICAL_REVIEW_PACKET_V1.md',
 'a10_e1_fermion_common.py','a10_e1_fermion_primary.py','a10_e1_fermion_replay.py','a10_e1_fermion_checks.py',
 'audit_a10_e1_fermion.py','test_a10_e1_fermion.py','run_a10_e1_fermion.py','export_a10_e1_fermion.py',
 'validate_a10_e1_fermion.py','export_a10_e1_fermion_receipt.py','seal_a10_e1_fermion.py')

def hashfile(p):return sha256(p.read_bytes()).hexdigest()

def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['scientific_gate']==STATUS and receipt['targeted_regression_tests']==142
    assert receipt['fresh_new_routes_byte_identical']==3 and not receipt['audit_time_changes']
    assert receipt['historical_custody_exit']==2 and not receipt['historical_equivalence_proved']
    state=hashfile(ROOT/'project_state.json');assert state==receipt['live_state_transaction_sha256']
    from audit_a10_e1_fermion import authenticate
    assert authenticate()['scientific_gate']==receipt['scientific_gate']
    files=[HERE/n for n in FILES]+[ROOT/'docs/A10_E1_FERMION_CURRENT.md']
    files+=sorted(p for p in OUT.glob('*.json') if p.name!='bindings.json')
    for p in files:
        raw=p.read_bytes();assert b'\r\n' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),('BAD_LINE_ENDINGS',str(p))
    manifests=[HERE/n/'bindings.json' for n in PREDECESSORS]
    p=read(OUT/'primary.json');history={str((HERE/n).relative_to(ROOT).as_posix()):h for n,h in p['recovery']['historical_bytes'].items()}
    assert all(hashfile(ROOT/n)==h for n,h in history.items())
    result={'schema':'A10_E1_FERMION_BYTE_BINDINGS_V1',
      'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'byte_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in files},
      'inherited_manifest_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in manifests},
      'historical_input_sha256':history,'state_sha256':state,'scientific_disposition':STATUS,
      'authority_changed':False,'candidate_adopted':False,'sources_activated':False,
      'Stage_D_preserved':True,'Stage_E_completed':False,'E2_E5_executed':False,
      'historical_equivalence_proved':False,'personal_outreach':False,'remote_push':False,
      'post_validation_finalization':'receipt export and byte sealing only; no scientific edits after validation'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(files))+' files; E2 not executed; historical custody remains exit 2',flush=True)
if __name__=='__main__':main()
