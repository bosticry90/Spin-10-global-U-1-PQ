"""Mathematical and adversarial checks of the coherent measured-residue record."""
import unittest
from audit_a10_e5_measured_functional_v2 import *


class MeasuredFunctionalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_twelve_sectors_aggregate(self):self.assertEqual(self.c['sector_count'],12);self.assertEqual(self.c['canonical_residue_terms'],27745)
    def test_declared_coupling_degrees_enforced(self):
        for name,data in self.a['sectors'].items():self.assertTrue(all(s.Poly(z,g).monoms()==[(EXPECTED_G[name],)] for z in decode_typed(data).values()))
    def test_archived_missing_g2_factor_is_rejected(self):
        bad=decode_typed(read(OUT/'primary.json')['sectors']['auxiliary_g2']);self.assertTrue(any(s.Poly(z,g).monoms()!=[(2,)] for z in bad.values()))
    def test_archived_failed_historical_replay_is_rejected(self):
        p=HERE/'frozen_a10_e5_quartic_companion';self.assertNotEqual(read(p/'replay.json')['actual_pole'],read(p/'replay_v2.json')['actual_pole'])
    def test_constant_parameter_Ward_identity(self):
        P=decode_typed(self.a['local_Ward_variation']);self.assertFalse(canonical({word:z for word,z in P.items() if all(not j for n,j in word if n.startswith('omega'))}))
    def test_full_local_parameter_variation_survives(self):self.assertTrue(self.c['Ward_parameter_Euler_witness']['full_Euler']);self.assertFalse(self.c['Ward_parameter_Euler_witness']['pure_boundary'])
    def test_Ward_current_is_complete(self):
        w=alphabet();P=decode_typed(self.a['local_Ward_variation']);A=decode_typed(self.a['anchored_Ward_parameter_density']);C=[decode_typed(v) for v in self.a['full_Ward_IBP_currents']]
        self.assertFalse(canonical(w.add(P,w.scale(A,-1),w.scale(w.add(*(w.D(T,mu) for mu,T in enumerate(C))),-1))))
    def test_external_background_predecessor_required_in_census(self):
        self.assertTrue(all(any('A' in p['types'] for p in row['necessary_predecessors']) for row in self.c['Ward_dependencies_with_coverage']))
    def test_only_missing_nonboundary_leading_ghost_type(self):self.assertEqual(self.c['unmeasured_Slavnov_input_types']['ghost_two_jet'],[[['C','C','JC'],0,2]])
    def test_pure_boundary_input_types_not_mistaken_for_unknown_amplitudes(self):
        rows_=self.c['Slavnov_dependencies_with_coverage']['ghost_two_jet'];self.assertTrue(any(v['disposition']=='PURE_BOUNDARY_INPUT' for v in rows_))
    def test_both_projected_domains_complete(self):self.assertEqual(self.a['target_domains'],{'ghost_two_jet':3539700,'auxiliary_no_jet':2004750})
    def test_equal_color_unequal_jets_not_nilpotent(self):
        w=alphabet();self.assertTrue(w.mul(w.var('C13'),w.D(w.var('C13'),0)));self.assertFalse(w.mul(w.var('C13'),w.var('C13')))
    def test_source_parity_negative_control(self):self.assertTrue(self.u['wrong_even_source_residual'])
    def test_projected_Q_real_structure(self):self.assertTrue(all(v['real_coefficients'] for v in self.q['physical_projected_Q_checks'].values()))
    def test_no_unmeasured_coefficient_bound(self):
        self.assertTrue(all(not v['unknown_coefficient_bound'] and not v['unknown_remainder_is_zero'] for values in self.c['Slavnov_dependencies_with_coverage'].values() for v in values))
    def test_deferred_physical_Eulers_retained(self):self.assertEqual(self.q['deferred_physical_Eulers'],508);self.assertFalse(self.a['Q_column_screen']['full_physical_Euler_set_to_zero'])
    def test_scalar_program_keeps_its_representation(self):
        v=self.a['separate_indexed_or_regulated_nodes']['scalar_g0_indexed'];self.assertEqual(v['hessian_program']['graph_coefficients'],331);self.assertFalse(v['merged_into_Minkowski_polynomial_sum'])
    def test_power_and_finite_profile_not_in_log_sum(self):self.assertFalse(self.a['separate_indexed_or_regulated_nodes']['ghost_g1_power_and_finite']['merged_into_local_logarithmic_sum'])
    def test_both_failed_calculation_classifications_preserved(self):
        self.assertFalse(read(OUT/'input_selection_failure_disposition_1.json')['counted_as_PASS']);self.assertFalse(read(OUT/'coupling_unit_failure_disposition_1.json')['counted_as_PASS'])
    def test_g3_obstruction_stays_failed(self):self.assertFalse(read(HERE/'frozen_a10_e5_quartic_g3/bindings.json')['candidate_selected_quartic_g3_gate_PASS'])


if __name__=='__main__':unittest.main()
