"""Fresh bounded old controls, reached ONLY after the free BV gates pass.

This does not couple the free model to M08 or qualify any full M08 replacement.
"""
from hashlib import sha256
import json
from pathlib import Path
from source_convention_control import build as primary_build
from source_convention_replay import build as replay_build
from audit_source_convention_review import compare, serialized

HERE = Path(__file__).resolve().parent


def build():
    if not __debug__:
        raise RuntimeError("EXACT_REGRESSION_REQUIRES_ASSERTIONS_ENABLED")
    primary, replay = primary_build(), replay_build()
    for name, payload in (("primary", primary), ("replay", replay)):
        assert serialized(payload) == (HERE/"frozen_source_convention_review"/(name+".json")).read_bytes()
    compare(primary, replay)
    return {"schema": "NONMINIMAL_BV_FREE_FOLLOWUP_REGRESSIONS_V1",
            "prior_comparator_bytes_reproduced": True,
            "prior_primary_sha256": sha256(serialized(primary)).hexdigest(),
            "prior_replay_sha256": sha256(serialized(replay)).hexdigest(),
            "exact_comparator_assertions": sum(v["exact_assertion_count"] for v in primary["results"]),
            "partial_gauge_full_BV_generator_count": primary["results"][1]["gauge_fixed_full_BV_generator_count"],
            "partial_gauge_master_square_Cartan": "EXACT_ZERO_WITH_NONMINIMAL_ANTIFIELDS",
            "M08_bounded_controls": primary["M08_bounded_comparison"],
            "interpretation": "Separate bounded sectors remain successful; no coupled full M08 proof",
            "full_M08_replacement": False, "external_specialist_review": False}


if __name__ == "__main__":
    print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
