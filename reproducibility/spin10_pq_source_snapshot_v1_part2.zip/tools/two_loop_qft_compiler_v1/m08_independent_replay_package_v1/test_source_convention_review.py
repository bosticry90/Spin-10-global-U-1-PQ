"""Bounded algebra regressions; no scientific-state writes."""
import unittest
import sympy as s
from source_convention_control import Exterior, model


class AlgebraTests(unittest.TestCase):
    def setUp(self):
        self.a = Exterior()
        self.x = self.a.variable("x", 0)
        self.c = self.a.variable("c", 1)
        self.d = self.a.variable("d", 1)

    def test_odd_square_zero(self):
        self.assertEqual(self.a.mul(self.c, self.c), {})

    def test_anticommutativity(self):
        self.assertEqual(self.a.add(self.a.mul(self.c, self.d), self.a.mul(self.d, self.c)), {})

    def test_left_right_odd_product(self):
        cd = self.a.mul(self.c, self.d)
        self.assertEqual(self.a.partial(cd, "c"), self.d)
        self.assertEqual(self.a.partial(cd, "c", "right"), self.a.scale(self.d, -1))

    def test_even_coefficient_image_precedes_word(self):
        # Regression for a development bug in the new comparator implementation.
        q = {"x": self.c}
        self.assertEqual(self.a.derive(self.a.mul(self.x, self.d), q), self.a.mul(self.c, self.d))
        self.assertEqual(self.a.derive(self.a.mul(self.x, self.c), q), {})

    def test_left_leibniz(self):
        images = {"x": self.c, "c": self.x}
        for f, parity in ((self.x, 0), (self.c, 1), (self.a.mul(self.x, self.d), 1)):
            lhs = self.a.derive(self.a.mul(f, self.d), images)
            rhs = self.a.add(self.a.mul(self.a.derive(f, images), self.d), self.a.scale(self.a.mul(f, self.a.derive(self.d, images)), (-1)**parity))
            self.assertEqual(lhs, rhs)

    def test_odd_bracket_coordinate_change(self):
        jx = self.a.variable("jx", 1)
        jc = self.a.variable("jc", 0)
        pairs = [("x", "jx"), ("c", "jc")]
        self.assertEqual(self.a.bracket(self.x, jx, pairs), {(): s.Integer(1)})
        self.assertEqual(self.a.bracket(self.c, jc, pairs), {(): s.Integer(-1)})
        # c_star=-jc is the canonical coordinate; x_star=jx.
        self.assertEqual(self.a.bracket(self.c, self.a.scale(jc, -1), pairs), {(): s.Integer(1)})

    def test_bracket_is_left_hamiltonian_derivation(self):
        jx = self.a.variable("jx", 1)
        jc = self.a.variable("jc", 0)
        pairs = [("x", "jx"), ("c", "jc")]
        action = self.a.mul(jx, self.c)  # even
        images = {"x": self.a.bracket(action, self.x, pairs), "c": self.a.bracket(action, self.c, pairs)}
        expression = self.a.mul(self.x, self.c)
        self.assertEqual(self.a.bracket(action, expression, pairs), self.a.derive(expression, images))

    def test_conventional_master_and_wrong_sign_control(self):
        result = model(False)
        self.assertEqual(result["master_equation"], "EXACT_ZERO")
        self.assertTrue(result["wrong_sign_Lc0_square"])


if __name__ == "__main__":
    unittest.main()
