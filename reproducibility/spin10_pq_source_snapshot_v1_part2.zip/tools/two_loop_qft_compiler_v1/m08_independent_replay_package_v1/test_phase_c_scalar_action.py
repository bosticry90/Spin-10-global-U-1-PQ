"""Tests for missed compensators, projection order and divergence adjudication."""
import unittest
import sympy as s
import phase_c_complete_scalar_action as p
import phase_c_complete_scalar_action_replay as r
from interacting_actual_h_preflight_replay import GaugeWords


def field(name): return {'node': 'Field', 'name': name, 'parity': 0}
def derivative(x): return {'node': 'PartialDerivative', 'argument': x, 'index': 'mu', 'parity': 0}
def product(*xs): return {'node': 'OrderedProduct', 'factors': list(xs), 'parity': 0}


class CompensatorTests(unittest.TestCase):
    def possible(self, tree, euler=False):
        return any(p.channel_possible(w, euler) for w in p.varied_support(p.support(tree)))

    def test_linear_gauge_scalar_term_is_detected_after_connection_variation(self):
        tree = product(field('q_L'), field('x_Phi_offdiag_0_4'), derivative(field('x_Phi_offdiag_0_1')))
        self.assertTrue(self.possible(tree)); self.assertTrue(self.possible(tree, True))

    def test_second_ghost_derivative_can_affect_Euler_even_without_selected_density_word(self):
        tree = product(derivative(field('q_L')), field('Phi'), field('Phi'))
        self.assertFalse(self.possible(tree)); self.assertTrue(self.possible(tree, True))

    def test_derivative_inside_product_is_prolonged(self):
        tree = product(field('q_L'), derivative(product(field('Phi'), field('Phi'))))
        self.assertTrue(self.possible(tree)); self.assertTrue(self.possible(tree, True))

    def test_independent_scanner_rejects_injected_compensator(self):
        action = r.read('frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json')['action']
        action['local_terms'][0]['term'] = product(field('q_L'), field('Phi'), derivative(field('Phi')))
        with self.assertRaises(AssertionError): r.inspect_complete_action(action)

    def test_antighost_supported_scalar_terms_are_excluded(self):
        self.assertFalse(self.possible(product(field('ubar_H'), derivative(field('Phi')), field('Phi'))))

    def test_nonzero_density_coefficient_is_not_itself_a_functional_obstruction(self):
        w = GaugeWords(0); w.p = {'C': 1, 'x': 0, 'y': 0}
        current = w.mul(w.var('C'), w.var('x'), w.D(w.var('y'), 0))
        density = w.D(current, 0)
        self.assertTrue(density)
        self.assertFalse(w.EL(density, 'C'))

    def test_exact_nondivergence_for_two_field_witness(self):
        w = GaugeWords(0); w.p = {'C': 1, 'x': 0, 'y': 0}
        k = s.I*s.Symbol('g10')/s.sqrt(2)
        density = w.scale(w.mul(w.D(w.var('C'), 0),
                     w.add(w.mul(w.var('y'), w.D(w.var('x'), 0)),
                           w.scale(w.mul(w.var('x'), w.D(w.var('y'), 0)), -1))), k)
        expected = w.scale(w.add(w.mul(w.var('x'), w.D(w.D(w.var('y'), 0), 0)),
                                 w.scale(w.mul(w.var('y'), w.D(w.D(w.var('x'), 0), 0)), -1)), k)
        self.assertEqual(w.EL(density, 'C'), expected)


if __name__ == '__main__': unittest.main()
