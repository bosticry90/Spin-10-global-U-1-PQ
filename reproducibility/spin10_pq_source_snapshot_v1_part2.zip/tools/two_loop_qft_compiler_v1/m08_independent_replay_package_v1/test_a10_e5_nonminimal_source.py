"""Scientific actual-source, complete affine-map and exactness controls."""
import unittest
from audit_a10_e5_nonminimal_source import evidence, independent_checks
from a10_e5_nonminimal_source import read, OUT, s


class NonminimalSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.a, cls.c = evidence()

    def test_all91125_source_slots(self): self.assertEqual(self.a['domain']['all_tensor_slots'], 91125)
    def test_actual_routes_agree(self): self.assertTrue(self.c['actual_methods_agree'])
    def test_linear_source_zero_is_literal(self): self.assertEqual(self.a['inventory']['literal_source_linear_terms'], 45); self.assertTrue(self.a['inventory']['light_source_Hessian_zero_all643_squared_slots'])
    def test_nonlinear_heavy_source_retained(self): self.assertGreater(self.a['inventory']['literal_nonlinear_source_terms'], 0)
    def test_all12_local_H(self): self.assertEqual(self.a['all12_local_H_identities'], list(range(12)))
    def test_source_real_and_exact(self): self.assertTrue(all(not s.sympify(v).has(s.Float) for i, j, k, v in self.a['physical_pole_slots']))
    def test_light_zero_channels_not_dropped(self): self.assertTrue(all(min(i, j, k) >= 12 for i, j, k, v in self.a['physical_pole_slots']))
    def test_all4_Lorentz(self): self.assertTrue(self.a['inventory']['all4_Lorentz_copies_checked'])
    def test_full_current_and_ghost_derivative(self): self.assertEqual(len(self.a['inventory']['IBP_current']), 4)
    def test_bubble_zero_has_edge_proof(self): self.assertIn('light antighost', self.a['inventory']['quarter_bubble_zero_reason'])
    def test_scalar_alternatives_excluded_by_edge_and_dimension(self): self.assertIn('dimension-zero', self.a['inventory']['other_physical_vertices_reason'])
    def test_width_independence_after_full_inverse(self): self.assertTrue(self.a['width_independent_after_full_reference_contraction'])
    def test_UV_only_not_scaleless(self): self.assertFalse(self.a['UV_residue']['exceptional_scaleless_integral_used']); self.assertFalse(self.a['complete_finite_IR_amplitude_calculated'])
    def test_heat_profiles_retained(self): self.assertTrue(self.a['UV_residue']['different_heat_profiles_retained'])
    def test_no_prediction_input_to_actual(self): self.assertFalse(self.a['affine_or_candidate_read_during_actual_calculation'])
    def test_complete_affine_equations(self): self.assertTrue(self.c['all91125_source_slots_compared']); self.assertEqual(self.c['quartet_affine_directions_before_source'], 39)
    def test_match_unique_or_exact_obstruction(self):
        if self.c['match']: self.assertEqual(self.c['remaining_affine_directions'], 0); self.assertEqual(self.c['affine_source_rank'], 39)
        else: self.assertTrue(self.c['first_failure_stopped']); self.assertTrue(self.c['real_physical_affine_annihilator']['annihilates_all39_affine_directions'])
    def test_full_member_or_witness_preserved(self):
        if self.c['match']: self.assertTrue(self.c['unique_new_generator']); self.assertTrue(self.c['all980100_quartet_match_preserved'])
        else: self.assertTrue(self.c['full_actual_minus_affine_particular_source_density']); self.assertFalse(self.c['real_source_Euler_witness']['pure_total_derivative'])
    def test_failed_float_precheck_preserved(self):
        r = read(OUT / 'vertex_precheck_attempt_1_disposition.json'); self.assertEqual(r['floating_coefficients'], 502); self.assertFalse(r['counted_as_PASS'])
    def test_Born_Wick_and_mutation_controls(self): self.assertTrue(independent_checks(self.a)['elementary_Born_Wick_reproduced_after_vertex_exactness_fix'])
    def test_no_others_after_first_gate(self): self.assertFalse(self.c['other_new_companion_loops_executed']); self.assertFalse(self.c['JC_CC_or_JB_BC_loops_executed'])
    def test_no_adoption_or_quantum_promotion(self): self.assertFalse(self.c['normalization_adopted']); self.assertFalse(self.c['full_E5_or_quantum_A5'])
    def test_whole_goal_active(self): self.assertFalse(self.c['whole_goal_complete'])


if __name__ == '__main__': unittest.main()
