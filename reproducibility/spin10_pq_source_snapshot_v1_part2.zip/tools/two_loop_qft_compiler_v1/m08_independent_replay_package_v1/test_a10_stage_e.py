"""Exact E1 interpretation, variational and real-frame regression checks."""
from copy import deepcopy
import unittest
from a10_stage_e_common import *
from audit_a10_stage_e import adjudicate

class StageETests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
    def test_reserved_chart_identification_is_not_promoted(self):
        self.assertFalse(recovery()['historical_nonminimal_AST_identified'])
        self.assertEqual(self.p['status'],STOP)
    def test_current_divergence_has_both_connections(self):
        h=read(HERE/HISTORICAL[1])['functional']['gauge_function']
        self.assertTrue({'q_L','Abar_H'} <= {n.get('name') for n in walk(h)})
    def test_exact_all_12_by_33_matrix_comparison(self):
        self.assertEqual(self.p['Ward_auxiliary_matrices'],self.r['Ward_auxiliary_matrices'])
        self.assertEqual(adjudicate(self.p,self.r)['dense_auxiliary_Ward_entries_compared'],13068)
    def test_full_coefficient_and_Euler_replay(self):
        for key in ('full_Ward_density','Euler_L13','minimal_parent_Euler_coefficient'):
            self.assertEqual(self.p['diagnostic'][key],self.r['diagnostic'][key])
    def test_minimal_exact_nonboundary_witness(self):
        self.assertEqual(self.p['diagnostic']['minimal_parent_Euler_coefficient'],
            [{'word':['omega1','ub13'],'coefficient':'sqrt(2)*I*g10*xi/2'}])
        self.assertTrue(self.p['diagnostic']['not_total_derivative'])
    def test_correct_pairing_derived_without_fitting(self):
        control=self.p['inverse_Gram_control'];self.assertEqual(control,self.r['inverse_Gram_control'])
        self.assertTrue(control['all_12_Ward_residuals_zero'])
        self.assertFalse(control['historical_fermion_changed'])
        self.assertFalse(control['complete_fermion_qualified'])
    def test_real_physical_conjugation_and_heavy_projection(self):
        w=self.p['real_physical_witness'];self.assertEqual(w,self.r['real_physical_witness'])
        self.assertTrue(w['real_parent_conjugation_verified'] and w['heavy_projection_verified'])
        self.assertEqual(w['coefficient'],'sqrt(2)*g10*xi')
        self.assertFalse(w['EOM_used'])
    def test_real_control_direct_first_variation(self):
        self.assertEqual(self.r['diagnostic']['direct_real_variation_without_theta'],'sqrt(2)*g10*omega1*t*xi')
    def test_all_possible_auxiliary_cancellations_screened(self):
        self.assertEqual(len(self.p['recovery']['channel_exclusion']),4)
        self.assertTrue(self.p['recovery']['all_other_terms_screened_before_projection'])
    def test_no_later_gate_or_complete_action_claim(self):
        for n in ('Stage_E_completed','E2_E5_executed','complete_fixed_action_constructed'):
            self.assertFalse(self.p[n])
    def test_false_PASS_and_activation_rejected(self):
        for key in ('Stage_E_completed','sources_activated','candidate_adopted'):
            p,r=deepcopy(self.p),deepcopy(self.r);p[key]=r[key]=True
            with self.assertRaises(AssertionError):adjudicate(p,r)
    def test_comparison_rejects_changed_coefficient(self):
        r=deepcopy(self.r);r['Ward_auxiliary_matrices']['1']['entries'][0][2]='0'
        with self.assertRaises(AssertionError):adjudicate(self.p,r)
    def test_all_old_action_and_evidence_bytes_still_bound(self):
        for path,expected in self.p['recovery']['historical_bytes'].items():
            self.assertEqual(sha256((HERE/path).read_bytes()).hexdigest(),expected)
        self.assertTrue(self.p['Stage_D_preserved'])
    def test_no_external_or_quantum_authority_claim(self):
        for key in ('external_endorsement','personal_outreach','HB1_C5_run','C1_GS_calculated'):
            self.assertFalse(self.p[key])
        self.assertEqual(self.p['formal_authority'],'34/39_UNCHANGED')
if __name__=='__main__':unittest.main()
