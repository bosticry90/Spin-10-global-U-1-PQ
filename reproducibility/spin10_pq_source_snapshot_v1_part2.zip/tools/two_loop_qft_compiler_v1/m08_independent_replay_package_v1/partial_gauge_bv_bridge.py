"""Inactive SU(2)/U(1) continuum bridge; exact exterior/Euler route, stdout only."""
import json
import sympy as s
from source_convention_control import Exterior, Checks, cross, dot
from interacting_bv_preflight import ModelJets

FIELDS={**{f"A{k}{m}":(1,0,0) for k in range(3) for m in range(4)},
        **{f"p{k}":(1,0,0) for k in range(3)},**{f"c{k}":(1,1,1) for k in range(3)},
        **{f"bar{k}":(1,-1,1) for k in range(2)},**{f"b{k}":(2,0,0) for k in range(2)}}
PAIRS=[(z,"J"+z) for z in FIELDS]
GRADES={**FIELDS,**{j:(3-FIELDS[z][0],-1-FIELDS[z][1],1-FIELDS[z][2]) for z,j in PAIRS}}
g,h,xi,v=s.symbols("g h xi v")
ETA=(1,-1,-1,-1)
DISPOSITION="BLOCKED_GLOBAL_CARTAN_SQUARE_OMITS_LOCAL_RESIDUAL_CONNECTION_TERM"


class PartialJets(ModelJets):
    # Reuse the qualified ordinary-jet Euler, polynomial serialization,
    # evolutionary prolongation and source-substitution algorithms, not its model.
    def __init__(self):
        self.a,self.meta,self.values=Exterior(),{},{}
        self.limit,self.max_order,self._prolongations=6,0,{}
        for base in GRADES: self.var(base)

    def var(self,base,indices=()):
        indices=tuple(sorted(indices))
        if len(indices)>self.limit: raise RuntimeError("JET_LIMIT_NOT_A_ZERO_RELATION")
        name=base+("__"+"".join(map(str,indices)) if indices else "")
        if name not in self.meta:
            self.meta[name]=(base,indices)
            parity=0 if base=="omega" else GRADES[base][2]
            self.values[name]=self.a.variable(name,parity)
            self.max_order=max(self.max_order,len(indices))
        return self.values[name]

    def bracket(self,f,k,pairs=PAIRS):
        a=self.a
        return a.add(*(a.scale(a.add(a.mul(self.euler(f,z,"right"),self.euler(k,j)),
            a.scale(a.mul(self.euler(f,j,"right"),self.euler(k,z)),-1)),(-1)**GRADES[z][2]) for z,j in pairs))

    def columns(self,S,pairs=PAIRS):
        return {n:self.euler(S,other) for pair in pairs for n,other in (pair,pair[::-1])}

    def homogeneous_grade(self,p,grade):
        for row in self.record(p):
            base_grade=[0,0,0]
            for name in row["word"]:
                z,I=self.meta[name]; d,gh,par=GRADES[z]
                base_grade[0]+=d+len(I); base_grade[1]+=gh; base_grade[2]^=par
            for powers,_ in s.Poly(s.sympify(row["coefficient"]),v).terms():
                if (base_grade[0]+powers[0],base_grade[1],base_grade[2])!=grade: return False
        return True

    # The inherited scaling-current algorithm checks Euler residuals against
    # the old 48-name superset. All 44 present names are in that set; the four
    # absent names have zero Euler derivative. No new generator is missed.

    def act(self,p,images,parity):
        lifted={n:self.multiD(images.get(self.meta[n][0],{}),self.meta[n][1]) for n in self.support(p)}
        return self.a.derive(p,lifted,parity=parity)

    def strip_light_ghost(self,p):
        names=[n for n in self.support(p) if self.meta[n][0]=="c2"]
        return {word:co for word,co in p.items() if not any(n in word for n in names)}


def setup():
    j=PartialJets(); a=j.a; x={n:j.var(n) for n in GRADES}
    A=[[x[f"A{k}{m}"] for k in range(3)] for m in range(4)]
    phi=[x[f"p{k}"] for k in range(3)]; eta=[phi[0],phi[1],a.add(phi[2],{():v})]
    C=[x[f"c{k}"] for k in range(3)]
    bar=[x["bar0"],x["bar1"],{}]; b=[x["b0"],x["b1"],{}]
    e=[{},{},{():s.Integer(1)}]
    t=lambda z:cross(a,e,z)
    R=a.scale(a.mul(C[0],C[1]),-1)
    F={}; cov=[]
    for m in range(4):
        for n in range(4):
            comm=cross(a,A[m],A[n])
            F[m,n]=[a.add(j.D(A[n][k],m),a.scale(j.D(A[m][k],n),-1),a.scale(comm[k],g)) for k in range(3)]
        cov.append([a.add(j.D(eta[k],m),a.scale(cross(a,A[m],eta)[k],g)) for k in range(3)])
    radius=a.add(dot(a,eta,eta),{():-v*v}); potential=a.scale(a.mul(radius,radius),h/4)
    S0=a.add(*(a.scale(dot(a,f,f),-s.Rational(1,4)*ETA[m]*ETA[n]) for (m,n),f in F.items()),
             *(a.scale(dot(a,y,y),s.Rational(1,2)*ETA[m]) for m,y in enumerate(cov)),a.scale(potential,-1))
    Q={}
    for m in range(4):
        ac=cross(a,A[m],C)
        for k in range(3): Q[f"A{k}{m}"]=a.add(j.D(C[k],m),a.scale(ac[k],g))
    for k in range(3):
        Q[f"p{k}"]=a.scale(cross(a,C,eta)[k],-g)
        Q[f"c{k}"]=a.scale(cross(a,C,C)[k],-g/2)
    for k in range(2):
        Q[f"bar{k}"]=a.add(a.scale(b[k],-1),a.scale(a.mul(C[2],t(bar)[k]),-g))
        Q[f"b{k}"]=a.add(a.scale(a.mul(C[2],t(b)[k]),-g),a.scale(a.mul(R,t(bar)[k]),-g*g))
    Smin=a.add(S0,*(a.mul(x[source],Q[z]) for z,source in PAIRS))
    W=[[A[m][0],A[m][1],{}] for m in range(4)]
    gold=cross(a,[{},{},{():v}],phi)
    G=[a.add(*(a.scale(a.add(j.D(W[m][k],m),a.scale(a.mul(A[m][2],t(W[m])[k]),g)),ETA[m]) for m in range(4)),a.scale(gold[k],-xi*g)) for k in range(2)]
    psi=dot(a,bar[:2],[a.add(G[k],a.scale(b[k],-xi/2)) for k in range(2)])
    L={n:{} for n in GRADES}
    for prefix,indices in (("A",range(4)),("JA",range(4)),("p",[None]),("Jp",[None]),("c",[None]),("Jc",[None]),("bar",[None]),("Jbar",[None]),("b",[None]),("Jb",[None])):
        for mu in indices:
            suffix="" if mu is None else str(mu)
            # -tX = (X1,-X0,0), including evaluation-dual sources.
            L[prefix+"0"+suffix]=x[prefix+"1"+suffix]
            L[prefix+"1"+suffix]=a.scale(x[prefix+"0"+suffix],-1)
    I={n:{} for n in GRADES}; I["c2"]={():s.Integer(1)}
    return j,x,A,eta,C,bar,b,R,F,cov,S0,Q,Smin,G,psi,L,I


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda name,fn:fn()
    j,x,A,eta,C,bar,b,R,F,cov,S0,forward,Smin,G,psi,L,I=stage("partial_model",setup)
    a,checks=j.a,Checks()
    Qmin=stage("partial_minimal_columns",lambda:j.columns(Smin))
    gf=j.Q(psi,Qmin); S=a.add(Smin,gf)
    Q=stage("partial_fixed_columns",lambda:j.columns(S))
    Lie=lambda P:j.act(P,L,0)
    contraction=lambda P:j.act(P,I,1)
    for z in FIELDS:
        checks.equal(a,Qmin[z],forward[z],"minimal forward "+z)
        checks.equal(a,Q[z],forward[z],"fixed forward "+z)
    for n in GRADES:
        d,gh,par=GRADES[n]
        checks.true(j.homogeneous_grade(Q[n],(d+1,gh+1,1-par)),"column grade "+n)
    checks.true(j.homogeneous_grade(S,(4,0,0)),"master grade")
    checks.true(j.homogeneous_grade(psi,(3,-1,1)),"fermion grade")
    checks.zero(j.Q(S0,Q),"pointwise invariant action")
    for m in range(4):
        for k in range(3): checks.equal(a,j.Q(cov[m][k],Q),a.scale(cross(a,C,cov[m])[k],-g),"Deta covariance")
        for n in range(4):
            for k in range(3): checks.equal(a,j.Q(F[m,n][k],Q),a.scale(cross(a,C,F[m,n])[k],-g),"curvature covariance")
    checks.equal(a,Q["c2"],a.scale(R,g),"derived curvature ghost")
    checks.zero(j.Q(R,Q),"abelian H curvature closed")
    checks.zero(Lie(psi),"global invariant fermion")
    checks.zero(contraction(psi),"horizontal fermion")
    checks.true(j.strip_light_ghost(gf)==gf,"GF independent of light ghost and all jets")
    def structural():
        for n in GRADES:
            checks.zero(a.add(Lie(Q[n]),a.scale(j.Q(L[n],Q),-1)),"LQ "+n)
            checks.equal(a,a.add(contraction(Q[n]),j.Q(I[n],Q)),a.scale(L[n],g),"Cartan iQ "+n)
            checks.zero(a.add(Lie(I[n]),a.scale(contraction(L[n]),-1)),"Li "+n)
            checks.zero(contraction(I[n]),"i square "+n)
            for mu in range(4):
                checks.equal(a,contraction(j.D(x[n],mu)),j.D(I[n],mu),"i derivative")
                checks.equal(a,Lie(j.D(x[n],mu)),j.D(L[n],mu),"L derivative")
        delta={n:j.strip_light_ghost(Q[n]) for n in GRADES if n!="c2"}
        for n in delta:
            checks.equal(a,j.Q(delta[n],delta),a.scale(a.mul(R,L[n]),-g*g),"Cartan delta square "+n)
        checks.zero(j.Q(R,delta),"delta R")
        return delta
    stage("partial_complete_source_Cartan_identities",structural)
    raise AssertionError("EXPECTED_FAILED_GATE_DISAPPEARED_REQUIRES_NEW_ADJUDICATION")


def obstruction_evidence(stage=None):
    """Freeze only the first failed gate; never run the downstream build."""
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda n,f:f()
    j,x,A,eta,C,bar,b,R,F,cov,S0,forward,Smin,G,psi,L,I=stage("obstruction_model",setup)
    a=j.a
    Qmin=stage("obstruction_minimal_columns",lambda:j.columns(Smin))
    gf=j.Q(psi,Qmin); S=a.add(Smin,gf)
    Q=stage("obstruction_fixed_columns",lambda:j.columns(S))
    lie=lambda P:j.act(P,L,0)
    contract=lambda P:j.act(P,I,1)
    for n in GRADES:
        assert a.add(lie(Q[n]),a.scale(j.Q(L[n],Q),-1))=={},"LQ "+n
        assert a.add(contract(Q[n]),j.Q(I[n],Q))==a.scale(L[n],g),"iQ "+n
        assert a.add(lie(I[n]),a.scale(contract(L[n]),-1))=={} and contract(I[n])=={}
    delta={n:j.strip_light_ghost(Q[n]) for n in GRADES if n!="c2"}
    actual=j.Q(delta["A20"],delta); expected=a.scale(a.mul(R,L["A20"]),-g*g)
    residual=a.add(actual,a.scale(expected,-1)); derivative=a.scale(j.D(R,0),-g)
    assert residual and residual==derivative and not expected
    # The selected monomial cannot be silently declared a zero density or an
    # IBP-null operator: pair it with the already present independent source.
    paired=a.mul(x["JA20"],residual)
    assert j.euler(paired,"JA20")==residual
    return {"schema":"PARTIAL_GAUGE_BV_BRIDGE_OBSTRUCTION_V1",
        "disposition":"BLOCKED_GLOBAL_CARTAN_SQUARE_OMITS_LOCAL_RESIDUAL_CONNECTION_TERM",
        "first_failed_gate":"delta^2 A20 = -g^2 R L A20", "base_generator_count":44,"canonical_pair_count":22,
        "passed_before_failure":{"full_44_generator_LQ_iQ_Li_i2":True,"all_reverse_source_columns_derived":True},
        "actions":{"invariant":j.record(S0),"minimal_master":j.record(Smin),"gauge_fermion":j.record(psi),"gauge_fixing":j.record(gf),"partial_fixed_master":j.record(S)},
        "minimal_images":{n:j.record(Qmin[n]) for n in GRADES},"images":{n:j.record(Q[n]) for n in GRADES},
        "obstruction":{"generator":"A20","L_generator":j.record(L["A20"]),"R":j.record(R),
            "delta_generator":j.record(delta["A20"]),"actual_square":j.record(actual),"expected_global_square":j.record(expected),
            "residual":j.record(residual),"minus_g_partial_R":j.record(derivative),"source_paired_residual":j.record(paired),"source_Euler_residual":j.record(j.euler(paired,"JA20"))},
        "interpretation":"local unfixed residual connection sees derivative of R; global L alone does not represent this local curvature action",
        "EOM_used":False,"M08_changed":False,"full_M08_replacement":False,"bridge_qualified":False,"HB1_C5_authorized":False,
        "cochain_dimensions_computed":False,"complete_square_or_master_audit_reached":False,"local_H_Ward_gate_reached":False,
        "external_specialist_review":False,"formal_authority":"34/39_UNCHANGED","finite_C1_GS":None}


if __name__=="__main__": print(json.dumps(obstruction_evidence(),sort_keys=True,separators=(",",":")))
