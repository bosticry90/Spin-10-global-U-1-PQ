"""Canonical loop contraction, complete-width and scientific-scope adversaries."""
import unittest
from copy import deepcopy
from a10_e5_scalar_uv import *
from audit_a10_e5_scalar_uv import adjudicate,execution_matches


class ScalarUVWidth(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.basis=cls.P['symmetric_heavy_width']['basis'];cls.forms=[mat(v['symmetric_covariant_form']) for v in cls.basis]
        cls.proj=[mat(v['spectral_projector']) for v in cls.basis]
        old=read(HERE/'frozen_a10_e5_ghost_normalization/primary.json')['ghost_metric']
        cls.GI=mat(old['old_width_metric']);cls.K=mat(old['canonical_kappa'])
        cls.w=alphabet()

    def test_01_two_distinct_complete_routes(self):
        self.assertTrue(adjudicate(self.P,self.R)['ordinary_g0_scalar_UV_membership_qualified'])

    def test_02_accepted_basis_is_authority_dependency_not_recount(self):
        slots,d=basis_inputs();self.assertEqual(d,self.P['accepted_scalar_basis'])
        self.assertEqual(len(slots),26);self.assertTrue(d['character_counts_and_rank_calculations_authenticated_not_rerun'])

    def test_03_exact_all_parameter_hessian_coverage(self):
        h=self.P['hessian_program'];self.assertEqual(len(h['programs']),29)
        self.assertEqual({p for v in h['programs'] for ps,f,c in v['canonical_second_differential_graphs'] for p in ps},set(self.P['literal_action_inventory']['all_34_real_parameters']))
        self.assertEqual(h['graph_coefficients'],331)

    def test_04_omitted_complex_direction_rejected(self):
        slots,_=basis_inputs();_,pot,_=action_inventory(slots)
        omitted={p for t in pot if t['term_id']=='potential_zK' for c,ps,fs in polynomial_signatures(t) for p in ps}
        self.assertEqual(omitted,{'zK_Re','zK_Im'})
        self.assertNotEqual(set(self.P['literal_action_inventory']['all_34_real_parameters'])-omitted,set(self.P['literal_action_inventory']['all_34_real_parameters']))
        self.assertTrue(self.P['mixed_complex_control']['zK_omission_would_fail_this_channel'])

    def test_05_PQ_and_kinetic_canonical_maps(self):
        for sec,v in self.P['scalar_global_and_kinetic']['sectors'].items():
            R=mat(v['PQ_matrix']);self.assertEqual(cm(R+R.T),s.zeros(DIM[sec]))
            self.assertEqual(mat(v['kinetic_metric']),s.eye(DIM[sec]))
        self.assertEqual(self.P['scalar_global_and_kinetic']['Spin_PQ_commutators_checked'],180)

    def test_06_coupled_trace_is_homogeneous_all_four_sectors(self):
        n=self.P['coupled_norm_control'];variables=[s.Symbol(n,real=True) for n in n['polynomial_variables']]
        P=s.Poly(s.sympify(n['Tr_H_squared'],locals={str(v):v for v in variables}),*variables)
        self.assertEqual([[list(p),str(c)] for p,c in P.terms()],n['Tr_H_squared_coefficients'])
        self.assertEqual(len(P.terms()),66)
        self.assertTrue(all(sum(2*v for v in p[:4])+sum(PARAM_DIM(n)*v for n,v in zip(n['norm_family_parameters'],p[4:]))==4 for p,c in P.terms()))

    def test_07_vacuum_constant_not_erased(self):
        mP,mSig,mp,mS=s.symbols('mPhi2 mSigma2 mphi2 mS2')
        value=s.sympify(self.P['coupled_norm_control']['vacuum_constant'])
        self.assertEqual(value,216*mP**2+1008*mSig**2+20*mp**2+2*mS**2)
        self.assertEqual(self.P['UV_construction']['vacuum_directions'],1)

    def test_08_boson_loop_sign_and_minus_potential(self):
        v=self.P['scalar_loop_sign'];self.assertEqual(s.sympify(v['Euclidean_boson_determinant_pole_residue']),-s.Symbol('M_squared')**2/(64*s.pi**2))
        self.assertTrue(self.P['literal_action_inventory']['physical_minus_potential_convention'])

    def test_09_raw_ambient_and_complex_traces_fail(self):
        v=self.P['negative_loop_trace_controls'];self.assertNotEqual(v['Phi_mass_canonical_trace'],v['Phi_mass_wrong_ambient_trace'])
        l,z,zb=s.symbols('lambdaS z_scalar zbar_scalar')
        correct=s.sympify(v['complex_singlet_correct_loop_trace']);wrong=s.sympify(v['complex_singlet_wrong_raw_trace'])
        self.assertEqual(correct,40*l*l*z*z*zb*zb);self.assertTrue(s.expand(wrong-correct).coeff(z,4))

    def test_10_mixed_phase_and_holomorphic_zero_control(self):
        v=self.P['mixed_complex_control'];self.assertEqual(v['Tr_H_squared_z4_conjugate_times_zD_coefficient'],'1120')
        self.assertEqual(s.sympify(v['off_shell_controls'][1]['loop_coefficient']),1120*s.I)
        self.assertTrue(v['same_chirality_loop_contraction_zero'])

    def test_11_complete_upper_bounds_distinct_methods(self):
        a=self.P['symmetric_heavy_width']['upper_bound_certificate'];b=self.R['symmetric_heavy_width']['upper_bound_certificate']
        self.assertEqual(a['rref_rank'],556);self.assertEqual(a['all_covariance_rows'],6732)
        self.assertEqual(len(b['allowed_weight_pairs']),17);self.assertEqual(len(b['connected_components']),5)
        self.assertEqual(sorted(len(c) for c in b['connected_components']),[1,1,3,6,6]);self.assertNotEqual(a['method'],b['method'])

    def test_12_projector_partition_and_all_relative_ranks(self):
        self.assertEqual(cm(sum(self.proj,s.zeros(33))),s.eye(33))
        for i,P in enumerate(self.proj):
            self.assertEqual(P.rank(),self.basis[i]['real_rank'])
            for j,Q in enumerate(self.proj):self.assertEqual(cm(P*Q),P if i==j else s.zeros(33))

    def test_13_pole_decomposition_exact_and_uniform_xi_fails(self):
        self.assertEqual(cm(sum(self.forms,s.zeros(33))),self.GI)
        self.assertEqual(cm(sum((s.sympify(v['relative_eigenvalue'])*K for v,K in zip(self.basis,self.forms)),s.zeros(33))),self.K)
        self.assertTrue(cm(self.K-8*self.GI).todok())

    def test_14_real_structure_and_invariant_bare_pairing_rejection(self):
        C=mat(self.P['symmetric_heavy_width']['real_structure'])
        for K in self.forms:self.assertEqual(cm(C.T*K*C),K.conjugate())
        Ds=read(HERE/'frozen_a10_e5_ghost_normalization/primary.json')['ghost_metric']['H_dual_matrices']
        self.assertTrue(any(cm(mat(D).T+mat(D)).todok() for D in Ds))
        for D in Ds:
            for K in self.forms:self.assertEqual(cm(mat(D).T*K+K*mat(D)),s.zeros(33))

    def test_15_canonical_sources_do_not_use_width_pairing(self):
        w=self.P['symmetric_heavy_width'];self.assertEqual(mat(w['evaluation_source_pairing']),s.eye(33))
        self.assertFalse(w['evaluation_source_metric_changed']);self.assertNotEqual(self.GI,s.eye(33))

    def test_16_full_BRST_primitives_retain_quartic_structure(self):
        self.assertEqual([v['quartic_ghost_coefficients'] for v in self.basis],[156,174,72,16,0])
        for v in self.basis:
            self.assertTrue(self.w.grade(decode_typed(v['primitive']),(3,-1,1)))
            self.assertTrue(self.w.grade(decode_typed(v['full_Q_primitive']),(4,0,0)))
            self.assertFalse(any(n.startswith('J') for word in decode_typed(v['full_Q_primitive']) for n,j in word))
        self.assertTrue(self.P['symmetric_heavy_width']['composite_RH_removed_negative_control'])

    def test_17_g0_primitive_sign_is_derived(self):
        for v in self.basis:
            psi=decode_typed(v['primitive']);Q={f'ub{i}':self.w.scale(self.w.var(f'L{i}'),-1) for i in M}
            result=act(psi,self.w,Q,'replay',1)
            self.assertEqual(result,decode_typed(v['g0_Q_primitive']))
            self.assertNotEqual(result,self.w.scale(result,-1))

    def test_18_IR_reference_and_insertion_limits_preserved(self):
        u=self.P['UV_construction'];self.assertTrue(u['ordinary_g0_IR_regulated_UV_prescription_nonempty'])
        for key in ('physical_IR_or_benchmark_vacuum_existence','all_gauge_couplings_restored','general_local_probe_contact_normalization','all_A4_A5_insertion_equivalences'):self.assertFalse(u[key])
        self.assertFalse(self.P['coupled_norm_control']['subfamily_used_as_proof_of_full_34_parameter_closure'])

    def test_19_full_authority_and_quantum_overclaims_rejected(self):
        for key in ('full_quantum_target_nonempty_proved','general_insertions_and_contacts_qualified','weighted_gF_quantum_A5_equivalence_proved','A1_A5_discharged','full_E5_PASS','sources_activated','all_scalar_beta_coefficients_freshly_expanded'):
            a=deepcopy(self.P);b=deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_20_start_hashes_reject_stale_basis_or_implementation(self):
        r=next(read(p) for p in OUT.glob('primary_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(r['fingerprint']);bad=deepcopy(r['fingerprint'])
        n=next(iter(bad['accepted_basis_input_sha256']));bad['accepted_basis_input_sha256'][n]='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)


if __name__=='__main__':unittest.main()
