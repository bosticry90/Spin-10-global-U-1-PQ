"""Covariance-versus-regulation, scalar trace and Ward negative controls."""
import unittest
from copy import deepcopy
from a10_e5_nonzero_regulator import *
from audit_a10_e5_nonzero_regulator import adjudicate,execution_matches,typed_expression


def spectral_matrix(row):
    local={n:s.Symbol(n,positive=True) for n in ('alpha','mu_squared')}
    return s.SparseMatrix(*row['shape'],{(i,j):s.sympify(v,locals=local) for i,j,v in row['entries']})


class NonzeroRegulator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')

    def test_01_completed_routes_authenticate_scientific_stop(self):
        a=adjudicate(self.P,self.R);self.assertEqual(a['scientific_gate'],STATUS)
        self.assertFalse(a['covariant_action_kernel_is_complete_quantum_regulator'])

    def test_02_all_generator_trace_pairs_and_internal_norm(self):
        idx=self.P['scalar_indices'];self.assertEqual(idx['all_trace_pair_coefficients'],8100)
        for sec,v in idx['trace_matrices'].items():self.assertEqual(mat(v),idx['sector_indices'][sec]*s.eye(45))
        self.assertEqual(mat(idx['total_trace_matrix']),84*s.eye(45))

    def test_03_physical_wedge_selfduality_and_realification(self):
        w=self.R['physical_wedge_replay_certificate'];self.assertEqual(w['all_Hodge_commutators_zero'],45)
        self.assertTrue(w['two_replacements_cannot_reach_complement']);self.assertTrue(w['realification_restores_full_trace'])
        self.assertEqual(self.P['scalar_indices']['sector_indices']['Sigma'],70)

    def test_04_wrong_complex_half_factor_changes_actual_pole(self):
        idx=self.P['scalar_indices'];wrong=idx['wrong_half_total_index']*g*g/(384*s.pi**2)
        correct=s.sympify(self.P['scalar_gauge_loop']['total_Euclidean_F_squared_pole_residue'],locals={'g10':g})
        self.assertNotEqual(clean(correct-wrong),0);self.assertEqual(idx['sector_indices']['phi'],2)

    def test_05_singlet_zero_gauge_response(self):
        p=self.P['scalar_gauge_loop']['sector_poles']['S'];self.assertEqual(p['transverse_Pi_pole_residue'],'0')
        self.assertTrue(self.P['scalar_indices']['singlet_no_gauge_current'])

    def test_06_full_formal_Berezinian_not_quantum_anomaly_proof(self):
        m=self.P['formal_measure'];self.assertEqual(m['integrated_field_coordinates_checked'],643)
        self.assertEqual(m['nonzero_diagonal_entries_before_sector_sum'],264)
        self.assertTrue(all(not v for v in m['sector_supertraces'].values()))
        self.assertFalse(m['continuum_measure_or_anomaly_freedom_proved'])

    def test_07_local_parameter_defect_is_nonzero(self):
        d=self.P['free_only_kernel_defect'];v=typed_expression(d['selected_p2_1_q2_4_reference2_1'])
        alpha=s.Symbol('alpha',positive=True);self.assertNotEqual(clean(v.subs(alpha,s.Rational(1,2))),0)
        self.assertTrue(d['ghost_Euler_coefficient_nonzero'])

    def test_08_constant_parameter_and_g0_limits_do_not_certify_local_g(self):
        v=typed_expression(self.P['free_only_kernel_defect']['full_free_only_kernel_defect_coefficient'])
        p2,q2=s.symbols('p_squared q_squared',positive=True)
        self.assertEqual(clean(v.subs(q2,p2)),0);self.assertEqual(v.subs(g,0),0)
        self.assertTrue(self.P['free_only_kernel_defect']['constant_parameter_test_would_miss_defect'])

    def test_09_typed_logarithms_have_exact_equal_derivations(self):
        for k in ('full_free_only_kernel_defect_coefficient','generic_first_alpha_coefficient'):
            self.assertEqual(s.simplify(typed_expression(self.P['free_only_kernel_defect'][k])-typed_expression(self.R['free_only_kernel_defect'][k])),0)
        z=s.Symbol('z_complex');self.assertNotEqual(s.expand_log(s.log(z**2)),2*s.log(z))

    def test_10_finite_kernel_breaking_is_not_local_polynomial(self):
        v=typed_expression(self.P['free_only_kernel_defect']['generic_first_alpha_coefficient'])
        p2=s.Symbol('p_squared',positive=True);self.assertNotEqual(s.diff(v,p2,4),0)
        self.assertFalse(self.P['free_only_kernel_defect']['finite_alpha_exact_local_polynomial_restoration_possible'])

    def test_11_resolvent_derivative_keeps_connection_variation(self):
        c=self.P['covariant_variation'];R=spectral_matrix(c['physical_generator_plane']);P=spectral_matrix(c['spectral_P'])
        delta=spectral_matrix(c['connection_variation_delta_P']);self.assertEqual(cm(delta),cm(R*P-P*R))
        self.assertTrue(c['missing_connection_variation_defect']);self.assertTrue(c['physical_pairing_variation_zero'])

    def test_12_scalar_operator_ordering_is_explicit(self):
        c=self.P['covariant_variation'];L=spectral_matrix(c['kinetic_L']);P=spectral_matrix(c['spectral_P']);R=spectral_matrix(c['physical_generator_plane'])
        self.assertEqual(spectral_matrix(c['kinetic_delta_LP']),cm(R*L*P-L*P*R))
        self.assertFalse(c['different_Dx_P_Dx_ordering_assumed_equivalent'])

    def test_13_all_four_transverse_momentum_outputs(self):
        L=self.P['scalar_gauge_loop'];Pi=mat(L['Pi_pole_tensor']);p=s.Matrix(s.symbols('p0_loop:4'))
        self.assertEqual(cm(p.T*Pi),s.zeros(1,4));self.assertEqual(cm(Pi*p),s.zeros(4,1))
        self.assertEqual(L['weighted_Feynman_integral'],'1/3')

    def test_14_omitted_seagull_gives_longitudinal_mass_pole(self):
        L=self.P['scalar_gauge_loop'];missing=mat(L['missing_seagull_longitudinal_pole'])
        self.assertTrue(missing.todok());self.assertTrue(all(s.sympify(v).has(s.Symbol('M_squared')) for v in missing if v))

    def test_15_Euclidean_and_Minkowski_counterterm_signs(self):
        L=self.P['scalar_gauge_loop'];loc={'g10':g}
        pole=s.sympify(L['total_Euclidean_F_squared_pole_residue'],locals=loc)
        self.assertEqual(clean(pole+s.sympify(L['total_Euclidean_counterterm_F_squared_residue'],locals=loc)),0)
        self.assertEqual(s.sympify(L['total_Minkowski_counterterm_F_squared_residue'],locals=loc),pole)

    def test_16_finite_nonlocal_scalar_loop_is_not_matching(self):
        L=self.P['scalar_gauge_loop'];v=s.sympify(L['nonexceptional_massless_finite_weight']);p2=s.Symbol('p_E_squared')
        self.assertEqual(clean(s.diff(v,p2)),-1/(3*p2));self.assertTrue(L['finite_nonlocal_kernel'])
        self.assertFalse(L['C1_GS_or_physical_matching_computed'])

    def test_17_fractional_kernel_fails_for_positive_alpha(self):
        r=self.P['regulator_stop'];alpha=s.Symbol('alpha',positive=True)
        pole=s.sympify(r['full_scalar_F_squared_pole_residue'],locals={'g10':g,'alpha':alpha})
        bare=s.sympify(self.P['scalar_gauge_loop']['total_Euclidean_F_squared_pole_residue'],locals={'g10':g})
        self.assertEqual(clean(pole-bare*(1+alpha)),0)
        self.assertNotEqual(pole.subs({g:1,alpha:s.Rational(1,2)}),0)
        self.assertTrue(r['positive_regulator_reference_does_not_remove_UV_log'])

    def test_18_proper_time_scalar_control_and_full_program_limits(self):
        p=self.P['proper_time_scalar_control'];self.assertEqual(clean(mat(p['heat_kernel_connection_variation']).trace()),0)
        self.assertFalse(p['complete_gauge_ghost_nonminimal_source_or_contact_regulator'])
        d=self.P['inactive_candidate'];self.assertTrue(d['actual_xi_cubic_retained'])
        self.assertIn('g[V,C_M]_H',d['heavy_kernel_full_Q_rule']);self.assertFalse(d['external_45_background_added'])

    def test_19_whole_quantum_success_and_promotion_overclaims_rejected(self):
        for key in ('complete_nonzero_g_quantum_restoration_proved','full_anomaly_freedom_proved','all_source_insertion_and_contact_identities_proved',
          'weighted_gF_quantum_A5_equivalence_proved','A1_A5_discharged','full_E5_PASS','sources_activated'):
            a=deepcopy(self.P);b=deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_20_start_hashes_reject_stale_input(self):
        r=next(read(p) for p in OUT.glob('primary_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(r['fingerprint']);bad=deepcopy(r['fingerprint']);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)


if __name__=='__main__':unittest.main()
