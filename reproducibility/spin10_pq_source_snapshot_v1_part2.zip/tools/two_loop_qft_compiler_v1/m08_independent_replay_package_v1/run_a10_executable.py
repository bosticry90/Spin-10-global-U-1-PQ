"""Measured read-only new-route runner; no historical calculation rerun."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_phase_c_scalar_action

def main():
    import importlib,json,os,time
    from profile_pole_blind_workflow import process_counters
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    route=sys.argv[1]
    assert route in ('a10_executable_action','a10_executable_primary','a10_executable_replay',
                     'a10_executable_source_interface','a10_executable_source_interface_replay')
    reads=set(); writes=[]
    def hook(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)): return
        path=Path(os.fsdecode(args[0])); mode=args[1] or ''; flags=args[2] if len(args)>2 else 0
        if any(c in mode for c in 'wax+') or flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
            writes.append(str(path)); raise PermissionError('EXECUTABLE_CALCULATION_WRITES_FORBIDDEN')
        reads.add(str(path.resolve()))
    sys.addaudithook(hook); start=time.perf_counter(); first=process_counters(); stages=[]
    def stage(name,fn):
        print('STAGE '+name,flush=True); t=time.perf_counter(); before=process_counters()
        try:return fn()
        finally:
            after=process_counters(); stages.append({'name':name,'wall_seconds':time.perf_counter()-t,
                'cpu_seconds':after['cpu_seconds']-before['cpu_seconds'],'peak_process_working_set_bytes':after['peak_working_set_bytes']})
    module=stage('module_import',lambda:importlib.import_module(route))
    result=module.build() if route=='a10_executable_action' else module.build(stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    last=process_counters()
    print('METRICS '+json.dumps({'route':route,'stages':stages,'wall_seconds':time.perf_counter()-start,
        'cpu_seconds':last['cpu_seconds']-first['cpu_seconds'],'peak_process_working_set_bytes':last['peak_working_set_bytes'],
        'read_paths':sorted(reads),'write_open_attempts':writes,'workspace_files_written':0,
        'limits':'Shared runtime/libraries; read paths count accesses, not byte volume; peak is process cumulative.'},sort_keys=True,separators=(',',':')),flush=True)

if __name__=='__main__':main()
