"""Exact INT8 multiplicity-block conjugation, with unchanged canonical basis.

K_source,target pulls conjugated source coordinate components back to target
coordinates. B[target,source] then acts anti-linearly on covector coefficients.
No slot permutation, statistics quotient, A3 coefficient fitting, or loop input.
"""
from functools import lru_cache
from itertools import product
from collections import defaultdict
import hashlib
import json
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from scalar_bridge_primary_v3 import qualified_duals

HERE = br.HERE
OUT = HERE / 'frozen_int8_block_conjugation_v2'
CONJ = {'Phi':'Phi', 'Sigma':'SigmaBar', 'SigmaBar':'Sigma', 'phi':'phiBar', 'phiBar':'phi',
        'S':'SBar', 'SBar':'S', 'heavy':'heavy', 'adjoint':'adjoint'}


def exact(m):
    return sp.SparseMatrix(m).applyfunc(sp.simplify)


def dual_label(r):
    return r[1], r[0], r[2], -r[3]


class BlockConjugation:
    def __init__(self):
        self.duals = qualified_duals()
        ledger = br.load(HERE / 'frozen_intertwiner_channel_basis/INT3_binary_channel_ledger.json')
        self.components = ledger['module_components']
        self.binary = {tuple(r['ordered_character_pair']):r['blocks'] for r in ledger['ordered_pair_blocks']}
        self.descriptors = {r['family_id']:r for r in br.load(HERE/'frozen_intertwiner_basis_int4r_int15/INT6_ordered_invariant_channel_families.json')['family_descriptors']}
        self.by_id = {r['component_id']:r for rows in self.components.values() for r in rows}
        self.partner = {}
        for cid, row in self.by_id.items():
            target = [r for r in self.components[row['family']]
                      if tuple(r['H_label']) == dual_label(tuple(row['H_label']))
                      and r['PQ_charge'] == -row['PQ_charge'] and r['source_sector'] == CONJ[row['source_sector']]]
            assert len(target) == 1 and target[0]['copy_multiplicity'] == row['copy_multiplicity'], cid
            self.partner[cid] = target[0]['component_id']
        self.w = {}; self.carrier_rows = []; self.module_rows = []; self.factor_rows = []; self.pairing_rows = []
        self.l3 = {}; self.l2 = {}; self.tau = {}
        self.binary_lookup = {pair:{(r['left_component_id'],r['right_component_id'],tuple(r['output_H_label']),r['output_PQ_charge']):i for i,r in enumerate(rows)} for pair,rows in self.binary.items()}
        self.address_lookup = {}

    @classmethod
    def from_frozen(cls):
        """Load certified factors and deterministic addresses, without construction.

        ``image`` returns every exact address/coefficient in conjugation's image.
        Calling it on the conjugate block gives the anti-linear inverse map.
        """
        cp=br.load(OUT/'INT8V2_checkpoint.json')
        assert cp['status']=='PASS' and cp['INT8']=='PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2'
        assert cp['artifact_sha256']==br.canonical({k:v for k,v in cp.items() if k!='artifact_sha256'})
        for name,digest in cp['artifacts'].items():
            assert hashlib.sha256((OUT/name).read_bytes()).hexdigest()==digest
        obj=cls()
        for row in br.load(OUT/'INT8V2_physical_copy_maps.json')['components']:
            obj.w[row['source_component']]=br.matrix(row['copy_matrix_source_from_target'])
        for row in br.load(OUT/'INT8V2_binary_terminal_maps.json')['binary_factors']:
            key=tuple(tuple(r) for r in row['source_key']) if row['group']=='SU3' else tuple(row['source_key'])
            store=obj.l3 if row['group']=='SU3' else obj.l2
            store[key]=br.matrix(row['projection_conjugation_matrix'])
        for fid,desc in obj.descriptors.items():
            lookup={}
            for key,card,b,r in obj.blocks(desc):
                label=tuple(b['output_H_label']) if b else (0,0,0,0)
                lookup[(tuple(obj.block_slots(desc,key)),label)]=key
            obj.address_lookup[fid]=lookup
        return obj

    @lru_cache(None)
    def k3(self, label):
        f = self.duals.f3[label]; target = self.duals.f3[(label[1], label[0])]
        source_basis = br.matrix(f['trace_kernel_basis'])
        ambient = [tuple(tuple(x) for x in row) for row in f['ambient_monomials']]
        target_ambient = [tuple(tuple(x) for x in row) for row in target['ambient_monomials']]
        indices = {row:i for i,row in enumerate(ambient)}
        perm = sp.SparseMatrix(len(ambient),len(target_ambient),{(indices[(y,x)],j):1 for j,(x,y) in enumerate(target_ambient)})
        raw = perm * br.matrix(target['trace_kernel_basis'])
        k = raw[f['coordinate_rows'],:]
        assert source_basis*k == raw
        return sp.ImmutableSparseMatrix(k)

    @lru_cache(None)
    def k2(self, n):
        return sp.ImmutableSparseMatrix(n+1,n+1,{(j,n-j):(-1)**j for j in range(n+1)})

    @lru_cache(None)
    def k(self, label):
        return sp.kronecker_product(self.k3(label[:2]),self.k2(label[2]))

    def qualify_carriers(self):
        for label,f in sorted(self.duals.f3.items()):
            target=(label[1],label[0]); k=self.k3(label)
            assert k*self.k3(target)==sp.eye(k.rows)
            gs={n:br.matrix(v) for n,v in f['generators'].items()}
            gt={n:br.matrix(v) for n,v in self.duals.f3[target]['generators'].items()}
            for h in ('H1','H2'):
                assert gs[h]*k == -k*gt[h]
            for e,ff in [('E12','F12'),('E23','F23'),('E13','F13')]:
                assert gs[e]*k == -k*gt[ff] and gs[ff]*k == -k*gt[e]
            self.carrier_rows.append({'group':'SU3','source':label,'target':target,'K':br.serialize(k),
                                      'ambient_swap_and_generator_residuals':'ZERO_EXACT','involution':'IDENTITY'})
        for n,f in sorted(self.duals.f2.items()):
            k=self.k2(n); gs={name:br.matrix(v) for name,v in f['generators'].items()}
            assert k*k==(-1)**n*sp.eye(n+1)
            assert gs['H']*k == -k*gs['H']
            assert gs['E']*k == -k*gs['F'] and gs['F']*k == -k*gs['E']
            self.carrier_rows.append({'group':'SU2','source':n,'target':n,'K':br.serialize(k),
                                      'compact_generator_residuals':'ZERO_EXACT','carrier_square':(-1)**n,
                                      'half_integer_caveat':'Carrier pseudoreality is compensated by physical conjugate-copy transport; invariant B squares to identity.'})

    def physical_modules(self):
        historical=br.load(HERE/'frozen_intertwiner_basis_int4r_int15/INT7_exact_physical_role_adapters.json')
        current=br.load(HERE/'frozen_scalar_adapter_v2/SA9_scalar_role_adapter_V2.json')
        copies=br.load(HERE/'frozen_scalar_adapter_v2/SA2_SA8_copy_certificates.json')['copies']
        canonical=sp.SparseMatrix(328,328,{(i,j):sp.sympify(v) for j,col in enumerate(br.load(HERE.parent/'sm_weight_basis.json')['columns']) for i,v in col['sparse_parent_coordinates']})
        reg10=br.load(HERE/'frozen_irrep_carrier_registry/REG10_physical_module_regressions.json')
        c3=br.load(HERE/'frozen_c3/C3_representation_basis.json')
        for family,rows in self.components.items():
            ids=[r['component_id'] for r in rows]
            if family=='S':
                am={r['component_id']:br.matrix(r['matrix'])*canonical.T for r in current['component_adapters']['S']}
                pm={cid:sp.Matrix.hstack(*(br.matrix(r['P_registry']) for r in copies if r['component_id']==cid)) for cid in ids}
            else:
                key='heavy_module' if family=='H' else 'residual_adjoint'
                data=c3['heavy_basis' if family=='H' else 'h_basis']
                raw=sp.SparseMatrix(45,len(data),{(r['index'],j):sp.sympify(r['coefficient']) for j,col in enumerate(data) for r in col['raw_so10_coordinates']})
                pinv=(raw.H*raw).inv()*raw.H
                am={r['component_id']:br.matrix(r['matrix'])*pinv for r in historical['component_adapters'][family]}
                physical=raw*br.matrix(reg10[key]['adapter']); offset=0; pm={}
                bylabel={tuple(r['H_label']):r['component_id'] for r in rows}
                for label in reg10[key]['labels']:
                    cid=bylabel[tuple(label)]; d=am[cid].rows; pm[cid]=physical[:,offset:offset+d]; offset+=d
            m=sp.Matrix.vstack(*(am[cid] for cid in ids)); p=sp.Matrix.hstack(*(pm[cid] for cid in ids))
            assert exact(m*p)==sp.eye(m.rows)
            global_k=exact(sp.conjugate(m)*p)
            assert exact(sp.conjugate(p)*global_k-p)==sp.zeros(*p.shape)
            assert exact(global_k*sp.conjugate(global_k))==sp.eye(m.rows)
            offsets={}; off=0
            for cid in ids: offsets[cid]=off; off+=am[cid].rows
            allowed=sp.zeros(m.rows)
            for cid in ids:
                target=self.partner[cid]; r=self.by_id[cid]; label=tuple(r['H_label']); n=r['copy_multiplicity']; d=self.k(label).rows
                kk=exact(sp.conjugate(am[cid])*pm[target]); k0=self.k(label); w=sp.zeros(n)
                for i in range(n):
                    for j in range(n):
                        part=exact(kk[i*d:(i+1)*d,j*d:(j+1)*d]*k0.inv())
                        assert part==part[0,0]*sp.eye(d), (cid,'non-Schur physical copy conjugation')
                        w[i,j]=part[0,0]
                assert exact(kk-sp.kronecker_product(w,k0))==sp.zeros(*kk.shape)
                assert w.det()!=0
                self.w[cid]=sp.ImmutableSparseMatrix(w)
                i,j=offsets[cid],offsets[target]; allowed[i:i+n*d,j:j+n*d]=kk
                self.module_rows.append({'family':family,'source_component':cid,'target_component':target,
                    'source_label':label,'target_label':dual_label(label),'source_PQ':r['PQ_charge'],
                    'target_PQ':-r['PQ_charge'],'copy_matrix_source_from_target':br.serialize(w),
                    'physical_K':br.serialize(kk),'physical_columns':br.serialize(pm[cid]),
                    'target_physical_columns':br.serialize(pm[target]),'physical_extractor':br.serialize(am[cid]),
                    'physical_conjugation_residual':'ZERO_EXACT','no_out_of_block_leakage':'ZERO_EXACT'})
            assert exact(global_k-allowed)==sp.zeros(*global_k.shape), (family,'physical conjugation leakage')
        for cid,w in self.w.items():
            n=self.by_id[cid]['H_label'][2]
            assert exact(sp.conjugate(w)*self.w[self.partner[cid]])==(-1)**n*sp.eye(w.rows)

    def qualify_binary_factors(self):
        for group,cs0,ds0,ks,js,store in (
                ('SU3',self.duals.c3,self.duals.d3,self.k3,self.duals.j3,self.l3),
                ('SU2',self.duals.c2,self.duals.d2,self.k2,self.duals.j2,self.l2)):
            partner=(lambda r:(r[1],r[0])) if group=='SU3' else (lambda r:r)
            for key,cs in sorted(cs0.items()):
                a,b,o=key; pk=tuple(partner(r) for r in key); cps=cs0[pk]; dps=ds0[pk]
                ka,kb,ko=ks(a),ks(b),ks(o); kp=sp.kronecker_product(ka,kb)
                mat=sp.zeros(len(cps),len(cs))
                for si,d in enumerate(ds0[key]):
                    transformed=exact(sp.conjugate(d)*kp)
                    for ti,c in enumerate(cps):
                        part=exact(ko.inv()*transformed*c)
                        assert part==part[0,0]*sp.eye(part.rows), (group,key,'non-Schur conjugated projection')
                        mat[ti,si]=part[0,0]
                    reconstructed=ko*sum((mat[j,si]*dj for j,dj in enumerate(dps)),sp.zeros(*dps[0].shape))
                    assert exact(transformed-reconstructed)==sp.zeros(*transformed.shape)
                assert mat.det()!=0
                # Conjugated embeddings must have the inverse coefficient transport.
                cinv=exact(mat.T.inv())
                for si,c in enumerate(cs):
                    transformed=exact(kp.inv()*sp.conjugate(c)*ko)
                    assert exact(transformed-sum((cinv[j,si]*cp for j,cp in enumerate(cps)),sp.zeros(*cps[0].shape)))==sp.zeros(*transformed.shape)
                store[key]=sp.ImmutableSparseMatrix(mat)
                self.factor_rows.append({'group':group,'source_key':key,'target_key':pk,
                    'projection_conjugation_matrix':br.serialize(mat),'embedding_inverse_transport':br.serialize(cinv),
                    'projection_full_residual':'ZERO_EXACT','embedding_full_residual':'ZERO_EXACT','no_leakage':'ZERO_EXACT'})
            for key,mat in store.items():
                pk=tuple(partner(r) for r in key)
                assert store[pk]*sp.conjugate(mat)==sp.eye(mat.rows)
            for o,j in sorted(js.items()):
                oo=partner(o); k=ks(o); kb=ks(oo)
                target=exact(k.T*sp.conjugate(j.T)*kb); jt=js[oo].T
                pos=next((i,q) for i in range(jt.rows) for q in range(jt.cols) if jt[i,q]!=0)
                tau=sp.simplify(target[pos]/jt[pos])
                assert exact(target-tau*jt)==sp.zeros(*target.shape)
                # Source/primal dual covector dictionary is transported through J.
                dual_map=exact(js[oo].T.inv()*k.T*sp.conjugate(j.T))
                assert exact(js[oo].T*dual_map-k.T*sp.conjugate(j.T))==sp.zeros(*dual_map.shape)
                self.pairing_rows.append({'group':group,'source':o,'target':oo,'terminal_phase':str(tau),
                    'dual_covector_transport':br.serialize(dual_map),'pairing_residual':'ZERO_EXACT'})

    @lru_cache(None)
    def terminal_phase(self,label):
        j=self.duals.pairing(label).T; jt=self.duals.pairing(dual_label(label)).T
        target=exact(self.k(label).T*sp.conjugate(j)*self.k(dual_label(label)))
        pos=next((i,q) for i in range(jt.rows) for q in range(jt.cols) if jt[i,q]!=0)
        phase=sp.simplify(target[pos]/jt[pos]); assert exact(target-phase*jt)==sp.zeros(*target.shape)
        return phase

    def binary_partner(self,pair,bi):
        b=self.binary[pair][bi]
        return self.binary_lookup[pair][(self.partner[b['left_component_id']],self.partner[b['right_component_id']],
                                        dual_label(tuple(b['output_H_label'])),-b['output_PQ_charge'])]

    @lru_cache(None)
    def binary_label_matrix(self,a,bb,o):
        return self.l3[(a[:2],bb[:2],o[:2])]*self.l2[(a[2],bb[2],o[2])][0,0]

    def binary_matrix(self,b):
        a,bb,o=(tuple(b[k]) for k in ('left_H_label','right_H_label','output_H_label'))
        return self.binary_label_matrix(a,bb,o)

    def blocks(self,desc):
        f=tuple(desc['ordered_character_families']); degree=len(f)
        for ti,t in enumerate(desc['terminal_channels']):
            if degree<=1:
                yield (ti,),t['cardinality'],None,None
            elif degree in (2,3):
                b=self.binary[f[:2]][t['binary_block_index' if degree==2 else 'left_binary_block_index']]
                yield (ti,),t['cardinality'],b,None
            else:
                for lc,li in enumerate(t['left_binary_block_indices']):
                    for rc,ri in enumerate(t['right_binary_block_indices']):
                        b=self.binary[f[:2]][li]; r=self.binary[f[2:]][ri]
                        yield (ti,lc,rc),b['cardinality']*r['cardinality'],b,r

    def block_slots(self,desc,key):
        f=tuple(desc['ordered_character_families']); degree=len(f); t=desc['terminal_channels'][key[0]]
        if degree==0: return []
        if degree==1: return [self.components[f[0]][t['component_index']]['component_id']]
        bi=t['left_binary_block_indices'][key[1]] if degree==4 else t['binary_block_index' if degree==2 else 'left_binary_block_index']
        b=self.binary[f[:2]][bi]
        slots=[b['left_component_id'],b['right_component_id']]
        if degree==3: slots.append(self.components[f[2]][t['third_component_index']]['component_id'])
        if degree==4:
            r=self.binary[f[2:]][t['right_binary_block_indices'][key[2]]]
            slots += [r['left_component_id'],r['right_component_id']]
        return slots

    def qualify_families(self):
        rows=[]; largest=None; qualified_patterns=set(); pattern_rows=[]
        for fid,desc in self.descriptors.items():
            f=tuple(desc['ordered_character_families']); degree=len(f); lookup={}
            for key,card,b,r in self.blocks(desc):
                slots=self.block_slots(desc,key)
                label=tuple(b['output_H_label']) if b else (0,0,0,0)
                lk=(tuple(slots),label)
                assert lk not in lookup, ('duplicate block',fid,lk)
                lookup[lk]=key
                if largest is None or card>largest['multiplicity']:
                    largest={'family_id':fid,'key':list(key),'multiplicity':card}
            self.address_lookup[fid]=lookup
            digest=hashlib.sha256(); total=0; count=0; target_keys=set(); monomial=0; scalar_blocks=0
            for key,card,b,r in self.blocks(desc):
                slots=self.block_slots(desc,key); targetslots=tuple(self.partner[cid] for cid in slots)
                label=tuple(b['output_H_label']) if b else (0,0,0,0)
                targetkey=lookup[(targetslots,dual_label(label))]
                targetdesc=desc['terminal_channels'][targetkey[0]]
                if degree==4:
                    tb=self.binary[f[:2]][targetdesc['left_binary_block_indices'][targetkey[1]]]
                    tr=self.binary[f[2:]][targetdesc['right_binary_block_indices'][targetkey[2]]]
                    targetcard=tb['cardinality']*tr['cardinality']
                else: targetcard=targetdesc['cardinality']
                assert card==targetcard
                assert targetkey not in target_keys
                target_keys.add(targetkey)
                assert lookup[(tuple(self.partner[cid] for cid in targetslots),label)]==key
                phase=self.terminal_phase(label) if degree>=3 else sp.Integer(1)
                # Factors have been qualified on full carrier tensors, not counts.
                factors=[self.w[cid].T for cid in slots]
                if b: factors.append(self.binary_matrix(b))
                if r: factors.append(self.binary_matrix(r))
                prodsize=1
                for factor in factors: prodsize*=factor.rows
                assert prodsize==card
                backward=[self.w[cid].T for cid in targetslots]
                if b:
                    tb=self.binary[f[:2]][self.binary_partner(f[:2],self.binary_lookup[f[:2]][(b['left_component_id'],b['right_component_id'],label,b['output_PQ_charge'])])]
                    backward.append(self.binary_matrix(tb))
                if r:
                    rl=tuple(r['output_H_label'])
                    tr=self.binary[f[2:]][self.binary_partner(f[2:],self.binary_lookup[f[2:]][(r['left_component_id'],r['right_component_id'],rl,r['output_PQ_charge'])])]
                    backward.append(self.binary_matrix(tr))
                reverse_phase=self.terminal_phase(dual_label(label)) if degree>=3 else sp.Integer(1)
                pattern=(str(phase),str(reverse_phase),tuple(tuple(tuple(v) for v in q.tolist()) for q in factors),tuple(tuple(tuple(v) for v in q.tolist()) for q in backward))
                if pattern not in qualified_patterns:
                    bf=phase*sp.kronecker_product(*factors) if factors else sp.ones(1)
                    brf=reverse_phase*sp.kronecker_product(*backward) if backward else sp.ones(1)
                    assert bf.det()!=0 and bf.rank()==card
                    assert exact(brf*sp.conjugate(bf))==sp.eye(card), (fid,key,'fusion involution')
                    qualified_patterns.add(pattern)
                    pattern_rows.append({'factor_order_B':br.serialize(bf),'factor_order_B_reverse':br.serialize(brf),
                                         'rank':card,'determinant':str(bf.det()),'antilinear_involution':'ZERO_EXACT'})
                ismonomial=all(sum(q[j,i]!=0 for j in range(q.rows))==1 for q in factors for i in range(q.cols))
                monomial+=int(ismonomial); scalar_blocks+=int(card==1)
                digest.update((json.dumps([key,targetkey,slots,label,card,str(phase)],separators=(',',':'))+'\n').encode())
                count+=1
                total+=card
            assert total==desc['addressable_invariant_count']
            rows.append({'family_id':fid,'ordered_character_families':f,'addressable_count':total,
                         'block_count':count,'block_coverage_sha256':digest.hexdigest(),
                         'multiplicity_one_blocks':scalar_blocks,'monomial_blocks':monomial,
                         'B_descriptor':'INT6 terminal enumeration + exact module W transposes + binary L matrices + terminal phase; frozen address digit order, no slot permutation',
                         'source_target_block_bijection':True,'coverage':'COMPLETE_FACTORIZED',
                         'tensor_reconstruction':'ZERO_EXACT_BY_FULL_FACTOR_IDENTITIES',
                         'involution':'ZERO_EXACT_EVERY_DISTINCT_MATRIX_PATTERN',
                         'leakage':'ZERO_EXACT_BY_FULL_FACTOR_IDENTITIES'})
            print('INT8V2_FAMILY',fid,total,count,flush=True)
        self.pattern_rows=pattern_rows
        return rows,largest

    def addresses(self,fid,key):
        desc=self.descriptors[fid]; degree=desc['arity']; slots=self.block_slots(desc,key)
        copies=[range(self.by_id[cid]['copy_multiplicity']) for cid in slots]
        t=desc['terminal_channels'][key[0]]; f=tuple(desc['ordered_character_families'])
        if degree==0: yield {'family_id':fid,'terminal_channel_index':key[0],'digits':[]}; return
        if degree==1:
            for (c,) in product(*copies): yield {'family_id':fid,'terminal_channel_index':key[0],'digits':[c]}
            return
        bi=t['binary_block_index' if degree==2 else 'left_binary_block_index'] if degree<4 else t['left_binary_block_indices'][key[1]]
        b=self.binary[f[:2]][bi]; channels=range(b['SU3_channel_range'][1])
        right=range(self.binary[f[2:]][t['right_binary_block_indices'][key[2]]]['SU3_channel_range'][1]) if degree==4 else range(1)
        for c in product(*copies):
            for a in channels:
                for bb in right:
                    digits=[*c[:2],a] if degree==2 else [c[0],c[1],a,c[2]] if degree==3 else [key[1],key[2],c[0],c[1],a,c[2],c[3],bb]
                    yield {'family_id':fid,'terminal_channel_index':key[0],'digits':digits}

    def address_parts(self,address):
        fid=address['family_id']; desc=self.descriptors[fid]; degree=desc['arity']; x=address['digits']; f=tuple(desc['ordered_character_families']); t=desc['terminal_channels'][address['terminal_channel_index']]
        key=(address['terminal_channel_index'],x[0],x[1]) if degree==4 else (address['terminal_channel_index'],)
        slots=self.block_slots(desc,key)
        if degree<=1: return desc,key,slots,x,None,None,0,0
        b=self.binary[f[:2]][t['binary_block_index' if degree==2 else 'left_binary_block_index'] if degree<4 else t['left_binary_block_indices'][x[0]]]
        r=self.binary[f[2:]][t['right_binary_block_indices'][x[1]]] if degree==4 else None
        copies=x[:2] if degree==2 else [x[0],x[1],x[3]] if degree==3 else [x[2],x[3],x[5],x[6]]
        return desc,key,slots,copies,b,r,x[2] if degree<4 else x[4],x[7] if degree==4 else 0

    def image(self,address):
        desc,key,slots,copies,b,r,a,bb=self.address_parts(address); degree=desc['arity']; fid=desc['family_id']
        label=tuple(b['output_H_label']) if b else (0,0,0,0)
        tk=self.address_lookup[fid][(tuple(self.partner[cid] for cid in slots),dual_label(label))]
        choices=[[ (j,self.w[cid][i,j]) for j in range(self.w[cid].cols) if self.w[cid][i,j]!=0] for cid,i in zip(slots,copies)]
        ls=[(j,self.binary_matrix(b)[j,a]) for j in range(self.binary_matrix(b).rows) if self.binary_matrix(b)[j,a]!=0] if b else [(0,sp.Integer(1))]
        rs=[(j,self.binary_matrix(r)[j,bb]) for j in range(self.binary_matrix(r).rows) if self.binary_matrix(r)[j,bb]!=0] if r else [(0,sp.Integer(1))]
        phase=self.terminal_phase(label) if degree>=3 else sp.Integer(1)
        for cs in product(*choices):
            c=[j for j,v in cs]; scalar=phase*sp.prod(v for j,v in cs)
            for (aa,va),(bbb,vb) in product(ls,rs):
                digits=[] if degree==0 else c if degree==1 else [*c,aa] if degree==2 else [c[0],c[1],aa,c[2]] if degree==3 else [tk[1],tk[2],c[0],c[1],aa,c[2],c[3],bbb]
                yield {'family_id':fid,'terminal_channel_index':tk[0],'digits':digits},sp.simplify(scalar*va*vb)


def address_key(a):
    return a['family_id'],a['terminal_channel_index'],tuple(a['digits'])
