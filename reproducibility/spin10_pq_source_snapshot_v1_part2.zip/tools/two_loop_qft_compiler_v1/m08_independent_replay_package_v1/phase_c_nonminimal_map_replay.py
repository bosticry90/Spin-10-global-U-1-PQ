"""Independent word/cotangent reconstruction of the heavy auxiliary map."""
import itertools
import json
import sympy as s
from nonabelian_m08_semantic_replay import geometry
from source_domain_transport_replay import DomainWords

IDS=[0,1,3,4,11,12,13,19,38,44]; H=[0,1,3,4,11]; M=[12,13,19,38,44]
g=s.Symbol('g10')


def build(stage=lambda n,fn:fn()):
    f,_,_=stage('physical_matrix_geometry',geometry); w=DomainWords(0)
    fields={**{'C'+str(i):1 for i in IDS},**{'ubar'+str(i):1 for i in M},**{'Lambda'+str(i):0 for i in M}}
    w.pairs=[(n,'J'+n) for n in fields]; w.p=fields|{J:1-fields[n] for n,J in w.pairs}
    x={n:w.var(n) for n in w.p}; U=dict(x)
    for i in M:
        U['Lambda'+str(i)]=w.add(x['Lambda'+str(i)],*(w.scale(w.mul(x['C'+str(h)],x['ubar'+str(j)]),-g*f.get((j,h,i),0)) for j in M for h in H))
        U['Jubar'+str(i)]=w.add(x['Jubar'+str(i)],*(w.scale(w.mul(x['JLambda'+str(j)],x['C'+str(h)]),-g*f.get((i,h,j),0)) for j in M for h in H))
    for h in H:
        U['JC'+str(h)]=w.add(x['JC'+str(h)],*(w.scale(w.mul(x['JLambda'+str(i)],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for j,i in itertools.product(M,repeat=2)))
    for z in fields:
        for y in fields:
            expected={():s.Integer((-1)**fields[z])} if z==y else {}
            assert not w.add(w.bracket(U[z],U['J'+y]),w.scale(expected,-1)),(z,y)
    for (_,J),(_,K) in itertools.combinations_with_replacement(w.pairs,2): assert not w.bracket(U[J],U[K]),(J,K)
    inverse={n:{word:s.expand(c.subs(g,-g)) for word,c in P.items()} for n,P in U.items()}
    for n in x:
        assert not w.add(w.replace(U[n],inverse),w.scale(x[n],-1)),('inverse',n)
        assert not w.add(w.replace(inverse[n],U),w.scale(x[n],-1)),('forward',n)
    qc={'C'+str(i):w.add(*(w.scale(w.mul(x['C'+str(j)],x['C'+str(k)]),-g*f.get((i,j,k),0)/2) for j,k in itertools.product(IDS,repeat=2))) for i in IDS}
    oldS=w.add(*(w.mul(x['J'+z],P) for z,P in qc.items()),*(w.scale(w.mul(x['Jubar'+str(i)],x['Lambda'+str(i)]),-1) for i in M))
    newS=w.replace(oldS,U)
    for i in M:
        expected=w.add(w.scale(x['Lambda'+str(i)],-1),*(w.scale(w.mul(x['C'+str(h)],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for h in H for j in M))
        assert not w.add(w.EL(newS,'Jubar'+str(i)),w.scale(expected,-1))
    return {'schema':'PHASE_C_HEAVY_CANONICAL_COORDINATE_MAP_V1','status':'PASS','pairs':len(w.pairs),'field_source_brackets':len(w.pairs)**2,'source_cross_brackets':len(w.pairs)*(len(w.pairs)+1)//2,
        'old_coordinates_in_new':{n:w.record(P) for n,P in U.items()},'inverse':'Reverse g10 signs in the triangular shifts; C,ubar,JLambda unchanged','inverse_checks':2*len(x),'source_action_transport':w.record(newS),
        'field_formula':'b0=Lambda-g10 ad_H(c)^T ubar','physical_action_changed':False,'active_sources_added':False}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    print(json.dumps(build(),sort_keys=True,separators=(',',':')))
