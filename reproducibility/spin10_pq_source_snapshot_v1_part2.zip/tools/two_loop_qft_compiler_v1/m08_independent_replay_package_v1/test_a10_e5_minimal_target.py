"""Adversaries for the exact source class and conditional target distinction."""
import unittest
from copy import deepcopy
from a10_e5_minimal_target import *
from audit_a10_e5_minimal_target import adjudicate,execution_matches


class MinimalTarget(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json');cls.w=alphabet()

    def test_01_independent_routes_agree(self):
        self.assertEqual(adjudicate(self.P,self.R)['scientific_gate'],STATUS)

    def test_02_surviving_cubic_refutes_full_Gaussian(self):
        P=decode_typed(self.P['g0_split']['nonquadratic_residual'])
        self.assertEqual(P[((('C12',()),('L13',()),('ub44',())))],s.sqrt(2)*s.I*xi/4)
        self.assertFalse(any(v.has(g) for v in P.values()))
        a=deepcopy(self.P);b=deepcopy(self.R)
        a['g0_split']['nonquadratic_residual']=b['g0_split']['nonquadratic_residual']=[]
        with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_03_real_heavy_domain_and_auxiliary_Euler(self):
        N=self.P['nonlinear_g0_witness'];a,b,c=[mat(v) for v in N['real_parent_vectors']]
        for v in (a,b,c):self.assertEqual(v.conjugate(),v)
        self.assertEqual(clean((c.T*c)[0]),s.sympify(N['squared_bracket_norm']))
        self.assertTrue(N['auxiliary_Euler']);self.assertTrue(N['heavy_projector_verified'])

    def test_04_all_sources_retained_and_absence_not_deletion(self):
        c=self.P['g0_split'];active=set(c['affine_BV_source_drivers']);absent=set(c['absent_BV_sources'])
        self.assertFalse(active&absent);self.assertEqual(active|absent,{J for z,J in self.w.pairs})
        self.assertTrue(all(n.startswith(('Jx_','JC','JL','Jb')) for n in absent))
        self.assertTrue(c['all_643_g0_field_columns_compared'])

    def test_05_source_shift_boundary_wrong_sign_detected(self):
        w=self.w;c=self.P['g0_split'];density=decode_typed(c['source_density'])
        shifts={n:decode_typed(P) for n,P in c['ordinary_source_shifts'].items()}
        current=[decode_typed(P) for P in c['source_shift_boundary_current']]
        shifted=w.add(*(w.mul(P,w.var(n)) for n,P in shifts.items()))
        div=w.add(*(w.D(P,mu) for mu,P in enumerate(current)))
        self.assertFalse(canonical(w.add(density,w.scale(shifted,-1),w.scale(div,-1))))
        self.assertTrue(canonical(w.add(density,w.scale(shifted,-1),div)))

    def test_06_odd_Legendre_sign_is_not_ungraded(self):
        w=alphabet();register(w,'kOdd',(3,0,1));register(w,'phiOdd',(1,0,1))
        P=w.mul(w.var('kOdd'),w.var('phiOdd'))
        derivatives=el(P,w,['phiOdd'],'replay')
        self.assertEqual(derivatives['phiOdd'],w.scale(w.var('kOdd'),-1))
        self.assertNotEqual(derivatives['phiOdd'],w.var('kOdd'))

    def test_07_quadratic_inverse_both_directions(self):
        for row in self.P['quadratic_inverse']['physical_frame_blocks']:
            K=mat(row['kernel']);D=mat(row['inverse'])
            self.assertEqual(cm(K*D),s.eye(5));self.assertEqual(cm(D*K),s.eye(5))
        self.assertTrue(self.P['quadratic_inverse']['higher_interactions_retained'])

    def test_08_inverse_is_not_local_ring_or_IR_result(self):
        n=self.P['quadratic_inverse']
        self.assertTrue(n['generic_non_null_momentum_only']);self.assertTrue(n['no_IR_prescription'])
        self.assertTrue(n['no_full_Gaussian_evaluation']);self.assertTrue(n['no_massive_benchmark_inverse'])

    def test_09_stationary_nonexact_source_witness(self):
        v=self.P['witness'];self.assertTrue(v['Euler_source'])
        self.assertNotEqual(s.sympify(v['exact_source_coefficient']),0)
        self.assertEqual(v['exact_source_coefficient'],v['independent_tensor_coefficient'])
        self.assertTrue(v['all_1286_source_polynomial_columns_zero'])
        self.assertFalse(v['source_free_representative_over_polynomial_ring'])
        self.assertFalse(v['benchmark_parameters_changed'])

    def test_10_local_trace_obstruction_not_Gamma_exclusion(self):
        v=self.P['witness'];self.assertTrue(s.sympify(v['local_second_order_trace_obstruction']).is_positive)
        self.assertEqual(v['local_second_order_trace_obstruction'],v['positive_Phi_skew_norm'])
        self.assertFalse(v['all_quantum_functional_admission_excluded'])

    def test_11_exact_g_factor_and_nondivisible_negative_control(self):
        w=self.w;base=w.mul(w.var('C12'),w.var('Jx_Phi_0'),w.var('x_Phi_1'));P=w.scale(base,g+g**2)
        self.assertEqual(factor_g(P),canonical(w.scale(base,1+g)))
        with self.assertRaises(AssertionError):factor_g(w.var('x_Phi_0'))
        self.assertFalse(self.P['functional_Wards']['g_inverted'])

    def test_12_minimal_source_power_count_excludes_source_square(self):
        # Minimal sources: d=2, ghost=-1 or -2. At gh=0, two sources
        # need at least two d=1 ghosts: minimum dimension six, not four.
        pairs=[self.w.grades[J] for z,J in self.w.pairs if z.startswith(('B','x_','C'))]
        self.assertTrue(all(d==2 and gh in (-1,-2) for d,gh,p in pairs))
        self.assertTrue(all(d1+d2-gh1-gh2>4 for d1,gh1,p1 in pairs for d2,gh2,p2 in pairs))

    def test_13_H_ghost_contraction_vanishes(self):
        F=decode_typed(self.P['source_class_columns'])
        self.assertFalse(any(n in {f'C{h}' for h in H} for word in F for n,j in word))
        self.assertEqual(self.P['functional_Wards']['matrix_H_covariance_checks'],2160)

    def test_14_seagull_comparison_and_structural_disclosure(self):
        v=self.P['physical_variation'];self.assertGreater(v['first_derivative_coefficients'],0)
        self.assertGreater(v['seagull_coefficients_per_Lorentz_direction'],0)
        self.assertEqual(v['seagull_all_four_Lorentz_coefficients'],4*v['seagull_coefficients_per_Lorentz_direction'])
        self.assertFalse(self.P['functional_Wards']['fresh_exhaustive_physical_QF_expansion'])

    def test_15_preserved_failed_hypothesis_and_execution_attempt(self):
        a=read(OUT/'preflight_v1/disposition.json');self.assertFalse(a['counted_as_completed_qualification'])
        a=read(OUT/'primary_attempt_1.json');self.assertFalse(a['completed_evidence'])
        self.assertIn('TypeError',a['log']);self.assertFalse(a['counted_in_final_evidence'])

    def test_16_stale_execution_rejected(self):
        v=next(read(p) for p in OUT.glob('primary_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(v['fingerprint'])
        bad=deepcopy(v['fingerprint']);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)

    def test_17_quantum_and_authority_overclaims_rejected(self):
        for name in ('actual_quantum_prescription_constructed','full_E5_PASS','intrinsic_induced_quotients_identified','source_activation'):
            a=deepcopy(self.P);b=deepcopy(self.R);a[name]=b[name]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_18_finite_normalization_not_silently_imposed(self):
        for name in ('new_normalization_adopted','all_W1_W7_prescriptions_restricted'):
            a=deepcopy(self.P);b=deepcopy(self.R);a['g0_split'][name]=b['g0_split'][name]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)


if __name__=='__main__':unittest.main()
