"""Read-only validation of selected auxiliary poles and joint normalization."""
import json,os,re,subprocess,sys,time
from hashlib import sha256
from a10_e5_joint_normalization import *
from seal_a10_e5_joint_normalization import files,protected,PARENTS
from validate_interacting_actual_h_preflight import inventory


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    before=inventory();old=protected();bounded=files(False)
    hashes={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in bounded}
    state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    tasks=[('joint_normalization_authenticate',[str(HERE/'audit_a10_e5_joint_normalization.py')],ROOT,0),
     ('scientific_regressions',['-m','unittest','test_a10_e5_joint_normalization','test_a10_e5_ghost_companion','test_a10_e5_source_vertex','test_a10_e5_regulated_slavnov','test_a10_e5_full_hessian','test_a10_e5_nonzero_regulator',
       'test_a10_e5_scalar_uv','test_a10_e5_ghost_normalization','test_a10_e5_minimal_target','test_a10_e5_nonminimal_retract','test_a10_e5_coupling_ring','test_a10_e5_regularity',
       'test_a10_e5_quantum_contract','test_a10_e5_theorem_bridge','test_a10_e5_quotient','test_a10_e5_domain',
       'test_a10_e4_interaction','test_a10_e3_symmetry','test_a10_e2_transport','-v'],HERE,0),
     ('process_regressions',['-m','unittest','discover','-s','tools','-p','test_research_*.py','-v'],ROOT,0),
     ('governance',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT,0),
     ('local_entry_point',['tools/research_check.py','e5','--budget-seconds','180'],ROOT,0),
     ('fresh_joint_normalization',[str(HERE/'audit_a10_e5_joint_normalization.py'),'--fresh'],ROOT,0)]
    records=[];started=time.perf_counter()
    for name,args,cwd,expected in tasks:
        print('START '+name,flush=True);tick=time.perf_counter()
        if name=='fresh_joint_normalization':
            p=subprocess.Popen([sys.executable,'-B',*args],cwd=cwd,env=env,stdout=subprocess.PIPE,
               stderr=subprocess.STDOUT,text=True,encoding='utf-8');lines=[]
            for line in p.stdout:
                lines.append(line)
                if not line.startswith('AUDIT '):print(line,end='',flush=True)
            code=p.wait();out=''.join(lines);err=''
        else:
            p=subprocess.run([sys.executable,'-B',*args],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8')
            code=p.returncode;out=p.stdout;err=p.stderr
        records.append({'name':name,'command':[sys.executable,'-B',*args],'exit_code':code,
          'expected_exit_code':expected,'seconds':time.perf_counter()-tick,'stdout':out,'stderr':err})
        print('DONE '+name+' '+str(code),flush=True);assert code==expected,records[-1]
    counts={n:int(re.search(r'Ran (\d+) tests?',next(r['stderr'] for r in records if r['name']==n)).group(1))
            for n in ('scientific_regressions','process_regressions','governance')}
    assert counts=={'scientific_regressions':332,'process_regressions':24,'governance':21}
    events=[json.loads(line) for line in next(r['stdout'] for r in records if r['name']=='local_entry_point').splitlines()]
    assert events[-1]['execution_state']=='COMPLETED' and events[-1]['scientific_acceptance']=='NOT_PERFORMED'
    custody=next(e for e in events if e.get('step')=='historical_custody' and e['event']=='step_finished')
    assert custody['exit_code']==2 and custody['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    fresh=json.loads(next(line[6:] for line in records[-1]['stdout'].splitlines() if line.startswith('AUDIT ')))
    assert fresh['fresh_routes_byte_identical']==2 and fresh['fresh_artifacts_byte_identical']==2 and fresh['scientific_gate']==STATUS
    after=inventory();changes=sorted(n for n in before.keys()|after.keys() if before.get(n)!=after.get(n))
    assert not changes and protected()==old
    assert {p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in bounded}==hashes
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
    result={'schema':'E5_JOINT_NORMALIZATION_VALIDATION_V1','status':'PASS_BOUNDED_JOINT_NORMALIZATION_VALIDATION_ONLY',
     'scientific_gate':STATUS,'tasks':records,'test_counts':counts,'targeted_regression_tests':sum(counts.values()),
     'independent_pairing_and_width_checks':fresh['independent_pairing_and_width_checks'],
     'new_joint_normalization_tests':20,'fresh_routes_byte_identical':2,'fresh_artifacts_byte_identical':2,'predecessor_manifests_authenticated':len(PARENTS),
     'protected_byte_sha256':old,'new_sha256':hashes,'state_sha256':state,'audit_time_changes':changes,
     'metadata_records':len(before),'inventory_kind':'size_and_mtime_not_whole_environment_byte_audit',
     'wall_seconds':time.perf_counter()-started,'runtime':{'python':sys.version,'executable':sys.executable,'sympy':s.__version__},
     'historical_custody_exit':2,'unresolved_historical_references':7,'old_expensive_science_rerun':False,
     'unaccepted_current_executions_counted_as_PASS':0,'all_canonical_pairs_retained':643,
     'original_primary_and_replay_preserved':True,'prior_failures_and_sign_adjudication_preserved':True,
     'predecessor_source_poles_authenticated':True,'predecessor_selected_source_projections_preserved':True,'complete_other_loop_poles_match_candidate_proved':False,'ghost_only_normalization_sufficient':False,'selected_kinetic_log_pole_zero':True,'selected_auxiliary_poles_and_joint_image_match':True,
     'complete_nonzero_g_restoration_proved':False,'full_quantum_M2_M5_nonempty_proved':False,
     'all_source_insertion_and_contact_identities_proved':False,'full_anomaly_freedom_proved':False,
     'full_E5_PASS':False,'A1_A5_discharged':False,'weighted_gF_quantum_A5_equivalence_proved':False,
     'inverse_physical_couplings_adopted':False,'physical_IR_measure_or_vacuum_proved':False,
     'catalog_generated':False,'sources_activated':False,'auxiliaries_eliminated':False,'HB1_C5_run':False,'C1_GS_calculated':False,
     'authority':'34/39_UNCHANGED','external_endorsement':False,'personal_outreach':False}
    print('RECEIPT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
