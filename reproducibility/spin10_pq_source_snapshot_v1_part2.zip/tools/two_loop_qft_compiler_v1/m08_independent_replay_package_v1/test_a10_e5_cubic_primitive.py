"""Discriminating mutations of the new scientific prerequisite evidence."""
import unittest
from copy import deepcopy
from audit_a10_e5_cubic_primitive import read,OUT,adjudicate


class PrimitiveControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=read(OUT/'primary.json');cls.b=read(OUT/'replay.json')

    def mutation(self,change):
        a,b=deepcopy(self.a),deepcopy(self.b);change(a);change(b)
        with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_valid_prerequisite(self):
        result=adjudicate(self.a,self.b)
        self.assertFalse(result['actual_four_ghost_pole_calculated'])

    def test_sign_control_cannot_disappear(self):
        self.mutation(lambda x:x['primitive'].__setitem__('wrong_sign_control_nonzero_slots',0))

    def test_cubic_domain_cannot_shrink(self):
        self.mutation(lambda x:x['primitive'].__setitem__('all49005_slots_checked',False))

    def test_H_identity_cannot_fail(self):
        self.mutation(lambda x:x['background_H']['all12_background_H_identities'][2].__setitem__('residual',[{'coefficient':'1','word':['C12']}]))

    def test_H_identity_cannot_be_omitted(self):
        self.mutation(lambda x:x['background_H']['all12_background_H_identities'].pop())

    def test_quartic_light_domain_cannot_shrink(self):
        self.mutation(lambda x:x['normalization']['quartic_domain'].__setitem__('antighost_directions',33))

    def test_prediction_cannot_be_reported_as_measurement(self):
        self.mutation(lambda x:x['normalization'].__setitem__('actual_four_ghost_pole_calculated',True))

    def test_prediction_cannot_be_reported_as_matching(self):
        self.mutation(lambda x:x['normalization'].__setitem__('actual_quartic_matching_proved',True))

    def test_old_width_control_cannot_disappear(self):
        self.mutation(lambda x:x['normalization']['negative_controls'].__setitem__('omit_K0_quartic_residual',[]))

    def test_nonlinear_jet_control_cannot_disappear(self):
        self.mutation(lambda x:x['normalization']['second_source_jet_cross_control'].__setitem__('omitted_cross_term_residual',[]))

    def test_formal_authority_cannot_promote(self):
        self.mutation(lambda x:x.__setitem__('authority','39/39'))

    def test_full_E5_cannot_promote(self):
        self.mutation(lambda x:x.__setitem__('full_E5_PASS',True))

    def test_candidate_cannot_be_adopted(self):
        self.mutation(lambda x:x['normalization'].__setitem__('candidate_adopted',True))

    def test_route_coefficient_corruption_fails(self):
        b=deepcopy(self.b);b['primitive']['physical_primitive'][0]['coefficient']='1'
        with self.assertRaises(AssertionError):adjudicate(self.a,b)


if __name__=='__main__':unittest.main()
