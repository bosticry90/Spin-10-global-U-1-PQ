"""Physical symmetric-tensor/ordered-word replay; no primary or SA10 import."""
import itertools
import json
from pathlib import Path
import sympy as s
from interacting_actual_h_preflight_replay import GaugeWords

HERE = Path(__file__).resolve().parent
ETA = (1, -1, -1, -1)


def read(name): return json.loads((HERE/name).read_text(encoding='utf-8'))


def category(name):
    if name in ('Abar_H', 'q_L', 'V_H'): return 'G'
    if name.startswith('x_') or name in ('Phi', 'Sigma', 'SigmaBar', 'phi', 'phiBar', 'S', 'SBar', 'eta_328'): return 'S'
    if name in ('O_exact', 'v_328'): return 'K'
    return 'X'


def signatures(t):
    """Independent scalar/connection/other bidegree propagation over the AST."""
    k = t['node']
    if k in ('Field', 'FrozenBackground', 'ExternalSource'): return {((category(t['name']), 0),)}
    if k in ('ExactScalar', 'Parameter', 'StructureConstant', 'RepresentationGenerator', 'KroneckerMetric'): return {()}
    if k == 'Add': return set().union(*(signatures(x) for x in t['terms']))
    if k == 'OrderedProduct':
        out = {()}
        for factor in t['factors']:
            out = {tuple(sorted(a+b)) for a in out for b in signatures(factor)}
        return out
    if k == 'PartialDerivative':
        return {tuple(sorted(word[:i]+((tag, order+1),)+word[i+1:]))
                for word in signatures(t['argument']) for i, (tag, order) in enumerate(word)}
    for key in ('density', 'expression', 'argument'):
        if key in t: return signatures(t[key])
    raise ValueError('REPLAY_UNDEFINED_NODE_' + k)


def inspect_complete_action(action):
    records = []
    for index, row in enumerate(action['local_terms']):
        variants = set()
        for word in signatures(row['term']):
            for i, (tag, order) in enumerate(word):
                rest = word[:i]+word[i+1:]
                if tag == 'G': variants.add(tuple(sorted(rest+(('C', order+1),))))
                for corder in range(order+1):
                    variants.add(tuple(sorted(rest+((tag, order-corder), ('C', corder)))))
                    if tag == 'S': variants.add(tuple(sorted(rest+(('K', order-corder), ('C', corder)))))
        selected = euler = False
        for word in variants:
            c = [n for tag, n in word if tag == 'C']
            xs = [n for tag, n in word if tag == 'S']
            if any(tag in ('G', 'X') for tag, n in word) or len(c) != 1 or len(xs) != 2: continue
            selected |= c == [1] and sorted(xs) == [0, 1]
            euler |= c[0]+sum(xs) == 2
        if not row['sector'].startswith('SCALAR_KINETIC_'): assert not selected and not euler, index
        records.append({'index': index, 'sector': row['sector'],
                        'selected_channel_possible': selected, 'selected_Euler_channel_possible': euler})
    assert len(records) == 36
    return records


def physical_generator_and_embedding():
    rep = read('frozen_c3/C3_representation_basis.json')
    raw = rep['h_basis'][4]['raw_so10_coordinates']
    pairs = list(itertools.combinations(range(10), 2))
    h = s.zeros(10)
    for entry in raw:
        i, j = pairs[entry['index']]; value = s.sympify(entry['coefficient'])/s.sqrt(2)
        h[i, j] += value; h[j, i] -= value
    row = read('frozen_action_ast_a3/A31_embeddings.json')['sectors']['Phi']
    e = s.SparseMatrix(100, 54, {(i, j): s.sympify(v) for i, j, v in row['embedding_entries']})
    metric = s.diag(*map(s.sympify, row['tensor_metric_diagonal']))
    assert e.T*metric*e == s.eye(54) and metric == s.eye(100)
    basis = [s.Matrix(10, 10, list(e[:, i])) for i in range(54)]
    images = [h*y+y*h.T for y in basis]
    rho = s.SparseMatrix(54, 54, {(i, j): s.simplify(s.trace(basis[i].T*images[j]))
                                for i in range(54) for j in range(54)
                                if s.trace(basis[i].T*images[j]) != 0})
    assert rho.T+rho == s.zeros(54)
    for j in range(54):
        assert images[j] == sum((rho[i, j]*basis[i] for i in range(54)), s.zeros(10))
    return rho, ['x_'+n.replace('.', '_') for n in row['coordinate_names']]


def build(stage=lambda n, fn: fn()):
    payload = read('frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json')
    action = payload['action']; assert payload['source_count'] == 0
    inventory = stage('independent_complete_action_bidegree_inspection', lambda: inspect_complete_action(action))
    rho, names = stage('C3_A31_symmetric_tensor_reconstruction', physical_generator_and_embedding)
    literal = next(t['term'] for t in action['local_terms'] if t['sector'] == 'SCALAR_KINETIC_Phi')
    recovered_names = []
    for summand in literal['terms']:
        coefficient, left, right = summand['factors']
        assert s.sympify(coefficient['value']) == s.Rational(1, 2)
        assert left == right and left['node'] == 'PartialDerivative' and left['index'] == 'mu'
        assert left['argument']['node'] == 'Field' and left['argument']['indices'] == []
        recovered_names.append(left['argument']['name'])
    assert sorted(recovered_names) == sorted(names) and len(recovered_names) == 54
    w = GaugeWords(0)
    w.p = {**{n: 0 for n in names}, 'C4': 1}
    w.fields = {n: (1, 0, 0) for n in names}; w.grades = {**w.fields, 'C4': (1, 1, 1)}; w.pairs = []; w.external = {}
    x = {n: w.var(n) for n in w.p}; g = s.Symbol('g10')
    # Direct tensor contraction gives L=1/2 Tr(dPhi^T dPhi); A31's
    # independently checked orthonormal pairing lowers this to sum_i dx_i^2/2.
    current = [w.add(*(w.scale(w.mul(w.D(x[names[i]], mu), x[names[j]]), -g*v)
                       for (i, j), v in rho.todok().items())) for mu in range(4)]
    residual = stage('direct_tensor_local_parameter_current', lambda:
                     w.add(*(w.scale(w.mul(w.D(x['C4'], mu), current[mu]), ETA[mu]) for mu in range(4))))
    euler = stage('independent_ghost_Euler', lambda: w.EL(residual, 'C4'))
    # Independent scalar Euler route: E_C(delta L)=sum_i (-g rho x)_i
    # E_x_i(L). This contains no local parameter and reproduces the obstruction.
    direct_euler = w.add(*(w.scale(w.mul(x[names[j]], w.D(w.D(x[names[i]], mu), mu)), g*v*ETA[mu])
                          for (i, j), v in rho.todok().items() for mu in range(4)))
    assert euler == direct_euler and euler
    # Diagnostic only: the ABSENT linear connection term tests the projection
    # order. Actually construct it and vary it BEFORE projecting its A fields.
    # No interaction is adopted or fitted and no physical input is changed.
    anames = ['diagnostic_A4_'+str(mu) for mu in range(4)]
    w.p.update({n: 0 for n in anames})
    linear = w.add(*(w.scale(w.mul(w.var(anames[mu]), current[mu]), -ETA[mu]) for mu in range(4)))
    forward = {names[i]: w.add(*(w.scale(w.mul(x['C4'], x[names[j]]), -g*v)
                  for (row, j), v in rho.todok().items() if row == i)) for i in range(54)}
    forward.update({anames[mu]: w.D(x['C4'], mu) for mu in range(4)})
    varied_linear = w.act(linear, forward, parity=1)
    compensation = {word: value for word, value in varied_linear.items()
                    if all(name not in anames for name, jets in word)}
    assert compensation == w.scale(residual, -1) and not w.add(residual, compensation)
    assert not {word: value for word, value in linear.items()
                if all(name not in anames for name, jets in word)}
    target = sorted(['C4__0', 'x_Phi_offdiag_0_4', 'x_Phi_offdiag_0_1__0'])
    records = w.record(residual)
    selected = next(r['coefficient'] for r in records if r['word'] == target)
    keep = {'x_Phi_offdiag_0_1', 'x_Phi_offdiag_0_4', 'C4'}
    minimal = {word: value for word, value in residual.items() if all(name in keep for name, jets in word)}
    minimum_euler = w.EL(minimal, 'C4')
    assert minimum_euler
    return {'schema': 'PHASE_C_COMPLETE_ACTION_SCALAR_PHYSICAL_REPLAY_V1',
            'status': 'FAILED_COMPLETE_PHYSICAL_ACTION_SELECTED_CHANNEL',
            'canonical_action_sha256': action['canonical_action_sha256'],
            'generator': 4, 'coordinates': 54, 'scalar_orientation': -1,
            'spacetime_metric': list(ETA), 'selected_word': target, 'selected_coefficient': selected,
            'variation': records, 'ghost_Euler_residual': w.record(euler),
            'scalar_Euler_route_agrees': True, 'minimal_two_field_variation': w.record(minimal),
            'literal_A10_kinetic_matches_tensor_pairing': True,
            'minimal_two_field_ghost_Euler': w.record(minimum_euler),
            'complete_action_channel_inventory': inventory,
            'projection_trap_control': {'missing_linear_connection_term_variation': w.record(compensation),
                                        'actual_connection_variation_before_projection': True,
                                        'premature_projection_would_lose_compensator': True,
                                        'would_cancel_exactly': True, 'adopted': False},
            'primary_or_SA10_imported': False, 'external_specialist_review': False,
            'independence': 'Distinct physical tensor/current and ordered-word routes; shared Python, SymPy, frozen C3/A31 inputs, conventions and analyst. No library/runtime/specialist independence.',
            'covariant_completion_adopted': False, 'formal_authority': '34/39_UNCHANGED'}


if __name__ == '__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    print('RESULT '+json.dumps(build(), sort_keys=True, separators=(',', ':')))
