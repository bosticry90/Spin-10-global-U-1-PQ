"""Read-only validation of the completed bounded stop, not BV acceptance."""
from hashlib import sha256
import json,os,subprocess,sys,time
from pathlib import Path
from validate_interacting_actual_h_preflight import inventory,bound_hashes
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest();before=inventory();inherited=bound_hashes()
    start=time.perf_counter();records=[]
    tasks=[
      ('authenticate_BV_partial_candidate_and_independent_stop',[str(HERE/'audit_a10_bv.py')],ROOT,0),
      ('fresh_decisive_gauge_Euler_negative_controls',[str(HERE/'audit_a10_bv.py'),'--fresh-witness-only'],ROOT,0),
      ('new_BV_stop_regressions',['-m','unittest','test_a10_bv','-v'],HERE,0),
      ('preserved_cotangent_regressions',['-m','unittest','test_a10_cotangent','-v'],HERE,0),
      ('preserved_executable_regressions',['-m','unittest','test_a10_executable','-v'],HERE,0),
      ('preserved_classical_regressions',['-m','unittest','test_a10_physical_reconciliation','-v'],HERE,0),
      ('preserved_A10_failure_regressions',['-m','unittest','test_phase_c_scalar_action','-v'],HERE,0),
      ('governance',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT,0),
      ('authority',['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'],ROOT,0),
      ('structure_preserving_map',['tools/readiness/audit_structure_preserving_map_contract.py'],ROOT,0),
      ('read_only_contract',['tools/readiness/audit_read_only_contract.py'],ROOT,0),
      ('historical_custody',['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'],ROOT,2)]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name,args,cwd,expected in tasks:
        print('START '+name,flush=True);t=time.perf_counter()
        p=subprocess.run([sys.executable,'-B',*args],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
        row={'name':name,'exit_code':p.returncode,'expected_exit_code':expected,'wall_seconds':time.perf_counter()-t,'stdout':p.stdout,'stderr':p.stderr}
        records.append(row);print('DONE '+name+' '+str(p.returncode),flush=True)
        if p.returncode!=expected:print('FAILED '+json.dumps(row),flush=True);raise RuntimeError('BV_STOP_VALIDATION_FAILED_'+name)
    after=inventory();changes=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
    assert not changes and bound_hashes()==inherited
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
    assert records[-1]['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    print('RECEIPT '+json.dumps({'schema':'A10_BV_MASTER_STOP_VALIDATION_RECEIPT_V1',
      'status':'PASS_BOUNDED_FAILURE_EVIDENCE_VALIDATION_ONLY',
      'scientific_gate':'STOP_GATE_3_CANONICAL_GAUGE_EULER_TRANSLATION_FAILED',
      'tasks':records,'targeted_regression_tests':75,'wall_seconds':time.perf_counter()-start,
      'inherited_byte_bindings':len(inherited),'inherited_bytes_unchanged':True,
      'workspace_active_data_metadata_records':len(before),'inventory_kind':'size_and_mtime_ns_not_all_byte_audit',
      'audit_time_changes':changes,'live_state_transaction_sha256':state,
      'historical_custody_exit':2,'unresolved_historical_references':7,'historical_original_bindings_resolved':False,
      'fresh_witness_routes_byte_identical':True,
      'large_source_action_routes':'two fresh initial read-only derivations compared exactly; receipt authenticates saved outputs, does not rerun large source construction',
      'old_expensive_calculations_rerun':False,'candidate_adopted':False,'sources_activated':False,
      'full_master_action_qualified':False,'Stage_E_reached':False,'Phase_C_resumed':False,
      'HB1_C5_run':False,'C1_GS_calculated':False,'catalog_rebuilt':False,'formal_authority':'34/39_UNCHANGED',
      'external_specialist_endorsement':False,'personal_outreach_planned':False,
      'solo_review_policy':'docs/SOLO_REVIEW_POLICY_V1.md'},sort_keys=True,separators=(',',':')),flush=True)
if __name__=='__main__':main()
