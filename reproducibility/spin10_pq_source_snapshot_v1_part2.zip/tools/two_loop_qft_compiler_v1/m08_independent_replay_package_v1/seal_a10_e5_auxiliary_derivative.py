"""Seal a validated failed derivative gate, without adopting a normalization."""
import subprocess
from hashlib import sha256
from a10_e5_auxiliary_derivative_control import HERE,ROOT,OUT,BASE,read
from validate_a10_e5_auxiliary_derivative import protected,new_files
from export_a10_e5_auxiliary_derivative import dump
from seal_a10_e5_source_gauge import PARENTS as PREVIOUS_PARENTS

PARENTS=(*PREVIOUS_PARENTS,'frozen_a10_e5_source_gauge')


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'NO_OVERWRITE'
    r=read(OUT/'validation_receipt.json')
    assert r['status']=='PASS_BOUNDED_AUXILIARY_DERIVATIVE_EVIDENCE_VALIDATION_ONLY'
    assert r['fresh_routes_byte_identical']==4 and not r['audit_time_changes']
    assert r['historical_custody_exit']==2 and r['unresolved_historical_references']==7
    assert r['full_canonical_image_run'] and r['candidate_existing_companion_gates_PASS'] and not r['normalization_adopted'] and not r['full_E5_or_quantum_A5']
    assert protected()==r['protected_byte_sha256'] and len(PARENTS)==39
    for n,h in r['new_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==r['state_sha256']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
    paths=new_files()+[OUT/'validation_receipt.json']
    dump(OUT/'bindings.json',{'schema':'E5_AUXILIARY_DERIVATIVE_BINDINGS_V1','base_commit':BASE,
        'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
        'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
        'state_sha256':r['state_sha256'],'scientific_disposition':r['scientific_disposition'],'new_full_canonical_image_calculated':True,
        'candidate_existing_companion_gates_PASS':True,'normalization_adopted':False,'physical_parameters_fitted':False,
        'higher_or_other_source_actual_loops_executed':False,'sources_activated':False,'auxiliaries_eliminated':False,
        'full_E5_or_quantum_A5':False,'HB1_C5_run':False,'C1_GS_calculated':False,'authority_changed':False,
        'whole_goal_complete':False,'remote_push':False,'external_endorsement':False})
    print('SEALED actual derivative evidence and failed inactive comparison; whole goal incomplete')


if __name__=='__main__':main()
