"""Exact packet semantics and a bounded ordered-triplet completion test.

Primary extraction contracts manifestly covariant tensors with qualified
primal embeddings. Replay differentiates ordinary jet polynomials and solves
their background-variation kernel. No IBP, final statistics or BRST action.
"""
from itertools import product
from math import prod
import sympy as sp
from jcat3_contract_preflight import HERE, load, canonical
from jcat_internal_permutations import FactorPermutations, coordinates
from jcat_physical_jets import tensor_generators
from scalar_bridge_primary_v3 import qualified_duals
from execute_scalar_ast_channel_bridge import matrix

BLOCKER = 'M08_JCAT7_BACKGROUND_VARIATION_KERNEL_NONFAITHFUL_ORDERED_EXPANSION'
SIDS = ('SIG_5766b31c9c67456ae865', 'SIG_4ab9025ede0c5ecebda5',
        'SIG_1b36a8fa7c3003fc8e39')


def serial(m):
    return {'shape': list(m.shape), 'entries': [[int(i), int(j), str(v)]
        for (i, j), v in sorted(sp.SparseMatrix(m).todok().items())]}


def contract():
    return {'contract_id': 'M08_JCAT7_BACKGROUND_COVARIANT_PACKET_CONTRACT_V2',
        'status': 'FROZEN_USER_ADJUDICATED_TWO_LEVEL_CONTRACT',
        'expansion_layer': '431_IMMUTABLE_ORDERED_SIGNATURE_ADDRESSES',
        'operator_layer': 'BACKGROUND_COVARIANT_PACKET',
        'primary': 'Manifestly covariant grammar; exact signature expansion',
        'replay': 'Independent infinitesimal affine background variation kernel',
        'acceptance': 'Exact mutual span, expansion rank and non-overcounting',
        'background_action': 'delta X=rho(theta)X; delta Abar=[theta,Abar]-partial(theta)/g10',
        'quantum_BRST_distinct': 'The frozen quantum Weil action leaves Abar inert; it is not delta_background',
        'covariant_derivative': 'Dbar=partial+g10*rho(Abar)',
        'curvature_authority': 'Derived restriction of the frozen N1-N4 total-connection curvature; no new primitive or parameter',
        'curvature_definition': 'Fbar_mu_nu=partial_mu Abar_nu-partial_nu Abar_mu+g10[Abar_mu,Abar_nu]',
        'source_duals': 'Certified contragredient action, not an untyped transpose',
        'parity_policy': 'Retain PARITY_EVEN and PARITY_ODD; physical dimension four',
        'signature_ids_changed': False, 'upstream_basis_changed': False,
        'IBP_applied': False, 'statistics_applied': False, 'EOM_applied': False,
        'C5_executed': False}


def expansion_ledger():
    rows = load(HERE/'frozen_jcat3_contract_preflight/JCAT3_signature_contract_ledger.json')['rows']
    out = []
    for row in rows:
        names = row['ordered_symbol_names']
        vectors = [('v', i) for i, f in enumerate(row['field_types']) if f['Lorentz_type'] == 'VECTOR']
        from itertools import combinations_with_replacement
        keys = set()
        for degree in row['degree_bounds']['feasible_derivative_degrees']:
            for placement in combinations_with_replacement(range(len(names)), degree):
                for key, sign in tensor_generators(vectors+[('p', i) for i in placement]):
                    if sign: keys.add((degree, key))
        keys = sorted(keys)
        singleton = names.count('Abar_H_mu') == 0
        singleton_keys = [i for i, (degree, _) in enumerate(keys) if singleton and degree == 0]
        out.append({'signature_id': row['signature_id'], 'object_type': 'EXPANSION_ADDRESS',
            'ordered_occurrences': [{'slot': i, 'field': n,
                'background_transformation': 'AFFINE_CONNECTION' if n == 'Abar_H_mu' else 'HOMOGENEOUS_CERTIFIED_H_MODULE'}
                for i, n in enumerate(names)],
            'raw_Lorentz_derivative_addresses': keys, 'internal_family': row['G_sig']['family_id'],
            'internal_address_count': row['G_sig']['ordered_dimension'],
            'internal_address_authority': 'Immutable INT6 addresses; factorized product descriptor',
            'background_occurrences': names.count('Abar_H_mu'),
            'EXPANSION_ADDRESS_COUNT': len(keys)*row['G_sig']['ordered_dimension'],
            'singleton_covariant_jet_indices': singleton_keys,
            'singleton_packet_count': len(singleton_keys)*row['G_sig']['ordered_dimension'],
            'completion_class': {'homogeneous_occurrences': [n for n in names if n != 'Abar_H_mu'],
                                 'canonical_dimension': row['degree_bounds']['base_dimension'],
                                 'derivative_degrees': row['degree_bounds']['feasible_derivative_degrees']},
            'admissibility': 'SINGLETON_FOR_ZERO_DERIVATIVE_NO_BACKGROUND_SUBSPACE_ONLY' if singleton_keys else 'COMPLETION_REQUIRED_OR_EMPTY',
            'background_packet_dimension': None})
    assert len(out) == 431 and len({r['signature_id'] for r in out}) == 431
    return {'status': 'PASS_COMPLETE_EXPANSION_TYPING_NOT_PACKET_COMPLETENESS',
        'signature_count': len(out), 'rows': out,
        'EXPANSION_ADDRESS_COUNT': sum(r['EXPANSION_ADDRESS_COUNT'] for r in out),
        'certified_zero_derivative_singleton_packets': sum(r['singleton_packet_count'] for r in out),
        'BACKGROUND_COVARIANT_PACKET_DIMENSION': None,
        'singleton_certificate': 'Every frozen internal covector annihilates the sum of homogeneous generators; no derivative(theta) occurs',
        'IBP_applied': False, 'statistics_applied': False}


def triplet_data():
    d = qualified_duals()
    engine = FactorPermutations(d, 'SU2')
    E, F, H = (matrix(d.f2[2]['generators'][k]) for k in ('E', 'F', 'H'))
    actions = [2*F, H, -2*E]
    J = d.j2[2]
    assert all(t.T*J+J*t == sp.zeros(3) for t in actions)
    assert all(actions[i][:, j]+actions[j][:, i] == sp.zeros(3, 1)
               for i in range(3) for j in range(3))
    return engine, actions


def extract(engine, n, tensor):
    """Qualified fusion-dual extraction: tensor target never comes from replay."""
    labels = (2,)*n
    result = []
    mat = sp.Matrix(9, 3**(n-2), list(tensor))
    for key, _ in engine.basis(labels)[1]:
        o, a, b = key
        C = engine.cs[(2, 2, o)][a]
        if n == 2:
            value = (tensor.T*C)[0, 0]
        else:
            block = C.T*mat
            if n == 4: block = block*engine.cs[(2, 2, o)][b]
            scalar = block*engine.js[o].T.inv()
            value = scalar.trace()/scalar.rows
            assert scalar == value*sp.eye(scalar.rows)
        result.append(value)
    reconstructed = sum((c*v for c, (_, v) in zip(result, engine.basis(labels)[1])), sp.zeros(3**n, 1))
    assert reconstructed == tensor
    return sp.Matrix(result)


def primary():
    engine, T = triplet_data()
    B2 = engine.basis((2, 2))[1][0][1]
    I = sp.Matrix(3, 3, list(B2))
    unit = sp.eye(3)
    # Tensor slots are A,x,y and A,A,x,y. Extract algebraically through C/J;
    # no physical samples, target kernel or reconstruction comparison imported.
    left1 = sp.Matrix([((T[a]*unit[:, x]).T*I*unit[:, y])[0] for a, x, y in product(range(3), repeat=3)])
    right1 = sp.Matrix([(unit[:, x].T*I*T[a]*unit[:, y])[0] for a, x, y in product(range(3), repeat=3)])
    left2 = sp.Matrix([((T[a]*T[b]*unit[:, x]).T*I*unit[:, y])[0] for a, b, x, y in product(range(3), repeat=4)])
    middle2 = sp.Matrix([((T[a]*unit[:, x]).T*I*T[b]*unit[:, y])[0] for a, b, x, y in product(range(3), repeat=4)])
    right2 = sp.Matrix([(unit[:, x].T*I*T[a]*T[b]*unit[:, y])[0] for a, b, x, y in product(range(3), repeat=4)])
    l, r = extract(engine, 3, left1), extract(engine, 3, right1)
    ll, mm, rr = (extract(engine, 4, v) for v in (left2, middle2, right2))
    # Coefficients in g10-graded expansion coordinates. The three quadratic
    # jets are ddx*y, dx*dy, x*ddy; cubic jets b*x*y,A*dx*y,A*x*dy.
    P = sp.zeros(9, 3)
    P[0, 0] = P[1, 1] = P[2, 2] = 1
    P[3, 0], P[4, 0] = l[0], 2*l[0]
    P[4, 1], P[5, 1] = r[0], l[0]
    P[3, 2], P[5, 2] = r[0], 2*r[0]
    for j, coefs in enumerate((ll, mm, rr)):
        for i, c in enumerate(coefs): P[6+i, j] = c
    assert P.rank() == 3
    keys = [[n, key] for n in (2, 3, 4) for key, _ in engine.basis((2,)*n)[1]]
    rows = [{'signature_id': SIDS[0], 'derivative_placement': p, 'factor_key': keys[0], 'g10_power': 0}
            for p in ([2, 0], [1, 1], [0, 2])]
    rows += [{'signature_id': SIDS[1], 'derivative_placement': p, 'factor_key': keys[1], 'g10_power': 1}
             for p in ([1, 0, 0], [0, 1, 0], [0, 0, 1])]
    rows += [{'signature_id': SIDS[2], 'derivative_placement': [0, 0, 0, 0], 'factor_key': key, 'g10_power': 2}
             for key in keys[2:]]
    for row in rows:
        row['parity'] = 'PARITY_EVEN'
        row['Lorentz_address'] = 'One metric pairing of the two attached indices'
        row['internal_scope'] = 'Frozen SU3-singlet/U1-neutral/PQ-neutral SU2-triplet factor block; two independent ordered Phi occurrences'
    from int8_block_conjugation_v2 import BlockConjugation
    catalog = BlockConjugation.from_frozen()
    for row in rows:
        fid = ('INV_S_S', 'INV_A_S_S', 'INV_A_A_S_S')[SIDS.index(row['signature_id'])]
        desc = catalog.descriptors[fid]
        found = []
        for key, _, left, right in catalog.blocks(desc):
            slots = catalog.block_slots(desc, key)
            if not all(catalog.by_id[c]['H_label'] == [0, 0, 2, 0] for c in slots): continue
            if len(slots) == 4 and left['output_H_label'][2] != row['factor_key'][1][0]: continue
            found.extend(catalog.addresses(fid, key))
        assert len(found) == 1
        row['internal_channel_address'] = found[0]
        row['ordered_components'] = [catalog.by_id[c] for c in catalog.address_parts(found[0])[2]]
    parents = ['(Dbar^2 x)^T I y', '(Dbar x)^T I (Dbar y)', 'x^T I (Dbar^2 y)']
    return {'status': 'PASS_BOUNDED_MANIFESTLY_COVARIANT_PRIMARY', 'expansion_addresses': rows,
        'packet_parents': [{'packet_id': 'PKT_'+canonical({'parent': p, 'factor': keys})[:20], 'parent': p}
                           for p in parents],
        'expansion_matrix': serial(P), 'EXPANSION_ADDRESS_COUNT': 9,
        'BACKGROUND_COVARIANT_PACKET_DIMENSION': 3, 'expansion_rank': 3,
        'coefficient_extraction': 'C/J qualified dual coefficient contraction, full tensor reconstruction',
        'ordinary_covariant_derivatives_commuted': False,
        'field_occurrences_polarized_separately': True, 'IBP_applied': False, 'statistics_applied': False}


def polynomial_columns(expressions, variables):
    polys = [sp.Poly(sp.expand(p), *variables) for p in expressions]
    monomials = sorted({m for p in polys for m, c in p.terms() if c})
    return monomials, sp.Matrix([[p.coeff_monomial(m) for p in polys] for m in monomials])


def replay():
    engine, T = triplet_data()
    x, p, q, y, r, s, a, b, t, dt, ddt = [sp.Matrix(sp.symbols(f'{n}0:3'))
        for n in ('x', 'dx', 'ddx', 'y', 'dy', 'ddy', 'a', 'da', 'theta', 'dtheta', 'ddtheta')]
    def rho(v): return sum((v[i]*T[i] for i in range(3)), sp.zeros(3))
    def value(n, args):
        return [sp.expand(sum(v*sp.prod(args[i][z] for i, z in enumerate(coordinates(j, (3,)*n)))
            for (j, _), v in basis.todok().items())) for _, basis in engine.basis((2,)*n)[1]]
    targets = [*value(2, (q, y)), *value(2, (p, r)), *value(2, (x, s)),
               *value(3, (b, x, y)), *value(3, (a, p, y)), *value(3, (a, x, r)),
               *value(4, (a, a, x, y))]
    # Independent direct prolongation of the ordinary background action, g10
    # absorbed in a and b. This retains all theta, dtheta and ddtheta monomials.
    variables = [*x, *p, *q, *y, *r, *s, *a, *b]
    variations = [*(rho(t)*x), *(rho(t)*p+rho(dt)*x),
        *(rho(t)*q+2*rho(dt)*p+rho(ddt)*x), *(rho(t)*y),
        *(rho(t)*r+rho(dt)*y), *(rho(t)*s+2*rho(dt)*r+rho(ddt)*y),
        *(rho(t)*a-dt), *(rho(t)*b+rho(dt)*a-ddt)]
    deltas = [sp.expand(sum(sp.diff(f, z)*dz for z, dz in zip(variables, variations))) for f in targets]
    monomials, V = polynomial_columns(deltas, variables+[*t, *dt, *ddt])
    realization_monomials, E = polynomial_columns(targets, variables)
    K = sp.Matrix.hstack(*V.nullspace())
    Z = sp.Matrix.hstack(*E.nullspace())
    assert V*K == sp.zeros(V.rows, K.cols) and E*Z == sp.zeros(E.rows, Z.cols)
    # Exact Cartesian control: this is a diagnostic coordinate view only.
    return {'status': 'PASS_BOUNDED_INDEPENDENT_AFFINE_VARIATION_KERNEL',
        'variation_matrix': serial(V), 'variation_monomials': monomials,
        'variation_variables': [str(z) for z in variables+[*t, *dt, *ddt]],
        'kernel': serial(K), 'variation_rank': V.rank(), 'kernel_dimension': K.cols,
        'realization_matrix': serial(E), 'realization_monomials': realization_monomials,
        'realization_variables': [str(z) for z in variables],
        'realization_kernel': serial(Z), 'realization_rank': E.rank(),
        'ordinary_expressions': [str(z) for z in targets],
        'primary_coefficients_imported': False, 'IBP_applied': False, 'statistics_applied': False,
        'independence': {'ALGORITHM_INDEPENDENT': True, 'COEFFICIENT_CODE_PATH_INDEPENDENT': True,
                         'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
                         'shared_inputs': 'Qualified SU2 carrier and canonical covector basis'}}


def compare(primary_record, replay_record):
    P, V, K, E, Z = (matrix(r[k]) for r, k in ((primary_record, 'expansion_matrix'),
        (replay_record, 'variation_matrix'), (replay_record, 'kernel'),
        (replay_record, 'realization_matrix'), (replay_record, 'realization_kernel')))
    assert V*P == sp.zeros(V.rows, P.cols)
    assert E*P != sp.zeros(E.rows, P.cols)
    joint = P.row_join(K)
    equal = joint.rank() == P.rank() == K.rank()
    assert P.row_join(Z).rank() == K.rank()
    assert (E*P).rank() == (E*K).rank() == P.rank()
    # Zero directions are recorded, NOT quotiented or promoted as operators.
    negative = Z[:, 0]
    engine, _ = triplet_data()
    swap = engine.swap((2, 2, 2, 2), 0)
    assert swap*negative[6:, :] == -negative[6:, :]
    return {'status': 'PASS_EXACT_MUTUAL_SPAN' if equal else 'BLOCKED_NONFAITHFUL_KERNEL_DOMAIN',
        'current_blocker': None if equal else BLOCKER,
        'primary_packet_rank': P.rank(), 'replay_raw_kernel_rank': K.rank(),
        'combined_rank': joint.rank(), 'raw_mutual_span': equal,
        'primary_background_variation_residual': 'ZERO_EXACT',
        'realization_kernel_dimension': Z.cols,
        'zero_realization_direction': serial(negative),
        'background_slot_swap_eigenvalue_of_zero_direction': -1,
        'zero_direction_has_nonzero_frozen_expansion_coordinates': True,
        'zero_direction_origin': 'Antisymmetric two-Abar internal contraction with symmetric Lorentz metric; same commuting background connection in both occurrences',
        'physical_image_mutual_span': 'ZERO_EXACT',
        'physical_packet_image_rank': (E*P).rank(),
        'no_zero_directions_counted_as_independent_physical_packets': True,
        'no_realization_quotient_performed': True, 'no_final_statistics_projection_performed': True,
        'full_four_dimensional_zero_certificate': 'The qualified tensor is odd under exchange of the two Abar slots; eta_mu_nu is symmetric. Contracting the same commuting background connection twice therefore gives zero for all four-dimensional Lorentz components, not just the spatial fiber.',
        'diagnostic_replay_scope': 'Complete nine-coordinate ordered SU2-triplet spatial kinetic fiber; not a complete 431-signature variation replay',
        'required_contract_disposition': 'Specify faithful ordered affine-variation domain/target, or authorize comparing the replay kernel modulo the intrinsic realization kernel. Do not silently count zero operators as packets.',
        'IBP_applied': False, 'C5_executed': False}
