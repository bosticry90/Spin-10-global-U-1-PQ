"""Adversarial coefficient, quartic, vacuum and background controls."""
import json
from pathlib import Path
import unittest
import sympy as s
from interacting_actual_h_preflight_replay import GaugeWords
from audit_a10_physical_reconciliation import authenticate
from assemble_a10_physical_candidate import build

HERE = Path(__file__).resolve().parent; OUT = HERE/'frozen_a10_physical_reconciliation'
g = s.Symbol('g10'); t = s.I/s.sqrt(2)

def control(linear=1, quadratic=1, scalar_sign=-1, shift=True):
    w = GaugeWords(0); w.p = {'x': 0, 'y': 0, 'B': 0, 'C': 1}
    x, y, B, C = [w.var(n) for n in ('x', 'y', 'B', 'C')]
    v = s.Symbol('v', real=True)
    totalx = w.add(x, {(): v}) if shift else x
    ordinary = w.scale(w.add(w.mul(w.D(x, 0), w.D(x, 0)), w.mul(w.D(y, 0), w.D(y, 0))), s.Rational(1, 2))
    cross = w.scale(w.mul(B, w.add(w.scale(w.mul(y, w.D(x, 0)), -t), w.scale(w.mul(totalx, w.D(y, 0)), t))), linear*g)
    quartic = w.scale(w.mul(B, B, w.add(w.mul(y, y), w.mul(totalx, totalx))), quadratic*g**2*t**2/2)
    action = w.add(ordinary, cross, quartic)
    forward = {'x': w.scale(w.mul(C, y), -scalar_sign*g*t),
               'y': w.scale(w.mul(C, totalx), scalar_sign*g*t), 'B': w.D(C, 0)}
    return w, action, forward

class ReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED'), 'POLE_GUARD_REQUIRED'

    def test_exact_saved_independent_evidence_and_old_failure(self):
        self.assertEqual(authenticate()['exact_nonzero_representation_coefficients_compared'], 7602)

    def test_covariant_shifted_two_field_control(self):
        w, action, forward = control()
        self.assertFalse(w.act(action, forward, parity=1))

    def test_missing_quartic_is_visible_at_nonzero_connection(self):
        w, action, forward = control(quadratic=0)
        residual = w.act(action, forward, parity=1)
        self.assertTrue(residual)
        self.assertFalse(w.replace(residual, {'B': {}}))
        self.assertTrue(w.EL(residual, 'C'))

    def test_linear_coefficient_is_fixed_before_projection(self):
        w, action, forward = control(linear=2)
        residual = w.replace(w.act(action, forward, parity=1), {'B': {}})
        self.assertTrue(residual)

    def test_ordinary_kinetic_reproduces_historical_coefficient(self):
        w, action, forward = control(linear=0, quadratic=0, shift=False)
        residual = w.act(action, forward, parity=1)
        coefficient = next(row['coefficient'] for row in w.record(residual) if row['word'] == ['C__0', 'x__0', 'y'])
        self.assertEqual(s.sympify(coefficient), g*t)
        self.assertTrue(w.EL(residual, 'C'))

    def test_wrong_historical_scalar_orientation_fails(self):
        w, action, forward = control(scalar_sign=1)
        self.assertTrue(w.act(action, forward, parity=1))

    def test_omitting_affine_vacuum_from_transformation_fails(self):
        w, action, forward = control()
        forward['y'] = w.scale(w.mul(w.var('C'), w.var('x')), -g*t)
        self.assertTrue(w.act(action, forward, parity=1))

    def test_background_constant_vev_projection_must_follow_variation(self):
        beta, dbeta, v, eta, deta = s.symbols('beta dbeta v eta deta', commutative=False)
        dtotal = -g*(dbeta*(v+eta)+beta*deta)
        good = -g*dbeta*v-g*(dbeta*eta+beta*deta)
        premature = -g*(dbeta*eta+beta*deta)
        self.assertEqual(s.expand(good-dtotal), 0)
        self.assertEqual(s.expand(premature-dtotal), g*dbeta*v)

    def test_full_nonabelian_curvature_parameter_jets_cancel(self):
        B0, B1, d0B1, d1B0, W, d0W, d1W, d01W = s.symbols('B0 B1 d0B1 d1B0 W d0W d1W d01W', commutative=False)
        bracket = lambda a, b: a*b-b*a
        F = d0B1-d1B0+g*bracket(B0, B1)
        deltaB0 = d0W+g*bracket(B0, W); deltaB1 = d1W+g*bracket(B1, W)
        deltaF = d01W+g*(bracket(d0B1, W)+bracket(B1, d0W))-d01W-g*(bracket(d1B0, W)+bracket(B0, d1W))+g*(bracket(deltaB0, B1)+bracket(B0, deltaB1))
        self.assertEqual(s.expand(deltaF-g*bracket(F, W)), 0)

    def test_mass_normalization_and_missing_goldstone_mixing_detected(self):
        p = json.loads((OUT/'full_primary.json').read_text()); row = p['vacuum']['orbit_Gram']
        gram = s.SparseMatrix(*row['shape'], {(i, j): s.sympify(v) for i, j, v in row['entries']})
        self.assertNotEqual(gram, 2*gram)
        self.assertTrue(p['vacuum']['orbit']['entries'])
        self.assertFalse(p['vacuum']['mixing_cancellation_matrix']['entries'])
        self.assertEqual(p['vacuum']['literal_A10_physical_vector_mass_from_scalar_kinetic'], 'ZERO_EXACT')

    def test_candidate_preserves_literal_potential_and_stays_inactive(self):
        p = json.loads((OUT/'full_primary.json').read_text()); candidate = build(p)
        old = json.loads((HERE/'frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json').read_text())
        self.assertEqual(candidate['local_terms'][5:], [row for row in old['action']['local_terms'] if row['sector'] == 'PARENT_SCALAR_POTENTIAL'])
        self.assertFalse(candidate['adopted']); self.assertEqual(candidate['new_parameters'], [])
        self.assertFalse(candidate['gauge_fixing_ghost_terms_included'])

    def test_all_four_previous_packets_have_current_solo_versions(self):
        for filename in ('SOURCE_DOMAIN_SOLO_REVIEW_PACKET_V2.md', 'SOURCE_COMPONENT_SOLO_REVIEW_PACKET_V2.md',
                         'INTERACTING_BV_M08_SOLO_REVIEW_PACKET_V2.md', 'INTERACTING_ACTUAL_H_SOLO_REVIEW_PACKET_V2.md'):
            text = (HERE/filename).read_text()
            self.assertIn('no personal contact, recruitment or external-participation gate applies', text)

    def test_actual_H_background_preserves_restricted_carriers_and_vev(self):
        from audit_a10_physical_reconciliation import background_scope
        p = json.loads((OUT/'full_primary.json').read_text()); r = json.loads((OUT/'full_replay.json').read_text())
        scope = background_scope(p, r)
        self.assertEqual(scope['H_closure_checks'], {'H_H': 66, 'H_heavy': 396})
        self.assertEqual(scope['VEV_H_orbit_primary_and_replay'], 'ZERO_EXACT')
        self.assertFalse(scope['new_background_carrier_activated'])

if __name__ == '__main__': unittest.main()
