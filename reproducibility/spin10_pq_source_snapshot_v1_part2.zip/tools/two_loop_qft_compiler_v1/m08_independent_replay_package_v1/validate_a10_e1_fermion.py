"""Bounded read-only E1 validation transaction; strict custody remains exit 2."""
from hashlib import sha256
import os,sys,subprocess,json,time,re
from a10_e1_fermion_common import HERE,ROOT,OUT,STATUS,HISTORICAL
from validate_interacting_actual_h_preflight import inventory,bound_hashes

def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    before=inventory();inherited=bound_hashes();start=time.perf_counter();records=[]
    history={n:sha256((HERE/n).read_bytes()).hexdigest() for n in HISTORICAL}
    tasks=[
      ('authenticate_nine_predecessor_chains',[str(HERE/'audit_a10_e1_fermion.py')],ROOT,0),
      ('fresh_three_E1_read_only_routes',[str(HERE/'audit_a10_e1_fermion.py'),'--fresh'],ROOT,0),
      ('new_E1_regressions',['-m','unittest','test_a10_e1_fermion','-v'],HERE,0),
      ('preserved_E1_stop_regressions',['-m','unittest','test_a10_stage_e','-v'],HERE,0),
      ('preserved_Stage_D_regressions',['-m','unittest','test_a10_bv_integration','-v'],HERE,0),
      ('preserved_gauge_Euler_regressions',['-m','unittest','test_a10_gauge_euler','-v'],HERE,0),
      ('preserved_BV_stop_regressions',['-m','unittest','test_a10_bv','-v'],HERE,0),
      ('preserved_cotangent_regressions',['-m','unittest','test_a10_cotangent','-v'],HERE,0),
      ('preserved_executable_regressions',['-m','unittest','test_a10_executable','-v'],HERE,0),
      ('preserved_classical_regressions',['-m','unittest','test_a10_physical_reconciliation','-v'],HERE,0),
      ('preserved_A10_failure_regressions',['-m','unittest','test_phase_c_scalar_action','-v'],HERE,0),
      ('governance',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT,0),
      ('authority',['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'],ROOT,0),
      ('structure_preserving_map',['tools/readiness/audit_structure_preserving_map_contract.py'],ROOT,0),
      ('read_only_contract',['tools/readiness/audit_read_only_contract.py'],ROOT,0),
      ('historical_custody',['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'],ROOT,2)]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name,args,cwd,expected in tasks:
        print('START '+name,flush=True);t=time.perf_counter()
        p=subprocess.run([sys.executable,'-B',*args],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
        row={'name':name,'exit_code':p.returncode,'expected_exit_code':expected,
          'wall_seconds':time.perf_counter()-t,'stdout':p.stdout,'stderr':p.stderr}
        records.append(row);print('DONE '+name+' '+str(p.returncode),flush=True)
        if p.returncode!=expected:print('FAILED '+json.dumps(row),flush=True);raise RuntimeError('E1_VALIDATION_FAILED_'+name)
    scientific=sum(int(re.search(r'Ran (\d+) tests?',r['stderr']).group(1)) for r in records if r['name'].endswith('_regressions'))
    governance=int(re.search(r'Ran (\d+) tests?',next(r['stderr'] for r in records if r['name']=='governance')).group(1))
    assert scientific==121 and governance==21
    after=inventory();changes=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
    assert not changes and bound_hashes()==inherited
    assert {n:sha256((HERE/n).read_bytes()).hexdigest() for n in HISTORICAL}==history
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
    assert records[-1]['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    from audit_a10_e1_fermion import adjudicate
    coverage=adjudicate(*[__import__('a10_e1_fermion_common').read(OUT/(n+'.json')) for n in ('primary','replay')])
    print('RECEIPT '+json.dumps({'schema':'A10_E1_FERMION_VALIDATION_RECEIPT_V1',
      'status':'PASS_BOUNDED_E1_REPLACEMENT_EVIDENCE_VALIDATION_ONLY','scientific_gate':STATUS,
      'tasks':records,'targeted_regression_tests':142,'new_regression_tests':20,'inherited_regression_tests':122,
      'scientific_regression_tests':scientific,'governance_regression_tests':governance,
      'wall_seconds':time.perf_counter()-start,'inherited_byte_bindings':len(inherited),'inherited_bytes_unchanged':True,
      'historical_fermion_and_chart_bytes_unchanged':True,'workspace_active_data_metadata_records':len(before),
      'inventory_kind':'size_and_mtime_ns_not_all_byte_audit','audit_time_changes':changes,
      'live_state_transaction_sha256':state,'historical_custody_exit':2,'unresolved_historical_references':7,
      'historical_original_bindings_resolved':False,'fresh_new_routes_byte_identical':3,
      'old_expensive_representation_or_source_calculations_rerun':False,'predecessor_chains_authenticated':9,
      'coefficient_coverage':coverage,'historical_equivalence_proved':False,
      'Stage_D_preserved':True,'Stage_E_completed':False,'E2_E5_executed':False,'sources_activated':False,
      'candidate_adopted':False,'HB1_C5_run':False,'C1_GS_calculated':False,'catalog_rebuilt':False,
      'formal_authority':'34/39_UNCHANGED','external_specialist_endorsement':False,
      'personal_outreach_planned':False,'solo_review_policy':'docs/SOLO_REVIEW_POLICY_V1.md'},
      sort_keys=True,separators=(',',':')),flush=True)
if __name__=='__main__':main()
