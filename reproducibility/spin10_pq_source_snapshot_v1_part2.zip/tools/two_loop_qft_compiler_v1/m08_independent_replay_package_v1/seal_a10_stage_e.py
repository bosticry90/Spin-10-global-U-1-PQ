"""Seal completed E1 stop evidence; historical inputs are never refreshed."""
import json,subprocess
from a10_stage_e_common import *

FILES=('A10_STAGE_E_CONTRACT_V1.md','A10_STAGE_E_RESULT.md','A10_STAGE_E_TECHNICAL_REVIEW_PACKET_V1.md',
       'a10_stage_e_common.py','a10_stage_e_primary.py','a10_stage_e_replay.py','a10_stage_e_checks.py',
       'audit_a10_stage_e.py','test_a10_stage_e.py','run_a10_stage_e.py','export_a10_stage_e.py',
       'validate_a10_stage_e.py','export_a10_stage_e_receipt.py','seal_a10_stage_e.py')

def hashfile(p):return sha256(p.read_bytes()).hexdigest()

def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['scientific_gate']==STOP and receipt['targeted_regression_tests']==122
    assert receipt['fresh_new_routes_byte_identical']==3 and not receipt['audit_time_changes']
    assert receipt['historical_custody_exit']==2 and not receipt['Stage_E_completed']
    state=hashfile(ROOT/'project_state.json');assert state==receipt['live_state_transaction_sha256']
    from audit_a10_stage_e import authenticate
    assert authenticate()['scientific_gate']==receipt['scientific_gate']
    files=[HERE/n for n in FILES]+[ROOT/'docs/A10_STAGE_E_E1_CURRENT.md']
    files+=sorted(p for p in OUT.glob('*.json') if p.name!='bindings.json')
    for p in files:
        raw=p.read_bytes();assert b'\r\n' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),('BAD_LINE_ENDINGS',str(p))
    manifests=[HERE/n/'bindings.json' for n in ('frozen_source_component_decoder','frozen_phase_c_scalar_action',
        'frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation','frozen_a10_cotangent_adapter',
        'frozen_a10_bv_master','frozen_a10_gauge_euler_adapter','frozen_a10_bv_integration')]
    p=read(OUT/'primary.json')
    history={str((HERE/n).relative_to(ROOT).as_posix()):value for n,value in p['recovery']['historical_bytes'].items()}
    assert all(hashfile(ROOT/n)==v for n,v in history.items())
    result={'schema':'A10_STAGE_E_E1_BYTE_BINDINGS_V1',
        'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'byte_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in files},
        'inherited_manifest_sha256':{p.relative_to(ROOT).as_posix():hashfile(p) for p in manifests},
        'historical_input_sha256':history,'state_sha256':state,'scientific_disposition':STOP,
        'authority_changed':False,'candidate_adopted':False,'sources_activated':False,
        'Stage_D_preserved':True,'Stage_E_completed':False,'E2_E5_executed':False,
        'personal_outreach':False,'remote_push':False,
        'post_validation_finalization':'receipt export and byte sealing only; no scientific edits after validation'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(files))+' files; E1 stopped and historical custody remains exit 2',flush=True)
if __name__=='__main__':main()
