"""Read-only exact completeness and addressed-operator reconstruction checks."""
from hashlib import sha256
from jcat_final_operator_evaluator import *
from execute_jcat_packet_catalog import bindings

PROMOTION='M08_JCAT3_JCAT12_JOINT_PERMUTATION_LORENTZ_IBP_CATALOG_V1'
NEXT='M08_C5_COMPLETE_LOCAL_FUNCTIONAL_COMPLEX_PENDING'


def evidence():
    assert hasattr(__import__('sitecustomize'),'DENIED')
    assert load(OUT/'JCAT8_custody.json')['immutable_input_byte_hashes']==bindings()
    for k in range(8,12):assert load(OUT/f'JCAT{k}_checkpoint.json')[f'JCAT{k}']=='PASS'
    for path in OUT.glob('*.json'):load(path)
    encoding=load(OUT/'JCAT10_lossless_whitespace_encoding_receipt.json')
    for name,h in encoding['compact_byte_hashes'].items():assert sha256((OUT/name).read_bytes()).hexdigest()==h
    engine=FinalOperators();counts=load(OUT/'JCAT11_final_counting_ledger.json')
    @lru_cache(None)
    def pattern_record(name):return load(OUT/name)
    replay=load(OUT/'JCAT11R_character_census_closed.json')
    assert counts['final_statistics_allowed_dimension']==replay['final_dimension']
    signatures=set();ids=set();orbit_count=0;rows=[];IBP_owners={}
    for group in engine.engine.ledger:
        cid=group['class_id'];sig={m['signature_id'] for m in group['members']};signatures.update(sig)
        # A divergence preserves ordinary field content, parity, total derivative
        # grade and constant internal carrier/copy tensor. Check, rather than
        # assume, that its entire support belongs to a single declared block.
        for member in group['members']:
            sid=member['signature_id'];source_row=engine.engine.engine.rows[sid]
            for ji in member['jet_indices']:
                degree,key=tup(source_row['raw_Lorentz_derivative_addresses'][ji])
                support=(sid,degree,key[0])
                assert support not in IBP_owners or IBP_owners[support]==cid
                IBP_owners[support]=cid
        cls=engine.class_data(cid);orbits=engine.orbit_data(cid)
        assert cls['signature_provenance']==[m['signature_id'] for m in group['members']]
        assert cls['allowed_dimension']==len(cls['operator_addresses'])
        assert len(cls['orbits'])==len(orbits)
        assert sum(o['post_IBP_dimension'] for o in orbits)==next(r['quotient_dimension'] for r in load(OUT/'JCAT9_IBP_ledger.json')['rows'] if r['class_id']==cid)
        by_orbit=defaultdict(list)
        for op in cls['operator_addresses']:
            assert op['operator_id'] not in ids;ids.add(op['operator_id'])
            by_orbit[op['orbit_index']].append(op['local_basis_column'])
        for i,o in enumerate(orbits):
            stat=cls['orbits'][i];p=pattern_record('JCAT10_PATTERN_'+o['pattern_id']+'.json')
            s=pattern_record('JCAT11_PATTERN_'+stat['statistics_pattern_id']+'.json')
            B=matrix(s['canonical_allowed_local_basis']);Pi=matrix(s['local_statistics_projector'])
            assert by_orbit[i]==list(range(B.cols)) and B.cols==stat['allowed_dimension']
            assert o['orbit_id']==stat['orbit_id']
            hom=tup(o['canonical_homogeneous_components'])
            assert len({tuple(hom[j] for j in perm) for perm in o['coset_transport']})==len(o['coset_transport'])
            assert len(o['coset_transport'])*p['local_dimension']==o['post_IBP_dimension']
            if group['trivial_singleton']:
                selector=o['canonical_packet_source_selector']
                # The selector is an exact finite address recipe, not a count-only object.
                assert selector['source_enumeration_sha256']==canonical(engine.singleton_sources(cid)[hom])
                assert len(engine.singleton_sources(cid)[hom])==selector['coordinate_count']==p['local_dimension']
            else:
                assert o['canonical_JCAT7_block']==engine.engine.records[cid][hom]['block_id']
                assert matrix(engine.ibp(cid,hom)['quotient_map']).rows==p['local_dimension']
            orbit_count+=1
        assert sum(s['allowed_dimension'] for s in cls['orbits'])==cls['allowed_dimension']
        rows.append({'class_id':cid,'final_dimension':cls['allowed_dimension'],
            'orbit_count':len(orbits),'signature_provenance':sorted(sig),'parity':group['parity'],
            'status':'COMPLETE_EXACT_ADDRESSED_LOCAL_OPERATORS'})
    # Recheck all finite projector matrices once, independently of address multiplicities.
    for sid in counts['statistics_pattern_ids']:
        s=load(OUT/('JCAT11_PATTERN_'+sid+'.json'));p=load(OUT/('JCAT10_PATTERN_'+s['pattern_id']+'.json'))
        B=matrix(s['canonical_allowed_local_basis']);Pi=matrix(s['local_statistics_projector'])
        assert Pi*Pi==Pi and Pi*B==B and B.rank()==B.cols==Pi.rank()==s['allowed_dimension']
        positions=tup(p['species_positions']);G=[tup(v) for v in p['G_elements']]
        signs={g:v for g,v in zip(G,s['G_statistics_character'])}
        for r in p['local_matrices']:
            h=tup(r['permutation']);assert matrix(r['matrix'])*B==signs[h]*B
        assert sum(r['multiplicity']*r['Specht_dimension'] for r in p['Young_decomposition'])==p['induced_dimension']
    # Every active IBP quotient is an exact structure-preserving map.
    for cid,blocks in engine.engine.records.items():
        for hom,b in blocks.items():
            r=engine.ibp(cid,hom);R=matrix(r['packet_IBP_relation_basis'])
            Q=matrix(r['quotient_map']);S=matrix(r['section'])
            assert Q*R==sp.zeros(Q.rows,R.cols) and Q*S==sp.eye(Q.rows)
            assert Q.rows+R.cols==Q.cols and R.rank()==R.cols
    assert len(signatures)==431 and len(rows)==362 and len(ids)==counts['final_statistics_allowed_dimension']
    assert sum(r['final_dimension'] for r in rows)==len(ids)
    assert sum(r['final_dimension'] for r in rows if r['parity']=='PARITY_ODD')==counts['parity_odd_final_dimension']
    control=load(OUT/'JCAT11R_joint_statistics_control.json')
    assert control['paired_bosonic_surviving_rank']==1 and control['one_negative_factor_bosonic_output_rank']==0
    return {'rows':rows,'signature_count':len(signatures),'completion_class_count':len(rows),
        'active_carrier_copy_block_count':sum(len(b) for b in engine.engine.records.values()),
        'carrier_copy_orbit_count':orbit_count,'final_operator_dimension':len(ids),
        'parity_even_final_dimension':counts['parity_even_final_dimension'],
        'parity_odd_final_dimension':counts['parity_odd_final_dimension'],
        'IBP_relation_rank':counts['IBP_relation_rank'],'post_IBP_dimension':counts['post_IBP_dimension'],
        'all_431_expansion_signatures_preserved':True,'incomplete_object_count':0,
        'IBP_support_partition_certificate':'Every ordinary signature/derivative-grade/parity support has exactly one completion-class owner; constant internal carrier/copy tensors are derivative-inert'}


def reconstruction_coverage():
    engine=FinalOperators();ledger=load(OUT/'JCAT11_final_counting_ledger.json')['rows']
    candidates=[r for r in ledger if r['allowed_dimension']]
    cases={'largest_final_class':max(candidates,key=lambda r:(r['allowed_dimension'],r['class_id']))['class_id'],
        'cross_signature_null_ancestry':'BGC_de08589c4371006e30e7',
        'joint_Yang_Mills':'BGC_36ce114afb3c520e5d7f',
        'parity_odd':next(r['class_id'] for r in candidates if r['parity']=='PARITY_ODD')}
    for role,predicate in (
        ('repeated_Grassmann',lambda ns:any(ns.count(n)>1 and engine.types[n]['Grassmann_parity']=='ODD' for n in ns)),
        ('source',lambda ns:any(engine.types[n].get('role','').upper().find('SOURCE')>=0 or n.startswith(('K_','L_')) for n in ns)),
        ('auxiliary',lambda ns:any(n in ('Lambda_H','lambda_L') for n in ns))):
        hit=next((r for r in candidates if predicate(engine.engine.groups[r['class_id']]['homogeneous_roles'])),None)
        assert hit,('MISSING_FINAL_EVALUATOR_ROLE',role)
        cases[role]=hit['class_id']
    return {'cases':[{ 'role':role,'class_id':cid,'operator_indices':[0]} for role,cid in cases.items()],
        'selection':'First deterministic nonzero address per declared coverage role; largest by final addressed dimension'}


def reconstruct(case,engine=None):
    engine=engine or FinalOperators();cid=case['class_id'];cls=engine.class_data(cid);results=[]
    for index in case['operator_indices']:
        op=cls['operator_addresses'][index];terms=engine.representative(cid,op)
        o=engine.orbit_data(cid)[op['orbit_index']];hom=tup(o['canonical_homogeneous_components'])
        group=engine.engine.groups[cid]
        stat=load(OUT/('JCAT11_PATTERN_'+cls['orbits'][op['orbit_index']]['statistics_pattern_id']+'.json'))
        b=matrix(stat['canonical_allowed_local_basis'])[:,op['local_basis_column']]
        if group['trivial_singleton']:
            sources=engine.singleton_sources(cid)[hom]
            lookup={engine.engine.source_key(s):i for i,s in enumerate(sources)}
            v=sp.zeros(len(sources),1)
            for t in terms:
                k=engine.engine.source_key(t['source'])
                if k in lookup:v[lookup[k]]+=sp.sympify(t['coefficient'])
            assert v==b
        else:
            primary=engine.engine.primary(cid,hom);ibp=engine.ibp(cid,hom)
            lookup={engine.engine.source_key(s):i for i,s in enumerate(primary['sources'])};v=sp.zeros(len(lookup),1)
            for t in terms:
                k=engine.engine.source_key(t['source'])
                if k in lookup:v[lookup[k]]+=sp.sympify(t['coefficient'])
            faithful=matrix(primary['quotient_map'])*v;P=matrix(primary['canonical_packet_basis'])
            pivots=list(P.T.rref()[1]);packet=P.extract(pivots,range(P.cols)).inv()*faithful.extract(pivots,[0])
            assert P*packet==faithful and matrix(ibp['quotient_map'])*packet==b
        results.append({'operator_id':op['operator_id'],'expansion_term_count':len(terms),
            'expansion_hash':canonical(terms),'canonical_quotient_round_trip':'ZERO_EXACT',
            'representative_type':'EXACT_LOCAL_DENSITY_REPRESENTATIVE_MODULO_IBP',
            'Grassmann_rule':'Final species sign projection; homogeneous tags are provenance, not independently valued physical fields'})
    return {'case':case,'results':results,'status':'PASS_EXACT_FINAL_OPERATOR_RECONSTRUCTION'}
