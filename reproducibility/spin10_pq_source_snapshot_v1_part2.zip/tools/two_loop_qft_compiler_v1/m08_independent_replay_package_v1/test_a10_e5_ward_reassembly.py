"""Scientific regressions for corrected Ward coefficients and unknown partners."""
import unittest
from audit_a10_e5_ward_reassembly import *


class WardReassemblyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_all_thirteen_measured_sectors_have_declared_units(self):
        expected={**EXPECTED_G,'ghost_source_g2':2}
        self.assertEqual(len(self.a['sectors']),13)
        for n,P in self.a['sectors'].items():self.assertTrue(all(s.Poly(z,g).monoms()==[(expected[n],)] for z in decode_typed(P).values()))
    def test_corrected_sum_has_no_missing_or_duplicate_sector(self):
        w=alphabet();self.assertFalse(canonical(w.add(decode_typed(self.a['canonical_measured_residue_sum']),w.scale(w.add(*(decode_typed(P) for P in self.a['sectors'].values())),-1))))
    def test_actual_gauge_source_has_no_extra_metric(self):
        actual=decode_typed(read(HERE/'frozen_a10_e5_source_vertex/primary.json')['canonical_normalization']['gauge_source_derivative_projection']);self.assertEqual(decode_typed(self.a['sectors']['gauge_source_g1']),actual)
    def test_old_metric_error_is_preserved_and_rejected(self):self.assertEqual(len(self.a['old_gauge_source_sign_error']),99);self.assertTrue(self.c['old_to_corrected_Ward_difference'])
    def test_both_H_affine_connections_retained(self):self.assertEqual(self.a['operator_inventory']['affine_H_connection'],96);self.assertEqual(self.a['operator_columns'],1334)
    def test_constant_parameter_projection_is_zero(self):self.assertFalse(self.a['constant_H_Ward_residual'])
    def test_local_parameter_Euler_survives(self):self.assertTrue(self.c['canonical_parameter_Euler_witness']['full_Euler'])
    def test_full_parameter_current_reconstructs_density(self):
        w=alphabet();raw=decode_typed(self.a['local_Ward_variation']);A=decode_typed(self.a['anchored_Ward_parameter_density']);C=[decode_typed(P) for P in self.a['full_Ward_IBP_currents']]
        self.assertFalse(canonical(w.add(raw,w.scale(A,-1),w.scale(w.add(*(w.D(P,mu) for mu,P in enumerate(C))),-1))))
    def test_dropped_currents_have_nonzero_residual(self):self.assertGreater(self.c['negative_controls']['omit_current_exact_discrepancy_terms'],0)
    def test_even_parameters_all_twelve_Eulers(self):self.assertEqual(set(self.a['Ward_parameter_Eulers']),{f'omega{h}' for h in H})
    def test_physical_parameter_witness_is_real(self):self.assertTrue(all(clean(z-s.conjugate(z))==0 for z in decode_typed(self.c['real_physical_parameter_Euler_witness']['full_Euler']).values()))
    def test_new_JC_pole_local_Ward_is_proved_zero(self):self.assertFalse(self.a['new_JC_local_Ward_residual'])
    def test_forward_and_reverse_predecessors_agree(self):self.assertEqual(census(decode_typed(self.a['local_Ward_variation']),'primary'),census(decode_typed(self.a['local_Ward_variation']),'replay'))
    def test_external_background_predecessors_are_retained(self):self.assertEqual(self.c['negative_controls']['omitting_A_predecessor_loses_families'],self.c['target_families'])
    def test_total_connection_predecessors_are_retained(self):self.assertEqual(self.c['negative_controls']['omitting_B_predecessor_loses_families'],self.c['target_families'])
    def test_affine_B_minus_A_omission_controls_nonzero(self):self.assertTrue(self.u['omitted_A_affine_residual']);self.assertTrue(self.u['omitted_B_affine_residual'])
    def test_unknown_coefficients_never_measured_zero(self):self.assertTrue(all(x['coefficient'] is None and not x['coefficient_bound'] for row in self.c['complete_Ward_dependencies'] for x in row['necessary_predecessors']))
    def test_unequal_jet_same_color_ghosts_survive(self):
        w=alphabet();self.assertTrue(w.mul(w.var('C14'),w.D(w.var('C14'),0)));self.assertFalse(w.mul(w.var('C14'),w.var('C14')))
    def test_wrong_source_primal_chart_is_rejected(self):
        w,sub,back,source,anti,Cinv,Cphys=frames('primary');pullback=w.replace
        for i in IDS:
            register(w,f'JCp{i}',(2,-2,0))
            back[f'JCp{i}']=w.add(*(w.scale(w.var(f'JC{j}'),Cphys[i,j]) for j in IDS if Cphys[i,j]))
        physical=decode_typed(read(HERE/'frozen_a10_e5_ghost_source/primary.json')['physical_full_g_squared_xi_density'])
        wrong=canonical(pullback(physical,back));self.assertTrue(canonical(w.add(wrong,w.scale(decode_typed(self.a['sectors']['ghost_source_g2']),-1))))
    def test_indexed_scalar_and_finite_nodes_stay_separate(self):
        nodes=self.a['separate_indexed_or_regulated_nodes'];self.assertFalse(nodes['scalar_g0_indexed']['merged_into_Minkowski_polynomial_sum']);self.assertFalse(nodes['ghost_g1_power_and_finite']['merged_into_local_logarithmic_sum'])
    def test_selected_Slavnov_and_prior_g3_failure_keep_their_scopes(self):self.assertTrue(self.c['selected_GS_Slavnov_left_side_qualification_preserved']);self.assertTrue(self.c['prior_g3_candidate_failure_preserved'])
    def test_unknown_breaking_no_new_loop_or_full_restoration(self):self.assertFalse(self.c['unmeasured_Gamma_Delta_contacts_measure_or_IR_set_to_zero']);self.assertFalse(self.c['new_actual_loop_candidate_or_completion_fit']);self.assertFalse(self.c['whole_goal_complete'])


if __name__=='__main__':unittest.main()
