"""Bounded JCAT7 global covariant grammar and independent affine Ward replay.

Homogeneous fields retain independent tags. Only background jets commute as
the same connection. No IBP, final statistics, EOM or BRST calculation.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product, permutations, combinations, combinations_with_replacement
from hashlib import sha256
import json
import sympy as sp
from jcat3_contract_preflight import HERE, ROOT, load, canonical, AUTHORITY
from int8_block_conjugation_v2 import BlockConjugation, address_key
from jcat_realization_v3 import full_covector, tup, quotient
from jcat_background_packets_v2 import serial
from jcat_physical_jets import canon, matchings
from execute_scalar_ast_channel_bridge import matrix
from execute_scalar_adapter_v2 import registry_generators

OLD = HERE/'frozen_jcat_realization_v3'
OUT = HERE/'frozen_jcat_global_packets'
NEXT = 'M08_JCAT8_JCAT12_PACKET_LEVEL_LORENTZ_IBP_STATISTICS_PENDING'


@lru_cache(None)
def norm(v):
    return sp.expand(v)


def add(result, key, value):
    if value:
        result[key] = norm(result.get(key, 0)+value)
        if not result[key]: del result[key]


def contract():
    return {'contract_id': 'M08_JCAT7_GLOBAL_BACKGROUND_COMPLETION_CONTRACT_V1',
        'source_commit': '24061dc', 'homogeneous_occurrences': 'TAGGED_UNTIL_JCAT11',
        'background_realization': 'SAME_COMMUTING_CONNECTION_AND_ORDINARY_JETS',
        'classes': 'Homogeneous ordered roles, total canonical dimension, Lorentz parity; carrier/copy subblocks refine the class',
        'connection_coordinates': 'a=g10*Abar in current physical registry coordinates',
        'primary_grammar': ['ordered Dbar derivatives on homogeneous fields',
            'Fbar derived from frozen total connection', 'ordered Dbar derivatives on Fbar',
            'qualified invariant contractions with metric or one epsilon'],
        'curvature': 'g10 Fbar_mu_nu = partial_mu a_nu-partial_nu a_mu+[a_mu,a_nu]',
        'replay': 'Independent ordinary component jet prolongation of delta a=[theta,a]-partial theta',
        'quotient': 'Existing exact realization only; no IBP/EOM/BRST/statistics',
        'acceptance': 'Exact primary faithful span equals independent faithful Ward kernel in every class',
        'physical_Lorentz_dimension': 4, 'epsilon_0123': 1,
        'parity_odd_included': True, 'upstream_changed': False,
        'not_executed': ['JCAT8_JCAT12', 'IBP', 'final_statistics', 'C5', 'C6', 'D6',
            'E', 'M08_attempt_2', 'M09_M13', 'Layer6', 'C1_GS'], 'formal_authority': AUTHORITY}


def lorentz_indices(key):
    """Separate dummy index occurrences before imposing ordinary derivatives."""
    parity, contraction = key
    pairs = contraction if parity == 'PARITY_EVEN' else [contraction]
    attached = defaultdict(list); vector = {}
    for pair in pairs:
        for token in pair:
            label = sum(len(v) for v in attached.values())+len(vector)
            if token[0] == 'v': vector[token[1]] = label
            else: attached[token[1]].append(label)
    # Distinct labels carry the exact matching / epsilon, not component values.
    relation = tuple(tuple(range(2*i, 2*i+2)) for i in range(len(pairs))) if parity == 'PARITY_EVEN' else tuple(range(4))
    return vector, dict(attached), relation


def canonical_term(factors, parity, contraction):
    """Direct polarized monomial normal form, with at most four Lorentz indices.

    Each factor is (tag, color, vector index or -1, ordinary derivative labels).
    The homogeneous tag includes its occurrence number. Background a is untagged.
    """
    groups = defaultdict(list)
    for i, (tag, color, vector, derivatives) in enumerate(factors):
        groups[(tag, color, len(derivatives), vector != -1)].append(i)
    keys = sorted(groups)
    orders = product(*(permutations(groups[k]) if k[0] == 'A' else [tuple(groups[k])] for k in keys))
    best = None; signs = set()
    for chunks in orders:
        order = tuple(i for chunk in chunks for i in chunk)
        tokens = {}
        for j, i in enumerate(order):
            _, _, vector, derivatives = factors[i]
            if vector != -1: tokens[vector] = ('v', j)
            for label in derivatives: tokens[label] = ('p', j)
        mapped = tuple(tuple(tokens[x] for x in pair) for pair in contraction) if parity == 'PARITY_EVEN' else tuple(tokens[x] for x in contraction)
        lorentz, phase = canon(parity, mapped)
        if not phase: return None, 0
        candidate = (tuple((factors[i][0], factors[i][1], len(factors[i][3]), factors[i][2] != -1) for i in order), lorentz)
        if best is None or candidate < best: best, signs = candidate, {phase}
        elif candidate == best: signs.add(phase)
    if len(signs) != 1: return None, 0
    return best, next(iter(signs))


def term_factors(key):
    basics, (parity, contraction) = key
    vector, derivatives, relation = lorentz_indices((parity, contraction))
    return tuple((tag, color, vector.get(i, -1), tuple(derivatives.get(i, ())))
        for i, (tag, color, _, _) in enumerate(basics)), parity, relation


def normalize_words(words, parity, contraction):
    result = {}
    for factors, coefficient in words:
        key, phase = canonical_term(factors, parity, contraction)
        if phase: add(result, key, phase*coefficient)
    return result


def poly_hash(poly):
    return canonical([[k, str(v)] for k, v in sorted(poly.items())])


class GlobalPackets:
    def __init__(self):
        self.catalog = BlockConjugation.from_frozen()
        self.ledger = load(HERE/'frozen_jcat_background_packets_v2/JCAT7V2_expansion_address_ledger.json')['rows']
        self.rows = {r['signature_id']: r for r in self.ledger}
        self.contract_rows = {r['signature_id']: r for r in load(HERE/'frozen_jcat3_contract_preflight/JCAT3_signature_contract_ledger.json')['rows']}
        self.realization = load(OLD/'JCAT7V3_reusable_realization_catalog.json')
        self.realization_rows = {r['signature_id']: r for r in self.realization['rows']}
        self.fid_by_families = {tuple(d['ordered_character_families']): fid for fid, d in self.catalog.descriptors.items()}
        self.connection = self.build_connection()
        self.as_by_component = self.connection['offsets']

    def build_connection(self):
        roots = load(HERE/'frozen_c3/C3_representation_basis.json')['h_basis']
        P = sp.SparseMatrix(45, 12, {(r['index'], j): sp.sympify(r['coefficient'])
            for j, col in enumerate(roots) for r in col['raw_so10_coordinates']})
        inverse = (P.H*P).inv()*P.H
        physical = {r['source_component']: matrix(r['physical_columns']) for r in
            load(HERE/'frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json')['components']}
        offsets = {}; labels = []; coefficients = []; offset = 0
        for row in self.catalog.components['A']:
            cid = row['component_id']; columns = physical[cid]
            co = (inverse*columns).applyfunc(sp.simplify)
            assert (P*co-columns).applyfunc(sp.simplify) == sp.zeros(45, columns.cols)
            assert row['copy_multiplicity'] == 1
            offsets[cid] = offset
            coefficients.append(co); labels.append((cid, tuple(row['H_label']), offset, co.cols))
            offset += co.cols
        self.root_coefficients = sp.ImmutableSparseMatrix(sp.Matrix.hstack(*coefficients))
        assert offset == 12 and self.root_coefficients.det() != 0
        f = sp.zeros(12, 144)
        for cid, label, start, d in labels:
            for b, G in enumerate(self.actions(label)):
                for (i, j), value in G.todok().items(): f[start+i, b*12+start+j] = value
        assert all(f[a,b*12+c]+f[a,c*12+b] == 0 for a,b,c in product(range(12), repeat=3))
        self.f = sp.ImmutableSparseMatrix(f)
        self.adjoint_actions = tuple(sp.ImmutableSparseMatrix(12, 12,
            {(a,c):f[a,b*12+c] for a,c in product(range(12), repeat=2) if f[a,b*12+c]}) for b in range(12))
        for b,c in product(range(12), repeat=2):
            target = sum((f[a,b*12+c]*self.adjoint_actions[a] for a in range(12)), sp.zeros(12))
            assert self.adjoint_actions[b]*self.adjoint_actions[c]-self.adjoint_actions[c]*self.adjoint_actions[b] == target
        return {'offsets': offsets, 'labels': labels, 'root_coordinate_columns': serial(self.root_coefficients),
            'bracket': serial(f), 'antisymmetry': 'ZERO_EXACT', 'Jacobi': 'ZERO_EXACT',
            'physical_column_residual': 'ZERO_EXACT', 'normalization': 'a=g10 Abar; frozen physical sqrt(2) columns and 1/sqrt(2) generator normalization cancel'}

    @lru_cache(None)
    def actions(self, label):
        raw = registry_generators(label, self.catalog.duals)
        return tuple(sp.ImmutableSparseMatrix(sum((self.root_coefficients[j,a]*raw[j] for j in range(12)), sp.zeros(raw[0].rows)).applyfunc(sp.simplify)) for a in range(12))

    @lru_cache(None)
    def addresses(self, fid):
        desc = self.catalog.descriptors[fid]
        return tuple(a for key, _, _, _ in self.catalog.blocks(desc) for a in self.catalog.addresses(fid, key))

    def census(self):
        groups = {}; rows = []
        for row in self.ledger:
            sid = row['signature_id']; names = tuple(r['field'] for r in row['ordered_occurrences'])
            hom = tuple(n for n in names if n != 'Abar_H_mu')
            count = names.count('Abar_H_mu'); base = self.contract_rows[sid]['degree_bounds']['base_dimension']
            partition = defaultdict(list)
            for j, (degree, key) in enumerate(row['raw_Lorentz_derivative_addresses']):
                spec = (hom, base+degree, key[0]); partition[spec].append(j)
            for spec, js in partition.items():
                cid = 'BGC_'+canonical(spec)[:20]
                group = groups.setdefault(cid, {'class_id': cid, 'homogeneous_roles': spec[0],
                    'canonical_dimension': spec[1], 'parity': spec[2], 'members': [],
                    'ORDERED_COORDINATE_DIMENSION': 0, 'REALIZATION_NULLITY': 0})
                dim = row['internal_address_count']*len(js)
                null = 0
                realization_row = self.realization_rows[sid]
                cls = self.realization['reusable_background_classes'].get(realization_row['class_id'])
                if cls is not None:
                    nj = len(row['raw_Lorentz_derivative_addresses'])
                    for block in cls['blocks']:
                        hit = [i for i in block['ordered_coordinate_indices'] if i % nj in js]
                        assert not hit or len(hit) == len(block['ordered_coordinate_indices']), 'REALIZATION_BLOCK_CROSSES_DIMENSION_OR_PARITY'
                        if hit: null += block['nullity']
                group['members'].append({'signature_id': sid, 'jet_indices': js, 'internal_family': row['internal_family'],
                    'ordered_dimension': dim, 'realization_nullity': null, 'background_count': count})
                group['ORDERED_COORDINATE_DIMENSION'] += dim; group['REALIZATION_NULLITY'] += null
                rows.append({'signature_id': sid, 'class_id': cid, 'jet_indices': js, 'dimension': dim})
        for group in groups.values():
            group['REALIZED_TAGGED_DIMENSION'] = group['ORDERED_COORDINATE_DIMENSION']-group['REALIZATION_NULLITY']
            group['has_background'] = any(m['background_count'] for m in group['members'])
            group['trivial_singleton'] = all(not m['background_count'] and
                all(self.rows[m['signature_id']]['raw_Lorentz_derivative_addresses'][j][0] == 0 for j in m['jet_indices']) for m in group['members'])
        assert sum(g['ORDERED_COORDINATE_DIMENSION'] for g in groups.values()) == 369980
        assert sum(g['REALIZATION_NULLITY'] for g in groups.values()) == 1356
        assert sum(g['REALIZED_TAGGED_DIMENSION'] for g in groups.values()) == 368624
        return {'status': 'PASS_NONOVERLAPPING_COMPLETION_CLASS_CENSUS', 'classes': sorted(groups.values(), key=lambda g:g['class_id']),
            'signature_coverage': rows, 'signature_count': 431,
            'ORDERED_COORDINATE_DIMENSION': 369980, 'REALIZATION_NULLITY': 1356,
            'REALIZED_TAGGED_DIMENSION': 368624,
            'partition_certificate': 'Each (signature, internal address, raw jet index) occurs once, by its homogeneous ordered roles / dimension / parity key',
            'addresses_deleted': False}

    def source_blocks(self, group):
        blocks = defaultdict(list)
        for member in group['members']:
            row = self.rows[member['signature_id']]
            names = tuple(r['field'] for r in row['ordered_occurrences']); bg = tuple(i for i,n in enumerate(names) if n == 'Abar_H_mu')
            for ai, address in enumerate(self.addresses(row['internal_family'])):
                slots, copies = self.catalog.address_parts(address)[2:4]
                hom = tuple((slots[i], copies[i]) for i in range(len(slots)) if i not in bg)
                for ji in member['jet_indices']:
                    blocks[hom].append({'signature_id': member['signature_id'], 'address': address,
                        'internal_ordinal': ai, 'jet_index': ji, 'background_slots': bg})
        assert sum(map(len, blocks.values())) == group['ORDERED_COORDINATE_DIMENSION']
        return sorted(blocks.items())

    @lru_cache(None)
    def tensor(self, encoded):
        address = json.loads(encoded)
        from jcat_internal_permutations import coordinates
        dims, column = full_covector(self.catalog, address)
        return tuple((coordinates(i, dims), v) for (i,_),v in column.todok().items())

    def source_words(self, source):
        row = self.rows[source['signature_id']]
        names = tuple(r['field'] for r in row['ordered_occurrences'])
        address = source['address']; slots, copies = self.catalog.address_parts(address)[2:4]
        degree, key = tup(row['raw_Lorentz_derivative_addresses'][source['jet_index']])
        vector, derivatives, contraction = lorentz_indices(key)
        hom_i = {}; h = 0
        for i,n in enumerate(names):
            if n != 'Abar_H_mu': hom_i[i] = h; h += 1
        words = []
        for colors, coefficient in self.tensor(json.dumps(address, sort_keys=True)):
            factors = tuple(('A' if i in source['background_slots'] else 'H'+str(hom_i[i]),
                self.as_by_component[slots[i]]+colors[i] if i in source['background_slots'] else colors[i],
                vector.get(i, -1), tuple(derivatives.get(i, ()))) for i in range(len(slots)))
            words.append((factors, coefficient))
        return words, key[0], contraction

    def source_polynomial(self, source):
        return normalize_words(*self.source_words(source))

    @lru_cache(None)
    def frozen_null_columns(self, signature_id):
        cls=self.realization['reusable_background_classes'].get(self.realization_rows[signature_id]['class_id'])
        columns=[]
        if cls:
            for block in cls['blocks']:
                M=matrix(block['null_basis'])
                for j in range(M.cols):
                    columns.append({index:M[i,j] for i,index in enumerate(block['ordered_coordinate_indices']) if M[i,j]})
        return tuple(columns)

    def known_nullspace(self, sources):
        original={}
        for i,s in enumerate(sources):
            nj=len(self.rows[s['signature_id']]['raw_Lorentz_derivative_addresses'])
            original[(s['signature_id'],s['internal_ordinal']*nj+s['jet_index'])]=i
        columns=[]
        for sid in sorted({s['signature_id'] for s in sources}):
            for column in self.frozen_null_columns(sid):
                hit={(sid,i):v for i,v in column.items() if (sid,i) in original}
                if hit:
                    assert len(hit)==len(column), 'FROZEN_REALIZATION_NULL_RELATION_CROSSES_COMPLETION_SUBBLOCK'
                    columns.append(sp.SparseMatrix(len(sources),1,{(original[k],0):v for k,v in hit.items()}))
        return sp.SparseMatrix.hstack(*columns) if columns else sp.zeros(len(sources),0)

    @lru_cache(None)
    def covjet(self, hom, slot, color, vector, order):
        if not order: return (((('H'+str(slot), color, vector, ()),), sp.S.One),)
        outer, rest = order[0], order[1:]
        result = []
        for factors, coefficient in self.covjet(hom, slot, color, vector, rest):
            for i, f in enumerate(factors):
                new = list(factors); new[i] = (f[0], f[1], f[2], f[3]+(outer,))
                result.append((tuple(new), coefficient))
        G = self.actions(tuple(self.catalog.by_id[hom[slot][0]]['H_label']))
        for a, generator in enumerate(G):
            for j in range(generator.cols):
                value = generator[color,j]
                if value:
                    for factors, coefficient in self.covjet(hom, slot, j, vector, rest):
                        result.append(((('A', a, outer, ()),)+factors, coefficient*value))
        return tuple(result)

    def covariantized(self, source, hom):
        words, parity, contraction = self.source_words(source)
        sample = words[0][0] if words else ()
        orders = list(product(*(tuple(dict.fromkeys(permutations(f[3]))) for f in sample)))
        output = []
        for order in orders:
            expanded = []
            for factors, coefficient in words:
                pieces = [self.covjet(hom, int(f[0][1:]), f[1], f[2], ds) for f,ds in zip(factors,order)]
                for choice in product(*pieces):
                    expanded.append((tuple(f for fs,_ in choice for f in fs), coefficient*sp.prod(v for _,v in choice)))
            output.append(({'kind': 'COVARIANT_DERIVATIVE_CONTRACTION', 'leading_source': source,
                'ordered_derivative_labels': order}, normalize_words(expanded, parity, contraction)))
        return output

    @lru_cache(None)
    def curvature(self, color, mu, nu, order=()):
        if not order:
            result = [((('A',color,nu,(mu,)),), sp.S.One), ((('A',color,mu,(nu,)),), -sp.S.One)]
            for b,c in product(range(12), repeat=2):
                v = self.f[color,b*12+c]
                if v: result.append(((('A',b,mu,()),('A',c,nu,())),v))
            return tuple(result)
        outer, rest = order[0], order[1:]; result = []
        for factors, coefficient in self.curvature(color,mu,nu,rest):
            for i,f in enumerate(factors):
                new=list(factors); new[i]=(f[0],f[1],f[2],f[3]+(outer,))
                result.append((tuple(new),coefficient))
        for a,G in enumerate(self.adjoint_actions):
            for j in range(12):
                if G[color,j]:
                    for factors,coefficient in self.curvature(j,mu,nu,rest):
                        result.append(((('A',a,outer,()),)+factors,coefficient*G[color,j]))
        return tuple(result)

    def curvature_candidates(self, group, hom):
        """All one-F (with bounded D) and two-F invariant contractions."""
        homroles = group['homogeneous_roles']; budget = group['canonical_dimension']
        homdim = budget-next((self.rows[m['signature_id']]['background_occurrences']+
            self.rows[m['signature_id']]['raw_Lorentz_derivative_addresses'][m['jet_indices'][0]][0]
            for m in group['members']),0)
        result=[]
        for nf in (1,2):
            degree=budget-homdim-2*nf
            if degree<0 or (nf==2 and hom): continue
            prototype=next((self.rows[m['signature_id']] for m in group['members']
                if m['background_count']==nf),None)
            if prototype is None: continue
            names=tuple(r['field'] for r in prototype['ordered_occurrences'])
            bg=tuple(i for i,n in enumerate(names) if n=='Abar_H_mu')
            if len(bg)!=nf: continue
            for address in self.addresses(prototype['internal_family']):
                slots,copies=self.catalog.address_parts(address)[2:4]
                htuple=tuple((slots[i],copies[i]) for i in range(len(slots)) if i not in bg)
                if htuple!=hom: continue
                vectors={}; fidx={}; nextlabel=0; hi=0
                for i,name in enumerate(names):
                    if i in bg: fidx[i]=(nextlabel,nextlabel+1); nextlabel+=2
                    else:
                        typ=self.contract_rows[prototype['signature_id']]['field_types'][i]['Lorentz_type']
                        if typ=='VECTOR': vectors[i]=nextlabel; nextlabel+=1
                        hi+=1
                if nextlabel+degree not in (0,2,4): continue
                for placement in combinations_with_replacement(range(len(names)),degree):
                    ds=defaultdict(list)
                    for di,slot in enumerate(placement): ds[slot].append(nextlabel+di)
                    if group['parity']=='PARITY_EVEN': contractions=list(matchings(tuple(range(nextlabel+degree))))
                    else: contractions=[tuple(range(4))] if nextlabel+degree==4 else []
                    for contraction in contractions:
                        for order in product(*(tuple(dict.fromkeys(permutations(ds[i]))) for i in range(len(names)))):
                            expanded=[]
                            for colors,coefficient in self.tensor(json.dumps(address,sort_keys=True)):
                                pieces=[]; hi=0
                                for i,name in enumerate(names):
                                    if i in bg:
                                        pieces.append(self.curvature(self.as_by_component[slots[i]]+colors[i],*fidx[i],order[i]))
                                    else:
                                        pieces.append(self.covjet(hom,hi,colors[i],vectors.get(i,-1),order[i])); hi+=1
                                for choice in product(*pieces):
                                    expanded.append((tuple(f for fs,_ in choice for f in fs),coefficient*sp.prod(v for _,v in choice)))
                            result.append(({'kind':'DERIVED_CURVATURE_CONTRACTION','curvature_count':nf,
                                'internal_address':address,'derivative_placement':placement,
                                'ordered_derivatives':order,'Lorentz_contraction':contraction},
                                normalize_words(expanded,group['parity'],contraction)))
        return result

    def primary_candidates(self, group, hom, sources):
        result=[]
        for source in sources:
            if not source['background_slots']: result.extend(self.covariantized(source,hom))
        result.extend(self.curvature_candidates(group,hom))
        return result

    def variation(self, polynomial, hom):
        """Replay: ordinary jet prolongation, not Dbar expansion or primary maps."""
        result={}
        for key,coefficient in polynomial.items():
            factors,parity,contraction=term_factors(key)
            for i,(tag,color,vector,derivatives) in enumerate(factors):
                # Undifferentiated theta cancels by separately qualified H covariance.
                # Every remaining derivative(theta) is retained explicitly.
                if tag=='A':
                    generators=self.adjoint_actions
                    new=list(factors); new[i]=('T',color,-1,derivatives+(vector,))
                    k,phase=canonical_term(tuple(new),parity,contraction)
                    if phase:add(result,k,-coefficient*phase)
                else: generators=self.actions(tuple(self.catalog.by_id[hom[int(tag[1:])][0]]['H_label']))
                for size in range(1,len(derivatives)+1):
                    for selected in combinations(range(len(derivatives)),size):
                        theta_ds=tuple(derivatives[j] for j in selected)
                        remain=tuple(derivatives[j] for j in range(len(derivatives)) if j not in selected)
                        for a,G in enumerate(generators):
                            for j in range(G.cols):
                                v=G[color,j]
                                if v:
                                    new=list(factors); new[i]=(tag,j,vector,remain); new.append(('T',a,-1,theta_ds))
                                    k,phase=canonical_term(tuple(new),parity,contraction)
                                    if phase:add(result,k,coefficient*v*phase)
        return result


def polynomial_matrix(columns):
    keys=sorted(set().union(*(set(c) for c in columns))) if columns else []
    lookup={k:i for i,k in enumerate(keys)}
    return keys,sp.SparseMatrix(len(keys),len(columns),{(lookup[k],j):v for j,c in enumerate(columns) for k,v in c.items()})


def combine(columns, coefficients):
    result={}
    for polynomial,c in zip(columns,coefficients):
        if c:
            for k,v in polynomial.items():add(result,k,c*v)
    return result


def finite_row_space(M):
    """Exact independent equations, streaming reduction; no global dense matrix."""
    pivots={}
    for i in range(M.rows):
        row={j:v for (r,j),v in M[i:i+1,:].todok().items() if v}
        for p,base in sorted(pivots.items()):
            if p in row:
                c=row[p]
                for j,v in base.items():add(row,j,-c*v)
        if row:
            p=min(row); c=row[p]; row={j:norm(v/c) for j,v in row.items()}
            pivots[p]=row
    out=sp.SparseMatrix(len(pivots),M.cols,{(i,j):v for i,(_,row) in enumerate(sorted(pivots.items())) for j,v in row.items()})
    return out


def coordinate_extraction(E, target_columns):
    """Full exact component-polynomial coefficient equality, not sample fitting."""
    keys,M=polynomial_matrix(E)
    _,pivots=M.T.rref(); pivots=list(pivots)
    assert len(pivots)==len(E)
    inverse=M.extract(pivots,range(len(E))).inv()
    co=[]
    for target in target_columns:
        c=inverse*sp.Matrix([target.get(keys[i],0) for i in pivots])
        reconstructed=combine(E,c)
        assert not combine([target,reconstructed],[1,-1]), 'COVARIANT_PARENT_EXPANSION_OUTSIDE_FROZEN_ADDRESS_SPAN'
        co.append(c)
    return sp.Matrix.hstack(*co) if co else sp.zeros(len(E),0)


def block_domain(engine, group, hom, sources):
    E=[engine.source_polynomial(s) for s in sources]
    _,rho=polynomial_matrix(E)
    q,section,N,pivots=quotient(rho)
    # Bind the new local coordinate solve to the immutable qualified null space.
    # No change of canonical internal addresses or realization relation is made.
    frozen=engine.known_nullspace(sources)
    assert frozen.cols==N.cols and rho*frozen==sp.zeros(rho.rows,frozen.cols)
    assert frozen.row_join(N).rank()==N.cols, 'CURRENT_REALIZATION_NULL_SPACE_CHANGED'
    faithful=[E[i] for i in pivots]
    return E,faithful,q,section,N,pivots


def primary_block(engine,group,hom,sources,domain):
    E,faithful,q,section,N,pivots=domain
    candidates=engine.primary_candidates(group,hom,sources)
    parents=[p for p,_ in candidates]; polys=[p for _,p in candidates]
    P=coordinate_extraction(faithful,polys)
    _,independent=P.rref()
    return {'homogeneous_components':hom,'sources':sources,'ordered_dimension':len(E),
        'realization_rank':q.rows,'realization_nullity':N.cols,'quotient_map':serial(q),
        'section':serial(section),'canonical_pivots':pivots,'realization_null_basis':serial(N),
        'RAW_PRIMARY_PARENT_COUNT':len(parents),'PRIMARY_REALIZED_PACKET_RANK':len(independent),
        'parent_expressions':parents,'parent_faithful_coordinates':serial(P),
        'parent_ordered_expansion_representatives':serial(section*P),
        'ordered_expansion_orientation':'Canonical section of the immutable faithful realization; alternatives differ only by qualified realization-null identities',
        'g10_power_of_expansion_rows':[len(s['background_slots']) for s in sources],
        'canonical_parent_indices':list(independent),'canonical_packet_basis':serial(P[:,list(independent)]),
        'source_polynomial_hashes':[poly_hash(p) for p in E],
        'parent_polynomial_hashes':[poly_hash(p) for p in polys],
        'coefficient_derivation':'Full ordinary component polynomial expansion of manifest covariant grammar; exact coordinate extraction before replay',
        'primary_replay_coefficients_imported':False}


def replay_block(engine,group,hom,sources,domain):
    E,faithful,q,section,N,pivots=domain
    polynomials=[engine.variation(p,hom) for p in E]
    keys,V=polynomial_matrix(polynomials)
    assert V*N==sp.zeros(V.rows,N.cols), 'AFFINE_VARIATION_FAILS_REALIZATION_DESCENT'
    raw=finite_row_space(V)
    induced=finite_row_space(V*section)
    assert V*section*q==V
    K=sp.Matrix.hstack(*induced.nullspace()) if induced.rows<q.rows else sp.zeros(q.rows,0)
    Kraw=sp.Matrix.hstack(*raw.nullspace()) if raw.rows<len(E) else sp.zeros(len(E),0)
    assert (q*Kraw).rank()==K.cols and (q*Kraw).row_join(K).rank()==K.cols
    return {'homogeneous_components':hom,'ordered_dimension':len(E),'faithful_dimension':q.rows,
        'realization_nullity':N.cols,'raw_variation_row_count':V.rows,
        'raw_variation_polynomial_hashes':[poly_hash(p) for p in polynomials],
        'independent_variation_equations':serial(raw),'faithful_variation_equations':serial(induced),
        'raw_kernel_dimension':Kraw.cols,'faithful_kernel':serial(K),'faithful_kernel_dimension':K.cols,
        'quotient_descent':'ZERO_EXACT','q_raw_kernel_equals_induced_kernel':'ZERO_EXACT',
        'primary_packet_coefficients_imported':False,
        'constant_theta_certificate':'All input fusion covectors have qualified exact full-H residual zero; the undifferentiated homogeneous Ward sum vanishes',
        'independence':{'ALGORITHM_INDEPENDENT':True,'CODE_PATH_INDEPENDENT':True,
            'LIBRARY_INDEPENDENT':False,'RUNTIME_INDEPENDENT':False,
            'shared_inputs':'Certified carriers, physical root action, ordinary tensor realization and Lorentz algebra'}}


def compare_blocks(primary,replay):
    P=matrix(primary['canonical_packet_basis']); V=matrix(replay['faithful_variation_equations']); K=matrix(replay['faithful_kernel'])
    covariance=V*P==sp.zeros(V.rows,P.cols)
    combined=P.row_join(K).rank(); equal=combined==P.cols==K.cols
    return {'status':'PASS_EXACT_PRIMARY_REPLAY_MUTUAL_SPAN' if covariance and equal else 'BLOCKED_EXACT_PACKET_DISAGREEMENT',
        'primary_packet_rank':P.cols,'replay_kernel_dimension':K.cols,'combined_rank':combined,
        'primary_covariance_residual':'ZERO_EXACT' if covariance else serial(V*P),
        'mutual_span_residual':'ZERO_EXACT' if equal else 'NONZERO_EXACT',
        'extra_faithful_replay_direction':K.cols>P.cols,'noncovariant_primary':not covariance,
        'primary_and_replay_frozen_before_comparison':True}
