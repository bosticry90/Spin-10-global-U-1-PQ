"""Physical-matrix / ordered-word replay; imports no primary model or output."""
import itertools
import json
from hashlib import sha256
from pathlib import Path
import sympy as s
from nonminimal_bv_free_replay import Words

HERE = Path(__file__).resolve().parent


def load(name): return json.loads((HERE/name).read_text(encoding="utf-8"))
def digest(value): return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
def matrix_record(m): return {"shape": list(m.shape), "entries": [[i, j, str(s.simplify(v))] for (i, j), v in sorted(m.todok().items()) if s.simplify(v) != 0]}


def geometry():
    # Derive all constants from physical matrix commutators, NOT the primary
    # stored upper-index tensor or primary adjoint matrices.
    basis = load("frozen_c3/C3_representation_basis.json")
    pairs = list(itertools.combinations(range(10), 2)); columns = []; physical = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        col = s.zeros(45, 1); m = s.zeros(10)
        for item in row["raw_so10_coordinates"]:
            k, v = item["index"], s.sympify(item["coefficient"])
            i, j = pairs[k]; col[k] = v; m[i, j], m[j, i] = v/s.sqrt(2), -v/s.sqrt(2)
        columns.append(col); physical.append(s.ImmutableSparseMatrix(m))
    split = s.Matrix.hstack(*columns); inverse = split.inv(); f = {}
    for a, b in itertools.combinations(range(45), 2):
        comm = physical[a]*physical[b]-physical[b]*physical[a]
        vector = s.Matrix([comm[i, j]*s.sqrt(2) for i, j in pairs])
        coords = (inverse*vector).applyfunc(s.simplify)
        for k in range(45):
            if coords[k]: f[k, a, b], f[k, b, a] = coords[k], -coords[k]
    H = [s.ImmutableSparseMatrix(12, 12, {(i, j): f[i, a, j] for i in range(12) for j in range(12) if (i, a, j) in f}) for a in range(12)]
    heavy = [s.ImmutableSparseMatrix(33, 33, {(i, j): f[i+12, a, j+12] for i in range(33) for j in range(33) if (i+12, a, j+12) in f}) for a in range(12)]
    # Tensor/index Jacobi equations, rather than primary matrix products, for
    # the H and heavy modules; physical 10 uses the actual matrix commutator.
    for a, b in itertools.combinations(range(12), 2):
        for module, offset in ((H, 0), (heavy, 12)):
            n = module[0].rows
            for i in range(n):
                for j in range(n):
                    residual = sum((f.get((i+offset, a, k+offset), 0)*f.get((k+offset, b, j+offset), 0)-f.get((i+offset, b, k+offset), 0)*f.get((k+offset, a, j+offset), 0) for k in range(n)))
                    residual -= sum((f.get((k, a, b), 0)*f.get((i+offset, k, j+offset), 0) for k in range(12)))
                    assert s.simplify(residual) == 0
        expected = sum((f.get((k, a, b), 0)*physical[k] for k in range(12)), s.zeros(10))
        assert (physical[a]*physical[b]-physical[b]*physical[a]-expected).applyfunc(s.simplify) == s.zeros(10)
    gram = s.ImmutableSparseMatrix((split.T*split)[:12, :12])
    assert gram.det() != 0 and gram != s.eye(12)
    for m in H: assert (m.T*gram+gram*m).applyfunc(s.simplify) == s.zeros(12)
    wrong_pairing = -H[0].T-H[0]
    assert wrong_pairing != s.zeros(12)
    # Independent antisymmetric bilinear tensor covariance calculation.
    K = [s.ImmutableSparseMatrix(33, 33, {(i, j): -f.get((h, i+12, j+12), 0) for i in range(33) for j in range(33) if f.get((h, i+12, j+12), 0)}) for h in range(12)]
    for a in range(12):
        for h in range(12):
            actual = -heavy[a].T*K[h]-K[h]*heavy[a]
            expected = sum((-H[a][h, k]*K[k] for k in range(12)), s.zeros(33))
            assert (actual-expected).applyfunc(s.simplify) == s.zeros(33)
    R = []
    for m in K:
        records = []
        for i in range(33):
            for j in range(i+1, 33):
                if m[i, j]:
                    word = ["u"+str(i), "u"+str(j)]
                    sign = -1 if word[0] > word[1] else 1
                    records.append({"word": sorted(word), "coefficient": str(s.simplify(sign*m[i, j]))})
        R.append(sorted(records, key=lambda r: r["word"]))
    non = next((i, a, b, v) for (i, a, b), v in sorted(f.items()) if i >= 12 and 12 <= a < b and v != 0)
    return f, H, {"H_dimension": 12, "heavy_dimension": 33, "generator_pairs": 66,
        "module_hashes": {"H": digest([matrix_record(m) for m in H]), "heavy": digest([matrix_record(m) for m in heavy]), "physical_10": digest([matrix_record(m) for m in physical[:12]])},
        "H_gram": matrix_record(gram), "H_gram_nondegenerate_nonidentity": True, "metric_intertwiner_checks": 12,
        "wrong_primal_source_pairing_matrix": matrix_record(wrong_pairing),
        "R": R, "R_covariance_equations": 144, "non_symmetric_coset_witness": [*non[:3], str(s.simplify(non[3]))], "normalized_f_4_0_4": str(f[4, 0, 4]),
        "physical_parent_commutators_reconstructed": 990, "scalar_328_reconstructed": False}


class LocalWords(Words):
    def act(self, poly, images, parity=0):
        out = {}
        for word, c in poly.items():
            for pos, (name, indices) in enumerate(word):
                sign = (-1)**(parity*sum(self.p[n] for n, _ in word[:pos]))
                out = self.add(out, self.scale(self.mul({word[:pos]: c}, self.dword(images.get(name, {}), indices), {word[pos+1:]: 1}), sign))
        return out


def light_block(f, H):
    w = LocalWords(); g = s.Symbol("g10")
    par = {"c": 1, "Jc": 0, "bar": 1, "b": 0, "Jbar": 0, "Jb": 1}
    w.p = {prefix+str(i): p for prefix, p in par.items() for i in range(12)}
    w.p.update({"omega"+str(i): 0 for i in range(12)})
    w.pairs = [(prefix+str(i), source+str(i)) for prefix, source in (("c", "Jc"), ("bar", "Jbar"), ("b", "Jb")) for i in range(12)]
    x = {n: w.var(n) for n in w.p}; base = [n for n in w.p if not n.startswith("omega")]
    qc = {"c"+str(i): w.add(*(w.scale(w.mul(x["c"+str(j)], x["c"+str(k)]), -g*f.get((i, j, k), 0)) for j in range(12) for k in range(j+1, 12))) for i in range(12)}
    S = w.add(*(w.mul(x["Jc"+str(i)], qc["c"+str(i)]) for i in range(12)), *(w.scale(w.mul(x["Jbar"+str(i)], x["b"+str(i)]), -1) for i in range(12)))
    G = w.add(*(w.mul(x["Jc"+str(i)], x["omega"+str(i)]) for i in range(12)), *(w.scale(w.mul(x["Jb"+str(i)], x["omega"+str(h)], x["bar"+str(j)]), g*v) for h in range(12) for (i, j), v in H[h].todok().items()))
    Q = {n: w.EL(S, other) for pair in w.pairs for n, other in (pair, pair[::-1])}
    I = {n: w.EL(G, other) for pair in w.pairs for n, other in (pair, pair[::-1])}
    T = {}
    for prefix in par:
        matrices = [m.T if prefix.startswith("J") else -m for m in H]
        for i in range(12): T[prefix+str(i)] = w.add(*(w.scale(w.mul(x["omega"+str(h)], x[prefix+str(j)]), g*v) for h in range(12) for (row, j), v in matrices[h].todok().items() if row == i))
    for n in base:
        assert not w.add(w.Q(Q[n], I), w.Q(I[n], Q), w.scale(T[n], -1)), n
        assert not w.Q(I[n], I)
        assert not w.Q(Q[n], Q)
        assert not w.add(w.act(Q[n], T), w.scale(w.Q(T[n], Q), -1))
    w.p.update({"nu"+str(i): 0 for i in range(12)})
    Inu = {n: w.replace(p, {"omega"+str(i): w.var("nu"+str(i)) for i in range(12)}) for n, p in I.items()}
    eta = {"omega"+str(i): w.add(*(w.scale(w.mul(w.var("omega"+str(h)), w.var("nu"+str(k))), g*f.get((i, h, k), 0)) for h in range(12) for k in range(12))) for i in range(12)}
    Ieta = {n: w.replace(p, eta) for n, p in I.items()}
    for n in base:
        assert not w.add(w.act(Inu[n], T), w.scale(w.Q(T[n], Inu), -1), w.scale(Ieta[n], -1))
    assert not w.add(*(w.mul(w.EL(S, z), Q[z]) for z, _ in w.pairs))
    return {"base_components": 72, "canonical_pairs": 36, "Cartan_checks": 72, "contraction_square_checks": 72, "Q_square_checks": 72,
        "local_L_iota_checks": 72, "TQ_checks": 72,
        "scope": "ungauge_fixed_H_ghost_and_light_nonminimal_block_not_full_M08_master",
        "contraction_images": {n: w.record(p) for n, p in I.items()}, "local_action_hash": digest({n: w.record(p) for n, p in T.items()}),
        "canonical_contraction_Hamiltonian": w.record(G), "master_zero": True}


def fixed_source_control():
    w = LocalWords(); base = list(w.p); w.p["omega"] = 0; x = {n: w.var(n) for n in w.p}; xi = s.Symbol("xi")
    metric = [1, -1, -1, -1]
    box = lambda P: w.add(*(w.scale(w.D(w.D(P, m), m), metric[m]) for m in range(4)))
    div = w.add(*(w.scale(w.D(x[f"V{m}"], m), metric[m]) for m in range(4)))
    kinetic = {}
    for m in range(4):
        for n in range(m+1, 4):
            F = w.add(w.D(x[f"V{n}"], m), w.scale(w.D(x[f"V{m}"], n), -1))
            kinetic = w.add(kinetic, w.scale(w.mul(F, F), -s.Rational(1, 2)*metric[m]*metric[n]))
    Smin = w.add(kinetic, *(w.mul(x[f"KV{m}"], w.D(x["u"], m)) for m in range(4)), w.scale(w.mul(x["Kbar"], x["Lambda"]), -1))
    Qmin = {n: w.EL(Smin, other) for pair in w.pairs for n, other in (pair, pair[::-1])}
    psi = w.mul(x["bar"], w.add(div, w.scale(x["Lambda"], -xi/2)))
    Sfixed = w.add(Smin, w.Q(psi, Qmin))
    Q = {n: w.EL(Sfixed, other) for pair in w.pairs for n, other in (pair, pair[::-1])}
    shifts = {source: w.scale(w.EL(psi, z), -(-1)**w.p[z]) for z, source in w.pairs}
    positive = {n: w.add(x[n], shifts.get(n, {})) for n in base}
    negative = {n: w.add(x[n], w.scale(shifts.get(n, {}), -1)) for n in base}
    U = lambda P: w.replace(P, positive); inv = lambda P: w.replace(P, negative)
    Traw = {f"V{m}": w.D(x["omega"], m) for m in range(4)}; Iraw = {"u": x["omega"]}
    T = {n: U(w.act(inv(x[n]), Traw)) for n in base}; I = {n: U(w.Q(inv(x[n]), Iraw)) for n in base}
    # Derive transported Hamiltonian columns independently by right/left
    # formal variation; this odd generator has different source signs.
    Graw = w.add(*(w.scale(w.mul(x[f"KV{m}"], w.D(x["omega"], m)), -1) for m in range(4)))
    GT = U(Graw)
    canonical_T = {}
    for z, J in w.pairs:
        canonical_T[z] = w.scale(w.EL(GT, J), -(-1)**w.p[z])
        canonical_T[J] = w.scale(w.EL(GT, z), (-1)**w.p[z])
    for n in base:
        assert canonical_T[n] == T[n]
        assert not w.add(w.Q(Q[n], I), w.Q(I[n], Q), w.scale(T[n], -1)), n
        assert not w.add(w.act(Q[n], T), w.scale(w.Q(T[n], Q), -1)), n
        assert not w.Q(Q[n], Q)
        assert inv(U(x[n])) == x[n]
        assert w.Q(U(x[n]), Q) == U(Qmin[n])
        for mu in range(4):
            assert w.act(w.D(x[n], mu), T) == w.D(T[n], mu)
            assert w.Q(w.D(x[n], mu), I) == w.D(I[n], mu)
    defect = w.add(w.Q(Q["Kbar"], I), w.Q(I["Kbar"], Q), w.scale(Traw.get("Kbar", {}), -1))
    assert defect == T["Kbar"] == w.scale(box(x["omega"]), -1) and defect
    return {"base_generators": 14, "Cartan_checks": 14, "TQ_checks": 14, "ordinary_prolongation_checks": 112,
        "transported_T": {n: w.record(p) for n, p in T.items()}, "transported_iota": {n: w.record(p) for n, p in I.items()},
        "shifts": {n: w.record(shifts.get(n, {})) for n in base}, "Q_fixed_hash": digest({n: w.record(p) for n, p in Q.items()}),
        "raw_source_action_defect": w.record(defect), "light_fermion_raw_quantum_variation": w.record(w.act(psi, Traw)),
        "nonzero_transported_Kbar": w.record(T["Kbar"]), "canonical_T_generator_transported": True,
        "inverse_and_Q_intertwining": True, "no_EOM": True, "full_M08_gauge_fixing_transport": False}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    stage = stage or (lambda n, f: f())
    f, H, geom = stage("replay_physical_commutators_and_tensor_covariance", geometry)
    return {"schema": "NONABELIAN_M08_SEMANTIC_REPLAY_V1", "geometry": geom,
        "light_block": stage("replay_word_nonminimal_block", lambda: light_block(f, H)),
        "fixed_source_control": stage("replay_canonical_gauge_fixed_sources", fixed_source_control),
        "independence": {"ALGORITHM_INDEPENDENT": True, "CODE_PATH_INDEPENDENT": True, "LIBRARY_INDEPENDENT": False, "RUNTIME_INDEPENDENT": False,
            "primary_model_or_output_imported": False, "external_specialist_review": False, "analyst_blind": False,
            "shared": "C3 split and declared mathematical conventions, Python, SymPy, prior qualified ordered-word engine"}}


if __name__ == "__main__": print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
