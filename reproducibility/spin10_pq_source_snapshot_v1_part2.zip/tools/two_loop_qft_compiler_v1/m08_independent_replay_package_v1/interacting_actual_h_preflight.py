"""Inactive four-dimensional actual-H gauge/source preflight; stdout only."""
import itertools
import json
import time
from collections import OrderedDict
import sympy as s
from source_domain_transport import DomainJets, source_bridge, g, xi
from source_convention_control import Exterior
from nonminimal_bv_free import ETA


class FailedIdentity(Exception):
    def __init__(self,label,residual,engine):
        self.evidence={'identity':label,'residual':engine.record(residual),'first_component':engine.record(residual)[0]}


class BatchedExterior(Exterior):
    """Same exact exterior arithmetic; normalize once per derivation sum.

    The historical engine is unchanged. Tests compare this accumulator with it.
    """
    def derive(self,poly,images,parity=1):
        terms=[]
        for name,image in images.items():
            if image and not self.parity[name]:
                terms.append(self.mul(image,self.partial(poly,name)))
        for word,coefficient in poly.items():
            for pos,name in enumerate(word):
                if image:=images.get(name):
                    terms.append(self.mul({word[:pos]:coefficient*(-1)**(parity*pos)},image,{word[pos+1:]:s.Integer(1)}))
        return self.add(*terms)


class GaugeJets(DomainJets):
    def __init__(self,n):
        self.a,self.meta,self.values=BatchedExterior(),{},{}
        self.limit,self.max_order,self.n=6,0,n
        self.fields={**{f'q{i}_{mu}':(1,0,0) for mu in range(4) for i in range(n)},
            **{f'{prefix}{i}':grade for prefix,grade in [('c',(1,1,1)),('bar',(1,-1,1)),('b',(2,0,0))] for i in range(n)}}
        self.pairs=[(z,'J'+z) for z in self.fields]
        self.grades={**self.fields,**{J:(3-self.fields[z][0],-1-self.fields[z][1],1-self.fields[z][2]) for z,J in self.pairs}}
        self.external={**{f'A{i}_{mu}':(1,0,0) for mu in range(4) for i in range(n)},**{f'{prefix}{i}':(0,0,0) for prefix in ('omega','beta') for i in range(n)}}
        self._cache={}; self._Euler_cache=OrderedDict()
        for name in self.grades|self.external: self.var(name)

    def act(self,P,images,parity=0):
        key=id(images)
        if key not in self._cache: self._cache[key]=(images,{})
        owner,cache=self._cache[key]; assert owner is images
        names=self.support(P)
        for name in names:
            if name not in cache:
                base,jets=self.meta[name]; cache[name]=self.multiD(images.get(base,{}),jets)
        return self.a.derive(P,{name:cache[name] for name in names},parity=parity)

    def euler(self,P,base,side='left'):
        # Keep the input alive with its result: an id cannot alias a freed input.
        # Bounded LRU storage, no symbolic approximation or changed derivative.
        key=(id(P),base,side)
        if key in self._Euler_cache:
            owner,result=self._Euler_cache[key]; assert owner is P
            self._Euler_cache.move_to_end(key); return result
        result=super().euler(P,base,side)
        self._Euler_cache[key]=(P,result)
        if len(self._Euler_cache)>256: self._Euler_cache.popitem(last=False)
        return result

    def transport(self,P,shifts,sign=1):
        a=self.a; names=self.support(P); terms=[]
        images={name:a.add(self.values[name],a.scale(self.multiD(shifts.get(self.meta[name][0],{}),self.meta[name][1]),sign)) for name in names}
        even=[a.even_symbols[name] for name in names if not a.parity[name]]
        for word,coefficient in P.items():
            monomials=s.Poly(coefficient,*even).terms() if even else [((),coefficient)]
            for powers,scalar in monomials:
                term={():scalar}
                for variable,power in zip(even,powers):
                    for _ in range(power): term=a.mul(term,images[str(variable)])
                terms.append(a.mul(term,*(images[name] for name in word)))
        return a.add(*terms)

    def current4(self,P):
        a=self.a; pieces={}
        for row in self.record(P):
            degree=len(row['word']); assert degree
            term={():s.sympify(row['coefficient'])}
            for name in row['word']: term=a.mul(term,self.values[name])
            pieces.setdefault(degree,[]).append(term)
        current_terms=[[] for _ in range(4)]
        for degree,terms in pieces.items():
            part=a.add(*terms)
            for base in self.grades|self.external:
                zero(self.euler(part,base),'master_Euler_'+base,self)
            for name in self.support(part):
                base,jets=self.meta[name]; coefficient=a.partial(part,name)
                for pos,mu in enumerate(jets):
                    term=a.mul(self.var(base,jets[pos+1:]),self.multiD(coefficient,jets[:pos]))
                    current_terms[mu].append(a.scale(term,s.Rational((-1)**pos,degree)))
        currents=[a.add(*terms) for terms in current_terms]
        zero(a.add(self.div(currents),a.scale(P,-1)),'explicit_divergence',self)
        return currents


def zero(P,label,j):
    if P: raise FailedIdentity(label,P,j)


def model(f,ids,G,stage):
    n=len(ids); j=GaugeJets(n); a=j.a; x={name:j.var(name) for name in j.grades|j.external}
    vec=lambda prefix:[x[prefix+str(i)] for i in range(n)]
    conn=lambda prefix,mu:[x[f'{prefix}{i}_{mu}'] for i in range(n)]
    plus=lambda v,w:[a.add(z,y) for z,y in zip(v,w)]
    scale=lambda v,k:[a.scale(z,k) for z in v]
    comm=lambda v,w:[a.add(*(a.scale(a.mul(v[b],w[c]),f[(ids[i],ids[b],ids[c])]) for b,c in itertools.product(range(n),repeat=2) if (ids[i],ids[b],ids[c]) in f)) for i in range(n)]
    dot=lambda v,w:a.add(*(a.mul(z,y) for z,y in zip(v,w)))
    paired=lambda v,w:a.add(*(a.scale(a.mul(v[i],w[k]),G[i,k]) for i,k in itertools.product(range(n),repeat=2) if G[i,k]))
    A=[conn('A',mu) for mu in range(4)]; q=[conn('q',mu) for mu in range(4)]; B=[plus(v,w) for v,w in zip(A,q)]
    c,bar,b,omega,beta=[vec(p) for p in ('c','bar','b','omega','beta')]
    curvature={(mu,nu):plus(plus([j.D(z,mu) for z in B[nu]],scale([j.D(z,nu) for z in B[mu]],-1)),scale(comm(B[mu],B[nu]),g)) for mu in range(4) for nu in range(4)}
    S0=a.add(*(a.scale(paired(F,F),-s.Rational(1,4)*ETA[mu]*ETA[nu]) for (mu,nu),F in curvature.items()))
    forward={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(plus([j.D(z,mu) for z in c],scale(comm(B[mu],c),g)))}
    for prefix,images in [('c',scale(comm(c,c),-g/2)),('bar',scale(b,-1)),('b',[{} for _ in b])]: forward.update({prefix+str(i):P for i,P in enumerate(images)})
    source=a.add(*(a.mul(x[J],forward[z]) for z,J in j.pairs)); Smin=a.add(S0,source)
    condition=[a.add(*(a.scale(a.add(j.D(q[mu][i],mu),a.scale(comm(A[mu],q[mu])[i],g)),ETA[mu]) for mu in range(4))) for i in range(n)]
    psi=paired(bar,plus(condition,scale(b,-xi/2)))
    assert j.grade(Smin,(4,0,0)) and j.grade(psi,(3,-1,1))
    # The deliberately mixed old free organization has no antighost source,
    # but retains Qbar=-b as an external rule. This is not a BV subcomplex.
    def free_control():
        Sfree=a.add(*(a.mul(x[J],{word:s.expand(coef.subs(g,0)) for word,coef in forward[z].items() if coef.subs(g,0)}) for z,J in j.pairs))
        free=j.columns(Sfree); psifree={word:s.expand(coef.subs(g,0)) for word,coef in psi.items() if coef.subs(g,0)}
        fixed=a.add(Sfree,j.Q(psifree,free)); images=j.columns(fixed)
        bad=dict(images)
        for i in range(n): bad['Jb'+str(i)]=a.add(images['Jb'+str(i)],x['Jbar'+str(i)]); bad['Jbar'+str(i)]={}
        witnesses={}
        for i in range(n):
            actual=j.Q(bad['Jb'+str(i)],bad)
            expected=a.add(*(a.scale(j.box(c[k]),-G[i,k]) for k in range(n) if G[i,k]))
            zero(a.add(actual,a.scale(expected,-1)),'free_omitted_partner_'+str(i),j)
            assert actual; witnesses['Jb'+str(i)]=j.record(actual)
            zero(j.Q(images['Jb'+str(i)],images),'free_complete_partner_'+str(i),j)
        return witnesses
    negative=stage('free_missing_partner_regression',free_control)
    Q=stage('interacting_minimal_Euler_columns',lambda:j.columns(Smin))
    Igen=a.add(dot(vec('Jc'),omega),dot(vec('Jb'),scale(comm(omega,bar),g)))
    I={name:j.bracket(Igen,x[name]) for name in j.grades}
    def local(parameter,background=False):
        fields={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(scale(comm(q[mu],parameter),g))}
        if not background:
            fields={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(plus([j.D(z,mu) for z in parameter],scale(comm(B[mu],parameter),g)))}
        for prefix in ('c','bar','b'): fields.update({prefix+str(i):P for i,P in enumerate(scale(comm(vec(prefix),parameter),g))})
        generator=a.add(*(a.scale(a.mul(x[J],fields[z]),-(-1)**j.grades[z][2]) for z,J in j.pairs))
        out={name:j.bracket(generator,x[name]) for name in j.grades}
        if background: out.update({f'A{i}_{mu}':P for mu in range(4) for i,P in enumerate(plus([j.D(z,mu) for z in parameter],scale(comm(A[mu],parameter),g)))})
        return out,generator
    Tq,Tgen=stage('quantum_Hamiltonian_source_lift',lambda:local(omega))
    Tb,_=stage('background_Hamiltonian_source_lift',lambda:local(beta,True))
    Tqb,_=local(beta); Tbo,_=local(omega,True); pb=scale(comm(beta,omega),g)
    Tqbr,_=local(pb); Tbbr,_=local(pb,True)
    Ibrgen=a.add(dot(vec('Jc'),pb),dot(vec('Jb'),scale(comm(pb,bar),g)))
    Ibr={name:j.bracket(Ibrgen,x[name]) for name in j.grades}
    def pre_checks():
        for name in j.grades:
            zero(j.Q(Q[name],Q),'pre_Q_square_'+name,j)
            zero(a.add(j.Q(Q[name],I),j.Q(I[name],Q),a.scale(Tq[name],-1)),'pre_Cartan_'+name,j)
            zero(j.Q(I[name],I),'pre_iota_square_'+name,j)
            for tag,T in [('quantum',Tq),('background',Tb)]:
                zero(a.add(j.act(Q[name],T),a.scale(j.Q(T[name],Q),-1)),'pre_'+tag+'_Q_'+name,j)
            for first,second,expected in [(Tqb,Tq,Tqbr),(Tb,Tbo,Tbbr),(Tb,Tq,Tqbr)]:
                zero(a.add(j.act(second[name],first),a.scale(j.act(first[name],second),-1),a.scale(expected[name],-1)),'local_Lie_'+name,j)
            for T in (Tqb,Tb): zero(a.add(j.act(I[name],T),a.scale(j.Q(T[name],I),-1),a.scale(Ibr[name],-1)),'iota_covariance_'+name,j)
        for z in j.fields: zero(a.add(Q[z],a.scale(forward[z],-1)),'derived_forward_'+z,j)
        for mu,nu in itertools.combinations(range(4),2):
            for i,P in enumerate(curvature[mu,nu]): zero(a.add(j.Q(P,Q),a.scale(comm(curvature[mu,nu],c)[i],-g)),'curvature_Q_'+str((mu,nu,i)),j)
        zero(j.Q(S0,Q),'kinetic_Q_invariance',j)
        zero(j.act(S0,Tq),'kinetic_quantum_Ward',j); zero(j.act(S0,Tb),'kinetic_background_Ward',j)
        zero(j.act(psi,Tb),'fermion_background_Ward',j)
        for name in j.external:
            if name.startswith('A'):
                zero(a.add(j.act(Tbo[name],Tb),a.scale(j.act(Tb[name],Tbo),-1),a.scale(Tbbr[name],-1)),'background_connection_Lie_'+name,j)
        return True
    stage('pre_generator_identities_and_interacting_Ward',pre_checks)
    def master(action):
        P=a.scale(j.bracket(action,action),s.Rational(1,2)); currents=j.current4(P)
        return {'half_density':j.record(P),'currents':[j.record(v) for v in currents],'Euler_zero':True,'divergence_reconstructed':True}
    minimal_master=stage('minimal_master_divergence',lambda:master(Smin))
    shifts={name:a.scale(j.bracket(psi,x[name]),-1) for name in j.grades}
    U=lambda P:j.transport(P,shifts); inv=lambda P:j.transport(P,shifts,-1)
    fixed=U(Smin); Qfixed=stage('fixed_Euler_columns',lambda:j.columns(fixed))
    transported=lambda images,parity:{name:U(j.act(inv(x[name]),images,parity)) for name in j.grades}
    Tfixed=stage('transport_quantum_sources',lambda:transported(Tq,0)); Ifixed=stage('transport_iota',lambda:transported(I,1))
    Bfixed=stage('transport_background',lambda:{**{name:U(Tb[name]) for name in j.external if name.startswith('A')},**transported(Tb,0)})
    def fixed_checks():
        for name in j.grades:
            assert j.grade(shifts[name],j.grades[name])
            zero(a.add(inv(U(x[name])),a.scale(x[name],-1)),'inverse_'+name,j)
            zero(a.add(j.Q(U(x[name]),Qfixed),a.scale(U(Q[name]),-1)),'Q_intertwiner_'+name,j)
            zero(j.Q(Qfixed[name],Qfixed),'fixed_Q_square_'+name,j)
            zero(a.add(j.Q(Qfixed[name],Ifixed),j.Q(Ifixed[name],Qfixed),a.scale(Tfixed[name],-1)),'fixed_Cartan_'+name,j)
            zero(a.add(Bfixed[name],a.scale(Tb[name],-1)),'background_commutes_U_'+name,j)
            for T in (Tfixed,Bfixed): zero(a.add(j.act(Qfixed[name],T),a.scale(j.Q(T[name],Qfixed),-1)),'fixed_TQ_'+name,j)
            zero(a.add(j.bracket(U(Tgen),x[name]),a.scale(Tfixed[name],-1)),'fixed_quantum_Hamiltonian_'+name,j)
            zero(a.add(j.bracket(U(Igen),x[name]),a.scale(Ifixed[name],-1)),'fixed_iota_Hamiltonian_'+name,j)
            for mu in range(4):
                jet=j.D(x[name],mu)
                zero(j.Q(j.Q(jet,Qfixed),Qfixed),'fixed_first_jet_square_'+str((name,mu)),j)
                for tag,images,parity in [('Q',Qfixed,1),('I',Ifixed,1),('Tq',Tfixed,0),('Tb',Bfixed,0)]:
                    zero(a.add(j.act(jet,images,parity),a.scale(j.D(images[name],mu),-1)),'first_jet_prolongation_'+str((tag,name,mu)),j)
        for z,J in j.pairs: zero(a.add(j.bracket(U(x[z]),a.scale(U(x[J]),(-1)**j.grades[z][2])),{():s.Integer(-1)}),'canonical_diagonal_'+z,j)
        for (_,J),(_,K) in itertools.combinations_with_replacement(j.pairs,2): zero(j.bracket(U(x[J]),U(x[K])),'canonical_cross_'+J+'_'+K,j)
        for name in j.external:
            if name.startswith('A'):
                zero(a.add(Bfixed[name],a.scale(Tb[name],-1)),'external_background_transport_'+name,j)
                for mu in range(4): zero(a.add(j.act(j.D(x[name],mu),Bfixed),a.scale(j.D(Bfixed[name],mu),-1)),'external_background_first_jet_'+str((name,mu)),j)
        difference=a.add(fixed,a.scale(Smin,-1),a.scale(j.Q(psi,Q),-1))
        currents=j.current4(difference)
        return [j.record(v) for v in currents]
    density_current=stage('canonical_transport_fixed_identities_and_jets',fixed_checks)
    fixed_master=stage('fixed_master_divergence',lambda:master(fixed))
    F=dot(vec('Jb'),curvature[0,1]); image=j.Q(F,Q); FF=U(F); fixedimage=j.Q(FF,Qfixed)
    def domain():
        assert image and fixedimage and j.grade(F,(3,-1,1))
        zero(a.add(fixedimage,a.scale(U(image),-1)),'domain_Q_intertwiner',j)
        for P in (F,image):
            for tag,T,parity in [('Tq',Tq,0),('I',I,1),('Tb',Tb,0)]: zero(j.act(P,T,parity),'pre_domain_'+tag,j)
        for P in (FF,fixedimage):
            for tag,T,parity in [('Tq',Tfixed,0),('I',Ifixed,1),('Tb',Bfixed,0)]: zero(j.act(P,T,parity),'fixed_domain_'+tag,j)
        defect=j.act(fixedimage,Tq); assert defect
        selected=next((name,j.euler(defect,name)) for name in j.grades|j.external if j.euler(defect,name))
        return {'raw_quantum_defect':j.record(defect),'Euler_variable':selected[0],'Euler_residual':j.record(selected[1])}
    wrong=stage('nonzero_source_domain_and_raw_source_negative',domain)
    return {'status':'PASS_BOUNDED_INTERACTING_ACTUAL_H_CONTROL','ids':ids,'pairs':28,'generators':56,'spacetime_directions':4,
        'actions':{'kinetic':j.record(S0),'minimal':j.record(Smin),'fermion':j.record(psi),'fixed':j.record(fixed)},
        'images':{tag:{name:j.record(P) for name,P in table.items()} for tag,table in [('Q_min',Q),('Q_fixed',Qfixed),('Tq_min',Tq),('Tb_min',Tb),('iota_min',I),('Tq_fixed',Tfixed),('Tb_fixed',Bfixed),('iota_fixed',Ifixed)]},
        'shifts':{name:j.record(P) for name,P in shifts.items()},'master':{'minimal':minimal_master,'fixed':fixed_master},'fixed_density_current':density_current,
        'domain':{'F':j.record(F),'QF':j.record(image),'UF':j.record(FF),'Qfixed_UF':j.record(fixedimage),'nonzero_images':True,'structural_preservation':True,'counterterm_completeness':False},
        'negative_controls':{'free_missing_partner':negative,'wrong_raw_source':wrong},
        'counts':{'minimal_squares':56,'fixed_squares':56,'fixed_first_jet_squares':224,'canonical_diagonal':28,'source_cross_pairs':406,'first_jet_prolongation':896,'external_background_first_jets':64},
        'maximum_jet_order':j.max_order,'jet_truncation':False,'EOM_used':False}


def build(stage=None):
    if not __debug__: raise RuntimeError('ASSERTIONS_REQUIRED')
    stage=stage or (lambda name,fn:fn())
    f,ids,G,_=stage('actual_H_bound_geometry',source_bridge)
    try: result=model(f,ids,G,stage)
    except FailedIdentity as failure: result={'status':'FAILED_FIRST_PREREQUISITE','witness':failure.evidence}
    return {'schema':'INTERACTING_ACTUAL_H_PREFLIGHT_V1','result':result,'full_M08_qualified':False,'active_sources_added':False,'phase_C_authorized':False,'HB1_C5_authorized':False,'formal_authority':'34/39_UNCHANGED','finite_C1_GS':None,'external_specialist_review':False}


if __name__=='__main__': print(json.dumps(build(),sort_keys=True,separators=(',',':')))
