"""Physical-matrix and ordered-word replay; no primary model/output import."""
import itertools
import json
import sympy as s
from nonabelian_m08_semantic_replay import geometry, load, matrix_record
from nonminimal_bv_free_replay import Words

g, xi = s.symbols("g10 eta_H")


def coordinate_bridge():
    f, H, previous = geometry()
    basis = load("frozen_c3/C3_representation_basis.json")
    columns = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        columns.append(s.Matrix([sum(s.sympify(r["coefficient"]) for r in row["raw_so10_coordinates"] if r["index"] == i) for i in range(45)]))
    frame = s.Matrix.hstack(*columns)
    G = (frame.T*frame)[:12, :12]; inverse = G.inv()
    C = (frame.inv()*frame.conjugate())[:12, :12].applyfunc(s.simplify); dual = C.inv().T
    assert inverse*G == s.eye(12)
    assert (C*C.conjugate()).applyfunc(s.simplify) == s.eye(12)
    assert (C.T*G*C-G.conjugate()).applyfunc(s.simplify) == s.zeros(12)
    assert (G*C-dual*G.conjugate()).applyfunc(s.simplify) == s.zeros(12)
    for m in H: assert (m.T*G+G*m).applyfunc(s.simplify) == s.zeros(12)
    selected = {0, 4}; history = []
    while True:
        new = selected | {i for i in range(12) if any(f.get((i, a, b), 0) for a in selected for b in selected)} | {j for j in range(12) if any(G[i, j] for i in selected)}
        history.append(sorted(new))
        if new == selected: break
        selected = new
    ids = sorted(selected); K = G.extract(ids, ids)
    assert K.det() and ids == [0, 1, 4, 11]
    bridge = {"H_gram": matrix_record(G), "inverse": matrix_record(inverse), "conjugation": matrix_record(C), "evaluation_dual_conjugation": matrix_record(dual),
        "inverse_pairing_equivariance_and_reality": True, "induced_carrier_bracket": matrix_record(inverse.T), "wrong_delta_bracket_residual": matrix_record(inverse-s.eye(12)),
        "coordinate_map": "J=G_H k; canonical z_star=(-1)^p J; k alone is not a canonical source with delta bracket",
        "legacy_catalog_decoder_bound": False, "selection_seed": [0, 4], "selection_iterations": history, "selected_H_indices": ids, "selected_gram": matrix_record(K)}
    return f, ids, K, bridge


class DomainWords(Words):
    def __init__(self, n):
        types = {"q": (1, 0, 0), "c": (1, 1, 1), "bar": (1, -1, 1), "b": (2, 0, 0), "p": (1, 0, 0)}
        self.fields = {prefix+str(i): grade for prefix, grade in types.items() for i in range(n)}
        self.pairs = [(z, "J"+z) for z in self.fields]
        self.grades = {**self.fields, **{J: (3-self.fields[z][0], -1-self.fields[z][1], 1-self.fields[z][2]) for z, J in self.pairs}}
        self.external = {prefix+str(i): (1 if prefix == "A" else 0, 0, 0) for prefix in ("A", "omega", "beta") for i in range(n)}
        self.p = {z: grade[2] for z, grade in (self.grades | self.external).items()}; self.max_jet = 0

    def act(self, poly, images, parity=0):
        out = {}
        for word, coefficient in poly.items():
            for pos, (name, jets) in enumerate(word):
                sign = (-1)**(parity*sum(self.p[n] for n, _ in word[:pos]))
                out = self.add(out, self.scale(self.mul({word[:pos]: coefficient}, self.dword(images.get(name, {}), jets), {word[pos+1:]: 1}), sign))
        return out

    def bracket(self, F, G):
        out = {}
        parities = {sum(self.p[n] for n, _ in word) % 2 for word in F}
        assert len(parities) <= 1
        parity = next(iter(parities), 0)
        for z, J in self.pairs:
            # Right-to-left variation is derived separately for each parity.
            rz = self.scale(self.EL(F, z), s.Integer(-1)**(self.p[z]*(parity-self.p[z])))
            rj = self.scale(self.EL(F, J), s.Integer(-1)**(self.p[J]*(parity-self.p[J])))
            out = self.add(out, self.scale(self.add(self.mul(rz, self.EL(G, J)), self.scale(self.mul(rj, self.EL(G, z)), -1)), (-1)**self.p[z]))
        return out

    def columns(self, S): return {name: self.EL(S, other) for pair in self.pairs for name, other in (pair, pair[::-1])}

    @staticmethod
    def record(P):
        assert all(not c.has(s.Float) for c in P.values()), "EXACT_COEFFICIENTS_REQUIRED"
        return [{"word": [n+("__"+"".join(map(str, jets)) if jets else "") for n, jets in word], "coefficient": str(s.simplify(c))} for word, c in sorted(P.items())]

    def partial_jet(self, P, variable):
        out = {}
        for word, c in P.items():
            for pos, v in enumerate(word):
                if v == variable:
                    sign = (-1)**(self.p[v[0]]*sum(self.p[n] for n, _ in word[:pos]))
                    out = self.add(out, {word[:pos]+word[pos+1:]: sign*c})
        return out

    def current(self, P):
        parts = {}
        for word, c in P.items(): parts[len(word)] = self.add(parts.get(len(word), {}), {word: c})
        out = {}
        for degree, part in parts.items():
            assert degree
            assert all(not self.EL(part, n) for n in self.p)
            for name, jets in sorted({v for word in part for v in word}):
                assert all(mu == 0 for mu in jets)
                coeff = self.partial_jet(part, (name, jets))
                for k in range(len(jets)):
                    out = self.add(out, self.scale(self.mul(self.var(name, jets[k+1:]), self.dword(coeff, jets[:k])), s.Rational((-1)**k, degree)))
        assert not self.add(self.D(out, 0), self.scale(P, -1))
        return out


def model(f, ids, G, stage):
    n = len(ids); w = DomainWords(n); x = {z: w.var(z) for z in w.p}
    vec = lambda prefix: [x[prefix+str(i)] for i in range(n)]
    addvec = lambda v, r: [w.add(a, b) for a, b in zip(v, r)]
    scale = lambda v, c: [w.scale(a, c) for a in v]
    comm = lambda v, r: [w.add(*(w.scale(w.mul(v[a], r[b]), f.get((ids[i], ids[a], ids[b]), 0)) for a in range(n) for b in range(n))) for i in range(n)]
    dot = lambda v, r: w.add(*(w.mul(a, b) for a, b in zip(v, r)))
    pairing = lambda v, r: w.add(*(w.scale(w.mul(v[a], r[b]), G[a, b]) for a in range(n) for b in range(n) if G[a, b]))
    A, q, c, bar, b, phi, omega, beta = [vec(prefix) for prefix in ("A", "q", "c", "bar", "b", "p", "omega", "beta")]
    B = addvec(A, q); cov = lambda v: addvec([w.D(a, 0) for a in v], scale(comm(A, v), g))
    field_images = {"q"+str(i): value for i, value in enumerate(addvec([w.D(a, 0) for a in c], scale(comm(B, c), g)))}
    field_images.update({"c"+str(i): w.add(*(w.scale(w.mul(c[a], c[b]), -g*f.get((ids[i], ids[a], ids[b]), 0)) for a in range(n) for b in range(a+1, n))) for i in range(n)})
    field_images.update({"bar"+str(i): w.scale(b[i], -1) for i in range(n)})
    field_images.update({"b"+str(i): {} for i in range(n)})
    field_images.update({"p"+str(i): value for i, value in enumerate(scale(comm(c, phi), -g))})
    S = w.add(*(w.mul(x[J], field_images[z]) for z, J in w.pairs)); Q = stage("word_minimal_Euler_columns", lambda: w.columns(S))
    Igen = w.add(dot(vec("Jc"), omega), dot(vec("Jb"), scale(comm(omega, bar), g)))
    I = {name: w.bracket(Igen, x[name]) for name in w.grades}
    # Independent direct cotangent matrices, not the primary Hamiltonian lift.
    def local(parameter, background=False):
        images = {prefix+str(i): value for prefix in ("q", "c", "bar", "b", "p") for i, value in enumerate(scale(comm(vec(prefix), parameter), g))}
        if not background: images.update({"q"+str(i): value for i, value in enumerate(addvec([w.D(a, 0) for a in parameter], scale(comm(B, parameter), g)))})
        for prefix in ("q", "c", "bar", "b", "p"):
            for i in range(n):
                images["J"+prefix+str(i)] = w.add(*(w.scale(w.mul(parameter[a], x["J"+prefix+str(k)]), g*f.get((ids[k], ids[a], ids[i]), 0)) for a in range(n) for k in range(n)))
        if background: images.update({"A"+str(i): value for i, value in enumerate(cov(parameter))})
        return images
    Tq, Tb = local(omega), local(beta, True)
    condition = cov(q); psi = pairing(bar, addvec(condition, scale(b, -xi/2)))
    wrong = w.act(dot(bar, addvec(condition, scale(b, -xi/2))), Tb)
    def prechecks():
        assert wrong and not w.act(psi, Tb)
        for name in w.grades:
            assert not w.add(w.Q(Q[name], I), w.Q(I[name], Q), w.scale(Tq[name], -1))
            assert not w.Q(Q[name], Q) and not w.Q(I[name], I)
            for T in (Tq, Tb): assert not w.add(w.act(Q[name], T), w.scale(w.Q(T[name], Q), -1))
        assert all(Q[z] == field_images[z] for z in w.fields)
        parameter = scale(comm(beta, omega), g)
        QB, BO, BC, QC = local(beta), local(omega, True), local(parameter, True), local(parameter)
        IG = w.add(dot(vec("Jc"), parameter), dot(vec("Jb"), scale(comm(parameter, bar), g)))
        IC = {name: w.bracket(IG, x[name]) for name in w.grades}
        for name in w.grades:
            for first, second, expected in ((QB, Tq, QC), (Tb, BO, BC), (Tb, Tq, QC)):
                assert not w.add(w.act(second[name], first), w.scale(w.act(first[name], second), -1), w.scale(expected[name], -1))
            for first in (QB, Tb): assert not w.add(w.act(I[name], first), w.scale(w.Q(first[name], I), -1), w.scale(IC[name], -1))
        for name in w.external:
            if name.startswith("A"): assert not w.add(w.act(BO[name], Tb), w.scale(w.act(Tb[name], BO), -1), w.scale(BC[name], -1))
    stage("word_pre_joint_domain_and_local_Lie", prechecks)
    shifts = {z: {} for z in w.grades}
    shifts.update({J: w.scale(w.EL(psi, z), -(-1)**w.p[z]) for z, J in w.pairs})
    positive = {z: w.add(x[z], shifts[z]) for z in w.grades}; negative = {z: w.add(x[z], w.scale(shifts[z], -1)) for z in w.grades}
    U = lambda P: w.replace(P, positive); inverse = lambda P: w.replace(P, negative)
    fixed = U(S); Qf = stage("word_fixed_Euler_columns", lambda: w.columns(fixed))
    transport = lambda T, parity: {z: U(w.act(inverse(x[z]), T, parity)) for z in w.grades}
    T, Ip, Bp = transport(Tq, 0), transport(I, 1), transport(Tb, 0)
    def fixedchecks():
        for z in w.grades:
            assert inverse(U(x[z])) == x[z]
            assert w.Q(U(x[z]), Qf) == U(Q[z])
            assert Bp[z] == Tb[z]
            assert not w.add(w.Q(Qf[z], Ip), w.Q(Ip[z], Qf), w.scale(T[z], -1))
            assert not w.Q(Qf[z], Qf)
            for L in (T, Tb): assert not w.add(w.act(Qf[z], L), w.scale(w.Q(L[z], Qf), -1))
            assert w.act(w.D(x[z], 0), T) == w.D(T[z], 0)
            assert w.Q(w.D(x[z], 0), Ip) == w.D(Ip[z], 0)
        for z, J in w.pairs: assert w.bracket(U(x[z]), w.scale(U(x[J]), (-1)**w.p[z])) == {(): s.Integer(1)}
        for (_, J), (_, K) in itertools.combinations_with_replacement(w.pairs, 2): assert not w.bracket(U(x[J]), U(x[K]))
        current = w.D(pairing(bar, [field_images["q"+str(i)] for i in range(n)]), 0)
        assert not w.add(fixed, w.scale(S, -1), w.scale(w.Q(psi, Q), -1), w.scale(current, -1))
    stage("word_canonical_transport_and_joint_identities", fixedchecks)
    F = dot(vec("Jb"), phi); image = w.Q(F, Q); FF = U(F); fixed_image = w.Q(FF, Qf)
    assert image and fixed_image and fixed_image == U(image)
    for P in (F, image): assert not w.act(P, Tq) and not w.Q(P, I) and not w.act(P, Tb)
    for P in (FF, fixed_image): assert not w.act(P, T) and not w.Q(P, Ip) and not w.act(P, Tb)
    defect = w.act(fixed_image, Tq); euler = w.EL(defect, "p0"); assert defect and euler
    def masters():
        out = {}
        for label, action in (("minimal", S), ("fixed", fixed)):
            half = w.scale(w.bracket(action, action), s.Rational(1, 2)); current = w.current(half)
            out[label] = {"half_density": w.record(half), "current": w.record(current), "all_Euler_residuals_zero": True}
        return out
    master = stage("word_source_master_currents", masters)
    return {"actions": {"source_minimal": w.record(S), "gauge_fermion": w.record(psi), "source_fixed": w.record(fixed)},
        "images": {label: {z: w.record(P) for z, P in values.items()} for label, values in (("Q_min", Q), ("Q_fixed", Qf), ("T_quantum_fixed", T), ("iota_fixed", Ip))},
        "shifts": {z: w.record(P) for z, P in shifts.items()}, "master": master,
        "domain": {"pre_basic_source_F": w.record(F), "pre_Q_image": w.record(image), "fixed_F": w.record(FF), "fixed_Q_image": w.record(fixed_image)},
        "negative_controls": {"wrong_plain_dot_Ward_residual": w.record(wrong), "wrong_raw_quantum_domain_residual": w.record(defect), "nonzero_scalar_Euler_residual": w.record(euler)},
        "canonical_pairs": len(w.pairs), "base_generators": len(w.grades), "maximum_jet_order": w.max_jet, "ordinary_derivations": 1, "kinetic_potential_action_included": False,
        "all_generator_and_first_jet_identities_pass": True, "all_source_cross_pair_checks_pass": True, "EOM_used": False}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    stage = stage or (lambda n, fn: fn())
    f, ids, G, bridge = stage("replay_physical_H_coordinate_bridge", coordinate_bridge)
    return {"schema": "SOURCE_DOMAIN_TRANSPORT_REPLAY_V1", "source_bridge": bridge, "block": model(f, ids, G, stage),
        "independence": {"ALGORITHM_INDEPENDENT": True, "CODE_PATH_INDEPENDENT": True, "LIBRARY_INDEPENDENT": False, "RUNTIME_INDEPENDENT": False,
            "primary_model_or_output_imported": False, "analyst_blind": False, "external_specialist_review": False,
            "shared_assumptions": "declared bracket/model/transport; Python and SymPy; previous physical-geometry and word engines reused",
            "source_lift": "direct cotangent matrices rather than primary Hamiltonian variation", "physical_parent_commutators": 990, "scalar_328_reconstructed": False}}


if __name__ == "__main__": print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
