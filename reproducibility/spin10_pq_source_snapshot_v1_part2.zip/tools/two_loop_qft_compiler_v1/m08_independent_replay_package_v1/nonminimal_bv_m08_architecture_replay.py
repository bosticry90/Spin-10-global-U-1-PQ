"""Direct physical Phi-tensor replay; no primary module/SA10 matrices import."""
import json
from itertools import combinations
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent


def load(name):
    return json.loads((HERE/name).read_text(encoding="utf-8"))


def build():
    if not __debug__:
        raise RuntimeError("EXACT_REPLAY_REQUIRES_ASSERTIONS_ENABLED")
    rep = load("frozen_c3/C3_representation_basis.json")
    pairs = list(combinations(range(10), 2))
    H = []
    for row in rep["h_basis"]:
        h = s.zeros(10)
        for entry in row["raw_so10_coordinates"]:
            i, j = pairs[entry["index"]]
            h[i, j] += s.sympify(entry["coefficient"])/s.sqrt(2)
            h[j, i] -= s.sympify(entry["coefficient"])/s.sqrt(2)
        H.append(h)
    a, b = 0, 4
    bracket = H[a]*H[b]-H[b]*H[a]
    gram = s.Matrix(12, 12, lambda i, j: s.trace(H[i].T*H[j]))
    coeff = (gram.inv()*s.Matrix([s.trace(h.T*bracket) for h in H])).applyfunc(s.simplify)
    assert (sum((coeff[i]*H[i] for i in range(12)), s.zeros(10))-bracket).applyfunc(s.simplify) == s.zeros(10)
    assert [(i, v) for i, v in enumerate(coeff) if v] == [(4, -s.I/s.sqrt(2))]
    phi = load("frozen_action_ast_a3/A31_embeddings.json")["sectors"]["Phi"]
    E = s.SparseMatrix(100, 54, {(i, j): s.sympify(v) for i, j, v in phi["embedding_entries"]})
    assert E.T*E == s.eye(54)
    tensor = s.Matrix(10, 10, list(E[:, 3]))
    dual = s.Matrix(10, 10, list(E[:, 0]))
    assert tensor == tensor.T and s.trace(tensor) == 0
    assert s.trace(dual.T*tensor) == 0
    def act(h, x):
        # Direct symmetric-tensor transformation, no serialized rho action.
        return (h*x+x*h.T).applyfunc(s.simplify)
    # Read original forward AST rather than primary sign/table results.
    seed = load("frozen_st_seed/S1_component_transformations.json")
    assert "sigma(phi)=rho(c+u)(v+phi)" in seed["shifted_scalar_convention"]
    rows = load("frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json")["images"]
    qc = next(row["B_Sigma_image"] for row in rows if row["identity"] == "c_L")
    qcc = next(row for row in qc["terms"] if any(n.get("node") == "StructureConstant" for n in row["factors"]))
    assert s.sympify(qcc["factors"][0]["value"]) == -s.Rational(1, 2)
    # Explicit ordered odd slots: Q(c_a rho_a X)=Qc_a rho_a X-c_a rho_a QX.
    ghost_tensor = -sum((coeff[i]*act(H[i], tensor) for i in range(12)), s.zeros(10))
    iteration_tensor = -act(H[a], act(H[b], tensor))+act(H[b], act(H[a], tensor))
    total = (ghost_tensor+iteration_tensor).applyfunc(s.simplify)
    ghost_value = s.simplify(s.trace(dual.T*ghost_tensor))
    iteration_value = s.simplify(s.trace(dual.T*iteration_tensor))
    value = s.simplify(s.trace(dual.T*total))
    assert (ghost_value, iteration_value, value) == (s.Rational(1, 2), s.Rational(1, 2), 1)
    assert (act(H[a], act(H[b], tensor))-act(H[b], act(H[a], tensor))-act(bracket, tensor)).applyfunc(s.simplify) == s.zeros(10)
    # The alternate matter sign is a semantic diagnostic, NOT a modified theory.
    assert (-ghost_tensor+iteration_tensor).applyfunc(s.simplify) == s.zeros(10)
    return {"schema": "NONMINIMAL_BV_M08_PHYSICAL_PHI_REPLAY_V1",
        "route": "Normalized physical 10x10 H matrices, trace-Gram projection, symmetric Phi tensor, ordered odd-slot differentiation",
        "selected_component": {"light_ghost_pair": [0, 4], "scalar_output_coordinate": 0,
            "scalar_input_coordinate": 3, "coefficient_in_Q2_eta0": str(value),
            "ghost_variation_contribution": str(ghost_value),
            "scalar_iteration_contribution": str(iteration_value)},
        "physical_tensor_result": [[i, j, str(v)] for (i, j), v in sorted(total.todok().items())],
        "normalization": "T_ab=(E_ab-E_ba)/sqrt(2), C=Q^-1 bracket(Q,Q)",
        "EOM_or_IBP_used": False, "unshifted_scalar_coefficient_extracted": True,
        "R_H_or_sources_needed": False, "primary_output_or_SA10_matrix_imported": False,
        "independence": {"algorithm_independent": True, "code_path_independent": True,
            "library_independent": False, "runtime_independent": False,
            "external_specialist_review": False,
            "limits": "Shared Python/SymPy, physical C3/A3 basis and frozen AST conventions; replay target known, not analyst-blind"}}


if __name__ == "__main__":
    print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
