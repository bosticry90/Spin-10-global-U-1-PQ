"""Versioned primary M08 amendment certified by the frozen D4 oracle.

The historical primary construction remains in ``execute_work_package_d``.
This module changes only the five primitive graph families for which D4
provided an implementation-independent action derivative, group orientation,
and BPHZ residue certificate.
"""

from __future__ import annotations

import sympy as sp

import execute_work_package_d as historical


XI = historical.XI


def amended_primary_piece_construction(action):
    structure, pieces, trees = historical.primary_piece_construction(action)
    amended = {}
    for process, rows in pieces.items():
        output = []
        for topology, assignment, color, lorentz, sign in rows:
            key = (topology, assignment)
            provenance = "HISTORICAL_UNCHANGED"
            if process == "ubarH_uH_VH" and key == (
                "seagull_cubic_swordfish", "Vq_three_vector"
            ):
                coefficient = sp.Rational(3, 4) * (1 + XI + 4 / XI)
                lorentz, sign = (coefficient, coefficient, sp.Integer(0), sp.Integer(0)), 1
                provenance = "D4_MIXED_YM_PLUS_PARTIAL_GF_SPLIT_RECOMBINED"
            elif process == "ubarH_uH_qL" and key == (
                "seagull_cubic_swordfish", "qq_ext_antighost_on_seagull"
            ):
                lorentz, sign = (sp.Integer(0), sp.Rational(3, 2), sp.Integer(0), sp.Integer(0)), 1
                provenance = "D4_COVARIANT_LAPLACIAN_SEAGULL_SIGN"
            elif process == "ubarH_uH_qL" and key == (
                "seagull_cubic_swordfish", "qq_ext_ghost_on_seagull"
            ):
                lorentz, sign = (sp.Rational(-3, 2), sp.Integer(0), sp.Integer(0), sp.Integer(0)), 1
                provenance = "D4_COVARIANT_LAPLACIAN_SEAGULL_SIGN"
            elif topology == "equivariant_quartic_ghost_bubble":
                if process == "ubarH_uH_qL":
                    lorentz, sign = (sp.Integer(0),) * 4, 1
                    provenance = "D4_LIGHT_EXTERNAL_QUARTIC_CHANNEL_CANCELLATION"
                elif process == "ubarH_uH_VH" and assignment == "direct":
                    lorentz, sign = (sp.Integer(0),) * 4, 1
                    provenance = "D4_HEAVY_EXTERNAL_QUARTIC_DIRECT_CANCELLATION"
                elif process == "ubarH_uH_VH" and assignment == "exchange":
                    lorentz, sign = (-XI / 2, -XI / 2, sp.Integer(0), sp.Integer(0)), 1
                    provenance = "D4_HEAVY_EXTERNAL_QUARTIC_EXCHANGE_RESIDUE"
            output.append((topology, assignment, color, lorentz, sign, provenance))
        amended[process] = output
    return structure, amended, trees


def strip_provenance(piece):
    return piece[:5]
