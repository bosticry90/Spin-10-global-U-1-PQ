"""Syntactic exact Ward identity for closed SO(10) contraction ASTs.

This is a polynomial identity, not an inference from character dimensions.
Every contracted fundamental index has precisely two occurrences. Acting on
both endpoints produces G_ij+G_ji=0 after renaming the dummy index. Restricted
constrained carriers obey this same parent tensor action (certified SA10/11).
After qualified C restriction, Schur's lemma and the certified REG7 pairing
therefore fix an ENTIRE terminal matrix to c J. Only c requires extraction.
"""
import sympy as sp
import execute_scalar_ast_channel_bridge as br


def certify(ast):
    _,occurrences=br.factors(ast)
    expected={'Phi':2,'Sigma':5,'SigmaBar':5,'phi':1,'phiBar':1,'S':0,'SBar':0}
    endpoints={}
    for slot,(name,indices) in enumerate(occurrences):
        assert name in expected and len(indices)==expected[name]
        assert len(indices)==len(set(indices))
        for leg,index in enumerate(indices):endpoints.setdefault(index,[]).append((slot,leg))
    actions=br.load(br.HERE/'frozen_scalar_adapter_v2/SA10_physical_actions.json')
    generators=[br.matrix(m) for m in actions['H_10_matrices']]
    assert len(generators)==12
    assert all(g.T+g==sp.zeros(10) for g in generators)
    edges=[]
    for index,legs in endpoints.items():
        assert len(legs)==2 and legs[0][0]!=legs[1][0]
        # Explicit generator-coordinate polynomial cancellation at EVERY
        # index value for every frozen H generator, before physical restriction.
        assert all(g[i,j]+g[j,i]==0 for g in generators for i in range(10) for j in range(10))
        edges.append({'index':index,'ordered_endpoints':legs,
            'dummy_index_transport':'First endpoint: rename summed i<->j; second endpoint unchanged',
            'variation_coefficient':'G_ji+G_ij','all_12_parent_generator_residual':'ZERO_EXACT'})
    return {'A3_AST_hash':br.canonical(ast),'ordered_occurrences':occurrences,'edges':edges,
        'status':'PASS_EXACT_POLYNOMIAL_WARD_IDENTITY','constraint_authority':actions['artifact_sha256'],
        'scope':'Closed fundamental-index contractions; invariant constrained Phi/Sigma/real-complex bridges',
        'terminal_proof':{
            'hypotheses':['Exact A3 tensor Ward identity','Certified V2 physical registry-column equivariance',
                'Immutable INT3 C generator covariance','Irreducibility of promoted harmonic SU3/Sym^n SU2 carriers',
                'REG7 full-rank invariant dual terminal pairing'],
            'conclusion':'For each fixed pair of binary copies, T_restricted=c*J on the ENTIRE terminal block',
            'extraction':'One preregistered first nonzero J entry evaluated directly from A3, never comparator values',
            'not_used':['Euclidean transpose identification','Character-count-only argument','Channel coefficient import']}}
