"""Seal validated inactive prerequisite evidence; no state promotion."""
import json,subprocess,sys
from hashlib import sha256
from a10_e5_cubic_primitive import HERE,ROOT,OUT,read
from validate_a10_e5_cubic_primitive import protected,new_files
from seal_a10_e5_auxiliary_vertex import PARENTS as OLD_PARENTS

PARENTS=(*OLD_PARENTS,'frozen_a10_e5_auxiliary_vertex')


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'NO_OVERWRITE'
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['status']=='PASS_BOUNDED_CUBIC_PRIMITIVE_PREREQUISITE_EVIDENCE_ONLY'
    assert receipt['fresh_routes_byte_identical']==2 and not receipt['audit_time_changes']
    assert receipt['historical_custody_exit']==2 and receipt['unresolved_historical_references']==7
    assert not receipt['actual_four_ghost_pole_calculated'] and not receipt['enclosing_contract_complete']
    assert protected()==receipt['protected_byte_sha256']
    for name,h in receipt['new_sha256'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,('CHANGED_AFTER_VALIDATION',name)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==receipt['state_sha256']
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='f7f605443062b76f38ca3569ba2fe38e66d80d26'
    paths=new_files()+[OUT/'validation_receipt.json']+list(OUT.glob('validation_attempt_*.json'))
    for p in paths:assert p.read_bytes().endswith(b'\n'),p
    value={'schema':'E5_CUBIC_PRIMITIVE_PREREQUISITE_BINDINGS_V1','base_commit':base,
        'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
        'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
        'state_sha256':receipt['state_sha256'],'scientific_disposition':'QUALIFIED_INACTIVE_CUBIC_PRIMITIVE_AND_FROZEN_QUARTIC_PREDICTION_ONLY',
        'authority_changed':False,'actual_four_ghost_pole_calculated':False,'actual_quartic_matching_proved':False,
        'enclosing_contract_complete':False,'full_E5_PASS':False,'whole_goal_complete':False,
        'candidate_adopted':False,'sources_activated':False,'auxiliaries_eliminated':False,'HB1_C5_run':False,
        'C1_GS_calculated':False,'remote_push':False,'external_endorsement':False,'personal_outreach':False,
        'post_validation_finalization':'receipt and byte seal only; no calculation edits'}
    with (OUT/'bindings.json').open('xb') as f:f.write(json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED inactive primitive prerequisite and quartic prediction; actual quartet remains uncalculated')


if __name__=='__main__':main()
