"""Full finite-block equivalence of two exact AST summation orders."""
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from execute_int9_int15 import freeze
from int11_ordered_ast_lowering import AllParentLowering


def main():
    directions=br.load(br.HERE/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions']
    primary=AllParentLowering(directions); rows=[]
    for name in ('lambdaSigma2','lambdaSigma3','lambdaSigma4'):
        seen=set()
        for address,slots,fields in primary.eligible(directions[name]):
            t=primary.descriptors[4]['terminal_channels'][address['terminal_channel_index']]
            label=tuple(t['intermediate_H_label']) if 'intermediate_H_label' in t else tuple(primary.binary[t['left_binary_block_indices'][address['digits'][0]]]['output_H_label'])
            d=primary.duals.pairing(label).rows
            category=0 if d==1 else 1 if d<8 else 2
            if category in seen: continue
            primary.use_crossed_kernel=False
            old,_,_=primary.restricted_tensor(name,address,slots,fields)
            new,_,_=primary.crossed_restricted_tensor(name,address,slots,fields)
            assert sp.SparseMatrix(old-new).applyfunc(sp.simplify)==sp.zeros(*old.shape),(name,address)
            pairing=primary.duals.pairing(label).T
            i,j=sorted(pairing.todok())[0]
            entry=primary.extraction_entry(name,address,slots,fields,i,j)
            assert sp.simplify(entry-old[i,j])==0,(name,address,'independent extraction entry')
            assert sp.simplify(old-entry/pairing[i,j]*pairing)==sp.zeros(*old.shape),(name,address,'Ward/Schur full block')
            seen.add(category)
            rows.append({'family':name,'address':address,'full_terminal_shape':list(old.shape),
                         'original_target_sha256':br.canonical(br.serialize(old)),
                         'crossed_target_sha256':br.canonical(br.serialize(new)),
                         'nonzero_tensor':bool(old.todok()),
                         'A3_extraction_entry':[i,j],'extraction_value':str(entry),
                         'Ward_Schur_vs_original_full_tensor_residual':'ZERO_EXACT',
                         'full_entrywise_residual':'ZERO_EXACT'})
            print('CROSSED_KERNEL_EXACT',name,list(old.shape),flush=True)
            if seen=={0,1,2}: break
    freeze('INT11_crossed_boundary_qualification.json',{
        'status':'PASS_EXACT_AST_SUMMATION_ORDER_TRANSPORT','full_tensor_checks':rows,
        'fusion_coefficient_extraction_tree':'UNCHANGED_(01)(23)',
        'dense_global_scalar_tensor_materialized':False,'comparator_or_channel_coefficients_used':False})


if __name__=='__main__':main()
