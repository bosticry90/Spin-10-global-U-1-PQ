"""Read-only finite-amplitude extension with exact local/input start bindings."""
import json,sys,time
from hashlib import sha256
from a10_e5_ghost_normalization_finite import HERE,ROOT,OUT,build,s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==2 and sys.argv[1] in ('primary','replay');route=sys.argv[1]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            raise PermissionError('FINITE_GHOST_WRITE_DENIED')
    sys.addaudithook(hook)
    names=('A10_E5_GHOST_NORMALIZATION_FINITE_SPEC_V1.md','a10_e5_ghost_normalization_finite.py','run_a10_e5_ghost_normalization_finite.py')
    fingerprint={'schema':'GHOST_FINITE_EXECUTION_START_V1','route':route,
      'implementation_and_contract_sha256':{n:sha256((HERE/n).read_bytes()).hexdigest() for n in names},
      'main_input_sha256':sha256((OUT/(route+'.json')).read_bytes()).hexdigest(),
      'input_manifest_sha256':sha256((HERE/'frozen_a10_e5_minimal_target/bindings.json').read_bytes()).hexdigest(),
      'state_sha256':sha256((ROOT/'project_state.json').read_bytes()).hexdigest(),
      'python':sys.version,'executable':sys.executable,'sympy':s.__version__,'guard_active':True}
    print('EXECUTION '+json.dumps(fingerprint,sort_keys=True,separators=(',',':')),flush=True)
    start=time.perf_counter();value=build(route)
    print('RESULT '+json.dumps(value,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'execution_state':'COMPLETED','seconds':time.perf_counter()-start,'write_attempts':[]},sort_keys=True),flush=True)


if __name__=='__main__':main()
