"""Exact quantum family, representation and adversarial regression checks."""
import unittest
from audit_a10_e5_quartic_g3 import *


class G3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_full_vector_and_Gaussian_weights(self):self.assertEqual(self.u['full4_Born'],self.u['full4_Gaussian'])
    def test_longitudinal_reduction_weights(self):self.assertEqual(self.u['full4_Born'],self.u['reduced_Born'])
    def test_five_class_omissions_detected(self):self.assertTrue(all(value(z)!=0 for z in self.u['omit_each_nonzero_class_residual_at_width2'].values()))
    def test_wrong_loop_sign_detected(self):self.assertTrue(all(value(z)!=0 for z in self.u['wrong_loop_sign_residual_at_width2'].values()))
    def test_transverse_extension_counterexample(self):self.assertNotEqual(value(self.u['endpoint_proof']['outside_scope_transverse_counterexample']),0)
    def test_curvature_families_calculated(self):self.assertTrue(self.a['formal_family_poles']['GXR_triangle']);self.assertTrue(self.a['formal_family_poles']['QR_bubble'])
    def test_curvature_omission_changes_tensor(self):
        p={}
        for name in ['GXR_triangle','QR_bubble']:
            for key,z in slot_map(self.a['bound_family_poles'][name]).items():p[key]=p.get(key,0)+z
        self.assertTrue(any(s.expand(z)!=0 for z in p.values()))
    def test_explicit_WQ_block_zero(self):self.assertEqual(self.a['formal_family_poles']['WQ_bubble'],[]);self.assertEqual(self.u['full4_Born']['WQ_bubble'],'0')
    def test_all_H_gauge_vertices_retained(self):
        P=decode_typed(self.a['vertices']['W_ALL_H_M'])
        self.assertTrue(any(any(n.startswith('Bp') and int(n[2:])<12 for n,j in word) for word in P))
    def test_G_external_antighost_derivative_route_retained(self):
        P=decode_typed(self.a['vertices']['G']);self.assertTrue(any(any(n.startswith('Cp') and j for n,j in word) for word in P))
    def test_real_quartet_coupling_width_homogeneity(self):
        for z in slot_map(self.a['actual_pole']).values():
            self.assertEqual(s.expand(z-s.conjugate(z)),0);self.assertEqual(s.Poly(z,xi,ETA_H).total_degree(),2)
    def test_no_predicted_H_zeros_used(self):self.assertEqual(self.a['domain']['antisymmetric_pair_slots'],980100);self.assertFalse(self.a['candidate_read_after_byte_authentication'])
    def test_real_frame_roundtrip(self):
        w,sub,source,anti,Cinv,Cphys,EM,EH=physical_model('primary');pull=w.replace
        raw=decode_typed(self.c['canonical_actual_density']);p=decode_typed(self.c['physical_actual_density'])
        self.assertFalse(canonical(w.add(pull(raw,sub),w.scale(p,-1))))
    def test_wrong_dual_chart_changes_tensor(self):self.assertTrue(self.c['wrong_real_dual_chart_residual'])
    def test_wrong_width_binding_changes_tensor(self):self.assertTrue(self.c['wrong_width_binding_residual'])
    def test_odd_Euler_order_changes_tensor(self):self.assertTrue(self.c['odd_Euler_control']['wrong_even_deletion_residual'])
    def test_graded_supertrace_negative_control(self):self.assertNotEqual(self.u['graded_algebra_controls']['full_supertrace_log'],self.u['graded_algebra_controls']['wrong_ungraded_trace'])
    def test_complete_difference_and_failure_witness(self):
        self.assertEqual(bool(self.c['full_difference_slots']),not self.c['match'])
        if not self.c['match']:
            self.assertTrue(self.c['real_odd_first_failure_witness']['full_Euler']);self.assertFalse(self.c['real_odd_first_failure_witness']['pure_total_derivative'])
    def test_prior_prediction_unchanged(self):
        old=read(HERE/'frozen_a10_e5_auxiliary_derivative/comparison.json')
        self.assertEqual(self.c['unchanged_candidate_prediction'],old['complete_total_g3_quartet_prediction'])


if __name__=='__main__':unittest.main()
