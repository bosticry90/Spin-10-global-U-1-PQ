"""Inactive local U(1) cotangent/source reconciliation; stdout only."""
import json
import sympy as s
from source_convention_control import Checks, dot
from partial_gauge_bv_bridge import setup, GRADES, FIELDS, PAIRS, g

DISPOSITION="QUALIFIED_LOCAL_SU2_U1_PARTIAL_BV_CONTROL_ONLY_NOT_M08"


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda n,f:f()
    j,x,A,eta,C,bar,b,R,F,cov,S0,forward,Smin,G,psi,L,I=stage("local_model",setup)
    a,checks=j.a,Checks()
    Qmin=stage("local_minimal_Euler_columns",lambda:j.columns(Smin))
    gf=j.Q(psi,Qmin); S=a.add(Smin,gf)
    Q=stage("local_fixed_Euler_columns",lambda:j.columns(S))
    for z in FIELDS:
        checks.equal(a,Q[z],forward[z],"unchanged fixed forward rule")
        checks.equal(a,Qmin[z],forward[z],"unchanged minimal forward rule")
    for n in GRADES:
        d,gh,par=GRADES[n]
        checks.true(j.homogeneous_grade(Q[n],(d+1,gh+1,1-par)),"column grade")
    checks.true(j.homogeneous_grade(S,(4,0,0)),"master action grade")
    checks.true(j.homogeneous_grade(psi,(3,-1,1)),"fermion grade")
    omega=j.var("omega")
    field_action={z:a.scale(a.mul(omega,L[z]),g) for z in FIELDS}
    for mu in range(4): field_action[f"A2{mu}"]=j.D(omega,mu)
    # Cotangent Hamiltonian from the physical local action, before any square.
    generator=a.add(*(a.scale(a.mul(x[J],field_action[z]),-(-1)**GRADES[z][2]) for z,J in PAIRS))
    T=stage("independent_parameter_cotangent_lift",lambda:{n:j.bracket(generator,x[n]) for n in GRADES})
    for z in FIELDS: checks.equal(a,T[z],field_action[z],"canonical field lift "+z)
    for z,J in PAIRS:
        checks.equal(a,T[J],a.scale(a.mul(omega,L[J]),g),"evaluation dual source "+J)
    contraction={n:{} for n in GRADES}; contraction["c2"]=omega
    act=lambda P:j.act(P,T,0)
    iota=lambda P:j.act(P,contraction,1)
    lie=lambda P:j.act(P,L,0)
    iglobal=lambda P:j.act(P,I,1)
    def compatibility():
        for n in GRADES:
            checks.equal(a,a.add(iota(Q[n]),j.Q(contraction[n],Q)),T[n],"local iQ "+n)
            checks.zero(a.add(act(Q[n]),a.scale(j.Q(T[n],Q),-1)),"local TQ "+n)
            checks.equal(a,a.add(iglobal(Q[n]),j.Q(I[n],Q)),a.scale(L[n],g),"global iQ "+n)
            checks.zero(a.add(lie(Q[n]),a.scale(j.Q(L[n],Q),-1)),"global LQ "+n)
            checks.zero(a.add(lie(I[n]),a.scale(iglobal(L[n]),-1)),"global Li "+n)
            checks.zero(iglobal(I[n]),"global i squared")
            for mu in range(4):
                checks.equal(a,act(j.D(x[n],mu)),j.D(T[n],mu),"local derivative prolongation")
                checks.equal(a,iota(j.D(x[n],mu)),j.D(contraction[n],mu),"contraction derivative prolongation")
        for z,J in PAIRS:
            checks.zero(a.add(act(j.bracket(x[z],x[J])),a.scale(j.bracket(T[z],x[J]),-1),a.scale(j.bracket(x[z],T[J]),-1)),"canonical bracket derivation")
        for prefix in ("A","p","c","bar","b"):
            mus=range(4) if prefix=="A" else [None]
            for mu in mus:
                tail="" if mu is None else str(mu)
                paired=a.add(*(a.mul(x["J"+prefix+str(k)+tail],x[prefix+str(k)+tail]) for k in range(2)))
                checks.zero(act(paired),"homogeneous dual pairing")
        M=j.euler(S,"c2")
        checks.equal(a,M,j.euler(Smin,"c2"),"GF does not change residual moment")
        current=[a.scale(a.mul(omega,x[f"JA2{mu}"]),-1) for mu in range(4)]
        checks.equal(a,a.add(generator,a.scale(a.mul(omega,M),-1)),j.div(current),"moment density with exact current")
        return M,current
    M,current=stage("local_source_Cartan_compatibility",compatibility)
    # Substitute only after the independent-parameter source variation.
    substitution={"omega":a.add(a.scale(R,-g),a.scale(omega,-1))}
    T_R={n:j.transport(T[n],substitution) for n in GRADES}
    delta={n:j.strip_light_ghost(Q[n]) for n in GRADES if n!="c2"}
    checks.zero(j.Q(R,delta),"delta R")
    def closure_gate():
        passed=[]
        for n in delta:
            actual=j.Q(delta[n],delta)
            residual=a.add(actual,a.scale(T_R[n],-1))
            checks.zero(residual,"local Cartan square "+n)
            passed.append(n)
        for n in delta:
            for mu in range(4):
                checks.equal(a,j.Q(j.Q(j.var(n,(mu,)),delta),delta),j.D(T_R[n],mu),"local Cartan first jet "+n)
        return passed
    passed=stage("complete_local_Cartan_base_and_first_jets",closure_gate)
    # The independent parameter is held fixed during source variation.
    # Replacing it BEFORE variation is a different Hamiltonian on sources.
    n="Jc0"; actual=j.Q(delta[n],delta)
    transported_generator=j.transport(generator,substitution)
    canonical_before=j.bracket(transported_generator,x[n])
    before_residual=a.add(actual,a.scale(canonical_before,-1))
    diagnostic=a.scale(a.mul(j.a.partial(R,"c0"),M),-g)
    checks.equal(a,before_residual,diagnostic,"field-dependent source chain rule distinguished")
    checks.true(bool(before_residual),"wrong substitution order is a negative control")
    connection=j.Q(delta["A20"],delta)
    checks.equal(a,connection,T_R["A20"],"old connection now local gauge action")
    checks.equal(a,connection,a.scale(j.D(R,0),-g),"old nonzero derivative unchanged")
    old_pair=a.mul(x["JA20"],connection)
    checks.equal(a,j.euler(old_pair,"JA20"),connection,"old source-paired witness not discarded")
    density=a.mul(x["JA20"],x["A20"])
    density_square=j.Q(j.Q(density,delta),delta)
    checks.equal(a,density_square,j.act(density,T_R,0),"source-paired density full local action")
    M_h=j.strip_light_ghost(M)
    checks.equal(a,M_h,M,"moment is horizontal")
    checks.zero(lie(M),"moment is globally invariant")
    checks.true(bool(M),"nonzero moment not eliminated")
    def local_ward():
        rotation=[a.scale(G[1],-1),G[0]]
        for k in range(2): checks.equal(a,act(G[k]),a.scale(a.mul(omega,rotation[k]),-g),"local condition covariance")
        for name,P in (("S0",S0),("psi",psi),("GF",gf)):
            checks.zero(act(P),"local H "+name)
            checks.zero(iota(P),"horizontal "+name)
        checks.zero(j.Q(S0,Q),"physical action invariance")
        return {"arbitrary_parameter_jets":True,"G_covariant":True,"S0_psi_GF_pointwise_invariant_and_horizontal":True,"residual_connection_dynamical_not_background":True}
    ward=stage("local_Ward_and_horizontal_gauge_fixing",local_ward)
    def squares():
        for n in GRADES:
            checks.zero(j.Q(Qmin[n],Qmin),"minimal Q square "+n)
            checks.zero(j.Q(Q[n],Q),"fixed Q square "+n)
            for mu in range(4):
                checks.equal(a,j.Q(j.D(x[n],mu),Q),j.D(Q[n],mu),"Q ordinary prolongation")
                checks.zero(j.Q(j.Q(j.var(n,(mu,)),Q),Q),"fixed Q first jet "+n)
        return 264
    square_count=stage("complete_full_Weil_Q_squares",squares)
    def masters():
        result={}
        for label,action in (("minimal",Smin),("partial_fixed",S)):
            half=a.scale(j.bracket(action,action),s.Rational(1,2))
            for n in GRADES: checks.zero(j.euler(half,n),"master Euler "+n)
            boundary=j.divergence_certificate(half)
            result[label]={"half_density":j.record(half),"current":[j.record(t) for t in boundary],"all_Euler_residuals_zero":True}
        return result
    master=stage("partial_master_equations_and_currents",masters)
    def transport():
        shifts={n:a.scale(j.bracket(psi,x[n]),-1) for n in GRADES}
        transformed=j.transport(Smin,shifts)
        boundary=j.divergence_certificate(a.add(transformed,a.scale(S,-1)))
        for n in GRADES:
            checks.true(j.homogeneous_grade(shifts[n],GRADES[n]),"shift grade")
            checks.equal(a,j.transport(j.transport(x[n],shifts),shifts,-1),x[n],"canonical inverse")
            checks.equal(a,j.Q(j.transport(x[n],shifts),Q),j.transport(Qmin[n],shifts),"canonical Q intertwining")
            checks.equal(a,act(j.transport(x[n],shifts)),j.transport(T[n],shifts),"canonical local equivariance")
            checks.equal(a,iota(j.transport(x[n],shifts)),j.transport(contraction[n],shifts),"canonical local contraction")
        checks.equal(a,j.transport(transformed,shifts,-1),Smin,"action inverse")
        return {"shifts":{n:j.record(shifts[n]) for n in GRADES},"action_difference_current":[j.record(t) for t in boundary],"inverse_intertwining_local_equivariance":True}
    trans=stage("partial_canonical_gauge_fixing",transport)
    def controls():
        quartic={word:co for word,co in gf.items() if len(word)==4 and set(word)=={"bar0","bar1","c0","c1"}}
        checks.true(bool(quartic),"quartic coset ghost term nonzero")
        checks.zero(j.Q(gf,delta),"equivariant GF invariance")
        omitted_quartic=j.Q(a.add(gf,a.scale(quartic,-1)),delta)
        checks.true(bool(omitted_quartic),"quartic omission must fail")
        wrong=dict(Q)
        for k in range(3): wrong[f"p{k}"]=a.scale(Q[f"p{k}"],-1)
        scalar_bad=j.Q(wrong["p0"],wrong); checks.true(bool(scalar_bad),"wrong positive scalar sign fails")
        bad=dict(Q)
        for k in range(2):
            rotation=a.scale(bar[1],-1) if k==0 else bar[0]
            bad[f"b{k}"]=a.add(Q[f"b{k}"],a.scale(a.mul(R,rotation),g*g))
        auxiliary_bad=j.Q(bad["bar0"],bad); checks.true(bool(auxiliary_bad),"missing R auxiliary lift fails")
        broken=a.add(S,*(a.scale(a.mul(x[f"Jbar{k}"],Q[f"bar{k}"]),-1) for k in range(2)))
        old=j.columns(broken,[pair for pair in PAIRS if not pair[0].startswith("bar")])
        old.update({f"bar{k}":Q[f"bar{k}"] for k in range(2)})
        old_square=j.Q(old["Jb0"],old)
        free={word:s.expand(co.subs(g,0)) for word,co in old_square.items() if s.expand(co.subs(g,0))!=0}
        checks.equal(a,free,a.scale(j.box(C[0]),-1),"omitted partner retains historical free failure")
        basic={"scalar_coset_radius":a.add(a.mul(eta[0],eta[0]),a.mul(eta[1],eta[1])),
            "source_curvature":a.mul(x["Jc2"],R),"antighost_auxiliary":dot(a,bar[:2],b[:2])}
        records={}
        for name,P in basic.items():
            checks.zero(act(P),"local basic invariant "+name); checks.zero(iota(P),"local horizontal "+name)
            image=j.Q(P,Q)
            checks.true(bool(image),"nonzero basic image "+name)
            checks.zero(act(image),"local basic image invariant "+name); checks.zero(iota(image),"local basic image horizontal "+name)
            checks.equal(a,image,j.Q(P,delta),"basic Q equals delta "+name)
            records[name]={"operator":j.record(P),"image":j.record(image)}
        return {"quartic_density":j.record(quartic),"omitted_quartic_delta_residual":j.record(omitted_quartic),"wrong_scalar_square":j.record(scalar_bad),"omitted_R_auxiliary_square":j.record(auxiliary_bad),"omitted_partner_free_square":j.record(free),"basic_controls":records}
    ctrl=stage("partial_local_basic_and_negative_controls",controls)
    return {"schema":"LOCAL_RESIDUAL_CARTAN_V1","disposition":DISPOSITION,"model":"unchanged_SU2_U1_44_generator_control",
        "base_generator_count":44,"canonical_pair_count":22,
        "actions":{"invariant":j.record(S0),"minimal_master":j.record(Smin),"gauge_fermion":j.record(psi),"gauge_fixing":j.record(gf),"partial_fixed_master":j.record(S)},
        "minimal_images":{n:j.record(Qmin[n]) for n in GRADES},"images":{n:j.record(Q[n]) for n in GRADES},
        "local_action":{"Hamiltonian":j.record(generator),"independent_parameter_images":{n:j.record(T[n]) for n in GRADES},"moment":j.record(M),"moment_current":[j.record(t) for t in current],"R":j.record(R),"after_variation_substituted_images":{n:j.record(T_R[n]) for n in GRADES},"all_44_local_and_global_compatibility_checks":True,"source_pair_orientation":"zstar=(-1)^p J; odd Hamiltonian -sum (-1)^p J Tz"},
        "closure":{"all_43_base_generators":passed,"all_172_first_jets":True,"total_checks":215,"all_exact_zero_residual":True,
            "source_Jc2_retained":True,"moment_constraint_not_imposed":True,"substitution_order_control":{"generator":n,"actual_square":j.record(actual),"local_parameter_square":j.record(T_R[n]),"field_dependent_Hamiltonian_square":j.record(canonical_before),"field_dependent_residual":j.record(before_residual),"moment_chain_rule_diagnostic":j.record(diagnostic)}},
        "historical_connection":{"actual_square":j.record(connection),"source_paired_nonzero_Euler":j.record(j.euler(old_pair,"JA20")),"source_density_square":j.record(density_square),"full_local_source_density_action":j.record(j.act(density,T_R,0))},
        "master":master,"transport":trans,"local_Ward":ward,"controls":ctrl,
        "Q_squares":{"minimal_base":44,"partial_fixed_base":44,"partial_fixed_first_jets":176,"total":square_count,"all_exact_zero":True,"maximum_jet_order":j.max_order,"truncation":False,"higher_jets":"evolutionary prolongation theorem, not separately enumerated"},
        "domain":{"local_functionals_modulo_total_derivatives":True,"conditions":"T_omega F=iota_omega F=0 for every independent local even parameter omega and its jets, as functionals",
            "preservation":"[T_omega,Q]=0 and {iota_omega,Q}=T_omega; evolutionary prolongation descends through divergences; Q equals delta on horizontal representatives, and delta^2=T_omega evaluated at omega=-gR vanishes on local-invariant functionals",
            "no_EOM_or_moment_quotient":True,"M08_H_basic_definition_certified":False},
        "exact_assertion_count":checks.count,"bridge_qualified":True,"master_and_complete_Q_square_gates_reached":True,"EOM_used":False,"M08_changed":False,"HB1_C5_authorized":False,"cochain_dimensions_computed":False,"external_specialist_review":False,"formal_authority":"34/39_UNCHANGED","finite_C1_GS":None}


if __name__=="__main__": print(json.dumps(build(),sort_keys=True,separators=(",",":")))
