"""Ring, graded-source, real-domain and quantum-target adversaries."""
import unittest
from copy import deepcopy
from hashlib import sha256
from a10_e5_coupling_ring import *
from audit_a10_e5_coupling_ring import adjudicate
from m08_local_functional_ast import field,tensor
from a10_executable_action import contract


class CouplingRing(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')

    def test_01_complete_independent_comparison(self):
        self.assertEqual(adjudicate(self.P,self.R)['scientific_gate'],STATUS)

    def test_02_literal_parameter_program(self):
        self.assertEqual(parameter_program(),self.P['physical_program'])
        self.assertEqual(len(self.P['physical_program']['literal_B_g_homogeneity']),34)

    def test_03_coupling_independent_curvature_has_typed_zero_variation(self):
        R=contract(mul(scalar(-s.Rational(1,2)),tensor('StructureConstant','f_Hmm',('h','a','b')),
                        field('C',indices=('a',),parity=1),field('C',indices=('b',),parity=1)),('a','b'))
        self.assertEqual(partial_g_ast(R),scalar(0))
        self.assertEqual(partial_g_ast(derivative('mu',R)),scalar(0))

    def test_04_closure_has_boundary_not_false_density_zero(self):
        c=self.P['closure'];self.assertEqual(c['source_master_density_coefficients'],5316)
        self.assertEqual(c['source_current_coefficients'],1772)
        self.assertFalse(c['source_residual']);self.assertFalse(c['EOM_used'])

    def test_05_weighted_named_class_uses_no_pole(self):
        w=self.P['weighted_family'];self.assertTrue(w['no_division_by_g'])
        self.assertIn('g F_beta = -2 L_YM - Q_beta K',w['full_identity'])
        self.assertFalse(w['all_intrinsic_basic_primitives_classified'])

    def test_06_source_left_dilation_has_different_field_signs(self):
        w=algebra();K=decode(self.P['weighted_family']['generator']);E=el(K,w,['JB0_0','JC0'],'replay')
        self.assertEqual(E['JB0_0'],w.scale(w.var('B0_0'),-1))
        self.assertEqual(E['JC0'],w.var('C0'))
        self.assertEqual(w.scale(E['JB0_0'],-1),w.var('B0_0'))

    def test_07_stationary_class_survives_with_source_Euler(self):
        w=algebra();P=decode(self.P['unrestricted_class']['pure_ghost_source_polynomial'])
        self.assertEqual(len(P),443)
        self.assertTrue(el(P,w,['JC13'],'replay')['JC13'])
        self.assertEqual(self.P['unrestricted_class']['stationary_source_columns_zero'],1286)

    def test_08_unrestricted_class_is_not_a_quantum_claim(self):
        u=self.P['unrestricted_class'];self.assertTrue(u['unrestricted_polynomial_nonexact_class'])
        self.assertEqual(u['horizontal_defect_coefficients'],230)
        self.assertFalse(u['quantum_Ward_admissibility_inferred'])

    def test_09_real_physical_norm_and_subspaces(self):
        r=self.P['real_controls'];Z=s.Matrix([s.sympify(v) for v in r['real_bracket']])
        self.assertEqual(clean((Z.T*Z)[0]),s.Rational(9,100))
        self.assertTrue(r['input_subspaces_verified'])
        self.assertTrue(all(s.im(v)==0 for v in Z))
        self.assertEqual(r['chosen_plane_seeds'],[0,1])

    def test_10_local_parameter_jets_expose_background_failure(self):
        v=self.P['Ward_target']['Euler_JB13_0_selected']
        self.assertEqual(v,[{'word':['C13','omega1__0'],'coefficient':'-sqrt(2)*I/2'}])
        self.assertFalse(self.P['Ward_target']['raw_tangent_background_Ward_admissible'])
        self.assertTrue(self.P['Ward_target']['constant_parameter_test_misses_defect'])

    def test_11_primitive_is_not_intrinsic_basic(self):
        w=algebra();register(w,'omega0',(0,0,0))
        P=decode(self.P['Ward_target']['primitive_background_defect'])
        self.assertEqual(el(P,w,['JB0_0'],'replay')['JB0_0'],w.scale(w.var('omega0',(0,)),-1))
        self.assertFalse(self.P['Ward_target']['primitive_intrinsic_basic'])

    def test_12_parameter_dependent_chart_correction_retained(self):
        t=self.P['source_tangent'];self.assertEqual(t['connection_Q_coefficients'],1484)
        self.assertTrue(t['nonminimal_connection_generator']);self.assertFalse(t['chart_connection_residual'])
        self.assertFalse(t['literal_derivatives_in_different_charts_identified_without_correction'])

    def test_13_no_inverse_physical_coupling_or_fitted_parameter(self):
        for row in self.P['source_tangent']['nonminimal_connection_generator']:
            c=s.sympify(row['coefficient'],locals={'g10':g})
            self.assertFalse(s.denom(c).has(g));self.assertFalse(c.has(s.Float))
        self.assertFalse(self.P['parameters_fitted']);self.assertFalse(self.P['inverse_physical_couplings_adopted'])

    def test_14_overclaim_rejected(self):
        for flag in ('quantum_target_missing_class_proved','general_full_basic_comparison_proved','full_E5_PASS'):
            bad=deepcopy(self.P);bad[flag]=True
            with self.assertRaises(AssertionError):adjudicate(bad,bad)

    def test_15_superseded_and_failed_runs_remain_excluded(self):
        for n in ('supersession.json','parameter_ast_recovery.json','schema_recovery.json'):
            r=read(OUT/n);self.assertFalse(r['counted_in_final_evidence'])
            for name,h in r['preserved_sha256'].items():self.assertEqual(sha256((OUT/name).read_bytes()).hexdigest(),h)
        r=read(OUT/'replay_attempt_1.json');self.assertEqual(r['exit_code'],1)
        self.assertFalse(r['counted_in_final_evidence'])
        self.assertIn("AssertionError: (('a', 'b'), ())",r['log'])
        r=read(OUT/'replay_attempt_2.json');self.assertEqual(r['exit_code'],1)
        self.assertFalse(r['counted_in_final_evidence']);self.assertIn("KeyError: 'architecture'",r['log'])

    def test_16_typed_parameters_and_actual_coset_preserved(self):
        r=self.P['real_controls'];self.assertEqual(r['parameter_grades'],{'sigma':[0,0,0],'sigmaDot':[1,0,0]})
        self.assertTrue(r['witness_grading_verified'])
        self.assertEqual(self.P['nonsymmetric_heavy_structure_coefficients_retained'],276)
        self.assertEqual(self.P['canonical_pairs_retained'],643)
        self.assertFalse(self.P['A1_A5_discharged'])


if __name__=='__main__':unittest.main()
