"""Complete selected graphs, exact UV/IR separation and first-failure controls."""
import unittest
from copy import deepcopy
from a10_e5_auxiliary_vertex import *
from audit_a10_e5_auxiliary_vertex import adjudicate,execution_matches,complete_graph_and_witness_check
from a10_e5_source_vertex import Green


def triangle_control(mixed=True,wrong_metric=False,wrong_odd_trace=False):
    w=elementary_model();k=[s.Integer(0),s.Integer(1),s.Integer(0),s.Integer(0)]
    p2=-s.Integer(1);G=elementary_Green(w,k,p2)
    P=w.add(*(w.scale(w.mul(w.D(w.var('barA'),mu),w.var(f'Bloop{mu}'),w.var('Cext')),
       1 if wrong_metric else ETA[mu]) for mu in range(4)))
    X=w.mul(w.var('Lloop'),w.var('barExt'),w.var('uB'))
    L=w.mul(w.var('LambdaExt'),w.var('barB'),w.var('uA'))
    V=[Fourier_vertex(Q,w,'primary',k,k,{}) for Q in (P,X,L)]
    if not mixed:
        for i in range(1,5):G[i][5]={};G[5][i]={}
    if wrong_odd_trace:w.p['uA']=0
    target=w.mul(w.var('LambdaExt'),w.var('barExt'),w.var('Cext'));word=next(iter(target))
    return clean(sum(s.I*trace(mp(mp(mp(mp(mp(G,A,w),G,w),B,w),G,w),C,w),w).get(word,0)/(6*target[word])
        for A,B,C in permutations(V)))


class AuxiliaryVertex(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.T=[mat(v) for v in cls.P['actual_group_tensors']['triangle_group_matrices']]
        cls.B=[mat(v) for v in cls.P['actual_group_tensors']['quartic_bubble_operator_group_matrices']]
        cls.D=[mat(v) for v in cls.P['comparison']['actual_minus_joint_candidate']]

    def test_01_routes_match_failure_evidence(self):
        a=adjudicate(self.P,self.R,False);self.assertEqual(a['scientific_gate'],STOP)
        self.assertFalse(a['joint_candidate_selected_cubic_matches'])

    def test_02_full_reference_and_two_ghost_labels(self):
        w=elementary_model();k=[s.Integer(2),s.Integer(1),s.Integer(0),s.Integer(0)];p2=s.Integer(3)
        G=elementary_Green(w,k,p2);old,k2=Green(model(),k,s.Symbol('Msource_squared',positive=True))
        for i in range(6):
            for j in range(6):self.assertEqual(canonical(G[i][j]),canonical(old[i][j]))
        for i in (6,8):self.assertEqual(G[i][i+1],{():s.Rational(1,3)});self.assertEqual(G[i+1][i],{():-s.Rational(1,3)})
        self.assertFalse(G[5][5]);self.assertTrue(G[1][5])

    def test_03_each_Born_word_has_its_exact_weight(self):
        details=self.P['elementary_loops']['primary_six_Born_word_details'];self.assertEqual(len(details),6)
        for text in details:self.assertEqual(s.cancel(s.sympify(text)-s.I/6),0)
        self.assertEqual(self.R['elementary_loops']['triangle_homogeneous_coefficient'],'I')
        self.assertEqual(self.R['elementary_loops']['bubble_homogeneous_coefficient'],'-I')

    def test_04_missing_mixed_propagation_removes_triangle(self):
        self.assertEqual(triangle_control(),s.I);self.assertEqual(triangle_control(mixed=False),0)

    def test_05_wrong_spatial_metric_changes_original_graph(self):
        self.assertEqual(triangle_control(wrong_metric=True),-s.I)
        self.assertNotEqual(triangle_control(wrong_metric=True),triangle_control())

    def test_06_wrong_odd_start_changes_graph(self):
        self.assertNotEqual(triangle_control(wrong_odd_trace=True),triangle_control())

    def test_07_external_derivative_triangle_not_a_false_zero_IR_integral(self):
        a=self.P['elementary_loops'];self.assertEqual(a['external_antighost_derivative_triangle_UV_degree'],-1)
        self.assertEqual(a['external_antighost_assignment_log_coefficient'],0)
        self.assertTrue(a['UV_Taylor_not_a_whole_zero_momentum_massless_integral'])
        self.assertFalse(self.P['UV_residue']['exceptional_scaleless_integral_used'])

    def test_08_vanishing_bosonic_triangle_checked_in_actual_frame(self):
        a=complete_graph_and_witness_check(self.P);self.assertEqual(a['literal_Lambda_BH_BM_coefficients_screened'],720)
        self.assertTrue(a['gauge_fixing_bosonic_triangle_zero_mixed_H_M_edge'])
        U,Ui,Cinv,EM,EH=chart('primary');self.assertEqual(cm(EH.T*EM),s.zeros(12,33))
        wrong=EM.copy();wrong[:,0]+=EH[:,0];self.assertNotEqual(cm(EH.T*wrong),s.zeros(12,33))

    def test_09_quartic_inventory_and_wrong_coupling_classes(self):
        a=read(OUT/'quartic_inventory_audit_preflight_v1/disposition.json')
        self.assertEqual(a['actual_literal_inventory'],{'(1, 1)':648,'(2, 0)':17480,'(2, 1)':418})
        self.assertFalse(a['counted_in_final_evidence']);self.assertFalse(a['scientific_pole_changed'])

    def test_10_omitting_quartic_changes_complete_pole(self):
        self.assertTrue(any(B.todok() for B in self.B))
        full=[cm(-2*(T+B)) for T,B in zip(self.T,self.B)]
        self.assertTrue(any(cm(P+2*T).todok() for P,T in zip(full,self.T)))

    def test_11_omitting_nonzero_triangle_changes_complete_pole(self):
        full=[cm(-2*(T+B)) for T,B in zip(self.T,self.B)]
        self.assertTrue(any(cm(P+2*B).todok() for P,B in zip(full,self.B)))
        self.assertEqual(sum(len(T.todok()) for T in self.T),600)

    def test_12_nonsymmetric_and_complete_quartic_retained(self):
        q=self.P['actual_group_tensors'];self.assertEqual(q['literal_quartic_coefficients'],648)
        self.assertEqual(q['physical_quartic_coefficients'],3096);self.assertTrue(q['nonsymmetric_heavy_tensor_retained'])
        self.assertTrue(q['physical_quartic'])

    def test_13_UV_residue_is_independent_of_IR_split(self):
        eps,R,mu=s.symbols('eps_uv R_uv mu_uv',positive=True)
        pole=mu**eps*R**(-eps)/(16*s.pi**2*eps)
        residue=s.limit(eps*pole,eps,0,dir='+');self.assertEqual(residue,1/(16*s.pi**2))
        self.assertEqual(s.diff(residue,R),0);self.assertEqual(s.diff(residue,mu),0)

    def test_14_heat_profiles_have_same_pole_not_same_finite_split(self):
        z=s.Symbol('z_uv',positive=True)
        tri=s.expint(1,6*z);bubble=s.expint(1,4*z)
        self.assertEqual(s.limit(-z*s.diff(tri,z),z,0,dir='+'),1)
        self.assertEqual(s.limit(-z*s.diff(bubble,z),z,0,dir='+'),1)
        self.assertEqual(s.simplify(s.limit(tri-bubble,z,0,dir='+')),s.log(s.Rational(2,3)))
        self.assertFalse(self.P['UV_residue']['complete_finite_IR_amplitude_calculated'])

    def test_15_all_tensor_slots_and_H_zeros_compared(self):
        a=self.P['comparison'];self.assertTrue(a['all49005_entries_compared'])
        self.assertEqual(sum(len(D.todok()) for D in self.D),888)
        for D in self.D:self.assertEqual(D[:,:12],s.zeros(33,12))

    def test_16_real_Euler_witness_cannot_be_boundary(self):
        w=physical_words();q=self.P['comparison']['exact_real_Euler_witness']
        self.assertEqual(q['coefficient_in_common_g_xi_squared_over_32pi2epsilon_units'],'8*sqrt(10)/25')
        P=w.scale(w.mul(w.var('Lp0'),w.var('barP1'),w.var('ghostP14')),8*s.sqrt(10)/25)
        self.assertEqual(canonical(w.EL(P,'Lp0')),canonical(w.scale(w.mul(w.var('barP1'),w.var('ghostP14')),8*s.sqrt(10)/25)))
        self.assertFalse(w.EL(w.D(w.mul(w.var('Lp0'),w.var('barP1')),0),'Lp0'))

    def test_17_simple_tensor_compression_is_explicitly_refuted(self):
        a=read(OUT/'simple_compression_negative_control.json');self.assertFalse(a['matches'])
        self.assertEqual(a['nonzero_residual_coefficients'],776);self.assertFalse(a['actual_pole_or_candidate_edited'])

    def test_18_earlier_qualifications_not_overturned_or_primitive_adopted(self):
        old=read(HERE/'frozen_a10_e5_joint_normalization/primary.json')
        self.assertTrue(old['selected_source_ghost_mixing_and_width_poles_jointly_match'])
        self.assertFalse(old['normalization']['candidate_adopted'])
        self.assertFalse(self.P['comparison']['additional_primitive_adopted'])
        self.assertFalse(self.P['comparison']['JC_CC_or_JB_BC_loops_executed'])

    def test_19_quantum_and_activation_overclaims_rejected(self):
        for key in ('complete_quantum_restoration_proved','all_contacts_or_quantum_A5_proved','full_E5_PASS','sources_activated','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b,False)

    def test_20_stale_fingerprint_and_changed_pole_rejected(self):
        fp=next(read(p)['fingerprint'] for p in OUT.glob('replay_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(fp);bad=deepcopy(fp);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        a=deepcopy(self.P);a['comparison']['actual_pole_matrices'][0]['entries'][0][2]='0'
        with self.assertRaises(AssertionError):adjudicate(a,self.R,False)


if __name__=='__main__':unittest.main()
