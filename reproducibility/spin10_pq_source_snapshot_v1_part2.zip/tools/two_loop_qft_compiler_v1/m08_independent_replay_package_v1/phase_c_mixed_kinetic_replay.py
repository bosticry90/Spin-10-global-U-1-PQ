"""Direct matrices, ordered words and Euler source replay for mixed kinetics."""
import itertools
import json
from hashlib import sha256
import sympy as s
from nonabelian_m08_semantic_replay import geometry,load
from interacting_actual_h_preflight_replay import GaugeWords,FailedIdentity

IDS=[0,1,3,4,11,12,13,19,38,44]; H=[0,1,3,4,11]
g=s.Symbol('g10'); ETA=(1,-1,-1,-1)


def build(stage=lambda n,fn:fn()):
    f,_,_=stage('physical_parent_mixed_geometry',geometry)
    rows=load('frozen_c3/C3_representation_basis.json')
    columns=[s.Matrix([sum(s.sympify(v['coefficient']) for v in r['raw_so10_coordinates'] if v['index']==i) for i in range(45)]) for r in rows['h_basis']+rows['heavy_basis']]
    G=s.Matrix.hstack(*(columns[i] for i in IDS)).T*s.Matrix.hstack(*(columns[i] for i in IDS))
    w=GaugeWords(0)
    w.fields={**{f'q{i}_{mu}':(1,0,0) for mu in range(4) for i in IDS},**{'C'+str(i):(1,1,1) for i in IDS}}
    w.pairs=[(n,'J'+n) for n in w.fields]
    w.grades={**w.fields,**{J:(3-w.fields[z][0],-1-w.fields[z][1],1-w.fields[z][2]) for z,J in w.pairs}}
    w.external={f'A{i}_{mu}':(1,0,0) for mu in range(4) for i in H}
    w.p={n:t[2] for n,t in (w.grades|w.external).items()}; x={n:w.var(n) for n in w.p}
    # Reconstruct through independent indexed multiplication, all heavy terms.
    B={(i,mu):w.add(x[f'q{i}_{mu}'],x.get(f'A{i}_{mu}',{})) for i in IDS for mu in range(4)}
    F={(i,mu,nu):w.add(w.D(B[i,nu],mu),w.scale(w.D(B[i,mu],nu),-1),*(w.scale(w.mul(B[j,mu],B[k,nu]),g*f.get((i,j,k),0)) for j,k in itertools.product(IDS,repeat=2))) for i in IDS for mu,nu in itertools.combinations(range(4),2)}
    S0=w.add(*(w.scale(w.mul(F[i,mu,nu],F[k,mu,nu]),-G[IDS.index(i),IDS.index(k)]*ETA[mu]*ETA[nu]/2) for mu,nu in itertools.combinations(range(4),2) for i,k in itertools.product(IDS,repeat=2) if G[IDS.index(i),IDS.index(k)]))
    forward={'C'+str(i):w.add(*(w.scale(w.mul(x['C'+str(j)],x['C'+str(k)]),-g*f.get((i,j,k),0)) for j,k in itertools.combinations(IDS,2))) for i in IDS}
    forward.update({f'q{i}_{mu}':w.add(w.D(x['C'+str(i)],mu),*(w.scale(w.mul(B[j,mu],x['C'+str(k)]),g*f.get((i,j,k),0)) for j,k in itertools.product(IDS,repeat=2))) for i in IDS for mu in range(4)})
    def zero(P,label):
        if P: raise FailedIdentity(label,P,w)
    def fields():
        for n in w.fields: zero(w.Q(forward[n],forward),'mixed_forward_square_'+n)
        for (i,mu,nu),P in F.items():
            target=w.add(*(w.scale(w.mul(F[j,mu,nu],x['C'+str(k)]),g*f.get((i,j,k),0)) for j,k in itertools.product(IDS,repeat=2)))
            zero(w.add(w.Q(P,forward),w.scale(target,-1)),'mixed_curvature_'+str(((mu,nu),i)))
        zero(w.Q(S0,forward),'mixed_physical_kinetic_invariance')
    stage('mixed_interacting_forward_and_kinetic',fields)
    S=w.add(S0,*(w.mul(x[J],forward[z]) for z,J in w.pairs))
    Q=stage('mixed_complete_Euler_source_columns',lambda:{n:w.EL(S,other) for pair in w.pairs for n,other in (pair,pair[::-1])})
    def sources():
        for n in w.grades: zero(w.Q(Q[n],Q),'mixed_full_square_'+n)
        for n in w.fields: zero(w.add(Q[n],w.scale(forward[n],-1)),'mixed_derived_forward_'+n)
    stage('mixed_source_nilpotence',sources)
    half=w.scale(w.bracket(S,S),s.Rational(1,2))
    currents=stage('mixed_master_current',lambda:w.current4(half))
    def summary(P):
        r=w.record(P); raw=json.dumps(r,sort_keys=True,separators=(',',':')).encode()
        return {'terms':len(r),'canonical_sha256':sha256(raw).hexdigest()}
    return {'schema':'PHASE_C_MIXED_KINETIC_GATE_V1','status':'PASS_CLOSED_MIXED_KINETIC_GATE_ONLY','ids':IDS,'pairs':50,'generators':100,'spacetime_directions':4,
        'kinetic':summary(S0),'master_action':summary(S),'images':{n:summary(P) for n,P in Q.items()},'half_master':summary(half),'explicit_currents':[summary(P) for P in currents],
        'counts':{'forward_squares':50,'curvature_covariance':60,'full_squares':100,'forward_recovery':50},
        'physical_gauge_interactions':{'cubic_and_quartic_retained':True,'non_symmetric_heavy_bracket_retained':True},
        'maximum_jet_order':w.max_jet,'EOM_used':False,'physical_scalar_or_gauge_fixing_tested':False,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    try: result=build(lambda n,fn:(print('STAGE '+n,flush=True),fn())[1])
    except FailedIdentity as e: result={'schema':'PHASE_C_MIXED_KINETIC_GATE_V1','status':'FAILED_FIRST_PREREQUISITE','witness':e.evidence,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
