"""Read-only new E5 route; exporters own persistence."""
import importlib,json,sys,time
from a10_e5_domain_common import Obstruction,ROOT


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==2 and sys.argv[1] in ('a10_e5_domain_primary','a10_e5_domain_replay')
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('E5_READ_ONLY_WRITE_DENIED')
    sys.addaudithook(hook)
    stages=[];started=time.perf_counter()
    def stage(name,fn):
        print('STAGE '+name,flush=True);t=time.perf_counter();value=fn()
        stages.append({'name':name,'seconds':time.perf_counter()-t});return value
    try:result=importlib.import_module(sys.argv[1]).build(stage)
    except Obstruction as error:result=error.evidence
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'wall_seconds':time.perf_counter()-started,'stages':stages,'write_attempts':writes},sort_keys=True),flush=True)


if __name__=='__main__':main()
