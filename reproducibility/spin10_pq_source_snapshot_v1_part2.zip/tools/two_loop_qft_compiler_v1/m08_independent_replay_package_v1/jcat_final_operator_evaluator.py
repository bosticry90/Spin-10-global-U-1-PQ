"""Exact addressed density representatives modulo IBP; no BRST differential."""
from jcat_packet_statistics import *
from int8_block_conjugation_v2 import address_key


class FinalOperators(QuotientRepresentations):
    @lru_cache(None)
    def class_data(self,cid):
        return load(OUT/(cid+'_final_operator_addresses.json'))

    @lru_cache(None)
    def orbit_data(self,cid):
        return load(OUT/(cid+'_IBP_orbit_addresses.json'))['orbits']

    @lru_cache(None)
    def singleton_sources(self,cid):
        return self.singleton_blocks(self.engine.groups[cid])

    @lru_cache(None)
    def singleton_transport(self,cid,hom,p):
        group=self.engine.groups[cid];th=tuple(hom[i] for i in p)
        src=self.singleton_sources(cid)[hom];dst=self.singleton_sources(cid)[th]
        lookup={self.engine.source_key(s):i for i,s in enumerate(dst)};values={}
        for j,s in enumerate(src):
            row=self.engine.engine.rows[s['signature_id']]
            degree,key=tup(row['raw_Lorentz_derivative_addresses'][s['jet_index']])
            image,phase=rename(key,p)
            ji=[tup(v) for v in row['raw_Lorentz_derivative_addresses']].index((degree,image))
            for a,c in self.engine.internal.image(s['address'],p):
                add(values,(lookup[(s['signature_id'],address_key(a),ji)],j),phase*c)
        return sp.ImmutableSparseMatrix(len(dst),len(src),values)

    def representative(self,cid,operator):
        """Return exact expansion source/coefficient pairs, with all provenance."""
        cls=self.class_data(cid);oi=operator['orbit_index'];o=self.orbit_data(cid)[oi]
        hom=tup(o['canonical_homogeneous_components']);group=self.engine.groups[cid]
        pattern=load(OUT/('JCAT11_PATTERN_'+cls['orbits'][oi]['statistics_pattern_id']+'.json'))
        b=matrix(pattern['canonical_allowed_local_basis'])[:,operator['local_basis_column']]
        result=[]
        for perm in o['coset_transport']:
            p=tup(perm);th=tuple(hom[i] for i in p)
            sign=stat_character(group['homogeneous_roles'],self.types,p)
            if group['trivial_singleton']:
                sources=self.singleton_sources(cid)[th];v=sign*self.singleton_transport(cid,hom,p)*b
            else:
                source=self.ibp(cid,hom);target=self.ibp(cid,th)
                quotient=matrix(target['quotient_map'])*self.engine.action(cid,hom,p)*matrix(source['section'])*b
                packet=sign*matrix(target['section'])*quotient
                primary=self.engine.primary(cid,th)
                v=matrix(primary['section'])*matrix(primary['canonical_packet_basis'])*packet
                sources=primary['sources']
            for i,c in enumerate(v):
                if c:result.append({'source':sources[i],'coefficient':str(c)})
        assert result,('ZERO_MATERIALIZED_FINAL_OPERATOR',cid,operator['operator_id'])
        return result
