"""JCAT8 full joint expansion actions, before IBP and final statistics.

Column convention: target slot j contains source slot perm[j]. Internal and
Lorentz relocation act together before the immutable realization quotient.
"""
from functools import lru_cache
from collections import defaultdict
import sympy as sp
from jcat_global_packets import (GlobalPackets, HERE, ROOT, OUT as PACKETS,
    load, canonical, AUTHORITY, serial, matrix, tup, combine, add,
    canonical_term, term_factors, coordinate_extraction)
from jcat_internal_permutations import InternalPermutation, stabilizer_elements
from jcat_physical_jets import rename, representation
from int8_block_conjugation_v2 import address_key

OUT = HERE/'frozen_jcat_packet_catalog'


class FrozenFactors:
    """Use qualified JCAT4 recoupling data without changing its basis."""
    def __init__(self, group, rows):
        self.rows={tup(r['labels']):r for r in rows if r['group']==group}

    def basis(self,labels):
        return (),[(tup(k),None) for k in self.rows[labels]['basis_keys']]

    def swap(self,labels,i):
        return matrix(self.rows[labels]['adjacent_transpositions'][i])


def generators(names):
    result=[]
    for name in dict.fromkeys(names):
        slots=[i for i,n in enumerate(names) if n==name];part=[]
        for i,j in zip(slots,slots[1:]):
            p=list(range(len(names)));p[i],p[j]=p[j],p[i];part.append(tuple(p))
        result.append(part)
    return result


class PacketPermutations:
    def __init__(self):
        self.engine=GlobalPackets();self.internal=InternalPermutation()
        rows=load(HERE/'frozen_jcat_lorentz_v2/JCAT4_factor_recoupling.json')['factor_blocks']
        self.internal.engines={g:FrozenFactors(g,rows) for g in ('SU3','SU2')}
        self.ledger=load(PACKETS/'JCAT7G_completeness_ledger.json')['rows']
        self.groups={r['class_id']:r for r in self.ledger}
        self.records={r['class_id']:{tup(b['homogeneous_components']):b
            for b in r.get('blocks',[])} for r in self.ledger}

    @lru_cache(None)
    def primary(self,cid,hom):
        return load(PACKETS/self.records[cid][hom]['primary'])

    @staticmethod
    def source_key(source):
        return source['signature_id'],address_key(source['address']),source['jet_index']

    def full_perm(self,sid,homperm):
        names=[r['field'] for r in self.engine.rows[sid]['ordered_occurrences']]
        slots=[i for i,n in enumerate(names) if n!='Abar_H_mu'];perm=list(range(len(names)))
        for i,j in enumerate(homperm):perm[slots[i]]=slots[j]
        assert [names[i] for i in perm]==names
        return tuple(perm)

    @lru_cache(None)
    def joint_expansion(self,cid,hom,perm):
        src=self.primary(cid,hom);th=tuple(hom[i] for i in perm);dst=self.primary(cid,th)
        lookup={self.source_key(s):i for i,s in enumerate(dst['sources'])};values={}
        for j,s in enumerate(src['sources']):
            row=self.engine.rows[s['signature_id']];full=self.full_perm(s['signature_id'],perm)
            degree,key=tup(row['raw_Lorentz_derivative_addresses'][s['jet_index']])
            transformed,phase=rename(key,full)
            if not phase:continue
            ji=[tup(v) for v in row['raw_Lorentz_derivative_addresses']].index((degree,transformed))
            for a,c in self.internal.image(s['address'],full):
                k=(s['signature_id'],address_key(a),ji)
                assert k in lookup,('JOINT_EXPANSION_LEAKAGE',cid,hom,perm,k)
                add(values,(lookup[k],j),phase*c)
        return sp.ImmutableSparseMatrix(len(dst['sources']),len(src['sources']),values)

    @lru_cache(None)
    def action(self,cid,hom,perm):
        src=self.primary(cid,hom);th=tuple(hom[i] for i in perm);dst=self.primary(cid,th)
        S=self.joint_expansion(cid,hom,perm)
        qs,qt=matrix(src['quotient_map']),matrix(dst['quotient_map'])
        ss=matrix(src['section']);ns=matrix(src['realization_null_basis'])
        ps,pt=matrix(src['canonical_packet_basis']),matrix(dst['canonical_packet_basis'])
        assert qt*S*ns==sp.zeros(qt.rows,ns.cols),('REALIZATION_DESCENT_FAILED',cid,hom,perm)
        pivots=list(pt.T.rref()[1])
        M=pt.extract(pivots,range(pt.cols)).inv()*(qt*S*ss*ps).extract(pivots,range(ps.cols))
        residual=qt*S*ss*ps-pt*M
        assert residual==sp.zeros(*residual.shape),('PACKET_PERMUTATION_LEAKAGE',cid,hom,perm,serial(residual))
        assert qt*S==qt*S*ss*qs
        return sp.ImmutableSparseMatrix(M)

    def path(self,cid,hom,word):
        current=hom;result=sp.eye(matrix(self.primary(cid,hom)['canonical_packet_basis']).cols)
        for perm in word:
            result=self.action(cid,current,perm)*result;current=tuple(current[i] for i in perm)
        return current,result

    def qualify(self,cid,hom):
        factors=generators(self.groups[cid]['homogeneous_roles'])
        n=matrix(self.primary(cid,hom)['canonical_packet_basis']).cols
        for factor in factors:
            for p in factor:assert self.path(cid,hom,[p,p])==(hom,sp.eye(n))
            for p,q in zip(factor,factor[1:]):assert self.path(cid,hom,[p,q,p])==self.path(cid,hom,[q,p,q])
            for i,p in enumerate(factor):
                for q in factor[i+2:]:assert self.path(cid,hom,[p,q])==self.path(cid,hom,[q,p])
        for i,factor in enumerate(factors):
            for other in factors[i+1:]:
                for p in factor:
                    for q in other:assert self.path(cid,hom,[p,q])==self.path(cid,hom,[q,p])
        return {'class_id':cid,'homogeneous_components':hom,'packet_dimension':n,
            'actions':[{'permutation':p,'target_homogeneous_components':tuple(hom[i] for i in p),
                'matrix':serial(self.action(cid,hom,p))} for f in factors for p in f],
            'joint_expansion_quotient_packet_diagram':'ZERO_EXACT',
            'realization_null_descent':'ZERO_EXACT','Coxeter_residual':'ZERO_EXACT'}

    def physical_replay(self,cid,hom,perm):
        """Independent colored-polynomial solve without importing primary S."""
        src=self.primary(cid,hom);th=tuple(hom[i] for i in perm);dst=self.primary(cid,th)
        def columns(record):
            E=[self.engine.source_polynomial(s) for s in record['sources']]
            P=matrix(record['section'])*matrix(record['canonical_packet_basis'])
            return [combine(E,P[:,j]) for j in range(P.cols)]
        source=columns(src);target=columns(dst);inverse={old:new for new,old in enumerate(perm)}
        transformed=[]
        for polynomial in source:
            result={}
            for key,v in polynomial.items():
                fs,parity,contraction=term_factors(key)
                fs=tuple(('H'+str(inverse[int(tag[1:])]) if tag.startswith('H') else tag,
                    color,vector,ds) for tag,color,vector,ds in fs)
                k,phase=canonical_term(fs,parity,contraction)
                if phase:add(result,k,phase*v)
            transformed.append(result)
        return coordinate_extraction(target,transformed)

    @lru_cache(None)
    def conjugation(self,cid,hom):
        src=self.primary(cid,hom);blocks={};cat=self.engine.catalog
        for j,s in enumerate(src['sources']):
            for a,c in cat.image(s['address']):
                slots,copies=cat.address_parts(a)[2:4]
                th=tuple((slots[i],copies[i]) for i in range(len(slots)) if i not in s['background_slots'])
                dst=self.primary(cid,th)
                if th not in blocks:blocks[th]=sp.zeros(len(dst['sources']),len(src['sources']))
                k=self.source_key(dict(s,address=a))
                lookup={self.source_key(t):i for i,t in enumerate(dst['sources'])}
                blocks[th][lookup[k],j]+=c
        result={}
        P=matrix(src['section'])*matrix(src['canonical_packet_basis'])
        N=matrix(src['realization_null_basis'])
        for th,C in blocks.items():
            dst=self.primary(cid,th);q=matrix(dst['quotient_map']);pt=matrix(dst['canonical_packet_basis'])
            assert q*C*sp.conjugate(N)==sp.zeros(q.rows,N.cols)
            pivots=list(pt.T.rref()[1]);target=q*C*sp.conjugate(P)
            B=pt.extract(pivots,range(pt.cols)).inv()*target.extract(pivots,range(target.cols))
            assert target==pt*B,('PACKET_CONJUGATION_LEAKAGE',cid,hom,th)
            result[th]=B
        return result

    def conjugation_check(self,cid,hom):
        n=matrix(self.primary(cid,hom)['canonical_packet_basis']).cols
        twice={}
        for th,B in self.conjugation(cid,hom).items():
            for uh,D in self.conjugation(cid,th).items():
                twice[uh]=twice.get(uh,sp.zeros(D.rows,n))+D*sp.conjugate(B)
        for uh,M in twice.items():assert M==(sp.eye(n) if uh==hom else sp.zeros(*M.shape))
        for factor in generators(self.groups[cid]['homogeneous_roles']):
            for p in factor:
                ph=tuple(hom[i] for i in p);A=self.action(cid,hom,p)
                left={th:B*sp.conjugate(A) for th,B in self.conjugation(cid,ph).items()}
                right={}
                for th,B in self.conjugation(cid,hom).items():
                    uh=tuple(th[i] for i in p);term=self.action(cid,th,p)*B
                    right[uh]=right.get(uh,sp.zeros(*term.shape))+term
                for th in set(left)|set(right):
                    assert left.get(th,sp.zeros(*right[th].shape) if th in right else 0)==right.get(th,sp.zeros(*left[th].shape)),('PACKET_CONJUGATION_PERMUTATION_DIAGRAM',cid,hom,p)
        return {'homogeneous_components':hom,'conjugation_blocks':[
            {'target_homogeneous_components':th,'matrix':serial(B)} for th,B in self.conjugation(cid,hom).items()],
            'antilinear_involution':'ZERO_EXACT','permutation_conjugation_diagram':'ZERO_EXACT',
            'realization_null_descent':'ZERO_EXACT','packet_conjugation_closure':'ZERO_EXACT'}


def factor_conjugation_check(engine):
    cat=engine.engine.catalog
    pairings=load(HERE/'frozen_int8_block_conjugation_v2/INT8V2_binary_terminal_maps.json')['pairings']
    phases={(r['group'],tup(r['source'])):sp.sympify(r['terminal_phase']) for r in pairings}
    records=[]
    for group,fac in engine.internal.engines.items():
        dual=lambda r:(r[1],r[0]) if group=='SU3' else r
        L=cat.l3 if group=='SU3' else cat.l2
        @lru_cache(None)
        def B(labels):
            keys=[k for k,_ in fac.basis(labels)[1]];target=tuple(dual(r) for r in labels)
            tkeys=[k for k,_ in fac.basis(target)[1]];values={}
            for j,(o,a,b) in enumerate(keys):
                left=L[(labels[0],labels[1],o)]
                right=L[(labels[2],labels[3],dual(o))] if len(labels)==4 else sp.ones(1,1)
                phase=phases[(group,o)] if len(labels)>=3 else 1
                for aa in range(left.rows):
                    for bb in range(right.rows):
                        v=phase*left[aa,a]*right[bb,b]
                        if v:values[tkeys.index((dual(o),aa,bb)),j]=v
            return sp.ImmutableSparseMatrix(len(tkeys),len(keys),values)
        for labels,row in fac.rows.items():
            K=B(labels)
            for i in range(len(labels)-1):
                target=list(labels);target[i],target[i+1]=target[i+1],target[i];target=tuple(target)
                dlabels=tuple(dual(r) for r in labels)
                assert B(target)*sp.conjugate(fac.swap(labels,i))==fac.swap(dlabels,i)*K,(group,labels,i,'CONJUGATION_DIAGRAM')
            records.append({'group':group,'labels':labels,'dimension':K.rows,'conjugation':serial(K),
                'adjacent_transposition_conjugation_diagrams':'ZERO_EXACT'})
    return {'factor_blocks':records,'status':'PASS_ALL_FROZEN_RECOUPLING_CONJUGATION_DIAGRAMS',
        'copy_factor':'Ordinary same-species slot relocation intertwines tensor-product W factors exactly; no copy phase convention is changed',
        'Lorentz_factor':'Real metric/epsilon contraction coefficients commute with anti-linear conjugation'}


def singleton_check(engine,group):
    row=engine.engine.rows[group['members'][0]['signature_id']]
    names=tuple(r['field'] for r in row['ordered_occurrences']);js=group['members'][0]['jet_indices']
    keys=[tup(row['raw_Lorentz_derivative_addresses'][j]) for j in js]
    gs=generators(names);mats={p:representation(keys,p) for f in gs for p in f}
    for f in gs:
        for p in f:assert mats[p]*mats[p]==sp.eye(len(keys))
        for p,q in zip(f,f[1:]):assert mats[p]*mats[q]*mats[p]==mats[q]*mats[p]*mats[q]
        for i,p in enumerate(f):
            for q in f[i+2:]:assert mats[p]*mats[q]==mats[q]*mats[p]
    for i,f in enumerate(gs):
        for g in gs[i+1:]:
            for p in f:
                for q in g:assert mats[p]*mats[q]==mats[q]*mats[p]
    return {'class_id':group['class_id'],'packet_dimension':group['PRIMARY_REALIZED_PACKET_RANK'],
        'internal_family':row['internal_family'],'jet_indices':js,
        'jet_actions':[{'permutation':p,'matrix':serial(mats[p])} for p in mats],
        'joint_action':'Qualified JCAT4 address action tensor exact Lorentz relocation',
        'realization_quotient':'IDENTITY','packet_embedding':'IDENTITY',
        'Coxeter_residual':'ZERO_EXACT_BY_FACTORS','component_reconstruction':'ZERO_EXACT_BY_FACTORS'}
