"""Guarded read-only E2 evidence routes; no workspace writes permitted."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_phase_c_scalar_action

def main():
    import importlib,json,os,time
    from profile_pole_blind_workflow import process_counters
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    route=sys.argv[1];assert route in ('a10_e2_transport_primary','a10_e2_transport_replay','a10_e2_transport_checks')
    reads=set();writes=[]
    def hook(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)):return
        mode=args[1] or '';flags=args[2] if len(args)>2 else 0
        if any(c in mode for c in 'wax+') or flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
            writes.append(str(args[0]));raise PermissionError('E2_ROUTE_WRITES_FORBIDDEN')
        reads.add(str(Path(os.fsdecode(args[0])).resolve()))
    sys.addaudithook(hook);first=process_counters();start=time.perf_counter();stages=[]
    def stage(name,fn):
        print('STAGE '+name,flush=True);t=time.perf_counter()
        try:return fn()
        finally:stages.append({'name':name,'wall_seconds':time.perf_counter()-t})
    result=stage('module_import',lambda:importlib.import_module(route)).build(stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    last=process_counters()
    print('METRICS '+json.dumps({'route':route,'stages':stages,'wall_seconds':time.perf_counter()-start,
      'cpu_seconds':last['cpu_seconds']-first['cpu_seconds'],'peak_process_working_set_bytes':last['peak_working_set_bytes'],
      'read_paths':sorted(reads),'write_open_attempts':writes,'workspace_files_written':0,
      'limits':'distinct transport and differentiation routes, shared Python/SymPy, word arithmetic, assumptions and analyst; no external endorsement'},sort_keys=True,separators=(',',':')),flush=True)
if __name__=='__main__':main()
