"""Bounded canonical transport, physical-source and derivative-kernel regressions."""
import unittest
from a10_e2_transport_common import *
from audit_a10_e2_transport import adjudicate

class E2TransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
        cls.c=read(OUT/'checks.json');cls.w=alphabet()
        cls.old=read(HERE/'frozen_a10_bv_integration/M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json')
    def test_all_canonical_shift_coefficients_and_zero_slots(self):
        a=adjudicate(self.p,self.r)
        self.assertEqual(a['source_shift_coefficients_compared'],4396)
        self.assertEqual(a['nonzero_source_shifts'],503)
        self.assertEqual(set(self.p['source_shifts']),{J for z,J in self.w.pairs})
    def test_sign_is_derived_from_bracket_and_odd_parity(self):
        self.assertTrue(self.p['canonical_map']['generator_signs_derived'])
        e=read(HERE/'frozen_a10_e1_fermion/primary.json')['Euler_columns']
        for z,J in self.w.pairs:
            expected=canonical(self.w.scale(decode_typed(e[z]),-(-1)**self.w.p[z]))
            self.assertEqual(decode_typed(self.p['source_shifts'][J]),expected)
    def test_inverse_on_all_fields_and_sources_in_both_directions(self):
        self.assertEqual(self.p['canonical_map']['inverse_generator_checks'],2572)
        self.assertFalse(self.p['canonical_map']['EOM_used'])
    def test_full_smeared_Hessian_identity_and_boundary(self):
        c=self.p['canonical_map'];self.assertEqual(c,self.r['canonical_map'])
        self.assertEqual(len(c['smeared_cross_density']),752)
        self.assertEqual(sum(map(len,c['smeared_boundary_current'])),376)
        self.assertEqual(c['smeared_cross_minus_divergence'],[])
    def test_derivative_kernel_is_not_tested_by_bare_coordinate_bracket(self):
        self.assertTrue(self.c['bare_derivative_coordinate_bracket_misses_failure'])
        self.assertTrue(self.c['omitted_derivative_shift_smeared_bracket'])
        self.assertTrue(self.c['omitted_derivative_shift_Euler_test'])
    def test_uniform_ungraded_shift_fails_exact_auxiliary_pairing(self):
        self.assertEqual(decode_typed(self.c['wrong_ungraded_shift_source_bracket']),{():xi/5})
    def test_all_original_action_terms_and_physical_parameters_preserved(self):
        v=read(OUT/(NAME+'.json'));self.assertEqual(v,candidate(self.p))
        for key in ('local_terms','parameters','architecture','bound_constant_C3_to_plane',
          'physical_origin_sha256','physical_tensor_aliases'):
            self.assertEqual(v[key],self.old[key])
        self.assertEqual(v['unchanged_local_terms'],43)
        self.assertEqual(self.p['route_evidence']['physical_terms_preserved'],34)
        self.assertEqual(self.p['route_evidence']['source_terms_executed'],9)
        self.assertEqual(v['new_physical_parameters'],[])
    def test_direct_source_AST_and_independent_fermion_gradient_agree(self):
        self.assertEqual(len(self.p['gauge_fixing_density']),33092)
        self.assertEqual(self.p['gauge_fixing_density'],self.r['gauge_fixing_density'])
        self.assertEqual(self.p['route_evidence']['transformed_source_polynomial_sha256'],
          self.r['route_evidence']['transformed_source_polynomial_sha256'])
        self.assertFalse(self.r['route_evidence']['primary_outputs_imported'])
    def test_local_action_density_retains_positive_boundary_divergence(self):
        self.assertEqual(self.p['action_density_boundary'],self.r['action_density_boundary'])
        self.assertEqual(sum(map(len,self.p['action_density_boundary'])),3668)
        self.assertIn('Delta=Q Psi+div L',self.p['route_evidence']['action_boundary_identity'])
    def test_all_variational_source_corrections_and_conjugate_columns(self):
        self.assertEqual(len(self.p['source_column_corrections']),643)
        self.assertEqual(sum(map(len,self.p['source_column_corrections'].values())),108243)
        self.assertEqual(self.p['route_evidence']['exact_column_conjugacy_checks'],1286)
    def test_full_columns_and_all_508_physical_Euler_programs(self):
        self.assertEqual(len(self.p['complete_columns']),1286)
        self.assertEqual(sum(len(v['source_polynomial']) for v in self.p['complete_columns'].values()),214340)
        old=read(HERE/'frozen_a10_bv_integration/primary.json')
        self.assertEqual(self.p['physical_Euler_program'],old['physical_Euler_program'])
        self.assertEqual(sum(v['physical_program'] is not None for v in self.p['complete_columns'].values()),508)
    def test_field_transformations_and_composite_curvature_are_unchanged(self):
        _,columns=source_data('primary')
        for z in self.w.fields:
            self.assertEqual(decode_typed(self.p['complete_columns'][z]['source_polynomial']),canonical(columns[z]))
        self.assertTrue(any(r['word'] for r in self.p['complete_columns']['C0']['source_polynomial']))
    def test_complete_new_master_density_and_current_compare_exactly(self):
        m=self.p['master'];self.assertEqual(m,self.r['master'])
        self.assertEqual(len(m['new_source_degree_zero_density']),88180)
        self.assertEqual(sum(map(len,m['new_boundary_current'])),23984)
        self.assertEqual(m['new_density_minus_divergence'],[])
        self.assertFalse(m['EOM_used'])
    def test_master_source_degree_decomposition_preserves_physical_certificate(self):
        m=self.p['master']
        self.assertIn('all 45 Noether',m['source_degree_zero_physical'])
        self.assertIn('2 div(J_B QC)',m['source_degree_one'])
        self.assertIn('source free',m['higher_source_degrees'])
        self.assertTrue(m['physical_Euler_program_unchanged'])
    def test_source_and_jet_nilpotence_is_structural_not_full_square_enumeration(self):
        self.assertTrue(self.p['full_source_nilpotence_established'])
        self.assertFalse(self.p['nilpotence']['exhaustively_expanded_full_source_squares'])
        self.assertEqual(self.c['field_source_first_jet_transport_checks'],80)
        self.assertTrue(self.c['jet_resource_cap_raises'])
    def test_distinct_exterior_physical_source_and_second_jet_control(self):
        c=self.c['exterior_control'];self.assertEqual(c['canonical_pairs'],20)
        self.assertEqual(c['generator_columns'],40);self.assertEqual(c['all_column_conjugacy_checks'],40)
        self.assertEqual(c['base_and_order_two_jet_squares'],240)
        self.assertEqual(c['master_minus_divergence'],[])
        self.assertTrue(c['missing_antighost_source_column_obstruction'])
        self.assertFalse(c['EOM_used'] or c['control_parameters_are_candidate_physical_parameters'])
    def test_real_structure_grading_and_retained_quartic_terms(self):
        self.assertTrue(self.c['all_643_source_shifts_real_structure_verified'])
        self.assertTrue(self.c['complete_gauge_fixing_real_structure_verified'])
        for z,J in self.w.pairs:
            d,gh,p=self.w.grades[J]
            for word in decode_typed(self.p['source_shifts'][J]):
                self.assertEqual(sum((self.w.grades|self.w.external)[n][1] for n,jets in word),gh)
                self.assertEqual(sum(self.w.p[n] for n,jets in word)%2,p)
        self.assertGreater(self.c['quartic_ghost_monomials_retained'],0)
        self.assertFalse(self.c['E4_quartic_reconciliation_qualified'])
    def test_transporting_sources_without_inverse_map_derivative_fails(self):
        self.assertTrue(self.c['partial_source_transport_Jb0_square'])
    def test_backgrounds_stay_external_and_historical_equivalence_unproved(self):
        self.assertEqual(self.p['external_background_components'],48)
        self.assertEqual(self.p['background_canonical_pairs'],0)
        self.assertTrue(self.p['contract']['quantum_background_held_fixed'])
        self.assertFalse(self.p['historical_equivalence_proved'] or self.p['physical_gauge_independence_established'])
    def test_false_promotions_and_tampered_coefficient_are_rejected(self):
        self.assertEqual(len(self.c['false_promotion_flags_rejected']),11)
        self.assertTrue(self.c['changed_action_coefficient_rejected'])
        for key in self.c['false_promotion_flags_rejected']:
            p,r=dict(self.p),dict(self.r);p[key]=r[key]=True
            with self.assertRaises(AssertionError):adjudicate(p,r)
        self.assertEqual(self.p['formal_authority'],'34/39_UNCHANGED')
        self.assertTrue(self.p['inactive'])

if __name__=='__main__':unittest.main()
