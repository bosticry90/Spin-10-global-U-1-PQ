"""Actual companions, paired sources, primitive ambiguity and authority controls."""
import unittest
from copy import deepcopy
from a10_e5_joint_normalization import *
from audit_a10_e5_joint_normalization import adjudicate,execution_matches,direct_pairing_and_width_checks


class JointNormalization(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.w=alphabet();cls.n=cls.P['normalization'];cls.A=mat(cls.n['primitive_required_symmetric_matrix'])

    def test_01_routes_match_complete_inactive_image(self):
        a=adjudicate(self.P,self.R,False);self.assertTrue(a['selected_poles_and_complete_inactive_image_qualified'])
        self.assertFalse(a['complete_quantum_restoration_proved'])

    def test_02_mixing_bubble_all_Lorentz_outputs(self):
        q=s.symbols('q0_jn:4',real=True);K,R=s.symbols('K_squared R_squared',nonzero=True)
        loc={str(v):v for v in (*q,K,R)}
        for mu,text in enumerate(self.P['mixed_loop']['Born_or_Gaussian_symmetrized_numerators']):
            self.assertEqual(s.cancel(s.sympify(text,locals=loc)+ETA[mu]*q[mu]/(2*K*R)),0)
        self.assertFalse(self.P['mixed_loop']['zero_external_momentum_used'])

    def test_03_wrong_spatial_metric_changes_mixing(self):
        w=model();register(w,'BExt',(1,0,0));register(w,'LambdaExt',(2,0,0))
        k=list(s.symbols('k0_jn:4',real=True));q=list(s.symbols('q0_jn:4',real=True));r=[a+b for a,b in zip(k,q)]
        K,R=s.symbols('K_squared R_squared',nonzero=True)
        # Deliberately lose the spatial metric at the original contraction.
        PB=w.mul(w.D(w.var('ubLoop'),1),w.var('BExt'),w.var('uLoop'))
        PL=w.mul(w.var('LambdaExt'),w.var('ubLoop'),w.var('uLoop'))
        VB=Fourier_vertex(PB,w,'primary',k,r,{'BExt':[-v for v in q]})
        VL=Fourier_vertex(PL,w,'primary',r,k,{'LambdaExt':q})
        pol=trace(mp(mp(mp(Green_abbreviated(w,k,K),VB,w),Green_abbreviated(w,r,R),w),VL,w),w)
        word=next(iter(w.mul(w.var('BExt'),w.var('LambdaExt'))))
        wrong=clean(-s.I*pol[word]/2)
        self.assertEqual(s.cancel(wrong+q[1]/(2*K*R)),0)
        self.assertNotEqual(wrong,q[1]/(2*K*R))
        self.assertTrue(self.P['literal_vertices_and_width']['all_four_literal_Lorentz_copies_equal'])

    def test_04_complete_H_and_heavy_trace_groups(self):
        v=self.P['literal_vertices_and_width'];B=mat(v['mixed_gauge_auxiliary_trace_group'])
        k=mat(read(HERE/'frozen_a10_e5_source_vertex/primary.json')['actual_internal_group']['kappa_physical'])
        self.assertEqual(B,s.Matrix.vstack(s.zeros(12,33),-k))
        self.assertEqual(mat(v['extra_derivative_trace_group']),s.zeros(45,33))

    def test_05_derivative_placements_are_not_omitted(self):
        v=self.P['literal_vertices_and_width'];self.assertEqual(v['literal_derivative_counts'],{'antighost':1824,'ghost':720})
        self.assertEqual(len(v['physical_antighost_derivative_vertices']),45)
        # The extra H derivative vertices are nonzero before their trace.
        self.assertTrue(any(mat(B).todok() for B in v['physical_ghost_derivative_vertices'][:12]))

    def test_06_actual_width_orders_not_inferred_from_normalization(self):
        v=self.P['literal_vertices_and_width'];self.assertEqual(v['Lambda_cubic_orders'],{'(1, 0)':720,'(0, 1)':276})
        self.assertEqual(v['two_Lambda_quartic_vertices'],0)
        self.assertEqual(mat(v['order_g_xi_squared_width_log_matrix']),s.zeros(33))
        self.assertIn('xi^2 Lambda',v['qualified_order_xi_squared_width_pole_reused'])

    def test_07_leg_count_blocks_false_three_cubic_two_point_graph(self):
        # E_internal=V at one loop and n_external=sum(deg-2).
        self.assertEqual(sum(d-2 for d in (3,3)),2)
        self.assertEqual(sum(d-2 for d in (4,)),2)
        self.assertNotEqual(sum(d-2 for d in (3,3,3)),2)

    def test_08_omitting_primitive_leaves_exact_width_Euler(self):
        w=alphabet();P=decode_typed(self.n['source_linear_width_image_normalized'])
        self.assertTrue(P);E=canonical(w.EL(P,'L12'))
        self.assertTrue(E);self.assertEqual(quadratic_matrix(P),self.A)
        # A boundary term has zero Euler derivative, unlike this width image.
        boundary=w.D(w.mul(w.var('L12'),w.var('L13')),0)
        self.assertFalse(w.EL(boundary,'L12'))

    def test_09_primitive_equation_by_direct_variation(self):
        w=alphabet();Psi=decode_typed(self.n['derived_width_primitive'])
        Q0={f'ub{i}':w.scale(w.var(f'L{i}'),-1) for i in M}
        actual=canonical(w.act(Psi,Q0,1))
        expected=w.add(*(w.scale(w.mul(w.var(f'L{12+i}'),w.var(f'L{12+j}')),-g*xi**2*c) for (i,j),c in self.A.todok().items()))
        self.assertEqual(actual,canonical(expected));self.assertTrue(actual)

    def test_10_primitive_wrong_sign_fails_width_equation(self):
        w=alphabet();lin=decode_typed(self.n['source_linear_width_image_normalized'])
        Q0={f'ub{i}':w.scale(w.var(f'L{i}'),-1) for i in M}
        Psi=decode_typed(self.n['derived_width_primitive'])
        wrong=w.scale(w.act(Psi,Q0,1),-1)
        self.assertTrue(canonical(w.add(w.scale(lin,g*xi**2),wrong)))

    def test_11_antisymmetric_primitive_kernel_is_real(self):
        w=alphabet();K=w.add(w.mul(w.var('ub12'),w.var('L13')),w.scale(w.mul(w.var('ub13'),w.var('L12')),-1))
        Q0={f'ub{i}':w.scale(w.var(f'L{i}'),-1) for i in M}
        self.assertTrue(K);self.assertFalse(w.act(K,Q0,1))
        self.assertTrue(self.n['antisymmetric_primitive_kernel_not_claimed_unique'])

    def test_12_correct_Gram_bridge_and_physical_pullback(self):
        Q,QM,FM,GM,GI,EM,EH,PM=input_chart('primary');U=cm(EM.T*QM);Ui=cm(GI*QM.T*EM)
        old=read(HERE/'frozen_a10_e5_source_vertex/primary.json')['actual_internal_group']
        N=mat(old['ghost_endomorphism_C3'])[12:,12:];k=mat(old['kappa_physical'])
        self.assertEqual(cm(self.A*GM),N);self.assertEqual(cm(U*self.A*U.T),k)
        self.assertNotEqual(self.A,N)

    def test_13_direct_graded_pairings_and_width_check(self):
        a=direct_pairing_and_width_checks(self.P);self.assertEqual(a['direct_graded_source_source_cross_pairings'],1089)
        self.assertTrue(a['direct_Q0_width_primitive_matches'])

    def test_14_wrong_source_shift_sign_breaks_cross_pairing(self):
        w=alphabet();Psi=decode_typed(self.n['derived_width_primitive'])
        left=partials(Psi,w,{'ub12','L12'});correct_left=w.scale(left['ub12',()],-1);correct_right=left['L12',()]
        a=partials(correct_left,w,{'L12'}).get(('L12',()),{})
        b=partials(correct_right,w,{'ub12'}).get(('ub12',()),{})
        self.assertFalse(w.add(a,b));self.assertTrue(w.add(a,w.scale(b,-1)))

    def test_15_complete_polynomial_generator_has_no_inverse_coupling(self):
        w=alphabet();K=decode_typed(self.n['complete_generator'])
        self.assertEqual(len(K),132);self.assertTrue(w.grade(K,(3,-1,1)))
        for c in K.values():
            poly=s.Poly(c,g,xi);self.assertTrue(all(a>=1 and b>=1 for a,b in poly.monoms()))
            self.assertEqual(c.subs(g,0),0)

    def test_16_candidate_and_current_coverage_are_explicit(self):
        self.assertEqual(self.n['complete_candidate_coefficients'],47958)
        self.assertEqual(self.n['boundary_divergence_coefficients'],8160)
        self.assertEqual(self.n['mixed_projection_coefficients'],132)
        self.assertTrue(self.n['all1286_canonical_generator_columns_checked'])
        self.assertFalse(self.n['first_variation_residual'])
        self.assertTrue(self.n['ghost_kinetic_projection_zero']);self.assertTrue(self.n['order_g_xi_squared_width_projection_zero'])
        # Dropping the density current would give a different local image.
        self.assertNotEqual(self.n['complete_Q_image'],self.n['complete_normalization_candidate'])

    def test_17_earlier_source_success_and_failure_preserved(self):
        self.assertTrue(self.n['old_gauge_scalar_source_projections_preserved'])
        old=read(HERE/'frozen_a10_e5_ghost_companion/primary.json')
        self.assertFalse(old['normalization_verdict']['ghost_only_canonical_normalization_sufficient'])
        self.assertEqual(old['kinetic_log_coefficient'],0)

    def test_18_measure_not_canceled_by_external_sources(self):
        a=self.P['transport'];self.assertEqual(a['carrier_trace'],132)
        self.assertTrue(a['ghost_and_antighost_traces_cancel_auxiliary_trace_retained'])
        self.assertTrue(a['background_heat_trace_not_replaced_by_constant'])
        self.assertTrue(a['source_free_primitive_shifts_only_external_sources']);self.assertFalse(a['full_quantum_A5_proved'])

    def test_19_complete_quantum_overclaims_rejected(self):
        for key in ('finite_complete_restoration_proved','all_Ward_Slavnov_contacts_restored','full_quantum_A5_proved','full_E5_PASS','sources_activated','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b,False)

    def test_20_stale_execution_and_mutated_candidate_rejected(self):
        fp=next(read(p)['fingerprint'] for p in OUT.glob('replay_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(fp);bad=deepcopy(fp);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        a=deepcopy(self.P);a['normalization']['complete_normalization_candidate'][0]['coefficient']='0'
        with self.assertRaises(AssertionError):adjudicate(a,self.R,False)


if __name__=='__main__':unittest.main()
