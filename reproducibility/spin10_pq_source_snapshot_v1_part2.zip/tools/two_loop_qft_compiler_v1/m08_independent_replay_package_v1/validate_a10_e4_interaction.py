"""Read-only validation transaction for E4 and compatible process improvements."""
from a10_e4_interaction_common import *
from validate_interacting_actual_h_preflight import inventory,bound_hashes
from a10_e1_fermion_common import HISTORICAL
import os,sys,subprocess,json,time,re


def run_captured(args,cwd,env,timeout=None):
    """communicate drains both pipes; verbose stderr must not block stdout."""
    return subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,
        encoding='utf-8',errors='replace',timeout=timeout)


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    from seal_a10_e4_interaction import files
    bounded=files(include_receipt=False);state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    before=inventory();inherited=bound_hashes();start=time.perf_counter();records=[]
    history={n:sha256((HERE/n).read_bytes()).hexdigest() for n in HISTORICAL}
    hashes={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in bounded}
    tests=['test_a10_e4_interaction','test_a10_e3_symmetry','test_a10_e2_transport',
        'test_a10_e1_fermion','test_a10_stage_e','test_a10_bv_integration','test_a10_gauge_euler',
        'test_a10_bv','test_a10_cotangent','test_a10_executable','test_a10_physical_reconciliation',
        'test_phase_c_scalar_action']
    tasks=[('authenticate_twelve_predecessor_chains',[str(HERE/'audit_a10_e4_interaction.py')],ROOT,0),
        ('session_preflight',['tools/research_session_preflight.py'],ROOT,0),
        ('scientific_regressions',['-m','unittest',*tests,'-v'],HERE,0),
        ('process_regressions',['-m','unittest','discover','-s','tools','-p','test_research_*.py','-v'],ROOT,0),
        ('fresh_E4_routes',[str(HERE/'audit_a10_e4_interaction.py'),'--fresh'],ROOT,0),
        ('governance',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT,0),
        ('authority',['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'],ROOT,0),
        ('structure_preserving_map',['tools/readiness/audit_structure_preserving_map_contract.py'],ROOT,0),
        ('read_only_contract',['tools/readiness/audit_read_only_contract.py'],ROOT,0),
        ('historical_custody',['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'],ROOT,2)]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name,args,cwd,expected in tasks:
        print('START '+name,flush=True);t=time.perf_counter()
        if name=='fresh_E4_routes':
            # Merge the child streams while forwarding bounded stage updates.
            # The fresh auditor has no unittest count to extract from stderr.
            p=subprocess.Popen([sys.executable,'-B',*args],cwd=cwd,env=env,
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
            output=[]
            for line in p.stdout:
                output.append(line)
                if not line.startswith('AUDIT '):print(line,end='',flush=True)
            code=p.wait();error='';stdout=''.join(output)
        else:
            p=run_captured([sys.executable,'-B',*args],cwd,env)
            code=p.returncode;stdout=p.stdout;error=p.stderr
        row={'name':name,'exit_code':code,'expected_exit_code':expected,'wall_seconds':time.perf_counter()-t,
            'stdout':stdout,'stderr':error};records.append(row)
        print('DONE '+name+' '+str(code),flush=True)
        if code!=expected:print('FAILED '+json.dumps(row),flush=True);raise RuntimeError('VALIDATION_FAILED_'+name)
    scientific=int(re.search(r'Ran (\d+) tests?',next(r['stderr'] for r in records if r['name']=='scientific_regressions')).group(1))
    process=int(re.search(r'Ran (\d+) tests?',next(r['stderr'] for r in records if r['name']=='process_regressions')).group(1))
    governance=int(re.search(r'Ran (\d+) tests?',next(r['stderr'] for r in records if r['name']=='governance')).group(1))
    assert scientific==177 and process==11 and governance==21
    after=inventory();changes=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
    assert not changes and bound_hashes()==inherited
    assert {p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in bounded}==hashes
    assert {n:sha256((HERE/n).read_bytes()).hexdigest() for n in HISTORICAL}==history
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
    assert records[-1]['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    from audit_a10_e4_interaction import adjudicate
    coverage=adjudicate(*[read(OUT/(n+'.json')) for n in ('primary','replay')])
    assert coverage['scientific_gate']==STATUS
    print('RECEIPT '+json.dumps({'schema':'A10_E4_AND_AGENTIC_ENGINEERING_VALIDATION_V1',
        'status':'PASS_BOUNDED_E4_EVIDENCE_VALIDATION_ONLY','scientific_gate':STATUS,
        'tasks':records,'targeted_regression_tests':209,'new_E4_tests':16,'new_process_tests':11,
        'inherited_tests':182,'scientific_tests':scientific,'governance_tests':governance,
        'fresh_new_routes_byte_identical':3,'predecessor_manifests_authenticated':12,
        'wall_seconds':time.perf_counter()-start,'inherited_byte_bindings':len(inherited),
        'runtime':{'python':sys.version,'executable':sys.executable,'sympy':s.__version__},
        'inherited_bytes_unchanged':True,'historical_fermion_bytes_unchanged':True,
        'new_bytes_unchanged':True,'audit_time_code_and_output_sha256':hashes,
        'workspace_active_data_metadata_records':len(before),'audit_time_changes':changes,
        'inventory_kind':'size_and_mtime_ns_not_all_byte_audit','live_state_transaction_sha256':state,
        'historical_custody_exit':2,'unresolved_historical_references':7,
        'old_expensive_qualifications_rerun':False,'coefficient_coverage':coverage,
        'E5_executed':False,'Stage_D_E3_modified':False,'sources_activated':False,'candidate_adopted':False,
        'catalog_rebuilt':False,'HB1_C5_run':False,'C1_GS_calculated':False,
        'auxiliaries_eliminated':False,'formal_authority':'34/39_UNCHANGED',
        'personal_outreach':False,'external_endorsement':False},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
