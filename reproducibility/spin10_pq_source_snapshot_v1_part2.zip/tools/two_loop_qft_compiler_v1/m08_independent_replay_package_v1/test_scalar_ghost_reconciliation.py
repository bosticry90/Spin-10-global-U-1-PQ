"""Fast contract/adversarial tests; full fresh mathematics is in the audit."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from scalar_ghost_reconciliation import local_convention,potential_contraction_checks
import scalar_ghost_reconciliation_replay as replay_module
from audit_scalar_ghost_reconciliation import compare,negative_controls

HERE=Path(__file__).resolve().parent


class ReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out=HERE/"frozen_scalar_ghost_reconciliation"
        cls.p=json.loads((out/"primary.json").read_text())
        cls.r=json.loads((out/"replay.json").read_text())

    def test_complete_comparison(self): compare(self.p,self.r)
    def test_fifteen_bad_claims_rejected(self): self.assertEqual(negative_controls(self.p,self.r),15)
    def test_sign_derived_from_local_covariance(self): self.assertEqual(local_convention(),self.p["convention"])
    def test_complete_potential_contraction_scan(self): self.assertEqual(potential_contraction_checks(),self.p["potential"])
    def test_all_ghost_pair_sectors(self): self.assertEqual(sum(self.r["pair_sectors"].values()),990)
    def test_original_failure_retained(self): self.assertEqual(self.r["selected_historical_square"],"1")
    def test_two_candidate_contributions_cancel(self): self.assertEqual(self.r["selected_candidate_pieces"],["-1/2","1/2"])
    def test_no_primary_action_import_in_replay(self):
        code=inspect.getsource(replay_module)
        self.assertNotIn("from scalar_ghost_reconciliation import",code)
        self.assertNotIn('read("frozen_scalar_adapter_v2/',code)
    def test_nonminimal_source_work_remains_unqualified(self): self.assertTrue(self.p["source_impacts_unqualified"])
    def test_external_review_not_invented(self): self.assertFalse(self.p["external_specialist_review"])
    def test_truncated_scalar_coordinate_coverage_rejected(self):
        bad=copy.deepcopy(self.r);bad["scalar_coordinates"]=54
        with self.assertRaises(AssertionError): compare(self.p,bad)
    def test_weight_and_authority_unchanged(self):
        self.assertEqual(self.p["formal_authority"],"34/39_UNCHANGED")
        self.assertIsNone(self.p["finite_C1_GS"])
        self.assertFalse(self.p["HB1_C5_authorized"] or self.p["active_rules_changed"])


if __name__=="__main__": unittest.main()
