"""Bounded inactive actual-H semantic review. Read inputs; emit stdout only."""
import itertools
import json
from hashlib import sha256
import sympy as s
from nonminimal_bv_m08_architecture import load
from source_convention_control import Exterior
from nonminimal_bv_free import Jets, GRADES, PAIRS, ETA

DISPOSITION = "BOUNDED_NONABELIAN_ARCHITECTURE_REVIEW_NOT_FULL_M08"


def canonical(poly, algebra):
    out = {}
    for odd, coefficient in poly.items():
        evens = sorted((x for x in coefficient.free_symbols if str(x) in algebra.even_symbols), key=str)
        terms = s.Poly(coefficient, *evens).terms() if evens else [((), coefficient)]
        sign = (-1)**sum(x > y for i, x in enumerate(odd) for y in odd[i+1:])
        for powers, c in terms:
            word = tuple(sorted(list(odd)+[str(x) for x, power in zip(evens, powers) for _ in range(power)]))
            out[word] = out.get(word, 0)+sign*c
    return [{"word": list(w), "coefficient": str(s.simplify(c))} for w, c in sorted(out.items()) if s.simplify(c) != 0]


def matrix_record(m):
    return {"shape": list(m.shape), "entries": [[i, j, str(s.simplify(v))] for (i, j), v in sorted(m.todok().items()) if s.simplify(v) != 0]}


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def geometry():
    raw = load("frozen_rh_composite_adjudication/RH_primary_closed.json")
    f = {(i, a, b): s.sympify(v)/s.sqrt(2) for i, a, b, v in raw["upper_index_structure_constants_raw"]}
    f.update({(i, b, a): -v for (i, a, b), v in list(f.items())})
    basis = load("frozen_c3/C3_representation_basis.json")
    columns = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        col = s.zeros(45, 1)
        for item in row["raw_so10_coordinates"]: col[item["index"]] = s.sympify(item["coefficient"])
        columns.append(col)
    split = s.Matrix.hstack(*columns)
    pairs = list(itertools.combinations(range(10), 2))
    fundamental = []
    for col in columns[:12]:
        m = s.zeros(10)
        for k, (i, j) in enumerate(pairs): m[i, j], m[j, i] = col[k]/s.sqrt(2), -col[k]/s.sqrt(2)
        fundamental.append(s.ImmutableSparseMatrix(m))
    adj = [s.ImmutableSparseMatrix(12, 12, {(i, j): f.get((i, a, j), 0) for i in range(12) for j in range(12) if f.get((i, a, j), 0)}) for a in range(12)]
    heavy = [s.ImmutableSparseMatrix(33, 33, {(i, j): f.get((i+12, a, j+12), 0) for i in range(33) for j in range(33) if f.get((i+12, a, j+12), 0)}) for a in range(12)]
    gram = s.ImmutableSparseMatrix((split.T*split)[:12, :12])
    assert gram.det() != 0 and gram != s.eye(12)
    checked = 0
    for a, b in itertools.combinations(range(12), 2):
        for matrices in (adj, heavy, fundamental):
            expected = sum((f.get((k, a, b), 0)*matrices[k] for k in range(12)), s.zeros(matrices[0].rows))
            assert (matrices[a]*matrices[b]-matrices[b]*matrices[a]-expected).applyfunc(s.simplify) == s.zeros(matrices[0].rows)
            # Evaluation dual coordinate action is +ad^T; coordinates compose
            # in the reverse order to derivations.
            dual = matrices[a].T*matrices[b].T-matrices[b].T*matrices[a].T+expected.T
            assert dual.applyfunc(s.simplify) == s.zeros(matrices[0].rows)
            checked += 2
        # Coefficients of B, d(omega) and d(nu) in the local connection bracket.
        for j in range(12):
            # [[B,e_a],e_b]-[[B,e_b],e_a]=[B,[e_a,e_b]].
            lhs = adj[b]*adj[a][:, j]-adj[a]*adj[b][:, j]
            rhs = -sum((f.get((k, a, b), 0)*adj[k][:, j] for k in range(12)), s.zeros(12, 1))
            assert (lhs-rhs).applyfunc(s.simplify) == s.zeros(12, 1)
        assert all(s.simplify(f.get((i, a, b), 0)+f.get((i, b, a), 0)) == 0 for i in range(12))
    for a in range(12): assert (adj[a].T*gram+gram*adj[a]).applyfunc(s.simplify) == s.zeros(12)
    wrong_pairing = -adj[0].T-adj[0]
    assert wrong_pairing != s.zeros(12), "wrong primal copy must fail evaluation pairing"
    # Actual composite, not a separately assigned curvature generator.
    algebra = Exterior(); u = [algebra.variable("u"+str(i), 1) for i in range(33)]
    R = [algebra.add(*(algebra.scale(algebra.mul(u[i], u[j]), -f.get((h, i+12, j+12), 0)) for i in range(33) for j in range(i+1, 33))) for h in range(12)]
    for a in range(12):
        action = {"u"+str(i): algebra.add(*(algebra.scale(u[j], -v) for (row, j), v in heavy[a].todok().items() if row == i)) for i in range(33)}
        for h in range(12):
            expected = algebra.add(*(algebra.scale(R[k], -adj[a][h, k]) for k in range(12)))
            assert not algebra.add(algebra.derive(R[h], action, parity=0), algebra.scale(expected, -1))
    nonsymmetric = next((i, a, b, v) for (i, a, b), v in sorted(f.items()) if i >= 12 and 12 <= a < b and v != 0)
    return f, adj, heavy, {"H_dimension": 12, "heavy_dimension": 33, "generator_pairs": 66,
        "module_and_dual_matrix_equations": checked, "local_connection_pair_equations": 66,
        "module_hashes": {"H": digest([matrix_record(m) for m in adj]), "heavy": digest([matrix_record(m) for m in heavy]), "physical_10": digest([matrix_record(m) for m in fundamental])},
        "H_gram": matrix_record(gram), "H_gram_nondegenerate_nonidentity": True, "metric_intertwiner_checks": 12,
        "wrong_primal_source_pairing_matrix": matrix_record(wrong_pairing),
        "R": [canonical(p, algebra) for p in R], "R_covariance_equations": 144,
        "non_symmetric_coset_witness": [*nonsymmetric[:3], str(s.simplify(nonsymmetric[3]))],
        "normalized_f_4_0_4": str(s.simplify(f[4, 0, 4])),
        "full_328_and_990_checks": "previous scalar reconciliation evidence reused, not reconstructed here"}


def light_block(f, adj):
    a = Exterior(); g = s.Symbol("g10")
    names = {"c": 1, "Jc": 0, "bar": 1, "b": 0, "Jbar": 0, "Jb": 1}
    x = {prefix: [a.variable(prefix+str(i), parity) for i in range(12)] for prefix, parity in names.items()}
    omega = [a.variable("omega"+str(i), 0) for i in range(12)]
    pairs = [(prefix+str(i), source+str(i)) for prefix, source in (("c", "Jc"), ("bar", "Jbar"), ("b", "Jb")) for i in range(12)]
    qc = [a.add(*(a.scale(a.mul(x["c"][j], x["c"][k]), -g*f.get((i, j, k), 0)) for j in range(12) for k in range(j+1, 12))) for i in range(12)]
    S = a.add(*(a.mul(x["Jc"][i], qc[i]) for i in range(12)), *(a.scale(a.mul(x["Jbar"][i], x["b"][i]), -1) for i in range(12)))
    G = a.add(*(a.mul(x["Jc"][i], omega[i]) for i in range(12)), *(a.scale(a.mul(x["Jb"][i], omega[h], x["bar"][j]), g*v) for h in range(12) for (i, j), v in adj[h].todok().items()))
    variables = {prefix+str(i): value for prefix, vec in x.items() for i, value in enumerate(vec)}
    Q = {n: a.bracket(S, p, pairs) for n, p in variables.items()}
    I = {n: a.bracket(G, p, pairs) for n, p in variables.items()}
    T = {}
    for prefix in names:
        matrices = [m.T if prefix.startswith("J") else -m for m in adj]
        for i in range(12): T[prefix+str(i)] = a.add(*(a.scale(a.mul(omega[h], x[prefix][j]), g*v) for h in range(12) for (row, j), v in matrices[h].todok().items() if row == i))
    for n in variables:
        assert not a.add(a.derive(Q[n], I), a.derive(I[n], Q), a.scale(T[n], -1)), "Cartan "+n
        assert not a.derive(I[n], I), "contraction square "+n
        assert not a.derive(Q[n], Q), "nonminimal block square "+n
        assert not a.add(a.derive(Q[n], T, parity=0), a.scale(a.derive(T[n], Q), -1)), "TQ "+n
    nu = [a.variable("nu"+str(i), 0) for i in range(12)]
    def contraction_parameter(vec):
        substitution = {a.even_symbols["omega"+str(i)]: vec[i] for i in range(12)}
        return {n: {word: s.expand(c.subs(substitution, simultaneous=True)) for word, c in p.items()} for n, p in I.items()}
    Inu = contraction_parameter([a.even_symbols["nu"+str(i)] for i in range(12)])
    eta = [s.expand(g*sum((f.get((i, h, k), 0)*a.even_symbols["omega"+str(h)]*a.even_symbols["nu"+str(k)] for h in range(12) for k in range(12)))) for i in range(12)]
    Ieta = contraction_parameter(eta)
    for n in variables:
        assert not a.add(a.derive(Inu[n], T, parity=0), a.scale(a.derive(T[n], Inu), -1), a.scale(Ieta[n], -1)), "local Lie-contraction "+n
    assert not a.bracket(S, S, pairs)
    return {"base_components": 72, "canonical_pairs": 36, "Cartan_checks": 72, "contraction_square_checks": 72, "Q_square_checks": 72,
        "local_L_iota_checks": 72, "TQ_checks": 72,
        "scope": "ungauge_fixed_H_ghost_and_light_nonminimal_block_not_full_M08_master",
        "contraction_images": {n: canonical(p, a) for n, p in I.items()},
        "local_action_hash": digest({n: canonical(p, a) for n, p in T.items()}),
        "canonical_contraction_Hamiltonian": canonical(G, a), "master_zero": True}


class ParameterJets(Jets):
    def var(self, base, indices=()):
        if base != "omega": return super().var(base, indices)
        indices = tuple(sorted(indices))
        if len(indices) > self.limit: raise RuntimeError("PARAMETER_JET_LIMIT_NOT_TRUNCATED")
        name = base+("__"+"".join(map(str, indices)) if indices else "")
        if name not in self.meta:
            self.meta[name] = (base, indices); self.values[name] = self.a.variable(name, 0)
            self.max_order = max(self.max_order, len(indices))
        return self.values[name]


def fixed_source_control():
    j = ParameterJets(); a = j.a; x = {n: j.var(n) for n in GRADES}; xi = s.Symbol("xi"); omega = j.var("omega")
    div = a.add(*(a.scale(j.D(x[f"V{m}"], m), ETA[m]) for m in range(4)))
    kinetic = a.add(*(a.scale(a.mul(a.add(j.D(x[f"V{n}"], m), a.scale(j.D(x[f"V{m}"], n), -1)), a.add(j.D(x[f"V{n}"], m), a.scale(j.D(x[f"V{m}"], n), -1))), -s.Rational(1, 2)*ETA[m]*ETA[n]) for m in range(4) for n in range(m+1, 4)))
    Smin = a.add(kinetic, *(a.mul(x[f"KV{m}"], j.D(x["u"], m)) for m in range(4)), a.scale(a.mul(x["Kbar"], x["Lambda"]), -1))
    psi = a.mul(x["bar"], a.add(div, a.scale(x["Lambda"], -xi/2)))
    Qmin = j.columns(Smin); Sfixed = a.add(Smin, j.Q(psi, Qmin)); Qfixed = j.columns(Sfixed)
    shifts = {n: a.scale(j.bracket(psi, x[n]), -1) for n in GRADES}
    U = lambda P: j.transport(P, shifts); inverse = lambda P: j.transport(P, shifts, -1)
    Traw = {f"V{m}": j.D(omega, m) for m in range(4)}
    Iraw = {"u": omega}
    def act(P, images, parity):
        lifted = {n: j.multiD(images.get(j.meta[n][0], {}), j.meta[n][1]) for n in j.support(P)}
        return a.derive(P, lifted, parity=parity)
    T = {n: U(act(inverse(p), Traw, 0)) for n, p in x.items()}
    I = {n: U(act(inverse(p), Iraw, 1)) for n, p in x.items()}
    Graw = a.add(*(a.scale(a.mul(x[f"KV{m}"], j.D(omega, m)), -1) for m in range(4)))
    for n, p in x.items():
        assert not a.add(j.bracket(U(Graw), p), a.scale(T[n], -1)), "transported canonical T"
        assert not a.add(act(Qfixed[n], I, 1), j.Q(I[n], Qfixed), a.scale(T[n], -1)), "fixed Cartan "+n
        assert not a.add(act(Qfixed[n], T, 0), a.scale(j.Q(T[n], Qfixed), -1)), "fixed TQ "+n
        assert not j.Q(Qfixed[n], Qfixed)
        assert not a.add(inverse(U(p)), a.scale(p, -1))
        assert not a.add(j.Q(U(p), Qfixed), a.scale(U(Qmin[n]), -1))
        for mu in range(4):
            assert not a.add(act(j.D(p, mu), T, 0), a.scale(j.D(T[n], mu), -1))
            assert not a.add(act(j.D(p, mu), I, 1), a.scale(j.D(I[n], mu), -1))
    assert T["Kbar"] and not a.add(T["Kbar"], j.box(omega))
    assert not I.get("Kbar")
    # Naively retaining the minimal source action fails, even at zero coupling.
    raw_defect = a.add(act(Qfixed["Kbar"], I, 1), j.Q(I["Kbar"], Qfixed), a.scale(Traw.get("Kbar", {}), -1))
    assert raw_defect and not a.add(raw_defect, j.box(omega))
    return {"base_generators": 14, "Cartan_checks": 14, "TQ_checks": 14, "ordinary_prolongation_checks": 112,
        "transported_T": {n: canonical(p, a) for n, p in T.items()}, "transported_iota": {n: canonical(p, a) for n, p in I.items()},
        "shifts": {n: canonical(p, a) for n, p in shifts.items()}, "Q_fixed_hash": digest({n: canonical(p, a) for n, p in Qfixed.items()}),
        "raw_source_action_defect": canonical(raw_defect, a), "light_fermion_raw_quantum_variation": canonical(act(psi, Traw, 0), a),
        "nonzero_transported_Kbar": canonical(T["Kbar"], a), "canonical_T_generator_transported": True,
        "inverse_and_Q_intertwining": True, "no_EOM": True, "full_M08_gauge_fixing_transport": False}


def frozen_semantic_bindings():
    seed = load("frozen_st_seed/S1_component_transformations.json")
    gauge = load("frozen_action_ast_a4_v2_l6r/A4V2_light_gauge_function.json")
    alphabet = load("frozen_c5/C5_alphabet.json")["symbols"]
    couplings = load("frozen_source_seed_s3_s5/S33_source_couplings.json")["couplings"]
    modules = {row["identity"]: row for row in load("frozen_catalog_cat0_cat4/CAT1_module_actions.json")["modules"]}
    assert seed["background_BRST_convention"] == "QUANTUM_WEIL_DIFFERENTIAL_LEAVES_Abar_H_INERT"
    assert seed["transformation_ast"]["Abar_H_mu"]["op"] == "Zero"
    assert seed["exact_split_certificate"]["h_h_to_m_nonzero_components"] == seed["exact_split_certificate"]["h_m_to_h_nonzero_components"] == 0
    assert seed["exact_scalar_shift_certificate"]["H_VEV_orbit"] == "0_exact"
    assert gauge["derivation"]["definition"] == "G_alpha=(Dbar_mu q^mu)_alpha"
    assert len(alphabet) == 17 and len(couplings) == 6
    by_name = {row["identity"]: row for row in alphabet}
    partners = {}
    for field, source in (("ubar_H", "K_ubar"), ("cbar_L", "K_cbar"), ("lambda_L", "K_lambda")):
        r = by_name[field]; p = int(r["grassmann_parity"] == "ODD")
        partners[source] = [3-r["canonical_dimension"], -1-r["ghost_number"], 1-p]
    assert partners == {"K_ubar": [2, 0, 0], "K_cbar": [2, 0, 0], "K_lambda": [1, -1, 1]}
    return {"background_seed_convention": seed["background_BRST_convention"], "light_gauge_definition": gauge["derivation"]["definition"],
        "H_VEV_annihilation": "immutable exact S1 evidence reused; no new physical vacuum calculation",
        "roles": [{k: row[k] for k in ("identity", "canonical_dimension", "ghost_number", "grassmann_parity", "H_representation", "Lorentz_representation", "role_class")} | {"catalog_H_action": modules[row["identity"]]["H_action"]} for row in alphabet],
        "six_source_targets": {row["source"]: row["target"] for row in couplings}, "prospective_partner_grades_derived": partners}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    stage = stage or (lambda n, f: f())
    f, adj, heavy, geom = stage("actual_H_geometry_and_composite", geometry)
    block = stage("actual_H_canonical_nonminimal_block", lambda: light_block(f, adj))
    control = stage("canonical_light_gauge_fixing_source_control", fixed_source_control)
    return {"schema": "NONABELIAN_M08_SEMANTIC_REVIEW_V1", "disposition": DISPOSITION, "geometry": geom, "light_block": block, "fixed_source_control": control,
        "frozen_semantic_bindings": stage("frozen_role_background_and_gauge_bindings", frozen_semantic_bindings),
        "semantics": {"quantum_Abar": "0", "quantum_q": "d omega + g10 [Abar+q,omega]_H", "background_Abar": "d omega + g10 [Abar,omega]_H", "background_q": "g10 [q,omega]_H",
            "total_connection_both": "d omega + g10 [Abar+q,omega]_H", "bracket_parameter": "g10 [omega,nu]_H", "matter": "-g10 rho(omega) (v+phi)",
            "canonical_sources": "+g10 rho(omega)^T J before gauge fixing; afterward transport with U_psi", "composite_parameter": "differentiate independent parameter first, substitute -g10 R_H afterward",
            "light_G": "Dbar.q", "raw_quantum_minus_background_G": "Dbar^2 omega + g10 [q,Dbar omega]_H", "raw_quantum_light_psi_invariant": False,
            "iQ_Abar_cannot_equal_affine_background_action": True},
        "impact": {"old_roles": 17, "old_independent_roles": 16, "old_canonical_pairs": 6, "prospective_pair_types": 9,
            "prospective_partner_components": {"K_ubar": 33, "K_cbar": 12, "K_lambda": 12}, "prospective_new_components": 57,
            "prospective_partner_grades": {"K_ubar": [2, 0, 0], "K_cbar": [2, 0, 0], "K_lambda": [1, -1, 1]},
            "maximum_independent_occurrence_bounds": {"C_minus1": 3, "C_zero": 4, "C_plus1": 5},
            "catalog_coordinate_map": "nonidentity H Gram supplies a candidate self-dual/evaluation-dual intertwiner, not qualified catalog decoder transport",
            "catalogs_reused_as_historical_authority": True, "extended_alphabet_completeness_claimed": False},
        "remaining": ["owner and specialist adjudication of quantum/background/transported residual domain", "full canonical source coordinate maps and action including non-symmetric coset and affine background", "full partial/light gauge-fixing and reverse-image derivation", "full M08 master/local Cartan/Weil and composite chain identities", "representative-independent descent through JCAT/T5 quotients"],
        "M08_changed": False, "full_M08_qualified": False, "HB1_C5_authorized": False, "cochain_dimensions_computed": False, "EOM_used": False, "external_specialist_review": False,
        "formal_authority": "34/39_UNCHANGED", "finite_C1_GS": None}


if __name__ == "__main__": print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
