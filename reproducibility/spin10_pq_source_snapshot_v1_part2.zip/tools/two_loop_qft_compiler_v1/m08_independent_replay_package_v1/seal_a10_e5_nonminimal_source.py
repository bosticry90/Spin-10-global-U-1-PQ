"""Seal validated source/affine bytes without scientific authority promotion."""
import subprocess
from hashlib import sha256
from a10_e5_nonminimal_source import HERE, ROOT, OUT, BASE, read
from validate_a10_e5_nonminimal_source import protected, new_files
from export_a10_e5_nonminimal_source import dump
from seal_a10_e5_shear_space import PARENTS as SHEAR_PARENTS

PARENTS = (*SHEAR_PARENTS, 'frozen_a10_e5_shear_space')


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    assert not (OUT / 'bindings.json').exists(), 'NO_OVERWRITE'
    r = read(OUT / 'validation_receipt.json')
    assert r['status'] == 'PASS_BOUNDED_ACTUAL_SOURCE_AND_AFFINE_EVIDENCE_VALIDATION_ONLY'
    assert r['fresh_routes_byte_identical'] == 3 and not r['audit_time_changes']
    assert r['historical_custody_exit'] == 2 and r['unresolved_historical_references'] == 7
    assert not r['other_new_companion_loops_executed'] and not r['normalization_adopted'] and not r['full_E5_or_quantum_A5']
    assert protected() == r['protected_byte_sha256'] and len(PARENTS) == 34
    for n, h in r['new_sha256'].items(): assert sha256((ROOT / n).read_bytes()).hexdigest() == h, n
    assert sha256((ROOT / 'project_state.json').read_bytes()).hexdigest() == r['state_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    paths = new_files() + [OUT / 'validation_receipt.json']
    dump(OUT / 'bindings.json', {'schema': 'E5_ACTUAL_NONMINIMAL_SOURCE_BINDINGS_V1', 'base_commit': BASE,
        'byte_sha256': {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
        'inherited_manifest_sha256': {(HERE / n / 'bindings.json').relative_to(ROOT).as_posix(): sha256((HERE / n / 'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
        'state_sha256': r['state_sha256'], 'scientific_disposition': r['scientific_disposition'],
        'complete_selected_actual_source_pole_qualified': True, 'affine_source_match': r['source_summary']['match'],
        'normalization_adopted': False, 'physical_parameters_fitted': False,
        'other_new_companion_loops_executed': False, 'sources_activated': False, 'auxiliaries_eliminated': False,
        'full_E5_or_quantum_A5': False, 'HB1_C5_run': False, 'C1_GS_calculated': False,
        'authority_changed': False, 'whole_goal_complete': False, 'remote_push': False, 'external_endorsement': False})
    print('SEALED actual nonminimal-source and bounded affine comparison; whole goal incomplete')


if __name__ == '__main__': main()
