"""Stage D acceptance, adverse normalization and canonical pairing controls."""
import unittest
import sympy as s
from a10_bv_integration_common import *

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r,cls.c=[read(OUT/(n+'.json')) for n in ('primary','replay','checks')]
        cls.candidate=read(OUT/'M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json')
    def test_complete_columns_reuse_exact_source_coefficients(self):
        old,_=source_data()
        self.assertEqual(len(self.p['complete_columns']),1286)
        for n,col in self.p['complete_columns'].items():self.assertEqual(col['source_only'],old['source_only_columns'][n])
    def test_physical_contributions_only_correct_canonical_sources(self):
        targets={n for n,v in self.p['complete_columns'].items() if v['physical']}
        self.assertEqual(len(targets),508)
        self.assertTrue(all(n.startswith(('JB','Jx_')) for n in targets))
        self.assertIsNone(self.p['complete_columns']['JC0']['physical'])
        from a10_bv_integration_euler import canonical_physical_values
        from a10_cotangent_adapter import Adapter
        plane={(a,mu):s.Integer(0) for a in IDS for mu in range(4)}
        t=s.Symbol('t',real=True);plane[0,1]=t
        kinetic={sec:s.zeros(n,1) for sec,n in DIM.items()}
        potential={row['term_id']:{sec:{} for sec in DIM} for row in self.p['physical_Euler_program']['potential_ordered_ASTs']}
        alpha=s.zeros(252,1);alpha[0]=-2*t
        potential[next(iter(potential))]['Sigma']=Adapter('Sigma').section(alpha)
        got=canonical_physical_values(plane,kinetic,potential)
        Q=mat(self.p['contract']['architecture']['C3_to_plane_field'])
        self.assertEqual(got['Jx_Sigma_0'],-2*t)
        for a in IDS:self.assertEqual(got[f'JB{a}_1'],s.expand(Q[0,a]*t))
    def test_candidate_preserves_all_terms_parameters(self):
        old=read(HERE/'frozen_a10_bv_master/M08_CANONICAL_BV_CANDIDATE_UNQUALIFIED_V1.json')
        self.assertEqual(self.candidate['local_terms'],old['local_terms'])
        self.assertEqual(self.candidate['parameters'],old['parameters'])
    def test_both_routes_all_field_squares(self):
        self.assertEqual(self.p['field_nilpotence'],self.r['field_nilpotence'])
        self.assertEqual(len(self.p['field_nilpotence']),643)
        self.assertTrue(all(not v['residual'] for v in self.p['field_nilpotence']))
    def test_master_density_is_nonzero_but_exact_boundary(self):
        M=self.p['source_degree_one_master'];self.assertEqual(M,self.r['source_degree_one_master'])
        self.assertEqual(len(M['literal_master_density']),5316)
        self.assertEqual(sum(map(len,M['boundary_current'])),1772)
        self.assertEqual(M['density_minus_divergence'],[])
    def test_all_physical_cross_identities_and_offshell_Noether(self):
        p=self.p['physical_cross'];r=self.r['physical_cross']
        self.assertEqual(p['Euler_covariance'],r['Euler_covariance'])
        self.assertEqual(p['Noether_parent'],r['Noether_parent'])
        self.assertEqual(len(p['all_643_source_cross_checks']),643)
        self.assertFalse(p['source_degree_zero_master']['EOM_used'])
    def test_independent_exterior_source_and_jet_squares(self):
        r=self.r['independent_exterior_control']
        self.assertEqual(r['canonical_pairs'],20);self.assertEqual(len(r['full_generator_squares']),40)
        self.assertEqual(r['first_jet_squares'],80);self.assertEqual(r['master_minus_divergence'],[])
    def test_wrong_physical_Euler_breaks_ghost_source_nilpotence(self):
        r=self.c['wrong_gauge_Euler_negative']
        self.assertEqual(r['correct_ghost_source_square'],[])
        self.assertEqual(r['wrong_spatial_Euler_ghost_source_square'],[
            {'word':['B0__011'],'coefficient':'-2'},{'word':['B1__001'],'coefficient':'2'}])
    def test_heavy_full_parent_canonical_transport(self):
        r=self.c['heavy_canonical_transport']
        self.assertEqual(r['field_source_pair_checks'],12321);self.assertEqual(r['source_cross_checks'],6216)
        self.assertEqual(r['inverse_checks'],444);self.assertTrue(r['transport_matches_saved_source_columns'])
    def test_missing_cotangent_ghost_correction_is_noncanonical(self):
        # Minimal even shift b=L-g c u with both c,u odd. Dropping JC's
        # correction leaves a nonzero cross pairing between b and JC.
        from source_convention_control import Exterior
        a=Exterior();p={'c':1,'u':1,'L':0};pairs=[(z,'J'+z) for z in p]
        x={n:a.variable(n,k) for n,k in (p|{'J'+z:1-k for z,k in p.items()}).items()}
        shifted=a.add(x['L'],a.scale(a.mul(x['c'],x['u']),-g))
        self.assertTrue(a.bracket(shifted,x['Jc'],pairs))
    def test_composite_curvature_cannot_be_omitted(self):
        data,cols=source_data();w=algebra();wrong=dict(cols)
        # Drop just the cubic composite-R term in QLambda, leaving all other
        # saved transformations intact. This must break Q^2 ubar.
        for i in M:wrong[f'L{i}']={word:c for word,c in cols[f'L{i}'].items() if len(word)==2}
        residual=canonical(w.act(wrong['ub13'],wrong,parity=1))
        self.assertTrue(residual)
        self.assertEqual(rows(residual),self.c['composite_curvature_omission_negative']['residual'])
    def test_no_symmetric_coset_substitution(self):
        data,_=source_data();f={tuple(row[:3]):coefficient(row[3]) for row in data['geometry']['f']}
        self.assertNotEqual(f.get((12,13,44),0),0)
        self.assertTrue(self.c['heavy_canonical_transport']['full_nonsymmetric_parent_algebra_retained'])
    def test_scalar_and_gauge_adapter_scopes_preserved(self):
        from a10_gauge_euler_adapter import canonical_euler
        from m08_local_functional_ast import field
        with self.assertRaises(AssertionError):canonical_euler(field('C',parity=1))
        program=self.p['physical_Euler_program']
        self.assertEqual(len(program['potential_ordered_ASTs']),29)
        self.assertEqual(set(program['scalar_kinetic_ASTs']),set(DIM))
    def test_jet_scope_and_no_bruteforce_overclaim(self):
        self.assertTrue(self.c['jets']['computational_jet_cap_raises'])
        self.assertEqual(self.c['jets']['source_and_field_prolongation_checks'],68)
        self.assertFalse(self.p['source_nilpotence_certificate']['expanded_source_squares_claimed'])
    def test_no_downstream_promotion(self):
        for key in ('Stage_E_reached','sources_activated','adopted','gauge_fixing_included','Yukawa_included','HB1_C5_authorized','quantum_consistency_established'):
            self.assertFalse(self.candidate[key])
    def test_seven_exact_dependency_bindings(self):
        self.assertEqual(len(self.p['contract']['dependency_manifest_sha256']),7)
        self.assertEqual(self.p['contract']['authority'],'34/39_UNCHANGED')
if __name__=='__main__':unittest.main()
