"""Acceptance, normalization, parameter and cotangent-interface falsifiers."""
from copy import deepcopy
import unittest
import sympy as s
from a10_executable_action import (build, Executor, read, HERE, OUT, conjugate_tree, digest)
from audit_a10_executable import authenticate
from interacting_actual_h_preflight_replay import GaugeWords

def unpack(rows):
    p={}
    for row in rows:
        key=[]
        for item in row['word']:
            name,sep,jet=item.partition('__'); key.append((name,tuple(map(int,jet)) if sep else ()))
        p[tuple(key)]=s.sympify(row['coefficient'])
    return p

class ExecutableTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')

    def test_direct_translation_and_stop_evidence(self):
        a=authenticate(); self.assertEqual(a['potential_directions_with_fresh_nonzero_control'],29)
        self.assertEqual(a['scientific_stage_E'],'NOT_REACHED')

    def test_gauge_invariant_wrong_singlet_normalization_is_detected(self):
        w=GaugeWords(0); w.p={'S0':0,'S1':0}
        tables={'x_S':{(0,):w.var('S0'),(1,):w.var('S1')},'rho_S':{},'B':{}}
        term=build()['local_terms'][4]; correct=Executor(w,tables).eval(term).rows[()]
        bad=deepcopy(term); bad['density']['expression']['expression']['factors'][0]['value']='1'
        changed=Executor(w,tables).eval(bad).rows[()]
        self.assertEqual(changed,w.scale(correct,2)); self.assertNotEqual(changed,correct)
        self.assertFalse(w.act(changed,{},parity=1))

    def test_complex_parameter_orientation_is_physical_translation_data(self):
        w=GaugeWords(0); w.p={}; old=read(HERE/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions']['z6']['density']
        z=s.Integer(3)+2*s.I
        kernels={digest(old):lambda:z,digest(conjugate_tree(old)):lambda:s.conjugate(z)}
        term=next(row for row in build()['local_terms'] if row.get('coefficient_direction')=='z6')
        good=Executor(w,{},kernels).eval(term).rows[()][()]
        bad=deepcopy(term)
        def flip(n):
            if isinstance(n,dict):
                if n.get('node')=='ExactScalar' and n.get('value') in ('I','-I'):n['value']='-I' if n['value']=='I' else 'I'
                for v in n.values():flip(v)
            elif isinstance(n,list):
                for v in n:flip(v)
        flip(bad); other=Executor(w,{},kernels).eval(bad).rows[()][()]
        self.assertNotEqual(s.expand(good-other),0)
        self.assertEqual(s.expand(good),-6*s.Symbol('z6_Re',real=True)+4*s.Symbol('z6_Im',real=True))

    def test_nonabelian_executable_gauge_density_Ward(self):
        p=read(OUT/'primary.json'); old=read(HERE/'frozen_a10_physical_reconciliation/full_replay.json')
        ids=(0,1,9); w=GaugeWords(0); w.p={**{'b'+str(a)+'_'+str(mu):0 for a in ids for mu in range(4)},**{'C'+str(a):1 for a in ids}}
        g=s.Symbol('g10'); f={}
        for c,a,b,v in old['ward']['plane_structure_constants']:f[c,a,b]=s.sympify(v);f[c,b,a]=-s.sympify(v)
        forward={'b'+str(a)+'_'+str(mu):w.add(w.D(w.var('C'+str(a)),mu),
            *(w.scale(w.mul(w.var('b'+str(b)+'_'+str(mu)),w.var('C'+str(c))),g*f.get((a,b,c),0)) for b in ids for c in ids)) for a in ids for mu in range(4)}
        self.assertFalse(w.act(unpack(p['gauge_density']),forward,parity=1))

    def test_kernel_lookup_cannot_hide_a_changed_contraction(self):
        w=GaugeWords(0);w.p={}; node={'node':'GroupContraction','summed_indices':['i'],'argument':{'node':'Field','name':'phi','indices':['i'],'parity':0},'parity':0}
        ex=Executor(w,{'phi':{(0,):{():s.Integer(2)}}},{digest(node):lambda:s.Integer(7)})
        self.assertEqual(ex.eval(node).rows[()][()],7)
        changed=deepcopy(node);changed['name']='changed_graph_metadata'
        self.assertEqual(ex.eval(changed).rows[()][()],2)

    def test_canonical_value_binding_uses_frozen_embeddings(self):
        from a10_executable_action import canonical_state
        values={'Phi':[0]*54,'Sigma':[0]*252,'phi':[0]*20,'S':[1,2]}
        state=canonical_state(values);self.assertEqual(s.simplify(state.S-(1+2*s.I)/s.sqrt(2)),0)

    def test_ordinary_jets_are_supplied_before_point_value_projection(self):
        w=GaugeWords(0); w.p={}; field={'node':'Field','name':'x','indices':['i'],'parity':0}
        node={'node':'PartialDerivative','index':'mu','argument':field,'parity':0}
        result=Executor(w,{'x':{(0,):{():s.Integer(5)}}},jets={('x','mu'):{(0,2):{():s.Integer(7)}}}).eval(node)
        self.assertEqual(result.rows,{(0,2):{():s.Integer(7)}})

    def test_correct_abstract_Riesz_bridge_does_not_certify_raw_template_type(self):
        p=read(OUT/'source_interface_primary.json')
        self.assertFalse(p['abstract_Riesz_bridge_refuted']);self.assertFalse(p['physical_action_refuted'])
        self.assertEqual(p['required_ordered_to_sorted_multiplicity'],120)
        self.assertNotEqual(p['canonical_derivative'],p['raw_real_to_sorted_Riesz_without_measure'])
        self.assertEqual(p['canonical_derivative'],p['derived_correct_pullback_control'])

    def test_no_downstream_action_follows_from_the_interface_stop(self):
        p=read(OUT/'source_interface_primary.json'); action=build()
        self.assertFalse(p['complete_master_action_constructed']);self.assertFalse(p['Stage_E_reached'])
        self.assertFalse(action['adopted']);self.assertEqual(action['sources'],[])
        self.assertFalse(action['gauge_fixing_included'])

if __name__=='__main__':unittest.main()
