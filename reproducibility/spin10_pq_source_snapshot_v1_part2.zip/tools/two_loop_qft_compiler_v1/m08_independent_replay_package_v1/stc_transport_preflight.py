"""Bounded equivalence and abstract-extension tests; no new project alphabet."""
from hashlib import sha256
import sympy as s
from hbc_structural_preflight import HERE, ROOT, load, serialized, seal, measured
from hbp_structural_preflight import split_geometry, source_coefficients, monomials

OUT = HERE / 'frozen_stc_source_transport'
BLOCKER = 'M08_C5_EQUIVARIANT_SOURCE_FORMALISM_REQUIRES_REDESIGN'
INPUTS = [
    'STC_TASK_RECORD.md', 'frozen_c3/C3_representation_basis.json',
    'frozen_c4/C4_offshell_differential.json', 'frozen_c4/C4_equivariant_algebra_certificate.json',
    'frozen_c5/C5_alphabet.json', 'frozen_catalog_cat0_cat4/CAT1_module_actions.json',
    'frozen_source_seed_s3_s5/S32_graded_source_convention.json',
    'frozen_source_seed_s3_s5/S33_source_couplings.json',
    'frozen_source_seed_s3_s5/Sigma_M08_V1.json',
    'frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json',
    'frozen_variational_s5_s8/S52_ST_identity.json', 'frozen_variational_s5_s8/S63_equivariant_closure.json',
    'frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json',
    'T5_target_catalog_checkpoint.json',
    'frozen_hbp_structural_domain/HBP_primary_preflight.json',
    'frozen_hbp_structural_domain/HBP_component_replay.json',
    'frozen_hbp_structural_domain/HBP_checkpoint.json',
]


def bindings():
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in INPUTS}


def code_bindings():
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in (
        'stc_transport_preflight.py', 'stc_transport_replay.py', 'execute_stc_source_transport.py',
        'hbp_structural_preflight.py', 'hbp_component_replay.py', 'hbc_structural_preflight.py')}


def nodes(node):
    if isinstance(node, dict):
        yield node
        for value in node.values(): yield from nodes(value)
    elif isinstance(node, list):
        for value in node: yield from nodes(value)


def comparator():
    # Ferrari 2.59-2.66, abelian de Rham module: I(x)=0, I(xi)=1.
    # This is a separate mathematical example, not extra M08 variables.
    t = s.Symbol('t')
    # U xi=xi+t*omega; U^-1 xi=xi-t*omega. All other generators fixed.
    # Total contraction: I_total xi=1, I_total omega=1.
    # B_T x=xi+t omega; B_T xi=-t rho; B_T omega=rho.
    inverse = s.expand(t-t)
    nilpotence_x = s.expand(-t+t)
    cartan_x = s.expand((1-t)+t)
    assert inverse == nilpotence_x == 0 and cartan_x == 1
    return {'status': 'PASS_EXTERNAL_SOURCE_FREE_ABELIAN_COMPARATOR',
        'reference': 'https://arxiv.org/html/1308.6802v3', 'equations': ['2.59','2.60','2.61','2.64','2.66'],
        'algebra': 'de Rham(x,xi) tensor Weil(omega,rho) for one abelian generator',
        'original_D': {'x':'xi','xi':'0','omega':'rho','rho':'0'},
        'original_iota_total': {'x':'0','xi':'1','omega':'1','rho':'0'},
        'L': {'x':'1','xi':'0','omega':'0','rho':'0'},
        'U': {'xi':'xi+t*omega','others':'fixed'}, 'inverse': {'xi':'xi-t*omega','others':'fixed'},
        'transported_D': {'x':'xi+t*omega','xi':'-t*rho','omega':'rho','rho':'0'},
        'transported_iota': {'x':'0','xi':'1-t','omega':'1','rho':'0'},
        'generator_nilpotence': ['0','0','0','0'], 'Cartan_generator_residuals': ['0','0','0','0'],
        'Cartan_at_t1': 'omega-free invariants, d_C(x)=xi, d_C(xi)=-rho; d_C^2=-rho*L; nilpotent on invariants',
        'M08_source_application': False,
        'missing_M08_hypothesis': 'Source Cartan identity fails; no source H-differential algebra or equivalent basic complex is qualified.'}


def build_primary():
    with measured('STC_AST_and_custody', 'input_parse_and_symbolic_normalization'):
        images = {v['identity']: v for v in load('frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json')['images']}
        coeff, rsign = source_coefficients(images)
        sigma = load('frozen_source_seed_s3_s5/Sigma_M08_V1.json')['Sigma_M08']
        hbp = load('frozen_hbp_structural_domain/HBP_primary_preflight.json')
        assert coeff == {'first': s.Rational(1,2), 'second': -s.Rational(1,2)} and rsign == -1
        carriers = sorted(k for k,v in images.items() if any(n.get('name') == 'L_c' for n in nodes(v['B_Sigma_image'])))
        assert carriers == ['L_c']
        # Bind what the CURRENT images contain, not a hypothetical rederivation
        # that changes treatment of a composite inside a source Euler image.
    with measured('STC_exact_source_equations', 'exact_linear_algebra_and_tensor_identity'):
        f, _, R, words = split_geometry()
        col = words.index((1,26)); rv = R[:,col]
        f044 = s.simplify(f[0][4,4]); r4 = s.simplify(rv[4])
        defect = s.simplify(-2*(f[0]*rv)[4])
        assert defect == -2*s.I
        # On the no-u coefficient, Qc=-g/2[c,c], QLc=-g c^a A_a^T Lc.
        # The coefficient of c^a c^b (a<b) in Q^2 Lc is
        # g^2 (sum f^k_ab A_k^T - [A_a^T,A_b^T]).
        a,b,component,source = 0,4,0,4
        term1 = sum((f[a][k,b]*f[k].T for k in range(12)), s.zeros(12))
        term2 = -(f[a].T*f[b].T-f[b].T*f[a].T)
        square = (term1+term2).applyfunc(s.simplify)
        assert term1 == term2 and square[component,source] == 1
        # Needed contraction partner transformation, at first order in chi:
        # {iota_a,Q}Lc = g A_a^T Lc implies
        # Q chi_a = 2g A_a^T Lc - g c^b A_b^T chi_a.
        # Anticommutation gives eta_ab=iota_a chi_b=-eta_ba.
    comp = comparator()
    return seal({'status':'BOUNDED_TRANSPORT_NO_GO_AND_ACYCLIC_EXTENSION_OBSTRUCTION',
        'resume_commit':'353ab9a','input_byte_sha256':bindings(),'code_byte_sha256':code_bindings(),
        'formal_authority':load('frozen_c5_weight_grading/M08_C5_WEIGHT_GRADED_LOCAL_FUNCTIONAL_COMPLEX_CONTRACT_V2.json')['formal_authority'],
        'Sigma_canonical_sha256':sigma['canonical_action_sha256'],
        'obstruction': {'F':'integral L_c,a R_H^a','d':4,'gh':0,'w':4,
            'H_invariant':True,'minimal_horizontal':True,'physical_nonzero':True,
            'component':hbp['component'],'f_4_0_4':str(f044),'R4_u1_u26':str(r4),
            'Sigma_nonhorizontal_coefficient':hbp['negative_controls']['historical_Sigma_witness']['coefficient_of_g10_Lc4_c4']},
        'transport_no_go': {
            'status':'NO_EXISTING_ALPHABET_GRADE_COMPATIBLE_SOURCE_TRANSPORT_FOUND',
            'method':'EXHAUSTIVE_CONJUGACY_IDENTITY_NOT_FINITE_ANSATZ_SEARCH',
            'class':'All preregistered exact invertible equivalent transports of B, structural operators and the admitted old cochain domain; ST bracket transported if not preserved.',
            'identity':'(U iota U^-1)(U B U^-1)(U F_R) = U(iota B F_R)',
            'proof':'The inner U^-1 U pairs cancel. If the right side vanished, applying U^-1 would force the frozen nonzero defect to vanish.',
            'Cartan_relabeling':'An invertible domain equivalence intertwining B inherits the same failure; merely all invariants is a new domain, not an equivalent transport.',
            'ST_pairing':'For any U define bracket_T(a,b)=U bracket(U^-1 a,U^-1 b); this cannot change the conjugacy identity.',
            'new_structural_calculi_excluded':False,
            'scope_limit':'Does not exclude a genuinely different relative/BV domain, non-equivalent source calculus, or non-polynomial/nonlocal reformulation.'},
        'source_square': {'equation':'[B^2 Lc_p]_(g10^2 Lc_d c^a c^b) = (sum_k f^k_ab A_k^T - [A_a^T,A_b^T])_p,d, a<b',
            'selected':{'ghost_word':[a,b],'output_source_component':component,'remaining_source_component':source,
                'ghost_image_contribution':str(s.simplify(term1[component,source])),
                'source_image_contribution':str(s.simplify(term2[component,source])),
                'total_over_g10_squared':str(square[component,source])},
            'component_scope':'Isolated zero-derivative source coefficient, not a C5 differential composition or global nilpotence adjudication.',
            'coefficient_isolation': {'images_containing_Lc':carriers,'other_route':'No current image of another role contains Lc; non-self terms in B Lc cannot create the selected source coefficient.',
                'derivative_terms':'Cannot contribute to a zero-derivative coefficient; no explicit x or inverse derivatives.',
                'R_terms':'Contain u*u; selected coefficient has no heavy ghost.'}},
        'abstract_extension': {'implemented':False,'Cartan_identity_tested':'{iota_alpha,B}=g10 L_alpha',
            'chi': {'definition':'iota_alpha Lc_b','d':1,'gh':-3,'w':4,'Grassmann_parity':1,
                'Lorentz':'scalar','H_module':'adjoint-generator covector index tensor evaluation-dual adjoint-source index; covariance fixed by [L,iota] and L Lc',
                'Lie_rule':'L_a chi_b = f^k_ab chi_k + A_a^T chi_b',
                'required_B':'B chi_a = 2*g10*A_a^T*Lc - g10*c^b*A_b^T*chi_a + contractions of non-self source terms, if present'},
            'next_contraction': {'definition':'eta_ab=iota_a chi_b=-eta_ba','d':0,'gh':-4,'w':4,'Grassmann_parity':0,
                'third':'d=-1, gh=-5 forbidden by the preregistered nonnegative polynomial dimension filtration',
                'qualification':'Grade ceiling only; not proof that eta is nonzero or that a finite module exists.'},
            'no_go':'Any extension whose B restricts unchanged to old generators has the same nonzero B^2 Lc coefficient. It cannot be nilpotent full-Weil, or have only R-proportional equivariant curvature, since this coefficient survives at u=R=0.',
            'acyclicity':'NOT_QUALIFIED: a contractible differential extension satisfying these requirements is impossible before any homotopy solve; no certificate or source extension promoted.',
            'limits':'Does not exclude curved modules with additional curvature, an extension modifying old B images, or a different relative/BV formalism. These are not the authorized neutral repair.'},
        'catalog_impact_bounds': {'actual_new_recipes':0,'status':'CONDITIONAL_ONLY_NO_CONSISTENT_EXTENSION_CANDIDATE',
            'weight_argument':'Each chi or possible eta has weight 4. Every old independent field has weight >=0; thus at most one partner occurs in a weight<=4 monomial.',
            'minimal_chi_candidates': {'Cminus':'chi plus two d1 gh+1 ghosts, at most 3 occurrences',
                'Czero':'chi plus three d1 gh+1 ghosts, at most 4 occurrences',
                'Cplus':'chi plus four d1 gh+1 ghosts, at most 5 occurrences'},
            'possible_eta_candidates': {'Cminus':'eta plus three positive ghosts, at most 4 occurrences',
                'Czero':'eta plus four positive ghosts, at most 5 occurrences',
                'Cplus':'eta plus five positive ghosts, at most 6 occurrences'},
            'role_recipe_upper_bounds_chi_only':[3,4,5], 'role_recipe_upper_bounds_chi_plus_eta':[7,9,11],
            'bound_convention':'Zero-derivative partner-bearing role recipes with only the two weight-zero odd species c_L and u_H; before H/PQ/Lorentz/statistics. New symbols are not registered.',
            'component_upper_bounds_chi':[144*990,144*14190,144*148995],
            'component_bound_convention':'chi(12*12) times binomial(45,n), n=2,3,4; old light/heavy ghosts already odd. Bounds are before H invariants.',
            'internal_family_need':'New source-module representations and role words would need separate qualification; existing catalogs can be referenced, not assumed complete for partners.'},
        'comparator':comp, 'historical_ST_status':'ZERO_UNDER_ORIGINAL_DOMAIN_CUSTODY_ONLY',
        'ST_recomputed':False,'pole_payload_read':False,'new_source_variables':0,
        'H_basic_dimensions':None,'full_differential_matrices_constructed':False})


def adjudicate(primary,replay):
    assert primary['obstruction']['component'] == replay['component']
    assert primary['source_square']['selected'] == replay['source_square_selected']
    assert primary['obstruction']['Sigma_nonhorizontal_coefficient'] == replay['Sigma_nonhorizontal_coefficient']
    assert replay['conjugacy_counterexample_cannot_vanish'] and replay['comparator_pass']
    return seal({'status':'BLOCKED_STC_EQUIVALENT_TRANSPORT_AND_NEUTRAL_EXTENSION',
        'localized_blocker':BLOCKER,'current_blocker':'M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING',
        'primary_sha256':primary['artifact_sha256'],'replay_sha256':replay['artifact_sha256'],
        'primary_replay_agreement':'EXACT','outcome':'C_BOUNDED_FORMALISM_REDESIGN_REQUIRED',
        'transport_promoted':False,'acyclic_extension_spec_promoted':False,'HB1_authorized':False,
        'transport_result':primary['transport_no_go']['status'],
        'scope':'Equivalent transports of the rejected basic domain, and unchanged-old-B differential/curvature-only equivariant source extensions. Not every possible alternative cochain domain.',
        'next_decision':'Separately scope a relative/BV or other source-cochain formulation; do not patch signs, add partners or apply source-free Kalkman by fiat.',
        'stages': {'STC0':'PASS_FROZEN_OBSTRUCTION','STC1':'PASS_PREREGISTERED_EQUIVALENT_TRANSPORT_CLASS',
            'STC2':'PASS_SOURCE_FREE_COMPARATOR_ONLY','STC3':'NO_GO_BY_INVERTIBLE_CONJUGACY',
            'STC4':'NO_EQUIVALENT_INVARIANT_ONLY_DOMAIN_EARNED','STC5':'GENERAL_TRANSPORTED_BRACKET_CANNOT_REMOVE_DEFECT',
            'STC6':'BOUNDED_EXACT_NO_GO','STC7':'NECESSARY_PARTNER_GRADES_AND_INCONSISTENT_CLOSURE',
            'STC8':'NO_ACYCLIC_DIFFERENTIAL_EXTENSION_WITH_FIXED_OLD_B',
            'STC9':'CONDITIONAL_RECIPE_BOUNDS_ONLY','STC10':'STOP_BOUNDED_FORMALISM_REDESIGN'},
        'independence': {'ALGORITHM_INDEPENDENT':True,'CODE_PATH_INDEPENDENT':True,
            'LIBRARY_INDEPENDENT':False,'RUNTIME_INDEPENDENT':False,
            'limits':'Current-image AST/raw split tensors versus action right derivative/physical matrix Gram projection and separate exterior derivation. Shared inputs, Python/SymPy; conjugacy is the same mathematical theorem.'},
        'formal_authority':primary['formal_authority'],'H_basic_dimensions':None,
        'new_source_variables':0,'full_differential_matrices_constructed':False,'pole_payload_read':False})
