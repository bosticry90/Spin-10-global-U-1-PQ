"""Fast local-source evidence regressions; fresh construction is in the audit."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from audit_local_residual_cartan import compare,negative_controls
from partial_gauge_bv_bridge import GRADES
from partial_gauge_bv_bridge_replay import PartialWords
import local_residual_cartan_replay as replay


class LocalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        folder=Path(__file__).resolve().parent/"frozen_local_residual_cartan"
        cls.p=json.loads((folder/"primary.json").read_text())
        cls.r=json.loads((folder/"replay.json").read_text())
    def test_complete_comparison(self): compare(self.p,self.r)
    def test_28_adversarial_claims_rejected(self): self.assertEqual(negative_controls(self.p,self.r),28)
    def test_all_88_source_columns(self): self.assertEqual(len(self.p["images"])+len(self.p["minimal_images"]),88)
    def test_local_parameter_not_a_physical_generator(self): self.assertNotIn("omega",GRADES); self.assertEqual(len(GRADES),44)
    def test_affine_parameter_derivative_retained(self):
        self.assertEqual(self.p["local_action"]["independent_parameter_images"]["A20"],[{"coefficient":"1","word":["omega__0"]}])
    def test_canonical_source_evaluation_dual(self):
        self.assertEqual(self.p["local_action"]["independent_parameter_images"]["JA00"],[{"coefficient":"g","word":["JA10","omega"]}])
    def test_all_43_Cartan_generators_including_light_source(self):
        self.assertEqual(len(self.p["closure"]["all_43_base_generators"]),43)
        self.assertIn("Jc2",self.p["closure"]["all_43_base_generators"])
    def test_all_172_first_Cartan_jets(self): self.assertTrue(self.p["closure"]["all_172_first_jets"])
    def test_all_264_Q_checks(self): self.assertEqual(self.p["Q_squares"]["total"],264)
    def test_both_master_currents(self): self.assertEqual(set(self.p["master"]),{"minimal","partial_fixed"})
    def test_canonical_inverse_and_local_intertwining(self): self.assertTrue(self.p["transport"]["inverse_intertwining_local_equivariance"])
    def test_source_parameter_substitution_order_distinguished(self): self.assertTrue(self.p["closure"]["substitution_order_control"]["field_dependent_residual"])
    def test_old_connection_nonzero_result_preserved(self): self.assertTrue(self.p["historical_connection"]["actual_square"])
    def test_source_paired_witness_not_discarded(self): self.assertEqual(self.p["historical_connection"]["actual_square"],self.p["historical_connection"]["source_paired_nonzero_Euler"])
    def test_full_source_pair_local_action_matches_square(self): self.assertEqual(self.p["historical_connection"]["source_density_square"],self.p["historical_connection"]["full_local_source_density_action"])
    def test_quartic_ghost_coefficient(self): self.assertEqual(self.p["controls"]["quartic_density"],[{"coefficient":"-g**2*xi","word":["bar0","bar1","c0","c1"]}])
    def test_omitted_quartic_fails(self): self.assertTrue(self.p["controls"]["omitted_quartic_delta_residual"])
    def test_omitted_source_retains_free_failure(self): self.assertTrue(self.p["controls"]["omitted_partner_free_square"])
    def test_wrong_scalar_orientation_fails(self): self.assertTrue(self.p["controls"]["wrong_scalar_square"])
    def test_wrong_auxiliary_R_lift_fails(self): self.assertTrue(self.p["controls"]["omitted_R_auxiliary_square"])
    def test_nonzero_basic_controls(self): self.assertTrue(all(v["image"] for v in self.p["controls"]["basic_controls"].values()))
    def test_no_moment_or_EOM_quotient(self): self.assertTrue(self.p["closure"]["moment_constraint_not_imposed"]); self.assertFalse(self.p["EOM_used"])
    def test_M08_domain_not_inferred(self): self.assertFalse(self.p["domain"]["M08_H_basic_definition_certified"] or self.p["HB1_C5_authorized"])
    def test_authority_and_finite_threshold_unchanged(self): self.assertEqual(self.p["formal_authority"],"34/39_UNCHANGED"); self.assertIsNone(self.p["finite_C1_GS"])
    def test_external_review_not_invented(self): self.assertFalse(self.p["external_specialist_review"])
    def test_library_independence_not_invented(self): self.assertFalse(self.r["independence"]["LIBRARY_INDEPENDENT"])
    def test_replay_does_not_import_primary_model(self): self.assertNotIn("from local_residual_cartan import",inspect.getsource(replay))
    def test_general_word_bracket_canonical_orientation(self):
        w=PartialWords()
        for z,J in w.pairs:
            star=w.scale(w.var(J),(-1)**w.p[z])
            self.assertEqual(replay.bracket(w,w.var(z),star),{():1})
            self.assertEqual(replay.bracket(w,star,w.var(z)),{():-1})
    def test_dropped_source_column_rejected(self):
        bad=copy.deepcopy(self.p); del bad["images"]["Jc2"]
        with self.assertRaises(AssertionError): compare(bad,self.r)


if __name__=="__main__": unittest.main()
