"""Quantum-regulator, pole and normalization adversaries, with scope ceilings."""
import unittest
from copy import deepcopy
from a10_e5_ghost_normalization import *
from audit_a10_e5_ghost_normalization import adjudicate,execution_matches


class GhostNormalization(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.FP=read(OUT/'finite_primary.json');cls.FR=read(OUT/'finite_replay.json')
        cls.w=alphabet();register(cls.w,'rhoGhost',(0,0,0))
        cls.kappa=mat(cls.P['ghost_metric']['canonical_kappa']);cls.GI=mat(cls.P['ghost_metric']['old_width_metric'])

    def test_01_two_complete_derivation_routes(self):
        self.assertEqual(adjudicate(self.P,self.R,self.FP,self.FR)['scientific_gate'],STATUS)

    def test_02_complete_33_ghost_matrices_reproduce_pole(self):
        A=[mat(v) for v in self.P['ghost_metric']['canonical_ghost_operators']]
        K=cm(s.Matrix(33,33,lambda i,j:clean(-(A[i]*A[j]).trace())))
        self.assertEqual(K,self.kappa);self.assertTrue(all(clean(v.trace())==0 for v in A))

    def test_03_real_ray_ratios_exclude_uniform_width(self):
        rays=self.P['ghost_metric']['nonproportional_width_witnesses']
        self.assertEqual([v['ratio'] for v in rays],['8','24/5'])
        for r in rays:
            a=mat(r['physical_vector']);l=mat(r['dual_coordinates'])
            self.assertEqual(a.conjugate(),a)
            self.assertEqual(clean((l.T*self.kappa*l)[0]/(l.T*self.GI*l)[0]),s.sympify(r['ratio']))

    def test_04_uniform_fitted_eight_leaves_exact_residual(self):
        self.assertTrue(cm(self.kappa-8*self.GI).todok())
        self.assertFalse(self.P['ghost_metric']['literal_auxiliary_single_delta_xi_sufficient'])

    def test_05_missing_H_Casimir_is_detected(self):
        m=self.P['ghost_metric'];real=mat(m['real_orthonormal_kappa']);CH=mat(m['H_Casimir'])
        self.assertEqual(real,cm(8*s.eye(33)-2*CH))
        self.assertNotEqual(real,8*s.eye(33));self.assertTrue(CH.todok())

    def test_06_complete_positive_relative_spectrum(self):
        spectrum=self.P['ghost_metric']['relative_width_spectrum']
        self.assertEqual(spectrum,[['3',12],['19/5',12],['24/5',6],['34/5',2],['8',1]])
        self.assertEqual(sum(n for v,n in spectrum),33)
        self.assertEqual(sum(s.sympify(v)*n for v,n in spectrum),132)

    def test_07_full_H_dual_metric_identity(self):
        for v in self.P['ghost_metric']['H_dual_matrices']:
            D=mat(v);self.assertFalse(cm(D.T*self.kappa+self.kappa*D).todok())
        self.assertFalse(cm(self.kappa-self.kappa.T).todok())

    def test_08_Berezin_sign_and_nonzero_pole(self):
        r=self.P['loop_residue'];self.assertEqual(r['Euclidean_scalar_bubble_residue'],'1/(16*pi**2)')
        self.assertEqual(r['finite_Berezin_determinant_control'],'a_ctl**2*xi**2/p_squared_ctl**2 + 1')
        self.assertTrue(self.P['subtraction']['pole_metric_density_normalized'])

    def test_09_BRST_primitive_wrong_sign_does_not_cancel(self):
        w=self.w;S=self.P['subtraction'];psi=decode_typed(S['primitive_normalized']);L=decode_typed(S['pole_metric_density_normalized'])
        Q={f'ub{i}':w.scale(w.var(f'L{i}'),-1) for i in M}
        correct=act(psi,w,Q,'replay',1)
        self.assertFalse(canonical(w.add(correct,L)))
        self.assertEqual(canonical(w.add(w.scale(correct,-1),L)),canonical(w.scale(L,2)))

    def test_10_actual_linear_BRST_and_background_alphabet(self):
        c=self.P['explicit_regulator'];self.assertEqual(c['field_columns_nilpotent'],643)
        self.assertEqual(c['first_jet_commutation_checks'],2572)
        self.assertEqual(c['all_BV_sources_retained'],643);self.assertEqual(c['external_backgrounds'],48)
        self.assertEqual(c['background_B_minus_A_shift_invariant'],48)

    def test_11_regulated_auxiliary_inverse_zero_at_arbitrary_width(self):
        c=self.P['explicit_regulator'];K=mat(c['quadratic_kernel']);D=mat(c['quadratic_inverse'])
        self.assertEqual(cm(K*D),s.eye(5));self.assertEqual(cm(D*K),s.eye(5));self.assertEqual(D[4,4],0)
        self.assertTrue(c['non_Gaussian_interactions_retained'])

    def test_12_expected_geometric_quantum_breaking_retained(self):
        c=self.P['explicit_regulator'];self.assertTrue(c['geometric_quantum_breaking_control'])
        self.assertTrue(c['breaking_auxiliary_Euler'])
        self.assertFalse(c['g_nonzero_regulator_restoration_proved'])

    def test_13_explicit_finite_nonlocal_amplitude(self):
        F=s.sympify(self.FP['analytic_minimal_subtracted_bubble']);q=s.Symbol('q_E_squared')
        self.assertEqual(clean(s.diff(F,q)),-1/(16*s.pi**2*q))
        self.assertNotEqual(s.diff(F,q),0);self.assertTrue(self.FP['logarithmic_kernel_is_nonlocal'])

    def test_14_local_finite_scheme_difference_is_not_forced_zero(self):
        a=s.sympify(self.FP['analytic_minimal_subtracted_bubble']);b=s.sympify(self.FR['dimensional_modified_minimal_subtracted_bubble'])
        self.assertEqual(clean(b-a),1/(16*s.pi**2))
        self.assertFalse(self.FP['scheme_adopted_as_unique_project_prescription'])

    def test_15_explicit_one_and_two_insertion_contact_coefficients(self):
        w=self.w;v=self.P['subtraction'];L=decode_typed(v['pole_metric_density_normalized']);first=decode_typed(v['first_insertion_pole_normalized']);second=decode_typed(v['second_contact_pole_normalized'])
        self.assertFalse(canonical(w.add(second,w.scale(L,2))))
        self.assertFalse(canonical(w.add(first,w.scale(w.mul(w.add({():1},w.var('rhoGhost')),L),2))))
        self.assertNotEqual(second,w.scale(L,-1));self.assertTrue(v['third_and_higher_probe_poles_zero'])

    def test_16_source_independent_selected_counterterms(self):
        for key in ('primitive_normalized','subtraction_with_probe_normalized','first_insertion_pole_normalized','second_contact_pole_normalized'):
            for word in decode_typed(self.P['subtraction'][key]):self.assertFalse(any(n.startswith('J') for n,j in word))
        self.assertTrue(self.P['subtraction']['this_selected_subtraction_and_probe_family_source_independent'])

    def test_17_torsion_insertion_and_quantum_equivalence_not_overclaimed(self):
        self.assertTrue(self.P['named_unweighted_F_ordinary_g0_source_correction_excluded_in_this_family'])
        self.assertFalse(self.P['named_F_as_operator_insertion_universally_excluded'])
        self.assertFalse(self.P['weighted_gF_quantum_A5_equivalence_proved'])

    def test_18_M2_M4_and_authority_overclaims_rejected(self):
        for key in ('M2_complete_quantum_prescription_nonempty_proved','M4_all_insertions_and_contacts_proved','A1_A5_discharged','full_E5_PASS','sources_activated'):
            a=deepcopy(self.P);b=deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b,self.FP,self.FR)

    def test_19_start_bindings_reject_stale_main_and_finite_input(self):
        for prefix in ('','finite_'):
            r=next(read(p) for p in OUT.glob(prefix+'primary_attempt_*.json') if read(p)['completed_evidence'])
            execution_matches(r['fingerprint'],bool(prefix));bad=deepcopy(r['fingerprint'])
            bad['main_input_sha256' if prefix else 'state_sha256']='stale'
            with self.assertRaises(AssertionError):execution_matches(bad,bool(prefix))

    def test_20_IR_and_scalar_closure_are_explicitly_unresolved(self):
        self.assertFalse(self.P['explicit_regulator']['physical_IR_limit_proved'])
        self.assertFalse(self.P['explicit_regulator']['global_scalar_subtraction_and_parameter_closure_proved'])
        self.assertFalse(self.FP['full_IR_limit_proved'])
        self.assertFalse(self.P['C1_GS_calculated']);self.assertFalse(self.P['physical_matching_computed'])


if __name__=='__main__':unittest.main()
