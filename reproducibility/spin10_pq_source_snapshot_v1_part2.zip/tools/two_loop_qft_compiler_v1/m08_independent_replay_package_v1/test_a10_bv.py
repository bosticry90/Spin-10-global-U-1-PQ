"""Adversarial checks for the bounded prerequisite failure, not full BV PASS."""
import unittest
import sympy as s
from a10_executable_action import HERE,read,digest,mat
OUT=HERE/'frozen_a10_bv_master'
class BVStopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=read(OUT/'primary.json');cls.r=read(OUT/'replay.json')
        cls.w=read(OUT/'physical.json');cls.i=read(OUT/'gauge_euler_replay.json')
        cls.c=read(OUT/'M08_CANONICAL_BV_CANDIDATE_UNQUALIFIED_V1.json')
    def test_exact_smallest_witness(self):
        row=self.w['smallest_witness']
        self.assertEqual(row['physical_density'],[{'word':['b__0','b__0'],'coefficient':'1/2'}])
        self.assertEqual(row['canonical_Euler'],[{'word':['b__00'],'coefficient':'-1'}])
        self.assertEqual(row['indexed_Euler_generic'],[{'word':['b__00'],'coefficient':'1'}])
        self.assertEqual(row['indexed_Euler_lorentz'],row['indexed_Euler_generic'])
    def test_all_lorentz_directions_including_zero(self):
        self.assertEqual(len(self.w['comparisons']),16)
        self.assertEqual(sum(not r['match'] for r in self.w['comparisons']),9)
        for r in self.w['comparisons']:
            if r['connection_component']==r['ordinary_jet_direction']:
                self.assertEqual(r['canonical_Euler'],[]);self.assertEqual(r['indexed_Euler_generic'],[])
    def test_independent_physical_replay(self):
        self.assertFalse(self.i['indexed_helper_imported'])
        self.assertEqual(self.i['smallest_witness']['canonical_Euler_coefficient'],'-1')
        self.assertFalse(self.i['EOM_used'])
    def test_boundary_does_not_change_Euler(self):
        h,dh,b1,b2=s.symbols('h dh b1 b2')
        variation=b1*dh;boundary_derivative=b1*dh+b2*h
        self.assertEqual(s.expand(variation-boundary_derivative),-b2*h)
        self.assertEqual(s.diff(2*b2*h,h),2*b2) # difference is not a boundary for arbitrary h
    def test_uniform_metric_shortcut_fails_nonlinearly(self):
        c=self.w['nonlinear_metric_shortcut_control']
        self.assertFalse(c['uniform_metric_shortcut_agrees'])
        self.assertEqual(c['indexed_Euler_B1_T02'],c['canonical_Euler_B1_T02'])
        for k in ('physical_density','canonical_Euler_B1_T02'):
            self.assertEqual(c[k],self.i['nonlinear_10x10_matrix_control'][k])
    def test_all_source_only_columns_independently_compared(self):
        self.assertEqual(self.p['source_only_columns'],self.r['source_only_columns'])
        self.assertEqual(len(self.p['source_only_columns']),1286)
        self.assertEqual(self.p['source_polynomial'],self.r['source_polynomial'])
    def test_canonical_frame_inverse_and_pairing(self):
        a=self.p['architecture'];Q=mat(a['C3_to_plane_field']);Qi=mat(a['plane_to_C3_field'])
        self.assertEqual(Qi*Q,s.eye(45))
        self.assertEqual(mat(a['C3_to_plane_source']).T*Q,s.eye(45))
        self.assertNotEqual(mat(a['gauge_metric_C3']),s.eye(45))
    def test_complete_alphabet_and_grading(self):
        rows=self.p['architecture']['pairs'];self.assertEqual(len(rows),643)
        for z,J,(d,gh,p),grade in rows:self.assertEqual(grade,[3-d,-1-gh,1-p])
        self.assertEqual(sum(z.startswith('B') for z,_,_,_ in rows),180)
        self.assertEqual(sum(z.startswith('x_') for z,_,_,_ in rows),328)
    def test_nonsymmetric_coset_retained(self):
        f={(k,a,b):s.sympify(v) for k,a,b,v in self.p['geometry']['f']}
        self.assertEqual(f[12,13,44],-4*s.sqrt(2)*s.I/5)
        col=self.p['source_only_columns']['C12']
        found=next(r for r in col if r['word']==['C13','C44'])
        self.assertEqual(s.sympify(found['coefficient']),4*s.sqrt(2)*s.I*s.Symbol('g10')/5)
    def test_physical_terms_and_parameters_preserved(self):
        old=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
        self.assertEqual(self.c['physical_origin_sha256'],digest(old))
        self.assertEqual(self.c['parameters'],old['parameter_coordinates'])
        self.assertEqual(self.c['local_terms'][5:34],old['local_terms'][5:34])
        self.assertEqual(len(self.c['local_terms']),43)
    def test_source_only_singlet_columns_not_physical_Euler(self):
        self.assertEqual(self.p['source_only_columns']['x_S_0'],[])
        self.assertEqual(self.p['source_only_columns']['Jx_S_0'],[])
        self.assertIn('physical Euler',self.p['full_columns_recipe'])
    def test_stop_gate_and_no_activation(self):
        for flag in ('full_master_equation_established','full_source_nilpotence_established',
                     'Stage_E_reached','sources_activated','adopted','HB1_C5_authorized'):
            self.assertFalse(self.c[flag])
        self.assertEqual(self.c['status'],'UNQUALIFIED_STOP_GATE_3')
if __name__=='__main__':unittest.main()
