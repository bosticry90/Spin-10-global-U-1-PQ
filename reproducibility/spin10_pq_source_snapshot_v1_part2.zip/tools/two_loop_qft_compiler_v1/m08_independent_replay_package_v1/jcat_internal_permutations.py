"""Small exact covector recoupling blocks. No physical action or loop inputs.

S[target,source] pulls an ordered source covector through a slot swap and
expands it in the unchanged canonical target fusion tree. Copy indices and
U(1)/PQ labels are spectators, relocated with the corresponding occurrence.
"""
from functools import lru_cache
from itertools import product, permutations
from collections import Counter
from math import prod
import sympy as sp
from scalar_bridge_primary_v3 import qualified_duals
from int8_block_conjugation_v2 import BlockConjugation
from execute_scalar_ast_channel_bridge import serialize


def coordinates(index, dimensions):
    out = []
    for size in reversed(dimensions):
        index, digit = divmod(index, size)
        out.append(digit)
    assert index == 0
    return tuple(reversed(out))


def flat(digits, dimensions):
    out = 0
    for digit, size in zip(digits, dimensions):
        out = out * size + digit
    return out


class FactorPermutations:
    def __init__(self, duals, group):
        self.group = group
        self.cs = duals.c3 if group == 'SU3' else duals.c2
        self.ds = duals.d3 if group == 'SU3' else duals.d2
        self.js = duals.j3 if group == 'SU3' else duals.j2
        self.fs = duals.f3 if group == 'SU3' else duals.f2
        self.scalar = (0, 0) if group == 'SU3' else 0

    def dual(self, label):
        return (label[1], label[0]) if self.group == 'SU3' else label

    @lru_cache(None)
    def basis(self, labels):
        n = len(labels)
        dims = tuple(self.fs[r]['dimension'] for r in labels)
        rows = []
        if n < 2:
            if not labels or labels[0] == self.scalar:
                rows.append(((), sp.ones(1, 1)))
            return dims, rows
        for (a, b, o), ds in sorted(self.ds.items()):
            if (a, b) != labels[:2]:
                continue
            if n == 2 and o != self.scalar:
                continue
            if n == 3 and self.dual(o) != labels[2]:
                continue
            rds = self.ds.get((labels[2], labels[3], self.dual(o)), []) if n == 4 else [None]
            for i, d in enumerate(ds):
                for j, rd in enumerate(rds):
                    mat = d if n == 2 else d.T * self.js[o].T if n == 3 else d.T * self.js[o].T * rd
                    values = {(r * mat.cols + c, 0): v for (r, c), v in sp.SparseMatrix(mat).todok().items()}
                    rows.append(((o, i, j), sp.ImmutableSparseMatrix(prod(dims), 1, values)))
        return dims, rows

    def swapped(self, tensor, dims, i):
        target = list(dims)
        target[i], target[i+1] = target[i+1], target[i]
        values = {}
        for (r, _), v in tensor.todok().items():
            digits = list(coordinates(r, dims))
            digits[i], digits[i+1] = digits[i+1], digits[i]
            values[flat(digits, target), 0] = v
        return sp.ImmutableSparseMatrix(prod(dims), 1, values)

    @lru_cache(None)
    def swap(self, labels, i):
        dims, source = self.basis(labels)
        target_labels = list(labels)
        target_labels[i], target_labels[i+1] = target_labels[i+1], target_labels[i]
        target_labels = tuple(target_labels)
        tdims, target = self.basis(target_labels)
        assert len(source) == len(target), (self.group, labels, i, 'cardinality')
        n = len(labels)
        result = sp.zeros(len(target), len(source))
        for si, (_, vector) in enumerate(source):
            transformed = self.swapped(vector, dims, i)
            tensor = sp.SparseMatrix(prod(tdims[:2]), prod(tdims[2:]),
                {(r // prod(tdims[2:]), r % prod(tdims[2:])): v for (r, _), v in transformed.todok().items()})
            for ti, (key, _) in enumerate(target):
                o, a, b = key
                cl = self.cs[(target_labels[0], target_labels[1], o)][a]
                block = transformed.T * cl if n == 2 else cl.T * tensor
                if n == 4:
                    block = block * self.cs[(target_labels[2], target_labels[3], self.dual(o))][b]
                if n == 2:
                    assert block.shape == (1, 1)
                    value = block[0, 0]
                else:
                    scaled = block * self.js[o].T.inv()
                    value = scaled.trace() / scaled.rows
                    assert scaled == value * sp.eye(scaled.rows), (self.group, labels, i, 'Schur')
                result[ti, si] = value
            reconstructed = sum((result[t, si] * v for t, (_, v) in enumerate(target)), sp.zeros(prod(tdims), 1))
            assert reconstructed == transformed, (self.group, labels, i, 'full covector reconstruction')
        return sp.ImmutableSparseMatrix(result)

    def qualify(self, labels):
        size = len(self.basis(labels)[1])
        for i in range(len(labels)-1):
            target = list(labels)
            target[i], target[i+1] = target[i+1], target[i]
            assert self.swap(tuple(target), i) * self.swap(labels, i) == sp.eye(size)
        def path(indices):
            current = list(labels)
            matrix = sp.eye(size)
            for i in indices:
                matrix = self.swap(tuple(current), i) * matrix
                current[i], current[i+1] = current[i+1], current[i]
            return tuple(current), matrix
        for i in range(len(labels)-2):
            assert path([i,i+1,i]) == path([i+1,i,i+1])
        for i in range(len(labels)-1):
            for j in range(i+2,len(labels)-1):
                assert path([i,j]) == path([j,i])
        return size


def demand_patterns(catalog):
    patterns = {'SU3': set(), 'SU2': set()}
    families = []
    for fid, desc in catalog.descriptors.items():
        seen = set()
        total = 0
        for key, cardinality, _, _ in catalog.blocks(desc):
            slots = tuple(catalog.block_slots(desc, key))
            if slots in seen:
                continue
            seen.add(slots)
            labels = [catalog.by_id[c]['H_label'] for c in slots]
            patterns['SU3'].add(tuple(tuple(r[:2]) for r in labels))
            patterns['SU2'].add(tuple(r[2] for r in labels))
            total += 1
        families.append({'family_id':fid, 'slot_irrep_blocks':total,
                         'address_count':desc['addressable_invariant_count']})
    return patterns, families


def generate():
    catalog = BlockConjugation.from_frozen()
    patterns, families = demand_patterns(catalog)
    duals = catalog.duals
    records = []
    for group in ('SU3','SU2'):
        engine = FactorPermutations(duals, group)
        for ordinal, labels in enumerate(sorted(patterns[group])):
            if len(labels) < 2:
                continue
            size = engine.qualify(labels)
            records.append({'group':group,'labels':labels,'invariant_dimension':size,
                'basis_keys':[key for key,_ in engine.basis(labels)[1]],
                'adjacent_transpositions':[serialize(engine.swap(labels,i)) for i in range(len(labels)-1)],
                'full_tensor_reconstruction':'ZERO_EXACT','Coxeter_residual':'ZERO_EXACT'})
            if ordinal % 25 == 0:
                print('JCAT4_LOCAL_BLOCK',group,ordinal,len(patterns[group]),size,flush=True)
    return {'status':'PASS_LOCAL_FACTOR_RECOUPLING', 'factor_blocks':records,
            'families':families,'canonical_basis_changed':False,
            'copy_action':'Relocate the whole occurrence copy index, no Grassmann sign',
            'U1_PQ_action':'Relocate labels with slots; admissible total charges remain zero',
            'global_matrix_materialized':False}


def permutation_word(perm):
    """Target slot j contains old slot perm[j]."""
    current = list(range(len(perm))); word = []
    for j, old in enumerate(perm):
        k = current.index(old)
        while k > j:
            current[k-1],current[k] = current[k],current[k-1]
            word.append(k-1); k -= 1
    assert tuple(current) == tuple(perm)
    return word


def permutation_matrix(engine, labels, perm):
    current = list(labels); result = sp.eye(len(engine.basis(tuple(labels))[1]))
    for i in permutation_word(perm):
        result = engine.swap(tuple(current),i) * result
        current[i],current[i+1] = current[i+1],current[i]
    return sp.ImmutableSparseMatrix(result)


class InternalPermutation:
    def __init__(self):
        self.catalog = BlockConjugation.from_frozen()
        self.engines = {g:FactorPermutations(self.catalog.duals,g) for g in ('SU3','SU2')}
        self.unique = {}
        for fid,desc in self.catalog.descriptors.items():
            self.unique[fid] = sorted({tuple(self.catalog.block_slots(desc,key))
                                      for key,_,_,_ in self.catalog.blocks(desc)})

    @lru_cache(None)
    def local(self, labels, perm):
        a = tuple(tuple(r[:2]) for r in labels); b = tuple(r[2] for r in labels)
        return (permutation_matrix(self.engines['SU3'],a,perm),
                permutation_matrix(self.engines['SU2'],b,perm))

    def image(self,address,perm):
        c = self.catalog
        desc,key,slots,copies,left,right,a,b = c.address_parts(address)
        f = tuple(desc['ordered_character_families']); n = desc['arity']
        assert sorted(perm) == list(range(n)) and tuple(f[i] for i in perm) == f
        if n < 2:
            yield address,sp.Integer(1); return
        labels = tuple(tuple(c.by_id[cid]['H_label']) for cid in slots)
        old3 = tuple(r[:2] for r in labels); old2 = tuple(r[2] for r in labels)
        e3,e2 = self.engines['SU3'],self.engines['SU2']
        k3 = (tuple(left['output_H_label'][:2]),a,b)
        k2 = (left['output_H_label'][2],0,0)
        i3 = [k for k,_ in e3.basis(old3)[1]].index(k3)
        i2 = [k for k,_ in e2.basis(old2)[1]].index(k2)
        m3,m2 = self.local(labels,tuple(perm))
        targetslots = tuple(slots[i] for i in perm); targetcopies = [copies[i] for i in perm]
        new3 = tuple(old3[i] for i in perm); new2 = tuple(old2[i] for i in perm)
        for j3,(tk3,_) in enumerate(e3.basis(new3)[1]):
            for j2,(tk2,_) in enumerate(e2.basis(new2)[1]):
                coefficient = m3[j3,i3] * m2[j2,i2]
                if coefficient == 0:
                    continue
                output = (*tk3[0],tk2[0],sum(labels[i][3] for i in perm[:2]))
                targetkey = c.address_lookup[desc['family_id']][(targetslots,output)]
                aa,bb = tk3[1:]
                digits = [*targetcopies,aa] if n==2 else [targetcopies[0],targetcopies[1],aa,targetcopies[2]] if n==3 else [targetkey[1],targetkey[2],targetcopies[0],targetcopies[1],aa,targetcopies[2],targetcopies[3],bb]
                yield {'family_id':desc['family_id'],'terminal_channel_index':targetkey[0],'digits':digits},coefficient

    @lru_cache(None)
    def trace(self,fid,perm):
        if tuple(perm) == tuple(range(len(perm))):
            return sp.Integer(self.catalog.descriptors[fid]['addressable_invariant_count'])
        total = 0
        for slots in self.unique[fid]:
            if tuple(slots[i] for i in perm) != slots:
                continue
            labels = tuple(tuple(self.catalog.by_id[cid]['H_label']) for cid in slots)
            m3,m2 = self.local(labels,perm)
            visited = set(); copies = 1
            for i,cid in enumerate(slots):
                if i not in visited:
                    copies *= self.catalog.by_id[cid]['copy_multiplicity']
                    j=i
                    while j not in visited:
                        visited.add(j);j=perm[j]
            total += copies*m3.trace()*m2.trace()
        return sp.Integer(total)

    def coverage(self):
        rows=[]
        for fid,desc in self.catalog.descriptors.items():
            dimensions=Counter()
            for key,card,_,_ in self.catalog.blocks(desc):
                dimensions[tuple(self.catalog.block_slots(desc,key))]+=card
            count=0
            for slots,expected in dimensions.items():
                labels=[self.catalog.by_id[c]['H_label'] for c in slots]
                copies=prod(self.catalog.by_id[c]['copy_multiplicity'] for c in slots)
                n3=len(self.engines['SU3'].basis(tuple(tuple(r[:2]) for r in labels))[1])
                n2=len(self.engines['SU2'].basis(tuple(r[2] for r in labels))[1])
                assert expected==copies*n3*n2,(fid,slots,'factor/address dimension')
                count+=expected
            assert count==desc['addressable_invariant_count']
            rows.append({'family_id':fid,'ordered_dimension':count,'component_tuple_blocks':len(dimensions),
                         'SU3_SU2_copy_factor_address_cardinality':'ZERO_EXACT'})
        # Physical permutations commute with physical conjugation. Verify the
        # consequential mixed octet coefficient map, including copy transport.
        fid='INV_S_S_S';desc=self.catalog.descriptors[fid]
        selected=next((key for key,_,_,_ in self.catalog.blocks(desc)
                       if all(tuple(self.catalog.by_id[c]['H_label'][:3])==(1,1,0)
                              and self.catalog.by_id[c]['source_sector']=='Phi'
                              for c in self.catalog.block_slots(desc,key))))
        address=next(self.catalog.addresses(fid,selected));perm=(0,2,1)
        def identity(a):return a['family_id'],a['terminal_channel_index'],tuple(a['digits'])
        left=Counter();right=Counter()
        for p,v in self.image(address,perm):
            for q,w in self.catalog.image(p):left[identity(q)]+=sp.conjugate(v)*w
        for q,w in self.catalog.image(address):
            for p,v in self.image(q,perm):right[identity(p)]+=w*v
        assert all(sp.simplify(left[k]-right[k])==0 for k in set(left)|set(right))
        return {'status':'PASS_FACTORIZED_COMPLETE_ADDRESS_COVERAGE',
                'family_count':len(rows),'families':rows,'mixed_octet_conjugation_commutation':'ZERO_EXACT',
                'image_API':'InternalPermutation.image(address, target_slot_order)',
                'map_typing':'source covector -> permuted target covector coordinates',
                'canonical_addresses_rotated':False}


def stabilizer_elements(names):
    classes = [tuple(i for i,n in enumerate(names) if n==name) for name in dict.fromkeys(names)]
    for choices in product(*(permutations(c) for c in classes)):
        perm = list(range(len(names)))
        for positions,values in zip(classes,choices):
            for i,j in zip(positions,values): perm[i]=j
        yield tuple(perm)


def partitions(m):
    return {1:[(1,)],2:[(2,),(1,1)],3:[(3,),(2,1),(1,1,1)],
            4:[(4,),(3,1),(2,2),(2,1,1),(1,1,1,1)]}[m]


def specht_character(part, perm):
    m=len(perm); fixed=sum(i==j for i,j in enumerate(perm))
    sign=(-1)**sum(perm[i]>perm[j] for i in range(m) for j in range(i+1,m))
    if part==(m,): return 1
    if part==(1,)*m: return sign
    if part==(m-1,1): return fixed-1
    if part==(2,1,1): return sign*(fixed-1)
    assert m==4 and part==(2,2)
    pairs=[(i,j) for i in range(4) for j in range(i+1,4)]
    pairfixed=sum(tuple(sorted((perm[i],perm[j])))==(i,j) for i,j in pairs)
    return pairfixed-fixed


def young_ledger(engine, rows):
    out=[]
    for number,row in enumerate(rows):
        names=row['ordered_symbol_names']; fid=row['G_sig']['family_id']
        elements=list(stabilizer_elements(names)); traces=[engine.trace(fid,p) for p in elements]
        classes=[tuple(i for i,n in enumerate(names) if n==name) for name in dict.fromkeys(names)]
        blocks=[]
        for multi in product(*(partitions(len(c)) for c in classes)):
            chars=[]
            for p in elements:
                chars.append(sp.prod(specht_character(part,tuple(c.index(p[i]) for i in c)) for part,c in zip(multi,classes)))
            multiplicity=sp.Rational(sum(t*x for t,x in zip(traces,chars)),len(elements))
            assert multiplicity.is_Integer and multiplicity>=0
            dim=chars[0]
            if multiplicity:
                blocks.append({'multipartition':multi,'multiplicity':int(multiplicity),'Specht_dimension':int(dim)})
        assert sum(b['multiplicity']*b['Specht_dimension'] for b in blocks)==row['G_sig']['ordered_dimension']
        out.append({'signature_id':row['signature_id'],'family_id':fid,'group_order':len(elements),
                    'elements':elements,'internal_traces':[int(t) for t in traces],'Young_blocks':blocks,
                    'dimension_reconstruction':'ZERO_EXACT','statistics_projected':False})
        if number%50==0: print('JCAT6_SIGNATURE',number,flush=True)
    return {'status':'PASS_EXACT_INTERNAL_YOUNG_DECOMPOSITION','signature_count':len(out),'rows':out}
