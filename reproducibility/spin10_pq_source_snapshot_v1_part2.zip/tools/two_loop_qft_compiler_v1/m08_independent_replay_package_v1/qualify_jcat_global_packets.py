"""Adjudicate the frozen JCAT7 constructions; never overwrite evidence."""
from hashlib import sha256
from jcat_global_packets import *
from execute_jcat_global_packets import freeze, bindings

PROMOTION = 'M08_JCAT7_COMPLETE_BACKGROUND_COVARIANT_PACKET_BASIS_V1'


def evidence():
    construction = load(OUT/'JCAT7G_construction_checkpoint.json')
    assert construction['status'] == 'PASS_GLOBAL_CLASS_CONSTRUCTION_PENDING_PHYSICAL_CONTROLS'
    assert construction['failure'] is None and construction['formal_authority'] == AUTHORITY
    for name, h in construction['artifacts'].items():
        assert sha256((OUT/name).read_bytes()).hexdigest() == h, name
    custody = load(OUT/'JCAT7G_custody.json')
    assert custody['immutable_input_byte_hashes'] == bindings()
    # The incoming qualified custody is itself hash-bound above. Verify its
    # transitive inputs rather than merely retaining their recorded digests.
    for name in ('JCAT7V3_custody.json','JCAT7V3_physical_action_custody.json'):
        for path,h in load(OLD/name)['source_byte_hashes'].items():
            assert sha256((HERE/path).read_bytes()).hexdigest()==h,path
    census = load(OUT/'JCAT7G_class_census.json')
    ledger = load(OUT/'JCAT7G_completeness_ledger.json')
    assert ledger['status'] == 'PASS_COMPLETE_CLASS_MUTUAL_SPANS'
    assert ledger['completed_classes'] == ledger['expected_classes'] == len(census['classes']) == 362
    rows = ledger['rows']
    assert [r['class_id'] for r in rows] == [r['class_id'] for r in census['classes']]
    signatures = {m['signature_id'] for r in rows for m in r['members']}
    assert len(signatures) == census['signature_count'] == 431
    assert sum(r['ORDERED_COORDINATE_DIMENSION'] for r in rows) == 369980
    assert sum(r['REALIZATION_NULLITY'] for r in rows) == 1356
    assert sum(r['REALIZED_TAGGED_DIMENSION'] for r in rows) == 368624
    assert sum(r['PRIMARY_REALIZED_PACKET_RANK'] for r in rows) == 359524
    blocks = 0
    for row in rows:
        assert row['PRIMARY_REALIZED_PACKET_RANK'] == row['replay_kernel_dimension']
        assert row['ORDERED_COORDINATE_DIMENSION'] == row['REALIZATION_NULLITY']+row['REALIZED_TAGGED_DIMENSION']
        if row['trivial_singleton']:
            assert row['status'] == 'PASS_EXACT_SINGLETON_COVARIANCE'
            assert row['mutual_span_residual'] == 'ZERO_EXACT'
            assert row['PRIMARY_REALIZED_PACKET_RANK'] == row['REALIZED_TAGGED_DIMENSION']
        else:
            assert row['status'] == 'PASS_EXACT_GLOBAL_CLASS'
            for block in row['blocks']:
                primary = load(OUT/block['primary']); replay = load(OUT/block['replay'])
                result = load(OUT/block['acceptance'])
                q=matrix(primary['quotient_map']); section=matrix(primary['section'])
                n=matrix(primary['realization_null_basis'])
                raw=matrix(replay['independent_variation_equations'])
                induced=matrix(replay['faithful_variation_equations']); kernel=matrix(replay['faithful_kernel'])
                assert q*section==sp.eye(q.rows) and q*n==sp.zeros(q.rows,n.cols)
                assert n.rank()==n.cols and q.rows+n.cols==q.cols
                assert raw*n==sp.zeros(raw.rows,n.cols) and raw*section*q==raw
                assert (raw*section).col_join(induced).rank()==induced.rows==induced.rank()
                assert induced*kernel==sp.zeros(induced.rows,kernel.cols)
                assert kernel.rank()==kernel.cols==q.rows-induced.rows
                assert replay['raw_kernel_dimension']==q.cols-raw.rank()==kernel.cols+n.cols
                assert result['artifact_sha256'] == canonical(compare_blocks(primary, replay))
                assert result['status'] == 'PASS_EXACT_PRIMARY_REPLAY_MUTUAL_SPAN'
                assert not result['extra_faithful_replay_direction'] and not result['noncovariant_primary']
                assert replay['quotient_descent'] == replay['q_raw_kernel_equals_induced_kernel'] == 'ZERO_EXACT'
                blocks += 1
    assert blocks == 2524
    physical = load(OUT/'JCAT7G_physical_control_acceptance.json')
    assert physical['status'] == 'PASS_ALL_PREREGISTERED_PHYSICAL_CONTROLS'
    assert len(physical['cases']) == 4 and not physical['primary_coefficients_imported_in_physical_solve']
    for case in physical['cases']:
        assert case['physical_primary_mutual_span'] == case['physical_quotient_agreement'] == 'ZERO_EXACT'
        record = load(OUT/(case['block_id']+'_physical_closed.json'))
        assert record['complete_component_reconstruction'] == 'ZERO_EXACT'
        assert not record['primary_coefficients_imported'] and not record['primary_formal_realization_imported']
    curvature = load(OUT/'JCAT7G_curvature_covariance.json')
    assert curvature['status'] == 'PASS_DERIVED_CURVATURE_AFFINE_COVARIANCE'
    assert curvature['delta_F_minus_theta_commutator_F'] == '0'
    known = load(OUT/'JCAT7G_known_control_recovery.json')
    w = known['witness']
    assert [w[k] for k in ('ordered_dimension','realization_rank','realization_nullity','raw_kernel_dimension','faithful_kernel_dimension')] == [9,8,1,4,3]
    assert w['zero_direction']['status'] == 'REALIZATION_NULL_NONZERO_EXPANSION_NEGATIVE_CONTROL'
    assert known['kinetic']['individual_witness_variations'] == [2,2,-4]
    assert known['kinetic']['combined_variation'] == 0 and known['original_witness_unchanged']
    parity = {p: sum(r['PRIMARY_REALIZED_PACKET_RANK'] for r in rows if r['parity'] == p)
              for p in ('PARITY_EVEN','PARITY_ODD')}
    assert parity == {'PARITY_EVEN':358444,'PARITY_ODD':1080}
    return {'signature_count':431,'completion_class_count':362,
        'singleton_class_count':sum(r['trivial_singleton'] for r in rows),
        'active_completion_class_count':sum(not r['trivial_singleton'] for r in rows),
        'active_carrier_copy_block_count':blocks,'ORDERED_COORDINATE_DIMENSION':369980,
        'EXPANSION_ADDRESS_COUNT':369980,'REALIZATION_NULLITY':1356,
        'REALIZED_TAGGED_DIMENSION':368624,'BACKGROUND_COVARIANT_PACKET_DIMENSION':359524,
        'packet_dimension_by_parity':parity,'physical_control_count':4,
        'largest_active_ordered_block':max(b['ordered_dimension'] for r in rows for b in r.get('blocks',[])),
        'largest_active_faithful_block':max(b['faithful_dimension'] for r in rows for b in r.get('blocks',[])),
        'maximum_participating_signatures':max(len({m['signature_id'] for m in r['members']}) for r in rows)}


def main():
    assert hasattr(__import__('sitecustomize'), 'DENIED')
    counts = evidence()
    excluded = {PROMOTION+'.json','JCAT7G_checkpoint.json'}
    artifacts = {p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('*.json')) if p.name not in excluded}
    old = load(OLD/'JCAT_RealizationV3_custody_checkpoint.json')
    promotion = {'object_id':PROMOTION,'status':'PROMOTED_EXACT_GLOBAL_BACKGROUND_COVARIANT_PACKETS',
        'authority_ceiling':'Complete bounded background-covariant tagged packet space under frozen C5.1 grammar; pre-IBP, pre-final-statistics, not C5 or empirical Spin(10) viability',
        'counts':counts,'class_census':'JCAT7G_class_census.json','complete_packet_ledger':'JCAT7G_completeness_ledger.json',
        'canonical_packet_addresses':'(completion class, homogeneous carrier/copy block, canonical parent column); singleton addresses remain frozen expansion addresses',
        'canonical_internal_basis_changed':False,'all_expansion_addresses_preserved':True,
        'homogeneous_occurrences':'TAGGED_UNTIL_JCAT11','background_occurrences':'SAME_COMMUTING_CONNECTION',
        'quotients_applied':['EXACT_PHYSICAL_REALIZATION_NULL_ONLY'],
        'primary':'Manifest Dbar / derived Fbar grammar expanded by exact component polynomial equality',
        'replay':'Independent ordinary affine Ward prolongation, induced onto the qualified realization quotient',
        'acceptance':'ZERO_EXACT mutual spans and primary covariance in every completion class',
        'constant_theta':'Separately qualified full-H covariance of input fusion covectors',
        'Lorentz_scope':'Physical 4D metric plus epsilon, at most four index occurrences in this bounded scope; not regulator tensor algebra',
        'independence':{'ALGORITHM_INDEPENDENT':True,'CODE_PATH_INDEPENDENT':True,
            'LIBRARY_INDEPENDENT':False,'RUNTIME_INDEPENDENT':False,
            'shared_data':'Certified carriers, binary duals, physical role maps, realization quotient; Python/SymPy stack shared'},
        'formal_authority':AUTHORITY,'artifacts':artifacts,'forbidden_payload_read':False,
        'upstream_objects_changed':False,'not_executed':contract()['not_executed']}
    ph = freeze(PROMOTION+'.json',promotion)
    freeze('JCAT7G_checkpoint.json',{'status':'PASS_GLOBAL_BACKGROUND_PACKETS_STOPPED_AT_JCAT7',
        'source_commit':'24061dc','current_blocker':NEXT,'JCAT7_promoted':True,
        'promotion_object':PROMOTION,'promotion_byte_hash':ph,'counts':counts,
        'ordered_basis_promoted':True,'joint_catalog_promoted':False,
        'full_packet_catalog_qualified':True,'realization_quotient_qualified':True,
        'all_431_expansion_addresses_preserved':True,'homogeneous_occurrences_tagged_until_JCAT11':True,
        'INT7R':'PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR','INT8':'PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2',
        'DISTANCE_TO_C1_GS':'ONE_GATE_REMOVED','distance_is_project_management_only':True,
        'formal_authority':AUTHORITY,'preserved_authority_links':old['preserved_authority_links'],
        'forbidden_payload_read':False,'upstream_objects_changed':False,
        'not_executed':contract()['not_executed']})
    print('JCAT7_GLOBAL_PACKET_PROMOTION_EARNED',counts['BACKGROUND_COVARIANT_PACKET_DIMENSION'],'TAGGED_PRE_IBP_PRE_STATISTICS',flush=True)


if __name__ == '__main__':main()
