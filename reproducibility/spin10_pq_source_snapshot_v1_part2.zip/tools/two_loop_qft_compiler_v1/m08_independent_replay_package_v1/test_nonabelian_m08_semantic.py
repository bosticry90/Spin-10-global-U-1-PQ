"""Bounded evidence regressions; fresh algebra is exercised by the audit."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from audit_nonabelian_m08_semantic import compare, negative_controls
import nonabelian_m08_semantic_replay as replay


class SemanticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out = Path(__file__).resolve().parent/"frozen_nonabelian_m08_semantic"
        cls.p = json.loads((out/"primary.json").read_text()); cls.r = json.loads((out/"replay.json").read_text())
    def test_complete_comparison(self): compare(self.p, self.r)
    def test_27_negative_claims(self): self.assertEqual(negative_controls(self.p, self.r), 27)
    def test_actual_H_pairs(self): self.assertEqual(self.p["geometry"]["generator_pairs"], 66)
    def test_physical_reconstruction(self): self.assertEqual(self.r["geometry"]["physical_parent_commutators_reconstructed"], 990)
    def test_328_not_reconstructed(self): self.assertFalse(self.r["geometry"]["scalar_328_reconstructed"])
    def test_nonsymmetric_coset_retained(self): self.assertTrue(self.p["geometry"]["non_symmetric_coset_witness"])
    def test_composite_R_covariance(self): self.assertEqual(self.p["geometry"]["R_covariance_equations"], 144)
    def test_dual_Gram_not_identity(self): self.assertTrue(self.p["geometry"]["H_gram_nondegenerate_nonidentity"])
    def test_all_nonminimal_contraction_images(self): self.assertEqual(len(self.p["light_block"]["contraction_images"]), 72)
    def test_nonabelian_L_iota(self): self.assertEqual(self.p["light_block"]["local_L_iota_checks"], 72)
    def test_nonminimal_Q_squares(self): self.assertEqual(self.p["light_block"]["Q_square_checks"], 72)
    def test_free_local_source_transport(self): self.assertTrue(self.p["fixed_source_control"]["transported_T"]["Kbar"])
    def test_raw_source_control_not_erased(self): self.assertEqual(self.p["fixed_source_control"]["raw_source_action_defect"], self.p["fixed_source_control"]["nonzero_transported_Kbar"])
    def test_raw_light_fermion_not_invariant(self): self.assertTrue(self.p["fixed_source_control"]["light_fermion_raw_quantum_variation"])
    def test_both_affine_actions_distinguished(self): self.assertEqual(self.p["semantics"]["quantum_Abar"], "0"); self.assertNotEqual(self.p["semantics"]["background_Abar"], "0")
    def test_parameter_substitution_order_retained(self): self.assertIn("first", self.p["semantics"]["composite_parameter"])
    def test_source_inventory_all17(self): self.assertEqual(len(self.p["frozen_semantic_bindings"]["roles"]), 17)
    def test_six_couplings_retained(self): self.assertEqual(len(self.p["frozen_semantic_bindings"]["six_source_targets"]), 6)
    def test_57_prospective_components_not_active(self): self.assertEqual(self.p["impact"]["prospective_new_components"], 57); self.assertFalse(self.p["M08_changed"])
    def test_catalog_completeness_not_transferred(self): self.assertFalse(self.p["impact"]["extended_alphabet_completeness_claimed"])
    def test_no_HB1(self): self.assertFalse(self.p["HB1_C5_authorized"] or self.p["cochain_dimensions_computed"])
    def test_no_full_M08_promotion(self): self.assertFalse(self.p["full_M08_qualified"])
    def test_formal_authority(self): self.assertEqual(self.p["formal_authority"], "34/39_UNCHANGED"); self.assertIsNone(self.p["finite_C1_GS"])
    def test_external_review_still_required(self): self.assertFalse(self.p["external_specialist_review"])
    def test_library_independence_not_claimed(self): self.assertFalse(self.r["independence"]["LIBRARY_INDEPENDENT"])
    def test_replay_no_primary_import(self): self.assertNotIn("from nonabelian_m08_semantic import", inspect.getsource(replay))
    def test_wrong_domain_promotion_rejected(self):
        bad = copy.deepcopy(self.p); bad["full_M08_qualified"] = True
        with self.assertRaises(AssertionError): compare(bad, self.r)


if __name__ == "__main__": unittest.main()
