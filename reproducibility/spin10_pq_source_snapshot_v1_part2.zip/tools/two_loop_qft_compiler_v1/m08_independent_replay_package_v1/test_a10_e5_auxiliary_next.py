"""Scientific projection, graded sign, width and first-failure checks."""
import unittest
from audit_a10_e5_auxiliary_next import *


class AuxiliaryNextTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c=evidence();cls.ctrl=read(OUT/'controls.json')
    def test_all91125_slots(self):self.assertEqual(self.a['domain']['all_tensor_slots'],91125)
    def test_two_actual_routes(self):self.assertTrue(self.c['actual_methods_agree'])
    def test_curvature_quartic_not_omitted(self):self.assertEqual(self.a['inventory']['raw_curvature_quartic_terms'],418);self.assertTrue(self.a['curvature_bubble_slots'])
    def test_nonlinear_auxiliary_gauge_retained(self):self.assertGreater(self.a['inventory']['raw_auxiliary_gauge_temporal_terms'],0)
    def test_full_derivative_current(self):self.assertEqual(len(self.a['inventory']['retained_IBP_current']),4)
    def test_four_derivative_Lorentz_copies(self):self.assertTrue(self.a['inventory']['all4_derivative_Lorentz_copies_checked'])
    def test_four_auxiliary_Lorentz_copies(self):self.assertTrue(self.a['inventory']['all4_auxiliary_gauge_Lorentz_copies_checked'])
    def test_transverse_inverse_included_before_reduction(self):self.assertTrue(self.ctrl['transverse_inverse_included_before_reduction'])
    def test_full_reference_and_width_polynomial(self):self.assertTrue(self.a['loop_structure']['full_even_odd_reference']);self.assertTrue(self.a['loop_structure']['width_powers_not_truncated'])
    def test_ordinary_quartic_zero_edge_proof(self):self.assertIn('every inverse edge vanishes',self.a['inventory']['ordinary_g_squared_quartic_xi_bubble_zero'])
    def test_UV_positive_radius(self):self.assertIn('>0',self.a['UV_residue']['UV_radial_domain']);self.assertFalse(self.a['UV_residue']['exceptional_scaleless_integral_used'])
    def test_distinct_heat_profiles(self):self.assertTrue(self.a['UV_residue']['different_heat_profiles_retained'])
    def test_twelve_H_identities(self):self.assertEqual(self.a['all12_local_H_identities'],list(range(12)))
    def test_actual_blind_to_candidate(self):self.assertFalse(self.a['candidate_read_during_actual'])
    def test_Born_Schur_elementary(self):self.assertEqual(self.ctrl['elementary']['primary'],self.ctrl['elementary']['replay'])
    def test_curvature_omission_detected(self):self.assertTrue(self.ctrl['curvature_omission_exact_residual'])
    def test_auxiliary_gauge_omission_detected(self):self.assertTrue(self.ctrl['missing_auxiliary_gauge_exact_residual'])
    def test_even_auxiliary_order(self):
        a={(90,):ex.coefficient(2)};b={(0,45):ex.coefficient(3)};self.assertEqual(product(a,b),product(b,a))
    def test_odd_order(self):self.assertEqual(product({(45,):ex.coefficient(1)},{(0,):ex.coefficient(1)}),{(0,45):ex.coefficient(-1)})
    def test_width_powers_unbounded(self):
        a=ex.coefficient(WM**4*WH**3);b=ex.coefficient(WM**5*WH**2);self.assertEqual(ex.D.to_sympy(a*b),WM**9*WH**5)
    def test_projection_removes_only_unrecoverable_degree(self):
        a={(0,):ex.coefficient(1)};self.assertFalse(product(a,{(1,):ex.coefficient(1)}));self.assertTrue(product(a,{(45,90):ex.coefficient(1)}))
    def test_match_or_exact_Euler_obstruction(self):self.assertTrue(self.c['match'] or witness_check(self.c)['full_even_Euler_recomputed_by_independent_deletion'])
    def test_first_failure_stops_dependent_amplitudes(self):self.assertFalse(self.c['derivative_gauge_run']);self.assertFalse(self.c['higher_coupling_amplitudes_run'])
    def test_full_order_scope_not_promoted(self):self.assertTrue(self.a['inventory']['other_coupling_families_not_calculated']);self.assertFalse(self.c['full_E5_or_quantum_A5'])
    def test_failed_precheck_preserved(self):self.assertFalse(read(OUT/'controls_attempt_1_disposition.json')['counted_as_PASS'])
    def test_unique_candidate_no_remaining_fit(self):self.assertEqual(self.c['remaining_affine_directions'],0);self.assertFalse(self.c['other_primitive_fitted'])
    def test_inactive_and_goal_incomplete(self):self.assertFalse(self.c['new_normalization_adopted']);self.assertFalse(self.c['whole_goal_complete'])
    def test_unassumed_symbol_is_a_detectable_different_type(self):self.assertNotEqual(s.sympify(str(WH)),WH);self.assertEqual(parse(str(WH)),WH)
    def test_exact_binding_rechecks_every_real_coefficient(self):
        bound=read(OUT/'primary_bound.json');self.assertEqual(bound['all12_local_H_identities'],list(range(12)));self.assertTrue(bound['all_formal_tensor_coefficients_reused_exactly'])
    def test_binding_defect_full_evidence_preserved(self):self.assertEqual(len(read(OUT/'parameter_binding_disposition_1.json')['unsubstituted_width_terms']),600)
    def test_failed_comparison_never_promoted(self):self.assertFalse((OUT/'comparison.json').exists());self.assertEqual(read(OUT/'comparison_attempt_1.json')['execution_state'],'FAILED')
    def test_exact_equality_does_not_require_structural_equality(self):
        a=xi*(WH+xi);b=xi*WH+xi**2;self.assertNotEqual(a,b);self.assertEqual(clean(a-b),0)
    def test_disposition_records_are_not_execution_attempts(self):self.assertEqual(len(attempt_records('controls')),2);self.assertTrue(all('calculation_completed' in a for a in attempt_records('controls')))


if __name__=='__main__':unittest.main()
