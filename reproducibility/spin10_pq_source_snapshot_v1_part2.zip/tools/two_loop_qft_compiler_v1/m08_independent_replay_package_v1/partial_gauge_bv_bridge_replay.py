"""Independent word/functional-variation SU(2)/U(1) bridge, stdout only.

No primary model, columns or output imported. Shared conventions and Python/
SymPy remain common assumptions; this is not external or runtime independence.
"""
import json
import sympy as s
from interacting_bv_preflight_replay import ControlWords


class PartialWords(ControlWords):
    def __init__(self):
        self.p={**{f"A{k}{m}":0 for k in range(3) for m in range(4)},
            **{f"p{k}":0 for k in range(3)},**{f"c{k}":1 for k in range(3)},
            **{f"bar{k}":1 for k in range(2)},**{f"b{k}":0 for k in range(2)}}
        self.pairs=[(z,"J"+z) for z in self.p]
        self.p.update({J:1-self.p[z] for z,J in self.pairs}); self.max_jet=0

    def act(self,P,images,parity):
        out={}
        for word,c in P.items():
            for pos,(name,indices) in enumerate(word):
                sign=(-1)**(parity*sum(self.p[n] for n,_ in word[:pos]))
                out=self.add(out,self.scale(self.mul({word[:pos]:c},self.dword(images.get(name,{}),indices),{word[pos+1:]:1}),sign))
        return out

    @staticmethod
    def strip(P): return {word:c for word,c in P.items() if all(n!="c2" for n,I in word)}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda name,fn:fn()
    w=PartialWords(); names=tuple(w.p); x={n:w.var(n) for n in names}
    g,h,xi,v=s.symbols("g h xi v"); metric=(1,-1,-1,-1)
    def cross(X,Y):
        return [w.add(w.mul(X[(k+1)%3],Y[(k+2)%3]),w.scale(w.mul(X[(k+2)%3],Y[(k+1)%3]),-1)) for k in range(3)]
    def dot(X,Y): return w.add(*(w.mul(a,b) for a,b in zip(X,Y)))
    def t(X): return [w.scale(X[1],-1),X[0],{}]
    A=[[x[f"A{k}{m}"] for k in range(3)] for m in range(4)]
    p=[x[f"p{k}"] for k in range(3)]; eta=[p[0],p[1],w.add(p[2],{():v})]
    C=[x[f"c{k}"] for k in range(3)]; bar=[x["bar0"],x["bar1"],{}]; b=[x["b0"],x["b1"],{}]
    R=w.scale(w.mul(C[0],C[1]),-1)
    kinetic={}; curvature={}; cov=[]
    for m in range(4):
        for n in range(m+1,4):
            ac=cross(A[m],A[n]); f=[w.add(w.D(A[n][k],m),w.scale(w.D(A[m][k],n),-1),w.scale(ac[k],g)) for k in range(3)]
            curvature[m,n]=f; kinetic=w.add(kinetic,w.scale(dot(f,f),-metric[m]*metric[n]/s.Integer(2)))
        cov.append([w.add(w.D(eta[k],m),w.scale(cross(A[m],eta)[k],g)) for k in range(3)])
    rad=w.add(dot(eta,eta),{():-v*v})
    S0=w.add(kinetic,*(w.scale(dot(y,y),metric[m]/s.Integer(2)) for m,y in enumerate(cov)),w.scale(w.mul(rad,rad),-h/4))
    forward={}
    for m in range(4):
        for k in range(3): forward[f"A{k}{m}"]=w.add(w.D(C[k],m),w.scale(cross(A[m],C)[k],g))
    for k in range(3):
        forward[f"p{k}"]=w.scale(cross(C,eta)[k],-g); forward[f"c{k}"]=w.scale(cross(C,C)[k],-g/2)
    for k in range(2):
        forward[f"bar{k}"]=w.add(w.scale(b[k],-1),w.scale(w.mul(C[2],t(bar)[k]),-g))
        forward[f"b{k}"]=w.add(w.scale(w.mul(C[2],t(b)[k]),-g),w.scale(w.mul(R,t(bar)[k]),-g*g))
    Smin=w.add(S0,*(w.mul(x[J],forward[z]) for z,J in w.pairs))
    G=[]; gold=cross([{},{},{():v}],p)
    for k in range(2):
        # Explicit two-dimensional rotation, not the primary epsilon grammar.
        G.append(w.add(*(w.scale(w.add(w.D(A[m][k],m),w.scale(w.mul(A[m][2],t(A[m])[k]),g)),metric[m]) for m in range(4)),w.scale(gold[k],-xi*g)))
    psi=dot(bar[:2],[w.add(G[k],w.scale(b[k],-xi/2)) for k in range(2)])
    Qmin=stage("word_partial_minimal_columns",lambda:w.columns(Smin))
    gf=w.Q(psi,Qmin); S=w.add(Smin,gf)
    Q=stage("word_partial_fixed_columns",lambda:w.columns(S))
    for z in forward: assert Q[z]==Qmin[z]==forward[z],"forward "+z
    assert w.Q(S0,Q)=={}
    for m in range(4):
        for k in range(3): assert w.Q(cov[m][k],Q)==w.scale(cross(C,cov[m])[k],-g)
    for f in curvature.values():
        for k in range(3): assert w.Q(f[k],Q)==w.scale(cross(C,f)[k],-g)
    L={n:{} for n in names}
    for prefix,mus in (("A",range(4)),("JA",range(4)),("p",[None]),("Jp",[None]),("c",[None]),("Jc",[None]),("bar",[None]),("Jbar",[None]),("b",[None]),("Jb",[None])):
        for mu in mus:
            tail="" if mu is None else str(mu)
            L[prefix+"0"+tail]=x[prefix+"1"+tail]; L[prefix+"1"+tail]=w.scale(x[prefix+"0"+tail],-1)
    I={n:{} for n in names}; I["c2"]={():s.Integer(1)}
    lie=lambda P:w.act(P,L,0)
    contract=lambda P:w.act(P,I,1)
    assert Q["c2"]==w.scale(R,g) and w.Q(R,Q)=={}
    assert lie(psi)==contract(psi)=={} and w.strip(gf)==gf
    def structural():
        for n in names:
            assert w.add(lie(Q[n]),w.scale(w.Q(L[n],Q),-1))=={},"LQ "+n
            assert w.add(contract(Q[n]),w.Q(I[n],Q))==w.scale(L[n],g),"iQ "+n
            assert w.add(lie(I[n]),w.scale(contract(L[n]),-1))=={} and contract(I[n])=={}
            for mu in range(4):
                assert contract(w.D(x[n],mu))==w.D(I[n],mu)
                assert lie(w.D(x[n],mu))==w.D(L[n],mu)
        delta={n:w.strip(Q[n]) for n in names if n!="c2"}
        for n in delta: assert w.Q(delta[n],delta)==w.scale(w.mul(R,L[n]),-g*g),"delta square "+n
        assert w.Q(R,delta)=={}
        return delta
    stage("word_partial_source_Cartan_identities",structural)
    raise AssertionError("EXPECTED_FAILED_GATE_DISAPPEARED_REQUIRES_NEW_ADJUDICATION")


def obstruction_evidence(stage=None):
    """Independent direct-component calculation of the first failed gate.

    Only the connection and coset ghosts are needed; import no complete table.
    Reconstruct R and delta A20 by their physical SU(2) components.
    """
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    w=PartialWords(); g=s.Symbol("g")
    u0,u1=w.var("c0"),w.var("c1")
    R=w.scale(w.mul(u0,u1),-1)
    # epsilon(2,0,1)=+1. delta u_i=0 in this symmetric coset.
    da=w.scale(w.add(w.mul(w.var("A00"),u1),w.scale(w.mul(w.var("A10"),u0),-1)),g)
    images={"c0":{},"c1":{},
        "A00":w.add(w.D(u0,0),w.scale(w.mul(w.var("A20"),u1),-g)),
        "A10":w.add(w.D(u1,0),w.scale(w.mul(w.var("A20"),u0),g))}
    actual=w.Q(da,images); expected={}
    residual=w.add(actual,w.scale(expected,-1)); derivative=w.scale(w.D(R,0),-g)
    assert residual==derivative and residual
    paired=w.mul(w.var("JA20"),residual)
    assert w.EL(paired,"JA20")==residual
    return {"schema":"PARTIAL_GAUGE_BV_BRIDGE_OBSTRUCTION_REPLAY_V1",
        "obstruction":{"generator":"A20","L_generator":[],"R":w.record(R),"delta_generator":w.record(da),
            "actual_square":w.record(actual),"expected_global_square":w.record(expected),"residual":w.record(residual),
            "minus_g_partial_R":w.record(derivative),"source_paired_residual":w.record(paired),"source_Euler_residual":w.record(w.EL(paired,"JA20"))},
        "independence":{"ALGORITHM_INDEPENDENT":True,"CODE_PATH_INDEPENDENT":True,"LIBRARY_INDEPENDENT":False,"RUNTIME_INDEPENDENT":False,
            "primary_model_or_columns_imported":False,"full_source_replay_reached":False,"analyst_blind":False,"external_specialist_review":False,
            "scope":"direct physical SU2 connection/ghost component square and source-Euler control only; no replay claim for all 88 columns"}}


if __name__=="__main__": print(json.dumps(obstruction_evidence(),sort_keys=True,separators=(",",":")))
