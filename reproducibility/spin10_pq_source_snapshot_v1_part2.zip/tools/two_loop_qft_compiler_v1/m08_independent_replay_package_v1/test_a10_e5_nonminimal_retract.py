"""Exact adversaries for the domain lemma; shared arithmetic is disclosed."""
import unittest
from copy import deepcopy
from a10_e5_nonminimal_retract import *
from audit_a10_e5_nonminimal_retract import adjudicate,execution_matches


class NonminimalRetract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json');cls.w=alphabet()
        cls.h={n:decode_typed(v) for n,v in cls.P['homotopy_columns'].items()}
        cls.Rscale={n:{word:c.subs(s.Symbol('lambda_nm'),lam) for word,c in decode_typed(v).items()}
                    for n,v in cls.P['finite_scale_columns'].items()}
        cls.projection={n:decode_typed(v) for n,v in cls.P['projection_columns'].items()}

    def test_01_distinct_routes_agree(self):
        self.assertEqual(adjudicate(self.P,self.R)['scientific_gate'],STATUS)

    def test_02_actual_width_source_corrections(self):
        w=self.w
        self.assertEqual(self.h['Jbar0'],w.add(w.scale(w.var('Jb0'),-1),w.scale(w.var('bar0'),-2*etaH),w.scale(w.var('bar1'),etaH)))
        self.assertEqual(self.h['Jub13'],w.add(w.scale(w.var('JL13'),-1),w.scale(w.var('ub44'),-xi/4)))

    def test_03_projection_is_not_blind_old_chart_deletion(self):
        self.assertTrue(self.projection['Jub13'])
        self.assertNotEqual(self.projection['JC1'],self.w.var('JC1'))
        self.assertNotEqual(self.projection['Jx_Phi_5'],self.w.var('Jx_Phi_5'))
        self.assertEqual(self.P['minimal_image_pairs'],553)

    def test_04_count_includes_ghost_cotangent(self):
        self.assertTrue(self.P['count_columns']['JC1'])
        self.assertNotIn('JC1',NM)
        self.assertFalse(self.P['cochain_scaling_is_canonical'])

    def test_05_complete_generator_and_parameter_jet_coverage(self):
        c=self.P['operator_checks']
        self.assertEqual(c['all_generator_counts'],{'Q':1334,'iota':1334,'Tq':1334,'Tb':1334})
        self.assertEqual(c['first_and_mixed_second_jet_checks'],16008)
        self.assertTrue(c['local_parameter_jets_retained'])

    def test_06_jet_extension_is_structural_and_cap_not_relation(self):
        c=self.P['operator_checks']
        self.assertEqual(c['cap_behavior'],'raises; never a zero relation')
        self.assertIn('graded derivation',c['all_jet_extension'])
        with self.assertRaises(RuntimeError):self.w.dword(self.w.var('L13'),(0,)*7)

    def test_07_real_evaluation_dual_and_Lorentz_types(self):
        t=self.P['types'];self.assertEqual(t['real_carrier_entry_checks'],2466)
        self.assertTrue(t['component_real_structure_preserved'])
        self.assertTrue(t['Lorentz_scalar_blocks_and_ordinary_jets'])
        self.assertTrue(t['not_operator_Hilbert_adjoint_claim'])

    def test_08_vacuum_coefficient_grade_cannot_be_omitted(self):
        w=self.w;P=w.scale(w.var('ub15'),5*g*xi*vacuum_unit/4)
        self.assertFalse(w.grade(P,(2,-1,1)))
        self.assertTrue(typed_grade(P,w,(2,-1,1)))
        self.assertFalse(typed_grade(normalize_vacuum(P),w,(2,-1,1)))
        self.assertEqual(self.P['types']['vacuum_coefficient_dimension'],1)
        raw={(("JB0_0",()),):(lam-1)*(lam+1)-lam**2+1}
        self.assertTrue(raw);self.assertFalse(canonical(raw))

    def test_09_h_is_not_canonical_despite_hPsi_zero(self):
        n=self.P['negative_controls']
        self.assertFalse(n['hD_Psi']);self.assertEqual(n['h_not_canonical_bracket_defect'],[{'word':[],'coefficient':'2'}])

    def test_10_untransported_h_fails_both_width_channels(self):
        n=self.P['negative_controls']['untransported_h_free_source_defects']
        self.assertEqual(n['Jub13'],[{'word':['L44'],'coefficient':'-xi/4'}])
        self.assertEqual(n['Jbar0'],[{'word':['b0'],'coefficient':'-2*eta_H'},{'word':['b1'],'coefficient':'eta_H'}])

    def test_11_only_integer_degree_denominators(self):
        for key in ('homotopy_columns','count_columns','finite_scale_columns','projection_columns'):
            for P in self.P[key].values():
                for c in decode_typed(P).values():
                    self.assertFalse(s.denom(c).has(g,xi,etaH));self.assertFalse(c.has(s.Float))

    def test_12_high_degree_full_quartet_retract(self):
        w=self.w;names=list(w.grades);Q={n:{} for n in names};h={n:{} for n in names}
        for eta,beta,Je,Jb in PAIRS:
            Q[eta]=w.var(beta);Q[Jb]=w.var(Je);h[beta]=w.var(eta);h[Je]=w.var(Jb)
        R={n:w.scale(w.var(n),lam if n in NM else 1) for n in names}
        F=w.mul(w.var('Jbar0'),w.var('Jbar0'),*[w.var('b0') for _ in range(7)])
        self.assertTrue(F)
        HF=homotopy(F,R,h,w,'replay');HQF=homotopy(act(F,w,Q,'replay',1),R,h,w,'replay')
        self.assertFalse(canonical(w.add(act(HF,w,Q,'replay',1),HQF,w.scale(F,-1))))
        self.assertEqual(nm_degree(next(iter(F))),9)

    def test_13_nontrivial_multiple_source_basic_counterterm(self):
        controls=self.P['cochain_controls']['basic_closed_counterterm_controls']
        self.assertGreaterEqual(controls['source_quadratic']['max_source_factors'],2)
        for c in controls.values():
            self.assertGreater(c['counterterm_coefficients'],0)
            self.assertEqual(c['primitive_sha256'],c['recovered_primitive_sha256'])
            self.assertFalse(c['closed']);self.assertFalse(c['projection'])

    def test_14_nonzero_full_model_functional_boundary_retract(self):
        w=self.w
        e2=read(HERE/'frozen_a10_e2_transport/primary.json')
        Q={n:decode_typed(v['source_polynomial']) for n,v in e2['complete_columns'].items()}
        M=[w.mul(w.var('Jub12'),w.var(f'B0_{mu}')) for mu in range(4)]
        F=w.add(*(w.D(v,mu) for mu,v in enumerate(M)))
        qM=[act(v,w,Q,'replay',1) for v in M]
        QF=act(F,w,Q,'replay',1)
        self.assertEqual(QF,canonical(w.add(*(w.D(v,mu) for mu,v in enumerate(qM)))))
        HF=homotopy(F,self.Rscale,self.h,w,'replay')
        hQM=[homotopy(v,self.Rscale,self.h,w,'replay') for v in qM]
        self.assertTrue(HF);self.assertTrue(w.add(*hQM))
        residual=w.add(F,w.scale(sub(F,self.projection,w),-1),
          w.scale(act(HF,w,Q,'replay',1),-1),w.scale(w.add(*(w.D(v,mu) for mu,v in enumerate(hQM))),-1))
        self.assertFalse(canonical(residual))
        for mu,v in enumerate(M):
            self.assertEqual(sub(w.D(v,mu),self.projection,w),w.D(sub(v,self.projection,w),mu))

    def test_15_source_half_of_h_is_required(self):
        w=self.w;v=w.var('Jbar0');Q={'Jb0':v};missing={}
        defect=w.add(act(act(v,w,Q,'primary',1),w,missing,'primary',1),
          act(act(v,w,missing,'primary',1),w,Q,'primary',1),w.scale(v,-1))
        self.assertEqual(defect,w.scale(v,-1));self.assertTrue(defect)

    def test_16_reject_full_E5_and_quantum_overclaims(self):
        for name in ('full_E5_PASS','remaining_minimal_basic_coverage_proved','A1_A5_discharged','sources_removed'):
            a=deepcopy(self.P);b=deepcopy(self.R);a[name]=b[name]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_17_failed_attempt_and_original_sources_preserved(self):
        a=read(OUT/'primary_attempt_1.json')
        self.assertEqual(a['execution_state'],'FAILED');self.assertFalse(a['counted_in_final_evidence'])
        self.assertIn('grading_and_reality',a['log'])
        r=read(OUT/'superseded_start_v1/disposition.json')
        self.assertFalse(r['completed_evidence']);self.assertEqual(r['scientific_qualification'],'NOT_QUALIFIED')

    def test_18_execution_binding_rejects_stale_input_or_runtime(self):
        a=next(read(p) for p in OUT.glob('primary_attempt_*.json') if read(p)['completed_evidence'])
        f=a['fingerprint'];execution_matches(f)
        for name in ('input_manifest_sha256','state_sha256','python','sympy'):
            bad=deepcopy(f);bad[name]='changed'
            with self.assertRaises(AssertionError):execution_matches(bad)


if __name__=='__main__':unittest.main()
