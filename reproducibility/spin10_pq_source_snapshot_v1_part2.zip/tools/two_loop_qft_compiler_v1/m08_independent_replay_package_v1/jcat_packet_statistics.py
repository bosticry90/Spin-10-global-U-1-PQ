"""Finite induced packet/IBP representations and final statistics operators.

Representations are stored by carrier/copy orbit, local stabilizer matrices,
and exact coset transport. This avoids a dense global 357392-dimensional map.
"""
from functools import lru_cache
from itertools import product
from collections import defaultdict
import sympy as sp
from jcat_packet_ibp import *
from jcat_internal_permutations import partitions,specht_character


def compose(p,q):
    return tuple(q[p[i]] for i in range(len(p)))


def inverse(p):
    return tuple(p.index(i) for i in range(len(p)))


def species_positions(names):
    return tuple(tuple(i for i,n in enumerate(names) if n==name) for name in dict.fromkeys(names))


def stat_character(names,types,p):
    return sp.Integer((-1)**sum(sum(p[i]>p[j] for a,i in enumerate(c) for j in c[a+1:])
        for c in species_positions(names) if types[names[c[0]]]['Grassmann_parity']=='ODD'))


def character(multi,positions,p):
    return sp.prod(specht_character(part,tuple(c.index(p[i]) for i in c)) for part,c in zip(multi,positions))


class QuotientRepresentations:
    def __init__(self):
        self.engine=PacketPermutations()
        self.types={r['identity']:r for r in load(HERE/'frozen_catalog_cat0_cat4/CAT1_module_actions.json')['modules']}
        self.patterns={}

    @lru_cache(None)
    def ibp(self,cid,hom):
        b=self.engine.records[cid][hom]
        return load(OUT/(b['block_id']+'_IBP_closed.json'))

    def singleton_blocks(self,group):
        return dict(self.engine.engine.source_blocks(group))

    @lru_cache(None)
    def singleton_local(self,labels,keys,indices,p):
        if tuple(p)==tuple(range(len(p))):return sp.eye(len(indices))
        m3,m2=self.engine.internal.local(labels,p)
        jet=representation(keys,p)
        whole=sp.kronecker_product(m3,m2,jet)
        return sp.ImmutableSparseMatrix(whole.extract(indices,indices))

    def local(self,group,hom,sources,p):
        cid=group['class_id']
        if not group['trivial_singleton']:
            rec=self.ibp(cid,hom);Q=matrix(rec['quotient_map']);section=matrix(rec['section'])
            return Q*self.engine.action(cid,hom,p)*section
        labels=tuple(tup(self.engine.engine.catalog.by_id[c]['H_label']) for c,_ in hom)
        sid=group['members'][0]['signature_id'];row=self.engine.engine.rows[sid]
        keys=tuple(tup(row['raw_Lorentz_derivative_addresses'][j]) for j in group['members'][0]['jet_indices'])
        if len(labels)<2:return sp.eye(len(sources))
        e3,e2=self.engine.internal.engines['SU3'],self.engine.internal.engines['SU2']
        b3=[k for k,_ in e3.basis(tuple(r[:2] for r in labels))[1]]
        b2=[k for k,_ in e2.basis(tuple(r[2] for r in labels))[1]]
        indices=[]
        for s in sources:
            desc,key,slots,copies,b,r,a,bb=self.engine.engine.catalog.address_parts(s['address'])
            i3=b3.index((tuple(b['output_H_label'][:2]),a,bb))
            i2=b2.index((b['output_H_label'][2],0,0))
            ij=group['members'][0]['jet_indices'].index(s['jet_index'])
            indices.append((i3*len(b2)+i2)*len(keys)+ij)
        assert sorted(indices)==list(range(len(indices)))
        return self.singleton_local(labels,keys,tuple(indices),p)

    def pattern(self,group,hom,sources,G,H):
        names=group['homogeneous_roles'];positions=species_positions(names)
        matrices={p:self.local(group,hom,sources,p) for p in H}
        key=canonical([positions,[(p,serial(M)) for p,M in matrices.items()],group['parity']])
        if key in self.patterns:return key,self.patterns[key]
        n=next(iter(matrices.values())).rows
        for p in H:
            for q in H:
                assert matrices[p]*matrices[q]==matrices[compose(p,q)]
        # Ind_H^G character computed from exact local quotient representation.
        chars=[]
        for g in G:
            value=0
            for x in G:
                h=compose(compose(inverse(x),g),x)
                if h in matrices:value+=matrices[h].trace()
            value=sp.Rational(value,len(H))
            assert value.is_Integer
            chars.append(int(value))
        assert chars[0]==len(G)//len(H)*n
        young=[]
        for multi in product(*(partitions(len(c)) for c in positions)):
            chi=[character(multi,positions,p) for p in G]
            m=sp.Rational(sum(v*w for v,w in zip(chars,chi)),len(G))
            assert m.is_Integer and m>=0
            if m:young.append({'multipartition':multi,'multiplicity':int(m),'Specht_dimension':int(chi[0])})
        assert sum(r['multiplicity']*r['Specht_dimension'] for r in young)==chars[0]
        record={'pattern_id':key,'species_positions':positions,'G_elements':G,'local_stabilizer':H,
            'local_dimension':n,'induced_dimension':chars[0],
            'local_matrices':[{'permutation':p,'matrix':serial(matrices[p])} for p in H],
            'quotient_characters':chars,'Young_decomposition':young,'parity':group['parity'],
            'representation':'Exact finite induced representation; canonical coset representatives carry carrier/copy orbit transport',
            'local_group_relations':'ZERO_EXACT','dimension_reconstruction':'ZERO_EXACT'}
        self.patterns[key]=record
        return key,record

    def orbits(self,group):
        cid=group['class_id'];names=group['homogeneous_roles'];G=tuple(stabilizer_elements(names))
        if group['trivial_singleton']:blocks=self.singleton_blocks(group)
        else:blocks={hom:None for hom in self.engine.records[cid]}
        seen=set()
        for hom in sorted(blocks):
            if hom in seen:continue
            orbit=sorted({tuple(hom[i] for i in p) for p in G});seen.update(orbit)
            assert all(h in blocks for h in orbit)
            H=tuple(p for p in G if tuple(hom[i] for i in p)==hom)
            sources=blocks[hom] if group['trivial_singleton'] else None
            key,pattern=self.pattern(group,hom,sources,G,H)
            cosets=[next(p for p in G if tuple(hom[i] for i in p)==h) for h in orbit]
            # Addresses, not just dimensions: singleton sources identify every
            # frozen packet coordinate; active packet IDs bind their exact JCAT7 columns.
            provenance=({'canonical_packet_source_selector':{
                'signature_id':group['members'][0]['signature_id'],
                'internal_family':group['members'][0]['internal_family'],
                'jet_indices':group['members'][0]['jet_indices'],
                'homogeneous_component_copy_tuple':hom,'coordinate_count':len(sources),
                'source_enumeration_sha256':canonical(sources),
                'enumeration':'Frozen INT6 family addresses filtered by this component/copy tuple, then listed jet indices'}} if group['trivial_singleton'] else
                {'canonical_JCAT7_block':self.engine.records[cid][hom]['block_id'],
                 'canonical_JCAT9_artifact':self.engine.records[cid][hom]['block_id']+'_IBP_closed.json'})
            yield {'orbit_id':cid+'_'+canonical(hom)[:16],'class_id':cid,'canonical_homogeneous_components':hom,
                'pattern_id':key,'coset_transport':cosets,
                'coset_target_rule':'target_hom[j] = canonical_hom[permutation[j]]',
                'post_IBP_dimension':pattern['induced_dimension'],
                'signature_provenance':[m['signature_id'] for m in group['members']],**provenance}


def statistics_basis(pattern,names,types):
    matrices={tup(r['permutation']):matrix(r['matrix']) for r in pattern['local_matrices']}
    H=list(matrices);n=pattern['local_dimension']
    signs={p:stat_character(names,types,p) for p in H}
    projector=sum((signs[p]*M for p,M in matrices.items()),sp.zeros(n))/len(H)
    assert projector*projector==projector
    basis=independent_columns(projector)
    for p,M in matrices.items():assert M*basis==signs[p]*basis
    N=sp.Rational(sum(stat_character(names,types,tup(p))*v for p,v in zip(pattern['G_elements'],pattern['quotient_characters'])),len(pattern['G_elements']))
    assert N==basis.cols,('STATISTICS_CHARACTER_CENSUS',pattern['pattern_id'])
    return {'pattern_id':pattern['pattern_id'],'local_statistics_projector':serial(projector),
        'canonical_allowed_local_basis':serial(basis),'allowed_dimension':basis.cols,
        'independent_full_group_character_dimension':int(N),'projector_idempotence':'ZERO_EXACT',
        'statistics_covariance':'ZERO_EXACT','character_census_residual':'ZERO_EXACT',
        'statistics_character':'Species-wise trivial for bosons and sign for Grassmann-odd fields; backgrounds excluded'}
