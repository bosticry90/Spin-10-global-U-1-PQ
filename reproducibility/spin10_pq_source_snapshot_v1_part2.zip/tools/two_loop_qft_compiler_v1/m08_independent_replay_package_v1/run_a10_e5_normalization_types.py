"""Strict, read-only own-byte derivation runner."""
import json, sys, time
from hashlib import sha256
from a10_e5_normalization_types import HERE, ROOT, OUT, read, build, s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    assert len(sys.argv) == 3 and sys.argv[1] in ('primary', 'replay')
    route = sys.argv[1]; path = OUT / sys.argv[2] / 'preparation.json'; prep = read(path)
    for name, h in prep['execution_bytes'].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == h, ('START_BYTES_CHANGED', name)
    assert sha256((ROOT / 'project_state.json').read_bytes()).hexdigest() == prep['state_sha256']
    assert sha256((ROOT / prep['input_manifest']).read_bytes()).hexdigest() == prep['input_manifest_sha256']
    assert prep['contract_version'] == 'V2'
    assert sha256((OUT / 'unlowered_shear_failure_1.json').read_bytes()).hexdigest() == prep['unlowered_H_control_sha256']
    writes = []
    def hook(event, args):
        if event == 'open' and len(args) > 1 and isinstance(args[1], str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0])); raise PermissionError('NORMALIZATION_TYPES_WORKER_WRITE_DENIED')
    sys.addaudithook(hook)
    print('EXECUTION ' + json.dumps({'route': route, 'preparation': path.relative_to(ROOT).as_posix(),
        'preparation_sha256': sha256(path.read_bytes()).hexdigest(), 'execution_bytes': prep['execution_bytes'],
        'input_manifest_sha256': prep['input_manifest_sha256'], 'state_sha256': prep['state_sha256'],
        'contract_version': prep['contract_version'], 'unlowered_H_control_sha256': prep['unlowered_H_control_sha256'],
        'python': sys.version, 'executable': sys.executable, 'sympy': s.__version__, 'guard_active': True}, sort_keys=True, separators=(',', ':')), flush=True)
    stages = []; started = time.perf_counter()
    def stage(name, fn):
        print('STAGE ' + name, flush=True); tick = time.perf_counter(); result = fn()
        stages.append({'name': name, 'seconds': time.perf_counter() - tick}); return result
    result = build(route, stage)
    print('RESULT ' + json.dumps(result, sort_keys=True, separators=(',', ':')), flush=True)
    print('METRICS ' + json.dumps({'execution_state': 'COMPLETED', 'seconds': time.perf_counter() - started,
        'stages': stages, 'write_attempts': writes}, sort_keys=True, separators=(',', ':')), flush=True)


if __name__ == '__main__': main()
