"""Exact typed-AST successor for the certified A5 V2 ghost-vector rule.

V4 preserved the correct mathematical statement but serialized the two
momenta as factors of one term.  The typed-rule language multiplies factors
within a term, so the certified sum requires two additive terms.  V4 remains
immutable historical evidence; consumers of the current action use V5.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any


RULE_ID = "A.HH.VH.derivative"


def corrected_rule() -> dict[str, Any]:
    common = {
        "coefficient_factors": [{
            "op": "parameter", "name": "g10", "power": 1
        }],
        "group_factors": [{
            "op": "structure_constant",
            "indices": [0, 1, 2],
            "dummy_domains": {},
        }],
    }
    ghost = deepcopy(common)
    ghost.update({
        "label": "complete_product_derivative_on_ghost",
        "lorentz_factors": [{
            "op": "momentum", "leg": 1, "lorentz_leg": 2
        }],
    })
    vector = deepcopy(common)
    vector.update({
        "label": "complete_product_derivative_on_vector",
        "lorentz_factors": [{
            "op": "momentum", "leg": 2, "lorentz_leg": 2
        }],
    })
    return {
        "rule_id": RULE_ID,
        "ordered_fields": ["Hbar", "H", "VH"],
        "incoming_momentum_convention": "ALL_INCOMING",
        "terms": [ghost, vector],
        "grassmann_leg_order": [0, 1],
        "identical_leg_symmetry": "NONE",
        "action_term_provenance": (
            "-ubar_i*partial_mu(g10*f[i,k,j]*V_k^mu*u_j); "
            "-f[i,k,j]=+f[i,j,k]"
        ),
        "derived_without_display_string_parser": True,
        "historical_facade_status": "SUPERSEDED_BY_A5_V2_FUNCTIONAL",
        "supersedes_typed_patch": "typed_rule_ast_a5v2_vertex_patch_v4.py",
        "v4_defect": "ADDITIVE_MOMENTA_SERIALIZED_AS_MULTIPLICATIVE_FACTORS",
    }


def apply(module: Any) -> None:
    base = module.vertex_rules

    def patched() -> dict[str, Any]:
        rules = base()
        rules[RULE_ID] = corrected_rule()
        return rules

    module.vertex_rules = patched
