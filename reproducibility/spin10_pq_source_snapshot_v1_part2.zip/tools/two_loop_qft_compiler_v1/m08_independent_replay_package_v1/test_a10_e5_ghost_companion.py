"""Adversarial ghost companion, boundary, frame and evidence controls."""
import unittest
from copy import deepcopy
from a10_e5_ghost_companion import *
from a10_e5_source_vertex import Green
from audit_a10_e5_ghost_companion import adjudicate,execution_matches,comparison


class GhostCompanion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.kap=mat(cls.P['actual_group_matrices']['kappa_physical'])

    def test_01_failure_evidence_routes_agree(self):
        a=adjudicate(self.P,self.R,False)
        self.assertEqual(a['scientific_gate'],STOP);self.assertFalse(a['full_E5_PASS'])

    def test_02_complete_mixed_inverse_and_abbreviation(self):
        w=model();p=[s.Integer(2),s.Integer(1),s.Integer(0),s.Integer(0)]
        G,k2=Green(w,p,s.Symbol('Msource_squared',positive=True))
        abbreviated=Green_abbreviated(w,p,k2)
        for row,other in zip(G,abbreviated):
            for a,b in zip(row,other):self.assertEqual(canonical(a),canonical(b))
        self.assertFalse(G[5][5]);self.assertTrue(G[1][5]);self.assertTrue(G[5][1])
        self.assertEqual(G[6][7],w.scale(G[7][6],-1))

    def test_03_two_assignment_log_cancellation(self):
        a=self.P['bubble_arithmetic'];self.assertEqual(a['kinetic_log_assignment_weights'],[-1,1])
        self.assertEqual(sum(a['kinetic_log_assignment_weights']),0)
        K,R,p=s.symbols('K R p2',nonzero=True)
        first=-s.I*p/(2*K*R);second=-s.I*(K+R-p)/(2*K*R)
        self.assertEqual(s.cancel(first+second+s.I*(1/K+1/R)/2),0)

    def test_04_missing_assignment_would_create_false_pole(self):
        weights=self.P['bubble_arithmetic']['kinetic_log_assignment_weights']
        for removed in range(2):self.assertNotEqual(sum(weights[:removed]+weights[removed+1:]),0)

    def test_05_wrong_odd_orientation_breaks_cancellation(self):
        weights=self.P['bubble_arithmetic']['kinetic_log_assignment_weights']
        self.assertNotEqual(weights[0]-weights[1],0)
        w=model();self.assertEqual(w.mul(w.var('ubLoop'),w.var('uLoop')),w.scale(w.mul(w.var('uLoop'),w.var('ubLoop')),-1))

    def test_06_actual_derivative_and_quartic_inventory(self):
        group=self.P['actual_group_matrices'];self.assertEqual(group['literal_primary_derivative_counts'],{'antighost':2544,'gauge':720,'ghost':720})
        self.assertEqual(group['quartic_primary_route_count'],648)
        for tag in ('antighost','gauge','ghost'):self.assertEqual(len(group['all_physical_derivative_vertices'][tag]),45)

    def test_07_H_channels_zero_and_heavy_groups(self):
        group=self.P['actual_group_matrices']
        self.assertEqual(mat(group['all_external_antighost_group_matrices']['antighost']),s.Matrix.vstack(s.zeros(12,33),-self.kap))
        self.assertEqual(mat(group['all_external_ghost_group_matrices']['antighost']),s.Matrix.hstack(s.zeros(33,12),-self.kap))
        self.assertEqual(mat(group['complete_quartic_tadpole_matrix']),s.diag(s.zeros(12),-self.kap))

    def test_08_complete_other_derivative_placement_groups_zero(self):
        group=self.P['actual_group_matrices']
        for tag in ('gauge','ghost'):
            self.assertEqual(mat(group['all_external_antighost_group_matrices'][tag]),s.zeros(45,33))
            self.assertEqual(mat(group['all_external_ghost_group_matrices'][tag]),s.zeros(33,45))

    def test_09_heat_power_and_finite_term_are_not_logarithm(self):
        a,q=s.symbols('aGc q_E_squared',positive=True);c=a*q
        pair=(s.exp(-c/2)-s.exp(-c))/(16*s.pi**2*a*c)
        self.assertEqual(s.limit(a*pair,a,0,dir='+'),1/(32*s.pi**2))
        self.assertEqual(s.limit(pair-1/(32*s.pi**2*a),a,0,dir='+'),-3*q/(128*s.pi**2))
        self.assertEqual(s.limit(a*s.diff(pair-1/(32*s.pi**2*a),a),a,0,dir='+'),0)

    def test_10_omitting_quartic_changes_power_coefficient(self):
        a=s.Symbol('aGc',positive=True)
        bubble=1/(32*s.pi**2*a);tad=-1/(16*s.pi**2*a)
        self.assertNotEqual(bubble,bubble+tad)
        self.assertEqual(s.simplify(bubble+tad),-1/(32*s.pi**2*a))

    def test_11_nonexceptional_and_IR_scope(self):
        a=self.P['regulated_integrals'];self.assertTrue(a['nonzero_external_momentum_required_for_separate_bubble'])
        self.assertTrue(a['both_integrals_IR_integrable']);self.assertFalse(a['physical_IR_limit_proved'])
        self.assertTrue(a['dimensional_scaleless_tadpole_not_used_as_kinetic_proof'])

    def test_12_full_2025_entry_mismatch(self):
        a=self.P['normalization_verdict'];self.assertEqual(mat(a['actual_kinetic_log_matrix']),s.zeros(45))
        self.assertEqual(mat(a['actual_minus_candidate_matrix']),s.diag(s.zeros(12),self.kap))
        self.assertEqual(self.kap.trace(),132);self.assertEqual(self.kap[0,0],8)

    def test_13_nonzero_position_space_Euler_witness(self):
        w=alphabet();P=w.add(*(w.scale(w.mul(w.D(w.var('ub12'),mu),w.D(w.var('C12'),mu)),8*ETA[mu]) for mu in range(4)))
        E=canonical(w.EL(P,'ub12'))
        expected=w.add(*(w.scale(w.D(w.D(w.var('C12'),mu),mu),-8*ETA[mu]) for mu in range(4)))
        self.assertEqual(E,canonical(expected));self.assertTrue(E)
        # A true divergence has zero Euler derivative, so it cannot erase E.
        boundary=w.D(w.mul(w.var('ub12'),w.D(w.var('C12'),0)),0)
        self.assertFalse(w.EL(boundary,'ub12'))

    def test_14_spacelike_Fourier_witness_sign_is_explicit(self):
        qM2,qE2=s.symbols('q_M_squared q_E_squared',real=True)
        # EL(+8 dbar.dC)=-8 Box C -> +8 q_M^2 C.
        coefficient=8*qM2;self.assertEqual(coefficient.subs(qM2,-qE2),-8*qE2)
        self.assertNotEqual(coefficient.subs(qM2,-qE2),8*qE2)

    def test_15_ghost_endomorphism_requires_Gram(self):
        N=mat(self.P['actual_group_matrices']['ghost_endomorphism_C3'])[12:,12:]
        Q,QM,FM,GM,GI,EM,EH,PM=input_chart('primary')
        old=mat(read(HERE/'frozen_a10_e5_ghost_normalization/primary.json')['ghost_metric']['canonical_kappa'])
        self.assertEqual(cm(old*GM),N);self.assertNotEqual(old,N)

    def test_16_doublet_and_evaluation_dual_control_only(self):
        N=mat(self.P['actual_group_matrices']['ghost_endomorphism_C3'])[12:,12:];tau=s.Symbol('tau')
        C=s.eye(33)+tau*N;bar=s.eye(33)-tau*N.T
        self.assertEqual(cm(bar.T*C-s.eye(33)+tau*tau*N*N),s.zeros(33))
        w=alphabet();Q={f'ub{12+i}':w.scale(w.var(f'L{12+i}'),-1) for i in range(33)};Z={}
        for pre in ('ub','L'):
            for i in range(33):Z[f'{pre}{12+i}']=w.add(*(w.scale(w.var(f'{pre}{12+j}'),-N[j,i]) for j in range(33) if N[j,i]))
        for i in range(33):
            n=f'ub{12+i}';self.assertFalse(canonical(w.add(w.act(Q[n],Z),w.scale(w.act(Z[n],Q,1),-1))))
            jet=w.D(w.var(n),0)
            self.assertFalse(canonical(w.add(w.act(w.act(jet,Q,1),Z),w.scale(w.act(w.act(jet,Z),Q,1),-1))))
        self.assertFalse(self.P['nonminimal_pairing_control']['candidate_adopted'])
        self.assertFalse(self.P['nonminimal_pairing_control']['complete_joint_loop_normalization_qualified'])

    def test_17_wrong_dual_sign_changes_free_pairing(self):
        N=mat(self.P['actual_group_matrices']['ghost_endomorphism_C3'])[12:,12:]
        self.assertNotEqual(cm(N+N),s.zeros(33))
        w=alphabet();Q={'ub12':w.scale(w.var('L12'),-1)}
        Z={'ub12':w.add(*(w.scale(w.var(f'ub{12+j}'),-N[j,0]) for j in range(33) if N[j,0]))}
        # Keeping Lambda unchanged fails the doublet commutator.
        self.assertTrue(w.act(Z['ub12'],Q,1))
        a=self.P['nonminimal_pairing_control'];self.assertTrue(a['width_and_auxiliary_mixing_images_change'])

    def test_18_first_failure_excludes_other_companions_and_adoption(self):
        a=self.P['normalization_verdict'];self.assertFalse(a['JC_CC_or_JB_BC_companion_loops_executed_after_stop'])
        self.assertFalse(a['entire_physical_action_or_BV_failure_inferred'])
        self.assertFalse(self.P['new_joint_normalization_or_restoration_adopted'])

    def test_19_complete_quantum_overclaims_rejected(self):
        for key in ('complete_one_loop_restoration_proved','full_E5_PASS','sources_activated','all_contacts_or_quantum_A5_proved','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[key]=b[key]=True
            with self.assertRaises(AssertionError):adjudicate(a,b,False)

    def test_20_stale_execution_or_mutated_group_rejected(self):
        fp=next(read(p)['fingerprint'] for p in OUT.glob('replay_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(fp);bad=deepcopy(fp);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        a=deepcopy(self.P);a['normalization_verdict']['actual_kinetic_log_matrix']['entries']=[[12,12,'1']]
        with self.assertRaises(AssertionError):adjudicate(a,self.R,False)


if __name__=='__main__':unittest.main()
