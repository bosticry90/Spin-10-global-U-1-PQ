"""Independent bounded HBC reconstruction: no primary math/table imports."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sympy as s

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def build_replay():
    basis = read('frozen_c3/C3_representation_basis.json')['h_basis']
    pairs = list(combinations(range(10), 2)); matrices = []; columns = []
    for v in basis:
        matrix = s.zeros(10); column = s.zeros(45, 1)
        for e in v['raw_so10_coordinates']:
            i, j = pairs[e['index']]; value = s.sympify(e['coefficient']) / s.sqrt(2)
            matrix[i, j] = value; matrix[j, i] = -value; column[e['index']] = value
        matrices.append(matrix); columns.append(column)
    q = s.Matrix.hstack(*columns)
    pivots = list(q.T.rref()[1]); minor = q[pivots, :]
    # Physical commutator, independent 12-dimensional pivot solve, all 45 rows certified.
    def coordinates(a, b):
        commutator = matrices[a] * matrices[b] - matrices[b] * matrices[a]
        raw = s.Matrix([s.simplify(commutator[i, j]) for i, j in pairs])
        coords = minor.inv() * raw[pivots, :]
        coords = coords.applyfunc(s.simplify)
        assert (q * coords - raw).applyfunc(s.simplify) == s.zeros(45, 1)
        return coords
    # Independent source coefficient extraction: replace c -> c + tau*e0,
    # put odd tau to the left, and extract the term linear in tau.
    source = next(v for v in read('frozen_source_seed_s3_s5/S33_source_couplings.json')['couplings'] if v['target'] == 'c_L')
    assert source['source'] == 'L_c'
    cc = source['coupling_AST']['density']['expression']['factors'][1]['terms'][0]['factors']
    factor = s.sympify(cc[0]['value']); assert factor == -s.Rational(1, 2)
    result = s.zeros(12, 1)
    for gamma in range(12):
        first = coordinates(0, gamma)[4]  # tau*c_gamma
        second = coordinates(gamma, 0)[4]  # c_gamma*tau = -tau*c_gamma
        result[gamma] = s.simplify(factor * (first - second))
    selected_f = coordinates(0, 4)[4]
    assert selected_f != 0 and result[4] == -selected_f
    # Independent grade feasibility via minimum dimension for negative ghost number:
    # every independent generator satisfies d >= max(0,-gh); derivatives/parameters
    # have nonnegative dimension and zero ghost number. Sums inherit the inequality.
    alphabet = read('frozen_c5/C5_alphabet.json')['symbols']
    assert all(v['canonical_dimension'] >= max(0, -v['ghost_number']) for v in alphabet)
    for name in ('K_V', 'K_q', 'K_phi', 'L_u', 'K_Lambda', 'L_c'):
        v = next(v for v in alphabet if v['identity'] == name)
        assert v['canonical_dimension'] - 1 < -(v['ghost_number'] - 1)
    sigma = read('frozen_source_seed_s3_s5/Sigma_M08_V1.json')['Sigma_M08']
    value = {'status': 'EXACT_INDEPENDENT_BOUNDED_COMPONENT_COUNTEREXAMPLE',
        'algorithm': 'Physical normalized 10x10 commutator, independent pivot solve, odd-shift coefficient extraction',
        'primary_math_or_output_imported': False, 'pivot_rows': pivots, 'full_component_residual': 'ZERO',
        'preregistered_component': {'contraction_index': 0, 'source_index': 4, 'remaining_ghost_index': 4,
            'f_4_0_4': str(selected_f), 'coefficient_of_g10_Lc4_c4': str(result[4]), 'nonzero': True},
        'contracted_ghost_vector_over_g10_Lc4': [str(v) for v in result],
        'source_contraction_grade_envelopes_empty': True,
        'source_grade_proof': 'd>=-gh for every generator and permitted coefficient; each required source contraction violates this necessary inequality',
        'R_composite_check': 'A derivation of u*u has an uncontracted u; no bare Lc*c coefficient',
        'Sigma_canonical_sha256': sigma['canonical_action_sha256'],
        'library_runtime_independence': False, 'shared_inputs': 'C3 H basis, S33 source AST, frozen role grades',
        'source_byte_sha256': sha256(Path(__file__).read_bytes()).hexdigest()}
    data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    return dict(value, artifact_sha256=sha256(data).hexdigest())
