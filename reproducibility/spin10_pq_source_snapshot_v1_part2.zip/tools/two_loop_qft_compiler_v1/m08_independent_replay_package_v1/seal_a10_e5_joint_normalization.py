"""Seal selected auxiliary companions and an inactive joint normalization."""
import json,subprocess,sys
from hashlib import sha256
from a10_e5_joint_normalization import HERE,ROOT,OUT,read,STATUS
from seal_a10_e5_ghost_companion import PARENTS as OLD_PARENTS

PARENTS=(*OLD_PARENTS,'frozen_a10_e5_ghost_companion')
SCIENCE=('A10_E5_JOINT_NORMALIZATION_CONTRACT_V1.md','A10_E5_JOINT_NORMALIZATION_DERIVATION_V1.md','A10_E5_JOINT_NORMALIZATION_RESULT.md',
 'a10_e5_joint_normalization.py','run_a10_e5_joint_normalization.py','export_a10_e5_joint_normalization.py','audit_a10_e5_joint_normalization.py',
 'test_a10_e5_joint_normalization.py','validate_a10_e5_joint_normalization.py','export_a10_e5_joint_normalization_receipt.py','seal_a10_e5_joint_normalization.py')
DOCS=('docs/A10_E5_JOINT_NORMALIZATION_CURRENT.md','docs/RESEARCH_EXECUTION_HANDOFF_V17.md')
LIVE=('AGENTS.md',)


def files(receipt=True):
    return [HERE/n for n in SCIENCE]+[ROOT/n for n in (*DOCS,*LIVE)]+sorted(p for p in OUT.rglob('*')
      if p.is_file() and p.name!='bindings.json' and (receipt or p.name!='validation_receipt.json'))


def protected():
    sys.path.insert(0,str(ROOT/'tools'))
    from research_session_preflight import BINDING_KEYS,authenticate_bytes
    manifest=(HERE/'frozen_a10_e5_ghost_companion/bindings.json').relative_to(ROOT).as_posix()
    authenticate_bytes(ROOT,manifest);names=set();seen=set()
    def visit(n):
        if n in seen:return
        seen.add(n);data=read(ROOT/n)
        for key in BINDING_KEYS:names.update(data.get(key,{}))
        for child in data.get('inherited_manifest_sha256',{}):visit(child)
    visit(manifest);names.update(seen)
    return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(names)}


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists()
    if '--process-snapshot' in sys.argv:
        v={'schema':'E5_JOINT_NORMALIZATION_EXECUTION_INSTRUCTIONS_V1','scientific_authority':False,
          'live_instructions_permanent_scientific_dependency':False,
          'files':{n:{'sha256':sha256((ROOT/n).read_bytes()).hexdigest(),'utf8':(ROOT/n).read_text(encoding='utf-8')} for n in LIVE}}
        assert not (OUT/'process_snapshot.json').exists()
        (OUT/'process_snapshot.json').write_bytes(json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n')
        print('EXPORTED execution instructions');return
    r=read(OUT/'validation_receipt.json')
    assert r['status']=='PASS_BOUNDED_JOINT_NORMALIZATION_VALIDATION_ONLY' and r['scientific_gate']==STATUS
    assert r['targeted_regression_tests']==377 and r['fresh_routes_byte_identical']==2 and r['fresh_artifacts_byte_identical']==2
    assert not r['audit_time_changes'] and protected()==r['protected_byte_sha256']
    assert r['historical_custody_exit']==2 and r['unresolved_historical_references']==7
    assert r['independent_pairing_and_width_checks']['direct_graded_source_source_cross_pairings']==1089
    for n,h in r['new_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,('AFTER_VALIDATION_CHANGED',n)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==r['state_sha256']
    from audit_a10_e5_joint_normalization import authenticate
    assert authenticate()['scientific_gate']==STATUS
    for p in files():
        raw=p.read_bytes();raw.decode('utf-8');assert raw.endswith(b'\n'),str(p)
    for n,row in read(OUT/'process_snapshot.json')['files'].items():
        assert row['sha256']==sha256((ROOT/n).read_bytes()).hexdigest() and row['utf8'].encode()==(ROOT/n).read_bytes()
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='d138e586beb77c7cd42b91ef2b9419c80c033a50'
    v={'schema':'A10_E5_JOINT_NORMALIZATION_BINDINGS_V1','base_commit':base,
      'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in files() if p.relative_to(ROOT).as_posix() not in LIVE},
      'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
      'state_sha256':r['state_sha256'],'scientific_disposition':STATUS,
      'predecessor_source_poles_authenticated':True,'predecessor_selected_source_projections_preserved':True,'complete_other_loop_poles_match_candidate_proved':False,'ghost_only_normalization_sufficient':False,'selected_kinetic_log_pole_zero':True,'selected_auxiliary_poles_and_joint_image_match':True,
      'complete_nonzero_g_restoration_proved':False,'full_quantum_M2_M5_nonempty_proved':False,
      'all_source_insertion_and_contact_identities_proved':False,'full_anomaly_freedom_proved':False,
      'full_E5_PASS':False,'A1_A5_discharged':False,'weighted_gF_quantum_A5_equivalence_proved':False,
      'authority_changed':False,'catalog_generated':False,'sources_activated':False,'auxiliaries_eliminated':False,
      'HB1_C5_run':False,'C1_GS_calculated':False,'remote_push':False,'external_endorsement':False,
      'post_validation_finalization':'receipt export and byte seal only; no derivation edits'}
    with (OUT/'bindings.json').open('xb') as f:f.write(json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED selected auxiliary poles and joint normalization; full quantum restoration remains open')


if __name__=='__main__':main()
