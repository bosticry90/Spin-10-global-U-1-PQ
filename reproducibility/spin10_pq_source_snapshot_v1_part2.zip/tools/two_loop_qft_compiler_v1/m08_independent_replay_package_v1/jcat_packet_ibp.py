"""Exact total-derivative image intersected with the covariant packet span.

The immutable boundary convention removes local total derivatives. A current
need not be pointwise covariant; its divergence must be an admissible packet.
No EOM, BRST or final-statistics relation enters this space.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations_with_replacement
import sympy as sp
from jcat_packet_permutations import *
from jcat_physical_jets import construct,canon,tensor_generators


def relation_quotient(R):
    reduced,pivots=R.T.rref();free=[i for i in range(R.rows) if i not in pivots]
    q=sp.zeros(len(free),R.rows);section=sp.zeros(R.rows,len(free))
    for j,i in enumerate(free):q[j,i]=section[i,j]=1
    for row,pivot in enumerate(pivots):
        for j,i in enumerate(free):q[j,pivot]=-reduced[row,i]
    assert q*R==sp.zeros(q.rows,R.cols) and q*section==sp.eye(q.rows)
    assert R.rank()+q.rows==R.rows
    return q,section,tuple(free)


def independent_columns(M):
    return M[:,list(M.rref()[1])]


def intersection_coordinates(P,R):
    """Coordinates in the full-rank P columns of span(P) intersection span(R)."""
    joined=P.row_join(-R);ns=joined.nullspace()
    solutions=sp.Matrix.hstack(*ns) if ns else sp.zeros(joined.cols,0)
    packet=solutions[:P.cols,:]
    packet=independent_columns(packet)
    assert packet.rank()==packet.cols
    return packet


def ordinary_relations(engine,record):
    index={engine.source_key(s):i for i,s in enumerate(record['sources'])}
    source_groups=defaultdict(list)
    for s in record['sources']:
        source_groups[(s['signature_id'],address_key(s['address']))].append(s)
    columns=[];parents=[]
    for (sid,_),sources in sorted(source_groups.items()):
        row=engine.engine.rows[sid];types=engine.engine.contract_rows[sid]['field_types']
        vectors=tuple(i for i,t in enumerate(types) if t['Lorentz_type']=='VECTOR')
        degrees=tuple(sorted({row['raw_Lorentz_derivative_addresses'][s['jet_index']][0] for s in sources}))
        jets,R,_,_,_=construct(vectors,len(types),degrees)
        lookup={tup(j):i for i,j in enumerate(row['raw_Lorentz_derivative_addresses'])}
        for j in range(R.cols):
            values={}
            for k in range(R.rows):
                if R[k,j] and jets[k] in lookup:
                    key=(sid,address_key(sources[0]['address']),lookup[jets[k]])
                    if key in index:values[index[key],0]=R[k,j]
            if values:
                columns.append(sp.SparseMatrix(len(record['sources']),1,values))
                parents.append({'signature_id':sid,'internal_address':sources[0]['address'],
                    'ordinary_total_derivative_column':j})
    return (sp.Matrix.hstack(*columns) if columns else sp.zeros(len(record['sources']),0)),parents


def primary_ibp(engine,cid,hom):
    record=engine.primary(cid,hom);q=matrix(record['quotient_map']);P=matrix(record['canonical_packet_basis'])
    R,parents=ordinary_relations(engine,record);faithful=q*R
    relation=intersection_coordinates(P,faithful)
    Q,section,free=relation_quotient(relation)
    # Every accepted relation is precisely a total derivative and a packet.
    assert faithful.row_join(P*relation).rank()==faithful.rank()
    return {'class_id':cid,'homogeneous_components':hom,'packet_dimension':P.cols,
        'ordinary_current_count':len(parents),'ordinary_total_derivative_image_rank':faithful.rank(),
        'ordinary_current_provenance':parents,'ordered_total_derivative_matrix':serial(R),
        'packet_IBP_relation_basis':serial(relation),'IBP_relation_rank':relation.cols,
        'quotient_dimension':Q.rows,'quotient_map':serial(Q),'section':serial(section),
        'canonical_quotient_packet_indices':free,'parity':engine.groups[cid]['parity'],
        'background_covariant_relation_residual':'ZERO_EXACT_BY_PACKET_INTERSECTION',
        'total_derivative_realization_residual':'ZERO_EXACT','EOM_quotiented':False,
        'BRST_quotiented':False,'statistics_projected':False}


def replay_divergences(engine,record):
    """Literal ordinary-jet Leibniz on colored tensor words, not primary R."""
    sources=record['sources'];current_specs={}
    for source in sources:
        sid=source['signature_id'];row=engine.engine.rows[sid]
        d=row['raw_Lorentz_derivative_addresses'][source['jet_index']][0]
        if not d:continue
        key=(sid,address_key(source['address']),d)
        current_specs.setdefault(key,source)
    polys=[]
    from jcat_global_packets import normalize_words,lorentz_indices
    import json
    for (sid,_,d),source in sorted(current_specs.items()):
        row=engine.engine.rows[sid];names=[r['field'] for r in row['ordered_occurrences']]
        vectors=[('v',i) for i,t in enumerate(engine.engine.contract_rows[sid]['field_types']) if t['Lorentz_type']=='VECTOR']
        slots,copies=engine.engine.catalog.address_parts(source['address'])[2:4]
        homtags={i:'H'+str(sum(n!='Abar_H_mu' for n in names[:i])) for i,n in enumerate(names) if n!='Abar_H_mu'}
        for placement in combinations_with_replacement(range(len(names)),d-1):
            for (parity,contraction),phase in tensor_generators(vectors+[('p',i) for i in placement]+[('q',-1)]):
                if not phase or parity!=engine.groups[record['class_id']]['parity']:continue
                vi,ds,rel=lorentz_indices((parity,contraction));free=ds[-1][0];words=[]
                for colors,c in engine.engine.tensor(json.dumps(source['address'],sort_keys=True)):
                    factors=tuple(('A' if i in source['background_slots'] else homtags[i],
                        engine.engine.as_by_component[slots[i]]+colors[i] if i in source['background_slots'] else colors[i],
                        vi.get(i,-1),tuple(ds.get(i,()))) for i in range(len(names)))
                    for i,f in enumerate(factors):
                        new=list(factors);new[i]=(f[0],f[1],f[2],f[3]+(free,))
                        words.append((tuple(new),phase*c))
                polys.append(normalize_words(words,parity,rel))
    return polys


def replay_ibp(engine,cid,hom):
    record=dict(engine.primary(cid,hom),class_id=cid)
    E=[engine.engine.source_polynomial(s) for s in record['sources']]
    section=matrix(record['section']);faithful=[combine(E,section[:,j]) for j in range(section.cols)]
    derivatives=replay_divergences(engine,record)
    R=coordinate_extraction(faithful,derivatives)
    P=matrix(record['canonical_packet_basis']);relation=intersection_coordinates(P,R)
    Q,_,_=relation_quotient(relation)
    return {'class_id':cid,'homogeneous_components':hom,'packet_IBP_relation_basis':serial(relation),
        'IBP_relation_rank':relation.cols,'quotient_dimension':Q.rows,
        'ordinary_divergence_count':len(derivatives),
        'route':'Colored constrained tensors with independently prolonged ordinary current words, realization, and packet-span intersection',
        'primary_IBP_coefficients_imported':False,'ALGORITHM_INDEPENDENT':True,
        'CODE_PATH_INDEPENDENT':True,'LIBRARY_INDEPENDENT':False,'RUNTIME_INDEPENDENT':False,
        'shared':'Qualified tensor/realization data, canonical Lorentz normalizer and exact SymPy linear algebra'}
