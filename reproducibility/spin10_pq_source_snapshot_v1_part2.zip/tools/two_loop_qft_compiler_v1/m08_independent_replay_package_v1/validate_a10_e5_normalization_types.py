"""Read-only validation of a classical prerequisite, not quantum acceptance."""
import json, os, re, subprocess, sys, time
from hashlib import sha256
from a10_e5_normalization_types import HERE, ROOT, OUT, read, STATUS
from validate_interacting_actual_h_preflight import inventory


def protected():
    sys.path.insert(0, str(ROOT / 'tools'))
    from research_session_preflight import BINDING_KEYS, authenticate_bytes
    manifest = (HERE / 'frozen_a10_e5_quartic_companion/bindings.json').relative_to(ROOT).as_posix()
    authenticate_bytes(ROOT, manifest); names = set(); seen = set()
    def visit(name):
        if name in seen: return
        seen.add(name); data = read(ROOT / name)
        for key in BINDING_KEYS: names.update(data.get(key, {}))
        for child in data.get('inherited_manifest_sha256', {}): visit(child)
    visit(manifest); names.update(seen)
    assert len(seen) == 32
    return {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)}


def new_files():
    names = ['a10_e5_normalization_types.py', 'run_a10_e5_normalization_types.py',
        'export_a10_e5_normalization_types.py', 'audit_a10_e5_normalization_types.py',
        'test_a10_e5_normalization_types.py', 'validate_a10_e5_normalization_types.py',
        'export_a10_e5_normalization_types_receipt.py', 'seal_a10_e5_normalization_types.py']
    files = [HERE / n for n in names] + list(HERE.glob('A10_E5_NORMALIZATION_TYPES*.md'))
    files += [ROOT / 'docs/A10_E5_NORMALIZATION_TYPES_CURRENT.md', ROOT / 'docs/RESEARCH_EXECUTION_HANDOFF_V21.md']
    files += [p for p in OUT.rglob('*') if p.is_file() and p.name not in ['bindings.json', 'validation_receipt.json']]
    return sorted(set(files))


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    before = inventory(); old = protected()
    new = {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in new_files()}
    state = sha256((ROOT / 'project_state.json').read_bytes()).hexdigest()
    assert state == 'd610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT / 'tools/pole_blind_validation_guard'))
    tasks = [('normalization_type_evidence', [str(HERE / 'audit_a10_e5_normalization_types.py')], ROOT),
        ('scientific_regressions', ['-m', 'unittest', 'test_a10_e5_normalization_types', 'test_a10_e2_transport', 'test_a10_e3_symmetry', '-v'], HERE),
        ('process_regressions', ['-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_research_*.py'], ROOT),
        ('governance', ['-m', 'unittest', 'discover', '-s', 'docs/ai_research_epistemic_ladder_v1', '-p', 'test_*.py'], ROOT),
        ('delegated_existing_e5', ['tools/research_check.py', 'e5'], ROOT),
        ('fresh_own_byte_routes', [str(HERE / 'audit_a10_e5_normalization_types.py'), '--fresh'], ROOT)]
    records = []; started = time.perf_counter()
    for name, args, cwd in tasks:
        print('START ' + name, flush=True); tick = time.perf_counter()
        proc = subprocess.Popen([sys.executable, '-B', *args], cwd=cwd, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
        lines = []
        for line in proc.stdout:
            lines.append(line)
            if not line.startswith(('AUDIT ', '{')): print(line, end='', flush=True)
        code = proc.wait(); output = ''.join(lines)
        records.append({'name': name, 'command': [sys.executable, '-B', *args], 'exit_code': code,
            'expected_exit_code': 0, 'seconds': time.perf_counter() - tick, 'stdout_and_stderr': output})
        print('DONE ' + name + ' ' + str(code), flush=True); assert code == 0, records[-1]
    counts = {name: int(re.search(r'Ran (\d+) tests?', next(r['stdout_and_stderr'] for r in records if r['name'] == name)).group(1))
        for name in ['scientific_regressions', 'process_regressions', 'governance']}
    events = [json.loads(line) for line in next(r['stdout_and_stderr'] for r in records if r['name'] == 'delegated_existing_e5').splitlines()]
    assert events[-1]['execution_state'] == 'COMPLETED' and events[-1]['scientific_acceptance'] == 'NOT_PERFORMED'
    custody = next(e for e in events if e.get('step') == 'historical_custody' and e['event'] == 'step_finished')
    assert custody['exit_code'] == 2 and custody['stdout'].count('RECORDED_DIGEST_UNRESOLVED:') == 7
    fresh = json.loads(next(line[6:] for line in records[-1]['stdout_and_stderr'].splitlines() if line.startswith('AUDIT ')))
    assert len(fresh['fresh_routes']) == 2 and all(v['own_bytes_identical'] and v['start_identical'] for v in fresh['fresh_routes'])
    after = inventory(); changes = sorted(n for n in before.keys() | after.keys() if before.get(n) != after.get(n))
    assert not changes and protected() == old
    assert {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in new_files()} == new
    assert sha256((ROOT / 'project_state.json').read_bytes()).hexdigest() == state
    print('RECEIPT ' + json.dumps({'schema': 'E5_NORMALIZATION_TYPES_VALIDATION_V1',
        'status': 'PASS_BOUNDED_NORMALIZATION_TYPES_AND_CLASSICAL_SHEAR_ONLY', 'scientific_disposition': STATUS,
        'tasks': records, 'test_counts': counts, 'targeted_tests': sum(counts.values()), 'fresh_routes_byte_identical': 2,
        'predecessor_chains_authenticated': 32, 'protected_byte_sha256': old, 'new_sha256': new, 'state_sha256': state,
        'audit_time_changes': changes, 'metadata_records': len(before), 'metadata_inventory_kind': 'size_and_mtime_not_whole_environment_byte_audit',
        'wall_seconds': time.perf_counter() - started, 'historical_custody_exit': 2, 'unresolved_historical_references': 7,
        'old_expensive_scientific_replays_run': False, 'failed_attempts_counted_as_PASS': 0,
        'source_free_obstruction': True, 'classical_shear': fresh, 'new_loop_amplitudes_computed': False,
        'residual_fit': False, 'preceding_quartic_failure_replaced': False, 'normalization_adopted': False,
        'quantum_A5_or_full_E5_PASS': False, 'whole_goal_complete': False, 'authority': '34/39_UNCHANGED'}, sort_keys=True, separators=(',', ':')), flush=True)


if __name__ == '__main__': main()
