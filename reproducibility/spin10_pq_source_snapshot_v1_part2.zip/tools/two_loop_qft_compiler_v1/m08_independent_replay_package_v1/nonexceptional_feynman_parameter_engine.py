"""Independent one-loop Feynman-parameter UV-pole primitives.

The engine returns coefficients in units of 1/(16*pi**2*epsilon_bar).  It
keeps d=4-2*epsilon and isotropic tensor denominators symbolic until the pole
limit is taken.  It does not import any primary M08 Taylor or auxiliary-mass
kernel.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha256
import inspect
from math import prod
from typing import Iterable

import sympy as sp


EPSILON = sp.Symbol("epsilon", positive=True)
D = 4 - 2 * EPSILON
DELTA = sp.Symbol("Delta", positive=True)


@dataclass(frozen=True)
class ShiftedTensorTerm:
    coefficient: sp.Expr
    tensor_rank: int
    extra_loop_squared_power: int = 0
    tensor_label: str = "scalar"

    def __post_init__(self) -> None:
        if self.tensor_rank < 0:
            raise ValueError("tensor rank must be nonnegative")
        if self.extra_loop_squared_power < 0:
            raise ValueError("extra loop-squared power must be nonnegative")


def isotropic_pairing_denominator(rank: int, dimension: sp.Expr = D) -> sp.Expr:
    if rank % 2:
        raise ValueError("odd tensor rank has no isotropic pairing denominator")
    return sp.prod(dimension + 2 * step for step in range(rank // 2))


@lru_cache(maxsize=None)
def feynman_parameter_master_pole(
    denominator_count: int,
    loop_squared_power: int,
) -> sp.Expr:
    """Pole of the parameter integrand, including Gamma(N) parameter prefactor."""
    if denominator_count not in (2, 3, 4, 5, 6):
        raise ValueError("supported denominator count is 2 through 6")
    if loop_squared_power < 0:
        raise ValueError("loop power must be nonnegative")
    n = sp.Integer(denominator_count)
    a = sp.Integer(loop_squared_power)
    expression = (
        16
        * sp.pi**2
        * (4 * sp.pi) ** (-D / 2)
        * sp.gamma(a + D / 2)
        * sp.gamma(n - a - D / 2)
        / sp.gamma(D / 2)
        * DELTA ** (a + D / 2 - n)
    )
    return sp.simplify(sp.limit(EPSILON * expression, EPSILON, 0))


def shifted_tensor_term_pole(
    denominator_count: int,
    term: ShiftedTensorTerm,
) -> sp.Expr:
    if term.tensor_rank % 2:
        return sp.Integer(0)
    radial_power = term.tensor_rank // 2 + term.extra_loop_squared_power
    expression = (
        term.coefficient
        * feynman_parameter_master_pole(denominator_count, radial_power)
        / isotropic_pairing_denominator(term.tensor_rank, D)
    )
    # Crucially, the d-dependent tensor factor is still present here.
    return sp.simplify(sp.limit(expression, EPSILON, 0))


def simplex_symbols(denominator_count: int) -> tuple[sp.Symbol, ...]:
    return sp.symbols("x0:" + str(denominator_count), nonnegative=True)


def simplex_integrate(expression: sp.Expr, parameters: tuple[sp.Symbol, ...]) -> sp.Expr:
    if len(parameters) < 2:
        raise ValueError("at least two Feynman parameters are required")
    independent = parameters[1:]
    result = sp.expand(expression.subs(parameters[0], 1 - sum(independent)))
    # x1 is innermost; its upper bound depends on x2,... .
    for position, parameter in enumerate(independent):
        later = independent[position + 1 :]
        result = sp.integrate(result, (parameter, 0, 1 - sum(later)))
    return sp.simplify(result)


def feynman_delta(
    masses_squared: tuple[sp.Expr, ...],
    q_dot: tuple[tuple[sp.Expr, ...], ...],
    parameters: tuple[sp.Symbol, ...],
) -> sp.Expr:
    count = len(masses_squared)
    if len(parameters) != count or len(q_dot) != count:
        raise ValueError("mass, shift, and parameter counts must agree")
    for row in q_dot:
        if len(row) != count:
            raise ValueError("q_dot must be square")
    q_bar_squared = sum(
        parameters[left] * parameters[right] * q_dot[left][right]
        for left in range(count)
        for right in range(count)
    )
    return sp.expand(
        sum(
            parameters[index] * (masses_squared[index] + q_dot[index][index])
            for index in range(count)
        )
        - q_bar_squared
    )


def evaluate_shifted_terms(
    denominator_count: int,
    terms: Iterable[ShiftedTensorTerm],
    parameters: tuple[sp.Symbol, ...],
    delta_expression: sp.Expr,
) -> dict[str, sp.Expr]:
    by_tensor: dict[str, sp.Expr] = {}
    for term in terms:
        pole = shifted_tensor_term_pole(denominator_count, term).subs(DELTA, delta_expression)
        integrated = simplex_integrate(pole, parameters)
        by_tensor[term.tensor_label] = sp.simplify(
            by_tensor.get(term.tensor_label, sp.Integer(0)) + integrated
        )
    return by_tensor


def is_local_polynomial(expression: sp.Expr, invariants: Iterable[sp.Symbol]) -> bool:
    expanded = sp.cancel(expression)
    if expanded.has(sp.log):
        return False
    numerator, denominator = sp.fraction(expanded)
    if any(denominator.has(symbol) for symbol in invariants):
        return False
    return bool(numerator.is_polynomial(*tuple(invariants)))


def source_sha256() -> str:
    return sha256(inspect.getsource(inspect.getmodule(source_sha256)).encode()).hexdigest()
