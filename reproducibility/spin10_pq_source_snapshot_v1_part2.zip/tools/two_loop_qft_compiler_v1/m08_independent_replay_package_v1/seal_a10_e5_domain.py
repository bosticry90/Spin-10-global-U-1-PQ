"""Seal only newly validated bounded E5 stopping evidence and process versions."""
import json,subprocess,sys
from hashlib import sha256
from a10_e5_domain_common import HERE,ROOT,OUT,read,STATUS
from a10_e4_interaction_common import PREDECESSORS as E4_PARENTS

PARENTS=(*E4_PARENTS,'frozen_a10_e4_interaction')
SCIENCE_FILES=('A10_E5_DOMAIN_CONTRACT_V1.md','A10_E5_DOMAIN_RESULT.md',
    'a10_e5_domain_common.py','a10_e5_domain_primary.py','a10_e5_domain_replay.py',
    'run_a10_e5_domain.py','export_a10_e5_domain.py','audit_a10_e5_domain.py',
    'test_a10_e5_domain.py','validate_a10_e5_domain.py','export_a10_e5_domain_receipt.py','seal_a10_e5_domain.py')
DOCS=('docs/SHAPE_UP_RAILS_GAP_ANALYSIS_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
    'docs/RESEARCH_EXECUTION_HANDOFF_V2.md','docs/SHAPE_UP_RAILS_INCORPORATION_RESULT_V1.md','docs/A10_E5_DOMAIN_CURRENT.md')
LIVE=('AGENTS.md','tools/research_check.py','tools/test_research_check.py')


def files(receipt=True):
    return [HERE/n for n in SCIENCE_FILES]+[ROOT/n for n in (*DOCS,*LIVE)]+sorted(p for p in OUT.iterdir()
        if p.is_file() and p.name!='bindings.json' and (receipt or p.name!='validation_receipt.json'))


def protected():
    sys.path.insert(0,str(ROOT/'tools'))
    from research_session_preflight import BINDING_KEYS,authenticate_bytes
    manifest=(HERE/'frozen_a10_e4_interaction/bindings.json').relative_to(ROOT).as_posix()
    authenticate_bytes(ROOT,manifest)
    names=set();seen=set()
    def visit(n):
        if n in seen:return
        seen.add(n);data=read(ROOT/n)
        for key in BINDING_KEYS:names.update(data.get(key,{}))
        for child in data.get('inherited_manifest_sha256',{}):visit(child)
    visit(manifest);names.add(manifest)
    return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(names)}


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'SEALED'
    if '--process-snapshot' in sys.argv:
        value={'schema':'SHAPE_UP_LOCAL_PROCESS_SNAPSHOT_V1','scientific_authority':False,
               'live_generic_tools_are_permanent_scientific_dependencies':False,
               'files':{n:{'sha256':sha256((ROOT/n).read_bytes()).hexdigest(),
                           'utf8':(ROOT/n).read_text(encoding='utf-8')} for n in LIVE}}
        (OUT/'process_snapshot.json').write_bytes(json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n')
        print('EXPORTED process version snapshot');return
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['status']=='PASS_BOUNDED_E5_STOP_AND_ENGINEERING_VALIDATION_ONLY'
    assert receipt['scientific_gate']==STATUS and receipt['fresh_E5_routes_byte_identical']==2
    assert receipt['targeted_regression_tests']==111 and not receipt['audit_time_changes']
    assert receipt['historical_custody_exit']==2 and receipt['unresolved_historical_references']==7
    assert protected()==receipt['protected_byte_sha256']
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==receipt['state_sha256']
    for n,h in receipt['new_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,('AFTER_VALIDATION_CHANGED',n)
    from audit_a10_e5_domain import authenticate
    assert authenticate()['scientific_gate']==STATUS
    for p in files():
        raw=p.read_bytes();assert b'\r\n' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),str(p)
    for n,row in read(OUT/'process_snapshot.json')['files'].items():
        assert row['sha256']==sha256((ROOT/n).read_bytes()).hexdigest() and row['utf8'].encode()==(ROOT/n).read_bytes()
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='76affe53da3efe7e66bd5e35dc03af1467ee88bd'
    value={'schema':'A10_E5_STOP_AND_LOCAL_ENGINEERING_BINDINGS_V1','base_commit':base,
       'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in files()
                      if p.relative_to(ROOT).as_posix() not in LIVE},
       'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
       'state_sha256':receipt['state_sha256'],'scientific_disposition':STATUS,'E5_full_PASS':False,
       'authority_changed':False,'catalog_generated':False,'sources_activated':False,'HB1_C5_run':False,
       'C1_GS_calculated':False,'remote_push':False,'external_endorsement':False,
       'post_validation_finalization':'receipt export and byte seal; no derivation edits'}
    (OUT/'bindings.json').write_bytes(json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED bounded stopping evidence; full E5 remains unqualified')


if __name__=='__main__':main()
