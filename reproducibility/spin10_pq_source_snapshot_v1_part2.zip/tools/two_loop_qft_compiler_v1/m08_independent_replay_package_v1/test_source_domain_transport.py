"""Frozen-evidence regressions; the bounded audit rebuilds both exact routes."""
import copy
import inspect
import json
import re
from pathlib import Path
import unittest
import sympy as s
from audit_source_domain_transport import compare, negative_controls
import source_domain_transport_replay as replay


class SourceDomainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out = Path(__file__).resolve().parent/"frozen_source_domain_transport"
        cls.p = json.loads((out/"primary.json").read_text()); cls.r = json.loads((out/"replay.json").read_text())
    def test_complete_comparison(self): compare(self.p, self.r)
    def test_36_adversarial_claims(self): self.assertEqual(negative_controls(self.p, self.r), 36)
    def test_preregistered_selection(self): self.assertEqual(self.p["source_bridge"]["selected_H_indices"], [0, 1, 4, 11])
    def test_coordinate_bridge_all_H(self): self.assertEqual(self.p["source_bridge"]["H_gram"]["shape"], [12, 12])
    def test_wrong_delta_bracket_retained(self): self.assertTrue(self.p["source_bridge"]["wrong_delta_bracket_residual"]["entries"])
    def test_evaluation_dual_conjugation(self): self.assertTrue(self.p["source_bridge"]["evaluation_dual_conjugation"]["entries"])
    def test_legacy_decoder_not_inferred(self): self.assertFalse(self.p["source_bridge"]["legacy_catalog_decoder_bound"])
    def test_40_generators_not_historical17_replacement(self): self.assertEqual(self.p["block"]["base_generators"], 40); self.assertFalse(self.p["M08_changed"])
    def test_160_columns(self): self.assertEqual(sum(len(c) for c in self.p["block"]["images"].values()), 160)
    def test_20_pairs(self): self.assertEqual(self.p["block"]["canonical_pairs"], 20)
    def test_one_derivation_scope(self): self.assertEqual(self.p["block"]["ordinary_derivations"], 1)
    def test_no_physical_action_claim(self): self.assertFalse(self.p["block"]["kinetic_potential_action_included"])
    def test_local_Lie_includes_background(self): self.assertEqual(self.p["block"]["pre_structural_check_counts"]["local_Lie"], 124)
    def test_contraction_covariance(self): self.assertEqual(self.p["block"]["pre_structural_check_counts"]["local_iota_covariance"], 80)
    def test_quantum_and_Ward_commute_with_Q(self): self.assertEqual(self.p["block"]["pre_structural_check_counts"]["TQ"], 80)
    def test_background_transport_not_assumed(self): self.assertTrue(self.p["block"]["transport"]["background_action_unchanged"])
    def test_canonical_cross_sources(self): self.assertEqual(self.p["block"]["transport"]["canonical_source_cross_pair_checks"], 210)
    def test_first_jet_transport(self): self.assertEqual(self.p["block"]["transport"]["ordinary_first_jet_prolongation_checks"], 80)
    def test_nonzero_source_basic_image(self): self.assertTrue(self.p["block"]["domain"]["pre_Q_image"])
    def test_nonzero_transported_source_image(self): self.assertTrue(self.p["block"]["domain"]["fixed_Q_image"])
    def test_wrong_raw_domain_not_total_derivative(self): self.assertTrue(self.p["block"]["negative_controls"]["nonzero_scalar_Euler_residual"])
    def test_wrong_dot_pairing_control(self): self.assertTrue(self.p["block"]["negative_controls"]["wrong_plain_dot_Ward_residual"])
    def test_master_currents(self): self.assertTrue(all(r["all_Euler_residuals_zero"] for r in self.p["block"]["master"].values()))
    def test_Sigma_not_required_basic(self): self.assertFalse(self.p["candidate"]["Sigma_basic_required"])
    def test_no_source_zero_quotient(self): self.assertFalse(self.p["candidate"]["source_zero_quotient"])
    def test_parameter_order_retained(self): self.assertTrue(self.p["candidate"]["independent_parameter_then_substitution"])
    def test_no_full_M08_or_HB1(self): self.assertFalse(self.p["candidate"]["full_M08_qualified"] or self.p["HB1_C5_authorized"])
    def test_no_cochain_dimensions(self): self.assertFalse(self.p["cochain_dimensions_computed"])
    def test_no_EOM_or_jet_truncation(self): self.assertFalse(self.p["block"]["EOM_used"] or self.p["block"]["jet_truncation"])
    def test_authority_unchanged(self): self.assertEqual(self.p["formal_authority"], "34/39_UNCHANGED"); self.assertIsNone(self.p["finite_C1_GS"])
    def test_no_external_endorsement(self): self.assertFalse(self.p["external_specialist_review"])
    def test_honest_independence(self): self.assertFalse(self.r["independence"]["LIBRARY_INDEPENDENT"] or self.r["independence"]["analyst_blind"])
    def test_replay_no_primary_import(self): self.assertNotIn("from source_domain_transport import", inspect.getsource(replay))
    def test_replay_rejects_floating_coefficients(self):
        with self.assertRaises(AssertionError): replay.DomainWords.record({(): s.Float(0.5)})
    def test_candidate_source_table_uses_frozen_field_grades(self):
        here = Path(__file__).resolve().parent
        fields = {row["identity"]: row for row in json.loads((here/"frozen_c5/C5_alphabet.json").read_text())["symbols"]}
        text = (here/"SOURCE_DOMAIN_TRANSPORT_CONTRACT_V1.md").read_text()
        rows = re.findall(r"^\| (\w+) \| J_\w+ / (?:prospective )?(\w+) \| \((\d+),(-?\d+),(odd|even)\) \|$", text, re.M)
        self.assertEqual(len(rows), 9)
        for field, source, dimension, ghost, parity in rows:
            z = fields[{"V_H": "V_H_mu", "q_L": "q_L_mu"}.get(field, field)]
            expected = (3-z["canonical_dimension"], -1-z["ghost_number"], "odd" if z["grassmann_parity"] == "EVEN" else "even")
            self.assertEqual((int(dimension), int(ghost), parity), expected)
            if source in fields:
                old = fields[source]
                self.assertEqual((old["canonical_dimension"], old["ghost_number"], old["grassmann_parity"].lower()), expected)
    def test_actual_physical_geometry_reconstructed(self): self.assertEqual(self.r["independence"]["physical_parent_commutators"], 990); self.assertFalse(self.r["independence"]["scalar_328_reconstructed"])
    def test_false_transport_claim_rejected(self):
        bad = copy.deepcopy(self.p); bad["block"]["transport"]["background_action_unchanged"] = False
        with self.assertRaises(AssertionError): compare(bad, self.r)


if __name__ == "__main__": unittest.main()
