"""Adjudicate JCAT12 only; never construct the later C5 complex."""
from jcat_packet_catalog_evidence import *
from execute_jcat_packet_catalog import freeze


def main():
    assert load(OUT/'JCAT11_checkpoint.json')['JCAT11']=='PASS'
    specification=reconstruction_coverage()
    freeze('JCAT12_reconstruction_coverage.json',specification)
    controls=[];engine=FinalOperators()
    for case in specification['cases']:
        print('JCAT12_RECONSTRUCT',case['role'],flush=True)
        r=reconstruct(case,engine);freeze('JCAT12_'+case['role']+'_reconstruction.json',r);controls.append(r)
    counts=evidence();freeze('JCAT12_completeness_ledger.json',counts)
    conjugation={'status':'COMPLETE_EXACT_DESCENDING_FINAL_CONJUGATION',
        'ordered_authority':'M08_INT8_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2',
        'packet_authority':'JCAT8_factor_conjugation_diagrams.json',
        'affine_packet_blocks':'<class_id>_packet_conjugation.json for every active JCAT7 completion class',
        'IBP_descent_authority':'JCAT9_quotient_descent.json',
        'final_transport':'Act with INT8 on each expansion coefficient and conjugate it; use JCAT7 realization/packet maps, JCAT9 quotient, and the JCAT11 allowed-basis exact pivot inverse in each coset block',
        'proof':'JCAT8 conjugation commutes with the full slot action; JCAT9 relations are conjugation-invariant; real species statistics characters commute with anti-linear conjugation. Thus the final statistics image is conjugation-closed.',
        'Lorentz_side':'The frozen metric and oriented epsilon coefficients are real; parity sectors remain traceable',
        'historical_adapter_used':False,'canonical_internal_basis_changed':False}
    assert (OUT/conjugation['packet_authority']).exists()
    freeze('JCAT12_final_conjugation_descriptor.json',conjugation)
    old=load(PACKETS/'JCAT7G_checkpoint.json')
    artifacts={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('*.json'))
        if p.name not in (PROMOTION+'.json','JCAT12_checkpoint.json')}
    promotion={'object_id':PROMOTION,'status':'PROMOTED_COMPLETE_BOUNDED_LOCAL_OPERATOR_CATALOG',
        'authority_ceiling':'Complete bounded physical 4D local-operator catalog after exact realization identities, affine background covariance, IBP and diagonal identical-field statistics; not C5, cohomology, counterterm closure or empirical Spin(10) viability',
        'bindings':{'JCAT7_packet_basis':old['artifact_sha256'],
            'upstream_input_byte_hashes':load(OUT/'JCAT8_custody.json')['immutable_input_byte_hashes']},
        'counts':{k:v for k,v in counts.items() if k!='rows'},'artifacts':artifacts,
        'canonical_internal_basis_changed':False,'upstream_objects_changed':False,
        'quotients_and_projections':['QUALIFIED_REALIZATION_NULL','BACKGROUND_COVARIANT_KERNEL','EXACT_IBP','DIAGONAL_SPECIES_STATISTICS'],
        'IBP_rule':'All exact local total derivatives whose divergence lies in the admissible packet space; no EOM, no requirement that the generating current itself be covariant',
        'final_address_schema':'(class ID, carrier/copy orbit ID, exact allowed local column) plus canonical coset transport, IBP section, packet embedding and frozen expansion-address selector',
        'evaluator':'jcat_final_operator_evaluator.FinalOperators.representative',
        'representative_convention':'Exact local density representatives modulo IBP; surviving homogeneous tags are provenance, with physical identical-field algebra enforced by the final species statistics projector',
        'conjugation_descriptor':'JCAT12_final_conjugation_descriptor.json',
        'forbidden_payload_read':False,'EOM_quotiented':False,'C5_constructed':False}
    h=freeze(PROMOTION+'.json',promotion)
    freeze('JCAT12_checkpoint.json',{'status':'PASS_COMPLETE_JOINT_LOCAL_OPERATOR_CATALOG_STOPPED_AT_JCAT12',
        'current_blocker':NEXT,'JCAT8_JCAT12':'PASS','joint_catalog_promoted':True,
        'ordered_basis_promoted':True,'JCAT7_promoted':True,'counts':promotion['counts'],
        'promotion_byte_hash':h,'formal_authority':AUTHORITY,
        'preserved_authority_links':old['preserved_authority_links'],
        'all_431_expansion_addresses_preserved':True,'forbidden_payload_read':False,
        'DISTANCE_TO_C1_GS':'ONE_GATE_REMOVED','distance_semantics':'PROJECT_MANAGEMENT_METADATA_ONLY',
        'not_executed':['C5','B_Sigma_differential_matrices','EOM_quotient','H0','C6','D6','E','M08_attempt2','M09_M13','Layer6','C1_GS']})
    print('JCAT12_PROMOTED_STOP_BEFORE_C5',counts['final_operator_dimension'],flush=True)


if __name__=='__main__':main()
