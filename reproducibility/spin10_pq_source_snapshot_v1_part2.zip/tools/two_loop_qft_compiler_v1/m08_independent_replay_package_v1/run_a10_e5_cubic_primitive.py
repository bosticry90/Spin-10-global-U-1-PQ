"""Read-only prerequisite route with immutable preparation/start fingerprints."""
import json,sys,time
from hashlib import sha256
from a10_e5_cubic_primitive import HERE,ROOT,OUT,build,s,read


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==3 and sys.argv[1] in ('primary','replay')
    preparation=OUT/sys.argv[2]/'preparation.json';frozen=read(preparation)
    for name,expected in frozen['execution_bytes'].items():
        assert sha256((ROOT/name).read_bytes()).hexdigest()==expected,('PREPARATION_CHANGED',name)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==frozen['state_sha256']
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('CUBIC_PRIMITIVE_WRITE_DENIED')
    sys.addaudithook(hook)
    fingerprint={'schema':'E5_CUBIC_PRIMITIVE_START_V1','route':sys.argv[1],
        'preparation':preparation.relative_to(ROOT).as_posix(),'preparation_sha256':sha256(preparation.read_bytes()).hexdigest(),
        'implementation_and_contract_sha256':frozen['execution_bytes'],'state_sha256':frozen['state_sha256'],
        'input_manifest_sha256':frozen['input_manifest_sha256'],'python':sys.version,
        'executable':sys.executable,'sympy':s.__version__,'guard_active':True}
    print('EXECUTION '+json.dumps(fingerprint,sort_keys=True,separators=(',',':')),flush=True)
    stages=[];started=time.perf_counter()
    def stage(name,fn):
        print('STAGE '+name,flush=True);tick=time.perf_counter();value=fn()
        stages.append({'name':name,'seconds':time.perf_counter()-tick});return value
    result=build(sys.argv[1],stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'stages':stages,'seconds':time.perf_counter()-started,
        'execution_state':'COMPLETED','write_attempts':writes},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
