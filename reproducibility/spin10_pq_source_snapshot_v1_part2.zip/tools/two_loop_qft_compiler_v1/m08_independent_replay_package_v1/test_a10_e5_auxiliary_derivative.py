"""Meaningful jet/canonical/current/complete-companion controls."""
import unittest
from audit_a10_e5_auxiliary_derivative import *


class AuxiliaryDerivativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_unit_bracket_derived_even_field_odd_source_signs(self):self.assertTrue(self.u['unit']['bracket_derived_columns']['l']);self.assertTrue(self.u['unit']['bracket_derived_columns']['Jb'])
    def test_boundary_is_retained_not_set_to_pointwise_zero(self):self.assertTrue(self.u['unit']['omitted_current_residual']);self.assertTrue(self.a['omitted_boundary_current_residual'])
    def test_full_GF_connection_completion(self):self.assertEqual(self.a['raw_generator_terms'],848);self.assertEqual(self.a['physical_generator_terms'],2328)
    def test_parameter_jets_and_wrong_completion_control(self):self.assertTrue(self.a['full_local_H']['all12_H_parameters_and_first_parameter_jets_retained']);self.assertTrue(self.a['full_local_H']['omit_connection_completion_residual'])
    def test_all_full_image_terms_retained(self):self.assertEqual(self.a['full_Q_image_terms'],47532)
    def test_all1286_generators_inverse(self):self.assertEqual(self.a['canonical_flow']['both_direction_inverse_checks'],2572)
    def test_all208_changed_column_jets(self):self.assertEqual(self.a['canonical_flow']['first_jet_checks'],832)
    def test_second_jet_product_control(self):self.assertTrue(self.a['canonical_flow']['second_jet_omission_residual'])
    def test_differential_pairing_adjoint(self):self.assertTrue(self.a['canonical_flow']['all_differential_field_source_kernels_proved']);self.assertTrue(self.a['canonical_flow']['formal_adjoint_currents'])
    def test_all_source_source_Hessian_blocks(self):self.assertTrue(self.a['canonical_flow']['all_source_source_smeared_Hessian']);self.assertFalse(self.a['canonical_flow']['source_source_kernel_residual'])
    def test_wrong_source_adjoint_sign(self):self.assertTrue(self.a['canonical_flow']['wrong_source_adjoint_sign_residual'])
    def test_regulated_triangular_single_flow_measure(self):self.assertEqual(self.a['canonical_flow']['integrated_field_Berezinian'],1);self.assertEqual(self.a['canonical_flow']['changed_integrated_fields'],32)
    def test_no_false_combined_finite_inverse(self):self.assertFalse(self.c['combined_old_flow_exact_finite_inverse_claimed'])
    def test_typed_OrbitPullback_is_exact(self):self.assertTrue(self.a['typed_dimension_one_OrbitPullback_image']);self.assertGreater(self.q['exact_typed_OrbitPullback_image_terms'],0)
    def test_complete_inactive_member(self):self.assertEqual(len(self.c['complete_inactive_total_generator']),1354);self.assertEqual(len(self.c['complete_inactive_total_candidate']),95155)
    def test_source_actual_all2025(self):self.assertTrue(self.c['actual_source_match_all2025']);self.assertFalse(self.c['full_source_difference'])
    def test_derivative_actual_all182250(self):self.assertTrue(self.c['actual_derivative_match_all182250']);self.assertFalse(self.c['full_derivative_difference'])
    def test_full_new_derivative_current(self):self.assertEqual(len(self.c['new_derivative_IBP_current']),436)
    def test_old_auxiliary_all91125(self):self.assertTrue(self.c['previous_auxiliary_match_all91125_preserved'])
    def test_old_nonminimal_source_all91125(self):self.assertTrue(self.c['previous_nonminimal_source_match_all91125_preserved'])
    def test_old_quartet_all980100(self):self.assertTrue(self.c['previous_quartet_match_all980100_preserved'])
    def test_old_lower_source_kinetic_width_mixing_cubic(self):self.assertTrue(self.c['all_lower_source_kinetic_mixing_width_cubic_orders_preserved'])
    def test_wrong_sign_and_coupling_degree(self):self.assertTrue(self.c['wrong_generator_sign_source_residual']);self.assertTrue(self.c['wrong_coupling_degree_old_orders_residual'])
    def test_omission_recreates_old_derivative_obstruction(self):self.assertTrue(self.c['omitted_generator_old_derivative_residual'])
    def test_all_unmeasured_companions_kept(self):self.assertTrue(self.c['new_unmeasured_companion_inventory']);self.assertEqual(len(self.c['complete_total_g3_quartet_prediction']),966);self.assertFalse(self.c['new_actual_loop_run'])
    def test_connection_choice_not_uniqueness_claim(self):self.assertFalse(self.c['source_fixed_connection_choice_unique'])
    def test_no_adoption_or_full_quantum_promotion(self):self.assertFalse(self.c['normalization_adopted']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete'])


if __name__=='__main__':unittest.main()
