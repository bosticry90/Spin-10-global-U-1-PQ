"""Complete-action selected-channel prerequisite; no physical-action repair.

Every AST monomial is varied before projection. Connection variations include
even inhomogeneous dC terms for all split carriers, conservatively overcounting
the possible compensators. Only the surviving Phi channel needs exact lowering.
"""
import itertools
import json
import sympy as s
from nonminimal_bv_m08_architecture import load, matrix
from interacting_actual_h_preflight import GaugeJets
from nonminimal_bv_free import ETA

CONNECTIONS = {'Abar_H', 'q_L', 'V_H'}
SCALARS = {'Phi', 'Sigma', 'SigmaBar', 'phi', 'phiBar', 'S', 'SBar', 'eta_328'}


def nodes(x):
    if isinstance(x, dict):
        yield x
        for v in x.values(): yield from nodes(v)
    elif isinstance(x, list):
        for v in x: yield from nodes(v)


def scalar(n):
    return n.startswith('x_') or n in SCALARS


def support(tree):
    """Leibniz-expanded field/derivative supports; ignore all coefficients.

    Ignoring coefficients and contractions enlarges support. Even exact zero
    coefficients are retained. No conclusion relies on a cancellation here.
    """
    kind = tree['node']
    if kind in ('Field', 'FrozenBackground', 'ExternalSource'):
        return {((tree['name'], ()),)}
    if kind in ('ExactScalar', 'Parameter', 'StructureConstant',
                'RepresentationGenerator', 'KroneckerMetric'): return {()}
    if kind == 'Add': return set().union(*(support(t) for t in tree['terms']))
    if kind == 'OrderedProduct':
        return {tuple(sorted(sum(parts, ()))) for parts in
                itertools.product(*(support(t) for t in tree['factors']))}
    if kind == 'PartialDerivative':
        out = set()
        for word in support(tree['argument']):
            for k, (name, jets) in enumerate(word):
                out.add(tuple(sorted(word[:k] + ((name, jets + (tree['index'],)),) + word[k+1:])))
        return out
    if kind in ('GroupContraction', 'LorentzContraction', 'LocalActionTerm'):
        return support(next(tree[k] for k in ('expression', 'argument', 'density') if k in tree))
    raise ValueError('UNDEFINED_AST_SUPPORT_' + kind)


def varied_support(words):
    out = set()
    for word in words:
        for k, (name, jets) in enumerate(word):
            rest = word[:k] + word[k+1:]
            if name in CONNECTIONS:
                # Retain dC for ALL split carriers; H4 actually acts
                # homogeneously on the heavy carrier V_H.
                out.add(tuple(sorted(rest + (('C4', jets + ('connection_mu',)),))))
            # Even fixed tensors get an overestimated homogeneous variation.
            # Scalar shifts additionally admit replacing the varied eta by v.
            for mask in itertools.product((0, 1), repeat=len(jets)):
                cj = tuple(j for j, bit in zip(jets, mask) if bit)
                fj = tuple(j for j, bit in zip(jets, mask) if not bit)
                out.add(tuple(sorted(rest + (('C4', cj), (name, fj)))))
                if scalar(name):
                    out.add(tuple(sorted(rest + (('C4', cj), ('v_328', fj)))))
    return out


def channel_possible(word, euler=False):
    # Every scalar carrier may conservatively feed Phi; v/O may contribute
    # arbitrary scalar-free coefficients. Actual frozen O is a VEV map.
    c = [jets for name, jets in word if name == 'C4']
    xs = [jets for name, jets in word if scalar(name)]
    others = [name for name, jets in word if name != 'C4' and not scalar(name)
              and name not in ('v_328', 'O_exact')]
    if len(c) != 1 or len(xs) != 2 or others: return False
    if euler:
        # Ghost IBP preserves total derivative degree, so this also catches
        # C'' x x, which must never be missed by the projected Euler test.
        return len(c[0]) + sum(map(len, xs)) == 2
    return len(c[0]) == 1 and sorted(map(len, xs)) == [0, 1]


def action_inventory(action):
    rows = []
    for index, term in enumerate(action['local_terms']):
        ns = list(nodes(term['term'])); original = support(term['term'])
        varied = varied_support(original)
        fields = sorted({n['name'] for n in ns if n.get('node') in ('Field', 'FrozenBackground')})
        selected = any(channel_possible(w) for w in varied)
        euler = any(channel_possible(w, True) for w in varied)
        rows.append({'index': index, 'sector': term['sector'],
                     'coefficient_direction': term.get('coefficient_direction'),
                     'physical_action': term['sector'] not in
                     ('LIGHT_GAUGE_FIXING_AND_GHOST', 'HEAVY_EQUIVARIANT_GAUGE_FIXING_AND_GHOST'),
                     'fields': fields, 'connection_fields': sorted(set(fields) & CONNECTIONS),
                     'ordinary_derivative_nodes': sum(n.get('node') == 'PartialDerivative' for n in ns),
                     'original_supports': len(original), 'varied_supports_before_projection': len(varied),
                     'selected_channel_possible': selected, 'selected_Euler_channel_possible': euler})
        if not term['sector'].startswith('SCALAR_KINETIC_'):
            assert not selected and not euler, ('POSSIBLE_COMPENSATOR_REQUIRES_LOWERING', index)
    assert len(rows) == action['local_term_count'] == 36
    return rows


def build(stage=lambda n, fn: fn()):
    payload = load('frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json')
    action = payload['action']; assert payload['source_count'] == 0
    inventory = stage('all_36_action_terms_varied_before_projection', lambda: action_inventory(action))
    phi = next(t['term'] for t in action['local_terms'] if t['sector'] == 'SCALAR_KINETIC_Phi')
    assert phi['node'] == 'Add'
    components = []
    for term in phi['terms']:
        k, d1, d2 = term['factors']
        assert k == {'node': 'ExactScalar', 'parity': 0, 'value': '1/2'} and d1 == d2
        assert d1['node'] == 'PartialDerivative' and d1['index'] == 'mu' and d1['argument']['node'] == 'Field'
        components.append(d1['argument']['name'])
    embedding = load('frozen_action_ast_a3/A31_embeddings.json')['sectors']['Phi']
    names = ['x_' + n.replace('.', '_') for n in embedding['coordinate_names']]
    assert set(components) == set(names) and len(components) == len(names) == 54
    whole = matrix(load('frozen_scalar_adapter_v2/SA10_physical_actions.json')['physical_H_parent'][4])/s.sqrt(2)
    assert whole[:54, 54:] == s.zeros(54, 274) and whole[54:, :54] == s.zeros(274, 54)
    rho = whole[:54, :54]
    assert (rho.T + rho).applyfunc(s.simplify) == s.zeros(54)
    j = GaugeJets(0); a = j.a
    j.fields = {n: (1, 0, 0) for n in names}
    j.grades = {**j.fields, 'C4': (1, 1, 1)}; j.external = {}; j.pairs = []
    x = {n: j.var(n) for n in j.grades}
    kinetic = a.add(*(a.scale(a.mul(j.D(x[n], mu), j.D(x[n], mu)), s.Rational(ETA[mu], 2))
                      for n in components for mu in range(4)))
    forward = {names[i]: a.add(*(a.scale(a.mul(x['C4'], x[names[k]]), -s.Symbol('g10')*v)
                for (row, k), v in rho.todok().items() if row == i)) for i in range(54)}
    residual = stage('complete_action_Phi_derivative_channel', lambda: j.Q(kinetic, forward))
    euler = stage('complete_action_ghost_Euler_two_derivative_channel', lambda: j.euler(residual, 'C4'))
    records = j.record(residual)
    target = sorted(['C4__0', 'x_Phi_offdiag_0_4', 'x_Phi_offdiag_0_1__0'])
    selected = next(r['coefficient'] for r in records if r['word'] == target)
    assert residual and euler
    return {'schema': 'PHASE_C_COMPLETE_ACTION_SCALAR_GATE_V2',
            'status': 'FAILED_COMPLETE_PHYSICAL_ACTION_SELECTED_CHANNEL',
            'canonical_action_sha256': action['canonical_action_sha256'],
            'generator': 4, 'scalar_sector': 'Phi', 'coordinates': 54,
            'scalar_orientation': -1, 'spacetime_metric': list(ETA),
            'literal_kinetic_fields': components, 'kinetic_ordinary_derivatives_only': True,
            'selected_word': target, 'selected_coefficient': selected,
            'variation': records, 'ghost_Euler_residual': j.record(euler), 'Euler_nonzero': True,
            'action_sector_inventory': inventory, 'source_count': 0,
            'scope': 'Complete 36-term A10 inventory; exact complete Phi two-derivative variation channel. Other potential/gauge-fixing variation channels are not calculated or asserted zero.',
            'projection_order': 'Vary connection/matter carriers and prolong derivatives before selecting Phi-only channel; ignore coefficients/contractions only for conservative absence proof.',
            'physical_action_terms': 34, 'gauge_fixing_ghost_terms': 2,
            'other_scalar_sector_mixing': False, 'covariant_completion_adopted': False,
            'full_M08_reconstructed': False, 'HB1_C5_authorized': False,
            'active_scientific_state_changed': False, 'formal_authority': '34/39_UNCHANGED'}


if __name__ == '__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    print('RESULT ' + json.dumps(build(), sort_keys=True, separators=(',', ':')))
