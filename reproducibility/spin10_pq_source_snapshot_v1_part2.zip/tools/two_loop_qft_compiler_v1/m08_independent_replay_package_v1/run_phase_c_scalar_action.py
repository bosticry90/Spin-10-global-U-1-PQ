"""Read-only instrumented stdout route runner, never freezes its own result."""
import importlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'tools/readiness'))
from profile_pole_blind_workflow import process_counters


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    route = sys.argv[1]
    assert route in ('phase_c_complete_scalar_action', 'phase_c_complete_scalar_action_replay')
    reads = set(); writes = []
    def hook(event, args):
        if event != 'open' or not isinstance(args[0], (str, bytes)): return
        path = Path(os.fsdecode(args[0])); mode = args[1] or ''; flags = args[2] if len(args) > 2 else 0
        if any(c in mode for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
            writes.append(str(path)); raise PermissionError('PHASE_C_ROUTE_WRITES_FORBIDDEN')
        reads.add(str(path.resolve()))
    sys.addaudithook(hook)
    start = time.perf_counter(); first = process_counters(); stages = []
    def stage(name, fn):
        print('STAGE '+name, flush=True); t = time.perf_counter(); c = process_counters()
        try: return fn()
        finally:
            after = process_counters()
            stages.append({'name': name, 'wall_seconds': time.perf_counter()-t,
                           'cpu_seconds': after['cpu_seconds']-c['cpu_seconds'],
                           'peak_process_working_set_bytes': after['peak_working_set_bytes']})
    module = stage('module_import', lambda: importlib.import_module(route))
    result = module.build(stage)
    raw = stage('serialization', lambda: json.dumps(result, sort_keys=True, separators=(',', ':')))
    print('RESULT '+raw, flush=True)
    after = process_counters()
    print('METRICS '+json.dumps({'route': route, 'stages': stages,
          'wall_seconds': time.perf_counter()-start, 'cpu_seconds': after['cpu_seconds']-first['cpu_seconds'],
          'peak_process_working_set_bytes': after['peak_working_set_bytes'],
          'unique_read_files': len(reads), 'read_paths': sorted(reads),
          'write_open_attempts': writes, 'workspace_files_written': 0,
          'os_io_read_transfer_bytes': after['os_io_read_transfer_bytes']-first['os_io_read_transfer_bytes'],
          'os_io_write_transfer_bytes': after['os_io_write_transfer_bytes']-first['os_io_write_transfer_bytes'],
          'limits': 'OS I/O includes runtime and pipes; peak is cumulative; read paths are accesses, not byte counts; no external independence.'},
          sort_keys=True, separators=(',', ':')), flush=True)


if __name__ == '__main__': main()
