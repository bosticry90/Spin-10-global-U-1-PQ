"""Tree-AST internal-index networks, with ordered occurrences kept explicit.

Derivatives and Lorentz contractions are carried as frozen annotations, not
expanded into jets. This compiler never reads a loop/projection artifact.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product, combinations
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from int8_block_conjugation_v2 import BlockConjugation, dual_label
from int9_scalar_swap import clean, dimension, payload
from int11_ordered_ast_lowering import entry_bounded_cache

ROLES = {'V_H':('H',False), 'u_H':('H',False), 'ubar_H':('H',True),
         'Lambda_H':('H',True), 'K_V':('H',True), 'L_u':('H',True),
         'K_Lambda':('H',False), 'q_L':('A',False), 'c_L':('A',False),
         'Abar_H':('A',False), 'cbar_L':('A',True), 'lambda_L':('A',True),
         'K_q':('A',True), 'L_c':('A',True), 'eta_328':('S',False),
         'v_328':('S',False), 'K_phi':('S',True)}

# Cache aliases for equal numerical physical-column maps only. AST field
# names, tagged occurrences, parity and derivative envelopes stay unchanged.
ROLE_COLUMN_NAME={('H',False):'V_H',('H',True):'ubar_H',
    ('A',False):'q_L',('A',True):'cbar_L',('S',False):'eta_328',('S',True):'K_phi'}


def expanded_terms(expression, derivatives=()):
    node = expression['node']
    if node in ('LocalActionTerm',):
        yield from expanded_terms(expression['density'], derivatives)
    elif node in ('GroupContraction', 'LorentzContraction'):
        yield from expanded_terms(expression['expression'], derivatives)
    elif node == 'Add':
        for term in expression['terms']:
            yield from expanded_terms(term, derivatives)
    elif node == 'OrderedProduct':
        choices = [list(expanded_terms(f, derivatives)) for f in expression['factors']]
        for selection in product(*choices):
            yield [f for selected in selection for f in selected]
    elif node == 'PartialDerivative':
        # Tree-level derivative occurrence labels only. No derivative alphabet,
        # Lorentz jets, permutation quotient or IBP is constructed here.
        scope={'index':expression['index'],'complete_argument_AST_hash':br.canonical(expression['argument']),
               'scope_AST_hash':br.canonical(expression),'meaning':'WHOLE_ARGUMENT_ENVELOPE_NOT_LEIBNIZ_EXPANSION'}
        yield from expanded_terms(expression['argument'], derivatives+(scope,))
    else:
        yield [dict(expression, derivative_occurrences=list(derivatives))]


def role_inventory():
    path = br.HERE/'frozen_source_seed_s3_s5/Sigma_M08_V1.json'
    source = br.load(path)
    sectors = ('EXTERNAL_SOURCE_COUPLING', 'LIGHT_GAUGE_FIXING_AND_GHOST_OFFSHELL',
               'HEAVY_EQUIVARIANT_GAUGE_FIXING_AND_GHOST_OFFSHELL')
    rows = []
    for entry in source['Sigma_M08']['local_terms']:
        if entry['sector'] not in sectors:
            continue
        term = entry['term']
        for i, factors in enumerate(expanded_terms(term)):
            rows.append({'structure_id':term['term_id']+'::'+str(i),
                         'sector':entry['sector'], 'ordered_factors':factors,
                         'source_AST_hash':br.canonical(term),
                         'source_authority_hash':source['artifact_sha256']})
    return rows


def expand_backgrounds(row):
    """Keep the Goldstone background as a scalar spurion occurrence.

    O(A,i)=rho_m(i,A,B)*v(B); R(alpha)=-f(alpha,j,k)u(j)u(k)/2.
    No frozen scalar VEV is discarded from PQ bookkeeping.
    """
    result=[]; spurions=[]
    for k,f in enumerate(row['ordered_factors']):
        suffix='_int12_'+str(k)
        if f['node']=='FrozenBackground' and f['name']=='O_exact':
            a,i=f['indices']; b='_sO'+suffix
            result.append({'node':'RepresentationGenerator','name':'rho_m','indices':[i,a,b]})
            # O was an immutable tensor, not a live field occurrence. Retain
            # the original live occurrence order and append the newly exposed
            # scalar spurion. This is a typed AST representation, not a general
            # slot-permutation representation or an identical-field projection.
            spurions.append({'node':'FrozenBackground','name':'v_328','indices':[b],'parity':0})
        elif f['node']=='Field' and f['name']=='R_H':
            a=f['indices'][0]; j,k='_mRj'+suffix,'_mRk'+suffix
            result.extend([{'node':'ExactScalar','value':'-1/2'},
                           {'node':'StructureConstant','name':'f','indices':[a,j,k]},
                           {'node':'Field','name':'u_H','indices':[j],'parity':1},
                           {'node':'Field','name':'u_H','indices':[k],'parity':1}])
        else: result.append(f)
    return dict(row,ordered_factors=result+spurions,
                background_rule='Exact O=rho(v), R=-f(u,u)/2; preserve live occurrence order, append exposed O spurions in tensor occurrence order')


class Tensor:
    """Sparse finite index network. Never a dense global cubic/quartic."""
    def __init__(self, axes, entries):
        unique=tuple(dict.fromkeys(axes)); positions=[axes.index(a) for a in unique]
        out=defaultdict(lambda:0)
        for key,value in entries.items():
            if all(key[i]==key[axes.index(a)] for i,a in enumerate(axes)):
                out[tuple(key[i] for i in positions)]+=value
        self.axes=unique; self.entries={k:sp.expand(v) for k,v in out.items() if sp.expand(v)!=0}

    def join(self, other, eliminate=()):
        shared=tuple(a for a in self.axes if a in other.axes)
        union=self.axes+tuple(a for a in other.axes if a not in self.axes)
        si=[self.axes.index(a) for a in shared]; oi=[other.axes.index(a) for a in shared]
        keep=tuple(a for a in union if a not in eliminate)
        buckets=defaultdict(list)
        for key,v in other.entries.items(): buckets[tuple(key[i] for i in oi)].append((key,v))
        result=defaultdict(lambda:0)
        for key,v in self.entries.items():
            for kk,w in buckets.get(tuple(key[i] for i in si),()):
                assigned=dict(zip(self.axes,key)); assigned.update(zip(other.axes,kk))
                result[tuple(assigned[a] for a in keep)]+=v*w
        return Tensor(keep,result)


def contract_network(nodes, outputs):
    nodes=list(nodes)
    while any(a not in outputs for node in nodes for a in node.axes):
        axes={a for node in nodes for a in node.axes if a not in outputs}
        def cost(axis):
            involved=[n for n in nodes if axis in n.axes]
            cardinal=max((len({k[n.axes.index(axis)] for k in n.entries}) for n in involved),default=1)
            return sp.prod(max(1,len(n.entries)) for n in involved)/max(1,cardinal)
        axis=min(axes,key=lambda a:(cost(a),a))
        involved=[n for n in nodes if axis in n.axes]
        nodes=[n for n in nodes if axis not in n.axes]
        joined=involved[0]
        for i,n in enumerate(involved[1:]):
            joined=joined.join(n,(axis,) if i==len(involved)-2 else ())
        if len(involved)==1:
            joined=Tensor(tuple(a for a in joined.axes if a!=axis),
                          _sum_axis(joined,axis))
        nodes.append(joined)
    result=nodes[0]
    for node in nodes[1:]: result=result.join(node)
    return result


def _sum_axis(node,axis):
    pos=node.axes.index(axis); result=defaultdict(lambda:0)
    for k,v in node.entries.items(): result[k[:pos]+k[pos+1:]]+=v
    return result


class PhysicalIndexGeometry:
    """Canonical physical SO(10) primitives, independently of channels."""
    def __init__(self):
        from execute_c3_invariant_basis import generators
        import execute_a3_scalar_geometry as geometry
        self.raw=generators(); self.gauge=[sp.SparseMatrix(g/sp.sqrt(2)) for _,g in self.raw]
        e=geometry.build_embeddings(); self.rho=[]
        indices=geometry.INDEX5; where={idx:i for i,idx in enumerate(indices)}
        for g in self.gauge:
            wedge={}
            for col,idx in enumerate(indices):
                for slot,old in enumerate(idx):
                    for new in range(10):
                        v=g[new,old]
                        if v==0 or new in idx: continue
                        moved=idx[:slot]+(new,)+idx[slot+1:]
                        key=where[tuple(sorted(moved))],col
                        wedge[key]=wedge.get(key,0)+br.parity(moved)*v
            w=sp.SparseMatrix(252,252,wedge)
            ep,es,ev=e['matrices']['Phi'],e['matrices']['Sigma'],e['matrices']['phi']
            p=clean(ep.T*(sp.kronecker_product(g,sp.eye(10))+sp.kronecker_product(sp.eye(10),g))*ep)
            s=clean(es.T*sp.diag(w,w)*es)
            v=clean(ev.T*(2*sp.diag(g,g))*ev)
            matrix=sp.SparseMatrix(sp.diag(p,s,v,sp.zeros(2)))
            assert matrix.T==-matrix
            self.rho.append(matrix)
        # Direct Lie bracket, with the canonical action-normalized basis.
        self.f={}
        for j,k in combinations(range(45),2):
            bracket=self.gauge[j]*self.gauge[k]-self.gauge[k]*self.gauge[j]
            for i,g in enumerate(self.gauge):
                value=sp.simplify(sp.trace(g.T*bracket))
                if value: self.f[i,j,k]=value; self.f[i,k,j]=-value
        rep=br.load(br.HERE/'frozen_c3/C3_representation_basis.json')
        self.projectors={}
        for family,key in [('H','heavy_basis'),('A','h_basis')]:
            q=sp.SparseMatrix(45,len(rep[key]),{(r['index'],j):sp.sympify(r['coefficient'])
                     for j,col in enumerate(rep[key]) for r in col['raw_so10_coordinates']})
            self.projectors[family]=clean(q*(q.T*q).inv()*q.T)
        assert self.projectors['H']+self.projectors['A']==sp.eye(45)
        self.qualification=[]
        # Independent constrained tensor action checks, not matrix recycling.
        from independent_m05_gauge_replay import _gauge_action
        offsets={'Phi':0,'Sigma':54,'phi':306,'S':326}
        for gi in (0,17,44):
            for sector in offsets:
                entry=e['sectors'][sector][0]; image=_gauge_action(self.gauge[gi],entry.state)
                expected=e['matrices'][sector].T*e['metrics'][sector]*geometry.flatten_state(image,sector)
                start=offsets[sector]; d=len(e['sectors'][sector])
                assert clean(expected-self.rho[gi][start:start+d,start])==sp.zeros(d,1)
                self.qualification.append({'generator':gi,'sector':sector,'residual':'ZERO_EXACT'})
        certified=br.load(br.HERE/'frozen_scalar_adapter_v2/SA10_physical_actions.json')
        for gi,row in enumerate(rep['h_basis']):
            transported=sum((sp.sqrt(2)*sp.sympify(entry['coefficient'])*self.rho[entry['index']]
                for entry in row['raw_so10_coordinates']),sp.zeros(328))
            assert clean(transported-br.matrix(certified['physical_H_parent'][gi]))==sp.zeros(328)
            self.qualification.append({'all_scalar_columns':328,'residual_H_generator':gi,
                'direct_tensor_primitive_vs_certified_V2_action':'ZERO_EXACT'})

    @lru_cache(None)
    def primitive(self,node,name,indices,domains):
        if node=='RepresentationGenerator':
            entries={(g,i,j):v for g,m in enumerate(self.rho) for (i,j),v in m.todok().items()}
        elif node=='StructureConstant': entries=self.f
        elif node=='KroneckerMetric':
            family='H' if name=='P_m_exact' else 'A' if name=='P_H_exact' else None
            m=self.projectors[family] if family else sp.eye(45)
            return Tensor(indices,m.todok())
        else: raise ValueError(('unsupported physical primitive',node,name))
        axes=tuple('_physical_axis_'+str(i) for i in range(len(indices)))
        value=Tensor(axes,entries)
        for i,domain in enumerate(domains):
            if domain not in ('H','A'): continue
            axis=axes[i]; replacement='_projected_axis_'+str(i)
            p=self.projectors[domain]
            value=value.join(Tensor((replacement,axis),p.todok()),(axis,))
            value=Tensor(tuple(axis if a==replacement else a for a in value.axes),value.entries)
        # The elimination routine may reorder axes; explicitly transport them.
        return Tensor(indices,{tuple(k[value.axes.index(a)] for a in axes):v for k,v in value.entries.items()})


class TypedPhysicalMaps:
    def __init__(self, catalog):
        self.catalog=catalog; self.p={}; self.a={}; self.dual_p={}; self.dual_a={}
        rows=br.load(br.HERE/'frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json')['components']
        for family in ('S','H','A'):
            local={r['source_component']:br.matrix(r['physical_columns'])*(sp.sqrt(2) if family!='S' else 1)
                   for r in rows if r['family']==family}
            full=sp.Matrix.hstack(*(local[r['component_id']] for r in catalog.components[family]))
            extractors={r['source_component']:br.matrix(r['physical_extractor'])/(sp.sqrt(2) if family!='S' else 1)
                        for r in rows if r['family']==family}
            extractor=sp.Matrix.vstack(*(extractors[r['component_id']] for r in catalog.components[family]))
            assert clean(extractor*full)==sp.eye(full.cols)
            offset=0
            for r in catalog.components[family]:
                cid=r['component_id']; n=local[cid].cols
                self.p[cid]=sp.SparseMatrix(local[cid]); self.a[cid]=extractor[offset:offset+n,:]
                offset+=n
            for r in catalog.components[family]:
                cid=r['component_id']; target=catalog.partner[cid]
                j=catalog.duals.pairing(tuple(catalog.by_id[target]['H_label'])).T
                copies=r['copy_multiplicity']; jj=sp.kronecker_product(sp.eye(copies),j)
                self.dual_p[cid]=clean(self.a[target].T*jj)
                self.dual_a[cid]=clean(jj.inv()*self.p[target].T)
                assert clean(self.dual_a[cid]*self.dual_p[cid])==sp.eye(self.dual_p[cid].cols)
        self.conjugation_factors={}; self.conjugation_certificates=[]
        for dual,pp,aa in ((False,self.p,self.a),(True,self.dual_p,self.dual_a)):
            for family in ('S','H','A'):
                ids=[r['component_id'] for r in catalog.components[family]]
                fullp=sp.Matrix.hstack(*(pp[cid] for cid in ids))
                fulla=sp.Matrix.vstack(*(aa[cid] for cid in ids))
                global_k=clean(sp.conjugate(fulla)*fullp)
                assert clean(global_k*sp.conjugate(global_k))==sp.eye(global_k.rows)
                offsets={}; offset=0
                for cid in ids: offsets[cid]=offset; offset+=pp[cid].cols
                permitted=sp.zeros(global_k.rows)
                for cid in ids:
                    target=catalog.partner[cid]; row=catalog.by_id[cid]; d=dimension(row)
                    n=row['copy_multiplicity']; k=clean(sp.conjugate(aa[cid])*pp[target])
                    carrier=catalog.k(tuple(row['H_label'])); w=sp.zeros(n)
                    for i in range(n):
                        for j in range(n):
                            block=clean(k[i*d:(i+1)*d,j*d:(j+1)*d]*carrier.inv())
                            assert block==block[0,0]*sp.eye(d)
                            w[i,j]=block[0,0]
                    assert clean(k-sp.kronecker_product(w,carrier))==sp.zeros(*k.shape)
                    permitted[offsets[cid]:offsets[cid]+n*d,offsets[target]:offsets[target]+n*d]=k
                    self.conjugation_factors[dual,cid]=w
                    self.conjugation_certificates.append({'dual':dual,'source_component':cid,
                        'target_component':target,'copy_matrix':payload(w),
                        'physical_conjugation_and_carrier_transport_residual':'ZERO_EXACT'})
                assert clean(global_k-permitted)==sp.zeros(*global_k.shape)

    @lru_cache(2048)
    def physical_columns(self, name, cid, copy):
        family,dual=ROLES[name]; r=self.catalog.by_id[cid]
        assert r['family']==family
        d=dimension(r); p=(self.dual_p if dual else self.p)[cid]
        return p[:,copy*d:(copy+1)*d]


class TreeIndexLowering:
    def __init__(self):
        self.cat=BlockConjugation.from_frozen(); self.maps=TypedPhysicalMaps(self.cat)
        self.geometry=PhysicalIndexGeometry()

    def prepared(self,row,require_channel_family=True):
        row=expand_backgrounds(row)
        original=[f for f in row['ordered_factors'] if f['node'] in ('Field','ExternalSource','FrozenBackground')]
        assert all(f['name'] in ROLES for f in original),row['structure_id']
        families=tuple(ROLES[f['name']][0] for f in original)
        desc=next((d for d in self.cat.descriptors.values() if tuple(d['ordered_character_families'])==families),None)
        # The literal AST word stays ordered and immutable. A descriptor's
        # coordinate-axis order need not be the AST's field-word order. Bind
        # each descriptor axis to one tagged AST occurrence; this constructs
        # no permutation-group representation and commutes no odd fields.
        if desc is None:
            candidates=[d for d in self.cat.descriptors.values()
                        if sorted(d['ordered_character_families'])==sorted(families)]
            desc=min(candidates,key=lambda d:d['family_id']) if candidates else None
        if desc is None and require_channel_family:
            raise ValueError(('INT12_MISSING_ORDERED_FAMILY',row['structure_id'],families))
        remaining=list(range(len(original)));axis_map=[]
        for family in (desc['ordered_character_families'] if desc else families):
            index=next(i for i in remaining if ROLES[original[i]['name']][0]==family)
            axis_map.append(index);remaining.remove(index)
        assert not remaining and sorted(axis_map)==list(range(len(original)))
        fields=[original[i] for i in axis_map]
        row=dict(row,AST_ordered_occurrences=original,channel_axis_to_AST_occurrence=axis_map)
        domains={f['indices'][0]:ROLES[f['name']][0] for f in original}
        prefactor=sp.Integer(1); parameters=[]; nodes=[]
        for f in row['ordered_factors']:
            kind=f['node']
            if kind=='ExactScalar': prefactor*=sp.sympify(f['value'])
            elif kind=='Parameter': parameters.append(f['name'])
            elif kind=='FrozenScalarCovector':
                # An explicitly frozen internal invariant probe, not a new
                # action parameter or a change to the scalar role adapter.
                assert len(f['indices'])==1 and f['coordinate_dimension']==328
                nodes.append(Tensor(tuple(f['indices']),
                    {(int(i),):sp.sympify(v) for i,v in f['entries']}))
            elif kind in ('StructureConstant','RepresentationGenerator','KroneckerMetric'):
                indices=tuple(f['indices'])
                for label in indices:
                    if label not in domains:
                        domains[label]='A' if label.startswith('_h') or label in ('alpha','beta','gamma') else 'H' if label.startswith('_m') or label in ('i','j','k') else 'S'
                dd=tuple(domains[x] for x in indices)
                nodes.append(self.geometry.primitive(kind,f['name'],indices,dd))
        # Contract a frozen one-index covector with its unique constant
        # primitive at a private index before lifting field columns. This is
        # an exact finite contraction reassociation, not a support heuristic
        # or a global high-rank physical tensor materialization.
        live_indices={f['indices'][0] for f in original}
        for factor in (row['ordered_factors'] if getattr(self,'use_frozen_covector_precontraction',True) else []):
            if factor['node']!='FrozenScalarCovector':continue
            index=factor['indices'][0]
            if index in live_indices:continue
            containing=[i for i,n in enumerate(nodes) if index in n.axes]
            if len(containing)!=2:continue
            first,second=containing
            combined=nodes[first].join(nodes[second],(index,))
            nodes=[n for i,n in enumerate(nodes) if i not in containing]+[combined]
        return row,fields,desc,sp.factor(prefactor),parameters,nodes

    def map_qualification(self):
        from execute_scalar_adapter_v2 import physical_generators, registry_generators
        actions=br.load(br.HERE/'frozen_scalar_adapter_v2/SA10_physical_actions.json')
        scalar_actions=[br.matrix(v) for v in actions['physical_H_parent']]
        scalar_pq=br.matrix(actions['physical_PQ_parent'])
        physical=physical_generators(); raw=[m for _,m in self.geometry.raw]
        adjoint=[]
        for g in physical:
            adjoint.append(clean(sp.SparseMatrix(45,45,{(i,j):sp.trace(b.T*(g*c-c*g))/2
                for i,b in enumerate(raw) for j,c in enumerate(raw)
                if sp.trace(b.T*(g*c-c*g))!=0})))
        results=[]
        for dual,pp,aa in ((False,self.maps.p,self.maps.a),(True,self.maps.dual_p,self.maps.dual_a)):
            for cid,row in self.cat.by_id.items():
                family=row['family']; target=self.cat.partner[cid]
                generators=registry_generators(tuple(row['H_label']),self.cat.duals)
                if dual:
                    partner_generators=registry_generators(tuple(self.cat.by_id[target]['H_label']),self.cat.duals)
                    j=self.cat.duals.pairing(tuple(self.cat.by_id[target]['H_label'])).T
                    generators=[clean(-j.inv()*g.T*j) for g in partner_generators]
                for gi,g in enumerate(generators):
                    greg=sp.kronecker_product(sp.eye(row['copy_multiplicity']),g)
                    gphys=scalar_actions[gi] if family=='S' else adjoint[gi]
                    if dual:gphys=-gphys.T
                    assert clean(gphys*pp[cid]-pp[cid]*greg)==sp.zeros(*pp[cid].shape),(cid,dual,gi)
                    assert clean(greg*aa[cid]-aa[cid]*gphys)==sp.zeros(*aa[cid].shape),(cid,dual,gi,'extraction')
                qphysical=scalar_pq if family=='S' else sp.zeros(45)
                if dual:qphysical=-qphysical.T
                qregistry=sp.I*row['PQ_charge']*sp.eye(pp[cid].cols)
                assert clean(qphysical*pp[cid]-pp[cid]*qregistry)==sp.zeros(*pp[cid].shape),(cid,dual,'PQ')
                results.append({'component':cid,'orientation':'REG7_SOURCE_DUAL' if dual else 'PRIMAL',
                    'all_12_H_generators':'ZERO_EXACT','PQ_covariance':'ZERO_EXACT',
                    'round_trip':'ZERO_EXACT','conjugation':'ZERO_EXACT'})
        return results

    @entry_bounded_cache(500000)
    def embedded_pair(self, roles, slots, embedding):
        ps=[]
        for (family,dual),(cid,copy) in zip(roles,slots):
            row=self.cat.by_id[cid];assert row['family']==family
            d=dimension(row);p=(self.maps.dual_p if dual else self.maps.p)[cid]
            ps.append(p[:,copy*d:(copy+1)*d])
        pair=sp.SparseMatrix(sp.kronecker_product(*ps)*embedding)
        return {(i//ps[1].rows,i%ps[1].rows,j):v for (i,j),v in pair.todok().items()}

    def pair_node(self, fields, slots, embedding, axis):
        entries=self.embedded_pair(tuple(ROLES[f['name']] for f in fields),
                                   tuple(slots),sp.ImmutableSparseMatrix(embedding))
        return Tensor((fields[0]['indices'][0],fields[1]['indices'][0],axis),entries)

    def restricted(self, fields, nodes, address):
        if getattr(self,'use_local_carrier_kernel',True):
            return self.local_restricted(fields,nodes,address)
        return self.physical_pair_restricted(fields,nodes,address)

    @entry_bounded_cache(500000)
    def local_tensor(self, fields, slots, nodes):
        axes=tuple('_local_slot_'+str(i) for i in range(len(fields)))
        unaries=[]
        for i,((name,index),(cid,copy)) in enumerate(zip(fields,slots)):
            p=self.maps.physical_columns(name,cid,copy)
            unaries.append(Tensor((index,axes[i]),p.todok()))
        result=contract_network(unaries+list(nodes),axes)
        return {tuple(k[result.axes.index(axis)] for axis in axes):v for k,v in result.entries.items()}

    def local_restricted(self, fields, nodes, address):
        _,_,cids,copies,left,right,ch,dh=self.cat.address_parts(address)
        slots=tuple(zip(cids,copies));arity=len(fields)
        axes=tuple('_local_slot_'+str(i) for i in range(arity))
        local=Tensor(axes,self.local_tensor(tuple((ROLE_COLUMN_NAME[ROLES[f['name']]],f['indices'][0])
                                                 for f in fields),slots,tuple(nodes)))
        pairing=sp.ones(1) if arity==2 else self.cat.duals.pairing(tuple(left['output_H_label'])).T
        if not local.entries:
            # Complete physical local restriction is exactly zero; contracting
            # it with unchanged embeddings is the exact zero terminal matrix.
            return sp.SparseMatrix(*pairing.shape,{}),pairing
        lc,_=self.cat.duals.channel_objects(tuple(left['left_H_label']),tuple(left['right_H_label']),tuple(left['output_H_label']),ch)
        d1=dimension(self.cat.by_id[cids[1]])
        lnode=Tensor((axes[0],axes[1],'_terminal_L'),
            {(i//d1,i%d1,j):v for (i,j),v in lc.todok().items()})
        if arity==2:
            target=contract_network([local,lnode],('_terminal_L',))
            return sp.SparseMatrix([[target.entries.get((0,),0)]]),sp.ones(1)
        if arity==3:
            rnode=Tensor((axes[2],'_terminal_R'),{(i,i):1 for i in range(dimension(self.cat.by_id[cids[2]]))})
        else:
            rc,_=self.cat.duals.channel_objects(tuple(right['left_H_label']),tuple(right['right_H_label']),tuple(right['output_H_label']),dh)
            d3=dimension(self.cat.by_id[cids[3]])
            rnode=Tensor((axes[2],axes[3],'_terminal_R'),
                {(i//d3,i%d3,j):v for (i,j),v in rc.todok().items()})
        result=contract_network([local,lnode,rnode],('_terminal_L','_terminal_R'))
        entries={(k[result.axes.index('_terminal_L')],k[result.axes.index('_terminal_R')]):v for k,v in result.entries.items()}
        return clean(sp.SparseMatrix(*pairing.shape,entries)),pairing

    def physical_pair_restricted(self, fields, nodes, address):
        arity=len(fields); desc=self.cat.descriptors[address['family_id']]
        _,_,cids,copies,left,right,ch,dh=self.cat.address_parts(address)
        slots=list(zip(cids,copies))
        lc,ld=self.cat.duals.channel_objects(tuple(left['left_H_label']),tuple(left['right_H_label']),tuple(left['output_H_label']),ch)
        pair=self.pair_node(fields[:2],slots[:2],lc,'_terminal_L')
        if arity==2:
            contracted=contract_network([pair]+nodes,('_terminal_L',))
            matrix=sp.SparseMatrix(1,1,{(0,0):contracted.entries.get((0,),0)})
            return matrix,sp.ones(1)
        if arity==3:
            p=self.maps.physical_columns(fields[2]['name'],*slots[2])
            other=Tensor((fields[2]['indices'][0],'_terminal_R'),p.todok())
        else:
            rc,rd=self.cat.duals.channel_objects(tuple(right['left_H_label']),tuple(right['right_H_label']),tuple(right['output_H_label']),dh)
            other=self.pair_node(fields[2:],slots[2:],rc,'_terminal_R')
        contracted=contract_network([pair,other]+nodes,('_terminal_L','_terminal_R'))
        pairing=self.cat.duals.pairing(tuple(left['output_H_label'])).T
        entries={(k[contracted.axes.index('_terminal_L')],k[contracted.axes.index('_terminal_R')]):v
                 for k,v in contracted.entries.items()}
        return clean(sp.SparseMatrix(*pairing.shape,entries)),pairing

    def lower(self,row):
        expanded,fields,desc,prefactor,parameters,nodes=self.prepared(row)
        coefficients=[]; checks=[]
        for key,_,_,_ in self.cat.blocks(desc):
            for address in self.cat.addresses(desc['family_id'],key):
                target,pairing=self.restricted(fields,nodes,address)
                i,j=sorted(pairing.todok())[0]
                coefficient=sp.simplify(prefactor*target[i,j]/pairing[i,j])
                residual=clean(prefactor*target-coefficient*pairing)
                if residual!=sp.zeros(*pairing.shape):
                    raise ValueError(('INT12_TERMINAL_NOT_IN_PAIRING_SPAN',row['structure_id'],address,payload(residual)))
                checks.append({'address':address,'target_sha256':br.canonical(payload(target)),
                               'terminal_shape':list(target.shape),'residual':'ZERO_EXACT'})
                if coefficient: coefficients.append({'address':address,'coefficient':str(coefficient)})
                if len(checks)%1000==0:
                    print('TREE_FULL_TERMINAL_CHECKS',row['structure_id'],len(checks),flush=True)
        return {'structure_id':row['structure_id'],'source_authority_hash':row['source_authority_hash'],
                'source_AST_hash':row['source_AST_hash'],
                'expanded_ordered_occurrences':expanded['AST_ordered_occurrences'],
                'channel_ordered_occurrences':fields,
                'channel_axis_to_AST_occurrence':expanded['channel_axis_to_AST_occurrence'],
                'axis_binding':'Tagged coordinate-axis map only; original AST word unchanged, no Grassmann reorder or permutation matrix',
                'derivative_scope':'Frozen tree-AST annotations only; no Lorentz jet or IBP construction',
                'parameters':parameters,'ordered_family':desc['family_id'],'coefficients':coefficients,
                'terminal_checks':checks,'status':'FROZEN_BEFORE_RECONSTRUCTION',
                'source_primal_dictionary':'Explicit REG7 contragredient columns, not Euclidean identification'}

    def direct_physical_value(self,row,vectors):
        # A tree-only pointwise contraction can also verify an exact Ward
        # cancellation before channel lowering. This does not materialize a
        # higher-degree family or construct a cochain census.
        expanded,_,_,prefactor,_,nodes=self.prepared(row,require_channel_family=False)
        fields=expanded['AST_ordered_occurrences']
        assert len(fields)==len(vectors)
        unaries=[Tensor((f['indices'][0],),{(i,):v for (i,_),v in vector.todok().items()})
                 for f,vector in zip(fields,vectors)]
        value=contract_network(unaries+nodes,())
        return sp.simplify(prefactor*value.entries.get((),0))

    def coefficient_reconstruction(self,closed,vectors):
        fields=closed['channel_ordered_occurrences']; total=sp.Integer(0)
        vectors=[vectors[i] for i in closed['channel_axis_to_AST_occurrence']]
        for row in closed['coefficients']:
            value=self.evaluate_ordered(row['address'],[f['name'] for f in fields],vectors)
            total+=sp.sympify(row['coefficient'])*value
        return sp.simplify(total)

    @lru_cache(4096)
    def extract_slot(self,name,cid,copy,vector):
        family,dual=ROLES[name];r=self.cat.by_id[cid];d=dimension(r)
        assert r['family']==family
        a=(self.maps.dual_a if dual else self.maps.a)[cid]
        return sp.ImmutableSparseMatrix(a[copy*d:(copy+1)*d,:]*vector)

    @lru_cache(12000)
    def decompose_pair(self,a,b,out,index,left,right):
        _,d=self.cat.duals.channel_objects(a,b,out,index)
        return sp.ImmutableSparseMatrix(d*sp.kronecker_product(left,right))

    def evaluate_ordered(self,address,role_names,vectors):
        desc,_,cids,copies,left,right,ch,dh=self.cat.address_parts(address)
        assert len(role_names)==len(vectors)==desc['arity']
        if not role_names:return sp.Integer(1)
        abstract=[]
        for name,cid,copy,v in zip(role_names,cids,copies,vectors):
            abstract.append(self.extract_slot(ROLE_COLUMN_NAME[ROLES[name]],cid,copy,sp.ImmutableSparseMatrix(v)))
        if any(not v.todok() for v in abstract):return sp.Integer(0)
        if len(role_names)==1:return abstract[0][0]
        yl=self.decompose_pair(tuple(left['left_H_label']),tuple(left['right_H_label']),
            tuple(left['output_H_label']),ch,*abstract[:2])
        if len(role_names)==2:return yl[0]
        if len(role_names)==3:yr=abstract[2]
        else:
            yr=self.decompose_pair(tuple(right['left_H_label']),tuple(right['right_H_label']),
                tuple(right['output_H_label']),dh,*abstract[2:])
        return sp.expand((yl.T*self.cat.duals.pairing(tuple(left['output_H_label'])).T*yr)[0])

    def conjugation_image(self,address,fields):
        desc,key,cids,copies,left,right,ch,dh=self.cat.address_parts(address)
        label=tuple(left['output_H_label']); fid=desc['family_id']; arity=len(fields)
        target=self.cat.address_lookup[fid][(tuple(self.cat.partner[c] for c in cids),dual_label(label))]
        choices=[]
        for f,cid,copy in zip(fields,cids,copies):
            w=self.maps.conjugation_factors[ROLES[f['name']][1],cid]
            choices.append([(j,w[copy,j]) for j in range(w.cols) if w[copy,j]])
        lb=self.cat.binary_matrix(left)
        ls=[(j,lb[j,ch]) for j in range(lb.rows) if lb[j,ch]]
        rb=self.cat.binary_matrix(right) if right else sp.ones(1)
        rs=[(j,rb[j,dh]) for j in range(rb.rows) if rb[j,dh]]
        phase=self.cat.terminal_phase(label) if arity>=3 else 1
        for selection in product(*choices):
            cs=[j for j,_ in selection]; v=phase*sp.prod(v for _,v in selection)
            for (lc,vl),(rc,vr) in product(ls,rs):
                digits=[*cs,lc] if arity==2 else [cs[0],cs[1],lc,cs[2]] if arity==3 else [target[1],target[2],cs[0],cs[1],lc,cs[2],cs[3],rc]
                yield {'family_id':fid,'terminal_channel_index':target[0],'digits':digits},sp.simplify(v*vl*vr)


if __name__ == '__main__':
    # Inventory-only diagnostic. No coefficient map or scientific PASS is
    # inferred from a node's name, number of fields, or representation label.
    for row in role_inventory():
        print(row['structure_id'], [(f['node'],f.get('name',f.get('value')),
                                     f.get('indices'),f['derivative_occurrences'])
                                    for f in row['ordered_factors']])
