"""Canonical heavy-doublet coordinate prerequisite, stdout only."""
import itertools
import json
import sympy as s
from phase_c_mixed_source import geometry, IDS, H, M, g
from source_convention_control import Exterior
from nonabelian_m08_semantic import canonical


def build(stage=lambda n,fn:fn()):
    f,_=stage('actual_mixed_geometry',geometry); a=Exterior()
    fields={**{'C'+str(i):1 for i in IDS},**{'ubar'+str(i):1 for i in M},**{'Lambda'+str(i):0 for i in M}}
    pairs=[(z,'J'+z) for z in fields]
    x={n:a.variable(n,p) for n,p in (fields|{J:1-fields[z] for z,J in pairs}).items()}
    shift={i:a.add(*(a.scale(a.mul(x['C'+str(h)],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for h in H for j in M)) for i in M}
    # Express OLD b0 and OLD evaluation sources in new Lambda coordinates.
    U=dict(x)
    for i in M:
        U['Lambda'+str(i)]=a.add(x['Lambda'+str(i)],a.scale(shift[i],-1))
        U['Jubar'+str(i)]=a.add(x['Jubar'+str(i)],*(a.scale(a.mul(x['JLambda'+str(j)],x['C'+str(h)]),-g*f.get((i,h,j),0)) for h in H for j in M))
    for h in H:
        U['JC'+str(h)]=a.add(x['JC'+str(h)],*(a.scale(a.mul(x['JLambda'+str(i)],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for i,j in itertools.product(M,repeat=2)))
    # All cross brackets, not only diagonal pairs. The map is triangular;
    # reversing the same field/source shifts is its exact inverse.
    for z in fields:
        for y in fields:
            target={():s.Integer((-1)**fields[z])} if z==y else {}
            assert not a.add(a.bracket(U[z],U['J'+y],pairs),a.scale(target,-1)),(z,y)
    for (_,J),(_,K) in itertools.combinations_with_replacement(pairs,2): assert not a.bracket(U[J],U[K],pairs),(J,K)
    def replace(P,table):
        terms=[]
        for row in canonical(P,a):
            term={():s.sympify(row['coefficient'])}
            for n in row['word']: term=a.mul(term,table[n])
            terms.append(term)
        return a.add(*terms)
    inverse={n:{word:s.expand(c.subs(g,-g)) for word,c in P.items()} for n,P in U.items()}
    for n in x:
        assert not a.add(replace(U[n],inverse),a.scale(x[n],-1)),('inverse',n)
        assert not a.add(replace(inverse[n],U),a.scale(x[n],-1)),('forward',n)
    qc={'C'+str(i):a.add(*(a.scale(a.mul(x['C'+str(j)],x['C'+str(k)]),-g*f.get((i,j,k),0)) for j,k in itertools.combinations(IDS,2))) for i in IDS}
    oldS=a.add(*(a.mul(x['J'+z],P) for z,P in qc.items()),*(a.scale(a.mul(x['Jubar'+str(i)],x['Lambda'+str(i)]),-1) for i in M))
    newS=replace(oldS,U)
    for i in M:
        derived=a.bracket(newS,x['ubar'+str(i)],pairs)
        assert not a.add(derived,x['Lambda'+str(i)],a.scale(shift[i],-1))
    return {'schema':'PHASE_C_HEAVY_CANONICAL_COORDINATE_MAP_V1','status':'PASS','pairs':len(pairs),'field_source_brackets':len(pairs)**2,'source_cross_brackets':len(pairs)*(len(pairs)+1)//2,
        'old_coordinates_in_new':{n:canonical(P,a) for n,P in U.items()},'inverse':'Reverse g10 signs in the triangular shifts; C,ubar,JLambda unchanged','inverse_checks':2*len(x),'source_action_transport':canonical(newS,a),
        'field_formula':'b0=Lambda-g10 ad_H(c)^T ubar','physical_action_changed':False,'active_sources_added':False}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    print(json.dumps(build(),sort_keys=True,separators=(',',':')))
