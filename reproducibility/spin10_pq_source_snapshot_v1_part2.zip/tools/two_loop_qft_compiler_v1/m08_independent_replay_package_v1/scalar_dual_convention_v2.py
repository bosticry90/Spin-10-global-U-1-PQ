"""Typed primal embeddings and REG7-derived projections; no AST or loop data."""
from __future__ import annotations

from functools import lru_cache
import sympy as sp

from execute_scalar_ast_channel_bridge import HERE, load, matrix, serialize


class ExactDualConvention:
    def __init__(self):
        self.f3 = {(r['p'], r['q']): r for r in load(HERE / 'frozen_irrep_carrier_registry/REG3_SU3_factor_carriers.json')['factors']}
        self.f2 = {r['n']: r for r in load(HERE / 'frozen_irrep_carrier_registry/REG4_SU2_factor_carriers.json')['factors']}
        pairings = load(HERE / 'frozen_irrep_carrier_registry/REG7_dual_pairings.json')
        # J_R has dual rows and primal columns. This is not a Euclidean metric.
        # REG7's serialized ``left`` names the primal input (columns), despite
        # the name: its constructor is dual_basis.T * ambient_J * primal_basis.
        self.j3 = {tuple(r['left']): matrix(r['matrix']) for r in pairings['SU3_pairings']}
        self.j2 = {r['n']: matrix(r['matrix']) for r in pairings['SU2_pairings']}
        self.c3 = {(tuple(r['left']), tuple(r['right']), tuple(r['output'])):
                   [matrix(c['embedding']) for c in r['channels']]
                   for r in load(HERE / 'frozen_intertwiner_channel_basis/INT3_SU3_binary_intertwiners.json')['families']}
        self.c2 = {(r['left_n'], r['right_n'], r['output_n']): [matrix(r['embedding'])]
                   for r in load(HERE / 'frozen_intertwiner_channel_basis/INT3_SU2_binary_intertwiners.json')['channels']}
        self.d3, self.d2, self.certificates = {}, {}, []

    def derive(self):
        for group, carriers, pairings, embeddings, projections in (
                ('SU3', self.f3, self.j3, self.c3, self.d3),
                ('SU2', self.f2, self.j2, self.c2, self.d2)):
            dual = (lambda r: (r[1], r[0])) if group == 'SU3' else (lambda r: r)
            generators = {r: {name: matrix(value) for name, value in row['generators'].items()}
                          for r, row in carriers.items()}
            for r, j in pairings.items():
                for name, g in generators[r].items():
                    assert generators[dual(r)][name].T * j + j * g == sp.zeros(*j.shape), (group, r, name, 'pairing')
            for key, cs in sorted(embeddings.items()):
                a, b, out = key
                partner = tuple(dual(r) for r in key)
                if partner not in embeddings:
                    raise RuntimeError(f'DUAL2_MISSING_CONTRAGREDIENT_PARTNER {group} {key} {partner}')
                cvs = embeddings[partner]
                assert len(cs) == len(cvs)
                product_pairing = sp.kronecker_product(pairings[a], pairings[b])
                candidates = [pairings[out].inv() * cv.T * product_pairing for cv in cvs]
                gram = sp.zeros(len(cvs), len(cs))
                for bi, candidate in enumerate(candidates):
                    for ai, c in enumerate(cs):
                        m = candidate * c
                        gram[bi, ai] = m[0, 0]
                        if m != m[0, 0] * sp.eye(c.cols):
                            raise RuntimeError(f'DUAL3_NON_SCHUR_GRAM {group} {key} {bi} {ai}')
                assert gram.det() != 0, (group, key, 'singular Gram')
                inverse = gram.inv()
                ds = [sum((inverse[ai, bi] * candidate for bi, candidate in enumerate(candidates)),
                          sp.zeros(cs[ai].cols, cs[ai].rows)) for ai in range(len(cs))]
                projections[key] = ds
                for ai, d in enumerate(ds):
                    for ci, c in enumerate(cs):
                        assert d * c == (sp.eye(d.rows) if ai == ci else sp.zeros(d.rows)), (group, key, ai, ci)
                    for name, g in generators[a].items():
                        action = sp.kronecker_product(g, sp.eye(carriers[b]['dimension'])) + sp.kronecker_product(sp.eye(carriers[a]['dimension']), generators[b][name])
                        assert d * action == generators[out][name] * d, (group, key, ai, name, 'covariance')
                    for other, other_cs in embeddings.items():
                        if other[:2] == key[:2] and other[2] != out:
                            for c in other_cs:
                                assert d * c == sp.zeros(d.rows, c.cols), (group, key, other, 'off-channel')
                self.certificates.append({'group': group, 'channel_labels': key, 'dual_partner_labels': partner,
                                          'Gamma': serialize(gram), 'Gamma_inverse': serialize(inverse),
                                          'determinant': str(gram.det()), 'rank': gram.rows,
                                          'dual_index_transport': 'Gamma inverse, not index identity',
                                          'projections': [serialize(d) for d in ds],
                                          'Schur_residual': 'ZERO_EXACT', 'biorthogonality_residual': 'ZERO_EXACT',
                                          'generator_covariance_residual': 'ZERO_EXACT', 'off_channel_residual': 'ZERO_EXACT'})
                print('DUAL4', group, key, 'Gram', gram.shape, 'ZERO_EXACT', flush=True)
        return self

    @lru_cache(None)
    def pairing(self, label):
        return sp.kronecker_product(self.j3[label[:2]], self.j2[label[2]])

    @lru_cache(None)
    def channel_objects(self, left, right, output, channel):
        c3 = self.c3[(left[:2], right[:2], output[:2])][channel]
        c2 = self.c2[(left[2], right[2], output[2])][0]
        d3 = self.d3[(left[:2], right[:2], output[:2])][channel]
        d2 = self.d2[(left[2], right[2], output[2])][0]
        dl3, dr3 = self.f3[left[:2]]['dimension'], self.f3[right[:2]]['dimension']
        dl2, dr2 = self.f2[left[2]]['dimension'], self.f2[right[2]]['dimension']
        do2 = self.f2[output[2]]['dimension']
        # Product coordinates (a3,a2,b3,b2), output coordinates (o3,o2).
        c = sp.MutableSparseMatrix(dl3*dl2*dr3*dr2, c3.cols*c2.cols, {})
        d = sp.MutableSparseMatrix(c.cols, c.rows, {})
        for (r3, o3), v3 in c3.todok().items():
            a3, b3 = divmod(r3, dr3)
            for (r2, o2), v2 in c2.todok().items():
                a2, b2 = divmod(r2, dr2)
                c[(a3*dl2+a2)*dr3*dr2+b3*dr2+b2, o3*do2+o2] = v3*v2
        for (o3, r3), v3 in sp.SparseMatrix(d3).todok().items():
            a3, b3 = divmod(r3, dr3)
            for (o2, r2), v2 in sp.SparseMatrix(d2).todok().items():
                a2, b2 = divmod(r2, dr2)
                d[o3*do2+o2, (a3*dl2+a2)*dr3*dr2+b3*dr2+b2] = v3*v2
        assert d * c == sp.eye(c.cols)
        return sp.ImmutableSparseMatrix(c), sp.ImmutableSparseMatrix(d)

    def embed_channel(self, block, channel, vector):
        c, _ = self.channel_objects(tuple(block['left_H_label']), tuple(block['right_H_label']), tuple(block['output_H_label']), channel)
        return c * vector

    def decompose_to_channel(self, block, channel, vector):
        _, d = self.channel_objects(tuple(block['left_H_label']), tuple(block['right_H_label']), tuple(block['output_H_label']), channel)
        return d * vector
