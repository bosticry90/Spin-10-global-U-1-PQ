"""Versioned D4 amendments to the historical replay typed-rule module."""

from __future__ import annotations

from copy import deepcopy
from typing import Any


def apply(module: Any) -> None:
    """Apply only primitive changes independently certified by D4."""

    original_vertex_rules = module.vertex_rules
    original_terms = module._vertex_terms_for_instance

    def vertex_rules() -> dict[str, dict[str, Any]]:
        rules = deepcopy(original_vertex_rules())
        q = rules["A.HH.qL.covariant_laplacian"]
        for item in q["terms"]:
            item["group_factors"][0]["indices"] = [0, 2, 1]

        qq = rules["A.HH.qLqL.seagull"]
        qq["terms"][0]["coefficient_factors"][0] = module.rat("-1")
        qq["terms"][0]["group_factors"][0]["indices"] = [0, 2, "m"]
        qq["terms"][0]["group_factors"][1]["indices"] = ["m", 3, 1]
        qq["terms"][1]["coefficient_factors"][0] = module.rat("-1")
        qq["terms"][1]["group_factors"][0]["indices"] = [0, 3, "m"]
        qq["terms"][1]["group_factors"][1]["indices"] = ["m", 2, 1]

        mixed = rules["A.HH.VHqL.mixed"]["terms"][0]
        mixed["group_factors"][1]["indices"] = ["m", 3, 1]

        quartic = rules["A.HHHH.equivariant"]
        quartic["terms"][0]["coefficient_factors"] = [
            module.param("xi"), module.param("g10", 2)
        ]
        quartic["terms"][1]["coefficient_factors"] = [
            module.rat("-1"), module.param("xi"), module.param("g10", 2)
        ]
        return rules

    def terms_for_instance(
        family: str, signature: list[str], rules: dict[str, dict[str, Any]]
    ) -> list[dict[str, Any]]:
        terms = original_terms(family, signature, rules)
        if family == "A.GGG.yang_mills":
            for item in terms:
                item["coefficient_factors"] = [module.rat("-1")] + item[
                    "coefficient_factors"
                ]
        return terms

    def grassmann_sign(graph: dict[str, Any]) -> dict[str, Any]:
        ghost_species = {"Hbar", "H", "Lbar", "L"}
        flattened = []
        for vertex_index, vertex in enumerate(graph["vertices"]):
            external = {
                item["slot"]: item["external"]
                for item in graph["external_attachments"]
                if item["vertex"] == vertex_index
            }
            for slot, species in enumerate(vertex["signature"]):
                if species in ghost_species:
                    flattened.append((vertex_index, slot, species, external.get(slot)))
        internal_edges = [
            edge for edge in graph["internal_edges"]
            if edge["left"][2] in ghost_species or edge["right"][2] in ghost_species
        ]
        working = [(v, s, species) for v, s, species, _external in flattened]
        labels = [f"v{v}s{s}" for v, s, _species in working]
        sign = 1
        contractions = []
        for edge_index, edge in enumerate(internal_edges):
            endpoints = [tuple(edge["left"]), tuple(edge["right"])]
            ghost = next(item for item in endpoints if not item[2].endswith("bar"))
            antighost = next(item for item in endpoints if item[2].endswith("bar"))
            pos_u = working.index(ghost)
            pos_b = working.index(antighost)
            exponent = pos_b - pos_u - 1 if pos_u < pos_b else pos_u - pos_b
            pair_sign = -1 if exponent % 2 else 1
            sign *= pair_sign
            contractions.append({
                "edge": edge_index,
                "ghost_token": f"v{ghost[0]}s{ghost[1]}",
                "antighost_token": f"v{antighost[0]}s{antighost[1]}",
                "permutation_exponent": exponent,
                "pair_sign": pair_sign,
                "contraction": "<u bar_u>=K^-1",
            })
            for position in sorted((pos_u, pos_b), reverse=True):
                working.pop(position)
        target = []
        for label in ("external_antighost", "external_ghost"):
            target.extend(
                (v, s, species)
                for v, s, species, external in flattened
                if external == label
            )
        if working != target:
            assert working == list(reversed(target))
            sign *= -1
        return {
            "source_order": labels,
            "canonical_order": [f"v{v}s{s}" for v, s, _species in target],
            "internal_contractions": contractions,
            "wick_permutation_sign": sign,
            "internal_ghost_edges": len(internal_edges),
            "sign_scope": (
                "DIRECTED_GAUSSIAN_CONTRACTIONS_<u_bar_u>_THEN_EXTERNAL_"
                "ANTIGHOST_GHOST_EFFECTIVE_ACTION_ORDER"
            ),
            "separate_imported_closed_loop_sign": False,
        }

    module.vertex_rules = vertex_rules
    module._vertex_terms_for_instance = terms_for_instance
    module._grassmann_sign = grassmann_sign
