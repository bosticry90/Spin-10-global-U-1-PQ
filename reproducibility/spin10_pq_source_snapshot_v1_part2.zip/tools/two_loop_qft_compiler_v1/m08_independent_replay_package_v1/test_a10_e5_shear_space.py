"""Full-family scientific tests and discriminating type/image controls."""
import unittest
from audit_a10_e5_shear_space import evidence, independent_checks
from a10_e5_shear_space import QQ_I, I
from a10_e5_shear_comparison import image_membership


class ShearSpaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.a, cls.b, cls.c = evidence()

    def test_all91125_tensor_slots(self): self.assertEqual(self.a['raw_tensor_slots'], 91125)
    def test_all12_covariance_output_rows(self): self.assertEqual(self.a['all12_full_output_equation_slots'], 1093500)
    def test_kernel_complete_by_character(self): self.assertEqual(self.a['real_dimension'], self.b['character_dimension']['invariant_dimension'])
    def test_exact_sector_completeness(self): self.assertEqual(self.a['sector_dimensions'], self.b['character_dimension']['three_sector_dimensions'])
    def test_real_basis_rank(self): self.assertEqual(len(self.a['real_basis']), self.a['real_dimension'])
    def test_cartan_not_full_H(self): self.assertGreater(len(self.a['weight_zero_slots']), self.a['real_dimension'])
    def test_ghost_H_cannot_be_omitted(self): self.assertGreater(independent_checks(self.a)['omit_ghost_H_loses_directions'], 0)
    def test_light_cannot_be_omitted(self): self.assertGreater(independent_checks(self.a)['omit_light_sectors_loses_directions'], 0)
    def test_all980100_image_slots(self): self.assertTrue(self.a['images']['all980100_physical_slots_defined_for_each_image'])
    def test_full_map_rank_nullity(self): self.assertEqual(self.a['images']['quartet_map_rank'] + self.a['images']['quartet_map_nullity'], self.a['real_dimension'])
    def test_complete_images_for_every_basis(self): self.assertEqual(len(self.a['images']['basis_images']), self.a['real_dimension'])
    def test_full_canonical_slots(self): self.assertTrue(self.a['images']['all1286_canonical_slots_checked_for_each_image'])
    def test_companion_injectivity(self): self.assertTrue(self.a['images']['companion_metrics_and_injectivity']['full_auxiliary_cubic_map_injective'])
    def test_source_companion_injectivity(self): self.assertTrue(self.a['images']['companion_metrics_and_injectivity']['full_nonminimal_source_map_injective'])
    def test_derivative_companion_injectivity(self): self.assertTrue(self.a['images']['companion_metrics_and_injectivity']['full_derivative_gauge_map_injective'])
    def test_nonlinear_jets_all_basis(self): self.assertTrue(all(v['second_jet_omission_control'] for v in self.a['images']['basis_images']))
    def test_measure_does_not_supply_A5(self): self.assertEqual(self.a['images']['exact_triangular_field_Berezinian'], '1'); self.assertFalse(self.a['images']['quantum_A5_implied'])
    def test_old_projections_preserved(self): self.assertTrue(self.a['images']['all_prior_measured_projections_preserved'])
    def test_actual_residual_only_dependent(self): self.assertFalse(self.a['actual_quartet_residual_read']); self.assertFalse(self.b['actual_quartet_residual_read'])
    def test_complete_membership_comparison(self): self.assertTrue(self.c['all980100_slots_compared'])
    def test_membership_does_not_adopt(self): self.assertFalse(self.c['normalization_adopted']); self.assertFalse(self.c['full_E5_or_quantum_A5'])
    def test_exact_small_membership_and_obstruction(self):
        one = QQ_I.one
        self.assertTrue(image_membership([{('x',): one}], {('x',): 2 * one})['member'])
        r = image_membership([{('x',): one, ('y',): one}], {('x',): one, ('y',): 2 * one})
        self.assertFalse(r['member']); self.assertNotEqual(r['value'], 0)
    def test_complex_row_with_real_solution(self): self.assertTrue(image_membership([{('x',): I}], {('x',): 2 * I})['member'])
    def test_whole_goal_remains_open(self): self.assertFalse(self.c['whole_goal_complete'])


if __name__ == '__main__': unittest.main()
