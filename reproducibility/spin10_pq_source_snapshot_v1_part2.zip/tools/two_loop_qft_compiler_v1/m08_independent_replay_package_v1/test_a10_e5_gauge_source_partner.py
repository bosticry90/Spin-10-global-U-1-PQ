"""Scientific/adversarial checks of source-vector poles and selected Ward test."""
import unittest
from audit_a10_e5_gauge_source_partner import *
from a10_e5_gauge_source_partner_control import born as unit_born,residue as unit_residue,model


class GaugeSourcePartnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_complete_source_gauge_background_domain(self):self.assertEqual(self.a['domain']['B_slots'],16*45**3);self.assertEqual(self.a['domain']['A_H_slots'],16*45*12*45)
    def test_all_three_B_triangle_families_nonzero(self):self.assertTrue(all(self.a['family_poles'][n]['B'] for n in ['ghost_B','aux_B','YM_B']))
    def test_source_is_odd_and_wrong_parity_is_rejected(self):
        w,P=model('ghost:a',0,0);self.assertTrue(w.grade(P[0],(4,0,0)));w.p['Je']=0;w.external['Je']=(2,-1,0);self.assertFalse(w.grade(P[0],(4,0,0)))
    def test_all16_Lorentz_unit_pairs_are_calculated(self):self.assertTrue(all(len(P)==16 for P in self.u['unit_pole_Lorentz_matrices'].values()))
    def test_nonzero_offdiagonal_kernel_residue_zero(self):self.assertTrue(self.u['nonzero_offdiagonal_intermediate_kernels_not_discarded']);self.assertTrue(all(z=='0' for P in self.u['unit_pole_Lorentz_matrices'].values() for i,j,z in P if i!=j))
    def test_external_gauge_derivative_evaluated_zero(self):self.assertTrue(self.u['external_gauge_derivative_zero_evaluated']);self.assertEqual(self.u['unit_pole_Lorentz_matrices']['ghost:B'][0][2],'0')
    def test_YM_transverse_piece_is_required(self):self.assertEqual(unit_residue(unit_born('YM',0,0,omit_transverse=True),'primary'),0);self.assertEqual(self.u['unit_pole_Lorentz_matrices']['YM'][0][2],'-3/2')
    def test_both_YM_pipe_orientations_match_full_Born(self):self.assertEqual(self.u['YM_even_inverse_pipe_Lorentz']['primary'],self.u['YM_even_inverse_pipe_Lorentz']['replay'])
    def test_mixed_and_reverse_odd_omissions_fail(self):self.assertTrue(all(v['nonzero_discrepancies'] for v in self.u['omission_controls'].values()))
    def test_A_vertices_are_nonzero_before_pole_zero(self):self.assertTrue(self.a['vertices']['ghost_A']);self.assertTrue(self.a['vertices']['aux_A']);self.assertFalse(self.a['actual_pole_A'])
    def test_A_H_M_edge_zero_is_independent_of_Ward_target(self):
        self.assertTrue(all(int(n[2:])<12 for role in ['ghost_A','aux_A'] for word in decode_typed(self.a['vertices'][role]) for n,j in word));self.assertTrue(all(int(n[2:])>=12 for word in decode_typed(self.a['vertices']['Xi']) for n,j in word))
    def test_altered_zero_A_channel_has_nonzero_Ward(self):
        w=alphabet();P=w.scale(w.mul(w.var('JB0_0'),w.var('A0_0'),w.var('C0')),g**2*xi)
        T={n:decode_typed(Q) for n,Q in read(HERE/'frozen_a10_e3_symmetry/primary.json')['operators']['Tb_geometric_and_transported'].items()}
        self.assertTrue(canonical(act(P,w,T,'primary',0)))
    def test_all_actual_source_density_units(self):self.assertTrue(all(s.Poly(z,g,xi).monoms()==[(2,1)] for z in decode_typed(self.a['canonical_full_g_squared_xi_density']).values()))
    def test_all12_constant_H_tensors(self):self.assertEqual(self.a['all12_constant_H_identities'],list(range(12)))
    def test_source_Ward_currents_and_Eulers_complete(self):
        w=alphabet();P=decode_typed(self.c['enlarged_source_Ward_raw']);A=decode_typed(self.c['enlarged_source_Ward_anchored']);C=[decode_typed(Q) for Q in self.c['source_Ward_full_currents']]
        self.assertFalse(canonical(w.add(P,w.scale(A,-1),w.scale(w.add(*(w.D(Q,mu) for mu,Q in enumerate(C))),-1))));self.assertEqual(len(self.c['all12_source_parameter_Eulers']),12)
    def test_omitted_actual_partners_leave_nonzero_Ward(self):self.assertGreater(self.c['negative_controls']['omitted_partners_source_Ward_terms'],0)
    def test_previous_Slavnov_projections_are_not_changed(self):self.assertTrue(all(not P for P in self.c['selected_Slavnov_new_node_projections'].values()))
    def test_failed_label_and_action_charts_are_preserved(self):
        for n in ['background_label_failure_disposition_1.json','action_frame_failure_disposition_1.json']:self.assertFalse(read(OUT/n)['counted_as_validation_PASS'])
    def test_source_chart_wrong_primal_has_nonzero_discrepancy(self):
        w,sub,back,source,anti,Cinv,Cphys=frames('primary');pullback=w.replace
        for i in IDS:
            for mu in range(4):back[f'JBp{i}_{mu}']=w.add(*(w.scale(w.var(f'JB{j}_{mu}'),Cphys[i,j]) for j in IDS if Cphys[i,j]))
        physical=decode_typed(self.a['physical_full_g_squared_xi_density']);wrong=pullback(physical,back);self.assertTrue(canonical(w.add(wrong,w.scale(decode_typed(self.a['canonical_full_g_squared_xi_density']),-1))))
    def test_unknown_breakings_and_full_E5_never_claimed(self):self.assertFalse(self.c['Gamma_unknown_Delta_b_s_contacts_measure_or_IR_set_to_zero']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete'])
    def test_prior_g3_failure_is_preserved(self):self.assertTrue(self.c['prior_g3_candidate_failure_preserved']);self.assertFalse(read(HERE/'frozen_a10_e5_quartic_g3/bindings.json')['candidate_selected_quartic_g3_gate_PASS'])


if __name__=='__main__':unittest.main()
