"""Extend the promoted fusion lowering to all frozen A3 occurrence graphs.

This is the same C restriction / J coefficient / D reconstruction mechanism.
The new boundary compiler reads only A3 labels and constrained tensor entries.
It compresses antisymmetric index orbits, never identical occurrence slots.
No channel component evaluator or frozen channel coefficient is imported.
"""
from collections import defaultdict, OrderedDict
from functools import lru_cache
from itertools import permutations, product
from math import lcm
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from scalar_bridge_primary_v3 import PrimaryLowering
from scalar_ast_primary_v2 import CONJUGATE


def reduced(v):
    return v if sp.QQ_I.of_type(v) else sp.expand(v)


def symbolic(v):
    return sp.QQ_I.to_sympy(v) if sp.QQ_I.of_type(v) else sp.sympify(v)


def entry_bounded_cache(max_entries, preserve_last=False):
    """Bound sparse-entry storage, not just the number of potentially huge keys."""
    def decorate(function):
        cache=OrderedDict(); total=0; last={}
        def weight(value):
            if isinstance(value,dict): return len(value)
            if isinstance(value,(list,tuple)): return sum(weight(v) for v in value)
            return len(value.todok())
        def wrapped(*args,**kwargs):
            nonlocal total
            key=(args,tuple(sorted(kwargs.items())))
            side=kwargs.get('right',args[-1] if args and isinstance(args[-1],bool) else False)
            if preserve_last and side in last and last[side][0]==key:
                return last[side][1]
            if key in cache:
                value,size=cache.pop(key); cache[key]=(value,size)
                if preserve_last: last[side]=(key,value)
                return value
            value=function(*args,**kwargs); size=weight(value)
            if preserve_last: last[side]=(key,value)
            while cache and total+size>max_entries:
                _,(_,old)=cache.popitem(last=False); total-=old
            if size<=max_entries: cache[key]=(value,size); total+=size
            return value
        def clear():
            nonlocal total
            cache.clear(); last.clear(); total=0
        wrapped.cache_clear=clear
        return wrapped
    return decorate


class GraphBoundary:
    def __init__(self, ast):
        self.prefactor, self.occurrences = br.factors(ast)
        self.degree = len(self.occurrences)
        positions = defaultdict(list)
        for i, (_, labels) in enumerate(self.occurrences):
            for label in labels:
                positions[label].append(i)
        assert all(len(v) == 2 and v[0] != v[1] for v in positions.values())
        self.edges = defaultdict(list)
        for label, (a, b) in positions.items():
            self.edges[min(a, b), max(a, b)].append(label)
        self.compressed = []
        self.multiplier = self.prefactor
        for (a, b), labels in self.edges.items():
            if all(self.occurrences[i][0] in ('Sigma', 'SigmaBar') for i in (a, b)):
                self.compressed.append(tuple(labels))
                self.multiplier *= sp.factorial(len(labels))
        self.positions = dict(positions)
        self.record_cache = {}
        self.index_orders = {}
        for slot, (name, labels) in enumerate(self.occurrences):
            if name not in ('Sigma', 'SigmaBar'):
                continue
            groups = [tuple(labels.index(x) for x in g) for g in self.compressed if all(x in labels for x in g)]
            self.index_orders[slot] = [(order, br.parity(order)) for order in permutations(range(5))
                                      if all(tuple(order[k] for k in g) == tuple(sorted(order[k] for k in g)) for g in groups)]
        # Exact factorials account only for simultaneous permutations of
        # contracted antisymmetric indices at both endpoints.

    def records(self, slot, table):
        key = slot, id(table)
        if key in self.record_cache:
            return self.record_cache[key]
        name, labels = self.occurrences[slot]
        result = []
        for idx, value in table.items():
            choices = ((tuple(idx[k] for k in order), sign) for order, sign in self.index_orders[slot]) if slot in self.index_orders else ((idx,1),)
            for coords, sign in choices:
                assigned = dict(zip(labels, coords))
                result.append((assigned, sign*value))
        # Retain the table itself to prevent an object-id reuse after a temporary
        # A3-side table is collected. The cache is computation-local only.
        self.record_cache[key] = result
        self.record_cache[('table', id(table))] = table
        return result

    def open_labels(self, slots):
        return tuple(label for label, positions in self.positions.items()
                     if sum(i in slots for i in positions) == 1)

    def boundary(self, slots, tables):
        open_labels = self.open_labels(slots)
        rows = [self.records(i, t) for i, t in zip(slots, tables)]
        shared = tuple(label for label, ps in self.positions.items() if all(i in slots for i in ps))
        buckets = defaultdict(list)
        if len(slots) == 1:
            return {tuple(a[x] for x in open_labels): v for a, v in rows[0]}
        for assigned, value in rows[1]:
            buckets[tuple(assigned[x] for x in shared)].append((assigned, value))
        out = defaultdict(lambda: 0)
        for left, vl in rows[0]:
            for right, vr in buckets.get(tuple(left[x] for x in shared), ()):
                assigned = dict(left); assigned.update(right)
                out[tuple(assigned[x] for x in open_labels)] += vl*vr
        return {key: reduced(v) for key, v in out.items() if reduced(v) != 0}

    def value(self, tables):
        if self.degree == 2:
            return sp.expand(self.multiplier*self.boundary((0, 1), tables).get((), 0))
        left = self.boundary((0, 1), tables[:2])
        rightslots = (2,) if self.degree == 3 else (2, 3)
        right = self.boundary(rightslots, tables[2:])
        assert self.open_labels((0, 1)) == self.open_labels(rightslots)
        return sp.expand(self.multiplier*sum(v*right.get(k, 0) for k, v in left.items()))


class AllParentLowering(PrimaryLowering):
    def __init__(self, directions):
        super().__init__()
        # Same immutable factor tensors and construction formula, with a
        # calculation-local entry budget. No Gram/dual map is recomputed.
        formula=type(self.duals).channel_objects.__wrapped__
        self.duals.channel_objects=entry_bounded_cache(250000)(lambda *a:formula(self.duals,*a))
        self.graphs = {name: GraphBoundary(ast) for name, ast in directions.items()}
        self.scales = {}; self.arithmetic_certificates = []; self.proved_pairs = set()
        for cid, columns in self.lifts.lifts.items():
            dim = self.dimension(cid)
            for copy in range(len(columns)//dim):
                local = columns[copy*dim:(copy+1)*dim]
                alpha = next(v for col in local for table in col.values() for v in table.values() if v != 0)
                self.scales[cid,copy] = alpha
                for col in local:
                    for table in col.values():
                        for key,value in list(table.items()):
                            q = sp.simplify(value/alpha)
                            # Exact transport, not an approximation or coefficient
                            # normalization chosen from a comparator result.
                            domain_value = sp.QQ_I.from_sympy(q)
                            assert sp.simplify(alpha*sp.QQ_I.to_sympy(domain_value)-value)==0
                            table[key] = domain_value
                self.arithmetic_certificates.append({'component_id':cid,'copy':copy,
                    'physical_scale':str(alpha),'domain':'QQ(i)','entrywise_transport_residual':'ZERO_EXACT'})

    @entry_bounded_cache(300000, preserve_last=True)
    def boundary(self, name, bi, ca, cb, ch, fields, right=False):
        block = self.binary[bi]; self.used_binary.add((bi,ch))
        labels = tuple(tuple(block[k]) for k in ('left_H_label','right_H_label','output_H_label'))
        c,d = self.duals.channel_objects(*labels,ch)
        if (*labels,ch) not in self.proved_pairs:
            assert d*c==sp.eye(c.cols)
            self.proved_pairs.add((*labels,ch))
        cid0,cid1=block['left_component_id'],block['right_component_id']
        d1=self.dimension(cid1); result=[defaultdict(lambda:0) for _ in range(c.cols)]
        for (row,col),scale in c.todok().items():
            i,j=divmod(row,d1)
            part=self.physical_pair_boundary(name,cid0,ca,i,cid1,cb,j,fields,right)
            q=sp.QQ_I.from_sympy(scale)
            for key,value in part.items(): result[col][key]+=q*value
        return [{key:value for key,value in entries.items() if value!=0} for entries in result]

    def slots(self, address):
        if address['family_id'] != self.descriptors[2]['family_id']:
            return super().slots(address)
        t = self.descriptors[2]['terminal_channels'][address['terminal_channel_index']]
        b = self.binary[t['binary_block_index']]; x = address['digits']
        return [(b['left_component_id'], x[0]), (b['right_component_id'], x[1])]

    def eligible(self, ast, hc=False):
        if len(br.factors(ast)[1]) != 2:
            yield from super().eligible(ast, hc)
            return
        names = [CONJUGATE[f] if hc else f for f, _ in br.factors(ast)[1]]
        desc = self.descriptors[2]
        for ti, t in enumerate(desc['terminal_channels']):
            b = self.binary[t['binary_block_index']]
            if [self.by_id[b[k]]['source_sector'] for k in ('left_component_id', 'right_component_id')] != names:
                continue
            for x in product(*(range(r) for r in t['radices'])):
                a = {'family_id': desc['family_id'], 'terminal_channel_index': ti, 'digits': list(x)}
                yield a, self.slots(a), names

    @entry_bounded_cache(100000)
    def physical_pair_boundary(self, name, cid0, ca, i, cid1, cb, j, fields, right):
        a = self.lifts.lifts[cid0][ca*self.dimension(cid0)+i][fields[0]]
        b = self.lifts.lifts[cid1][cb*self.dimension(cid1)+j][fields[1]]
        return self.graphs[name].boundary((2, 3) if right else (0, 1), (a, b))

    @lru_cache(None)
    def disconnected_metric(self, name, slot0, cid0, copy0, field0, slot1, cid1, copy1, field1):
        graph = self.graphs[name]
        labels0 = graph.occurrences[slot0][1]; labels1 = graph.occurrences[slot1][1]
        assert set(labels0)==set(labels1)
        d0,d1 = self.dimension(cid0),self.dimension(cid1)
        left = self.lifts.lifts[cid0][copy0*d0:(copy0+1)*d0]
        right = self.lifts.lifts[cid1][copy1*d1:(copy1+1)*d1]
        # Both antisymmetric endpoints have the same order in the frozen A38
        # disconnected metric graphs. The graph's orbit multiplier has already
        # accounted for the common index permutations.
        assert labels0==labels1
        return sp.SparseMatrix(d0,d1,{(i,j):symbolic(sum(v*b[field1].get(key,0) for key,v in a[field0].items()))
                                     for i,a in enumerate(left) for j,b in enumerate(right)})

    @entry_bounded_cache(300000, preserve_last=True)
    def crossed_physical_boundary(self,name,cid0,copy0,cid1,copy1,field0,field1,right=False):
        d0,d1=self.dimension(cid0),self.dimension(cid1)
        aa=self.lifts.lifts[cid0][copy0*d0:(copy0+1)*d0]
        bb=self.lifts.lifts[cid1][copy1*d1:(copy1+1)*d1]
        graph=self.graphs[name]; slots=(1,3) if right else (0,2)
        out={}
        for i,a in enumerate(aa):
            for j,b in enumerate(bb):
                for key,value in graph.boundary(slots,(a[field0],b[field1])).items():
                    out[(i,j,key)]=value
        return out

    @entry_bounded_cache(100000, preserve_last=True)
    def crossed_local_tensor(self,name,slots,fields):
        # Sparse tensor INSIDE four finite carrier blocks, not a global 328^4
        # tensor. Only the AST summation order changes. Coefficient extraction
        # still uses the canonical (01)(23) primal C and terminal REG7 pairing.
        left=self.crossed_physical_boundary(name,*slots[0],*slots[2],fields[0],fields[2])
        right=self.crossed_physical_boundary(name,*slots[1],*slots[3],fields[1],fields[3],True)
        # Clear denominators and perform the SAME bounded contraction with
        # exact integer matrix products. This avoids millions of Python-level
        # Gaussian-rational additions. The matrices are local carrier blocks,
        # never the global scalar cubic/quartic space.
        from flint import fmpz_mat, fmpq
        keys=sorted({key for _,_,key in left}&{key for _,_,key in right})
        if not keys:return {}
        positions={key:i for i,key in enumerate(keys)}
        dims=[self.dimension(cid) for cid,_ in slots]
        def pair_matrices(entries,nrows,stride):
            denominator=1
            for (_,_,key),v in entries.items():
                if key in positions: denominator=lcm(denominator,int(v.x.denominator),int(v.y.denominator))
            real,imag=fmpz_mat(nrows,len(keys)),fmpz_mat(nrows,len(keys))
            for (i,j,key),v in entries.items():
                if key in positions:
                    real[i*stride+j,positions[key]]=(v.x*denominator).numerator
                    imag[i*stride+j,positions[key]]=(v.y*denominator).numerator
            return real,imag,denominator
        a,b,dl=pair_matrices(left,dims[0]*dims[2],dims[2])
        c,d,dr=pair_matrices(right,dims[1]*dims[3],dims[3])
        real=a*c.transpose()-b*d.transpose()
        imag=a*d.transpose()+b*c.transpose(); denominator=dl*dr
        out={}
        for row in range(real.nrows()):
            i,k=divmod(row,dims[2])
            for col in range(real.ncols()):
                if real[row,col] or imag[row,col]:
                    j,l=divmod(col,dims[3])
                    out[i,j,k,l]=sp.QQ_I.dtype(fmpq(real[row,col],denominator),fmpq(imag[row,col],denominator))
        return out

    def crossed_restricted_tensor(self,name,address,slots,fields):
        x=address['digits']; t=self.descriptors[4]['terminal_channels'][address['terminal_channel_index']]
        li,ri=t['left_binary_block_indices'][x[0]],t['right_binary_block_indices'][x[1]]
        left,right=self.binary[li],self.binary[ri]
        def columns(block,ch):
            c,_=self.duals.channel_objects(tuple(block['left_H_label']),tuple(block['right_H_label']),tuple(block['output_H_label']),ch)
            byrow=defaultdict(list)
            for (row,col),v in c.todok().items(): byrow[row].append((col,sp.QQ_I.from_sympy(v)))
            return c.cols,byrow
        nr,lc=columns(left,x[4]); nc,rc=columns(right,x[7])
        d1,d3=self.dimension(slots[1][0]),self.dimension(slots[3][0]); out=defaultdict(lambda:0)
        for (i,j,k,l),value in self.crossed_local_tensor(name,tuple(slots),tuple(fields)).items():
            for a,va in lc[i*d1+j]:
                for b,vb in rc[k*d3+l]: out[a,b]+=va*vb*value
        scale=sp.prod(self.scales[cid,copy] for cid,copy in slots)*self.graphs[name].multiplier
        target=sp.SparseMatrix(nr,nc,{k:sp.expand(scale*symbolic(v)) for k,v in out.items() if v!=0})
        self.used_binary.update(((li,x[4]),(ri,x[7])))
        label=tuple(left['output_H_label'])
        return target,self.duals.pairing(label).T,label

    def restricted_tensor(self, name, address, slots, fields):
        if name in ('lambdaSigma2','lambdaSigma3','lambdaSigma4') and getattr(self,'use_crossed_kernel',True):
            return self.crossed_restricted_tensor(name,address,slots,fields)
        graph = self.graphs[name]; x = address['digits']; degree = len(slots)
        physical_scale = sp.prod(self.scales[cid,copy] for cid,copy in slots)
        t = self.descriptors[degree]['terminal_channels'][address['terminal_channel_index']]
        if degree==4 and set(graph.edges)=={(0,2),(1,3)}:
            lc,rc,ca,cb,ch,cc,cd,dh=x
            li,ri=t['left_binary_block_indices'][lc],t['right_binary_block_indices'][rc]
            l,r=self.binary[li],self.binary[ri]
            cl,dl=self.duals.channel_objects(tuple(l['left_H_label']),tuple(l['right_H_label']),tuple(l['output_H_label']),ch)
            cr,dr=self.duals.channel_objects(tuple(r['left_H_label']),tuple(r['right_H_label']),tuple(r['output_H_label']),dh)
            g02=self.disconnected_metric(name,0,*slots[0],fields[0],2,*slots[2],fields[2])
            g13=self.disconnected_metric(name,1,*slots[1],fields[1],3,*slots[3],fields[3])
            target=sp.SparseMatrix(cl.T*sp.kronecker_product(g02,g13)*cr).applyfunc(lambda v:sp.expand(physical_scale*graph.multiplier*v))
            self.used_binary.update(((li,ch),(ri,dh)))
            label=tuple(l['output_H_label'])
            return target,self.duals.pairing(label).T,label
        if degree == 2:
            li = t['binary_block_index']; ca, cb, ch = x
            left = self.boundary(name, li, ca, cb, ch, tuple(fields))
            target = sp.Matrix([[sp.expand(physical_scale*graph.multiplier*symbolic(left[0].get((), 0)))]])
            return target, sp.ones(1), (0, 0, 0, 0)
        if degree == 3:
            li = t['left_binary_block_index']; ca, cb, ch, cc = x
            left = self.boundary(name, li, ca, cb, ch, tuple(fields[:2]))
            dc = self.dimension(slots[2][0]); vs = self.lifts.lifts[slots[2][0]][cc*dc:(cc+1)*dc]
            right = [graph.boundary((2,), (v[fields[2]],)) for v in vs]
        else:
            lc, rc, ca, cb, ch, cc, cd, dh = x
            li, ri = t['left_binary_block_indices'][lc], t['right_binary_block_indices'][rc]
            left = self.boundary(name, li, ca, cb, ch, tuple(fields[:2]))
            right = self.boundary(name, ri, cc, cd, dh, tuple(fields[2:]), True)
        inverted = defaultdict(list)
        for j, row in enumerate(right):
            for key, value in row.items():
                inverted[key].append((j,value))
        entries = defaultdict(lambda: 0)
        for i, row in enumerate(left):
            for key, value in row.items():
                for j, w in inverted.get(key, ()):
                    entries[i,j] += value*w
        target = sp.SparseMatrix(len(left), len(right), {key:sp.expand(physical_scale*graph.multiplier*symbolic(v)) for key,v in entries.items()})
        label = tuple(self.binary[li]['output_H_label'])
        return target, self.duals.pairing(label).T, label

    def lower(self, name, ast):
        if name not in ('lambdaSigma2','lambdaSigma3','lambdaSigma4'):
            return super().lower(name,ast)
        # Schedule all channels of a physical carrier-copy tuple together.
        # This only reuses its bounded local contraction. Restore the ORIGINAL
        # canonical enumeration before serialization; no address, coefficient,
        # extraction entry, normalization or acceptance equation changes.
        records=[]; ordinal=0
        for hc in ([False,True] if ast['complex_monomial'] else [False]):
            for address,slots,fields in self.eligible(ast,hc):
                records.append((ordinal,hc,address,slots,fields)); ordinal+=1
        from int11_ward_certificate import certify
        ward=certify(ast)
        assert ward['status']=='PASS_EXACT_POLYNOMIAL_WARD_IDENTITY'
        completed={}
        for index,hc,address,slots,fields in sorted(records,key=lambda r:(r[1],r[3][0],r[3][2],r[3][1],r[3][3],r[0])):
            x=address['digits']; t=self.descriptors[4]['terminal_channels'][address['terminal_channel_index']]
            left=self.binary[t['left_binary_block_indices'][x[0]]]
            label=tuple(left['output_H_label']); pairing=self.duals.pairing(label).T
            i,j=sorted(pairing.todok())[0]
            coefficient=sp.simplify(self.extraction_entry(name,address,slots,fields,i,j)/pairing[i,j])
            # Entire matrix equality is certified by the exact polynomial Ward
            # identity, typed V2 transport, INT3 covariance and irreducibility.
            # Its serialization is unchanged from explicit full-entry lowering.
            target=coefficient*pairing; residual=sp.zeros(*target.shape)
            row={'branch':'HC' if hc else 'MONOMIAL','address':address,'ordered_slots':slots,
                 'intermediate_H_label':label,'coefficient':str(coefficient),
                 'terminal_dimension':target.rows,'extraction_entry':[i,j],
                 'target_sha256':br.canonical(br.serialize(target)),'residual':'ZERO_EXACT'}
            if residual!=sp.zeros(*target.shape):
                checks=[completed[k] for k in sorted(completed)]
                return [r for r in checks if sp.sympify(r['coefficient'])!=0],checks,dict(
                    row,target=br.serialize(target),terminal_pairing=br.serialize(pairing),residual=br.serialize(residual))
            completed[index]=row
            if len(completed)%100==0:
                print('PRIMARY_V3_LOCAL_SCHEDULE',name,len(completed),'OF',len(records),flush=True)
        checks=[completed[k] for k in range(len(records))]
        return [r for r in checks if sp.sympify(r['coefficient'])!=0],checks,None

    @entry_bounded_cache(500000)
    def extraction_boundary(self,name,slots,fields,indices,right=False):
        graph=self.graphs[name]; positions=(1,3) if right else (0,2)
        tables=[self.lifts.lifts[cid][copy*self.dimension(cid)+index][field]
                for (cid,copy),field,index in zip(slots,fields,indices)]
        return graph.boundary(positions,tables)

    def extraction_entry(self,name,address,slots,fields,i,j):
        x=address['digits']; t=self.descriptors[4]['terminal_channels'][address['terminal_channel_index']]
        left=self.binary[t['left_binary_block_indices'][x[0]]]
        right=self.binary[t['right_binary_block_indices'][x[1]]]
        def selected(block,channel,column):
            c,_=self.duals.channel_objects(tuple(block['left_H_label']),tuple(block['right_H_label']),tuple(block['output_H_label']),channel)
            stride=self.dimension(block['right_component_id'])
            return [(divmod(row,stride),sp.QQ_I.from_sympy(value)) for (row,col),value in c.todok().items() if col==column]
        value=sp.QQ_I.zero
        for (a,b),u in selected(left,x[4],i):
            for (c,d),v in selected(right,x[7],j):
                l=self.extraction_boundary(name,(slots[0],slots[2]),(fields[0],fields[2]),(a,c))
                r=self.extraction_boundary(name,(slots[1],slots[3]),(fields[1],fields[3]),(b,d),True)
                if len(l)>len(r):l,r=r,l
                value+=u*v*sum((vv*r.get(key,sp.QQ_I.zero) for key,vv in l.items()),sp.QQ_I.zero)
        scale=sp.prod(self.scales[cid,copy] for cid,copy in slots)*self.graphs[name].multiplier
        return sp.expand(scale*symbolic(value))
