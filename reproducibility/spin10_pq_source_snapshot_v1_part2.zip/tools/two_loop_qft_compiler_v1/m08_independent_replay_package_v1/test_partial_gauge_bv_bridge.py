"""Bounded failed-gate custody and semantic regression tests."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from audit_partial_gauge_bv_bridge import compare,negative_controls,first_gate_regression
from partial_gauge_bv_bridge import PartialJets,PAIRS,GRADES,setup,g
import partial_gauge_bv_bridge_replay as replay


class PartialTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        folder=Path(__file__).resolve().parent/"frozen_partial_gauge_bv_bridge"
        cls.p=json.loads((folder/"primary.json").read_text())
        cls.r=json.loads((folder/"replay.json").read_text())
    def test_complete_obstruction_comparison(self): compare(self.p,self.r)
    def test_adversarial_claim_mutations(self): self.assertEqual(negative_controls(self.p,self.r),22)
    def test_all_44_columns_retained(self): self.assertEqual(len(self.p["images"]),44)
    def test_residual_nonzero(self): self.assertTrue(self.p["obstruction"]["residual"])
    def test_global_connection_L_is_zero(self): self.assertEqual(self.p["obstruction"]["L_generator"],[])
    def test_local_curvature_derivative_identified(self): self.assertEqual(self.p["obstruction"]["residual"],self.p["obstruction"]["minus_g_partial_R"])
    def test_source_pairing_not_IBP_null(self): self.assertTrue(self.p["obstruction"]["source_Euler_residual"])
    def test_nontrivial_interactions_present(self): self.assertTrue(any("g**2" in r["coefficient"] for r in self.p["actions"]["invariant"]))
    def test_vev_present(self): self.assertTrue(any("v" in r["coefficient"] for r in self.p["images"]["p0"]))
    def test_residual_group_not_gauge_fixed_by_light_doublet(self): self.assertNotIn("bar2",GRADES); self.assertNotIn("b2",GRADES)
    def test_canonical_orientation_all_22_pairs(self):
        j=PartialJets()
        for z,J in PAIRS:
            star=j.a.scale(j.var(J),(-1)**GRADES[z][2])
            self.assertEqual(j.bracket(j.var(z),star),{():1})
            self.assertEqual(j.bracket(star,j.var(z)),{():-1})
    def test_jet_bound_raises(self):
        with self.assertRaises(RuntimeError): PartialJets().var("c0",(0,)*7)
    def test_replay_no_primary_import(self): self.assertNotIn("from partial_gauge_bv_bridge import",inspect.getsource(replay))
    def test_direct_replay_fresh(self): self.assertEqual(replay.obstruction_evidence(),self.r)
    def test_wrong_failure_not_accepted(self):
        def bad(): raise AssertionError("UNRELATED")
        with self.assertRaises(AssertionError): first_gate_regression(bad,"delta square A20")
    def test_no_failure_not_accepted(self):
        with self.assertRaises(AssertionError): first_gate_regression(lambda:None,"delta square A20")
    def test_independence_ceiling(self): self.assertFalse(self.r["independence"]["LIBRARY_INDEPENDENT"] or self.r["independence"]["full_source_replay_reached"])
    def test_downstream_gates_not_claimed(self): self.assertFalse(self.p["complete_square_or_master_audit_reached"] or self.p["local_H_Ward_gate_reached"])
    def test_no_promotion_or_physics_change(self): self.assertFalse(self.p["bridge_qualified"] or self.p["M08_changed"] or self.p["HB1_C5_authorized"])
    def test_authority_and_finite_threshold_unchanged(self): self.assertEqual(self.p["formal_authority"],"34/39_UNCHANGED"); self.assertIsNone(self.p["finite_C1_GS"])
    def test_external_review_not_invented(self): self.assertFalse(self.p["external_specialist_review"])
    def test_dropped_source_rejected(self):
        bad=copy.deepcopy(self.p); del bad["images"]["Jb0"]
        with self.assertRaises(AssertionError): compare(bad,self.r)


if __name__=="__main__": unittest.main()
