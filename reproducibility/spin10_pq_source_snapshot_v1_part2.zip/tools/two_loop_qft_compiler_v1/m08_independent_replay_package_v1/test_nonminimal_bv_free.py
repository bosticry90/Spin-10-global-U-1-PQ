"""Bounded exact regressions; no filesystem writes or cochain calculations."""
import copy
import itertools
import unittest
import sympy as s
from nonminimal_bv_free import build, setup, Jets, GRADES
from nonminimal_bv_free_replay import build as replay_build
from audit_nonminimal_bv_free import compare, negative_controls, normal_primary


class FreeBVTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.primary, cls.replay = build(), replay_build()
        cls.j, cls.x, cls.kinetic, cls.gf, cls.minimal, cls.psi = setup()
        cls.action = cls.j.a.add(cls.minimal, cls.gf)
        cls.Q = cls.j.columns(cls.action)

    def test_complete_primary_replay_agreement(self):
        compare(self.primary, self.replay)

    def test_seven_audit_mutations_are_rejected(self):
        self.assertEqual(negative_controls(self.primary, self.replay), 7)

    def test_fourteen_images_and_seven_pairs(self):
        self.assertEqual(len(self.Q), 14)
        self.assertEqual(self.primary["canonical_pair_count"], 7)

    def test_every_required_first_and_second_jet_square(self):
        self.assertEqual(self.primary["squares"]["base_and_jets_through_order_two_checked"], 210)
        self.assertEqual(self.replay["square_count"], 210)
        self.assertTrue(self.primary["squares"]["all_exact_zero"])

    def test_third_mixed_source_jets_without_truncation(self):
        for n in ("KL", "Lu", "KV0"):
            p = self.j.var(n, (0, 1, 2))
            self.assertEqual(self.j.Q(self.j.Q(p, self.Q), self.Q), {})

    def test_auxiliary_source_two_nonzero_pieces_cancel(self):
        j, a = self.j, self.j.a
        old_part = a.add(self.Q["KL"], self.x["Kbar"])
        first = j.Q(old_part, self.Q)
        second = a.scale(self.Q["Kbar"], -1)
        self.assertTrue(first)
        self.assertTrue(second)
        self.assertEqual(a.add(first, second), {})

    def test_all_forward_rules_come_from_same_action(self):
        a, j = self.j.a, self.j
        self.assertEqual(self.Q["bar"], a.scale(self.x["Lambda"], -1))
        self.assertEqual(self.Q["Lambda"], {})
        self.assertEqual(self.Q["u"], {})
        for m in range(4):
            self.assertEqual(self.Q[f"V{m}"], j.D(self.x["u"], m))

    def test_old_failure_remains_nonzero(self):
        self.assertTrue(self.primary["old_failure"]["Q2_KL"])
        self.assertTrue(self.primary["old_failure"]["Q2_KL_Lambda"])

    def test_master_is_zero_as_functional_not_pointwise(self):
        half = self.j.a.scale(self.j.bracket(self.action, self.action), s.Rational(1, 2))
        self.assertTrue(half)
        self.assertTrue(all(self.j.euler(half, n) == {} for n in GRADES))
        self.assertTrue(self.primary["master"]["total_derivative_current"])

    def test_old_witness_is_not_a_total_derivative(self):
        density = self.j.a.mul(self.x["Lambda"], self.j.box(self.x["u"]))
        self.assertEqual(self.j.euler(density, "Lambda"), self.j.box(self.x["u"]))

    def test_setting_partner_to_zero_is_not_chain_restriction(self):
        self.assertTrue(self.Q["Kbar"])
        self.assertFalse(self.primary["negative_controls"]["Kbar_zero_is_Q_invariant"])

    def test_flipping_partner_sign_fails_master_and_square(self):
        j, x, _, gf, minimal, _ = setup(partner_sign=1)
        action = j.a.add(minimal, gf)
        Q = j.columns(action)
        self.assertEqual(j.Q(Q["KL"], Q), j.a.scale(j.box(x["u"]), -2))
        self.assertTrue(j.euler(j.bracket(action, action), "Lambda"))

    def test_derivatives_commute(self):
        for n in GRADES:
            self.assertEqual(self.j.D(self.j.D(self.x[n], 0), 1), self.j.D(self.j.D(self.x[n], 1), 0))

    def test_jet_limit_raises_instead_of_dropping_terms(self):
        with self.assertRaisesRegex(RuntimeError, "NOT_TRUNCATED"):
            Jets(limit=1).var("u", (0, 0))

    def test_graded_left_right_relation_on_even_action(self):
        for n in GRADES:
            self.assertEqual(self.j.euler(self.action, n, "right"), self.j.a.scale(self.j.euler(self.action, n), (-1)**GRADES[n][2]))

    def test_Lambda_parser_is_a_symbol_not_a_function(self):
        self.assertEqual(normal_primary([{"odd_word": [], "coefficient": "-Lambda"}]), {("Lambda",): -1})

    def test_gauge_shift_inverse_and_intertwiner(self):
        self.assertTrue(self.primary["transport"]["inverse_and_intertwining_exact"])
        self.assertTrue(self.replay["gauge_fixing_inverse_and_intertwining"])

    def test_wrong_but_invertible_shift_is_not_accepted(self):
        a, j = self.j.a, self.j
        shifts = {n: a.scale(j.bracket(self.psi, self.x[n]), -1) for n in GRADES}
        shifts["Kbar"] = a.scale(shifts["Kbar"], -1)
        # Still invertible because this is a source-free additive shift.
        self.assertEqual(j.transport(j.transport(self.x["Kbar"], shifts), shifts, -1), self.x["Kbar"])
        residual = a.add(j.Q(j.transport(self.x["KL"], shifts), self.Q), a.scale(j.transport(j.columns(self.minimal)["KL"], shifts), -1))
        self.assertTrue(residual)

    def test_no_EOM_or_M08_promotion_claim(self):
        self.assertFalse(self.primary["master"]["EOM_used"])
        self.assertFalse(self.primary["M08_changed"])
        self.assertFalse(self.primary["HB1_C5_authorized"])
        self.assertFalse(self.primary["cochain_rank_cohomology_computed"])
        self.assertFalse(self.primary["external_specialist_review"])


if __name__ == "__main__":
    unittest.main()
