"""Bounded engine and false-claim controls; no catalog reconstruction."""
import copy
import unittest
import sympy as s
from audit_interacting_actual_h_preflight import load,decode,compare,validate_architecture,validate_result,verify_divergences,verify_fresh_repeat
from interacting_actual_h_preflight import GaugeJets,BatchedExterior
from interacting_actual_h_preflight_replay import GaugeWords
from source_convention_control import Exterior
from source_domain_transport_replay import DomainWords
from nonminimal_bv_free_replay import Words
from nonminimal_bv_free import Jets


class EngineControls(unittest.TestCase):
    def test_memoized_Euler_against_uncached_derivation(self):
        j=GaugeJets(2); a=j.a
        P=a.add(a.mul(j.var('Jb0'),j.var('bar1')),a.mul(j.var('q0_0',(0,1)),j.var('c0')),a.mul(j.var('bar0'),j.var('c1',(1,))))
        for name in j.grades|j.external:
            for side in ('left','right'):
                expected=Jets.euler(j,P,name,side)
                self.assertEqual(j.euler(P,name,side),expected)
                self.assertEqual(j.euler(P,name,side),expected)
        self.assertLessEqual(len(j._Euler_cache),256)

    def test_batched_primary_transport_against_historical(self):
        j=GaugeJets(2); a=j.a
        shifts={'Jb0':j.var('bar0'),'Jbar1':a.add(j.var('b1'),j.var('q0_0',(0,1)))}
        P=a.add(a.mul(j.var('Jb0'),j.var('bar1')),a.mul(j.var('Jbar1'),j.var('Jbar1'),j.var('q1_0')),a.mul(j.var('Jb0',(1,2)),j.var('c0')))
        for sign in (-1,1): self.assertEqual(Jets.transport(j,P,shifts,sign),j.transport(P,shifts,sign))

    def test_batched_exterior_against_historical_engine(self):
        old,new=Exterior(),BatchedExterior()
        for engine in (old,new):
            x=engine.variable('x',0); y=engine.variable('y',0)
            b=engine.variable('b',1); c=engine.variable('c',1)
            P=engine.add(engine.mul(x,x,b,c),engine.mul(y,b),engine.mul(x,y))
        for parity in (0,1):
            images={'x':y,'y':x,'b':c,'c':b} if parity==0 else {'x':new.mul(y,c),'y':b,'b':x,'c':y}
            self.assertEqual(old.derive(P,images,parity),new.derive(P,images,parity))

    def test_word_batching_against_historical_engine(self):
        w=GaugeWords(2)
        P=w.add(w.mul(w.var('q0_0'),w.var('bar0',(0,)),w.var('c1')),w.mul(w.var('Jb1'),w.var('bar0')),w.mul(w.var('q0_0',(1,)),w.var('q1_0')))
        even={name:w.var(name) for name in w.p}
        odd={'bar0':w.scale(w.var('b0'),-1),'q0_0':w.var('c0',(0,)),'Jb1':w.var('Jbar1'),'c1':w.var('b1')}
        for mu in range(4): self.assertEqual(Words.D(w,P,mu),w.D(P,mu))
        for name in w.p: self.assertEqual(Words.EL(w,P,name),w.EL(P,name))
        for parity,images in ((0,even),(1,odd)): self.assertEqual(DomainWords.act(w,P,images,parity),w.act(P,images,parity))
        self.assertEqual(Words.replace(w,P,even),w.replace(P,even))

    def test_left_right_odd_source_derivative(self):
        j=GaugeJets(1); a=j.a; product=a.mul(j.var('Jb0'),j.var('bar0'))
        self.assertEqual(j.euler(product,'bar0'),a.scale(j.var('Jb0'),-1))
        self.assertEqual(j.euler(product,'bar0','right'),j.var('Jb0'))

    def test_graded_left_product_rule(self):
        j=GaugeJets(2); a=j.a
        product=a.mul(j.var('bar0'),j.var('bar1')); images={'bar0':a.scale(j.var('b0'),-1),'bar1':a.scale(j.var('b1'),-1)}
        expected=a.add(a.scale(a.mul(j.var('b0'),j.var('bar1')),-1),a.mul(j.var('bar0'),j.var('b1')))
        self.assertEqual(j.Q(product,images),expected)

    def test_word_left_derivative_replay(self):
        w=GaugeWords(1); product=w.mul(w.var('Jb0'),w.var('bar0'))
        self.assertEqual(w.EL(product,'bar0'),w.scale(w.var('Jb0'),-1))

    def test_canonical_antifield_orientation(self):
        j=GaugeJets(1); a=j.a
        for z,J in j.pairs:
            self.assertEqual(j.bracket(j.var(z),a.scale(j.var(J),(-1)**j.grades[z][2])),{():s.Integer(1)})

    def test_high_jet_is_error_not_zero(self):
        j=GaugeJets(1)
        with self.assertRaises(RuntimeError): j.var('c0',(0,)*7)

    def test_symmetric_ordinary_jets(self):
        j=GaugeJets(1); w=GaugeWords(1)
        self.assertEqual(j.D(j.D(j.var('q0_0'),1),2),j.D(j.D(j.var('q0_0'),2),1))
        self.assertEqual(w.D(w.D(w.var('q0_0'),1),2),w.D(w.D(w.var('q0_0'),2),1))

    def test_word_transport_explicit_inverse(self):
        w=GaugeWords(1); shifts={'Jb0':w.var('bar0')}
        positive={name:w.add(w.var(name),P) for name,P in shifts.items()}
        inverse={name:w.add(w.var(name),w.scale(P,-1)) for name,P in shifts.items()}
        for name in w.grades:
            self.assertEqual(w.replace(w.replace(w.var(name),positive),inverse),w.var(name))
        self.assertEqual(w.replace(w.replace(w.var('Jb0',(1,2)),positive),inverse),w.var('Jb0',(1,2)))

    def test_primary_transport_explicit_inverse(self):
        j=GaugeJets(1); shifts={'Jb0':j.var('bar0')}
        for name in j.grades:
            self.assertEqual(j.transport(j.transport(j.var(name),shifts),shifts,-1),j.var(name))


class EvidenceControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.architecture=load('architecture.json'); cls.capsule=load('primary.json'); cls.primary=decode(cls.capsule); cls.replay=decode(load('replay.json'))

    def test_phase_A_maps(self): self.assertTrue(validate_architecture(self.architecture))
    def test_exact_independent_comparison(self): self.assertTrue(compare(self.primary,self.replay))
    def test_fresh_repeat_receipt(self): self.assertTrue(verify_fresh_repeat(load('regeneration.json'),self.capsule,load('replay.json')))
    def test_repeat_digest_mismatch_rejected(self):
        bad=copy.deepcopy(load('regeneration.json')); bad['routes']['primary']['repeat_payload_sha256']='0'*64
        with self.assertRaises(AssertionError): verify_fresh_repeat(bad,self.capsule,load('replay.json'))
    def test_failed_repeat_exit_rejected(self):
        bad=copy.deepcopy(load('regeneration.json')); bad['routes']['replay']['repeat_exit_code']=1
        with self.assertRaises(AssertionError): verify_fresh_repeat(bad,self.capsule,load('replay.json'))
    def test_evidence_digest_corruption_rejected(self):
        bad=copy.deepcopy(self.capsule); bad['payload_sha256']='0'*64
        with self.assertRaises(AssertionError): decode(bad)

    def test_master_currents_reconstructed(self): self.assertIn(verify_divergences(self.primary),(0,3))

    def test_primary_column_mutation_rejected(self):
        bad=copy.deepcopy(self.primary)
        if bad['result']['status'].startswith('PASS'):
            bad['result']['images']['Q_min']['c0']=[{'word':[],'coefficient':'1'}]
        else: bad['result']['witness']['identity']='INVENTED'
        with self.assertRaises(AssertionError): compare(bad,self.replay)

    def test_divergence_mutation_rejected(self):
        if not self.primary['result']['status'].startswith('PASS'): self.skipTest('Later scientific gate not reached')
        bad=copy.deepcopy(self.primary)
        current=next(v for v in bad['result']['master']['minimal']['currents'] if v)
        current[0]['coefficient']=str(s.sympify(current[0]['coefficient'])+1)
        with self.assertRaises(AssertionError): verify_divergences(bad)


def architecture_mutation_test(name,mutator):
    def test(self):
        bad=copy.deepcopy(self.architecture); mutator(bad)
        with self.assertRaises(AssertionError): validate_architecture(bad)
    setattr(EvidenceControls,'test_reject_architecture_'+name,test)


architecture_mutation_test('wrong_Gram',lambda a:a['gram']['entries'][0].__setitem__(2,'1'))
architecture_mutation_test('missing_partner',lambda a:a['prospective_partner_maps'].pop())
architecture_mutation_test('wrong_partner_ghost',lambda a:a['prospective_partner_maps'][0]['source_grade'].__setitem__(1,-3))
architecture_mutation_test('identity_bracket',lambda a:a['prospective_partner_maps'][0]['induced_unsigned_bracket'].__setitem__('entries',[[i,i,'1'] for i in range(12)]))
architecture_mutation_test('historical_AST_claim',lambda a:a['prospective_partner_maps'][0].__setitem__('historical_nonminimal_AST_identified',True))
architecture_mutation_test('unclosed_block',lambda a:a.__setitem__('ids',[0,4]))
architecture_mutation_test('source_activation',lambda a:a.__setitem__('active_sources_added',True))
architecture_mutation_test('lost_historical_binding',lambda a:a['inherited_bindings_authenticated'].pop())


def result_mutation_test(name,mutator):
    def test(self):
        bad=copy.deepcopy(self.primary); mutator(bad)
        with self.assertRaises(AssertionError): validate_result(bad)
    setattr(EvidenceControls,'test_reject_result_'+name,test)


for field in ('full_M08_qualified','active_sources_added','phase_C_authorized','HB1_C5_authorized','external_specialist_review'):
    result_mutation_test(field,lambda a,key=field:a.__setitem__(key,True))
result_mutation_test('authority_promotion',lambda a:a.__setitem__('formal_authority','35/39'))
result_mutation_test('threshold_invention',lambda a:a.__setitem__('finite_C1_GS',0))


def bounded_pass_mutation_test(name,mutator):
    def test(self):
        if not self.primary['result']['status'].startswith('PASS'): self.skipTest('Scientific gate not reached')
        bad=copy.deepcopy(self.primary); mutator(bad['result'])
        with self.assertRaises(AssertionError): validate_result(bad)
    setattr(EvidenceControls,'test_reject_bounded_'+name,test)


bounded_pass_mutation_test('missing_external_background',lambda r:r['images']['Tb_fixed'].pop('A0_0'))
bounded_pass_mutation_test('counterterm_completeness',lambda r:r['domain'].__setitem__('counterterm_completeness',True))
bounded_pass_mutation_test('Euler_without_current',lambda r:r['master']['minimal'].__setitem__('currents',[[],[],[],[]]))
bounded_pass_mutation_test('EOM_identification',lambda r:r.__setitem__('EOM_used',True))
bounded_pass_mutation_test('source_only_action',lambda r:r['actions'].__setitem__('kinetic',[]))
bounded_pass_mutation_test('free_action_only',lambda r:r['actions'].__setitem__('kinetic',[row for row in r['actions']['kinetic'] if not s.sympify(row['coefficient']).has(s.Symbol('g10'))]))
bounded_pass_mutation_test('source_grade',lambda r:r['images']['Q_min'].__setitem__('Jb0',[{'word':['c0'],'coefficient':'1'}]))
bounded_pass_mutation_test('floating_coefficient',lambda r:r['images']['Q_min'].__setitem__('c0',[{'word':['c0','c1'],'coefficient':'0.5*g10'}]))
bounded_pass_mutation_test('new_parameter',lambda r:r['actions']['fermion'][0].__setitem__('coefficient','invented_parameter'))


if __name__=='__main__': unittest.main()
