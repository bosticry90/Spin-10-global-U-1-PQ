"""Read-only historical component preflight. No active source definitions."""
import json
from hashlib import sha256
from pathlib import Path
import sympy as s
from m08_indexed_variational import indexed_euler_lagrange
from m08_local_functional_ast import content_hash
from nonabelian_m08_semantic import geometry, matrix_record as raw_matrix_record

HERE = Path(__file__).resolve().parent
DISPOSITION = "QUALIFIED_BOUNDED_SIX_SOURCE_COORDINATE_DECODER_NOT_FULL_M08"


def load(name): return json.loads((HERE/name).read_text(encoding="utf-8"))
def clean(m): return s.ImmutableSparseMatrix(m).applyfunc(s.simplify)
def matrix_record(m):
    r=raw_matrix_record(m)
    return {"shape":[int(v) for v in r["shape"]],"entries":[[int(i),int(j),v] for i,j,v in r["entries"]]}
def matrix(r): return s.ImmutableSparseMatrix(*r["shape"], {(i,j): s.sympify(v) for i,j,v in r["entries"]})
def matrix_digest(m):
    payload = matrix_record(m)
    payload = {"shape": [int(v) for v in payload["shape"]], "entries": [[int(i),int(j),v] for i,j,v in payload["entries"]]}
    return {"shape": payload["shape"], "nonzero_entries": len(payload["entries"]), "canonical_sparse_sha256": sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()}


def physical_triangles():
    """Use actual physical columns to derive source maps, not representation names."""
    rows = load("frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json")["components"]
    registry = load("frozen_irrep_carrier_registry/REG7_dual_pairings.json")
    j3 = {tuple(r["left"]): matrix(r["matrix"]) for r in registry["SU3_pairings"]}
    j2 = {r["n"]: matrix(r["matrix"]) for r in registry["SU2_pairings"]}
    typed = {}; orders = {}
    for family in ("A", "H", "S"):
        local = [r for r in rows if r["family"] == family]; orders[family] = [r["source_component"] for r in local]
        factor = s.sqrt(2) if family != "S" else 1
        p = {r["source_component"]: factor*matrix(r["physical_columns"]) for r in local}
        a = {r["source_component"]: matrix(r["physical_extractor"])/factor for r in local}
        dp = {}; da = {}
        for r in local:
            cid, partner = r["source_component"], r["target_component"]
            label = next(v["source_label"] for v in local if v["source_component"] == partner)
            J = s.kronecker_product(j3[tuple(label[:2])], j2[label[2]]).T
            copies = p[cid].cols//J.cols; JJ = s.kronecker_product(s.eye(copies), J)
            dp[cid] = clean(a[partner].T*JJ); da[cid] = clean(JJ.inv()*p[partner].T)
        P = s.ImmutableSparseMatrix(s.Matrix.hstack(*(p[c] for c in orders[family])))
        A = s.ImmutableSparseMatrix(s.Matrix.vstack(*(a[c] for c in orders[family])))
        DP = s.ImmutableSparseMatrix(s.Matrix.hstack(*(dp[c] for c in orders[family])))
        DA = s.ImmutableSparseMatrix(s.Matrix.vstack(*(da[c] for c in orders[family])))
        assert clean(A*P) == clean(DA*DP) == s.eye(P.cols)
        typed[family] = P,A,DP,DA
    basis = load("frozen_c3/C3_representation_basis.json"); bases = {}
    for family, key in (("A","h_basis"),("H","heavy_basis")):
        B = s.ImmutableSparseMatrix(45,len(basis[key]),{(v["index"],j):s.sympify(v["coefficient"]) for j,r in enumerate(basis[key]) for v in r["raw_so10_coordinates"]})
        Gram = clean(B.T*B); inverse = Gram.inv(); bases[family] = B,inverse*B.T,B*inverse
    bases["S"] = (s.ImmutableSparseMatrix(s.eye(328)),)*3
    results = []
    # Explicit source/field role bindings from the six AST occurrences and
    # typed physical columns. Lambda is dual; its source is double-dual.
    specs = (("K_V","H",False,True),("K_q","A",False,True),("K_phi","S",False,True),
             ("L_u","H",False,True),("K_Lambda","H",True,False),("L_c","A",False,True))
    for source, family, field_dual, source_dual in specs:
        P,A,DP,DA = typed[family]; B,L,BD = bases[family]
        F,FL = (BD,B.T) if field_dual else (B,L)
        X,XA = (DP,DA) if field_dual else (P,A)
        Y,YA = (DP,DA) if source_dual else (P,A)
        E = clean(F.T*Y); E_inv = clean(YA*FL.T)
        T = clean(FL*X); T_inv = clean(XA*F)
        assert clean(E*E_inv) == clean(E_inv*E) == s.eye(E.rows)
        assert clean(T*T_inv) == clean(T_inv*T) == s.eye(T.rows)
        assert clean(F*T-X) == s.zeros(*X.shape)
        # F^-T maps evaluation sources into the physical source space.
        assert clean(FL.T*E-Y) == s.zeros(*Y.shape)
        terminal = clean(Y.T*X)
        assert clean(E.T*T-terminal) == s.zeros(*terminal.shape)
        Cfield = clean(FL*F.conjugate()); Ceval = Cfield.inv().T
        Ctyped = clean(YA*Y.conjugate())
        assert clean(Ctyped*Ctyped.conjugate()) == s.eye(Ctyped.rows)
        assert clean(E*Ctyped-Ceval*E.conjugate()) == s.zeros(*E.shape)
        # CAT macro self-dual A sources use primal C3 carrier coordinates;
        # the other four sources already use evaluation/double-dual coordinates.
        macro = clean(B.T*B) if source in ("K_q","L_c") else s.ImmutableSparseMatrix(s.eye(E.rows))
        K = clean(macro.inv()*E); K_inv = clean(E_inv*macro)
        assert clean(macro*K-E) == s.zeros(*E.shape)
        assert clean(K*K_inv) == clean(K_inv*K) == s.eye(K.rows)
        source_frame = B if source in ("K_q","L_c","K_Lambda") else FL.T
        assert clean(source_frame*K-Y) == s.zeros(*Y.shape)
        results.append({"source":source,"family":family,"field_dual":field_dual,"typed_source_dual":source_dual,
            "channel_components":E.rows,"channel_address_order":orders[family],
            "AST_evaluation_from_typed_source":matrix_digest(E), "inverse":matrix_digest(E_inv),
            "AST_field_from_typed_field":matrix_digest(T),"field_inverse":matrix_digest(T_inv),
            "catalog_macro_from_typed_source":matrix_digest(K),"catalog_macro_inverse":matrix_digest(K_inv),
            "macro_to_AST_evaluation":matrix_digest(macro),"typed_pairing":matrix_digest(terminal),
            "induced_source_only_coordinate_bracket_unsigned":matrix_digest(E_inv.T),
            "evaluation_conjugation":matrix_digest(Ceval),"typed_source_conjugation":matrix_digest(Ctyped),
            "both_inverse_products_pairing_physical_reconstruction_conjugation":True,
            "field_and_source_varied_simultaneously_identity_pairing_assumed":False})
    return results


def inventory():
    source = load("frozen_source_seed_s3_s5/S33_source_couplings.json")
    catalog = load("frozen_catalog_cat0_cat4/CAT1_module_actions.json")
    modules = {r["identity"]: r for r in catalog["modules"]}
    prior = {r["source"]: r for r in load("frozen_variational_s5_s8/V8_source_derivatives.json")["rows"]}
    typed = load("frozen_int9_int15/INT12_typed_role_maps.json")["role_dictionary"]
    rows = []
    for row in source["couplings"]:
        density = row["coupling_AST"]["density"]; value = density; envelopes = []
        while value["node"] in ("GroupContraction", "LorentzContraction"):
            envelopes.append({"node": value["node"], "indices": value["contracted_indices"]})
            value = value["expression"]
        assert value["node"] == "OrderedProduct" and len(value["factors"]) == 2
        src, image = value["factors"]
        assert src["node"] == "ExternalSource" and src["name"] == row["source"]
        kinds = ["lorentz" if i == "mu" else "heavy" if i == "i" else "scalar" if i == "A" else "adjoint_H" for i in src["indices"]]
        recovered = indexed_euler_lagrange(density, name=row["source"], free_indices=src["indices"], index_kinds=kinds, node_type="ExternalSource", side="left")
        assert recovered == prior[row["source"]]["recovered_image_AST"]
        assert content_hash(recovered) == prior[row["source"]]["frozen_transformation_sha256"]
        assert content_hash(image) == content_hash(recovered)
        target = {"V_H": "V_H_mu", "q_L": "q_L_mu", "eta_328": "phi"}.get(row["target"], row["target"])
        z, J = modules[target], modules[row["source"]]
        expected_dual = not z["H_module"].startswith("dual_")
        cat_dual = J["H_module"].startswith("dual_")
        assert typed[row["source"]][1] == expected_dual
        rows.append({"source": row["source"], "target_AST": row["target"], "target_catalog": target,
            "source_grade": [J["canonical_dimension"], J["ghost_number"], int(J["Grassmann_parity"] == "ODD")],
            "field_grade": [z["canonical_dimension"], z["ghost_number"], int(z["Grassmann_parity"] == "ODD")],
            "Lorentz_type": J["Lorentz_type"], "component_dimension": J["real_dimension"],
            "literal_source_indices": src["indices"], "literal_contractions": envelopes,
            "source_left_two_factor_pairing": True, "explicit_Gram_between_source_and_image": False,
            "source_Euler_recovery": "EXACT_FROZEN_IMAGE", "image_AST_sha256": content_hash(recovered),
            "coupling_AST_sha256": row["coupling_sha256"], "indexed_component_pairing": "IDENTITY_EVALUATION",
            "operational_evaluation_map": "J_AST="+row["source"]+"_AST; canonical z_star=(-1)^p J_AST",
            "field_H_module": z["H_module"], "CAT_source_H_module": J["H_module"], "CAT_source_action": J["H_action"],
            "CAT_source_dual_flag": cat_dual, "required_evaluation_dual_flag": expected_dual,
            "INT12_source_dual_flag": typed[row["source"]][1], "INT12_field_dual_flag": typed[row["target"]][1],
            "CAT_INT12_direct_orientation_agrees": cat_dual == typed[row["source"]][1],
            "historical_BV_bracket_repaired": False})
    assert len(rows) == 6
    assert [r["source"] for r in rows if not r["CAT_INT12_direct_orientation_agrees"]] == ["K_q", "L_c"]
    return rows


def coordinate_test():
    _, H, heavy, _ = geometry()
    basis = load("frozen_c3/C3_representation_basis.json")
    cols = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        col = s.zeros(45, 1)
        for item in row["raw_so10_coordinates"]: col[item["index"]] = s.sympify(item["coefficient"])
        cols.append(col)
    frame = s.Matrix.hstack(*cols); G = clean((frame.T*frame)[:12, :12]); inverse = G.inv()
    C = clean(frame.inv()*frame.conjugate())[:12, :12]; dualC = C.inv().T
    assert G*inverse == inverse*G == s.eye(12)
    assert clean(C*C.conjugate()) == s.eye(12)
    assert clean(G*C-dualC*G.conjugate()) == s.zeros(12)
    assert clean(C.T*G*C-G.conjugate()) == s.zeros(12)
    wrong = []; counts = {"identity_evaluation": 0, "carrier_Gram": 0, "inverse": 2, "conjugation": 3}
    for a, M in enumerate(H):
        assert clean((-M.T).T+M) == s.zeros(12); counts["identity_evaluation"] += 1
        assert clean(M.T*G+G*M) == s.zeros(12); counts["carrier_Gram"] += 1
        residual = clean(M.T+M)
        wrong.append({"generator": a, "residual": matrix_record(residual)})
    first = next([r["generator"], *entry] for r in wrong for entry in r["residual"]["entries"])
    assert first == [0, 4, 4, "-sqrt(2)*I"]
    # The two tensor indices are evaluation source / primal image slots;
    # this is even Lie covariance, not an odd-source Leibniz convention.
    e = s.eye(12)[:, 4]
    assert (e.T*s.eye(12)*e)[0] == 1 and (e.T*G*e)[0] == 0
    scalar = load("frozen_scalar_adapter_v2/SA10_physical_actions.json")
    scalar_dim = scalar["physical_H_parent"][0]["shape"][0]; assert scalar_dim == 328
    for M in heavy: assert (-M.T).T+M == s.zeros(33) and M.T+(-M.T) == s.zeros(33)
    # The four other roles have explicit contragredient / double-dual recipes;
    # this is a recipe-level check, not revalidation of every scalar expression.
    return {"H_gram": matrix_record(G), "inverse": matrix_record(inverse), "primal_conjugation": matrix_record(C),
        "evaluation_dual_conjugation": matrix_record(dualC), "checks": counts,
        "wrong_direct_primal_delta_pairing": wrong, "first_nonzero_component": first,
        "witness_roles": ["K_q", "L_c"], "witness_definition": "N^T+M with N=M=ad_H in the same component basis",
        "correct_evaluation_rule": "N=-M^T; pairing matrix I",
        "conditional_carrier_rule": "J=G_H k, N=M; pairing matrix G_H; fields unchanged",
        "conditional_induced_even_field_bracket": matrix_record(inverse.T),
        "conditional_induced_odd_field_bracket": matrix_record(-inverse.T),
        "conditional_coupling_difference": {"source_index": 4, "image_index": 4, "literal_delta_coefficient": "1", "Gram_inserted_coefficient": "0"},
        "historical_component_bridge_bound": False, "conditional_map_adopted": False,
        "ordinary_derivative_rule": "constant even P commutes with every ordinary derivative; no new jets or quotient",
        "scalar_scope": "328-coordinate source grade/duality inventory; scalar actions reused, not regenerated",
        "direct_identification_refuted_not_every_possible_decoder": True}


def build(stage=lambda name, fn: fn()):
    rows = stage("six_frozen_source_Euler_decodings", inventory)
    coords = stage("actual_H_evaluation_carrier_comparison", coordinate_test)
    triangles = stage("six_physical_source_coordinate_triangles", physical_triangles)
    coords["historical_component_bridge_bound"] = True
    partner_rows = []
    cat = {r["identity"]: r for r in load("frozen_catalog_cat0_cat4/CAT1_module_actions.json")["modules"]}
    typed_roles = load("frozen_int9_int15/INT12_typed_role_maps.json")["role_dictionary"]
    for field, source, n in (("ubar_H", "K_ubar", 33), ("cbar_L", "K_cbar", 12), ("lambda_L", "K_lambda", 12)):
        z = cat[field]
        partner_rows.append({"source": source, "field": field, "components": n,
            "grade": [3-z["canonical_dimension"], -1-z["ghost_number"], int(z["Grassmann_parity"] == "EVEN")],
            "field_CAT_H_module": z["H_module"], "field_INT12_dual_flag": typed_roles[field][1],
            "nonminimal_field_component_semantics_still_require_full_architecture_review": True,
            "pairing_requirement": "evaluation covector of the actual chosen field components; not a name-based primal identification",
            "active": False, "catalog_extension_constructed": False})
    return {"schema": "SOURCE_COMPONENT_DECODER_PREFLIGHT_V1", "disposition": DISPOSITION,
        "source_inventory": rows, "coordinates": coords, "physical_triangles": triangles, "prospective_partners": partner_rows,
        "historical_layer_comparison": {
            "CAT1_top_level_rule": "exact_contragredient_of_the_target_transformation_in_each_source_coupling",
            "light_row_recipes": "primal adjoint for K_q/L_c; not the explicit evaluation dual in the indexed component basis",
            "INT12_rule": "dual columns A_partner^T J_REG7, with primal/dual role tags and raw physical index lowering",
            "factorized_channel_map": "z_phys=P z_channel; J_phys=A_partner^T J_REG7 k_channel; evaluation J_channel=P^T J_phys",
            "channel_map_to_C3_S33_components": "E=F^T P_source, inverse=A_source F^-T; field map T=F_left_inverse P_field; E^T T=P_source^T P_field, computed for all six",
            "same_coordinate_identification": "REFUTED_EXACTLY_FOR_LIGHT_SOURCES",
            "all_possible_source_decoders_ruled_out": False,
            "new_bounded_coordinate_bridge_qualified":True,
            "legacy_implementation_already_applied_this_bridge":False,
            "historical_canonical_operator_repaired":False},
        "joint_domain": {"qualified_control_reused": "frozen_source_domain_transport/primary.json and replay.json",
            "historical_sources_identified_with_control": False, "full_M08_domain_preservation_tested": False,
            "bounded_coordinate_pullback_compatibility": "constant even invertible E commutes with ordinary derivatives; conjugate Q/Tq/iota/Tb together and use induced bracket; identities and joint kernels transported, not raw operations",
            "reason_not_reached": "full interacting M08 action/nonminimal/source domain remains a separate prerequisite",
            "quantum_background_actions_distinct": True, "independent_parameter_then_substitution": True},
        "stop": "BOUNDED_DECODER_COMPLETE_INTERACTING_RECONSTRUCTION_PROPOSAL_ONLY",
        "interacting_reconstruction_proposal_authorized": True, "full_interacting_reconstruction_authorized": False,
        "M08_changed": False, "HB1_C5_authorized": False,
        "cochain_dimensions_computed": False, "external_specialist_review": False,
        "formal_authority": "34/39_UNCHANGED", "finite_C1_GS": None}


if __name__ == "__main__": print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
