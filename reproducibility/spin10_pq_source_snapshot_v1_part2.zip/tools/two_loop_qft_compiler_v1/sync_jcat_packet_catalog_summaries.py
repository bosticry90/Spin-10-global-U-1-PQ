"""Sync earned JCAT12 implementation authority without changing Layer-5 science."""
import sys
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1];BASE=HERE/'m08_independent_replay_package_v1'
sys.path.insert(0,str(BASE))
from jcat_packet_catalog_evidence import OUT,load,NEXT

UTC='2026-10-06T22:53:04Z'


def save(path,obj):
    encoded=json.dumps(obj,indent=2)+'\n'
    if path.read_text(encoding='utf-8')!=encoded:path.write_text(encoded,encoding='utf-8',newline='\n')


def main():
    cp=load(OUT/'JCAT12_checkpoint.json')
    assert cp['joint_catalog_promoted'] and cp['current_blocker']==NEXT
    state,compiler,layer5=(load(p) for p in (ROOT/'project_state.json',HERE/'compiler_status.json',HERE/'layer5_status.json'))
    assert state['state_version'] in (109,110)
    node=state['scaffold']['two_loop_qft_compiler_v1']
    for obj in (compiler,node):
        assert obj['layer5a_execution_progress']=='34_OF_39_ENGINE_27_OF_27'
        assert obj['layer5a_current_result_sha256']==cp['preserved_authority_links']['formal_ledger_sha256']
        assert obj['layer5a_M08']=='BLOCKED' and not obj['layer6_tensor_IBP_reduction_authorized']
        obj['layer5_blocker']=obj['layer5a_M08_BRST_remaining_blocker']=NEXT
        obj['layer5a_M08_C5_checkpoint_sha256']=obj['layer5a_M08_jcat12_checkpoint_sha256']=cp['artifact_sha256']
        obj['layer5a_M08_joint_catalog_promoted']=True
        obj['layer5a_M08_homogeneous_occurrence_realization']='FINAL_DIAGONAL_STATISTICS_APPLIED_AT_JCAT11'
        obj['layer5a_M08_local_operator_dimension']=cp['counts']['final_operator_dimension']
        tag='JCAT12_LOCAL_OPERATOR_CATALOG_PASS_C5_PENDING'
        if tag not in obj['layer5a_M08_implementation_preflight']:obj['layer5a_M08_implementation_preflight']+='_'+tag
    compiler['next_gate']=compiler['layer5a_M08_current_implementation_blocker']=NEXT
    state['state_version']=110;state['updated_utc']=UTC
    active='TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT12_LOCAL_OPERATOR_CATALOG_PROMOTED'
    state['research']['active_physics_calculation']=active
    state['scaffold']['active_focus']=active+'_34_OF_39_LAYER6_UNAUTHORIZED_FINITE_C1_GS_UNCOMPUTED'
    state['scaffold']['last_completed_calculation'].update({
        'calculation':'TWO_LOOP_QFT_COMPILER_V1_M08_JCAT8_JCAT12_PACKET_OPERATOR_CATALOG',
        'completed_utc':UTC,'outcome':cp['status'],
        'result':'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_PACKET_CATALOG_RESULT.md'})
    layer5['blocker']=NEXT
    layer5['M08_C5_checkpoint_sha256']=layer5['M08_jcat12_checkpoint_sha256']=cp['artifact_sha256']
    layer5['M08_joint_catalog_promoted']=True
    layer5['M08_local_operator_dimension']=cp['counts']['final_operator_dimension']
    for path,obj in ((ROOT/'project_state.json',state),(HERE/'compiler_status.json',compiler),(HERE/'layer5_status.json',layer5)):save(path,obj)
    print('JCAT12_SUMMARIES_SYNCED_FORMAL_AUTHORITY_UNCHANGED')


if __name__=='__main__':main()
