# IBS1 valence, degree and mixed-port completeness

For a connected one-loop graph, I=V, and summing vertex valences gives
sum_v(n_v-2)=E_ext. One E cubic is mandatory. For3external fields this
allows E+two cubics or E+one quartic. For4external fields with one KcP cubic
it allows E+KcP+two cubics or E+KcP+one quartic. No higher-valence vertex
can occur. The explicit typed enumeration must still reject bridges,
self-tadpole attachments and incompatible external roles.

Every connected bridgeless unicyclic graph with multiple vertices has
internal degree2 at every vertex: connectivity/1PI requires degree>=2 and
sum internal degrees=2I=2V. Hence it is a cycle, including a two-vertex
double edge when V=2. This supplies an independent complete replay without
reusing the primary's arbitrary internal pairings/edge-deletion test.

For an insertion of dimension5, with E external dimensions sum D_ext and
coefficient mass dimension m, the maximum local ordinary jet degree is
5-D_ext-m. The actual loop counting is
4-sum(edge falloffs)+internal_derivative_count.
Add explicitly attached ordinary external jets; compare both formulas.
Hat derivatives on external physical fields vanish before loop integration.
For cPP the degree budget is1; for KccP it is0. Thus an ordinary external
ghost derivative previously excluded in a KcP pole calculation may survive
in cPP with a degree0 loop kernel. This must be measured, not assumed0.

The actual E insertion has one S port. Since all ordinary matter/source
vertices contain only P and no external S is allowed, every surviving graph
has exactly one PS/SP edge. Its one hatted numerator and the insertion's
one hatted derivative allow a contracted pair. No odd-hat argument removes
that pair. The coefficient can still vanish by actual signs/color identities;
typed support does not decide it. Keep E derivative placements separate.

The physical and GF action domains, couplings, derivative locations and
source conventions are frozen before enumeration. Ordinary backgrounds are
set0 only for these specified targets. No finite amplitude, contact kernel,
counterterm, renormalized source product or multiple-insertion domain is
defined by the inventory. Its purpose is to make the next bounded finite
calculation complete in scope, particularly where nonlinear GF changes it.
