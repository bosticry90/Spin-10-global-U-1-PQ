"""IBS1 independent action profiles and bridgeless unicyclic construction."""
from data import *
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations,product
from functools import lru_cache
import re
for pn,ph in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(pn))==ph,pn
start=begin('replay');dim={'P':s.Rational(3,2),'S':s.Rational(3,2),'K':s.Rational(3,2),'B':1,'x':1,'a':1,'c':1,'L':2,'A':1}
raw=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density'];profiles=Counter();quartic=[];row_grades=[]
patterns=[('x',r'x_(Phi|Sigma|phi|S)_\d+'),('a',r'(bar|ub)\d+'),('L',r'(L|b)\d+'),('B',r'B\d+_[0-3]'),('A',r'A\d+_[0-3]'),('c',r'C\d+')]
@lru_cache(None)
def degree(text):
 co=s.expand(s.sympify(text));g=s.Symbol('g10');parts={};n=0;tmp=co
 while tmp!=0:
  coefficient=s.expand(tmp.subs(g,0)/s.factorial(n))
  if coefficient!=0:parts[n]=coefficient
  tmp=s.diff(tmp,g);n+=1
 assert s.expand(co-sum(g**i*v for i,v in parts.items()))==0;return sorted(parts)
for ordinal,row in enumerate(raw):
 ports=[]
 for name in row['word']:
  base,sep,jets=name.partition('__');assert not sep or re.fullmatch('[0-3]+',jets)
  kind=next(k for k,pattern in patterns if re.fullmatch(pattern,base));ports.append((kind,'b'*len(jets)))
 ports=tuple(sorted(ports));md=4-sum(dim[k]+len(j) for k,j in ports);assert md>=0 and int(md)==md
 grades=degree(row['coefficient']);row_grades.append(grades)
 for gp in grades:profiles[ports,int(md),gp]+=1
 if [k for k,j in ports]==['a','a','c','c']:quartic.append(ordinal)
F=packed(CAL/'canonical_so10_fermion_scalar_vertex_support/census_v3_tables.json.gz');physical=set()
for term,rows in F['physical_profiles'].items():
 for ps,nj,md in rows:
  pp=[[k,''] for k in ps]
  if len(ps)<3:continue # free symbols are resummed, not graph vertices
  assert nj in [0,1]
  if nj:next(row for row in pp if row[0]==('x' if 'x' in ps else 'B'))[1]='b'
  gp=(ps.count('B')-2 if term=='gauge' else ps.count('B')) if term.startswith(('gauge','kinetic_')) else 0
  physical.add((tuple(sorted(tuple(v) for v in pp)),md,gp))
def make(origin,pp,md,gp,yp=0):return {'origin':origin,'ports':[list(v) for v in sorted(pp)],'mass_dimension':md,'g_degree':gp,'Y_degree':yp}
vertices=[]
for origin,entries in [('PHY',physical),('GF',profiles)]:
 for pp,md,gp in entries:
  if len(pp) in [3,4] and 'A' not in [k for k,j in pp]:vertices.append(make(origin,pp,md,gp))
vertices += [make('PPB',[('P',''),('P',''),('B','')],0,1),make('PPx',[('P',''),('P',''),('x','')],0,0,1),make('KCP',[('K',''),('c',''),('P','')],0,1)]
for letter in ['C','P','S']:vertices.append(make('E_'+letter,[(k,'h' if k==('c' if letter=='C' else letter) else '') for k in ['P','S','c']],0,1))
identifier=lambda v:json.dumps([v['origin'],v['ports'],v['mass_dimension'],v['g_degree'],v['Y_degree']],separators=(',',':'))
catalog={identifier(v):v for v in vertices};ec=[k for k in sorted(catalog) if catalog[k]['origin'].startswith('E_')];ks=next(k for k,v in catalog.items() if v['origin']=='KCP');ordinary=[k for k in sorted(catalog) if len(catalog[k]['ports'])==3 and k not in ec+[ks]];four=[k for k,v in sorted(catalog.items()) if len(v['ports'])==4]
prop={tuple(sorted(v)):w for v,w in [(('P','P'),1),(('P','S'),1),(('S','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('a','c'),2)]}
def canonical(labels,external,edges,meta):
 options=[]
 # Canonical target ordering is a type ordering, not the cycle ordering.
 for arrangement in permutations(range(len(labels))):
  vv=[labels[i] for i in arrangement]
  if vv!=sorted(labels):continue
  mapping={a:b for b,a in enumerate(arrangement)}
  ex=sorted((mapping[a],k,j) for a,k,j,no in external)
  ed=[]
  for a,b in edges:ed.append(tuple(sorted([(mapping[a[0]],a[1],a[2]),(mapping[b[0]],b[1],b[2])])))
  options.append(json.dumps([vv,ex,sorted(ed),*meta],separators=(',',':')))
 return min(options)
def cycles(n):
 for tail in permutations(range(1,n)):
  if n>2 and tail[0]>tail[-1]:continue
  yield (0,*tail)
out={}
for target,wanted in [('cPP',['P','P','c']),('KccP',['K','P','c','c'])]:
 result={k:set() for k in ['candidate','external_hat_zero','positive_dimension','UV_convergent']}
 for ee in ec:
  sequences=[(ee,*a) if target=='cPP' else (ee,ks,*a) for a in combinations_with_replacement(ordinary,2)]
  sequences += [(ee,a) if target=='cPP' else (ee,ks,a) for a in four]
  for seq in sequences:
   n=len(seq);ports=[[(i,k,j,no) for no,(k,j) in enumerate(catalog[name]['ports'])] for i,name in enumerate(seq)]
   for choices in product(*[list(combinations(pp,2)) for pp in ports]):
    ext=[p for pp,ch in zip(ports,choices) for p in pp if p not in ch]
    if sorted(k for i,k,j,no in ext)!=sorted(wanted):continue
    for order in cycles(n):
     for flip in product([0,1],repeat=n):
      edge=[(choices[v][flip[v]],choices[order[(idx+1)%n]][1-flip[order[(idx+1)%n]]]) for idx,v in enumerate(order)]
      types=[tuple(sorted([a[1],b[1]])) for a,b in edge]
      if any(t not in prop for t in types):continue
      m=sum(catalog[k]['mass_dimension'] for k in seq);g=sum(catalog[k]['g_degree'] for k in seq);y=sum(catalog[k]['Y_degree'] for k in seq)
      internaljets=sum(len(j) for ch in choices for i,k,j,no in ch);externaljets=sum(len(j) for i,k,j,no in ext);ld=4-sum(prop[t] for t in types)+internaljets
      assert ld+externaljets==5-sum(dim[k] for k in wanted)-m
      cat='external_hat_zero' if any('h' in j for i,k,j,no in ext) else 'positive_dimension' if m else 'UV_convergent' if ld<0 else 'candidate'
      result[cat].add(canonical(list(seq),ext,edge,[ld,externaljets,g,y,m]))
 out[target]={k:sorted(v) for k,v in result.items()}
finish('replay',{'method':'regex_GF_and_authenticated_physical_profiles_with_unicyclic_cycle_construction','vertices':catalog,'GF_profiles':[{'ports':[list(v) for v in pp],'mass_dimension':m,'g_degree':g,'positions':n} for (pp,m,g),n in sorted(profiles.items())],
 'GF_positions':len(raw),'row_grade_orders':row_grades,'homogeneous_GF_components':sum(map(len,row_grades)),'quartic_ghost_ordinals':quartic,'physical_terms':len(F['physical_profiles']),'targets':out,
 'new_loop_integrals':0,'nonzero_amplitudes_measured':False,'source_qS_changed':False,'physical_scheme_adopted':False},start)
