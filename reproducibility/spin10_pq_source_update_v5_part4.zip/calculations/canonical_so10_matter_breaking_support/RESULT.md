# IBS1 result: finite-breaking support requires quartic and external-jet classes

Qualified complete candidate support within the frozen one-loop proper,
mass-independent local insertion domain. Receipt SHA256
ed1596f57675dd7dfc94c10854c6bdd00184157bf875e4821a28b0bca046243f.
State113/authority34of39 unchanged; scientific acceptance NOT_PERFORMED.
Whole investigation active/incomplete. No new loop integral or nonzero
amplitude has been measured by this support calculation.

The actual SMA1 insertion E=qS_hat gives12 candidate typed classes for
external(c,P,P) and32 for external(K,c,c,P). They retain all insertion
derivative placements, compatible mixed matter edges, ghost/vector and
auxiliary channels, coupling grades and ordinary external jets. Counts are
typed supports, not independent diagrams with already nonzero coefficients.
Color/Grassmann identities can reduce them after explicit calculation.

The cPP inventory contains the E insertion on the internal gauge or Yukawa
fermion line, and the external-fermion insertion joined through an ordinary
ghost/vector or mixed ghost/auxiliary loop. The latter ordinary class must
retain the external-ghost derivative profiles: the target allows one ordinary
external jet, even though the old KcP UV-pole target allowed none. The
ordinary gauge group has g^3 order, the auxiliary group g^2 and the Yukawa
internal group gY^2. No missing coefficient was assigned from a Ward target.

The KccP inventory contains insertion-on-fermion-edge source cycles,
cycles where a vector or mixed auxiliary line joins two ghost vertices,
and triangles containing the actual quartic ghost vertex. The quartic
family exists at both g^3 and g^4 after the source/E factors. It cannot be
discarded by importing the familiar linear-gauge source diagrams.
The complete table keeps both PS/SP insertion orientations and distinct
derivative/coupling profiles; it is deliberately not a premature amplitude
or automorphism-weight calculation.

All33092 literal gauge-fixing positions and34 physical action terms are
covered. Exactly100 raw GF coefficients contain multiple powers of g10;
splitting them gives33192 homogeneous coefficient components. The966 raw
quartic-ghost positions give1066 such components. A raw position is not
the same thing as a homogeneous coupling component. Every split reconstructs
its original coefficient exactly; no coefficient or physical g was changed.

Primary parses the physical AST with per-port jets and the literal GF
density, then enumerates all compatible internal pairings and tests
connectedness,one loop and1PI by deleting each edge. Replay uses a separate
GF parser and authenticated physical support, deriving every bridgeless
unicyclic graph as a cycle with two internal ports per vertex. Complete
canonical support sets agree, including exclusions and all zero complements.
Each candidate has exactly one mixed P-S edge; its hatted numerator can
pair with the insertion derivative, so an odd-hat shortcut is invalid.

Exclusions are explicit: cPP has7 physical-external-hat zeros and2
positive-dimension classes; KccP has28 external-hat zeros,6 positive-
dimension classes and18 UV-convergent classes outside the local target.
They are not declarations that arbitrary finite source amplitudes vanish.
Removing BL changes both target inventories; removing quartic ghosts
changes KccP; removing external-ghost derivatives changes cPP. Removing
mixed P-S propagation removes every candidate. The corresponding controls
are insensitive in the other target for stated type/degree reasons.

Original primary failed native1 on its assumption that every full-GF
coefficient had one g-degree. Its frozen source/copy/preparation, full
capture and controller failure are preserved. A complete external diagnostic
retains all100 mixed-grade rows. V2 represents each nonzero polynomial
component separately: Poly coefficients in the primary, repeated derivatives
at g=0 in replay. Both check exact reconstruction. The new gate distinguishes
raw positions from component counts. This is a parser/model-representation
correction, not a weakened scientific condition or relabelled PASS.

Completed primary_v2/replay_v2/verify_v2 native0 in
1.3491394999946351/1.285890200000722/0.04759870000270894s after imports.
2/2/1 samples,max73768960/73568256/393216 private bytes; the verifier's
startup-only sample is not its runtime maximum or a memory peak. Original
failed primary had one startup sample491520bytes, likewise not a peak.
Frozen600s/8GiBsampled/350MiBfloor/16MiB limits respected.43initial61V2
68validationbindings,14source copies. Fresh current-turn E4 executed before
the failed worker, native0 with exits0,0,0,0,0,2; V2 authenticates its reuse,
not a second execution or an old scientific replay. Custodyexit2/seven NOTPASS.

This establishes what must be included in the next finite insertion tests.
The group/action/dimensional premises, old physical support, Python/SymPy
and AI author remain shared. The mixed-grade failure records a genuine
engineering limitation. Agreement of the two inventories is computational
corroboration, not independent scientific confirmation of the model.

Next: calculate the quartic-ghost KccP insertion from the actual966-position
density, full raw ghost Green matrix, source/E charges and mixed PS
propagator. Derive the odd-insertion cumulant and Nambu polarization signs,
keep both coupling orders and transport both external ghosts exactly.
Its finite hatted moment must be integrated independently before comparison
with any symmetry target. Other supported auxiliary/vector/source classes
remain required before a simultaneous nonlinear finite restoration claim.
No full QAP/source product,measure/phase,massive matterC1,E5/A5 or physical
unification is earned. No source qS change, scheme/baseline adoption or
physical rescue fit. All historical exclusions, singlet140% warning,
flavorpause/HB1C5blocks/quartetFAIL/custody2seven remain; old evidence and
scientific authority unchanged.
