"""IBS1 independent inventory, graph witness and finite-degree gate."""
from data import *
from collections import Counter
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['vertices','GF_profiles','GF_positions','quartic_ghost_ordinals','physical_terms','targets']:assert P[key]==R[key],key
assert P['GF_positions']==33092 and P['physical_terms']==34
V=P['vertices'];counts={};families={};controls={};quarticV={k for k,v in V.items() if v['origin']=='GF' and [a for a,j in v['ports']]==['a','a','c','c']}
def connected(edges,n,skip=-1):
 remaining={0};change=True
 while change:
  before=set(remaining)
  for i,(a,b) in enumerate(edges):
   if i==skip:continue
   if a[0] in remaining:remaining.add(b[0])
   if b[0] in remaining:remaining.add(a[0])
  change=before!=remaining
 return len(remaining)==n
def properties(text):
 names,ext,edges,ld,ej,gp,yp,md=json.loads(text)
 return names,ext,edges,ld,ej,gp,yp,md
for target,classes in P['targets'].items():
 counts[target]={k:len(v) for k,v in classes.items()};family=Counter();hasBL=[];hasQ=[];externalC=[]
 for text in classes['candidate']:
  names,ext,edges,ld,ej,gp,yp,md=properties(text);n=len(names)
  assert len(edges)==n and connected(edges,n) and all(connected(edges,n,k) for k in range(len(edges)))
  assert sorted(k for v,k,j in ext)==sorted(['c','P','P'] if target=='cPP' else ['K','c','c','P'])
  assert not any('h' in j for v,k,j in ext) and md==0 and ld>=0
  degree=Counter(a[0] for e in edges for a in e);assert all(degree[i]==2 for i in range(n))
  mixed=[e for e in edges if sorted([e[0][1],e[1][1]])==['P','S']];assert len(mixed)==1
  assert gp==sum(V[k]['g_degree'] for k in names) and yp==sum(V[k]['Y_degree'] for k in names)
  bl=any(sorted([a[1],b[1]])==['B','L'] for a,b in edges);q=any(v in quarticV for v in names);ec=any(k=='c' and j for v,k,j in ext)
  hasBL.append(bl);hasQ.append(q);externalC.append(ec)
  summary=(tuple(sorted(V[k]['origin'] for k in names)),tuple(sorted(''.join(sorted([a[1],b[1]])) for a,b in edges)),gp,yp,ld,ej)
  family[summary]+=1
 assert classes['candidate']
 controls[target]={'removing_BL_changes_classes':any(hasBL),'removing_quartic_ghost_changes_classes':any(hasQ),'removing_external_ghost_derivative_changes_classes':any(externalC),'removing_mixed_PS_eliminates_all':True}
 families[target]=[{'vertices':list(v),'edges':list(e),'g_degree':gp,'Y_degree':yp,'loop_Taylor_degree':ld,'attached_ordinary_external_jets':ej,'typed_classes':num} for (v,e,gp,yp,ld,ej),num in sorted(family.items())]
assert controls['cPP']['removing_BL_changes_classes'] and controls['KccP']['removing_BL_changes_classes']
assert controls['KccP']['removing_quartic_ghost_changes_classes'] and not controls['cPP']['removing_quartic_ghost_changes_classes']
assert controls['cPP']['removing_external_ghost_derivative_changes_classes'] and not controls['KccP']['removing_external_ghost_derivative_changes_classes']
assert len(P['quartic_ghost_ordinals'])==sum(v['positions'] for v in P['GF_profiles'] if [k for k,j in v['ports']]==['a','a','c','c'])
for d in [P,R]:assert d['new_loop_integrals']==0 and not d['nonzero_amplitudes_measured'] and not d['source_qS_changed'] and not d['physical_scheme_adopted']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_CANDIDATE_MATTER_BREAKING_INSERTION_SUPPORT','elapsed_after_imports':time.perf_counter()-start,'GF_positions':P['GF_positions'],'quartic_ghost_density_positions':len(P['quartic_ghost_ordinals']),
 'class_counts':counts,'families':families,'controls':controls,'one_mixed_matter_edge_in_every_candidate':True,'complete_scalar_and_auxiliary_exclusions_retained':True,'new_loop_integrals':0,'nonzero_amplitudes_measured':False,
 'finite_source_QAP_or_full_Slavnov_qualified':False,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
