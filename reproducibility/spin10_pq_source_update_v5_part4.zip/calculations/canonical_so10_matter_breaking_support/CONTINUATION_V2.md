# IBS1 V2: split actual mixed coupling grades without changing coefficients

Original primary exited1 at the full-GF homogeneous-coupling assertion;
no table was produced and replay/verifier were not launched. Its source,
source copy, preparation, full native capture and controller failure remain.
A bounded diagnostic retained all100 mixed-grade raw rows externally.
For example -g10*xi*(3*g10+2)/5 contains grades2 and1. Earlier MSV1's
selected cubic rows were homogeneous; this does not justify extending that
assumption to the quartic action. No physical input or g-power is changed.

V2 records every nonzero homogeneous coupling component separately and
checks exact reconstruction of each original coefficient. Primary uses
Poly coefficients, replay independently uses repeated derivatives at g=0.
Both retain the complete raw-row grade list,966 raw quartic ordinals and
component counts. One raw position may contribute to two grade profiles;
raw-position counts and homogeneous-component counts must not be equated.
The new verifier compares both and checks their relationship explicitly.
This corrects a representation assumption; it does not weaken coverage,
change degree budgets or relabel the failed execution PASS.

New primary_v2/replay_v2/verify_v2,preparer/controller and this record are
frozen as six new sources/copies, retaining the eight original pairs.
Same600s/8GiBsampled/350MiBfloor/16MiB limits, sequential workers and exact
graph/jet/support controls. Authenticate the already completed current-turn
E4 command; no second execution or historical scientific replay. Preserve
any further failure and reassess. Authority34/39 and all protected limits
remain unchanged.
