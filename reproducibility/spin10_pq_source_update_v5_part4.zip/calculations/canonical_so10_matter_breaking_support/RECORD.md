# IBS1: complete candidate support of the actual matter breaking insertion

Previous goal turn PROGRESS: OFK1,YVF1,FYV1 supplied verified finite open-line
inputs and a selected measured current insertion. Whole goal active/incomplete.
Base cc24379ec3d4d9a4fea162cdf2eaa5c4524c304d/main31257 tracked blobs.
Recover actual preflight/Git/processes before computation; no matching workers.

Question: which actual one-loop proper graphs with one SMA1 evanescent
insertion remain for cPP and KccP? Earlier proper KcP UV support is not this
problem. The extra ghost and derivative degree can admit external-ghost
derivatives and quartic ghost terms. The least expensive competent next step
is complete typed support, before calculating or fitting finite coefficients.

Freeze current AGENTS/CHARTER/state113/V517/local/solo rules; SMA1 actual
action/source qS0, SMP1 full PS inverse; actual34-term physical executable,
all33092 literal GF rows; existing FSV1 support and MSV1 source row inventory;
YVF1 direct insertion/free Ward result; FYV1 bounds. Historical dependencies
retain their original manifests/policy; no old input or receipt is rebound.

Targets: one-loop1PI proper insertion graphs with exactly one E=qS_hat
vertex, physical external hats0, mass-independent local Euclidean off-shell
sector, external multisets (c,P,P) and (K,c,c,P). P is the physical Nambu
field,S its auxiliary Gaussian field. They are port roles, not new particles.
No external S or background A. Insertion dimension5, ghost number1; source
K has dimension3/2,gh-1 and vertex KcP with coupling g. Local ordinary
derivative budgets are1 and0 respectively. The insertion's hat derivative
on a physical external port is exactly0. This is not a complete nonlinear
Slavnov/QAP domain theorem or a measured nonzero amplitude.

Retain the three literal SMA1 insertion terms: (dhat c)barS A P,
c barS A dhatP, and -c barP Atilde dhatS, with their common ig/2 and
ordered matrices. The census records derivative location and field roles;
it does not set their relative signs or perform integration by parts. Other
matter vertices are PPB (g),PPx (one Yukawa), and the unique KcP source(g).
There is no ordinary S interaction or matter quartic. Free PP,PS,SP,SS all
fall as momentum^-1; the mixed numerator is hatted. BB and xx fall^-2,
BL/LB fall^-1,C-a falls^-2,LL=0. The single S port therefore forces one
mixed matter edge and must not be identified with a physical external P.

Primary: independently parse the actual physical AST and literal GF rows
with per-port ordinary jets, coefficient dimension and g-degree; add SMA1
matter/source/E roles. Enumerate permitted external attachments and every
compatible internal pairing, then require connectedness,L=1 and1PI after
deleting each edge. Canonicalize identical port/vertex permutations, retain
all derivative/degree exclusions and exact witnesses. Bivalent free terms
are already resummed; positive-dimensional insertions cannot supply this
mass-independent target and remain excluded only in that scope.
Replay: use an independent literal-GF regex parser and authenticated FSV1
physical support; construct bridgeless unicyclic graphs as cycles with
exactly two internal ports per vertex. Use independent cycle order/port
orientations, external multiset extraction and canonical permutation code.
No primary program/table is read. Compare complete canonical support sets.

Acceptance: coverage of all raw GF rows; agreement on complete target
classes/jet/coupling gradings, graph witnesses and zero/excluded profiles;
separate cubic and quartic source channels. Controls remove BL,quartic
ghosts,external-C derivative rows or PS mixing and must report which actual
supports change. No candidate count is a loop coefficient or anomaly count.
Color/Grassmann contractions may still exclude candidates. Shared action,
typed power counting, existing physical support, Python/SymPy/AI authorship
are limitations, not independent scientific confirmation.

Derivation comparator: arXiv2004.14398v2 Sec6.2.2 distinguishes one-loop
source/breaking insertions from ordinary source vertices. Its linear-gauge
diagram disposition cannot remove nonlinear GF auxiliary or quartic terms.
This calculation derives support from this action rather than importing it.
Possible outcomes: complete candidate inventory; additional indispensable
class; mismatch or bounded incompleteness. None promotes E5/A5 or a physical
scheme. After qualification, calculate the most informative unmeasured
class with its actual graded sign and full propagator, not a fitted target.

Freeze eight sources/copies and input hashes before sequential primary/
replay/verifier. Compile prelaunch;600s after imports each,8GiB sampled cap,
350MiB launch floor,16MiB package. Fresh E4 command in this logical goal turn;
no requested expensive historical science replay. Stop at first failure,
retain complete source/capture and version any correction. No agents,
branch/worktree,reset,old evidence edits,publication,push or external action.
Authority34/39 unchanged; flavorpause,HB1/C5blocks,E5/A5 unqualified,
quartetFAIL,physical exclusions/140%singlet warning,custodyexit2/seven persist.
