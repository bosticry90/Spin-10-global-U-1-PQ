"""IBS1 literal action/GF profiles and all compatible internal matchings."""
from data import *
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations
from functools import lru_cache
start=begin('primary');dim2={'P':3,'S':3,'K':3,'B':2,'x':2,'a':2,'c':2,'L':4,'A':2}
def port(k,j=0):return (k,'b'*j)
def ordered(ps):return tuple(sorted(ps))
def typed(n):
 t=n['node']
 if t=='Field':return {(ordered([port('B' if n['name']=='B' else 'x')]),0,0)}
 if t=='Parameter':return {((),int(n['mass_dimension']),int(n['name']=='g10'))}
 if t in ['ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return {((),0,0)}
 if t=='PartialDerivative':
  out=set()
  for ps,m,gp in typed(n['argument']):
   for i,(k,j) in enumerate(ps):out.add((ordered(ps[:i]+((k,j+'b'),)+ps[i+1:]),m,gp))
  return out
 if t=='LocalActionTerm':return typed(n['density'])
 if t in ['LorentzContraction','GroupContraction']:return typed(n.get('expression',n.get('argument')))
 if t=='Add':return set().union(*(typed(v) for v in n['terms']))
 if t=='OrderedProduct':
  out={((),0,0)}
  for q in n['factors']:out={(ordered(a+b),m+n,gp+gq) for a,m,gp in out for b,n,gq in typed(q)}
  return out
 raise AssertionError(t)
action=read(PK/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');physical=set()
for t in action['local_terms']:physical|=typed(t)
assert len(action['local_terms'])==34
def role(word):
 base,*jet=word.split('__');js=''.join(jet);assert all(c in '0123' for c in js)
 if base.startswith('x_'):k='x'
 elif base.startswith(('bar','ub')):k='a'
 elif base.startswith(('L','b')):k='L'
 else:k={'B':'B','C':'c','A':'A'}[base[0]]
 return port(k,len(js))
@lru_cache(None)
def gdegree(co):
 q=s.Poly(s.expand(s.sympify(co)),s.Symbol('g10'));degrees={x[0] for x,c in q.terms()};assert len(degrees)==1;return next(iter(degrees))
gf=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density'];counts=Counter();quartic_ord=[]
for no,row in enumerate(gf):
 pp=ordered([role(v) for v in row['word']]);jj=sum(len(j) for k,j in pp);m2=8-sum(dim2[k] for k,j in pp)-2*jj;assert m2>=0 and m2%2==0
 gp=gdegree(row['coefficient']);counts[pp,m2//2,gp]+=1
 if sorted(k for k,j in pp)==['a','a','c','c']:quartic_ord.append(no)
def vertex(origin,pp,m,gp,y=0):
 return {'origin':origin,'ports':[list(v) for v in ordered(pp)],'mass_dimension':m,'g_degree':gp,'Y_degree':y}
vs=[]
for origin,seq in [('PHY',physical),('GF',counts)]:
 for pp,m,gp in seq:
  if len(pp) in [3,4] and not any(k=='A' for k,j in pp):vs.append(vertex(origin,pp,m,gp))
vs+=[vertex('PPB',[port('P'),port('P'),port('B')],0,1),vertex('PPx',[port('P'),port('P'),port('x')],0,0,1)]
for label,jk in [('E_C','c'),('E_P','P'),('E_S','S')]:vs.append(vertex(label,[(k,'h' if k==jk else '') for k in ['P','S','c']],0,1))
vs.append(vertex('KCP',[port('K'),port('c'),port('P')],0,1))
vid=lambda v:json.dumps([v['origin'],v['ports'],v['mass_dimension'],v['g_degree'],v['Y_degree']],separators=(',',':'))
vd={vid(v):v for v in vs};ids=sorted(vd);cub=[k for k in ids if len(vd[k]['ports'])==3 and not vd[k]['origin'].startswith('E_') and vd[k]['origin']!='KCP'];qua=[k for k in ids if len(vd[k]['ports'])==4];eids=[k for k in ids if vd[k]['origin'].startswith('E_')];kid=next(k for k in ids if vd[k]['origin']=='KCP')
fall={tuple(sorted(a)):b for a,b in [(('P','P'),1),(('S','S'),1),(('P','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('c','a'),2)]}
def match(ps):
 if not ps:yield [];return
 a=ps[0]
 for i,b in enumerate(ps[1:],1):
  if tuple(sorted([a[1],b[1]])) not in fall:continue
  for tail in match(ps[1:i]+ps[i+1:]):yield [(a,b)]+tail
def connected(es,n,omit=-1):
 seen={0}
 while True:
  old=set(seen)
  for i,(a,b) in enumerate(es):
   if i==omit:continue
   if a[0] in seen:seen.add(b[0])
   if b[0] in seen:seen.add(a[0])
  if old==seen:return len(seen)==n
def canon(names,ext,edges,meta):
 best=None
 for p in permutations(range(len(names))):
  if tuple(names[i] for i in p)!=tuple(sorted(names)):continue
  mp={old:new for new,old in enumerate(p)}
  xx=sorted((mp[v],k,j) for v,k,j,idx in ext)
  ee=sorted(tuple(sorted(((mp[a[0]],a[1],a[2]),(mp[b[0]],b[1],b[2])))) for a,b in edges)
  ss=json.dumps([sorted(names),xx,ee,*meta],separators=(',',':'));best=ss if best is None else min(best,ss)
 return best
targets={'cPP':['c','P','P'],'KccP':['K','c','c','P']};out={};raw_pairings=Counter()
for target,want in targets.items():
 groups=[]
 for ei in eids:
  groups += [(ei,*pair) if target=='cPP' else (ei,kid,*pair) for pair in combinations_with_replacement(cub,2)]
  groups += [(ei,q) if target=='cPP' else (ei,kid,q) for q in qua]
 classes={k:set() for k in ['candidate','external_hat_zero','positive_dimension','UV_convergent']}
 for names in groups:
  n=len(names);allp=[(i,k,j,no) for i,name in enumerate(names) for no,(k,j) in enumerate(vd[name]['ports'])]
  for ext in combinations(allp,len(want)):
   if Counter(k for v,k,j,idx in ext)!=Counter(want):continue
   extset=set(ext);internal=[p for p in allp if p not in extset]
   for edges in match(internal):
    raw_pairings[target]+=1
    if len(edges)!=n or not connected(edges,n) or any(not connected(edges,n,skip) for skip in range(len(edges))):continue
    md=sum(vd[v]['mass_dimension'] for v in names);gp=sum(vd[v]['g_degree'] for v in names);yp=sum(vd[v]['Y_degree'] for v in names)
    ej=sum(len(j) for v,k,j,no in ext);dj=sum(len(j) for v,k,j,no in internal);loop=4-sum(fall[tuple(sorted([a[1],b[1]]))] for a,b in edges)+dj
    budget=5-sum(dim2[k] for k in want)/2;assert loop+ej==budget-md
    status='external_hat_zero' if any('h' in j for v,k,j,no in ext) else 'positive_dimension' if md else 'UV_convergent' if loop<0 else 'candidate'
    meta=[loop,ej,gp,yp,md];classes[status].add(canon(names,ext,edges,meta))
 out[target]={k:sorted(v) for k,v in classes.items()}
finish('primary',{'method':'literal_AST_per_port_jets_and_all_internal_pairings_edge_deletion','vertices':vd,'GF_profiles':[{'ports':[list(v) for v in pp],'mass_dimension':m,'g_degree':g,'positions':n} for (pp,m,g),n in sorted(counts.items())],
 'GF_positions':len(gf),'quartic_ghost_ordinals':quartic_ord,'physical_terms':len(action['local_terms']),'targets':out,'compatible_pairings_before_graph_gates':dict(raw_pairings),
 'new_loop_integrals':0,'nonzero_amplitudes_measured':False,'source_qS_changed':False,'physical_scheme_adopted':False},start)
