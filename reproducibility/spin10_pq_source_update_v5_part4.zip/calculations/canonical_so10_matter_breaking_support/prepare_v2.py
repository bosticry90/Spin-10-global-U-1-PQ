"""IBS1 V2 freeze; preserve mixed-grade failure and reconstruct every row."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-breaking-support-v1-2026-10-22')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='cc24379ec3d4d9a4fea162cdf2eaa5c4524c304d'
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
assert read(HERE/'primary_capture.json')['exit_code']==1 and read(HERE/'controller_failure.json')['last_role']=='primary' and not (HERE/'primary_tables.json.gz').exists()
for n in ['CONTINUATION_V2.md','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
for n in ['mixed_grade_diagnostic.json','readiness.jsonl','readiness_stderr.txt']:bind[str(CONTROL/n)]=digest(CONTROL/n)
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'IBS1_CONTINUATION_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'original_primary_native_exit':1,'failure_relabelled_PASS':False,'scientific_coverage_or_resource_limits_weakened':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('IBS1_V2_FROZEN',len(bind),flush=True)
