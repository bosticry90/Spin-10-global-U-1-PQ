"""IBS1 compact input/source freeze before native graph workers."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-breaking-support-v1-2026-10-22');BASE='cc24379ec3d4d9a4fea162cdf2eaa5c4524c304d'
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind={}
def add(p,want=None):
 p=p.resolve();h=sha256(p.read_bytes()).hexdigest()
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V517.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(PK/'export_a10_e5_antighost_vector.py')
add(ROOT/'tools/portable_dh_v1/inputs.json.gz','7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb')
for n in ['frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json','frozen_a10_executable_reconciliation/bindings.json','frozen_a10_executable_reconciliation/validation_receipt.json']:add(PK/n)
manifest=json.loads((PK/'frozen_a10_executable_reconciliation/bindings.json').read_bytes());name='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';assert bind[str((ROOT/name).resolve())]==manifest['byte_sha256'][name]
deps={'canonical_so10_sterile_matter_action':(['ACTION_V1.md','primary_tables.json.gz','validation_receipt.json'],'validation_receipt.json','21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_sterile_massive_propagator':(['RESULT.md','validation_receipt.json'],'validation_receipt.json','53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c'),
 'canonical_so10_fermion_scalar_vertex_support':(['RESULT.md','census_v3_tables.json.gz','validation_receipt_v3.json'],'validation_receipt_v3.json','cd3cce0713743819ff040a9d2c91bb886fbe6f48d747dfe25cd494446d8bf3c6'),
 'canonical_so10_matter_source_vertex_support':(['SUPPORT_PROOF.md','census_tables.json.gz','validation_receipt.json'],'validation_receipt.json','2e612469d2819b99b0c11bab1362a55e02718f049485117a327aac2bc7106f40'),
 'canonical_so10_yukawa_finite_vertex_ward':(['DERIVATION.md','RESULT.md','validation_receipt.json'],'validation_receipt.json','19c30c658e3662845a57026fbeaa0ce9e4a82d779c42eb274b298bcdeb5c20cb'),
 'canonical_so10_finite_yukawa_vertex_comparison':(['RESULT.md','validation_receipt.json'],'validation_receipt.json','080a979c0f86e8f0507ec12c09b68a71f666093af3837807ea770ec09980e467')}
for folder,(names,rn,rh) in deps.items():
 for n in names:add(ROOT/'calculations'/folder/n,rh if n==rn else None)
source=(ROOT/'calculations/canonical_so10_sterile_matter_action/ACTION_V1.md').read_text(encoding='utf-8');assert 'qS=0' in source and '(dhat c^a)' in source and 'Atilde_a hat_gamma dhat S' in source
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31257
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'IBS1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('IBS1_FROZEN',len(bind),'bindings',flush=True)
