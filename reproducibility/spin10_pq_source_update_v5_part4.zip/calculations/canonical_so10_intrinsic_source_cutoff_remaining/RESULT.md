# The complete relative cutoff contribution is now measured

PROGRESS. Both remaining cutoff tensors C2/C3 are calculated and qualified,
then assembled with the previously measured C4 into the complete finite
relative cutoff coefficient for this retained source projection. The
earlier isolated log5 cancellation remains exact. The other known partial
source carriers are nonzero,with two actual ordinary kernels still missing.
No complete Ward restoration or anomaly finding follows.

Goal ACTIVE/INCOMPLETE. State113,authority34/39,E5/A5 OPEN unchanged.
Historical custody exit2/seven NOTPASS. No changed physical parameter,
benchmark,scheme,normalization or foundation. All old evidence is preserved.

## Results

Every tensor has45 auxiliary-source directions,45 ghosts and328 real
scalars:664200 coefficient positions perprobe,including implicit zeros.
Both momentum orientations and both contraction methods agree exactly.

| Probe | C2 nonzero | C3 nonzero | Previously measured C4 |
| --- | ---: | ---: | ---: |
| 0 | 0 | 0 | 0 |
| 1 | 10640 | 10584 | 12432 |

The new tensors retain mixed coupling orders. For example,at(13,13,207),
probe1 has,inside the common hbar/(16pi^2) convention,

    C2 = i sqrt(15) xi^2 (11 g10^4/400 - 3 g10^3/25)
    C3 = i sqrt(15) xi^2 (33 g10^4/400 - 3 g10^3/25).

At the old witness(13,0,137),both C2 and C3 vanish even in probe1. That
selected zero would not have justified dropping either full tensor.

The radial pairs give sum Cn log((n+1)/n),n=2..4. Two exact assembly
methods agree:direct coefficient combinations and integer heat-endpoint
prime valuations. The complete relative cutoff is represented by

    log2: -C2+2 C3-2 C4
    log3:  C2-C3
    log5:  C4,

since the complete free-root C5 group is zero by the qualified SMP lemma.
The actual prime tensors contain13280,10472,12432 nonzero probe1 positions,
respectively;probe0 is zero throughout. Two radial integral formulations
agree beyond65 decimal places,and reversed signs fail. There is no
cutoff shift of chi4 in this heat-pair construction. This does not choose
an absolute finite constant or identify chi4 with b0,kappa or infrared
normalization freedom.

## Complete operands and qualified scope

The five previously excluded multigrade classes return:intrinsic scalar
ghost terms,intrinsic ghost–scalar terms,probe/intrinsic terms,source–
ghost terms and probe/source terms. The latter include both actual BB
source Hessians and aC source densities. Complete ordinary and probe
tangents are taken from actual source G before restriction.

All source-degree0/1/2 G terms are inspected. The12/33 source-quadratic
rows have no ordinary fields and hence no field tangent here;this is an
actual derivative zero,not deletion of source products. Probe1 adds600
rho*C tangent coefficients and296 rho*intrinsic coefficients. The600
nonzero tangent entries yield zero complete C2/C3 root groups;the296-entry
root contributes12128 C3 positions. Nonzero classical support is not the
same as a nonzero summed loop coefficient.

The full source/ghost/scalar derivative structure is preserved. Primary
contracts scalar nodes before left-associated color chains;replay uses
explicit scalar-index accumulation and right association. Paths can have
zero or one internal scalar node;the external scalar can instead reside
in an S0 coefficient. All328 internal scalar coordinates are summed.

The independent full508-coordinate operand representation agrees with
native type blocks for every external index and its implicit zeros.
It has82056/85268 nonzero G0V entries and16612/17571 tangent entries
for probes0/1,at each orientation. The independent RIGHT-source derivative
uses a global Wick-phase count for all external ghost directions.
The new parser uses LEFT-source derivatives and individual source phases.
Both retain source differentiation before restriction.

Actual RSH non-free n2/n3 support maps into the generated words. Probe0
has2/27 raw supported paths represented in8/60 grade-compatible words;
probe1 has9/73 paths represented in12/72 words. These are different
representations. Only previously qualified complete free/scalar-root
groups and abstract-family support zeros are excluded.

Literal508-coordinate quadratic/cubic powers verify40 coefficients at
five triples,both probes and both orientations,with every root group.
The tuple set is(12,12,50),(13,0,137),(13,13,207),(44,44,262),
(44,44,265). These selected checks supplement full tensor comparison;
they are not a separate literal508-coordinate replay of every entry.

## Preserved verification failure

The first RFF2 review FAILED its final control-coverage assertion. All
tensor,operand,source,word-coverage and literal comparisons had passed,
but the bare J reverse-endpoint perturbation was insensitive in every
selected example. Original source,copies,preparation,capture and controller
remain unchanged,and no original qualification receipt exists.

V2 retains those insensitive trials and adds the actual correlated rhoJ
source endpoint and extra-probe-root controls. Correlated source reversal
and vector reversal are sensitive at(12,12,50);extra-root omission at
(13,0,137);width omission at(13,13,207). All change C3. The bare J
control remains explicitly INSENSITIVE in the tested sample domain.
Acceptance still requires sensitive source/root/vector/width tests;no
scientific input,coefficient requirement or physical convention changed.

Shared action,charts,data,coefficient ring,parts of the frontend,
Python/SymPy/runtime and AI authorship remain limits. Method agreement
cannot validate these shared premises. No external scientific validation,
proof-assistant formalization or new empirical connection is claimed.

## Late comparison and scientific consequence

Only after coefficient qualification and complete cutoff assembly was the
authenticated USR5 known partial H read. The following is the algebraic
sum H_known+cutoff in common conventions,not a complete quantum identity:

| Probe1 carrier | Known H | Cutoff | Partial sum nonzero |
| --- | ---: | ---: | ---: |
| chi4 | 10488 | 0 | 10488 |
| log2 | 13080 | 13280 | 10784 |
| log3 | 10296 | 10472 | 10632 |
| log5 | 12432 | 12432 | 0 |

Probe0 is zero in every carrier. All coefficients and implicit zeros are
retained. No unknown quantum coefficient is assigned the negative partial
sum. The remaining intrinsic JL Cx and aCx kernels are still unmeasured;
this comparison is not an anomaly verdict or evidence that they vanish.
The completed cutoff coefficient will be counted exactly once when the
actual missing kernels are available.

The next smallest scientific action is the actual intrinsic JL Cx kernel,
whose qualified inventory has82 profiles(4 two-edge,30 three-edge,48
four-edge),before the466-profile aCx class. Derive a complete ordered
graded-logarithm expression and its Lorentz/reference normalization from
the actual source/gauge/ghost Hessian. Use scalar/color reductions where
justified,with a different contraction/reassociation replay. Do not infer
either kernel from this partial remainder or fit chi4 to force closure.
If a common operator relation reduces both classes,prove it on the actual
action before using it to avoid integration. The already qualified support
excludes abstract scalar-potential and isolated fermion cycles in these
targets;it does not exclude every possible missing quantum premise.

## Domain and execution limits

Original unshifted SMA/CSW/EDS,A0,constant first probes,intrinsicdegree1,
externaljets0,symbolic g10/xi/eta_H. Same Euclidean nonexceptional LOCAL
RELATIVE symbol comparison,not physical scalelessp0,massive/causal vacuum,
absolute connected products or an adopted scheme. The full nonlinear/
intrinsic augmented-source master premise,continuum trace/product
applicability,QAP,measure/global phase,source reality and physical domains
remain open. This complete cutoff contribution does not settle them.

Native primary268.4742s,replay149.1453s afterimports;review V2 39.8187s;
assembly4.4963s;late partial sum5.9274s. Primary approached but did not
exhaust the300s bound. Right association was materially less costly;future
calculations should reuse that evidence instead of increasing limits.
Largest sampled private allocation657903616B before final review;sampling
is not continuous peak measurement. Limits300s native/180s review,8GiB
sampled private,350MiB available-pagefile launch floor,32MiB retained
unchanged. Packet about2.1MB before this report/final review.

A preliminary rg query named a missing run_integration.py;file inventory
found the actual run_integrate.py. The warning is preserved externally;
no scientific input or protected evidence was altered. Full captures,
source copies,preparations and exact hashes are retained. Commands are
run.py,run_validation.py(expected control-coverage failure),
run_validation_v2.py,run_assembly.py and run_partial.py. Exclusive output
creation protects this run;replay in a separate evidence destination.

E5/A5,physical viability and other source/contact/matter-domain obligations
remain open. No flavor/HB1/C5 activation,publication,remote push or protected
promotion is authorized by this bounded result. project_state.json remains
the sole machine-readable scientific authority.
