from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'assembly_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
v=read(O/'validation_receipt_v2.json');assert v['all_C2_C3_coefficients_groups_and_zero_complements_agree']and v['old_Ward_remainder_not_operand'];cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda z:{tuple(q[:-1]):co(q[-1])for q in z};clean=lambda D:{k:v for k,v in D.items()if v};new=[load(O/(role+'_tables.json.gz'))for role in['primary','replay']];ip=read(O/'assembly_inputs.json');old=[load(Path(ip[role]))for role in['C4_primary','C4_replay']];outputs=[]
for probe in range(2):
 C={n:tab(new[0]['results'][probe]['C'][str(n)])for n in[2,3]};C[4]=tab(old[0]['results'][probe]['tensor']);assert C[4]==tab(old[1]['results'][probe]['tensor'])and all(C[n]==tab(new[1]['results'][probe]['C'][str(n)])for n in[2,3]);keys=set().union(*(set(z)for z in C.values()));prime={name:{}for name in['log2','log3','log5']}
 for k in keys:
  c2,c3,c4=(C[n].get(k,0)for n in[2,3,4]);prime['log2'][k]=-c2+2*c3-2*c4;prime['log3'][k]=c2-c3;prime['log5'][k]=c4
 prime={name:clean(D)for name,D in prime.items()};independent={p:defaultdict(lambda:0)for p in[2,3,5]}
 for n,D in C.items():
  for endpoint,sign0 in[(n+1,1),(n,-1)]:
   for p,power in s.factorint(endpoint).items():
    assert p in independent
    for k,v in D.items():independent[p][k]+=sign0*int(power)*v
 assert all(prime['log'+str(p)]==clean(D)for p,D in independent.items());outputs.append({'probe':probe,'prime_basis':{name:[[*k,str(v)]for k,v in sorted(D.items())]for name,D in prime.items()},'C2_C3_C4_nonzero':[len(C[n])for n in[2,3,4]],'zero_completed_positions_per_prime_tensor':664200,'chi4_baseline_not_selected':True})
mp.mp.dps=80;rad=[]
for n in[2,3,4]:
 f=lambda u:(mp.exp(-2*n*u)-mp.exp(-2*(n+1)*u))/u if u else mp.mpf(2);a=mp.quad(f,[0,mp.mpf('.001'),1,mp.inf]);b=mp.quad(lambda z:1/z,[2*n,2*(n+1)]);want=mp.log(mp.mpf(n+1)/n);assert max(abs(a-want),abs(b-want))<mp.mpf('1e-65')and abs(-a-want)>mp.mpf('.3');rad.append({'n':n,'pair_value':str(a),'independent_interval':str(b)})
out={'schema':'RFF3_COMPLETE_RELATIVE_FINITE_CUTOFF_PRIME_TENSORS','results':outputs,'radial_heat_pairs':rad,'coefficient_and_heat_endpoint_prime_assemblies_agree':True,'no_missing_native_kernel_or_Ward_target_operand':True,'full_Ward_QAP_E5_or_physical_promotion':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'assembly_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'nonzero_prime_coefficients_by_probe':[{name:len(D)for name,D in z['prime_basis'].items()}for z in outputs],'two_independent_prime_assemblies_and_radial_rules_pass':True,'full_Ward_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
