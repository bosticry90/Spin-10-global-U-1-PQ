from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-remaining-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for role in['primary','replay']:
  z=read(O/(role+'_capture.json'));assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed'];assert read(O/(role+'_result.json'))['elapsed_after_imports']<300
 D=O.parent/'canonical_so10_intrinsic_source_cutoff_defect';ip={'operand_reviewer':str(O/'operand_review.py'),'RSH_support':str(D/'support_replay_tables.json.gz'),'RSH_classical_helper':str(D/'kernel_v4.py')};assert read(O/'validation_inputs.json')==ip
 for p in [Path(v)for v in ip.values()]+[O/'validation_inputs.json']:b[str(p)]=H(p)
 for n in['VALIDATION_V2_RECORD.md','verify_v2.py','run_validation_v2.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'validation_preparation_v2.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'verify_v2.py')]);dump(O/'verify_v2_capture.json',z);dump(C/'verify_v2_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'validation_receipt_v2.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print(json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'validation_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
