# RFF3: assemble the complete relative cutoff logarithms

Prospective;execute only after RFF2 V2 qualification. Authenticate the
already measured RCC C4 tensor and its qualified receipt,without repeating
its contractions. Combine with the independently qualified C2/C3. Complete
free-root C5=0 is an imported SMP group theorem,not a chosen coefficient.

The cutoff finite term is sum(n=2..4) Cn log((n+1)/n). Compare two exact
assembly methods:explicit prime linear combinations versus factorization
of each integer heat length and addition of its signed endpoint valuation.
Retain all664200 positions/probe and implicit zeros. Verify radial pairs
using two integrations and a sign-reversed negative control. No old partial
Ward H,missing native ordinary kernel or desired cancellation is an input.

Output full relative formal log2/log3/log5 tensors,with no fitted chi4 or
absolute finite constant. This completes the declared symbol cutoff
contribution,not the whole quantum Ward/Slavnov identity. Remaining ordinary
source roots and nonlinear source/master,continuum product and measure
applicability remain separate.180s afterimports,8GiB sampled,350MiB floor,
32MiB packet. Failure preserves sources/outputs and earns no receipt.
