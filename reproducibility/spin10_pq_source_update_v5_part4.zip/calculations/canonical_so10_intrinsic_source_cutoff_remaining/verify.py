from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import ast,json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(role+'_tables.json.gz'))for role in['primary','replay']]
# Load only the authenticated native definitions. The nested RCC prefix is
# also explicitly parameterized for reviewer access to frozen comparators.
p=O/'native.py';src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));prefix='\n'.join(src.splitlines()[:cut-1]);old=".join(src.splitlines()[:cut-1]),str(P),'exec')";assert prefix.count(old)==1;prefix=prefix.replace(old,".join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # frozen independent reviewer'),str(P),'exec')");ns={'__file__':str(p),'__name__':'RFF2_CLASSICAL_REVIEW'};sv=sys.argv;sys.argv=[str(p),'primary'];exec(compile(prefix,str(p),'exec'),ns);sys.argv=sv;ns['timer'].cancel();co=ns['co'];tab=lambda z:{tuple(q[:-1]):co(q[-1])for q in z};counts=[]
for aa,bb in zip(a['results'],b['results']):
 assert aa['probe']==bb['probe']and aa['both_q_orientations_agree']and bb['both_q_orientations_agree']and aa['zero_completed_positions_per_tensor']==bb['zero_completed_positions_per_tensor']==664200
 for n in['2','3']:
  T=tab(aa['C'][n]);assert T==tab(bb['C'][n]);GG={name:tab(z)for name,z in aa['groups'][n].items()};assert set(GG)==set(bb['groups'][n])and all(GG[name]==tab(bb['groups'][n][name])for name in GG);keys=set(T).union(*(set(z)for z in GG.values()))
  for k in keys:assert sum((z.get(k,0)for z in GG.values()),0)==T.get(k,0)
  assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in keys);counts.append({'probe':aa['probe'],'V_length':int(n),'nonzero':len(T),'zero':664200-len(T),'roots':{name:len(z)for name,z in GG.items()}})
for role in['primary','replay']:
 rr=read(O/(role+'_result.json'));p=O/(role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
ip=read(O/'validation_inputs.json');exec(compile(Path(ip['operand_reviewer']).read_text(),ip['operand_reviewer'],'exec'),ns);offset=ns['offset'];operand_positions=[];coverage=[];support=load(Path(ip['RSH_support']));labelmask=lambda grade:sum(bit*v for bit,v in zip([16,2,4,8,32],grade));kn={'B':0,'L':1,'x':2,'C':3,'a':4}
for probe in range(2):
 for q in[1,-1]:
  ops,source_audit=ns['make_all'](probe,q);newV={};newM={}
  for name,blocks in ops.items():
   target=newV if name in ns['vnames']else newM
   for(rk,ck),D in blocks.items():
    for key,v in D.items():target[(offset[rk]+key[0],offset[ck]+key[1],ns['masks'][name])+key[2:]]=v
  oldV,oldM,s2=ns['independent_operands'](probe,q);assert newV==oldV and newM==oldM,('full_classical_operand_mismatch',probe,q);assert s2==[12,33][probe];operand_positions.append({'probe':probe,'q':q,'G0V_nonzero':len(newV),'tangent_nonzero':len(newM),'source2_no_field_tangent_rows':s2})
  if q==-1:continue
  rootnames=[name for name in ops if name not in ns['vnames']];wordsets={n:set(ns['all_words'](rootnames,n))for n in[2,3]};vm={ns['masks'][name]:name for name in ns['vnames']};ct={2:0,3:0}
  for w in support['results'][probe]['words']:
   n=len(w['V_word'])
   if n not in[2,3]:continue
   root=support['M_roots'][w['root_M']];grade=root['grade']
   if root['origin']=='M0'and(sum(grade)==0 or root['ports']==['x','x']):continue
   assert not root['origin'].startswith('ABSTRACT');mask=1|labelmask(grade)
   if root['origin']=='M0':name={9:'MC',33:'MX'}[mask]
   else:name='MR'+str(mask)
   seq=tuple(vm[labelmask(support['V_letters'][v]['grade'])]for v in w['V_word'])+(name,);assert seq in wordsets[n],('uncovered_actual_RSH_word',probe,w);ct[n]+=1
  coverage.append({'probe':probe,'actual_relevant_n2_n3_words':ct,'generated_operator_words':{n:len(v)for n,v in wordsets.items()}});print('STAGE RFF2 all-operands',probe,flush=True)
# Literal selected full508-coordinate calculation uses original classical
# definitions,not the new scalar/color contraction. Every source direction
# in a chosen triple is supplied before constructing the old tangent.
p=Path(ip['RSH_classical_helper']);src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));oldprefix='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # authenticated classical reviewer');assert oldprefix.count('r=13;h=0;ix=137')==1
def model(r,h,i):
 zz={'__file__':str(p),'__name__':'RFF2_LITERAL_MODEL'};sv=sys.argv;sys.argv=[str(p),'primary'];exec(compile(oldprefix.replace('r=13;h=0;ix=137',f'r={r};h={h};ix={i}'),str(p),'exec'),zz);sys.argv=sv;zz['timer'].cancel();return zz
samples={(13,0,137),(13,13,207),(44,44,262)}
for pr in a['results']:
 for n in['2','3']:
  T=tab(pr['C'][n])
  if T:samples.update([min(T),max(T)])
assert len(samples)<=7;checked=[];trials=[];sensitive={name:False for name in['source_reverse_endpoint','vector_reverse_endpoint','omit_BB_width']}
def powers(m,G,V,roots):
 X=m['mm'](G,V);power={(i,i):{0:m['constant'](1)}for i in range(508)};out={}
 for n in range(1,4):
  power=m['mm'](power,X)
  if n>=2:out[n]={name:(-1)**n*m['tr'](m['mm'](power,M))for name,M in roots.items()}
 return out
for r,h,i in sorted(samples):
 m=model(r,h,i)
 for probe in range(2):
  for q in[1,-1]:
   G,V,roots=m['pieces'](probe,q);rr={'MC':roots['M0_diagonal_C'],'MX':roots['M0_xC'],'free_BC':roots['M0_BC'],'free_aL':roots['M0_aL']}
   for mask in[3,11,19]:rr['MR'+str(mask)]={ij:{mask:D[mask]}for ij,D in roots['Mrho'].items()if mask in D}
   zz=powers(m,G,V,rr)
   for n in[2,3]:
    vv=zz[n];assert vv['free_BC']+vv['free_aL']==0;pr=a['results'][probe];gg={name:tab(z)for name,z in pr['groups'][str(n)].items()};assert all(vv[name]==D.get((r,h,i),0)for name,D in gg.items());total=sum(vv.values(),0);assert total==tab(pr['C'][str(n)]).get((r,h,i),0),(r,h,i,probe,q,n);checked.append([r,h,i,probe,q,n,str(total)])
   if probe==1 and q==1:
    for control in sensitive:
     if sensitive[control]:continue
     GG={ij:dict(D)for ij,D in G.items()};VV={ij:dict(D)for ij,D in V.items()}
     if control=='source_reverse_endpoint':
      for(ii,jj),D in VV.items():
       if 45<=ii<90 and 418<=jj<463 and 4 in D:D[4]=-D[4]
     elif control=='vector_reverse_endpoint':
      for(ii,jj),D in VV.items():
       if ii<45 and jj>=463:
        for mask in[2,8]:
         if mask in D:D[mask]=-D[mask]
     else:GG={ij:D for ij,D in GG.items()if not(ij[0]<45 and ij[1]<45)}
     wrong=powers(m,GG,VV,rr);changed=[n for n in[2,3]if sum(wrong[n].values(),0)!=sum(zz[n].values(),0)];sensitive[control]=bool(changed);trials.append({'sample':[r,h,i],'control':control,'sensitive_at_V_lengths':changed})
 print('STAGE RFF2 literal',r,h,i,flush=True)
assert all(sensitive.values()),('insensitive_negative_control_requires_further_test',trials)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_C2_C3_coefficients_groups_and_zero_complements_agree':True,'counts':counts,'full_operand_comparisons_all_external_indices':operand_positions,'actual_RSH_word_coverage':coverage,'literal_full508_selected_coefficients':checked,'sensitive_control_trials':trials,'all_negative_controls_sensitive_somewhere':sensitive,'old_Ward_remainder_not_operand':True,'full_source_master_continuum_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
