from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'partial_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
ip=read(O/'partial_inputs.json');old=load(Path(ip['USR_known_H']));new=load(O/'assembly_tables.json.gz');cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};results=[];assert old['all_source_scalar_positions_per_probe_basis']==664200 and old['remaining_H_quantum_roots']==['intrinsic JL Cx','intrinsic aCx']
for probe in range(2):
 per=[]
 for prior in old['results'][probe]['formal_basis']:
  basis=prior['basis'];known=tab(prior['known_partial_H_with_scalar_source']);cutoff=tab(new['results'][probe]['prime_basis'].get(basis,[]));keys=set(known)|set(cutoff);total={k:known.get(k,0)+cutoff.get(k,0)for k in keys};total={k:v for k,v in total.items()if v};ind=defaultdict(lambda:0)
  for D in[cutoff,known]:
   for k,v in D.items():ind[k]+=v
  assert total=={k:v for k,v in ind.items()if v};assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in keys);per.append({'basis':basis,'known_nonzero':len(known),'cutoff_nonzero':len(cutoff),'partial_sum_nonzero':len(total),'partial_sum':[[*k,str(v)]for k,v in sorted(total.items())],'zero_completed_positions':664200})
 results.append({'probe':probe,'formal_basis':per,'two_native_quantum_root_families_unmeasured':True})
out={'schema':'RFF4_KNOWN_PARTIAL_SOURCE_H_PLUS_MEASURED_CUTOFF','results':results,'unknown_kernels_not_assigned_or_fitted':True,'full_Ward_identity_or_anomaly_verdict':False,'chi4_b0_kappa_IR_not_fixed_or_identified':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'partial_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'known_cutoff_partial_nonzero_by_probe_basis':[[[z['basis'],z['known_nonzero'],z['cutoff_nonzero'],z['partial_sum_nonzero']]for z in pr['formal_basis']]for pr in results],'two_native_root_families_still_unmeasured':True,'full_Ward_or_QAP_E5_or_anomaly_verdict':False},sort_keys=True),flush=True);timer.cancel()
