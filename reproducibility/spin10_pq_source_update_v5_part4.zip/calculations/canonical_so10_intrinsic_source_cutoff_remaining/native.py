from pathlib import Path
from hashlib import sha256
import ast,json
# Reuse only authenticated RCC classical definitions,not its target loop.
P=Path(__file__).resolve().parent.parent/'canonical_so10_intrinsic_source_cutoff_color/native.py';raw=P.read_bytes();prep=json.loads((Path(__file__).resolve().parent/'preparation.json').read_bytes());assert sha256(raw).hexdigest()==prep['input_sha256'][str(P)];src=raw.decode();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='terms'for t in n.targets));exec(compile('\n'.join(src.splitlines()[:cut-1]),str(P),'exec'),globals())
base_make=make
ext.update({'nx':('i',),'nC':('h',),'rhoN':(),'JC':('r','h'),'rhoJ':('r',)});masks.update({'nx':48,'nC':24,'rhoN':18,'JC':12,'rhoJ':6});vnames=['n','rho','J','C','x','nx','nC','rhoN','JC','rhoJ'];offset={0:0,1:45,2:90,3:418,4:463};S0=tab(d['S0']);Z0=tab(d['Z0']);T=d['rho_source_vertices']
def full_mrho(probe,q):
 roots={};audit_counts=Counter();p=audit['physical_G'][probe]
 for gp,w,ci in p['monomials']:
  audit_counts['source_degree_'+str(sum(n in sources for n,I in w))]+=1
  if any(n not in fields and n not in sources for n,I in w):continue
  dg=3-sum((3-(2 if sources[n]in aux else 1))if n in sources else(2 if names[n]in aux else 1)for n,I in w)-sum(len(I)for n,I in w)
  if dg not in[0,1]:continue
  for at,(n,I)in enumerate(w):
   if n not in sources:continue
   output=field(sources[n])
   if output is None:continue
   for j,(nf,J)in enumerate(w):
    if nf not in fields:continue
    inn=field(names[nf])
    if inn is None or any(int(k)!=3 for k in list(I)+list(J)):continue
    rest=[(nn,K)for k,(nn,K)in enumerate(w)if k not in[at,j]];ee={};keep=True
    for nn,K in rest:
     if K:keep=False;break
     if nn in sources and sources[nn]in aux:key,index='r',aux.index(sources[nn])
     elif nn in fields and names[nn]in cs:key,index='h',cs.index(names[nn])
     elif nn in fields and names[nn]in xs:key,index='i',xs.index(names[nn])
     else:keep=False;break
     if key in ee:keep=False;break
     ee[key]=index
    if not keep:continue
    z=-Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in p['coefficients'][ci]])
    for nn,K in w:
     f=sources[nn]if nn in sources else names[nn];v=phase(f)
     if nn in sources:v=pw(v,3)if v in[CI,-CI]else v;v=v*((-1)**(pa[f]+1))
     z=z*v*pw(CI,sum(int(k)==0 for k in K))
    sg=(-1)**((1-pa[sources[n]])*sum(pa[names[nn]]for nn,K in w[:at]));sg*=(-1)**(pa[names[nf]]*sum(pa[names[nn]]for k,(nn,K)in enumerate(w)if k!=at and k>j));z=-sg*z*pw(-CI*q,len(I))*pw(CI*q,len(J));mask=3|(16 if dg else 0)|sum({'r':4,'h':8,'i':32}[k]for k in ee);name='MR'+str(mask);ext[name]=tuple(k for k in['r','h','i']if k in ee);masks[name]=mask;add(roots.setdefault(name,{}),output[0],inn[0],(output[1],inn[1])+tuple(ee[k]for k in ext[name]),z);audit_counts['retained_mask_'+str(mask)]+=1
 return {n:tidy(M)for n,M in roots.items()if tidy(M)},dict(audit_counts)
def make_all(probe,q):
 ops=base_make(probe,q);oldMR=ops.pop('MR');roots,source_audit=full_mrho(probe,q);assert roots.get('MR3',{})==oldMR,'new_full_source_derivative_changes_constant_tangent';ops.update(roots);G={}
 for(i,j),v in dec(E['G0']).items():add(G,i//45,j//45,(i%45,j%45),q*v if i//45!=j//45 else v)
 for i in range(328):add(G,2,2,(i,i),constant(1))
 for i in range(45):add(G,3,4,(i,i),constant(1));add(G,4,3,(i,i),constant(-1))
 raw={n:{}for n in['nx','nC','rhoN','JC','rhoJ']}
 for(a,c,i),v in S0.items():add(raw['nx'],4,3,(a,c,i),v);add(raw['nx'],3,4,(c,a,i),-v);add(raw['nC'],4,2,(a,i,c),v);add(raw['nC'],2,4,(i,a,c),-v)
 for(a,i),v in dec(E['rho'][probe]['direct']).items():add(raw['rhoN'],4,2,(a,i),v);add(raw['rhoN'],2,4,(i,a),-v)
 for(r,h,a,c),v in Z0.items():add(raw['JC'],4,3,(a,c,r,h),v);add(raw['JC'],3,4,(c,a,r,h),-v)
 for r,a,b,v in T[probe]['BB_Hessian_T']:assert 0<=a<90 and 0<=b<90;add(raw['rhoJ'],a//45,b//45,(a%45,b%45,r),co(v))
 for r,a,c,v in T[probe]['aC_density_U']:add(raw['rhoJ'],4,3,(a,c,r),co(v));add(raw['rhoJ'],3,4,(c,a,r),-co(v))
 G=tidy(G)
 for name,M in raw.items():
  out={}
  for(rk,ck),D in tidy(M).items():
   for(gk,gcol),gg in G.items():
    if gcol!=rk:continue
    by=bysecond(gg)
    for key,v in D.items():
     for i,z in by[key[0]]:add(out,gk,ck,(i,key[1])+key[2:],z*v)
  ops[name]=tidy(out)
 return ops,source_audit
def all_words(roots,n):
 words=[]
 for root in roots:
  def choose(used,seq):
   if len(seq)==n:
    if used==63:words.append(tuple(seq)+(root,))
    return
   for name in vnames:
    if not used&masks[name]:choose(used|masks[name],seq+[name])
  choose(masks[root],[])
 return words
def fold(fs,output):
 # Association differs between roles;axes needed by uncontracted factors
 # and all external indices are retained until their final occurrence.
 todo=list(fs)
 while len(todo)>1:
  at=0 if role=='primary'else len(todo)-2;A,aa=todo[at];B,bb=todo[at+1];remaining=todo[:at]+todo[at+2:];needed=set(output).union(*(set(ax)for D,ax in remaining));keep=tuple(dict.fromkeys(x for x in aa+bb if x in needed));Z=join(A,aa,B,bb,keep);todo[at:at+2]=[(Z,keep)]
 D,axes=todo[0];assert set(axes)==set(output);ids=[axes.index(x)for x in output];return {tuple(k[j]for j in ids):v for k,v in D.items()}
def scalar_contract(A,aa,B,bb,output):
 if role=='primary':return join(A,aa,B,bb,output)
 av=defaultdict(list);bv=defaultdict(list);ia=aa.index('s');ib=bb.index('s');out=defaultdict(lambda:0);pick=[(0,aa.index(x))if x in aa else(1,bb.index(x))for x in output]
 for k,v in A.items():av[k[ia]].append((k,v))
 for k,v in B.items():bv[k[ib]].append((k,v))
 for j in range(328):
  for(k,v),(l,w)in product(av[j],bv[j]):out[tuple((k if side==0 else l)[z]for side,z in pick)]+=v*w
 return clean(out)
def calculate_remaining(probe,q):
 ops,audit_source=make_all(probe,q);roots=[name for name in ops if name not in vnames];results={};metas={}
 for n in[2,3]:
  words=all_words(roots,n);spec=Counter();typed=Counter();length=n+1
  for seq in words:
   assert sorted(x for name in seq for x in ext[name])==['h','i','r']
   def walk(at,chosen):
    if at==length:
     if chosen[-1][1]!=chosen[0][0]:return
     nodes=[b[0]for b in chosen];assert nodes.count(2)<=1,('uncovered_multiple_scalar_nodes',seq,nodes);items=tuple(zip(seq,chosen));sg=sign(seq)*(-1)**par[nodes[0]]*((-1)**n);root=seq[-1]
     if 2 in nodes:
      k=nodes.index(2);ind=items[(k-1)%length];outd=items[k];chain=tuple(items[(k+j)%length]for j in range(1,length-1));key=(root,'scalar',ind,outd,chain)
     else:
      cycle=min(items[j:]+items[:j]for j in range(length));key=(root,'color',cycle)
     spec[key]+=sg;typed[root,nodes.count(2)]+=1;return
    for block0 in ops[seq[at]]:
     if chosen and chosen[-1][1]!=block0[0]:continue
     walk(at+1,chosen+[block0])
   walk(0,[])
  yc={};pc={};groups={root:defaultdict(lambda:0)for root in roots};largest=0
  for key,mult in sorted(spec.items()):
   if not mult:continue
   root,kind0=key[:2]
   if kind0=='scalar':
    ind,outd,chain=key[2:];yk=(ind,outd)
    if yk not in yc:
     na,ba=ind;nb,bb=outd;axes=('a','b')+tuple(x for x in['r','h','i']if x in ext[na]+ext[nb]);yc[yk]=(scalar_contract(ops[na][ba],('a','s')+ext[na],ops[nb][bb],('s','b')+ext[nb],axes),axes)
    Y,ya=yc[yk]
    if chain not in pc:
     nodes=['b']+[f'c{j}'for j in range(len(chain)-1)]+['a'];fs=[(ops[name][block0],(nodes[j],nodes[j+1])+ext[name])for j,(name,block0)in enumerate(chain)];axes=('b','a')+tuple(x for x in['r','h','i']if any(x in ext[name]for name,block0 in chain));pc[chain]=(fold(fs,axes),axes)
    PP,pp=pc[chain];Z=join(PP,pp,Y,ya,('r','h','i'));largest=max(largest,len(Y),len(PP),len(Z))
   else:
    cycle=key[2]
    if cycle not in pc:
     fs=[(ops[name][block0],(f'v{j}',f'v{(j+1)%length}')+ext[name])for j,(name,block0)in enumerate(cycle)];pc[cycle]=(fold(fs,('r','h','i')),('r','h','i'))
    Z,zz=pc[cycle];largest=max(largest,len(Z))
   for k,v in Z.items():groups[root][k]+=mult*v
  groups={root:clean(D)for root,D in groups.items()};total=defaultdict(lambda:0)
  for D in groups.values():
   for k,v in D.items():total[k]+=v
  total=clean(total);results[n]=(total,groups);metas[n]={'operator_words':len(words),'typed_cycles':[[list(k),v]for k,v in sorted(typed.items())],'descriptors':len(spec),'nonzero_descriptor_weights':sum(bool(v)for v in spec.values()),'largest_contracted_table':largest,'scalar_tables':len(yc),'color_tables':len(pc),'root_nonzero_entries':{name:sum(len(v)for v in ops[name].values())for name in roots},'actual_G_source_audit_before_restriction':audit_source};print('STAGE RFF',role,probe,q,n,len(total),json.dumps(metas[n],sort_keys=True),flush=True)
 return results,metas
def encode(D):return [[*k,str(v)]for k,v in sorted(D.items())]
results=[]
for probe in range(2):
 aa=[]
 for q in[1,-1]:z,meta=calculate_remaining(probe,q);aa.append(z)
 assert aa[0]==aa[1],'opposite momentum tensors differ';results.append({'probe':probe,'C':{str(n):encode(z[0])for n,z in aa[0].items()},'groups':{str(n):{name:encode(D)for name,D in z[1].items()}for n,z in aa[0].items()},'metadata':meta,'both_q_orientations_agree':True,'zero_completed_positions_per_tensor':664200})
out={'schema':'RFF1_COMPLETE_TWO_THREE_VERTEX_INTRINSIC_CUTOFF_TENSORS','role':role,'results':results,'full_actual_source_derivatives_before_restriction':True,'known_quantum_Ward_remainder_not_operand':True,'complete_quantum_QAP_or_E5_promoted':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'nonzero_C2_C3':[[len(z['C'][str(n)])for n in[2,3]]for z in results],'complete_quantum_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
