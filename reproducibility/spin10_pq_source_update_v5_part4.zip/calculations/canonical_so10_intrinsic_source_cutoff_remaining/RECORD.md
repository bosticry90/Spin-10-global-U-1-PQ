# RFF1: complete remaining two/three-vertex cutoff tensors

Prospective atfb2ea5411c9e094bae8775b871313ca9dce9e23c,V634. Previous
goal turn PROGRESS;fresh preflight clean main,no matching workers,goal
ACTIVE. State113,authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS.
Live AGENTS/charter/solo review/epistemic ladder apply. No agents,branch/
worktree,remote actions,publication,outreach,foundation/scheme/benchmark
adoption,flavor/HB1/C5 activation,protected promotion or state edit.

Question:what are the complete C2/C3 cutoff tensors needed beside the
qualified C4/log5 tensor? Completing only log5 cannot establish the full
finite source relation. Reuse the actual RSH family and RCC factorization,
return every multigrade vertex and all relevant probe tangents. Both
nonzero contributions and exact cancellation are acceptable outcomes;
never assign a value required by the known partial Ward remainder.

Original unshifted SMA/CSW/EDS,A0,constant first probes0/1,intrinsicdegree1,
externaljets0,symbolicg10/xi/eta_H,45x45x328 positions/probe. Same Euclidean
nonexceptional LOCAL RELATIVE symbol and commonhbar/(16pi^2),not physical
scalelessp0,massive/causal vacuum,absolute products or adopted scheme.
chi4,b0,kappa and IR freedom remain distinct and unfixed.

Qualified dependencies:RSH actual complete support and Lorentz pinning,
corrected paired-current endpoints,RCC raw gauge-chart normalization,
SMP principal quadratic source/master premise and complete free-root zero
at every V degree,scalar-only antisymmetric tangent zero. These are finite
symbol/Gaussian premises,not the full nonlinear source master/continuum QAP.
The independent native calculation receives no old quantum remainder.

Restore V grades n,rho,J,C,x,nx,nC,rho*n,JC,rho*J. The last group has
both the actual BB source Hessian and aC source density. Derive all probe
field tangents from the full actual G,retaining source variables before
derivatives;do not silently set them zero. Compare root/word coverage
against the actual RSH inventory. Any additional admissible root discovered
must be retained or cause an explicit scientific incompleteness finding.
Known nonfree roots MC/MX,Mrho constant,rho*C and rho*n are not assumed
to be exhaustive merely because a selected sample used them.

Primary:enumerate every ordered grade-compatible n2/n3 word and typed
cycle;contract a scalar node if present,then left-associate the remaining
color factors. Replay uses separately bound classical inputs,explicit
scalar-index accumulation and right association. The external r,h,i axes
are never summed. Cycles can have zero or one internal scalar node;the
scalar's external index may instead sit in S0. Sum all328 internal scalar
directions. Keep matrix/Grassmann order and both q orientations.

Before qualification,independently compare all scalar/source/current
operands and probe roots with literal RSH classical derivatives at typed
coefficients and implicit zeros. Check actual word coverage,complete
coefficient equality and selected full508-coordinate matrix products;
use source,root and momentum negative controls where sensitive. Do not
reuse a previously selected zero as proof of a full tensor zero. Shared
frontend/action/charts/ring,Python/SymPy and AI authorship remain limits.

Then authenticate C4 and assemble full relative cutoff prime coefficients:
log2=-C2+2C3-2C4,log3=C2-C3,log5=C4,C5=0. Independently verify the radial
heat-pair arithmetic;this is not a new finite normalization. Compare old
partial-source H only after the actual cutoff tensors are independently
qualified. Missing ordinary JL Cx/aCx roots still cannot be discarded.

Sequential300s native/180s review afterimports,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB retained packet. Freeze
sources/copies/inputs before execution. Unexpected support,normalization,
resource exhaustion or missing analytic premise means failed/incomplete
scope;preserve all evidence without fitting or silent limit expansion.
No whole source Ward/QAP/measure/source-reality/E5 promotion follows.
