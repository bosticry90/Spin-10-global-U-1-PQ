from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];control_root=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-remaining-v1-2026-10-25');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();bindings=copies=peak=0
for p in O.glob('*preparation*.json'):
 for f,h in read(p)['input_sha256'].items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
caps={p.name:read(p)for p in O.glob('*capture.json')};assert set(caps)=={'primary_capture.json','replay_capture.json','verify_capture.json','verify_v2_capture.json','assembly_capture.json','partial_capture.json','final_review_capture.json'}
for name,z in caps.items():
 assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and not z['failed_or_incomplete_counted_as_PASS'];peak=max(peak,max(v['private_bytes']for v in z['all_resource_samples']));assert peak<=8*1024**3
 if name in['verify_capture.json','final_review_capture.json']:assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
assert read(O/'final_review_controller_failure.json')['execution_state']=='FAILED'and not(O/'final_review_validation_receipt.json').exists();assert read(O/'validation_controller_failure.json')['execution_state']=='FAILED'and not(O/'validation_receipt.json').exists()and not(O/'validation_controller_failure_v2.json').exists();vr=read(O/'validation_receipt_v2.json');disp=vr['negative_control_sensitivity_disposition'];assert not disp['source_reverse_endpoint']and all(disp[k]for k in['vector_reverse_endpoint','omit_BB_width','correlated_source_reverse_endpoint','omit_extra_probe_roots']);assert vr['all_C2_C3_coefficients_groups_and_zero_complements_agree']and vr['original_insensitive_bare_source_trials_preserved']and len(vr['literal_full508_selected_coefficients'])==40 and not vr['full_source_master_continuum_QAP_or_E5_promoted']
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda z:{tuple(q[:-1]):co(q[-1])for q in z};new=[load(O/(role+'_tables.json.gz'))for role in['primary','replay']];ip=read(O/'assembly_inputs.json');oldC4=[load(Path(ip[k]))for k in['C4_primary','C4_replay']];assembly=load(O/'assembly_tables.json.gz');ip=read(O/'partial_inputs.json');oldH=load(Path(ip['USR_known_H']));partial=load(O/'partial_tables.json.gz');summary=[]
for probe in range(2):
 C={}
 for n in[2,3]:
  C[n]=tab(new[0]['results'][probe]['C'][str(n)]);assert C[n]==tab(new[1]['results'][probe]['C'][str(n)]);gg={name:tab(z)for name,z in new[0]['results'][probe]['groups'][str(n)].items()};assert all(D==tab(new[1]['results'][probe]['groups'][str(n)][name])for name,D in gg.items());keys=set(C[n]).union(*(set(D)for D in gg.values()))
  for k in keys:assert sum((D.get(k,0)for D in gg.values()),0)==C[n].get(k,0)
 C[4]=tab(oldC4[0]['results'][probe]['tensor']);assert C[4]==tab(oldC4[1]['results'][probe]['tensor']);prime={name:defaultdict(lambda:0)for name in['log2','log3','log5']}
 for n,D in C.items():
  for endpoint,sg in[(n+1,1),(n,-1)]:
   for p,power in s.factorint(endpoint).items():
    for k,v in D.items():prime['log'+str(p)][k]+=sg*int(power)*v
 prime={name:{k:v for k,v in D.items()if v}for name,D in prime.items()};assert all(D==tab(assembly['results'][probe]['prime_basis'][name])for name,D in prime.items());cs=[]
 for prior in oldH['results'][probe]['formal_basis']:
  basis=prior['basis'];H0=tab(prior['known_partial_H_with_scalar_source']);cut=prime.get(basis,{});keys=set(H0)|set(cut);total={k:H0.get(k,0)+cut.get(k,0)for k in keys};total={k:v for k,v in total.items()if v};record=next(q for q in partial['results'][probe]['formal_basis']if q['basis']==basis);assert total==tab(record['partial_sum'])and record['partial_sum_nonzero']==len(total);cs.append([basis,len(H0),len(cut),len(total)])
 summary.append({'probe':probe,'C2_C3_C4_nonzero':[len(C[n])for n in[2,3,4]],'prime_nonzero':{name:len(D)for name,D in prime.items()},'partial_known_cutoff_sum_counts':cs})
for role in['primary','replay']:
 rr=read(O/(role+'_result.json'));p=O/(role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
for stem in['assembly','partial']:
 rr=read(O/(stem+'_receipt.json'));p=O/(stem+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<180
assert partial['unknown_kernels_not_assigned_or_fitted']and not partial['full_Ward_identity_or_anomaly_verdict'];e=read(control_root/'e4_full_capture.json');events=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];ex=[q['exit_code']for q in events if q['event']=='step_finished'];assert e['native_exit']==0 and ex==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert not read(control_root/'read_only_lookup_warning.json')['scientific_native_or_PASS'];assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'preparation_bindings_authenticated':bindings,'source_copies_equal':copies,'pre_review_captures':len(caps),'largest_pre_review_private_sample':peak,'original_failed_control_coverage_and_insensitive_trials_preserved':True,'original_final_directory_variable_failure_preserved':True,'full_exact_prime_assembly_and_partial_sum_recomputed':summary,'two_missing_native_kernels_not_assigned':True,'E4_native_exit':e['native_exit'],'E4_step_exits':ex,'custody':'EXIT2_SEVEN_NOTPASS','full_Ward_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
