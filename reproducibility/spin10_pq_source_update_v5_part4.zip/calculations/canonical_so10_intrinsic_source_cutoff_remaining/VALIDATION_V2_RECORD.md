# RFF2 V2: retain insensitive bare-source trials;test correlated source

Original RFF2 native exited1 at the final negative-control coverage
assertion. Exact C2/C3 tensors/groups/zeros,all external-index operands,
RIGHT-source tangents,word coverage and all five selected literal triples
had passed. Bare J reverse-endpoint control was insensitive at every
selected triple. Vector endpoint was sensitive at(12,12,50),width omission
at(13,13,207). No original qualification receipt exists.

Preserve original sources,copies,preparation,complete capture/controller.
The observed insensitivity is not a mathematical failure of the measured
tensors,and is not a sensitive test of that error. V2 retains every original
trial,including those insensitive cases. It adds reversal of the actual
correlated rhoJ ghost-source endpoint (mask6),plus omission of the extra
MR11/MR19 probe-root group. The correlated source control and extra-root
control must be sensitive somewhere in the same bounded literal sample
domain,as must the original vector and width controls. Bare-J insensitivity
remains reported;do not claim it detects that omission in this projection.

All tensor equality,operand,typing,source/quadratic-source,coverage and
literal requirements remain unchanged. No physical input,convention,
normalization or previously qualified matrix is changed. Native outputs
are reused,not re-executed. This is a new frozen review version under the
standing delegation,not a changed old acceptance record.180s/8GiB sampled/
350MiB floor/32MiB packet unchanged. No full Ward/QAP/E5 promotion.
