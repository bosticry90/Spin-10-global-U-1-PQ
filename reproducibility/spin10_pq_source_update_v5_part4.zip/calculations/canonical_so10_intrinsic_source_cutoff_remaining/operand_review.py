from collections import defaultdict
# Executed with the authenticated RFF/RCC coefficient and classical input
# namespace. Full508 coordinates are distinct from native type blocks.
def independent_operands(probe,q):
 F={};GF={};x0=90;c0=418;a0=463
 def put(M,ij,mask,ee,v):
  if v:M[ij+(mask,)+tuple(ee)]+=v
 def oddflat(name,i,j,ee,v):put(F,(i,j),masks[name],ee,v)
 F=defaultdict(lambda:0)
 for(a,i),v in N.items():oddflat('n',a,x0+i,(),v);oddflat('n',x0+i,a,(),v)
 for color,M in enumerate(RR):
  for(j,i),v in M.items():oddflat('x',color,x0+j,(i,),-CI*q*v);oddflat('x',x0+j,color,(i,),CI*q*v)
 for h,M in enumerate(J0):
  for(a,b),v in M.items():
   z=q*v if b<45 else v;oddflat('C',a0+a,b,(h,),z);oddflat('C',b,a0+a,(h,),z if b<45 else-z)
 for(a,b),v in dec(E['rho'][probe]['J']).items():
  z=q*v if b<45 else v;oddflat('rho',a0+a,b,(),z);oddflat('rho',b,a0+a,(),z if b<45 else-z)
 for(r,c,a),v in beta.items():oddflat('J',c0+c,45+a,(r,),-v);oddflat('J',45+a,c0+c,(r,),v)
 for(a,c,i),v in S0.items():oddflat('nx',a0+a,c0+c,(i,),v);oddflat('nx',c0+c,a0+a,(i,),-v);oddflat('nC',a0+a,x0+i,(c,),v);oddflat('nC',x0+i,a0+a,(c,),-v)
 for(a,i),v in dec(E['rho'][probe]['direct']).items():oddflat('rhoN',a0+a,x0+i,(),v);oddflat('rhoN',x0+i,a0+a,(),-v)
 for(r,h,a,c),v in Z0.items():oddflat('JC',a0+a,c0+c,(r,h),v);oddflat('JC',c0+c,a0+a,(r,h),-v)
 for r,a,b,v in T[probe]['BB_Hessian_T']:oddflat('rhoJ',a,b,(r,),co(v))
 for r,a,c,v in T[probe]['aC_density_U']:oddflat('rhoJ',a0+a,c0+c,(r,),co(v));oddflat('rhoJ',c0+c,a0+a,(r,),-co(v))
 FF=clean(F);G={}
 for(i,j),v in dec(E['G0']).items():G[i,j]=q*v if(i<45<=j or j<45<=i)else v
 for i in range(328):G[x0+i,x0+i]=constant(1)
 for i in range(45):G[c0+i,a0+i]=constant(1);G[a0+i,c0+i]=constant(-1)
 # Column accumulation:the full free propagator acts on the literal Hessian.
 gg=defaultdict(list)
 for(i,j),v in G.items():gg[j].append((i,v))
 out=defaultdict(lambda:0)
 for(row,col,*tail),v in FF.items():
  for i,w in gg[row]:out[(i,col,*tail)]+=w*v
 out=clean(out);roots=defaultdict(lambda:0);Aq=defaultdict(lambda:0)
 for(i,h,j),v in qc.items():Aq[i,h,j]+=v;Aq[i,j,h]-=v
 for(i,h,j),v in clean(Aq).items():put(roots,(i,j),9,(h,),v);put(roots,(c0+i,c0+j),9,(h,),v)
 for(i,h,j),v in beta.items():put(roots,(45+i,45+j),9,(h,),v);put(roots,(a0+i,a0+j),9,(h,),v)
 for c,M in enumerate(RR):
  for(i,j),v in M.items():put(roots,(x0+i,c0+c),33,(j,),v)
 # RIGHT-source derivative. Phase is a global count of Wick-rotated
 # auxiliary variables and time components,not a factor-by-factor source
 # inverse phase. Source2 rows are inspected before any projection.
 p=audit['physical_G'][probe];no_field_source2=0
 for gp,w,ci in p['monomials']:
  if any(n not in fields and n not in sources for n,I in w):continue
  js=[at for at,(n,I)in enumerate(w)if n in sources]
  if len(js)>1:
   assert not any(n in fields for n,I in w),'additional_source_dependent_tangent_requires_full_continuation';no_field_source2+=1;continue
  if len(js)!=1:continue
  at=js[0];n,I=w[at];f=sources[n];of=field(f)
  if of is None:continue
  # Only aux/antighost sources can enter this retained target support.
  assert f in aux or f in ants
  countL=sum((sources[nn]if nn in sources else names[nn])in aux for nn,K in w);countB0=sum(names[nn].startswith('B')and names[nn].endswith('_0')for nn,K in w if nn in fields);countT=sum(sum(int(v)==0 for v in K)for nn,K in w);phase0=-pw(-CI,countL)*pw(CI,countB0+countT);base0=Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in p['coefficients'][ci]])*phase0;suffix=sum(pa[names[nn]]for nn,K in w[at+1:]);sg=-(-1)**((1-pa[f])*suffix)
  for j,(nf,J)in enumerate(w):
   if nf not in fields:continue
   inn=field(names[nf]);rest=[(nn,K)for k,(nn,K)in enumerate(w)if k not in[at,j]]
   if inn is None or len(rest)>1 or any(nn in sources or names[nn]not in cs or K for nn,K in rest)or any(int(v)!=3 for v in list(I)+list(J)):continue
   dg=3-sum((1 if sources[nn]in aux else 2)if nn in sources else(2 if names[nn]in aux else 1)for nn,K in w)-sum(len(K)for nn,K in w)
   if dg not in[0,1]:continue
   after=[(nn,K)for k,(nn,K)in enumerate(w)if k>j and k!=at];move=(-1)**(pa[names[nf]]*sum(pa[names[nn]]for nn,K in after));z=sg*move*base0*pw(CI*q,len(J))*pw(-CI*q,len(I));mask=3|(16 if dg else 0)|(8 if rest else 0);ee=(cs.index(names[rest[0][0]]),)if rest else();put(roots,(offset[of[0]]+of[1],offset[inn[0]]+inn[1]),mask,ee,z)
 return out,clean(roots),no_field_source2
