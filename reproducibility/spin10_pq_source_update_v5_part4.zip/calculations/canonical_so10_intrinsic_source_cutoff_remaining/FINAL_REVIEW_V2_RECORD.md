# RFF5 V2: control-directory variable collision

Original final review exited1 after recomputing the complete coefficient,
prime and partial-sum comparisons. Its variable C initially held the
external control directory and was later reused for the coefficient map.
The subsequent E4 capture lookup attempted dict/path division and raised
TypeError. This is an evidence-checker implementation failure,not a
mathematical discrepancy or a resource limit. No original final receipt.

Preserve original source/copy/preparation/capture/controller failure.
V2 renames only the external path variable to control_root,expects both
the original RFF2 control-coverage failure and original final failure,
and rechecks all previous requirements unchanged. Frozen RESULT remains
byte-identical. Scientific inputs,normalizations,acceptance conditions,
180s/8GiB sampled/350MiB floor/32MiB limits remain unchanged. No native
kernel rerun or additional E4 replay is required. No authority promotion.
