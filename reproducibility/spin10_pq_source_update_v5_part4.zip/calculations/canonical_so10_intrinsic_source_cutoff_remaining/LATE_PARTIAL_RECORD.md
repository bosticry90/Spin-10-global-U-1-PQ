# RFF4: late algebraic comparison with the authenticated known partial H

Prospective after RFF2 V2 and RFF3 receipts. Only now read USR5's known
partial source relation,including its measured scalar-source contribution.
It uses the same canonical rho JL Cx positions,common hbar/(16pi^2),
unshifted parameters and formal chi4/log2/log3/log5 basis. The algebraic
sum is H_known + cutoff,using the RSH/RCC sign already checked in log5.

Calculate and preserve this PARTIAL sum coefficientwise at all positions.
It is not the full quantum Ward identity:two native intrinsic JL Cx/aCx
kernels and quantum-product/master/measure applicability remain missing.
Do not use the negative partial sum as an input or fitted value for either
kernel. A nonzero residual is neither an anomaly nor a failure of Spin(10).
This comparison informs the next actual kernel calculation and avoids
counting the completed cutoff term again. chi4 receives no cutoff shift.

Require authenticated old receipts and new assembly,exact addition with
independent coefficient grouping and implicit zeros,and no source/scale/
coupling convention change. Any schema/domain discrepancy leaves the
comparison unqualified. Preserve all coefficients,including zeros.180s
afterimports,8GiB sampled,350MiB floor,32MiB packet;no authority promotion.
