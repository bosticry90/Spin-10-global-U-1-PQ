# RFF2: operand,coverage and tensor qualification

Prospective while RFF1 execution is live;do not run this review until both
natives have terminal successful captures and frozen results. Compare
complete C2/C3 tensor values,groups,opposite-q orientations and implicit
zeros. Counts alone cannot qualify equality. Authenticate all input/output
hashes,copies,execution states and resource bounds.

Use a separate full508-coordinate sparse representation of every classical
G0V block and positive-grade tangent. Assemble all ext-index operands from
the qualified RSH classical definitions,rather than sampling their color
directions. Reconstruct every probe tangent with the independent RIGHT-source
derivative and a global Wick-phase count,retaining ALL external ghost
directions. Check actual source-quadratic G terms before restriction;their
absence of ordinary fields must justify zero field tangent,not a blanket
source deletion. Compare operands and their typed implicit zeros.

Map every relevant actual RSH rooted word into the complete generated
operator-word inventory before interpreting its zero/nonzero tensor.
Exclusions may use only the qualified free/scalar-root group identities
or the already established abstract-family support zero. Compare selected
full508-coordinate quadratic/cubic powers and each positive root group,
including nonzero positions away from the old witness. Use deliberately
incorrect endpoint/root/width controls where the actual coefficients are
sensitive;disclose insensitive cases. They cannot substitute for a missing
domain or a full independent physical derivation.

Shared action/inputs/charts,ring,parts of the frontend and AI authorship
remain limits. No old partial Ward H or required cancellation is an input.
The native operators and their actual coefficients must be qualified before
assembling with previously measured C4. Review180s afterimports,8GiB sampled,
350MiB launch floor,32MiB packet. Failures remain FAILED and cannot overwrite
original outputs or acquire a qualification receipt.
