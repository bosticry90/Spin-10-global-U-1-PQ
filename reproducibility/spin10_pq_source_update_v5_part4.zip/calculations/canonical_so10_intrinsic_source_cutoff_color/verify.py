from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import ast,json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(z):return s.expand(s.sympify(z,locals=loc))
def tab(z):return {tuple(q[:-1]):val(q[-1])for q in z}
a,b=[load(O/(role+'_tables.json.gz'))for role in ['primary','replay']];assert a['all_color_gauge_tangent_from_raw_maps_pass']and b['all_color_gauge_tangent_from_raw_maps_pass'];assert len(a['results'])==len(b['results'])==2;hist=[]
for aa,bb in zip(a['results'],b['results']):
 assert aa['probe']==bb['probe']and aa['both_q_orientations_agree']and bb['both_q_orientations_agree']and aa['zero_completed_positions']==bb['zero_completed_positions']==664200;assert tab(aa['tensor'])==tab(bb['tensor']);assert aa['metadata']==bb['metadata'];tt=tab(aa['tensor']);gg={n:tab(z)for n,z in aa['groups'].items()};assert all(gg[n]==tab(bb['groups'][n])for n in gg);keys=set(tt).union(*(set(z)for z in gg.values()))
 for k in keys:assert s.expand(sum(z.get(k,0)for z in gg.values())-tt.get(k,0))==0
 assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in keys);assert all(s.Poly(v,g).degree()==4 and len(s.Poly(v,g).terms())==1 for z in [tt,*gg.values()]for v in z.values());hist.append({'probe':aa['probe'],'nonzero':len(tt),'zero':664200-len(tt),'roots':{n:len(z)for n,z in gg.items()}})
for role in ['primary','replay']:
 rr=read(O/(role+'_result.json'));blob=(O/(role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==rr['packed_sha256']and sha256(gzip.decompress(blob)).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
# Only import definitions from each authenticated source,never its output loop.
p=O/'native.py';src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='terms'for t in n.targets));new={'__file__':str(p),'__name__':'RCC2_CLASSICAL_FRONTEND_REVIEW'};oldargs=sys.argv;sys.argv=[str(p),'primary'];helper='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # authenticated reviewer has frozen comparators');exec(compile(helper,str(p),'exec'),new);sys.argv=oldargs;new['timer'].cancel()
ip=read(O/'validation_inputs.json');p=Path(ip['RSH_classical_helper']);src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));prefix='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # reviewer uses only frozen classical definitions');assert prefix.count('r=13;h=0;ix=137')==1
def model(r,h,i):
 ns={'__file__':str(p),'__name__':'RCC2_LITERAL_SELECTED_REPLAY'};sv=sys.argv;sys.argv=[str(p),'primary'];exec(compile(prefix.replace('r=13;h=0;ix=137',f'r={r};h={h};ix={i}'),str(p),'exec'),ns);sys.argv=sv;ns['timer'].cancel();return ns
ref=model(13,0,137);offset={0:0,1:45,2:90,3:418,4:463};mr=[]
for probe in range(2):
 for q in[1,-1]:
  out={(offset[rk]+i,offset[ck]+j):val(str(v))for(rk,ck,i,j),v in new['mrho'](probe,q).items()};old=ref['mrho'](probe,q);old={ij:val(str(D[3]))for ij,D in old.items()if 3 in D};assert out==old;mr.append([probe,q,len(out),508*508])
samples={(13,0,137)}
for pr in a['results']:
 for z in pr['groups'].values():
  zz=tab(z)
  if zz:samples.add(min(zz))
 tt=tab(pr['tensor'])
 if tt:samples.add(max(tt))
assert len(samples)<=6;checked=[];controls={}
def fourth(ns,G,V,roots):
 X=ns['mm'](G,V);power={(i,i):{0:ns['constant'](1)}for i in range(508)}
 for _ in range(4):power=ns['mm'](power,X)
 return {name:ns['tr'](ns['mm'](power,M))for name,M in roots.items()}
for r,h,i in sorted(samples):
 ns=ref if(r,h,i)==(13,0,137)else model(r,h,i)
 for probe in range(2):
  pr=a['results'][probe];tt=tab(pr['tensor']);gg={n:tab(z)for n,z in pr['groups'].items()}
  for q in[1,-1]:
   G,V,roots=ns['pieces'](probe,q);values=fourth(ns,G,V,roots);assert values['M0_BC']+values['M0_aL']==0;mapping={'MC':'M0_diagonal_C','MX':'M0_xC','MR':'Mrho'}
   for name,oldname in mapping.items():assert val(str(values[oldname]))==gg[name].get((r,h,i),0),(r,h,i,probe,q,name)
   total=sum(values.values(),0);assert val(str(total))==tt.get((r,h,i),0);checked.append([r,h,i,probe,q,str(total)])
   if(r,h,i,probe,q)==(13,0,137,1,1):
    for control in['source_reverse_endpoint','vector_current_reverse_endpoint','omit_width_BB']:
     W={ij:dict(D)for ij,D in V.items()};GG={ij:dict(D)for ij,D in G.items()}
     if control=='source_reverse_endpoint':
      for(ii,jj),D in W.items():
       if 45<=ii<90 and 418<=jj<463 and 4 in D:D[4]=-D[4]
     elif control=='vector_current_reverse_endpoint':
      for(ii,jj),D in W.items():
       if ii<45 and jj>=463:
        for mask in[2,8]:
         if mask in D:D[mask]=-D[mask]
     else:GG={ij:D for ij,D in GG.items()if not(ij[0]<45 and ij[1]<45)}
     wrong=sum(fourth(ns,GG,W,roots).values(),0);controls[control]={'correct':str(total),'wrong':str(wrong),'sensitive':wrong!=total}
 print('STAGE RCC2 literal',r,h,i,flush=True)
assert all(v['sensitive']for v in controls.values());assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'full_tensor_and_zero_complement_agree':True,'counts':hist,'independent_full508_constant_source_tangent_positions':mr,'literal_full508_selected_coefficients':checked,'actual_sensitive_endpoint_and_width_controls':controls,'all_color_raw_gauge_chart_entries':1674,'known_IAG_N5_not_read':True,'full_Ward_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
