from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-color-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b={}
 for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V633.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/n;b[str(p)]=H(p)
 cp=O.parent/'canonical_so10_intrinsic_full_source_descent/coefficient_ring.py';dump(O/'ring_inputs.json',{'coefficient_ring':str(cp)});b[str(cp)]=H(cp);b[str(O/'ring_inputs.json')]=H(O/'ring_inputs.json')
 D=O.parent/'canonical_so10_source_master_principal_bridge'
 for n in ['PROOF.md','final_review_validation_receipt.json','validation_receipt.json','reduction_validation_receipt.json','reduction_tables_v2.json']:p=D/n;b[str(p)]=H(p)
 dump(O/'operator_inputs.json',{'operator_terms':read(D/'reduction_tables_v2.json')['operator_terms']});b[str(O/'operator_inputs.json')]=H(O/'operator_inputs.json')
 for role in ['primary','replay']:
  p=O.parent/'canonical_so10_intrinsic_source_cutoff_defect'/('kernel_v2_'+role+'_inputs.json.gz');b[str(p)]=H(p);d=load(p);d={k:v for k,v in d.items()if k in ['R','endings','maps','audit','frame','field_maps','xs']};d['endings']={k:v for k,v in d['endings'].items()if k in ['G0','N0','J0','rho']};d['endings']['rho']=[{'J':v['J']}for v in d['endings']['rho']];d['maps']={k:v for k,v in d['maps'].items()if k in ['beta_C_L','qC_CC']};d['audit']={k:v for k,v in d['audit'].items()if k in ['geometry','names','physical_G']};p=O/(role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for p in [O.parent/'canonical_so10_intrinsic_source_cutoff_defect/final_review_validation_receipt.json',O.parent/'canonical_so10_unprobed_source_root_module/operands_validation_receipt.json']:b[str(p)]=H(p)
 for n in ['RECORD.md','native.py','run.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay']:
  z=capture([sys.executable,'-B',str(O/'native.py'),role]);dump(O/(role+'_capture.json'),z);dump(C/(role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300;dump(O/(role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_RCC1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
