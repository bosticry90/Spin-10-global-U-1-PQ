"""VFU1 Gaussian moments and exact common-IR Gamma/Bessel finite parts."""
from data import *
tick=begin('replay');D=s.Symbol('D');eps=s.Symbol('epsilon',positive=True);J=s.symbols('J0:4');Z=s.exp(sum(x*x for x in J)/4);zero=dict.fromkeys(J,0)
moment2=s.diff(Z,J[0],2).subs(zero);b2=sum(s.diff(Z,x,2).subs(zero) for x in J);b4=sum(s.diff(Z,x,2,y,2).subs(zero) for x in J for y in J);bkr=sum(s.diff(Z,x,2,J[0],2).subs(zero) for x in J)
kr=s.factor(moment2/(D/2));bar=s.factor(b2/(D/2));bar4=s.factor(b4/(D*(D+2)/4));barr=s.factor(bkr/(D*(D+2)/4))
u={'GFT:F':2*bar-4*kr,'GFT:L':bar4,'FCV:FF':-12*kr,'FCV:LF':barr-bar,'FCV:FL':barr-bar,'FCV:LL':s.S.Zero,'FAV:F':bar,'FAV:L':barr,'YGV:F':2*kr,'YGV:S':kr}
out=units(u,D);m2=s.Symbol('m2',positive=True);a=s.Symbol('a',positive=True);nl=s.Symbol('n_log');raw=s.gamma(eps)*(4*s.pi/m2)**eps/s.gamma(2-eps);heat=2*s.besselk(0,2*s.sqrt(6*a));hfp=s.expand(s.series(heat,a,0,1).removeO()).subs(a,m2)+nl;dfp=s.expand(s.series(raw,eps,0,1).removeO()-1/eps);chi=1+s.log(16*s.pi)-nl
for tag,v in u.items():
 dim=s.expand(s.series(v.subs(D,4-2*eps)*raw,eps,0,1).removeO()-v.subs(D,4)/eps);h=v.subs(D,4)*hfp
 value=s.simplify(s.expand_log(dim-h,force=True)-chi*v.subs(D,4)-s.log(s.Rational(3,2))*v.subs(D,4));assert value==s.sympify(out[tag]['fixed'])
 out[tag]['integral_derived_fixed']=str(value)
finish('replay',{'method':'barred_Gaussian_rank_moments_and_exact_Gamma_Bessel_IR_completed_integrals','units':out,'moments':{'k_r_slash':str(kr),'barQ':str(bar),'barQ_squared':str(bar4),'barQ_k_r_slash':str(barr)},'scalar_dim_finite':str(dfp),'scalar_heat_finite':str(hfp),'common_scalar_relative':str(s.expand_log(dfp-hfp,force=True)),'auxiliary_IR_mass_cancels':not s.simplify(dfp-hfp).has(m2),'LL_zero_before_integration':True,'positive_heat_power_jet_in_this_zeroth_vertex':False},tick)
