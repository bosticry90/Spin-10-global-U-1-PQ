# VFU1: finite vertex units from actual critical numerators

Use Q=k²,b=bar_k²,s=bar_slash(k),g_r=bar_gamma_r. The actual marginal
current's critical angular numerators,with old phases/color outside,are

 GFT F:sum_mu g_mu*s*g_r*s*g_mu;
 GFT L:s*s*g_r*s*s;
 FCV FF:sum_mu,nu g_mu*s*g_nu*(2k_r delta_mu,nu
                 -k_mu delta_nu,r-k_nu delta_r,mu);
 FCV LF:s*s*(k_r*s-Q*g_r),FL:(k_r*s-Q*g_r)*s*s;
 FCV LL:exact full k_mu k_nu V_r,mu,nu=0;
 FAV F:s*s*g_r,FAV L:s*s*s*k_r;
 YGV F:-s*g_r*s,YGV S:k_r*s.

The last two use the phase conventions specified in RECORD. Contractions
against a longitudinal VVV leg take place in the full internal Lorentz
space before the physical endpoints. Replacing Q by b there gives the
same pole at4 but a different dimension jet. No finite proof follows from
pole equality. Exact double-longitudinal cancellation uses total Q in
each contracted index and holds before integration.

Angular averages use D(D+2)... in denominators with barred rank4. An
independent barred Gaussian generating function exp(J²/4) gives moments
<b>=4/D,<k_r s>=g_r/D,<b*k_r*s>=6g_r/[D(D+2)],
<b²>=24/[D(D+2)]. Clifford contractions provide the indicated ordered
spin matrices; no full-dimensional spinor trace or family multiplicity
is substituted. Tensor matrices proportional to g_r must agree at every
zero and nonzero matrix position,not just a scalar trace.

For a unit u_D its complete local critical symbol is u_D/Q². All actual
words have three edges F G F,so the flat heat factor is exp(-6tQ).
There is no external Taylor jet in this zeroth-derivative marginal vertex.
Introduce the SAME auxiliary exp(-m²/Q) in both integrals. In16pi² units,

 I_dim(D)=u_D*(4pi)^epsilon*Gamma(epsilon)
             *(m²)^(-epsilon)/Gamma(2-epsilon), D=4-2epsilon;
 I_heat(4)=2*u_4*K0(2sqrt(6t*m²)).

The latter follows by substitution in the positive proper-time Bessel
integral,not analytic assignment of a scaleless expression. Its small-t
constant is u4*(-2gamma_E-log(6m²)),before adding n_log*u4. The former's
pole is u4/epsilon;its finite part retains -2u'_4. Their difference is

 u4*(chi4+log(3/2))-2u'_4,
 chi4=1+log(16pi)-n_log.

The arbitrary positive m² cancels. Common integrable completions do not
alter this relative UV coefficient. This proves a critical local unit
conversion for the specified formal flat heat member. It does not prove
the physical nonexceptional vertex or complete connected-product domain.
It cannot supply the independently needed chiral p-slot insertion.

After both derivations,compare actual old angular units/poles/placement
records. In particular FCV old tables distinguish barred LF from FULL LF.
Use the full member for the actual numerator and retain their finite
difference as a negative control. Only the subsequently assembled actual
model colors can yield a finite Spin(10) proper vertex;no unknown color
or regulator coefficient is chosen to make an identity vanish.
