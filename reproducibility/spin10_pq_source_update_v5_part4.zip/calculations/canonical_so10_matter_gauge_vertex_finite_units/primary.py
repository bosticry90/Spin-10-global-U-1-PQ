"""VFU1 explicit barred Clifford numerators,all external tensor positions."""
from data import *
from itertools import product
tick=begin('primary');D=s.Symbol('D');k=s.symbols('k0:4');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],m) for m in pa]+[s.kronecker_product(pa[0],s.eye(2))];slash=sum((v*g for v,g in zip(k,gam)),s.zeros(4));b=sum(v*v for v in k)
def avg(z):
 out=0
 for pp,co in s.Poly(s.expand(z),*k).terms():
  if any(p%2 for p in pp):continue
  out+=co*s.prod(s.factorial2(p-1) for p in pp)/s.prod(D+2*j for j in range(sum(pp)//2))
 return s.factor(out)
uu={};checks=0;barredLF=None
for r,g in enumerate(gam):
 ff=sum((gam[mu]*slash*gam[nu]*(2*k[r]*int(mu==nu)-k[mu]*int(nu==r)-k[nu]*int(r==mu)) for mu,nu in product(range(4),repeat=2)),s.zeros(4))
 # Full contractions: k_mu V_r,mu,nu=k_r*k_nu-Q*delta_r,nu.
 # Contracting the remaining full k_nu gives k_r*Q-Q*k_r=0.
 Q=s.Symbol('Q');assert s.expand(k[r]*Q-Q*k[r])==0
 numer={'GFT:F':sum((a*slash*g*slash*a for a in gam),s.zeros(4)),'GFT:L':slash*slash*g*slash*slash,'FCV:FF':ff,'FCV:LF':slash*slash*(k[r]*slash-g),'FCV:FL':(k[r]*slash-g)*slash*slash,'FCV:LL':s.zeros(4),'FAV:F':slash*slash*g,'FAV:L':slash*slash*slash*k[r],'YGV:F':-slash*g*slash,'YGV:S':k[r]*slash}
 for tag,m in numer.items():
  mm=m.applyfunc(avg);v=s.factor(s.trace(g*mm)/4);assert not (mm-v*g).applyfunc(s.simplify).todok();checks+=16
  if r==0:uu[tag]=v
  else:assert s.simplify(v-uu[tag])==0
 control=(slash*slash*(k[r]*slash-b*g)).applyfunc(avg);bv=s.factor(s.trace(g*control)/4)
 if r==0:barredLF=bv
 else:assert s.simplify(bv-barredLF)==0
finish('primary',{'method':'actual_ordered_barred_Clifford_D_sphere_with_full_VVV_longitudinal_contraction','units':units(uu,D),'tensor_positions_checked':checks,'barred_only_LF_control':units({'barredLF':barredLF},D)['barredLF'],'LL_zero_before_integration':True,'positive_heat_power_jet_in_this_zeroth_vertex':False},tick)
