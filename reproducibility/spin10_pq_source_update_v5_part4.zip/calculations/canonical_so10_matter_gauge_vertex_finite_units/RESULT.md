# VFU1: all five proper gauge-vertex critical finite units

Two distinct methods and the separate gate qualify ten critical numerator
units covering the five actual marginal BPP families. This completes the
local unit input; actual Spin(10) finite color tensors are not yet assembled.
It does not qualify a full finite vertex, regulated p response or Slavnov
restoration. Authority34/39/state113 unchanged; acceptance NOT_PERFORMED.

With Gaussian/Wick/color factors stripped exactly as RECORD specifies,
each relative unit is

```
u4*(chi4+log(3/2))+fixed, chi4=1+log(16pi)-n_log.
```

| Unit | u_D | u4 | fixed |
| --- | --- | --- | --- |
| GFT Feynman | 4/D | 1 | 1/2 |
| GFT longitudinal | 24/[D(D+2)] | 1 | 5/6 |
| Cubic-vector FF | -12/D | -3 | -3/2 |
| Cubic-vector LF,FL | -2(2D+1)/[D(D+2)] | -3/4 | -7/24 |
| Cubic-vector LL | 0 | 0 | 0 |
| Auxiliary Feynman | 4/D | 1 | 1/2 |
| Auxiliary longitudinal | 6/[D(D+2)] | 1/4 | 5/24 |
| Yukawa fermion-current | 2/D | 1/2 | 1/4 |
| Yukawa scalar-current | 1/D | 1/4 | 1/8 |

The Yukawa fermion unit strips its old left phase+i;the scalar unit strips
the actual vertex factor2. Their chiral/right phases remain those of YGV1.
These are units,not additional physical interaction strengths. No new
model-color integration,fit,physical input or normalization choice occurs.

Primary derives explicit ordered rank4 barred Clifford numerators in all
four external directions,checking640 tensor positions and zeros. Replay
uses barred Gaussian moments and exact common-IR Gamma/Bessel integrals.
The auxiliary completion exp(-m²/Q),m²>0,is shared by both integrals and
cancels from their relative constant. It is not a physical mass or IR
prescription change. Both retain dimension-dependent sphere normalization.

All actual words have three edges F G F and heatlength6. This zeroth
external-momentum marginal vertex has no positive-power heat Taylor jet;
FHK1's two-point first-momentum correction must not be inserted here.
Late validation checks all nine nonzero angular units against the actual
old GFT/FCV/FAV/YGV calculations,their phases and placement conventions.
No pole coefficient is used to define a new finite unit.

The cubic-vector longitudinal contraction is especially sensitive. Total
Q=k² occurs BEFORE selecting barred spin endpoints. Replacing it by bar_k²
gives the same pole-3/4 but fixed-5/8 instead of-7/24,a difference1/3.
The pole-only FCV result explicitly retained both variants;it is preserved.
PrematureD4 and heatlength4 change all nine nonzero units. The exact LL
zero is insensitive to those controls and remains identified separately.

Full source copies,paired tables,receipt and native captures are retained.
Receipt validation_receipt.json SHA256
7bf0b7055aeccc234086b8d277ecf42bd450fa60f66aead70c78f08f719805a7,
status QUALIFIED_ALL_FIVE_MARGINAL_GAUGE_VERTEX_CRITICAL_FINITE_UNITS.
Primary/replay/gate exit0 in2.0473140/2.8243475/0.9287078s afterimports.
Their2/2/1 memory samples have maxima49,160,192/50,245,632/397,312 bytes.
The gate's sole sample observes launch,not its peak. Manifest counts1236/
1244 and eight source copies are retained.
Frozen600s each,8GiB sampledprivate,350MiB launchfloor,16MiB packet bounds
are respected. No failed scientific worker,gate or controller. This logical
goalturn's LSF E4 audit is authenticated reuse here;new bytepreflight ran.
Historical custody remains exit2/seven NOTPASS. The external control folder
is matter-gauge-vertex-finite-units-v1-2026-10-23.

The next least expensive indispensable calculation is exact-once model
color assembly. Use GFT's distinct Feynman/longitudinal tensors,FCV's three
ordered parts,FAV's two mixed placements with F/L separated,and both YGV
current classes. Sum B45 and the separate A_H12 response under the same
scale/phase convention before comparing any q image. The existing general
family matrices and328 scalar contraction inputs must remain. The nonzero
FHK/PSF p remainder and missing chiral regulator/source-product response
remain independent obligations;do not fit a proper vertex to remove them.

Shared action,spin conventions,data,Python/SymPy and AI author limit the
comparison. This is internal mathematical corroboration,not independent
physical validation. The old metric-dimensional Stokes theorem excludes
the chiral algebra;no automatic extension is claimed. Full products/QAP,
measure/phase,quantum source equivalence,physical chiral prescription,
massiveC1,E5/A5 and physical unification remain unqualified. Bothscalar
warnings,quartetFAIL,flavorpause,HB1/C5 blocks,custody and all independent
finite normalization freedoms remain. Whole investigation ACTIVE/incomplete.
No historical evidence,state,foundation,benchmark or physical scheme was
changed;no agents,branch/worktree,outreach,publication or remote push.
