"""VFU1 small exact critical-unit packet and pole-blind native capture."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('VFU1_PEER_OR_POLE_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_fermion_gauge_fermion_vertex','canonical_so10_fermion_cubic_vector_vertex','canonical_so10_fermion_auxiliary_gauge_vertex','canonical_so10_yukawa_dependent_gauge_vertices'] and p.name.endswith('.gz'):raise PermissionError('VFU1_OLD_POLE_TABLE_DENIED')
 sys.addaudithook(audit);return tick
def units(u,D):return {k:{'u_D':str(s.factor(v)),'pole':str(s.simplify(v.subs(D,4))),'chi4':str(s.simplify(v.subs(D,4))),'log3over2':str(s.simplify(v.subs(D,4))),'fixed':str(s.simplify(-2*s.diff(v,D).subs(D,4)))} for k,v in u.items()}
def finish(role,d,tick):
 d.update({'elapsed_after_imports':time.perf_counter()-tick,'role':role,'heat_length':6,'barred_rank':4,'primitive_families':5,'unit_labels':10,'actual_model_color_contractions_completed':False,'full_regulated_p_insertion_derived':False,'physical_scheme_adopted':False,'full_coupled_restoration_claimed':False,'quantum_coefficient_fitted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
