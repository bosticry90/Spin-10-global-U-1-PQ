"""VFU1 finite-sensitive full-contraction and old-pole comparison."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');D=s.Symbol('D');d=s.Symbol('d')
assert P['tensor_positions_checked']==640 and len(P['units'])==len(R['units'])==10
for tag,unit in P['units'].items():
 for k,v in unit.items():assert s.simplify(s.sympify(v)-s.sympify(R['units'][tag][k]))==0,(tag,k)
 assert R['units'][tag]['integral_derived_fixed']==unit['fixed']
 assert s.simplify(-2*s.diff(s.sympify(unit['u_D']),D).subs(D,4)-s.sympify(unit['fixed']))==0
assert R['auxiliary_IR_mass_cancels']
assert s.simplify(s.sympify(R['common_scalar_relative'])-(1+s.log(24*s.pi)-s.Symbol('n_log')))==0
control=packed(HERE/'validation_control_inputs.json.gz');gft=control['GFT'];fcv=control['FCV'];fav=control['FAV'];ygv=control['YGV']
bindings={'GFT:F':gft['angular_factors'][0][0],'GFT:L':gft['angular_factors'][0][1],'FCV:FF':fcv['angular_factors'][0][0],'FCV:LF':fcv['angular_factors'][0][3],'FCV:FL':fcv['angular_factors'][0][4],'FAV:F':fav['angular_factors'][0][0],'FAV:L':fav['angular_factors'][0][1]}
bindings['YGV:F']=str(s.sympify(ygv['angular_current_factors_fermion'][0][0])/s.I)
bindings['YGV:S']=str(s.sympify(ygv['angular_current_factors_scalar'][0][0])/2)
for tag,v in bindings.items():assert s.simplify(s.sympify(v).subs(d,D)-s.sympify(P['units'][tag]['u_D']))==0,tag
for obj in [gft,fcv,fav]:assert obj['family_extension']=='identity_no_extra3' and not obj['open_line_extra_half'] and obj['new_one_loop_vertex_families']==1
assert ygv['new_one_loop_vertex_families']==2 and not ygv['open_line_extra_half'] and fcv['LL_zero_exact']
actual=P['units']['FCV:LF'];wrong=P['barred_only_LF_control'];assert actual['pole']==wrong['pole']=='-3/4'
assert s.sympify(actual['fixed'])-s.sympify(wrong['fixed'])==s.Rational(1,3)
assert P['units']['FCV:LL']=={'u_D':'0','pole':'0','chi4':'0','log3over2':'0','fixed':'0'}
nonzero=[tag for tag,u in P['units'].items() if u['pole']!='0'];assert len(nonzero)==9 and all(P['units'][tag]['fixed']!='0' for tag in nonzero)
for x in [P,R]:
 assert x['heat_length']==6 and x['barred_rank']==4 and x['primitive_families']==5 and x['LL_zero_before_integration'] and not x['positive_heat_power_jet_in_this_zeroth_vertex']
 assert not any(x[k] for k in ['actual_model_color_contractions_completed','full_regulated_p_insertion_derived','physical_scheme_adopted','full_coupled_restoration_claimed','quantum_coefficient_fitted'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_ALL_FIVE_MARGINAL_GAUGE_VERTEX_CRITICAL_FINITE_UNITS','elapsed_after_imports':time.perf_counter()-tick,'unit_labels':10,'primitive_families':5,'tensor_positions_compared':640,'all_units_and_zero_complements_match':True,'old_actual_angular_units_checked':9,'units':P['units'],'heat_length':6,'barred_rank':4,'auxiliary_IR_mass_cancels':True,'barred_only_VVV_longitudinal_same_pole':True,'full_minus_barred_LF_fixed_difference':'1/3','negative_controls':{'premature_D4_changes_units':9,'heat_length4_loses_nonzero_log_units':9,'LL_zero_case_insensitive':True,'wrong_rank_detected_by_Gaussian_barQ':'4/D','barred_only_LF_fixed':wrong['fixed']},'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','actual_model_color_contractions_completed':False,'full_regulated_p_insertion_derived':False,'physical_scheme_adopted':False,'full_coupled_restoration_claimed':False,'quantum_coefficient_fitted':False,'scientific_authority_changed':False,'primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
