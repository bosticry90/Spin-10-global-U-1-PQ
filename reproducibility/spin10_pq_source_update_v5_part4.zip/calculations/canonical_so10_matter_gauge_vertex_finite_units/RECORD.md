# VFU1: complete marginal proper gauge-vertex critical finite units

Base1eb19411363575ac7f04236c216eea79e47b0140/main32359oldblobs.
FHK1 has derived the kinetic comparison, with a nonzero partial p image.
The older dimensional-Stokes proof explicitly excludes chiral algebras;
its applicability remains open. No regulated p response is inferred here.
Instead calculate the indispensable q-input critical units of all FIVE
actual proper vertex families before any full model color assembly.

Scientific question: derive the finite raw-dimensional-minus-common-scalar
heat local coefficient of each actual marginal BPP numerator. Keep barred
spin rank4, full internal dimensionD, external physical Lorentz index,
all Feynman/longitudinal placements, full VVV longitudinal contractions,
both auxiliary placements and both Yukawa current classes. Couplings,
color products and Gaussian/Wick phases are the previously qualified
ones; units strip those phases and specify their orientation explicitly.
Do not import a pole-only angular approximation as a finite numerator.

Ten unit labels cover GFT F/L;FCV FF/LF/FL/LL;FAV F/L;YGV F/S. For YGV F
strip the actual left fermion phase+i and use positive2/D;for YGV S
strip the scalar vertex factor2 and use1/D. Right phases remain inherited.
No current tensor is calculated, fitted or canonically integrated here.
This is complete critical numerator coverage,not a complete physical
finite vertex or coupled Slavnov theorem. Keep all old coefficient data.

Primary derives each unit from explicit rank4 barred gamma matrices and
D-sphere moments, for all4 external directions. Longitudinal vector
contractions at the VVV vertex use total Q before barred spin endpoints;
Q=1 on the angular sphere. Replay derives the same moments from a barred
Gaussian generating function and evaluates a common-IR-completed radial
integral, including dimension-dependent sphere normalization. All units
have three heat-damped edges,heatlength6. There is no external momentum
or positive-power symbol for a dimension4 BPP counterterm; higher external
Taylor terms have positive inverse dimension and are outside this local
coefficient. Do not use FHK's heat Taylor correction for a zeroth jet.

The IR completion exp(-m²/Q),m²>0 is an AUXILIARY comparison proof,not a
new physical mass/IR scheme. Any two common completions whose difference
is integrable give equal relative UV constants by dominated convergence.
Use exact Gamma/Bessel integrals,not a scaleless integral set tozero.
Keep chi4 and log(3/2) symbolic and distinct from b0,kappa and physical
normalizations. No prescription or parameter value is adopted.

Gate compares complete tensor/zero complements,finite units,pole limits
against actual qualified GFT/FCV/FAV/YGV tables only AFTER computation,
actual phase/placement metadata,and analytic integral constants. Controls:
prematureD4,heat4instead6,LLinsertion,barred-only VVV longitudinal
substitution,wrong physical rank. Preserve insensitive zero cases.
Firstfailure stops;full sources/captures/versioned corrections retained.

Eight sources/copies frozen first. Sequential P/R/gate600s afterimports
each,8GiB sampledprivatecap,350MiB availablecommit floor,16MiB packet.
Honest reuse of THISgoalturn LSF freshE4,new bytepreflight. Preserve main,
state113/34of39,all oldbytes and failures. No agents,branches/worktrees,
physicaladoption,blockedstageactivation,publication,outreach or push.
Shared action,spin conventions,data,Python/SymPy and AI author remain;
two methods are not independent scientists. Full chiral QAP/products/
measure/phase,full coupled restoration,massiveC1,E5/A5 and physical GUT
remain unqualified. Bothscalarwarnings,quartetFAIL,flavorpause,HB1/C5,
custodyexit2sevenNOTPASS and independent normalization freedoms remain.
