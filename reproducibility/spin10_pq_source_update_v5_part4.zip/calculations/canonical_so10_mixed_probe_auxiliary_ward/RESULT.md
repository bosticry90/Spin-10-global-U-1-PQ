# The measured mixed products leave a nonzero relative Ward term

MPA1 qualifies the COMPLETE auxiliary-linear local relative Ward coefficient
for the actual Mlight/Mheavy probe pair. It is nonzero after retaining the
one-probe companions and both field/source Euler legs. This is a measured
regulator-conversion term, not a finding of a physical anomaly or full QAP.

## Exact result

In the literal Euclidean chart, in hbar/(16pi^2) density units and after
removing the ordered rho0*rho1 factor,

 R_Lambda=-g10^2*xi*eta_H^2*log(4/3)*sum_ij Kij JL_i Lambda_j.

K is EXACTLY the previous SPC56-entry rational matrix, not a fitted tensor.
For example K13,13=1/5. All56 old entries match. The native112 monomials are
the two separate formal logarithms log(3/2) and log2 at each physical slot;
they describe56 coefficient positions, not112 new physical quantities.
No a*Lambda, common chi4, rational finite or other coupling/logarithm
component survives in this projected relative Ward expression. Kappa,b0
and IR constants were neither identified nor fixed. The expression is
generically nonzero in the frozen symbolic ring; no gauge/parameter was
chosen to suppress it.

This is the measured combination

 Pi_Lambda[Qp+C01-C10+X_G0 I1-X_G1 I0],

where rho0*rho1*p is the earlier56-position contact, C_rs are ACTUAL mixed
u_r*rho_s comparisons, and I_r are ACTUAL first-probe comparisons. Neither
C_rs nor I_r was assigned from the desired Ward cancellation.

The Qp projection has112 positions (56 JL*Lambda and56 a*Lambda).
Field-only companion variation has112 formal-log/baseline positions;
the source companion has224. These counts include normalization-basis
monomials. Fixed-source omission and omission of the one-probe companions
both change the result. The final a*Lambda and common-baseline pieces cancel
only after all required terms have been retained.

## Coverage and calculation

Two mixed orientations each retain all4050 Lambda*(JL or a) slots. The
two one-probe companions each retain all8100 (Lambda or Ja)*(JL or a) slots.
These are complete carriers of this specified projection before invariance,
not invariant counterterm ranks. The proof in DERIVATION excludes feeds from
unmeasured physical-source, mass, jet and other first-probe terms into this
projection. It does not exclude those terms from other Ward sectors.

The group counts are:

| Coefficient | n2 | n3 | n4 |
|---|---:|---:|---:|
| C01 |0|112|56|
| C10 |0|56|56|
| I0, Ja anchor |0|56|not allowed by grade|
| I0, Lambda anchor |0|56|not allowed by grade|
| I1, Ja anchor |0|0|not allowed by grade|
| I1, Lambda anchor |226|113|not allowed by grade|

Only I1's Lambda-anchor bubble has a nonzero first-D jet:112 positions.
Its finite contribution is retained. Bubble/triangle/box heat lengths4/6/8
remain distinct. The common finite constant is symbolic throughout.

Primary derives QG=U(Q0 seed) from qualified untwisted source columns;
replay applies the actual full raw Q/Euler-source operation to U seed before
transport. Full physical G and QG densities agree. Primary sums all ordered
log words by closed paths; replay uses rooted dressed-inverse sparse products.
Both differentiate before replacing residual ordinary a,Lambda by background
labels. Full643-field principal differentiation proves scalar exclusion in
this saturated sector. It does not set the scalar/nonlocal remainder zero.

The separate verifier uses expanded Fraction/exterior arithmetic, fresh
physical Hessians, complete quadratic Fourier symbols (including off-diagonal
q_mu*q_nu), all groups and a fresh extra transverse dimension. It independently
derives consumed Q columns by Euler differentiation of the actual Euclidean
GF/source action and checks the rho-Hamiltonian cross by direct EVEN Euler
operations. It checks all concrete zero complements and radial shifts.
It does not reconstruct the raw frame/QG a third time. Typed sector selection
and analytic symbol/IR/radial premises remain shared.

Standard-library Fractions then compress BOTH validated native Ward tables
against the OLD SPC tensor, including every coefficient and every absent
component. This is an interpretation audit, not another quantum calculation.

## Verification, resources and limitations

Native times305.208821s and299.378751s after imports. Corrected verifier
178.105487s; compression2.436849s. Native sampled private maxima1068908544
and1078505472 B (156/154 samples); verifier978296832 B (92 samples);
compression606683136 B (3 samples). All600s native/verifier,60s compression,
8GiB sampled memory,350MiB launch floors and16MiB packet caps held. Sampled
maxima are not exact peaks. Preparation bindings50; original validation58;
corrected validation67; compression12. Thirteen exact source snapshots.

The original verifier completed its physical-Hessian and symbolic-shape
comparisons, then failed at an unbound display label `role`. Its source,
capture (exit1,84 samples,max967860224 B) and controller failure remain.
The display-only V2 correction was identified while the immutable original
controller was active; that controller/source was not rewritten. V2 repeats
all checks from the same native arrays. No native failed, no cap expanded,
no original validation receipt exists, and no failed check was relabelled.
This avoidable generation/review error remains an AI workflow limitation.

validation_receipt_v2.json SHA256
d12adeb1808cf870aecd197d8e00bd9b93030dd1e862803676c6a97012976f68.
compression_receipt.json SHA256
c05c6df842c631e9778d35c57247c6f535fd4533a9e657e50aef6093a66f0f46.
Full captures also reside in the matching mixed-probe-auxiliary-ward external
control directory. Controllers are exclusive-write; reproduce historical
bound inputs/policies in a fresh output location, never overwrite/rebind
the sealed evidence. No expensive historical calculation was repeated.

Shared action, reference conventions, source/metric lift, analytic UV/IR
comparison proofs, software and AI authorship remain. These are bounded
internally verified mathematical calculations, not external scientific or
experimental confirmation. No proof-assistant certification is claimed.

## Scientific consequence and next action

The homogeneous Q+d completion in SPC's DESCENT_NOTE is algebraically valid.
The actual mixed coefficients are not that completion by themselves: even
Qp plus their antisymmetric difference is nonzero. The measured one-probe
bracket companions are also indispensable. Varying a coefficient along a
homogeneous degree2 completion cannot erase this relative Ward variation.
This does NOT exclude other admissible finite terms or prove an anomaly.

The correct next question is the actual absolute regulated Ward response,
not another favorable choice of a baseline or a new unrelated tensor table.
NEXT_INSERTION.md specifies the ordered variation/Duhamel target. The heat
breaking and the finite conversion must be compared in their common domain;
neither absolute breaking has been calculated here. Full nonlocal U,
reference/measure/trace defects, other source/physical/jet sectors and contact
admissibility remain explicit. Do not infer the missing response from -R.

No physical scheme, foundation, benchmark, parameter point, state or authority
changed; no flavor/HB1/C5 activation, branch/worktree, agent, push, publication
or outreach. State113/34of39 unchanged; custodyexit2/seven NOTPASS. Old
benchmark exclusions, scalar quantum warning, gauge/massive-fermion matching,
quartet failure and chiral/global/causal/full-QAP/E5/A5 obligations remain.
The whole investigation remains incomplete.
