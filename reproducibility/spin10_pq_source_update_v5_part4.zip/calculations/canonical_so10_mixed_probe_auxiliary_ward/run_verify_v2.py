from pathlib import Path
from hashlib import sha256
import json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/mixed-probe-auxiliary-ward-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
stage='preparation'
try:
 for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
 f=read(O/'verify_capture.json');assert f['exit_code']==1 and not f['calculation_completed'] and "NameError: name 'role' is not defined" in f['stdout_and_stderr']
 for r in ['primary','replay']:assert read(O/(r+'_capture.json'))['calculation_completed']
 assert not (O/'validation_receipt.json').exists()
 old=(O/'verify.py').read_text(encoding='utf-8').replace("'validation_preparation.json'","'validation_preparation_v2.json'").replace("P=json.loads(gzip.decompress","role='verifier'\nP=json.loads(gzip.decompress",1)
 assert old==(O/'verify_v2.py').read_text(encoding='utf-8')
 for n in ['VERIFIER_V2.md','verify_v2.py','run_verify_v2.py']:
  with (O/(n+'.source.txt')).open('xb') as ff:ff.write((O/n).read_bytes())
 b=dict(read(O/'preparation.json')['input_sha256'])
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'validation_preparation_v2.json',{'input_sha256':dict(sorted(b.items())),'only_change':'bound display label plus new manifest path','native_arrays_reused_not_rerun':True})
 stage='verify_v2';c=capture([sys.executable,'-B',str(O/'verify_v2.py')]);dump(O/'verify_v2_capture.json',c);dump(C/'verify_v2_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<600
 dump(O/'validation_receipt_v2.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(O/'controller_failure_v2.json',{'stage':stage,'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
