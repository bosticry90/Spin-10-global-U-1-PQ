"""Actual augmented action: mixed and companion local quantum coefficients."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from collections import defaultdict
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json')
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
   assert Path(os.fsdecode(args[0])).resolve()==O/(role+'_tables.json.gz')
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 extra=['mw_u0','mw_u1','mw_rho0','mw_rho1']+['mw_a'+str(i) for i in range(45)]+['mw_L'+str(i) for i in range(45)]+['mw_q'+str(i) for i in range(4)]+['mw_chi','mw_l32','mw_l2']
 A=Algebra(geo['names']+extra,geo['parities']+[0,0,1,1]+[1]*45+[0]*52)
 u=[A.index['mw_u'+str(i)] for i in range(2)];rho=[A.index['mw_rho'+str(i)] for i in range(2)]
 bg=[A.index['mw_a'+str(i)] for i in range(45)];bl=[A.index['mw_L'+str(i)] for i in range(45)];qs=[A.index['mw_q'+str(i)] for i in range(4)];cs=[A.index[n] for n in ['mw_chi','mw_l32','mw_l2']]
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b}
 dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 @lru_cache(None)
 def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
 def mul(*pp):
  p={(0,()):ONE}
  for q in pp:p=A.product(p,q)
  return p
 def rows(p):return A.rows(p)
 def pack(p):
  cc=[];ix={};mm=[]
  for(g,w),c in sorted(p.items()):
   if c not in ix:ix[c]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in c])
   mm.append([g,[[n,list(j)] for n,j in w],ix[c]])
  return {'coefficients':cc,'monomials':mm,'positions':len(p),'sha256':A.fingerprint(p)}
 def unpack(p,names=None):
  co=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in p['coefficients']];out={}
  for g,w,k in p['monomials']:
   ww,sg=A.canonical(tuple((A.index[names[n]] if names else n,tuple(j)) for n,j in w))
   if sg:put(out,(g,ww),scale_coefficient(co[k],sg))
  return out
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,mp):
  out={}
  for(g,w),c in p.items():
   z={(g,()):c}
   for n,j in w:z=mul(z,DD(mp.get(n,elem(n)),j))
   for k,v in z.items():put(out,k,v)
  return out
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(A.parities[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    sg=(-1)**(A.parities[n]*prefix) if role=='primary' else (-1)**(A.parities[n]*(total-prefix-A.parities[n])+A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));prefix+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def op(p,v,odd):
  out={}
  if role=='replay':
   for(n,j),df in grad(p).items():
    if n in v:
     for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  else:
   for(g,w),c in p.items():
    prefix=0
    for at,(n,j) in enumerate(w):
     if n in v:
      z=mul({(g,w[:at]):scale_coefficient(c,(-1)**prefix if odd else 1)},DD(v[n],j),{(0,w[at+1:]):ONE})
      for k,t in z.items():put(out,k,t)
     prefix+=A.parities[n]
  return out
 def wick(p):
  phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
  for(g,w),c in p.items():
   fac=scalar('-1')
   for n,j in w:
    fac=mul(fac,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
   for k,v in mul({(g,w):c},fac).items():put(out,k,v)
  return out
 ref=read(Path(prep['artifacts'][role]['reference']))['retained_reference'];order=ref['field_order'];pos={n:i for i,n in enumerate(order)}
 phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{s}_{i}' for s,c in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(c)]+[A.names[n] for n in ln+cn+an]
 assert len(phys)==643 and set(phys)==set(order)
 T={(i,j):scalar(z) for i,j,z in ref['physical_to_raw_kernel']['entries']};Ti={(i,j):scalar(z) for i,j,z in ref['physical_to_raw_inverse']['entries']};frame={}
 for name,j in pos.items():
  n=A.index[name];frame[n]=add(*(mul(z,elem(phys[i])) for(r,i),z in Ti.items() if r==j));frame[Jof[n]]=add(*(mul(z,elem(Jof[A.index[phys[i]]])) for(i,r),z in T.items() if r==j))
 e2=read(Path(prep['artifacts'][role]['e2']));shift={A.index[n]:rows(p) for n,p in e2['source_shifts'].items()};U={n:add(elem(n),p) for n,p in shift.items()}
 old=json.loads(gzip.decompress(Path(prep['artifacts'][role]['contact']).read_bytes()));master=json.loads(gzip.decompress(Path(prep['artifacts'][role]['master']).read_bytes()))
 seeds=[unpack(p) for p in old['seed_parts'][:2]];rawG=[sub(p,U) for p in seeds]
 qraw={i:rows(data['master_field_maps'][A.names[i]]) for i in fields};qraw.update({J:rows(e2['complete_columns'][A.names[J]]['source_polynomial']) for J in ja+jl})
 if role=='primary':
  q0={A.index[n]:unpack(p) for n,p in master['q0_columns'].items()};rawQ=[sub(op(p,q0,True),U) for p in seeds]
 else:rawQ=[op(p,qraw,True) for p in rawG]
 Gm=[sub(p,frame) for p in rawG];Qm=[sub(p,frame) for p in rawQ]
 assert all(p==unpack(old['physical_G'][i]) for i,p in enumerate(Gm))
 GE=[wick(p) for p in Gm];QE=[wick(p) for p in Qm]
 src=add(rows(data['gauge_fixing_density']),*(mul(elem(jl[i]),qraw[ln[i]]) for i in range(45)),*(mul(elem(ja[i]),qraw[an[i]]) for i in range(45)))
 source=wick(sub(src,frame));print('STAGE '+role+' actual_QG_before_any_loop_or_Ward_test',flush=True)
 bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))}
 def hess(p):
  out={}
  for(n,I),f in grad(p).items():
   if n not in fields:continue
   for(m,J),c in grad(f).items():
    if m not in fields:continue
    c=sub(c,{n:elem(v) for n,v in bgmap.items()});c={k:v for k,v in c.items() if all(t in ext|probe and not j for t,j in k[1]) and len(I)+len(J)==4-dims[n]-dims[m]-sum(ew.get(t,0) for t,j in k[1])}
    if not c:continue
    assert n in core and m in core,('NONMINIMAL_PRINCIPAL_CLOSURE',A.names[n],A.names[m])
    fac=scalar(str((-1)**(A.parities[m]*(A.parities[n]+1))))
    for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
    for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
    z=mul(c,fac);out[n,m]=add(out.get((n,m),{}),z)
  return {k:p for k,p in out.items() if p}
 HS=[hess(mul(elem(r),p)) for r,p in zip(rho,GE)];US=[hess(mul(elem(v),p)) for v,p in zip(u,QE)];VS=hess(source)
 VS={k:q for k,p in VS.items() if (q:={z:c for z,c in p.items() if any(n in ext for n,j in z[1])})}
 def evaluate(p,vec):return sub(p,{n:scalar(str(z)) for n,z in zip(qs,vec)})
 def checkshape(M):
  z0=[F(0)]*4;z1=[F(1),F(0),F(0),F(0)];q2=add(*(mul(elem(q),elem(q)) for q in qs))
  for i in range(45):
   for j in range(45):
    S=evaluate(M.get((bn[i][0],bn[j][0]),{}),z0);Tr=add(evaluate(M.get((bn[i][1],bn[j][1]),{}),z1),scale(S,-1));Lo=add(evaluate(M.get((bn[i][0],bn[j][0]),{}),z1),scale(S,-1),scale(Tr,-1))
    for mu in range(4):
     for nu in range(4):assert M.get((bn[i][mu],bn[j][nu]),{})==add(mul(Lo,elem(qs[mu]),elem(qs[nu])),add(S,mul(Tr,q2)) if mu==nu else {})
  for a in an+cn+ln:
   for b in bn:
    for side in [True,False]:
     factor=evaluate(M.get((a,b[0]) if side else (b[0],a),{}),z1)
     for mu in range(4):assert M.get((a,b[mu]) if side else (b[mu],a),{})==mul(factor,elem(qs[mu]))
  for(i,j),p in M.items():
   if i not in bset and j not in bset:
    S=evaluate(p,z0);T0=add(evaluate(p,z1),scale(S,-1));assert p==add(S,mul(T0,q2))
 for M in HS+US+[VS]:checkshape(M)
 print('STAGE '+role+' full_quadratic_Fourier_tensor_shapes_and_scalar_exclusion',flush=True)
 vec=[F(1),F(0),F(0),F(0)] if role=='primary' else [F(0),F(0),F(0),F(1)]
 def evalmat(M):return {k:q for k,p in M.items() if (q:=evaluate(p,vec))}
 H=[evalmat(M) for M in HS];UU=[evalmat(M) for M in US];V=evalmat(VS)
 G={}
 for i in range(45):
  w=scalar('eta_H' if i<12 else 'xi')
  for mu in range(4):
   for nu in range(4):
    z=add(scalar(str(int(mu==nu))),scale(add(w,scalar('-1')),vec[mu]*vec[nu]))
    if z:G[bn[i][mu],bn[i][nu]]=z
   if vec[mu]:G[bn[i][mu],ln[i]]=scalar(str(-vec[mu]));G[ln[i],bn[i][mu]]=scalar(str(vec[mu]))
  G[cn[i],an[i]]=scalar('1');G[an[i],cn[i]]=scalar('-1')
 def trim(p):return {k:c for k,c in p.items() if sum(n in anchors for n,j in k[1])<=1 and sum(n in chi for n,j in k[1])<=1 and sum(n in u for n,j in k[1])<=1 and sum(n in rho for n,j in k[1])<=1}
 def mm(L,B):
  rows=defaultdict(list);out={}
  for(k,j),p in B.items():rows[k].append((j,p))
  for(i,k),p in L.items():
   for j,q in rows[k]:
    z=trim(mul(p,q))
    if z:out[i,j]=add(out.get((i,j),{}),z)
  return {k:p for k,p in out.items() if p}
 def trace(M):return add(*(scale(p,(-1)**(A.parities[i] if i<len(A.names) else 0)) for(i,j),p in M.items() if i==j))
 def pathtrace(matrices):
  if any(not m for m in matrices):return {}
  indexes=[]
  for M in matrices[1:]:
   ix=defaultdict(list)
   for(i,j),p in M.items():ix[i].append((j,p))
   indexes.append(ix)
  out={}
  def walk(root,at,depth,p):
   if depth==len(indexes):
    if at==root:
     for k,c in scale(p,(-1)**(A.parities[root] if root<len(A.names) else 0)).items():put(out,k,c)
    return
   for j,q in indexes[depth].get(at,[]):
    if depth==len(indexes)-1 and j!=root:continue
    z=trim(mul(p,q))
    if z:walk(root,j,depth+1,z)
  for(i,j),p in matrices[0].items():walk(i,j,0,p)
  return out
 def contractions(ms):
  n=len(ms);out={}
  if role=='primary':
   for word in permutations(range(n)):out=add(out,scale(pathtrace([ms[i] for i in word]),F((-1)**(n+1),2*n)))
  else:
   for word in permutations(range(1,n)):
    z=ms[0]
    for i in word:z=mm(z,ms[i])
    out=add(out,scale(trace(z),F((-1)**(n+1),2)))
  return out
 def select(M,tag):
  def good(w):
   ee=[n for n,j in w if n in ext]
   return not ee if tag=='0' else len(ee)==1 and ee[0] in (chi if tag=='c' else set(bl) if tag=='L' else set(ja))
  return {k:q for k,p in M.items() if (q:={z:c for z,c in p.items() if good(z[1])})}
 def target(p,anchor,rs,us=None):return {k:c for k,c in p.items() if sum(n in set(bl if anchor=='L' else ja) for n,j in k[1])==1 and sum(n in chi for n,j in k[1])==1 and sum(n in rho for n,j in k[1])==1 and any(n==rho[rs] for n,j in k[1]) and sum(n in u for n,j in k[1])==int(us is not None) and (us is None or any(n==u[us] for n,j in k[1]))}
 def groups(G,H,UU,V):
  HH={d:[mm(G,select(h,d)) for h in H] for d in ['0','c']};UV={d:[mm(G,select(h,d)) for h in UU] for d in ['0','c','L']};VV={d:mm(G,select(V,d)) for d in ['c','L','J']};out={}
  for r in range(2):
   for anchor in ['L','J']:
    aa='L' if anchor=='L' else 'J';vals={'2':target(contractions([HH['c'][r],VV[aa]]),anchor,r),'3':target(contractions([HH['0'][r],VV['c'],VV[aa]]),anchor,r)};out['I'+str(r)+anchor]=vals
  for r,s in [(0,1),(1,0)]:
   vals={str(n):{} for n in [2,3,4]};vals['2']=target(contractions([UV['L'][r],HH['c'][s]]),'L',s,r)
   for a,b,c in [('L','0','c'),('c','0','L'),('0','c','L')]:vals['3']=add(vals['3'],target(contractions([UV[a][r],HH[b][s],VV[c]]),'L',s,r))
   vals['4']=target(contractions([UV['0'][r],HH['0'][s],VV['c'],VV['L']]),'L',s,r);out['C'+str(r)+str(s)]=vals
  return out
 four=groups(G,H,UU,V)
 G5=dict(G);H5=[dict(M) for M in H];U5=[dict(M) for M in UU];V5=dict(V);tr=1 if role=='primary' else 0
 for i in range(45):
  ii=len(A.names)+i;G5[ii,ii]=scalar('1')
  for j in range(45):
   jj=len(A.names)+j
   for M,N in list(zip(H,H5))+list(zip(UU,U5))+[(V,V5)]:
    p=M.get((bn[i][tr],bn[j][tr]),{})
    if p:N[ii,jj]=p
 five=groups(G5,H5,U5,V5);contacts={};jets={}
 for key,vs in four.items():
  jets[key]={n:add(five[key][n],scale(p,-1)) for n,p in vs.items()};z=mul(elem(cs[0]),add(*vs.values()))
  for n,slot in [('3',1),('4',2)]:
   if n in vs:z=add(z,mul(elem(cs[slot]),vs[n]))
  z=add(z,scale(add(*jets[key].values()),-2));contacts[key]=z
 print('STAGE '+role+' actual_one_probe_and_mixed_quantum_contacts',flush=True)
 def coeff(p,n):return grad(p).get((n,()),{})
 I=[coeff(add(contacts['I'+str(r)+'L'],contacts['I'+str(r)+'J']),rho[r]) for r in range(2)]
 C={k:coeff(coeff(contacts[k],u[int(k[1])]),rho[int(k[2])]) for k in ['C01','C10']}
 gm=[sub(p,{**{n:elem(v) for n,v in bgmap.items()},**{n:{} for n in fields if n not in bgmap}}) for p in GE]
 # Only no-jet nonminimal bilinear pieces feed this saturated projection.
 gm=[{k:c for k,c in p.items() if all(n in ext and not j for n,j in k[1])} for p in gm]
 flows=[]
 for p in gm:
  df=grad(p);v={}
  for a,l,aa,jj in zip(bg,bl,ja,jl):
   v[a]=df.get((aa,()),{});v[l]=scale(df.get((jj,()),{}),-1);v[aa]=scale(df.get((a,()),{}),-1);v[jj]=df.get((l,()),{})
  flows.append(v)
 def lambda_part(p):return {k:c for k,c in p.items() if sum(n in bl for n,j in k[1])==1 and sum(n in chi for n,j in k[1])==1 and not any(j for n,j in k[1])}
 crossfield=add(lambda_part(op(I[1],{n:p for n,p in flows[0].items() if n in set(bg+bl)},False)),scale(lambda_part(op(I[0],{n:p for n,p in flows[1].items() if n in set(bg+bl)},False)),-1))
 crosssource=add(lambda_part(op(I[1],{n:p for n,p in flows[0].items() if n in set(ja+jl)},False)),scale(lambda_part(op(I[0],{n:p for n,p in flows[1].items() if n in set(ja+jl)},False)),-1))
 oldnames=geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)];names=[('mw_rho'+n[7:] if n.startswith('spc_rho') else 'mw_a'+n[5:] if n.startswith('spc_a') else n) for n in oldnames]
 Pp=unpack(old['pair_tensors']['0,1']['4'],names);p=coeff(coeff(Pp,rho[0]),rho[1]);qlinear={}
 for a,l,aa,jj in zip(an,ln,bg,jl):
  ia=phys.index(A.names[a]);il=phys.index(A.names[l]);qa=add(*(mul(z,qraw[A.index[order[k]]]) for(i,k),z in T.items() if i==ia));ql=add(*(mul(z,qraw[Jof[A.index[order[k]]]]) for(k,i),z in Ti.items() if i==il))
  qa=scale(wick(sub(qa,frame)),-1);ql=mul(scalar('-I'),wick(sub(ql,frame)))
  for dest,poly in [(aa,qa),(jj,ql)]:
   z=sub(poly,{n:elem(v) for n,v in bgmap.items()});qlinear[dest]={k:c for k,c in z.items() if len(k[1])==1 and k[1][0][0] in bl and not k[1][0][1]}
 Qp=lambda_part(op(p,qlinear,True));cross=add(crossfield,crosssource);mixed=add(C['C01'],scale(C['C10'],-1));ward=add(mul(elem(cs[2]),Qp),scale(mul(elem(cs[1]),Qp),-1),mixed,cross)
 def pm(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
 output={'schema':'MIXED_PROBE_AUXILIARY_WARD_V1','role':role,'names':list(A.names),'parities':list(A.parities),'physical_G':[pack(p) for p in Gm],'physical_QG':[pack(p) for p in Qm],'euclidean_source':pack(source),'H_symbols':[pm(M) for M in HS],'U_symbols':[pm(M) for M in US],'V_symbols':pm(VS),'groups':{k:{n:pack(p) for n,p in vs.items()} for k,vs in four.items()},'Djets':{k:{n:pack(p) for n,p in vs.items()} for k,vs in jets.items()},'contacts':{k:pack(p) for k,p in contacts.items()},'G_bilinear':[pack(p) for p in gm],'flows':[{A.names[n]:pack(p) for n,p in v.items()} for v in flows],'qlinear':{A.names[n]:pack(p) for n,p in qlinear.items()},'p':pack(p),'Qp_Lambda':pack(Qp),'cross_field':pack(crossfield),'cross_source':pack(crosssource),'mixed_difference':pack(mixed),'relative_Ward_Lambda':pack(ward),'unit_orientation':[str(z) for z in vec],'all_other_Ward_sectors_or_full_QAP_qualified':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(output,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'group_positions':{k:{n:len(p) for n,p in vs.items()} for k,vs in four.items()},'ward_positions':len(ward),'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':output['elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
