from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
from itertools import permutations
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('MPA_VERIFIER_WRITE')
os.sys.addaudithook(guard)
role='verifier'
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
for k in ['names','parities','physical_G','physical_QG','euclidean_source','groups','Djets','contacts','G_bilinear','flows','qlinear','p','Qp_Lambda','cross_field','cross_source','mixed_difference','relative_Ward_Lambda']:assert P[k]==Z[k],k
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  for key,value in pp.items():put(out,key,value)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])


u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];bg=[index['mw_a'+str(i)] for i in range(45)];bl=[index['mw_L'+str(i)] for i in range(45)];qs=[index['mw_q'+str(i)] for i in range(4)];cs=[index[n] for n in ['mw_chi','mw_l32','mw_l2']]
bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b};dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)};bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))}
def hess(p):
 out={}
 for(n,I),f in gradient(p).items():
  if n not in fields:continue
  for(m,J),c in gradient(f).items():
   if m not in fields:continue
   c=subst(c,{n:elem(v) for n,v in bgmap.items()})
   c={k:v for k,v in c.items() if all(t in ext|probe and not j for t,j in k[-1]) and len(I)+len(J)==4-dims[n]-dims[m]-sum(ew.get(t,0) for t,j in k[-1])}
   if not c:continue
   assert n in core and m in core
   fac=scalar(str((-1)**(par[m]*(par[n]+1))))
   for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
   for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
   z=mul(c,fac);out[n,m]=add(out.get((n,m),{}),z)
 return {k:p for k,p in out.items() if p}
def wick(p):
 phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
 for(gp,xp,hp,m,w),v in p.items():
  term={(gp,xp,hp,m,w):-v}
  for n,j in w:term=mul(term,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
  for k,c in term.items():put(out,k,c)
 return out
GE=[wick(unpack(p)) for p in P['physical_G']];QE=[wick(unpack(p)) for p in P['physical_QG']];source=unpack(P['euclidean_source'])
HS=[hess(mul(elem(r),p)) for r,p in zip(rho,GE)];US=[hess(mul(elem(v),p)) for v,p in zip(u,QE)];VS=hess(source)
VS={k:q for k,p in VS.items() if (q:={z:c for z,c in p.items() if any(n in ext for n,j in z[-1])})}
frommat=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
assert HS==[frommat(p) for p in P['H_symbols']] and US==[frommat(p) for p in P['U_symbols']] and VS==frommat(P['V_symbols'])
print('STAGE verifier complete_physical_Hessians_and_principal_scalar_exclusion',flush=True)
def evaluate(p,vec):return subst(p,{n:scalar(str(z)) for n,z in zip(qs,vec)})
def checkshape(M):
 z0=[F(0)]*4;z1=[F(1),F(0),F(0),F(0)];q2=add(*(mul(elem(q),elem(q)) for q in qs))
 for i in range(45):
  for j in range(45):
   S=evaluate(M.get((bn[i][0],bn[j][0]),{}),z0);Tr=add(evaluate(M.get((bn[i][1],bn[j][1]),{}),z1),scaled(S,-1));Lo=add(evaluate(M.get((bn[i][0],bn[j][0]),{}),z1),scaled(S,-1),scaled(Tr,-1))
   for mu in range(4):
    for nu in range(4):assert M.get((bn[i][mu],bn[j][nu]),{})==add(mul(Lo,elem(qs[mu]),elem(qs[nu])),add(S,mul(Tr,q2)) if mu==nu else {})
 for a in an+cn+ln:
  for b in bn:
   for side in [True,False]:
    factor=evaluate(M.get((a,b[0]) if side else (b[0],a),{}),z1)
    for mu in range(4):assert M.get((a,b[mu]) if side else (b[mu],a),{})==mul(factor,elem(qs[mu]))
 for(i,j),p in M.items():
  if i not in bset and j not in bset:
   S=evaluate(p,z0);T0=add(evaluate(p,z1),scaled(S,-1));assert p==add(S,mul(T0,q2))
for M in HS+US+[VS]:checkshape(M)
print('STAGE '+role+' full_quadratic_Fourier_tensor_shapes_and_scalar_exclusion',flush=True)
vec=[F(1),F(0),F(0),F(0)]
def evalmat(M):return {k:q for k,p in M.items() if (q:=evaluate(p,vec))}
H=[evalmat(M) for M in HS];UU=[evalmat(M) for M in US];V=evalmat(VS)
G={}
for i in range(45):
 w=scalar('eta_H' if i<12 else 'xi')
 for mu in range(4):
  for nu in range(4):
   z=add(scalar(str(int(mu==nu))),scaled(add(w,scalar('-1')),vec[mu]*vec[nu]))
   if z:G[bn[i][mu],bn[i][nu]]=z
  if vec[mu]:G[bn[i][mu],ln[i]]=scalar(str(-vec[mu]));G[ln[i],bn[i][mu]]=scalar(str(vec[mu]))
 G[cn[i],an[i]]=scalar('1');G[an[i],cn[i]]=scalar('-1')
def trim(p):return {k:c for k,c in p.items() if sum(n in anchors for n,j in k[-1])<=1 and sum(n in chi for n,j in k[-1])<=1 and sum(n in u for n,j in k[-1])<=1 and sum(n in rho for n,j in k[-1])<=1}
def mm(L,B):
 rows=defaultdict(list);out={}
 for(k,j),p in B.items():rows[k].append((j,p))
 for(i,k),p in L.items():
  for j,q in rows[k]:
   z=trim(mul(p,q))
   if z:out[i,j]=add(out.get((i,j),{}),z)
 return {k:p for k,p in out.items() if p}
def trace(M):return add(*(scaled(p,(-1)**(par[i] if i<len(names) else 0)) for(i,j),p in M.items() if i==j))
def pathtrace(matrices):
 if any(not m for m in matrices):return {}
 indexes=[]
 for M in matrices[1:]:
  ix=defaultdict(list)
  for(i,j),p in M.items():ix[i].append((j,p))
  indexes.append(ix)
 out={}
 def walk(root,at,depth,p):
  if depth==len(indexes):
   if at==root:
    for k,c in scaled(p,(-1)**(par[root] if root<len(names) else 0)).items():put(out,k,c)
   return
  for j,q in indexes[depth].get(at,[]):
   if depth==len(indexes)-1 and j!=root:continue
   z=trim(mul(p,q))
   if z:walk(root,j,depth+1,z)
 for(i,j),p in matrices[0].items():walk(i,j,0,p)
 return out
def contractions(ms):
 out={};n=len(ms)
 for word in permutations(range(1,n)):
  out=add(out,scaled(pathtrace([ms[0]]+[ms[i] for i in word]),F((-1)**(n+1),2)))
 return out
def select(M,tag):
 def good(w):
  ee=[n for n,j in w if n in ext]
  return not ee if tag=='0' else len(ee)==1 and ee[0] in (chi if tag=='c' else set(bl) if tag=='L' else set(ja))
 return {k:q for k,p in M.items() if (q:={z:c for z,c in p.items() if good(z[-1])})}
def target(p,anchor,rs,us=None):return {k:c for k,c in p.items() if sum(n in set(bl if anchor=='L' else ja) for n,j in k[-1])==1 and sum(n in chi for n,j in k[-1])==1 and sum(n in rho for n,j in k[-1])==1 and any(n==rho[rs] for n,j in k[-1]) and sum(n in u for n,j in k[-1])==int(us is not None) and (us is None or any(n==u[us] for n,j in k[-1]))}
def groups(G,H,UU,V):
 HH={d:[mm(G,select(h,d)) for h in H] for d in ['0','c']};UV={d:[mm(G,select(h,d)) for h in UU] for d in ['0','c','L']};VV={d:mm(G,select(V,d)) for d in ['c','L','J']};out={}
 for r in range(2):
  for anchor in ['L','J']:
   aa='L' if anchor=='L' else 'J';vals={'2':target(contractions([HH['c'][r],VV[aa]]),anchor,r),'3':target(contractions([HH['0'][r],VV['c'],VV[aa]]),anchor,r)};out['I'+str(r)+anchor]=vals
 for r,s in [(0,1),(1,0)]:
  vals={str(n):{} for n in [2,3,4]};vals['2']=target(contractions([UV['L'][r],HH['c'][s]]),'L',s,r)
  for a,b,c in [('L','0','c'),('c','0','L'),('0','c','L')]:vals['3']=add(vals['3'],target(contractions([UV[a][r],HH[b][s],VV[c]]),'L',s,r))
  vals['4']=target(contractions([UV['0'][r],HH['0'][s],VV['c'],VV['L']]),'L',s,r);out['C'+str(r)+str(s)]=vals
 return out

four=groups(G,H,UU,V);G5=dict(G);H5=[dict(M) for M in H];U5=[dict(M) for M in UU];V5=dict(V)
for i in range(45):
 ii=len(names)+i;G5[ii,ii]=scalar('1')
 for j in range(45):
  jj=len(names)+j
  for M,N in list(zip(H,H5))+list(zip(UU,U5))+[(V,V5)]:
   p=M.get((bn[i][1],bn[j][1]),{})
   if p:N[ii,jj]=p
five=groups(G5,H5,U5,V5);contacts={};jets={}
for key,vs in four.items():
 for n,p in vs.items():assert p==unpack(P['groups'][key][n]),(key,n)
 jets[key]={n:add(five[key][n],scaled(p,-1)) for n,p in vs.items()}
 for n,p in jets[key].items():assert p==unpack(P['Djets'][key][n]),(key,n,'Djet')
 z=mul(elem(cs[0]),add(*vs.values()))
 for n,slot in [('3',1),('4',2)]:
  if n in vs:z=add(z,mul(elem(cs[slot]),vs[n]))
 z=add(z,scaled(add(*jets[key].values()),-2));assert z==unpack(P['contacts'][key]);contacts[key]=z
print('STAGE verifier independent_all_ordered_groups_and_dimension_jets',flush=True)
coeff=lambda p,n:gradient(p).get((n,()),{})
I=[coeff(add(contacts['I'+str(r)+'L'],contacts['I'+str(r)+'J']),rho[r]) for r in range(2)]
C={k:coeff(coeff(contacts[k],u[int(k[1])]),rho[int(k[2])]) for k in ['C01','C10']}
gm=[subst(p,{**{n:elem(v) for n,v in bgmap.items()},**{n:{} for n in fields if n not in bgmap}}) for p in GE]
gm=[{k:c for k,c in p.items() if all(n in ext and not j for n,j in k[-1])} for p in gm]
assert gm==[unpack(p) for p in P['G_bilinear']]
def projection(p):return {k:c for k,c in p.items() if sum(n in bl for n,j in k[-1])==1 and sum(n in chi for n,j in k[-1])==1 and not any(j for n,j in k[-1])}
# Direct EVEN Hamiltonian of rho*G, with actual local left Euler legs.
F0=add(*(mul(elem(r),p) for r,p in zip(rho,gm)));B=add(*(mul(elem(r),p) for r,p in zip(rho,I)))
eF=EL(F0,set(bg+bl+ja+jl));dB=gradient(B);field={};src={}
for a,l,aa,jj in zip(bg,bl,ja,jl):
 for n,v in [(a,eF[aa]),(l,eF[jj])]:field=add(field,mul(v,dB.get((n,()),{})))
 for n,v in [(aa,eF[a]),(jj,eF[l])]:src=add(src,mul(v,dB.get((n,()),{})))
field=projection(coeff(coeff(field,rho[0]),rho[1]));src=projection(coeff(coeff(src,rho[0]),rho[1]))
assert field==unpack(P['cross_field']) and src==unpack(P['cross_source'])
# Q columns freshly from the actual Euclidean action, not desired descendants.
ell=EL(source,set(ln+ja));qlinear={}
for a,l,aa,jj in zip(an,ln,bg,jl):
 for dest,poly in [(aa,ell[Jof[a]]),(jj,ell[l])]:
  z=subst(poly,{n:elem(v) for n,v in bgmap.items()});qlinear[dest]={k:c for k,c in z.items() if len(k[-1])==1 and k[-1][0][0] in bl and not k[-1][0][1]}
assert qlinear=={index[n]:unpack(p) for n,p in P['qlinear'].items()}
p=unpack(P['p']);qp={}
for(n,j),df in gradient(p).items():
 if n in qlinear:qp=add(qp,mul(qlinear[n],df))
qp=projection(qp);assert qp==unpack(P['Qp_Lambda'])
mixed=add(C['C01'],scaled(C['C10'],-1));ward=add(mul(elem(cs[2]),qp),scaled(mul(elem(cs[1]),qp),-1),mixed,field,src)
assert mixed==unpack(P['mixed_difference']) and ward==unpack(P['relative_Ward_Lambda'])
# Domain audit and finite radial comparison, without an expected-zero Ward gate.
for p in [qp,mixed,field,src,ward]:
 assert all(sum(n in bl for n,j in w)==1 and sum(n in chi for n,j in w)==1 and all(n in set(bl)|chi|set(cs) and not j for n,j in w) for gp,xp,hp,m,w in p)
eps,m2,nlog=s.symbols('eps m2 n_log',positive=True)
for n in [2,3,4]:
 ratio=s.gamma(n-eps)/(s.gamma(2-eps)*s.gamma(n));a=s.simplify(s.diff(ratio,eps).subs(eps,0));assert a==1-s.harmonic(n-1)
 dim=s.log(4*s.pi)-s.EulerGamma-s.log(m2)+a;heat=-s.EulerGamma-s.log(2*n)-s.log(m2)-s.harmonic(n-1)+nlog
 assert s.simplify(dim-heat-(1+s.log(16*s.pi)-nlog+s.log(s.Rational(n,2))))==0
receipt={'schema':'MIXED_PROBE_AUXILIARY_WARD_VALIDATION_V1','scientific_disposition':'QUALIFIED_COMPLETE_AUXILIARY_LINEAR_LOCAL_RELATIVE_WARD_COEFFICIENT','mixed_slots_per_orientation':4050,'one_probe_companion_slots_per_G':8100,'nonzero_groups':{k:{n:len(collapsed(p)) for n,p in vs.items()} for k,vs in four.items()},'Qp_Lambda_positions':len(collapsed(qp)),'cross_field_positions':len(collapsed(field)),'cross_source_positions':len(collapsed(src)),'relative_Ward_positions':len(collapsed(ward)),'relative_Ward_is_zero':not ward,'fixed_source_omission_sensitive':bool(src),'one_probe_omission_sensitive':bool(add(field,src)),'all_symbolic_quadratic_Fourier_coefficients_checked':True,'all_physical_Hessians_freshly_differentiated':True,'Q_columns_fresh_action_Euler_check':True,'rho_Hamiltonian_cross_direct_even_Euler_check':True,'all_group_and_Djet_cells_fresh_expanded_arithmetic':True,'raw_QG_and_frame_not_reconstructed_third_time':True,'absolute_heat_Ward_nonlocal_products_QAP_or_physical_restoration':False,'authority_changed':False,'shared_inputs_proofs_software_AI_author':True,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True);watch.cancel()
