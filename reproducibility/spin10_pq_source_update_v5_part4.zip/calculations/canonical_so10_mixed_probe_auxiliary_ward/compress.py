from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,gzip,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(60,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'compression_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
old=json.loads(gzip.decompress((R/'calculations/canonical_so10_source_probe_contact_complete/primary_v2_tables.json.gz').read_bytes()))
new=[json.loads(gzip.decompress((O/(r+'_tables.json.gz')).read_bytes())) for r in ['primary','replay']]
geo=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))['geometry'];oldnames=geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)]
def cells(packet,names):
 out={}
 for g,w,c in packet['monomials']:
  word=tuple((names[n],tuple(j)) for n,j in w)
  for x,h,m,num,den in packet['coefficients'][c]:
   k=(g,x,h,m,word);out[k]=out.get(k,F(0))+F(num,den)
 return {k:v for k,v in out.items() if v}
base={}
for(g,x,h,m,w),c in cells(old['pair_tensors']['0,1']['4'],oldnames).items():
 assert g==2 and x==1 and h==2 and m==16 and all(not j for n,j in w)
 rest=tuple((('mw_L'+n[5:] if n.startswith('spc_a') else n),j) for n,j in w if not n.startswith('spc_rho'))
 assert len(rest)==2 and rest[0][0].startswith('JL') and rest[1][0].startswith('mw_L')
 # Removing the two ordered odd rho gives +; multiplying i by -i gives +.
 base[g,x,h,0,rest]=c
assert len(base)==56
expected={}
for(g,x,h,m,w),c in base.items():
 for name,sg in [('mw_l32',1),('mw_l2',-1)]:expected[g,x,h,m,w+((name,()),)]=c*sg
for p in new:
 assert cells(p['relative_Ward_Lambda'],p['names'])==expected
 qp=cells(p['Qp_Lambda'],p['names']);src={k:v for k,v in qp.items() if all(n.startswith(('JL','mw_L')) for n,j in k[-1])};assert src==base
assert len(expected)==112
out={'schema':'MPA_WARD_COMPRESSION_V1','all_old_tensor_entries_matched':56,'formal_log_monomials':112,'common_chi4_and_rational_and_antighost_components_zero':True,'formula':'-(log(2)-log(3/2))*g10^2*xi*eta_H^2*sum Kij JL_i Lambda_j in16pi2 density units','same_K_as_SPC':True,'no_absolute_heat_breaking_or_QAP_claim':True,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
