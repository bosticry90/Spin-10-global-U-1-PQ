# Next required operator calculation, not a chosen compensating coefficient

The measured R is a variation of the LOCAL regulator-conversion functional.
It is not the absolute Ward breaking of either quantum prescription. The
actual heat response must be derived before asserting restoration or failure.
This note fixes the next mathematical target; no such new worker has run.

Retain the SAME augmented Hessian H_ext=H0+M_ext, source Euler operation and
independently labelled Schwartz probes. At finite proof cutoff let

 B_t=G0 exp(-2t P) M_ext,
 Gamma_t=one half sum_(n>=1) (-1)^(n+1) STr(B_t^n)/n-Gamma_ref.

For delta=(S_ext,.)+d, use an odd tracking parameter if needed to express an
even variation. At each finite coefficient the complete ordered variation is

 delta Gamma_t=one half sum_(n>=1)(-1)^(n+1)
                  STr(B_t^(n-1) delta B_t)-delta Gamma_ref,

 delta B_t=(delta G0) exp(-2tP) M_ext
     -G0 integral_0^(2t) exp(-(2t-s)P)(delta P)exp(-sP) M_ext ds
     +G0 exp(-2tP) delta M_ext.

This uses trace-class finite-cutoff cyclicity only, not arbitrary cyclicity
of a renormalized trace. Before omitting delta G0,delta P or delta Gamma_ref,
check their ACTUAL dependence and the prescribed cutoff/inverse defects.
Source differentiation precedes source0. delta M_ext must come from the
actual full field/source/probe variation; a bare field Frechet derivative
alone omits its source-kernel companions. Preserve all four master-Hessian
product legs and their graded transpose/jet adjoints if reorganizing it.

Project the whole ordered family onto rho0*rho1*Lambda*(JL or a), with the
same power count, source/field duals and Wick conventions. The measured
matrix is a concrete target for comparison, not the value to be assigned to
an unknown insertion. Keep lengths and noncommuting factors until the finite
UV extraction. Separate UV logarithms/power finite parts from the joint IR
limit. Never cancel a naked critical inverse pair before the grouped defects.

Once the actual absolute objects are justified in a common extended domain,
their difference must agree with the independently calculated variation of
the conversion functional. Check the signs from Crel=Gamma_D-FP-Gamma_H-FP;
do not assume either individual breaking is zero. Reconcile any additional
T_kappa trace/transgression terms explicitly rather than silently calling a
bare dimensional finite part the fully normalized prescription.

Success would identify the actual regulator/contact response and its
relation to R. A remaining undefined product/limit or inconsistent coefficient
is an explicit construction gap, not license to set the missing term to -R.
Even a successful selected identity would not construct the unrestricted
counterterm module, full chiral SMA/measure/phase or physical E5/A5 limits.
