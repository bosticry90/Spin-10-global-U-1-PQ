from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
old=(R/'calculations/canonical_so10_source_probe_contact_complete/verify_v3.py').read_text(encoding='utf-8');native=(O/'native.py').read_text(encoding='utf-8')
helpers=old[old.index('def put('):old.index('bn=[[index')]
header='''from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
from itertools import permutations
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('MPA_VERIFIER_WRITE')
os.sys.addaudithook(guard)
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
for k in ['names','parities','physical_G','physical_QG','euclidean_source','groups','Djets','contacts','G_bilinear','flows','qlinear','p','Qp_Lambda','cross_field','cross_source','mixed_difference','relative_Ward_Lambda']:assert P[k]==Z[k],k
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
'''
env='''
u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];bg=[index['mw_a'+str(i)] for i in range(45)];bl=[index['mw_L'+str(i)] for i in range(45)];qs=[index['mw_q'+str(i)] for i in range(4)];cs=[index[n] for n in ['mw_chi','mw_l32','mw_l2']]
bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b};dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)};bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))}
def hess(p):
 out={}
 for(n,I),f in gradient(p).items():
  if n not in fields:continue
  for(m,J),c in gradient(f).items():
   if m not in fields:continue
   c=subst(c,{n:elem(v) for n,v in bgmap.items()})
   c={k:v for k,v in c.items() if all(t in ext|probe and not j for t,j in k[-1]) and len(I)+len(J)==4-dims[n]-dims[m]-sum(ew.get(t,0) for t,j in k[-1])}
   if not c:continue
   assert n in core and m in core
   fac=scalar(str((-1)**(par[m]*(par[n]+1))))
   for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
   for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
   z=mul(c,fac);out[n,m]=add(out.get((n,m),{}),z)
 return {k:p for k,p in out.items() if p}
def wick(p):
 phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
 for(gp,xp,hp,m,w),v in p.items():
  term={(gp,xp,hp,m,w):-v}
  for n,j in w:term=mul(term,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
  for k,c in term.items():put(out,k,c)
 return out
GE=[wick(unpack(p)) for p in P['physical_G']];QE=[wick(unpack(p)) for p in P['physical_QG']];source=unpack(P['euclidean_source'])
HS=[hess(mul(elem(r),p)) for r,p in zip(rho,GE)];US=[hess(mul(elem(v),p)) for v,p in zip(u,QE)];VS=hess(source)
VS={k:q for k,p in VS.items() if (q:={z:c for z,c in p.items() if any(n in ext for n,j in z[-1])})}
frommat=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
assert HS==[frommat(p) for p in P['H_symbols']] and US==[frommat(p) for p in P['U_symbols']] and VS==frommat(P['V_symbols'])
print('STAGE verifier complete_physical_Hessians_and_principal_scalar_exclusion',flush=True)
'''
def extract(a,b):
 t=native[native.index(a):native.index(b,native.index(a))]
 return '\n'.join(line[1:] if line.startswith(' ') else line for line in t.splitlines())+'\n'
math=extract(' def evaluate('," four=groups(")
math=math.replace('sub(', 'subst(').replace('scale(', 'scaled(').replace('A.parities','par').replace('A.names','names').replace('k[1]','k[-1]').replace('z[1]','z[-1]')
# Third route uses closed rooted index paths, not either native's full log or sparse inverse products.
start=math.index('def contractions(');end=math.index('def select(',start)
math=math[:start]+'''def contractions(ms):
 out={};n=len(ms)
 for word in permutations(range(1,n)):
  out=add(out,scaled(pathtrace([ms[0]]+[ms[i] for i in word]),F((-1)**(n+1),2)))
 return out
'''+math[end:]
math=math.replace(" if role=='primary' else [F(0),F(0),F(0),F(1)]",'')
tail='''
four=groups(G,H,UU,V);G5=dict(G);H5=[dict(M) for M in H];U5=[dict(M) for M in UU];V5=dict(V)
for i in range(45):
 ii=len(names)+i;G5[ii,ii]=scalar('1')
 for j in range(45):
  jj=len(names)+j
  for M,N in list(zip(H,H5))+list(zip(UU,U5))+[(V,V5)]:
   p=M.get((bn[i][1],bn[j][1]),{})
   if p:N[ii,jj]=p
five=groups(G5,H5,U5,V5);contacts={};jets={}
for key,vs in four.items():
 for n,p in vs.items():assert p==unpack(P['groups'][key][n]),(key,n)
 jets[key]={n:add(five[key][n],scaled(p,-1)) for n,p in vs.items()}
 for n,p in jets[key].items():assert p==unpack(P['Djets'][key][n]),(key,n,'Djet')
 z=mul(elem(cs[0]),add(*vs.values()))
 for n,slot in [('3',1),('4',2)]:
  if n in vs:z=add(z,mul(elem(cs[slot]),vs[n]))
 z=add(z,scaled(add(*jets[key].values()),-2));assert z==unpack(P['contacts'][key]);contacts[key]=z
print('STAGE verifier independent_all_ordered_groups_and_dimension_jets',flush=True)
coeff=lambda p,n:gradient(p).get((n,()),{})
I=[coeff(add(contacts['I'+str(r)+'L'],contacts['I'+str(r)+'J']),rho[r]) for r in range(2)]
C={k:coeff(coeff(contacts[k],u[int(k[1])]),rho[int(k[2])]) for k in ['C01','C10']}
gm=[subst(p,{**{n:elem(v) for n,v in bgmap.items()},**{n:{} for n in fields if n not in bgmap}}) for p in GE]
gm=[{k:c for k,c in p.items() if all(n in ext and not j for n,j in k[-1])} for p in gm]
assert gm==[unpack(p) for p in P['G_bilinear']]
def projection(p):return {k:c for k,c in p.items() if sum(n in bl for n,j in k[-1])==1 and sum(n in chi for n,j in k[-1])==1 and not any(j for n,j in k[-1])}
# Direct EVEN Hamiltonian of rho*G, with actual local left Euler legs.
F0=add(*(mul(elem(r),p) for r,p in zip(rho,gm)));B=add(*(mul(elem(r),p) for r,p in zip(rho,I)))
eF=EL(F0,set(bg+bl+ja+jl));dB=gradient(B);field={};src={}
for a,l,aa,jj in zip(bg,bl,ja,jl):
 for n,v in [(a,eF[aa]),(l,eF[jj])]:field=add(field,mul(v,dB.get((n,()),{})))
 for n,v in [(aa,eF[a]),(jj,eF[l])]:src=add(src,mul(v,dB.get((n,()),{})))
field=projection(coeff(coeff(field,rho[0]),rho[1]));src=projection(coeff(coeff(src,rho[0]),rho[1]))
assert field==unpack(P['cross_field']) and src==unpack(P['cross_source'])
# Q columns freshly from the actual Euclidean action, not desired descendants.
ell=EL(source,set(ln+ja));qlinear={}
for a,l,aa,jj in zip(an,ln,bg,jl):
 for dest,poly in [(aa,ell[Jof[a]]),(jj,ell[l])]:
  z=subst(poly,{n:elem(v) for n,v in bgmap.items()});qlinear[dest]={k:c for k,c in z.items() if len(k[-1])==1 and k[-1][0][0] in bl and not k[-1][0][1]}
assert qlinear=={index[n]:unpack(p) for n,p in P['qlinear'].items()}
p=unpack(P['p']);qp={}
for(n,j),df in gradient(p).items():
 if n in qlinear:qp=add(qp,mul(qlinear[n],df))
qp=projection(qp);assert qp==unpack(P['Qp_Lambda'])
mixed=add(C['C01'],scaled(C['C10'],-1));ward=add(mul(elem(cs[2]),qp),scaled(mul(elem(cs[1]),qp),-1),mixed,field,src)
assert mixed==unpack(P['mixed_difference']) and ward==unpack(P['relative_Ward_Lambda'])
# Domain audit and finite radial comparison, without an expected-zero Ward gate.
for p in [qp,mixed,field,src,ward]:
 assert all(sum(n in bl for n,j in w)==1 and sum(n in chi for n,j in w)==1 and all(n in set(bl)|chi|set(cs) and not j for n,j in w) for gp,xp,hp,m,w in p)
eps,m2,nlog=s.symbols('eps m2 n_log',positive=True)
for n in [2,3,4]:
 ratio=s.gamma(n-eps)/(s.gamma(2-eps)*s.gamma(n));a=s.simplify(s.diff(ratio,eps).subs(eps,0));assert a==1-s.harmonic(n-1)
 dim=s.log(4*s.pi)-s.EulerGamma-s.log(m2)+a;heat=-s.EulerGamma-s.log(2*n)-s.log(m2)-s.harmonic(n-1)+nlog
 assert s.simplify(dim-heat-(1+s.log(16*s.pi)-nlog+s.log(s.Rational(n,2))))==0
receipt={'schema':'MIXED_PROBE_AUXILIARY_WARD_VALIDATION_V1','scientific_disposition':'QUALIFIED_COMPLETE_AUXILIARY_LINEAR_LOCAL_RELATIVE_WARD_COEFFICIENT','mixed_slots_per_orientation':4050,'one_probe_companion_slots_per_G':8100,'nonzero_groups':{k:{n:len(collapsed(p)) for n,p in vs.items()} for k,vs in four.items()},'Qp_Lambda_positions':len(collapsed(qp)),'cross_field_positions':len(collapsed(field)),'cross_source_positions':len(collapsed(src)),'relative_Ward_positions':len(collapsed(ward)),'relative_Ward_is_zero':not ward,'fixed_source_omission_sensitive':bool(src),'one_probe_omission_sensitive':bool(add(field,src)),'all_symbolic_quadratic_Fourier_coefficients_checked':True,'all_physical_Hessians_freshly_differentiated':True,'Q_columns_fresh_action_Euler_check':True,'rho_Hamiltonian_cross_direct_even_Euler_check':True,'all_group_and_Djet_cells_fresh_expanded_arithmetic':True,'raw_QG_and_frame_not_reconstructed_third_time':True,'absolute_heat_Ward_nonlocal_products_QAP_or_physical_restoration':False,'authority_changed':False,'shared_inputs_proofs_software_AI_author':True,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True);watch.cancel()
'''
with (O/'verify.py').open('x',encoding='utf-8',newline='\n') as f:f.write(header+helpers+env+math+tail)
print('BUILT_MPA1_EXPANDED_VERIFIER')
