# Mixed probe auxiliary-linear relative Ward coefficient, MPA1

Base34a124042dc13571b549abb3bde2ffc4255e6e3d/main; previous goal turn PROGRESS.
Recover actual preflight/AGENTS/receipts. State113/34of39 and custodyexit2/seven
NOTPASS unchanged. No agents, branch/worktree, remote action, publication,
physical scheme/foundation/benchmark/state/promotion/flavor/HB1-C5 activation.

Question: what does the ACTUAL mixed u*rho local comparison contribute to
the auxiliary-linear second-probe Ward coefficient associated with SPC's
nonzero56-position finite contact? The symbolic completion is not quantum data.
Measure both mixed orientations and the necessary one-probe companions before
classifying their sum. Do NOT require that sum to vanish.

Scope: explicit frozen643-field bosonic Euclidean local relative comparison,
u0*rho1 and u1*rho0, ordinary physical fields/ghost backgrounds and external
jets0 AFTER differentiation. Retain one auxiliary Lambda and one a or JL.
This is the COMPLETE auxiliary-linear carrier:4050 concrete slots per
orientation. First-probe companions require anchors Lambda or Ja times a
or JL:8100 slots per G0/G1. Covariance/reality constrain these carriers;
their counts are not invariant ranks. No full Ward/QAP/nonlocal/measure/
physical/global/causal claim. Other source/physical/jet sectors remain open.

Inputs: actual SPC Mlight/Mheavy projections, SPM pre-U seed and Q0 columns,
portable actual GF/field rules, actual E2 source Euler columns, full643
field/source-dual frames and authenticated SPC56 tensor. Same fixed mass,
width/source/Wick conventions. Never import the desired symbolic u*rho value.

Primary derives QG=U(Q0 seed), replay differentiates U seed with actual raw
Q fields and E2 source columns BEFORE transport. Both derive G, QG, principal
Hessians, one-probe contacts, mixed contacts, projected Hamiltonian flows and
Qp. Full scalar rows are tested in the principal projection rather than
assumed absent. Other physical action terms have no relevant nonminimal
background dependence by the qualified action screen.

Ordered log / closed index paths versus dressed inverse / sparse products;
two unit orientations. Store formal momentum symbols through degree2.
Verify the full Lorentz tensor coefficients, not only four axis values for
quadratic symbols. Keep lengths4/6/8 and every angular D jet. Separate fresh
expanded-Fraction verifier differentiates physical densities and all loop
groups/flows; it does not reconstruct the raw frame a third time. Shared
inputs/analytic UV-IR comparison proofs/software/AI author remain explicit.

Success: full exact comparison of independently calculated arrays, classical
types/signs, sensitive omissions where meaningful, complete zero complements,
and classification of measured relative Ward tensor. A nonzero tensor is not
an anomaly: the absolute heat breaking and full nonlocal products are separate.
Underdefinition or resource exhaustion is incomplete, never PASS.

Caps each sequential native600s after imports, separate verifier600s;
8GiB sampled private,350MiB available-commit launch floor, packet16MiB.
Freeze sources, hashes and evidence before launch. Preserve all exact failures
and full captures. Reassess on exhaustion; no silent resource or input change.
Verify completed bounded work and delegated E4 checks before a local commit.
Continue from measured data, without setting unknown terms from restoration.
