# Complete selected projection and signs before computation

Use existing S_ext=S+sum(u_r QG_r+rho_r G_r), d u=rho, Q u=Q rho=0.
Classical S_ext is linear in these probes. All operations are integrated
local functionals modulo admitted currents. The saturated Lambda-linear
coefficient has dimension3,ghost-1,odd after removing u*rho. Lambda has
dimension2,ghost0,even. The remaining factor must be JL or a (dimension1,
ghost-1,odd). No jet, mass or scalar-vacuum coefficient fits. All45x90=4050
slots are retained. Localizing probes does not create an omitted jet in THIS
projection; jets in other projections are not declared zero.

For the one-probe bracket, only I_G terms anchor*chi can flow to Lambda*chi,
where anchors=(Lambda,Ja), chi=(a,JL). There are90x90=8100 slots per G.
X_G fixes ordinary physical fields/C. Its physical-source and JC flows have
no Lambda by dimension and the actual G's affine auxiliary dependence.
Its relevant linear flows are X_G chi in chi and X_G Lambda/Ja in Lambda.
Therefore no omitted physical/source/jet/mass term in I_G can feed this
projection. Retain the source flows; fixed-source variation is insufficient.

Let rho0*rho1*p be SPC's measured contact. Let I_r be the left-rho coefficient
of the actual one-probe relative functional, and C_rs its u_r*rho_s
coefficient. The project Hamiltonian convention for odd G is
X_G z=(-1)^(p_z+1) EL_J G, X_G J=(-1)^p_z EL_z G.
For the even density rho_r G_r the field/source flow is rho_r X_G, odd.
Acting on rho_s I_s moves past rho_s and gives rho_r*rho_s*X_G I_s.
Thus the complete selected RELATIVE Ward coefficient is

 R_Lambda=Pi_Lambda[Qp+C_01-C_10+X_G0 I_1-X_G1 I_0].

This is the coefficient in (S_ext,Crel_ext)+d Crel_ext. It is not the
absolute breaking of Gamma_heat or a requirement R_Lambda=0. No S2 term
exists classically. Qp uses both QJL*a and -JL*Qa from actual columns.

Differentiate complete densities before replacing residual a,Lambda by
distinct background labels. For density dimension4 keep Fourier degree
4-d_i-d_j-d_external exactly; lower degrees contain positive-dimensional
coefficients and cannot contribute to this saturated target. This filters
scalar/orbit pieces without setting their complete nonlocal amplitudes0.
Retain formal q0..q3 in principal Hessians; scalar/vector/BB tensors have
degree<=2, and the symbolic checks include q_mu*q_nu off diagonal.

Write A_r=H_(rho_r G_r), U_r=H_(u_r QG_r). Relevant A degrees0,chi1;
U degrees0,chi1,Lambda2; action V degreeschi1,Lambda2,Ja2.
Each degree refers to external fields/sources, not probe labels. Projection
to Lambda*chi fixes all ordered loop words:
mixed n2: U_L A_chi;
mixed n3: (U_L,A0,V_chi),(U_chi,A0,V_L),(U0,A_chi,V_L);
mixed n4: (U0,A0,V_chi,V_L).
All orders are retained with (-1)^(n+1)/(2n) in the log, or rooted inverse
weights (-1)^(n+1)/2. One-probe anchor*chi has n2 A_chi V_anchor and
n3 A0 V_chi V_anchor, both latter orders. These exhaust the carrier, not a
graph cutoff. Identical/probe Grassmann signs remain inside even vertices.

Use the inherited G_BB=delta+(w-1)nn, G_BL=-n,G_LB=n,G_Ca=1,G_aC=-1
on unit q. Extra transverse components of all metric BB blocks implement
the angular first-D jet; no guessed4/D factor. Each n has heat2n. The
relative comparison is chi4*sum Tn+log(3/2)T3+log2*T4-2*sum d_D Tn.
One-probe has no n4. chi4 is free; log symbols are separate formal basis
elements, not fitted numbers. Kappa,b0 and IR constants remain distinct.

Literal Wick fields B0_M=iB0_E,Lambda_M=-iLambda_E; source dual phase
J_M*field_phase=-J_E, hence JL=-i,Ja=-1,JC=-1. S_E=-W S_M;
u,rho unchanged. Q_E z_E=W(Q_M z_M)/field_phase_z (source phase for J).
The odd generators G_E=-W G_M give their flows via the same Hamiltonian
rule. Background labels represent ordinary fields for these variations.

The IR/local-relative comparison and first-D-jet proofs are inherited in
their qualified order: UV finite part then joint IR removal, no exceptional
pullback. Full convergent U, reference/measure and absolute heat-breaking
terms remain unextracted. This projection does not extend the pure metric
argument to full chiral SMA or activate blocked basic/counterterm stages.
