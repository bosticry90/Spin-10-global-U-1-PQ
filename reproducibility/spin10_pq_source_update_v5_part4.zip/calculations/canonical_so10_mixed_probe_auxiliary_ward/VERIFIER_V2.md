# Pre-identified verifier display-label correction

Both native routes completed under the frozen600s caps and agree on their
group counts and nonzero relative Ward coefficient. Before original verifier
completion, source inspection identified an unbound display variable `role`
in its symbolic-shape progress print. The original frozen controller/source
cannot be edited during execution. Its exact eventual failure/capture must
remain; no receipt may be issued for that attempt.

V2 adds ONLY role='verifier' to a separate verifier source. It reuses the
completed native arrays, repeats every fresh physical Hessian, symbolic
Fourier, loop-group, D-jet, actual Euler-source, direct rho-Hamiltonian and
radial check, with the same600s/8GiB/350MiB/16MiB caps. No quantum coefficient,
graph, physical input, expected result or acceptance condition changes.
Freeze a new validation manifest after the original attempt is terminal.
