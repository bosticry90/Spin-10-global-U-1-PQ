from pathlib import Path
from hashlib import sha256
import json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/mixed-probe-auxiliary-ward-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 files=[O/n for n in ['COMPRESSION.md','compress.py','run_compression.py','primary_tables.json.gz','replay_tables.json.gz','validation_receipt_v2.json']]+[R/'calculations/canonical_so10_source_probe_contact_complete/primary_v2_tables.json.gz',R/'tools/portable_dh_v1/inputs.json.gz',R/'AGENTS.md']
 for n in ['COMPRESSION.md','compress.py','run_compression.py']:
  p=O/n
  with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 files.extend(O/(n+'.source.txt') for n in ['COMPRESSION.md','compress.py','run_compression.py'])
 dump(O/'compression_preparation.json',{'input_sha256':{str(p):H(p) for p in files},'limits':{'seconds_after_imports':60,'sampled_private_bytes':8*1024**3,'launch_commit_floor':350*1024**2,'packet_bytes':16*1024**2}})
 c=capture([sys.executable,'-B',str(O/'compress.py')]);dump(O/'compression_capture.json',c);dump(C/'compression_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified'] and c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2
 rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<60
 dump(O/'compression_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(O/'compression_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
