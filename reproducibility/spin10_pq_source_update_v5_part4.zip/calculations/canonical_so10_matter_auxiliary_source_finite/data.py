"""MAF1 exact amplitudes and selected source-Euler projections."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('MAF1_PEER_OR_COMPARISON_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_bosonic_source_onejet_finite','canonical_so10_lower_source_vector_finite','canonical_so10_matter_source_primitive'] and p.name.endswith('.gz'):raise PermissionError('MAF1_BOSONIC_OR_COUNTERTERM_TARGET_DENIED')
 sys.addaudithook(audit);return start
def images(source,T,U):
 out={}
 for part,sides in source.items():
  out[part]={}
  for side,other,ts in [('left','right',T),('right','left',U)]:
   this=list(map(dec,sides[side]));opp=list(map(dec,sides[other]));pp=[];qq=[];gg=[]
   for c,m in enumerate(this):
    pp.append(enc(scale(plus(m,trans(opp[c])),II)));x=scale(m,II);qq.append(enc(x))
    for b,t in enumerate(ts):
     v=minus(mul(x,t),mul(t,x))
     if v.d:gg.append([b,c,enc(v)])
   out[part][side]={'p':pp,'q':qq,'gauge':gg}
 return out
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','comparison_member':'RAW_DIMENSIONAL_MINUS_COMMON_SCALAR_HEAT_LENGTH6_LOCAL_UV','bosonic_heat_extension_physically_adopted':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_coupled_restoration_claimed':False,'new_model_color_integrations':0,'source_overall_factor':'g10^2*xi/(16*pi^2)','source_gauge_image_overall_factor':'g10^3*xi/(16*pi^2)','xi_factored_out_exactly_once':True,'other_scalar_hatted_and_highest_source_images':'UNCOMPUTED_RETAINED_SMA_EULER_OBLIGATIONS'})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
