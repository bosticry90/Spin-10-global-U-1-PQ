"""MAF1 actual source amplitudes,barred numerator inputs and late bosonic comparisons."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-auxiliary-source-finite-v1-2026-10-23');PRED=CAL/'canonical_so10_lower_source_vector_finite'
BASE='5779e1956f1b27047766d98992fae9fd55d4d8dd';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32262
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt_v2.json','verify_v2_capture.json','RESULT.md','validation_preparation_v2.json','primary_tables.json.gz','replay_tables.json.gz']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V542.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_source_vector_g3_color',['color.py','color.py.source.txt','RECORD.md','RESULT.md','primary_result.json','replay_result.json','validation_receipt.json','preparation.json']),('canonical_so10_source_vector_g3_inputs',['primary_result.json','replay_result.json','validation_receipt.json','inputs.py','RECORD.md'])]:
 for n in names:add(CAL/folder/n)
# Bind reused Python helpers under their recorded historical hashes; do not
# substitute live policy for old policy or reinterpret an old manifest.
for folder in ['canonical_so10_source_vector_g3_color','canonical_so10_source_vector_g3_inputs']:
 for p,h in read(CAL/folder/'preparation.json')['input_sha256'].items():
  if Path(p).suffix=='.py':assert digest(Path(p))==h,p;bind[p]=h
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';MAS=CAL/'canonical_so10_matter_auxiliary_source_pole'
for folder,names in [('canonical_so10_matter_auxiliary_source_pole',['RECORD.md','DERIVATION.md','RESULT.md','primary.py','replay.py','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_dimensional_stokes_primitive',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_source_vector_finite_units',['DERIVATION.md','validation_receipt_v2.json']),('canonical_so10_coupled_common_log_onejet',['DERIVATION.md','validation_receipt_v2.json']),('canonical_so10_matter_source_primitive',['DERIVATION.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for role in ['primary','replay']:
 m=packed(MAS/(role+'_tables.json.gz'));yp=CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz');fp=CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz'
 for path in [yp,fp]:add(path)
 y=packed(yp)
 gz(HERE/(role+'_inputs.json.gz'),{'MAS':{k:m[k] for k in ['loop_left','loop_right','angular_unit','UV_unit','coupling_order']},'Y':{k:y[k] for k in ['Tminus','H_new']},'plane_f':packed(fp)['reference_fields']['plane_f']})
 add(HERE/(role+'_inputs.json.gz'))
bs=CAL/'canonical_so10_bosonic_source_onejet_finite/primary_v2_tables.json.gz';add(bs);bc=packed(bs);lc=packed(PRED/'primary_tables.json.gz')
gz(HERE/'validation_control_inputs.json.gz',{'BSF_mixed_q':{side:bc['matter_q_images'][side]['mixed'] for side in ['left','right']},'LSF_currents':lc['matter_current_coefficients']});add(HERE/'validation_control_inputs.json.gz')
origin=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/lower-source-vector-finite-v1-2026-10-23');reuse={}
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:
 q=origin/n;raw=q.read_bytes();reuse[str(q)]=sha256(raw).hexdigest()
 with (CONTROL/n).open('xb') as f:f.write(raw)
 add(CONTROL/n)
dump(CONTROL/'readiness_reuse.json',{'source_sha256':reuse,'fresh_readiness_command_here':False,'source_command_executed_earlier_this_goal_turn':True,'fresh_byte_preflight_here':True,'scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and not d['active_A10_M08_python_processes'] and d['files_written']==0
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'MAF1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('MAF1_FROZEN',len(bind),'bindings',flush=True)
