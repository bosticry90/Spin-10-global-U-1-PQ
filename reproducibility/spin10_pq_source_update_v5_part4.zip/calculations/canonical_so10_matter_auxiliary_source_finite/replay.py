"""MAF1 split8 spin and actual IR-completed Schwinger/Gamma finite integrals."""
from data import *
start=begin('replay');pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gg=[sy.kronecker_product(pa[1],m) for m in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];gam=[sy.kronecker_product(g,pa[2]) for g in gg];hat=sy.kronecker_product(sy.eye(4),pa[0]);k=sy.symbols('k0:4');bar=sum((z*g for z,g in zip(k,gam)),sy.zeros(8));assert not (bar*bar-sum(z*z for z in k)*sy.eye(8)).applyfunc(sy.expand).todok();assert all(not (g*hat+hat*g).todok() for g in gam)
z=sy.Symbol('z',positive=True);eps=sy.Symbol('epsilon',positive=True);m2,c=sy.symbols('m2 heat_length',positive=True);nl=sy.Symbol('n_log');D,r=sy.symbols('D bar_rank')
Ih=(1+z)*sy.exp(z)*sy.expint(1,z)-1;hFP=sy.expand(sy.series(Ih,z,0,1).removeO()).subs(z,c*m2)+nl
Id=sy.gamma(eps)*sy.exp(eps*sy.log(4*sy.pi/m2));dFP=sy.expand(sy.series(Id,eps,0,1).removeO()-1/eps)
v=sy.Symbol('v',positive=True);massI3=sy.integrate(v/(1+v)**3,(v,0,sy.oo));assert massI3==sy.Rational(1,2)
rank_ratio=sy.combsimp((r/D)*sy.gamma(D/2+1)/(2*sy.gamma(D/2)));assert rank_ratio==r/4
actual_difference=sy.expand_log(-(dFP-(hFP-massI3)),force=True);chi6=1+sy.log(4*sy.pi*c)-nl;assert sy.simplify(actual_difference+chi6+sy.Rational(1,2))==0
fixed=sy.simplify(actual_difference+chi6);unit=-sy.Integer(1);ratio=sy.simplify(fixed/unit)
# Independent all-incoming endpoint variation fixes the classical p/q map.
p,q=sy.symbols('p q');a,b=sy.symbols('ML MRt');assert sy.expand(sy.I*(b*p+a*(p+q))-sy.I*((a+b)*p+a*q))==0
d=packed(HERE/'replay_inputs.json.gz');assert d['MAS']['coupling_order']=='g10^2*xi' and d['MAS']['UV_unit']=='-1'
source={}
for part,z0 in [('chi4',Q(1)),('log3over2',Q(1)),('fixed',Q(str(ratio)))]:source[part]={side:[enc(scale(dec(m),z0)) for m in d['MAS']['loop_'+side]] for side in ['left','right']}
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
finish('replay',{'method':'actual_split8_spin_and_Schwinger_Gamma_rank4_numerator_integrals','angular_unit':'-4/D','UV_unit':str(unit),'fixed_unit':str(fixed),'finite_to_pole_fixed_ratio':str(ratio),'heat_length':6,'source_matrices':source,'source_Euler_images':images(source,T,U),'bar_rank_fixed':4,'generic_rank_angular':'-bar_rank/D','common_scalar_difference':'1+log(4*pi*heat_length)-n_log','dimension_jet_omission_fixed_ratio':'0','incorrect_bar_rank_D_fixed_unit':'0','scalar_normalization_matches_BSF':True,'heat_scalar_finite':str(hFP),'dimensional_scalar_finite':str(dFP),'rank_r_dimensional_to_I2_ratio':str(rank_ratio),'common_IR_mass_I3_limit':str(massI3),'actual_signed_integral_difference':str(actual_difference),'source_endpoint_variation_remainder':0},start)
