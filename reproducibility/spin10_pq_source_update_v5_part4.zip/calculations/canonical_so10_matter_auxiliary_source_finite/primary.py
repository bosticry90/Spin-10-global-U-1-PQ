"""MAF1 actual four-barred numerator and dimension/heat finite jets."""
from data import *
from itertools import permutations
start=begin('primary');pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gam=[sy.kronecker_product(pa[1],m) for m in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];k=sy.symbols('k0:4');slash=sum((z*a for z,a in zip(k,gam)),sy.zeros(4));numerator=-sum((z*slash*a for z,a in zip(k,gam)),sy.zeros(4));assert not (numerator+sum(z*z for z in k)*sy.eye(4)).applyfunc(sy.expand).todok()
verts=[[4,2],[3,1],[5,0]];signs=[]
for order in permutations(range(3)):
 word=sum((verts[i] for i in order),[]);signs.append((-1)**sum(word[i]>word[j] for i in range(6) for j in range(i+1,6)))
gaussian=sy.Rational(sum(signs),6);phase=sy.I*(-sy.I)*sy.I*(-sy.I);assert gaussian==phase==1
D=sy.Symbol('D');r=sy.Symbol('bar_rank');angular=-r/D;u=angular.subs(r,4);u4=u.subs(D,4);fixed=-2*sy.diff(u,D).subs(D,4);ratio=sy.simplify(fixed/u4)
c=sy.Symbol('heat_length',positive=True);nl=sy.Symbol('n_log',real=True);sigma=sy.diff(sy.log(2*sy.pi**(D/2)/sy.gamma(D/2)/(2*sy.pi)**D),D).subs(D,4);chi=sy.expand_log(sy.EulerGamma+sy.log(c)-nl-2*sigma,force=True);assert sy.simplify(chi-(1+sy.log(4*sy.pi*c)-nl))==0
assert sy.simplify(chi.subs(c,6)-chi.subs(c,4)-sy.log(sy.Rational(3,2)))==0
d=packed(HERE/'primary_inputs.json.gz');assert sy.sympify(d['MAS']['angular_unit'],locals={'d':D})==u and d['MAS']['UV_unit']=='-1' and d['MAS']['coupling_order']=='g10^2*xi'
source={}
for part,z in [('chi4',Q(1)),('log3over2',Q(1)),('fixed',Q(str(ratio)))]:source[part]={side:[enc(scale(dec(m),z)) for m in d['MAS']['loop_'+side]] for side in ['left','right']}
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
finish('primary',{'method':'actual_4spin_numerator_graded_gaussian_and_D_measure_jet','angular_unit':str(u),'UV_unit':str(u4),'fixed_unit':str(fixed),'finite_to_pole_fixed_ratio':str(ratio),'heat_length':6,'source_matrices':source,'source_Euler_images':images(source,T,U),'bar_rank_fixed':4,'generic_rank_angular':str(angular),'common_scalar_difference':'1+log(4*pi*heat_length)-n_log','dimension_jet_omission_fixed_ratio':'0','incorrect_bar_rank_D_fixed_unit':'0','scalar_normalization_matches_BSF':True},start)
