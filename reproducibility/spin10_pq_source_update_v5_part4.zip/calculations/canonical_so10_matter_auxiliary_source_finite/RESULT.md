# MAF1: actual auxiliary matter-source finite coefficient is nonzero

Primary, independent replay and separate gate completed native0. Receipt
validation_receipt.json SHA256:
d5d7c1c96780e559bd1e3f2106f9d0bfa6dd2d94b90cc95f08341c6b11fb7398.
Status QUALIFIED_AUXILIARY_MATTER_SOURCE_LOCAL_FINITE_COMPARISON.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 unchanged.

In the explicitly specified common-flat-heat comparison member,the complete
selected proper auxiliary source amplitude is

 M_relative = [chi4+log(3/2)+1/2] * M_MAS,pole,

with source factor g10²*xi/(16pi²) OUTSIDE the stored matrix. The independently
measured MAS color tensor is unchanged. The extra finite half is derived,
not selected to satisfy a Ward relation. Both chiral tensors have592 nonzero
positions in each displayed direction;all69120 source positions including
zeros agree between methods. Xi is factored out exactly once and remains
symbolic. No physical coupling,finite baseline,flavor matrix or mass is chosen.

## Why the half survives

The actual physical pp inverse has bar_slash(k)/Q at nonzero internal hats.
MAS routing and Wick/Gaussian phases give numerator-bar_k²,whose angular
unit is-4/D. The barred rank is4 even when total D varies. Primary checks
the actual4-spin identity and differentiates this angular unit with the
same measure/heat normalization as BSF. Replay checks split8-spin Clifford
identities and derives the IR-completed Schwinger/Gamma integrals directly.
The auxiliary spin witness is not a new particle or family multiplicity.

At D4,the common heat integral has the numerator finite term
I2_heat-m²I3_heat with m²I3_heat->1/2. The variable-D rank4 Gaussian/Gamma
identity instead gives exactly I2_dim. Their difference supplies the extra
half. Setting D4 before differentiation,or changing barred rank4 to D,
would erase it. Those controls change592 source coefficients/chirality.
Wrong heat length4 instead of6 would lose the nonzero log(3/2) coefficient.

The positive auxiliary IR mass is a common relative-UV completion. Its
UV-integrable difference cancels on both sides;no physical massless p=0
finite amplitude or physical IR limit is claimed. The actual loop order,
source current products,phases and old independently qualified MAS color
methods are reused,not recomputed as new model integrations.

## Selected classical images and late bosonic comparison

The qualified odd-left source-Euler map gives p=i(ML+MR.T),q=iML with the
right analogues. MAS has MR=-ML.T,so its p image is0. Its q image is a
Hermitian tensor with592 nonzero positions/chirality,and its gauge companion
[iML_c,T_b] has19008,for each finite direction. Actual U=-T.T gives the
right matrices;all1620 H-cochain coefficient tests pass. Source restriction
and boundary currents are treated as in CLO/MSP. Other scalar,hatted and
highest-source descendants remain uncomputed obligations.

Only after the independent source amplitudes matched did the gate read the
already measured bosonic BSF derivative and LSF vector tensors. The selected
remainders below are observed exact coefficients,not acceptance targets.

| Direction | One-jet q remainder/chirality | Gauge remainder/chirality |
| --- | ---: | ---: |
| chi4 | 0 | 0 |
| log(3/2) | 592 | 0 |
| fixed | 592 | 19,008 |

All p remainders are0. The logarithmic vector cancellation uses LSF's
independently calculated heat-length contribution. The nonzero one-jet and
fixed gauge terms demonstrate why neither the bosonic fixed cancellation
nor a common-pole match closes the finite coupled construction. They are
not anomalies or independently required new particles/counterterms. Complete
comparison tables retain every coefficient and implicit zero complement.
No unmeasured contribution was assigned an opposite value.

## Precisely what is qualified

This is a local raw-dimensional-minus-symmetric-common-heat amplitude
comparison for a specified Euclidean member chosen before computation.
The scalar heat extension to the provisional P/S reference is a concrete
mathematical choice. It has not been adopted as a unique historical physical
chiral regulator,renormalization scheme,measure or full quantum prescription.
In particular this calculation does not assert that Q commutes with a
gamma5 dimension lift or import the nonchiral Stokes theorem as that proof.
The amplitude calculation is valid within its declared fixed-barred algebra.

The result supplies a genuine finite proper source input and a bounded
relationship to existing bosonic inputs. It does not prove a complete
coupled Slavnov identity,QAP,quantum equivalence or physical unification.
The common chi4 and all other distinct normalization freedoms remain unfixed.

## Execution,capability evidence and continuation

P/R/gate completed in4.5259353/4.7623597/2.5966242s after imports,each
native0,with no new failed worker or verifier. Their3/4/2 private-memory
sample maxima63729664/67088384/100139008 bytes are sparse observations,
not peaks. Frozen600s/8GiB sampled/350MiB available-commit floor/16MiB
stored-packet bounds held. Eight source copies,1087 preparation and1095
validation bindings,full captures and comparison-table hashes are retained.
THIS-goal-turn LSF fresh E4 was honestly reused,with fresh byte preflight.
Historical custody remains exit2/seven NOTPASS. State and old evidence unchanged.

Track B demonstrates an actual finite source derivation,independent angular
and integral routes,and late comparison that retains nonzero remainders.
It does not turn the formal heat member into an accepted physical scheme.
Shared action,old independent color data,Clifford/regulator assumptions,
exact software and AI authorship remain common-error limits.

Next least-expensive action:extend the finite comparison to the complete
ordinary g10³ proper source family. MVS retains a fixed4/D numerator with
the actual longitudinal vector projector and both internal derivative
placements. Its source matrices are NOT generally anti-Hermitian,so retain
both chiral blocks and the nonzero p image. Derive the generic gauge Euler
image before using the MAS special commutator formula. Then assess the
full two-family source input before the source-free kinetic/vertex finite
comparison needed for a complete selected coupled one-jet construction.

Full coupled/chiral restoration,QAP/products/measure/phase,physical scheme,
massiveC1,E5/A5 and GUT viability remain unqualified. Bothscalarwarnings,
quartetFAIL,flavorpause,HB1/C5blocks,custody and distinct freeconstants remain.
No new physical benchmark,state change,branch/worktree,publication/outreach
or remote push.
