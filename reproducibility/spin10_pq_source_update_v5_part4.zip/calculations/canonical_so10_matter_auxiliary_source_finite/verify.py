"""MAF1 finite source amplitude gate and late unbiased bosonic comparisons."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz')
for k in ['angular_unit','UV_unit','fixed_unit','finite_to_pole_fixed_ratio','heat_length','source_matrices','source_Euler_images','bar_rank_fixed','generic_rank_angular','common_scalar_difference','dimension_jet_omission_fixed_ratio','incorrect_bar_rank_D_fixed_unit','scalar_normalization_matches_BSF','source_overall_factor','source_gauge_image_overall_factor','xi_factored_out_exactly_once']:assert P[k]==R[k],k
assert P['angular_unit']=='-4/D' and P['UV_unit']=='-1' and P['fixed_unit']=='-1/2' and P['finite_to_pole_fixed_ratio']=='1/2' and P['bar_rank_fixed']==4 and P['heat_length']==6
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(d['Y']['H_new']);f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
counts={};covariance_checks=0;positions=0
for part,sides in P['source_matrices'].items():
 counts[part]={};left=list(map(dec,sides['left']));right=list(map(dec,sides['right']));assert len(left)==len(right)==45
 for side,ms in [('left',left),('right',right)]:
  im=P['source_Euler_images'][part][side];assert all(not dec(m).d for m in im['p']);counts[part][side]={'source':sum(len(m.d) for m in ms),'p':0,'q':sum(len(dec(m).d) for m in im['q']),'gauge':sum(len(dec(m).d) for b,c,m in im['gauge'])};positions+=45*16**2
 for l,r in zip(left,right):zero(plus(l,trans(star(l))));zero(plus(r,trans(l)))
 q=list(map(dec,P['source_Euler_images'][part]['left']['q']))
 for m in q:zero(minus(m,trans(star(m))))
 for h in range(12):
  th=Mat(16,16);fh=defaultdict(lambda:Z)
  for a in range(45):
   z=HF.d.get((a,h),Z)
   if z:
    th=plus(th,scale(T[a],z))
    for c in range(45):
     for e,v in f[a,c]:fh[c,e]=add(fh[c,e],prod(z,v))
  for c,m in enumerate(q):
   res=scale(minus(mul(th,m),mul(m,th)),neg(II))
   for (cc,e),v in fh.items():
    if cc==c:res=minus(res,scale(q[e],v))
   zero(res);covariance_checks+=1
assert positions==69120 and covariance_checks==1620
for side in ['left','right']:
 assert P['source_matrices']['chi4'][side]==d['MAS']['loop_'+side] and P['source_matrices']['log3over2'][side]==d['MAS']['loop_'+side]
 for fixed,pole in zip(P['source_matrices']['fixed'][side],d['MAS']['loop_'+side]):zero(minus(dec(fixed),scale(dec(pole),Q('1/2'))))
# Only now interpret the independently completed bosonic coefficients.
control=packed(HERE/'validation_control_inputs.json.gz');comparisons={};remainders={}
for part in ['chi4','log3over2','fixed']:
 comparisons[part]={};remainders[part]={}
 for side in ['left','right']:
  im=P['source_Euler_images'][part][side];one=[]
  bq=control['BSF_mixed_q'][side]['chi' if part=='chi4' else 'fixed']
  for source,boson in zip(im['q'],bq):one.append(enc(plus(dec(source),dec(boson))))
  gm={(b,c):dec(m) for b,c,m in im['gauge']};bc={(b,c):dec(m) for b,c,m in control['LSF_currents'][part]['B'][side]};gg={}
  for key in set(gm)|set(bc):
   z=plus(gm.get(key,Mat(16,16)),scale(bc.get(key,Mat(16,16)),neg(II)))
   if z.d:gg[key]=z
  comparisons[part][side]={'p':[enc(dec(m)) for m in im['p']],'q':one,'gauge':[[b,c,enc(m)] for (b,c),m in sorted(gg.items())]}
  remainders[part][side]={'p':0,'q':sum(len(dec(m).d) for m in one),'gauge':sum(len(m.d) for m in gg.values())}
raw=(json.dumps({'selected_remainders':comparisons,'counts':remainders,'quantum_input_fitted':False,'full_coupled_restoration_claimed':False},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'comparison_tables.json.gz').open('xb') as out:out.write(blob)
assert P['source_overall_factor']=='g10^2*xi/(16*pi^2)' and P['source_gauge_image_overall_factor']=='g10^3*xi/(16*pi^2)' and P['xi_factored_out_exactly_once']
assert R['common_IR_mass_I3_limit']=='1/2' and R['rank_r_dimensional_to_I2_ratio']=='bar_rank/4' and R['source_endpoint_variation_remainder']==0
for x in [P,R]:assert not any(x[k] for k in ['bosonic_heat_extension_physically_adopted','physical_scheme_adopted','quantum_coefficient_fitted','full_coupled_restoration_claimed','new_model_color_integrations'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_AUXILIARY_MATTER_SOURCE_LOCAL_FINITE_COMPARISON','elapsed_after_imports':time.perf_counter()-start,'actual_source_positions_compared':positions,'source_H_covariance_positions':covariance_checks,'angular_unit':P['angular_unit'],'fixed_unit':P['fixed_unit'],'finite_to_pole_fixed_ratio':P['finite_to_pole_fixed_ratio'],'heat_length':6,'bar_rank_fixed':4,'source_and_image_nonzero_counts':counts,'observed_selected_bosonic_comparison_remainders':remainders,'comparison_tables_sha256':digest(HERE/'comparison_tables.json.gz'),'comparison_raw_sha256':sha256(raw).hexdigest(),'negative_controls':{'drop_dimension_jet_changes_source_positions_per_chirality':counts['fixed']['left']['source'],'replace_fixed_bar_rank4_with_D_erases_nonzero_fixed_unit':True,'wrong_heat6_to4_loses_nonzero_log_positions_per_chirality':counts['log3over2']['left']['source'],'half_source_changes_nonzero_positions_per_chirality':counts['chi4']['left']['source']},'comparison_member':P['comparison_member'],'common_chi4_symbolic':True,'xi_factored_out_exactly_once':True,'source_overall_factor':P['source_overall_factor'],'source_gauge_image_overall_factor':P['source_gauge_image_overall_factor'],'other_source_hatted_scalar_images_qualified':False,'full_coupled_restoration_claimed':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'scientific_authority_changed':False,'full_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
