# MAF1: fixed barred rank before the finite dimension derivative

MAS1's exact phases,Gaussian sign and routed G_BL(+k) give numerator
-bar_slash(k)*bar_gamma_mu*k_mu=-bar_k² I on the open physical spinor line.
The pp inverse is bar_slash/Q,with Q=bar_k²+hat_k²;using a full slash would
change the actual action/reference. The source and scalar/group conventions
are already fixed by the measured MAS coefficient,not a cancellation target.

For fixed bar rank r=4 the angular unit is u_D=-r/D,u4=-1. At total D=4,
the common scalar heat multiplies the complete critical kernel by exp(-6tQ).
Relative to BSF's same chi4,the unit conversion is

 (chi4+log(3/2))*u4 -2*(partial_D u_D)|4.

This is a local amplitude comparison. It does not assume Q commutes with
the chiral dimension lift or import the nonchiral bosonic primitive theorem.
All external labels are kept and the source is differentiated before any
source0 restriction,as in the already qualified proper-vertex calculation.

An independent actual-integral derivation completes the critical numerator
with a common positive auxiliary m². Its relative UV coefficient is unchanged:
the difference is UV-integrable and the same in both regulated constructions.
The symmetric heat length is c=6. In16pi² units,

 FP I2_heat=-gamma_E-log(c*m²)-1+n_log,
 FP I2_dim=-gamma_E+log(4pi/m²).

At D4,the fixed rank4 numerator bar_k² is Q,so the tensor numerator integral
is I2_heat-m² I3_heat with m²I3_heat->1/2. In variable D,the Gaussian rank-r
moment and Gamma recurrence give integral bar_k²/(Q+m²)^3 = r*I2_dim/4,
which is I2_dim for r=4. Consequently the finite difference of that rank4
numerator is chi6+1/2,where chi6=chi4+log(3/2). Its minus follows the actual
MAS numerator. Verify the sign and finite unit before multiplying any color.

The normalized unit ratio to the measured UV coefficient therefore has to
be DERIVED from both routes;the prospective expression is chi6+1/2. Taking
D4 before the dimension derivative would erase its extra finite1/2. Replacing
fixed barred rank4 by D would likewise silently change the regulator algebra.
The finite coefficient is relative to the common fixed n_log;it cannot be
removed by a separate favorable source normalization without changing the
declared common comparison.

For the actual proper source matrices ML,MR,the selected kinetic Euler
slots are p_L=i(ML+MR.T),q_L=iML and their right analogues. This is CLO's
generic odd-left derivation,not an assumed anti-Hermitian restriction.
MAS happens to have MR=-ML.T. For x=iML,the physical gauge companion is
[x_c,T_b],with actual U=-T.T on the right. This is the already derived MSP/
CFC source-Euler representative,with its boundary current retained. The
overall extra g in that gauge component is explicit. No scalar/hatted image
is discarded globally or declared covered by these two projections.

Late comparisons use BSF's mixed derivative source coefficient and LSF's
lower vector coefficient. Keep all overall xi and g powers exact. A zero
subcomparison is bounded evidence;a nonzero one identifies a remaining
coupled contribution,not an anomaly or permission to fit an unknown term.
