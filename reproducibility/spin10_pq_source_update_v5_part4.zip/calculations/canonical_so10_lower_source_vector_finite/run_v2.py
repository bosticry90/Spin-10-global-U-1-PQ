"""LSF1 new explicit zero theorem gate,reusing both completed workers unchanged."""
from pathlib import Path
from hashlib import sha256
import json,sys,subprocess,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/lower-source-vector-finite-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
 for p,h in bind.items():assert digest(Path(p))==h,p
 assert read(HERE/'verify_capture.json')['exit_code']==1 and read(HERE/'controller_failure.json')['last_role']=='verify'
 for n in ['ADJUDICATION_V2.md','verify_v2.py','run_v2.py']:
  p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
  if p.suffix=='.py':compile(raw,str(p),'exec')
  with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 for p in HERE.iterdir():
  if p.is_file():bind[str(p.resolve())]=digest(p)
 with (CONTROL/'prelaunch_v2_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v2_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
 assert r.returncode==0 and not read(CONTROL/'prelaunch_v2_preflight.json')['active_A10_M08_python_processes']
 for n in ['prelaunch_v2_preflight.json','prelaunch_v2_preflight_stderr.txt']:bind[str(CONTROL/n)]=digest(CONTROL/n)
 dump(HERE/'validation_preparation_v2.json',{'schema':'LSF1_ZERO_ADJUDICATION_V2','input_sha256':dict(sorted(bind.items())),'seconds':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'old_nonzero_conjecture':'FAILED_PRESERVED','completed_workers_repeated':False,'scientific_acceptance':'NOT_PERFORMED'})
 print('LSF1_V2_FROZEN',len(bind),'bindings',flush=True)
 c=capture([sys.executable,'-B',str(HERE/'verify_v2.py')]);dump(HERE/'verify_v2_capture.json',c);dump(CONTROL/'verify_v2_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1;r=rows[0]
 assert r['status']=='QUALIFIED_LOWER_AUXILIARY_SOURCE_VECTOR_FINITE_FAMILY' and r['complete_fixed_color_and_current_tensor_zero'] and r['original_nonzero_fixed_expectation']=='REFUTED_ORIGINAL_GATE_FAILED_PRESERVED' and r['elapsed_after_imports']<600
 dump(HERE/'validation_receipt_v2.json',r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
 print('VERIFY_V2_COMPLETED',r['elapsed_after_imports'],flush=True)
except BaseException:
 dump(HERE/'controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
