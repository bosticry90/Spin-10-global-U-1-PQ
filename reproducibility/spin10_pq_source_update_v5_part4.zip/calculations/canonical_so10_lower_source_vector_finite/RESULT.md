# LSF1: complete lower source/vector finite family; fixed terms cancel

Primary and independent replay completed; the explicit cancellation gateV2
completed native0. Receipt validation_receipt_v2.json SHA256:
62c5ed150391a88f9409b27acbdac7d9d95dfad4dc0d2b647675b996a2d12ccf.
Status QUALIFIED_LOWER_AUXILIARY_SOURCE_VECTOR_FINITE_FAMILY. Scientific/
director acceptance NOT_PERFORMED; state113/34of39 unchanged.

The complete lowerg10²*xi gauge-source/vector family is

 rho_(lower)=g10²*xi/(16pi²) * [chi4+log(3/2)] * P_lower.

Its additional fixed color tensor is EXACTLY ZERO. This is a collective
cancellation,not the absence of the individual finite terms. The selected
A_H channel is also zero within this complete family. P_lower is independently
derived from the actual source/ghost/auxiliary/vector action; no Ward target,
normalization choice or physical parameter supplied its value.

## Full kernels and finite normalization

Fresh graded Born and routed Wick derivations agree at all80 unintegrated
Lorentz positions for ghost:a/c/B,aux,YM. They retain both mixed-propagator
orientations and the full cubic-vector interaction. Pointwise covariant
reduction and a dimension-free tensor proof determine the natural D lift;
it is not inferred from a four-dimensional pole.

| Unit | u_D | u4 | Fixed finite unit |
| --- | --- | --- | --- |
| ghost:a | 1/D | 1/4 | 1/8 |
| ghost:c | -1/D | -1/4 | -1/8 |
| external-vector derivative | 0 | 0 | 0 |
| auxiliary | 1/D | 1/4 | 1/8 |
| full YM | -(D-1)/D | -3/4 | 1/8 |

All are triangles of heat length6. The finite unit is
(chi4+log(3/2))*u4+B/8 for the actual tensor A delta/Q²+Bkk/Q³.
The full kernel actually loses all ordinary-vector widths before integration.
Primary uses the rational D-sphere recurrence;replay uses a Dirichlet/Gamma
moment and the qualified SVF common-IR finite scalar/tensor comparison.
The complete ghost derivative-current sum vanishes pointwise,including its
finite map. Discarding the first dimension jet or replacing heat6 by4 would
change the nonzero unit contributions while leaving their old poles unchanged.

The constant finite-to-old32pi²-pole ratios are1/4 for the combined ghost
and auxiliary groups,and-1/12 for YM. These are derived rational UNIT ratios,
not division by physical widths/couplings or a fit. Their constancy and equal
ghost:a/c ratios justify reusing the fully resolved old independent color
tables. No new model color paths or full loop integrals were recomputed.
Fresh work consists of the full finite unit derivations,reassembly,structure
transport and verification. All160 old unit-pole positions compare afterward.

## Actual color cancellation and matter-Euler tensor

The two qualified old color routes independently obey,at every coefficient,

 V_YM,32 = 3*(V_ghost,32+V_aux,32).

Therefore V_ghost/4+V_aux/4-V_YM/12=0 exactly. Each term is nonzero before
addition. Omitting YM or ghost leaves1940 old-frame coefficients;omitting
auxiliary leaves526. The zero result cannot be reproduced by deleting the
auxiliary or transverse vector contribution.

All346275 finite color/round-trip positions,including zeros in both45B and
12A_H channels,agree after the SVT-qualified source/primal transport. The
surviving chi4 and log(3/2) tensors are identical:1680 nonzero parent-plane
B color positions each,with19008 actual matter-current positions per
chirality. All1620 homogeneous H-covariance matrix checks pass,including the
zero fixed direction. Actual T/U currents satisfy Hermiticity and right=-left.T.

The bosonic factor g10²*xi/(16pi²) and matter factor-i*g10³*xi/(16pi²) are
retained externally,with xi factored out EXACTLY ONCE. All free normalizations
remain symbolic. The computed current is a source-Euler companion,not an
independently measured compensating quantum insertion or a coupled restoration.

## Original failed expectation and new adjudication

Both original workers completed in4.1042946/5.3298509s after imports. The
original gate failed native1 on its extra nonzero-fixed-total expectation.
That conjecture is REFUTED in this scope. It was not a physical requirement
or a justified premise of the finite calculation. Its source,capture and
controller remain FAILED and unchanged;there is no original validation receipt.

V2 freezes a separate explicit ZERO theorem,tests the exact independently
measured group identity above in BOTH routes,and checks all final fixed
source/current entries vanish. Every other original unit,frame,covariance,
zero-complement,current and normalization condition is retained. All failure
and omission evidence is preserved. No scientific coefficient,sign,width,
method,domain or resource bound was changed to obtain a preferred result.
Completed workers were not repeated.

V2 gate completed in3.4666728s. P/R/failedgate/V2 have3/4/3/3 private-memory
samples,max59064320/69201920/104816640/105271296 bytes;observations,not peaks.
Frozen600s/8GiB sampled/350MiB launch floor/16MiB stored-packet limits held.
Eleven source copies,1036/1044/1055 bindings and full captures remain. Fresh
THIS-goal-turn research_check e4 completed with steps0,0,0,0,0,2. Historical
custody remains exit2/seven NOTPASS. New byte preflights and old bytes/state
checks are separate from scientific qualification.

The first external precommit seal also failed on an engineering template
assumption:it expected a separate preparation_v2 subprocess capture,while
this V2 freezes its verifier inline. Original seal source/failure are retained
externally;seal_v2 checks the actual inline manifest/preflight and existing
preparation capture. No scientific gate,coefficient or capture was altered.

Track B: independent finite derivation and a structural color cancellation
corrected an unjustified nonzero expectation. Verification should test the
actual question,not assume the desired answer's sign or support. Shared action,
inherited independent color data,regulator assumptions,software and AI author
remain common-error risks;this is not external or experimental confirmation.

## Next scientific question

The lower finite source/vector input is now available. The immediate higher-
value step is to derive the ACTUAL finite heat/dimensional comparison of
the proper auxiliary matter-source vertex,not fit a counterterm from this
new current or repeat the already refuted unchanged naive direct sum.
Its old MAS angular factor retains the fixed four-barred numerator4/D;
the full nonzero finite dimension/heat term must be computed with that
precise chiral reference. Compare only after independent derivation.

The complete bosonic vector-source inputs now consist of BSF's derivative
jet,the ordinary SVC/SVT vector tensor and this lower family. Other bosonic
scalar-source jets and the complete coupled chiral regulator conversion
remain obligations. No full affine Ward,Slavnov,QAP/products/measure/phase,
physical scheme,massiveC1,E5/A5 or unification is qualified here. Two adverse
scalar points,quartetFAIL,flavorpause,HB1/C5blocks,custody and all distinct
free constants remain. No state,old evidence,physical input,branch/worktree,
publication/outreach or remote push changed.
