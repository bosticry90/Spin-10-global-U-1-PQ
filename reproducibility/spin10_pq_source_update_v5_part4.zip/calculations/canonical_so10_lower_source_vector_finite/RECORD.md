# LSF1: lower auxiliary gauge-source/vector finite family

Basee6aeb51f33fd539c9eadda19b59e986415f781ec/main32221oldblobs. Current
AGENTS,state113/34of39,wholegoal ACTIVE. Previous goal turn PROGRESS: the
ordinary finite source/vector family and its actual structure transport were
qualified. Complete the lowerg2*xi JB V C family before testing their joint
coupled matter-Euler effect. This is not a new physical benchmark or rescue fit.

Use the actual qualified frozen_a10_e5_gauge_source_partner calculation:
five complete unit variants ghost:a/c/B,aux,YM, all16 Lorentz pairs and
all ordered Born/Wick words. The full YM interaction is required. Target
J_B(d2,gh-1),V(d1,gh0),C(d1,gh1),zero jets and coefficient dimension0.
All five variants are triangles with scalar heat length6. Coupling factors
are g10^2*xi for the bosonic source and -i*g10^3*xi for its matter current,
in common1/(16pi^2) units. Xi is FACTORED OUT,not omitted or included twice.
No physical parameter,finite normalization or gauge width is chosen.

First calculate new complete unintegrated unit kernels with the historical
action vertices:primary graded Born and replay routed Gaussian Wick. Extract
the full covariant tensor A delta/Q²+B kk/Q³ pointwise at all80 positions
before angular projection. The metric-natural D lift must be justified by
dimension-free contractions,not inferred from a D4 pole. Keep possible
width dependence until the complete kernel has actually eliminated it.

Only if the resulting finite unit map is proportional to each stored
resolved color-family unit may the old independent color tables supply the
actual color contractions. Otherwise stop that assembly as needing finer
color data;never infer missing dimension/finite structure from a total pole.
Ghost:a/c must have the same finite-to-pole ratio before using their stored
combined ghost family. DERIVATION gives the proposed criterion and map.
No target Ward remainder is read or fitted.

Compute chi4/log(3/2)/fixed directions separately in the old H-adapted frame,
then use SVT's verified source/primal bridge into the actual BSF/GTT frame.
Primary uses direct matrix transport;replay uses raw-C3 pullback/pushforward.
Retain complete45 B/12 A_H source/ghost tensors,all zeros,actual T/U currents,
reality,right relation,H covariance and round trips. Reuse the qualified
metric scalar finite-integral comparison,without claiming a physical massless
zero-momentum amplitude or a gamma5 continuation of the bosonic lift.

Freeze eight sources/copies,inputs,proof,expected failures and caps before
sequential P/R/gate:600s afterimports each,8GiB sampledprivate,350MiB available
commit floor,16MiB stored packet. Fresh current-goal-turn research_check e4
and byte preflight;custody2/seven NOTPASS. Firstfailure stops;all failed and
unfinished sources/captures preserved,version corrections only. No agents,
resource expansion,truncation,unnecessary expensive qualified replay.

Expected qualified result:complete selected relative finite lower family,
with its induced matter current. Alternative:finite-color data insufficient,
incompatible unit methods,invalid metric lift or bounded incompleteness.
None alone establishes a physical anomaly. All common-action/data/software/
AI-authorship limits remain;agreement is internal corroboration.

Ceiling excludes joint coupled cancellation,full background/Slavnov,QAP/
products/measure/phase,physical chiral prescription,massiveC1,E5/A5 and GUT
viability. Bothscalarwarnings,quartetFAIL,flavorpause,HB1/C5blocks,custody
and distinct freeconstants remain. Preserve main/state/oldbytes;no branches,
physical adoption,publication/outreach/push. If qualified,continue the actual
combined vector-source/Euler compatibility test before a large new expansion.
