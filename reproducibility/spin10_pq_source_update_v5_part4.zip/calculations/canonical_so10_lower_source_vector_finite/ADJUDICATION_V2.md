# LSF1 V2: test the actual fixed cancellation,not the failed nonzero expectation

Both original scientific workers completed. They derived matching unit
kernels and actual finite tensors. The separate original gate FAILED native1
at its prospective assertion that the fixed total be nonzero. All earlier
peer,unit,zero-complement,frame,current and covariance checks completed.
Do not relabel that original gate PASS or overwrite its source/capture.

Nonzero fixed total was an unjustified expectation,not an external physical
requirement. The frozen research question was the value of the complete
finite family. A measured zero is a legitimate scientific outcome,provided
the full contributions cancel and their omission controls remain sensitive.
Preserve the nonzero conjecture as refuted within this scope. No quantum
coefficient or method may be adjusted to make a desired answer.

Prospective new V2 claim:the COMPLETE fixed tensor is exactly zero. With the
independently derived finite ratios ghost/aux=1/4 and YM=-1/12,this is
equivalent to the complete old-frame identity YM=3*(ghost+aux). Test that
identity explicitly at every coefficient in BOTH completed routes,and
separately test the resulting fixed source/current tensors and all implied
zeros after transport. Require nonzero individual contributions and show
that omitting YM,ghost or auxiliary spoils the collective cancellation.
The chi4/log(3/2) total must remain independently checked and nonzero.

Keep every original unit,zero complement,current,frame,H-covariance and
outer-coupling requirement. No scientific input,source order,normalization,
width,scope or resource bound changes. This is qualification of a different
observed value with a stronger explicit cancellation theorem;the old
nonzero expectation remains FAILED. Do not rerun completed workers.

Freeze this record,new verifier/driver and immutable completed outputs,
full original failed capture/controller before V2 gate. Same600s afterimports,
8GiB sampledprivate,350MiB launch floor,16MiB stored packet. Current-goal-turn
fresh E4 is honestly reused,new byte preflight. Firstfailure stops. No full
coupled cancellation or physical scheme may be inferred from this one zero.
