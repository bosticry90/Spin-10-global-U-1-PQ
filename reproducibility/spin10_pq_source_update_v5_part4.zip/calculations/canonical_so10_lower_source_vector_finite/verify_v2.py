"""LSF1 complete finite lower-family gate with old units withheld to validation."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz');ctl=packed(HERE/'validation_control_inputs.json.gz')
for k in ['unit_coefficients','complete_unintegrated_kernels','old_groups','old_totals','finite_tensors','matter_current_coefficients','current_kernel_sum_remainder','new_model_color_path_recalculation','finite_color_reuse_criterion_satisfied','bosonic_overall_factor','matter_overall_factor','xi_factored_out_exactly_once']:assert P[k]==R[k],k
unit_controls={};unit_positions=0
for f,rows0 in P['complete_unintegrated_kernels'].items():
 assert f in FAMILIES and len(rows0)==16;u=P['unit_coefficients'][f];a=parse(u['A']);b=parse(u['B']);v=parse(u['u4']);fixed=parse(u['fixed']);check_kernel(rows0,a,b)
 assert tidy(parse(u['u_D'])-a-b/DD)==0 and tidy(fixed-b/8)==0 and not (a.free_symbols|b.free_symbols) and u['heat_length']==6
 for nu,mu,old in ctl['unit_poles'][f]:assert tidy(parse(old)-2*v*int(nu==mu))==0;unit_positions+=2
 if v:assert tidy(parse(u['finite_to_UV32_ratio'])-fixed/(2*v))==0
 else:assert a==b==fixed==0
 unit_controls[f]={'omit_dimension_jet':str(-fixed),'wrong_heat6_to4_log_coefficient':str(-v),'finite_jet_nonzero':bool(fixed!=0)}
assert unit_positions==160 and all(unit_controls[f]['finite_jet_nonzero'] for f in ['ghost:a','ghost:c','aux','YM'])
assert P['unit_coefficients']['ghost:a']['finite_to_UV32_ratio']==P['unit_coefficients']['ghost:c']['finite_to_UV32_ratio']
for index in range(16):assert tidy(sum(parse(P['complete_unintegrated_kernels'][f][index][2]) for f in ['ghost:a','ghost:c','ghost:B']))==0
# Complete dimension-free transverse identity;these finite witnesses supplement
# the algebraic all-D proof,not replace it by a fitted rank extrapolation.
for n in [2,3,5]:
 k=sy.Matrix(range(1,n+1));q=(k.T*k)[0];pr=k*k.T/q;wy=sy.Symbol('unfixed_width');proj=sy.eye(n)+(wy-1)*pr
 assert all(tidy(z)==0 for z in proj*(pr-sy.eye(n))-(pr-sy.eye(n)))
fr=d['frame'];L=dec(fr['L']);Li=dec(fr['Li']);am=dec(fr['Aold_from_Anew']);T=list(map(dec,d['Y']['Tminus']));HF=dec(d['Y']['H_new']);f=[Mat(45,45) for _ in range(45)]
for a,b,e,z in d['plane_f']:f[a].d[e,b]=Q(z)
fh=[]
for h in range(12):
 m=Mat(45,45)
 for (a,hh),z in HF.d.items():
  if hh==h:m=plus(m,scale(f[a],z))
 fh.append(m)
counts={};current_counts={};covariance_checks=0;positions=0;family_counts={}
for part,ks in P['finite_tensors'].items():
 counts[part]={};current_counts[part]={};family_counts[part]={tag:len(rows0) for tag,rows0 in P['old_groups'][part].items()}
 for kind,rows0 in ks.items():
  n=45 if kind=='B' else 12;v=bridge.decoded_tensor(rows0);old=bridge.decoded_tensor(P['old_totals'][part][kind]);assert bridge.matrix_transport(v,Li,L if kind=='B' else trans(am),L)==old
  assert all(0<=i<45 and 0<=b<n and 0<=c<45 and conj(z)==z for (i,b,c),z in v.items());counts[part][kind]=len(v);positions+=45*n*45
  if part in ['chi4','log3over2']:assert old==scale_tensor(bridge.decoded_tensor(ctl['old_totals'][kind]),Q('1/2'))
  if kind=='A':assert not old and not v
  mats=[Mat(45,45) for _ in range(n)]
  for (i,b,c),z in v.items():mats[b].d[i,c]=z
  if kind=='B':
   for h in range(12):
    for b,m in enumerate(mats):
     residual=minus(mul(fh[h],m),mul(m,fh[h]))
     for e in range(45):
      z=fh[h].d.get((e,b),Z)
      if z:residual=minus(residual,scale(mats[e],z))
     zero(residual);covariance_checks+=1
  ims=P['matter_current_coefficients'][part][kind];left={(b,c):dec(m) for b,c,m in ims['left']};right={(b,c):dec(m) for b,c,m in ims['right']};assert set(left)==set(right)
  assert ims['left']==bridge.current(v,T,n)
  for key,m in left.items():zero(minus(m,trans(star(m))));zero(plus(right[key],trans(m)))
  current_counts[part][kind]={'left':sum(len(m.d) for m in left.values()),'right':sum(len(m.d) for m in right.values())}
assert positions==346275 and covariance_checks==1620 and P['finite_tensors']['chi4']==P['finite_tensors']['log3over2']
# The original nonzero-fixed expectation failed; this independently tests
# its explicit alternative, retaining the original gate and all its inputs.
assert not any(counts['fixed'].values()) and any(counts['chi4'].values())
assert read(HERE/'verify_capture.json')['exit_code']==1
fixed_cancellation={};fixed_omissions={}
for route in [P,R]:
 groups=route['old_groups']['fixed'];pieces={tag:bridge.decoded_tensor(rows0) for tag,rows0 in groups.items()}
 assert any(pieces['ghost_B'].values()) and any(pieces['aux_B'].values()) and any(pieces['YM_B'].values())
 zero_sum=sum_tensor(*pieces.values());assert not zero_sum
 # These are measured oldUV tensors after unit conversion,not targets:
 # fixedGhost+fixedAux+fixedYM=0 <=> UV_YM=3(UV_ghost+UV_aux).
 old_input=packed(HERE/(route['role']+'_inputs.json.gz'))['old_families']
 for kind in ['A','B']:
  ghost=bridge.decoded_tensor(old_input['ghost_'+kind][kind]);aux=bridge.decoded_tensor(old_input['aux_'+kind][kind]);ym=bridge.decoded_tensor(old_input.get('YM_'+kind,{'A':[],'B':[]})[kind])
  assert not sum_tensor(ym,scale_tensor(sum_tensor(ghost,aux),Q(-3)))
 for tag in ['ghost_B','aux_B','YM_B']:
  remaining=sum_tensor(*(v for k,v in pieces.items() if k!=tag));assert remaining
  fixed_omissions[tag]=len(remaining)
 for kind in ['A','B']:
  assert not route['finite_tensors']['fixed'][kind] and not route['matter_current_coefficients']['fixed'][kind]['left'] and not route['matter_current_coefficients']['fixed'][kind]['right']
 fixed_cancellation[route['role']]=True

assert P['xi_factored_out_exactly_once'] and P['bosonic_overall_factor']=='g10^2*xi/(16*pi^2)' and P['matter_overall_factor']=='-I*g10^3*xi/(16*pi^2)'
for x in [P,R]:assert x['finite_color_reuse_criterion_satisfied'] and not any(x[k] for k in ['new_model_color_path_recalculation','physical_scheme_adopted','quantum_coefficient_fitted','coupled_cancellation_claimed','new_model_loop_integrals'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_LOWER_AUXILIARY_SOURCE_VECTOR_FINITE_FAMILY','original_nonzero_fixed_expectation':'REFUTED_ORIGINAL_GATE_FAILED_PRESERVED','complete_fixed_color_and_current_tensor_zero':True,'old_UV_YM_equals_three_ghost_plus_aux':fixed_cancellation,'fixed_family_omission_nonzero_counts':fixed_omissions,'elapsed_after_imports':time.perf_counter()-start,'unit_variants':5,'complete_unintegrated_positions_per_route':80,'old_UV_unit_positions_compared':unit_positions,'finite_color_roundtrip_positions':positions,'all_family_coefficients_and_zero_complements_match':True,'homogeneous_H_covariance_matrix_checks':covariance_checks,'unit_coefficients':P['unit_coefficients'],'unit_controls':unit_controls,'new_color_nonzero_counts':counts,'old_family_nonzero_counts':family_counts,'matter_current_nonzero_counts':current_counts,'background_A_selected_channel_zero':True,'xi_factored_out_exactly_once':True,'bosonic_overall_factor':P['bosonic_overall_factor'],'matter_overall_factor':P['matter_overall_factor'],'common_chi4_remains_symbolic':True,'fresh_finite_units_and_reassembly_only':True,'new_model_color_paths_or_loop_integrals_recomputed':False,'coupled_cancellation_claimed':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'scientific_authority_changed':False,'full_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
