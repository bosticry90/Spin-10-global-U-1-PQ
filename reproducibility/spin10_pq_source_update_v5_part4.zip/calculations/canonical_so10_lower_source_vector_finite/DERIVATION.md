# LSF1: complete mixed-propagator kernels before finite color reuse

Keep the inherited source order Je Be Ce and full ordered mixed BL/LB
propagators. Extract each kernel in the same fixed Wick normalization as SVF:

 -i[A delta_(nu,mu)t²+B eta_(mu,mu) k_nu k_mu t³],t=1/Q.

The two ghost-derivative placements each contain one mixed-propagator k
and one derivative k,so their full natural tensor is proportional to kk/Q.
The external Be derivative vanishes at this zero-jet Taylor coefficient.
The auxiliary route contains two mixed k factors and is also proportional
to kk/Q. These statements fix the invariant tensor language,not its sign
or coefficient;derive those from every Born/Wick word.

In the full YM route,the mixed leg supplies k at the literal cubic vertex.
At incoming momenta(0,k,-k),that contraction is kk^T-QI. It is transverse,
so its contraction with the source ordinary-vector projector eliminates
the longitudinal width pointwise. No closed numeric Lorentz trace is
formed in any of these tensor graphs. These are dimension-free identities,
not a proposed lift recovered from an angular D4 numerical value.

For the complete tensor,u_D=A+B/D and the actual heat length is6. Reusing
the qualified common-IR Schwinger/Gamma comparison from SVF gives

 finite=(chi4+log(3/2))*u4+B/8.

The1/8 is the real tensor finite difference;discarding the first dimension
jet loses it. Primary uses the rational D-sphere recurrence;replay uses its
independent Dirichlet/Gamma moment and dimension differentiation. The actual
finite-integral normalization and common IR subtraction are qualified reuse,
not new physical scale or mass choices. No positive-external-jet heat term
can enter this dimension4 zero-jet coefficient.

Let v32=2u4 be a NONZERO CONSTANT unit,after widths have actually canceled
pointwise. Then a completely resolved old color family V32 may be transported
with coefficients V32/2 for both chi4 and log(3/2),and V32*(B/8)/v32 for
the remaining fixed term. This division is by a derived rational unit,not a
coupling,width,mass or fitted quantum coefficient. Require ghost:a/c ratios
equal before applying the same map to the combined old ghost contribution.
If any of these premises fails,the stored group pole is insufficient and
this finite-color assembly must remain incomplete.

The old source/vector action uses exactly the historical physical_model
source/primal charts verified in SVT. Its reported coefficients strip
g10²*xi ONCE. Apply the already verified tensor and background12 maps to
both independent color routes. Use actual T and U=-T.T for the induced
matter current;retain the overall -i*g10³*xi separately. A computed Euler
companion is not an independently measured compensating quantum insertion.
