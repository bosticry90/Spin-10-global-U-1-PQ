"""LSF1 actual lower-family packets and freshly executed E4 readiness."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/lower-source-vector-finite-v1-2026-10-23');PRED=CAL/'canonical_so10_source_vector_finite_transport'
BASE='e6aeb51f33fd539c9eadda19b59e986415f781ec';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32221
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt_v2.json','verify_v2_capture.json','RESULT.md','validation_preparation_v2.json','primary_v2_tables.json.gz','replay_v2_tables.json.gz']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V541.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_source_vector_g3_color',['color.py','color.py.source.txt','RECORD.md','RESULT.md','primary_result.json','replay_result.json','validation_receipt.json','preparation.json']),('canonical_so10_source_vector_g3_inputs',['primary_result.json','replay_result.json','validation_receipt.json','inputs.py','RECORD.md'])]:
 for n in names:add(CAL/folder/n)
# Bind reused Python helpers under their recorded historical hashes; do not
# substitute live policy for old policy or reinterpret an old manifest.
for folder in ['canonical_so10_source_vector_g3_color','canonical_so10_source_vector_g3_inputs']:
 for p,h in read(CAL/folder/'preparation.json')['input_sha256'].items():
  if Path(p).suffix=='.py':assert digest(Path(p))==h,p;bind[p]=h
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';OLD=PK/'frozen_a10_e5_gauge_source_partner'
for n in ['a10_e5_gauge_source_partner.py','a10_e5_gauge_source_partner_control.py']:add(PK/n)
for n in ['primary.json','replay.json','controls.json','validation_receipt.json','bindings.json']:add(OLD/n)
for rel,h in read(OLD/'bindings.json')['byte_sha256'].items():
 if Path(rel).suffix=='.py':
  q=ROOT/rel;assert digest(q)==h,rel;add(q)
assert read(OLD/'validation_receipt.json')['actual_gauge_source_partners_qualified']
assert read(PRED/'validation_receipt_v2.json')['status']=='QUALIFIED_FINITE_SOURCE_VECTOR_STRUCTURE_TRANSPORT'
for role in ['primary','replay']:
 v=packed(PRED/(role+'_v2_tables.json.gz'));prior=packed(PRED/(role+'_inputs.json.gz'));old=read(OLD/(role+'.json'))
 gz(HERE/(role+'_inputs.json.gz'),{'old_families':old['family_poles'],'frame':{k:v[k] for k in ['L','Li','Qold','Qold_inverse','Aold_from_Anew']},'new':{k:prior['new'][k] for k in ['Qchart','Qi']},'Y':prior['Y'],'plane_f':prior['plane_f']})
 add(HERE/(role+'_inputs.json.gz'))
co=read(OLD/'controls.json');old=read(OLD/'primary.json');gz(HERE/'validation_control_inputs.json.gz',{'unit_poles':co['unit_pole_Lorentz_matrices'],'old_totals':{'A':old['actual_pole_A'],'B':old['actual_pole_B']}});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
assert r.returncode==0
dump(CONTROL/'readiness_result.json',{'command':['python','-B','tools/research_check.py','e4'],'native_exit':r.returncode,'fresh_command':True,'scientific_replay_requested':False,'custody_expected_exit':2,'custody_expected_unresolved':7,'scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and not d['active_A10_M08_python_processes'] and d['files_written']==0
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'LSF1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('LSF1_FROZEN',len(bind),'bindings',flush=True)
