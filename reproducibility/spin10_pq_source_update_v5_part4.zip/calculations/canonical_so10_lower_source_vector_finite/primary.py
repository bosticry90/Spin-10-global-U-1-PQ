"""LSF1 all ordered Born kernels,D recurrence and direct physical transport."""
from data import *
start=begin('primary');kernels={};units={}
for f in FAMILIES:
 raw=[]
 for nu in range(4):
  for mu in range(4):raw.append([nu,mu,str(sy.expand(lib.born(f,nu,mu).as_expr()))])
 a,b=extract(raw);assert not (a.free_symbols|b.free_symbols),'FINITE_COLOR_NEEDS_FURTHER_WIDTH_RESOLUTION'
 u=tidy(a+b/DD);v=tidy(u.subs(DD,4));jet=tidy(-2*sy.diff(u,DD).subs(DD,4));ratio=tidy(jet/(2*v)) if v else sy.S.Zero
 units[f]={'A':str(a),'B':str(b),'u_D':str(u),'u4':str(v),'fixed':str(jet),'finite_to_UV32_ratio':str(ratio),'heat_length':6};kernels[f]=raw
 print('STAGE UNIT',f,units[f],flush=True)
for i in range(16):assert tidy(sum(parse(kernels[f][i][2]) for f in ['ghost:a','ghost:c','ghost:B']))==0
# Qualified old color coefficients are interpreted only after the complete
# finite units have passed their pointwise and constant-ratio premises.
d=packed(HERE/'primary_inputs.json.gz');groups,totals=prepare_coefficients(d,units);fr=d['frame'];L=dec(fr['L']);Li=dec(fr['Li']);am=dec(fr['Aold_from_Anew']);T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];new={};images={}
for part,ks in totals.items():
 new[part]={};images[part]={}
 for kind,n,bm in [('B',45,Li),('A',12,am)]:
  v=bridge.matrix_transport(ks[kind],L,bm,Li);new[part][kind]=bridge.packed_tensor(v);images[part][kind]={side:bridge.current(v,ts,n) for side,ts in [('left',T),('right',U)]}
finish('primary',{'method':'all_Born_kernels_D_recurrence_then_resolved_color_map_and_direct_transport','unit_coefficients':units,'complete_unintegrated_kernels':kernels,'old_groups':groups,'old_totals':{p:{k:bridge.packed_tensor(t) for k,t in v.items()} for p,v in totals.items()},'finite_tensors':new,'matter_current_coefficients':images,'current_kernel_sum_remainder':0,'new_model_color_path_recalculation':False,'finite_color_reuse_criterion_satisfied':True},start)
