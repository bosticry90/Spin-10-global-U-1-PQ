"""LSF1 complete mixed unit kernels,exact color ring and qualified frame reuse."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading,importlib.util
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PK));sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
import a10_e5_gauge_source_partner_control as lib
spec=importlib.util.spec_from_file_location('lsf_qualified_transport',CAL/'canonical_so10_source_vector_finite_transport/data_v2.py');bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
KS=sy.symbols('k0:4',real=True);tt=sy.Symbol('t');WX,WY=sy.symbols('width_X width_Y');DD=sy.Symbol('D');ETA=[1,-1,-1,-1];QQ=sum(e*k*k for e,k in zip(ETA,KS));FAMILIES=['ghost:a','ghost:c','ghost:B','aux','YM']
def parse(z):return sy.sympify(z,locals={**{str(k):k for k in KS},'t':tt,'width_X':WX,'width_Y':WY})
def tidy(z):return sy.factor(sy.cancel(z))
def check_kernel(raw,a,b):
 for nu,mu,z in raw:
  target=-sy.I*(a*int(nu==mu)*tt**2+b*ETA[mu]*KS[nu]*KS[mu]*tt**3)
  p=sy.Poly(sy.expand(parse(z)-target),tt);n=p.degree() if not p.is_zero else 0
  assert sy.Poly(sy.expand(sum(co*QQ**(n-e[0]) for e,co in p.terms())),*KS).is_zero,(nu,mu)
def extract(raw):
 point={k:sy.Integer(i+1) for i,k in enumerate(KS)};cells={(nu,mu):parse(z).subs(tt,1/QQ) for nu,mu,z in raw}
 b=tidy((sy.I*cells[0,1]*QQ**3/(ETA[1]*KS[0]*KS[1])).subs(point));a=tidy((sy.I*cells[0,0]*QQ**2-b*KS[0]**2/QQ).subs(point));check_kernel(raw,a,b)
 return a,b
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('LSF1_PEER_OR_OLD_UNIT_DENIED')
   if p.parent.name=='frozen_a10_e5_gauge_source_partner' and p.suffix=='.json':raise PermissionError('LSF1_OLD_POLE_OR_TARGET_DIRECT_READ_DENIED')
 sys.addaudithook(audit);return start
def sum_tensor(*ps):
 out={}
 for p in ps:
  for k,z in p.items():out[k]=add(out.get(k,Z),z)
 return {k:z for k,z in out.items() if z}
def scale_tensor(p,z):return {k:prod(v,z) for k,v in p.items() if prod(v,z)}
def prepare_coefficients(d,units):
 ratios={n:sy.sympify(u['finite_to_UV32_ratio']) for n,u in units.items() if u['u4']!='0'}
 assert ratios['ghost:a']==ratios['ghost:c'] and all(not r.free_symbols for r in ratios.values())
 groups={part:{} for part in ['chi4','log3over2','fixed']};totals={part:{k:{} for k in ['A','B']} for part in groups}
 for tag,ks in d['old_families'].items():
  family='YM' if tag.startswith('YM') else 'aux' if tag.startswith('aux') else 'ghost:a';kind=tag[-1]
  assert kind in ['A','B'] and not ks['A' if kind=='B' else 'B']
  p=bridge.decoded_tensor(ks[kind]);factors={'chi4':Q('1/2'),'log3over2':Q('1/2'),'fixed':Q(str(ratios[family]))}
  for part,z in factors.items():
   v=scale_tensor(p,z);groups[part][tag]=bridge.packed_tensor(v);totals[part][kind]=sum_tensor(totals[part][kind],v)
 return groups,totals
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','bosonic_overall_factor':'g10^2*xi/(16*pi^2)','matter_overall_factor':'-I*g10^3*xi/(16*pi^2)','xi_factored_out_exactly_once':True,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'coupled_cancellation_claimed':False,'new_model_loop_integrals':0})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
