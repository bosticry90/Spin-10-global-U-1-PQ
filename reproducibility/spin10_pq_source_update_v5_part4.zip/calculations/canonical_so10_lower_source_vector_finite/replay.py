"""LSF1 routed Wick kernels,Dirichlet moment and raw-C3 tensor transport."""
from data import *
start=begin('replay');kernels={};units={}
moment=sy.combsimp(sy.gamma(DD/2)*sy.gamma(sy.Rational(3,2))/(sy.gamma(DD/2+1)*sy.gamma(sy.Rational(1,2))));assert tidy(moment-1/DD)==0
for f in FAMILIES:
 raw=[]
 for nu in range(4):
  for mu in range(4):raw.append([nu,mu,str(sy.expand(lib.wick(f,nu,mu).as_expr()))])
 a,b=extract(raw);assert not (a.free_symbols|b.free_symbols),'FINITE_COLOR_NEEDS_FURTHER_WIDTH_RESOLUTION'
 u=tidy(a+b*moment);v=tidy(u.subs(DD,4));fixed=tidy(-2*sy.diff(u,DD).subs(DD,4));ratio=tidy(fixed/(2*v)) if v else sy.S.Zero
 # Independent scalar/tensor integral comparison from the qualified SVF
 # IR-completed Gamma/Schwinger calculation: delta*chi6, kk*(chi6/4+1/8).
 chi=sy.Symbol('chi6');assert tidy((a*chi+b*(chi/4+sy.Rational(1,8)))-(v*chi+fixed))==0
 units[f]={'A':str(a),'B':str(b),'u_D':str(u),'u4':str(v),'fixed':str(fixed),'finite_to_UV32_ratio':str(ratio),'heat_length':6};kernels[f]=raw
 print('STAGE UNIT',f,units[f],flush=True)
for i in range(16):assert tidy(sum(parse(kernels[f][i][2]) for f in ['ghost:a','ghost:c','ghost:B']))==0
d=packed(HERE/'replay_inputs.json.gz');groups,totals=prepare_coefficients(d,units);fr=d['frame'];qo=dec(fr['Qold']);qi=dec(fr['Qold_inverse']);newQ=dec(d['new']['Qchart']);newQi=dec(d['new']['Qi']);am=dec(fr['Aold_from_Anew']);T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];new={};images={};raw_counts={}
for part,ks in totals.items():
 new[part]={};images[part]={};raw_counts[part]={}
 for kind,n in [('B',45),('A',12)]:
  mid=bridge.path_transport(ks[kind],qi,qo if kind=='B' else ident(12),qo);raw_counts[part][kind]=len(mid)
  v=bridge.path_transport(mid,newQ,newQi if kind=='B' else am,newQi);new[part][kind]=bridge.packed_tensor(v);images[part][kind]={side:bridge.current(v,ts,n) for side,ts in [('left',T),('right',U)]}
finish('replay',{'method':'all_routed_Wick_kernels_Dirichlet_moment_old_independent_colors_raw_transport','unit_coefficients':units,'complete_unintegrated_kernels':kernels,'old_groups':groups,'old_totals':{p:{k:bridge.packed_tensor(t) for k,t in v.items()} for p,v in totals.items()},'finite_tensors':new,'matter_current_coefficients':images,'current_kernel_sum_remainder':0,'new_model_color_path_recalculation':False,'finite_color_reuse_criterion_satisfied':True,'raw_intermediate_counts':raw_counts},start)
