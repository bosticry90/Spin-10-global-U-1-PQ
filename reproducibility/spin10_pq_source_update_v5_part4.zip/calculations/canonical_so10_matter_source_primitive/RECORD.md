# MSP1: construct the measured source breaking's primitive

Previous goal turn PROGRESS: CMS1 measured all32 selected bare KccP
supports, and MSC1 verified that both resulting Lie-valued two-cochains
are closed. The whole Spin(10)xPQ investigation remains active/incomplete.
Base77532dba14bc19e09dad3083dcf04d6d790df59f/main31386 tracked blobs.

Question: does the actual measured source tensor have an explicit local,
real, residual-H-covariant polynomial source primitive? Construct it from
the Lie-module Casimir, then verify the entire source image. Keep the
correlated source-free Euler term; do not interpret a selected primitive
as full finite quantum restoration. This is more informative than another
coefficient inventory because it tests removability of an existing complete
selected breaking. Success, a nonzero image/admissibility remainder or a
bounded construction failure are meaningful outcomes.

Freeze actual current AGENTS/CHARTER/state113/V521/local/solo/epistemic
rules, MSC1 paired r and f tensors/receipt, CMS1 paired full source
matrices/receipt, YCT actual generators/H frame/receipt, and SMA1 action,
source and Nambu/Euler conventions/receipt. Physical families remain I3;
no extra3, Nambu half or numerical Yukawa/flavor parameters. Couplings
and both gauge widths remain polynomial symbols. No desired cancellation
changes the independently measured input R.

Types follow SMA1's actual ghost-dimension1 convention: P dimension3/2,
K_P dimension3/2, c dimension1; the source counterterm K c X P has
dimension4/ghost0, and its Slavnov image has dimension5/ghost1. K_P is
even, c/P/E_P odd. The elementary external-source rule qK_P=0 remains
unchanged. b_Sigma below is the linearized Slavnov/cotangent operation,
whose K_P component includes the matter Euler derivative; it is NOT a
replacement elementary BRST rule. Work at the mass-independent physical
external domain. Actual hatted/source-free Euler terms are retained in
operator form, not declared zero or independently matched to quantum loops.

For R_ab=i r_ab^e T_e, define rho_a X=-i[T_a,X]. Compute C_A from actual
generators, not a coefficient fitted to R. Candidate X_b=-(sum_a rho_a
R_ab)/C_A. Primary uses matrix commutators/Casimir, replay scalar adjoint
contractions and an exact normalization example. Directly test dX=R at
every990 external ghost pair and16x16 position for both g3/g4 inputs.
Source counterterm is C_src=-sum_p g^(p-1) K c X^[p] P/(16pi^2), p=3,4.
Thus no inverse g or width appears. This fixes one mathematical primitive,
not a unique finite physical normalization or an adopted scheme.

Admissibility: all coefficients real, source conjugate right=-left.T,
local/dimension4/ghost0, polynomial nonnegative g/width powers and local-H
covariance. Test all12 inherited H generators and both chiral source maps.
Use actual family identity, never a trace average. Show the non-source
descendant is +sum_p g^(p-1)c^a E_P X_a^[p]P/(16pi^2) in fixed ghost order,
with E_P the actual SMA1 variational derivative. The generic alternating
Gaussian and graded Euler calculus verify its sign and absence of a half;
do not expand a new huge scalar polynomial or drop boundary terms.

Independent controls: wrong Casimir/sign, omit ghost or module part,
ordinary source transpose instead of cotangent, drop an input order.
Report actual sensitivity. Derive Casimir/sign separately and compare the
actual fixed image; no scalar fit is permitted. A constructed primitive
may produce nonzero field descendants requiring later independent breaking
calculations. Their operator definition does not claim measured matching.

Freeze eight sources/copies and hashes before workers. Fresh research_check
e4 command in this NEW goal turn, without --fresh historical science, with
native full capture; expected step exits0,0,0,0,0,2 and custody seven NOTPASS.
Sequential workers600s after imports,8GiB sampled private cap,350MiB launch
floor,16MiB package. Compile prelaunch. Stop on first failure/exhaustion,
preserve full sources/captures and version routine corrections. No agents,
new branch/worktree,reset,remote push,publication or outreach.

Authority34/39 unchanged; no E5/A5 promotion. Full finite chiral QAP,
connected products/measure/phase, cPP matching, ghost-source completion,
physical prescription and massive C1 remain unqualified. Preserve both
adverse scalar benchmarks, quartetFAIL, flavor pause, HB1/C5 blocks and
all historical evidence. Shared action/data/software/AI author are explicit
independence limits. No new general cohomology or physics claim is needed
from literature: actual finite matrix identities determine this result.
