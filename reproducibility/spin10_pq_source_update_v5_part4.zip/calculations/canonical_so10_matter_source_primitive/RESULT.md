# MSP1: explicit local primitive for the complete selected source breaking

The actual measured KccP breaking has an explicit selected source primitive.
Both frozen methods and the independent gate completed with native exit0.
Receipt SHA256:
`c0e178079368b7f841ef0c44d2b76035a289a761dc8d427b4a6a4732119638c2`.
Disposition `CONSTRUCTED_SELECTED_LOCAL_SOURCE_PRIMITIVE`.
State113 and authority34/39 remain unchanged; no physical scheme is adopted.

## Constructed result

From the actual matrices, both methods independently derive C_A=8. For
each measured coupling component R^[p], p=3,4, define

`X_b^[p]=-(1/8) sum_a rho_a R_ab^[p]`, with `rho_a X=-i[T_a,X]`.

The complete actual source image satisfies `dX^[p]=R^[p]`, with zero
remainder at every990 ghost pair and every16x16 entry, including zeros and
both source chiralities. No normalization was solved from a desired image:
the Casimir follows from the generator matrices/adjoint contraction, and
the sign is independently fixed by a nonzero exact cochain example.

Each X uses105 nonzero scalar color coefficients. At g10^3 the left/right
primitive matrices each have592 nonzero entries; at g10^4 they each have720.
They reproduce the measured8,768/10,368 nonzero image entries per chirality.
The gate compares2,027,520 matrix positions across complete/module/ghost
images and46,080 primitive positions. These are exact algebraic positions.

The restoring source term can therefore be written, within this selected
formal domain, as

`C_src=-(1/(16pi^2)) sum_p g10^(p-1) K_P c^a X_a^[p] P`.

Its selected linearized Slavnov source image is minus CMS1's measured
KccP breaking. The source coefficients carry g10^2 and g10^3, with no
inverse coupling, width, mass or scale. The primitive is local,
dimension4/ghost0 under the actual ghost-dimension1 convention. Its
coefficients are real polynomials in the widths. All12 local-H covariance
tests have zero remainders. The right source matrix is independently
constructed as minus the transpose of the left; both are anti-Hermitian.
The three-family extension is I3 without an extra multiplicity or half.

## Essential companion and scope

This is a primitive for a selected source component, not a completed full
counterterm action or renormalized quantum prescription. The elementary
external-source rule qK_P=0 has not changed. The source-cotangent operation
used here belongs to the linearized Slavnov operator b_Sigma; its K_P
variation includes the actual matter Euler derivative.

Consequently the complete image also contains

`+(1/(16pi^2)) sum_p g10^(p-1) c^a E_i X_a,ij^[p] P_j`,

where `E_P=C(D_phys P+hat_gamma.partial_hat S)` and D_phys retains the
actual kinetic, gauge and symbolic scalar-Yukawa operator of SMA1. This
term is retained in Euler form, including its derivative, gauge, scalar
and hatted-auxiliary content. It is not set to zero by an early source/hat
projection or unrecorded integration by parts. The generic alternating
Grassmann calculation checks its sign and the absence of a Nambu half.

Its equality to the independently measured complete cPP/cBPP/cxPP quantum
breaking is not established here. In particular, source cancellation alone
does not establish simultaneous finite Slavnov restoration. No uniqueness
or physical baseline follows from choosing this mathematical primitive;
b0,kappa,zeta and other normalization freedoms remain separate.

## Verification and execution

Primary matrix Casimir/commutator homotopy and replay scalar adjoint
contractions give identical primitives and complete images. Controls with
a wrong Casimir half or restoring sign change8,768/10,368 left image
positions. Dropping the module part changes9,408/10,368; dropping the ghost
part changes4,736/5,760. Using an ordinary source transpose changes592/720
primitive positions. Removing a coupling order loses the full corresponding
measured component. The unit normalization example is independent of R.

Primary38.1063148s, replay20.1354307s and gate67.2053292s after imports.
Observed sample counts20/11/35; largest sampled private allocations
88,281,088/89,366,528/121,561,088bytes, not continuous peaks. All600s/8GiB
sampled/350MiB launch-floor/16MiB package bounds respected. Eight immutable
source copies,49 initial56 validation bindings. No frozen worker or gate
failure. No new one-loop or two-loop integration was performed: the quantum
input is the already measured complete selected source tensor.

A fresh `python -B tools/research_check.py e4` command ran in this new goal
turn, native0, expected step exits0,0,0,0,0,2. It did not request --fresh
historical scientific replay. Custody exit2 with seven unresolved remains
NOTPASS. Full readiness/captures and local seals are external under
`C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-source-primitive-v1-2026-10-23`.

The next meaningful test is the actual correlated field-breaking sector.
Use the complete IBS1 cPP inventory, retain the gauge/ghost/auxiliary
contributions and already measured Yukawa insertion, and derive its local
finite coefficient independently before comparison with this primitive's
Euler companions and the existing kinetic/vertex normalizations.

All old evidence, both distinct adverse scalar benchmarks, quartetFAIL,
flavor pause, HB1/C5 blocks, custody limitations and state bytes remain.
Full QAP/products/measure/phase, physical chiral reference, massive C1,
E5/A5 and physical unification remain unqualified. Shared assumptions,
action, data, software and AI authorship limit independent validation.
