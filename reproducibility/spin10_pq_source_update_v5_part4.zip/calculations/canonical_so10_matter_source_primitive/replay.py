"""MSP1 scalar adjoint homotopy, explicit coboundary and Berezin variation."""
from data import *
from collections import defaultdict
from itertools import combinations
start=begin('replay')
M=packed(CAL/'canonical_so10_matter_source_consistency/replay_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-v.T for v in T];HF=dec(Y['H_new'])
f={tuple(row[:3]):s.sympify(row[3]) for row in M['f']};fc=defaultdict(list)
for (a,b,e),co in f.items():fc[a,b].append((e,co))
def clean(tab):return {key:s.expand(co) for key,co in tab.items() if s.expand(co)!=0}
# Adjoint trace/Casimir contraction uses all45 generators, no measured input.
CA=[]
for a in range(45):
 for b in range(45):
  co=s.expand(sum(v*f.get((b,c,d),0) for (aa,c,d),v in f.items() if aa==a))
  if a==b:CA.append(co)
  else:assert co==0
assert len(set(CA))==1 and CA[0]!=0;casimir=CA[0]
r={p:{tuple(row[:3]):s.sympify(row[3],locals={'eta_H':WH,'xi':WM}) for row in rows} for p,rows in M['r'].items()}
def get(tab,a,b):return [(u,co if a<b else -co) for (c,d,u),co in tab.items() if (c,d)==tuple(sorted((a,b)))] if a!=b else []
def homotopy(tab):
 out=defaultdict(lambda:s.S.Zero)
 for b in range(45):
  for a in range(45):
   for u,co in get(tab,a,b):
    for e,h in fc[a,u]:out[b,e]-=h*co/casimir
 return clean(out)
def differential(xx):
 by=defaultdict(list)
 for (a,u),co in xx.items():by[a].append((u,co))
 module={};ghost={};total={}
 for a,b in combinations(range(45),2):
  mm=defaultdict(lambda:s.S.Zero);gg=defaultdict(lambda:s.S.Zero)
  for u,co in by[b]:
   for e,h in fc[a,u]:mm[e]+=h*co
  for u,co in by[a]:
   for e,h in fc[b,u]:mm[e]-=h*co
  for u,h in fc[a,b]:
   for e,co in by[u]:gg[e]-=h*co
  for e,co in clean(mm).items():module[a,b,e]=co
  for e,co in clean(gg).items():ghost[a,b,e]=co
  for e in set(mm)|set(gg):
   co=s.expand(mm[e]+gg[e])
   if co:total[a,b,e]=co
 return total,module,ghost
pairs=list(combinations(range(45),2))
def matrices(tab,generators):return [enc((s.I*sum((co*generators[e] for (a,b,e),co in tab.items() if (a,b)==(c,d)),s.zeros(16))).applyfunc(s.expand)) for c,d in pairs]
XL={};XR={};images={};imagesR={};modules={};ghosts={};cov={};xco={}
for power,tab in r.items():
 xx=homotopy(tab);xco[power]=[[a,e,str(co)] for (a,e),co in sorted(xx.items())]
 XL[power]=[enc((s.I*sum((co*T[e] for (b,e),co in xx.items() if b==a),s.zeros(16))).applyfunc(s.expand)) for a in range(45)]
 XR[power]=[enc((s.I*sum((co*U[e] for (b,e),co in xx.items() if b==a),s.zeros(16))).applyfunc(s.expand)) for a in range(45)]
 image,mm,gg=differential(xx);images[power]=matrices(image,T);imagesR[power]=matrices(image,U);modules[power]=matrices(mm,T);ghosts[power]=matrices(gg,T)
 cv=[]
 for h in range(12):
  for a in range(45):
   rem=defaultdict(lambda:s.S.Zero)
   for b in range(45):
    if not HF[b,h]:continue
    for (aa,u),co in xx.items():
     if aa==a:
      for e,v in fc[b,u]:rem[e]+=HF[b,h]*co*v
    for u,v in fc[b,a]:
     for (aa,e),co in xx.items():
      if aa==u:rem[e]-=HF[b,h]*v*co
   rem=clean(rem)
   if rem:cv.append([h,a,enc(s.I*sum((co*T[e] for e,co in rem.items()),s.zeros(16)))])
 cov[power]=cv
exact={(a,b,e):co for (a,b,e),co in f.items() if a<b};example=homotopy(exact)
assert example=={(a,a):s.S.One for a in range(45)}
# Exterior Gaussian action and actual LEFT derivative, with c indexed0.
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return clean(out)
def wedge(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(5) if a&(1<<i))*x*y
 return clean(out)
def derivative(A,i):return {k^(1<<i):(-1)**((k&((1<<i)-1)).bit_count())*v for k,v in A.items() if k&(1<<i)}
kk=s.symbols('k0:6');K=s.zeros(4);action={}
for co,(a,b) in zip(kk,combinations(range(4),2)):K[a,b]=co;K[b,a]=-co;action=add(action,wedge({1<<(a+1):1},{1<<(b+1):co}))
X=s.Matrix(4,4,s.symbols('x0:16'));actual={};expected={}
for i in range(4):
 E=derivative(action,i+1);assert E=={1<<(j+1):K[i,j] for j in range(4) if K[i,j]}
 for j in range(4):
  old=wedge(E,wedge({1:1},{1<<(j+1):-X[i,j]}));actual=add(actual,old)
  wanted=wedge({1:1},wedge(E,{1<<(j+1):X[i,j]}));expected=add(expected,wanted)
assert not add(actual,{k:-v for k,v in expected.items()}) and actual
finish('replay',{'method':'scalar_adjoint_Casimir_contraction_homotopy_explicit_coboundary_Berezin_Euler','adjoint_Casimir':str(casimir),'Casimir_per_generator':list(map(str,CA)),'x_coefficients':xco,'X_left':XL,'X_right':XR,'image_left':images,'image_right':imagesR,'module_left':modules,'ghost_left':ghosts,'H_covariance_remainders':cov,'normalization_example_remainder':'0','Euler_half_remainder':'0','Euler_odd_swap_sign':-1,'counterterm_source_unit':-1,'counterterm_Euler_companion_unit':1,'generic_Euler_companion_nonzero_positions':len(actual),'counterterm_g_powers':{'3':2,'4':3},'ghost_dimension':1,'P_dimension':'3/2','K_dimension':'3/2','counterterm_dimension':4,'breaking_dimension':5,'external_elementary_qK_changed':False,'full_quantum_matching_claimed':False,'scientific_authority_changed':False},start)
