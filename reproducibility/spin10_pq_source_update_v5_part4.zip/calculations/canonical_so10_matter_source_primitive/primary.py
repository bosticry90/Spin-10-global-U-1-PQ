"""MSP1 actual matrix Casimir/homotopy, complete source image and Euler signs."""
from data import *
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
start=begin('primary')
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-M.T for M in T];HF=dec(Y['H_new'])
def clean(tab):return {key:s.expand(co) for key,co in tab.items() if s.expand(co)!=0}
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
@lru_cache(None)
def comm(a,b):return (T[a]*T[b]-T[b]*T[a]).applyfunc(s.expand)
# Internal Casimir derives from every matrix, without a measured R coefficient.
CA=[]
for b in range(45):
 Z=sum((T[a]*comm(a,b)-comm(a,b)*T[a] for a in range(45)),s.zeros(16)).applyfunc(s.expand)
 value=s.simplify(s.trace(T[b]*Z)/s.trace(T[b]*T[b]));zero(Z-value*T[b]);CA.append(value)
assert len(set(CA))==1 and CA[0]!=0;casimir=CA[0]
basis=defaultdict(list)
for e,M in enumerate(T):
 for (i,j),co in M.todok().items():basis[j,i].append((e,co/(2*s.I)))
def project(M):
 out=defaultdict(lambda:s.S.Zero)
 for pos,co in M.todok().items():
  for e,u in basis[pos]:out[e]+=u*co
 out=clean(out);zero(M-s.I*sum((co*T[e] for e,co in out.items()),s.zeros(16)));return out
f=defaultdict(list)
for a,b in combinations(range(45),2):
 for e,co in project(comm(a,b)).items():f[a,b].append((e,co));f[b,a].append((e,-co))
MSC=packed(CAL/'canonical_so10_matter_source_consistency/primary_tables.json.gz');r={p:{tuple(row[:3]):s.sympify(row[3],locals={'eta_H':WH,'xi':WM}) for row in rr} for p,rr in MSC['r'].items()}
def homotopy(tab,generators):
 hh=[s.zeros(16) for _ in range(45)]
 for (a,b,u),co in tab.items():
  hh[b]+=co*(generators[a]*generators[u]-generators[u]*generators[a]);hh[a]-=co*(generators[b]*generators[u]-generators[u]*generators[b])
 return [(-M/casimir).applyfunc(s.expand) for M in hh]
pairs=list(combinations(range(45),2));XL={};XR={};images={};imagesR={};modules={};ghosts={};cov={};xco={}
for power,tab in r.items():
 XX=homotopy(tab,T);YY=homotopy(tab,U);XL[power]=[enc(M) for M in XX];XR[power]=[enc(M) for M in YY];xco[power]=[[a,e,str(co)] for a,M in enumerate(XX) for e,co in sorted(project(M).items())]
 il=[];ir=[];ml=[];gl=[]
 for a,b in pairs:
  mod=(-s.I*(T[a]*XX[b]-XX[b]*T[a]-T[b]*XX[a]+XX[a]*T[b])).applyfunc(s.expand)
  gh=(-sum((co*XX[u] for u,co in f[a,b]),s.zeros(16))).applyfunc(s.expand)
  modR=(-s.I*(U[a]*YY[b]-YY[b]*U[a]-U[b]*YY[a]+YY[a]*U[b])).applyfunc(s.expand)
  ghR=(-sum((co*YY[u] for u,co in f[a,b]),s.zeros(16))).applyfunc(s.expand)
  il.append(enc(mod+gh));ir.append(enc(modR+ghR));ml.append(enc(mod));gl.append(enc(gh))
 images[power]=il;imagesR[power]=ir;modules[power]=ml;ghosts[power]=gl;cv=[]
 for h in range(12):
  Th=sum((HF[a,h]*T[a] for a in range(45) if HF[a,h]),s.zeros(16))
  for a in range(45):
   rhs=sum((HF[b,h]*co*XX[u] for b in range(45) if HF[b,h] for u,co in f[b,a]),s.zeros(16))
   rem=(-s.I*(Th*XX[a]-XX[a]*Th)-rhs).applyfunc(s.expand)
   if s.SparseMatrix(rem).todok():cv.append([h,a,enc(rem)])
 cov[power]=cv
# A normalization example d(iTa)=i f_ab^e Te is independent of measured r.
exact={(a,b,e):co for (a,b),rr in f.items() if a<b for e,co in rr};example=homotopy(exact,T)
for a in range(45):zero(example[a]-s.I*T[a])
# Generic alternating Grassmann action: the Euler derivative has NO half.
def canonical(word):return tuple(sorted(word)),(-1)**sum(word[i]>word[j] for i in range(len(word)) for j in range(i+1,len(word)))
coef=s.symbols('k0:6');K=s.zeros(4)
for co,(i,j) in zip(coef,combinations(range(4),2)):K[i,j]=co;K[j,i]=-co
euler=[]
for i in range(4):
 row=defaultdict(lambda:s.S.Zero)
 for a,b in combinations(range(4),2):
  if i==a:row[b]+=K[a,b]
  if i==b:row[a]-=K[a,b]
 assert all(s.expand(row[j]-K[i,j])==0 for j in range(4));euler.append(row)
assert canonical([1,0,2])[1]==-1
# Counterterm minus times E*c*X*P gives plus c*E*X*P. Keep E unintegrated.
finish('primary',{'method':'full_matrix_internal_Casimir_and_source_homotopy_direct_source_images','adjoint_Casimir':str(casimir),'Casimir_per_generator':list(map(str,CA)),'x_coefficients':xco,'X_left':XL,'X_right':XR,'image_left':images,'image_right':imagesR,'module_left':modules,'ghost_left':ghosts,'H_covariance_remainders':cov,'normalization_example_remainder':'0','Euler_half_remainder':'0','Euler_odd_swap_sign':-1,'counterterm_source_unit':-1,'counterterm_Euler_companion_unit':1,'counterterm_g_powers':{'3':2,'4':3},'ghost_dimension':1,'P_dimension':'3/2','K_dimension':'3/2','counterterm_dimension':4,'breaking_dimension':5,'external_elementary_qK_changed':False,'full_quantum_matching_claimed':False,'scientific_authority_changed':False},start)
