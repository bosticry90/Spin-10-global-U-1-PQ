"""MSP1 complete image/admissibility comparison, no desired coefficient fitting."""
from data import *
from itertools import combinations
from collections import Counter
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');CMS=packed(CAL/'canonical_so10_complete_matter_source_breaking/primary_tables.json.gz')
def nz(M):return len(s.SparseMatrix(M.applyfunc(s.expand)).todok())
def zero(M):assert not nz(M)
def coeffs(rows):return {tuple(row[:2]):s.sympify(row[2],locals={'eta_H':WH,'xi':WM}) for row in rows}
assert s.sympify(P['adjoint_Casimir'])==s.sympify(R['adjoint_Casimir'])==8
assert P['Casimir_per_generator']==R['Casimir_per_generator']==['8']*45
for obj in [P,R]:
 assert obj['normalization_example_remainder']==obj['Euler_half_remainder']=='0' and obj['Euler_odd_swap_sign']==-1
 assert obj['counterterm_source_unit']==-1 and obj['counterterm_Euler_companion_unit']==1
 assert obj['counterterm_g_powers']=={'3':2,'4':3} and obj['ghost_dimension']==1 and obj['P_dimension']==obj['K_dimension']=='3/2'
 assert obj['counterterm_dimension']==4 and obj['breaking_dimension']==5
 assert not obj['external_elementary_qK_changed'] and not obj['full_quantum_matching_claimed'] and not obj['scientific_authority_changed']
assert R['generic_Euler_companion_nonzero_positions']>0
counts={};controls={};remainders={};covariance={};compared=primitive_positions=0
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new'])
for power in ['3','4']:
 pc,rc=coeffs(P['x_coefficients'][power]),coeffs(R['x_coefficients'][power]);assert set(pc)==set(rc)
 for key in pc:
  assert s.expand(pc[key]-rc[key])==0 and s.simplify(pc[key]-s.conjugate(pc[key]))==0
  assert all(n>=0 for mon,co in s.Poly(pc[key],WH,WM).terms() for n in mon)
 assert P['H_covariance_remainders'][power]==R['H_covariance_remainders'][power]
 cc=Counter();ctrl=Counter();rem=Counter();XX=[];YY=[]
 for a in range(45):
  x=dec(P['X_left'][power][a]);y=dec(P['X_right'][power][a]);zero(x-dec(R['X_left'][power][a]));zero(y-dec(R['X_right'][power][a]));zero(y+x.T);zero(x+x.H);zero(y+y.H)
  zero(x-s.I*sum((co*T[e] for (aa,e),co in pc.items() if aa==a),s.zeros(16)))
  XX.append(x);YY.append(y);cc['left_primitive']+=nz(x);cc['right_primitive']+=nz(y);ctrl['ordinary_source_transpose_changes']+=nz(y-x.T);primitive_positions+=2*16**2
 for i in range(990):
  mats={key:dec(P[key][power][i]) for key in ['image_left','image_right','module_left','ghost_left']}
  for key,M in mats.items():zero(M-dec(R[key][power][i]));compared+=16**2
  zero(mats['image_right']+mats['image_left'].T);zero(mats['image_left']-mats['module_left']-mats['ghost_left'])
  ll=dec(CMS['total_left'][power][i]);rr=dec(CMS['total_right'][power][i])
  rem['left_image']+=nz(mats['image_left']-ll);rem['right_image']+=nz(mats['image_right']-rr)
  cc['left_image']+=nz(mats['image_left']);cc['right_image']+=nz(mats['image_right'])
  ctrl['omit_module_changes']+=nz(mats['module_left']);ctrl['omit_ghost_changes']+=nz(mats['ghost_left'])
  ctrl['wrong_Casimir_half_changes']+=nz(2*mats['image_left']-mats['image_left'])
  ctrl['wrong_restoring_sign_changes']+=nz(mats['image_left']+mats['image_left'])
  ctrl['drop_this_coupling_order_changes']+=nz(ll)
 # Negative transpose transfers any left H remainder to the right; check
 # the operator identity directly on all12x45 actual source blocks.
 for h in range(12):
  th=sum((HF[a,h]*T[a] for a in range(45) if HF[a,h]),s.zeros(16))
  for a in range(45):zero((-s.I*((-th.T)*YY[a]-YY[a]*(-th.T)))+(-s.I*(th*XX[a]-XX[a]*th)).T)
 covariance[power]=len(P['H_covariance_remainders'][power]);remainders[power]=dict(rem);counts[power]={'scalar_primitive_coefficients':len(pc),**dict(cc)};controls[power]=dict(ctrl)
 assert all(v>0 for v in ctrl.values())
constructed=not any(v for rem in remainders.values() for v in rem.values()) and not any(covariance.values())
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_EXPLICIT_MATTER_SOURCE_PRIMITIVE_TEST','disposition':'CONSTRUCTED_SELECTED_LOCAL_SOURCE_PRIMITIVE' if constructed else 'CANDIDATE_PRIMITIVE_REMAINDER_PRESERVED','elapsed_after_imports':time.perf_counter()-start,'adjoint_Casimir':'8','source_image_remainders':remainders,'H_covariance_nonzero_blocks':covariance,'full_matrix_entries_compared':compared,'primitive_matrix_entries_compared':primitive_positions,'counts':counts,'controls':controls,'counterterm_coupling_powers':[2,3],'no_inverse_physical_parameter':True,'real_polynomial_H_covariant':constructed,'Euler_companion_density_retained':True,'Euler_companion_sign':1,'external_elementary_qK_changed':False,'full_cPP_quantum_matching_or_QAP_or_Slavnov_restoration_qualified':False,'scientific_authority_changed':False,'physical_scheme_adopted':False,'shared_inputs_software_AI_authorship':True,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
