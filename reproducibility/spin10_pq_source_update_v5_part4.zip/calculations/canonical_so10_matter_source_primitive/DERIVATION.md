# MSP1: source primitive and its unremoved companions

Use [Ta,Tb]=i f_ab^e Te, rho_a=-i ad(Ta), and the actual trace normalization.
The value module is the adjoint subspace already reconstructed by MSC1.
Its Casimir satisfies sum_a rho_a^2=-C_A I. Matrix commutators independently
derive C_A and its scalar character; replay contracts actual structure
constants over the full45-dimensional internal domain.

For a closed two-cochain R define (hR)_b=sum_a rho_a R_ab. The invariant
metric/Jacobi algebra gives dh+hd=-C_A on this value module; for the actual
input the candidate X=-hR/C_A is tested directly, rather than accepting
this formal homotopy identity as the answer. A normalization example
R_ab=i f_ab^e Te=d(iTa)_ab fixes the sign without using the measured R.

The verified image must be

 (dX)_ab=-i([Ta,Xb]-[Tb,Xa])-f_ab^u Xu=R_ab.

Restore the source operation's overall g: a g^p breaking, p=3 or4, uses
a g^(p-1) primitive. This is polynomial division by a known factor, not
admission of inverse physical parameters. No inverse width, mass or scale
is generated. The rational internal Casimir normalization is not a fit.

For the physical Nambu source, X_a=i(PL x_a-PR x_a^T) with x_a a real
linear combination of Hermitian actual T. The left/right blocks use the
same coefficient and right=-left.T. Local-H covariance is the intertwiner
identity rho_h X_a=f_ha^b X_b for all12 unbroken generators, where
T_h=sum_a H_new[a,h]Ta. No derivative in KcXP means this checks the full
local-H transformation, with the already qualified ordinary tensor rules.

Let E_i=delta_left S_matter/delta P_i. From the alternating Nambu action,
including operator transpose/integration by parts,

 E_P=C(D_phys P+hat_gamma.partial_hat S),
 D_phys=bar_gamma.partial_bar-ig bar_gamma A G+PL M+PR Mdagger.

M is the actual YCT/SMA scalar-family operator, not a chosen mass matrix.
The elementary external-source BRST rule qK=0 differs from b_Sigma. In
the latter operation bK=E plus its inverse-cotangent source term. The
highest-source part of b(KcXP) is g K(dX)(c,c)P. Its source-free part is
E_i c X_ij P_j=-c E_i X_ij P_j. Therefore

 b C_src = -sum_p g^p K R^[p](c,c)P/(16pi^2)
           +sum_p g^(p-1)c^a E_i X_a,ij^[p]P_j/(16pi^2).

The second line is retained. It contains derivative, gauge, scalar and
hatted-auxiliary companions. It is not an independently measured cPP
quantum breaking and is not discarded by setting sources/hats to zero
before variation. The density is kept in Euler form; no unrecorded
integration-by-parts boundary current is dropped. A generic alternating
quadratic Grassmann action checks the Euler factor and sign exactly.
