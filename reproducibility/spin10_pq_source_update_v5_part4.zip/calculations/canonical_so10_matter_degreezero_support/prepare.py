"""MDS1 qualified-catalog authentication and prelaunch immutable freeze."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-degreezero-support-v1-2026-10-23')
BASE='36b9ce2d9442d9f873e6d4fc3c8717ef014d6d4d'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();bind={}
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
def add(p,want=None):
 p=p.resolve();h=digest(p)
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V525.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/research_session_preflight.py']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
add(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py')
deps={
 'canonical_so10_matter_breaking_support':(['RECORD.md','DERIVATION.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation_v2.json','validation_receipt.json'],'ed1596f57675dd7dfc94c10854c6bdd00184157bf875e4821a28b0bca046243f'),
 'canonical_so10_complete_matter_source_breaking':(['RECORD.md','DERIVATION.md','primary.py','replay.py','validation_receipt.json'],'c6eee8c9655d4acc68ffdc7f3e729a8541b2a4d1091fa3ef59c58334ffd6eb6a'),
 'canonical_so10_ghost_triangle_field_insertion':(['DERIVATION.md','RESULT.md','validation_receipt.json'],'610e974608e4d4f711708a7018a0981a857180cdc852a36807cdb7fa5be42d4a'),
 'canonical_so10_sterile_matter_action':(['ACTION_V1.md','validation_receipt.json'],'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_coupled_fermion_finite_counterterm':(['RESULT.md','validation_receipt.json'],'faa4a2441b9e445b2fc682621c4bbae7b8333ac0c91d460d1d085e9b5d182de3')}
for folder,(names,rh) in deps.items():
 for n in names:add(CAL/folder/n,rh if n=='validation_receipt.json' else None)
old=read(CAL/'canonical_so10_matter_breaking_support/validation_preparation_v2.json')['input_sha256']
for n in ['primary_tables.json.gz','replay_tables.json.gz']:
 p=(CAL/'canonical_so10_matter_breaking_support'/n).resolve();assert digest(p)==old[str(p)]
add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/coupled-fermion-finite-counterterm-v1-2026-10-23/postcommit_seal.json'))
source=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-source-primitive-v1-2026-10-23')
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(source/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31525
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:
 with (CONTROL/n).open('xb') as f:f.write((source/n).read_bytes())
ready=read(source/'readiness_result.json');assert ready['native_exit']==0 and ready['step_exits']==[0,0,0,0,0,2] and not ready['fresh_historical_science_requested']
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:
 rr=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
snap=read(CONTROL/'prelaunch_preflight.json');assert rr.returncode==0 and snap['git_HEAD']==BASE and snap['files_written']==0 and not snap['active_A10_M08_python_processes']
assert snap['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
reuse={'fresh_readiness_command_here':False,'source_was_fresh_in_prior_goal_turn':True,'fresh_byte_preflight_here':True,'fresh_byte_preflight_native_exit':rr.returncode,'scientific_replay_or_acceptance_inferred':False,'source_sha256':{str(source/n):digest(source/n) for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']}}
with (CONTROL/'readiness_reuse.json').open('xb') as f:f.write((json.dumps(reuse,sort_keys=True)+'\n').encode())
add(CONTROL/'readiness_reuse.json')
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'MDS1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('MDS1_FROZEN',len(bind),'bindings',flush=True)
