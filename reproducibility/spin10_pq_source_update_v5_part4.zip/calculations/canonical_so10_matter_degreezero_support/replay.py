"""MDS1 independent direct cycles and internal port orientations."""
from data import *
from itertools import combinations,combinations_with_replacement,permutations,product
start=begin('replay')
old=packed(CAL/'canonical_so10_matter_breaking_support/replay_tables.json.gz');V=old['vertices']
dimensions={'P':1.5,'S':1.5,'B':1,'x':1,'c':1,'a':1,'L':2}
power={tuple(sorted(k)):v for k,v in [(('P','P'),1),(('P','S'),1),(('S','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('a','c'),2)]}
insertion=[k for k,v in sorted(V.items()) if v['origin'].startswith('E_')]
ordinary=[k for k,v in sorted(V.items()) if len(v['ports'])==3 and k not in insertion and v['origin']!='KCP']
four=[k for k,v in sorted(V.items()) if len(v['ports'])==4]
def canonical(names,ext,edges,meta):
 options=[]
 for perm in permutations(range(len(names))):
  labels=[names[i] for i in perm]
  if labels!=sorted(labels):continue
  mapping={v:i for i,v in enumerate(perm)}
  ex=sorted((mapping[a],k,j) for a,k,j,no in ext)
  ed=[]
  for a,b in edges:ed.append(tuple(sorted([(mapping[a[0]],a[1],a[2]),(mapping[b[0]],b[1],b[2])])))
  options.append(json.dumps([labels,ex,sorted(ed),*meta],separators=(',',':')))
 return min(options)
def cycles(n):
 for tail in permutations(range(1,n)):
  if tail[0]<tail[-1]:yield (0,*tail)
out={}
for target,wanted in [('cBPP',['B','P','P','c']),('cxPP',['P','P','c','x'])]:
 tab={k:set() for k in ['candidate','external_hat_zero','positive_dimension','UV_convergent']}
 for ee in insertion:
  sequences=[(ee,*a) for a in combinations_with_replacement(ordinary,3)]+[(ee,a,b) for a in ordinary for b in four]
  for seq in sequences:
   n=len(seq);ports=[[(i,k,j,no) for no,(k,j) in enumerate(V[name]['ports'])] for i,name in enumerate(seq)]
   choices=[[v for v in combinations(pp,2) if all(a[1] in wanted for a in pp if a not in v)] for pp in ports]
   for selected in product(*choices):
    ext=[p for pp,ch in zip(ports,selected) for p in pp if p not in ch]
    if sorted(k for i,k,j,no in ext)!=wanted:continue
    for order in cycles(n):
     for flips in product([0,1],repeat=n):
      es=[(selected[v][flips[v]],selected[order[(i+1)%n]][1-flips[order[(i+1)%n]]]) for i,v in enumerate(order)]
      kinds=[tuple(sorted([a[1],b[1]])) for a,b in es]
      if any(k not in power for k in kinds):continue
      m=sum(V[k]['mass_dimension'] for k in seq);g=sum(V[k]['g_degree'] for k in seq);y=sum(V[k]['Y_degree'] for k in seq)
      inside=sum(len(j) for pair in selected for i,k,j,no in pair);outside=sum(len(j) for i,k,j,no in ext);ld=4-sum(power[k] for k in kinds)+inside
      assert ld+outside==5-sum(dimensions[k] for k in wanted)-m
      status='external_hat_zero' if any('h' in j for i,k,j,no in ext) else 'positive_dimension' if m else 'UV_convergent' if ld<0 else 'candidate'
      tab[status].add(canonical(list(seq),ext,es,[ld,outside,g,y,m]))
 out[target]={k:sorted(v) for k,v in tab.items()}
finish('replay',{'method':'all_cycle_orders_and_internal_port_flips_from_qualified_replay_catalog','vertices':V,'targets':out,'qualified_catalog_GF_positions':old['GF_positions'],'qualified_catalog_homogeneous_GF_components':old['homogeneous_GF_components'],'new_loop_integrals':0,'internal_ghost_coefficients_measured':False,'physical_scheme_adopted':False},start)
