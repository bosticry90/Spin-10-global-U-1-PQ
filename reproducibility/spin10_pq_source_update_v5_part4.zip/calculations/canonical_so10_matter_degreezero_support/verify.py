"""MDS1 full canonical coverage, witness typing and actual-zero applicability."""
from data import *
from collections import Counter,defaultdict
from itertools import permutations
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['vertices','targets','qualified_catalog_GF_positions','qualified_catalog_homogeneous_GF_components']:assert P[key]==R[key],key
assert P['qualified_catalog_GF_positions']==33092 and P['qualified_catalog_homogeneous_GF_components']==33192
V=P['vertices'];power={tuple(sorted(k)):v for k,v in [(('P','P'),1),(('P','S'),1),(('S','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('a','c'),2)]}
def connected(edges,n,omit=-1):
 todo=[0];done=set()
 while todo:
  v=todo.pop()
  if v in done:continue
  done.add(v)
  for no,(a,b) in enumerate(edges):
   if no!=omit and (a[0]==v or b[0]==v):todo.append(b[0] if a[0]==v else a[0])
 return len(done)==n
def pairing_key(text):
 names,ext,edges,*meta=json.loads(text);ei=next(i for i,k in enumerate(names) if V[k]['origin'].startswith('E_'));tag=V[names[ei]]['origin']
 labels=list(names);labels[ei]='E_PAIR'
 ee=[tuple(tuple((v,k,'' if v==ei else j)) for v,k,j in edge) for edge in edges]
 out=[]
 for perm in permutations(range(len(names))):
  ll=[labels[i] for i in perm]
  if ll!=sorted(ll):continue
  ix={old:new for new,old in enumerate(perm)}
  ex=sorted((ix[v],k,j) for v,k,j in ext)
  ed=sorted(tuple(sorted((ix[v],k,j) for v,k,j in edge)) for edge in ee)
  out.append(json.dumps([ll,ex,ed,*meta],separators=(',',':')))
 return min(out),tag
counts={};families={};controls={};partitions={};witnesses=0
for target,want in [('cBPP',['B','P','P','c']),('cxPP',['P','P','c','x'])]:
 classes=P['targets'][target];counts[target]={k:len(v) for k,v in classes.items()};family=Counter();ctrl=Counter();pairs=defaultdict(dict);remaining=[]
 for classification,rows in classes.items():
  for text in rows:
   names,ext,edges,ld,ej,gp,yp,md=json.loads(text);n=len(names);witnesses+=1
   assert len(edges)==n and connected(edges,n) and all(connected(edges,n,j) for j in range(n))
   assert sorted(k for v,k,j in ext)==want
   assert len([k for k in names if V[k]['origin'].startswith('E_')])==1 and all(V[k]['origin']!='KCP' for k in names)
   assert sorted(len(V[k]['ports']) for k in names) in [[3,3,3,3],[3,3,4]]
   for i,name in enumerate(names):
    ports=[(k,j) for v,k,j in ext if v==i]+[(k,j) for edge in edges for v,k,j in edge if v==i]
    assert Counter(ports)==Counter(map(tuple,V[name]['ports']))
    assert sum(v==i for edge in edges for v,k,j in edge)==2
   assert gp==sum(V[k]['g_degree'] for k in names) and yp==sum(V[k]['Y_degree'] for k in names) and md==sum(V[k]['mass_dimension'] for k in names)
   assert ld==4-sum(power[tuple(sorted([a[1],b[1]]))] for a,b in edges)+sum(len(j) for edge in edges for v,k,j in edge)
   assert ej==sum(len(j) for v,k,j in ext) and ld+ej==-md
   expected='external_hat_zero' if any('h' in j for v,k,j in ext) else 'positive_dimension' if md else 'UV_convergent' if ld<0 else 'candidate'
   assert classification==expected
   if classification!='candidate':continue
   assert ld==ej==md==0 and sum(sorted([a[1],b[1]])==['P','S'] for a,b in edges)==1
   ei=next(i for i,k in enumerate(names) if V[k]['origin'].startswith('E_'));ex=[k for v,k,j in ext if v==ei];assert len(ex)==1 and ex[0] in ['c','P']
   if ex[0]=='c':
    key,tag=pairing_key(text);assert tag in ['E_P','E_S'] and tag not in pairs[key];pairs[key][tag]=text
   else:remaining.append(text)
   kinds=tuple(sorted(''.join(sorted([a[1],b[1]])) for a,b in edges));origins=tuple(sorted(V[k]['origin'] for k in names));family[origins,kinds,gp,yp,ex[0]]+=1
   ctrl['remove_PS_changes']+=1
   ctrl['remove_BL_changes']+=int('BL' in kinds)
   ctrl['omit_GF_BBac_changes']+=int(any(V[k]['origin']=='GF' and sorted(p for p,j in V[k]['ports'])==['B','B','a','c'] for k in names))
   ctrl['omit_PHY_BBB_changes']+=int(any(V[k]['origin']=='PHY' and sorted(p for p,j in V[k]['ports'])==['B','B','B'] for k in names))
   ctrl['omit_GF_LBB_changes']+=int(any(V[k]['origin']=='GF' and sorted(p for p,j in V[k]['ports'])==['B','B','L'] for k in names))
   ctrl['omit_internal_GF_C_derivative_changes']+=int(any(V[name]['origin']=='GF' and any(v==i and k=='c' and j for edge in edges for v,k,j in edge) for i,name in enumerate(names)))
 for key,pair in pairs.items():assert set(pair)=={'E_P','E_S'}
 assert 2*len(pairs)+len(remaining)==counts[target]['candidate']
 partitions[target]={'external_ghost_paired_zero_groups':[pairs[k] for k in sorted(pairs)],'remaining_internal_ghost_candidates':sorted(remaining),'actual_free_identity_reused':'CMS1_GTT1_S_E_S_PP_equals_i_hatk2_A_barq','degree_zero_paired_local_coefficient':'0','internal_ghost_coefficients_measured':False}
 controls[target]=dict(ctrl);families[target]=[{'vertices':o,'edges':e,'g_degree':g,'Y_degree':y,'E_external_port':x,'typed_classes':n} for (o,e,g,y,x),n in sorted(family.items())]
for d in [P,R]:assert d['new_loop_integrals']==0 and not d['internal_ghost_coefficients_measured'] and not d['physical_scheme_adopted']
raw=(json.dumps({'partitions':partitions,'classes':P['targets'],'families':families,'quantum_coefficients_assigned_from_counterterm':False},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'support_tables.json.gz').open('xb') as f:f.write(blob)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_DEGREE_ZERO_MATTER_SUPPORT_AND_PAIRED_ZERO_TEST','elapsed_after_imports':time.perf_counter()-start,'class_counts':counts,'canonical_witnesses_checked':witnesses,'paired_external_ghost_zero_groups':{k:len(v['external_ghost_paired_zero_groups']) for k,v in partitions.items()},'remaining_internal_ghost_candidates':{k:len(v['remaining_internal_ghost_candidates']) for k,v in partitions.items()},'families':families,'controls':controls,'full_D_bosonic_coefficient_control':'NOT_EVALUATED_IN_TYPED_CENSUS','actual_free_identity_imported_not_independently_rederived_here':True,'new_loop_integrals':0,'internal_ghost_coefficients_measured':False,'full_coupled_source_counterterms_or_restoration_qualified':False,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','support_tables_sha256':sha256(blob).hexdigest(),'support_raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
