"""MDS1 all compatible internal pairings and edge-deletion tests."""
from data import *
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations,product
start=begin('primary')
old=packed(CAL/'canonical_so10_matter_breaking_support/primary_tables.json.gz');V=old['vertices']
dim2={'P':3,'S':3,'B':2,'x':2,'c':2,'a':2,'L':4}
fall={tuple(sorted(k)):v for k,v in [(('P','P'),1),(('P','S'),1),(('S','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('a','c'),2)]}
E=[k for k in sorted(V) if V[k]['origin'].startswith('E_')]
cub=[k for k in sorted(V) if len(V[k]['ports'])==3 and k not in E and V[k]['origin']!='KCP']
qua=[k for k in sorted(V) if len(V[k]['ports'])==4]
def match(ps):
 if not ps:yield [];return
 a=ps[0]
 for i,b in enumerate(ps[1:],1):
  if a[0]==b[0] or tuple(sorted([a[1],b[1]])) not in fall:continue
  for tail in match(ps[1:i]+ps[i+1:]):yield [(a,b)]+tail
def connected(es,n,skip=-1):
 seen={0}
 while True:
  was=set(seen)
  for i,(a,b) in enumerate(es):
   if i==skip:continue
   if a[0] in seen:seen.add(b[0])
   if b[0] in seen:seen.add(a[0])
  if was==seen:return len(seen)==n
def canon(names,ext,edges,meta):
 best=None
 for order in permutations(range(len(names))):
  if [names[i] for i in order]!=sorted(names):continue
  mp={v:i for i,v in enumerate(order)}
  xx=sorted((mp[v],k,j) for v,k,j,no in ext)
  ee=sorted(tuple(sorted(((mp[a[0]],a[1],a[2]),(mp[b[0]],b[1],b[2])))) for a,b in edges)
  ss=json.dumps([sorted(names),xx,ee,*meta],separators=(',',':'));best=ss if best is None else min(best,ss)
 return best
out={};checked={}
for target,want in [('cBPP',['c','B','P','P']),('cxPP',['c','x','P','P'])]:
 classes={k:set() for k in ['candidate','external_hat_zero','positive_dimension','UV_convergent']};nn=0
 for e in E:
  groups=[(e,*v) for v in combinations_with_replacement(cub,3)]+[(e,c,q) for c in cub for q in qua]
  for names in groups:
   n=len(names);ports=[[(i,k,j,no) for no,(k,j) in enumerate(V[name]['ports'])] for i,name in enumerate(names)]
   # Degree2 at each vertex is proved in DERIVATION; do not discard roles.
   options=[[ex for ex in combinations(pp,len(pp)-2) if all(a[1] in want for a in ex)] for pp in ports]
   for parts in product(*options):
    ext=[v for part in parts for v in part]
    if Counter(v[1] for v in ext)!=Counter(want):continue
    used=set(ext);inside=[v for pp in ports for v in pp if v not in used]
    for edges in match(inside):
     nn+=1
     if not connected(edges,n) or any(not connected(edges,n,j) for j in range(len(edges))):continue
     md=sum(V[k]['mass_dimension'] for k in names);gp=sum(V[k]['g_degree'] for k in names);yp=sum(V[k]['Y_degree'] for k in names)
     ej=sum(len(j) for v,k,j,no in ext);dj=sum(len(j) for v,k,j,no in inside);ld=4-sum(fall[tuple(sorted([a[1],b[1]]))] for a,b in edges)+dj
     assert 2*(ld+ej)==10-sum(dim2[k] for k in want)-2*md
     status='external_hat_zero' if any('h' in j for v,k,j,no in ext) else 'positive_dimension' if md else 'UV_convergent' if ld<0 else 'candidate'
     classes[status].add(canon(names,ext,edges,[ld,ej,gp,yp,md]))
 out[target]={k:sorted(v) for k,v in classes.items()};checked[target]=nn
finish('primary',{'method':'all_compatible_pairings_complete_degree2_port_selection_and_edge_deletion','vertices':V,'targets':out,'compatible_pairings_before_connectivity':checked,'qualified_catalog_GF_positions':old['GF_positions'],'qualified_catalog_homogeneous_GF_components':old['homogeneous_GF_components'],'new_loop_integrals':0,'internal_ghost_coefficients_measured':False,'physical_scheme_adopted':False},start)
