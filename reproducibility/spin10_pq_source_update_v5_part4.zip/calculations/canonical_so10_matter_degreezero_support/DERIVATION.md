# MDS1: graph completeness and the imported free-insertion zero

For connected one-loop graphs I=V and sum(n_v-2)=N_external=4. With one
trivalent E and ordinary valences3/4, the only possibilities are E+3cubic
or E+cubic+quartic. A connected1PI multigraph has every internal degree>=2;
sum degrees=2I=2V then forces degree2 everywhere. Self-tadpole attachments
cannot connect a multiple-vertex1PI graph. All allowed graphs are cycles.
Primary arbitrary compatible pairings plus edge deletion and replay direct
cycles give distinct finite enumerations using the same qualified catalog.

Each port retains its derivative tag. The two independent UV degree counts
must agree:

 loop_degree=4-sum(edge falloffs)+internal_derivative_count,
 loop_degree+external_ordinary_jets=5-sum(external_dimensions)-mass_degree.

For both new targets the latter budget is0-mass_degree. External hatted
derivatives vanish in this physical target. Explicit ordinary external jets
can therefore change the class from log candidate to UV-convergent. This
does not contradict GTT1, whose one-jet cPP target required external-C jets.

Every surviving graph has exactly one PS/SP edge: E has the only S port,
no external S is allowed and no ordinary interaction contains S. The other
hatted factor comes from E. An odd-hat argument cannot remove the pair.

If E's external port is ghost, canonical E_P and E_S graphs have identical
other vertices, external attachments, edge roles and homogeneous degrees.
Strip only the location of their single internal h derivative to identify
the partner key; require exactly one of each before using the identity.
Do not strip derivatives at any ordinary vertex or conflate GF/PHY origins.

CMS1 derived the actual mixed PP numerator

 i[bar k Atilde hat r^2-hat k^2 A bar r].

For physical external q=k-r, hat k=hat r and bar k Atilde=A bar k. Thus
the sum is i hat k^2 A bar q. This identity is already qualified from the
actual SMA1/SMP1 free blocks, not newly asserted from a graph name. At fixed
generic nonexceptional external momenta the remaining primitive one-loop
integral has improved UV degree-1. With the explicit evanescent pair its
convergent four-dimensional limit vanishes. The local ordinary-degree0
coefficient is therefore0. There is no inverse external momentum in the
local counterterm ring. No exceptional IR or constant-vacuum limit is used.

When E's external port is P the ghost is internal. Its E_C/E_S terms and
full ghost/vector/auxiliary interactions must be measured separately with
their actual matrix, spin, Wick and derivative conventions. Candidate
membership is not a nonzero coefficient. A later bosonic-edge insertion
can carry hatted vector indices even when external B and a fermion end
are barred; retain all formal-D metric and joint angular factors there.

This proof imports an actual free-block identity and qualifies its complete
new partner coverage. It neither constructs full renormalized products nor
proves quantum equivalence of the provisional physical/reference actions.
