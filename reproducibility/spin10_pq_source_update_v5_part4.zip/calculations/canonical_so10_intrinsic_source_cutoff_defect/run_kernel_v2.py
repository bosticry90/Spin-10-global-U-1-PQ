from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-defect-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'support_validation_preparation.json')['input_sha256'])
 for p in [O/'kernel.py',O/'run_kernel.py',O/'kernel_controller_failure.json',O/'kernel_primary_inputs.json.gz',O/'kernel.py.failed_preparation_source.txt',O/'run_kernel.py.failed_preparation_source.txt']:b[str(p)]=H(p)
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['support_validation_preparation.json','support_validation_receipt.json','support_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 cp=O.parent/'canonical_so10_intrinsic_full_source_descent/coefficient_ring.py';assert read(O/'kernel_inputs.json')=={'coefficient_ring':str(cp)}
 for p in [cp,O/'kernel_inputs.json']:b[str(p)]=H(p)
 for role in ['primary','replay']:
  paths={'old':O.parent/'canonical_so10_intrinsic_auxiliary_ghost_source'/('color_'+role+'_inputs.json.gz'),'Z0':O.parent/'canonical_so10_intrinsic_auxiliary_ghost_source'/('vertex_'+role+'_tables.json.gz'),'rho':O.parent/'canonical_so10_intrinsic_auxiliary_source'/('vertex_'+role+'_tables.json.gz'),'op':O.parent/'canonical_so10_unprobed_source_root_module'/('operands_'+role+'_inputs.json.gz'),'aligned':O.parent/'canonical_so10_unprobed_source_root_module'/('operands_'+role+'_tables.json.gz'),'maps':O.parent/'canonical_so10_intrinsic_full_source_descent'/('map_'+role+'_tables.json.gz')}
  for p in paths.values():b[str(p)]=H(p)
  old=load(paths['old']);op=load(paths['op']);z={'audit':load(O/('support_'+role+'_inputs.json.gz'))['audit'],'field_maps':load(O/('support_'+role+'_inputs.json.gz'))['field_maps'],'endings':old['endings'],'R':load(paths['aligned'])['R'],'S0':old['S0'],'Z0':load(paths['Z0'])['Z0_JC_aC'],'rho_source_vertices':load(paths['rho'])['rho_source_vertices'],'frame':op['frame'],'xs':op['xs'],'maps':load(paths['maps'])};p=O/('kernel_v2_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['KERNEL_RECORD.md','CORRECTION_V2.md','kernel_v2.py','run_kernel_v2.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'kernel_preparation_v2.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay']:
  z=capture([sys.executable,'-B',str(O/'kernel_v2.py'),role]);dump(O/('kernel_v2_'+role+'_capture.json'),z);dump(C/('kernel_v2_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300;dump(O/('kernel_v2_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_RSH2',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'kernel_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
