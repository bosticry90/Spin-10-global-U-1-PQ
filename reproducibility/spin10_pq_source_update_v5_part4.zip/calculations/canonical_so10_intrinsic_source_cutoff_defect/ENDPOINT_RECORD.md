# RSH3: paired-momentum endpoint test before V4

V3 natives completed and agreed computationally. Their coefficient is NOT
qualified. Review of the actual paired action exposes an endpoint error:

    a_-q theta J(q) b_q + a_q theta J(-q) b_-q

gives H_ab(q)=theta J(q) but H_ba(q)=-theta J(-q),not -theta J(q).
The vector part of J is odd in q;the auxiliary part is even. V3 used
the same q in both endpoint coefficients. Both implementations shared
the same pieces builder and therefore failed to detect it by agreement.
All V3 tables,captures and sources remain;they authenticate a completed
but scientifically unqualified calculation,not a measured model result.

First test this with a literal two-mode graded Hessian for both q signs,
both external odd roles(C and rho),and vector versus auxiliary momentum
parity. The wrong V3 vector endpoint must fail;the corrected endpoint
must agree,without any reference to N5 or another quantum coefficient.
Then V4 changes ONLY the reverse vector-current endpoints for J0/Jrho.
The actual relative comparison remains withheld until validation.

Same bounds/authority ceiling. This is a graded Fourier endpoint correction,
not a regulator,symmetry,source normalization or physical input change.
