# Exact coefficient API correction after failed native

V2 preparation completed. Its primary native exited1 before a matrix-power
coefficient was evaluated:the frozen exact Coeff ring has multiplication but
no Python exponentiation method. The source-Euler Fourier factor requested
Coeff**integer,including power0. Full failed capture/source/preparation and
controller remain immutable. No replay or verifier ran and no V2 native
result/qualification receipt exists. Resource observations remain preserved.

V3 uses repeated exact multiplication for these nonnegative integer powers,
with constant1 for power0. It reuses the same authenticated V2 role inputs.
New preparations,source copies,natives,captures and outputs have V3 names.
No action,coordinate,phase,parameter or acceptance requirement is changed.
All original failed versions remain scientific failures of execution,not PASS.
