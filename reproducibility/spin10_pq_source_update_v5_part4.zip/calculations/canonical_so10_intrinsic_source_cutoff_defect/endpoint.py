from pathlib import Path
from hashlib import sha256
import json,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter()
for p,h in read(O/'endpoint_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
# Two quantum modes,one even b and one odd a in each mode;one external
# odd theta. Differentiate literal words,then move theta to the coefficient.
par={0:0,1:1,2:0,3:1,4:1}
def derivative(w,i):
 for at,n in enumerate(w):
  if n==i:yield w[:at]+w[at+1:],(-1)**(par[i]*sum(par[n]for n in w[:at]))
def hessian(terms):
 out={}
 for v,w in terms:
  for i in range(4):
   for ww,sg in derivative(w,i):
    for j in range(4):
     for www,tg in derivative(ww,j):
      assert www==(4,);out[i,j]=out.get((i,j),0)+sg*tg*(-1)**(par[j]*(par[i]+1))*v
 return out
cases=[]
for external in ['C','rho']:
 for jet in [0,1]:
  for q in [1,-1]:
   J=lambda p:3*p**jet
   z=hessian([(J(q),(3,4,0)),(J(-q),(1,4,2))]);actual=(z[3,0],z[2,1]);correct=(J(q),-J(-q));wrong=(J(q),-J(q));assert actual==correct
   cases.append({'external':external,'jet':jet,'q':q,'correct':list(correct),'V3_wrong_endpoint_detected':actual!=wrong})
assert sum(q['V3_wrong_endpoint_detected']for q in cases)==4
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'literal_paired_graded_Hessian_cases':cases,'corrected_endpoints_all_pass':True,'V3_vector_endpoint_fails_four_sensitive_cases':True,'quantum_remainder_used':False,'V3_qualifies_as_model_coefficient':False},sort_keys=True),flush=True)
