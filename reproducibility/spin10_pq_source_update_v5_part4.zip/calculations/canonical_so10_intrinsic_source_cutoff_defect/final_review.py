from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();bindings=copies=captures=0;peak=0
for p in O.glob('*preparation*.json'):
 for f,h in read(p).get('input_sha256',{}).items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
for n in ['kernel.py','run_kernel.py']:assert(O/(n+'.failed_preparation_source.txt')).read_bytes()==(O/n).read_bytes()
for p in O.glob('*capture.json'):
 z=read(p);assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2;peak=max(peak,max(q['private_bytes']for q in z['all_resource_samples']));assert peak<=8*1024**3;captures+=1
 if p.name=='kernel_v2_primary_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
assert captures==9 and not(O/'kernel_v2_primary_result.json').exists()and not(O/'kernel_v3_validation_receipt.json').exists();assert read(O/'endpoint_validation_receipt.json')['V3_vector_endpoint_fails_four_sensitive_cases'];assert all(read(O/n)['execution_state']=='FAILED'for n in ['kernel_controller_failure.json','kernel_controller_failure_v2.json','kernel_controller_failure_v4.json']);assert not(O/'kernel_controller_failure_v3.json').exists()and not(O/'kernel_controller_failure_v4_continuation.json').exists();assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};val=lambda z:s.expand(s.sympify(z,locals=loc));a,b=[load(O/('kernel_v4_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b;counts=[]
for q in a['results']:
 cc={int(n):val(v)for n,v in q['cutoff_pair_coefficients'].items()}
 for n,v in cc.items():assert s.expand(sum(val(vv[str(n)])for vv in q['root_groups'].values())-v)==0
 expected={'log2':-cc[2]+2*cc[3]-2*cc[4]+cc[5],'log3':cc[2]-cc[3]+cc[5],'log5':cc[4]-cc[5]}
 assert all(s.expand(expected[k]-val(v))==0 for k,v in q['finite_prime_basis'].items());counts.append([q['probe'],{str(n):str(v)for n,v in cc.items()}])
v=read(O/'kernel_validation_receipt.json');assert v['all_4096_exterior_squarefree_products_pass']and v['independent_right_source_Mrho_full_positions']==1032256 and v['sensitive_wrong_order_sharp_controls']==[8,8]and v['selected_coefficient_only_not_full_Ward_or_QAP'];assert all(val(z['known_conversion_log5'])+val(z['measured_cutoff_log5'])==0 for z in v['late_selected_log5_comparisons'])
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-defect-v1-2026-10-25');e=read(C/'e4_full_capture.json');ev=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];assert e['native_exit']==0 and[q['exit_code']for q in ev if q['event']=='step_finished']==[0,0,0,0,0,2]and ev[-1]['execution_state']=='COMPLETED';assert H(O.parents[1]/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
report=(O/'RESULT.md').read_text();assert all(x in report for x in ['one selected exact coefficient','not a general continuum','UNQUALIFIED','No normalization or unknown quantum input was fitted','full tensor','ACTIVE/INCOMPLETE'])
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_preparation_bindings_checked':bindings,'frozen_source_copies_equal':copies,'pre_review_captures':captures,'largest_pre_review_private_sample':peak,'root_groups_and_radial_prime_basis_checked':counts,'selected_late_log5_sum_zero_both_probes':True,'V3_completed_but_endpoint_rejected_not_scientific_operand':True,'native_and_preparation_failures_preserved':True,'E4_declared_exits_and_state_unchanged':True,'complete_tensor_Ward_QAP_or_E5_promotion':False},sort_keys=True),flush=True);timer.cancel()
