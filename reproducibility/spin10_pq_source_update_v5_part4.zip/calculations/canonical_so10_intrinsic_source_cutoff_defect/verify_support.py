from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'support_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('support_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
for q in a['results']:
 assert q['words']and not q['abstract_superfamily_occurrences']
 for w in q['words']:assert w['heat_edges']==[len(w['V_word']),len(w['V_word'])+1]and w['heat_pair_signs']==[1,-1]
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'rooted_directed_paths_vs_multisets_all_words_pass':True,'word_counts':[[q['probe'],len(q['words']),q['word_counts_by_V_length'],q['possible_positive_heat_lengths']]for q in a['results']],'families':[q['families']for q in a['results']],'all_G_source_degrees_retained_before_tangents':True,'abstract_potential_and_fermion_supersets_no_target_paths':True,'typed_operator_not_quantum_coefficient_or_QAP':True},sort_keys=True),flush=True)
