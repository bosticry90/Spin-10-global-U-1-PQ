# RSH4: operator,source orientation and late selected comparison

Prospective after both V4 natives. Authenticate their agreement without
accepting shared construction as independent physics. Check all4096 finite
exterior/squarefree multiplication cases. Reuse the qualified CSW generic
finite Gaussian helpers only as algebra definitions;execute eight Euclidean
inverse/graded-congruence fixtures and sensitive order/sharp controls.
This is finite algebra,not an extension of CSW's older analytic cPP domain.

Independently reconstruct Mrho from RIGHT source derivatives of the actual
Euclidean rhoG polynomial followed by literal linearization. Use a global
Wick phase count rather than the native per-variable phase multiplication.
Compare all matrix/grade entries and implicit zeros for both probes and q
orientations. Independently check every typed vector/nonvector transition
has its qualified longitudinal momentum pin;no closed B-only component.
The original EDS full-Lorentz and symbol-scaling proof is inherited science,
not replaced by checking just q+/- or two axes. Verify the finite radial
pairs for n2..5 by two parameterizations and a sign-reversal control.

Only afterward read the authenticated OLD IAG F5 at(r,h,i)=(13,0,137).
Test the formal log5 sum with the NEW measured cutoff coefficient,including
probe0. A failed comparison is retained;do not infer a whole tensor from
one selected coefficient. chi4 stays free;log2/log3 and two native roots
remain separate. No full augmented-master/source-product analytic identity,
Ihat/measure,full Ward restoration,QAP or E5 promotion is claimed.

V3 completed but failed the independently frozen paired endpoint test.
It has no qualification receipt and must not supply scientific operands.
V2 primary failed before a coefficient;original/V4 preparation failures and
the rejected patch remain preserved. Authenticate all these classifications.
Review180s,8GiB sampled,350MiB floor,32MiB packet. No scheme/physical input
or scientific requirement changed in the delegated implementation corrections.
