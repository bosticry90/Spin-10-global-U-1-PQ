from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import combinations,permutations
import json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'support_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('support_'+('replay'if role=='primary'else'primary')):raise PermissionError('RSH1_PEER_DENIED')
  if p.parent.name in ['canonical_so10_unprobed_source_root_module','canonical_so10_intrinsic_auxiliary_ghost_source','canonical_so10_intrinsic_full_source_descent']and p.name.endswith('tables.json.gz'):raise PermissionError('RSH1_DESIRED_QUANTUM_COEFFICIENT_DENIED')
sys.addaudithook(guard)
d=load(O/('support_'+role+'_inputs.json.gz'));audit=d['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux={('b'if i<12 else'L')+str(i)for i in range(45)};ants={('bar'if i<12 else'ub')+str(i)for i in range(45)}
def kind(n):
 if n in aux:return'L'
 if n in ants:return'a'
 if n.startswith('B'):return'B'
 if n.startswith('A'):return'A'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return'F'
dims={'B':1,'A':1,'L':2,'a':1,'C':1,'x':1,'F':1.5};V=defaultdict(list);M=defaultdict(list);excluded=Counter();low=[];resummed=[];hist=[];target=(1,1,1,1,1)
sub=lambda a,b:tuple(x-y for x,y in zip(a,b));sat=lambda a:all(x>=0 for x in a)
def put(store,origin,n,rho,js,ports,external,ref):
 if n not in [0,1]:excluded[origin+':intrinsic_grade']+=1;return
 if any(k!='JL'or j for k,j in js):excluded[origin+':other_external_source_or_jet']+=1;return
 if any(k not in ['C','x']or j for k,j in external):excluded[origin+':other_mean_field_or_jet']+=1;return
 grade=(int(n),rho,len(js),sum(k=='C'for k,j in external),sum(k=='x'for k,j in external))
 if not sat(sub(target,grade)):excluded[origin+':excess_target_grade']+=1;return
 if store is V and not any(grade):resummed.append([origin,ports,ref]);return
 assert store is M or sum(grade)>0
 key=(origin,*grade,ports[0][0],ports[1][0],ports[0][1],ports[1][1]);store[key].append(ref)
def hess(origin,n,rho,js,ww,ref):
 if len(ww)<2:low.append([origin,'zero_or_one_quantum_port',ref,js,ww]);return
 pairs=((i,j)for i in range(len(ww))for j in range(len(ww))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(ww)),2)for pair in[ij,ij[::-1]])
 for i,j in pairs:put(V,origin,n,rho,js,[ww[i],ww[j]],[v for k,v in enumerate(ww)if k not in[i,j]],[*ref,i,j])
for idx,row in enumerate(d['GF']):
 ww=[(kind(n.partition('__')[0]),len(n.partition('__')[2]))for n in row['word']];hess('GF',4-sum(dims[k]+j for k,j in ww),0,[],ww,[idx])
for out,rows in d['qLambda'].items():
 for idx,row in enumerate(rows):
  ww=[(kind(n.partition('__')[0]),len(n.partition('__')[2]))for n in row['word']];hess('JL_qLambda',3-sum(dims[k]+j for k,j in ww),0,[('JL',0)],ww,[out,idx])
for term in d['physical_graphs']:
 for idx,(parameters,nodes,coefficient)in enumerate(term['index_jet_graph_coefficients']):
  internal={};external=[]
  for tag,n,indices,jets in nodes:
   if tag!='Field':continue
   if n.startswith('h_'):internal['h']=(kind(n[2:]),len(jets))
   elif n.startswith('k_'):internal['k']=(kind(n[2:]),len(jets))
   else:external.append((kind(n),len(jets)))
  assert set(internal)=={'h','k'};put(V,term['term_id'],0,0,[],[internal['h'],internal['k']],external,[idx])
for out,rows in d['field_maps'].items():
 for idx,row in enumerate(rows):
  ww=[(kind(n.partition('__')[0]),len(n.partition('__')[2]))for n in row['word']];n=dims[kind(out)]+1-sum(dims[k]+j for k,j in ww)
  for at,v in enumerate(ww):put(M,'M0',n,0,[],[(kind(out),0),v],[w for j,w in enumerate(ww)if j!=at],[out,idx,at])
for probe,p in enumerate(audit['physical_G']):
 counts=Counter()
 for idx,(gp,w,ci)in enumerate(p['monomials']):
  counts[sum(n in sources for n,I in w)]+=1
  if any(n not in fields and n not in sources for n,I in w):excluded['G_background_or_control']+=1;continue
  ordinary=[(at,kind(names[n]),len(I))for at,(n,I)in enumerate(w)if n in fields];js=[(at,'J'+kind(sources[n]),len(I))for at,(n,I)in enumerate(w)if n in sources];n=3-sum(dims[k]+j for at,k,j in ordinary)-sum(3-dims[kind(sources[nn])]+len(I)for nn,I in w if nn in sources)
  hess('rhoG'+str(probe),n,1,[(k,j)for at,k,j in js],[(k,j)for at,k,j in ordinary],[idx])
  for at,k,j in js:
   output=kind(sources[w[at][0]]);restjs=[(kk,jj)for aa,kk,jj in js if aa!=at]
   if not ordinary:low.append(['Mrho'+str(probe),'source_flow_has_no_field_tangent',[idx,at],restjs,[]])
   for pos,ink,inj in ordinary:
    # Euler adjoint of a differentiated source distributes its derivatives.
    # In the selected external-jet0 term only the internal tangent port can
    # absorb them. Other distributions are retained as external-jet exclusions.
    if j and len(ordinary)+len(restjs)>1:excluded['Mrho'+str(probe)+':Euler_distributions_with_external_jets']+=len(ordinary)+len(restjs)-1
    put(M,'Mrho'+str(probe),n,1,restjs,[(output,0),(ink,inj+j)],[(kk,jj)for aa,kk,jj in ordinary if aa!=pos],[idx,at,pos,j])
 hist.append(dict(counts))
# Complete supersets for potential/fermion diagonal blocks. An absent
# numerical table is never interpreted as zero amplitude.
hess('ABSTRACT_scalar_cubic',1,0,[],[('x',0)]*3,['arbitrary_cubic'])
hess('ABSTRACT_scalar_quartic',0,0,[],[('x',0)]*4,['arbitrary_quartic'])
hess('ABSTRACT_scalar_mass',2,0,[],[('x',0)]*2,['arbitrary_mass'])
put(V,'ABSTRACT_fermion_Yukawa',0,0,[],[('F',0),('F',0)],[('x',0)],['arbitrary_Yukawa'])
put(V,'ABSTRACT_fermion_mass',1,0,[],[('F',0),('F',0)],[],['arbitrary_mass'])
put(M,'ABSTRACT_M0_fermion',0,0,[],[('F',0),('F',0)],[('C',0)],['actual_SMA_C_times_P_field_degree'])
def letters(store):
 out=[]
 for key,refs in sorted(store.items()):
  origin,n,rho,jl,c,x,L,R,j1,j2=key;out.append({'id':len(out),'origin':origin,'grade':[n,rho,jl,c,x],'ports':[L,R],'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
 return out
vs=letters(V);ms=letters(M);G={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x'),('F','F')};ks=sorted(set(dims)-{'A'});results=[]
for probe in range(2):
 active=[v['id']for v in vs if not v['origin'].startswith('rhoG')or v['origin'].endswith(str(probe))];roots=[m for m in ms if not m['origin'].startswith('Mrho')or m['origin'].endswith(str(probe))];opts={i:[(r,vs[i]['ports'][1])for r in ks if(r,vs[i]['ports'][0])in G]for i in active};found=set()
 for root in roots:
  left=sub(target,root['grade']);assert sat(left);start=root['ports'][1];end=root['ports'][0]
  if role=='primary':
   edges=defaultdict(list)
   for i in active:
    for r,c in opts[i]:edges[r].append((i,c))
   def walk(at,rem,w,path):
    if not any(rem):
     if at==end:found.add((root['id'],tuple(w),tuple(path)))
     return
    for i,to in edges[at]:
     nxt=sub(rem,vs[i]['grade'])
     if sat(nxt):walk(to,nxt,w+[i],path+[to])
   walk(start,left,[],[start])
  else:
   multis=[]
   def choose(lo,rem,w):
    if not any(rem):multis.append(tuple(w));return
    for at in range(lo,len(active)):
     i=active[at];nxt=sub(rem,vs[i]['grade'])
     if sat(nxt):choose(at,nxt,w+[i])
   choose(0,left,[])
   for bag in multis:
    for w in set(permutations(bag)):
     def attach(at,path):
      if at==len(w):
       if path[-1]==end:found.add((root['id'],w,tuple(path)))
       return
      for r,c in opts[w[at]]:
       if path[-1]==r:attach(at+1,path+[c])
     attach(0,[start])
 words=[];counts=Counter();families=Counter();abstract=Counter()
 for root,w,path in sorted(found):
  n=len(w);assert n<=sum(target)-sum(ms[root]['grade']);words.append({'root_M':root,'V_word':list(w),'G_path':list(path),'rooted_series_sign':(-1)**n,'STr_sign':(-1)**int(path[0]in ['C','a','F']),'heat_edges':[n,n+1],'heat_pair_signs':[1,-1]});counts[n]+=1;families[ms[root]['origin'],n,tuple(sorted(vs[i]['origin']for i in w))]+=1
  for name in [ms[root]['origin']]+[vs[i]['origin']for i in w]:
   if name.startswith('ABSTRACT'):abstract[name]+=1
 results.append({'probe':probe,'words':words,'word_counts_by_V_length':dict(counts),'families':[{'root':m,'V_length':n,'V_origins':list(orig),'words':v}for(m,n,orig),v in sorted(families.items())],'abstract_superfamily_occurrences':dict(abstract),'max_V_length':max(counts,default=0),'possible_positive_heat_lengths':sorted({n for q in words for n in q['heat_edges']})});print('STAGE RSH1',role,probe,'V',len(vs),'M',len(ms),'words',len(words),'by_length',dict(counts),'abstract',dict(abstract),flush=True)
out={'schema':'RSH1_COMPLETE_ROOTED_CUTOFF_SOURCE_TYPED_SUPPORT','role':role,'V_letters':vs,'M_roots':ms,'results':results,'excluded':dict(excluded),'source_only_or_one_port_rows':low,'resummed_free_candidates':resummed,'actual_G_source_inventory_before_derivatives':hist,'model_cutoff_coefficient_measured':False,'common_source_analytic_domain_or_QAP_not_inferred':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'V_letters':len(vs),'M_roots':len(ms),'word_counts':[[q['probe'],len(q['words']),q['word_counts_by_V_length'],q['possible_positive_heat_lengths']]for q in results],'quantum_coefficient_fitted':False},sort_keys=True),flush=True);timer.cancel()
