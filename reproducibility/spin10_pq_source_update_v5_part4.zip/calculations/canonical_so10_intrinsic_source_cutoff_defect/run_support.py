from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-cutoff-defect-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b={}
 for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V631.md','docs/RESEARCH_EXECUTION_HANDOFF_V630.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/n;b[str(p)]=H(p)
 for p in [O.parent/'canonical_so10_cutoff_source_ward_operator/validation_receipt.json',O.parent/'canonical_so10_cutoff_source_ward_operator/DERIVATION.md',O.parent/'canonical_so10_unprobed_source_root_module/final_review_validation_receipt.json',Path('C:/Users/psboy/.codex/attachments/a3020d5d-8adf-434c-b027-547c26d2f0ba/Pasted text.txt')]:b[str(p)]=H(p)
 for role in ['primary','replay']:
  kp=O.parent/'canonical_so10_intrinsic_kinetic_support'/('support_'+role+'_inputs.json.gz');qp=O.parent/'canonical_so10_intrinsic_quadratic_source_contacts'/('support_'+role+'_inputs.json.gz');mp=O.parent/'canonical_so10_cutoff_source_ward_operator'/(role+'_inputs.json.gz')
  for p in [kp,qp,mp]:b[str(p)]=H(p)
  k=load(kp);q=load(qp);m=load(mp);z={'audit':q['audit'],'qLambda':q['qLambda'],'GF':k['GF'],'physical_graphs':k['physical_graphs'],'field_maps':m['field_maps']};p=O/('support_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['RECORD.md','support.py','verify_support.py','run_support.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'support_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['support_preparation.json']+[f'support_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in ['primary','replay']for t in ['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'support_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_support.py'if role=='verify'else'support.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('support_'+role+'_capture.json'),z);dump(C/('support_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('support_validation_receipt.json'if role=='verify'else'support_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_RSH1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'support_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
