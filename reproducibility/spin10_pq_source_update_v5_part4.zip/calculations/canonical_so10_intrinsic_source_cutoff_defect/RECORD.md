# RSH1+: actual intrinsic source cutoff insertion

Prospective at bb48a75733324ded92ef44317561f2b58af5449d,V631. Fresh goal
tool ACTIVE supersedes the earlier PAUSED observation;preflight clean main,
no matching workers. Previous goal turn PROGRESS. State113,authority34/39,
E5/A5 OPEN,custodyexit2/seven NOTPASS unchanged. Live AGENTS,charter,solo
review and epistemic obligations apply. No agents,branch/worktree,remote
action,publication,outreach,foundation/scheme/benchmark adoption,flavor/
HB1/C5 activation,protected promotion or scientific-state edit.

Question: what is the actual cutoff/source Ward insertion in the selected
rho JL Cx,intrinsicdegree1 local relative sector? The previous USR result
proves a protected formal log5 component;it supplies no regulator coefficient.
Do not use that component's value or negative as a native operand.

First derive COMPLETE typed support of the positive-heat cutoff operator
from the existing full source-Hessian identity,including the actual nonlinear
and source-dependent field tangent. Source derivatives precede restriction.
Both M0 with a rhoG Hessian and Mrho with unprobed Hessians can contribute.
Do not assume only a four-to-five-edge defect or only a linear source action.

At fixed field/probe independent reference,Euclidean Gaussian algebra gives
the structural cutoff term STr(Gt Rt M),with
Gt Rt=(1+E G0 V)^-1(1-E),E=exp(-2tP). This follows from the inherited CSW
finite Gaussian proof;its older cPP analytic domain does NOT automatically
qualify this new source projection. Establish the needed source/master,
reference and analytic premises separately before claiming an actual full
renormalized Ward identity. Keep Ihat,reference response and superdivergence
as distinct obligations. No arbitrary finite-part trace cyclicity.

Original unshifted SMA/CSW/EDS,A0,constant rho/first probes,externaljets0,
one intrinsic GF/reference coefficient of dimension1,all45 nonminimal/
ghost/gauge and328 scalar directions,symbolicg10/xi/eta_H. Same local
relative nonexceptional Euclidean comparison,not physical scalelessp0,
massive-vacuum/causal limit or absolute product normalization. chi4 stays
free,distinct from b0/kappa/IR freedom.

Inventory V0 from full actual GF,physical kinetic Hessian programs and
original qLambda source density. Include abstract potential/fermion supersets
for exclusion proofs. Vrho=Hessian of actual physical G at all source degrees.
M0=actual full field tangent,including constant B<-partialC and a<-Lambda.
Mrho comes from differentiating G in its conjugate source and then its
remaining field. Source jets require Euler adjoints;at zero external jets
their derivatives act on the internal tangent port. Preserve source-only/
one-port rows and exclusions. Source-quadratic classical terms are retained
before differentiation,not incorrectly discarded by a linear-source premise.

Rooted directed G/V paths vs independent multiset/permutation closures.
Each non-reference V consumes positive target grade;free gradezero two-port
terms are resummed. Bound the finite number of V factors from actual target
grade,not an imposed Born truncation. Root M has no propagator. Its two
positive-heat members have lengths2n and2(n+1),opposite signs. Retain their
matrix order,internal jets and all original monomial references. The typed
inventory is not a measured coefficient tensor or proof of cancellation.

Next derive the smallest COMPLETE generic graded Gaussian cutoff kernel
and then its actual model contraction if justified by the support. Test
noncommuting order,source signs,auxiliary ports,finite heat and source-Euler
terms with distinct derivations and sensitive controls. Compare known N5
only after independent construction. Possible outcomes:qualified selected
regulator coefficient;precise missing premise;nonzero remainder;bounded
inconclusiveness. None alone completes QAP/E5 or proves an anomaly.

Sequential natives300s/reviews180s afterimports,8GiB sampled private memory,
350MiB available-pagefile launch floor,32MiB packet. Freeze exact inputs,
source copies and failure conditions before each computation. Preserve full
captures and all failures;no silent resource expansion. Reuse old qualified
science without expensive repetition. Shared action,charts,helpers,data,
runtime and AI author remain limits on independence.
