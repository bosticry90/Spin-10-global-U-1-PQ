# RSH2: direct cutoff coefficient at the selected nonzero witness

Prospective after RSH1 support. Rooted paths have n=2..5 V factors and
heat pairs(n,n+1),so BOTH n4 and n5 affect formal log5. There are197/378
typed words for probes0/1,not all nonzero amplitudes. Do not omit either
ordinary M0 or probe Mrho,or any source-dependent density before differentiation.

Calculate the original canonical witness r13,h0,x137 for both probes,
with SYMBOLIC g10,xi,eta_H. This is a selected coefficient,not a full tensor.
Build the complete longitudinal boson/scalar/ghost quadratic blocks from
qualified CLASSICAL G0,N0,J0,Jrho,S0,Srho,R,beta,Z0,rho-source BB/aC data.
Derive Mrho anew from the full actual G polynomial with source Euler
adjoints and Wick phases. Derive the gauge tangent from raw actual field
maps and charts,then compare its representation with QC. Include all the
other actual nonminimal/scalar tangents. Fermion and potential exclusions
are supplied by COMPLETE RSH1 superfamily support,not missing tables.

Use epsilon-left even variation with ordered odd bits epsilon,rho,JL,C;
intrinsic n and scalar x are even squarefree grades. For each q orientation
construct G0,V,M. Keep the literal graded Hessian signs,including ghost
offdiagonal inverse signs. The cutoff series is

    sum_n (-1)^n STr[(G0 V)^n M] (E^n-E^(n+1)).

The paired-q normalization is the average of the two oriented supertraces,
since the Euclidean Gaussian half-trace combines the two congruence terms.
Primary multiplies full graded sparse matrices. Replay roots paths at each
actual M entry and advances sparse state vectors;it does not read primary
output or the known quantum remainder. Independent Euclidean graded-Gaussian
congruence/inverse checks must verify order and normalization before any
Ward interpretation. Preserve uncommuting matrix order.

Every vector segment is forced longitudinal by the source auxiliary port,
mixed intrinsic port,scalar-current derivative or constant B<-partialC
tangent. No closed Lorentz spectator remains in these target cycles;check
this against all RSH1 words before using the q-axis reduction/fixed Djet0.
The radial cutoff pair integrates to log((n+1)/n)/(16pi^2). Keep n2..5
separate before formal-prime reduction. No chi4 can be fitted.

Native inputs contain no measured IAG F5,ISD H or USR partial-H coefficient.
Only after both calculations complete compare the independently measured
formal log5 coefficient against the prior relative-conversion witness.
Report exact disagreement rather than correcting a sign to force a result.
Even agreement would establish only a selected regulated symbol coefficient,
not the full source identity,absolute subtraction,analytic product domain,
Ihat/measure/QAP or E5. These dependencies remain explicit.

Same native300/review180s,8GiB sampled,350MiB launch floor,32MiB packet.
Actual limits/captures/source copies bound prospectively. Any failed source,
calculation or comparison is preserved;no altered quantum input or tolerance.
