from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('kernel_v4_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b and all(q['q_orientations_agree']for q in a['results'])
# Load the already frozen native definitions,not its output loop. All
# validation inputs are separately authenticated before these guards run.
p=O/'kernel_v4.py';src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));ns={'__file__':str(p),'__name__':'RSH4_CLASSICAL_OPERATOR_REVIEW'};oldargs=sys.argv;sys.argv=[str(p),'primary'];helper_source='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # frozen reviewer permits authenticated late comparison');exec(compile(helper_source,str(p), 'exec'),ns);sys.argv=oldargs;ns['timer'].cancel()
for x in range(64):
 for y in range(64):
  one=ns['constant'](1);got=ns['pmul']({x:one},{y:one});expected={}if x&y else{x|y:((-1)**sum(i>j for i in range(4)for j in range(4)if x&(1<<i)and y&(1<<j)))*one};assert got==expected
ip=read(O/'kernel_validation_inputs.json');helpers=Path(ip['CSW_helpers']).read_text();nodes=ast.parse(helpers);needed={'ec','ea','es','em','ei','elog','mz','mid','ma','ms','mm','mst','st','bodyinv','minv','det2','inv2','sdet4','fixture'};sc={'F':F,'defaultdict':defaultdict,'sy':s};exec(compile(ast.Module(body=[n for n in nodes.body if isinstance(n,ast.FunctionDef)and n.name in needed],type_ignores=[]),'<RSH4_frozen_CSW_finite_algebra>', 'exec'),sc);controls=[0,0]
for j in range(8):
 K,E,R,V,M,I=sc['fixture'](j);HH=sc['ma'](K,V);Gt=sc['minv'](sc['ma'](HH,R));sharp=sc['mst'](M);dh=sc['ma'](I,sc['ms'](sc['mm'](sharp,HH),-1),sc['ms'](sc['mm'](HH,M),-1));lhs=sc['es'](sc['st'](sc['mm'](Gt,dh)),F(1,2));rhs=sc['ea'](sc['es'](sc['st'](sc['mm'](Gt,I)),F(1,2)),sc['es'](sc['st'](M),-1),sc['st'](sc['mm'](sc['mm'](Gt,R),M)));assert lhs==rhs;controls[0]+=int(sc['st'](sc['mm'](sc['mm'](R,Gt),M))!=sc['st'](sc['mm'](sc['mm'](Gt,R),M)));controls[1]+=int(sc['st'](sc['mm'](sc['mm'](Gt,M),HH))!=sc['st'](sc['mm'](sc['mm'](Gt,sharp),HH)))
assert controls==[8,8]
# Independent RIGHT-source route. Only zero-external-jet terms of the
# literal source polynomial survive;source adjoints act on the internal port.
audit=ns['audit'];names=ns['names'];sources=ns['sources'];fields=ns['fields'];pa=ns['pa'];aux=ns['aux'];cs=ns['cs'];CI=ns['CI'];co=ns['co'];comparisons=0
for probe in range(2):
 p=audit['physical_G'][probe]
 for q in [1,-1]:
  out={}
  for gp,w,ci in p['monomials']:
   if any(n not in fields and n not in sources for n,J in w):continue
   # The retained target roots have no remaining external sources. Count
   # action/source/field Wick phases globally in a different representation.
   jslots=[at for at,(n,J)in enumerate(w)if n in sources]
   if len(jslots)!=1:continue
   at=jslots[0];n,I=w[at];f=sources[n];output=ns['field'](f)
   if output is None:continue
   assert f in aux or f in ns['ants']
   countL=sum((sources[nn]if nn in sources else names[nn])in aux for nn,J in w);countB0=sum(names[nn].startswith('B')and names[nn].endswith('_0')for nn,J in w if nn in fields);countT=sum(sum(int(v)==0 for v in J)for nn,J in w);phase=s.expand(-(-s.I)**countL*s.I**(countB0+countT));baseco=ns['rawco'](p,ci,gp)*co(str(phase));suffix=sum(pa[names[nn]]for nn,J in w[at+1:]);sg=-(-1)**((1-pa[f])*suffix)
   for j,(nf,J)in enumerate(w):
    if nf not in fields:continue
    inn=ns['field'](names[nf]);rest=[(nn,L)for k,(nn,L)in enumerate(w)if k not in[at,j]]
    if inn is None or any(nn in sources or names[nn]!=cs[0]or L for nn,L in rest)or len(rest)>1 or any(int(v)!=3 for v in list(I)+list(J)):continue
    after=[(nn,L)for k,(nn,L)in enumerate(w)if k>j and k!=at];move=(-1)**(pa[names[nf]]*sum(pa[names[nn]]for nn,L in after));n_degree=3-sum((1 if sources[nn]in aux else 2)if nn in sources else(2 if names[nn]in aux else 1)for nn,L in w)-sum(len(L)for nn,L in w)
    if n_degree not in[0,1]:continue
    v=sg*move*baseco*co(str((s.I*q)**len(J)*(-s.I*q)**len(I)));mask=3|(8 if rest else 0)|(16 if n_degree else 0);ns['add'](out,output,inn,mask,v)
  assert out==ns['mrho'](probe,q),('right_source_map_mismatch',probe,q);comparisons+=508*508
support=load(O/'support_replay_tables.json.gz');pins=0
for pr in support['results']:
 for word in pr['words']:
  path=word['G_path'];root=support['M_roots'][word['root_M']];assert not all(k=='B'for k in path)
  for at,vid in enumerate(word['V_word']):
   v=support['V_letters'][vid];a0,b0=v['ports'];gfrom=path[at]
   if(gfrom=='B')!=(a0=='B'):assert {gfrom,a0}=={'B','L'};pins+=1
   if(a0=='B')!=(b0=='B'):assert set([a0,b0])in[{'B','x'},{'B','a'}]and sum(v['internal_jet_orders'])==1;pins+=1
  a0,b0=root['ports']
  if(a0=='B')!=(b0=='B'):assert set([a0,b0])in[{'B','C'},{'B','L'}]and sum(root['internal_jet_orders'])==1;pins+=1
mp.mp.dps=70;rad=[]
for n in range(2,6):
 f=lambda u:(mp.exp(-2*n*u)-mp.exp(-2*(n+1)*u))/u if u else mp.mpf(2);v=mp.quad(f,[0,mp.mpf('.01'),1,mp.inf]);z=mp.quad(lambda x:1/x,[2*n,2*(n+1)]);expected=mp.log(mp.mpf(n+1)/n);assert max(abs(v-expected),abs(z-expected))<mp.mpf('1e-63')and abs(-v-expected)>mp.mpf('.3');rad.append(str(v))
# Late comparison AFTER independent operator/contraction checks. Reading
# this old table authenticates prior measurement,not a fresh quantum replay.
old=load(Path(ip['old_IAG_F5']));late=[]
for probe,z in enumerate(a['results']):
 known={tuple(v[:-1]):co(v[-1])for v in old['results'][probe]['F_m']['5']}.get((13,0,137),0);new=co(z['finite_prime_basis']['log5']);assert known+new==0;late.append({'probe':probe,'known_conversion_log5':str(known),'measured_cutoff_log5':str(new),'sum':str(known+new)})
assert read(O/'endpoint_validation_receipt.json')['V3_vector_endpoint_fails_four_sensitive_cases']and not(O/'kernel_v3_validation_receipt.json').exists();assert not(O/'kernel_v2_primary_result.json').exists()
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_V4_contractions_prime_bases_and_q_orientations_agree':True,'literal_endpoint_V3_rejected_V4_corrected':True,'all_4096_exterior_squarefree_products_pass':True,'eight_finite_Euclidean_Gaussian_operator_checks_pass':True,'sensitive_wrong_order_sharp_controls':controls,'independent_right_source_Mrho_full_positions':comparisons,'longitudinal_pin_occurrences_checked':pins,'radial_pairs_n2_through5_pass':True,'late_selected_log5_comparisons':late,'selected_coefficient_only_not_full_Ward_or_QAP':True,'chi4_b0_kappa_IR_not_fixed_or_identified':True},sort_keys=True),flush=True);timer.cancel()
