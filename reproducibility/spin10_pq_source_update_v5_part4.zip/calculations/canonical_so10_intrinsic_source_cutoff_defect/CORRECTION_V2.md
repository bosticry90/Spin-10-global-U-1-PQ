# Prelaunch input-schema correction

The original RSH2 preparer failed with KeyError R while assembling the
replay input. Primary's partial input exists;neither scientific kernel
launched and no original kernel preparation or qualification receipt exists.
Replay's input stores raw source_Qx,whereas its separately qualified
classical operand OUTPUT supplies the aligned R table. This is not an
unknown quantum input. The original preparer,proposed kernel,partial
inputs,controller traceback and failure record remain immutable.

V2 binds the primary/replay CLASSICAL operands outputs explicitly and uses
their R matrices. These were independently reconstructed and checked in
USR3;they are reused evidence,not fresh R reconstructions in this native.
No measured quantum remainder is used. New filenames keep original failed
preparation artifacts unchanged. Kernel changes are only IO filenames and
the corresponding peer guard. Mathematical requirements and bounds remain.
