from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation_v4.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('kernel_v4_'+('replay'if role=='primary'else'primary')):raise PermissionError('RSH2_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_auxiliary_ghost_source','canonical_so10_unprobed_source_root_module','canonical_so10_intrinsic_full_source_descent']and p.name.startswith(('color_','integration','variation','partial_H')):raise PermissionError('RSH2_KNOWN_QUANTUM_REMAINDER_DENIED')
sys.addaudithook(guard)
cp=Path(read(O/'kernel_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,I as CI,constant,verify_basis_products
assert verify_basis_products()==1024
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def dec(z):return {(i,j):co(v)for i,j,v in z['entries']}
def tab(z):return {tuple(q[:-1]):co(q[-1])for q in z}
def tidy(d):return {k:v for k,v in d.items()if v!=0}
def padd(a,b):
 out=dict(a)
 for k,v in b.items():out[k]=out.get(k,0)+v
 return tidy(out)
@lru_cache(None)
def sign(a,b):return (-1)**sum((b&((1<<i)-1)).bit_count()for i in range(4)if a&(1<<i))
def pmul(a,b):
 out=defaultdict(lambda:0)
 for m,v in a.items():
  for n,w in b.items():
   if not m&n:out[m|n]+=sign(m,n)*v*w
 return tidy(out)
def mm(A,B):
 by=defaultdict(list);out={}
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:
   q=pmul(v,w)
   if q:out[i,j]=padd(out.get((i,j),{}),q)
 return {ij:p for ij,p in out.items()if p}
nb=418;NC=418;NA=463;dim=508;par=lambda i:int(i>=nb);target=63;eps=1;rho=2;JJ=4;CC=8;NN=16;XX=32;r=13;h=0;ix=137
d=load(O/('kernel_v2_'+role+'_inputs.json.gz'));E=d['endings'];R=list(map(dec,d['R']));N=dec(E['N0']);J0=list(map(dec,E['J0']));S0=tab(d['S0']);beta=tab(d['maps']['beta_C_L']);alpha=tab(d['maps']['alpha_L']);qc=tab(d['maps']['qC_CC']);Z0=tab(d['Z0']);T=d['rho_source_vertices'];frame=d['frame'];xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns,A,inverse=False):return {(i,j):A.get((pi[ni],ri[nj])if inverse else(ri[ni],pi[nj]),0)for i,ni in enumerate(ns)for j,nj in enumerate(ns)if A.get((pi[ni],ri[nj])if inverse else(ri[ni],pi[nj]),0)}
TB=block([f'B{i}_3'for i in range(45)],TI);FB=block([f'B{i}_3'for i in range(45)],TF,True);TC=block(cs,TI);BC=defaultdict(lambda:0);BB=defaultdict(lambda:0)
for out,rows in d['field_maps'].items():
 if not(out.startswith('B')and out.endswith('_3')):continue
 a=int(out[1:].split('_')[0])
 for row in rows:
  ww=[n.partition('__')for n in row['word']]
  if any(n.startswith('A')for n,sp,j in ww):continue
  if len(ww)==1 and ww[0][0].startswith('C')and ww[0][2]=='3':
   c=int(ww[0][0][1:])
   for b in range(45):
    for k in range(45):
     if FB.get((b,a),0)and TC.get((c,k),0):BC[b,k]+=CI*FB[b,a]*co(row['coefficient'])*TC[c,k]
  elif len(ww)==2 and not any(j for n,sp,j in ww):
   if not(any(n.startswith('C')for n,sp,j in ww)and any(n.startswith('B')and n.endswith('_3')for n,sp,j in ww)):continue
   c=int(next(n[1:]for n,sp,j in ww if n.startswith('C')));b0=int(next(n[1:].split('_')[0]for n,sp,j in ww if n.startswith('B')))
   for b in range(45):
    for j in range(45):
     if FB.get((b,a),0)and TB.get((b0,j),0)and TC.get((c,h),0):BB[b,j]+=FB[b,a]*co(row['coefficient'])*TC[c,h]*TB[b0,j]
BC=tidy(BC);BB=tidy(BB);assert BC=={(i,i):CI for i in range(45)}
A=defaultdict(lambda:0)
for(k,a,b),v in qc.items():
 if a==h:A[k,b]+=v
 if b==h:A[k,a]-=v
A=tidy(A);assert BB==A,('actual_gauge_tangent_not_QC_chart',len(BB),len(A))
audit=d['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,u,k in geo['field_source_h_k']};fields={names.index(base[f]):base[f]for f,J,u,k in geo['field_source_h_k']};pa={n:p for n,p in zip(base,geo['parities'])};xiid={n:i for i,n in enumerate(xs)}
def field(n):
 if n in aux:return 45+aux.index(n)
 if n in xiid:return 90+xiid[n]
 if n in cs:return NC+cs.index(n)
 if n in ants:return NA+ants.index(n)
 if n.startswith('B')and n.endswith('_3'):return int(n[1:].split('_')[0])
 return None
def phase(n):
 if n in aux:return -CI
 if n.startswith('B')and n.endswith('_0'):return CI
 return constant(1)
def rawco(p,ci,gp):
 z=0
 for xp,ep,m,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*g**gp*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if m&(1<<j):v*=s.sqrt(q)
  if m&16:v*=s.I
  z+=v
 return co(str(z))
def cpow(a,n):
 out=constant(1)
 for _ in range(n):out=out*a
 return out
def mrho(probe,q):
 out={};p=audit['physical_G'][probe]
 for gp,w,ci in p['monomials']:
  if any(n not in fields and n not in sources for n,I in w):continue
  z=-rawco(p,ci,gp)
  for n,I in w:
   if n in sources:
    f=sources[n];z=z*((-1)**(pa[f]+1))*phase(f) # inverse phase is +/-1 or +/-i
    # phase(f)^-1=-phase(f) for +/-i,otherwise itself.
    if phase(f)==CI or phase(f)==-CI:z=-z
   else:z=z*phase(names[n])
   for jet in I:
    if int(jet)==0:z=z*CI
  for at,(n,I)in enumerate(w):
   if n not in sources:continue
   output=field(sources[n])
   if output is None:continue
   for j,(nf,J)in enumerate(w):
    if nf not in fields:continue
    inn=field(names[nf])
    if inn is None:continue
    rest=[(nn,K)for k,(nn,K)in enumerate(w)if k not in[at,j]]
    if any(nn in sources or names[nn]!=cs[h]or K for nn,K in rest)or len(rest)>1:continue
    if any(int(k)!=3 for k in list(I)+list(J)):continue
    sg=(-1)**((1-pa[sources[n]])*sum(pa[names[nn]]for nn,K in w[:at]));remaining=[(nn,K)for k,(nn,K)in enumerate(w)if k!=at];pos=next(k for k,v in enumerate(remaining)if v==(nf,J));sg*=(-1)**(pa[names[nf]]*sum(pa[names[nn]]for nn,K in remaining[pos+1:]));v=-sg*z*cpow(CI*q,len(J))*cpow(-CI*q,len(I));n_grade=3-sum((3-(2 if sources[nn]in aux else 1))if nn in sources else(2 if names[nn]in aux else 1)for nn,K in w)-sum(len(K)for nn,K in w)
    if n_grade not in[0,1]:continue
    mask=eps|rho|(CC if rest else 0)|(NN if n_grade else 0);out[output,inn]=padd(out.get((output,inn),{}),{mask:v})
 return out
def add(A,i,j,mask,v):
 if v:A[i,j]=padd(A.get((i,j),{}),{mask:v})
def pieces(probe,q):
 V={};groups={};G={}
 for(i,j),v in dec(E['G0']).items():add(G,i,j,0,q*v if(i<45<=j or j<45<=i)else v)
 for i in range(328):add(G,90+i,90+i,0,constant(1))
 for i in range(45):add(G,NC+i,NA+i,0,constant(1));add(G,NA+i,NC+i,0,constant(-1))
 for(b,j),v in N.items():add(V,b,90+j,NN,v);add(V,90+j,b,NN,v)
 for a,M in enumerate(R):
  for(j,i),v in M.items():
   if i==ix:add(V,a,90+j,XX,-CI*q*v);add(V,90+j,a,XX,CI*q*v)
 for(a,b),v in J0[h].items():
  v=q*v if b<45 else v;add(V,NA+a,b,CC,v);add(V,b,NA+a,CC,v if b<45 else -v)
 for(a,c,i),v in S0.items():
  if i==ix:add(V,NA+a,NC+c,NN|XX,v);add(V,NC+c,NA+a,NN|XX,-v)
  if c==h:add(V,NA+a,90+i,NN|CC,v);add(V,90+i,NA+a,NN|CC,-v)
 for(rr,c,a),v in beta.items():
  if rr==r:add(V,NC+c,45+a,JJ,-v);add(V,45+a,NC+c,JJ,v)
 for(rr,ch,a,c),v in Z0.items():
  if rr==r and ch==h:add(V,NA+a,NC+c,JJ|CC,v);add(V,NC+c,NA+a,JJ|CC,-v)
 Jr=dec(E['rho'][probe]['J']);Sr=dec(E['rho'][probe]['direct'])
 for(a,b),v in Jr.items():
  v=q*v if b<45 else v;add(V,NA+a,b,rho,v);add(V,b,NA+a,rho,v if b<45 else -v)
 for(a,i),v in Sr.items():add(V,NA+a,90+i,rho|NN,v);add(V,90+i,NA+a,rho|NN,-v)
 for rr,a,b,v in T[probe]['BB_Hessian_T']:
  if rr==r:add(V,a,b,rho|JJ,co(v))
 for rr,a,c,v in T[probe]['aC_density_U']:
  if rr==r:add(V,NA+a,NC+c,rho|JJ,co(v));add(V,NC+c,NA+a,rho|JJ,-co(v))
 m={}
 for(i,j),v in BC.items():add(m,i,NC+j,eps,q*v)
 groups['M0_BC']=m;m={}
 for(i,j),v in alpha.items():add(m,NA+i,45+j,eps,v)
 groups['M0_aL']=m;m={}
 for(i,j),v in BB.items():add(m,i,j,eps|CC,v);add(m,NC+i,NC+j,eps|CC,v)
 for(i,c,j),v in beta.items():
  if c==h:add(m,45+i,45+j,eps|CC,v);add(m,NA+i,NA+j,eps|CC,v)
 for(i,j),v in R[h].items():add(m,90+i,90+j,eps|CC,v)
 groups['M0_diagonal_C']=m;m={}
 for c,RR in enumerate(R):
  for(i,j),v in RR.items():
   if j==ix:add(m,90+i,NC+c,eps|XX,v)
 groups['M0_xC']=m;groups['Mrho']=mrho(probe,q)
 return G,V,groups
def tr(A):return sum(((-1)**par(i)*p.get(target,0)for(i,j),p in A.items()if i==j),0)
results=[]
for probe in range(2):
 orientations=[]
 for q in [1,-1]:
  G,V,groups=pieces(probe,q);X=mm(G,V);by_n=defaultdict(lambda:0);per={k:{}for k in groups}
  if role=='primary':
   power={(i,i):{0:constant(1)}for i in range(dim)}
   for n in range(1,6):
    power=mm(power,X)
    for name,M in groups.items():per[name][n]=(-1)**n*tr(mm(power,M));by_n[n]+=per[name][n]
    print('STAGE RSH2',role,probe,q,n,'power_entries',len(power),flush=True)
  else:
   # Root the ordered path at M;rowwise propagation has no unrooted V
   # matrix powers and retains external odd order before finite cyclicity.
   for name,M in groups.items():
    power=M
    for n in range(1,6):power=mm(power,X);per[name][n]=(-1)**n*tr(power);by_n[n]+=per[name][n]
    print('STAGE RSH2',role,probe,q,name,flush=True)
  orientations.append((dict(by_n),per))
 avg={n:co('1/2')*(orientations[0][0][n]+orientations[1][0][n])for n in range(1,6)};groupavg={name:{n:co('1/2')*(orientations[0][1][name][n]+orientations[1][1][name][n])for n in range(1,6)}for name in groups};assert avg[1]==0
 prime={'log2':-avg[2]+2*avg[3]-2*avg[4]+avg[5],'log3':avg[2]-avg[3]+avg[5],'log5':avg[4]-avg[5]}
 results.append({'probe':probe,'cutoff_pair_coefficients':{str(n):str(v)for n,v in avg.items()},'root_groups':{name:{str(n):str(v)for n,v in z.items()}for name,z in groupavg.items()},'finite_prime_basis':{k:str(v)for k,v in prime.items()},'q_orientations_agree':all(orientations[0][0][n]==orientations[1][0][n]for n in range(1,6))});print('STAGE RSH2_COEFFICIENT',role,json.dumps(results[-1],sort_keys=True),flush=True)
out={'schema':'RSH2_SELECTED_ACTUAL_CUTOFF_ROOT_COEFFICIENT','role':role,'indices':{'source':r,'ghost':h,'scalar':ix},'parameters_symbolic':True,'results':results,'known_quantum_remainder_not_operand':True,'actual_gauge_tangent_QC_chart_verified':True,'common_analytic_source_master_or_full_QAP_not_inferred':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('kernel_v4_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'selected_finite_prime_basis':[[q['probe'],q['finite_prime_basis']]for q in results],'quantum_remainder_fitted':False},sort_keys=True),flush=True);timer.cancel()
