# V4 preparation continuation

The original V4 controller stopped before writing its preparation or
launching either native:the endpoint review had already created the exact
ENDPOINT_RECORD source copy. Its exclusive-create call correctly refused
to overwrite that file. The failed controller/source remain preserved.

This continuation authenticates any already existing identical source copy
instead of overwriting it,then writes the FIRST V4 preparation and launches
the same proposed V4 kernel. A different copy is an error. No V4 calculation
was previously launched,so there is no interrupted handle or partial native
to restart. This changes custody plumbing only;it does not rebind an old
manifest,change a physical input or weaken the endpoint rejection of V3.
