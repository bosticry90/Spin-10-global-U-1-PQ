# VFC1: retain spectral placements before finite weighting

Write each current as (chi4+log(3/2))*L_pole+L_fixed. This decomposition
is qualified by VFU for each actual critical numerator,not inferred from
pole covariance. Its finite ratios fixed/u4 are

 GFT F:1/2,L:5/6;
 FCV FF:1/2,LF/FL:7/18,LL:exact0;
 FAV F:1/2,L:5/6;
 YGV fermion/scalar:1/2 each.

Thus GFT cannot be weighted as a single pole tensor. FAV requires its
Feynman tensor separately;the rest is the actual longitudinal pole tensor.
The primary retains both actual mixed auxiliary placements in that split.
The independent A_H family comes from FAV and is not optional.

Replay uses T_a with [T_a,T_b]=i f_abd T_d. Let CF,CW be actual carrier
Casimirs,CA,CAW actual adjoint Casimirs. The GFT ordered triple at a
weightX is (CX*T_c+T_c*CX-sum_d CAX_dc*T_d)/2 with its old phase-i.
This recovers its Feynman and(W-I) pieces independently of the primary
ordered contractions. The cubic vector sum for general units ff,lf is

 i*sum_d [ff*CA/2+lf*(CAW-CA)]_dc T_d.

Here ff=-3,lf=-3/4 for pole;ff=-3/2,lf=-7/24 for fixed. This formula
includes both longitudinal placements;do not double it again. Using the
barred-only pole-equivalent numerator would instead change lf to-5/8.

For FAV,derive N_ce=sum_rab U_rac * weight_ba * f_rbe from actual
qualified plane_U. Its old Gaussian/Wick phase multiplies N once,then
L_c=i N_ce T_e. The pole weight is3/4 I+1/4 W;the fixed weight is
7/24 I+5/24 W. The primary's direct F/L separation gives the same result.
This is a full symbolic width polynomial,not evaluation at a new gauge.

YGV keeps its separately measured fermion and scalar currents with the
two full general family factors. Equal fixed ratios here permit weighting
their sum by1/2 only after all contributions have been retained. No new
scalar model contractions or two-loop integrations are necessary.

In CFC/CLO's fixed Euler convention,vertex q image is iL and p=0;
kinetic images are -[C,T] and-CT;generic source images use both chiral
endpoint matrices as PSF derives. The separate bosonic source Euler
image from BSF is added only at late comparison,including its fixed R.
There is no independent bosonic log(3/2) bubble term. This defines an
unfitted partial classical image of the selected relative functional.
Neither finite-part rearrangement nor an absent regulator term is
implicitly assumed. A nonzero result belongs to the outstanding actual
ordered heat/source-product transport question,not an anomaly conclusion.
