"""VFC1 weighted Casimir identities and actual auxiliary adjoint contraction."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');u=d['units'];F=d['F'];V=d['V'];U=d['U'];YV=d['YV'];T=list(map(dec,d['Y']['Tminus']));families={n:{p:{} for p in ['chi4','log3over2','fixed']} for n in ['GFT','FCV','FAV','YGV_fermion','YGV_scalar']}
def adjcurr(C):return [combine([C.d.get((e,c),Z) for e in range(45)],T) for c in range(45)]
cf,cw,ca,caw=map(dec,[F['carrier_total_Casimir'],F['C_width'],F['adjoint_total_Casimir'],F['adjoint_width_Casimir']]);aF,aW=adjcurr(ca),adjcurr(caw)
trF=[scale(minus(plus(mul(cf,t),mul(t,cf)),a),Q('1/2')) for t,a in zip(T,aF)];trW=[scale(minus(plus(mul(cw,t),mul(t,cw)),a),Q('1/2')) for t,a in zip(T,aW)]
for p in families['GFT']:
 x,y=(ratio(u,'GFT:F'),ratio(u,'GFT:L')) if p=='fixed' else (ONE,ONE)
 families['GFT'][p]['gauge']=arrscale(arrsum(arrscale(trF,x),arrscale(arrminus(trW,trF),y)),Q(F['combined_phase']))
vca,vcaw=map(dec,[V['adjoint_total_Casimir'],V['adjoint_width_Casimir']])
for p in families['FCV']:
 ff=Q(u['FCV:FF']['fixed' if p=='fixed' else 'pole']);lf=Q(u['FCV:LF']['fixed' if p=='fixed' else 'pole']);n=plus(scale(vca,prod(ff,Q('1/2'))),scale(minus(vcaw,vca),lf));families['FCV'][p]['gauge']=arrscale(adjcurr(n),prod(II,Q(V['combined_phase'])))
H=dec(d['Y']['H_new']);W=plus(scale(ident(45),Q('xi')),scale(mul(H,trans(H)),Q('eta_H-xi')));f=defaultdict(list)
for r,b,e,v in d['plane_f']:f[r,b].append((e,Q(v)))
A={}
for part in ['chi4','log3over2','fixed']:
 ff=Q(u['FAV:F']['fixed' if part=='fixed' else 'pole']);fl=Q(u['FAV:L']['fixed' if part=='fixed' else 'pole']);weight=plus(scale(ident(45),sub(ff,fl)),scale(W,fl));wr=defaultdict(list)
 for (b,a),v in weight.d.items():wr[a].append((b,v))
 for kind,n in [('B',45),('A',12)]:
  entries={}
  for r,a,c,z in U['plane_U'][kind]:
   v=prod(Q(z),Q(U['combined_phase']))
   for b,x in wr[a]:
    for e,y in f[r,b]:entries[c,e]=add(entries.get((c,e),Z),prod(v,prod(x,y)))
  N=Mat(n,45,entries);aa=[scale(combine([N.d.get((c,e),Z) for e in range(45)],T),II) for c in range(n)]
  if kind=='B':families['FAV'][part]['gauge']=aa
  else:A[part]=aa
for j,tag in enumerate(['Y10','Y126']):
 for old,new,unit in [('fermion','YGV_fermion','YGV:F'),('scalar','YGV_scalar','YGV:S')]:
  aa=list(map(dec,YV['outputs'][old]['left'][j]))
  for part in families[new]:families[new][part][tag]=arrscale(aa,ratio(u,unit)) if part=='fixed' else aa
package('replay',families,A,d['Y'],tick,'weighted_carrier_adjoint_Casimirs_and_independent_actual_auxiliary_Lie_map')
