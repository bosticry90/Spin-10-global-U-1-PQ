# VFC1: actual five-family marginal finite current assembly

Base7d09c5e428484cc0be2daa52d974c03b851352bf/main32389oldblobs.
Previous goal turn PROGRESS: FHK kinetic and VFU all five finite unit
families qualified. Whole investigation ACTIVE/incomplete,state113/34of39.
No running worker,changed input,benchmark or adoption. AGENTS governs.

Question: assemble the ACTUAL complete local BPP and independent A_H PP
relative finite currents from VFU's qualified units and the previously
measured model-specific color contractions. Then assess their ordinary
p/q image together with independently measured source/kinetic/bosonic
source coefficients. No cancellation is an assumed endpoint or fitted input.

Same provisional Euclidean raw-dimensional-minus-common-scalar-heat
local marginal member,p_hat0,barredrank4,internalhatsretained. Heatlength6
for all five vertex families,4 for kinetic. Use three symbolic carrier
factors g10² I3,Y10dagY10,Y126dagY126 under overall g10/(16pi²).
Keep widths eta_H,xi general,and all328 scalar inputs through their
qualified complete contractions. No family averaging,extra3,open half,
numerical Yukawa,mass,scale,gauge or baseline selection.

Primary uses actual ordered GFT F/L,FCV FF/LF/FL,FAV B/A F/L and two
YGV class tensors. Replay uses the independently qualified weighted
Casimir/double-commutator forms,actual FAV plane_U and full Lie tensor,
and independently calculated YGV tensors. Required finite ratios are
read from qualified VFU tables;phases and all placements count once.
Both build complete B45 and independent A12 currents,plus diagonal-H
projection B=H A with the independent A added. Right internal matrices
and family orientations remain inherited and are checked explicitly.

Only after both current outputs complete,gate reads withheld MGN UV sum,
FHK kinetic images,PSF generic proper source images,and BSF ordinary
bosonic source Euler map. Compute actual ordinary p/q partial image:
kinetic p/q + i*vertex q + source p/q + bosonic source q. Do not add an
unknown regulator insertion or require finite q=0. Yukawa source terms
are absent only in these actual marginal proper source families. Coupling
orders stay separate;the lower g²xi auxiliary-source sector is not merged.

Acceptance:all P/R family tensors,aggregates,B/A/H projections and zeros
agree;MGN common pole normalization recovered;Hermiticity/conjugate-right
and homogeneous H current laws hold. Negative controls omit/duplicate a
family or A,erase F/L separation,use barred-only FCV LF,wrong heat4 and
open half. Report insensitive directions explicitly. A shared nonzero
partial finite image qualifies a mismatch,not anomaly or full restoration.
Classical image calculation is not an independently constructed breaking
insertion. The chiral heat/source-product response remains unresolved.

Freeze eight sources/copies,immutable inputs/proof/ceilings first.
Sequential P/R/gate600safterimports,8GiB sampledprivate,350MiB available
commit floor,16MiB storedpacket. Fresh E4 readiness this goal turn and
new bytepreflight;custodyexit2/sevenNOTPASS. Stopfirstfailure;full failed
sources/native captures retained;version correction only. No agents,
branches/worktrees,resource expansion,reset,push or external action.

Ceiling:complete selected local marginal finite current tensor and
unfitted partial p/q assessment,not a full nonexceptional finite amplitude,
physical chiral prescription,QAP/products/measure/phase,massive matterC1,
E5/A5 or physical GUT. Keep old metric-Stokes applicability excluded for
chiral algebra until proved. Bothscalarwarnings,quartetFAIL,flavorpause,
HB1/C5 blocks and all distinct free constants remain. Shared action,
data,software and AI author are not independent scientific confirmation.
