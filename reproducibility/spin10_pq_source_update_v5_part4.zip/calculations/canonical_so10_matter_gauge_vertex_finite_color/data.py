"""VFC1 exact current assembly helpers and bounded pole-blind IO."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('VFC1_PEER_OR_IMAGE_CONTROL_DENIED')
   if p.parent.name in ['canonical_so10_open_fermion_heat_kinetic','canonical_so10_proper_matter_source_finite','canonical_so10_bosonic_source_onejet_finite','canonical_so10_coupled_fermion_finite_counterterm'] and p.name.endswith('.gz'):raise PermissionError('VFC1_OLD_IMAGE_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def arrsum(*aa):return [combine([ONE]*len(ms),list(ms)) for ms in zip(*aa)]
def arrscale(a,z):return [scale(m,z) for m in a]
def arrminus(a,b):return arrsum(a,arrscale(b,Q(-1)))
def right(a):return arrscale(list(map(trans,a)),Q(-1))
def ratio(units,tag):return Q(str(sy.sympify(units[tag]['fixed'])/sy.sympify(units[tag]['pole'])))
def project(a,H):
 out=[]
 for h in range(12):out.append(combine([H.d.get((c,h),Z) for c in range(45)],a))
 return out
def package(role,families,A,Y,tick,meta):
 B={};diagonal={};H=dec(Y['H_new'])
 for part in ['chi4','log3over2','fixed']:
  B[part]={};diagonal[part]={}
  for tag in ['gauge','Y10','Y126']:
   left=arrsum(*(families[n][part][tag] for n in families if tag in families[n][part]));rr=right(left);B[part][tag]={'left':list(map(enc,left)),'right':list(map(enc,rr))}
   lp=project(left,H)
   if tag=='gauge':lp=arrsum(lp,A[part])
   diagonal[part][tag]={'left':list(map(enc,lp)),'right':list(map(enc,right(lp)))}
 d={'method':meta,'families':{n:{p:{t:list(map(enc,aa)) for t,aa in ds.items()} for p,ds in ps.items()} for n,ps in families.items()},'B':B,'A':{p:{'left':list(map(enc,a)),'right':list(map(enc,right(a)))} for p,a in A.items()},'diagonal_H':diagonal,'role':role,'elapsed_after_imports':time.perf_counter()-tick,'family_count':5,'B_directions':45,'independent_A_directions':12,'scalar_supports_retained':328,'general_family_factors_retained':True,'carrier_factors':{'gauge':'g10^2*I3','Y10':'Y10dagger*Y10','Y126':'Y126dagger*Y126'},'overall_factor':'g10/(16*pi^2)','heat_length':6,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_coupled_restoration_claimed':False,'full_regulated_p_insertion_derived':False,'new_model_integrations':0}
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
