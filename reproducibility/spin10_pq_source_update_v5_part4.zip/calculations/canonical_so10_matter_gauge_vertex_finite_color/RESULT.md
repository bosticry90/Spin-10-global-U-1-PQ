# VFC1: all five model-specific marginal finite current families assembled

Qualified in the specified provisional Euclidean local comparison member:
RAW_DIMENSIONAL_MINUS_COMMON_SCALAR_HEAT,barredrank4,physicalexternalhats0.
The result includes all45 total-B currents and the independent12 A_H
currents,with general widths and three factorized family directions.
This is a local marginal finite comparison,not a complete nonexceptional
finite amplitude or a physical chiral prescription.

Receipt validation_receipt.json SHA256
59c06e053092024b43b0adde3fb9136e8d1ad0481d1f31721c9e6812cb1868ec,
status QUALIFIED_COMPLETE_FIVE_FAMILY_MARGINAL_FINITE_GAUGE_CURRENT.
Scientific/director acceptance NOT_PERFORMED; state113/authority34of39
unchanged. Whole investigation remains ACTIVE/incomplete.

## Actual coefficients,not an adjusted Ward target

Under common overall g10/(16pi²),the carrier factors are g10² I3,
Y10daggerY10 and Y126daggerY126. Each current is represented as

```
L_relative=(chi4+log(3/2))*L_pole+L_fixed.
```

Primary independently weights the actual ordered measured color pieces:
GFT F/L with ratios1/2,5/6;FCV FF/LF/FL with1/2,7/18,7/18;FAV F/L with
1/2,5/6;both YGV current classes with1/2. It retains both mixed auxiliary
placements and the separate A family. Replay instead uses weighted carrier
and adjoint Casimir identities and contracts the actual FAV plane_U with
the Lie tensor and weight7/24 I+5/24 W. Its YGV inputs come from the
separately qualified scalar covariance route. No expensive complete model
contraction or two-loop integral is repeated.

The methods agree on all207,360 retained B color positions including zeros,
all independent A currents and diagonal-H projections. There are720
nonzero aggregate B positions per chirality/carrier/direction;these are
algebraic coordinates,not particles or independent experiments. The exact
MGN ultraviolet sum is recovered in the common coefficient. General family
matrices and all328 scalar input directions remain through their qualified
complete contractions. Physical reality/conjugate-right relations and6480
homogeneous H current checks pass. The independent A is included in the
diagonal-H projection before assessment.

Finite-sensitive omission controls change the actual tables:GFT720,
FCV720,FAV715,YGVfermion1440,YGVscalar1440,independentA92 positions.
Erasing the GFT or FAV F/L separation changes720 or715 positions. Using
barred-only FCV longitudinal contraction changes720 positions although its
pole is identical. Wrong heatlength4 or an extra open-line half changes
the nonzero common normalization. No unmeasured finite tensor was assigned
to obtain a desired identity.

## The selected combined classical image remains nonzero

Only after both finite current calculations completed,the gate combined
the FHK kinetic image,these vertex q images,the PSF ordinary proper-source
image and the BSF ordinary bosonic-source Euler contribution. The p/q
images retain their separate derivative slots and coupling carriers.

| Direction | Gauge p per chirality | Gauge q | Y10 q | Y126 q |
| --- | ---: | ---: | ---: | ---: |
| chi4 | 0 | 0 | 0 | 0 |
| log(3/2) | 512 | 720 | 720 | 720 |
| fixed | 512 | 720 | 720 | 720 |

Yukawa p is zero in every direction. The gauge p remains exactly the
previously measured (log(3/2)+1/12)[CW,T]. The new q tables are nonzero;
their physical reality relation qdagger=q-p is checked coefficientwise.
No regulator insertion was inserted into this comparison. The lower
g²xi source sector is separate and is not included in this ordinary g³
assessment. The free chi4 is retained;its direction cancels in the complete
selected image without a baseline choice.

Full partial-image table packed/raw SHA256:
164baaf59d9f289da7bf0025bdbb8fd68dc11291e77ce9175864b616f541204d /
95505c29ae91c7b7ea46ed75233c5471e57aea2027f042a3ca9f75160536d17d.
These nonzero terms identify a required regulator/source-product response.
They are not independent anomalies,proof of incompatibility,or a completed
renormalized Slavnov identity. A local algebraic image is not an independent
calculation of the actual breaking insertion. The old nonchiral Stokes
theorem still does not automatically cover this chiral construction.

## Execution and carry-forward

Eight source copies and1277/1285 initial/validation bindings frozen before
sequential observed P/R/gate. Native exits0;4.6268575/3.1261613/10.0999805s
afterimports. Their3/3/6 memory samples have maxima63,303,680/64,901,120/
155,111,424 bytes,not peaks. Frozen600s each/8GiB sampledprivate/350MiB
availablecommit floor/16MiB packet limits respected. No failed worker,
gate or controller. Complete captures and source copies are retained in
the repository and external matter-gauge-vertex-finite-color-v1-2026-10-23
control folder. Fresh E4 command executed this goal turn:native0,step exits
0,0,0,0,0,2. Custody remains exit2/seven unresolved NOTPASS.

This supplies the previously missing complete model-specific local current
input. The next priority is an actual ordered heat/source-product insertion
calculation with a justified common first-variation domain. Begin with the
Yukawa q channel:its complete source-free kinetic and two proper-current
inputs are now measured,and its p slot is zero. Derive the scalar/fermion
line Ward contraction and heat endpoint terms before integration,retaining
physical source derivatives. Its nonzero target is an assessment comparator,
never an input chosen to define the insertion. This can test the quantum
bridge on a complete nonzero carrier before the two-width gauge response.

Shared physical assumptions,action,representation data,Python/SymPy and AI
author limit independence. Agreement corroborates the mathematical
implementation;it does not establish the physical model's validity.
Full chiral regulator/source response,products/QAP,measure/phase,physical
prescription,massive matterC1,E5/A5 and physical unification remain open.
Both adverse scalar benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks,
custody,gauge gaps and distinct free finite constants remain. No oldbytes,
physical input,foundation,state or scheme changed. No branch/worktree,
agents,external action,publication or remote push.
