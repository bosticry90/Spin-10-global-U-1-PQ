"""VFC1 complete current comparison,finite-sensitive controls and late images."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');di=packed(HERE/'primary_inputs.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['families','B','A','diagonal_H','carrier_factors','overall_factor']:assert P[k]==R[k],k
T=list(map(dec,di['Y']['Tminus']));H=dec(di['Y']['H_new']);TH=project(T,H);f={(a,b,c):Q(z) for a,b,c,z in late['plane_f']};hact={}
for h in range(12):
 for c in range(45):
  rr=[]
  for e in range(45):
   z=Z
   for a in range(45):z=add(z,prod(H.d.get((a,h),Z),f.get((a,c,e),Z)))
   if z:rr.append((e,z))
  hact[h,c]=rr
covchecks=0;positions=0;counts={}
for part in ['chi4','log3over2','fixed']:
 counts[part]={}
 for tag in ['gauge','Y10','Y126']:
  left=list(map(dec,P['B'][part][tag]['left']));rightm=list(map(dec,P['B'][part][tag]['right']));positions+=2*45*16**2;counts[part][tag]=sum(len(m.d) for m in left)
  for a,b in zip(left,rightm):zero(plus(a,trans(star(a))));zero(plus(b,trans(a)))
  for h in range(12):
   for c in range(45):zero(minus(minus(mul(TH[h],left[c]),mul(left[c],TH[h])),scale(combine([z for e,z in hact[h,c]],[left[e] for e,z in hact[h,c]]) if hact[h,c] else Mat(16,16),II)));covchecks+=1
  lp=project(left,H)
  if tag=='gauge':lp=arrsum(lp,list(map(dec,P['A'][part]['left'])))
  assert list(map(enc,lp))==P['diagonal_H'][part][tag]['left']
 for a,b in zip(map(dec,P['A'][part]['left']),map(dec,P['A'][part]['right'])):zero(plus(a,trans(star(a))));zero(plus(b,trans(a)))
 aa=list(map(dec,P['A'][part]['left']));shadow=[combine([H.d.get((c,h),Z) for h in range(12)],aa) for c in range(45)]
 for h in range(12):
  for c in range(45):zero(minus(minus(mul(TH[h],shadow[c]),mul(shadow[c],TH[h])),scale(combine([z for e,z in hact[h,c]],[shadow[e] for e,z in hact[h,c]]) if hact[h,c] else Mat(16,16),II)));covchecks+=1
 for side in ['left','right']:
  for j,tag in enumerate(['gauge','Y10','Y126']):assert P['B']['chi4'][tag][side]==late['MGN']['loop_B'][side][j]
  assert P['A']['chi4'][side]==late['MGN']['loop_A'][side]
assert positions==207360
comparison={};rc={}
for part in ['chi4','log3over2','fixed']:
 comparison[part]={};rc[part]={}
 for tag in ['gauge','Y10','Y126']:
  comparison[part][tag]={};rc[part][tag]={}
  for side in ['left','right']:
   kin=late['FHK']['kinetic_Euler_images'][part][tag][side];vv=P['B'][part][tag][side];src=late['PSF']['source_Euler_images']['ordinary'][part][side] if tag=='gauge' else None;bb=late['BSF']['matter_q_images'][side]['ordinary']['chi' if part=='chi4' else 'fixed'] if tag=='gauge' and part!='log3over2' else None;pp=[];qq=[]
   for c in range(45):
    p=dec(kin['p'][c]);q=plus(dec(kin['q'][c]),scale(dec(vv[c]),II))
    if src:p=plus(p,dec(src['p'][c]));q=plus(q,dec(src['q'][c]))
    if bb:q=plus(q,dec(bb[c]))
    zero(plus(p,trans(star(p))));zero(minus(trans(star(q)),minus(q,p)))
    pp.append(enc(p));qq.append(enc(q))
   comparison[part][tag][side]={'p':pp,'q':qq};rc[part][tag][side]={'p':sum(len(dec(m).d) for m in pp),'q':sum(len(dec(m).d) for m in qq)}
   if part=='chi4':assert rc[part][tag][side]=={'p':0,'q':0}
# Controls measure actual coefficient changes,not a chosen Ward target.
controls={}
for n,parts in P['families'].items():controls['omit_'+n]=sum(len(dec(m).d) for a in parts['fixed'].values() for m in a);assert controls['omit_'+n]>0
controls['omit_independent_A']=sum(len(dec(m).d) for m in P['A']['fixed']['left']);assert controls['omit_independent_A']>0
fpart=list(map(dec,di['F']['Feynman_left']));lpart=list(map(dec,di['F']['longitudinal_left']));wrong=arrscale(arrsum(fpart,lpart),Q('1/2'));actual=list(map(dec,P['families']['GFT']['fixed']['gauge']));controls['erase_GFT_F_L_separation']=sum(len(minus(a,b).d) for a,b in zip(actual,wrong));assert controls['erase_GFT_F_L_separation']>0
lf=arrsum(list(map(dec,di['V']['parts']['LF']['left'])),list(map(dec,di['V']['parts']['FL']['left'])));controls['barred_only_FCV_longitudinal']=sum(len(m.d) for m in arrscale(lf,Q('4/9')));assert controls['barred_only_FCV_longitudinal']>0
controls['erase_FAV_F_L_separation']=sum(len(minus(dec(a),scale(dec(b),Q('1/2'))).d) for a,b in zip(P['families']['FAV']['fixed']['gauge'],P['families']['FAV']['chi4']['gauge']));assert controls['erase_FAV_F_L_separation']>0
controls['wrong_heat4_or_open_half']=sum(len(dec(m).d) for t in P['B']['chi4'].values() for m in t['left']);assert controls['wrong_heat4_or_open_half']>0
raw=(json.dumps({'partial_p_q_images':comparison,'nonzero_counts':rc,'full_regulated_insertion_derived':False,'full_coupled_restoration_claimed':False},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'comparison_tables.json.gz').open('xb') as out:out.write(blob)
for d in [P,R]:assert d['family_count']==5 and d['scalar_supports_retained']==328 and not any(d[k] for k in ['physical_scheme_adopted','quantum_coefficient_fitted','full_coupled_restoration_claimed','full_regulated_p_insertion_derived','new_model_integrations'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_FIVE_FAMILY_MARGINAL_FINITE_GAUGE_CURRENT','elapsed_after_imports':time.perf_counter()-tick,'B_color_positions_compared':positions,'B_nonzero_counts_per_chirality':counts,'A_directions':12,'B_directions':45,'family_count':5,'scalar_supports_retained':328,'general_family_factors_retained':True,'current_H_covariance_checks':covchecks,'all_current_coefficients_and_zero_complements_match':True,'old_MGN_pole_sum_reproduced_exactly':True,'partial_p_q_image_nonzero_counts':rc,'negative_control_changed_positions':controls,'comparison_tables_sha256':digest(HERE/'comparison_tables.json.gz'),'comparison_raw_sha256':sha256(raw).hexdigest(),'actual_model_current_assembly_completed':True,'full_nonexceptional_vertex_amplitude_qualified':False,'full_regulated_p_insertion_derived':False,'full_coupled_restoration_claimed':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
