"""VFC1 direct ordered measured tensors and distinct finite placement weights."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');u=d['units'];F=d['F'];V=d['V'];U=d['U'];YV=d['YV'];families={n:{p:{} for p in ['chi4','log3over2','fixed']} for n in ['GFT','FCV','FAV','YGV_fermion','YGV_scalar']}
ff=list(map(dec,F['Feynman_left']));fl=list(map(dec,F['longitudinal_left']));pole=arrsum(ff,fl);fixed=arrsum(arrscale(ff,ratio(u,'GFT:F')),arrscale(fl,ratio(u,'GFT:L')))
for p in ['chi4','log3over2','fixed']:families['GFT'][p]['gauge']=fixed if p=='fixed' else pole
parts={n:list(map(dec,V['parts'][n]['left'])) for n in ['FF','LF','FL']};pole=arrsum(*parts.values());fixed=arrsum(*(arrscale(a,ratio(u,'FCV:'+n)) for n,a in parts.items()))
for p in families['FCV']:families['FCV'][p]['gauge']=fixed if p=='fixed' else pole
A={}
for kind in ['B','A']:
 total=list(map(dec,U['outputs'][kind]['left']));ff=list(map(dec,U['outputs'][kind]['omit_longitudinal']));fl=arrminus(total,ff);fixed=arrsum(arrscale(ff,ratio(u,'FAV:F')),arrscale(fl,ratio(u,'FAV:L')))
 for p in ['chi4','log3over2','fixed']:
  a=fixed if p=='fixed' else total
  if kind=='B':families['FAV'][p]['gauge']=a
  else:A[p]=a
for j,tag in enumerate(['Y10','Y126']):
 for old,new,unit in [('fermion','YGV_fermion','YGV:F'),('scalar','YGV_scalar','YGV:S')]:
  aa=list(map(dec,YV['outputs'][old]['left'][j]))
  for p in families[new]:families[new][p][tag]=arrscale(aa,ratio(u,unit)) if p=='fixed' else aa
package('primary',families,A,d['Y'],tick,'qualified_ordered_triples_FF_LF_FL_actual_auxiliary_F_L_and_Yukawa_classes')
