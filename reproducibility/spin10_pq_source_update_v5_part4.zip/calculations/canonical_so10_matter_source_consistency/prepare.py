"""MSC1 source/input freeze; all numerical breaking tensors remain immutable."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-source-consistency-v1-2026-10-23');BASE='b5a27ab9db5802afae8c58eb272d913bceef804f'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();bind={}
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
def add(p,want=None):
 p=p.resolve();h=digest(p)
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V520.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(PK/'export_a10_e5_antighost_vector.py')
deps={
 'canonical_so10_sterile_matter_action':(['ACTION_V1.md','validation_receipt.json'],'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_yukawa_carrier_transport':(['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b'),
 'canonical_so10_quartic_ghost_source_insertion':(['replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'2e8d4600a9f30e73ca720edd70677b16b0fa92d53bc95882c9a6370039ec9ee4'),
 'canonical_so10_complete_matter_source_breaking':(['RECORD.md','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz','validation_preparation.json','validation_receipt.json'],'c6eee8c9655d4acc68ffdc7f3e729a8541b2a4d1091fa3ef59c58334ffd6eb6a')}
for folder,(names,rh) in deps.items():
 for n in names:add(CAL/folder/n,rh if n=='validation_receipt.json' else None)
for folder,names in [('canonical_so10_quartic_ghost_source_insertion',['replay_tables.json.gz']),('canonical_so10_complete_matter_source_breaking',['primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz'])]:
 old=read(CAL/folder/'validation_preparation.json')['input_sha256']
 for n in names:assert digest(CAL/folder/n)==old[str((CAL/folder/n).resolve())]
prior=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-matter-source-breaking-v1-2026-10-23');add(prior/'postcommit_seal.json')
source=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-breaking-support-v1-2026-10-22')
for n in ['readiness.jsonl','readiness_stderr.txt','postcommit_seal.json']:add(source/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31358
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'MSC1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
for n in ['readiness.jsonl','readiness_stderr.txt']:
 with (CONTROL/n).open('xb') as f:f.write((source/n).read_bytes())
with (CONTROL/'readiness_reuse.json').open('xb') as f:f.write((json.dumps({'fresh_readiness_execution_here':False,'source_was_fresh_in_this_logical_goal_turn':True,'source_sha256':{str(source/n):digest(source/n) for n in ['readiness.jsonl','readiness_stderr.txt']},'expensive_historical_science_replayed':False},sort_keys=True)+'\n').encode())
print('MSC1_FROZEN',len(bind),'bindings',flush=True)
