"""MSC1 independent measured scalar-Lie assembly and six-term CE operation."""
from data import *
from collections import defaultdict
from itertools import combinations
start=begin('replay')
CMS=packed(CAL/'canonical_so10_complete_matter_source_breaking/replay_tables.json.gz');QSI=packed(CAL/'canonical_so10_quartic_ghost_source_insertion/replay_tables.json.gz');ref=packed(CAL/'canonical_so10_complete_matter_source_breaking/qualified_reference_inputs.json.gz')['reference_fields']
f={tuple(row[:3]):s.sympify(row[3]) for row in ref['plane_f']};fc=defaultdict(list)
for (a,b,e),co in f.items():fc[a,b].append((e,co))
def clean(tab):return {key:s.expand(co) for key,co in tab.items() if s.expand(co)!=0}
def decode(rows):return {tuple(row[:3]):s.sympify(row[3],locals={'eta_H':WH,'xi':WM}) for row in rows}
cycle={name:decode(CMS['Lie_cycles'][name]) for name in ['BB','B_Lambda','Lambda_B']};bare={p:{} for p in ['3','4']}
for power,b,c,e,co in QSI['Lie_contraction']:bare[str(power)][b,c,e]=-s.sympify(co,locals={'eta_H':WH,'xi':WM})/2
def plus(*args):
 out=defaultdict(lambda:s.S.Zero)
 for tab in args:
  for key,co in tab.items():out[key]+=co
 return clean(out)
r={'3':plus(cycle['B_Lambda'],cycle['Lambda_B'],bare['3']),'4':plus(cycle['BB'],bare['4'])}
def differential(tab):
 bypair=defaultdict(list)
 for (a,b,e),co in tab.items():assert a<b;bypair[a,b].append((e,co))
 def get(a,b):return bypair[a,b] if a<b else [(e,-co) for e,co in bypair[b,a]] if b<a else []
 total={};module={};ghost={}
 for a,b,c in combinations(range(45),3):
  m=defaultdict(lambda:s.S.Zero);g=defaultdict(lambda:s.S.Zero)
  for outside,u,v,sign in [(a,b,c,1),(b,a,c,-1),(c,a,b,1)]:
   for inner,co in get(u,v):
    for e,h in fc[outside,inner]:m[e]+=sign*h*co
  for u,v,outside,sign in [(a,b,c,-1),(a,c,b,1),(b,c,a,-1)]:
   for inner,h in fc[u,v]:
    for e,co in get(inner,outside):g[e]+=sign*h*co
  mm,gg=clean(m),clean(g)
  for e,co in mm.items():module[a,b,c,e]=co
  for e,co in gg.items():ghost[a,b,c,e]=co
  for e,co in plus(mm,gg).items():total[a,b,c,e]=co
 return total,module,ghost
out={};mod={};gh={}
for p,tab in r.items():out[p],mod[p],gh[p]=differential(tab)
bare_d={p:differential(tab)[0] for p,tab in bare.items()};mixed_d={name:differential(cycle[name])[0] for name in ['B_Lambda','Lambda_B']}
exact={(a,b,e):s.expand((a+b-e+1)*co) for (a,b,e),co in f.items() if a<b};exact=clean(exact);dd,_,_=differential(exact);assert exact and not dd
def rows(tab):return [[*key,str(co)] for key,co in sorted(tab.items())]
finish('replay',{'method':'measured_quartic_and_oriented_cycles_scalar_Lie_assembly_explicit_six_term_CE','f':rows(f),'r':{p:rows(t) for p,t in r.items()},'dR':{p:rows(t) for p,t in out.items()},'module_part':{p:rows(t) for p,t in mod.items()},'ghost_part':{p:rows(t) for p,t in gh.items()},'bare_quartic_dR':{p:rows(t) for p,t in bare_d.items()},'mixed_orientation_dR':{n:rows(t) for n,t in mixed_d.items()},'exact_example_dX':rows(exact),'exact_example_ddX':rows(dd),'pair_count':990,'triple_count':14190,'scalar_component_count_per_order':638550,'coupling_orders':[3,4],'source_or_physical_scheme_changed':False,'full_quantum_consistency_claimed':False},start)
