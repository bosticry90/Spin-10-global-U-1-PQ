# MSC1: measured source tensor's classical consistency test

Question: is CMS1's independently measured complete bare KccP tensor a
two-cocycle of the actual Spin(10) matter-source Lie algebra? This is the
smallest necessary algebraic test before looking for a source-only finite
primitive; no quantum closure assumption is imposed on the input. Base
b5a27ab9db5802afae8c58eb272d913bceef804f/main31358 tracked blobs.

CMS1 is verified progress; the whole investigation remains incomplete.
This increment does not construct a full counterterm, QAP or anomaly
classification. A nonzero consistency remainder is valid evidence, not a
failed verification, if both independently derived routes agree. It may
require correlated ghost-source terms, evanescent/subtraction contributions
or a different complete quantum identity. It cannot invalidate unrelated
qualified UV or finite calculations by itself.

Frozen inputs: current AGENTS/CHARTER/state113/V520/local/solo/epistemic
policies, CMS1 paired full total tensors and receipt, QSI1 independent Lie
contraction of the bare component and receipt, YCT actual generators and
receipt, CMS1 restricted actual Lie constants, and the provisional matter
action/source contract. Preserve both formal orders g10^3/g10^4, widths,
physical reality, all990 external ghost pairs and all zero coefficients.
No parameter is fitted or assigned to make a remainder vanish.

Types: Hermitian generators [T_a,T_b]=i f_ab^e T_e on the actual16 carrier;
End(16)-valued source cochains. Write R_cd=i sum_e r_cd^e T_e only after
checking the complete actual tensor lies in that subspace. Acting on an
endomorphism, rho_a X=-i[T_a,X]. The classical source map is the standard
Chevalley-Eilenberg differential with ghost dc^e=-sum_a<b f_ab^e c^a c^b.
Overall g10 is suppressed in the test and is restored by multiplication,
never inverse-g. This is the highest Kc^3P component of the minimal
cotangent source operation; lower-source descendants and ghost-source
counterterms are not certified complete here.

Primary: extract every color coefficient by direct trace projection of
CMS1 primary's full16x16 matrices. Verify reconstruction/orthogonality;
derive only the Lie constants actually entering this calculation from the
matrix commutators. Compute dR with a ghost exterior differential and the
adjoint module action. Replay: independently assemble Lie-valued R from
QSI1's scalar-Lie quartic result and CMS1's two oriented scalar-Lie cycle
results, then evaluate the explicit six-term three-index CE formula using
authenticated actual f. Compare full two-cochain reconstruction and every
three-cochain coefficient, including zeros. No primary/replay cross-read.

Controls: omit the module action, omit the ghost-bracket action, reverse
the bracket-part sign, omit the bare quartic input or one mixed orientation.
Report which controls are actually sensitive. Test d^2 on a concrete
nontrivial one-cochain, not only on a cocycle or zero input. If the measured
R is not closed, preserve its exact remainder rather than correcting it.
No source-only primitive can have a nonzero dR since d^2=0; this limited
statement does not exclude a full correlated source construction.

Freeze eight sources/copies plus immutable input hashes before workers.
Sequential600s after imports each,8GiB sampled private cap,350MiB launch
floor,16MiB package. Reuse this logical turn's IBS1 readiness; no expensive
qualified science is repeated. Stop at the first failed computation/gate
or exhaustion; preserve captures and source bytes and version corrections.
No agents, branch/worktree, reset, push, publication or external action.
Scientific authority34/39 unchanged; E5/A5 unqualified. Flavor paused,
HB1/C5 blocked, both distinct adverse scalar benchmarks, quartetFAIL and
historical custody2/seven NOTPASS remain. Shared action/software/AI author
limit independence. Literature comparator: previously reviewed BMHV source
restoration distinguishes measured breakings from their counterterm images;
the nonlinear source answer is not imported from a linear-gauge formula.
