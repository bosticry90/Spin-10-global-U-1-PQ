"""MSC1 full cochain-domain comparison; either consistency outcome is valid."""
from data import *
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def rows(rr,n):
 out={}
 for row in rr:
  key=tuple(row[:n]);assert len(row)==n+1 and key not in out
  out[key]=s.sympify(row[n],locals={'eta_H':WH,'xi':WM})
  assert out[key]!=0 and all(0<=v<45 for v in key)
 return out
def same(a,b):
 assert set(a)==set(b)
 for key in a:assert s.expand(a[key]-b[key])==0
same(rows(P['f'],3),rows(R['f'],3));assert len(P['f'])==720
same(rows(P['exact_example_dX'],3),rows(R['exact_example_dX'],3));assert P['exact_example_dX'] and P['exact_example_ddX']==R['exact_example_ddX']==[]
assert P['source_matrix_reconstruction_remainder']=='0' and P['all_r_coefficients_real']
for obj in [P,R]:
 assert obj['pair_count']==990 and obj['triple_count']==14190 and obj['scalar_component_count_per_order']==638550
 assert obj['coupling_orders']==[3,4] and not obj['source_or_physical_scheme_changed'] and not obj['full_quantum_consistency_claimed']
counts={};controls={};dispositions={}
for power in ['3','4']:
 for key,n in [('r',3),('dR',4),('module_part',4),('ghost_part',4)]:
  a,b=rows(P[key][power],n),rows(R[key][power],n);same(a,b)
  for idx in a:assert idx[0]<idx[1] and (n==3 or idx[1]<idx[2])
 d,m,g=[rows(P[key][power],4) for key in ['dR','module_part','ghost_part']]
 for key in set(d)|set(m)|set(g):assert s.expand(d.get(key,0)-m.get(key,0)-g.get(key,0))==0
 counts[power]={'two_cochain_color_positions':len(P['r'][power]),'three_cochain_nonzero_positions':len(d),'source_matrix_nonzero_positions':P['nonzero_source_matrix_positions'][power]}
 dispositions[power]='CLOSED_IN_TESTED_SOURCE_MODULE' if not d else 'NONZERO_CE_REMAINDER_IN_TESTED_SOURCE_MODULE'
 controls[power]={'omit_module_changes':len(m),'omit_ghost_bracket_changes':len(g),'reverse_bracket_part_changes':len(g),'omit_measured_quartic_changes':len(R['bare_quartic_dR'][power])}
 if power=='3':
  for name in ['B_Lambda','Lambda_B']:controls[power]['omit_'+name+'_changes']=len(R['mixed_orientation_dR'][name])
 assert len(m)>0 and len(g)>0
assert counts['3']['source_matrix_nonzero_positions']==8768 and counts['4']['source_matrix_nonzero_positions']==10368
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_SOURCE_CE_CONSISTENCY_TEST','elapsed_after_imports':time.perf_counter()-start,'disposition_by_order':dispositions,'counts':counts,'full_color_three_cochain_positions_compared':1277100,'full_source_matrix_positions_reconstructed':506880,'actual_Lie_constants_compared':720,'nontrivial_exact_example_dd_remainder':'0','projection_reconstruction_remainder':'0','controls':controls,'not_an_anomaly_or_full_counterterm_verdict':True,'correlated_ghost_source_quantum_completion_unqualified':True,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
