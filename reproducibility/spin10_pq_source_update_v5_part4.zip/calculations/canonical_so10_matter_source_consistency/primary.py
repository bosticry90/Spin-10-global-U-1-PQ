"""MSC1 full matrix projection, commutator-derived f and exterior differential."""
from data import *
from collections import defaultdict
from itertools import combinations
start=begin('primary')
T=list(map(dec,packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['Tminus']))
def clean(tab):return {key:s.expand(co) for key,co in tab.items() if s.expand(co)!=0}
def z(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
for a in range(45):
 for b in range(45):assert s.simplify(s.trace(T[a]*T[b]))==2*int(a==b)
basis=defaultdict(list)
for e,M in enumerate(T):
 for (i,j),co in M.todok().items():basis[j,i].append((e,co/(2*s.I)))
def project(M):
 out=defaultdict(lambda:s.S.Zero)
 for pos,co in M.todok().items():
  for e,u in basis[pos]:out[e]+=u*co
 out=clean(out);z(M-s.I*sum((co*T[e] for e,co in out.items()),s.zeros(16)))
 return out
f={}
for a,b in combinations(range(45),2):
 for e,co in project(T[a]*T[b]-T[b]*T[a]).items():f[a,b,e]=co;f[b,a,e]=-co
by_module=defaultdict(list);by_ghost=defaultdict(list)
for (a,b,e),co in f.items():
 by_module[b].append((a,e,co))
 if a<b:by_ghost[e].append((a,b,co))
def canon(ww):
 if len(set(ww))!=len(ww):return None,0
 return tuple(sorted(ww)),(-1)**sum(ww[i]>ww[j] for i in range(len(ww)) for j in range(i+1,len(ww)))
def differential(R):
 module=defaultdict(lambda:s.S.Zero);ghost=defaultdict(lambda:s.S.Zero)
 for (b,c,u),co in R.items():
  for a,e,v in by_module[u]:
   key,sign=canon([a,b,c])
   if sign:module[key+(e,)]+=sign*v*co
  for a,d,v in by_ghost[b]:
   key,sign=canon([a,d,c])
   if sign:ghost[key+(u,)]-=sign*v*co
  for a,d,v in by_ghost[c]:
   key,sign=canon([b,a,d])
   if sign:ghost[key+(u,)]+=sign*v*co
 m,g=clean(module),clean(ghost);total=defaultdict(lambda:s.S.Zero)
 for tab in [m,g]:
  for key,co in tab.items():total[key]+=co
 return clean(total),m,g
CMS=packed(CAL/'canonical_so10_complete_matter_source_breaking/primary_tables.json.gz');r={};out={};mod={};gh={};mat_counts={}
for power in ['3','4']:
 tab={};mat_counts[power]=0
 for (b,c),raw in zip(CMS['external_pairs'],CMS['total_left'][power]):
  M=dec(raw);mat_counts[power]+=len(M.todok())
  for e,co in project(M).items():
   assert s.simplify(co-s.conjugate(co))==0
   tab[b,c,e]=co
 r[power]=tab;out[power],mod[power],gh[power]=differential(tab)
# Nontrivial exact example X_a=i(a+1)T_a; dX !=0 and d(dX)=0.
exact={(a,b,e):s.expand((a+b-e+1)*co) for (a,b,e),co in f.items() if a<b};exact=clean(exact);dd,_,_=differential(exact);assert exact and not dd
def rows(tab):return [[*key,str(co)] for key,co in sorted(tab.items())]
finish('primary',{'method':'complete_matrix_trace_projection_actual_commutators_and_graded_exterior_derivative','f':rows(f),'r':{p:rows(t) for p,t in r.items()},'dR':{p:rows(t) for p,t in out.items()},'module_part':{p:rows(t) for p,t in mod.items()},'ghost_part':{p:rows(t) for p,t in gh.items()},'nonzero_source_matrix_positions':mat_counts,'exact_example_dX':rows(exact),'exact_example_ddX':rows(dd),'pair_count':990,'triple_count':14190,'scalar_component_count_per_order':638550,'source_matrix_reconstruction_remainder':'0','all_r_coefficients_real':True,'coupling_orders':[3,4],'source_or_physical_scheme_changed':False,'full_quantum_consistency_claimed':False},start)
