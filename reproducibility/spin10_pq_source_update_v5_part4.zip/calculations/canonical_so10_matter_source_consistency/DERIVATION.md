# MSC1: fixed source-cochain differential

For Hermitian T, [T_a,T_b]=i f_ab^e T_e, the real Lie-module action is
rho_a X=-i[T_a,X]. It obeys [rho_a,rho_b]=f_ab^e rho_e. The source pairing
K P uses the inverse cotangent action, so acting on K R(c) P combines into
this commutator, not two copies of a left action. A degree-zero source
counterterm K c^a X_a P has highest source image g10 dX. Here

 (dX)_ab=rho_a X_b-rho_b X_a-f_ab^u X_u.

For the measured two-cochain R, the next consistency coefficient is

 (dR)_abc=rho_a R_bc-rho_b R_ac+rho_c R_ab
            -f_ab^u R_uc+f_ac^u R_ub-f_bc^u R_ua.

No factorial is hidden: R=sum_c<d R_cd c^c c^d and dR uses a<b<c.
When R_cd=i r_cd^u T_u, rho_a R_cd=i f_au^e r_cd^u T_e. Reality of r and
the matrix reconstruction are tested, not presumed from the input label.

Primary writes dR as rho_a R c^a plus the graded ghost differential
d(c^b c^c)=(dc^b)c^c-c^b dc^c. Replay evaluates the six displayed terms
directly using antisymmetric pair lookup. They compare all
C(45,3)*45=638550 scalar-Lie positions at each coupling order, as well as
the entire990*256 source matrix positions at each order. These are finite
exact algebraic domains, not truncations or numerical samples.

The scalar-Lie projection uses tr(T_a T_b)=2delta_ab, which is verified from
the actual generator entries. Then r_cd^e=tr(T_e R_cd)/(2i), and every
matrix must reconstruct. The primitive example X_a=i u_a T_a with distinct
real u_a gives a nonzero dX and an exactly zero d(dX); it calibrates the
relative signs independently of the measured R.

This test intentionally does not assume a full quantum Wess-Zumino
condition for the isolated bare insertion. A nonzero result narrows what
source-only normalization can do. It does not establish an anomaly, a
missing physical particle or an incompatible full renormalization family.
In particular, correlated ghost-antifield terms can have Kc^2P images and
additional descendants; those obligations must be examined separately.
