# OGC1 correction V2: measure omission-control differences

Original primary/replay/verifier all native0; their exact chiral/freeword/color
identities agree. Manual report review identified two metadata labels in the
original receipt that used complete identity inventory sizes rather than an
actual one-term omission difference:24for the Alt4 commutator-pair label and2
for the trace4 half-term label. Those two labeled counts are not accepted as
measured sensitivity. Preserve the original sources/receipt/artifact unchanged.

Freeze this record, controlworker/controller and completed inputs before one
bounded explicit mutation check. Compute each of the three Alt4 pair omissions
and each of the two trace4half-term omissions with exact freeword subtraction,
plus their independent finite-matrix values and the wrong reversal-sign control.
No physical input, identity requirement, modeltrace, resource ceiling or authority
changes.600s-afterimports/8GiBsampled/350MiBlaunch/16MiBpacket. Do not rerun old
scientific workers. New control receipt supersedes only those semantic labels;
core proof remains authenticated by the original receipt and paired outputs.
A failed mutation check remains failed, never relabelled PASS. This correction
is delegated verification/reporting repair, not a new scientific acceptance.
