from data import *
from itertools import product,permutations
start=begin('primary');PL=s.diag(1,0);PR=s.diag(0,1);flip=s.Matrix([[0,1],[1,0]]);chi=s.diag(1,-1)
paths={};wrongpaths={}
def path(n,labs,kind,wrong=False):
 seq=[]
 for j in range(n):
  A=PL if labs[j+1]==0 else -PR
  seq.extend([flip,A,flip] if kind=='PS' else [flip,flip,A])
 ghost=(PR if labs[0]==0 else -PL) if kind=='PS' and not wrong else (PL if labs[0]==0 else -PR)
 seq.append(ghost);return s.simplify(s.trace(s.prod(seq)*chi)/2)
for n in [2,3,4]:
 for kind in ['PS','SP','HEAT']:
  vals={};bad={}
  for labs in product(range(2),repeat=n+1):
   label=''.join(map(str,labs));vals[label]=str(path(n,labs,kind));bad[label]=str(path(n,labs,kind,True))
  paths[str(n)+'_'+kind]=vals;wrongpaths[str(n)+'_'+kind]=bad
# Exact free noncommuting word arithmetic, no model tensor assumptions.
def plus(*polys):
 out={}
 for p in polys:
  for w,v in p.items():out[w]=out.get(w,0)+v
 return {w:s.simplify(v) for w,v in out.items() if s.simplify(v)!=0}
def scale(p,c):return {w:v*c for w,v in p.items()}
def mul(a,b):return plus(*[{x+y:v*z} for x,v in a.items() for y,z in b.items()])
def com(a,b):return plus(mul(a,b),scale(mul(b,a),-1))
def anti(a,b):return plus(mul(a,b),mul(b,a))
def trace(p):
 out={}
 for w,v in p.items():
  k=min(w[j:]+w[:j] for j in range(len(w)));out[k]=out.get(k,0)+v
 return plus(out)
A,B,C,D,E=[{(j,):s.S.One} for j in range(5)]
lhs4=trace({(0,1,2,3):1,(0,3,2,1):-1})
rhs4=trace(scale(plus(mul(anti(A,B),com(C,D)),mul(com(A,B),anti(C,D))),s.Rational(1,2)));assert plus(lhs4,scale(rhs4,-1))=={}
perms=list(permutations(range(1,5)))
sign=lambda w:(-1)**sum(w[i]>w[j] for i in range(len(w)) for j in range(i+1,len(w)))
alt={w:s.Integer(sign(w)) for w in perms}
rhs=plus(anti(com(B,C),com(D,E)),scale(anti(com(B,D),com(C,E)),-1),anti(com(B,E),com(C,D)))
assert plus(alt,scale(rhs,-1))=={}
alttrace=trace(mul(A,alt));reverse=trace({(0,)+w[::-1]:s.Integer(sign(w)) for w in perms});assert plus(alttrace,scale(reverse,-1))=={}
# Nonzero anomalous SU3 controls, never the project's physical group.
e=lambda i,j:s.SparseMatrix(3,3,{(i,j):1})
T1=(e(0,1)+e(1,0))/2;T2=(-s.I*e(0,1)+s.I*e(1,0))/2;T3=s.diag(1,-1,0)/2;T4=(e(0,2)+e(2,0))/2;T5=(-s.I*e(0,2)+s.I*e(2,0))/2;T8=s.diag(1,1,-2)/(2*s.sqrt(3))
four=s.simplify(s.trace(T8*T1*T2*T3-T8*T3*T2*T1));fourrhs=s.simplify(s.trace((T8*T1+T1*T8)*(T2*T3-T3*T2)+(T8*T1-T1*T8)*(T2*T3+T3*T2))/2);assert four==fourrhs and four!=0
mats={1:T1,2:T2,3:T4,4:T5};five=s.simplify(sum(sign(w)*s.trace(T8*s.prod(mats[j] for j in w)) for w in perms));assert five!=0
finish('primary',{'chiral_paths':paths,'wrong_At_paths':wrongpaths,'trace4_reversal_identity':{','.join(map(str,k)):str(v) for k,v in sorted(lhs4.items())},'Alt4_coefficients':{','.join(map(str,k)):str(v) for k,v in sorted(alt.items())},'trace5_Alt4_coefficients':{','.join(map(str,k)):str(v) for k,v in sorted(alttrace.items())},'trace4_identity_difference_nonzero_words':0,'Alt4_identity_difference_nonzero_words':0,'reversed_Alt4_same_sign':True,'nonzero_anomalous_trace4_control':str(four),'nonzero_anomalous_Alt4_trace5_control':str(five),'normalized_Alt4_used':False,'chirality_fixture_dimension':2,'chirality_fixture_is_Clifford_or_particle_model':False},start)
