# OGC1: complete selected local odd closed-fermion gauge-insertion coverage

Question: do actual SMA chiral paths and generic color identities reduce every
remaining local parity-odd one-variation closed-fermion gauge contribution to
the already qualified cubic tensor, completing OGT1's selected triangle scope?
Base1260472a16fddacbd3c14c4b630e5334f9322f3a/main33201oldblobs. Previousbounded
resultPROGRESS OGT actualIhat/heat match, no failure. WholegoalACTIVE/incomplete,
state113/34of39. No new model anomaly traces or large loop expansions.

Freeze actual SMA qP/At,qS0, P/S hatmix, physical trace4 and Gaussianhalf,
CSW actual ordered one-variation source/Gaussian identity and scoped joint
Schwartz domain, OGT actualphysicalepsilon triangle coefficient, MAR full
Spin10d_abc0/candidate identification and nonzero fifth Cartan moment. Current
proof is componentwise parity-odd local one-loop insertion, not an absolute
Pfaffian phase. Restrict physical external hats0, nonexceptional Euclidean
momenta, polynomial local ring, source-free bosonic external fields and one
Spin10 gauge ghost (ghostdim1). No externalPQ ghost. Leadingmass-independent
Cartesian M insertions, no inverse mass/coupling, no numerical flavor point,
finite baseline, physical mass, scheme or benchmark selected.

Use the actual operator projectors P_s gamma_bar=gamma_bar P_(1-s),
P_s gamma_hat=gamma_hat P_s. Gauge and PPbarprop pairs preserve chirality,
so only all-T or all-minus-transpose charge paths survive. Prove this for both
Ihat mixed orientations and heatword. Their physical odd color combination is
Tr(Ta Tb...Tn)+(-1)^nTr(Ta Tn...Tb). Primary exact2stateprojector products check
all n=2,3,4 charge-label words and twoorientations, with the operator lemma
proving factorization independently of Lorentz coefficients. These2state
matrices test chirality flow only, not Lorentz/Clifford traces or particles.
Replay independent boolean chiral-state walk checks every allowed/zero path.
OGT's full16spinor cGG result calibrates the actual physicalodd convention.

n3: prove trace(ABCD-ADCB)=1/2 trace({A,B}[C,D]+[A,B]{C,D}), hence
(i/2)(f_cd^e d_abe+f_ab^e d_cde). This is exact for arbitrary matrices with
cyclic finite-color trace. Therefore every odd four-charge word vanishes for
actualSpin10 before its scalar integral. n4local UVdegree0: Lorentz covariance
allows only epsilon_mu nu rho sigma. Complete Bose sum enforces Alt4 on four
external gauge matrices. Prove unnormalized24term Alt4(B,C,D,E)=
{[B,C],[D,E]}-{[B,D],[C,E]}+{[B,E],[C,D]}; its trace withTa reduces f*f*d.
The reversed color partner doubles this Alt4, not an arbitrary Tr5. Do not
assume all fifth-order traces vanish; preserve MAR's nonzero fifthmoment60.

Primary generic free-word polynomial/cyclic identities and explicit Hermitian
SU3 fundamental matrix controls; replay independent telescoping commutator
trace proof, permutation-pair grouping and independently constructed matrices.
Use nonzero reversed4trace and Alt4Tr5 controls. Also apply the actual inherited
commuting Cartan fifthmoment: raw fiveword can be nonzero while Alt4 iszero.
This tests the necessity of Bose antisymmetry without a new Spin10 trace run.
No unknown local breaking coefficient is fitted to make an identity vanish.

Complete coverage uses actual primitive one-loop power counting: for nVvectors
and nMscalar insertions, derivative degree4-nV-nM. Physicalodd closed traces
require four barred epsilon slots; nV+derivatives<=4-nM excludes all nM>=1.
For nV0/1 the only momenta are zero/one independent vector and odd tensors
vanish. nV2 covered by actualOGT; nV3 by reversal*d; nV4 local part by Alt4*d.
nV>=5 are UVconvergent at nonexceptional transfers; explicit h factor in Ihat
and dominated positiveheat(1-E)->0 remove them from the local variation. These
are polynomial/local firstvariation statements, not absence of a gauge-invariant
nonlocal phase or massive/nonpolynomial CP effects. Bound the subtracted n3/n4
remainders through existing nonexceptional one-loop convergence construction,
using positive auxiliaryIRmass only on UV Taylor denominators. No scaleless
integral, IRdelta or exceptional limit is discarded. No nonchiralStokes theorem.

Controls wrong At ghost projector, omit conjugate path, swap odd reversal sign,
unsymmetrizedfour-gaugecolor, dropcommutator terms, erase nonzerofifthmoment,
and broaden mass/nonlocal/global domain. Report exact sensitivity/insensitivity.
Freeze8sources/copies/inputs before sequential P/R/V600s-afterimports each,
8GiBsampled/350MiBlaunch/16MiBpacket. Reuse authenticated currentturnOGT E4
root0steps0/0/0/0/0/2,custody2sevenNOTPASS. Preserve failures/nativecaptures,
versionrepairs. Validate before/index/afterlocalcommit preserving33201oldblobs.

Ceiling: complete selected polynomial local parity-odd bosonic one-variation
fermion gauge-insertion/heat-response sector in the explicit formal Euclidean
reference family. Not full chiral source/contact/QAP/measure/global phase,
Lorentzian/causal/constant-vacuum/massive/nonlocal construction, fullE5/A5 or GUT.
Inheritedanomaly proofs authenticated, no16215rerun. Shared action/analyticdomain,
software/freewordconventions/AIauthor limit independence. State/main, scalar
failures,quartetFAIL,flavorpause,HB1/C5,finitefreedoms/history unchanged. No agents,
branch/worktree/push/outreach/publication or foundational/scheme adoption.
