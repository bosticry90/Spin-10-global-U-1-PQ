# OGC1: selected local odd bosonic fermion gauge variation vanishes completely

Qualified complete selected polynomial local parity-odd closed-fermion bosonic
one-variation sector at physical external hats0 and nonexceptional Euclidean
momenta. Core receiptSHA2563adbe1600754c9b11230e24fe25d4402dfeb696e4663fd212e89a22d1f525ff1
must be read together with the corrected omission-control receiptSHA256
92e87d7988fa5f78b18f8d6a6344b8884c1e70a956b46b636e91b40c4ab35b13.
The original receipt's two omission-count labels are superseded as explained
below; its paired core identities are unchanged. Scientific acceptance
NOT_PERFORMED; state113 and authority34of39 unchanged.

## The complete local scope is reduced to the cubic tensor

OGT1 already measured the actual cGG Ihat and positive-heat response, obtaining
a nonzero universal epsilon coefficient1/3 times d_abc=TrTa{Tb,Tc}. Here the
higher gauge contributions are resolved structurally, without another model
trace run or an unnecessary large integral calculation.

The actual projector algebra permits only all-T or all-minus-transpose paths.
There are168declared chirality-path positions for nV2,3,4 and the PS/SP/heat
orientations:18active and150zero, with exact agreement of direct projector
multiplication and an independent boolean state walk. These2state fixtures
encode chiral selection only; they are not Clifford representations or physical
particles. The general operator proof uses the actual barred anticommutation,
hatted commutation and At ghost projector. The conjugate odd path differs by
(-1)^nV, so each physical odd color factor is

    Tr(Ta Tb...Tn)+(-1)^nV Tr(Ta Tn...Tb).

For three vectors this is the reversed four-word difference. Exact generic
finite-color trace algebra proves

    Tr(ABCD-ADCB)=1/2 Tr({A,B}[C,D]+[A,B]{C,D})
      =(i/2)(f_cd^e d_abe+f_ab^e d_cde).

Thus every actual odd nV3word vanishes for Spin10 before its scalar integration.
No cancellation of an unknown Lorentz coefficient is assumed.

For four vectors, the local Taylor degree iszero and the only available
physical odd Lorentz tensor is epsilon_mu_nu_rho_sigma. Complete Bose summation
therefore antisymmetrizes the four gauge matrices. The exact unnormalized
24word identity is

    Alt4(B,C,D,E)={ [B,C],[D,E] }
                -{ [B,D],[C,E] }+{ [B,E],[C,D] }.

Its trace with Ta is a linear combination of f*f*d. The reversed Nambu color
partner has the same Alt4 sign, giving twice this expression. Qualified
Spin10d0 therefore removes the complete local nV4odd contribution as well.
This is an antisymmetrized five-word result, not a claim that every Tr5 iszero.

The full finite local power-counting inventory contains15(nV,nM)classes with
nV+nM<=4. Ten scalar-bearing classes lack four free barred epsilon slots:
maximum slots nV+derivatives=4-nM. nV0/1have zero or one independent momentum
and their odd tensors vanish. nV2is the actual OGT computation; nV3/4are the
proved reductions above. All larger vertex numbers have negative local degree.
Their primitive nonexceptional subtracted kernels are UV/IR convergent; the
explicit evanescent factor or dominated positive-heat(1-E) factor removes them
from this local variation. A positive auxiliary mass is used only for UV Taylor
completions, never as a physical spectrum or scaleless-IR deletion.

Consequently the actual selected local odd Ihat/ordered-heat gauge variation
vanishes for the declared Spin10 matter. The original16215symmetric cubic slots
and candidate-carrier identification are authenticated inherited evidence,
not recomputed traces. This complements the measured parity-even relative
functional but does not by itself construct its restoring counterterm.

## Nonzero controls and correction history

The anomalous SU3 fundamental control gives a nonzero reversed4trace
sqrt3*i/12 and a nonzero Alt4Tr5 of -sqrt3/8. The actual inherited Spin10
Cartan fifthmoment60 is preserved: the raw reversed-sum five-word coefficient
can be120, while its complete Alt4 iszero. Bose antisymmetry is essential.
The wrong At projector changes12path positions; omission of one conjugate
path affects9active rows. These tests do not use the modelzero as validation.

Manual source/report review caught two metadata errors in the original core
receipt:24was the complete Alt4 identity inventory, and2the complete reversed
trace inventory. They were incorrectly labeled as one-term omission changes.
Those two original labels are not accepted as measured controls. V2 records
the correction and defines explicit word-subtraction tests; all originals
remain unchanged.

The V2 correction launcher then returned native1 before any scientific worker:
a copied source filename was wrong. Its source, partial copies and complete
traceback/native-exit observation are preserved. No V2controlworker or receipt
exists. V3 corrects only launch/source/output names and the worker's manifest
binding, retaining identical mathematical checks and resource requirements.

The actual V3 omissions measure4changed free words for either trace4half-term
and8for each of the three Alt4pairs. Direct matrix changes for the Alt4terms
are -sqrt3/12,-sqrt3/48,-sqrt3/48. The trace4control changes are sqrt3*i/12
and0: the second term is explicitly insensitive in that particular commuting
matrix subspace even though its generic freeword omission changes4words.
Wrong reversal sign changes the anomalous control from sqrt3*i/12 to0.
These are measured sensitivities, not identity inventory sizes.

## Evidence, significance and limits

Core artifact packed/rawSHA256:
984e0c8178f759566d53ca5b5677ee1b4663e180a7e49d0fc3dc1e150034b78c /
acafc1b2131782e8348f4a74ef726cd011eef7bedbac72511c8e86c86975c7b1.
P/R/V native0 in0.433717/0.264536/0.491569s afterimports; V3control0.310779s.
Each has one early private-memory sample929792/401408/393216/2670592B,
not a peak measurement.14sourcecopies,69/77/95bindings,pre-report147900B;
600s/8GiBsampled/350MiBlaunch/16MiB bounds respected. One semantic metadata
error and one preserved prelaunchfailure; no core scientific identity failed.
The original/failed versions are not retroactively relabeled as fully corrected
qualification. Current-turn OGTfreshE4 is authenticated reuse,root0steps
0/0/0/0/0/2,custodyexit2sevenNOTPASS. External before/index/afterseals must
preserve33201oldblobs and exact appended proof/correction/failure bytes.

This is a structural coverage proof with exact algebra checks and a matched
actual regulated triangle, not an external or proof-kernel theorem. Shared
SMA/Clifford/analytic-domain assumptions, modeldata, software and AIauthor
remain common error sources. The reporting and launch mistakes are evidence
of workflow limitations despite the corrected core result.

Next: assess a complete finite normalization for the closed bosonic matter
sector from the newly measured rawDIM-minus-heat functional and the older
measured DIM-minus-covariant-comparator BWF/GWF functional. Their difference
is an explicit candidate; its quantum reference covariance, boundary currents,
power-contact subtraction and admissible normalization family must be justified,
not inferred from this oddzero. Reuse the actual coupled finite/source parents
before making any full Slavnov claim. No new coefficients should be chosen to
force cancellation. The reference is parity-even and provisional, not a new
physical scheme or a discarded Gamma_ref[A_H].

Global/gauge-invariant nonlocal Pfaffian phase, renormalized source/contact
products, multiple insertions/QAP/measure, external backgrounds, massive and
physical Lorentzian/causal/constant-vacuum domains remain unqualified. Neither
this sector proof nor the parity-even comparison completes E5/A5 or establishes
physical GUT viability. All scalarfailures,quartetFAIL,flavorpause,HB1/C5blocks,
independent finite freedoms,state/history persist. No agents,branch/worktree,
push,outreach,publication,scheme or foundational adoption. Wholegoal ACTIVE.
