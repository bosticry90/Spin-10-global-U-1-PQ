from data import *
from itertools import product,permutations
start=begin('replay');paths={};badpaths={}
def flow(n,labs,kind,wrong=False):
 # Operators are applied right toleft; initial chirality0=L(+),1=R(-).
 seq=[]
 for j in range(n):seq.extend(['bar',('P',labs[j+1]),'bar'] if kind=='PS' else ['bar','bar',('P',labs[j+1])])
 seq.append(('At' if kind=='PS' and not wrong else 'P',labs[0]));out=0
 for initial in [0,1]:
  state=initial;coefficient=1
  for node in reversed(seq):
   if node=='bar':state=1-state;continue
   tag,lab=node;wanted=1-lab if tag=='At' else lab
   if state!=wanted:coefficient=0;break
   if lab==1:coefficient=-coefficient
  if state==initial:out+=coefficient*s.Rational(1 if initial==0 else -1,2)
 return s.Rational(out)
for n in [2,3,4]:
 for kind in ['PS','SP','HEAT']:
  paths[f'{n}_{kind}']={''.join(map(str,l)):str(flow(n,l,kind)) for l in product(range(2),repeat=n+1)}
  badpaths[f'{n}_{kind}']={''.join(map(str,l)):str(flow(n,l,kind,True)) for l in product(range(2),repeat=n+1)}
# Trace telescoping and cancellation of the commutator-commutator pair.
def canon(w):return min(w[j:]+w[:j] for j in range(len(w)))
def polynomial(terms,cyclic=False):
 d={}
 for w,v in terms:
  if cyclic:w=canon(w)
  d[w]=d.get(w,0)+v
 return {w:s.simplify(v) for w,v in d.items() if s.simplify(v)!=0}
def concatenate(a,b):return [(wa+wb,va*vb) for wa,va in a for wb,vb in b]
def comm(a,b):return [(a,b),1],[(b,a),-1]
# First telescope [A,B]CD+BA[C,D], then split symmetric/antisymmetric halves.
first=polynomial([((0,1,2,3),1),((1,0,2,3),-1),((1,0,2,3),1),((1,0,3,2),-1)],True)
expanded=[]
for ab,sgn1 in [((0,1),1),((1,0),-1)]:
 for cd in [(2,3),(3,2)]:expanded.append((ab+cd,s.Rational(sgn1,2)))
for ab in [(0,1),(1,0)]:
 for cd,sgn2 in [((2,3),1),((3,2),-1)]:expanded.append((ab+cd,s.Rational(sgn2,2)))
second=polynomial(expanded,True);assert first==second
# Pair each permutation by its first ordered2subset and remaining2subset.
perms=list(permutations(range(1,5)));sgn=lambda w:s.Integer((-1)**sum(w[a]>w[b] for a in range(4) for b in range(a+1,4)))
alt=polynomial([(w,sgn(w)) for w in perms]);grouped=[]
for (a,b),(c,d),outer in [((1,2),(3,4),1),((1,3),(2,4),-1),((1,4),(2,3),1)]:
 for aa,sa in [((a,b),1),((b,a),-1)]:
  for cc,sc in [((c,d),1),((d,c),-1)]:grouped.extend([(aa+cc,outer*sa*sc),(cc+aa,outer*sa*sc)])
assert polynomial(grouped)==alt
tracealt=polynomial([((0,)+w,v) for w,v in alt.items()],True)
# Independently written control matrices and commutator-pair result.
T1=s.Matrix([[0,1,0],[1,0,0],[0,0,0]])/2;T2=s.Matrix([[0,-s.I,0],[s.I,0,0],[0,0,0]])/2;T3=s.diag(1,-1,0)/2;T4=s.Matrix([[0,0,1],[0,0,0],[1,0,0]])/2;T5=s.Matrix([[0,0,-s.I],[0,0,0],[s.I,0,0]])/2;T8=s.diag(1,1,-2)/(2*s.sqrt(3))
cm=lambda a,b:a*b-b*a;am=lambda a,b:a*b+b*a
four=s.simplify(s.trace(am(T8,T1)*cm(T2,T3)+cm(T8,T1)*am(T2,T3))/2)
five=s.simplify(s.trace(T8*(am(cm(T1,T2),cm(T4,T5))-am(cm(T1,T4),cm(T2,T5))+am(cm(T1,T5),cm(T2,T4)))))
finish('replay',{'chiral_paths':paths,'wrong_At_paths':badpaths,'trace4_reversal_identity':{','.join(map(str,k)):str(v) for k,v in sorted(first.items())},'Alt4_coefficients':{','.join(map(str,k)):str(v) for k,v in sorted(alt.items())},'trace5_Alt4_coefficients':{','.join(map(str,k)):str(v) for k,v in sorted(tracealt.items())},'trace4_identity_difference_nonzero_words':0,'Alt4_identity_difference_nonzero_words':0,'reversed_Alt4_same_sign':True,'nonzero_anomalous_trace4_control':str(four),'nonzero_anomalous_Alt4_trace5_control':str(five),'normalized_Alt4_used':False,'chirality_fixture_is_Clifford_or_particle_model':False},start)
