# OGC1 control launch correction V3

V2 launcher native1 before any controlworker because its source-copy list named
run_check_controls_v2.py, which does not exist. Original V2controller, partial
sourcecopies and complete traceback are preserved. No V2controlmanifest, worker
or receipt was produced. This is prelaunchdependency failure, not a failed
freeword identity. The original OGCscientificworkers remain completed.

V3 changes only the controller source names/output version and the worker's
new input-manifest filename. The actual omission calculations are byte-identical
apart from that manifest binding. Freeze this record,V3worker,V3controller and
the failedV2controller copy before one observed run. Bind all preserved failures
and the external nativeexit1 observation. Same600s/8GiBsampled/350MiB/16MiB.
No scientific requirement, physical input, sourceproof or authority changes.
