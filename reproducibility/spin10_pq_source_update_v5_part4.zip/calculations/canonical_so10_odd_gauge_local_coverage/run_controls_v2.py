from pathlib import Path
from hashlib import sha256
import json,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/odd-gauge-local-coverage-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
 for p,h in bind.items():assert digest(Path(p))==h,p
 for n in ['CORRECTION_V2.md','check_controls_v2.py','run_check_controls_v2.py']:
  p=HERE/n;b=p.read_bytes();assert b'\r' not in b
  if p.suffix=='.py':compile(b,str(p),'exec')
  with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 for p in HERE.iterdir():
  if p.is_file():bind[str(p)]=digest(p)
 dump(HERE/'control_preparation_v2.json',{'input_sha256':bind,'same_original_resource_caps':True,'scientific_acceptance':'NOT_PERFORMED'})
 c=capture([sys.executable,'-B',str(HERE/'check_controls_v2.py')]);dump(HERE/'complete_controls_capture.json',c);dump(CONTROL/'complete_controls_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600 and rows[0]['status']=='QUALIFIED_OGC_CORE_WITH_EXPLICIT_CORRECTED_OMISSION_CONTROLS'
 dump(HERE/'control_receipt_v2.json',rows[0]);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(HERE/'control_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
