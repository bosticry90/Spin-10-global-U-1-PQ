# OGC1 chiral factorization, generic color algebra and local coverage

For any actual ordered closed P loop, adjacent gauge charges are separated by
barSlash*barGamma, so projectors must have the same label. Hatted matrices
commute with chi; in Ihat they occur only in the mixed propagator/current pair.
The ghost At in the PS orientation supplies precisely the swapped projector
required by the final barSlash. The other mixed orientation and heatword use
Aa. Thus two charge paths survive. The conjugate path has n+1 minus signs
and the opposite physical odd trace. Transposing its finite-color product
reverses gauge order with ghostfirst. Ratio=(-1)^(n+1)*(-1)=(-1)^n. This is
an operator proof, not an assumed property of selected fixtures or modelzeros.

For arbitrary even matrices A,B,C,D, cyclic trace telescoping gives
Tr(ABCD-ADCB)=Tr([A,B]CD+BA[C,D]). Split both products into symmetric and
antisymmetric halves. The commutator-commutator terms cancel, yielding
1/2Tr([A,B]{C,D}+{A,B}[C,D]). Insert[Tb,Tc]=i f_bc^e Te and
TrTa{Tb,Tc}=d_abc. No quadratic or fourth invariant remains. This applies
separately to each ordered n3odd numerator, before integration.

Expand all24signed products in Alt4(B,C,D,E) and group into the three unordered
pair partitions. Each group equals an anticommutator of two commutators, with
signs+,-,+. Therefore TrTaAlt4=-d_amn*(f_bc^m f_de^n-f_bd^m f_ce^n+f_be^m f_cd^n).
All antisymmetrizations here are unnormalized sums. With four physical vector
indices and no external derivative, a local odd Lorentz tensor must be epsilon;
Bose symmetrization of the amplitude thus implements Alt4. Reversing the four
external matrices has parity+1, so the n4Nambu sum becomes2TrTaAlt4.

The insertion has ghostnumber1, engineeringdimension5 (ghostdim1). Hence
nV+nM+derivatives<=4. In the physicalodd trace all free barred orientation
slots must come from vectors or derivatives, never scalar indices. All
nM>=1are excluded from this localodd polynomial. Internal angular moments
provide only metric pairings and cannot supply missing free epsilon indices.
This does not constrain nonpolynomial phases such as functions of massive
scalar eigenvalues. At nV1, epsilon contracted with repeated oneexternal
momentum vanishes; nV0has no oriented vector. nV2is the actual OGT integral.

For nV3/4, subtract UV Taylor degree1/0 in a strictly positive auxiliary mass
completion. The resulting UVdegree<=-1 kernels are convergent at fixed
nonexceptional Euclidean transfers; their explicit evanescent factor vanishes.
The auxiliary completion does not replace a physical spectrum or erase an IR
contact. Same convergence and positiveheat bounds handle nV>=5. A single
source/field tangent is within inherited joint Schwartz kernel domain; epsilon
trace coefficients are fixed finite component scalars and do not worsen those
IRbounds. Full cutoffsourceorder is unchanged. No additional multipleinsertions
or finitepart trace cyclicity is assumed. Only finite-color trace is cyclic.

A vanishing complete selected local variation is compatible with nonlocal,
gauge-invariant determinant phase information. The absolute infinite-dimensional
Pfaffian, its global sign and composite-product normalizations remain unconstructed.
