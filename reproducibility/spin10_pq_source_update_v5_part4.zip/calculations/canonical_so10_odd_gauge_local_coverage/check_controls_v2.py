from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'control_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');old=read(HERE/'validation_receipt.json')
def tidy(p):return {w:s.simplify(v) for w,v in p.items() if s.simplify(v)!=0}
def add(a,b):return tidy({w:a.get(w,0)+b.get(w,0) for w in set(a)|set(b)})
def scale(a,z):return tidy({w:v*z for w,v in a.items()})
def mul(a,b):
 out={}
 for w,x in a.items():
  for v,y in b.items():out[w+v]=out.get(w+v,0)+x*y
 return tidy(out)
def com(a,b):return add(mul(a,b),scale(mul(b,a),-1))
def anti(a,b):return add(mul(a,b),mul(b,a))
def tr(p):
 out={}
 for w,v in p.items():
  c=min(w[j:]+w[:j] for j in range(len(w)));out[c]=out.get(c,0)+v
 return tidy(out)
P,Q,R,S,T=[{(j,):s.S.One} for j in range(5)]
terms4=[tr(scale(mul(anti(P,Q),com(R,S)),s.Rational(1,2))),tr(scale(mul(com(P,Q),anti(R,S)),s.Rational(1,2)))]
lhs4={tuple(map(int,w.split(','))):s.sympify(v) for w,v in A['trace4_reversal_identity'].items()}
assert add(add(terms4[0],terms4[1]),scale(lhs4,-1))=={}
changed4=[]
for j in range(2):
 bad=terms4[1-j];delta=add(lhs4,scale(bad,-1));assert delta==terms4[j] and delta;changed4.append(len(delta))
terms5=[anti(com(Q,R),com(S,T)),scale(anti(com(Q,S),com(R,T)),-1),anti(com(Q,T),com(R,S))]
lhs5={tuple(map(int,w.split(','))):s.sympify(v) for w,v in A['Alt4_coefficients'].items()};total={}
for x in terms5:total=add(total,x)
assert total==lhs5;changed5=[]
for j in range(3):
 bad={}
 for k,x in enumerate(terms5):
  if k!=j:bad=add(bad,x)
 delta=add(lhs5,scale(bad,-1));assert delta==terms5[j] and delta;changed5.append(len(delta))
# Direct independent3x3 matrix control checks corresponding altered values.
T1=s.Matrix([[0,1,0],[1,0,0],[0,0,0]])/2;T2=s.Matrix([[0,-s.I,0],[s.I,0,0],[0,0,0]])/2;T3=s.diag(1,-1,0)/2;T4=s.Matrix([[0,0,1],[0,0,0],[1,0,0]])/2;T5=s.Matrix([[0,0,-s.I],[0,0,0],[s.I,0,0]])/2;T8=s.diag(1,1,-2)/(2*s.sqrt(3))
cm=lambda a,b:a*b-b*a;am=lambda a,b:a*b+b*a
matrix4=[s.simplify(s.trace(am(T8,T1)*cm(T2,T3))/2),s.simplify(s.trace(cm(T8,T1)*am(T2,T3))/2)]
matrix5=[s.simplify(s.trace(T8*am(cm(T1,T2),cm(T4,T5)))),s.simplify(-s.trace(T8*am(cm(T1,T4),cm(T2,T5)))),s.simplify(s.trace(T8*am(cm(T1,T5),cm(T2,T4))))]
left=s.trace(T8*T1*T2*T3);right=s.trace(T8*T3*T2*T1);correct=s.simplify(left-right);wrong=s.simplify(left+right);assert correct!=wrong
assert sum(matrix4)==s.sympify(A['nonzero_anomalous_trace4_control']) and s.simplify(sum(matrix5)-s.sympify(A['nonzero_anomalous_Alt4_trace5_control']))==0
out={'status':'QUALIFIED_OGC_CORE_WITH_EXPLICIT_CORRECTED_OMISSION_CONTROLS','elapsed_after_imports':time.perf_counter()-start,'original_receipt_sha256':digest(HERE/'validation_receipt.json'),'original_identity_inventory_counts_preserved_but_not_used_as_omission_counts':{'Alt4':24,'trace4':2},'trace4_half_term_omission_changed_free_words':changed4,'Alt4_single_pair_omission_changed_free_words':changed5,'trace4_half_term_matrix_changes':list(map(str,matrix4)),'Alt4_single_pair_matrix_changes':list(map(str,matrix5)),'wrong_reversal_sign_correct_control':str(correct),'wrong_reversal_sign_altered_control':str(wrong),'zero_matrix_control_subspaces_reported':sum(x==0 for x in matrix4+matrix5),'old_scientific_workers_replayed':False,'core_identities_or_physics_changed':False,'original_metadata_reporting_error_preserved':True,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
