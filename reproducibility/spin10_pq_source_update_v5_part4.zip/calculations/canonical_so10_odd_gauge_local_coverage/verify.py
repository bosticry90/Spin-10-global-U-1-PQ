from data import *
from itertools import product
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
for field in ['chiral_paths','wrong_At_paths','trace4_reversal_identity','Alt4_coefficients','trace5_Alt4_coefficients']:
 assert A[field].keys()==B[field].keys()
 def compare(x,y):
  if isinstance(x,dict):
   assert x.keys()==y.keys()
   for k in x:compare(x[k],y[k])
  else:assert s.simplify(s.sympify(x)-s.sympify(y))==0,(x,y)
 compare(A[field],B[field])
for field in ['nonzero_anomalous_trace4_control','nonzero_anomalous_Alt4_trace5_control']:
 assert s.simplify(s.sympify(A[field])-s.sympify(B[field]))==0 and s.sympify(A[field])!=0
pathpositions=0;active=0;At_changes=0
for n in [2,3,4]:
 for kind in ['PS','SP','HEAT']:
  row=A['chiral_paths'][f'{n}_{kind}'];assert len(row)==2**(n+1);pathpositions+=len(row)
  nonzero={k:s.sympify(v) for k,v in row.items() if s.sympify(v)!=0};assert set(nonzero)=={'0'*(n+1),'1'*(n+1)};active+=len(nonzero)
  assert s.simplify(nonzero['1'*(n+1)]-(-1)**n*nonzero['0'*(n+1)])==0
  At_changes+=sum(s.sympify(v)!=s.sympify(A['wrong_At_paths'][f'{n}_{kind}'][k]) for k,v in row.items())
assert At_changes>0
# Authenticate inherited input scopes; no cubic/fifth model trace is recomputed.
MAR=CAL/'canonical_so10_matter_anomaly_reuse';GA=CAL/'canonical_so10_local_gauge_anomaly';OGT=CAL/'canonical_so10_odd_gauge_triangle_insertion'
assert digest(MAR/'validation_receipt.json')=='fc5eb3c19e01f5b4e0e9eabcba05d26a09da224556132bdcfd0a561d5db71172'
assert digest(GA/'validation_receipt.json')=='cf2cb5b63cc835822f0d143c465ec97123337f9a203c991982bcdee0ee2c4e0b'
assert digest(OGT/'validation_receipt.json')=='97ff54a20cd05e0c0d4a28d47989a5c5d06039236ab76997c8e9a7c415350b3d'
mar=read(MAR/'validation_receipt.json');ga=read(GA/'validation_receipt.json');ogt=read(OGT/'validation_receipt.json')
assert mar['historical_gauge_cubic_and_linear_zero_reusable'] and ga['all_symmetric_cubic_gauge_traces_zero_checked'] and ga['symmetric_cubic_slots_checked']==16215 and ogt['unit_coefficient']=='1/3' and ogt['actual_Spin10_selected_odd_breaking']==0
fifth=s.sympify(mar['carrier_comparisons']['candidate_odd']['fifth_sum_Cartan_moment']);assert fifth!=0
# The inherited commuting generator example retains its NONZERO raw C5.
raw_C5=2*fifth;alt_signsum=sum(s.sympify(v) for v in A['Alt4_coefficients'].values());assert alt_signsum==0 and raw_C5!=0
coverage=[]
for nV in range(5):
 for nM in range(5-nV):
  degree=4-nV-nM;slots=nV+degree
  if nM:reason='NO_FOUR_FREE_BARRED_EPSILON_SLOTS';assert slots<4
  elif nV<2:reason='ZERO_OR_ONE_INDEPENDENT_EXTERNAL_MOMENTUM'
  elif nV==2:reason='ACTUAL_OGT_INSERTION_AND_HEAT_TENSOR_TIMES_d_ZERO'
  elif nV==3:reason='EACH_REVERSED_TRACE4_WORD_REDUCES_f_d_ZERO'
  else:reason='LOCAL_EPSILON_BOSE_Alt4_REDUCES_f_f_d_ZERO'
  coverage.append({'vectors':nV,'scalar_insertions':nM,'maximum_derivative_degree':degree,'maximum_barred_slots':slots,'disposition':reason})
assert len(coverage)==15 and sum(x['scalar_insertions']>0 for x in coverage)==10
controls={'wrong_At_chiral_path_positions':At_changes,'omit_conjugate_path_nonzero_rows':9,'wrong_n3_reversal_sign_anomalous_control':1,'omit_four_vector_Bose_antisymmetry_actual_raw_C5':str(raw_C5),'drop_Alt4_commutator_pair_nonzero_free_words':len(A['Alt4_coefficients']),'drop_trace4_symmetric_commutator_terms_nonzero_words':len(A['trace4_reversal_identity']),'erase_nonzero_historical_fifth_moment':str(fifth)}
artifact={'schema':'OGC1_COMPLETE_SELECTED_LOCAL_ODD_BOSONIC_FERMION_GAUGE_COVERAGE','actual_chiral_reversal_factor':'(-1)^nV','chiral_path_positions':pathpositions,'generic_trace4_identity':A['trace4_reversal_identity'],'generic_Alt4_identity':A['Alt4_coefficients'],'three_vector_color_reduction':'(i/2)*(f_cd^e*d_abe+f_ab^e*d_cde)','four_vector_color_reduction':'-2*d_amn*(f_bc^m*f_de^n-f_bd^m*f_ce^n+f_be^m*f_cd^n)','antisymmetrization':'UNNORMALIZED_24_TERM_SUM','local_coverage':coverage,'higher_n_total_gt4':'NO_POLYNOMIAL_LOCAL_DEGREE;UV_IR_CONVERGENT_EXPLICIT_EVANESCENCE_AND_HEAT_DOMINANCE_IN_FROZEN_DOMAIN','inherited_actual_Spin10_d_tensor':0,'inherited_symmetric_cubic_slots':16215,'actual_selected_local_odd_Ihat_and_heat_variation':0,'OGT_receipt_sha256':digest(OGT/'validation_receipt.json'),'actual_historical_fifth_Cartan_moment_preserved':str(fifth),'new_Spin10_trace_or_loop_integrals':0,'gauge_invariant_nonlocal_or_absolute_phase_proved':False,'full_QAP_measure_products_or_physical_scheme_adopted':False}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'local_odd_coverage_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_COMPLETE_SELECTED_LOCAL_ODD_BOSONIC_FERMION_GAUGE_INSERTION_COVERAGE','elapsed_after_imports':time.perf_counter()-start,'all_chiral_path_positions_compared':pathpositions,'active_chiral_path_positions':active,'zero_chiral_path_positions':pathpositions-active,'free_trace4_words':len(A['trace4_reversal_identity']),'free_Alt4_words':len(A['Alt4_coefficients']),'anomalous_trace4_control':A['nonzero_anomalous_trace4_control'],'anomalous_Alt4_trace5_control':A['nonzero_anomalous_Alt4_trace5_control'],'local_power_counting_classes':15,'scalar_bearing_classes_excluded_by_Lorentz_slots':10,'actual_selected_odd_local_variation':0,'new_Spin10_trace_evaluations':0,'new_loop_integrals':0,'negative_controls':controls,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'global_or_nonlocal_Pfaffian_phase_proved':False,'full_chiral_source_QAP_measure_restoration_proved':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','scientific_authority_changed':False,'authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
