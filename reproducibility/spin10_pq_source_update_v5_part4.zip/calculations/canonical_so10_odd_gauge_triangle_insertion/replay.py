from data import *
from itertools import product,permutations
start=begin('replay')
def eps4(w):
 if len(set(w))<4:return s.S.Zero
 inv=sum(w[i]>w[j] for i in range(4) for j in range(i+1,4));return s.Integer((-1)**inv)
# Physical chi odd trace, with conjugate right word: each contributes halftrace.
c1={};c2={}
for mu,nu,a,b in product(range(4),repeat=4):
 c1[f'{mu}_{nu}_{a}_{b}']=str(-2*eps4((mu,a,nu,b)))
 c2[f'{mu}_{nu}_{a}_{b}']=str(2*eps4((a,mu,b,nu)))
e,m=s.symbols('epsilon Delta',positive=True);D=4-2*e;h=-2*e;proper=s.Symbol('proper',positive=True)
# Hat Gaussian average h/(2proper), propagator denominator power3 suppliesproperÂ²/2.
rad=s.simplify(h*s.gamma(2-D/2)*m**(D/2-2)/4);rad0=s.simplify(s.limit(rad,e,0))
x0,x1,x2=s.symbols('x0 x1 x2',nonnegative=True)
k=s.Matrix([x1+x2,x2]);r=k-s.Matrix([1,0]);ss=k-s.Matrix([1,1]);wedge=lambda a,b:s.expand(a[0]*b[1]-a[1]*b[0])
w1=s.factor(wedge(r,ss));w2=s.factor(wedge(k,r));assert s.simplify(w1+w2-(1-x1))==0
simplex=lambda p:s.integrate(s.integrate(p,(x2,0,1-x1)),(x1,0,1))
weight1=simplex(w1);weight2=simplex(w2)
# Positive heat via radial integration-by-parts recurrence on ordinary4D measure.
t,ell=s.symbols('t ell',positive=True);heatvec=s.simplify(-2*t*s.integrate(ell/(ell+6*t)**3,(ell,0,s.oo)))
out={};heat={};pieces={}
phase=s.simplify(-s.Rational(1,2)*(-s.I)**5)
for mu,nu,rho,sigma in product(range(4),repeat=4):
 epsilon=eps4((mu,rho,nu,sigma));p1=s.simplify(phase*2*rad0*(-2*epsilon)*weight1/s.I);p2=s.simplify(phase*2*rad0*(-2*epsilon)*weight2/s.I)
 key=f'{mu}_{nu}_{rho}_{sigma}';out[key]=str(p1+p2);pieces[key]=[str(p1),str(p2)]
 # -igÂ³tr(B gammaA B gammaA A)times ordered positive heat. Firstheat term isepsilonzero.
 heat[key]=str(s.simplify((-s.I)*2*epsilon*heatvec/s.I))
# Independent actual finite-color numerical fixture, including right transpose order.
Ta=s.diag(1,0,-1);Tb=s.Matrix([[0,1,0],[1,0,0],[0,0,0]])/2;Tc=s.Matrix([[0,1-s.I,0],[1+s.I,0,0],[0,0,0]])/2
left=s.trace(Tb*Tc*Ta);right=s.trace(Tb.T*Tc.T*Ta.T)
finish('replay',{'dimensional_tensor':out,'positive_heat_tensor':heat,'dimensional_mixed_pieces':pieces,'spin_odd_term1':c1,'spin_odd_term2':c2,'radial_hat_finite':str(rad0),'heat_vector_p2_coefficient':str(heatvec),'simplex_weights':[str(weight1),str(weight2)],'epsilon_orientation':'0123_PLUS','color_fixture_ordered_traces':[str(s.expand(left)),str(s.expand(right))],'color_fixture_symmetric_trace':str(s.simplify(left+right)),'unit_charge_symmetric_trace':2,'physical_spin_trace':4,'Gaussian_factor':'-1/2','ordered_functional_not_twice_differentiated':True},start)
