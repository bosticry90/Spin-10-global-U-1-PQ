from data import *
from itertools import product
start=begin('primary')
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g8=[s.kronecker_product(v,pa[2]) for v in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
gam=[s.kronecker_product(v,s.eye(2)) for v in g8];C=s.kronecker_product(g8[0]*g8[2]*g8[5],pa[1]);chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));I=s.eye(16);Z=s.zeros(16)
PL=(I+chi)/2;PR=(I-chi)/2;H=gam[4];divisor=4
zero(C.T+C);zero(C.inv()*chi.T*C-chi)
assert s.trace(chi*s.prod(gam[:4]))/divisor==4
for i in range(6):zero(gam[i]*chi+chi*gam[i] if i<4 else gam[i]*chi-chi*gam[i])
def blk(a,b,c,d):return s.BlockMatrix([[a,b],[c,d]]).as_explicit()
def dirac(v):
 B=sum((v[j]*gam[j] for j in range(4)),Z);hh=v[4]*gam[4]+v[5]*gam[5]
 return s.I*blk(B,hh,hh,B)
def inverse(v):
 B=sum((v[j]*gam[j] for j in range(4)),Z);hh=v[4]*gam[4]+v[5]*gam[5];Q=sum(z*z for z in v)
 return -s.I*blk(B,hh,hh,B)/Q
k=[2,1,-1,1,1,0];p1=[1,0,1,0,0,0];p2=[0,1,0,1,0,0];r=[a-b for a,b in zip(k,p1)];ss=[a-b-c for a,b,c in zip(k,p1,p2)]
X=blk(s.I*chi,Z,Z,Z);Y=blk(-s.I*chi,Z,Z,Z);q=[a-b for a,b in zip(ss,k)];delta=blk(sum((q[j]*gam[j]*chi for j in range(4)),Z),Z,Z,Z)
E=blk(Z,-chi*H,-H*chi,Z)
zero(delta+dirac(ss)*X-Y*dirac(k)-E);zero(dirac(k)*inverse(k)-s.eye(32))
# New actual full-P/S fixture, not a replay of the old congruence.
fixture={}
for mu,nu in product(range(4),repeat=2):
 vb=blk(-s.I*gam[mu]*chi,Z,Z,Z);vc=blk(-s.I*gam[nu]*chi,Z,Z,Z)
 direct=s.simplify(-s.trace(inverse(k)*vb*inverse(r)*vc*inverse(ss)*E)/(2*divisor))
 Br=sum((r[j]*gam[j] for j in range(4)),Z);Bs=sum((ss[j]*gam[j] for j in range(4)),Z);Bk=sum((k[j]*gam[j] for j in range(4)),Z)
 reduced=s.I*s.trace(gam[mu]*chi*Br*gam[nu]*chi*Bs*(-chi)-Bk*gam[mu]*chi*Br*gam[nu]*chi*chi)/(2*divisor*sum(z*z for z in k)*sum(z*z for z in r)*sum(z*z for z in ss))
 assert s.simplify(direct-reduced)==0;fixture[f'{mu}_{nu}']=str(direct)
# Exact physical-odd traces. Formal left/right finite-color words stay separate.
coef1={};coef2={};wrong={}
for mu,nu,a,b in product(range(4),repeat=4):
 key=f'{mu}_{nu}_{a}_{b}';c1={};c2={}
 for label in [0,1]:
  vals1=[];vals2=[]
  for orientation in [1,-1]:
   P=(I+orientation*chi)/2;R=I-P
   ab=P if label==0 else -R;ac=ab;at=R if label==0 else -P;aa=ab
   vals1.append(s.trace(gam[mu]*ab*gam[a]*gam[nu]*ac*gam[b]*at)/divisor)
   vals2.append(s.trace(gam[a]*gam[mu]*ab*gam[b]*gam[nu]*ac*aa)/divisor)
  c1[str(label)]=s.simplify((vals1[0]-vals1[1])/2);c2[str(label)]=s.simplify((vals2[0]-vals2[1])/2)
 # Transposed-color trace reverses to ghost-first order; label1 includes all signs.
 assert c1['0']==c1['1'] and c2['0']==c2['1']
 coef1[key]=str(c1['0']);coef2[key]=str(c2['0'])
# Gamma radial moment and independent positive-heat moment.
e,Delta=s.symbols('epsilon Delta',positive=True);D=4-2*e;h=-2*e
rad=h/D*s.gamma(D/2+1)*s.gamma(3-D/2-1)/(s.gamma(D/2)*s.gamma(3))*Delta**(D/2-2)
rad0=s.simplify(s.limit(s.gammasimp(rad),e,0))
x,y=s.symbols('x y',nonnegative=True);dimout={};heatout={};pieces={}
t,Q=s.symbols('t Q',positive=True);heatmoment=s.simplify(-4*t*s.integrate(s.exp(-6*t*Q),(Q,0,s.oo))/4)
for mu,nu,rho,sigma in product(range(4),repeat=4):
 km=[(x+y)*int(j==rho)+y*int(j==sigma) for j in range(4)];rm=[v-int(j==rho) for j,v in enumerate(km)];sm=[v-int(j==rho)-int(j==sigma) for j,v in enumerate(km)]
 n1=sum(s.sympify(coef1[f'{mu}_{nu}_{a}_{b}'])*rm[a]*sm[b] for a,b in product(range(4),repeat=2));n2=sum(s.sympify(coef2[f'{mu}_{nu}_{a}_{b}'])*km[a]*rm[b] for a,b in product(range(4),repeat=2))
 v1=s.integrate(s.integrate(s.expand(n1),(y,0,1-x)),(x,0,1));v2=s.integrate(s.integrate(s.expand(n2),(y,0,1-x)),(x,0,1))
 # Actual phases derived from Gaussian, propagator, vertex and insertion factors.
 phase=s.simplify(-s.Rational(1,2)*(-s.I)**3*(-s.I)**2)
 dim=s.simplify(phase*2*rad0*(v1-v2)/s.I)
 heat=s.simplify((-s.I)*s.sympify(coef2[f'{mu}_{nu}_{sigma}_{rho}'])*(-heatmoment)/s.I)
 key=f'{mu}_{nu}_{rho}_{sigma}';dimout[key]=str(dim);heatout[key]=str(heat);pieces[key]=[str(s.simplify(phase*2*rad0*v1/s.I)),str(s.simplify(-phase*2*rad0*v2/s.I))]
Ta=s.diag(1,0,-1);Tb=s.Matrix([[0,1,0],[1,0,0],[0,0,0]])/2;Tc=Tb+s.Matrix([[0,-s.I,0],[s.I,0,0],[0,0,0]])/2
left=s.trace(Ta*Tb*Tc);right=s.trace(Ta*Tc*Tb)
finish('primary',{'dimensional_tensor':dimout,'positive_heat_tensor':heatout,'dimensional_mixed_pieces':pieces,'spin_odd_term1':coef1,'spin_odd_term2':coef2,'radial_hat_finite':str(rad0),'heat_vector_p2_coefficient':str(heatmoment),'full_PS_ghost_identity_positions':1024,'full_PS_free_inverse_positions':1024,'literal_loop_fixture':fixture,'witness_spin_trace':16,'physical_spin_trace':4,'witness_divisor':divisor,'epsilon_orientation':'0123_PLUS','color_fixture_ordered_traces':[str(left),str(right)],'color_fixture_symmetric_trace':str(left+right),'unit_charge_symmetric_trace':2,'Gaussian_factor':'-1/2','ordered_functional_not_twice_differentiated':True},start)
