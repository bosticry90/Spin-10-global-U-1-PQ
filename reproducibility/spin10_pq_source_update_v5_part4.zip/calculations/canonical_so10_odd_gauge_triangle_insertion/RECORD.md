# OGT1: actual parity-odd Ihat ghost/two-vector insertion and heat response

Question: does the actual SMA hatted P/S breaking produce the same finite
physical-epsilon cGG kernel as its ordered positive-heat regulator response,
and does that kernel apply to the already qualified Spin10 anomaly tensor?
This is an actual one-loop insertion, not another representation trace screen
or a Ward-fitted counterterm. Baseb2ae38a93f89ab69c8bf7e2647964628b789e57b/
main33171oldblobs. Previousgoalturn PROGRESS closed parityeven bosonic DIM-heat.
Wholegoal ACTIVE/incomplete,state113/authority34of39 unchanged.

Freeze SMA1 qP=ig c A P,qS=0,qbarP=-ig c barP At, one Nambu source and
Gaussian -TrlogD/2; D0=i[[barSlash,hatSlash],[hatSlash,barSlash]],
G0=-i[[barSlash,hatSlash],[hatSlash,barSlash]]/k², physical mass-independent
zero-field symbol only. Gauge V=-ig barGamma_mu A_b G_mu^b on PP,
A=PL T-PR T.T,At=PR T-PL T.T. chi=PL-PR has the actual SMA orientation,
tr_phys(chi Gamma0Gamma1Gamma2Gamma3)=4,epsilon0123=+1. Physical spintrace4,
not the integer-witness trace. No physical mass/flavor/VEV is set tozero.
M=0 here selects the marginal mass-independent insertion; external p1,p2,q
have hats0, q=-p1-p2 and all nonexceptional Euclidean invariants positive.

At ghost momentum physical, the actual Ihat Hessian in D coordinates is
E_PS=+g At_a hatSlash,E_SP=-g hatSlash A_a, diagonal0. Derive this from
qD+D X-Y D, X=diag(ig A_a,0),Y=diag(ig At_a,0) with distinct node momenta.
Retain both mixed orientations and qS0. The selected Euclidean insertion
is -1/2 Tr[G0 V G0 V G0 E], with complete ordered field sums; functional
second derivatives produce the usual separate Bose factor2. Do not add a
second Gaussian half or erase the conjugate-right charge word.

The positive-heat identity uses Eheat(k)=exp(-2t k²),
Gt Rt=(1+Eheat G0 V)^-1(1-Eheat). Its selected Euclidean response is
-Tr[(Eheat G0 V)^2(1-Eheat)X], fixed by the actual graded Gaussian/source
identity. Maintain order Gt Rt X, endpoint momentum k,r=k-p1,s=k-p1-p2.
Jacobian/tangent trace has no cGG degree; no general measure/phase conclusion.
At D4 Ihat iszero pointwise but the regulator response need not vanish.
Do not interchange fixed-cutoff D4 and removed-cutoff dimensional limits.

Primary uses the actual SMA16-spinor witness, physical divisor4, literal
projector traces and new32x32 free/ghost-flow check. It derives the dimensional
triangle by Gamma moments and exact simplex polynomials and the heat response
by its first positive-heat Taylor moment. Replay uses four-dimensional epsilon
Clifford reduction, ordered chiral charges, wedge-coordinate/simplex algebra
and Schwinger moments. Full256Lorentz/momentum tensor positions and both finite
color orders remain until the late gate. Preserve every zero and sign.
No parity-even trace averaging is applied to this physical odd trace.

Only after both calculations agree, reuse MAR1's authenticated full Spin10
symmetric cubic zero and its actual-YCT carrier identification. Do not replay
16215known trace slots. A unit-charge anomalous U1 fixture and a noncommuting
Hermitian3x3fixture with distinct complex ordered traces test the nonzero
universal coefficient, Gaussianhalf/rightword/epsilon/hat signs. They are
method controls, not adopted physical gauge groups or new matter.

Controls omit either mixed insertion, prematurely set internal hats0, reverse
analytic hat rank, omit third heat, replace heat6 by4, wrong witness/Gaussian
normalization or conjugate-right colorword. Modeldabc0 is insensitive by itself;
all sensitivity must be measured in the anomalous controls. Compare both actual
regulator outputs without assigning any unknown value from cancellation.

Freeze8sources/copies/inputs before sequential P/R/V600s eachafterimports,
8GiBsampledprivate/350MiBlaunchcommit/16MiBpacket. New currentturn E4 root0
steps0/0/0/0/0/2, historicalcustody2sevenNOTPASS required. Preserve nativefailed/
unfinished sources and captures; version corrections only. Validate and external
before/index/afterlocalcommitseals preserving33171oldblobs. No old scientific
replay/currentpolicy substituted into historical manifests.

Scope ceiling: actual selected mass-independent Euclidean parity-odd cGG
one-loop Ihat/ordered-heat response and authenticated group application.
Not cGGG/cGGGG completeness, all chiral/source Slavnov restoration, absolute
Pfaffian/global phase, QAP/multiple products/measure, Lorentzian/causal/constant
vacuum limits, massive matterC1,E5/A5 or GUT. chi4 and all prior finite constants
remain free; no physical scheme or counterterm adopted. Both scalar failures,
quartetFAIL,flavorpause,HB1/C5,state/main/history remain. No agents,branch/
worktree,push,outreach,publication or foundational change. Shared action,
Clifford/dimensional/heat/analytic assumptions,data/software and AIauthor limit
independence; agreement is not independent scientific confirmation.

Primary literature comparator Belusca-Maito etal2004.14398v2 sections3.3/6.2.1,
https://arxiv.org/html/2004.14398v2 and Bilal0802.0634 sections5.2/7.2,
https://arxiv.org/pdf/0802.0634,consulted2026-10-23. They motivate an explicit
physical epsilon insertion and separating local anomaly from finite restoring
terms; no source model coefficient or scheme is imported as the answer.
