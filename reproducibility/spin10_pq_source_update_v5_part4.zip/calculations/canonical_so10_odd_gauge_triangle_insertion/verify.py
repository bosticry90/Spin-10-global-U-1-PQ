from data import *
from itertools import product
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
def eq(x,y):assert s.simplify(s.sympify(x)-s.sympify(y))==0,(x,y)
for field in ['dimensional_tensor','positive_heat_tensor','spin_odd_term1','spin_odd_term2']:
 assert A[field].keys()==B[field].keys()
 for k in A[field]:eq(A[field][k],B[field][k])
for k in A['dimensional_tensor']:
 eq(A['dimensional_tensor'][k],A['positive_heat_tensor'][k])
 for x,y in zip(A['dimensional_mixed_pieces'][k],B['dimensional_mixed_pieces'][k]):eq(x,y)
for field in ['radial_hat_finite','heat_vector_p2_coefficient','physical_spin_trace']:eq(A[field],B[field])
for x,y in zip(A['color_fixture_ordered_traces'],B['color_fixture_ordered_traces']):eq(x,y)
eq(A['color_fixture_symmetric_trace'],B['color_fixture_symmetric_trace'])
assert A['witness_spin_trace']/A['witness_divisor']==4 and A['ordered_functional_not_twice_differentiated'] and B['ordered_functional_not_twice_differentiated']
def epsilon(w):
 if len(set(w))!=4:return 0
 return (-1)**sum(w[i]>w[j] for i in range(4) for j in range(i+1,4))
unit=s.simplify(s.sympify(A['dimensional_tensor']['0_1_2_3'])/epsilon((0,2,1,3)));assert unit!=0
for mu,nu,rho,sigma in product(range(4),repeat=4):
 key=f'{mu}_{nu}_{rho}_{sigma}';eq(A['dimensional_tensor'][key],unit*epsilon((mu,rho,nu,sigma)))
 eq(A['dimensional_tensor'][key],A['dimensional_tensor'][f'{nu}_{mu}_{sigma}_{rho}'])
# Actual full Spin10 tensor is inherited complete evidence, not a fresh zero trace.
MAR=CAL/'canonical_so10_matter_anomaly_reuse';GA=CAL/'canonical_so10_local_gauge_anomaly'
assert digest(MAR/'validation_receipt.json')=='fc5eb3c19e01f5b4e0e9eabcba05d26a09da224556132bdcfd0a561d5db71172'
assert digest(GA/'validation_receipt.json')=='cf2cb5b63cc835822f0d143c465ec97123337f9a203c991982bcdee0ee2c4e0b'
mar=read(MAR/'validation_receipt.json');ga=read(GA/'validation_receipt.json')
assert mar['historical_gauge_cubic_and_linear_zero_reusable'] and mar['historical_declared_carrier_matches_candidate'] and ga['all_symmetric_cubic_gauge_traces_zero_checked'] and ga['symmetric_cubic_slots_checked']==16215
nzcount=sum(s.sympify(v)!=0 for v in A['dimensional_tensor'].values());assert nzcount==24
left,right=list(map(s.sympify,A['color_fixture_ordered_traces']));assert s.simplify(left-right)!=0 and s.simplify(left+right)!=0
controls={'premature_internal_hat_zero':nzcount,'wrong_hat_rank_sign':nzcount,'omit_third_heat':nzcount,'wrong_heat6_as4':nzcount,'omit_Nambu_half':nzcount,'wrong_witness_divisor':nzcount,'drop_conjugate_right_colorword':nzcount,'wrong_transpose_word_reversal':nzcount}
for j in [0,1]:
 controls['omit_mixed_insertion_'+str(j)]=sum(s.sympify(v[j])!=0 for v in A['dimensional_mixed_pieces'].values());assert controls['omit_mixed_insertion_'+str(j)]>0
# Store altered coefficients explicitly, so sensitivity is not a label-only claim.
changed_units={'correct':str(unit),'wrong_hat_rank':str(-unit),'premature_hat0':'0','wrong_heat4':str(s.simplify(s.Rational(3,2)*unit)),'missing_Nambu_half':str(2*unit),'inflated_witness_trace':str(4*unit),'omit_third_heat':'0'}
for k,v in changed_units.items():
 if k!='correct':assert s.simplify(s.sympify(v)-unit)!=0
artifact={'schema':'OGT1_ACTUAL_CGG_ODD_IHAT_HEAT_MATCH','common_phase_and_loop_factor':'i g10^3/(16pi^2)','finite_tensor_per_symmetric_color_trace':A['dimensional_tensor'],'symmetric_color_trace':'Tr16(Ta {Tb,Tc})','unit_coefficient_epsilon_mu_rho_nu_sigma':str(unit),'physical_epsilon_orientation':'0123_PLUS','ordered_functional_coefficient_not_twice_differentiated':True,'unit_charge_U1_fixture_coefficient':str(2*unit),'noncommuting_color_fixture_coefficient':str(s.simplify((left+right)*unit)),'actual_Spin10_three_family_tensor':0,'Spin10_symmetric_cubic_slots_inherited':16215,'Spin10_ordered_slots_implied_by_symmetry':45**3,'historical_traces_recomputed':False,'MAR_receipt_sha256':digest(MAR/'validation_receipt.json'),'local_anomaly_receipt_sha256':digest(GA/'validation_receipt.json'),'higher_gauge_insertions_or_global_phase_qualified':False,'counterterm_or_physical_scheme_adopted':False}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_odd_triangle_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_ACTUAL_CGG_ODD_IHAT_AND_POSITIVE_HEAT_MATCH_WITH_SPIN10_TENSOR_APPLICATION','elapsed_after_imports':time.perf_counter()-start,'tensor_positions_per_regulator':256,'spin_odd_positions_compared':512,'nonzero_universal_epsilon_positions':nzcount,'unit_coefficient':str(unit),'unit_charge_control_coefficient':str(2*unit),'noncommuting_color_fixture_ordered_traces':[str(left),str(right)],'full_PS_new_ghost_and_inverse_positions':2048,'full_PS_loop_fixture_positions':16,'negative_control_changed_positions':controls,'negative_control_units':changed_units,'actual_Spin10_selected_odd_breaking':0,'inherited_symmetric_cubic_slots':16215,'new_model_trace_slots_computed':0,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'higher_gauge_or_full_chiral_Slavnov_QAP_phase_proved':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','scientific_authority_changed':False,'authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
