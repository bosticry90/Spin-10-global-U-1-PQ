# OGT1 ordered Ihat and positive-heat kernels

Use Euclidean Gamma1=-TrlogD/2. r=k-p1,s=k-p1-p2,external hats0. The three
propagators give(-i)^3, two vertices(-ig)^2 and Ihat g; the complete Gaussian
factor is -1/2. After the mixed orientations and cyclic finite matrix trace,
the stripped dimensional numerator is

 hatk² {tr[gamma_mu A_b barslash(r) gamma_nu A_c barslash(s) At_a]
       -tr[barslash(k) gamma_mu A_b barslash(r) gamma_nu A_c A_a]}.

The common phase is derived before projection; no arbitrary Wick sign is fitted.
In the physical odd part both color orders TaTbTc and TaTcTb must be retained.
Move projectors using barred anticommutation and hatted commutation only. Primary
computes these traces literally; replay uses tr_phys(chi fourGamma)=4epsilon.
Reversing transpose words is essential. A physical-epsilon trace is not the
old parity-even restricted comparison trace.

Feynman weights x0,x1,x2 sum1, shifted k=l+(x1+x2)p1+x2p2. The hat numerator
is unchanged. The symmetric l_alpha l_beta covariance drops from the epsilon
contraction before integration. The exact nonexceptional radial moment is
h/4 Gamma(eps) Delta^(-eps),h=-2eps, in16pi²units with the usual analytic
normalization. Derive this through Gamma and independently Schwinger integration.
Its limit exists although setting hats0 before the UV integral would erase it.
logDelta is integrable at simplex corners in the retained domain; no scaleless
integral, fictitious physical mass or exceptional IR contact is discarded.

At finite heat, the actual n2 word carries
exp[-2t(Qk+Qr)](1-exp[-2t Qs])/(Qk Qr) times the physical trace of
barslash(k) gamma_mu A_b barslash(r) gamma_nu A_c A_a and phase -ig³.
The first heat product depends only on p1, so its vector integral has no
p2 component and its odd contraction vanishes. Retain it until that symmetry
is established. The other product has heat length6 and Taylor factor
4t k.(2p1+p2). Its p2 coefficient is determined by an ordinary positive
Gaussian moment, not by the dimensional answer. All p1-only denominator and
heat Taylor terms are independently epsilon-insensitive. Higher Taylor terms
are suppressed at t0 under the declared nonexceptional UV-shell argument.

Report ordered functional coefficients; differentiation twice w.r.t. the two
gauge fields is a distinct combinatorial factor2. Reuse the single-variation
Schwartz-domain construction and Gaussian dual transpose from CSW, not arbitrary
continuum finite-part trace cyclicity or a global Pfaffian phase theorem.
