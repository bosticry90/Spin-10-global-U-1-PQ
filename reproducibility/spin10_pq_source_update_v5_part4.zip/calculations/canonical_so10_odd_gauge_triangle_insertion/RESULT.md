# OGT1: the actual odd cGG insertion matches the ordered heat response

Qualified selected mass-independent Euclidean parity-odd ghost/two-gauge-field
kernel. ReceiptSHA25697ff54a20cd05e0c0d4a28d47989a5c5d06039236ab76997c8e9a7c415350b3d.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

The actual hatted P/S action insertion and the independently extracted positive-
heat regulator response give the same ordered functional coefficient:

    [i g10³/(16pi²)] * (1/3) * d_abc
      * epsilon_(mu rho nu sigma) p1_rho p2_sigma,
    d_abc=Tr16(Ta {Tb,Tc}), epsilon0123=+1.

This uses Gamma1=-TrlogD/2 and the actual SMA chi orientation. It is an
Euclidean imaginary variation coefficient; no Lorentzian continuation or
absolute Pfaffian phase is supplied. Functional differentiation twice in
the two gauge fields has the separate Bose factor2. The physical spintrace
is4, despite the primary's16component Clifford witness/divisor4. There is
no extra Nambu half. Pure-gauge three-family multiplication is applied once.

Only after deriving the nonzero universal coefficient, the gate applies the
qualified Spin10 symmetric cubic tensor. Its16215complete symmetric slots
are authenticated inherited evidence, not recomputed traces. MAR1 supplies
the actual candidate-carrier identification and trace-covariant reuse.
Consequently this actual selected Spin10 three-family odd kernel is zero.
The full91125ordered color slots follow by symmetry. This closes a particular
regulator-level dependency that the representation zero alone did not calculate.
It does not qualify all higher insertions, a full anomaly/measure construction,
or a global determinant phase.

## Actual action and two integral routes

The inherited physical flow qP=ig c A P,qS0 and qbarP=-ig c barP At determines
E_PS=+g At hatSlash and E_SP=-g hatSlash A at physical external ghost momentum.
The new full P/S check verifies qD+D X-Y D=E at1024positions, the free inverse
at1024positions and16literal ordered-loop fixture entries. Both mixed
orientations are retained. The mass-independent zero-field symbol does not
set physical neutrino/Yukawa masses tozero or change a benchmark.

Primary computes the physical odd part from actual16spinor projectors,
retaining both finite-color trace orders. It uses the exact off-shell
Feynman-parameter/Gamma integral. After shifting k=l+(x1+x2)p1+x2p2, the
two mixed terms have simplex weights x0 and x2. The actual hatted Gaussian
moment is h Gamma(epsilon)Delta^(-epsilon)/4 with h=-2epsilon, finite-1/2.
The symmetric loop covariance drops from the epsilon contraction. The
positive nonexceptional invariants control the simplex endpoint logarithms;
no scaleless integral or exceptional IR contact is deleted.

Replay independently reduces the four-bar-gamma physical epsilon trace,
uses ordered chiral charges and wedge/simplex algebra, and evaluates the
radial moment by Schwinger integration. It independently evaluates the
positive-heat vector moment. All256Lorentz/momentum positions agree between
regulators, including24nonzero universal epsilon slots and232zeros;512odd
spin coefficients and both mixed contributions agree between methods.

For the heat response the actual word is -Tr[(E G0 V)^2(1-E)X]. Its weight
is exp[-2t(Qk+Qr)](1-exp[-2t Qs]), with r=k-p1,s=k-p1-p2. The first heat
term depends only on p1 and has zero odd epsilon contraction by symmetry.
The second term has heat6. Its p2 vector coefficient is-1/6, from an ordinary
positive Gaussian moment; it yields the independently measured1/3 unit.
Order Gt Rt X and each node's heat factor are retained. At fixed D4 Ihat
vanishes pointwise; the surviving heat response demonstrates why that is not
permission to erase the removed-cutoff dimensional insertion. No value is
assigned from the desired Spin10 zero or from a counterterm cancellation.

## Sensitive controls and evidence

The unit-charge U1 method fixture has nonzero coefficient2/3. The separate
noncommuting Hermitian3x3fixture has ordered traces(1+i)/4 and(1-i)/4,
symmetric trace1/2, and a nonzero imaginary antisymmetric difference. It
detects an incorrect transpose-word reversal that the physical model's
zero tensor could not detect. Neither fixture is an adopted physical model.

Every tested omission/sign/normalization control changes24universal slots:
either mixed Ihat orientation, premature internal hats0, wrong analytic hat
rank, omission of the third heat, heat6 replaced by4, missing Nambu half,
inflated witness trace or missing/wrong conjugate-right colorword. Altered
units are explicitly stored: correct1/3,wronghat-1/3,wrongheat4=1/2,
missinghalf2/3,inflatedwitness4/3,omittedhat/thirdheat0. The physical Spin10
zero alone is insensitive to these errors, as disclosed.

Selected member packed/rawSHA256:
aa01632ad9d322ffae7a4124db93065de58a4555a28d66cb7381141cd487882d /
ca28d8d448b04bb9fe5cb43da11ee70a1b00637f22761e8143ca4641fbdfaef2.
P/R/V native0 in16.837291/0.424890/1.601488s afterimports,9/1/2samples,
private sampled maxima60813312/397312/47738880B, not continuous peaks.
Eight source copies,60/68bindings,pre-reportpacket98530B. All600s/8GiBsampled/
350MiBlaunch/16MiB limits respected; no worker/controller failure. New current-
turn E4 root0steps0/0/0/0/0/2,custodyexit2sevenNOTPASS. No old scientific replay.
External before/index/afterlocal seals must preserve33171oldblobs and new bytes.

[Belusca-Maito etal.,sections3.3/6.2.1](https://arxiv.org/html/2004.14398v2)
is a primary-method comparator for treating evanescent insertions and separating
odd anomalies from removable finite breakings. Its chiral model/conventions are
not this action or heat prescription. [Bilal,sections5.2/7.2](https://arxiv.org/pdf/0802.0634)
provides established anomaly/group context. The displayed model coefficient
comes from the frozen actual kernels, not an imported published number.

## Next action and limits

The next least expensive competent step is a complete higher-gauge color
reduction, not a new16215trace calculation. For cGGG, the actual odd Nambu
color factor may be the reversed four-word difference, which is reducible
to f*d. For cGGGG, locality/Lorentz counting permits only an epsilon times
an antisymmetrized four-gauge colorword; the anticommutator-of-commutators
identity may reduce it to f*f*d. These are prospective next targets: their
actual projector signs, Bose symmetrization, power-counting and analytic
premises must be checked before claiming complete odd-sector coverage.
Do not assume all fifth-order Spin10 traces vanish; the historical nonzero
fifth Cartan moment remains a sensitive chirality fact. A gauge-invariant
nonlocal/absolute phase is a different obligation.

The result is one selected primitive one-loop regulated insertion and heat
response. Full renormalized source products, contact freedom, multiple
insertions/QAP, measure/global phase, all background and massive amplitudes,
physical causal limits, full E5/A5 and GUT remain unqualified. No state,
foundations, scheme, finite baseline or protected stage changed. Both adverse
scalar configurations, quartetFAIL, flavorpause,HB1/C5blocks and all historical
failures persist. No agents/branch/worktree/push/outreach/publication. Shared
action/formal analytic premises/software/AIauthor limit independence. The
complete investigation remains ACTIVE/incomplete, authority34/39 unchanged.
