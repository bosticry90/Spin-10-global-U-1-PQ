"""MMI1 universal noncommutative numerator proof plus actual SMA16 witness."""
from data import *
from functools import lru_cache
tick=begin('primary');b,u=s.symbols('b u',nonnegative=True);Q=b+u
rules={('B','B'):(b,()),('H','H'):(u,()),('H','B'):(-1,('B','H')),('B','A'):(1,('C','B')),('B','C'):(1,('A','B')),('H','A'):(1,('A','H')),('H','C'):(1,('C','H'))}
@lru_cache(None)
def normal(w):
 for i in range(len(w)-1):
  if w[i:i+2] in rules:
   c,v=rules[w[i:i+2]];z,r=normal(w[:i]+v+w[i+2:]);return s.expand(c*z),r
 return s.S.One,w
def poly(*w,c=1):return {tuple(w):s.sympify(c)}
def plus(*arr):
 d={}
 for a in arr:
  for w,z in a.items():d[w]=s.expand(d.get(w,0)+z)
 return {w:z for w,z in d.items() if z}
def times(a,c):
 out={}
 for w,z in a.items():
  for v,y in c.items():
   f,r=normal(w+v);out[r]=s.expand(out.get(r,0)+z*y*f)
 return {w:z for w,z in out.items() if z}
D=[[plus(poly('B',c=s.I),poly('A')),poly('H',c=s.I)],[poly('H',c=s.I),poly('B',c=s.I)]]
N=[[plus(poly('B',c=-s.I*Q),poly('C',c=b)),plus(poly('H',c=-s.I*Q),poly('B','A','H'))],[plus(poly('H',c=-s.I*Q),poly('H','A','B')),plus(poly('B',c=-s.I*Q),poly('B','C','A',c=-s.I),poly('A',c=u))]]
DS=plus(poly(c=Q**2),poly('A','C',c=b));DD=plus(poly(c=Q**2),poly('C','A',c=b));target=[[DS,{}],[{},DD]]
for i in range(2):
 for j in range(2):
  got=plus(*[times(D[i][k],N[k][j]) for k in range(2)]);assert plus(got,{w:-z for w,z in target[i][j].items()})=={}
U=plus(poly(c=Q),poly('B','A',c=-s.I));V=plus(poly(c=Q),poly('B','A',c=s.I))
for z in [times(U,V),times(V,U)]:assert plus(z,{w:-c for w,c in DD.items()})=={}
print('STAGE UNIVERSAL_NONCOMMUTATIVE_COLUMN_IDENTITY',flush=True)
d=packed(HERE/'primary_inputs.json.gz');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];g8=[s.kronecker_product(z,pa[2]) for z in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]];g=[s.kronecker_product(z,s.eye(2)) for z in g8];L=s.kronecker_product(s.diag(1,1,0,0),s.eye(4));R=s.eye(16)-L;C=s.kronecker_product(g8[0]*g8[2]*g8[5],pa[1]);zero(C.inv()*L.T*C-L)
RR=block(L,R,-R,-L);RI=block(L,-R,R,-L);zero(RR-dec(d['SMA']['R']));zero(RI-dec(d['SMA']['R_inverse']));zero(s.SparseMatrix.hstack(L,-R)-dec(d['SMA']['source_pullback']))
assert set(d['SMA']['coefficients'].values())=={'1'}
IC=s.eye(2);fullM=s.Matrix([[1+s.I,2-s.I],[2-s.I,3+2*s.I]]);rankM=s.diag(0,2);zero(fullM-fullM.T);assert nz(fullM*fullM.H-fullM.H*fullM)>0
selected=[4*j+c for j in range(8) for c in range(2)];pairsel=selected+[32+j for j in selected]
def operators(mom,M):
 bb=sum(z*z for z in mom[:4]);hh=sum(z*z for z in mom[4:]);qq=bb+hh;B=s.kronecker_product(sum((a*v for a,v in zip(g[:4],mom[:4])),s.zeros(16)),IC);H=s.kronecker_product(sum((a*v for a,v in zip(g[4:],mom[4:])),s.zeros(16)),IC);A=s.kronecker_product(L,M)+s.kronecker_product(R,M.H);CS=s.kronecker_product(R,M)+s.kronecker_product(L,M.H);W=CS*A;Wswap=A*CS;delta=qq**2*s.eye(32)+bb*W;deltas=qq**2*s.eye(32)+bb*Wswap
 Nm=block(-s.I*qq*B+bb*CS,-s.I*qq*H+B*A*H,-s.I*qq*H+H*A*B,-s.I*B*(qq*s.eye(32)+W)+hh*A);DD=block(s.I*B+A,s.I*H,s.I*H,s.I*B);GG=tidy(Nm*s.diag(deltas.inv(),delta.inv()));zero(DD*GG-s.eye(64));zero(GG*DD-s.eye(64));return DD,GG,B,H,A,CS,delta,deltas,qq,bb,hh
fixtures=[];controls={};raw=[]
for label,mom,M in [('nonnormal_fullhat',[2,1,0,0,1,-1],fullM),('barzero_fullmass',[0,0,0,0,1,-1],fullM),('rankdef_strict4D',[2,1,0,0,0,0],rankM),('masszero_fullhat',[2,1,0,0,1,-1],s.zeros(2))]:
 DD,GG,B,H,A,CS,delta,deltas,qq,bb,hh=operators(mom,M);raw.append((label,mom,M,GG));naive=tidy((-s.I*B+CS)*(qq*s.eye(32)+A*CS).inv());wrongorder=tidy((-s.I*qq*B+bb*CS)*delta.inv());controls[label]={'ordinary_massive_denominator':nz((naive-GG[:32,:32]).extract(selected,selected)),'commute_mass_with_adjoint':nz((wrongorder-GG[:32,:32]).extract(selected,selected)),'omit_mixed_hat_blocks':nz((s.diag(DD[:32,:32],DD[32:,32:])*GG-s.eye(64)).extract(pairsel,pairsel))}
 if hh==0:zero(GG[:32,32:]);zero(GG[32:,:32]);zero(GG[32:,32:]+s.I*B/qq);zero(GG[:32,:32]-naive)
 if bb==0:zero(GG[:32,:32]);zero(GG[:32,32:]+s.I*H/qq);zero(GG[32:,:32]+s.I*H/qq);zero(GG[32:,32:]-A/qq)
 if not M.todok():zero(GG+s.I*block(B,H,H,B)/qq)
 fixtures.append({'label':label,'momentum':mom,'mass':enc(M),'inverse':enc(GG.extract(pairsel,pairsel))})
# Constant unitary family basis and its forced auxiliary partner.
Uf=s.Matrix([[1,s.I],[s.I,1]])/s.sqrt(2);zero(Uf.H*Uf-IC);mom=[2,1,0,0,1,-1];DD,GG,B,H,A,CS,delta,deltas,qq,bb,hh=operators(mom,fullM);Dp,Gp,*_=operators(mom,Uf.T*fullM*Uf)
RP=s.kronecker_product(L,Uf)+s.kronecker_product(R,Uf.conjugate());RS=s.kronecker_product(R,Uf)+s.kronecker_product(L,Uf.conjugate());ROT=s.diag(RP,RS);CC=s.diag(s.kronecker_product(C,IC),s.kronecker_product(C,IC));sharp=tidy(CC.inv()*ROT.T*CC);zero(sharp*DD*ROT-Dp);zero(ROT.inv()*GG*sharp.inv()-Gp)
bad=s.diag(RP,RP);badsharp=tidy(CC.inv()*bad.T*CC);badcount=nz((badsharp*DD*bad-Dp).extract(pairsel,pairsel));assert badcount>0
finish('primary',{'method':'universal_noncommutative_numerator_normal_form_and_actual_SMA16_matrices','universal_column_identities':4,'universal_resolvent_product_identities':2,'mass_blocks_commuted':False,'denominators':'Delta=Q^2+b*C*A; Delta_s=Q^2+b*A*C; on RIGHT of each column','no_inverse_bar_p2_or_mass_in_final_formula':True,'positive_Q_Euclidean_invertibility':'Delta eigenvalues Q^2+b*m_singular^2 >= Q^2 >0','fixtures':fixtures,'controls':controls,'family_congruence_and_inverse_checked':True,'wrong_auxiliary_family_rotation_changed_positions':badcount,'barzero_auxiliary_soft_scaling':'Gss=A/Q; Q=lambda^2; Gps=-iH/Q; Gpp=0','uniform_Dirac_IR_bound_proved':False,'single_physical_source_pullback_preserved':True,'qS':'0 unchanged','source_copies':1,'strict4D_and_massless_limits_checked':True,'witness_spin_dimension':16,'comparison_spin_dimension':8,'spectator_identity_removed_for_comparison_only':True},tick)
