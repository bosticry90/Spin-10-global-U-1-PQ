# MMI1: denominators follow the full mixed operator

Let A=PL M+PR Mdagger and C=PR M+PL Mdagger (C here is a mass swap, not the
charge-conjugation matrix). B2=bI,H2=uI,BH=-HB, BA=CB,BC=AB, and H commutes
with both mass blocks. In particular A and C are not assumed to commute.
The actual inverse-operator block is

 D=[[iB+A,iH],[iH,iB]], Q=b+u.

Set W=CA=PL MdaggerM+PR MMdagger, V=AC, Delta=Q2+bW,
Delta_s=Q2+bV. Candidate inverse columns have the ordered numerators

 Npp=-iQB+bC,              Nps=-iQH+BAH,
 Nsp=-iQH+HAB,             Nss=-iB(Q+W)+uA,

 G=[[Npp Delta_s^-1, Nps Delta^-1],
    [Nsp Delta_s^-1, Nss Delta^-1]].

Primary reduces D*N=diag(Delta_s,Delta) using only the listed identities.
Every denominator stays on the RIGHT of its column. Since W and V are
positive Hermitian for the physical adjoint and Q>0,b>=0, their eigenvalues
are at leastQ2. Hence a right inverse exists in each finite spin/internal
matrix space and is the inverse. The same proof applies to arbitraryN,
including the physical48 and null mass directions. No inverseM is used.

A separate Woodbury route begins with G0=-i[[B,H],[H,B]]/Q and the mass only
in the PP block. Its finite-rank resolvent is Q-iBA; multiplying by Q+iBA
gives Delta. This explains why the quadratic-in-Q denominator occurs.
Replay instead uses the literal Schur inverse for b>0:

 D_eff=iB Q/b+A.

The final rational expression removes the apparent1/b singularity. At b=0
and Q=u>0 direct block inversion gives Gpp=0,Gps=Gsp=-iH/Q,Gss=A/Q,
consistent with the same formula. This is a real finite-momentum limit,
not permission to discard the zero-momentum infrared region.

For M=0 the full massless SMA inverse is recovered. At u=0, Q=b,
Gps=Gsp=0,Gss=-iB/Q and

 Gpp=(-iB+C)(Q+AC)^-1.

For a single real massm and general hats,

 Gpp=(-iQB+bm)/(Q2+bm2),

which differs from an ordinary (-iB+m)/(Q+m2) when u is nonzero. The
strict4D positive-mass pole is recovered without changing the h.c. sign.
These are D inverse blocks; the Gaussian K inverse also carries the fixed
right charge-conjugation inverse. No new open-line half or source is added.

Under a unitary constant family basis U, M'=U.T M U. The P field basis
rotation is RP=PL U+PR U*, while the correlated auxiliary basis is
RS=PR U+PL U*. Charge-conjugate transpose and the actual Dirac-to-P/S map
give the corresponding congruence of D and inverse congruence of G. An
unchanged or wrongly matched auxiliary rotation generally fails at hats!=0.
This is a basis change of regulator variables, not a new qS transformation.

An important infrared diagnostic follows directly: at barred momentum0 and
hat momentumlambda*n with n2=1, Gss=A/lambda2, mixed Gps is of order1/lambda,
and Gpp=0. Thus no finite Euclidean pole does not imply a uniform Dirac-like
1/|p| bound on the full massive auxiliary reference. Strict4D decoupling and
the physical massive PP limit remain valid. A quantum integration/trace-domain
proof must account for this scaling instead of transferring a massless bound
without justification. This is not a physical extra particle or anomaly.
