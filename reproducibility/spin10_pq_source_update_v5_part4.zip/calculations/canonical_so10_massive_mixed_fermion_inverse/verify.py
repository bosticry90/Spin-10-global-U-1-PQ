"""MMI1 exact fixture, covariance and limit gate; no massive loop claim."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
assert P['universal_column_identities']==4 and P['universal_resolvent_product_identities']==2
assert P['mass_blocks_commuted']==R['mass_blocks_commuted']==False
assert len(P['fixtures'])==len(R['fixtures'])==4;positions=0
for a,b in zip(P['fixtures'],R['fixtures']):
 assert a['label']==b['label'] and a['momentum']==b['momentum'];zero(dec(a['mass'])-dec(b['mass']));assert dec(a['mass']).shape==(2,2);zero(dec(a['mass'])-dec(a['mass']).T)
 A,B=dec(a['inverse']),dec(b['inverse']);assert A.shape==B.shape==(32,32);zero(A-B);positions+=32**2
assert positions==4096 and P['controls']==R['controls']
assert all(v>0 for v in P['controls']['nonnormal_fullhat'].values())
assert P['controls']['rankdef_strict4D']=={'ordinary_massive_denominator':0,'commute_mass_with_adjoint':0,'omit_mixed_hat_blocks':0}
assert P['controls']['masszero_fullhat']['ordinary_massive_denominator']==0 and P['controls']['barzero_fullmass']['commute_mass_with_adjoint']==0
assert R['barzero_scaling_verified_by_exact_momentum_doubling']
assert P['wrong_auxiliary_family_rotation_changed_positions']==R['wrong_auxiliary_family_rotation_changed_positions']>0
for obj in [P,R]:
 assert obj['family_congruence_and_inverse_checked'] and obj['no_inverse_bar_p2_or_mass_in_final_formula'] and obj['strict4D_and_massless_limits_checked']
 assert obj['single_physical_source_pullback_preserved'] and obj['source_copies']==1 and obj['qS']=='0 unchanged'
 assert not obj['uniform_Dirac_IR_bound_proved'] and not obj['physical_scheme_adopted'] and obj['new_massive_loop_integrals']==0
 assert obj['barzero_auxiliary_soft_scaling']=='Gss=A/Q; Q=lambda^2; Gps=-iH/Q; Gpp=0'
assert late['positive_mass_pole_polynomial']=='p**2 + m*mbar' and late['barred_pair_hc_sign']=='-1'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
recipe={'D':'[[iB+A,iH],[iH,iB]]','A':'PL*M+PR*Mdagger','C_mass_swap':'PR*M+PL*Mdagger','B_square':'b*I','H_square':'u*I','Q':'b+u>0','Delta':'Q^2+b*C*A','Delta_s':'Q^2+b*A*C','inverse_blocks':{'PP':'(-i*Q*B+b*C)*Delta_s^-1','PS':'(-i*Q*H+B*A*H)*Delta^-1','SP':'(-i*Q*H+H*A*B)*Delta_s^-1','SS':'(-i*B*(Q+C*A)+u*A)*Delta^-1'},'all_denominators_on_right':True,'M':'constant complex symmetric, arbitraryN, physicalN48','massless_and_strict4D_limits_qualified':True,'barzero_limit':{'PP':'0','PS':'-iH/Q','SP':'-iH/Q','SS':'A/Q'},'qS':'0 unchanged','physical_source_copies':1,'uniform_Dirac_IR_bound_or_analytic_dimensional_domain_proved':False,'physical_scheme_or_spectrum_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'massive_inverse_recipe.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'status':'QUALIFIED_EXACT_CONSTANT_MASS_SMA_MIXED_INVERSE_AND_LIMITS_WITH_AUXILIARY_IR_DIAGNOSTIC','elapsed_after_imports':time.perf_counter()-tick,'universal_noncommutative_column_identities':4,'universal_resolvent_identities':2,'fixture_inverse_positions_compared':positions,'fixture_count':4,'arbitrary_internal_matrix_dimension_proof':True,'physical_internal_dimension':48,'M_Mdagger_commuted':False,'no_inverse_M_or_bar_p2_required':True,'positive_real_Euclidean_Q_domain_invertible':True,'strict4D_positive_mass_and_full_massless_limits':True,'family_basis_congruence_and_correlated_auxiliary_rotation_verified':True,'negative_control_changed_positions':P['controls'],'wrong_auxiliary_family_rotation_changed_positions':P['wrong_auxiliary_family_rotation_changed_positions'],'barzero_auxiliary_scaling':'A/lambda^2','barzero_scaling_verified_by_exact_momentum_doubling':True,'uniform_Dirac_IR_bound_or_quantum_domain_qualified':False,'single_physical_source_and_qS0_preserved':True,'new_massive_loop_integrals':0,'physical_scheme_or_mass_spectrum_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','recipe_sha256':sha256(blob).hexdigest(),'recipe_raw_sha256':sha256(raw).hexdigest(),'primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
