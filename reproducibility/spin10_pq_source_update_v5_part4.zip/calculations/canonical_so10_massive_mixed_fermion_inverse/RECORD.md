# MMI1: exact constant-mass inverse of the actual mixed SMA reference

Previous increment YBH1 qualified the selected Yukawa background heat local
comparison. Base d2c6f4f72ad7adccc3b13749990410edecf3424e/main32971 blobs;
state113/authority34/39 unchanged. No new reference or physical scheme is
selected here: invert the already specified SMA constant-mass quadratic action.

Question: what is the full physical/auxiliary inverse with nonzero hatted
momenta and a general complex symmetric mass, and which strict4D/infrared
claims are justified? SMA1 explicitly leaves this as a prerequisite; replacing
k2 by k2+m2 in its massless propagator has not been justified. It is necessary
for actual massive fermion threshold kernels, independently of the unfinished
g3 background completion. The latter still needs a full-D bosonic/reference
continuation; do not bypass that domain by expanding more component tensors.

Freeze SMA1 actual action, coefficient receipt, split-Clifford source map and
h.c. sign, YCT1 mass form and current policy. At zero external background use
constant M=M.T with physical adjoint Mdagger, arbitrary internal sizeN
(the physical lift isN=48). No mass spectrum or Yukawa value is selected.
The reference vacuum's neutral rank<=3 block is included as a special case;
flavor work remains paused. Work with real Euclidean momenta, barred rank4,
B=bar_slash(p), H=hat_slash(p), b=bar_p2,u=hat_p2,Q=b+u>0. u is a momentum
square, NOT the formal hatted dimension D-4. Literal finite-Clifford positivity
is not an analytic dimensional-regularization or quantum IR theorem.

Primary proves a universal noncommutative numerator identity keeping A and
its chirality-swap noncommuting, then evaluates the actual split16-spin SMA
operator. Replay independently inverts the physical/auxiliary block through
Schur complements in an8-spin Weyl/hat representation; at b=0 it solves the
off-diagonal block directly. Compare complete matrix fixtures after removing
only the primary's explicit spectator identity, with no trace normalization
or extra particle. Fixtures include a nonnormal complex symmetric mass,
rank-deficient and zero mass, nonzero hats, strict4D and b=0. These are exact
algebraic diagnostics, not physical benchmark choices. The general proof is
not replaced by agreement of fixtures.

Check Q>0 invertibility from positive MdaggerM/MMdagger, no artificial1/b
pole in the final formula, full massless and strict4D limits, unchanged
single source and qS=0, and unitary family congruence including the correlated
auxiliary basis transformation. Controls omit hatted mixing, substitute an
ordinary massive denominator, commute M with Mdagger, or rotate the auxiliary
basis incorrectly. Report insensitive limits honestly. Expose the actual
bar-zero soft scaling; do not call absence of finite-momentum poles a uniform
IR bound, mass gap or full QAP domain. No inverseM, inverseY, inverseg or
numerical spectrum is required or allowed to rescue a mismatch.

Freeze eight sources/copies, inputs and expectations before workers. Three
sequential600s-afterimports/8GiB sampled-private/350MiB launch-commit/16MiB
packet stages. Reuse this goal turn's completed fresh YBH E4 audit with its
hash; custodyexit2/seven remains NOTPASS. Preserve failed and unfinished
sources/captures; only frozen versioned corrections. A failed operator or
replay identity stops dependent execution. Before/index/after local seals
must preserve all32971 prior blobs. No agents, branches/worktrees, external
actions, publication/push, adoption or scientific-authority promotion.

Ceiling: exact bare constant-mass reference inverse and stated algebraic
limits/covariance, plus a regulator-auxiliary infrared diagnostic. Not a
massive loop, finite restoration, all-g3 background construction, analytic
heat/causal/IR domain, QAP/products/measure/Pfaffian phase, physical scheme,
complete matterC1, E5/A5 or GUT. Shared action/Clifford premises/software/AI
and old normalization proofs limit independence. Protect both scalar failures,
quartetFAIL, paused flavor, blockedHB1/C5, constants and historical evidence.
