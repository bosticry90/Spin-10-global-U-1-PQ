"""MMI1 exact actual-H neutral support through two independent old data routes."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'neutral_support_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
rows=[];projectors=[]
for role in ['primary','replay']:
 d=packed(CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz'));P=dec(d['P_N']);T=list(map(dec,d['Tminus']));H=dec(d['H_new']);zero(P*P-P);zero(P-P.H);zero(P-P.T);assert s.trace(P)==1 and d['c_N']=='sqrt(2)/2';zero(dec(d['mass126'])-s.sqrt(30)*P/10);zero(dec(d['mass10']))
 if role=='primary':HH=[tidy(sum((H[a,h]*T[a] for a in range(45) if H[a,h]),s.zeros(16))) for h in range(12)]
 else:
  HH=list(map(dec,d['SM_generators']));co=s.Matrix(45,12,lambda a,h:simp(s.trace(T[a]*HH[h])/2));gram=tidy(co.T*co);assert gram.det()!=0;zero(co*gram.inv()*co.T-H*H.T)
  for h in range(12):zero(HH[h]-sum((co[a,h]*T[a] for a in range(45) if co[a,h]),s.zeros(16)))
 for g in HH:
  for z in [g*P,P*g,g.T*P,P*g.T]:zero(z)
 # The current basis can differ, so compare the stabilizer projector rather
 # than silently renaming its twelve coordinates.
 projectors.append(enc(H*H.T));candidate=None
 for a,t in enumerate(T):
  if nz(t*P):candidate=(a,tidy(t-sum((H[a,h]*sum((H[b,h]*T[b] for b in range(45) if H[b,h]),s.zeros(16)) for h in range(12) if H[a,h]),s.zeros(16))));break
 assert candidate is not None;a,broken=candidate;assert nz(broken*P)>0 and nz(P*broken)>0
 for h in range(12):assert simp(sum(H[b,h]*s.trace(T[b]*broken)/2 for b in range(45) if H[b,h]))==0
 rows.append({'route':role,'neutral_projector':enc(P),'H_stabilizer_projector':enc(H*H.T),'H_annihilation_positions':12*4*16**2,'mass10_zero':True,'mass126_direction_exact':True,'broken_plane_seed':a,'pure_broken_control':enc(broken),'broken_neutral_changed_positions':nz(broken*P)+nz(P*broken),'all_four_Nambu_background_charge_sides_annihilate_neutral_support':True})
zero(dec(rows[0]['neutral_projector'])-dec(rows[1]['neutral_projector']));zero(dec(projectors[0])-dec(projectors[1]));assert rows[0]['broken_plane_seed']==rows[1]['broken_plane_seed'];zero(dec(rows[0]['pure_broken_control'])-dec(rows[1]['pure_broken_control']))
# The inverse is block diagonal in the exact neutral projector because the
# mass perturbation is supported there and the free spin operator is internal I.
# This is a finite-rank resolvent consequence, not another loop evaluation.
print('RESULT '+json.dumps({'status':'QUALIFIED_ACTUAL_NEUTRAL_MASS_SUPPORT_AND_H_WEIGHTED_MIXED_INVERSE_COROLLARY','elapsed_after_imports':time.perf_counter()-tick,'actual_H_annihilation_positions_per_route':12*4*16**2,'two_distinct_H_basis_routes':True,'H_basis_span_projector_compared':True,'neutral_rank':1,'physical_family_matrix_remains_general':True,'mass_dependent_inverse_correction_has_two_sided_neutral_support':True,'H_charge_weighted_massive_inverse_equals_massless':True,'generic_auxiliary_IR_enhancement_absent_from_pure_H_charged_segments':True,'pure_H_one_loop_reference_mass_independence_within_candidate':True,'pure_broken_control_seed':rows[0]['broken_plane_seed'],'pure_broken_control_changed_positions':rows[0]['broken_neutral_changed_positions'],'full_two_loop_mass_independence_claimed':False,'general_quantum_IR_or_QAP_proved':False,'neutral_determinant_or_phase_discarded':False,'new_loop_integrals':0,'scientific_acceptance':'NOT_PERFORMED','scientific_authority_changed':False,'authority':'34/39','input_projector_P_N':rows[0]['neutral_projector'],'broken_control':rows[0]['pure_broken_control']},sort_keys=True),flush=True)
