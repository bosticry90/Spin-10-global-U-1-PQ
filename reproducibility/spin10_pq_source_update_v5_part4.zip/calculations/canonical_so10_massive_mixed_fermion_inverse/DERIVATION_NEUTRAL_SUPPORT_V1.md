# Neutral mass support and charged background propagators

The actual YCT reference has M10(v)=0 and M126(v)=c_N sigma PN, with real
rank-one PN=e15 e15.T in this frame. The family matrix Y126 stays arbitrary
and symmetric. Both actual H bases must satisfy T_H PN=PN T_H=0, and their
transposes also annihilate PN. This is stronger than the homogeneous mass
spurion relation T_H.T M+M T_H=0 for a general invariant charged mass.

Let N be the neutral internal projector lifted by the family and spin/PS
identities. G0 commutes with N, and the added constant mass has support on
both sides of N. The full reference therefore preserves N. On its complement
it is exactly the massless reference. Equivalently the Woodbury correction
G_M-G0=-G0 P A (1+G0_PP A)^-1 P G0 has neutral support on both ends. Thus

 G_M-G0=N(G_M-G0)N.

All physical/auxiliary background charge blocks X_H and Xswap_H annihilate
N on both sides, because they consist of T_H and -T_H.T. Hence either charge
at either end of the mass correction gives zero. The same is true of its
barred reference current Gamma_mu X_H and minimal H heat variations, which
preserve the neutral/charged split. Charged H-background propagator factors
therefore retain their massless reference values and do not inherit the
neutral Gss=A/Q enhancement. The statement holds for arbitrary sigma,Y126
and null masses; no inverseY or numerical spectrum is involved.

For a loop containing only such external H-background vertices, a neutral
mass correction cannot occur on any charged segment. The pure neutral factor
of the reference determinant is H-background independent. This supplies a
bounded mass-independence corollary; it does not normalize away that factor
or its phase. It also does not construct a general regulated trace theorem.

A broken generator can connect the neutral support to charged matter. Select
one by subtracting the H projection from an actual plane generator with
nonzero action on PN. Its surviving product is a sensitive negative control.
Internal broken vectors, Yukawa fluctuations or full BRST/source insertions
can therefore restore mass dependence in two-loop graphs. Neither zero SM
index nor this projector identity permits discarding RH neutrinos from the
full threshold, nor transferring a massless IR proof to all massive products.
