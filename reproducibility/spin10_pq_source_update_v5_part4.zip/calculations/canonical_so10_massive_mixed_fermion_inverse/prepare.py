"""MMI1 freeze the actual SMA action and the universal inverse question."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_yukawa_background_heat_completion'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/massive-mixed-fermion-inverse-v1-2026-10-23');OLD=CONTROL.with_name('yukawa-background-heat-completion-v1-2026-10-23')
BASE='d2c6f4f72ad7adccc3b13749990410edecf3424e';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32971
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
assert digest(PRED/'validation_receipt_v2.json')=='a4e2ea0861a15b54365373a7ee2fa7a9889f43d52594f943f1d34d017623a84b'
for n in ['validation_receipt_v2.json','verify_v2_capture.json','RESULT.md','validation_preparation_v2.json','selected_background_family.json.gz']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json','readiness.jsonl','readiness_result.json','readiness_stderr.txt']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'readiness_result.json')['step_exits']==[0,0,0,0,0,2]
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V561.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
SMA=CAL/'canonical_so10_sterile_matter_action'
for n in ['ACTION_V1.md','RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz']:add(SMA/n)
assert digest(SMA/'validation_receipt.json')=='21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
sma=packed(SMA/'primary_tables.json.gz');rep=packed(SMA/'replay_tables.json.gz')
for role in ['primary','replay']:
 gz(HERE/(role+'_inputs.json.gz'),{'SMA':{k:sma[k] for k in ['R','R_inverse','source_pullback','coefficients','physical_antifield_copies','auxiliary_BRST_transform']},'independence_note':'actual source/field conventions shared; inverse derivations differ'});add(HERE/(role+'_inputs.json.gz'))
gz(HERE/'validation_control_inputs.json.gz',{k:rep[k] for k in ['positive_mass_pole_polynomial','barred_pair_hc_sign']});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'MMI1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'current_turn_E4_authenticated_reuse':True,'scientific_acceptance':'NOT_PERFORMED'})
print('MMI1_FROZEN',len(bind),'bindings',flush=True)
