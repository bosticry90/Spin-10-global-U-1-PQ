"""One bounded exact structural corollary; original inverse stages are not rerun."""
from pathlib import Path
import json,sys,subprocess,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/massive-mixed-fermion-inverse-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 p=subprocess.run([sys.executable,'-B',str(HERE/'prepare_neutral_support.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8');dump(HERE/'neutral_preparation_capture.json',{'native_exit':p.returncode,'stdout_and_stderr':p.stdout});print(p.stdout,flush=True);assert p.returncode==0
 c=capture([sys.executable,'-B',str(HERE/'neutral_support.py')]);dump(HERE/'neutral_support_capture.json',c);dump(CONTROL/'neutral_support_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1;r=rows[0];assert r['elapsed_after_imports']<600 and r['status']=='QUALIFIED_ACTUAL_NEUTRAL_MASS_SUPPORT_AND_H_WEIGHTED_MIXED_INVERSE_COROLLARY'
 dump(HERE/'neutral_support_receipt.json',r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(HERE/'neutral_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
