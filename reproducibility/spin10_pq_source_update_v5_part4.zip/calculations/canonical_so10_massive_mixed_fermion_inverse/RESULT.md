# MMI1: exact massive mixed inverse, with a model-specific infrared distinction

The exact constant-mass SMA physical/auxiliary inverse is qualified within
its stated algebraic Euclidean domain. Receipt status
`QUALIFIED_EXACT_CONSTANT_MASS_SMA_MIXED_INVERSE_AND_LIMITS_WITH_AUXILIARY_IR_DIAGNOSTIC`, SHA256
`4a59fceecdcf9c61fa046b576ff73be8e2e46030498edb33d2984f6d49944b47`. The separate actual-neutral support corollary has
receipt V2 SHA256 `711c806c1a8e26642d368eab7022e5db0b805f99b1d1b8c30bd3b828f6fc59b7`.
Scientific/director acceptance not performed; state113/34of39 unchanged.

## The inverse follows the existing action

For constant arbitrary complex symmetric M, set
A=PL M+PR Mdagger, Atilde=PR M+PL Mdagger, B=bar_slash(p), H=hat_slash(p),
b=bar_p2,u=hat_p2,Q=b+u. The actual SMA block is

```
D = [[iB+A, iH], [iH, iB]].
Delta   = Q^2+b*Atilde*A,
Delta_s = Q^2+b*A*Atilde.
```

Its physical propagator block is

```
G_PP = (-iQ B+b Atilde) Delta_s^-1.
```

The complete PS,SP,SS blocks and their right-ordered denominators are in
DERIVATION.md and massive_inverse_recipe.json.gz. Matrix order matters;
M and Mdagger are not assumed to commute. No inverseM, inverseY, inverseg
or artificial1/b is required. The proof applies to arbitrary internalN,
including physical48 and rank-deficient/zero mass. The reference vacuum's
neutral-only mass with general Y126 is included without a numerical spectrum.

Primary proves four universal noncommutative column identities and two
resolvent identities, then evaluates the actual split16-spin SMA operator.
Replay independently uses Weyl/hat blocks and a Schur inverse, with a direct
solve at b=0. Four exact fixtures agree at4,096 complete inverse positions,
including nonnormal complex mass, null masses, strict4D and zero barred
momentum. The primary's spectator identity is removed only for component
comparison, not as a changed particle count or trace normalization.

At u=0 the mixed blocks vanish, the physical block becomes the ordinary
massive Weyl/Majorana inverse and S becomes its old free factor. At M=0 the
full mixed massless SMA inverse is recovered. A one-mass physical block at
nonzero hats has denominatorQ^2+b*m^2; it is not generally obtained by
inserting m into the old Q denominator. The ordinary-massive substitution
changes64 positions in the nonnormal full-hat fixture; falsely commuting
the mass with its adjoint changes48; omitting mixed blocks changes256.
Those controls are insensitive in the displayed normal strict4D fixture,
which is explicitly recorded rather than credited as validation.

Constant family covariance also requires correlated P and S basis rotations:
RP=PL U+PR U*, RS=PR U+PL U*. Both methods check the action congruence and
inverse congruence with M'=U.T M U. The wrong auxiliary rotation changes64
positions. This is a regulator basis change; qS stays0 and the single physical
source pullback is unchanged. These are D inverse blocks; the Gaussian also
has its fixed charge-conjugation factor and no new open-line half.

For physical adjoint masses, Delta and Delta_s are positive Hermitian for
real Euclidean Q>0,b>=0. Their eigenvalues are Q^2+b*m_singular^2. Thus the
formula has no extra finite Euclidean pole. This finite-Clifford statement
is not a proof of analytic continuation to a literal negative hat dimension,
a Lorentzian phase, a regulated trace domain or physical unitarity.
Recipe packed SHA256 `c91290f3d85e1a839d149f31c0f24a3903a46ad2e20164fe6f457231fd288257`,
raw SHA256 `bbca6370fc5c95af1170532e1f9375597dc965411088d7657d13dd53d053c0e8`.

## Stronger auxiliary softness and the actual neutral mass

At barred momentum0 and hat momentumlambda*n, the exact inverse gives
G_PP=0, G_PS=-iH/Q and G_SS=A/Q=A/lambda^2. Exact momentum doubling confirms
the mixed1/lambda and auxiliary1/lambda^2 scaling. Therefore the full generic
massive reference has not earned a uniform massless-Dirac infrared bound.
Absence of a finite-momentum pole cannot justify reusing every old IR proof.
This is an auxiliary regulator diagnostic, not evidence of a new particle
or a physical anomaly.

The model-specific support check prevents the opposite overstatement.
Both qualified YCT routes give the real rank-one PN=e15 e15.T,
M126(v)=c_N sigma PN and M10(v)=0. All twelve actual H generators and their
transposes annihilate PN on both sides. Each route checks12,288 coefficient
positions; replay reconstructs the independently supplied SM-basis span,
so coordinate labels are not silently equated.

For arbitrary general familyY126 the massive inverse correction has neutral
support on both ends, by the exact projector/resolvent identity. All physical,
auxiliary and dual H-background charges annihilate that support. Consequently
H-charge-weighted massive propagator factors equal their massless values:
the neutral A/Q enhancement is absent from pure H-charged segments. The pure
neutral determinant factor is H-background independent in this candidate;
it is not discarded or assigned a phase normalization. This is a bounded
pure-background one-loop corollary, not a general quantum IR/QAP theorem.

A pure broken-generator control retains a neutral-to-H-charged transition:
seed1, two nonzero transition positions and positive normalized H-Casimir
weight1/5. Broken vectors and other interactions can therefore bring mass
dependence back into two-loop threshold graphs. The first V1 support worker
completed with a diagonal neutral self-current control; its source, receipt
and capture are preserved as a weaker control, not labelled a failed run.
V2 adds the stronger off-diagonal charged-state requirement. Neither zero SM
index nor this support identity permits omitting RH neutrinos from full C1.

## Execution and next step

Original inverse primary/replay/gate native0 in83.731423/66.441337/1.604965s
afterimports,43/34/2 memory samples, maxima72,929,280/71,204,864/48,525,312B.
Neutral-support V1/V2 native0 in2.707591/2.738838s,2 samples each, maxima
48,574,464/48,922,624B. These are sampled observations, not continuous peaks.
No worker/controller failed. Sixteen source copies;2089/2097/2111/2121
bindings in initial/validation/neutralV1/neutralV2 preparations. Pre-report
packet1,749,632B. All600s/8GiB/350MiB/16MiB bounds respected. This turn's
fresh YBH E4 is authenticated reuse; historical custody exit2/seven remains
NOTPASS. Before/index/after seals preserve all32971 prior tracked blobs.

This supplies a missing massive bare-action ingredient and separates generic
auxiliary softness from its actual neutral support. It does not calculate a
massive loop or solve the full matter threshold. Next recover the full-D
gauge/auxiliary principal background member needed for the remaining g3
background heat comparison. The old643 four-coordinate witness alone does
not fix all hatted vector/auxiliary continuation. Keep the full inverse and
neutral-support limits available for subsequent massive insertion/domain
checks; do not infer all broken-source products are IR-safe.

Full chiral background/Slavnov restoration, all source products, QAP, measure/
Pfaffian phase, causal/analytic IR domains, a physical subtraction scheme,
complete massive matterC1, E5/A5 and physical GUT remain unresolved. Shared
action, Clifford premises, supplied representation proofs, software and AI
author limit independence. Both scalar failures, quartetFAIL, paused flavor,
blockedHB1/C5, all finite constants and historical evidence remain. No agents,
new branches/worktrees, external actions, publication/push, adoption or
protected promotion occurred. Whole investigation remains ACTIVE/incomplete.
