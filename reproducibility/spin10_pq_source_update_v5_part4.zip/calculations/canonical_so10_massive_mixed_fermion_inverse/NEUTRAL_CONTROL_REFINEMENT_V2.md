# MMI1 neutral-support V2: require a transition to an H-charged state

The V1 structural corollary completed native0 and correctly verified all
H-neutral annihilation conditions. Its first pure-broken control was diagonal:
a neutral self-current, sufficient for its declared surviving mass-coupling
control but not a demonstration of a neutral-to-charged transition. Preserve
its source, manifest, full capture and receipt as COMPLETED with that limit.
No failed run or independent two-loop amplitude is invented.

V2 chooses a plane seed with (1-PN)T PN nonzero, removes its H projection,
and verifies a positive H-Casimir weight of the resulting endpoint. This
strengthens the explanation of why pure-H one-loop mass independence cannot
be carried into two-loop diagrams containing charged broken vectors. The
H-neutral theorem and general inverse are unchanged. Freeze three new source
copies plus all V1 evidence before one small exact worker, with the same
600s/8GiB/350MiB/16MiB limits and no physical inputs or scheme changes.
