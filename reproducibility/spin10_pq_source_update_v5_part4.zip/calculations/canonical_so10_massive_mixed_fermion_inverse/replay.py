"""MMI1 independent block Schur inverse in Weyl/hat components."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');Z=s.zeros(2);I=s.eye(2);pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[block(Z,-s.I*z,s.I*z,Z) for z in pa]+[block(Z,I,I,Z)];g=[s.kronecker_product(z,s.diag(1,-1)) for z in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]];L=s.kronecker_product(s.diag(1,1,0,0),I);R=s.eye(8)-L;fullM=s.Matrix([[1+s.I,2-s.I],[2-s.I,3+2*s.I]]);rankM=s.diag(0,2)
for a in range(6):
 for b in range(a,6):zero(g[a]*g[b]+g[b]*g[a]-2*int(a==b)*s.eye(8))
def operators(mom,M):
 bb=sum(z*z for z in mom[:4]);hh=sum(z*z for z in mom[4:]);qq=bb+hh;B=s.kronecker_product(sum((a*v for a,v in zip(g[:4],mom[:4])),s.zeros(8)),I);H=s.kronecker_product(sum((a*v for a,v in zip(g[4:],mom[4:])),s.zeros(8)),I);A=s.kronecker_product(L,M)+s.kronecker_product(R,M.H);CS=s.kronecker_product(R,M)+s.kronecker_product(L,M.H);Dpp=s.I*B+A;K=s.I*H;Dss=s.I*B;DD=block(Dpp,K,K,Dss)
 if bb:
  Ss=Dss.inv();Schur=tidy(Dpp-K*Ss*K);zero(Schur-(s.I*B*qq/bb+A));PP=Schur.inv();PS=-PP*K*Ss;SP=-Ss*K*PP;SS=Ss+Ss*K*PP*K*Ss;GG=tidy(block(PP,PS,SP,SS))
 else:
  # Literal inverse of [[A,K],[K,0]], with K invertible at Q>0.
  Ki=K.inv();GG=tidy(block(s.zeros(16),Ki,Ki,-Ki*A*Ki))
 zero(DD*GG-s.eye(32));zero(GG*DD-s.eye(32));return DD,GG,B,H,A,CS,qq,bb,hh
fixtures=[];controls={}
for label,mom,M in [('nonnormal_fullhat',[2,1,0,0,1,-1],fullM),('barzero_fullmass',[0,0,0,0,1,-1],fullM),('rankdef_strict4D',[2,1,0,0,0,0],rankM),('masszero_fullhat',[2,1,0,0,1,-1],s.zeros(2))]:
 DD,GG,B,H,A,CS,qq,bb,hh=operators(mom,M);naive=tidy((-s.I*B+CS)*(qq*s.eye(16)+A*CS).inv());wrongorder=tidy((-s.I*qq*B+bb*CS)*(qq**2*s.eye(16)+bb*CS*A).inv());controls[label]={'ordinary_massive_denominator':nz(naive-GG[:16,:16]),'commute_mass_with_adjoint':nz(wrongorder-GG[:16,:16]),'omit_mixed_hat_blocks':nz(s.diag(DD[:16,:16],DD[16:,16:])*GG-s.eye(32))}
 if hh==0:zero(GG[:16,16:]);zero(GG[16:,:16]);zero(GG[16:,16:]+s.I*B/qq);zero(GG[:16,:16]-naive)
 if bb==0:zero(GG[:16,:16]);zero(GG[:16,16:]+s.I*H/qq);zero(GG[16:,:16]+s.I*H/qq);zero(GG[16:,16:]-A/qq)
 if not M.todok():zero(GG+s.I*block(B,H,H,B)/qq)
 fixtures.append({'label':label,'momentum':mom,'mass':enc(M),'inverse':enc(GG)})
# Obtain the family rotations through the original Dirac-to-P/S field map.
U=s.Matrix([[1,s.I],[s.I,1]])/s.sqrt(2);RR=block(L,R,-R,-L);RI=block(L,-R,R,-L);r=s.kronecker_product(RR,I);ri=s.kronecker_product(RI,I);dirac=s.diag(s.kronecker_product(s.eye(8),U),s.kronecker_product(s.eye(8),U.conjugate()));ROT=tidy(ri*dirac*r);RP=s.kronecker_product(L,U)+s.kronecker_product(R,U.conjugate());RS=s.kronecker_product(R,U)+s.kronecker_product(L,U.conjugate());zero(ROT-s.diag(RP,RS));sharp=s.diag(s.kronecker_product(L,U.T)+s.kronecker_product(R,U.H),s.kronecker_product(R,U.T)+s.kronecker_product(L,U.H))
DD,GG,*_=operators([2,1,0,0,1,-1],fullM);Dp,Gp,*_=operators([2,1,0,0,1,-1],U.T*fullM*U);zero(sharp*DD*ROT-Dp);zero(ROT.inv()*GG*sharp.inv()-Gp)
bad=s.diag(RP,RP);bads=s.diag(sharp[:16,:16],sharp[:16,:16]);badcount=nz(bads*DD*bad-Dp);assert badcount>0
_,G1,*_=operators([0,0,0,0,1,-1],fullM);_,G2,*_=operators([0,0,0,0,2,-2],fullM);zero(G2[16:,16:]-G1[16:,16:]/4);zero(G2[:16,16:]-G1[:16,16:]/2)
finish('replay',{'method':'independent_Weyl_hat_block_Schur_inversion_and_barzero_direct_solve','fixtures':fixtures,'controls':controls,'family_congruence_and_inverse_checked':True,'wrong_auxiliary_family_rotation_changed_positions':badcount,'barzero_auxiliary_soft_scaling':'Gss=A/Q; Q=lambda^2; Gps=-iH/Q; Gpp=0','barzero_scaling_verified_by_exact_momentum_doubling':True,'uniform_Dirac_IR_bound_proved':False,'single_physical_source_pullback_preserved':True,'qS':'0 unchanged','source_copies':1,'strict4D_and_massless_limits_checked':True,'witness_spin_dimension':8,'comparison_spin_dimension':8,'spectator_identity_removed_for_comparison_only':False,'mass_blocks_commuted':False,'no_inverse_bar_p2_or_mass_in_final_formula':True},tick)
