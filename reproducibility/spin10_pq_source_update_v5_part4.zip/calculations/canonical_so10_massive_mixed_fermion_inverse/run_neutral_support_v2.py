"""Frozen stronger control; retain the completed V1 scope and evidence."""
from pathlib import Path
from hashlib import sha256
import json,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/massive-mixed-fermion-inverse-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 base=read(HERE/'neutral_support_preparation.json');bind=dict(base['input_sha256'])
 for p,h in bind.items():assert digest(Path(p))==h,p
 assert read(HERE/'neutral_support_capture.json')['exit_code']==0 and read(HERE/'neutral_support_receipt.json')['pure_broken_control_seed']==0
 for n in ['NEUTRAL_CONTROL_REFINEMENT_V2.md','neutral_support_v2.py','run_neutral_support_v2.py']:
  p=HERE/n;b=p.read_bytes();assert b'\r' not in b
  if p.suffix=='.py':compile(b,str(p),'exec')
  with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 for p in HERE.iterdir():
  if p.is_file():bind[str(p.resolve())]=digest(p)
 dump(HERE/'neutral_support_preparation_v2.json',{**base,'schema':'MMI1_NEUTRAL_SUPPORT_PREPARATION_V2','input_sha256':dict(sorted(bind.items())),'V1_completed_with_neutral_self_current_control_preserved':True})
 print('MMI1_NEUTRAL_CONTROL_V2_FROZEN',len(bind),'bindings',flush=True)
 c=capture([sys.executable,'-B',str(HERE/'neutral_support_v2.py')]);dump(HERE/'neutral_support_v2_capture.json',c);dump(CONTROL/'neutral_support_v2_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1;r=rows[0];assert r['elapsed_after_imports']<600 and r['status']=='QUALIFIED_ACTUAL_NEUTRAL_MASS_SUPPORT_AND_H_WEIGHTED_MIXED_INVERSE_COROLLARY' and r['neutral_to_H_charged_transition_positions']>0
 dump(HERE/'neutral_support_v2_receipt.json',r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(HERE/'neutral_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
