"""Freeze the actual-neutral support corollary after the completed massive inverse."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/massive-mixed-fermion-inverse-v1-2026-10-23')
digest=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
base=read(HERE/'preparation.json');bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
assert read(HERE/'validation_receipt.json')['status']=='QUALIFIED_EXACT_CONSTANT_MASS_SMA_MIXED_INVERSE_AND_LIMITS_WITH_AUXILIARY_IR_DIAGNOSTIC'
for n in ['NEUTRAL_SUPPORT_CONTINUATION_V1.md','DERIVATION_NEUTRAL_SUPPORT_V1.md','neutral_support.py','prepare_neutral_support.py','run_neutral_support.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
for p in HERE.iterdir():
 if p.is_file():bind[str(p.resolve())]=digest(p)
for role in ['primary','replay']:
 p=CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz');bind[str(p.resolve())]=digest(p)
with (HERE/'neutral_support_preparation.json').open('xb') as f:f.write((json.dumps({**base,'schema':'MMI1_NEUTRAL_SUPPORT_PREPARATION','input_sha256':dict(sorted(bind.items())),'original_massive_inverse_receipt_authenticated':True},sort_keys=True,indent=2)+'\n').encode())
print('MMI1_NEUTRAL_SUPPORT_FROZEN',len(bind),'bindings',flush=True)
