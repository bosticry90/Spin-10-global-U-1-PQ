# Complete selected source cycles and their vanishing limit

Qualification requires actual receipts. Source differentials are taken
before J0. Rho is constant; all other ordinary means vanish except the
single external physical P in Gamma_rhoKP P. The classical E_P linear
coefficient at the source-free PP target is kinetic in the unshifted
intrinsic grade1 sector. Its fixed external momentum does not undo a
vanishing source coefficient. The separately translated mass class is
outside this argument.

## Exhaustive ports

SMA has one physical source vertex K_P i g C(PL T-PR T^T)P and no sterile
vertex. Its fluctuation Hessian couples a ghost and physical fermion.
The other external P must occur at a matter vertex. One intrinsic scalar
mixing occurs either at rho-a-x or at N0-L-x with rho-a-B/L. Exactly one
scalar Yukawa vertex is then necessary to close its scalar port. No
ordinary gauge endpoint can close that single scalar port. The free
supports BB,BL,LB,xx,Ca,aC,PP,PS,SP,SS are inherited. All actual vertices
in this sector act on P, so the only fermion edge is the full SMA PP block
-i bar_slash(R)/R; mixed sterile edges have no second endpoint. Internal
hats remain in R=k_D² and the d=4-2epsilon Gaussian measure.

The type enumeration records the rho direct and the N0 mixed cycles in
both orientations. Each vertex has a required external label or positive
intrinsic degree, so at most four vertices occur. It also enumerates the
JB-BC source target with no ordinary P: at grade1 it has an unmatched
scalar port. Two intrinsic insertions could close it but are excluded
from this grade, not declared zero in the full theory.

EDS/FIS give the actual equality Srho=J G0 N0, for all45 ghost and328
scalar columns. The two terms have different heat counts. At constant
rho the ghost and scalar momenta coincide. Combined ending and source
loop therefore retain

    L_mu=N int E_Q²(1-E_Q)E_R (k-p)_mu/(Q²R),
    Q=k²,R=(k-p)²,q=p_E²>0,c=2t,
    N=exp(gamma_E epsilon)*(mu_R²)^epsilon.

The physical barred vector is understood. Overall charge/source phases
multiply a finite polynomial matrix, irrelevant to the zero limit. This
argument does not equate a source vector to its mass-Yukawa image.

## Two actual integral routes

Strip the common1/(16pi²). Gaussian integration gives L_mu=-p_mu N c I.
Let e=epsilon,u=A/(A+B),Delta=q u(1-u). Direct Schwinger parameters for
Q^-2R^-1 give

    N c I = N int_0^1 du [u² Delta^(-1-e)
       (Gamma(1+e,z2)-Gamma(1+e,z3))
       -c u Delta^(-e)(2Gamma(e,z2)-3Gamma(e,z3))],
    z_lambda=Delta c max(lambda/u,1/(1-u)).

Keep these differences combined. At e=0 Gamma(0,z)=E1(z). Do not
integrate the individual critically singular lambda2/lambda3 terms.

Alternatively use E_Q²(1-E_Q)=Q int_(2c)^(3c) dh exp(-hQ), cancel one Q,
and integrate the new positive Schwinger representation:

    I=int_2^3 d lambda int_0^1 du u Delta^(-e) Gamma(e,z_lambda).

This representation is positive. For fixed u, lambda switches to a
constant lower limit at lambda0=u/(1-u). The independent antiderivative
on the variable part is

    F(lambda)=lambda Gamma(e,a lambda)-Gamma(e+1,a lambda)/a,
    a=cq(1-u),   F'=Gamma(e,a lambda).

Below u=2/3 use F(3)-F(2); above u=3/4 use Gamma(e,cqu); in between use
F(lambda0)-F(2)+(3-lambda0)Gamma(e,cqu). This is the replay formula.

## Uniform bound, including e approaching0

The positive T representation is
I=int_2^3 d lambda int_0^1 du u int_(c max(lambda/u,1/(1-u)))^infinity
T^(-1+e) exp[-Delta T] dT.
For0<c<=1 and0<=e<=1/4 split T at1. The lower portion is bounded by
|log c|, since its lower endpoint is >=c and T^e<=1. The upper portion
is bounded by Gamma(1/4) Delta^(-1/4), since T^e<=T^(1/4) there.
Integrating u gives the explicit finite estimate

    0<=N c I<=N c [|log c|/2
       +Gamma(1/4) q^(-1/4) Beta(7/4,3/4)].

N is bounded on this e interval for fixed positive scale. Hence the
source coefficient tends to0 uniformly as c->0, even jointly with e->0.
Multiplication by the classical fixed-momentum E_P is harmless on compact
nonexceptional Euclidean momentum sets. This is stronger than the earlier
FIS/FIM isolated scalar kernels' path-dependent limits and does not change
their values. At unfiltered heat1 the complete source ending cancels
algebraically before any singular individual integration, also giving0.

The actual finite source term need not be zero. Its scalar norm factor is
positive for c,q>0 and generic nonzero color coefficients. Zero limit is
not absence of the connected product. No claim at q=0,constant-vacuum
domain,Lorentzian boundary,independent repeated insertions,full hatted
insertion,measure/phase,QAP or E5/A5 follows from this selected theorem.
