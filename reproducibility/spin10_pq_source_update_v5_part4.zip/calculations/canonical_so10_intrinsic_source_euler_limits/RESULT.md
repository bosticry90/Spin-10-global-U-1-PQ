# Intrinsic physical source-Euler coefficient has a uniform zero limit

October25,2026. PROGRESS, base31441f4ce1abdaef5137d9a9c241fd4631b6242c.
The selected rho-KP-P connected source coefficient and its fixed-momentum
physical source-Euler contribution tend to0 uniformly for epsilon in
[0,1/4] as the heat length tends to0. The selected rho-JB grade1 component
is excluded by complete interaction support. Neither conclusion discards
a finite-regulator connected product or qualifies the full Ward group.
State113/34of39 unchanged; E5/A5 open, custody exit2/sevenNOTPASS.

Original unshifted SMA/CSW/EDS,constant firstprobe,A0,nonexceptional
Euclidean p²=q>0,first intrinsic coefficient-dimension-one GF/reference
grade only. External physical P and its single Nambu source are retained;
the general scalar/Yukawa/color maps are not fitted or truncated. This
does not cover translated scalar/mass classes,full massive propagators,
physical vacuum or chiral measure/phase/QAP.

## Actual connected class and its kernel

The physical source vertex is K_P-C-P. One external ordinary P requires
one scalar-Yukawa endpoint. The first intrinsic insertion is either the
rho-a-x term or N0-L-x with rho-a-B/L. Four vertices suffice; no unlabeled
grade0 vertex remains outside the reference. The complete type scan has
14 ordered trace cycles, all with one Yukawa and no ordinary gauge-P
endpoint. A lone scalar port forbids such a gauge alternative. The scan
also finds no rho-JB grade1 cycle at zero ordinary means: its BC vertex
cannot close the single intrinsic scalar port. Grade2 is not excluded.

Actual EDS matrices recheck Srho=J G0 N0 over all45 ghost/328 scalar
coordinates. Retain both heat paths. The only internal fermion edge has
physical endpoints, so it is the full SMA PP inverse
-i bar_slash(k-p)/R, including the D-dimensional denominator. Sterile
mixed propagators have no second vertex here. This is an inherited SMA
inverse statement, not a new four-matrix representation of BMHV.

The remaining vector kernel, stripping1/(16pi²), is

    L_mu=N int E_Q²(1-E_Q)E_R (k-p)_mu/(Q²R),
    Q=k²,R=(k-p)²,c=2t,N=exp(gamma_E e)*(mu_R²)^e.

Both chiralities and all model-specific source/color phases multiply
this common kernel by fixed finite polynomial matrices. No complete
finite color table or sign of that matrix is claimed. A uniform zero of
the entire kernel suffices for all such coefficients and their zeros.

Primary combined Gaussian parameters and replay positive heat-length
integration independently compute L_mu=-p_mu N c I. The latter gives

    I=int_2^3 d lambda int_0^1 du u int_L^infinity
       T^(-1+e) exp[-q u(1-u)T] dT,
    L=c max(lambda/u,1/(1-u)).

It is positive for c,q>0. The universal finite-regulator kernel therefore
is not zero. In contrast, the complete unfiltered ending cancels before
integrating its singular individual paths. A bare zero alone would not
have justified this limit claim.

## Uniform result, including joint regulator paths

For0<c<=1 and0<=e<=1/4, splitting the positive T integral at1 gives

    0<=N c I<=N c[|log c|/2
       +Gamma(1/4)q^(-1/4)Beta(7/4,3/4)].

For fixed positive scale, N is bounded on that epsilon interval. Thus
L_mu tends to0 even when c and epsilon approach0 together. Multiplication
by the classical fixed-momentum E_P remains bounded on compact
nonexceptional Euclidean momentum sets. This qualifies the stated
physical source-Euler zero limit. It does not extend to q=0 or arbitrary
momentum-dependent sources/probes without another domain argument.

This differs from the isolated FIS source and FIM ordinary scalar
kernels, whose c^epsilon factors gave path-dependent nonzero limits.
Those older values remain unchanged. Nor does this prove anything about
the separately required hatted insertion merely because the PP source
kernel has a uniform zero.

## Preserved failure and validation

The original primary and replay completed but their finite answers
disagreed; the verifier correctly FAILED. The replay had reversed the
constant and variable lambda intervals for2<lambda0=u/(1-u)<3. V2 uses
(lambda0-2)Gamma(e,cqu)+F(3)-F(lambda0), with the unchanged gamma
antiderivative. CORRECTION_V2.md prospectively corrects that branch in
the frozen PROOF/native sources. All original outputs, sources/copies,
captures, failed verification and controller evidence remain intact.
Only the replay and verifier were re-executed. Inputs, tolerances and
resource limits were unchanged; the original primary was reused.

Completed primary31.3162013s,original replay27.8970368s,corrected replay
27.4031082s and verifierV2 .0198686s after imports. Their17/15/15/1 samples
reached50,241,536/50,081,792/50,536,448/393,216B. The failed verifier's
single sample was397,312B. These are sampled observations,not continuous
peaks. Worker180s/verifier120s,8GiBsampled/350MiBfloor/8MiB limits held.

Six finite cases and three joint paths give24 numerical comparisons,
60digits/50stored/1e-30 scaled gate; stored maximum discrepancy0 is
numerical corroboration,not exact integration. The wrong extra heat
endpoint changes all six finite cases. The analytic positive integral
and uniform bound supply the limit theorem; finite samples alone do not.
Preparation/validation/continuation/V2-validation bindings36/44/55/59.
Validation receipt SHA256
f83af1792cd2db45664d4cba8b728f22686b23670f3892514929215a92f61172.

Delegated E4 native0,step exits[0,0,0,0,0,2]; historical custody retains
seven unresolved references and no overall PASS. Complete captures,
readiness and preservation seals are also retained under the external
intrinsic-source-euler-limits-v1-2026-10-25 directory. Shared action,
source/Clifford/reference assumptions,software and AI author remain;
no external scientific validation,proof-assistant certificate or new
physical evidence is claimed.

## Next discriminating step

Calculate the actual first-intrinsic-grade hatted insertion with external
rhoPP. Retain E_C/E_S legs, mixed P/S propagation and all heat factors.
Its prospective numerator contains paired internal hats, suggesting an
epsilon-suppressed finite heat difference. That is not yet a qualified
calculation. Audit its complete source/field support and derive its
integral before comparing with the corrected ordinary/source/root group.
The root's strict4D result must not be silently promoted to a full
dimensional joint-limit or renormalized restoration theorem.
