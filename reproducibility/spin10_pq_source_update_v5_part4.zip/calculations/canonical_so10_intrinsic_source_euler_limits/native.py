from pathlib import Path
from hashlib import sha256
from collections import Counter
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('ISE1_PEER_DENIED')
sys.addaudithook(guard);d=load(O/(role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);G=dec(d['G0']);N=dec(d['N0']);assert len(d['hat_vertices'])==3 and all(all(p in ['P','S','c'] for p,j in z['ports']) for z in d['hat_vertices'])
for z in d['rho']:assert not cl(dec(z['direct'])-dec(z['J'])*G*N).todok()
# Type traces for all source Hessian cycles: each orientation is retained.
edges={'B':['B','L'],'L':['B'],'x':['x'],'C':['a'],'a':['C'],'f':['f']};states=list(edges);vs=[]
def v(a,b,name,pp,rh,nn,jj):vs.extend([(a,b,name,pp,rh,nn,jj),(b,a,name,pp,rh,nn,jj)])
v('B','f','gP',1,0,0,0);v('x','f','yP',1,0,0,0);v('a','B','rho_aB',0,1,0,0);v('a','L','rho_aL',0,1,0,0);v('a','x','rho_ax',0,1,1,0);v('L','x','N0',0,0,1,0)
def walks(source,target):
 vv=vs+[(source[0],source[1],source[2],0,0,0,1),(source[1],source[0],source[2],0,0,0,1)];out=[]
 for m in range(1,6):
  for start in states:
   paths=[(start,(0,0,0,0),())]
   for step in range(m):
    nxt=[]
    for cur,deg,word in paths:
     for mid in edges[cur]:
      for a,b,name,*newdeg in vv:
       dd=tuple(deg[i]+newdeg[i] for i in range(4))
       if a==mid and all(dd[i]<=target[i] for i in range(4)):nxt.append((b,dd,word+(name,)))
    paths=nxt
   out.extend({'m':m,'word':ww} for cur,dd,ww in paths if cur==start and dd==target)
 return out
kp=walks(('C','f','KP_CP'),(1,1,1,1));jb=walks(('B','C','JB_BC'),(0,1,1,1));assert kp and not jb and max(x['m'] for x in kp)<=4 and all('yP' in x['word'] and 'gP' not in x['word'] for x in kp)
# Split scalar and vector Gaussian integrals, avoiding separate IR divergences.
mp.mp.dps=60;fmt=lambda z:mp.nstr(z,50)
def calc(e,z,q,mu,wrong=False):
 c=z/q;Nn=mp.exp(mp.euler*e)*mu**e;hi=mp.mpf(4 if wrong else 3);cuts=[0,mp.mpf(2)/3,hi/(hi+1),1]
 def GG(a,x):return mp.e1(x) if not a else mp.gammainc(a,x,mp.inf)
 def primary(u):
  D=q*u*(1-u);z2=D*c*max(2/u,1/(1-u));z3=D*c*max(hi/u,1/(1-u));return u*u*D**(-1-e)*(GG(1+e,z2)-GG(1+e,z3))-c*u*D**(-e)*(2*GG(e,z2)-hi*GG(e,z3))
 def replay(u):
  D=q*u*(1-u);a=z*(1-u);l0=u/(1-u)
  def F(l):return l*GG(e,a*l)-GG(1+e,a*l)/a
  if l0<=2:ans=F(hi)-F(2)
  elif l0>=hi:ans=(hi-2)*GG(e,z*u)
  else:ans=F(l0)-F(2)+(hi-l0)*GG(e,z*u)
  return c*u*D**(-e)*ans
 ans=Nn*mp.quad(primary if role=='primary' else replay,cuts);bound=Nn*c*(abs(mp.log(c))/2+mp.gamma(mp.mpf(1)/4)*q**(-mp.mpf(1)/4)*mp.beta(mp.mpf(7)/4,mp.mpf(3)/4));return ans,bound
rows=[]
for ee in ['0','0.2']:
 for zz,qq in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  e,z,q=map(mp.mpf,[ee,zz,qq]);ans,bound=calc(e,z,q,mp.mpf('1.5'));bad,_=calc(e,z,q,mp.mpf('1.5'),True);assert 0<ans<=bound and abs(bad-ans)>mp.mpf('1e-40');rows.append({'epsilon':ee,'cq':zz,'q':qq,'positive_scalar_factor_minus_L_over_p':fmt(ans),'uniform_bound':fmt(bound),'wrong_extra_heat_endpoint':fmt(bad)})
 print('STAGE ISE1 '+role+' epsilon '+ee+' complete',flush=True)
paths=[]
for ee in ['0.1','0.05','0.025']:
 e=mp.mpf(ee);z=mp.exp(-1/e);ans,bound=calc(e,z,mp.mpf(2),mp.mpf('1.5'));assert 0<ans<=bound;paths.append({'epsilon':ee,'a':'1','cq':fmt(z),'scalar_factor':fmt(ans),'uniform_bound':fmt(bound),'joint_limit':'0'})
out={'schema':'ISE1_INTRINSIC_SOURCE_EULER_LIMIT','role':role,'source_KP_complete_typed_cycles':kp,'source_JB_grade1_cycles':jb,'actual_full_ending_identity_checked':True,'only_full_SMA_PP_block_between_physical_vertices':True,'uniform_epsilon_interval':['0','1/4'],'kernel_limit':'0','unfiltered_complete_ending':'0','source_Euler_limit_at_fixed_nonexceptional_p':'0','rows':rows,'paths':paths,'sign_of_finite_source_matrix_not_claimed':True,'complete_hatted_Ward_group_or_QAP':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
