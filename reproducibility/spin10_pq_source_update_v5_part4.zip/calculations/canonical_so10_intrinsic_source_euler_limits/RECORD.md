# ISE1: intrinsic physical source-Euler limit

Freeze before computation, October25,2026, base31441f4ce1abdaef5137d9a9c241fd4631b6242c,
35917oldblobs. Question: does the actual rho-KP-P one-loop coefficient leave
a finite first-intrinsic-grade contribution to the physical source Euler
term? Also check rho-JB grade1 at zero ordinary mean fields. This follows
IRR1 without assuming its root supplies the missing source answer.

Original unshifted SMA/CSW/EDS,constant firstprobe,A0,nonexceptional Euclidean
q=p²>0,physical external P and its sole Nambu source K_P. All scalar/color
channels and arbitrary family Yukawas remain. No translated scalar mass,
full massive inverse, physical benchmark, scheme, phase, measure or QAP.

Derive complete typed cycles from actual source vertices before J0.
Gamma_rhoKP P uses K_P-C-P, one scalar Yukawa-P endpoint and the complete
rho-a-x ending (direct Srho versus mixed J G0 N0). One intrinsic insertion
is allowed; a gauge-P endpoint cannot terminate the single scalar port.
Other source degree2 terms vanish only after the appropriate derivatives.
For Gamma_rhoJB no ordinary fields, its BC source vertex cannot close a
single intrinsic scalar port. Enumerate the full declared support with
normal type/degree bounds, not a desired zero coefficient.

The surviving source-K kernel has one physical propagator
-i bar_slash(k-p)/R with its appropriate source routing/sign; its vanishing
bound is insensitive to an overall convention sign. Keep the full SMA
P/S inverse until only its PP block is selected; no internal hat denominator
is omitted. The two ordered ending paths produce
E_Q²(1-E_Q)E_R bar_slash(k-p)/(Q²R), not a naked bare zero.
Do not individually integrate its critically IR-singular separated paths.

Primary: paired Gaussian Schwinger parameters and a combined upper-gamma
formula. Replay: integrate the positive heat length first with an exact
gamma antiderivative. Check6 finite cases and3 joint paths,60digits with
50stored and1e-30 scaled gate. A wrong extra heat endpoint is a sensitive
finite control. Derive a uniform c(1+|log c|) bound for0<=epsilon<=1/4,
fixed positive q and scale,0<c<=1. No isolated1/epsilon bound may replace
the uniform estimate. Keep FIS/FIM isolated nonunique limits distinct.

Expected dispositions: qualified vanishing source-Euler coefficient;
nonzero finite remainder; underdefined source domain; calculation failure
or incomplete resources. A sign/routing failure remains preserved. Actual
source colors need not be expanded if the entire universal kernel tends
to0 uniformly and all polynomial color factors are finite and fixed.
This does not calculate the separate hatted insertion or full Ward group.

Two sequential workers180s after imports,verifier120s,8GiBsampled,
350MiBlaunchfloor,8MiBpacket. Freeze inputs, code/copies, dependencies and
proof before execution. Preserve failed/unfinished runs and historical
policy. Noagents/branches/worktrees/push/outreach/publication/foundation/
scheme/benchmark/flavor/HB1C5/promotion. State113/34of39,E5A5open,custody
exit2sevenNOTPASS unchanged. Shared action,source charts,software and
AI author limit independence. No scientific acceptance inferred.
