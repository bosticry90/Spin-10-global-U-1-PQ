from pathlib import Path
from hashlib import sha256
import json,gzip,ast,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-source-euler-limits-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
b=dict(read(O/'validation_preparation.json')['input_sha256'])
for name in ['CORRECTION_V2.md','native_v2.py','verify_v2.py','run_v2.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(p)
for name in ['validation_preparation.json','verify_capture.json','controller_failure.json']:b[str(O/name)]=H(O/name)
dump(O/'continuation_preparation.json',{'input_sha256':b,'replay_only_correction_original_primary_reused':True,'scientific_requirements_unchanged':True})
stage='replay_v2'
try:
 for role in ['replay_v2','verify_v2']:
  stage=role
  if role=='verify_v2':
   for name in ['continuation_preparation.json','replay_v2_capture.json','replay_v2_result.json','replay_v2_tables.json.gz']:b[str(O/name)]=H(O/name)
   dump(O/'validation_v2_preparation.json',{'input_sha256':b})
  z=capture([sys.executable,'-B',str(O/('native_v2.py' if role=='replay_v2' else'verify_v2.py'))]+(['replay'] if role=='replay_v2' else[]));dump(O/(role+'_capture.json'),z);dump(C/(role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:]) for x in z['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='replay_v2' else 120)
  if role=='replay_v2':
   blob=(O/'replay_v2_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==rr[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rr[0]['raw_sha256']
  dump(O/('replay_v2_result.json' if role=='replay_v2' else'validation_receipt_v2.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<8*1024**2;print('COMPLETED_ISE1',role,rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'controller_failure_v2.json',{'execution_state':'FAILED','stage':stage,'traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
