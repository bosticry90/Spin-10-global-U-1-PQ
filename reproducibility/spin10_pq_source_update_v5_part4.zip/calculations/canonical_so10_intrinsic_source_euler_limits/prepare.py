from pathlib import Path
from hashlib import sha256
import json,gzip,ast,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='31441f4ce1abdaef5137d9a9c241fd4631b6242c';b={};I=O.parent/'canonical_so10_intrinsic_regulator_root_v2';P=O.parent/'canonical_so10_chiral_probe_support';im=read(I/'review_preparation.json')['input_sha256'];pm=read(P/'preparation.json')['input_sha256']
for role in ['primary','replay']:
 ip=I/(role+'_inputs.json.gz');hp=P/(role+'_inputs.json.gz');assert H(ip)==im[str(ip)] and H(hp)==pm[str(hp)];d=load(ip)['ending'];hh=load(hp);out={k:d[k] for k in ['G0','N0','rho']};out['hat_vertices']=hh['hat_vertices'];dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for p in [ip,hp,dst]:b[str(p)]=H(p)
for folder,names in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_intrinsic_regulator_root_v2',['RESULT.md','PROOF.md','validation_receipt.json','review_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json']),('canonical_so10_chiral_probe_support',['DERIVATION.md','validation_receipt.json'])]:
 for name in names:p=O.parent/folder/name;b[str(p)]=H(p)
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V610.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/name;b[str(p)]=H(p)
for name in ['RECORD.md','PROOF.md','native.py','prepare.py','verify.py','run.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(p)
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'worker_seconds_after_imports':180,'verifier_seconds_after_imports':120,'packet_cap':8*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_ISE1',len(b),flush=True)
