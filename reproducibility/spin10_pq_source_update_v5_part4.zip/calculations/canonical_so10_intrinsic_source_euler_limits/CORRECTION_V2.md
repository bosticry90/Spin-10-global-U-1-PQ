# ISE1 V2 replay interval correction

The original completed workers disagree, and the first verifier correctly
FAILED. All sources/copies, outputs, captures, preparation and controller
failure remain unchanged. No scientific qualification came from that run.

In the replay lower limit max(lambda/u,1/(1-u)), lambda0=u/(1-u).
For lambda BELOW lambda0 the lower limit is CONSTANT, and ABOVE it the
limit varies with lambda. The original middle branch reversed those
intervals. Its antiderivative itself is correct. The corrected branch is

    (lambda0-2)Gamma(e,cqu)+F(3)-F(lambda0), 2<lambda0<3.

This prospectively corrects that branch in PROOF.md and native.py without
changing their frozen historical bytes. No other equation or physical
input changes. The positive integral and its uniform bound are unchanged.
V2 re-executes only replay, then compares with the original primary under
the same60digit/1e-30 requirements. No need to rerun an unchanged primary.
Same180s/120s,8GiBsampled/350MiBfloor/8MiB limits. Outputs and source copies
are newly named. The old mismatch remains a mathematical implementation
failure, not a failed Spin(10) theory or a relaxed verification requirement.
