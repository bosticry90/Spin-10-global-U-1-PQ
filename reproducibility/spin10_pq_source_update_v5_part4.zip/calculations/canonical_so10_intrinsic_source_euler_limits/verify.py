from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']];assert a['source_KP_complete_typed_cycles']==b['source_KP_complete_typed_cycles'] and a['source_JB_grade1_cycles']==b['source_JB_grade1_cycles']==[] and len(a['rows'])==len(b['rows'])==6 and len(a['paths'])==len(b['paths'])==3
mp.mp.dps=60;worst=mp.mpf(0);comp=0;controls=0
for aa,bb in zip(a['rows'],b['rows']):
 for k in ['epsilon','cq','q']:assert aa[k]==bb[k]
 for k in ['positive_scalar_factor_minus_L_over_p','uniform_bound','wrong_extra_heat_endpoint']:
  x,y=mp.mpf(aa[k]),mp.mpf(bb[k]);err=abs(x-y)/(1+abs(x)+abs(y));assert err<mp.mpf('1e-30');worst=max(worst,err);comp+=1
 assert 0<mp.mpf(aa['positive_scalar_factor_minus_L_over_p'])<=mp.mpf(aa['uniform_bound']);controls+=mp.mpf(aa['wrong_extra_heat_endpoint'])!=mp.mpf(aa['positive_scalar_factor_minus_L_over_p'])
for aa,bb in zip(a['paths'],b['paths']):
 for k in ['epsilon','a','cq','joint_limit']:assert aa[k]==bb[k]
 for k in ['scalar_factor','uniform_bound']:
  x,y=mp.mpf(aa[k]),mp.mpf(bb[k]);err=abs(x-y)/(1+abs(x)+abs(y));assert err<mp.mpf('1e-30');worst=max(worst,err);comp+=1
out={'schema':'ISE1_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'combined_Gaussian_and_positive_heat_length_integrals_agree':True,'finite_cases':6,'joint_paths':3,'numeric_comparisons':comp,'maximum_scaled_discrepancy':mp.nstr(worst,40),'wrong_heat_endpoint_sensitive_cases':controls,'typed_source_cycles':len(a['source_KP_complete_typed_cycles']),'rho_JB_grade1_structurally_excluded':True,'rho_KP_P_and_its_fixed_momentum_Euler_limit':'0_UNIFORM_EPSILON_0_TO_1over4','finite_connected_kernel_zero':False,'complete_hatted_Ward_group_QAP_measure_or_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
