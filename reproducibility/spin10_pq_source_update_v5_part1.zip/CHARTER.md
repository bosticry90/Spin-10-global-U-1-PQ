# ToE-Next Charter

## Objective

Construct the most coherent and complete unification obtainable from established physics, existing serious unification frameworks, surviving project results, and promote new physics only where evidence or mathematical consistency requires it.

This private, human-directed project has two equally important research objectives:

1. Investigate whether the selected Spin(10) × global U(1)PQ construction is mathematically consistent, physically viable, predictive, and able to recover established physics.
2. Determine what AI-executed scientific research can reliably accomplish under human direction when the director has limited formal mathematics and physics expertise, including where it fails or cannot justify a conclusion.

The director's scientific education is a third, complementary activity: concurrent, voluntary and nonblocking. This is a standing requirement of the experiment, not a temporary accommodation. The three tracks may progress at different rates.

The central physical question is:

> How much accepted physics can be recovered from progressively fewer independent assumptions?

Originality is not an acceptance criterion. Provenance, physical adequacy, mathematical consistency, and explanatory compression are.

Genuine grand unification, equivalence to an established model, useful computational contributions, underdetermination and refutation are all permissible outcomes. Neither the physical model's success nor AI's reliability is presumed.

## Three parallel tracks

**Track A — Scientific investigation.** Investigate the actual physics using explicit assumptions, credible literature, defined success/failure/inconclusive outcomes, appropriate verification, resource limits and scientific stopping rules. Scientific authority depends on evidence, never on AI confidence or the director's proficiency. Missing scientific justification, an invalid assumption or inadequate verification still blocks the affected calculation or claim where its contract requires it.

**Track B — AI scientific-capability evaluation.** Evaluate demonstrated ability to find established physics and literature, formulate meaningful problems, justify methods, derive and reproduce results, consider alternatives, detect mistakes and contradictions, distinguish consistency from viability, assess novelty or redundancy, recognize insufficient evidence, and recommend stopping or changing direction. Record what AI actually accomplished, the reference standard, errors and limitations in existing calculation/result/review records and epistemic mechanisms where useful. Failures and unreliable or inconclusive performance are legitimate outcomes. Fluent explanations, calculation volume, apparent sophistication and agreement among AI implementations are not capability measures by themselves. Do not create a separate benchmarking platform, score or mandatory sidecar for each calculation.

**Track C — Director's scientific education.** For consequential decisions, explain in plain language first the question, significance, established physics, selected approach, alternatives, limits and success/failure/uncertainty criteria; add technical detail when useful. Offer lessons, worked examples or conceptual assessments when requested. Never require their completion, a proficiency examination, compulsory teach-back, independent derivation or graduate-level understanding before otherwise justified and authorized research continues. The director may deepen understanding at a different pace without pausing active work.

The director retains control over objectives, priorities, foundational assumptions, consequential model changes, acceptance, publication and external actions. Agents investigate, derive, implement, test, challenge and recommend within the authorized scope. Explain options, evidence, risks and uncertainty before consequential decisions; obtain authorization where existing policy requires it. Authorization to explore does not supply missing scientific evidence or justify promotion. Personal lack of understanding does not create an additional authorization gate.

| Illustrative situation | Required response |
| --- | --- |
| The director cannot explain a scalar 54 rather than a 16. | Continue an already authorized, scientifically justified calculation; make accessible education available without a learning prerequisite. |
| AI proposes a scalar representation without defensible physical justification. | Identify the gap and keep the proposal exploratory, if exploration is authorized. Neither authorization nor consistent-looking mathematics justifies foundational adoption or scientific promotion; do not perform work whose scientific prerequisites are missing. |
| Two AI calculations share an unverified physical assumption and agree. | Credit only the errors their comparison can test. The assumption and physical relevance remain unverified; agreement is not independent physical validation. |

This model operates within the existing [solo-project review policy](docs/SOLO_REVIEW_POLICY_V1.md). Education and AI evaluation introduce no outreach, specialist recruitment, mandatory public review or external personal participation. Solo review does not establish the confidence of genuinely independent expert reproduction. Publicity, social-media credibility and online approval do not determine research priorities; publication and external engagement remain separate director-controlled decisions.

## Scientific scaffold

Research is organized as a dependency structure:

```text
empirical obligations
→ established theories
→ candidate unifications
→ recovery maps and seams
→ operational observables
→ verification
→ assumption compression
```

The layers mean:

1. **Empirical obligations** — observations and tested regularities that a viable construction must reproduce.
2. **Established theories** — the accepted descriptions that work in specified domains, including their known limits.
3. **Candidate unifications** — serious broader frameworks assessed without presuming adoption.
4. **Recovery maps and seams** — explicit derivations or compatibility relations connecting broader and lower-level descriptions.
5. **Operational observables** — the route from formal structure to quantities that can be measured or constrained.
6. **Verification** — checks scaled to the strength, consequence, and failure modes of a claim.
7. **Assumption compression** — determining whether several independent assumptions can be replaced by fewer justified principles.

This scaffold begins as an intellectual and dependency structure. It does not justify pre-creating software or document hierarchies. A new directory, abstraction, dependency, or data surface must be earned by active scientific work.

## Scientific commitments

- Established physics is preferred to reinvention when it already supplies the needed result.
- Established physics is cited and used under its conventional identity.
- A successful effective theory in its tested domain need not be a final fundamental theory.
- Scientifically motivated new-physics hypotheses may be generated, explored, and falsified when useful. They become accepted components only after evidence, consistency, recovery, and comparator tests justify promotion.
- No mechanism is promoted merely because it is mathematically attractive or computationally tractable.
- A failed, blocked, or underdetermined calculation is a scientific result when its scope and assumptions are explicit.
- Open questions are not automatically active research seams.
- A translation map earns authority only for the structures it is proven to preserve. Rank, invertibility and reconstruction do not by themselves certify a faithful representation or recovery map. The structure-preserving map contract in the computational-authority policy applies before such a map transfers authority.

## AI and computational science operating model

ToE-Next is AI-assisted and computationally capable. AI may act in distinct roles:

- **Proposer:** generate hypotheses, mathematical structures, and discriminating questions.
- **Implementer:** translate a frozen claim into symbolic, numerical, logical, or formal work.
- **Comparator:** determine whether a result is already known and identify its provenance and nearest established analogues.
- **Adversary:** search for hidden assumptions, counterexamples, sign or convention errors, failed limits, and alternative explanations.
- **Integrator:** interpret what a result changes in the larger scaffold.

These roles may inform one another, but an AI-generated statement is not scientific authority merely because it is fluent, reproducible by the same model, or supported by many generated artifacts.

The normal workflow is:

```text
scientific question
→ minimal claim
→ frozen assumptions
→ smallest competent toolset
→ independent attack when warranted
→ physical interpretation
→ bounded authority
```

Tools are selected by the claim. Running more engines does not automatically increase confidence, and the complete available stack is never run merely for procedural completeness.

## Scientific foundations and priorities

Before a substantial new calculation or consequential change of direction, identify the unresolved question, its relationship to physical viability or the bounded AI-capability objective, available evidence, consequences of plausible outcomes, and the least expensive scientifically competent resolution. Check whether existing literature, a simpler test or a bounded calculation could make the larger computation unnecessary. Unfinished implementation tasks alone do not determine priorities. Recommend continuing, revising, deferring, simplifying or rejecting a direction when warranted; do not indefinitely repair a favored model to evade a negative result, or discard valid work because one normalization, implementation or benchmark fails.

Use the following twelve scientific-foundations concerns proportionally in the existing record, drawing on cited evidence rather than requiring twelve essays or a new artifact for each calculation:

| Concerns to consider | Decision-relevant inquiry |
| --- | --- |
| 1. Established consensus; 2. Precise problem | What is established, in which domain, and what exact uncertainty is being tested? |
| 3. Historical origin; 4. Why this form | Where did the problem arise, and what mathematical or physical reasons give it this structure? |
| 5. Why unresolved; 6. Significance | Which obstacles remain, and why does resolving them matter? |
| 7. Implications; 8. Acceptance, rejection and validation | What would plausible outcomes change, and what evidence would establish success, failure or inconclusiveness? |
| 9. Established and contemporary candidates; 10. Their historical development | What alternatives exist, what has already been tried, and what lessons survive? |
| 11. Structural justification; 12. Weaknesses, failures, exclusions and assumptions | Why are these mathematical and physical choices justified, and where could they fail or remain unsupported? |

Retrieve and reuse existing reviews, literature and calculation records; investigate gaps further only when they can change a scientific decision. This is a scientific reasoning requirement, not an educational assessment of the director or an additional documentation gate. A consequential missing justification remains explicit and constrains the affected claim or work.

For current work, this three-track scope updates the physics-only purpose wording in the [computational-authority policy](tools/readiness/COMPUTATIONAL_AUTHORITY_POLICY.md), including its task header and active-seam description. A bounded AI-capability investigation or necessary methodology task states the question it serves and why no physics blocker is removed, rather than inventing one. Reuse the existing header/record; no separate framework is required. This clarification does not activate a physics seam or relax technical prerequisites, frozen acceptance conditions, resource limits or authorization requirements. Bound historical policy and evidence bytes remain unchanged.

## Calculation record

Every calculation begins with one compact record containing these twelve fields:

1. **Scientific question** — the decision the work is intended to inform.
2. **Claim under test** — the smallest exact statement being evaluated.
3. **Scope and authority ceiling** — what the result can and cannot establish.
4. **Frozen inputs and assumptions** — physical, mathematical, numerical, and conventional choices.
5. **Provenance and comparators** — relevant established results and prior project evidence.
6. **Primary method and tool** — the chosen method, engine, and reason for the choice.
7. **Independent replay decision and reason** — whether a genuinely independent check is needed and why.
8. **Adversarial checks and falsifiers** — tests that could expose an error or defeat the claim.
9. **Known-limit and physical-assumption checks** — required recovery behavior and assumption audit.
10. **Stopping rule** — the outcome or boundary that ends the calculation.
11. **Failure interpretation** — what a negative, blocked, unstable, or inconclusive outcome means.
12. **Result and reproducibility record** — disposition, evidence, calculation-local versions, outputs, and carry-forward consequence.

This record is the unit of computational work. Reuse the existing versioned contract and result when they already contain these fields; the twelve record fields and the twelve foundations concerns do not require duplicate forms. Separate planning packets, mirrored status files, and schemas are not created unless a concrete need later justifies them.

Numerical work must address convergence, discretization or truncation error, conditioning, precision sensitivity, and uncertainty propagation when applicable. A precise-looking numerical value without the controls relevant to its method does not earn additional authority.

## Risk-scaled verification

Verification effort follows claim risk:

- **Exploratory work:** one competent engine plus dimensional, sign, scale, and limiting sanity checks.
- **Consequential mathematical result:** a primary derivation, a genuinely independent replay when practical, and an adversarial attack.
- **Major scientific claim:** independent computational reproduction, known-limit recovery, literature comparison, a physical-assumptions audit, and formalization only where a small decisive statement benefits from it.

Independent replay means independence in method, implementation, representation, or engine sufficient to expose the relevant failure modes. Repeating the same derivation through a cosmetic wrapper does not qualify.

Verification must assess both correctness within stated assumptions and whether those assumptions and the result are justified and relevant to the scientific claim. Different algorithms, representations, engines or AI instances may share the same incorrect physical assumption. Disclose shared assumptions, imported results, data, software and authorship; multiple AI agents are not independent scientists or external endorsement. Agreement alone cannot settle those shared risks, and AI-designed checks are not automatically sufficient.

Where meaningful, anchor acceptance and AI-capability assessment to independently established mathematical identities, published reference calculations or empirical evidence outside the current AI-generated construction, and use deliberately incorrect controls capable of detecting relevant errors. Cite the source and specify what it tests; if no adequate anchor is available, state the limitation and withhold any stronger claim. Literature-derived expertise is inherited human knowledge, not an independent AI discovery. Reuse qualified reference evidence instead of repeating expensive calculations solely for evaluation.

After a meaningful bounded result, synthesize its evidence, supported claim,
remaining inference gaps, significance and next discriminating action using
the [focused result-to-claim assessment](docs/LOCAL_RESEARCH_CONVENTIONS_V1.md#focused-result-to-claim-assessment).
Keep this synthesis in the existing result/review record, proportionate to
the decision. It connects verification to interpretation and priorities;
it creates no additional acceptance gate or scientific authority.

## Provenance and authority

Claims must distinguish observation, established theory, inherited result, current project result, hypothesis, and speculation. Authority is claim-specific and bounded by assumptions, evidence, and reproducibility. Detailed rules are in [`docs/PROVENANCE_AND_AUTHORITY.md`](docs/PROVENANCE_AND_AUTHORITY.md).

Historical material is not current authority merely because it exists. Legacy evidence is consulted deliberately through the immutable references in [`docs/LEGACY_HANDOFF.md`](docs/LEGACY_HANDOFF.md).

## Repository operation

All ordinary work occurs on `main`. No branch, worktree, or alternate development ref may be created unless the owner explicitly authorizes it for the task. Any authorized temporary branch or worktree must be reconciled or rejected and removed before task completion. Force pushes, history rewrites, and destructive ref updates are prohibited. Remote `main` receives only reviewed, validated, fast-forward checkpoints. At normal task completion, local and remote `main` should agree.

Scientific questions and calculations drive architecture. The repository does not accumulate empty structures, speculative abstractions, duplicated external frameworks, or universal environments in anticipation of possible work.

## Storage and external payloads

Git stores the science needed to understand and reproduce claims, not every byte produced while obtaining them.

Store in Git:

- source and compact derivations;
- concise calculation records;
- small exact or machine-readable evidence;
- scientifically useful small figures;
- hashes and manifests for external payloads;
- reproduction instructions.

Keep outside Git by default:

- environments, package depots, caches, and compiled artifacts;
- downloaded frameworks and external databases;
- large datasets, sweeps, grids, simulations, frames, and symbolic intermediates;
- raw outputs that can be regenerated from preserved inputs and instructions.

Storage thresholds are:

- initial foundation below 1 MiB;
- preferred active Git repository below 250 MiB;
- architecture and storage review before exceeding 1 GiB;
- individual files above 10 MiB external by default;
- generated tranches above 100 MiB external by default;
- expected additions above 500 MiB require explicit owner approval before execution.

Large authoritative payloads may use a separately designated active-data location, including D:, when a calculation requires it. Each payload must be separated from historical custody, provenance-bound, hash-identified, manifest-described, and accompanied by reproduction and retrieval information. A missing declared payload must fail explicitly or be reported unavailable; silent fallback is prohibited.

The active project must never depend on the legacy custody tree through a junction, symlink, worktree, import, required execution path, or hidden runtime lookup. Historical custody is evidence storage, not an active dependency surface.

Repository size is not a measure of scientific capability or completeness. Scientific authority depends on the quality and custody of evidence.
