from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='ebdcf56aee689dbbeec023a81b260106790e2a7f'
pv=O.parent/'canonical_so10_probe_vector_response';m=pv/'preparation.json';b[str(m)]=H(m)
for role in ['primary','replay']:
 p=pv/(role+'_inputs.json.gz');assert H(p)==read(m)['input_sha256'][str(p)];b[str(p)]=H(p);d=load(p);q=O/(role+'_inputs.json')
 with q.open('xb') as f:f.write((json.dumps({'Tminus':d['Tminus'],'family_count':3,'extraction':'CLASSICAL_GENERATORS_ONLY_NO_OLD_QUANTUM_TARGET'},sort_keys=True)+'\n').encode())
 b[str(q)]=H(q)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V601.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for folder,ns in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_chiral_sterile_comparison',['RESULT.md','validation_receipt.json']),('canonical_so10_closed_fermion_quadratic_heat',['RESULT.md','DERIVATION.md','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','RESULT.md','validation_receipt_v3.json']),('canonical_so10_two_probe_lifted_ward',['PROOF.md','RESULT.md','validation_receipt_v2.json']),('canonical_so10_ordered_shear_finite_part',['RESULT.md']),('canonical_so10_higher_probe_local_audit',['validation_receipt_v2.json','review_receipt.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['RECORD.md','DERIVATION.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_JHP1',len(b),flush=True)
