from pathlib import Path
from hashlib import sha256
import gzip,json,time,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']]
for key in ['Gram_one_family','Gram_three_families','symmetric_action_numerator','Ward_numerator','analytic']:assert a[key]==b[key],key
assert len(a['numeric_kernels'])==len(b['numeric_kernels'])==9 and len(a['correlated_paths'])==len(b['correlated_paths'])==9
mp.mp.dps=100;worst=mp.mpf('0');positions=0;tails=mp.mpf('0');control={'omit_endpoint_sensitive_cases':0,'omit_hatted_sensitive_cases':0,'hatted_zero_fixed_e0_cases':0,'wrong_e0_power_early_sensitive_cases':0}
for x,y in zip(a['numeric_kernels'],b['numeric_kernels']):
 assert [x[k] for k in ['epsilon','z','q','mu2']]==[y[k] for k in ['epsilon','z','q','mu2']]
 for key in ['B','C','P','tensor_delta','tensor_pp','Ward','power_total','Ward_power_subtracted']:
  p,q=mp.mpf(x[key]),mp.mpf(y[key]);err=abs(p-q)/max(1,abs(p),abs(q));worst=max(worst,err);positions+=1;assert err<mp.mpf('1e-40'),(key,x,err)
 for key in ['B_tail_bound','C_tail_bound','P_tail_bound']:tails=max(tails,mp.mpf(y[key]));assert mp.mpf(y[key])<mp.mpf('1e-48')
 e=mp.mpf(y['epsilon']);ep=mp.mpf(y['endpoint_from_lower_face']);hh=mp.mpf(y['hatted_from_Ward_line']);assert abs(mp.mpf(x['Ward'])-ep-hh)<mp.mpf('1e-38')*max(1,abs(ep),abs(hh));control['omit_endpoint_sensitive_cases']+=int(ep!=0);control['omit_hatted_sensitive_cases']+=int(hh!=0);control['hatted_zero_fixed_e0_cases']+=int(e==0 and hh==0);c=mp.mpf(y['c']);control['wrong_e0_power_early_sensitive_cases']+=int(abs(-mp.mpf(y['power_total'])-1/(4*c))>mp.mpf('1e-40'))
for x,y in zip(a['correlated_paths'],b['correlated_paths']):
 for key in ['H_ren','endpoint_ren','Ward_ren','dimensional_Ward','heat_fraction','hatted_fraction']:
  p,q=mp.mpf(x[key]),mp.mpf(y[key]);err=abs(p-q)/max(1,abs(p),abs(q));worst=max(worst,err);assert err<mp.mpf('1e-40'),(key,x,err)
 assert abs(mp.mpf(x['difference']))<=mp.mpf(x['uniform_error_bound'])+mp.mpf('1e-70')
# Exact elementary moments and remainder signs prove the uniform bound.
e=s.Symbol('epsilon',real=True);q,mu=s.symbols('q mu2',positive=True);A=2**(e-2)*(4-e)/((2-e)*(3-e));cm=2*(2**(e-2)/(2-e)-2*2**(e-3)/(3-e)+2**(e-4)/(4-e));assert s.simplify(A.subs(e,0))==s.Rational(1,6) and s.simplify(cm.subs(e,0))==s.Rational(11,96)
ga=s.Matrix(45,45,{(i,j):s.sympify(v) for i,j,v in a['Gram_three_families']['entries']});assert ga==6*s.eye(45);action_contact=ga/6;polarization_contact=ga/3;assert action_contact==s.eye(45) and polarization_contact==2*s.eye(45)
# Late comparisons,after the two complete new outputs agree.
cqh=read(O.parent/'canonical_so10_closed_fermion_quadratic_heat/validation_receipt.json');csc=read(O.parent/'canonical_so10_chiral_sterile_comparison/validation_receipt.json');assert cqh['actual_minus_covariant_reference_contacts_retained']=='gauge_and_scalar_action_units_1/6' and cqh['power_contacts_retained'] and csc['insertion_and_polarization_contact_match'] and csc['witness_to_physical_divisor']==2 and csc['complex_Gaussian_factor']=='1'
out={'schema':'JHP1_VALIDATION_RECEIPT','elapsed_after_imports':time.perf_counter()-tick,'actual_joint_tensor_vs_direct_Ward_and_endpoint_routes_agree':True,'finite_joint_kernels':9,'correlated_limit_paths':9,'numeric_compared_scalars':positions,'maximum_scaled_numeric_discrepancy':mp.nstr(worst,30),'maximum_retained_tail_bound':mp.nstr(tails,30),'exact_uniform_joint_Ward_limit_per_Gram_action':'q/6','three_family_action_contact_color_diagonal':'I45','three_family_polarization_contact_color_diagonal':'2*I45','old_CQH_CSC_endpoints_match_after_new_calculation':True,'power_coefficient_kept_at_nonzero_epsilon':True,'separate_hatted_and_endpoint_limits_do_not_commute':True,'correlated_total_uniform_in_epsilon_log_heat':True,'nonlocal_kernel_retained':True,'controls':control,'extra_Gaussian_half_sensitive_color_positions':45,'extra_family3_sensitive_color_positions':45,'fixed_simplex_wrong_power_ratio':2,'new_physical_scheme_finite_baseline_or_particles':False,'full_chiral_sources_probes_products_trace_QAP_measure_phase_or_E5_A5':False,'scientific_authority_changed':False,'primary_packed_sha256':H(O/'primary_tables.json.gz'),'replay_packed_sha256':H(O/'replay_tables.json.gz')}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
