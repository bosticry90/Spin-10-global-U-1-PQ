# JHP3 verifier constructor correction

Both JHP2 native calculations completed and their numeric,analytic and joint
path comparisons passed inside the verifier. It then FAILED at the color
matrix construction: SymPy's dense Matrix constructor does not accept the
dictionary format supplied. The completed P/R tables/captures and failed
verify_v2 source/source copy,full capture and controller_failure_v2 remain.
No V2 validation receipt exists; its failed gate is not called PASS.

New verify_v3.py uses SparseMatrix for the SAME45x45 data. All assertions,
positions,normalizations,tolerances,tail bounds and scientific ceilings remain.
The new controller authenticates/reuses completed P/R; it reruns only the
verifier. It also binds the old universal CPC F0/F1 master for a late
normalization comparison,after unknown joint calculations are complete.
Only scalar F is used; the old conjugate-Nambu transpose-sensitive color
tensor is not imported into the SMA charged/sterile model.

New sources/preparation/capture/receipt paths are distinct. Same600s/8GiB
sampled-private/350MiB-floor/16MiB limits,no new physical input or scheme.
