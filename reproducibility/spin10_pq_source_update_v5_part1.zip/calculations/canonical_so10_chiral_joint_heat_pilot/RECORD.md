# JHP1: joint chiral heat/evanescent two-point pilot

Freeze before computation,2026-10-25,baseebdcf56a/main. Question: can the
specified positive free-edge heat prescription and actual SMA charged/sterile
dimensional continuation be realized together in one selected nonzero Ward
amplitude,with correlated power subtraction and controlled joint limits?
This is the next analytic prerequisite after HPA's projected bare-local
probe result. It is not another arbitrary scalar moment or a two-probe QAP.

Use the actual mass-independent parity-even closed-fermion gauge two-point
projection: p_hat=0,p_E^2>0,all45 real-plane generators,three Weyl families
once,original unshifted SMA. No zero-Yukawa physical model,vacuum,flavor or
physical renormalization scheme is adopted. Reuse SMA's normalized alternating
P/S Gaussian,CSC charged/sterile equivalence at M=0 and CSW's reference
R_t=K0(E^-1-1),E=exp(-2t k^2),at zero external backgroundA. Extend this
reference to the full free P/S block BEFORE normalizing its sterile factor;
scalar E commutes with K0 so the free inverse is E G0. Prove this algebra.
This defines a selected joint analytic comparison family,not an already
qualified full chiral trace/product construction. Its endpoints must be
compared with the actual existing DIM/heat amplitudes after calculation.

Keep d=4-2epsilon,h=d-4,physical spin trace4 and all internal hats. Finite
Clifford witnesses are algebra/normalization checks,not analytic positive
hatted dimensions. The action quadratic kernel has half the polarization's
second-variation coefficient. Use inherited1/(16pi^2),Tr48,and no extra
Nambu half after charged/sterile normalization. Keep p^2 and mu_R^2 symbolic.
Finite transverse constants chi4/zeta,kappa,b0 remain distinct/unselected.

Primary: derive the complete parity-even barred numerator from literal
split-Clifford matrices,then perform the d-dimensional Gaussian/Schwinger
integration with BOTH free-edge times a,b>=c=2t. Its x-domain is
s>=c/min(x,1-x),not a fixed simplex. Derive independent delta/pp coefficients
and contract with p. Replay: contract the free chiral Ward line first,
retain both endpoint terms and the actual hatted defect,then integrate
their different Schwinger domains. No unknown response may be assigned from
the negative of the primary tensor or the old measured Ward contact.

In action-kernel normalization the proposed unintegrated Ward reduction is
k_nu/Q-(k+p)_nu/R+p_nu*hat(k)^2/(Q R),Q=k^2,R=(k+p)^2.
Derive/check it rather than impose it. Endpoint heat factors stay at BOTH
node momenta. Fixed positive t does not permit discarding the endpoints
as odd tadpoles. Dimensional analytic continuation at t=0 instead has its
own translation-invariant endpoint rule. Do not interchange these rules.

Construct exact parameter/incomplete-gamma functions at finite epsilon,t;
retain their full nonlocal p dependence. Extract the complete leading
power term from the actual lower Schwinger faces,with its epsilon dependence,
rather than subtracting only its epsilon0 value. Separate the hatted and
endpoint power parts consistently with their derived Ward identity. This
is mathematical FP separation in the reference,not choosing a new physical
finite subtraction. Prove a joint bound on the power-subtracted total for
0<=epsilon<=1/4 and p^2 in a positive compact interval. Test whether its
joint limit agrees with both old endpoint prescriptions; preserve a mismatch.
Do not infer commutation of the individual hatted and endpoint limits.

Numerics are corroboration of exact identities,not a substitute for bounds.
At100 decimal digits compare nine finite pairs:
epsilon in{0,1/20,1/5}, z=c p^2 in{1/100,1/5,3/2};choose p^2=1/2,2,5
respectively by z column and mu_R^2=3/2 throughout. These are auxiliary
integration checks,not physical parameters. Primary integrates x using
upper incomplete gamma; replay integrates total Schwinger time and its
lower-face endpoint independently. Integrate s only to Smax=10^28/p^2
with the omitted hat tail explicitly bounded by
4|epsilon*N|/[p^2(2-epsilon)]*Smax^(epsilon-2).
No omitted tail is labelled zero. Require tail<1e-48 and route agreement
within1e-40 relative to max(1,|value|). Store75-digit values/full captures.
For the s-integral use log(s/(2c)) and the exact erfi inner-x expression.

Also evaluate nine correlated approaches epsilon={1/10,1/20,1/40},
c*p^2=exp(-a/epsilon),a={1/2,1,2},atp^2=2,mu_R^2=3/2. Use stable expm1
for the power-subtracted boundary. Test exact error bounds and derive
limiting shares analytically; do not fit them from a desired cancellation.
Keep analytic gamma/Beta dependence before epsilon0 for future forests.

Controls: omit endpoint,omit hatted term,drop power subtraction,use epsilon0
power coefficient too early,erase the edge-dependent lower face,extra
Gaussian half/family3,prematurely set internal hats0. Quantify insensitive
cases explicitly. Compare only after both outputs exist with CQH/CSC old
coefficients. Source derivatives/global phase/chiral multiple insertions,
general backgrounds,causal/physicalvacuum/massiveC1 and E5/A5 remain open.

Freeze immutable classical inputs,sources,types and failure conditions.
Sequential nativeP/R/verifier each600s after imports,8GiB sampled-private,
350MiB launch floor,whole packet16MiB. Preparers preserve every failure;
cap exhaustionINCOMPLETE,no silent widening,truncation or old evidence edits.
Current E4 may run independently read-only,capturesexternal only.
State113/34of39,custody2/sevenNOTPASS unchanged. No agents,branch/worktree,
push/publication/outreach,foundation/scheme/benchmark adoption,flavor/HB1C5
activation or promotion. Shared action,reference,software and AI author limit
independence. Primary papers2004.14398v2 and1904.08231v3 are methodological
comparators,not sources of this model's coefficients or scheme authorization.
