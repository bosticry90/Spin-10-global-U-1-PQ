# JHP2 prelaunch compatibility continuation

Original preparation FAILED because it guessed CSW's completed receipt name
as validation_receipt_v3.json. The actual immutable receipt is the unversioned
validation_receipt.json. No scientific worker launched and no V1 preparation
or validation receipt exists. The complete capture,controller failure and
six exact failed_source copies preserve the original sources. Its two
classical input extracts remain unchanged and are byte-checked before reuse.

V2 binds the actual historical receipt without changing it or any historical
manifest/policy. New native/controller/verifier and preparation/output paths
are distinct. Before launch,the analytic series comparison is made semantic
(exact simplified difference0),not literal expression-string equality.
No equation,coefficient,tolerance or zero complement changes.

The independent correlated-path lower-gamma series uses16 terms. Its omitted
tail is now explicit: N*c^e*(c*q)^16*A_e/[16!*(e+16)],from the alternating
exponential remainder on the compact half interval. Require it below1e-48
and retain it in every output; it is not silently set0. These paths have
c*q<=exp(-5),so the alternating bound applies. All infinite Schwinger tails
in RECORD.md remain separately recorded. This adds required evidence rather
than changing the scientific target.

The same600s/8GiB-sampled/350MiB-floor/16MiB limits hold. No physical
scheme,baseline,inputs or scientific authority are changed. All limitations
and acceptance obligations of RECORD.md/DERIVATION.md remain.
