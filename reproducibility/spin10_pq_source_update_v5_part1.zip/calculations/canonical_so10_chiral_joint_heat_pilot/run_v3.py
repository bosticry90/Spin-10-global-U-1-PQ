from pathlib import Path
from hashlib import sha256
import json,sys,ast,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-joint-heat-pilot-v1-2026-10-25');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'validation_preparation_v2.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 assert read(O/'primary_v2_capture.json')['execution_state']==read(O/'replay_v2_capture.json')['execution_state']=='COMPLETED' and read(O/'verify_v2_capture.json')['execution_state']=='FAILED' and not(O/'validation_receipt_v2.json').exists()
 folder=O.parent/'canonical_so10_chiral_polarization_contact';p=folder/'primary_tables.json.gz';m=folder/'validation_preparation.json';assert H(p)==read(m)['input_sha256'][str(p)];b[str(p)]=H(p);b[str(m)]=H(m)
 for n in ['CORRECTION_V3.md','verify_v3.py','run_v3.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'validation_preparation_v3.json',{'input_sha256':b,'seconds_after_imports':600,'completed_native_outputs_reused_not_rerun':True,'scientific_acceptance':'NOT_PERFORMED'})
 c=capture([sys.executable,'-B',str(O/'verify_v3.py')]);dump(O/'verify_v3_capture.json',c);dump(C/'verify_v3_full_capture.json',c)
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<600;dump(O/'validation_receipt_v3.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2;print('COMPLETED_JHP3_VERIFIER',rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'controller_failure_v3.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
