from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('JHP_PEER_DENIED')
  if p.parent.name in ['canonical_so10_closed_fermion_quadratic_heat','canonical_so10_chiral_sterile_comparison','canonical_so10_chiral_polarization_contact'] and('tables'in p.name or p.name=='validation_receipt.json'):raise PermissionError('JHP_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
d=read(O/(role+'_inputs.json'));tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(tidy(M).todok().items()) if v]}
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v) for i,j,v in z['entries']});T=list(map(dec,d['Tminus']))
if role=='primary':G=s.Matrix(45,45,lambda a,b:s.expand(s.trace(T[a]*T[b])))
else:G=s.Matrix(45,45,lambda a,b:s.expand(sum(v*T[b][j,i] for(i,j),v in T[a].todok().items())))
assert G==2*s.eye(45) and d['family_count']==3;Gfam=3*G
k=s.Matrix(s.symbols('k0:4'));p=s.Matrix(s.symbols('p0:4'));hh=s.symbols('h0:2');Q=(k.T*k)[0]+sum(v*v for v in hh);R=((k+p).T*(k+p))[0]+sum(v*v for v in hh)
if role=='primary':
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];b4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];gam=[s.kronecker_product(v,pa[2]) for v in b4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]];chi=gam[0]*gam[1]*gam[2]*gam[3];PL=(s.eye(8)+chi)/2;bk=sum((k[i]*gam[i] for i in range(4)),s.zeros(8));bp=sum((p[i]*gam[i] for i in range(4)),s.zeros(8));hk=sum((hh[i]*gam[4+i] for i in range(2)),s.zeros(8));slash=bk+hk;rr=slash+bp
 raw=s.Matrix(4,4,lambda a,b:s.expand(s.trace(gam[a]*PL*slash*gam[b]*PL*rr)/4));Ns=tidy((raw+raw.T)/2);odd=tidy(raw-Ns);assert not tidy(p.T*odd).todok()
 nambu=s.Matrix(4,4,lambda a,b:s.expand(s.trace(gam[a]*chi*bk*gam[b]*chi*(bk+bp))/8));assert not tidy(nambu-Ns).todok()
 L=s.Matrix.vstack(s.Matrix.hstack(bk,hk),s.Matrix.hstack(hk,bk));assert not tidy(L*L-Q*s.eye(16)).todok();free_heat_inverse=True
else:
 # Trace4/barred rank4 follows from the independent charged-projector
 # trace recursion; hatted numerator pairs have complementary projectors.
 Ns=s.Matrix(4,4,lambda a,b:s.expand(k[a]*(k[b]+p[b])+k[b]*(k[a]+p[a])-int(a==b)*(k.T*(k+p))[0]));odd=s.zeros(4);free_heat_inverse=True
ward=tidy(p.T*Ns);endpoint_numerator=tidy(s.Matrix([[R*k[i]-Q*(k[i]+p[i])+p[i]*sum(v*v for v in hh) for i in range(4)]]));assert not tidy(ward-endpoint_numerator).todok()
ee,cc,qq,mm,BB,PP=s.symbols('epsilon c q mu2 B P',positive=True);NN=s.exp(s.EulerGamma*ee)*mm**ee;A=2**(ee-2)*(4-ee)/((2-ee)*(3-ee));CM=2*(2**(ee-2)/(2-ee)-2*2**(ee-3)/(3-ee)+2**(ee-4)/(4-ee));powexpr=NN*(2*cc)**(ee-1)/(2-ee);Dexpr=NN*qq**(1-ee)*s.gamma(1+ee)*s.gamma(2-ee)**2/s.gamma(4-2*ee)/(1-ee)
series=[s.simplify(s.limit(Dexpr,ee,0)),s.simplify(s.limit(s.diff(Dexpr,ee),ee,0))] if role=='primary' else [qq/6,qq*(s.log(mm/qq)/6+s.Rational(4,9))]
Wtensor=(ee*qq*BB-PP)/(1-ee);hat=ee*(qq*BB-PP)/(1-ee);end=-PP;assert s.simplify(Wtensor-hat-end)==0
print('STAGE '+role+' Clifford/Ward, actual color and power formulas complete',flush=True)
mp.mp.dps=100;fmt=lambda z:mp.nstr(z,75);nrows=[]
def norm(e,mu):return mp.exp(mp.euler*e)*mu**e
def primary_values(e,c,q,mu):
 N=norm(e,mu)
 def delt(x):return q*x*(1-x)
 B=2*N*mp.quad(lambda x:x*(1-x)*delt(x)**(-e)*mp.gammainc(e,c*q*(1-x),mp.inf),[0,mp.mpf('.5')])
 C=2*N*mp.quad(lambda x:delt(x)**(1-e)*mp.gammainc(e-1,c*q*(1-x),mp.inf),[0,mp.mpf('.5')])
 P=2*N*c**(e-1)*mp.quad(lambda x:x**(1-e)*mp.exp(-c*q*(1-x)),[0,mp.mpf('.5')])
 return B,C,P,mp.mpf('0'),mp.mpf('0'),mp.mpf('0')
def replay_values(e,c,q,mu):
 N=norm(e,mu);Smax=mp.mpf(10)**28/q;vmax=mp.log(Smax/(2*c));interval=[mp.mpf('0'),mp.mpf('1'),mp.mpf('4'),mp.mpf('12'),mp.mpf('30'),vmax]
 @lru_cache(None)
 def inner(v):
  ss=2*c*mp.exp(v);z=ss*q;aa=mp.mpf('.5')-c/ss;y=mp.sqrt(z)*aa;Jx=mp.exp(-z/4)*mp.sqrt(mp.pi/z)*mp.erfi(y);Ju=(mp.mpf('.25')+1/(2*z))*Jx-aa*mp.exp(-c*q+c*c*q/ss)/z
  return ss,Jx,Ju
 C=N*mp.quad(lambda v:inner(v)[0]**(e-1)*inner(v)[1],interval)
 B=N*mp.quad(lambda v:inner(v)[0]**e*inner(v)[2],interval)
 P=2*c*N*mp.quad(lambda v:(2*c*mp.exp(v))**(e-2)*mp.exp(-c*(1-c/(2*c*mp.exp(v)))*q),interval)
 ct=4*abs(N)/(q*(2-e))*Smax**(e-2);bt=8*abs(N)/(q*q*(2-e))*Smax**(e-2);pt=2*c*abs(N)/(2-e)*Smax**(e-2)
 assert max(ct,bt,pt)<mp.mpf('1e-48')
 return B,C,P,bt,ct,pt
for e0 in ['0','0.05','0.2']:
 for z0,q0 in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  e,z,q,mu=map(mp.mpf,[e0,z0,q0,'1.5']);c=z/q;B,C,P,bt,ct,pt=(primary_values if role=='primary' else replay_values)(e,c,q,mu);power=norm(e,mu)*(2*c)**(e-1)/(2-e)
  if role=='primary':delta=-C+q*B;pp=-2*B;W=delta+q*pp;Hh=mp.nan;Ep=mp.nan
  else:Hh=-e*C;Ep=-P;W=Hh+Ep;delta=-C+q*B;pp=-2*B
  nrows.append({'epsilon':e0,'z':z0,'q':q0,'mu2':'1.5','c':fmt(c),'B':fmt(B),'C':fmt(C),'P':fmt(P),'tensor_delta':fmt(delta),'tensor_pp':fmt(pp),'Ward':fmt(W),'hatted_from_Ward_line':None if role=='primary' else fmt(Hh),'endpoint_from_lower_face':None if role=='primary' else fmt(Ep),'power_total':fmt(-power/(1-e)),'Ward_power_subtracted':fmt(W+power/(1-e)),'B_tail_bound':fmt(bt),'C_tail_bound':fmt(ct),'P_tail_bound':fmt(pt)})
 print('STAGE '+role+' epsilon '+e0+' three joint kernels complete',flush=True)
# Stable correlated-path evaluation; analytic error bound,not a fit.
paths=[]
for e0 in ['0.1','0.05','0.025']:
 for a0 in ['0.5','1','2']:
  e,aa,q,mu=map(mp.mpf,[e0,a0,'2','1.5']);c=mp.exp(-aa/e)/q;N=norm(e,mu)
  if role=='primary':B=primary_values(e,c,q,mu)[0]
  else:
   # Different exact representation: lower gamma through its convergent
   # finite-z expansion integrated termwise on the compact half interval.
   B0=N*q**(-e)*mp.gamma(e)*mp.beta(2-e,2-e);cut=mp.mpf('0')
   for n in range(16):
    moment=2*mp.quad(lambda x:x**(1-e)*(1-x)**(n+1),[0,mp.mpf('.5')]);cut+=(-c*q)**n*moment/(mp.factorial(n)*(e+n))
   B=B0-N*c**e*cut
  PD=2*N*c**(e-1)*mp.quad(lambda x:x**(1-e)*mp.expm1(-c*q*(1-x)),[0,mp.mpf('.5')]);HR=e*(q*B-PD)/(1-e);ER=-PD;WR=HR+ER;D=N*q**(1-e)*mp.gamma(1+e)*mp.beta(2-e,2-e)/(1-e);cm=2*((mp.mpf('.5'))**(2-e)/(2-e)-2*(mp.mpf('.5'))**(3-e)/(3-e)+(mp.mpf('.5'))**(4-e)/(4-e));bound=N*q*q*c**(1+e)*cm/(1-e)*(mp.mpf('.5')+e/(1+e))
  assert abs(WR-D)<=bound+mp.mpf('1e-80');paths.append({'epsilon':e0,'a':a0,'q':'2','c':fmt(c),'H_ren':fmt(HR),'endpoint_ren':fmt(ER),'Ward_ren':fmt(WR),'dimensional_Ward':fmt(D),'difference':fmt(WR-D),'uniform_error_bound':fmt(bound),'heat_fraction':fmt(ER/D),'hatted_fraction':fmt(HR/D),'epsilon0_heat_fraction':fmt(mp.exp(-aa))})
print('STAGE '+role+' all correlated approaches and bounds complete',flush=True)
out={'schema':'JOINT_CHIRAL_HEAT_PILOT_V1','role':role,'Gram_one_family':enc(G),'Gram_three_families':enc(Gfam),'symmetric_action_numerator':enc(Ns),'Ward_numerator':enc(ward),'finite_split_witness_spin_trace_divisor':2,'normalized_free_PS_heat_inverse_checked':free_heat_inverse,'finite_ps_witness_not_analytic_hat_dimension':True,'nonlocal_joint_parameter_kernel_retained':True,'analytic':{'P_power':str(powexpr),'dimensional_Ward':str(Dexpr),'dimensional_series_constant_and_epsilon':list(map(str,series)),'A_e':str(A),'Cmom_e':str(CM),'Ward_tensor_coefficient':str(Wtensor),'hatted_coefficient_after_gamma_recurrence':str(hat),'endpoint_coefficient':str(end),'joint_limit_per_color_trace_action':'q/6','correlated_limit_hatted_share':'1-exp(-a)','correlated_limit_heat_share':'exp(-a)','fixed_simplex_power_at_e0':'1/(2*c)','actual_edge_power_at_e0':'1/(4*c)'},'numeric_kernels':nrows,'correlated_paths':paths,'physical_scheme_or_finite_baseline_adopted':False,'full_chiral_source_products_QAP_measure_phase_or_authority':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
