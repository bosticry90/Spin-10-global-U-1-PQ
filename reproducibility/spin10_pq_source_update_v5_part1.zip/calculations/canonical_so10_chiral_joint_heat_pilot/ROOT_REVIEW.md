# Positive-heat Ward-root and uniform-limit review

Freeze before this dependent review. JHP3 completed all new raw tensor/Ward
and parameter-integral comparisons. The review must identify its endpoint
as the selected actual regulator contribution,not a fitted tensor remainder.

For Q=k2,R=(k+p)^2,Sk=Dk/Q,Sr=Dr/R and scalar Ek,Er,the actual free chiral
identity is V=Dr PL-PR Dk-Ihat, Ihat=hat_k chi. With St=E S the fixed CSW
regulator modifies the inverse by (E^-1-1)D. Algebra BEFORE a trace gives

 Er Ek Sr V Sk = Ek PL Sk-Er Sr PR-Er Ek Sr Ihat Sk
                   +Er(1-Ek)Sr PR-Ek(1-Er)PL Sk.

Derive/check the complete identity in split-Clifford matrices. The final
two terms are positive-heat regulator roots; no inverse heat remains.
The first two single-edge endpoint integrals vanish by oddness in their
own shifted momentum at positive heat,with absolute convergence in the
admitted neighborhood of epsilon0. The root trace therefore leaves the
two-edge endpoint k_nu/Q-r_nu/R weighted by Ek Er,not zero.

After physical trace4 and the Gaussian action factor,check each nu:
 root_trace=Er(1-Ek)r_nu/R-Ek(1-Er)k_nu/Q;
 direct_hat_trace=Er Ek p_nu hat(k)^2/(Q R).
The complete selected lower-face integral is exactly the independent P_e
of JHP; it is not assigned from -H_e or from a desired Ward identity.
The field/source Gaussian sign/order and normalized P/S-to-complex reduction
are inherited SMA/CSW premises; this review is not a full new source theorem.

Check the elementary A_e,Cmom_e integrals and their values1/6,11/96; verify
the exponential remainder signs used by the uniform bound. Nonnegative
epsilon<=1/4,nonzero compact p2/mu2 and c<=1 make its coefficient bounded
and c^(1+epsilon)<=c. D_e is continuous at0. This proves the common total
joint limit while allowing different limiting hatted/endpoint shares.
Retain the fact that the total contact is NONZERO,not restored by this test.

No free finite coefficient,source omission or full-T_kappa assertion.
Source/capture/hash freeze; single review180s/8GiB sampled/350MiB floor,
whole16MiB. Preserve failure,incomplete work and every earlier failed
preparer/verifier. Authority34of39,E5/A5 and whole goal remain unchanged.
