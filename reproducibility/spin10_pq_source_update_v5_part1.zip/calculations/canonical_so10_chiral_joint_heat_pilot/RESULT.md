# JHP: a joint chiral heat/evanescent Ward-limit pilot

## Disposition and scientific question

Qualified bounded result in the selected analytic reference family. After the
derived, epsilon-dependent power subtraction, the complete parity-even gauge
two-point Ward contraction has the common joint limit q/6 per color trace in
action normalization. The hatted insertion and positive-heat regulator endpoint
do not have commuting separate limits. Their sum has a nonzero local limit;
this is not symmetry restoration, an anomaly verdict or a full chiral QAP.

This advances the actual regulated-finite dependency identified by V601 after
the projected bare-local probe result. It does not repeat that local result or
assume that the bosonic two-probe trace construction extends to chiral fields.
The possible outcomes frozen in RECORD.md were a common controlled limit, an
explicit mismatch or a precise missing premise. The first outcome is obtained
for this selected contraction, with the limitations below.

## Domain and actual scientific inputs

Base ebdcf56aee689dbbeec023a81b260106790e2a7f, main, October 25, 2026.
Use the original unshifted SMA, its normalized alternating physical/sterile
Gaussian and charged/sterile massless comparison, and CSW's fixed free
reference R_t=K0(E^-1-1), E=exp(-2t k^2). Extend this scalar free-edge factor
to the full P/S block before normalizing the field-independent sterile factor.
The explicit split-Clifford calculation checks L^2=k^2 I and the normalization.
This is a defined joint analytic comparison family at zero external gauge
background, not an adopted physical scheme or a heat operator on a
noninteger-dimensional Hilbert space.

The target is the mass-independent parity-even closed-fermion gauge two-point
amplitude, p_hat=0, q=p_E^2>0, d=4-2 epsilon, internal hats retained. The joint
bound holds for 0<=epsilon<=1/4 and q and mu_R^2 in positive compact intervals.
No constant-vacuum or p=0 limit is included. Mass independence here is a
projection of the original action, not adoption of a zero-Yukawa model.
Actual 45 real-plane Tminus generators are extracted from authenticated PVR
classical inputs; three Weyl families are included once. No flavor fit occurs.

The finite split-Clifford witness has trace 8, divided by 2 to obtain physical
trace 4. Its two explicit hatted matrices test algebra; their positive integer
number is not used as the analytic hatted dimension h=-2 epsilon. The Gaussian
action coefficient is half the polarization second variation. No extra Nambu
half is inserted after the charged/sterile normalization.

## Two derived integration routes

In common g10^2/(16 pi^2) times family color-trace action units, the actual
symmetrized numerator is

    N_mn = k_m(k+p)_n + k_n(k+p)_m - delta_mn bar_k.(bar_k+p).

The literal projector trace derives it, checks the parity-odd contraction and
its symmetric integral, and checks the alternating-variable normalization.
The other route contracts the free chiral Ward line before integration:

    p_m N_mn/(Q R) = k_n/Q - (k+p)_n/R + p_n hat_k^2/(Q R),
    Q=k^2, R=(k+p)^2.

Both free edges have Schwinger times a,b>=c=2t. With s=a+b and x=a/s,
s>=c/min(x,1-x); replacing this by a fixed simplex gives a wrong power term.
Let u=x(1-x), m=min(x,1-x), Delta=q u, s0=c/m and
N=exp(gamma_E epsilon)(mu_R^2)^epsilon. The exact functions retained are

    B = N integral u Delta^(-epsilon) Gamma(epsilon,Delta s0) dx,
    P = N integral s0^(epsilon-1) exp(-Delta s0) dx,
    C = N integral Delta^(1-epsilon) Gamma(epsilon-1,Delta s0) dx.

The tensor calculation gives

    K_mn = [((2-epsilon)q B-P)/(1-epsilon)]delta_mn - 2B p_m p_n.

The direct hatted coefficient is H=-epsilon C. Independently integrating
the endpoint on its lower Schwinger face gives

    Eend = -2c N integral_(2c)^infinity
                    s^(-3+epsilon) exp[-c(1-c/s)q] ds = -P.

The incomplete-gamma recurrence C=(P-qB)/(1-epsilon) relates the two routes:

    p_m K_mn = p_n W,    W=H+Eend=(epsilon qB-P)/(1-epsilon).

This is not a fitted endpoint or an assumed cancellation. ROOT_REVIEW.md and
review.py additionally derive the actual positive-heat Ward roots. Writing
Sk=Dk/Q, Sr=Dr/R, V=Dr PL-PR Dk-Ihat and Ihat=hat_k chi, the matrix identity is

    Er Ek Sr V Sk = Ek PL Sk - Er Sr PR - Er Ek Sr Ihat Sk
                      + Er(1-Ek)Sr PR - Ek(1-Er)PL Sk.

All matrix entries and four normalized root/hat traces agree. The last two
terms are the regulator roots after the finite-mode inverse-heat cancellation.
Their single-edge odd terms vanish only after absolutely convergent shifted
positive-heat integration. The retained two-edge term integrates to -P.
The inherited source/Gaussian sign and ordering remain scientific premises;
this selected free-line check is not a new full source theorem.

## Power subtraction and a uniform total limit

The lower face fixes

    Ppow = N(2c)^(epsilon-1)/(2-epsilon).

The total leading power is -Ppow/(1-epsilon), with hatted and endpoint shares
-epsilon Ppow/(1-epsilon) and -Ppow. Keeping this correlation and setting
Pdiff=P-Ppow gives

    H_R=epsilon(qB-Pdiff)/(1-epsilon),
    E_R=-Pdiff,    W_R=(epsilon qB-Pdiff)/(1-epsilon).

This separates a derived reference power contribution, without choosing a
finite longitudinal or transverse normalization to make an identity hold.
At zero heat the dimensional analytic continuation instead yields

    D_e = N q^(1-epsilon) Gamma(1+epsilon)
                         Beta(2-epsilon,2-epsilon)/(1-epsilon).

The original zero-heat integral has a convergence strip before continuation;
no divergent boundary is simply set to zero. DERIVATION.md gives exact
positive moments A_e and Cmom_e, with A_0=1/6 and Cmom_0=11/96. Elementary
exponential remainder bounds prove

    |W_R-D_e| <= N q^2 c^(1+epsilon) Cmom_e/(1-epsilon)
                                      * (1/2+epsilon/(1+epsilon)).

The coefficient is bounded on the declared compact sets. Thus W_R -> q/6
jointly as (epsilon,c)->(0+,0+), without restricting epsilon log c.
Numerical path tests corroborate this bound; they do not replace it.

The separate pieces retain their order-of-limits information. Taking epsilon
to zero first leaves the contact in E_R; taking c to zero first leaves it in
H_R. Along cq=exp(-a/epsilon), a>0, their fractions approach

    H_R/(q/6) -> 1-exp(-a),    E_R/(q/6) -> exp(-a).

Neither individual contribution may be dropped. The full nonlocal B kernel
remains in K_mn; this result does not assert a common renormalized limit for
every transverse tensor term, product or background-dependent functional.

The independently recovered color Gram is Tr16(Ta Tb)=2 delta_ab, hence the
three-family Gram is 6 I45. The total local action contact is therefore
q I45 in these common units, and the polarization second-variation contact
is 2q I45. Late comparison with CQH/CSC and the universal CPC scalar master
agrees, including

    D_e = q/6 + epsilon q[log(mu_R^2/q)/6+4/9] + O(epsilon^2).

Only the universal CPC scalar master is reused at comparison; its earlier
conjugate-Nambu, transpose-sensitive color tensor is not imported.

## Validation, controls and preserved failures

Primary: literal split-Clifford tensor followed by x/incomplete-gamma
integration. Replay: free-line contraction followed by total-Schwinger-time
and lower-face integrations, with a separate convergent lower-gamma expansion
for correlated paths. Both reconstruct the actual color Gram. They share
the action, reference assumptions, author, Python, SymPy and mpmath; the
replay also reuses elementary tensor formulas. This is distinct mathematical
corroboration, not external scientific or experimental validation.

Nine finite (epsilon,cq) cases and nine correlated paths were evaluated at
100 decimal digits and serialized at 75. The verifier compares 72 finite-case
scalars plus six quantities per correlated path. Maximum scaled discrepancy
is 9.20997400049118e-51, against the frozen 1e-40 gate. The largest explicitly
retained Schwinger tail bound is 3.90227666694762e-50; the largest retained
16-term lower-gamma series tail is 6.34423172799630e-51, both below 1e-48.
Omitted tails are bounded, not declared zero.

Omitting the endpoint changes all nine finite cases; omitting the hatted term
changes six and is correctly insensitive in the three epsilon=0 cases. Using
the epsilon=0 power too early changes six. A fixed-simplex power is twice
the actual epsilon=0 power. An extra Gaussian half or extra family factor
changes all 45 diagonal color positions. Dropping the power subtraction leaves
the explicitly derived nonzero divergent term. These controls do not validate
all source signs, multiple-insertion contacts or a full measure construction.

Two execution failures remain FAILED, with original sources and full captures:

1. V1 preparation guessed a nonexistent versioned CSW receipt name. It failed
   before scientific workers or a preparation manifest existed. Six original
   failed_source copies and the two unchanged classical extracts are retained.
   V2 binds the actual unversioned historical receipt; no old bytes are rebound.
2. After both V2 calculations and their analytic/numerical comparisons, the V2
   verifier failed because SymPy's dense Matrix constructor cannot accept the
   sparse dictionary supplied. V3 changes that constructor to SparseMatrix,
   authenticates completed P/R and reruns only verification. No requirement,
   tolerance, quantum coefficient or physical input was weakened. There is no
   V2 validation receipt; its full source/capture/failure remain.

Completed primary/replay/V3 verification/root review took respectively
80.4231742, 24.3918276, 0.2684666 and 1.0723319 seconds after imports. Frozen
limits were 600 seconds per native/verification route, 180 for root review,
8 GiB sampled private memory, 350 MiB launch floor and 16 MiB whole packet.
Resource samples were 41/13/1/2, with sampled private maxima
55,304,192 / 63,549,440 / 921,600 / 51,609,600 bytes. Sampling is not a
continuous-peak guarantee. Manifest binding counts are 57/65/76/54 for V2
preparation, V2 validation preparation, V3 validation preparation and review.
Thirteen source copies and six failed-source copies are retained.

Validation receipt: validation_receipt_v3.json, SHA256
b587dff090d75e8bd0c34679242bc7c03d84b319ad2d776708479b7644039ce6.
Root review: review_receipt.json, with its complete capture and preparation.
Primary/replay table SHA256:
e034813200240e2c416107e78277f2244f77f3b1955db5186f535a58c4d54560 /
077bdb900ba60e2e7828b200f84739b1cdcca430b0aedc3e19d01407d5f2cb56.

Current delegated E4 checks completed with native exit 0 and step exits
[0,0,0,0,0,2]. Historical custody is still exit 2, seven NOTPASS references;
authentication is not fresh replay or scientific acceptance. External captures
and the before/index/after byte seals are under
C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-joint-heat-pilot-v1-2026-10-25/.
The seal must protect all 35,494 prior Git blobs and all new raw/index/HEAD
bytes. No old evidence, project_state.json, branch or remote is changed.

## Significance, limits and next dependency

The selected DIM and heat endpoints can be connected through an explicit
joint Ward calculation that retains both the hatted defect and regulator
response. A componentwise limit argument would have attributed the finite
contact incorrectly. The result supplies one necessary analytic check for
the finite chiral construction, rather than promoting bare-local zeros into
finite-product statements.

The unprobed Ihat remains nonzero. Q_full remains curved. General chiral
sources, probes and connected products, the full trace domain, arbitrary
backgrounds, absolute phase and measure, massive/infrared/causal physical
limits and E5/A5 remain unresolved. chi4, zeta, kappa and b0 remain distinct
and unselected. Scientific authority is 34/39, state113 unchanged, state SHA
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
Existing physical exclusions and blocked flavor/HB1/C5 boundaries remain.

The next least expensive scientific test is the remaining transverse part of
this same nonlocal amplitude: derive its joint finite-part comparison using
the actual fixed heat prescription and inherited DIM-to-heat conversion,
retaining epsilon-dependent pole/power terms before limits. Determine which
uniform statement is justified without selecting chi4 or a new physical
normalization. Only then extend to the first necessary source/probe-connected
chiral channel under the actual CSW/SQP source-Hessian rules. No claim about
full products follows from this one contraction or its numerical precision.

The supplied assessment and five outside references were already reviewed in
the PVR reference intake. Its older scalar-companion recommendation has since
been tested; no qualified calculation is repeated because of that historical
recommendation. No foundation, new acceptance gate or monitoring automation
is imported from those references. The ongoing Spin(10) x PQ goal is active
and incomplete.
