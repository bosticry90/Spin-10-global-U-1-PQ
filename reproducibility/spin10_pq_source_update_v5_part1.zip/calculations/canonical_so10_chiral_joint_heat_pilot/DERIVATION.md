# Joint two-point coefficient and the order of limits

Prospective until independent calculations and review qualify it. This is a
selected reference construction,not adoption of a full physical scheme.

At A0 the inherited CSW regulator is R_t=K0(E^-1-1),E=exp(-2t k2)I.
For the full SMA free P/S block,L=[[bar_k,hat_k],[hat_k,bar_k]],L^2=k2 I.
The regulated inverse is -i E L/k2. Scalar E commutes with the fixed Nambu
change of variables; normalizing the field-independent sterile factor then
has the same massless charged/sterile determinant as the qualified SMA/CSC
construction. This proves the free-edge factors for THIS pilot; it does not
define an absolute Pfaffian phase,arbitrary-background chiral measure or
noninteger-dimensional Hilbert-space heat operator.

Let q=p^2>0,c=2t,d=4-2e,N=exp(gamma_E e)*(mu_R^2)^e,u=x(1-x),
m=min(x,1-x),Delta=q*u and s0=c/m. The action coefficient in common
g10^2/(16pi^2)*Tr48(A_mu(-p)A_nu(p)) units has numerator

    N_mn=k_m(k+p)_n+k_n(k+p)_m-delta_mn bar_k.(bar_k+p).

This follows from the charged PL trace with its Gaussian expansion factor.
In the SMA P/S alternating variables both conjugate chiral paths and the
Nambu half give the SAME factor. A finite Clifford witness checks algebra
only; analytic h=-2e is substituted after the normalized physical trace.
The parity-odd piece contracts to0 and has zero symmetric Gaussian integral;
it is not discarded before checking those facts.

For a,b>=c,set s=a+b,x=a/s. After k=l-xp,the Gaussian delta coefficient
is -1/s+u*q and the pp coefficient is -2u. Define

 B_e(c)=N integral_0^1 u*Delta^(-e)*Gamma(e,Delta*s0) dx,
 P_e(c)=N integral_0^1 s0^(e-1)*exp(-Delta*s0) dx,
 C_e(c)=N integral_0^1 Delta^(1-e)*Gamma(e-1,Delta*s0) dx.

The independent tensor calculation gives

 K_mn = [((2-e)/(1-e))*q*B_e-P_e/(1-e)]delta_mn -2B_e p_m p_n.

The independent free-line Ward contraction must instead retain

 p_m N_mn/(Q R)=k_n/Q-(k+p)_n/R+p_n*hat_k^2/(Q R),
 Q=k2,R=(k+p)^2.

Thus its ACTUAL direct hatted insertion coefficient is H_e=-e*C_e.
For the endpoint difference,represent the denominator on ONE line while
retaining heat on BOTH nodes. Symmetric routing gives

 E_e=-2c*N integral_(s=2c)^infinity s^(-3+e)
                 exp[-c*(1-c/s)*q] ds = -P_e.

This equality is derived from a lower Schwinger face,not from subtracting a
desired tensor Ward result. The incomplete-gamma recurrence gives

 C_e=(P_e-q B_e)/(1-e),
 W_e=H_e+E_e=(e*q*B_e-P_e)/(1-e).

The tensor contraction p_m K_mn=p_n W_e is then a test of the two routes.
Both powers and finite terms are kept. At fixed t>0,H_0=0 but E_0 is nonzero.
At zero heat the dimensional analytic continuation instead sets the surface
P to0. Its convergence strip for the original numerator permits1<Re(e)<3/2
before continuation to e0; no divergent boundary is simply evaluated at0.
The resulting dimensional W is

 D_e=N*q^(1-e)*Gamma(1+e)*Beta(2-e,2-e)/(1-e), D_0=q/6.

## Correlated power subtraction,not an arbitrary finite choice

The leading power is independently fixed by the lower-face integral:

 P_pow=N*(2c)^(e-1)/(2-e).

The total power is -P_pow/(1-e). Its hatted and endpoint pieces are
-e P_pow/(1-e) and -P_pow. Define

 P_diff=P_e-P_pow,
 H_R=e*(q B_e-P_diff)/(1-e), E_R=-P_diff,
 W_R=(e*q B_e-P_diff)/(1-e).

The same decomposition of the derived power coefficient is essential;
subtracting its e0 value at nonzero e is a different operation. No finite
longitudinal or transverse coefficient has been chosen to force W_R.

For0<=e<=1/4,define exact positive moments

 A_e=integral u*m^(-e)dx=2^(e-2)*(4-e)/[(2-e)(3-e)],
 Cmom_e=integral u^2*m^(-e-1)dx
       =2[(1/2)^(2-e)/(2-e)-2(1/2)^(3-e)/(3-e)
                                             +(1/2)^(4-e)/(4-e)].

The elementary exponential remainder bounds0<=exp(-z)-1+z<=z^2/2 and
0<=1-exp(-z)<=z give

 P_diff=-N*q*c^e*A_e+R_P,
 0<=R_P<=N*q^2*c^(1+e)*Cmom_e/2,
 e*q*B_e=(1-e)D_e-N*q*c^e*A_e+R_B,
 0<=R_B<=N*q^2*c^(1+e)*Cmom_e*e/(1+e).

They imply

 |W_R-D_e| <= N*q^2*c^(1+e)*Cmom_e/(1-e)*(1/2+e/(1+e)).

This is uniform near e0 on positive compact q and mu_R^2 intervals.
Consequently the TOTAL W_R has common joint limit q/6 as(e,c)->(0+,0+),
with no restriction on e*log(c). For c*q=exp(-a/e),a>0,the separated
renormalized shares instead approach H_R/(q/6)=1-exp(-a),
E_R/(q/6)=exp(-a). Their iterated limits differ; the correlated total agrees.
No claim of interchangeability for the separate terms or the full theory.

## Independent numerical route and retained tails

For replay exchange the two Schwinger integrations. At fixed s>=2c,

 J(s)=integral_(c/s)^(1-c/s) exp[-s*q*x(1-x)]dx
     =exp[-s*q/4]*sqrt(pi/(s*q))*erfi(sqrt(s*q)*(1/2-c/s)).

Compute H_e=-e*N integral_(2c)^infinity s^(-2+e)*J(s)ds and the independent
endpoint lower-face integral above. Use v=log(s/(2c)),Smax=10^28/q.
J(s)<=4/(s*q) bounds the omitted hat tail by
4|e*N|/[q(2-e)]*Smax^(e-2); endpoint tail is bounded by
2c|N|/(2-e)*Smax^(e-2). Neither omitted tail is labelled zero. Work at
100 digits,store75; validate the analytic bound in addition to1e-40 route
agreement. Correlated-path P_diff uses expm1 to avoid cancellation.

## Interpretation and references

The limit is the existing nontransverse action contact q*G_family/6,
equivalently polarization contact q*G_family/3. With actual Tr16 Gram2I
and three families once,G_family=6I. No Spin(10) contraction is inferred
from an arbitrary one-color fixture. The transverse form factor and its
chi4/zeta normalization remain; the nonlocal B_e is retained explicitly.
CQH/CSC comparisons are loaded only AFTER independent new output agreement.

[BMHV counterterm analysis](https://arxiv.org/abs/2004.14398v2) and
[BRST with a cutoff](https://arxiv.org/abs/1904.08231v3) are primary
methodological comparators: finite evanescent contributions and cutoff
terms require explicit treatment. They supply none of the model coefficients
above and do not establish the full chiral reference domain here. The pilot
leaves arbitrary backgrounds,source products,probe derivatives,global phase,
measure,full QAP,causal/physical limits and E5/A5 unresolved.
