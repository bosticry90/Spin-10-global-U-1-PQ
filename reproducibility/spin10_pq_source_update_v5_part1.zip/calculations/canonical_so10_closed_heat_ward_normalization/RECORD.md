# CHW1: explicit reference-matched closed-matter heat Ward normalization family

Question: do the complete measured rawDIM-heat and DIM-covariant-comparator
functionals define a nonempty one-loop local normalization family satisfying
the CLOSED BOSONIC MATTER gauge Ward relation, with actual quantum reference
applicability and a direct nonzero even insertion control? This is not a full
Slavnov/source/QAP restoration claim. Base dddb6743f5e0139deabcbbb1f91abec01cd1c692/
main33247oldblobs,state113/34of39,wholegoalACTIVE/incomplete. OGT actualoddtriangle
and OGC complete selectedlocalodd coverage qualified, with original control
metadata correction/prelaunchfailure preserved. No failed oldstage rerun.

Freeze physical hats0, source-free bosonic external fields, one Spin10 gauge
variation, nonexceptional Euclidean momenta, formal one-loop graph expansion,
actual SMA/Pfaffian/trace4, YCTfull328scalar/45generator covariance, CSW scoped
firstvariationdomain, CSH/CQH/CGH complete raw local comparison, BWF/GWF complete
DIM-minus-formal-parity-even-covariant-comparator. Actual odd localvariation0
is OGC, not a presumed missingphase. Keep general symmetric familymatrices,
R=-L.T,U.T=U,V.T=V,V=Udagger. Background A_H=0; no discarded Gamma_ref[A_H].

Append the compact curvature prefactor correction: physical F=partialA-partialA
-ig[A,A], so UVgauge=g²TrF²/6, bilateral=g²(TrFL²+TrFR²)/12. Earlier CSH prose
omitted explicitg²; actual typed loop orders/tables unchanged. Bind correction
and verify pure-gauge g²/g³/g⁴ degrees independently, not a fitted rescaling.

Define C_raw=GammaD_even-Gammaheat_even from measured diagrams, retaining its
power contacts. C_cmp=GammaD_even-Gammacmp_even is separately measured BWF.
Provisional matching counterterm K=C_raw-C_cmp plus three independent real
invariant directions zeta_g*g²Ig/6,zeta_M*Im/2,zeta_V*Iv/2. Ig=(TrFL²+TrFR²)/2,
Im=Tr(DV DU),Iv=TrUVUV. No assertion these exhaust counterterms. chi4 remains
1+log(16pi)-n_log, the inherited common log/finite convention, never set0 or
identified with zeta,b0/kappa. Power matching g²TrA²/(8t)+TrVU/(4t) is explicit
in the candidate map; do not silently adopt it as the project's physical scheme.
No canonical functional or project_state mutation is authorized by this packet.

A quantum applicability proof is required before claiming this Ward family:
the comparator is the actual SYR full-anticommuting parity-even trace with
oddchi traceszero, not the physical oddtrace or a new fullchiral regulator.
Use its proven qD=ig(AtD-DA), cyclic finite-color/parity-even spintrace and
Schwinger-defined dimensional Gaussian translation to telescope the regulated
one-loop graph series. TrAt-TrA has oddchi and vanishes in this reference.
Its actual UVpole is invariant, so pole/finitepart subtraction preserves this
Ward relation. Prove on coefficientwise nonexceptional kernels under existing
onevariationdomain; no arbitrary continuum heat finitepart trace cyclicity,
absolute measure/phase, nonchiralStokes or global QAP theorem. If a necessary
premise fails, retain algebraic candidate only, not quantum restoration.

Primary reconstructs rawS_n from authenticated paired UVinvariant densities,
subtracts actual BWF words, derives Euler/explicit currents and Ward image.
Replay independently builds the expanded local coefficient template and
matrix Euler derivatives. Compare every word, implicitzero, boundary and
physical Hermitian/reality direction; preserve invariant parameters and verify
chi4/zeta-independence of the Ward image. Derive reference trace telescope
and Gaussian shift identities independently; identify their hypotheses.

Direct actual EVEN cG control: onevector Ihat graph+two mixed orientations
and actual n1cutoffsource word. Euclidean insertion +1/2TrG0VG0E and response
+Tr[E G0V(1-E)X] retain actual signs. Derive dimensional h/2 Gamma(eps-1)
Delta^(1-eps) and positiveheat shiftedvector integral; compare the finite
p²p_mu coefficient and the nonzero1/t power part against K's quadratic Ward
kernel only after independently computing loops. No quantum coefficient is
assigned from cancellation. Reuse actual2025Gram positions, closedfamily3once.

Controls wrongK sign/omitpower,omit a mixedorientation,wronghat/witness/half,
wrongheat4length,omitg²curvatureprefactor,omitcmp orscalarEuler/current/boundary.
Calculate actual changed words rather than inventorysizes. Report insensitive
matrix subspaces. Failure nativeorsemantic preserved/versioned, no weakened gate.
Freeze8sources/copies/inputs before sequential P/R/V600safterimports each,
8GiBsampled/350MiBlaunch/16MiBpacket. Reuse currentturnOGT E4authenticated0steps
0/0/0/0/0/2,custody2sevenNOTPASS. Before/index/afterseals preserve33247oldblobs.

Ceiling: an explicit nonempty reference-matched closed-bosonic-matter one-loop
Euclidean gauge-Ward normalization family within the stated formal graphdomain,
NOT adoption of a physical heat scheme, full chiral source/Slavnov/QAP/product/
measure/phase, multipleinsertions, all backgrounds,massive/causal/Lorentzian/
constant-vacuum limits, fullE5/A5 or GUT. Independentfinitefreedoms and all
physicalfailures/pausedflavor/HB1C5/quartet/state/history persist. No agents,
branch/worktree/push/outreach/publication or foundational adoption. Shared
assumptions/action/data/software/AIauthor limit independent assurance.
