from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/closed-heat-ward-normalization-v1-2026-10-23');OLD=CONTROL.with_name('odd-gauge-local-coverage-v1-2026-10-23');READY=CONTROL.with_name('odd-gauge-triangle-insertion-v1-2026-10-23')
BASE='dddb6743f5e0139deabcbbb1f91abec01cd1c692';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
CONTROL.mkdir(parents=True,exist_ok=False);bind={}
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==33247
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['postcommit_seal.json','after_seal_full_capture.json','seal.py']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'after_seal_full_capture.json')['native_exit']==0
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V568.md','docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md','docs/CSH1_COMPACT_CURVATURE_FACTOR_CORRECTION_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in {
'canonical_so10_odd_gauge_local_coverage':['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json','control_receipt_v3.json','local_odd_coverage_member.json.gz'],
'canonical_so10_bosonic_fermion_finite_ward':['RECORD.md','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
'canonical_so10_fermion_pure_gauge_uv':['RECORD.md','RESULT.md','validation_receipt_v2.json'],
'canonical_so10_scalar_yukawa_reference':['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json'],
'canonical_so10_open_fermion_heat_kinetic':['RECORD.md','DERIVATION.md','RESULT.md','replay_tables.json.gz','validation_receipt.json'],
'canonical_so10_closed_gauge_heat_companions':['RECORD.md','RESULT.md','validation_receipt.json','complete_pure_gauge_relative_member.json.gz'],
'canonical_so10_closed_fermion_quadratic_heat':['RECORD.md','RESULT.md','validation_receipt.json','selected_quadratic_relative_member.json.gz'],
'canonical_so10_odd_gauge_triangle_insertion':['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json','selected_odd_triangle_member.json.gz'],
'canonical_so10_fermion_gauge_finite_difference':['RECORD.md','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
'canonical_so10_sterile_matter_action':['ACTION_V1.md','RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json'],
'canonical_so10_matter_anomaly_reuse':['RECORD.md','RESULT.md','validation_receipt.json'],
'canonical_so10_local_gauge_anomaly':['RECORD.md','RESULT.md','validation_receipt.json','original_result.json','fresh_result.json'],
'canonical_so10_cutoff_source_ward_operator':['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json'],
'canonical_so10_fermion_statistical_normalization':['RECORD.md','RESULT.md','validation_receipt.json'],
'canonical_so10_yukawa_carrier_transport':['RESULT.md','validation_receipt.json'],
'canonical_so10_closed_scalar_heat_companions':['RECORD.md','RESULT.md','validation_receipt.json','complete_bosonic_relative_member.json.gz']}.items():
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(READY/n)
rd=read(READY/'readiness_result.json');assert rd['native_exit']==0 and rd['step_exits']==[0,0,0,0,0,2] and rd['historical_custody']=='EXIT2_SEVEN_NOTPASS'
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'CHW1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('CHW1_FROZEN',len(bind),'bindings',flush=True)
