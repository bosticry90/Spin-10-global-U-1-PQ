# CHW1: a closed-matter one-loop heat Ward normalization family is constructed

Qualified selected reference-matched closed-bosonic-matter gauge-Ward family
in the frozen formal one-loop, nonexceptional Euclidean, physical-external-hats0
domain. ReceiptSHA25690c47ac743d962e92acd21a2608ad9923f6ad2626ac027a35ea3090f0216b09b.
Scientific acceptance NOT_PERFORMED; project_state113/authority34of39 unchanged.
This is not full chiral Slavnov/QAP/source restoration or physical-scheme adoption.

## The measured comparisons define a nonempty family

The two complete measured local comparisons are different objects:

    C_raw = Gamma_dim,even - Gamma_heat,even,
    C_cmp = Gamma_dim,even - Gamma_cmp,even.

The first is CQH/CGH/CSH's actual raw dimensional/positive-free-edge-heat
comparison, with its explicit power contacts. The second is the independent
BWF/GWF actual/formal-covariant-comparator comparison. Their subtraction gives
an explicit matching counterterm, with no unmeasured coefficient selected:

    K = C_raw - C_cmp
        +zeta_g*(g10²/6)Ig +zeta_M*Im/2+zeta_V*Iv/2.

Here Ig=(Tr48 FL²+Tr48 FR²)/2, Im=Tr48(DV DU), Iv=Tr48(UVUV).
The three zeta directions are independent tested real invariant directions,
not a complete ambiguity classification. chi4 remains the inherited common
comparison input1+log(16pi)-n_log. Its invariant contribution overlaps a common
shift of those directions; four symbols do not mean four independent physical
couplings. None is fixed0 or identified with b0,kappa,zpsi,z10,z126.

C_raw,finite=sum c_n S_n, with
c2=chi4-5/12,c3=chi4+log(3/2)+1/2,c4=chi4+log2+5/6 and S_n the field-degree
pieces of the ACTUAL pole functional

    S=(g10²/6)Ig+Im/2+Iv/2.

The explicit g10² in the gauge term is essential. The compact CSH prose/V566
formula omitted it. The appended
[compact curvature prefactor correction](../../docs/CSH1_COMPACT_CURVATURE_FACTOR_CORRECTION_V1.md)
records this reporting error, preserving the original tables, coupling-typed
pole calculations, receipts and historical text. New construction and gate
check every pure-gauge g²/g³/g⁴ degree; the wrong omission changes108typed words.
No physical gauge coupling or previous calculation is rescaled.

The candidate map also retains

    K_power=g10² sum_mu Tr48(L_mu²+R_mu²)/(16t)+Tr48(VU)/(4t).

These local power subtractions are part of the explicit reference-matching
construction, not an adopted physical mass or a silently selected project
renormalization scheme. Applying K would match the heat definition to the
specified comparison family. No canonical action or project_state was changed.

## Why this is a quantum Ward construction within its stated domain

The comparator is the already specified SYR formal full-anticommuting,
parity-even chiral algebra: oddchi traces are0. It is not the actual physical
epsilon trace and is not adopted as a full physical chiral regulator. Its
actual bilateral operator obeys qD=ig(AtD-DA) with the existing scalar mass law.

Before taking pole/finite parts, dimensional graph cyclicity and loop translation
telescope -TrlogD/2 into -igTr(At-A)/2. At-A contains oddchi and its reference
trace vanishes. Loop translation is justified by the Schwinger generating
Gaussian and meromorphic coefficientwise continuation, with the inherited
nonexceptional/joint-Schwartz first-variation bounds. Finite-color trace alone
is cyclic; no arbitrary renormalized heat finite-part trace is rearranged.
The independently measured pole S is invariant, so its subtraction and the
three finite invariant directions preserve this comparator Ward identity.
Finite trace/inverse and Gaussian-translation checks corroborate the operator
argument; they do not replace its analytic hypotheses with matrix fixtures.

Thus, in this formal graph domain,

    Gamma_heat,even+K = Gamma_cmp,even+invariants,

including the stated local power matching. OGC independently qualifies zero
actual physical-odd local gauge variation in this selected closed-matter sector.
Together these establish a nonempty selected one-loop gauge-Ward normalization
family. They do not construct a global determinant phase, a full quantum source
map or every renormalized connected product. This is a comparison-prescription
existence result, not a physical theory or scheme adopted by the director.

Complete parent coverage is crucial: C_raw and C_cmp include all seven allowed
closed-bosonic parity-even one-loop classes in this mass-independent domain.
K was not manufactured from the negative of an unexplained Ward remainder.
The nonlocal common effective action need not be local; the measured regulator
conversion and its counterterm are local. Independent scalar/gauge family and
source normalizations remain retained for later simultaneous construction.

## A direct nonzero insertion checks the quantum sign and finite normalization

The actual even cG insertion is calculated separately from K, using SMA's
mixed P/S Ihat Hessian and +1/2Tr(G0 V G0 E). Both mixed orientations give
the literal physical-spin numerator4G_ab timesr_mu andk_mu. Their difference
is-4G_ab p_mu. The actual propagator/vertex/Gaussian phase is+i g10²/2.
The off-shell dimensional hat moment is

    (h/2)Gamma(epsilon-1)Delta^(1-epsilon),
    h=-2epsilon,Delta=x(1-x)p².

One route takes the Gamma limit then exact x integral; the independent route
uses the full Schwinger/beta expression before the limit. In common
[i g10² G_ab p_mu/(16pi²)] units both give finite -p²/3.

The independent actual heat response +Tr[E G0 V(1-E)X] gives

    +1/(4t)-p²/3+O(t p4).

The shifted positive Gaussian vector integral is evaluated exactly, not inferred
from cancellation. Its power coefficient1/4 and finite coefficient-1/3 agree
between the two integral methods. The first unshifted term is odd and vanishes
only after its momentum symmetry is established. The actual K quadratic Ward
kernel contributes -1/(4t)+p²/3, with zero power and finite sum remainders.
This is a nonzero model-relevant consistency check: actual paired2025Gram
positions are reused, with G_ab=2delta_ab and closedfamily3once. It is not a
prediction of a physical gauge-boson mass or a fitted finite coupling.

## Exact assembly, controls and resources

Direct cyclic Euler extraction and an independent expanded matrix-calculus
construction agree on all166generic counterterm words and88actual transpose-
quotient words. The Ward image has480words. The explicit boundary divergence
has752words, and qK=W+partialJ has zero coefficient remainder. K is Hermitian;
its Ward image is independent of chi4 and all three zeta symbols without
selecting them. These are algebraic words, not physical experiments.

Explicit mutations change264q-density words when C_cmp is omitted,208when
C_raw is omitted,8when the power term is omitted,752when the boundary is omitted,
and480Ward words when the counterterm sign is reversed. The missing curvature
g² control has108wrong coupling-degree words. These are actual calculated
differences, not complete inventory counts mislabeled as omissions.

Family artifact packed/rawSHA256:
a13389c2e9f77b66f43e8582f06db18582883be08cb9c0519867785e2f8d35b0 /
bd63cb5175b469411491e1757107366c3ffa559b0e51f02e3df9e4ad7f7abfd0.
P/R/V native0 in5.272361/196.070782/3.792300s afterimports,4/99/3samples,
private sampled maxima62205952/191139840/54431744B, not continuous peaks.
Eight sourcecopies,104/112bindings,pre-reportpacket166765B. All600s/8GiBsampled/
350MiBlaunch/16MiB bounds respected. No CHWworker/controller failed. Earlier
OGCmetadata errors/prelaunchfailure and every original record remain intact.
Currentturn OGT E4 is authenticated reuse,root0steps0/0/0/0/0/2,custody2seven
NOTPASS. External before/index/after seals must preserve33247oldblobs.

Shared action, formal comparator/analytic-domain assumptions, old quantum
coefficients, word conventions, SymPy and AI authorship limit independence.
Agreement is computational/analytic corroboration, not external expert or
physical validation. The relatively slow independent replay is preserved;
no complete expensive old calculation was repeated to obtain this result.

## Remaining scientific task

Next reconcile this closed-matter family with the existing HSC common open-
matter/source family in one exact-once local functional. HSC already tests the
one-jet, vector, scalar and highest-K_PccP projections; do not recalculate those
known loops or redeclare their current parents missing. Preserve the old
bosonic J_B,J_x,J_C source coefficients exactly once: their matter Euler
companions are essential even where their closed-fermion-loop source graphs
are1PRzero. Differentiate sources before J0, retain the hatted auxiliary Euler
term and keep the proper matter source distinct from an MSP primitive.

A complete coupled result needs a justified full parent/insertion domain,
not the assumption that two separately successful Ward families automatically
combine. Positive-dimension/vacuum transport, external backgrounds/hats,
renormalized multiple products/QAP, measure/global and nonlocal phase, massive
matching and physical causal limits remain separate. No full E5/A5 or physical
GUT qualification follows. Both adverse scalar configurations, quartetFAIL,
flavorpause,HB1/C5blocks and independent finite freedoms persist. No agents,
branch/worktree,push,outreach,publication,physicalscheme or foundation adopted.
Whole Spin(10)xPQ investigation remains ACTIVE/incomplete; authority34/39.
