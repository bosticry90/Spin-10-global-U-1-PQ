from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');g=s.Symbol('g10',real=True);chi,zg,zm,zv=s.symbols('chi4 zeta_g zeta_M zeta_V',real=True);t=s.Symbol('t',positive=True)
local={'g10':g,'chi4':chi,'zeta_g':zg,'zeta_M':zm,'zeta_V':zv,'t':t}
def decp(rows):return {tuple((k,n,tuple(ds)) for k,n,ds in w):s.sympify(v,locals=local) for w,v in rows}
def clean(d):return {k:s.expand(v) for k,v in d.items() if s.expand(v)!=0}
def diff(a,b):return clean({k:a.get(k,0)-b.get(k,0) for k in set(a)|set(b)})
for k in ['counterterm_density','Ward_image','direct_q_density','boundary_divergence']:assert not diff(decp(P[k]),decp(R[k]))
for a,b in zip(P['boundary_current'],R['boundary_current']):assert not diff(decp(a),decp(b))
W=decp(P['Ward_image']);Q=decp(P['direct_q_density']);DJ=decp(P['boundary_divergence']);assert not diff(diff(Q,W),DJ)
K=decp(P['counterterm_density']);pole=decp(P['pole_density']);raw=decp(P['raw_finite_density']);cmp=decp(P['comparison_density']);power=decp(P['power_density']);inv=decp(P['invariant_density'])
assert not diff(K,clean({w:raw.get(w,0)-cmp.get(w,0)+power.get(w,0)+inv.get(w,0) for w in set(raw)|set(cmp)|set(power)|set(inv)}))
# Explicit coefficient-degree check catches the compact prose missing-g² error.
pure_gauge=[(w,v) for w,v in pole.items() if all(k in ['L','R'] for k,n,ds in w)]
for w,v in pure_gauge:
 assert s.simplify(v/g**len(w)).has(g)==False
 assert s.Poly(v,g).degree()==len(w)
for sym in [chi,zg,zm,zv]:assert all(s.expand(v).coeff(sym)==0 for v in W.values())
# Actual transpose quotient, only oneghost so no graded cyclic ambiguity.
swap={'L':'R','R':'L','cL':'cR','cR':'cL'}
def cyc(w):return min(w[j:]+w[:j] for j in range(len(w)))
def actual(d):
 out={}
 for w,v in d.items():
  rev=tuple((swap.get(k,k),n,ds) for k,n,ds in reversed(w));sign=(-1)**sum(k in swap for k,n,ds in w);a,b=cyc(w),cyc(rev)
  if a==b and sign==-1:continue
  key=min(a,b);out[key]=out.get(key,0)+(1 if key==a else sign)*v
 return clean(out)
physicalW=actual(W)
linear3=cyc((('L',0,(0,0,0)),('cL',-1,())));linear1=cyc((('L',0,(0,)),('cL',-1,())))
Kfinite=s.simplify(-physicalW[linear3]/g**2);Kpower=s.simplify(t*physicalW[linear1]/g**2)
for field in ['cG_dimensional_finite_p2_coefficient','cG_heat_power_t_coefficient','cG_heat_finite_p2_coefficient']:
 assert s.simplify(s.sympify(P[field])-s.sympify(R[field]))==0
Dunit=s.sympify(P['cG_dimensional_finite_p2_coefficient']);Hfinite=s.sympify(P['cG_heat_finite_p2_coefficient']);Hpower=s.sympify(P['cG_heat_power_t_coefficient'])
assert Dunit!=0 and Hpower!=0 and Dunit==Hfinite and s.simplify(Hfinite+Kfinite)==0 and s.simplify(Hpower+Kpower)==0
assert P['Hermitian_density_verified'] and P['comparator_trace_odd_chi_zero'] and R['comparator_trace_odd_chi_zero'] and P['comparator_Gaussian_translation_identity'] and R['comparator_Gaussian_translation_identity']
# Preserve actual old measured parent and local odd coverage qualification/corrections.
BWF=CAL/'canonical_so10_bosonic_fermion_finite_ward';OGC=CAL/'canonical_so10_odd_gauge_local_coverage'
assert digest(BWF/'validation_receipt.json')=='49a9e814cde68fd165d1d42732cc12b2fc1421be8407b48290da23d0c65a6e0a'
assert digest(OGC/'control_receipt_v3.json')=='92e87d7988fa5f78b18f8d6a6344b8884c1e70a956b46b636e91b40c4ab35b13'
assert read(OGC/'validation_receipt.json')['actual_selected_odd_local_variation']==0
Agram=dec(packed(CAL/'canonical_so10_fermion_gauge_finite_difference/primary_tables.json.gz')['G']);Bgram=dec(packed(CAL/'canonical_so10_fermion_gauge_finite_difference/replay_tables.json.gz')['G']);zero(Agram-Bgram);assert Agram==2*s.eye(45)
# Explicit changes, not inventory counts masquerading as omission tests.
controls={}
for tag,part in [('omit_comparator',decp(P['comparison_q_density'])),('omit_raw',decp(P['raw_q_density'])),('omit_power',decp(P['power_q_density'])),('omit_boundary',DJ)]:
 controls[tag+'_changed_q_density_words']=len(diff(Q,clean({w:Q.get(w,0)-part.get(w,0) for w in set(Q)|set(part)})))
controls['wrong_counterterm_sign_changed_Ward_words']=len(diff(W,{w:-v for w,v in W.items()}))
wrongpole={w:v/g**2 for w,v in pure_gauge};controls['missing_gauge_g2_prefactor_wrong_typed_words']=sum(s.Poly(v,g).degree()!=len(w) for w,v in wrongpole.items())
assert all(v>0 for v in controls.values())
artifact={'schema':'CHW1_REFERENCE_MATCHED_CLOSED_MATTER_GAUGE_WARD_NORMALIZATION_FAMILY','common_loop_factor':'1/(16pi^2)','counterterm_density':P['counterterm_density'],'Ward_image':P['Ward_image'],'boundary_current':P['boundary_current'],'counterterm_definition':'Craw-Ccmp+Kpower+independent_invariants; Craw here means stored finitepart','reference_quantum_Ward_scope':'FORMAL_PARITY_EVEN_ANTICOMMUTING_CHI_GRAPH_SERIES;NONEXCEPTIONAL_EUCLIDEAN;ODD_PHYSICAL_LOCAL_COVERAGE_FROM_OGC','reference_matching_map_constructed_but_physical_scheme_not_adopted':True,'complete_closed_parent_family_coverage_reused':True,'direct_actual_even_cG_dimensional_finite':str(Dunit),'direct_actual_even_cG_heat_power':str(Hpower),'direct_actual_even_cG_heat_finite':str(Hfinite),'counterterm_even_cG_power':str(Kpower),'counterterm_even_cG_finite':str(Kfinite),'free_real_parameters':['chi4','zeta_g','zeta_M','zeta_V'],'chi4_convention':'1+log(16pi)-n_log;NO_BASELINE_SELECTED','all_source_open_background_measure_phase_QAP_Slavnov_or_E5A5_proved':False,'CSH_prefactor_correction':str(ROOT/'docs/CSH1_COMPACT_CURVATURE_FACTOR_CORRECTION_V1.md')}
rawbytes=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(rawbytes,mtime=0)
with (HERE/'closed_heat_ward_normalization_family.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_SELECTED_CLOSED_MATTER_HEAT_GAUGE_WARD_NORMALIZATION_FAMILY','elapsed_after_imports':time.perf_counter()-start,'counterterm_generic_words':len(K),'counterterm_physical_quotient_words':len(actual(K)),'Ward_image_words':len(W),'boundary_divergence_words':len(DJ),'Ward_identity_remainder_nonzero':0,'explicit_pure_gauge_coupling_degrees_verified':True,'CSH_compact_g2_prefactor_corrected_by_append_only':True,'actual_even_cG_dimensional_finite':str(Dunit),'actual_even_cG_heat_power':str(Hpower),'actual_even_cG_heat_finite':str(Hfinite),'counterterm_even_cG_power':str(Kpower),'counterterm_even_cG_finite':str(Kfinite),'selected_even_cG_sum_remainders':['0','0'],'actual_model_Gram_positions_reused':2025,'negative_control_changed_words':controls,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(rawbytes).hexdigest(),'physical_scheme_adopted':False,'full_chiral_Slavnov_source_QAP_measure_phase_proved':False,'scientific_acceptance':'NOT_PERFORMED','scientific_authority_changed':False,'authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
