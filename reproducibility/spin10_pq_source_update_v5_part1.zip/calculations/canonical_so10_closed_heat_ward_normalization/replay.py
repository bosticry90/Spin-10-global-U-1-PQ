from data import *
from itertools import product
start=begin('replay');g=s.Symbol('g10',real=True);chi4,zg,zm,zv=s.symbols('chi4 zeta_g zeta_M zeta_V',real=True);t=s.Symbol('t',positive=True);reg={};lookup={}
def jet(kind,mu=-1,ds=()):
 token=(kind,mu,tuple(sorted(ds)))
 if token not in lookup:
  z=s.Symbol(kind+str(mu)+'d'+''.join(map(str,token[2])),commutative=False);lookup[token]=z;reg[z]=token
 return lookup[token]
keys=[(k,mu) for k in ['L','R'] for mu in range(4)]+[('U',-1),('V',-1)]
F={key:jet(*key) for key in keys};Var={key:jet('v'+key[0],key[1]) for key in keys};U,V=F['U',-1],F['V',-1];CL,CR=jet('cL'),jet('cR')
def terms(expr):
 for term in s.Add.make_args(s.expand(expr)):
  cc,nc=term.args_cnc();co=s.Mul(*cc);word=[]
  for z in nc:
   if z.is_Pow:assert z.exp.is_Integer and z.exp>0;word.extend([z.base]*int(z.exp))
   else:word.append(z)
  if co!=0:yield co,tuple(word)
def D(expr,mu):
 out=0
 for co,w in terms(expr):
  for j,z in enumerate(w):
   kind,n,ds=reg[z];out+=co*s.Mul(*w[:j])*jet(kind,n,ds+(mu,))*s.Mul(*w[j+1:])
 return s.expand(out)
comm=lambda x,y:x*y-y*x
Q={}
for kind,C in [('L',CL),('R',CR)]:
 for mu in range(4):Q[kind,mu]=D(C,mu)-s.I*g*comm(F[kind,mu],C)
Q['U',-1]=s.I*g*(CR*U-U*CL);Q['V',-1]=s.I*g*(CL*V-V*CR)
def change(expr,q=False):
 out=0
 for co,w in terms(expr):
  for j,z in enumerate(w):
   kind,n,ds=reg[z];value=(Q if q else Var)[kind,n]
   for mu in ds:value=D(value,mu)
   out+=co*s.Mul(*w[:j])*value*s.Mul(*w[j+1:])
 return s.expand(out)
def rows(expr,cyclic=True):
 out={}
 for co,w in terms(expr):
  token=tuple(reg[z] for z in w)
  if cyclic and token:token=min(token[j:]+token[:j] for j in range(len(token)))
  out[token]=s.expand(out.get(token,0)+co)
 return [[[[k,n,list(ds)] for k,n,ds in w],str(v)] for w,v in sorted(out.items()) if v!=0]
def zero(expr):assert not rows(expr)
def rowdict(expr):return {tuple((k,n,tuple(ds)) for k,n,ds in w):s.sympify(v,locals={'g10':g}) for w,v in rows(expr)}
def fromrows(rr,rename=None):
 out=0
 for w,v in rr:out+=s.sympify(v,locals={'g10':g})*s.Mul(*(jet(rename if rename and k=='A' else k,n,ds) for k,n,ds in w))
 return out
c2=chi4-s.Rational(5,12);c3=chi4+s.log(s.Rational(3,2))+s.Rational(1,2);c4=chi4+s.log(2)+s.Rational(5,6)
a1=g*g*((c2+zg)/6-s.Rational(1,12));a2=-g*g*(c2+zg)/6;ac=-s.I*g**3*(c3+zg-1)/3
b1=g**4*((c4+zg)/6-s.Rational(1,4));b2=g**4*(-(c4+zg)/6+s.Rational(5,24));pg=g*g/(16*t)
k=(c2+zm)/2-s.Rational(1,6);a=s.I*g*((c3+zm)/2-s.Rational(1,3));b=g*g*((c4+zm)/2-s.Rational(2,3));c=g*g*(-c4-zm+s.Rational(5,6));d=(c4+zv)/2-s.Rational(5,12);pm=1/(4*t)
L=0;E={key:0 for key in keys};theta=[0]*4
for kind in ['L','R']:
 G=[F[kind,mu] for mu in range(4)];VG=[Var[kind,mu] for mu in range(4)];S=sum(z*z for z in G)
 for mu,nu in product(range(4),repeat=2):
  L+=a1*D(G[nu],mu)*D(G[nu],mu)+a2*D(G[nu],mu)*D(G[mu],nu)+ac*D(G[nu],mu)*comm(G[mu],G[nu])+b1*G[mu]**2*G[nu]**2+b2*G[mu]*G[nu]*G[mu]*G[nu]
 L+=pg*sum(z*z for z in G)
 for lam in range(4):
  E[kind,lam]=-2*a1*sum(D(D(G[lam],mu),mu) for mu in range(4))-2*a2*sum(D(D(G[mu],mu),lam) for mu in range(4))
  E[kind,lam]+=ac*sum(-comm(D(G[mu],mu),G[lam])+comm(G[mu],D(G[mu],lam))-2*comm(G[mu],D(G[lam],mu)) for mu in range(4))
  E[kind,lam]+=2*b1*(G[lam]*S+S*G[lam])+4*b2*sum(G[mu]*G[lam]*G[mu] for mu in range(4))+2*pg*G[lam]
 for mu in range(4):theta[mu]+=sum(2*a1*VG[nu]*D(G[nu],mu)+2*a2*VG[nu]*D(G[mu],nu)+ac*VG[nu]*comm(G[mu],G[nu]) for nu in range(4))
for mu in range(4):
 LL,RR=F['L',mu],F['R',mu];dU,dV=D(U,mu),D(V,mu)
 L+=k*dV*dU+a*(LL*(dV*U-V*dU)+RR*(dU*V-U*dV))+b*(LL*LL*V*U+RR*RR*U*V)+c*LL*V*RR*U
 E['L',mu]+=a*(dV*U-V*dU)+b*(LL*V*U+V*U*LL)+c*V*RR*U
 E['R',mu]+=a*(dU*V-U*dV)+b*(RR*U*V+U*V*RR)+c*U*LL*V
 E['U',-1]+=-k*D(D(V,mu),mu)+a*(2*LL*dV-2*dV*RR+D(LL,mu)*V-V*D(RR,mu))+b*(LL*LL*V+V*RR*RR)+c*LL*V*RR
 E['V',-1]+=-k*D(D(U,mu),mu)+a*(2*RR*dU-2*dU*LL+D(RR,mu)*U-U*D(LL,mu))+b*(U*LL*LL+RR*RR*U)+c*RR*U*LL
 theta[mu]+=k*(Var['V',-1]*D(U,mu)+Var['U',-1]*D(V,mu))+a*(Var['V',-1]*(U*LL-RR*U)+Var['U',-1]*(V*RR-LL*V))
L+=d*U*V*U*V+pm*V*U;E['U',-1]+=2*d*V*U*V+pm*V;E['V',-1]+=2*d*U*V*U+pm*U
zero(change(L)-sum(E[key]*Var[key] for key in keys)-sum(D(theta[mu],mu) for mu in range(4)))
J=[s.expand(theta[mu].xreplace({Var[key]:Q[key] for key in keys})+CL*E['L',mu]+CR*E['R',mu]) for mu in range(4)]
Wg=-sum(C*(D(E[kind,mu],mu)-s.I*g*comm(F[kind,mu],E[kind,mu])) for kind,C in [('L',CL),('R',CR)] for mu in range(4))
Wm=s.I*g*(CL*(V*E['V',-1]-E['U',-1]*U)+CR*(U*E['U',-1]-E['V',-1]*V));W=Wg+Wm;qL=change(L,True);divJ=sum(D(J[mu],mu) for mu in range(4));zero(qL-W-divJ)
for symbol in [chi4,zg,zm,zv]:zero(s.diff(W,symbol))
# Independent Schwinger/beta exact dimensional cG moment and heat source derivative.
e,p2=s.symbols('epsilon p2',positive=True);h=-2*e
whole=-h*s.gamma(e-1)*s.gamma(2-e)**2/s.gamma(4-2*e)*p2**(-e)
dim=s.simplify(s.limit(whole,e,0))
aint=s.Symbol('proper',nonnegative=True)
heatpower=s.simplify(8*t*t*s.integrate((aint+4*t)**(-3),(aint,0,s.oo)))
heatfinite=s.simplify(8*t*s.integrate(-2*t/(aint+4*t)**3+4*t*t/(aint+4*t)**4,(aint,0,s.oo)))
# Comparator finite matrix telescope and formal Gaussian shift as independent checks.
cL=s.Matrix([[1,2],[0,-1]]);cR=s.Matrix([[0,1],[3,2]]);PL=s.diag(1,0);PR=s.diag(0,1)
AA=s.kronecker_product(PL,cL)+s.kronecker_product(PR,cR);At=s.kronecker_product(PR,cL)+s.kronecker_product(PL,cR)
DD=s.Matrix([[4,1,0,1],[0,3,1,0],[1,0,5,1],[0,1,0,2]]);qDD=At*DD-DD*AA
assert s.simplify(s.trace(DD.inv()*qDD)-s.trace(At-AA))==0 and s.trace(At-AA)==0
ss,j,P=s.symbols('proper j shift',positive=True);Ddim=s.Symbol('Ddim')
Z=ss**(-Ddim/2)*s.exp(j*j/(4*ss)-j*P)
assert s.simplify(s.diff(Z,P)+j*Z)==0
finish('replay',{'counterterm_density':rows(L),'Ward_image':rows(W),'direct_q_density':rows(qL),'boundary_current':[rows(v) for v in J],'boundary_divergence':rows(divJ),'cG_dimensional_finite_p2_coefficient':str(dim),'cG_heat_power_t_coefficient':str(heatpower),'cG_heat_finite_p2_coefficient':str(heatfinite),'comparator_trace_odd_chi_zero':True,'comparator_Gaussian_translation_identity':True,'no_full_chiral_reference_adopted':True},start)
