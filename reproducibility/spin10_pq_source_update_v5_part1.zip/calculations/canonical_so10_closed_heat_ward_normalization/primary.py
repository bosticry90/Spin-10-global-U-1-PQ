from data import *
from itertools import product
start=begin('primary');g=s.Symbol('g10',real=True);chi4,zg,zm,zv=s.symbols('chi4 zeta_g zeta_M zeta_V',real=True);heat_time=s.Symbol('t',positive=True)
def tok(k,mu=-1,ds=()):return (k,mu,tuple(sorted(ds)))
def field(k,mu=-1):return {(tok(k,mu),):s.S.One}
keys=[(k,mu) for k in ['L','R'] for mu in range(4)]+[('U',-1),('V',-1)]
CL,CR=field('cL'),field('cR')
def plus(*ps):
 out={}
 for p in ps:
  for w,v in p.items():out[w]=s.expand(out.get(w,0)+v)
 return {w:v for w,v in out.items() if v!=0}
def scale(p,a):return {w:s.expand(a*v) for w,v in p.items() if a*v!=0}
def mul(*ps):
 out={():s.S.One}
 for p in ps:
  new={}
  for a,x in out.items():
   for b,y in p.items():new[a+b]=s.expand(new.get(a+b,0)+x*y)
  out={w:v for w,v in new.items() if v!=0}
 return out
comm=lambda a,b:plus(mul(a,b),scale(mul(b,a),-1))
def partial(p,mu):
 out={}
 for w,v in p.items():
  for j,t in enumerate(w):
   nw=w[:j]+(tok(t[0],t[1],t[2]+(mu,)),)+w[j+1:];out[nw]=out.get(nw,0)+v
 return plus(out)
def trace(p):
 out={}
 for w,v in p.items():
  nw=min(w[j:]+w[:j] for j in range(len(w))) if w else w;out[nw]=out.get(nw,0)+v
 return plus(out)
def decode(rows,rename=None):
 out={}
 for ww,v in rows:
  w=tuple(tok(rename if rename and k=='A' else k,mu,ds) for k,mu,ds in ww);out[w]=s.sympify(v,locals={'g10':g})
 return out
BWF=packed(CAL/'canonical_so10_bosonic_fermion_finite_ward/primary_tables.json.gz')
Ig,Im,Iv=[decode(BWF['invariant_densities'][k]) for k in ['gauge','mass_kinetic','potential']]
S=trace(plus(scale(Ig,g*g/6),scale(Im,s.Rational(1,2)),scale(Iv,s.Rational(1,2))))
cs={2:chi4-s.Rational(5,12),3:chi4+s.log(s.Rational(3,2))+s.Rational(1,2),4:chi4+s.log(2)+s.Rational(5,6)}
raw=trace({w:s.expand(v*cs[len(w)]) for w,v in S.items()});cmp=decode(BWF['density'])
power=trace(plus(*(scale(mul(field(k,mu),field(k,mu)),g*g/(16*heat_time)) for k in ['L','R'] for mu in range(4)),scale(mul(field('V'),field('U')),1/(4*heat_time))))
inv=trace(plus(scale(Ig,zg*g*g/6),scale(Im,zm/2),scale(Iv,zv/2)))
L=trace(plus(raw,scale(cmp,-1),power,inv));U,V=field('U'),field('V')
def qfield(kind,mu=-1):
 if kind in ['L','R']:
  C=CL if kind=='L' else CR
  return plus(partial(C,mu),scale(comm(field(kind,mu),C),-s.I*g))
 if kind=='U':return scale(plus(mul(CR,U),scale(mul(U,CL),-1)),s.I*g)
 assert kind=='V';return scale(plus(mul(CL,V),scale(mul(V,CR),-1)),s.I*g)
def q(poly):
 out={}
 for w,v in poly.items():
  for j,t in enumerate(w):
   qt=qfield(t[0],t[1])
   for mu in t[2]:qt=partial(qt,mu)
   out=plus(out,scale(mul({w[:j]:1},qt,{w[j+1:]:1}),v))
 return out
E={key:{} for key in keys};theta=[{} for _ in range(4)]
for w,v in L.items():
 for j,t in enumerate(w):
  rest={w[j+1:]+w[:j]:v};key=t[:2]
  if not t[2]:E[key]=plus(E[key],rest)
  else:
   assert len(t[2])==1;mu=t[2][0];E[key]=plus(E[key],scale(partial(rest,mu),-1));theta[mu]=plus(theta[mu],mul({(tok('v'+t[0],t[1]),):1},rest))
def qtheta(poly):
 out={}
 for w,v in poly.items():
  factors=[qfield(t[0][1:],t[1]) if t[0].startswith('v') else {(t,):1} for t in w];out=plus(out,scale(mul(*factors),v))
 return out
J_current=[trace(plus(qtheta(theta[mu]),mul(CL,E['L',mu]),mul(CR,E['R',mu]))) for mu in range(4)]
Wg=scale(plus(*(mul(C,plus(partial(E[kind,mu],mu),scale(comm(field(kind,mu),E[kind,mu]),-s.I*g))) for kind,C in [('L',CL),('R',CR)] for mu in range(4))),-1)
Wmass=scale(plus(mul(CL,plus(mul(V,E['V',-1]),scale(mul(E['U',-1],U),-1))),mul(CR,plus(mul(U,E['U',-1]),scale(mul(E['V',-1],V),-1)))),s.I*g)
W=trace(plus(Wg,Wmass));qL=trace(q(L));divJ=trace(plus(*(partial(J_current[mu],mu) for mu in range(4))));assert not trace(plus(qL,scale(W,-1),scale(divJ,-1)))
# Reality of the local even density, including explicit power matching.
swapstar={'U':'V','V':'U'}
star=trace({tuple((swapstar.get(k,k),mu,ds) for k,mu,ds in reversed(w)):s.conjugate(v) for w,v in L.items()});assert not trace(plus(L,scale(star,-1)))
for sym in [chi4,zg,zm,zv]:assert not trace({w:s.expand(v).coeff(sym) for w,v in W.items()})
# Direct actual cG even numerator and dimensional/positive-heat integrals.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gamma=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];ch=s.diag(1,1,-1,-1);PL=(s.eye(4)+ch)/2;PR=s.eye(4)-PL
num1=[];num2=[]
for mu,a in product(range(4),repeat=2):
 v1=s.trace(gamma[mu]*PL*gamma[a]*PR)+s.trace(gamma[mu]*PR*gamma[a]*PL)
 v2=s.trace(gamma[a]*gamma[mu]*PL)+s.trace(gamma[a]*gamma[mu]*PR)
 assert v1==v2==4*int(mu==a);num1.append(str(v1));num2.append(str(v2))
e,Delta,x,p2=s.symbols('epsilon Delta x p2',positive=True);h=-2*e
hat=(h/2)*s.gamma(e-1)*Delta**(1-e);hat0=s.simplify(s.limit(hat,e,0));phase=s.simplify(s.Rational(1,2)*(-s.I)**2*(-s.I));dim=s.simplify((phase/s.I)*(-s.sympify(num1[0]))*s.integrate(hat0.subs(Delta,x*(1-x)*p2),(x,0,1))/p2)
a=s.Symbol('a',nonnegative=True);u,z=s.symbols('u z',positive=True)
# Shifted Gaussian source integral; the changevariable is exact.
J=s.integrate(u*s.exp(-z*(2-u)),(u,0,1))/(8*heat_time)
heat_power=s.simplify(s.limit(4*heat_time*J,z,0));heat_finite=s.simplify(s.limit(s.diff(4*heat_time*J,z),z,0))
# Formal comparator trace telescope and dimensional Gaussian shift.
def inverse_trace_reduce(w):
 w=list(w)
 while len(w)>1:
  hit=None
  for n in range(len(w)):
   if (w[n],w[(n+1)%len(w)]) in [('D','S'),('S','D')]:hit=n;break
  if hit is None:break
  w=w[hit:]+w[:hit];w=w[2:]
 return min(tuple(w[j:]+w[:j]) for j in range(len(w))) if w else ()
assert inverse_trace_reduce(('S','At','D'))==('At',) and inverse_trace_reduce(('S','D','A'))==('A',)
assert s.trace(PL-PR)==0
Ddim,proper,j,shift=s.symbols('Ddim proper j shift',positive=True)
Z=proper**(-Ddim/2)*s.exp(j*j/(4*proper)-j*shift)
assert s.simplify(s.diff(Z,shift)+j*Z)==0
encp=lambda poly:[[[[k,n,list(ds)] for k,n,ds in w],str(v)] for w,v in sorted(trace(poly).items())]
finish('primary',{'counterterm_density':encp(L),'raw_finite_density':encp(raw),'comparison_density':encp(cmp),'power_density':encp(power),'invariant_density':encp(inv),'pole_density':encp(S),'Ward_image':encp(W),'direct_q_density':encp(qL),'boundary_current':[encp(v) for v in J_current],'boundary_divergence':encp(divJ),'Hermitian_density_verified':True,'raw_q_density':encp(trace(q(raw))),'comparison_q_density':encp(trace(q(cmp))),'power_q_density':encp(trace(q(power))),'cG_numerator1':num1,'cG_numerator2':num2,'cG_dimensional_finite_p2_coefficient':str(dim),'cG_heat_power_t_coefficient':str(heat_power),'cG_heat_finite_p2_coefficient':str(heat_finite),'shifted_heat_vector_integral':str(J),'comparator_trace_odd_chi_zero':True,'comparator_Gaussian_translation_identity':True,'no_full_chiral_reference_adopted':True},start)
