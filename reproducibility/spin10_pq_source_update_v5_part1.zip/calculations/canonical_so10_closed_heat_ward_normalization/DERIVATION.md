# CHW1 quantum comparison and explicit normalization, not a fitted breaking

Let Gamma_cmp be the coefficientwise parity-even reference graph series defined
by the full-anticommuting chi algebra of SYR. Oddchi traces are0 by definition;
this is expressly not the physical epsilon trace or a full chiral quantum
measure. At physical external hats0 its actual bilateralmatrix operator obeys
qDcmp=ig(AtDcmp-Dcmp A). In the common analytic dimensional graph domain,
cyclic finite matrix/spin traces and loop translation telescope -Trlog/2:
qGamma_cmp=-ig Tr(At-A)/2=0. This manipulation is made before pole/finitepart
extraction, never by moving an arbitrary heat factor inside a renormalized trace.

Translation is fixed by the Schwinger generating Gaussian:
Z_D(s,J,P)=s^(-D/2)exp(J²/(4s)-J.P). Shifting loop variables and differentiating
sources preserve all tensor moments meromorphically. Nonexceptional momenta
and the existing one-variation Schwartz bounds control internalIRsingularities.
All ghost-zero poles are the covariant UVdensity g²Ig/6+Im/2+Iv/2, independently
measured. Their subtraction and invariant finite directions preserve Ward.
No global determinant or general multipleproduct limit follows.

Measured quantum equalities are
GammaD_even-Gammaheat_even=Craw (power+localfinite),
GammaD_even-Gammacmp_even=Ccmp (the independent BWFcomparison).
Thus Gammaheat_even+K=Gammacmp_even+invariants with K=Craw-Ccmp+invariants.
Actual OGCoddlocalvariation iszero, so this supplies the selected closedmatter
Ward family without guessing an unmeasured insertion or its opposite. Complete
parentcoverage and comparatorWard proof are essential hypotheses; the identity
alone is not a full quantum action principle. All actual boundary transgressions
are retained by old immutable input and the new explicit qK=W+partialJ.

Use Craw_finite=sum_(n=2..4)c_n S_n with S_n fielddegreepieces of
S=g²Ig/6+Im/2+Iv/2,c2=chi4-5/12,c3=chi4+log(3/2)+1/2,c4=chi4+log2+5/6.
The explicit g² is essential; bind appended CSHcompactformula correction.
The common chi4 part is invariant and drops from W, without choosing n_log.
K_power=g²sum_muTr(L_mu²+R_mu²)/(16t)+TrVU/(4t). Its Ward image is nonzero
and cancels the actual cutoff power response. Defining this candidate matching
map is not applying a physical normalization to the project.

Direct cG: physical spin traces of each of the two Ihat orientations give
4G_ab timesr_mu andk_mu. Their difference is-4G_ab p_mu. The actual Gaussian/
propagator/vertex phase is+i g²/2. FeynmanparameterDelta=x(1-x)p² and
16pi²int hatl²/(l²+Delta)²=(h/2)Gamma(eps-1)Delta^(1-eps),h=-2eps.
Derive the finite integral before setting hats0. For heat, only the shifted
positiveGaussian contributes to intk_mu/Q E(k)(1-E(k-p)); its vector integral
is 2t int_0^infty da/(a+4t)^3 exp[-2t p²+4t²p²/(a+4t)]. Reduce independently
to int_0^1 u exp[-z(2-u)]du/(8t),z=t p². Derive its power andfinite terms
from the integral, not from the counterterm target. The old CSHoddtrace result
is not used for this even coefficient. A source-free Jacobian tangent trace
has no cG fielddegree and does not replace the cutoff response.
