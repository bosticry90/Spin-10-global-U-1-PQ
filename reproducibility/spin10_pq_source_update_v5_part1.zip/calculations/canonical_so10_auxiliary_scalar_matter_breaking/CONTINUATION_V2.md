# ASB1 V2: completed quantum inputs reused; exact sparse gate continuation

Original primary/replay completed in500.2725145/104.4792678s within the frozen
600s limit, producing authenticated full tables. The original verifier then
exhausted600s, native124, after printing its kernel/generic-Euler stage. It
produced no comparison table or validation receipt. The precise last internal
step is unknown. Preserve original sources/copies/preparation, validation
manifest, full native captures and controller failure unchanged. Its execution
is FAILED; scientific disposition is INCOMPLETE_RESOURCE_LIMIT, not PASS or
a scientific refutation. Neither completed quantum method is repeated.

Local read-only inspection of installed SymPy's matrix_kronecker_product
shows repeated row/column joins. A new verifier represents exactly the same
tensor product by its sparse coefficients

 (A tensor B)_(i*m+k,j*n+l)=A_ij B_kl.

Cache the fixed endpoint/source operators and repeated exact programs. No
input, equation, coefficient, zero complement, mass-map comparison, physical
projection, generic Grassmann sign proof, covariance test or negative control
is removed. Sparse absent entries are exact zeros; cache eviction only
recomputes an operator. This is an algebraic representation change, not a
truncated proof or a result fitted to the source comparison.

Freeze continuation/verify_v2/prepare_v2/run_v2 and copies; authenticate all
original bindings, completed quantum tables/resources and failed gate capture
before launching the new gate. Fresh read-only byte preflight here; the E4
command already completed in this goal turn is authenticated, not rerun.
Custody remains exit2/seven NOTPASS. Current AGENTS unchanged and binding.

Same600s after imports,8GiB sampled private cap,350MiB launch floor,16MiB
packet. First failure stops; no resource increase. Source/quantum separation
and all scientific authority ceilings unchanged. State113/34of39 unchanged;
no physical scheme or model adopted, no agents, branch/worktree, external
action, publication or push. Whole investigation remains active/incomplete.
