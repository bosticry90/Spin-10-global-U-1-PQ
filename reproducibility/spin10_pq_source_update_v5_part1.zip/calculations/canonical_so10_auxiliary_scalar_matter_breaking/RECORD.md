# ASB1: actual auxiliary scalar matter-breaking family

Previous goal turn PROGRESS:CFC1 constructed the selected complete one-jet
matter correction and MDS1 classified higher support with32 paired zeros.
Whole Spin(10)xPQ investigation ACTIVE/incomplete. Base
d776b6cf628cebc96ee249826f79234fa7842a36/main31554 old tracked blobs.

Question: what is the actual degree-zero g10^2 Y breaking from the complete
four auxiliary cxPP profiles, and does it agree with the retained fixed
MSP1 scalar Euler companion? Calculate quantum coefficients before that
comparison. A zero,nonzero agreement,nonzero remainder or bounded method
failure is meaningful; no answer is imposed by desired restoration.

Freeze current AGENTS/CHARTER/state113/V526/local/solo/epistemic rules;
MDS1's complete selected witnesses; SMA1 positive mass/source/free PS
conventions; GTT1 paired actual H ghost tensor and iE blocks/phases;
YCT1 actual generators and full B10/B126 scalar maps/covariance; GYV1
actual real-scalar current Hessian/routing. The source primitive is a
separate comparison input. Workers authenticate its bytes before installing
an audit guard, then are denied its tables/coefficients and all CFC1 tables.
Only the verifier reads the fixed source target after both quantum methods.

Types/domain: one-loop1PI,physical external hats0,constant external scalar
for degree-zero local UV extraction, A=B=0 elsewhere,nonexceptional
Euclidean Feynman analytic family. The constant scalar denotes a local
Taylor coefficient, not a constant-vacuum/IR/adiabatic limit. Positive
mass-dimension coefficients,ordinary g3Y scalar profiles and all cBPP
coefficients remain separate. Preserve both chiralities and general complex
symmetric Y10/Y126. No physical flavor point,scheme,mass or vacuum adopted.

MDS1 supplies exactly four g2Y profiles: E_C/E_S times fermion-line/scalar-
current placements. The normalized auxiliary vertex is+i xi H_ra,c,
G_BL(k)=-k/k2,G_LB(k)=+k/k2,ghost covariance1/k2. H is real and antisymmetric
in r,a. Physical fermion vertices are -ig bar_gamma A_r and positive
V_M=PL M+PR Mdagger; iE_SP=-g hatk A_a,iE_PS=+g Atilde_a hatk. Retain
matrix order,external eta/source probe,actual cumulants and Nambu factors.

Primary differentiates the actual free PS and bosonic resolvents. It checks
explicit split-Clifford matrices,scalar-current polarization/routing and
both chiral open numerators,then evaluates the joint Gamma moments before
analytic h=-2epsilon. Replay independently derives four-vertex Berezin
and bosonic Wick signs,abstract bar/hat Clifford words and Schwinger
Gaussian moments. Both transport to actual H/T/B tensors separately;
primary uses direct products/Kronecker operators,replay component-index
contractions and qualified Lie reduction. No comparison-target coefficient
defines either loop input. Reuse qualified H/YCT data,not old science replay.

The scalar-current vector index has two bosonic ends and is full D under
the inherited metric lift. Its contraction k2 includes bar k2+hat k2.
Keep the finite hat4 contribution. A fermion gauge endpoint is barred.
Use positive auxiliary IR mass to isolate primitive local UV residues;
UV/IR-convergent differences with explicit h vanish in the declared
nonexceptional domain. No scaleless full amplitude is assigned0.

Expected evidence: complete four-witness coverage,matching independent raw
units/radial limits/ordered operator programs,all45 ghost directions and
both256x328 scalar maps including zeros,conjugate mass-map reality and
symmetry,polynomial xi dependence,correct factorized family transport.
Store compact exact operator programs plus their total model maps; do not
expand numerical three-family/flavor coefficients or truncate the domain.
Assess the fixed source Euler image only after independent calculation.
Retain currents and the other scalar/gauge/hatted source companions.

Controls: prematurely bar the scalar-current contraction,drop a fermion
or scalar orientation,wrong scalar Bose factor,wrong insertion/propagator
orientation and extra Nambu half. Report actual insensitive limits. The
ordered mass operators precede the physical symmetric-Majorana quotient;
report omission sensitivity both there and after that projection. An
antisymmetric internal mass matrix is not a new physical Yukawa operator.
The
source comparison uses its full alternating quadratic mass flow,not an
ordinary transpose chosen to cancel a loop. A generic Grassmann density
checks its sign and factor before coefficient comparison. A successful
selected match is not the complete coupled bosonic/matter prescription;
possible bosonic-source fermion Euler terms remain a separate assessment.

Freeze eight sources/copies and immutable bindings before sequential
workers/gate. Each600s after imports,8GiB sampled private cap,350MiB launch
available-commit floor,16MiB packet. Compile prelaunch; stop first failure,
preserve all sources/full captures and version any correction. Run the
delegated non-fresh E4 readiness command this goal turn,retain custody
exit2/seven NOTPASS,and a fresh byte preflight. No historical science replay.

Authority ceiling: selected bare formal auxiliary scalar breaking and its
fixed primitive comparison only. State113/34of39 unchanged. No full finite
Slavnov/background/QAP/products/measure/phase,physical chiral prescription,
massive C1,E5/A5 or unification claim. Both adverse scalar benchmarks,
quartetFAIL,flavorpause,HB1/C5blocks and custody2/seven persist. No agents,
branch/worktree,old evidence edit,foundation/scheme change,publication,
outreach or push. Shared action/inputs/software/AI author limit independence.

Track B asks whether independent direct/open-resolvent and word/Gaussian
calculations can retain a finite full-D term while avoiding target fitting.
Use this actual calculation record,not a separate benchmark framework.
