"""ASB1 exact Berezin/Wick, abstract Clifford words and Schwinger moments."""
from data import *
from collections import defaultdict
from functools import lru_cache
start=begin('replay')
@lru_cache(maxsize=65536)
def simp(v):return s.simplify(v)
def clean(d):return {k:s.expand(v) for k,v in d.items() if s.expand(v)!=0}
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return clean(out)
def scale(z,A):return clean({k:z*v for k,v in A.items()})
def wedge(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(10) if a&(1<<i))*x*y
 return clean(out)
def word(seq,co):
 out={0:co}
 for i in seq:out=wedge(out,{1<<i:1})
 return out
f1,f2,q,al,be,ce,de=s.symbols('f1 f2 q alpha beta gamma delta',nonzero=True);mass_sign=[]
for ew,vw in [([0,8,7,2],[3,4]),([0,8,3,4],[7,2])]:
 action={}
 for ww,co in [([4,5],-f1),([6,7],-f2),([8,9],-q),(ew,al),(vw,be),([5,6],ce),([9,1],de)]:action=add(action,word(ww,co))
 term=Z={0:s.S.One}
 for no in range(1,6):term=scale(-s.Rational(1,no),wedge(term,action));Z=add(Z,term)
 mask=sum(1<<i for i in range(4,10));z0=Z[mask];zext=Z[(1<<10)-1]
 mass_sign.append(simp(zext*f1*f2*q/(z0*al*be*ce*de)))
# Three-even-vertex cumulant reused only after exact independent word sum.
from itertools import permutations
tri=[]
for ww in [[[0,6,5,2],[3,4],[7,1]],[[0,6,3,4],[5,2],[7,1]]]:
 ss=[]
 for order in permutations(range(3)):
  w=sum((ww[i] for i in order),[]);ss.append((-1)**sum(w[i]>w[j] for i in range(8) for j in range(i+1,8)))
 tri.append(-s.Rational(sum(ss),6))
# Bosonic Wick derivative: -<Lambda z B z>_conn=-G_LambdaB G_zz.
ell,zz=s.symbols('ell zz');cov={tuple(sorted(v)):co for v,co in [(('L','B'),ell),(('z','z'),zz)]}
def wick(seq):
 if not seq:return s.S.One
 return sum(cov.get(tuple(sorted([seq[0],seq[i]])),0)*wick(seq[1:i]+seq[i+1:]) for i in range(1,len(seq)))
bose_sign=simp(-wick(['L','z','B','z'])/(ell*zz))
# Independent all-incoming routing: B momenta -k/+k at fermion endpoints.
k=s.symbols('k',nonzero=True);assert s.expand(k-k)==0
mixL=simp(bose_sign*(-s.I*(-k))*(-(-k))/k**2);mixR=simp(bose_sign*(+(-k))*(s.I*(-k))/k**2)
assert mixL==mixR
# Abstract Clifford words: b^2=B,h^2=H,bh=-hb; b flips physical chirality.
B,H=s.symbols('B H');aL,aR,rL,rR,m,md,n,nd=s.symbols('aL aR rL rR m md n nd')
def spin(seq,side):
 chir=side;co=s.S.One
 for v in reversed(seq):
  if v=='b':chir=1-chir
  elif v in ['Aa','Ata','Ar','V','Tau']:
   co*=({'Aa':[aL,aR],'Ata':[aR,aL],'Ar':[rL,rR],'V':[m,md],'Tau':[n,nd]}[v][chir])
 mask=0
 for v in seq:
  if v not in ['b','h']:continue
  bit=1 if v=='b' else 2
  co*=(-1)**((mask>>(1 if bit==1 else 2)).bit_count())
  if mask&bit:co*=B if bit==1 else H
  mask^=bit
 assert mask==0 and chir==side
 return s.expand(co)
phaseF1=mass_sign[0]*(-1)*(-s.I)**2*(-s.I)*s.I*(+1)
phaseF2=mass_sign[1]*(+1)*(-s.I)**2*(-s.I)*s.I*(-1)
phaseS1=tri[0]*(-1)*(-s.I)*mixL*s.I
phaseS2=tri[1]*(+1)*(-s.I)*mixR*s.I
seqs={'F_EC':['b','Ar','b','V','h','h','Aa'],'F_ES':['Ata','h','h','V','b','b','Ar'],'SC_EC':['Tau','h','h','Aa'],'SC_ES':['Ata','h','h','Tau']}
phases=dict(zip(seqs,[phaseF1,phaseF2,phaseS1,phaseS2]));charges={'F_EC':[rR*m*aL,rL*md*aR],'F_ES':[aR*m*rL,aL*md*rR],'SC_EC':[n*aL,nd*aR],'SC_ES':[aR*n,aL*nd]}
raw={};anti={}
for tag,seq in seqs.items():
 base=B*H if tag.startswith('F_') else H
 raw[tag]=simp(phases[tag]*spin(seq,0)/(base*charges[tag][0]));anti[tag]=simp(phases[tag]*spin(seq,1)/(base*charges[tag][1]))
 assert raw[tag]==anti[tag]
print('STAGE INDEPENDENT_BEREZIN_AND_WORD_NUMERATORS',flush=True)
eps,h,mu=s.symbols('epsilon h m2',positive=True)
# Differentiating independent bar/hat Gaussian variances gives these
# Schwinger factors before analytic continuation, not a fixed integer rank.
reg0=h*s.gamma(1+eps)*mu**(-eps)/(2*s.factorial(2));regB=h*4*s.gamma(1+eps)*mu**(-eps)/(4*s.factorial(3));regH=h*(h+2)*s.gamma(1+eps)*mu**(-eps)/(4*s.factorial(3))
finite=lambda z:simp(s.diff(z.subs(h,-2*eps),eps).subs(eps,0))
I0,IB,IH=map(finite,[reg0,regB,regH]);Ifull=finite(regB+regH);assert Ifull==I0
units={tag:simp(co*(IB if tag.startswith('F_') else Ifull)) for tag,co in raw.items()};badbar={tag:simp(co*IB) for tag,co in raw.items()}
# Independently collect the explicit ordered color words after covariance.
programs={'F_EC':{'J':-units['F_EC']},'F_ES':{'J':units['F_ES']},'SC_EC':{'R':s.I*units['SC_EC'],'J':s.I*units['SC_EC']},'SC_ES':{'L':-s.I*units['SC_ES'],'J':s.I*units['SC_ES']}}
aprograms={'F_EC':{'J':-units['F_EC']},'F_ES':{'J':units['F_ES']},'SC_EC':{'R':-s.I*units['SC_EC'],'J':s.I*units['SC_EC']},'SC_ES':{'L':s.I*units['SC_ES'],'J':s.I*units['SC_ES']}}
total={x:simp(sum(d.get(x,0) for d in programs.values())) for x in ['J','L','R']};atotal={x:simp(sum(d.get(x,0) for d in aprograms.values())) for x in ['J','L','R']}
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));Bs=[dec(Y[n]) for n in ['B10','B126']]
HH=[(r,a,c,s.sympify(co)) for r,a,c,co in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz')['plane_H']]
f=defaultdict(list)
for r,a,e,co in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[r,a].append((e,s.sympify(co)))
chco=defaultdict(lambda:s.S.Zero);jd=[defaultdict(lambda:s.S.Zero) for _ in range(45)];td=[t.todok() for t in T]
for r,a,c,co in HH:
 for e,v in f[r,a]:chco[c,e]+=s.I*co*v/2
 for (u,v),x in td[r].items():
  for (w,z),y in td[a].items():jd[c][v*16+z,u*16+w]+=co*x*y
CH=[sum((simp(v)*T[e] for (cc,e),v in chco.items() if cc==c),s.zeros(16)).applyfunc(simp) for c in range(45)]
J=[s.SparseMatrix(256,256,{key:simp(v) for key,v in row.items() if simp(v)!=0}) for row in jd]
models=[]
for Bmap in Bs:
 row={'holomorphic':[],'antiholomorphic':[]}
 # Index action of endpoint matrices, avoiding primary's Kronecker maps.
 for c,M in enumerate(CH):
  left=defaultdict(lambda:s.S.Zero);right=defaultdict(lambda:s.S.Zero);al=defaultdict(lambda:s.S.Zero);ar=defaultdict(lambda:s.S.Zero)
  for (flat,scalar),co in Bmap.todok().items():
   i,j=divmod(flat,16)
   for u in range(16):
    if M[i,u]:left[u*16+j,scalar]+=M[i,u]*co
    if M[j,u]:right[i*16+u,scalar]+=M[j,u]*co
   # Actual Mdagger map is the conjugate symmetric real-coordinate map.
   bc=s.conjugate(co)
   for u in range(16):
    if M[u,i]:al[u*16+j,scalar]+=M[u,i]*bc
    if M[u,j]:ar[i*16+u,scalar]+=M[u,j]*bc
  LM=s.SparseMatrix(256,328,{key:simp(v) for key,v in left.items() if simp(v)!=0});RM=s.SparseMatrix(256,328,{key:simp(v) for key,v in right.items() if simp(v)!=0})
  AL=s.SparseMatrix(256,328,{key:simp(v) for key,v in al.items() if simp(v)!=0});AR=s.SparseMatrix(256,328,{key:simp(v) for key,v in ar.items() if simp(v)!=0})
  jj=J[c]*Bmap;aj=s.conjugate(J[c])*s.conjugate(Bmap)
  row['holomorphic'].append(enc((WM*(total['J']*jj+total['L']*LM+total['R']*RM)).applyfunc(simp)))
  row['antiholomorphic'].append(enc((WM*(atotal['J']*aj+atotal['L']*AL+atotal['R']*AR)).applyfunc(simp)))
 models.append(row)
print('STAGE COMPLETE_COMPONENT_INDEX_MODEL_TRANSPORT',flush=True)
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cxPP']['remaining_internal_ghost_candidates'];support=[v for v in support if json.loads(v)[-3:-1]==[2,1]]
serialize=lambda d:{k:{x:str(simp(v)) for x,v in terms.items()} for k,terms in d.items()}
finish('replay',{'method':'four_vertex_Berezin_bosonic_Wick_abstract_Clifford_Schwinger_and_component_Lie_transport','mass_cumulant_units':list(map(str,mass_sign)),'three_vertex_units':list(map(str,tri)),'bosonic_insertion_unit':str(bose_sign),'raw_spin_units':{k:str(v) for k,v in raw.items()},'raw_conjugate_spin_units':{k:str(v) for k,v in anti.items()},'finite_moments':dict(zip(['I0','IB','IH','Ifull'],map(str,[I0,IB,IH,Ifull]))),'kernel_units':{k:str(v) for k,v in units.items()},'premature_barred_kernel_units':{k:str(v) for k,v in badbar.items()},'programs':serialize(programs),'antiprograms':serialize(aprograms),'total_program':{k:str(v) for k,v in total.items()},'total_antiprogram':{k:str(v) for k,v in atotal.items()},'CH':list(map(enc,CH)),'J_operators':list(map(enc,J)),'models':models,'supported_witnesses':support,'scalar_current_full_D':True,'no_extra_Nambu_half_or_family3':True,'source_target_read_to_fit_quantum_input':False,'quantum_operator_moments_computed_before_source_comparison':True,'new_two_loop_integrals':0,'full_restoration_claimed':False},start)
