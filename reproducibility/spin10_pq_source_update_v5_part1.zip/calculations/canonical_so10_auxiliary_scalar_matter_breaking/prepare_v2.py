"""ASB1 authenticates preserved gate exhaustion and freezes exact continuation."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/auxiliary-scalar-matter-breaking-v1-2026-10-23')
BASE='d776b6cf628cebc96ee249826f79234fa7842a36'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
for n,h in bind.items():assert digest(Path(n))==h,n
def add(p):
 p=p.resolve();bind[str(p)]=digest(p)
failed=read(HERE/'verify_capture.json')
assert failed==read(CONTROL/'verify_full_capture.json') and failed['exit_code']==124 and failed['execution_state']=='FAILED' and not failed['calculation_completed'] and failed['post_run_observations_qualified']
assert not any(v.startswith('RESULT ') for v in failed['stdout_and_stderr'].splitlines())
assert read(HERE/'controller_failure.json')['last_role']=='verify'
assert not (HERE/'validation_receipt.json').exists() and not (HERE/'comparison_tables.json.gz').exists()
for name in ['primary','replay']:
 c=read(HERE/(name+'_capture.json'));r=read(HERE/(name+'_result.json'));blob=(HERE/(name+'_tables.json.gz')).read_bytes()
 assert c==read(CONTROL/(name+'_full_capture.json')) and c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert r['elapsed_after_imports']<600 and c['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 assert [json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')]==[r]
 assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
 add(CONTROL/(name+'_full_capture.json'))
for n in ['validation_preparation.json','verify_capture.json','controller_failure.json']:add(HERE/n)
add(CONTROL/'verify_full_capture.json')
for n in ['CONTINUATION_V2.md','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
with (CONTROL/'v2_prelaunch_preflight.json').open('xb') as out,(CONTROL/'v2_prelaunch_preflight_stderr.txt').open('xb') as err:
 rr=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'v2_prelaunch_preflight.json');assert rr.returncode==0 and d['git_HEAD']==BASE and d['files_written']==0 and not d['active_A10_M08_python_processes']
assert d['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for n in ['v2_prelaunch_preflight.json','v2_prelaunch_preflight_stderr.txt']:add(CONTROL/n)
out={'schema':'ASB1_PREPARATION_V2','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'completed_quantum_workers_reused_not_rerun':True,'original_gate_scientific_disposition':'INCOMPLETE_RESOURCE_LIMIT','seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'readiness_command_executed_earlier_this_goal_turn':True,'fresh_byte_preflight_here':True,'scientific_acceptance':'NOT_PERFORMED'}
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,indent=2)+'\n').encode())
print('ASB1_V2_FROZEN',len(bind),'bindings',flush=True)
