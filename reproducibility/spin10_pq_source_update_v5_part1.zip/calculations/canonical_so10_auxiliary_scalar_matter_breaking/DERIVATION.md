# ASB1 ordered kernels before source comparison

Use bar momentum b,hat momentum h,K2=bar k2+hat k2. The actual free
S0=-i[[b,h],[h,b]]/K2 has N2=K2. A positive scalar insertion is diag(V,0),
V=PL M+PR Mdagger. Its derivative is S1=-S0 diag(V,0) S0,so
S1_PS=b V h/K2^2,S1_SP=h V b/K2^2. This is a resolvent identity,not a
new simple massive propagator or an assumption about its finite-hat poles.

Let A_a=PL T_a+PR U_a,U_a=-T_a.T and Atilde interchange PL/PR. The actual
iE blocks at physical external fermion hat0 are -g h A_a (E_C endpoint)
and+g Atilde_a h (E_S endpoint). Differentiate the GTT1 auxiliary open
graph with respect to the scalar before local momentum extraction. The
fermion-line chains,with overall g2 xi H_ra,c stripped,are

 (-i b A_r) S1_PS (-h A_a) (+1)(+i),
 (Atilde_a h) S1_SP (-i b A_r) (-1)(+i).

Here +/-1 retains the BL momentum orientation; b already contracts its
barred fermion end. S1 in these numerator chains means its numerator only.
Both denominators are K2^4 after including the ghost and mixed boson.
Primary derives their exact scalar coefficients; replay obtains the same
sign from the four-even-vertex cumulant without assuming a closed-loop sign.

For the actual scalar kinetic density1/2(d x+g rho B x)^2, polarization
about external scalar s gives deltaK_Bx(q)=+ig q(rho s).T and
deltaK_xB(q)=-ig q rho s. The convolution momentum is q=-k. Thus the
two ordered propagator derivatives are

 deltaG_xLambda=-G_xx deltaK_xB G_BL,
 deltaG_Lambda x=-G_LB deltaK_Bx G_xx.

Both have the bosonic factor -ig rho s/K2 after the full-D k.k contraction.
Check the signs before simplifying. The two open fermion numerators are
V_j(-i h)(-h A_a) and (Atilde_a h)(-i h)V_j. Include the+i xi H vertex
and full scalar propagator. Keeping k.k uncontracted gives denominator
K2^4 and numerator hat k2*(bar k2+hat k2). Cancellation of K2 before
auxiliary IR rearrangement has the same finite local limit; their difference
is convergent with explicit h and is checked,not silently discarded.

The required radial moments are I0=int hat k2/(K2+m2)^3,
IB=int hat k2 bar k2/(K2+m2)^4 and IH=int(hat k2)^2/(K2+m2)^4,
in16pi2 units. Derive Gamma/Schwinger expressions before h=-2epsilon.
IH can survive at order h/epsilon through its h(h+2) factor. Replacing the
full-D scalar contraction by bar k2 is a scientifically sensitive control.

Keep generic raw mass tensors U_r M T_a,U_a M T_r,tau_r(M)T_a,
U_a tau_r(M),and their conjugate-chirality tensors. The scalar-current
map is the actual tau_r(M)=i(T_r.T M+M T_r),tau_r(Mdagger)=
-i(T_r Mdagger+Mdagger T_r.T),from the qualified YCT1 full covariance.
It is not introduced to match a counterterm. Row-major vec is the actual
YCT convention: vec(A M B)=(A tensor B.T)vec(M).

For efficient exact transport define only action-derived operators
CH_c=sum_ra H_ra,c T_r T_a and
J_c(M)=sum_ra H_ra,c T_r.T M T_a. H antisymmetry relates the reversed
orders. Each independent raw unit determines its own coefficients on J,
CH.T M and M CH; do not set these coefficients from a proposed total.
Conjugate operators act on Mdagger with the verified transpose/reality rules.
Compact programs and their bound B10/B126 images cover every328 scalar
direction and all symbolic family factors without a flavor choice.

Only after both methods finish, compare with MSP1. With x=-i X^[3] and
x_R=-x_L.T,the negative source flow delta psi=-i c x_L psi gives the
holomorphic mass kernel i(x_R M-M x_L),and its conjugate kernel
i(x_L Mdagger-Mdagger x_R). Derive this from the alternating quadratic
Grassmann density including its1/2,not by transferring an untested ordinary
matrix sign. Retain scalar source/Euler terms before setting sources0.
This is one selected primitive companion,not the full renormalized QAP.
