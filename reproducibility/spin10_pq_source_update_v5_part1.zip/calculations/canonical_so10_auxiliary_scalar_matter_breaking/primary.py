"""ASB1 actual resolvent derivatives, split matrices, joint Gamma moments."""
from data import *
from collections import defaultdict
from functools import lru_cache
start=begin('primary')
@lru_cache(maxsize=65536)
def simp(v):return s.simplify(v)
def tidy(M):return s.SparseMatrix(M).applyfunc(simp)
def zero(M):assert not tidy(M).todok()
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gam=[s.kronecker_product(v,pa[2]) for v in g4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
chi=s.prod(gam[:4]);PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL;O=s.zeros(8)
k=s.symbols('k0:6');b=sum((k[i]*gam[i] for i in range(4)),O);hh=sum((k[i]*gam[i] for i in [4,5]),O)
B=sum(v*v for v in k[:4]);HH=sum(v*v for v in k[4:]);K=B+HH
zero(b*b-B*s.eye(8));zero(hh*hh-HH*s.eye(8));zero(b*hh+hh*b);zero(chi*hh-hh*chi)
aL,aR,rL,rR,m,md,n,nd=s.symbols('aL aR rL rR m md n nd')
Aa=aL*PL+aR*PR;Ata=aR*PL+aL*PR;Ar=rL*PL+rR*PR;V=m*PL+md*PR;Tau=n*PL+nd*PR
N=b.row_join(hh).col_join(hh.row_join(b));Snum=-s.I*N;VM=V.row_join(O).col_join(O.row_join(O));S1num=(-Snum*VM*Snum).applyfunc(s.expand)
zero(N*N-K*s.eye(16));zero(S1num[:8,8:]-b*V*hh);zero(S1num[8:,:8]-hh*V*b)
F1=(-s.I*b*Ar)*S1num[:8,8:]*(-hh*Aa)*s.I
F2=(Ata*hh)*S1num[8:,:8]*(-s.I*b*Ar)*(-1)*s.I
# Polarize the actual real scalar kinetic normalization; p_x=-q_B.
u,v,zg,bb,p,t=s.symbols('u v g b p t');zz=s.Matrix(s.symbols('z0:2'));ss=s.Matrix(s.symbols('s0:2'));rho=s.Matrix([[0,-t],[t,0]])
field=u*zz+v*ss;der=s.I*p*u*zz;dens=((der+zg*bb*rho*field).T*(der+zg*bb*rho*field))[0]/2
assert s.expand(s.expand(dens).coeff(u).coeff(v).coeff(bb)-s.I*zg*p*(zz.T*rho*ss)[0])==0
q=[-v for v in k];gb=[-v for v in q];gl=list(q)
dxB=[-s.I*v for v in q];dBx=[s.I*v for v in q]
mixedL=s.expand(-sum(x*y for x,y in zip(dxB,gb)));mixedR=s.expand(-sum(x*y for x,y in zip(gl,dBx)))
assert s.expand(mixedL+s.I*K)==s.expand(mixedR+s.I*K)==0
SC1=Tau*(-s.I*hh)*(-hh*Aa)*mixedL*s.I
SC2=(Ata*hh)*(-s.I*hh)*Tau*mixedR*s.I
def extract(mat,base,charge,P):
 co=simp(s.trace(P*mat)/(s.trace(P)*base*charge));zero(mat*P-co*base*charge*P);return co
raw={};anti={}
for tag,mat,base,cl,cr in [('F_EC',F1,B*HH,rR*m*aL,rL*md*aR),('F_ES',F2,B*HH,aR*m*rL,aL*md*rR),('SC_EC',SC1,HH*K,n*aL,nd*aR),('SC_ES',SC2,HH*K,aR*n,aL*nd)]:
 raw[tag]=extract(mat,base,cl,PL);anti[tag]=extract(mat,base,cr,PR);assert raw[tag]==anti[tag]
print('STAGE ACTUAL_RESOLVENT_AND_SPIN_NUMERATORS',flush=True)
eps,h,m2=s.symbols('epsilon h m_IR2',positive=True);D=4-2*eps
def regular(power,denom):return m2**(-eps)*s.gamma(power+D/2)*s.gamma(1+eps)/(s.gamma(D/2)*s.gamma(denom))
def finite(z):return simp(s.diff(z.subs(h,-2*eps),eps).subs(eps,0))
reg0=h/D*regular(1,3);regB=4*h/(D*(D+2))*regular(2,4);regH=h*(h+2)/(D*(D+2))*regular(2,4)
I0,IB,IH=map(finite,[reg0,regB,regH]);Ifull=finite(regB+regH);assert simp(Ifull-I0)==0
units={tag:simp(co*(IB if tag.startswith('F_') else Ifull)) for tag,co in raw.items()}
badbar={tag:simp(co*(IB if tag.startswith('SC_') else IB)) for tag,co in raw.items()}
programs={'F_EC':{'J':-units['F_EC']},'F_ES':{'J':units['F_ES']},'SC_EC':{'J':s.I*units['SC_EC'],'R':s.I*units['SC_EC']},'SC_ES':{'J':s.I*units['SC_ES'],'L':-s.I*units['SC_ES']}}
aprograms={'F_EC':{'J':-units['F_EC']},'F_ES':{'J':units['F_ES']},'SC_EC':{'J':s.I*units['SC_EC'],'R':-s.I*units['SC_EC']},'SC_ES':{'J':s.I*units['SC_ES'],'L':s.I*units['SC_ES']}}
total={x:simp(sum(v.get(x,0) for v in programs.values())) for x in ['J','L','R']};atotal={x:simp(sum(v.get(x,0) for v in aprograms.values())) for x in ['J','L','R']}
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));Bs=[dec(Y[n]) for n in ['B10','B126']]
H={(r,a,c):s.sympify(co) for r,a,c,co in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz')['plane_H']}
for (r,a,c),co in H.items():assert simp(co+H.get((a,r,c),0))==0 and simp(co-s.conjugate(co))==0
CH=[s.zeros(16) for c in range(45)];J=[s.SparseMatrix(256,256,{}) for c in range(45)]
for (r,a,c),co in H.items():CH[c]+=co*T[r]*T[a];J[c]+=co*s.kronecker_product(T[r].T,T[a].T)
CH=list(map(tidy,CH));J=list(map(tidy,J));I=s.eye(16);models=[]
for M in CH:zero(M+M.H)
for Bmap in Bs:
 row={'holomorphic':[],'antiholomorphic':[]}
 for c in range(45):
  op=total['J']*J[c]+total['L']*s.kronecker_product(CH[c].T,I)+total['R']*s.kronecker_product(I,CH[c].T)
  ap=atotal['J']*s.conjugate(J[c])+atotal['L']*s.kronecker_product(CH[c],I)+atotal['R']*s.kronecker_product(I,CH[c])
  row['holomorphic'].append(enc(tidy(WM*op*Bmap)));row['antiholomorphic'].append(enc(tidy(WM*ap*s.conjugate(Bmap))))
 models.append(row)
print('STAGE COMPLETE_ACTION_DERIVED_SCALAR_MAPS',flush=True)
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cxPP']['remaining_internal_ghost_candidates']
support=[v for v in support if json.loads(v)[-3:-1]==[2,1]]
serialize=lambda d:{k:{x:str(simp(v)) for x,v in terms.items()} for k,terms in d.items()}
finish('primary',{'method':'actual_PS_and_bosonic_resolvents_explicit_gamma8_Gamma_moments_direct_products','raw_spin_units':{k:str(v) for k,v in raw.items()},'raw_conjugate_spin_units':{k:str(v) for k,v in anti.items()},'finite_moments':dict(zip(['I0','IB','IH','Ifull'],map(str,[I0,IB,IH,Ifull]))),'kernel_units':{k:str(v) for k,v in units.items()},'premature_barred_kernel_units':{k:str(v) for k,v in badbar.items()},'programs':serialize(programs),'antiprograms':serialize(aprograms),'total_program':{k:str(v) for k,v in total.items()},'total_antiprogram':{k:str(v) for k,v in atotal.items()},'CH':list(map(enc,CH)),'J_operators':list(map(enc,J)),'models':models,'supported_witnesses':support,'scalar_current_full_D':True,'no_extra_Nambu_half_or_family3':True,'source_target_read_to_fit_quantum_input':False,'quantum_operator_moments_computed_before_source_comparison':True,'new_two_loop_integrals':0,'full_restoration_claimed':False},start)
