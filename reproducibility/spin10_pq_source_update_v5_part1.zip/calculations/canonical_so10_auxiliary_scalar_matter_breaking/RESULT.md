# ASB1: the auxiliary scalar kernel matches the fixed source Euler term

The complete four-profile auxiliary g10^2 Y scalar breaking has been
calculated and verified in the frozen mass-independent, degree-zero,
physical-external-hats0 Euclidean Feynman domain. It is nonzero, and its
sum with the already fixed MSP1 scalar Euler companion is exactly zero.
Receipt SHA256:
`3af347d2e00daba90bf69359d5c5acaa94fbf7e54b0591f8504fd5a3af27821c`.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

## Action-derived kernel and independent source comparison

Strip g10^2/(16pi^2), retain xi explicitly, and define from the actual
normalized auxiliary ghost tensor

 CH_c=sum_ra H_ra,c T_r T_a,
 J_c(M)=sum_ra H_ra,c T_r.T M T_a.

The four ordered holomorphic mass kernels are

 F_EC(M)=-(xi/3) J_c(M),
 F_ES(M)=+(xi/3) J_c(M),
 SC_EC(M)=(xi/2)[J_c(M)+M CH_c],
 SC_ES(M)=(xi/2)[CH_c.T M-J_c(M)].

Their sum is the measured quantum mass kernel

 Delta_c(M)=(xi/2)[CH_c.T M+M CH_c].

The conjugate mass kernel is

 Delta_c(Mdagger)=-(xi/2)[CH_c Mdagger+Mdagger CH_c.T].

These are ghost-dependent symmetry-insertion kernels, not physical fermion
mass predictions or a massive threshold. The full Nambu density retains
its original1/2; no extra open-line Gaussian half or family3 is inserted.
Both chiralities and all scalar coordinates are retained. General symmetric
Y10/Y126 remain factorized, without a numerical flavor point or trace average.

Only after the two quantum calculations completed did the verifier read
MSP1's fixed X^[3]. For x_L=-i X_left^[3],x_R=-i X_right^[3], its Euler
mass kernels are i(x_R M-M x_L) and i(x_L Mdagger-Mdagger x_R).
They are exactly the negatives of the independently calculated kernels.
A generic alternating Grassmann mass density checks their sign and1/2
before comparing actual coefficients. Source tables were denied to both
quantum workers after byte authentication. No unknown loop value or source
coefficient was fitted to obtain cancellation.

All5898240 unrestricted mass-operator positions in the declared comparison
have zero source-sum remainder. Both actual256x328 Yukawa maps and their
conjugates agree across15114240 color/scalar positions, including zeros.
The nonzero map positions are:

| Carrier | Holomorphic | Antiholomorphic |
| --- | ---: | ---: |
|10|6720|6720|
|126|137920|137920|

All328 scalar directions are checked; Phi/S non-Yukawa zero directions are
not omitted. Counts describe representation coordinates, not independent
experiments or particles. Reality, mass symmetry and all12 global-H color
covariance tests have zero remainders. Full local-background quantum
restoration is not inferred from those tensor tests.

## The finite full-D contribution is indispensable

The independently derived moments, in16pi^2 units, are

 I0=FP int hat k2/(k2+m_IR2)^3=-1/2,
 IB=FP int hat k2 bar k2/(k2+m_IR2)^4=-1/3,
 IH=FP int(hat k2)^2/(k2+m_IR2)^4=-1/6.

The scalar-current contraction has two bosonic ends. Its full-D k.k gives
IB+IH=-1/2, matching I0. The positive-IR rearrangement difference is
convergent with the explicit evanescent factor and vanishes in the stated
nonexceptional local family. No full scaleless integral or exceptional IR
contact is declared zero.

Prematurely barring that vector contraction loses IH and changes144640
holomorphic map positions across the two carriers. This is an actual finite
control, not an assumption that an evanescent term must be harmless.
The raw integrated units before color covariance are1/3,1/3,-i/2,+i/2.
Their phases follow from the actual iE blocks, mixed propagator routing,
positive scalar vertex and polarized real-scalar current.

Each fermion-line ordered contribution has139040 nonzero omission-sensitive
positions, but its physical symmetric mass projection is0; their collected
sum is also0. This is a genuine insensitive physical control, not a test
of all four global signs. Each scalar-current omission changes178748
ordered positions and144640 physical symmetric positions. Wrong scalar
Bose factor2, extra Nambu half or reversed overall insertion changes144640.
Transposing an already symmetric physical M is correctly insensitive.
These control counts are for the holomorphic maps; conjugates are separately
checked, not silently counted as additional control experiments.

## Methods, resources and preserved gate exhaustion

Primary differentiates the actual PS/bosonic resolvents, checks explicit
split-Clifford matrices and literal scalar-current polarization, then uses
joint Gamma moments and direct matrix/Kronecker transport. Replay uses exact
four-vertex Berezin and bosonic Wick signs, abstract bar/hat Clifford words,
Schwinger Gaussian moments, component-index tensor transport and the qualified
Lie reduction. The three-even-vertex units are1, the mass-insertion cumulants
are-1 and the bosonic propagator-insertion unit is-1. No closed fermion loop
sign or half is assigned by analogy.

Completed primary/replay native0 in500.2725145/104.4792678s after imports.
250/53 samples,max126070784/132796416 private bytes. The original verifier
exhausted600s,native124, after its kernel/Euler stage, without result or
comparison table. Its exact last internal step is unknown. The complete
failed source/copy/capture/controller record is preserved as scientific
INCOMPLETE_RESOURCE_LIMIT, not refutation or PASS.

V2 reuses both completed quantum tables without rerunning them. Its exact
sparse Kronecker definition and cached fixed operators change representation
only; every original comparison, zero complement, physical projection and
control remains. V2 verifier native0 in295.7752722s,149 samples,max251129856
bytes. The failed verifier had300 samples,max205795328 bytes. These are
sampled maxima, not continuous peaks. All600s/8GiB sampled/350MiB launch
floor/16MiB packet limits held; no resource expansion or evidence truncation.

59 initial67 validation bindings;83 continuation85 validation-V2 bindings;
12 source copies. E4 readiness command executed this goal turn without
--fresh historical science replay. Its audit steps returned0,0,0,0,0,2;
custody remains exit2/seven, NOTPASS. Fresh byte preflights/resources recorded.
Comparison compressed/raw SHA256:
`1b64f6406e5a1fb219b4cceb7ea6568ea3b54312fd08f1637d7a8a2182d17a93` /
`d69fccd30cd20d80a012645951134d34c3394094764d736c868bbd8529d8cf5e`.

Track B demonstrates independent ordered-kernel derivation, a sensitive
full-D finite control, honest physical-projection insensitivity and reuse
after a gate timeout. The costly original Kronecker representation and
600s gate exhaustion are engineering weaknesses, not erased successes.
Shared action, regulator assumptions, H/Yukawa data, SymPy and AI authorship
remain; no independent expert, proof-kernel or empirical validation is claimed.

## Scientific consequence and next calculation

The source primitive previously matched the lower-order kinetic channel.
It now also matches a separately calculated nonzero auxiliary scalar
channel, without a new normalization or Yukawa choice. This strengthens
the selected bare field/source consistency argument. It does not establish
a common renormalized prescription for all bosonic and matter source terms.
Their coupled fermion Euler companions and regulator applicability still
require assessment before a full quantum restoration statement.

The next economical step is the eight ordinary g3Y scalar profiles. They
complete the remaining scalar-bearing class in MDS1's degree-zero inventory.
The same spin moments may be reused only after deriving their actual BB/GF
derivative contractions and phases. Preserve both GF derivative placements,
full width matrix, ordered masses and source X^[4]. Calculate the quantum
input first; retain any source-sum remainder rather than choosing it away.
The42 gauge-bearing profiles and positive-dimension sectors remain unmeasured.

No physical finite baseline is selected; CFC1 z_psi/z_10/z_126,b0,kappa and
bosonic normalization freedoms remain distinct. Full finite Slavnov/QAP,
products,measure/phase,background/causal limits,physical chiral prescription,
massive C1,E5/A5 and physical unification remain unqualified. Both adverse
scalar benchmarks,quartetFAIL,flavorpause,HB1/C5blocks and all historical
evidence persist. No foundation,scheme,benchmark or authority adopted; no
agents,branch/worktree,outreach,publication or push.
