"""ASB1 immutable scientific inputs, sources and current readiness capture."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/auxiliary-scalar-matter-breaking-v1-2026-10-23')
BASE='d776b6cf628cebc96ee249826f79234fa7842a36'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();bind={}
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
def add(p,want=None):
 p=p.resolve();h=digest(p)
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V526.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/research_session_preflight.py','tools/research_check.py']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
add(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py')
deps={
 'canonical_so10_sterile_matter_action':(['ACTION_V1.md','validation_receipt.json'],'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_yukawa_carrier_transport':(['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b'),
 'canonical_so10_ghost_triangle_field_insertion':(['DERIVATION.md','primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz','validation_preparation.json','validation_receipt.json'],'610e974608e4d4f711708a7018a0981a857180cdc852a36807cdb7fa5be42d4a'),
 'canonical_so10_matter_degreezero_support':(['RECORD.md','DERIVATION.md','RESULT.md','support_tables.json.gz','validation_receipt.json'],'e14380e2c763754d4557ba0c12b77e39b3f37668a1115ad2c7f52fc4304c28af'),
 'canonical_so10_matter_source_primitive':(['DERIVATION.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'c0e178079368b7f841ef0c44d2b76035a289a761dc8d427b4a6a4732119638c2')}
for folder,(names,rh) in deps.items():
 for n in names:add(CAL/folder/n,rh if n=='validation_receipt.json' else None)
for folder,names in [('canonical_so10_yukawa_carrier_transport',['primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_ghost_triangle_field_insertion',['primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz']),('canonical_so10_matter_source_primitive',['primary_tables.json.gz','replay_tables.json.gz'])]:
 old=read(CAL/folder/'validation_preparation.json')['input_sha256']
 for n in names:
  p=(CAL/folder/n).resolve();assert digest(p)==old[str(p)]
for n in ['DERIVATION.md','ORIENTATION_V2.md','validation_receipt_v2.json','orientation_receipt_v2.json']:add(CAL/'canonical_so10_gauge_yukawa_vertex_poles'/n)
add(CAL/'canonical_so10_gauge_yukawa_vertex_poles/validation_receipt_v2.json','d8627df20f8cb21d820a3c284474d17447b8b83f909cf508facb395d2e00c666')
add(CAL/'canonical_so10_gauge_yukawa_vertex_poles/orientation_receipt_v2.json','edf690ae4bb58e69b8e4e9607526d5a848ffee72fada2064c72b46ee5c6c1a44')
r=read(CAL/'canonical_so10_matter_degreezero_support/validation_receipt.json');blob=(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz').read_bytes()
assert sha256(blob).hexdigest()==r['support_tables_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['support_raw_sha256']
add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-degreezero-support-v1-2026-10-23/postcommit_seal.json'))
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31554
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
# Delegated audits execute now; the sealed historical science is NOT freshly replayed.
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:
 rr=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()]
steps=[v for v in events if v['event']=='step_finished'];exits=[v['exit_code'] for v in steps]
assert rr.returncode==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
with (CONTROL/'readiness_result.json').open('xb') as f:f.write((json.dumps({'native_exit':rr.returncode,'step_exits':exits,'fresh_historical_science_requested':False,'readiness_command_executed_this_goal_turn':True,'custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:
 rr=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
snap=read(CONTROL/'prelaunch_preflight.json');assert rr.returncode==0 and snap['git_HEAD']==BASE and snap['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8' and snap['files_written']==0 and not snap['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'ASB1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('ASB1_FROZEN',len(bind),'bindings',flush=True)
