"""ASB1 independent coefficient, physical-mass and fixed Euler comparison."""
from data import *
from collections import defaultdict,Counter
from functools import lru_cache
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
@lru_cache(maxsize=65536)
def simp(v):return s.simplify(v)
def kron(A,B):
 aa=s.SparseMatrix(A);bb=s.SparseMatrix(B)
 return s.SparseMatrix(aa.rows*bb.rows,aa.cols*bb.cols,{(i*bb.rows+k,j*bb.cols+l):x*y for (i,j),x in aa.todok().items() for (k,l),y in bb.todok().items()})
def tidy(M):return s.SparseMatrix(M).applyfunc(simp)
def nz(M):return len(tidy(M).todok())
def zero(M):assert not nz(M)
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for k in ['raw_spin_units','raw_conjugate_spin_units','finite_moments','kernel_units','premature_barred_kernel_units','programs','antiprograms','total_program','total_antiprogram','supported_witnesses']:assert P[k]==R[k],k
for obj in [P,R]:
 assert obj['scalar_current_full_D'] and obj['no_extra_Nambu_half_or_family3'] and not obj['source_target_read_to_fit_quantum_input']
 assert obj['quantum_operator_moments_computed_before_source_comparison'] and obj['new_two_loop_integrals']==0 and not obj['full_restoration_claimed']
assert len(P['supported_witnesses'])==4
actual=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cxPP']['remaining_internal_ghost_candidates']
assert sorted(P['supported_witnesses'])==sorted(v for v in actual if json.loads(v)[-3:-1]==[2,1])
assert R['mass_cumulant_units']==['-1','-1'] and R['three_vertex_units']==['1','1'] and R['bosonic_insertion_unit']=='-1'
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);Bs=[dec(Y[n]) for n in ['B10','B126']];I=s.eye(16)
CH=list(map(dec,P['CH']));J=list(map(dec,P['J_operators']))
for c in range(45):zero(CH[c]-dec(R['CH'][c]));zero(J[c]-dec(R['J_operators'][c]));zero(CH[c]+CH[c].H)
# Derive the source mass-image sign using generic alternating Grassmann
# densities, separately from either loop or the actual comparison tensor.
def clean(d):return {k:s.expand(v) for k,v in d.items() if s.expand(v)!=0}
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return clean(out)
def wedge(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(5) if a&(1<<i))*x*y
 return clean(out)
def word(seq,co):
 out={0:co}
 for i in seq:out=wedge(out,{1<<i:1})
 return out
mm=s.Matrix([[s.Symbol('m0'),s.Symbol('m1')],[s.Symbol('m1'),s.Symbol('m2')]]);xx=s.Matrix(2,2,s.symbols('x0:4'));C=s.Matrix([[0,1],[-1,0]])
for phase,flow,target in [(-s.I,xx,-s.I*(xx.T*mm+mm*xx)),(s.I,xx.T,s.I*(xx*mm+mm*xx.T))]:
 K=kron(C,mm);X=kron(s.eye(2),flow);variation={};expected={};DK=kron(C,target)
 for i in range(4):
  for j in range(4):
   co=K[i,j]/2
   for k in range(4):
    variation=add(variation,word([0,1+k,1+j],co*phase*X[i,k]))
    variation=add(variation,{a:-v for a,v in wedge(word([1+i],co),word([0,1+k],phase*X[j,k])).items()})
   expected=add(expected,word([0,1+i,1+j],DK[i,j]/2))
 assert not add(variation,{k:-v for k,v in expected.items()})
print('STAGE ACTUAL_KERNELS_AND_GENERIC_EULER_SIGN_QUALIFIED',flush=True)
S=packed(CAL/'canonical_so10_matter_source_primitive/primary_tables.json.gz')
XL=[-s.I*dec(v) for v in S['X_left']['3']];XR=[-s.I*dec(v) for v in S['X_right']['3']]
def transpose_rows(M,conjugate=False):
 return s.SparseMatrix(256,328,{((i%16)*16+i//16,j):(s.conjugate(v) if conjugate else v) for (i,j),v in M.todok().items()})
@lru_cache(maxsize=90)
def endpoints(c,anti):
 return kron(CH[c] if anti else CH[c].T,I),kron(I,CH[c] if anti else CH[c].T)
@lru_cache(maxsize=720)
def cached_op(items,c,anti):
 pp={k:s.sympify(v) for k,v in items};L,RR=endpoints(c,anti)
 return pp.get('J',0)*(s.conjugate(J[c]) if anti else J[c])+pp.get('L',0)*L+pp.get('R',0)*RR
def op(prog,c,anti=False):return cached_op(tuple(sorted(prog.items())),c,anti)
@lru_cache(maxsize=45)
def source_ops(c):
 return s.I*(kron(XR[c],I)-kron(I,XL[c].T)),s.I*(kron(XL[c],I)-kron(I,XR[c].T))
counts={};remainders={};ctrl=Counter();positions=0;op_positions=0;source_op_remainders=0
for c in range(45):
 source,sourceA=source_ops(c)
 source_op_remainders+=nz(WM*op(P['total_program'],c)+source)+nz(WM*op(P['total_antiprogram'],c,True)+sourceA)
 op_positions+=2*256**2
print('STAGE COMPLETE_UNRESTRICTED_MASS_OPERATOR_COMPARISON',flush=True)
for ri,BB in enumerate(Bs):
 rr=Counter();nn=Counter();cc=Counter()
 for c in range(45):
  q=dec(P['models'][ri]['holomorphic'][c]);qa=dec(P['models'][ri]['antiholomorphic'][c]);zero(q-dec(R['models'][ri]['holomorphic'][c]));zero(qa-dec(R['models'][ri]['antiholomorphic'][c]));positions+=2*256*328
  zero(q-WM*op(P['total_program'],c)*BB);zero(qa-WM*op(P['total_antiprogram'],c,True)*s.conjugate(BB))
  zero(q-transpose_rows(q));zero(qa-transpose_rows(qa));zero(qa-transpose_rows(q,True))
  source,sourceA=source_ops(c);source=source*BB;sourceA=sourceA*s.conjugate(BB)
  rr['holomorphic_source_sum']+=nz(q+source);rr['antiholomorphic_source_sum']+=nz(qa+sourceA);nn['holomorphic']+=nz(q);nn['antiholomorphic']+=nz(qa)
  pieces={tag:tidy(WM*op(pp,c)*BB) for tag,pp in P['programs'].items()}
  for tag,M in pieces.items():
   cc['omit_'+tag+'_ordered']+=nz(M);cc['omit_'+tag+'_physical_symmetric']+=nz((M+transpose_rows(M))/2)
  zero(pieces['F_EC']+pieces['F_ES'])
  scalar=pieces['SC_EC']+pieces['SC_ES'];cc['wrong_scalar_Bose_factor2']+=nz(scalar);cc['extra_Nambu_half']+=nz(q/2);cc['reverse_overall_insertion']+=nz(2*q)
  bu={k:s.sympify(v) for k,v in P['premature_barred_kernel_units'].items()}
  bp={'J':str(-bu['F_EC']+bu['F_ES']+s.I*bu['SC_EC']+s.I*bu['SC_ES']),'L':str(-s.I*bu['SC_ES']),'R':str(s.I*bu['SC_EC'])}
  cc['premature_barred_scalar_contraction']+=nz(WM*op(bp,c)*BB-q)
  # Physical M transposition is correctly insensitive in these symmetric maps.
  cc['replace_physical_M_by_transpose']+=nz(q-transpose_rows(q))
 counts[str(ri)]=dict(nn);remainders[str(ri)]=dict(rr);ctrl.update(cc)
 print('STAGE COMPLETE_SCALAR_CARRIER',ri,flush=True)
print('STAGE COMPLETE_ALL_SCALAR_MAPS_AND_FIXED_SOURCE_COMPARISON',flush=True)
# All12 H generators on the action-derived color ghost tensor; scalar/full
# family covariance then follows from the bound all45 YCT covariance.
f=defaultdict(list)
for a,b,e,co in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,s.sympify(co)))
cov=0
for h in range(12):
 th=sum((HF[a,h]*T[a] for a in range(45) if HF[a,h]),s.zeros(16))
 for c in range(45):
  rhs=sum((HF[b,h]*co*CH[e] for b in range(45) if HF[b,h] for e,co in f[b,c]),s.zeros(16))
  cov+=nz(-s.I*(th*CH[c]-CH[c]*th)-rhs)
assert cov==0
allzero=not source_op_remainders and not any(n for d in remainders.values() for n in d.values())
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'models':P['models'],'programs':P['programs'],'antiprograms':P['antiprograms'],'CH':P['CH'],'J_operators':P['J_operators'],'source_comparison_remainders':remainders,'source_companion_not_adopted_as_full_prescription':True}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'comparison_tables.json.gz').open('xb') as fh:fh.write(blob)
print('RESULT '+json.dumps({'status':'QUALIFIED_AUXILIARY_SCALAR_MATTER_BREAKING_TEST','disposition':'SELECTED_AUXILIARY_SCALAR_KERNEL_CANCELS_FIXED_SOURCE_EULER' if allzero else 'NONZERO_AUXILIARY_SCALAR_REMAINDER_PRESERVED','elapsed_after_imports':time.perf_counter()-start,'selected_profiles':4,'coupling_order':'g10^2*xi*Y','raw_spin_units':P['raw_spin_units'],'finite_moments':P['finite_moments'],'kernel_units':P['kernel_units'],'total_holomorphic_program':P['total_program'],'total_antiholomorphic_program':P['total_antiprogram'],'mass_map_positions_compared':positions,'unrestricted_mass_operator_positions_compared_to_source':op_positions,'unrestricted_mass_operator_source_remainder_positions':source_op_remainders,'source_sum_remainders':remainders,'counts':counts,'controls':dict(ctrl),'global_H_color_remainder_positions':cov,'general_symmetric_families_factorized_not_fitted':True,'full_328_scalar_domain_retained':True,'mass_kernel_reality_and_symmetry_remainders':'0','fermion_line_collected_remainder':'0','remaining_unmeasured_degreezero_profiles':50,'physical_finite_normalization_chosen':False,'full_Slavnov_QAP_measure_phase_massive_C1_E5A5_or_physical_unification_qualified':False,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','comparison_tables_sha256':sha256(blob).hexdigest(),'comparison_raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
