"""CHM1 freeze separate raw amplitudes and withhold combined images until the gate."""
from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_cutoff_source_ward_operator'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-matter-response-v1-2026-10-23');OLD=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/cutoff-source-ward-operator-v1-2026-10-23')
BASE='62db442a162fdee55cf257eaf841e351391806e8';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v3.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32574
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_v3_capture.json','RESULT.md','validation_preparation_v3.json','primary_v3_tables.json.gz','replay_v3_tables.json.gz']:add(PRED/n)
add(ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V551.md')
for n in ['postcommit_seal.json','before_commit_seal.json','successful_index_gate.json','seal.py','before_seal_full_capture.json','index_seal_full_capture.json','after_seal_full_capture.json']:add(OLD/n)
for folder in ['canonical_so10_open_fermion_heat_kinetic','canonical_so10_matter_gauge_vertex_finite_color','canonical_so10_proper_matter_source_finite','canonical_so10_bosonic_source_onejet_finite','canonical_so10_ghost_triangle_field_insertion','canonical_so10_gauge_fermion_insertion','canonical_so10_yukawa_finite_vertex_ward','canonical_so10_yukawa_heat_ward_response','canonical_so10_gauge_source_heat_p_response']:
 for n in ['RESULT.md','validation_receipt.json']:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 q=HERE/(n+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 add(p);add(q)
def source(folder,name):
 p=CAL/folder/(name+'.json.gz');add(p);return packed(p)
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables');k=source('canonical_so10_open_fermion_heat_kinetic',role+'_tables');v=source('canonical_so10_matter_gauge_vertex_finite_color',role+'_tables');s=source('canonical_so10_proper_matter_source_finite',role+'_tables');b=source('canonical_so10_bosonic_source_onejet_finite',('primary_v2' if role=='primary' else 'replay_v3')+'_tables');g=source('canonical_so10_ghost_triangle_field_insertion',role+'_tables');f=source('canonical_so10_gauge_fermion_insertion',role+'_tables');z=source('canonical_so10_yukawa_finite_vertex_ward',role+'_tables')
 assert s['source_overall_factors']['auxiliary']=='g10^2*xi/(16*pi^2)' and b['mixed_matter_factor']=='g10**2*xi'
 gz(HERE/(role+'_inputs.json.gz'),{'Y':{key:y[key] for key in ['Tminus','H_new']},'KIN':k['kinetic_coefficients'],'VERT':v['B'],'SRC':s['source_matrices'],'RHO':b['rho'],'GTT':{key:g[key] for key in ['left','right']},'GFI':{key:f[key] for key in ['left','right']},'YVF':{key:z[key] for key in ['fermion_vertex_left','fermion_vertex_right','family_left','family_right']}});add(HERE/(role+'_inputs.json.gz'))
controls={'GTT':source('canonical_so10_ghost_triangle_field_insertion','comparison_tables')['complete_cPP_components'],'VFC':source('canonical_so10_matter_gauge_vertex_finite_color','comparison_tables')['partial_p_q_images'],'GHP':source('canonical_so10_gauge_source_heat_p_response','primary_tables')['response_p'],'YHT':source('canonical_so10_yukawa_heat_ward_response','primary_tables')['response_q']}
gz(HERE/'validation_control_inputs.json.gz',controls);add(HERE/'validation_control_inputs.json.gz')
assert read(OLD/'readiness_result.json')['step_exits']==[0,0,0,0,0,2]
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(OLD/n)
dump(CONTROL/'readiness_reuse.json',{'source':str(OLD/'readiness_result.json'),'sha256':digest(OLD/'readiness_result.json'),'same_goalturn_fresh_command_authenticated_not_repeated':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'CHM1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('CHM1_FROZEN',len(bind),'bindings',flush=True)
