# CHM1: extract the complete selected heat/source matter response by the operator identity

Base62db442a162fdee55cf257eaf841e351391806e8/main32574blobs;state113/34of39
unchanged. Read CSW1/V551 and current AGENTS. WholegoalACTIVE/incomplete.
No agents/branch/worktree,push,physical adoption,protected activation.

Question:using the constructed actual cutoff/source operator,extract all
selected mass-independent one-jet cPP p/q coefficients at ordinary g³,
lower g²xi and both general gYdagY factors. Establish local comparison
completeness before combining inputs. This is an identity-based evaluation
of the actual operator,not a new independent integration of every heat word.
No coefficient is chosen from a desired Ward remainder.

Immutable quantum inputs:raw independently qualified FHK kinetic comparisons,
VFC complete5-family currents,PSF proper physical-source matrices,BSF raw
JBpartialC rho;raw12-support dimensional insertion from GTT/GFI/YVF. Workers
receive no stored combined images,remainder,counterterm or heat-response
target. Primary computes separate action-derived images;replay uses a generic
noncommutative congruence/two-endpoint derivation then sums before acting.
Both use independent native source packets;shared exact ring is disclosed.
Late verifier compares separately derived GHPp,YHTlinearY responses and the
authenticated old raw-assembly/relative-image controls. A mismatch is retained,
not fitted or relabelled. No CFC coefficient or free constant is selected.

The constructed Gaussian/source identity plus the actual split classical
defect gives R_dim-R_heat=bSigma C_rel at this projection. Its dimensional
finite part must be justified before use:keep both hatted sewing blocks and
actual ghost derivatives;the stable physical external ideal commutes with
the first local operation;graded diagonal trace vanishes here. Ordinary
convergent dimensional integrals are shifted only before meromorphic finite
part,not by cyclicity of a divergent arbitrary finite trace. No nonchiral
Stokes/gamma5 theorem or unrestricted measure assertion is imported.

Freeze complete domain/derivation/eight sources,copies,inputs,expected checks,
failure conditions and limits before workers. Sequential primary/replay/gate
600safterimports,8GiB sampledprivate,350MiB launch floor,16MiB storedpacket.
Reuse fresh E4 from same goalturn by byteauthentication;new preflight. On first
failure stop,preserve complete captures and source bytes,version corrections.
Mandatory passing precommit/index/after seals;never bypass failed gate.

Ceiling:qualified complete SELECTED one-jet heat p/q response within formal
Euclidean marginal domain. No full source functional/higher descendants,
finite chiral restoration,QAP/products,measure/phase,physical chiral scheme,
massive C1,E5/A5 or GUT. No free chi4,z,kappa,b0 or flavor choice. Preserve
both adverse scalar points,quartetFAIL,flavorpause,HB1/C5blocks,custodyexit2/
seven,all historical failures and authority. Agreement shares action,inputs,
software,analytic premises and AI author;not independent science.
