"""CHM1 exact full response comparison and independent late loop controls."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['response','nonzero_counts','controls','general_family_factors','selected_local_parent_classes']:assert P[k]==R[k],k
positions=0
for group,orders in P['response'].items():
 for order,sides in orders.items():
  for side,ds in sides.items():
   for jet,aa in ds.items():
    assert len(aa)==45
    for m in aa:assert m['shape']==[16,16]
    positions+=45*256
  lp=list(map(dec,sides['left']['p']));lq=list(map(dec,sides['left']['q']));rp=list(map(dec,sides['right']['p']));rq=list(map(dec,sides['right']['q']))
  for p,q,pr,qr in zip(lp,lq,rp,rq):
   zero(plus(p,trans(star(p))));zero(minus(trans(star(q)),minus(q,p)));zero(minus(pr,trans(p)));zero(minus(qr,trans(minus(p,q))))
assert positions==1105920
for order in ORDERS:
 for side in SIDES:
  for jet in ['p','q']:
   get=lambda g:list(map(dec,P['response'][g][order][side][jet]))
   for m in get('relative_chi4'):zero(m)
   for a,b in zip(get('heat_length_log'),get('relative_log')):zero(plus(a,b))
   for h,r,di in zip(get('heat_total_fixed'),get('relative_fixed'),get('dimensional_fixed')):zero(minus(plus(h,r),di))
   assert P['response']['dimensional_fixed'][order][side][jet]==late['GTT'][order][side][jet]
   if order!='g2':
    tag={'g3':'gauge','gY10':'Y10','gY126':'Y126'}[order]
    for part,group in [('chi4','relative_chi4'),('log3over2','relative_log'),('fixed','relative_fixed')]:assert P['response'][group][order][side][jet]==late['VFC'][part][tag][side][jet]
for group in ['dimensional_fixed','heat_length_log','heat_total_fixed','relative_fixed','relative_log']:
 for side in SIDES:
  assert P['response'][group]['g3'][side]['p']==late['GHP'][group][side]
  for order,tag in [('gY10','Y10'),('gY126','Y126')]:assert P['response'][group][order][side]['q']==late['YHT'][group][tag][side]
for obj in [P,R]:
 assert not any(obj[k] for k in ['independent_component_heat_integration','quantum_coefficient_fitted','free_finite_constant_selected','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
csw=read(CAL/'canonical_so10_cutoff_source_ward_operator/validation_receipt.json');assert csw['word_counts']=={'g3':5,'g2xi':3,'gY2':2} and csw['first_variation_joint_test_field_domain']
print('RESULT '+json.dumps({'status':'QUALIFIED_OPERATOR_DERIVED_COMPLETE_SELECTED_HEAT_MATTER_P_Q_RESPONSE','elapsed_after_imports':time.perf_counter()-tick,'coefficient_positions_compared':positions,'all45_ghosts_both_chiralities_p_q_zero_complements_match':True,'general_family_factors_retained':True,'chi4_image_zero_without_selecting_chi4':True,'raw_dimensional_12_support_reassembly_matches':True,'independent_GHP_p_response_matches':True,'independent_YHT_q_responses_match':True,'independent_component_heat_integration':False,'extraction':'actual_CSW_operator_identity_and_complete_local_comparison_parents','nonzero_counts':P['nonzero_counts'],'negative_controls':P['controls'],'physical_scheme_adopted':False,'free_finite_constant_selected':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
