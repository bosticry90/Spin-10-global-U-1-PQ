"""CHM1 distinct action-derived kinetic,current and both source Euler images."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');TL=list(map(dec,d['Y']['Tminus']));TR=[scale(trans(t),Q(-1)) for t in TL];rel={p:{} for p in PARTS};controls=defaultdict(int)
for part in PARTS:
 for order in ORDERS:
  rel[part][order]={}
  for side,T in [('left',TL),('right',TR)]:
   C,V,M,O,B=terms(d,order,part,side,T);pp=[];qq=[]
   for t,v,m,o,b in zip(T,V,M,O,B):
    pk=scale(minus(mul(C,t),mul(t,C)),Q(-1));qk=scale(mul(C,t),Q(-1));ps=scale(plus(m,trans(o)),II);qs=scale(m,II);qv=scale(v,II)
    pp.append(enc(plus(pk,ps)));qq.append(enc(plus(plus(qk,qv),plus(qs,b))))
    if part=='fixed':
     controls['omit_bosonic_source']+=len(b.d);controls['omit_proper_source']+=len(qs.d);controls['wrong_generic_source_p_zero']+=len(ps.d)
   rel[part][order][side]={'p':pp,'q':qq}
assert all(controls.values())
finish('primary',rel,tick,'separate_action_Euler_images_on_independent_raw_primary_amplitudes',dict(controls))
