"""CHM1 alternating kinetic/source congruence then combined endpoint extraction."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz')
# Generic noncommutative color coefficients,explicit chirality flip.
A=sy.Matrix(2,2,sy.symbols('a0:4'));B=sy.Matrix(2,2,sy.symbols('b0:4'));CL=sy.Matrix(2,2,sy.symbols('c0:4'));CR=sy.Matrix(2,2,sy.symbols('d0:4'));T=sy.Matrix(2,2,sy.symbols('t0:4'));U=-T.T
gamma=sy.BlockMatrix([[sy.zeros(2),sy.eye(2)],[sy.eye(2),sy.zeros(2)]]).as_explicit();M=sy.diag(A,B);bar=sy.diag(A.T,B.T)
srcp=sy.I*(bar*gamma+gamma*M);srcq=sy.I*gamma*M
assert srcp[2:,:2]==sy.I*(B.T+A) and srcq[2:,:2]==sy.I*A
gen=sy.diag(sy.I*T,sy.I*U);genbar=sy.diag(sy.I*T.T,sy.I*U.T);K=sy.diag(CL,CR)
kinp=sy.I*(genbar*gamma*K+gamma*K*gen);kinq=sy.I*gamma*K*gen
assert (kinp[2:,:2]+CL*T-T*CL).applyfunc(sy.expand)==sy.zeros(2)
assert (kinq[2:,:2]+CL*T).applyfunc(sy.expand)==sy.zeros(2)
TL=list(map(dec,d['Y']['Tminus']));TR=[scale(trans(t),Q(-1)) for t in TL];rel={p:{} for p in PARTS};controls=defaultdict(int)
for part in PARTS:
 for order in ORDERS:
  rel[part][order]={}
  for side,ts in [('left',TL),('right',TR)]:
   C,V,M,O,B=terms(d,order,part,side,ts);pp=[];qq=[]
   for t,v,m,o,b in zip(ts,V,M,O,B):
    endpoint=plus(scale(mul(C,t),Q(-1)),scale(m,II));p=plus(endpoint,plus(mul(t,C),scale(trans(o),II)));q=plus(endpoint,plus(scale(v,II),b));pp.append(enc(p));qq.append(enc(q))
    if part=='fixed':
     controls['omit_bosonic_source']+=len(b.d);controls['omit_proper_source']+=len(m.d);controls['wrong_generic_source_p_zero']+=len(plus(m,trans(o)).d)
   rel[part][order][side]={'p':pp,'q':qq}
assert all(controls.values())
finish('replay',rel,tick,'generic_chiral_congruence_combined_endpoints_on_independent_raw_replay_amplitudes',dict(controls))
