"""CHM1 exact coefficient IO;no combined Ward targets in scientific workers."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
PARTS=['chi4','log3over2','fixed'];ORDERS=['g2','g3','gY10','gY126'];SIDES=['left','right'];ZERO=Mat(16,16)
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('CHM1_PEER_OR_WARD_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_matter_gauge_vertex_finite_color','canonical_so10_ghost_triangle_field_insertion','canonical_so10_coupled_fermion_finite_counterterm','canonical_so10_yukawa_heat_ward_response','canonical_so10_gauge_source_heat_p_response'] and p.name.endswith('.gz'):raise PermissionError('CHM1_OLD_COMBINED_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def terms(d,order,part,side,T):
 tag={'g2':None,'g3':'gauge','gY10':'Y10','gY126':'Y126'}[order]
 C=dec(d['KIN'][part][tag][side]) if tag else ZERO
 V=list(map(dec,d['VERT'][part][tag][side])) if tag else [ZERO]*45
 sg='auxiliary' if order=='g2' else 'ordinary';other='right' if side=='left' else 'left';have=order in ['g2','g3']
 M=list(map(dec,d['SRC'][sg][part][side])) if have else [ZERO]*45
 O=list(map(dec,d['SRC'][sg][part][other])) if have else [ZERO]*45
 fac=Q('xi') if order=='g2' else ONE
 M=[scale(m,fac) for m in M];O=[scale(m,fac) for m in O]
 rho=dec(d['RHO']['mixed' if order=='g2' else 'ordinary']['chi' if part=='chi4' else 'fixed']) if have and part!='log3over2' else Mat(45,45)
 B=[scale(combine([rho.d.get((b,c),Z) for b in range(45)],T),fac) for c in range(45)]
 return C,V,M,O,B
def dimensional(d,order,side,jet):
 if order in ['g2','g3']:
  out=list(map(dec,d['GTT'][side][order[1:]][jet]))
  if order=='g3' and jet=='q':out=[plus(v,dec(w)) for v,w in zip(out,d['GFI'][side])]
  return out
 return [scale(dec(m),II) for m in d['YVF']['fermion_vertex_'+side][0 if order=='gY10' else 1]] if jet=='q' else [ZERO]*45
def finish(role,rel,tick,method,controls):
 d=packed(HERE/(role+'_inputs.json.gz'));response={};counts={}
 for group in ['relative_chi4','relative_log','relative_fixed','dimensional_fixed','heat_length_log','heat_total_fixed']:
  response[group]={};counts[group]={}
  for order in ORDERS:
   response[group][order]={};counts[group][order]={}
   for side in SIDES:
    response[group][order][side]={};counts[group][order][side]={}
    for jet in ['p','q']:
     rd=dimensional(d,order,side,jet);rr={p:list(map(dec,rel[p][order][side][jet])) for p in PARTS}
     aa={'relative_chi4':rr['chi4'],'relative_log':rr['log3over2'],'relative_fixed':rr['fixed'],'dimensional_fixed':rd,'heat_length_log':[scale(m,Q(-1)) for m in rr['log3over2']],'heat_total_fixed':[minus(a,b) for a,b in zip(rd,rr['fixed'])]}[group]
     response[group][order][side][jet]=list(map(enc,aa));counts[group][order][side][jet]=sum(len(m.d) for m in aa)
 out={'role':role,'method':method,'elapsed_after_imports':time.perf_counter()-tick,'response':response,'nonzero_counts':counts,'controls':controls,'general_family_factors':{s:d['YVF']['family_'+s] for s in SIDES},'operator_identity_used':'Rheat=Rdim-bSigma Crel','selected_local_parent_classes':['kinetic_PdP','proper_BPP','proper_KPcP','proper_JBdc'],'independent_component_heat_integration':False,'quantum_coefficient_fitted':False,'free_finite_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
