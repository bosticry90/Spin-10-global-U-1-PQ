# CHM1: complete local projection and actual comparison-identity extraction

Prospective proof;native checks and validation must qualify it.

## Completeness is for one specific local coefficient

Work at A=B=x=Lambda=a=J=0 after differentiating external sources,with two
physical Nambu matter fields,one ghost and one ordinary external derivative.
Keep full Cartesian scalars,all45 ghosts,both widths and both general symmetric
Yukawa family matrices. Ghost dimension1 makes the Slavnov density dimension5;
the parent one-loop local functional has dimension4 and ghostnumber0.
Mass-positive coefficients give zero-jet bilinears or lower UV degree and
cannot contribute this dimension-zero one-jet coefficient in the admitted
polynomial ring. They are not removed from massive amplitudes.

The only source-independent local parents are PslashpartialP and BPP.
The xPP parent has qx proportional c*x in the full Cartesian expansion and
vanishes in this target. Four-P/higher-derivative parents exceed dimension4.
The only source parents contributing here are K_P*c*P and J_B*partial*c.
For the latter,the classical Euler column contains the actual matter current.
Its source derivative is taken before J0. At one loop no additional proper
closed-fermion-loop correction to J_BpartialC exists:the single bosonic leg
would attach through a bridge to a fermion current tadpole,which is1PR.

Other source columns do not enter this one-jet projection. J_x*c would need
a mass coefficient to supply dimension4 and a scalar index;there is no
Lorentz-scalar one-derivative J_x*c operator without an external vector.
Multiplying by the scalar Euler YPP therefore gives a different zero-jet
mass channel. J_x*c*x retains x and vanishes here. The auxiliary Euler has
no PP term;the nonminimal cubic CCa derivatives leave two ghosts or an
antighost. An antighost-source PP parent exceeds dimension4;its Euler
partial²c cannot repair that dimension. Ghost-source Euler terms retain
antighosts or sources. Background/source/hatted/sterile parents are retained
in the full theory but vanish in this selected external ideal or belong to
different derivative/field content. This is not the complete counterterm
module for the full nonlinear Slavnov functional.

Thus authenticated FHK,VFC,PSF,BSF cover all local parents of the selected
comparison. CSW independently supplies the complete10 ordered cutoff words
including constant derivative and auxiliary roots;their existence is not
inferred from a desired finite cancellation.

## Coefficients follow from the field/source operation

For each chirality let T be the actual generator (right U=-T_left.T),C the
kinetic comparison,V the measured current comparison,and M_L,M_R the proper
source matrices. In the inherited Fourier/Euler convention the images are

 kinetic:p=-[C,T],q=-C*T;
 vertex:p=0,q=i*V;
 source:p=i*(M_side+M_other.T),q=i*M_side;
 bosonic-source:p=0,q=sum_b rho[b,c]*T_b.

For ordinary g³,all four parents occur. For lower g²xi,only the proper-source
and bosonic-source parents occur;their factored xi is reinserted exactly once
before comparison with raw GTT g²,which already contains xi. For each gYdagY
carrier,only the kinetic/current parents occur. General family factors and
their right conjugate orientation are retained,with no extra factor3 or half.

An independent derivation retains the two kinetic/source endpoints in an
alternating physical bilinear. Write A=-C*T+i*M_side. The direct Fourier
coefficient is p=A+T*C+i*M_other.T and q=A+i*V+rho*T. The block-congruence
derivation below checks the generic noncommutative endpoint formula before
substituting actual model matrices. This is a distinct algebraic extraction,
not another independently regulated component integration.

## Why the measured dimensional insertion can be used

For the actual SMA/source action qS=Ihat. At finite graded Gaussian order
the same twice-polarized source relation used in CSW applies before the
cutoff is introduced. For the dimensional comparator,take the one-loop
coefficient integrals initially in their meromorphic convergence domain
with inherited nonexceptional external momenta/joint tests. Ordered inverse
and graded trace identities hold there;analytic continuation preserves the
identity. The unregularized diagonal tangent trace iszero in this actual
projection. Therefore bSigma Gamma_dim=(i/2)STr(G Ihat'') for this coefficient.
The raw GTT/GFI/YVF12-support calculation is exactly that measured insertion,
including both PS hatted blocks and the external ghost derivative UC.
This excludes a new uncomputed anomaly term only in this two-matter channel;
no determinant-phase or all-sector theorem follows.

Take the dimensional Laurent finite coefficient and heat finite part in the
specified UV-first joint domain. CSW proves physical external projection
stable under the first classical source/field operation. That operation
does not itself close a numerical Lorentz trace or introduce an epsilon
factor. It commutes with the coefficientwise finite-part extraction. The
complete local difference C_rel=Gamma_dim,FP-Gamma_heat,FP is given by the
four parents above. No arbitrary change of finite subtraction is made.
Consequently the actual heat response is fixed by

 R_heat=R_dim-bSigma C_rel.

This evaluates an operator whose source/order/domain were proved separately.
It is legitimate use of an identity,not assigning unknown breaking terms
to cancel a chosen counterterm. R_dim comes from the independent raw hatted
insertion;C_rel comes from independent raw amplitudes. Neither input is a
stored Ward remainder. The common chi4 direction must cancel from their
relative image without choosing chi4. Keep logarithmic and fixed heat pieces
separate. Old GHPp and YHTq are late independent sensitive controls.

No old CFC/MSP counterterm is an extraction input. A possible later finite
restoration will require applying the resulting complete response to an
admissible correlated field/source functional and checking its higher
descendants. No current result closes that additional obligation,chooses
free finite constants,or licenses physical benchmark adoption.
