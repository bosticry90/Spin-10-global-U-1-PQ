from data import *
from itertools import product,permutations
start=begin('primary')
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.kronecker_product(pa[0],s.eye(2)),s.kronecker_product(pa[1],s.eye(2)),s.kronecker_product(pa[2],pa[0]),s.kronecker_product(pa[2],pa[1])]
pair={w:gam[w[0]]*gam[w[1]] for w in product(range(4),repeat=2)}
four={w:s.SparseMatrix(pair[w[:2]]*pair[w[2:]]).todok() for w in product(range(4),repeat=4)};pair={w:s.SparseMatrix(m).todok() for w,m in pair.items()}
@lru_cache(None)
def tr(w):
 A=four[w[:4]];B=pair[w[4:]] if len(w)==6 else four[w[4:]]
 return sum(v*B.get((j,i),0) for (i,j),v in A.items())
def cyc(w):return min(w[j:]+w[:j] for j in range(len(w)))
D=s.Symbol('D',positive=True);Q,t=s.symbols('Q t',positive=True)
raw={};poles={};finite={};heats={}
# Literal leading numerator heat insertion, kept separate from Taylor angulars.
radial=s.integrate(s.exp(-6*t*Q),(Q,0,s.oo));assert s.simplify(radial-1/(6*t))==0
for mu,nu,rho,j in product(range(4),repeat=4):
 a=-sum(tr((a,mu,j,nu,a,rho)) for a in range(4))
 b=-sum(tr((a,mu,a,nu,j,rho)) for a in range(4))
 summ=sum(tr((j,mu,a,nu,a,rho))+tr((a,mu,j,nu,a,rho))+tr((a,mu,a,nu,j,rho)) for a in range(4))
 v=[a/D,b/D,2*summ/(D*(D+2))];h=s.simplify(4*t*radial*summ/24)
 key=(mu,nu,rho,j);raw[key]=v;poles[key]=[s.simplify(x.subs(D,4)) for x in v]
 heats[key]=[0,0,h];finite[key]=[s.simplify(-2*s.diff(x,D).subs(D,4)-(h if n==2 else 0)) for n,x in enumerate(v)]
def tri(table):
 out={}
 for lor in product(range(4),repeat=3):
  block={(0,1,2):[s.S.Zero]*8,(0,2,1):[s.S.Zero]*8}
  for perm in permutations(range(3)):
   a,b,c=perm;w=cyc(perm)
   for j in range(4):
    A,B,U=table[lor[a],lor[b],lor[c],j]
    for leg,val in [(a,A+B+2*U),(b,B+U)]:
     for independent in range(2):block[w][4*independent+j]+=s.Rational(1,6)*(int(leg==independent)-int(leg==2))*val
  out[','.join(map(str,lor))]={''.join(map(str,w)):list(map(lambda x:str(s.simplify(x)),v)) for w,v in block.items()}
 return out
boxpole={cyc(w):s.S.Zero for w in product(range(4),repeat=4)};boxfixed=dict(boxpole);boxbad=dict(boxpole)
for w in product(range(4),repeat=4):
 mu,nu,rho,sig=w;parts=[sum(tr((a,mu,a,nu,b,rho,b,sig)) for a,b in product(range(4),repeat=2)),sum(tr((a,mu,b,nu,a,rho,b,sig)) for a,b in product(range(4),repeat=2)),sum(tr((a,mu,b,nu,b,rho,a,sig)) for a,b in product(range(4),repeat=2))]
 z=sum(parts)/(8*D*(D+2));boxpole[cyc(w)]+=z.subs(D,4);boxfixed[cyc(w)]+=-2*s.diff(z,D).subs(D,4);boxbad[cyc(w)]+=sum(parts[:2])/192
# Radial constants by exact Gamma ratio and independent positive partial fractions.
e=s.Symbol('epsilon');y=s.Symbol('y',positive=True);rad=[]
for r in [1,2]:
 ratio=s.prod(j-e for j in range(2,r+2))/s.factorial(r+1)
 dim=s.diff(ratio,e).subs(e,0)
 frac=s.apart(y**(r+1)/(y+1)**(r+2),y);heat=0
 for term in s.Add.make_args(frac):
  num,den=s.fraction(term);power=s.degree(den,y)
  if power==1:assert s.simplify(term-1/(y+1))==0
  else:heat+=s.integrate(term,(y,0,s.oo))
 rad.append({'rank_r':r,'dimensional_mass_completion_constant':str(dim),'heat_mass_completion_constant_without_gamma_log':str(heat),'relative_universal_constant':str(s.simplify(dim-heat))})
finish('primary',{'triangle_pole':tri(poles),'triangle_fixed':tri(finite),'triangle_heat_jet':tri(heats),'box_pole':{','.join(map(str,k)):str(v) for k,v in sorted(boxpole.items())},'box_fixed':{','.join(map(str,k)):str(v) for k,v in sorted(boxfixed.items())},'box_drop_one_pairing':{','.join(map(str,k)):str(v) for k,v in sorted(boxbad.items())},'critical_radial_constants':rad,'ordered_heat_nonzero_components':sum(v[2]!=0 for v in heats.values()),'heat_length_triangle':6,'heat_length_box':8,'triangle_heatlength_shift':str(s.log(s.Rational(3,2))),'box_heatlength_shift':str(s.log(2)),'physical_spin_trace':4,'Gaussian_triangle':'1/6','Gaussian_box':'1/8','closed_family_count':3},start)
