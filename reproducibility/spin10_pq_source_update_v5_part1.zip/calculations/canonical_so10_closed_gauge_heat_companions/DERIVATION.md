# CGH1 ordered critical symbols and heat jets

Let rawA=-sum_a tr(a mu j nu a rho), rawB=-sum_a tr(a mu a nu j rho),
rawU=2sum_a[tr(j mu a nu a rho)+tr(a mu j nu a rho)+tr(a mu a nu j rho)],
where traces have physicalspin4 and only barred a,j,mu,nu,rho. The actual
ordered cubic Taylor vector is
A_D=rawA/D, B_D=rawB/D, U_D=rawU/[D(D+2)],
(A_D+B_D+2U_D)*p1+(B_D+U_D)*p2, with Gaussian1/6 and all six leg orders.
Do not identify these derivatives with full-hatted reference numerators.
The extra cubic heat vector follows the leading three-slash numerator and
fourth moment with one k contracted against(2p1+p2). Integrate its positive
radial moment explicitly at heat6. Its sign follows the chosen momentum route.

At n4 the actual all-bar numerator uses three rank4 pairings. Coefficient
1/8 multiplies raw/[D(D+2)]. No heat Taylor is needed at logarithmic degree0.
Derive its dimensional finite jet and preserve every ordered word before cyclic
finite-color reduction. Scalar-free quantum vertices; Gamma_ref[A_H] is not
being discarded from an independently varied background functional.

For temporary mass1, radial critical completion is Q^r/(Q+1)^(r+2).
The D integral's pole-subtracted constant is -H_(r+1)+1. The positive-heat
integral's constant is -gamma-log(2nt)-H_(r+1). Derive these identities by
Gamma ratios/partial fractions in primary and recurrence/Schwinger in replay.
Thus all r share chi4+log(n/2) relative to the n2 heat4 bubble convention.
Convergent subtracted remainder has the same limit for the two regulators at
fixed nonexceptional Euclidean momenta. This is not a general heat-trace
cyclicity or quantum-equivalence theorem. No scaleless integral is erased.

The new finite word is (chi4+log(n/2))*pole -2partial_D(pole_D)|4 -heatjet.
Compare the independently derived coefficient tensors, not just a Ward target.
CQH's power contacts remain even if the finite comparison is local. A common
curvature coefficient would require equality of the ratios of all three
measured degree projections; test rather than impose that condition.
