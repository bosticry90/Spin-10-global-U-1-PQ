# CGH1: complete parity-even pure-gauge closed-fermion heat companions

Question: do the actual cubic and quartic DIM-minus-positive-free-edge-heat
coefficients supply covariant companions to the measured quadratic term, or
an explicit noncovariant relative polynomial? This is a new finite regulator
comparison, not a repeat GPC pole/GFD covariant-reference calculation. Base
4e0316dd467e49d732c37c7c6f18ab04df304427/main33111oldblobs. State113/34of39,
wholeSpin10xPQ ACTIVE/incomplete. Reuse CQH quadratic power and finite results.

Freeze actual SMA mass-independent PPonly barred vertices/numerators and
full-D denominator/angular continuation, Gaussian determinant half, physical
trace4, both actual transposed charges, closedfamily3once. Reuse GFD parity-
even reversal equivalence. External hats0, nonexceptional Euclidean momenta,
positive auxiliary IR mass on Taylor denominators only. No new physical mass,
Yukawa point, width, VEV, benchmark, baseline or quantum scheme. Full odd phase
is excluded. The formal heat on each edge is exp(-2t k_edge²).

Cubic momenta k,k-p1,k-p1-p2; retain all six finite-color orderings, p3=-p1-p2,
1024 Lorentz/momentum/color coefficient positions. n4 zerojet retains all three
fourth angular pairings and all70cyclic words. No45^4 component expansion is
needed for a universal arbitrary-matrix traceword equality. n>4 relative
contribution vanishes only under the frozen nonexceptional convergence domain;
no exceptional/causal/constant-vacuum/multipleproduct extension is asserted.

Primary literal4spinor products and D-sphere angular derivatives, leading cubic
power symbol times the heatlinear +4t k.(2p1+p2),radial exp(-6tQ). Replay metric
trace recurrence plus independently differentiated angular moments and positive
Schwinger moment integral. Quartic uses heat8, not heat4or6. Derive critical
radial finite difference for ranks1/2 via Gamma recurrence versus partial
fractions in a positive mass completion. Express in symbolic chi4 fixed by
CQH/FHK; derive logarithmic heatlength shifts, never select them from a Wardfit.

Late verifier compares full pole words against already qualified GFD/GPC,
then both new finite routes, implicit zeros and QQHquadratic immutable recipe.
Assemble measured n2/n3/n4 plus power term exactly once. Determine whether
one common curvature normalization fits all three degrees; if it does not,
record exact differences, not an anomaly verdict. The Ward image of a local
comparison is algebraic evidence only, not a newly integrated insertion/QAP.

Controls omit cubic heatlinear, substitute heat4for6/8, prematureD4, omit
one quartic angular pairing, missing/extra half,family3,commuted colorwords,
and omit CQHpower. Report actual insensitive positions. Both methods must
agree before assembly; any mismatch fails without changing the quantum input.
Possible outcomes qualified comparison/counterterm candidate, scoped mismatch,
underdefinition or incomplete resource-limited work. No physical baseline adopted.

Freeze8sources/copies/inputs before sequential P/R/V,600s afterimports each,
8GiBsampled private cap,350MiB launch commit floor,16MiBpacket. Preserve native
failures and complete captures, version any corrections. Reuse authenticated
freshGAB E4root0steps0/0/0/0/0/2,custody2sevenNOTPASS. Validate before local
commit; external before/index/after seals preserve33111priorblobs. No old
scientific replay. Authority ceiling: actual parity-even mass-independent pure
quantum-gauge rawdimensional/positive-heat local relative functional only.
Not complete finite chiral source/background restoration, oddPfaffianphase,
QAP/multiplecontacts/measure, massive matterC1,E5/A5 or physicalGUT. Mixedscalar
heat companions still separate. Shared action/analytic premises/olddata/SymPy/
AIauthor limit independence. Preserve adverse scalarpoints,quartetFAIL,flavor
pause,HB1/C5,state/main/history. No agents/branches/worktrees/push/publication,
outreach or foundational adoption. AI target: complete a required class while
separating heatlength finite effects, pole consistency and physical significance.
