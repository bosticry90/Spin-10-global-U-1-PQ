# CGH1: complete measured parity-even pure-gauge heat comparison

The actual cubic and quartic calculations qualify within the frozen mass-
independent, external-hats-zero, nonexceptional Euclidean domain. ReceiptSHA
7f1d05df134ba437f6427e9107a2e2880e200e01c7d1adaa30c6bfe2053780c5.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

Let S2,S3,S4 be the quadratic, cubic and quartic degree projections of the
already measured actual fermion gauge-pole functional, including their actual
gauge powers and Tr48 normalization. The finite raw DIM-minus-positive-edge-
heat comparison is exactly

    (chi4-5/12) S2
    +(chi4+log(3/2)+1/2) S3
    +(chi4+log2+5/6) S4.

The common loop normalization is1/(16pi²); pure-gauge family3 occurs once.
CQH's additional g10²Tr48(A_mu A_mu)/(8t) power contact remains by immutable
reference. This formula is a measured relative local functional, generally
nonzero. It is not an assertion that the finite heat effective action is local,
that a physical power subtraction has been adopted, or that the theory has
been restored. The full nonlocal common amplitude is outside this difference.

Both new routes compare all1024triangle and70quartic coefficient positions,
including zeros, plus their fixed/heat/control tensors. Primary uses explicit
four-spinor products and full-D angular derivatives before the finite limit;
replay uses metric trace recurrence and independent epsilon/Schwinger moments.
Late checks reproduce both qualified GPC pole implementations and GFD's barred
reference pole tensors. No model charge tensor or unknown coefficient is fitted.

The critical radial integral at any rank r=1,2 has dimensional completion
constant -H_(r+1)+1 and positive-heat constant -gamma-log(2nt)-H_(r+1).
The two derivations use Gamma ratios/partial fractions and independent
Schwinger recurrences. Therefore the n3 heat6 and n4 heat8 shifts relative
to CQH heat4 are log(3/2) andlog2. They cannot be suppressed by pretending
all loops have the same heat length. The finite angular jet contributes1/2
of the complete cubic pole tensor and5/6 of the quartic one.

An informative insensitive control is preserved: the cubic linear heat jet
has40nonzero ordered components, but cancels completely after the required
cyclic Bose summation and momentum conservation. Omitting that jet thus changes
zero summed coefficients here. This does not justify omitting it in an open
loop or a differently ordered/source calculation. The raw ordered terms were
derived before observing cancellation. Wrong heat4 changes144triangle and
12quartic positions, prematureD4 changes12quartic finite positions, omission
of one quartic pairing changes16, wrong Gaussian half/family count changes156,
and commuting all colorwords erases12nonzero quartic positions. CQH power
omission affects45actual gauge diagonal charge positions.

A single common curvature coefficient cannot represent this selected finite
functional: the degree3-minus-degree2 multiplier is log(3/2)+11/12 and the
degree4-minus-degree2 multiplier is log2+5/4, both positive and independent of
chi4. This rejects only that one-parameter invariant description. It is not a
no-go theorem for general local, source-completed finite counterterms, and is
not a gauge anomaly diagnosis. Its algebraic Ward variation must remain distinct
from an independently regulated insertion and the full quantum source identity.

Complete relative recipe packed/rawSHA256:
a56720569a145b5d591cfb0c04be7bff5f3dad14a7b032b6c16791b589cf45ce /
900d0a071227d5a76554334dabe9b5c24facc73ce1fb38a8f09dcdeb625369c6.
The quadratic recipe is referenced exactly once, not re-added or recomputed.
The original covariant-comparator GWF/BWF records remain intact; these are
different regulator comparisons and their finite constants need not coincide.

P/R/V native0 in0.711763/0.615887/4.870253s afterimports. Primary and replay
each have one early memory sample,487424/397312B; verifier3samples,max47357952B.
These are sampled observations, not continuous peaks.77/85bindings,8source
copies, pre-reportpacket99730B. All600s/8GiBsampled/350MiB/16MiB limits respected.
No worker/controller failure. E4 authenticated fresh GABroot0steps0/0/0/0/0/2,
custodyexit2sevenNOTPASS. External before/index/after seals must preserve33111
oldblobs and exact new source/output bytes; no remote action is authorized.

Next: use the cyclic leading-symbol argument and actual chiral-path algebra
to calculate the mixed2Y+g,2Y+2g and4Y positive-heat companions, with independent
ordered-loop/metric routes. Do not infer them by covariantizing CQH scalar2.
The proposed structural reduction is testable: cubic cyclic leading-symbol
terms may cancel while the numerator derivative remains, and quartic rank4
has common D(D+2). The actual mass-current phases and allowed path factors
must still be derived and compared, not assumed from the pure-gauge answer.

No complete finite chiral Slavnov/QAP/phase/source/background equivalence,
multiple contacts, massive matter threshold or physical GUT is claimed. No
finite freedom, physical input, foundation, state or protected stage changed.
Both distinct scalar failures, historical quartetFAIL, pausedflavor, HB1/C5
blocks and all failures/evidence persist. Shared action/formal dimensional and
heat assumptions/data/software/AIauthor limit independent assurance. The
investigation remains ACTIVE/incomplete, E5/A5 unqualified, authority34/39.
