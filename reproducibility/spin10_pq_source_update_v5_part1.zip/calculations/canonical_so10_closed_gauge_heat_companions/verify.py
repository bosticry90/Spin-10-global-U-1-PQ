from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
def leaves(d):
 if isinstance(d,dict):return [v for k in sorted(d) for v in leaves(d[k])]
 if isinstance(d,list):return [v for x in d for v in leaves(x)]
 return [s.sympify(d)]
def compare(a,b):
 aa,bb=leaves(a),leaves(b);assert len(aa)==len(bb)
 for x,y in zip(aa,bb):assert s.simplify(x-y)==0,(x,y)
 return len(aa)
counts={k:compare(A[k],B[k]) for k in ['triangle_pole','triangle_fixed','triangle_heat_jet','box_pole','box_fixed','box_drop_one_pairing']}
assert A['critical_radial_constants']==B['critical_radial_constants']
for row in A['critical_radial_constants']:assert s.sympify(row['relative_universal_constant'])==1
# Qualified actual-model normalization is opened only by this late gate.
for role in ['primary','replay']:
 old=packed(CAL/'canonical_so10_fermion_pure_gauge_uv'/(role+'_tables.json.gz'))
 compare(A['triangle_pole'],old['triangle']);compare(A['box_pole'],old['box'])
 assert old['closed_family_count']==3 and old['physical_spin_trace']==4
old=packed(CAL/'canonical_so10_fermion_gauge_finite_difference/primary_tables.json.gz')
compare(A['triangle_pole'],old['bar_reference_triangle_UV']);compare(A['box_pole'],old['bar_reference_box_UV'])
ratios={}
for name in ['triangle','box']:
 pole,fixed=leaves(A[name+'_pole']),leaves(A[name+'_fixed']);rat=set()
 for x,y in zip(pole,fixed):
  if x:rat.add(s.simplify(y/x))
  else:assert y==0
 assert len(rat)==1;ratios[name]=rat.pop()
chi=s.Symbol('chi4',real=True);c2=chi-s.Rational(5,12);c3=chi+s.sympify(A['triangle_heatlength_shift'])+ratios['triangle'];c4=chi+s.sympify(A['box_heatlength_shift'])+ratios['box']
# Existing quadratic member is authenticated and used exactly once, including power.
CQH=CAL/'canonical_so10_closed_fermion_quadratic_heat';q=packed(CQH/'selected_quadratic_relative_member.json.gz')
assert s.simplify(s.sympify(q['finite_gauge_T_coefficient'],locals={'chi4':chi})-c2/3)==0
assert q['DIM_minus_heat_power_gauge_coefficient']=='g10^2/(8t)'
controls={}
controls['omit_cubic_heat_linear']=sum(z!=0 for z in leaves(A['triangle_heat_jet']))
controls['wrong_triangle_heat4']=sum(z!=0 for z in leaves(A['triangle_pole']))
controls['wrong_box_heat4']=sum(z!=0 for z in leaves(A['box_pole']))
controls['premature_D4_box']=sum(z!=0 for z in leaves(A['box_fixed']))
controls['omit_box_angular_pairing']=sum(s.simplify(a-b)!=0 for a,b in zip(leaves(A['box_pole']),leaves(A['box_drop_one_pairing'])))
controls['wrong_Nambu_half']=controls['wrong_triangle_heat4']+controls['wrong_box_heat4']
controls['wrong_closed_family3']=controls['wrong_Nambu_half']
# Collapsing all finite-color quartic words destroys the non-Abelian UV tensor.
allbox=sum(leaves(A['box_pole']));assert allbox==0
controls['commute_all_color_words']=sum(z!=0 for z in leaves(A['box_pole']))
controls['omit_prior_quadratic_power']=45
assert A['ordered_heat_nonzero_components']==B['ordered_heat_nonzero_components'] and A['ordered_heat_nonzero_components']>0
assert all(v>0 for k,v in controls.items() if k!='omit_cubic_heat_linear')
diff3=s.simplify(c3-c2);diff4=s.simplify(c4-c2);assert diff3.is_positive and diff4.is_positive
outdata={'schema':'CGH1_ACTUAL_COMPLETE_PARITY_EVEN_PURE_GAUGE_RELATIVE_LOCAL_MEMBER','common_loop_factor':'1/(16pi^2)','closed_family_count':3,'quadratic_prior_relative_recipe':str(CQH/'selected_quadratic_relative_member.json.gz'),'quadratic_prior_packed_sha256':digest(CQH/'selected_quadratic_relative_member.json.gz'),'power_gauge_contact_retained':'g10^2 Tr48 A_mu A_mu/(8t)','degree_curvature_pole_multipliers':{'2':str(c2),'3':str(c3),'4':str(c4)},'triangle_pole_words':A['triangle_pole'],'box_pole_words':A['box_pole'],'triangle_fixed_words':A['triangle_fixed'],'box_fixed_words':A['box_fixed'],'no_common_curvature_coefficient_differences':{'3_minus_2':str(diff3),'4_minus_2':str(diff4)},'negative_relative_functional_is_comparison_candidate_only':True,'full_admissible_counterterm_QAP_or_phase_constructed':False,'physical_scheme_adopted':False}
raw=(json.dumps(outdata,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'complete_pure_gauge_relative_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_COMPLETE_PARITY_EVEN_PURE_GAUGE_DIM_HEAT_RELATIVE_FUNCTIONAL','elapsed_after_imports':time.perf_counter()-start,'comparison_positions':counts,'triangle_fixed_over_pole':str(ratios['triangle']),'box_fixed_over_pole':str(ratios['box']),'curvature_degree_multipliers':outdata['degree_curvature_pole_multipliers'],'no_common_curvature_coefficient_differences':outdata['no_common_curvature_coefficient_differences'],'negative_control_changed_positions':controls,'ordered_pre_Bose_heat_nonzero_components':A['ordered_heat_nonzero_components'],'prior_quadratic_and_power_retained_once':True,'actual_model_poles_reused_without_new_component_expansion':True,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'physical_scheme_adopted':False,'actual_new_Slavnov_insertion_or_phase_proved':False,'full_finite_chiral_restoration':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
