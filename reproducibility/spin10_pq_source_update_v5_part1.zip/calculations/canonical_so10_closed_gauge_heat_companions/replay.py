from data import *
from itertools import product,permutations
start=begin('replay')
@lru_cache(None)
def tr(w):
 if not w:return s.Integer(4)
 a=w[0];return sum((-1)**(j+1)*int(a==w[j])*tr(w[1:j]+w[j+1:]) for j in range(1,len(w)))
def cyc(w):return min(w[j:]+w[:j] for j in range(len(w)))
def accumulate(table):
 out={}
 for mu,nu,rho in product(range(4),repeat=3):
  lor=[mu,nu,rho];blocks={'012':[s.S.Zero]*8,'021':[s.S.Zero]*8}
  for a,b,c in permutations(range(3)):
   word=''.join(map(str,cyc((a,b,c))))
   for j in range(4):
    pfirst,psecond=table[lor[a],lor[b],lor[c],j]
    for leg,v in [(a,pfirst),(b,psecond)]:
     for ind in range(2):blocks[word][4*ind+j]+=v*(int(leg==ind)-int(leg==2))/6
  out[f'{mu},{nu},{rho}']={w:list(map(lambda x:str(s.simplify(x)),v)) for w,v in blocks.items()}
 return out
D=s.Symbol('D',positive=True);e=s.Symbol('epsilon');q,t=s.symbols('q t',positive=True)
# Positive Schwinger moment at heat6, without a literal Clifford representation.
heat_moment=s.integrate(4*t*s.exp(-6*t*q),(q,0,s.oo))/24
pole={};fixed={};heat={}
for mu,nu,rho,j in product(range(4),repeat=4):
 na=-sum(tr((a,mu,j,nu,a,rho)) for a in range(4));nb=-sum(tr((a,mu,a,nu,j,rho)) for a in range(4))
 nc=sum(tr((j,mu,a,nu,a,rho))+tr((a,mu,j,nu,a,rho))+tr((a,mu,a,nu,j,rho)) for a in range(4))
 first=(na+nb)/D+4*nc/(D*(D+2));second=nb/D+2*nc/(D*(D+2))
 hv=[2*heat_moment*nc,heat_moment*nc];key=(mu,nu,rho,j)
 pole[key]=[s.simplify(v.subs(D,4)) for v in [first,second]]
 fixed[key]=[s.simplify(s.diff(v.subs(D,4-2*e),e).subs(e,0)-h) for v,h in zip([first,second],hv)];heat[key]=hv
bp={cyc(w):s.S.Zero for w in product(range(4),repeat=4)};bf=dict(bp);bad=dict(bp)
for w in product(range(4),repeat=4):
 mu,nu,rho,sig=w
 pairs=[sum(tr((a,mu,a,nu,b,rho,b,sig)) for a,b in product(range(4),repeat=2)),sum(tr((a,mu,b,nu,a,rho,b,sig)) for a,b in product(range(4),repeat=2)),sum(tr((a,mu,b,nu,b,rho,a,sig)) for a,b in product(range(4),repeat=2))]
 ang=sum(pairs)/(8*(4-2*e)*(6-2*e));bp[cyc(w)]+=ang.subs(e,0);bf[cyc(w)]+=s.diff(ang,e).subs(e,0);bad[cyc(w)]+=sum(pairs[:2])/192
# Schwinger recurrence: R_r=(r+1-eps)/(r+1)*R_(r-1),
# positive-heat finite constants decrement by1/(r+1); base dim0/heat-1.
dim=s.S.Zero;h=-s.S.One;rad=[]
for r in [1,2]:
 dim-=s.Rational(1,r+1);h-=s.Rational(1,r+1)
 rad.append({'rank_r':r,'dimensional_mass_completion_constant':str(dim),'heat_mass_completion_constant_without_gamma_log':str(h),'relative_universal_constant':str(dim-h)})
finish('replay',{'triangle_pole':accumulate(pole),'triangle_fixed':accumulate(fixed),'triangle_heat_jet':accumulate(heat),'box_pole':{','.join(map(str,k)):str(v) for k,v in sorted(bp.items())},'box_fixed':{','.join(map(str,k)):str(v) for k,v in sorted(bf.items())},'box_drop_one_pairing':{','.join(map(str,k)):str(v) for k,v in sorted(bad.items())},'critical_radial_constants':rad,'ordered_heat_nonzero_components':sum(v[1]!=0 for v in heat.values()),'heat_length_triangle':6,'heat_length_box':8,'triangle_heatlength_shift':str(s.log(s.Rational(3,2))),'box_heatlength_shift':str(s.log(2)),'physical_spin_trace':4,'Gaussian_triangle':'1/6','Gaussian_box':'1/8','closed_family_count':3},start)
