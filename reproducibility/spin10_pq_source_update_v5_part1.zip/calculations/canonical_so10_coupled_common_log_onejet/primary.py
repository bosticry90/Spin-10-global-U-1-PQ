"""CLO1 graded source Euler slots and complete measured pole-functional image."""
from data import *
start=begin('primary')
# A generic odd-left kinetic variation:ghost c0,dc1,bar2/3,dpsi4/5,psi6/7.
def addex(a,b):
 out=dict(a)
 for k,v in b.items():out[k]=sy.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v!=0}
def wedge(a,b):
 out=defaultdict(lambda:sy.S.Zero)
 for ka,x in a.items():
  for kb,y in b.items():
   if not ka&kb:out[ka|kb]+=(-1)**sum((kb&((1<<i)-1)).bit_count() for i in range(8) if ka&(1<<i))*x*y
 return {k:sy.expand(v) for k,v in out.items() if sy.expand(v)!=0}
def word(seq,z=1):
 out={0:z}
 for i in seq:out=wedge(out,{1<<i:1})
 return out
ML=sy.Matrix(2,2,sy.symbols('ml0:4'));MR=sy.Matrix(2,2,sy.symbols('mr0:4'));R=MR.T;variation={};expected={}
for i in range(2):
 for j in range(2):
  variation=addex(variation,wedge(word([0,2+i],R[i,j]),word([4+j])))
  variation=addex(variation,{k:-v for k,v in wedge(word([2+i]),addex(word([1,6+j],ML[i,j]),word([0,4+j],ML[i,j]))).items()})
  expected=addex(expected,addex(word([0,2+i,4+j],(R+ML)[i,j]),word([1,2+i,6+j],ML[i,j])))
assert variation==expected
treeT=sy.Matrix([[1,sy.I],[-sy.I,-1]]);treeL=sy.I*treeT;treeR=-sy.I*treeT.T
assert not (sy.I*(treeL+treeR.T)).todok() and not (sy.I*treeL+treeT).todok()
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gg=[sy.kronecker_product(pa[1],z) for z in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];chir=sy.prod(gg);PL=(sy.eye(4)+chir)/2;PR=sy.eye(4)-PL
M=sy.kronecker_product(PL,ML)+sy.kronecker_product(PR,MR);MS=sy.kronecker_product(PL,ML.T)+sy.kronecker_product(PR,MR.T)
for gm in gg:
 gamma=sy.kronecker_product(gm,sy.eye(2));target=gamma*(sy.kronecker_product(PL,ML+MR.T)+sy.kronecker_product(PR,MR+ML.T));assert not (MS*gamma+gamma*M-target).applyfunc(sy.expand).todok()
MG=packed(CAL/'canonical_so10_matter_gauge_vertex_normalization/primary_tables.json.gz');MV=packed(CAL/'canonical_so10_matter_vector_source_pole/primary_tables.json.gz');MA=packed(CAL/'canonical_so10_matter_auxiliary_source_pole/primary_tables.json.gz');BS=packed(CAL/'canonical_so10_bosonic_source_onejet_finite/primary_v2_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
parts={};image={};boson={};remainder={}
for index,tag in enumerate(['g3','gY10','gY126','g2']):
 parts[tag]={};image[tag]={};boson[tag]={};remainder[tag]={}
 for side,ts,other in [('left',T,'right'),('right',U,'left')]:
  C=dec(MG['kinetic_loop'][side][index]) if tag!='g2' else Mat(16,16);vertex=list(map(dec,MG['loop_B'][side][index])) if tag!='g2' else [Mat(16,16) for _ in range(45)]
  src=MV if tag=='g3' else MA if tag=='g2' else None;ss=list(map(dec,src['loop_'+side])) if src else [Mat(16,16) for _ in range(45)];op=list(map(dec,src['loop_'+other])) if src else [Mat(16,16) for _ in range(45)]
  arr={n:{j:[] for j in ['p','q']} for n in ['kinetic','vertex','source']};im={'p':[],'q':[]};bb={'p':[],'q':[]};rr={'p':[],'q':[]}
  for c in range(45):
   kp=scale(minus(mul(C,ts[c]),mul(ts[c],C)),Q(-1));kq=scale(mul(C,ts[c]),Q(-1));vq=scale(vertex[c],II);sp=scale(plus(ss[c],trans(op[c])),II);sq=scale(ss[c],II)
   for n,pv,qv in [('kinetic',kp,kq),('vertex',Mat(16,16),vq),('source',sp,sq)]:arr[n]['p'].append(enc(pv));arr[n]['q'].append(enc(qv))
   ip=plus(kp,sp);iq=plus(plus(kq,vq),sq);bq=Mat(16,16)
   if tag in ['g3','g2']:
    bq=dec(BS['matter_q_images'][side]['ordinary' if tag=='g3' else 'mixed']['chi'][c]);bq=scale(bq,Q('xi')) if tag=='g2' else bq
   im['p'].append(enc(ip));im['q'].append(enc(iq));bb['p'].append(enc(Mat(16,16)));bb['q'].append(enc(bq));rr['p'].append(enc(ip));rr['q'].append(enc(plus(iq,bq)))
  parts[tag][side]=arr;image[tag][side]=im;boson[tag][side]=bb;remainder[tag][side]=rr
finish('primary',{'method':'odd_exterior_density_charge_Clifford_actual_complete_pole_functional','source_Euler_generic_derivation_remainder':0,'source_Euler_tree_p_remainder':0,'source_Euler_tree_q_unit':'-T','parts':parts,'matter_pole_image':image,'bosonic_pole_Euler_image':boson,'common_log_remainder':remainder,'remaining_fixed_g3_q':{s:BS['matter_q_images'][s]['ordinary']['fixed'] for s in ['left','right']},'common_chi_remains_free':True,'common_finite_direction_physically_adopted':False,'fixed_other_Born_word_constants_computed':False,'complete_fixed_conversion_computed':False,'quantum_poles_fitted':False,'new_loop_integrals':0,'full_coupled_restoration_claimed':False},start)
