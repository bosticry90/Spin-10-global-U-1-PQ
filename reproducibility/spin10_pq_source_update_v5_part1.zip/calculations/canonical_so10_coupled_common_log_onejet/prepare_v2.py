"""CLO1 prefactor correction: new bindings, no historical rebinding."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/coupled-common-log-onejet-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='ee04445a6359f89d950518232f0026e6235e6048'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bind=dict(read(HERE/'diagnostic_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
def add(p):p=p.resolve();bind[str(p)]=digest(p)
for folder,names in [('canonical_so10_matter_auxiliary_source_pole',['RESULT.md','DERIVATION.md','primary.py','replay.py']),('canonical_so10_matter_source_uv_assembly',['DERIVATION.md','verify.py'])]:
 for n in names:add(CAL/folder/n)
for n in ['CONTINUATION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
for n in ['diagnostic_tables.json.gz','diagnostic_capture.json','diagnostic_preparation.json']:add(HERE/n)
for n in ['DIAGNOSTIC_RECORD.md','diagnose.py','DIAGNOSTIC_RECORD.md.source.txt','diagnose.py.source.txt']:add(HERE/n)
with (CONTROL/'prelaunch_v2_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v2_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
assert r.returncode==0 and not read(CONTROL/'prelaunch_v2_preflight.json')['active_A10_M08_python_processes']
for n in ['prelaunch_v2_preflight.json','prelaunch_v2_preflight_stderr.txt']:add(CONTROL/n)
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'CLO1_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'historical_gate_preserved':'FAILED','scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('CLO1_V2_FROZEN',len(bind),'bindings',flush=True)
