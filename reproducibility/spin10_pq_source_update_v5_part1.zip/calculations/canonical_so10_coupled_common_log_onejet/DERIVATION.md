# CLO1: the common finite normalization multiplies the complete pole

FP_(mu,kappa)=FP_mu+kappa*L for the whole coefficient functional. The
specified subtraction Cfin=Gamma_cyclic-Gamma_heat therefore changes by
-delta(kappa)*L. BSF's chi4 has that same derivative-1,so its direction is
+L,including the MATTER part after matter is coupled. Multiplying the
measured proper UV pole coefficients by chi4 is the prescribed common-log
transport,not fitting a new quantum or finite coefficient.
Only the common n_log slope is universal. Using BSF's chi4 as its coordinate
retains that bubble's fixed reference constant in the split. Other Born-word
constants(e.g.different heat lengths) remain in the uncomputed FIXED coupled
conversion. They are not assigned chi4 times a pole by this calculation.

Let the actual inverse-fermion pole be i barslash(p) C,with rightC=C.T.
Write the measured physical gauge vertex as-i K_c,thus K=i L_vertex.
Source-free graded variation gives

 kinetic p:-[C,Tc], kinetic q:-C Tc, vertex p:0, vertex q:+K_c.

The actual proper KP C P pole is M_c=PL ML_c+PR MR_c,with its originally
measured chiral order,not an assumed anti-Hermitian restriction. In the
Nambu kernel the source Euler variation of the kinetic action gives

 source p:left i(ML+MR.T),right i(MR+ML.T),
 source q:left i ML,right i MR.

Derive this from qP=c M P and qbarP=c barP Msharp. Odd-left Leibniz on
barP gamma.partialP gives
c barP(Msharp gamma+gamma M)partialP+(partialc)barP gamma M P.
The charge transpose is Msharp=PL ML.T+PR MR.T;bar gamma flips chirality.
Fourier multiplication then yields the displayed matrices. The same
result follows by assigning the two kinetic endpoints momenta p andp+q.
For the tree generator ML=igT,MR=-igT.T,this gives sourcep0 and sourceq-gT,
fixing the normalization/sign without reading any loop target. It agrees
with MSP/CFC's anti-Hermitian special case;it does not assume it generally.
The local Euler representative retains the ordinary IBP current from the
quadratic action. No EOM or hatted internal-propagator simplification enters.

For the actual ordinary source pole MSU reports,with C=C_width,
ML=i Nvec_dc Td/2+i[Tc,C]/2 and
MR=-i Nvec_dc Td.T/2+i[Tc,C].T/2.
These are comparators only;the calculation reads the MEASURED MVS tables.
The nonadjoint sourcep cancels the kinetic commutator. Its sourceq and
the complete measured vertex leave a pure adjoint one-jet image. Whether
that equals the negative bosonic source-pole Euler map P is tested,not
assigned. The lower auxiliary source pole and Yukawa carriers are retained
separately,using their qualified proper-topology support exclusions.

If each image agrees,the coefficient of chi4 in the properly transported
coupled one-jet identity is0 for arbitrary chi4. BMC's former chi4=0
implication applied only to unchanged matter coefficients. The fixed
finite R from BSF is independent of this common-log transport and remains
a separate required coupled-conversion contribution. This result supplies
no negative R quantum input or new finite counterterm by fiat.
