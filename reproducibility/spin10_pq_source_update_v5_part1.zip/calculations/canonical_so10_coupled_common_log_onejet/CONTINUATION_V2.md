# CLO1 V2: restore the documented auxiliary width factor

The original P/R computations completed and agreed, but their scientific gate
failed with a nonzero g2 remainder:592 positions per chirality. That failure,
all eight original sources/copies, outputs, controller and diagnostic are
preserved. Original prospective common_chi_remains_free metadata was NOT
qualified by the failed gate.

The diagnostic compares the actual MAS table to MSU and isolates the mismatch
to the auxiliary source alone. MAS RESULT.md and DERIVATION.md explicitly
factor xi outside loop_left/right. More decisively, the already committed
MSU verify.py multiplies both MAS loop tensors by xi before comparing them to
its auxiliary image. The new CLO assembly omitted this factor in BOTH routes.
This is a coefficient-prefactor import error, not evidence of a quantum
obstruction and not a license to alter any measured coefficient or sign.

Before this correction executes, freeze these historical convention sources,
the complete failed outputs/captures and diagnostic, new source copies and
the same scientific requirements. P2/R2 restore exactly xi*MAS in both source
chiralities, retaining the original generic Euler derivations, couplings,
bosonic images and all other inputs. No quantum coefficient, source operation,
Grassmann sign or physical parameter changes. The xi factor is read from the
preexisting amplitude contract, not solved from the desired cancellation.

V2 gate must retain all original zero-complement, independent-route, reality,
12H, p/q, coupling and fixed-remainder tests. Additionally compare every
corrected source tensor to MSU, reproduce every failed original coefficient
by deliberately omitting xi, and prove all other original outputs unchanged.
This is a sensitive import-normalization control, not a weakened gate.

Sequential bounded P2/R2/gate:600s after imports each,8GiB sampled private,
350MiB available commit floor,16MiB packet. Reuse the current-goal-turn E4
honestly; authenticate all bytes anew. First failure stops; no overwrite,
resource expansion, truncation or automatic acceptance. Original scientific
gate remains FAILED even if corrected work subsequently qualifies.

Ceiling remains selected common-log normalization transport only. The fixed
finite R and other Born-word constants, complete coupled conversion and full
quantum prescription remain unresolved. chi4 stays symbolic; no b0/kappa
identification or adopted physical normalization. State113/34of39, historical
custody2/seven NOTPASS, all protected failures/pauses/blocks unchanged.
Shared action/data/software/AI authorship are not independent scientists.
