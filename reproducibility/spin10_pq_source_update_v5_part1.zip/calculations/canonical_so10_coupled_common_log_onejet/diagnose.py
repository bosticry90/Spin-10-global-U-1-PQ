"""CLO1 exact complete failed-image adjudication,not a cancellation repair."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'diagnostic_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['parts']==R['parts'] and P['common_log_remainder']==R['common_log_remainder']
counts={};source_adjoint={};matter_adjoint={};Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));gram=Mat(45,45)
for a in range(45):
 for b in range(45):
  v=trace(mul(T[a],T[b]))
  if v:gram.d[a,b]=v
zero(minus(gram,scale(ident(45),Q(2))))
for tag,d in P['common_log_remainder'].items():
 counts[tag]={}
 for side,jets in d.items():counts[tag][side]={j:sum(len(dec(m).d) for m in arr) for j,arr in jets.items()}
 # Exact full End16 projection;retain any nonadjoint remainder explicitly.
 mats=list(map(dec,d['left']['q']));co=Mat(45,45);bad=[]
 for c,m in enumerate(mats):
  reconstructed=Mat(16,16)
  for a,t in enumerate(T):
   z=prod(Q('1/2'),trace(mul(t,m)))
   if z:co.d[a,c]=z;reconstructed=plus(reconstructed,scale(t,z))
  bad.append(enc(minus(m,reconstructed)))
 matter_adjoint[tag]={'coefficient':enc(co),'nonadjoint_remainder':bad}
MG=packed(CAL/'canonical_so10_matter_gauge_vertex_normalization/primary_tables.json.gz');MS=packed(CAL/'canonical_so10_matter_source_uv_assembly/primary_tables.json.gz');BS=packed(CAL/'canonical_so10_bosonic_source_onejet_finite/primary_v2_tables.json.gz')
db=dec(MG['plane_DB']);ng=dec(MS['ghost_matrices']['ordinary_ghost']['plane']);derived=scale(plus(db,ng),Q('-1/2'));bp=dec(BS['rho']['ordinary']['chi']);difference=minus(bp,derived)
MV=packed(CAL/'canonical_so10_matter_vector_source_pole/primary_tables.json.gz');MA=packed(CAL/'canonical_so10_matter_auxiliary_source_pole/primary_tables.json.gz');mvsdiff={}
for side in ['left','right']:
 for tag,actual,qualified in [('g3',MV['loop_'+side],MS['ordinary_complete_'+side]),('g2',MA['loop_'+side],MS['auxiliary_'+side])]:
  residual=[minus(dec(a),dec(b)) for a,b in zip(actual,qualified)];mvsdiff[tag+side]=sum(len(m.d) for m in residual)
width=matrix_width_coefficient(difference,0,1);constant=matrix_width_coefficient(difference,0,0);eta=matrix_width_coefficient(difference,1,0)
finish('diagnostic',{'method':'complete_failed_pq_image_and_old_fixed_map_comparison','original_scientific_gate':'FAILED_NONZERO_REMAINDER','original_gate_changed':False,'counts':counts,'complete_remainder':P['common_log_remainder'],'matter_remainder_adjoint':matter_adjoint,'old_DB':enc(db),'old_Nghost':enc(ng),'old_source_firstjet_from_fixed_maps':enc(derived),'measured_bosonic_P':enc(bp),'bosonic_P_minus_old_fixed_firstjet':enc(difference),'difference_width_coefficients':{'eta':enc(eta),'xi':enc(width),'constant':enc(constant)},'proper_source_loops_minus_MSU_fixed_projection_counts':mvsdiff,'source_KP_pq_Euler_rule_changed':False,'quantum_coefficients_fitted_or_changed':False,'common_log_completion_qualified':False,'physical_scheme_adopted':False},start)
