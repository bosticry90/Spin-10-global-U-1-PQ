# Prelaunch manifest-name correction

The original preparer referenced IBS1's nonexistent validation_preparation.json.
That historical inventory uses validation_preparation_v2.json. Preparation
stopped before input extraction, source freezing or any scientific worker.
The exact original preparer/controller, complete capture and controller
failure remain. No V1 preparation/validation receipt is manufactured.

V2 names the ACTUAL recorded manifest, authenticates only its relevant data
bindings and leaves historical policy hashes unchanged. It freezes original
and corrected orchestration sources plus the failure before launching the
UNCHANGED scientific native/verifier sources. All physical inputs, source
requirements, acceptance comparisons and120second/8GiB/350MiB/8MiB limits
remain. This is a preparer path correction, not a new scientific result.
