from pathlib import Path
import ast
O=Path(__file__).resolve().parent
p=(O/'prepare.py').read_text(encoding='utf-8');p=p.replace("'canonical_so10_matter_breaking_support':['DERIVATION.md','RESULT.md','validation_receipt.json','validation_preparation.json']","'canonical_so10_matter_breaking_support':['DERIVATION.md','RESULT.md','validation_receipt.json','validation_preparation_v2.json']")
p=p.replace("(I,ip,'validation_preparation.json')","(I,ip,'validation_preparation_v2.json')")
p=p.replace("'verify.py','prepare.py','run.py']","'verify.py','prepare.py','run.py','prepare_v2.py','run_v2.py','CORRECTION_V2.md','generate_prepare_v2.py']")
p=p.replace("files.extend(O.glob('*.source.txt'));","files.extend([O/'preparation_capture.json',O/'controller_failure.json']);files.extend(O.glob('*.source.txt'));")
r=(O/'run.py').read_text(encoding='utf-8');r=r.replace("C.mkdir(parents=True,exist_ok=False)","assert C.exists()")
r=r.replace("with(C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))","assert (C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)")
r=r.replace("O/'prepare.py'","O/'prepare_v2.py'").replace("'preparation_capture.json'","'preparation_v2_capture.json'").replace("'preparation_full_capture.json'","'preparation_v2_full_capture.json'").replace("O/'controller_failure.json'","O/'controller_failure_v2.json'")
for name,code in [('prepare_v2.py',p),('run_v2.py',r)]:
 ast.parse(code)
 with(O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(code)
print('GENERATED_CORRECT_ARCHIVED_IBS_MANIFEST_CONTINUATION')
