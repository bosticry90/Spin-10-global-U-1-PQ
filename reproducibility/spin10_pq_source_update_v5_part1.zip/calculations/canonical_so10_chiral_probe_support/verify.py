from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import combinations
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CPS_VERIFIER_WRITE')
os.sys.addaudithook(guard)
role='verifier'
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
for k in ['names','parities','source_support','marginal_H','bosonic_endpoint_colors','cross','kernel','cross_block_control','KP_carrier_words','KP_carrier_counts','gaussian_source_term','ghost_source_bad_variation']:assert P[k]==Z[k],k
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
inp=json.loads(gzip.decompress((O/'primary_inputs.json.gz').read_bytes()));geo=inp['geometry'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  for key,value in pp.items():put(out,key,value)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])


u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];bg=[index['mw_a'+str(i)] for i in range(45)];bl=[index['mw_L'+str(i)] for i in range(45)];qs=[index['mw_q'+str(i)] for i in range(4)];cs=[index[n] for n in ['mw_chi','mw_l32','mw_l2']]
bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b};dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)};bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))}

for key in ['physical_G','physical_QG']:
 for pkt in inp[key]:
  p=unpack(pkt);ss={n for gp,xp,hp,m,w in p for n,j in w if n in sources};assert ss<=set(ja+jl)
  assert {n for n in fields if Jof[n] in ss}<=set(an+ln)
assert {v['origin'] for v in inp['hat_vertices']}=={'E_C','E_P','E_S'}
assert all(sorted(k for k,j in v['ports'])==['P','S','c'] for v in inp['hat_vertices'])
assert sorted(k for k,j in inp['K_vertex']['ports'])==['K','P','c']
assert inp['SMA']['physical_antifield_copies']==1 and inp['SMA']['auxiliary_BRST_transform']=='0'
def wick(p):
 phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
 for(gp,xp,hp,m,w),v in p.items():
  z={(gp,xp,hp,m,w):-v}
  for n,j in w:z=mul(z,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
  out=add(out,z)
 return out
def marginal(p,rr):return {k:v for k,v in p.items() if all(n in set(qs+[rr]) and not j for n,j in k[-1]) and sum(n==rr for n,j in k[-1])==1}
H=[];scalar_subleading=[]
for rr,pkt in zip(rho,inp['physical_G']):
 p=wick(unpack(pkt));mat={};nscalar=0
 for gp,xp,hp,m,w in p:
  if len(w)==2 and all(n in fields for n,j in w) and any(names[n].startswith('x_') for n,j in w):
   assert 3-sum(dims[n]+len(j) for n,j in w)>0;nscalar+=1
 scalar_subleading.append(nscalar)
 for(n,I),p0 in gradient(mul(elem(rr),p)).items():
  if n not in fields:continue
  for(m,J),c in gradient(p0).items():
   if m not in fields or len(I)+len(J)!=3-dims[n]-dims[m]:continue
   c=marginal(c,rr)
   if not c:continue
   fac=scalar((-1)**(par[m]*(par[n]+1)))
   for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
   for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
   mat[n,m]=add(mat.get((n,m),{}),mul(c,fac))
 mat={k:p for k,p in mat.items() if p};H.append(mat)
fm=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
assert H==[fm(p) for p in P['marginal_H']]
vec=[F(0),F(0),F(1),F(0)];HH=[{ij:q for ij,p in mat.items() if(q:=subst(p,{n:scalar(v) for n,v in zip(qs,vec)}))} for mat in H];aset=set(an);bs={n for b in bn for n in b};bose=bs|set(ln)
blocks={'BB':{},'BL':{},'LB':{},'LL':{}}
for i in range(45):
 for mu in range(4):blocks['BB'][bn[i][mu],bn[i][mu]]=scalar('eta_H' if i<12 else 'xi') if mu==2 else scalar('1')
 blocks['BL'][bn[i][2],ln[i]]=scalar('-1');blocks['LB'][ln[i],bn[i][2]]=scalar('1')
left=[{k:p for k,p in mat.items() if k[0] in aset} for mat in HH];right=[{k:p for k,p in mat.items() if k[1] in aset} for mat in HH]
def contract(L,G,R):
 out={}
 for(i,a),p in L.items():
  for(b,j),q in R.items():
   if (a,b) in G:
    z=mul(p,G[a,b],q)
    if z:out[i,j]=add(out.get((i,j),{}),z)
 return {k:p for k,p in out.items() if p}
cross={}
for kind,G in blocks.items():
 for r,rr in [(0,1),(1,0)]:cross[kind+str(r)+str(rr)]=contract(left[r],G,right[rr])
assert cross=={k:fm(p) for k,p in P['cross'].items()}
assert all((i in aset and j in bose) or(i in bose and j in aset) for mat in HH for i,j in mat)
assert P['bosonic_endpoint_colors'][0]==list(range(12)) and P['bosonic_endpoint_colors'][1]==list(range(12,45))
bb0=next(j for i,j in left[0] if j in bs);bb1=next(j for i,j in left[1] if j in bs);bad={(bb0,bb1):scalar('1'),(bb1,bb0):scalar('1')};ctrl={}
for r,rr in [(0,1),(1,0)]:
 for ij,p in contract(left[r],bad,right[rr]).items():ctrl[ij]=add(ctrl.get(ij,{}),p)
ctrl={ij:p for ij,p in ctrl.items() if p};assert ctrl==fm(P['cross_block_control']) and ctrl
assert not any(subst(p,{rho[1]:elem(rho[0])}) for p in ctrl.values())
# Every target port is accounted for in the unicyclic internal-degree proof.
for e in inp['hat_vertices']:
 remaining=[(k,j) for k,j in e['ports'] if k!='P'];assert sorted(k for k,j in remaining)==['S','c']
assert sum(1 for k,j in inp['K_vertex']['ports'] if k!='K')==2
words=sorted((a,b,c,d) for a in range(3) for b in range(3-a) for c,d in combinations(range(47),2) if a+b+(c>=45)+(d>=45)<=2)
assert [list(t) for t in words]==P['KP_carrier_words'];counts=Counter(a+b+(c>=45)+(d>=45) for a,b,c,d in words);assert dict(counts)=={0:990,1:2070,2:3151}
one_rho=sum(a+b+(c>=45)+(d>=45)==2 for a in range(3) for b in range(3-a) for c,d in combinations(range(46),2) if a+b+(c>=45)+(d>=45)<=2);assert 3151-one_rho==91
eta0,pp,f0,f1,ks,jc0=[index[n] for n in ['cp_eta','cp_p','cp_f0','cp_f1','cp_K','cp_Jc']];x=mul(elem(ks),elem(eta0));y=elem(pp);inv=add(scalar('1'),scaled(elem(u[0]),-1),mul(elem(u[0]),elem(u[0])))
J=add(mul(x,elem(f0)),mul(y,elem(f1)));assert mul(J,J)==scaled(mul(x,y,elem(f0),elem(f1)),-2)
integrand=mul(add(scalar('1'),scaled(mul(elem(f0),elem(f1)),-2)),add(scalar('1'),scaled(mul(J,J,inv),F(1,2))))
ferm=gradient(gradient(integrand).get((f0,()),{})).get((f1,()),{});source=scaled(add(scaled(ferm,F(-1,2)),scalar('-1')),-1);assert source==unpack(P['gaussian_source_term'])==scaled(mul(x,y,inv),F(-1,2))
u2={k:v for k,v in source.items() if sum(n==u[0] for n,j in k[-1])==2};assert u2 and not subst(source,{ks:{},pp:{}})
ih=add(mul(elem(eta0,(4,)),elem(f0),elem(pp)),mul(elem(eta0),elem(f0),elem(pp,(4,))));assert operation({eta0:elem(eta0)},odd=False)(ih)==ih==unpack(P['ghost_source_bad_variation']);assert EL(ih,{eta0})[eta0]
kernel={}
for mat in cross.values():
 for ij,p in mat.items():kernel[ij]=add(kernel.get(ij,{}),p)
kernel={ij:p for ij,p in kernel.items() if p};assert kernel==fm(P['kernel']);zero=not kernel
print('RESULT '+json.dumps({'schema':'CHIRAL_PROBE_SUPPORT_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'classical_augmented_defect':'UNCHANGED_NONZERO_IHAT','full_Q_not_asserted_nilpotent':True,'both_full_generators_and_QG_matter_BV_brackets_zero':True,'KP_carrier_counts':dict(counts),'early_rho_identification_loses_degree2_words':91,'complete_pure_rho2_KP_marginal_color_zero':zero,'spinor_positions_excluded_by_support':512 if zero else 0,'positive_dimension_scalar_quadratics_retained_then_excluded':scalar_subleading,'all_formal_current_Hessians_fresh_expanded_arithmetic':True,'all8_bosonic_orientations_checked':True,'offblock_control_nonzero':bool(ctrl),'early_rho_identification_control_sensitive':True,'source_differentiation_before_zero_superGaussian_control_nonzero':True,'nonzero_hatted_kernel_normalization_newly_computed':False,'mixed_u_rho_uu_finite_source_coefficients_measured':False,'full_chiral_QAP_measure_phase_physical_restoration':False,'authority_changed':False,'shared_SMA_action_reference_domain_software_AI_author':True},sort_keys=True),flush=True);watch.cancel()
