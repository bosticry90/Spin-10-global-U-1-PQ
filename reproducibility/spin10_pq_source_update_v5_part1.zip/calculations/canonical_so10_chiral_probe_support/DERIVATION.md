# The hatted defect stays, and source differentiation must precede restriction

The actual SMA insertion has fields C,P,S and hatted derivatives only. Its
raw three terms and compact two terms are related by SMA's retained boundary
current. Neither has BV sources, antighosts or auxiliary Lambda. The matter
action has only P/S kinetic, BPP and xPP vertices, and the single source K_P
couples to C P. It has no a/Lambda or Ja/JL dependence.

Actual G_r and QG_r have BV sources only Ja/JL and no P/S or matter source.
Shared ordinary C, B and x do NOT alone produce a BV bracket: their conjugate
sources are absent. Thus both (S_matter+S_src,matter,G_r) and the analogous
QG bracket vanish. Q_full G_r=Q_bos G_r exactly. Likewise (Ihat,G_r)=0 and
(Ihat,QG_r)=0. SPM's quadratic probe brackets remain the same. Consequently

 (S_full,ext,S_full,ext)/2+d S_full,ext = Ihat

through degree2, with the actual hatted defect UNCHANGED. This is not a claim
Q_full^2=0: generally Q_full^2=(Ihat,.). Its restriction to these generators
is flat because the actual bracket vanishes. A ghost-source rescaling
control has a nonzero Ihat bracket and distinguishes the support argument
from simply observing shared fields or setting hats0.

At a finite common proof cutoff the full source-Hessian chain still reads

 b_ext H_ext = Ihat''-Msharp H_ext-H_ext M,
 b_ext Gamma1,t = onehalf STr(Gt Ihat'')-STr M+STr(Gt Rt M)

in literal Euclidean normalization. Keep the four source-Hessian product
legs, ordered Rt placement and regulator/reference dependencies. A chiral
finite conversion is not automatically the purely metric bosonic T_kappa.
No unrestricted finite chiral or measure theorem is claimed here.

## Complete local physical-fermion source carrier

K_P P has dimension3, ghostnumber-1. A dimension5/ghost1 breaking must
multiply it by two dimension1, ghost1 odd objects, chosen from45 ordinary
C and the two independent rho. The u labels are even dimension0/ghost0.
No ordinary derivative, positive-dimension coefficient or additional field
fits. Through total probe degree2, the whole K_P-P carrier has6211
ghost/probe words. At EXACT degree2 it is

 u0^2,u0u1,u1^2 times C_c C_d (c<d): 3*990;
 u_r rho_s C_c: 4*45;
 rho0 rho1: 1;
 total3151.

These are field patterns before invariant/reality constraints, not3151
independent counterterms. This is one physical K-P source sector, not the
whole fermionic breaking module; current/derivative PP sectors and auxiliary
S external insertions are separate. Identifying the two rho labels early
loses91 degree2 words and is not allowed.

## Pure rho0*rho1 K_P P: complete leading one-loop envelope

Every bridgeless connected unicyclic1PI graph has internal degree2 at each
vertex. The source vertex has external K and internal C,P. Both rho labels
must come from two distinct linear rho*G vertices; no rho^2 classical
vertex exists and no u insertion fits this probe coefficient. No external
ordinary ghost remains. The hatted insertion therefore supplies the one
external physical P and internal C,S. Insertion derivatives on an external
hatted leg vanish only after that leg is declared physical.

Any G cubic has three internal legs at this target, so cannot be in such a
cycle. An additional physical PPB vertex would leave no allowed external
leg at the insertion, making it internally cubic and again impossible.
Unmarked kinetic pieces are already in the fixed reference; constant
mass/scalar insertions have positive dimension and lower the local UV
degree. Hence every marginal candidate is exactly the four-vertex cycle
E + KCP + H_(rho0 G0) + H_(rho1 G1), with two C-a edges, one PS/SP mixed
edge and one bosonic BB/BL/LB edge. LL is zero in the fixed reference.
The mixed hatted fermion numerator is retained; no odd-hat shortcut removes it.

Take the complete actual zero-background principal Hessians. Check the full
formal Lorentz shape before choosing an exact unit q. Compute both ordered
H0_(a,b) G_(b,b') H1_(b',a) orientations for every bosonic block. A zero
of these actual color matrices excludes the corresponding full spinor
coefficient BEFORE radial integration; it is not a guessed amplitude.
An artificial off-block bosonic connection supplies a sensitive control.
If any matrix survives, the nonzero hatted sewing must instead be calculated.

The replay differentiates full G before restriction. Source support of the
full G/QG is checked separately first. Scalar a*x terms are retained in
that scan, then excluded from this saturated local coefficient by their
positive coefficient dimension. They are not set0 in massive amplitudes.

## Why the fermion-zero control is insufficient

At P=S=K=0, the classical Hessian has no boson/fermion mixed blocks. The
fermion block and Ihat'' fermion block have no u/rho dependence; the probes
have no matter/source coordinates. Their degree2 trace is consequently0
on that locus, BEFORE taking a trace limit. This does not prove a source
derivative0: off-diagonal Hessian entries can survive differentiation.

A finite alternating super-Gaussian control uses one even b and two odd f:

 S=(1+u)b^2/2+b*x*f0+b*y*f1+2*f0*f1,
 x=K*eta, y=p, with K even and eta,p odd.

Eliminating b yields F01=2+x*y/(1+u). Direct Berezin expansion gives the
same result. The source-dependent one-loop term is -x*y/[2(1+u)]; its u^2
coefficient is -x*y/2, nonzero. Its fermion/source-zero block is probe
independent. This is a statistics-sensitive algebra control, not a Spin10
loop or a finite-dimensional BMHV representation.

No conclusion here establishes mixed u*rho/u*u source coefficients, finite
chiral restoration, global Pfaffian phase, full QAP/E5/A5, flavor or physical
massive matching. Kappa/b0/IR freedoms and historical exclusions stay.
