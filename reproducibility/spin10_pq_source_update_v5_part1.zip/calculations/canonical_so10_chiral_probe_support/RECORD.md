# CPS1: actual hatted defect and the first complete chiral probe/source class

Base/main0690890eeed067d47d3e1608c00d5024b0339f61. Previous goal turn
PROGRESS; full investigation active/incomplete. Current AGENTS, State113/
34of39 and custodyexit2/sevenNOTPASS unchanged. No agents/branch/worktree,
push/publication/outreach, scheme/benchmark/foundation/state/promotion,
flavor fitting or HB1/C5 activation.

Question: how does the actual SMA hatted kinetic defect couple to the SAME
Mlight/Mheavy probe family? First derive whether the augmented classical
defect changes. Then account for the complete local K_P-P source carrier
at probe degree2, and evaluate/exclude the pure rho0*rho1 K_P P class.
Do not infer the source derivative from a fermion/source-zero block alone.
This is a necessary class, not the full fermionic/QAP/measure theorem.

Reuse SMA's explicit P/S hatted action, single physical source and graded
conventions; the IBS/QSI/CMS actual one-loop insertion types; TPW/SPM's
classical generators; and the existing mass-independent off-shell UV-first
domain. All numerical Yukawa/flavor/mass points remain unspecified.
Use full actual G/QG BV-source supports before restricting fields/sources.
The hatted action is NOT replaced by its zero D4 specialization.

For the first quantum class retain two independently labelled rho vertices,
the actual full mixed PP/PS regulator structure and both source chiralities.
Derive the one-loop1PI cycle envelope. Compute every BB/BL/LB current
connection from actual principal kernels; exclude positive-dimension scalar
terms by the saturated dimension5 target. A color support zero may exclude
the whole spinor coefficient but does not normalize a nonzero hatted kernel.
If a color kernel survives, preserve it as requiring full insertion sewing.
No scientific acceptance condition demands a desired zero.

Primary reuses qualified full Fourier Hessian symbols. Replay freshly
differentiates the complete actual G density before restriction. Separate
expanded-Fraction verification rederives the symbols and component products.
An explicit mixed super-Gaussian source control demonstrates why setting
fermions/sources0 before differentiation is invalid. A cross-block
propagator and identified-rho control must detect the actual support/label
requirement. No algebra fixture is a physical parameter choice.

Freeze sources/input hashes/types/degree envelope before running: sequential
natives/verifier120s after imports each,8GiB sampled private,350MiB launch
floor, whole packet8MiB. Preserve failed/unfinished runs and full captures;
no cap expansion, truncation or weakening. Methods share action, symbolic
infrastructure, analytical premises and AI author; no independent scientist,
experiment or proof assistant certifies them.

After validation, select the next indispensable nonzero/missing family,
especially mixed u*rho and u*u source terms. Neither a bosonic theorem,
a pure-rho zero nor a classical unchanged defect closes the full chiral
construction. Validate existing E4 before local commit; preserve all older
physical failures, authority and evidence.
