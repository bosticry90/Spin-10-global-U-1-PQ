# The probe extension preserves the actual hatted defect; its pure-rho source class is excluded

Both native routes and separate verification completed. The result concerns
the provisional SMA continuation in its declared mass-independent Euclidean,
nonexceptional/test-field UV domain. It is not a complete chiral quantum
construction or a new physical scheme.

## The classical defect is unchanged, rather than removed

The full actual G and QG have BV sources only Ja/JL and no matter variables
or matter sources. SMA's matter action/source vertices have no a/Lambda or
Ja/JL arguments. Its hatted breaking contains C,P,S and hatted derivatives,
with no BV sources. Canonical conjugate-port checks therefore give

 (S_matter+S_src,matter,G_r)=(S_matter+S_src,matter,QG_r)=0,
 (Ihat,G_r)=(Ihat,QG_r)=0.

Shared ordinary fields such as C do not create a bracket when their conjugate
source is absent. Thus the same actual augmented action has

 (S_full,ext,S_full,ext)/2+d S_full,ext=Ihat

through probe degree2. The hatted insertion remains nonzero and unchanged.
The full differential is generally curved, Q_full^2=(Ihat,.); nilpotence
is not imported from the bosonic construction. A ghost-source rescaling
control has a nonzero hatted bracket and detects the relevant source support.
The SMA Clifford/source theorem is authenticated and reused, not freshly
reproved by this port calculation.

## A complete first fermionic source class is excluded by actual color support

At exact probe degree2, the whole local physical K_P-P source carrier is

| Pattern | Ghost/probe words |
| --- | ---: |
| u_r u_s C_c C_d |2970 |
| u_r rho_s C_c |180 |
| rho0 rho1 |1 |
| Total |3151 |

Through degree2 the count is6211. These are patterns before invariant/reality
restrictions, not independent counterterms. Current/derivative matter
bilinears, auxiliary-S external products and the other chiral sectors remain.

For the pure rho0*rho1 K_P P coefficient, the complete marginal1PI envelope
is the four-vertex cycle E+KCP+G0+G1. The two ghosts and one mixed PS/SP
fermion edge remain; the hatted numerator is not set0. Degree and internal-
valence bounds exclude additional cubic vertices, and positive-dimension
scalar insertions are UV-subleading at this saturated dimension5 target.

The two actual leading G kernels connect respectively to the12 unbroken
and33 broken boson/auxiliary directions. Every ordered BB/BL/LB connection
between them vanishes; LL is zero in the unperturbed reference. All eight
block/orientation products were checked. The resulting marginal color
kernel is identically zero before hatted integration or spinor sewing.
It excludes all512 left/right internal-spinor matrix positions in this
declared source class, including their zero complement. A new normalized
nonzero hatted loop coefficient has NOT been calculated.

Primary reuses qualified full Fourier Hessians; replay differentiates the
complete actual G before restriction. The expanded-Fraction verifier
freshly reconstructs those symbols and component contractions at a third
momentum orientation. All296 scalar-bearing quadratic G terms in the heavy
generator are retained in the source audit, then excluded from this
principal local class by their positive coefficient dimension.

An artificial cross-block covariance makes the candidate color kernel
nonzero. Identifying the rho labels early removes that control and loses91
degree2 carrier words. These are sensitive diagnostic errors, not new
physical propagators or allowed parameter choices.

## A source-zero block does not prove a source identity

At zero fermion means AND fermionic sources the fermion Hessian block and
its regulator are probe independent; this supplies a legitimate restricted
zero before the limit. The actual source derivative was assessed separately.
A finite alternating super-Gaussian has a nonzero u^2*K*eta*p coefficient
even though its source-zero fermion block is independent of u. Independent
boson-Wick/Berezin expansion and the odd-block Schur determinant agree.
This confirms why setting sources0 too early would miss permissible terms.
It is a statistics-sensitive fixture, not a Spin10 coefficient or a finite
BMHV gamma representation.

## Evidence, failure and continuation

Native times1.947/2.293 seconds; verification31.301 seconds after imports.
Maximum sampled private allocation303,878,144 bytes, not a true peak. The
120second/8GiB/350MiB/8MiB limits held. No scientific worker or verifier failed.

One original PREPARER failed before launching any scientific worker because
it named a nonexistent historical manifest. The actual IBS manifest is
validation_preparation_v2.json. Original source/controller/capture remain;
V2 names the correct manifest, binds historical data without rebinding its
policy and freezes both orchestration versions. No scientific condition or
resource bound changed.

Validation receipt SHA256:
1dceffebe506b53382a124821d66c351083f8ad1f81c7c8099e6938c01a36b4e.

The mixed-u source classes are NOT measured. The justified follow-on PAR1
derives their actual probe-dependent boson/auxiliary inverse, including any
new LL contact. The pure-rho support zero must not be extrapolated to them.

Shared action, reference/frame, analytic premises, symbolic infrastructure
and AI author limit independence. There is no external physical validation.
Full chiral finite Slavnov/QAP, measure/phase, physical limits and massive
fermion matching remain open. Authority stays34/39, E5/A5 unqualified,
custodyexit2/seven unresolved NOTPASS, and all prior exclusions/blocks intact.
