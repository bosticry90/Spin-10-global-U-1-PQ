"""Actual augmented action: mixed and companion local quantum coefficients."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from collections import defaultdict
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json')
 for p,h in prep['native_input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
   assert Path(os.fsdecode(args[0])).resolve()==O/(role+'_tables.json.gz')
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 extra=['mw_u0','mw_u1','mw_rho0','mw_rho1']+['mw_a'+str(i) for i in range(45)]+['mw_L'+str(i) for i in range(45)]+['mw_q'+str(i) for i in range(4)]+['mw_chi','mw_l32','mw_l2']
 A=Algebra(geo['names']+extra+['cp_eta','cp_p','cp_f0','cp_f1','cp_K','cp_Jc'],geo['parities']+[0,0,1,1]+[1]*45+[0]*52+[1,1,1,1,0,0])
 u=[A.index['mw_u'+str(i)] for i in range(2)];rho=[A.index['mw_rho'+str(i)] for i in range(2)]
 bg=[A.index['mw_a'+str(i)] for i in range(45)];bl=[A.index['mw_L'+str(i)] for i in range(45)];qs=[A.index['mw_q'+str(i)] for i in range(4)];cs=[A.index[n] for n in ['mw_chi','mw_l32','mw_l2']]
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b}
 dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 @lru_cache(None)
 def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
 def mul(*pp):
  p={(0,()):ONE}
  for q in pp:p=A.product(p,q)
  return p
 def rows(p):return A.rows(p)
 def pack(p):
  cc=[];ix={};mm=[]
  for(g,w),c in sorted(p.items()):
   if c not in ix:ix[c]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in c])
   mm.append([g,[[n,list(j)] for n,j in w],ix[c]])
  return {'coefficients':cc,'monomials':mm,'positions':len(p),'sha256':A.fingerprint(p)}
 def unpack(p,names=None):
  co=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in p['coefficients']];out={}
  for g,w,k in p['monomials']:
   ww,sg=A.canonical(tuple((A.index[names[n]] if names else n,tuple(j)) for n,j in w))
   if sg:put(out,(g,ww),scale_coefficient(co[k],sg))
  return out
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,mp):
  out={}
  for(g,w),c in p.items():
   z={(g,()):c}
   for n,j in w:z=mul(z,DD(mp.get(n,elem(n)),j))
   for k,v in z.items():put(out,k,v)
  return out
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(A.parities[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    sg=(-1)**(A.parities[n]*prefix) if role=='primary' else (-1)**(A.parities[n]*(total-prefix-A.parities[n])+A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));prefix+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def op(p,v,odd):
  out={}
  if role=='replay':
   for(n,j),df in grad(p).items():
    if n in v:
     for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  else:
   for(g,w),c in p.items():
    prefix=0
    for at,(n,j) in enumerate(w):
     if n in v:
      z=mul({(g,w[:at]):scale_coefficient(c,(-1)**prefix if odd else 1)},DD(v[n],j),{(0,w[at+1:]):ONE})
      for k,t in z.items():put(out,k,t)
     prefix+=A.parities[n]
  return out
 def wick(p):
  phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
  for(g,w),c in p.items():
   fac=scalar('-1')
   for n,j in w:
    fac=mul(fac,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
   for k,v in mul({(g,w):c},fac).items():put(out,k,v)
  return out

 inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));assert list(A.names[:-6])==inp['names']
 source_support=[]
 for typ in ['physical_G','physical_QG']:
  for r,pkt in enumerate(inp[typ]):
   pp=unpack(pkt);ss={n for g,w in pp for n,j in w if n in sources};assert ss<=set(ja+jl)
   used={n for g,w in pp for n,j in w};assert used<=fields|sources|{i for i,n in enumerate(A.names) if n.startswith('A') and n[1:].split('_')[0].isdigit()}
   conjugates={n for n in fields if Jof[n] in ss};assert conjugates<=set(an+ln)
   source_support.append({'type':typ,'generator':r,'density_positions':len(pp),'source_coordinate_count':len(ss),'conjugate_fields':sorted(A.names[n] for n in conjugates)})
 E=inp['hat_vertices'];assert {v['origin'] for v in E}=={'E_C','E_P','E_S'}
 assert all(sorted(k for k,j in v['ports'])==['P','S','c'] and sum(j=='h' for k,j in v['ports'])==1 for v in E)
 K=inp['K_vertex'];assert sorted(k for k,j in K['ports'])==['K','P','c'] and inp['SMA']['physical_antifield_copies']==1 and inp['SMA']['auxiliary_BRST_transform']=='0'
 # Ordinary fields C/B/x may be shared; only conjugate source ports count.
 assert not {'P','S','c'}&{'a','L'} and not {'P','S','c','B','x'}&{'a','L'}
 print('STAGE '+role+' full_actual_source_support_preserves_hatted_master_defect',flush=True)
 GE=[wick(unpack(p)) for p in inp['physical_G']]
 def marginal(p,rr):return {k:c for k,c in p.items() if all(n in set(qs+[rr]) and not j for n,j in k[1]) and sum(n==rr for n,j in k[1])==1}
 def fm(pkt,rr):return {(i,j):q for i,j,p in pkt if (q:=marginal(unpack(p),rr))}
 H=[]
 for rr,gp in zip(rho,GE):
  if role=='primary':H.append(fm(inp['H_symbols'][len(H)],rr));continue
  out={}
  for(n,I),df in grad(mul(elem(rr),gp)).items():
   if n not in fields:continue
   for(m,J),c in grad(df).items():
    if m not in fields or len(I)+len(J)!=3-dims[n]-dims[m]:continue
    c=marginal(c,rr)
    if not c:continue
    fac=scalar(str((-1)**(A.parities[m]*(A.parities[n]+1))))
    for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
    for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
    out[n,m]=add(out.get((n,m),{}),mul(c,fac))
  H.append({k:p for k,p in out.items() if p})
 bset={n for b in bn for n in b};aset=set(an);lset=set(ln);bose=bset|lset
 for mat in H:
  assert all((i in aset and j in bose) or(i in bose and j in aset) for i,j in mat)
  for a in an:
   for b in bn:
    for side in [0,1]:
     pp=mat.get((a,b[0]) if side==0 else(b[0],a),{});f=sub(pp,{q:scalar(str(int(mu==0))) for mu,q in enumerate(qs)})
     for mu in range(4):assert mat.get((a,b[mu]) if side==0 else(b[mu],a),{})==mul(f,elem(qs[mu]))
 vec=[F(1),F(0),F(0),F(0)] if role=='primary' else [F(0),F(0),F(0),F(1)]
 ev=lambda p:sub(p,{q:scalar(str(z)) for q,z in zip(qs,vec)})
 HH=[{k:q for k,p in mat.items() if(q:=ev(p))} for mat in H]
 blocks={'BB':{},'BL':{},'LB':{},'LL':{}}
 for i in range(45):
  w=scalar('eta_H' if i<12 else 'xi')
  for mu in range(4):
   for nu in range(4):
    z=add(scalar(str(int(mu==nu))),scale(add(w,scalar('-1')),vec[mu]*vec[nu]))
    if z:blocks['BB'][bn[i][mu],bn[i][nu]]=z
   if vec[mu]:blocks['BL'][bn[i][mu],ln[i]]=scalar(str(-vec[mu]));blocks['LB'][ln[i],bn[i][mu]]=scalar(str(vec[mu]))
 def mm(L,B):
  rows=defaultdict(list);out={}
  for(k,j),p in B.items():rows[k].append((j,p))
  for(i,k),p in L.items():
   for j,q in rows[k]:
    z=mul(p,q)
    if z:out[i,j]=add(out.get((i,j),{}),z)
  return {k:p for k,p in out.items() if p}
 left=[{k:p for k,p in mat.items() if k[0] in aset} for mat in HH];right=[{k:p for k,p in mat.items() if k[1] in aset} for mat in HH]
 cross={}
 for kind,G in blocks.items():
  for r,rr in [(0,1),(1,0)]:cross[kind+str(r)+str(rr)]=mm(mm(left[r],G),right[rr])
 kernel={}
 for mat in cross.values():
  for k,p in mat.items():kernel[k]=add(kernel.get(k,{}),p)
 kernel={k:p for k,p in kernel.items() if p}
 # A wrong cross-block covariance is a diagnostic, not a new model input.
 bb0=next(j for i,j in left[0] if j in bset);bb1=next(j for i,j in left[1] if j in bset);badG={(bb0,bb1):scalar('1'),(bb1,bb0):scalar('1')};control={}
 for r,rr in [(0,1),(1,0)]:
  for k,p in mm(mm(left[r],badG),right[rr]).items():control[k]=add(control.get(k,{}),p)
 control={k:p for k,p in control.items() if p};assert control
 early={k:sub(p,{rho[1]:elem(rho[0])}) for k,p in control.items()};assert not any(early.values())
 bosoncolors=[]
 for mat in HH:
  used={i for pair in mat for i in pair if i in bose};bosoncolors.append(sorted({next(k for k,b in enumerate(bn) if i in b) if i in bset else ln.index(i) for i in used}))
 # Direct enumeration vs a count-stratified construction of the full carrier.
 if role=='primary':
  carrier=sorted((i,j,c,d) for i in range(3) for j in range(3-i) for c,d in __import__('itertools').combinations(range(47),2) if i+j+int(c>=45)+int(d>=45)<=2)
 else:
  carrier=[]
  for i in range(3):
   for j in range(3-i):
    if i+j<=2:carrier.extend((i,j,c,d) for c,d in __import__('itertools').combinations(range(45),2))
    if i+j<=1:carrier.extend((i,j,c,d) for c in range(45) for d in [45,46])
    if i+j==0:carrier.append((i,j,45,46))
  carrier.sort()
 counts=defaultdict(int)
 for i,j,c,d in carrier:counts[i+j+int(c>=45)+int(d>=45)]+=1
 assert len(carrier)==6211 and counts[2]==3151
 eta,pp,f0,f1,ks,jc0=[A.index[n] for n in ['cp_eta','cp_p','cp_f0','cp_f1','cp_K','cp_Jc']];xx=mul(elem(ks),elem(eta));yy=elem(pp);inv=add(scalar('1'),scale(elem(u[0]),-1),mul(elem(u[0]),elem(u[0])))
 if role=='primary':
  J=add(mul(xx,elem(f0)),mul(yy,elem(f1)));expo=add(scalar('1'),scale(mul(J,J,inv),F(1,2)));integrand=mul(add(scalar('1'),scale(mul(elem(f0),elem(f1)),-2)),expo);ferm=grad(grad(integrand).get((f0,()),{})).get((f1,()),{});znorm=scale(ferm,F(-1,2));gauss=scale(add(znorm,scalar('-1')),-1)
 else:
  h01=add(scalar('2'),mul(xx,yy,inv));h10=scale(h01,-1);det=scale(mul(h01,h10),-1);gauss=scale(add(scale(det,F(1,4)),scalar('-1')),F(-1,2))
 assert gauss==scale(mul(xx,yy,inv),F(-1,2))
 ih=add(mul(elem(eta,(4,)),elem(f0),elem(pp)),mul(elem(eta),elem(f0),elem(pp,(4,))));bad_variation=op(ih,{eta:elem(eta)},False);assert ih and bad_variation==ih
 def pm(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
 out={'schema':'CHIRAL_PROBE_SUPPORT_V1','role':role,'names':list(A.names),'parities':list(A.parities),'source_support':source_support,'classical_augmented_hatted_defect':'UNCHANGED_IHAT_NOT_ZERO_FULL_Q_NOT_NILPOTENT','Ihat_source_brackets_zero_by_actual_BV_ports':True,'marginal_H':[pm(M) for M in H],'bosonic_endpoint_colors':bosoncolors,'cross':{k:pm(M) for k,M in cross.items()},'kernel':pm(kernel),'rho2_KP_marginal_color_zero':not kernel,'spinor_positions_excluded_by_support_if_zero':512 if not kernel else 0,'cross_block_control':pm(control),'early_identified_rho_control_zero':not any(early.values()),'KP_carrier_words':carrier,'KP_carrier_counts':dict(counts),'gaussian_source_term':pack(gauss),'ghost_source_bad_variation':pack(bad_variation),'new_normalized_nonzero_hatted_kernel_calculated':False,'mixed_u_rho_and_uu_finite_source_coefficients_calculated':False,'full_chiral_QAP_measure_physical_restoration':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'rho2_KP_marginal_color_zero':not kernel,'KP_carrier_degree2':counts[2]},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
