from pathlib import Path
import ast
O=Path(__file__).resolve().parent;old=(O.parent/'canonical_so10_mixed_probe_auxiliary_ward/verify_v2.py').read_text(encoding='utf-8');helpers=old[old.index('def put('):old.index("u=[index['mw_u'")];types=old[old.index("u=[index['mw_u'"):old.index('def hess(')]
head='''from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import combinations
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CPS_VERIFIER_WRITE')
os.sys.addaudithook(guard)
role='verifier'
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
for k in ['names','parities','source_support','marginal_H','bosonic_endpoint_colors','cross','kernel','cross_block_control','KP_carrier_words','KP_carrier_counts','gaussian_source_term','ghost_source_bad_variation']:assert P[k]==Z[k],k
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
inp=json.loads(gzip.decompress((O/'primary_inputs.json.gz').read_bytes()));geo=inp['geometry'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
'''
tail=r'''
for key in ['physical_G','physical_QG']:
 for pkt in inp[key]:
  p=unpack(pkt);ss={n for gp,xp,hp,m,w in p for n,j in w if n in sources};assert ss<=set(ja+jl)
  assert {n for n in fields if Jof[n] in ss}<=set(an+ln)
assert {v['origin'] for v in inp['hat_vertices']}=={'E_C','E_P','E_S'}
assert all(sorted(k for k,j in v['ports'])==['P','S','c'] for v in inp['hat_vertices'])
assert sorted(k for k,j in inp['K_vertex']['ports'])==['K','P','c']
assert inp['SMA']['physical_antifield_copies']==1 and inp['SMA']['auxiliary_BRST_transform']=='0'
def wick(p):
 phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
 for(gp,xp,hp,m,w),v in p.items():
  z={(gp,xp,hp,m,w):-v}
  for n,j in w:z=mul(z,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
  out=add(out,z)
 return out
def marginal(p,rr):return {k:v for k,v in p.items() if all(n in set(qs+[rr]) and not j for n,j in k[-1]) and sum(n==rr for n,j in k[-1])==1}
H=[];scalar_subleading=[]
for rr,pkt in zip(rho,inp['physical_G']):
 p=wick(unpack(pkt));mat={};nscalar=0
 for gp,xp,hp,m,w in p:
  if len(w)==2 and all(n in fields for n,j in w) and any(names[n].startswith('x_') for n,j in w):
   assert 3-sum(dims[n]+len(j) for n,j in w)>0;nscalar+=1
 scalar_subleading.append(nscalar)
 for(n,I),p0 in gradient(mul(elem(rr),p)).items():
  if n not in fields:continue
  for(m,J),c in gradient(p0).items():
   if m not in fields or len(I)+len(J)!=3-dims[n]-dims[m]:continue
   c=marginal(c,rr)
   if not c:continue
   fac=scalar((-1)**(par[m]*(par[n]+1)))
   for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
   for mu in J:fac=mul(fac,scalar('I'),elem(qs[mu]))
   mat[n,m]=add(mat.get((n,m),{}),mul(c,fac))
 mat={k:p for k,p in mat.items() if p};H.append(mat)
fm=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
assert H==[fm(p) for p in P['marginal_H']]
vec=[F(0),F(0),F(1),F(0)];HH=[{ij:q for ij,p in mat.items() if(q:=subst(p,{n:scalar(v) for n,v in zip(qs,vec)}))} for mat in H];aset=set(an);bs={n for b in bn for n in b};bose=bs|set(ln)
blocks={'BB':{},'BL':{},'LB':{},'LL':{}}
for i in range(45):
 for mu in range(4):blocks['BB'][bn[i][mu],bn[i][mu]]=scalar('eta_H' if i<12 else 'xi') if mu==2 else scalar('1')
 blocks['BL'][bn[i][2],ln[i]]=scalar('-1');blocks['LB'][ln[i],bn[i][2]]=scalar('1')
left=[{k:p for k,p in mat.items() if k[0] in aset} for mat in HH];right=[{k:p for k,p in mat.items() if k[1] in aset} for mat in HH]
def contract(L,G,R):
 out={}
 for(i,a),p in L.items():
  for(b,j),q in R.items():
   if (a,b) in G:
    z=mul(p,G[a,b],q)
    if z:out[i,j]=add(out.get((i,j),{}),z)
 return {k:p for k,p in out.items() if p}
cross={}
for kind,G in blocks.items():
 for r,rr in [(0,1),(1,0)]:cross[kind+str(r)+str(rr)]=contract(left[r],G,right[rr])
assert cross=={k:fm(p) for k,p in P['cross'].items()}
assert all((i in aset and j in bose) or(i in bose and j in aset) for mat in HH for i,j in mat)
assert P['bosonic_endpoint_colors'][0]==list(range(12)) and P['bosonic_endpoint_colors'][1]==list(range(12,45))
bb0=next(j for i,j in left[0] if j in bs);bb1=next(j for i,j in left[1] if j in bs);bad={(bb0,bb1):scalar('1'),(bb1,bb0):scalar('1')};ctrl={}
for r,rr in [(0,1),(1,0)]:
 for ij,p in contract(left[r],bad,right[rr]).items():ctrl[ij]=add(ctrl.get(ij,{}),p)
ctrl={ij:p for ij,p in ctrl.items() if p};assert ctrl==fm(P['cross_block_control']) and ctrl
assert not any(subst(p,{rho[1]:elem(rho[0])}) for p in ctrl.values())
# Every target port is accounted for in the unicyclic internal-degree proof.
for e in inp['hat_vertices']:
 remaining=[(k,j) for k,j in e['ports'] if k!='P'];assert sorted(k for k,j in remaining)==['S','c']
assert sum(1 for k,j in inp['K_vertex']['ports'] if k!='K')==2
words=sorted((a,b,c,d) for a in range(3) for b in range(3-a) for c,d in combinations(range(47),2) if a+b+(c>=45)+(d>=45)<=2)
assert [list(t) for t in words]==P['KP_carrier_words'];counts=Counter(a+b+(c>=45)+(d>=45) for a,b,c,d in words);assert dict(counts)=={0:990,1:2070,2:3151}
one_rho=sum(a+b+(c>=45)+(d>=45)==2 for a in range(3) for b in range(3-a) for c,d in combinations(range(46),2) if a+b+(c>=45)+(d>=45)<=2);assert 3151-one_rho==91
eta0,pp,f0,f1,ks,jc0=[index[n] for n in ['cp_eta','cp_p','cp_f0','cp_f1','cp_K','cp_Jc']];x=mul(elem(ks),elem(eta0));y=elem(pp);inv=add(scalar('1'),scaled(elem(u[0]),-1),mul(elem(u[0]),elem(u[0])))
J=add(mul(x,elem(f0)),mul(y,elem(f1)));assert mul(J,J)==scaled(mul(x,y,elem(f0),elem(f1)),-2)
integrand=mul(add(scalar('1'),scaled(mul(elem(f0),elem(f1)),-2)),add(scalar('1'),scaled(mul(J,J,inv),F(1,2))))
ferm=gradient(gradient(integrand).get((f0,()),{})).get((f1,()),{});source=scaled(add(scaled(ferm,F(-1,2)),scalar('-1')),-1);assert source==unpack(P['gaussian_source_term'])==scaled(mul(x,y,inv),F(-1,2))
u2={k:v for k,v in source.items() if sum(n==u[0] for n,j in k[-1])==2};assert u2 and not subst(source,{ks:{},pp:{}})
ih=add(mul(elem(eta0,(4,)),elem(f0),elem(pp)),mul(elem(eta0),elem(f0),elem(pp,(4,))));assert operation({eta0:elem(eta0)},odd=False)(ih)==ih==unpack(P['ghost_source_bad_variation']);assert EL(ih,{eta0})[eta0]
kernel={}
for mat in cross.values():
 for ij,p in mat.items():kernel[ij]=add(kernel.get(ij,{}),p)
kernel={ij:p for ij,p in kernel.items() if p};assert kernel==fm(P['kernel']);zero=not kernel
print('RESULT '+json.dumps({'schema':'CHIRAL_PROBE_SUPPORT_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'classical_augmented_defect':'UNCHANGED_NONZERO_IHAT','full_Q_not_asserted_nilpotent':True,'both_full_generators_and_QG_matter_BV_brackets_zero':True,'KP_carrier_counts':dict(counts),'early_rho_identification_loses_degree2_words':91,'complete_pure_rho2_KP_marginal_color_zero':zero,'spinor_positions_excluded_by_support':512 if zero else 0,'positive_dimension_scalar_quadratics_retained_then_excluded':scalar_subleading,'all_formal_current_Hessians_fresh_expanded_arithmetic':True,'all8_bosonic_orientations_checked':True,'offblock_control_nonzero':bool(ctrl),'early_rho_identification_control_sensitive':True,'source_differentiation_before_zero_superGaussian_control_nonzero':True,'nonzero_hatted_kernel_normalization_newly_computed':False,'mixed_u_rho_uu_finite_source_coefficients_measured':False,'full_chiral_QAP_measure_phase_physical_restoration':False,'authority_changed':False,'shared_SMA_action_reference_domain_software_AI_author':True},sort_keys=True),flush=True);watch.cancel()
'''
code=head+helpers+types+tail;ast.parse(code)
with(O/'verify.py').open('x',encoding='utf-8',newline='\n') as f:f.write(code)
print('GENERATED_CPS1_EXPANDED_HESSIAN_AND_BEREZIN_VERIFIER')
