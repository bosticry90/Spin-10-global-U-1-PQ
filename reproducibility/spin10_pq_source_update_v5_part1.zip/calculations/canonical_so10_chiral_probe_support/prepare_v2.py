from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;M=O.parent/'canonical_so10_mixed_probe_auxiliary_ward';S=O.parent/'canonical_so10_sterile_matter_action';I=O.parent/'canonical_so10_matter_breaking_support'
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='0690890eeed067d47d3e1608c00d5024b0339f61'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
assert H(S/'validation_receipt.json')=='21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'
assert H(I/'validation_receipt.json')=='ed1596f57675dd7dfc94c10854c6bdd00184157bf875e4821a28b0bca046243f'
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V589.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
deps={'canonical_so10_sterile_matter_action':['ACTION_V1.md','RESULT.md','validation_receipt.json','primary.py','replay.py','validation_preparation.json'],'canonical_so10_matter_breaking_support':['DERIVATION.md','RESULT.md','validation_receipt.json','validation_preparation_v2.json'],'canonical_so10_quartic_ghost_source_insertion':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_complete_matter_source_breaking':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_cutoff_source_ward_operator':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_two_probe_lifted_ward':['PROOF.md','PROOF_REVIEW.md','RESULT.md','NEXT_CHIRAL_DEPENDENCY.md','validation_receipt_v2.json'],'canonical_so10_mixed_probe_auxiliary_ward':['DERIVATION.md','validation_receipt_v2.json','validation_preparation_v2.json'],'canonical_so10_joint_born_ir_trace_domain':['DERIVATION_V2.md','validation_receipt.json']}
for folder,nn in deps.items():files.extend(O.parent/folder/n for n in nn)
geo=load(R/'tools/portable_dh_v1/inputs.json.gz')['geometry'];sma=load(S/'primary_tables.json.gz');files.append(S/'primary_tables.json.gz')
for role in ['primary','replay']:
 mp=M/(role+'_tables.json.gz');ip=I/(role+'_tables.json.gz');sp=S/(role+'_tables.json.gz');files.extend([mp,ip,sp])
 # Authenticate data against its recorded receipt input bindings only.
 # Historical policy files in those manifests are NOT rebound to live bytes.
 for folder,p,manifest in [(M,mp,'validation_preparation_v2.json'),(I,ip,'validation_preparation_v2.json'),(S,sp,'validation_preparation.json')]:assert H(p)==read(folder/manifest)['input_sha256'][str(p.resolve())]
 m=load(mp);iv=load(ip);ss=load(sp);assert ss['physical_antifield_copies']==1
 e=[v for v in iv['vertices'].values() if v['origin'].startswith('E_')];k=[v for v in iv['vertices'].values() if v['origin']=='KCP'];assert len(e)==3 and len(k)==1
 z={n:m[n] for n in ['names','parities','physical_G','physical_QG','H_symbols']};z.update({'geometry':geo,'hat_vertices':e,'K_vertex':k[0],'SMA':{n:sma[n] for n in ['physical_antifield_copies','auxiliary_BRST_transform','kinetic_requires_IBP_transpose']},'common_SMA_definition_reused':True,'role_source_copy_count':ss['physical_antifield_copies'],'extraction':'NO_QUANTUM_TARGETS_CLASSICAL_ACTION_AND_SOURCE_PORTS_ONLY'})
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for n in ['RECORD.md','DERIVATION.md','build_native.py','native.py','build_verifier.py','verify.py','prepare.py','run.py','prepare_v2.py','run_v2.py','CORRECTION_V2.md','generate_prepare_v2.py']:
 p=O/n;files.append(p)
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend([O/'preparation_capture.json',O/'controller_failure.json']);files.extend(O.glob('*.source.txt'));b={str(p):H(p) for p in sorted(set(files))};nb={str(p):b[str(p)] for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'native.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz']}
dump(O/'preparation.json',{'base':base,'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':120,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':8*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_CPS1',len(b))
