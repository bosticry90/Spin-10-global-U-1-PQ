# BME1: actual bosonic-source to matter-Euler interface

Baseb04fefa00c48c9003925bc5ea04851e8fb461e3d/main31890 oldblobs.
WholegoalACTIVE/incomplete,state113/34of39 unchanged,liveAGENTS applies.
VMA1 completed the full selected vector cancellation;SMP1 covers the
selected scalar remainder. Neither includes the bosonic finite
counterterm's matter Euler companion. Determine its exact interface before
claiming a coupled restoration or calculating more loops.

Question:which first source derivatives of an existing bosonic local
finite counterterm can contribute to the source-free two-matter identity?
Use actual SMA1 charged/sterile action and source-left Euler convention,
the complete20-placement one-source evidence,and YCT1 actual all45
generators/B10/B126 maps. No bosonic finite coefficient is assigned0,
extracted from a UV pole,fitted or adopted physically. The complete
dimensional-Stokes primitive remains an operator formula,not a source
coefficient table. Its applicable chiral extension is not assumed.

Same provisional mass-independent Euclidean physical-external-hats0,
zero-background local ring. Fields have inherited project dimensions:
B,x,C dimension1,JB,Jx dimension2,q dimension1. Keep all45 ghost/vector
and328 scalar directions,all general complex symmetric family matrices,
both mass-map conjugates. A source-output null direction need not be an
ordinary scalar-input null direction for a general mixing coefficient.

Derive the exact additional source-free bSigma image of a bosonic-only
counterterm:rho_B E_B^matter+rho_x E_x^matter. Other bosonic Euler columns
vanish in this projection;source degree>=2 leaves a source after the one
gradient and vanishes ONLY after differentiation and source0. First source
jets are integrated by parts retaining the ordinary boundary current.
Mass-independent Lorentz/type counting should leave JB partialC,JB B C,
Jx C x carriers;externalA/positive-dimension translations remain separate.
These are carrier families with unrestricted admissible color tensors,
not three independent finite constants or computed coefficients.

Primary checks actual left-Weyl current Gram and paired scalar Gram.
Replay uses current coefficient duals and direct sparse scalar-column
duals to construct complete projectors and their zero complements.
Question whether the inherited isometric scalar coordinates give simple
orthogonal carrier projectors is an explicit test,not silently assumed.
If it fails,retain failure and construct the correct domain in a new
version. Compare full328x328 coefficient/zero complement and180 current
slots. Keep original Nambu polarization,do not multiply by extra families.

Controls omit conjugate mass map,drop all source derivatives before source0,
and remove an active current/scalar carrier. Report actual sensitivities;
these are algebraic controls,not quantum finite-amplitude tests. Expected
outcome:qualified source/matter interface and explicitly unresolved finite
source jets,or a preserved failure/incomplete result. No global completion.

Freeze eight sources/copies and actual inputbytes before sequential P/R/gate.
600s afterimports each,8GiB sampledprivatecap,350MiB availablecommitfloor,
16MiBpacketcap. Reuse current-turn E4 honestly;freshbytepreflight. Preserve
failed/unfinished evidence,no resourceexpansion/truncation. Old sources,
state,main and protected physical assumptions remain unchanged. Noagents,
branches/worktrees,outreach/publication/push. Scalarwarnings,quartetFAIL,
flavorpause,HB1/C5blocks,custody2sevenNOTPASS and all freeconstants remain.
Shared action/software/data/AIauthor are not independent scientists.
