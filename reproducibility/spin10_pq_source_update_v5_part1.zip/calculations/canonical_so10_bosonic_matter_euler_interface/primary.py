"""BME1 actual current and paired-mass Gram/projector construction."""
from data import *
from itertools import combinations_with_replacement
start=begin('primary');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));grams={};proj={};norms={};ranks={};controls={}
tg=Mat(45,45)
for a in range(45):
 for b in range(45):
  m=mul(T[a],T[b]);z=Z
  for i in range(16):z=add(z,m.d.get((i,i),Z))
  if z:tg.d[a,b]=z
zero(minus(tg,scale(ident(45),Q(2))))
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];sig=[sy.I*v for v in pa]+[sy.eye(2)];sg=sy.Matrix(4,4,lambda i,j:sy.simplify(sy.trace(sig[i].conjugate().T*sig[j])));assert sg==2*sy.eye(4)
current=kron(ident(4),scale(tg,Q('1/2')));zero(minus(current,ident(180)))
for name in ['10','126']:
 B=dec(Y['B'+name]);g=plus(mul(trans(star(B)),B),mul(trans(B),star(B)));assert all(i==j for i,j in g.d),('NONDIGONAL_ACTUAL_GRAM',name)
 nn={i:z for (i,j),z in g.d.items()};assert nn and all(expr(z).is_positive is True for z in nn.values())
 invdiag=Mat(328,328,{(i,i):Q(1/expr(z)) for i,z in nn.items()});p=mul(invdiag,g);zero(minus(mul(p,p),p));grams[name]=enc(g);proj[name]=enc(p);norms[name]=[[i,textq(z)] for i,z in sorted(nn.items())];ranks[name]=len(p.d)
 bad=mul(invdiag,mul(trans(star(B)),B));controls['omit_conjugate_'+name]=len(minus(p,bad).d);assert controls['omit_conjugate_'+name]>0
 print('STAGE PAIRED_SCALAR_GRAM',name,ranks[name],flush=True)
p10,p126=map(dec,[proj['10'],proj['126']]);zero(mul(p10,p126));pn=minus(minus(ident(328),p10),p126);zero(minus(mul(pn,pn),pn));proj['null']=enc(pn);ranks['null']=len(pn.d)
# Derive the allowed mass-independent flow carriers from actual dimensions,
# ghost numbers,Grassmann parity and available Lorentz indices.
atoms={'B':(1,0,0,1),'x':(1,0,0,0),'C':(1,1,1,0),'a':(1,-1,1,0),'Lambda':(2,0,0,0)};carriers={'B':[],'x':[]}
for names in combinations_with_replacement(atoms,2):
 vals=[atoms[n] for n in names]
 if sum(v[0] for v in vals)!=2 or sum(v[1] for v in vals)!=1 or sum(v[2] for v in vals)%2!=1:continue
 nvec=sum(v[3] for v in vals)
 if nvec==1:carriers['B'].append(' '.join(names))
 elif nvec==0:carriers['x'].append(' '.join(names))
for n,(dim,gh,odd,nvec) in atoms.items():
 if dim+1==2 and gh==1 and odd==1 and nvec==0:carriers['B'].append('partial '+n)
carriers={n:sorted(v) for n,v in carriers.items()};assert carriers=={'B':['B C','partial C'],'x':['x C']}
# Source-left J rho and even matter Euler:two swaps place the ghost left.
assert (-1)**sum(x>y for i,x in enumerate([2,3,1]) for y in [2,3,1][i+1:])==1
finish('primary',{'method':'actual_matrix_Gram_and_type_enumeration','source_gradient_sign':1,'source_gradient_before_zero_required':True,'sourcefree_matter_zero_bosonic_Euler':['C','a','Lambda'],'higher_bosonic_source_degree_sourcefree_contribution':0,'current_dual_pairings':enc(current),'current_rank':180,'scalar_grams':grams,'scalar_projectors':proj,'scalar_column_norms':norms,'scalar_ranks':ranks,'mass_independent_flow_carriers':carriers,'ordinary_scalar_input_dimension_retained':328,'controls':controls,'finite_bosonic_source_jets_extracted':False,'finite_bosonic_source_coefficients_assigned':False,'coupled_cancellation_claimed':False,'new_loop_integrals':0},start)
