# BME1: the coupled bosonic-source/matter interface is explicit

Receipt SHA256 f06ad520773f8d8981011033cc98218f5d4b4b927e1bc0aff8b56b9f29c84c8f:
QUALIFIED_BOSONIC_MATTER_EULER_INTERFACE,
ACTUAL_INTERFACE_REDUCED_FINITE_FIRST_SOURCE_JETS_UNEXTRACTED.
This is an exact source/Euler interface result,not a new quantum amplitude
or a coupled finite-restoration theorem. State113/authority34of39 unchanged.

For a bosonic finite local counterterm Cb,the additional source-free image
after coupling the actual matter action is

    rho_B E_B^matter+rho_x E_x^matter,
    rho_i=leftEuler_Ji(Cb)|allJ=0.

The gradient must precede source restriction. The sign is positive in the
inherited odd-left convention;moving the odd ghost across a two-fermion
Euler term makes two swaps. Ghost,antighost and auxiliary matter Euler
derivatives vanish in this projection because the source-free SMA1 action
does not depend on them. Higher bosonic source degree leaves a source and
vanishes only after differentiation and all-source restriction. These
statements do not discard their other quantum/source identities.

The only mass-independent zero-background carrier families required here
are JB partialC,JB B C and Jx C x. Color and scalar tensors remain general;
these are three families,not three finite constants or a complete invariant
rank classification. Source jets carry their integration-by-parts currents.
Background A C and positive-dimension scalar translations remain separate.

The actual left-Weyl current dual is the identity on all180 vector/Lorentz
slots. The45-generator trace Gram is2I45 and the Weyl-sigma Gram is2I4;
normalized duals therefore reconstruct each current independently. No
closed family trace or extra Nambu factor is introduced.

The paired actual scalar Gram matrices are already orthogonal projectors:

    G_R=B_R^dagger B_R+B_R^T B_R^*, R=10,126.

Every active column norm is1. Their ranks are20 and252,with disjoint
supports;their exact common kernel has dimension56. Primary matrix products
and replay component duals agree on537920 scalar Gram/projector positions
and32400 current-dual positions,including all zeros. The verifier checks
B_R P_R=B_R,B_R Pnull=0,B_R^* Pnull=0 and the complete328-dimensional
projector identity. Both conjugate mass maps and independent symbolic
family labels are retained;no numerical flavor point or physical metric
normalization was selected.

The kernel concerns the scalar SOURCE/output index. All328 ordinary
scalar input columns in rho_x remain permitted by this interface. In
particular,a mixing tensor with a Higgs source-output can depend on an
ordinary Phi54/singlet input. It would be wrong to erase those input
columns merely because their direct Yukawa map vanishes.

Removing the conjugate map changes40 and504 normalized projector entries
for10 and126. Restricting sources before differentiation loses the full
active interface. These are algebraic omission controls,not independent
finite quantum measurements. All actual finite coefficients rho remain
unextracted and unassigned;the test does not show they vanish.

Commands:python -B calculations/canonical_so10_bosonic_matter_euler_interface/
run.py;sequential primary/replay/gate native0 at2.0084219/2.0409565/
0.3835652s afterimports. No new failed/incomplete worker. Eight frozen
source copies;441/449 preparation/validation bindings. Same600s/8GiB
sampled/350MiB availablecommit/16MiBpacket bounds. Sample counts2/2/1,
private maxima53112832/50438144/397312B are sparse observations,not
continuous peaks or a complete memory profile. Full captures and external
bosonic-matter-euler-interface-v1-2026-10-23 records are preserved.

Primary packed e3cb549293c9b4ba4b2f3d3c455af9c32b338b4bc9767d325b4f898fa38c54ec,
raw9904153dca3a7b2beb0878a0bbf692e8a761f1c5e9f075bc4a63672abdc9bba3.
Replay packed32b40852874beb8de9457a8ce49bfdd3be58a7bb55d0cb61b95b5f9a82e27750,
raw96cfb1e978da41dcf74b01a28c3d172a7b9db9ff52fd98a9a123638f4a58e531.

Current-turn completed freshE4 reused by authenticated bytes;new byte
preflight performed. Custody remains exit2/seven NOTPASS,not global PASS.
No old action,policy,evidence,physical benchmark,finite scheme or state
was changed;shared action,data,software and AI author remain limitations.

The next smallest consequential quantum task is extraction of the finite
first source jets of the actual bosonic primitive in these three carrier
families,and their regulated coupled transport. The dimensional-Stokes
primitive currently defines them as an operator formula. The38-class UV
source theorem does not supply their finite values,and its nonchiral
metric-lift proof is not automatically a gamma5 applicability theorem.
Start with the JB partialC channel and determine its actual word/heat
support,normalization and dimension jet before assigning any coefficient.
Retain all bosonic-source Euler contributions exactly once in the later
coupled comparison. No need to repeat the completed471s VPR calculation.

VMA1's complete selected vector cancellation and SMP1's scalar primitive
remain qualified in their own scopes. Full coupled Slavnov/QAP/products/
measure/phase,physical chiral prescription,massive C1,E5/A5 and physical
unification remain unqualified. Scalar warnings,quartetFAIL,flavorpause,
HB1/C5blocks,custody and all distinct free constants remain unchanged.
