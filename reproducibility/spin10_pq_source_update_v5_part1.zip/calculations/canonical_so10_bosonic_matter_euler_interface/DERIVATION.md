# BME1: first source gradient before source restriction

Let Cb(z,J) be any bosonic local even ghost-zero dimension4 counterterm,
with source jets put in Euler normal form modulo their recorded currents.
Set rho_i=leftEuler_(J_i) Cb|allJ=0 AFTER differentiating. Extending the
classical source Euler operation by the actual matter action gives exactly

 (b_(Sigma_b+S_m)-b_Sigma_b) Cb|J=0
       =sum_i rho_i E_i^matter.

This follows from the qualified source-left physical Euler rule;it needs
no quantum equivalence,trace theorem or assumption that Cb restores the
chiral theory. For an odd source J and odd rho,Cb=J rho,delta(qJ)=E_m,
so the contribution is+E_m rho. The two fermions make E_m even;moving the
ghost to the left adds two swaps and no new minus. Higher source degrees
leave a source and vanish in this source-free projection only.

The source-free SMA1 action depends on integrated bosonic fields only
through G=B+A and M(x). Its hat kinetic terms have no bosonic fields.
Thus E_C,E_a,E_Lambda^matter=0 here. In the physical quadratic kernel the
remaining response is

 delta D_PP=-ig barGamma_mu A_a rho_B^a_mu
            +PL delta M[rho_x]+PR delta Mdagger[rho_x],
 deltaM=Y10 tensor unvec(B10 rho_x)+Y126 tensor unvec(B126 rho_x).

The inherited alternating-Gaussian1/2 is retained;this kernel formula is
not a new open-line half convention. All general family matrices remain
formal and independent. Source terms involving KP vanish here after all
source restrictions;this does not remove their separately tested images.

Dimension and Lorentz counting at zero background and zero positive
coefficient dimension leaves rho_B=u partialC+v B C and rho_x=w C x.
No Lorentz vector can be made from Cx without a derivative;three ordinary
dimension1 fields exceed the available dimension2. Ghost number1 and
parity exclude an ordinary ghost-free term. Positive-dimension C times
a scalar translation and background A C are not claimed absent globally.
For partialJ*C,integrated rho=-partialC;the local identity is
partial(E_m)*C=-E_m*partialC+partial(E_m C). Never discard the current
before converting the local representative. All ordinary scalar input
columns in w remain328,even if some source-output columns have E_x=0.

For the vector embedding use the actual45 Hermitian T with
Tr(Ta Tb)=2delta_ab. The four2x2 left-Weyl sigma matrices have Gram2I.
Their tensor product has Gram4I180,so the current interface is faithful
on all180 vector/Lorentz coefficients. The right/conjugate current does
not create another set of physical particles or a family factor3.

For the scalar embedding retain independent family labels10/126 and both
holomorphic/conjugate matrices. The Gram in real scalar coordinates is

 G_R=B_R^dagger B_R+B_R^T B_R^*.

In the admitted real form it is positive. If the actual computed G_R are
diagonal,normalize each nonzero column to construct explicit duals and
projectors P10,P126. Check P10 P126=0 and the complete identity
P10+P126+Pnull=I328. These projectors concern the scalar SOURCE/output
index of rho_x. They do not forbid rho_x from depending on ordinary
Phi54 or singlet inputs through a general finite mixing tensor.

No coefficient of rho is determined by these finite-dimensional tests.
The next quantum task is extraction/transport of the actual finite first
source jets of the chosen bosonic primitive and its coupled regulator
insertions. The source38 UV theorem cannot by itself supply those finite
jets,and the nonchiral Stokes theorem is not silently applied to gamma5.
