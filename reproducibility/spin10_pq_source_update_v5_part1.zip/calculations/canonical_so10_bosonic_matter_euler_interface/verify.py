"""BME1 complete finite-dimensional interface gate,no finite coefficient claims."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
keys=['source_gradient_sign','source_gradient_before_zero_required','sourcefree_matter_zero_bosonic_Euler','higher_bosonic_source_degree_sourcefree_contribution','current_dual_pairings','current_rank','scalar_grams','scalar_projectors','scalar_column_norms','scalar_ranks','mass_independent_flow_carriers','ordinary_scalar_input_dimension_retained','finite_bosonic_source_jets_extracted','finite_bosonic_source_coefficients_assigned','coupled_cancellation_claimed','new_loop_integrals']
for k in keys:assert P[k]==R[k],k
assert P['current_rank']==180 and P['source_gradient_sign']==1 and P['scalar_ranks']=={'10':20,'126':252,'null':56}
p={n:dec(v) for n,v in P['scalar_projectors'].items()};zero(minus(plus(plus(p['10'],p['126']),p['null']),ident(328)));zero(mul(p['10'],p['126']))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')
for name in ['10','126']:
 B=dec(Y['B'+name]);zero(minus(mul(B,p[name]),B));zero(mul(B,p['null']));zero(mul(star(B),p['null']));zero(minus(mul(p[name],p[name]),p[name]))
 assert P['controls']['omit_conjugate_'+name]>0
assert not any(P[k] for k in ['finite_bosonic_source_jets_extracted','finite_bosonic_source_coefficients_assigned','coupled_cancellation_claimed','new_loop_integrals'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_BOSONIC_MATTER_EULER_INTERFACE','disposition':'ACTUAL_INTERFACE_REDUCED_FINITE_FIRST_SOURCE_JETS_UNEXTRACTED','elapsed_after_imports':time.perf_counter()-start,'current_rank':180,'current_dual_positions_compared':180**2,'scalar_ranks':P['scalar_ranks'],'scalar_Gram_and_projector_positions_compared':5*328**2,'mass_independent_flow_carriers':P['mass_independent_flow_carriers'],'ordinary_scalar_input_dimension_retained':328,'source_gradient_sign':1,'source_gradient_before_zero_required':True,'sourcefree_matter_zero_bosonic_Euler':['C','a','Lambda'],'higher_bosonic_source_degree_sourcefree_contribution':0,'controls':P['controls'],'drop_source_derivatives_early_loses_all_active_interfaces':True,'finite_bosonic_source_jets_extracted':False,'finite_bosonic_source_coefficients_assigned':False,'coupled_cancellation_claimed':False,'new_loop_integrals':0,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
