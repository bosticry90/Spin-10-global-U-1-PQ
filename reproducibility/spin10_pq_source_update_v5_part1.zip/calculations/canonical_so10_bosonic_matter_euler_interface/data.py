"""BME1 frozen IO and exact coefficient representations, not quantum units."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('BME1_PEER_DENIED')
 sys.addaudithook(audit);return start
def inv(m):
 z=sy.SparseMatrix(m.r,m.c,{ij:expr(v) for ij,v in m.d.items()}).inv()
 return dec({'shape':[z.rows,z.cols],'entries':[[i,j,str(v)] for (i,j),v in z.todok().items()]})
def rowmaps(m):
 out=defaultdict(list)
 for (i,j),v in m.d.items():out[i].append((j,v))
 return out
def gens(coeff,T):
 out=[]
 for r in range(45):
  m=Mat(16,16)
  for (i,j),v in coeff.d.items():
   if i==r:m=plus(m,scale(T[j],v))
  out.append(m)
 return out
def putm(tab,key,m,co=ONE):tab[key]=plus(tab.get(key,Mat(16,16)),scale(m,co))
def table(tab):return [enc(tab.get((c,d),Mat(16,16))) for c in range(45) for d in range(45)]
def fromtable(tab):return {(c,d):dec(tab[45*c+d]) for c in range(45) for d in range(45) if tab[45*c+d]['entries']}
def tablinear(a,b,x,y):
 return {k:plus(scale(a.get(k,Mat(16,16)),x),scale(b.get(k,Mat(16,16)),y)) for k in set(a)|set(b)}
def tabnz(tab):return sum(len(m.d) for m in tab.values())
def tabminus(a,b):return tablinear(a,b,ONE,Q(-1))
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','quantum_coefficients_assigned_from_counterterm':False,'physical_scheme_adopted':False,'extra_family_or_Nambu_half':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
