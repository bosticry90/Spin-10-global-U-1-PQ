"""BME1 component duals on actual current and paired scalar columns."""
from data import *
start=begin('replay');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));dual=Mat(180,180)
sigma=[[[0,sy.I],[sy.I,0]],[[0,1],[-1,0]],[[sy.I,0],[0,-sy.I]],[[1,0],[0,1]]]
for u in range(4):
 for v in range(4):
  inner=Q(sum(sy.conjugate(sigma[u][i][j])*sigma[v][i][j] for i in range(2) for j in range(2))/2)
  if not inner:continue
  for a in range(45):
   for b in range(45):
    q=Z
    for (i,j),z in T[a].d.items():q=add(q,prod(conj(z),T[b].d.get((i,j),Z)))
    val=prod(inner,prod(Q('1/2'),q))
    if val:dual.d[45*u+a,45*v+b]=val
zero(minus(dual,ident(180)))
grams={};projs={};norms={};ranks={}
for tag in ['10','126']:
 B=dec(Y['B'+tag]);cols=defaultdict(dict)
 for (i,j),z in B.d.items():cols[j][i]=z
 dd={};nn=[]
 for j,v in sorted(cols.items()):
  n=Z
  for z in v.values():n=add(n,prod(Q(2),prod(conj(z),z)))
  assert n and expr(n).is_positive is True;nn.append([j,textq(n)])
  for k,w in sorted(cols.items()):
   s=Z
   for i,z in v.items():
    if i in w:s=add(s,add(prod(conj(z),w[i]),prod(z,conj(w[i]))))
   if s:dd[j,k]=s
 g=Mat(328,328,dd);d=Mat(328,328)
 for j,n in nn:
  ni=Q(1/sy.sympify(n))
  for k in cols:
   z=prod(ni,g.d.get((j,k),Z))
   if z:d.d[j,k]=z
 for i in cols:
  for j in range(328):assert d.d.get((i,j),Z)==(ONE if i==j else Z)
 grams[tag]=enc(g);projs[tag]=enc(d);norms[tag]=nn;ranks[tag]=len(cols)
 print('STAGE SCALAR_COLUMN_DUAL',tag,len(cols),flush=True)
nullcols=set(range(328))-set(dec(projs['10']).d.keys()) # use index set below
used={i for x in projs.values() for (i,j) in dec(x).d};pn=Mat(328,328,{(i,i):ONE for i in range(328) if i not in used});projs['null']=enc(pn);ranks['null']=len(pn.d)
zero(minus(plus(plus(dec(projs['10']),dec(projs['126'])),pn),ident(328)))
# The even two-fermion Euler commutes with the odd ghost coefficient.
# Source-left derivative of J*c returns c;source0 before it returns zero.
J,c=sy.symbols('J c');assert sy.diff(J*c,J).subs(J,0)==c and sy.diff((J*c).subs(J,0),J)==0
# Enumerate by target flow rather than by source polynomial. Only a single
# dimension1 ghost and either one derivative or one ordinary dimension1
# boson fit dimension2;the boson's Lorentz rank selects the output.
carriers={target:sorted((['partial C'] if target=='B' else [])+[('B' if target=='B' else 'x')+' C' if target=='B' else 'x C']) for target in ['B','x']}
finish('replay',{'method':'component_current_duals_and_complete_scalar_column_pairings','source_gradient_sign':1,'source_gradient_before_zero_required':True,'sourcefree_matter_zero_bosonic_Euler':['C','a','Lambda'],'higher_bosonic_source_degree_sourcefree_contribution':0,'current_dual_pairings':enc(dual),'current_rank':180,'scalar_grams':grams,'scalar_projectors':projs,'scalar_column_norms':norms,'scalar_ranks':ranks,'mass_independent_flow_carriers':carriers,'ordinary_scalar_input_dimension_retained':328,'finite_bosonic_source_jets_extracted':False,'finite_bosonic_source_coefficients_assigned':False,'coupled_cancellation_claimed':False,'new_loop_integrals':0},start)
