from data import *
t=begin('primary');csw=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');L,cubic=source(csw['field_maps']);p=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(p['C3_plane_to_parent']);vts=read(PK/'frozen_a10_e1_fermion/primary.json');FM=dec(vts['charts']['blocks']['heavy_dual']['field_embedding']);gtt=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');U=dec(gtt['raw_aux_map']);Ui=U.inv()
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);pm=s.symbols('p0_ref0:4');P=pm[0]**2-sum(x*x for x in pm[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];lam=[f'b{a}' if a<12 else f'L{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,lambda c,a:co(P*green[fi[f'C{c}'],fi[anti[a]]]))
for mu in range(4):
 zero(s.SparseMatrix(45,45,lambda a,b:green[fi[lam[a]],fi[f'B{b}_{mu}']])+s.I*pm[mu]*CG.T/P)
zero(Q*CG*Ui.T-s.eye(45))
# Direct rooted walks of G*V, each external label used once.
edges=[(a,b,gt+'/'+vt,degree) for a,k,gt in G for kk,b,vt,degree in V if k==kk];words=[]
for start in sorted(set(a for a,b,gt in G)):
 def walk(node,mask,path):
  if mask==7:
   if node==start:words.append({'start':start,'path':path})
   return
  for a,b,tag,d in edges:
   if a==node and not mask&d:walk(b,mask|d,path+[tag])
 walk(start,0,[])
words=canonical(words)
# Wick permutations of three EVEN vertices, external order J,h before C,a.
perms=[]
for order in itertools.permutations(range(3)):
 odd=[]
 for vertex in order:odd+=([0,2] if vertex==0 else [1,3] if vertex==1 else [])
 perms.append((-1)**sum(odd[i]>odd[j] for i in range(4) for j in range(i+1,4)))
wick=s.Rational(sum(perms),6);phase=co(wick*(-s.I));assert phase==s.I
jm,je,qm,qe,le=s.symbols('jm je qm qe le');assert s.expand(-jm*qm).subs({jm:-s.I*je,qm:-s.I*qe})==je*qe
# Differentiate the actual generic covariant kinetic quadratic cross term.
bx,xx,dx,rho,g=s.symbols('B x dX rho g');kin=(dx-g*bx*rho*xx)**2/2;assert s.expand(kin).coeff(g,1)==-bx*dx*rho*xx
blocks=[];wrong=[];changed_reverse=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));Rraw=[tidy(sum((Q[d,b]*R[d] for d in range(45) if Q[d,b]),s.SparseMatrix(n,n,{}))) for b in range(45)];T=[tidy(sum((FM[d,a]*R[d] for d in range(45) if FM[d,a]),s.SparseMatrix(n,n,{}))) for a in range(33)]
 for z in R+T:zero(z+z.T)
 AR=[tidy(sum((CG[b,a]*Rraw[b] for b in range(45) if CG[b,a]),s.SparseMatrix(n,n,{}))) for a in range(45)]
 GT=[tidy(sum((CG[c,12+a]*T[a] for a in range(33) if CG[c,12+a]),s.SparseMatrix(n,n,{}))) for c in range(45)]
 raw=[s.SparseMatrix(n,n,{}) for _ in range(45)];bad=[s.SparseMatrix(n,n,{}) for _ in range(45)];cache={}
 for (r,a,c),z in L.items():
  if (a,c) not in cache:cache[a,c]=(AR[a].T*GT[c],GT[c].T*AR[a])
  raw[r]+=z*cache[a,c][0];bad[r]+=z*cache[a,c][1]
 mats=[tidy(sum((Ui[r,i]*raw[i] for i in range(45) if Ui[r,i]),s.SparseMatrix(n,n,{}))) for r in range(45)];bm=[tidy(sum((Ui[r,i]*bad[i] for i in range(45) if Ui[r,i]),s.SparseMatrix(n,n,{}))) for r in range(45)]
 changed_reverse+=sum(len(tidy(a-b).todok()) for a,b in zip(mats,bm));blocks.append({'sector':sec,'matrices':list(map(enc,mats))});print('STAGE RAW_COLOR',sec,flush=True)
# Exact symbol contraction has no D-dependent Lorentz trace.
q2,k0,k1,kh=s.symbols('q2 k0 k1 kh');assert s.cancel((k0**2+k1**2+kh)/(k0**2+k1**2+kh))==1
ell=s.log(s.Rational(3,2));sigma=-s.log(2)-(s.log(s.pi)+1-s.EulerGamma)/2;nlog=s.Symbol('n_log');chi4=s.EulerGamma+s.log(4)-nlog-2*sigma;chi6=co(chi4+ell)
finish('primary',{'method':'actual_raw_source_Green_heavy_dual_contraction_and_ordered_third_cumulant','words':words,'proper_pairings':graphs(),'source_linear_rows':len(L),'source_cubic_rows':len(cubic),'source_cubic_grades':sorted(set(tuple(x['parameter_monomials'][0]) for x in cubic)),'source_cubic_one_port_graph_has_bridge':True,'cubic_bridge_audit':cubic_bridge_audit(),'wick_signs':perms,'wick_cumulant':str(wick),'universal_phase':str(phase),'color':blocks,'reverse_order_changed_positions':changed_reverse,'dimension_angular_unit':'1','dimension_angular_derivative':'0','heat_edges':3,'heat_length':6,'chi4':str(co(chi4)),'chi6':str(chi6),'coefficient_positions':45*328**2,'affine_v_evaluation_qualified':False,'complete_common_source_extension_qualified':False},t)
