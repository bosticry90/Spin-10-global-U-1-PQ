from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import gzip,json,os,sys,time,threading,itertools,importlib.util
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
SECTORS=[('Phi',54),('Sigma',252),('phi',20),('S',2)]
@lru_cache(maxsize=131072)
def co(z):return s.simplify(s.sympify(z))
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):co(z) for i,j,z in m['entries']})
def tidy(m):return s.SparseMatrix(m).applyfunc(co)
def zero(m):assert not tidy(m).todok()
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(tidy(m).todok().items())]}
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('ATS1_PEER_DENIED')
   if p.parent.name=='canonical_so10_vacuum_heat_root_completion' and p.suffix=='.gz':raise PermissionError('ATS1_PREVIOUS_TARGET_DENIED')
 sys.addaudithook(guard);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','physical_scheme_adopted':False,'full_h_source_QAP_E5A5_qualified':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def source(rows):
 g,xi=s.symbols('g10 xi');L=defaultdict(lambda:s.S.Zero);cub=[]
 names=[f'b{a}' if a<12 else f'L{a}' for a in range(45)];li={n:i for i,n in enumerate(names)}
 for r,name in enumerate(names):
  for row in rows[name]:
   w=row['word'];z=co(row['coefficient'])
   if len(w)==2:
    c=int(next(x for x in w if x.startswith('C'))[1:]);a=li[next(x for x in w if x in li)];unit=co(z/g);assert not unit.free_symbols;L[r,a,c]+=unit
   else:
    assert len(w)==3 and sum(n.startswith('C') for n in w)==2 and sum(n.startswith(('bar','ub')) for n in w)==1
    cub.append({'output':r,'word':w,'coefficient':str(z),'parameter_monomials':[list(v) for v in s.Poly(z,g,xi).monoms()]})
 return {k:co(z) for k,z in L.items() if co(z)},cub
G=[('B','B','BB'),('B','L','BL'),('L','B','LB'),('C','a','Ca'),('a','C','aC'),('X','X','XX'),('F','F','FF')]
V=[('L','C','J_LC',1),('C','L','J_CL',1),('X','a','h_Xa',2),('a','X','h_aX',2),('B','X','x_BX',4),('X','B','x_XB',4)]
def canonical(words):return sorted(words,key=lambda x:(x['start'],x['path']))
def graphs():
 # Independent undirected proper graph: actual quantum legs at each vertex.
 legs=[('J','C'),('J','L'),('h','a'),('h','X'),('x','B'),('x','X')];pairs=[]
 def match(rem,out):
  if not rem:
   # Test connectedness and every possible removed-edge bridge.
   edges=[(legs[a][0],legs[b][0]) for a,b in out]
   def connected(ee):
    seen={'J'}
    for _ in range(3):seen|={v for a,b in ee for u,v in [(a,b),(b,a)] if u in seen}
    return len(seen)==3
   if connected(edges) and all(connected(edges[:i]+edges[i+1:]) for i in range(len(edges))):pairs.append(sorted([[legs[a][0],legs[a][1],legs[b][0],legs[b][1]] for a,b in out]))
   return
  a,*tail=rem
  for b in tail:
   if any((x,y)==(legs[a][1],legs[b][1]) for x,y,_ in G):match([v for v in tail if v!=b],out+[(a,b)])
 match(list(range(6)),[]);return sorted(pairs)
def cubic_bridge_audit():
 # qLambda's three quantum legs; the tangent supplies the external scalar.
 # Each available ghost pairing has a self-loop and a bridge to the h vertex.
 pairings=[[(0,3),(1,2)],[(1,3),(0,2)]];nodes=['J','J','J','h'];bridges=[]
 for pairs in pairings:
  edges=[(nodes[a],nodes[b]) for a,b in pairs]
  bridges.append(sum(a!=b for a,b in edges))
 assert bridges==[1,1]
 return {'candidate_pairings':len(pairings),'bridge_counts':bridges,'proper_pairings':0,'Hessian_unused_source_field':'absent_external_C_or_a'}
