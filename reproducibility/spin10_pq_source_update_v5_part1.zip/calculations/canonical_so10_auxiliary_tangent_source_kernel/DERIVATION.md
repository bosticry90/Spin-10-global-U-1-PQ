# ATS1 convention and proof obligations

Use qLambda_M=g betaL*C*Lambda_M+the actual cubic CCa rule. With the fixed
Lambda_M=-i Lambda_E and common Wick sign-1, require the source term to retain
JLambda_E*qLambda_E. This gives JLambda_M=-i JLambda_E and
qLambda_E=i*qLambda_M. Thus its quadratic Euclidean source vertex is
g JLambda_r betaL[r,a,c] C_c Lambda_a. This derivation precedes all target
access. The cubic term has its own phase and is retained in the support audit.
The tangent vertex is the VTS +g*xi*h_A*a_s*T_s,jA*X_j.

The scalar kinetic action is (partialX-g*rho_a*B_a*X)^2/2. At zero external
x jets, its current is -g*B_a*(partialX)_j*(rho_a*x)_j. Differentiating the
two full scalar legs before setting external jets0 gives the same expression;
there is no extra half or second identical current. Use actual rho.T=-rho.

Place J-source at1,h at2,x at3. At zero external transfers use the quantum
C at1 momentum-k,Lambda at1 momentum+k; a at2 momentum+k,X at2 momentum-k;
B at3 momentum-k,X at3 momentum+k. Thus the ordered mixed inverse is
G_LB(+k)=+k/Q in the normalized Euclidean plane. The current contributes
-i*k, not+i*k. Its product is -i*Q/Q. The permutation of odd variables
(J,C,h,a) to(J,h,C,a) has sign-1. The third cumulant+1/6 sums six even-vertex
orders. The prospective universal unit is therefore+i, to be checked by a
literal paired-mode Gaussian calculation before accepting the model tensor.

Let CG[c,s] be the actual raw ghost inverse residue, U the raw auxiliary
embedding and Q the raw-to-plane gauge/ghost map. The raw mixed inverse unit
is CG.T. Check this against every actual Lorentz component before using it.
Rraw_b=sum_d Q[d,b]*rho_d, T_s=sum_d FM[d,s]*rho_d for heavy raw antighosts.
With Sraw[r,a,c] read directly from qLambda/g, the real raw tensor is

 Fraw_r = sum_acbs Sraw[r,a,c]*CG[b,a]*CG[c,s]*Rraw_b.T*T_s,
 Fplane_r = sum_i (U^-1)[r,i]*Fraw_i.

The independent plane expression uses actual source-column transport
betaL_r=U^-1*Sraw_c*U, C_raw=Q^-1*Cplane, and P_M=I-H*H.T:

 Fplane_r = sum_ac betaL[r,a,c]*rho_a.T*(sum_d P_M[d,c]*rho_d).

Do not replace P_M byI or first33/last33 coordinate slots. The physical plane
mixes raw unbroken/broken directions. Both expressions carry external x thenh
indices(k,A); source order isJ,h. The Euclidean kernel is+i*F; Wick pullback
reality is checked in the original real Lorentzian source chart.

The determinant's marginal external classes have oneJ,oneh,onex. The source
qLambda C*Lambda and tangent a*X each have exactly two quantum legs. The
scalar current B*X is the candidate completion. A cubic JL CCa source with
no external C/a has three quantum legs. Giving the tangent's X to the
external x makes its remaining quantum a a one-port vertex: any connecting
edge is a bridge, so this connected graph is not proper1PI. In the Hessian
formulation the unused third source field is an absent external C/a. All
other interaction Hessians require extra external fields or positive-dimension
coefficients. Derive the full ordered/cyclic list from the typed matrices and
separately from graph pairings; any additional support must be resolved.

The mixed and current vector indices contract sum_mu k_mu*k_mu=Q before
angular averaging inD dimensions. There is no numerical Lorentz trace or
4/D factor. The critical numerator therefore has zero firstDjet. Three heat
edges give exp(-6tQ). No external heat Taylor jet or power term has this zero-
jet dimension4 grade. For an auxiliary positive mass the scalar radial
integral is (1+z)*exp(z)*E1(z)-1,z=6tm2; its finite part is
-gamma_E-log6-logm2-1+n_log. The dimensional comparator is
-gamma_E+log4pi-logm2. Difference chi6=chi4+log(3/2), with
chi4=1+log16pi-n_log. The mass is an IR comparator, not a physical choice.

Independently the difference of three-edge and two-edge critical heat
integrals is -log(3/2)/(16pi2); combine with the already qualified
nonexceptional two-edge comparison. Absolutely integrable lower-symbol
remainders cancel in the relative limit. With the actual positive scalar
reference, soft degrees of Ca,LB,XX are2,1,0; common independent transfer
momenta and free-edge smoothing give the inherited first-variation domain.
An isolated scaleless integral or constant physical vacuum limit is not used.
Hence the proposed local relative member is
i*g3*xi/(16pi2)*(chi4+log(3/2))*JL_r*x_k*F[r,k,A]*h_A,
reordered as JL*h*x. Its full quantum/source consistency is not presumed.
