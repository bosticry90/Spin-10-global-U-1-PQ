from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
# Primary raw source/actual Green contraction before any scalar generator.
S,cub=source(packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['field_maps']);ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};GG=dec(ref['reference_Green_raw_C3']);pp=s.symbols('p0_ref0:4');P=pp[0]**2-sum(z*z for z in pp[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];CG=s.SparseMatrix(45,45,lambda c,a:co(P*GG[fi[f'C{c}'],fi[anti[a]]]))
raw=defaultdict(lambda:s.S.Zero)
for (r,a,c),z in S.items():
 for h in range(33):
  if CG[c,12+h]:raw[r,a,h]+=z*CG[c,12+h]
raw={k:co(z) for k,z in raw.items() if co(z)};assert not raw
used=sorted({c for r,a,c in S});assert all(not CG[c,12:].todok() for c in used)
# Independent replay source-column projection; the physical H plane is mixed.
LS,cubic=source(packed(CAL/'canonical_so10_cutoff_source_ward_operator/replay_inputs.json.gz')['field_maps']);p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');Q=dec(p['C3_plane_to_parent']);Qi=Q.inv();U=dec(packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz')['raw_aux_map']);Ui=U.inv();H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);zero(H.T*H-s.eye(12));PM=s.eye(45)-H*H.T;zero(PM*PM-PM);assert PM.trace()==33
columns=[Ui*s.SparseMatrix(45,45,{(r,a):z for (r,a,c0),z in LS.items() if c0==c})*U for c in range(45)];beta=[tidy(sum((Qi[c,d]*columns[c] for c in range(45) if Qi[c,d]),s.SparseMatrix(45,45,{}))) for d in range(45)]
projected=[tidy(sum((PM[d,c]*beta[c] for c in range(45) if PM[d,c]),s.SparseMatrix(45,45,{}))) for d in range(45)];assert not any(m.todok() for m in projected);full_bad=sum(len(m.todok()) for m in beta);assert full_bad>0
out={'method':'raw_ghost_port_before_scalar_generators_AND_independent_plane_source_column_projector','raw_port_positions':45*45*33,'raw_port_nonzero':len(raw),'plane_port_positions':45**3,'plane_port_nonzero':sum(len(m.todok()) for m in projected),'raw_source_ghost_indices':used,'heavy_projector_rank':33,'full_projector_nonzero_control':full_bad,'raw_linear_rules':len(S),'raw_cubic_rules':len(cub),'before_momentum_integration':True,'all_offblock_scalar_coefficients_zero_by_sector_preserving_types':True,'same_primitive_and_fixed_reference':True,'elapsed_after_imports':time.perf_counter()-t,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'annihilator_v2_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
