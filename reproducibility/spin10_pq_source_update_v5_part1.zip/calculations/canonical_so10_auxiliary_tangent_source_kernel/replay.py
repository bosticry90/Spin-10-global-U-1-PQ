from data import *
t=begin('replay');csw=packed(CAL/'canonical_so10_cutoff_source_ward_operator/replay_inputs.json.gz');L,cubic=source(csw['field_maps']);p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');Q=dec(p['C3_plane_to_parent']);Qi=Q.inv();gtt=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');U=dec(gtt['raw_aux_map']);Ui=U.inv();H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);PM=s.eye(45)-H*H.T
# Independent support via vertex permutations and compatible endpoint roles.
words=[]
for perm in itertools.permutations([1,2,4]):
 choices=[[v for v in V if v[3]==k] for k in perm]
 for vs in itertools.product(*choices):
  for gs in itertools.product(G,repeat=3):
   if all(gs[i][1]==vs[i][0] and vs[i][1]==gs[(i+1)%3][0] for i in range(3)):
    words.append({'start':gs[0][0],'path':[gs[i][2]+'/'+vs[i][2] for i in range(3)]})
words=canonical(words)
# Source-column transport, not the raw loop contraction.
S=[s.SparseMatrix(45,45,{(r,a):z for (r,a,c0),z in L.items() if c==c0}) for c in range(45)];Braw=[Ui*m*U for m in S];B=[tidy(sum((Qi[c,d]*Braw[c] for c in range(45) if Qi[c,d]),s.SparseMatrix(45,45,{}))) for d in range(45)];beta=[(r,a,c,z) for c,m in enumerate(B) for (r,a),z in m.todok().items()]
blocks=[];changed_full=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));RH=[tidy(sum((PM[d,c]*R[d] for d in range(45) if PM[d,c]),s.SparseMatrix(n,n,{}))) for c in range(45)];out=[s.SparseMatrix(n,n,{}) for _ in range(45)];bad=[s.SparseMatrix(n,n,{}) for _ in range(45)];cache={}
 for r,a,c,z in beta:
  if (a,c) not in cache:cache[a,c]=(R[a].T*RH[c],R[a].T*R[c])
  out[r]+=z*cache[a,c][0];bad[r]+=z*cache[a,c][1]
 out=list(map(tidy,out));bad=list(map(tidy,bad));changed_full+=sum(len(tidy(a-b).todok()) for a,b in zip(out,bad));blocks.append({'sector':sec,'matrices':list(map(enc,out))});print('STAGE PLANE_COLOR',sec,flush=True)
# Literal +/- modes. Algebra order externalJ,h, then internal ghosts.
spec=importlib.util.spec_from_file_location('ats_exact',CAL/'canonical_so10_tangent_heat_ward_bridge/data.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
par=[0,0,0,1,1]*2;at=lambda mode,i:5*mode+i;gm={};vj={};vh={};vx={}
for mode,q in enumerate([-1,1]):
 other=1-mode
 for a,b,z in [(0,0,3),(0,1,-q),(1,0,q),(2,2,1),(3,4,1),(4,3,-1)]:gm[at(mode,a),at(other,b)]=e.ex(0,z)
 vj[at(mode,1),at(other,3)]=e.ex(1,1);vj[at(mode,3),at(other,1)]=e.ex(1,-1)
 vh[at(mode,2),at(other,4)]=e.ex(2,1);vh[at(mode,4),at(other,2)]=e.ex(2,-1)
 vx[at(mode,0),at(other,2)]=e.ex(0,s.I*q);vx[at(mode,2),at(other,0)]=e.ex(0,-s.I*q)
val={};ordinary={}
for vs in itertools.permutations([vj,vh,vx]):
 m=e.mm(e.mm(e.mm(gm,vs[0]),e.mm(gm,vs[1])),e.mm(gm,vs[2]));val=e.add(val,e.trace(m,par));ordinary=e.add(ordinary,e.trace(m,par,True))
# Gaussian1/2, logarithm1/3, paired full-shell mode average1/2.
def sym(z):return s.Rational(z[0])+s.I*s.Rational(z[1])
phase=co(sym(val.get(3,(0,0)))/12);badphase=co(sym(ordinary.get(3,(0,0)))/12)
z=s.symbols('z',positive=True);rad=s.limit((1+z)*s.exp(z)*s.expint(1,z)-1+s.log(z),z,0,dir='+');assert rad==-s.EulerGamma-1
nlog=s.Symbol('n_log');fdim=-s.EulerGamma+s.log(4*s.pi);fheat=-s.EulerGamma-s.log(6)-1+nlog;chi6=co(fdim-fheat);chi4=co(chi6-s.log(s.Rational(3,2)))
# Independent relative radial integral; never assign a scaleless integral0.
a,b,u=s.symbols('a b u',positive=True);fr=s.integrate(s.exp(-u),(u,0,s.oo));assert fr==1
finish('replay',{'method':'source_column_plane_projector_and_literal_paired_mode_exterior_Gaussian','words':words,'proper_pairings':graphs(),'source_linear_rows':len(L),'source_cubic_rows':len(cubic),'source_cubic_grades':sorted(set(tuple(x['parameter_monomials'][0]) for x in cubic)),'source_cubic_one_port_graph_has_bridge':True,'universal_phase':str(phase),'ordinary_trace_phase':str(badphase),'color':blocks,'full_projector_changed_positions':changed_full,'dimension_angular_unit':'1','dimension_angular_derivative':'0','heat_edges':3,'heat_length':6,'chi4':str(chi4),'chi6':str(chi6),'wrong_two_edge_finite_difference':str(s.log(s.Rational(3,2))),'coefficient_positions':45*328**2,'affine_v_evaluation_qualified':False,'complete_common_source_extension_qualified':False},t)
