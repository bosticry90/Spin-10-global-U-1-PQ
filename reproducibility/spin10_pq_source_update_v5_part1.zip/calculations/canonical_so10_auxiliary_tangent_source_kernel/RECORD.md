# ATS1: the proper auxiliary-source/tangent/scalar coefficient

Frozen before computation at base452d5b1e6e310ff878eaa839f51427de36ad7b56,
main33771olderblobs; state113/authority34of39 unchanged. Whole goalACTIVE.

Question: what actual proper one-loop local coefficient multiplies JLambda*h*x
in the explicit provisional Cartesian v/z/h extension? VHR1's six physical
fermion projections do not determine this zero-matter source coefficient.
The least expensive competent test is complete Hessian/cycle support followed
by the actual mixed scalar/ghost/auxiliary contraction, not another PP table.
Positive, zero, different finite direction or unsupported domain outcomes must
be preserved. No coefficient may be assigned from a desired Nielsen identity.

Domain: dimension4, ghost0, zero external jets, coefficient dimension0,
background0 and physical hats0; all45 source/ghost directions, all328 scalar
and tangent components, both full and heavy charts. Fixed K0 as in VTS/HWB;
no GF-v or physical mass resummation, no affine-v assertion. Use the actual
source qLambda including cubic CCa, the fixed tangent h*a*T*x, scalar covariant
kinetic current and both mixed inverse orientations. Target orderg3*xi.
Retain exact other source grades in the audit. Terms excluded from a proper
one-loop determinant are not zero as arbitrary connected products.

Qualified comparators: VTS actual primitive/Green/contours, HWB first-variation
free-edge domain, VHR1 actual betaL and source transports, VTF/BSF finite heat
comparison. Old receipts are authenticated reuse, not wholesale replay.
Primary: raw action source maps, actual raw Green, heavy dual and component
contractions; ordered third-cumulant Wick sign and kinetic differentiation.
Replay: source-column normalization, plane heavy projector and ordered matrix
products; literal paired +/- mode exterior superdeterminant coefficient.
Both use the same frozen action/representations/software/AI author. Agreement
does not validate those premises or constitute outside scientific confirmation.

First prove why all target-compatible proper vertices have two quantum legs,
how source cubic one-port h graphs have bridges, and why no unlabelled extra
interaction can occur. Compare complete cyclic support, all coefficients and
zero complements; do not demand a prechosen count to qualify support. The
finite angular numerator must be derived before settingD4. Keep positive heat
per edge; compare positive auxiliary-IR and nonexceptional domains without
identifying their absolute finite amplitudes. No unique physical scheme is
selected: chi4,kappa,b0 and invariant finite constants remain distinct.

Controls: scalar/aux transpose and reversed color order, wrong heavy projector,
ordinary trace in place of supertrace, and wrong two-edge heat length where
sensitive. Each control's actual sensitivity is reported, not assumed. Any
unexpected proper class or sign discrepancy blocks the coefficient claim until
a preserved, versioned continuation resolves it. Failure/exhaustion is notPASS.

Sequential primary,replay,then gate. Each600s afterimports/8GiB sampled private/
350MiB availablecommit launchfloor/16MiB stored packet; poleblind Python-B,
immutable inputs/source copies/exclusive writes and complete failed captures.
Validation before local commit, external before/index/after seals preserve all
33771olderblobs. Current delegatedE4 audits; custody exit2/sevenNOTPASS.
No agents/branch/worktree/push/outreach/foundation or physical input change.
No flavor/HB1/C5 activation, full source prescription/QAP/measure/phase/causal/
physical vacuum/massiveC1/E5A5/GUT promotion. Director education nonblocking.

Results, actual resources, limitations and next smallest question go inRESULT
and the next handoff. A measured source kernel does not prove a compatible
common h-dependent action/source normalization. That remains a separate test.
