# ATS1 V2: verify the permitted zero outcome without rewriting the failed gate

The original primary and replay completed native0. They agree at all3007080
block-diagonal coefficient positions: every coefficient is exactlyzero. The
literal paired-mode Gaussian agrees with the ordered Wick phase+i. Replacing
the heavy projector byI produces36320 scalar positions; ordinary trace gives
the wrong universal phaseI/3. Reversing the color order changes0 positions in
the actual zero channel and is INSENSITIVE here. All original files/captures
and the controller failure remain unchanged. No original validation receipt
or accepted artifact was emitted.

The original verifier failed its line17 assertion nonzero>0. That requirement
was not in RECORD's scientific question: zero was expressly a permitted
outcome. It was an unjustified verifier assumption. V2 does not change the
action, source, phase, propagators, projector, domain, finite map or coverage.
It does not relabel the original failed gatePASS. Reuse completed primary and
replay without rerunning them. Add a stronger structural check instead:

1. Contract the actual raw source ghost port with every heavy antighost Green
   column before scalar generators or momentum integration: all45*45*33 slots.
2. Independently normalize source columns and contract their ghost index with
   the actual plane heavy projector: all45^3 slots.
3. Authenticate and compare the completed full scalar contractions, retaining
   all implicit zeros and the exact four scalar block types. Mixed scalar
   sector pairs are absent because both the generators and primitive preserve
   each irreducible scalar sector; assert this type decomposition rather than
   counting only the block positions as a full328-square tensor.
4. Preserve correct/incorrect universal finite templates. A wrong heat length
   or sign cannot be diagnosed from a model tensor that is identicallyzero;
   report this sensitivity boundary explicitly. The full-projector control is
   sensitive to the actual model tensor. Do not invent a nonzero contact term.

The source has180 raw linear rules and836 cubic rules atg2 (xi0), not an
assumed xi1. Thus cubic source plus tangent has the targetg3xi and MUST be
excluded by the proper-graph bridge argument, not coupling power. The six
ordered walks represent a single unoriented triangle. A connected proper
one-loop graph has all internal degrees2: connected loopnumber1 implies
E=V and sumdeg=2V, while a degree1 vertex would be a bridge. This justifies
the Hessian support criterion, including the cubic-source exclusion.

This may establish that the actual selected proper kernel and its local
relative comparison vanish before integration. It does not forbid an
admissible homogeneous finite mixing term, fix a contact normalization or
prove the remaining h-dependent source/ordinary identities. Positive-v affine
source evaluation, other connected products and source completions stay open.
Same600s/8GiB sampled/350MiB/16MiB caps and immutable-source/guarded-native
execution; authority34/39 and all historical scientific scopes unchanged.
