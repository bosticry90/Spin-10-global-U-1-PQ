from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');A=packed(HERE/'annihilator_v2_tables.json.gz')
for key in ['words','proper_pairings','source_linear_rows','source_cubic_rows','source_cubic_grades','source_cubic_one_port_graph_has_bridge','universal_phase','dimension_angular_unit','dimension_angular_derivative','heat_edges','heat_length','coefficient_positions','affine_v_evaluation_qualified','complete_common_source_extension_qualified']:assert P[key]==R[key],key
assert P['universal_phase']=='I' and P['words'] and P['proper_pairings'] and P['source_cubic_rows']==A['raw_cubic_rules']
for key in ['chi4','chi6']:assert co(s.sympify(P[key])-s.sympify(R[key]))==0
ell=s.log(s.Rational(3,2));assert co(s.sympify(P['chi6'])-s.sympify(P['chi4'])-ell)==0
assert A['raw_port_positions']==66825 and A['plane_port_positions']==91125 and A['raw_port_nonzero']==A['plane_port_nonzero']==0 and A['before_momentum_integration'] and A['full_projector_nonzero_control']>0
assert P['source_cubic_grades']==[[2,0]] and P['cubic_bridge_audit']['proper_pairings']==0
positions=0;nonzero=0;persector={};assert len(P['color'])==len(R['color'])==len(SECTORS)
for pb,rb,(sec,n) in zip(P['color'],R['color'],SECTORS):
 assert pb['sector']==rb['sector']==sec and len(pb['matrices'])==len(rb['matrices'])==45;count=0
 for p,r in zip(pb['matrices'],rb['matrices']):
  pm,rm=dec(p),dec(r);assert pm.shape==rm.shape==(n,n);zero(pm-rm);zero(pm);zero(rm)
  positions+=n*n;count+=len(pm.todok())
 persector[sec]=count;nonzero+=count
assert positions==45*sum(n*n for _,n in SECTORS) and nonzero==0
assert P['reverse_order_changed_positions']==0 and R['full_projector_changed_positions']>0 and R['ordinary_trace_phase']!=R['universal_phase']
assert (HERE/'controller_failure.json').exists() and read(HERE/'verify_capture.json')['exit_code']==1 and not (HERE/'validation_receipt.json').exists() and not (HERE/'selected_auxiliary_tangent_source.json.gz').exists()
out={'status':'QUALIFIED_STRUCTURAL_ZERO_SELECTED_PROPER_JLAMBDA_H_X_CHANNEL','elapsed_after_imports':time.perf_counter()-t,'ordered_words':len(P['words']),'proper_unoriented_graphs':len(P['proper_pairings']),'raw_source_port_positions':66825,'plane_source_port_positions':91125,'block_diagonal_coefficient_positions':positions,'offblock_zero_positions_by_sector_types':45*328**2-positions,'full_source_scalar_tangent_positions':45*328**2,'nonzero_coefficients':0,'nonzero_by_sector':persector,'universal_phase':P['universal_phase'],'source_linear_rows':P['source_linear_rows'],'source_cubic_rows':P['source_cubic_rows'],'cubic_bridge_exclusion':P['cubic_bridge_audit'],'zero_before_momentum_integration':True,'heat_length':6,'universal_chi6':P['chi6'],'coupling_order':'g10^3*xi','affine_v_evaluation_qualified':False,'common_full_h_source_extension_qualified':False,'full_QAP_measure_phase_E5A5_qualified':False,'homogeneous_contact_freedom_fixed':False,'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','original_failed_verifier_preserved':True,'controls':{'reversed_color_order_changed_positions':0,'reversed_color_order_actual_model_sensitive':False,'full_instead_of_heavy_projector_changed_positions':R['full_projector_changed_positions'],'source_port_full_projector_nonzero_positions':A['full_projector_nonzero_control'],'ordinary_trace_universal_phase':R['ordinary_trace_phase'],'wrong_heat_length_universal_shift':str(ell),'heat_length_and_phase_actual_zero_channel_sensitive':False}}
raw=(json.dumps({'coefficient':'0, before momentum integration; homogeneous finite mixing freedom not fixed','F':P['color'],'proper_support':P['words'],'annihilator_proof':A,'scope':out},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_auxiliary_tangent_zero_v2.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()})
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
