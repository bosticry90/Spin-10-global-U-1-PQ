# The selected auxiliary-source/tangent/scalar kernel is structurally zero

The actual proper one-loop JLambda*h*x channel vanishes before momentum
integration in the declared provisional Cartesian extension. This is a
source/ghost support result, not a fitted contact subtraction. Both completed
scalar contractions agree with the stronger raw-port and plane-projector
annihilation proofs. Authority remains34/39; the full h-dependent quantum
normalization and E5/A5 remain unqualified.

## Actual support and zero mechanism

The actual qLambda action contains180 raw linear C*Lambda rules and836
cubic C*C*a rules. The linear rules use raw ghost indices0through11 only.
Do not transfer that statement to the first12 physical plane coordinates:
the plane mixes the raw unbroken and broken directions.

The ordinary scalar current, tangent h*a*X vertex and linear source produce
one unoriented triangle, with6 ordered trace words. Its internal roles are
Ca/aC, BL/LB andXX. The derivative acts on the internal scalar momentum;
both inverse orientations and source contour phases are retained. Raw
third-cumulant Wick signs give+i, matching the literal paired-mode exterior
Gaussian. An ordinary trace instead gives the incorrect universal unitI/3.
There is no extra family multiplicity, Pfaffian factor, or4/D trace.

The cubic source cannot simply be excluded by coupling order: its actual
order isg2*xi0, so together with the tangent it has the targetg3*xi. In a
connected proper one-loop graph every internal vertex has degree2. A degree1
vertex is a bridge, while E=V forces the mean degree2. Both candidate cubic
source pairings give a source self-loop and a bridge to the one-port tangent
vertex when its scalar is external. They are connected but not proper1PI.
The Hessian criterion gives the same exclusion: an unused source field would
be an absent externalC orantighost. This is not a zero theorem for arbitrary
connected composite products.

The allowed triangle's actual ghost port is alreadyzero:

    sum_c Sraw[r,a,c]*CG[c,heavy_s] = 0,
    sum_c betaL[r,a,c]*P_M[d,c] = 0.

The first direct raw calculation covers66825 slots. The independent
source-column transport/projector calculation covers91125 slots. P_M is
the actual rank33 heavy projector, not a coordinate-slot selection. Thus
the result does not rely on scalar-generator cancellations or the value of
an integral. It holds before those scalar contractions in this fixed
reference and selected proper graph family.

The completed raw-Green/dual contraction and plane scalar contraction also
agree at3007080 within-sector coefficient positions, allzero. The additional
1834200 cross-sector positions vanish by the actual block-preserving scalar
and primitive types, giving4841280 full source/scalar/tangent positions.
These are coefficient positions, not independent experiments or particles.

The wrong full projector produces880 nonzero source-port positions and36320
nonzero scalar positions. This is a sensitive model-specific negative control.
Reversing the color order changes0 actual positions and is INSENSITIVE in
this channel. Phase and heat-length changes are likewise invisible after
multiplication by the actual zero tensor. Their nonzero universal templates
are useful convention checks, not independent proof of this model's zero.

## Finite normalization and scope

The allowed universal triangle has three positive heat edges, length6. Its
mixed/current numerator contracts toQ before angular averaging inD, with
no first dimensional angular jet. The independently derived relative factor
is chi6=chi4+log(3/2)=1+log(24pi)-n_log. Positive auxiliary-IR and inherited
nonexceptional heat differences agree. Lower-symbol integrable remainders
cancel in this relative local comparison; no scaleless integral or physical
constant-vacuum limit is assignedzero.

Here the actual tensor multiplying that factor iszero. Thus neither a pole
nor an extra fixed finite relative JLambda*h*x member is required by this
selected calculation. It does NOT fix a permissible homogeneous finite
operator-mixing coefficient, choose a subtraction scheme, or prove there is
no such freedom. Keep chi4,kappa,b0 and invariant freedoms distinct.

This result concerns a proper one-loop zero-jet dimension4 coefficient at
coefficient dimension0, background/hats0, fixed Cartesian K0, and the explicit
provisional v/z/h extension. The common first-variation domain uses the
existing independent-transfer/free-edge construction. Scalar reference
positivity and source-Hessian premises are shared. Positive-v affine source
evaluation, the ordinary h*antighost*x/h*antighost*v vertices, general
connected products, full source mixing, QAP, measure/global phase, causal/
Lorentzian and physical-vacuum limits are not supplied by this result.

## Failed verifier preserved and corrected

Primary and replay completed native0. The original verifier then failed
its nonzero>0 assertion. That was an unjustified harness assumption: RECORD
expressly allowedzero. The original sources/copies, input manifests, full
capture and controller failure are unchanged. No original validation receipt
or selected artifact was produced; the failed verifier remains native1.

CONTINUATION_V2 freezes a stronger structural proof and zero-aware gate. It
reuses the completed contractions, verifies the raw/plane annihilators and
explicitly separates within-sector computed zeros from cross-sector type
zeros. It does not change a scientific acceptance condition, physical input,
source rule, phase, kernel or projector. The V2 proof and gate completed
native0. No completed primary/replay was rerun. An earlier read-only lookup
for a nonexistent old gauge-source DERIVATION path also failed; it changed
no files or inputs and launched no scientific worker.

validation_receipt_v2 SHA256:
0fcc29e0d58407506d15c62910b4a65cca296cdc253c1eac9c92ca453a5f632f.
selected_auxiliary_tangent_zero_v2 packed/raw SHA256:
c89835068e462a9259355ae253cbe54b358107ba545a8d3c35e21b50e935768a /
10c78bf99463e1ea53a2a64508e9d689e4641288b7df0a9188b6ce3ff0b9b9bd.

Native primary/replay/annihilator2/gate2 times7.671084/7.970699/4.678000/
.289420s. Their memory sample counts5/5/3/1 and maxima124006400/147386368/
64147456/401408B are observations, NOT process peaks. Failed gate1 has one
405504B startup sample and no completed RESULT. All600s/8GiB sampled/
350MiB/16MiB bounds held.13 source copies; preparation49 and continuation70
bindings, original validation57 and V2validation75. Pre-report packet152451B.

Current delegatedE4 preservation checks and external before/index/after seals
must be inspected in auxiliary-tangent-source-kernel-v1-2026-10-24. They must
preserve all33771 older blobs, state113/34of39, custodyexit2/sevenNOTPASS,
and the original failed verifier. A successful custody check of the failure
does not make its scientific gatePASS. No remote action authorized.

TrackA gains a genuine model-specific structural zero and avoids an
unnecessary new tensor/contact direction. TrackB gains a corroborated raw/
plane port proof and records the real nonzero-assumption verifier error.
Scientific inputs, data, software and AI authorship are shared; no independent
scientist or proof-assistant verification is claimed. TrackC remains voluntary.

Next derive the proper ordinary h*antighost*x support before selecting new
contact coefficients. Ordinary ghost-vector and auxiliary ghost vertices can
carry distinct g3*xi andg2*xi2 orders and must be audited separately. Also
check positive-v affine/evaluation companions with the actual source/primitive
transports; do not transfer the dimension-zero result without proof. Only
then test a complete common h-dependent ordinary/source finite family. The
six selected VHR1 fermion projections are retained but do not settle that
question. Whole investigationACTIVE/incomplete; E5/A5 and physicalGUT open.
