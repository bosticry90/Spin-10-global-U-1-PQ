from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['words','proper_pairings','source_linear_rows','source_cubic_rows','source_cubic_grades','source_cubic_one_port_graph_has_bridge','universal_phase','dimension_angular_unit','dimension_angular_derivative','heat_edges','heat_length','coefficient_positions','affine_v_evaluation_qualified','complete_common_source_extension_qualified']:assert P[key]==R[key],key
assert P['universal_phase']=='I' and P['words'] and P['proper_pairings'] and P['source_cubic_rows']>0
for key in ['chi4','chi6']:assert co(s.sympify(P[key])-s.sympify(R[key]))==0
ell=s.log(s.Rational(3,2));assert co(s.sympify(P['chi6'])-s.sympify(P['chi4'])-ell)==0
positions=0;nonzero=0;persector={}
for pb,rb in zip(P['color'],R['color']):
 assert pb['sector']==rb['sector'];count=0
 for p,r in zip(pb['matrices'],rb['matrices']):
  pm,rm=dec(p),dec(r);zero(pm-rm);assert pm.shape==rm.shape and pm.rows==pm.cols
  assert all(co(s.conjugate(z)-z)==0 for z in pm.todok().values())
  positions+=pm.rows*pm.cols;count+=len(pm.todok())
 persector[pb['sector']]=count;nonzero+=count
assert positions==45*sum(n*n for _,n in SECTORS) and nonzero>0
assert P['reverse_order_changed_positions']>0 and R['full_projector_changed_positions']>0 and R['ordinary_trace_phase']!=R['universal_phase']
out={'status':'QUALIFIED_SELECTED_PROPER_JLAMBDA_H_X_KERNEL_AND_RELATIVE_FINITE_MAP','elapsed_after_imports':time.perf_counter()-t,'ordered_words':len(P['words']),'proper_unoriented_graphs':len(P['proper_pairings']),'coefficient_positions':positions,'implicit_zero_positions':positions-nonzero,'nonzero_coefficients':nonzero,'nonzero_by_sector':persector,'universal_phase':P['universal_phase'],'source_linear_rows':P['source_linear_rows'],'source_cubic_rows':P['source_cubic_rows'],'cubic_bridge_exclusion':P['cubic_bridge_audit'],'heat_length':6,'chi6':P['chi6'],'coupling_order':'g10^3*xi','affine_v_evaluation_qualified':False,'common_full_h_source_extension_qualified':False,'full_QAP_measure_phase_E5A5_qualified':False,'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','controls':{'reversed_color_order_changed_positions':P['reverse_order_changed_positions'],'full_instead_of_heavy_projector_changed_positions':R['full_projector_changed_positions'],'ordinary_trace_phase':R['ordinary_trace_phase'],'wrong_heat_length_shift':str(ell)}}
raw=(json.dumps({'coefficient':'i*g10^3*xi/(16*pi^2)*(chi4+log(3/2))*JL_r*h_A*x_k*F[r,k,A]','F':P['color'],'proper_support':P['words'],'scope':out},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_auxiliary_tangent_source.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()})
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
