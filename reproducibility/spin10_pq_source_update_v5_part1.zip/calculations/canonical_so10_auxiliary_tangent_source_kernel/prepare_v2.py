from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='452d5b1e6e310ff878eaa839f51427de36ad7b56'
old=json.loads((HERE/'preparation.json').read_bytes());b=dict(old['input_sha256'])
for p,h in b.items():assert digest(Path(p))==h,p
for p in HERE.iterdir():
 if p.is_file():b[str(p)]=digest(p)
assert json.loads((HERE/'controller_failure.json').read_bytes())['last_role']=='verify'
for n in ['CONTINUATION_V2.md','annihilator_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 b[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'ATS1_V2_PREPARATION','input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('ATS1_V2_FROZEN',len(b),'bindings',flush=True)
