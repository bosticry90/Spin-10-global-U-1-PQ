"""VMA1 exact-once primary quantum assembly and fixed higher-image comparison."""
from data import *
start=begin('primary')
C=packed(CAL/'canonical_so10_vector_contact_breaking/primary_tables.json.gz');F=packed(CAL/'canonical_so10_vector_fermion_edge_breaking/primary_tables.json.gz');V=packed(CAL/'canonical_so10_vector_propagator_breaking/primary_v2_tables.json.gz');CT=packed(CAL/'canonical_so10_coupled_fermion_finite_counterterm/primary_tables.json.gz');out={};counts={};controls={}
for side in ['left','right']:
 out[side]={}
 for power,tag in [('4','g4'),('3','g3_from_lower_source')]:
  families={'contact':fromtable(C[side]) if power=='4' else {},'fermion':fromtable(F[side][power])}
  families.update({n:fromtable(V[side][n][power]) for n in ['ghost','physical','mixed']})
  quantum={}
  for t in families.values():quantum=tablinear(quantum,t,ONE,ONE)
  image={}
  for a,b,m in CT['higher_cBPP_images'][side][tag]:assert (a,b) not in image;image[a,b]=dec(m)
  remainder=tablinear(quantum,image,ONE,ONE);out[side][power]={'quantum':table(quantum),'counterterm':table(image),'remainder':table(remainder)}
  counts[side+power]={'quantum':tabnz(quantum),'counterterm':tabnz(image),'remainder':tabnz(remainder),'families':{n:tabnz(t) for n,t in families.items()}}
  if side=='left':controls[power]={**{'omit_'+n:tabnz(t) for n,t in families.items()},'extra_half_quantum':tabnz(quantum),'omit_counterterm':tabnz(image),'wrong_right_sign':tabnz(quantum)}
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP'];measured=sum((C['partition'][n] for n in ['contact','fermion_edge','ghost_edge','physical_vector_edge','GF_mixed_edge']),[])
assert len(measured)==len(set(measured))==42 and set(measured)==set(support['remaining_internal_ghost_candidates'])
finish('primary',{'method':'complete_five_primary_family_sum_plus_fixed_CFC_image','results':out,'counts':counts,'controls':controls,'measured_witnesses':sorted(measured),'support_partition_keys':sorted(support),'measured_profiles':42,'external_ghost_zero_profiles':20,'new_loop_integrals':0,'counterterm_refitted':False,'quantum_outputs_changed':False},start)
