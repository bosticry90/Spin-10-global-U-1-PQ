"""VMA1 replay sums and independently rebuilt field/source higher images."""
from data import *
start=begin('replay')
C=packed(CAL/'canonical_so10_vector_contact_breaking/replay_tables.json.gz');F=packed(CAL/'canonical_so10_vector_fermion_edge_breaking/replay_tables.json.gz');V=packed(CAL/'canonical_so10_vector_propagator_breaking/replay_v2_tables.json.gz');CT=packed(CAL/'canonical_so10_coupled_fermion_finite_counterterm/replay_tables.json.gz');S=packed(CAL/'canonical_so10_matter_source_primitive/replay_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];f=defaultdict(list)
for a,b,e,v in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,Q(v)))
out={};parts={};homogeneous=0
for side,ts,key in [('left',T,'X_left'),('right',U,'X_right')]:
 out[side]={};parts[side]={};K=list(map(dec,CT['K_'+side]));xx={p:[scale(dec(v),neg(II)) for v in S[key][p]] for p in ['4','3']}
 for power in ['4','3']:
  quantum={}
  # Independent dictionary collection,not primary's fixed-family reduction.
  mats=[fromtable(V[side][n][power]) for n in ['mixed','physical','ghost']]+[fromtable(F[side][power])]
  if power=='4':mats.append(fromtable(C[side]))
  for c in range(45):
   for d in range(45):
    q=Mat(16,16)
    for tab in mats:q=plus(q,tab.get((c,d),Mat(16,16)))
    quantum[c,d]=q
  field={};source={};image={};rem={}
  for a in range(45):
   for b in range(45):
    c=Mat(16,16)
    if power=='4':
     c=minus(mul(K[b],ts[a]),mul(ts[a],K[b]))
     for e,v in f[a,b]:c=plus(c,scale(K[e],prod(II,v)))
     h=minus(mul(ts[b],ts[a]),mul(ts[a],ts[b]))
     for e,v in f[a,b]:h=plus(h,scale(ts[e],prod(II,v)))
     zero(h);homogeneous+=256
    s=minus(mul(xx[power][a],ts[b]),mul(ts[b],xx[power][a]));field[a,b]=c;source[a,b]=s;image[a,b]=plus(c,s);rem[a,b]=plus(quantum[a,b],image[a,b])
  out[side][power]={'quantum':table(quantum),'counterterm':table(image),'remainder':table(rem)};parts[side][power]={'field':table(field),'source':table(source)}
  print('STAGE COMPLETE_REPLAY',side,power,tabnz(rem),flush=True)
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP'];measured=sorted(support['remaining_internal_ghost_candidates'])
finish('replay',{'method':'dictionary_five_replay_families_plus_rebuilt_K_X_graded_image','results':out,'parts':parts,'homogeneous_zpsi_positions_checked':homogeneous,'homogeneous_zpsi_image_remainder':0,'measured_witnesses':measured,'support_partition_keys':sorted(support),'measured_profiles':42,'external_ghost_zero_profiles':20,'new_loop_integrals':0,'counterterm_refitted':False,'quantum_outputs_changed':False},start)
