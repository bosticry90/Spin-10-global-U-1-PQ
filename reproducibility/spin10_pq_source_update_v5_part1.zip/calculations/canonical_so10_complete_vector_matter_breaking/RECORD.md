# VMA1: complete degree-zero vector-matter comparison

Base7e15c7287dabc8081c6b681cf82c526ce43ee8bb/main31861 trackedblobs.
Live AGENTS delegation,state113/34of39 unchanged,wholegoalACTIVE.
VCT1 contact2,VFE1 fermion6,VPR1 ghost12/physical12/mixed10 are independently
measured before this comparison. The MDS1 remaining42 internal-ghost
profiles are therefore ready for exact-once assembly. The separate20
paired external-ghost local zeros are authenticated,not remeasured.

Question:what is the complete quantum cBPP local coefficient plus the
already fixed CFC1 finite field/source counterterm image? Retain bothg4
and lowerg3,all45x45 ghost/B directions,full End16,bothchiralities,familyI3,
both widths/general Yukawa symbols and allzero complements. Domain is
the inherited mass-independent degree-zero Euclidean nonexceptional
one-loop analytic construction,physical externalhats0,background0.
Positive-dimension,background,massive,phase/measure/products,QAP and
physicalchiralprescription limits remain outside this test.

Primary sums all five qualified primary family matrices and directly
imports the independently fixed CFC higher image. Replay sums all five
qualified replay family matrices and recomputes the image from actual
T,K and source X using qualified graded Euler signs. No new loop integral,
matrix fitting,counterterm solving or omitted diagram assignment occurs.
Neither desired cancellation nor CFC target supplied any measured loop.
Keep source and field images separate in replay;compare their sum to
the prior complete table before interpreting the remainder.

Expected:all62 catalogue witnesses covered exactlyonce(42measured+20zero),
coupling-degree inventory retained,all2073600 output positions inclzeros
agree,all12H tensor tests,right=-left.T,antiHermitian totals. Preserve full
quantum,counterterm and remainder tables. Outcome may be exact selected
cancellation or a verified nonzero remainder;both are legitimate bounded
results. A nonzero remainder is not an anomaly verdict:coupled bosonic
source Euler companions and other quantum sectors remain separate.

Controls omit each measured family,source component,field component,
reverse source orientation,extra half and wrong right sign. The known
fermion-edge auxiliary zero and absent contactg3 give insensitive controls,
not a failure to test a nonzero term. Remove-witness control checks support
completeness separately from coefficient cancellation. Verify arbitrary
zpsi's homogeneous higher image is zero rather than fixing it physically.
z10/z126 have no vector image in this selected degree-zero ring;no new
physical finite parameter or normalization baseline is chosen.

Freeze eight sources/copies,allqualified inputs,expected evidence and caps
before sequential primary/replay/gate:600s afterimports each,8GiB sampled
privatecap,350MiB availablecommit launchfloor,16MiB packetcap. Reuse this
goalturn's completed freshE4 with its true0,0,0,0,0,2 exits;add a newbyte
preflight. Preserve all failed/incomplete sources/captures;firstfailure
stops,no silentretry,resourceexpansion or truncatedevidence.

Ceiling:complete selected zero-jet vector-matter comparison,not full finite
Slavnov/QAP/measure/phase,massiveC1,E5A5 or physicalunification. No protected
authority,physicalaction,scheme,benchmark,flavorpause/HB1/C5 changed.
Scalarwarnings,quartetFAIL,custody2sevenNOTPASS and all free constants stay.
Shared physicalinputs,software/charts and AIauthor are not independent
scientists. Preserve main/oldbytes;noagents,branches/worktrees,outreach,
publication,push or statechange. After result assess exact next scientific
dependency rather than assuming globalrestoration from this sector.
