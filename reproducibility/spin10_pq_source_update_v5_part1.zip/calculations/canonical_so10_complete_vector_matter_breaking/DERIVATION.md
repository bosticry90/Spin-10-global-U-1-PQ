# VMA1: independently fixed images meet complete measured quantum inputs

CFC1 already derived odd-left q on the kinetic and vertex densities and
the source Euler term. In the common c^a B^b gamma_bar local ring its
source-free finite vertex image is

    Vfield_ab=-[Ta,K_b]+i sum_d f_ab^d K_d,

and the g4 source companion is

    Vsource_ab=[x_a^[4],T_b], x=-i X.

The lower g3 image is[x_a^[3],T_b]. These signs are authenticated from
CFC's graded density/Fourier proof,not selected after seeing the new sum.
For U=-T.T use the actual separately constructed K_right and X_right,
not a chosen transpose of the resulting target.

The measured quantum expression is the sum of VCT's contact,VFE's fermion
inverse response and VPR's ghost,physical-vector and GFmixed inverse
responses. The five families partition all42 remaining internal-ghost
witnesses. At g3 the contact class is absent and the fully paired fermion
class has its qualified collective zero;these are justified zeros,not
missing calculations. MDS's20 externalghost pairs vanish only as local
degree-zero coefficients in the declared off-shell domain. Add no extra
closed-ghost minus,open-family3 or Nambu half during assembly.

Define R_ab=Lquantum_ab+Vfield_ab+Vsource_ab. This sign agrees with the
already qualified one-jet comparison,Lquantum+countertermimage=0;the new
higher-field equality has not been assumed. If R is nonzero,retain it
exactly. Primary reads the complete fixed CFC image;replay derives its
pieces anew from the fixed K/X matrices before comparing either to R.

A covariant homogeneous fermion normalization sends F->F+zpsiI and
K_b->K_b+zpsi T_b. Its higher image is identically
-[Ta,Tb]+i f_ab^d T_d=0. This is a matrix identity at each a,b and leaves
zpsi unfixed. It does not establish the full homogeneous counterterm
space. The Yukawa invariant source-free scalar corrections contain no
quantum B and no derivative and do not change this selected cBPP image.

No use is made of a bosonic-source matter Euler term that has not yet
been calculated/embedded. No boundary current can remove a nonderivative
zero-jet remainder within the retained local representative. A nonzero
R would therefore be a real remainder of this selected combined image,
but need not be a complete coupled Slavnov obstruction.
