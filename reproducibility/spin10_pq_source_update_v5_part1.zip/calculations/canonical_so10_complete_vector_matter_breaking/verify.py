"""VMA1 full comparison and exact-once support gate;nonzero is not hidden."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for k in ['results','measured_witnesses','support_partition_keys','measured_profiles','external_ghost_zero_profiles','new_loop_integrals','counterterm_refitted','quantum_outputs_changed']:assert P[k]==R[k],k
assert not P['counterterm_refitted'] and not P['quantum_outputs_changed'] and not P['new_loop_integrals'] and R['homogeneous_zpsi_image_remainder']==0 and R['homogeneous_zpsi_positions_checked']==1036800
M=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP'];cand=packed(CAL/'canonical_so10_matter_degreezero_support/replay_tables.json.gz')['targets']['cBPP']['candidate'];zero_w=[]
for pair in M['external_ghost_paired_zero_groups']:assert set(pair)=={'E_P','E_S'};zero_w+=list(pair.values())
assert len(zero_w)==len(set(zero_w))==20 and not set(zero_w)&set(P['measured_witnesses']) and set(cand)==set(zero_w)|set(P['measured_witnesses']) and len(cand)==62
assert M['degree_zero_paired_local_coefficient']=='0';orders=Counter(str(json.loads(w)[5]) for w in P['measured_witnesses']);assert orders=={'4':30,'3':12}
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);f=defaultdict(list)
for a,b,e,v in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,Q(v)))
counts={};compared=0;hc={};controls=P['controls']
for power in ['4','3']:
 counts[power]={};hc[power]={}
 for target in ['quantum','counterterm','remainder']:
  L=fromtable(P['results']['left'][power][target]);RR=fromtable(P['results']['right'][power][target]);counts[power][target]={'left':tabnz(L),'right':tabnz(RR)}
  for c in range(45):
   for d in range(45):
    l=L.get((c,d),Mat(16,16));r=RR.get((c,d),Mat(16,16));zero(plus(r,trans(l)));zero(plus(l,trans(star(l))))
    for v in l.d.values():assert all(k[0]>=0 and k[1]>=0 for k,z in v)
    if target=='remainder':compared+=512
  hc[power][target]=[]
  for u in range(12):
   th=Mat(16,16);fh=defaultdict(lambda:Z)
   for a in range(45):
    v=HF.d.get((a,u),Z)
    if v:
     th=plus(th,scale(T[a],v))
     for b in range(45):
      for e,z in f[a,b]:fh[b,e]=add(fh[b,e],prod(v,z))
   rev=defaultdict(list)
   for (a,b),v in fh.items():
    if v:rev[b].append((a,v))
   var={}
   for (c,d),m in L.items():
    if not m.d:continue
    putm(var,(c,d),minus(mul(th,m),mul(m,th)),neg(II))
    for a,v in rev[c]:putm(var,(a,d),m,neg(v))
    for a,v in rev[d]:putm(var,(c,a),m,neg(v))
   n=tabnz(var);assert n==0,(power,target,u,n);hc[power][target].append(n)
 for side in ['left','right']:
  fld=fromtable(R['parts'][side][power]['field']);src=fromtable(R['parts'][side][power]['source']);image=fromtable(P['results'][side][power]['counterterm']);zero_sum=tabminus(tablinear(fld,src,ONE,ONE),image);assert tabnz(zero_sum)==0
  if side=='left':controls[power].update({'omit_field_image':tabnz(fld),'omit_source_image':tabnz(src),'reverse_source_image':tabnz(src)})
assert controls['3']['omit_contact']==controls['3']['omit_fermion']==controls['3']['omit_field_image']==0
total=sum(v['remainder'][s] for v in counts.values() for s in ['left','right']);disposition='COMPLETE_SELECTED_VECTOR_CANCELLATION' if total==0 else 'NONZERO_FIXED_COUNTERTERM_REMAINDER'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_VECTOR_MATTER_BREAKING_COMPARISON','disposition':disposition,'elapsed_after_imports':time.perf_counter()-start,'measured_profiles':42,'paired_external_ghost_local_zero_profiles':20,'candidate_profiles_accounted_for':62,'measured_orders':dict(orders),'remainder_positions_compared':compared,'quantum_counterterm_remainder_positions_compared':3*compared,'nonzero_counts':counts,'all12_H_tensor_remainders':hc,'right_plus_left_transpose_and_antiHermitian_remainders':0,'controls':controls,'homogeneous_zpsi_positions_checked':R['homogeneous_zpsi_positions_checked'],'homogeneous_zpsi_image_remainder':0,'counterterm_refitted':False,'quantum_outputs_changed':False,'new_loop_integrals':0,'bosonic_source_matter_Euler_completion_included':False,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
