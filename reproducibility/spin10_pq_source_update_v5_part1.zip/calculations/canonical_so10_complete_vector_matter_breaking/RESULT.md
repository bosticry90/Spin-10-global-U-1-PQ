# VMA1: complete selected vector-matter cancellation

The full measured zero-jet cBPP quantum insertion cancels the independently
fixed CFC1 field/source image,at both g4 and lowerg3 and in both chiralities.
No quantum coefficient,counterterm or physical parameter was fitted or
changed. Disposition COMPLETE_SELECTED_VECTOR_CANCELLATION,scientific
acceptance NOT_PERFORMED,state113/authority34of39 unchanged.
Receipt SHA256 d180b00b60fedde92e0703b60bd13455ec02a410669dd839dcd97a7ed55f4aed.

| Coupling order | Quantum nonzero/chirality | Counterterm nonzero/chirality | Sum |
| --- | --- | --- | --- |
| g4 | 28416 | 28416 | 0 |
| lower g3 | 19008 | 19008 | 0 |

All42 internal-ghost candidates are measured:contact2,fermion6,ghost12,
physicalvector12,mixed10. Their30g4 and12g3 witnesses partition the full
internal-ghost inventory exactly once. MDS1's separate20 external-ghost
paired local zeros complete the62-candidate vector catalogue. Those zeros
are inherited off-shell local results,not newly evaluated full amplitudes.

Primary sums five primary families and reads the fixed CFC higher image.
Replay sums five replay families and reconstructs the image from actual
K,T and x=-iX with the qualified graded signs. The image pieces are

    Vfield_ab=-[Ta,K_b]+i f_ab^d K_d,
    Vsource_ab=[x_a,T_b].

They independently reproduce the old complete CFC image. Quantum,
counterterm and remainder agree on6220800 matrix positions including
zeros;the remainder itself is checked on2073600 positions. Right=-left.T,
anti-Hermiticity and all12 H covariance tests hold separately for the
quantum sum,image and remainder at each coupling order. The arbitrary
zpsi homogeneous image is zero across1036800 checked positions;no finite
normalization is physically fixed. Yukawa invariant scalar directions do
not introduce a new vector image here.

Omission controls demonstrate why assembly matters. At g4,removing contact,
fermion,ghost,physical or mixed changes19648,25104,21312,20832 or21696
entries,respectively. Removing the field/source image changes25344/20736.
At g3,ghost/physical/mixed removals change19968/19008/7360;the source
image changes19008. Contactg3 is absent,fermiong3 is a previously qualified
collective zero,and the fieldg3 image is absent:their omission controls
are correctly insensitive. A half factor or wrong right/source sign
changes the tested nonzero totals. Counts are coefficient positions,
not independent experiments or evidence of physical particles.

Commands:python -B calculations/canonical_so10_complete_vector_matter_breaking/
run.py,which freezes and runs primary,replay,verify sequentially. Native0
each;elapsed afterimports12.1710013/16.4447439/59.7945147s. No new loop
integrals,no failed scientific worker in this increment. Caps600s each,
8GiB sampled private,350MiB availablecommit launchfloor,16MiB packet.
Full captures,resources,source copies,input hashes and readiness records
are preserved in the packet and external complete-vector-matter-breaking-
v1-2026-10-23 directory. The preceding VPR failed diagnostic remains intact.
Eight frozen source copies;401/409 preparation/validation bindings. Resource
samples8/10/31,max415563776/356020224/211828736B,not continuous peaks.

Primary packed5e84a158f47df5409fed4660b4f890f766e9d1c5cf7a44b8bc23227ed4949b35,
raw48036aabab95fbdc70560c60188ae7f02854bd75124be82308feb68f87091b56.
Replay packed739804f836560668b4b7a5e0e34efb2f105ecbf3d1eff778bab6e3523b1bb3e5,
raw85207e1fa8d04735f0898d3fb67a634ff48e1138d250d0f669325affcb42c531.

The current-turn fresh E4 command is authenticated reuse with true step
exits0,0,0,0,0,2. Historical custody stays exit2/seven NOTPASS. A new
byte preflight was performed;no historical scientific replay is inferred.

Significance:the previously unmeasured higher-vector contribution now
provides a complete,nontrivial consistency check on the counterterm that
was fixed from one-jet and source data before these loop measurements.
The correct result required all five response families. This is stronger
than fitting a correction after observing the full vector tensor.

Scope remains the one-loop mass-independent,degree-zero,physical-hats0,
zero-background Euclidean nonexceptional local ring. Bosonic-source matter
Euler completion is not included. The separate scalar primitive and
one-jet/source-highest results remain in their qualified scopes. The
next smallest consequential question is their exact coupled embedding,
especially whether existing bosonic finite source corrections introduce
additional matter Euler terms. This result alone does not establish that
embedding or global finite Slavnov restoration.

No full QAP/products/measure/determinantphase,physical chiral prescription,
massive fermion C1,E5/A5 or physicalunification qualification follows.
Both adverse scalar configurations,quartetFAIL,pausedflavor,HB1/C5blocks,
gauge/physical-input gaps and custody remain. Free normalization constants
remain distinct and unfixed. Shared action,data,software,charts and AI
authorship limit agreement to internal computational corroboration.
