from data import *
from itertools import product,combinations
start=begin('replay');g=s.Symbol('g10',real=True);D=s.Symbol('D',positive=True)
@lru_cache(None)
def tr(w):
 if not w:return s.Integer(4)
 return sum((-1)**(j+1)*int(w[0]==w[j])*tr(w[1:j]+w[j+1:]) for j in range(1,len(w)))
def spin(indices,v):
 w=[]
 for k,mu in zip(indices,v):
  w.append(k)
  if mu>=0:w.append(mu)
 return tr(tuple(w))
def canon(w):return min(w[j:]+w[:j] for j in range(len(w)))
def add(out,w,v):
 k=canon(w);out[k]=s.expand(out.get(k,0)+v)
def rows(d):return [[[[k,mu,list(ds)] for k,mu,ds in w],str(s.simplify(v))] for w,v in sorted(d.items()) if s.simplify(v)!=0]
def labels(v):
 for labs in product(range(2),repeat=len(v)):
  count=0
  for initial in [0,1]:
   state=initial;ok=True
   for mu,lab in reversed(list(zip(v,labs))):
    if state!=lab:ok=False;break
    state^=(1+int(mu>=0))%2
   if ok and state==initial:count+=1
  if count:yield labs,s.Rational(count,2)
def fields(v,labs):return tuple(('L' if lab==0 else 'R',mu,()) if mu>=0 else ('U' if lab==0 else 'V',-1,()) for mu,lab in zip(v,labs))
tri={kind:{} for kind in ['pole','fixed','heat','one_path']};raw_nonzero=0
for pos in range(3):
 for mu,j in product(range(4),repeat=2):
  v=tuple(mu if k==pos else -1 for k in range(3));aa=-sum(spin((a,j,a),v) for a in range(4));bb=-sum(spin((a,a,j),v) for a in range(4));nc=sum(spin((j,a,a),v)+spin((a,j,a),v)+spin((a,a,j),v) for a in range(4))
  jets=[aa/D,bb/D,2*nc/(D*(D+2))];tt,qq=s.symbols('tt qq',positive=True);hv=s.integrate(4*tt*s.exp(-6*tt*qq),(qq,0,s.oo))*nc/24;raw_nonzero+=int(hv!=0)
  pp=[s.simplify(x.subs(D,4)) for x in jets];hh=[0,0,hv];ff=[s.simplify(s.diff(x.subs(D,4-2*s.Symbol('eps')),s.Symbol('eps')).subs(s.Symbol('eps'),0)-(hv if n==2 else 0)) for n,x in enumerate(jets)]
  ls=list(labels(v))
  for ii,(lab,weight) in enumerate(ls):
   w=fields(v,lab)
   for kind,values in [('pole',pp),('fixed',ff),('heat',hh)]+([('one_path',pp)] if ii==0 else []):
    A,B,U=values
    for slot,val in [(0,A+B+2*U),(1,B+U)]:
     ww=list(w);k,n,ds=ww[slot];ww[slot]=(k,n,(j,));add(tri[kind],tuple(ww),s.simplify(s.Rational(-1,6)*(-s.I)**3*(-s.I*g))*weight*(-s.I)*val)
vs=set()
for a,b in combinations(range(4),2):
 for mu,nu in product(range(4),repeat=2):vs.add(tuple(mu if k==a else nu if k==b else -1 for k in range(4)))
vs.add((-1,)*4);boxes={kind:{'YYGG':{},'YYYY':{}} for kind in ['pole','fixed','one_path','drop_pair']}
for v in sorted(vs):
 ny=sum(mu<0 for mu in v);ng=4-ny;phase=s.simplify(s.Rational(1,8)*(-s.I)**4*(-s.I*g)**ng)
 parts=[sum(spin(w,v) for a,b in product(range(4),repeat=2) for w in [pattern(a,b)]) for pattern in [lambda a,b:(a,a,b,b),lambda a,b:(a,b,a,b),lambda a,b:(a,b,b,a)]]
 ang=sum(parts)/(D*(D+2));pole=s.simplify(ang.subs(D,4));fixed=s.simplify(s.diff(ang.subs(D,4-2*s.Symbol('eps')),s.Symbol('eps')).subs(s.Symbol('eps'),0));bad=sum(parts[:2])/24
 for ii,(lab,weight) in enumerate(labels(v)):
  tag='YYYY' if ny==4 else 'YYGG';w=fields(v,lab)
  for kind,z in [('pole',pole),('fixed',fixed),('drop_pair',bad)]+([('one_path',pole)] if ii==0 else []):add(boxes[kind][tag],w,phase*weight*z)
finish('replay',{'triangle':{k:rows(v) for k,v in tri.items()},'boxes':{k:{tag:rows(v) for tag,v in row.items()} for k,row in boxes.items()},'raw_ordered_heat_nonzero_components':raw_nonzero,'raw_triangle_positions':144,'raw_box_types':len(vs),'path_source':'INDEPENDENT_CHIRAL_STATE_SELECTOR','full_family_trace':'Tr48_NO_EXTRA3','Gaussian_half_preserved':True},start)
