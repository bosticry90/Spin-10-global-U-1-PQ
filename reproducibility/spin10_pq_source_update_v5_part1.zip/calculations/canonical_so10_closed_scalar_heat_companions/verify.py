from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz');g=s.Symbol('g10',real=True);chi=s.Symbol('chi4',real=True)
def canon(w):return min(w[j:]+w[:j] for j in range(len(w)))
def parse(rows):return {tuple((k,int(mu),tuple(ds)) for k,mu,ds in w):s.sympify(v,locals={'g10':g}) for w,v in rows}
def add(out,w,v):
 w=canon(w);out[w]=s.expand(out.get(w,0)+v)
def clean(d):return {k:s.simplify(v) for k,v in d.items() if s.simplify(v)!=0}
def diff(a,b):return clean({k:a.get(k,0)-b.get(k,0) for k in set(a)|set(b)})
def normalize(d):
 vectors={}
 for w,c in d.items():
  slots=[i for i,t in enumerate(w) if t[2]];assert len(w)==3 and len(slots)==1
  oldslot=slots[0];j=w[oldslot][2][0];base=tuple((k,mu,()) for k,mu,ds in w)
  rotations=[base[q:]+base[:q] for q in range(3)];base=min(rotations);q=rotations.index(base);assert rotations.count(base)==1
  slot=(oldslot-q)%3;vectors.setdefault((base,j),[0,0,0])[slot]+=c
 norm={};current={};rebuild={}
 for (base,j),(a,b,c) in vectors.items():
  current[base,j]=s.simplify(c)
  for slot,z in [(0,a-c),(1,b-c)]:
   w=list(base);k,mu,ds=w[slot];w[slot]=(k,mu,(j,));add(norm,tuple(w),z);add(rebuild,tuple(w),z)
  for slot in range(3):
   w=list(base);k,mu,ds=w[slot];w[slot]=(k,mu,(j,));add(rebuild,tuple(w),c)
 assert not diff(d,clean(rebuild))
 return clean(norm),clean(current)
def rows(d):return [[[[k,mu,list(ds)] for k,mu,ds in w],str(v)] for w,v in sorted(clean(d).items())]
comparisons={}
for group in ['triangle','boxes']:
 for kind in A[group]:
  if group=='triangle':
   x,y=parse(A[group][kind]),parse(B[group][kind]);assert not diff(x,y);comparisons[group+'_'+kind]=len(set(x)|set(y))
  else:
   for tag in ['YYGG','YYYY']:
    x,y=parse(A[group][kind][tag]),parse(B[group][kind][tag]);assert not diff(x,y);comparisons[group+'_'+kind+'_'+tag]=len(set(x)|set(y))
assert A['raw_ordered_heat_nonzero_components']==B['raw_ordered_heat_nonzero_components']
T={k:parse(v) for k,v in A['triangle'].items()};norm={};curr={}
for k,v in T.items():norm[k],curr[k]=normalize(v)
assert not norm['heat']
assert not diff(norm['fixed'],{k:v/2 for k,v in norm['pole'].items()})
# Independent late UV reconstruction from covariant scalar kinetic and quartic.
expected_tri={};expected_boxes={'YYGG':{},'YYYY':{}}
for mu in range(4):
 for w,sign in [((('L',mu,()),('V',-1,(mu,)),('U',-1,())),1),((('L',mu,()),('V',-1,()),('U',-1,(mu,))),-1),((('R',mu,()),('U',-1,(mu,)),('V',-1,())),1),((('R',mu,()),('U',-1,()),('V',-1,(mu,))),-1)]:add(expected_tri,w,sign*s.I*g/2)
 for w,z in [((('L',mu,()),('L',mu,()),('V',-1,()),('U',-1,())),g*g/2),((('R',mu,()),('R',mu,()),('U',-1,()),('V',-1,())),g*g/2),((('L',mu,()),('V',-1,()),('R',mu,()),('U',-1,())),-g*g)]:add(expected_boxes['YYGG'],w,z)
add(expected_boxes['YYYY'],(('U',-1,()),('V',-1,()),('U',-1,()),('V',-1,())),s.Rational(1,2))
exp_norm,exp_J=normalize(expected_tri);assert not diff(norm['pole'],exp_norm)
for tag in ['YYGG','YYYY']:
 pp=parse(A['boxes']['pole'][tag]);ff=parse(A['boxes']['fixed'][tag]);assert not diff(pp,expected_boxes[tag]);assert not diff(ff,{k:s.Rational(5,6)*v for k,v in pp.items()})
controls={'omit_boundary_current':sum(len(v) for v in curr.values()),'omit_cubic_heat_after_IBP':len(norm['heat']),'one_chiral_path_triangle':len(diff(norm['pole'],norm['one_path'])),'wrong_heat6_as4':len(norm['pole']),'extra_scalar_closed_family3':len(norm['pole'])+sum(len(v) for v in expected_boxes.values()),'wrong_right_current_sign':sum(any(t[0]=='R' for t in w) for w in norm['pole'])}
for tag in ['YYGG','YYYY']:
 controls['drop_pair_'+tag]=len(diff(parse(A['boxes']['pole'][tag]),parse(A['boxes']['drop_pair'][tag])))
 controls['one_path_'+tag]=len(diff(parse(A['boxes']['pole'][tag]),parse(A['boxes']['one_path'][tag])))
assert all(v>0 for k,v in controls.items() if k!='omit_cubic_heat_after_IBP')
prior=CAL/'canonical_so10_closed_gauge_heat_companions';quad=CAL/'canonical_so10_closed_fermion_quadratic_heat'
pr=packed(prior/'complete_pure_gauge_relative_member.json.gz');qr=packed(quad/'selected_quadratic_relative_member.json.gz')
c3=chi+s.log(s.Rational(3,2))+s.Rational(1,2);c4=chi+s.log(2)+s.Rational(5,6)
assert s.simplify(s.sympify(qr['finite_scalar_p2_coefficient'],locals={'chi4':chi})-s.Rational(1,2)*(chi-s.Rational(5,12)))==0
artifact={'schema':'CSH1_COMPLETE_SELECTED_PARITY_EVEN_BOSONIC_RELATIVE_MEMBER','common_loop_factor':'1/(16pi^2)','pure_gauge_prior':{'path':str(prior/'complete_pure_gauge_relative_member.json.gz'),'sha256':digest(prior/'complete_pure_gauge_relative_member.json.gz')},'scalar_quadratic_prior':{'path':str(quad/'selected_quadratic_relative_member.json.gz'),'sha256':digest(quad/'selected_quadratic_relative_member.json.gz')},'prior_power_contacts_retained_once':True,'scalar_full_trace':'Tr48_NO_EXTRA3','scalar_current_normalized_pole_density':rows(norm['pole']),'scalar_current_relative_finite_density':rows({k:c3*v for k,v in norm['pole'].items()}),'scalar_quartic_pole_densities':{tag:rows(v) for tag,v in expected_boxes.items()},'scalar_quartic_relative_finite_densities':{tag:rows({k:c4*v for k,v in d.items()}) for tag,d in expected_boxes.items()},'literal_triangle_raw_densities':A['triangle'],'literal_boundary_currents':{kind:[[[[k,mu,list(ds)] for k,mu,ds in base],j,str(v)] for (base,j),v in sorted(J.items())] for kind,J in curr.items()},'all_source_open_background_phase_QAP_or_physical_scheme_proved':False}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'complete_bosonic_relative_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_COMPLETE_SELECTED_PARITY_EVEN_BOSONIC_DIM_HEAT_RELATIVE_FUNCTIONAL','elapsed_after_imports':time.perf_counter()-start,'word_comparisons':comparisons,'raw_triangle_positions':A['raw_triangle_positions'],'raw_box_types':A['raw_box_types'],'normalized_current_pole_words':len(norm['pole']),'quartic_YYGG_pole_words':len(expected_boxes['YYGG']),'quartic_YYYY_pole_words':len(expected_boxes['YYYY']),'raw_heat_nonzero_components':A['raw_ordered_heat_nonzero_components'],'normalized_heat_nonzero_words':0,'literal_boundary_identity_verified':True,'negative_control_changed_words':controls,'degree3_multiplier':str(c3),'degree4_multiplier':str(c4),'all_prior_quadratic_and_pure_gauge_terms_assembled_once':True,'new_model_tensor_contractions':0,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'physical_scheme_adopted':False,'full_finite_chiral_Slavnov_QAP_phase_proved':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
