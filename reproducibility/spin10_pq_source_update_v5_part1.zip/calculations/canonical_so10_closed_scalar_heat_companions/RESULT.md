# CSH1: complete selected parity-even bosonic heat comparison

Qualified within the actual mass-independent closed-fermion, external-hats-zero,
nonexceptional Euclidean domain. ReceiptSHA256
1df019be70c376c21e05fff0e87b4d3c641c1b4561b1f71512e933c27aa1ad0c.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

The new actual ordered loops yield the mixed scalar pole densities

    +ig10/2 Tr48[L_mu(dV U-VdU)+R_mu(dU V-UdV)],
    +g10²/2 Tr48[L_mu² VU+R_mu² UV]-g10² Tr48[L_mu V R_mu U],
    +1/2 Tr48[UVUV],

where U=M,V=Mdagger and actual R=-L.T with symmetric mass matrices. These
match the independent late expansion of1/2Tr(DV DU)+1/2TrUVUV. They were not
assigned from that target. The full Tr48 contains the general family matrices;
no extra family3 or fitted Yukawa point is introduced in scalar words.

The measured finite DIM-minus-positive-free-edge-heat current is its pole
current times chi4+log(3/2)+1/2, modulo an explicit retained boundary current.
Both quartic pole densities are multiplied by chi4+log2+5/6. Combined with
CQH's scalar quadratic and CGH's pure-gauge terms exactly once, the complete
selected parity-even bosonic relative finite functional has the compact form

    Cfinite = sum_(n=2,3,4) c_n S_n,
    c2=chi4-5/12,
    c3=chi4+log(3/2)+1/2,
    c4=chi4+log2+5/6.

Here S_n denotes field-degree n of the actual measured parity-even fermionic
bosonic pole functional

    1/6 Tr48(F_mu_nu F_mu_nu)
    +1/2 Tr48(DV DU)+1/2 Tr48(UVUV),

with inherited gauge/Fourier conventions and common1/(16pi²). All n2/n3/n4
coefficients were obtained by actual numerator/heat calculations; this compact
account is a consequence, not a Ward fit. CQH's power contacts
+g10²Tr48(A_mu A_mu)/(8t)+Tr48(Mdagger M)/(4t) remain by immutable reference.
Their display does not adopt a physical subtraction or finite baseline.

Primary uses explicit4spinor traces and authenticated actual chiral paths;
replay uses metric trace recurrence, an independent chiral-state selector,
independent phase derivation and Schwinger/epsilon moments. The routes share
word assembly conventions, IO and analytic assumptions; they are not independent
scientists or wholly independent software infrastructures. Every compared
nonzero word agrees. Complete raw domains include144triangle numerator
positions and97quartic role/Lorentz types; the factored operator result retains
the full scalar/family dependence without another328field tensor expansion.

A nontrivial boundary qualification is essential. Twelve ordered cubic heat
components are nonzero and produce24nonzero raw density words. Their normalized
integrated functional is zero, but their local density is a total derivative.
The calculation does not silently discard it. For each cyclic3word with one
derivative, coefficients(a0,a1,a2) are replaced by(a0-a2,a1-a2,0), retaining
J_j=a2Tr(w). Literal density=normalized+partialJ is checked for every word.
The fixed current then equals one half of the pole current modulo its stated
boundary; four-point fixed words equal5/6 times their actual pole words.

The normalized current has16nonzero pole words, the two-gauge/two-scalar class
12 and the scalar quartic1. Omitting boundary currents changes32recorded
current slots across the tested variants; omission of the heat contribution
after integration by parts is explicitly insensitive. One chiral path changes
16current/12mixedquartic/1scalarquartic words. Omission of a quartic angular
pairing changes12mixed/1scalar words; wrong heat6 changes16current words;
wrong right-current sign changes8; extra scalar family3 changes29pole words.
These counts are algebraic word/support diagnostics, not physical measurements.

Complete selected bosonic recipe packed/rawSHA256:
41dc7f6e5881c1777d1f996a0c9e6bf966895796ed398804471b87e5d7d2a35a /
4f7648e8cf70463fadeecee19d545bab02d827fe3ca49d534bd1bc79d963d019.
It references CQH scalar2/power and CGH complete pure-gauge recipes exactly
once, and stores raw mixed densities and explicit boundary currents.

P/R/V native0 in2.412940/2.538455/2.127032s afterimports,2samples each,
private sampled maxima48615424/52043776/50769920B, not continuous peaks.
Eight source copies,87/95bindings,pre-reportpacket104793B.600s/8GiBsampled/
350MiBlaunch/16MiB limits respected; no worker/controller failure. Reused
fresh authenticated GAB E4root0steps0/0/0/0/0/2,custody2sevenNOTPASS. External
before/index/after seals must preserve all33141oldblobs and exact new bytes.

This is a complete relative local comparison for the selected parity-even
bosonic closed-fermion domain, not full chiral restoration. The algebraic Ward
image of the measured functional is not an independently integrated quantum
Slavnov insertion. Its negative is a relative counterterm candidate only.
The old actual-minus-covariant-comparator BWF/GWF results remain different
objects; their hypotheses are not silently transferred to physical positive
heat. The physical odd gamma5/Pfaffian phase, actual regulated source products,
nonlinear insertion/QAP/measure, full background domain, massive matching and
Lorentzian/causal/constant-vacuum limits remain unresolved.

The next informative step is actual quantum applicability/phase, with evidence
recovery first. Existing local_gauge_anomaly and matter_anomaly_reuse establish
representation-level facts, not automatically the physical SMA regulated odd
insertion or complete determinant phase. Inspect their exact scopes and the
current CSW first-variation domain before choosing a bounded parity-odd or
source/insertion calculation. Do not repeat the already qualified core anomaly
trace or redeclare the scoped first-variation domain missing. A bridge using
BWF and the new heat comparison must state its reference/phase limitations.

No scientific state, physical scheme, foundation or protected stage changed.
Both adverse scalar configurations, historical quartetFAIL, flavorpause, HB1/C5
blocks, finite freedoms and all historical evidence persist. No agents,
branch/worktree, push, outreach or publication. Shared premises/software and
AI authorship do not establish external physical validation. The complete
Spin(10)xPQ investigation remains ACTIVE/incomplete; E5/A5 remain unqualified.
