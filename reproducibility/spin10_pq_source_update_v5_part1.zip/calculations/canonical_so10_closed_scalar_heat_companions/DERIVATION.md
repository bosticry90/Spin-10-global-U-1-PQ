# CSH1 local ordered words and literal boundary account

Write token(kind,mu,derivatives), kind=L,R,U,V. L/R have one Lorentzindex;
U=M,V=Mdagger are matrices. A word is identified only under cyclic finite
matrix trace, never under commutation or quantum heat-trace cyclicity.

At cubic order, all three quantum vertices are even. The ordered leading
numerator is trace(S(k)V1 S(k)V2 S(k)V3). Its cyclic rotation preserves the
leading polynomial. Sum(2p1+p2) over three cyclic leg starts is zero because
sum p=0. Thus the denominator Taylor and heatlinear parts may be exact
boundary densities. This is proved on actual chiralpath words, not used to
omit them beforehand. The two numerator derivatives have angular1/D;
the denominator derivative has1/D(D+2). After D=4-2epsilon and finite part,
compare the normalized fixed tensor to the normalized pole tensor. Four-point
angular1/[D(D+2)] is uniform but both actual paths and all pairings remain.

For a canonical undifferentiated cyclic baseword w with one derivativej,
let a0,a1,a2 be its three slotcoefficients. Then
sum a_s Tr(w with derivative on s) equals
(a0-a2)Tr(dw0 w1 w2)+(a1-a2)Tr(w0 dw1 w2)+partial_j[a2 Tr(w)].
Store the boundary current and check reconstruction exactly. The selected
3words have no periodic cyclicbase ambiguity (oneL/R and distinctU/V).
Schwartz boundary integration is allowed only in the stipulated domain.

Reference UV current for late comparison has coefficient+ig/2 times
Tr[L_mu(dV U-VdU)+R_mu(dU V-UdV)]. The quarticUV has
+g²/2Tr[L_mu²VU+R_mu²UV]-g²Tr[L_mu V R_mu U]+1/2TrUVUV.
These values follow the existing scalar pole and covariance; their match is
an independent normalization check of the new actual traceword calculation.

chi4 and the heat6/heat8 logarithmic shifts remain symbolic and fixed by the
actual relative scalar bubble plus CGH positive radial proof. No selected
finite normalization parameter is solved from the desired compatibility.
