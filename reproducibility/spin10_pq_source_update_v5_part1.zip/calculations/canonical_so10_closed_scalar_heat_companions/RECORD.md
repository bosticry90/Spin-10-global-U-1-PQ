# CSH1: complete mixed scalar closed-fermion positive-heat companions

Question: do independently measured2Y+g,2Y+2g and4Y rawDIM-minus-edgeheat
terms share the CGH degree multipliers, and together with CQH/CGH form the
complete mass-independent parity-even bosonic relative local functional?
Baseaa915c84cb342f74abd6385fd52d02bc80d83192/main33141oldblobs,state113/34of39,
wholegoal ACTIVE/incomplete. Do not infer mixed coefficients from covariance.

Actual SMA PPbar numerator, physicalspin4, Gaussianhalf, two chiral paths,
external hats0, general symmetric M(x)=Y10tensorb10+Y126tensorb126. FullTr48,
no additional family3 in M words. Generalbilateral L/R charge notation only;
actual restriction R=-L.T,M.T=M,Mdagger.T=Mdagger. Reuse paired SYR path algebra
as primary data, derive paths independently in replay. No physical mass,
flavor point, source action, scheme, chi4/b0/kappa/zeta baseline adopted.

n3momentum route k,k-p1,k-p1-p2, one barredvector/2scalar; use numerator
Taylor Araw/ D,Braw/D,Uraw/D(D+2), full leading heatlinear at heat6. n4two
vectors/2scalars or4scalars has all three rank4 pairings,heat8. Keep the
actual phases (-1)^n/(2n)*(-i)^n*(-ig)^ng, allowedpathweight1/2. n3=-g/6,
n4twoY2g=-g²/8,n4fourY=+1/8. Momentum to local derivative factor -i.
Primary explicit4spinor trace and actual old path tables; replay metric
recurrence and independent chiral state selector/phase. Derive angular finite
jets and positive heat moments, then compare actual coefficient words.

Cyclic leading-symbol sums can be total derivatives, not literalzero
polynomials. Keep complete derivative placement; normalize modulo a specified
boundary current by eliminating derivative on the last slot of each cyclic
undifferentiated3word. Verify density=normalized+partialJ literally for all
words. Compare heat image, finite/pole ratio and every source-free coefficient
only after preserving J. Boundary omission control can be sensitive even if
integrated Schwartz functional is unchanged. No QAP is supplied by this algebra.

Late checks against independently constructed covariant scalar pole density
1/2Tr(DV DU)+1/2TrUVUV test normalization; do not use it to assign loops.
DU=partialU-ig(RU-UL),DV=partialV-ig(LV-VR). Use actual phases and zero
complements. Reuse CGH radial log shifts and CQH scalar2 with their exact
receipts; no old loop replay. An agreement allows exact-once selected complete
parity-even bosonic rawDIM-heat comparison, including prior power contacts.
Mixedsource/openfermion/background/phase and quantum insertion applicability
remain separate. Old BWF/GWF actual-minus-covariant comparator is not equated
with rawDIM-minus-positiveheat. No counterterm is fitted to remove a breaking.

Controls wrongpath/half/family orientation, omitted pairing/heatlength or
boundary, prematureD4. Record actual insensitivities. Freeze8sources/copies
and inputs before P/R/V600s eachafterimports,8GiBsampled/350MiBlaunch/16MiBpacket.
Native observed sequential captures, failstop, preserve failures/versionrepairs.
FreshE4 GABauthenticatedroot0steps0/0/0/0/0/2,custody2sevenNOTPASS. Validate
before localcommit, before/index/afterseals preserve33141oldblobs.

Possible outcomes qualified relative family, scoped mismatch, underdefinition
or bounded incomplete. Ceiling selected complete mass-independent parity-even
bosonic relative local comparison under nonexceptional Euclidean assumptions.
No complete physicalchiralregulator,Slavnov/QAP/source/measure/phase equivalence,
multipleproduct/Lorentzian/causal/constantvacuum construction, massive matterC1,
E5/A5 or GUT. All state/protectedstage/physical failures remain, scalarbenchmarks
not quantumcontrolled. Shared assumptions/action/data/SymPy/AIauthor limit
independence. No agents/branch/worktree/push/outreach/publication or foundation
adoption. Ordinary research delegated; no routine approval or old rebindings.
