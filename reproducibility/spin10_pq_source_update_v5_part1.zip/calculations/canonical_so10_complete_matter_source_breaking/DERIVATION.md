# CMS1 source pairing and bosonic-current reduction

For qhat=0, the actual two mixed Ward blocks give the PP numerator
i[bar k Atilde hat r^2-hat k^2 A bar r]. Since hat k=hat r and
bar k Atilde=A bar k, this equals i hat k^2 A bar q. At degree0
in ordinary external jets it is0. Both BB and BL source-edge kernels
therefore acquire an extra external q and are UV convergent after pairing.
There is no inverse external momentum in the local polynomial target.
The off-shell finite remainder is proportional to h=-2epsilon. This
does not declare an arbitrary finite source amplitude0 or discard endpoint
terms before forming the complete insertion.

Use normalized plane fields with unit C-a covariance and generators T_a.
V[r,a,c] is the measured ordinary ghost vertex after internal momentum
assignment (antighost jet minus vector jet), stripping g. H[r,a,c] is the
actual auxiliary ghost coefficient stripping xi. Its Euclidean vertex is
i xi H; ordinary Euclidean derivative coefficients are+i g k V at the
first ghost vertex and-i g k V at the second. Source->E fermion momentum
k implies source ghost -k,E ghost+k and boson from first->second vertex-k.
Thus BL(-k)=+k/k^2 and LB(-k)=-k/k^2. Derive their signs before integration.

The inherited metric lift contracts both bosonic ends over D indices.
After dividing longitudinal numerators by their denominators, BB gives W,
BL/LB the stated signs and LL0. The loop kernel reduces to the same hatted
three-denominator moment as QSI1; no trace is prematurely frozen at4.
The hatted integral is finite-1/2 in16pi^2 units. A barred bosonic
contraction would instead carry evanescent rank ratios and change the
finite answer; it is a diagnostic, not the inherited prescription.
The hatted radial numerator is part of that angular average: ratios for
one and two barred factors are 4/(D+2) and 24/((D+2)(D+4)), giving2/3
and1/2 at D=4, rather than ratios for an unweighted scalar integral.

Let J_Vr=sum V[r,a,c] a_a C_c and J_Hr=sum H[r,a,c] a_a C_c be even
ghost bilinear currents. The oriented bosonic Schur complement gives the
effective Lorentzian quartic density

 H_exchange = (g^2/2) sum_rs W_rs J_Vr J_Vs
              -g xi sum_r J_Vr J_Hr.

Products are exterior products of the underlying odd ghosts, not products
of commuting coefficients. This formula is only the tree exchange inside
the specified one-loop graph. It does not replace the action by a new
effective physical potential or drop a determinant. Source bridges and
other valences are excluded by IBS1's complete1PI inventory.

Primary feeds the canonical aaCC coefficients of this density into the
independently normalized QSI1 commutator insertion map. Replay directly
obtains, for each external canonical pair c<d, color coefficients

 cycle_BB = +(1/2) sum_rsab W_rs V[r,a,c] V[s,b,d] [T_a,T_b],
 cycle_BL = -(xi/2) sum_rab
              (V[r,a,c] H[r,b,d]+H[r,a,c] V[r,b,d]) [T_a,T_b].

These candidate coefficients must be calculated from the cumulant and
radial moment before the routes compare. The two mixed assignments are
separate. Keep family identity only and source right action -T^T.
Add QSI1 measured bare quartic contribution exactly once. Do not solve
for an unknown normalization from a preferred total or assert that a
nonzero component is an anomaly. The complete tested result remains a
bare formal KccP breaking, not the entire Slavnov functional.
