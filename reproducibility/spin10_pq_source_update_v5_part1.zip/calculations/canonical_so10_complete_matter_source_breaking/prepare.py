"""CMS1 immutable source freeze and restricted V/H/Lie input extraction."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-matter-source-breaking-v1-2026-10-23');BASE='3bd925a711cd9a564ce16dd5edf46f895cd0eb62'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));bind={}
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
def add(p,want=None):
 p=p.resolve();h=digest(p)
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V519.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(PK/'export_a10_e5_antighost_vector.py')
for n in ['frozen_a10_e1_fermion/replay.json','frozen_a10_physical_reconciliation/full_primary.json','frozen_a10_physical_reconciliation/full_replay.json']:add(PK/n)
deps={
 'canonical_so10_sterile_matter_action':(['ACTION_V1.md','primary.py','validation_receipt.json'],'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_sterile_massive_propagator':(['RESULT.md','validation_receipt.json'],'53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c'),
 'canonical_so10_yukawa_carrier_transport':(['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b'),
 'canonical_so10_matter_vector_source_pole':(['replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'d73871d191316b7582b8d6322367481a36a7ccbfd425fc006ebe149f72592fa2'),
 'canonical_so10_matter_auxiliary_source_pole':(['primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'3184454449bab57749e1b5ea0add1ac8ef6a38f4542392ecafbd6a9c88b4ccb4'),
 'canonical_so10_matter_breaking_support':(['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'ed1596f57675dd7dfc94c10854c6bdd00184157bf875e4821a28b0bca046243f'),
 'canonical_so10_quartic_ghost_source_insertion':(['RECORD.md','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'2e8d4600a9f30e73ca720edd70677b16b0fa92d53bc95882c9a6370039ec9ee4'),
 'canonical_so10_yukawa_finite_vertex_ward':(['DERIVATION.md','RESULT.md','validation_receipt.json'],'19c30c658e3662845a57026fbeaa0ce9e4a82d779c42eb274b298bcdeb5c20cb'),
 'canonical_so10_dimensional_counterterm_applicability':(['DERIVATION.md','RESULT.md','validation_receipt.json'],'ae66c799ca99f933d30cb466b8cefdd2a75f65635cb6db4f6dd830a8f89e428a'),
 'canonical_so10_dimensional_stokes_primitive':(['DERIVATION.md','RESULT.md','validation_receipt.json'],'c4b4d2f83d87e9575e58be2e8fc73ed48c24f98d58244daee45cfa85539f400f')}
for folder,(names,rh) in deps.items():
 for n in names:add(CAL/folder/n,rh if n=='validation_receipt.json' else None)
vdir=CAL/'canonical_so10_matter_vector_source_pole';hdir=CAL/'canonical_so10_matter_auxiliary_source_pole';qdir=CAL/'canonical_so10_quartic_ghost_source_insertion'
for folder,names in [(vdir,['replay_tables.json.gz']),(hdir,['primary_tables.json.gz','replay_tables.json.gz']),(qdir,['primary_tables.json.gz','replay_tables.json.gz'])]:
 old=read(folder/'validation_preparation.json')['input_sha256']
 for n in names:assert digest(folder/n)==old[str((folder/n).resolve())]
fields={'V_plane':packed(vdir/'replay_tables.json.gz')['plane_vertex'],'H_plane':packed(hdir/'replay_tables.json.gz')['plane_H_LaC'],'plane_f':packed(hdir/'replay_tables.json.gz')['plane_f'],'raw_ghost_Green':packed(hdir/'primary_tables.json.gz')['raw_ghost_Green']}
ex={'reference_fields':fields,'old_source_UV_loop_targets_excluded':True,'source_sha256':{str(p):digest(p) for p in [vdir/'replay_tables.json.gz',hdir/'primary_tables.json.gz',hdir/'replay_tables.json.gz']}}
with (HERE/'qualified_reference_inputs.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(ex,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
add(HERE/'qualified_reference_inputs.json.gz')
source=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-breaking-support-v1-2026-10-22')
for n in ['readiness.jsonl','readiness_stderr.txt','postcommit_seal.json']:add(source/n)
for d in ['cd7c60f9-60ac-40e2-ad7b-f76925b47a3f','c3dc08cd-3864-4f1d-87e0-52d7ee3c1554']:add(Path('C:/Users/psboy/.codex/attachments')/d/'Pasted text.txt')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31329
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'CMS1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
for n in ['readiness.jsonl','readiness_stderr.txt']:
 with (CONTROL/n).open('xb') as f:f.write((source/n).read_bytes())
with (CONTROL/'readiness_reuse.json').open('xb') as f:f.write((json.dumps({'fresh_readiness_execution_here':False,'source_was_fresh_in_this_logical_goal_turn':True,'source_sha256':{str(source/n):digest(source/n) for n in ['readiness.jsonl','readiness_stderr.txt']},'expensive_historical_science_replayed':False},sort_keys=True)+'\n').encode())
print('CMS1_FROZEN',len(bind),'bindings',flush=True)
