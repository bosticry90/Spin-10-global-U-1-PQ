# CMS1: complete selected KccP finite matter-breaking component

Question: after QSI1's measured nonzero quartic family, what is the complete
one-loop bare local KccP breaking including every IBS1 candidate? Base
3bd925a711cd9a564ce16dd5edf46f895cd0eb62/main31329 tracked blobs.
Whole investigation active/incomplete. IBS1 and QSI1 are verified progress,
not completion or an automatic stopping point.

The complete32 typed candidates divide into12 fermion-edge insertions,
4 quartic-ghost insertion supports and16 two-ghost-vertex cycles. Prove
the first group vanishes collectively in this target, reuse the qualified
measured quartic family and independently calculate both BB and BL/LB
cycles. Then assemble each coupling order exactly once. No unknown term
is assigned to cancel QSI1; zero,nonzero or mismatch are valid outcomes.
This is a full selected KccP component, not full Slavnov restoration,QAP,
renormalized products/measure,phase,massive matching or E5/A5 promotion.

Freeze current AGENTS/CHARTER/state113/V519/local/solo rules; IBS1 complete
typed witnesses/receipt; QSI1 measured paired tensors and phase/Nambu proof;
SMA1/SMP1 action/source/free inverse; YVF1 exact free insertion identity;
actual normalized ordinary ghost V and auxiliary H tensors from qualified
MVS1/MAS1, with original input hashes; actual YCT generators and H projector.
Old source UV loop targets are excluded by a restricted field extraction.
Both g^3,g^4 and all source chiralities/zero complements remain formal.

The Lorentz question is resolved by EXISTING qualified bosonic metric
contracts: dimensional_counterterm_applicability and dimensional_stokes_
primitive. They continue every bosonic metric contraction and vector
multiplicity to D, retaining internal Lorentz traces before the epsilon
jet. Their classical lift is not a complete quantum-trace theorem. Here
the additional loop applicability is demonstrated only for this explicit
off-shell local Feynman family. This is the inherited formal comparison
domain, not a newly adopted physical scheme. A fermion current projects its
own gauge end barred; both ends in these cycles are bosonic and stay full D.
Thus k_mu G_BB^mu,nu k_nu=W, and the mixed contraction is+/-1 after routing.
Do not replace their full k^2 by bar k^2 or add new physical polarizations.

Source-fermion edge group: physical external E ghost qhat0 gives
S(k)E S(r)|PP=i hatk^2 A barslash(q)/(k^2 r^2). Source KccP local
ordinary-jet budget is0. The remaining q factor lowers the UV degree below
zero; the evanescent convergent remainder vanishes in the stated
nonexceptional Euclidean domain. Pair E_P/E_S before using that statement;
individual blocks are not0. Compare every one of the12 supported graphs
to its partner rather than deleting a named topology by analogy.

New cycle calculation: one ordinary B-a-C effective vertex V, one H=L-a-C
vertex or two V's, source KcP and E on the external physical fermion.
Both ghost Wick contractions, ordinary derivative placements, both mixed
propagator orientations and external ghost antisymmetry are mandatory.
G_BB has W=eta_H PH+xi PM, G_BL=-k/k^2,G_LB=+k/k^2,LL0. Preserve actual
coupling degrees: V carries g,H carries xi but no additional g. Use the
QSI1 action insertion i*gE, not the earlier current convention.

Primary: prove the12 zero classes by explicit barred spin matrices and
exact canonical pairing; integrate the bosonic tree exchange at fixed loop
momentum via a Schur quadratic form in even ghost bilinear currents.
Use the actual Lorentz-full inverse and ghost exterior algebra to construct
its effective quartic. Sew that with the already normalized QSI1 source
kernel, using direct spinor commutators, and add the measured bare family.
Replay: independent word-algebra/jet proof; exact eta-even four-vertex
Berezin cumulant, oriented Fourier/BL signs and Schwinger hatted moment;
direct two-ghost-cycle contractions through qualified scalar Lie constants.
No peer result or desired symmetry cancellation may determine a coefficient.

Acceptance: complete32-class partition,6 paired zero groups, both new
cycle families and their summed g3/g4 left/right tensors for all990 ghost
pairs and16x16 entries including zeros. Test action phase,Nambu/cumulant,
full-D contraction,chart normalization,external ghost antisymmetry and
ordinary source transpose. Controls omit a paired insertion block, one
cycle/mixed orientation,ghost contraction,width or prematurely project
the bosonic Lorentz domain. Report real sensitivity and insensitive
limits; no coefficient fitting or hidden source qK/qS change.

Freeze eight sources/copies with input hashes before sequential workers.
Compile prelaunch;600s after imports each,8GiB sampled private cap,350MiB
launch floor,16MiB package. Authenticate reuse of IBS1 fresh E4 in this
same logical turn. No old scientific replay or per-calculation approval.
Stop at first failure/resource exhaustion, retain full source/capture and
version any correction. No agents,branch/worktree,reset,publication/push.
Authority34/39 unchanged. Flavorpause/HB1C5blocks,physical exclusions/140%
singlet warning,quartetFAIL,custodyexit2/seven NOTPASS and all old evidence
remain. Shared action/data/software/AI author limit scientific independence.

Literature comparator: arXiv2004.14398v2 Sec6.2.2's linear-gauge source
insertion is a later scope/convention anchor, not the nonlinear model
answer. Even a completed component still requires the actual simultaneous
source/counterterm and renormalized-product applicability before acceptance.

Reference intake: the director's two attached fermionic reviews are bound
as supplied commentary, not new scientific receipts. Their insistence on
finite source restoration, real regulator applicability and preservation
of the two distinct adverse scalar benchmarks is retained. Their older
unmeasured-source UV statements are superseded only by the actual MVS1/
MAS1 receipts, not by prose. CMS1 extends the finite insertion calculation;
it does not authorize a massive numerical neutrino fit or reinterpret the
relative bosonic functional as physical quartic input. Shared software,
inputs and AI authorship limit the corroboration. No new literature claim
is needed to derive this bounded algebraic result; the comparator is the
previously reviewed reference, not an adopted nonlinear-gauge theorem.
