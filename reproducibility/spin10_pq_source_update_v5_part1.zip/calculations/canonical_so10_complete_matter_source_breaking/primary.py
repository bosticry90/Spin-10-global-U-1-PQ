"""CMS1 exact source pairing and oriented bosonic Schur/exterior reduction."""
from data import *
from collections import defaultdict
from functools import lru_cache
from itertools import combinations,permutations
start=begin('primary')
def z(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
ib=packed(CAL/'canonical_so10_matter_breaking_support/primary_tables.json.gz')
groups={'fermion_edge':[],'quartic':[],'BB':[],'BL':[]};paired=defaultdict(list)
for witness in ib['targets']['KccP']['candidate']:
 w=json.loads(witness);names,ext,edges=w[:3];vv=[ib['vertices'][n] for n in names]
 assert w[3:5]==[0,0]
 if any(v['origin']=='PPB' for v in vv):
  groups['fermion_edge'].append(witness);ei=next(i for i,v in enumerate(vv) if v['origin'].startswith('E_'));origin=vv[ei]['origin'];assert origin in ['E_P','E_S']
  labels=list(names);v=json.loads(labels[ei]);v[0]='E_pair';v[1]=[[k,''] for k,j in v[1]];labels[ei]=json.dumps(v,separators=(',',':'))
  point=lambda p:[p[0],p[1],'' if p[0]==ei else p[2]]
  ex=list(map(point,ext));ed=[[point(a),point(b)] for a,b in edges];options=[]
  for perm in permutations(range(len(labels))):
   if [labels[i] for i in perm]!=sorted(labels):continue
   mp={old:new for new,old in enumerate(perm)};pt=lambda p:[mp[p[0]],p[1],p[2]]
   options.append(json.dumps([sorted(labels),sorted(map(pt,ex)),sorted(sorted([pt(a),pt(b)]) for a,b in ed),*w[3:]],separators=(',',':')))
  paired[min(options)].append(origin)
 elif any(v['origin']=='GF' and len(v['ports'])==4 for v in vv):groups['quartic'].append(witness)
 else:
  bos=[sorted([a[1],b[1]]) for a,b in edges if a[1] in ['B','L'] and b[1] in ['B','L']];assert len(bos)==1
  groups['BB' if bos[0]==['B','B'] else 'BL'].append(witness);assert bos[0] in [['B','B'],['B','L']]
assert all(sorted(v)==['E_P','E_S'] for v in paired.values())
# Actual mixed propagators and both insertion blocks, before Taylor degree0.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gs=[s.kronecker_product(v,pa[2]) for v in g4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
chi=s.prod(gs[:4]);PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL
rv=s.symbols('r0:4');qv=s.symbols('q0:4');hv=s.symbols('h0:2');tL,tR=s.symbols('tL tR')
slash=lambda vs,gg:sum((v*G for v,G in zip(vs,gg)),s.zeros(8))
br=slash(rv,gs[:4]);bq=slash(qv,gs[:4]);hat=slash(hv,gs[4:]);A=tL*PL+tR*PR;At=tL*PR+tR*PL
n1=s.I*(br+bq)*At*hat*hat;n2=-s.I*hat*hat*A*br;sewn=(n1+n2).applyfunc(s.expand);z(sewn-s.I*sum(v*v for v in hv)*A*bq)
local0=sewn.subs(dict.fromkeys(qv,0));z(local0);block_controls=[len(s.SparseMatrix(n.subs(dict.fromkeys(qv,0)).applyfunc(s.expand)).todok()) for n in [n1,n2]];assert min(block_controls)>0
# Four even vertices: exp(-S) has + at fourth order, connected -log has -.
words=[[6,4],[0,8,5,3],[7,1],[9,2]];signs=[]
for perm in permutations(range(4)):
 ww=sum((words[i] for i in perm),[]);signs.append((-1)**sum(ww[i]>ww[j] for i in range(10) for j in range(i+1,10)))
cumulant=-s.Rational(sum(signs),24)
k,w,g,v,u,xi=s.symbols('k w g v u xi',nonzero=True)
GG=s.Matrix([[w/k**2,-1/k],[1/k,0]]);jminus=s.Matrix([-s.I*g*k*v,s.I*xi*u]);jplus=s.Matrix([s.I*g*k*v,s.I*xi*u]);schur=s.expand(-(jminus.T*GG*jplus)[0]/2)
assert s.expand(schur-(-g*g*w*v*v/2+g*xi*v*u))==0
eps,h=s.symbols('epsilon h');regular=h*s.gamma(1+eps)/4;radial=s.diff(regular.subs(h,-2*eps),eps).subs(eps,0);assert radial==-s.Rational(1,2)
# Full-dimensional longitudinal contraction: transverse term+longitudinal.
assert s.expand(1+(w-1)-w)==0
ref=packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields'];V=defaultdict(list);H=defaultdict(list)
for r,a,c,co in ref['V_plane']:V[r].append((a,c,s.sympify(co)))
for r,a,c,co in ref['H_plane']:H[r].append((a,c,s.sympify(co)))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));UH=dec(Y['H_new']);PH=UH*UH.T;W=WH*PH+WM*(s.eye(45)-PH)
@lru_cache(None)
def comm(a,b):return T[a]*T[b]-T[b]*T[a]
def exchange(wmat,mixed=True,orientation='both'):
 out=defaultdict(lambda:s.S.Zero)
 def term(power,a,c,b,d,co):
  if a==b or c==d or not comm(min(a,b),max(a,b)).todok():return
  # a C a C -> a a C C and the two independent exterior reorderings.
  key=(power,min(a,b),max(a,b),min(c,d),max(c,d));out[key]+=-co*(1 if a<b else -1)*(1 if c<d else -1)
 for (r,t),ww in s.SparseMatrix(wmat).todok().items():
  for a,c,x in V[r]:
   for b,d,y in V[t]:term(4,a,c,b,d,ww*x*y/2)
 if mixed:
  for r in range(45):
   for a,c,x in V[r]:
    for b,d,y in H[r]:term(3,a,c,b,d,-WM*x*y)
 return {key:s.expand(co) for key,co in out.items() if s.expand(co)!=0}
eff=exchange(W);wrong=exchange(s.eye(45)/6+W/2)
# Mixed barred contraction carries 2/3 under the SAME hatted radial measure.
wrong={key:(co*s.Rational(2,3) if key[0]==3 else co) for key,co in wrong.items()}
def sew(tab):
 out=defaultdict(lambda:s.zeros(16));one=defaultdict(lambda:s.zeros(16));right=defaultdict(lambda:s.zeros(16))
 for (power,a,b,c,d),co in tab.items():
  out[power,c,d]+=radial*co*comm(a,b);one[power,c,d]+=radial*co*(T[a]*T[b]);right[power,c,d]+=radial*co*(T[a].T*T[b].T-T[b].T*T[a].T)
 return out,one,right
cycle,onepair,cycleR=sew(eff);barred,_,_=sew(wrong);unitwidth,_,_=sew(exchange(s.eye(45)))
pairs=list(combinations(range(45),2));bare=packed(CAL/'canonical_so10_quartic_ghost_source_insertion/primary_tables.json.gz')
def encode_table(tab):return {str(p):[enc(tab.get((p,c,d),s.zeros(16)).applyfunc(s.expand)) for c,d in pairs] for p in [3,4]}
left=encode_table(cycle);right=encode_table(cycleR);total={};totalR={}
for p in ['3','4']:
 total[p]=[enc(dec(a)+dec(b)) for a,b in zip(left[p],bare['left'][p])];totalR[p]=[enc(dec(a)+dec(b)) for a,b in zip(right[p],bare['right'][p])]
finish('primary',{'method':'actual_PS_pairing_oriented_bosonic_Schur_exterior_quartic_direct_commutator','partition':groups,'paired_witnesses':dict(paired),'paired_zero_local_degree':0,'paired_UV_degree_after_q':-1,'omitted_PS_block_nonzero_positions':block_controls,
 'cumulant_unit':str(cumulant),'cumulant_permutation_signs':signs,'hatted_integral_finite':str(radial),'Schur_Euclidean':str(schur),'full_D_BB_contraction':'w','full_D_mixed_contractions':[1,-1],
 'exchange_quartic_projected_to_commutator_support':[[*key,str(co)] for key,co in sorted(eff.items())],'left':left,'right':right,'bare_left':bare['left'],'bare_right':bare['right'],'total_left':total,'total_right':totalR,
 'one_ghost_pairing_left':encode_table(onepair),'wrong_barred_boson_left':encode_table(barred),'wrong_unit_width_left':encode_table(unitwidth),'external_pairs':[list(x) for x in pairs],'coupling_orders':[3,4],
 'full_D_inherited_metric_lift':True,'source_or_physical_scheme_changed':False,'family_extension':'I3_NO_EXTRA3','full_Slavnov_or_QAP_qualified':False},start)
