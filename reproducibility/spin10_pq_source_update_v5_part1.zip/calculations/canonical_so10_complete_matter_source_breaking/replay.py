"""CMS1 Clifford words, Berezin cumulant and direct scalar-Lie ghost cycles."""
from data import *
from collections import defaultdict
from itertools import permutations,combinations
start=begin('replay')
ib=packed(CAL/'canonical_so10_matter_breaking_support/replay_tables.json.gz');groups={k:[] for k in ['fermion_edge','quartic','BB','BL']};paired=defaultdict(list)
for witness in ib['targets']['KccP']['candidate']:
 w=json.loads(witness);vv=[json.loads(n) for n in w[0]];origins=[v[0] for v in vv]
 assert w[3]==w[4]==0
 if 'PPB' in origins:
  kind='fermion_edge';idx=next(i for i,v in enumerate(vv) if v[0].startswith('E_'));origin=vv[idx][0]
  vv[idx][0]='E_pair';vv[idx][1]=[[t,''] for t,j in vv[idx][1]];labels=[json.dumps(v,separators=(',',':')) for v in vv];ex=[list(p) for p in w[1]];ed=[[list(a),list(b)] for a,b in w[2]]
  for p in ex+[pt for edge in ed for pt in edge]:
   if p[0]==idx:p[2]=''
  candidates=[]
  for arrangement in permutations(range(len(vv))):
   if [labels[i] for i in arrangement]!=sorted(labels):continue
   mapping={i:arrangement.index(i) for i in range(len(vv))}
   X=sorted([mapping[a],b,c] for a,b,c in ex);E=sorted(sorted([[mapping[a],b,c] for a,b,c in edge]) for edge in ed)
   candidates.append(json.dumps([sorted(labels),X,E,*w[3:]],separators=(',',':')))
  paired[min(candidates)].append(origin)
 elif any(v[0]=='GF' and len(v[1])==4 for v in vv):kind='quartic'
 else:kind='BL' if any({a[1],b[1]}=={'B','L'} for a,b in w[2]) else 'BB'
 groups[kind].append(witness)
assert all(sorted(v)==['E_P','E_S'] for v in paired.values())
# Clifford basis words, reduced by gamma_i gamma_j+gamma_j gamma_i=2delta_ij.
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def scale(a,A):return {k:s.expand(a*v) for k,v in A.items() if s.expand(a*v)!=0}
def cliff(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():out[a^b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(6) if a&(1<<i))*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
r=s.symbols('r0:4');q=s.symbols('q0:4');ht=s.symbols('h0:2');tl,tr=s.symbols('tL tR');A={0:(tl+tr)/2,15:(tl-tr)/2};At={0:(tl+tr)/2,15:(tr-tl)/2}
br={1<<i:r[i] for i in range(4)};bq={1<<i:q[i] for i in range(4)};hh={1<<(i+4):ht[i] for i in range(2)}
one=scale(s.I,cliff(cliff(cliff(add(br,bq),At),hh),hh));two=scale(-s.I,cliff(cliff(cliff(hh,hh),A),br));sewn=add(one,two)
assert not add(sewn,scale(-s.I*sum(v*v for v in ht),cliff(A,bq)))
zerojet={key:s.expand(co.subs(dict.fromkeys(q,0))) for key,co in sewn.items()};assert not any(zerojet.values())
block_controls=[sum(s.expand(co.subs(dict.fromkeys(q,0)))!=0 for co in t.values()) for t in [one,two]];assert min(block_controls)>0
# Exterior algebra uses ten odd coordinates and unrelated ghost kinetic entries.
def wedge(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(10) if a&(1<<i))*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def word(w,co):
 out={0:co}
 for i in w:out=wedge(out,{1<<i:1})
 return out
F,q11,q12,q21,q22,al,be,v1,v2,B1,B2=s.symbols('F q11 q12 q21 q22 alpha beta v1 v2 B1 B2',nonzero=True)
action={}
for w,co in [([4,5],-F),([6,7],-q11),([6,9],-q12),([8,7],-q21),([8,9],-q22),([6,4],al),([0,8,5,3],be),([7,1],v1*B1),([9,2],v2*B2)]:action=add(action,word(w,co))
term={0:s.S.One};expn=dict(term)
for n in range(1,6):term=scale(-s.Rational(1,n),wedge(term,action));expn=add(expn,term)
internal=sum(1<<i for i in range(4,10));Z={key^internal:co for key,co in expn.items() if key&internal==internal};detQ=q11*q22-q12*q21
assert s.expand(Z[0]-F*detQ)==0 and set(Z)=={0,15}
cumulant=s.simplify(-Z[15]*F*detQ/(Z[0]*al*be*v1*v2*B1*B2))
eps,h=s.symbols('epsilon h');x,y=s.symbols('x y');vol=s.integrate(s.integrate(1,(y,0,1-x)),(x,0,1));reg=h*vol*s.gamma(1+eps)/2;radial=s.diff(reg.subs(h,-2*eps),eps).subs(eps,0)
sourceEprop=s.I*(-1)*(-s.I)
bb=s.simplify(cumulant*sourceEprop*s.I*(-s.I)*radial)
bl=s.simplify(cumulant*sourceEprop*s.I*s.I*(+1)*radial)
lb=s.simplify(cumulant*sourceEprop*s.I*(-s.I)*(-1)*radial)
ref=packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields'];V=defaultdict(list);H=defaultdict(list);fc=defaultdict(list)
for rr,a,c,co in ref['V_plane']:V[rr].append((a,c,s.sympify(co)))
for rr,a,c,co in ref['H_plane']:H[rr].append((a,c,s.sympify(co)))
for a,b,e,co in ref['plane_f']:fc[a,b].append((e,s.sympify(co)))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));UH=dec(Y['H_new']);PH=UH*UH.T;W=WH*PH+WM*(s.eye(45)-PH)
N={name:defaultdict(lambda:s.S.Zero) for name in ['BB','B_Lambda','Lambda_B','wrong_BB','wrong_BL']}
def contract(name,aa,bb_,weight):
 for a,c,v in aa:
  for b,d,u in bb_:
   if c<d:
    for e,f in fc[a,b]:N[name][c,d,e]+=weight*v*u*f
for (rr,ss),ww in s.SparseMatrix(W).todok().items():contract('BB',V[rr],V[ss],bb*ww)
for rr in range(45):
 contract('B_Lambda',V[rr],H[rr],bl*WM);contract('Lambda_B',H[rr],V[rr],lb*WM)
for (rr,ss),ww in s.SparseMatrix(s.eye(45)/6+W/2).todok().items():contract('wrong_BB',V[rr],V[ss],bb*ww)
for rr in range(45):
 contract('wrong_BL',V[rr],H[rr],bl*WM*s.Rational(2,3));contract('wrong_BL',H[rr],V[rr],lb*WM*s.Rational(2,3))
N={name:{key:s.expand(co) for key,co in tab.items() if s.expand(co)!=0} for name,tab in N.items()}
pairs=list(combinations(range(45),2))
def matrix(tab,c,d):return (s.I*sum((tab.get((c,d,e),0)*T[e] for e in range(45)),s.zeros(16))).applyfunc(s.expand)
def matrixR(tab,c,d):return (s.I*sum((tab.get((c,d,e),0)*(-T[e].T) for e in range(45)),s.zeros(16))).applyfunc(s.expand)
def encode_cycles(n3,n4):return {'3':[enc(matrix(n3,c,d)) for c,d in pairs],'4':[enc(matrix(n4,c,d)) for c,d in pairs]}
mixed=add(N['B_Lambda'],N['Lambda_B']);left=encode_cycles(mixed,N['BB']);right={'3':[enc(matrixR(mixed,c,d)) for c,d in pairs],'4':[enc(matrixR(N['BB'],c,d)) for c,d in pairs]}
bare=packed(CAL/'canonical_so10_quartic_ghost_source_insertion/replay_tables.json.gz');total={};totalR={}
for p in ['3','4']:
 total[p]=[enc(dec(a)+dec(b)) for a,b in zip(left[p],bare['left'][p])];totalR[p]=[enc(dec(a)+dec(b)) for a,b in zip(right[p],bare['right'][p])]
# Chart normalization is a separate inherited-input applicability check.
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['C3_plane_to_parent']);FM=dec(read(PK/'frozen_a10_e1_fermion/replay.json')['charts']['blocks']['heavy_dual']['field_embedding']);Ad=s.SparseMatrix.hstack(Q[:,:12],FM);CG=dec(ref['raw_ghost_Green']);chart=s.SparseMatrix(Q*CG*Ad.T-s.eye(45)).applyfunc(s.simplify);assert not chart.todok()
# Hatted radial measure changes barred angular ratios to 4/(D+2),24/((D+2)(D+4)).
D=s.Symbol('D');bar1=s.Rational(4)/(D+2);bar2=24/((D+2)*(D+4));assert bar1.subs(D,4)==s.Rational(2,3) and bar2.subs(D,4)==s.Rational(1,2)
finish('replay',{'method':'Clifford_word_pairing_Berezin_cumulant_direct_oriented_ghost_cycles_scalar_Lie','partition':groups,'paired_witnesses':dict(paired),'paired_zero_local_degree':0,'paired_UV_degree_after_q':-1,'omitted_PS_block_nonzero_words':block_controls,
 'cumulant_unit':str(cumulant),'hatted_integral_finite':str(radial),'BB_unit':str(bb),'B_Lambda_unit':str(bl),'Lambda_B_unit':str(lb),'full_D_BB_contraction':'w','full_D_mixed_contractions':[1,-1],'simplex_volume':str(vol),'chart_remainder':'0',
 'Lie_cycles':{name:[[*key,str(co)] for key,co in sorted(tab.items())] for name,tab in N.items()},'left':left,'right':right,'bare_left':bare['left'],'bare_right':bare['right'],'total_left':total,'total_right':totalR,
 'drop_B_Lambda_left':encode_cycles(N['Lambda_B'],N['BB']),'drop_Lambda_B_left':encode_cycles(N['B_Lambda'],N['BB']),'wrong_barred_boson_left':encode_cycles(N['wrong_BL'],N['wrong_BB']),
 'external_pairs':[list(p) for p in pairs],'coupling_orders':[3,4],'full_D_inherited_metric_lift':True,'source_or_physical_scheme_changed':False,'family_extension':'I3_NO_EXTRA3','full_Slavnov_or_QAP_qualified':False},start)
