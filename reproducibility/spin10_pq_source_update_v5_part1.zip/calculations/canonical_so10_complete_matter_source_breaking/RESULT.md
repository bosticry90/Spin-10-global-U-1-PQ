# CMS1: the complete selected bare KccP breaking is nonzero

Qualified within the frozen mass-independent one-loop Euclidean local
insertion domain. Native primary, replay and independent gate all returned0.
Receipt SHA256:
`c6eee8c9655d4acc68ffdc7f3e729a8541b2a4d1091fa3ef59c58334ffd6eb6a`.
No scientific promotion: state113, authority34/39 and E5/A5 unchanged.

## Complete selected component

Every one of IBS1's32 candidate supports is accounted for exactly once:

| Supports | Treatment |
| --- | --- |
|12 source-to-matter fermion-edge insertions|Six exact E_P/E_S pairs; local coefficient zero|
|4 bare quartic-ghost supports|Reuse QSI1's qualified measured tensors|
|8 two-ordinary-ghost-vertex BB cycles|New full-D calculation, order g10^4|
|8 mixed ordinary/auxiliary ghost cycles|Both BL/LB orientations, order g10^3|

For all990 external ghost pairs and16x16 internal spinor matrices, the two
routes agree, including the implicit zero complement and both source
chiralities. The gate compared3,041,280 coefficient positions across the
cycle, bare and total tensors and checked1,013,760 exact-once assembly
positions. These counts are algebraic positions, not physical particles or
independent experiments.

| Order | Bare quartic, each chirality | New cycles, each chirality | Complete sum, each chirality |
| --- | ---: | ---: | ---: |
|g10^3|7,424|8,832|8,768|
|g10^4|1,560|10,368|10,368|

The common loop factor is1/(16pi^2); the family extension is the identityI3
without an extra3 or open-line half. Tables retain symbolic eta_H and xi,
both coupling orders, actual generator matrices and right source action.
The right coefficient is minus the transpose of the left coefficient.

The new cycles, before adding QSI1, are

`BB_cd = (1/2) sum_rsab W_rs V[r,a,c] V[s,b,d] [T_a,T_b]`,

`BL_cd = -(xi/2) sum_rab (V[r,a,c] H[r,b,d]+H[r,a,c] V[r,b,d]) [T_a,T_b]`,

for c<d, with `W=eta_H PH+xi PM`. V and H are authenticated actual action
vertices, not values inferred from a desired Slavnov cancellation. Their
restricted input extraction excludes the old source UV loop answers.

## What makes the result nontrivial

The source-edge zero is collective: actual mixed free propagators and the
two insertion blocks give `i hatk^2 A barslash(q)/(k^2 r^2)`. Pairing removes
the ordinary degree-zero local target. The extra physical q improves its
UV degree to-1, so the evanescent convergent remainder vanishes in the
nonexceptional off-shell domain. Neither individual block vanishes.

Both bosonic endpoints obey the already qualified metric-natural dimensional
lift. Their longitudinal contraction gives W, not a barred four-dimensional
angular factor. The extra hatted radial numerator matters even for the
diagnostic: its barred ratios are4/(D+2) and24/((D+2)(D+4)). The primary
uses an oriented bosonic Schur complement followed by exterior quartic
sewing. Replay uses a ten-coordinate exact Berezin cumulant and direct
scalar-Lie contractions, with the independent hatted Schwinger moment-1/2.
Their intermediate algorithms are distinct; action, software and AI author
remain shared.

Omitting one mixed orientation changes9,408 left positions at g10^3.
Dropping a ghost pairing changes8,832/10,368 positions at g10^3/g10^4.
Prematurely barring the bosonic line changes8,832/10,368. Replacing the
width by1 changes10,368 at g10^4 and is correctly insensitive at g10^3;
the unit-width specialization itself agrees. Omitting or duplicating the
measured quartic changes7,424/1,560. Thus a preserved zero or nonzero is
tested with controls sensitive to the relevant omitted term.

The qualitative distinction between noncontributing fermion-edge diagrams
and contributing ghost-connecting vector diagrams has an established
linear-gauge comparator in
[Belusca-Maito et al., section6.2.2](https://arxiv.org/html/2004.14398v2#S6.SS2.SSS2).
Its scalar-free source formulas are not substituted for the nonlinear
Spin(10) calculation or treated as a full applicability theorem here.

## Execution and reference disposition

Primary102.3090696s, replay65.2603091s and gate118.6948996s after imports.
Observed sample counts52/34/60; largest sampled private allocations
151,699,456/104,988,672/124,186,624bytes. These are sampled maxima, not
continuous peaks. All600s,8GiB,350MiB launch-floor and16MiB package bounds
were respected. No frozen CMS1 worker or gate failed. Eight source copies,
68 initial and77 validation bindings are authenticated.

Readiness is authenticated reuse of IBS1's fresh E4 command in this same
logical goal turn; it is not a second command or fresh replay of historical
scientific calculations. Custody exit2 with seven unresolved references
remains NOTPASS. External controls are under
`C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-matter-source-breaking-v1-2026-10-23`.

The director's two supplied reviews are bound as references. Their old
unmeasured-source UV status is superseded only by MVS1/MAS1 receipts. Their
finite-restoration priority and separation of ultraviolet compatibility,
quantum construction and physical viability remain applicable. No numerical
flavor fit or physical finite normalization has been selected.

## Interpretation and next smallest action

This completes a selected bare KccP breaking component, not the complete
finite Slavnov functional. A nonzero component is not an anomaly verdict.
No counterterm exactness or source-algebra closure theorem is claimed by
this calculation. The next useful bounded action is to test the measured
source tensor's actual classical consistency/counterterm map before
claiming removability, and then complete the remaining cPP insertion class.
Full source products, finite quantum QAP, measure/phase, physical chiral
reference, positive-mass matching and simultaneous restoration remain open.

Both scalar adverse results remain: the original eta=.3 bosonic hierarchy
failure and the distinct eta=.0001 singlet ratio1.40004177709. No fermion
rescue is inferred. Flavor remains paused, HB1/C5 blocked, historical
quartet failure preserved, b0/kappa/zeta distinct. No old evidence or state
was changed; no external action is authorized or performed.
