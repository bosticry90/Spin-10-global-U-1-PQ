"""CMS1 independent full-domain tensor and exactly-once coverage gate."""
from data import *
from itertools import combinations
from collections import Counter
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def z(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
def nn(M):return len(s.SparseMatrix(M.applyfunc(s.expand)).todok())
def changed(A,B):return nn((A-B).applyfunc(s.expand))
for obj in [P,R]:
 assert {k:len(v) for k,v in obj['partition'].items()}=={'fermion_edge':12,'quartic':4,'BB':8,'BL':8}
 flat=sum(obj['partition'].values(),[]);assert len(flat)==len(set(flat))==32
 assert len(obj['paired_witnesses'])==6 and all(sorted(v)==['E_P','E_S'] for v in obj['paired_witnesses'].values())
 assert obj['paired_zero_local_degree']==0 and obj['paired_UV_degree_after_q']==-1
 assert obj['external_pairs']==[list(v) for v in combinations(range(45),2)] and obj['coupling_orders']==[3,4]
 assert s.sympify(obj['cumulant_unit'])==1 and s.sympify(obj['hatted_integral_finite'])==-s.Rational(1,2)
 assert obj['full_D_BB_contraction']=='w' and obj['full_D_mixed_contractions']==[1,-1]
 assert obj['full_D_inherited_metric_lift'] and not obj['source_or_physical_scheme_changed'] and not obj['full_Slavnov_or_QAP_qualified'] and obj['family_extension']=='I3_NO_EXTRA3'
for name in P['partition']:assert sorted(P['partition'][name])==sorted(R['partition'][name])
assert P['paired_witnesses']==R['paired_witnesses']
assert set(P['cumulant_permutation_signs'])=={-1} and len(P['cumulant_permutation_signs'])==24
assert min(P['omitted_PS_block_nonzero_positions'])>0 and min(R['omitted_PS_block_nonzero_words'])>0
assert s.sympify(R['BB_unit'])==s.Rational(1,2) and s.sympify(R['B_Lambda_unit'])==s.sympify(R['Lambda_B_unit'])==-s.Rational(1,2)
assert R['simplex_volume']=='1/2' and R['chart_remainder']=='0'
counts={};controls={};compared=0;assembly=0
for power in ['3','4']:
 cc=Counter();ctrl=Counter()
 for key in ['left','right','bare_left','bare_right','total_left','total_right']:
  assert len(P[key][power])==len(R[key][power])==990
 for i in range(990):
  mats={key:dec(P[key][power][i]) for key in ['left','right','bare_left','bare_right','total_left','total_right']}
  for key,M in mats.items():z(M-dec(R[key][power][i]));compared+=16**2;cc[key]+=nn(M)
  z(mats['right']+mats['left'].T);z(mats['bare_right']+mats['bare_left'].T);z(mats['total_right']+mats['total_left'].T)
  z(mats['total_left']-mats['left']-mats['bare_left']);z(mats['total_right']-mats['right']-mats['bare_right']);assembly+=2*16**2
  assert s.simplify(s.trace(mats['left']))==0 and s.simplify(s.trace(mats['total_left']))==0
  wrongP=dec(P['wrong_barred_boson_left'][power][i]);wrongR=dec(R['wrong_barred_boson_left'][power][i]);z(wrongP-wrongR)
  ctrl['premature_barred_boson']+=changed(mats['left'],wrongP)
  ctrl['drop_one_ghost_pairing']+=changed(mats['left'],dec(P['one_ghost_pairing_left'][power][i]))
  ctrl['replace_width_by_one']+=changed(mats['left'],dec(P['wrong_unit_width_left'][power][i]))
  if power=='4':z((mats['left']-dec(P['wrong_unit_width_left'][power][i])).subs({WH:1,WM:1}))
  for orient in ['B_Lambda','Lambda_B']:ctrl['drop_'+orient]+=changed(mats['left'],dec(R['drop_'+orient+'_left'][power][i]))
  ctrl['omit_measured_quartic']+=changed(mats['total_left'],mats['left'])
  ctrl['double_count_measured_quartic']+=changed(mats['total_left'],mats['left']+2*mats['bare_left'])
 counts[power]=dict(cc);controls[power]=dict(ctrl)
 assert ctrl['premature_barred_boson']>0 and ctrl['drop_one_ghost_pairing']>0 and ctrl['omit_measured_quartic']>0
 if power=='3':assert ctrl['drop_B_Lambda']>0 and ctrl['drop_Lambda_B']>0
 else:assert ctrl['drop_B_Lambda']==ctrl['drop_Lambda_B']==0 and ctrl['replace_width_by_one']>0
# Required input projections are actual tensors, never an old UV answer.
ref=packed(HERE/'qualified_reference_inputs.json.gz');assert ref['old_source_UV_loop_targets_excluded'] and set(ref['reference_fields'])=={'V_plane','H_plane','plane_f','raw_ghost_Green'}
assert len(ref['reference_fields']['V_plane'])==1328 and len(ref['reference_fields']['H_plane'])==2064 and len(ref['reference_fields']['plane_f'])==720
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_BARE_KccP_FINITE_MATTER_BREAKING','elapsed_after_imports':time.perf_counter()-start,'typed_candidates_covered':32,'paired_fermion_edge_supports_zero':12,'paired_zero_groups':6,'measured_quartic_supports_reused':4,'new_two_ghost_cycle_supports':16,'BB_supports':8,'BL_supports':8,'coupling_orders':[3,4],'full_tensor_positions_compared':compared,'exact_once_assembly_positions':assembly,'nonzero_positions':counts,'controls':controls,'actual_D_bosonic_metric_lift_reused':True,'complete_partition_and_zero_complement':True,'source_conjugate_remainders':'0','full_Slavnov_QAP_measure_phase_or_massive_threshold_qualified':False,'counterterm_restoration_not_tested_here':True,'shared_action_software_and_AI_authorship':True,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
