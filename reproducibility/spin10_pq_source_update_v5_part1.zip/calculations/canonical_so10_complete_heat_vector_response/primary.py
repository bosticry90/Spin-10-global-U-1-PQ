"""CHV1 raw rho contraction and separate odd-field/source images."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
relative={p:{} for p in PARTS};pieces={p:{} for p in PARTS};controls={}
for part in PARTS:
 for order in ORDERS:
  relative[part][order]={};pieces[part][order]={}
  for side,ts in [('left',T),('right',U)]:
   vertex,source,opposite,rho,fac=inputs(d,order,part,side);current={}
   for i,b,a,z in rho:current[a,b]=plus(current.get((a,b),ZERO),scale(ts[i],prod(fac,Q(z))))
   field={};src={};bos={};wrong={}
   for a in range(45):
    for b in range(45):
     h=minus(mul(vertex[b],ts[a]),mul(ts[a],vertex[b]))
     for e,z in f[a,b]:h=plus(h,scale(vertex[e],prod(II,z)))
     s=scale(plus(mul(trans(opposite[a]),ts[b]),mul(ts[b],source[a])),neg(II));e=scale(current.get((a,b),ZERO),neg(II))
     if h.d:field[a,b]=h
     if s.d:src[a,b]=s
     if e.d:bos[a,b]=e
     if part=='fixed' and order=='g4' and side=='left':
      q=scale(source[a],II);shortcut=minus(mul(q,ts[b]),mul(ts[b],q));diff=minus(s,shortcut)
      if diff.d:wrong[a,b]=diff
   total=linear((field,ONE),(src,ONE),(bos,ONE));relative[part][order][side]=total;pieces[part][order][side]={n:sparse(v) for n,v in [('field',field),('proper_source',src),('bosonic_source',bos)]}
   if part=='fixed' and side=='left':
    controls[order]={'omit_vertex_field':nz(field),'omit_proper_source':nz(src),'omit_bosonic_source':nz(bos)}
    if order=='g4':
     controls[order]['wrong_nonadjoint_source_shortcut']=nz(wrong);controls[order]['swap_vector_ghost_bosonic_roles']=nz(linear((bos,ONE),({(b,a):m for (a,b),m in bos.items()},Q(-1))))
   print('STAGE',part,order,side,nz(total),flush=True)
dim=quantum(d)
finish('primary',relative,pieces,dim,controls,tick,'raw_transported_rho_times_actual_generators_and_separate_graded_Euler_images')
