"""CHV1 freeze full actual vector/source inputs before response extraction."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_complete_heat_matter_response'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-vector-response-v1-2026-10-23');OLD=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-matter-response-v1-2026-10-23')
BASE='691938ab5c27f868c64716ca6ed4089f10164ff7';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/(name+'.json.gz');add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32606
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','DERIVATION.md','validation_preparation.json']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V552.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for n in ['postcommit_seal.json','before_commit_seal.json','successful_index_gate.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for folder,names in [
 ('canonical_so10_source_vector_finite_transport',['DERIVATION.md','RESULT.md','validation_receipt_v2.json']),
 ('canonical_so10_lower_source_vector_finite',['DERIVATION.md','RESULT.md','validation_receipt_v2.json']),
 ('canonical_so10_complete_vector_matter_breaking',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_matter_degreezero_support',['RESULT.md','validation_receipt.json']),
 ('canonical_so10_coupled_fermion_finite_counterterm',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_matter_source_primitive',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_proper_matter_source_finite',['DERIVATION.md','RESULT.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 q=HERE/(n+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 add(p);add(q)
ref=source('canonical_so10_ghost_triangle_field_insertion','qualified_reference_inputs')['reference_fields']['plane_f']
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables');v=source('canonical_so10_matter_gauge_vertex_finite_color',role+'_tables');s=source('canonical_so10_proper_matter_source_finite',role+'_tables');sv=source('canonical_so10_source_vector_finite_transport',role+'_v2_tables');ls=source('canonical_so10_lower_source_vector_finite',role+'_tables');ct=source('canonical_so10_vector_contact_breaking',role+'_tables');fe=source('canonical_so10_vector_fermion_edge_breaking',role+'_tables');pr=source('canonical_so10_vector_propagator_breaking',role+'_v2_tables')
 assert ls['xi_factored_out_exactly_once'] and ls['matter_overall_factor']=='-I*g10^3*xi/(16*pi^2)'
 gz(HERE/(role+'_inputs.json.gz'),{'Y':{k:y[k] for k in ['Tminus','H_new']},'plane_f':ref,'VFC':v['B'],'PSF':s['source_matrices'],'SVT':{k:sv[k] for k in ['finite_tensors','matter_current_coefficients']},'LSF':{k:ls[k] for k in ['finite_tensors','matter_current_coefficients']},'VCT':{k:ct[k] for k in ['left','right']},'VFE':{k:fe[k] for k in ['left','right']},'VPR':{k:pr[k] for k in ['left','right']}});add(HERE/(role+'_inputs.json.gz'))
cfc=source('canonical_so10_coupled_fermion_finite_counterterm','family_tables');msp=source('canonical_so10_matter_source_primitive','primary_tables');vma=source('canonical_so10_complete_vector_matter_breaking','primary_tables');ps=source('canonical_so10_proper_matter_source_finite','primary_tables');cr=source('canonical_so10_complete_heat_matter_response','primary_inputs')
cfc_receipt=read(CAL/'canonical_so10_coupled_fermion_finite_counterterm/validation_receipt.json');mds=read(CAL/'canonical_so10_matter_degreezero_support/validation_receipt.json')
cfc_ok=cfc_receipt['status']=='QUALIFIED_COUPLED_ONE_JET_MATTER_COUNTERTERM_TEST' and all(v==0 for directions in cfc_receipt['cPP_image_remainders'].values() for slots in directions.values() for v in slots.values())
yy=[v for v in mds['families']['cBPP'] if v['Y_degree']==2]
mds_ok=mds['status']=='QUALIFIED_COMPLETE_DEGREE_ZERO_MATTER_SUPPORT_AND_PAIRED_ZERO_TEST' and mds['class_counts']['cBPP']['candidate']==62 and bool(yy) and all(v['E_external_port']=='c' and any(e in v['vertices'] for e in ['E_P','E_S']) for v in yy) and mds['actual_free_identity_imported_not_independently_rederived_here']
assert cfc_ok and mds_ok
gz(HERE/'validation_control_inputs.json.gz',{'VMA':{'results':vma['results']},'PSF':ps['source_Euler_images'],'CFC_family':cfc['family'],'MSP_X':{k:msp[k] for k in ['X_left','X_right']},'CHM_raw':{k:cr[k] for k in ['KIN','VERT','SRC','RHO']},'CFC_matching_zero_qualified':cfc_ok,'MDS_Y_g2Y2_degreezero_zero_qualified':mds_ok});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'CHV1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('CHV1_FROZEN',len(bind),'bindings',flush=True)
