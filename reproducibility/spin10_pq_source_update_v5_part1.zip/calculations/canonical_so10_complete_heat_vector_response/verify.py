"""CHV1 full response,source orientation and late common-family embedding gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz');d=packed(HERE/'primary_inputs.json.gz')
for k in ['response','pieces','nonzero_counts','negative_controls','orders']:assert P[k]==R[k],k
positions=0;unique_ring=set();embedding={}
for group,orders in P['response'].items():
 for order,sides in orders.items():
  left=untab(sides['left']);right=untab(sides['right']);assert len(sides['left'])==len(sides['right'])==2025;positions+=2*2025*256
  for key in set(left)|set(right):
   l=left.get(key,ZERO);r=right.get(key,ZERO);zero(plus(l,trans(star(l))));zero(plus(r,trans(l)))
   unique_ring.update(l.d.values());unique_ring.update(r.d.values())
assert positions==24883200
for z in unique_ring:
 for (h,x,r,j),co in z:assert h>=0 and x>=0
for order in ORDERS:
 embedding[order]={}
 for side in SIDES:
  get=lambda group:untab(P['response'][group][order][side])
  assert not get('relative_chi4')
  old=late['VMA']['results'][side]['4' if order=='g4' else '3'] if order in ['g4','g3xi'] else None
  dimold=untab(old['quantum']) if old else {};ct=untab(old['counterterm']) if old else {}
  assert table(get('dimensional_fixed'))==table(dimold)
  zero_tables=[linear((get('heat_length_log'),ONE),(get('relative_log'),ONE)),linear((get('heat_total_fixed'),ONE),(get('relative_fixed'),ONE),(get('dimensional_fixed'),Q(-1))),linear((get('dimensional_fixed'),ONE),(ct,ONE))]
  assert all(not t for t in zero_tables)
  corrected=linear((ct,ONE),(get('relative_fixed'),ONE));remainder=linear((get('heat_total_fixed'),ONE),(corrected,ONE));assert not remainder
  embedding[order][side]={'fixed_image':sparse(corrected),'length_log_image':sparse(get('relative_log')),'fixed_remainder_nonzero':nz(remainder),'length_log_remainder_nonzero':0,'chi4_remainder_nonzero':0}
  for part in PARTS:
   pieces=P['pieces'][part][order][side]
   if order.startswith('g2Y'):assert not any(pieces.values())
   else:
    sg='ordinary' if order=='g4' else 'auxiliary';fac=ONE if order=='g4' else Q('xi');expected={(a,b):scale(dec(m),fac) for b,a,m in late['PSF'][sg][part][side]['gauge']}
    assert table(unsparse(pieces['proper_source']))==table(expected)
for name in ['omit_vertex_field','omit_proper_source','omit_bosonic_source','wrong_nonadjoint_source_shortcut','swap_vector_ghost_bosonic_roles']:assert P['negative_controls']['g4'][name]>0
# Existing one-jet family qualification and identical raw parent coefficients.
chm=read(CAL/'canonical_so10_complete_heat_matter_response/validation_receipt.json');assert chm['status']=='QUALIFIED_OPERATOR_DERIVED_COMPLETE_SELECTED_HEAT_MATTER_P_Q_RESPONSE' and chm['chi4_image_zero_without_selecting_chi4']
assert d['VFC']==late['CHM_raw']['VERT'] and d['PSF']==late['CHM_raw']['SRC']
assert late['CFC_matching_zero_qualified'] and late['MDS_Y_g2Y2_degreezero_zero_qualified']
recipe={'definition':'C_heat=C_dim_restore+Crel;unexpanded local coefficient sum','base_field_family':late['CFC_family'],'base_fixed_matter_source_primitive':late['MSP_X'],'relative_onejet_parents':{k:late['CHM_raw'][k] for k in ['KIN','VERT','SRC','RHO']},'relative_vector_bosonic_sources':{key:{part:{'B':d[key]['finite_tensors'][part]['B']} for part in PARTS} for key in ['SVT','LSF']},'coefficients_use_inherited_density_scales_and_phases':'DERIVATION.md and bound CFC/MSP/CHM/SVT/LSF action definitions','selected_vector_images':embedding,'all_selected_onejet_and_vector_remainders_zero':True,'parameters_left_symbolic':['z_psi','z_10','z_126','chi4'],'other_kappa_b0_uR_zeta_not_identified_or_selected':True,'full_source_or_background_functional_image_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_correction_family.json.gz').open('xb') as f:f.write(blob)
for obj in [P,R]:assert not any(obj[k] for k in ['independent_component_heat_integration','quantum_coefficient_fitted','counterterm_read_to_fit_response','free_constant_selected','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_HEAT_VECTOR_RESPONSE_AND_COMMON_ONEJET_VECTOR_CORRECTION_FAMILY','elapsed_after_imports':time.perf_counter()-tick,'response_positions_compared':positions,'all45_vector_and_ghost_directions_zero_complements_match':True,'both_chiralities_reality_right_negative_transpose':True,'general_family_factors_retained':True,'raw_five_family_dimensional_reassembly_matches':True,'relative_chi4_image_zero_without_selecting_chi4':True,'complete_source_Euler_orientation_matches_PSF':True,'same_CHM_onejet_parent_coefficients_retained':True,'common_selected_onejet_vector_correction_family_constructed':True,'all_selected_vector_correction_remainders_zero':True,'nonzero_counts':P['nonzero_counts'],'negative_controls':P['negative_controls'],'correction_family_sha256':digest(HERE/'selected_correction_family.json.gz'),'correction_family_raw_sha256':sha256(raw).hexdigest(),'independent_component_heat_integration':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
