"""CHV1 exact current/tensor IO and independently assembled dimensional input."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
PARTS=['chi4','log3over2','fixed'];ORDERS=['g4','g3xi','g2Y10','g2Y126'];SIDES=['left','right'];ZERO=Mat(16,16)
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('CHV1_PEER_OR_CORRECTION_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_complete_heat_matter_response','canonical_so10_complete_vector_matter_breaking','canonical_so10_coupled_fermion_finite_counterterm','canonical_so10_matter_source_primitive'] and p.name.endswith('.gz'):raise PermissionError('CHV1_OLD_COMBINED_IMAGE_DENIED')
 sys.addaudithook(audit);return tick
def table(tab):return [enc(tab.get((a,b),ZERO)) for a in range(45) for b in range(45)]
def untab(aa):
 assert len(aa)==2025
 return {(a,b):dec(aa[45*a+b]) for a in range(45) for b in range(45) if aa[45*a+b]['entries']}
def sparse(tab):return [[a,b,enc(v)] for (a,b),v in sorted(tab.items()) if v.d]
def unsparse(aa):return {(a,b):dec(m) for a,b,m in aa}
def linear(*terms):
 out={}
 for tab,z in terms:
  for key,m in tab.items():out[key]=plus(out.get(key,ZERO),scale(m,z))
 return {k:m for k,m in out.items() if m.d}
def nz(tab):return sum(len(m.d) for m in tab.values())
def quantum(d):
 out={}
 for side in SIDES:
  out[side]={}
  for order,power in [('g4','4'),('g3xi','3')]:
   raw=[d['VPR'][side][name][power] for name in ['ghost','physical','mixed']]+[d['VFE'][side][power]]
   if power=='4':raw.append(d['VCT'][side])
   out[side][order]=linear(*[(untab(v),ONE) for v in raw])
  out[side]['g2Y10']={};out[side]['g2Y126']={}
 return out
def inputs(d,order,part,side):
 tag={'g4':'gauge','g3xi':None,'g2Y10':'Y10','g2Y126':'Y126'}[order]
 vertex=[scale(dec(m),II) for m in d['VFC'][part][tag][side]] if tag else [ZERO]*45
 have=order in ['g4','g3xi'];sg='ordinary' if order=='g4' else 'auxiliary';other='right' if side=='left' else 'left';fac=Q('xi') if order=='g3xi' else ONE
 this=[scale(dec(m),fac) for m in d['PSF'][sg][part][side]] if have else [ZERO]*45
 opp=[scale(dec(m),fac) for m in d['PSF'][sg][part][other]] if have else [ZERO]*45
 key='SVT' if order=='g4' else 'LSF'
 rho=d[key]['finite_tensors'][part]['B'] if have else []
 return vertex,this,opp,rho,fac
def finish(role,relative,pieces,dim,controls,tick,method):
 response={};counts={}
 for group in ['relative_chi4','relative_log','relative_fixed','dimensional_fixed','heat_length_log','heat_total_fixed']:
  response[group]={};counts[group]={}
  for order in ORDERS:
   response[group][order]={};counts[group][order]={}
   for side in SIDES:
    if group=='dimensional_fixed':v=dim[side][order]
    elif group=='heat_length_log':v=linear((relative['log3over2'][order][side],Q(-1)))
    elif group=='heat_total_fixed':v=linear((dim[side][order],ONE),(relative['fixed'][order][side],Q(-1)))
    else:v=relative[{'relative_chi4':'chi4','relative_log':'log3over2','relative_fixed':'fixed'}[group]][order][side]
    response[group][order][side]=table(v);counts[group][order][side]=nz(v)
 out={'role':role,'method':method,'elapsed_after_imports':time.perf_counter()-tick,'response':response,'pieces':pieces,'nonzero_counts':counts,'negative_controls':controls,'dimensionless_zerojet':True,'orders':ORDERS,'general_family_factors_retained':True,'independent_component_heat_integration':False,'operator_identity_used':'Rheat=Rdim-bSigmaCrel','quantum_coefficient_fitted':False,'counterterm_read_to_fit_response':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
