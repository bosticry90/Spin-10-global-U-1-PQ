"""CHV1 generic endpoint congruence and independently transported current input."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz')
m=sy.Matrix(2,2,sy.symbols('m0:4'));n=sy.Matrix(2,2,sy.symbols('n0:4'));t=sy.Matrix(2,2,sy.symbols('t0:4'));q=sy.I*m;p=sy.I*(m+n.T)
assert (q*t-t*q-p*t+sy.I*(n.T*t+t*m)).applyfunc(sy.expand)==sy.zeros(2)
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t0),Q(-1)) for t0 in T];f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
relative={p:{} for p in PARTS};pieces={p:{} for p in PARTS};controls={}
for part in PARTS:
 for order in ORDERS:
  relative[part][order]={};pieces[part][order]={}
  for side,ts in [('left',T),('right',U)]:
   vertex,source,opposite,rho,fac=inputs(d,order,part,side);have=order in ['g4','g3xi'];key='SVT' if order=='g4' else 'LSF'
   current={(a,b):scale(dec(m),fac) for b,a,m in d[key]['matter_current_coefficients'][part]['B'][side]} if have else {}
   field={};src={};bos={};total={};wrong={}
   for a in range(45):
    qa=scale(source[a],II);pa=scale(plus(source[a],trans(opposite[a])),II)
    for b in range(45):
     pair=minus(mul(vertex[b],ts[a]),mul(ts[a],vertex[b]));Lie=combine([prod(II,z) for e,z in f[a,b]],[vertex[e] for e,z in f[a,b]]) if f[a,b] else ZERO
     h=plus(pair,Lie);special=minus(mul(qa,ts[b]),mul(ts[b],qa));s=minus(special,mul(pa,ts[b]));e=scale(current.get((a,b),ZERO),neg(II));v=plus(plus(h,s),e)
     if h.d:field[a,b]=h
     if s.d:src[a,b]=s
     if e.d:bos[a,b]=e
     if v.d:total[a,b]=v
     if part=='fixed' and order=='g4' and side=='left':
      df=scale(mul(pa,ts[b]),Q(-1))
      if df.d:wrong[a,b]=df
   relative[part][order][side]=total;pieces[part][order][side]={n:sparse(v) for n,v in [('field',field),('proper_source',src),('bosonic_source',bos)]}
   if part=='fixed' and side=='left':
    controls[order]={'omit_vertex_field':nz(field),'omit_proper_source':nz(src),'omit_bosonic_source':nz(bos)}
    if order=='g4':controls[order].update({'wrong_nonadjoint_source_shortcut':nz(wrong),'swap_vector_ghost_bosonic_roles':nz(linear((bos,ONE),({(b,a):m for (a,b),m in bos.items()},Q(-1))))})
   print('STAGE',part,order,side,nz(total),flush=True)
# Independent collection of quantum coefficients in reversed family order.
dim={s:{o:{} for o in ORDERS} for s in SIDES}
for side in SIDES:
 for order,power in [('g4','4'),('g3xi','3')]:
  aa=[d['VFE'][side][power]]+[d['VPR'][side][k][power] for k in ['mixed','physical','ghost']]
  if power=='4':aa.append(d['VCT'][side])
  for index in range(2025):
   v=combine([ONE]*len(aa),[dec(row[index]) for row in aa])
   if v.d:dim[side][order][index//45,index%45]=v
finish('replay',relative,pieces,dim,controls,tick,'generic_nonadjoint_endpoint_identity_and_independently_transported_current_coefficients')
