# HSC1 V2: absent sparse endpoint/slot rows contribute zero

Original primary completed245.11337990000902s and wrote its full authenticated
table. Original replay passed the generic spin-source identity and all actual
tree covariance positions, then exited1 at KeyError322 in slot(): its no-scalar-
slot source call had rr={}, but the contraction accessed rr[x] for every active
scalar column. The no-fermion-endpoint bosonic call has the analogous ar={}
hazard. Neither is a new physical coefficient or a mathematical mismatch.
Original verifier NOT_LAUNCHED; controller FAILED. Preserve all original bytes.

V2 uses .get(index,[]) for all three absent sparse row lookups. An absent
endpoint/slot has the typed zero contraction. All occupied rows, signs, phases,
zero complements, generic/tree tests and final acceptance checks stay unchanged.
The repair changes no physical input or resource bound. Retain the completed
primary after checking its original manifest, table hashes and full capture;
do not rerun its245-second calculation. Only replay and separate gate run.

Freeze this record, replay_v2,verify_v2,prepare_v2,run_v2 and exact copies,
plus original failure/primary evidence before computation. Continuation byte
authentication precedes the unchanged peer/target read-denial hook. Same600s
afterimports,8GiB sampledprivate,350MiB launch floor,32MiB storedpacket. Stop
on any new failure; retain its exact capture and classify it. Qualification and
before/index/after local custody remain mandatory. Authority34/39, all protected
physical/adoption/paused/blocked boundaries and old failures remain unchanged.
