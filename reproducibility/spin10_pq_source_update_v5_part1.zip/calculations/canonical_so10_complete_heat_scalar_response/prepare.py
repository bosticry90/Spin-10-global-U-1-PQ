"""HSC1 freeze complete actual comparison parents and independent bare insertion."""
from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_scalar_source_finite_comparison'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-scalar-response-v1-2026-10-23');OLD=CONTROL.with_name('scalar-source-finite-comparison-v1-2026-10-23')
BASE='ace6e26cc03e3e4f2fb44b97ceb65b50fb1c39b8';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/(name+'.json.gz');add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32796
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','DERIVATION.md','validation_preparation.json']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V557.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
receipts=[('canonical_so10_sterile_matter_action','validation_receipt.json','21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),('canonical_so10_auxiliary_scalar_matter_breaking','validation_receipt.json','3af347d2e00daba90bf69359d5c5acaa94fbf7e54b0591f8504fd5a3af27821c'),('canonical_so10_ordinary_scalar_matter_breaking','validation_receipt_v5.json','529cd63ec58eb22b9763d530a495509912908e87e34215c1601fcdd27023560a'),('canonical_so10_scalar_matter_primitive','validation_receipt.json','0a7cf416cc8777095a9ec879193aad84d77c92a179e338ca8c3147ce0ba10737'),('canonical_so10_matter_source_primitive','validation_receipt.json','c0e178079368b7f841ef0c44d2b76035a289a761dc8d427b4a6a4732119638c2'),('canonical_so10_matter_degreezero_support','validation_receipt.json','e14380e2c763754d4557ba0c12b77e39b3f37668a1115ad2c7f52fc4304c28af')]
for folder,name,h in receipts:
 p=CAL/folder/name;assert digest(p)==h;add(p);add(CAL/folder/'RESULT.md')
for folder,names in [('canonical_so10_sterile_matter_action',['ACTION_V1.md']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_proper_matter_source_finite',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_yukawa_vertex_heat_comparison',['DERIVATION.md','RESULT.md','validation_receipt_v3.json']),('canonical_so10_heat_highest_matter_source',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_scalar_matter_primitive',['DERIVATION.md']),('canonical_so10_matter_source_primitive',['DERIVATION.md'])]:
 for n in names:add(CAL/folder/n)
add(CAL/'canonical_so10_ordinary_scalar_matter_breaking/exact_ring_v4.py')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables');yh=source('canonical_so10_yukawa_vertex_heat_comparison','primary_tables' if role=='primary' else 'replay_v3_tables');sc=source('canonical_so10_scalar_source_finite_comparison',role+'_tables');ps=source('canonical_so10_proper_matter_source_finite',role+'_tables');osb=source('canonical_so10_ordinary_scalar_matter_breaking',role+'_tables');asb=source('canonical_so10_auxiliary_scalar_matter_breaking',role+'_tables')
 assert sc['lower_xi_outside_once'] and ps['auxiliary_xi_factored_out_exactly_once'] and yh['fullD_scalar_current']
 gz(HERE/(role+'_inputs.json.gz'),{'Y':{k:y[k] for k in ['Tminus','B10','B126','H_new']},'YHC':yh['models'],'PSF':ps['source_matrices'],'SCF':{k:sc[k] for k in ['finite_coefficients','classical_Rnew']},'OSM':osb['models'],'ASB':asb['models']});add(HERE/(role+'_inputs.json.gz'))
smp=source('canonical_so10_scalar_matter_primitive','primary_tables');msp=source('canonical_so10_matter_source_primitive','primary_tables');hms=source('canonical_so10_heat_highest_matter_source','selected_three_projection_family')
mds=read(CAL/'canonical_so10_matter_degreezero_support/validation_receipt.json');support=source('canonical_so10_matter_degreezero_support','support_tables')['partitions']['cxPP']
assert mds['class_counts']['cxPP']['candidate']==24 and len(support['remaining_internal_ghost_candidates'])==12 and mds['actual_free_identity_imported_not_independently_rederived_here']
gz(HERE/'validation_control_inputs.json.gz',{'SMP':{k:smp[k] for k in ['K','physical_holomorphic_maps','physical_antiholomorphic_maps']},'MSP_X':{k:msp[k] for k in ['X_left','X_right']},'HMS_family':hms,'scalar_catalogue':support});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],stdout=out,stderr=err,cwd=ROOT)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'HSC1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('HSC1_FROZEN',len(bind),'bindings',flush=True)
