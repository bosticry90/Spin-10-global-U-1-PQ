"""HSC1 exterior source mass variation then direct sparse matrix images."""
from data import *
tick=begin('primary')
# Generic alternating density FIRST, before any quantum table is read.
def word(seq,z):
 if len(set(seq))!=len(seq):return {}
 return {tuple(sorted(seq)):(-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))*z}
def acc(a,b):
 for k,z in b.items():a[k]=sy.expand(a.get(k,0)+z)
M=sy.Matrix([[sy.Symbol('m0'),sy.Symbol('m1')],[sy.Symbol('m1'),sy.Symbol('m2')]]);N=sy.Matrix([[sy.Symbol('n0'),sy.Symbol('n1')],[sy.Symbol('n1'),sy.Symbol('n2')]]);ML=sy.Matrix(2,2,sy.symbols('l0:4'));MR=sy.Matrix(2,2,sy.symbols('r0:4'));C=sy.Matrix([[0,1],[-1,0]])
for mass,flow in [(M,ML),(N,MR)]:
 K=sy.kronecker_product(C,mass);X=sy.kronecker_product(sy.eye(2),flow);DK=sy.kronecker_product(C,flow.T*mass+mass*flow);actual={};expected={}
 for i in range(4):
  for j in range(4):
   for a in range(4):
    acc(actual,word([0,1+a,1+j],K[i,j]*X[i,a]/2))
    acc(actual,word([1+i,0,1+a],-K[i,j]*X[j,a]/2))
   acc(expected,word([0,1+i,1+j],DK[i,j]/2))
 assert all(sy.expand(actual.get(k,0)-expected.get(k,0))==0 for k in set(actual)|set(expected))
assert (ML.T*M+M*ML-(MR.T*M+M*MR)).applyfunc(sy.expand).todok()
generic={'holo':'ML.T*M+M*ML','anti':'MR.T*N+N*MR','independent_ML_MR':True,'wrong_projector_source_sensitive':True,'Nambu_half_extra':False}
print('STAGE GENERIC_GRASSMANN_SOURCE_MASS_IDENTITY',flush=True)
d=packed(HERE/'primary_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];Bs=[dec(d['Y'][k]) for k in ['B10','B126']];Rho=scalar_blocks(d['SCF']['classical_Rnew']);I=ident(16)
def endpoint(A,B):return mul(plus(kron(trans(A),I),kron(I,trans(A))),B)
def field(A,V,R):return minus(scale(endpoint(A,V),II),mul(V,R))
tree=0
for B in Bs:
 for b,ts in [(B,T),(star(B),U)]:
  for a in range(45):zero(field(ts[a],b,Rho[a]));tree+=256*328
print('STAGE ACTUAL_TREE_MASS_COVARIANCE',tree,flush=True)
relative=make_relative();pieces={};controls={}
for part in PARTS:
 pieces[part]={}
 for order in ORDERS:
  pieces[part][order]=[]
  fam='ordinary_g3' if order=='g3Y' else 'lower_g2xi';Sx=scalar_blocks(d['SCF']['finite_coefficients'][fam][part]);fac=ONE if order=='g3Y' else Q('xi');Sx=[scale(m,fac) for m in Sx]
  for idx,B in enumerate(Bs):
   record={}
   raw=d['YHC'][idx];V=addmaps(*(dec(raw[n][part]) for n in ['exchange','scalar_left','scalar_right'])) if order=='g3Y' else Mat(256,328)
   for side,ts,b,v in [('holomorphic',T,B,V),('antiholomorphic',U,star(B),star(V))]:
    src=source_part(d,order,part,side);ff=[];ss=[];bb=[];total=[]
    for a in range(45):
     f=field(ts[a],v,Rho[a]);s0=endpoint(src[a],b);e=mul(b,Sx[a]);ff.append(f);ss.append(s0);bb.append(e);total.append(addmaps(f,s0,e))
    relative[part][order][idx][side]=total;record[side]={n:summary(m) for n,m in [('field',ff),('proper_source',ss),('bosonic_source',bb)]}
    if part=='fixed':controls.setdefault(order,[]).append({'carrier':idx,'side':side,'omit_vertex_field':nz(ff),'omit_proper_source':nz(ss),'omit_bosonic_source':nz(bb),'wrong_projector_source':nz([minus(endpoint(a,b),endpoint(o,b)) for a,o in zip(src,source_part(d,order,part,'antiholomorphic' if side=='holomorphic' else 'holomorphic'))])})
   pieces[part][order].append(record)
   print('STAGE',part,order,idx,nz(relative[part][order][idx]['holomorphic']),flush=True)
dim=raw_quantum(d)
finish('primary',relative,pieces,dim,tree,controls,generic,tick,'generic_odd_alternating_mass_density_direct_Kronecker_scalar_and_source_Euler_images')
