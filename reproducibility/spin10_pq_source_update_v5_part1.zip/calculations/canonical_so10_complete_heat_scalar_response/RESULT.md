# Complete selected scalar heat identity and a common four-projection family

The complete selected marginal cxPP heat response is zero in both coupling
orders, both chiralities and both general Yukawa carriers. Its independently
measured dimensional breaking is nonzero. The actual finite comparison image
equals that dimensional breaking, leaving the zero heat result through the
qualified source-Hessian/operator identity. No unknown quantum coefficient,
source phase or physical normalization was fitted to obtain this equality.

The same fixed correction family now passes the onejet, vector, highest-matter-
source and scalar projections together. This remains a four-projection result
at zero external background/hats and coefficient dimension0, not a complete
chiral prescription, physical massive threshold or E5/A5 qualification.

Receipt [validation_receipt_v2.json](validation_receipt_v2.json), SHA256
`36b4cc573c79aa9cf200cdb39dc85de43c8f694cb41fe353dc54a4e1e4487f5f`, records
`QUALIFIED_COMPLETE_SELECTED_HEAT_SCALAR_RESPONSE_AND_COMMON_FOUR_PROJECTION_FAMILY`.
Scientific/director acceptance NOT_PERFORMED; authority remains34/39/state113.

## The source formula and quantum comparison

The literal physical mass action contains PL M+PR Mdagger. The generic proper
source contributes

    holomorphic: ML.T M+M ML,
    conjugate:   MR.T Mdagger+Mdagger MR.

ML and MR remain independent. A direct odd Grassmann density expansion and
an independent spin-projector congruence derive these identities before quantum
extraction. The actual classical cancellation using all45 ghosts, all328 scalar
directions and both carriers/chiralities passes at15,114,240 coefficient
positions. This fixes the source phase, scalar frame and endpoint convention
without a quantum cancellation target. The two source matrices must not be
interchanged or forced into a primitive-only antisymmetric relation.

The only local comparison parents in this selected projection are the measured
proper Yukawa vertex YHC, proper matter source PSF and scalar source SCF. The
bare dimensional insertion is independently assembled from OSM's eight ordinary
and ASB's four auxiliary profiles. MDS supplies the twelve remaining profiles'
complete paired-zero argument. Positive-dimension and background insertions
are outside this domain, rather than silently removed from the theory.

The two calculation routes use sparse Kronecker matrix products versus explicit
fermion-index/scalar-slot expansion. Their separate gate compares181,370,880
response positions, including zeros, across six related response components.
These are algebraic coverage counts, not that many independent integrations.
The actual heat response is evaluated as Rheat=Rdim-bSigmaCrel; a new independent
component heat-loop integration is not claimed.

| Stripped order/carrier | Nonzero Rdim positions per chirality | Nonzero fixed comparison image | Heat response |
| --- | ---: | ---: | ---: |
| g10^3 Y10 | 10,176 | 10,176 | 0 |
| g10^3 Y126 | 171,712 | 171,712 | 0 |
| g10^2 xi Y10 | 6,720 | 6,720 | 0 |
| g10^2 xi Y126 | 137,920 | 137,920 | 0 |

Equality includes values and zero complements, not only these counts. The
chi4 and log(3/2) images cancel separately without choosing chi4. The mixed
PSF/SCF xi is reinserted outside exactly once; the ASB raw input already
contains it. General symmetric family matrices retain their original entries;
there is no extra family3, scalar multiplicity or Nambu half.

## The same correction family passes all four projections

Only after quantum extraction, the verifier rederives the scalar images of
the fixed MSP source coefficient -X and the fixed SMP scalar maps. Their sum
cancels the measured dimensional insertion. Adding the independently measured
relative comparison then preserves the zero heat identity.

The structured family is
[selected_four_projection_family.json.gz](selected_four_projection_family.json.gz),
packed SHA256
`12289aa74b80c087f65c875cad57694994be5cbb6328b5e7eb161a0f02a481da`.
Its definition adds the fixed SMP mass maps and actual YHC/SCF terms to the
existing HMS family. PSF was already included and is checked byte-for-coefficient
equal; it is not added twice. The new xPP and JxCx terms leave the three prior
projections unchanged by their field/source and derivative degrees. Their
scalar correction remainders, including normalization and logarithmic parts,
are all zero. No new primitive is solved from the heat result.

The real free zpsi,z10,z126,chi4 and invariant mass additions u10/u126 stay
symbolic. The actual tree check gives the latter zero image. No claim is made
that these exhaust all invariant counterterms or identify kappa,b0,zeta.

Controls detect omission of the ordinary fixed vertex image at8,384/141,120
positions, omission of its proper-source image at10,176/172,096, and swapping
the source chirality at5,888/96,128. In the lower family the corresponding
proper-source and wrong-chirality controls change6,720/137,920 and4,160/79,040
positions. Fixed bosonic-source images are zero, so fixed-only omission there
is explicitly insensitive. Their common-normalization images are nonzero
(ordinary6,720/171,712; lower6,720/137,920) and participate in the exact
cancellation. Physical mass symmetry and conjugate reality hold coefficientwise.
Local-H compatibility follows authenticated tensor operations; no new large
all-H replay or full background completion is asserted.

## Execution and remaining work

The primary, corrected replay and gate record after-import calculation-time
markers245.113380s,246.364221s and74.086005s. Complete captures also retain
the resource observations through serialization and process completion.
Their126/127/39 samples have maximum private
bytes738,193,408 /737,992,704 /949,858,304, sampled observations rather than
peaks. The600s/8GiB/350MiB launchfloor limits held. A32MiB packet cap was
frozen for this broader domain; the approximately19.1MB pre-report packet
exceeds the earlier increments'16MiB cap, whose historical contracts were
not changed. Thirteen source copies and1850/1870/1875 initial/continuation/
validation bindings precede their calculations. Fresh bounded E4 readiness
completed this goalturn with step exits0/0/0/0/0/2 and seven custody NOTPASS.

Original replay passed generic/tree checks then failed at an absent sparse
slot lookup (KeyError322). Its source/capture and controller failure remain
preserved; the original verifier was not launched. V2 uses exact zero for
missing sparse rows, with every occupied coefficient and acceptance check
unchanged, and reuses the authenticated completed primary. See
[CONTINUATION_V2.md](CONTINUATION_V2.md). This implementation error remains
Track B evidence; it was not a physical disagreement or an erased failure.

The next useful question is how this coupled result extends to actual external
H backgrounds and the remaining chiral quantum construction. In particular,
an action-vertex diagonal-H projection alone does not include derivatives of
background-dependent heat factors or the reference subtraction. Recover the
actual SMA/background heat contract before calculating that extension; do not
silently substitute the earlier643-field bosonic witness for the enlarged
fermionic construction. A clean first target is the general-Yukawa two-point/
one-background-vertex relation with all ordered heat derivatives retained.

Full background/hatted/positive-mass identities, source completion, nonlinear
products/QAP, measure/phase, physical finite scheme and massive fermionicC1
remain open. Neither adverse scalar benchmark is repaired. QuartetFAIL,
flavorpause, HB1/C5 blocks, custody2/seven and authority34/39 are unchanged.
Shared action, earlier quantum coefficients, analytic hypotheses, exact
helpers/software and AI authorship limit independent scientific assurance.
