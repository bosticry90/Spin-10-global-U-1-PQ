# HSC1: complete selected scalar heat response and common correction family

Baseace6e26cc03e3e4f2fb44b97ceb65b50fb1c39b8/main32796blobs. WholegoalACTIVE,
state113/34of39 unchanged. Recover current AGENTS,V557, actual SMA mass/source,
CSW operator, YHC/SCF/PSF, OSM/ASB, MDS and prior correction receipts.

Question: evaluate the actual heat response in the complete marginal no-jet
cxPP projection, then test whether the SAME already fixed onejet/vector/
highest-source family extends with the fixed SMP scalar primitive and the
independently measured YHC/SCF relative coefficients. An exact nonzero response
or correction remainder is an allowed scientific outcome, not automatically
an anomaly. No coefficient or source sign may be inferred from cancellation.

First derive the proper source's mass Euler image from the literal physical
alternating action: holomorphic PLM uses ML at both endpoints, conjugate PRMdag
uses MR. ML/MR are independent; do not assume MR=-ML.T. Primary expands an
odd Grassmann mass density; replay uses full spin-projector congruence. Their
generic noncommuting identities, a wrong-projector control and the actual
classical tree covariance must pass before quantum extraction. No physical
normalization, imaginary factor or source orientation is fitted to loop data.

Only local comparison parents in this projection are proper xPP (YHC),
proper KPcP (PSF) and proper JxCx (SCF). Derive the coverage and source Euler
contributions using the actual action. Retain all45 ghosts/328 scalars, both
chiralities and both general family matrices, ordinaryg3Y and lowerg2xiY.
Reinsert the outside xi exactly once in PSF/SCF lower; ASB already contains it.
The dimensionally measured insertion is assembled from actual OSM/ASB bare
models, never their source-summed comparison or SMP target. The MDS complete
12 paired external-ghost profiles give the remaining structural zero, including
pureY3. New response uses Rheat=Rdim-bSigmaCrel under the qualified first-source
CSW identity; this is not a new independent component heat-loop integration.

Primary uses exact sparse Kronecker/end-point matrices, replay explicit three-
index Grassmann/scalar slot contractions. Freeze eight source/copies, domain,
proof, actual immutable input hashes, expected full evidence, negative controls
and caps before workers. Scientific workers deny primitive/combined target
reads. Only the late verifier reads the old SMP/MSP/HMS family and computes
their actual scalar image from their fixed coefficients. Preserve free zpsi,
z10,z126,chi4,u10/u126 and all other unrelated finite constants distinctly.

Three sequential600s-afterimport stages, sampledprivate8GiB, launch available
commit350MiB. New storedpacket cap32MiB is frozen for the broader full328-scalar
response and its complete parents; old16MiB contracts are unchanged. No evidence
truncation. Fresh E4 readiness thisgoalturn, no --fresh scientific replay, custody
expected exit2/seven. Any native failure stops dependent work; preserve complete
sources/captures and repair only under a versioned continuation. Validate before
local commit; before/index/after gates preserve every prior tracked blob.

Ceiling if all tests pass: a complete selected scalar response and a common
four-projection marginal correction family. No full source/background/hatted/
positive-mass functional, products/QAP/measure/phase, physicalscheme, massive
fermionicC1, E5/A5 or GUT promotion. Preserve both adverse scalar points,
quartetFAIL, pausedflavor, blockedHB1/C5 and custody2/seven. Shared action,
old quantum coefficients, analytic assumptions, exact helpers/software and AI
author remain shared-error limits. No agents/branches/worktrees/remote actions.
