# HSC1: actual scalar-source and matter-source Euler operation

## Actual mass and the generic source flow

SMA's physical alternating mass kernel is C(PL M+PR Mdagger), not its
opposite-projector propagator Born insertion. Let the odd-left proper source
flow be c(PL ML+PR MR)P. Charge transpose gives the corresponding sharp on
the left endpoint, without identifying the independent ML and MR. The two
generic mass images are

    source_holo=ML^T M+M ML,
    source_anti=MR^T Mdagger+Mdagger MR.

Both have the common inherited Nambu1/2 on either side of the density identity;
there is no extra half in these coefficient equations. An exterior-algebra
derivation and an independent full PL/PR matrix congruence check this before
reading quantum tables. At tree ML=igT,MR=igU,U=-T.T and qx=-g rho(c)x.
The bound B rho=i(T.T B+B T) identity cancels the total tree mass variation
exactly. Actual SCF supplies the same rho through literal scalar source rules.
This checks signs and frame applicability without a quantum cancellation target.

For a measured proper mass map V(x), the classical field image is

    g c^a [i(T_a^T V+V T_a)-V rho_a] (holomorphic),
    g c^a [i(U_a^T Vbar+Vbar U_a)-Vbar rho_a] (conjugate).

The proper bosonic source density Jx^T S_a x c^a contributes +B S_a to the
holomorphic image and +Bstar S_a to the conjugate image through the actual
physical scalar Euler column. The source derivative is taken before J0.
SCF has S_a in source-left Jx*C*x order; neither source nor scalar chart is
changed. Inserting a wrong sign would already violate the corresponding
classical mass/source identity. The lower source xi is outside once.

## Completeness of the local parents and measured breaking

The Slavnov density cxPP has dimension5 (ghost1,scalar1,twofermions3), no jets
and coefficient dimension0. Source-independent local parents of dimension4
can supply two fermions through kinetic PdP, gauge BPP or mass xPP. The first
two have no scalar and their tree variations have no affine scalar term in
this full Cartesian target; only xPP contributes. Purely bosonic parents have
no matter under elementary q. More matter, derivatives or fields exceed the
allowed dimension or leave additional external labels.

A proper matter-source KPcP contributes through the Yukawa part of the physical
fermion Euler column. A proper JxCx contributes through its physical PP scalar
Euler column. The coefficient-dimension-one JxC channel has no external scalar
and is separate. Gauge/auxiliary Euler columns have no tree xPP of this field
content; ghost/source Euler terms retain antighosts or sources. Antighost-source
PP parents exceed the allowed dimension. External hatted, sterile, background,
vacuum-tangent and positive-mass insertions are in different ideals/domains.
No equation-of-motion quotient, inverse coupling or hidden VEV specialization
is used. Thus YHC,PSF,SCF exhaust this selected local comparison.

The MDS24-profile scalar census consists of12 measured internal-ghost profiles
(eight ordinary OSM, four auxiliary ASB) and12 external-ghost profiles in six
complete paired-zero groups. This includes the local pureY3 coefficient; the
proper pureY3 comparison also has its pointwise polarization zero. Rdim is the
sum of the actual bare OSM/ASB model maps, with their full-D scalar-current
moments and both source-attachment orientations retained. No source-summed
fixed remainder is substituted as an independently measured quantum input.

The first-variation CSW Hessian identity and joint test-field domain apply to
this no-jet scalar coefficient just as to the earlier marginal matter sectors:
there is one physical matter insertion, no diagonal matter trace, and physical
external hats0 is stable. Full scalar Cartesian coefficients are differentiated
before x0. The comparison is local and the operation closes no numerical
Lorentz trace. Therefore

    Rheat=Rdim-bSigmaCrel, Crel=Gamma_dim,FP-Gamma_heat,FP.

Both widths, both general Yukawa matrices and chi4 remain symbolic. This is an
operator-identity evaluation using independently measured local parents, not a
new independent continuum heat integral, phase, measure or multiple-product
theorem. Derivative-free projected densities have no hidden IBP current.

## The late common-family test

The existing HMS family contains the fixed MSP source coefficient -X; its
scalar image is -(X_L.T B+B X_L), and the analogous right expression. This
follows the generic mass derivation, not the special primitive-only shortcut.
The independently constructed SMP maps deltaM=K B supply their actual field
image i(T.T deltaM+deltaM T)-deltaM rho. No new primitive is solved here.
The prior kinetic/gauge counterterm maps have zero scalar image by the same
field/jet argument above. Only after quantum extraction compare Rdim with
these fixed images, and then add the measured YHC/PSF/SCF comparison to the
same family. New xPP and JxCx terms do not change the three previous selected
onejet/vector/highest-source projections at their declared external ideals.
Check coefficient equality of the retained PSF and old family, and preserve
the symbolic invariant u10/u126 mass additions (their images vanish at tree).
Any failure is retained as an exact scoped remainder, not repaired by fitting.
