"""HSC1 authenticate original success/failure and freeze the exact V2 repair."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-scalar-response-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for n,h in bind.items():assert digest(Path(n))==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='ace6e26cc03e3e4f2fb44b97ceb65b50fb1c39b8'
assert read(HERE/'primary_capture.json')['exit_code']==0 and read(HERE/'replay_capture.json')['exit_code']==1 and not (HERE/'validation_receipt.json').exists()
assert read(HERE/'primary_capture.json')==read(CONTROL/'primary_full_capture.json') and read(HERE/'replay_capture.json')==read(CONTROL/'replay_full_capture.json')
r=read(HERE/'primary_result.json');raw=(HERE/'primary_tables.json.gz').read_bytes();assert sha256(raw).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(raw)).hexdigest()==r['tables_sha256']
assert read(HERE/'controller_failure.json')['last_role']=='replay'
for n in ['CONTINUATION_V2.md','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
for p in HERE.iterdir():
 if p.is_file():bind[str(p.resolve())]=digest(p)
for n in ['preparation_full_capture.json','primary_full_capture.json','replay_full_capture.json']:p=CONTROL/n;bind[str(p.resolve())]=digest(p)
with (HERE/'continuation_preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'HSC1_CONTINUATION_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'original_replay':'FAILED_ABSENT_SPARSE_ROW_LOOKUP','original_verifier':'NOT_LAUNCHED','primary_authenticated_not_recomputed':True,'seconds_each':600,'private_cap':8*1024**3,'packet_cap':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('HSC1_V2_FROZEN',len(bind),'bindings',flush=True)
