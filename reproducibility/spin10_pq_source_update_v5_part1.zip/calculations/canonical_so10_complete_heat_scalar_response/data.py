"""HSC1 exact matrices and IO only; distinct physical slot derivations in workers."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
PARTS=['chi4','log3over2','fixed'];ORDERS=['g3Y','g2xiY'];SIDES=['holomorphic','antiholomorphic'];DIMS=[('Phi',54),('Sigma',252),('phi',20),('S',2)]
def begin(role):
 tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('HSC1_PEER_OR_CORRECTION_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_scalar_matter_primitive','canonical_so10_matter_source_primitive','canonical_so10_heat_highest_matter_source'] and p.suffix=='.gz':raise PermissionError('HSC1_FIXED_PRIMITIVE_DENIED')
 sys.addaudithook(audit);return tick
def scalar_blocks(blocks):
 result=[Mat(328,328) for _ in range(45)];offset=0
 for sec,n in DIMS:
  assert len(blocks[sec])==45
  for a,record in enumerate(blocks[sec]):
   m=dec(record);assert (m.r,m.c)==(n,n)
   for (i,j),v in m.d.items():result[a].d[i+offset,j+offset]=v
  offset+=n
 assert offset==328;return result
def addmaps(*mm):
 out=Mat(256,328)
 for m in mm:out=plus(out,m)
 return out
def make_relative():return {p:{o:[{side:[] for side in SIDES} for _ in range(2)] for o in ORDERS} for p in PARTS}
def source_part(d,order,part,side):
 tag='ordinary' if order=='g3Y' else 'auxiliary';ss='left' if side=='holomorphic' else 'right';fac=ONE if order=='g3Y' else Q('xi')
 return [scale(dec(m),fac) for m in d['PSF'][tag][part][ss]]
def raw_quantum(d):return {order:[{side:[dec(m) for m in row[side]] for side in SIDES} for row in d['OSM' if order=='g3Y' else 'ASB']] for order in ORDERS}
def pack_relative(t):return {p:{o:[{s:[enc(v) for v in row[s]] for s in SIDES} for row in rows] for o,rows in orders.items()} for p,orders in t.items()}
def nz(mm):return sum(len(m.d) for m in mm)
def summary(mm):
 raw=(json.dumps([enc(m) for m in mm],sort_keys=True,separators=(',',':'))+'\n').encode()
 return {'nonzero':nz(mm),'sha256':sha256(raw).hexdigest()}
def finish(role,relative,pieces,dim,tree,controls,generic,tick,method):
 response={};counts={}
 for group in ['relative_chi4','relative_log','relative_fixed','dimensional_fixed','heat_length_log','heat_total_fixed']:
  response[group]={};counts[group]={}
  for order in ORDERS:
   response[group][order]=[];counts[group][order]=[]
   for idx in range(2):
    rr={};nn={}
    for side in SIDES:
     if group=='dimensional_fixed':v=dim[order][idx][side]
     elif group=='heat_length_log':v=[scale(m,Q(-1)) for m in relative['log3over2'][order][idx][side]]
     elif group=='heat_total_fixed':v=[minus(a,b) for a,b in zip(dim[order][idx][side],relative['fixed'][order][idx][side])]
     else:v=relative[{'relative_chi4':'chi4','relative_log':'log3over2','relative_fixed':'fixed'}[group]][order][idx][side]
     rr[side]=[enc(m) for m in v];nn[side]=nz(v)
    response[group][order].append(rr);counts[group][order].append(nn)
 out={'method':method,'response':response,'piece_summaries':pieces,'tree_covariance_zero_positions':tree,'generic_mass_source_identity':generic,'negative_controls':controls,'nonzero_counts':counts,'elapsed_after_imports':time.perf_counter()-tick,'operator_identity':'Rheat=Rdim-bSigmaCrel','independent_component_heat_integration':False,'quantum_coefficient_fitted':False,'primitive_read_to_fit_response':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
