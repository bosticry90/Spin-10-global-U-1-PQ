"""HSC1 spin-projector source congruence and independent three-index slot sums."""
from data import *
for path,hsh in read(HERE/'continuation_preparation_v2.json')['input_sha256'].items():assert digest(Path(path))==hsh,path
tick=begin('replay_v2')
PL=sy.diag(1,1,0,0);PR=sy.eye(4)-PL;ML=sy.Matrix(2,2,sy.symbols('l0:4'));MR=sy.Matrix(2,2,sy.symbols('r0:4'));M=sy.Matrix([[sy.Symbol('m0'),sy.Symbol('m1')],[sy.Symbol('m1'),sy.Symbol('m2')]]);N=sy.Matrix([[sy.Symbol('n0'),sy.Symbol('n1')],[sy.Symbol('n1'),sy.Symbol('n2')]])
source=sy.kronecker_product(PL,ML)+sy.kronecker_product(PR,MR);sharp=sy.kronecker_product(PL,ML.T)+sy.kronecker_product(PR,MR.T);mass=sy.kronecker_product(PL,M)+sy.kronecker_product(PR,N)
actual=sharp*mass+mass*source;expected=sy.kronecker_product(PL,ML.T*M+M*ML)+sy.kronecker_product(PR,MR.T*N+N*MR);assert not (actual-expected).applyfunc(sy.expand).todok()
wrong=sy.kronecker_product(PL,MR.T*M+M*MR)+sy.kronecker_product(PR,ML.T*N+N*ML);assert (actual-wrong).applyfunc(sy.expand).todok()
generic={'holo':'ML.T*M+M*ML','anti':'MR.T*N+N*MR','independent_ML_MR':True,'wrong_projector_source_sensitive':True,'Nambu_half_extra':False}
print('STAGE GENERIC_SPIN_PROJECTOR_SOURCE_CONGRUENCE',flush=True)
d=packed(HERE/'replay_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];Bs=[dec(d['Y'][k]) for k in ['B10','B126']];Rho=scalar_blocks(d['SCF']['classical_Rnew'])
def rows(m):
 out=defaultdict(list)
 for (i,j),z in m.d.items():out[i].append((j,z))
 return out
def slot(V,A=None,R=None,phase=ONE):
 out={};ar=rows(A) if A else {};rr=rows(R) if R else {}
 for (ij,x),z in V.d.items():
  i,j=divmod(ij,16)
  for a,w in ar.get(i,[]):key=16*a+j,x;out[key]=add(out.get(key,Z),prod(z,prod(phase,w)))
  for b,w in ar.get(j,[]):key=16*i+b,x;out[key]=add(out.get(key,Z),prod(z,prod(phase,w)))
  for y,w in rr.get(x,[]):key=ij,y;out[key]=add(out.get(key,Z),prod(z,w))
 return Mat(256,328,out)
tree=0
for B in Bs:
 for b,ts in [(B,T),(star(B),U)]:
  for a in range(45):zero(slot(b,ts[a],scale(Rho[a],Q(-1)),II));tree+=256*328
print('STAGE ACTUAL_TREE_MASS_COVARIANCE',tree,flush=True)
relative=make_relative();pieces={};controls={}
for part in PARTS:
 pieces[part]={}
 for order in ORDERS:
  pieces[part][order]=[];fam='ordinary_g3' if order=='g3Y' else 'lower_g2xi';Sx=scalar_blocks(d['SCF']['finite_coefficients'][fam][part]);fac=ONE if order=='g3Y' else Q('xi');Sx=[scale(m,fac) for m in Sx]
  for idx,B in enumerate(Bs):
   record={};V=addmaps(*(dec(d['YHC'][idx][n][part]) for n in ['exchange','scalar_left','scalar_right'])) if order=='g3Y' else Mat(256,328)
   for side,ts,b,v in [('holomorphic',T,B,V),('antiholomorphic',U,star(B),star(V))]:
    src=source_part(d,order,part,side);ff=[];ss=[];bb=[];total=[]
    for a in range(45):
     f=slot(v,ts[a],scale(Rho[a],Q(-1)),II);s0=slot(b,src[a]);e=slot(b,R=Sx[a]);ff.append(f);ss.append(s0);bb.append(e);total.append(addmaps(f,s0,e))
    relative[part][order][idx][side]=total;record[side]={n:summary(m) for n,m in [('field',ff),('proper_source',ss),('bosonic_source',bb)]}
    if part=='fixed':controls.setdefault(order,[]).append({'carrier':idx,'side':side,'omit_vertex_field':nz(ff),'omit_proper_source':nz(ss),'omit_bosonic_source':nz(bb),'wrong_projector_source':nz([minus(slot(b,a),slot(b,o)) for a,o in zip(src,source_part(d,order,part,'antiholomorphic' if side=='holomorphic' else 'holomorphic'))])})
   pieces[part][order].append(record)
   print('STAGE',part,order,idx,nz(relative[part][order][idx]['holomorphic']),flush=True)
dim=raw_quantum(d)
finish('replay_v2',relative,pieces,dim,tree,controls,generic,tick,'full_spin_projector_congruence_and_literal_three_index_slot_expansion')
