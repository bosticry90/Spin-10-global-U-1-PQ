"""HSC1 separate complete response and fixed common-family scalar image gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz');d=packed(HERE/'primary_inputs.json.gz')
for k in ['response','piece_summaries','nonzero_counts','negative_controls','generic_mass_source_identity','tree_covariance_zero_positions']:assert P[k]==R[k],k
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];Bs=[dec(d['Y'][k]) for k in ['B10','B126']];Rho=scalar_blocks(d['SCF']['classical_Rnew']);I=ident(16)
def endpoint(A,B):return mul(plus(kron(trans(A),I),kron(I,trans(A))),B)
def field(A,V,R):return minus(scale(endpoint(A,V),II),mul(V,R))
positions=0;embedding={};ctcounts={};chi_counts={}
for group,orders in P['response'].items():
 for order,models in orders.items():
  for idx,row in enumerate(models):
   assert len(row['holomorphic'])==len(row['antiholomorphic'])==45
   for l,r in zip(row['holomorphic'],row['antiholomorphic']):
    a,b=dec(l),dec(r);assert (a.r,a.c)==(b.r,b.c)==(256,328);zero(minus(a,rowtrans(a)));zero(minus(b,star(a)));positions+=2*256*328
assert positions==181370880 and P['tree_covariance_zero_positions']==15114240
for order in ORDERS:
 embedding[order]=[];ctcounts[order]=[];chi_counts[order]=[];power='4' if order=='g3Y' else '3'
 for idx,B in enumerate(Bs):
  emb={};nn={};cc={}
  for side,ts,b in [('holomorphic',T,B),('antiholomorphic',U,star(B))]:
   get=lambda group:list(map(dec,P['response'][group][order][idx][side]))
   dim=get('dimensional_fixed');relative=get('relative_fixed');heat=get('heat_total_fixed');log=get('relative_log');chi=get('relative_chi4')
   for h,rf,di,hl,lr in zip(heat,relative,dim,get('heat_length_log'),log):zero(minus(plus(h,rf),di));zero(plus(hl,lr))
   assert P['response']['dimensional_fixed'][order][idx][side]==d['OSM' if order=='g3Y' else 'ASB'][idx][side]
   X=list(map(dec,late['MSP_X']['X_left' if side=='holomorphic' else 'X_right'][power]));source=[scale(endpoint(x,b),Q(-1)) for x in X]
   mass=dec(late['SMP']['physical_'+side+'_maps'][idx]);mass_images=[field(ts[a],mass,Rho[a]) for a in range(45)] if order=='g3Y' else [Mat(256,328) for _ in range(45)]
   dimct=[addmaps(a,c) for a,c in zip(source,mass_images)]
   for q,c in zip(dim,dimct):zero(plus(q,c))
   corrected=[plus(c,r) for c,r in zip(dimct,relative)]
   for h,c in zip(heat,corrected):zero(plus(h,c))
   cc[side]=nz(chi);nn[side]={'fixed':0,'log':0,'chi4':0}
   emb[side]={'dim_counterterm_image':summary(dimct),'heat_fixed_counterterm_image':summary(corrected),'heat_log_counterterm_image':summary(log),'chi4_counterterm_image':summary(chi),'scalar_heat_remainders_zero':True}
  embedding[order].append(emb);ctcounts[order].append(nn);chi_counts[order].append(cc)
assert late['HMS_family']['all_three_selected_projection_remainders_zero']
assert d['PSF']==late['HMS_family']['previous_CHV_family']['relative_onejet_parents']['SRC']
base=late['HMS_family']['previous_CHV_family'];assert set(base['base_field_family'])=={'gauge','Y10','Y126'}
assert all(set(v)=={'F_left','F_right','K_left','K_right'} for v in base['base_field_family'].values())
assert base['base_fixed_matter_source_primitive']==late['MSP_X']
catalogue=late['scalar_catalogue'];assert len(catalogue['remaining_internal_ghost_candidates'])==12
for c in P['negative_controls']['g3Y']:assert c['omit_vertex_field']>0 and c['omit_proper_source']>0 and c['wrong_projector_source']>0
for c in P['negative_controls']['g2xiY']:assert c['omit_proper_source']>0 and c['wrong_projector_source']>0 and c['omit_vertex_field']==c['omit_bosonic_source']==0
for order in ORDERS:
 for record in P['piece_summaries']['chi4'][order]:
  for side in SIDES:assert record[side]['proper_source']['nonzero']>0 and record[side]['bosonic_source']['nonzero']>0
for obj in [P,R]:assert not any(obj[k] for k in ['independent_component_heat_integration','quantum_coefficient_fitted','primitive_read_to_fit_response','free_constant_selected','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
recipe={'definition':'oldHMScommonfamily+fixedSMPg2xPP+actualYHCg2xPPcomparison+actualSCFJxCxcomparison;PSFalreadyincludedONCE','old_three_projection_family':late['HMS_family'],'new_dimensional_scalar_mass_maps':{k:late['SMP'][k] for k in ['physical_holomorphic_maps','physical_antiholomorphic_maps']},'new_relative_Yukawa_coefficients':d['YHC'],'new_relative_scalar_source_coefficients':d['SCF']['finite_coefficients'],'scalar_images':embedding,'all_four_selected_projection_remainders_zero':True,'new_terms_leave_previous_three_selected_projections_unchanged_by_field_source_and_jet_degree':True,'proper_matter_source_not_added_twice':True,'parameters_left_symbolic':['z_psi','z_10','z_126','chi4','u10','u126'],'invariant_mass_additions':'u10*B10+u126*B126_have_zero_image_by_actual_tree_check','other_kappa_b0_zeta_not_identified_or_selected':True,'full_source_or_background_functional_image_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_four_projection_family.json.gz').open('xb') as f:f.write(blob)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_HEAT_SCALAR_RESPONSE_AND_COMMON_FOUR_PROJECTION_FAMILY','elapsed_after_imports':time.perf_counter()-tick,'response_positions_including_zeros_compared':positions,'tree_mass_covariance_positions':P['tree_covariance_zero_positions'],'generic_proper_mass_source_Euler_derived_before_quantum_extraction':True,'actual_bare_OSM_ASB_input_reassembled_without_source_target':True,'same_previous_three_projection_family_extended_exactly_once':True,'all_selected_scalar_heat_correction_remainders':ctcounts,'chi4_image_nonzero_counts':chi_counts,'nonzero_counts':P['nonzero_counts'],'negative_controls':P['negative_controls'],'local_H_covariance':'INHERITED_QUALIFIED_TENSOR_OPERATIONS_NO_NEW_LARGE_ALL_H_REPLAY','independent_component_heat_integration':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','family_sha256':sha256(blob).hexdigest(),'family_raw_sha256':sha256(raw).hexdigest(),'primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
