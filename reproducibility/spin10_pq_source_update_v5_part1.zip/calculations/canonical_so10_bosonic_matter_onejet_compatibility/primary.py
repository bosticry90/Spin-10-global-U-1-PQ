"""BMC1 fixed quantum/image sum and measured bosonic-Euler additions."""
from data import *
start=begin('primary');Q0=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/comparison_tables.json.gz')['complete_cPP_components'];C=packed(CAL/'canonical_so10_coupled_fermion_finite_counterterm/primary_tables.json.gz');B=packed(CAL/'canonical_so10_bosonic_source_onejet_finite/primary_v2_tables.json.gz');base={};compared=0
for tag in ['g2','g3','gY10','gY126']:
 base[tag]={}
 for side in ['left','right']:
  base[tag][side]={}
  for jet in ['p','q']:
   result=[]
   for q,c in zip(Q0[tag][side][jet],C['counterterm_images'][side][tag][jet]):
    m=plus(dec(q),dec(c));zero(m);result.append(enc(m));compared+=256
   assert len(result)==45;base[tag][side][jet]=result
additional={};counts={}
for tag,fam in [('g3','ordinary'),('g2','mixed')]:
 additional[tag]={};counts[tag]={}
 for side in ['left','right']:
  additional[tag][side]={};counts[tag][side]={}
  for direction in ['chi','fixed']:
   mm=list(map(dec,B['matter_q_images'][side][fam][direction]));mm=[scale(z,Q('xi')) for z in mm] if tag=='g2' else mm;additional[tag][side][direction]=list(map(enc,mm));counts[tag][side][direction]=sum(len(z.d) for z in mm)
fixed=list(map(dec,additional['g3']['left']['fixed']));eta=[matrix_width_coefficient(m,1,0) for m in fixed];xi=[matrix_width_coefficient(m,0,1) for m in fixed];const=[matrix_width_coefficient(m,0,0) for m in fixed]
for m,a,b,c in zip(fixed,eta,xi,const):
 zero(plus(plus(a,b),c));zero(minus(m,plus(scale(a,Q('eta_H-1')),scale(b,Q('xi-1')))));zero(at_one(m))
gram=gram2(eta,xi);det=determinant2(gram);assert det and expr(det).is_positive is True
lower=list(map(dec,additional['g2']['left']['chi']));witness=None
for c,m in enumerate(lower):
 for (i,j),v in sorted(m.d.items()):
  assert all(k[0]==0 and k[1]==1 for k,n in v)
  if witness is None:witness={'ghost':c,'row':i,'column':j,'coefficient':textq(v),'nonzero_algebraic_xi_coefficient':textq(width_coefficient(v,0,1))}
assert witness and witness['nonzero_algebraic_xi_coefficient']!='0' and counts['g2']['left']['fixed']==0 and counts['g3']['left']['fixed']>0
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));hom=0
for t in T:zero(minus(mul(ident(16),t),mul(t,ident(16))));zero(plus(scale(t,Q(-1)),t));hom+=512
print('STAGE NAIVE_SUM_FORMAL_WITNESS',witness,flush=True)
finish('primary',{'method':'fixed_complete_cPP_sum_measured_source_images_actual_matter_Gram','base_remainders':base,'base_positions_compared':compared,'additional_q_images':additional,'additional_q_nonzero_counts':counts,'additional_p_slot':'0','lower_actual_witness':witness,'formal_lower_equation_forces_common_chi_zero':True,'no_division_by_coupling_or_width':True,'ordinary_fixed_remainder_after_necessary_chi_zero':additional['g3']['left']['fixed'],'width_direction_Gram':enc(gram),'width_direction_Gram_determinant':textq(det),'independent_width_directions':2,'unit_width_fixed_remainder':0,'homogeneous_kinetic_vertex_pq_positions_checked':hom,'homogeneous_onejet_image':0,'required_compensating_quantum_term_calculated':False,'known_counterterms_refitted':False,'quantum_inputs_changed':False,'naive_direct_sum_full_width_polynomial_identity':False,'full_coupled_prescription_obstruction_claimed':False,'new_loop_integrals':0},start)
