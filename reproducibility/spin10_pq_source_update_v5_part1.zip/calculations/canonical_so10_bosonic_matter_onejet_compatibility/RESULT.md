# BMC1: unchanged direct assembly does not restore the full width family

The naive direct sum defined in RECORD is not a restored one-loop matter
identity over the complete symbolic-width ring. This is an exact conditional
compatibility finding,not a gauge anomaly or an obstruction to every coupled
prescription. The existing separate bosonic and fermionic qualifications
remain intact. State113/authority34of39 unchanged,scientific acceptance
NOT_PERFORMED.
Receipt SHA256 d675d509b20492a281efbbedb15105763aa776a7cbcba60ac37bd9a44083619d.

The pre-existing fixed fermionic quantum+counterterm sum is reproduced as0
on all184320 one-jet positions,including all45 colors,bothchiralities,p/q
slots and g2/g3/gY10/gY126 tags. Primary reads the qualified complete input;
replay independently reassembles GTT,gauge-E and Yukawa terms and rebuilds
the g2/g3 image from actual F,K,X. No coefficient is fitted or changed.

BSF1's actual additional bosonic-source matter Euler contribution is

 deltaLq_g3=chi4 sum_i P_i,c Ti+sum_i R_i,c Ti,
 deltaLq_g2=xi*chi4 sum_i PX_i,c Ti, deltaLp=0.

The source-free scalar correction,other bosonic source carriers and higher
source degrees do not add to this particular zero-field,dimension-zero
one-jet projection. Their other coupled identities remain obligations.

An actual lower-order coefficient is

    (3 sqrt(2)/5) xi chi4

at ghost0,matrix position(0,0) of the left carrier. As a polynomial identity
in the full eta_H,xi ring this forces chi4=0. This is a necessary implication
of the tested ansatz,NOT an adopted baseline or division by xi. The ring has
no zero divisors. Even allowing chi4 to be a polynomial of widths cannot
remove the implication. A specialization such as xi0 is a different test;
no conclusion about all fixed-width specializations is claimed.

At that necessary implication,the ordinary fixed contribution remains
nonzero at720 matrix positions per chirality. It cannot be made zero as
a full-width identity. Its actual affine decomposition is

 Rmatter=R_eta(eta_H-1)+R_xi(xi-1).

The complete matter Frobenius Gram is

    [[165/8, 24], [24, 75/2]], det=3159/16>0.

Replay obtains the same Gram from the actual source endomorphisms and
Tr(Ti Tj)=2delta_ij. Thus the two width directions are independently nonzero.
The unitwidth diagnostic makes the fixed term0,but is not an adopted
gauge,physical point or rescue of the general polynomial claim. No broader
classification of exceptional gauges or finite counterterms is inferred.

All92160 additional q-image positions,including zeros,agree between methods.
Actual right=-left.T,Hermiticity and all12 H cochain tests pass for every
order/direction. The illustrative homogeneous kinetic/gauge directions have
zero p/q image(23040 positions per carrier checked);their coefficients stay
free and cannot hide this remainder. The two Yukawa factor tags retain
their symbolic family meaning. They are not physical flavor choices.

Omitting the bosonic jet loses720 ordinary chi,720 ordinary fixed and592
lower chi positions. Removing the lower order loses the actual necessity
witness. Halving the fixed term changes720. Assigning independent common
normalizations changes1312 coefficient directions and would enlarge the
tested ansatz;it is not an authorized solution. These controls do not prove
failure of every possible coupled construction.

The result concerns automatic juxtaposition of counterterms with the OLD
quantum input unchanged. A proper coupled finite conversion,source/regulator
transport or independently justified correlated matter correction may supply
the missing terms. Their required negative image is a TARGET,not a measured
quantum insertion. No missing contribution was assigned that value. In
particular,the common logarithmic finite normalization should ultimately
transport the COMPLETE coupled pole functional,not only its bosonic part.
Existing qualified matter UV data may provide that common-log companion;
the fixed width-dependent finite contribution still needs its own treatment.

Commands:python -B calculations/canonical_so10_bosonic_matter_onejet_compatibility/
run.py;P/R/gate native0 at1.2893619/1.7616018/1.6189500s afterimports.
No new failed/incomplete worker or loop integral. Eight frozen source copies,
full captures/inputhashes and external bosonic-matter-onejet-compatibility-
v1-2026-10-23 records preserved. Same600s/8GiBsampled/350MiBfloor/16MiBpacket
bounds. Current-turn fresh E4 authenticated reuse,newbytepreflight;custody
exit2/sevenNOTPASS. No state,old evidence,physical parameter or scheme change.
Preparation/validation bindings592/600;resource samples2/2/2,private maxima
78462976/101949440/55820288B are sparse observations,not continuous peaks.

Primary packed1c87812a5eb0a3edf0f4cd19f0e6b63d5246e39f4ee1bd45f416408359ac3f71,
raw2b673b0e288d5f6e45a88eea7e040ac5016bde6011250c026f8bab33b6143aae.
Replay packed60098308605d4e996d8105641c238d83d00b7b11d78fc6cdd5c5eb3ad2ca2d74,
rawee7a6afea677fa8ae9a8369b599747b31d66c27cfc73ac78c83fb1dc5192e793.

The next smallest justified step is to recover the complete matter UV pole
normalization and determine its common-log source/Euler transport. Do not
solve for a new quantum finite coefficient from this desired cancellation.
Then investigate the remaining fixed finite conversion and the two other
bosonic source carriers. Source38,VMA,SMP,CFC and all older theorems retain
their qualified domains;full coupled Slavnov/QAP/products/measure/phase,
physicalchiralprescription,massiveC1,E5/A5 and physicalGUT remain unqualified.
Scalarwarnings,quartetFAIL,flavorpause,HB1/C5,custody and distinct free
constants remain. Shared action,data,software and AIauthor are common-error
limits,not independent scientific confirmation.
