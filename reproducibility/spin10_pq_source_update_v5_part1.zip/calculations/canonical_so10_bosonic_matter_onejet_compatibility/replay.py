"""BMC1 independent quantum component collection and actual rho/T image."""
from data import *
start=begin('replay');G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');E=packed(CAL/'canonical_so10_gauge_fermion_insertion/replay_tables.json.gz');V=packed(CAL/'canonical_so10_yukawa_finite_vertex_ward/replay_tables.json.gz');S=packed(CAL/'canonical_so10_matter_source_primitive/replay_tables.json.gz');C=packed(CAL/'canonical_so10_coupled_fermion_finite_counterterm/replay_tables.json.gz');B=packed(CAL/'canonical_so10_bosonic_source_onejet_finite/replay_v3_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];base={};compared=0
for tag in ['g2','g3','gY10','gY126']:
 base[tag]={}
 for side,ts,skey in [('left',T,'X_left'),('right',U,'X_right')]:
  base[tag][side]={};F=dec(C['F_'+side]);K=list(map(dec,C['K_'+side]));xh=[scale(dec(v),neg(II)) for v in S[skey]['4']];xl=[scale(dec(v),neg(II)) for v in S[skey]['3']]
  for jet in ['p','q']:
   out=[]
   for a in range(45):
    if tag in ['g2','g3']:
     q=dec(G[side][tag[-1]][jet][a])
     if tag=='g3' and jet=='q':q=plus(q,dec(E[side][a]))
     if tag=='g3':im=scale(minus(mul(F,ts[a]),mul(ts[a],F)),Q(-1)) if jet=='p' else plus(minus(K[a],mul(F,ts[a])),xh[a])
     else:im=Mat(16,16) if jet=='p' else xl[a]
    else:
     q=scale(dec(V['fermion_vertex_'+side][0 if tag=='gY10' else 1][a]),II) if jet=='q' else Mat(16,16)
     im=dec(C['counterterm_images'][side][tag][jet][a])
    z=plus(q,im);zero(z);out.append(enc(z));compared+=256
   base[tag][side][jet]=out
rho={f:{n:dec(v) for n,v in d.items()} for f,d in B['rho'].items()};additional={};counts={}
for tag,fam in [('g3','ordinary'),('g2','mixed')]:
 additional[tag]={};counts[tag]={}
 for side,ts in [('left',T),('right',U)]:
  additional[tag][side]={};counts[tag][side]={}
  for direction in ['chi','fixed']:
   m=rho[fam][direction];out=[]
   for c in range(45):
    z=Mat(16,16)
    for i in range(45):
     v=m.d.get((i,c),Z)
     if v:z=plus(z,scale(ts[i],prod(v,Q('xi') if tag=='g2' else ONE)))
    out.append(z)
   additional[tag][side][direction]=list(map(enc,out));counts[tag][side][direction]=sum(len(z.d) for z in out)
a=matrix_width_coefficient(rho['ordinary']['fixed'],1,0);b=matrix_width_coefficient(rho['ordinary']['fixed'],0,1)
for i in range(45):
 for j in range(45):
  z=rho['ordinary']['fixed'].d.get((i,j),Z)
  assert z==add(prod(a.d.get((i,j),Z),Q('eta_H-1')),prod(b.d.get((i,j),Z),Q('xi-1')))
source_gram=gram2([a],[b]);gram=scale(source_gram,Q(2));det=determinant2(gram);assert det and expr(det).is_positive is True
lower=list(map(dec,additional['g2']['left']['chi']));witness=None
for c,m in enumerate(lower):
 for (i,j),v in sorted(m.d.items()):
  assert all(k[0]==0 and k[1]==1 for k,n in v)
  if witness is None:witness={'ghost':c,'row':i,'column':j,'coefficient':textq(v),'nonzero_algebraic_xi_coefficient':textq(width_coefficient(v,0,1))}
assert witness and witness['nonzero_algebraic_xi_coefficient']!='0'
hom=0
for t in U:zero(minus(t,t));zero(plus(scale(t,Q(-1)),t));hom+=512
finish('replay',{'method':'separate_quantum_inputs_rebuilt_fixed_F_K_X_and_direct_source_current_duality','base_remainders':base,'base_positions_compared':compared,'additional_q_images':additional,'additional_q_nonzero_counts':counts,'additional_p_slot':'0','lower_actual_witness':witness,'formal_lower_equation_forces_common_chi_zero':True,'no_division_by_coupling_or_width':True,'ordinary_fixed_remainder_after_necessary_chi_zero':additional['g3']['left']['fixed'],'width_direction_Gram':enc(gram),'width_direction_Gram_determinant':textq(det),'independent_width_directions':2,'unit_width_fixed_remainder':0,'homogeneous_kinetic_vertex_pq_positions_checked':hom,'homogeneous_onejet_image':0,'required_compensating_quantum_term_calculated':False,'known_counterterms_refitted':False,'quantum_inputs_changed':False,'naive_direct_sum_full_width_polynomial_identity':False,'full_coupled_prescription_obstruction_claimed':False,'new_loop_integrals':0},start)
