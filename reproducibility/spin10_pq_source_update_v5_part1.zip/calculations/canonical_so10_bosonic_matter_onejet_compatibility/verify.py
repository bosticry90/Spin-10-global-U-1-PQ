"""BMC1 exact conditional compatibility test,not a full coupled anomaly gate."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['base_remainders','base_positions_compared','additional_q_images','additional_q_nonzero_counts','additional_p_slot','lower_actual_witness','formal_lower_equation_forces_common_chi_zero','no_division_by_coupling_or_width','ordinary_fixed_remainder_after_necessary_chi_zero','width_direction_Gram','width_direction_Gram_determinant','independent_width_directions','unit_width_fixed_remainder','homogeneous_kinetic_vertex_pq_positions_checked','homogeneous_onejet_image','required_compensating_quantum_term_calculated','known_counterterms_refitted','quantum_inputs_changed','naive_direct_sum_full_width_polynomial_identity','full_coupled_prescription_obstruction_claimed','new_loop_integrals']:assert P[key]==R[key],key
assert P['base_positions_compared']==184320 and P['additional_p_slot']=='0' and P['homogeneous_onejet_image']==0
for tags in P['base_remainders'].values():
 for jets in tags.values():
  for table0 in jets.values():assert len(table0)==45 and all(not dec(m).d for m in table0)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);fs=defaultdict(list)
for a,b,e,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:fs[a,b].append((e,Q(z)))
counts={};cov={};compared=0
for tag in ['g2','g3']:
 counts[tag]={};cov[tag]={}
 for direction in ['chi','fixed']:
  left=list(map(dec,P['additional_q_images'][tag]['left'][direction]));right=list(map(dec,P['additional_q_images'][tag]['right'][direction]));assert len(left)==len(right)==45
  counts[tag][direction]={'left':sum(len(m.d) for m in left),'right':sum(len(m.d) for m in right)}
  for l,r in zip(left,right):zero(plus(r,trans(l)));zero(minus(l,trans(star(l))));compared+=512
  cov[tag][direction]=[]
  for h in range(12):
   th=Mat(16,16);fh=defaultdict(lambda:Z)
   for a in range(45):
    v=HF.d.get((a,h),Z)
    if v:
     th=plus(th,scale(T[a],v))
     for c in range(45):
      for e,z in fs[a,c]:fh[c,e]=add(fh[c,e],prod(v,z))
   for c in range(45):
    m=scale(minus(mul(th,left[c]),mul(left[c],th)),neg(II))
    for (cc,e),v in fh.items():
     if cc==c:m=minus(m,scale(left[e],v))
    zero(m)
   cov[tag][direction].append(0)
witness=P['lower_actual_witness'];chi=sy.Symbol('chi4');c=int(witness['ghost']);i=int(witness['row']);j=int(witness['column']);m=dec(P['additional_q_images']['g2']['left']['chi'][c]);actual=m.d[i,j];assert textq(actual)==witness['coefficient'] and all(k[0]==0 and k[1]==1 for k,v in actual)
scalar=width_coefficient(actual,0,1);assert scalar and textq(scalar)==witness['nonzero_algebraic_xi_coefficient']
equation=sy.Poly(chi*expr(actual),WH,WM).coeff_monomial(WM);assert sy.solve(equation,chi)==[0]
fixed=list(map(dec,P['ordinary_fixed_remainder_after_necessary_chi_zero']));assert sum(len(m.d) for m in fixed)==720
eta=[matrix_width_coefficient(m,1,0) for m in fixed];xi=[matrix_width_coefficient(m,0,1) for m in fixed]
for m,a,b in zip(fixed,eta,xi):zero(minus(m,plus(scale(a,Q('eta_H-1')),scale(b,Q('xi-1')))));zero(at_one(m))
gg=gram2(eta,xi);zero(minus(gg,dec(P['width_direction_Gram'])));det=determinant2(gg);assert det and expr(det).is_positive is True and textq(det)==P['width_direction_Gram_determinant']
controls={'omit_bosonic_first_source_jet_loses_g3_chi':counts['g3']['chi']['left'],'omit_bosonic_first_source_jet_loses_g3_fixed':counts['g3']['fixed']['left'],'omit_bosonic_first_source_jet_loses_g2_chi':counts['g2']['chi']['left'],'drop_lower_order_loses_nonzero_necessity_witness':True,'half_new_fixed_image_changes_positions':720,'independent_normalization_per_family_changes_nonzero_coefficient_directions':counts['g3']['chi']['left']+counts['g2']['chi']['left'],'unit_width_fixed_remainder':0}
assert not any(P[k] for k in ['required_compensating_quantum_term_calculated','known_counterterms_refitted','quantum_inputs_changed','naive_direct_sum_full_width_polynomial_identity','full_coupled_prescription_obstruction_claimed','new_loop_integrals'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_BOSONIC_MATTER_ONEJET_COMPATIBILITY_TEST','disposition':'NAIVE_DIRECT_SUM_NOT_A_FULL_WIDTH_POLYNOMIAL_RESTORATION','elapsed_after_imports':time.perf_counter()-start,'base_cancelled_positions':184320,'additional_q_positions_compared':compared,'additional_q_nonzero_counts':counts,'all12_H_cochain_remainders':cov,'physical_reality_and_right_relation_remainders':0,'lower_actual_witness':witness,'common_chi_zero_is_necessary_polynomial_implication_not_adopted_value':True,'inverse_coupling_or_width_used':False,'ordinary_fixed_remainder_after_implication_per_chirality':720,'width_direction_Gram':P['width_direction_Gram'],'width_direction_Gram_determinant':P['width_direction_Gram_determinant'],'independent_width_directions':2,'homogeneous_kinetic_vertex_pq_positions_checked_per_carrier':P['homogeneous_kinetic_vertex_pq_positions_checked'],'homogeneous_onejet_image':0,'controls':controls,'required_compensating_quantum_term_calculated':False,'known_counterterms_refitted':False,'quantum_inputs_changed':False,'new_loop_integrals':0,'obstruction_to_all_coupled_prescriptions_claimed':False,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
