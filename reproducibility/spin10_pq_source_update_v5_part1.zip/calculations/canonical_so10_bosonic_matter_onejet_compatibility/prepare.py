"""BMC1 immutable inputs after independent quantum measurement."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_bosonic_source_onejet_finite'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/bosonic-matter-onejet-compatibility-v1-2026-10-23');BASE='ea630a3988f1affc1b5f58ecbc48a61135c191db';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v4.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==31999
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_v4_capture.json','RESULT.md','validation_preparation_v4.json','primary_v2_tables.json.gz','replay_v3_tables.json.gz']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V536.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_coupled_fermion_finite_counterterm',['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json','DERIVATION.md']),('canonical_so10_matter_source_primitive',['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),('canonical_so10_vector_fermion_edge_breaking',['primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_matter_degreezero_support',['primary_tables.json.gz','replay_tables.json.gz','support_tables.json.gz','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for folder,names in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_onesource_primitive_probe',['DERIVATION.md','validation_receipt.json']),('canonical_so10_dimensional_stokes_primitive',['RESULT.md','validation_receipt.json'])]:
 for name in names:add(CAL/folder/name)
for folder,names in [('canonical_so10_ghost_triangle_field_insertion',['comparison_tables.json.gz']),('canonical_so10_gauge_fermion_insertion',['replay_tables.json.gz','validation_receipt.json']),('canonical_so10_yukawa_finite_vertex_ward',['replay_tables.json.gz','validation_receipt.json']),('canonical_so10_scalar_matter_primitive',['RESULT.md','validation_receipt.json'])]:
 for name in names:add(CAL/folder/name)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
origin=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/bosonic-source-onejet-finite-v1-2026-10-23');reuse={}
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:
 p=origin/n;raw=p.read_bytes();reuse[str(p)]=sha256(raw).hexdigest()
 with (CONTROL/n).open('xb') as f:f.write(raw)
 add(CONTROL/n)
dump(CONTROL/'readiness_reuse.json',{'source_sha256':reuse,'fresh_readiness_command_here':False,'source_command_executed_earlier_this_goal_turn':True,'fresh_byte_preflight_here':True,'scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and d['files_written']==0 and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'BMC1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('BMC1_FROZEN',len(bind),'bindings',flush=True)
