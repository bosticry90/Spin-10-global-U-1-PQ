# BMC1: what a source-only finite jet adds to the existing matter identity

CFC already supplies Qmatter+image_CFC=0 separately in the p and q slots
at g2,g3,gY10,gY126. Do not use that old cancellation to assign a new
quantum coefficient. BSF measured the selected bosonic source jet before
this comparison. BME's exact additional source-free source/Euler operation
therefore adds

 deltaLq_g3=chi4 sum_i P_i,c Ti+sum_i R_i,c Ti,
 deltaLq_g2=xi*chi4 sum_i PX_i,c Ti,
 deltaLp=0.

The right maps use actual U=-T.T. Other source-free bosonic terms contain
no fermions. Higher bosonic source degree leaves a source after its one
gradient. Ghost/a/Lambda matter Euler columns vanish in this projection.
rho_B(B C) vanishes at ordinaryB0 and rho_x(C x) contributes no derivative
and vanishes at scalar0. Positive-dimension scalar translations are outside
the one-jet dimension-zero target. SMP's derivative-free Yukawa correction
likewise contributes no one-jet here. None of these facts makes the
uncomputed coupled quantum transport term zero.

Because the previous complete base is0,the residual of the explicitly
defined naive direct sum is exactly deltaLq above. If the actual lower
PX map is nonzero,a coefficient of xi*chi4 must vanish in any polynomial
identity in the complete eta_H,xi ring. In its integral domain this forces
chi4=0 (even if chi4 is allowed to be a polynomial of widths). This is a
necessary implication,not division by xi or choice of a gauge/normalization.
If the ordinary fixed R is then nonzero,the naive sum fails as a full-ring
identity. Keep both actual witnesses and every residual entry.

R is affine in widths. Extract R_eta,R_xi and R_const coefficientwise and
check R=R_eta(eta_H-1)+R_xi(xi-1). An exact nonzero two-direction Gram
determinant proves independence and bounds the exceptional unit-width
diagnostic. The test does not assert that no other fixed-width diagnostic
or coupled prescription can exist. It does not classify singular gauges,
choose unitwidth,or turn a polynomial-family failure into a physical no-go.

The same rank is checked directly on all matter maps and on the source
endomorphism coefficients through Tr(Ti Tj)=2delta_ij. This is an actual
structure/duality identity,not a transfer of physical authority from rank.
The illustrated homogeneous direction F->F+zI,K_c->K_c+zT_c has p-image
-[I,Tc]=0 and q-image-I Tc+Tc=0;its coefficient stays free. The z10/z126
directions have the same checked one-jet property in their factorized tags.

A negative result requires a genuinely coupled finite conversion/source/
regulator response or an independently justified correlated correction.
It is not repaired by treating the negative residual as a measured quantum
insertion. The existing separate bosonic and matter theorems remain
qualified in their domains;their automatic juxtaposition would be the
refuted inference,not the theories or physical Spin(10) hypothesis.
