from data import *
import mpmath as mp
start=begin('replay');mp.mp.dps=50
x,eps,z=s.symbols('x epsilon z',positive=True);D=4-2*eps;u=x*(1-x)
# Complete moving-edge-domain Gaussian. Derive radial and tensor factors.
A,B,P=s.symbols('A B P');p2=s.Symbol('p2',positive=True)
# A=int exp/sÂ²=P-pÂ²B. Gauge=(-A+pÂ²B)delta-2Bpp;
# scalar=-2A+pÂ²B. No fixed simplex approximation is made.
gdelta=s.expand((-A+p2*B).subs(A,P-p2*B));gpp=-2*B;scalar=s.expand((-2*A+p2*B).subs(A,P-p2*B))
assert gdelta==2*p2*B-P and scalar==3*p2*B-2*P
mom0=s.integrate(s.log(x),(x,s.Rational(1,2),1))*2
mom1=s.integrate(u*s.log(x),(x,s.Rational(1,2),1))*2
# Relative to Iheat, 2B=Iheat/3+jshift. The common log/Euler terms cancel.
jshift=s.simplify(-2*mom1+mom0/3)
# P=1/(8t)-pÂ²/6+O(t*p4).
power_g=-s.Rational(1,8);power_s=-s.Rational(1,4)
heat_g_T=jshift;heat_g_delta=s.Rational(1,6)
heat_s=s.simplify(s.Rational(3,2)*jshift+s.Rational(1,3))
# Exact beta/Gamma dimensions. Scalar physical trace has rank4, notD.
beta=s.gamma(2-eps)**2/s.gamma(4-2*eps)
reg=s.exp(s.EulerGamma*eps)*s.gamma(1+eps)*beta
bubble=s.exp(s.EulerGamma*eps)*s.gamma(1+eps)*s.gamma(1-eps)**2/s.gamma(2-2*eps)
def dimunit(f,pole):return s.simplify(s.diff(f*reg,eps).subs(eps,0)-pole*s.diff(bubble,eps).subs(eps,0))
sdim=dimunit(4/(D-2)+1,s.Rational(1,2));gdelta_dim=dimunit(D/(D-2),s.Rational(1,3));gpp_dim=dimunit(-s.Integer(2),-s.Rational(1,3))
relative_g_delta=s.simplify(gdelta_dim-heat_g_T-heat_g_delta);relative_g_pp=s.simplify(gpp_dim+heat_g_T)
relative_s=s.simplify(sdim-heat_s)
# Exact nonexceptional integral controls, independent of critical Taylor route.
numeric=[]
for q2 in [2,5]:
 for zz in [mp.mpf('1e-4'),mp.mpf('1e-7')]:
  tt=zz/q2
  ih=2*mp.e1(2*zz)-mp.e1(zz)+(mp.exp(-zz)-mp.exp(-2*zz))/zz
  bval=2*mp.quad(lambda xx:xx*(1-xx)*mp.e1(2*zz*xx),[mp.mpf('.5'),1])
  pval=mp.quad(lambda xx:(1-xx)*mp.exp(-2*zz*xx)/tt,[mp.mpf('.5'),1])
  gT=2*bval;gd=2*q2*bval-pval;ss=3*q2*bval-2*pval
  gd_as=-1/(8*tt)+q2*(ih/3+mp.mpf(str(s.N(heat_g_T,60)))+mp.mpf(str(s.N(heat_g_delta,60))))
  ss_as=-1/(4*tt)+q2*(ih/2+mp.mpf(str(s.N(heat_s,60))))
  err=max(abs(gd-gd_as),abs(ss-ss_as))/q2;assert err<=100*zz*abs(mp.log(zz))
  exact_ih=2*mp.quad(lambda xx:mp.e1(2*zz*xx),[mp.mpf('.5'),1]);assert abs(exact_ih-ih)<mp.mpf('1e-40')
  numeric.append({'p2':q2,'t_p2':str(zz),'normalized_asymptotic_error':str(err),'E1_bubble_error':str(abs(exact_ih-ih))})
G={}
for mu in range(4):
 for nu in range(4):
  delta=int(mu==nu);pp=int(mu==0 and nu==0);T=delta-pp
  G[f'{mu}_{nu}']={'pole':str(s.Rational(1,3)*T),'relative_fixed':str(s.simplify(relative_g_delta*delta+relative_g_pp*pp)),'heat_power_t_inverse':str(power_g*delta),'dimensional_finite_relative_to_bubble':str(s.simplify(gdelta_dim*delta+gpp_dim*pp)),'heat_finite_relative_to_bubble':str(s.simplify(heat_g_T*T+heat_g_delta*delta))}
finish('replay',{'scalar':{'pole':'1/2','relative_fixed':str(relative_s),'heat_power_t_inverse':str(power_s),'dimensional_finite_relative_to_bubble':str(sdim),'heat_finite_relative_to_bubble':str(heat_s)},'gauge':G,'log_moments':[str(mom0),str(mom1)],'heat_transverse_bubble_shift':str(jshift),'numeric_checks':numeric,'moving_edge_lower_limits_retained':True,'power_terms_retained':True,'physical_spin_trace':4,'Gaussian_action_coefficient':'1/4'},start)
