# CQH1: actual closed-fermion quadratic dimensional/positive-heat comparison

Question: what are the full power, logarithmic and finite local differences
of the actual mass-independent parity-even gauge and scalar two-point loops
versus the actual scalar positive free-edge heat? Existing BWF/GWF compared
DIM to a full-slash covariant comparator; that is a different object. Reuse
those results as late checks, not inputs fitted to a Ward cancellation.
Base81ac6894b9eb761aae6dc013c1af4fa9451488aa/main33072 old blobs. Whole goal
ACTIVE/incomplete, state113/authority34of39 unchanged. No physical adoption.

Freeze SMA actual PP propagator -i bar_slash/k², barred gauge vertices,
PL M+PR Mdagger scalar vertices, single Nambu/Pfaffian determinant half,
physical spin trace4, external hats0, Euclidean p²>0. This is the quadratic
part of the actual mass-independent closed-loop expansion at A_H=0, not a
massive or physical-vacuum amplitude. Both orientations remain. FullTr48
absorbs family trace; pure gauge has exactly three identical families, while
M already contains general symmetric Y10/Y126 matrices and full328carriers.
The sterile reference has no quantum vertices; no extra sterile determinant.
Parity odd is outside this target. Preserve all earlier phase/QAP limits.

Each free edge is filtered at both endpoints, so the two-edge loop weight is
exp[-2t(k²+(k+p)²)],t>0. Keep its second-order heat Taylor terms and leading
1/t power contacts. Define a finite-part coefficient after displaying those
power terms; this is not adoption of a physical power subtraction or baseline.
Use the existing chi4=FP(I_dim-I_heat) scalar-bubble normalization symbolically.
No finite coupling, flavor point, chi4,b0,kappa or zeta value is selected.

Primary: actual four-spinor Pfaffian numerator, full-D angular moments with
bar rank4, Oepsilon derivative and the second heat jet on lower power terms.
Replay: complete off-shell Feynman-parameter/Gaussian Schwinger calculation,
edge times >=2t, retain moving simplex boundary and its power contribution.
Derive exact E1 kernels and small-t finite constants. Compare all sixteen
gauge tensor positions plus scalar unit, power/log/finite coefficients and
implicit zeros. Use existing paired model Gram/scalar metrics only afterward.
This avoids rerunning full328 scalar/gauge contractions already qualified.

Controls: omit quadratic/linear heat jets, prematurely set D4 before the UV
finite part, discard power contact, alter Pfaffian half or family count, use
fixed Schwinger simplex instead of edge bounds. Report insensitive zeros.
Numeric exact E1/one-dimensional integrals at p²=2,5 and t*p²=1e-4,1e-7
check asymptotics at50digits, with normalized error <=100*z*abs(log z),
z=t*p²; finite analytic equality is the acceptance test, not that tolerance.
Remainder O(t*p^4*abs(log(t*p²))) follows compact max(x,1-x) between1/2and1
and the E1 remainder; no exceptional or constant-vacuum/causal limit follows.

Freeze8sources/copies and authenticated action/receipts/tables before P/R/V.
Each600s afterimports,8GiB sampled private,350MiB launch commit floor,
16MiB stored packet; sequential actual captured workers. Preserve failures,
version repairs, native exits, complete captures. Fresh E4 this logical turn
already GAB authenticatedroot0steps0/0/0/0/0/2,custody2sevenNOTPASS. No new
historical scientific replay. Validate and before/index/after local seals.

Possible outcomes: exact selected relative local comparison, scoped mismatch,
or underdefined/incomplete construction. A transverse finite quadratic gauge
difference cannot establish full non-Abelian restoration: cubic/quartic heat
companions and actual insertions/phase/source quantum applicability remain.
Negative comparison is a candidate relative counterterm only. Do not use the
algebraic Ward image as an independently integrated quantum breaking. No
E5/A5, full chiral QAP/measure, massive matterC1 or GUT promotion. Preserve
both distinct scalar failures, quartetFAIL, flavorpause,HB1/C5 blocks, all
old bytes and state. No agents/branch/worktree/push/publication/outreach.
Shared action, analytic dimensional and heat premises, SymPy/data/AIauthor
limit independence. AI target: detect finite/power terms invisible to poles,
reuse actual evidence, distinguish regulator comparison from physical scheme.
