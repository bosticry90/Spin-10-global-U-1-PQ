# CQH1 numerator, angular and complete off-shell routes

Use common1/(16pi²) units and Tr48. With r=k+p the gauge quadratic action
numerator after Gaussian half and physical spin trace is
Nmunu=kmu rnu+knu rmu-deltamunu bar_k.bar_r, divided by Q R, times g10².
The scalar action coefficient of Tr(V(-p)U(p)) is -bar_k.bar_r/(Q R).
Derive these factors, including both chiral paths, before integral extraction.
Second variation kernels have a further factor2, not an extra family/Nambu half.

Primary Taylor expands denominator and numerator through p² before angle
integration. Barred rank is4 while sphere dimension isD=4-2epsilon. For
2r moment use all pairings divided by D(D+2)... and Q^r. The second-order
heat factor is -2t p²+8t²(k.p)²; the linear factor -4t k.p multiplies the
entire first-order integrand, including its denominator Taylor term.
The finite relative unit is chi4*u4 -2 duD/dD|4 -h_heat, where h_heat is
the integrated power-symbol heat jet. The common convergent remainder cancels
between the two regulators in this nonexceptional two-point domain.

Replay Schwinger: a,b>=2t, s=a+b, x=a/s, s>=2t/min(x,1-x),u=x(1-x).
Complete Gaussian formulas are to be derived from the actual numerator.
The relevant integrals reduce to B=integral_0^1 u E1(2t p² max(x,1-x))dx
and P=integral_0^1 min(x,1-x) exp(-2t p² max(x,1-x))/(2t)dx.
Use integral e^(-s u p²)/s² = exp(-s0u p²)/s0-u p²E1(s0u p²).
This boundary term retains the power contact and a finite p² term. Dropping
it before expanding changes the finite normalization. E1(z)=-gamma-log z+O(z)
uniformly here after factoring positive p². Compute the logarithmic x moments
rather than copying a desired finite answer. Iheat=integral E1(...)dx equals
the previously qualified scalar bubble only in the late verifier.

Dimensional Feynman parameter uses J2=-D*u*p²/(D-2)*I2. Scalar coefficient
is u*(4/(D-2)+1),gauge delta coefficient u*D/(D-2), pp coefficient -2u.
Expand the exact beta/Gamma integrals before finite part. Keep the actual
q²delta finite contact found by GFD/SYR separate from the raw heat comparison.
Model charge/scalar metrics and general family trace are reused by immutable
paired input. No unknown counterterm coefficient is solved from cancellation.
