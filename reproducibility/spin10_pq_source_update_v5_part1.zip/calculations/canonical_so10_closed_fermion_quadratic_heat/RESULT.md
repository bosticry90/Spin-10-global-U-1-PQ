# CQH1: measured closed-fermion quadratic heat comparison

Qualified selected mass-independent parity-even Euclidean quadratic comparison.
Receipt SHA2569e81537c1d9dc50785cffab9c2c37a97b5a0cae24d1616f27f6745a3d8b59e50;
control-extension receipt d3ee87ecf30f3ceb34fb980e165900a057f3db7e80756d91370e090a494996a8.
Scientific acceptance NOT_PERFORMED; state113 and authority34/39 unchanged.

The two independently derived methods agree. In common1/(16pi²) action units,
Tr48 and physical p_hat=0,p²>0, DIM minus positive free-edge heat has the finite
quadratic gauge coefficient

    g10²*(chi4/3-5/36)*(p² delta_mu_nu-p_mu p_nu)

and scalar coefficient

    (chi4/2-5/24)*p²*Tr48(Mdagger(-p)M(p)).

Here chi4 is the previously defined scalar-bubble finite difference and remains
symbolic. Pure gauge Tr48 has family3 once. The scalar mass word already contains
general symmetric family matrices, both Yukawa representations and all328scalar
carriers. These are coefficients of the quadratic action, not its second
variation. The latter has an additional factor2. No extra Nambu half is applied.
The gauge finite kernel is transverse; this is a selected linearized statement,
not complete non-Abelian restoration.

The same measured difference retains the power contacts

    +g10²/(8t)*Tr48(A_mu A_mu) +1/(4t)*Tr48(Mdagger M).

They are not silently set to zero. Separating the finite coefficient does not
adopt a physical subtraction. In particular the gauge power term has a nonzero
linearized Ward variation. A complete heat-normalized construction must account
for that term, not infer restoration from the transverse finite remainder.

Primary derives literal4-spinor traces and the Gaussian/Pfaffian coefficient,
then Taylor-expands the actual barred numerators before integrating over the
full D-sphere. The scalar critical unit is6(D-2)/[D(D+2)], and the transverse
gauge unit is4(D-2)/[D(D+2)]. Their Oepsilon angular finite units are -1/12 and
-1/18. The second-order heat jet gives1/8 and1/12. Combining those independently
computed contributions gives fixed -5/24 and -5/36. Both the linear heat factor
on the complete first-order denominator/numerator and the quadratic heat factor
on the power symbol are essential.

Replay performs the full nonexceptional two-edge Schwinger integral. Edge
times a,b>=2t imply s>=2t/min(x,1-x), not a fixed simplex. Let u=x(1-x),
B=int u E1(2t p² max(x,1-x))dx and
P=int min(x,1-x) exp[-2t p² max(x,1-x)]/(2t)dx. Then

    K_gauge=2B*(p² delta-pp)-P*delta,
    K_scalar=3p²B-2P.

The asymptotic identities are
2B=Iheat/3+1/36+O(t p²), P=1/(8t)-p²/6+O(t p4).
Thus the complete heat expressions, in scalar-bubble normalization, are

    K_gauge=-delta/(8t)+(Iheat/3+1/36)*(p²delta-pp)+p²delta/6+o(1),
    K_scalar=-1/(4t)+p²*(Iheat/2+3/8)+o(1).

Independent exact dimensional beta/Gamma integrals give

    K_gauge=(Idim/3-1/9)*(p²delta-pp)+p²delta/6,
    K_scalar=p²*(Idim/2+1/6)

after pole separation. The nontransverse p²delta/6 appears in both regulators
and cancels in their relative finite difference. It remains the known selected
actual-minus-covariant-reference contact; that older comparison is not being
rewritten. The scalar analogous action contact1/6 is likewise retained.
The off-shell E1 expressions are checked at50digits for four p²,t combinations.
The displayed remainder is controlled only for positive nonexceptional p²,
not the constant-vacuum, IR delta, Lorentzian or causal limits.

All51 universal power/pole/fixed comparisons pass, including16gauge tensor
positions. Qualified paired data reuse checks2025Gram and215168scalar metric
positions, including zeros; there are no new model contractions or flavor fits.
The selected member artifact has packed/rawSHA256
fe2cc2b98f862a7790e05fe1d8fd56e717af063805a09313eca7c846d5c7161a /
77e8659d4d0ca0381df52eeccc87aa70b56fb54d832eb97205fa6de41aebfac7.

Omitting linear or quadratic heat jets changes5units each; premature D4 changes4;
discarding power contacts changes5. Wrong Pfaffian half changes4nonzero finite
units. The extension calculates the deliberately wrong fixed-simplex comparator:
it changes the gauge/scalar finite constants by7/36 and7/24 and the power
coefficients by-1/8 and-1/4. Omitting the closed family3 changes45Gram positions;
1980zero entries are insensitive and reported as such. Its arbitrary-momentum
linearized finite Ward contraction vanishes at4positions; the power variation
has4nonzero components. No unknown input was fitted to force cancellation.

Primary/replay/gate native0 in0.591860/0.374876/0.367534s afterimports;
control worker0.556768s. Each had one sampled private-memory observation,
2785280/401408/397312/921600B respectively. These short runs finish before
later samples: those values are not memory peaks. Observed launch memory floors
and sampled8GiB bounds pass; each600s budget and16MiB packet limit respected.
Eight initial source copies plus three extension copies,63/71/81bindings;
pre-reportpacket114071B. No worker/controller failure. Reused authenticated
fresh GAB E4 root0steps0/0/0/0/0/2; custodyexit2sevenNOTPASS. Local seals must
preserve all33072oldblobs before/through/after commit.

Reference intake: the two supplied fermionic assessments distinguish the two
adverse scalar configurations, preserve the failed chirality interface, and
prioritize actual finite/source/regulator applicability over assumed fermionic
rescues of physical matching. The later open-fermion and background calculations
address parts of their recommended sequence, with their own ceilings. This
new closed-loop comparison addresses a separate remaining dependency; neither
it nor the earlier proper-vertex UV agreement establishes a physical scheme.
No new literature claim or quantum interpretation is adopted from the reviews.

Next: derive the complete pure-gauge cubic and quartic raw DIM-minus-edge-heat
companions. A quadratic transverse result alone cannot supply their coefficients.
Retain actual three/four-edge heat lengths, the cubic linear heat jet and full
ordered color words. Reuse GPC/GFD pole data as late comparators; never assign
companions by covariantizing this answer. Mixed scalar/gauge heat companions,
actual insertion/Slavnov applicability, determinant phase and source equivalence
remain separate. No full finite QAP/E5/A5/massive matterC1 or physical GUT claim.
No finite constants, state, foundations or protected stages changed. Both scalar
failures, quartetFAIL, flavorpause, HB1/C5 and all original evidence persist.
Shared action, formal dimensional/heat premises, software and AI authorship are
not independent scientific confirmation. Whole investigation ACTIVE/incomplete.
