from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'control_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
r=packed(HERE/'replay_tables.json.gz');x=s.Symbol('x',positive=True);u=x*(1-x)
# Wrong fixed simplex uses E1(4t*p²*u) at allx and s0=4t.
# Express both in the actual Iheat normalization: -gamma-logz-2log2+1.
Iheat_constant=1-2*s.log(2)
flat_g_T=s.simplify(-s.log(4)/3-2*s.integrate(u*s.log(u),(x,0,1))-Iheat_constant/3)
flat_s=s.simplify(s.Rational(3,2)*flat_g_T+s.Rational(1,3))
true_g=s.sympify(r['heat_transverse_bubble_shift']);true_s=s.sympify(r['scalar']['heat_finite_relative_to_bubble'])
diffs={'gauge_finite_T':str(s.simplify(flat_g_T-true_g)),'scalar_finite_p2':str(s.simplify(flat_s-true_s)),'gauge_power_t_inverse':str(-s.Rational(1,4)+s.Rational(1,8)),'scalar_power_t_inverse':str(-s.Rational(1,2)+s.Rational(1,4))}
assert all(s.sympify(v)!=0 for v in diffs.values())
G=dec(packed(CAL/'canonical_so10_fermion_gauge_finite_difference/primary_tables.json.gz')['G'])
changed=nz(3*G-G);assert changed==45 and G.rows*G.cols-changed==1980
# Linearized finite Ward image is zero; gauge power variation is nonzero.
p0,p1,p2,p3=s.symbols('p0:4',real=True);v=s.Matrix([p0,p1,p2,p3]);T=(v.dot(v))*s.eye(4)-v*v.T;zero(T*v)
power_image=v/4;assert nz(power_image)==4
out={'status':'QUALIFIED_MOVING_SIMPLEX_FAMILY_AND_QUADRATIC_WARD_CONTROLS','elapsed_after_imports':time.perf_counter()-start,'wrong_fixed_simplex_minus_actual_heat':diffs,'wrong_closed_family_count_changed_Gram_positions':changed,'wrong_closed_family_insensitive_zero_positions':1980,'finite_linearized_Ward_tensor_positions':4,'power_contact_Ward_image_nonzero_positions':4,'power_contact_physical_subtraction_adopted':False,'original_completed_workers_rerun':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
