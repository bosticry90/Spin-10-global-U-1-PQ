# CQH1 control-completion extension V2
Original P/R/V completed without failure. Preserve them. Before reporting,
complete the stated moving-simplex and closed-family controls by a small
analytic post-check; no old scientific replay or new physical input. Freeze
this record, worker/controller and all completed outputs before execution.
Same600s/8GiB/350MiB/16MiB limits, one observed worker. Fixed simplex s>=4t
is a deliberately wrong comparator: calculate its power/finite difference,
do not merely assert that moving bounds matter. Test actual paired Gram
family3 and retain its zero complement. No new restoration authority.
