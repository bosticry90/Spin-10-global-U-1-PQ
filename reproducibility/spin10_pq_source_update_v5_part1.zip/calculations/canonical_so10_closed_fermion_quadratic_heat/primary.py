from data import *
from math import prod
start=begin('primary')
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.kronecker_product(pa[0],s.eye(2)),s.kronecker_product(pa[1],s.eye(2)),s.kronecker_product(pa[2],pa[0]),s.kronecker_product(pa[2],pa[1])]
chi=s.prod(gam);PL=(s.eye(4)+chi)/2;PR=s.eye(4)-PL
k=s.symbols('k0:4');p=[1,0,0,0];Q,D,t=s.symbols('Q D t',positive=True);b=sum(v*v for v in k);kp=k[0]
U,V=s.symbols('U V',commutative=False)
# Literal physical-spin/Nambu numerators with two actual chiral paths.
for mu in range(4):
 for nu in range(4):
  for a in range(4):
   for j in range(4):
    z=s.trace(gam[a]*gam[mu]*gam[j]*gam[nu])/4
    expected=int(a==mu)*int(j==nu)+int(a==nu)*int(j==mu)-int(mu==nu)*int(a==j)
    assert z==expected
for a in range(4):
 for j in range(4):
  assert s.trace(gam[a]*PL*gam[j]*PL)==0 and s.trace(gam[a]*PR*gam[j]*PR)==0
  assert s.trace(gam[a]*PL*gam[j]*PR)==2*int(a==j)

def avg(expr,dim=D):
 out=0
 poly=s.Poly(s.expand(expr),*k)
 for powers,c in poly.terms():
  if any(n%2 for n in powers):continue
  n=sum(powers)//2;den=s.prod(dim+2*j for j in range(n));num=prod(prod(range(1,v,2)) for v in powers)
  out+=c*num*Q**n/den
 return s.factor(out)
def radial(expr):
 expr=s.expand(expr);out=0
 for term in s.Add.make_args(expr):
  power=term.as_powers_dict().get(Q,0);c=s.cancel(term/Q**power)
  assert power in [-1,0]
  out+=c*(1/(4*t) if power==-1 else 1/(16*t*t))
 return s.simplify(out)
def jets(N0,N1):
 zer=N0/Q**2;one=N1/Q**2-2*kp*N0/Q**3
 two=-N0/Q**3+4*kp**2*N0/Q**4-2*kp*N1/Q**3
 unit=s.simplify(avg(two)*Q**2)
 hlin=radial(avg(-4*t*kp*one,4));hquad=radial(avg((-2*t+8*t*t*kp**2)*zer,4))
 power=s.simplify(radial(avg(zer,4))*t)
 return unit,s.simplify(hlin+hquad),hlin,hquad,power
S=jets(-b,-kp)
G={}
for mu in range(4):
 for nu in range(4):
  delta=int(mu==nu);N0=2*k[mu]*k[nu]-delta*b;N1=k[mu]*p[nu]+k[nu]*p[mu]-delta*kp
  G[f'{mu}_{nu}']=jets(N0,N1)
def form(row):
 u,h,hl,hq,power=row
 return {'u_D':str(u),'pole':str(s.simplify(u.subs(D,4))),'dimensional_angular_finite':str(s.simplify(-2*s.diff(u,D).subs(D,4))),'heat_jet':str(h),'heat_linear':str(hl),'heat_quadratic':str(hq),'heat_power_t_inverse':str(power),'relative_fixed':str(s.simplify(-2*s.diff(u,D).subs(D,4)-h))}
finish('primary',{'scalar':form(S),'gauge':{k:form(v) for k,v in G.items()},'literal_gauge_spin_positions':256,'literal_scalar_chiral_positions':64,'physical_spin_trace':4,'Gaussian_action_coefficient':'1/4','full_D_before_limit':True,'power_terms_retained':True},start)
