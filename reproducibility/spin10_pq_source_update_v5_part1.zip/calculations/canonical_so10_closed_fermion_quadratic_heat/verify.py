from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz');comparisons=0
for key in ['scalar','gauge']:
 rows=[(A[key],B[key])] if key=='scalar' else [(A[key][k],B[key][k]) for k in A[key]]
 for a,b in rows:
  for field in ['pole','relative_fixed','heat_power_t_inverse']:
   assert s.simplify(s.sympify(a[field])-s.sympify(b[field]))==0,(key,field,a,b);comparisons+=1
chi=s.Symbol('chi4',real=True);D=s.Symbol('D',positive=True)
controls={};sc=A['scalar'];ga=A['gauge'];zero_direction=ga['0_0']
assert s.sympify(zero_direction['pole'])==0 and s.sympify(zero_direction['relative_fixed'])==0
for name,field in [('omit_linear_heat_jet','heat_linear'),('omit_quadratic_heat_jet','heat_quadratic'),('premature_D4','dimensional_angular_finite'),('discard_power_contacts','heat_power_t_inverse')]:
 controls[name]=sum(s.sympify(v[field])!=0 for v in [sc,*ga.values()]);assert controls[name]>0
controls['wrong_Pfaffian_half']=sum(s.sympify(v['relative_fixed'])!=0 for v in [sc,*ga.values()]);assert controls['wrong_Pfaffian_half']>0
# Late authentication/application of qualified model tensors, not new contractions.
g=[];metrics=[];family=[]
for role in ['primary','replay']:
 v=packed(CAL/'canonical_so10_fermion_gauge_finite_difference'/(role+'_tables.json.gz'))
 sy=packed(CAL/'canonical_so10_scalar_yukawa_reference'/(role+'_tables.json.gz'))
 g.append(dec(v['G']));metrics.append(list(map(dec,sy['scalar_metrics'])));family.append(sy['family_norm_polynomials'])
 assert s.sympify(v['two_point_q2_delta_finite'])/2==s.Rational(1,6)
 assert s.sympify(sy['physical_difference_finite'])/2==s.Rational(1,6)
 assert v['closed_family_count']==3 and sy['extra_family_factor_used']==False
zero(g[0]-g[1]);assert g[0]==2*s.eye(45)
for j in range(2):zero(metrics[0][j]-metrics[1][j]);assert metrics[0][j].shape==(328,328)
assert family[0]==family[1]
fg=s.sympify(ga['1_1']['pole'])*chi+s.sympify(ga['1_1']['relative_fixed'])
fs=s.sympify(sc['pole'])*chi+s.sympify(sc['relative_fixed'])
assert s.simplify(fg-s.Rational(2,3)*fs)==0
artifact={'schema':'CQH1_MEASURED_QUADRATIC_RELATIVE_MEMBER','common_loop_factor':'1/(16pi^2)','action_not_second_variation':True,'finite_gauge_T_coefficient':str(fg),'finite_scalar_p2_coefficient':str(fs),'DIM_minus_heat_power_gauge_coefficient':'g10^2/(8t)','DIM_minus_heat_power_scalar_coefficient':'1/(4t)','gauge_Gram_per_family':enc(g[0]),'closed_gauge_family_count':3,'scalar_metrics':list(map(enc,metrics[0])),'family_norm_polynomials':family[0],'gauge_tensor':'p2 delta_mu_nu-p_mu p_nu','scalar_matrix_word':'Tr48(partial Mdagger partial M)','power_contacts_subtracted_as_physical_scheme':False,'finite_constant_or_cubic_quartic_completion_adopted':False,'full_QAP_phase_restoration':False}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_quadratic_relative_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_ACTUAL_PARITY_EVEN_CLOSED_QUADRATIC_DIM_HEAT_FINITE_AND_POWER_COMPARISON','elapsed_after_imports':time.perf_counter()-start,'universal_comparison_positions':comparisons,'gauge_tensor_positions':16,'model_Gram_positions_reused':45*45,'scalar_metric_positions_reused':2*328*328,'new_model_contractions':0,'finite_gauge_T_coefficient':str(fg),'finite_scalar_p2_coefficient':str(fs),'finite_gauge_longitudinal_remainder':0,'negative_control_changed_units':controls,'numeric_offshell_checks':len(B['numeric_checks']),'actual_minus_covariant_reference_contacts_retained':'gauge_and_scalar_action_units_1/6','power_contacts_retained':True,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'physical_scheme_adopted':False,'full_nonAbelian_chiral_restoration_QAP_phase':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','scientific_authority_changed':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
