# Prospective transverse boundary identities

Use JHP's actual numerator and power subtraction. Set w=2x(1-x)-1/3,
m=min(x,1-x), z=cq and N=exp(gammaE e)mu2^e. The exact reduced coefficient is

 F(e,c)=N int_0^1 w [q x(1-x)]^-e Gamma(e,z*max(x,1-x)) dx.

The zero-heat dimensional expression uses the beta identities:

 I_D=N q^-e Gamma(e) Beta(1-e,1-e),
 2B_D/I_D=(1-e)/(3-2e),
 F_D=-N q^-e Gamma(1+e) Beta(1-e,1-e)/[3(3-2e)].

It is continuous at e0 with F_D(0)=-1/9. The lower-face moment is

 J(e)=int w m^-e dx
     =2^e*e*(e-5)/[6(1-e)(2-e)(3-e)].

Thus j(e)=J(e)/e is continuous, j(0)=-5/36. The compact lower-gamma integral
gives the exact decomposition

 F=F_D-N c^e j(e)+R,
 |R|<=N q c^(1+e)*2^e/[3(1-e)(1+e)].

Derive the remainder using 0<=1-exp(-v)<=v and |w|<=1/3, not a numerical
fit. This bound is uniform near e0 on positive compact q/mu2 sets.
The LOCAL boundary transport A(e,c)=N c^e j(e) is derived from this kernel.
F+A tends jointly to-1/9. It is not a new free finite coefficient.

Raw F lacks one joint limit: heat-first (e0 then c0) gives1/36;
dimensional-first (c0 then e0) gives-1/9. Along cq=exp(-a/e),a>0,

 F -> -1/9+(5/36)exp(-a), A -> -(5/36)exp(-a).

Applying the constant -5/36 before a joint limit leaves a nonzero remainder
relative to F_D: -(5/36)(1-exp(-a)). The old CQH endpoint conversion remains
valid in its prescribed endpoint order. Its joint extension requires retaining
the derived epsilon-dependent boundary rather than substituting its e0 limit.
This is a selected analytic comparison, not adoption of a physical scheme.

Replay lower-gamma expansion: M_n(e)=int w m^-e max^n dx. Symmetry gives
M_n=2 int_0^(1/2) [2x(1-x)-1/3]x^-e(1-x)^n dx. For n>=1 the correction is

 -N c^e sum_(n>=1) (-cq)^n M_n/[n!(e+n)].

Compute M_n by expanding the polynomial on the half interval and integrating
each monomial; no primary output. Keep n=0 via j(e) so e0 is well-defined.
Retaining n=1..63 leaves a tail bounded by

 |N c^e| (cq)^64 * 2^e / [3(1-e)*64!*(e+64)].

The exponential Taylor remainder bound holds for all positive arguments and
the declared finite cases have cq<=1.5. Store every bound explicitly.
Finite-Clifford/Grassmann signs, powers and Ward part are reused JHP results,
not newly checked chiral source identities. I is retained; an actual common
scalar-bubble comparison and finite source/product domain remain dependencies.
