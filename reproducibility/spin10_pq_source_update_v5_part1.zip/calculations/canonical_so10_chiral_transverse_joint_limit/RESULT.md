# CTJ1: a transverse boundary transport, and a failure of premature conversion

## Bounded result

The scalar-bubble-reduced transverse coefficient of the actual JHP two-point
kernel has no single joint heat/evanescent limit. Using the known four-dimensional
finite conversion before removing both regulators does not repair this path
dependence. An epsilon-dependent local boundary transport, derived from the
same kernel rather than fitted to an identity, gives a uniform converted limit.
It reproduces the earlier CQH endpoint conversion in its qualified limit order.

This is a selected analytic comparison, not adoption of a physical subtraction
scheme or qualification of a full chiral trace, source-product, measure or QAP
construction. The nonzero Ward contact qualified by JHP is unchanged.

## Exact domain and derivation

Base95508d8422af57442ffd4b7f2e7937f4272bca2a, October25,2026. Reuse the
qualified actual SMA/CSW free P/S heat factors, numerator, normalization,
45-generator three-family Gram and power subtraction from JHP. They are
authenticated premises, not new contractions or an independent action replay.
Original unshifted mass-independent parity-even gauge two-point projection,
A0,p_hat0,q=p_E^2>0,0<=epsilon<=1/4,positive compact q/mu_R^2 sets.
No physical zero-Yukawa model, flavor benchmark or finite baseline is chosen.

In JHP common action units the power-subtracted tensor is

    K_R = 2B (q delta-pp) + W_R delta.

Let c=2t, N=exp(gamma_E epsilon)(mu_R^2)^epsilon, u=x(1-x),
m=min(x,1-x), Delta=qu. Keep the actual scalar bubble

    I = N integral_0^1 Delta^-epsilon
                       Gamma(epsilon,Delta*c/m) dx

explicitly. The present target is the reduced transverse coefficient F=2B-I/3,
not I itself. Thus K_R=(I/3+F)(q delta-pp)+W_R delta. The direct route
integrates the signed weight w=2u-1/3 against the exact upper-gamma kernel.
The independent lower-face route starts with the dimensional beta integral:

    I_D=N q^-epsilon Gamma(epsilon) Beta(1-epsilon,1-epsilon),
    2B_D/I_D=(1-epsilon)/(3-2epsilon),
    F_D=-N q^-epsilon Gamma(1+epsilon) Beta(1-epsilon,1-epsilon)
                                                      /[3(3-2epsilon)].

These are dimensional analytic continuations, not ordinary convergent
zero-cutoff integrals near epsilon0. F_D is continuous there, F_D(0)=-1/9.
The actual compact lower-face moment is

    J(epsilon)=integral w m^-epsilon dx
       =2^epsilon epsilon(epsilon-5)
                    /[6(1-epsilon)(2-epsilon)(3-epsilon)].

Its zero at epsilon0 is essential. Writing j=J/epsilon continuously gives
j(0)=-5/36. The lower-gamma representation proves

    F=F_D-N c^epsilon j(epsilon)+R,
    |R|<=N q c^(1+epsilon) 2^epsilon
                               /[3(1-epsilon)(1+epsilon)].

The bound follows from 0<=1-exp(-v)<=v, |w|<=1/3 and the integrable moment
integral m^-epsilon dx=2^epsilon/(1-epsilon). It is uniform on the declared
compact sets. The local transport A=N c^epsilon j(epsilon) therefore gives
F+A -> -1/9 jointly, without restricting epsilon log c. Its coefficient is
fixed by the boundary integral, not a new freely selected finite normalization.

## What fails, and what is retained

Raw F approaches 1/36 when epsilon is removed first and -1/9 when heat is
removed first. Along cq=exp(-a/epsilon),a>0,

    F -> -1/9+(5/36)exp(-a),
    A -> -(5/36)exp(-a).

Applying the endpoint constant -5/36 too early leaves the nonzero limiting
remainder -(5/36)(1-exp(-a)) relative to F_D. Thus JHP's uniform longitudinal
limit cannot be promoted into a uniform full-tensor comparison by simply
reusing a four-dimensional conversion constant.

The old CQH relation DIM-minus-heat=chi4/3-5/36 in the transverse action
coefficient remains valid in its endpoint prescription. The derived A gives
its required boundary dependence for this selected joint comparison. It does
not define chi4, or equate it to zeta,kappa,b0. The scalar bubble I and its
nonlocal momentum dependence remain explicit. A simultaneous finite part for
that bubble under the actual fixed prescription is still required before
claiming a complete quadratic comparison, much less a chiral source theorem.

Combining only the earned statements, the scalar-bubble-reduced transported
tensor has joint limit -(q delta-pp)/9+q delta/6 per color trace in common
action units. The second term is JHP's nonzero contact. Nothing has made the
actual unprobed hatted defect vanish or restored the whole quantum identity.

## Calculations and verification

The contract and all six source copies were frozen before computation.
Primary directly integrates the signed upper-gamma kernel. Replay integrates
the compact lower-gamma expansion via polynomial moments, retaining terms
n=1..63 after the n=0 moment is treated exactly. Its omitted tail is bounded by

    |N c^epsilon| (cq)^64 2^epsilon
                         /[3(1-epsilon)64!(epsilon+64)].

The exponential Taylor remainder establishes this bound for the positive
arguments; it is not silently set to zero. The largest retained series tail
is 1.04631446645206e-80, below the frozen1e-48 ceiling.

Nine finite cases and nine correlated paths were computed at100digits and
serialized at75. All126 scalar comparisons pass the1e-40 scaled gate.
The stored comparisons' largest scaled difference is about2.68e-102; this
is a diagnostic, not a claim of102-digit accuracy or physical precision.
The exact moment identities and uniform error bound are the limit argument.

Omitting or sign-flipping A changes all18cases. Substituting -5/36 early
changes15; the three epsilon0 cases have that same leading transport, as
expected. A wrong fixed lower face has integral w=0 and erases the nonzero
J/epsilon boundary term. This last control tests that moment, not every
coefficient of a complete alternative regulator. No control is presented as
verification of general source signs, arbitrary backgrounds or multiple products.

Primary/replay/verifier completed in57.4703734/2.7707880/.1397831seconds after
imports. Limits180s each,8GiB sampled private memory,350MiB launch floor,
8MiB packet were respected. Resource samples30/2/1, sampled private maxima
52,129,792/50,311,168/397,312bytes; these are not continuous memory peaks.
Preparation/validation bindings32/40, six source copies, pre-reportpacket67408B.
No worker, preparer or verifier failure occurred in CTJ1. JHP's two earlier
failures remain preserved and FAILED; they were neither rerun nor relabeled.

Receipt validation_receipt.json SHA256
95bd3450d9a56e086f1ee1b69ce605a5de0591d5f6c7f909072213c48c833e36.
Complete native captures, hashes and source copies accompany it. The routes
share the action, inherited JHP construction, elementary formulas, Python,
SymPy, mpmath and AI author. Their agreement is internal mathematical
corroboration, not external scientific or experimental confirmation.

Reused same-session E4 authentication: native0, steps[0,0,0,0,0,2], historical
custody exit2/sevenNOTPASS. It is not a fresh scientific replay or acceptance.
External before/index/after byte seals are under
C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-transverse-joint-limit-v1-2026-10-25/.
They protect all35553priorGitblobs and new raw/index/HEAD bytes. State113 and
authority34/39 unchanged; project_state.json SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.

## Next actual dependency

Retain the noncommuting raw limit as a real limitation of premature conversion.
The next small test is the scalar-bubble joint finite-part prescription itself:
derive its complete epsilon/heat subtraction from the existing fixed reference,
retain nonlocal log q and unspecified normalization, and test its relation to
the already derived tensor boundary transport. Do not impose a convenient
chi4 or exchange limits componentwise. If the joint finite-part extension is
not specified by the current contract, identify that precise missing datum.

Only then proceed to the first indispensable chiral source/probe-connected
channel with actual CSW/SQP Hessian roots and justified trace/contact domain.
No general background, full chiral QAP, measure/phase, multiple insertion,
physical-vacuum/massive-C1, causal-limit or E5/A5 claim is earned here. Existing
physical exclusions and paused flavor/HB1/C5 remain. No scheme/foundation/
benchmark adoption, promotion, branch/worktree, push, publication or outreach.
Overall Spin(10)xPQ investigation remains ACTIVE and INCOMPLETE.
