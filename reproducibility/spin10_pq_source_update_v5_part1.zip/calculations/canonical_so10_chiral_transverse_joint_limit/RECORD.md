# CTJ1: transverse boundary transport in the selected joint chiral amplitude

Freeze before computation, October25,2026, base95508d8422af57442ffd4b7f2e7937f4272bca2a.
Question: does the scalar-bubble-reduced transverse coefficient of JHP have
a common joint heat/evanescent limit under the inherited endpoint conversion,
or does the actual boundary require an epsilon-dependent local transport?
This directly follows V602, not a new physical subtraction scheme.

Authenticate current AGENTS/charter/state/V602, JHP equations/actual P/S root
review/receipts/outputs, and CQH's endpoint comparison. Reuse JHP's qualified
actual45-generator Gram/family3once and physical trace/Gaussian factors. No
new model contraction or independent validation of those premises is claimed.
Original SMA, mass-independent parity-even gauge2point, A0,p_hat0,q=pE2>0,
0<=e<=1/4,positive compactq/mu2,c=2t>0; no physical zeroYukawa benchmark.
Full tensor K_R=2B*(q delta-pp)+WR delta. JHP controls WR only. Define actual
scalar bubble I=N int Delta^-e Gamma(e,Delta*c/min) dx, N=exp(gammaE e)mu2^e,
u=x(1-x),Delta=qu. The target F=2B-I/3 leaves the nonlocal scalar bubble
explicit, not set0. No chi4,zeta,kappa,b0 is chosen or identified.

Primary: directly integrate signed weight (2u-1/3) against the upper-gamma
kernel; derive its zero-heat beta/Gamma coefficient and lower-face moment.
Replay: independently expand the compact lower-gamma integral with actual
Schwinger boundary, using polynomial moments and64 exponential terms. Retain
an explicit Taylor remainder <1e-48, no silently omitted tails. Do not use
the primary output or assign a response from a desired DIM comparison.

Derive exact moment J(e)=int(2u-1/3)min^-e dx, including its removable zero
at e0, and exact dimensional FD(e). Determine raw F's iterated/correlated
limits for cq=exp(-a/e). Test the existing constant -5/36 conversion, rather
than assuming it applies before removing e. Derive boundary transport from
the actual kernel, before comparing its limit to the old CQH coefficient.
If a corrected combination admits a uniform remainder bound, prove it for
the declared compact domain; preserve path dependence in uncorrected terms.
No cancellation is a full chiral QAP, source theorem or scheme adoption.

100digits/75serialized, agreement1e-40scaled. Same9finitecases as JHP:
e0,.05,.2,z=cq=.01,.2,1.5 with q=.5,2,5 andmu2=1.5; plus9paths
e=.1,.05,.025,a=.5,1,2,q2,mu2=1.5. These are auxiliary analytic diagnostics.
Require all finite-point route comparisons, all retained series tails, exact
beta/moment relations, old endpoint comparison only AFTER outputs, and
controls omitting/sign-flipping boundary transport, using -5/36 too early,
and replacing min(x,1-x) by a fixed lower face. Record insensitive e0 cases.

SequentialP/R/verifier180s each afterimports,8GiBsampledprivate,350MiBlaunch
floor,8MiBwholepacket. Freeze sources/inputs before launch; failures preserved,
cap exhaustionINCOMPLETE. Reuse native JHP results, not rerun its80s calculation.
Current E4 authentication already completed this session; authenticate that
capture and byte-identical scientific roots, not call it new acceptance.
All35553priorGitblobs/state113/34of39/custody2sevenNOTPASSprotected.
No agent,branch/worktree,push,outreach/publication,physicalscheme/foundation/
benchmark adoption,flavor/HB1C5 or E5/A5 promotion. Shared action/reference,
software/AIauthor and reused algebra limit independence. Goalactiveincomplete.
