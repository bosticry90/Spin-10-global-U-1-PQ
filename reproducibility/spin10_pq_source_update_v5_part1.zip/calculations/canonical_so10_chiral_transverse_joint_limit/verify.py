from pathlib import Path
from hashlib import sha256
import gzip,json,time,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
load=lambda r:json.loads(gzip.decompress((O/(r+'_tables.json.gz')).read_bytes()));a,b=load('primary'),load('replay');assert len(a['rows'])==len(b['rows'])==18;mp.mp.dps=100;worst=mp.mpf(0);tail=mp.mpf(0);controls={'omit_boundary':0,'wrong_boundary_sign':0,'premature_constant_4d':0,'e0_constant_insensitive_limit':3};positions=0
for x,y in zip(a['rows'],b['rows']):
 for k in ['epsilon','q','kind']:assert x[k]==y[k]
 for k in ['F','F_D','boundary_transport','converted','constant_4d_converted','remainder','uniform_bound']:
  xx,yy=mp.mpf(x[k]),mp.mpf(y[k]);error=abs(xx-yy)/max(1,abs(xx),abs(yy));worst=max(worst,error);assert error<mp.mpf('1e-40'),(k,x,error);positions+=1
 assert abs(mp.mpf(x['remainder']))<=mp.mpf(x['uniform_bound'])+mp.mpf('1e-75');tail=max(tail,mp.mpf(y['series_tail_bound']));assert mp.mpf(y['series_tail_bound'])<mp.mpf('1e-48');A=mp.mpf(y['boundary_transport']);controls['omit_boundary']+=int(A!=0);controls['wrong_boundary_sign']+=int(A!=0);controls['premature_constant_4d']+=int(abs(A+mp.mpf(5)/36)>mp.mpf('1e-40'))
for k in ['J_over_e','heat_endpoint','dimensional_endpoint','boundary_heat_endpoint','correlated_raw_limit','correlated_constant_conversion_remainder','uniform_converted_limit']:assert s.simplify(s.sympify(a[k])-s.sympify(b[k]))==0
e=s.Symbol('epsilon',real=True);j=2**e*(e-5)/(6*(1-e)*(2-e)*(3-e));assert s.simplify(j.subs(e,0))==-s.Rational(5,36);assert s.Rational(-1,9)-j.subs(e,0)==s.Rational(1,36)
# A wrong fixed face m=1 has J(e)=integral w=0, erasing this nonzero transport.
assert s.integrate(2*s.Symbol('x')*(1-s.Symbol('x'))-s.Rational(1,3),(s.Symbol('x'),0,1))==0
old=read(O.parent/'canonical_so10_closed_fermion_quadratic_heat/validation_receipt.json');jh=read(O.parent/'canonical_so10_chiral_joint_heat_pilot/validation_receipt_v3.json');assert old['actual_minus_covariant_reference_contacts_retained']=='gauge_and_scalar_action_units_1/6' and jh['nonlocal_kernel_retained'] and jh['exact_uniform_joint_Ward_limit_per_Gram_action']=='q/6'
out={'schema':'CTJ1_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'direct_upper_gamma_vs_independent_lower_face_series_agree':True,'finite_cases':9,'correlated_paths':9,'compared_scalars':positions,'maximum_scaled_discrepancy':mp.nstr(worst,30),'maximum_retained_series_tail':mp.nstr(tail,30),'raw_transverse_reduced_coefficient_has_no_single_joint_limit':True,'derived_epsilon_dependent_boundary_gives_uniform_converted_limit':True,'converted_limit':'-1/9','old_CQH_endpoint_conversion_preserved':'chi4/3-5/36','constant_4d_conversion_insufficient_for_joint_paths':True,'actual_fixed_face_erases_nonzero_boundary_moment':True,'controls':controls,'inherited_JHP_Ward_nonzero_contact_unchanged':True,'scalar_bubble_nonlocal_terms_not_discarded':True,'full_chiral_sources_probes_trace_QAP_measure_phase_or_E5_A5':False,'new_physical_scheme_or_baseline_adopted':False,'scientific_authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
