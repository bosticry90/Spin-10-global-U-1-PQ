from pathlib import Path
from hashlib import sha256
import gzip,json,sys,time,threading,os,math,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('CTJ_PEER_DENIED')
  if p.parent.name in ['canonical_so10_chiral_joint_heat_pilot','canonical_so10_closed_fermion_quadratic_heat'] and('tables'in p.name or 'receipt'in p.name):raise PermissionError('CTJ_OLD_TARGET_DENIED')
sys.addaudithook(guard)
e=s.Symbol('epsilon',real=True);j=2**e*(e-5)/(6*(1-e)*(2-e)*(3-e));m0=2*(2*2**(e-2)/(2-e)-2*2**(e-3)/(3-e)-2**(e-1)/(3*(1-e)))
if role=='primary':assert s.simplify(m0-e*j)==0;ratio=s.simplify((1-e)/(3-2*e)-s.Rational(1,3));assert s.simplify(ratio+e/(3*(3-2*e)))==0
else:
 def exact_moment(n):
  x=s.Symbol('x');pol=s.Poly((2*x-2*x*x-s.Rational(1,3))*(1-x)**n,x);return s.Add(*(2*a*2**(e-i-1)/(i+1-e) for (i,),a in pol.terms()))
 assert s.simplify(exact_moment(0)-e*j)==0
assert s.simplify(j.subs(e,0))==-s.Rational(5,36)
mp.mp.dps=100;fmt=lambda x:mp.nstr(x,75);rows=[]
def norm(e,mu):return mp.exp(mp.euler*e)*mu**e
def jd(e):return 2**e*(e-5)/(6*(1-e)*(2-e)*(3-e))
def dim(e,q,mu):return -norm(e,mu)*q**(-e)*mp.gamma(1+e)*mp.beta(1-e,1-e)/(3*(3-2*e))
def moment(n,e):
 coeff={}
 for k in range(n+1):
  base=(-1)**k*math.comb(n,k)
  for off,a in [(0,-mp.mpf(1)/3),(1,mp.mpf(2)),(2,-mp.mpf(2))]:coeff[k+off]=coeff.get(k+off,mp.mpf('0'))+base*a
 return 2*mp.fsum(a*mp.mpf('.5')**(i+1-e)/(i+1-e) for i,a in coeff.items())
def calc(e,c,q,mu):
 N=norm(e,mu);A=N*c**e*jd(e);FD=dim(e,q,mu);z=c*q;tail=mp.mpf('0')
 if role=='primary':
  F=2*N*mp.quad(lambda x:(2*x*(1-x)-mp.mpf(1)/3)*(q*x*(1-x))**(-e)*mp.gammainc(e,z*(1-x),mp.inf),[0,(1-1/mp.sqrt(3))/2,mp.mpf('.5')])
 else:
  rem=-N*c**e*mp.fsum((-z)**n*moment(n,e)/(mp.factorial(n)*(e+n)) for n in range(1,64));F=FD-A+rem;tail=abs(N*c**e)*z**64*2**e/(3*(1-e)*mp.factorial(64)*(e+64));assert tail<mp.mpf('1e-48')
 bound=N*q*c**(1+e)*2**e/(3*(1-e)*(1+e));error=F+A-FD;assert abs(error)<=bound+mp.mpf('1e-75')
 return {'F':fmt(F),'F_D':fmt(FD),'boundary_transport':fmt(A),'converted':fmt(F+A),'constant_4d_converted':fmt(F-mp.mpf(5)/36),'remainder':fmt(error),'uniform_bound':fmt(bound),'series_tail_bound':fmt(tail)}
for ee in ['0','0.05','0.2']:
 for z,q in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  ev,zv,qv=map(mp.mpf,[ee,z,q]);row=calc(ev,zv/qv,qv,mp.mpf('1.5'));row.update({'epsilon':ee,'cq':z,'q':q,'kind':'finite'});rows.append(row)
 print('STAGE CTJ '+role+' epsilon '+ee+' finite complete',flush=True)
for ee in ['0.1','0.05','0.025']:
 for a in ['0.5','1','2']:
  ev,av=map(mp.mpf,[ee,a]);row=calc(ev,mp.exp(-av/ev)/2,mp.mpf('2'),mp.mpf('1.5'));row.update({'epsilon':ee,'a':a,'q':'2','kind':'path','path_limit_raw':fmt(-mp.mpf(1)/9+mp.mpf(5)/36*mp.exp(-av)),'path_limit_constant_remainder':fmt(-mp.mpf(5)/36*(1-mp.exp(-av)))});rows.append(row)
print('STAGE CTJ '+role+' all paths complete',flush=True)
out={'schema':'CTJ1_TRANSVERSE_BOUNDARY','role':role,'J_over_e':str(j),'heat_endpoint':'1/36','dimensional_endpoint':'-1/9','boundary_heat_endpoint':'-5/36','correlated_raw_limit':'-1/9+5*exp(-a)/36','correlated_constant_conversion_remainder':'-5*(1-exp(-a))/36','uniform_converted_limit':'-1/9','scalar_bubble_and_nonlocal_part_retained':True,'new_physical_scheme_baseline_or_authority':False,'rows':rows};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
