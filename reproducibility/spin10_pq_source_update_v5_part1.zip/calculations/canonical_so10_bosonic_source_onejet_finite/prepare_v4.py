"""BSF1 verifier-only typed witness continuation;no scientific worker replay."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/bosonic-source-onejet-finite-v1-2026-10-23');BASE='f9a03ce2daac73bc726f6aeb09ecf78101dd2199'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
bind=dict(read(HERE/'preparation_v3.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
for role in ['primary_v2','replay_v3']:
 c=read(HERE/(role+'_capture.json'));r=read(HERE/(role+'_result.json'));b=(HERE/(role+'_tables.json.gz')).read_bytes()
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified'] and sha256(b).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==r['tables_sha256']
assert read(HERE/'verify_v3_capture.json')['exit_code']==1 and not (HERE/'validation_receipt.json').exists()
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
for n in ['preparation_v3.json','preparation_v3_capture.json','replay_v3_capture.json','replay_v3_result.json','replay_v3_tables.json.gz','validation_preparation_v3.json','verify_v3_capture.json','controller_failure_v3.json']:add(HERE/n)
for n in ['CORRECTION_V4.md','data_v4.py','verify_v4.py','prepare_v4.py','run_v4.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
with (CONTROL/'prelaunch_v4_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v4_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_v4_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8' and not d['active_A10_M08_python_processes']
for n in ['prelaunch_v4_preflight.json','prelaunch_v4_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation_v4.json',{'schema':'BSF1_PREPARATION_V4','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'completed_primary_v2_replay_v3_authenticated_reuse':True,'fresh_E4_reused_this_goal_turn':True,'scientific_acceptance':'NOT_PERFORMED'})
print('BSF1_V4_FROZEN',len(bind),'bindings',flush=True)
