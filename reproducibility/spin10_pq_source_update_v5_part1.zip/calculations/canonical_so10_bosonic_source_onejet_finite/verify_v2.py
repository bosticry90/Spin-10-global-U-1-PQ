"""BSF1 full finite-jet,source/UV bridge,reality and matter-Euler gate."""
from data_v2 import *
import re
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_v2_tables.json.gz');Ain=packed(HERE/'qualified_action_inputs.json.gz');UV=packed(HERE/'validation_control_inputs.json.gz')
for key in ['source_tensor','source_counts','source_linear_plane_remainder','V','A','H','Qchart','Qi','W','color_basis','rho','canonical_rho','matter_q_images','frontier','ordinary_source_factor','mixed_source_factor','ordinary_matter_factor','mixed_matter_factor','q_matter_p_slot','common_chi_chosen','bosonic_source_finite_jet_extracted','coupled_regulator_insertion_computed','coupled_cancellation_claimed','new_physical_scheme_adopted']:assert P[key]==R[key],key
sym={n:sy.Symbol(n,real=True) for n in ['D','w','routing','n_log']}
for key in ['unit_poles','finite_units']:
 for tag in ['a','B','C']:assert sy.simplify(sy.sympify(P[key][tag],locals=sym)-sy.sympify(R[key][tag],locals=sym))==0,(key,tag)
assert sy.simplify(sy.sympify(P['chi_definition'],locals=sym)-sy.sympify(R['chi_definition'],locals=sym))==0
assert R['longitudinal_heat_extra']=='3/8' and R['longitudinal_dimensional_extra']=='1/2' and R['finite_odd_heat_integral']=='1/4'
lam=sym['routing'];w=sym['w']
for tag in ['a','B','C']:
 u=sy.sympify(P['critical_D_coefficients'][tag],locals=sym);h=sy.sympify(P['heat_constants'][tag],locals=sym);d=sy.sympify(P['dimension_jets'][tag],locals=sym);v=sy.sympify(P['finite_units'][tag],locals=sym)
 assert sy.simplify(sy.diff(-h-d,lam))==0 and sy.simplify(-h-d-v)==0 and sy.simplify(2*sy.diff(u,sym['D']).subs(sym['D'],4)-d)==0
 if tag in ['a','B']:assert sy.diff(h,lam)!=0 and sy.diff(d,lam)!=0
front=P['frontier'];assert front['supported_families']==['SB*F','SB*X']
profiles={n:len(front['candidate_families'][n]['profiles']) for n in front['candidate_families']};assert profiles=={'SB*F':7,'SB*G3':0,'SB*S3':0,'SB*U':0,'SB*X':2}
assert front['candidate_families']['SB*F']['g']==2 and front['candidate_families']['SB*X']['g']==1 and front['candidate_families']['SB*X']['xi']==1
Qchart=dec(P['Qchart']);Qi=dec(P['Qi']);g=sy.Symbol('g10');controls32={};compared=0
for role in ['primary','replay']:
 copies=[{} for _ in range(4)]
 for row in UV['ordinary_canonical_32'][role]:
  names=row['word'];jn=next(n for n in names if n.startswith('JB'));cn=next(n for n in names if n.startswith('C'));i,mu=map(int,jn[2:].split('_'));c,nu=map(int,cn[1:].split('__'));assert mu==nu
  z=sy.sympify(row['coefficient'],locals={'g10':g,'eta_H':WH,'xi':WM});assert sy.Poly(z,g).degree()==2 and sy.expand(z-g*g*sy.diff(z,g,2)/2)==0
  sign=-1 if names.index(cn)<names.index(jn) else 1;copies[mu][i,c]=Q(sign*sy.diff(z,g,2)/2)
 assert all(v==copies[0] for v in copies);old=Mat(45,45,copies[0]);new=mul(mul(Qchart,old),Qi);zero(minus(new,scale(dec(P['rho']['ordinary']['chi']),Q(2))))
 N=dec(UV['mixed_N_C3'][role]);oldx=scale(mul(mul(Qchart,N),Qi),Q('-1/2'));zero(minus(oldx,dec(P['rho']['mixed']['chi'])));compared+=2*2025
rho={f:{n:dec(v) for n,v in t.items()} for f,t in P['rho'].items()};Y=Ain['Y']['replay'];T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);fg=defaultdict(list)
for a,b,e,z in Ain['plane_f']:fg[a,b].append((e,Q(z)))
counts={};hc={};matter_counts={}
for family,terms in rho.items():
 counts[family]={};hc[family]={};matter_counts[family]={}
 for tag,m in terms.items():
  counts[family][tag]=len(m.d);assert all(conj(v)==v and all(k[0]>=0 and k[1]>=0 for k,c in v) for v in m.d.values())
  hc[family][tag]=[]
  for h in range(12):
   F=Mat(45,45)
   for a in range(45):
    x=HF.d.get((a,h),Z)
    if x:
     for b in range(45):
      for e,z in fg[a,b]:F.d[e,b]=add(F.d.get((e,b),Z),prod(x,z))
   rem=minus(mul(F,m),mul(m,F));zero(rem);hc[family][tag].append(0)
  left=list(map(dec,P['matter_q_images']['left'][family][tag]));right=list(map(dec,P['matter_q_images']['right'][family][tag]));assert len(left)==len(right)==45
  for l,r in zip(left,right):zero(plus(r,trans(l)));zero(minus(l,trans(star(l))))
  matter_counts[family][tag]={'left':sum(len(v.d) for v in left),'right':sum(len(v.d) for v in right)}
zero(at_one(rho['ordinary']['fixed']));assert rho['ordinary']['fixed'].d and rho['ordinary']['chi'].d and rho['mixed']['chi'].d and not rho['mixed']['fixed'].d
bm={n:dec(v) for n,v in P['color_basis'].items()};R0=rho['ordinary']['fixed'];bad_noD=scale(plus(bm['ZW'],bm['AW']),Q('1/8'));bad_noH=minus(R0,bad_noD);missC=scale(minus(plus(bm['ZW'],bm['AW']),plus(bm['Z0'],bm['A0'])),Q('1/16'))
controls={'drop_dimension_jet':len(minus(R0,bad_noD).d),'drop_positive_heat_jet':len(minus(R0,bad_noH).d),'drop_finite_odd_heat_integral':len(R0.d),'omit_GF_external_ghost_derivative_fixed':len(minus(R0,missC).d),'omit_mixed_inverse':len(rho['mixed']['chi'].d),'one_Born_word_only_ordinary':len(rho['ordinary']['chi'].d),'one_Born_word_only_mixed':len(rho['mixed']['chi'].d),'unit_width_fixed_piece':0}
assert all(v>0 for n,v in controls.items() if n!='unit_width_fixed_piece')
assert not P['common_chi_chosen'] and P['bosonic_source_finite_jet_extracted'] and not P['coupled_regulator_insertion_computed'] and not P['coupled_cancellation_claimed']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_BOSONIC_SOURCE_ONEJET_FINITE_COEFFICIENT','disposition':'COMPLETE_JB_DERIVATIVE_C_FINITE_JET_AND_NONZERO_MATTER_EULER_COMPANION','elapsed_after_imports':time.perf_counter()-start,'profile_counts':profiles,'source_tensor_positions_compared':45**3,'rho_matrix_positions_compared':4*2025,'all4_Lorentz_rho_positions_compared':16*4*2025,'matter_image_positions_compared':2*4*45*256,'UV_normalization_comparator_positions':compared,'source_counts':P['source_counts'],'rho_nonzero_counts':counts,'matter_image_nonzero_counts':matter_counts,'all12_H_endomorphism_remainders':hc,'physical_plane_reality_and_right_relation_remainders':0,'unit_poles':P['unit_poles'],'finite_units':P['finite_units'],'chi_definition':P['chi_definition'],'longitudinal_heat_extra':R['longitudinal_heat_extra'],'longitudinal_dimensional_extra':R['longitudinal_dimensional_extra'],'finite_odd_heat_integral':R['finite_odd_heat_integral'],'controls':controls,'common_chi_chosen':False,'new_free_normalization_introduced':False,'bosonic_source_finite_jet_extracted':True,'coupled_regulator_insertion_computed':False,'coupled_cancellation_claimed':False,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_v2_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_v2_tables.json.gz')},sort_keys=True),flush=True)
