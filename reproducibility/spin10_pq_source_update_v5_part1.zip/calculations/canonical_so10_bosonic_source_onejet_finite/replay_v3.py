"""BSF1 actual heat/DR nonexceptional integrals and indexed source contraction."""
from data_v3 import *
import re
start=begin('replay');P=packed(HERE/'qualified_action_inputs.json.gz');assert not P['prior_loop_coefficients_included']
a,eps,p2,v=sy.symbols('a epsilon p2 v',positive=True);w,NL=sy.symbols('w n_log',real=True)
ih=2*sy.expint(1,2*a)-sy.expint(1,a)+(sy.exp(-a)-sy.exp(-2*a))/a
y=sy.Symbol('y',positive=True);primitive=y*sy.expint(1,2*a*y)-sy.exp(-2*a*y)/(2*a)
assert sy.simplify(sy.diff(primitive,y)-sy.expint(1,2*a*y))==0
assert sy.simplify(2*(primitive.subs(y,1)-primitive.subs(y,sy.Rational(1,2)))-ih)==0
heat_scalar=sy.simplify(sy.limit(ih+sy.log(a),a,0,dir='+'))+NL
idim=(4*sy.pi)**eps*p2**(-eps)*sy.gamma(eps)*sy.gamma(1-eps)**2/sy.gamma(2-2*eps)
raw_scalar=sy.simplify(sy.limit(idim-1/eps+sy.log(p2),eps,0,dir='+'))
chi=sy.expand_log(sy.expand(raw_scalar-heat_scalar),force=True)
# The finite vector integral is convergent off shell. Schwinger/Feynman
# parameters give p_mu/p2 times integral_0^1 1 dx.
x=sy.Symbol('x',positive=True);vector_convergent=sy.integrate(x*(1-x)/(x*(1-x)*p2),(x,0,1));assert vector_convergent==1/p2
# Odd heat integral:alpha=t*v,dominated by v/(v+4)^3. The exponential is
# between exp(-2t*p2) and exp(-t*p2),hence tends1 with an L1 majorant.
odd_heat=sy.integrate(2*v/(v+4)**3,(v,0,sy.oo));assert odd_heat==sy.Rational(1,4)
jheat=sy.simplify(sy.Rational(1,2)*p2*vector_convergent-odd_heat/2)
# Symmetry of the Feynman simplex replaces both x and1-x by their mean1/2.
assert sy.simplify(sy.gamma(2-eps)*sy.gamma(1-eps)/sy.gamma(3-2*eps)/(sy.gamma(1-eps)**2/sy.gamma(2-2*eps)))==sy.Rational(1,2)
jdim=sy.limit((sy.Rational(1,4)+eps/2-sy.Rational(1,4))/eps,eps,0);assert jdim==sy.Rational(1,2)
u4={'a':sy.factor(1-w/2+(w-1)/4),'B':w/2,'C':sy.factor(-1-(w-1)/4)}
fixed={'a':sy.factor((w-1)*(jdim-jheat)),'B':sy.S.Zero,'C':sy.factor(-(w-1)*(jdim-jheat))}
sum_differences=[sy.simplify(sum(u4.values())),sy.simplify(sum(fixed.values()))]
print('STAGE NORMALIZED_IBP_DIFFERENCES',sum_differences,flush=True)
assert sum_differences==[0,0]
assert sy.simplify((sy.Rational(1,4)*raw_scalar+jdim)-(sy.Rational(1,4)*heat_scalar+jheat)-chi/4-sy.Rational(1,8))==0
print('STAGE DIRECT_FINITE_INTEGRALS_COMPLETE',flush=True)
G=P['G']['replay'];UL=dec(G['raw_aux_map']);Qi=mul(dec(G['raw_Gca']),trans(inv(UL)));Qchart=dec(G['C3_chart']);zero(minus(mul(Qchart,Qi),ident(45)))
source={(b,i,a):Q(z) for b,a,i,z in P['plane_f']};Sby=defaultdict(list)
for (b,i,a),z in source.items():Sby[b,a].append((i,z))
jets={n:tensorrows(rows) for n,rows in G['plane_jets'].items()};V=cleanq({q:sub(jets['a'].get(q,Z),jets['B'].get(q,Z)) for q in set(jets['a'])|set(jets['B'])});A=cleanq({q:sub(jets['a'].get(q,Z),jets['c'].get(q,Z)) for q in set(jets['a'])|set(jets['c'])});H=tensorrows(G['plane_H']);Y=P['Y']['replay'];T=list(map(dec,Y['Tminus']));U=[scale(trans(z),Q(-1)) for z in T];HF=dec(Y['H_new']);PH=mul(HF,trans(HF));W=plus(scale(PH,Q('eta_H')),scale(minus(ident(45),PH),Q('xi')));wr=rowmaps(trans(W));tab={n:{} for n in ['A0','AW','ZW','Z0','X']}
Z0=cleanq({q:sub(prod(Q(2),V.get(q,Z)),A.get(q,Z)) for q in set(V)|set(A)})
for tag,co in [('A0',A),('Z0',Z0),('X',H)]:
 for (r,a,c),v in co.items():
  for i,z in Sby[r,a]:putq(tab[tag],(i,c),prod(z,v))
for tag,co in [('AW',A),('ZW',Z0)]:
 for (r,a,c),v in co.items():
  for b,wv in wr[r]:
   for i,z in Sby[b,a]:putq(tab[tag],(i,c),prod(z,prod(v,wv)))
bm={n:Mat(45,45,co) for n,co in tab.items()};rho={'ordinary':{'chi':scale(minus(scale(bm['A0'],Q(3)),bm['ZW']),Q('1/4')),'fixed':scale(minus(bm['AW'],bm['A0']),Q('1/8'))},'mixed':{'chi':scale(bm['X'],Q('1/2')),'fixed':Mat(45,45)}}
images={}
for side,ts in [('left',T),('right',U)]:
 images[side]={}
 for family,terms in rho.items():
  images[side][family]={}
  for tag,m in terms.items():
   mm=[]
   for c in range(45):
    q=Mat(16,16)
    for i in range(45):
     z=m.d.get((i,c),Z)
     if z:q=plus(q,scale(ts[i],z))
    mm.append(enc(q))
   images[side][family][tag]=mm
counts={'linear':0,'cubic':0,'all4_copies_equal':True};copies=[{} for _ in range(4)]
for row in P['source_rows']['replay']:
 names=row['word'];J=next(n for n in names if n.startswith('JB'));mu=int(J[-1]);kind='linear' if len(names)==2 else 'cubic';counts[kind]+=1
 canonical=tuple(n[:-1]+'0' if re.fullmatch(r'(?:JB|B)\d+_[0-3]',n) else re.sub(r'__[0-3]$','__0',n) for n in names)
 copies[mu][canonical]=row['coefficient']
assert all(c==copies[0] for c in copies) and counts['linear']==180 and counts['cubic']==3544
finish('replay_v3',{'method':'nonexceptional_heat_and_dimensional_Feynman_integrals_indexed_Lie','unit_poles':{n:str(z) for n,z in u4.items()},'finite_units':{n:str(z) for n,z in fixed.items()},'chi_definition':str(chi),'mixed_unit_pole':'1/2','mixed_finite_fixed_unit':'0','scalar_heat_finite_without_minus_log_p2':str(sy.expand_log(heat_scalar,force=True)),'scalar_raw_dimensional_finite_without_minus_log_p2':str(sy.expand_log(raw_scalar,force=True)),'longitudinal_heat_extra':str(jheat),'longitudinal_dimensional_extra':str(jdim),'finite_odd_heat_integral':str(odd_heat),'convergent_vector_integral':str(vector_convergent),'source_tensor':[[*q,textq(z)] for q,z in sorted(source.items())],'source_counts':counts,'source_linear_plane_remainder':0,'V':[[*q,textq(z)] for q,z in sorted(V.items())],'A':[[*q,textq(z)] for q,z in sorted(A.items())],'H':[[*q,textq(z)] for q,z in sorted(H.items())],'Qchart':enc(Qchart),'Qi':enc(Qi),'W':enc(W),'color_basis':{n:enc(v) for n,v in bm.items()},'rho':{f:{n:enc(v) for n,v in t.items()} for f,t in rho.items()},'canonical_rho':{f:{n:enc(mul(mul(Qi,v),Qchart)) for n,v in t.items()} for f,t in rho.items()},'matter_q_images':images,'frontier':P['frontier']['replay'],'ordinary_source_factor':'g10**2','mixed_source_factor':'g10*xi','ordinary_matter_factor':'g10**3','mixed_matter_factor':'g10**2*xi','q_matter_p_slot':'0','common_chi_chosen':False,'bosonic_source_finite_jet_extracted':True,'coupled_regulator_insertion_computed':False,'coupled_cancellation_claimed':False,'new_physical_scheme_adopted':False},start)
