# BSF1 direct replay normal-form continuation

V2 primary completed native0 and its normalized finite-unit differences
were all exactly0. It produced the full finite-source and matter maps.
Reuse it with unchanged bytes;do not run it again. V2 replay then failed
at a structural equality of summed factored/expanded IBP units,line25.
No replay table was exported and no gate launched. Preserve every original
and V2 source/copy,preparation,capture and controller failure.

V3 requires simplified exact zero for both the pole-unit sum and finite-unit
sum. These are the SAME mathematical IBP requirements. If they are notzero,
stop;no source/color coefficient may be relabeled qualified. This is a second
avoidable symbolic-comparison issue and remains part of the capability
record. It supplies no independent physical evidence. All actual integrals,
coefficients,constants,routing/UV controls and resources are unchanged.
New replay/gate/data/controller files are frozen;completed V2 primary is
authenticated as reuse,not presented as a V3 execution. Current-turn E4 is
also authenticated reuse with a fresh byte preflight. No physical input or
scheme is changed.
