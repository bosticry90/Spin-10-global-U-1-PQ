# BSF1 independent frontier-witness labels

Completed V2 primary and V3 replay are immutable and reused. All new finite
source matrices,source tensor,GF/color bases,matter maps and metadata through
those objects compared equal in V3 validation. The verifier then failed on
frontier:the two OLD qualified inventories use different internal-leg order
and pairing indices for identical typed edges. Candidate families,profiles,
jets,roles,status and witness counts already agree. No new coefficient table
failed and no physical or analytic assumption was changed.

For example,the SB*F primary internal ports are(BH,CH),(aH,BH),with pairs
(1,2),(3,0). Replay ports are(BH,CH),(BH,aH),with pairs(0,2),(1,3).
Both have the same typed BH--BH and CH--aH edges with identical derivative
roles. Comparing their raw index lists is not a scientific invariant.

V4 explicitly canonicalizes each edge endpoint as(vertex name,field role,
jet order),retains the complete external ports and profile,and checks every
internal port is paired exactlyonce. It requires exact equality of allnine
typed witnesses and every non-witness frontier field. No profile is removed,
filled0 or inferred from a desired answer. Original gate/capture/controller
failure are preserved. All subsequent finite/UV/reality/coverage tests remain
unchanged. Freeze a verifier-only continuation with the same600s/8GiB/350MiB/
16MiB bounds;no worker or E4 rerun. This is an avoidable validation-design
error,not an additional physical result or independent confirmation.
