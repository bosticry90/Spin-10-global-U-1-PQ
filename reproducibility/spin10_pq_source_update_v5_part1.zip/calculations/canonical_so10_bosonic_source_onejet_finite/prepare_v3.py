"""BSF1 reuse completed primary;freeze exact replay IBP normalization."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/bosonic-source-onejet-finite-v1-2026-10-23');BASE='f9a03ce2daac73bc726f6aeb09ecf78101dd2199'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
bind=dict(read(HERE/'preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
pc=read(HERE/'primary_v2_capture.json');pr=read(HERE/'primary_v2_result.json');blob=(HERE/'primary_v2_tables.json.gz').read_bytes()
assert pc['exit_code']==0 and pc['execution_state']=='COMPLETED' and pc['calculation_completed'] and pc['post_run_observations_qualified'] and digest(HERE/'primary_v2_tables.json.gz')==pr['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==pr['tables_sha256']
assert read(HERE/'replay_v2_capture.json')['exit_code']==1 and not (HERE/'replay_v2_tables.json.gz').exists() and not (HERE/'verify_v2_capture.json').exists()
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
for n in ['preparation_v2.json','preparation_v2_capture.json','primary_v2_capture.json','primary_v2_result.json','primary_v2_tables.json.gz','replay_v2_capture.json','controller_failure_v2.json']:add(HERE/n)
for n in ['CORRECTION_V3.md','data_v3.py','replay_v3.py','verify_v3.py','prepare_v3.py','run_v3.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
with (CONTROL/'prelaunch_v3_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v3_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_v3_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8' and not d['active_A10_M08_python_processes']
for n in ['prelaunch_v3_preflight.json','prelaunch_v3_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation_v3.json',{'schema':'BSF1_PREPARATION_V3','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'completed_primary_v2_authenticated_reuse':True,'fresh_E4_reused_this_goal_turn':True,'scientific_acceptance':'NOT_PERFORMED'})
print('BSF1_V3_FROZEN',len(bind),'bindings',flush=True)
