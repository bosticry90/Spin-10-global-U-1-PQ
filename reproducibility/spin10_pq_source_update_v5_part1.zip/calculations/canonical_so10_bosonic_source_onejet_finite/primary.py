"""BSF1 full critical/angular/heat jets and literal source matrix transport."""
from data import *
import re
start=begin('primary');P=packed(HERE/'qualified_action_inputs.json.gz');assert not P['prior_loop_coefficients_included']
D,w,lam,NL=sy.symbols('D w lambda n_log',real=True);Qd,Rd=sy.symbols('Q R',nonzero=True);k=sy.symbols('k0:6');p=sy.symbols('p0:6');dot=sum(x*y for x,y in zip(k,p));ps0=dict.fromkeys(p,0);uv={};u4={};heat={};jet={};fixed={};critical={}
for name,sgn in [('a',-w),('B',w),('C',sy.S.Zero)]:
 ab=None
 for mu in range(4):
  pp=(p[mu]/Qd+(w-1)*k[mu]*dot/Qd**2)/Rd
  kernel={'a':-w*k[mu]/(Qd*Rd)+pp,'B':w*k[mu]/(Qd*Rd),'C':-pp}[name]
  for nu in range(4):
   c=sy.diff(kernel,p[nu])-2*k[nu]*sy.diff(kernel,Rd)
   c=c.subs(ps0).subs(Rd,Qd)+lam*sgn*(int(mu==nu)/Qd**2-4*k[mu]*k[nu]/Qd**3)
   aa={'a':1-lam*w,'B':lam*w,'C':-1}[name];bb={'a':-1-w+4*lam*w,'B':2*w-4*lam*w,'C':1-w}[name]
   assert sy.expand(c*Qd**3-aa*int(mu==nu)*Qd-bb*k[mu]*k[nu])==0
   ab=(aa,bb)
 # Exact G(k)k=w*k uses a full vector,not a prematurely barred endpoint.
 K2=sum(v*v for v in k)
 for mu in range(6):assert sy.simplify(sum((int(mu==nu)+(w-1)*k[mu]*k[nu]/K2)*k[nu] for nu in range(6))-w*k[mu])==0
 uv[name]=sy.expand(ab[0]+ab[1]/D);u4[name]=sy.factor(uv[name].subs(D,4));jet[name]=sy.factor(2*sy.diff(uv[name],D).subs(D,4))
 t=sy.Symbol('t',positive=True);radial=sy.simplify(t*sy.gamma(1)/(4*t));assert radial==sy.Rational(1,4)
 heat[name]=sy.expand(-4*(2*lam-1)*sgn*sy.Rational(1,4)*radial)
 fixed[name]=sy.factor(-heat[name]-jet[name]);assert sy.diff(fixed[name],lam)==0
 critical[name]=[str(sy.expand(z)) for z in ab]
sigma=sy.simplify(sy.diff(sy.log(2*sy.pi**(D/2)/sy.gamma(D/2)/(2*sy.pi)**D),D).subs(D,4));chi=sy.expand_log(sy.expand(sy.EulerGamma+sy.log(4)-NL-2*sigma),force=True)
assert sy.simplify(sum(uv.values()))==sy.simplify(sum(heat.values()))==sum(fixed.values())==0
assert fixed=={'a':(w-1)/8,'B':0,'C':-(w-1)/8}
# Mixed orientations combine before projection. This fixes u_X=1/2
# with no heat-positive jet or dimension-dependent angular factor.
px=sy.simplify((-sy.I)*(-sy.I*k[0]+sy.I*(k[0]+p[0]))/(2*Qd*Rd));assert px==p[0]/(2*Qd*Rd)
print('STAGE FINITE_UNIT_JETS_COMPLETE',flush=True)
G=P['G']['primary'];Qchart=dec(G['C3_chart']);Qi=inv(Qchart);qr=rowmaps(Qi);sr=rowmaps(trans(Qchart));raw=[{} for _ in range(4)];lin=[{} for _ in range(4)];nlinear=ncubic=0;g=sy.Symbol('g10')
for row in P['source_rows']['primary']:
 names=row['word'];jname=next(n for n in names if re.fullmatch(r'JB\d+_[0-3]',n));i,mu=map(int,jname[2:].split('_'));cn=next(n for n in names if re.fullmatch(r'C\d+(?:__[0-3])?',n));sign=-1 if names.index(cn)<names.index(jname) else 1
 z=sy.sympify(row['coefficient'],locals={'g10':g})
 if len(names)==2:
  cjet=cn[1:].split('__');assert len(cjet)==2 and int(cjet[1])==mu;nlinear+=1;putq(lin[mu],(i,int(cjet[0])),Q(sign*z));continue
 assert len(names)==3 and '__' not in cn
 bn=next(n for n in names if re.fullmatch(r'B\d+_[0-3]',n));b,nu=map(int,bn[1:].split('_'));assert mu==nu and sy.Poly(z,g).degree()==1 and z.subs(g,0)==0;ncubic+=1
 putq(raw[mu],(i,b,int(cn[1:])),Q(sign*sy.diff(z,g)))
assert nlinear==180 and ncubic==3544 and all(raw[mu]==raw[0] and lin[mu]==lin[0] for mu in range(4))
zero(minus(mul(mul(Qchart,Mat(45,45,lin[0])),Qi),ident(45)))
source={}
for (i,b,c),v in raw[0].items():
 for ii,x in sr[i]:
  for bb,y in qr[b]:
   for cc,z in qr[c]:putq(source,(bb,ii,cc),prod(v,prod(x,prod(y,z))))
source=cleanq(source);assert all(conj(v)==v for v in source.values())
jets={n:tensorrows(rows) for n,rows in G['plane_jets'].items()};V=cleanq({q:sub(jets['a'].get(q,Z),jets['B'].get(q,Z)) for q in set(jets['a'])|set(jets['B'])});A=cleanq({q:sub(jets['a'].get(q,Z),jets['c'].get(q,Z)) for q in set(jets['a'])|set(jets['c'])});H=tensorrows(G['plane_H']);S=tensor_matrices(source);AM=tensor_matrices(A);VM=tensor_matrices(V);HM=tensor_matrices(H)
Y=P['Y']['primary'];T=list(map(dec,Y['Tminus']));U=[scale(trans(z),Q(-1)) for z in T];HF=dec(Y['H_new']);W=plus(scale(ident(45),Q('xi')),scale(mul(HF,trans(HF)),Q('eta_H-xi')))
A0=Mat(45,45);AW=Mat(45,45);ZW=Mat(45,45);Z0=Mat(45,45);XX=Mat(45,45);WT=rowmaps(W)
for b in range(45):
 A0=plus(A0,mul(S[b],AM[b]));Z0=plus(Z0,mul(S[b],minus(scale(VM[b],Q(2)),AM[b])));XX=plus(XX,mul(S[b],HM[b]))
 for r,z in WT[b]:AW=plus(AW,scale(mul(S[b],AM[r]),z));ZW=plus(ZW,scale(mul(S[b],minus(scale(VM[r],Q(2)),AM[r])),z))
rho={'ordinary':{'chi':scale(minus(scale(A0,Q(3)),ZW),Q('1/4')),'fixed':scale(minus(AW,A0),Q('1/8'))},'mixed':{'chi':scale(XX,Q('1/2')),'fixed':Mat(45,45)}}
images={}
for side,ts in [('left',T),('right',U)]:
 images[side]={}
 for family,terms in rho.items():
  images[side][family]={}
  for tag,m in terms.items():
   mm=[Mat(16,16) for _ in range(45)]
   for (i,c),z in m.d.items():mm[c]=plus(mm[c],scale(ts[i],z))
   images[side][family][tag]=list(map(enc,mm))
# Full broken routing controls cannot be repaired by a leading-pole test.
controls={'drop_heat_jet':{n:str(sy.factor(-jet[n]-fixed[n])) for n in fixed},'drop_dimension_jet':{n:str(sy.factor(-heat[n]-fixed[n])) for n in fixed},'drop_odd_heat_integral_longitudinal_finite':'1/8','wrong_auxiliary_inverse_orientation':True}
finish('primary',{'method':'critical_D_angular_positive_heat_jets_literal_source_direct_matrix','unit_poles':{n:str(z) for n,z in u4.items()},'finite_units':{n:str(z) for n,z in fixed.items()},'critical_D_coefficients':{n:str(z) for n,z in uv.items()},'critical_tensor_coefficients':critical,'heat_constants':{n:str(z) for n,z in heat.items()},'dimension_jets':{n:str(z) for n,z in jet.items()},'sigma':str(sigma),'chi_definition':str(chi),'mixed_unit_pole':'1/2','mixed_finite_fixed_unit':'0','source_tensor':[[*q,textq(v)] for q,v in sorted(source.items())],'source_counts':{'linear':nlinear,'cubic':ncubic,'all4_copies_equal':True},'source_linear_plane_remainder':0,'V':[[*q,textq(v)] for q,v in sorted(V.items())],'A':[[*q,textq(v)] for q,v in sorted(A.items())],'H':[[*q,textq(v)] for q,v in sorted(H.items())],'Qchart':enc(Qchart),'Qi':enc(Qi),'W':enc(W),'color_basis':{n:enc(v) for n,v in [('A0',A0),('AW',AW),('ZW',ZW),('Z0',Z0),('X',XX)]},'rho':{f:{n:enc(v) for n,v in t.items()} for f,t in rho.items()},'canonical_rho':{f:{n:enc(mul(mul(Qi,v),Qchart)) for n,v in t.items()} for f,t in rho.items()},'matter_q_images':images,'controls':controls,'frontier':P['frontier']['primary'],'ordinary_source_factor':'g10**2','mixed_source_factor':'g10*xi','ordinary_matter_factor':'g10**3','mixed_matter_factor':'g10**2*xi','q_matter_p_slot':'0','common_chi_chosen':False,'bosonic_source_finite_jet_extracted':True,'coupled_regulator_insertion_computed':False,'coupled_cancellation_claimed':False,'new_physical_scheme_adopted':False},start)
