# BSF1: finite source coefficient from the full heat and dimension jets

Prospective formulas;require paired calculation and gate. Unit source is
J_mu B_mu c;the three GF derivative placements are(da)BC,a(dB)C,aB(dC).
The qualified odd-source Born/Wick calculation gives their full kernels.
After the fixed Wick/source-derivative normalization let k be the vector
momentum,r=k-p the ghost momentum and G=(I+(w-1)kk.T/k2)/k2. Then

 Ka=-G(k)(k-p)/r2, KB=+G(k)k/r2, KC=-G(k)p/r2.

Their pointwise sum is0. Each is multiplied by exp[-2t(k2+r2)]. The same
factor on both inverse orientations follows from the flat scalar heat.
For shifted integration variable k=l+lambda p,the critical coefficients
on p_mu/l4 and l_mu(l.p)/l6 are

 a:(1-lambda*w, -1-w+4lambda*w),
 B:(lambda*w, 2w-4lambda*w), C:(-1,1-w).

The D-angular unit is u_D=a+b/D. At4 these are(3-w)/4,w/2,-(3+w)/4 in
1/(16pi2) units,half the old32pi2 convention. The first dimension derivative
must be taken BEFORE D4. The heat's linear-p expansion produces finite
constants h_a=w(2lambda-1)/4,h_B=-h_a,h_C=0. These come from a positive
heat jet multiplying a power radial integral,not the leading logarithm.

Write n_log for the already retained common logarithmic finite-part addition
(scale and kappa,in the fixed coordinate units),not a new parameter.
For s_D=area(S^(D-1))/(2pi)^D,set sigma=(d_D log s_D)|4. The complete
selected primitive coefficient has unit

 chi_4*u_4 +v, chi_4=gamma_E+log4-n_log-2sigma,
 v=-h-2u'_4.

The prospective v are(w-1)/8,0,(1-w)/8. Their IBP sum is0 and all are
routing independent even though h and u' individually are not. The scalar
measure gives sigma=-log2-(logpi+1-gamma_E)/2,so chi_4=1+log(16pi)-n_log.
No MSbar member is physically selected or finite freedom equated with b0.

An independent actual integral route is available at p_E2>0. With a=t p2,
the scalar heat bubble in16pi2 units is

 I_h=2E1(2a)-E1(a)+(exp(-a)-exp(-2a))/a,
 FP I_h=1-gamma_E-log4-log(p2)+n_log.

The unscaled raw dimensional bubble has FP
I_d=2-gamma_E+log(4pi)-log(p2). Their difference is chi_4. This is an
auxiliary normalization comparator,not adoption of another physical scheme.
Symmetric heat gives int k_mu/(k2 r2)=p_mu I_h/2. For the longitudinal
integral J_mu=int k_mu(k.p)/(k4 r2),the exact numerator identity yields

 J_mu=p_mu I_h/4+(p2/2)int k_mu/(k4 r2)
                        -(1/2)int k_mu/k4 exp[-2t(k2+r2)].

The middle convergent integral tends p_mu/(16pi2 p2). The last tends
p_mu/(64pi2),not0. A Schwinger substitution alpha=t v gives the normalized
last coefficient 2 int_0^infinity v/(v+4)^3 dv=1/4 with a bounded exponential.
Thus FP J_h=p_mu(I_h/4+3/8) in16pi2 units. Direct dimensional Feynman
parameters give J_d=p_mu(1/4+epsilon/2)I_d before pole subtraction,so its
extra finite term is1/2. Their difference is chi_4/4+1/8. Combining the
three unit numerators recovers the same v. Dropping the finite odd heat
integral would erase the1/8 correction. No scaleless or p0 IR limit is used.

The mixed source bubble's two actual inverse orientations combine to
p_mu/(2k2 r2) BEFORE integration. Its u_X=1/2 has no dimension jet and
its h_X=0. Its finite conversion is chi_4/2 times its action-derived color
tensor. The auxiliary ghost vertex has explicit xi but no g;ordinary and
mixed source orders remain g2 and g*xi separately.

Let S_b[i,a] be the actual source tensor. Current reduction gives V=UA-UB
and Fc=UC-UB=V-A,A=UA-UC. W=eta_H PH+xi PM acts on the internal B line.
Define A0=sum_b S_b A_b, Z0=sum_b S_b(2V_b-A_b),
AW=sum_br W_br S_b A_r, ZW=sum_br W_br S_b(2V_r-A_r).
Then the ordinary source matrices are

 P=(3A0-ZW)/4, R=(AW-A0)/8.

The mixed matrix is PX=sum_b S_b H_b/2. These signs are from the actual
ordered a,C density;literal canonical odd words must be reordered before
transport. Compare PX and P to the old UV inputs only after measurement.
The coefficient is

 rho_B=ell[g2(chi_4 P+R)+g*xi*chi_4 PX] partialC.

With GTT chart Q mapping raw fields to the new physical plane,the dual
source map gives rho_plane=Q rho_raw Q^-1. Primary transports all four
literal source copies;replay uses S_b[i,a]=f_ba^i after checking the actual
source bridge. Rho_raw is pulled back by Q^-1 rho_plane Q. Reality is tested
in the physical plane,not imposed on complex raw coordinates.

BME's additional matter Euler contribution is computed,not canceled here:
the -ig gamma_bar T_i current and Fourier partialC=+ip C give
Lq_c=sum_i rho^i_c T_i,with left/right actual U=-T.T. Its ordinary and
mixed coupling orders are g3 and g2*xi;the one-jet p slot is0. Retain both
chiralities,familyI3,all zeros,source sign and the original Nambu convention.
Any matching quantum regulator insertion remains a separate calculation.
