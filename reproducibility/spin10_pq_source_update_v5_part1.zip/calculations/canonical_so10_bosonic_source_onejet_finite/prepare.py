"""BSF1 action-only packet,withheld UV controls,fresh E4 and byte freeze."""
from pathlib import Path
from hashlib import sha256
import gzip,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';PRED=CAL/'canonical_so10_bosonic_matter_euler_interface'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/bosonic-source-onejet-finite-v1-2026-10-23');BASE='f9a03ce2daac73bc726f6aeb09ecf78101dd2199';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==31919
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V535.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_gauge_source_g2_canonical',['primary_result.json','replay_result.json','validation_receipt.json']),('canonical_so10_gauge_source_derivative_units',['units_v2.py','validation_v2_receipt.json','RECORD.md']),('canonical_so10_single_source_uv_frontier',['primary_result.json','replay_result.json','validation_receipt.json']),('canonical_so10_finite_heat_transgression',['DERIVATION.md','validation_receipt.json']),('canonical_so10_ordered_shear_finite_part',['DERIVATION.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for folder,names in [('frozen_a10_e5_source_vertex',['primary.json','replay.json','validation_receipt.json']),('frozen_a10_bv_master',['primary.json','replay.json'])]:
 for n in names:add(PK/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
action={'schema':'BSF1_CLASSICAL_ONLY','source_rows':{},'G':{},'Y':{},'frontier':{},'prior_loop_coefficients_included':False};control={'ordinary_canonical_32':{},'mixed_N_C3':{}}
for role in ['primary','replay']:
 master=read(PK/'frozen_a10_bv_master'/(role+'.json'))
 action['source_rows'][role]=[r for r in master['source_polynomial'] if any(re.fullmatch(r'JB\d+_[0-3]',n) for n in r['word'])]
 assert len(action['source_rows'][role])==3724
 G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion'/(role+'_tables.json.gz'));action['G'][role]={k:G[k] for k in ['plane_jets','plane_H','C3_chart','raw_Gca','raw_aux_map']}
 Y=packed(CAL/'canonical_so10_yukawa_carrier_transport'/(role+'_tables.json.gz'));action['Y'][role]={k:Y[k] for k in ['Tminus','H_new']}
 action['frontier'][role]=read(CAL/'canonical_so10_single_source_uv_frontier'/(role+'_result.json'))['targets']['C_JB__j1']
 control['ordinary_canonical_32'][role]=read(CAL/'canonical_so10_gauge_source_g2_canonical'/(role+'_result.json'))['new_actual_g2_node']
 control['mixed_N_C3'][role]=read(PK/'frozen_a10_e5_source_vertex'/(role+'.json'))['actual_internal_group']['ghost_endomorphism_C3']
action['plane_f']=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']
gz(HERE/'qualified_action_inputs.json.gz',action);gz(HERE/'validation_control_inputs.json.gz',control)
add(HERE/'qualified_action_inputs.json.gz');add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
assert r.returncode==0
dump(CONTROL/'readiness_result.json',{'command':['python','-B','tools/research_check.py','e4'],'native_exit':r.returncode,'fresh_command':True,'scientific_replay_requested':False,'custody_expected_exit':2,'custody_expected_unresolved':7,'scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and d['files_written']==0 and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'BSF1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('BSF1_FROZEN',len(bind),'bindings',flush=True)
