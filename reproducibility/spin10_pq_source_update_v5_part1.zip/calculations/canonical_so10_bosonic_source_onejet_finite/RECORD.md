# BSF1: finite first gauge-source jet of the specified bosonic primitive

Basef9a03ce2daac73bc726f6aeb09ecf78101dd2199/main31919 oldblobs. Previous
goalturn PROGRESS(VPR,VMA,BME). WholeSpin(10)xPQ ACTIVE/incomplete.
LiveAGENTS,state113/34of39 unchanged. BME isolated three relevant first
source-jet carriers. Start the complete JB partialC channel,retaining both
ordinary SB*F(g2) and mixed SB*X(g*xi) bubbles from the qualified frontier.
The lower explicit-xi vertex has NO g;it cannot be absorbed into the ordinary
width or omitted. Positive-dimension/background carriers remain separate.

Question:extract this source jet of the actual dimensional-Stokes bosonic
representative C0=-Lheat-(i/2)alpha'_4(LD),and its induced matter Euler map.
Use the fixed scalar-principal heat P=p2 I at background0,actual damped
propagators F G F,nonexceptional p_E2>0 and the same lifted measure s_D.
No new physical regulator,MSbar conversion,baseline,flavor/mass/width value
or finite normalization is adopted. C0 is a particular specified formal
bosonic primitive,not a claimed complete coupled chiral counterterm.

Same mass-independent coefficient-dimension0 one-loop local ring. Target
JB dimension2,C dimension1,one derivative,totaldimension4/ghost0/even.
All45x45 ordered source/ghost coefficients,all4 Lorentz copies/zero
complements,full mixed propagator orientations and all45 current generators
are required. Local source jet is differentiated before source0. Gamma_ref
is source independent,not discarded globally. Mass/vacuum insertions cannot
supply this dimension-zero UV-local coefficient;their amplitudes are not0.

Primary derives D-angular critical jets and the positive-t heat constant
before taking the dimension derivative. Replay evaluates the actual
nonexceptional bubble/vector integrals:Schwinger heat,Feynman dimensional
integrals and a convergent remainder. The finite odd shifted heat integral
must remain. Routing changes affect heat and dimension pieces separately;
their complete local conversion must be routing invariant. The two Born/
Wick units and source/GF action vertices are qualified reuse,not new diagrams.

Use an action-only packet:literal JB B C/linear source rows,GTT primary/
replay classical GF jets/H and source charts,actual f,T,H_new. Primary
transports the literal source through primal/dual frames;replay constructs
the adjoint source directly. No proper pole supplies a new finite value.
Previous ordinary/mixed UV matrices are kept in a validation-only packet,
denied to workers after authentication and used as normalization comparators
only after both finite calculations complete. Explicit odd ordering matters.

Retain the ONE common coefficient chi_4 defined by the frozen scalar critical
heat-minus-hard normalization and s_D derivative. Keep the existing common
scale/kappa symbolic;chi_4 is a named combination,not an additional freely
chosen physical constant. It is distinct from b0 and all invariant freedoms.
Represent rho as chi_4*P+R with polynomial eta_H,xi matrices. Never choose
chi_4 to cancel a Ward remainder. The same chi_4 applies to both bubbles.

Expected evidence:all source/GF tensors and every2025 rho matrix slot agree;
critical/angular/heat constants and direct finite integral differences agree;
both coupling orders and right/left induced matter maps/zeros agree;all12H
intertwining and physical reality;UV comparisons agree in their exact prior
normalizations. Unitwidth is counterfactual,not adopted. Controls omit heat
jet,dimension jet,conjugate/odd orientation,one Born word,GF C derivative,
mixed propagation and full width structure;preserve insensitive cases.
No complete coupled quantum insertion/cancellation is inferred from rho.

Freeze eight sources/copies,packet,inputhashes,derivation/limits first.
Sequential primary/replay/gate each600s afterimports,8GiB sampledprivatecap,
350MiB availablecommit launchfloor,16MiBpacketcap. Fresh E4 thisgoalturn
and bytepreflight fully captured. Custodyexit2/sevenNOTPASS. Firstfailure
stops;preserve original sources/full captures;new version corrections only.
No resourceexpansion,truncation,repeated expensive qualified kernel or agents.

Ceiling:selected bosonic finite source jet plus its actual matter Euler
companion,not coupled chiral-restoration/QAP/products/measure/phase,massiveC1,
E5/A5 or physicalunification. Scalarwarnings,quartetFAIL,flavorpause,HB1/C5,
custody/freeconstants remain. Main/state/oldbytes unchanged;no branches,
worktrees,physicaladoption,outreach/publication/push. Shared physics,charts,
data,software and AIauthor are not independent scientists. If qualified,
continue the indispensable coupled regulator/source transport or next
finite source carrier without treating this local extraction as globalproof.
