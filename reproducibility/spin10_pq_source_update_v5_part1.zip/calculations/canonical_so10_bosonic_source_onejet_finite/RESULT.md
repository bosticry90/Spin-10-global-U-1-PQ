# BSF1: the finite gauge-source jet and matter Euler companion are nonzero

Qualified receipt SHA256
d162225d8a2c9b562a594ce1c4afc4464b2448f96ceb872fe61d067e85022ded:
QUALIFIED_BOSONIC_SOURCE_ONEJET_FINITE_COEFFICIENT. The selected JB partialC
jet of the specified dimensional-Stokes bosonic representative is now
extracted. The result includes both ordinary and mixed-auxiliary bubbles.
It does not establish their coupled quantum-regulator cancellation.
State113/authority34of39 unchanged;scientific acceptance NOT_PERFORMED.

With ell=1/(16pi2),the real physical-plane coefficient is

 rho_B=ell[g10²(chi_4 P+R)+g10*xi*chi_4 PX] partialC,
 P=(3A0-ZW)/4, R=(AW-A0)/8, PX=sum_b S_b H_b/2.

All matrices and their raw canonical pullbacks are in the paired tables.
In DERIVATION notation,A0=sum S_b A_b,AW=sum W_br S_b A_r,
ZW=sum W_br S_b(2V_r-A_r),A=UA-UC,V=UA-UB. W retains independent eta_H
and xi. The explicit auxiliary vertex has xi and NO g;its orderg*xi is
distinct from ordinaryg² and from width dependence inside W.

| Matrix direction | Nonzero physical-plane entries | Nonzero induced matter entries/chirality |
| --- | --- | --- |
| Ordinary chi_4 coefficient P | 105 | 720 |
| Ordinary fixed finite R | 105 | 720 |
| Mixed chi_4 coefficient PX | 105 | 592 |
| Mixed fixed piece | 0 | 0 |

These are coefficient positions,not independent experiments. The mixed
finite contribution is not0 merely because its fixed piece is0. The ONE
common chi_4 is retained for both families:

 chi_4=gamma_E+log4-n_log-2(d_D log s_D)|4
      =1+log(16pi)-n_log,
 s_D=area(S^(D-1))/(2pi)^D.

n_log denotes the inherited common logarithmic finite-part addition(scale
and kappa,in the fixed coordinate units). It is not an extra mixing or
physical parameter,and is not identified with b0. No value of chi_4,mu,
kappa,width,gauge coupling or flavor matrix was selected. Other admitted
Q-closed finite additions to the bosonic primitive are not classified here.

Primary obtains the coefficient from the actual full D-angular critical
symbol and its first dimension derivative,plus the positive heat jet.
Replay obtains it from nonexceptional heat/Schwinger and dimensional
Feynman integrals. The longitudinal heat integral has finite extra3/8;
the raw dimensional one has1/2. Their1/8 difference gives the fixed units

 v_a=(w-1)/8, v_B=0, v_C=(1-w)/8.

The odd shifted heat integral contributes1/4 before its coefficient-1/2
in the numerator identity. It cannot be dropped as an odd integral:its
heat weight is shifted. Heat and dimension pieces separately depend on
loop routing;their complete finite conversion does not. The unit IBP sum
is0. These are actual finite integral checks,not deductions from a pole.
The auxiliary inverse orientations combine to p_mu/(2k²r²) before any
integration,so its fixed dimension/heat remainder vanishes legitimately.

The primary transports3544 literal source cubic rows and180 linear rows,
checking allfour Lorentz copies and the evaluation-dual source frame.
Replay reconstructs the source adjoint directly. All91125 possible tensor
entries agree(720 nonzero),as do all8100 rho matrix entries and92160
induced left/right matter-image entries,including zeros. The full rank-two
Lorentz lift covers129600 component positions using the all16 critical
tensor checks and identical source copies;this is a factorized proof,not
129600 independent numerical integrations. The old ordinary32pi2 pole and
mixed source endomorphism agree on8100 comparator positions after proper
odd-word reordering and frame transport. They were withheld from workers
after byte authentication and did not determine finite coefficients.

Every rho coefficient is real in the physical plane,all12 H endomorphism
commutators vanish,and the induced matter maps are Hermitian with actual
right=-left.T. The matter Euler current -ig gamma_bar T and Fourier
partialC=+ip C give Lq_c=sum_i rho^i_c T_i. Their orders are g³ andg²*xi;
the p-on-fermion slot is0. General familyI3 is retained,without an extra
closed-family3 or Nambu half. The canonical raw matrices need not be real
under an unqualified bare conjugation.

Omitting either dimension jet,positive heat jet or the finite odd integral
changes105 ordinary fixed entries. Omitting the GF external-C derivative
changes80;omitting mixed propagation loses105 mixed chi coefficients.
One Born word halves a nonzero result. At eta_H=xi=1 the fixed R is0;
this counterfactual limit is correctly insensitive and is not an adopted
physical gauge or a substitute for the symbolic result.

Execution and failures are preserved. Original primary FAILED1 on a
structural equality of factored and expanded expected units,before model
output. V2 normalized differences were all0;primary then completed. V2
replay FAILED1 on the same class of structural sum comparison;V3 normalized
both IBP sums to0 and completed. V3 gate FAILED1 on different legacy edge
index orderings. V4 canonicalized every typed edge,external role and jet,
requiring allnine witnesses and every other frontier field to agree. No
profile,coefficient,physical assumption or acceptance condition was removed.
Original/V2/V3 sources,copies,preparations,captures and controller failures
remain intact. These two native implementation failures and one gate-design
failure are limitations of the AI workflow,not additional scientific tests.

Completed primary_v2,replay_v3,verify_v4 native0 at5.1803573/2.0046640/
1.6964787s afterimports. Successful calculation bytes were authenticated
and reused rather than rerun during verifier corrections. Samples4/2/2,
private maxima67358720/61063168/64532480B are sparse observations,not peaks.
Failed primary/replay/gate samples2/2/1,max59240448/61104128/393216B.
All600s/8GiBsampled/350MiBfloor/16MiBpacket bounds held.26 frozen source
copies;496/516/537/542/557/559 bindings across preparation/validation versions.
Fresh current-turn E4 native0 with step exits0,0,0,0,0,2;later versions reuse
those bytes and add byte preflights. Custodyexit2/sevenNOTPASS,not globalPASS.
Full external records:bosonic-source-onejet-finite-v1-2026-10-23.

Primary packed5040e9dd5caa01d354784d76fa95d0529723df23aa455852667b558186732dbd,
raw822371ed45b0e73ff3b6e7a16de903b687fa4064761af0c46bd4a74a300ec1a6.
Replay packed05333753238212fd1918698c0b20096d56ea84d07895b1b2f0fc147d393aecb3,
raw915cd019af7919a42944d961b77c1e99791eb47b1f8433953a317d6f0889c185.

Scientific consequence:the bosonic finite source correction has an actual
nonzero matter Euler image. It cannot be declared absent when combining
the separately completed bosonic and fermionic restorations. The next
small test is the compatibility of that direct sum with the fixed CFC
one-jet cancellation,retaining common chi_4 symbolically. Any remainder
must be classified as a missing coupled transport contribution,not an
anomaly or failure of Spin(10). The matching regulated coupled insertion
and the other two first-source carrier families remain uncomputed here.

No complete coupled chiral restoration,QAP/products/measure/phase,massive
C1,E5/A5 or physicalunification follows. The scalar warnings,quartetFAIL,
flavorpause,HB1/C5blocks,custody and distinct free normalizations remain.
No canonical physical action or partial Gamma was changed. Shared action,
regulator,geometry,data,software and AI author limit agreement to internal
computational/analytic corroboration,not independent scientific validation.
