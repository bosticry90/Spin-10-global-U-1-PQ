# ABY1: a strict-four-dimensional zero need not have zero finite part

At zero background, the full SMA mixed inverse has
G_PS=G_SP=-i hat_slash(k)/Q, Q=k2. FBR1 fixes the new S reference vertex
V_S=-ig bar_gamma_mu B(T), B=PR T-PL T.T. Its contribution is the ordered
PP inverse response -G_PS V_S G_SP, with a physical Yukawa vertex at each
end. This term is absent from the historical action-vertex calculation.

For the YdaggerY orientation the outside spin projectors are PR and PL.
The S vertex selects -T.T; the symmetric hatted spin contraction gives

 PR hat_gamma_i bar_gamma_mu (PR-PL) hat_gamma_j PL
   + (i<->j) = 2 delta_ij bar_gamma_mu PL.

The opposite chirality has the opposite sign and the conjugate ordered
color. This uses hat/chirality commutation and hat/bar anticommutation;
it does not replace internal hats by zero or perform a four-dimensional
closed chiral trace. Summing the formal hatted rank h=D-4 gives u(D)=h/D
against the reference angular sphere. The inherited open-line Gaussian
phase is i, to be independently checked. Define

 X_R,h = sum_i b_R,i dagger T_H,h.T b_R,i.

All328 real maps and their canonical complement are retained. The left
current is i*u(D)*X_R,h times the normalized critical radial integral and
Y_RdaggerY_R; the right orientation is its required negative transpose with
Y_R Y_Rdagger. Each internal color is a16x16 matrix, not a family trace.

Primary uses the same mathematical IR completion exp(-m2/Q) as the earlier
critical finite units. Its normalized radial factor is
(4pi)^epsilon Gamma(epsilon) m2^(-epsilon)/Gamma(2-epsilon).
Replay instead uses the massive Schwinger Gaussian:

 16pi2 integral hat_k2/(k2+m2)^3
   = (h/4)(4pi)^epsilon Gamma(epsilon) m2^(-epsilon).

Both must be derived from the actual numerator, and both have zero pole
but a potentially nonzero finite part. Their difference has zero limit.
No finite heat term occurs for this numerator in strict4D, because its
mixed propagators vanish identically there. This is a declared relative
local-UV result with shared IR completions, not a full nonexceptional
background amplitude. No heat/Duhamel term from other placements is omitted
from a claimed complete answer: those are explicitly outside this result.

The pure auxiliary reference determinant depends only on background fields,
so its derivative cannot change this external-P2 coefficient. That degree
argument does not discard its pure-background contribution or phase.
The independently known action fermion-current pole is a late comparator;
it must not determine this new reference-current finite coefficient.
