# ABY1: evanescent auxiliary background current in the Yukawa vertex

Base d767da7d069dfd92fb923465685d45ad02cb41b2/main32891 blobs. State113,
authority34/39 unchanged. FBR1 constructs a provisional background member,
not a physical scheme. Its auxiliary S current is required by hatted mixing,
although qS=0 and all actual quantum Yukawa vertices still act on P.

Question: does that S reference current between two mixed P-S propagators
produce a finite g10 YdaggerY one-H-background local coefficient? This tests
an omitted ingredient before a complete background Ward comparison. The
least expensive competent test is the mass-independent critical UV symbol,
using qualified full real328 scalar/Yukawa maps and a common positive IR
completion; no massive threshold or flavor fit is needed.

Freeze FBR1 actual receipt/recipe/captures/custody, SMA1 action and split
Clifford assumptions, YCT1 maps/generators/H_new, and YGV1 Gaussian phases,
source convention and replay color contractions. Physical external indices
and momenta are barred, p_hat=0. Internal hats and D=4-2epsilon remain until
integration. The new current is a REFERENCE contribution, not an old physical
action vertex. Scalar heat is evaluated at strict4D after the same declared
local subtraction. There is one open line, no Pfaffian half or family3.

Primary contracts explicit split16-spin mixed propagators and both chiral
Yukawa endpoints, evaluates literal sums over every supported real scalar
and all12 H generators, and obtains the angular/radial Gamma integral with
an auxiliary exp(-m2/Q). Replay uses the independent old Clifford-grade/Sym16
color result projected into H, a chirality-block mixed inverse response and
ordinary massive Gaussian Schwinger integral. The two different positive
IR completions test the universal evanescent UV constant, not a physical
infrared prescription. Full generic complex symmetric family products are
retained and compared. Workers cannot read peer or late current targets.

Freeze eight source copies, immutable inputs, methods, failure criteria and
bounds before execution. Sequential primary/replay/gate,600s afterimports
each,8GiB sampled private,350MiB launch availablecommit,16MiB stored packet.
Reuse this turn's actual E4 audit, preserving exit2/sevenNOTPASS. Retain all
failures; versioned repairs only. No mismatch may be repaired by changing a
reference charge, Yukawa map, sign, target or physical normalization. A
resource stop is incomplete. Gate compares all color/family zeros and only
then checks the previous physical-action fermion-current comparator.

Controls omit the auxiliary current, set hat rank0 before pole extraction,
insert an extra half/family3, or reverse the independently derived finite
sign. Detect whether each changes the actual answer; do not credit a zero
projection as a sensitive control. Auxiliary pure-background Pfaffian has
no P2 coefficient by field degree, but its full normalization remains open.

Ceiling: one finite local auxiliary-reference gY2 background coefficient.
Not complete background vertex, finite Ward restoration, all heat/Duhamel
terms, positive-mass construction, full products/QAP/measure/phase, adopted
scheme, matterC1, E5/A5 or physical GUT. Both scalar failures, quartetFAIL,
paused flavor, blockedHB1/C5, independent finite constants and custody stay.
Shared action, Clifford/dimensional premises, inherited color proof, software
and AI author limit independence. No agents, branches/worktrees, external
actions, publication/push or scientific promotion. Validate before local
commit, then continue the most informative missing background ingredient.
