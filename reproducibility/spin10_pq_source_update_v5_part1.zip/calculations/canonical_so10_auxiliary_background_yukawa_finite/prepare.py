"""ABY1 freeze actual candidate reference and independent color routes."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_fermionic_background_reference'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/auxiliary-background-yukawa-finite-v1-2026-10-23');OLD=CONTROL.with_name('fermionic-background-reference-v1-2026-10-23')
BASE='d767da7d069dfd92fb923465685d45ad02cb41b2';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/name;add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32891
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
assert digest(PRED/'validation_receipt_v2.json')=='2bce95c8003e5b87e8de85e3f7fcf801a5b359fd690877105bb69beb85c6f706'
for n in ['validation_receipt_v2.json','verify_v2_capture.json','RESULT.md','validation_preparation_v2.json','candidate_background_reference.json.gz']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json','readiness.jsonl','readiness_result.json','readiness_stderr.txt']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'readiness_result.json')['step_exits']==[0,0,0,0,0,2]
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V559.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
YV=CAL/'canonical_so10_yukawa_dependent_gauge_vertices'
for n in ['RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json']:add(YV/n)
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables.json.gz');bg=source(PRED.name,role+'_tables_v2.json.gz');v=source(YV.name,role+'_tables.json.gz')
 d={'Y':{k:y[k] for k in (['Tminus','H_new','B10','B126'] if role=='primary' else ['Tminus','H_new'])},'carrier_S':bg['carrier_S']}
 if role=='replay':d.update({'X_internal':v['X_internal'],'scalar_supports':v['scalar_supports']})
 gz(HERE/(role+'_inputs.json.gz'),d);add(HERE/(role+'_inputs.json.gz'))
y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');v=packed(YV/'primary_tables.json.gz');gz(HERE/'validation_control_inputs.json.gz',{'H_new':y['H_new'],'fermion':v['outputs']['fermion']});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'ABY1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'current_turn_E4_authenticated_reuse':True,'scientific_acceptance':'NOT_PERFORMED'})
print('ABY1_FROZEN',len(bind),'bindings',flush=True)
