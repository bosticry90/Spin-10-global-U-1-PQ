"""ABY1 independent Weyl blocks, Gaussian Schwinger rank and inherited grade2 color."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');I=s.eye(2);Z=s.zeros(2);sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[block(Z,-s.I*z,s.I*z,Z) for z in sigma]+[block(Z,I,I,Z)];L4=s.diag(1,1,0,0);R4=s.eye(4)-L4
bars=[s.kronecker_product(z,s.diag(1,-1)) for z in g4];hats=[s.kronecker_product(s.eye(4),z) for z in sigma[:2]];L=s.kronecker_product(L4,I);R=s.kronecker_product(R4,I);spinpos=0
for gam in bars:
 for h1 in hats:
  for h2 in hats:
   delta=int(h1==h2)
   for outside,inside,sgn in [(R,L,1),(L,R,-1)]:zero(outside*(h1*gam*(R-L)*h2+h2*gam*(R-L)*h1)*inside/2-sgn*delta*gam*inside);spinpos+=8**2
# Schur response fixes the open-line sign independently of a loop target.
f,a,b,c,t=s.symbols('f a b c t',nonzero=True);schur=s.det(s.Matrix([[a,b],[c,f+t]]))/(f+t);response=s.simplify(s.diff(schur,t).subs(t,0)/(b*c/f**2));phase=s.simplify(response*(-s.I)**2*(-s.I));assert response==1
D=s.Symbol('D');eps,m2,tau=s.symbols('epsilon m2 tau',positive=True);h=D-4
# Integral of the Gaussian hatted rank times the cubic propagator Schwinger weight.
# int d^D k hatk2 exp(-tau k2) = (h/(2tau))*(pi/tau)^(D/2).
power=s.simplify(2-1-D/2);assert power==1-D/2
radial=s.gamma(2-D/2)*m2**(D/2-2);expr=(h/4*(4*s.pi)**((4-D)/2)*radial).subs(D,4-2*eps);pole=s.limit(eps*expr,eps,0);finite=s.limit(expr,eps,0)
unit=(D-4)/D;assert pole==0
T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);TH=[]
for j in range(12):TH.append(tidy(sum((T[a]*H[a,j] for a in range(45) if H[a,j]),s.zeros(16))))
X45=[[dec(v) for v in row] for row in d['X_internal']];XS=[];left=[];right=[]
for row in X45:
 xx=[tidy(sum((row[a]*H[a,j] for a in range(45) if H[a,j]),s.zeros(16))) for j in range(12)];XS.append(list(map(enc,xx)));left.append([enc(phase*finite*v) for v in xx]);right.append([enc(-phase*finite*v.T) for v in xx])
for th,aux in zip(TH,d['carrier_S']):zero(s.kronecker_product(R4,th)-s.kronecker_product(L4,th.T)-dec(aux))
fam=[];fleft=[];fright=[]
for tag in ['10','126']:
 y=s.zeros(3)
 for i in range(3):
  for j in range(i,3):y[i,j]=y[j,i]=s.Symbol(f'u{tag}_{i}{j}',real=True)+s.I*s.Symbol(f'v{tag}_{i}{j}',real=True)
 fam.append(enc(y));fleft.append(enc(s.Matrix(3,3,lambda i,j:s.expand(sum(s.conjugate(y[k,i])*y[k,j] for k in range(3))))));fright.append(enc(s.Matrix(3,3,lambda i,j:s.expand(sum(y[i,k]*s.conjugate(y[j,k]) for k in range(3))))))
finish('replay',{'method':'independent_Weyl_hat_blocks_Gaussian_Schwinger_rank_and_inherited_grade2_color_projection','spin_positions_checked':spinpos,'unit_D':str(unit),'pole':str(pole),'finite_unit':str(finite),'Gaussian_phase':str(phase),'X_H':XS,'left':left,'right':right,'T_H':list(map(enc,TH)),'scalar_supports':d['scalar_supports'],'family_Y':fam,'family_left':fleft,'family_right':fright,'strict4D_auxiliary_heat_current_zero':True,'pure_background_auxiliary_factor_P2_zero_by_field_degree':True,'general_family_no_trace_no_extra3_or_half':True,'physical_action_vertex_changed':False},tick)
