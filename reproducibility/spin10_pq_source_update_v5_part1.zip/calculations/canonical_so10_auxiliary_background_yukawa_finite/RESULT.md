# ABY1: a finite auxiliary-reference Yukawa background contribution

Qualified within FBR1's declared provisional reference and local UV domain:
`QUALIFIED_FINITE_EVANESCENT_AUXILIARY_REFERENCE_YUKAWA_BACKGROUND_CURRENT`.
Receipt SHA256 `f2bbc9037a59fd9d8ce20aaa57efd62c327d221b13c99cdd6ec3c5dee605190d`. Scientific/director acceptance not performed;
state113 and authority34/39 remain unchanged.

The new auxiliary reference background current between two actual mixed
P-S propagators gives, in the common g10/(16pi2) current convention,

```
left_R,h = -i/2 * (Y_RdaggerY_R) tensor X_R,h,
X_R,h = sum_i b_R,i dagger T_H,h.T b_R,i.
```

The conjugate-right current is the negative transpose with Y_R Y_Rdagger.
There is no extra open-line half or family3. The full real328 scalar maps,
including their zero complement, and all twelve actual H directions are
retained. The independent inherited grade-two/Sym16 contraction gives
X_10,h=-(3/8)T_H,h and X_126,h=(7/8)T_H,h; equivalently the new left
internal coefficients are +(3i/16)T_H,h and -(7i/16)T_H,h. These are relative
reference-current coefficients, not fitted or measured physical couplings.

The ordered numerator has angular unit (D-4)/D. Its pole is zero while its
finite radial integral is -1/2. Primary checks explicit split16-spin mixed
propagators and sums the real scalar products literally. Replay uses distinct
Weyl/hat blocks, a Gaussian Schwinger integral and the independently qualified
Clifford-grade color result projected into H. The two mathematical positive
IR completions give the same evanescent UV finite constant. Neither selects
a physical mass or claims a complete nonexceptional amplitude.

At strict4D the mixed propagators and this auxiliary-current heat contribution
are identically zero. Setting internal hat rank0 before extracting the
dimensional finite part would therefore lose a nonzero term. The finite
constant is independent of chi4 and the heat-length logarithm in this scope.
The pure auxiliary Pfaffian has no P2 coefficient by field degree; that does
not discard or normalize away its pure-background effective action or phase.

Primary/replay and the gate agree on12,288 internal left/right current
positions including zeros,36 generic family polynomials, and a factorized
lift covering110,592 full48x48 current positions. Each carrier and chirality
has107 nonzero internal positions. Dropping this term, prematureD4, an extra
half/family3 or reversed sign changes428 combined internal positions.
Only after calculation, the gate compares the earlier physical-action
fermion-current pole: the new finite current equals its negative in every
retained H coefficient. That is a late numerical/algebraic comparison, not
the source of the new coefficient and not the complete background Ward test.

## Execution and interpretation

Eight source copies and1988/1996 preparation/validation bindings precede
sequential workers. Native exits0; primary/replay/gate8.172928/3.995858/
3.998538s after imports,5/3/3 memory samples, maxima58,798,080/55,844,864/
53,796,864 bytes (sampled, not continuous peaks). Pre-report packet865,146B.
All600s/8GiB/350MiB/16MiB limits respected; no failed worker or controller.
This turn's completed fresh FBR E4 is authenticated reuse here, not a new
scientific replay. Historical custody remains exit2/seven unresolved,
NOTPASS. Before/index/after seals protect all32891 old tracked blobs.

This supplies an indispensable missing background-reference input. It does
not complete the regulated background derivative: inverse placement changes
the heat weights, and first variations of both heat operators on fermion
and scalar edges can leave finite power terms. Derive those from the ordered
FBR filter before comparing their sum with FHK/VFC. Do not assign them from
a desired Ward cancellation. Keep the reference determinant and general
family factors explicit. The earlier action vertices retain their original
scope; they were not incorrect calculations of this newly specified member.

Full background Ward/Slavnov restoration, all Duhamel terms, quantum source
products, measure/Pfaffian phase, positive masses, an adopted scheme, massive
matterC1, E5/A5 and physical GUT remain unqualified. Shared action, dimensional
Clifford assumptions, inherited color proof, software and AI authorship limit
independence. Both adverse scalar points, quartetFAIL, paused flavor, blocked
HB1/C5, finite freedoms and custody are preserved. No authority or historical
file changed, no agents/branch/worktree/external actions occurred. Whole goal
remains ACTIVE and incomplete.
