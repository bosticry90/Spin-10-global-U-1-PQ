"""ABY1 exact finite and late action-current comparison, including zeros."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['unit_D','pole','finite_unit','Gaussian_phase','scalar_supports','family_Y','family_left','family_right']:assert P[k]==R[k],k
assert P['pole']=='0' and P['finite_unit']=='-1/2' and P['Gaussian_phase']=='I'
assert P['scalar_supports']==[list(range(306,326)),list(range(54,306))]
for a,b in zip(P['T_H'],R['T_H']):zero(dec(a)-dec(b))
positions=0;counts={}
for side in ['left','right']:
 counts[side]=[]
 for pp,rr in zip(P[side],R[side]):
  nn=0
  for a,b in zip(pp,rr):
   A,B=dec(a),dec(b);assert A.shape==B.shape==(16,16);zero(A-B);zero(A+A.H);positions+=256;nn+=nz(A)
  counts[side].append(nn)
assert positions==12288
for key in ['X_H']:
 for pp,rr in zip(P[key],R[key]):
  for a,b in zip(pp,rr):zero(dec(a)-dec(b))
H=dec(late['H_new']);pole=late['fermion'];cmp=0
for side in ['left','right']:
 for j,src in enumerate(pole[side]):
  rows=list(map(dec,src))
  for h in range(12):zero(dec(P[side][j][h])+sum((H[a,h]*rows[a] for a in range(45) if H[a,h]),s.zeros(16)));cmp+=256
assert cmp==12288
for ll,rr in zip(P['left'],P['right']):
 for a,b in zip(ll,rr):zero(dec(a).T+dec(b))
loc={str(z):s.Symbol(str(z),real=True) for row in P['family_Y'] for i,j,v in row['entries'] for z in s.sympify(v).free_symbols}
def fdec(m):return s.Matrix(*m['shape'],lambda i,j:s.sympify(next((z for a,b,z in m['entries'] if (a,b)==(i,j)),'0'),locals=loc))
for y,l,r in zip(P['family_Y'],P['family_left'],P['family_right']):
 Y,L,R0=map(fdec,[y,l,r]);zero(Y-Y.T);zero(L-Y.H*Y);zero(R0-Y*Y.H);zero(L-L.H);zero(R0-R0.H)
controls={'omit_auxiliary_or_premature_hat0':sum(sum(v) for v in counts.values()),'extra_open_half':sum(sum(v) for v in counts.values()),'extra_family3':sum(sum(v) for v in counts.values()),'reverse_finite_sign':sum(sum(v) for v in counts.values())}
for k,v in controls.items():assert v>0
for d in [P,R]:assert d['strict4D_auxiliary_heat_current_zero'] and d['general_family_no_trace_no_extra3_or_half'] and d['pure_background_auxiliary_factor_P2_zero_by_field_degree'] and not any(d[k] for k in ['physical_action_vertex_changed','finite_complete_background_vertex','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_FINITE_EVANESCENT_AUXILIARY_REFERENCE_YUKAWA_BACKGROUND_CURRENT','elapsed_after_imports':time.perf_counter()-tick,'color_positions_compared':positions,'late_action_fermion_current_positions_compared':cmp,'family_polynomial_positions_compared':36,'factorized_48by48_current_positions_covered':2*2*12*48**2,'scalar_inputs':328,'H_directions':12,'finite_left':'-I/2 * sum_i b_i_dagger T_H_transpose b_i','finite_right':'negative_left_transpose_with_Y_Ydagger','zero_pole_nonzero_finite':True,'finite_unit':'-1/2','hat_unit_D':'(D-4)/D','nonzero_internal_positions':counts,'negative_control_changed_positions':controls,'equals_negative_previous_action_fermion_current_pole_as_late_comparison':True,'strict4D_positive_heat_term_zero':True,'full_background_vertex_or_Ward_restoration_qualified':False,'all_Duhamel_or_scalar_background_terms_assembled':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
