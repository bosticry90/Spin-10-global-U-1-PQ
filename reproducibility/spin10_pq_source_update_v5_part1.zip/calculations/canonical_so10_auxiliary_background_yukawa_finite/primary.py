"""ABY1 direct split-Clifford numerator and all real scalar products."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]];g=[s.kronecker_product(z,s.eye(2)) for z in g8];chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));L=(s.eye(16)+chi)/2;R=s.eye(16)-L;spinpos=0
for mu in range(4):
 for i in [4,5]:
  for j in [4,5]:
   for outer,inner,sgn in [(R,L,1),(L,R,-1)]:
    z=outer*(g[i]*g[mu]*(R-L)*g[j]+g[j]*g[mu]*(R-L)*g[i])*inner/2
    zero(z-sgn*int(i==j)*g[mu]*inner);spinpos+=16**2
# Direct inverse response has two -i mixed inverses and one -i current.
z=s.Symbol('z');F=s.Matrix([[2,1],[1,3]]);V=s.Matrix([[0,z],[z,0]]);zero(s.diff((F+z*V.subs(z,1)).inv(),z).subs(z,0)+F.inv()*V.subs(z,1)*F.inv());phase=s.simplify((-s.I)**2*(-s.I));assert phase==s.I
D=s.Symbol('D');eps,m2=s.symbols('epsilon m2',positive=True);h=D-4;unit=h/D
rad=(4*s.pi)**eps*s.gamma(eps)*m2**(-eps)/s.gamma(2-eps);expr=unit.subs(D,4-2*eps)*rad;pole=s.limit(eps*expr,eps,0);finite=s.limit(expr,eps,0);assert pole==0
Y=d['Y'];T=list(map(dec,Y['Tminus']));H=dec(Y['H_new']);TH=[tidy(sum((H[a,j]*T[a] for a in range(45) if H[a,j]),s.zeros(16))) for j in range(12)];maps=[dec(Y[k]) for k in ['B10','B126']]
L4=s.diag(1,1,0,0);R4=s.eye(4)-L4
for th,aux in zip(TH,d['carrier_S']):zero(s.kronecker_product(R4,th)-s.kronecker_product(L4,th.T)-dec(aux))
XS=[];left=[];right=[];support=[]
for B in maps:
 mats=[s.SparseMatrix(16,16,{(f//16,f%16):z for (f,col),z in B.todok().items() if col==i}) for i in range(328)];active=[i for i,m in enumerate(mats) if m.todok()];support.append(active);xx=[];ll=[];rr=[]
 for th in TH:
  xl=tidy(sum((mats[i].H*th.T*mats[i] for i in active),s.zeros(16)));xr=tidy(sum((mats[i]*th*mats[i].H for i in active),s.zeros(16)));zero(xr-xl.T);xx.append(enc(xl));ll.append(enc(phase*finite*xl));rr.append(enc(-phase*finite*xr))
 XS.append(xx);left.append(ll);right.append(rr)
print('STAGE COMPLETE_REAL_SCALAR_SUMS_ALL12_H',flush=True)
loc={n:s.Symbol(n,real=True) for tag in ['10','126'] for i in range(3) for j in range(i,3) for n in [f'u{tag}_{i}{j}',f'v{tag}_{i}{j}']};fam=[];fleft=[];fright=[]
for tag in ['10','126']:
 y=s.Matrix(3,3,lambda i,j:loc[f'u{tag}_{min(i,j)}{max(i,j)}']+s.I*loc[f'v{tag}_{min(i,j)}{max(i,j)}']);fam.append(enc(y));fleft.append(enc((y.H*y).applyfunc(s.expand)));fright.append(enc((y*y.H).applyfunc(s.expand)))
finish('primary',{'method':'literal_split16_mixed_inverse_numerator_real328_scalar_sums_and_inverse_radial_IR_completion','spin_positions_checked':spinpos,'unit_D':str(unit),'pole':str(pole),'finite_unit':str(finite),'Gaussian_phase':str(phase),'X_H':XS,'left':left,'right':right,'T_H':list(map(enc,TH)),'scalar_supports':support,'family_Y':fam,'family_left':fleft,'family_right':fright,'strict4D_auxiliary_heat_current_zero':True,'pure_background_auxiliary_factor_P2_zero_by_field_degree':True,'general_family_no_trace_no_extra3_or_half':True,'physical_action_vertex_changed':False},tick)
