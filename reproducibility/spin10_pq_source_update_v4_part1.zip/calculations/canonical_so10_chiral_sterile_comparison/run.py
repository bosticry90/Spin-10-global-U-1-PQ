"""CSC1 freeze sources/dependencies and capture the bounded comparison."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-sterile-comparison-v1-2026-10-22');BASE='4eace95e3dc74026424bd6c82b10127ebfe5276e'
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=digest(p)
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for p in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V481.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:add(ROOT/p)
for folder,names in {
 'canonical_so10_chiral_polarization_contact':['RECORD.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_yukawa_carrier_transport':['replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_fermion_statistical_normalization':['RESULT.md','validation_receipt.json'],
 'canonical_so10_matter_evanescent_brst':['RECORD.md','validation_receipt.json'],
 'canonical_so10_chiral_dimensional_ward':['RECORD.md','validation_receipt.json']}.items():
 for name in names:add(ROOT/'calculations'/folder/name)
add(ROOT/'calculations/canonical_so10_chiral_polarization_contact/validation_receipt.json','3bbec425b715d3a11037c699eb582e3f2566bc79a65121275b0d8b8643d9b70d')
for name in ['RECORD.md','review.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
old=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-polarization-contact-v1-2026-10-22')
for n in ['postcommit_seal.json','postcommit_scope_correction_v2.json','readiness.jsonl']:add(old/n)
correction=read(old/'postcommit_scope_correction_v2.json');assert correction['actual_new_massless_one_loop_two_point_families']==1 and correction['actual_new_two_loop_integrals']==0
assert correction['old_postcommit_seal_sha256']==digest(old/'postcommit_seal.json') and correction['scientific_receipt_sha256']==digest(ROOT/'calculations/canonical_so10_chiral_polarization_contact/validation_receipt.json')
events=[json.loads(v) for v in (old/'readiness.jsonl').read_text().splitlines()];assert events[-1]['execution_state']=='COMPLETED' and [v['exit_code'] for v in events if v['event']=='step_finished']==[0,0,0,0,0,2]
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30141
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
dump(HERE/'preparation.json',{'schema':'CSC1_PREPARATION','base_commit':BASE,'input_sha256':b,'E4_readiness_reused_not_rerun':True,
 'seconds':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(HERE/'review.py')]);dump(HERE/'capture.json',cap);dump(CONTROL/'full_capture.json',cap)
assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0,cap['stdout_and_stderr']
assert cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['launch']['memory']['available_pagefile']>=350*1024**2
assert cap['all_resource_samples'] and max(v['private_bytes'] for v in cap['all_resource_samples'])<=8*1024**3
out=[json.loads(v[7:]) for v in cap['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1;r=out[0]
assert r['status']=='QUALIFIED_SELECTED_CHARGED_STERILE_TWO_POINT_FINITE_CONVERSION' and r['elapsed_after_imports']<600
assert r['same_physical_Weyl_count_in_strict_4D'] and r['insertion_and_polarization_contact_match'] and r['quadratic_restored_families_agree_for_common_zeta']
assert not r['full_H_covariant_or_nonAbelian_scheme_equivalence_qualified'] and not r['physical_scheme_adopted'] and not r['new_physical_sterile_matter_or_flavor_input']
for p,h in b.items():assert digest(Path(p))==h,p
dump(HERE/'validation_receipt.json',r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
print('CSC1_COMPLETED',r['elapsed_after_imports'],digest(HERE/'validation_receipt.json'),flush=True)
