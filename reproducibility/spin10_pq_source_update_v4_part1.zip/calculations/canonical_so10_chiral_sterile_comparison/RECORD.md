# CSC1: selected charged/sterile versus conjugate-Nambu continuation

Base4eace95e3dc74026424bd6c82b10127ebfe5276e/main,30141trackedblobs.
CPC1 qualified an actual finite contact and independent insertion match.
Its isolated transpose-sensitive color tensor fails homogeneous H covariance.
Question: does the standard charged/sterile continuation have that same
color term, and are the selected one-loop two-point limits related by an
independently specified local conversion? This is a regulator comparison,
not permission to add physical sterile matter or declare full equivalence.

Freeze currentpolicy/charter/state113/34of39,V481/local/solo conventions;
CPC1 record/result/primary+replay tables/receipt, YCT1 generators/receipt,
FSN1 Gaussian/pole result/receipt and MEB1/CDW1 records/receipts. Sources and
input hashes precede the observed execution. Keep CPC1's actual one-loop
count and all old evidence. Its external generic custody seal copied an
inapplicable new_model_loop_integrals=0 label; a separately preserved V2
scope correction binds that old seal and the correct scientific receipt.
No scientific worker failed; do not change the old receipt or source bytes.

Define a provisional Dirac continuation with one charged left chirality
and one sterile right auxiliary chirality: B_a=PL*T_a, Btilde_a=PR*T_a,
Gamma_bar=bar_gamma*PL*T, Gamma_hat=0, D0=i slash(p). BRST acts on the
charged chirality and its oriented barred endpoint; the right chirality
is sterile. The free field-independent spectator factor is normalized out.
Ordinary complex Gaussian gives -TrlogD, with NO Nambu half. Establish the
strict4D block determinant ratio detD(G)/detD(0)=detW(G)/detW(0), so the
comparison does not double the physical Weyl degrees of freedom. This
finite identity is not a global determinant-phase or full-Yukawa theorem.

Same CPC1 domain: massless kinetic subgraph, q^2>0, externalqhat0/barred
indices, parity-even one-loop two-point function. It does not choose physical
Yukawa matrices or a new vacuum. Keep d=4-2epsilon/internalhats. Use exactly
the already measured CPC1 integral form factors without rerunning integrals.

Primary finite trace test: independent8-dimensional split-Clifford witness,
fourbar/twohat, normalized to physicaltrace4 bydivisor2. Directly calculate
all256 charged-chirality bar traces. Separate parity-even/odd parts and
show the odd two-point tensor is antisymmetric in its internal momentum
indices, so symmetric angular/parameter integration annihilates it. Compute
all16 hatted external-index trace coefficients, including their zero values.
Actual45color Gram comes from YCT1, not an assumed label.

Independent insertion route: use B,Btilde and Hs=(B-Btilde)/2 in the physical
free-line identity. Keep both endpoint terms and calculate both insertion
momentum coefficients with the correct complex-Gaussian factor. Contract
before applying CPC1's authenticated Ihat. Compare the resulting two-point
Ward kernel to the direct-numerator reduction. No coefficient is fitted.

Determine the finite local difference from CPC1, its minimal quadratic
restoring kernel and any remaining invariant transverse freedom. Preserve
epsilon terms: an O(epsilon) logarithm can matter in a later two-loop forest.
Check all2025color entries, spin identities and zero complement. Recover
FSN1 pole and reject extraNambuhalf, auxiliarytrace inflation and treating
the sterile chirality as another charged physical family. A universal color
Gram passes homogeneous H covariance; that does not prove full local H
background covariance, cubic/quartic gauge/source identities, massive Yukawa
equivalence, phase, measure, QAP or full finite Slavnov restoration.

Literature anchor: Belusca-Maito et al.2004.14398v2,Secs3.2-3.3 and9,
https://arxiv.org/pdf/2004.14398 . Their charged/sterile setup motivates the
comparison. Their finite coefficients and preferred scheme are not imported.
No physical scheme/baseline is adopted; common zeta remains symbolic, not
identified with b0 or kappa. Shared physicalinputs/software/AIauthor limits
remain; no independent scientific confirmation is claimed.

One compact exact engine, direct traces versus insertion/block-Gaussian
arguments, using existing independently measured integrals. This reuse is
the least expensive competent test; no new two-loop/master integration.
One600s-afterimports/8GiBsampled/350MiBlaunchfloor run,16MiBpackage. Freeze
three sources/copies, preserve failures/unfinished runs and version fixes.
Reuse currentturn E4readiness with hash/state/oldblob verification, not a
fresh replay. Authority34/39, E5/A5unqualified, flavorpaused,HB1/C5blocked,
custodyexit2/seven NOTPASS, whole goal incomplete. No adoption/externalaction.
