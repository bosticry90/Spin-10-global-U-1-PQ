# CSC1: a selected finite conversion between two chiral continuations

The charged/sterile continuation has a universal color contact in the selected
massless gauge two-point function. It differs from CPC1's conjugate-Nambu
continuation by an explicitly derived finite local term. Their quadratically
restored expressions agree for a common symbolic transverse normalization.
This is a two-point comparison, not equivalence of the full regulated theories.

Receipt status:
`QUALIFIED_SELECTED_CHARGED_STERILE_TWO_POINT_FINITE_CONVERSION`,
SHA-256
`90549ac97bd0a786ea8cc2f09536f05bdccd7cde4863a5c1f6f9d32970c76f14`.
Scientific/director acceptance NOT_PERFORMED; authority remains34/39.

## One physical Weyl field is still being counted

The comparison uses one charged left chirality and an auxiliary sterile right
chirality in an ordinary complex Gaussian. Its interaction is
`Gamma_bar=bar_gamma PL T`, with no hatted vector vertex. There is no Nambu
half in this complex determinant. A general finite four-dimensional chiral
block calculation checks that

```
det D(G)/det D(0) = det W(G)/det W(0),
```

when the free sterile block is normalized out. Thus the gauge-dependent
Gaussian counts one physical Weyl field, in agreement with FSN1. Adding a
Nambu half here would incorrectly halve its pole. This finite local determinant
identity does not determine a global infinite-dimensional phase.

The auxiliary sterile chirality is regulator bookkeeping. It is not another
physical sterile-neutrino species, and is distinct from the model's physical
neutral component in the16. No flavor fit, neutrino spectrum, field-content
replacement or new physical coupling is introduced.

## Direct traces and a separately contracted insertion

An independent8-dimensional split-Clifford witness, reduced to physical
spin trace4 by divisor2, supplies all256 barred trace slots. The24 nonzero
parity-odd slots before integration are antisymmetric in the internal momentum
indices. The symmetric angular/parameter integral annihilates them in this
two-point graph. This is not a triangle-anomaly or determinant-phase result.
All16 hatted numerator trace slots vanish because of the charged projector
and sterile complementary chirality. Actual45-generator color contractions
are evaluated at all2025 positions.

The free-line Ward insertion is computed separately with
`B=PL T`, `Btilde=PR T`, and `Hs=(B-Btilde)/2`. The complex-Gaussian
insertion has endpoint momentum coefficients `+2G` and `-2G`, where
`G_ab=tr(T_a T_b)`. Applying the already qualified CPC1 moment gives the
same Ward contact as the direct tensor numerator. No new loop integral is
executed and no coefficient is chosen from a desired cancellation.

## The finite conversion and its limit

Using CPC1's authenticated functions C and F, the parity-even expressions
per family are

```
Pi_sterile = g^2/(16pi^2) [
  G C (q^2 delta-qq) + G F q^2 delta
],
Pi_conjugate = g^2/(16pi^2) [
  G C (q^2 delta-qq) + (G+M) F q^2 delta
],
M_ab = tr(T_a T_b^T),
F = 1/3 + epsilon*(L/3+8/9) + ... .
```

Consequently

```
finite(Pi_conjugate-Pi_sterile)
  = g^2/(16pi^2) * (M/3) q^2 delta.
```

This conversion has rank45 in the fixed plane frame. The next coefficient
is `M*(L/3+8/9) q^2 delta`: it must be retained for a later two-loop forest,
where an evanescent term can multiply a pole. A one-loop finite equality
does not permit dropping those terms in higher-loop assembly.

Subtracting each calculated quadratic contact leaves the same transverse
form factor. A common invariant transverse constant `zeta` stays free.
It is neither fixed to zero nor identified with `b0` or `kappa`. The sterile
contact's color tensor G is homogeneous-H invariant, while CPC1's G+M was
not. This passes a **color** covariance test; full local-background covariance
and the non-Abelian cubic/quartic/source identities remain unproved.

The standard charged/sterile construction is discussed in
[Belusca-Maito et al., Secs3.2-3.3 and9](https://arxiv.org/pdf/2004.14398).
Only the setup is a comparator. Its preferred finite counterterms and scheme
were not imported as answers for this model.

## Validation and preserved limitations

The exact trace calculation, insertion contraction and finite Gaussian block
identity use different mathematical checks. They reuse CPC1's independently
derived and integrated master functions. Shared physical assumptions, input
data, SymPy/Python and AI authorship remain limitations; no outside scientific
verification is claimed. Extra Gaussian half, inflated auxiliary spin trace
and extra charged physical family fail the normalization comparison.

One observed worker completed exit0 in3.4867067 seconds after imports.
Three samples have private maximum51,347,456 bytes, not a peak estimate;
launch available commit was11,196,493,824 bytes. Frozen600s/8GiB sampled/
350MiB launch-floor/16MiB package boundaries were unexhausted. Preparation
binds29 inputs and three source copies. No failed or unfinished worker occurred.
Current-turn E4 readiness and existing integral evidence are authenticated
reuse, not fresh replay. Historical custody stays exit2/seven NOTPASS.

An engineering-label correction is preserved: CPC1's external generic custody
summary copied `new_model_loop_integrals=0`, although its scientific receipt
correctly reports one new massless one-loop two-point family and zero new
two-loop integrals. The original seal/source remain unchanged; a separate
`postcommit_scope_correction_v2.json` binds and corrects only that label and
is frozen by this preparation. No scientific result was rerun or relabeled.

## Consequence and next question

The chosen conjugate-Nambu member's transpose-sensitive contact is a
continuation-dependent feature in this tested graph, not a representation
anomaly. A full scheme conversion, determinant phase, massive Yukawa action,
source measure, QAP and finite physical threshold remain separate obligations.

The next necessary construction is a complete provisional charged/sterile
matter action containing the actual YCT1 symmetric Yukawa maps, with its
conjugate/auxiliary blocks, source transformations and Gaussian normalization
specified together. Its strict four-dimensional physical sector must reduce
to the original Weyl theory without adding particles. Do not blindly reuse
the ordinary massless Dirac determinant factor for a massive Majorana block,
or the earlier single Majorana antifield count for unconstrained Dirac fields.
That construction can identify the precise evanescent insertions and inputs
needed before further massive two-loop or full restoration claims.

No physical regulator or scheme is adopted. E5/A5, physical matching and
viability remain unqualified. Both scalar points' negative quantum evidence,
flavor pause, HB1/C5 blocks and all historical evidence remain intact.
