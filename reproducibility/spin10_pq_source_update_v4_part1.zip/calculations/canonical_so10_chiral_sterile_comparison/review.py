"""CSC1 direct sterile-chirality traces and independent Ward numerator."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import gzip,json,os,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dec(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
p1=s.Matrix([[0,1],[1,0]]);p2=s.Matrix([[0,-s.I],[s.I,0]]);p3=s.diag(1,-1)
g4=[s.kronecker_product(p1,s.eye(2)),s.kronecker_product(p2,s.eye(2)),s.kronecker_product(p3,p1),s.kronecker_product(p3,p2)]
g=[s.kronecker_product(a,p3) for a in g4]+[s.kronecker_product(s.eye(4),p1),s.kronecker_product(s.eye(4),p2)]
chi=s.kronecker_product(g4[0]*g4[1]*g4[2]*g4[3],s.eye(2));PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL
assert chi**2==s.eye(8) and s.trace(PL)==s.trace(PR)==4
for i,j in product(range(6),repeat=2):assert g[i]*g[j]+g[j]*g[i]==2*int(i==j)*s.eye(8)
for i in range(6):assert (g[i]*chi+chi*g[i] if i<4 else g[i]*chi-chi*g[i])==s.zeros(8)
cp=packed(CAL/'canonical_so10_chiral_polarization_contact/primary_tables.json.gz');cr=packed(CAL/'canonical_so10_chiral_polarization_contact/replay_tables.json.gz')
odd={};idx=0
for mu,al,nu,be in product(range(4),repeat=4):
 full=s.simplify(s.trace(g[mu]*PL*g[al]*g[nu]*PL*g[be])/2)
 even=s.simplify(sum(s.trace(g[mu]*p*g[al]*g[nu]*p*g[be]) for p in [PL,PR])/4)
 assert even==s.sympify(cp['bar_trace_coefficients'][idx]);idx+=1;odd[mu,al,nu,be]=full-even
for mu,al,nu,be in product(range(4),repeat=4):assert odd[mu,al,nu,be]+odd[mu,be,nu,al]==0
hat=[]
for mu,nu in product(range(4),repeat=2):
 v=s.simplify(s.trace(g[mu]*PL*g[4]*g[nu]*PL*g[4])/2);assert v==0;hat.append(v)
# No Gaussian half here. The factor2 comes from E=2 hat_slash Hs.
hs=(PL-PR)/2;kk=s.simplify(-2*s.trace(hs*g[0]*PL*g[0])/2);pp=s.simplify(-2*s.trace(hs*g[0]*g[0]*PL)/2)
assert kk==-pp==2
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,d['Tminus']))
G=s.Matrix(45,45,lambda a,b:s.simplify(s.trace(T[a]*T[b])));M=dec(cp['M']);N=dec(cp['contact_color']);assert G==dec(cp['G'])==2*s.eye(45)
L=s.Symbol('L');f0,f1=map(s.sympify,cp['contact_coefficients_F0_F1']);assert cp['contact_coefficients_F0_F1']==cr['contact_coefficients_F0_F1']
# Direct tensor formula is CPC1's bar result with zero hat numerator.
# It gives contact G*F; the independently inserted numerator kk*G times
# Ihat/q^2=F/2 gives the same coefficient.
sterile_contact=G*f0;inserted=kk*G*f0/2;assert sterile_contact==inserted
conjugate_contact=N*f0;conversion=conjugate_contact-sterile_contact;assert conversion==M*f0
assert N*f1-G*f1==M*f1
sterile_CT=-sterile_contact;conjugate_CT=-conjugate_contact
assert sterile_contact+sterile_CT==s.zeros(45) and conjugate_contact+conjugate_CT==s.zeros(45)
assert conjugate_CT-sterile_CT==-conversion
assert 3*s.sympify(cp['transverse_coefficients_pole_finite_epsilon'][0])*G==4*s.eye(45)
# Four-dimensional free spectator normalization: a general invertible W0
# and a free right block yield one Weyl determinant ratio, with no extrahalf.
a,b,c,d0,z=s.symbols('a b c d z');W=s.Matrix([[a,b],[c,d0]]);V=s.Matrix([[1,2],[-1,0]]);R=s.Matrix([[1,1],[-1,2]])
D=s.BlockMatrix([[s.zeros(2),R],[W+z*V,s.zeros(2)]]).as_explicit();D0=D.subs(z,0)
assert s.cancel(D.det()/D0.det()-(W+z*V).det()/W.det())==0
assert G/2!=G and 2*G!=G and 4*G!=G
assert sum(int(v!=0) for v in M)==45 and (M/3).rank()==45
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_SELECTED_CHARGED_STERILE_TWO_POINT_FINITE_CONVERSION','elapsed_after_imports':time.perf_counter()-start,
 'bar_trace_slots_checked':256,'parity_odd_antisymmetric_slots_checked':256,'nonzero_parity_odd_slots_before_integration':sum(int(v!=0) for v in odd.values()),
 'hat_trace_slots_checked_zero':16,'actual_color_entries_checked':2025,'spin_trace_witness':8,'witness_to_physical_divisor':2,'complex_Gaussian_factor':'1',
 'free_spectator_block_determinant_ratio_checked':True,'same_physical_Weyl_count_in_strict_4D':True,'sterile_contact_kernel_per_family':'G*F*q^2*delta_mn',
 'independent_insertion_momentum_coefficients':[str(kk),str(pp)],'insertion_and_polarization_contact_match':True,
 'finite_conversion_conjugate_minus_sterile':'M*q^2*delta_mn/3','epsilon_conversion':'M*(L/3+8/9)*q^2*delta_mn',
 'conversion_rank_in_plane_frame':45,'sterile_color_tensor_homogeneous_H_invariant':True,'quadratic_restored_families_agree_for_common_zeta':True,
 'transverse_finite_baseline':'zeta_symbolic_unfixed','new_master_or_two_loop_integrals':0,'integral_evidence_reused_not_rerun':True,
 'new_physical_sterile_matter_or_flavor_input':False,'full_H_covariant_or_nonAbelian_scheme_equivalence_qualified':False,'physical_scheme_adopted':False,
 'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
