"""CDW1 formal chiral hat coefficients and radial/Gamma evanescent moment."""
from data import *
import mpmath as mp
start=begin('primary');src=packed(CAL/'canonical_so10_fermion_goldstone_interface/primary_v2_tables.json.gz');r=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz')
T=list(map(dec,src['spinor_plane_generators']));U=dec(r['normalized_vector_basis']);PL=s.diag(1,0);PR=s.diag(0,1);ph,qh=s.symbols('ph qh',real=True)
def tidy(M):return s.SparseMatrix(M).applyfunc(s.expand)
rows=[];total=[s.S.Zero]*4;at_physical_q=0;av_generic=0
for j in range(33):
 t=sum((U[a,j]*T[a] for a in range(45)),s.zeros(16));A=s.SparseMatrix(s.kronecker_product(PL,t)-s.kronecker_product(PR,t.T));At=s.SparseMatrix(s.kronecker_product(PR,t)-s.kronecker_product(PL,t.T));VV=(A+At)/2
 # Factor out i*hat_gamma. Its commuting action leaves these actual chiral
 # coefficient polynomials; barred/mass identities are inherited FWL inputs.
 rawB=tidy((ph+qh)*A-At*ph);rawAV=tidy(rawB-qh*VV)
 cp=rawB.applyfunc(lambda z:z.coeff(ph));cb=rawB.applyfunc(lambda z:z.coeff(qh));ca=rawAV.applyfunc(lambda z:z.coeff(qh))
 assert tidy(rawAV-ph*cp-qh*ca)==s.zeros(32)
 norms=[s.simplify(s.trace(cp.H*cp)),s.simplify(s.trace(cp.H*cb+cb.H*cp)),s.simplify(s.trace(cb.H*cb)),s.simplify(s.trace(ca.H*ca))]
 assert s.simplify(s.trace(cp.H*ca+ca.H*cp)-norms[1])==0
 total=[a+b for a,b in zip(total,norms)];at_physical_q+=int(bool(s.SparseMatrix(cp).todok()));av_generic+=int(bool(s.SparseMatrix(ca).todok()))
 rows.append({'direction':j,'p_coefficient':enc(cp),'q_barred_coefficient':enc(cb),'q_averaged_coefficient':enc(ca),'Gram_p2_pdotq_qB2_qAV2':list(map(str,norms))})
# Radial tensor integral, including its angular projection and MSbar measure.
e,L=s.symbols('epsilon L',real=True);d=4-2*e
J=s.simplify((d-4)/d*(d/2)/s.gamma(3)*s.gamma(2-d/2)*s.exp(s.EulerGamma*e+L*e))
assert s.simplify(J+s.exp(s.EulerGamma*e+L*e)*s.gamma(1+e)/2)==0
coeff=[s.simplify(s.expand(s.series(J,e,0,3).removeO()).coeff(e,k)) for k in range(3)]
mp.mp.dps=80;probes=[]
for ee in [mp.mpf(1)/10,mp.mpf(1)/100,mp.mpf(1)/1000]:
 for ratio in [mp.mpf(1)/2,mp.mpf(2),mp.mpf(5)]:
  dd=4-2*ee;value=(dd-4)/dd*(dd/2)/2*mp.gamma(ee)*mp.exp(mp.euler*ee)*ratio**ee
  probes.append({'epsilon':mp.nstr(ee,10),'mu_R2_over_m_IR2':mp.nstr(ratio,10),'J':mp.nstr(value,65)})
finish('primary',{'method':'formal_chiral_coefficient_extraction_and_radial_Gamma','rows':rows,'aggregate_Gram_p2_pdotq_qB2_qAV2':list(map(str,total)),
 'physical_hat_q_zero_sensitive':at_physical_q,'averaged_generic_sensitive':av_generic,'barred_generic_sensitive':33,
 'moment_coefficients':list(map(str,coeff)),'moment_probes':probes,'auxiliary_moment_not_model_threshold':True,
 'provisional_evanescent_choices_not_physical_adoption':True,'full_fermionic_prescription_or_quantum_restoration':False},start)
