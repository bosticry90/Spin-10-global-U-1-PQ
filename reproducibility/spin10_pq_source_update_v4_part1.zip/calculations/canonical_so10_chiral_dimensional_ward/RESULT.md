# CDW1 result: a conditional evanescent Ward defect, not a fermion threshold

The four-dimensional FWL1 line identity cannot be transferred unchanged to
the tested split-Clifford continuation. Both explicit algebraic choices
recover FWL1 when the hatted directions vanish, but retain a nonzero
evanescent kinetic insertion in the declared dimensional comparison.
An auxiliary UV moment shows how such a vanishing-dimensional factor can
leave a finite contribution. This is not a calculated Spin(10) FFV/FFS
amplitude, an anomaly, or adoption of a complete fermionic regulator.

The separate validation receipt is
`fb3d228d5c32ac4655c77c5898f6afae6ae3823e5bef69dfa1baf31749bdd0bf`,
status
`QUALIFIED_CONDITIONAL_SPLIT_CLIFFORD_WARD_DEFECT_AND_EVANESCENT_MOMENT`.
Scientific/director acceptance is NOT_PERFORMED. State113/34of39 is unchanged.

## Selected scope and why this test matters

The existing dimensional-counterterm applicability record expressly
excludes spacetime spinor/gamma5/epsilon objects. Its gauge-fixing fermion
and 643 integrated directions do not supply the missing physical Weyl16
prescription. The extended-source-pole derivation also excludes matter.
The inspected original threshold and Yukawa conventions do not fix the
evanescent interaction, Majorana charge-conjugation rule or finite chiral
restoration. This authenticates the limits of those selected dependencies;
it is not an exhaustive absence theorem about the whole Git history.

FGI1 supplies the actual heavy-vector eigenbasis, physical spinor generators
and normalized Goldstone couplings. FWL1 supplies the oriented four-dimensional
free-line identity. Both completed receipts are authenticated, not rerun.
The present calculation keeps the same chirality labels, formal neutral
mass direction, and canonical carrier identification. No numerical fermion
masses, Yukawa matrices, flavor fit or physical subtraction scheme is chosen.

The split algebra and the possibility of distinct evanescent interactions
are established QFT tools. Belusca-Maito et al.,
[2004.14398v2](https://arxiv.org/pdf/2004.14398), sections2 and3.2--3.3,
explicitly distinguish interaction continuations and evanescent kinetic
breaking. Their [2109.11042v2](https://arxiv.org/pdf/2109.11042) constructs
evanescent and finite restoring counterterms in a chiral-QED example.
Those are methodological comparators, not counterterms for this massive
Spin(10) theory. Our averaged choice below is defined by its formula and
must not be confused with the first paper's differently defined preferred
interaction. Neither algebraic comparison here proves a full BMHV Majorana
action or its charge-conjugation prescription.

## The extra term from the actual 33 heavy generators

Use `{bar_gamma,chi}=0`, `[hat_gamma,chi]=0`, `chi=PL-PR`, and the FWL1
matrices

    A=PL*T-PR*T^T, Atilde=PR*T-PL*T^T,
    V=(A+Atilde)/2, H=(A-Atilde)/2.

For k=p+q the defect is defined as

    E=D(k)A-Atilde D(p)-i[q.Gamma-sqrt(lambda)Y4].

The inherited mass and Goldstone terms cancel in the oriented combination.
The four barred momentum coefficients cancel for every heavy direction.
Two precisely specified provisional current choices give:

    B:  Gamma_bar=bar_gamma A, Gamma_hat=0,
        E_B=i[hat_slash(k)A-Atilde hat_slash(p)].

    AV: Gamma^mu=(gamma^mu A+Atilde gamma^mu)/2,
        Gamma_hat=hat_gamma V,
        E_AV=i[hat_slash(k)+hat_slash(p)]H.

Consequently `E_B-E_AV=i hat_slash(q)V`. At physical external `q_hat=0`,
the two choices agree, but both still contain
`i hat_slash(p)(A-Atilde)`. Internal loop hatted momenta cannot be set to
zero merely because external momenta are four-dimensional.

Primary extracts formal momentum polynomials in the actual 2-by-16 chiral
blocks. Replay constructs an eight-dimensional spinor matrix representation
of six Euclidean Clifford generators, with four barred and two auxiliary
hatted directions, and contracts the actual internal tensors. The latter
is a finite algebra witness, not dimensional regularization near d=4 or a
physical model of extra dimensions. Its spinor trace8 is not a dimreg trace4.
An explicit divisor4 relates its trace to the primary chirality trace2.

The separate gate compares all 1,622,016 positions of the 33*3*128-by-128
operator coefficients, including zeros. It checks 21 Clifford relations,
four barred and two hatted chirality relations, 132 barred momentum
coefficients, 33 mass/Goldstone coefficients, and 297 cross-hat inner products.

For the first hatted direction, the summed trace Gram coefficients are:

| Coefficient | Aggregate in the fixed carrier/eigenbasis |
| --- | ---: |
| hat p squared | 272 |
| hat p dot hat q | 272 |
| hat q squared, B choice | 132 |
| hat q squared, AV choice | 68 |

With `p_hat=(1,2),q_hat=(3,-1)` in the auxiliary two-direction witness,
the trace norms are2952 and2312. This is a predetermined algebra probe,
not a physical momentum or normalization condition.

At `q_hat=0` the defect is nonzero in17/33 frozen basis directions;
the other16 are explicitly insensitive to this test. With general hatted
momenta the B choice is nonzero in33/33 and AV in17/33. Swapping the
evanescent vertex choices is detectable in16/33. These counts and norms
depend on the specified left/conjugate-right evanescent identification.
They are not particle counts, anomaly ranks or a claim of invariance under
arbitrary complex basis changes with untransported regulator data.

Dropping the hatted kinetic term misses the17 sensitive physical-q_hat-zero
directions. Wrong hat anticommutation is rejected by the explicit Clifford
witness. Using trace divisor2 instead of4 doubles nonzero Grams and fails.
The strictly four-dimensional limit recovers the authenticated FWL1 line.
No heat operator, loop trace or sewn-loop endpoint has been rearranged here.

## A finite evanescent moment, kept separate from the model

Define exactly the auxiliary scalar integral in RECORD.md, with d=4-2epsilon,
positive auxiliary m_IR squared and the declared MSbar-normalized measure.
The primary radial/Gamma reduction gives, for L=log(mu_R squared/m_IR squared),

    J(epsilon)=-exp[(gamma_E+L)epsilon]*Gamma(1+epsilon)/2
             =-1/2-L*epsilon/2
              -(L^2/4+pi^2/24)*epsilon^2+O(epsilon^3).

Replay instead reduces the numerator as I2-m_IR squared*I3, obtains the
log-Gamma derivatives, and evaluates Gamma(1+epsilon) through its convergent
proper-time integral. Nine80-digit comparisons, at epsilon=.1,.01,.001
and scale ratios.5,2,5, agree after65-digit serialization; maximum stored
scaled discrepancy is0.0, below the frozen1e-50 gate. This is finite printed
precision agreement, not a claim of exact numerical quadrature.

The finite limit is-1/2 in the normalized J, equivalently-1/(32pi^2) before
the16pi^2 normalization. It comes from `(d-4)/d` times a UV pole. Setting
d=4 before pole subtraction gives the wrong zero; reversing the sign of the
hatted dimension gives the wrong positive limit. The positive auxiliary
mass prevents an IR singularity; no massless scaleless integral is assigned
this value. The epsilon and epsilon-squared terms are retained rather than
discarded before any future forest subtraction.

This one auxiliary scalar moment is not a measured model contact. It has
not been multiplied by the Gram table to manufacture a finite restoring
counterterm or C1 coefficient. There are zero new model loop integrals.

## Execution, credibility and carry-forward

Run `python -B calculations/canonical_so10_chiral_dimensional_ward/run.py`
was executed once. Preparation froze37 bindings and seven source copies
before either route; validation froze44 bindings after both routes completed.
Primary/replay/gate completed at1.8719673/19.1519793/4.3747753 seconds after
imports, native exit0 each. Their2/10/3 observed memory samples have maxima
49,586,176/55,476,224/47,058,944 bytes, respectively; these are sampled maxima,
not true peaks. Launch available commit exceeded7.39GB. No600-second,
8GiB sampled-private,350MiB launch-floor or16MiB package boundary was
exhausted. There was no failed or unfinished scientific worker execution.
The paired gzip/raw hashes, full native stdout/stderr, launch observations
and all samples are retained internally and in the external control folder.

The AI-capability result is a bounded dependency diagnosis: distinguish
internal Spin(10) Clifford matrices from spacetime chirality, identify that
the older bosonic dimensional theorem does not cover matter, derive the
necessary conditional extra term, and challenge a premature four-dimensional
limit. The two derivations share upstream action/assignment tables, software,
libraries and AI authorship. They corroborate implementation and algebra,
not the physical validity of a full fermionic prescription. The underlying
evanescent mechanism is established literature, not a new physics discovery.

Next smallest justified action: construct a genuinely specified provisional
regularized chiral kinetic/current/source domain, including Majorana
charge conjugation and its evanescent symmetry insertion, before using
the free line in finite matter loops. Keep alternatives explicitly provisional;
ordinary comparison research is authorized, physical scheme adoption is not
implied. A complete massive Spin(10) BRST-restoring subtraction, its allowed
counterterm space, full parent Yukawa/scalar complement, finite fermion
threshold and physical mass spectrum remain unresolved. No flavor research
is resumed, and no unknown matter contribution is fitted to repair a failed
bosonic benchmark.

## Reference intake and preserved physical warnings

The director's supplied negative-benchmark assessment, attachment SHA256
`2d410d2b3723335ab0de0e1b7bc9877f6f5cb691928228d840a67acde426ee11`,
is useful reference and was read in full. Preserve its core distinction:
the original eta=.3 nine-family bosonic threshold is a qualified mathematical
calculation with failed perturbative hierarchy at the three measured couplings;
neither changing the explicit common log nor treating a truncated expression
as exact repairs that bounded failure. The excluded fixed-eta domain stays
excluded. Do not automatically rerun all nine families at another point.

Its historical attribution of the approximately140% singlet correction to
the original point requires the already committed SPS/V471 correction:
the complete selected ratio1.40004177709 belongs to the distinct eta=.0001
finite coherent witness. That witness is therefore not an untested quantum
alternative. Its classical contact/BFB/mass certificates coexist with that
large one-loop correction and the previously qualified input/tadpole/gauge
warnings. Do not transfer old C1 spectra or coefficients to it or repeat
already completed singlet/portal screens. CDW1 uses their common geometric
representation data only; it changes neither scalar point or conclusion.

Authority remains34/39; E5/A5, physical unification and the whole investigation
remain incomplete. HB1/C5 stay blocked, flavor stays human-paused, the
historical quartet failure and custodyexit2/seven NOTPASS remain. No state
change, foundation or benchmark adoption, external action or promotion occurs.
