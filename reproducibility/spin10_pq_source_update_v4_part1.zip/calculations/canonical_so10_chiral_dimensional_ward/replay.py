"""CDW1 six-dimensional split-Clifford witness and convergent time integral."""
from data import *
import mpmath as mp
start=begin('replay')
sig=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(sig[1],z) for z in sig]+[s.kronecker_product(sig[0],s.eye(2))]
bar=[s.SparseMatrix(s.kronecker_product(g,sig[2])) for g in g4];hat=[s.SparseMatrix(s.kronecker_product(s.eye(4),z)) for z in sig[:2]]
chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(2));PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
allg=bar+hat
for i in range(6):
 for j in range(i,6):zero(allg[i]*allg[j]+allg[j]*allg[i]-(2*s.eye(8) if i==j else s.zeros(8)))
for g in bar:zero(g*chi+chi*g)
for g in hat:zero(g*chi-chi*g);assert tidy(g*chi+chi*g).todok()
src=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz');T=list(map(dec,src['spinor_plane_generators']));V=dec(src['normalized_vector_basis']);G=dec(src['vector_Gram']);Y=dec(src['normalized_Goldstone_vertices_per_mass'])
PN=s.diag(1,*([0]*15));mass=s.SparseMatrix(s.kronecker_product(s.eye(8),PN));ggbar=[s.SparseMatrix(s.kronecker_product(g,s.eye(16))) for g in bar];gghat=[s.SparseMatrix(s.kronecker_product(g,s.eye(16))) for g in hat]
rows=[];aggregate=[s.S.Zero]*4;checks=0;twohat=[s.S.Zero,s.S.Zero]
for j in range(33):
 t=sum((V[a,j]*T[a] for a in range(45)),s.zeros(16));lam=s.simplify((V[:,j].T*G*V[:,j])[0]);y=s.Matrix(16,16,list(Y[:,j]))
 A=s.SparseMatrix(s.kronecker_product(PL,t)-s.kronecker_product(PR,t.T));At=s.SparseMatrix(s.kronecker_product(PR,t)-s.kronecker_product(PL,t.T));y8=s.SparseMatrix(s.kronecker_product(PL,y)+s.kronecker_product(PR,y.H))
 for g in ggbar:zero(g*A-At*g)
 zero(mass*A-At*mass+s.I*s.sqrt(lam)*y8)
 coeff=[]
 for gh in gghat:
  zero(gh*A-A*gh);zero(gh*At-At*gh)
  # Direct momentum coefficients of D(k)A-Atilde D(p)-i(q.Gamma-sqrt(lam)Y).
  cp=tidy(s.I*(gh*A-At*gh));cb=tidy(s.I*gh*A);vertex_av=(gh*A+At*gh)/2;ca=tidy(s.I*(gh*A-vertex_av))
  coeff.append([cp,cb,ca])
 nrm=lambda X:s.simplify(s.trace(X.H*X)/4)
 cp,cb,ca=coeff[0];gram=[nrm(cp),s.simplify(s.trace(cp.H*cb+cb.H*cp)/4),nrm(cb),nrm(ca)]
 assert s.simplify(s.trace(cp.H*ca+ca.H*cp)/4-gram[1])==0
 assert [nrm(z) for z in coeff[0]]==[nrm(z) for z in coeff[1]]
 for x in coeff[0]:
  for z in coeff[1]:assert s.simplify(s.trace(x.H*z))==0;checks+=1
 probeB=coeff[0][0]+2*coeff[1][0]+3*coeff[0][1]-coeff[1][1]
 probeAV=coeff[0][0]+2*coeff[1][0]+3*coeff[0][2]-coeff[1][2]
 twohat[0]+=nrm(probeB);twohat[1]+=nrm(probeAV)
 assert nrm(probeB)==5*gram[0]+gram[1]+10*gram[2] and nrm(probeAV)==5*gram[0]+gram[1]+10*gram[3]
 aggregate=[a+b for a,b in zip(aggregate,gram)]
 rows.append({'direction':j,'E_p_firsthat':enc(cp),'E_q_barred_firsthat':enc(cb),'E_q_averaged_firsthat':enc(ca),'Gram_p2_pdotq_qB2_qAV2':list(map(str,gram))})
# Independent scalar reduction I2-m² I3, then logarithmic Gamma derivatives.
e,L=s.symbols('epsilon L',real=True);d=4-2*e
J=s.simplify((d-4)/d*(s.gamma(e)-s.gamma(1+e)/2)*s.exp(s.EulerGamma*e+L*e))
assert s.simplify(J+s.exp(s.EulerGamma*e+L*e)*s.gamma(1+e)/2)==0
logfac=s.EulerGamma*e+s.log(s.gamma(1+e))+L*e
c1=s.simplify(s.diff(logfac,e).subs(e,0));c2=s.simplify(s.diff(logfac,e,2).subs(e,0)/2)
coef=[-s.Rational(1,2),-c1/2,s.simplify(-(c1*c1/2+c2)/2)]
mp.mp.dps=80;probes=[]
for ee in [mp.mpf(1)/10,mp.mpf(1)/100,mp.mpf(1)/1000]:
 proper=mp.quad(lambda u:u**ee*mp.exp(-u),[0,1,mp.inf])
 for ratio in [mp.mpf(1)/2,mp.mpf(2),mp.mpf(5)]:
  value=-mp.mpf(1)/2*proper*mp.exp(mp.euler*ee)*ratio**ee
  probes.append({'epsilon':mp.nstr(ee,10),'mu_R2_over_m_IR2':mp.nstr(ratio,10),'J':mp.nstr(value,65)})
finish('replay',{'method':'six_D_split_matrix_witness_and_proper_time_quadrature','rows':rows,'aggregate_Gram_p2_pdotq_qB2_qAV2':list(map(str,aggregate)),
 'split_Clifford_relations_checked':21,'barred_chirality_relations_checked':4,'hatted_chirality_relations_checked':2,'cross_hat_trace_checks':checks,
 'barred_momentum_checks':132,'mass_checks':33,
 'two_hat_probe_norms':list(map(str,twohat)),'moment_coefficients':list(map(str,coef)),'moment_probes':probes,
 'witness_trace_divisor_to_chirality_trace':4,'six_D_witness_not_dimreg_spinor_trace':True,'auxiliary_moment_not_model_threshold':True,
 'provisional_evanescent_choices_not_physical_adoption':True,'full_fermionic_prescription_or_quantum_restoration':False},start)
