# CDW1: conditional dimensional Ward defect before fermion loop integration

Scientific question: may the four-dimensional FWL1 line identity be used
unchanged in a dimensionally regulated fermion kernel? Existing dimensional
applicability explicitly excludes spacetime spinor/gamma5 objects; its E1
fermion is gauge-FIXING. The extended-source-pole derivation excludes matter.
The inspected original threshold/Yukawa contracts do not fix the missing
evanescent interaction/charge-conjugation/finite-restoration prescription.
This is a selected-source conclusion, not proof of absence anywhere in Git.

The least expensive competent test is a conditional split-Clifford analysis
on the actual33 FGI1 heavy-vector generators, plus a separately labelled
scalar evanescent moment. It can disprove an automatic dimensional transfer
without choosing neutrino masses, running a flavor fit or rebuilding two
loops at a failed scalar point. No counterterm is fitted to a desired result.

Freeze FGI1/FWL1 receipts, actual generator/eigenbasis/Goldstone tables, the
inspected original contracts and dimensional applicability statements.
Use BMHV-type relations {bar_gamma,chi}=0,[hat_gamma,chi]=0, where
chi=P_L-P_R labels the SAME physical chirality as FWL1. Split momenta into
bar and hat parts; d=4-2epsilon is formal for the scalar moment only.

Let A=PL*T-PR*T^T, Atilde=PR*T-PL*T^T, V=(A+Atilde)/2,H=(A-Atilde)/2.
Keep the FWL mass and oriented Goldstone term. Compare two EXPLICIT
ALGEBRAIC continuations of its current:

 B: Gamma_bar=bar_gamma*A, Gamma_hat=0;
 AV: Gamma^mu=(gamma^mu*A+Atilde*gamma^mu)/2,
     so Gamma_bar=bar_gamma*A, Gamma_hat=hat_gamma*V.

Neither is adopted as a full regularized Majorana action, physical scheme,
charge-conjugation rule, QAP domain or symmetry-restoring counterterm set.
The literature motivates making these distinctions; it does not qualify
either complete massive Spin(10) construction here. Both reduce to FWL1 in
strictly four dimensions, but their evanescent Ward insertions can differ.

For D(k)A-Atilde D(p)-i[q.Gamma-sqrt(lambda)Y4], k=p+q,
derive the full surviving hat coefficients without moving a heat regulator:

 E_B=i[hat_slash(k)*A-Atilde*hat_slash(p)],
 E_AV=i(hat_slash(k)+hat_slash(p))*H.

They are evanescent algebraic terms, NOT anomalies or finite model amplitudes.
External background momenta may be physical while contracted loop momenta
remain d dimensional. Test both general hat q and hat q=0; do not silently
set all internal hat momenta to zero.

Primary uses formal chirality coefficient blocks and polynomial extraction
in hat p,hat q, with actual spinor tensors. Replay constructs an8-by-8
Clifford witness with four barred and two auxiliary hatted directions,
checks every split relation, and contracts actual128-by-128 operator
coefficients. The finite6D witness checks algebra ONLY: it is not d near4,
not a physical extra-dimensional model, and its trace8 is NOT a physical
dimreg spinor trace. Compare to chirality traces using the explicit factor4.
Compare all33*3*128^2 coefficient positions, zeros included, for one hat
direction and check the second direction/cross moments independently.

Report the Gram coefficients of hat p²,hat p.hat q,hat q² for both choices,
and sensitive/insensitive directions in the frozen basis. These counts and
norms belong to the chosen evanescent identification of left/conjugate-right
carriers; do not call them physical particle counts or basis-independent
anomaly ranks. A real orthogonal/permutation transport preserves the stated
comparison; a general complex basis change needs its evanescent data moved too.

Separately define, with m_IR²>0 and a declared MSbar-normalized measure,

 J(epsilon)=16pi²*(exp(gamma_E)*mu_R²/(4pi))^epsilon
   * integral d^(4-2epsilon)k/(2pi)^(4-2epsilon)
       hat k²/(k²+m_IR²)^3.

This is an AUXILIARY scalar moment, not an FFV/FFS diagram or measured
Spin(10) contact. Primary uses radial/Gamma integration and the rotational
factor(d-4)/d. Replay uses I2-m_IR²*I3 and a convergent proper-time integral.
Derive finite/epsilon/epsilon² coefficients and compare finite epsilon
probes using80-digit quadrature,1e-50 scaled gate. Keep UV and IR separate:
the positive mass avoids IR singularities; no massless/scaleless integral
or physical neutrino mass is substituted. NEVER multiply this diagnostic
by the color Gram to invent a model finite counterterm.

Controls: drop the hatted kinetic term, impose anticommutation on the hat
generators, interchange the two evanescent current choices, set d=4 before
the UV pole, wrong hat-dimension sign, and wrong witness trace normalization.
Recover FWL1 when hats vanish and the exact currentless/axialless cases.

Reference standards: Belusca-Maito et al.2004.14398v2,secs2/3.2-3.3 describe
the split algebra, distinct interaction extensions, and evanescent kinetic
breaking (https://arxiv.org/pdf/2004.14398). Their2109.11042v2 demonstrates
the need for evanescent/finite symmetry-restoring counterterms in its chiral
QED example (https://arxiv.org/pdf/2109.11042). These general facts are
inherited published QFT, not AI discoveries or a counterterm result for
massive Spin(10). Sources consulted2026-10-22; no quoted finite formula
or source model is imported as the investigated theory's physical answer.

Sequential primary/replay/separate gate, immutable inputs/source copies first.
600s each after imports,8GiB sampled private,350MiB launch floor,16MiB package.
Preserve any failed/incomplete result and version repairs. Qualification is
conditional algebra/moment correctness or an explicit discrepancy; missing
prescription stays underdefined. No agents, numerical flavor or mass fit,
accepted scheme/benchmark change, physical finite C1, full measure/QAP or
E5/A5 promotion. Keep state113/34of39, flavor pause,HB1/C5 blocks,custodyexit2/
seven NOTPASS, both scalar points' warnings and historical evidence. Shared
action/assignment/software/AI author remain; no external physical validation.
Scientific/director acceptance NOT_PERFORMED; whole investigation incomplete.
