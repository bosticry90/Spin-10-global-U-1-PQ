"""CDW1 separate full-position comparison and scope-sensitive controls."""
from data import *
import mpmath as mp
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
assert len(P['rows'])==len(R['rows'])==33
sig1=s.Matrix([[0,1],[1,0]]);chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(2));PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL
gh=s.SparseMatrix(s.kronecker_product(s.eye(4),sig1,s.eye(16)))
def embed(C):
 zero(C[:16,16:]);zero(C[16:,:16])
 return s.SparseMatrix(s.kronecker_product(PL,C[:16,:16])+s.kronecker_product(PR,C[16:,16:]))
position_count=0;physical_sensitive=0;averaged_sensitive=0;barred_sensitive=0;choice_sensitive=0;sumgram=[s.S.Zero]*4
for a,b in zip(P['rows'],R['rows']):
 assert a['direction']==b['direction'] and a['Gram_p2_pdotq_qB2_qAV2']==b['Gram_p2_pdotq_qB2_qAV2']
 coeff=[dec(a[n]) for n in ['p_coefficient','q_barred_coefficient','q_averaged_coefficient']]
 actual=[dec(b[n]) for n in ['E_p_firsthat','E_q_barred_firsthat','E_q_averaged_firsthat']]
 for C,E in zip(coeff,actual):
  assert C.shape==(32,32) and E.shape==(128,128);zero(s.I*gh*embed(C)-E);position_count+=128**2
 cp,cb,ca=coeff
 # The momentum-p coefficient is twice the averaged current's q coefficient.
 zero(cp-2*ca)
 physical_sensitive+=int(bool(cp.todok()));barred_sensitive+=int(bool(cb.todok()));averaged_sensitive+=int(bool(ca.todok()))
 # Explicitly swapping current choices is detected only where V is nonzero.
 choice_sensitive+=int(bool(s.SparseMatrix(cb-ca).todok()))
 # At q_hat=0 the choices coincide; dropping the hatted kinetic term misses cp.
 zero(actual[0]-s.I*gh*embed(cp))
 gram=list(map(s.sympify,a['Gram_p2_pdotq_qB2_qAV2']));sumgram=[x+y for x,y in zip(sumgram,gram)]
 assert gram[0]>=0 and gram[2]>0 and gram[3]>=0
assert position_count==1622016 and [physical_sensitive,averaged_sensitive,barred_sensitive,choice_sensitive]==[17,17,33,16]
assert list(map(str,sumgram))==P['aggregate_Gram_p2_pdotq_qB2_qAV2']==R['aggregate_Gram_p2_pdotq_qB2_qAV2']==['272','272','132','68']
assert P['physical_hat_q_zero_sensitive']==17 and P['averaged_generic_sensitive']==17 and P['barred_generic_sensitive']==33
assert [R[n] for n in ['split_Clifford_relations_checked','barred_chirality_relations_checked','hatted_chirality_relations_checked','cross_hat_trace_checks','barred_momentum_checks','mass_checks']]==[21,4,2,297,132,33]
assert R['two_hat_probe_norms']==['2952','2312'] and R['witness_trace_divisor_to_chirality_trace']==4 and R['six_D_witness_not_dimreg_spinor_trace']
# Wrong trace divisor2 doubles every nonzero Gram and is explicitly rejected.
assert [2*z for z in sumgram]!=sumgram
# Wrong hat anticommutation conflicts with the concrete witness, rather than
# being inferred merely from a tally of an absent output.
hat8=s.kronecker_product(s.eye(4),sig1);zero(hat8*chi-chi*hat8);assert s.SparseMatrix(hat8*chi+chi*hat8).todok()
e,L=s.symbols('epsilon L',real=True);expected=[-s.Rational(1,2),-L/2,-L**2/4-s.pi**2/24]
for a,b,c in zip(P['moment_coefficients'],R['moment_coefficients'],expected):
 assert s.simplify(s.sympify(a,locals={'L':L})-c)==0 and s.simplify(s.sympify(b,locals={'L':L})-c)==0
assert expected[0]!=0 and expected[0]!=-expected[0]
mp.mp.dps=80;errors=[]
assert len(P['moment_probes'])==len(R['moment_probes'])==9
for a,b in zip(P['moment_probes'],R['moment_probes']):
 assert a['epsilon']==b['epsilon'] and a['mu_R2_over_m_IR2']==b['mu_R2_over_m_IR2']
 x,y=mp.mpf(a['J']),mp.mpf(b['J']);err=abs(x-y)/max(mp.mpf(1),abs(x),abs(y));assert err<mp.mpf('1e-50');errors.append(err)
for d in [P,R]:
 assert d['auxiliary_moment_not_model_threshold'] and d['provisional_evanescent_choices_not_physical_adoption'] and not d['full_fermionic_prescription_or_quantum_restoration']
# Scope assertions authenticate the selected applicability statements. They
# are not an exhaustive search of every historical file or a scheme adoption.
dimrec=(CAL/'canonical_so10_dimensional_counterterm_applicability/RECORD.md').read_text()
epc=(CAL/'canonical_so10_extended_source_pole/DERIVATION.md').read_text()
assert 'No spacetime spinor/gamma5/epsilon' in dimrec and 'Matter/fermions are excluded' in epc
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_CONDITIONAL_SPLIT_CLIFFORD_WARD_DEFECT_AND_EVANESCENT_MOMENT','elapsed_after_imports':time.perf_counter()-start,
 'heavy_generators':33,'operator_coefficient_positions_compared':position_count,'aggregate_Gram_p2_pdotq_qB2_qAV2':list(map(str,sumgram)),
 'physical_hat_q_zero_sensitive_directions_fixed_basis':physical_sensitive,'physical_hat_q_zero_insensitive_directions_fixed_basis':33-physical_sensitive,
 'barred_generic_sensitive_directions':barred_sensitive,'averaged_generic_sensitive_directions':averaged_sensitive,'current_choice_sensitive_directions_fixed_basis':choice_sensitive,
 'six_D_witness_Clifford_relations':21,'barred_chirality_relations':4,'hatted_chirality_relations':2,'cross_hat_inner_products':297,'barred_momentum_checks':132,'mass_checks':33,
 'wrong_hat_anticommutation_rejected':True,'wrong_witness_trace_divisor_rejected':True,'premature_d4_and_wrong_hat_dimension_sign_rejected':True,
 'auxiliary_moment_coefficients':list(map(str,expected)),'auxiliary_moment_quadrature_positions':len(errors),'max_scaled_quadrature_discrepancy':mp.nstr(max(errors),12),
 'physical_scheme_adopted':False,'complete_Majorana_regulator_or_charge_conjugation_constructed':False,'finite_FFV_FFS_model_threshold_calculated':False,'new_model_loop_integrals':0,
 'anomaly_or_quantum_restoration_claimed':False,'numerical_flavor_or_mass_selected':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
