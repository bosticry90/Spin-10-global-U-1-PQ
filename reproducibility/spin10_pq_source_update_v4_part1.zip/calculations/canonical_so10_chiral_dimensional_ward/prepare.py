"""CDW1 freeze the selected missing-scope evidence and conditional test."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='13cd571515b1d0340cbca0a74d3943243874bbb9'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-dimensional-ward-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 if str(p) in bind:assert bind[str(p)]==v
 bind[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V473.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
 'calculations/canonical_so10_direct_two_loop_heavy_threshold/RECORD.md','calculations/canonical_so10_direct_two_loop_heavy_threshold/YUKAWA_CONVENTION_V1.md',
 'calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/RECORD.md','calculations/canonical_so10_dimensional_counterterm_applicability/RECORD.md',
 'calculations/canonical_so10_dimensional_counterterm_applicability/RESULT.md','calculations/canonical_so10_extended_source_pole/DERIVATION.md',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 add(ROOT/n)
for folder,names in {
 'canonical_so10_fermion_goldstone_interface':['RECORD.md','RESULT.md','primary_v2_tables.json.gz','replay_v2_tables.json.gz','validation_receipt_v2.json'],
 'canonical_so10_fermion_ward_line':['RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
add(ROOT/'calculations/canonical_so10_fermion_goldstone_interface/validation_receipt_v2.json','52424d69de97649877193b309b94a702c0e88c4462aa9de56e5eb098df3f6211')
add(ROOT/'calculations/canonical_so10_fermion_ward_line/validation_receipt.json','d2179484cc56e72c2aa87c87d687268fec45a5272e0f5e3b2a364c5c60b6cf8a')
for name in ['RECORD.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if name.endswith('.py'):ast.parse(raw)
 q=HERE/(name+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 add(p);add(q)
CONTROL.mkdir(parents=True,exist_ok=False)
tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==29941
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'CDW1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('CDW1_FROZEN',len(bind),'bindings',flush=True)
