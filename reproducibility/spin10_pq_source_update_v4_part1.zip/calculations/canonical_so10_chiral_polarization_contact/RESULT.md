# CPC1: a finite two-point Ward contact is calculated and insertion-matched

The specified provisional Nambu continuation has a nonzero finite local gauge
two-point contact. A separately contracted and integrated evanescent insertion
reproduces its Ward contraction. The known transverse pole is also recovered.
This is an actual massless fermion-loop calculation within its stated domain,
not the earlier auxiliary three-propagator moment and not a massive threshold.

Separate receipt status:
`QUALIFIED_CONDITIONAL_FINITE_CHIRAL_TWO_POINT_CONTACT_AND_INSERTION_MATCH`,
SHA-256
`3bbec425b715d3a11037c699eb582e3f2566bc79a65121275b0d8b8643d9b70d`.
Scientific/director acceptance NOT_PERFORMED. Authority remains34/39.

## The calculated tensor

Use the actual historically matched YCT1 generators and define

```
G_ab = tr(T_a T_b),    M_ab = tr(T_a T_b^T),    N_ab = G_ab + M_ab.
```

For one Weyl family, physical external momentum `q_hat=0`, barred vector
indices and `q^2>0`, the parity-even polarization is

```
Pi_ab^mn = g^2/(16 pi^2) [
  G_ab C(epsilon,L) (q^2 delta_mn - q_m q_n)
  + N_ab F(epsilon,L) q^2 delta_mn
],
L = log(mu_R^2/q^2),    d = 4-2epsilon.
```

The form factors are independently derived, not fitted to the Ward identity:

```
C = 4 exp[(gamma_E+L)epsilon] Gamma(epsilon)
      Beta(2-epsilon,2-epsilon),
F = 2 exp[(gamma_E+L)epsilon] Gamma(1+epsilon)
      Beta(2-epsilon,2-epsilon)/(1-epsilon).

C = 2/(3epsilon) + 2L/3 + 10/9
    + epsilon*(L^2/3 + 10L/9 + 56/27 - pi^2/18) + ... ,
F = 1/3 + epsilon*(L/3 + 8/9) + ... .
```

The three declared families multiply the expression by3. Since `G=2 I45`,
the transverse pole is `4 I45`, matching FSN1. Their finite contact kernel,
after removing `g^2/(16pi^2)`, is `N q^2 delta_mn`.

`N` has25 eigenvalues4 and20 zeros in the fixed45-plane frame. Its SM12
projection has rank8. These ranks describe this regulator's color tensor,
not particle counts, anomaly ranks or physical additional interactions.
The transpose-sensitive term depends on the fixed evanescent identification
of the left and conjugate-right carriers. Changing that identification or a
complex carrier basis without transporting regulator data is not innocuous.

## Two independent routes and the endpoint terms

Primary evaluates the full barred/hatted polarization numerator using finite
chiral-block trace identities. After a Feynman-parameter shift, its angular
average separates into the transverse expression and

```
2 (G+M) (d-4)/d * J2(Delta) delta_mn,
J2 = -d*Delta*I2/(d-2),    Delta=x(1-x)q^2.
```

Replay instead contracts the free-line Ward defect before integrating. For
this physical external momentum, both earlier B and AV choices have
`E=2i hat_slash(p) H_a`. Finite split-Clifford/C matrices derive the numerator
of this insertion, including its two opposite endpoint coefficients. Both
endpoint odd tadpoles are retained and vanish under the explicitly stipulated
translation-invariant dimensional integral. No arbitrary cyclic rearrangement
of an ordered heat trace or discarded zero-momentum distribution is involved.

The surviving insertion gives

```
q_m Pi_ab^mn = g^2/(16pi^2) * 2 N_ab q_n I_hat,
I_hat/q^2 = -epsilon exp[(gamma_E+L)epsilon]
             Gamma(epsilon-1) Beta(2-epsilon,2-epsilon)
           = F/2.
```

Thus the independently calculated Ward insertion exactly equals the
polarization's contraction. Setting internal hats to zero before integration
misses this finite result in25 plane directions. The hatted dimension is the
analytic `d-4`, not the two positive auxiliary directions used to test algebra.
The auxiliary spin trace16 is divided by4 before applying the Nambu half.

Nine80-digit comparisons of closed Gamma/Beta functions with proper-time and
parameter integrals agree through65-digit serialization; stored maximum scaled
discrepancy is0.0, below1e-50. This is finite printed-precision agreement.
The original loop moments use dimensional analytic continuation; the replay
quadratures evaluate their reduced convergent Gamma/Beta representation.

## What is restored, and what is still missing

The measured finite contact supplies a quadratic restoring candidate

```
delta Pi_ab^mn = -g^2/(16pi^2) * (N_ab/3) q^2 delta_mn
```

per family. It cancels the selected local two-point defect. A transverse
invariant finite addition `zeta G_ab(q^2 delta_mn-q_m q_n)` remains free.
Neither `zeta`, the earlier `b0`, nor `kappa` is fixed or identified here.
The coefficient above comes from the actual graph and insertion; it is not
an unknown parameter assigned to force a cancellation.

There is a material applicability limit. The isolated tensor `N` fails
`[ad(h),N]=0` for8 of the12 actual residual-H generators, while the invariant
Gram passes. This is a **homogeneous color covariance** test. Failure excludes
local-H covariance of this isolated term; passing alone would not prove a
complete local-background identity. All24,300 commutator positions are checked.
The candidate restoring term is not by itself an admissible full non-Abelian
counterterm theorem. Cubic/quartic gauge terms, sources, scalar insertions,
the measure/phase and their compatibility with the project's heat construction
remain to be demonstrated. No complete H-covariant scheme bridge is claimed.

The two-point graph is insensitive to the B/AV hatted-vector vertex difference:
it has only barred external vertices. This does not qualify those prescriptions
as equivalent in other graphs. The result is a massless kinetic subgraph, not
an adopted physical zero-Yukawa model, changed vacuum or fermion spectrum.

The published comparator,
[Belusca-Maito et al., Secs3,5,6](https://arxiv.org/pdf/2004.14398), explains
why chiral continuations require evanescent and finite restoring terms.
Its charged/sterile construction is not the present conjugate-Nambu member;
its finite coefficients were not imported into this calculation.

## Evidence, resources and consequence

Primary and replay compare6363 color positions,32,400 hatted Lorentz/color
positions and256 barred spin traces, including zeros. Wrong right-transpose
handling is detected in20 plane directions and insensitive in25; premature
hat deletion has the complementary25 sensitive directions. Sign reversal,
omitted Gaussian half, auxiliary trace inflation and the unrelated prior
three-propagator moment fail the nonzero coefficient checks. This is bounded
computational corroboration with shared scientific premises, input data,
Python/SymPy/mpmath and AI authorship, not external physical confirmation.

Primary/replay/gate completed exit0 in6.4967431/39.0021424/1.1642271 seconds
after imports. Their4/20/2 resource samples have private maxima51,015,680/
49,922,048/55,001,088 bytes, not true peak measurements. Launch available
commit exceeded11.27GB. Frozen600s/8GiB sampled/350MiB launchfloor/16MiB
package limits were unexhausted. Preparation42/validation49 bindings and
seven source copies precede the workers. Full captures are preserved; no
failed or unfinished scientific worker occurred. Zero new two-loop integrals.

The next useful comparison is a precisely specified charged/sterile chiral
continuation with its free spectator factor normalized out. It can determine
whether the non-invariant transpose-sensitive color term is specific to this
continuation and whether their selected two-point results differ by a derived
finite local conversion. Do not add physical sterile matter or infer complete
scheme equivalence from such a comparison.

Historical YCI failure and all earlier results are preserved. Neither scalar
point's adverse quantum-control result is repaired. Flavor remains paused,
HB1/C5 blocked, E5/A5 and physical unification unqualified, custodyexit2/seven
NOTPASS. No physical regulator, benchmark, finite scheme or scientific
promotion was adopted. The complete investigation remains active/incomplete.
