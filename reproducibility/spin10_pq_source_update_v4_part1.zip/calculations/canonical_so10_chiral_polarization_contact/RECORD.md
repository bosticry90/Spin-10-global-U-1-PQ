# CPC1: actual finite evanescent gauge-polarization contact

Base2c7af4415d6d01e6bc7597d3323ed319299862cd/main,30115trackedblobs.
Previous goal turn PROGRESS: YCT1 full Yukawa realization, FSN1 statistics/
pole recovery, MAR1 historical-character identification and anomaly reuse.
Actual preflight clean/no matching workers. Whole goal active/incomplete.

Question: does the specified provisional chiral regulator produce a finite
local two-point Ward defect, and does the independently inserted line defect
produce exactly its contraction? A local gauge anomaly is not being sought:
its qualified representation screen is inherited. The new information is
an actual finite graph and its insertion, beyond the prior auxiliary moment.

Freeze current AGENTS/CHARTER/state113/34of39,V480, local/solo conventions,
YCT1 primary/replay generators/H embedding/receipt, FSN1 receipt, CDW1/MEC1/
MEB1 records/results/receipts and BFT f/receipt. Keep all historical evidence,
the failed YCI interface, scalar-point warnings and numerical flavor pause.
Use the historically matched candidate component realization provisionally.
No new physical matter assignment, numerical mass, Yukawa, vacuum or scheme.

Domain: massless kinetic gauge-current subgraph, one loop, Euclidean q^2>0,
physical external q_hat=0 and barred vector indices, parity-even part only.
This is a formal massless subgraph/normalization comparison, not a choice
Y126=0 for the physical theory. Internal momenta are d=4-2epsilon dimensional.
BMHV relations {bar_gamma,chi}=0,[hat_gamma,chi]=0, tracephysicalI=4.
Retain all evanescent numerator terms through integration/subtraction.

Define D0(p)=i slash(p), A_a=PL T_a-PR T_a^T,
Atilde_a=PR T_a-PL T_a^T, H_a=(A_a-Atilde_a)/2. CurrentB has
Gamma_bar=bar_gamma A,Gamma_hat=0. AV shares the same barred current;
the physical-external two-point loop contains no hatted vector vertex and
is insensitive to the B/AV interaction difference. It does not qualify
their equivalence for other graphs. Fixed left/conjugate-right evanescent
identification and formal charge-conjugation premises remain explicit.

Use the qualified Nambu Gaussian factor, not an auxiliary spin multiplicity:
Gamma2=1/2 int G_mu^a(-q) Pi_ab^munu(q) G_nu^b(q),
Pi_ab^munu=g^2/2 int tr[Gamma_a^mu slash(p) Gamma_b^nu slash(p+q)]/[p^2(p+q)^2].
The stated Euclidean sign follows from -Trlog(D)/2 and is checked against
FSN1's positive matter pole. Both loop orientations/real gauge fields are
included by this definition; no extra Dirac/Weyl or diagram factor is added.

Normalized measure: multiply ordinary Euclidean loop integral by
16pi^2*(exp(gamma_E)*mu_R^2/(4pi))^epsilon. L=log(mu_R^2/q^2).
Define I2(Delta)=exp(gamma_E epsilon)*(mu_R^2/Delta)^epsilon*Gamma(epsilon),
J2(Delta)=-d*Delta*I2/(d-2), Delta=x(1-x)q^2. These are analytic dimensional
integrals, not convergent radial integrals for all positive epsilon. q^2>0
and integrable parameter endpoints separate this UV question from q=0 IR
extensions. A scaleless physical vacuum or old heat/contact domain is not
substituted. Dimensional translation invariance applies to the endpoint
odd tadpoles in this selected graph, not arbitrary ordered heat traces.

Primary: finite chiral-block trace algebra and all actual color pairs. Derive
bar/hat numerators, perform tensor Feynman-parameter reduction, separate the
transverse form factor from any local delta_mn q^2 contact. Extract pole,
finite and epsilon terms from Gamma/Beta functions. Do not insert the desired
Ward cancellation to determine a scalar or color coefficient.

Replay: direct split-Clifford matrices with four barred/two auxiliary hatted
directions and optional C witness, normalized to trace4 rather than8/16.
They check algebra only: the analytic hatted dimension is d-4, not2. Contract
the actual free-line defect E=2i hat_slash(p) H before loop integration.
Keep both endpoint terms, justify their odd integrals and derive the surviving
two-denominator hatted moment independently. Compare its Ward form factor
with primary only after both outputs are complete. Proper-time Gamma(1+eps)
and parameter integrals provide nine80-digit finite-epsilon checks at
eps=.1,.01,.001 and mu_R^2/q^2=.5,2,5; serialize65digits,scaledgate1e-50.

Compare all45x45 color entries, SM12 projection and all Lorentz trace slots
including zeros. Derive G_ab=tr(Ta Tb) and transpose-sensitive trace rather
than assume the contact is universal. Test its residual-H covariance against
actual structure constants. The restored QUADRATIC expression may be
transverse while non-Abelian cubic/quartic/source conditions remain open.
Keep an invariant transverse finite ambiguity symbolic; do not identify it
with b0 or kappa. A negative contact kernel may be exhibited as a derived
quadratic restoring candidate, not adoption of a full subtraction scheme.

Controls: premature d=4/internalhat=0, wrong sign of d-4, omission of the
conjugate-right transpose, omitted Gaussian half, auxiliary trace inflation,
and substitution of the old positive-mass three-propagator auxiliary moment.
Require genuinely sensitive nonzero sectors and retain insensitive sectors.
Do not infer a complete gauge anomaly, QAP, determinant phase, quantum measure,
massive matter C1 or full Slavnov restoration from this two-point comparison.

Published standard: Belusca-Maito et al.2004.14398v2,Secs3.2-3.3,5.2,6,
https://arxiv.org/pdf/2004.14398 . Distinct chiral continuations and finite
restoring counterterms are established QFT. Their sterile-chirality model
and finite coefficients are not this Nambu prescription's answer. Shared
physical premises/data, Python/SymPy/mpmath and AI authorship limit corroboration.

Freeze seven sources/copies and inputs first; sequential primary/replay/gate,
600s each afterimports,8GiB sampledprivate,350MiB launchfloor,16MiB package.
Any failure/unfinished attempt retained; new version for correction; no agents.
Scientific/director acceptance NOT_PERFORMED. Authority34/39 unchanged,
E5/A5unqualified,HB1/C5blocked,flavorpaused,custodyexit2/seven NOTPASS. No remote
action/adoption, fitting unknown fermions or reopening closed failed routes.
