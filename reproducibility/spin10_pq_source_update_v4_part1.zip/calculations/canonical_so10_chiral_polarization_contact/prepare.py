"""CPC1 freeze full inputs and seven sources before either calculation."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='2c7af4415d6d01e6bc7597d3323ed319299862cd';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/chiral-polarization-contact-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V480.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:add(ROOT/n)
for folder,names in {
 'canonical_so10_yukawa_carrier_transport':['RECORD.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_chiral_dimensional_ward':['RECORD.md','RESULT.md','validation_receipt.json'],
 'canonical_so10_majorana_evanescent_current':['RECORD.md','RESULT.md','validation_receipt.json'],
 'canonical_so10_matter_evanescent_brst':['RECORD.md','RESULT.md','validation_receipt.json'],
 'canonical_so10_fermion_statistical_normalization':['RECORD.md','RESULT.md','validation_receipt.json'],
 'canonical_so10_matter_anomaly_reuse':['RESULT.md','validation_receipt.json'],
 'canonical_so10_background_threshold_inputs':['primary_tables.json.gz','validation_receipt_v2.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
for n,h in {
 'project_state.json':'d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8',
 'calculations/canonical_so10_yukawa_carrier_transport/validation_receipt.json':'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b',
 'calculations/canonical_so10_fermion_statistical_normalization/validation_receipt.json':'330046873656c162bb502ade91324dc1bbb9e5c2fb9149d99ce452ba25e0079b',
 'calculations/canonical_so10_background_threshold_inputs/primary_tables.json.gz':'230e87ea09358bcc63e14fc2188a0f5fa7c2ce3532e6bb0ab7f53f257053cbbf',
 'calculations/canonical_so10_background_threshold_inputs/validation_receipt_v2.json':'fd1afe95d714f99d37828660f146bdc1b71c6ae13b014de16d51123766f561e6'}.items():add(ROOT/n,h)
for name in ['RECORD.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30115
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'CPC1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('CPC1_FROZEN',len(b),'bindings',flush=True)
