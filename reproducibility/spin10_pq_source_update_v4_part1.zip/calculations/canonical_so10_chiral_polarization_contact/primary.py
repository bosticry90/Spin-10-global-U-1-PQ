"""CPC1 direct polarization numerator and exact tensor integral reduction."""
from data import *
from itertools import product
start=begin('primary');e,L,x,q2,qq,dd=s.symbols('epsilon L x q2 qq delta');dim=4-2*e;u=x*(1-x);Delta=u*q2
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
chi=s.diag(1,1,-1,-1);PL=(s.eye(4)+chi)/2;PR=s.eye(4)-PL
bar=[]
for mu,al,nu,be in product(range(4),repeat=4):
 # Nambu half times the sum of the two conjugate chirality blocks.
 value=s.simplify(sum(s.trace(g[mu]*P*g[al]*g[nu]*P*g[be]) for P in [PL,PR])/2)
 target=2*(int(mu==al)*int(nu==be)+int(mu==be)*int(al==nu)-int(mu==nu)*int(al==be))
 assert value==target;bar.append(str(value))
# Hat anticommutation with barred gamma and commutation with P gives
# trace_phys(bar_gamma_mu hat_gamma bar_gamma_nu hat_gamma)=-4delta_mu_nu.
hat=[str(-s.trace(g[mu]*g[nu])) for mu,nu in product(range(4),repeat=2)]
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,d['Tminus']));H=dec(d['H_new'])
G=s.Matrix(45,45,lambda a,b:s.simplify(s.trace(T[a]*T[b])));M=s.Matrix(45,45,lambda a,b:s.simplify(s.trace(T[a]*T[b].T)));N=G+M
# Exact angular average of the measured bar/hat traces, including d-4.
gs,ms=s.symbols('G M');I=s.Symbol('I2');J=-dim*Delta*I/(dim-2)
polar=s.expand((-4*gs/dim+2*ms*(dim-4)/dim)*J*dd+2*gs*Delta*I*dd-4*gs*u*qq*I)
cov=4*gs*u*(q2*dd-qq)*I;diff=s.factor(polar-cov)
scalar=s.simplify(diff/((gs+ms)*q2*dd*I));assert s.simplify(scalar-2*e*u/(1-e))==0
B=s.gamma(2-e)**2/s.gamma(4-2*e)
F=2*s.exp((s.EulerGamma+L)*e)*s.gamma(1+e)*B/(1-e)
C=4*s.exp((s.EulerGamma+L)*e)*s.gamma(e)*B
fc=[s.simplify(F.subs(e,0)),s.simplify(s.diff(F,e).subs(e,0))]
Cregular=4*s.exp((s.EulerGamma+L)*e)*s.gamma(1+e)*B
cc=[s.simplify(s.diff(Cregular,e,k).subs(e,0)/s.factorial(k)) for k in [0,1,2]]
import mpmath as mp
mp.mp.dps=80;rows=[]
for ep in ['.1','.01','.001']:
 for scale in ['.5','2','5']:
  z=mp.mpf(ep);r=mp.mpf(scale);value=2*mp.exp(mp.euler*z)*r**z*mp.gamma(1+z)/(1-z)*mp.beta(2-z,2-z)
  rows.append({'epsilon':ep,'scale_ratio':scale,'F':mp.nstr(value,65)})
finish('primary',{'method':'direct_bar_hat_numerator_and_full_tensor_Feynman_integral','bar_trace_coefficients':bar,'formal_hat_trace_coefficients':hat,
 'G':enc(G),'M':enc(M),'contact_color':enc(N),'SM_contact_color':enc(H.T*N*H),'SM_G':enc(H.T*G*H),
 'contact_coefficients_F0_F1':list(map(str,fc)),'transverse_coefficients_pole_finite_epsilon':list(map(str,cc)),
 'contact_form_factor':str(F),'finite_epsilon_rows':rows,'physical_spin_trace':4,'gaussian_factor':'1/2','endpoint_or_phase_claim':False,
 'three_family_contact_kernel_stripped_q2_delta':enc(3*fc[0]*N),'three_family_transverse_pole':enc(3*cc[0]*G),
 'new_two_loop_integrals':0,'provisional_only':True},start)
