"""CPC1 finite split-Clifford witness and independently integrated Ward insertion."""
from data import *
from itertools import product
import mpmath as mp
start=begin('replay');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
gs=[s.SparseMatrix(s.kronecker_product(g,s.eye(2))) for g in g8];chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL;P=[PL,PR]
C8=g8[0]*g8[2]*g8[5];C=s.kronecker_product(C8,pa[1]);Ci=C.inv();assert C.T==-C
assert Ci*chi*C==chi.T
for j,g in enumerate(gs):
 assert Ci*g*C==-g.T
 assert (g*chi+chi*g if j<4 else g*chi-chi*g)==s.zeros(16)
 for k,h in enumerate(gs):assert g*h+h*g==2*int(j==k)*s.eye(16)
# Explicit factor4 reduces the auxiliary C16 trace to the physical trace4.
bar=[]
for mu,al,nu,be in product(range(4),repeat=4):bar.append(str(s.simplify(sum(s.trace(gs[mu]*p*gs[al]*gs[nu]*p*gs[be]) for p in P)/8)))
hatcoeff={}
for mu,nu in product(range(4),repeat=2):
 hatcoeff[mu,nu]=[[s.simplify(s.trace(gs[mu]*P[i]*gs[4]*gs[nu]*P[j]*gs[4])/8) for j in range(2)] for i in range(2)]
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,d['Tminus']));H=dec(d['H_new']);S=[(t+t.T)/2 for t in T]
def trprod(A,B):return s.simplify(sum(z*B[j,i] for (i,j),z in s.SparseMatrix(A).todok().items()))
# The projected q.Gamma identity keeps both endpoint terms. Their dimensional
# integrals are odd tadpoles after an allowed loop shift. The remaining
# -hat_slash H insertion is contracted BEFORE the hatted angular integral.
kp=[[ -s.trace(P[i]*gs[0]*P[j]*gs[0])/4 for j in range(2)] for i in range(2)]
pp=[[ -s.trace(P[i]*gs[0]*gs[0]*P[j])/4 for j in range(2)] for i in range(2)]
K=s.zeros(45);Pmom=s.zeros(45);hatmats={key:s.zeros(45) for key in hatcoeff}
for a,b in product(range(45),repeat=2):
 ha=[S[a],-S[a]];bc=[T[b],-T[b].T];ac=[T[a],-T[a].T]
 K[a,b]=s.simplify(sum(kp[i][j]*trprod(ha[i],bc[j]) for i,j in product(range(2),repeat=2)))
 Pmom[a,b]=s.simplify(sum(pp[i][j]*trprod(ha[i],bc[j]) for i,j in product(range(2),repeat=2)))
 pairs=[[trprod(ac[i],bc[j]) for j in range(2)] for i in range(2)]
 for key,v in hatcoeff.items():hatmats[key][a,b]=s.simplify(sum(v[i][j]*pairs[i][j] for i,j in product(range(2),repeat=2)))
assert K==-Pmom
N=K/2;M=hatmats[0,0]/2;G=s.Matrix(45,45,lambda a,b:trprod(T[a],T[b]))
e,L=s.symbols('epsilon L');B=s.gamma(2-e)**2/s.gamma(4-2*e)
# Independent two-denominator moment via h/d times J2=(d/2)I1:
# Ihat/q^2 = -epsilon Gamma(epsilon-1) B exp[(gamma_E+L)epsilon].
Ihat=-e*s.exp((s.EulerGamma+L)*e)*s.gamma(e-1)*B
Ihat_regular=s.exp((s.EulerGamma+L)*e)*s.gamma(1+e)*B/(1-e)
F=2*Ihat_regular;fs=s.series(F,e,0,2).removeO().expand();fc=[s.simplify(fs.coeff(e,k)) for k in [0,1]]
mp.mp.dps=80;rows=[]
for ep in ['.1','.01','.001']:
 for scale in ['.5','2','5']:
  z=mp.mpf(ep);r=mp.mpf(scale)
  gam=mp.quad(lambda t:mp.exp(-t)*t**z,[0,1,mp.inf]);bet=mp.quad(lambda x:(x*(1-x))**(1-z),[0,mp.mpf('.5'),1])
  value=2*mp.exp(mp.euler*z)*r**z*gam*bet/(1-z)
  rows.append({'epsilon':ep,'scale_ratio':scale,'F':mp.nstr(value,65)})
finish('replay',{'method':'explicit_split_C_witness_and_Ward_insertion_before_integration','bar_trace_coefficients':bar,
 'hat_numerator_matrices':{f'{a}_{b}':enc(v) for (a,b),v in hatmats.items()},'G':enc(G),'M':enc(M),'ward_k_coefficient':enc(K),'ward_p_coefficient':enc(Pmom),
 'contact_color':enc(N),'SM_contact_color':enc(H.T*N*H),'SM_G':enc(H.T*G*H),'contact_coefficients_F0_F1':list(map(str,fc)),
 'Ihat_analytic_expression':str(Ihat),'finite_epsilon_rows':rows,'witness_spin_trace':16,'witness_to_physical_trace_divisor':4,'gaussian_factor':'1/2',
 'odd_endpoint_integrals_retained_and_shifted':2,'new_two_loop_integrals':0,'provisional_only':True},start)
