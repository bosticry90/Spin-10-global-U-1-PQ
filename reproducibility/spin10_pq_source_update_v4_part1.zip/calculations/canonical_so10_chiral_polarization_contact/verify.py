"""CPC1 full comparison, Ward restoration within scope, and covariance audit."""
from data import *
import mpmath as mp
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');L=s.Symbol('L')
assert P['bar_trace_coefficients']==R['bar_trace_coefficients'] and len(P['bar_trace_coefficients'])==256
positions=0
for name,n in [('G',45),('M',45),('contact_color',45),('SM_G',12),('SM_contact_color',12)]:
 a,b=dec(P[name]),dec(R[name]);assert a==b;positions+=n*n
G,M,N=map(lambda k:dec(P[k]),['G','M','contact_color']);assert G==2*s.eye(45) and N==G+M
assert dec(R['ward_k_coefficient'])==2*N and dec(R['ward_p_coefficient'])==-2*N
hatpositions=0
for mu in range(4):
 for nu in range(4):
  assert dec(R['hat_numerator_matrices'][f'{mu}_{nu}'])==2*int(mu==nu)*M;hatpositions+=2025
assert N.T==N and N*N==4*N;rank=N.rank();assert rank==25
nh=dec(P['SM_contact_color']);assert nh.rank()==8 and nh*nh==4*nh
assert P['contact_coefficients_F0_F1']==R['contact_coefficients_F0_F1']
f0,f1=map(s.sympify,P['contact_coefficients_F0_F1']);assert f0==s.Rational(1,3) and s.simplify(f1-(L/3+s.Rational(8,9)))==0
cp,cf,ce=map(s.sympify,P['transverse_coefficients_pole_finite_epsilon']);assert cp==s.Rational(2,3) and s.simplify(cf-2*L/3-s.Rational(10,9))==0
assert s.simplify(ce-(L**2/3+10*L/9+s.Rational(56,27)-s.pi**2/18))==0
assert dec(P['three_family_transverse_pole'])==4*s.eye(45) and dec(P['three_family_contact_kernel_stripped_q2_delta'])==N
# The derived quadratic counterterm is minus this contact. An independent
# transverse invariant normalization zeta*G remains free and is annihilated
# by q_mu; no equation here fixes the full quantum scheme.
contact=N*f0;counterterm=-contact;assert contact+counterterm==s.zeros(45)
mp.mp.dps=80;maximum=mp.mpf('0')
assert len(P['finite_epsilon_rows'])==len(R['finite_epsilon_rows'])==9
for a,b in zip(P['finite_epsilon_rows'],R['finite_epsilon_rows']):
 assert (a['epsilon'],a['scale_ratio'])==(b['epsilon'],b['scale_ratio'])
 x,y=mp.mpf(a['F']),mp.mpf(b['F']);err=abs(x-y)/max(mp.mpf(1),abs(x),abs(y));maximum=max(maximum,err);assert err<mp.mpf('1e-50')
# Actual residual-H covariance of the isolated contact, not an assumption
# that its tensor is the invariant color Gram.
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');H=dec(d['H_new'])
bft=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz');f=[(a,b,c,s.sympify(v)) for a,b,c,v in bft['f']]
noncov=[];commuting=[];covpositions=0
for j in range(12):
 A=s.SparseMatrix(45,45,{})
 for a,b,c,v in f:A[c,b]+=H[a,j]*v
 assert A*G-G*A==s.zeros(45)
 D=s.SparseMatrix(A*N-N*A).applyfunc(s.simplify);covpositions+=2025
 (noncov if D.todok() else commuting).append(j)
assert noncov
for mu in range(4):
 for nu in range(4):assert s.sympify(P['formal_hat_trace_coefficients'][4*mu+nu])==-4*int(mu==nu)
premature_sensitive=sum(int(N[j,j]!=0) for j in range(45));wrong_transpose_sensitive=sum(int((G+G-N)[j,j]!=0) for j in range(45))
assert premature_sensitive==25 and wrong_transpose_sensitive==20
assert N*f0!=-N*f0 and N*f0!=2*N*f0 and N*f0!=4*N*f0 and N*f0!=s.zeros(45)
assert P['physical_spin_trace']==4 and R['witness_spin_trace']==16 and R['witness_to_physical_trace_divisor']==4
assert P['gaussian_factor']==R['gaussian_factor']=='1/2' and R['odd_endpoint_integrals_retained_and_shifted']==2
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_CONDITIONAL_FINITE_CHIRAL_TWO_POINT_CONTACT_AND_INSERTION_MATCH','elapsed_after_imports':time.perf_counter()-start,
 'color_matrix_positions_compared':positions,'hat_Lorentz_color_positions_checked':hatpositions,'bar_trace_coefficients_compared':256,
 'contact_scalar_finite':'1/3','contact_scalar_epsilon':str(f1),'transverse_pole':'2/3','transverse_finite':str(cf),'transverse_epsilon':str(ce),
 'contact_color_rank':rank,'contact_color_eigenvalues':{'4':25,'0':20},'SM_contact_rank':8,'three_family_transverse_pole':'4*I45','three_family_contact_kernel':'N*q^2*delta_mn',
 'Ward_insertion_matches_polarization':True,'quadratic_contact_cancellation_checked':True,'transverse_finite_ambiguity':'zeta_symbolic_unfixed',
 'isolated_contact_H_covariant':False,'H_noncovariant_generator_indices':noncov,'H_commuting_generator_indices':commuting,'H_covariance_positions_checked':covpositions,
 'premature_hat_zero_sensitive_directions':premature_sensitive,'wrong_right_transpose_sensitive_directions':wrong_transpose_sensitive,
 'proper_time_parameter_comparisons':9,'max_scaled_discrepancy':mp.nstr(maximum,12),'new_two_loop_integrals':0,'new_massless_two_point_loop_family':1,
 'full_BRST_restoration_or_H_covariant_scheme_bridge_qualified':False,'finite_massive_threshold_or_phase_qualified':False,'physical_scheme_or_benchmark_adopted':False,
 'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
