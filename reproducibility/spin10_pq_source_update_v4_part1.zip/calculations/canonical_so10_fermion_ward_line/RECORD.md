# FWL1: the ordered gauge/Goldstone Ward identity on an actual fermion line

FGI1 V2 has completed the actual vector-sector/Goldstone interface. Next
question: when a longitudinal heavy-vector vertex is contracted on a free
fermion line, what precisely accompanies its Goldstone vertex? The inverse
propagator endpoint terms must be derived, not discarded in a future loop.
This is an algebraic input for two-loop kernels, not a regulated-loop/QAP
claim or another finite threshold at the uncontrolled old benchmark.

Freeze FGI1 V2 sources/receipt/tables and actual oriented vector/Goldstone
bases. Use all33 heavy vector directions in that basis, not one favorable
projection. Neutrino mass mu is a formal real Takagi spectral variable, not
a chosen physical mass/flavor benchmark. No hierarchy or small-mass limit.
The general complex symmetric mass identity is checked separately; numerical
family eigenvalues and the physical-scalar Yukawa complement remain unfixed.

Use explicit Euclidean gamma matrices, {gamma_mu,gamma_nu}=2delta_mu_nu,
P_L=diag(I2,0),P_R=diag(0,I2). This is a Wick-rotated algebraic quadratic
operator, not a new Lorentzian/causal continuation theorem. For a Hermitian
spinor generator T_e define

 A_e=P_L tensor T_e-P_R tensor T_e^T,
 Atilde_e=P_R tensor T_e-P_L tensor T_e^T,
 D(p)=i gamma.p tensor I16+I4 tensor(mu P_N).

The right-handed generator is -T^T for the conjugate Weyl component. No
doubling of the physical Weyl count or closed-loop factor is inferred.
The mass-linear four-component Goldstone operator is

 Y4_e=mu(P_L tensor Y_e+P_R tensor Y_e^dagger),
 Y_e=i(T_e^T P_N+P_N T_e)/sqrt(lambda_e),

in the oriented FGI1 convention. With k=p+q, the proposed exact identity is

 D(k)A_e-Atilde_e D(p)
       = i[gamma.q A_e-sqrt(lambda_e)Y4_e].

For F(p)=D(p)^-1, retain ordering to obtain

 i F(k)[gamma.q A_e-sqrt(lambda_e)Y4_e]F(p)
       = A_e F(p)-F(k)Atilde_e.

Multiplication by g replaces g sqrt(lambda_e) by M_V,e; no g value is chosen.
This is a FREE ordered-line identity. Heat factors and insertions do not in
general commute with its endpoints. Do not infer a regulated trace identity,
vanishing contact/tadpole terms, quantum gauge-width cancellation, forest
subtraction or complete FFV/FFS amplitude from it.

Primary uses four-component Clifford/chiral matrices and actual 64-by-64
Nambu/internal operators. Check all independent p,q and mass coefficients
for every direction, proving the polynomial identity for arbitrary momenta.
Use the exact free inverse with P_N and its complement for an independent
sewing check. Replay derives the two-component Weyl block equations and
multiplies their ordered 2-by-2 blocks, importing no primary helper/results.
Compare all33 resulting64-by-64 endpoint kernels including implicit zeros.

For sewing, the predetermined Euclidean probe p=(1,2,3,4),q=(-1,1,0,2)
has p²=30,k²=54. Mu remains symbolic, so inverses exist for every real mu.
These are algebraic test momenta, not physical input scales or amplitudes.
No integration, pole extraction, analytic continuation or numerical mass.

Controls: wrong Goldstone sign/phase, omitted inverse-propagator endpoints,
wrong ordering of those endpoints and an adjoint rather than transpose mass
variation. Report insensitive zero-Goldstone directions rather than pretend
every control tests all33. Check generic complex symmetric mass/Hermitian
generator algebra, Majorana symmetry and Euclidean inverse/Clifford limits.
The field covariance identity is established QFT (Martens1011.2927v2 eq24);
FGI1's actual map, not an imported finite formula, fixes component inputs.

Sequential primary/replay/separate gate, frozen sources/copies and bindings
first. 600s each after imports,8GiB sampled private,350MiB launch floor,
16MiB package. Stop/preserve any discrepancy, failed/incomplete capture or
resource exhaustion; no gate weakening. No agents, numerical flavor or mass
fit, new input prescription, benchmark or theory adoption. The scalar points'
warnings remain, with no unknown fermion cancellation assumed. State113/
34of39, HB1/C5 blocks, flavor pause and custodyexit2/seven NOTPASS stay.
Shared representation, covariance premise, software and AI author limit
independence. Scientific/director acceptance NOT_PERFORMED; goal incomplete.
