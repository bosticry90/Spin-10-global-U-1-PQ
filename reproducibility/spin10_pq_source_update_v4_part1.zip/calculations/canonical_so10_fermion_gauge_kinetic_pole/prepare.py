"""GFK1 freeze actual physical reference and matter inputs before execution."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='1b8e47f52f46c6ee909510d3af9bd13c8ca6befb';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-gauge-kinetic-pole-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V487.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/primary.json',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/validation_receipt.json']:add(ROOT/n)
for folder,names in {
 'canonical_so10_yukawa_carrier_transport':['RECORD.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_background_reference_normalization':['DERIVATION.md','RESULT.md','validation_receipt_v6.json'],
 'canonical_so10_auxiliary_vector_g2':['RESULT.md','validation_receipt.json'],
 'canonical_so10_fermion_goldstone_interface':['replay_v2_tables.json.gz','validation_receipt_v2.json'],
 'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json'],
 'canonical_so10_sterile_massive_propagator':['RESULT.md','validation_receipt.json'],
 'canonical_so10_fermion_yukawa_self_energy':['RECORD.md','RESULT.md','validation_receipt.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
for n,h in {
 'project_state.json':'d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8',
 'calculations/canonical_so10_yukawa_carrier_transport/validation_receipt.json':'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b',
 'calculations/canonical_so10_background_reference_normalization/validation_receipt_v6.json':'77699e6902ce3f3cb9f4c066cd86d3c1eb784dc3a76f48d8e9807bdcabdfb941',
 'calculations/canonical_so10_auxiliary_vector_g2/validation_receipt.json':'638d7900f163e1aae1321d6a3f5a6c09d06552a208e11c8ed87d967501a97c66',
 'calculations/canonical_so10_sterile_matter_action/validation_receipt.json':'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41',
 'calculations/canonical_so10_sterile_massive_propagator/validation_receipt.json':'53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c',
 'calculations/canonical_so10_fermion_yukawa_self_energy/validation_receipt.json':'960dd63d9aacb2a8ef30bb13b029470458c0cfef761db7f758945e101e44b3b8'}.items():add(ROOT/n,h)
for name in ['RECORD.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30306
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'GFK1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GFK1_FROZEN',len(b),'bindings',flush=True)
