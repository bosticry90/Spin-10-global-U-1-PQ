# GFK1: the actual two-width fermion gauge kinetic pole

The actual reference gives the one-loop inverse-propagator pole

```
delta D_gauge,pole = +i g10^2 bar_slash
                    (PL C_width+PR C_width^T)/(16pi^2epsilon),
C_width = eta_H C_H + xi[(45/8) I16-C_H].
```

The corresponding counterterm has the opposite sign. All three families
carry `I3 tensor C_width`; no numerical Yukawa or mass choice is made.
This completes one gauge kinetic UV input in the provisional matter
construction. It is not a finite amplitude, complete counterterm forest,
physical gauge choice or full symmetry-restoration result.

Receipt `validation_receipt.json`, SHA-256
`d29b95ea3d6d463f765fe940a1cc25a89cd62d04bf0ba8e0efc94157f8ffd376`, has status
`QUALIFIED_ACTUAL_TWO_WIDTH_FERMION_GAUGE_KINETIC_POLE`.
Scientific/director acceptance NOT_PERFORMED; authority34/39 unchanged.

## The widths were recovered from the action's reference matrix

The frozen643-field raw reference Hessian was transported by its actual
physical-to-raw inverse into the225 vector/auxiliary coordinates. All50,625
positions, including color-off-diagonal zeros, match the expected free blocks.
This distinction matters: the raw field labels at the same numerical indices
are not the physical vector/auxiliary chart. Substituting that raw slice fails.

The actual light12 widths are eta_H, and the heavy33 widths are xi. There
is no additional factor2 or inverse width. The inherited contour gives each
Euclidean block

```
K = [[q^2 I-q q^T, q],[-q^T,w]],
G_BB = I/q^2+(w-1)q q^T/q^4,
G_BL = -q/q^2,   G_LB=q^T/q^2,   G_LL=0.
```

Both inverse orders pass. Replay obtains the inverse from the normalized
longitudinal2x2 block. No division by w, auxiliary elimination or physical
zero-width limit is needed. The transverse/longitudinal width is retained
rather than replaced by a uniform Feynman gauge.

In the actual45-plane color frame,
`W=eta_H P_H+xi(I-P_H)`. The H span is constructed from the YCT1 matched
generators, and its full45x45 projector agrees with FGI1's massless vector
projector, including orientation and zeros. The physical current contraction
is the ordered sum `C_width=sum_ab W_ab T_a T_b`. Its conjugate-right sum
is the transpose because W is symmetric. No averaged mass or charge is used.

## Two loop routes and the model-specific color result

The primary Taylor-expands the barred-current numerator and integrates its
rotational moments in d dimensions with barred rank4. Its Feynman and
longitudinal angular factors are

```
f(d) = -2+4/d,
l(d) = -2/d-12/[d(d+2)].
```

Both have residue coefficient-1 at d=4. The open-line factor from `-V S V`
is `-i g10^2`; together they give the positive i in the displayed pole.
There is no closed-loop Pfaffian half on this graph.

Replay uses the shifted Feynman parameter for the longitudinal term and the
first-moment routing identity for the Feynman term. Its residue factors are
`-1` and `-4/d`, with the same values at d=4. These pole-truncated expressions
differ away from4. They do not determine equal finite coefficients or a full
reference conversion. No unseparated scaleless integral is assigned zero.

The physical pp numerator and both gauge vertices contain barred gamma
matrices. The hatted fermion derivative pole is zero in this graph. This
does not remove FKP1's nonzero hatted **scalar** derivative pole or supply
the complete evanescent gauge/source action.

The primary directly contracts the actual45 current matrices with the
actual color projector. Replay derives C_H from the independently supplied
SM representation data, normalized hypercharge and weak/color Casimirs,
checking the actual SM matrices too. The total carrier Casimir is45/8,
with its trace normalization computed from the actual generator entries.

| SM component | Multiplicity within16 | C_H | 45/8-C_H |
| --- | ---: | ---: | ---: |
| Q | 6 | 21/10 | 141/40 |
| uc | 3 | 8/5 | 161/40 |
| dc | 3 | 7/5 | 169/40 |
| L | 2 | 9/10 | 189/40 |
| ec | 1 | 3/5 | 201/40 |
| N | 1 | 0 | 45/8 |

Thus the two widths cannot generally be averaged. C_H commutes with all12
actual H generators, while40 of the45 plane generators have nonzero
commutator with it. The latter are individual plane-frame counts, not a
count of broken physical particles. This gauge-dependent field pole does
not establish a gauge anomaly. The related gauge/Yukawa/source operations
are still needed before assessing simultaneous renormalization.

The uniform-width limit gives `C_width=w*(45/8)I`, matching the standard
fermion self-energy structure in [Belusca-Maito et al., Sec5.2.1 Eq5.10 and9](https://arxiv.org/pdf/2004.14398).
That comparison supplies a normalization anchor, not the two-width answer
or a reason to impose uniform widths. Extra open-line half, family factor3,
width exchange/averaging and omitted longitudinal terms fail the checks.

## Validation and remaining work

Primary/replay/gate completed exit0 in7.8679729/1.2342512/6.7416642s after
imports. Private-memory samples5/2/4 have maxima56,754,176/54,345,728/
56,778,752 bytes, not peaks. Frozen600s per worker,8GiB sampled private,
350MiB launch floor and16MiB package bounds were unexhausted. No scientific
worker or verifier failed. Preparations bind42/49 paths; seven source copies
and complete native captures are retained. Peer-output denial was active.

A few read-only navigation calls used missing filenames or printed long
historical JSON receipts beyond the display limit; the relevant actual
fields were subsequently read directly. They launched no scientific worker
and changed no evidence. The scientific calculation and validation have
complete captures. Current-turn E4 readiness completed with expected exits
0,0,0,0,0,2; custody remains exit2/seven unresolved NOTPASS.

This is one new one-loop UV pole family and zero two-loop integrals. The
two mathematical routes share action/reference assumptions, supplied
representation data, power counting, Python/SymPy and AI authorship. Their
agreement checks implementation and normalization, not the independent
physical validity of the model. No external scientific confirmation is claimed.

Combined with FYS1, the leading fermion kinetic input in16pi^2epsilon units
is `g10^2 I3 tensor C_width + W_Yukawa/2`, with the charge-conjugate transpose.
This does not determine the finite field normalization or complete matter
counterterm action. Full gauge/Yukawa/source vertices, mixed mass/tadpole
terms, evanescent restoration, measure/phase/QAP and finite matching remain.

Before a gauge-Yukawa vertex calculation, inspect the actual nonlinear
gauge-fixing scalar/auxiliary vertices and mixed propagators. The standard
linear-gauge vertex formula is only a comparator until those possible
contributions are excluded or included by actual support/power counting.
That support reduction is the next smallest useful action.

No physical width, mass, flavor point, benchmark, scheme or foundational
adoption occurred. Both scalar points' negative quantum-control evidence,
old failed interfaces, flavor pause, HB1/C5 blocks and quartet failure remain.
State113/34of39, E5/A5 and physical matter C1/unification standing are
unchanged. No historical/policy editing, remote push or external action.
