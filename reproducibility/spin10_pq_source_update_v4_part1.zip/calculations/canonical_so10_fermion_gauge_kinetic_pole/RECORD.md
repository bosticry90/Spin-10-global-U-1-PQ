# GFK1: recover both gauge widths and derive the fermion gauge kinetic pole

Base1b8e47f52f46c6ee909510d3af9bd13c8ca6befb/main/30306 tracked blobs.
Previous goal turn PROGRESS: FKP1,FYS1,YPP1 supply actual Yukawa pole inputs.
Full investigation ACTIVE/incomplete. No existing fermion gauge self-energy
calculation was identified. The next necessary parent-counterterm input is
its gauge contribution in the actual two-width reference, not a convenient
uniform-gauge substitute. This calculation does not adopt a physical scheme.

Freeze live AGENTS/CHARTER/state113/34of39,V487/local/solo conventions;
actual retained643-field raw reference Hessian and physical-to-raw inverse,
its receipt; BCR1 contour/reference result/receipt; AV2 width dictionary;
YCT1 complete actual45 generators/12H frame; FGI1 vector projectors/receipt;
SMA1 physical current/Gaussian and SMP1 actual free inverse; FYS1 pole input.
Keep all failures, physical exclusions, paused flavor and HB1/C5 blocks.

First recover all225 physical vector/auxiliary Hessian entries by congruence
from the frozen canonical matrix. Physical order is180 vectors then45
auxiliaries within the full physical frame (aux indices508..552); the raw
field_order labels must not be confused with these physical indices. Check
all45 free color5x5 blocks, mixed signs and widths. Under the already tested
Euclidean contour, the block is [[q^2 I-q q^T,q],[-q^T,w]]. Derive its inverse
without assuming w invertible: BB=I/q^2+(w-1)q q^T/q^4, mixed=-q/q^2,+q^T/q^2,
LL=0. Verify w_H=eta_H for12 unbroken directions, w_M=xi for33 broken.
No width value or physical IR limit is selected.

The leading plane-color width is W=eta_H P_H+xi(I-P_H), with P_H taken from
the actual YCT H span and independently compared to FGI's massless vector
projector. Derive its orientation, not just its rank. All physical scalar
mass/mixing and fermion masses are retained in the theory; power counting
only uses their mass-independent leading kinetic UV symbol here. Mixed
auxiliary edges cannot connect two ordinary fermion gauge vertices; there
is no new fermion-auxiliary vertex.

Use the SMA1 physical current -ig bar_gamma_mu(PL Ta-PR Ta^T), pp propagator
-i bar_slash/k^2, physical spin trace conventions and open-line -V S V.
There is NO closed-loop Pfaffian half on this open line. Both gauge indices
at fermion vertices are barred; do not replace the physical gamma sum by a
d-dimensional anticommuting-gamma identity. At p_E^2>0 the massless bubble
has an integrable IR endpoint. A positive auxiliary IR mass separates the
large-momentum log coefficient; no complete scaleless integral is set zero.
Normalize the radial residue to1/(16pi^2epsilon), d=4-2epsilon.

Primary: obtain transverse/Feynman and longitudinal first-Taylor residues
directly from the open-line numerator and d-dimensional angular moments,
retaining barred rank4. Contract the actual plane-color W with all45
generators in order; determine left and conjugate-right16x16 kinetic tensors.
Check the width-free transverse part before combining. Physical q_hat can
appear in denominators but no hat gamma exists at the two vertices/pp
numerator; assess its derivative pole separately from FKP's scalar hat pole.

Replay: use a longitudinal2x2 block inverse, shifted Feynman parameters for
the longitudinal loop and the k->p-k first moment for its Feynman part.
Use the independently supplied SM generators/species charges to reconstruct
the unbroken Casimir from SU3,SU2 and normalized hypercharge, and the full
carrier Casimir from index/dimension, then subtract to get the broken sum.
Keep a split-Clifford routing witness; do not read primary outputs.

Gate: all50625 physical reference slots, both inverse orders, all2025 color
projector slots, actual16x16 ordered tensors and full family identity lift.
Verify the six SM species and their multiplicities, 12H covariance and generic
failure of full45 homogeneity when widths differ. Uniform width must reproduce
the standard Casimir result; it is a diagnostic, not an adopted gauge. Controls
reject width averaging/exchange, a raw-frame substitution, dropped longitudinal
term, an extra half/family factor and premature finite-reference equivalence.
No source-free full Ward identity is inferred from a two-point pole.

Comparator: Belusca-Maito et al.,arXiv2004.14398v2 Sec5.2.1 Eq5.10 and9,
https://arxiv.org/pdf/2004.14398 . Only the uniform-width form is a standard
anchor. The actual two-width model tensor and signs must be derived here.
The shared action, regulator/reference, QFT power counting, data, Python/SymPy
and AI author remain scientific limitations, not independent external proof.

Possible outcomes: qualified actual pole input; normalization/frame/routing
mismatch preserved; or resource/domain incomplete. No finite counterterm,
gauge-Yukawa/source vertex, full evanescent restoration, determinant phase,
measure/QAP, physical mass spectrum or full R' forest is claimed.
Freeze seven sources/copies/inputs before sequential primary/replay/gate with
peer denial.600s after imports each,8GiB sampled private cap,350MiB launch
floor,16MiB package. No agents. Failures remain, corrections versioned.
One new one-loop UV pole family,0two-loop integrals. No state/scientific
authority change, foundational adoption, flavor work, publication or external
action; E5/A5/finite matter C1/physical unification remain unqualified.
