"""GFK1 full-frame reference, pole and model-specific color comparison."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
for key in ['H_color_projector','full_internal_Casimir','unbroken_internal_Casimir','gauge_kinetic_left','gauge_kinetic_right','universal_inverse']:zero(dec(P[key])-dec(R[key]))
PH=dec(P['H_color_projector']);zero(PH-PH.T);zero(PH*PH-PH);assert s.trace(PH)==12
fg=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz');zero(PH-dec(fg['vector_projectors'][0]))
C=dec(P['full_internal_Casimir']);CH=dec(P['unbroken_internal_Casimir']);CW=dec(P['gauge_kinetic_left']);zero(C-s.Rational(45,8)*s.eye(16))
wh,wm=s.symbols('eta_H xi');zero(CW-wh*CH-wm*(C-CH));zero(CW-CW.H.xreplace({s.conjugate(wh):wh,s.conjugate(wm):wm}));zero(dec(P['gauge_kinetic_right'])-CW.T)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');sm=list(map(dec,Y['SM_generators']));Ts=list(map(dec,Y['Tminus']))
for g in sm:zero(CH*g-g*CH)
bad=sum(bool(s.SparseMatrix(CH*t-t*CH).applyfunc(s.simplify).todok()) for t in Ts);assert bad>0
zero(CW.subs(wm,wh)-wh*C);assert CW!=((12*wh+33*wm)/45)*C and CW!=CW.xreplace({wh:wm,wm:wh})
assert CW!=CW/2 and CW!=3*CW
expected={'Q':('21/10',6),'uc':('8/5',3),'dc':('7/5',3),'L':('9/10',2),'ec':('3/5',1),'N':('0',1)}
for name,(val,count) in expected.items():
 rows=[v for v in R['SM_species'] if v['species']==name];assert len(rows)==count and {r['C_H'] for r in rows}=={val}
for d in [P,R]:assert d['Feynman_residue']==d['longitudinal_residue']=='-1' and not d['open_line_extra_half'] and d['hat_fermion_derivative_pole']=='0' and d['new_one_loop_UV_pole_families']==1 and d['new_two_loop_integrals']==0 and not d['numerical_flavor_or_physical_scheme_adopted']
dim=s.Symbol('d');assert s.simplify(s.sympify(P['angular_Feynman_longitudinal'][0][1])-s.sympify(R['longitudinal_pole_route']))!=0
q=s.Matrix(s.symbols('q0:4'));Q=(q.T*q)[0];w=s.Symbol('w');G=dec(P['universal_inverse']);K=(Q*s.eye(4)-q*q.T).row_join(q).col_join((-q.T).row_join(s.Matrix([[w]])))
zero(K*G-s.eye(5));zero(G*K-s.eye(5));assert not G.has(1/w)
omitted=G.copy();omitted[:4,:4]=s.eye(4)/Q;assert s.SparseMatrix(K*omitted-s.eye(5)).applyfunc(s.simplify).todok()
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_ACTUAL_TWO_WIDTH_FERMION_GAUGE_KINETIC_POLE','elapsed_after_imports':time.perf_counter()-start,
 'physical_reference_slots_checked':P['full_reference_slots_checked'],'color_projector_positions_compared':2025,'internal_pole_positions_compared':2*16**2,'family_lift':'I3 tensor C_width',
 'full_Casimir':'45/8','unbroken_species_Casimirs':{k:v[0] for k,v in expected.items()},'width_dictionary':{'unbroken12':'eta_H','broken33':'xi'},
 'C_width':'eta_H*C_H+xi*(45/8*I16-C_H)','inverse_propagator_loop_pole':'+i*g10^2*bar_slash*(PL*C_width+PR*C_width^T)/(16*pi^2*epsilon)',
 'hat_fermion_derivative_pole':'0','uniform_width_limit_checked':True,'H_covariance_generators_checked':12,'full45_noncommuting_generators_at_distinct_widths':bad,
 'mixed_auxiliary_fields_eliminated':False,'reference_width_values_selected':False,'extra_open_line_half_or_family_factor_rejected':True,'raw_frame_substitution_rejected':P['raw_frame_substitution_rejected'],
 'new_one_loop_UV_pole_families':1,'new_two_loop_integrals':0,'finite_reference_equivalence_claimed':False,'gauge_Yukawa_source_vertices_or_full_forest_qualified':False,
 'finite_scheme_measure_phase_or_QAP_qualified':False,'numerical_flavor_or_physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
