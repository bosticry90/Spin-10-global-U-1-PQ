"""GFK1 actual225 reference recovery and direct angular current loop."""
from data import *
from itertools import product
start=begin('primary')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
full=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];raw=dec(full['reference_Hessian_raw_C3']);chart=dec(full['physical_to_raw_inverse'])
ids=list(range(180))+list(range(508,553));cols=chart[:,ids];KM=s.SparseMatrix(cols.T*raw*cols).applyfunc(s.simplify)
p=s.Matrix(s.symbols('p0_ref0:4'));eta=[1,-1,-1,-1];u=s.Matrix([eta[i]*p[i] for i in range(4)]);P=sum(p[i]*u[i] for i in range(4));wh,wm=s.symbols('eta_H xi')
target=s.SparseMatrix(225,225,{})
for a in range(45):
 for mu,nu in product(range(4),repeat=2):target[4*a+mu,4*a+nu]=-P*eta[mu]*int(mu==nu)+u[mu]*u[nu]
 for mu in range(4):target[4*a+mu,180+a]=s.I*u[mu];target[180+a,4*a+mu]=-s.I*u[mu]
 target[180+a,180+a]=wh if a<12 else wm
zero(KM-target);assert s.SparseMatrix(raw.extract(ids,ids)-target).todok()
q=s.Matrix(s.symbols('q0:4'));Q=(q.T*q)[0];w=s.Symbol('w');K=(Q*s.eye(4)-q*q.T).row_join(q).col_join((-q.T).row_join(s.Matrix([[w]])))
G=(s.eye(4)/Q+(w-1)*q*q.T/Q**2).row_join(-q/Q).col_join((q.T/Q).row_join(s.zeros(1)))
zero(K*G-s.eye(5));zero(G*K-s.eye(5))
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gs=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
ks=s.symbols('k0:4');slash=sum((k*g for k,g in zip(ks,gs)),s.zeros(4));kb2=sum(k*k for k in ks);dim=s.Symbol('d')
def avg(z):
 out=0
 for powers,coef in s.Poly(s.expand(z),*ks).terms():
  if any(i%2 for i in powers):continue
  n=sum(powers)//2;den=s.prod(dim+2*j for j in range(n));num=s.prod(s.factorial2(i-1) for i in powers)
  out+=coef*num/den
 return s.factor(out)
factors=[]
for nu,gp in enumerate(gs):
 nf0=-sum((g*slash*g for g in gs),s.zeros(4));nf1=sum((g*gp*g for g in gs),s.zeros(4))
 F=(nf1+2*ks[nu]*nf0).applyfunc(avg)
 L=(slash*gp*slash-2*ks[nu]*kb2*slash).applyfunc(avg)
 f=s.factor(s.trace(gp*F)/4);ell=s.factor(s.trace(gp*L)/4);zero(F-f*gp);zero(L-ell*gp);factors.append([str(f),str(ell)])
assert len(set(map(tuple,factors)))==1
fr=s.simplify(f.subs(dim,4));lr=s.simplify(ell.subs(dim,4));phase=-(-s.I)**2*(-s.I);assert phase==-s.I
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');Ts=list(map(dec,d['Tminus']));H=dec(d['H_new']);PH=s.SparseMatrix(H*H.T).applyfunc(s.simplify);W=wm*s.eye(45)+(wh-wm)*PH
allc=sum((t*t for t in Ts),s.zeros(16));ch=sum((z*Ts[a]*Ts[b] for (a,b),z in PH.todok().items()),s.zeros(16));cw=sum((z*Ts[a]*Ts[b] for (a,b),z in W.todok().items()),s.zeros(16))
right=sum((z*Ts[a].T*Ts[b].T for (a,b),z in W.todok().items()),s.zeros(16));pole=(-fr*allc-lr*(cw-allc)).applyfunc(s.simplify)
finish('primary',{'method':'actual_full_reference_congruence_and_barred_current_angular_residue','physical_reference_Hessian':enc(KM),'H_color_projector':enc(PH),
 'full_internal_Casimir':enc(allc),'unbroken_internal_Casimir':enc(ch),'gauge_kinetic_left':enc(pole),'gauge_kinetic_right':enc(right),'universal_inverse':enc(G),
 'angular_Feynman_longitudinal':factors,'Feynman_residue':str(fr),'longitudinal_residue':str(lr),'loop_phase_before_spin_residue':str(phase),
 'open_line_extra_half':False,'hat_fermion_derivative_pole':'0','raw_frame_substitution_rejected':True,'full_reference_slots_checked':225**2,
 'new_one_loop_UV_pole_families':1,'new_two_loop_integrals':0,'numerical_flavor_or_physical_scheme_adopted':False},start)
