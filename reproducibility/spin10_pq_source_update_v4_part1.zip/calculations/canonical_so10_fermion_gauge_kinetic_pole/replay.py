"""GFK1 longitudinal elimination, shifted moment and independent SM Casimirs."""
from data import *
start=begin('replay')
Q,w=s.symbols('Q w',nonzero=True);L=s.Matrix([[0,s.sqrt(Q)],[-s.sqrt(Q),w]]).inv();q=s.Matrix(s.symbols('q0:4'));qq=(q.T*q)[0]
BB=(s.eye(4)-q*q.T/qq)/qq+(q*q.T/qq)*L[0,0].subs(Q,qq)
G=BB.row_join(q/s.sqrt(qq)*L[0,1].subs(Q,qq)).col_join((q.T/s.sqrt(qq)*L[1,0].subs(Q,qq)).row_join(s.Matrix([[L[1,1]]])))
G=G.applyfunc(s.simplify)
x,dim=s.symbols('x d');f=s.integrate(-2*x,(x,0,1));ell=s.integrate(2*x*(6*x-8)/dim,(x,0,1))
# Shift k=l+(1-x)p: the longitudinal numerator linear in p has
# coefficient [2x-(x+2(1-x))*4]/d=(6x-8)/d times l^2 bar_slash(p).
assert s.simplify(2*x-4*(x+2*(1-x))-(6*x-8))==0
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];gs=[s.kronecker_product(g,pa[2]) for g in g4]
PL=s.kronecker_product(s.diag(1,1,0,0),s.eye(2));PR=s.eye(8)-PL
for g in gs:
 assert sum((h*g*h for h in gs),s.zeros(8))==-2*g
 for A in [PL,PR]:assert A*g==g*(s.eye(8)-A)
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');Ts=list(map(dec,d['Tminus']));sm=list(map(dec,d['SM_generators']));H=dec(d['H_new']);PH=(H*H.T).applyfunc(s.simplify)
norm=s.simplify(sum(s.conjugate(z)*z for t in Ts for z in t.todok().values())/16)
types={'Q':(s.Rational(4,3),s.Rational(3,4)),'uc':(s.Rational(4,3),0),'dc':(s.Rational(4,3),0),'L':(0,s.Rational(3,4)),'ec':(0,0),'N':(0,0)}
vals=[];species=[]
for row in d['SM_states']:
 c3,c2=types[row['species']];y=s.sympify(row['Y']);v=s.simplify(c3+c2+s.Rational(3,5)*y*y);vals.append(v);species.append({'species':row['species'],'Y':str(y),'C_H':str(v)})
CH=s.diag(*vals);directSM=sum((g*g for g in sm),s.zeros(16));assert not s.SparseMatrix(CH-directSM).applyfunc(s.simplify).todok()
wh,wm=s.symbols('eta_H xi');cw=wh*CH+wm*(norm*s.eye(16)-CH)
finish('replay',{'method':'longitudinal_block_elimination_shifted_Feynman_parameter_and_SM_species','H_color_projector':enc(PH),'full_internal_Casimir':enc(norm*s.eye(16)),
 'unbroken_internal_Casimir':enc(CH),'gauge_kinetic_left':enc(cw),'gauge_kinetic_right':enc(cw.T),'universal_inverse':enc(G),
 'Feynman_pole_route':str(f),'longitudinal_pole_route':str(ell),'Feynman_residue':str(f),'longitudinal_residue':str(ell.subs(dim,4)),
 'SM_species':species,'open_line_extra_half':False,'hat_fermion_derivative_pole':'0','new_one_loop_UV_pole_families':1,'new_two_loop_integrals':0,'numerical_flavor_or_physical_scheme_adopted':False},start)
