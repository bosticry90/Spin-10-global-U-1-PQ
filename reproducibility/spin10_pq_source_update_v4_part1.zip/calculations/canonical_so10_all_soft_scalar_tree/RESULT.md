# ASE1: scalar all-soft contact/exchange/bridge reproduces the relaxed EFT

Qualified receipt SHA256
2fc51822ce0a10dcc8c11216bd5ca22ebb6410261d976e490ffb60bfa3b64aa7.
Scientific/director acceptance NOT_PERFORMED;state113/authority34of39 unchanged.
This is the complete specified five-scalar TREE/soft-bridge correspondence,
not the entire quantum soft subtraction, finite C1, E5/A5 or physical matching.

For Gaussian covariance Z=u PH+v Pa on4 Higgs+1PQ real directions, the actual
parent quartic and scalar heavy elimination give
 F_eff=F_parent-A/4-B/8.
A contracts the two crossed light pairings of the heavy cubic exchange; B
contracts the two tadpole leaves through the physical-heavy inverse. B is
the BOTH-SOFT heavy-EOM bridge, distinct from the both-hard HTB contribution
and the mixed hard/soft OSF leaf. No new loop integral was evaluated.

In the coefficient order(u²,uv,v²), the measured values are approximately:
 F_parent=(1.19071410436664,0.000995900169311,0.75),
 A/4=(0.191157930494645,0.585751497390216,0.5),
 B/8=(0.370406716294478,-0.584755597220905,0.25),
 F_eff=(0.629149457577521372,0,0).
The large mixed terms cancel only when both pairings and their signs remain.
The underlying60-digit coefficients/residuals are preserved, not rounded to
these displayed zeros. The analytic H/PQ chart/Ward premises predict the two
zero coefficients; native agreement corroborates them within this domain.

The resulting lambda_E=F_eff,u²/6 is
 0.104858242929586895327769116224755516675152416086990578254151.
It lies in the earlier independent exact-direction enclosure. This is a
reproduction/reconciliation from the complete SSSS/SSS source data and all
five light directions, not a new physical Higgs measurement or benchmark.

Primary sums all23 two-soft/one-physical-heavy spectral rows, including
charge-zero entries, with the required class_orbit/3 factor and actual masses.
Replay contracts complete class Grams against a direct physical pseudoinverse
and both exact light projectors, without spectral weights or finite SSS units.
Both retain the full source phases and all physical-heavy directions. The
Goldstone two-soft exclusions use the qualified exact stationary Ward source
identity, never an eigenvalue or weight threshold. No row was clipped.

The both-soft trace source is obtained independently from HTB's fixed-parameter
radial Hessians and S3L's literal cubic on its complexified light basis. Their
raw covectors and three-radius Hessian agree EXACTLY. The bilinear Gaussian
covariance(X^T X)^-1 and raw metric diag(60,3/5,3/5) are essential; using the
Hermitian metric changes9 coordinate positions. Only the actual three physical
neutral singlets can carry the traced source by the inherited H/orbit census.

Maximum native scaled discrepancy6.22418e-66 passes the frozen1e-45 gate.
Mixed/PQ scaled residuals are3.51835e-67 and serialized0.0, below1e-40;
these are not rigorous uncertainty intervals or new exact transcendental
identities. S3M's stored65-digit spectral data limit the numerical claim.

The independently measured LRS1 POTENTIAL regulator coefficients are
 alpha0_H=1.191212054451298865, alpha0_PQ=3.001991800338621264.
The actual induced exchange shifts them by
 (0.562062596873777493,3.001991800338621264),
leaving(6lambda_E,0), as the relaxed scalar EFT requires. Their raw comparison
error is7.29966e-61 scaled. The exchange was calculated before comparing with
LRS1, not assigned its cancellation value. This accounts for the coupling-
independent potential part; the separate g10² regulator/kinetic/gauge part
and the full regulated one/two-soft matching remain unresolved.

Controls omit the both-soft bridge, crossed exchange, half exchange or class
orbit normalization and produce nonzero differences. Deleting charge-zero
rows loses A_PQ²=2, even though those rows needed no F² master in S3A. A
non-diagonal heavy/two-light polynomial with literal Gaussian Wick recursion
independently fixes2A+B and the factor1/8. These controls do not replace the
actual source comparisons or the tree-EOM/Ward proof.

Native6.9777315s/replay22.8716958s/validation1.4181782s after imports;
sampled private maxima62705664/75415552/49659904bytes, not continuous peaks.
4678 initial bindings,600s each/8GiB sampled/350MiB launch/24MiB package.
All3 workers COMPLETED with no failed preparation/science/verifier, timeout,
cancel or output truncation. Explicit manifest-type inventories avoid the
preserved controller mistakes from the preceding increment. Reports UTF8/LF;
historical sources and failures remain unchanged.

The methods share action/point/cubic/quartic/frame/spectrum/radial/EFT premises,
symbolic/numerical software and AI authorship. This is internal corroboration,
not outside scientific, experimental or Lean confirmation. TrackB demonstrates
collective matching and a distinct source/covariance representation, without
another benchmark framework; education remains voluntary/nonblocking.

Next: prove the required dimension-four light gauge/ghost/gauge-fixing
correspondence for the ACTUAL ordinary linear BFT1 gauge. Then apply the
common one-soft matching identity with the LRS regulator and kinetic terms
and actual induced scalar interaction. The literature's ordinary-BF gauge
caveat remains; no partial fixing or quartic ghosts are imported. Original
forests, finite physical jets, dimensional terms, overall subtraction,
nonlinear conversion and general gauge/basis/degenerate-limit gates remain.
