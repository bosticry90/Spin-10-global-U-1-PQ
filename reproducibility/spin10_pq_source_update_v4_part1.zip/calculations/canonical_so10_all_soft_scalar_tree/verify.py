"""ASE1 independent target, regulator map, toy Wick and omission checks."""
from data import *
start=begin('validation_preparation.json');mp.mp.dps=110
a=packed(HERE/'primary_tables.json.gz');b=packed(HERE/'replay_tables.json.gz');err=mp.mpf(0)
for key in ['parent_gaussian','crossed_A','trace_B','induced_exchange_gaussian','effective_gaussian']:
    for x,y in zip(a[key],b[key]):
        x,y=q(x),q(y);e=abs(x-y)/(1+abs(x)+abs(y));err=max(err,e);assert e<mp.mpf('1e-45'),(key,mp.nstr(e,20))
for key in ['raw_source_H','raw_source_PQ','raw_M']:zero(dec(a['trace_source'][key])-dec(b['trace_source'][key]))
root=point_root();scale=1+sum(abs(q(v)) for key in ['parent_gaussian','crossed_A','trace_B'] for v in a[key])
zeros=[abs(q(z))/scale for z in a['effective_gaussian'][1:]];assert max(zeros)<mp.mpf('1e-40')
old=json.loads((CAL/'canonical_so10_higgs_leading_soft_reduction/original_result.json').read_bytes());lo,hi=map(q,old['exact_u_quartic_public_interval']);lam=q(a['lambda_from_all_light_source']);assert lo<lam<hi
lrs=json.loads((CAL/'canonical_so10_light_regulator_spurion/validation_receipt.json').read_bytes())
parent=list(map(q,a['parent_gaussian']));induced=list(map(q,a['induced_exchange_gaussian']));eff=list(map(q,a['effective_gaussian']))
raw=[parent[0]+parent[1]/2,2*parent[1]+4*parent[2]];shift=[induced[0]+induced[1]/2,2*induced[1]+4*induced[2]];reduced=[eff[0]+eff[1]/2,2*eff[1]+4*eff[2]]
resid=mp.mpf(0)
for value,key in zip(raw,['scalar_quartic_spurion_H','scalar_quartic_spurion_PQ']):
    want=nv(s.sympify(lrs[key],locals={'w':w}),root);e=abs(value-want)/(1+abs(want));resid=max(resid,e);assert e<mp.mpf('1e-45')
assert abs(reduced[0]-6*lam)/scale<mp.mpf('1e-40') and abs(reduced[1])/scale<mp.mpf('1e-40')
# Literal Gaussian Wick recursion and completing a non-diagonal heavy square.
u,v,z=s.symbols('u v z',real=True);Z=s.Matrix([[u,z],[z,v]]);M=s.Matrix([[3,1],[1,4]]);T=[s.Matrix([[2,1],[1,3]]),s.Matrix([[1,-2],[-2,4]])];x,y=s.symbols('x y');l=s.Matrix([x,y]);j=s.Matrix([(l.T*P*l)[0] for P in T]);literal=s.expand(-(j.T*M.inv()*j)[0]/8)
mom={(4,0):3*u*u,(3,1):3*u*z,(2,2):u*v+2*z*z,(1,3):3*v*z,(0,4):3*v*v}
wick=s.expand(sum(c*mom[p] for p,c in s.Poly(literal,x,y).terms()))
A=sum(M.inv()[i,j]*s.trace(T[i]*Z*T[j]*Z) for i in range(2) for j in range(2));B=sum(M.inv()[i,j]*s.trace(T[i]*Z)*s.trace(T[j]*Z) for i in range(2) for j in range(2));assert s.expand(wick+A/4+B/8)==0
controls={'omit_both_soft_bridge':list(map(lambda z:fmt(q(z)/8),a['trace_B'])),'omit_crossed_sunset_exchange':list(map(lambda z:fmt(q(z)/4),a['crossed_A'])),
 'half_heavy_exchange':list(map(lambda z:fmt(q(z)/2),a['induced_exchange_gaussian'])),'extra_class_orbit_factor3':list(map(lambda z:fmt(q(z)/2),a['crossed_A'])),
 'delete_charge_zero_rows':a['exchange_info']['source_charge_zero_part'],'wrong_Hermitian_light_covariance_nonzero':len(dec(b['trace_source']['wrong_Hermitian_covariance_difference']).todok())}
for key in ['omit_both_soft_bridge','omit_crossed_sunset_exchange','half_heavy_exchange','extra_class_orbit_factor3','delete_charge_zero_rows']:assert any(abs(q(v))>mp.mpf('1e-40') for v in controls[key]),key
receipt={'schema':'ASE1_VALIDATION','status':'QUALIFIED_COMPLETE_ALL_SOFT_SCALAR_TREE_EXCHANGE_AND_BOTH_SOFT_BRIDGE',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED','real_light_ranks':[4,1],
 'native_max_scaled_error':fmt(err),'mixed_PQ_zero_scaled_residuals':list(map(fmt,zeros)),
 'effective_gaussian':a['effective_gaussian'],'lambda_from_actual_source':a['lambda_from_all_light_source'],'old_lambda_interval':old['exact_u_quartic_public_interval'],
 'raw_potential_regulator_coefficients':list(map(fmt,raw)),'induced_potential_regulator_coefficients':list(map(fmt,shift)),
 'relaxed_potential_regulator_coefficients':list(map(fmt,reduced)),'LRS_independent_raw_comparison_max_scaled':fmt(resid),
 'all_two_soft_rows_retained':len(a['exchange_info']['rows']),'negative_controls':controls,
 'global_soft_gauge_matching_g2_spurion_or_full_C1_E5_A5_qualified':False,
 'shared_error_limits':['action/point/source/frame/spectrum/radial/EFT premises','symbolic_numeric_software','AI authorship'],
 'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
