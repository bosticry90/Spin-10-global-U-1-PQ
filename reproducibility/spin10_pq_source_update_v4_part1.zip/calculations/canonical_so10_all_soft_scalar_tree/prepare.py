"""ASE1 explicit typed parent manifests and immutable source freeze."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='eb02405e98f8cd917b58cde44b272f38d871fbe2'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/all-soft-scalar-tree-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
deps={};cache={};qualified={}
PARENTS=[('canonical_so10_scalar_cubic_spectral_measure', 'validation_receipt.json', 'QUALIFIED_COMPLETE_TRILINEAR_SCALAR_MASS_SPECTRAL_MEASURE', '197fa749a298407d3d6f981c563e8c31fbef681e9c61f31bbeb7a1c665fe10ee', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_scalar_cubic_class_gram', 'validation_receipt.json', 'QUALIFIED_COMPLETE_EXACT_TRILINEAR_CLASS_GRAM_OPERATORS', 'a6e841ec56023b68e0bc2fffc9503c5542c8f0656884d84aee8cc46a026e7497', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_scalar_cubic_light', 'validation_receipt.json', 'QUALIFIED_COMPLETE_ALL_LIGHT_CUBIC_AND_TWO_LIGHT_RADIAL_SUPPORT', '241dbd397f64d09f39f320b4657c60cfdd912fa20eda319b9d4d62a4233c6956', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_scalar_quartic_functional', 'validation_receipt.json', 'QUALIFIED_COMPLETE_PARENT_QUARTIC_GAUSSIAN_FUNCTIONAL', '397459477bc57d85834f11cbdf538f1b6177f20d8829d7c00ec0fa48d0d5176a', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_scalar_quartic_covariance', 'validation_receipt.json', 'QUALIFIED_COMPLETE_SCALAR_QUARTIC_COVARIANCE_TRANSPORT', 'e93c8e0639aa357b10a5e2a05ddc6b0aec6799d3bbc51e673faa13acff6155bf', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_finite_counterterm_insertion', 'validation_receipt_v5.json', 'QUALIFIED_PRESCRIBED_POLE_POSITIVE_HEAVY_CT_LAURENT_AND_FINITE_CONTRIBUTION', '8001162677d2281016e3fb7ef8da53b91dd788fa82feec673f38b91becd156d7', ['preparation.json', 'preparation_v2.json', 'preparation_v3.json', 'validation_preparation_v3.json', 'validation_preparation_v4.json', 'validation_preparation_v5.json'], {}), ('canonical_so10_heavy_tadpole_bridge', 'validation_receipt_v4.json', 'QUALIFIED_FIXED_REFERENCE_RADIAL_HEAVY_BRIDGE_FINITE_LOOP_AND_SYMBOLIC_TADPOLE_FAMILY', '3b77d2f5bd1d93ce5f0cc55b12a06e36ad00cf88d748e3ca284b9a6752b4fa00', ['preparation.json', 'preparation_v2.json', 'preparation_v3.json', 'validation_preparation_v3.json', 'validation_preparation_v4.json'], {}), ('canonical_so10_higgs_leading_soft_reduction', 'validation_receipt.json', 'COMPLETED_LEADING_LOCAL_BOSONIC_RECONSTRUCTION_ONLY', '96cb8b440126e7d3a0dd1628631e2eae589f1bc09809debfc8fecc19b540b8bf', ['preparation.json', 'validation_preparation.json'], {}), ('canonical_so10_one_soft_factorization', 'validation_receipt_v4.json', 'QUALIFIED_SPECIFIED_ONE_SOFT_CYCLE_FACTORIZATION_AND_CONDITIONAL_HIGGS_MASS_CANCELLATION', '3612bc3db506239b90101c5b8b511243c7e8e2aa5581de3f2b5ac24018e427fe', ['preparation.json', 'validation_preparation.json', 'validation_preparation_v2.json', 'validation_preparation_v3.json', 'validation_preparation_v4.json'], {}), ('canonical_so10_light_regulator_spurion', 'validation_receipt.json', 'QUALIFIED_COMPLETE_LINEAR_DELTA_LIGHT_UV_KERNEL_AND_EFT_RESIDUE_COMPARISON', '6706209b1c043d44106d68b3956daa5fb794d005be9102b4afe67620451c51fb', ['preparation.json', 'validation_preparation.json'], {'preparation_failure_v1.json': '54b03cc38d467349745f044eeace28e32a56def96f7e6a2b306a4657dd2f0bd7', 'preparation_tool_result_v1.json': 'a0ad89d1f62500700386579face289cdab0cd6e7a8ba0cfd567f619f380c3fa5'})]
for folder,receipt,want,wantsha,manifests,metadata in PARENTS:
    parent=ROOT/'calculations'/folder
    assert {v.name for v in parent.glob('*preparation*.json')}==set(manifests)|set(metadata)
    for name in manifests:
        record=json.loads((parent/name).read_bytes());bindings=record.get('input_sha256',record.get('byte_sha256'));assert isinstance(bindings,dict) and bindings
        for n,h in bindings.items():
            n=str((ROOT/Path(n)).resolve())
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for name,h in metadata.items():assert sha256((parent/name).read_bytes()).hexdigest()==h
    for f in sorted(parent.iterdir()):
        if f.is_file():deps[str(f)]=sha256(f.read_bytes()).hexdigest()
    f=parent/receipt;v=json.loads(f.read_bytes());assert v.get('status',v.get('disposition'))==want and sha256(f.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=wantsha
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V436.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:
    f=ROOT/name;deps[str(f)]=sha256(f.read_bytes()).hexdigest()
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    f=HERE/name;raw=f.read_bytes();assert b'\r' not in raw
    if f.suffix=='.py':ast.parse(raw,filename=str(f))
    cp=HERE/(name+'.source.txt');dump(cp,raw);deps[str(f)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==27872
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'ASE1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),'qualified_receipts':qualified,'old_blobs':27872,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':24*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;27872 oldblobs;no science executed',flush=True)
