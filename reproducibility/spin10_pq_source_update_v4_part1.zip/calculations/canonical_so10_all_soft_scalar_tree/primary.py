"""ASE1 complete spectral rows and fixed-reference radial vertices."""
from data import *
start=begin();mp.mp.dps=90;save('primary',calculate('primary'),start)
