"""ASE1 source Gram/resolvent and literal light-cubic coordinates."""
from data import *
start=begin();mp.mp.dps=110;save('replay',calculate('replay'),start)
