# ASE1 complete all-soft scalar tree/bridge correspondence

Question: do the actual SSSS contact, SSS two-soft heavy exchange and BOTH-
SOFT heavy-EOM bridge reproduce the already qualified relaxed five-scalar
EFT interaction in the common soft construction? This is a missing common
matching prerequisite, not a new physical scalar point or another two-loop
master. Reuse all qualified source tensors; no328^4 expansion or loop rerun.

Fields: exact scalar soft projector Ps=PH+Pa, real ranks4+1; physical-heavy
potential projector rank290 with H inverse; all33 gauge Goldstone directions
kept in the inventory but their two-soft cubic sources vanish by the qualified
stationary Ward identity. No mass-magnitude cutoff. Keep all class multiplicity
phases, norms and tiny recorded spectral residuals; no numeric clipping.

V3=T_ijk eta_i eta_j eta_k/6 and V4=lambda_ijkl eta_i eta_j eta_k eta_l/24.
At zero momentum tree heavy elimination gives
 Veff4=V4-(T_HLL[l,l])^T Hheavy^-1 T_HLL[l,l]/8.
For covariance Z=u PH+v Pa, define
 A(Z)=T_alpha,ij T_beta,kl Hplus_alpha,beta Z_ik Z_jl,
 B(Z)=Tr(Z T_alpha) Hplus_alpha,beta Tr(Z T_beta).
Then the complete Gaussian quartic is F_eff(Z)=F_parent(Z)-A(Z)/4-B(Z)/8.
The cross pairing A corresponds to the heavy-line all-soft sunset exchange;
B is the both-soft tadpole bridge. Neither is the both-hard HTB result or
OSF1's mixed hard/soft bridge. Derive the factors from independent Wick and
heavy-square routes before comparing coefficients. Keep all three u²,uv,v².

Primary obtains A from ALL S3M rows with exactly two soft and one physical
heavy index, including charge-zero rows, with class_orbit/3 and inverse mass.
Replay contracts the full S3G class Gram against Hplus and the exact soft
projectors, summing all three heavy-axis placements with class_orbit/3.
No finite SSS kernel or gauge target enters either native. Primary obtains
B from HTB's actual fixed-parameter radial Hessian vertices/Mraw; replay
from S3L's literal cubic restriction on a complete NONORTHONORMAL complexified
light basis and three real unit radial directions, with the correct bilinear
Gaussian coordinate covariance and raw-radius metric. Do not replace X^T X
by X^dagger X. Only the3 physical neutral singlets can carry a traced source;
the actual H/PQ/gauge Ward source census is an explicit inherited premise.

F_parent comes from the complete S4F functional/S4C covariance program at
the same actual point. Primary direct monomial contraction vs replay
polarization/gradient contraction. Their quadratic-polynomial coefficients
and A/B/F_eff must agree below1e-45 scaled; stored S3M65digits limit the
comparison. Native working90/110digits, report60. Exact radial-source and
covariance/reality/projector identities must agree with no tolerance.
The analytic PQ/H-invariance premise predicts F_eff=[6lambda_E,0,0].
Check the two zero coefficients below1e-40 scaled and the independent old
lambda_E enclosure; a decimal zero is not exact arithmetic or a new Ward
proof. Retain actual residuals. No native reads that old numerical target.

Post-native verification also compares parent/induced tadpole maps with
the actual LRS1 scalar regulator residue: alpha_H=F_uu+F_uv/2 and
alpha_PQ=2F_uv+4F_vv. The induced exchange must account for the difference
between the raw parent and the relaxed EFT quartic spurion; do not define
exchange from the difference needed to cancel it. This establishes only
the coupling-independent potential piece, not LRS1's g10² mismatch.

Controls omit B, omit A, halve heavy exchange, misuse class orbit or covariance
metric, and omit charge-zero channels where sensitive. Ward-excluded Gold
and all-light cubic sources stay structurally classified, not dropped by a
floating threshold. A symmetric positive-mass multivariate toy proves Wick
and heavy-EOM coefficients independently; it is not a Spin10 amplitude.

Freeze inputs/sources first. Sequential600s natives and600s validation,
8GiB sampled private/350MiB launch/24MiB package. Failures/timeouts remain
preserved and incomplete; no fitted coefficient, truncated table, relaxed
gate, physical-scheme/point change or authority promotion. State113/34of39,
9/9 INPUTS, director/scientific acceptance NOT_PERFORMED stay.

Ceiling: the specified all-soft scalar tree/bridge matching and potential
regulator-spurion reconciliation, with existing finite-region/UV/EFT premises
explicit. This does not establish the entire ordinary-BF-gauge soft matching,
gauge/regulator kinetic sector, full C1 or E5/A5. The literature's gauge caveat
is retained; no partially fixed gauge or quartic ghosts are imported. Shared
action/point/cubic/quartic/frame/physical spectrum/old EFT/UV software and AI
authorship limit independent assurance. TrackB tests structural common matching
and distinct source representations, not a new benchmark; education voluntary.
