"""ASE1 actual scalar contact, spectral/Gram exchange and both-soft bridge."""
from pathlib import Path
from hashlib import sha256
from math import prod
import json,gzip,sys,time,os,threading,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,dec,enc,w,coeffs,point_root,number,numeric,real,inflate

def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep='preparation.json'):
    start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def q(v):
    a,sep,b=str(v).partition('/');return mp.mpf(a)/mp.mpf(b) if sep else mp.mpf(a)
def fmt(v):return mp.nstr(real(v),60)
def nv(v,root):return real(number(v,root))
def sector(label):
    a,b,l,q=map(int,label)
    if (a,b,l)==(0,0,1) and abs(q)==3:return 'H'
    assert (a,b,l,q)==(0,0,0,0);return 'a'

def inputs(role):
    frame=packed(CAL/'canonical_so10_scalar_sm_frame'/f'{role}_tables.json.gz')
    fci=packed(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_tables.json.gz')
    PH=[];PA=[]
    for b,src in zip(frame['blocks'],fci['blocks']):
        P=dec(src['soft']);Z=s.zeros(P.rows)
        if not P.todok():PH.append(Z);PA.append(Z);continue
        label=sector(b['label']);PH.append(P if label=='H' else Z);PA.append(P if label=='a' else Z)
    assert sum(b['dimension']*int(red(s.trace(P))) for b,P in zip(frame['blocks'],PH))==4
    assert sum(b['dimension']*int(red(s.trace(P))) for b,P in zip(frame['blocks'],PA))==1
    return frame,fci,PH,PA

def parent_polynomial(role,frame,PH,PA,root):
    cov=packed(CAL/'canonical_so10_scalar_quartic_covariance'/f'{role}_tables.json.gz')
    func=packed(CAL/'canonical_so10_scalar_quartic_functional'/f'{role}_tables.json.gz')
    sys.path.insert(0,str(CAL/'canonical_so10_scalar_quartic_functional'))
    F=module('ase_quartic_source',CAL/'canonical_so10_scalar_quartic_functional/data.py')
    pol=F.physical_poly(func['kernels']);cc=coeffs()[1];parts={}
    def values(P):
        slots=[P[v['block']][v['i'],v['j']] for v in cov['slot_definitions']]
        return [number(red(sum(s.sympify(c)*slots[k] for k,c in row)),root) for row in cov['program']['forms']]
    hh,aa=values(PH),values(PA)
    for name,rows in pol.items():
        n,_,part=name.partition(':');c=s.im(cc[n]) if part=='im' else s.re(cc[n]);rows=[(i,j,number(c*z,root)) for i,j,z in rows]
        if role=='primary':p=[mp.fsum(z*hh[i]*hh[j] for i,j,z in rows),mp.fsum(z*(hh[i]*aa[j]+aa[i]*hh[j]) for i,j,z in rows),mp.fsum(z*aa[i]*aa[j] for i,j,z in rows)]
        else:
            gh=[mp.mpc(0)]*356;ga=gh[:]
            for i,j,z in rows:gh[i]+=z*hh[j];gh[j]+=z*hh[i];ga[i]+=z*aa[j];ga[j]+=z*aa[i]
            p=[mp.fsum(x*y for x,y in zip(gh,hh))/2,mp.fsum(x*y for x,y in zip(gh,aa)),mp.fsum(x*y for x,y in zip(ga,aa))/2]
        parts[name]=[real(z) for z in p]
    return [mp.fsum(row[j] for row in parts.values()) for j in range(3)],{k:list(map(fmt,v)) for k,v in parts.items()}

def spectral_exchange(role,frame):
    measure=packed(CAL/'canonical_so10_scalar_cubic_spectral_measure'/f'{role}_tables.json.gz')
    masses={m['key']:q(m['reference_mass_squared']) for b in measure['blocks'] for m in b['modes'] if m['type']==0}
    out=[mp.mpf(0)]*3;chargezero=out[:];rows=[]
    for i,row in enumerate(measure['rows']):
        if row['types'].count(1)!=2 or row['types'].count(0)!=1:continue
        axis=row['types'].index(0);soft=[k for k in range(3) if k!=axis];pair=sorted(sector(frame['blocks'][row['classes'][k]]['label']) for k in soft)
        k=0 if pair==['H','H'] else 2 if pair==['a','a'] else 1
        value=q(row['class_orbit'])*q(row['weight'])/(3*masses[row['mass_keys'][axis]])
        out[k]+=value
        if row['classification']!='KERNEL_REQUIRED':chargezero[k]+=value
        rows.append({'index':i,'coefficient':k,'heavy_axis':axis,'weight':row['weight'],'contribution':fmt(value),'classification':row['classification']})
    assert rows
    return out,{'rows':rows,'source_charge_zero_part':list(map(fmt,chargezero)),'all_rows_retained_no_clipping':True}

def gram_exchange(role,frame,fci,PH,PA,root):
    M=module('ase_gram_tools',CAL/'canonical_so10_scalar_cubic_spectral_measure/data.py')
    grams=packed(CAL/'canonical_so10_scalar_cubic_class_gram'/f'{role}_tables.json.gz');Hplus=[]
    for src in fci['blocks']:
        H=numeric(dec(src['H']),root);P=numeric(dec(src['physical']),root);Hplus.append((H+mp.eye(H.rows)-P)**-1*P)
    ps=[[numeric(P,root) for P in PH],[numeric(P,root) for P in PA]];ps.append([x+y for x,y in zip(*ps)])
    values=[];counts=[]
    for pp in ps:
        total=mp.mpf(0);terms=0
        for g in grams['groups']:
            cls=g['classes'];entries=M.gram_entries(g)
            for axis in range(3):
                if not dec(fci['blocks'][cls[axis]]['physical']).todok():continue
                others=[k for k in range(3) if k!=axis]
                if any(not any(pp[cls[k]]) for k in others):continue
                operators=[pp[c] for c in cls];operators[axis]=Hplus[cls[axis]]
                total+=mp.mpf(M.orbit(cls))*M.gtrace(entries,operators)/3;terms+=1
        values.append(total);counts.append(terms)
    return [values[0],values[2]-values[0]-values[1],values[1]],{'class_axis_terms':counts,'direct_mass_pseudoinverse_used':True}

def field_inverse(A):
    n=A.rows;B=s.MutableSparseMatrix(A.row_join(s.eye(n)))
    for j in range(n):
        pivot=next(k for k in range(j,n) if red(B[k,j])!=0)
        if pivot!=j:B.row_swap(j,pivot)
        z=red(B[j,j])
        for k in range(2*n):B[j,k]=red(B[j,k]/z)
        for i in range(n):
            if i==j:continue
            z=red(B[i,j])
            if z:
                for k in range(2*n):B[i,k]=red(B[i,k]-z*B[j,k])
    out=tidy(B[:,n:]);zero(A*out-s.eye(n));return out

def trace_bridge(role,frame,fci,PH,PA,root):
    htb=packed(CAL/'canonical_so10_heavy_tadpole_bridge'/f'{role}_v3_tables.json.gz');mass=dec(htb['raw_Hessian']);inv=dec(htb['raw_Hessian_inverse']);zero(mass*inv-s.eye(3))
    if role=='primary':
        k=[]
        for P in [PH,PA]:k.append(s.Matrix([red(sum(b['dimension']*s.trace(p*dec(row['D'][j])) for b,p,row in zip(frame['blocks'],P,htb['radial_blocks']))) for j in range(3)]))
        metric_control=None
    else:
        light=packed(CAL/'canonical_so10_scalar_cubic_light'/f'{role}_tables.json.gz');X=dec(light['light_basis_canonical']);bilinear=tidy(X.T*X);cov=field_inverse(bilinear)
        Q,D=dec(frame['Q']),dec(frame['D']);Qi=s.diag(*[1/D[i,i] for i in range(328)])*Q.H;Z=tidy(Qi*X)
        hs=[i for i,v in enumerate(light['light_labels']) if sector(v['SM_label'])=='H'];aa=[i for i in range(5) if i not in hs]
        covs=[]
        for ids,P in [(hs,PH),(aa,PA)]:
            A=s.SparseMatrix(5,5,{(i,j):cov[i,j] for i in ids for j in ids});zero(Z*A*Z.T*(Q.T*Q)-inflate(frame['blocks'],P));covs.append(A)
        zero(sum(covs,s.zeros(5))-cov)
        k=[s.zeros(3,1),s.zeros(3,1)];norm=[s.sqrt(60),s.sqrt(s.Rational(3,5)),s.sqrt(s.Rational(3,5))]
        for j,name in enumerate(['Phi','Sigma','S']):
            B=s.zeros(5)
            for i,l,r,z in light['restrictions'][name]['polynomial']:
                if r!=5 or l==5:continue
                value=s.sympify(z,locals={'w':w});B[i,l]+=value*(2 if i==l else 1)
                if i!=l:B[l,i]+=value
            for a,C in enumerate(covs):k[a][j]=red(norm[j]*s.trace(B*C))
        metric_control=enc(tidy(cov-field_inverse(tidy(X.H*X))))
        assert dec(metric_control).todok()
    pol=[red((k[0].T*inv*k[0])[0]),red(2*(k[0].T*inv*k[1])[0]),red((k[1].T*inv*k[1])[0])]
    return [nv(z,root) for z in pol],{'raw_source_H':enc(k[0]),'raw_source_PQ':enc(k[1]),'raw_M':enc(mass),'exact_coefficients':list(map(str,pol)),'wrong_Hermitian_covariance_difference':metric_control}

def calculate(role):
    frame,fci,PH,PA=inputs(role);root=point_root();parent,pieces=parent_polynomial(role,frame,PH,PA,root)
    print('STAGE '+role+'_full_parent_quartic',flush=True)
    A,info=spectral_exchange(role,frame) if role=='primary' else gram_exchange(role,frame,fci,PH,PA,root)
    print('STAGE '+role+'_crossed_heavy_exchange',flush=True)
    B,trace=trace_bridge(role,frame,fci,PH,PA,root);correction=[a/4+b/8 for a,b in zip(A,B)];eff=[p-c for p,c in zip(parent,correction)]
    return {'schema':'ASE1_ALL_SOFT_SCALAR_TREE','axes':['u_H²','u_H*u_PQ','u_PQ²'],'real_light_ranks':[4,1],
      'parent_gaussian':list(map(fmt,parent)),'crossed_A':list(map(fmt,A)),'trace_B':list(map(fmt,B)),
      'induced_exchange_gaussian':list(map(fmt,correction)),'effective_gaussian':list(map(fmt,eff)),
      'lambda_from_all_light_source':fmt(eff[0]/6),'parent_pieces':pieces,'exchange_info':info,'trace_source':trace,
      'all_soft_gauge_or_global_matching_or_finite_C1_qualified':False}
