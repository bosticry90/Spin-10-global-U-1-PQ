# ASE1 scalar Gaussian tree/bridge identity

At zero light fields the vacuum Hessian is block diagonal in the qualified
light/heavy split. In the potential through quartic order write
 S=1/2 x^T Hheavy x+1/2 x_alpha T_alpha,ij l_i l_j+V4(l)+O(fields5).
Terms with additional heavy fields first affect the reduced potential above
quartic order, because x0=O(l²). The tree solution is
 x0=-Hheavy^-1 T[l,l]/2+O(l³).
Substitution or completing the heavy square gives Veff4=V4-T Hplus T/8.
For the actual potential two-soft sources along gauge/PQ orbit directions
vanish by H Ps=0 and the differentiated stationary Ward identity. The heavy
inverse in this scalar formula is the physical-potential inverse, not1/delta
or a gauge-orbit mass inverse. This uses the qualified S3L/Ward source census.

Wick's theorem for a real Gaussian with symmetric covariance Z gives
 <l_i l_j l_k l_l>=Z_ij Z_kl+Z_ik Z_jl+Z_il Z_jk.
The cubic tensor is symmetric in its light legs, so the three contractions
give2A+B. The induced quartic expectation is therefore-A/4-B/8.
In the two-loop reduced functional the two light-crossing contractions are
the soft part of the SSS sunset after Taylor expanding the heavy line;
the same-loop pairings are -t_soft^T Hplus t_soft/2 with
t_soft,alpha=Tr(Z T_alpha)/2, i.e.-B/8. The full1PI exclusion of dumbbells
does not remove this permitted heavy bridge in the reduced1LPI functional.
OSF1 already proved the distinct mixed hard/soft bridge; HTB measured the
distinct both-hard bridge. No bridge is substituted for another.

S3G's class Gram includes the FULL actual irrep/metric contraction.
S3M resolves it into ordered spectral modes. Summing every class orbit and
every possible heavy axis counts a fixed-heavy-first T_HLL norm three times.
Thus A=(1/3)sum_groups orbit*sum_heavyaxis Tr[G(Hplus tensor Z tensor Z)].
The same factor applies to the complete resolved rows with two soft modes.
This is not an additional3! or a quotient of equal soft modes. Charge-zero
rows can contribute to the scalar EFT and cannot be excluded because no
F² master was needed for them in S3A.

For the trace pairing, residual H invariance and the actual stationary orbit
Ward identities leave only three physical neutral singlet source directions.
In the raw fractional-radius basis E their Hessian is Mraw=E^T H E and
k_raw=E^T k. Therefore B=k_raw^T Mraw^-1 k_raw. HTB supplies one independently
qualified radial derivative representation. S3L supplies another from literal
cubic substitution on its five complexified light coordinates and normalized
real radial directions. If l=X z, the Gaussian BILINEAR coordinate covariance
is (X^T X)^-1 on that complete real carrier's complexification, not the inverse
Hermitian metric. X C X^T=Ps must be checked. The Higgs/PQ covariance pieces
are separated by the actual charge labels and reconstruct PH,Pa exactly.
For V3 restricted as r*Q(z), its radial two-light matrix is the Hessian of Q;
diagonal monomials require factor2 and off-diagonal ones factor1. Unit radial
derivatives are multiplied by sqrt(60),sqrt(3/5),sqrt(3/5) for raw fractional
radii. The same metric must be retained in the inverse Hessian.

An invariant leading potential on one realified Higgs doublet and a local
adapted PQ phase is lambda_E(H^T H)^2/4, with no leading PQ potential. The
qualified local phase/chart and tree-EOM argument are required, rather than
assumed arbitrary global field equivalence. Its Gaussian expectation is
6lambda_E u² for Z=u PH+v Pa. For a general F=f_uu u²+f_uv uv+f_vv v²,
Tr[S(Ps)PH]=2 D F(Ps)[PH]=4f_uu+2f_uv, hence the rank4 Higgs mass coefficient
is f_uu+f_uv/2. The rank1 PQ coefficient is2f_uv+4f_vv. These are the relations
used to compare the independently calculated tree-exchange correction with
LRS1's measured potential regulator poles. They do not determine an unknown
loop coefficient by demanding a cancellation.

This tests one genuine all-soft tree correspondence. A global matching
formula still requires the SAME full/EFT gauge fixing, original light forests,
mass/kinetic/regulator matching and all two-soft overlap terms. The original
ordinary BF gauge is retained. Fuentes-Martin et al2412.12270v2 sections4.1/4.2
(https://arxiv.org/html/2412.12270v2#S4.SS1) derive a general hard-region formula
subject to gauge matching hypotheses. Thomsen2404.11640v2 section4.3
(https://arxiv.org/html/2404.11640v2#S4.SS3) explains the ordinary broken-BF
gauge difficulty. These are primary mathematical comparators, not certificates
for the actual BFT1 linear gauge or a reason to adopt a different action.
