# CBR1 V2 preparation correction, no science executed

The original prepare.py FAILED on the historical LRS1 preserved records
preparation_failure_v1.json and preparation_tool_result_v1.json: their names
match a broad glob but they are not binding manifests. Original source and
the complete delivered terminal output remain in preflight records. No
scientific worker, freeze manifest or result was produced.

V2 explicitly classifies those two exact historical names as non-manifest
records, authenticates them among all parent folder files, and still checks
every actual binding manifest. Unknown non-manifest schemas still fail. No
input is omitted, rebound or substituted; no scientific condition changes.
The explicit manifest-type inventory avoids treating preserved failures as
executable preparations. This repeats an existing orchestration weakness.

Prelaunch mathematical review also clarifies the prospective derivation:
all-light HH/HS regions have no hard mass scale, but a parent scalar quartic
graph is not individually equal to an EFT relaxed-quartic graph. The latter
uses the measured exchange plus both-soft bridge as a group. The native
classification strings PURE_LIGHT_COMMON_HH/HS name their common subtraction
domain, not a per-graph coefficient equality. No completed science changed.
An ad hoc file patch was rejected before writing because its proposed line
was absent; the actual prospective wording was then corrected.
