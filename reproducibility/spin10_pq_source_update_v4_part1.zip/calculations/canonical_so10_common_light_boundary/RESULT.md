# CBR1: the projected common light boundary now composes

Qualified bounded reduction and forest transport, within the existing
source-zero,xi1,fixed-v,H-background,Euclidean dimensional/MSbar local-F2
reference family at fixed heavy gap. Scientific/director acceptance is NOT
PERFORMED. Main validation_receipt_v2.json SHA256
c4358eb1d5f1f952ae1bdd2ac10f7219094d453c4ae3fd149996b26e2997df90.
State113/authority34of39 unchanged. Full finite C1,E5/A5,quantum equivalence
and physical unification remain unqualified.

## What has changed

The existing results now support a common soft-region reduction, rather than
only separate primitive subtractions. The proof composes actual tree gauge/
FP correspondence, relaxed scalar exchange, cycle-opening weights, the
original one-soft kernels, internal-delta/two-soft overlap and reduced
tadpole terms. No finite normalization is selected to obtain cancellation.
No new huge Higgs self-energy, two-loop master or model tensor was calculated.

The significant assembly consequence is

    sum matched primitives
      +(Cparent_full-sum Cfamily_full)
      +(sum Cfamily_soft-Cparent_soft)
    =sum matched primitives+Cparent_hard-sum Cfamily_hard.

Here parent/family counterterms are RAW1PI closures. Hard/soft labels the
REMAINING loop's momentum region, never the masses inside its UV subgraph.
In particular a heavy remaining loop still receives light-internal UV poles.
The additional soft transport cannot be omitted unless separately shown to
vanish. The older graph-local full-forest identity remains correct; it did
not alone establish the complete EFT subtraction. Existing primitive values,
pole checks and historical receipts have not been changed.

The actual tadpole-renormalized HTB term is retained separately ONCE. It
already contains its hard tadpole CT. Putting that same CT into the parent
hard remainder again would duplicate it. The reduced soft CT tadpole leaf
instead belongs to the common matching cancellation. This distinction was
added to the prospective execution before any native worker ran.

## Completeness within this domain

SRC's60 binary mass assignments are not momentum regions. Exact row-space
enumeration and an independent hard-flow representation agree on all288
labelled mass/momentum cells:48 quartic and240 sunset. Their dispositions are

| Contribution/domain | Cells |
| --- | ---: |
| Actual vertex-support zero | 95 |
| Retained HH input with at least one positive mass | 35 |
| All-light HH/HS common Taylor domain | 6 / 15 |
| Ordinary one-light HS openings | 22 |
| Additional internal-light HS openings in two-light assignments | 8 |
| Leading light-tree SS assignments | 6 |
| Induced SSS scalar-quartic SS assignments | 3 |
| Higher-dimension VSS SS assignment | 1 |
| Scaleless polynomial Taylor contacts after region expansion | 97 |

These are region labels, not new measured amplitudes or progress percentages.
The35 retained HH mass assignments lie within the existing nine primitive
families. All-light HH/HS has no hard scale. Its common-domain label does
NOT assert that each unrelaxed parent light graph has the same coefficient
as an EFT graph. In particular the scalar parent quartic must be grouped
with heavy-scalar exchange AND the both-soft bridge before comparison.

ASE's actual grouped coefficients are reused from both independently
completed routes. Parent-A/4-B/8 reproduces the relaxed quartic and its
lambda_E=0.1048582429295868953277691162...; mixed/PQ Gaussian terms vanish
within their inherited precision. Maximum new scaled comparison2.21406e-61
passes1e-45. This is reuse/recombination of qualified65-digit source data,
not a new rigorous transcendental identity or physical Higgs determination.
LGF supplies the actual ordinary light gauge/FP tree and charged kinetic
terms. A partial-gauge/quartic-ghost action is not imported from literature.

The22 ordinary HS cuts comprise GSR's12 gauge/ghost and SSR's10 scalar
cuts. The8 additional internal-light cuts are SSS6 and VSS2, already
measured/reconciled in TSR/HDMV2. The SSS SS terms supply induced scalar
exchange; VSS SS starts at dimension six and is fixed-gap suppressed.
Its two HS scalar cuts are nonzero and are preserved. No inner-soft endpoint
is added a second time to SSR's strictly positive-pair formula.

The polynomial contacts are region-expanded dimensional integrals. We do
not set unseparated massless graphs, separate critical UV/IR poles, or the
nonzero fixed-delta field/width response to zero. Higher-operator suppression
uses the inherited finite-loop,positive-gap,local-F2 arguments; this is not
a uniform physical infrared,background or g->0 theorem.

## Common operation, overlaps and tadpoles

Primary ordered differentiation and replay inverse Neumann jets agree on
all18 weighted CT insertion words: six each for real scalar,real vector and
ordered complex ghost. Both background orders, inverse seagull, operator
derivatives and real/Grassmann closing weights remain. The actual OSF444
words and original GSR/SSR/TSR coefficients are authenticated dependencies,
not newly evaluated color tensors. Bare lower-order matching defines
K1=H_h,red+C_F,red-C_E. The same operation closes each term before limits.
Consequently the complete non-HH difference cancels without choosing an
unknown finite hard Higgs mass or finite field/width coefficient.

For each SSS coefficient p=b/M the internal-delta and SS pieces split as

 HSren=-p H_M H_delta/[eps(1-eps)]+p H_delta/eps,
 SSren=+p H_delta^2/[eps(1-eps)]-p H_delta/eps.

The added CTs cancel before expansion. Their finite sum remains
p log(M/delta); it is not zero or a new hard matching parameter. The SS
piece belongs to the induced EFT quartic and its CT. Actual TSR W1/W1log
moments, nonzero kinetic term, original charged forest-1/9 and matched19/18
remain. This is distinct from CLM's13/18. The old HDM extra-closing-pole
interpretation remains explicitly superseded, not erased.

The V2 supplement checks tadpole-counterterm routing in the actual positive
three-neutral-singlet Hessian. Primary differentiates the full quadratic
bridge; replay enumerates ordered leaf pairs and independently inverts that
Hessian. All60 nonzero coefficient-map entries and their implicit polynomial
zero complements agree. With hard/soft leaves t_h+R_h F2,t_s+R_s F2 and
renormalizable tadpole CT t_c, the bridge's F2 coefficient splits into

 HHren=-R_h M^-1(t_h+t_c),
 HSloop=-R_h M^-1 t_s-R_s M^-1 t_h,
 CTsoft=-R_s M^-1 t_c,
 SS=-R_s M^-1 t_s.

HSloop,CTsoft and SS have their common EFT partners. HHren remains HTB.
No independent dimension-five scalar-F2 CT is assumed in this renormalizable
slice. Omitting the soft CT bridge or duplicating the hard CT bridge changes
five nonzero coefficient positions each. The actual finite tadpole constants
remain symbolic; mathematical test covectors are not adopted physical values.

The parent soft-transport witness uses the measured Higgs indices(3/5,1,0)
and adjoint indices(0,2,3). A diagnostic finite mass with h=1,delta=1/7
has response(21/10,7/2,0); a diagnostic unit width has(0,1,3/2). They show
why assuming parent/family soft equality is not innocuous. Neither witness
sets a physical normalization. Controls also retain the distinction that
deleting the same inverse seagull on BOTH sides leaves a matching zero
insensitive; the independent full18-word comparison detects that error.

## Execution and limitations

The original preparation FAILED because a broad name glob mistook LRS's
preserved preparation_failure_v1.json/preparation_tool_result_v1.json for
binding manifests. No science ran. Corrected prepare_v2.py explicitly types
those two records, authenticates them among all parent files and still
checks EVERY actual manifest. Original failed source and complete delivered
terminal output remain. An ad hoc text patch was rejected before writing
because its proposed line was absent; this is also recorded. See
PREFLIGHT_CORRECTION_V2.md and preflight records. This repeats an avoidable
orchestration weakness; it is not a failed physics result or erased failure.

Prelaunch review clarified grouped scalar-tree semantics and added the
explicit tadpole-CT decomposition. Original V1 primary/replay/verifier/run
sources are UNEXECUTED and preserved. V2 native/validator sources were
separately frozen before launch. Exactly three manifests:preparation.json,
execution_preparation.json,validation_preparation_v2.json, with5077/5090/5097
bindings. Commands:prepare.py(FAILED);prepare_v2.py;freeze_execution_v2.py;
run_v2.py. All three scientific workers COMPLETED and passed their gates.
After-import times2.148605/1.892943/1.742015seconds; maximum sampled private
47656960/48107520/48652288bytes, two samples each, not instantaneous peaks.
Same600s/8GiB sampled/350MiBlaunch/24MiBpackage; no timeout,cancel or
scientific-output truncation. No qualified large-loop work was repeated.

The external common-light-boundary-v1-2026-10-21 folder holds full captures,
readiness and final custody seals. The e4 readiness command authenticates
its existing bounded checkpoints; it does not independently replay CBR or
accept the science. Custody remains exit2/seven unresolved, NOT PASS.

The [functional matching comparator](https://arxiv.org/html/2412.12270v2#S4)
supports the region/1LPI structure. Its gauge hypotheses remain material;
the [ordinary broken-BF caveat](https://arxiv.org/html/2404.11640v2#S4.SS3)
is addressed here only through LGF's qualified fixed-reference dimension-four
premise. Shared model/action/point,regulator and analytic region assumptions,
upstream calculations,software and AI analyst limit independent assurance.
This is internal analytic/computational corroboration, not external scientist,
experimental or Lean verification. TrackB gains a complete composition and
ownership test while retaining the preparation failure and prelaunch fixes.
Director education stays voluntary and nonblocking.

The next work is the actual hard parent-minus-family remainder, reusing GCT's
already qualified positive-heavy pole-trace result instead of repeating it,
then compatible HTB/finite physical conditions,overall MS and nonlinear C1
conversion. Original RG,gauge-width,basis,degenerate-mass,one-loop and final
physical-refit obligations remain. No partial target comparison or fit.
Scalar140%local/1.94%Euclidean/20.27%timelike,gauge residual.745476/missing
Yukawas,quartetFAIL3960/648,HB1/C5blocked and matter/flavor pause remain.
No old evidence,point,foundation,scheme,authority or remote action changed.
