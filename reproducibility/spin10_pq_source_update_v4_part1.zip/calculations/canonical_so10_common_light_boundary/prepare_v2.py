"""CBR1 prospective contract/source and qualified immutable input freeze."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='988b0763544504f708aa4ac4bdca4d4678012807'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/common-light-boundary-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
parents=[('canonical_so10_scalar_soft_reconciliation', 'validation_receipt_v2.json', '8e5239c50a977a78d98090952f4be19e3286726bf15a2ce27ae124bd3315b772'), ('canonical_so10_scalar_soft_reconciliation', 'adversarial_receipt.json', '2dd82ba7e503524d667d23250ead523fce787971262febda94e299fa4ca2f44e'), ('canonical_so10_gauge_soft_reconciliation', 'validation_receipt_v3.json', '04de86bf2e7af04dcc206026b59cb1270ea0616bb6c6bf8d5fdcccd8d7ad0f79'), ('canonical_so10_gauge_hard_kinetic_curvature', 'validation_receipt.json', 'c01f7b73ed60d895ea32e7e5b9894fd9a18cbf0f7d2db1cd1fbe4b02755f21a2'), ('canonical_so10_scalar_hard_gauge_normalization', 'validation_receipt.json', '4f91bbc1aa6f96d860817a1f4391d76e02cb8eaa3390c13315dbeff8effeaf50'), ('canonical_so10_unbroken_vector_hard_mass', 'validation_receipt_v2.json', '6c31a48f82b5fd99a2dc53fae79248842d6e7fd94786bd6a361cce8c6e05e1d0'), ('canonical_so10_light_field_normalization', 'validation_receipt.json', '1b899a5e6f1932353e60f534ba712a4ae9f6793447d37e350fa53db12b463a71'), ('canonical_so10_two_soft_regulator_reconciliation', 'validation_receipt.json', '045224bc43edabcc38071248388f3a184bc965e67cecc894bbb092881f02a8c2'), ('canonical_so10_hard_delta_matching', 'validation_receipt_v2.json', 'ea83003375edff8fa212b71047c8c1f2ba915802e5e7201095a5c3585b78bd11'), ('canonical_so10_soft_region_support_closure', 'validation_receipt.json', '9aad60eadad67bf8c7fe807f7f8d38eb082c3aa1efc3df302e0ed55bab1eaccb'), ('canonical_so10_one_soft_factorization', 'validation_receipt_v4.json', '3612bc3db506239b90101c5b8b511243c7e8e2aa5581de3f2b5ac24018e427fe'), ('canonical_so10_all_soft_scalar_tree', 'validation_receipt.json', '2fc51822ce0a10dcc8c11216bd5ca22ebb6410261d976e490ffb60bfa3b64aa7'), ('canonical_so10_light_gauge_tree_correspondence', 'validation_receipt.json', '43468f7cb07c8df65e13092d47375bbad4fd57ed6c1118805a4a64ff0b5cfda4'), ('canonical_so10_light_regulator_spurion', 'validation_receipt.json', '6706209b1c043d44106d68b3956daa5fb794d005be9102b4afe67620451c51fb'), ('canonical_so10_heavy_tadpole_bridge', 'validation_receipt_v4.json', '3b77d2f5bd1d93ce5f0cc55b12a06e36ad00cf88d748e3ca284b9a6752b4fa00'), ('canonical_so10_nine_family_uv_assembly', 'validation_receipt.json', '834a79eb5cf5f0009bc7b7f1a9a3d9b339db92abd92a79c0b1ac50b4d75df14a'), ('canonical_so10_scalar_counterterm_family_closure', 'validation_receipt.json', '9443bea431be22e60982ccd7d61813bc833bf2d1d73715b83015d4302c5a14f1')]

deps={};cache={};qualified={};non_manifest_records={}
for folder,receipt,want in parents:
    P=ROOT/'calculations'/folder
    for p in P.glob('*preparation*.json'):
        if p.name in ['preparation_failure_v1.json','preparation_tool_result_v1.json']:
            assert folder=='canonical_so10_light_regulator_spurion'
            record=json.loads(p.read_bytes());assert 'input_sha256' not in record
            non_manifest_records[str(p)]={'sha256':sha256(p.read_bytes()).hexdigest(),'classification':'PRESERVED_PREFLIGHT_FAILURE_OR_TOOL_OUTPUT_NOT_A_BINDING_MANIFEST'}
            continue
        bindings=json.loads(p.read_bytes())['input_sha256'];assert bindings
        for n,h in bindings.items():
            n=str((ROOT/Path(n)).resolve())
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in P.iterdir():
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=P/receipt;v=json.loads(p.read_bytes());assert v['status'].startswith('QUALIFIED_') and sha256(p.read_bytes()).hexdigest()==want
    qualified[folder+'/'+receipt]={'status':v['status'],'sha256':want}
for name in ['calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/RECORD.md','calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/MASTER_BASIS_CONTRACT.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_vector_ghost_closed_controls_v3.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_vector_ghost_closed_actual_v3.py','tools/pole_blind_validation_guard/sitecustomize.py','AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V444.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:
    p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py','prepare_v2.py','PREFLIGHT_CORRECTION_V2.md','preflight_failure.json','preflight_tool_events.json']:
    p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(name+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==28258
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
dump(HERE/'preparation.json',(json.dumps({'schema':'CBR1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),'qualified_receipts':qualified,'non_manifest_records':non_manifest_records,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':24*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(deps),'bindings;28258 oldblobs;no science executed',flush=True)
