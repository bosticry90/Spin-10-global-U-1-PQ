# CBR1 projected two-loop light-boundary proof

## Region domain and the actual leading light theory

The60 SRC entries label masses, not integration regions. A doublebubble has
independent momenta k,l and four regions HH,HS,SH,SS. A sunset has k,l,k+l;
any two soft edge momenta force the third soft, leaving HH,three distinct
one-soft-edge regions,and SS. Enumerating these subspaces with every mass
assignment gives288 labelled mass/region cells before support exclusions.
All9 interaction families remain. A massless line may carry hard momentum.

The exact SRC identities exclude19 mass assignments in EVERY region. In the
other cells: at least one positive mass can supply a hard scale; a one-soft
edge carrying a light field closes a massive hard two-point cycle. All-light
HH/HS Taylor regions have no hard mass scale and belong to the common
subtraction domain, not to a heavy threshold. This does NOT assert equality
of each unrelaxed parent light graph with one EFT graph. The scalar quartic
must first be grouped with exchange and the heavy bridge below. Soft-expanded heavy
propagators are polynomial; a soft loop with no light propagator is a
scaleless Taylor contact in dimensional regularization, after the region
expansion/common subtraction. This does not erase a full massless integral
or its separate UV/IR residues. No heat-cutoff equivalence is assumed.

All-light assignments give the six leading light graph families VVVV,VVSS,
SSSS,VVV,VSS,ghostV. LGF proves their actual fixed-v H gauge,ordered FP,
Higgs/PQ kinetic density and absence of a light ghost-scalar vertex. ASE
supplies the RELAXED scalar quartic. The SSS three two-light/one-heavy mass
assignments have a nonzero SS heavy-scalar exchange; the both-soft heavy
bridge supplies its other Wick pairing. Their sum with the parent quartic
is the actual measured EFT quartic, not the original unrelaxed restriction.
The VSS two-light/one-heavy-vector assignment induces a dimension-six
current interaction in SS. Its F2 coefficient is suppressed by delta/M.
The two possible light-edge HS cuts remain NONZERO and are retained by TSR.

The22 ordinary one-light mass assignments have22 possible leading HS cuts.
The four two-light mass assignments have8 additional HS cuts and four SS
cells of the kinds just described. These counts are tested by independent
momentum-conservation and row-space methods; they are not30 new integrals.

## Common insertions and dimensional order

OSF proves complete weighted cycle opening and its444 background words.
GSR/SSR identify the ACTUAL original one-soft prescriptions with that
operation, including finite D terms,kinetic terms and ghost signs. TSR/HDM
provide its internal-delta expansion and two-soft overlap. The source-zero
Gaussian local operator domain is exhausted here by mass,kinetic,width and
vector magnetic terms. Higher-dimension quadratic operators close with a
positive power of delta at fixed heavy gap. Higher TREE operators likewise
are suppressed in the all-soft F2 coefficient (LGF). In particular the
nonzero finite dimension-four responses cannot be dropped by that argument.

For each species use the ordered operation L_s, real boson1/2 or complex
ghost-1 times Tr(G_s X). Its two background derivatives contain SIX words:
 G Kh G Kk G X + G Kk G Kh G X - G Khk G X
 -G Kh G Xk -G Kk G Xh +G Xhk.
No cyclic commuting or background-order identification is used. Bare
two-point matching defines K1=H_h,red+C_F,red-C_E. Apply the SAME L_s to all
three terms. Thus L_s(H_h,red+C_F,red)-L_s(K1)-L_s(C_E)=0 before limits.
This is an inherited matching definition and a tested common operation,
not an unknown input chosen from a desired gauge cancellation. Finite hard
Higgs mass/field/width coefficients may remain arbitrary and nonzero.

Writing one-loop leaves F_h,F_s and positive heavy inverse M^-1, the reduced
two-loop functional contains -(F_h'+F_s')M^-1(F_h'+F_s')/2. The two mixed
orderings form the OSF reduced HS leaf. The SS leaf completes ASE's tree
quartic. The HH leaf remains a distinct HTB contribution; it is not canceled
by one-soft or full1PI dumbbell exclusion. This holds before background
derivatives and therefore retains all11 bridge background placements.

## The two-soft overlap is not an additional matching coefficient

For a nonzero SSS spectral weight b and heavy squared mass M, let p=b/M,
H=H_eps(M),h=H_eps(delta). TSR retains the internal-delta piece
 -p H h/[eps(1-eps)]
and SS piece +p h^2/[eps(1-eps)]. Their sum has zero pole but nonzero
p log(M/delta). Their natural proper split is

 HSren=-p H h/[eps(1-eps)]+p h/eps,
 SSren=+p h^2/[eps(1-eps)]-p h/eps.

The two added CTs cancel EXACTLY before expansion. HSren finite is
-p(1+log(Q^2/M)); SSren finite is+p(1+log(Q^2/delta)). The latter belongs
to the induced EFT tree quartic and its CT, not to a new hard local term.
Keeping only either finite piece, or allocating both CTs twice, is wrong.
This per-row identity preserves actual W1/W1log moments,zero-charge source
rows and the nonzero kinetic piece. VSS's complete TSR finite terms and its
original per-axis scalar forest -(1/d+3)/6 are inherited unchanged; its
charged-vector finite forest-1/9 and matched19/18 remain distinct from CLM.

## Parent-minus-family transport

Use a common finite-delta regulator before region expansion and write
C_F=C_Fh+C_Fs and C_f=C_fh+C_fs for the PARENT and ORIGINAL FAMILY insertion
closures. The s/h subscript labels the REMAINING loop's region, not whether
the UV subgraph contains a light mass. Heavy closings retain all internal
light UV contributions. No original Cfull is replaced by a heavy-only
internal subgraph. Let S_f be the complete bare non-HH subtraction and
M_f=B_f+C_f-S_f-C_fs the graph-locally matched input in its qualified
convention. Any stored bare primitive is first normalized algebraically to
that convention; G2P's explicit quartic proper forest provides this lift.

The actual EFT non-HH contribution, including lower-order matching and EFT
CTs, is sum_f S_f+C_Fs after the preceding common-operation proof and
heavy-reduction decomposition. Hence the physical projected difference is

 sum_f M_f +(C_F-sum_f C_f) +(sum_f C_fs-C_Fs)
   = sum_f M_f +C_Fh-sum_f C_fh.

The extra parent/family SOFT TRANSPORT is necessary unless its vanishing is
separately proved. The old identity M_f+(C_F-C_f)=B_f+C_F-(S_f+C_fs) remains
correct; it was not by itself the full common EFT subtraction. This new
composition does not invalidate earlier measured kernels or totals. It
identifies their exact-once assembly convention. Never add an old complete
FCI on top of a graph-local result without subtracting the original forest.

This equation is an operator identity with actual C_F left symbolic. It
does not assert C_F equals a sum of family forests, determine its finite
normalizations,or supply a two-loop background counterterm. A finite scalar
mass-direction witness has response tau_H hfin/(2delta),tau_H=(3/5,1,0),
so a guessed equality is not an innocent numerical convention. Pure-field
regulator coordinate transport must match on both sides (LFN); no ghost or
Goldstone partner is invented for a pure light width response.

This proves the bounded projected COMMON SOFT REDUCTION in the declared BFT
reference family, modulo fixed-gap suppressed terms and inherited qualified
region premises. It is not the final evaluated hard parent remainder, HTB,
overall MS subtraction,finite physical conditions or nonlinear C1 mapping.
The original acceptance gates and the general ordinary-BF warning remain.

## Primary comparators checked for this continuation

[Fuentes-Martin et al2412.12270v2](https://arxiv.org/html/2412.12270v2#S4),
sections4.1/4.2 and appendixD: quantum-heavy1LPI matching, region decomposition,
combinatorics and polynomial soft contacts in dimensional regularization.
[Thomsen2404.11640v2](https://arxiv.org/html/2404.11640v2#S4.SS3),section4.3:
the ordinary broken-BF gauge's heavy-EOM/quantum-fixing difficulty. LGF's
actual fixed-reference dimension-four proof is the model-specific premise;
these references alone do not certify it. No verbatim passage is reproduced.
