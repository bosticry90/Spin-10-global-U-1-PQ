# CBR1: compose the actual projected common light boundary

Prospective on main at988b0763544504f708aa4ac4bdca4d4678012807.
Previous turn PROGRESS: SSR1 qualified all ten remaining ordinary scalar
one-soft mass assignments. No live research process or uncommitted work.

1. Question: do the existing tree, cycle-opening, regulator/overlap and
   original-family results justify a COMPLETE source-zero dimension-four
   light-boundary reduction, and what counterterm ownership follows?
2. Claim: the specified BFT one/two-soft and all-soft terms are reproduced
   by the common EFT tree and independently defined quadratic matching
   insertion. The exact-once parent forest must be transported consistently
   with each stored matched primitive. This is not just an inventory count.
3. Ceiling: fixed-v,xi1,H-background,Euclidean dimensional/MSbar local F2,
   five light scalars/12 light gauge generators/ordered ghosts,598 quantum
   coordinates. Scientific/director acceptance NOT_PERFORMED. No physical
   prescription, full finite C1,E5/A5 or unification qualification;34/39 stays.
4. Frozen inputs: actual SRC60 mass census; OSF444 weighted words/six CT
   words and mixed heavy-EOM leaf; ASE/LGF tree; HDM V2/TSR regulator and
   overlap; UHF/LFN/SHG/GHK/GSR/SSR original mass/kinetic/curvature response;
   G2P original forest ledger,HTB both-hard contribution,original C1 contract.
   Exact receipt/source/manifests authenticated in preparation.json.
5. Distinguish MASS assignments from MOMENTUM regions. Enumerate both loop
   momenta using actual two-loop topologies; no unseparated scaleless
   integral is set to zero. Fixed positive heavy gap and small delta only.
   Preserve IR/UV poles until common subtraction. No uniform g->0 limit.
6. Primary: exact rational momentum subspaces, ordered insertion derivative
   algebra, full-minus-EFT heavy reduction, and original forest transformation.
   Reuse already qualified model coefficients; no giant self-energy/integral.
7. Replay: graph momentum-conservation/cycle enumeration, inverse Neumann
   jets and exact Fraction coefficient maps; independent direct hard/soft
   counterterm projection. Compare before dependent validation/mutations.
8. Falsifiers: a missing mass/region cell, omitted induced scalar quartic or
   heavy bridge, duplicated overlap, wrong ghost sign, missing inverse seagull,
   premature parent/family equality or double original forest. Test a genuine
   charged finite-response witness, not just a symbolic zero by definition.
9. Actual checks: ASE Gaussian parent/exchange/bridge coefficients and
   lambda_E; TSR internal-delta/double-soft CT redistribution, including its
   nonzero finite/log overlap; LFN real charge indices and nonzero width
   response. Inner-soft endpoints stay TSR, not added to SSR again.
10. Resources:600seconds after imports per serial native/verifier,8GiB
    sampled private,350MiB launch available commit,24MiB package. No agents,
    expensive qualified reruns, timeout-as-PASS or output truncation.
11. Outcomes: bounded reduction qualified; actual missing premise; exact
    contradiction; or resource-incomplete. No finite coefficient fitted to
    cancel a target. Physical finite hard conditions remain free symbols.
12. Record: frozen sources, two native tables/results, separate validation,
    full captures, resource observations, readiness e4, raw/index/HEAD custody,
    RESULT and next smallest scientific action. Preserve every failure.

Scientific basis: standard expansion by subgraphs and perturbative matching,
with the model-specific fixed-reference gauge restriction checked by LGF.
Fuentes-Martin et al2412.12270v2 sections4.1/4.2 and appendixD supply the
region/1LPI comparator. Thomsen2404.11640v2 section4.3 supplies the ordinary
broken-BF warning. This is not a universal ordinary-gauge theorem or adoption
of partial gauge fixing/quartic ghosts. The original C1 gauge/width,basis,
degenerate-mass,RG and one-loop gates remain unmodified.

TrackB tests whether AI can correctly compose independently checked physics
without confusing a mass label, a region, and a counterterm convention.
Shared action,regulator,premises,software and analyst limit independence.
No external scientist/experiment/Lean confirmation; education nonblocking.
Protected/paused stages and all scalar,gauge,quartet/custody warnings remain.
