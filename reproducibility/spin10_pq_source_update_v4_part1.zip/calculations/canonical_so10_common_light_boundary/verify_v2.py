"""CBR1 complete region, common-operation and forest-transport validation."""
from data import *
from collections import Counter
start=begin('validation_preparation_v2.json');mp.mp.dps=100
A=packed(HERE/'primary_v2_tables.json.gz');B=packed(HERE/'replay_v2_tables.json.gz')
assert A['peer_or_physical_targets_read'] is B['peer_or_physical_targets_read'] is False
assert A['cells']==B['cells'] and len(A['cells'])==288
assert A['mass_census']==B['mass_census']=={'ALL_HARD':9,'ONE_SOFT_CANDIDATE':22,'TWO_SOFT_CANDIDATE':4,'ALL_SOFT_CANDIDATE':6,'STRUCTURAL_ZERO':19}
want={'STRUCTURAL_VERTEX_ZERO':95,'RETAIN_HARD_INPUT':35,'PURE_LIGHT_COMMON_HH':6,'PURE_LIGHT_COMMON_HS':15,
 'ORDINARY_HARD_OPENING':22,'INTERNAL_LIGHT_HARD_OPENING_TSR':8,'COMMON_LIGHT_TREE_SS':6,
 'INDUCED_SCALAR_QUARTIC_SS':3,'HIGHER_DIMENSION_TREE_SS':1,'SCALELESS_TAYLOR_CONTACT_AFTER_EXPANSION':97}
assert A['fate_counts']==B['fate_counts']==want
assert len({(v['family'],tuple(v['mass_bits']),tuple(v['soft_momentum_edges'])) for v in A['cells']})==288
ordinary=[v for v in A['cells'] if v['fate']=='ORDINARY_HARD_OPENING']
internal=[v for v in A['cells'] if v['fate']=='INTERNAL_LIGHT_HARD_OPENING_TSR']
source=packed(CAL/'canonical_so10_scalar_soft_reconciliation/primary_v2_tables.json.gz')
scalar={(v['family'],tuple(v['bits'])) for v in source['scalar_slots']}
gauge={(v['family'],tuple(v['bits'])) for v in source['other_gauge_ghost_slots']}
assert {(v['family'],tuple(v['mass_bits'])) for v in ordinary}==scalar|gauge and len(scalar)==10 and len(gauge)==12
assert Counter(v['family'] for v in internal)=={'SSS':6,'VSS':2}
assert Counter(v['family'] for v in A['cells'] if v['fate']=='COMMON_LIGHT_TREE_SS')=={n:1 for n in ['VVVV','VVSS','SSSS','VVV','VSS','ghostV']}
assert all(v['family']=='SSS' for v in A['cells'] if v['fate']=='INDUCED_SCALAR_QUARTIC_SS')
assert all(v['family']=='VSS' for v in A['cells'] if v['fate']=='HIGHER_DIMENSION_TREE_SS')

assert A['ordered_CT_words']==B['ordered_CT_words'] and sum(map(len,A['ordered_CT_words'].values()))==18
for name,words in A['ordered_CT_words'].items():
    assert len(words)==6
    assert sum('Khk' in w for c,w in words)==1 and sum('Xhk' in w for c,w in words)==1
    assert any(w==['G','Kh','G','Kk','G','X0'] for c,w in words)
    assert any(w==['G','Kk','G','Kh','G','X0'] for c,w in words)
assert A['matching_residual']==B['matching_residual']=='0'
assert A['full_vs_hard_residual']==B['full_vs_hard_residual']=='0'
Ph,Ps=s.symbols('Ph Ps');Fs=s.symbols('Fs0:9')
assert clean(s.sympify(A['parent_soft_transport'])-(sum(Fs)-Ps))==0
assert B['parent_transport_coefficients']==[[['Fs',i],'1'] for i in range(9)]+[[['Ps',0],'-1']]
eps,j,jd,p=s.symbols('eps j jd p',real=True)
dv=s.Symbol('d');parse=lambda z:s.sympify(z,locals={'eps':eps,'j':j,'jd':jd,'p':p,'d':dv})
for n in A['two_soft_overlap']:
    for a,b in zip(A['two_soft_overlap'][n],B['two_soft_overlap'][n]):assert clean(parse(a)-parse(b))==0
assert A['two_soft_overlap']['HS_ren'][0]==A['two_soft_overlap']['SS_ren'][0]==A['two_soft_overlap']['sum'][0]=='0'
assert clean(parse(A['two_soft_overlap']['sum'][1])-p*(jd-j))==0
tsr=packed(CAL/'canonical_so10_two_soft_regulator_reconciliation/primary_tables.json.gz')
assert clean(parse(tsr['VSS_units']['full_renormalized'])-((1+j)/dv+(1+j)+(s.Rational(3,2)+2*j)))==0
# Actual scalar overlap moments are retained, not fitted to their cancellation.
W=list(map(lambda row:list(map(mp.mpf,row)),tsr['scalar_moments_W0_Wlog_W1_W1log']))
for i in range(3):
    assert abs(W[2][i]+mp.mpf(tsr['scalar_overlap_log_delta_coefficient'][i]))<mp.mpf('1e-50')
    assert abs(W[3][i]-mp.mpf(tsr['scalar_overlap_constant'][i]))<mp.mpf('1e-50')
    assert abs(-W[2][i]/2-mp.mpf(tsr['scalar_kinetic_finite'][i]))<mp.mpf('1e-50')
assert W[2][0]!=0 and W[2][1]!=0 and W[2][2]==0
ase_error=mp.mpf(0)
for x,y in zip(A['ASE_reconstructed_effective'],B['ASE_reconstructed_effective']):
    err=abs(mp.mpf(x)-mp.mpf(y))/(1+abs(mp.mpf(x))+abs(mp.mpf(y)));ase_error=max(ase_error,err);assert err<mp.mpf('1e-45')
for x in A['ASE_serialization_residuals']:assert abs(mp.mpf(x))<mp.mpf('1e-45')
assert abs(mp.mpf(A['ASE_reconstructed_effective'][0])/6-mp.mpf(A['ASE_lambda']))<mp.mpf('1e-45')
for x in A['ASE_reconstructed_effective'][1:]:assert abs(mp.mpf(x))<mp.mpf('1e-45')

# Heavy-EOM coefficient check with the ACTUAL neutral raw Hessian. The test
# covectors are explicit mathematical controls, not assigned model tadpoles.
htb=packed(CAL/'canonical_so10_heavy_tadpole_bridge/primary_v3_tables.json.gz')
mat=lambda raw:s.SparseMatrix(*raw['shape'],{(i,k):s.sympify(v) for i,k,v in raw['entries']})
M=mat(htb['raw_Hessian']);Mi=mat(htb['raw_Hessian_inverse'])
assert (M*Mi-s.eye(3)).applyfunc(clean)==s.zeros(3)
th=s.Matrix([1,2,3]);ts=s.Matrix([-1,2,1])
bridge=clean(-((th+ts).T*Mi*(th+ts))[0]/2)
hh=clean(-(th.T*Mi*th)[0]/2);ss=clean(-(ts.T*Mi*ts)[0]/2);hs=clean(-(th.T*Mi*ts)[0])
assert clean(bridge-hh-hs-ss)==0 and hh!=0 and hs!=0 and ss!=0
assert A['bridge_coefficients']==B['bridge_coefficients']=={'HH':'-1/2','HS_plus_SH':'-1','SS':'-1/2'}

# Actual Gaussian index witnesses for a missing finite parent soft transport.
lfn=packed(CAL/'canonical_so10_light_field_normalization/primary_tables.json.gz')
idx=lambda raw,i:s.sympify(next((v for a,b,v in raw['entries'] if a==b==i),'0'))
tauS=[idx(lfn['scalar_index'],i) for i in [0,1,4]];tauA=[idx(lfn['adjoint_index'],i) for i in [0,1,4]]
assert tauS==[s.Rational(3,5),s.Integer(1),s.Integer(0)] and tauA==[0,2,3]
h,delta,width=s.symbols('h delta width',real=True)
mass=[clean(s.sympify(z,locals={'h':h,'delta':delta})) for z in A['nonzero_response_witness']['finite_mass']]
wid=[clean(s.sympify(z,locals={'width':width})) for z in A['nonzero_response_witness']['finite_width']]
assert [clean(z-t*h/(2*delta)) for z,t in zip(mass,tauS)]==[0,0,0]
assert [clean(z-t*width/2) for z,t in zip(wid,tauA)]==[0,0,0]
mass_witness=[str(z.subs({h:1,delta:s.Rational(1,7)})) for z in mass]
width_witness=[str(z.subs(width,1)) for z in wid]
assert mass_witness==['21/10','7/2','0'] and width_witness==['0','1','3/2']
controls={'omit_parent_soft_transport':'leaves Ps-sum(Fs);finite charged witnesses below',
 'finite_scalar_mass_witness':mass_witness,'finite_width_witness':width_witness,
 'lose_original_forest':'nonzero independent Fh/Fs coefficient per family',
 'omit_mixed_bridge':str(-hs),'omit_SS_bridge':str(-ss),'incorrectly_cancel_HH_bridge':str(-hh),
 'drop_overlap_SS_pole':str(-p),'duplicate_overlap_CT_pole':str(p),
 'missing_inverse_seagull':'changes one of each species six ordered words',
 'same_seagull_deleted_on_both_sides':'matching_zero_INSENSITIVE;independent18_word_check_is_sensitive',
 'all_light_HH_as_heavy':'incorrectly includes6 common pure-light cells',
 'all_two_light_as_SS_only':'loses8 TSR internal-light HS cuts'}
for name,words in A['ordered_CT_words'].items():
    missing=[t for t in words if 'Khk' not in t[1]];assert len(missing)==5 and missing!=B['ordered_CT_words'][name]
assert all(s.Rational(c).q==1 for c,w in A['ordered_CT_words']['ghost'])
assert all(abs(s.Rational(c))==s.Rational(1,2) for c,w in A['ordered_CT_words']['scalar'])
for i in range(9):
    mutant=[entry for entry in B['parent_transport_coefficients'] if entry[0]!=['Fs',i]]
    assert len(mutant)==9 and mutant!=B['parent_transport_coefficients']
assert Ph+Ps-sum(Fs)!=Ph and Ps-sum(Fs)!=0

# V2: compare every ordered leaf-pair coefficient and both CT ownerships.
assert A['parent_hard_CT_scope']==B['parent_hard_CT_scope']=='RAW_1PI;CT_TADPOLE_HH_ALREADY_IN_HTB_REN'
assert set(A['tadpole_CT_bridge_maps'])==set(B['tadpole_CT_bridge_maps'])=={'complete','HH_ren','HS_loop','CT_soft','SS'}
bridge_coefficients=0
maps={}
for name in A['tadpole_CT_bridge_maps']:
 aa={tuple(tags):s.sympify(v) for tags,v in A['tadpole_CT_bridge_maps'][name]}
 bb={tuple(tags):s.sympify(v) for tags,v in B['tadpole_CT_bridge_maps'][name]}
 assert set(aa)==set(bb)
 for k in aa:assert clean(aa[k]-bb[k])==0;bridge_coefficients+=1
 maps[name]=aa
for key in maps['complete']:
 assert clean(maps['complete'][key]-sum(maps[n].get(key,s.Integer(0)) for n in ['HH_ren','HS_loop','CT_soft','SS']))==0
assert len(maps['CT_soft'])>0
hard_tadpole={k:v for k,v in maps['HH_ren'].items() if any(t.startswith('tc') for t in k)}
assert hard_tadpole and set(hard_tadpole).isdisjoint(maps['CT_soft'])
controls['double_HH_CT_bridge_nonzero_positions']=len(hard_tadpole)
controls['omit_soft_CT_bridge_nonzero_positions']=len(maps['CT_soft'])

receipt={'schema':'CBR1_VALIDATION','status':'QUALIFIED_PROJECTED_TWO_LOOP_COMMON_LIGHT_BOUNDARY_REDUCTION_AND_FOREST_TRANSPORT',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
 'mass_assignments':60,'labelled_mass_momentum_region_cells':288,'fate_counts':want,
 'ordinary_HS_cuts':22,'internal_light_HS_cuts':8,'induced_SSS_SS_assignments':3,'suppressed_VSS_SS_assignments':1,
 'ordered_insertion_words':18,'same_operation_before_limits':True,'all_original_forests_retained_before_projection':True,
 'parent_soft_transport':'sum(Cfamily_soft)-Cparent_soft',
 'tadpole_bridge_coefficients_compared':bridge_coefficients,'hard_parent_CT':'RAW_1PI;HH_tadpole_CT_in_HTB_only','soft_reduced_tadpole_CT_cancels_with_EFT':True,
 'equivalent_parent_hard_remainder':'Cparent_hard-sum(Cfamily_hard);hard labels the remaining loop,NOT internal subgraph masses',
 'two_soft_overlap_and_EFT_tree_CT_redistribution':'EXACT_BEFORE_LIMITS;NONZERO_FINITE_LOG_RETAINED',
 'maximum_ASE_common_tree_scaled_error':fmt(ase_error),'actual_HH_bridge_removed':False,'finite_physical_conditions_adopted':False,
 'negative_controls':controls,'full_finite_C1_E5_A5_or_quantum_equivalence_qualified':False,
 'scope':'sourcezero,xi1,fixed-v,H-background,Euclidean_dimensional_MSbar_localF2,fixed_heavy_gap',
 'shared_limits':['qualified model inputs and analytic region premises','same regulator/subtraction and perturbative light coordinates','action/point/data/software/AI authorship'],
 'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
