"""CBR1 prospective V2 execution freeze, including explicit CT-tadpole ownership."""
from pathlib import Path
from hashlib import sha256
import json,ast
H=Path(__file__).resolve().parent
deps=dict(json.loads((H/'preparation.json').read_bytes())['input_sha256'])
for n,h in deps.items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
for p in H.iterdir():
 if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['primary_v2.py','replay_v2.py','verify_v2.py','run_v2.py','freeze_execution_v2.py','TADPOLE_OWNERSHIP_SUPPLEMENT_V2.md']:
 p=H/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw,filename=str(p))
 cp=H/(n+'.source.txt')
 with cp.open('xb') as f:f.write(raw)
 deps[str(cp)]=sha256(raw).hexdigest()
with (H/'execution_preparation.json').open('xb') as f:f.write((json.dumps({'schema':'CBR1_V2_EXECUTION_PREPARATION','input_sha256':deps,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'scientific_acceptance':'NOT_PERFORMED','V1_scientific_workers':'UNEXECUTED'},sort_keys=True,indent=2)+'\n').encode())
print('EXECUTION_V2_FROZEN',len(deps),'bindings',flush=True)
