"""CBR1 exact row-space regions and ordered common-operation composition."""
from data import *
from itertools import combinations
from collections import Counter
start=begin('execution_preparation.json');guard('primary')
census=packed(CAL/'canonical_so10_soft_region_support_closure/primary_tables.json.gz')['census']
cells=[]
for row in census:
    n=len(row['light_bits']);flows=[(1,0),(0,1)]+([(1,1)] if n==3 else [])
    regions={}
    for mask in range(1<<n):
        con=s.Matrix([flows[k] for k in range(n) if mask>>k&1]) if mask else s.zeros(0,2)
        rank=con.rank();soft=tuple(k for k,f in enumerate(flows) if con.col_join(s.Matrix([f])).rank()==rank)
        regions[soft]=rank
    for soft,rank in sorted(regions.items()):
        bits=row['light_bits'];alllight=all(bits)
        if row['kind']=='STRUCTURAL_ZERO':fate='STRUCTURAL_VERTEX_ZERO'
        elif rank==0:fate='PURE_LIGHT_COMMON_HH' if alllight else 'RETAIN_HARD_INPUT'
        elif rank==1:
            assert len(soft)==1
            if not bits[soft[0]]:fate='SCALELESS_TAYLOR_CONTACT_AFTER_EXPANSION'
            elif alllight:fate='PURE_LIGHT_COMMON_HS'
            else:fate='ORDINARY_HARD_OPENING' if sum(bits)==1 else 'INTERNAL_LIGHT_HARD_OPENING_TSR'
        elif alllight:fate='COMMON_LIGHT_TREE_SS'
        elif n==3 and sum(bits)==2:
            assert row['family'] in ['SSS','VSS']
            fate='INDUCED_SCALAR_QUARTIC_SS' if row['family']=='SSS' else 'HIGHER_DIMENSION_TREE_SS'
        else:fate='SCALELESS_TAYLOR_CONTACT_AFTER_EXPANSION'
        cells.append({'family':row['family'],'mass_bits':bits,'soft_momentum_edges':list(soft),'fate':fate})
cells.sort(key=lambda v:(v['family'],v['mass_bits'],v['soft_momentum_edges']))

# Generic ordered Hessian insertion differentiated in distinct background directions.
G,Kh,Kk,Khk,X0,Xh,Xk,Xhk=s.symbols('G Kh Kk Khk X0 Xh Xk Xhk',commutative=False)
word=G*Kh*G*Kk*G*X0+G*Kk*G*Kh*G*X0-G*Khk*G*X0-G*Kh*G*Xk-G*Kk*G*Xh+G*Xhk
def encode(poly):
    out=[]
    for term in s.Add.make_args(s.expand(poly)):
        c,w=term.as_coeff_Mul();atoms=list(s.Mul.make_args(w));out.append([str(c),list(map(str,atoms))])
    return sorted(out,key=lambda z:z[1])
words={name:encode(weight*word) for name,weight in [('scalar',s.Rational(1,2)),('vector',s.Rational(1,2)),('ghost',-s.Integer(1))]}
H=s.symbols('H0 Hh Hk Hhk',commutative=False);F=s.symbols('F0 Fh Fk Fhk',commutative=False);E=s.symbols('E0 Eh Ek Ehk',commutative=False)
xs=[X0,Xh,Xk,Xhk]
operation=lambda vs:s.expand(word.xreplace(dict(zip(xs,vs))))
matching=[hh+ff-ee for hh,ff,ee in zip(H,F,E)]
common=s.expand(operation([hh+ff for hh,ff in zip(H,F)])-operation(matching)-operation(E))
assert common==0

# Explicit aggregate full/original-family split; parent/family equality is NOT used.
Bf=s.symbols('B0:9');Sh=s.symbols('S0:9');Fh=s.symbols('Fh0:9');Fs=s.symbols('Fs0:9')
Ph,Ps=s.symbols('Ph Ps');Mf=[b+fh-ss for b,fh,ss in zip(Bf,Fh,Sh)]
# M=B+Cfull-Sbare-Csoft, with Sbare already the complete non-HH bare term.
full=sum(Bf)+Ph+Ps;eft=sum(Sh)+Ps
transport=sum(Fs)-Ps
via_full=sum(Mf)+Ph+Ps-sum(Fh)-sum(Fs)+transport
via_hard=sum(Mf)+Ph-sum(Fh)
assert s.expand(full-eft-via_full)==0 and s.expand(via_full-via_hard)==0

eps,j,jd,p=s.symbols('eps j jd p',real=True);HH,HD=s.symbols('HH HD')
raw_internal=-p*HH*HD/(eps*(1-eps));raw_ss=p*HD**2/(eps*(1-eps))
hs=raw_internal+p*HD/eps;ss=raw_ss-p*HD/eps
assert clean(hs+ss-raw_internal-raw_ss)==0
def jets(v):
    v=v.subs({HH:1+eps*j,HD:1+eps*jd});reg=clean(eps*v)
    return [str(clean(reg.subs(eps,0))),str(clean(s.diff(reg,eps).subs(eps,0)))]
overlap={'raw_internal':jets(raw_internal),'raw_SS':jets(raw_ss),'HS_ren':jets(hs),'SS_ren':jets(ss),'sum':jets(hs+ss)}

mp.mp.dps=100;ase=packed(CAL/'canonical_so10_all_soft_scalar_tree/primary_tables.json.gz')
eff=[mp.mpf(v)-mp.mpf(a)/4-mp.mpf(b)/8 for v,a,b in zip(ase['parent_gaussian'],ase['crossed_A'],ase['trace_B'])]
checks=[mp.mpf(v)-w for v,w in zip(ase['effective_gaussian'],eff)]
lfn=packed(CAL/'canonical_so10_light_field_normalization/primary_tables.json.gz')
tau_s=[s.Rational(3,5),s.Integer(1),s.Integer(0)];tau_a=[s.Integer(0),s.Integer(2),s.Integer(3)]
h,delta,ww=s.symbols('h delta width',real=True)
witness={'finite_mass':list(map(str,[t*h/(2*delta) for t in tau_s])),
 'finite_width':list(map(str,[t*ww/2 for t in tau_a]))}

# V2: explicit CT-tadpole ownership in the ACTUAL neutral carrier.
htb=packed(CAL/'canonical_so10_heavy_tadpole_bridge/primary_v3_tables.json.gz')
Mi=s.SparseMatrix(*htb['raw_Hessian_inverse']['shape'],{(i,k):s.sympify(v) for i,k,v in htb['raw_Hessian_inverse']['entries']})
th,ts,tc,rh,rs=[s.Matrix(s.symbols(prefix+'0:3')) for prefix in ['th','ts','tc','rh','rs']]
nu=s.Symbol('F2')
leaf=th+ts+tc+nu*(rh+rs)
complete=s.expand(s.diff(-(leaf.T*Mi*leaf)[0]/2,nu).subs(nu,0))
blocks={'complete':complete,'HH_ren':-(rh.T*Mi*(th+tc))[0],
 'HS_loop':-(rh.T*Mi*ts)[0]-(rs.T*Mi*th)[0],
 'CT_soft':-(rs.T*Mi*tc)[0],'SS':-(rs.T*Mi*ts)[0]}
variables=list(th)+list(ts)+list(tc)+list(rh)+list(rs)
def bridge_map(poly):
    out=[]
    for powers,co in s.Poly(s.expand(poly),*variables).terms():
        tags=[str(v) for v,power in zip(variables,powers) for _ in range(power)]
        assert len(tags)==2
        if co!=0:out.append([sorted(tags),str(clean(co))])
    return sorted(out,key=lambda q:q[0])
bridge_maps={k:bridge_map(v) for k,v in blocks.items()}
assert s.expand(blocks['complete']-sum(v for k,v in blocks.items() if k!='complete'))==0

save('primary_v2',{'schema':'CBR1_PRIMARY','peer_or_physical_targets_read':False,'cells':cells,
 'fate_counts':dict(Counter(v['fate'] for v in cells)),'mass_census':dict(Counter(v['kind'] for v in census)),
 'ordered_CT_words':words,'matching_residual':str(common),'parent_soft_transport':str(transport),
 'full_vs_hard_residual':str(s.expand(full-eft-via_hard)),'two_soft_overlap':overlap,
 'ASE_reconstructed_effective':list(map(fmt,eff)),'ASE_serialization_residuals':list(map(fmt,checks)),
 'ASE_lambda':ase['lambda_from_all_light_source'],'nonzero_response_witness':witness,
 'tadpole_CT_bridge_maps':bridge_maps,'parent_hard_CT_scope':'RAW_1PI;CT_TADPOLE_HH_ALREADY_IN_HTB_REN',
 'bridge_coefficients':{'HH':'-1/2','HS_plus_SH':'-1','SS':'-1/2'},
 'LFN_actual_response_evidence':lfn['response_per_index'],
 'complete_projected_light_reduction_pending_validation':True,'full_C1_E5_A5_or_physical_scheme_qualified':False},start)
