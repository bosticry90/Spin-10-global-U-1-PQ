"""CBR1 graph-flow dual regions, Neumann jets and Fraction forest ownership."""
from data import *
from fractions import Fraction as Q
from collections import Counter
start=begin();guard('replay')
census=packed(CAL/'canonical_so10_soft_region_support_closure/replay_tables.json.gz')['census']
cells=[]
for item in census:
    bits=item['light_bits'];n=len(bits);edges=[(1,0),(0,1)]+([(1,1)] if n==3 else [])
    # Hard-momentum flow subspaces dual to the primary's soft constraints.
    hardspaces=[[(1,0),(0,1)],[(1,0)],[(0,1)]]+([[(1,-1)]] if n==3 else [])+[[]]
    for hard in hardspaces:
        soft=[i for i,(a,b) in enumerate(edges) if all(a*x+b*y==0 for x,y in hard)]
        if item['kind']=='STRUCTURAL_ZERO':dest='STRUCTURAL_VERTEX_ZERO'
        elif len(hard)==2:dest='RETAIN_HARD_INPUT' if 0 in bits else 'PURE_LIGHT_COMMON_HH'
        elif not hard:
            if 0 not in bits:dest='COMMON_LIGHT_TREE_SS'
            elif sum(bits)==2 and n==3:
                dest={'SSS':'INDUCED_SCALAR_QUARTIC_SS','VSS':'HIGHER_DIMENSION_TREE_SS'}[item['family']]
            else:dest='SCALELESS_TAYLOR_CONTACT_AFTER_EXPANSION'
        elif bits[soft[0]]==0:dest='SCALELESS_TAYLOR_CONTACT_AFTER_EXPANSION'
        elif 0 not in bits:dest='PURE_LIGHT_COMMON_HS'
        elif bits.count(0)==n-1:dest='ORDINARY_HARD_OPENING'
        else:dest='INTERNAL_LIGHT_HARD_OPENING_TSR'
        cells.append({'family':item['family'],'mass_bits':bits,'soft_momentum_edges':soft,'fate':dest})
cells.sort(key=lambda v:(v['family'],v['mass_bits'],v['soft_momentum_edges']))

def add(*polys):
    out={}
    for poly in polys:
        for k,v in poly.items():out[k]=out.get(k,Q(0))+v
    return {k:v for k,v in out.items() if v}
def scale(poly,c):return {k:v*c for k,v in poly.items() if v*c}
def mul(A,B):
    out={}
    for (ah,ak,aw),av in A.items():
        for (bh,bk,bw),bv in B.items():
            if ah+bh<=1 and ak+bk<=1:
                key=(ah+bh,ak+bk,aw+bw);out[key]=out.get(key,Q(0))+av*bv
    return {k:v for k,v in out.items() if v}
G={(0,0,('G',)):Q(1)}
V={(1,0,('Kh',)):Q(1),(0,1,('Kk',)):Q(1),(1,1,('Khk',)):Q(1)}
inverse=add(G,scale(mul(mul(G,V),G),Q(-1)),mul(mul(mul(mul(G,V),G),V),G))
X={(0,0,('X0',)):Q(1),(1,0,('Xh',)):Q(1),(0,1,('Xk',)):Q(1),(1,1,('Xhk',)):Q(1)}
hk={word:value for (h,k,word),value in mul(inverse,X).items() if h==k==1}
words={name:sorted([[str(c*weight),list(word)] for word,c in hk.items()],key=lambda t:t[1]) for name,weight in [('scalar',Q(1,2)),('vector',Q(1,2)),('ghost',Q(-1))]}
# Componentwise independently defined bare matching. No commuting of G/K/X.
components={'0':(0,0),'h':(1,0),'k':(0,1),'hk':(1,1)}
def extension(prefix):return {(h,k,(prefix+name,)):Q(1) for name,(h,k) in components.items()}
H,F,E=map(extension,['H','F','E']);K=add(H,F,scale(E,Q(-1)))
res=add(mul(inverse,add(H,F)),scale(mul(inverse,K),Q(-1)),scale(mul(inverse,E),Q(-1)))
assert not res
# Coefficient maps with all nine original families distinct.
full={('B',i):Q(1) for i in range(9)};full.update({('Ph',0):Q(1),('Ps',0):Q(1)})
eft={('S',i):Q(1) for i in range(9)};eft['Ps',0]=Q(1)
matched={('B',i):Q(1) for i in range(9)};matched.update({('Fh',i):Q(1) for i in range(9)});matched.update({('S',i):Q(-1) for i in range(9)})
parent_minus_full={('Ph',0):Q(1),('Ps',0):Q(1)}
for i in range(9):parent_minus_full['Fh',i]=Q(-1);parent_minus_full['Fs',i]=Q(-1)
transport={('Fs',i):Q(1) for i in range(9)};transport['Ps',0]=Q(-1)
reconstructed=add(matched,parent_minus_full,transport);direct=add(full,scale(eft,Q(-1)))
assert reconstructed==direct

# Analytic subtraction of two meromorphic ratios at epsilon=0. Each term
# keeps its own simple-pole and derivative of the analytic numerator.
eps,j,jd,p=s.symbols('eps j jd p',real=True)
terms={'raw_internal':(-p,(j+jd+1)*(-p)),'raw_SS':(p,p*(2*jd+1)),
 'HS_ren':(s.Integer(0),-p*(j+1)),'SS_ren':(s.Integer(0),p*(jd+1)),
 'sum':(s.Integer(0),p*(jd-j))}
overlap={k:list(map(str,map(clean,v))) for k,v in terms.items()}
mp.mp.dps=100;ase=packed(CAL/'canonical_so10_all_soft_scalar_tree/replay_tables.json.gz')
eff=[mp.mpf(v)-mp.mpf(ex) for v,ex in zip(ase['parent_gaussian'],ase['induced_exchange_gaussian'])]
save('replay',{'schema':'CBR1_REPLAY','peer_or_physical_targets_read':False,'cells':cells,'fate_counts':dict(Counter(v['fate'] for v in cells)),
 'mass_census':dict(Counter(v['kind'] for v in census)),'ordered_CT_words':words,'matching_residual':str(len(res)),
 'parent_transport_coefficients':[[list(k),str(v)] for k,v in sorted(transport.items())],
 'full_vs_hard_residual':str(len(add(reconstructed,scale(direct,Q(-1))))),'two_soft_overlap':overlap,
 'ASE_reconstructed_effective':list(map(fmt,eff)),'ASE_lambda':ase['lambda_from_all_light_source'],
 'bridge_coefficients':{'HH':'-1/2','HS_plus_SH':'-1','SS':'-1/2'},
 'full_C1_E5_A5_or_physical_scheme_qualified':False},start)
