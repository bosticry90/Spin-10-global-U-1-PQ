# CBR1 V2 prospective execution: keep tadpole CT bridges in one place

Before any scientific worker, review identified an ownership distinction that
must be made explicit in the composition. All V1 native sources remain
UNEXECUTED. Their frozen preparation remains. V2 adds the following exact
test without changing inputs, tolerances, original kernels or resource caps.

In the parent-minus-family equation, C_Fh/C_Fs denote RAW1PI one-loop
counterterm closures, split by the remaining loop. The reduced C_F,red in
lower-order light matching additionally contains the heavy-EOM tadpole leaf.
It must not be counted once in a hard parent insertion and again in the
already tadpole-renormalized HTB contribution.

In the actual positive three-neutral-singlet carrier write, through F2,
 F_h'=t_h+R_h F2, F_s'=t_s+R_s F2, C1'=t_c.
M is the actual raw neutral Hessian. Renormalizable tree counterterms have
no independent neutral-scalar F2 tadpole: such a field operator has dimension
five. Thus t_c has no F2 component in this declared slice; this is not a
general claim about arbitrary effective higher-dimensional counterterms.
The actual constant neutral Hessian has no tree background-H connection.
HTB qualifies this carrier and the absence of other contributing F2 bridges.

The complete bridge's F2 coefficient is
 -(R_h+R_s) M^-1 (t_h+t_s+t_c).
It splits exactly into
 HH_ren = -R_h M^-1 (t_h+t_c),
 HS_loop = -R_h M^-1 t_s-R_s M^-1 t_h,
 CT_soft = -R_s M^-1 t_c,
 SS = -R_s M^-1 t_s.

HS_loop is OSF's mixed leaf, SS completes ASE's quartic tree, and CT_soft
is the reduced-C_F term in the SAME soft matching operation. They cancel
their EFT counterparts. HH_ren remains the qualified HTB normalization
family. With that explicit allocation the remaining parent-minus-family
term is RAW C_Fh-sum RAW C_fh. The actual HTB loop-plus-f_fin family can be
added once, after the required finite conditions and projections agree.
No tadpole coefficient is set to zero or fitted here.

The primary differentiates the complete quadratic bridge using the frozen
M^-1; replay enumerates ordered leaf pairs with the factor-1/2 and derives
M^-1 independently from the raw Hessian. All coefficient maps, including
zeros, must agree. A separate verifier checks the decomposition and detects
omitting/doubling either CT bridge. Mathematical test covectors are not
assigned physical tadpoles. No finite physical prescription or final C1 is
earned by this ownership theorem.
