"""GFT1 exterior Gaussian, barred Clifford angular moments and raw products."""
from data import *
start=begin('primary')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   n=sum((b&((1<<i)-1)).bit_count() for i in range(a.bit_length()) if (a>>i)&1)%2;out[a|b]=out.get(a|b,0)+(-1)**n*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)}
F,a,b,c,X,Y,t=s.symbols('F a b c X Y t',nonzero=True);action={12:-(F+t*c),5:a*X,10:-b*Y};term={0:s.S.One};exponential=dict(term)
for n in range(1,5):
 term={k:-v/n for k,v in mul(term,action).items()}
 for k,v in term.items():exponential[k]=s.expand(exponential.get(k,0)+v)
effective=-exponential[15]/exponential[12];unit=s.simplify(s.diff(effective,t).subs(t,0)/(a*b*c*X*Y/F**2));assert unit==1
phase=s.simplify(unit*(-s.I)**3*(-s.I)**2)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gamma=[s.kronecker_product(pa[1],x) for x in pa]+[s.kronecker_product(pa[0],s.eye(2))];ks=s.symbols('k0:4');slash=sum((k*A for k,A in zip(ks,gamma)),s.zeros(4));d=s.Symbol('d')
def avg(z):
 out=0
 for p,v in s.Poly(s.expand(z),*ks).terms():
  if any(n%2 for n in p):continue
  out+=v*s.prod(s.factorial2(n-1) for n in p)/s.prod(d+2*j for j in range(sum(p)//2))
 return s.factor(out)
factors=[]
for rho,G in enumerate(gamma):
 NF=sum((A*slash*G*slash*A for A in gamma),s.zeros(4)).applyfunc(avg);NL=(slash*slash*G*slash*slash).applyfunc(avg);ff=s.simplify(s.trace(G*NF)/4);fl=s.simplify(s.trace(G*NL)/4);zero(NF-ff*G);zero(NL-fl*G);factors.append([str(ff),str(fl)])
assert len(set(map(tuple,factors)))==1;ff0=ff.subs(d,4);fl0=fl.subs(d,4)
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,yc['Tminus']));H=dec(yc['H_new']);Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);Qi=Q.inv();ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};rawG=dec(ref['reference_Green_raw_C3']);p=s.symbols('p0_ref0:4');sub=dict(zip(p,[1,0,0,0]))
GF=s.Matrix(45,45,lambda a,b:s.simplify(rawG[fi[f'B{a}_1'],fi[f'B{b}_1']].subs(sub)));GL=s.Matrix(45,45,lambda a,b:s.simplify(-rawG[fi[f'B{a}_0'],fi[f'B{b}_0']].subs(sub)));W=xi*s.eye(45)+(eta-xi)*H*H.T;zero(GF-Qi*Qi.T);zero(GL-Qi*W*Qi.T)
TR=[tidy(sum((Q[a,c]*T[a] for a in range(45) if Q[a,c]),s.zeros(16))) for c in range(45)]
def currents(weight):
 pair=list(s.SparseMatrix(weight).todok().items());L=[];R=[]
 for c in range(45):
  L.append(tidy(phase*sum((v*TR[a]*TR[c]*TR[b] for (a,b),v in pair),s.zeros(16))));R.append(tidy(-phase*sum((v*TR[a].T*TR[c].T*TR[b].T for (a,b),v in pair),s.zeros(16))))
 return [[tidy(sum((Qi[c,h]*A[c] for c in range(45) if Qi[c,h]),s.zeros(16))) for h in range(45)] for A in [L,R]]
LF,RF=currents(GF);LL,RL=currents(GL-GF);L=[tidy(ff0*a+fl0*b) for a,b in zip(LF,LL)];R=[tidy(ff0*a+fl0*b) for a,b in zip(RF,RL)]
CW=sum((v*T[a]*T[b] for (a,b),v in s.SparseMatrix(W).todok().items()),s.zeros(16));wrong=[tidy(phase*A*CW) for A in T]
finish('primary',{'method':'actual_raw_BB_reference_exterior_Gaussian_Clifford_and_ordered_triples','loop_left':list(map(enc,L)),'loop_right':list(map(enc,R)),'Feynman_left':list(map(enc,LF)),'longitudinal_left':list(map(enc,LL)),'wrong_middle_order_left':list(map(enc,wrong)),'raw_Feynman':enc(GF),'raw_longitudinal':enc(GL),'Gaussian_insertion_unit':str(unit),'combined_phase':str(phase),'angular_factors':factors,'Feynman_residue':str(ff0),'longitudinal_residue':str(fl0),'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'family_extension':'identity_no_extra3','open_line_extra_half':False},start)
