# GFT1: complete gauge–fermion triangle ultraviolet family

QUALIFIED_COMPLETE_GAUGE_FERMION_TRIANGLE_UV_FAMILY. Receipt SHA256
81b7e57cbc44883d057ed50d351014f2497ce60f14ee9340e4e8f6440ab90635.
Scientific/director acceptance NOT_PERFORMED. State113, authority34/39 unchanged.

Both independently organized calculations agree at all23040 left/right
current positions, including zeros, for all45 external total-field directions
and four Lorentz components. This covers FGS1's four outward profiles for this
family; profiles are not a count of independently nonzero amplitudes.

With common g10³ bar_gamma_rho/(16pi²eps), the inverse-fermion-operator pole is

    L_c = -i sum_ab W_ab T_a T_c T_b,  R_c = -(L_c)^T,
    W = eta_H P_H + xi P_M.

There are720 nonzero entries in each chiral current list.696 positions remain
in the left current after its adjoint projection is subtracted. The result
must therefore retain the full matrix current rather than only an adjoint
charge rescaling. All138240 homogeneous-H covariance positions were checked.
Widths remain symbolic with the inherited real-parameter involution.

Primary derives the Gaussian open-line insertion sign, evaluates explicit
barred Clifford matrices and angular moments, and contracts actual raw643-field
Green matrices and ordered spinor triples before changing the external chart.
Replay uses Schur differentiation, independent Gaussian-moment identities and
the weighted double commutator:

    sum_ab W_ab T_a T_c T_b
       = {C_width,T_c}/2 - sum_d C_ad,width(dc) T_d/2.

GFK1's independently measured carrier matrix supplies C_width; scalar-derived
Lie constants supply C_ad,width. Neither route reads an intended source
counterterm or uses a desired Ward cancellation to assign the result.

The Feynman angular factor4/d and longitudinal factor24/[d(d+2)] both have
pole residue1. Their finite-epsilon parts differ and are not discarded as
finite restoration data. Positive temporary IR references establish radial
residue1 without changing physical masses. Three gauge phases and two
fermion numerator phases give-i; the inverse-insertion unit is+1. No
closed-loop half or extra factor of three is present.

Uniform W=wI gives(13/8)w T_c, using45/8 carrier and8 adjoint Casimirs;
zero widths give zero pole for this family. These are verification limits,
not adopted gauge values. Omitted longitudinal terms, wrong middle ordering,
swapped widths and extra half/family multiplicities are detected.

Primary95.6931867s, replay33.7351058s, verifier30.0435166s after imports,
all native exit0.49/18/16 samples have private maxima71159808/61423616/
62275584 bytes, not continuous peaks.600s each,8GiB sampled cap,350MiB
launch floor and16MiB package bound were unexhausted.41 initial/48 validation
bindings and eight exact source copies authenticate the evidence. No frozen
scientific worker or verifier failed. The resumed UI session no longer had
its old terminal handle; the completed native captures and receipt were
recovered without restarting the calculation.

Fresh E4 readiness executed in this logical research turn, native exit0,
steps0,0,0,0,0,2. This was not fresh replay of expensive historical science.
Historical custody remains exit2/seven unresolved references, NOTPASS.

After the calculation freeze, the published BMHV treatment was consulted as
a methodological comparator: [Belusca-Maito et al., arXiv:2004.14398v2](https://arxiv.org/abs/2004.14398v2).
Its distinction between ultraviolet, evanescent and finite restoring terms
supports keeping these obligations separate. Its total linear-gauge vertex
was not used as an isolated-family value or imported into this nonlinear
gauge construction. No finite scheme equivalence is established.

FAV1 and GFT1 now supply two of five quantum-B topology families. The next
necessary pure-gauge input is the cubic-vector family, with its actual action
normalization and both longitudinal placements. The g10 Y² Yukawa-fermion and
scalar-current families remain. Full finite vertex, hatted restoration, QAP,
measure, matter C1 and physical unification remain unqualified. This result
does not promote E5/A5 or alter the original benchmark exclusions,140% singlet
warning, flavor pause, HB1/C5 blocks, quartet failure or historical custody.

Distinct algebraic routes share action, group data, runtime and AI authorship.
Their agreement is internal corroboration, not independent scientific confirmation.
