# GFT1 ordered insertion and weighted-current identity

For physical pp inverse S, an external B insertion gives delta S=-S V_c S.
The one-loop open-line self-energy is -V_a S V_b G_ab. Its derivative in
this family is therefore +V_a S V_c S V_b G_ab. At zero external momenta
the two internal physical-fermion propagators have the same momentum k and
the vector carries -k. The three vertices contribute(-i)^3, two fermion
numerators(-i)^2, giving phase-i after the open-line Gaussian unit is derived.
There is no closed Pfaffian half or flavor factor three.

Using barred rank4 and total integration dimension d, the Feynman numerator
sum_mu gamma_mu bar_slash gamma_rho bar_slash gamma_mu has angular coefficient
4/d. The longitudinal numerator bar_slash^2 gamma_rho bar_slash^2 has
coefficient24/[d(d+2)]. Both residues are1 at d=4. They differ away from4,
so this is a UV-pole statement, not equality of finite evanescent pieces.
The corresponding positive-reference radial UV residues equal1.

Let W=eta_H P_H+xi P_M. Direct contraction at pole order must give the ordered
current sum_ab W_ab T_a T_c T_b, if the independent momentum normalization
agrees; it is computed rather than assigned. The independent algebraic identity
for symmetric W is

    sum_ab W_ab T_a T_c T_b
       = 1/2{C_width,T_c} - 1/2 sum_d C_ad,width(dc) T_d,
    C_width=sum_ab W_ab T_a T_b,
    C_ad,width=-sum_ab W_ab f_a f_b.

It follows by expanding the double commutator, without discarding an
anticommutator or assuming the result purely adjoint. The right current
uses the ordered transposed matrices and the three right-charge signs.

At uniform W=wI the identity becomes w(45/8-8/2)T_c=(13/8)w T_c.
This is a known-limit check of the model generators and normalized kernel,
not a choice of physical width or a substitute for the actual two-width result.
