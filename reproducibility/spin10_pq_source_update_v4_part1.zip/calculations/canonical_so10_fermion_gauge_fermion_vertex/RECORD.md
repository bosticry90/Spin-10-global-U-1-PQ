# GFT1: complete gauge-fermion triangle UV family

Question: what is the complete proper g10³ P-P-B UV pole with the external
gauge insertion on the internal fermion line? FGS1 identifies four outward
H/M profiles in this family. It is a distinct necessary input from FAV1's
nonlinear auxiliary family and the still unmeasured cubic-vector family.

Freeze SMA1 provisional action, actual GFK1 raw/reference BB inverse, physical
pp propagator with barred numerator/full hatted denominator, YCT1 current
matrices and actual C3/plane chart. Retain both real symbolic widths eta_H,xi;
no benchmark gauge value or family/Yukawa parameter is selected. Physical
matter vertices act only on P; sterile mixing stays in its internal inverse.
Family extension is I3, not a closed flavor trace.

Primary derives the open-line inverse-insertion sign by exact exterior Gaussian
integration, retains all four barred-Clifford components and d-dimensional
angular moments, then contracts actual raw Green matrices and ordered
T_internal*T_external*T_internal products before external-plane conversion.

Replay uses a separate Schur/inverse expansion and Gaussian moment/Clifford
identities. It derives the complete current from the weighted double-commutator
identity, actual scalar-derived adjoint Lie constants and GFK1's independently
calculated carrier width matrix. It does not use a required source-pole value.

Separate verifier compares all left/right45x16x16 positions including zeros,
Hermiticity under declared real-width involution, H covariance and the complete
weighted identity. Controls omit longitudinal terms, alter internal ordering,
swap widths or introduce a spurious open-line half/family multiplicity. Check
uniform-width and zero-width limits without adopting either as a gauge choice.
Equal pole factors must not be asserted equal at finite epsilon.

The Gaussian derivative is +V S V_external S V G. The gauge/fermion phases
and dimensional pole coefficients must be independently derived, not fitted.
Positive temporary IR mass separates the UV residue only; finite evanescent,
IR and momentum-dependent amplitudes are not set zero. Independent A at fixed
B has no matter-line external vertex; the separate A auxiliary family remains.

Freeze eight sources/copies and inputs before three sequential observed
workers:600s after imports each,8GiB sampled-private cap,350MiB launch floor,
16MiB package cap. Run fresh delegated E4 readiness this goal turn, preserving
custody exit2/seven NOTPASS. Failure or exhaustion has no qualified receipt;
routine corrections retain failed sources/captures and use a frozen continuation.

Ceiling: this complete bare-action marginal UV family under the explicit
provisional reference assumptions, not the full fermion/gauge vertex, source-free
restoration, finite QAP/measure/contact construction, finite matter C1, E5/A5 or
physical unification. All old evidence, exclusions, flavor/HB1/C5 boundaries,
main and sole state113/34of39 remain. No scheme, foundation or physical point
is adopted. Shared physical premises, action, data, software/runtime and AI
author limit independence. RESULT/receipt will record resources and next action.
