"""GFT1 Schur/Gaussian momentum route and complete weighted Casimir identity."""
from data import *
start=begin('replay')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
F,dx,a,b,c,X,Y,t=s.symbols('F dx a b c X Y t',nonzero=True);Schur=s.det(s.Matrix([[dx,a*X],[b*Y,F+t*c]]))/(F+t*c);unit=s.simplify(s.diff(Schur-dx,t).subs(t,0)/(a*b*c*X*Y/F**2));assert unit==1;phase=unit*(-s.I)**3*(-s.I)**2
# Clifford identity sum_mu gamma_mu slash gamma_rho slash gamma_mu
# =2*bar_k^2 gamma_rho-4*k_rho slash in barred rank4. Gaussian
# second moments give(2*4-4)/d. Fourth radial moment gives24/[d(d+2)].
J=s.symbols('J0:4');Z=s.exp(sum(x*x for x in J)/4);at0=dict.fromkeys(J,0);n2=sum(s.diff(Z,x,2).subs(at0) for x in J);k0sq=s.diff(Z,J[0],2).subs(at0);n4=sum(s.diff(Z,x,2,y,2).subs(at0) for x in J for y in J);d=s.Symbol('d');ff=s.factor((2*n2-4*k0sq)/(d/2));fl=s.factor(n4/(d*(d+2)/4));ff0=ff.subs(d,4);fl0=fl.subs(d,4)
eps,m2=s.symbols('epsilon m2',positive=True);r2=s.gamma(1+eps)*m2**(-eps)*(2-eps)/2;r4=s.gamma(1+eps)*m2**(-eps)*(3-eps)*(2-eps)/6;assert r2.subs(eps,0)==r4.subs(eps,0)==1
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,yc['Tminus']));H=dec(yc['H_new']);PH=H*H.T;W=xi*s.eye(45)+(eta-xi)*PH;f={(a,b,c):s.sympify(v) for a,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']};FA=[s.SparseMatrix(45,45,{(c,b):v for (aa,b,c),v in f.items() if aa==a}) for a in range(45)];CA=tidy(-sum((A*A for A in FA),s.zeros(45)));CWA=tidy(-sum((v*FA[a]*FA[b] for (a,b),v in s.SparseMatrix(W).todok().items()),s.zeros(45)))
kin=packed(CAL/'canonical_so10_fermion_gauge_kinetic_pole/replay_tables.json.gz');CW=dec(kin['gauge_kinetic_left']);CF=dec(kin['full_internal_Casimir']);L=[];R=[]
for c,A in enumerate(T):
 Fpart=(CF*A+A*CF-sum((CA[e,c]*T[e] for e in range(45) if CA[e,c]),s.zeros(16)))/2
 Wpart=(CW*A+A*CW-sum((CWA[e,c]*T[e] for e in range(45) if CWA[e,c]),s.zeros(16)))/2
 current=tidy(phase*(ff0*Fpart+fl0*(Wpart-Fpart)));L.append(current);R.append(-current.T)
finish('replay',{'method':'Schur_insertion_Gaussian_moments_and_weighted_double_commutator_identity','loop_left':list(map(enc,L)),'loop_right':list(map(enc,R)),'C_width':enc(CW),'adjoint_width_Casimir':enc(CWA),'adjoint_total_Casimir':enc(CA),'carrier_total_Casimir':enc(CF),'Gaussian_insertion_unit':str(unit),'combined_phase':str(phase),'angular_factors':[[str(ff),str(fl)]]*4,'Feynman_residue':str(ff0),'longitudinal_residue':str(fl0),'positive_IR_radial_residues':['1','1'],'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'family_extension':'identity_no_extra3','open_line_extra_half':False},start)
