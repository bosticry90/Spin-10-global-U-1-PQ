"""GFT1 complete two-route coefficient gate and known-limit/adversarial checks."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
for key in ['Gaussian_insertion_unit','combined_phase','Feynman_residue','longitudinal_residue']:assert P[key]==R[key],key
assert P['Gaussian_insertion_unit']=='1' and P['combined_phase']=='-I' and P['Feynman_residue']==P['longitudinal_residue']=='1'
for a,b in zip(P['angular_factors'],R['angular_factors']):
 for x,y in zip(a,b):assert s.simplify(s.sympify(x)-s.sympify(y))==0
assert s.simplify(s.sympify(P['angular_factors'][0][0])-s.sympify(P['angular_factors'][0][1]))!=0
L=list(map(dec,P['loop_left']));RR=list(map(dec,P['loop_right']))
for a,b,c,d in zip(L,map(dec,R['loop_left']),RR,map(dec,R['loop_right'])):zero(a-b);zero(c-d);zero(c+a.T)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));H=dec(Y['H_new']);C=dec(R['carrier_total_Casimir']);zero(C-s.Rational(45,8)*s.eye(16));zero(dec(R['adjoint_total_Casimir'])-8*s.eye(45));w=s.Symbol('w')
for c,a in enumerate(L):
 zero(a.subs({eta:w,xi:w})+s.I*s.Rational(13,8)*w*T[c]);zero(a.subs({eta:0,xi:0}));zero(a+a.conjugate().T.xreplace({s.conjugate(eta):eta,s.conjugate(xi):xi}))
controls={'omit_longitudinal':any(tidy(a-b).todok() for a,b in zip(L,map(dec,P['Feynman_left']))),'wrong_middle_order':any(tidy(a-b).todok() for a,b in zip(L,map(dec,P['wrong_middle_order_left']))),'swap_widths':any(tidy(a-a.xreplace({eta:xi,xi:eta})).todok() for a in L),'extra_half_or_family3':any(a!=a/2 and a!=3*a for a in L)};assert all(controls.values())
f={(a,b,c):s.sympify(v) for a,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']};FH=[s.SparseMatrix(45,45,{(c,b):s.simplify(sum(H[a,h]*f.get((a,b,c),0) for a in range(45) if H[a,h])) for b in range(45) for c in range(45)}) for h in range(12)]
for h,Fh in enumerate(FH):
 th=sum((H[a,h]*T[a] for a in range(45) if H[a,h]),s.zeros(16))
 for c,a in enumerate(L):zero(th*a-a*th-s.I*sum((Fh[d,c]*L[d] for d in range(45) if Fh[d,c]),s.zeros(16)))
adj=s.Matrix(45,45,lambda c,d:s.simplify(s.trace(T[d]*L[c])/(-2*s.I)));nonadj=[tidy(L[c]+s.I*sum((adj[c,d]*T[d] for d in range(45) if adj[c,d]),s.zeros(16))) for c in range(45)]
for D in [P,R]:assert D['new_one_loop_vertex_families']==1 and D['new_two_loop_integrals']==0 and D['family_extension']=='identity_no_extra3' and not D['open_line_extra_half']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_GAUGE_FERMION_TRIANGLE_UV_FAMILY','elapsed_after_imports':time.perf_counter()-start,'total_chiral_current_positions_compared':2*45*16**2,'all_Lorentz_copies_checked':4,'H_covariance_positions_checked':12*45*16**2,'left_nonzero_positions':sum(len(a.todok()) for a in L),'right_nonzero_positions':sum(len(a.todok()) for a in RR),'nonadjoint_left_positions':sum(len(a.todok()) for a in nonadj),'adjoint_projection_map':enc(adj),'controls':controls,'Feynman_residue':'1','longitudinal_residue':'1','combined_phase':'-I','uniform_width_coefficient':'13/8','uniform_and_zero_width_limits_checked':True,'finite_angular_factors_distinct':True,'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'full_B_vertex_completed':False,'finite_QAP_measure_or_matching_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
