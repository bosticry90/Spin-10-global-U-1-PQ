# FSV1 V3: use the literal compact numeric jet encoding

V2 passes the explicit physical field-name inventory, then fails before a
support table at the guessed d0-style jet decoder. The actual portable GF
projection encodes first jets as C10__0, not C10__d0. A complete suffix scan
found exactly0,1,2,3 (1619 occurrences each). Preserve both failed censuses,
sources/copies/captures and controller failures; neither produced a table or
qualified receipt, and both old verifiers were NOT_LAUNCHED.

V3 decodes the documented compact numeric suffix as an ordinary derivative
multiindex and explicitly rejects characters outside0..3. The independent
gate counts those numeric labels by its own parser. Derivative counts and
dimension requirements are unchanged; unknown encodings are not ignored.
The frozen input bytes, action, field types, graph classes and controls remain.

Freeze this record and census_v3,verify_v3,run_v3/copies with original and V2
failure bindings before computation. Recompute the census; no prior table
exists to reuse. Use the same600s/8GiBsampled/350MiBfloor/16MiB limits.
The two historical-schema mistakes are AI implementation failures, not
scientific discrepancies. Their correction does not supply a PASS until the
complete new census and independent gate actually finish. No physical input,
acceptance requirement, state/authority, protected stage or external action
changes. Shared action/semantic assumptions/software/AI author remain.
