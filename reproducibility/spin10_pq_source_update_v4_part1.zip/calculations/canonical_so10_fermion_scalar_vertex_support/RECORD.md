# FSV1: complete leading UV support of the proper fermion-scalar vertex

Basec71e579d03ed390eed66e3e090941b548ed9ba5b/main/30332 tracked blobs.
GFK1 recovered actual two-width propagators. Before gauge-Yukawa poles,
determine whether the nonlinear GF introduces marginal scalar-auxiliary
vertices through its mixed B/Lambda propagator. Inspect actual action, not
an imported linear-gauge formula. A complete support exclusion can avoid
unnecessary loops; a genuine new family must instead be retained.

Freeze live AGENTS/CHARTER/state113/34of39,V488/local/solo conventions;
complete34-term physical executable AST/receipt; literal GF projection in
portable_dh_v1 inputs/manifest and its qualified joint-domain receipt;
SMA1 physical current/Yukawa action, YCT1 full maps/covariance, GFK1 reference
and pole receipt, YPP1 pure-Yukawa pole receipt. No old calculation/receipt,
policy or physical point changes. Do not reopen paused flavor or HB1/C5.

Target: proper1PI one-loop2F+1x local dimensionless UV vertex, dimF=3/2,
dimx=dimB=dimC=dima=1,dimLambda=2. Zero ordinary/background/source fields
apart from external legs; no numerical mass/Yukawa values. All scalar
directions and actual symbolic family matrices remain. No amplitude is
assigned from a desired Ward cancellation. Physical vertices are FFB/FFx,
with no matter quartic, ghost or auxiliary vertex, from the complete SMA1
action. The actual leading references allow FF,BB,BL/LB,xx,Ca/aC and no LL
or Bx. Constant GF Lambda-x and vacuum/mass insertions have positive mass
dimension; classify them instead of silently deleting them from the theory.

Native calculation: expand the typed physical AST into support monomials
(field roles,derivative count,parameter dimension). Parse every literal GF
row with distinct scalar/ghost/auxiliary roles and jets, keeping the complete
profile counts and scalar-containing subset. Drop backgrounds only for this
zero-background target. Establish whether Lxx/LBx marginal supports exist.
No mere table absence is a zero without this complete density scan.

For a1PI one-loop graph with E3 and vertices of valence>=3,
sum_v(valence_v-2)=3. Hence only three cubic vertices or one cubic plus one
quartic are possible. A single matter cubic in the latter case has both
external fermions and one internal boson bridge, so cannot be1PI. For three
cubic vertices a1PI loop is a triangle, with one external leg per vertex.
Explicitly enumerate all typed internal port pairings in that triangle using
every actual marginal bosonic cubic support. Require connectedness,1PI,
L=1,correct external types and homogeneous UV degree0. Retain the two
external-fermion orientations as distinct support classes, not multiplicities
of an amplitude. Color support remains a candidate, never a nonzero pole.

Separate gate: reconstruct physical support by a symbolic generating
polynomial rather than tuple products; independently classify all literal
GF rows with mass/jet dimensions. Rebuild the triangles from their three
edge endpoint types and actual bosonic cubic ports; compare the complete
class set. Independently prove the valence bound/bridge exclusion. Controls
add a synthetic marginal Lxx or LBx only to the diagnostic catalogue: the
mixed reference must then create extra candidate triangles. Suppressing BL
must remove those diagnostic families. No synthetic vertex is added to the
action. Removing FFx,FFB or Bxx must detect missing relevant classes.

The external Phi54 and S2 maps are zero in YCT1; the actual gauge action is
block diagonal on real scalar sectors. State the resulting support boundary
without claiming finite effective Phi/S Yukawa amplitudes vanish. Potentials,
VVS and mass/VEV insertions have positive coefficient dimensions and cannot
supply a dimensionless local pole without forbidden inverse masses. Proper
vertices exclude reducible tadpole bridges; tadpole normalization remains.

The standard gauge-Yukawa diagram structure in Belusca-Maito et al.,
arXiv2004.14398v2 Sec5.2.2, https://arxiv.org/pdf/2004.14398 is a comparator,
not a pole input or proof for nonlinear GF. Possible outcomes: complete
candidate support; additional actual auxiliary class; or underdefined input/
resource incomplete. No new loop integral, coefficient tensor, finite
normalization, source/evanescent/QAP/restoration or complete forest is claimed.

Freeze four sources/copies and inputs before census then separate gate.
Each600s after imports,8GiB sampled private cap,350MiB launch floor,16MiB
package. No agents. Preserve failures, version corrections. Gate agreement
shares action/typed power counting/data/Python/AI author, not external physics
validation. Authority34/39 unchanged; scientific/director acceptance
NOT_PERFORMED, E5/A5/finite matter C1/unification unqualified. All prior
failures and negative physical points remain; no adoption or external action.
