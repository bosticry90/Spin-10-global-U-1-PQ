"""FSV1 independent generating-polynomial/GF scan and edge-type reconstruction."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import product
import gzip,json,os,re,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
C=json.loads(gzip.decompress((HERE/'census_tables.json.gz').read_bytes()));B,X,J,D=s.symbols('B X jets massdim')
def polynomial(n):
 t=n['node']
 if t=='Field':
  assert n['name']=='B' or n['name'].startswith('x_');return B if n['name']=='B' else X
 if t=='Parameter':return D**int(n['mass_dimension'])
 if t in ['ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return s.S.One
 if t=='PartialDerivative':return J*polynomial(n['argument'])
 if t=='LocalActionTerm':return polynomial(n['density'])
 if t in ['LorentzContraction','GroupContraction']:return polynomial(n.get('expression',n.get('argument')))
 if t=='Add':return sum(polynomial(v) for v in n['terms'])
 if t=='OrderedProduct':return s.prod(polynomial(v) for v in n['factors'])
 raise AssertionError(t)
ast=read(PK/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');profiles={}
for term in ast['local_terms']:
 rows=[]
 for (nb,nx,nj,nd),coef in s.Poly(polynomial(term),B,X,J,D).terms():
  assert coef>0;rows.append((tuple(['B']*nb+['x']*nx),nj,nd))
 profiles[term['term_id']]=sorted(rows)
assert json.loads(json.dumps(profiles,sort_keys=True))==C['physical_profiles']
dimensions={'B':1,'x':1,'L':2,'c':1,'a':1,'A':1};gfc=Counter();gfs=Counter()
gf=json.loads(gzip.decompress((ROOT/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))['gauge_fixing_density']
def decode(n):
 pieces=n.split('__');name=pieces[0];suffix=''.join(pieces[1:]);numbers=re.findall('[0-3]',suffix);assert re.sub('d|[0-3]|_','',suffix)==''
 if name.startswith('x_'):r='x'
 elif name.startswith(('bar','ub')):r='a'
 elif name.startswith(('Lambda','L','b')):r='L'
 elif name[0] in ['B','C','A']:r={'B':'B','C':'c','A':'A'}[name[0]]
 else:raise AssertionError(name)
 return r,len(numbers)
for row in gf:
 a=[decode(n) for n in row['word']];pp=tuple(sorted(r for r,j in a));jets=sum(j for r,j in a);md=4-sum(dimensions[r] for r in pp)-jets;assert md>=0
 gfc[pp,jets,md]+=1
 if 'x' in pp:gfs[pp,jets,md]+=1
def table(c):return [{'ports':list(p),'jets':j,'coefficient_dimension':d,'positions':n} for (p,j,d),n in sorted(c.items())]
assert C['GF_positions']==len(gf) and C['GF_profiles']==table(gfc) and C['GF_scalar_profiles']==table(gfs)
allp=set(gfc)
for rows in profiles.values():allp.update(rows)
assert all(len(p)<=4 for p,j,d in allp)
boson={p:j for p,j,d in allp if len(p)==3 and d==0 and 'A' not in p};matter={('B','F','F'):0,('F','F','x'):0};vs={**boson,**matter}
poss=[(('F','F'),1),(('B','B'),2),(('B','L'),1),(('L','B'),1),(('x','x'),2),(('c','a'),2),(('a','c'),2)]
def triangle(vdict,ep):
 out=set()
 for (e01,p01),(e12,p12),(e02,p02) in product(ep,repeat=3):
  ports=[tuple(sorted(['F',e01[0],e02[0]])),tuple(sorted(['F',e01[1],e12[0]])),tuple(sorted(['x',e02[1],e12[1]]))]
  if all(p in vdict for p in ports):
   assert 4-p01-p12-p02+sum(vdict[p] for p in ports)==0
   out.add(tuple(''.join(p) for p in ports))
 return sorted(out)
actual=triangle(vs,poss);assert json.loads(json.dumps(actual))==C['triangle_classes']
expected={('BFF','BFF','FFx'),('FFx','FFx','FFx'),('BFF','FFx','Bxx'),('FFx','BFF','Bxx')};assert set(actual)==expected
assert [(a,b) for a in range(4) for b in range(3) if a+2*b==3]==[(1,1),(3,0)]
assert C['quartic_matter_vertices']==0
# With one cubic matter vertex and one bosonic quartic, both external F are
# on the cubic. Its sole remaining bosonic port is a bridge: never1PI.
for added in [('L','x','x'),('B','L','x')]:
 assert added not in boson
 augmented=triangle({**vs,added:0},poss);extra=[list(p) for p in augmented if p not in actual]
 assert extra and C['synthetic_auxiliary_controls'][''.join(added)]['extra_classes']==extra
 noBL=triangle({**vs,added:0},[(e,p) for e,p in poss if 'L' not in e]);assert noBL==actual
for removed in [('B','F','F'),('F','F','x'),('B','x','x')]:assert triangle({p:j for p,j in vs.items() if p!=removed},poss)!=actual
scalaraux=[v for (p,j,d),v in gfs.items() if 'L' in p];assert scalaraux and all(p==('L','x') and d==1 for p,j,d in gfs if 'L' in p)
yct=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_yukawa_carrier_transport/primary_tables.json.gz').read_bytes()))
supports=[{row[1] for row in yct[key]['entries']} for key in ['B10','B126']];assert supports==[set(range(306,326)),set(range(54,306))]
sma=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_sterile_matter_action/primary_tables.json.gz').read_bytes()))
assert set(sma['coefficients'])=={*(f'current_T_{i}' for i in range(4)),*(f'current_Ttranspose_{i}' for i in range(4)),*(f'kin_bar_{i}' for i in range(4)),'mass_anti','mass_holo','mix_hat_4','mix_hat_5'}
for term in ast['local_terms']:
 if not term['term_id'].startswith('kinetic_'):continue
 stack=[term];names=set()
 while stack:
  z=stack.pop()
  if isinstance(z,dict):
   if z.get('node')=='Field' and z['name'].startswith('x_'):names.add(z['name'])
   stack.extend(z.values())
  elif isinstance(z,list):stack.extend(z)
 assert names=={'x_'+term['scalar_sector']}
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_MARGINAL_PROPER_FERMION_SCALAR_VERTEX_SUPPORT','elapsed_after_imports':time.perf_counter()-start,
 'physical_terms_scanned':len(profiles),'GF_positions_scanned':len(gf),'GF_scalar_profiles':table(gfs),'actual_triangle_classes':[list(v) for v in actual],
 'marginal_Lxx_or_LBx_vertices':0,'mixed_reference_auxiliary_control_sensitive':True,'quartic_matter_vertices':0,'cubic_plus_quartic_onePI_excluded':True,
 'positive_dimension_insertions_excluded_only_from_local_dimensionless_UV_pole':True,'proper_external_scalar_Yukawa_carriers':['phi20','Sigma252'],
 'other56_directions_not_claimed_zero_finite_amplitudes':True,'new_loop_integrals':0,'pole_coefficients_measured':False,'gauge_Yukawa_vertex_poles_or_full_forest_qualified':False,
 'finite_scheme_measure_phase_or_QAP_qualified':False,'numerical_flavor_or_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
