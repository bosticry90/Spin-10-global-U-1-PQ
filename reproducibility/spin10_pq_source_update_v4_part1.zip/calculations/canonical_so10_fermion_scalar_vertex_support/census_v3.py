"""FSV1 literal GF/physical support and connected typed triangle enumeration."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import product
import gzip,json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
for p,h in read(HERE/'continuation_preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
def typed(n):
 t=n['node']
 if t=='Field':
  assert n['name'] in ['B','x_Phi','x_Sigma','x_phi','x_S','Phi','Sigma','SigmaBar','phi','phiBar','S','SBar']
  return {(('B' if n['name']=='B' else 'x',),0,0)}
 if t=='Parameter':return {((),0,int(n['mass_dimension']))}
 if t in ['ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return {((),0,0)}
 if t=='PartialDerivative':return {(p,j+1,d) for p,j,d in typed(n['argument'])}
 if t=='LocalActionTerm':return typed(n['density'])
 if t in ['LorentzContraction','GroupContraction']:return typed(n.get('expression',n.get('argument')))
 if t=='Add':return set().union(*(typed(v) for v in n['terms']))
 if t=='OrderedProduct':
  out={((),0,0)}
  for f in n['factors']:out={(tuple(sorted(p+q)),j+k,d+e) for p,j,d in out for q,k,e in typed(f)}
  return out
 raise AssertionError(t)
physical=read(PK/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');physical_profiles={r['term_id']:sorted(typed(r)) for r in physical['local_terms']};assert len(physical_profiles)==34
dim={'B':1,'x':1,'L':2,'c':1,'a':1,'A':1,'F':1.5}
def role(n):
 base,_,suf=n.partition('__');assert not suf or re.fullmatch('[0-3]+',suf);j=len(suf)
 if base.startswith('x_'):return 'x',j
 for a,b in [('bar','a'),('ub','a'),('L','L'),('b','L'),('B','B'),('C','c'),('A','A')]:
  if base.startswith(a):return b,j
 raise AssertionError(base)
gf=json.loads(gzip.decompress((ROOT/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))['gauge_fixing_density'];count=Counter();scalar=Counter()
for row in gf:
 rr=[role(n) for n in row['word']];ports=tuple(sorted(r for r,j in rr));jets=sum(j for r,j in rr);cd=4-sum(dim[r] for r in ports)-jets;assert cd>=0
 count[ports,jets,cd]+=1
 if 'x' in ports:scalar[ports,jets,cd]+=1
all_profiles=set(count)
for rows in physical_profiles.values():
 for ports,jets,cd in rows:assert cd+jets+sum(dim[r] for r in ports)==4;all_profiles.add((tuple(ports),jets,cd))
boson={p:j for p,j,cd in all_profiles if len(p)==3 and cd==0 and 'A' not in p};assert all(len({j for p1,j,cd in all_profiles if p1==p and cd==0})==1 for p in boson)
vertices=[(('B','F','F'),0),(('F','F','x'),0)]+list(boson.items())
edges={tuple(sorted(k)):v for k,v in [(('F','F'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('c','a'),2)]}
def pairs(ports):
 if not ports:yield [];return
 a=ports[0]
 for k,b in enumerate(ports[1:],1):
  if tuple(sorted((a[1],b[1]))) not in edges:continue
  for rest in pairs(ports[1:k]+ports[k+1:]):yield [(a,b)]+rest
def connected(es,skip=None):
 seen={0}
 while True:
  prev=set(seen)
  for k,(a,b) in enumerate(es):
   if k==skip:continue
   if a[0] in seen:seen.add(b[0])
   if b[0] in seen:seen.add(a[0])
  if seen==prev:return len(seen)==3
def collect(vs,edge_catalog):
 global edges
 old=edges;edges=edge_catalog;out=set()
 try:
  for xyz in product(vs,repeat=3):
   rem=[];valid=True
   for i,ext in enumerate(['F','F','x']):
    pp=list(xyz[i][0])
    if ext not in pp:valid=False;break
    pp.remove(ext);rem.extend((i,t,k) for k,t in enumerate(pp))
   if not valid:continue
   for es in pairs(rem):
    if not connected(es) or any(not connected(es,k) for k in range(3)):continue
    degree=4-sum(edges[tuple(sorted((a[1],b[1])))] for a,b in es)+sum(v[1] for v in xyz)
    assert degree==0
    out.add(tuple(''.join(v[0]) for v in xyz))
 finally:edges=old
 return sorted(out)
classes=collect(vertices,edges);synthetic={}
for p in [('L','x','x'),('B','L','x')]:
 vv=vertices+[(p,0)];extra=collect(vv,edges);noBL=collect(vv,{k:v for k,v in edges.items() if k!=('B','L')})
 synthetic[''.join(p)]={'extra_classes':[v for v in extra if v not in classes],'classes_without_BL':noBL}
for p in [('L','x','x'),('B','L','x')]:assert p not in boson
def rows(c):return [{'ports':list(p),'jets':j,'coefficient_dimension':d,'positions':n} for (p,j,d),n in sorted(c.items())]
out={'physical_profiles':physical_profiles,'GF_positions':len(gf),'GF_profiles':rows(count),'GF_scalar_profiles':rows(scalar),'marginal_bosonic_cubics':[{'ports':list(p),'jets':j} for p,j in sorted(boson.items())],
 'triangle_classes':classes,'synthetic_auxiliary_controls':synthetic,'quartic_matter_vertices':0,'new_loop_integrals':0,'pole_coefficients_measured':False,'full_forest_or_QAP_qualified':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'census_v3_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'role':'census_v3','elapsed_after_imports':time.perf_counter()-start,'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
