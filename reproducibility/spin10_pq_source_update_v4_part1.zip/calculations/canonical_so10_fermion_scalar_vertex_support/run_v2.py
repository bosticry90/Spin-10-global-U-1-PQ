"""FSV1 corrected explicit AST scalar names, preserve original failed census."""
from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-scalar-vertex-support-v1-2026-10-22')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='c71e579d03ed390eed66e3e090941b548ed9ba5b'
for n,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
assert read(HERE/'census_capture.json')['execution_state']=='FAILED' and read(HERE/'census_capture.json')['exit_code']==1
assert read(HERE/'controller_failure.json')['last_role']=='census' and not (HERE/'census_tables.json.gz').exists() and not (HERE/'validation_receipt.json').exists()
bind={}
for n in ['CORRECTION_V2.md','census_v2.py','verify_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 bind[str(p)]=digest(p);bind[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
for n in ['preparation.json','census.py','census.py.source.txt','census_capture.json','controller_failure.json']:bind[str(HERE/n)]=digest(HERE/n)
dump(HERE/'continuation_preparation_v2.json',{'schema':'FSV1_CONTINUATION_PREPARATION_V2','input_sha256':bind,'original_census_execution':'FAILED','original_verifier':'NOT_LAUNCHED',
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
def execute(label):
 cap=capture([sys.executable,'-B',str(HERE/(label+'.py'))]);dump(HERE/(label+'_capture.json'),cap);dump(CONTROL/(label+'_full_capture.json'),cap)
 if cap['exit_code']:print(cap['stdout_and_stderr'],flush=True)
 assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples'] and max(v['private_bytes'] for v in cap['all_resource_samples'])<=8*1024**3
 rr=[json.loads(v[7:]) for v in cap['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rr)==1;r=rr[0];assert r['elapsed_after_imports']<600
 if label=='census_v2':
  blob=(HERE/'census_v2_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256'];dump(HERE/'census_v2_result.json',r)
 else:
  assert r['status']=='QUALIFIED_COMPLETE_MARGINAL_PROPER_FERMION_SCALAR_VERTEX_SUPPORT';dump(HERE/'validation_receipt_v2.json',r)
 assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
 print(label,'COMPLETED',r['elapsed_after_imports'],flush=True)
label=None
try:
 label='census_v2';execute(label)
 bind=dict(read(HERE/'preparation.json')['input_sha256'])
 for p in HERE.iterdir():
  if p.is_file():bind[str(p)]=digest(p)
 dump(HERE/'validation_preparation_v2.json',{'schema':'FSV1_VALIDATION_PREPARATION_V2','input_sha256':bind,'scientific_acceptance':'NOT_PERFORMED'})
 label='verify_v2';execute(label)
except BaseException:
 dump(HERE/'controller_failure_v2.json',{'execution_state':'FAILED','last_role':label,'traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
