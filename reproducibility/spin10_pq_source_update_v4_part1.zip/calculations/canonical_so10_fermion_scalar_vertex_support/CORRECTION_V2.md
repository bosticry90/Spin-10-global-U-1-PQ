# FSV1 V2: explicit scalar names in the physical AST

The original census failed at its restricted Field-name parser before producing
a support table. Kinetic terms use x_Phi,x_Sigma,x_phi,x_S, while the potential
uses the already declared tensor names Phi,Sigma,SigmaBar,phi,phiBar,S,SBar.
All are dimension-one scalar roles in the same frozen real-coordinate theory.
The actual field-name inventory was read from all34 terms after the failure.

V2 explicitly accepts this finite name set as scalar, rather than treating an
arbitrary unknown field as scalar. No action, parameter, embedding, dimensional
rule or expected graph class changes. The independent generating-polynomial
gate receives the same explicit field-name typing correction. Its distinct
method and all complete GF/graph/omission controls remain required.

Preserve original record/sources/copies, FAILED census capture and controller
failure. No original table or qualified receipt exists; verifier NOT_LAUNCHED.
Freeze this record, census_v2,verify_v2,run_v2 and their copies plus original
failure bytes before execution. CensusV2 recomputes from the original immutable
inputs. Validation is separately frozen after completion. Same600s/8GiBsampled/
350MiBfloor/16MiB bounds, no agents or acceptance relaxation. No physical
adoption, authority/state change, flavor work or external action.
