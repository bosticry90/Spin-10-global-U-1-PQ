"""FSV1 freeze prospective inputs, observe census, then independent support gate."""
from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-scalar-vertex-support-v1-2026-10-22')
BASE='c71e579d03ed390eed66e3e090941b548ed9ba5b';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PK));from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind={}
def add(p,h=None):
 p=p.resolve();v=digest(p)
 if h is not None:assert v==h,str(p)
 bind[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V488.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
 'tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/manifest.json']:add(ROOT/n)
for n in ['export_a10_e5_antighost_vector.py','frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json','frozen_a10_executable_reconciliation/validation_receipt.json']:add(PK/n)
for folder,names in {
 'canonical_so10_joint_born_ir_trace_domain':['RESULT.md','validation_receipt.json'],
 'canonical_so10_sterile_matter_action':['ACTION_V1.md','primary_tables.json.gz','validation_receipt.json'],
 'canonical_so10_yukawa_carrier_transport':['RESULT.md','primary_tables.json.gz','validation_receipt.json'],
 'canonical_so10_fermion_gauge_kinetic_pole':['RESULT.md','validation_receipt.json'],
 'canonical_so10_yukawa_polarization_poles':['RESULT.md','validation_receipt_v2.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
for n,h in {
 'project_state.json':'d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8',
 'tools/portable_dh_v1/inputs.json.gz':'7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb',
 'calculations/canonical_so10_fermion_gauge_kinetic_pole/validation_receipt.json':'d29b95ea3d6d463f765fe940a1cc25a89cd62d04bf0ba8e0efc94157f8ffd376',
 'calculations/canonical_so10_yukawa_carrier_transport/validation_receipt.json':'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b'}.items():add(ROOT/n,h)
for n in ['RECORD.md','census.py','verify.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30332
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
dump(HERE/'preparation.json',{'schema':'FSV1_PREPARATION','base_commit':BASE,'input_sha256':bind,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
def execute(label):
 cap=capture([sys.executable,'-B',str(HERE/(label+'.py'))]);dump(HERE/(label+'_capture.json'),cap);dump(CONTROL/(label+'_full_capture.json'),cap)
 if cap['exit_code']:print(cap['stdout_and_stderr'],flush=True)
 assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples'] and max(v['private_bytes'] for v in cap['all_resource_samples'])<=8*1024**3
 rr=[json.loads(v[7:]) for v in cap['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rr)==1;r=rr[0];assert r['elapsed_after_imports']<600
 if label=='census':
  blob=(HERE/'census_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256'];dump(HERE/'census_result.json',r)
 else:
  assert r['status']=='QUALIFIED_COMPLETE_MARGINAL_PROPER_FERMION_SCALAR_VERTEX_SUPPORT';dump(HERE/'validation_receipt.json',r)
 assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
 print(label,'COMPLETED',r['elapsed_after_imports'],flush=True)
label=None
try:
 label='census';execute(label)
 bind=dict(read(HERE/'preparation.json')['input_sha256'])
 for p in HERE.iterdir():
  if p.is_file():bind[str(p)]=digest(p)
 dump(HERE/'validation_preparation.json',{'schema':'FSV1_VALIDATION_PREPARATION','input_sha256':bind,'scientific_acceptance':'NOT_PERFORMED'})
 label='verify';execute(label)
except BaseException:
 dump(HERE/'controller_failure.json',{'execution_state':'FAILED','last_role':label,'traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
