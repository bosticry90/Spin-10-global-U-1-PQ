# FSV1: complete proper Yukawa-vertex UV support has four oriented classes

The leading dimensionless one-loop2F+1scalar vertex has four candidate
support classes. There is no additional marginal scalar/auxiliary class
from the actual nonlinear gauge fixing. Three gauge classes remain to be
calculated; the pure-Yukawa class already has the YPP1 UV zero. This is a
complete support result in the declared local UV domain, not a new pole
measurement or a complete counterterm action.

Receipt `validation_receipt_v3.json`, SHA-256
`cd3cce0713743819ff040a9d2c91bb886fbe6f48d747dfe25cd494446d8bf3c6`, has status
`QUALIFIED_COMPLETE_MARGINAL_PROPER_FERMION_SCALAR_VERTEX_SUPPORT`.
Scientific/director acceptance NOT_PERFORMED; authority34/39 unchanged.

## The nonlinear gauge-fixing question is settled in scope

All34 physical executable terms and all33,092 literal gauge-fixing density
positions were scanned. The only scalar-bearing GF profiles are

| Profile | Density positions | Ordinary jets | Coefficient mass dimension |
| --- | ---: | ---: | ---: |
| Lambda*x | 432 | 0 | 1 |
| antighost*ghost*x | 6,688 | 0 | 1 |

There is no marginal Lambda*x*x or Lambda*B*x vertex. The scalar/auxiliary
bilinear remains a real action contribution. Its positive coefficient
dimension prevents it from supplying this dimensionless local vertex pole;
it is not deleted from the theory or from finite/mass calculations.

The actual marginal bosonic cubic supports at zero external background are
BBB with one derivative, B*scalar*scalar with one derivative, BB*Lambda,
B*antighost*ghost with one derivative and Lambda*antighost*ghost. The last
three do not produce an extra proper2F+scalar triangle with the actual
matter vertices. SMA1's complete affine operator basis has only FFB and
FFscalar interactions, with no matter quartic or direct ghost/auxiliary
matter vertex.

The physical action scan retains all potential profiles and parameter
dimensions. Potential cubics, VVS terms after a vacuum shift, mass/VEV
insertions and the GF scalar bilinear have positive mass dimension. In this
local polynomial UV problem they lower the superficial degree below zero;
inverse masses cannot restore a dimensionless pole. Finite amplitudes and
reducible tadpole bridges require their own treatment.

## Completeness and the remaining classes

For a1PI one-loop graph with three external legs and interaction valences
at least3, `sum_v(valence_v-2)=3`. The only possibilities in this action are
three cubics or one cubic with one quartic. There is no fermion quartic.
In the latter case both external fermions must be on the matter cubic;
its sole remaining internal bosonic edge is a bridge. That graph is1PR,
so it is outside the proper vertex.

Three cubic vertices in a1PI one-loop graph form a triangle, with one
external leg at each vertex. The full typed pairing enumeration, including
BB,BL/LB,scalar,fermion and ghost edges, gives exactly

| Vertex at external F1 | Vertex at external F2 | Vertex at external scalar | Status |
| --- | --- | --- | --- |
| FFB | FFB | FFscalar | Gauge exchange; coefficient unmeasured |
| FFB | FFscalar | B*scalar*scalar | Gauge/scalar branch; coefficient unmeasured |
| FFscalar | FFB | B*scalar*scalar | Opposite branch; coefficient unmeasured |
| FFscalar | FFscalar | FFscalar | Pure Yukawa; YPP1 UV zero reused |

The two scalar-current branches retain distinct external-fermion orientations.
These are support classes, not amplitude multiplicities or independently
nonzero model coefficients. Bosonic type support is deliberately conservative:
representation contractions may produce additional zeros when measured.

YCT1's actual maps have scalar support only in phi20 and Sigma252. The actual
kinetic AST preserves each scalar sector, so gauge scalar-current transport
does not create a leading pole in the other56 directions. This statement
does not exclude finite effective Phi54/S2 fermion amplitudes from other
mass-dependent interactions.

## Independent checks and sensitive controls

The census expands typed AST monomials and enumerates internal port pairings,
checking connectedness,1PI and UV degree. The separate gate reconstructs the
physical support through a generating polynomial, scans the complete GF
with another parser and rebuilds triangle classes by edge endpoint types.
It also checks the valence/bridge argument, actual scalar-map supports,
sector-diagonal kinetic terms and SMA1's complete operator basis.

Adding a synthetic marginal Lambda*x*x produces two additional mixed-edge
candidate classes. Adding Lambda*B*x produces one. Removing BL propagation
eliminates all those additional control classes. Thus the test would detect
the possible auxiliary omission; it has not simply assumed a linear gauge.
No synthetic interaction is added to the action. Removing FFB, FFscalar
or B*scalar*scalar also changes the actual class set.

The resulting ordinary diagram structure can now be compared with
[Belusca-Maito et al., Sec5.2.2](https://arxiv.org/pdf/2004.14398).
Its coefficient formula has not been imported. GFK1's actual eta_H/xi width
matrix, current orientation, scalar generators, spinor numerator and source/
evanescent obligations must still be retained in the three gauge calculations.

## Preserved schema failures and execution

The original census failed before a table because its AST parser recognized
only x_* scalar names. The frozen potential uses the declared tensor names
Phi,Sigma,SigmaBar,phi,phiBar,S,SBar. V2 explicitly adds these scalar roles;
its run then failed at an assumed d0-style derivative encoding. A complete
literal suffix scan found compact numeric0,1,2,3, each occurring1,619 times.
V3 uses that exact ordinary-jet encoding and rejects unknown characters.

Both old source sets/copies, FAILED captures and controller failures remain.
Neither produced a table or receipt; both old verifiers were NOT_LAUNCHED.
The new version changes neither field dimensions, action, graph domain nor
acceptance controls. These were avoidable historical-schema implementation
errors; agreement after correction does not erase them.

CensusV3 and gateV3 completed exit0 in.5256080/.7323896s after imports.
Each has one private-memory startup sample,3,977,216/393,216 bytes. Failed
V1/V2 samples479,232/1,343,488 bytes are also preserved. These sparse samples
are not memory peaks or representative runtime maxima. Native allocation
guards and full post-run observations remain. Frozen600s/8GiBsampled/
350MiBfloor/16MiB limits were unexhausted. Preparations bind31/13/18/57
paths and12 source copies. There was no failed completed-version verifier.
Current-turn E4 readiness is authenticated reuse from GFK1, not fresh replay;
custody stays exit2/seven unresolved NOTPASS.

No loop integral, new pole coefficient, full finite forest, QAP or physical
scheme was calculated. Shared action, type/power-counting premises, supplied
data, software and AI authorship limit independence. This is internal support
qualification, not external physical validation or experimental evidence.

## Next calculation and unchanged boundaries

Derive the three remaining gauge-Yukawa triangle UV coefficients from their
ordered actual vertices. Keep the two scalar-current branches and the full
eta_H/xi color matrix. Reconcile them only after their separate coefficients
are derived. In the uniform-width limit compare the sum with the standard
chiral formula; do not use that formula to choose the individual signs.

No numerical flavor point, physical scheme, benchmark or foundation is
adopted. State113/34of39, E5/A5 and finite matter C1/unification standing
remain unchanged. Preserve both scalar points' negative quantum evidence,
old failed interfaces, flavor pause, HB1/C5 blocks, quartet failure, historical
policies and all evidence. No publication, push or external action occurred.
