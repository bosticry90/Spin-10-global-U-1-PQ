"""EPC1 ordered Born momenta and actual field-measure/principal-symbol checks."""
from data import *
from itertools import permutations
started=begin('primary')
x=s.symbols('x',real=True);z=x*(1-x);coeff={}
coeff['B2']=-s.Rational(1,4)
coeff['B_divA']=-s.Rational(1,2)*s.integrate(-x,(x,0,1))
coeff['B_A2']=s.Rational(1,6)*3*(-1)*s.Rational(1,4)
# Ordered A-A numerator i^2 k_mu(k+p)_nu with log factor-1/4.
coeff['gradA2']=s.Rational(1,4)*s.integrate(-z/2,(x,0,1))
coeff['divA2']=s.Rational(1,4)*s.integrate(-z,(x,0,1))
u0,u1,v0,v1=s.symbols('u0 u1 v0 v1');mom=[(u0,u1),(v0,v1),(-u0-v0,-u1-v1)];indices=[0,1,1]
cyclic=lambda w:min(w[i:]+w[:i] for i in range(len(w)))
loop=0;Y1=0;Y2=0
for order in permutations(range(3)):
    if cyclic(order)!=(0,1,2):continue
    a,b,c=order;mu,nu,rho=[indices[j] for j in order];pa,pc=mom[a],mom[c]
    delta=lambda i,j:int(i==j)
    residue=(-pa[mu]*delta(nu,rho)+pc[nu]*delta(mu,rho))/4
    residue+=(delta(mu,nu)*(pa[rho]-pc[rho])+delta(mu,rho)*(pa[nu]-pc[nu])+delta(nu,rho)*(pa[mu]-pc[mu]))/12
    loop-=residue/6 # i^3/i=-1;the common external i is stripped
    if indices[a]==indices[c]:Y1+=mom[a][indices[b]]
    if indices[a]==indices[b]:Y2+=mom[a][indices[c]]
c1,c2=s.symbols('c1 c2')
solution=s.solve(s.Poly(s.expand(c1*Y1+c2*Y2-loop),u0,u1,v0,v1).coeffs(),[c1,c2])
coeff['Y1']=s.simplify(solution[c1]);coeff['Y2']=s.simplify(solution[c2])
angular4=s.Rational(1,4*6);coeff['X4']=-s.Rational(1,8)*angular4*2;coeff['Y4']=-s.Rational(1,8)*angular4
packet=read(PACKET/'full_primary.json');scalar_traces=[];scalar_dim=0
for name,rows in sorted(packet['representation_matrices'].items()):
    size=rows[0]['shape'][0];scalar_dim+=size;assert len(rows)==45
    for row in rows:
        matrix=dec(row);assert matrix+matrix.T==s.zeros(size)
        scalar_traces.append(str(s.trace(matrix)))
f=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')['f']
ad=[s.SparseMatrix(45,45,{}) for _ in range(45)]
for a,b,c,value in f:ad[a][c,b]=s.sympify(value)
adjoint_traces=[str(s.trace(T)) for T in ad];assert set(scalar_traces+adjoint_traces)=={'0'}
D=s.symbols('D');superdiv=[s.expand((D-1)*s.sympify(t)-sum(s.sympify(scalar_traces[45*j+i]) for j in range(4))) for i,t in enumerate(adjoint_traces)]
assert superdiv==[0]*45 and scalar_dim==328
# Actual nonminimal vector principal inverse;all16 entries tested symbolically.
k=s.Matrix(s.symbols('k0:4',real=True));k2=(k.T*k)[0];width=s.symbols('x1',positive=True)
principal=k2*s.eye(4)-(1-1/width)*k*k.T
inverse=(s.eye(4)+(width-1)*k*k.T/k2)/k2
assert (principal*inverse-s.eye(4)).applyfunc(s.cancel)==s.zeros(4)
# Finite momentum-degree inventory,n insertions of first/zeroth-order V.
inventory=[]
for n in range(1,6):
    for first in range(n+1):
        degree=first-2*n;derivative_count=degree+4
        if derivative_count>=0:inventory.append([n,first,derivative_count])
assert all(n<=4 for n,first,derivative_count in inventory)
finish('primary',{'method':'ordered_Born_Feynman_Taylor_angular_words_actual_generator_traces',
    'minimal_integrated_pole_coefficients':{key:str(value) for key,value in coeff.items()},
    'cubic_external_color_word_coefficient':str(s.expand(loop)),'cubic_basis_probe':[str(Y1),str(Y2)],
    'Born_factors':[str((-1)**(n+1)*s.Rational(1,2*n)) for n in range(1,5)],
    'degree_inventory':inventory,'scalar_dimension':scalar_dim,'scalar_generator_traces':scalar_traces,
    'adjoint_generator_traces':adjoint_traces,'field_superdivergence_coefficients':list(map(str,superdiv)),
    'D4_fields_before_auxiliary':45*4+scalar_dim+45+45+45,'D4_fields_after_auxiliary':45*4+scalar_dim+45+45,
    'principal_inverse_matrix_positions':16,'complete_local_one_loop_source_pole_recipe':True,
    'all_model_source_components_extracted':False,'two_loop_width_identity_qualified':False,'finite_C1_calculated':False},started)
