"""EPC1 separate rational,graded-matrix,Gamma and nonlinear-source checks."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from itertools import product
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
started=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
expected={'B2':'-1/4','B_divA':'1/4','B_A2':'-1/8','gradA2':'-1/48','divA2':'-1/24','Y1':'-1/24','Y2':'-1/12','X4':'-1/96','Y4':'-1/192'}
for key,value in expected.items():assert Fraction(A['minimal_integrated_pole_coefficients'][key])==Fraction(B['minimal_integrated_pole_coefficients'][key])==Fraction(value)
assert set(A['minimal_integrated_pole_coefficients'])==set(B['minimal_integrated_pole_coefficients'])==set(expected)
assert A['degree_inventory']==B['degree_inventory'] and len(A['degree_inventory'])==8
assert max(n for n,first,derivatives in A['degree_inventory'])==4
assert A['Born_factors']==B['Born_factors']==['1/2','-1/4','1/6','-1/8']
assert len(A['scalar_generator_traces'])==len(B['scalar_generator_traces'])==180
assert len(A['adjoint_generator_traces'])==len(B['adjoint_generator_traces'])==45
assert A['scalar_generator_traces']==B['scalar_generator_traces']==['0']*180
assert A['adjoint_generator_traces']==B['adjoint_generator_traces']==['0']*45
assert A['field_superdivergence_coefficients']==B['field_superdivergence_coefficients']==['0']*45
assert A['D4_fields_before_auxiliary']==B['D4_fields_before_auxiliary']==643
assert A['D4_fields_after_auxiliary']==B['D4_fields_after_auxiliary']==598
assert A['principal_inverse_matrix_positions']==16
# Independent radial normalization at a positive mass;no scaleless integral.
eps=s.symbols('eps',positive=True);D=4-2*eps
moment=lambda r,n:s.gamma(r+D/2)*s.gamma(n-r-D/2)/(s.gamma(D/2)*s.gamma(n))
assert s.limit(eps*moment(0,2),eps,0)==1
assert s.limit(eps*moment(1,3)/D,eps,0)==s.Rational(1,4)
assert s.limit(eps*moment(2,4)/(D*(D+2)),eps,0)==s.Rational(1,24)
# Exact dimensional chart bookkeeping,not a finite parameter change.
assert all((n-2)-n==-2 for n in range(5))
assert -2+1+1==0
# Graded exterior tensor algebra. Each coefficient matrix has parity equal
# to its exterior degree;the whole differential coefficient is EVEN.
N=4;parities=[0,0,1,1]
def unit(i,j):
    T=s.zeros(N);T[i,j]=1;return T
def add(U,V):
    out={k:v.copy() for k,v in U.items()}
    for k,v in V.items():out[k]=out.get(k,s.zeros(N))+v
    return {k:v for k,v in out.items() if v!=s.zeros(N)}
def scale(U,z):return {k:z*v for k,v in U.items() if z*v!=s.zeros(N)}
def mul(U,V,cross=True):
    out={}
    for a,C in U.items():
        for b,E in V.items():
            if a&b:continue
            wedge=(-1)**sum(i>j for i in range(2) if a&(1<<i) for j in range(2) if b&(1<<j))
            transfer=(-1)**(a.bit_count()*b.bit_count()) if cross else 1
            key=a|b;out[key]=out.get(key,s.zeros(N))+wedge*transfer*C*E
    return {k:v for k,v in out.items() if v!=s.zeros(N)}
def trace(U,graded=True):return {k:s.expand(sum(((-1)**parities[i] if graded else 1)*C[i,i] for i in range(N))) for k,C in U.items()}
aa=[{0:unit(0,1)-unit(1,0)+2*unit(2,3)-2*unit(3,2)},
    {0:s.diag(1,-1,3,-3)}]
bb={0:s.diag(2,3,5,7),1:unit(0,2)+2*unit(3,1),2:unit(2,0)+3*unit(1,3)}
for op in aa+[bb]:
    for mask,C in op.items():
        assert all((parities[i]+parities[j])%2==mask.bit_count()%2 for (i,j),value in s.SparseMatrix(C).todok().items() if value!=0)
# Direct ordered Born sums,with angular contractions rather than the native
# nine-coefficient table. Two spacetime A components nonzero in D=4.
born=scale(mul(bb,bb),-s.Rational(1,4))
for a in aa:
    terms=add(add(mul(mul(a,a),bb),mul(mul(a,bb),a)),mul(mul(bb,a),a))
    born=add(born,scale(terms,-s.Rational(1,24))) # 1/6*i^2*1/4
for i,j,k,l in product(range(2),repeat=4):
    weight=int(i==j and k==l)+int(i==k and j==l)+int(i==l and j==k)
    if weight:born=add(born,scale(mul(mul(mul(aa[i],aa[j]),aa[k]),aa[l]),-s.Rational(weight,192)))
E=dict(bb)
for a in aa:E=add(E,scale(mul(a,a),s.Rational(1,4)))
heat=scale(mul(E,E),-s.Rational(1,4))
for a in aa:
    for b in aa:
        curvature=scale(add(mul(a,b),scale(mul(b,a),-1)),s.Rational(1,4))
        heat=add(heat,scale(mul(curvature,curvature),-s.Rational(1,24)))
Tb,Th=trace(born),trace(heat)
assert all(s.simplify(Tb.get(mask,0)-Th.get(mask,0))==0 for mask in range(4))
assert Th.get(3)==-s.Rational(5,2) and trace(heat,False).get(3)==0
wrong=trace(scale(mul(bb,bb,cross=False),-s.Rational(1,4)))
assert wrong.get(3)!=trace(scale(mul(bb,bb),-s.Rational(1,4))).get(3)
# Another nonlinear invariant Gaussian,with distinct polynomial and point.
x,y=s.symbols('x y',real=True);coords=[x,y]
S=2*x*x+3*y*y+x*x*y/2+y**4/4
grad=s.Matrix([s.diff(S,q) for q in coords]);R=s.Matrix([s.diff(S,y),-s.diff(S,x)])
H=s.hessian(S,coords);JR=R.jacobian(coords);at={x:2,y:1};G=H.subs(at).inv()
direct=sum((R[i]*H.diff(q) for i,q in enumerate(coords)),s.zeros(2))
mixed=sum((grad[i]*s.hessian(R[i],coords) for i in range(2)),s.zeros(2))
assert s.expand((grad.T*R)[0])==0 and s.trace(JR)==0
assert (direct+mixed+H*JR+JR.T*H).applyfunc(s.expand)==s.zeros(2)
field=s.trace(G*direct.subs(at))/2;source=s.trace(G*mixed.subs(at))/2
assert field+source==0 and field!=0
native=B['nonlinear_Ward_example'];assert Fraction(native['field_variation'])+Fraction(native['source_Hessian'])==0 and Fraction(native['field_variation'])!=0
# Epsilon-dependent basis projection is not silently allowed.
e=s.symbols('eps');Be=s.Matrix([[1,1+e]])
closed=s.Matrix([-(1+e)/e,1/e]);pole=s.Matrix([-1/e,1/e])
assert s.simplify((Be*closed)[0])==0 and s.simplify((Be*pole)[0])==1
# Receipt reuse is authenticated evidence,not a new re-extraction of all
# source/ordinary component poles. Exact hashes also belong to preparation.
receipt_names=[('canonical_so10_nielsen_affine_poles','validation_receipt_v2.json'),
 ('canonical_so10_hard_regulator_sources','validation_receipt.json'),
 ('canonical_so10_regulated_light_slavnov','validation_receipt_v3.json'),
 ('canonical_so10_vector_nielsen_form_factor','validation_receipt.json'),
 ('canonical_so10_ghost_counterterm_trace_closure','validation_receipt.json'),
 ('canonical_so10_quantum_vector_derivative_uv','validation_receipt_v2.json'),
 ('canonical_so10_light_regulator_spurion','validation_receipt.json')]
inherited={}
for folder,name in receipt_names:
    p=CAL/folder/name;result=read(p);assert result['execution_state']=='COMPLETED' and result['status'].startswith('QUALIFIED_')
    inherited[folder]={'file':name,'sha256':sha256(p.read_bytes()).hexdigest(),'status':result['status'],'recomputed_here':False}
controls={'ordinary_trace_instead_of_supertrace':Th.get(3)!=trace(heat,False).get(3),
 'omitted_odd_tensor_crossing':wrong.get(3)!=-s.Rational(5,2),'omitted_antifield_Hessian':field!=0,
 'early_epsilon_dependent_reduction':s.simplify((Be*pole)[0])!=0,
 'constant_symbols_miss_derivative_terms':all(Fraction(expected[k])!=0 for k in ['B_divA','gradA2','divA2','Y1','Y2']),
 'omitted_angular_pairings':Fraction(expected['X4'])!=Fraction(expected['Y4'])}
assert all(controls.values())
for result in [A,B]:
    assert result['complete_local_one_loop_source_pole_recipe'] and not result['all_model_source_components_extracted']
    assert not result['two_loop_width_identity_qualified'] and not result['finite_C1_calculated']
out={'schema':'EPC1_VALIDATION_RECEIPT','status':'QUALIFIED_LOCAL_ONE_LOOP_EXTENDED_SOURCE_POLE_CONSTRUCTION',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
 'minimal_symbol_coefficients':expected,'coefficient_count':9,'complete_degree_channels':8,'maximum_Born_length':4,
 'actual_scalar_generator_traces':180,'actual_adjoint_generator_traces':45,'field_superdivergence_positions':45,
 'D4_fields_before_auxiliary':643,'D4_fields_after_auxiliary':598,'principal_inverse_positions':16,
 'dimensional_potential_units_checked':5,'paired_mu_exponent':'0',
 'graded_matrix_size':4,'external_exterior_positions':4,'graded_u_chi_coefficient':str(Th[3]),
 'independent_nonlinear_Gaussian_field_term':str(field),'independent_nonlinear_Gaussian_source_term':str(source),
 'epsilon_dependent_projection_remainder':'1','inherited_quantum_receipts_authenticated':inherited,
 'complete_one_loop_source_pole_functional_defined':True,'one_loop_Slavnov_pole_closure_in_declared_chart':True,
 'all_model_source_components_extracted':False,'full_finite_source_prescription_qualified':False,
 'two_loop_width_identity_qualified':False,'finite_C1_calculated':False,'controls':controls,
 'new_physical_normalization_chosen':False,'elapsed_after_imports':time.perf_counter()-started}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
