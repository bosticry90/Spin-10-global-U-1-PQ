"""EPC1 independent heat trace/IBP coefficients and nonlinear source-Hessian Ward test."""
from data import *
started=begin('replay')
cyclic=lambda w:min(w[i:]+w[:i] for i in range(len(w)))
def square_trace(terms,factor):
    out={}
    for a,u in terms.items():
        for b,v in terms.items():
            word=cyclic((a,b));out[word]=out.get(word,0)+factor*u*v
    return out
E=square_trace({'B':1,'d':-s.Rational(1,2),'L':s.Rational(1,4)},-s.Rational(1,4))
O=square_trace({'F':-s.Rational(1,2),'C':s.Rational(1,4)},-s.Rational(1,24))
basis=s.symbols('B2 B_divA B_A2 gradA2 divA2 Y1 Y2 X4 Y4');B2,Bd,BL,X,C,Y1,Y2,X4,Y4=basis
dictionary={('B','B'):B2,('B','d'):Bd,('B','L'):BL,('d','d'):C,
    ('L','d'):-(Y1+Y2),('L','L'):X4,('F','F'):2*(X-C),('C','F'):2*(Y1-Y2),('C','C'):2*(Y4-X4)}
heat=s.expand(sum(value*dictionary[word] for word,value in (list(E.items())+list(O.items()))))
coeff={str(key):str(heat.coeff(key)) for key in basis}
packet=read(PACKET/'full_replay.json');scalar_traces=[];scalar_dim=0
for name,rows in sorted(packet['representation_matrices'].items()):
    size=rows[0]['shape'][0];scalar_dim+=size;assert len(rows)==45
    for row in rows:
        entries={(i,j):s.sympify(v) for i,j,v in row['entries']}
        assert all(entries.get((j,i),0)==-v for (i,j),v in entries.items())
        scalar_traces.append(str(sum(v for (i,j),v in entries.items() if i==j)))
adj=[s.S.Zero]*45
for a,b,c,z in packed(CAL/'canonical_so10_background_threshold_inputs/replay_tables.json.gz')['f']:
    if b==c:adj[a]+=s.sympify(z)
adj=list(map(str,adj));assert set(adj+scalar_traces)=={'0'}
D=s.symbols('D');superdiv=[s.expand((D-1)*s.sympify(v)-sum(s.sympify(scalar_traces[45*j+i]) for j in range(4))) for i,v in enumerate(adj)]
# A nonlinear invariant finite Gaussian with nonzero separate field/source
# variations. This tests the antifield Hessian term,not the physical model.
x,y=s.symbols('x y',real=True);coordinates=[x,y]
S=3*x*x/2+5*y*y/2+x*x*y*y/4+x**4/12
R=s.Matrix([s.diff(S,y),-s.diff(S,x)]);gradient=s.Matrix([s.diff(S,q) for q in coordinates]);H=s.hessian(S,coordinates)
assert s.expand((gradient.T*R)[0])==0 and s.trace(R.jacobian(coordinates))==0
at={x:1,y:2};G=H.subs(at).inv()
field_variation=sum((R[i]*H.diff(q) for i,q in enumerate(coordinates)),s.zeros(2))
mixed=sum((gradient[i]*s.hessian(R[i],coordinates) for i in range(2)),s.zeros(2))
JR=R.jacobian(coordinates)
assert (field_variation+mixed+H*JR+JR.T*H).applyfunc(s.expand)==s.zeros(2)
field_value=s.trace(G*field_variation.subs(at))/2;source_value=s.trace(G*mixed.subs(at))/2
assert field_value+source_value==0 and field_value!=0
# Rank-one longitudinal projector algebra,independent of a literal4x4 inverse.
t=s.symbols('t',positive=True);p=s.symbols('Pi',commutative=False)
rank_product=s.expand((1-(1-1/t)*p)*(1+(t-1)*p)).subs(p**2,p).expand();assert rank_product==1
inventory=[]
for n in range(1,6):
    for zeroth in range(n+1):
        first=n-zeroth;order=-n-zeroth
        for derivatives in range(5):
            if order-derivatives==-4:inventory.append([n,first,derivatives])
finish('replay',{'method':'heat_E_Omega_cyclic_IBP_replay_entries_nonlinear_Gaussian_Ward',
    'minimal_integrated_pole_coefficients':coeff,'Born_factors':[str(s.Rational(1,2)*(-1)**(n+1)/n) for n in range(1,5)],
    'degree_inventory':sorted(inventory),'scalar_dimension':scalar_dim,'scalar_generator_traces':scalar_traces,
    'adjoint_generator_traces':adj,'field_superdivergence_coefficients':list(map(str,superdiv)),
    'D4_fields_before_auxiliary':45*4+scalar_dim+45+45+45,'D4_fields_after_auxiliary':45*4+scalar_dim+45+45,
    'nonlinear_Ward_example':{'field_variation':str(field_value),'source_Hessian':str(source_value),'total':'0','dimension':2},
    'complete_local_one_loop_source_pole_recipe':True,'all_model_source_components_extracted':False,
    'two_loop_width_identity_qualified':False,'finite_C1_calculated':False},started)
