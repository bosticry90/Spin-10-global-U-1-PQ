# EPC1: a complete one-loop source pole prescription is defined

Within the frozen formal Euclidean BFT dimensional prescription,the actual
extended Hessian now defines a complete local one-loop MSbar source pole
functional. Its linearized extended Slavnov closure follows in the declared
component tensor chart. No unknown source coefficient was fitted to a
desired cancellation. No finite source normalization or physical parameter
was changed.

This is a constructive operator-functional result. It is stronger than
listing possible source counterterms,and different from extracting every
model-specific component. The latter has not been done here. In particular,
the result does not qualify the nonlinear two-loop matching identity.

## What is explicitly constructed

Start with the actual physical BFT action,its gauge fermion,the RNC regulator
doublet and every ordinary antifield. Retain b through source differentiation,
then perform its exact inherited Gaussian,including all correlated source
contacts. Raise the598-field graded Hessian by its constant kinetic metric.
Its symbol has principal part P2 and lower orders V1,V0.

The pole is the following finite operation on that specified Hessian:

    Gamma1_pole=ell/(2eps)*int <STr sum_(n=1..4)
                     (-1)^(n+1)/n [(P2^-1#(V1+V0))^(#n)]_(-4)>_S3.

The counterterm is its negative. The star product retains spacetime
derivatives,operator order and odd coefficient/internal-parity crossings.
The degree-minus-four coefficient and normalized angular average are local.
There are eight momentum-degree channels,at most four ordered insertions
and finitely many derivatives. Higher Born words cannot contribute to this
pole by degree,although their finite quantum amplitudes need not vanish.

All field and source dependence is specified by the actual action,not by
free entries in a mixing matrix. The construction includes source classes
outside the previously selected contact module. The principal inverse is
field/source independent and analytic near positive widths1. It introduces
no inverse mass,field or gauge coupling. The source-zero physical action,
reference point and original MSbar/tadpole conventions remain unchanged.

## Independent normalization and locality checks

At widths1,the direct ordered momentum calculation and independent heat
calculation give the same nine integrated minimal-symbol coefficients:

| Structure | Pole coefficient in ell/eps units |
| --- | --- |
| Tr B^2 | -1/4 |
| Tr B partial.A | +1/4 |
| Tr B sum A^2 | -1/8 |
| Tr(partial_mu A_nu)^2 | -1/48 |
| Tr(partial.A)^2 | -1/24 |
| Tr(partial_mu A_nu)A_mu A_nu | -1/24 |
| Tr(partial_mu A_nu)A_nu A_mu | -1/12 |
| Tr A_mu A_mu A_nu A_nu | -1/96 |
| Tr A_mu A_nu A_mu A_nu | -1/192 |

These are universal differential-operator structures,not nine new physical
primitive families. The heat route uses E=B-partial.A/2+sum A^2/4 and
Omega for omega=-A/2. Total derivatives are explicitly quotiented only in
the integrated Schwartz-field functional. Constant-symbol comparisons
alone would miss five of these structures;the momentum route retains them.

The actual nonminimal vector principal inverse was checked on all16 matrix
positions,with an independent longitudinal-projector derivation. The raised
ghost pair gives the required ordered minus trace. A graded matrix/exterior
test reproduces the u*chi coefficient-5/2;an ordinary trace would give zero,
and omitting the odd tensor crossing reverses the relevant contribution.

## Why the source poles close

The ordinary BFT field superdivergence vanishes before any spatial trace:
all45 actual adjoint traces and180 scalar representation traces are zero.
The corresponding45 ghost-color coefficients are zero for symbolic D.
The auxiliary Gaussian preserves its source contacts;it removes only the
field/background-independent identity normalization. The inherited classical
potential invariance,Jacobi and representation identities remain explicit
scientific premises,not newly established by this computation.

Differentiating the classical extended equation twice gives the full
one-loop Hessian identity. It includes the antifield contribution S_i R_i''
for nonlinear transformations. The contracted identity is

    B_S Gamma1=-STr R'=0.

Pole extraction commutes with B_S in the unreduced component tensor chart.
The common mu^eps units factor consistently:the classical density carries
mu^(-2eps),and its two field/antifield derivative units cancel that factor.
No epsilon-dependent Lorentz quotient or altered pole lift is introduced.
Hence the pole and the fixed-regulator one-loop minimally subtracted
functional obey the linearized identity in this formal domain.

The tests deliberately show what this conclusion does not allow. In two
different nonlinear finite-Gaussian examples,the field variation and source
Hessian contribution are separately nonzero and cancel. Omitting the source
term fails. A separate epsilon-dependent basis-change example has a closed
bare expression but a pure-pole projection with nonzero finite remainder1.
That is why an arbitrary reduction or pole-preserving lift is not accepted.
These examples test the algebra;they do not validate shared physical inputs.

## Evidence,execution and limitations

Receipt validation_receipt.json,SHA256
168b93b1e6cd2ee0a0b13e867ad047403b9272a9ae3916a565b38c8392abc5ab,
status QUALIFIED_LOCAL_ONE_LOOP_EXTENDED_SOURCE_POLE_CONSTRUCTION.
Scientific/director acceptance NOT_PERFORMED. Authority remains34/39.

Primary used ordered Born/Feynman/Taylor/angular contractions and actual
generator matrices. Replay used heat E/Omega expansion,cyclic trace/IBP,
independent representation entries and a nonlinear source-Hessian example.
The separate verifier imported neither native calculation and used rational
coefficient checks,positive-mass Gamma residues,a graded exterior/matrix
test and a distinct nonlinear Gaussian. All three executions completed on
their first attempts. There were no failed scientific workers,verifiers,
timeouts or resource exhaustions in this increment.

Native times after imports were5.41398369998 and4.46247660002s;verification
took2.04274370003s. Sampled private-memory maxima were53501952,49008640 and
47652864 bytes,with4,3,2 samples. These are sampled observations,not continuous
peaks. All stayed within600s/8GiB sampled/350MiB launch/24MiB package limits.
Preparation bound5641 inputs;verification bound5648. Readiness and complete
raw/index/HEAD preservation are recorded in the external
extended-source-pole-v1-2026-10-21 control directory. Custody must retain
exit2/seven unresolved references,not a global PASS.

Seven existing NAP/HRS/RLS/NVF/GCT/QDV/LRS quantum receipts were authenticated
and retain their own scopes. They were not labelled fresh component
re-extractions or independent confirmation of the new generating theorem.
This increment constructs the full operator recipe and checks its universal
coefficients and applicability;it does not produce a full expanded source
coefficient table. No expensive qualified primitive amplitudes were rerun.

Read-only recovery encountered one guessed BFT source filename that did not
exist;the actual inventory was then read. No scientific execution was lost.
All earlier failed runs remain. Shared action,representation data,classical
identities,DR/symbol assumptions,software and AI author remain shared-error
limits. Root previously saw the historical comparison target;no blind-author
claim. Workers did not use it for scientific calculation or fitting.

The primary references are [Vassilevich,eq4.28](https://arxiv.org/html/hep-th/0306138v3)
and [Lewandowski,section2 and Appendix C](https://arxiv.org/pdf/1307.4055v1).
They provide established heat and dimensional extended-BRST methods. The
actual BFT gauge fermion,regulator,source signs and domain checks are still
required;the literature does not independently certify this model.

## What remains for the requested threshold

The one-loop pole family is now defined collectively rather than inferred
from selected cancellations. It can be differentiated as an actual local
functional to obtain counterterm source jets. Finite source freedoms and
the nonlinear two-loop equation are separate. At order two,the one-loop
antibracket,counterterm insertions,overall pole and common full/EFT forest
and heavy-EOM reduction must be handled together. In particular,the actual
two-soft source ownership is not proved by the one-soft SCO template.

No unknown two-loop finite variation has been assigned the FAN conditional
value. No numerical C1,two-loop width independence,complete finite product
framework,E5/A5,fermionic coverage or physical unification is promoted.
Original C1 acceptance/refit and perturbative-control requirements remain.
Keep all scalar140%local/1.94%Euclidean/20.27%timelike,tree|a0|~.76809>1/2,
gauge residual.745476/missingYukawas and quartet warnings. Matter/flavor
remains paused,HB1/C5 blocked,authority34/39 and custodyexit2/seven NOTPASS.
Whole Spin10xglobalU1PQ investigation remains incomplete.
