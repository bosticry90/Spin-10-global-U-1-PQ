# Next: nonlinear order-two subtraction and actual common source forests

EPC defines the complete local one-loop source pole functional by the
actual extended Hessian residue,and proves its linearized closure in the
specified component chart. NVF/RLS/HRS remain actual finite/nonlocal source
inputs. Do not reduce the next problem to more selected one-loop residues.

At order two the identity is nonlinear. Let P1=-Pole Gamma1 and
Gamma1R=Gamma1+P1. The actual order-two subtracted functional contains
Gamma2[S_ext]+delta_(P1)Gamma1[S_ext],where the second term is the complete
one-loop trace of P1's Hessian. Its overall subtraction is not determined
by declaring that each separate source term vanishes.

Derive the two-loop extended Wick/Slavnov identity in the SAME regulated
dimensional domain. Include the antibracket of one-loop functionals and
the possible local measure contact from the counterterm deformation. Prove
the correct pole relation with P1,P1 and the overall P2;do not assume the
linear one-loop closure automatically extends. Test the nonlinear subtraction
algebra with complete Laurent projections and sensitive missing-cross-term
controls. A cohomology classification or blocked HB1/C5 activation is not
authorized or required merely to derive the actual fixed-order identity.

Use the full graded cubic/quartic skeleton functional of S_ext to specify
Gamma2. Its source-zero limit must recover the nine BFT bosonic families
and their exact original forests. Show how source derivatives act on every
vertex,propagator and counterterm,including heavy-EOM/tadpole leaves.
EPC's formula gives genuine source CT jets,not arbitrary matrix entries.
Preserve the D-dimensional lifts and finite terms from pole products.

Then prove common full/EFT source ownership of the one-soft AND two-soft
regions. Existing SCO covers one specific operation;it does not supply an
automatic two-soft theorem. Seek a complete required first-variation result
or identify the precise missing graph/source class. No unmeasured two-loop
1PI width derivative is set from the desired FAN bridge cancellation.

Keep original C1 item7 gauge/basis/degenerate/scale/1L tests,item8 refit,
arbitrary-g evaluator,MSbar/tadpole conventions and perturbative-control
assessment. No target fitting,physical promotion,paused flavor or HB1/C5
activation. State113/34of39,custodyexit2/seven NOTPASS and all warnings stay.
