# EPC1: a local pole functional,not a fitted source completion

## Actual action,field domain and inherited classical inputs

Use the physical Spin10 scalar/gauge action underlying BFT,not the separate
formal E5 gauge fixing. BFT binds the parent action hash
01323e0f6a025edd6f6669b43e7c730f5350e28d8561e72df89636862ca358ed and the
positive-Higgs reference hash476645438ea8a7ada42fea90e80174b772d45ce3e729d013d134e9848950c816.
The inherited invariant scalar potential and representation/Lie identities
are scientific inputs,not re-proved by agreement of new implementations.
The BFT scalar kinetic and YM action have their ordinary covariant forms.

Before auxiliary elimination define the actual extended action

 S_ext=S_phys+s_ext Psi+s_ext(u O_delta)+sum_i K_i R_i,
 Psi=barc*[Dbar.Q+g sqrt(x1*x2)O^T eta-x1*b/2],
 O_delta=Q P0 Q/2+eta Ps eta/2+barc P0 c.

R_Q=Dbar c+g[Q,c],R_eta=-g rho(c)(v+eta),R_c=-g[c,c]/2,
R_barc=b,R_b=0. Also s_ext xk=chik,s_ext chik=0,s_ext u=delta,
s_ext delta=0. The background is fixed under quantum BRST. Jacobi,the
actual representation identity and s_ext^2=0 establish the classical
extended Slavnov equation. Gauge-fermion and regulator terms are exact;
no source coefficient is inferred from a quantum cancellation.

Fields at D=4 are180 real vector,328 real scalar,45 ghost,45 antighost and
45 auxiliary directions. Canonical dimensions are1,1,1,1,2. R raises
dimension1,so K_i has dimension3-d_i and opposite parity. Constant chi,u
have dimension1,delta2. R_b0 makes K_b absent,not an omitted quantum
coupling. All finite source monomials allowed by locality/power counting
are included by the functional derivative below,not restricted to the
earlier nine-family auxiliary contact module. Matter/fermions are excluded
from this bosonic BFT subaction,not declared irrelevant to the full model.

The ordinary field superdivergence is,per ghost color,

 g*[(D-1)Tr(ad_c)-Tr(rho_c)].

The vector trace is D times the adjoint trace;the odd ghost derivative has
the opposite supertrace weight. Scalar traces sum over all328 directions.
Every actual adjoint and scalar generator is traceless. Thus this density
vanishes BEFORE a spatial trace or delta(0) is assigned a value. Antighost
and auxiliary diagonal derivatives vanish. This justifies the perturbative
flat/Berezin measure change used here;it is not a nonperturbative global
gauge-orbit or Lorentzian measure theorem.

## Auxiliary Gaussian and actual principal symbol

Keep b until source equations are defined. Its bracket is
F-chi1*barc/2-u P0c+K_barc and its quadratic term is-x1*b^2/2.
The inherited imaginary contour integrates it exactly. The Schur complement
retains ALL correlated source contacts,including u*chi,antifield terms and
the source-only square. The b determinant is field/background independent;
the declared vacuum normalization removes only that identity factor.
It is not legitimate to delete source cross terms with it.

After this exact Gaussian,raise the graded Hessian with its constant kinetic
metric Z. Odd c/barc blocks are raised with their antisymmetric metric;
half the supertrace then gives the actual ordered -Tr log Kc. The598-field
operator has symbol P=P2+V1+V0,where the principal vector block is

 P2,v=k^2 I-(1-1/x1)k_mu k_nu,
 P2,v^-1=[I+(x1-1)k_mu k_nu/k^2]/k^2.

Scalar and raised ghost blocks have P2=k^2 I. All sources and mean fields
enter only V1,V0. This follows directly from the actual degree<=4 action:
K_Q Dbar c is linear in integrated fields;nonlinear R terms and auxiliary
source contacts give at most first derivatives in the Hessian. Positive
x1 makes P2 invertible;at1 it is minimal. Light delta and positive-heavy
reference masses regulate the IR. Fields/sources are formal perturbative
Schwartz insertions,not an assumed globally positive interacting potential.

## Complete finite residue recipe

For left symbols use a#b=sum_alpha (1/i)^|alpha|/alpha!
*(partial_k^alpha a)*(partial_x^alpha b),with graded coefficient products.
Let W=P2^-1#(V1+V0). The actual one-loop pole is

 Gamma1_pole=ell/(2 eps)*int_x <STr sum_(n=1..4)
              (-1)^(n+1)/n *[W^(#n)]_degree(-4)>_S3.     (1)

The local counterterm is-Gamma1_pole. Here ell=1/(16pi^2),D=4-2eps;
the normalized angular average and radial shell integral k^-4 have pole
ell/eps. Every W lowers momentum degree by at least1;every symbol derivative
lowers it further. Hence n>4 cannot contribute. For each n,at most4-n
additional derivatives are needed. This is a COMPLETE bound,not a numerical
cutoff or an assumption that higher finite amplitudes vanish.

Equation(1) is an explicit finite functional of the ACTUAL S_ext Hessian.
It defines all its source coefficients by differentiation without choosing
unknown mixing entries. It is not the unevaluated assertion that some
counterterm exists. Its finite momentum-degree extraction uses only local
coefficients and finitely many spacetime derivatives. P2^-1 depends only
on widths and momentum,so no inverse fields,masses or gauge couplings arise.
The width dependence is analytic near1. Power-sensitive and finite/IR terms
are not included in(1). A UV shell,not a scaleless whole integral,defines
the pole extraction.

No determinant-factorization assertion about finite multiplicative anomalies
is needed:insert lambda*(V1+V0),differentiate Tr log P with respect to lambda,
expand the inverse geometrically and integrate lambda from0 to1. Cyclicity
holds for the background-subtracted positive-mass convergence-domain traces,
and their pole residue is a trace. The pure P2 contribution is independent
of fields/background. This proves(1) without rearranging undefined finite
products. The relevant fixed-field-degree integrals have a common small
positive ReD UV convergence range and regulated IR;continue meromorphically.

## Minimal-symbol normalization and independent heat comparison

At widths1 write P=-partial^2+A_mu partial_mu+B. Define
omega_mu=-A_mu/2,E=B-partial_mu A_mu/2+sum A_mu A_mu/4 and
Omega_munu=partial_mu omega_nu-partial_nu omega_mu+[omega_mu,omega_nu].
All are EVEN superoperators,including odd coefficient/internal-parity
crossing signs. Then(1) must agree with

 Gamma1_pole=-ell/(2 eps)*int STr[E^2/2+Omega_munu Omega_munu/12]

modulo the explicit total derivative. The heat theorem fixes the independent
route;the Born route measures its normalization and derivative terms.

For an integrated trace basis,the nine coefficients of Gamma1_pole/(ell/eps)
are prospectively
 B^2:-1/4; B partial.A:+1/4; B sum A^2:-1/8;
 (partial_mu A_nu)^2:-1/48; (partial.A)^2:-1/24;
 Y1=sum(partial_mu A_nu) A_mu A_nu:-1/24;
 Y2=sum(partial_mu A_nu) A_nu A_mu:-1/12;
 X4=sum A_mu A_mu A_nu A_nu:-1/96;
 Y4=sum A_mu A_nu A_mu A_nu:-1/192.

Primary obtains these from the actual ordered log factors1/2,-1/4,1/6,-1/8,
two-point Feynman shifts and the first external-momentum Taylor term of the
three-A loop. Four-momentum angular contractions retain all three pairings.
Replay expands E/Omega and reduces cyclic traces and IBP. A constant-symbol
test alone is insufficient:it misses B partial.A,the two derivative squares
and the two derivative-cubic structures. Graded tensor/exterior tests retain
odd external signs rather than replacing STr with an ordinary matrix trace.

## One-loop extended Slavnov closure and the pole lift

Let B_S be the actual linearized extended Slavnov operator. Differentiating
the classical equation twice in integrated fields relates B_S S'' to the
two cotangent R' terms. Crucially it includes S_i R_i'' via the antifield
derivative of Gamma1. The one-loop Hessian trace therefore gives

 B_S Gamma1=-STr R'=0.                                  (2)

One route derives(2) by the infinitesimal Gaussian/Berezin change of
variables. The other differentiates the classical master equation twice,
contracts with the full inverse Hessian and uses graded cyclicity. Omitting
the antifield Hessian term S_i R_i'' is wrong for nonlinear transformations,
even if a source value happens to vanish at the reference. An off-shell
finite nonlinear Gaussian example checks this term explicitly;it is an
algebra diagnostic,not independent validation of the model's premises.

Pole extraction commutes with B_S in the unreduced component tensor chart:
the transformation coefficients have no explicit eps,only fixed internal
representation tensors and ordinary Lorentz metrics. Bare mu^eps coupling
units are factored homogeneously and held unexpanded during projection.
Explicitly,phi_D=mu^(-eps)phi and K_D=mu^(-eps)K for every field/antifield,
including b;g_D=mu^eps*g and an n-scalar potential coefficient is
mu^((n-2)eps) times its chart coefficient. Widths,chi,u and delta keep their
displayed units. The entire classical density has the common factor
mu^(-2eps). In each field-antifield pair of the linearized operation,the
two derivative factors mu^eps cancel that factor. The doublet derivatives
likewise act on the same chart. Thus the stated epsilon independence is
dimensional bookkeeping in the original MSbar chart,not an extra finite
field or coupling redefinition. Potential n=0..4 and the paired exponent
cancellation are checked explicitly. Expanding these units inconsistently
before the pole map would be a different calculation.
No dimension-specific epsilon tensor,gamma5,Fierz or rank-five antisymmetry
reduction is used. At renormalizable dimension4 the available metric
operators have no hidden four-dimensional evanescent quotient. Closed D
traces contribute to the computed pole coefficients,not to a redefinition
of B_S. The derivative/ghost/source tensor lifts are the actual D-dimensional
ones. Do not replace them with pole-preserving but finite-changing lifts.

This restriction matters. For an invented B_eps(v1)=w,
B_eps(v2)=(1+eps)w,the closed expression[-(1+eps)v1+v2]/eps has a pole part
whose B_eps image is the nonzero finite w. A projection performed after
such an eps-dependent basis change need not commute. The calculation must
detect this control and MUST NOT claim arbitrary reductions preserve(2).

With the stated actual chart,(1),(2) give B_S Gamma1_pole=0 and
B_S[Gamma1-Gamma1_pole]=0 at fixed regulator in this formal Euclidean domain.
This constructs the nonempty complete one-loop MSbar source pole prescription
as a generating functional. It does not enumerate every model coefficient,
fix legitimate finite source freedoms,prove multiple-insertion/causal limits,
or establish the two-loop identity. Existing measured source projections
remain authenticated comparators,not fresh full component extractions here.

At order two the nonlinear antibracket,one-loop counterterm insertions,
overall subtraction,heavy-EOM reduction and common full/EFT one-/two-soft
source ownership still require the bounded proof. They cannot be assigned
from the desired FAN width cancellation. No blocked H-basic/C5 construction
or protected E5 promotion is performed by this one-loop pole result.

Primary literature: Vassilevich,hep-th/0306138v3,eq4.28,
https://arxiv.org/html/hep-th/0306138v3;Lewandowski,1307.4055v1,section2 and
Appendix C around eq272--273,https://arxiv.org/pdf/1307.4055v1. The latter
uses dimensional extended BRST pole subtraction for bosonic Yang--Mills;
the actual gauge fermion/regulator/domain checks above are still required
for this BFT application. Its abstract is not scientific acceptance here.
