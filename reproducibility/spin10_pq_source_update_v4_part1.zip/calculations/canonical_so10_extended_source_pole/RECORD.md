# EPC1: complete one-loop extended-source pole functional in the BFT chart

Prospective at d8afe6707228e85b25034910441590a196adb51c/main,2026-10-21.
Previous goal turn PROGRESS via NVF. Clean main,no matching workers. The
scientific question is whether the actual source-extended BFT action has a
complete local one-loop MSbar pole functional closed under its linearized
Slavnov operation,rather than a collection of separately normalized source
projections. This is a prerequisite for C1's two-loop matching variation.

Freeze RECORD,DERIVATION and six Python sources before execution. Actual
physical scalar/gauge action,ordinary BFT gauge fermion,RNC regulator doublet
and NAP/NVF source conventions remain. All643 fields before the auxiliary
Gaussian,598 after it;all antifields with opposite parity and dimensions;
constant width sources chi1,chi2 and regulator u,su=delta. Widths analytic
near positive1;minimal-symbol comparisons at widths1. No formal E5 action
or blocked cohomology construction is imported. All source derivatives LEFT.

Construct the pole functional explicitly by a finite graded symbol residue
of the actual extended Hessian. Prove locality,complete finite word bound,
actual principal-symbol applicability,vanishing ordinary field Jacobian and
one-loop Slavnov closure. Preserve the dimensional tensor lift and factored
mu^eps coupling units. Counterterms are opposite the computed pole,no finite
normalization is fitted. This is a generating functional construction;it
does not claim extraction of every model-specific component coefficient.

Primary: direct ordered Born-loop derivation of the nine integrated minimal
symbol coefficients,including external-momentum quadratic/cubic terms;
actual adjoint/scalar diagonal traces and principal inverse. Replay: local
heat E/Omega expansion with cyclic trace and integration-by-parts reduction;
independent representation-entry trace construction and nonlinear finite
Gaussian Ward example retaining antifield Hessians. Separate verifier:
exact coefficient comparisons,graded exterior/matrix supertraces,scalar
MSbar radial normalization and counterexamples for missing source curvature,
ordinary instead of graded trace,omitted derivative terms and epsilon-
dependent reductions. Existing NAP/HRS/RLS/NVF and ordinary kernel receipts
are authenticated inputs,not labelled fresh full component re-extractions.

Outcomes: bounded constructive one-loop pole theorem,precise failed premise,
or incomplete calculation. No two-loop finite Nielsen theorem is inferred.
No automatic physical scheme adoption,finite contact choice,C1 comparison,
cohomology-stage activation or authority promotion. State113/34of39 and
custodyexit2/seven NOTPASS remain;paused matter/flavor and HB1/C5 block stay.
Preserve all scalar,gauge,quartet warnings and every historical byte.

Sequential600s workers after imports,8GiB sampled private memory,350MiB
launch floor,24MiB package. Freeze explicit ancestry/source copies;complete
observed captures before assertions;separate validation;readiness e4 and
raw/index/HEAD seal before local commit. No agents,branch,reset,push,outreach
or publication. Shared action,kinematic data,DR/local-symbol premises,
software and AI author limit independence. Root saw the old comparison
target earlier;workers do not use it and no blind-author claim is made.
