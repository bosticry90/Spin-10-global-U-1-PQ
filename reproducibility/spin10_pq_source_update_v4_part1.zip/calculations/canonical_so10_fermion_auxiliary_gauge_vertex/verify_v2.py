"""FAV1 full two-route coefficient gate and unfitted old-A projection comparison."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
for key in ['raw_U','Lorentz_Wick_phase','selfenergy_Gaussian_unit','inverse_response_unit','combined_phase','Feynman_residue','longitudinal_residue']:assert P[key]==R[key],key
assert P['selfenergy_Gaussian_unit']=='-1' and P['inverse_response_unit']=='1' and P['combined_phase']=='1' and P['Lorentz_Wick_phase']==['-I']*4 and R['primitive_auxiliary_density_positions']==936
assert P['Feynman_residue']=='1' and P['longitudinal_residue']=='1/4'
for a,b in zip(P['angular_factors'][0],R['angular_factors'][0]):assert s.simplify(s.sympify(a)-s.sympify(b))==0
for key in ['background_RH','auxiliary_UL']:zero(dec(P[key])-dec(R[key]))
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,yc['Tminus']));H=dec(yc['H_new']);f={(a,b,c):s.sympify(v) for a,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']};FH=[s.SparseMatrix(45,45,{(c,b):s.simplify(sum(H[a,h]*f.get((a,b,c),0) for a in range(45) if H[a,h])) for b in range(45) for c in range(45)}) for h in range(12)];counts={};controls={};maps={}
for kind,n in [('B',45),('A',12)]:
 L=list(map(dec,P['outputs'][kind]['left']));RR=list(map(dec,P['outputs'][kind]['right']))
 for a,b,c,d in zip(L,map(dec,R['outputs'][kind]['left']),RR,map(dec,R['outputs'][kind]['right'])):zero(a-b);zero(c-d);zero(c+a.T)
 adj=s.Matrix(n,45,lambda c,d:s.simplify(s.trace(T[d]*L[c])/(2*s.I)));zero(adj-dec(R['outputs'][kind]['adjoint_map']))
 for c,a in enumerate(L):zero(a-s.I*sum((adj[c,d]*T[d] for d in range(45) if adj[c,d]),s.zeros(16)))
 controls[kind]={key:any(tidy(a-b).todok() for a,b in zip(L,map(dec,P['outputs'][kind][key]))) for key in ['only_one_mixed_placement','omit_longitudinal']};assert all(controls[kind].values())
 if kind=='B':
  for Fh in FH:zero(Fh*adj.T-adj.T*Fh)
 else:
  for h,Fh in enumerate(FH):
   th=sum((H[a,h]*T[a] for a in range(45) if H[a,h]),s.zeros(16));Fsmall=H.T*Fh*H
   for c,a in enumerate(L):zero(th*a-a*th-s.I*sum((Fsmall[d,c]*L[d] for d in range(12) if Fsmall[d,c]),s.zeros(16)))
 assert all(all(co.is_real for co in s.Poly(z,eta,xi).coeffs()) for z in adj.todok().values())
 maps[kind]=adj;counts[kind]={'directions':n,'nonzero_left':sum(len(a.todok()) for a in L),'nonzero_right':sum(len(a.todok()) for a in RR),'adjoint_map_positions':len(tidy(adj).todok()),'generic_adjoint_map_rank':int(adj.rank())}
# Only after both independently measured results exist: old fixed A-source
# generator projection. B is even, so its canonical field map is -Zraw*A;
# negative variation of the matter -ig gamma T.B is -ig Zraw*A in old32 units.
oldp=CAL/'canonical_so10_local_source_primitive/primary_v2_result.json';rec=read(oldp.parent/'validation_receipt.json');assert rec['execution_state']=='COMPLETED' and rec['input_sha256'][str(oldp)]==digest(oldp);old=read(oldp);Z=[s.zeros(45,12) for _ in range(4)]
for row in old['fixed_generator_components']['gauge']:
 w=row['word'];A=[n for n in w if n.startswith('A')];J=[n for n in w if n.startswith('JB')]
 if not A:continue
 assert len(w)==2 and len(A)==len(J)==1 and row['g']==2;h,mu=map(int,A[0][1:].split('_'));i,nu=map(int,J[0][2:].split('_'));assert mu==nu;Z[mu][i,h]+=s.sympify(row['coefficient'],locals={'reference_width_H':eta,'reference_width_M':xi})
for M in Z[1:]:zero(M-Z[0])
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);candidate=-tidy(Q*Z[0]*dec(P['background_RH'])).T/2;remainder=tidy(maps['A']-candidate)
out={'old_A_source_raw_matrix':enc(Z[0]),'old_fixed_A_pole_adjoint_candidate':enc(candidate),'actual_A_pole_adjoint':enc(maps['A']),'A_projection_remainder':enc(remainder),'B_pole_adjoint':enc(maps['B'])};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'projection_tables.json.gz').open('xb') as f:f.write(blob)
assert not old['sourcefree_normalization_matches_known_complete_projector'] and not old['generator_or_scheme_adopted']
for d in [P,R]:assert d['new_one_loop_vertex_families']==1 and d['new_two_loop_integrals']==0 and not d['open_line_extra_half'] and d['family_extension']=='identity_no_extra3'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_AUXILIARY_FERMION_GAUGE_VERTEX_UV_FAMILY','elapsed_after_imports':time.perf_counter()-start,'literal_auxiliary_cubic_positions':936,'all_Lorentz_copies_checked':4,'total_chiral_current_positions_compared':2*57*16**2,'B_and_independent_A_results':counts,'controls':controls,'Feynman_residue':'1','longitudinal_residue':'1/4','combined_phase':'1','old_A_source_projection_remainder_positions':len(remainder.todok()),'old_A_source_projection_match':not bool(remainder.todok()),'projection_packed_sha256':sha256(blob).hexdigest(),'projection_raw_sha256':sha256(raw).hexdigest(),'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'full_B_vertex_completed':False,'regulated_background_QAP_measure_or_finite_matching_qualified':False,'old_sourcefree_mismatch_preserved':True,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
