"""FAV1 actual density/raw Green products, exterior Gaussian and Clifford pole."""
from data import *
from collections import defaultdict
start=begin('primary');assert digest(Path(__file__))==read(HERE/'preparation_v2.json')['new_source_sha256'][str(Path(__file__).resolve())]
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
# Exact Grassmann Gaussian, order externalbar,externalP,internalP,internalbar.
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   parity=sum((b&((1<<i)-1)).bit_count() for i in range(a.bit_length()) if (a>>i)&1)%2;out[a|b]=out.get(a|b,0)+(-1)**parity*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)}
F,a,b,X,Y=s.symbols('F a b X Y',nonzero=True);action={12:-F,5:a*X,10:-b*Y};term={0:s.S.One};exp=dict(term)
for n in range(1,5):
 term={k:-v/n for k,v in mul(term,action).items()}
 for k,v in term.items():exp[k]=s.expand(exp.get(k,0)+v)
assert exp[12]==F;selfunit=s.simplify(-exp[15]/F/(a*b*X*Y/F));assert selfunit==-1
responseunit=-selfunit # dG=-G H G
wick=[s.simplify(-(-s.I)*sign*rot**2) for sign,rot in zip([1,-1,-1,-1],[s.I,1,1,1])];assert wick==[-s.I]*4
phase=s.simplify((-s.I)**2*(-s.I)*wick[0]*responseunit)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],x) for x in pa]+[s.kronecker_product(pa[0],s.eye(2))];ks=s.symbols('k0:4');slash=sum((k*x for k,x in zip(ks,gam)),s.zeros(4));d=s.Symbol('d')
def avg(z):
 out=0
 for powers,c in s.Poly(s.expand(z),*ks).terms():
  if any(i%2 for i in powers):continue
  out+=c*s.prod(s.factorial2(i-1) for i in powers)/s.prod(d+2*j for j in range(sum(powers)//2))
 return s.factor(out)
factors=[]
for rho in range(4):
 nf=(slash*slash*gam[rho]).applyfunc(avg);nl=(slash*slash*slash*ks[rho]).applyfunc(avg);ff=s.simplify(s.trace(gam[rho]*nf)/4);fl=s.simplify(s.trace(gam[rho]*nl)/4);zero(nf-ff*gam[rho]);zero(nl-fl*gam[rho]);zero((gam[rho]*slash*slash).applyfunc(avg)-nf);zero((ks[rho]*slash*slash*slash).applyfunc(avg)-nl);factors.append([str(ff),str(fl)])
assert len(set(map(tuple,factors)))==1;ff0=s.simplify(ff.subs(d,4));fl0=s.simplify(fl.subs(d,4))
rows=packed(CAL/'canonical_so10_fermion_gauge_vertex_support/census_tables.json.gz')['literal_auxiliary_cubic_rows'];U=[{'B':defaultdict(lambda:s.S.Zero),'A':defaultdict(lambda:s.S.Zero)} for _ in range(4)]
for row in rows:
 w=row['word'];la=next(i for i,n in enumerate(w) if n[0] in ['b','L'] and n[1:].isdigit());r=int(w[la][1:]);vec=[i for i in range(3) if i!=la];mu=int(w[vec[0]].split('_')[-1]);assert int(w[vec[1]].split('_')[-1])==mu;co=s.sympify(row['coefficient'])/g*[1,-1,-1,-1][mu]
 for pos in vec:
  target='A' if w[pos].startswith('A') else 'B'
  if target=='B' and any(w[j].startswith('A') for j in vec):continue
  other=next(j for j in vec if j!=pos);assert w[other].startswith('B');c=int(w[pos][1:].split('_')[0]);v=int(w[other][1:].split('_')[0]);U[mu][target][r,v,c]+=co
for mu in range(1,4):
 for target in ['B','A']:assert dict(U[mu][target])==dict(U[0][target])
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,yc['Tminus']));H=dec(yc['H_new']);Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);Qi=Q.inv();asm=packed(CAL/'canonical_so10_auxiliary_scalar_mass_interface/primary_tables.json.gz');UL=tidy(dec(asm['T_L'])*dec(asm['gauge_to_plane_F']).T);RH=tidy((Q[:,:12].T*Q[:,:12]).inv()*Q[:,:12].T*H);zero(Q[:,:12]*RH-H)
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};G=dec(ref['reference_Green_raw_C3']);pp=s.symbols('p0_ref0:4');sub=dict(zip(pp,[1,0,0,0]));an=[f'b{i}' if i<12 else f'L{i}' for i in range(45)]
GF=s.SparseMatrix(45,45,{(a,b):s.simplify(G[fi[f'B{a}_1'],fi[f'B{b}_1']].subs(sub)) for a in range(45) for b in range(45) if G[fi[f'B{a}_1'],fi[f'B{b}_1']]});GL=s.SparseMatrix(45,45,{(a,b):s.simplify(-G[fi[f'B{a}_0'],fi[f'B{b}_0']].subs(sub)) for a in range(45) for b in range(45) if G[fi[f'B{a}_0'],fi[f'B{b}_0']]});GM=s.SparseMatrix(45,45,{(a,r):s.simplify(-s.I*G[fi[f'B{a}_0'],fi[an[r]]].subs(sub)) for a in range(45) for r in range(45) if G[fi[f'B{a}_0'],fi[an[r]]]})
W=xi*s.eye(45)+(eta-xi)*H*H.T;zero(GF-Qi*Qi.T);zero(GL-Qi*W*Qi.T);zero(GM-Qi*UL.T)
TR=[tidy(sum((Q[a,b]*T[a] for a in range(45) if Q[a,b]),s.zeros(16))) for b in range(45)];TM=[tidy(sum((GM[b,r]*TR[b] for b in range(45) if GM[b,r]),s.zeros(16))) for r in range(45)]
def build(kind,bb):
 TV=[tidy(sum((bb[b,a]*TR[b] for b in range(45) if bb[b,a]),s.zeros(16))) for a in range(45)];n=45 if kind=='B' else 12;L=[s.zeros(16) for _ in range(n)];R=[s.zeros(16) for _ in range(n)];one=[s.zeros(16) for _ in range(n)]
 for (r,a,c),z in U[0][kind].items():
  L[c]+=phase*z*(TM[r]*TV[a]-TV[a]*TM[r]);R[c]+=phase*z*(TM[r].T*TV[a].T-TV[a].T*TM[r].T);one[c]+=phase*z*TM[r]*TV[a]
 ext=Qi if kind=='B' else RH
 return [[tidy(sum((ext[c,h]*M[c] for c in range(n) if ext[c,h]),s.zeros(16))) for h in range(n)] for M in [L,R,one]]
out={}
for kind in ['B','A']:
 L,R,one=build(kind,ff0*GF+fl0*(GL-GF));omit=build(kind,ff0*GF)[0];out[kind]={'left':list(map(enc,L)),'right':list(map(enc,R)),'only_one_mixed_placement':list(map(enc,one)),'omit_longitudinal':list(map(enc,omit))}
finish('primary_v2',{'method':'literal_all936_GF_raw_reference_Green_exterior_Gaussian_Clifford_angular','raw_U':{k:[[*idx,str(s.simplify(v))] for idx,v in sorted(U[0][k].items()) if s.simplify(v)] for k in ['B','A']},'outputs':out,'background_RH':enc(RH),'auxiliary_UL':enc(UL),'selfenergy_Gaussian_unit':str(selfunit),'inverse_response_unit':str(responseunit),'Lorentz_Wick_phase':list(map(str,wick)),'combined_phase':str(phase),'angular_factors':factors,'Feynman_residue':str(ff0),'longitudinal_residue':str(fl0),'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'open_line_extra_half':False,'family_extension':'identity_no_extra3'},start)
