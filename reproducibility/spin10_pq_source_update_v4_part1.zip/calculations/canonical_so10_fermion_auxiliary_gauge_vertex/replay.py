"""FAV1 primitive/dual-frame Lie reduction with Gaussian angular moments."""
from data import *
from collections import defaultdict
start=begin('replay')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
e1=read(PK/'frozen_a10_e1_fermion/replay.json');master=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['master_field_maps'];U={'B':defaultdict(lambda:s.S.Zero),'A':defaultdict(lambda:s.S.Zero)};positions=0
for name in [*[f'bar{i}' for i in range(12)],*[f'ub{i}' for i in range(12,45)]]:
 lam='b'+name[3:] if name.startswith('bar') else 'L'+name[2:];assert [r for r in master[name] if len(r['word'])==1]==[{'coefficient':'-1','word':[lam]}];r=int(lam[1:])
 for row in e1['Euler_columns'][name]:
  w=row['word']
  if len(w)!=2 or not all(n.startswith(('A','B')) and '__' not in n for n in w):continue
  positions+=1;mu=int(w[0].split('_')[-1]);assert int(w[1].split('_')[-1])==mu
  if mu!=0:continue
  co=-s.sympify(row['coefficient'])/g
  for pos in range(2):
   kind='A' if w[pos].startswith('A') else 'B'
   if kind=='B' and any(n.startswith('A') for n in w):continue
   other=1-pos;assert w[other].startswith('B');a=int(w[other][1:].split('_')[0]);c=int(w[pos][1:].split('_')[0]);U[kind][r,a,c]+=co
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['C3_plane_to_parent']);Qi=Q.inv();UL=s.SparseMatrix.hstack(Q[:,:12],dec(e1['charts']['blocks']['heavy_dual']['field_embedding'])).inv();yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,yc['Tminus']));H=dec(yc['H_new']);RH=tidy((Q[:,:12].T*Q[:,:12]).inv()*Q[:,:12].T*H);zero(Q[:,:12]*RH-H)
qr={a:[(b,z) for (aa,b),z in Qi.todok().items() if aa==a] for a in range(45)};ur={r:[(b,z) for (rr,b),z in UL.todok().items() if rr==r] for r in range(45)};hr={r:[(h,z) for (rr,h),z in RH.todok().items() if rr==r] for r in range(12)};Vp={}
for kind in ['B','A']:
 vp=defaultdict(lambda:s.S.Zero)
 for (r,a,c),v in U[kind].items():
  for rr,x in ur[r]:
   for aa,y in qr[a]:
    for cc,z in (qr[c] if kind=='B' else hr[c]):vp[rr,aa,cc]+=v*x*y*z
 Vp[kind]={k:s.simplify(v) for k,v in vp.items() if s.simplify(v)}
# Angular coefficients from Gaussian moments divided by radial moments.
J=s.symbols('J0:4');Z=s.exp(sum(x*x for x in J)/4);at0=dict.fromkeys(J,0);n2=sum(s.diff(Z,x,2).subs(at0) for x in J);n4=sum(s.diff(Z,x,2,J[0],2).subs(at0) for x in J);d=s.Symbol('d');ff=s.factor(n2/(d/2));fl=s.factor(n4/(d*(d+2)/4));ff0=ff.subs(d,4);fl0=fl.subs(d,4)
eps,m2=s.symbols('epsilon m2',positive=True);radial2=s.gamma(1+eps)*m2**(-eps)*(2-eps)/2;radial4=s.gamma(1+eps)*m2**(-eps)*(3-eps)*(2-eps)/6;assert radial2.subs(eps,0)==radial4.subs(eps,0)==1
# Independent Schur sign and actual ordered inverse response witness.
dx,F,v1,v2,X,Y=s.symbols('dx F v1 v2 X Y',nonzero=True);schur=s.det(s.Matrix([[dx,v1*X],[v2*Y,F]]))/F;selfunit=s.simplify((schur-dx)/(v1*v2*X*Y/F));assert selfunit==-1
w,z=s.symbols('w z');q=s.Matrix([1,0,0,0]);K=(s.eye(4)-q*q.T).row_join(q).col_join((-q.T).row_join(s.Matrix([[w]])));G=K.inv();HH=s.zeros(5);HH[1,4]=HH[4,1]=1;response=(K+z*HH).inv().diff(z).subs(z,0);zero(response+G*HH*G);responseunit=-selfunit
wick=-(-s.I)*(-1);phase=s.simplify((-s.I)**2*(-s.I)*wick*responseunit)
W=xi*s.eye(45)+(eta-xi)*H*H.T;weight=(ff0-fl0)*s.eye(45)+fl0*W;wr={a:[(b,v) for (b,aa),v in weight.todok().items() if aa==a] for a in range(45)};f=defaultdict(list)
for r,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']:f[r,b].append((c,s.sympify(v)))
outputs={}
for kind in ['B','A']:
 n=45 if kind=='B' else 12;N=s.zeros(n,45)
 for (r,a,c),v in Vp[kind].items():
  for b,x in wr[a]:
   for e,y in f[r,b]:N[c,e]+=phase*v*x*y
 N=tidy(N);L=[tidy(s.I*sum((N[c,e]*T[e] for e in range(45) if N[c,e]),s.zeros(16))) for c in range(n)];outputs[kind]={'left':list(map(enc,L)),'right':[enc(-A.T) for A in L],'adjoint_map':enc(N)}
finish('replay',{'method':'primitive_Euler_dual_frame_Lie_commutator_Gaussian_moment_Schur_inverse_response','raw_U':{k:[[*idx,str(s.simplify(v))] for idx,v in sorted(U[k].items()) if s.simplify(v)] for k in ['B','A']},'plane_U':{k:[[*idx,str(v)] for idx,v in sorted(Vp[k].items())] for k in ['B','A']},'outputs':outputs,'background_RH':enc(RH),'auxiliary_UL':enc(UL),'primitive_auxiliary_density_positions':positions,'selfenergy_Gaussian_unit':str(selfunit),'inverse_response_unit':str(responseunit),'Lorentz_Wick_phase':[str(wick)]*4,'combined_phase':str(phase),'angular_factors':[[str(ff),str(fl)]]*4,'Feynman_residue':str(ff0),'longitudinal_residue':str(fl0),'positive_IR_radial_residues':['1','1'],'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'open_line_extra_half':False,'family_extension':'identity_no_extra3'},start)
