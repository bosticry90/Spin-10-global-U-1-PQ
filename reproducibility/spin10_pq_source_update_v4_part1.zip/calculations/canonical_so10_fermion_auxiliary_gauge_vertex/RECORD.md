# FAV1: complete nonlinear auxiliary fermion/gauge vertex UV family

Question: what is the actual g10³ marginal fermion/gauge pole from the936
GF auxiliary-vector cubics, for both total B and independent fixed A? FGS1
proves these are a complete family and the only independent-A bare-action
class in this target; their values have not been measured. They are necessary
inputs before assessing the full quantum B vertex or a diagonal B=A response.

Freeze SMA1 provisional charged/sterile action, physical pp inverse with barred
numerator/full hatted denominator, actual GFK1 BB/BL/LB reference, ASM1 dual
auxiliary chart, all936 FGS1 coefficients, E1 primitive Euler columns, YCT1
generators and qualified scalar Lie constants. General g10,eta_H,xi; family
identity on three families with no extra factor three. No Yukawa/flavor value.

Primary: complete literal GF coefficients and all four Lorentz copies; actual
raw Green matrices and raw current products; explicit exterior Gaussian sign,
contour phases and barred-Clifford angular moments. Differentiate every B
factor, rather than assuming a density coefficient already equals a vertex.
Both placements of the mixed propagator and both chiral products remain.

Replay: reconstruct the density from independent E1 antighost Euler columns
and actual affine qantighost=-Lambda; use an independent dual frame and
plane transformation. Derive spin factors by Gaussian moment ratios and
the open-line sign by a Schur complement and inverse differentiation; use
qualified Lie commutators rather than direct ordered spinor products.

Fix Gaussian/contour/angular normalization before comparing results. Preserve
Feynman and longitudinal pieces separately. Do not import the old auxiliary
ghost triangle's sign: Lambda B.B has different Lorentz/Wick factors. Use a
positive temporary IR reference only to separate the UV pole, not a new mass.

After both routes finish, compare complete45B+12A current matrices and zeros,
all raw vertex coefficients, H covariance and adjoint projection. Controls
omit one mixed placement, the longitudinal contribution, the Nambu/open-line
normalization or a contour sign. Record insensitive subprojections honestly.

A POSTCALC comparator is the OLD fixed background-A component of the local
source primitive. Workers are denied that file. Its JB coefficient Zraw is
not fitted; since B is even the canonical field direction is -Zraw*A. Its
new matter pole image is -i Q Zraw RH T/(32pi²eps), with actual background
map QH*RH=H_new. Any comparison residual must be kept. This does not adopt
the old complete counterterm, erase its source-free mismatch or prove a full
quantum canonical transformation. No source BRST rule changes.

Three sequential observed workers:600s after imports each,8GiB sampled private
cap,350MiB launch floor,16MiB package cap; freeze all eight sources/inputs
before computation. Reuse this goal turn's completed fresh FGS1 E4 command
with authenticated copy. Its copied seal-label error has an immutable appended
correction; preserve both. Custody exit2/seven remains NOTPASS. No old loop replay.

Outcomes: measured family and exact matched/residual comparison, mismatch
requiring investigation, or resource INCOMPLETE. Do not tune any coefficient.
Ceiling: this bare-action UV family and a bounded counterterm projection only.
Other four B families, hatted/finite restoration, regulator-background Duhamel
terms, full source-free/QAP/measure/equivalence, finite matter C1, E5/A5 and
physical unification remain. State113/34of39 unchanged; flavor/HB1/C5 blocked
boundaries and all physical exclusions stand. No scheme/foundation adoption.

AI capability: retain nonlinear GF and ordered mixed-propagator contributions,
derive their actual signs, and compare with prior evidence without fitting.
Shared physical premises, action/Lie data, SymPy/runtime and AI author limit
independence. RESULT/receipt will record full evidence, failures and resources.
