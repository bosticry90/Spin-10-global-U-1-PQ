# FAV1 bounded raw-mixed conversion correction V2

V1 primary FAILED at its required raw Green conversion invariant before
emitting any loop coefficient; replay and verifier were not launched.
Keep V1 source/copy, full native primary capture and controller failure.

A separate read-only bounded diagnostic authenticated the same inputs and
found zero Feynman/longitudinal residuals,47 wrong-sign mixed-map positions,
and zero residual after negating that extraction. It also derived the exact
Minkowski2x2 inverse: K_M=[[0,ip],[-ip,w]] has G_M,BL=+i/p. With inherited
p_M0=iq, R=diag(i,-i) and K_E=-R^T K_M(iq)R, G_E,BL=-1/q. Thus the raw
positive mixed COLOR map is -i G_M,B0Lambda at p0=1, not+i times it.

V2 corrects ONLY that extraction, keeps all three raw-reference invariants
and the independent contour/Gaussian/angular/group/old-A tests, and names
its new output primary_v2. No density, width, physical scheme or desired
pole was changed. The independent original replay has not run and remains
unchanged; execute it after corrected primary, then the verifier with only
its new input/output paths. Both methods must still agree.

Freeze these new sources/copies and diagnostic bytes before execution.
Same600s/8GiB sampled/350MiB floor/16MiB bounds. Another distinct failure
requires reassessment; no automatic requirement weakening or favorable
coefficient adjustment is authorized. Diagnostic source/full capture remain
external and bound by preparation_v2. Its execution is not scientific acceptance.
