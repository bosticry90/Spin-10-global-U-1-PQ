# FAV1: complete auxiliary fermion/gauge UV family and matched A projection

QUALIFIED_COMPLETE_AUXILIARY_FERMION_GAUGE_VERTEX_UV_FAMILY.
Receipt SHA256
2e7f0c4fa65186b2df73d4561319856ebb413d50f904fe3bbcf60d73bbb5762c.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 unchanged.

The complete nonlinear auxiliary family has now been calculated for all45
total-field B directions and all12 independent orthonormal H-background A
directions. Both routes agree at all29184 left/right current positions,
including their zero complement and all four Lorentz copies.

| External target | Nonzero left/right current positions | Adjoint-map entries | Generic map rank |
| --- | ---: | ---: | ---: |
| Total B,45 directions | 715 each | 105 | 44 |
| Independent A_H,12 directions | 92 each | 23 | 11 |

These are algebraic coefficients and generic formal ranks, not particle or
experiment counts. Gauge widths remain symbolic, with no special values chosen.
The independent-A nullspace is retained rather than inferred from a numerical
cutoff. No diagonal B=A background limit is taken.

In the inverse-fermion-operator vertex the pole has common g10³/(16pi²eps)
factor and barred gamma_rho, with current matrices

    L_c^X=i sum_e M_ce^X T_e,   R_c^X=-(L_c^X)^T,
    M_ce^X=sum_(r,a,d) Uplane_(r a c)^X [(3I+W)/4]_(d a) f_(r d e),
    X=B or A,  W=eta_H P_H+xi P_M.

U is the derivative of the actual g10-stripped936-position GF density,
including every repeated-B differentiation factor. The full exact matrices,
raw tensors and coefficient maps are stored in paired compressed tables.
Both mixed placements and the longitudinal BB term are necessary: omitting
either changes both target results. There is no closed-loop half or extra
family multiplicity.

## Normalization and distinct derivations

Primary uses all literal936 coefficients, actual raw643-field reference
Green entries and the qualified raw/plane auxiliary map. It derives the
open-line minus by an exact exterior Gaussian, the inverse-response sign,
all Lorentz/Wick factors and the barred-Clifford angular moments. Replay
reconstructs the actual density through E1 antighost Euler columns, uses an
independent dual frame, Schur/inverse-response and Gaussian moment derivations,
then Lie commutators instead of direct ordered spinor products.

The Feynman and longitudinal pole units are1 and1/4, from4/d and6/[d(d+2)].
The scalar radial residues are1 with a positive temporary IR reference. The
Lambda B.B Wick coefficient is-i, distinct from the earlier Lambda a C
source diagram. Combined with the two gauge vertices, physical fermion
numerator and inverse response this gives phase1. Finite evanescent terms,
finite amplitudes and physical IR removal are not computed or declared zero.

Only after both results existed, the verifier extracted the actual old fixed
JB-Zraw-A generator component. Its new matter pole image is
-i*(Q Zraw RH)^T T/(32pi²eps), with QH*RH=H_new and the original32-to16
conversion. It matches the measured independent-A map exactly: remainder0.
No old coefficient or loop contribution was fitted or changed. This is a
source-free matter projection of a fixed normalization direction, not adoption
of the complete old counterterm or a quantum canonical-equivalence theorem.

## Preserved failed run and provenance correction

V1 primary FAILED before emitting a loop coefficient at its raw mixed-Green
invariant. The attempted extraction used+i G_M,B0Lambda instead of-i times it.
A separate bounded read-only diagnostic found47 wrong-sign map positions,
zero Feynman/longitudinal residuals and zero corrected mixed residual. It
also derived the exact two-by-two Minkowski inverse G_M,BL=+i/p and its
inherited Euclidean conversion G_E,BL=-1/q. V2 corrects only this extraction;
all physical inputs, contour factors, raw invariants, independent replay and
post-calculation tests remain. V1 source/copy/native capture/controller failure
and the diagnostic source/full capture are preserved. No V1 PASS is claimed.

Corrected primary62.6152783s, replay35.0287497s, verifier21.6604295s after
imports, all exit0.32/18/12 samples have private maxima67641344/82935808/
509870080 bytes, not continuous peaks. The failed V1 primary has2 samples,
maximum53837824 bytes; the read-only diagnostic completed exit0 with2 samples,
maximum56492032 bytes.600s/8GiB sampled/350MiB floor/16MiB bounds were
unexhausted.49 original/69 final validation bindings, separate V2 freeze and
twelve exact source copies retain the complete evidence. No verifier failed.

Readiness is authenticated reuse of this goal turn's fresh FGS1 E4 execution,
not another run. FGS1's copied post-commit label incorrectly described reuse;
its immutable appended correction, SHA256
1d63bc8c13e185da75c9bfa318f17674112f2cb4d0a3073f20049c42dacb8fd2,
records the actual fresh execution without editing the original seal. FAV1
binds that correction. Historical custody remains exit2/seven NOTPASS.

## Limits and next action

One of five quantum-B topology families is now measured. The other four
(gauge-fermion, cubic-vector, Yukawa-fermion and scalar-current) remain to be
calculated in this proper-vertex construction. The independent-A result is
complete only for FGS1's bare-action marginal sector. Regulator-background
Duhamel responses, finite parts, hatted restoration and diagonal-background
matching are separate obligations. Homogeneous H covariance is checked;
no complete local Ward, full source-free/QAP/measure or physical C1 is claimed.

The next informative calculation is the complete gauge-fermion triangle at
g10³, with actual two-width matrices and physical pp inverse, followed by
the cubic-vector class before a full pure-gauge vertex assembly. Use the
source normalization results as later comparators, never to assign a loop.
The two g10 Y² families remain separate with general family matrices.

This is internal computational corroboration with shared action, group data,
software/runtime and AI author. It demonstrates a relevant sign error being
caught by an actual reference-inverse test, while preserving the failed run.
It is not independent scientific confirmation. No scheme, flavor point or
foundation is adopted. E5/A5, physical matching/unification, the original
benchmark exclusions,140% singlet warning, flavor pause, HB1/C5 blocks,
quartet failure and historical custody remain unchanged.
