# FAV1 routing and normalization fixed before model contraction

Let the fermion line S_pp(k) run from the external-bar-fermion vertex1 to
the external-fermion vertex2. Bosonic momenta at these vertices are -k and+k.
At vertex1 G_BL(-k)=+k/Q; at vertex2 G_BL(+k)=-k/Q, equivalently the latter
placement is the ordered G_LB(-k). BB is even in k. Do not symmetrize BL/LB
as a finite zero-momentum covariance or identify the two signs.

Integrating the internal fermion gives self-energy -V S V G_BB, as can be
derived by an exact exterior Gaussian or the block Schur complement. A cubic
auxiliary/external-vector insertion H changes G by -G H G. Thus the required
vertex is +V S V G H G, with two ordered mixed placements. It is an open
line: the alternating Nambu half is canceled by two polarized placements;
there is no closed-loop Pfaffian factor1/2 or extra family trace.

For Lambda B.B or Lambda A.B, the inherited Wick map gives coefficient phase
(-1)*(-i)*(i*i)=-i for the temporal Lorentz component, and the same value
from the spatial metric signs. The global action minus, Lambda_M=-iLambda_E
and both vector rotations are separate from the fermion/gauge vertices.
The product of two -i gauge vertices, -i fermion numerator and -i auxiliary
coefficient is+1 after the inverse-response/open-line sign is established.

The mixed contraction reduces the numerator to bar_k² times the remaining
vector vertex. With barred rank4 and dimensional loop rank d, the angular
Feynman factor is4/d, the longitudinal factor6/[d(d+2)]. Each radial UV
residue is1 in16pi²eps units with a positive temporary IR reference.
Consequently an internal vector width w has pole factor

    4/d + (w-1)*6/[d(d+2)] -> (3+w)/4 at d=4.

Finite evanescent/IR terms are not evaluated or set zero. Both factors are
derived independently by the workers. They are not fitted to a Ward target.

The raw source-free tensor is the derivative of the actual density with
respect to the external B or A. A repeated B factor must be differentiated
with its multiplicity. For each raw Lambda_r/internal-vector_a/external_c,
the pole is the commutator of the mixed-line and weighted-BB current matrices.
Primary computes it in the raw frame; replay transforms to the actual plane
frame and uses the Lie constants. The right product is derived with ordered
transposed current matrices, not a substituted Hermitian conjugate.

Bplane=Q Braw, Lambdaraw=UL Lambdaplane, with UL=ASM.T_L*F^T independently
equal to (QH,FM)^-1. Background Araw=RH Aorth_H where QH RH=H_new. The old
background counterterm comparison uses the SAME maps and common32-to16
factor. Independent-A partial differentiation remains distinct from B=A.
