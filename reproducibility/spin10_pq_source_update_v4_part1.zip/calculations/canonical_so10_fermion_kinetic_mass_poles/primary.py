"""FKP1 direct mass-expanded current loop and shifted scalar bubble."""
from data import *
from itertools import product
start=begin('primary');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.kronecker_product(pa[1],q) for q in pa]+[s.kronecker_product(pa[0],s.eye(2))];PL=s.diag(1,1,0,0);PR=s.eye(4)-PL;Ps=[PL,PR]
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,d['Tminus']));PN=dec(d['P_N'])
def tr(A,B):return s.simplify(sum(v*B[j,i] for (i,j),v in s.SparseMatrix(A).todok().items()))
kin={};pair={}
for mu,nu in product(range(4),repeat=2):
 kin[mu,nu]=[[s.simplify(-sum(s.trace(gam[mu]*Ps[i]*gam[al]*gam[nu]*Ps[j]*gam[al]) for al in range(4))/8) for j in range(2)] for i in range(2)]
 pair[mu,nu]=[[-s.trace(gam[mu]*Ps[i]*gam[nu]*Ps[j])/2 for j in range(2)] for i in range(2)]
F=s.zeros(45);kinpart=s.zeros(45);pairpart=s.zeros(45)
for a,b in product(range(45),repeat=2):
 ac=[T[a],-T[a].T];bc=[T[b],-T[b].T]
 paths=[[tr(ac[i]*PN,bc[j])+tr(ac[i]*bc[j],PN) for j in range(2)] for i in range(2)]
 masspaths=[[tr(ac[i]*PN,bc[j]*PN) for j in range(2)] for i in range(2)]
 for mu,nu in product(range(4),repeat=2):
  k=s.simplify(sum(kin[mu,nu][i][j]*paths[i][j] for i,j in product(range(2),repeat=2)))
  p=s.simplify(sum(pair[mu,nu][i][j]*masspaths[i][j] for i,j in product(range(2),repeat=2)))
  if mu==nu==0:kinpart[a,b]=k;pairpart[a,b]=p;F[a,b]=k+p
  else:assert s.simplify(k+p-int(mu==nu)*F[a,b])==0
# Independently normalize the scalar bubble, including the hatted external
# derivative pole. The complete slash identity leaves an explicit hat term.
x,qb,qh,dim=s.symbols('x qb qh d');u=x*(1-x);qtotal=qb+qh
full_dot_pole=-qtotal/2
hat_dot_pole=(dim-4)/dim*(-2*u*qtotal)-u*qh
scalar=s.simplify(-2*(full_dot_pole-s.integrate(hat_dot_pole.subs(dim,4),(x,0,1))))
assert s.simplify(scalar-qb-s.Rational(2,3)*qh)==0
Bs=[dec(d['B10']),dec(d['B126'])]
metrics=[s.SparseMatrix(B.H*B).applyfunc(lambda z:s.simplify(s.re(z))) for B in Bs];cross=s.SparseMatrix(Bs[0].H*Bs[1]).applyfunc(s.simplify)
finish('primary',{'method':'actual_current_mass_expansion_with_direct_physical_spin_traces','unit_mass_vector_pole':enc(F),'kinetic_mass_roles':enc(kinpart),'mass_pair_role':enc(pairpart),
 'scalar_metrics':list(map(enc,metrics)),'cross_scalar_metric':enc(cross),'scalar_bar_derivative_pole':str(scalar.coeff(qb)),'scalar_hat_derivative_pole':str(scalar.coeff(qh)),
 'vector_Lorentz_color_slots_checked':16*2025,'mass_spurion_or_orbit_used_to_assign_loop':False,'new_one_loop_pole_families':2,'new_two_loop_integrals':0,'provisional_only':True},start)
