"""FKP1 actual complete-pole comparison and model-specific consistency tests."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_v2_tables.json.gz')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
F=dec(P['unit_mass_vector_pole']);zero(F-dec(R['unit_mass_vector_pole']));zero(F-F.T);assert F.rank()==21
assert F.eigenvals()=={s.S.Zero:24,s.Rational(1,2):20,s.Rational(5,2):1} and s.trace(F)==s.Rational(25,2)
for a,b in zip(P['scalar_metrics'],R['scalar_metrics']):zero(dec(a)-dec(b))
H10,H126=list(map(dec,P['scalar_metrics']));cross=dec(P['cross_scalar_metric']);zero(cross-dec(R['cross_scalar_metric']));zero(cross)
ph=s.zeros(328);sg=s.zeros(328)
for i in range(306,326):ph[i,i]=s.Rational(1,2)
for i in range(54,306):sg[i,i]=s.Rational(1,2)
zero(H10-ph);zero(H126-sg);assert s.trace(H10)==10 and s.trace(H126)==126
assert P['scalar_bar_derivative_pole']==R['scalar_bar_derivative_pole']=='1'
assert P['scalar_hat_derivative_pole']==R['scalar_hat_derivative_pole']=='2/3'
yr=read(CAL/'canonical_so10_yukawa_carrier_transport/validation_receipt.json');scale=s.sympify(yr['reference_sigma_squared'])*s.sympify(yr['abs_c_N_squared']);assert scale==s.Rational(3,10)
orbitmass=dec(R['scalar_orbit_mass_pole_per_k126']);zero(orbitmass-scale*F)
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,yc['Tminus']));PN=dec(yc['P_N']);H=dec(yc['H_new'])
S=[t.T*PN+PN*t for t in T];gram=s.Matrix(45,45,lambda a,b:s.simplify(s.re(s.trace(S[a].H*S[b]))));zero(gram-F);zero(F*H)
fg=packed(CAL/'canonical_so10_fermion_goldstone_interface/primary_v2_tables.json.gz');O=dec(fg['orbit']);GG=dec(fg['vector_Gram']);zero(F*GG-GG*F);zero(O.T*H10*O)
sectors=[]
for E,row in zip(map(dec,fg['vector_projectors']),fg['vector_resolved']):
 co=s.simplify(s.trace(E*F)/row['rank']);zero(F*E-co*E)
 sectors.append({'sector':row['sector'],'lambda':row['lambda'],'rank':row['rank'],'unit_mass_pole_eigenvalue':str(co),'per_k126_vector_pole':str(scale*co)})
assert [v['unit_mass_pole_eigenvalue'] for v in sectors]==['0','1/2','5/2','0','1/2']
# Independent failure controls: the commutator loses the self-current,
# and its trace must not be accepted as the Majorana mass variation.
wrong=[t*PN-PN*t for t in T];wrongnorm=s.simplify(sum(s.trace(w.H*w) for w in wrong));assert wrongnorm==10 and wrongnorm!=s.trace(F)
assert F!=2*F and orbitmass!=3*orbitmass and H126!=2*H126
dim=s.Symbol('d');a=s.sympify(R['case0_angular_bar_fourth']);b=s.sympify(R['case0_angular_bar_pair_fourth']);assert s.simplify(a.subs(dim,4)-1)==0 and s.simplify(b.subs(dim,4)-s.Rational(1,4))==0
assert not R['full_one_loop_finite_reference_equivalence_claimed']
for D in [P,R]:assert D['new_one_loop_pole_families']==2 and D['new_two_loop_integrals']==0 and D['provisional_only']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_FERMION_SCALAR_KINETIC_AND_VECTOR_MASS_POLE_MATCH','elapsed_after_imports':time.perf_counter()-start,
 'vector_color_positions_compared':2025,'vector_Lorentz_color_slots_checked':P['vector_Lorentz_color_slots_checked'],'scalar_metric_positions_compared':2*328**2,
 'complex_cross_metric_positions_checked':328**2,'scalar_orbit_vector_positions_compared':2025,'unbroken_kernel_positions_checked':540,
 'scalar_bar_derivative_pole_per_metric':'1','scalar_hat_derivative_pole_per_metric':'2/3','canonical_scalar_wavefunction_loop_pole_per_kappa':'1/(32*pi^2*epsilon)',
 'candidate_bar_covariant_kinetic_density_prefactor':'1/(32*pi^2*epsilon)','unit_mass_vector_pole_trace':'25/2','unit_mass_vector_pole_rank':21,
 'unit_mass_vector_pole_eigenvalues':{'0':24,'1/2':20,'5/2':1},'physical_vector_mass_pole_per_k126':'(3/10)*F','sectors':sectors,
 'scalar_wavefunction_ranks':{'phi':20,'Sigma':252,'Phi':0,'S':0},'cross10_126_local_kinetic_pole':'0','finite_mixed_threshold_excluded':False,
 'case0_case1_UV_residue_match_only':True,'finite_reference_conversion_qualified':False,'hat_derivative_pole_retained':True,
 'wrong_commutator_norm':'10','extra_family_factor_rejected':True,'new_one_loop_UV_pole_families':2,'new_two_loop_integrals':0,
 'full_gauge_scalar_source_evanescent_counterterm_or_QAP_qualified':False,'physical_flavor_mass_or_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
