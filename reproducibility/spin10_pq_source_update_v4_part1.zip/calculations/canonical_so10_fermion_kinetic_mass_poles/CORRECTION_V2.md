# FKP1 V2: exact angular-expression normalization

The original primary completed. ReplayV1 failed before its model contractions
at a structural SymPy equality between equivalent rational angular moments.
Its source/copy, FAILEDcapture and controllerfailure remain unchanged. No
replaytable, gate execution, validationpreparation or qualifiedreceipt existed.
The original verifier was NOT_LAUNCHED after the dependency failure.

Replace only the two rational-expression structural comparisons by exact
zero-of-difference comparisons. A negative control must still reject an
incorrect angular sign. This is a verification-harness normalization fix,
not a changed physical input, angular identity, tolerance or acceptance gate.
The executed V2source retains this correction explicitly. Reuse completed
primary bytes after authentication; do not rerun its model calculation.

Freeze this record, new replay/verifier/controller sources and copies,
originalpreparation/source/failure bytes and qualifiedupstreams first.
ReplayV2 cannot import primaryoutputs; parentcontroller authenticates them
separately. After replayV2 completes, freeze a separate validationpreparation
including reusedprimary and newreplay evidence. GateV2 makes the same original
scientific checks against replayV2. All paths new; old evidence immutable.

Same600s/8GiBsampled/350MiBlaunchfloor/16MiBpackage bounds. Observedsequential
replayV2 then gateV2 only; no agents. Preserve any failed/unfinished newrun
with its own capture. No scientific/foundational promotion, sourcephase/
scheme adoption or numericalflavor/mass change. Authority34/39, E5/A5
unqualified, flavorpaused,HB1/C5blocked,custodyexit2/seven NOTPASS unchanged.
