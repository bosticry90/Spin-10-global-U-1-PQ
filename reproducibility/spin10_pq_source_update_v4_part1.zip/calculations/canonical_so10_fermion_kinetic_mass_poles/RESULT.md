# FKP1: independently derived scalar kinetic and vector mass poles agree

The actual fermion-loop scalar kinetic residue and vector mass residue have
been calculated separately and agree when contracted through the model's
scalar orbit. This qualifies two one-loop UV pole families in the provisional
matter construction. It supplies a necessary parent-counterterm input, not a
finite fermionic threshold, full gauge completion, or physical spectrum.

Receipt `validation_receipt_v2.json` has SHA-256
`c0e8ecdcea6776433be31abc513bb5532512a358e7c8eb22e6f46e2ae720df06` and status
`QUALIFIED_FERMION_SCALAR_KINETIC_AND_VECTOR_MASS_POLE_MATCH`.
Scientific/director acceptance is NOT_PERFORMED. State113 and authority34/39
remain unchanged.

## What was calculated

Use the authenticated YCT1 symmetric mass maps on all328 real scalar
coordinates. Let `k_R=Tr_family(Y_R^dagger Y_R)` for R=10,126. Each trace already
includes all three families; it must not receive an additional factor of3.
The off-diagonal entries of a symmetric family matrix have weight2.

For `H_R,ab=Re Tr_internal(B_Ra^dagger B_Rb)`, the actual coefficient tables give

```
H_10  = (1/2) P_phi,       rank20,
H_126 = (1/2) P_Sigma,     rank252,
B_10^dagger B_126 = 0     as a complex328x328 matrix.
```

The Phi54 and singlet directions have zero kinetic pole from these Yukawa
vertices. The complex cross identity excludes the mixed local quadratic
kinetic pole in this calculation. It does not exclude finite mixed thresholds.
Both full328x328 metrics and all328x328 complex cross positions, including
their zero complements, were compared by matrix Gram products versus explicit
column inner products.

The independently normalized scalar two-point loop is

```
Pi_ab,pole = (k_10 H_10,ab + k_126 H_126,ab)
             * (bar q^2 + (2/3) hat q^2)/(16 pi^2 epsilon).
```

The hatted external derivative pole is retained. On the physical scalar
coordinates the barred wavefunction loop pole is `k_R/(32 pi^2 epsilon)`;
the counterterm has the opposite sign. The primary uses a shifted scalar
bubble identity with its explicit hatted moment; replay uses Feynman parameters
and the radial UV residues. These are not coefficients inferred from a Ward
cancellation. Their normalization agrees with the scalar self-energy structure
in [Belusca-Maito et al., Sec5.2.1](https://arxiv.org/pdf/2004.14398), after
matching the actual model's Yukawa trace convention rather than importing an
irreducible-scalar coefficient.

## Independent vector loop and the orbit comparison

The current loop uses all45 actual internal generators and the unit neutral
mass spurion PN. It retains both two-insertion line roles and the mass-pair
role, the Majorana closed-loop half, and the physical spin trace4. All16 barred
Lorentz slots and all2025 color positions are checked. The primary uses SMP1's
explicit mirror-mass auxiliary reference. Replay uses the actual massless
auxiliary Born expansion. Their angular factors differ away from d=4 but have
the same UV residue. Their finite parts are not proved equal.

The resulting unit-mass tensor F has rank21, trace25/2 and eigenvalues
`0[24], (1/2)[20], (5/2)[1]`. A separate mass-spurion calculation gives

```
F_ab = Re Tr[(T_a^T PN + PN T_a)^dagger (T_b^T PN + PN T_b)].
O^T H_126 O = (3/10) F,       O^T H_10 O = 0,
```

using the actual328x45 scalar orbit O. The physical vector loop pole is
`g_10^2 k_126 (3/10) F/(16 pi^2 epsilon)`. The factor3/10 is the independently
qualified neutral relation `sum_i mu_i^2=(sigma^2/2)k_126`, with sigma^2=3/5.
No Yukawa eigenvalue or physical neutrino mass is selected.

| Vector sector | Rank | Vector mass squared/g_10^2 | Eigenvalue of F | Pole weight per k_126, before g_10^2/(16pi^2epsilon) |
| --- | ---: | ---: | ---: | ---: |
| r0 | 12 | 0 | 0 | 0 |
| r1 | 8 | 3/10 | 1/2 | 3/20 |
| r2 | 1 | 3/2 | 5/2 | 3/4 |
| r3 | 12 | 25 | 0 | 0 |
| r4 | 12 | 253/10 | 1/2 | 3/20 |

These are loop-pole coefficients, not finite physical mass shifts. The full
unbroken12-generator kernel is checked. Replacing the symmetric-mass
transformation by an adjoint commutator gives norm10 rather than25/2 and is
rejected. Extra family or Gaussian factors and the wrong real/complex scalar
normalization are also rejected.

The two projections agree with the candidate barred local density
`+Tr[(D_bar M)^dagger D_bar M]/(32pi^2epsilon)`. This comparison does not
determine the odd-gauge-coupling scalar current sign or prove the full
gauge/scalar/source completion. The separate hatted derivative pole also
requires its actual evanescent completion before a complete forest or QAP
claim. No finite normalization constant is fitted or fixed.

## Execution, correction and limits

The original primary completed in10.7396798s after imports. ReplayV1 failed
before model contractions: structural SymPy equality rejected equivalent
rational angular expressions. Its exact source/copy, FAILED capture and
controller failure remain. The original verifier was NOT_LAUNCHED and has no
receipt. CORRECTION_V2 freezes zero-of-difference comparisons plus a wrong-sign
control; no scientific equation, tolerance or physical input changes.

ReplayV2 completed in13.1265095s and the separate gate in1.5742105s. The primary
was authenticated and reused, not rerun. The peer-output denial remained
active. Successful primary/replayV2/gate captures have6/8/2 private-memory
samples, maxima52,461,568/55,955,456/51,392,512 bytes; these are sampled maxima,
not peaks. The failed replay has one startup sample397,312 bytes. Bounds were
600s per worker,8GiB sampled private allocation,350MiB launch floor and16MiB
package. No bound was exhausted. Original/V2/gate preparations bind42/13/60
paths and11 source copies are preserved. External full captures are retained
under `fermion-kinetic-mass-poles-v1-2026-10-22`.

There are two new one-loop UV pole families and zero new two-loop integrals.
Shared action definitions, input tables, symbolic runtime, conventions and AI
authorship limit independence. This is internal computational corroboration,
not external confirmation of the model. The scalar methods share their radial
UV master assumptions; the two vector references only test residue agreement.

Historical E4 readiness is checked with its frozen context; custody remains
exit2/seven unresolved NOTPASS. Full finite scheme conversion, determinant
phase/measure, evanescent gauge/source terms, QAP and full matter C1 remain
unqualified. Both scalar points' negative quantum evidence is unchanged. No
numerical flavor work, physical benchmark or scheme adoption, E5/A5 promotion,
HB1/C5 activation, historical editing or external action occurred.

The next inexpensive useful input is the actual fermion Yukawa self-energy
pole with its full family matrix retained. Search for existing evidence first;
then use the complete real-scalar maps and a separate representation-theory
sum to avoid either a scalar-family-trace substitution or a duplicate loop.
