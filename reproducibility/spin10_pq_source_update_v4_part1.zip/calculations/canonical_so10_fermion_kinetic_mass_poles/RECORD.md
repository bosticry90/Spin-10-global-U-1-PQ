# FKP1: independent Yukawa scalar-kinetic and vector-mass UV poles

Basea40e4fe91a39afa45a41e595eeb28f3189db7695/main,30205trackedblobs.
Actual preflight clean/no matchingworkers. Previousgoalturn PROGRESS:SMA1
fullprovisionalaction and SMP1 finite-hat massiveinverse. Wholegoalactive.
Question: do actual fermion-loop scalar-kinetic and vector-mass residues
give the same required covariant local normalization? This supplies a
parent-counterterm input, not a fitted finite threshold or fullrestoration.

Freeze currentAGENTS/CHARTER/state113/34of39,V484/local/solo conventions;
YCT1 completeprimary/replayB10/B126/T/PN/Mvac/receipts; FGI1 actualorbit/
vectorprojectors/receipt; SMA1ACTION/receipt, SMP1inverse/receipt, CSC1/FSN1
statistics/pole evidence. All oldinputs/failures/physical exclusions unchanged.
No numericalYukawa, flavorfit, new physicalmass/benchmark or regulatoradoption.

Use full328realcanonical scalar frame. M(x)=Y10 tensorB10*x+Y126 tensorB126*x,
symmetricfamilyY remain general. k10=Tr(Y10daggerY10),k126=Tr(Y126daggerY126)
already include the threefamilies; never multiply them by3again. Retain
offdiagonalfamilycoordinate weight2. Crossfamilygram is allowed in the
theory, but calculate whether its scalar-kinetic UVtensor vanishes rather
than infer finite mixed thresholds vanish.

One-loop EuclideanlocalUV residues only, d=4-2epsilon, physicalexternal
vectorindices barred. Normalize loopUVpole as1/(16pi²epsilon). Nambuclosed
fermionfactor1/2 fromFSN/SMA, physicalspintrace4. Scalarbubble at nonzero
q²>0: retain separate barq² andhatq² residues, including its EV derivative
pole needed by laterforests. UVmasspole is the coefficient of physicalmu²
in the largep degree-4 expansion at externalq0, not a scaleless fullgraph.
A positive auxiliaryIRmass in the logmaster defines its UVresidue without
choosing a physicalmass. Powerdivergence/IR/finite parts stay outside scope.

Primary vector route: actual45 currents Gamma=bar_gamma(PLTa-PRTa^T) and
formalunit neutralmass mu*PN in a Takagi coordinate. Expand SMPcase1 pp
propagator S0=-ibar_slash/p²,S1=muPN/p²,S2=+imu²bar_slashPN/p⁴. Derive
the two mass-insertion roles and direct mass-pair trace with the closed-loop
sign, all16 Lorentzslots/all2025colorpairs, includingzeros. Do not set the
answer from scalar covariance. Familyextension sum mu_i²=(sigma²/2)k126
uses the already derived symbolicmass relation, not a chosen spectrum.

Replay vector route: derive case0 Born insertion residues using its actual
pp propagator S1=muPN*barp²/p⁴,S2=imu²bar_slashPN*barp²/p⁶. Hatted factors
give angularmoments <barp⁴/p⁴>=24/[d(d+2)] and
<barp_alpha barp_beta barp²/p⁴>=6delta/[d(d+2)]. Derive these from rotational
moments and retain their rationald dependence. Show residue agreement with
case1; differences proportionald-4 can affect finite parts and must not be
called zero amplitudes or a quantumschemeconversion.

Independent scalar route: compute the Majorana mass-vertex bubble at general
externalbarq/hatq, derive both derivativepole coefficients by explicitspin
traces and Feynman-parameter integrals. Primary additionally uses the
shift/tadpole identity with the hattedmoment kept. No coefficient is assigned
from a desired zero Ward identity. Derive the actual real H_R=Re(B_RdaggerB_R)
and crossR tensors on all328columns; compare to the independent projectors.

Then contract the scalar-loop metric with the ACTUAL328x45orbit, and compare
its vector-mass residue against the independently derived current loop.
All45x45positions/zero complement retained. Project onto the five measured
vector mass sectors to identify legitimate zeros. Keep the transpose law
T^T M+MT, not an adjointcommutator. Distinguish rank/coefficients of formal
unitmass tensors from physical amplitudes at unknown Y values. The scalar
hat derivative pole is explicit; full gauge/scalar/source evanescent vertices
and fullnonAbelian counterterm completion are not assumed supplied by it.

Normalization anchors: FSN1 gaugepole and SMA1 Gaussian plus Belusca-Maito
et al.2004.14398v2 Sec5.2.1, https://arxiv.org/pdf/2004.14398 . Its scalar
Yukawatrace convention is compared explicitly, not imported as a coefficient
for this reducible328field theory. Spin10/representation assumptions, input
data, Python/SymPy and AIauthor remain shared; no external confirmation.

Separate gate: fulltensors/loopresidues, positivity/symmetry, actualHkernel,
Goldstone/sectorprojection and allscalarcoordinates. Controls: omittedNambu
half, extra3familyfactor, wrongtranspose/commutator, scalarpartialdomain,
wrong canonicalcomplex-normalization, omittedEVpole and premature finite-
amplitude interpretation. Poleagreement is insensitive to one-loop finite
regulator differences; disclose it. No finite fermioncounterterm is fitted.

Freeze7sources/copies and inputhashes before sequentialprimary/replay/gate.
600s each afterimports,8GiBsampled,350MiBlaunchfloor,16MiBpackage. Preserve
failed/unfinishedruns; versionfixes. No agents. Scientific/directoracceptance
NOT_PERFORMED,authority34/39,E5/A5unqualified,flavorpaused,HB1/C5blocked,
custodyexit2/seven NOTPASS. No physicalscheme/benchmarkadoption or external
action; both scalarpoints' negativequantumcontrol evidence remains intact.
