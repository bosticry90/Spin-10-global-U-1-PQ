"""FKP1 case0 Born residues and independent scalar/orbit contraction."""
from data import *
from itertools import product
start=begin('replay');
for path,hv in read(HERE/'continuation_preparation_v2.json')['input_sha256'].items():assert digest(Path(path))==hv,path
dim=s.Symbol('d');x,qb,qh=s.symbols('x qb qh');u=x*(1-x);Delta=u*(qb+qh)
# Rotational fourth moments follow from the two contractions of
# <p_i p_j p_k p_l>/p^4=(deltas)/(d(d+2)), with four barred directions.
bar_fourth=4*(4+2)/(dim*(dim+2));bar_pair_fourth=(4+2)/(dim*(dim+2));bar_pair=1/dim
assert s.factor(bar_pair_fourth-bar_pair+(dim-4)/(dim*(dim+2)))==0
assert s.factor(bar_fourth-1+(dim-4)*(dim+6)/(dim*(dim+2)))==0
assert s.factor(bar_pair_fourth-bar_pair-(dim-4)/(dim*(dim+2)))!=0
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],q) for q in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g=[s.kronecker_product(q,pa[2]) for q in g4];PL=s.kronecker_product(s.diag(1,1,0,0),s.eye(2));PR=s.eye(8)-PL;Ps=[PL,PR]
kin=[[s.simplify(-bar_pair_fourth*sum(s.trace(g[0]*Ps[i]*g[a]*g[0]*Ps[j]*g[a]) for a in range(4))/4) for j in range(2)] for i in range(2)]
mass=[[-bar_fourth*s.trace(g[0]*Ps[i]*g[0]*Ps[j])/4 for j in range(2)] for i in range(2)]
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,d['Tminus']));PN=dec(d['P_N'])
def tr(A,B):return s.simplify(sum(z*B[j,i] for (i,j),z in s.SparseMatrix(A).todok().items()))
F=s.zeros(45)
for a,b in product(range(45),repeat=2):
 ac=[T[a],-T[a].T];bc=[T[b],-T[b].T];result=0
 for i,j in product(range(2),repeat=2):
  result+=kin[i][j]*(tr(ac[i]*PN,bc[j])+tr(ac[i]*bc[j],PN))+mass[i][j]*tr(ac[i]*PN,bc[j]*PN)
 F[a,b]=s.simplify(result.subs(dim,4))
# Scalar route uses direct Feynman parameters and the analytic radial poles
# Res I2=1, Res J2=-2Delta. No vector-Ward target enters this derivation.
scalar=s.simplify(s.integrate((-2*((4/dim)*(-2*Delta)-u*qb)).subs(dim,4),(x,0,1)))
Bs=[dec(d['B10']),dec(d['B126'])]
# Sum actual column inner products rather than primary's matrix Gram product.
metrics=[];allcols=[]
for B in Bs:
 cols=[{i:z for (i,j),z in s.SparseMatrix(B[:,k]).todok().items()} for k in range(328)]
 allcols.append(cols)
 H=s.SparseMatrix(328,328,{})
 for i,a in enumerate(cols):
  if not a:continue
  for j,b in enumerate(cols):
   if not b:continue
   val=s.simplify(s.re(sum(s.conjugate(v)*b.get(k,0) for k,v in a.items())))
   if val:H[i,j]=val
 metrics.append(H)
cross=s.SparseMatrix(328,328,{})
for i,a in enumerate(allcols[0]):
 if not a:continue
 for j,b in enumerate(allcols[1]):
  if not b:continue
  val=s.simplify(sum(s.conjugate(v)*b.get(k,0) for k,v in a.items()))
  if val:cross[i,j]=val
fg=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz');O=dec(fg['orbit']);projected=s.SparseMatrix(O.T*metrics[1]*O).applyfunc(s.simplify)
finish('replay_v2',{'method':'case0_ordered_Born_residue_and_independent_scalar_bubble_orbit','unit_mass_vector_pole':enc(F),'scalar_metrics':list(map(enc,metrics)),'cross_scalar_metric':enc(cross),
 'scalar_bar_derivative_pole':str(scalar.coeff(qb)),'scalar_hat_derivative_pole':str(scalar.coeff(qh)),'scalar_orbit_mass_pole_per_k126':enc(projected),
 'case0_angular_bar_fourth':str(bar_fourth),'case0_angular_bar_pair_fourth':str(bar_pair_fourth),'case1_angular_bar_pair':str(bar_pair),
 'case0_case1_only_residue_equivalence_checked':True,'full_one_loop_finite_reference_equivalence_claimed':False,
 'new_one_loop_pole_families':2,'new_two_loop_integrals':0,'provisional_only':True},start)
