"""ACM1 route, common-scale, original-endpoint and negative-control gate."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();mp.mp.dps=100
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
assert set(A['cases'])==set(B['cases'])=={'1/2','3/4','1'}
assert A['VVSS_contraction_rows']==B['VVSS_contraction_rows']==420 and B['profile_rows_each']==125 and B['heavy_EOM_solved']
maximum=mp.mpf(0);comparisons=0;regressions=0
def compare(a,b,reg=False):
 global maximum,comparisons,regressions
 aa,bb=q(a),q(b);er=abs(aa-bb)/(1+abs(aa));maximum=max(maximum,er);assert er<mp.mpf('1e-35'),(a,b,str(er))
 if reg:regressions+=1
 else:comparisons+=1
for key in A['cases']:
 a,b=A['cases'][key],B['cases'][key]
 assert set(a['family_L_polynomials'])==set(b['family_L_polynomials'])=={'VVVV','VVV','ghostV','VVSS'}
 for name in a['family_L_polynomials']:
  assert len(a['family_L_polynomials'][name])==len(b['family_L_polynomials'][name])==3
  for ar,br in zip(a['family_L_polynomials'][name],b['family_L_polynomials'][name]):
   assert len(ar)==len(br)==3
   for v,z in zip(ar,br):compare(v,z)
  for i in range(3):compare(a['direct_at_L_2_over7'][name][i],b['direct_at_L_2_over7'][name][i])
 for ar,br in zip(a['bridge_L_polynomial'],b['bridge_L_polynomial']):
  for v,z in zip(ar,br):compare(v,z)
 for i in range(3):
  assert q(a['family_L_polynomials']['VVVV'][i][2])+q(a['family_L_polynomials']['VVV'][i][2])==0
  assert q(a['family_L_polynomials']['VVSS'][i][2])==q(a['family_L_polynomials']['ghostV'][i][2])==0
 assert all(abs(q(v))>mp.mpf('1e-20') for v in a['controls']['missing_log60']+a['controls']['omitted_bridge'])
 if key!='1':assert all(abs(q(v))>mp.mpf('1e-20') for v in a['controls']['extra_VVSS_x'])
 else:assert all(q(v)==0 for v in a['controls']['extra_VVSS_x'])
old=packed(CAL/'canonical_so10_nine_family_uv_assembly/primary_tables.json.gz')
fan=packed(CAL/'canonical_so10_finite_assembly_nielsen/primary_tables.json.gz')
for key in ['1/2','1']:
 a=A['cases'][key];ref=old['finite_cases'][key]
 for name in a['family_L_polynomials']:
  for ar,br in zip(a['family_L_polynomials'][name],ref['family_L_polynomials'][name]):
   for v,z in zip(ar,br):compare(v,z,True)
 for i in range(3):
  compare(a['bridge_L_polynomial'][i][0],q(fan['finite_lambda2_fixed_xi'][key][i][0])-q(ref['known_graph_local_finite_L0'][i]),True)
  compare(a['bridge_L_polynomial'][i][1],q(fan['finite_lambda2_fixed_xi'][key][i][1])-q(ref['known_graph_local_scale_linear'][i]),True)
print('RESULT '+json.dumps({'status':'QUALIFIED_ANALYTIC_GAUGE_FAMILY_AND_HEAVY_BRIDGE_COUPLING_MAPS','elapsed_after_imports':time.perf_counter()-start,'route_comparisons':comparisons,'endpoint_regressions':regressions,'maximum_scaled_error':mp.nstr(maximum,35),'quartic_cubic_L2_cancellation_exact':True,'new_x':'3/4','complete_nine_family_or_physical_C1':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
