"""ACM1 symbolic polynomial coefficients and contracted heavy bridge."""
from data import *
start=begin('primary');mp.mp.dps=100
g2p=packed(CAL/'canonical_so10_nine_family_uv_assembly/primary_tables.json.gz')
v3=packed(CAL/'canonical_so10_three_vector_sunset/primary_v2_tables.json.gz')
gv=packed(CAL/'canonical_so10_ghost_vector_sunset/primary_v2_tables.json.gz')
vs=packed(CAL/'canonical_so10_vector_scalar_quartic/primary_amplitude_tables.json.gz')
hb=read(CAL/'canonical_so10_heavy_tadpole_bridge/primary_v3_result.json')
Q=[s.sympify(v['family']['0'],locals={'J':J}) for v in g2p['quartic']]
assert all(s.expand(Q[i]).coeff(J,2)+s.sympify(v3['scale_J2'][i])==0 for i in range(3))
cases={}
for key in ['1/2','3/4','1']:
 x=q(key);u=mp.log(x);j=mp.log(60)-u;families={n:[] for n in ['VVVV','VVV','ghostV','VVSS']};bridge=[]
 for i in range(3):
  qq=[number(s.expand(Q[i]).coeff(J,k)) for k in range(3)]
  a,b,c=q(v3['finite_F0'][i]),number(v3['scale_J'][i]),number(v3['scale_J2'][i])
  families['VVVV'].append([x*(qq[0]+qq[1]*j+qq[2]*j*j),x*(qq[1]+2*qq[2]*j),x*qq[2]])
  families['VVV'].append([x*(a+b*j+c*j*j),x*(b+2*c*j),x*c])
  a,b=q(gv['finite_F0'][i]),number(gv['scale_J'][i]);families['ghostV'].append([x*(a+b*j),x*b,mp.mpf(0)])
  f=mp.mpf(0);b=mp.mpf(0)
  for p in vs['coupling_powers']:
   row=list(map(q,vs['coefficients'][str(p)][str(i)]['R_MS']));assert abs(row[0])<mp.mpf('1e-40')
   f+=x**(p//2)*(row[1]+u*row[3]);b+=x**(p//2)*row[2]
  families['VVSS'].append([f,b,mp.mpf(0)])
  bridge.append([mp.fsum(x**(p//2)*(q(hb['coefficients'][str(p)]['constant'][i])+u*q(hb['coefficients'][str(p)]['coupling_log'][i])) for p in [-2,0,2,4]),mp.fsum(x**(p//2)*q(hb['coefficients'][str(p)]['scale_log'][i]) for p in [-2,0,2,4]),mp.mpf(0)])
 direct={n:[fmt(a+b*mp.mpf(2)/7+c*(mp.mpf(2)/7)**2) for a,b,c in rows] for n,rows in families.items()}
 controls={'missing_log60':[fmt(x*number(Q[i].subs(J,s.Float(mp.nstr(-u,105),105)))-families['VVVV'][i][0]) for i in range(3)],'extra_VVSS_x':[fmt((x-1)*v[0]) for v in families['VVSS']],'omitted_bridge':[fmt(-v[0]) for v in bridge]}
 cases[key]={'family_L_polynomials':{n:[list(map(fmt,row)) for row in rows] for n,rows in families.items()},'bridge_L_polynomial':[list(map(fmt,row)) for row in bridge],'direct_at_L_2_over7':direct,'controls':controls}
finish('primary',{'schema':'ACM1','cases':cases,'quartic_cubic_L2_cancellation_exact':True,'VVSS_contraction_rows':len(vs['contractions']),'original_forests_inherited':True,'physical_C1':False,'authority':'34/39'},start)
