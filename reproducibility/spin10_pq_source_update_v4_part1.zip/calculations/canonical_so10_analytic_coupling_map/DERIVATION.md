# ACM1: fixed-ratio homogeneity and the retained bridge

With x=g10^2>0 and vector squared masses x*lambda_r, uniform momentum/mass
rescaling fixes the dimensionless pure-vector ratios. The original kernels
and full/soft forests already determine every finite constant, including
dimensional prefactors multiplying poles. No new finite subtraction is made.
The coupling and scale maps are

 VVVV_i=x*Q_i(J),
 VVV_i=x*(a_i+b_i*J+c_i*J^2),
 ghostV_i=x*(d_i+e_i*J), J=L+log(60)-log(x).

Q is the original quartic bare-plus-proper-forest polynomial in G2P1, not
the bare quartic alone. All125 VVV/ghostV assignments, including their exact
zeros and matched light terms, remain in the independent profile sums.
The local L^2 cancellation is x*(Q_i''/2+c_i)=0, independent of x.

For VVSS, let each stored physical contraction contain uh,uhl,wi,wil and
each Goldstone mass ls have ug,wg. With hv=log(lambda_r/60),hs=log(ls/60),
the finite contribution including its coupling factors is

 -10*uh*(1+L)+10*uhl
 +x^2*wi*(1+2*(L-log(x)-hv))
 +x*sum_ls[-10*ug*(1+L-log(x)-hs)
           +wg*(1+2*(L-log(x)-hv))].

It follows directly by inserting the actual masses in the qualified
-10*Uweight*(1+js)+Wweight*(1+2*jv) graph-local remainder and multiplying
its original outer x once. Physical U carries1/x,physical W carries x;
Goldstone ratios carry no x. The scalar physical logarithm is held fixed.
This equals the existing p=0,2,4 coefficient map, not a new assumption that
the scalar and charge matrices commute. The stored traces retain their order.
The unused wil entry belongs to the original subtractions and is not deleted
from their authenticated evidence; it cancels from this finite hard formula.

HTB retains the original source-free stationary bridge

 B=-(R0+Rminus2/x)*M^-1*t(x,L),
 t=sum_p=0,2,4 x^(p/2)*(t_p,0+L*t_p,L+log(x)*t_p,log).

Direct EOM solution is compared to the stored contracted p=-2,0,2,4 map.
No new vacuum/tadpole condition is chosen. MTA's correlated origin allocation
and HPR's parent-minus-family cancellation are inherited; no duplicate bridge,
old FCI, arbitrary finite parent term or E5 contact normalization is added.

The integral inputs were qualified at fixed ratios before this increment.
Changing x here changes their scale logarithms and explicit powers exactly;
it does not determine the remaining scalar mixed-mass integrals by scaling.
That is why the independently running VSG1 calculation is still required.
