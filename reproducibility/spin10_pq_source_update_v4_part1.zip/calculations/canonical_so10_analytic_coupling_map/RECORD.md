# ACM1: analytic gauge-family coupling maps and heavy bridge

Scientific question: can the remaining non-scalar-integral inputs to the
complete nine-family bosonic evaluator be transported to arbitrary positive
x=g10^2 without interpolation, new physical choices or repeated integration?
VSG1 is still executing; this independent increment reads none of its
unfinished outputs. Ownership is only this directory/control folder. No
agents; at most one ACM numerical worker alongside the one VSG worker.
Keep Git HEAD fixed until all live base-sensitive work is terminal.

Scope: VVVV,VVV,ghostV,VVSS and the already qualified heavy-tadpole bridge,
in the original xi1 MSbar parent reference,Q^2=60 exp(L). Fixed scalar
potential and stationary reference, all charge maps and original forests.
All heavy vector squared masses are x times their fixed eigenvalues; hence
the pure-vector kernels have fixed dimensionless mass ratios. Their common
logarithm is J=L+log(60)-log(x). VVSS retains its actual physical/Goldstone
mass and charge contractions, including noncommuting scalar operators.

Primary evaluates qualified coefficient polynomials. Replay sums all125
original VVV/ghostV profile rows pointwise, reconstructs VVSS from its420
physical/Goldstone contraction rows, and solves the three-dimensional heavy
stationary equation instead of using its contracted bridge coefficients.
The two VVVV routes reuse the separately qualified original quartic/forest
expressions. No universal integral or source theorem is derived afresh.
This is new coupling routing with inherited independent amplitude evidence.

Preregister x=1/2,3/4,1; L=0,2/7 and polynomial extraction at L=-1,0,1.
Compare all route coefficients and direct evaluations1e-35; regress all four
family polynomials at the two old endpoints against G2P1. Retain each original
pole/forest ownership without adding old FCI or a second parent insertion.
VVVV+VVV quadratic L coefficients must cancel exactly; other displayed
families and bridge have no L^2 term. Controls must detect missing log60,
an extra outer x on VVSS at nonunit x, and omission of the heavy bridge.
Do not fit any coefficient from a desired total, RG slope or physical target.

The compact positive-x formulas are analytic recipes, not uniform numerical
accuracy on unbounded coupling or a massless-gap limit. Source/width, reality,
basis and degeneracy applicability are inherited within their actual qualified
domains. No physical C1, observed-coupling refit, full-matter threshold or
perturbative-control conclusion follows from this subset alone. The nine
bosonic families omit the original ledger's mixed fermion/heavy-vector gauge
graphs; matter/flavor remains paused. E5/A5 and HB1/C5 stay unqualified/blocked.

Freeze all sources and qualified inputs before computation. Sequential
primary,replay,verification, each600s after imports,8GiB sampled private,
350MiB launch floor,24MiB package. Preserve complete failed/incomplete captures;
failure of any declared comparison ends that version, not its evidence.
Separate calculation, evidence validation and director acceptance. State113/
34of39 and custodyexit2/sevenNOTPASS unchanged. Shared action, old loop
assumptions, numerical libraries and AI author limit independent assurance.

The result will close the analytic portion of the off-grid assembly if the
tests pass. Otherwise preserve the mismatch and identify its actual mass,
scale, prefactor or subtraction dependency. A failure is not an anomaly
verdict. Do not interrupt or silently substitute a new method into VSG1.
