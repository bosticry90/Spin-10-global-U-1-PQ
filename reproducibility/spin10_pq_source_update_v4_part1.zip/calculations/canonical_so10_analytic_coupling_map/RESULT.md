# ACM1: four analytic family maps and the heavy bridge

Qualified receipt `validation_receipt.json`, SHA256
`e1456e1d2bb2f9c988e75b541ae497a76f449425971cf934d18cf3420ba926ec`.
Scientific/director acceptance NOT_PERFORMED; state113/authority34/39 unchanged.
The result supplies positive-x recipes for VVVV,VVV,ghostV,VVSS and the
retained heavy-tadpole bridge. It does not complete the nine-family evaluator
or calculate physical C1, a fit or a perturbative-control verdict.

The routes agree on171 coefficient/direct-value comparisons and84 original
endpoint regressions. Maximum scaled discrepancy4.51775728006462e-45 is
below the frozen1e-35 gate; inherited50/45-digit tables limit the evidence.
Seventy-digit output serialization is not a new seventy-digit accuracy claim.
The independently evaluated new point is x=g10^2=3/4, with L=log(Q^2/60).

All125 original VVV and ghostV profile rows are retained in the replay,
including their structural zeros and qualified light matching. The pure
vector scale map is J=L+log(60)-log(x), with the original outer x once.
VVVV and VVV quadratic L coefficients cancel exactly for each gauge factor
and every positive x. This is inherited fixed-ratio homogeneity plus new
coupling routing, not a repetition of the two-loop integral derivations.

VVSS's coefficient map is independently reconstructed from all420 original
physical/Goldstone contraction rows. The physical scalar masses stay fixed;
the Goldstones and vectors scale with x. Its physical-U,Goldstone,physical-W
pieces therefore carry powers x^0,x^1,x^2. Ordered matrix traces and the
noncommuting scalar/charge inputs remain inherited. No common extra outer x
is allowed on the already normalized VVSS polynomial.

For f(L)=a+bL+cL^2, the new coefficients below are rounded for navigation.
Each row already includes its family's coupling factors.

| Input | Gauge factor | a | b | c |
| --- | --- | ---: | ---: | ---: |
| VVVV | U1 | 33474.299116 | 21665.808583 | -864 |
| VVVV | SU2 | 658.708677 | -205.826077 | -324 |
| VVVV | SU3 | 12661.912400 | 7446.090935 | -135 |
| VVV | U1 | -52824.779733 | -34180.886943 | 864 |
| VVV | SU2 | -324.521088 | 739.310682 | 324 |
| VVV | SU3 | -17708.707017 | -10644.309532 | 135 |
| ghostV | U1 | 9781.129890 | 4499.692787 | 0 |
| ghostV | SU2 | 320.574274 | 203.171798 | 0 |
| ghostV | SU3 | 3079.520098 | 1439.822866 | 0 |
| VVSS | U1 | 234893.679744 | 111152.099947 | 0 |
| VVSS | SU2 | 3523.985355 | 1788.199878 | 0 |
| VVSS | SU3 | 84538.945568 | 41333.061792 | 0 |
| HTB | U1 | -2204987.912536 | -1819814.345480 | 0 |
| HTB | SU2 | -788237.729065 | -1195962.366605 | 0 |
| HTB | SU3 | -183726.503402 | -529091.329045 | 0 |

HTB's coefficient map agrees with a separate direct solution of the actual
three-field heavy stationary equation, retaining R0+Rminus2/x and every
tadpole power/log term. MTA's correlated origin allocation is inherited;
no finite vacuum condition, duplicate bridge or extra old FCI was introduced.
The original forest and light-subtraction ownership is unchanged. HPR's
parent-minus-family cancellation does not authorize a second finite addition.

Controls detect loss of log60 before addition, an extra VVSS outer x at
nonunit coupling, and an omitted heavy bridge. As expected, the extra-x
control is insensitive at x=1; the preregistered nonunit points detect it.
The L=2/7 direct profile/trace evaluations agree with polynomial evaluation.

All three workers completed on their first executions, with no new failed or
unfinished ACM calculation. Primary/replay/verifier elapsed after imports
1.9886034/7.8974189/1.8355232s. Sampled private maxima47,599,616/48,623,616/
47,542,272bytes,2/5/2samples, are not continuous peaks. All launch commit
floors and600s/8GiB sampled-private/24MiB-package bounds were respected.
Preparations bind6004 and6011 inputs. Full external captures reside under
analytic-coupling-map-v1-2026-10-22. Readiness and local-commit sealing are
deferred while the separate base-sensitive VSG1 replay remains live.

No unfinished VSG numerical output was read, changed or replaced. Reused
qualified kernels and profile/charge data remain shared premises; the new
comparison tests coupling/scale routing and contractions, not those physical
assumptions independently. Software and AI authorship also remain shared.
This is bounded computational progress under the existing epistemic ladder.

The new point is diagnostic, not an adopted physical benchmark. Full-matter
fermion/heavy-vector coverage, physical refit, scalar quantum-control and
tree-level perturbativity warnings, E5/A5, custodyexit2/seven, paused matter/
flavor and blocked HB1/C5 remain unchanged. No publication or remote action.
