"""ACM1 pointwise profile/trace sums and direct heavy stationary solution."""
from data import *
start=begin('replay');mp.mp.dps=110
g2p=packed(CAL/'canonical_so10_nine_family_uv_assembly/replay_tables.json.gz')
v3=packed(CAL/'canonical_so10_three_vector_sunset/replay_v2_tables.json.gz')
gv=packed(CAL/'canonical_so10_ghost_vector_sunset/replay_tables.json.gz')
vs=packed(CAL/'canonical_so10_vector_scalar_quartic/replay_amplitude_tables.json.gz')
hb=read(CAL/'canonical_so10_heavy_tadpole_bridge/replay_v3_result.json');ht=packed(CAL/'canonical_so10_heavy_tadpole_bridge/replay_v3_tables.json.gz')
lams=list(map(q,['3/10','3/2','25','253/10']));M=mat(ht['raw_Hessian']);Rm=mat(ht['Rminus2']);R0=mp.matrix(hb['R0'])
assert len(v3['profiles'])==len(gv['profiles'])==125 and len(vs['contractions'])==420
Q=[s.lambdify(J,s.sympify(v['family']['0'],locals={'J':J}),modules='mpmath') for v in g2p['quartic']]
def values(x,ll):
 u=mp.log(x);j=ll+mp.log(60)-u;out={n:[mp.mpf(0)]*3 for n in ['VVVV','VVV','ghostV','VVSS']}
 for i in range(3):
  out['VVVV'][i]=x*Q[i](j)
  out['VVV'][i]=x*mp.fsum(q(v['finite'][i])+number(v['scale_J'][i])*j+number(v['scale_J2'][i])*j*j for v in v3['profiles'])
  out['ghostV'][i]=x*mp.fsum(q(v['finite'][i])+number(v['scale'][i])*j for v in gv['profiles'])
 for row in vs['contractions']:
  i=row['i'];hv=mp.log(lams[row['r']-1]/60);uh,uhl,wi,wil=map(q,row['physical'])
  out['VVSS'][i]+=-10*uh*(1+ll)+10*uhl+x*x*wi*(1+2*(ll-u-hv))
  for ls,pair in zip(lams,row['Goldstone_U_W']):
   ug,wg=map(q,pair);out['VVSS'][i]+=x*(-10*ug*(1+ll-u-mp.log(ls/60))+wg*(1+2*(ll-u-hv)))
 t=mp.zeros(3,1)
 for p in [0,2,4]:
  v=hb['tadpole_coefficients'][str(p)];t+=x**(p//2)*(mp.matrix(v['constant'])+ll*mp.matrix(v['scale_log'])+u*mp.matrix(v['coupling_log']))
 bridge=(R0+Rm/x)*mp.lu_solve(M,-t)
 return out,list(bridge)
cases={}
for key in ['1/2','3/4','1']:
 x=q(key);vals={v:values(x,q(v)) for v in ['-1','0','1','2/7']};families={}
 for name in ['VVVV','VVV','ghostV','VVSS']:
  families[name]=[[fmt(vals['0'][0][name][i]),fmt((vals['1'][0][name][i]-vals['-1'][0][name][i])/2),fmt((vals['1'][0][name][i]+vals['-1'][0][name][i])/2-vals['0'][0][name][i])] for i in range(3)]
 bridge=[[fmt(vals['0'][1][i]),fmt((vals['1'][1][i]-vals['-1'][1][i])/2),'0'] for i in range(3)]
 cases[key]={'family_L_polynomials':families,'bridge_L_polynomial':bridge,'direct_at_L_2_over7':{n:list(map(fmt,v)) for n,v in vals['2/7'][0].items()}}
finish('replay',{'schema':'ACM1','cases':cases,'profile_rows_each':125,'VVSS_contraction_rows':420,'heavy_EOM_solved':True,'original_forests_inherited':True,'physical_C1':False,'authority':'34/39'},start)
