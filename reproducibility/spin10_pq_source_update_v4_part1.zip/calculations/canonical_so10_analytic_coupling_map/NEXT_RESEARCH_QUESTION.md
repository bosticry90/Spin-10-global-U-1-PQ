# Next: common nine-family bosonic evaluation

Let VSG1 V2 reach a terminal state. If its complete unit and amplitude gates
qualify, freeze a dependent common assembly of all nine families at x=3/4,
alongside the .5/1 regressions. Do not read unfinished tables as accepted
inputs, interpolate between endpoints or restart the running calculation.

Use ACM1 for VVVV,VVV,ghostV,VVSS and HTB; S4G1 for SSSS; S3G1 for SSS;
MSG1 for VVS/ghostS; VSG1 for all five VSS sectors. Every family's stored
normalization must be explicit. MSG/VSG inner coefficients need their
outer x, while SSSS/SSS/VVSS and ACM's displayed values already include
their coupling factors. HTB enters once after all1PI families, with its
correlated original MSbar tadpole allocation. HPR does not add a finite
parent-minus-family remainder; old FCI is not a tenth amplitude.

Regress the original FAN finite coefficient and L slope before assessing
the new result. Preserve the exact L^2 cancellation and the applicable
RG,width,basis,positive-degeneracy and one-loop controls in their actual
domains. Inspect BMC's background normalization before any loop-size or
inverse-coupling interpretation; do not add the one-loop square twice.

The next meaningful physics question is whether the completed bosonic
coefficient is perturbatively controlled in the stated fixed reference.
It is not whether selected terms look favorable. A scoped diagnostic can
be useful without declaring the full C1 ledger or an observed-coupling fit
complete: mixed light-fermion/heavy-vector graphs remain a separate missing
coverage obligation, and matter/flavor remains human-paused.
