"""FCV1 full coefficient and action normalization verifier; no fitted target."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
for key in ['selfenergy_Gaussian_unit','inverse_response_unit','cubic_Wick_phase','combined_phase','pole_units','LL_zero_exact','literal_vertex_positions_checked','literal_vertex_nonzero_positions']:assert P[key]==R[key],key
assert P['selfenergy_Gaussian_unit']=='-1' and P['inverse_response_unit']=='1' and P['cubic_Wick_phase']=='-I' and P['combined_phase']=='1' and P['LL_zero_exact']
assert P['pole_units']==['-3','-3/4','-3/4','-3/4','-3/4'] and P['literal_cubic_density_positions']==72 and P['literal_vertex_positions_checked']==384
for a,b in zip(P['angular_factors'],R['angular_factors']):
 for x,y in zip(a,b):assert s.simplify(s.sympify(x)-s.sympify(y))==0
assert s.simplify(s.sympify(P['angular_factors'][0][1])-s.sympify(P['angular_factors'][0][3]))!=0
assert {tuple(a[:-1]):s.sympify(a[-1]) for a in P['literal_vertex']}=={tuple(a[:-1]):s.sympify(a[-1]) for a in R['literal_vertex']}
f={(a,b,c):s.sympify(v) for a,b,c,v in P['full45_plane_f']};fr={(a,b,c):s.sympify(v) for a,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']};assert f==fr
L=list(map(dec,P['loop_left']));RR=list(map(dec,P['loop_right']))
for a,b,c,d in zip(L,map(dec,R['loop_left']),RR,map(dec,R['loop_right'])):zero(a-b);zero(c-d);zero(c+a.T)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));H=dec(Y['H_new']);w=s.Symbol('w')
for c,a in enumerate(L):
 zero(a.subs({eta:w,xi:w})+s.I*6*(w+1)*T[c]);zero(a.subs({eta:0,xi:0})+s.I*6*T[c]);zero(a+a.conjugate().T.xreplace({s.conjugate(eta):eta,s.conjugate(xi):xi}))
FH=[s.SparseMatrix(45,45,{(c,b):s.simplify(sum(H[a,h]*f.get((a,b,c),0) for a in range(45) if H[a,h])) for b in range(45) for c in range(45)}) for h in range(12)]
for h,Fh in enumerate(FH):
 th=sum((H[a,h]*T[a] for a in range(45) if H[a,h]),s.zeros(16))
 for c,a in enumerate(L):zero(th*a-a*th-s.I*sum((Fh[d,c]*L[d] for d in range(45) if Fh[d,c]),s.zeros(16)))
parts={n:list(map(dec,d['left'])) for n,d in P['parts'].items()};controls={'omit_first_longitudinal':any(tidy(a).todok() for a in parts['LF']),'omit_second_longitudinal':any(tidy(a).todok() for a in parts['FL']),'width_averaging':any(tidy(a-a.subs(eta,xi)).todok() for a in L),'width_exchange':any(tidy(a-a.xreplace({eta:xi,xi:eta})).todok() for a in L),'flip_Wick':any(tidy(2*a).todok() for a in L),'extra_half_or_family3':any(a!=a/2 and a!=3*a for a in L)};assert all(controls.values())
N=dec(R['adjoint_map'])
for c,a in enumerate(L):zero(a-s.I*sum((N[c,e]*T[e] for e in range(45) if N[c,e]),s.zeros(16)))
for D in [P,R]:assert D['new_one_loop_vertex_families']==1 and D['new_two_loop_integrals']==0 and D['family_extension']=='identity_no_extra3' and not D['open_line_extra_half']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_CUBIC_VECTOR_FERMION_GAUGE_UV_FAMILY','elapsed_after_imports':time.perf_counter()-start,'total_chiral_current_positions_compared':23040,'all_Lorentz_copies_checked':4,'H_covariance_positions_checked':138240,'left_nonzero_positions':sum(len(a.todok()) for a in L),'right_nonzero_positions':sum(len(a.todok()) for a in RR),'adjoint_map_entries':len(N.todok()),'full45_Lie_entries_checked':len(f),'literal_density_cubic_positions':72,'literal_vertex_positions_checked':384,'literal_vertex_nonzero_positions':P['literal_vertex_nonzero_positions'],'pole_units':P['pole_units'],'combined_phase':'1','LL_zero_exact':True,'uniform_and_zero_width_limits_checked':True,'finite_continuations_not_equated':True,'controls':controls,'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'full_B_vertex_completed':False,'finite_QAP_measure_or_matching_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
