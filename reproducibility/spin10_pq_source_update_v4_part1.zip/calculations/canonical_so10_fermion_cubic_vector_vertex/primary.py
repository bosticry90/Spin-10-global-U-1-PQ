"""FCV1 literal action Wick differentiation, Clifford tensor and direct colors."""
from data import *
from itertools import permutations,product
from collections import defaultdict
start=begin('primary')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
# Action AST and its qualified finite local polynomial are authenticated bytes.
act=read(PK/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');ex=read(PK/'frozen_a10_executable_reconciliation/primary.json');assert ex['action_sha256']=='936c6f856e92fc0844a124701fba0eee44f145d479b61b5eb058115cfc9a0b9c'
ast=act['local_terms'][0];assert ast['sector']=='GAUGE_KINETIC' and ast['density']['metric']=='diag(1,-1,-1,-1)';ff=ast['density']['expression']['expression']['factors'];assert ff[0]['value']=='-1/4' and ff[1]==ff[2];curv=ff[1]['terms'];assert len(curv)==3 and curv[-1]['expression']['factors'][0]['name']=='g10' and curv[-1]['expression']['factors'][1]['name']=='f_plane'
# Recover the full Lie tensor from the actual real20 scalar representation.
phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');rho=list(map(dec,phys['representation_matrices']['phi']));assert len(rho)==45
piv=[]
for c,A in enumerate(rho):
 entries=list(A.todok());idx=next(ij for ij in entries if all(not rho[b][ij] for b in range(45) if b!=c));piv.append((idx,A[idx]))
f={}
for a,A in enumerate(rho):
 for b in range(a+1,45):
  comm=A*rho[b]-rho[b]*A;vals=[s.simplify(comm[idx]/v) for idx,v in piv];zero(comm-sum((v*rho[c] for c,v in enumerate(vals) if v),s.zeros(20)))
  for c,v in enumerate(vals):
   if v:f[a,b,c]=v;f[b,a,c]=-v
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']))
for a in range(45):
 for b in range(a+1,45):zero(T[a]*T[b]-T[b]*T[a]-s.I*sum((f.get((a,b,c),0)*T[c] for c in range(45) if f.get((a,b,c),0)),s.zeros(16)))
k=s.symbols('k0:4');literal=[r for r in ex['gauge_density'] if len(r['word'])==3];assert len(literal)==72
vertex={};checked=0
for c,a,b in permutations([0,1,9]):
 for r,mu,nu in product(range(4),repeat=3):
  modes={(c,r):0,(a,mu):1,(b,nu):-1};coef=0
  for row in literal:
   assigned=[];phase=-s.S.One;deriv=1
   for n in row['word']:
    base,*jet=n.split('__');cc,ll=map(int,base[1:].split('_'));assigned.append((cc,ll));phase*=s.I if ll==0 else 1
    if jet:
     j=int(jet[0]);phase*=s.I if j==0 else 1;deriv=s.I*modes.get((cc,ll),0)*k[j]
   if sorted(assigned)!=sorted(modes):continue
   coef+=s.sympify(row['coefficient'])/g*phase*deriv
  V=2*k[r]*int(mu==nu)-k[mu]*int(nu==r)-k[nu]*int(r==mu);target=-s.I*f[a,b,c]*V;assert s.simplify(coef-target)==0,(c,a,b,r,mu,nu,coef,target)
  if coef:vertex[c,a,b,r,mu,nu]=str(s.expand(coef))
  checked+=1
# Exact finite exterior Gaussian for the open-line minus.
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   n=sum((b&((1<<i)-1)).bit_count() for i in range(a.bit_length()) if (a>>i)&1)%2;out[a|b]=out.get(a|b,0)+(-1)**n*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)}
F,a,b,X,Y=s.symbols('F a b X Y',nonzero=True);action={12:-F,5:a*X,10:-b*Y};term={0:s.S.One};expo=dict(term)
for n in range(1,5):
 term={k:-v/n for k,v in mul(term,action).items()}
 for k,v in term.items():expo[k]=s.expand(expo.get(k,0)+v)
selfunit=s.simplify((-expo[15]/expo[12])/(a*b*X*Y/F));assert selfunit==-1
z=s.Symbol('z');K=s.Matrix([[2,1],[1,3]]);J=s.Matrix([[1,2],[2,0]]);zero((K+z*J).inv().diff(z).subs(z,0)+K.inv()*J*K.inv());unit=-selfunit;wick=-s.I;phase=s.simplify(unit*(-s.I)**2*(-s.I)*wick)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gamma=[s.kronecker_product(pa[1],x) for x in pa]+[s.kronecker_product(pa[0],s.eye(2))];slash=sum((x*A for x,A in zip(k,gamma)),s.zeros(4));b2=sum(x*x for x in k);d,Q=s.symbols('d Q')
def avg(z):
 out=0
 for p,v in s.Poly(s.expand(z),*k).terms():
  if any(n%2 for n in p):continue
  out+=v*s.prod(s.factorial2(n-1) for n in p)/s.prod(d+2*j for j in range(sum(p)//2))
 return s.factor(out.subs(Q,1))
angular=[];pole=[]
for r,G in enumerate(gamma):
 FF=sum((gamma[mu]*slash*gamma[nu]*(2*k[r]*int(mu==nu)-k[mu]*int(nu==r)-k[nu]*int(r==mu)) for mu,nu in product(range(4),repeat=2)),s.zeros(4));LF=slash*slash*(k[r]*slash-b2*G);FL=(k[r]*slash-b2*G)*slash*slash;LL=s.expand(sum(k[mu]*k[nu]*(2*k[r]*int(mu==nu)-k[mu]*int(nu==r)-k[nu]*int(r==mu)) for mu,nu in product(range(4),repeat=2)));assert LL==0
 # Full-momentum longitudinal VVV contractions give Q in the contracted metric.
 LFfull=slash*slash*(k[r]*slash-Q*G);FLfull=(k[r]*slash-Q*G)*slash*slash
 vals=[]
 for N in [FF,LF,FL,LFfull,FLfull]:
  A=N.applyfunc(avg);u=s.factor(s.trace(G*A)/4);zero(A-u*G);vals.append(u)
 angular.append(list(map(str,vals)));pole.append([v.subs(d,4) for v in vals]);assert pole[-1]==[-3,-s.Rational(3,4),-s.Rational(3,4),-s.Rational(3,4),-s.Rational(3,4)]
raw=packed(CAL/'canonical_so10_fermion_gauge_fermion_vertex/primary_tables.json.gz');Qmap=dec(phys['C3_plane_to_parent']);GF=tidy(Qmap*dec(raw['raw_Feynman'])*Qmap.T);GL=tidy(Qmap*dec(raw['raw_longitudinal'])*Qmap.T);zero(GF-s.eye(45));H=dec(Y['H_new']);W=xi*s.eye(45)+(eta-xi)*H*H.T;zero(GL-W)
TF=[tidy(sum((GF[i,a]*T[i] for i in range(45) if GF[i,a]),s.zeros(16))) for a in range(45)];TL=[tidy(sum(((GL-GF)[i,a]*T[i] for i in range(45) if (GL-GF)[i,a]),s.zeros(16))) for a in range(45)]
parts={name:{'left':[s.zeros(16) for _ in range(45)],'right':[s.zeros(16) for _ in range(45)]} for name in ['FF','LF','FL']}
for (a,b,c),v in f.items():
 for name,A,B,u in [('FF',TF[a],TF[b],pole[0][0]),('LF',TL[a],TF[b],pole[0][1]),('FL',TF[a],TL[b],pole[0][2])]:
  parts[name]['left'][c]+=phase*u*v*A*B;parts[name]['right'][c]+=phase*u*v*A.T*B.T
for val in parts.values():
 for chir in val:val[chir]=list(map(tidy,val[chir]))
L=[tidy(sum((val['left'][c] for val in parts.values()),s.zeros(16))) for c in range(45)];R=[tidy(sum((val['right'][c] for val in parts.values()),s.zeros(16))) for c in range(45)]
finish('primary',{'method':'literal_Wick_action_and_full45_scalar_Lie_Clifford_ordered_products','loop_left':list(map(enc,L)),'loop_right':list(map(enc,R)),'parts':{n:{c:list(map(enc,v)) for c,v in a.items()} for n,a in parts.items()},'literal_cubic_density_positions':len(literal),'literal_vertex_positions_checked':checked,'literal_vertex_nonzero_positions':len(vertex),'literal_vertex':[[*i,v] for i,v in sorted(vertex.items())],'full45_plane_f':[[*i,str(v)] for i,v in sorted(f.items())],'selfenergy_Gaussian_unit':str(selfunit),'inverse_response_unit':str(unit),'cubic_Wick_phase':str(wick),'combined_phase':str(phase),'angular_factors':angular,'pole_units':list(map(str,pole[0])),'LL_zero_exact':True,'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'family_extension':'identity_no_extra3','open_line_extra_half':False},start)
