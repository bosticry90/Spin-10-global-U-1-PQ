# FCV1: complete cubic-vector fermion/gauge UV family

QUALIFIED_COMPLETE_CUBIC_VECTOR_FERMION_GAUGE_UV_FAMILY. Receipt SHA256
ed246abecd0393241c79408760a99331fb238d9eb6beaa2584c276f18a3fb701.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 unchanged.

The direct ordered calculation and the weighted-adjoint-Casimir calculation
agree at all23040 left/right current positions, including zeros, all45
external total-field directions and four Lorentz components. Each chiral
list has720 nonzero entries; the exact adjoint map has93 nonzero entries.
These are algebraic counts, not particles or independent experiments.

With common g10³ bar_gamma_rho/(16pi²eps), the inverse-fermion-operator pole is

    L_c = -3i/4 sum_d (C_adj+C_adj,width)_(dc) T_d,
    R_c = -(L_c)^T,
    C_adj=8I45, C_adj,width=-sum_ab W_ab F_a F_b,
    W=eta_H P_H+xi P_M, (F_a)_(cb)=f_abc.

All720 ordered nonzero Lie coefficients are retained, including the broken
non-symmetric coset; no f_MMM exclusion or average width was used. The full
138240 homogeneous-H covariance positions and the inherited real-width
Hermiticity condition were checked. This completes FGS1's cubic-vector
family, not the entire fermion/gauge vertex.

## Action normalization and separate momentum derivations

The actual Minkowski action has -F²/4 and the declared full45 f-plane tensor.
Primary derives all45 commutators from the actual real20 scalar representation
and checks them against the spinor current. It Wick-transforms all72 literal
cubic density positions in the closedSO3 subset{0,1,9}, differentiates them,
and checks all384 color/Lorentz vertex slots.216 are nonzero. Replay derives
the same vertex from the factorized positive Euclidean curvature without
reading the literal polynomial. Both give

    Gamma3_(c rho,a mu,b nu) = -ig f_abc
       (2k_rho delta_mu_nu-k_mu delta_nu_rho-k_nu delta_rho_mu).

The two internal vector momenta at this vertex are k,-k. The open-line
Gaussian gives self-energy unit-1; differentiating the vector inverse gives
response unit+1. Two matter vertices, physical fermion numerator and the
action-derived cubic phase give combined phase+1. There is no open-line half
or extra factor of three.

Primary uses explicit barred Clifford matrices and direct angular moments;
replay uses Schur differentiation and Gaussian moment ratios. The FF pole
unit is-3, each of the LF/FL placements is-3/4, and LL is exactly zero by
double-longitudinal transversality. Both longitudinal placements are necessary.
Positive temporary IR radial references have residue1.

The barred-only diagnostic factors are -12/d and -18/[d(d+2)]; contracting
the VVV longitudinal index with full momentum instead gives
-2(2d+1)/[d(d+2)]. These longitudinal factors agree at d=4 and differ at
finite epsilon. The result claims their common UV pole only; it neither
constructs nor identifies a finite continuation or restoration scheme.

Uniform W=wI gives -6i(w+1)T_c. Zero widths still give -6iT_c in this family.
These are limits of the verified formula, not adopted physical gauges.
Dropping either longitudinal placement, averaging/exchanging widths, reversing
the cubic Wick sign or adding a spurious half/family multiplicity is detected.

## Preserved implementation failures and resources

A prelaunch indentation error in the generated IO helper was caught before
freezing or launching a scientific worker. Exact failed source and parsing
exception are preserved externally and bound in the preparation.

V1 primary FAILED before any loop result because the exterior-Gaussian code
reused the momentum name k; its Y symbol also collided with the current-input
dictionary. V2 fixes those local names, then FAILED when an odd-moment angular
entry retained Python int0 and attempted SymPy substitution. V3 changes that
accumulator to exact SymPy Zero. Both failed sources/copies, native captures
and controller failures remain. Action, normalization, coefficient tests,
physical inputs and resource limits were unchanged. The independent replay
ran only after V3 completed; no failed verifier is being relabeled PASS.

V3 primary185.8589760s, replay30.6321691s, verifier21.3822123s after imports,
all exit0.94/16/12 samples have private maxima96342016/59076608/60305408bytes,
not continuous peaks. Failed V1/V2 each have3 samples with maxima74350592/
74514432bytes.600s each,8GiB sampled cap,350MiB launch floor and16MiB package
limit were unexhausted.54 initial/83 final validation bindings, separately
frozen V2/V3 continuations and16 exact source copies preserve the evidence.

Readiness is authenticated reuse of this logical goal turn's fresh GFT1 E4
execution, not another execution or expensive historical scientific replay.
Custody remains exit2/seven unresolved, NOTPASS. The control directory is
research-control-records/ToE-Next/fermion-cubic-vector-vertex-v1-2026-10-22.

## Significance and next action

GFT1, FCV1 and FAV1 now supply all three pure-gauge B topology families.
The next informative test is their exact-once sum, retaining FAV1's independent
background-A term, compared with GFK1's independently measured kinetic pole
under the diagonal-H connection projection. A failure should retain the full
remainder. Even a match would establish only a selected marginal UV
covariantization, not finite-background Duhamel or QAP restoration.

The g10 Y² Yukawa-fermion and scalar-current families remain. No source
counterterm was used to fit this loop. Finite amplitudes, hatted restoration,
measure/source equivalence, matter C1, E5/A5 and physical unification remain
unqualified. All benchmark exclusions, the140% singlet warning, flavor pause,
HB1/C5 blocks, quartet failure and custody limitations remain intact.

The two routes share scientific assumptions, action data, runtime and AI
authorship. They test different mathematical implementations, not independent
physical premises. The method exposes implementation weaknesses while
retaining the resulting failed evidence; it is not external validation.
