# FCV1: complete cubic-vector fermion/gauge ultraviolet family

Question: determine the complete proper g10 cubed P-P-B pole with the external
B on the cubic Yang-Mills vertex. FGS1 gives eight outward H/M profiles, not
eight presumed nonzero coefficients. GFT1 and FAV1 are distinct families.
This input is necessary before the pure-gauge vertex can be assembled.

Freeze the actual -F²/4 contracted action AST, its authenticated executable
reconciliation and all72 literal cubic coefficients in the closed SO3
subset {0,1,9}; the full45 scalar-derived Lie algebra; SMA1/SMP1 physical pp
inverse with barred numerator/full momentum denominator; GFT1's already
qualified raw BB inverse; both real symbolic widths eta_H,xi and YCT1's
complete chiral current. No flavor values, physical gauge values or masses
are selected. Positive temporary IR reference is for UV residue only.

Primary derives the open-line sign with an exterior Gaussian and the inverse
response, differentiates the literal density after inherited Wick rotation,
checks all six color permutations and64 Lorentz slots against the full AST's
cubic tensor, evaluates explicit barred Clifford numerators, then contracts
all45 Lie colors and both actual vector propagator placements in order.
Replay derives the cubic tensor from the factorized Euclidean curvature,
uses Schur/inverse differentiation, Gaussian angular moments and weighted
adjoint Casimirs rather than ordered current products. Workers cannot read
each other's output or old source counterterm candidates.

The pole projection uses d-dimensional angular integration with barred rank4
at the matter vertices. Four-dimensional and full-momentum longitudinal
contractions are both retained as diagnostics where their O(epsilon) parts
differ: only their common leading pole is claimed, no finite continuation
or scheme equivalence is adopted. Sterile hatted mixing remains inside the
physical denominator. No closed-loop half or extra family factor is allowed.

A separate verifier compares every left/right45x16x16 coefficient including
zeros, all four external Lorentz copies, source-free Hermiticity with the
inherited real-width involution and homogeneous H covariance. Controls omit
a longitudinal placement, average/exchange widths, flip the action-derived
Wick sign or insert a spurious open-line half/family factor. Uniform and zero
width limits are comparators, not chosen gauges. Actual f_MMM is retained.

Possible outcomes: qualified complete UV family; a preserved normalization,
Lie, routing or coefficient mismatch; or bounded incompleteness. Failure does
not become PASS. Freeze eight sources/copies/immutable inputs before primary,
replay and verifier, sequential native observed workers,600s after imports
each,8GiB sampled private cap,350MiB launch floor,16MiB package limit. Reuse
this logical goal turn's fresh GFT1 E4 readiness with authenticated bytes;
custody exit2/seven unresolved remains NOTPASS, not fresh historical science.

Authority ceiling: one proper marginal UV family, not a complete B vertex,
finite hatted restoration, background Duhamel response, source equivalence,
QAP, measure, finite matter C1, E5/A5 or physical unification. No foundation,
physical scheme, benchmark or paused/blocked-stage adoption. State113/34of39,
main, all prior failures and physical exclusions remain. Shared action,
regulator, group data, software and AI author limit independence. The result
will document demonstrated methods, failures, resources and next action.

Prelaunch source parsing caught a generated data.py indentation error. Its
exact failed bytes and parsing exception are preserved and bound from the
external fermion-cubic-vector-prelaunch-2026-10-22 record. No scientific
worker had launched; the unfrozen IO-only indentation was corrected before
freezing. No mathematical requirement or physical input changed.
