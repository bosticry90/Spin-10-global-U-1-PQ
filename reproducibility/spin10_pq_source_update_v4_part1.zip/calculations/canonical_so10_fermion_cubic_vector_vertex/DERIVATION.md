# FCV1 cubic insertion and two vector placements

S=-V S_F V G is the open self-energy. Differentiating the bosonic inverse,
delta G=-G Gamma3 G, gives +V S_F V G Gamma3 G. The two matter vertices have
phase(-i)^2 and physical numerator-i. With internal vector momenta k,-k at
the action vertex, the actual Euclidean curvature should give

    Gamma3_(c rho,a mu,b nu)=-ig f_abc V_(rho mu nu),
    V=2 k_rho delta_mu_nu-k_mu delta_nu_rho-k_nu delta_rho_mu.

This sign and normalization must be derived from frozen action coefficients;
it is a hypothesis until the literal Wick and factorized action routes agree.
Together the phases give+1 if that vertex sign is established. Family I3
is an open external identity, not a closed family trace.

At barred rank4, a direct Clifford contraction has candidate pole angular
units FF=-3, LF=FL=-3/4, LL=0. Full k contraction at the longitudinal VVV
index differs away from d=4 from a barred-only VVV tensor; both are checked
at the pole rather than claiming their finite terms equal. The exact
transversality k_mu k_nu V_(rho mu nu)=0 removes LL in either contraction.

Let W=eta_H PH+xi PM. The ordered current retains FF, (W-I)F and F(W-I)
separately before summation. The independent color reduction follows from
antisymmetry and [T_i,T_j]=i f_ijd T_d:

    sum_ab f_abc T_a T_b = i/2 sum_d C_adj(dc) T_d,
    sum_ab f_abc [(D T)_a T_b+T_a (D T)_b]
       = i sum_d C_adj,D(dc) T_d,
    C_adj,D=-sum_ab D_ab F_a F_b, (F_a)_cb=f_abc.

For D=W-I this suggests the complete current
L_c=-3i/4 sum_d(C_adj+C_adj,W)_dc T_d, R_c=-L_c^T. It must agree with the
independently normalized direct ordered contraction. Uniform W=wI suggests
-3i/4(w+1)*8 T_c; zero W still has a nonzero pure-vector pole. Neither limit
is used to fit an unknown coefficient. All45 colors and the non-symmetric
broken coset are retained. No finite Ward or counterterm claim follows.
