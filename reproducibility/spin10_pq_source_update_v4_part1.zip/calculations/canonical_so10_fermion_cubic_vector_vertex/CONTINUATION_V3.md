# FCV1 V3 exact-zero type continuation

V2 primary FAILED before loop coefficients: a scalar angular entry containing
only odd monomials left the accumulator as Python int0, then attempted its
SymPy .subs method. This is a serialization/type-harness failure. V3 changes
only the angular accumulator initial value to exact SymPy Zero. The failed
V1/V2 sources, copies, captures and controller failures are preserved. The
actual action vertex checks and Gaussian sign had completed before this
failure, but no partial pass is inferred. Replay is still unexecuted.

Reassessment: both failures are local Python name/type errors, not a failed
physics equation, resource exhaustion or evidence for a new physical scheme.
A further bounded unchanged600s route is competent after this exact-zero
correction; all coefficient, action, sign and independent tests remain.
