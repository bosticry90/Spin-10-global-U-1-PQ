"""FCV1 fixed action/reference inputs, source freeze and no authority change."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
BASE='4579d1e2028294b555926d0b6b28f8c19614e8d4';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-cubic-vector-vertex-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V503.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
for n in ['export_a10_e5_antighost_vector.py','frozen_a10_e5_full_hessian/primary.json','frozen_a10_physical_reconciliation/full_primary.json']:add(PK/n)
for folder,names in {'canonical_so10_yukawa_carrier_transport':['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json'],'canonical_so10_sterile_massive_propagator':['RESULT.md','validation_receipt.json'],'canonical_so10_fermion_gauge_kinetic_pole':['replay_tables.json.gz','validation_receipt.json','RESULT.md'],'canonical_so10_fermion_gauge_vertex_support':['RESULT.md','validation_receipt.json'],'canonical_so10_fermion_auxiliary_gauge_vertex':['RESULT.md','validation_receipt.json'],'canonical_so10_matter_source_uv_assembly':['qualified_lie_constants.json.gz','validation_receipt.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(ROOT/'calculations/canonical_so10_fermion_gauge_vertex_support/validation_receipt.json','69fcf85a4b4339ef79748644d7aae7b7a5c4fde43d823ad05e7488575b33b273')
for n in ['bindings.json','M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json','primary.json','validation_receipt.json']:add(PK/'frozen_a10_executable_reconciliation'/n)
for n in ['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json','RESULT.md']:add(ROOT/'calculations/canonical_so10_fermion_gauge_fermion_vertex'/n)
origin=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-fermion-triangle-v1-2026-10-22')
for n in ['readiness.jsonl','readiness_stderr.txt','postcommit_seal.json']:add(origin/n)
for n in ['data.py.failed-source.txt','failure.json']:add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-cubic-vector-prelaunch-2026-10-22')/n)
for name in ['RECORD.md' ,'DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
manifest=json.loads((PK/'frozen_a10_executable_reconciliation/bindings.json').read_bytes());actionpath=PK/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';assert sha256(actionpath.read_bytes()).hexdigest()==manifest['byte_sha256'][actionpath.relative_to(ROOT).as_posix()]
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30802
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'FCV1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FCV1_FROZEN',len(b),'bindings',flush=True)
