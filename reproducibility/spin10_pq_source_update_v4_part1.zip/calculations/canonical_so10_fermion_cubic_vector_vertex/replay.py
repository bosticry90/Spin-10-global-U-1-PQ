"""FCV1 factorized curvature, Schur/Gaussian moments and adjoint Casimirs."""
from data import *
from itertools import permutations,product
start=begin('replay')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));H=dec(Y['H_new']);W=xi*s.eye(45)+(eta-xi)*H*H.T;f={(a,b,c):s.sympify(v) for a,b,c,v in packed(CAL/'canonical_so10_matter_source_uv_assembly/qualified_lie_constants.json.gz')['plane_f']}
# Differentiate factorized positive Euclidean curvature, no literal-density input.
k=s.symbols('k0:4');amp=s.symbols('u v x');out=[];checked=0
for c,a,b in permutations([0,1,9]):
 for r,mu,nu in product(range(4),repeat=3):
  legs=[(c,r,0,amp[0]),(a,mu,1,amp[1]),(b,nu,-1,amp[2])];poly=0
  for al in range(4):
   for be in range(al+1,4):
    for e in [0,1,9]:
     linear=sum((s.I*p*(k[al]*int(ell==be)-k[be]*int(ell==al))*z for col,ell,p,z in legs if col==e),s.S.Zero)
     quadratic=sum((f.get((e,i,j),0)*z*y for i,ell,_,z in legs for j,ell2,_,y in legs if ell==al and ell2==be),s.S.Zero)
     poly+=linear*quadratic
  coef=s.expand(poly).coeff(amp[0]*amp[1]*amp[2]);V=2*k[r]*int(mu==nu)-k[mu]*int(nu==r)-k[nu]*int(r==mu);assert s.simplify(coef+s.I*f[a,b,c]*V)==0
  if coef:out.append([c,a,b,r,mu,nu,str(s.expand(coef))])
  checked+=1
F,dx,v1,v2,X,Yc=s.symbols('F dx v1 v2 X Yc',nonzero=True);schur=s.det(s.Matrix([[dx,v1*X],[v2*Yc,F]]))/F;selfunit=s.simplify((schur-dx)/(v1*v2*X*Yc/F));assert selfunit==-1
z=s.Symbol('z');K=s.Matrix([[2,z],[z,3]]);G=K.inv();zero(s.diff(G,z)+G*K.diff(z)*G);unit=-selfunit;wick=-s.I;phase=s.simplify(unit*(-s.I)**2*(-s.I)*wick)
# Gaussian second and fourth moments; barred Clifford identities give
# FF=-4*k_r slash-2*bar_kÂ² gamma_r,
# LF=FL=bar_kÂ²*k_r slash-bar_k^4 gamma_r (or -Q*bar_kÂ² for full contraction).
J=s.symbols('J0:4');Z=s.exp(sum(x*x for x in J)/4);at0=dict.fromkeys(J,0);q2=s.diff(Z,J[0],2).subs(at0);n2=sum(s.diff(Z,x,2).subs(at0) for x in J);q4=sum(s.diff(Z,J[0],2,x,2).subs(at0) for x in J);n4=sum(s.diff(Z,x,2,y,2).subs(at0) for x in J for y in J);d=s.Symbol('d');FF=s.factor((-4*q2-2*n2)/(d/2));LF=s.factor((q4-n4)/(d*(d+2)/4));LFfull=s.factor(q4/(d*(d+2)/4)-n2/(d/2));units=[x.subs(d,4) for x in [FF,LF,LF,LFfull,LFfull]]
eps,m2=s.symbols('epsilon m2',positive=True);rad2=s.gamma(1+eps)*m2**(-eps)*(2-eps)/2;rad4=s.gamma(1+eps)*m2**(-eps)*(3-eps)*(2-eps)/6;assert rad2.subs(eps,0)==rad4.subs(eps,0)==1
FA=[s.SparseMatrix(45,45,{(c,b):v for (aa,b,c),v in f.items() if aa==a}) for a in range(45)];CA=tidy(-sum((A*A for A in FA),s.zeros(45)));CWA=tidy(-sum((v*FA[a]*FA[b] for (a,b),v in s.SparseMatrix(W).todok().items()),s.zeros(45)));zero(CA-8*s.eye(45))
# Antisymmetric f turns the sum of both weighted placements into a commutator.
N=tidy(phase*(units[0]*CA/2+units[1]*(CWA-CA)));L=[tidy(s.I*sum((N[e,c]*T[e] for e in range(45) if N[e,c]),s.zeros(16))) for c in range(45)];R=[-A.T for A in L]
finish('replay',{'method':'factorized_curvature_Schur_Gaussian_and_weighted_adjoint_Casimir','loop_left':list(map(enc,L)),'loop_right':list(map(enc,R)),'adjoint_map':enc(N.T),'adjoint_total_Casimir':enc(CA),'adjoint_width_Casimir':enc(CWA),'literal_vertex_positions_checked':checked,'literal_vertex_nonzero_positions':len(out),'literal_vertex':out,'selfenergy_Gaussian_unit':str(selfunit),'inverse_response_unit':str(unit),'cubic_Wick_phase':str(wick),'combined_phase':str(phase),'angular_factors':[[str(FF),str(LF),str(LF),str(LFfull),str(LFfull)]]*4,'pole_units':list(map(str,units)),'LL_zero_exact':True,'positive_IR_radial_residues':['1','1'],'new_one_loop_vertex_families':1,'new_two_loop_integrals':0,'family_extension':'identity_no_extra3','open_line_extra_half':False},start)
