# FGS1: five total-field vertex families plus one independent-background class

QUALIFIED_COMPLETE_OUTWARD_FERMION_GAUGE_VERTEX_UV_SUPPORT.
Receipt SHA256
69fcf85a4b4339ef79748644d7aae7b7a5c4fde43d823ad05e7488575b33b273.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 unchanged.

The actual provisional matter action and qualified full bosonic/reference
envelope support five proper marginal P-P-B topology families and one class
for P-P-A with independent A held distinct from total B:

| External target | Family | Coupling order | Typed profiles |
| --- | --- | --- | ---: |
| B, both H/M sectors | Gauge-fermion triangle | g10³ | 4 |
| B, both H/M sectors | Cubic-vector triangle | g10³ | 8 |
| B, both H/M sectors | Nonlinear auxiliary-vector triangle | g10³ | 2 |
| B, both H/M sectors | Yukawa-fermion triangle | g10 Y² | 4 |
| B, both H/M sectors | Scalar-current triangle | g10 Y² | 4 |
| Independent A_H | Auxiliary-vector triangle | g10³ | 1 |

These23 profiles are an outward role/derivative support envelope, not23
nonzero amplitudes or multiplicity factors. Six additional external-derivative
profiles have lower UV degree for the nonderivative marginal target. Color,
Lorentz, spin, chirality and specific parameter cancellations remain unresolved.

## The nonlinear auxiliary vertices must be retained

The complete33092-position GF scan contains936 pure auxiliary/vector cubic
positions:720 Lambda_M B_H B_M and216 b_H A_H B_H. Independent reconstruction
from E1's antighost Euler columns and the actual affine qantighost=-Lambda
reproduces every coefficient. The first class contributes possible P-P-B
triangles, while the second supplies the independently differentiated A class.
One mixed BL edge, one BB edge and a physical fermion edge have total UV
degree0 even without a derivative on the auxiliary cubic. Removing mixed
edges changes the support and removes those profiles.

The two Yukawa carriers are the actual Sigma252 and phi20 maps. Their complete
column supports and the zero Phi54/S columns were checked against YCT1.
The two external-fermion vertices must use those action-derived couplings;
a generic extra scalar coupling was not introduced. Removing either carrier
changes the corresponding profile set. Sterile auxiliary fermions have no
interaction vertex; their hatted mixing stays inside the physical pp inverse.

Primary enumerates all typed three-cubic cycles with every internal derivative
placement. The independent verifier instead uses the forced open fermion line:
the external vector is either on a matter cubic or a bosonic cubic. Their
complete profile sets agree. The accompanying graph/UV proof excludes a
cubic-plus-quartic graph because its lone matter cubic is a bridge, and
excludes positive-dimensional insertions only from this marginal logarithm.
No finite mass/VEV-dependent amplitude is set to zero.

## Background distinction and limits

B is the total45-component parent field. A is an independent fixed H background;
the physical quantum split uses Q(B-A). Partial_A at fixed B and partial_B
at fixed A are different operations. Neither isolated vertex is automatically
the diagonal B=A response used in a physical background calculation. No such
identity or limit is qualified by this support count.

Census0.6324142s and verifier13.7378002s after imports, both exit0. The census
has one initial private-memory sample2617344 bytes; it does not characterize
its peak. The verifier's8 samples have maximum88817664 bytes, also not a
continuous peak claim.600s/8GiB sampled/350MiB launch floor/16MiB bounds
were unexhausted.35/39 bindings, six exact source copies and full native
captures are preserved. No frozen scientific worker/verifier failed or source
was corrected. Fresh goal-turn E4 completed with exits0,0,0,0,0,2; custody
remains exit2/seven unresolved NOTPASS.

This supplies complete outward support in the stated action/reference domain,
not loop coefficients, counterterm applicability, finite amplitudes, QAP,
finite matter C1, E5/A5 or physical unification. No width/flavor/scheme/foundation
or scientific authority was adopted. Original exclusions,140% singlet warning,
flavor pause, HB1/C5 blocks and quartet failure remain. Shared action, prior
support relaxation, software/runtime and AI author limit independence.

Next calculate the complete auxiliary-vector family from all936 actual cubic
positions, for both B and independent A, keeping BB and both ordered BL/LB
propagators. Derive the universal open-line spin/contour normalization before
model contractions. The other four B topology families remain unmeasured in
this new proper-vertex investigation; no uncomputed coefficient is assigned zero.
