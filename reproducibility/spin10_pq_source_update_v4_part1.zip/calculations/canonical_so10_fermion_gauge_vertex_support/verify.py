"""FGS1 actual primitive reconstruction and forced-open-fermion-line proof."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import product,permutations
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in json.loads((HERE/'validation_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
read=lambda p:json.loads(p.read_bytes());unpack=lambda p:json.loads(gzip.decompress(p.read_bytes()))
D=unpack(HERE/'census_tables.json.gz');oldp=ROOT/'calculations/canonical_so10_sourcefree_cycle_inventory/replay_v2_result.json';r=read(oldp.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(oldp)]==sha256(oldp.read_bytes()).hexdigest();old=read(oldp)
assert D['bosonic_vertices']==old['actual_sourcefree_vertices'] and D['GF_rows']==33092
assert all(v['degree']<=4 and (v['degree']!=2 or v['cd']>=1) for v in old['actual_sourcefree_vertices'].values())
# Reconstruct actual pure-bosonic auxiliary cubics from the primitive's
# antighost left-Euler columns and affine master transformation.
e1=read(PK/'frozen_a10_e1_fermion/replay.json');master=unpack(ROOT/'tools/portable_dh_v1/inputs.json.gz')['master_field_maps'];actual=defaultdict(lambda:s.S.Zero);primitive=defaultdict(lambda:s.S.Zero)
for row in D['literal_auxiliary_cubic_rows']:actual[tuple(sorted(row['word']))]+=s.sympify(row['coefficient'])
for name in [*[f'bar{i}' for i in range(12)],*[f'ub{i}' for i in range(12,45)]]:
 affine=[x for x in master[name] if len(x['word'])==1];expected='b'+name[3:] if name.startswith('bar') else 'L'+name[2:];assert affine==[{'coefficient':'-1','word':[expected]}]
 for row in e1['Euler_columns'][name]:
  if len(row['word'])!=2 or not all(x.startswith(('A','B')) and '__' not in x for x in row['word']):continue
  primitive[tuple(sorted(row['word']+[expected]))]+=-s.sympify(row['coefficient'])
actual={k:s.simplify(v) for k,v in actual.items() if s.simplify(v)};primitive={k:s.simplify(v) for k,v in primitive.items() if s.simplify(v)};assert actual==primitive
# Actual Yukawa support and gauge coupling existence, independent of the
# proposed triangle list. No fixed family values are inserted.
yc=unpack(ROOT/'calculations/canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')
for tag,allowed in [('B10',set(range(306,326))),('B126',set(range(54,306)))]:
 cols={j for i,j,z in yc[tag]['entries'] if s.sympify(z)!=0};assert cols==allowed
assert len(yc['Tminus'])==45 and all(x['entries'] for x in yc['Tminus'])
mat={'MBH':('BH',1,0),'MBM':('BM',1,0),'MYSigma':('X_Sigma',0,1),'MYphi':('X_phi',0,1)}
base={k:v for k,v in old['actual_sourcefree_vertices'].items() if v['degree']==3 and v['cd']==0};edges={tuple(x) for x in old['actual_reference_edges']}|{('F','F')}
def freeze(v):return tuple(map(freeze,v)) if isinstance(v,(list,tuple)) else v
def canon(path):
 candidates=[]
 for seq in [path,tuple((n,e,q,p) for n,e,p,q in reversed(path))]:
  for j in range(3):candidates.append(seq[j:]+seq[:j])
 return min(candidates)
def ep(a,b):return 1 if a==b=='F' or {a[0],b[0]}=={'B','L'} else 2
def forced(es,omit=None):
 M={k:v for k,v in mat.items() if k!=omit};found=set();lower=set()
 def put(path):
  pairs=[(path[j][3][0],path[(j+1)%3][2][0]) for j in range(3)]
  if not all(p in es for p in pairs):return
  degree=4-sum(ep(*p) for p in pairs)+sum(v[2][1]+v[3][1] for v in path);key=canon(path)
  if any(v[1][1] for v in path) or degree<0:lower.add(key)
  else:assert degree==0;found.add(key)
 # External B sits on a matter cubic: the two other matter vertices
 # connect by a bosonic edge and have separate fermion edges to it.
 for a,b,c in product(M,M,['MBH','MBM']):
  if c not in M:continue
  pa,pb,pc=M[a][0],M[b][0],M[c][0]
  put(((a,('F',0),('F',0),(pa,0)),(b,('F',0),(pb,0),('F',0)),(c,(pc,0),('F',0),('F',0))))
 # External B/A sits on a bosonic cubic. The two matter vertices
 # share the fermion edge; each remaining boson ends at that cubic.
 for name,V in base.items():
  for whole in V['ports']:
   for e in range(3):
    if whole[e][0] not in ['BH','BM','AH']:continue
    other=[j for j in range(3) if j!=e]
    for i,j in [other,other[::-1]]:
     if whole[i][0]=='AH' or whole[j][0]=='AH':continue
     for a,b in product(M,M):
      pa,pb=M[a][0],M[b][0]
      put(((a,('F',0),(pa,0),('F',0)),(b,('F',0),('F',0),(pb,0)),(name,tuple(whole[e]),tuple(whole[i]),tuple(whole[j]))))
 return found,lower
profiles,lower=forced(edges);given={freeze(x['cycle']) for x in D['profiles']};assert profiles==given and len(lower)==D['external_jet_lower_degree_profiles']
families=Counter();targets=defaultdict(set)
for row in D['profiles']:
 cycle=freeze(row['cycle']);tags=[v[0] for v in cycle];non=[n for n in tags if n not in mat]
 if not non:family='Yukawa_fermion_triangle' if any(n.startswith('MY') for n in tags) else 'gauge_fermion_triangle'
 else:
  assert len(non)==1;family={'G3':'cubic_vector_triangle','U':'auxiliary_vector_triangle','S3':'scalar_current_triangle'}[base[non[0]]['base']]
 target=row['target'];gd=sum(mat[n][1] if n in mat else base[n]['g'] for n in tags);yd=sum(mat[n][2] if n in mat else 0 for n in tags);assert (gd,yd)==(row['g'],row['Yukawa_vertices']);assert (gd,yd) in [(3,0),(1,2)]
 families[target,family,gd,yd]+=1;targets['A' if target=='AH' else 'B'].add(family)
assert targets['B']=={'gauge_fermion_triangle','cubic_vector_triangle','auxiliary_vector_triangle','Yukawa_fermion_triangle','scalar_current_triangle'} and targets['A']=={'auxiliary_vector_triangle'}
for name,es,omit in [('remove_BL',{e for e in edges if {e[0][0],e[1][0]}!={'B','L'}},None),('remove_Sigma_Yukawa',edges,'MYSigma'),('remove_phi_Yukawa',edges,'MYphi')]:
 alt,unused=forced(es,omit);assert len(alt)==D['controls'][name]['profiles'] and D['controls'][name]['support_changes'] and alt!=profiles
assert not D['new_loop_integrals'] and not D['nonzero_pole_coefficients_claimed']
assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_OUTWARD_FERMION_GAUGE_VERTEX_UV_SUPPORT','elapsed_after_imports':time.perf_counter()-start,'GF_rows_checked':33092,'literal_auxiliary_cubic_positions':len(D['literal_auxiliary_cubic_rows']),'primitive_reconstructed_auxiliary_positions':len(primitive),'auxiliary_role_counts':D['auxiliary_role_counts'],'typed_cycle_profiles':len(profiles),'external_derivative_lower_degree_profiles':len(lower),'family_profiles':[[*k,v] for k,v in sorted(families.items())],'B_topology_families':5,'independent_A_topology_families':1,'positive_dimension_and_quartic_bridge_exclusion_proof':'SUPPORT_PROOF.md','mixed_edges_required':True,'both_Yukawa_carriers_required':True,'outward_support_not_nonzero_coefficient_claim':True,'nonzero_poles_measured':False,'new_loop_integrals':0,'full_counterterm_QAP_or_matching_proved':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
