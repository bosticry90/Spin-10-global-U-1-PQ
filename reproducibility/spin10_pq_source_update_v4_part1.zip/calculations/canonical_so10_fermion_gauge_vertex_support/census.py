"""FGS1 literal auxiliary GF census and full typed triangle-cycle search."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import permutations,product
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in json.loads((HERE/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
oldp=ROOT/'calculations/canonical_so10_sourcefree_cycle_inventory/primary_v2_result.json';r=json.loads((oldp.parent/'validation_receipt.json').read_bytes());assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(oldp)]==sha256(oldp.read_bytes()).hexdigest();old=json.loads(oldp.read_bytes())
vertices=old['actual_sourcefree_vertices'];edges={tuple(x) for x in old['actual_reference_edges']}|{('F','F')}
for label,role,gd,yd in [('MBH','BH',1,0),('MBM','BM',1,0),('MYSigma','X_Sigma',0,1),('MYphi','X_phi',0,1)]:vertices[label]={'base':label,'degree':3,'g':gd,'y':yd,'cd':0,'ports':[[['F',0],['F',0],[role,0]]]}
gf=json.loads(gzip.decompress((ROOT/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))['gauge_fixing_density'];selected=[];coarse=Counter()
def role(n):
 b=n.split('__')[0]
 if b.startswith('bar'):return 'aH'
 if b.startswith('ub'):return 'aM'
 if b.startswith('b') and b[1:].isdigit():return 'LH'
 if b.startswith('L') and b[1:].isdigit():return 'LM'
 if b.startswith('B'):return 'BH' if int(b[1:].split('_')[0])<12 else 'BM'
 if b.startswith('A'):return 'AH'
 return None
for i,row in enumerate(gf):
 rr=[role(n) for n in row['word']]
 if len(rr)!=3 or rr.count('LH')+rr.count('LM')!=1 or sum(v in ['BH','BM','AH'] for v in rr)!=2:continue
 assert all('__' not in n for n in row['word']);selected.append({'ordinal':i,**row});coarse[tuple(sorted(rr))]+=1
def options(V):
 out=set()
 for name,v in V.items():
  if v['degree']!=3 or v['cd']!=0:continue
  for ports in v['ports']:
   for i,j in permutations(range(3),2):
    if ports[i][0]=='AH' or ports[j][0]=='AH':continue
    k=3-i-j;out.add((name,tuple(ports[k]),tuple(ports[i]),tuple(ports[j])))
 return sorted(out)
def canon(path):
 variants=[]
 for seq in [path,tuple((n,e,q,p) for n,e,p,q in reversed(path))]:
  for j in range(3):variants.append(seq[j:]+seq[:j])
 return min(variants)
def edgepower(a,b):
 assert (a,b) in edges
 return 1 if a==b=='F' or {a[0],b[0]}=={'B','L'} else 2
def search(es,omit_scalar=None):
 opts=options({n:v for n,v in vertices.items() if n!=omit_scalar});fe=[v for v in opts if v[1][0]=='F'];ve=[v for v in opts if v[1][0] in ['BH','BM','AH']];found={};lower=set()
 for a,b,c in product(fe,fe,ve):
  path=(a,b,c);pairs=[(path[j][3][0],path[(j+1)%3][2][0]) for j in range(3)]
  if not all(p in es for p in pairs):continue
  degree=4-sum(edgepower(*p) for p in pairs)+sum(v[2][1]+v[3][1] for v in path);gd=sum(vertices[v[0]]['g'] for v in path);yd=sum(vertices[v[0]].get('y',0) for v in path);key=canon(path)
  if c[1][1] or degree<0:lower.add(key);continue
  assert degree==0
  found[key]={'target':c[1][0],'g':gd,'Yukawa_vertices':yd,'cycle':key,'edges':[(key[j][3][0],key[(j+1)%3][2][0]) for j in range(3)],'UV_degree':degree}
 return [found[k] for k in sorted(found)],len(lower)
profiles,lower=search(edges);controls={}
for name,es,omit in [('remove_BL',{e for e in edges if {e[0][0],e[1][0]}!={'B','L'}},None),('remove_Sigma_Yukawa',edges,'MYSigma'),('remove_phi_Yukawa',edges,'MYphi')]:
 alt,_=search(es,omit);controls[name]={'profiles':len(alt),'support_changes':{str(x['cycle']) for x in profiles}!={str(x['cycle']) for x in alt}}
data={'schema':'FGS1_COMPLETE_TYPED_FERMION_GAUGE_SUPPORT','GF_rows':len(gf),'literal_auxiliary_cubic_rows':selected,'auxiliary_role_counts':[[list(k),v] for k,v in sorted(coarse.items())],'bosonic_vertices':{k:v for k,v in vertices.items() if not k.startswith('M')},'matter_vertices':{k:v for k,v in vertices.items() if k.startswith('M')},'reference_edges':sorted(edges),'profiles':profiles,'external_jet_lower_degree_profiles':lower,'controls':controls,'nonzero_pole_coefficients_claimed':False,'new_loop_integrals':0}
raw=(json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'census_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-start,'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
