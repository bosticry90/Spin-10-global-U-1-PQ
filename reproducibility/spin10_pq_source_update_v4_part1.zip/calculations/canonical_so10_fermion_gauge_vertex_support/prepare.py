"""FGS1 six-source freeze and existing full-action/reference qualifications."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
BASE='2a228574c76c69a4154d35ad623ce902f18be382';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-gauge-vertex-support-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();z=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert z==h,str(p)
 b[str(p)]=z
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V500.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
add(ROOT/'tools/portable_dh_v1/inputs.json.gz','7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb')
for n in ['export_a10_e5_antighost_vector.py','frozen_a10_e1_fermion/replay.json','frozen_a10_e1_fermion/bindings.json','frozen_a10_e1_fermion/validation_receipt.json']:add(PK/n)
for fold,names in {'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json'],'canonical_so10_yukawa_carrier_transport':['replay_tables.json.gz','validation_receipt.json'],'canonical_so10_sourcefree_cycle_inventory':['primary_v2_result.json','replay_v2_result.json','validation_receipt.json','RESULT.md'],'canonical_so10_matter_source_uv_assembly':['RESULT.md','validation_receipt.json'],'canonical_so10_fermion_gauge_kinetic_pole':['RESULT.md','validation_receipt.json']}.items():
 for n in names:add(ROOT/'calculations'/fold/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(ROOT/'calculations/canonical_so10_matter_source_uv_assembly/validation_receipt.json','c1c90fa9529f19d83270d17ce3348603c907d14ba2bd5ea42a6af57eae6cae24')
bind=json.loads((PK/'frozen_a10_e1_fermion/bindings.json').read_bytes());add(PK/'frozen_a10_e1_fermion/replay.json',bind['byte_sha256'][(PK/'frozen_a10_e1_fermion/replay.json').relative_to(ROOT).as_posix()])
for name in ['RECORD.md','census.py','verify.py','prepare.py','run.py','SUPPORT_PROOF.md']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30713
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'FGS1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FGS1_FROZEN',len(b),'bindings',flush=True)
