# FGS1: complete proper fermion/gauge UV support before amplitude calculation

Question: which one-loop, source-free, marginal P-P-B and P-P-A vertex
families are supported by the actual provisional matter action and the
qualified full bosonic vertex/reference inventory? The answer determines
which amplitudes must be calculated before counterterm applicability, without
importing an incomplete linear-gauge formula.

Types: physical Nambu P odd(dim3/2), total45-field B even(dim1), independent
fixed H background A even(dim1), Lambda even(dim2),328 real scalars(dim1).
Ghost and antighost fields remain but have no direct matter cubic. Sterile
variables have no interaction; their hatted mixing remains inside the physical
pp propagator. No new field, source pair, physical width or flavor choice.

Reuse the qualified16-family bosonic bare-action support with all34 physical
parameter coefficients and actual reference edges. It is an OUTWARD role
envelope: color/Lorentz/chirality cancellations remain to be calculated.
SMA1/YCT1 supply only FFB_H,FFB_M,FFX_Sigma,FFX_phi matter cubics. The latter
use symbolic Yukawa matrices; Phi54 and S have exactly zero Yukawa maps.
No matter quartic, FFLambda or FFghost exists in this action.

Primary separately reads all33092 literal GF rows, preserving exact LambdaBB
and LambdaAB coefficients and original ordinals. It enumerates all proper
three-cubic cycles with two external F and one external B_H/B_M/A_H, including
both mixed propagator orientations, internal derivatives and coupling powers.
All positive-dimensional insertions and external-derivative candidates must
be excluded only from this marginal UV target by an explicit dimension proof.

Independent verifier reconstructs the actual pure-bosonic GF cubic from E1
primitive antighost Euler columns and affine qantighost=-Lambda, then uses
the forced open-fermion-line graph structure rather than the primary cycle
search to enumerate the complete typed support. Retain witness information
and exact derivative placements. No amplitude multiplicity or nonzero pole
is inferred from a profile count.

Hypotheses to test: five B families (gauge-fermion, cubic-vector, nonlinear
auxiliary-vector, Yukawa-fermion and scalar-current triangles), and an
independent-A auxiliary-vector class. Discovering another supported family
or a missing one changes the next action; do not alter the action to fit this
hypothesis. Delete mixed edges and individual Yukawa carriers as controls.

Freeze six sources/copies and inputs before two sequential native observed
workers, each600s after imports, sampled private cap8GiB, launch floor350MiB,
package cap16MiB. Run fresh delegated E4 readiness this goal turn; custody
exit2/seven unresolved remains NOTPASS. Exhaustion is INCOMPLETE. Preserve
all old files, failed runs, main and sole project_state scientific authority.

Ceiling: complete outward UV support for this actual action/reference domain,
not measured nonzero coefficients, a full finite vertex, background identity,
counterterm restoration, finite matter C1, QAP, E5/A5 or physical unification.
Independent A is held fixed when differentiating B; diagonal B=A is a different
operation. No scheme/foundation adoption, flavor activation or blocked stage.

AI question: can the researcher identify all action-permitted diagram classes
and derivative restrictions before choosing formulas? Shared action, old
support relaxation, software/runtime and AI author limit independence. The
result will record actual resources, complete evidence, failures and next step.
