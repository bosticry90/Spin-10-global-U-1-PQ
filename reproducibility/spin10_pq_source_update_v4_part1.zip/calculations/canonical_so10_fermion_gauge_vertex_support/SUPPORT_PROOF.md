# FGS1 graph and UV completeness argument

For a connected one-loop graph with three external legs,
sum_v(valence_v-2)=3. The renormalizable action has at most quartics.
Without bivalent insertions the possibilities are three cubics, or a cubic
and a quartic. There is no matter quartic. In the latter case both external
fermions must be on the lone matter cubic. Its single remaining quantum port
is a bridge, so the graph is1PR, even if a bosonic tadpole closes elsewhere.

In a proper three-cubic cycle, each vertex has two internal ports and one
external leg. The two external F legs are on two different matter vertices.
The third external gauge/background leg is either on another matter vertex
or on one bosonic cubic. Reference F-F propagation is the physical pp block,
including its sterile hatted mixing; it has UV degree-1. The bosonic edges
are BB of degree-2, BL/LB of degree-1 and same-scalar XX of degree-2.
There is no LL or integrated-A propagator. The existing role inventory gives
all admissible bosonic cubics and their internal derivative placements.

The external dimension is 3/2+3/2+1=4. Local marginal UV support therefore
has coefficient dimension0 and no external jets. Each positive-dimensional
mass/VEV/orbit/reference insertion lowers the UV degree, as does a Taylor
mass expansion. Such terms cannot give a marginal local logarithm without
forbidden inverse physical parameters. They are not set to zero as finite
amplitudes. Dimension-zero bivalent kinetic/width terms are already resummed
in the qualified reference Green matrix, rather than added as interactions.
Any derivative on the external gauge leg is retained as a lower-degree
candidate but cannot enter this nonderivative local target.

The five hypothesized B topology classes have different numerator degrees.
The ordinary VVV triangle has one fermion, two BB edges and an internal
derivative. The nonlinear GF LambdaBB triangle instead has one fermion,
one BB and one BL edge and no derivative. Both can have degree0; the second
cannot be eliminated by using the first's kernel. The Yukawa triangles require
their actual scalar carrier and gauge-current support, not a generic scalar
quartic. This counting fixes possible classes, not loop signs or coefficients.

Matter depends on B as the total parent gauge field. Independent background
A enters the gauge fixing, while the physical split uses Q(B-A). Therefore
partial_A at fixed B and partial_B at fixed A must be kept distinct. A result
for either is not automatically the diagonal-background B=A response needed
by a physical matching calculation. No such limit or Ward identity is assumed.
