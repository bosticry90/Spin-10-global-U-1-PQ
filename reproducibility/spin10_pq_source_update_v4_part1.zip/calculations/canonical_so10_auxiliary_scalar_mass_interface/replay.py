"""ASM1 action derivatives and independently recovered auxiliary dual frame."""
from data import *
from collections import defaultdict
start=begin('replay');gf=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']
aux=[f'b{a}' if a<12 else f'L{a}' for a in range(45)];scalar=[f'x_{tag}_{i}' for tag,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(n)]
names={n:s.Symbol(n) for n in [*aux,*scalar]};kr=defaultdict(lambda:s.S.Zero);ds=[defaultdict(lambda:s.S.Zero) for _ in range(4)];count=0
for row in gf:
 word=row['word'];aa=[n for n in word if n in aux]
 if len(word)!=2 or len(aa)!=1:continue
 other=next(n for n in word if n!=aa[0]);a=aux.index(aa[0]);v=s.sympify(row['coefficient'])
 if other in scalar:
  # Independent coefficient as the actual two commuting field derivatives.
  density=v*names[aa[0]]*names[other];co=s.diff(density,names[aa[0]],names[other]);u=s.Poly(co,g,xi).coeff_monomial(g*xi);assert s.expand(co-g*xi*u)==0
  kr[a,scalar.index(other)]+=u;count+=1
 elif other.startswith('B') and '__' in other:
  base,jet=other.split('__');b,mu=map(int,base[1:].split('_'));assert jet==str(mu)
  ds[mu][a,b]+=v
K=s.SparseMatrix(45,328,dict(kr));D=[s.SparseMatrix(45,45,dict(d)) for d in ds]
assert all(not (D[mu]-([1,-1,-1,-1][mu])*D[0]).todok() for mu in range(4))
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['C3_plane_to_parent']);plane=(-Q*D[0].inv()*K).applyfunc(s.simplify)
# Recover scalar identity from the separately supplied replay chart, do not
# silently assume it in the dual-coordinate formula.
ref=read(PK/'frozen_a10_e5_full_hessian/replay.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};SX=dec(ref['physical_to_raw_inverse']).extract([fi[n] for n in scalar],list(range(180,508)))
assert SX==s.eye(328)
y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');images=[]
for key in ['B10','B126']:
 B=dec(y[key]);columns=defaultdict(list)
 for (a,col),z in plane.todok().items():columns[col].append((a,z))
 result=defaultdict(lambda:s.S.Zero)
 for (i,col),z in B.todok().items():
  for a,c in columns[col]:result[i,a]+=z*c
 images.append(s.SparseMatrix(256,45,dict(result)).applyfunc(s.simplify))
finish('replay',{'method':'literal_two_field_derivatives_and_dual_frame_from_Lambda_partialB','raw_K':enc(K),'derivative_D':enc(D[0]),'plane_K':enc(plane),'Yukawa_images':list(map(enc,images)),'literal_Lambda_scalar_positions':count,'Lorentz_derivative_blocks_checked':4,'stripped_coefficient':'g10*xi','new_loop_integrals':0},start)
