# ASM1: the actual GF mass bilinear is the full vacuum-orbit tensor

The432 literal Lambda*x coefficients, transported to the normalized plane
frame of the matched matter action, give exactly

    GF_mass = g10*xi * Lambda_plane^T O^T x,
    O_a=rho_a v.

The coefficient is +1, including the actual auxiliary convention with
derivative term -Lambda_plane*partial B_plane. No extra2, inverse width,
new VEV normalization or numerical coupling is introduced. The complete
orbit contains all scalar sectors before any matter projection.

Receipt `validation_receipt.json`, SHA-256
`53a457415b6c0cc2240661fd4899fb34816d3ad6860bfab6b6b27bbad38d6eb1`,
QUALIFIED_ACTUAL_AUXILIARY_SCALAR_MASS_INTERFACE. Scientific/director
acceptance NOT_PERFORMED; state113/34of39 unchanged. No loop was calculated.

## Two coordinate derivations

The primary parses the actual portable GF density and builds its45x328
raw bilinear. It uses the full643 inverse chart, with physical auxiliary
slots508..552 distinguished from raw ghost names, to form its congruence.
The actual C3 map then transports normalized gauge/auxiliary coordinates
to the plane basis used by the matched Yukawa tensors.

The replay differentiates the two-field density, reconstructs the
auxiliary dual-coordinate map from the independently extracted derivative
Lambda*partial B matrix D, and obtains -Q*D^-1*Kraw. It checks all four
Lorentz blocks. This inverse is a constant coordinate map, not an inverse
physical coupling or a new field-dependent transformation. The Yukawa
contractions are computed by explicit component summation.

All14760 mixing positions and23040 two-carrier matter-projection positions
agree. The gate checks both full643 chart inverses for both input routes
(1653796 entries), the real normalized gauge-frame orthogonality, scalar
chart identity and Ti_L^T D Ti_B=-I. Raw-frame substitution would change829
positions. Sign reversal, half normalization and omission of the entire
nonzero mixing tensor are distinguishable. These are classical controls.

An exact projection onto O^T gives coefficient1 and zero residual in every
position. This recognizes an identity in an already fixed action tensor;
no action/loop coefficient is fitted or selected from a desired cancellation.
The12 unbroken-H directions have zero image, as the actual orbit requires.

## Matched matter projections

For each complete carrier, the contraction is B_R*Kplane^T=B_R*O.
Thus, before any family matrix is numerically specified,

    B10*O=0,
    (B126*O)_a=i(T_a^T M126+M126*T_a).

The126 image contains85 nonzero coefficient positions; its full256x45 zero
complement is retained. The10 image vanishes across all11520 positions.
The126 proportionality coefficient is1 with zero residual, and all45
mass-direction equations are checked for each carrier. For general family
matrices the126 result tensors with Y126; this does not choose its spectrum.
The10 zero concerns this vacuum-orbit insertion, not every scalar coupling.

This provides the complete action-derived scalar/auxiliary vertex needed
before sewing the mixed gauge/scalar fermion self-energy. The leading
BL propagator, scalar propagator and fermion numerator can generate a
logarithmic mass pole with this dimension-one insertion. The sign and
coefficient of that loop must still be derived from its ordered vertices;
they are not implied by the classical interface or by YCA's deltaY*v.

## Execution, AI capability and remaining limits

Primary/replay/gate COMPLETED exit0 in7.6589320/7.5194316/9.8736952s after
imports. Their5/5/6 samples have private maxima79,872,000/80,859,136/
63,873,024 bytes, respectively; no continuous peak claim. Frozen600s/
8GiBsampled/350MiBfloor/16MiB limits were unexhausted. Preparations bind36/43
paths and seven source copies. No scientific worker/verifier failed and no
source correction was needed. YCA's fresh current-turn readiness was
authenticated/reused, not rerun; custody remains exit2/seven NOTPASS.

The AI-capability result is a complete historical-to-canonical tensor
transport checked by an independently recovered dual frame. Reuse avoids
expanding another fermionic loop before its exact input is known. Shared
GF/action, supplied chart, covariance/matter maps, Python/SymPy and AI
authorship limit independence. This is internal mathematical corroboration,
not external expert or experimental validation of the model.

No mass pole, source/VEV/tadpole normalization, finite-hat completion,
fermionic phase/measure/QAP/forest, finite matter C1 or physical matching
has been qualified here. No finite scheme, flavor fit, new benchmark or
foundation was adopted. Prior exclusions, finite-point140% singlet warning,
flavor pause, HB1/C5 blocks, quartetFAIL and custody remain unchanged.

Next: derive the complete leading gauge-exchange plus mixed BL/scalar
fermion mass UV pole using this actual vertex and SMP's physical propagator.
Retain the two oriented mixed branches, the inherited positive-hat numerator,
all widths and their mass/source/VEV interpretation. Only then identify
which mass normalization data remain missing. Do not impose a cancellation.
