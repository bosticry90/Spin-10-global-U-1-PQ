# ASM1: actual auxiliary-scalar mass-insertion interface

Base e650bb918cd4d0be18980324938bab3e6ccdb738/main,30447 tracked blobs.
Question: what is the actual432-position GF Lambda*x bilinear in the same
normalized plane/scalar frame as the matched matter action? This precedes
the mixed gauge/scalar fermion mass-pole calculation, not another new loop.
FSV's dimensionless vertex exclusion does not discard this dimension-one
interaction. No VEV, tadpole or source normalization is selected here.

Freeze live AGENTS/charter/state/V491/local/solo conventions, portable GF,
full643 reference charts, primary/replay physical reconciliation and orbit,
YCT matched odd-Fock maps/mass and covariance receipt, FSV support, GFK
mixed-reference inverse and YCA parameter-pole receipt. All old receipts,
sources, policies, failures and physical exclusions remain immutable.

Actual GF rows have coefficient g10*xi times a constant in the retained
reference geometry. Extract that coefficient without setting either symbol
to a numerical value or introducing an inverse coupling in a counterterm.
The resulting raw45x328 matrix Kraw is a measured action coefficient.
Scalar real order Phi54,Sigma252,phi20,S2; raw auxiliary names b0..b11,
L12..L44; raw gauge names Ba_mu. The complete643 chart must distinguish
raw ghost index508 from normalized physical auxiliary index508.

Primary: parse the literal density, extract all432 terms, and use the
independently qualified full643 inverse chart for bilinear congruence.
If F=Q*Ti_B is the normalized physical-gauge-to-plane map, transport the
auxiliary scalar block to Kplane=F*Ti_L^T*Kraw*Ti_x. Q is the actual C3
plane map, not an orthogonal approximation to a complex historical chart.
Compute all B_R*Kplane^T from the actual matched Yukawa maps.

Replay: parse density by derivatives in its two field roles and recover
the auxiliary dual map from the derivative Lambda*partial B term D.
The canonical reference has coefficient -Lambda*partial B; hence the
independently derived dual-coordinate result is -Q*D^-1*Kraw, with the
scalar chart checked explicitly. Do not guess a sign from a desired Ward
identity. Check all four Lorentz coefficients before using D from mu0.
Use component summation for the B_R contraction rather than matrix product.

Gate: compare the complete45x328 matrices and both256x45 matter projections,
including zeros. Check full chart inverse, orthogonality of F, scalar-chart
identity, and Ti_L^T*D*Ti_B=-I. These fix the convention linking the routes.
Compare Kplane with the actual vacuum orbit O^T by exact projection and
preserve the full residual, even if nonzero. Independently compare each
matter projection with B_R*O; derive any proportionality, never fit a loop
or change the GF action. A nonzero residual can describe a different gauge
functional; it is not automatically an anomaly. Check the12H null image
and sign/normalization/raw-frame/omitted-block controls where sensitive.

Possible outcomes: matched complete classical mass-insertion interface;
matched non-orbit action tensor retained for the future loop; exact frame
mismatch or underdefinition; resource incomplete. No loop pole is inferred
from this calculation. No beta, numerical flavor, finite matching, QAP or
source/evanescent completion is claimed. YCA's field image does not yet
define physical VEV/tadpole renormalization. Authority ceiling34/39 unchanged.

Freeze seven sources/copies before sequential primary/replay/gate, with
peer-output denial.600s each after imports,8GiB sampled private cap,350MiB
launch floor,16MiB package cap. No agents; preserve exact failed/unfinished
runs before versioned correction. Shared GF, reference/chart, matter map,
software and AI authorship limit independence; not external confirmation.
Use fresh current-turn E4 from YCA by authenticated reuse if unchanged.
Scientific/director acceptance NOT_PERFORMED. No state, foundation, branch,
worktree, publication/push or paused/blocked-stage change. Record actual
resources, failures, significance and smallest next calculation in RESULT.
