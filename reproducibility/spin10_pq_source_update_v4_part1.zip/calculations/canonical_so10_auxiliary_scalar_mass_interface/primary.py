"""ASM1 literal action extraction and full-reference congruence."""
from data import *
start=begin('primary');gf=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fields=ref['field_order'];fi={n:i for i,n in enumerate(fields)}
aux=[f'b{a}' if a<12 else f'L{a}' for a in range(45)];sc=[f'x_{tag}_{i}' for tag,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(n)]
ai={n:i for i,n in enumerate(aux)};si={n:i for i,n in enumerate(sc)};K=s.SparseMatrix(45,328,{});D=s.SparseMatrix(45,45,{});positions=0
for row in gf:
 word=row['word']
 if len(word)!=2:continue
 an=[n for n in word if n in ai];sn=[n for n in word if n in si]
 if an and sn:
  v=s.expand(s.sympify(row['coefficient']));u=v.coeff(g).coeff(xi);assert s.expand(v-g*xi*u)==0
  K[ai[an[0]],si[sn[0]]]+=u;positions+=1
 if an:
  bs=[n for n in word if n.startswith('B') and n.endswith('_0__0')]
  if bs:D[ai[an[0]],int(bs[0][1:].split('_')[0])]+=s.sympify(row['coefficient'])
assert positions==432
Ti=dec(ref['physical_to_raw_inverse']);Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent'])
TB=Ti.extract([fi[f'B{a}_0'] for a in range(45)],list(range(0,180,4)));TL=Ti.extract([fi[n] for n in aux],list(range(508,553)));SX=Ti.extract([fi[n] for n in sc],list(range(180,508)))
F=Q*TB;physical=TL.T*K*SX;plane=(F*physical).applyfunc(s.simplify)
y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');images=[dec(y[n])*plane.T for n in ['B10','B126']]
finish('primary',{'method':'literal_density_raw_matrix_and_full643_bilinear_congruence','raw_K':enc(K),'derivative_D':enc(D),'gauge_to_plane_F':enc(F),'T_B':enc(TB),'T_L':enc(TL),'scalar_chart':enc(SX),'physical_K':enc(physical),'plane_K':enc(plane),'Yukawa_images':list(map(enc,images)),'literal_Lambda_scalar_positions':positions,'stripped_coefficient':'g10*xi','new_loop_integrals':0},start)
