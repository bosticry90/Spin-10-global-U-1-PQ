"""ASM1 complete frame comparison and measured orbit/projection relation."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
for key in ['raw_K','derivative_D','plane_K']:zero(dec(P[key])-dec(R[key]))
for a,b in zip(P['Yukawa_images'],R['Yukawa_images']):zero(dec(a)-dec(b))
for D in [P,R]:assert D['literal_Lambda_scalar_positions']==432 and D['stripped_coefficient']=='g10*xi' and D['new_loop_integrals']==0
F,TB,TL,SX=[dec(P[k]) for k in ['gauge_to_plane_F','T_B','T_L','scalar_chart']];zero(F.T*F-s.eye(45));zero(F*F.T-s.eye(45));zero(SX-s.eye(328))
zero(TL.T*dec(P['derivative_D'])*TB+s.eye(45))
for role in ['primary','replay']:
 rr=read(PK/f'frozen_a10_e5_full_hessian/{role}.json')['retained_reference'];T,Ti=[dec(rr[k]) for k in ['physical_to_raw_kernel','physical_to_raw_inverse']];zero(T*Ti-s.eye(643));zero(Ti*T-s.eye(643))
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);raw=dec(P['raw_K']);K=dec(P['plane_K']);zero(K-F*dec(P['physical_K']))
assert tidy(K+K).todok() and tidy(K-K/2).todok()
raw_difference=tidy(K-raw);assert raw_difference.todok()
a=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');O=dec(a['vacuum']['orbit']);O2=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['vacuum']['orbit']);zero(O-O2)
norm=sum(v*v for v in O.todok().values());c=s.simplify(sum(z*O[j,i] for (i,j),z in K.todok().items())/norm);residual=tidy(K-c*O.T)
y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');H=dec(y['H_new']);Himage=tidy(H.T*K);projection=[]
for key,img in zip(['B10','B126'],P['Yukawa_images']):
 B=dec(y[key]);N=dec(img);target=tidy(B*O);n=sum(s.conjugate(z)*z for z in target.todok().values())
 if n:
  co=s.simplify(sum(s.conjugate(z)*N[i,j] for (i,j),z in target.todok().items())/n);rem=tidy(N-co*target)
 else:co=None;rem=N
 projection.append({'carrier':key,'orbit_factor':str(co) if co is not None else None,'orbit_projection_zero':not bool(target.todok()),'image_nonzero_positions':len(N.todok()),'residual_nonzero_positions':len(rem.todok())})
 # Confirm derivative of the actual matched mass, independent of GF transport.
 mass=dec(y['mass10' if key=='B10' else 'mass126']);Ts=list(map(dec,y['Tminus']))
 for j,t in enumerate(Ts):zero(s.Matrix(16,16,list(target[:,j]))-s.I*(t.T*mass+mass*t))
assert not Himage.todok()
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_ACTUAL_AUXILIARY_SCALAR_MASS_INTERFACE','elapsed_after_imports':time.perf_counter()-start,'raw_GF_positions':432,'complete_mixing_positions_compared':45*328,'matter_projection_positions_compared':2*256*45,'full643_chart_inverse_positions_checked':2*2*643**2,'gauge_frame_orthogonality_checked':True,'canonical_auxiliary_derivative_sign':'-1','scalar_chart_identity':True,'raw_frame_substitution_control_nonzero_positions':len(raw_difference.todok()),'unbroken_H_image_nonzero_positions':len(Himage.todok()),'full_orbit_least_squares_factor':str(c),'full_orbit_residual_nonzero_positions':len(residual.todok()),'matter_projections':projection,'new_loop_integrals':0,'mass_pole_or_VEV_normalization_qualified':False,'finite_source_evanescent_QAP_or_matching_qualified':False,'physical_flavor_or_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
