"""FMU1 immutable input/source freeze before ordered mass calculation."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
BASE='7a09d0071cfac93334d10037b9949369c12a5db0';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-mass-uv-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V492.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
for n in ['export_a10_e5_antighost_vector.py','frozen_a10_e5_full_hessian/primary.json','frozen_a10_physical_reconciliation/full_primary.json','frozen_a10_physical_reconciliation/full_replay.json']:add(PK/n)
for folder,names in {
 'canonical_so10_yukawa_carrier_transport':['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json'],
 'canonical_so10_sterile_massive_propagator':['RESULT.md','validation_receipt.json'],
 'canonical_so10_fermion_scalar_vertex_support':['RESULT.md','validation_receipt_v3.json'],
 'canonical_so10_auxiliary_scalar_mass_interface':['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_fermion_gauge_kinetic_pole':['RESULT.md','validation_receipt.json'],
 'canonical_so10_gauge_yukawa_vertex_poles':['DERIVATION.md','RESULT.md','replay_v2_tables.json.gz','validation_receipt_v2.json'],
 'canonical_so10_yukawa_counterterm_assembly':['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],
 'canonical_so10_fermion_kinetic_mass_poles':['RESULT.md','validation_receipt_v2.json'],
 'canonical_so10_yukawa_polarization_poles':['RESULT.md','validation_receipt_v2.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
for n,h in {
 'project_state.json':'d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8',
 'calculations/canonical_so10_auxiliary_scalar_mass_interface/validation_receipt.json':'53a457415b6c0cc2240661fd4899fb34816d3ad6860bfab6b6b27bbad38d6eb1',
 'calculations/canonical_so10_yukawa_counterterm_assembly/validation_receipt.json':'323d78b8262e0b9ec86ca55fdcf1a59b2e6328a0fcf17926dac0e547ac364980',
 'calculations/canonical_so10_sterile_massive_propagator/validation_receipt.json':'53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c'}.items():add(ROOT/n,h)
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30473
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'FMU1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FMU1_FROZEN',len(b),'bindings',flush=True)
