# FMU1: the proper mass pole and a necessary projected VEV image

At the inherited reference geometry, the actual one-loop proper fermion
mass pole is

    L_M = -[g10²/(16*pi²*epsilon)]*(5/8)*(3+xi)*M,
    M=Y126 tensor M126.

The two family matrices remain general complex symmetric3x3. This is the
proper two-point local UV coefficient; reducible tadpoles and finite pole
masses require separate calculations. No numerical flavor point is chosen.

Receipt `validation_receipt.json`, SHA-256
`b494bbb94f65e86b54e3ba574bc4a1498160793deebe5e028cb83dc87c149b2f`,
QUALIFIED_COMPLETE_PROPER_FERMION_MASS_UV_POLE_AND_NECESSARY_PROJECTED_VEV_IMAGE.
Scientific/director acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

## Physical kinetic mixing must accompany the GF insertion

V492's prospective next-step description listed gauge exchange and the
auxiliary-scalar mixing. The physical kinetic action also contributes a
Bx mixing after expansion about v. Both are included here. This corrects
the future calculation domain; ASM's qualified classical tensor is intact.

A common explicit Wick congruence fixes

    V_Bx,kin=+i*g10*q O^T, V_xB,kin=-i*g10*O q^T,
    V_Lx,GF=+i*g10*xi*O^T, V_xL,GF=+i*g10*xi*O.

The auxiliary phase follows from the same transformation that produces
the existing positive scalar/gauge reference and ordered BL inverse. It
is not selected to enforce a cancellation. The self-energy boson momentum
is q=-k, which fixes both mixed-branch orientations.

Each kinetic scalar-current contribution is individually nonzero. In the
actual126 mass direction its value is +(25/4)*xi*M in stripped gauge-pole
units. Each auxiliary companion is -(25/4)*xi*M. They cancel pair by pair.
The full O orbit and its12H null image are used before this conclusion.

The remaining exchange is -3J_I(M)-J_W(M). Direct actual45-generator
contraction gives J_I=(5/8)M and J_H=0, hence J_W=xi*J_I. A separate
scalar-Casimir/covariance calculation reproduces these tensors. The10
vacuum mass image and each associated tensor vanish; that does not set
its general Yukawa interactions or finite amplitudes to zero.

The qualified YPP pure-Yukawa mass UV zero is authenticated reuse. No
fermion quartic exists, and the actual pair of matter vertices exhausts
the proper one-loop two-point support described in RECORD. Positive-
dimension higher insertions cannot supply another degree-one local pole
without forbidden inverse masses. Reducible tadpole diagrams remain outside
this proper self-energy, not outside eventual physical mass matching.

## Consequence for a mass-visible VEV counterterm

Combining this independently derived pole with the measured GFK/FYS field
poles and YCA Yukawa parameter poles requires the VEV contribution visible
through the126 mass map to be

    B126(delta v), multiplied by Y126
      = [(25/4)*(3+xi)*g10²-k126/4]*M/(16*pi²*epsilon),
    k126=Tr_family(Y126dagger*Y126).

The ordinary scalar half-field contribution would instead be

    [(25/4)*(3-xi)*g10²-k126/4]*M/(16*pi²*epsilon).

Their nonzero difference is

    (25/2)*xi*g10²*M/(16*pi²*epsilon).

Thus using the scalar field factor alone for the VEV would leave an exact
mass-direction remainder. The Yukawa trace already counts all3 families;
there is no extra family3. Neither this subtraction nor the mass map
determines scalar directions in its kernel or a finite tadpole condition.

This agrees with the mass-visible projection of the familiar additional
background-field renormalization in Rxi gauges: arXiv1305.1548v3 Eq17c,
20a,23, https://arxiv.org/abs/1305.1548 . Its extra factor is2g²*xi*xi'*Cs;
the current GF coefficient permits xi'=1 in this bounded comparison.
The coefficient was compared after the actual loop result, not imported
to choose its diagram signs. The paper's background source doublet, ST
domain and finite prescription are not automatically the project's own.

## Verification and limits

Primary uses the full vector/auxiliary/scalar Wick congruence, direct4-spin
angular averaging and actual45-matrix contractions. Replay differentiates
an independently inverted longitudinal3-block symbol, checks split8-spin
identities, positive-IR-mass radial residues and the separate Casimir image.
Five individual mass tensors in each carrier compare across2560 positions,
including their zero complements. Their holomorphic/conjugate units are
(-4,-1,-i,-i,+i,+i) and their conjugates. The mixed propagation phases and
unexpanded d-dependent factors also agree. Full family/internal mass
factorization checks2304 slots, and the necessary projected VEV equation
checks9 complex polynomial positions.

Omitting either mixing source or one oriented component leaves a nonzero
remainder; reversing its relative phase also changes the individual terms.
Width substitution xi->etaH, extra open-line half and family3 are sensitive.
The mass-chirality relation is checked before color projection. Removing
both mixing groups together would be invisible to their summed pole; the
individual-kernel comparison prevents that omission from being credited
as a valid derivation. Likewise the UV residue alone cannot distinguish
SMP's finite-hat reference difference: that limitation is explicit, and
the actual bar k² mass numerator is retained rather than claiming a finite
reference conversion. There is no closed-loop Pfaffian half on the open line.

Primary/replay/gate COMPLETED exit0 in4.4662861/3.8260527/3.0773422s after
imports. Each has3 private-memory samples, with maxima53,321,728/62,160,896/
61,329,408 bytes; these are sampled maxima, not peaks. Frozen600s/
8GiBsampled/350MiBfloor/16MiB limits unexhausted.54/61 input bindings and
eight exact source copies remain. No worker/verifier failed and no frozen
source was corrected. Fresh current-turn E4 completed0,0,0,0,0,2;
historical custody remains exit2/seven NOTPASS.

The AI-capability result is a corrected support decision, a nonzero
action-derived loop and a mass-coordinate consistency consequence rather
than a favorable fitted counterterm. Shared action, group/covariance maps,
regulator assumptions, software and AI authorship limit independence.
This is internal computational corroboration with a literature anchor,
not independent scientific validation or empirical support for Spin(10).

No complete328-field VEV/source construction, finite tadpole/mass scheme,
fermionic measure/phase/QAP/full forest, finite matterC1, E5/A5 or physical
unification is qualified. Prior benchmark exclusions, the separate finite-
point140% singlet warning, flavor pause, HB1/C5 blocks, quartet failure
and all historical evidence are preserved. No state or physical input changed.

## Next smallest useful question

Determine whether the necessary extra projected VEV factor is supported
by the actual scalar-source/GF insertion structure. Use the existing
source action and a precisely defined vacuum-direction derivative of the
GF primitive, if available; construct its ghost/scalar contact kernel
before assuming a background-source theorem applies. A new external-source
extension, if investigated provisionally, must be stated explicitly and
must not be confused with an already defined renormalized prescription.
