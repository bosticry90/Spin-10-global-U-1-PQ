# FMU1: complete leading proper fermion mass UV pole

Base7a09d0071cfac93334d10037b9949369c12a5db0/main,30473 tracked blobs.
Question: what is the actual one-loop proper fermion mass pole, and what
mass-visible VEV image would be required alongside the measured Yukawa and
field poles? This is a parent-renormalization input before finite massive
matching, not adoption of a VEV/tadpole or physical subtraction prescription.

Freeze live AGENTS/charter/state113/34of39,V492/local/solo conventions;
SMA action/current, SMP actual finite-hat inverse, YCT complete maps/mass/
covariance, GFK two-width inverse/field pole, ASM actual GF bilinear, GYV
kinetic scalar polarization, FYS/FKP/YPP/YCA measured poles and receipts.
Original physical benchmarks/exclusions, paused flavor, HB1/C5 blocks,
quartet failure, custodyexit2/seven and historical policy remain unchanged.

Important correction to the prospective next-step description in V492:
include BOTH physical kinetic Bx mixing at the vacuum and GF Lambda*x
mixing. ASM established the latter, not the absence of the former.
The physical kinetic density expands to g(partial eta)^T O B. Its ordered
Hessian and the actual +g*xi*Lambda^T O^T eta must be Wick transported
before sewing the mixed fermion loop. No cancellation is presumed as input.

Domain: declared local one-loop Euclidean UV symbol, d=4-2epsilon,
nonexceptional momenta or positive auxiliary IR mass for residue isolation.
All scalar/gauge fields and all three family directions remain as inherited,
with TWO independent general symmetric complex matrices Y10,Y126.
M=Y126 tensor M126 at the fixed VEV; M126 comes
from the complete map, not a chosen mass spectrum. Barred spin rank4,
actual pp Born mass numerator bar k²(PL Mdagger+PR M)/k4 from SMP case0.
Retain its d-dependent angular factors; no finite-hat equivalence inferred.

Completeness: in a proper one-loop two-fermion graph without a fermion
quartic there are two matter cubics on the open line. Both are FFB, both
FFx, or one of each. A dimension-one local mass pole can contain one mass
or orbit insertion. Gauge/gauge uses the fermion mass insertion; scalar/
scalar is the qualified YPP pure-Yukawa mass zero; mixed endpoints use the
kinetic Bx and GF Lambda*x bilinears. Other positive-dimension insertions
lower the UV degree. A scalar tadpole attached to a single FFx vertex is
one-particle reducible and is excluded from the proper self-energy, not
from physical tadpole/mass matching. No finite amplitude is declared zero.

Primary: derive a single explicit Wick congruence from the Minkowski
reference and actual two bilinears. Use direct4-spin angular averaging
and the fixed open-line Gaussian sign to calculate exchange plus four
oriented mixing contributions. Contract actual45 T matrices, ASM images
and the two-width H projector; keep their individual answers.
Replay: independently invert/differentiate the longitudinal B/Lambda/x
three-block symbol, check split8-spin polynomial identities and derive
Gamma radial residues. Recover group contractions through the independent
scalar Casimir/covariance image at the actual VEV, not a fitted loop target.
No peer outputs, arbitrary numerical flavor values or new physical scheme.

Gate: all256 entries of each individual mass tensor in both carriers,
their conjugate normalization, Wick/mixed-kernel phases, radial/angular
factors, H-width support and actual finite-hat mass numerator. Compare the
assembled full48x48 family/internal pole by tensor factorization. Only
after these independently determined poles exist combine GFK/FYS/YCA/FKP
external-field inputs to derive the necessary mass-visible VEV image and
its difference from ordinary scalar half-field renormalization. Do not
interpret this as a complete328-field VEV/source construction or adopt it.

Controls: reverse the auxiliary Wick phase, omit either mixing source or
one oriented branch, exchange xi with etaH, use an extra open-line half/
family3, swap mass chirality, replace case0 by a naive finite-hat massive
propagator, or identify VEV renormalization with the ordinary scalar field
alone. Some of these can be insensitive to the final summed UV pole:
state that explicitly and use individual kernels/old SMP domain where
necessary. No test is weakened to make the answer favorable.

Comparator: Sperling/Stockinger/Voigt arXiv1305.1548v3 Eq17c,20a,23 gives
the standard distinction between scalar and background-VEV poles in Rxi
gauge. Translate only the mass-visible result after deriving it; their
background-source extension is not automatically the current action.
The retained extra gauge-fixing coefficient corresponds to their xi'=1
only for this bounded comparison. No source doublet is silently added.
See DERIVATION for source and explicit comparison boundaries.

Freeze eight sources/copies before sequential primary/replay/gate.600s
each after imports,8GiB sampled private cap,350MiB launch floor,16MiB
package cap; no agents. Preserve failures/unfinished work before versioned
correction; no silent retry, resource increase, input change or truncation.
Possible outcomes: qualified bounded mass pole/necessary image; exact
normalization mismatch; underdefinition; resource incomplete. Shared action,
maps, regulator assumptions, software and AI author limit independence.

Authority ceiling34/39; scientific/director acceptance NOT_PERFORMED. No
finite mass/VEV/tadpole prescription, full fermionic source/evanescent/
measure/phase/QAP/forest, finite matterC1, E5/A5 or unification qualification.
No state/foundation/branch/worktree/agents/publication/push. Record runtime,
resources, limitations and smallest justified next question in RESULT.md.
