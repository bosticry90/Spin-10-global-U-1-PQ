"""FMU1 longitudinal inversion, split spin identities and Casimir mass image."""
from data import *
start=begin('replay')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
# Independently transform each density rather than the primary 6x6 block.
# -Lambda*d.B -> -Lambda_E*d_E.B_E (Fourier block +/-r);
# scalar kinetic cross -> +/-i*g*r*o, GF term -> +i*g*xi*o.
r,w,zeta,o,gg,a,b=s.symbols('r w zeta o g kinetic_tag auxiliary_tag',nonzero=True)
pm=s.Matrix(s.symbols('pm0:4'));qe=s.Matrix(s.symbols('qe0:4'));bm=s.Matrix(s.symbols('bm0:4'));be=s.Matrix(s.symbols('be0:4'));lm,le,x=s.symbols('lambdaM lambdaE x')
sub={pm[0]:s.I*qe[0],bm[0]:s.I*be[0],lm:-s.I*le,**{pm[i]:qe[i] for i in range(1,4)},**{bm[i]:be[i] for i in range(1,4)}}
kin=s.expand((-gg*o*x*sum(s.I*pm[i]*bm[i]*[1,-1,-1,-1][i] for i in range(4))).subs(sub))
aux=s.expand((-gg*zeta*o*lm*x).subs(sub));pk=s.simplify(s.diff(kin,be[0],x)/(gg*o*qe[0]));pf=s.simplify(s.diff(aux,le,x)/(gg*zeta*o))
K=s.Matrix([[0,r,a*pk*gg*r*o],[-r,w,b*pf*gg*zeta*o],[-a*pk*gg*r*o,b*pf*gg*zeta*o,r*r]])
inverse=K.inv();dk=tidy(inverse.diff(a).subs({a:0,b:0}));df=tidy(inverse.diff(b).subs({a:0,b:0}))
zero(K*inverse-s.eye(3));zero(inverse*K-s.eye(3))
ph=[s.simplify(-dk[0,2]*r**3/(gg*w*o)),s.simplify(-dk[2,0]*r**3/(gg*w*o)),s.simplify(-df[0,2]*r**3/(gg*zeta*o)),s.simplify(-df[2,0]*r**3/(gg*zeta*o))]
# Gaussian averaging and inverse extraction determine the open-line minus.
D=s.Matrix([[2,1],[0,3]]);V=s.Matrix([[1,2],[-1,0]]);S=D.inv();t,c=s.symbols('t c');zero(((S+t*c*S*V*S*V*S)*(D-t*c*V*S*V)-s.eye(2)).diff(t).subs(t,0))
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[s.kronecker_product(pa[1],x) for x in pa]+[s.kronecker_product(pa[0],s.eye(2))];gam=[s.kronecker_product(x,pa[2]) for x in g4]
PL=s.kronecker_product(s.diag(1,1,0,0),s.eye(2));PR=s.eye(8)-PL;A=PL-PR;ks=s.symbols('k0:4');slash=sum((k*x for k,x in zip(ks,gam)),s.zeros(8));b2=sum(k*k for k in ks)
zero(b2*sum((x*A*PR*x*A for x in gam),s.zeros(8))+4*b2*PL);zero(b2*slash*A*PR*slash*A+b2*b2*PL)
zero(slash*A*slash*PL+b2*PL);zero(PL*slash*slash*A-b2*PL)
zero(b2*sum((x*A*PL*x*A for x in gam),s.zeros(8))+4*b2*PR);zero(b2*slash*A*PL*slash*A+b2*b2*PR)
mh,ma=s.symbols('mass_holo mass_anti');zero(slash*(PL*mh+PR*ma)*slash-b2*(PL*ma+PR*mh))
dim=s.Symbol('d');ang=[-16/dim,-24/(dim*(dim+2))]
for v,sign in zip(ph,[-1,1,-1,1]):ang.append(s.simplify(-(-s.I)**2*v*sign*4/dim))
units=[s.simplify(x.subs(dim,4)) for x in ang]
eps,m2=s.symbols('epsilon m2',positive=True);res=[]
for power in range(3):
 analytic=s.gamma(1+eps)*m2**(-eps)*s.prod(j-eps for j in range(2,power+2))/s.factorial(power+1);res.append(str(s.simplify(analytic.subs(eps,0))))
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/replay_v2_tables.json.gz');CI,CH=map(dec,gy['fermion_Casimir_I_H']);CSI,CSH=map(dec,gy['scalar_Casimir_I_H']);v=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['vacuum']['VEV']);CW=WM*CI+(WH-WM)*CH;models=[]
for rr,key in enumerate(['B10','B126']):
 B=dec(d[key]);M=s.Matrix(16,16,list(B*v));si=s.Matrix(16,16,list(B*CSI*v));sh=s.Matrix(16,16,list(B*CSH*v))
 JI=tidy((si-CI.T*M-M*CI)/2);JH=tidy((sh-CH.T*M-M*CH)/2);JW=WM*JI+(WH-WM)*JH
 # Use independently calculated phases, then the qualified actual orbit
 # covariance to transport the raw m(O)=i(T^T M+M T) endpoint tensors.
 terms={'exchange':tidy(units[0]*JI+units[1]*(JW-JI)),
 'kinetic_left':tidy(units[2]*s.I*(CW.T*M+JW)),'kinetic_right':tidy(units[3]*s.I*(M*CW+JW)),
 'auxiliary_left':tidy(units[4]*s.I*WM*(CI.T*M+JI)),'auxiliary_right':tidy(units[5]*s.I*WM*(M*CI+JI))}
 models.append({'carrier':['10','126'][rr],'M':enc(M),'J_I':enc(JI),'J_H':enc(JH),**{n:enc(x) for n,x in terms.items()},'proper_mass_gauge_pole':enc(sum(terms.values(),s.zeros(16)))})
finish('replay',{'method':'longitudinal_threeblock_inverse_split8spin_and_independent_Casimir_VEV_image','wick_K_kin_Bx_phase':str(pk),'wick_K_aux_Lx_phase':str(pf),'boson_phases_at_minus_k':list(map(str,ph)),'angular_units':list(map(str,ang)),'UV_units':list(map(str,units)),'conjugate_UV_units':[str(s.conjugate(x)) for x in units],'positive_IR_mass_radial_residues':res,'models':models,'C_I':enc(CI),'C_H':enc(CH),'new_one_loop_mass_pole_families':1,'new_two_loop_integrals':0,'open_line_closed_loop_half':False,'omitted_physical_kinetic_mixing':False},start)
