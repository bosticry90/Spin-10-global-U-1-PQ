"""FMU1 complete diagram comparison then necessary mass-visible VEV image."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.expand)
def zero(M):assert not tidy(M).todok()
def differs(M):assert tidy(M).todok()
for key in ['UV_units','conjugate_UV_units','boson_phases_at_minus_k','wick_K_kin_Bx_phase','wick_K_aux_Lx_phase']:assert P[key]==R[key],key
assert P['UV_units']==['-4','-1','-I','-I','I','I'] and R['positive_IR_mass_radial_residues']==['1','1','1']
dim=s.Symbol('d')
for p,r in zip(P['angular_units'],R['angular_units']):assert s.simplify(s.sympify(p)-s.sympify(r))==0
terms=['exchange','kinetic_left','kinetic_right','auxiliary_left','auxiliary_right'];co=[]
for p,r in zip(P['models'],R['models']):
 for key in ['M','J_I','J_H',*terms,'proper_mass_gauge_pole']:zero(dec(p[key])-dec(r[key]))
 M=dec(p['M']);zero(M-M.T);loop=dec(p['proper_mass_gauge_pole']);zero(loop-loop.T)
 zero(sum((dec(p[key]) for key in terms[1:]),s.zeros(16)))
 for label in ['left','right']:zero(dec(p['kinetic_'+label])+dec(p['auxiliary_'+label]))
 if M.todok():
  alpha=s.simplify(sum(s.conjugate(z)*loop[i,j] for (i,j),z in M.todok().items())/sum(s.conjugate(z)*z for z in M.todok().values()));zero(loop-alpha*M);co.append(str(alpha))
  assert s.expand(alpha+s.Rational(5,8)*(3+WM))==0
  for key in terms[1:]:differs(dec(p[key]))
  differs(loop+sum((dec(p[key]) for key in terms[3:]),s.zeros(16))-loop)
  differs((WM-WH)*M);differs(loop-loop/2);differs(loop-3*loop)
 else:zero(loop)
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');asm=packed(CAL/'canonical_so10_auxiliary_scalar_mass_interface/primary_tables.json.gz');H=dec(yc['H_new']);O=dec(asm['plane_K']).T;zero(O*H)
CI,CH=dec(P['C_I']),dec(P['C_H']);CW=WM*CI+(WH-WM)*CH;M=dec(P['models'][1]['M']);zero(CH.T*M);zero(M*CH);zero(CI-s.Rational(45,8)*s.eye(16))
# Verify inherited physical scalar Wick sign from its actual frozen symbol.
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];ix=ref['field_order'].index('x_Phi_0');raw=dec(ref['reference_Hessian_raw_C3']);p0=s.Symbol('p0_ref0');assert s.diff(raw[ix,ix],p0,2)==2
# Subsequent mass-coordinate pullback, using only independently measured
# proper pole, wavefunctions and dimensionless parameter pole.
yca=packed(CAL/'canonical_so10_yukawa_counterterm_assembly/primary_tables.json.gz');Y=dec(yca['models'][1]['Y']);DY=dec(yca['models'][1]['full_pole']);WY=dec(yca['W']);k=s.sympify(yca['models'][1]['trace'],locals=LOC)
cf=G**2*(CW.T*M+M*CW)/2
fieldY=-(WY.T*Y+Y*WY)/4
loopunit=s.sympify(co[0],locals=LOC)
req=-G**2*loopunit*Y+G**2*s.Rational(45,8)*WM*Y-fieldY
visible=tidy(req-DY)
sf=(G**2*(3-WM)*s.Rational(25,2)/2-k/4)*Y
extra=tidy(visible-sf)
zero(visible-(G**2*s.Rational(25,4)*(3+WM)-k/4)*Y);zero(extra-G**2*s.Rational(25,2)*WM*Y)
# These are necessary mass-visible images. No lift in the kernel of B126,
# finite tadpole condition or background-source operation is constructed.
differs(extra);zero(extra.subs(WM,0));zero(visible-visible.T)
# Tensor identity retains the full48x48 mass and family-offdiagonal image.
full_loop=s.kronecker_product(loopunit*Y,M);zero(full_loop-s.kronecker_product(Y,dec(P['models'][1]['proper_mass_gauge_pole'])))
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_PROPER_FERMION_MASS_UV_POLE_AND_NECESSARY_PROJECTED_VEV_IMAGE','elapsed_after_imports':time.perf_counter()-start,'individual_mass_tensor_positions_compared':2*5*256,'auxiliary_and_kinetic_mixing_pair_cancellation':True,'pure_Yukawa_mass_UV_zero':'AUTHENTICATED_YPP_REUSE','actual_mass_direction_gauge_loop_coefficient':co[0],'loop_normalization':'g10^2/(16*pi^2*epsilon)','mass_visible_VEV_image_stripped':'[(25/4)*(3+xi)*g10^2-Tr(Y126^dagger*Y126)/4]*M','additional_over_scalar_half_field_stripped':'(25/2)*xi*g10^2*M','full_family_internal_mass_positions_checked':48**2,'symbolic_mass_visible_VEV_polynomial_positions':9,'widths_retained':['eta_H','xi'],'unbroken_width_drops_from_actual_mass_direction':True,'new_one_loop_mass_pole_families':1,'new_two_loop_integrals':0,'finite_hatted_mass_substitution_rejected_by_inherited_SMP':True,'UV_residue_alone_sensitive_to_hat_finite_difference':False,'full328_VEV_or_background_source_map_qualified':False,'finite_mass_tadpole_QAP_forest_or_matching_qualified':False,'physical_flavor_or_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
