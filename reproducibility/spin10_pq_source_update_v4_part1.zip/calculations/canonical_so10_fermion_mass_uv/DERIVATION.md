# FMU1 prospective ordered mass calculation

This fixes conventions and a prospective derivation, not an accepted result
before independent execution and verification. Strip16pi²epsilon when noted.

The original scalar reference has p²-Mref²; the gauge/auxiliary reference
has K_BB=-p² eta+pup*pup^T, K_BL=+i pup,K_LB=-i pup^T,K_LL=w.
The scalar kinetic cross term at a constant vacuum is
g(partial eta)^T O B, hence K_Bx=+ig pup O^T,K_xB=-ig O pup^T.
ASM supplies K_Lx=+g*xi O^T,K_xL=+g*xi O.

Use p_M0=iq_E0, B_M0=iB_E0, B_Mj=B_Ej, Lambda_M=-iLambda_E,
x_M=x_E, and the common Wick action sign -1. These choices simultaneously
recover the already fixed positive scalar and gauge reference and its two
ordered BL signs. Apply this same congruence to the mixing terms. It fixes
their relative phase; choosing that phase to cancel a later loop is forbidden.

The massless reference inverse has
G_BB=I/Q+(W-I)qq^T/Q², G_BL=-q/Q,G_LB=q^T/Q,G_LL=0,
G_xx=I/Q. For a linear bosonic insertion V, deltaG=-G V G.
Keep kinetic and auxiliary pieces and both Bx/xB orientations distinct.
All mixed boson momenta in the self-energy convolution S(k)G(p-k)
are q=-k at p=0. The full-dimensional longitudinal contraction is used
before barred fermion currents project momenta to rank4.

The open-line inverse correction is Sigma=-sum R_i S R_j G_ij,
R_B=-ig bar_gamma(PL T-PR T^T), R_x=PL m+PR mdagger.
There is no closed-loop Pfaffian half. The exchange uses SMP's actual
linear mass block bar k²(PL Mdagger+PR M)/Q². Angular factors depend on
4/d and24/[d(d+2)], not a premature four-dimensional massive propagator.
Positive auxiliary IR mass isolates the logarithmic residue without
changing the physical vacuum. Equal radial simple-pole units do not
establish equality of finite parts.

Group notation: J_Q(M)=sum Qab T_a^T M T_b,C_Q=sum Qab T_a T_b.
Direct actual matrices are compared with the independent identity
B C_s,Q v=C_Q^T M+M C_Q+2J_Q(M). Widths stay etaH and xi until after
the inherited PH*O^T=0 property is verified. Preserve all individual
mixing kernels even if their sum happens to vanish.

Only after computing the proper pole L_M derive the required action
parameter image deltaM_req=-L_M-(Z_F^T M+M Z_F)/2, with measured Z_F.
For a fixed-coordinate relation M=Y126 tensor M126, the necessary
mass-visible VEV image is deltaM_req-deltaY126 tensor M126. Subtract
the separately measured ordinary scalar half-field image to assess what
is still required. This does not determine components in the Yukawa map's
kernel, impose stationarity or define finite tadpole normalization.

Reference review,2026-10-22: Sperling,Stockinger,Voigt,
https://arxiv.org/pdf/1305.1548v3 , Eq17c,20a,23, distinguishes ordinary
scalar field renormalization from an additional background-field factor.
Their one-loop additional factor is 2g² xi xi' C_s/(16pi²epsilon).
The current actual GF mixing allows xi'=1 for this structural comparison.
This is a primary-literature normalization anchor, not an imported answer
for any individual diagram or an adoption of their background-source domain.
Their source two-point function and ST construction have not been replayed
for the present nonlinear GF/sterile-hat matter extension. That remains
separate work even if the necessary projected image agrees.
