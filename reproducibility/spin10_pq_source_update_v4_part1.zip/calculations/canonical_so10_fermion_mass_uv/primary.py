"""FMU1 common Wick congruence, direct spin residue and actual mass tensors."""
from data import *
from itertools import product
start=begin('primary')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
# Actual Minkowski bilinears, with one scalar orbit component o as a
# polarization coordinate. This fixes phases, not model coefficients.
p=s.Matrix(s.symbols('p0:4'));eta=s.diag(1,-1,-1,-1);up=eta*p;P=(p.T*up)[0];w,o,gg,zeta=s.symbols('w orbit g zeta')
K=s.SparseMatrix(6,6,{});K[:4,:4]=-P*eta+up*up.T;K[:4,4]=s.I*up;K[4,:4]=-s.I*up.T;K[4,4]=w;K[5,5]=P
Vk=s.SparseMatrix(6,6,{});Vk[:4,5]=s.I*gg*o*up;Vk[5,:4]=-s.I*gg*o*up.T
Vf=s.SparseMatrix(6,6,{(4,5):gg*zeta*o,(5,4):gg*zeta*o})
q=s.Matrix(s.symbols('q0:4'));Q=(q.T*q)[0];rot=s.diag(s.I,1,1,1,-s.I,1);sub={p[0]:s.I*q[0],**{p[i]:q[i] for i in range(1,4)}}
wick=lambda A:tidy(-rot.T*A.subs(sub)*rot)
KE,EK,EF=map(wick,[K,Vk,Vf]);GE=s.SparseMatrix(6,6,{});GE[:4,:4]=s.eye(4)/Q+(w-1)*q*q.T/Q**2;GE[:4,4]=-q/Q;GE[4,:4]=q.T/Q;GE[5,5]=1/Q
zero(KE*GE-s.eye(6));zero(GE*KE-s.eye(6));DK=tidy(-GE*EK*GE);DF=tidy(-GE*EF*GE)
# q=-k in S(k)G(p-k). Extract these phases from the actual computed
# mixed propagator, before any fermion spin/color contraction.
phaseKL=s.simplify(-DK[0,5]/(gg*w*o*q[0]/Q**2));phaseKR=s.simplify(-DK[5,0]/(gg*w*o*q[0]/Q**2))
phaseFL=s.simplify(-DF[0,5]/(gg*zeta*o*q[0]/Q**2));phaseFR=s.simplify(-DF[5,0]/(gg*zeta*o*q[0]/Q**2))
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.kronecker_product(pa[1],a) for a in pa]+[s.kronecker_product(pa[0],s.eye(2))];PL=s.diag(1,1,0,0);PR=s.eye(4)-PL;A=PL-PR
ks=s.symbols('k0:4');slash=sum((k*a for k,a in zip(ks,gam)),s.zeros(4));b2=sum(k*k for k in ks);dim=s.Symbol('d')
def avg(v):
 out=0
 for powers,c in s.Poly(s.expand(v),*ks).terms():
  if any(i%2 for i in powers):continue
  n=sum(powers)//2;out+=c*s.prod(s.factorial2(i-1) for i in powers)/s.prod(dim+2*j for j in range(n))
 return s.factor(out)
def scalar(M,proj):
 v=s.factor(s.trace(proj*M)/s.trace(proj));zero(M-v*proj);return v
def units(proj,mt):
 # -R S1 R; S1=b2*(PL Mdagger+PR M)/Q², phase -(-i)^2.
 exF=(b2*sum((a*A*mt*a*A for a in gam),s.zeros(4))).applyfunc(avg)
 exL=(b2*slash*A*mt*slash*A).applyfunc(avg)
 left=(slash*A*slash*proj).applyfunc(avg);right=(proj*slash*slash*A).applyfunc(avg)
 phases=[-(-s.I)**2,-(-s.I)**2,-(-s.I)**2*phaseKL,-(-s.I)**2*phaseKR,-(-s.I)**2*phaseFL,-(-s.I)**2*phaseFR]
 spin=[exF,exL,left,right,left,right]
 return [s.factor(phase*scalar(mat,proj)) for phase,mat in zip(phases,spin)]
angular=units(PL,PR);anti=units(PR,PL);u=[s.simplify(v.subs(dim,4)) for v in angular]
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,d['Tminus']));H=dec(d['H_new']);PH=tidy(H*H.T);W=WM*s.eye(45)+(WH-WM)*PH
asm=packed(CAL/'canonical_so10_auxiliary_scalar_mass_interface/primary_tables.json.gz');CI=tidy(sum((a*a for a in T),s.zeros(16)));CH=tidy(sum((c*T[a]*T[b] for (a,b),c in PH.todok().items()),s.zeros(16)));models=[]
for r,key in enumerate(['mass10','mass126']):
 M=dec(d[key]);N=dec(asm['Yukawa_images'][r]);NW=tidy(N*W);I=s.eye(16)
 JI=tidy(sum((a.T*M*a for a in T),s.zeros(16)));JH=tidy(sum((c*T[a].T*M*T[b] for (a,b),c in PH.todok().items()),s.zeros(16)));JW=WM*JI+(WH-WM)*JH
 left=lambda X:tidy(sum((T[a].T*s.Matrix(16,16,list(X[:,a])) for a in range(45)),s.zeros(16)))
 right=lambda X:tidy(sum((s.Matrix(16,16,list(X[:,a]))*T[a] for a in range(45)),s.zeros(16)))
 terms={'exchange':tidy(u[0]*JI+u[1]*(JW-JI)),'kinetic_left':tidy(u[2]*left(NW)),'kinetic_right':tidy(u[3]*right(NW)),'auxiliary_left':tidy(u[4]*WM*left(N)),'auxiliary_right':tidy(u[5]*WM*right(N))}
 models.append({'carrier':['10','126'][r],'M':enc(M),'J_I':enc(JI),'J_H':enc(JH),**{n:enc(v) for n,v in terms.items()},'proper_mass_gauge_pole':enc(sum(terms.values(),s.zeros(16)))})
finish('primary',{'method':'common_Wick_congruence_direct4spin_angular_and_actual45_matrix_contractions','wick_K_kin_Bx_phase':str(s.simplify(EK[0,5]/(gg*o*q[0]))),'wick_K_aux_Lx_phase':str(s.simplify(EF[4,5]/(gg*zeta*o))),'boson_phases_at_minus_k':list(map(str,[phaseKL,phaseKR,phaseFL,phaseFR])),'angular_units':list(map(str,angular)),'UV_units':list(map(str,u)),'conjugate_UV_units':[str(s.simplify(v.subs(dim,4))) for v in anti],'models':models,'C_I':enc(CI),'C_H':enc(CH),'new_one_loop_mass_pole_families':1,'new_two_loop_integrals':0,'open_line_closed_loop_half':False,'omitted_physical_kinetic_mixing':False},start)
