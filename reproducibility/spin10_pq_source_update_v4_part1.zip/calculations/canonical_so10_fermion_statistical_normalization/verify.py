"""FSN1 independent output comparison and factor/sign-sensitive controls."""
from data import *
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
assert P['gaussian']==R['gaussian'] and len(P['gaussian'])==6
sensitive=0
for key,g in P['gaussian'].items():
 assert g['ratio'][0]=='1'
 for coefficient in g['log']:
  c=s.sympify(coefficient)
  if c:assert c!=2*c and c!=-c;sensitive+=int(c!=0)
assert sensitive>=12
positions=0
for name,n in [('beta_per_family',45),('beta_SM_per_family',12),('beta_three_families',45),('beta_SM_three_families',12)]:
 a,b=dec(P[name]),dec(R[name]);assert a==b;positions+=n*n
 expected=(s.Rational(4,3) if 'three' not in name else 4)*s.eye(n)
 assert a==expected
 if 'three' in name:assert a!=2*a and a!=4*a and a!=-a
assert dec(R['color_Gram'])==2*s.eye(45) and dec(R['SM_Gram'])==2*s.eye(12)
assert dec(P['heat_F12'])==s.Rational(8,3)*s.eye(45) and dec(P['heat_SM_F12'])==s.Rational(8,3)*s.eye(12)
assert P['spin_trace']==4 and P['gaussian_log_factor']=='1/2' and P['squared_operator_log_factor']=='1/4'
assert R['bubble_integral']=='2/3' and R['two_component_trace_checks']==256 and R['SM_species_indices']==['2','2','2'] and R['neutral_SM_index']=='0'
# A single chiral block supplies half the heat trace. Omitting Omega^2
# gives heat coefficient2*T rather than4*T/3. These are sensitive poles.
Tindex=2;correct=s.Rational(2,3)*Tindex
wrong={'no_Nambu_half':2*correct,'auxiliary_spin16':4*correct,'omitted_conjugate_block':correct/2,'omitted_Omega_squared':Tindex,'wrong_effective_action_sign':-correct,'families_six':2*correct}
assert all(v!=correct for v in wrong.values())
for D in [P,R]:assert D['provisional_only'] and not D['phase_or_finite_threshold_computed']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_PARITY_EVEN_WEYL_GAUSSIAN_AND_MASSLESS_GAUGE_POLE_NORMALIZATION','elapsed_after_imports':time.perf_counter()-start,
 'finite_Gaussian_probes':6,'log_series_orders_each':4,'nonzero_log_controls':sensitive,'color_positions_compared_per_multiplicity':2169,'total_beta_positions_compared':positions,
 'two_component_trace_identities':256,'gaussian_log_factor':'1/2','modulus_squared_operator_factor':'1/4','beta_one_Weyl_per_index':'2/3',
 'Spin10_index_per_family':'2','beta_three_16_families':'4','beta_SM_three_families':['4','4','4'],'SM_neutral_index':'0',
 'controls':{k:str(v) for k,v in wrong.items()},'massless_pole_only':True,'finite_or_evanescent_part_qualified':False,'Pfaffian_phase_or_global_sign_qualified':False,
 'new_physical_flavor_or_mass_selected':False,'provisional_carrier_adopted':False,'new_two_loop_integrals':0,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
