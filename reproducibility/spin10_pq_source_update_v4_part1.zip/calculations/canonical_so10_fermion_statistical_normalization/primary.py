"""FSN1 exterior Gaussian and exact four-component local heat coefficient."""
from data import *
import math
start=begin('primary');z=s.Symbol('z')
def top_integral(K):
 n=K.rows//2;Q={(1<<i)|(1<<j):K[i,j] for i in range(2*n) for j in range(i+1,2*n) if K[i,j]}
 def wedge(a,b):
  out={}
  for x,c in a.items():
   for y,d in b.items():
    if x&y:continue
    parity=sum((y&((1<<i)-1)).bit_count() for i in range(2*n) if (x>>i)&1)%2
    key=x|y;out[key]=out.get(key,0)+(-1 if parity else 1)*c*d
  return {m:s.expand(c) for m,c in out.items() if c!=0}
 power={0:s.S.One}
 for k in range(n):power=wedge(power,Q)
 return s.expand(power.get((1<<(2*n))-1,0)/math.factorial(n))
gauss={}
for n in [2,3,4]:
 for paired in [False,True]:
  K0,K1,V=probes(n,paired);Z=top_integral(K0+z*K1);ratio=s.expand(Z/Z.subs(z,0));series=s.series(s.log(ratio),z,0,5).removeO().expand()
  if paired:assert s.expand(ratio-(s.eye(n)+z*V).det())==0
  gauss[f'{n}_{int(paired)}']={'ratio':[str(ratio.coeff(z,k)) for k in range(n+1)],'log':[str(series.coeff(z,k)) for k in range(1,5)]}

P1=s.Matrix([[0,1],[1,0]]);P2=s.Matrix([[0,-s.I],[s.I,0]]);P3=s.diag(1,-1)
g=[s.kronecker_product(P1,s.eye(2)),s.kronecker_product(P2,s.eye(2)),s.kronecker_product(P3,P1),s.kronecker_product(P3,P2)]
chi=g[0]*g[1]*g[2]*g[3];PL=(s.eye(4)+chi)/2;PR=(s.eye(4)-chi)/2
for a in range(4):
 for b in range(4):assert g[a]*g[b]+g[b]*g[a]==2*(a==b)*s.eye(4)
assert chi**2==s.eye(4) and s.trace(s.eye(4))==4
d=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,d['Tminus']));SM=list(map(dec,d['SM_generators']))
def kernel(ts):
 A=[s.SparseMatrix(s.kronecker_product(PL,t)-s.kronecker_product(PR,t.T)) for t in ts]
 E=[s.SparseMatrix(-s.I*s.kronecker_product(g[0]*g[1],s.eye(16))*a) for a in A]
 def trprod(X,Y):return s.simplify(sum(v*Y[j,i] for (i,j),v in X.todok().items()))
 # F12=f: both Omega12 and Omega21 enter Omega_mn Omega_mn.
 heat=s.Matrix(len(ts),len(ts),lambda a,b:trprod(E[a],E[b])/2-trprod(A[a],A[b])/6)
 b=heat/2 # Re Gamma factor1/4, kinetic F^2 factor1/4, F^2=2 f^2.
 return heat,b
hg,bg=kernel(T);hs,bs=kernel(SM)
finish('primary',{'gaussian':gauss,'heat_F12':enc(hg),'beta_per_family':enc(bg),'heat_SM_F12':enc(hs),'beta_SM_per_family':enc(bs),
 'beta_three_families':enc(3*bg),'beta_SM_three_families':enc(3*bs),'spin_trace':4,'gaussian_log_factor':'1/2','squared_operator_log_factor':'1/4',
 'phase_or_finite_threshold_computed':False,'provisional_only':True},start)
