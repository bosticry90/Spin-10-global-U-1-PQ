"""FSN1 matching recursion, trace series and two-component bubble pole."""
from data import *
start=begin('replay');z=s.Symbol('z');gauss={}
def pf(K):
 if K.rows==0:return s.S.One
 return s.expand(sum((-1)**(j+1)*K[0,j]*pf(K.extract([k for k in range(K.rows) if k not in (0,j)],[k for k in range(K.rows) if k not in (0,j)])) for j in range(1,K.rows)))
for n in [2,3,4]:
 for paired in [False,True]:
  K0,K1,V=probes(n,paired);vals=[(j,pf(K0+j*K1)) for j in range(n+1)];Z=s.interpolate(vals,z).expand();ratio=s.expand(Z/Z.subs(z,0));X=K0.inv()*K1
  logs=[s.simplify((-1)**(m+1)*s.trace(X**m)/(2*m)) for m in range(1,5)]
  for j in [-1,0,2]:assert pf(K0+j*K1)**2==(K0+j*K1).det()
  if paired:
   for m in range(1,5):assert logs[m-1]==s.simplify((-1)**(m+1)*s.trace(V**m)/m)
  gauss[f'{n}_{int(paired)}']={'ratio':[str(ratio.coeff(z,k)) for k in range(n+1)],'log':list(map(str,logs))}

sig=[s.eye(2),s.Matrix([[0,s.I],[s.I,0]]),s.Matrix([[0,1],[-1,0]]),s.diag(s.I,-s.I)];bar=[sig[0]]+[-v for v in sig[1:]]
trace_checks=0
for mu in range(4):
 for al in range(4):
  for nu in range(4):
   for be in range(4):
    lhs=s.trace(sig[mu]*bar[al]*sig[nu]*bar[be]+sig[mu]*bar[be]*sig[nu]*bar[al])/2
    rhs=2*(int(mu==al)*int(nu==be)+int(mu==be)*int(al==nu)-int(mu==nu)*int(al==be))
    assert s.simplify(lhs-rhs)==0;trace_checks+=1
x,q2,qq,delta=s.symbols('x q2 qq delta');u=x*(1-x);dim=s.Symbol('d');Delta=u*q2
# The leading pole of I1 is -Delta and of I2 is1. The d-4 angular
# part contributes only finite terms, which are deliberately outside this test.
I2pole=1;J2pole=-2*Delta
res=s.expand(((4/dim-2)*delta*J2pole-4*u*qq*I2pole+2*delta*u*q2*I2pole).subs(dim,4))
assert s.simplify(res-4*u*(delta*q2-qq))==0
spin_factor=s.integrate(res.coeff(qq)*(-1),(x,0,1));assert s.simplify(res.subs({delta:1,qq:q2}))==0
old=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz');ts=list(map(dec,old['spinor_plane_generators']));H=dec(old['SM_plane_coefficients'])
sm=[sum((H[a,j]*ts[a] for a in range(45)),s.zeros(16)) for j in range(12)]
def gram(v):return s.Matrix(len(v),len(v),lambda a,b:s.simplify(s.trace(v[a]*v[b])))
gg,gs=gram(ts),gram(sm);bg=spin_factor*gg;bs=spin_factor*gs
states=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['SM_states'];indexY=s.simplify(s.Rational(3,5)*sum(s.sympify(v['Y'])**2 for v in states))
indices=[indexY,s.Rational(1,2)*(3+1),s.Rational(1,2)*(2+1+1)]
finish('replay',{'gaussian':gauss,'color_Gram':enc(gg),'SM_Gram':enc(gs),'beta_per_family':enc(bg),'beta_SM_per_family':enc(bs),
 'beta_three_families':enc(3*bg),'beta_SM_three_families':enc(3*bs),'two_component_trace_checks':trace_checks,'bubble_integrand':'4*x*(1-x)',
 'bubble_integral':str(spin_factor),'SM_species_indices':list(map(str,indices)),'neutral_SM_index':'0','phase_or_finite_threshold_computed':False,'provisional_only':True},start)
