# FSN1: fermionic Gaussian normalization and massless gauge-pole recovery

Base 3bd608c17e09f3df47cfd29b0e3e31fa0ed0734a/main,30071trackedblobs.
YCT1 is sealed; all scientific workers terminal. Previous increment PROGRESS.
Question: does the Nambu/alternating-form description count one Weyl family,
or accidentally double it? Settle this prerequisite before a matter threshold.
This is a recovery of established QFT normalization, not a new interaction.

Freeze state113/34of39, live AGENTS/CHARTER and local/solo policy, V478,
the original symbolic Yukawa convention, YCT1 maps/receipt, FGI1 even-carrier
maps/receipt and MEC1/CDW1 records/receipts. YCT1 stays provisional. Scalar
parent/points and all historical failures unchanged. No numerical flavor,
mass, finite subtraction, chiral continuation or physical scheme is adopted.

Domain: finite complex Grassmann Gaussian with explicitly oriented variables,
nondegenerate alternating K0 and polynomial K(z)=K0+zK1; local formal series
near z=0. K test matrices are algebra probes, not physical masses. Separately,
flat Euclidean four-dimensional parity-even massless one-loop gauge UV pole,
smooth compactly supported backgrounds, principal-symbol/local heat expansion.
No boundary, zero-mode, determinant-phase, global Pfaffian-sign, anomaly,
finite evanescent, massive threshold or QAP claim. IR separated by nonzero
Euclidean external momentum in the bubble; the heat calculation extracts only
the local short-time coefficient and does not take an unrestricted IR limit.

Primary computes the top Grassmann coefficient of exp(xi K xi/2) using an
exterior algebra, for paired and general alternating matrices of size4,6,8.
Its normalized formal log must be Tr log(K0^-1 K)/2. An off-diagonal Nambu
kernel must instead reproduce the ordinary complex determinant without an
additional half. Primary independently constructs exactly four Euclidean
gamma matrices (trace4), the actual odd-carrier chiral Nambu connection
A=PL T-PR T^T, and E=gamma12 Omega12 for F12. Calculate all color-pair
coefficients of tr(E^2/2+Omega_mn Omega_mn/12), both all45 and SM12.
Use Re Gamma_W=-Tr log(D^dagger D)/4, with both the Gaussian half and
modulus half explicit. P=-(nabla_A^2+E); no infinite-dimensional determinant
product equality or phase reconstruction is inferred from finite algebra.

Replay uses recursive alternating perfect matchings at integer z followed
by interpolation, determinant/trace identities and actual two-component
Euclidean sigma traces. Derive the parity-even bubble numerator, shift and
angular average in d=4-2epsilon, and extract ONLY its leading pole:
Res I2=1, Res int k^2/(k^2+Delta)^2=-2Delta, Delta=x(1-x)q^2,
in units1/(16pi^2 epsilon). Integrate the resulting transverse polynomial
over x in[0,1]. It independently uses the old even45 generators/SM frame
for the quadratic index, plus full species multiplicities. The same index
in conjugate carriers is appropriate; it does not assert full equivalence.

Published anchors: Vassilevich hep-th/0306138v3 Eq4.28 (Laplace a4), and
Dreiner/Haber/Martin0812.1594v6 Sec4.4 (closed-fermion sign), Sec6.23 and
AppB.2 (two-component current traces). These provide established mathematical
standards, not a Spin10 massive amplitude or an adopted regulator. The known
Weyl matter coefficient is +2T(R)/3 in beta(g)=b g^3/(16pi^2)+... . Compare
both calculated routes to this reference after derivation. The counterterm
has the opposite pole sign from the loop effective action.

Gate compares complete finite Gaussian polynomials/logs through order4,
all2025+144 color-pair positions including zeros, transverse bubble residue
and all sigma/Clifford identities. Controls omit the Nambu half, double a
family, use the auxiliary MEC spin trace16 as physical4, drop Omega^2,
reverse the loop effective-action sign or omit the conjugate block. Require
nonzero sensitive probes and identify any insensitive comparisons. Check
SM indices from actual matrices and species weights, including N indexzero.

Plausible outcomes: correct statistical recovery; an exact factor/sign
mismatch requiring correction; or underdefinition of a stronger quantum claim.
No primitive finite matter integral or finite scheme result may be inferred.
Do not repeat expensive old calculations. Distinct methods share physical
inputs, Python/SymPy and AI authorship; agreement is not independent physics.

Freeze seven sources/copies and inputs before sequential primary/replay/gate.
Each600s afterimports,8GiB sampled private,350MiB launchfloor,16MiB package.
Preserve failed/unfinished sources/captures, version any correction; no agents.
Scientific/director acceptance NOT_PERFORMED, authority34/39 unchanged;
E5/A5unqualified, flavorpaused,HB1/C5blocked,custodyexit2/seven NOTPASS.
The original scalar hierarchy failure and finite-point singlet warning remain.
