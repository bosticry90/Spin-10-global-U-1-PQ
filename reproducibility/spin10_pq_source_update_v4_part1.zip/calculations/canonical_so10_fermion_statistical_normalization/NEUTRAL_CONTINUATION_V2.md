# FSN1 neutral-index continuation V2

The first primary/replay/gate executions completed successfully and qualify
the finite Gaussian and parity-even gauge-pole normalization. Review before
commit found that replay's `neutral_SM_index=0` is a literal inherited value,
not a fresh projector calculation in that package. Its receipt is preserved;
that field alone must not be credited as a new verification of neutrality.
No failed scientific worker or failed Gaussian/pole result is being concealed.

This bounded continuation checks the missing claim directly, without rerunning
the completed normalization work. Freeze current live AGENTS/state and the
existing preparation/receipt, YCT1 generator/projector tables, FGI1 generators
and this record/script plus external controller. Source copies and hashes
precede the new execution. Same600s/8GiB sampled/350MiB launchfloor/16MiB
package limits. No agents, adoption, new loop or flavor calculation.

Check all12 SM generators annihilate the actual neutral projector on both
endpoints, in the provisional odd frame and original even frame. Compare the
orthogonal transformation explicitly. Independent stacked-matrix nullspace
and summed-positive-Casimir methods must both give a one-dimensional common
kernel equal to that projector. Test each of the15 other diagonal projectors;
all must be detected as charged. Report all coefficient positions and zeros.
These are finite representation identities, not a full massive gauge threshold.
State113/34of39 unchanged; scientific/director acceptance NOT_PERFORMED;
flavorpaused,HB1/C5blocked,E5/A5unqualified,custodyexit2/seven NOTPASS.
