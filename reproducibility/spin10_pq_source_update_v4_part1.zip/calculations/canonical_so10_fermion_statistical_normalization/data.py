"""FSN1 immutable IO and shared test inputs, not shared derivation."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dec(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(s.simplify(v))] for (i,j),v in sorted(s.SparseMatrix(M).todok().items()) if v]}
def probes(n,paired):
 D0=s.eye(n);V=s.Matrix(n,n,lambda i,j:(i+1 if i==j else ((i+2*j)%3-1)))
 B=s.Matrix(n,n,lambda i,j:0 if i==j else (i+j+1 if i<j else -(i+j+1)))
 C=s.Matrix(n,n,lambda i,j:0 if i==j else (j-i if i<j else j-i))
 K0=s.BlockMatrix([[s.zeros(n),-D0.T],[D0,s.zeros(n)]]).as_explicit()
 K1=s.BlockMatrix([[s.zeros(n) if paired else B,-V.T],[V,s.zeros(n) if paired else C]]).as_explicit()
 assert K0.T==-K0 and K1.T==-K1
 return K0,K1,V
def begin(role):
 start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]))
   if p.parent.resolve()==HERE and p.name.startswith('replay' if role=='primary' else 'primary'):raise PermissionError('FSN1_PEER_DENIED')
 sys.addaudithook(audit);return start
def finish(role,d,start):
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
