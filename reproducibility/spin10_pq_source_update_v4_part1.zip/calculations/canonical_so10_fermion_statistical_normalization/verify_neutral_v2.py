"""FSN1 V2 explicit common-kernel and neutral-projector checks."""
from data import *
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'neutral_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');fg=packed(CAL/'canonical_so10_fermion_goldstone_interface/replay_v2_tables.json.gz')
U=dec(yc['U']);PN=dec(yc['P_N']);H=dec(fg['SM_plane_coefficients']);Ts=list(map(dec,fg['spinor_plane_generators']));new=list(map(dec,yc['SM_generators']));old=[sum((H[a,j]*Ts[a] for a in range(45)),s.zeros(16)) for j in range(12)]
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
zero(PN*PN-PN);zero(PN.H-PN);assert s.trace(PN)==1
oldPN=s.simplify(U.H*PN*U);positions=0
for gs,p in [(new,PN),(old,oldPN)]:
 for g in gs:zero(g*p);zero(p*g);positions+=2*16*16
 stacked=s.SparseMatrix.vstack(*[s.SparseMatrix(g) for g in gs]);ker=stacked.nullspace();assert len(ker)==1
 Pker=ker[0]*ker[0].H/(ker[0].H*ker[0])[0];zero(Pker-p)
 cas=sum((g*g for g in gs),s.zeros(16));ker2=cas.nullspace();assert len(ker2)==1 and cas.rank()==15
 Pcas=ker2[0]*ker2[0].H/(ker2[0].H*ker2[0])[0];zero(Pcas-p)
for i in range(12):zero(new[i]-U*old[i]*U.H)
charged=0
for k in range(16):
 p=s.zeros(16);p[k,k]=1
 if p==PN:continue
 weights=[s.simplify(s.trace(p*g*g)) for g in new];assert any(v!=0 for v in weights);charged+=1
assert charged==15 and positions==12288
assert read(HERE/'validation_receipt.json')['status']=='QUALIFIED_PARITY_EVEN_WEYL_GAUSSIAN_AND_MASSLESS_GAUGE_POLE_NORMALIZATION'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_EXPLICIT_NEUTRAL_SM_PROJECTOR_AND_UNIQUE_COMMON_KERNEL','elapsed_after_imports':time.perf_counter()-start,
 'endpoint_positions_checked':positions,'SM_generators_each_frame':12,'frames':2,'common_kernel_dimension_each':1,'positive_Casimir_rank_each':15,
 'wrong_charged_projectors_detected':charged,'neutral_SM_index':'0','original_receipt_preserved':True,'original_literal_label_not_new_derivation':True,
 'new_model_loop_integrals':0,'provisional_carrier_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
