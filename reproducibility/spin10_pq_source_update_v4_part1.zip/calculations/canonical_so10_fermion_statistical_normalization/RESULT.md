# FSN1 result: correct Weyl counting and massless gauge-pole recovery

The parity-even massless gauge divergence has the standard normalization for
three Weyl families in the Spin(10) spinor. Redundant Nambu notation does not
introduce a second matter family. This is an established-physics recovery test
and a prerequisite for subsequent loops, not a finite matter threshold.

First gate status:
`QUALIFIED_PARITY_EVEN_WEYL_GAUSSIAN_AND_MASSLESS_GAUGE_POLE_NORMALIZATION`,
receipt SHA-256
`330046873656c162bb502ade91324dc1bbb9e5c2fb9149d99ce452ba25e0079b`.
The explicit neutral-projector supplement has status
`QUALIFIED_EXPLICIT_NEUTRAL_SM_PROJECTOR_AND_UNIQUE_COMMON_KERNEL`,
receipt SHA-256
`21215752812bdf38c97623e407dff78d6788bddaa7b64706134897c7d217474b`.
Scientific/director acceptance NOT_PERFORMED; authority remains 34/39.

## The two halves have different origins

For a finite nondegenerate alternating kernel, the oriented Grassmann integral
and its local normalized logarithm give

```
Z(K)/Z(K0) = Pf(K)/Pf(K0),
log[Z(K)/Z(K0)] = Tr log(K0^-1 K)/2.
```

The primary computes the top coefficient of the exterior exponential. Replay
uses alternating perfect matchings and interpolation, then independently
computes trace powers. Six paired/general kernels of size4,6,8 agree, with
all polynomial coefficients and logarithms through order4 compared. All24
tested logarithmic coefficients are nonzero and detect doubling/sign errors.
In the paired off-diagonal case, the normalized Pfaffian equals the ordinary
complex determinant. An extra half must not be applied to that determinant.

For the **modulus** of the massless four-component Nambu operator, the Gaussian
half and the separate squared-operator half instead give

```
Re Gamma_W = -Tr log(D^dagger D)/4.
```

This expression counts one Weyl field. It does not determine the phase or a
global sign of an infinite-dimensional Pfaffian. Finite algebra is not being
used to justify arbitrary products or rearrangements of regulated determinants.

## Two routes to the gauge divergence

Primary uses exactly four Euclidean gamma matrices with spin trace4 and the
actual provisional odd-carrier connection `A=PL T-PR T^T`. For the local
Laplace operator, it evaluates the complete color-pair coefficient in
`tr(E^2/2 + Omega_mn Omega_mn/12)`. With `F12=f`, the result per family is
`(8/3) delta_ab f^2` for all45 generators, and the same coefficient for SM12.
Both orientations of `Omega12` are retained. The local heat identity is the
established Laplace coefficient in
[Vassilevich, Eq4.28](https://arxiv.org/html/hep-th/0306138v3#S4.E28).
Only its local short-time logarithm is used; no unrestricted infrared limit,
boundary term or full determinant is constructed.

Replay uses actual two-component Euclidean sigma traces, checks all256
symmetrized four-sigma identities and derives the leading bubble pole.
After shifting momentum and angular averaging, its normalized residue is

```
4 x(1-x) (q^2 delta_mn - q_m q_n),
integral_0^1 4 x(1-x) dx = 2/3.
```

The longitudinal contraction vanishes. Nonzero Euclidean external momentum
separates this UV residue from a scaleless infrared integral. Dimensionally
vanishing numerator parts can affect finite terms and are not qualified by
this pole-only test. The fermionic sign and two-component method are checked
against [Dreiner, Haber and Martin, Sec4.4 and Sec6.23](https://arxiv.org/pdf/0812.1594).

The color calculation in replay uses the original even-carrier matrices and
subgroup frame; primary uses the candidate odd frame. Their quadratic indices
agree without implying fixed-generator equivalence of those representations.
Both routes agree across2025+144 positions for one family and again for three
families, including all off-diagonal zeros. The index per family is2 for
Spin(10) and for each normalized SM factor. Actual species weights corroborate
the SM indices. In the convention

```
beta(g)|matter = b_matter g^3/(16 pi^2) + ... ,
```

the result is

```
b_one_Weyl = 2 T(R)/3,
b_three_16 = 4,
b_SM_three_families = (4,4,4).
```

Equivalently, the loop pole multiplies `g^2 b F^2/(4*16 pi^2 epsilon)`;
the cancelling kinetic counterterm has the opposite sign. This is not a
finite matching coefficient or evidence of physical gauge unification.

## Review correction: explicit neutrality, rather than an inherited label

Review found that the first replay carried `neutral_SM_index=0` literally.
Its main Gaussian/pole result remains valid, but that label was not a fresh
neutral-projector derivation. The first frozen sources, captures and receipt
are preserved unchanged. `NEUTRAL_CONTINUATION_V2.md` records this limitation
and freezes the missing check before execution.

V2 directly checks both endpoints of all12 SM generators against the actual
neutral projector in the candidate and original frames:12,288 positions.
Stacked-generator nullspaces and the summed positive Casimir independently
give a unique one-dimensional kernel, equal to that projector. All15 other
diagonal projectors are detected as charged. The neutral state's zero SM
index is thus explicitly corroborated. It does **not** remove heavy gauge
transitions between neutral and charged states or their possible two-loop
mass dependence.

## Controls, execution and evidence limits

The tests distinguish an omitted Nambu half, using the auxiliary MEC spin
trace16 as physical4, omitting the conjugate block or the connection-curvature
term, a reversed effective-action sign, and doubled family counting. These
have nonzero pole probes. A leading parity-even pole cannot distinguish
finite evanescent continuations; it is explicitly insensitive to that issue.

Primary/replay/gate first executions completed exit0 in
66.1075449 / 3.6617486 / 0.1683400 seconds after imports. Their34/3/1 memory
samples have private maxima55,263,232 / 54,476,800 / 393,216 bytes. The last
single early sample does not estimate the verifier's peak. V2 completed in
0.5763998 seconds, with one early sample of2,551,808 bytes, also not a peak.
Launch available commit exceeded12.26GB. Frozen600s/8GiB sampled-memory/
350MiB launch-floor/16MiB package limits were not exhausted. All four workers
are terminal; no failed or unfinished new scientific worker occurred.
The first preparation/validation have36/43 bindings; V2 separately freezes
its inputs and source copies. Complete captures are retained internally and
in the external control directory. Reproduce fresh only in a separate
preserved copy, because outputs deliberately use exclusive creation.

The AI-capability evidence is recovery of a sensitive normalization by distinct
finite and local quantum methods, followed by detection and repair of a
verification-coverage gap. Shared action data, conventions, Python/SymPy and
AI authorship remain limitations. No external scientific confirmation, proof
assistant formalization, or empirical model validation is claimed.

## Consequence for the investigation

The basic Weyl/Nambu factor is now checked. A future matter calculation must
still specify its parity-odd phase, chiral regulator, evanescent/restoring
counterterms, source/measure domain, mass-dependent kernels and exact-once
forest assembly. A useful next question is the actual perturbative gauge
anomaly tensor and its relation to the unresolved determinant phase. Its
representation-theoretic test can be bounded without selecting flavor, but
must not be confused with constructing the full phase or QAP.

YCT1 remains a provisional full Yukawa realization. No carrier or physical
scheme was adopted, no flavor work resumed and no two-loop integral performed.
Both scalar points' separate negative quantum-control results are intact.
E5/A5 and physical unification remain unqualified; HB1/C5 blocked; historical
custody remains exit2/seven NOTPASS. The complete goal remains incomplete.
