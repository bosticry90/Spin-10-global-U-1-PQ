"""FGI1 full coefficient/map comparison and oriented Goldstone controls."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
def unequal(M):assert tidy(M).todok()
positions={}
for name in ['orbit','vector_Gram','SM_plane_coefficients','S','Goldstone_projector','projected_Yukawa_per_mass']:
 L,R=dec(A[name]),dec(B[name]);zero(L-R);positions[name]=L.rows*L.cols
for name in ['vector_projectors','spinor_plane_generators']:
 assert len(A[name])==len(B[name]);positions[name]=0
 for x,y in zip(A[name],B[name]):
  L,R=dec(x),dec(y);zero(L-R);positions[name]+=L.rows*L.cols
assert positions['projected_Yukawa_per_mass']==83968 and positions['Goldstone_projector']==107584
assert A['vector_resolved']==B['vector_resolved']
expected=[('0','0',['0']*3),('2','4',['7/10','0','1/4']),('5/8','5/2',['0']*3),('0','0',['0']*3),('3','6',['1/20','3/4','1/2'])]
expected_gold=['0','40/3','5/3','0','60/253']
for r,(current,ward,words),gold in zip(A['vector_resolved'],expected,expected_gold):
 assert r['current_trace']==current and r['Ward_trace']==ward and r['SM_words']==words and r['Goldstone_norm_per_mass2']==gold
for d in [A,B]:
 assert d['H_covariance_generators_checked']==12 and d['Majorana_symmetric'] and d['Goldstone_rank']==33 and d['SM_projector_matches_actual_kernel']
 assert not d['full_parent_Yukawa_tensor_constructed'] and not d['physical_mass_or_flavor_point_selected'] and d['new_loop_integrals']==0
T=list(map(dec,A['spinor_plane_generators']));f=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')['f']
by={}
for i,j,k,z in f:by.setdefault((i,j),[]).append((k,s.sympify(z)))
checks=0
for i in range(45):
 for j in range(i+1,45):
  zero(T[i]*T[j]-T[j]*T[i]-s.I*sum((z*T[k] for k,z in by.get((i,j),[])),s.zeros(16)));checks+=1
assert checks==990
print('STAGE full_spinor_scalar_Lie_map',checks,flush=True)
O=dec(A['orbit']);PG=dec(A['Goldstone_projector']);Y=dec(A['projected_Yukawa_per_mass']);S=dec(A['S']);H=dec(A['SM_plane_coefficients']);P=list(map(dec,A['vector_projectors']))
N=dec(B['normalized_Goldstone_basis']);YY=dec(B['normalized_Goldstone_vertices_per_mass']);V=dec(B['normalized_vector_basis'])
zero(N.T*N-s.eye(33));zero(V.T*V-s.eye(33));zero(N*N.T-PG);zero(YY*N.T-Y);zero(Y*O-s.I*S);zero(Y*PG-Y)
zero(P[0]-H*H.T);zero(sum(P,s.zeros(45))-s.eye(45))
mu=s.Symbol('mu');assert s.expand((-s.I*mu*S+s.I*mu*S)[0,0])==0
# The actual phase enters the matrix identity, not just a norm comparison.
unequal(-Y*O-s.I*S);unequal((-s.I*Y)*O-s.I*S);unequal(Y*O/s.sqrt(2)-s.I*S)
noPhi=Y.copy();noPhi[:,0:54]=s.zeros(256,54);unequal(noPhi*O-s.I*S)
W=s.SparseMatrix(33,33,{(32-j,j):(-1 if j%2 else 1) for j in range(33)});zero(W.T*W-s.eye(33));zero((YY*W)*(N*W).T-Y);unequal((YY*W)*N.T-Y)
goldnorm=s.simplify(s.trace(YY.H*YY));assert goldnorm==s.Rational(3855,253)
assert s.simplify(sum(s.Rational(r['Goldstone_norm_per_mass2']) for r in A['vector_resolved'])-goldnorm)==0
assert s.Rational(6)/s.Rational(3,10)!=s.Rational(60,253) # Sigma-only mass shortcut in mixed r4.
priorK=packed(CAL/'canonical_so10_gauge_fermion_mass_dependency/primary_tables.json.gz')
priorJ=packed(CAL/'canonical_so10_gauge_fermion_mass_dependency/primary_v2_tables.json.gz')
zero(sum((dec(r['K']) for r in A['vector_resolved']),s.zeros(16))-s.Matrix(priorK['kernel']))
zero(sum((dec(r['J']) for r in A['vector_resolved']),s.zeros(16))-s.Matrix(priorJ['mass_Ward_Gram']))
vmt=read(CAL/'canonical_so10_vector_mass_tangent/primary_result.json')['calculation']
assert [r['lambda'] for r in A['vector_resolved']]==vmt['base_eigenvalues']
assert [r['rank'] for r in A['vector_resolved']]==vmt['base_multiplicities']
for col in range(328):zero(s.Matrix(16,16,list(Y[:,col]))-s.Matrix(16,16,list(Y[:,col])).T)
print('RESULT '+json.dumps({'status':'QUALIFIED_ACTUAL_VECTOR_RESOLVED_SPINOR_GOLDSTONE_INTERFACE','elapsed_after_imports':time.perf_counter()-start,
 'coefficient_positions_compared':positions,'actual_Lie_commutators_checked':990,'H_covariance_generators_each_route':12,'canonical_Goldstone_rank':33,
 'vector_sector_current_traces':[r['current_trace'] for r in A['vector_resolved']],'vector_sector_Ward_traces':[r['Ward_trace'] for r in A['vector_resolved']],
 'vector_sector_SM_words':[r['SM_words'] for r in A['vector_resolved']],'vector_sector_Goldstone_norms_per_mass2':expected_gold,
 'total_Goldstone_norm_per_mass2':'3855/253','oriented_Goldstone_rule':'Y_e=i*(T_e^T*M+M*T_e)/sqrt(lambda_e), n_e=O*u_e/sqrt(lambda_e)',
 'full_parent_Yukawa_tensor_or_physical_scalar_complement_constructed':False,'Phi_projected_entries_are_not_new_54_Yukawa_terms':True,
 'controls':{'wrong_phase_or_sign_rejected':True,'wrong_sqrt2_normalization_rejected':True,'projected_Phi_omission_without_complement_rejected':True,'Sigma_only_mixed_vector_mass_rejected':True,'two_endpoint_Goldstone_rotation_preserved':True,'one_endpoint_rotation_rejected':True},
 'finite_threshold_or_quantum_width_cancellation_calculated':False,'physical_mass_flavor_or_scheme_selected':False,'new_loop_integrals':0,
 'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
