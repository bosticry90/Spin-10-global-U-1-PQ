"""FGI1 Fock bit actions and explicit normalized Goldstone eigenvertices."""
from data_v2 import *
from itertools import combinations
start=begin('replay');a=read(PK/'frozen_a10_physical_reconciliation/full_replay.json')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
O=dec(a['vacuum']['orbit']);G=dec(a['vacuum']['orbit_Gram']);zero(O.T*O-G)
lams=list(map(s.Rational,['0','3/10','3/2','25','253/10']));Ps=[];V=[]
for lam in lams:
 U=s.Matrix.hstack(*(G-lam*s.eye(45)).nullspace());W=U.T*U;L=W.cholesky();Q=tidy(U*L.T.inv())
 zero(Q.T*Q-s.eye(Q.cols));p=tidy(U*W.inv()*U.T);zero(p-Q*Q.T);zero(G*Q-lam*Q);Ps.append(p);V.append(Q)
masks=[m for m in range(32) if m.bit_count()%2==0];ix={m:i for i,m in enumerate(masks)}
def ga(mask,j):
 k=j//2;sign=-1 if (mask&((1<<k)-1)).bit_count()%2 else 1
 if j%2:sign*=s.I*(-1 if mask&(1<<k) else 1)
 return mask^(1<<k),sign
T=[]
for i,j in combinations(range(10),2):
 entries={}
 for mask in masks:
  after,c=ga(mask,j);target,d=ga(after,i);entries[ix[target],ix[mask]]=s.I*c*d/(2*s.sqrt(2))
 T.append(s.SparseMatrix(16,16,entries))
def number(i,j):
 entries={}
 for mask in masks:
  if not mask&(1<<j):continue
  sign=-1 if (mask&((1<<j)-1)).bit_count()%2 else 1;after=mask^(1<<j)
  if after&(1<<i):continue
  sign*= -1 if (after&((1<<i)-1)).bit_count()%2 else 1;entries[ix[after^(1<<i)],ix[mask]]=sign
 return s.SparseMatrix(16,16,entries)
E={(i,j):number(i,j) for i in range(5) for j in range(5)}
def su(indices):
 result=[]
 for i,j in combinations(indices,2):result.extend([(E[i,j]+E[j,i])/2,s.I*(E[j,i]-E[i,j])/2])
 for k in range(1,len(indices)):
  diagonal=sum((E[i,i] for i in indices[:k]),s.zeros(16))-k*E[indices[k],indices[k]];result.append(diagonal/s.sqrt(2*k*(k+1)))
 return result
g3=su([0,1,2]);g2=su([3,4]);Y=-sum((E[k,k] for k in range(3)),s.zeros(16))/3+sum((E[k,k] for k in [3,4]),s.zeros(16))/2
g1=s.sqrt(s.Rational(3,5))*Y;gs=[g1,*g2,*g3]
H=tidy(s.Matrix([[s.trace(t*g)/2 for g in gs] for t in T]));zero(H.T*H-s.eye(12));zero(H*H.T-Ps[0]);zero(G*H)
PN=s.diag(1,*([0]*15));S=tidy(s.Matrix.hstack(*(s.Matrix(256,1,list(t.T*PN+PN*t)) for t in T)));zero(S*Ps[0])
rows=[];Nv=[];Yv=[];vv=[]
for r,(lam,Q,p) in enumerate(zip(lams,V,Ps)):
 K=s.zeros(16);J=s.zeros(16)
 for col in range(Q.cols):
  t=tidy(sum((Q[k,col]*T[k] for k in range(45)),s.zeros(16)));M=t.T*PN+PN*t;K+=t*PN*t;J+=M.H*M
  if lam:
   n=O*Q[:,col]/s.sqrt(lam);y=s.I*M/s.sqrt(lam);Nv.append(n);Yv.append(s.Matrix(256,1,list(y)));vv.append(Q[:,col])
 K=tidy(K);J=tidy(J)
 words=[s.simplify(s.trace(g1*g1*K)),s.simplify(sum(s.trace(g*g*K) for g in g2)/3),s.simplify(sum(s.trace(g*g*K) for g in g3)/8)]
 rows.append({'sector':r,'lambda':str(lam),'rank':Q.cols,'K':enc(K),'J':enc(J),'current_trace':str(s.trace(K)),'Ward_trace':str(s.trace(J)),
  'SM_words':list(map(str,words)),'Goldstone_norm_per_mass2':str(s.simplify(s.trace(J)/lam)) if lam else '0'})
N=tidy(s.Matrix.hstack(*Nv));YY=tidy(s.Matrix.hstack(*Yv));VV=tidy(s.Matrix.hstack(*vv));zero(N.T*N-s.eye(33))
PG=tidy(N*N.T);B=tidy(YY*N.T);zero(B*O-s.I*S);zero(B*PG-B)
print('STAGE normalized_vector_and_Goldstone_eigenvertices',time.perf_counter()-start,flush=True)
cov_checks=0
for h,g in enumerate(gs):
 blocks=[]
 for sec in ['Phi','Sigma','phi','S']:
  n=a['representation_matrices'][sec][0]['shape'][0];blocks.append(tidy(sum((H[k,h]*dec(a['representation_matrices'][sec][k]) for k in range(45)),s.zeros(n))))
 rs=s.SparseMatrix(s.diag(*blocks));D=tidy(N.T*rs*N);zero(rs*N-N*D)
 rf=-s.I*g;L=s.SparseMatrix(s.kronecker_product(rf.T,s.eye(16))+s.kronecker_product(s.eye(16),rf.T));zero(L*YY+YY*D);cov_checks+=1
for j in range(33):zero(s.Matrix(16,16,list(YY[:,j]))-s.Matrix(16,16,list(YY[:,j])).T)
finish('replay_v2',{'method':'nullspace_Gram_Fock_normalized_eigenvertices','orbit':enc(O),'vector_Gram':enc(G),'vector_projectors':list(map(enc,Ps)),
 'spinor_plane_generators':list(map(enc,T)),'SM_plane_coefficients':enc(H),'SM_projector_matches_actual_kernel':True,'S':enc(S),'Goldstone_projector':enc(PG),'projected_Yukawa_per_mass':enc(B),
 'normalized_vector_basis':enc(VV),'normalized_Goldstone_basis':enc(N),'normalized_Goldstone_vertices_per_mass':enc(YY),
 'vector_resolved':rows,'H_covariance_generators_checked':cov_checks,'Majorana_symmetric':True,'Goldstone_rank':33,
 'full_parent_Yukawa_tensor_constructed':False,'physical_mass_or_flavor_point_selected':False,'new_loop_integrals':0},start)
