"""FGI1 V2 freezes the preserved helper failure and corrected source variants."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
bind=dict(json.loads((HERE/'preparation.json').read_bytes())['input_sha256'])
for p,h in bind.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='b3c7e24d577902a04e744836000d28a80fcd226c'
cap=json.loads((HERE/'primary_capture.json').read_bytes());assert cap['execution_state']=='FAILED' and cap['exit_code']!=0
assert 'TypeError' in cap['stdout_and_stderr'] and 'NoneType' in cap['stdout_and_stderr']
assert not (HERE/'primary_tables.json.gz').exists() and not (HERE/'replay_capture.json').exists()
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['CORRECTION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if name.endswith('.py'):ast.parse(raw)
 q=HERE/(name+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 bind[str(p)]=sha256(raw).hexdigest();bind[str(q)]=sha256(raw).hexdigest()
with (HERE/'execution_preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'FGI1_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),
 'source_fix':'missing su return only; versioned output/preparation paths','seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,
 'package_cap':16*1024**2,'original_primary_failure_preserved':True,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FGI1_V2_FROZEN',len(bind),'bindings',flush=True)
