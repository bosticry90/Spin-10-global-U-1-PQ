"""FGI1 coordinate-free orbit inverse and Clifford spinor interface."""
from data import *
from itertools import combinations
start=begin('primary');a=read(PK/'frozen_a10_physical_reconciliation/full_primary.json')
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
rho=[s.SparseMatrix(s.diag(*(dec(a['representation_matrices'][n][k]) for n in ['Phi','Sigma','phi','S']))) for k in range(45)]
v=dec(a['vacuum']['VEV']);O=tidy(s.SparseMatrix.hstack(*(r*v for r in rho)));zero(O-dec(a['vacuum']['orbit']))
G=tidy(O.T*O);zero(G-dec(a['vacuum']['orbit_Gram']))
lams=list(map(s.Rational,['0','3/10','3/2','25','253/10']));P=[]
for lam in lams:
 p=s.SparseMatrix(s.eye(45))
 for nu in lams:
  if nu!=lam:p=p*(G-nu*s.eye(45))/(lam-nu)
 p=tidy(p);zero(p*p-p);zero(G*p-lam*p);P.append(p)
assert list(map(lambda p:int(s.trace(p)),P))==[12,8,1,12,12]
Z=s.diag(1,-1);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]])
def kron(f):
 m=s.SparseMatrix([[1]])
 for z in f:m=s.SparseMatrix(s.kronecker_product(m,z))
 return m
gamma=[kron([Z]*k+[Q]+[s.eye(2)]*(4-k)) for k in range(5) for Q in [X,Y]]
masks=[m for m in range(32) if m.bit_count()%2==0];ids=[sum(((m>>k)&1)<<(4-k) for k in range(5)) for m in masks]
restrict=lambda M:s.SparseMatrix(M.extract(ids,ids));pairs=list(combinations(range(10),2))
T=[restrict(s.I*gamma[i]*gamma[j]/(2*s.sqrt(2))) for i,j in pairs]
ann=[(gamma[2*k]+s.I*gamma[2*k+1])/2 for k in range(5)];E={(i,j):restrict(ann[i].H*ann[j]) for i in range(5) for j in range(5)}
def su(js):
 out=[]
 for k,i in enumerate(js):
  for j in js[k+1:]:out.extend([(E[i,j]+E[j,i])/2,(E[i,j]-E[j,i])/(2*s.I)])
 for r in range(1,len(js)):out.append((sum((E[i,i] for i in js[:r]),s.zeros(16))-r*E[js[r],js[r]])/s.sqrt(2*r*(r+1)))
g3=su([0,1,2]);g2=su([3,4]);HY=sum((q*E[k,k] for k,q in enumerate([-s.Rational(1,3)]*3+[s.Rational(1,2)]*2)),s.zeros(16));g1=s.sqrt(s.Rational(3,5))*HY;gs=[g1,*g2,*g3]
H=tidy(s.Matrix(45,12,lambda i,j:s.trace(T[i]*gs[j])/2));zero(H.T*H-s.eye(12));zero(H*H.T-P[0]);zero(G*H)
PN=s.diag(1,*([0]*15));S=tidy(s.SparseMatrix.hstack(*[s.Matrix(256,1,list(t.T*PN+PN*t)) for t in T]))
for g in gs:zero(g*PN)
zero(S*P[0]);Gp=tidy(sum((p/lam for p,lam in zip(P[1:],lams[1:])),s.zeros(45)));PG=tidy(O*Gp*O.T)
B=tidy(s.I*S*Gp*O.T);zero(B*O-s.I*S);zero(B*PG-B);zero(PG*PG-PG);assert s.trace(PG)==33
print('STAGE actual_orbit_spinor_map_and_projected_vertices',time.perf_counter()-start,flush=True)
cov_checks=0
for h,g in enumerate(gs):
 rf=-s.I*g;rs=tidy(sum((H[k,h]*rho[k] for k in range(45)),s.zeros(328)))
 F=s.SparseMatrix(s.kronecker_product(rf.T,s.eye(16))+s.kronecker_product(s.eye(16),rf.T))
 zero(F*B+B*rs);cov_checks+=1
rows=[]
for ir,(p,lam) in enumerate(zip(P,lams)):
 K=s.zeros(16);J=s.zeros(16)
 for (x,y),c in p.todok().items():
  K+=c*T[x]*PN*T[y];sx=T[x].T*PN+PN*T[x];sy=T[y].T*PN+PN*T[y];J+=c*sx.H*sy
 K=tidy(K);J=tidy(J)
 words=[s.simplify(s.trace(K*g1*g1)),s.simplify(sum(s.trace(K*g*g) for g in g2)/3),s.simplify(sum(s.trace(K*g*g) for g in g3)/8)]
 rows.append({'sector':ir,'lambda':str(lam),'rank':int(s.trace(p)),'K':enc(K),'J':enc(J),'current_trace':str(s.trace(K)),'Ward_trace':str(s.trace(J)),
  'SM_words':list(map(str,words)),'Goldstone_norm_per_mass2':str(s.simplify(s.trace(J)/lam)) if lam else '0'})
for col in range(328):
 M=s.Matrix(16,16,list(B[:,col]));zero(M-M.T)
finish('primary',{'method':'matrix_polynomial_orbit_pseudoinverse_Clifford','orbit':enc(O),'vector_Gram':enc(G),'vector_projectors':list(map(enc,P)),
 'spinor_plane_generators':list(map(enc,T)),'SM_plane_coefficients':enc(H),'SM_projector_matches_actual_kernel':True,'S':enc(S),'Goldstone_projector':enc(PG),'projected_Yukawa_per_mass':enc(B),
 'vector_resolved':rows,'H_covariance_generators_checked':cov_checks,'Majorana_symmetric':True,'Goldstone_rank':33,
 'full_parent_Yukawa_tensor_constructed':False,'physical_mass_or_flavor_point_selected':False,'new_loop_integrals':0},start)
