# Actual vector sectors and normalized fermion–Goldstone input

The aggregate GFM current/mass-Ward result now has an exact interface to the
qualified 45-vector mass operator and 328-scalar orbit. This resolves the
relevant neutrino currents by vector mass and constructs their forced
Goldstone-projected Yukawa coefficients, retaining the neutral mass matrix
symbolically. It does not compute a loop amplitude or fix a flavor spectrum.

The completed V2 validation receipt is
52424d69de97649877193b309b94a702c0e88c4462aa9de56e5eb098df3f6211,
QUALIFIED_ACTUAL_VECTOR_RESOLVED_SPINOR_GOLDSTONE_INTERFACE. Original failed
V1 evidence remains separate. Scientific/director acceptance NOT_PERFORMED;
state113/34of39 unchanged.

## Resolving the actual currents

With G=O^T O and M_V,r²=g10² lambda_r, the actual mass projectors give:

| Sector | lambda_r | Vector rank | Tr K_r | Tr J_r | SM charge word (U1,SU2,SU3) |
| --- | ---: | ---: | ---: | ---: | --- |
| r0 | 0 | 12 | 0 | 0 | (0,0,0) |
| r1 | 3/10 | 8 | 2 | 4 | (7/10,0,1/4) |
| r2 | 3/2 | 1 | 5/8 | 5/2 | (0,0,0) |
| r3 | 25 | 12 | 0 | 0 | (0,0,0) |
| r4 | 253/10 | 12 | 3 | 6 | (1/20,3/4,1/2) |

K_r contracts T_a P_N T_b with P_r, and J_r contracts the Majorana mass
directions S_a=T_a^T P_N+P_N T_a. These are exact group-current/vertex
quantities per family and formal unit mass direction, not loop coefficients.
The light-sector and r3 zeros are zeros of THIS N-current projection; other
fermion currents in those sectors are not excluded. Nor does the r2 zero
SM word remove every fermionic diagram containing a neutral heavy vector.

The charged N-to-u^c/e^c currents occur in r1; N-to-Q occurs in r4. The
neutral self-current occurs in r2. The split r1 and r4 weights sum to the
earlier (3/4,3/4,3/4), but their masses differ. A common mass/charge average
therefore cannot substitute for the separate kernels.

The new spinor embedding is checked against the ACTUAL scalar/gauge basis:
the 12 spinor SM coefficient vectors form exactly ker(G), and all 990
commutators of the ordered 45 spinor matrices reproduce the qualified BFT
structure constants. This is stronger than matching field names, ranks or
Casimirs alone. It qualifies this classical representation/orbit map only.

## Oriented, canonically normalized Goldstone vertices

In the inherited convention O_a=rho_a v, delta eta=-g rho(omega)(v+eta),
rho_f=-iT and delta psi=+igT(omega)psi. Differentiating the mass bilinear
fixes dM[O_a]=i(T_a^T M+M T_a). For an orthonormal vector eigenvector u_e,

    n_e=O u_e/sqrt(lambda_e),
    Y_e=i(T_e^T M+M T_e)/sqrt(lambda_e).

Thus the phase and normalization are fixed in this chosen field orientation;
flipping the Goldstone basis flips both its direction and its vertex.
No physical mass or gauge-coupling value is selected. For family matrix
M_N, the matrices are obtained by tensoring with M_N, not by fitting it.

The coordinate-free Goldstone projection is

    B_G=i S G^+ O^T, G^+=sum_(r>0)P_r/lambda_r,
    B_G O=i S, B_G P_G=B_G, P_G=O G^+ O^T.

All 83,968 canonical coefficient positions compare exactly between the
direct pseudoinverse/Clifford route and independent nullspace/Fock route
that explicitly sums normalized eigenvertices. The latter retains all 33
vector/Goldstone basis directions, including zero vertex columns. All
107,584 scalar-projector positions, 14,760 orbit positions, 11,520 spinor
generator positions and 10,125 vector-projector positions also compare.
Both routes check the complete 12 unbroken-generator covariance equations;
the coefficients remain complex symmetric as required for Majorana bilinears.

The squared vertex norms per absolute neutral mass² are

    r1:40/3, r2:5/3, r3:0, r4:60/253,
    total:3855/253.

For general family masses the total multiplies Tr(M_N^dagger M_N). These
are coupling norms at the frozen VEV geometry, not perturbativity bounds,
partial-wave amplitudes or finite threshold contributions. No allowed mass
range has been inferred from them.

B_G is a projection onto gauge Goldstone directions, NOT a complete parent
Yukawa tensor. Its Phi-coordinate entries may be nonzero because those
Goldstones mix Phi and Sigma. They do not introduce a forbidden 54 Yukawa
coupling. The unconstructed physical-scalar complement of the full tensor
cannot be declared zero; it can cancel such coordinate components. The
projection alone must not be inserted as the full fermion/scalar action.

## Validation and preserved failure

Controls detect wrong Goldstone sign/i, wrong sqrt2 normalization, omission
of the projected Phi entries WITHOUT their missing scalar complement, and
using Sigma-only masses for the mixed r4 sector. Rotating both Goldstone
endpoints preserves B_G; rotating only one does not. The sum of sector K/J
matrices reproduces the separately qualified GFM results exactly.

The first primary stopped because its SM-generator helper omitted a return
statement. Original source/copy, capture and controller failure are intact;
replay/verifier V1 were never executed. CORRECTION_V2 freezes the return fix
and new paths without changing the science, inputs, tolerances or resources.
No interface or covariance qualification was reached by that failed run.

V2 primary/replay/gate completed in 38.369148/55.796998/10.075382 seconds
after imports. Sampled private maxima were 64,057,344/67,010,560/51,666,944
bytes with 20/29/6 samples; they are not continuous peaks. The failed primary
had 11 samples and sampled maximum 61,046,784 bytes. Available commit at
all launches exceeded 5.58GB. The 600s/8GiB sampled/350MiB launch/16MiB
package bounds were not exhausted. Preparations bind46/63/70 inputs.

The map, old representation/vacuum, exact-arithmetic software and AI analyst
remain shared premises. These checks are computational corroboration, not
external validation of the model or a new quantum equivalence theorem.

## Remaining calculation

This supplies actual sector/Goldstone inputs for a mass-dependent fermion
kernel. It does not supply full physical-scalar Yukawa vertices, numerical
Takagi masses, a finite FFV/FFS amplitude, proper forests, regulated contact
terms or quantum gauge-width cancellation. An ordered free-fermion Ward-line
test is the next bounded algebraic step; its inverse-propagator endpoints
must be retained before trying to sew a loop. Regulator placement can create
further terms, so even that identity will not be a complete quantum result.

The original bosonic threshold and its failed hierarchy remain OLD-point
results. The finite witness's classical certificates and already qualified
large singlet correction remain separate. No missing fermion term is fitted
to cancel either warning. No physical scheme, benchmark, source action or
paused flavor research is adopted; HB1/C5 remains blocked. Historical custody
is exit2/seven NOTPASS, formal authority34/39 and the full goal incomplete.
