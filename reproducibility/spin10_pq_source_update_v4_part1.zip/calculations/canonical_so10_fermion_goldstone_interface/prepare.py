"""FGI1 selected kinematic evidence closure, no historical policy rebinding."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='b3c7e24d577902a04e744836000d28a80fcd226c'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-goldstone-interface-v1-2026-10-22')
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 if str(p) in bind:assert bind[str(p)]==v
 bind[str(p)]=v
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V472.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
 'calculations/canonical_so10_direct_two_loop_heavy_threshold/RECORD.md','calculations/canonical_so10_direct_two_loop_heavy_threshold/YUKAWA_CONVENTION_V1.md',
 'calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/RECORD.md',
 'calculations/canonical_so10_vector_mass_tangent/DERIVATION.md','calculations/canonical_so10_vector_mass_tangent/pilot.py',
 'calculations/canonical_so10_vector_mass_tangent/preparation.json','calculations/canonical_so10_vector_mass_tangent/validation_preparation.json',
 'calculations/canonical_so10_vector_mass_tangent/primary_result.json','calculations/canonical_so10_vector_mass_tangent/replay_result.json',
 'calculations/canonical_so10_background_threshold_inputs/DERIVATION.md','calculations/canonical_so10_background_threshold_inputs/primary_tables.json.gz',
 'calculations/canonical_so10_background_threshold_inputs/replay_tables.json.gz',
 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 add(ROOT/name)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
for folder,names in {
 'canonical_so10_gauge_fermion_mass_dependency':['RECORD.md','RECORD_V2.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','primary_v2_tables.json.gz','replay_v2_tables.json.gz','validation_receipt.json','validation_receipt_v2.json'],
 'canonical_so10_vector_mass_tangent':['validation_receipt.json'],
 'canonical_so10_background_threshold_inputs':['validation_receipt_v2.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
add(ROOT/'calculations/canonical_so10_vector_mass_tangent/validation_receipt.json','82ca977dc8ca92187cff319f633f83bf07735fef5d51a920b7f6a2c051e7f138')
add(ROOT/'calculations/canonical_so10_background_threshold_inputs/validation_receipt_v2.json','fd1afe95d714f99d37828660f146bdc1b71c6ae13b014de16d51123766f561e6')
add(ROOT/'calculations/canonical_so10_gauge_fermion_mass_dependency/validation_receipt_v2.json','a1e82026bf738818eca5659d3711a6674fe23b826b89845a94bb3eef6962d9d9')
prior=json.loads((ROOT/'calculations/canonical_so10_vector_mass_tangent/preparation.json').read_bytes())['input_sha256']
for role in ['primary','replay']:
 p=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation'/('full_'+role+'.json')
 add(p,prior[str(p)])
for n in ['RECORD.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if n.endswith('.py'):ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==29873
CONTROL.mkdir(parents=True,exist_ok=False)
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'FGI1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FGI1_FROZEN',len(bind),'bindings',flush=True)
