# FGI1: actual vector sectors and the forced Goldstone projection

Question: can the qualified aggregate spinor currents/mass Ward direction
be resolved into the ACTUAL parent vector mass sectors and canonically
normalized Goldstone couplings, without selecting neutrino masses or a
flavor fit? This is the missing input interface for a future mass-dependent
fermion gauge/Goldstone kernel. Color norms alone are not loop amplitudes.
The previous GFM increment completed support/dependency statements, not this
actual scalar-orbit interface. No full two-loop rebuild is warranted here.

Freeze the physical 328-scalar/45-gauge representation and vacuum packets,
their exact orbit O and Gram G=O^T O, qualified BFT/VMT geometry, the frozen
three Weyl16 convention, GFM1/2 completed receipts and original C1 contracts.
Use omega²=60,sigma²=s²=3/5. The two scalar points share this kinetic/VEV
geometry; do not transfer their different scalar-potential masses or loops.
G has eigenvalues lambda=(0,3/10,3/2,25,253/10), multiplicities12,8,1,12,12,
and vector M²=g10² lambda. No numerical g10 or M_N is selected.

Claim FGI1.1: the canonical spinor45 and actual scalar45 use the SAME ordered
real-plane Lie basis and normalization. Construct the 12 SM spinor generators,
convert them by trace pairing to coefficients in that basis and prove their
orthogonal projector equals ker(G). Field-name/rank matching alone fails.
This earns only this representation/orbit interface, not quantum equivalence.

For the neutral projector P_N, let S_a=T_a^T P_N+P_N T_a and let S be the
256-by-45 matrix of vectorized S_a. Resolve current K_r and mass-Ward Gram
J_r with each exact spectral projector P_r; keep all off-diagonal adjoint
entries. Derive every species and charge-weighted word, including exact
zero sectors. Equal vector masses do not imply equal SM charges.

Claim FGI1.2: in the inherited real antisymmetric scalar convention
D=d+g rho, delta eta=-g rho(omega)(v+eta), physical T=i rho,
rho_fermion=-iT and delta psi=+igT(omega)psi. With mass term
-psi^T M psi/2+h.c., covariance fixes dM[rho_a v]=i(T_a^T M+M T_a).
Choose the oriented unit Goldstone n_e=O u_e/sqrt(lambda_e), with real
orthonormal vector eigenvector u_e. Its FORCED projected Yukawa coefficient
per formal neutral mass is Y_e=i S_e/sqrt(lambda_e). No physical unit mass
has been adopted. The family mass matrix remains a symbolic tensor factor.

Coordinate-free scalar projection and its acceptance identities are

 B_G=i S G^+ O^T,  G^+=sum_(r>0) P_r/lambda_r,
 B_G O=i S,  B_G P_G=B_G,  P_G=O G^+ O^T.

B_G is a Goldstone-PROJECTED matrix-valued coefficient in the 328 canonical
coordinates, NOT the full parent Yukawa tensor. Its Phi-coordinate part
can be nonzero because gauge Goldstones mix Phi and Sigma; this does NOT
create a forbidden 54 Yukawa interaction. The unknown physical-scalar
complement of the full parent tensor cannot be set to zero by this result.

Primary: reconstruct O from all physical rho_a v, use matrix-polynomial
P_r and Clifford spinors, then construct B_G with G^+. Replay: use the
independently qualified orbit packet, derive each P_r from exact nullspace
bases/Gram inverses, use Fock bit actions for the original 45 plane spinors,
orthonormalize each vector eigenspace and sum explicit normalized Goldstone
vertices Y_e*n_e^T. The replay imports no primary implementation/output.
Compare all canonical coefficients, actual orbit/projectors, resolved currents
and norms, including zero complements, before qualification.

The separate gate also bridges all45 spinor matrices to the QUALIFIED actual
BFT structure constants through all990 Lie commutators. This is a new
cross-representation map check, not a fresh replay of the old kernel proof.
Check all12 local-H algebraic covariance identities for B_G using the actual
328-scalar generators and the new spinor interface, retaining the cotangent
transpose. Check Majorana symmetry, the explicit phase through the mass
bilinear variation, normalization and projector identities. Gauge-orbit
derivatives are at fixed parent inputs, not retuned stationary families.
The inherited kinetic/Goldstone completeness and field conventions remain
assumptions, not new QAP, finite-width or physical-state unitarity theorems.

Controls: missing sqrt2 spinor normalization; wrong i/sign in the Goldstone
coefficient; zeroing the Phi part of the PROJECTED tensor without its missing
physical-scalar complement; using Sigma-only masses for mixed vector sectors;
and rotating/permuting an orthonormal Goldstone basis while retaining both
endpoints. The scalar-projection control is not a test of a proposed full
parent Yukawa tensor. Reproduce GFM aggregate K/J and qualified mass geometry.

Comparator: Martens1011.2927v2 eq24 and its Goldstone mass normalization give
established classical covariance context (https://arxiv.org/pdf/1011.2927,
consulted2026-10-22). BFT's actual rho/field orientation fixes our phase;
do not import another gauge or its no-heavy-fermion finite formula.

Freeze all sources/copies/inputs before sequential primary/replay/separate
gate. 600s each after imports,8GiB sampled private,350MiB launch floor,
16MiB package. Preserve failed/incomplete captures and version repairs.
Failure of any map/covariance requirement leaves that interface unqualified;
resource exhaustion is incomplete, never a smaller passing projection.
No agents, massive loop integral, numerical flavor/mass/hierarchy assumption,
physical benchmark/scheme, parameter release or paused-stage activation.

Ceiling: exact vector-resolved current and Goldstone-projected fermion input
only. No complete Yukawa intertwiner, physical-scalar Yukawa rule, finite
threshold, quantum Slavnov/width cancellation, E5/A5 or unification claim.
State113/34of39 and custodyexit2/seven NOTPASS unchanged. Shared action,
representation, old geometry, exact software and AI author limit independence;
no external physical confirmation. Director education voluntary/nonblocking.
Scientific/director acceptance NOT_PERFORMED; whole goal incomplete.
