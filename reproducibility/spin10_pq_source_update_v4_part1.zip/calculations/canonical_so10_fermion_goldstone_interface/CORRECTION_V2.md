# FGI1 implementation failure and V2 continuation

The original primary failed in primary.py's su helper: it built the list
of SM generators but omitted `return out`. The caller therefore received
None and raised TypeError before constructing the scalar/spinor interface.
It had built the actual orbit, Gram/projectors and Clifford matrices, but
no interface/covariance or final coefficient qualification was reached.

Preserve original sources/copies, primary_capture.json and
controller_failure.json unchanged. Original replay and verifier sources
were frozen but never executed; they are not failed scientific calculations.
This is an avoidable implementation error, not a nonzero physical residual.

primary_v2.py adds the missing return. New data_v2 and versioned filenames
bind a separate execution preparation, outputs and validation preparation;
replay_v2 and verify_v2 keep the original scientific operations and gates.
Freeze these new sources and all original failed evidence before computing.
Same physical inputs, exact equality requirements, 600s/8GiB sampled/
350MiB launch/16MiB package bounds. No gate, target or authority changes.
Failed/incomplete work is never relabelled PASS; only completed V2 evidence
can qualify the declared FGI1 interface. All old evidence stays immutable.
