from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g1-current-profile-applicability-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='740a198de631ddbe2dbf087aee76b025592b6425'
names=set(json.loads((O/'preparation.json').read_bytes())['sha256'])
for folder in ['canonical_so10_lifted_probe_master_carrier_reduction_v1','canonical_so10_geometric_metric_insertion_lift_v1','canonical_so10_geometric_affine_trace_domain_v1','canonical_so10_marked_geometric_primitive_transport_v1','canonical_so10_causal_one_loop_sewing','canonical_so10_graded_causal_qap','canonical_so10_connected_ward_transport']:
    names|={q.relative_to(R).as_posix()for q in(B/folder).iterdir()if q.is_file()and(q.name.startswith(('RESULT','PROOF','DERIVATION'))or'receipt'in q.name and q.name.endswith('.json'))}
names.add('calculations/canonical_so10_auxiliary_probe_renormalization/validation_v2_receipt.json')
for n in ['validate.py','execute_validation.py','RESULT.md','PROOF.md','FINAL_RECORD.md']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}|{'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V866.md'}
for n in ['README_before_final.bytes','campaign_before_final.bytes']:assert(C/n).is_file()
prep=dict(base_HEAD='740a198de631ddbe2dbf087aee76b025592b6425',sha256={n:digest(R/n)for n in sorted(names)},limits=dict(seconds=180,sampled_private_bytes=8*1024**3,packet_bytes=32*1024**2,artifact_bytes=8*1024**2),scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_validation.json',prep);dump(C/'preparation_validation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'validate.py')]);dump(O/'capture_validation.json',cap);dump(C/'capture_validation.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
