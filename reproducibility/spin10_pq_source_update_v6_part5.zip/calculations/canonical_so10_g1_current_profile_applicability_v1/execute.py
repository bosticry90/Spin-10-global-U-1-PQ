from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g1-current-profile-applicability-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='740a198de631ddbe2dbf087aee76b025592b6425'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V865.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md'}
for folder in ['canonical_so10_regulator_vertices_g1_recovery_v1','canonical_so10_regulator_free_inverse_g1_recovery_v1','canonical_so10_heat_clock_applicability_v1','canonical_so10_vector_physical_ward_g1_recovery_v1','canonical_so10_vector_ghost_divergence_companion_g1_v1','canonical_so10_vector_mixed30_g1_recovery_v1','canonical_so10_vector_expanded_regulator_reconciliation_g1_v1','canonical_so10_proper_normalization_transfer_g1_v1','canonical_so10_joint_common_family_applicability_v1','canonical_so10_g0_common_profile_applicability_v1','canonical_so10_common_conversion_carrier_v1','canonical_so10_geometric_ward_current_source_chart_v1','canonical_so10_auxiliary_primitive_contact_compatibility','canonical_so10_auxiliary_probe_renormalization','canonical_so10_finite_normalization_probe_lift']:
    names|={q.relative_to(R).as_posix()for q in(B/folder).iterdir()if q.is_file()and(q.name.startswith(('PROOF','RESULT','DERIVATION'))or q.name in ['validation_receipt.json','validation_receipt_v2.json','validation_receipt_v5.json','final_capture.json','capture_validation.json','capture_validation_v2.json','capture_validation_v5.json'])}
for role in ['native','replay']:
    for folder,fn in [('canonical_so10_regulator_vertices_g1_recovery_v1',role+'_catalog.json.gz'),('canonical_so10_regulator_vertices_g1_recovery_v1',role+'_units_F0.json.gz'),('canonical_so10_regulator_free_inverse_g1_recovery_v1',role+'_inverse.json.gz')]:names.add('calculations/'+folder+'/'+fn)
for folder,fn in [('canonical_so10_heat_clock_applicability_v1','complete_profile_and_clock_evidence_v3.json.gz'),('canonical_so10_vector_mixed30_g1_recovery_v1','path_partition_v2.json'),('canonical_so10_vector_expanded_regulator_reconciliation_g1_v1','support_result.json'),('canonical_so10_proper_normalization_transfer_g1_v1','proper_reference.json.gz')]:names.add('calculations/'+folder+'/'+fn)
prefix='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'
for n in ['A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md','A10_E5_QUANTUM_CONTRACT_V1.md','A10_E5_QUANTUM_CONTRACT_RESULT.md','A10_E5_MEASURED_RESTORATION_FOUNDATIONS_V1.md']:names.add(prefix+n)
enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored))
dump(O/'input_encoding_bindings.json',dict(bindings=enc));dump(C/'input_encoding_bindings.json',dict(bindings=enc))
for n in ['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
prep=dict(base_HEAD='740a198de631ddbe2dbf087aee76b025592b6425',sha256={n:digest(R/n)for n in sorted(names)},limits=dict(seconds=120,sampled_private_bytes=8*1024**3,packet_bytes=32*1024**2,artifact_bytes=8*1024**2),scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
