"""Separate V866 review, without producer parsing/exchange/path helpers."""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter,defaultdict
from hashlib import sha256
import gzip,json,os,threading,time,subprocess,sys
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g1-current-profile-applicability-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=8*1024**2
    with(O/n).open('xb')as f:f.write(blob)
    return dict(file=n,sha256=digest(O/n),bytes=len(blob))
def base(n):return(n-1319)%643
def odd(n):return int(553<=base(n)<643)
def col(i):
    if i<180:return i//4
    if i<553:return i-508
    if i<598:return i-553
    return i-598
def kind(i):
    if i<180:return 'B'
    if 508<=i<553:return 'L'
    if 553<=i<598:return 'C'
    if 598<=i<643:return 'a'
    raise AssertionError(('UNEXPECTED_FREE_COORDINATE',i))
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();prep=read(O/'preparation_validation_v2.json')
    for n,h in prep['sha256'].items():assert digest(R/n)==h,n
    prior=read(O/'preparation_validation.json')
    for n,h in prior['sha256'].items():
        archive={'README.md':'README_before_final_v2.bytes','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':'campaign_before_final_v2.bytes','docs/RESEARCH_EXECUTION_HANDOFF_V866.md':'handoff_before_final_v2.bytes'}
        assert digest(C/archive[n]if n in archive else R/n)==h,n
    failed=read(O/'capture_validation.json');assert failed==read(C/'capture_validation.json')and failed['exit_code']==1 and not failed['calculation_completed']and "TypeError: unhashable type: 'list'"in failed['stdout_and_stderr']
    old=read(O/'preparation.json')
    for n,h in old['sha256'].items():
        p=C/('README_before_final.bytes'if n=='README.md'else'campaign_before_final.bytes')if n in ['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']else R/n;assert digest(p)==h,n
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['calculation_completed']and cap['post_run_observations_qualified']and cap['exit_code']==0 and all(0<r['private_bytes']<=8*1024**3 for r in cap['all_resource_samples'])
    clock=load(B/'canonical_so10_heat_clock_applicability_v1/complete_profile_and_clock_evidence_v3.json.gz');M={4*r+mu for r in range(12,45)for mu in range(4)}|set(range(520,553))|set(range(565,598))|set(range(610,643));assert M==set(clock['selected_M_coordinate_ids'])
    counts=[];signature=[]
    for role in ['native','replay']:
        product=load(O/(role+'_complete_g1_profile_applicability.json.gz'));catalog=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_catalog.json.gz'));units=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_units_F0.json.gz'));inv=load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'))
        nonzero={r['field']for r in units['units']};assert len(units['zero_units'])==418 and all(len(row)==2 and row[1]=='ZERO_FULL_T1_F'for row in units['zero_units']);zero={row[0]for row in units['zero_units']};assert len(nonzero)==225 and len(zero)==418 and not nonzero&zero and nonzero|zero==set(range(643))
        raw=defaultdict(Q)
        for row in units['units']:
            for w,m,cs in row['families']['preference']['raw_product']:
                if any(n<1319 or n>=2605 for n,j in w):continue
                assert len(w)==2 and all(not j for n,j in w);assert col(base(w[0][0]))==col(base(w[1][0]))
                for key,num,den in cs:raw[tuple(n for n,j in w),tuple(m),tuple(key)]+=Q(num,den)
        raw={k:v for k,v in raw.items()if v};assert len(raw)==1440
        # Independent color-labelled exchange orbits; each original regulator
        # weight is retained. No H/M profile equivalence is used.
        normal=defaultdict(Q);broken=defaultdict(Q)
        for(nodes,m,k),v in raw.items():
            r=col(base(next(n for n in nodes if n>=1962)));power=tuple(m[i]+m[4+i]for i in range(4))+m[8:];original=next(base(n)for n in nodes if n>=1962);split=r<12 and kind(original)in['C','a']
            for orientation in [False,True]:
                word=tuple((n-1319+1962 if n<1962 else n-1962+1319)if orientation else n for n in nodes);sign=(-1)**sum(odd(word[i])*odd(word[j])for i in range(2)for j in range(i+1,2)if word[i]>word[j]);word=tuple(sorted(word));sgn=(-1)**sum(m[:4]if orientation else m[4:8]);value=v*sign*sgn/2;normal[word,power,k,r]+=value;broken[word,power,k,r,int(split)]+=value
        normal={k:v for k,v in normal.items()if v};broken={k:v for k,v in broken.items()if v};assert not normal and len(broken)==192
        actual_bad={}
        for w,m,k,label,num,den in product['complete_wrong_H_ghost_profile_residual']:actual_bad[tuple(n for n,j in w),tuple(m[:4]+m[8:]),tuple(k),label]=Q(num,den)
        combined=defaultdict(Q)
        for(w,m,k,r,sp),v in broken.items():combined[w,m,k,('H'if r<12 else'M')+('_ghost'if sp else'')]+=v
        assert{k:v for k,v in combined.items()if v}==actual_bad
        journals=[];coverage=0;h_universe=0
        for cat,saved in zip(catalog['catalogs'],product['all54_word_journals']):
            assert cat['channel']==saved['channel']and cat['probe']==saved['probe'];classes={r['id']:r for r in cat['classes']};h_universe+=sum(any(t.endswith('H')for t in r['quantum'])for r in classes.values());types={}
            expected=0 if not cat['probe']else(46 if cat['channel']=='vector'else 8);assert len(cat['complete_rooted_oriented_cycles'])==len(saved['all_unsummed_words'])==expected
            for ix,cycle in enumerate(cat['complete_rooted_oriented_cycles']):
                r,orient,tail=cycle;ports=[(classes[r],orient)]+[(classes[i],o)for i,o in tail];incoming=[c['quantum'][o]for c,o in ports];outgoing=[c['quantum'][1-o]for c,o in ports];edges=list(map(list,zip(outgoing,incoming[1:]+incoming[:1])));assert all(a[-1]==b[-1]=='M'for a,b in edges);assert edges==saved['all_unsummed_words'][ix]['ordered_green_types'];assert cycle==saved['all_unsummed_words'][ix]['word'];coverage+=1
                for a,b in edges:types[a,b]=types.get((a,b),0)+1
            journals.append(dict(channel=cat['channel'],probe=cat['probe'],cycles=expected,oriented_edge_occurrences=[[list(k),v]for k,v in sorted(types.items())]))
        assert coverage==54 and h_universe
        groups=read(B/'canonical_so10_vector_mixed30_g1_recovery_v1/path_partition_v2.json')['groups'];partition=[row for rows in groups.values()for row in rows];assert sorted(row['index']for row in partition)==list(range(46));vector=next(q for q in catalog['catalogs']if q['channel']=='vector'and q['probe']==1)
        for row in partition:assert row['word']==vector['complete_rooted_oriented_cycles'][row['index']]
        support=read(B/'canonical_so10_vector_expanded_regulator_reconciliation_g1_v1/support_result.json');assert len(support['separate_raw_unit_excluded_port_catalogs'])==8 and all(r['returning_paths']==0 for r in support['separate_raw_unit_excluded_port_catalogs'])
        selected={}
        for family,rows in clock['complete_selected_matrix_entries'].items():selected[family]=[r for r in inv[family]if r[0]in M and r[1]in M];assert selected[family]==rows
        assert len(selected['Greference'])==858 and len(selected['Preference'])==len(selected['Pphysical'])==891
        assert not selected['reference_defect']and not selected['reference_product']
        # Preserve both actual ordered ghost signs in the full color block.
        gr={(i,j):v for i,j,v in selected['Greference']}
        for r in range(12,45):assert gr[553+r,598+r]=='1/(q0**2 + q1**2 + q2**2 + q3**2)'and gr[598+r,553+r]=='-1/(q0**2 + q1**2 + q2**2 + q3**2)'
        counts.append(dict(role=role,all643_F0_dispositions=True,independent_color_profile_exchange_zero=True,mismatched_H_profile_positions=len(broken),all54_word_edges=journals,all9_M_matrix_families_equal=True));signature.append(selected)
        print('STAGE '+role+' independent_color_exchange_and_all54_interfaces_complete',flush=True)
    assert signature[0]==signature[1]
    proper=load(B/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz');allrows=proper['M_vector_all_positions'];assert len({(r['B'],r['Lambda'],r['C'])for r in allrows})==91125
    nz=[r for r in allrows if any(r[k]for k in ['ell_log','ell_rational','p_log','p_rational'])];saved=load(O/'complete_external_color_and_profile_boundary.json.gz');assert nz==saved['all_nonzero_proper_rows']and len(nz)==1126 and sum(r['B']<12 for r in nz)==526
    # Existing named scientific owners must have completed qualified receipts.
    owners=[];historical=[]
    endpoints={'canonical_so10_heat_clock_applicability_v1':'validation_receipt_v5.json','canonical_so10_vector_physical_ward_g1_recovery_v1':'validation_receipt_v2.json','canonical_so10_geometric_ward_current_source_chart_v1':'validation_receipt_v2.json','canonical_so10_g0_common_profile_applicability_v1':'validation_receipt_v2.json','canonical_so10_auxiliary_probe_renormalization':'validation_v2_receipt.json','canonical_so10_finite_normalization_probe_lift':'validation_receipt_v2.json','canonical_so10_graded_causal_qap':'validation_receipt_v2.json','canonical_so10_connected_ward_transport':'adversarial_validation_receipt.json'}
    for n in prep['sha256']:
        if 'receipt'in Path(n).name and Path(n).suffix=='.json':
            if Path(n).name!=endpoints.get(Path(n).parent.name,'validation_receipt.json'):
                historical.append([n,digest(R/n),'AUTHENTICATED_HISTORY_ONLY_NOT_CURRENT_QUALIFICATION']);continue
            rc=read(R/n)
            if 'evidence_validation'in rc:assert str(rc['evidence_validation']).startswith('PASS'),n
            if 'execution_state'in rc:assert rc['execution_state']=='COMPLETED',n
            owners.append([n,digest(R/n)])
    spec=(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md').read_text(encoding='utf-8');assert 'its coefficients are unresolved' in spec and 'At first differing restored order'in spec and 'tree normalization is fixed, loop mixing matrices are not calculated'in spec
    checks=save('complete_independent_final_checks_v2.json.gz',dict(role_checks=counts,qualified_owner_receipts=owners,historical_receipts_NOT_repromoted=historical,proper_all91125_positions=True,nonzero1126_external_H526_M600=True,original_W6_loop_mixing_unresolved=True,matched_even_quartet_premise_RETAINED=True,free_logarithmic_and_physical_baselines_NOT_chosen=True,actual_full643_profile_and_general_QAP_NOT_inferred=True))
    e4=subprocess.run([sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(exit_code=e4.returncode,stdout=e4.stdout,stderr=e4.stderr);dump(O/'e4_capture_v2.json',ec);dump(C/'e4_capture_v2.json',ec);events=[json.loads(q)for q in e4.stdout.splitlines()if q.strip()];exits=[q['exit_code']for q in events if q.get('event')=='step_finished'];assert e4.returncode==0 and exits==[0,0,0,0,0,2]and next(q for q in events if q.get('event')=='step_finished'and q.get('step')=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    for n,h in prep['sha256'].items():assert digest(R/n)==h,n
    assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['base_HEAD']and(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    historic=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);assert sha256(historic).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and(R/'README.md').read_bytes().replace(b'\r\n',b'\n').endswith(historic)
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V866.md'];assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    rc=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_SELECTED_G1_M_PROFILE_APPLICABILITY_AND_SCOPED_FORMAL_COMMON_FAMILY_CLOSEOUT',base_HEAD=prep['base_HEAD'],independent_check_artifact=checks,role_checks=counts,whole_F0_matched_even_profile_premise_RETAINED=True,no_new_H_profile_no_new_loop_integral=True,whole643_actual_heat_QAP_E5_A5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',state_sha256=digest(R/'project_state.json'),files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt_v2.json',rc);dump(C/'validation_receipt_v2.json',rc);watch.cancel()
if __name__=='__main__':main()
