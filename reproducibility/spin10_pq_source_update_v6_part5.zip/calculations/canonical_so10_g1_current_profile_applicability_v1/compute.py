from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter
from hashlib import sha256
import gzip,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g1-current-profile-applicability-v1-2026-11-08')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def tag(i):
    if i<180:return 'B'+('H'if i<48 else'M')
    if 508<=i<553:return 'L'+('H'if i<520 else'M')
    if 553<=i<598:return 'C'+('H'if i<565 else'M')
    if 598<=i<643:return 'a'+('H'if i<610 else'M')
    return 'x'
def color(i):return i//4 if i<180 else i-508 if i<553 else i-553 if i<598 else i-598
def field(n):
    assert 1319<=n<2605
    return n-1319 if n<1962 else n-1962
def parity(n):return int(553<=field(n)<643)
def canonical(w):
    if any(parity(n)and w.count((n,j))>1 for n,j in w):return None,0
    s=(-1)**sum(parity(w[i][0])*parity(w[j][0])for i in range(len(w))for j in range(i+1,len(w))if w[i]>w[j]);return tuple(sorted(w)),s
def encode(P):return [[[[n,list(j)]for n,j in w],list(m),list(k),label,v.numerator,v.denominator]for(w,m,k,label),v in sorted(P.items())if v]
def rawfree(packet):
    out=defaultdict(F)
    for row in packet['units']:
        for w,m,co in row['families']['preference']['raw_product']:
            if not all(1319<=n<2605 for n,j in w):continue
            assert len(w)==2 and all(not j for n,j in w)
            ww=tuple((n,tuple(j))for n,j in w)
            for k,num,den in co:out[ww,tuple(m),tuple(k)]+=F(num,den)
    return{k:v for k,v in out.items()if v}
def normal(P,method,mismatch=False):
    # The profile label stays attached to its ORIGINAL regulator halfedge.
    # It is even in q. Different H/M symbols are never identified.
    out=defaultdict(F)
    if method=='native':
        for(w,m,k),v in P.items():
            q=[field(n)for n,j in w];assert color(q[0])==color(q[1]);j=next(field(n)for n,js in w if n>=1962);label=('H'if color(j)<12 else'M')+('_ghost'if mismatch and tag(j)in['CH','aH']else'')
            mm=tuple(m[i]+m[4+i]for i in range(4))+(0,)*4+m[8:];sw=[(n+643 if n<1962 else n-643,js)for n,js in w]
            for word,sgn in [(w,(-1)**sum(m[4:8])),(sw,(-1)**sum(m[:4]))]:
                ww,s=canonical(word)
                if s:out[ww,mm,k,label]+=v*F(sgn*s,2)
    else:
        pulled=defaultdict(F)
        for(w,m,k),v in reversed(list(P.items())):
            j=next(field(n)for n,js in w if n>=1962);label=('H'if color(j)<12 else'M')+('_ghost'if mismatch and tag(j)in['CH','aH']else'');mm=tuple(a+b for a,b in zip(m[:4],m[4:8]))+(0,)*4+m[8:];pulled[w,mm,k,label]+=v*(-1)**sum(m[4:8])
        for(w,m,k,label),v in pulled.items():
            out[w,m,k,label]+=v/2;sw=[(n+643 if n<1962 else n-643,js)for n,js in w];ww,s=canonical(sw)
            if s:out[ww,m,k,label]+=v*F(s*(-1)**sum(m[:4]),2)
    return{k:v for k,v in out.items()if v}
ALLOWED={('BM','BM'),('BM','LM'),('LM','BM'),('CM','aM'),('aM','CM')}
def words(cat,method):
    classes={z['id']:z for z in cat['classes']};out=[]
    for index,row in enumerate(cat['complete_rooted_oriented_cycles']):
        root,ro,path=row;nodes=[(root,ro)]+[(i,o)for i,o in path];selected=[classes[i]for i,o in nodes];assert len(nodes)<=cat['proved_total_vertex_bound']
        assert sum(q['g']for q in selected)==sum(q['u']for q in selected)==1
        assert tuple(sum(q['external'][j]for q in selected)for j in range(4))==((1,1,1,0)if cat['channel']=='vector'else(0,1,1,1))
        if method=='native':edges=[[classes[i]['quantum'][1-o],classes[j]['quantum'][p]]for(i,o),(j,p)in zip(nodes,nodes[1:]+nodes[:1])]
        else:
            incoming=[classes[i]['quantum'][o]for i,o in nodes];outgoing=[classes[i]['quantum'][1-o]for i,o in nodes];edges=[[outgoing[n],incoming[(n+1)%len(nodes)]]for n in range(len(nodes))]
        assert all(tuple(q)in ALLOWED for q in edges)
        out.append(dict(index=index,word=row,ordered_vertex_classes=selected,ordered_green_types=edges,internal_H_edges=0,independent_edge_profiles=[dict(edge=j,profile='F_M(q_'+str(j)+')',q_squared='independent_transferred_momentum',root_IR_defect_RETAINED=True)for j in range(len(edges))]))
    return out
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    clock=load(B/'canonical_so10_heat_clock_applicability_v1/complete_profile_and_clock_evidence_v3.json.gz');M=set(clock['selected_M_coordinate_ids']);assert len(M)==231
    reports=[];paired=[]
    for role in ['native','replay']:
        catalog=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_catalog.json.gz'));inv=load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'));units=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_units_F0.json.gz'));raw=rawfree(units);assert len(raw)==1440
        normal_good=normal(raw,role);normal_bad=normal(raw,role,True);assert not normal_good and normal_bad
        sectors=Counter('H'if color(field(w[0][0]))<12 else'M'for w,m,k in raw)
        wh=[];universeH=[];typed=set()
        for cat in catalog['catalogs']:
            journal=words(cat,role);assert len(journal)==(0 if cat['probe']==0 else 46 if cat['channel']=='vector'else 8)
            for c in cat['classes']:
                if any(t.endswith('H')for t in c['quantum']):universeH.append(dict(channel=cat['channel'],probe=cat['probe'],complete_class=c))
            for w in journal:typed.update(map(tuple,w['ordered_green_types']))
            wh.append(dict(channel=cat['channel'],probe=cat['probe'],all_unsummed_words=journal,root_state_counts=cat['root_state_counts'],catalog_H_candidates_retained=sum(any(t.endswith('H')for t in c['quantum'])for c in cat['classes'])))
        assert universeH and sum(len(z['all_unsummed_words'])for z in wh)==54
        for family,entries in clock['complete_selected_matrix_entries'].items():
            actual=[r for r in inv[family]if r[0]in M and r[1]in M];assert actual==entries,('COMPLETE_MATRIX_FAMILY_MISMATCH',family)
        matrixpairs=Counter((tag(i),tag(j))for i,j,value in clock['complete_selected_matrix_entries']['Greference']);assert typed<=set(matrixpairs)and sum(matrixpairs.values())==858
        part=read(B/'canonical_so10_vector_mixed30_g1_recovery_v1/path_partition_v2.json');vm=next(x for x in wh if x['channel']=='vector'and x['probe']==1);fullcat=next(x for x in catalog['catalogs']if x['channel']=='vector'and x['probe']==1);classes={c['id']:c for c in fullcat['classes']};partition=[]
        for name,rows in part['groups'].items():
            for row in rows:
                ix=row['index'];assert row['word']==vm['all_unsummed_words'][ix]['word'];r,o,path=row['word'];assert row['root']==classes[r]and row['ordinary']==[classes[i]for i,oo in path];partition.append([ix,name])
        assert sorted(i for i,n in partition)==list(range(46))
        support=read(B/'canonical_so10_vector_expanded_regulator_reconciliation_g1_v1/support_result.json');assert all(not q['returning_paths']for q in support['separate_raw_unit_excluded_port_catalogs']);assert support['probe_non_antighost_full_T1_zero']and support['no_g0u0_ordinary_B_mean']
        art=save(role+'_complete_g1_profile_applicability.json.gz',dict(all54_word_journals=wh,complete_retained_H_class_universe=universeH,all46_actual_contracted_partition=sorted(partition),all_used_green_types=sorted(typed),complete_signed_M_Green_type_counts=[[list(k),v]for k,v in sorted(matrixpairs.items())],all9_complete_M_matrix_families_match=True,whole_F0_raw_monomials=[[[[n,list(j)]for n,j in w],list(m),list(k),v.numerator,v.denominator]for(w,m,k),v in sorted(raw.items())],whole_F0_sector_counts=dict(sectors),whole_F0_independent_H_M_even_profile_normal=encode(normal_good),complete_wrong_H_ghost_profile_residual=encode(normal_bad),full_omitted_port_proof=support['separate_raw_unit_excluded_port_catalogs'],heat_clock='t_new=2*t_old; delta=epsilon; no heat commuted through vertices',finite_clock_rule='FP_new=FP_old-L*log(2); all power/prefactor jets retained',actual_H_profile_NOT_chosen=True))
        paired.append(dict(journals=wh,raw=raw,normal_bad=normal_bad,partition=sorted(partition)));reports.append(dict(role=role,artifact=art,returning_words=54,M_coordinates=231,signed_M_Green_entries=858,whole_F0_raw_monomials=len(raw),whole_F0_sector_counts=dict(sectors),wrong_H_ghost_profile_residual_positions=len(normal_bad),actual_H_profile_NOT_needed_for_returning_words=True))
        print('STAGE '+role+' all54_M_words_and_whole_F0_profile_coherence_checked',flush=True)
    assert paired[0]==paired[1]
    proper=load(B/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz');positions=proper['M_vector_all_positions'];nonzero=[r for r in positions if any(r[k]for k in ['ell_log','ell_rational','p_log','p_rational'])];assert len(positions)==91125 and len(nonzero)==1126;bh=sum(r['B']<12 for r in nonzero);assert bh==526 and len(nonzero)-bh==600
    assert proper['proper_equals_negative_full_current_by_actual_operator_identity']and proper['all_finite_8_8_30_profiles_inherited_unchanged']and not proper['common_normalization_or_restoring_primitive_adopted']
    save('complete_external_color_and_profile_boundary.json.gz',dict(all_nonzero_proper_rows=nonzero,all91125_positions_owner_sha256=digest(B/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz'),external_B_H=bh,external_B_M=len(nonzero)-bh,internal_H_edges_in_qualified_54_words=0,zero_complements=proper['H_vector_zero_complement'],source_zero_complement=proper['source_zero_complement'],profile_equality_applies_BEFORE_ordered_limits=True,full_nonlocal_functional_NOT_identified=True))
    dump(O/'result.json',dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='SELECTED_G1_MEASURED_CURRENT_TARGETS_HAVE_COMPLETE_M_PROFILE_SUPPORT; WHOLE_F0_REQUIRES_MATCHED_EVEN_QUARTET_PROFILES',roles=reports,external_B_H_nonzero=526,external_B_M_nonzero=600,new_loop_integrals=0,actual_H_profile_selected=False,elapsed_after_imports=time.perf_counter()-tick));watch.cancel()
if __name__=='__main__':main()
