# V866 final reader correction V2

The first final worker FAILED before the independent mathematics: it passed
the list-valued zero-unit records to set(). Actual frozen records are
[field_id,"ZERO_FULL_T1_F"]. Preserve validate.py,its exact source copy,
preparation_validation.json,capture_validation.json and original prose.
No receipt or scientific qualification resulted from that worker.

V2 validates that explicit schema and extracts field_id. Retain ALL643
dispositions,225 nonzero/418 zero,disjointness and completeness. All path,
matrix,exchange,color,owner,contract,resource/provenance/E4 obligations stay.
Same180s/8GiB sampled,32MiB/8MiB,full restart; no scientific requirement is
relaxed and no input/model/profile is changed. New code/preparation/capture/
receipt/output names are versioned. Old navigation is archived under its
original frozen hashes rather than rebound when live links move to V2.

Only validation_receipt_v2.json and capture_validation_v2.json can qualify
the result. Original failed final evidence remains FAILED. Ordinary parsing
correction is delegated by AGENTS; no extra execution permission is needed.
