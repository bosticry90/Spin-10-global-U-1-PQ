from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-metric-insertion-lift-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V859_FROZEN_GRADED_CURRENT_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
import tensor_lift as m
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def flat(P):return {(w,(g,x,e,mask)):v for(g,w),co in P.items()for(x,e,mask),v in co}
def attachment(rules):
    rows=[]
    for i,P in sorted(rules.items()):
        assert 0<=i<180;mu=i%4
        for(g,w),co in sorted(P.items()):
            direct=[at for at,(n,j)in enumerate(w)if(n<180 and n%4==mu)or(643<=n<823 and(n-643)%4==mu)or mu in j];peer=set(at for at,(n,j)in enumerate(w)if mu in j);peer.update(at for at,(n,j)in enumerate(w)if n<180 and n%4==mu or 643<=n<823 and(n-643)%4==mu);assert direct==sorted(peer)and direct,('UNATTACHED_GEOMETRIC_VECTOR',i,g,w);rows.append([i,g,[[n,list(j)]for n,j in w],direct])
    return rows
def root(name,P,role):
    eu=flat(P);assert m.flat(m.encode(eu))==eu;mm=m.unwick(eu);lift=m.reconstruct(mm,role);assert lift['match'];return dict(name=name,complete_Euclidean=a.encode(P),complete_Minkowski=m.encode(mm),fixed_tensor_lift=lift,complete_wrong_time_jet_difference=m.encode(m.add(m.unwick(eu,omit_time_jets=True),m.scale(mm,-1))))
def current(name,P,role):
    eu=flat(P);assert m.flat(m.encode(eu))==eu;mm=m.unwick(eu);normal,curr=m.sym_normal(mm);assert not normal,('NONZERO_FULL_CURRENT_NORMAL',name);tagged=m.tag_current(curr);lift=m.reconstruct(tagged,role);assert lift['match'];return dict(name=name,complete_Euclidean_density=a.encode(P),complete_Minkowski_density=m.encode(mm),complete_symmetric_normal=m.encode(normal),all_four_natural_Minkowski_currents=[m.encode(q)for q in curr],complete_tagged_natural_current=m.encode(tagged),fixed_current_tensor_lift=lift)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    roles=[]
    for role,owner in[('native','primary'),('replay','replay')]:
        ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(ch['all_current_names'],ch['all_current_parities']);assert tuple(m.par(i)for i in range(1298))==A.parities;W=a.decode(ch['complete_W']);Kg=a.decode(ch['complete_Kgeo']);cs={i:a.decode(q)for i,q in ch['all1286_source_difference_columns']};T={i:a.decode(q)for i,q in ch['all1286_direct_Tq_columns']};EW=a.eulers(A,W,set(range(643)));assert all(cs[643+i]==EW.get(i,{})for i in range(643));assert all(sum(n<643 for n,j in w)<=2 and all(n<643 or n>=1286 for n,j in w)for(g,w),cv in W.items());support=sorted(i for i in range(643)if cs[643+i]);assert all(i<180 or 598<=i<643 for i in support)
        base=a.load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S=a.decode(base['complete_current_GF_source_base']);ES=a.eulers(A,S,set(range(643,1286)));ops=a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(q)for n,q in ops['states'].items()};Fbase={}
        for i in range(643):
            Fbase[i]=a.plus(*(p.chosen(p.old(states['F'+str(g)][i]),1+p.dim(i))for g in[0,1]));assert ES.get(643+i,{})==a.scale(Fbase[i],(-1)**A.parities[i]),('BASE_FULL_SOURCE_EULER_MISMATCH',role,i)
        attached_c=attachment({i:cs[643+i]for i in support if i<180});attached_F=attachment({i:Fbase[i]for i in range(180)});CS=p.pair(A,cs,ES);literal=p.action(A,S,cs,owner);ibp=a.plus(literal,a.scale(CS,-1));baseward=a.plus(p.action(A,S,T,owner),CS);oldboundary=p.divergence(A,[a.decode(q)for q in base['all_four_Tqprime_parent_current_images']]);assert not a.plus(baseward,ibp,oldboundary)
        roots=[root('W',W,role),root('Kgeo',Kg,role),root('C_S',CS,role)];currents=[current('C_source_IBP',ibp,role),current('base_geometric_Ward',baseward,role)];probeports=[]
        for probe in['H','M']:
            u=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_'+probe+'_even_geometric_insertion_v2.json.gz'));CU=a.decode(u['complete_C_U_Euler_pair']);TU=a.decode(u['complete_Tq_U']);roots.append(root('C_U_'+probe,CU,role));currents.append(current('probe_'+probe+'_geometric_Ward',a.plus(TU,CU),role));EE={i:a.decode(q)for i,q in u['all1286_selected_U_Eulers']};assert all(not EE[643+i]for i in range(508));probeports.append(dict(probe=probe,all508_physical_source_Eulers_zero=True,nonzero_C_source_ports=[i for i in support if EE[643+i]]))
        artifact=save(role+'_complete_geometric_metric_insertions.json.gz',dict(all_fixed_density_roots=roots,all_new_natural_current_witnesses=currents,actual_c_source_support=support,all_vector_c_free_index_attachments=attached_c,all_vector_base_F_free_index_attachments=attached_F,all643_base_source_Eulers_equal_reused_operators=True,probe_source_support=probeports,omega_even_scalar_current_chart=list(A.parities[1286:]),old_V857_V858_currents_NOT_modified=True,no_new_classical_D_circle_REQUIRES_final_actual_support_graph_review=True,all_quantum_closed_D_traces_and_first_U_covariance_RETAINED=True))
        roles.append(dict(role=role,artifact=artifact,density_roots=[dict(name=z['name'],words=len(z['complete_Minkowski']),tensor_groups=len(z['fixed_tensor_lift']['tensor_groups']),controls=z['fixed_tensor_lift']['controls'])for z in roots],natural_current_witnesses=[dict(name=z['name'],density_words=len(z['complete_Minkowski_density']),current_words=[len(q)for q in z['all_four_natural_Minkowski_currents']],tensor_groups=len(z['fixed_current_tensor_lift']['tensor_groups']))for z in currents],vector_c_attachment_rows=len(attached_c),vector_F_attachment_rows=len(attached_F)));print('STAGE '+role+' all_geometric_density_and_natural_current_metric_lifts_complete',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='FIXED_GEOMETRIC_INSERTION_AND_NATURAL_CURRENT_LIFTS_SUPPORTED_PENDING_FINAL_D_JET_REVIEW',roles=roles,new_alpha_prime_or_loop_coefficient_NOT_calculated=True,first_U_whole_operator='(i/2)T_kappa[G H_CU-G H_U G H_CS]',profiles_common_quantum_products_full_W5_E5_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
