from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product,permutations
from collections import defaultdict
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-metric-insertion-lift-v1-2026-11-08')
sys.path.insert(0,str(B/'canonical_so10_geometric_ward_current_source_chart_v1'));import algebra as a
sp=importlib.util.spec_from_file_location('V859_FROZEN_FRACTION_EULERS',B/'canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
sp=importlib.util.spec_from_file_location('V859_FROZEN_SOURCE_PAIR_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def raw(rows):return {(tuple((i,tuple(js))for i,js in w),tuple(k)):F(num,den)for w,co in rows for k,num,den in co}
def compact(q):
    rows=defaultdict(list)
    for(w,k),cv in sorted(q.items()):
        if cv:rows[w].append([list(k),cv.numerator,cv.denominator])
    return [[[[n,list(js)]for n,js in w],co]for w,co in sorted(rows.items())]
def grouped(q):
    out={}
    for(w,(g,x,e,mask)),cv in q.items():a.put(out,(g,w),(((x,e,mask),cv),))
    return out
def parity(n):
    if 2000<=n<2004 or 1286<=n<1298:return 0
    assert 0<=n<1286,n
    return int(n>=553)if n<643 else 1-int(n-643>=553)
def canon(w):
    odd=[t for t in w if parity(t[0])]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(w)),(-1)**sum(odd[i]>odd[j]for i in range(len(odd))for j in range(i+1,len(odd)))
def put(q,w,k,cv):
    ww,sg=canon(w)
    if sg:v.add(q,(ww,k),sg*cv)
def D(q,mu):
    out={}
    for(w,k),cv in q.items():
        for at,(n,js)in enumerate(w):put(out,w[:at]+((n,tuple(sorted(js+(mu,)))),)+w[at+1:],k,cv)
    return out
def div(cc):
    out={}
    for mu,q in enumerate(cc):
        for k,cv in D(q,mu).items():v.add(out,k,cv)
    return out
def phase(n):
    if 2000<=n<2004:return 1 if n==2000 else 0
    if 1286<=n<1298:return 0
    f=n-643 if n>=643 else n
    return 3 if 508<=f<553 else 1 if f<180 and f%4==0 else 2 if n>=643 and f<508 else 0
def unwick(q,omit_time=False):
    out={}
    for(w,k),cv in q.items():
        pw=(-sum(phase(n)for n,js in w)-(0 if omit_time else sum(js.count(0)for n,js in w)))%4;kk=list(k);sign=-[1,1,-1,-1][pw]
        if pw%2:
            if kk[3]&16:sign=-sign
            kk[3]^=16
        v.add(out,(w,tuple(kk)),sign*cv)
    return out
def descriptor(w):
    rows=[]
    for n,js in w:
        rows.append((0,n//4,len(js))if n<180 else(1,(n-643)//4,len(js))if 643<=n<823 else(2,0,len(js))if 2000<=n<2004 else(3,n,len(js)))
    return tuple(sorted(rows))
def variances(desc):return tuple(x for kind,n,j in desc for x in(([1]if kind==1 else[-1])if kind<3 else[])+[-1]*j)
def component_word(desc,indices):
    cursor=0;w=[]
    for kind,n,j in desc:
        if kind<3:
            mu=indices[cursor];cursor+=1;i=4*n+mu if kind==0 else 643+4*n+mu if kind==1 else 2000+mu
        else:i=n
        js=tuple(sorted(indices[cursor:cursor+j]));cursor+=j;w.append((i,js))
    assert cursor==len(indices);return canon(tuple(w))
PAIR={0:[()],2:[((0,1),)],4:[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]}
def columns(desc,wrongmetric=False,wrongsource=False):
    var=variances(desc);rank=len(var);assert rank in PAIR
    if wrongsource:var=(-1,)*rank
    cols=[]
    for pairing in PAIR[rank]:
        col={}
        for mus in product(range(4),repeat=len(pairing)):
            indices=[0]*rank;cv=1
            for (i,j),mu in zip(pairing,mus):
                indices[i]=indices[j]=mu
                if not wrongmetric and var[i]==var[j]and mu!=0:cv=-cv
            w,sg=component_word(desc,indices)
            if sg:col[w]=col.get(w,0)+sg*cv
        cols.append({w:cv for w,cv in col.items()if cv})
    return cols
def combine(cols,coefficients):
    out={}
    for col,co in zip(cols,coefficients):
        for w,cv in col.items():
            for k,num,den in co:v.add(out,(w,tuple(k)),cv*F(num,den))
    return out
def tensor(q,record):
    groups=defaultdict(dict)
    for(w,k),cv in q.items():groups[descriptor(w)][w,k]=cv
    assert len(groups)==len(record['tensor_groups']);allq={};domain_total=0;controls=dict(wrong_metric_sensitive_groups=0,wrong_source_variance_sensitive_groups=0,missing_first_rank4_pairing_sensitive_groups=0)
    for(desc,target),z in zip(sorted(groups.items()),record['tensor_groups']):
        rank=len(variances(desc));assert z['descriptor']==[list(x)for x in desc]and z['rank']==rank;cols=columns(desc);assert len(z['all_pairing_coefficients'])==len(cols);constructed=combine(cols,z['all_pairing_coefficients']);assert target==constructed and not z['complete_residual'];domain={w for ids in product(range(4),repeat=rank)for w,sg in[component_word(desc,ids)]if sg};assert {w for w,k in target}<=domain and z['canonical_component_domain']==len(domain)and z['zero_component_count']==len(domain)-len({w for w,k in target});domain_total+=len(domain)
        for k,cv in constructed.items():v.add(allq,k,cv)
        controls['wrong_metric_sensitive_groups']+=bool(v.delta(target,combine(columns(desc,wrongmetric=True),z['all_pairing_coefficients'])));controls['wrong_source_variance_sensitive_groups']+=bool(v.delta(target,combine(columns(desc,wrongsource=True),z['all_pairing_coefficients'])))
        if rank==4:controls['missing_first_rank4_pairing_sensitive_groups']+=bool(v.delta(target,combine(cols[1:],z['all_pairing_coefficients'][1:])))
    assert allq==q==raw(record['complete_reconstructed_density'])and record['match']and not record['complete_residual']and domain_total==record['component_domain_count']and controls==record['controls'];return dict(groups=len(groups),components_with_zero_complement=domain_total,controls=controls)
def natural_current(q):
    norm={};cur=[{}for mu in range(4)]
    for(w,k),cv in q.items():
        assert w
        for at,(n,js)in enumerate(w):
            orders=list(permutations(js))or[()];sg=(-1)**(parity(n)*sum(parity(i)for i,j in w[:at]));co=cv*F(sg,len(w)*len(orders))
            for order in orders:
                jj=list(order);rest={(w[:at]+w[at+1:],k):co}
                while jj:
                    mu=jj.pop()
                    for(ww,kk),vv in rest.items():put(cur[mu],((n,tuple(sorted(jj))),)+ww,kk,vv)
                    rest={key:-value for key,value in D(rest,mu).items()}
                for(ww,kk),vv in rest.items():put(norm,((n,()),)+ww,kk,vv)
    assert v.delta(q,norm)==div(cur);return norm,cur
def ledger(rules):
    out=[]
    for i,P in sorted(rules.items()):
        mu=i%4
        for(g,w),co in sorted(P.items()):
            hits=[at for at,(n,js)in enumerate(w)if mu in js or n<180 and n%4==mu or 643<=n<823 and(n-643)%4==mu];assert hits;out.append([i,g,[[n,list(js)]for n,js in w],hits])
    return out
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='11f39b34290677423215deb3fb57d555c7fe7c17'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation.json');assert prep==a.read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings.json');assert enc==a.read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    old=(B/'canonical_so10_augmented_metric_lift_v1/algebra.py').read_bytes();new=(O/'tensor_lift.py').read_bytes();assert new==old.replace(b'if 1286<=n<1319:return 1',b'if 1286<=n<1298:return 0')and old!=new;bind=a.read(O/'constructor_extension_binding.json');assert sha256(old).hexdigest()==bind['old_source_sha256']and sha256(new).hexdigest()==bind['new_source_sha256']
    sp=importlib.util.spec_from_file_location('V859_ACTUAL_PARAMETER_ALPHABET_ONLY',O/'tensor_lift.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
    for i in range(1298):assert m.par(i)==parity(i)
    for i in range(1298,1319):
        try:m.par(i)
        except AssertionError:pass
        else:raise AssertionError('STALE_EPSILON_PARAMETER_ACCEPTED')
    cap=a.read(O/'capture.json');assert cap==a.read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=a.read(O/'result.json');assert result['elapsed_after_imports']<180;prior={z['case']:z for z in a.read(B/'canonical_so10_augmented_metric_lift_v1/result.json')['cases']};summaries=[]
    for rr,owner in zip(result['roles'],['primary','replay']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(ch['all_current_names'],ch['all_current_parities']);assert A.parities==tuple(parity(i)for i in range(1298));W=a.decode(ch['complete_W']);Kg=a.decode(ch['complete_Kgeo']);cs={i:a.decode(q)for i,q in ch['all1286_source_difference_columns']};T={i:a.decode(q)for i,q in ch['all1286_direct_Tq_columns']};EW=v.allE(v.flat(a.encode(W)),A.parities);assert all(v.flat(a.encode(cs[643+i]))==EW.get(i,{})for i in range(643));assert all(sum(n<643 for n,j in w)<=2 and all(n<643 or n>=1286 for n,j in w)for(g,w),cv in W.items());support=[i for i in range(643)if cs[643+i]];assert support==z['actual_c_source_support']and all(i<180 or 598<=i<643 for i in support)
        base=a.load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S=a.decode(base['complete_current_GF_source_base']);EE=v.allE(v.flat(a.encode(S)),A.parities);ES={643+i:grouped(EE.get(643+i,{}))for i in range(643)};ops=a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(q)for n,q in ops['states'].items()};Fbase={}
        for i in range(643):
            Fbase[i]=a.plus(*(p.chosen(p.old(states['F'+str(g)][i]),1+p.dim(i))for g in[0,1]));assert ES[643+i]==a.scale(Fbase[i],(-1)**A.parities[i])
        for g in[0,1]:
            row=prior[role+'_current_parent_g'+str(g)];assert row['required']and row['match'];q=unwick(v.flat(a.encode(p.grade(S,g))));assert sha256((json.dumps(compact(q),separators=(',',':'))+'\n').encode()).hexdigest()==row['canonical_input_sha256']
        assert ledger({i:cs[643+i]for i in support if i<180})==z['all_vector_c_free_index_attachments']and ledger({i:Fbase[i]for i in range(180)})==z['all_vector_base_F_free_index_attachments'];CS=p.pair(A,cs,ES);literal=p.action(A,S,cs,'replay'if owner=='primary'else'primary');expected={'W':W,'Kgeo':Kg,'C_S':CS};currentP={'C_source_IBP':a.plus(literal,a.scale(CS,-1)),'base_geometric_Ward':a.plus(p.action(A,S,T,'replay'if owner=='primary'else'primary'),CS)}
        for pr,probe in enumerate(['H','M']):
            u=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_'+probe+'_even_geometric_insertion_v2.json.gz'));CU=a.decode(u['complete_C_U_Euler_pair']);expected['C_U_'+probe]=CU;currentP['probe_'+probe+'_geometric_Ward']=a.plus(a.decode(u['complete_Tq_U']),CU);U=a.decode(u['complete_selected_U']);Eu={i:a.decode(q)for i,q in u['all1286_selected_U_Eulers']};assert all(not Eu[643+i]for i in range(508))
            for g in[0,1]:
                row=prior[role+'_U'+str(g)+'_'+probe];assert row['required']and row['match'];q=unwick(v.flat(a.encode(p.grade(U,g))));assert sha256((json.dumps(compact(q),separators=(',',':'))+'\n').encode()).hexdigest()==row['canonical_input_sha256']
        roots=[]
        for r in z['all_fixed_density_roots']:
            P=expected.pop(r['name']);assert P==a.decode(r['complete_Euclidean']);Q=unwick(v.flat(a.encode(P)));assert Q==raw(r['complete_Minkowski']);lift=tensor(Q,r['fixed_tensor_lift']);assert v.delta(unwick(v.flat(a.encode(P)),omit_time=True),Q)==raw(r['complete_wrong_time_jet_difference']);roots.append(dict(name=r['name'],**lift))
        assert not expected;currents=[]
        for r in z['all_new_natural_current_witnesses']:
            P=currentP.pop(r['name']);assert P==a.decode(r['complete_Euclidean_density']);Q=unwick(v.flat(a.encode(P)));assert Q==raw(r['complete_Minkowski_density']);N,cc=natural_current(Q);assert not N and raw(r['complete_symmetric_normal'])==N and [raw(q)for q in r['all_four_natural_Minkowski_currents']]==cc and div(cc)==Q;tag={}
            for mu,q in enumerate(cc):
                for(w,k),cv in q.items():put(tag,w+((2000+mu,()),),k,cv)
            assert tag==raw(r['complete_tagged_natural_current']);lift=tensor(tag,r['fixed_current_tensor_lift']);currents.append(dict(name=r['name'],**lift))
        assert not currentP;summaries.append(dict(role=role,roots=roots,natural_currents=currents,all643_source_Eulers_and_actual_vector_attachments_verified=True));print('STAGE '+role+' independent_component_and_labelled_current_lifts_verified',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V859.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V859.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V859.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2;files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V859.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_FIXED_GEOMETRIC_INSERTION_NATURAL_CURRENT_AND_CLASSICAL_D_JET_INTERFACE',base_HEAD=head,state_sha256=state,roles=summaries,constructor_only_even_parameter_change_verified=True,actual_parent_canonical_hashes_source_support_graph_and_current_proof_reviewed=True,scope='CLASSICAL_FIXED_MODULE_LOCAL_GEOMETRIC_SUBSTITUTION_AND_FIRST_D_JET_ONLY',quantum_D_traces_mixed_Hessians_and_ordinary_U_covariance_NOT_zeroed=True,profiles_actual_common_quantum_normalization_full_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_codec_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
