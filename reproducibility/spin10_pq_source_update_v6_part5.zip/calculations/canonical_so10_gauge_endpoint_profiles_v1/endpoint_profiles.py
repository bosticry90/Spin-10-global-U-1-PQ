"""Exact endpoint, divergence and local-contact controls for V913."""

import json
import sys
import sympy as sp

from execute import ROOT, run_worker


def profiles(phase):
    s=sp.symbols("s",real=True)
    graphs={"DMM":[2,-1,-1],"FMY":[1,-1,0],"FFMM":[1,1,-1,-1],
            "kinetic_with_root":[1,-1,0],"YY":[0,0],"Y_feedback":[0,0]}
    degrees={}
    for name,charges in graphs.items():
        if phase=="native":
            weight=sp.prod(s*sp.exp(q*s/2) for q in charges)
        else:
            weight=s**len(charges)*sp.exp(s*sum(charges)/2)
        assert sp.simplify(weight-s**len(charges))==0
        degrees[name]=len(charges)
    assert sp.simplify(s**2-s**3-s**2*(1-s))==0
    assert sp.simplify(s**3*sp.exp(s/2)-s**3)!=0
    return {"collapsed_degrees":degrees,"per_mixed_edge_charges":[1,-1],
            "unpaired_endpoint_negative_control":"nonzero",
            "transition_profile":"chi**2*(1-chi)"}


def derivative_contacts(phase):
    z=sp.Matrix(sp.symbols("z0:2",real=True))
    g=sp.Matrix(sp.symbols("s0:2",real=True))
    a,b,c=sp.symbols("h00 h01 h11",real=True)
    H=sp.Matrix([[a,b],[b,c]])
    sigma_diff=(g.T*z)[0]-(z.T*H*z)[0]/2
    at_zero=dict.fromkeys(z,0)
    if phase=="native":
        E=sp.exp(sigma_diff/2)
        first=sp.Matrix([sp.diff(E,v).subs(at_zero) for v in z])
        second=sp.hessian(E,list(z)).subs(at_zero)
    else:
        E=1+sigma_diff/2+sigma_diff**2/8
        first=sp.Matrix([sp.diff(E,v).subs(at_zero) for v in z])
        second=sp.hessian(E,list(z)).subs(at_zero)
    assert all(sp.simplify(v)==0 for v in first-g/2)
    assert all(sp.simplify(v)==0 for v in second-(g*g.T/4-H/2))
    t=sp.symbols("t")
    sigma=sp.Function("sigma")(t)
    B,C,ant=(sp.Function(x)(t) for x in ("B","C","ant"))
    whole=sp.exp(sigma/2)*B*C*ant
    direct=sigma*sp.diff(whole,t)
    by_parts=sp.diff(sigma*whole,t)-sp.diff(sigma,t)*whole
    assert sp.simplify(direct-by_parts)==0
    assert all(sp.diff(t**3,t,n).subs(t,0)==0 for n in range(3))
    return {"first_endpoint_jet":"d_sigma/2","second_endpoint_jet":"d_sigma*d_sigma/4-dd_sigma/2",
            "ordinary_divergence":"-d_sigma*exp(sigma/2)*B*C*a",
            "last_contact_sensitive_pure_gauge_count":2}


def check(phase):
    d=ROOT/"calculations"
    v=json.loads((d/"canonical_so10_exact_gauge_ports_v1/result.json").read_bytes())["checks"]
    assert v["columns"]["original_endpoint_difference_vanishes_at_coincidence"]
    row=json.loads((d/"canonical_so10_ghost_two_color_transition_v2/result.json").read_bytes())["checks"]
    assert row["literal"]["divergence_triplets"]==44
    return {"profiles":profiles(phase),"contacts":derivative_contacts(phase),
            "retained_divergence_triplets":row["literal"]["divergence_triplets"]}


if __name__=="__main__":
    run_worker(check,sys.argv[1])
