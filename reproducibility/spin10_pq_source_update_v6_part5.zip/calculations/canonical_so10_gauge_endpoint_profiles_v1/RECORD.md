# V913 pre-execution contract

Fold the exact V912 pure-gradient mixed endpoint factors
into the actual selected ordinary vertices. Bind the
V896/V898 census and all derivative placements. Require
the unchanged collapsed constants, inherited proper
extension, kinetic contact-jet test and exact bridge and
exterior sewing. Keep the quadratic switches and the
remaining W-dependent mixed corrections distinct.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. Exact control replay and staged receipt.
