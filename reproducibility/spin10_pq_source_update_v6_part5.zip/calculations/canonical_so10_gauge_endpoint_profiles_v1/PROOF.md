# Pure-gradient gauge endpoints in the selected causal loop group

Use the V912 decomposition of the original mixed port,
the V911 exact internal scalar and ghost inverses, the
V908 bridge, both exterior roots, and the same V903 real
compact profile pair. Keep the two V898 color projections,
g^4 and two explicit xi powers. The V896/V898 literal
census applies to color-diagonal switching. DMM and FFMM
require both B endpoints to connect to the two Lambda
endpoints of M. FMY and the kinetic Bxx−M loop each
require one such mixed edge. YY and the Y tadpole have
none. Pairing the two Lambda endpoints in this budget
would not yield the scalar cycle with the required B
ports. The actual nonzero V912 auxiliary block therefore
has no occurrence in this selected group.

## Move the factors to the actual ordinary vertices

Retain only the pure-gradient part of each original
mixed line. On a B endpoint it supplies exp(sigma/2)
and on a Lambda endpoint exp(−sigma/2). These are
smooth multiplication factors. In rescaled coordinates
with switch chi, their effect is exactly to replace
the indicated ordinary compact profile by:

    DMM:  D:chi exp(chi), each M:chi exp(−chi/2).
    FMY:  F:chi exp(chi/2), M:chi exp(−chi/2), Y:chi.
    FFMM: each F:chi exp(chi/2), each M:chi exp(−chi/2).
    Kinetic: Bxx:chi exp(chi/2), M:chi exp(−chi/2),
             then the separate bridge vertex Y:chi.
    YY and Y feedback: unchanged.

The ordinary F representative differentiates the
antighost and not the B endpoint. The extra color-17
triplet is the derivative of the whole B C a product.
With the B endpoint reweighted, integration by parts
of the whole divergence gives the original switch
derivative times exp(sigma/2), with no second derivative
term of the form sigma d exp(sigma/2) from that vertex.
Keep its ordinary F partner and all inherited signs.
The Bxx derivative acts on a scalar. If it is on
the scalar port left open for the bridge, its Euler
adjoint differentiates the full weighted ordinary
coefficient, including the exponential when appropriate.
Those terms carry a physical switch derivative.
Do not modify the profiles of the quadratic scalar
or ghost switches, or of either exact external root.
Those continue to use the original chi.

For an ordinary vertex there is no change in the
underlying tensor, derivative placement or color.
Every new ordinary label is a fixed compact smooth
function of the rescaled coordinates. The V904, V907,
V910 and V911 transfer estimates use only such labels'
Schwartz seminorms and their small-scale support.
They do not require identical Fourier profiles at
different ordinary vertices. The contour estimates,
finite and exact-tail decompositions and massive bridge
source argument therefore apply to these reweighted
labels with the original quadratic inverses. The
same remains true for the smooth derivative label at
the color-17 divergence, which has its extra physical
scale.

## Constants and the original UV extensions

At a common vertex position each mixed edge has equal
and opposite exponents. Thus the collapsed profiles
are chi³ for DMM and FMY, chi⁴ for FFMM, chi³ for the
kinetic feedback including its root, and chi² for YY.
The separate divergence label still has a switch
derivative. At the source origin these products
are also the same as before, since chi=1 there.
The original zero-transfer constants therefore have
the same profile polynomials and the nonconstant
ordinary boundary has the same source limit.
No new normalization is selected.

For clarity the graphwise UV issue is local on the
core, and is not settled by evaluating the raw heat
clock of a reweighted line. In a proper loop the
largest original superficial divergence is
logarithmic. The full product of pure endpoint
factors equals one on the full cycle diagonal.
Its difference vanishes there to first order,
so the logarithmic contact is unchanged and the
pure difference is below the core diagonal scaling
degree. All proper subcollisions are open trees
by COS1. Positive internal simple-pole counts
already improve the core. Thus the pure part has
the inherited proper extension and no new local
freedom.

The kinetic core can have degree two, so multiplying
by the pure endpoint factor does change derivative
contacts. Hold the B vertex x fixed, use z=x−y,
and put E=exp((sigma(x)−sigma(y))/2). The actual jets
at z=0 are E=1, E_mu=sigma_mu/2 and
E_mu,nu=sigma_mu sigma_nu/4−sigma_mu,nu/2.
Consequently multiplication by E leaves delta
unchanged, gives E partial_mu delta=
partial_mu delta−E_mu(0)delta, and gives

    E partial_mu partial_nu delta
       = partial_mu partial_nu delta
          −E_mu(0) partial_nu delta
          −E_nu(0) partial_mu delta
          +E_mu,nu(0) delta.

Include the ordinary switched factors before the
full Euler adjoint. Every changed contact contains
a switch jet. At pure gauge order n the factor
(sigma(x)−sigma(y))^n vanishes to order n, so only
n=1 or 2 can affect these degree-two local
extensions. The actual switched quadratic
insertion in the literal action has a switch
derivative, so finite local terms from comparison
with the original separately converted words also
contain switch jets. The same superficial-degree
argument leaves only finitely many UV-sensitive
orders when simple-pole quadratic switches are
present. Retain the prescribed T_kappa core and
whole D_t B_t forest on each of these orders.
This argument does not equate different raw
heat clocks or drop finite local terms. It
bounds the entire local difference allowed by
the original fixed conversion on these labels.

For the ordinary normalized kinetic source
the small-transfer analytic one-mass kernel of
V907 gives the same collapsed source and a
difference O(R^-1) in every fixed rescaled
compact C^k norm. This follows by its first
Taylor bound and the rapid profile transforms,
including the changes to differentiated labels.
The local derivative contacts above have the
same or better estimate. The exact V908 bridge
retains that order, and V911's compact
test estimate for the exact exterior product
costs at most one logarithm. Thus neither the
kinetic reweighting nor its jet contacts
changes the limit.

The pure-gradient endpoint sector therefore
leaves the V911 selected nonzero two-color
profile difference intact at distinct
positive reference masses. All remaining
gauge corrections to this selected group
contain at least one W-dependent mixed
remainder from V912. Their loop estimates
are separate from this reweighting result.
