# Pure-gradient gauge endpoint reweighting V913

The original pure-gradient mixed line moves its two opposite
exponential weights into the ordinary vertices of every selected
graph. The collapsed ordinary profile powers and the two-color
transition term are unchanged. The color-17 total derivative
retains its original switch derivative. The internal quadratic
scalar and ghost profiles, exterior roots and bridge are kept.

Proper logarithmic contacts are unchanged. In the kinetic
one-port the changed delta-derivative contacts carry switch
jets, and their original normalized core is sewn to the whole
massive bridge. These changes vanish with the exact exterior
pair. The pure endpoint sector therefore preserves the V911
causal profile difference.

The selected graph census contains mixed gauge ports and no
auxiliary–auxiliary line. Its remaining gauge corrections
contain W. Exact replay checks endpoint charges, derivative
contacts and the actual divergence inventory.
