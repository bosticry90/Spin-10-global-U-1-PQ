"""Check the convergent loop and normalized tadpole bounds."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def read(owner, name):
    return json.loads((ROOT/"calculations"/("canonical_so10_"+owner)/name).read_bytes())


def graph_degrees(role):
    census = read("internal_gauge_switch_v1","result.json")["checks"]
    assert census["literal"]["diagonal_D_rows"] == 0
    assert census["literal"]["Sigma_Y_external_rows"] == 16
    assert census["budget"]["allowed_proper_cubic_pairs"] == [
        [["F","F"],2],[["F","Y"],1],[["Y","Y"],0]]
    source = ROOT/"calculations"/"canonical_so10_unprobed_compact_all_coupling_v1"/(role+"_full_current.json.gz")
    with gzip.open(source,"rt",encoding="utf-8") as stream:
        rows = json.load(stream)["current"]["complete_S_GF_source"]
    ports = {"C12":0,"a12":0}
    for grade,word,_ in rows:
        if grade != 1 or len(word) != 3:
            continue
        (B,jB),(C,jC),(a,ja) = word
        if 48 <= B < 180 and 553 <= C < 598 and 598 <= a < 643 and (C == 565 or a == 610):
            assert not jB and not jC and ja == [B%4]
            if C == 565:
                ports["C12"] += 1
            if a == 610:
                ports["a12"] += 1
    assert ports == {"C12":224,"a12":224}
    exponents = {"YY":[2,2],"FMY":[3,3,2],"FFMM":[3,3,3,2],
                 "Y_tadpole":[2],"kinetic_tadpole":[3,3]}
    excess = {name:sum(values)-4*(len(values)-1) for name,values in exponents.items()}
    assert excess == {"YY":0,"FMY":0,"FFMM":-1,"Y_tadpole":2,"kinetic_tadpole":2}
    assert all(excess[name]-1 < 0 for name in ("YY","FMY","FFMM"))
    kinetic_low = [(a,b) for a in range(4) for b in range(3)
                   if a+b and excess["kinetic_tadpole"]-a-2*b >= 0]
    assert kinetic_low == [(0,1),(1,0),(2,0)]
    assert [a for a in range(1,4) if excess["Y_tadpole"]-2*a >= 0] == [1]
    return {"actual_F_derivative_ports":ports,"bare_UV_excess":excess,"kinetic_UV_sensitive_gauge_scalar_counts":
            [list(pair) for pair in kinetic_low],"ghost_UV_sensitive_counts":[1]}


def relative_tail(role):
    # Riesz convolution in four dimensions from two independent routes.
    if role == "native":
        u = sp.Symbol("u",positive=True)
        conv = sp.pi**2/sp.gamma(sp.Rational(3,2))**2*sp.integrate(1/sp.sqrt(u*(1-u)),(u,0,1))
    else:
        def transform(alpha):
            return 2**(4-alpha)*sp.pi**2*sp.gamma((4-alpha)/2)/sp.gamma(alpha/2)
        conv = transform(sp.S(3))**2/transform(sp.S(2))
    assert sp.simplify(conv-4*sp.pi**2) == 0
    r,T = sp.symbols("r T",positive=True)
    tail = sp.integrate(2*sp.pi**2*r**3*conv/r**5,(r,T,sp.oo))
    assert sp.simplify(tail-8*sp.pi**4/T) == 0
    return {"Riesz_convolution_prefactor":"4*pi^2","collapsed_FFMM_tail_prefactor":"8*pi^4/T"}


def coincident_control():
    r,R,k = sp.symbols("r R k",positive=True)
    W = sp.Function("W")
    ell = sp.Symbol("ell",positive=True)
    ghost = k*k*R**4*W(R*k)*sp.log(k*k)
    scaled = ghost.subs(k,ell/R)/R**4
    assert sp.simplify(scaled-ell**2*W(ell)*(sp.log(ell**2)-2*sp.log(R))/R**2) == 0
    mixed = sp.integrate((1+sp.log(R/r)),(r,0,1))
    assert sp.simplify(mixed-2-sp.log(R)) == 0
    owner = read("ghost_exterior_switch_sum_v1","result.json")["checks"]["radial"]
    assert owner["green_lower_ratio"] == "exp((1-chi(r))/2)"
    return {"ghost_first_tadpole_bound":"R^-2*(1+log R)",
            "kinetic_mixed_remainder_bound":"R^-3*(2+log R)",
            "exterior_center_cost":"1+log R"}


def checks(role):
    return {"graphs":graph_degrees(role),"relative":relative_tail(role),"coincident":coincident_control()}


if __name__ == "__main__":
    run_worker(checks,sys.argv[1])
