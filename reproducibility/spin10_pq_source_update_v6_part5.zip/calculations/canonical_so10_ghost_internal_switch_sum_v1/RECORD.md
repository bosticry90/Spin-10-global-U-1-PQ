# V897 pre-execution contract

Decide whether the full internal quadratic switch sum cancels
the V895 transition term in the selected Euclidean ghost
coefficient. Keep the V896 color-12 census at one loop, g^4,
two explicit xi factors, zero mass difference, A and retained
sources zero. Fix a wide monotone compact radial shape before
dilation, bounded widths, and positive scalar reference
masses. Use the common UV finite parts coefficient by
coefficient before summing, with regulated rooted subtractions.

Require kernel estimates on the rescaled vertex set, local
convergence of the high-count inverse tail, relative UV and
far margins of the proper differences, and the complete
finite list of coincident tadpole subtractions. Test the
actual derivative ports, Riesz convolution, exceptional UV
counts and scale estimates. Keep inherited normalization
and V883 paired-rate control. Causal weak boundaries remain
a separate problem.

Native 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor,
8 MiB artifact, 32 MiB packet. Freeze proof and owner
bytes. Require replay and exact staged bytes.
