# Internal switching sum in the selected Euclidean ghost group

Use the actual V896 color-12 graph census at one loop,
g^4 with two explicit xi powers, zero A, retained sources
and scalar mass-difference degree. Use the same continuum
UV conversion and literal V879 density as V894. The
admissible radial monotone switches are the broad
logarithmic plateau profiles of V895–V896. For each
fixed profile let R tend to infinity. Widths range in
a fixed bounded real set for which the energy Neumann
bound holds. The exterior ghosts are summed as in V895.
This calculation sums the internal quadratic switches
as well. It uses the sum of the separately converted
coefficients.

## Kernel estimates on the rescaled compact set

All ordinary interaction vertices have a factor sigma_R
or a derivative of it. Their rescaled positions belong
to one fixed compact set K. Uniform bounds for both
endpoints in K suffice. The external ordinary sources
remain unswitched.

For the gauge system put E=diag(|D|,1) on (B,Lambda)
and use the bounded normalized free symbol and inverse
from V896. On the rescaled coordinates, the normalized
switch operator E^-1 Q E^-1 lowers high-frequency
order by one. The Maxwell switch is first order in B
and the off-diagonal switch is multiplication. All their
coefficients are smooth compact. The massless ghost
switch in |D| variables lowers order by two. For both
systems the normalized Neumann operator and its adjoint
map H^s to H^(s+1) for integer s≥0 (two gains in the
ghost case). At low frequency, |D|^-1 on an arbitrary
H^s input is locally controlled by Cauchy–Schwarz
since |q|^-2 is integrable there in four dimensions.
When |D|^-1 acts on a compact supported factor its
low-frequency output is also globally L², using the
L¹ bound on the input. At high frequency the orders
follow by the product rule, Riesz multiplier bounds
and compact coefficient multiplication.

Here is the needed kernel use of that calculus.
In a finite Neumann product cut the free multipliers at
|q|=1. Low-frequency kernels are smooth locally.
For high frequencies, composition with a smooth
compact multiplier preserves the symbol order by
Taylor expansion in its Schwartz Fourier transfer.
Localization on K removes smooth off-diagonal
remainders. A dyadic Fourier piece of order −d
has kernel bound C_N 2^((4−d)j)(1+2^j|x−y|)^−N
by integration by parts. The sum gives |x−y|^(d−4)
for d<4, a logarithm for d=4, and boundedness for
d>4. Each spatial derivative lowers d by one.
For the high-count tail factor off a fixed number
m of Neumann factors on each wing. In normalized
variables the middle norm is bounded by nu^(n−2m)
for some nu<1. Each wing, with its endpoint E^-1
and the corresponding adjoint, maps L² to C^k on K
when m is sufficiently large. Evaluation and its
derivatives are then bounded functionals on L².
The tail converges in C^k of the kernel on K×K.
This gives uniform bounds for partial sums and the
same singular orders for the exact inverse. The
argument uses bounded real widths, including zero.
It does not divide by a width.
[Elliptic symbol calculus](https://www.mathunion.org/fileadmin/ICM/Proceedings/ICM1970.1/ICM1970.1.ocr.pdf)

For the mixed B,Lambda block the bare order is −1,
and each extra gauge switch lowers it by one. For
the ghost the bare order is −2 and each extra
switch lowers it by two. Rescale back with the
endpoint weights. Writing r=|x−y|, for x/R,y/R
in K the full mixed difference is bounded by
C R^-1 r^-2 and the full ghost difference by
C R^-2(1+|log(r/R)|). One derivative raises the
inverse distance power by one. Both differences
are bounded by a constant times the corresponding
bare power on this compact rescaled set. For the
massive scalar use K_M,R=−Delta+M+V_R, where
V_R=(Delta sigma_R)/2=O(R^-2). For large R its
potential is at least M/2. Positivity of the scalar
resolvent gives 0≤G_M,R≤G_M/2. The resolvent identity
bounds the difference by C R^-2 G_M/2*G_M/2, and
its derivative by the same convolution with a
differentiated massive free factor. These decay
exponentially at large separation and improve the
bare short-distance powers by two, with the
four-dimensional logarithm at order −4.

The exterior solutions satisfy
|u_R(x)|≤C(1+|x|)^-2 and the same weaker bound
for their first derivatives. Indeed the free source
has this bound, and V895 writes the correction as
the free inverse of R^-4 times a uniformly smooth
compact function of x/R supported away from zero.
Its value and derivative on the rescaled compact
region are O(R^-2) and O(R^-3), and convolution
outside that region gives the free-power decay.
Consequently the product of two roots integrated
over the compact center costs O(1+log R), by
Cauchy–Schwarz, uniformly in the relative
translation. This includes a derivative on an
external antighost.

## Proper loop differences

Compare each surviving proper graph with its
bare internal edges and the same switched vertices
and exterior roots. Telescope the edge product.
The position singularity orders for the ordinary
massive link, mixed link, and ghost link are
respectively 2,3,2. A ghost derivative raises
its order to 3. The actual numerator assignment
places at most one derivative on an internal
ghost in these cycles. The YY bubble has total
order 4 in four relative dimensions. FMY has
at most 8 in eight. FFMM has at most 11 in twelve.
The color-12 DMM term is absent by V896.
Every proper partial diagonal has just simple
tree-edge powers below four. At the total
diagonal at least one improved internal edge
makes the difference integrable. There is
therefore no remaining proper UV subtraction
for a switched-edge difference. In momentum
the same statement follows from the maximal
q^-4 bare degree and at least one extra
inverse power from an internal switch.

The relative integrals are also uniformly
integrable at large separations. YY has a
massive tie. For FMY, collapsing the massive
relative coordinate leaves a pair with decay
at least r^-5. In FFMM it leaves the convolution
of three r^-3 factors in eight dimensions.
Integrate one variable using the convolution
of two r^-3 factors, proportional to r^-2,
to get an O(T^-1) tail beyond distance T.
The massive relative coordinate is integrated
with its exponential tail. To apply that
convolution at a nonzero massive separation,
split that separation at half the large relative
distance. The farther part is exponentially
small and the local singularities have the
same independent relative-coordinate bounds.
Thus after the short-distance subtraction
or integrable improvement there is a power
tail in each graph. On distances between one
and sqrt(R) the difference kernel has a
positive R gain from the bounds above. At the
short total diagonal keep the improved
inverse power explicitly. Beyond sqrt(R) use
the power tail. Together these bounds beat
the logarithmic exterior cost. They also
bound the partial Neumann sums, so passage
to the exact internal edge kernels preserves
the separately converted proper series.

## The finite set of tadpole subtractions

For the Y ghost tadpole the free converted
one-edge value is zero. The first ghost
switch is a massless two-propagator logarithm
times (Delta sigma_R)/2, with the original
ordered coefficient. Its already converted
Fourier multiplier is a log of the switch
momentum squared plus a local constant.
Integrating against the scaled compact switch
gives O(R^-2(1+log R)) uniformly in position.
The remaining exact ghost tail has order
at most −6 at the rescaled diagonal, so its
coincident value is bounded by C R^-2.
This uses the original finite one-switch
normalization and the unchanged higher terms.

In the kinetic Bxx–M tadpole, the most
singular product is mixed r^-3 times a
differentiated scalar r^-3 in four relative
dimensions. The first two mixed gauge
switch counts and the first scalar switch
can require a local subtraction. Use their
actual fixed-count common T_kappa extension,
with the entire regulated massive root and
source forest in D_t B_t. Each resulting
local polynomial has a switch jet. The
mixed remainder after two insertions has
order at most −4, so its rescaled product
with the massive derivative is integrable
and bounded by O(R^-3(1+log R)). The scalar
remainder after one insertion contains
two O(R^-2) potentials and three massive
inverses. Even with a first derivative its
coincident convolution against the mixed
edge is integrable and O(R^-4).
Products of a gauge and a scalar difference
are integrable from their combined gain
of three inverse powers. If the derivative
instead acts on the external scalar port,
the tadpole has a lower singularity and
the differentiated massive root has
uniform L¹ norm. Differentiating the
massive resolvent identity on the
left free edge bounds the difference
of these derivative bridge kernels
in L¹ by O(R^-2).

For clarity the finite normalized tadpole
terms needing local subtraction tend to
zero in the same uniform norm. They
contain a finite number N of independent
switch transfers, with no fixed ordinary
external loop momentum. Put lambda=1/R
and first restrict all transfers to
rho=lambda^beta, with beta<1 close to one.
In the region of loop momentum O(rho)
rescale it and the transfers by rho.
Loop-edge momenta are independent after
using the transfer at each vertex and
solving for the scalar root momentum.
Individual massless poles have order at
most two. The inserted gauge switches
preserve the mixed chain's total soft
order one, while a scalar switch
improves it. Using the weaker total
order two still yields a positive
power rho². Bounding the rescaled
switch weights by (rho/lambda)^(4N)
preserves a positive power by taking
beta sufficiently close to one.
Away from that region, each gauge
switch contributes rho/|q| on a
massless chain or a scalar potential
contributes rho² on a massive line.
On bounded loop momenta this gives a
vanishing bound. On large momenta the
fixed common Taylor subtraction leaves
an integrable remainder with the
explicit switch jet, and its finite
local terms have the same gain.
For the omitted transfer tails, cover
dyadic shells by rescaled independent
edge coordinates. The locally
integrable rational denominators and
the fixed UV subtractions have
polynomial bounds for these integrated
shells. The Schwartz switch weights
beat every such bound. All estimates
are absolute after subtraction, so
the Fourier phases have modulus one
and the resulting bound is uniform
in the center coordinate. This is
the required positive power for the
finite kinetic tadpole exceptions.

A switch confined to the massive
bridge leaves the loop's divergence
intact. At each such word first apply
D_t B_t with that exact regulated
bridge, including the derivative
when present. The normalized core
is then paired with the continuum
bridge. For a local subtraction with
two derivatives on the external scalar,
use the inherited action Ward identity
to put those derivatives on the compact
coefficient before sewing. This keeps
the contact and avoids claiming an
absolute L¹ bound for a twice
differentiated bridge. The massive feedback bridge
has uniform L¹ norm, and replacing its
bare version by its switched one
costs O(R^-2) in that norm. The
bare normalized one-port kernels
against the ordinary switches
remain uniformly bounded, by their
massive transfer and the same
finite-part normalization. Thus all
internal-switch changes of the
feedback vanish after multiplication
by the at most logarithmic exterior
pair. No subtraction of the finite
V883 paired regulator artifact is
inferred from a separate limit of
one of its raw cutoffs.

## Consequence for the selected weak limit

V896 gives exactly these proper and
one-port classes even when the
auxiliary inverse reopens. The
bounds above permit the complete
internal quadratic sum in this
Euclidean coefficient. Its change
relative to the V895 group tends
to zero. Hence the full selected
switched Euclidean coefficient has
the V883 uncut part plus the nonzero
V895 profile term for generic
inherited m_12 and the two sources.
The term remains dependent on the
radial transition shape. In the
special normalization m_12=0 this
color test is blind. A comparison to
a Lorentzian causal weak limit needs
a separate boundary construction
for the switches and the kernel
products. No Euclidean cutoff is
Wick rotated. The scope is the
specified color, coefficient,
reference and broad Euclidean
profile class. The checks share
the action, reference, software
and AI authorship.
