from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/ghost-source-companion-catalog-g1-v1-2026-11-07')
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z);return z
cat=module('final_new_catalog',O/'catalog.py');m=module('final_JB_master',O/'master.py');J=m.J;w=m.w
read=m.read;load=m.load;digest=m.digest

def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def check_path(classes,target,case,row,mode='actual',omit=False):
 root,ro,path=row;ids=[root]+[i for i,o in path];assert classes[root]['kind']=='marked' and ro in [0,1] and len(ids)<=5
 assert sum(classes[i]['g'] for i in ids)==1 and sum(classes[i]['u'] for i in ids)==case['u'] and [sum(classes[i]['external'][k] for i in ids) for k in range(4)]==list(target)
 probe=case['probe']
 for i in ids:
  z=classes[i];assert sum(z['external'])+z['g']+z['u']>=1
  if probe is None:assert 'probe' not in z['owner'] and 'Fu' not in z['owner']
  else:assert z['owner'] not in ['GF_probe'+str(1-probe),'R_Fu0_'+str(1-probe),'R_Fu1_'+str(1-probe)]
 cur=classes[root]['quantum'][1-ro];start=classes[root]['quantum'][ro]
 for i,o in path:
  z=classes[i];assert z['kind']=='ordinary' and o in [0,1]
  if omit:assert not(z['u'] and not any(z['external']))
  assert cat.v.edge(cur,z['quantum'][o],mode);cur=z['quantum'][1-o]
 assert cat.v.edge(cur,start,mode)

def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','master_preparation.json','master_v2_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps={};seconds={}
 for cf,rf,bound in [('native_capture.json','native_result.json',180),('replay_capture.json','replay_result.json',180),('source_grade_capture.json','source_grade_result.json',60),('replay_master_v2_capture.json','replay_master_v2_result.json',180)]:
  cap=read(O/cf);res=read(O/rf);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<s['private_bytes']<=8*1024**3 for s in cap['all_resource_samples']);caps[cf]=cap;seconds[cf]=res['elapsed_after_imports']
 failed=read(O/'native_master_capture.json');assert failed['exit_code']==124 and not failed['calculation_completed'] and failed['post_run_observations_qualified'] and failed['execution_state']=='FAILED'
 assert failed['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<s['private_bytes']<=8*1024**3 for s in failed['all_resource_samples'])
 prepfailed=read(O/'master_preparation_failure.json');assert prepfailed['classification']=='FAILED_PREPARATION_BEFORE_WORKER' and not prepfailed['monitored_capture'] and prepfailed['exit_code']==1
 packet=load(O/'native_inputs.json.gz');replay=load(O/'replay_inputs.json.gz');assert len(packet['roots'])==len(replay['roots'])==12 and len(packet['ordinary'])==len(replay['ordinary'])==8
 for a,b in zip(packet['roots'],replay['roots']):assert all(a[k]==b[k] for k in ['state','family','g','u','raw_root'])
 assert packet['ordinary']==replay['ordinary'];del replay;gc.collect()
 counts=[];path_count=0
 for ch,target in cat.TARGETS.items():
  np=O/('native_'+ch+'_catalog.json.gz');rp=O/('replay_'+ch+'_catalog.json.gz');assert np.read_bytes()==rp.read_bytes();z=load(np);sigs=set()
  for raw,saved in zip(packet['roots'],z['roots']):
   actual,ss=cat.project_root(raw,target);assert actual==saved;sigs.update(ss)
  for raw,saved in zip(packet['ordinary'],z['ordinary']):
   actual,ss=cat.project_ordinary(raw,target);assert actual==saved;sigs.update(ss)
  classes=[dict(id=i,owner=a,kind=b,g=g,u=u,quantum=list(q),external=list(e)) for i,(a,b,g,u,q,e) in enumerate(sorted(sigs))];assert classes==z['classes'] and z['total_vertex_bound']==5
  for case in z['cases']:
   assert case['scalar_reduced_cycles']==[]
   for row in case['complete_cycles']:check_path(classes,target,case,row);path_count+=1
   for mode,rows in case['wrong'].items():
    edge_mode={'wrong_HM':'mix_HM','wrong_LL':'LL','wrong_unrestricted':'unrestricted'}[mode]
    for row in rows:check_path(classes,target,case,row,edge_mode)
   for row in case['omit_inverse_U']:check_path(classes,target,case,row,omit=True)
   expected=[row for row in case['complete_cycles'] if not any(classes[i]['u'] and not any(classes[i]['external']) for i,o in row[2])];assert expected==case['omit_inverse_U']
  counts.append([ch,*[len(case['complete_cycles']) for case in z['cases']]])
  del z;gc.collect()
 assert counts==[['aCC',4,0,112],['JBCC',0,0,4],['JLambdaCC',0,0,0]]
 print('STAGE all_raw_new_catalog_projections_pairs_paths_controls_and_bounds_verified',flush=True)
 # Fresh source-grade validation before accepting its smaller proof.
 old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(old/'native_inputs.json.gz');pr=load(old/'replay_inputs.json.gz');assert pn==pr;del pr
 states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()}
 sg=load(O/'source_grade_tables.json.gz');sr=read(O/'source_grade_result.json');assert digest(O/'source_grade_tables.json.gz')==sr['artifact']['sha256'] and sr['M_gu1_normal_terms']==0 and sr['all_JB_bearing_pairs_have_complete_zero_partners']
 for saved,raw in zip(sg['ordinary_audits'][0]['blocks'],packet['ordinary']):
  ids=[i for i,(ww,cc) in enumerate(raw['quadratic_Taylor_half']) if any(643<=n<823 for n,js in ww)];assert ids==saved['all_JB_raw_indices']
  if ids:assert raw['g']==1
 for row in sg['all_four_branch_643_port_dispositions']:
  P=states[row['left']][row['field']];Q=states[row['right']][row['field']];lp=sum(any(643<=n<823 for n,js in ww) for ww in P);rp=sum(any(643<=n<823 for n,js in ww) for ww in Q)
  assert lp==row['left_JB_terms'] and rp==row['right_JB_terms'] and m.mh(P)==row['left_math_sha256'] and m.mh(Q)==row['right_math_sha256']
  if lp or rp:assert not P or not Q
 assert len(sg['all_four_branch_643_port_dispositions'])==2572 and sg['actual_M_gu1_source_JB_classical_density']==sg['selected_T2_master']==sg['normal']==[]
 del packet,sg;gc.collect()
 rr=read(O/'replay_master_v2_result.json');f=load(O/'replay_master_v2_factors.json.gz');cache={}
 for row in f['factors']:
  P=states[row['state']][row['field']];degree=row['degree'];assert m.mh(P)==row['original_math_sha256'] and len(P)==row['original_terms']
  if degree:
   elig,ej=m.eligible(P,degree);assert ej==row['eligibility'];raw=elig
   for k in range(degree):raw=m.v.tangent(raw)
   if degree==2:raw=w.scale(raw,J.constant(F(1,2)))
   assert J.encode(raw)==row['full_Taylor_of_eligible']
  else:raw=P
  selected,pj=m.project(raw,degree);assert J.encode(selected)==row['selected'] and pj==row['projection'];cache[row['state'],row['field'],degree]=selected
 print('STAGE full_classical_source_grade_and_LEFT_vs_prefix_Taylor_factors_verified',flush=True)
 pairs=[]
 for row in rr['cases']:
  name=row['case'];a=load(O/('native_master_'+name+'.json.gz'));b=load(O/row['artifact']['file']);assert digest(O/row['artifact']['file'])==row['artifact']['sha256']
  for key in ['case','operators','full_residual','currents','normal','pivot_counts','all_branch_port_product_dispositions','exact_density_reconstruction']:assert a[key]==b[key],(name,key)
  assert 'STAGE ' in failed['stdout_and_stderr'] and '"case": "'+name+'"' in failed['stdout_and_stderr']
  ops={k:{} for k in ['KQ','KD','KC']};assert len(b['all_branch_port_product_dispositions'])==3*643*len(b['case']['branches'])
  for kind,left,right,n,status,product in b['all_branch_port_product_dispositions']:
   ld,rd={'KQ':(0,2),'KD':(2,0),'KC':(1,1)}[kind];lp=cache[left,n,ld]
   if status=='ZERO_SAFE_LEFT':assert not lp;continue
   rp=cache[right,n,rd]
   if status=='ZERO_SAFE_RIGHT':assert not rp;continue
   raw=J.mul(lp,rp);selected,pj=m.project(raw,2,True);assert J.encode(raw)==product['raw'] and pj==product['projection'];J.add(ops[kind],selected)
  ops={k:J.clean(p) for k,p in ops.items()};assert {k:J.encode(p) for k,p in ops.items()}==b['operators'];res=w.plus(*ops.values());cur,norm,pivots=m.normal_form(res)
  assert J.encode(res)==b['full_residual'] and [J.encode(p) for p in cur]==b['currents'] and J.encode(norm)==b['normal']==[] and pivots==b['pivot_counts']
  for control in b['controls']:
   omit={'omit_Dsource':'KD','omit_current':'KC'}[control['control']];bad=w.plus(*(p for k,p in ops.items() if k!=omit));cc,nn,pp=m.normal_form(bad)
   assert J.encode(bad)==control['residual'] and [J.encode(p) for p in cc]==control['currents'] and J.encode(nn)==control['normal'] and len(nn)==control['normal_terms'] and pp==control['pivots']
  pairs.append(dict(case=name,native='native_master_'+name+'.json.gz',replay=row['artifact']['file'],operators_sha256=sha256(json.dumps(b['operators'],sort_keys=True).encode()).hexdigest(),fresh_replay_and_final_factor_product_IBP_checks=True,native_parent_remains='FAILED_TIMEOUT_INCOMPLETE'))
  print('STAGE validated_completed_native_case_and_independent_replay '+name,flush=True);del a,b,res,cur,norm,ops;gc.collect()
 assert len(pairs)==5
 # Actual physical premises, and completed old witnesses restricted only.
 for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[label][n] for n in range(508))
 for label in ['F0','F1']:
  for n in range(508):assert all(all(i<643 for i,js in ww) and sum(553<=i<598 for i,js in ww)<=1 for ww in states[label][n])
 for n,raw in pn['physical']['P_E0']:assert all(len(ww)<=1 and all(i<508 for i,js in ww) for ww in J.decode(raw))
 for label in ['P_E1_gauge','P_E1_scalar']:
  for n,raw in pn['physical'][label]:assert n<180 and all(len(ww)<=2 and all(i<508 for i,js in ww) for ww in J.decode(raw))
 owning=read(old/'collect_result.json');witness=[r for r in owning['artifacts'] if '_source_physical_' in r['file']];assert len(witness)==6;physical=[]
 for row in witness:
  assert digest(old/row['file'])==row['sha256'] and row['case_calculation_completed_and_reconstruction_checked'];z=load(old/row['file']);assert z['normal_form']==[] and z['exact_full_reconstruction']
  P,pj=m.project(J.decode(z['raw_residual']),2);curr=[];div={}
  for mu,raw in enumerate(z['boundary_currents']):
   q,qj=m.project(J.decode(raw),2);curr.append(J.encode(q));J.add(div,J.D(q,mu))
  assert J.clean(div)==P
  physical.append(dict(case=z['case'],source=row['file'],source_sha256=row['sha256'],restricted_residual=J.encode(P),restricted_currents=curr,projection=pj,exact_reconstruction=True))
 pa=save('physical_witness_restrictions.json.gz',dict(witnesses=physical,actual_support_premises_checked=True,source_free_g1_terms_excluded_at_final_JBCC_target_by_ordinary_g_grade=True,no_unknown_physical_E1_x_set_zero=True))
 dump(O/'master_pairs_verified.json',dict(pairs=pairs,physical_witnesses=pa,source_grade_artifact=sr['artifact'],scientific_acceptance='NOT_PERFORMED',full_V1_native_parent='FAILED_TIMEOUT_INCOMPLETE'))
 print('STAGE target_complete_JBCC_master_source_grade_physical_witnesses_and_failures_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 oldtree=(C/'old_git_tree.txt').read_bytes();assert oldtree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V808.md'];size=sum(p.stat().st_size for p in files);assert size<=128*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='GHOST_SOURCE_CATALOGS_AND_JBCC_TARGET_MASTER_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_FULL_CATALOGS_AND_TARGET_COMPLETE_JBCC_MASTER_WITH_EXHAUSTED_PARENT_PRESERVED',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,all3_catalog_pairs_byte_equal=True,catalog_counts=counts,actual_paths_verified=path_count,raw_root_and_full_ordinary_projections_recomputed=True,completed_native_master_cases_independently_replayed_and_verified=5,source_grade_all2572_rows_checked=True,physical_witness_restrictions=6,JBCC_finite_formal_proper_reduction='QGamma=-CQ=CR in stated prescription and source/grade target scope',JBCC_original_and_H_zero_only_this_formal_finite_prescription=True,M_JBCC_four_graph_coefficients_not_computed=True,aCC_and_JLambdaCC_no_new_proper_zero_claim=True,failed_preparations=1,failed_workers=1,native_master_parent='FAILED_TIMEOUT_124_INCOMPLETE_NOTPASS',full_source_free_M_gu1_upper_kernel_still_uncomputed=True,target_coverage_completed_by_actual_source_grade_support=True,worker_seconds_after_imports=seconds,largest_successful_private_sample=max(s['private_bytes'] for cap in caps.values() for s in cap['all_resource_samples']),largest_failed_private_sample=max(s['private_bytes'] for s in failed['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(oldtree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
