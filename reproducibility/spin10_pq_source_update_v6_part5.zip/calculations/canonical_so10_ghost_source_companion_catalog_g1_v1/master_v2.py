from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
sp=importlib.util.spec_from_file_location('JB_master_derivative',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/('physical_v2.py' if ROLE=='native' else 'physical_v4.py'));v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
w=v.w;J=v.J;half=J.constant(F(1,2));one=J.constant(1)
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()

def mh(P):return sha256((json.dumps(J.encode(P),sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 assert len(blob)<=10*1024**2
 with (O/(ROLE+'_master_v2_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2
 return dict(file=ROLE+'_master_v2_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def slot(n):return 0 if 553<=n<598 else 1 if 643<=n<823 else None

def project(P,degree,intrinsic=False):
 out={};keep=[];bad=defaultdict(list)
 for at,(ww,c) in enumerate(sorted(P.items())):
  cnt=[0,0];qq=0;why=None
  for n,js in ww:
   if 1319<=n<1962:qq+=1;continue
   k=slot(n)
   if k is None:why='FORBIDDEN_MEAN';break
   cnt[k]+=1
  if not why and qq!=degree:why='WRONG_QUANTUM_DEGREE'
  if not why and (cnt[0]>2 or cnt[1]>1):why='UPPER_MEAN_BUDGET_EXCEEDED'
  if not why and intrinsic:
   d=sum(J.dimension(n-1319 if 1319<=n<1962 else n)+len(js) for n,js in ww)
   if 5-d not in [0,1]:why='INTRINSIC_OUTSIDE_01'
  if why:bad[why].append(at)
  else:out[ww]=c;keep.append(at)
 return out,dict(kept_raw_indices=keep,rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(bad.items())])

def eligible(P,degree):
 out={};keep=[];bad=defaultdict(list)
 for at,(ww,c) in enumerate(sorted(P.items())):
  fields=0;forbidden=0;C=0;JB=0;why=None
  for n,js in ww:
   assert n<1286
   if n<643:
    fields+=1
    if 553<=n<598:C+=1
    else:forbidden+=1
   elif 643<=n<823:JB+=1
   else:why='FORBIDDEN_FIXED_SOURCE';break
  if not why and JB>1:why='FIXED_SOURCE_BUDGET_EXCEEDED'
  if not why and fields<degree:why='LESS_THAN_REQUIRED_FIELD_REPLACEMENTS'
  if not why and forbidden+max(C-2,0)>degree:why='TOO_MANY_REQUIRED_REPLACEMENTS'
  if why:bad[why].append(at)
  else:out[ww]=c;keep.append(at)
 return out,dict(kept_original_indices=keep,rejected=[dict(reason=k,original_indices=ids) for k,ids in sorted(bad.items())])

def normal_form(P):
 groups={};counts=defaultdict(int);currents=[{} for _ in range(4)];normal={}
 for ww,c in P.items():
  at=[i for i,(n,js) in enumerate(ww) if 643<=n<823];kind='JB'
  if not at:
   at=[i for i,(n,js) in enumerate(ww) if 553<=n<598];kind='mean_C'
   if len(at)==2:at=[i for i,(n,js) in enumerate(ww) if 1917<=n<1962];kind='quantum_a'
   elif not at:at=[i for i,(n,js) in enumerate(ww) if 1872<=n<1917];kind='quantum_C'
  assert len(at)==1,('NO_UNIQUE_DERIVATIVE_INVARIANT_PIVOT',ww,at)
  pos=at[0];n,jets=ww[pos];sg=(-1)**(J.parity(n)*sum(J.parity(i) for i,js in ww[:pos]));counts[kind]+=1
  J.put(groups.setdefault((kind,n,jets),{}),ww[:pos]+ww[pos+1:],c*sg)
 for (kind,n,jets),rest in groups.items():
  for r,mu in enumerate(jets):
   for ww,c in rest.items():J.put(currents[mu],((n,tuple(jets[r+1:])),)+ww,c*((-1)**r))
   rest=J.D(rest,mu)
  for ww,c in rest.items():J.put(normal,((n,()),)+ww,c*((-1)**len(jets)))
 currents=[J.clean(p) for p in currents];normal=J.clean(normal);div={}
 for mu,cur in enumerate(currents):J.add(div,J.D(cur,mu))
 assert J.clean(div)==w.plus(P,w.scale(normal,-one)),'FULL_UPPER_BUDGET_IBP_RECONSTRUCTION'
 return currents,normal,dict(sorted(counts.items()))

def cases():
 out=[]
 for g in [0,1]:
  out.append(dict(case='original_g'+str(g),g=g,u=0,probe=None,branches=[('F0','E0')] if g==0 else [('F1','E0'),('F0','E1')]))
  for pr in [0,1]:out.append(dict(case='probe'+str(pr)+'_g'+str(g),g=g,u=1,probe=pr,branches=[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))] if g==0 else [('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))]))
 return out

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'master_v2_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not p.startswith(peer),'PEER_NEW_MASTER_DENIED'
   assert not any(z in p for z in ['hard_response','known_consistency_images_g1_v1','_JBCC_catalog.json.gz','assembled_GF_kernels.json.gz']),'QUANTUM_TARGET_DENIED_IN_ACTUAL_MASTER'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(base/(ROLE+'_inputs.json.gz'));states={k:dict(z) for k,z in packet['states'].items()}
 assert all(list(z)==list(range(643)) for z in states.values())
 assert all(not states[label][n] for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1'] for n in range(508))
 for n in range(508):
  for label in ['F0','F1']:
   P=J.decode(states[label][n]);assert all(all(i<643 for i,js in ww) and sum(553<=i<598 for i,js in ww)<=1 for ww in P)
 phys0=dict(packet['physical']['P_E0']);assert all(len(ww)<=1 for n,raw in phys0.items() for ww in J.decode(raw))
 cache={};factors=[];rows=[];art=[]
 def factor(label,n,degree):
  key=label,n,degree
  if key in cache:return cache[key]
  P=J.decode(states[label][n]);row=dict(state=label,field=n,degree=degree,original_terms=len(P),original_math_sha256=mh(P))
  if degree:
   elig,journal=eligible(P,degree);raw=elig
   for i in range(degree):raw=v.tangent(raw)
   if degree==2:raw=w.scale(raw,half)
   row.update(eligibility=journal,full_Taylor_of_eligible=J.encode(raw))
  else:raw=P
  selected,journal=project(raw,degree);row.update(projection=journal,selected=J.encode(selected));factors.append(row);cache[key]=selected
  return selected
 for case in cases():
  if case['case']=='probe1_g1':continue
  sums={name:{} for name in ['KQ','KD','KC']};dispositions=[]
  for left,right in case['branches']:
   for n in range(643):
    for kind,ld,rd in [('KQ',0,2),('KD',2,0),('KC',1,1)]:
     lp=factor(left,n,ld)
     if not lp:dispositions.append([kind,left,right,n,'ZERO_SAFE_LEFT',None]);continue
     rp=factor(right,n,rd)
     if not rp:dispositions.append([kind,left,right,n,'ZERO_SAFE_RIGHT',None]);continue
     raw=J.mul(lp,rp);selected,journal=project(raw,2,True);J.add(sums[kind],selected)
     dispositions.append([kind,left,right,n,'PRODUCT',dict(raw=J.encode(raw),projection=journal)])
  assert len(dispositions)==3*643*len(case['branches']);sums={k:J.clean(p) for k,p in sums.items()};residual=w.plus(*sums.values());currents,normal,pivots=normal_form(residual)
  controls=[]
  if case['case']=='original_g1':
   for cn,omit in [('omit_Dsource','KD'),('omit_current','KC')]:
    bad=w.plus(*(p for k,p in sums.items() if k!=omit));cc,nn,pp=normal_form(bad);controls.append(dict(control=cn,residual=J.encode(bad),currents=[J.encode(p) for p in cc],normal=J.encode(nn),normal_terms=len(nn),pivots=pp))
  a=save(case['case'],dict(case=case,operators={k:J.encode(p) for k,p in sums.items()},full_residual=J.encode(residual),currents=[J.encode(p) for p in currents],normal=J.encode(normal),pivot_counts=pivots,all_branch_port_product_dispositions=dispositions,controls=controls,exact_density_reconstruction=True))
  art.append(a);rows.append(dict(case=case['case'],KQ_terms=len(sums['KQ']),KD_terms=len(sums['KD']),KC_terms=len(sums['KC']),raw_residual_terms=len(residual),normal_terms=len(normal),pivots=pivots,controls=[dict(control=c['control'],normal_terms=c['normal_terms']) for c in controls],artifact=a))
  print('STAGE '+json.dumps(rows[-1],sort_keys=True),flush=True);del dispositions,sums,residual,currents,normal;gc.collect()
 art.append(save('factors',dict(factors=factors,full_classical_sources_before_Taylor_and_restriction=True,original_input_sha256=digest(base/(ROLE+'_inputs.json.gz')))))
 out=dict(schema='FIVE_COMPLETED_JBCC_MASTER_CASES_REPLAY_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,uncomputed_M_gu1_full_upper_master_NOTPASS=True,cases=rows,artifacts=art,all_normal_forms_zero=all(r['normal_terms']==0 for r in rows),all643_ports_per_branch=True,physical_restriction_support_premises_checked=True,physical_witness_restriction_must_be_verified_at_final=True,not_new_quantum_coefficient=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/(ROLE+'_master_v2_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['cases','artifacts']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
