# Missing companion catalogs recovered; JBCC coefficient is next

Full raw vertices give matching native/replay catalogs:
aCC4 original/0 H/112 M; JBCC0/0/4; JLambdaCC0/0/0. These are candidate
counts, not measured amplitudes. All source/physical/inverse responses
were retained before new projections. Omitting inverse-U loses48 of112
M aCC candidates. Exact coefficients, projections and controls are saved.

The actual JBCC proper/current prerequisite now covers the final target.
Five full master cases match an independent LEFT replay with explicit IBP
witnesses. The sixth broad case exhausted its180s allowance and remains
INCOMPLETE. A new actual-source/grade proof establishes that its JB-bearing
pairs have zero partners and its uncomputed source-free part cannot reach
JBCC at overallg1. Physical witnesses are inherited only by justified
restriction, and the hatted support is target-specific.

Within the inherited finite formal Gaussian prescription, this gives
QGamma_JBCC=-C_Q_JBCC=C_R_JBCC; original/H JBCC coefficients vanish by
their empty catalogs. The four M graph coefficients are still unmeasured.
JLambdaCC has only a raw-regulator zero catalog here, not a promoted proper
zero. aCC and common normalization remain open.

Next derive the four M JBCC coefficients and finite heat/IR profile from
the actual R_Fu0 and JB vertex, with an odd-source sign check. No coefficient
is fitted to the partial consistency remainder. See PROOF.md for failures,
controls, scopes and shared-error limits. Full investigation stays ACTIVE;
state113/34of39/E5/A5open unchanged, no physical adoption or remote action.
