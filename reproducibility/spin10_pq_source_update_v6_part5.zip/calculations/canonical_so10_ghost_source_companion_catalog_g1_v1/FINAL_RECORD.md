# Final validation, enlarged-scope prospective V1

The initial catalog record planned a180s final audit. No final audit ran
under that plan. Actual work now also includes five full master cases,
a source/grade structural continuation and inherited physical witness
restriction. Freeze this new final validation BEFORE execution: one240s
after-import worker,8GiB sampled private/350MiB launch floor, same128MiB
packet, eachgenerated artifact<=10MiB. This does not extend/retroactively
pass the original180s master run, whose exit124 remains INCOMPLETE.

Authenticate all preparations/source copies and old committed inputs;
compare all3 completed byte-identical catalogs before dependent checks.
Freshly reproject native full roots/ordinary vertices, verify replay raw
math equality, all cases/edges/grades/endpoints/cost bounds/controls and
source/physical port coverage. No fresh expensive path enumeration needed
beyond checking saved complete native/replay equality and every path.

Revalidate the five native completed case artifacts against the completed
LEFT replay (including full per-port products); recompute Taylor factors
from actual maps, projection journals, operator sums, full density IBP and
controls. Verify all source/grade audit rows, ordinary JB support and M
source-zero partner claim. Reproject each actual completed physical witness
and check its four currents reconstruct the restricted residual. Save all
restricted witnesses. Review written CPS/proper/Jacobian normalization
applicability; no assertion that this validates a continuum measure/QAP.

Keep the failed source/witness preparer observation and exhausted native
master capture separate from successful runs. Check resources/full captures,
old tree, project_state exact bytes, E4 exactly once no-fresh existing
D evidence context. Save full E4 stdout/stderr before asserting exits
0,0,0,0,0,2 and exactly seven custody unresolved NOTPASS. Final receipt
validates bounded evidence and target-support argument; does not promote
scientific authority or mark failed/exhausted runs PASS. No local commit
until validation and exact staged raw-byte/mode guard complete.
