# Actual JB-C-C proper/current prerequisite V1

The completed paired catalogs identify four M-only JBCC raw-regulator
graphs; original/H empty. Before evaluating coefficients, test the ACTUAL
proper/current master relation on the enlarged upper external budget
JB<=1,C<=2 (no other means) and two fluctuation legs. An empty/returning
raw-regulator catalog alone cannot assign proper QGamma coefficients.

Inputs: full V802 native/replay classical F/E maps, all643 ports, original
and both probes throughg1, source operations before restrictions. Actual
source convention V800, actual finite proper-chain V801, V790 Gaussian
identity, V791 inverse, and physical source-free support in V802 retained.
Do not define Gamma from a target residual. No loop integral is rerun.

Build KQ=sum F*T2E/2, KD=sum(T2F/2)*E, KC=sum(T1F)*(T1E), full g/u
convolutions: F0E0;Fu0E0+F0Eu0; F1E0+F0E1;Fu1E0+Fu0E1+F1Eu0+F0Eu1.
Native even prefix vs replay LEFT Taylor. Eligible-factor pruning only
removes fixed forbidden sources or words needing more field replacements
than Taylor degree; keep every index/reason and full Taylor factor before
post-Taylor mean restriction. Upper budgets, not exact final mean counts:
ordinary loop insertions may add further external means. Degree total5
intrinsic01, ghost1, raw two-quantum current. All source quadratics retained.

For all6 GF cases keep KQ,KD,KC; compare complete normal of their sum by
explicit4-current IBP witnesses. Choose a unique JB if present, else unique
mean C, else unique quantum a for two mean C, else unique quantum C. These
mean-count sectors are derivative invariant; retain Grassmann extraction
signs and no equations of motion. A nonzero normal is a genuine measured
remainder, not a fitted correction or an assumed zero. Save it and withhold
the corresponding proper bridge. Omit KD, omit KC controls at M g1, report
actual sensitive/blind outcomes. Fresh derivative routes must agree.

Physical Euler companions are not setzero. For this budget, physical
F0/F1 have only B/x and at most one C; probe physical flows all508 vanish,
physical E0 is linear and physical E1_B is quadratic B/x. Thus surviving
physical KQ/KD/KC have no sources and at most one mean C. They lie in the
old V802 source upper budget restricted B=Lambda=Ja=0, where all6 physical
master identities already have explicit IBP witnesses. Verify the actual
input support premises and reproject those saved full witnesses; ordinary
D preserves mean counts. No unknown physical E1_x is needed: its only
multipliers F0_x/Fu0_x vanish. This is justified proof restriction, not new
physical loop validation or an assumption that physical terms vanish.

CPS applicability for a later proper transfer: external JB differentiation
and u are stable on the zero physical-fermion/source ideal. Source JB*qB,
ghost/GF and u-action contain no fermion, qB contains no fermion; the retained
fermion quadratic block and its hatted defect have no JB/u dependence after
mixed blocks vanish on that ideal. Their target JB/u derivative is zero,
not global anomaly/measure/phase zero. This written support bridge must be
reviewed with the actual full-jet/CPS input before a proper coefficient claim.
This worker owns the bosonic actual master prerequisite only.

Resources: sequential native/replay, each180s after imports,8GiB sampled
private,350MiB launch pagefile floor. Same128MiB packet, eachgenerated
file<=10MiB. Full failed/incomplete sources/captures stay NOTPASS. Freeze
new source and input receipts before execution; no automatic rerun. Final
validation/E4 once is shared with the catalog increment. All independence
is algorithmic within shared action/types/algebra/AI author, not independent
scientists. No normalization adoption, state or E5/A5 promotion/remote action.
