from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gc,gzip,importlib.util,itertools,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
sp=importlib.util.spec_from_file_location('new_companion_root_algebra',O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/roots.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('new_companion_free_edges',O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/inventory.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
J=m.J;w=m.w;load=m.load;read=m.read;digest=m.digest
TARGETS={'aCC':(1,2,0,0),'JBCC':(0,2,1,0),'JLambdaCC':(0,2,0,1)}
def mean(n):
 return 0 if 598<=n<643 else 1 if 553<=n<598 else 2 if 643<=n<823 else 3 if 1151<=n<1196 else None

def classify(word,target,root):
 ext=[0]*4;quant=[];copies=[0,0]
 for n,js in word:
  if 1319<=n<1962:copies[0]+=1;quant.append(v.tag(n-1319))
  elif root and 1962<=n<2605:copies[1]+=1;quant.append(v.tag(n-1962))
  else:
   k=mean(n)
   if k is None:return 'FORBIDDEN_MEAN',None,None
   ext[k]+=1
 if copies!=([1,1] if root else [2,0]):return 'WRONG_QUANTUM_ENDPOINTS',None,None
 if any(a>b for a,b in zip(ext,target)):return 'EXTERNAL_PROFILE_EXCEEDED',None,None
 return None,tuple(quant),tuple(ext)

def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 assert len(blob)<=10*1024**2,'INDIVIDUAL_OUTPUT_REQUIRES_EXTERNAL_STORAGE'
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))

def paths(classes,target,u,probe,method,mode='actual',omit=None):
 def allowed(a):
  owner=a['owner']
  if probe is None:return not('probe' in owner or 'Fu' in owner)
  other=1-probe
  return owner!='GF_probe'+str(other) and owner not in ['R_Fu0_'+str(other),'R_Fu1_'+str(other)]
 marks=[i for i,a in enumerate(classes) if a['kind']=='marked' and allowed(a)]
 ordinary=[i for i,a in enumerate(classes) if a['kind']=='ordinary' and allowed(a) and not(omit=='inverse_U' and a['u'] and not any(a['external']))]
 assert all(sum(classes[i]['external'])+classes[i]['g']+classes[i]['u']>=1 for i in marks+ordinary),'ZERO_COST_NONREFERENCE_VERTEX'
 out=set()
 def valid(g,uu,e):return g<=1 and uu<=u and all(a<=b for a,b in zip(e,target))
 for root in marks:
  r=classes[root];g0,u0,e0=r['g'],r['u'],tuple(r['external'])
  if not valid(g0,u0,e0):continue
  for ro in [0,1]:
   start=r['quantum'][ro];last=r['quantum'][1-ro]
   if method=='native':
    def dfs(last,g,uu,e,path):
     if (g,uu,e)==(1,u,target) and v.edge(last,start,mode):out.add((root,ro,tuple(path)))
     if len(path)==4:return
     for i in ordinary:
      a=classes[i];gg=g+a['g'];vv=uu+a['u'];ee=v.addtuple(e,tuple(a['external']))
      if not valid(gg,vv,ee):continue
      for orient in [0,1]:
       if v.edge(last,a['quantum'][orient],mode):dfs(a['quantum'][1-orient],gg,vv,ee,path+[(i,orient)])
    dfs(last,g0,u0,e0,[])
   else:
    bags=[]
    def collect(at,items,g,uu,e):
     if (g,uu,e)==(1,u,target):bags.append(tuple(items))
     if len(items)==4:return
     for j in range(at,len(ordinary)):
      i=ordinary[j];a=classes[i];gg=g+a['g'];vv=uu+a['u'];ee=v.addtuple(e,tuple(a['external']))
      if valid(gg,vv,ee):collect(j,items+[i],gg,vv,ee)
    collect(0,[],g0,u0,e0)
    for bag in bags:
     for order in sorted(set(itertools.permutations(bag))):
      for orientations in itertools.product([0,1],repeat=len(order)):
       current=last;ok=True
       for i,orient in zip(order,orientations):
        a=classes[i]
        if not v.edge(current,a['quantum'][orient],mode):ok=False;break
        current=a['quantum'][1-orient]
       if ok and v.edge(current,start,mode):out.add((root,ro,tuple(zip(order,orientations))))
 return [[r,ro,[[i,o] for i,o in p]] for r,ro,p in sorted(out)]

def project_root(row,target):
 raw=row['raw_root'];selected=[];kept=[];bad=defaultdict(list);groups=defaultdict(list)
 for at,(ww,mon,cc) in enumerate(raw):
  word=tuple((n,tuple(js)) for n,js in ww);why,qq,e=classify(word,target,True)
  if why:bad[why].append(at);continue
  assert all(k[0]==row['g'] for k,num,den in cc)
  sig=('R_'+row['state'],'marked',row['g'],row['u'],qq,e);groups[sig].append(len(selected));selected.append(raw[at]);kept.append(at)
 disposition='RETAINED';diagonal=None
 if row['state']=='F0' and row['family']=='preference':
  free,exchange=m.free_exchange(m.decode(raw));assert m.encode(free)==raw and not exchange and row['free_proof']['whole_free_zero'];disposition='WHOLE_FREE_F0_ZERO_BEFORE_ORDINARY_INSERTIONS'
 if row['family']=='reference':
  diagonal=m.encode(m.diagonal(m.decode(selected)))
  if diagonal:save('reference_diagonal_failure_'+row['state'],dict(target=list(target),selected=selected,diagonal=diagonal));raise AssertionError('NONZERO_NEW_REFERENCE_DIAGONAL')
  disposition='NEW_SELECTED_WHOLE_REFERENCE_DIAGONAL_ZERO'
 result=dict(state=row['state'],family=row['family'],g=row['g'],u=row['u'],raw_root_terms=len(raw),raw_root_math_sha256=m.mhash(raw),selected=selected,kept_raw_indices=kept,rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(bad.items())],groups=[dict(signature=[a,b,c,d,list(e),list(f)],selected_indices=ids) for (a,b,c,d,e,f),ids in sorted(groups.items())],disposition=disposition,whole_reference_diagonal=diagonal)
 return result,set(groups) if disposition=='RETAINED' else set()

def project_ordinary(row,target):
 raw=row['quadratic_Taylor_half'];groups=defaultdict(list);kept=[];bad=defaultdict(list);selected=[]
 for at,(ww,cc) in enumerate(raw):
  why,qq,e=classify(tuple((n,tuple(js)) for n,js in ww),target,False)
  if why:bad[why].append(at);continue
  assert all(k[0]==row['g'] for k,num,den in cc)
  sig=(row['owner'],'ordinary',row['g'],row['u'],qq,e);groups[sig].append(len(selected));selected.append(raw[at]);kept.append(at)
 result=dict(owner=row['owner'],g=row['g'],u=row['u'],raw_word_count=len(raw),raw_math_sha256=m.mhash(raw),selected=selected,kept_raw_indices=kept,rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(bad.items())],groups=[dict(signature=[a,b,c,d,list(e),list(f)],selected_indices=ids) for (a,b,c,d,e,f),ids in sorted(groups.items())])
 return result,set(groups)

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not p.startswith(peer),'PEER_COMPANION_CATALOG_DENIED'
   assert not any(z in p for z in ['whole_inventory.json.gz','assembled_GF_kernels.json.gz','hard_response','JaC_companion_g1_recovery_v1','known_consistency_images_g1_v1']),'OLD_CATALOG_OR_AMPLITUDE_TARGET_DENIED'
 sys.addaudithook(guard)
 packet=load(O/(ROLE+'_inputs.json.gz'));artifacts=[];summary=[]
 assert len(packet['roots'])==12 and len(packet['ordinary'])==8
 for channel,target in TARGETS.items():
  roots=[];ordinary=[];sigs=set()
  for row in packet['roots']:
   saved,s=project_root(row,target);roots.append(saved);sigs.update(s)
  for row in packet['ordinary']:
   saved,s=project_ordinary(row,target);ordinary.append(saved);sigs.update(s)
  classes=[dict(id=i,owner=a,kind=b,g=g,u=u,quantum=list(q),external=list(e)) for i,(a,b,g,u,q,e) in enumerate(sorted(sigs))];cases=[]
  for label,u,probe in [('original',0,None),('probe0',1,0),('probe1',1,1)]:
   actual=paths(classes,target,u,probe,ROLE);wrong={name:paths(classes,target,u,probe,ROLE,mode=mode) for name,mode in [('wrong_HM','mix_HM'),('wrong_LL','LL'),('wrong_unrestricted','unrestricted')]};omitted=paths(classes,target,u,probe,ROLE,omit='inverse_U')
   scalar=[z for z in actual if any(q.startswith('x') for i in [z[0]]+[j for j,o in z[2]] for q in classes[i]['quantum'])]
   if scalar:save('scalar_reduced_cycle_'+channel+'_'+label,dict(classes=classes,complete_cycles=actual,scalar_cycles=scalar));raise AssertionError('SCALAR_RESUMPTION_REQUIRED_NEW_TARGET')
   rc=Counter(classes[r]['owner'] for r,ro,p in actual);active=sorted({q for r,ro,p in actual for i in [r]+[j for j,o in p] for q in classes[i]['quantum']})
   cases.append(dict(case=label,u=u,probe=probe,complete_cycles=actual,wrong=wrong,omit_inverse_U=omitted,root_counts=dict(sorted(rc.items())),active_quantum_types=active,scalar_reduced_cycles=scalar,all_length_scalar_chain_erasure_applicable=True,max_vertices=max((len(p)+1 for r,ro,p in actual),default=0)))
   row=dict(channel=channel,case=label,cycles=len(actual),root_counts=dict(sorted(rc.items())),active_quantum_types=active,max_vertices=cases[-1]['max_vertices'],wrong_counts={k:len(v) for k,v in wrong.items()},omit_inverse_U_cycles=len(omitted));summary.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
  artifacts.append(save(channel+'_catalog',dict(schema='NEW_FULL_RAW_GHOST_SOURCE_COMPANION_CATALOG_V1',channel=channel,target=list(target),roots=roots,ordinary=ordinary,classes=classes,cases=cases,total_vertex_bound=5,no_color_amplitude_or_proper_transfer_claim=True,scalar_all_length_nonreturn_by_erasure=True)))
  del roots,ordinary,classes,cases;gc.collect()
 out=dict(schema='NEW_GHOST_SOURCE_G1_COMPANION_CATALOG_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,artifacts=artifacts,summary=summary,all_raw_vertices_projected_fresh=True,no_old_mean_budget_exclusion_transferred=True,no_proper_amplitude_or_quantum_zero_claim=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/(ROLE+'_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='summary'},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
