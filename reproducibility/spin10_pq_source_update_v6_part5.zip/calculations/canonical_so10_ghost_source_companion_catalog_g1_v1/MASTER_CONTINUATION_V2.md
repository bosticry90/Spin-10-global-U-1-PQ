# JBCC master continuation V2: source/grade completion, not resource expansion

V1 native worker exhausted180s, exit124/FAILED, sampled private peak
4256153600 bytes within8GiB. Five case artifacts completed full density
reconstruction before their printed STAGE; final M g1 case and factor
collection did not complete. All sources/capture/outputs remain unchanged
NOTPASS for the parent. Do not infer completion from those five artifacts.
One earlier preparer failure was a guessed witness filename; V2 preparer
uses exact completed filenames/hashes from the owning collector receipt.

Reassessment: a coefficient with external JB requires a JB-containing
kernel or ordinary vertex. Check EVERY actual full ordinary Taylor half:
if it contains JB, its g grade must be1. Thus at overallg1 an already-g1
master kernel with no JB cannot gain JB in any inverse expansion, at any
u grade. Field Taylor and ordinary D preserve fixed-source multiplicity.
For M g1-u1, compute the source-JB part of the actual classical sum F*E
BEFORE Taylor, summing all four branches/all643 ports. The even product
rule then proves KQ+KD+KC=T2(B_JB)/2 on this loop-eligible source component.
This derives a kernel identity from the action, not a fit to a quantum
remainder. If every JB-bearing pair has a zero partner, separately prove
all three JB-containing kernels zero; otherwise use the exact density
and its full T2/IBP witness. Nonzero normal blocks the transfer.

This narrower engineering calculation preserves coverage of the full final
JBCC g1-u coefficient. It does not complete V1's unrestricted source-free
upper M g1-u master kernels, whose run remains INCOMPLETE. Their contribution
to this target is excluded by actual source/coupling-grade support. No
scientific acceptance condition, physical input or resource is weakened.

Two new sequential bounded workers: source/grade audit60s then replay180s,
8GiB sampled private/350MiB launch floor, same128MiB packet. The replay
reconstructs only the five completed native cases by LEFT Taylor; compare
operators/full residuals/IBP currents/normals/port dispositions before reuse.
Save full new factor evidence. Controls omit KD/KC in originalg1, where
JB source terms occur, instead of the uncompleted M g1 control. Report
actual sensitivity. Native parent is never relabeled PASS; qualified case
reuse requires fresh independent replay and final algebra verification.

Physical support: g1 physical kernels have no JB and are excluded by the
same grade argument. Original g0 physical upper kernel has only zero means
and the old V802 source physical proof restricts unchanged. Probe physical
flows are zero, their master kernels zero. Verify actual F/E support and
all six inherited witness reconstructions, not an invented physical zero.
The hatted/CPS and actual normalization support in MASTER_RECORD remains
conditional on its actual-source prerequisites. No quantum coefficient is
assigned, no full QAP/chiral measure/normalization/adoption or state change.
Shared action/types/ring/AI authorship disclosed; agreement of the replay
alone does not validate those shared premises. Full goal remains ACTIVE.
