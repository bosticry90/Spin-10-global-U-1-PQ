# Full raw-regulator companion catalog, prospective V1

1. Question: which actual rooted one-loop Gaussian regulator graphs can
contribute to the still-unmeasured aCC, JBCC and JLambdaCC g1 breakings,
unprobed and first-u H/M? This selects the next indispensable coefficient
calculation after V807's nonzero partial consistency normal.
2. Claim/scope: original Euclidean A0/intrinsic01 action inputs, all643
field ports, all45 colors/all4 vector directions before type collapse.
This is a conservative combinatorial catalog, not a measured coefficient,
proper-identity transfer, color nonzero claim, scalar resummation or QAP.
No old source/vector external-budget exclusion is transferred.
3. Types: new external slots(a,C,JB,JLambda), canonical field/source indices
598..642,553..597,643..822,1151..1195; targets(1,2,0,0),(0,2,1,0),(0,2,0,1).
Root quantum copies1319/1962 are distinct; ordinary quantum copy1319 has
two field factors. Mean ghosts and quantum ghosts remain distinct.
Sources are retained before Taylor/source operations and target restriction.
4. Inputs: all12 V792 raw R_F0/F1/Fu0/Fu1 assemblies for Preference and
reference defect. Full V788 original/probe g0 ordinary Hessians; full V789
S1/U1 ordinary Hessians; V787 physical gauge/scalar g1 ordinary Hessians.
Preparation authenticates committed inputs and copies only full raw roots,
whole free-F0 proof and full ordinary Taylor halves into new native/replay
operand packets. Old returning lists/current targets are not inputs.
5. Exclusions: free F0 is removed only by whole actual free-exchange proof,
not individual-root deletion. New reference diagonals must be explicitly
zero for EACH new budget or the route fails and retains the nonzero data.
Retain physical owners, both probes, source quadratics and inverse-U
zero-mean responses before filtering. No propagator Lambda-Lambda edge.
6. Method: raw-root and full-ordinary classification with complete raw
index kept/rejected journals and actual selected coefficients. Native
oriented DFS vs replay multisets/all orders/end orientations. Standard
fixed V791 free inverse: BB/BL/LB and Ca/aC only within H/M, scalar same
representation. Raw type classes overcount colors and cancellations.
7. Completeness: every retained ordinary has positive external degree
or g/u cost. Free g0u0 is already in reference. Nonfree roots have positive
g/u/external cost (check actual classes). The target external degree3+
g1+u<=1 gives at most5 total vertices, at most4 ordinary insertions.
Every zero-arity g1/u1 response remains; no silent path truncation. Scalar
reduced cycles, if any, stop the simple nonreturn route and require actual
resummation. Any arbitrary degree0 same-scalar-chain insertion can be
erased preserving endpoint connection; absence of reduced scalar cycles
excludes those chains at every length, not by an arbitrary run allowance.
8. Controls: wrong H/M mixing, wrong LL edge, unrestricted edges and
omit inverse-U. Save complete control lists and actual sensitive/blind
results. Compare completed outputs before downstream coefficient work.
9. Applicability: V790 C_Q=Jac-C_R and V791 inverse are inherited scoped
inputs. New returning catalog alone does not extend V802's actual proper
master/current bridge to new a/JB/JLambda external budgets; that bridge
and full CPS/hatted/physical-source support must be proven before using
these catalogs as proper QGamma amplitudes or quantum zeros. No global
fermion anomaly or measure/phase claim, even for an empty typed catalog.
10. Resources/order: native then replay sequential, each180s after imports,
8GiB sampled private,350MiB launch available pagefile. Whole packet128MiB,
individual generated files>10MiB external by default. No overwrite/retry;
failed/unfinished exact sources/captures retained NOTPASS. Preparation is
operand serialization, not a scientific calculation or acceptance.
11. Verification: normalize and compare selected mathematical vertices,
classes and all completed cycles/controls. Recheck provenance/classifiers,
path grades/endpoints/budget/cost bound; final180s validation and E4 once
no-fresh existing D evidence context, exits0,0,0,0,0,2/seven custody NOTPASS.
No expensive loop reintegration. Independent enumerations share action,
chart, inverse, exact ring, support typing and AI author, not independent
scientists or evidence validating shared physical assumptions.
12. Outcome: nonempty candidate list narrows coefficient work, empty list
only supports raw-regulator graph exclusion, or FAILED/INCOMPLETE within
bounds. No missing coefficient fitted, no normalization/counterterm adopted,
no E5/A5 promotion/state change/flavor/HB1/C5 activation/remote action.
Full goal remains ACTIVE. Record significance, limits and next competent
quantum test after output; preserve prior exclusions in their old scopes.
