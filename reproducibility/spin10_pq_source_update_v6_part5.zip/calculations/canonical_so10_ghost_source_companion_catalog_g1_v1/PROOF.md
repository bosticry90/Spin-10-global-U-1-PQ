# Full ghost/source returning catalogs and the JBCC proper prerequisite

## New quantum envelope, from full inputs

The question is the missing aCC, JBCC and JLambdaCC companions of the
selected Spin(10) x global U(1)PQ proper breaking, not a fit of V807's
nonzero partial normal. Original Euclidean A0, firstg/firstu, intrinsic01,
all643 bosonic/ghost field ports and all45 colors precede type collapse.
The raw R_F regulator root and full ordinary Hessians are inherited from
the actual action; no lost October coefficient is used. Quantum copies
1319/1962 remain distinct. No old vector/Ja exclusion is transferred.

Preparation copies only full raw R_F0/F1/Fu0/Fu1 roots (both Preference and
reference defect) and eight full ordinary Taylor halves: GF original/U0
both probes, S1/U1 both probes, physical gauge/scalar g1. Existing current
answers and returning lists are not construction operands. Native oriented
DFS and replay multisets/all orders/end orientations produce byte-identical
complete catalogs, including source/physical/zero-mean inverse responses,
selected actual coefficients, every raw kept/rejected index, all classes,
cycles and controls. All three pairs are frozen before downstream work.

Only whole free F0 is removed: its full actual graded exchange vanishes
before insertions. Every new selected reference diagonal is checked zero
for each new budget. Individual roots, a probe free group or a scalar
reference term are never discarded by analogy. Fixed free edges are BB,
BL/LB and Ca/aC within a common H/M sector; scalars connect only within
the same representation; there is no LL free edge. Every retained vertex
has positive external degree or g/u cost, bounding total vertices by5.
Zero-mean g/u responses remain. No reduced scalar cycle occurs: erasing
any arbitrary same-scalar zero-arity chain preserves endpoints/grade/means,
so the nonreturn conclusion is not a truncation of chain length.

| Target | Unprobed g1 | H first-u,g1 | M first-u,g1 |
| --- | ---: | ---: | ---: |
| aCC |4|0|112|
| JBCC |0|0|4|
| JLambdaCC |0|0|0|

These are oriented typed candidates, not independent amplitudes or color
nonzeros. aCC original uses R_F1, M uses84 R_F1 and28 R_Fu0_1 cycles;
JBCC M uses4 R_Fu0_1 cycles. All surviving quantum types are BM/LM/CM/aM.
No physical scalar port was excluded before its raw projection. Maximum
vertices3 for original aCC and4 for M aCC/JBCC.

Controls are fully saved. For aCC original, wrong H/M/LL/unrestricted edges
admit16/20/296 vs4; H196/0/7984 vs0; M354/350/9812 vs112. Omitting inverse-U
changes M aCC112 ->64, losing48 cycles, and is blind for original/H and
JBCC. JBCC M wrong H/M/LL/unrestricted counts16/10/448 vs4. Empty original
JBCC remains empty even in these wrong-edge controls (blind); H gains8
with wrong H/M. JLambdaCC wrong unrestricted edges give96 H and112 M;
H/M and LL controls are blind. No insensitive control is called validation.
Catalog workers29.896/29.794s under180 each, no catalog failure.

## Actual JBCC master relation: scope and failure

Four M JBCC candidates make it the least expensive next coefficient target.
An empty catalog alone does NOT extend the old proper bridge to this new
source. The full-source LEFT convention remains
F_i=(-1)^p_i EL_Ji S, QJ_i=(-1)^p_i E_i, E_i=EL_i S. Even field Taylor
therefore gives actual kernels

    KQ=sum F_i T2E_i/2,
    KD=sum (T2F_i/2) E_i,
    KC=sum (T1F_i)(T1E_i),
    KQ+KD+KC=T2(sum F_i E_i)/2.

Upper mean budgets are required: ordinary inverse responses may supply
remaining external means. All643 ports/all g/u branches are retained
before restriction. Safe factor pruning removes only a fixed forbidden
source or more forbidden/excess field factors than Taylor can replace.
Every index and branch/port product has a disposition. Full eligible
Taylor factors are preserved before projection; not called unrestricted T2.

V1 native tested the complete C<=2,JB<=1 upper budget. Five cases completed
explicit density reconstruction with zero normal, but the final M g1-u1
case timed out at180s. Its parent is exit124/FAILED/INCOMPLETE, never PASS.
The sampled private maximum4256153600 bytes was below8GiB. One earlier
preparer failed a guessed V2 witness filename; the correct g1 witness was
in isolated V3. The receipt-owned filename correction preserved all failed
sources and returned observations. No scientific worker was launched by
that preparer. Old contracts, inputs and captures were not edited.

## Target-complete structural continuation

Rather than expand that worker's allowance, V2 changes method using actual
source/coupling support. EVERY ordinary Taylor half is scanned in both
routes: any word with JB has g grade1. Field Taylor and D preserve fixed
JB multiplicity. Thus, at overallg1, a g1 kernel with no JB cannot acquire
JB through any inverse expansion: it would require another g1 vertex.
This holds for arbitrary numbers of allowed g0 responses and both u grades.
It does not exclude a source-free g0 kernel followed by a g1 JB vertex;
those cases remain and are explicitly checked.

The new source audit examines all4 M g1-u1 branches/all643 ports BEFORE
Taylor. In every pair containing JB, the other COMPLETE operand is zero.
Consequently all three JB-containing KQ/KD/KC kernels vanish separately,
not just their sum after fitting or a Grassmann-product cancellation.
The full source-free M g1-u1 kernels remain uncomputed; their contribution
to this final target is excluded by the measured ordinary g-grade rule.
The actual source-JB classical density and selected T2 density are both0.
All2572 pair dispositions and raw hashes are preserved. Audit36.405s/60.
This covers the original final JBCC requirement by a smaller proof, not by
shrinking the physical target or relabeling the exhausted run complete.

A completed42.938s/180 LEFT-Taylor replay reexecutes the other five cases.
Its actual operators, products, residuals, currents and normals agree with
the five completed native case artifacts. The old parent remains FAILED;
these case results are reused only with this new replay and final proof
verification. Their residual sizes are360,480,13320,52892,23208; all have
zero normal. The originalg1 residual includes10044 JB-pivot and42848
mean-C-pivot words. Omitting KD gives10704 normal words; omitting KC gives
38252. The full exact control polynomials/currents are saved.

For IBP choose unique JB if present, else the unique mean C, else unique
quantum a when two mean C, else unique quantum C. The presence/count
classes are invariant under ordinary D. Extract the odd pivot with its
actual Grassmann sign and repeatedly integrate its jets onto the rest.
All four currents reconstruct the COMPLETE density. This supplies a
functional zero without equations of motion or kinematic specialization.
The new proof does not pretend that V1's uncompleted source-free upper
normal was checked. Independent algorithms share action/types/ring/AI
source and are not independent scientists or physical verification.

## Physical and hatted companions, not assigned zero

Physical terms use actual F/E support. F0/F1 at the508 physical ports are
source-free with at most one C, probe physical flows all vanish, E0 is
linear and retained E1_B is quadratic in B/x. g1 physical kernels have no
JB and cannot reach this target by the same coupling-grade rule. The g0
physical kernel lies unchanged inside the old V802 source proof after
B=Lambda=Ja=0; ordinary D preserves mean counts. Final verification
reprojects all six completed old physical witnesses and checks all four
currents reconstruct each residual. This is inherited proof restriction,
not a new physical trace replay or setting physical Eulers zero. Unknown
physical E1_x is bypassed only by actual F0_x/Fu0_x=0. Scalar potential
companions are not globally zero: atg0 physical x flow vanishes, and g1
physical source-free kernels are excluded here by the actual JB g-grade.
The retained intrinsic/zero-scalar-mean domain and polynomial coefficient
ring are unchanged.

The actual CPS hatted insertion has C,P,S/hatted derivatives and no JB,
a or Lambda. The fermion source K couples C P; JB*qB has no fermions.
G/QG and their u derivatives have no fermion fields/sources. On the
P=S=K=0 stable ideal the mixed blocks vanish AFTER external/source
operations. JB/u differentiation preserves that ideal and annihilates the
remaining fermion/hatted block, which is JB/u independent. No global
hatted defect, gauge anomaly, measure phase or Qfull-square-zero theorem
follows. This is the actual-source support reasoning of the inherited
CPS calculation reapplied to this particular new source target.

## Proper interpretation and remaining coefficient work

V801 derives, including LEFT odd-source derivatives and fixed source-
independent R, I_B1=QGamma1+C_Q. The actual kernel proof above makes its
JBCC target zero in the finite common-profile Gaussian. V790 independently
has C_Q=Jac-C_R, with every full own-jet diagonal0 throughg1/firstu before
mean/source restriction. Hence in this TARGET and prescription,

    QGamma1_JBCC = -C_Q_JBCC = C_R_JBCC.

This fixes the actual operator interpretation; it does not assign any of
the four M graph coefficients. The g0 proper determinant normalization,
all45 ghost/even inverse blocks and reference determinant convention from
V803/V791 are retained, without an extra ghost half or sign by naming.
Common continuum subtraction, full reality, source products and global
QAP remain unresolved. Zero original/H raw catalogs therefore transfer
only to their finite formal proper JBCC coefficients in this prescription;
the M coefficient remains unmeasured. No analogous proper zero is claimed
here for JLambdaCC: only its raw-regulator catalog is completed.

Next: derive the four actual M JBCC color/momentum coefficients from
R_Fu0 roots, full original g1 JB ordinary vertex and g0 ghost/auxiliary
vertices, retaining both root orientations and full internal45 colors.
Fix the odd-source/Berezin sign with an actual-coefficient finite Gaussian,
then derive its complete finite heat/IR kernel before taking a qualified
ordered reference. Do not choose a coefficient from the known consistency
remainder. aCC4/112 and its own proper-identity scope remain subsequent
indispensable tasks; unprobed JaC is already zero in V806's scope.

Scientific significance: three formerly unknown graph envelopes are now
reproducible, with a target-complete JBCC proper prerequisite despite one
exhausted broad run. AI demonstrated exact full-vertex reuse, source-aware
support and a more efficient proof after a resource failure; it also made
an avoidable witness-filename preparation error and an initially expensive
scope choice. All failures and limitations remain visible. This is no
normalization adoption, physical viability conclusion, E5/A5 promotion,
publication or full-goal completion. project_state stays the sole authority.
