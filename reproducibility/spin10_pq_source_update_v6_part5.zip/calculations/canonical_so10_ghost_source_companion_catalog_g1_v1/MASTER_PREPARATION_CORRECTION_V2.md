# Master preparation correction V2

V1 preparation guessed an old physical witness filename; the completed g1
witness actually belongs to the isolated V3 continuation. It failed before
worker/manifest launch. Exact failed source and returned observation remain
NOTPASS. V2 resolves all six physical source witnesses directly from owning
collect_result.json, checks their recorded hashes and completion flags,
and authenticates their committed bytes. Existing catalog-pair file is
verified, not overwritten. No algorithm, physical input or180s/8GiB/350MiB/
128MiB bound changes; no scientific worker had run in the failed preparation.
