# Actual mixed support and the surviving quantum contacts

Requires completed separate final evidence. Same unshifted bosonic A/alljets0,
g<=1,intrinsic01,first unit H/M probe. Project_state remains sole authority;
no full-profile,normalization,measure,QAP,A5,E5 or physical acceptance.

## Authenticate the actual owners and separate the alphabets

V839 bound the UNPREFIXED CGR endpoint packet,sha9fd4994a...aca4a5. Bind
that actual file and the newer v2 file separately; compare complete K/D
polynomials. Equal mathematical content does not authorize replacing an
old manifest hash or claiming historical replay. Reuse the completed M2
receipt,not its failed original raw-density equality attempt.

The epsilon chart keeps33 odd slots1286..1318. Decode old geometric omega
in its separate EVEN chart,then relocate only omega to1319..1330. Every
column round-trips. New h1331..1973,k1974..2616 carry the field parities;
TAG3000..3003 is a separate even current covector. Legacy polarization
wrappers and broad n>=1286 parity guesses are not used. Wrong omega parity
violates624 actual source-rule types. The coefficient ring/coupling degree
is unchanged; compact and split-g encodings are adapted losslessly.

## Complete classical support gates

Recover D from the full current odd primitive:

    Dzi=-EL_Ji KD, DJi=EL_zi KD.

Both raw and epsilon-normal K yield every supplied1286 D column. The only
nonzero ordinary-field flows are broken-antighost translations a610..642
to their local epsilons. Geometric C has zero field flow and source targets
JB_H(643..690),Ja_H(1241..1252). KD's only BV sources are Ja_M1253..1285.
These source/jet targets are disjoint,so C KD=0 as a COMPLETE density.

Likewise the actual raw/normal g1 DS has only Ja_M1254..1285 sources.
The g0 and each independently computed DU raw/normal have no active C
source port. Every direct C(raw),C(normal) and C(current) is evaluated;
all are zero densities in these actual cases. No source census replaces
variation,or zero normal replaces its raw/current identity.

C and D are even canonical operations. The actual full coordinate and
first-jet checks give [C,D]=CD-DC=X_(C KD)=0. In fact CD and DC are
separately zero on these coordinates,so this test is BLIND to reversing the
commutator sign. The convention comes from the inherited canonical and
rho-left calibrations,not from this insensitive zero. Commutation alone does
not imply D(C Sigma)=0: it gives D(C Sigma)=C(D Sigma). The separate actual
C(DS) and C(DU) gates establish that additional zero in this selected family.

## Retained currents and scoped all-D zeros

Each of the six V839 cases retains its own raw/normal/QKD/current packets.
Recheck raw=normal+divj and normalDS=-normalQKD. The native g0 raw264
divergence words and replay raw0 remain distinct; no failed historical
comparison is rewritten. A new epsilon-only symmetric Euler current gives
the SAME normal while keeping all scalar epsilon jets. The normalized g1
DS remains7296words with a nonzero35092-word ordered Hessian.

The whole raw-minus-normal difference is unwicked with actual source/time
phases. A fresh metric-natural symmetric current reconstructs it: g0 has
33 words per component; g1 has1268 per component. Full tagged rank2
component domains/zero complements are checked separately. Original
current representatives remain untouched; only their full divergence is
compared. No termwise omission or momentum shift is involved.

Every DU raw AND normal at g0/g1 for both probes is exactly zero density.
For its dimension jet,use V848's fixed U_D plus the actual rho-D source
operation of V852: natural one-Euler/local substitution adds no new numeric
metric circle and stays in the faithful rank<=4 module. The complete raw
zero therefore identifies the same fixed all-D density/operator/first jet,
not merely C(DU)=0. The symmetric current audit supplies the same argument
for integrated DS0 zero. DS1 remains nonzero. KD/DS active BV sources and
the disjoint C targets are internal color/scalar-source types,so their zero
source intersections persist in the fixed all-D constructor. There is no
arbitrary 4D-zero-to-D inference or independently chosen evanescent term.

Inside ONE prospective finite functional that respects these zero action
deformations,a DU direction and its Frechet derivatives vanish. This does
not qualify independently normalized composite products or all higher-g
DS/DU roots. All closed QUANTUM D traces and angular jets remain.

## What one parent actually generates

Let A=S+uU. Freeze C=X_W,even/source-canonical,with c_J=EL_zW. Define

    Sigma=A+rho KD,
    Sigma_theta=Sigma+theta C(Sigma),
    B_theta=B[Sigma_theta] BEFORE beta,
    F_kappa[Sigma_theta+beta B_theta].

Theta is constant even;beta and rho are odd,with beta LEFT. Theta changes
the pre-beta differential: Q_theta=Q_Sigma+theta[C,Q_Sigma];beta does not.
Classical canonicality gives B'[C Sigma]=C B[Sigma] modulo actual currents,
with no factor2. CKD=0 also gives D_theta=D,but does not freeze Q_theta.
The base-master zero through first-u is the separate V854 bosonic result.

Before using actual zeros,the rho-theta coefficient is

    F'[CKD]+F''[CA,KD].

The beta-rho-theta coefficient,after the base-master zero,is

    F'[CDA]+F''[CA,DA].

All signs are positive in beta-before-rho order. Theta commutes with both;
reversing LEFT beta/rho changes the sign. These are action derivatives,
not quantum C substitution on mean fields or an A5 equivalence theorem.

The new support gates and fixed DU zero reduce them to

    [rho theta]F=F''[CS+uCU,KD],
    [beta rho theta]F=F''[CS+uCU,DS].

Their first-u coefficients are respectively

    F'''[U,CS,KD]+F''[CU,KD],
    F'''[U,CS,DS]+F''[CU,DS].

Only the explicit direct contacts disappear. Ordinary-U propagator/finite-
map variations remain,with the full interacting g0 Lambda/a/C background.
No missing amplitude or normalization coefficient has been assigned.

## The next discriminating order

Actual ordered bilinear grades are KD:(1200 atg0,2672 atg1),
CS:(0,1152),DS:(0,35092),CUH:(0,2880),CUM:0,DUH/DUM:0.
Consequently the rho-theta covariance can begin atg1 from CS1/KD0.
The beta-rho-theta covariance from the known roots cannot start beforeg2.
Nonnegative action/inverse grading prevents hidden g0 Born dressing from
lowering those powers. These are necessary order bounds,not nonzero loop
amplitudes or a complete g2 calculation. Unknown higher-g direct roots and
current interfaces remain unqualified. A g<=1 beta-contact PASS would be
structurally insensitive to the leading known covariance.

The less expensive discriminating next target is therefore the WHOLE
rho-theta and first-u covariance operator/domain,including any indispensable
critical local words. Do not launch a new g2 amplitude catalog or replace
the full inverse by freeG0. Mixed UV/IR eligibility is NOT automatic from
the prior one-insertion theorem; n<=9 is still a proposed joint bound.

Finally C is not geometric T. With epsilon fixed,CKD=0 leaves

    T Sigma_rho+C(Sigma_rho)=rho TprimeKD=rho T KD.

The marked geometric Ward retains its whole [T KD] insertion and raw
regulator/measure response. It is not homogeneous,and classical C/D
commutation does not remove that RHS. Same action,software,arithmetic and
AI authorship limit all agreement; no physical or experimental validation.
