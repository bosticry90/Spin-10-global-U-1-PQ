from fractions import Fraction as F
from itertools import product,permutations
from collections import defaultdict
from functools import lru_cache
import json
TAG=3000
PAIR={0:[()],2:[((0,1),)],4:[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]}
def par(n):
    if TAG<=n<TAG+4:return 0
    if 1286<=n<1319:return 1
    if 1319<=n<1331:return 0
    assert 0<=n<1286,n
    return int(n>=553)if n<643 else 1-int(n-643>=553)
def canon(w):
    odd=[t for t in w if par(t[0])]
    if len(set(odd))<len(odd):return(),0
    return tuple(sorted(w)),(-1)**sum(x>y for at,x in enumerate(odd)for y in odd[at+1:])
def put(out,w,k,v):
    if not v:return
    w,sg=canon(w)
    if sg:out[w,k]=out.get((w,k),F(0))+v*sg
def clean(q):return{k:v for k,v in q.items()if v}
def add(*qs):
    out={}
    for q in qs:
        for k,v in q.items():out[k]=out.get(k,F(0))+v
    return clean(out)
def scale(q,c):return{k:v*c for k,v in q.items()if v*c}
def flat(rows):return{(tuple((i,tuple(js))for i,js in w),tuple(k)):F(n,d)for w,cs in rows for k,n,d in cs if n}
def encode(q):
    rows=defaultdict(list)
    for(w,k),v in sorted(q.items()):
        if v:rows[w].append([list(k),v.numerator,v.denominator])
    return[[[[n,list(js)]for n,js in w],cs]for w,cs in sorted(rows.items())]
def D(q,mu):
    out={}
    for(w,k),v in q.items():
        for at,(n,js)in enumerate(w):put(out,w[:at]+((n,tuple(sorted(js+(mu,)))),)+w[at+1:],k,v)
    return clean(out)
def phase(n):
    if TAG<=n<TAG+4:return 1 if n==TAG else 0
    if 1286<=n<1331:return 0
    assert n<1286,n
    f=n-643 if n>=643 else n
    if 508<=f<553:return 3
    if f<180 and f%4==0:return 1
    return 2 if n>=643 and f<508 else 0
def iphase(q,power):
    out={};power%=4
    for(w,k),v in q.items():
        kk=list(k);sign=-1 if power>=2 else 1
        if power%2:
            if kk[3]&16:sign*=-1
            kk[3]^=16
        out[w,tuple(kk)]=v*sign
    return clean(out)
def unwick(q,extra=0,omit_time_jets=False):
    out={}
    for(w,k),v in q.items():
        power=-sum(phase(n)for n,js in w)-sum(js.count(0)for n,js in w)*(not omit_time_jets)+extra
        for key,val in iphase({(w,k):-v},power).items():out[key]=out.get(key,F(0))+val
    return clean(out)
def tag_current(curr):
    out={}
    for mu,q in enumerate(curr):
        for(w,k),v in q.items():put(out,w+((TAG+mu,()),),k,v)
    return clean(out)
def div(curr):return add(*(D(q,mu)for mu,q in enumerate(curr)))
def sym_normal(q):
    out={};curr=[{}for mu in range(4)]
    for(w,k),v in q.items():
        if not w:put(out,w,k,v);continue
        for at,(n,js)in enumerate(w):
            orders=sorted(set(permutations(js)))or[()]
            sg=(-1)**(par(n)*sum(par(i)for i,jj in w[:at]));co=v*sg/F(len(w)*len(orders))
            for order in orders:
                remaining=list(order);rest={(w[:at]+w[at+1:],k):co}
                while remaining:
                    mu=remaining.pop()
                    for(ww,kk),cc in rest.items():put(curr[mu],((n,tuple(sorted(remaining))),)+ww,kk,cc)
                    rest=scale(D(rest,mu),-1)
                for(ww,kk),cc in rest.items():put(out,((n,()),)+ww,kk,cc)
    out=clean(out);curr=[clean(z)for z in curr];assert add(q,scale(out,-1))==div(curr),'SYMMETRIC_FULL_IBP_RECONSTRUCTION'
    return out,curr
def feature(n,js):
    if n<180:return(0,n//4,len(js)),[n%4,*js]
    if 643<=n<823:return(1,(n-643)//4,len(js)),[(n-643)%4,*js]
    if TAG<=n<TAG+4:return(2,0,len(js)),[n-TAG,*js]
    assert n<1331,n
    return(3,n,len(js)),list(js)
def describe(w):return tuple(sorted(feature(n,js)[0]for n,js in w))
def slots(desc):
    return tuple(v for kind,n,j in desc for v in(([1]if kind==1 else[-1])if kind<3 else[])+[-1]*j)
def word(desc,assignment):
    at=0;out=[]
    for kind,n,j in desc:
        if kind<3:
            mu=assignment[at];at+=1;i=4*n+mu if kind==0 else 643+4*n+mu if kind==1 else TAG+mu
        else:i=n
        js=tuple(sorted(assignment[at:at+j]));at+=j;out.append((i,js))
    assert at==len(assignment)
    return canon(tuple(out))
@lru_cache(None)
def columns(desc,wrong_metric=False,wrong_JB=False):
    var=slots(desc);rank=len(var);assert rank in PAIR,(rank,desc)
    if wrong_JB:var=tuple(-1 for v in var)
    out=[]
    for pairs in PAIR[rank]:
        q={}
        for mus in product(range(4),repeat=len(pairs)):
            assignment=[0]*rank;factor=1
            for(a,b),mu in zip(pairs,mus):
                assignment[a]=assignment[b]=mu
                if var[a]==var[b]and mu and not wrong_metric:factor*=-1
            ww,sg=word(desc,assignment)
            if sg:q[ww]=q.get(ww,0)+sg*factor
        out.append({w:c for w,c in q.items()if c})
    return tuple(out)
def cadd(a,b,c=F(1)):
    out=dict(a)
    for k,v in b.items():out[k]=out.get(k,F(0))+v*c
    return clean(out)
def cscale(a,c):return{k:v*c for k,v in a.items()if v*c}
def solve_rref(A,Y):
    n=len(A[0])if A else 0;rows=[[list(map(F,r)),dict(y)]for r,y in zip(A,Y)];rank=0;piv=[]
    for col in range(n):
        at=next((i for i in range(rank,len(rows))if rows[i][0][col]),None)
        if at is None:continue
        rows[rank],rows[at]=rows[at],rows[rank];r,b=rows[rank];pivot=r[col];r[:]=[v/pivot for v in r];rows[rank][1]=cscale(b,1/pivot)
        for i,(rr,bb)in enumerate(rows):
            if i==rank or not rr[col]:continue
            c=rr[col];rr[:]=[x-c*y for x,y in zip(rr,r)];rows[i][1]=cadd(bb,rows[rank][1],-c)
        piv.append(col);rank+=1
    x=[{}for j in range(n)]
    for at,col in enumerate(piv):x[col]=rows[at][1]
    return x,piv
def inverse(A):
    n=len(A);z=[[F(v)for v in row]+[F(int(i==j))for j in range(n)]for i,row in enumerate(A)]
    for j in range(n):
        at=next(i for i in range(j,n)if z[i][j]);z[j],z[at]=z[at],z[j];pivot=z[j][j];z[j]=[v/pivot for v in z[j]]
        for i in range(n):
            if i!=j:
                c=z[i][j];z[i]=[x-c*y for x,y in zip(z[i],z[j])]
    return[row[n:]for row in z]
def solve_gram(A,Y):
    _,basis=solve_rref(A,[{}for row in A]);n=len(A[0])if A else 0
    G=[[sum(row[i]*row[j]for row in A)for j in basis]for i in basis];GI=inverse(G)if basis else[]
    rhs=[]
    for j in basis:
        z={}
        for row,y in zip(A,Y):z=cadd(z,y,F(row[j]))
        rhs.append(z)
    x=[{}for j in range(n)]
    for i,col in enumerate(basis):
        for weight,z in zip(GI[i],rhs):x[col]=cadd(x[col],z,weight)
    return x,basis
def packed_co(c):return[[list(k),v.numerator,v.denominator]for k,v in sorted(c.items())if v]
def reconstruct(q,route):
    groups=defaultdict(dict)
    for(w,k),v in q.items():groups[describe(w)].setdefault(w,{})[k]=v
    stream=[];rebuilt={};allres={};controls=dict(wrong_metric_sensitive_groups=0,wrong_source_variance_sensitive_groups=0,missing_first_rank4_pairing_sensitive_groups=0);domain_count=0
    for desc,target in sorted(groups.items()):
        rank=len(slots(desc));cols=columns(desc);ordered=sorted(set(target)|{w for c in cols for w in c})
        A=[[c.get(w,0)for c in cols]for w in ordered];Y=[target.get(w,{})for w in ordered];x,basis=(solve_rref if route=='native'else solve_gram)(A,Y)
        projected={}
        for col,cc in zip(cols,x):
            for w,v in col.items():
                for k,a in cc.items():projected[w,k]=projected.get((w,k),F(0))+v*a
        projected=clean(projected);actual={(w,k):v for w,c in target.items()for k,v in c.items()};res=add(actual,scale(projected,-1));allres.update(res);rebuilt.update(projected)
        domain={ww for ass in product(range(4),repeat=rank)for ww,sg in[word(desc,ass)]if sg};assert set(target)<=domain and {w for w,k in projected}<=domain
        domain_count+=len(domain)
        for name,badcols in [('wrong_metric_sensitive_groups',columns(desc,wrong_metric=True)),('wrong_source_variance_sensitive_groups',columns(desc,wrong_JB=True))]:
            bad={}
            for col,cc in zip(badcols,x):
                for w,v in col.items():
                    for k,a in cc.items():bad[w,k]=bad.get((w,k),F(0))+v*a
            controls[name]+=bool(add(actual,scale(clean(bad),-1)))
        if rank==4:
            bad={}
            for col,cc in zip(cols[1:],x[1:]):
                for w,v in col.items():
                    for k,a in cc.items():bad[w,k]=bad.get((w,k),F(0))+v*a
            controls['missing_first_rank4_pairing_sensitive_groups']+=bool(add(actual,scale(clean(bad),-1)))
        stream.append(dict(descriptor=[list(v)for v in desc],rank=rank,independent_pairing_columns=basis,all_pairing_coefficients=[packed_co(v)for v in x],canonical_component_domain=len(domain),zero_component_count=len(domain)-len(target),complete_residual=encode(res)))
    return dict(tensor_groups=stream,complete_reconstructed_density=encode(rebuilt),complete_residual=encode(allres),component_domain_count=domain_count,controls=controls,match=not allres)
