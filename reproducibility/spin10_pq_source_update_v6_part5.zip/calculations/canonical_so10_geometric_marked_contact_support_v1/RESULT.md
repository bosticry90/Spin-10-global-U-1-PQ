# V861: explicit mixed tree contacts vanish; quantum covariance remains

The primary completed in69.61s. Qualification requires the separate completed
validation_receipt.json/capture_validation.json.

Both routes find C(KD)=0,C(DS)=0 and C(DU_H/M)=0 as complete densities in
the declared g<=1 domain. Full1286 C/D commutators and all first jets agree.
The source targets are disjoint; no missing coefficient was fitted. The
commutator sign control is blind because CD and DC separately vanish.

Every original raw/normal/current identity remains. Native g0 raw264 terms
are a retained divergence; replay has0. DS1 remains7296 nonzero words with
35092 ordered Hessian words. The new natural current lifts have33 and1268
words per component for the g0/g1 differences. All independently computed
DU raw densities are0; their fixed all-D operator zero is qualified only
under the stated constructor/source-naturality proof.

The [proof](PROOF.md) identifies what survives: the common-functional
rho-theta covariance F''[CS+uCU,KD],including its U response. Its known
kernels permit a contribution already atg1. The carrier covariance with DS
cannot begin beforeg2 from the qualified kernels. Neither statement measures
an amplitude. Higher-g direct roots remain unknown.

Next investigate that lowest-order WHOLE covariance and its joint UV/IR
domain. Keep the full interacting ghost background,all finite-map responses
and the geometric marked Ward RHS [T KD]. A classical mixed zero does not
complete a renormalized quantum product or impose homogeneous invariance.

Authority34/39,E5/A5 open,seven custody NOTPASS. No physical/prescription
adoption,state change,push/publication. C: captured recovery v13 reachesV860
with its six required predecessors; this later work is not automatically covered.
