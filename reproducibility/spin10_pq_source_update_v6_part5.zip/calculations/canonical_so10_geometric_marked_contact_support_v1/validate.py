from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-marked-contact-support-v1-2026-11-08')
sys.path.insert(0,str(B/'canonical_so10_geometric_ward_current_source_chart_v1'));import algebra as a
sp=importlib.util.spec_from_file_location('V861_FROZEN_FRACTION_WORD_EULERS',B/'canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
sp=importlib.util.spec_from_file_location('V861_FROZEN_INPUT_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
H=1331;K=1974;TAG=3000
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def dim(n):
    if 643<=n<1286:return 3-dim(n-643)
    if n<1286:return 2 if 508<=n<553 else 1
    if 1286<=n<1319:return 1
    if 1319<=n<1331:return 0
    if H<=n<K:return dim(n-H)
    if K<=n<K+643:return dim(n-K)
    assert TAG<=n<TAG+4;return 1
def choose(P,D):return{k:cv for k,cv in P.items()if k[0]<=1 and 0<=D-sum(dim(n)+len(js)for n,js in k[1])<=1}
def grouped(q):
    out={}
    for(w,(g,x,e,m)),cv in q.items():a.put(out,(g,w),(((x,e,m),cv),))
    return out
def par(n):
    if TAG<=n<TAG+4 or 1319<=n<1331:return 0
    if 1286<=n<1319:return 1
    assert 0<=n<1286
    return int(n>=553)if n<643 else 1-int(n-643>=553)
def canon(w):
    oo=[t for t in w if par(t[0])]
    if len(oo)!=len(set(oo)):return (),0
    return tuple(sorted(w)),(-1)**sum(oo[i]>oo[j]for i in range(len(oo))for j in range(i+1,len(oo)))
def raw(rows):return {(tuple((n,tuple(j))for n,j in w),tuple(k)):F(num,den)for w,co in rows for k,num,den in co}
def epsilon_Euler(P,pars):
    out={}
    for(w,k),cv in P.items():
        ee=[(at,n,js)for at,(n,js)in enumerate(w)if 1286<=n<1319];assert len(ee)==1;at,n,js=ee[0];q={(w[:at]+w[at+1:],k):cv*(-1)**(sum(pars[i]for i,j in w[:at])+len(js))}
        for mu in js:q=v.de(q,mu,pars)
        for(ww,kk),co in q.items():
            word,sg=v.canon(((n,()),)+ww,pars)
            if sg:v.add(out,(word,kk),sg*co)
    return out
def div(cc,pars):
    out={}
    for mu,q in enumerate(cc):
        for k,cv in v.de(q,mu,pars).items():v.add(out,k,cv)
    return out
def ports(P):return{n for(g,w),co in P.items()for n,js in w if 643<=n<1286}
def rename(A,P,back=False):
    out={}
    for(g,w),co in P.items():
        assert all(n<1286 or(1319<=n<1331 if back else 1286<=n<1298)for n,j in w)
        ww,sg=A.canonical(tuple((n-33 if back and n>=1319 else n+33 if not back and n>=1286 else n,j)for n,j in w));assert sg==1;a.put(out,(g,ww),co)
    return out
def polar(P,offset,pars):
    out={}
    for(w,k),cv in P.items():
        for at,(n,j)in enumerate(w):
            if n<643:
                ww,sg=v.canon(w[:at]+((offset+n,j),)+w[at+1:],pars)
                if sg:v.add(out,(ww,k),sg*cv)
    return out
def kernel(P,pars):return polar(polar(v.flat(a.encode(P)),H,pars),K,pars)
def phase(n):
    if TAG<=n<TAG+4:return 1 if n==TAG else 0
    if 1286<=n<1331:return 0
    i=n-643 if n>=643 else n
    return 3 if 508<=i<553 else 1 if i<180 and i%4==0 else 2 if n>=643 and i<508 else 0
def unwick(P):
    out={}
    for(w,k),cv in P.items():
        pw=(-sum(phase(n)for n,js in w)-sum(js.count(0)for n,js in w))%4;kk=list(k);sg=-[1,1,-1,-1][pw]
        if pw%2:
            if kk[3]&16:sg=-sg
            kk[3]^=16
        v.add(out,(w,tuple(kk)),sg*cv)
    return out
def desc(w):return tuple(sorted((0,n//4,len(js))if n<180 else(1,(n-643)//4,len(js))if 643<=n<823 else(2,0,len(js))if TAG<=n<TAG+4 else(3,n,len(js))for n,js in w))
def var(d):return tuple(vv for kind,n,j in d for vv in(([1]if kind==1 else[-1])if kind<3 else[])+[-1]*j)
def word(d,assignment):
    at=0;out=[]
    for kind,n,j in d:
        if kind<3:
            mu=assignment[at];at+=1;i=4*n+mu if kind==0 else 643+4*n+mu if kind==1 else TAG+mu
        else:i=n
        js=tuple(sorted(assignment[at:at+j]));at+=j;out.append((i,js))
    assert at==len(assignment);return canon(tuple(out))
def tensor(Q,rec):
    gg=defaultdict(dict)
    for(w,k),cv in Q.items():gg[desc(w)][w,k]=cv
    assert len(gg)==len(rec['tensor_groups']);domain_total=0;wrongmetric=wrongsource=0
    for(d,target),row in zip(sorted(gg.items()),rec['tensor_groups']):
        rank=len(var(d));assert rank in[0,2]and row['descriptor']==[list(x)for x in d]and row['rank']==rank and len(row['all_pairing_coefficients'])==1;co={tuple(k):F(num,den)for k,num,den in row['all_pairing_coefficients'][0]};cols=[]
        for metric,badsource in[(True,False),(False,False),(True,True)]:
            col={};vv=var(d)
            if badsource:vv=(-1,)*len(vv)
            for ass in([()]if rank==0 else[(mu,mu)for mu in range(4)]):
                ww,sg=word(d,ass)
                if sg:col[ww]=col.get(ww,0)+sg*(-1 if metric and rank and ass[0]!=0 and vv[0]==vv[1]else 1)
            cols.append({(w,k):cv*value for w,cv in col.items()if cv for k,value in co.items()if cv*value})
        assert cols[0]==target and not row['complete_residual'];wrongmetric+=bool(v.delta(target,cols[1]));wrongsource+=bool(v.delta(target,cols[2]));domain={ww for ass in product(range(4),repeat=rank)for ww,sg in[word(d,ass)]if sg};assert row['canonical_component_domain']==len(domain)and row['zero_component_count']==len(domain)-len({w for w,k in target});domain_total+=len(domain)
    assert raw(rec['complete_reconstructed_density'])==Q and rec['match']and not rec['complete_residual']and rec['component_domain_count']==domain_total and rec['controls']==dict(wrong_metric_sensitive_groups=wrongmetric,wrong_source_variance_sensitive_groups=wrongsource,missing_first_rank4_pairing_sensitive_groups=0)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b11fa9f72d43109fa4da57b4449e300398838637'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation.json');assert prep==a.read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings.json');assert enc==a.read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    binding=a.read(O/'constructor_extension_binding.json');old=(B/'canonical_so10_augmented_metric_lift_v1/algebra.py').read_bytes();new=old
    for aa,bb in binding['exact_source_replacements']:assert new.count(aa.encode())==1;new=new.replace(aa.encode(),bb.encode())
    assert new==(O/'tensor_lift.py').read_bytes()and digest(B/'canonical_so10_augmented_metric_lift_v1/algebra.py')==binding['old_source_sha256']and digest(O/'tensor_lift.py')==binding['new_source_sha256']
    cap=a.read(O/'capture.json');assert cap==a.read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=a.read(O/'result.json');assert result['elapsed_after_imports']<180
    original='calculations/canonical_so10_cartan_generator_residual_g1_v1/fixed_ward_and_old_affine_endpoints.json.gz';assert digest(R/original)==a.read(B/'canonical_so10_marked_proper_Euler_reference_g1_v1/preparation_master_v2.json')['sha256'][original]=='9fd4994a2ebfbf6df6307bac64fe1047ca58743f3e78d82f84e180ab0baca4a5';cg=a.load(R/original);cg2=a.load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');assert p.old(cg['complete_K'])==p.old(cg2['complete_K'])and p.old(cg['complete_K_epsilon_normal'])==p.old(cg2['complete_K_epsilon_normal'])and {i:p.old(q)for i,q in cg['all1286_D']}=={i:p.old(q)for i,q in cg2['all1286_D']};summaries=[]
    for rr,owner in zip(result['roles'],['primary','replay']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));base_names=ch['all_current_names'][:1286]+['epsilon_M_'+str(i)for i in range(33)]+ch['all_current_names'][1286:];base_par=ch['all_current_parities'][:1286]+[1]*33+[0]*12;names=base_names+['h_'+n for n in base_names[:643]]+['k_'+n for n in base_names[:643]];pars=base_par+base_par[:643]+base_par[:643];A=a.Algebra(names,pars);assert names==z['joined_names']and pars==z['joined_parities'];assert all(par(i)==pars[i]for i in range(1331));assert TAG>K+643
        oldA=a.Algebra(ch['all_current_names'],ch['all_current_parities']);W=rename(A,a.decode(ch['complete_W']));assert rename(oldA,W,True)==a.decode(ch['complete_W']);c={i:rename(A,a.decode(q))for i,q in ch['all1286_source_difference_columns']};assert all(rename(oldA,c[i],True)==a.decode(q)for i,q in ch['all1286_source_difference_columns']);EW=v.allE(v.flat(a.encode(W)),pars);assert all(v.flat(a.encode(c[643+i]))==EW.get(i,{})for i in range(643));targets={i for i,q in c.items()if q};assert targets==set(z['C_source_target_ports'])==set(range(643,691))|set(range(1241,1253));Kraw=choose(p.old(cg['complete_K']),3);Kn=choose(p.old(cg['complete_K_epsilon_normal']),3);oldj=[choose(p.old(q),2)for q in cg['four_IBP_currents']];assert Kraw==a.decode(z['complete_K'])and Kn==a.decode(z['complete_K_normal'])and v.delta(v.flat(a.encode(Kraw)),v.flat(a.encode(Kn)))==div([v.flat(a.encode(q))for q in oldj],pars);EK=v.allE(v.flat(a.encode(Kraw)),pars);EN=v.allE(v.flat(a.encode(Kn)),pars);assert EK==EN;D={**{i:a.scale(grouped(EK.get(643+i,{})),-1)for i in range(643)},**{643+i:grouped(EK.get(i,{}))for i in range(643)}};assert D=={i:a.decode(q)for i,q in z['all1286_D']}=={i:choose(p.old(q),dim(i))for i,q in cg['all1286_D']};assert ports(Kraw)==set(z['K_source_ports'])==set(range(1253,1286))and not(ports(Kraw)&targets);assert not z['complete_C_KD']and not z['complete_C_KD_normal']and not any(z['all_C_KD_current_images']);assert all(not(ports(q)&targets)for q in oldj)
        activeD={i for i in range(643)if D[i]};assert activeD==set(range(610,643));assert all(D[i]==a.atom(1286+i-610)for i in activeD)
        for i in range(1286):
            assert not(ports(D[i])&targets)and not any(n in activeD or 643<=n<1286 for(g,w),co in c[i].items()for n,j in w);assert z['all1286_C_D_commutators'][i]==[i,[]]
            for mu in range(4):assert not(ports(a.derivative(A,D[i],mu))&targets)and not any(n in activeD or 643<=n<1286 for(g,w),co in a.derivative(A,c[i],mu).items()for n,j in w)
        wrong=pars[:];wrong[1319:1331]=[1]*12;violations=sum(sum(wrong[n]for n,j in w)%2!=pars[i]for i,q in c.items()for(g,w),co in q.items());assert violations==z['controls']['wrong_omega_parity_violations']>0 and z['controls']['CD_nonzero_columns']==z['controls']['DC_nonzero_columns']==0 and not z['controls']['commutator_sign_sensitive'];norms={};case_summaries=[]
        for case,q,nat in zip(['g0','g1','u0_H','u0_M','u1_H','u1_M'],z['all_carrier_support_gates'],z['all_natural_carrier_current_lifts']):
            old=a.load(B/'canonical_so10_marked_proper_Euler_reference_g1_v1'/(role+'_master_'+case+'.json.gz'));P=choose(p.old(old['complete_direct_DS_density']),4);N=choose(p.old(old['complete_DS_epsilon_normal']),4);savedj=[choose(p.old(r),3)for r in old['four_DS_currents']];Qraw=choose(p.old(old['complete_QKD_density']),4);Qnorm=choose(p.old(old['complete_QKD_epsilon_normal']),4);Qj=[choose(p.old(r),3)for r in old['four_QKD_currents']];assert not a.plus(N,Qnorm)and v.delta(v.flat(a.encode(P)),v.flat(a.encode(N)))==div([v.flat(a.encode(r))for r in savedj],pars)and v.delta(v.flat(a.encode(Qraw)),v.flat(a.encode(Qnorm)))==div([v.flat(a.encode(r))for r in Qj],pars);assert q['case']==nat['case']==case and P==a.decode(q['complete_raw_DS'])and N==a.decode(q['complete_normal_DS']);assert v.flat(a.encode(N))==epsilon_Euler(v.flat(a.encode(P)),pars);norms[case]=N;newj=[a.decode(r)for r in q['all_new_epsilon_currents']];assert savedj==[a.decode(r)for r in q['all_old_currents']]and v.delta(v.flat(a.encode(P)),v.flat(a.encode(N)))==div([v.flat(a.encode(r))for r in newj],pars)
            assert ports(P)==set(q['raw_source_ports'])and ports(N)==set(q['normal_source_ports'])and not((ports(P)|ports(N))&targets);assert all(not(ports(r)&targets)for r in savedj+newj)and not q['complete_C_raw']and not q['complete_C_normal']and not any(q['all_C_old_current_images'])and not any(q['all_C_new_current_images'])and q['classification']=='ZERO_DENSITY'
            PM=unwick(v.flat(a.encode(P)));NM=unwick(v.flat(a.encode(N)));difference=v.delta(PM,NM);assert difference==raw(nat['complete_Minkowski_difference']);curr=[raw(r)for r in nat['all_four_natural_Minkowski_currents']];par_current=list(base_par)+[0]*(TAG+4-len(base_par));assert div(curr,par_current)==difference;tag={}
            for mu,r in enumerate(curr):
                for(w,k),cv in r.items():
                    ww,sg=canon(w+((TAG+mu,()),))
                    if sg:v.add(tag,(ww,k),sg*cv)
            assert tag==raw(nat['complete_tagged_current']);tensor(tag,nat['fixed_tensor_lift']);case_summaries.append(dict(case=case,raw_words=len(P),normal_words=len(N),C_raw_normal_and_current_images_zero=True,natural_current_words=[len(r)for r in nat['all_four_natural_Minkowski_currents']]))
        DS=a.plus(norms['g0'],norms['g1']);DU={probe:a.plus(norms['u0_'+probe],norms['u1_'+probe])for probe in['H','M']};assert all(not q for q in DU.values())and all(not row['raw_words']for row in case_summaries if row['case'].startswith('u'));lifted=a.load(B/'canonical_so10_geometric_metric_insertion_lift_v1'/(role+'_complete_geometric_metric_insertions.json.gz'));geo={q['name']:rename(A,a.decode(q['complete_Euclidean']))for q in lifted['all_fixed_density_roots']};polys={'KD':Kn,'DS':DS,'DU_H':DU['H'],'DU_M':DU['M'],'C_S':geo['C_S'],'C_U_H':geo['C_U_H'],'C_U_M':geo['C_U_M']};profiles={}
        for name,P in polys.items():
            HH=kernel(P,pars);assert HH==v.flat(z['complete_ordered_h_k_kernels'][name]);profiles[name]={str(g):sum(gg==g for gg,w in grouped(HH))for g in[0,1]}
        assert profiles==z['kernel_grade_profiles']==rr['kernel_grade_profiles'];mix={}
        for x,y in[('C_S','KD'),('C_S','DS'),('C_U_H','DS'),('C_U_M','DS')]:
            degrees=sorted({g+h for g in[0,1]if profiles[x][str(g)]for h in[0,1]if profiles[y][str(h)]});mix[x+'__'+y]=dict(possible_known_root_grade_sums=degrees,lowest_possible_from_qualified_kernels=min(degrees)if degrees else None,actual_amplitude_NOT_evaluated=True,higher_grade_direct_roots_NOT_qualified=True)
        assert mix==z['mixed_covariance_grade_support']==rr['mixed_covariance_grade_support']and mix['C_S__KD']['lowest_possible_from_qualified_kernels']==1 and mix['C_S__DS']['lowest_possible_from_qualified_kernels']==2;summaries.append(dict(role=role,KD_and_all1286_D_authenticated=True,all1286_C_D_and_firstjets_zero=True,commutator_sign_control_BLIND=True,wrong_omega_type_sensitive=violations,carriers=case_summaries,kernel_grade_profiles=profiles,leading_known_rho_theta_covariance_grade=1,leading_known_beta_rho_theta_covariance_grade=2,actual_quantum_value_NOT_calculated=True));print('STAGE '+role+' independent_support_normals_currents_and_kernel_grades_verified',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V861.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V861.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V861.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2;files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V861.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_GEOMETRIC_MARKED_CLASSICAL_SUPPORT_AND_LEADING_KERNEL_GRADES',base_HEAD=head,state_sha256=state,roles=summaries,unprefixed_historical_owner_binding_preserved=True,DU_fixed_all_D_root_zero_and_support_proof_reviewed=True,common_functional_covariances_and_marked_geometric_RHS_RETAINED=True,joint_five_grade_domains_profiles_normalizations_full_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_input_codec_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
