from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import permutations
from collections import Counter
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-marked-contact-support-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V861_FROZEN_COEFFICIENT_ACTION_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
import tensor_lift as m
H=1331;K=1974
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def dim(n):return 3-dim(n-643)if 643<=n<1286 else 2 if 508<=n<553 else 1 if n<1319 else 0 if n<1331 else dim(n-H)if H<=n<K else dim(n-K)
def choose(P,D):return{k:cv for k,cv in P.items()if k[0]<=1 and 0<=D-sum(dim(n)+len(js)for n,js in k[1])<=1}
def rename(A,P,reverse=False):
    out={}
    for(g,w),co in P.items():
        if reverse:assert all(n<1286 or 1319<=n<1331 for n,js in w)
        else:assert all(n<1298 for n,js in w)
        ww,sg=A.canonical(tuple((n-33 if reverse and n>=1319 else n+33 if not reverse and n>=1286 else n,js)for n,js in w));assert sg==1;a.put(out,(g,ww),co)
    return out
def flat(P):return {(w,(g,x,e,mask)):cv for(g,w),co in P.items()for(x,e,mask),cv in co}
def ports(P):return sorted({n for(g,w),co in P.items()for n,js in w if 643<=n<1286})
def act(A,P,rules,role):return p.action(A,P,rules,role)
def epsilon_normal(A,P,role):
    N={};cur=[{}for mu in range(4)]
    for(g,w),co in P.items():
        ee=[(at,n,js)for at,(n,js)in enumerate(w)if 1286<=n<1319];assert len(ee)==1;at,n,js=ee[0];sg=(-1)**sum(A.parities[i]for i,j in w[:at]);orders=sorted(set(permutations(js)))or[()]if role=='native'else list(permutations(js))or[()]
        for order in orders:
            jj=list(order);rest={(g,w[:at]+w[at+1:]):a.scale_coefficient(co,F(sg,len(orders)))}
            while jj:
                mu=jj.pop();term=A.product(a.atom(n,tuple(sorted(jj))),rest)
                for k,cv in term.items():a.put(cur[mu],k,cv)
                rest=a.scale(a.derivative(A,rest,mu),-1)
            for k,cv in A.product(a.atom(n),rest).items():a.put(N,k,cv)
    assert a.plus(P,a.scale(N,-1))==p.divergence(A,cur);return N,cur
def hamiltonian(A,P):
    E=a.eulers(A,P,set(range(1286)));return{**{i:a.scale(E.get(643+i,{}),-1)for i in range(643)},**{643+i:E.get(i,{})for i in range(643)}}
def kernel(A,P,role):return A.action(A.action(P,{i:H+i for i in range(643)},method='slot'if role=='native'else'left'),{i:K+i for i in range(643)},method='slot'if role=='native'else'left')
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    cg=B/'canonical_so10_cartan_generator_residual_g1_v1';older=a.load(cg/'fixed_ward_and_old_affine_endpoints.json.gz');newer=a.load(cg/'v2_fixed_ward_and_old_affine_endpoints.json.gz')
    for key in['complete_K','complete_K_epsilon_normal']:assert p.old(older[key])==p.old(newer[key])
    assert {i:p.old(q)for i,q in older['all1286_D']}=={i:p.old(q)for i,q in newer['all1286_D']};reports=[]
    for role,owner in[('native','primary'),('replay','replay')]:
        ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));names=ch['all_current_names'][:1286]+['epsilon_M_'+str(i)for i in range(33)]+ch['all_current_names'][1286:];pars=ch['all_current_parities'][:1286]+[1]*33+[0]*12;A=a.Algebra(names+['h_'+s for s in names[:643]]+['k_'+s for s in names[:643]],pars+pars[:643]+pars[:643]);oldA=a.Algebra(ch['all_current_names'],ch['all_current_parities']);W=rename(A,a.decode(ch['complete_W']));assert rename(oldA,W,True)==a.decode(ch['complete_W']);c={i:rename(A,a.decode(q))for i,q in ch['all1286_source_difference_columns']};EW=a.eulers(A,W,set(range(643)));assert all(c[643+i]==EW.get(i,{})for i in range(643));Kraw=choose(p.old(newer['complete_K']),3);Kn=choose(p.old(newer['complete_K_epsilon_normal']),3);Koldcurr=[choose(p.old(q),2)for q in newer['four_IBP_currents']];assert a.plus(Kraw,a.scale(Kn,-1))==p.divergence(A,Koldcurr);D=hamiltonian(A,Kraw);assert D==hamiltonian(A,Kn)=={i:choose(p.old(q),dim(i))for i,q in newer['all1286_D']}
        assert all(rename(oldA,c[i],True)==a.decode(q)for i,q in ch['all1286_source_difference_columns']);wrong_pars=list(A.parities);wrong_pars[1319:1331]=[1]*12;wrong_omega=sum(sum(wrong_pars[n]for n,js in w)%2!=A.parities[i]for i,qq in c.items()for(g,w),co in qq.items());assert wrong_omega>0
        CK=act(A,Kraw,c,owner);CKn=act(A,Kn,c,owner);CKj=[act(A,q,c,owner)for q in Koldcurr];assert a.plus(CK,a.scale(CKn,-1))==p.divergence(A,CKj);Dmix=hamiltonian(A,CK);comm=[];CDcount=DCcount=0
        for i in range(1286):
            CD=act(A,D[i],c,owner);DC=act(A,c[i],D,owner);CDcount+=bool(CD);DCcount+=bool(DC);q=a.plus(CD,a.scale(DC,-1));assert q==Dmix[i],('CANONICAL_EVEN_COMMUTATOR_MISMATCH',i)
            for mu in range(4):assert a.plus(act(A,a.derivative(A,D[i],mu),c,owner),a.scale(act(A,a.derivative(A,c[i],mu),D,owner),-1))==a.derivative(A,Dmix[i],mu)
            comm.append([i,a.encode(q)])
        gate=[];norms={};current_lifts=[]
        for case in['g0','g1','u0_H','u0_M','u1_H','u1_M']:
            z=a.load(B/'canonical_so10_marked_proper_Euler_reference_g1_v1'/(role+'_master_'+case+'.json.gz'));raw=choose(p.old(z['complete_direct_DS_density']),4);norm=choose(p.old(z['complete_DS_epsilon_normal']),4);saved=[choose(p.old(q),3)for q in z['four_DS_currents']];Qn=choose(p.old(z['complete_QKD_epsilon_normal']),4);assert not a.plus(norm,Qn)and a.plus(raw,a.scale(norm,-1))==p.divergence(A,saved);N,j=epsilon_normal(A,raw,role);assert N==norm;CN=act(A,norm,c,owner);CR=act(A,raw,c,owner);CJ=[act(A,q,c,owner)for q in saved];Cnew=[act(A,q,c,owner)for q in j];assert a.plus(CR,a.scale(CN,-1))==p.divergence(A,CJ)==p.divergence(A,Cnew)
            # The new natural current is typed separately from h/k fluctuations.
            MM=m.unwick(flat(raw));MN=m.unwick(flat(norm));diff=m.add(MM,m.scale(MN,-1));zero,natural=m.sym_normal(diff);assert not zero;tag=m.tag_current(natural);lift=m.reconstruct(tag,role);assert lift['match'];current_lifts.append(dict(case=case,complete_Minkowski_difference=m.encode(diff),all_four_natural_Minkowski_currents=[m.encode(q)for q in natural],complete_tagged_current=m.encode(tag),fixed_tensor_lift=lift))
            gate.append(dict(case=case,complete_raw_DS=a.encode(raw),complete_normal_DS=a.encode(norm),all_old_currents=[a.encode(q)for q in saved],all_new_epsilon_currents=[a.encode(q)for q in j],raw_source_ports=ports(raw),normal_source_ports=ports(norm),complete_C_raw=a.encode(CR),complete_C_normal=a.encode(CN),all_C_old_current_images=[a.encode(q)for q in CJ],all_C_new_current_images=[a.encode(q)for q in Cnew],classification='ZERO_DENSITY'if not CR else'ZERO_FUNCTIONAL_EXPLICIT_CURRENT'if not CN else'NONZERO_NORMAL_MIXED_ROOT_RETAINED'));norms[case]=norm
        DS=a.plus(norms['g0'],norms['g1']);DU={probe:a.plus(norms['u0_'+probe],norms['u1_'+probe])for probe in['H','M']};roots0=a.load(B/'canonical_so10_geometric_metric_insertion_lift_v1'/(role+'_complete_geometric_metric_insertions.json.gz'));roots={q['name']:rename(A,a.decode(q['complete_Euclidean']))for q in roots0['all_fixed_density_roots']};polys={'KD':Kn,'DS':DS,'DU_H':DU['H'],'DU_M':DU['M'],'C_S':roots['C_S'],'C_U_H':roots['C_U_H'],'C_U_M':roots['C_U_M']};HH={n:kernel(A,q,role)for n,q in polys.items()};profiles={n:{str(g):sum(gg==g for gg,w in q)for g in[0,1]}for n,q in HH.items()};mix={}
        for x,y in[('C_S','KD'),('C_S','DS'),('C_U_H','DS'),('C_U_M','DS')]:
            available=sorted({g+h for g in[0,1]if int(profiles[x][str(g)])for h in[0,1]if int(profiles[y][str(h)])});mix[x+'__'+y]=dict(possible_known_root_grade_sums=available,lowest_possible_from_qualified_kernels=min(available)if available else None,actual_amplitude_NOT_evaluated=True,higher_grade_direct_roots_NOT_qualified=True)
        artifact=save(role+'_complete_geometric_marked_contact_support.json.gz',dict(joined_names=list(A.names),joined_parities=list(A.parities),K_source_ports=ports(Kraw),C_source_target_ports=sorted(i for i,q in c.items()if q),complete_K=a.encode(Kraw),complete_K_normal=a.encode(Kn),all1286_D=[[i,a.encode(D[i])]for i in range(1286)],complete_C_KD=a.encode(CK),complete_C_KD_normal=a.encode(CKn),all_C_KD_current_images=[a.encode(q)for q in CKj],all1286_C_D_commutators=comm,all_carrier_support_gates=gate,all_natural_carrier_current_lifts=current_lifts,complete_ordered_h_k_kernels={n:a.encode(q)for n,q in HH.items()},kernel_grade_profiles=profiles,mixed_covariance_grade_support=mix,controls=dict(wrong_omega_parity_violations=wrong_omega,CD_nonzero_columns=CDcount,DC_nonzero_columns=DCcount,commutator_sign_sensitive=bool(CDcount or DCcount)),full_interacting_G0_NOT_replaced=True,tree_zero_does_NOT_imply_mixed_quantum_zero=True))
        reports.append(dict(role=role,artifact=artifact,CKD_density_words=len(CK),nonzero_CD_commutator_columns=sum(bool(q)for i,q in comm),carrier_gates=[dict(case=q['case'],normal_words=len(q['complete_normal_DS']),C_raw_words=len(q['complete_C_raw']),C_normal_words=len(q['complete_C_normal']),classification=q['classification'])for q in gate],kernel_grade_profiles=profiles,mixed_covariance_grade_support=mix));print('STAGE '+role+' mixed_classical_support_and_kernel_grade_gates_complete',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='GEOMETRIC_MARKED_CLASSICAL_CONTACT_SUPPORT_AND_LEADING_KERNEL_GRADES_CLASSIFIED',roles=reports,joint_five_grade_UV_IR_and_quantum_profiles_NOT_qualified=True,common_Frechet_covariance_terms_NOT_erased=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
