from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from itertools import product,permutations
from collections import Counter,defaultdict
import gzip,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-marked-critical-words-v1-2026-11-08')
H=1331;K=1974
def read(q):return json.loads(q.read_bytes())
def load(q):return json.loads(gzip.decompress(q.read_bytes()))
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def dimension(n):
    if 643<=n<1286:return 3-dimension(n-643)
    if 508<=n<553:return 2
    if 1319<=n<1331:return 0
    assert 0<=n<1319
    return 1
def sector(n):
    assert 0<=n<643
    if n<180:return 'H'if n//4<12 else'M'
    if n<508:return 'X'
    if n<553:return 'H'if n<520 else'M'
    if n<598:return 'H'if n<565 else'M'
    return 'H'if n<610 else'M'
def parity(n):return int(n>=553)
def root_audit(rows,g,epsilon):
    complete=[];sets=defaultdict(set)
    for at,(gg,ww,cells)in enumerate(rows):
        if gg!=g:continue
        assert all(Fraction(num,den) for key,num,den in cells)
        hs=[x for x in ww if H<=x[0]<K];ks=[x for x in ww if K<=x[0]<K+643];assert len(hs)==len(ks)==1
        i,ji=hs[0][0]-H,hs[0][1];j,jj=ks[0][0]-K,ks[0][1];remaining=[x for x in ww if x[0]<H]
        q=len(ji)+len(jj);cost=(2-dimension(i))+(2-dimension(j))-q
        eps=sum(1286<=n<1319 for n,js in remaining);omega=sum(1319<=n<1331 for n,js in remaining)
        assert(eps,omega)==((1,0)if epsilon else(0,1))
        complete.append([at,i,j,q,cost,parity(i),parity(j),remaining]);sets[str(cost)].add((i,j))
    return complete,{c:[list(x)for x in sorted(v)]for c,v in sets.items()}
def parent_audit(parent):
    low=[];sets=defaultdict(set);hist=Counter();block=Counter()
    for row in parent['all_density_words_and_ports']:
        w=row['complete_word'];D=row['declared_density_dimension'];assert D==4
        intrinsic=D-sum(dimension(n)+len(js)for n,js in w);assert intrinsic==row['intrinsic_coefficient_dimension']>=0
        positions=[j for j,(n,js)in enumerate(w)if n<643];ports=[]
        for a,b in product(positions,repeat=2):
            if a>=b:continue
            i,ji=w[a];j,jj=w[b];rest=[x for at,x in enumerate(w)if at!=a and at!=b]
            cost=intrinsic+sum(dimension(n)+len(js)for n,js in rest)
            assert cost==4-dimension(i)-dimension(j)-len(ji)-len(jj)>=0
            labs=[sum(n<643 for n,js in rest),sum(643<=n<1286 for n,js in rest),sum(1286<=n<1319 for n,js in rest)]
            ports.append([a,b,i,j,len(ji)+len(jj),cost,cost,labs]);hist[cost]+=1;block[cost,min(parity(i),parity(j)),max(parity(i),parity(j))]+=1
            if cost<=1:
                low.append([row['density_word_index'],a,b,i,j,len(ji)+len(jj),cost,parity(i),parity(j),rest]);sets[str(cost)].update([(i,j),(j,i)])
        assert ports==row['all_two_ordinary_port_positions']
    assert sorted([c,n]for c,n in hist.items())==parent['defect_histogram']
    return low,{c:[list(x)for x in sorted(v)]for c,v in sets.items()},[[list(k),n]for k,n in sorted(block.items())]
def exhaustive_words():
    # Independent bounded-token grammar; completeness follows from mandatory cost3.
    cost={'CS':1,'CU_H':1,'CU_M':1,'K0':2,'S01':1,'U0_H':0,'U0_M':0,'U1_H':1,'U1_M':1}
    alphabet=['K0','S01','U0_H','U0_M','U1_H','U1_M'];out={}
    for first in['CS','CU_H','CU_M']:
        for n in range(2,5):
            for tail in product(alphabet,repeat=n-1):
                w=(first,)+tail
                if w.count('K0')!=1 or sum(cost[x]for x in w)>4:continue
                u=int(first!='CS')+sum(x.startswith('U')for x in tail)
                if u>1:continue
                probe=first[-1]if first!='CS'else next((x[-1]for x in tail if x.startswith('U')),'none')
                kind='direct_CU'if first!='CS'else'ordinary_U_covariance'if u else'unprobed_covariance'
                out[w]=(bool(u),probe,kind,sum(cost[x]for x in w))
    assert len(out)==29 and max(map(len,out))==4
    return out
def graph_returns(edges,word):
    graph={}
    for name,ee in edges.items():
        graph[name]=defaultdict(set)
        for i,j in ee:graph[name][i].add(j)
    answer=[]
    for start in range(643):
        reachable={start}
        for letter in word:reachable={j for i in reachable for j in graph[letter].get(i,set())}
        answer.append(start in reachable)
    return answer
def formal_program():
    def cyclic(w):
        at=w.index('A');return w[at:]+w[:at]
    observed=defaultdict(Fraction)
    for w in permutations(('A','K')):observed[cyclic(w)]+=Fraction(-1,2)
    assert dict(observed)=={('A','K'):Fraction(-1)}
    triple=defaultdict(Fraction)
    for w in permutations(('A','U','K')):triple[cyclic(w)]+=Fraction(1,3)
    assert dict(triple)=={('A','U','K'):Fraction(1),('A','K','U'):Fraction(1)}
    assert {('A','U','K'):Fraction(1)}!=dict(triple)
    assert {('A','K'):Fraction(1)}!=dict(observed)
    return dict(converted_g_terms=1,converted_gu_inverse_placements=2,converted_gu_direct_CU_terms=1,omitted_inverse_placement_control_sensitive=True,wrong_direct_sign_control_sensitive=True,rho_total_even_Hessian_convention_inherited=True,raw_heat_cyclicity_NOT_inferred=True)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='31216362887eb4a35b14deb9b1259a1ba02368ac'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    prep=read(O/'preparation.json');assert prep==read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved.get(n,R/n))==h,n
    enc=read(O/'input_encoding_bindings.json');assert enc==read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=saved.get(n,R/n).read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
        assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(blob).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==blob)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==blob)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=blob:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    fail=read(O/'launch_failure.json');assert fail==read(C/'launch_failure.json')and fail['execution_state']=='FAILED'and not fail['worker_launched']and fail['exit_code']==1 and fail['source_sha256']==digest(O/'execute.py')and'validation_receipt.json'in fail['stderr']
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);res=read(O/'result.json');assert res['elapsed_after_imports']<120
    expected=exhaustive_words();summaries=[]
    for rr in res['roles']:
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=load(O/art['file'])
        source=load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'));uv=load(B/'canonical_so10_augmented_uv_grading_v1'/(role+'_complete_UV_grading_v2.json.gz'));ir=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_complete_operator_ir_audit.json.gz'))
        G=[(i,j)for i,j,s,p in ir['actual_free_Green_bounds']['complete_nonzero_Green_with_soft_orders']];assert len(G)==1498 and[list(x)for x in G]==z['all1498_reference_Green_edges']and all(parity(i)==parity(j)and sector(i)==sector(j)for i,j in G)
        sets={}
        for name,key,g,eps in[('K0','KD',0,True),('CS','C_S',1,False),('CU_H','C_U_H',1,False),('CU_M','C_U_M',1,False)]:
            rows,pp=root_audit(source['complete_ordered_h_k_kernels'][key],g,eps);assert rows==z['all_marked_geometric_kernel_cost_label_rows'][name]and pp==z['all_root_pairs_by_cost'][name];sets[name]=pp
            if name=='K0':assert set(pp)=={'2'}and all(i>=553 and j>=553 and sector(i)==sector(j)=='M'for i,j in pp['2'])
            elif name=='CU_M':assert not rows
            else:assert set(pp)=={'1'}and all(sector(i)==sector(j)=='H'for i,j in pp['1'])
        parents={p['density']:p for p in uv['all_literal_parent_density_ports']};base=set()
        for name in['S0_GF_source','physical_S0_gauge','physical_S0_scalar','U0_H','U0_M']:
            rows,pp,hist=parent_audit(parents[name]);assert rows==z['all_parent_low_cost_ports'][name]and hist==z['complete_parent_cost_parity_histograms'][name]
            if name.startswith('U0_'):
                probe=name[-1];sets['U0_'+probe]={'0':pp.get('0',[])};sets['U1_'+probe]={'1':pp.get('1',[])}
                assert sets['U0_'+probe]==z['all_root_pairs_by_cost']['U0_'+probe]and sets['U1_'+probe]==z['all_root_pairs_by_cost']['U1_'+probe]
            else:base.update(tuple(x)for x in pp.get('1',[]))
        sets['S01']={'1':[list(x)for x in sorted(base)]};assert sets['S01']==z['all_root_pairs_by_cost']['S01']and uv['complete_positive_cost_unlabeled_base_ports']==[]
        for term,degrees in uv['all29_physical_potential_degrees']:
            assert all(n>=2 and d>=0 and n+d==4 and(n-2)+d==2 for n,d in degrees)
        assert len(uv['all29_physical_potential_degrees'])==29
        for name,costs in sets.items():
            assert all(sector(i)==sector(j)for pp in costs.values()for i,j in pp)
        Gcolumn=defaultdict(set)
        for i,j in G:Gcolumn[j].add(i)
        edges={name:sorted({(a,j)for pp in costs.values()for i,j in pp for a in Gcolumn[i]})for name,costs in sets.items()}
        assert {n:[list(x)for x in ee]for n,ee in edges.items()}==z['all_conservative_G_H_edges']
        abstract={name:sorted({(sector(i),sector(j))for i,j in ee})for name,ee in edges.items()}
        assert abstract['CS']==[('H','H')]and abstract['K0']==[('M','M')]and abstract['CU_H']==[('H','H')]and abstract['CU_M']==[]
        assert all(i==j for ee in abstract.values()for i,j in ee)
        observed={tuple(q['word']):q for q in z['all_critical_words']};assert set(observed)==set(expected)
        for word,(u,probe,kind,cost)in expected.items():
            q=observed[word];assert(q['first_u'],q['probe'],q['kind'],q['total_cost'])==(u,probe,kind,cost)
            assert len(q['complete643_returning_support_walk_counts'])==643 and not any(q['complete643_returning_support_walk_counts'])and q['total_returning_support_walks']==0
            assert not any(graph_returns(edges,word))
        # Erasing INTERNAL sectors retains a ghost CS/K closed support cycle.
        loose_CS={(parity(i),parity(j))for i,j in edges['CS']};loose_K={(parity(i),parity(j))for i,j in edges['K0']}
        control=any((b,a)in loose_K for a,b in loose_CS);assert control
        assert z['synthetic_removed_crossing_budget_control_sensitive']and graph_returns({'A':[(0,1)],'K':[(1,1)],'V':[(1,0)]},['A','K','V'])[0]
        assert rr['first_u_all_support_walks_zero']and rr['unprobed_all_support_walks_zero']and rr['critical_word_count']==29 and not rr['nonempty_critical_words']
        summaries.append(dict(role=role,all1498_Green_edges_parity_and_internal_projectors_preserved=True,complete29_critical_words_independently_rebuilt=True,all_returning_support_zero=True,internal_projector_proof_before_D_continuation=True,erased_sector_control_sensitive=control,unknown_scalar_potential_cost_lower_bound=2,full_interacting_nonlocal_covariance_NOT_evaluated=True));print('STAGE '+role+' independent_complete_budget_and_internal_projector_proof_verified',flush=True)
    program=formal_program();assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V862.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V862.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V862.md').read_text()),(O/'RESULT.md',(O/'RESULT.md').read_text())]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V862.md']
    receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_CRITICAL_LOCAL_MIXED_CONVERSION_ZERO_IN_PROSPECTIVE_COMMON_MAP',base_HEAD=head,state_sha256=state,roles=summaries,formal_operator_program=program,IR_ordinary_two_label_domain_and_UV_remainder_proof_reviewed=True,actual_whole_profile_normalizations_full_covariance_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_inputs_conventions_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick)
    dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
