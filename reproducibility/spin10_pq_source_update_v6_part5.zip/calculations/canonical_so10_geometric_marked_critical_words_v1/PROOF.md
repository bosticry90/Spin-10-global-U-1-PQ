# The mixed local conversion has no critical returning word

This proof requires completed separate final validation. It concerns the
prospective common formal heat/converted functional in the unshifted bosonic
chart,first g,first H/M u,intrinsic01,with independent local omega and epsilon.
It does not identify every recovered actual regulator profile with that family.

## The actual operator, before a local restriction

V861 removes the explicit C(KD) direction. The remaining coefficient is
F''[CS+uCU,KD]. Write G0 for the FULL inverse of H_S0,including its ordinary
ghost and auxiliary backgrounds. In the admitted converted cyclic map,at
first g the operator program is

    -(i/2) T_kappa[G0 H_CS1 G0 H_K0].

At first gu its program is

    (i/2) T_kappa[
      G0 H_U0 G0 H_CS1 G0 H_K0
     +G0 H_CS1 G0 H_U0 G0 H_K0
     -G0 H_CU1 G0 H_K0].

Both inverse variations and the direct CU root are necessary. H_CS0 and
H_CU0 are zero by the complete V861 kernels,so K1 and U1 cannot enter this
coefficient. Keep rho with the odd K coefficient until the total Gaussian
perturbation is even; the formula is not an unsigned Hessian convention.
The cyclic program is for the converted map. Raw heat retains the complete
ordered word derivative,its heat lengths and its actual regulator defects.

These programs are not new amplitudes. In particular,the full G0 has not
been replaced by the free reference inverse.

## Why the local search is finite

For quantum ports i,j with total leg derivative order q,relative UV cost is
delta=4-di-dj-q. Every actual K0 position has cost2 and ghost ports; every
CS1/CU1 position has cost1. Their required sum is3. Derivatives moved onto
coefficients during adjoints can only increase cost. This gives an upper
support bound without discarding any cancellation or derivative placement.

V851 absorbs the complete ungraded marginal base into the reference. Every
remaining ungraded base root has positive cost. Therefore a local word of
order at least-4 can contain at most one extra cost1 S0 root. At first u it
also contains exactly one U0 root: either cost0,with the optional S0 cost1,
or cost1,with no further positive-cost root. A direct CU root replaces CS
and consumes u itself. No other g insertion can occur because CS1/CU1
already consumes the one g degree. No inverse coupling is used.

Rooting a cycle at its unique geometric root gives exactly29 ordered word
types. Without u there are CS,K and its two S01 placements. For each probe
the ordinary-U part has two cost0-U placements,six placements with both
cost0-U and S01,and two cost1-U placements. Each direct-CU part has its
two-root word and two S01 placements. Maximum length is4. This is a bound
on the LOCAL subtraction/conversion only,not on the full Born determinant.

Rooting here rotates a CLOSED SUPPORT WALK to choose its starting vertex;
it does not use cyclicity of a raw finite-heat trace. In the frozen packet,
U1_H/U1_M name the COST1 parts of U0. They are not the coupling-order U1,
which cannot enter after CS1/CU1 consumes the available g degree.

The complete literal S0/U0 ledgers are reconstructed; no proposed background
term is silently ignored. Unknown physical scalar potentials are retained.
Their actual AST has degree plus coefficient dimension4,scalar fields of
dimension1,and no derivatives: every ordinary Hessian root therefore costs2.
They cannot fit the one remaining cost unit. Positive scalar reference-mass
differences also cost2. No physical mass or width is inverted.

## An internal-color proof, valid before continuing D

The complete low-cost ledgers give the following quantum-port supports:

| Root | Cost | Support |
| --- | --- | --- |
| CS1 | 1 | H vector/auxiliary or H ghost/antighost |
| CU_H1 | 1 | H vector/auxiliary |
| CU_M1 | — | Empty |
| K0 | 2 | M ghost/antighost |
| S01 | 1 | M auxiliary/ghost or auxiliary/antighost |
| U_H0 | 0 | H vector/auxiliary |
| U_M0 | 0 | M vector/auxiliary |
| U_H0 cost1 part | 1 | Empty |
| U_M0 cost1 part | 1 | M vector/auxiliary with M ghost/antighost |

All1498 actual reference edges preserve the H/M projectors and field parity.
Thus the CS/CU side is supported in H,and K0 in M. Every additional root
allowed by the complete critical budget also preserves H or M. A returning
word containing both H and M projections is identically zero. The worker
checks every643 diagonal support count by sparse products and an independent
target recursion. All29 words are empty in both input routes.

The decisive proof uses INTERNAL color projectors,not a cancellation between
four Lorentz components. H/M projectors commute with the reference for every
D and all its reference/clock/heat factors. Restoring unrestricted vector
indices does not create an H-to-M edge. Hence each critical word is zero in
the fixed all-D constructor,including its first dimension jet. This does
not erase any closed quantum D factor in a surviving word or infer a D-jet
zero merely from a four-dimensional coefficient zero.

Final verification also removes the sector labels as a negative control.
Then the ghost CS/K support can return. The zero is sensitive to the actual
sector restriction,not an inability of the detector to recognize a cycle.
The synthetic crossing-budget control is separate and also sensitive.

## Joint IR eligibility and the meaning of the local zero

Omega and epsilon are distinct genuine Schwartz labels at the two ordinary
Hessian insertion nodes. They are not two unlabeled Q tangents. Constant u,
rho and theta supply no extra momentum transfer. V850's whole constant-chain
collapse still bounds every remaining ordinary free edge by pole2. With
the independent label transfers,the loop/node submersion gives a locally L1
joint kernel,including the one-node case. Adjoints differentiate a retained
label rather than remove it. All interacting background chains remain.

Use the same free-edge proof approximants and uniform UV-subtracted hard-shell
remainder as the qualified domain theorem,with UV finite part before IR
removal. Do not restrict external momenta or make omega/epsilon constant
inside an IR integral. The old nonlocal Born series is still coefficientwise;
infinite resummation or a physical shifted vacuum is not inferred.

In the prospective common formal family,the local conversion is determined
by the finitely many critical symbols and their dimension/heat-power jets.
Every such mixed word is identically zero here;higher-cost words have the
common convergent trace and give no heat-to-converted local difference.
Therefore the local conversion's mixed rho-theta coefficient is zero at
g1 and gu1 in this scope. No new angular or momentum integral is needed.

This is NOT F''[CS,KD]=0. Higher-cost background words can contribute to
the shared finite/nonlocal covariance. Neither independent composite-product
normalization nor an unknown amplitude has been assigned a favorable value.
Actual recovered-heat identification outside V847's selected-M profile,
fixed V833/V834 normalization compatibility and the full contact prescription
remain unresolved. Even a first-u M target does not grant that profile match.

The geometric marked Ward still includes the whole [T KD] insertion with
epsilon fixed,and the raw measure/heat defect. C is not geometric T.
Full background,QAP,measure,A5,E5 and physical viability remain open.
Same action,inputs,conventions,software and AI authorship limit independence;
there is no formal proof-assistant or experimental validation.
