from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import permutations
import gzip,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-marked-critical-words-v1-2026-11-08')
H=1331;K=1974
def read(q):return json.loads(q.read_bytes())
def load(q):return json.loads(gzip.decompress(q.read_bytes()))
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def dim(n):return 3-dim(n-643)if 643<=n<1286 else 2 if 508<=n<553 else 1 if n<1319 else 0
def parity(n):assert 0<=n<643;return int(n>=553)
def pairs(rows):return sorted({(i,j)for i,j in rows})
def costs_kernel(rows,g,label):
    records=[];by=defaultdict(set)
    for at,(gg,w,co)in enumerate(rows):
        if gg!=g:continue
        hs=[(n-H,js)for n,js in w if H<=n<K];ks=[(n-K,js)for n,js in w if K<=n<K+643];assert len(hs)==len(ks)==1
        i,ji=hs[0];j,jj=ks[0];rem=[(n,js)for n,js in w if n<H];cost=4-dim(i)-dim(j)-len(ji)-len(jj);assert cost>=0
        actual=[(n,js)for n,js in rem if 1286<=n<1319]if label=='epsilon'else[(n,js)for n,js in rem if 1319<=n<1331];assert len(actual)==1
        assert not any((1319<=n<1331 if label=='epsilon'else 1286<=n<1319)for n,js in rem)
        records.append([at,i,j,len(ji)+len(jj),cost,parity(i),parity(j),rem]);by[cost].add((i,j))
    return records,{c:pairs(v)for c,v in sorted(by.items())}
def parent_ports(row):
    records=[];by=defaultdict(set);hist=Counter();block=Counter()
    for z in row['all_density_words_and_ports']:
        w=z['complete_word'];co=z['complete_coefficient_cells'];assert any(k[0]==0 and num for k,num,den in co)
        ports=[at for at,(n,js)in enumerate(w)if n<643];D=z['declared_density_dimension'];intrinsic=D-sum(dim(n)+len(js)for n,js in w);assert intrinsic==z['intrinsic_coefficient_dimension']>=0;rebuilt=[]
        for x,at in enumerate(ports):
            for bt in ports[x+1:]:
                i,ji=w[at];j,jj=w[bt];rem=[t for p,t in enumerate(w)if p not in[at,bt]];cost=4-dim(i)-dim(j)-len(ji)-len(jj);cc=4-D+intrinsic+sum(dim(n)+len(js)for n,js in rem);assert cc==cost>=0
                labels=[sum(n<643 for n,js in rem),sum(643<=n<1286 for n,js in rem),sum(1286<=n<1319 for n,js in rem)];rebuilt.append([at,bt,i,j,len(ji)+len(jj),cost-(4-D),cost,labels]);hist[cost]+=1;block[cost,min(parity(i),parity(j)),max(parity(i),parity(j))]+=1
                if cost<=1:
                    records.append([z['density_word_index'],at,bt,i,j,len(ji)+len(jj),cost,parity(i),parity(j),rem]);by[cost].update([(i,j),(j,i)])
        assert rebuilt==z['all_two_ordinary_port_positions']
    assert sorted([c,n]for c,n in hist.items())==row['defect_histogram']
    return records,{c:pairs(v)for c,v in sorted(by.items())},[[list(k),n]for k,n in sorted(block.items())]
def endomorphism(G,P):
    # H legs (i,j),then G output a from i: (G H)[a,j].
    gg=defaultdict(set)
    for a,i in G:gg[i].add(a)
    return sorted({(a,j)for i,j in P for a in gg[i]})
def matrix(edges):
    out=defaultdict(dict)
    for i,j in edges:out[i][j]=1
    return dict(out)
def mul(A,B):
    out={}
    for i,row in A.items():
        rr={}
        for j,x in row.items():
            for k,y in B.get(j,{}).items():rr[k]=rr.get(k,0)+x*y
        if rr:out[i]=rr
    return out
def diagonal_walks(edges,word,replay=False):
    mats={n:matrix(v)for n,v in edges.items()};P=mats[word[0]]
    if not replay:
        for n in word[1:]:P=mul(P,mats[n])
        return[P.get(i,{}).get(i,0)for i in range(643)]
    # Independent target-by-target recursion,not the matrix-product route.
    diag=[]
    for target in range(643):
        q={target:1}
        for n in word:
            nxt={}
            for i,x in q.items():
                for j,y in mats[n].get(i,{}).items():nxt[j]=nxt.get(j,0)+x*y
            q=nxt
        diag.append(q.get(target,0))
    return diag
def critical_words():
    # Exactly one theta-root and K0; total positive cost<=4.
    out=[]
    for direct in[False,True]:
        for probe in(['H','M']if direct else['none','H','M']):
            first='CU_'+probe if direct else'CS';extras=[((),0),(('S01',),1)]
            if not direct and probe!='none':extras=[(('U0_'+probe,),0),(('U0_'+probe,'S01'),1),(('U1_'+probe,),1)]
            for ex,extra_cost in extras:
                for rest in sorted(set(permutations(('K0',)+ex))):out.append(dict(first_u=direct or probe!='none',probe=probe,kind='direct_CU'if direct else'ordinary_U_covariance'if probe!='none'else'unprobed_covariance',word=[first]+list(rest),total_cost=3+extra_cost))
    return out
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    reports=[]
    for role in['native','replay']:
        root=load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'));uv=load(B/'canonical_so10_augmented_uv_grading_v1'/(role+'_complete_UV_grading_v2.json.gz'));ir=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_complete_operator_ir_audit.json.gz'));G=[(i,j)for i,j,symbol,pole in ir['actual_free_Green_bounds']['complete_nonzero_Green_with_soft_orders']];assert len(G)==1498 and all(parity(i)==parity(j)for i,j in G);rootrows={};rootpairs={};rows={};hist={}
        for name,key,g,label in[('K0','KD',0,'epsilon'),('CS','C_S',1,'omega'),('CU_H','C_U_H',1,'omega'),('CU_M','C_U_M',1,'omega')]:
            rr,pp=costs_kernel(root['complete_ordered_h_k_kernels'][key],g,label);rootrows[name]=rr;rootpairs[name]=pp;assert not rr or set(pp)==({2}if name=='K0'else{1});assert all(i>=553 and j>=553 for i,j in pp.get(2,[]))if name=='K0'else True
        parents={q['density']:q for q in uv['all_literal_parent_density_ports']}
        for name in['S0_GF_source','physical_S0_gauge','physical_S0_scalar','U0_H','U0_M']:
            rr,pp,hh=parent_ports(parents[name]);rows[name]=rr;hist[name]=hh
            if name.startswith('U0_'):
                probe=name[-1];rootpairs['U0_'+probe]={0:pp.get(0,[])};rootpairs['U1_'+probe]={1:pp.get(1,[])}
        base=sorted({tuple(q)for n in['S0_GF_source','physical_S0_gauge','physical_S0_scalar']for q in parent_ports(parents[n])[1].get(1,[])});rootpairs['S01']={1:base};assert uv['complete_positive_cost_unlabeled_base_ports']==[]
        simple={n:pairs([pair for pp in costsets.values()for pair in pp])for n,costsets in rootpairs.items()};edges={n:endomorphism(G,pp)for n,pp in simple.items()};words=[]
        for q in critical_words():
            diag=diagonal_walks(edges,q['word']);other=diagonal_walks(edges,q['word'],True);assert diag==other;words.append(dict(**q,complete643_returning_support_walk_counts=diag,total_returning_support_walks=sum(diag),amplitude_NOT_evaluated=True))
        # Deliberately violate the crossing budget: this must admit an even/odd loop.
        synthetic={'K0':[(1,1)],'CS':[(0,1)],'bridge':[(1,0)]};assert diagonal_walks(synthetic,['CS','K0','bridge'])[0]==1
        art=save(role+'_complete_critical_word_support.json.gz',dict(all1498_reference_Green_edges=G,reference_edges_preserve_field_parity=True,all_marked_geometric_kernel_cost_label_rows=rootrows,all_parent_low_cost_ports=rows,complete_parent_cost_parity_histograms=hist,all_root_pairs_by_cost={n:{str(c):pp for c,pp in v.items()}for n,v in rootpairs.items()},all_conservative_G_H_edges=edges,all_critical_words=words,synthetic_removed_crossing_budget_control_sensitive=True,full_interacting_nonlocal_G0_RETAINED=True,raw_heat_cyclicity_NOT_assumed=True,closed_quantum_D_and_sphere_jets_NOT_dropped=True))
        reports.append(dict(role=role,artifact=art,root_cost_port_counts={n:len(q)for n,q in rootrows.items()},critical_word_count=len(words),nonempty_critical_words=[q['word']for q in words if q['total_returning_support_walks']],first_u_all_support_walks_zero=all(not q['total_returning_support_walks']for q in words if q['first_u']),unprobed_all_support_walks_zero=all(not q['total_returning_support_walks']for q in words if not q['first_u'])));print('STAGE '+role+' complete_critical_word_support_classified',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='CRITICAL_LOCAL_MIXED_SUPPORT_CLASSIFIED_NOT_FULL_COVARIANCE_EVALUATION',roles=reports,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
