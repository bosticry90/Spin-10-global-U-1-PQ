# V862 separate final verification contract

One180s/8GiB sampled verifier,64MiB packet/8MiB artifact. Reconstruct the
actual root and parent port metadata independently. Authenticate all sources,
input encodings,finished captures and the failed prelaunch path/source.
Verify all1498 Green edges and their projectors; derive every29 critical
word with the complete budget and independent graph reachability. Check the
internal-sector argument independently of four-dimensional Lorentz counts;
retaining an all-D interpretation requires this stronger argument.

Execute sensitive sector-erasure and crossing controls. Verify both first-u
inverse placements and direct CU signs at the formal word level. Review the
ordinary-node IR lemma,uniform local UV inheritance and no-whole-profile
ceiling. Retain full interacting nonlocal covariance,all unknown higher roots,
quantum D factors,raw heat defects and marked geometric [T KD] RHS.

Authenticate old Git tree,unchanged state,navigation and historical README;
run the fixed E4 command once with exits0,0,0,0,0,2 and seven custody NOTPASS.
Separate evidence validation from scientific acceptance. No resource expansion,
scientific promotion,protected-state change or remote action.
