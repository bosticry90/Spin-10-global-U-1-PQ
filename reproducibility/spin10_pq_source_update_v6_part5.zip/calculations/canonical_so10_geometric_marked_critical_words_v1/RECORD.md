# V862 — critical local words for the geometric/marked covariance

Continue V861 /31216362887eb4a35b14deb9b1259a1ba02368ac on main,D:.
Root owns all writes/execution/Git; AI reviews are read-only. Current AGENTS,
charter and solo policy apply. State113,authority34/39,E5/A5 open,seven custody
NOTPASS,flavor pause and HB1/C5 blocks remain. No new branch/worktree,
foundational/prescription adoption,promotion,push or publication.

Question: which words can enter the LOCAL conversion of the surviving
rho-theta contact at first g and first u? This decides which new coefficients
could matter. It does not evaluate the full finite/nonlocal covariance.

Use the V861 whole ordered h/k kernels, actual V850 reference Green support,
and V851 complete parent port ledgers and marginal-reference proof. Keep
all mean/source/epsilon/omega jets and intrinsic01. The chart is unshifted
bosonic A0,g<=1,first H/M u. Omega is even1319..1330,epsilon odd1286..1318;
h1331,k1974. Rho and theta are constant,not Schwartz labels. Epsilon and
omega remain independent genuine local Schwartz transfers.

Before computation freeze source/input/Git encodings,hashes and this record.
One120s/8GiB sampled worker,64MiB packet,8MiB per compressed artifact;
complete overflow/failure capture is preserved. Distinct native/replay input
routes and different support-product algorithms must agree on each route's
matrix calculation. A returning support walk is a candidate,not a nonzero
amplitude. No coefficient is fitted or inferred from a desired cancellation.

Reconstruct every qualified K0/CS1/CU1 h/k cost and label. Recompute the full
S0 and U0 parent two-port ledgers from their actual words. Retain complete
cost0/cost1 pair sets and verify all1498 reference edges preserve field parity.
Bound unknown pure-scalar physical potential roots by the existing actual AST
degree proof: each costs at least2. Do not assign their Hessians zero.

At g1 the obligatory K0 and CS1/CU1 consume their actual positive cost.
Enumerate EVERY remaining word at total cost<=4, including both U placements,
direct CU,all permitted S0 cost1 dressing and U0 cost0/1. Outside the absorbed
reference,ungraded S0 cost0 is absent by V851. Kernels' raw port supports
overestimate adjointed supports; cancellations may remove candidates but
cannot add any. Check complete returning-walk diagonals by independent sparse
products. Preserve empty and nonempty outcomes. No momentum integral or
unspecified dimension continuation is executed.

Verify the operator programs from the SAME functional. At first g the converted
cyclic program is -(i/2)T[G0 H_CS1 G0 H_K0]. At first gu it is (i/2)T[
G0 H_U0 G0 H_CS1 G0 H_K0+G0 H_CS1 G0 H_U0 G0 H_K0-G0 H_CU1 G0 H_K0].
Keep rho attached until the even-total Gaussian convention is fixed; no
unsigned K Hessian substitution. Raw heat uses complete ordered word
derivatives and each heat length,not a cyclic simplification.

The scoped mixed IR proof uses ordinary labeled Hessian nodes and V850's
constant-chain collapse,not two unlabeled Q tangents. UV subtractions use
hard-shell symbols; external momenta are not set to zero inside an IR integral.
Retain all internal quantum D factors,angular/sphere first jets,power and
log heat contacts,corrected clocks,reference determinant and raw heat defect.
Full interacting G0 remains in the complete nonlocal covariance. V847's
selected-M clock/profile bridge is not a whole H/M profile match.

Separate final180s/8GiB checks independent Fraction port reconstruction,
all roots/labels/types and sparse graph zero complements,arbitrary-word
budget completeness,operator/IR/UV proof,source freezes/captures,old Git/state,
navigation/historical README and fixed E4 once0,0,0,0,0,2/seven NOTPASS.
Validate before local commit. Possible dispositions include supported domain,
surviving candidates,qualified local exclusion,failed premise or bounded
inconclusiveness. None establishes quantum restoration,QAP,measure,A5,E5 or
physical viability. Shared action,conventions,software and AI limit independence.
