# Common-weight gauge first-switch s³ comparison

The mixed quadratic density differs from its
symmetric reference by the compact contribution
-(i/2)(partial s) B Lambda. At grade one its
ordinary master variation produces

    -(i/2)s(partial s) f_(u v b)
         (1-m_u h_b) Lambda_u B_v C_b.

The two signed source drivers are F_B and
F_Lambda. The latter is supported on both broken
ports and a light ghost, giving the mask by
antisymmetry. This is distinct from the V965
first-switch comparison of the two reference
roots without this density defect. Relative to
the ordered mixed reference root of V965 the
defect is minus one half, with the mask and
derivative ghost replaced by the switch
derivative. The n3 log coefficient is positive,
while the n2 coefficient stripped in V967 is
negative. The inverse insertion keeps its Dyson
minus, so dividing all terms by the same n2
sign reverses the n3 defect. Distinct vertex
labels account for the cyclic factors. In these
common units, the ordered coefficient is

    Y(a,b,c) = Alt_(b,c) sum_(v,u,i)
             f_(a v i) f_(i u c) f_(u v b)
             (1-m_u h_b)(1-m_u h_c).

The second mask is the internal d_a-d_B
residue at the ordinary F port. The J_B source,
the ordinary F and the mixed defect each supply
their switch factors. Both exports supply the
literal F_Lambda sign and the F derivative rows.

In the lower J_B–F bubble a single switched
inverse on the gauge line lets its internal
derivative survive without an exterior ghost
derivative. The endpoint divergence follows
the V967 projection, with one half from the
mixed quadratic insertion. In the V945 signs
the two internal derivative placements combine
as -d_a+d_B. The lower driver change is
s²(partial s) L_tilde C/2 in common three-edge
units. The literal sector sum is
L_tilde=C_h+8P_M. Its source-first master
square gives -delta L_tilde on two ghosts in
units s³(partial s)/2, where

    delta L(b,c)=[L b,c]+[b,L c]-L[b,c].

Subtract the defect and the V969 residual
auxiliary insertion. With one common weight
the resulting color map is

    -delta L_tilde - Y - 2 Q_Lambda.

It vanishes in the full ordered ghost domain.
For a light input, the defect is the negative
coboundary of C_H and H equivariance makes
delta L_tilde=delta C_H. For two broken inputs
Y=-8[b,c] and delta L_tilde=16[b,c]
minus C_h on its light output and minus 8 on
its broken output. Their combination is
2 Q_Lambda, with the sign in the preceding
display. The executable checks the actual
literal contractions, the full color equality
and a sensitive broken-ghost pivot.

The three pieces have a collapsed transverse
three-profile log core in this jet. A common
normalized coefficient is a premise for this
color comparison. Splitting the weights by
internal profile count gives a rank-three
comparison with the common weight as its
only null direction. The test does not identify the
nonexceptional separated kernels or fix
independent finite extensions. It leaves the
other first-switch roots and regulator products,
ordinary metric, marked sector and joint causal
compatibility separate. Both replays share the
action and software.
