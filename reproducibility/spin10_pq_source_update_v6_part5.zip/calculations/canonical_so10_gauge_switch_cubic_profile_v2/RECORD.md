# V970 pre-execution contract

Freeze V965 ordered transverse gauge transport,
V968 actual lower maps, V894 mixed inverse and
V969 regulator-corrected auxiliary carrier. In the
selected local first-switch s³ component compare
the switched lower source, explicit grade-one
mixed density defect and the auxiliary color.
Verify the literal signed color formulas in both
exports and test a common three-edge weight.
Keep separate profiles symbolic and report a
weight-splitting negative control. Do not equate
separated nonlocal amplitudes or claim a complete
finite compact normalization.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.

V1 failed the common-weight comparison. Its independently checked sign mismatch was a missing conversion from the positive n3 log factor to the negative n2 factor stripped in V967. V2 binds the original inputs, retains the same color, rank and negative controls, and tests the fixed log signs explicitly. The V1 contract, source, preparation, capture and diagnostic remain in D control. No extra resource allowance.
