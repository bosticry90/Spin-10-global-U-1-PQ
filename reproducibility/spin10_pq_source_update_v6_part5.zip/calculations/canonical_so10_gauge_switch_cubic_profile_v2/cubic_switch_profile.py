"""Compare the selected cubic-switch gauge contributions."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("first_switch_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compare(phase):
    x = sp.Symbol("x")
    trace_log = sp.series(sp.log(1+x)/2,x,0,4).removeO()
    assert trace_log.coeff(x,2) == -sp.Rational(1,4)
    assert trace_log.coeff(x,3) == sp.Rational(1,6)
    prior = previous()
    literal = prior.load_literal()
    owner = literal.load_owner()
    _, _, _, f, _, _ = owner.owner.inputs(phase)
    clean = owner.owner.clean
    J, _, da, db, _, _, _, JL = literal.literal_tables(owner,phase)
    J_ports, mixed_ports = defaultdict(list), defaultdict(list)
    for (a,v,i),j in J.items():
        J_ports[v,i].append((a,j))
    for (v,b),rows in f.items():
        for u,z in rows:
            masked = z-JL.get((v,u,b),0)
            assert sp.expand(masked-int(not (u>=12 and b<12))*z) == 0
            if masked:
                mixed_ports[u].append((v,b,masked))
    lower = [prior.table() for _ in range(4)]
    defect = [prior.table() for _ in range(4)]
    K_HH = prior.table()
    for (i,u,c),z in da.items():
        hard = z-db.get((i,u,c),0)
        for a,j in J_ports[u,i]:
            n = 2*int(u>=12)+int(i>=12)
            lower[n][a,c] -= j*hard
            if n == 0:
                K_HH[a,c] -= j*z
        if not hard:
            continue
        for v,b,l in mixed_ports[u]:
            if b == c:
                continue
            n = sum(k>=12 for k in (v,u,i))
            for a,j in J_ports[v,i]:
                defect[n][a,min(b,c),max(b,c)] += (1 if b<c else -1)*j*hard*l

    Q = clean(prior.auxiliary(f,clean(K_HH)))
    T = [clean(prior.square(f,clean(K),{})) for K in lower]
    Y = [clean(D) for D in defect]
    combined = [clean(prior.plus((lhs,1),(rhs,-1),(Q,-2 if n==3 else 0)))
                for n,(lhs,rhs) in enumerate(zip(T,Y))]
    assert not clean(prior.plus(*((D,1) for D in combined)))
    assert clean(prior.plus(*[(D,1) for D in T],*[(D,-1) for D in Y])) == {k:2*z for k,z in Q.items()}
    assert Q[0,13,14] == 19*sp.sqrt(10)/40
    keys = sorted(set().union(*(D.keys() for D in combined)))
    matrix = sp.Matrix([[D.get(key,0) for D in combined] for key in keys])
    basis = matrix.nullspace()
    assert matrix*sp.ones(4,1) == sp.zeros(len(keys),1)
    assert basis == [sp.ones(4,1)]
    assert [len(D) for D in combined] == [423,934,557,708]
    pivots = [(0,13,14),(0,17,18),(13,0,14)]
    minor = sp.Matrix([[D.get(key,0) for D in combined[:3]] for key in pivots])
    assert minor.det() != 0
    return {"profile_count_cells":[len(D) for D in combined],
            "profile_count_rank":4-len(basis),
            "profile_count_nullspace":[[str(z) for z in vec] for vec in basis],
            "common_three_edge_weight_cancels_selected_s3":True,
            "breaking_one_weight_detected":True,
            "broken_auxiliary_pivot":"19*sqrt(10)/40"}


if __name__ == "__main__":
    run_worker(compare,sys.argv[1])
