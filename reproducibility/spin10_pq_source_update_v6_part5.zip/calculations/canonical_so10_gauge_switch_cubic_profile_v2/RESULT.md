# V970 · Cubic-switch gauge profile comparison

The switched lower source and explicit mixed-density
defect match the remaining auxiliary color at
`s³∂s` for a common normalized three-edge weight.

Grouping the selected terms by their number of
broken-profile edges gives a rank-three matrix.
The common weight is its only null direction.
This is a comparison of the specified local
cores. Different separated kernels and additional
regulator terms remain outside the test.

V1 failed at the relative two-edge/three-edge
log sign. Its full packet remains in D control.
V2 derives the common sign before comparing both
literal exports.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
