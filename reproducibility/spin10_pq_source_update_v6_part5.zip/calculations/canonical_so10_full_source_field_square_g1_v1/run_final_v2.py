from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-source-field-square-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
for pn in['preparation.json','final_preparation.json']:
 for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,(pn,n)
cap=json.loads((O/'final_capture.json').read_bytes());assert cap['exit_code']==1 and not cap['calculation_completed']and cap['post_run_observations_qualified']and 'PEER_FIELD_SQUARES_DENIED'in cap['stdout_and_stderr'];assert not(O/'validation_receipt.json').exists()
for n in['FINAL_CONTINUATION_V2.md','final_review_v2.py','run_final_v2.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'final_preparation_v2.json',dict(sha256={p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()},original_failed_final_NOTPASS=True,E4_reuse_no_new_launch=True,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v2.py')]);dump(O/'final_capture_v2.json',cap);dump(C/'final_capture_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
