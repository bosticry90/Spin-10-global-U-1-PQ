# Full-source field-square prerequisite passes

Both odd-prefix and LEFT-derivative routes give zero for all 3,858 declared
field-square columns, with all sources retained. Their complete seven
artifacts agree byte for byte. The generated intrinsic-two complements
are also zero; higher action orders remain outside scope.

Omitting source variations or changing their odd-field pairing signs
produces 12 H and 33 M errors at each tested coupling order. The original
cases are blind, and all complete control differences are retained.

Native and replay completed in 10.333 and 11.172 seconds after imports,
respectively, under separate 240-second bounds. This was a structural
operator test, with no new loop expansion or fitted quantum coefficient.

The result removes the field-square prerequisite for a possible source
homotopy argument. Common-action integrability, signed Jacobi applicability,
source-free coverage and hatted support remain necessary before a broader
proper source identity. No source-square, full master, restoration or
physical viability conclusion follows here. Scientific authority remains
34/39; E5/A5 and seven historical custody references remain open.

The final validation receipt owns the fresh native reconstruction, complete
route comparison, input and resource checks, E4 result and preserved Git
tree check. Shared action, chart, software and AI authorship limit the
independence of the two routes. See PROOF.md for the exact claim boundary.
