from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-source-field-square-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(420,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','final_preparation.json','final_preparation_v2.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 results={q:read(O/(q+'_result.json'))for q in['native','replay']};captures={q:read(O/(q+'_capture.json'))for q in results};artifact_names=[];samples=[]
 expected=[(0,0),(0,0),(12,12),(12,12),(33,33),(33,33)]
 for role,res in results.items():
  cap=captures[role];assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['elapsed_after_imports']<240;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);samples.extend(x['private_bytes']for x in cap['all_resource_samples']);assert cap==read(C/(role+'_capture.json'))
  assert res['scientific_disposition']=='ALL3858_INTRINSIC01_FIELD_SQUARES_ZERO'and res['total_field_columns']==3858 and not res['nonzero_intrinsic01_columns']and not res['nonzero_outside_intrinsic2_columns'];assert[(z['omit_source_nonzero_columns'],z['wrong_source_sign_nonzero_columns'])for z in res['cases']]==expected
  support=load(O/res['support_artifact']['file']);assert len(support['all3858_field_columns'])==3858 and len(support['all540_supplied_nonminimal_source_columns'])==540 and not support['unsupported_source_ports'];count=0
  for case in res['cases']:
   table=load(O/case['artifact']['file']);assert len(table['all643_field_columns'])==643
   for row in table['all643_field_columns']:assert not row['complete_square']and not row['intrinsic01_square']and not row['complete_intrinsic2_complement'];count+=1
  assert count==3858
  for art in[res['support_artifact']]+[z['artifact']for z in res['cases']]:assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']
 for p in sorted(O.glob('native_*.json.gz')):
  peer=p.with_name(p.name.replace('native_','replay_',1));assert p.read_bytes()==peer.read_bytes(),p.name;artifact_names.append(p.name)
 assert len(artifact_names)==7
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);raw=(R/'README.md').read_bytes();assert raw.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';before=subprocess.check_output(['git','show','HEAD:README.md'],cwd=R);assert(C/'README_before.md').read_bytes()==before
 links=[]
 for path,body in[(R/'README.md',raw[:-len(history)].decode('utf-8')),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V829.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V829.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',body):
   if target.startswith(('https:','http:','#','mailto:')):continue
   resolved=(path.parent/target.split('#')[0]).resolve();assert resolved.is_relative_to(R)and resolved.exists(),(path,target);links.append([path.relative_to(R).as_posix(),target])
 ec=read(O/'e4_capture.json');assert ec==read(C/'e4_capture.json')and ec['exit_code']==0;failed=read(O/'final_capture.json');assert failed['exit_code']==1 and not failed['calculation_completed']and failed['post_run_observations_qualified']and 'PEER_FIELD_SQUARES_DENIED'in failed['stdout_and_stderr'];assert failed==read(C/'final_capture.json')
 events=[json.loads(x)for x in ec['stdout'].splitlines()if x.strip()];exits=[x['exit_code']for x in events if x['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(x for x in events if x['event']=='step_finished'and x['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V829.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 filehash={p.relative_to(R).as_posix():digest(p)for p in files}
 sp=importlib.util.spec_from_file_location('fresh_full_source_field_square',O/'squares.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);fresh=[];freshart=[]
 def compare_save(name,z):
  name='native_'+name+'.json.gz';blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),name;freshart.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
 def compare_dump(path,z):
  assert path==O/'native_result.json';prior=results['native'];assert{k:v for k,v in prior.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'};assert z['elapsed_after_imports']<240;fresh.append(z['elapsed_after_imports'])
 m.save=compare_save;m.dump=compare_dump;m.main();del m;gc.collect();assert len(fresh)==1 and sorted(freshart)==artifact_names;print('STAGE full_native_reconstruction_and_seven_complete_route_artifacts_verified',flush=True)
 out=dict(schema='FULL_SOURCE_FIELD_SQUARE_VALIDATION_V2',execution_state='COMPLETED',evidence_validation='PASS_ALL3858_DECLARED_FULL_SOURCE_FIELD_SQUARES',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,all3858_field_columns_zero_in_both_routes=True,all_generated_intrinsic2_complements_zero_no_higher_action_claim=True,all7_complete_route_artifacts_equal=artifact_names,fresh_native_seconds=fresh[0],all_native_artifacts_reconstructed_byte_identically=freshart,control_counts=expected,original_controls_BLIND_probe_controls_sensitive=True,no_unknown_physical_Euler_assigned_zero=True,no_source_square_master_proper_zero_restoration_or_HB1_C5_claim=True,shared_action_ring_chart_helpers_AI_limit_independence=True,primary_replay_seconds={q:results[q]['elapsed_after_imports']for q in results},largest_primary_replay_sampled_private_bytes=max(samples),sampled_not_true_or_nested_peak=True,E4_launches_this_continuation=0,E4_launches_whole_packet=1,E4_complete_capture_reused_not_newly_executed=True,failed_final_V1_exit1_NOTPASS=True,final_V2_correction_only_hash_inventory_order=True,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',README_historical_suffix_sha256=sha256(history).hexdigest(),checked_local_links=links,old_mode_blob_entries=len(tree.splitlines()),old_changes_only_authorized_live_README_prefix=True,files_excluding_pending_receipt_and_final_capture=filehash,packet_bytes_excluding_pending_receipt_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
