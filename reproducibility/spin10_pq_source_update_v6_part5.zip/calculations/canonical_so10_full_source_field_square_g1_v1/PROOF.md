# Declared full-source field squares

FSQ-1 tests the recovered classical operations on every one of the 643
field coordinates, with all sources and means retained. Its six coefficient
families are the original g0/g1 and first-u H/M g0/g1 coefficients. All four
terms of each gu square are included. The tested quotient is the original
Euclidean A0 chart at intrinsic coefficient degrees zero and one. The
complete generated intrinsic-two complement is retained separately.

For a homogeneous word, an odd derivation replaces its kth factor with
the factor's operation and multiplies by (-1) to the parity of the prefix.
Native implements this rule directly. Replay independently sorts odd tokens,
uses LEFT jet derivatives, and places the operation to their left. The sign
from moving that operation to the replacement position combines with the
LEFT derivative sign to give the same odd-prefix rule. Replay also implements
the even total jet derivative separately. Both routes use their respective
qualified input packets, not each other's output.

Before substitution, all 3,858 inner field maps are audited for coupling,
intrinsic degree, parity, ghost number and complete source support. Their
only source ports are Ja and JLambda. The signed source operations are
QJ_i=(-1)^p_i E_i, using all 540 nonminimal Euler columns across the six
states. Physical action does not depend on a or Lambda. No unavailable
physical Euler map is set to zero. Sources occurring only in a replacement
output do not need another operation for this field-square calculation.

Both routes return zero in all 3,858 selected columns. Their complete branch
tables and generated intrinsic-two complements agree byte for byte; those
complements also vanish. This latter observation is about the generated
truncated operands, not the uncomputed higher-intrinsic action.

Omitting source variations or reversing the odd-field source pairing gives
12 nonzero H columns at each coupling order and 33 nonzero M columns at
each order. The original g0/g1 cases are blind to both controls. Complete
control polynomials are preserved. They test the relevance of source terms
and signs, not the truth of the physical assumptions.

The common action, coordinate chart, coefficient ring, some algebra helpers
and AI authorship are shared. These are alternative implementation checks,
not independent scientists, experimental evidence or Lean kernel proofs.

## What does not follow yet

A field-square zero is not a source-square zero, a full master equation,
a quantum identity or a restoring counterterm. A proposed next route uses
common-action integrability and the correctly signed Jacobi relation to
infer source independence of the half-master modulo an ordinary divergence.
Those premises are not established by this packet. The current chart must
not be silently replaced by a different source-pairing convention.

Even with that inference, the source-free master insertion and hatted
remainder require their own proofs. In particular the aCC/BBC envelope
union leaves a potentially contributing Lambda x² C scalar class. Actual
source-free GF factor support, rather than V827's current-specific scalar
cut, is the next inexpensive discriminating test. Retain physical Noether,
potential-domain, own-jet, Gaussian mean-subtraction and CPS premises.

The antibracket and local-functional framework has established literature:
[Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228) and
[Barnich, Brandt and Henneaux](https://arxiv.org/abs/hep-th/0002245).
These references motivate applicability checks; no general cohomology or
anomaly-removal theorem is imported as a substitute for missing premises.

This work does not activate HB1/C5 or flavor, construct a complete admitted
correction module, restore the quantum symmetry, promote E5/A5 or resolve
the physical scalar and gauge-matching warnings. The exact FSQ result is
a prerequisite with a deliberately limited authority ceiling.
