# Final harness continuation V2

Final V1 failed, exit 1, after the complete native reconstruction, seven
route comparisons, README/link/tree/state checks and E4 execution. Its
result-isolation audit hook correctly denied a subsequent attempt by the
reviewer's file-hash inventory to read a replay file. No validation receipt
was written. Preserve final_review.py, its source copy, original preparation
and full final_capture.json unchanged; V1 remains FAILED NOTPASS.

This delegated harness correction changes only the order of final bookkeeping.
Authenticate and hash the complete evidence inventory BEFORE installing the
native route's persistent isolation hook. Keep that hook unchanged. Repeat
the complete scientific reconstruction and route comparisons under the same
240-second inner bound; final V2 has 420 seconds, 8 GiB sampled private memory,
350 MiB launch floor, 64 MiB packet and 10 MiB individual-file limits. This
is a new frozen version, not a modification or authorization of the old run.

Reuse and authenticate the complete already-executed E4 capture from V1,
including its expected 0,0,0,0,0,2 component exits and seven unresolved custody
references. Launch no second E4 process: no scientific inputs have changed.
Repeat all tree, state and link checks. Save the complete V2 capture on both
repository and D: control paths before judging. No science requirements,
physical inputs, source/sign conventions or failed execution statuses change.

V2 may qualify FSQ-1. It cannot qualify the proposed source-homotopy or
broader proper identity. The final receipt must disclose this harness failure
and both the new fresh execution and authenticated E4 reuse.
