# Full-source Hamiltonian field-square test

Continue from `33675da4eb8ba1b73eadb4faf5fa688835a90cd1`, main, V828,
in the D: repository. Fresh preflight is clean, with no matching live workers;
declared bytes are authenticated only. The previous goal turn made progress.
The full goal is active; current AGENTS.md and state 113 / 34 of 39 apply.
No new branch, worktree, remote push, external action, foundational adoption
or protected promotion is authorized here. Flavor remains paused and HB1/C5
remain blocked. Education is voluntary and nonblocking.

Question FSQ-1: do the CURRENT full-source classical field operations square
to zero through g1, first-u_H/M and intrinsic0/1? This is a prerequisite for
the proposed source-homotopy/proper applicability route, not a C5 cochain or
cohomology construction. It can yield zero, exact nonzero field squares, or
incomplete/source-underdefined execution. Do not assume nilpotence because
an older inactive parent has a classical-master proof.

Use exact native/replay recovered operator packets, F0/F1/Fu0/Fu1 and full
source Euler rows, before ANY source/mean restriction. Source variables remain
independent ordinary jets; no source-degree cutoff. Preserve EuclideanA0,
constant even u labels, original physical parameters/ring and intrinsic01
quotient. Current action signs are F_i=(-1)^p EL_Ji S and QJ_i=(-1)^p E_i.
The W1/CSW weighted-chart relation must be separately justified before
applying a Jacobi/source-Euler theorem. Field-square zeros alone are not a
complete master-zero proof and do not establish Q² on SOURCES or remove Ihat.

First journal ALL3858 field-map columns and all source ports they contain.
The only immediately supplied source operations are the90 Ja/JLambda rows;
physical action has no a/Lambda dependence. If another source is needed,
retain the exact unsupported ports and classify the full test underdefined;
do not assign unknown physical E1_x or any unavailable source Euler zero.
Check coefficient grades, ghost/parity and nonnegative intrinsic degree.

Test ALL643 fields in six coefficient families:
 Q0F0;
 Q0F1+Q1F0;
 Q0Fu0+Qu0F0 (H/M);
 Q0Fu1+Q1Fu0+Qu0F1+Qu1F0 (H/M).
The four gu terms are mandatory. No u²/contact, g2 or higher-intrinsic
nilpotence claim is made. Preserve COMPLETE generated intrinsic2 terms
separately rather than silently dropping them. Input g/u selections are
stable because their coefficients have nonnegative grades.

Native uses odd-prefix variation in the original factor order. Replay uses
LEFT jet derivatives with the operation on the left, independent literal
odd-word inversion sorting and a separately implemented even jet derivative.
Both use respective full native/replay packets. Preserve all branch outputs,
full square, intrinsic01 projection, intrinsic2 complement and controls.
Wrong controls omit all source variations or reverse the odd-field source
pairing. Retain complete nonzero differences and disclose blind cases.
Linearity permits recording correct source/odd-source contributions and
assembling these counterfactuals exactly without extra physical assumptions.

Run sequentially: each route has 240 seconds after imports, an 8 GiB sampled
private-memory limit, a 350 MiB launch commit floor, a 64 MiB packet limit
and a 10 MiB per-artifact limit. Freeze source/copies/bindings before
launch; full captures repo+D before judging. Partial completed case artifacts
survive a later failure; parent remains incomplete NOTPASS. If an artifact
would exceed its bound, preserve the COMPLETE overflow on D: controls and
end incomplete, not truncate or silently qualify a larger packet. No retry
or resource expansion within this frozen execution.

Root owns all writes/runs. Two bounded read-only AI reviews inspect the
Hamiltonian convention/common-action prerequisite and source-free/physical
remainder coverage respectively; neither runs workers or edits evidence.
Compare completed reviews before dependent claims. Different code routes
share coefficient ring, action, conventions and AI authorship; no independent
scientists, Lean or experiment is claimed.

After the bounded result, qualify it before local commit. Only if justified,
continue with a separate frozen common-action/chart and source-homotopy/
outside-envelope support audit. Need the actual common-action integrability,
correct signed Jacobi formula, source-free divergence proofs and physical/
hatted support BEFORE asserting a broader finite proper/current bridge.
All previous restricted correction exclusions and actual BBC proper zero
remain in their qualified scopes. No complete restoring module or E5/A5
acceptance is inferred. Failure is a scientific finding, not a coefficient
to fit away. project_state remains sole authority.
