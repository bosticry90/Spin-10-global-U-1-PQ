# Final evidence review

Authenticate the original preparation and source copies. Check both complete
captures and memory observations, compare all seven complete native/replay
artifacts, and inspect every selected and complementary square column.
Reconstruct the complete native calculation afresh, comparing every output
byte and all non-runtime result fields, under its original 240-second bound.

Final review has 420 seconds after imports, 8 GiB sampled private memory,
350 MiB launch commit floor, 64 MiB packet and 10 MiB per artifact. Primary
and replay executions remain immutable. Save complete captures repo and D:
before judging. No truncation, replacement of failures or resource extension.

Run the delegated E4 check once, without fresh replay, against the fixed D:
historical context. Require outer zero, component exits 0,0,0,0,0,2 and seven
unresolved custody references. Custody exit two stays NOTPASS. Verify all
old Git mode/blob entries except the authorized current README prefix,
whose historical suffix must remain identical. Check new navigation links,
unchanged scientific authority and staged raw bytes before local commit.

This review can qualify FSQ-1 only. A final receipt is evidence validation,
not director acceptance or full goal completion. Continue with the missing
common-action and source-free support premises if FSQ-1 is qualified.
