from pathlib import Path
from collections import Counter
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-source-field-square-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('full_source_field_square_algebra',O.parent/'canonical_so10_restoration_probe_interface_audit_v1/interface.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);J=a.J;A=a.A;one=J.constant(1)
ROLE=sys.argv[1]if __name__=='__main__'else'native';read=a.read;load=a.load;digest=a.digest
STATES={'Q0':('F0','E0',0),'Q1':('F1','E1',1),'U0H':('Fu0_0','Eu0_0',0),'U1H':('Fu1_0','Eu1_0',1),'U0M':('Fu0_1','Eu0_1',0),'U1M':('Fu1_1','Eu1_1',1)}
CASES=[('original_g0',0,[('Q0','Q0')]),('original_g1',1,[('Q0','Q1'),('Q1','Q0')]),('probe0_g0',0,[('Q0','U0H'),('U0H','Q0')]),('probe0_g1',1,[('Q0','U1H'),('Q1','U0H'),('U0H','Q1'),('U1H','Q0')]),('probe1_g0',0,[('Q0','U0M'),('U0M','Q0')]),('probe1_g1',1,[('Q0','U1M'),('Q1','U0M'),('U0M','Q1'),('U1M','Q0')])]
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 name=ROLE+'_'+name+'.json.gz';blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>10*1024**2:
  p=C/(name+'.COMPLETE_OVERFLOW_NOTPASS')
  with p.open('xb')as h:h.write(blob)
  print('COMPLETE_OVERFLOW_NOTPASS '+str(p)+' '+sha256(blob).hexdigest(),flush=True);raise AssertionError('ARTIFACT_LIMIT_NO_TRUNCATION')
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def parity(n):return int(553<=n<643)if n<643 else 1-int(553<=n-643<643)
def ghost(n):return(1 if 553<=n<598 else-1 if 598<=n<643 else 0)if n<643 else-1-ghost(n-643)
def literal_put(out,word,c):
 if not c:return
 odds=[t for t in word if parity(t[0])]
 if len(set(odds))!=len(odds):return
 sign=(-1)**sum(x>y for at,x in enumerate(odds)for y in odds[at+1:]);key=tuple(sorted(word));out[key]=out.get(key,J.ZERO)+c*sign
def literal_D(P,mu):
 out={}
 for word,c in P.items():
  for at,(n,js)in enumerate(word):literal_put(out,word[:at]+((n,tuple(sorted(js+(mu,)))),)+word[at+1:],c)
 return J.clean(out)
def minus(P,Q):
 out=dict(P);J.add(out,Q,-1);return J.clean(out)
def scaled(P,k):return J.clean({w:c*k for w,c in P.items()})
def intrinsic(word,dim):return dim-sum(J.dimension(n)+len(js)for n,js in word)
def project(P,dim):return{w:c for w,c in P.items()if intrinsic(w,dim)in[0,1]}
def phash(P):return sha256((json.dumps(J.encode(P),sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start();assert ROLE in['native','replay']
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 peer=str((O/('replay_'if ROLE=='native'else'native_')).resolve())
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_FIELD_SQUARES_DENIED'
 sys.addaudithook(guard)
 packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(ROLE+'_inputs.json.gz'));raw={k:dict(v)for k,v in packet['states'].items()};assert all(sorted(v)==list(range(643))for v in raw.values());F={q:{n:J.decode(P)for n,P in raw[fn].items()}for q,(fn,en,g)in STATES.items()};ops={};audit=[];unsupported=set();source_audit=[]
 for q,(fn,en,g)in STATES.items():
  for n,P in F[q].items():
   assert all(k[0]==g for c in P.values()for k,v in c.terms);assert all(intrinsic(w,J.dimension(n)+1)in[0,1]for w in P);assert all(sum(parity(i)for i,js in w)%2==(parity(n)+1)%2 and sum(ghost(i)for i,js in w)==ghost(n)+1 for w in P);ports=sorted({i for w in P for i,js in w if i>=643});unsupported.update(i for i in ports if not(1151<=i<1196 or 1241<=i<1286));audit.append(dict(state=q,field=n,words=len(P),full_math_sha256=phash(P),source_ports=ports,jet_tokens=sorted({(i,js)for w in P for i,js in w})))
  ops[q]=dict(F[q])
  for i in list(range(508,553))+list(range(598,643)):
   E=J.decode(raw[en][i]);P=scaled(E,(-1)**parity(i));n=643+i;assert all(k[0]==g for c in P.values()for k,v in c.terms);assert all(intrinsic(w,J.dimension(n)+1)in[0,1]for w in P);assert all(sum(parity(j)for j,js in w)%2==(parity(n)+1)%2 and sum(ghost(j)for j,js in w)==ghost(n)+1 for w in P);ops[q][n]=P;source_audit.append(dict(state=q,source=n,words=len(P),full_math_sha256=phash(P),physical_Euler_not_required_by_nonminimal_port=True))
 support=save('input_support',dict(all3858_field_columns=audit,all540_supplied_nonminimal_source_columns=source_audit,unsupported_source_ports=sorted(unsupported),no_other_source_operation_assigned_zero=True,all_sources_before_restriction=True))
 if unsupported:
  out=dict(schema='FULL_SOURCE_FIELD_SQUARE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,scientific_disposition='UNDERDEFINED_REQUIRED_SOURCE_OPERATIONS_NOT_ASSIGNED_ZERO',support_artifact=support,unsupported_source_ports=sorted(unsupported),field_square_calculation_NOT_EXECUTED=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/(ROLE+'_result.json'),out);watch.cancel();print('RESULT '+json.dumps(out,sort_keys=True),flush=True);return
 cache={}
 def image(q,token):
  key=q,token
  if key not in cache:
   n,js=token;assert n in ops[q],('UNAVAILABLE_SOURCE_OPERATION',q,n);P=ops[q][n]
   if ROLE=='native':P=J.Ds(P,js)
   else:
    for mu in js:P=literal_D(P,mu)
   cache[key]=P
  return cache[key]
 def act(q,P):
  out={};source={};oddsource={}
  if ROLE=='native':
   for word,c in P.items():
    prefix=0
    for at,token in enumerate(word):
     n,js=token;sg=(-1)**prefix
     for ww,d in image(q,token).items():
      combined=word[:at]+ww+word[at+1:];v=J.times(c,d)*sg;J.put(out,combined,v)
      if n>=643:
       J.put(source,combined,v)
       if parity(n-643):J.put(oddsource,combined,v)
     prefix+=parity(n)
  else:
   for token in sorted({t for word in P for t in word}):
    n,js=token;partial=J.leftjet(P,token);im=image(q,token)
    for ww,c in im.items():
     for vv,d in partial.items():
      v=J.times(c,d);literal_put(out,ww+vv,v)
      if n>=643:
       literal_put(source,ww+vv,v)
       if parity(n-643):literal_put(oddsource,ww+vv,v)
  return[J.clean(x)for x in[out,source,oddsource]]
 summaries=[];artifacts=[];total=nonzero=outside=controls_sensitive=0
 for label,g,branches in CASES:
  rows=[];nz=ox=ns=nw=0
  for n in range(643):
   full={};source={};oddsource={};parts=[]
   for left,right in branches:
    values=act(left,F[right][n])
    for accum,P in zip([full,source,oddsource],values):J.add(accum,P)
    parts.append(dict(operator=left,field_map=right,full=J.encode(values[0]),source_part=J.encode(values[1]),odd_field_source_part=J.encode(values[2])))
   full=J.clean(full);source=J.clean(source);oddsource=J.clean(oddsource);dim=J.dimension(n)+2;assert all(intrinsic(w,dim)in[0,1,2]for w in full);assert all(k[0]==g for c in full.values()for k,v in c.terms);assert all(sum(parity(i)for i,js in w)%2==parity(n)and sum(ghost(i)for i,js in w)==ghost(n)+2 for w in full);selected=project(full,dim);high=minus(full,selected);wrong_omit=project(minus(full,source),dim);wrong_sign=project(minus(full,scaled(oddsource,2)),dim);nz+=bool(selected);ox+=bool(high);ns+=bool(wrong_omit);nw+=bool(wrong_sign);rows.append(dict(field=n,branches=parts,complete_square=J.encode(full),intrinsic01_square=J.encode(selected),complete_intrinsic2_complement=J.encode(high),omit_all_source_variations_intrinsic01=J.encode(wrong_omit),wrong_odd_field_source_pairing_intrinsic01=J.encode(wrong_sign)))
  art=save('square_'+label,dict(case=label,coupling_grade=g,all643_field_columns=rows,no_source_degree_restriction=True,no_mean_source_restriction=True,full_generated_intrinsic2_retained=True));artifacts.append(art);summaries.append(dict(case=label,nonzero_intrinsic01_columns=nz,nonzero_intrinsic2_columns=ox,omit_source_nonzero_columns=ns,wrong_source_sign_nonzero_columns=nw,artifact=art));total+=643;nonzero+=nz;outside+=ox;controls_sensitive+=ns+nw;print('STAGE '+label+' intrinsic01_nonzero='+str(nz)+' outside_intrinsic2='+str(ox)+' omit='+str(ns)+' sign='+str(nw),flush=True);del rows;gc.collect()
 assert total==3858
 out=dict(schema='FULL_SOURCE_FIELD_SQUARE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,scientific_disposition='ALL3858_INTRINSIC01_FIELD_SQUARES_ZERO'if not nonzero else'NONZERO_FULL_SOURCE_FIELD_SQUARES_NO_MASTER_PROMOTION',support_artifact=support,cases=summaries,total_field_columns=total,nonzero_intrinsic01_columns=nonzero,nonzero_outside_intrinsic2_columns=outside,control_sensitive_column_occurrences=controls_sensitive,all_source_ports_supplied_without_unknown_physical_Eulers=True,no_new_source_square_or_full_master_or_proper_zero_claim=True,no_HB1_C5_activation_or_restoration_E5A5_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/(ROLE+'_result.json'),out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
