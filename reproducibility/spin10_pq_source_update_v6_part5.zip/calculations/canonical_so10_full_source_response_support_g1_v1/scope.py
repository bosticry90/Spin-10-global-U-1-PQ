from pathlib import Path
from collections import defaultdict
from hashlib import sha256
import gc,gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def scalar(n):return 180<=n<508
def mean_scalar(n):return scalar(n)or 823<=n<1151
def scan(packet):
 rows=[];violations=[]
 for kind in['roots','ordinary']:
  for rr,row in enumerate(packet[kind]):
   raw=row['raw_root']if kind=='roots'else row['quadratic_Taylor_half'];groups=defaultdict(list);bad=[]
   for at,entry in enumerate(raw):
    word=entry[0];q=[];means=[]
    for n,js in word:
     if 1319<=n<1962:q.append(n-1319)
     elif kind=='roots'and 1962<=n<2605:q.append(n-1962)
     else:means.append(n)
    assert len(q)==2 and all(0<=n<1286 for n in means);partition=tuple('scalar'if scalar(n)else'GF'for n in q);sm=any(mean_scalar(n)for n in means);groups[partition,sm].append(at);cross=partition[0]!=partition[1];why=[]
    if row['u']and(any(scalar(n)for n in q)or sm):why.append('EXPLICIT_U_HAS_SCALAR_INTERFACE')
    if not row['g']and cross:why.append('G0_SCALAR_GF_CROSSING')
    if partition==('GF','GF')and sm:why.append('GF_PAIR_HAS_SCALAR_OR_JX_MEAN')
    if kind=='roots'and row['state']=='F0'and any(scalar(n)for n in q):why.append('F0_ROOT_VISITS_SCALAR')
    if why:bad.append(dict(raw_index=at,reasons=why))
   assert sorted(i for ids in groups.values()for i in ids)==list(range(len(raw)))
   out=dict(kind=kind,input_row=rr,owner=row.get('owner',row.get('state')),family=row.get('family'),g=row['g'],u=row['u'],raw_word_count=len(raw),all_raw_partition_indices=[dict(quantum_partition=list(k),has_scalar_or_Jx_mean=sm,raw_indices=ids)for(k,sm),ids in sorted(groups.items())],complete_cut_violations=bad);rows.append(out);violations+=bad
 return dict(all20_full_raw_owners=rows,total_raw_words=sum(z['raw_word_count']for z in rows),complete_cut_violations=violations,all_scalar_GF_crossings_require_g1=not violations,first_u_scalar_potential_robust_cut_applicable=not violations)
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'scope_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 p=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';native=scan(load(p/'native_inputs.json.gz'));replay=scan(load(p/'replay_inputs.json.gz'));assert native==replay
 cl=load(O/'native_classification.json.gz');ref=next(z for z in cl['roots']if z['owner']=='reference_F1');assert ref['disposition']=='RETAINED_NONZERO_REFERENCE_DIAGONAL'and ref['complete_reference_diagonal'];zero=not native['complete_cut_violations'];art=save('scalar_partition_scope_tables.json.gz',dict(schema='FIRST_U_SCALAR_POTENTIAL_CUT_SCOPE_V1',complete_native_replay_equal_scan=native,original_packet_support_not_full_potential_census=True,nonzero_full_F1_reference_diagonal_retained=True,first_u_pure_scalar_potential_insertions_excluded_by_two_crossing_argument=zero))
 out=dict(schema='FIRST_U_FULL_SOURCE_SUPPORT_SCOPE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',total_raw_words=native['total_raw_words'],complete_native_replay_partition_scans_equal=True,cut_violations=len(native['complete_cut_violations']),first_u_pure_scalar_potential_robust_cut_applicable=zero,unprobed_full_physical_potential_support_NOT_CLAIMED=True,nonzero_full_F1_reference_diagonal_retained=True,full_HB1_C5_QAP_matter_extension_not_claimed=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);dump(O/'scope_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
