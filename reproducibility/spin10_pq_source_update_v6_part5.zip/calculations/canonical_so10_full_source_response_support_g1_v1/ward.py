from pathlib import Path
from fractions import Fraction as Fr
from collections import Counter,defaultdict
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
import sympy as sy
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('full_source_path_ward_helpers',O/'support.py');s=importlib.util.module_from_spec(sp);sp.loader.exec_module(s);J=s.J;A=s.m.m.A;read=s.read;load=s.load;digest=s.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def contract(rows,momentum,omit_mu=None):
 out={};literal={};used=[]
 for at,(word,mon,cc)in rows:
  legs=[(pos,n-1962)for pos,(n,js)in enumerate(word)if 1962<=n<2142];assert len(legs)==1;pos,n=legs[0];color,mu=divmod(n,4);assert word[pos][1]==[]
  if mu==omit_mu:continue
  powers=list(mon);powers[momentum+mu]+=1;key=color,tuple((n,tuple(js))for j,(n,js)in enumerate(word)if j!=pos),tuple(powers);out[key]=out.get(key,J.ZERO)+A.decode_coeff(cc);used.append(at)
  for atom,num,den in cc:
   kk=key,tuple(atom);literal[kk]=literal.get(kk,Fr())+Fr(num,den)
 out={k:v for k,v in out.items()if v};literal={k:v for k,v in literal.items()if v};assert{(k,tuple(atom)):v for k,c in out.items()for atom,v in c.terms}==literal
 return dict(used_raw_indices=used,complete_contraction=[[col,[[n,list(js)]for n,js in word],list(mon),A.encode_coeff(c)]for(col,word,mon),c in sorted(out.items())],nonzero_positions=len(out),all_literal_fraction_atoms_equal=True)
def ordinary_legs(packet):
 result=[]
 for row in packet['ordinary']:
  if row['g']:continue
  P=J.decode(row['quadratic_Taylor_half']);native=defaultdict(dict);bad=[];positions=[]
  for at,(word,c)in enumerate(sorted(P.items())):
   for pos,(n,js)in enumerate(word):
    if not 1319<=n<1499:continue
    field=n-1319;col,mu=divmod(field,4);positions.append([at,pos,col,mu,list(js)])
    if js!=(mu,):bad.append([at,pos,col,mu,list(js)]);continue
    J.put(native[col,mu],word[:pos]+word[pos+1:],c)
  columns=[];allgood=not bad
  for col in range(45):
   base=J.clean(native.get((col,0),{}))
   for mu in range(4):
    own=J.clean(native.get((col,mu),{}));peer=J.clean(J.leftjet(P,(1319+4*col+mu,(mu,))));assert own==peer;equal=own==base;allgood&=equal;columns.append(dict(color=col,mu=mu,complete_diagonal_jet_partial=J.encode(own),all4_mu_equal=equal,literal_LEFT_equal=True))
  result.append(dict(owner=row['owner'],raw_quadratic_half_sha256=s.m.m.mhash(row['quadratic_Taylor_half']),all_quantum_B_positions=positions,complete_non_divergence_leg_violations=bad,all180_columns=columns,all_B_legs_pure_divergence=allgood))
 return result
def inverse():
 p=O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1';pk=load(p/'native_inverse.json.gz');assert pk==load(p/'replay_inverse.json.gz');G={(i,j):v for i,j,v in pk['G_F']if(i<180 and(j<180 or 508<=j<553))or(508<=i<553 and j<180)};q=sy.Matrix(sy.symbols('q0:4',real=True));sq=(q.T*q)[0];E,f=sy.symbols('E_profile f_profile',positive=True);loc={str(t):t for t in[*q,E,f]};templates={};checks=[]
 for sector,col in[('H',0),('M',12)]:
  strings=[[G.get((4*col+mu,4*col+nu),'0')for nu in range(4)]for mu in range(4)];matrix=sy.Matrix([[sy.sympify(v,locals=loc)for v in rr]for rr in strings]);action=(matrix*q).applyfunc(sy.simplify);width=sy.simplify(action[0]*sq/(E*f*q[0]));assert all(sy.simplify(action[mu]-E*f*width*q[mu]/sq)==0 for mu in range(4));wrong=(sy.diag(*[matrix[mu,mu]for mu in range(4)])*q-action).applyfunc(sy.simplify);assert wrong!=sy.zeros(4,1);templates[sector]=dict(strings=strings,matrix=str(matrix),longitudinal_width=str(width),complete_longitudinal_action=[str(t)for t in action],wrong_diagonal_complete_difference=[str(t)for t in wrong])
 for col in range(45):
  template=templates['H'if col<12 else'M'];assert[[G.get((4*col+mu,4*col+nu),'0')for nu in range(4)]for mu in range(4)]==template['strings'];mixed=[]
  for mu in range(4):
   l=sy.sympify(G.get((4*col+mu,508+col),'0'),locals=loc);r=sy.sympify(G.get((508+col,4*col+mu),'0'),locals=loc);assert sy.simplify(l+E*f*q[mu]/sq)==0 and sy.simplify(r-E*f*q[mu]/sq)==0;mixed.append([mu,str(l),str(r)])
  checks.append(dict(color=col,sector='H'if col<12 else'M',all16_BB_entries_match_template=True,all4_mixed_edges=mixed))
 assert len(G)==1080
 return dict(H_M_templates=templates,all45_color_interfaces=checks,no_cross_color_or_extra_B_Lambda_edges=True)
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'ward_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 cl=load(O/'native_classification.json.gz');assert cl==load(O/'replay_classification.json.gz');packet=load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/native_inputs.json.gz');assert packet==load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/replay_inputs.json.gz');classes=cl['classes'];root=next(r for r in packet['roots']if r['state']=='F1'and r['family']=='preference');rootclass={};records=[]
 for c in classes:
  if c['kind']!='marked'or c['owner']!='R_F1':continue
  indices=[]
  for group in next(z for z in cl['roots']if z['owner']=='R_F1')['groups']:
   if group['signature']==[c[k]for k in['owner','kind','g','u','quantum','external']]:indices+=group['raw_indices']
  assert indices
  if not all(any(1962<=n<2142 for n,js in root['raw_root'][at][0])for at in indices):continue
  rows=[(at,root['raw_root'][at])for at in indices];tests={name:contract(rows,mom,omit)for name,mom,omit in[('right_l',4,None),('wrong_right_k',0,None),('omit_R_mu3',4,3)]};zero=not tests['right_l']['complete_contraction'];rootclass[c['id']]=zero;records.append(dict(class_id=c['id'],class_signature=c,complete_root_word_count=len(indices),contractions=tests,right_l_zero=zero));print('STAGE rootclass'+str(c['id'])+' right_l='+str(tests['right_l']['nonzero_positions']),flush=True)
 legs=ordinary_legs(packet);assert len(legs)==3;alllegs=all(z['all_B_legs_pure_divergence']for z in legs);edges=inverse();summaries=[];dispositions=[]
 for name in['original','0','1']:
  data=load(O/('native_support_'+name+'.json.gz'));assert data==load(O/('replay_support_'+name+'.json.gz'));raw=Counter();remaining=Counter();removed=Counter();decisions=[]
  for r,ro,g,u,e,flags,count in data['complete_root_orientation_profile_counts']:
   c=classes[r];eligible=(u==1 and g==1 and c['owner']=='R_F1'and c['g']==1 and c['u']==0 and rootclass.get(r,False)and alllegs);key=g,u,tuple(e);raw[key]+=count;(removed if eligible else remaining)[key]+=count;decisions.append(dict(root_class=r,orientation=ro,g=g,u=u,counts=e,path_flags=flags,typed_paths=count,disposition='ZERO_BY_CORRECT_R_SIDE_B_AND_G0_LONGITUDINAL_INTERFACE'if eligible else'RETAINED_NOT_EVALUATED_BY_THIS_PROOF'))
  profiles=[dict(g=g,u=u,counts=list(e),pattern=[n for n,v in zip(s.NAMES,e)for j in range(v)],raw_paths=count,removed_paths=removed[g,u,e],remaining_paths=remaining[g,u,e],entire_raw_profile_removed=bool(removed[g,u,e])and not remaining[g,u,e])for(g,u,e),count in sorted(raw.items())];summaries.append(dict(family=name,profiles=profiles,raw_paths=sum(raw.values()),removed_paths=sum(removed.values()),remaining_paths=sum(remaining.values())));dispositions.append(dict(family=name,all_root_orientation_profile_dispositions=decisions))
 art=save('full_source_right_root_tables.json.gz',dict(schema='FULL_SOURCE_FIRST_U_ROOT_INTERFACE_REDUCTION_V1',all_actual_R_F1_RB_class_tests=records,full_source_g0_B_leg_checks=legs,actual_free_inverse_interfaces=edges,complete_path_dispositions=dispositions,profile_summary=summaries,new_sourceful_proper_master_bridges_NOT_QUALIFIED=True,unprobed_zero_tail_paths_not_removed=True))
 out=dict(schema='FULL_SOURCE_RIGHT_ROOT_REDUCTION_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',R_F1_RB_classes_tested=len(records),zero_RB_classes=sum(rootclass.values()),all540_full_source_B_jet_columns_equal_LEFT_and_componentwise=alllegs,all45_actual_BB_and_mixed_longitudinal_interfaces=True,profile_summary=summaries,artifact=art,no_new_sourceful_proper_zero_claim=True,no_HB1_C5_activation=True,no_common_restoration_E5A5_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'ward_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
