from pathlib import Path
from types import ModuleType
from hashlib import sha256
import ast,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-source-response-support-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
role=sys.argv[1];assert role in['native','replay']and not(O/(role+'_capture.json')).exists()
if not(O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b9bac91ca60a7f43668c1ed83c462b95c93bfb60'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V826.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']
 for folder,files in[('canonical_so10_ghost_source_companion_catalog_g1_v1',['validation_receipt.json','PROOF.md','native_inputs.json.gz','replay_inputs.json.gz']),('canonical_so10_regulator_vertices_g1_recovery_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_BBC_full_source_catalog_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_g1_consistency_companion_carriers_v1',['validation_receipt.json','PROOF.md'])]:names+=['calculations/'+folder+'/'+n for n in files]
 sp=importlib.util.spec_from_file_location('full_response_support_preparer',O/'support.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);todo=[m];seen=set()
 while todo:
  mod=todo.pop()
  if id(mod)in seen:continue
  seen.add(id(mod));p=getattr(mod,'__file__',None)
  if not p:continue
  p=Path(p).resolve()
  if not p.is_relative_to(R):continue
  if not p.is_relative_to(O):names.append(p.relative_to(R).as_posix())
  todo.extend(v for v in vars(mod).values()if isinstance(v,ModuleType))
 for n in sorted(set(names)):assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 for n in['RECORD.md','support.py','run.py']:
  if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
 C.mkdir(parents=True,exist_ok=False)
 with(C/'old_git_tree.txt').open('xb')as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
 dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n)for n in sorted(set(names))},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'support.py'),role]);dump(O/(role+'_capture.json'),cap);dump(C/(role+'_capture.json'),cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
