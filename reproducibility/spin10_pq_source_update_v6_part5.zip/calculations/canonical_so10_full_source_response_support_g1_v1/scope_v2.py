from pathlib import Path
from hashlib import sha256
import gc,gzip,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'scope_v2_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 audit=load(O/'scalar_partition_scope_tables.json.gz')['complete_native_replay_equal_scan'];old=read(O/'scope_result.json');assert old['execution_state']=='COMPLETED'and old['cut_violations']==18408 and not old['first_u_pure_scalar_potential_robust_cut_applicable'];assert len(audit['complete_cut_violations'])==18408 and audit['total_raw_words']==765420
 cl=load(O/'native_classification.json.gz');assert cl==load(O/'replay_classification.json.gz');assert all(c['g']+c['u']>=1 for c in cl['classes']if c['kind']=='marked');assert next(c for c in cl['roots']if c['owner']=='R_F0')['disposition']=='WHOLE_F0_FULL_FREE_EXCHANGE_ZERO'and next(c for c in cl['roots']if c['owner']=='reference_F0')['disposition']=='FULL_NEW_REFERENCE_DIAGONAL_ZERO'
 decisions=[];bad=[];excluded_words=0;mixed_gu_root_words=0
 for row in audit['all20_full_raw_owners']:
  groups=[];excluded=row['kind']=='ordinary'and row['g']==1 and row['u']==1
  for group in row['all_raw_partition_indices']:
   partition=group['quantum_partition'];sm=group['has_scalar_or_Jx_mean'];cross=partition[0]!=partition[1];reasons=[]
   if excluded:disposition='G1U1_ORDINARY_HAS_NO_NONZERO_ROOT_WITHIN_GRADES';excluded_words+=len(group['raw_indices'])
   else:
    disposition='ACTIVE_PARTITION_CHECKED'
    if not row['g']and cross:reasons.append('ACTIVE_G0_CROSSING')
    if partition==['GF','GF']and sm:reasons.append('ACTIVE_GF_PAIR_SCALAR_MEAN')
    if row['u']and not row['g']and(partition!=['GF','GF']or sm):reasons.append('ACTIVE_U0_NOT_PURE_GF')
    if row['kind']=='roots'and row['u']and row['g']and partition==['scalar','scalar']:reasons.append('GU_ROOT_PURE_SCALAR_LOOP')
    if row['kind']=='roots'and row['u']and row['g']and cross:mixed_gu_root_words+=len(group['raw_indices'])
   groups.append(dict(quantum_partition=partition,has_scalar_or_Jx_mean=sm,raw_word_count=len(group['raw_indices']),disposition=disposition,violations=reasons))
   if reasons:bad.append(dict(kind=row['kind'],input_row=row['input_row'],group=group,reasons=reasons))
  decisions.append(dict(kind=row['kind'],input_row=row['input_row'],owner=row['owner'],family=row['family'],g=row['g'],u=row['u'],all_partition_decisions=groups))
 cps=read(O.parent/'canonical_so10_chiral_probe_support/validation_receipt.json');assert cps['both_full_generators_and_QG_matter_BV_brackets_zero']and cps['classical_augmented_defect']=='UNCHANGED_NONZERO_IHAT'and not cps['full_chiral_QAP_measure_phase_physical_restoration'];good=not bad
 art=save('graded_root_scalar_scope_v2_tables.json.gz',dict(schema='GRADED_ROOT_FIRST_U_SCALAR_POTENTIAL_SCOPE_V2',all20_owner_partition_dispositions=decisions,complete_active_condition_violations=bad,all_retained_marked_roots_have_positive_g_or_u=True,ordinary_g1u1_words_excluded_by_actual_root_grades=excluded_words,mixed_gu_root_words_retained_not_declared_zero=mixed_gu_root_words,old_simple_cut18k_violations_preserved_NOTPROVEN=True,qualified_CPS_G_QG_sources_only_Ja_JLambda_reused_WRITTEN_SCOPE=True,first_u_pure_scalar_potential_robust_cut_applicable=good,unprobed_physical_potential_census_NOT_CLAIMED=True))
 out=dict(schema='GRADED_ROOT_SCALAR_POTENTIAL_SCOPE_RESULT_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',old_simple_cut_NOTPROVEN_18408_violations_preserved=True,active_condition_violations=len(bad),ordinary_g1u1_words_excluded_by_root_grades=excluded_words,mixed_gu_root_words_retained=mixed_gu_root_words,first_u_pure_scalar_potential_robust_cut_applicable=good,unprobed_full_potential_census_NOT_CLAIMED=True,qualified_CPS_source_support_reused_not_new_matter_proof=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);dump(O/'scope_result_v2.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
