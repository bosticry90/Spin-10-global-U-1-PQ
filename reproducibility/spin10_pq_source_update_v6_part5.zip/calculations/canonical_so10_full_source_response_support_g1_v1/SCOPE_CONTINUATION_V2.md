# Graded-root scalar boundary continuation, same scientific target

The simple cut audit COMPLETED47.345s/60 and returned18,408 violations.
Its proposed scalar-free explicit-u premise is FALSE: Fu1_M has1184
mixed scalar/GF root words, and the gu ordinary has17224 scalar-related
words,5248 with both quantum endpoints GF. Preserve its full source,
result, capture and complete765420-word index tables. It is not a failed
execution and not a qualified simple-cut proof. Do not relabel it PASS.

V2 uses the same complete measured partition tables with the ACTUAL g/u
budget, rather than repeating an unnecessary global scalar-free premise.
The scientific target remains first-u,g<=1 support robustness under
pure-scalar potential insertions, not a smaller selected family.

First F0 is a qualified WHOLE root zero; its reference is also zero.
Every remaining marked root has g>=1 or u>=1. Therefore an ordinary
g1u1 vertex cannot occur at overall g<=1,u1 with ANY nonzero root. Its
scalar-related words remain preserved, not declared zero globally.

The active explicit-u g0 roots/ordinary vertices are pure GF. The actual
gu root CAN have scalar/GF crossing pairs; check it has NO scalar/scalar
pair and NO all-GF pair with scalar/Jx mean. A closed first-u path touches
GF either at its u0 root/ordinary vertex or at its gu root (GF or mixed).
To visit and leave the scalar block it still needs two crossings. Check
that all g0 ordinary vertices have no crossing; hence every crossing costs
g1, exceeding the totalg<=1 bound. Check remaining g1u0 all-GF pairs and
all g0 all-GF pairs have no scalar/Jx mean as well. These conditions must
be checked on all full raw partition groups, not inferred from labels.

An arbitrary pure-scalar potential adds only scalar/scalar Hessian edges,
never a GF crossing. It does not change field BV flows. The qualified CPS
proof has G and QG BV sources ONLY Ja/JLambda; no Jx, so (V(x),G)=0 and
(V(x),QG)=0. Thus adding V does not create a missing explicit-u action/
root either. Bind/reuse that exact source-support proof; no new potential
choice, master/QAP/fermion theorem or unprobed potential census follows.

This graded proof accommodates every measured violation of the failed
simple cut. If any active condition fails, the target remains unresolved;
do not discard the offending words. New worker60s after imports/8GiB
sampled private/350MiB floor/same64MiBpacket/10MiBartifact. Freeze new
source/copies/bindings before run; capture repo+D before judging success.
Historical contracts and sources unchanged. Final replay retains both the
completed negative audit and this new scope result with their original bounds.
