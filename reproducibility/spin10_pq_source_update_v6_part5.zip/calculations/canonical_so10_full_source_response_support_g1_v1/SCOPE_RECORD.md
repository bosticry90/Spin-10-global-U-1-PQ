# Scalar-potential boundary and first-u completeness scope

The support workers' complete_sourceful_original_H_M_g0_g1_support field
means completeness RELATIVE TO THEIR QUALIFIED RAW INPUT PACKET, as the
initial freeze states. It is not an unprobed full physical potential census.
Those8 ordinary inputs omit physical scalar potential Hessians, which the
older zero-scalar-mean selected calculations excluded by their own scope.
Allowing arbitrary scalar means in a new support over-envelope cannot make
those omitted terms scientifically zero. Preserve both workers unchanged.

Claim FS-SUPPORT-3: the FIRST-u g<=1 support still has no scalar visits or
scalar/BV-scalar means even after arbitrary allowed PURE-SCALAR potential
insertions. This follows from a two-crossing loop cut, provided the actual
raw interfaces have the following support; test them before using the claim.

Partition quantum fields into GF (B,Lambda,C,a) versus physical scalar x.
All explicit-u roots/ordinary vertices must be purely GF, with no scalar
or BV-scalar means. All g0 ordinary vertices and the F0 root must have no
crossing GF/scalar quantum pair. All retained g1 vertices with scalar/Jx
means and both quantum endpoints GF must be absent. Preserve every raw
index by partition/category, all violations, all mean-scalar flags and
both native/replay scans before judging these conditions.

A first-u closed loop touches a u vertex in GF. To visit the scalar block
and return needs at least TWO crossing vertices. Every such crossing has
g1, so cannot occur at overallg<=1. Adding any g0/g1 pure-scalar potential
Hessian only adds scalar/scalar edges, never a crossing. It cannot supply
scalar means on an all-GF path. This remains true with arbitrary intra-
scalar representation mixing/resummation; do not rely on same-representation
free erasure to establish the stronger statement. Potential BV field flows
are unchanged because an ordinary scalar potential has no BV sources.

This is a support theorem for the declared gauge/scalar input language,
not a model-specific QAP, full matter/Yukawa/background prescription or a
new physical potential choice. Unprobed scalar loops CAN be changed by
potential insertions and remain outside this packet census. The full new
F1 reference diagonal is NONZERO and correctly retained, unlike its old
selected projections; do not generalize the earlier reference zero.

One worker60s after imports,8GiB sampled private/350MiB floor,64MiB packet/
10MiB artifact. Freeze sources/copies/bindings before launch. Complete
capture repo+D before judging. Negative support means the cut proof is
unavailable, not an anomaly. No retries, truncation or silent expansion.
Final validation will replay the completed audit and bind this explicit
interpretation; no historical worker/receipt/status is rewritten.
