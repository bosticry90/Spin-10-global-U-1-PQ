# Source support gaps and full-source vector-root reduction

FS-SUPPORT-1 counts the entire oriented TYPE path language in the frozen
full-source packet's bare-mean-dimension<=5 envelope. FS-SUPPORT-2 removes
qualified first-u paths by actual right-vector root/ordinary interfaces.
FS-SUPPORT-3 justifies first-u scalar-potential robustness by a graded-root
cut after an earlier, stronger scalar-free premise failed. These are INPUT
support/operator results, not a full proper response, counterterm basis,
restoration, model QAP or E5/A5 promotion. The full objective remains open.

## What is complete, and what is not

The original finite Euclidean A0/intrinsic0/1/constant-mark raw packet has
12 roots and8 ordinary Taylor halves. Every one of276184 root words and
489236 ordinary words has a disposition; there were no rejected indices in
this new canonical-source/bare-dimension envelope. All643 bosonic/ghost
ports and45 colors precede collapse to16 mean species and11 active quantum
types. Source/Euler/Taylor operations preceded this mean classification.
The source dimensions/ghost/parity are the qualified ones, particularly
JLambda dimension1 and JB/Jx/JC/Ja dimension2. No mean jets or momentum/
reference-mass coefficient is discarded from the underlying frozen operands.

This is a NECESSARY upper support for a local dimension5 response, not a
Lorentz/color/reality/IBP/exchange basis or locality theorem. It says nothing
about arbitrary nonlocal/higher-dimensional IR-dependent Gamma terms. The
worker's completeness field is relative to its declared qualified raw packet.
The unprobed FULL physical potential census is explicitly NOT established.
The inherited8 ordinary halves omit scalar-potential Hessians; their absence
is not a physical zero. First-u robustness has its separate proof below.

The full F0 paired-exchange proof is checked before discarding its entire
root. Each full reference diagonal is checked anew. Unlike the old named
projections, the full F1 reference diagonal is NONZERO and remains retained.
That is a useful scope distinction, not an invalidation of those old zeros.
All Fu0/Fu1 and physical gauge/scalar owners remain before return support.

## Exact transfer language and verification

Each type class is an actual owner/g/u/ordered-quantum-pair/mean-multiplicity
group, not one raw color word. There are140 such retained classes. Every
vertex has positive bare-mean-dimension+g+u cost. A target with bare mean
dimension<=5,g<=1,u<=1 therefore uses at most7 vertices including its root.
All ordinary sequences of lengths0..6 are retained; the sixth-level tables
are empty in the measured inputs. This is a proved cost bound, not a cutoff
chosen after inspecting the answers. Zero-mean u inverse insertions remain.

For each ordinary oriented class, the free-edge incidence gives a matrix
entry with a commutative NONNEGATIVE INTEGER mean/g/u monomial. Native
appends vertices, forming powers by right multiplication. Replay prepends
them by left multiplication on its own full raw inputs. Every coefficient
of every length table, transfer entry with class/orientation provenance,
and root/orientation/profile count is saved. Canonical artifacts agree
byte-for-byte. This counts paths; it does not supply Grassmann loop signs,
color traces, Bose factors or cancellations. Coefficient commutativity is
only for these unsigned type counts, not an altered field-statistics rule.

An independent explicit word enumerator checks BBC in the NEW classes.
It gives original/H/M0/0/2; wrong H/M edges give M8, wrong LL edges M4.
Inverse-u omission is tracked exactly by a path flag. For example M aCC
changes112->64 and vector46->36, while BBC stays2 (blind). After completion,
final validation compares16 known target counts with their qualified V792,
V808 and V826 receipts; these were not construction operands.

The packet census has original7 profiles/48 paths, H1 profile/22 paths and
M19 profiles/536 paths. M includes3 g0-u profiles and16 g1-u profiles. Six
nonempty g1 profiles are the five nonempty old LambdaCC parents plus BBC;
there are10 additional g1 candidate profiles. The empty JLambdaCC parent
is also correctly reproduced. These are not10 new physical parameters or
10 measured nonzero quantum amplitudes. No first-u scalar visit or scalar/
BV-scalar mean returns in these completed packet tables.

## Actual full-source vector-root reduction

Every R_F1 class whose R-side quantum leg is B is tested with its correct
R momentum l: sum_mu l_mu R_(...,B_Rmu). Every other color/source/mean jet/
momentum/coefficient atom remains fixed. Coefficient-ring addition agrees
with literal Fraction accumulation for each full contraction and control.
Of10 tested classes,8 vanish;2 retain1336 nonzero positions each. Those
nonzero classes remain. Wrong-k and omitted-mu3 controls are fully saved,
with sensitivity/insensitivity exposed rather than assuming all roots zero.

The full original/H/M g0 ordinary Taylor halves have ONLY diagonal first
jets d_mu qB_mu on every quantum B leg. For every color the four jet
partials are identical, checked by literal even-variable removal and LEFT
jet differentiation: all540 columns, sources/means unrestricted. This is
the complete divergence-leg property before any named mean restriction.

All45 actual V791 G_F B/B blocks match their H/M templates. Each satisfies
G_BB(q)q=E f Omega q/q_squared; its diagonal-only control fails. Every
mixed B/Lambda edge is respectively minus/plus E f q_mu/q_squared. Thus a
right-side B next to a g0 B vertex, or a Lambda endpoint, receives precisely
the longitudinal direction tested in the root contraction, with a common
even same-line profile. Both root orientations are covered.

At first-u a g1/u0 F1 root leaves all ordinary vertices at g0 and requires
at least one of them. Each such closed path with a qualified zero right
root therefore vanishes BEFORE remaining color/Grassmann/momentum factors.
Zero-tail unprobed tadpoles are deliberately not removed by this argument.
Every root/profile count has an explicit removed/retained disposition.

The reduction removes12 H paths (22->10) and200 M paths (536->336), leaving
the original48 unchanged. In M it removes ALL candidates for Ja-aCC(4),
a-a-CCC(44), B-Ja-C(2), BBC(2) and BB-Lambda-C(4). It reduces aCC112->72,
Lambda-aCC164->120, B-aCC42->16 and vector46->34 among others. The old
completed46-path vector result is not invalidated; this proves zeros inside
its original contraction inventory. A retained path is still not presumed
nonzero. The two nonzero root classes are not fitted to a desired remainder.

These are RAW CURRENT zeros. V826 already supplies BBC's proper premise;
the new sourceful proper/master prerequisites have NOT been supplied here.
No automatic new Ja-aCC or other proper quantum zero follows. The full
quantum/counterterm equation remains distinct from its regulator support.

## Failed simple cut, and the successful graded continuation

The first scalar boundary audit completed47.345s/60 with18408 violations.
Its hypothesis that every explicit-u vertex was scalar-free is FALSE.
There are1184 mixed Fu1_M root words and17224 scalar-related gu ordinary
words, including5248 all-GF pairs with scalar/BV-scalar means. Its complete
765420-word partition journals, source, capture and negative result remain
immutable. Execution completed; the simple cut is NOT PROVEN.

The old audit's ancillary all_scalar_GF_crossings_require_g1 flag combines
ALL premise violations, including the unrelated scalar-free-u failures.
Its false value is not a measured g0 crossing. The graded proof uses the
complete partition groups directly; final review additionally counts actual
g0 crossing groups. Preserve the misleading old flag as historical output.

V2 uses the actual grades. F0 is a WHOLE zero and its reference is zero;
EVERY retained marked root has g>=1 or u>=1. Therefore an ordinary g1u1
vertex cannot accompany any nonzero root within overallg<=1,u1. All165608
gu ordinary words are excluded from this target by that grade argument,
not globally declared zero. The1184 mixed gu root words remain present.

The complete measured partitions show no active g0 scalar/GF crossing,
no active all-GF pair with scalar/Jx means, no pure-scalar gu root, and
pure GF u0 roots/ordinary vertices. A first-u loop must touch GF. To visit
the scalar block and return requires two crossings; each costs g1, beyond
the totalg<=1 budget. The measured mixed gu root provides one crossing,
not a counterexample to this stronger graded statement. V2 checks every
owner/partition disposition and has ZERO active-condition violations.

Adding arbitrary PURE-SCALAR potential Hessians cannot create a crossing
or scalar means on an all-GF path. It also does not change field BV flows.
The qualified CPS G/QG source-support proof has ONLY Ja/JLambda sources,
so (V(x),G)=(V(x),QG)=0: it supplies no missing u root/ordinary vertex.
This is reused source-support reasoning, not a new matter/QAP calculation
or physical potential adoption. Unprobed scalar loops lack the GF probe
argument and CAN be affected by potential insertions; their full physical
census remains open. The initial stronger premise stays false.

## Consequence and next discriminating work

The present first-u investigation is broader than six LambdaCC parents.
The gap census and actual operator zeros prevent treating a partly measured
projection as the complete response, while avoiding unnecessary integrations
for four additional removed profiles. Surviving extra g1 M profiles include
C, Lambda-C, Lambda-Lambda-C, B-C, Lambda-aCC and B-aCC. Their bare patterns
are not independent coefficient requirements: Lorentz/IBP/support and the
existing finite-auxiliary results must be compared before commissioning
new amplitudes. In particular do not count a one-ghost tadpole as a new
admissible local tensor without its dimension/ordinary-boundary analysis.

Next qualify the missing proper/source interfaces for these new raw-current
scopes and reuse the V782-V786 auxiliary evidence to distinguish genuinely
unmeasured inputs. Preserve V823/V824's excluded fixed-companion routes and
V826's actual BBC zero. Do not choose coefficients to rescue a normalization
or treat this input census as the blocked HB1/C5 counterterm/cohomology basis.

Track B demonstrates exact source-inclusive counting, sensitive interface
reduction, a falsified scope premise and a successful budget-aware proof
using its preserved counterexamples. Action/definitions/edges/ring/software/
AI author and inherited CPS/physical proofs are shared. No independent
scientist, Lean theorem or empirical result is claimed. State113/34of39,
E5/A5 open and seven historical custody NOTPASS are unchanged. Evidence
validation, execution and director scientific acceptance remain separate.
