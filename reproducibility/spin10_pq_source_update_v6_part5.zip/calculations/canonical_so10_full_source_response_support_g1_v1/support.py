from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('full_source_support_raw_helpers',O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/catalog.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
ROLE=sys.argv[1]if __name__=='__main__'else'native';J=m.J;read=m.read;load=m.load;digest=m.digest
NAMES=['B','xPhi','xSigma','xphi','xS','Lambda','C','a','JB','JxPhi','JxSigma','Jxphi','JxS','JLambda','JC','Ja'];REP=[0,180,234,486,506,508,553,598,643,823,877,1129,1149,1151,1196,1241];DIMS=[J.dimension(n)for n in REP];GH=[0,0,0,0,0,0,1,-1,-1,-1,-1,-1,-1,-1,-2,0];PAR=[J.parity(n)for n in REP];Z=(0,)*16
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 name=ROLE+'_'+name+'.json.gz';blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def species(n):
 if n>=643:return 8+species(n-643)
 return 0 if n<180 else 1 if n<234 else 2 if n<486 else 3 if n<506 else 4 if n<508 else 5 if n<553 else 6 if n<598 else 7
def dimension(e):return sum(n*d for n,d in zip(e,DIMS))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def allowed(z,probe):
 owner=z['owner']
 if probe is None:return not('probe'in owner or'Fu'in owner)
 other=1-probe;return owner!='GF_probe'+str(other)and not any(t in owner for t in['Fu0_'+str(other),'Fu1_'+str(other)])
def classify(word,root):
 e=[0]*16;qq=[];copies=[0,0]
 for n,js in word:
  if 1319<=n<1962:copies[0]+=1;qq.append(m.v.tag(n-1319))
  elif root and 1962<=n<2605:copies[1]+=1;qq.append(m.v.tag(n-1962))
  else:
   if not 0<=n<1286:return 'OUTSIDE_DECLARED_CANONICAL_A0_MEANS',None,None
   e[species(n)]+=1
 if copies!=([1,1]if root else[2,0]):return 'WRONG_QUANTUM_COPIES',None,None
 if dimension(e)>5:return 'BARE_MEAN_DIMENSION_OVER5',None,None
 return None,tuple(qq),tuple(e)
def projection(row,root):
 raw=row['raw_root']if root else row['quadratic_Taylor_half'];groups=defaultdict(list);bad=defaultdict(list);kept=[];owner=('R_'+row['state']if row['family']=='preference'else'reference_'+row['state'])if root else row['owner'];kind='marked'if root else'ordinary';disposition='RETAINED'
 for at,entry in enumerate(raw):
  word,cc=(entry[0],entry[2])if root else entry;why,q,e=classify(word,root)
  if why:bad[why].append(at);continue
  assert all(atom[0]==row['g']for atom,num,den in cc),'RAW_COUPLING_GRADE';groups[(owner,kind,row['g'],row['u'],q,e)].append(at);kept.append(at)
 diagonal=None
 if root and row['state']=='F0'and row['family']=='preference':
  free,normal=m.m.free_exchange(m.m.decode(raw));assert m.m.encode(free)==raw and not normal and row['free_proof']['whole_free_zero'];disposition='WHOLE_F0_FULL_FREE_EXCHANGE_ZERO'
 if root and row['family']=='reference':
  diagonal=m.m.encode(m.m.diagonal(m.m.decode([raw[i]for i in kept])))
  disposition='FULL_NEW_REFERENCE_DIAGONAL_ZERO'if not diagonal else'RETAINED_NONZERO_REFERENCE_DIAGONAL'
 assert sorted(kept+[i for ids in bad.values()for i in ids])==list(range(len(raw)))
 data=dict(owner=owner,kind=kind,g=row['g'],u=row['u'],family=row['family']if root else None,raw_word_count=len(raw),raw_mathematical_sha256=m.m.mhash(raw),kept_raw_indices=kept,rejected=[dict(reason=k,raw_indices=v)for k,v in sorted(bad.items())],groups=[dict(signature=[a,b,g,u,list(q),list(e)],raw_indices=ids)for(a,b,g,u,q,e),ids in sorted(groups.items())],disposition=disposition,complete_reference_diagonal=diagonal)
 return data,set(groups)if disposition.startswith('RETAINED')else set()
def encode_states(states):return[[a,b,g,u,list(e),z,c]for(a,b,g,u,e,z),c in sorted(states.items())]
def encode_output(out):return[[r,ro,g,u,list(e),z,c]for(r,ro,g,u,e,z),c in sorted(out.items())]
def transfer(classes,probe):
 kinds=sorted({q for c in classes for q in c['quantum']});entries=defaultdict(list)
 for c in classes:
  if c['kind']!='ordinary'or not allowed(c,probe):continue
  assert dimension(c['external'])+c['g']+c['u']>=1,'ZERO_COST_NONREFERENCE_VERTEX'
  for ro in[0,1]:
   l,r=c['quantum'][ro],c['quantum'][1-ro]
   for a in kinds:
    if m.v.edge(a,l):entries[(a,r,c['g'],c['u'],tuple(c['external']),int(bool(c['u']and not any(c['external'])))| (2 if any(q.startswith('x')for q in c['quantum'])else 0))].append([c['id'],ro])
 return kinds,entries
def tails(kinds,entries,probe):
 umax=int(probe is not None);states=Counter({(a,a,0,0,Z,2 if a.startswith('x')else 0):1 for a in kinds});allstates=[];right=defaultdict(list);left=defaultdict(list)
 for(a,b,g,u,e,z),ids in entries.items():right[a].append((b,g,u,e,z,len(ids)));left[b].append((a,g,u,e,z,len(ids)))
 for n in range(7):
  allstates.append(states);print('STAGE '+str(probe)+' tail'+str(n)+'='+str(len(states)),flush=True)
  if n==6:break
  new=Counter()
  for(a,b,g,u,e,z),count in states.items():
   for end,gg,uu,ee,zz,mult in(right[b]if ROLE=='native'else left[a]):
    ng,nu=g+gg,u+uu
    if ng>1 or nu>umax:continue
    ne=add(e,ee);cost=dimension(ne)+ng+nu
    if dimension(ne)>5 or cost>6:continue
    key=(a,end,ng,nu,ne,z|zz)if ROLE=='native'else(end,b,ng,nu,ne,z|zz);new[key]+=count*mult
  states=new
 return allstates
def family(classes,probe):
 kinds,T=transfer(classes,probe);levels=tails(kinds,T,probe);out=Counter();roots=[c for c in classes if c['kind']=='marked'and allowed(c,probe)];desired_u=int(probe is not None)
 for root in roots:
  rg,ru,re=root['g'],root['u'],tuple(root['external'])
  for ro in[0,1]:
   start,initial=root['quantum'][ro],root['quantum'][1-ro]
   for level in levels:
    for(a,b,g,u,e,z),count in level.items():
     if a!=initial or not m.v.edge(b,start)or g+rg>1 or u+ru!=desired_u:continue
     ne=add(e,re)
     if dimension(ne)>5:continue
     assert sum(x*y for x,y in zip(ne,GH))==1 and sum(x*y for x,y in zip(ne,PAR))%2==1,'CLOSED_PATH_GHOST_OR_PARITY'
     out[(root['id'],ro,g+rg,u+ru,ne,z|(2 if any(q.startswith('x')for q in root['quantum'])else 0))]+=count
 aggregate=Counter();omitted=Counter()
 for(r,ro,g,u,e,z),count in out.items():aggregate[g,u,e]+=count;omitted[g,u,e]+=count if not(z&1)else 0
 profiles=[dict(g=g,u=u,counts=list(e),pattern=[name for name,n in zip(NAMES,e)for j in range(n)],bare_dimension=dimension(e),typed_oriented_paths=count,omit_zero_mean_inverse_U_paths=omitted[g,u,e])for(g,u,e),count in sorted(aggregate.items())]
 # An explicit independent word enumerator tests one known target on the NEW classes.
 target=list(Z);target[0]=2;target[6]=1;controlcases=[]
 for mode in['actual','mix_HM','LL']:
  controlclasses=[dict(c,kind=c['kind']if allowed(c,probe)else'excluded')for c in classes];actual=m.paths(controlclasses,tuple(target),desired_u,probe,ROLE,mode=mode);controlcases.append(dict(mode=mode,complete_BBC_paths=actual))
 maincount=aggregate.get((1,desired_u,tuple(target)),0);assert len(controlcases[0]['complete_BBC_paths'])==maincount,'TRANSFER_VERSUS_EXPLICIT_BBC_WORDS'
 art=save('support_'+('original'if probe is None else str(probe)),dict(schema='FULL_SOURCE_TYPED_RESPONSE_SUPPORT_V1',probe=probe,all_quantum_types=kinds,path_flags=dict(bit0='contains_zero_mean_inverse_u',bit1='visits_internal_scalar'),complete_ordinary_transfer=[[a,b,g,u,list(e),z,ids]for(a,b,g,u,e,z),ids in sorted(T.items())],all_complete_tail_coefficients=[dict(ordinary_vertices=n,coefficients=encode_states(states))for n,states in enumerate(levels)],complete_root_orientation_profile_counts=encode_output(out),profiles=profiles,independent_BBC_controls=controlcases,max_ordinary_vertices=6,counts_are_unsigned_typed_paths_not_amplitudes=True))
 result=dict(family='original'if probe is None else'H'if probe==0 else'M',artifact=art,patterns=len(profiles),total_paths=sum(aggregate.values()),profiles=profiles,tail_state_counts=[len(q)for q in levels],BBC_control_counts={row['mode']:len(row['complete_BBC_paths'])for row in controlcases},scalar_return_profiles=[dict(g=g,u=u,counts=list(e))for g,u,e in sorted({(g,u,e)for r,ro,g,u,e,z in out if z&2})])
 del levels,out;gc.collect();return result
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start();assert ROLE in['native','replay']
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in['aCC_reference_integrability_prediction','log_source_restoring_preimage','coupled_lower_kinetic_log','_aCC_catalog.json','_JBCC_catalog.json','_JLambdaCC_catalog.json','_BBC_catalog.json']),'OLD_SELECTED_CATALOG_OR_DESIRED_REMAINDER_DENIED'
 sys.addaudithook(guard)
 assert DIMS==[1,1,1,1,1,2,1,1,2,2,2,2,2,1,2,2]and PAR==[0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0]
 packet=load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1'/(ROLE+'_inputs.json.gz'));assert len(packet['roots'])==12 and len(packet['ordinary'])==8;roots=[];ordinary=[];sigs=set()
 for row in packet['roots']:
  data,s=projection(row,True);roots.append(data);sigs.update(s)
 for row in packet['ordinary']:
  data,s=projection(row,False);ordinary.append(data);sigs.update(s)
 classes=[dict(id=i,owner=a,kind=b,g=g,u=u,quantum=list(q),external=list(e))for i,(a,b,g,u,q,e)in enumerate(sorted(sigs))];assert all(dimension(c['external'])+c['g']+c['u']>=1 for c in classes)
 provenance=save('classification',dict(species=[dict(name=n,representative=r,dimension=d,ghost=g,parity=p)for n,r,d,g,p in zip(NAMES,REP,DIMS,GH,PAR)],roots=roots,ordinary=ordinary,classes=classes,all_raw_indices_disposed=True,bare_dim5_envelope_not_tensor_or_cohomology_basis=True));print('STAGE full_source_classes='+str(len(classes)),flush=True)
 results=[family(classes,probe)for probe in[None,0,1]];out=dict(schema='FULL_SOURCE_RESPONSE_SUPPORT_CENSUS_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,classification=provenance,families=results,complete_sourceful_original_H_M_g0_g1_support=True,no_color_sign_amplitude_proper_zero_or_counterterm_basis_claim=True,no_HB1_C5_activation=True,shared_type_edge_source_software_AI_author=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/(ROLE+'_result.json'),out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
