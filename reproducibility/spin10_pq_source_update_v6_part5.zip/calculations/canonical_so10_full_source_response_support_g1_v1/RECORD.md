# Full source response support census — bounded execution freeze

Continue b9bac91ca60a7f43668c1ed83c462b95c93bfb60/main,V826 on D:.
Preflight clean, no matching live workers, declared bytes authenticated only.
Current AGENTS controls execution; full investigation goal ACTIVE, preceding
turn PROGRESS. State113/34of39,E5A5open unchanged. No agents/new branch/
worktree/push/adoption/protected promotion/external action. Flavor paused;
HB1/C5 blocked. This is a quantum INPUT SUPPORT census, not activation or
enumeration of the blocked counterterm/cohomology complex.

Question FS-SUPPORT-1: do full action-derived g0/g1, original/first-u_H/M
regulator currents have additional candidate local response patterns beyond
the six LambdaCC consistency parents and V826's BBC input? That six-family
list is target-specific, not a full Slavnov basis. Existing quantum evidence
and restricted normalization failures make a gap census more informative
than another coefficient chosen to repair one favored correction. Possible
outcomes: no additional returning patterns, additional finite candidate
patterns, or resource-limited/incomplete support. No coefficient or proper
zero will be inferred from a count without its separate premises.

Freeze original finite formal Euclidean A0/constant-mark and existing
intrinsic0/1 action inputs. Use all12 FULL raw regulator roots and all8 FULL
ordinary Taylor halves in the qualified native/replay input packets. Sources
are retained AFTER their actual source/Euler/Taylor operations, not removed
because earlier targets excluded them. All643 bosonic/ghost field ports,
all45 colors and all physical scalar representations precede type collapse.
No fermion-source/matter extension or unprobed hatted zero is claimed.

Means include eight field types B,xPhi,xSigma,xphi,xS,Lambda,C,a and their
eight BV sources. Use existing dimensions/ghost/parity, bare mean dimension
<=5 as a NECESSARY upper envelope for the declared local dimension5
Slavnov response. Do not count this as a full local tensor basis or all
nonlocal/higher-dimensional IR-dependent Gamma terms. Keep all mean jets,
quantum momenta/reference masses in the raw operand provenance; no Lorentz,
IBP, reality, color, exchange or amplitude quotient is taken. Unknown
potential/matter terms outside the qualified raw packet are not set zero.

Every raw word gets a kept/rejected index and type-profile disposition.
Source dimensions are NOT the conjugate field dimensions: JLambda dim1,
JB/Jx/JC/Ja dim2. Original F0 is removed only by its full paired-exchange
proof. Full new reference diagonals are tested; a nonzero reference remains
as a marked root, not discarded or assumed zero. All Fu0/Fu1 and physical
gauge/scalar ordinary owners survive until actual support. Fixed free
edges remain same-sector BB/BL/LB/Ca/aC and same-representation scalar.

Each nonreference vertex has positive bare-mean-dimension+g+u cost. At most
7 vertices can feed dimension<=5,g<=1,u<=1; thus at most6 ordinary vertices
after a root. Retain zero-mean u/g inverse responses. Keep a zero-U marker
so the exact counterfactual omitted-inverse-u counts are available without
amplitude subtraction, plus a scalar-visit marker for every internal leg.
Additional same-scalar zero-cost reference chains
cannot create a reduced return; if scalar returns exist, flag further
resummation analysis rather than asserting them absent.

Count ALL oriented TYPE paths with a nonnegative integer polynomial transfer
matrix. Native appends ordinary vertices to path states; replay prepends
them, on respective full native/replay raw inputs. Save every transfer
entry with its original class/orientation provenance, all complete n=0..6
coefficient tables and every root/orientation/profile count. These are exact
finite path-language counts, not signed/color amplitudes or symmetry factors.
Different enumeration direction shares the type/edge/algebra definitions;
it tests indexing/order completeness, not shared physical assumptions.

Independent explicit path enumeration on the fresh full classes checks
the BBC profile in each family; wrong H/M and LL edges are negative
controls with complete paths. The completed main construction is saved
before any old selected-count calibration. Final review may compare known
BBC/BLambdaC/JaLambdaC/aCC/JBCC/JLambdaCC counts with owning receipts. Such
comparisons are controls, not coefficient construction operands. Constructor
denies old selected catalogs, V814 prediction and V823/V824 correction data.

Native/replay run SEQUENTIALLY, each240s after imports,8GiB sampled private,
350MiB launch commit floor,64MiB complete packet,10MiB artifact. Freeze
sources/copies/bindings before launch. Full monitored captures repo+D before
judging success. Failure/exhaustion incomplete NOTPASS, no truncation,
automatic retry or silent resource expansion. Further amplitude/master/
normalization work requires a new frozen bounded calculation.

Final review will freeze separately, compare completed full artifacts and
nonruntime results, inspect actual source/type/controls and old qualified
count calibrations, run E4 exactly once/no fresh/fixed D: context, preserve
all old Git entries/project_state and stage raw bytes before local commit.
No director acceptance, full restoration/E5A5/common measure/QAP/physical
viability follows. Track B tests whether support-aware exact counting can
expose omitted inputs without an indefinite coefficient-search platform.
Shared action/chart/ring/software/AI author are explicit limitations. No
outside scientist, proof assistant, new benchmark platform or experiment.
