# Full-source right-root path reduction freeze

The completed two support routes agree:140 classes, original7/H1/M19
profiles, with48/22/536 unsigned typed paths. These counts have NOT earned
proper/source amplitude qualification. Before more integrations, test the
ACTUAL full-source R_F1 right-vector annihilator and all g0 ordinary B legs.
This is a new scope check, not an aCC/BBC zero imported by its name.

Bind both full support artifacts/results/captures, original preparation,
actual full native/replay V791 inverse packets and current AGENTS. For each
R_F1 class with R-side B, sum ALL4 components times its ACTUAL l_mu,
preserving every color/other momentum/mean jet/source word/coefficient atom.
Compare ring accumulation with literal Fraction accumulation. Preserve
complete correct, wrong-k and omitted-last-vector-component contractions.
A nonzero class remains nonzero; no blanket transversality is presumed.

For every g0 ordinary GF original/H/M full quadratic Taylor half, check
that every quantum B occurrence is precisely d_mu qB_mu, and that all4
partial derivatives with respect to these diagonal jets are equal for
each color. Compute them by literal even-variable removal and independent
LEFT jet derivatives. Preserve all540 columns, full violations and raw
positions. This is the complete source-dependent local divergence-leg
proof, before any named mean projection or Fourier alignment.

Read actual V791 G_F. Check all45 color B/B blocks against their H/M
templates; on each template verify G_BB(q)q is a scalar multiple of q.
All45 mixed B/Lambda and Lambda/B edges must be longitudinal as well,
with no cross-color entries. Wrong diagonal-only G_BB is a sensitive
control. Full same-line even profiles are retained; no inverse heat
operator is detached from its adjacent covariance.

Reduction ceiling: only FIRST-u rows with R_F1 g1/u0, a correctly zero
R-side vector contraction, and at least one ordinary vertex. Their g1
budget leaves all ordinary vertices at g0. The actual R-side B adjacent
free endpoint is B or Lambda. A g0 B vertex is longitudinal by the full
jet check; a Lambda edge is longitudinal directly. Hence the complete
path vanishes before color/Grassmann/remaining momentum contractions.
Record EVERY root/profile count disposition; do not remove other roots,
nonzero contractions, g0 first-u rows or unprobed zero-tail tadpoles.

This proves raw regulator-current path zeros. NEW sourceful proper/master
bridges are NOT supplied by this calculation. V826 remains the qualified
BBC proper zero; broader proper response, full restoration, tensor/IBP
completeness and E5/A5 do not follow. Partial reduction is a valid result.

One worker180s after imports/8GiB sampled private/350MiB launch floor,
same64MiB packet/10MiB artifact. Freeze sources/copies/hash bindings before
launch; complete capture repo+D before judging. Exhaustion incomplete,
no truncation or silent expansion. Final replay/validation plan separate.
Shared action/source/ring/edge/software/AI author limit independence.
