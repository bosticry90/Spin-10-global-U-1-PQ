# Full-source support final validation freeze

600s aggregate after imports for five fresh sequential workers: native and
replay support original240s each, right-root180s, negative simple cut60s,
graded continuation60s. Compare all11 complete artifact byte streams and
all5 nonruntime result records. Preserve the simple-cut completed negative
18408-violation result as NOT PROVEN; do not rewrite it as the V2 proof.
Verify source copies/bindings, raw index coverage, transfer/root tables,
all540 B-leg columns, all45 inverse interfaces, both nonzero root classes,
graded potential scope and its inherited CPS dependence.

Check16 preexisting named catalog counts against owning V792/V808/V826
receipts AFTER fresh construction. Authenticate their committed bytes;
they are calibration/control data, not fitted coefficients. No new proper
source zero, unprobed potential census, counterterm basis or E5/A5 claim.

8GiB sampled private/350MiB floor/64MiB packet/10MiB artifact. Full final
capture repo+D before judging. Failure/exhaustion incomplete, no truncation
or silent expansion. E4 once/no fresh/fixed D: context; expected component
exits0,0,0,0,0,2, exactly7 unresolved historical custody references NOTPASS.
Verify old Git mode/blob entries and project_state unchanged, then separate
raw-stage guard before local main commit with V827 handoff. No push, new
branch/worktree, external action/adoption/protected scientific promotion.
