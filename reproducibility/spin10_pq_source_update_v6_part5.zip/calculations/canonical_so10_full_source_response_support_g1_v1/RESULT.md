# Broader first-probe source support is now mapped and reduced

The full-source packet contains19 M-sector profiles across g0/g1, including
10 g1 profiles beyond the previous nonempty consistency parents and BBC.
Native append/replay prepend transfer methods reproduce every complete
coefficient table;16 earlier named target counts are final-review controls.
All765420 raw word indices and140 type classes remain recorded.

Actual sourceful vector-root and ordinary-leg proofs remove200 of536 M
candidate paths. Five profiles lose every path: Ja-aCC, a-a-CCC, B-Ja-C,
BBC and BB-Lambda-C. Only BBC already has its separate proper premise;
the new sourceful proper/master bridges remain open. Counts are unsigned
type possibilities, not nonzero amplitudes or normalization parameters.

Eight of10 actual right-vector root classes vanish; the other two remain
nonzero. All540 full-source g0 B-leg jet columns and all45 actual free
inverse interfaces are checked. Unprobed zero-tail paths are not discarded.
No arbitrary counterterm coefficient or missing quantum input was chosen.

The scalar scope check caught a false premise:18408 scalar-related words
defeat the original simple separation argument. That completed negative
audit remains NOT PROVEN. A new graded-root proof retains those words and
shows why they cannot generate first-u,g<=1 scalar returns, with zero
active-condition violations. Pure-scalar potential insertions do not change
that first-u support, using the qualified G/QG source chart. The unprobed
full physical potential census is explicitly NOT established. The full F1
reference diagonal is nonzero and was correctly retained.

Primary times after imports: support41.799/33.566s under240 each; full-source
Ward54.210s/180; negative simple cut47.345s/60; graded continuation1.113s/60.
Final receipt owns fresh5result/11artifact comparisons and E4once/no-fresh
fixedD:context.8GiB sampled/350MiB floor/64MiB packet/10MiB artifact, not
true/nested peaks. All old sources/receipts/state bytes remain unchanged.

Next: qualify new proper/source interfaces, compare surviving auxiliary
patterns with existing V782-V786 results, and identify genuinely missing
coefficients before new integrations. This is not a full tensor/cohomology
basis or HB1/C5 activation. Prior restricted normalization failures remain
excluded. Common restoration, E5/A5, physical viability and full goal remain
open; authority34/39 and seven custody references unchanged. Shared inputs/
software/AI author limit independence; director acceptance not performed.
