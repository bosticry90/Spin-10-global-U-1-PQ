from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-source-response-support-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','ward_preparation.json','scope_preparation.json','scope_v2_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 fresh=[];artifacts=[];caps=[]
 for script,role,resname,capname,limit in[('support.py','native','native_result.json','native_capture.json',240),('support.py','replay','replay_result.json','replay_capture.json',240),('ward.py',None,'ward_result.json','ward_capture.json',180),('scope.py',None,'scope_result.json','scope_capture.json',60),('scope_v2.py',None,'scope_result_v2.json','scope_capture_v2.json',60)]:
  res=read(O/resname);cap=read(O/capname);assert res['execution_state']=='COMPLETED'and res['elapsed_after_imports']<limit and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified'];assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);caps.append(cap)
  sp=importlib.util.spec_from_file_location('fresh_full_source_'+resname.replace('.','_'),O/script);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
  if role:m.ROLE=role
  def compare_save(name,z):
   name=role+'_'+name+'.json.gz'if role else name;blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),('FRESH_ARTIFACT_DIFFERS',name);artifacts.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
  def compare_dump(path,z):
   assert path==O/resname;assert{k:v for k,v in res.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'},resname;assert z['elapsed_after_imports']<limit;fresh.append(dict(result=resname,seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
  m.save=compare_save;m.dump=compare_dump;m.main();del m;gc.collect()
 assert len(fresh)==5 and len(artifacts)==len(set(artifacts))==11
 cl=load(O/'native_classification.json.gz');assert cl==load(O/'replay_classification.json.gz')and len(cl['classes'])==140;assert sum(z['raw_word_count']for z in cl['roots'])==276184 and sum(z['raw_word_count']for z in cl['ordinary'])==489236
 for row in cl['roots']+cl['ordinary']:assert not row['rejected']and sorted(row['kept_raw_indices'])==list(range(row['raw_word_count']))
 assert next(z for z in cl['roots']if z['owner']=='reference_F1')['complete_reference_diagonal']
 summaries={}
 for name in['original','0','1']:
  z=load(O/('native_support_'+name+'.json.gz'));assert z==load(O/('replay_support_'+name+'.json.gz'));assert len(z['all_complete_tail_coefficients'])==7 and not z['all_complete_tail_coefficients'][-1]['coefficients'];summaries[name]={(r['g'],tuple(r['counts'])):r['typed_oriented_paths']for r in z['profiles']}
 def profile(name,items):
  e=[0]*16
  for i,num in items.items():e[i]=num
  return summaries[name].get((1,tuple(e)),0)
 calibration=[];old=read(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/validation_receipt.json')
 for target,a,h,m in old['catalog_counts']:
  items={'aCC':{6:2,7:1},'JBCC':{6:2,8:1},'JLambdaCC':{6:2,13:1}}[target]
  for name,expected in zip(['original','0','1'],[a,h,m]):actual=profile(name,items);assert actual==expected;calibration.append(dict(target=target,family=name,actual=actual,expected=expected,owner='V808_qualified_catalog'))
 old=read(O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/validation_receipt.json')
 for row in old['catalog_summary']:
  items={0:1,5:1,6:1}if row['channel']=='vector'else{5:1,6:1,15:1};name=str(row['probe']);actual=profile(name,items);assert actual==row['cycles'];calibration.append(dict(target=row['channel'],family=name,actual=actual,expected=row['cycles'],owner='V792_qualified_catalog'))
 old=read(O.parent/'canonical_so10_BBC_full_source_catalog_g1_v1/validation_receipt.json')
 for name,expected in zip(['original','0','1'],old['catalog_counts_original_H_M']):actual=profile(name,{0:2,6:1});assert actual==expected;calibration.append(dict(target='BBC',family=name,actual=actual,expected=expected,owner='V826_qualified_catalog'))
 assert len(calibration)==16
 w=read(O/'ward_result.json');wt=load(O/w['artifact']['file']);assert w['R_F1_RB_classes_tested']==10 and w['zero_RB_classes']==8 and w['all540_full_source_B_jet_columns_equal_LEFT_and_componentwise'];assert[len(q['all180_columns'])for q in wt['full_source_g0_B_leg_checks']]==[180]*3 and all(q['all_B_legs_pure_divergence']for q in wt['full_source_g0_B_leg_checks']);assert[(r['family'],r['raw_paths'],r['removed_paths'],r['remaining_paths'])for r in w['profile_summary']]==[('original',48,0,48),('0',22,12,10),('1',536,200,336)];assert sorted(r['contractions']['right_l']['nonzero_positions']for r in wt['all_actual_R_F1_RB_class_tests'])==[0]*8+[1336]*2
 negative=read(O/'scope_result.json');positive=read(O/'scope_result_v2.json');assert negative['cut_violations']==18408 and not negative['first_u_pure_scalar_potential_robust_cut_applicable'];assert positive['active_condition_violations']==0 and positive['first_u_pure_scalar_potential_robust_cut_applicable']and positive['ordinary_g1u1_words_excluded_by_root_grades']==165608 and positive['mixed_gu_root_words_retained']==1184 and positive['unprobed_full_potential_census_NOT_CLAIMED'];print('STAGE fresh5results_11artifacts_16calibrations_negative_simple_cut_and_graded_scope_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();pp=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=pp.returncode,seconds=time.perf_counter()-et,stdout=pp.stdout,stderr=pp.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert pp.returncode==0
 events=[json.loads(x)for x in pp.stdout.splitlines()if x.strip()];exits=[e['exit_code']for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(e for e in events if e['event']=='step_finished'and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V827.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='FULL_SOURCE_RESPONSE_SUPPORT_AND_OPERATOR_SCOPE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_RAW_SOURCE_SUPPORT_AND_FIRST_U_OPERATOR_SCOPE',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,fresh_replays=fresh,complete_artifacts_freshly_recomputed=artifacts,all765420_raw_word_indices_and140_classes_verified=True,append_prepend_complete_transfer_tables_equal=True,all16_old_named_count_calibrations=calibration,raw_patterns_original_H_M=[7,1,19],raw_paths_original_H_M=[48,22,536],removed_first_u_paths_H_M=[12,200],remaining_paths_original_H_M=[48,10,336],R_F1_RB_zero_and_nonzero_classes=[8,2],all540_sourceful_B_jet_columns_and45_inverse_interfaces_verified=True,negative_simple_cut='COMPLETED_WITH18408_VIOLATIONS_NOTPROVEN_PRESERVED',graded_root_first_u_potential_scope='ZERO_ACTIVE_VIOLATIONS_WITH1184_MIXED_ROOT_WORDS_RETAINED',full_F1_reference_diagonal_NONZERO_RETAINED=True,unprobed_full_physical_potential_census_NOT_CLAIMED=True,new_sourceful_proper_master_bridges_NOT_QUALIFIED=True,no_counterterm_cohomology_basis_no_HB1_C5_activation=True,prior_restricted_correction_failures_and_BBC_proper_zero_preserved=True,common_restoration_E5_A5_viability_not_claimed=True,shared_action_software_AI_author_not_external_independence=True,largest_primary_sampled_private_bytes=max(x['private_bytes']for cap in caps for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_goal_completion_claim=False)
 partitions=load(O/'scalar_partition_scope_tables.json.gz')['complete_native_replay_equal_scan'];g0_crossings=sum(len(z['raw_indices'])for row in partitions['all20_full_raw_owners']if row['g']==0 for z in row['all_raw_partition_indices']if z['quantum_partition'][0]!=z['quantum_partition'][1]);assert g0_crossings==0
 out.update(support_completeness='QUALIFIED_RAW_PACKET; FIRST_U_PURE_SCALAR_POTENTIAL_EXTENSION_BY_GRADED_CUT; UNPROBED_FULL_POTENTIAL_NOT_ESTABLISHED',actual_g0_quantum_partition_crossing_words=g0_crossings,legacy_scope_flag_false_aggregates_unrelated_violations_NOT_actual_g0_crossing=True,static_AI_scope_review='NO_BLOCKING_FINDING; TWO_REPORTING_QUALIFIERS_ADDED; NOT_EXTERNAL_SCIENTIFIC_REVIEW')
 out['final_review_seconds']=time.perf_counter()-tick
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
