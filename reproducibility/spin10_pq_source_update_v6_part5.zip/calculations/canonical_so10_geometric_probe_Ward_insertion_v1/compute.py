from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-probe-Ward-insertion-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V857_FROZEN_GEOMETRIC_WORD_CODEC',B/'canonical_so10_geometric_ward_current_source_chart_v1/algebra.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def dim(n):return 3-dim(n-643)if 643<=n<1286 else 2 if 508<=n<553 else 1 if n<643 else 0
def old(rows):
    out={}
    for w,cs in rows:
        ww=tuple((n,tuple(j))for n,j in w)
        for(g,x,e,m),num,den in cs:a.put(out,(g,ww),(((x,e,m),F(num,den)),))
    return out
def chosen(q,D):return {k:v for k,v in q.items()if k[0]<=1 and 0<=D-sum(dim(n)+len(j)for n,j in k[1])<=1}
def grade(q,g):return{k:v for k,v in q.items()if k[0]==g}
def action(A,U,rules,role):
    return a.plus(*(a.act(A,grade(U,h),{n:grade(q,g)for n,q in rules.items()},role)for h in[0,1]for g in range(2-h)))
def pair(A,rules,E):
    return a.plus(*(A.product(grade(q,g),grade(E.get(n,{}),h))for n,q in rules.items()if q and E.get(n)for h in[0,1]for g in range(2-h)))
def currents(A,U,rules):
    cur=[{}for mu in range(4)]
    for(g,w),v in U.items():
        pref=0
        for at,(n,j)in enumerate(w):
            if j and rules.get(n):
                q={(g,w[:at]+w[at+1:]):a.scale_coefficient(v,(-1)**(A.parities[n]*pref))};jj=list(j)
                while jj:
                    mu=jj.pop();pp=a.jets(A,rules[n],jj);term=A.product(pp,q);term={k:v for k,v in term.items()if k[0]<=1};cur[mu]=a.plus(cur[mu],term);q=a.scale(a.derivative(A,q,mu),-1)
            pref+=A.parities[n]
    return cur
def divergence(A,cc):return a.plus(*(a.derivative(A,p,mu)for mu,p in enumerate(cc)))
def omega_normal(A,P):
    N={};cur=[{}for mu in range(4)]
    for(g,w),v in P.items():
        ports=[at for at,(n,j)in enumerate(w)if n>=1286];assert len(ports)==1;at=ports[0];n,j=w[at];rest={(g,w[:at]+w[at+1:]):v};jj=list(j)
        while jj:
            mu=jj.pop();cur[mu]=a.plus(cur[mu],A.product(a.atom(n,tuple(jj)),rest));rest=a.scale(a.derivative(A,rest,mu),-1)
        N=a.plus(N,A.product(a.atom(n),rest))
    assert a.plus(P,a.scale(N,-1))==divergence(A,cur)
    return N,cur
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    cases=[];peers=[]
    for role,owner in[('native','primary'),('replay','replay')]:
        chart=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(chart['all_current_names'],chart['all_current_parities']);T={n:a.decode(q)for n,q in chart['all1286_direct_Tq_columns']};Tp={n:a.decode(q)for n,q in chart['all1286_direct_Tqprime_columns']};cs={n:a.decode(q)for n,q in chart['all1286_source_difference_columns']};u0=a.load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));u1=a.load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));ops=a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={name:dict(rr)for name,rr in ops['states'].items()};rolecases=[]
        for pr in[0,1]:
            U=a.plus(chosen(old(u0['probes'][pr]['U']),4),chosen(old(u1['U1'][pr]),4));E=a.eulers(A,U,set(range(1286)));Eu={i:a.plus(*(chosen(old(states['Eu'+str(g)+'_'+str(pr)][i]),4-dim(i))for g in[0,1]))for i in range(643)};Fu={i:a.plus(*(chosen(old(states['Fu'+str(g)+'_'+str(pr)][i]),1+dim(i))for g in[0,1]))for i in range(643)}
            assert all(E.get(i,{})==Eu[i]and E.get(643+i,{})==a.scale(Fu[i],(-1)**A.parities[i])for i in range(643)),'ALL643_PROBE_FU_EU_INTERFACE_FAILED'
            tq=action(A,U,T,owner);cu=action(A,U,cs,owner);tp=action(A,U,Tp,owner);assert a.plus(tq,cu)==tp
            pt=pair(A,T,E);pc=pair(A,cs,E);cp=pair(A,Tp,E);ct=currents(A,U,T);cc=currents(A,U,cs);ctprime=currents(A,U,Tp)
            for direct,paired,cur in[(tq,pt,ct),(cu,pc,cc),(tp,cp,ctprime)]:assert a.plus(direct,a.scale(paired,-1))==divergence(A,cur),'COMPLETE_DIRECT_EULER_CURRENT_INTERFACE_FAILED'
            explicitC=a.plus(*(A.product(grade(cs[643+i],g),a.scale(grade(Fu[i],h),(-1)**A.parities[i]))for i in range(643)if cs[643+i]and Fu[i]for h in[0,1]for g in range(2-h)));assert explicitC==pc
            wrongC=a.plus(*(A.product(grade(cs[643+i],g),grade(Fu[i],h))for i in range(643)if cs[643+i]and Fu[i]for h in[0,1]for g in range(2-h)));wrongCdiff=a.plus(wrongC,a.scale(pc,-1));normal,ncurr=omega_normal(A,tp);constant={k:v for k,v in tp.items()if all(not j for n,j in k[1]if n>=1286)};cn,unused=omega_normal(A,constant);localdiff=a.plus(normal,a.scale(cn,-1));sourceports=sorted(i for i in range(643)if cs[643+i]and Fu[i]);assert all(not Fu[i]for i in range(508))
            record=dict(probe=['H','M'][pr],complete_selected_U=a.encode(U),all1286_selected_U_Eulers=[[i,a.encode(E.get(i,{}))]for i in range(1286)],complete_Tq_U=a.encode(tq),complete_C_U_literal=a.encode(cu),complete_Tqprime_U=a.encode(tp),complete_Tq_U_Euler_pair=a.encode(pt),complete_C_U_Euler_pair=a.encode(pc),complete_Tqprime_U_Euler_pair=a.encode(cp),all_Tq_IBP_currents=[a.encode(q)for q in ct],all_C_IBP_currents=[a.encode(q)for q in cc],all_Tqprime_IBP_currents=[a.encode(q)for q in ctprime],complete_omega_Euler_normal=a.encode(normal),all_omega_normal_currents=[a.encode(q)for q in ncurr],all_CU_participating_field_source_ports=sourceports,controls=dict(complete_wrong_source_parity_difference=a.encode(wrongCdiff),wrong_source_parity_sensitive=bool(wrongCdiff),complete_local_minus_constant_omega_normal=a.encode(localdiff),constant_omega_restriction_loses_functional_terms=bool(localdiff)),functional_disposition='NONZERO_EVEN_GEOMETRIC_PROBE_INSERTION_REQUIRED'if normal else'ZERO_MOD_EXPLICIT_OMEGA_CURRENTS',counts=dict(U_words=len(U),TqU_words=len(tq),CU_words=len(cu),TqprimeU_words=len(tp),omega_normal_words=len(normal)))
            artifact=save(role+'_complete_'+['H','M'][pr]+'_even_geometric_insertion.json.gz',record);rolecases.append(dict(probe=record['probe'],artifact=artifact,counts=record['counts'],functional_disposition=record['functional_disposition'],source_product_participating_ports=sourceports,controls={k:v for k,v in record['controls'].items()if not k.startswith('complete_')}));peers.append(record);print('STAGE '+role+' '+record['probe']+' '+record['functional_disposition'],flush=True)
        cases.append(dict(role=role,cases=rolecases))
    assert peers[:2]==peers[2:],'ACTUAL_NATIVE_REPLAY_GEOMETRIC_PROBE_INSERTION_DIFFERENCE'
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ACTUAL_COMPLETE_EVEN_GEOMETRIC_PROBE_INSERTIONS_CLASSIFIED',roles=cases,higher_g_probe_orders_full_background_and_quantum_contact_W5_E5_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
