# Actual even geometric probe identity and the whole quantum product

Use the fully checked V855/V856 current T,Tprime and source difference C,
not the auxiliary odd D operation. Tprime=T+C and C acts only on sources.
All operations below retain arbitrary LOCAL even omega and its jets and
every field/source slot. A/alljets0 is T-stable, not Tb-stable.

For each actual H/M density U=U0+U1 in g<=1/intrinsic01, reconstruct all
field and source Euler columns from the complete density, including zeros.
The old actual operator packets independently supply Eu_i and Fu_i, where

    Eu_i=EL_zi U, Fu_i=(-1)^p_i EL_Ji U.
    C(U)=sum_i c_Ji EL_Ji U=sum_i (-1)^p_i c_Ji Fu_i.

All products keep c first and LEFT Grassmann derivatives. The physical
508 Fu ports vanish as actual qualified polynomial coefficients, not by
setting physical potential/Euler expressions to zero. Consequently c_JB
does not contribute here. Any further zero is measured, not presumed.

Compute literal jet-prolonged T(U),C(U),Tprime(U) through g1, keeping both
T0U1 and T1U0. Independently pair the complete Euler columns with the
rules. For a varied jet D_j z with left-jet coefficient q, repeatedly use

    (D_mu R)q = partial_mu(Rq)-R partial_mu q.

This constructs every IBP current explicitly with full derivative placement.
No field/source is dropped before variation. Check literal variation minus
Euler pairing equals the divergence of those currents, in both routes.
Also check literal T(U)+C(U)=Tprime(U). This last equality follows from
the already qualified operation interface; it does not alone prove a zero.

To classify the complete functional, each term contains exactly ONE omega
or its jet. Move those jets by IBP onto all remaining factors, retaining
four complete currents:

    P=sum_h omega_h EL_omega_h P + partial_mu j_mu.

For arbitrary local test omega this normal is a complete functional-zero
test. Its zero is not a selected channel or a constant-parameter test. The
separate expanded-Fraction verifier reconstructs every omega Euler column
and the full current divergence without the producer's normal routine.

The original worker timed out before replayM. Its artifacts/capture stay
unqualified. The V2 worker recomputes all operands in both routes; it only
replaces repeated growing-dictionary copies by the same exact put additions.
The first V2 launcher stopped before calculation on an exclusive-path
collision; the new launcher uses a distinct destination. No resource limit
or scientific comparison is weakened. Only completed V2 and final captures
can qualify the result. Partial native agreement is not accepted evidence.

The frozen control named 'constant_omega...' actually erases omega-jet terms
and then treats omega as LOCAL again. This is only a malformed local-rule
diagnostic; it is not a global-symmetry test. Final review discloses that
limit and tests true constant omega separately by removing each undifferentiated
omega label and checking field/source Euler homotopy coefficientwise.
Blind controls remain blind. Grouped words and expanded coefficients are
reported separately and never compared as the same unit.

If Tprime(U)=0 is qualified, the DIRECT prospective Ward identity for
Sigma_u=S+uU has no additional classical u*Tprime(U) breaking, provided
the full base Noether/current identity and common quantum map apply:

    T Gamma_u+[C(Sigma_u)]_Gamma=M_q.

This is not Tprime Gamma_u=0 or homogeneous D Gamma=0. In particular the
first-u whole insertion generally includes BOTH C(U) and the ordinary-U
covariance response of C(S). A zero Tprime U does not zero either piece
or all connected products. No quantum [G], canonical equivalence or A5 is
assumed by this direct affine Ward route. Geometric C differs from KD.

The source dependence of U does not invalidate field affinity of T; its
whole Hessian/product and source derivatives must still be included. Fixed
tensor/first-D-jet applicability, the actual regulator/heat profiles,
source/contact normalization, background, QAP, measure and protected
acceptance obligations remain. Classical exact agreement does not validate
a shared physical action or establish measured physics. Both routes share
arithmetic, software/conventions and AI authorship; independence is bounded.
