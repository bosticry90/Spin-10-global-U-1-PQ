# V857 prospective actual even geometric probe insertion

Continue V856/1993dca044e60da00d8bb1ee687f32ac1d55e7a3 on main,D:,ACTIVE.
Root owns writes/runs/Git; AI reviews read only. Current AGENTS/charter/solo
apply. No foundation/prescription adoption,state change,protected promotion,
branch/worktree,push/publication. Authority34/39,E5/A5 open,seven NOTPASS,
flavor pause and HB1/C5 blocks unchanged.

Question: what is the actual complete even geometric breaking Tprime U
for the already fixed H/M probes? Does it vanish as a local functional,
or must the direct broken Ward identity retain a nonzero whole insertion?
This decides which insertion to normalize, before further loop computation.

Domain: current643 fields/sources,A/alljets0,g0/g1,intrinsic0/1,first UNIT
tree probe u, all local EVEN omega jets. No new quantum G or A5 inference,
no replacement by odd D. V855/V856 full current geometric T,Tprime,c chart
and complete existing U0/U1/Fu/Eu inputs are immutable. No unknown physical
Euler/potential coefficient is set zero; U gradients are already explicit.

Two routes consume native/replay actions/gradients and primary/replay Ward
charts. Compare literal even slot/LEFT jet prolongations with full gradient
pairing, constructing ALL IBP currents. C(U)=sum c_J EL_JU=sum s_i c_JFu_i,
c first,s_i=(-1)^p_i. Check ALL643 Fu/Eu against actual density Eulers,
including zero complement. Keep g0=T0U0 and g1=T0U1+T1U0 exactly; higherg
is outside the frozen target, not post-hoc discarded evidence.

Calculate full TqU,C(U),TprimeU. Literal Tq+C=Tprime is an interface check;
it is NOT itself a restoration result. Classify complete functional using
the exact omega Euler normal and reconstruct its four currents. Since every
word has exactly one omega/jet, it is zero as a local functional iff all
omega Euler columns vanish. A nonzero normal is an allowed scientific
outcome, not a failed gate. Do not count algebraic words as independent
constraints or choose a coefficient to cancel this target.

Controls: compare erroneous omission of source parity in C(U), and dropping
local omega jets (constant-parameter restriction). Record insensitive cases
as blind, never force nonzero. No conclusion about a quantum trace solely
from a nonzero tree/kernel coefficient.

One180s/8GiB sampled worker,32MiB packet,8MiB/artifact; complete captures,
source/input hashes first; failures/overflow/incomplete unchanged. Separate
180s/8GiB final verifier with independent expanded Fraction Eulers and
omega normal/current reconstruction, frozen inputs/source/encoding hashes,
unchanged Git/state, historical navigation and fixed E4 once. Require
0,0,0,0,0,2/seven unresolved. Validate before local commit. Next only after
this result: base current/physical Noether applicability and fixed geometric
insertion lift/common finite map. Full W5/QAP/measure/profile/A5 remain open.
