from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-probe-Ward-insertion-v1-2026-11-08/continuation-v2')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='1993dca044e60da00d8bb1ee687f32ac1d55e7a3'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names=set(json.loads((B/'canonical_so10_geometric_ward_current_source_chart_v1/preparation_validation_v2.json').read_bytes())['sha256'])|{'docs/RESEARCH_EXECUTION_HANDOFF_V856.md','calculations/canonical_so10_geometric_ward_current_source_chart_v1/validation_receipt_v2.json','calculations/canonical_so10_geometric_ward_current_source_chart_v1/capture_validation_v2.json','calculations/canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py'}
for folder,files in{
'canonical_so10_new_physical_returning_inventory_g1_recovery_v1':['native_GF_common.json.gz','replay_GF_common.json.gz','validation_receipt.json'],
'canonical_so10_full_current_inventory_g1_recovery_v1':['native_route_densities.json.gz','replay_route_densities.json.gz','validation_receipt.json'],
'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json']}.items():
    for n in files:names.add('calculations/'+folder+'/'+n)
enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
C.mkdir(exist_ok=False)
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings_v2.json',dict(bindings=enc));dump(C/'input_encoding_bindings_v2.json',dict(bindings=enc))
for n in['CONTINUATION_V2.md','LAUNCH_CORRECTION_V3.md','compute_v2.py','execute_v3.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_v2.json',prep);dump(C/'preparation_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_v2.py')]);dump(O/'capture_v2.json',cap);dump(C/'capture_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
