# Same-bound full restart with linear accumulation

The original worker exited124 at180s after nativeH/M and replayH artifacts;
it did NOT complete replayM/result and earns no qualification. All original
sources, partial artifacts, preparation and capture stay immutable. Do not
accept partial caches or infer a completed scientific result.

Code review identifies repeated copying of the growing IBP-current dictionary
for every monomial. New compute_v2.py replaces that quadratic engineering
accumulation with exact in-place coefficient addition via the SAME put routine.
It changes no algebra, signs, inputs, terms, target, tests or resource bound.
All inputs are recomputed in BOTH routes into distinct V2 artifact names.
One180s/8GiB sampled attempt, same32MiB packet/8MiB artifact, no expansion.
Any further failure/incomplete work remains so and triggers reassessment.

Final independent review also distinguishes the frozen control's legacy
'constant_omega...' label from its actual operation: erasing parameter-jet
terms and reapplying a LOCAL omega normal. This is a malformed local-operator
diagnostic, not a genuine global-parameter test. It earns no global-symmetry
claim. Final validation will test true constant omega by coefficientwise
field/source Euler homotopy after removing each constant omega label.
This corrects interpretation rather than assigning the diagnostic a desired
value. The complete local omega target and all source/field comparisons stay.
