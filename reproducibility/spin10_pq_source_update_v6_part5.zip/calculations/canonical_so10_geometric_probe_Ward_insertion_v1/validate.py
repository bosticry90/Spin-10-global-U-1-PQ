from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-probe-Ward-insertion-v1-2026-11-08/continuation-v2')
sys.path.insert(0,str(B/'canonical_so10_geometric_ward_current_source_chart_v1'))
import algebra as a
sp=importlib.util.spec_from_file_location('V857_INDEPENDENT_EXPANDED_FRACTION_EULER_CODEC',B/'canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
sp=importlib.util.spec_from_file_location('V857_FROZEN_INPUT_SELECTION_ONLY',O/'compute_v2.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def fromflat(q):
    out={}
    for(w,(g,x,e,m)),val in q.items():a.put(out,(g,w),(((x,e,m),val),))
    return out
def gh(n):return -1-gh(n-643)if 643<=n<1286 else 1 if 553<=n<598 else -1 if 598<=n<643 else 0
def normal(q,par):
    out={}
    for(w,k),val in q.items():
        ports=[(at,n,j)for at,(n,j)in enumerate(w)if n>=1286];assert len(ports)==1;at,n,j=ports[0];rest={(w[:at]+w[at+1:],k):val*(-1)**len(j)}
        for mu in j:rest=v.de(rest,mu,par)
        for(ww,kk),cv in rest.items():
            word,sign=v.canon(ww+((n,()),),par)
            if sign:v.add(out,(word,kk),sign*cv)
    return out
def div(cc,par):
    out={}
    for mu,q in enumerate(cc):
        for k,val in v.de(v.flat(q),mu,par).items():v.add(out,k,val)
    return out
def actual(A,U,rules,role):
    out={}
    for h in[0,1]:
        for g in range(2-h):
            q=a.act(A,{k:cv for k,cv in U.items()if k[0]==h},{n:{k:cv for k,cv in p.items()if k[0]==g}for n,p in rules.items()},role)
            for k,cv in q.items():a.put(out,k,cv)
    return out
def constant_test(A,P):
    cases=[]
    for h in range(1286,1298):
        q={}
        for(g,w),co in P.items():
            if any(n>=1286 and j for n,j in w):continue
            if any(n==h for n,j in w):a.put(q,(g,tuple((n,j)for n,j in w if n!=h)),co)
        E=v.allE(v.flat(a.encode(q)),A.parities);assert not E,'TRUE_CONSTANT_OMEGA_FIELD_SOURCE_EULERS_NONZERO'
        # Euler homotopy supplies actual currents, with omega removed first.
        cur=[{}for mu in range(4)];N={}
        for(g,w),co in q.items():
            assert w,'CONSTANT_FIELD_INDEPENDENT_MISMATCH';pref=0
            for at,(n,j)in enumerate(w):
                rest={(g,w[:at]+w[at+1:]):a.scale_coefficient(co,F((-1)**(A.parities[n]*pref),len(w)))};jj=list(j)
                while jj:
                    mu=jj.pop();term=A.product(a.atom(n,tuple(jj)),rest)
                    for k,cv in term.items():a.put(cur[mu],k,cv)
                    rest=a.scale(a.derivative(A,rest,mu),-1)
                for k,cv in A.product(a.atom(n),rest).items():a.put(N,k,cv)
                pref+=A.parities[n]
        assert not N and v.flat(a.encode(q))==div([a.encode(p)for p in cur],A.parities)
        cases.append(dict(omega=h,coefficient_words=len(q),all1286_Eulers_zero=True,currents=[a.encode(p)for p in cur]))
    return cases
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='1993dca044e60da00d8bb1ee687f32ac1d55e7a3'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation_v2.json');assert prep==a.read(C/'preparation_v2.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings_v2.json');assert enc==a.read(C/'input_encoding_bindings_v2.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    cap=a.read(O/'capture_v2.json');assert cap==a.read(C/'capture_v2.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);oldcap=a.read(O/'capture.json');assert oldcap['exit_code']==124 and not oldcap['calculation_completed'];assert not a.read(O/'launch_failure_v2.json')['calculation_launched'];result=a.read(O/'result_v2.json');assert result['elapsed_after_imports']<180;peers=[];summaries=[];constants=[]
    for rr,owner in zip(result['roles'],['primary','replay']):
        role=rr['role'];chart=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(chart['all_current_names'],chart['all_current_parities']);T={n:a.decode(q)for n,q in chart['all1286_direct_Tq_columns']};Tp={n:a.decode(q)for n,q in chart['all1286_direct_Tqprime_columns']};cs={n:a.decode(q)for n,q in chart['all1286_source_difference_columns']}
        for rules in[T,Tp,cs]:
            for n,p in rules.items():
                for(g,w),co in p.items():assert c.dim(n)==sum(c.dim(i)+len(j)for i,j in w)and gh(n)==sum(gh(i)for i,j in w)and A.parities[n]==sum(A.parities[i]for i,j in w)%2
        u0=a.load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));u1=a.load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));states={name:dict(rows)for name,rows in a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'))['states'].items()}
        for pr,row in enumerate(rr['cases']):
            art=row['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);peers.append(z);U=a.plus(c.chosen(c.old(u0['probes'][pr]['U']),4),c.chosen(c.old(u1['U1'][pr]),4));assert U==a.decode(z['complete_selected_U']);Ef=v.allE(v.flat(a.encode(U)),A.parities);E={n:fromflat(Ef.get(n,{}))for n in range(1286)};assert {n:a.decode(q)for n,q in z['all1286_selected_U_Eulers']}==E
            for i in range(643):
                EU=a.plus(*(c.chosen(c.old(states['Eu'+str(g)+'_'+str(pr)][i]),4-c.dim(i))for g in[0,1]));FU=a.plus(*(c.chosen(c.old(states['Fu'+str(g)+'_'+str(pr)][i]),1+c.dim(i))for g in[0,1]));assert E[i]==EU and E[643+i]==a.scale(FU,(-1)**A.parities[i])
                if i<508:assert not FU
            controls=z['controls'];data={n:a.decode(z[n])for n in['complete_Tq_U','complete_C_U_literal','complete_Tqprime_U','complete_Tq_U_Euler_pair','complete_C_U_Euler_pair','complete_Tqprime_U_Euler_pair']}
            for rules,n,paired,curr in[(T,'complete_Tq_U','complete_Tq_U_Euler_pair','all_Tq_IBP_currents'),(cs,'complete_C_U_literal','complete_C_U_Euler_pair','all_C_IBP_currents'),(Tp,'complete_Tqprime_U','complete_Tqprime_U_Euler_pair','all_Tqprime_IBP_currents')]:
                direct=actual(A,U,rules,'replay'if owner=='primary'else'primary');assert direct==data[n]
                pair=a.plus(*(A.product({k:cv for k,cv in p.items()if k[0]==g},{k:cv for k,cv in E[i].items()if k[0]==h})for i,p in rules.items()if p and E[i]for h in[0,1]for g in range(2-h)));assert pair==data[paired]
                assert v.flat(a.encode(a.plus(direct,a.scale(pair,-1))))==div(z[curr],A.parities)
            tp=data['complete_Tqprime_U'];assert a.plus(data['complete_Tq_U'],data['complete_C_U_literal'])==tp
            assert z['counts']==dict(U_words=len(U),TqU_words=len(data['complete_Tq_U']),CU_words=len(data['complete_C_U_literal']),TqprimeU_words=len(tp),omega_normal_words=len(a.decode(z['complete_omega_Euler_normal'])))
            assert z['all_CU_participating_field_source_ports']==[i for i in range(643)if cs[643+i]and E[643+i]]
            for p in[U,*data.values()]:
                for(g,w),co in p.items():assert g<=1 and 0<=4-sum(c.dim(n)+len(j)for n,j in w)<=1 and sum(gh(n)for n,j in w)==0 and sum(A.parities[n]for n,j in w)%2==0
            norm=normal(v.flat(a.encode(tp)),A.parities);assert norm==v.flat(z['complete_omega_Euler_normal'])and v.delta(v.flat(a.encode(tp)),norm)==div(z['all_omega_normal_currents'],A.parities)
            wrong=a.plus(*(A.product({k:cv for k,cv in cs[643+i].items()if k[0]==g},a.scale({k:cv for k,cv in E[643+i].items()if k[0]==h},(-1)**A.parities[i]))for i in range(643)if cs[643+i]and E[643+i]for h in[0,1]for g in range(2-h)));wd=a.plus(wrong,a.scale(data['complete_C_U_Euler_pair'],-1));assert wd==a.decode(controls['complete_wrong_source_parity_difference'])and bool(wd)==controls['wrong_source_parity_sensitive']
            erased={k:cv for k,cv in tp.items()if all(not j for n,j in k[1]if n>=1286)};legacy=v.delta(norm,normal(v.flat(a.encode(erased)),A.parities));assert legacy==v.flat(controls['complete_local_minus_constant_omega_normal']);constants.append(dict(role=role,probe=z['probe'],all12_true_constant_omega_cases=constant_test(A,tp)))
            disposition='NONZERO_EVEN_GEOMETRIC_PROBE_INSERTION_REQUIRED'if norm else'ZERO_MOD_EXPLICIT_OMEGA_CURRENTS';assert disposition==z['functional_disposition']==row['functional_disposition'];summaries.append(dict(role=role,probe=z['probe'],counts=z['counts'],functional_disposition=disposition,literal_density_zero=not tp,all1286_source_field_Eulers_checked=True,whole_source_and_U_covariance_NOT_zeroed=True,legacy_jet_erasure_control_NOT_global_symmetry_test=True));print('STAGE '+role+' '+z['probe']+' complete_independent_Eulers_currents_geometric_insertion_verified',flush=True)
    assert peers[:2]==peers[2:];dump(O/'true_constant_parameter_checks.json',constants)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V857.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V857.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V857.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2;files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V857.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_COMPLETE_EVEN_GEOMETRIC_PROBE_INSERTIONS_AND_CURRENTS',base_HEAD=head,state_sha256=state,cases=summaries,old_timeout_and_prelaunch_failures_preserved=True,erased_local_omega_jets_control_has_NO_global_symmetry_claim=True,true_constant_parameter_check_file='true_constant_parameter_checks.json',whole_C_Sigma_U_covariance_contacts_NOT_zeroed=True,actual_profiles_fixed_lift_and_full_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_input_action_codec_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
