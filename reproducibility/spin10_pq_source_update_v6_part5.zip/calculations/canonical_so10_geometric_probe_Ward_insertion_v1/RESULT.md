# V857: both actual probe actions preserve the transported geometric identity

The completed V2 worker took83.84s under the original180s limit. Final
qualification requires validation_receipt.json and capture_validation.json.
Native/replay agree on the full selected H/M probe domain, g0/g1 and
intrinsic0/1, retaining all fields/sources and local even omega jets.

Both probes have Tqprime U=0 as complete densities, a stronger result than
the tested zero modulo explicit omega currents. All1286 U Euler columns
match the qualified source/field gradients, with their zero complement.

For H, U has252 grouped words. TqU and C(U) each have2016 words and cancel
exactly. The12 light antighost-source ports participate; omitting their
source parity changes the result. For M, U has44629 words; both TqU and
C(U) are separately zero as complete densities. Its nonzero Euler-pairing
IBP currents remain recorded. Algebraic sizes are not physical predictions.

The [proof](PROOF.md) specifies the surviving quantum obligation: the
whole insertion C(S+uU) includes the direct C(U) AND the ordinary-U
covariance response of C(S). Neither can be discarded because TqprimeU=0.
This removes a potential additional classical probe-breaking dependency
from the DIRECT geometric Ward route without invoking quantum G/A5.

The original worker timed out before finishing replayM; its partial outputs
and FAILED capture remain unchanged. A continuation replaces repeated
dictionary copies with identical exact additions and fully restarts both
routes. One launcher failed before calculation on an exclusive-path collision;
that failure is also preserved. No resource/acceptance limit was expanded.

The frozen jet-erasure control is not a true constant-parameter test. Its
legacy label earns no global-symmetry claim; final validation records the
genuine constant-omega coefficient checks separately. Blind controls remain
blind, and grouped versus expanded coefficient counts remain distinct.

Next establish the complete base current/physical Noether interface and
fixed geometric insertion lift/common finite-functional applicability.
Actual profiles, normalized contacts, background/QAP/measure and A5 remain
unresolved. Authority34/39,E5/A5 open,seven custody NOTPASS; no scheme or
physical adoption,state change,push/publication. C: backupv11 reachesV854;
these later commits are not automatically covered.
