# V857 separate final verification

One180s/8GiB sampled,32MiB packet,8MiB/artifact. Check completed V2 primary
and final captures; original180s timeout and prelaunch failure retained.
Authenticate every original/current dependency, raw/Git encoding/source
freezes and exact artifacts. Verify full selected U from immutable inputs,
all1286 Eulers with expanded Fraction/radical arithmetic, literal variation
by opposite slot/LEFT route, source-gradient parity pairing and complete
IBP/omega currents. Verify all output/rule dimensions, ghost degree/parity
and local omega support; no intrinsic re-projection hides a bad image.
True constant omega is a separate coefficientwise test, not the legacy
erased-local-jets diagnostic. Preserve blind controls/limits explicitly.
Unchanged old Git tree/state,historical README suffix/current navigation,
fixed E4 once(0,0,0,0,0,2;seven unresolved NOTPASS). Receipt/capture before
local commit; no scientific promotion/physical or prescription adoption.
