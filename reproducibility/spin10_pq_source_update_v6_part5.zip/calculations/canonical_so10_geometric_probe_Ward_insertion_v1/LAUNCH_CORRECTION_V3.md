# Launcher-only exclusive-path correction

execute_v2.py stopped before source freeze or calculation because its copied
launcher tried to create the original external control directory exclusively.
That source and tool failure remain preserved; no V2 computation launched.
execute_v3.py uses a NEW exclusive continuation-v2 control subdirectory and
input_encoding_bindings_v2 filenames. compute_v2.py and its exact arithmetic,
full reexecution requirement,180s/8GiB/32MiB/8MiB limits are unchanged.
