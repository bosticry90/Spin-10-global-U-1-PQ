# V906 pre-execution contract

Bind V905, the free FCR1 gauge frame and the original Feynman
simple and dipole branch. Require the exact switched shear,
flat damping residual and a compact-wave reduction preserving
the width and original constraint. For the massless compact
first-order system test the half-wave Fredholm criterion on
dot H1 plus L2 and the compact-block argument. Require
constraint recovery under the strict V905 scalar bound and
a fixed-support small-amplitude absorption control. Keep the
unit amplitude kernel and loop sums open.

Native 120 s, final 180 s including E4 cap 120 s, sampled
private 8 GiB, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. Exact replay and staged validation required.
