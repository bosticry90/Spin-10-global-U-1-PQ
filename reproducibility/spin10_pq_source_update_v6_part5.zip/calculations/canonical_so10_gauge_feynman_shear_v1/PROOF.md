# The compact switched gauge Feynman boundary problem

Use the V905 actual Minkowski quadratic gauge/auxiliary equations, a
real smooth compact switch, and bounded real width w including zero.
Write D0=Box, d^nu=partial^nu, a=exp(sigma), s=d sigma, and
W=a(s² I−s_up s_down)/4. A Feynman branch in this packet means negative
frequency data before the switch and positive frequency data after it
in the sheared wave variables defined below. Positive absorption at
finite eta is specified separately. The scalar constraint argument
uses the strict V905 broad-profile Hardy bound.

## An exact shear retaining the flat dipole

With N=a^-1 M_a+d(div+s·)+a^-1 W, the V905 residual system has
left matrix

    P_sigma = [[N−d(s·), −(w−1)a^-1 d+w a^-1 s],
               [div(W·), D0]]

and right side (a^-1 J−d j, div J). Set alpha=(w−1)/2,
T^nu=alpha a^-1 x^nu and S=[[I,T],[0,1]], so b=c+T lambda.
Multiplication by S has a local differential inverse. Since the
principal part is D0 I, the conjugate S^-1 P_sigma S also has principal
part D0 I. On any constant-profile region W=s=0. There
[D0,T]=2 alpha a^-1 d, which cancels the full constant off-diagonal
derivative. Thus the conjugate is D0 I+Q_sigma with Q_sigma a
smooth compact spacetime first-order matrix. Its coefficients vanish
even on the unit plateau. Width has never been divided out.
The source is transformed to S^-1(a^-1 J−d j,div J), still compact.

At sigma=0 use R_eta=(Box−i eta)^-1=−(P+i eta)^-1. The two scalar
solves are lambda=R_eta div J and
c=R_eta(J−d j−alpha x div J). Reconstruction uses

    b=R_eta(J−d j)+alpha [x,R_eta] div J,
    [x^nu,R_eta]=2 d^nu R_eta².

This gives the exact FCR1 free BB dipole with Fourier numerator
(1−w)p^nu(p·J), the simple part, and both mixed signs. The derivative
of the simple multiplier supplies the numerator-dressed double pole.
No standalone unextended (P+i0)^-2 at the four-momentum origin is
needed. A naked square can have the critical logarithm of V899.
The original flat constraint at positive absorption is

    C_eta=div b+j−w lambda
         =i eta[(w−1)R_eta² div J−R_eta j].

It tends to zero as a distribution since R_eta and d R_eta² have
the stated limits. The vector residual is i eta b−d C_eta. Thus the
undamped constraint is recovered at the boundary. The scalar damping
in the sheared system is not an arbitrary matrix damping in the
original Hessian.

## Finite-dimensional obstruction for compact switches

Use the massless Cauchy energy space dot H^1(R³;C^5) plus
L²(R³;C^5). For a solution u=(c,lambda) set D=|D_space| and
f_+=(D u+i u_t)/sqrt(2), f_-=(D u−i u_t)/sqrt(2).
The free generators are −iD and +iD. A compactly supported
source for the sheared wave equation gives a compact time forcing
in this space. The first-order terms give a bounded matrix B(t)
on the doubled L², with norm-smooth compact time dependence.
Indeed its entries are combinations of compact coefficient
multipliers, multipliers followed by Riesz transforms, and
coefficients times D^-1. The last is bounded by dot H^1 to L^6
Sobolev and the L³ norm of the coefficient. This does not require
an infrared mass gap. The full and diagonal-block-only propagators
U and U_d are bounded invertible on the finite time slab, by the
bounded perturbation integral equation.

Here is a direct compactness proof for the difference of the
evolutions. Let Pi be the Fourier projector D>=1. In either
off-diagonal block, B−Pi B Pi is compact. Low momentum on the
left or right makes the localized multiplier Hilbert–Schmidt;
for D^-1 on the right use square integrability of
1_{|k|<1}/|k| in three spatial dimensions. On the left of a
coefficient times D^-1 one may first split its right low part
and use boundedness of the remaining high D^-1. For high-high B
define

    Y(t)=int_0^infty e^(-v D) Pi B(t) Pi e^(-v D) dv.

Each integrand with v>0 is compact by the localized
Hilbert–Schmidt bound with the exponential Fourier multiplier.
The norm is integrable, bounded by ||B|| exp(−2v).
Thus Y and its time derivative are compact in operator norm.
Differentiation in v gives D Y+Y D=Pi B Pi as a form,
and on the domain of D it is the operator identity. Assign
X_+-=iY_+- and X_-+=−iY_-+. With
A0=diag(−iD,+iD), this gives B_off=[A0,X]+K with compact K.
The first-order coefficient operators also preserve the
inhomogeneous H^1 domain of A0, by differentiating the smooth
coefficients and using the same low D^-1 bound.

In Duhamel's formula for U−U_d replace B_off by this identity.
Differentiate U_d(t,v) X(v) U(v,t0). The derivative equals the
sandwich of −[A0,X]+X'+X B−B_diag X. The boundary terms and
every remaining sandwich are compact. The integral is a norm
limit of compact operators, using strong continuity of the
propagators and their adjoints around the compact factors.
This proves U−U_d compact. This is an energy-space proof for
the present massless system, with no scalar positive-energy
or indefinite-bundle invertibility theorem imported.

For the R_F branch the free solution has f_-=0 at late times
and f_+=0 at early times for sources between those times. This
follows directly by the two poles of R_eta, or the kernel
e^(-i D |t−t'|) times its inverse-D normalization. To prescribe
that branch for the perturbed system, solve for its incoming
f_- using the outgoing minus block U_-- and the inhomogeneous
response. The diagonal minus evolution of U_d is invertible,
so U_-- is Fredholm of index zero. The only obstruction to a
bounded Feynman inverse in this space is a finite-dimensional
homogeneous Feynman kernel. On a fixed profile path
sigma=z chi the operators depend analytically on z over
finite slabs, also after complexifying z. The shear remains
exact. (U_d)_--^-1 U_-- is the identity plus an analytic compact
operator and is invertible at z=0. The analytic Fredholm
alternative therefore confines exceptional amplitudes on
this path to a discrete set. This does not decide whether the
prescribed unit plateau amplitude belongs to that set.

For a fixed shape, dilation preserves this criterion. Under
sigma_R(x)=sigma_1(x/R) the original fields scale as
b_R=R^-1 b_1(x/R) and lambda_R=R^-2 lambda_1(x/R).
The shear has the same b scaling because T_R scales as R.
On half-wave energy data the two port weights are, up to a
common factor, the spatial unitary dilation for c and R^-1
times that dilation for lambda. Thus the obstruction space
is conjugate for all dilations of the same shape. A uniform
bound in these scaled Cauchy norms would still leave the
loop product bounds to be shown.

## Original constraint and an absorption-controlled branch

Let the above Feynman boundary problem have a solution for
compact smooth J,j. Both c and lambda are R_F of compact
effective sources because the free wave equation sees only
the original source and Q_sigma u. The effective sources
are compact L² from the energy estimate. The free wave
Feynman solution of such sources has the selected data and
is unique by free half-wave evolution. Reconstruction gives

    C=div b+j−w a^-1 lambda
      =div c+alpha(x·partial+4)lambda−w lambda
          +compact distribution.

At the simple Feynman boundary [x·partial,R_F]=2R_F by
homogeneity. Compact terms themselves equal R_F Box of
those terms by the two-sided fundamental solution identity.
It follows that C=R_F Box C. The same holds for Z=e^(sigma/2) C
since its difference from C is compact. The exact V905
residual equation gives div(a d C)=0. Thus
(Box−Box sigma/2−s²/4) Z=0. The right-side potential forcing
is compact L² since c,lambda are in the energy space locally.
The V901 weighted simple-resolvent bound first places
rho^-1 Z in L², and strict Hardy contraction for this scalar
potential then gives Z=0. Hence the original auxiliary and
vector equations hold whenever the sheared Feynman problem
is solved on this domain.
The original unsheared fields equal the free gauge Feynman inverse
of their original compact effective source. Indeed the original
Hessian minus its flat part is compact first order, and the
reconstructed fields and this free solution have the same sheared
end signs. Their difference solves the flat homogeneous system,
whose shear gives zero by free uniqueness. This matches the original
dipole and mixed prescription at the boundary, independently of
finite-absorption matrix conventions.


There is also a controlled positive-absorption construction
near z=0 for any fixed compact chi. The V902 Huygens estimate
on spatially localized R_eta(tau) is O(<tau>^-1) in L².
The interior Helmholtz estimate gives O(<tau>) in spatial H²,
so interpolation gives a uniform spatial H¹ bound. Together
with the temporal derivative bound this maps compact sources
in L² to local spacetime H¹, uniformly for small eta, and
converges strongly there by interpolation and Plancherel.
On a fixed slab and ball containing the coefficient support,
Q_sigma is O(|z|) as a map from H¹ to L². The compactly
localized equation u=R_eta(F−Q_sigma u) is a contraction
for small |z|. The sequential eta boundary solves the sheared
Feynman problem, and the scalar constraint bound is strict
for sufficiently small real z. This establishes the branch
without selecting w. This amplitude control does not reach
the fixed unit plateau merely by taking a broad log profile.

Gell-Redman, Haber and Vasy, arXiv:1410.7113, gives a broader
Feynman Fredholm precedent. The compactness, infrared energy
space, shear and scalar constraint checks here are for the
actual residual system. The full coupled boundary at the
unit amplitude, an absorption construction there, and the
inner loop sums remain open.
