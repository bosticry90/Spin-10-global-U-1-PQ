# Constrained gauge Feynman reduction V906

The polynomial shear with its variable factor a^-1 preserves the
actual flat Feynman dipole, mixed signs and width. At positive flat
absorption the original constraint has an explicit residual that
vanishes in the distributional limit. For compact switched profiles
the sheared equations are five massless waves with a compact smooth
first-order matrix. The residual coefficients vanish on the constant
plateau and outside the switch.

On the massless Cauchy energy space the outgoing minus block is
Fredholm of index zero. A finite-dimensional homogeneous Feynman
kernel is the remaining fixed-shape obstruction. At a sufficiently
broad profile, any solution selected by these end conditions satisfies
the original auxiliary constraint and matches the original dipole
branch. Dilating the same shape conjugates the obstruction. The
controlled small-amplitude branch has a sequential absorption limit,
and exceptional amplitudes on the fixed shape path are discrete.

The physical unit amplitude still needs its own kernel test and
boundary estimates. The proof uses the actual gauge action and
ordinary Feynman conventions. The exact replay checks the shear,
dipole, infrared energy factors and constraint algebra. It does
not evaluate the infinite-dimensional block's kernel.
