"""Exact shear, absorption and half-wave controls for V906."""

import sys

import sympy as sp

from execute import run_worker


def flat_route(phase):
    P, eps, w, j, Jd = sp.symbols("P eps w j Jd")
    R = -1/(P+sp.I*eps)
    if phase == "native":
        commutator_multiplier = sp.I*sp.diff(R, P)*2
    else:
        commutator_multiplier = 2*sp.I*R**2
    assert sp.cancel(commutator_multiplier-2*sp.I*R**2) == 0
    alpha = (w-1)/2
    assert sp.expand(alpha*(2*sp.I)*sp.I) == 1-w
    lam = R*Jd
    div_b = R*(Jd+P*j)-(w-1)*P*R**2*Jd
    C = div_b+j-w*lam
    assert sp.cancel(C-sp.I*eps*((w-1)*R**2*Jd-R*j)) == 0
    return {"flat_dipole_width": "1-w", "simple_branch": "-1/(P+i*eps)",
            "constraint_residual": "i*eps*((w-1)*R**2*divJ-R*j)"}


def shear_route(phase):
    t, x, w = sp.symbols("t x w", real=True)
    sigma = t*x+x*x/3 if phase == "native" else t*t/2-t*x
    coords = (t, x)
    metric = sp.diag(1, -1)
    a = sp.exp(sigma)
    s = sp.Matrix([sp.diff(sigma,q) for q in coords])
    up_s = metric*s
    T = (w-1)*sp.Matrix(coords)/(2*a)

    def grad(f):
        return metric*sp.Matrix([sp.diff(f,q) for q in coords])

    def div(b):
        return sum(sp.diff(f,q) for f,q in zip(b,coords))

    def wave(f):
        return div(grad(f))

    def box_vec(b):
        return b.applyfunc(wave)

    W = a*((s.T*up_s)[0]*sp.eye(2)-up_s*s.T)/4
    Hess = metric*sp.hessian(sigma,coords)
    c = sp.Matrix([sp.Function("c0")(*coords),sp.Function("c1")(*coords)])
    lam = sp.Function("lam")(*coords)
    b = c+T*lam
    A_b = box_vec(b)+b.jacobian(coords)*up_s+Hess*b+W*b/a-grad((s.T*b)[0])
    P0 = A_b-(w-1)*grad(lam)/a+w*up_s*lam/a
    P1 = div(W*b)+wave(lam)
    top = (P0-T*P1-box_vec(c)).applyfunc(sp.expand)
    bot = sp.expand(P1-wave(lam))
    jets = [sp.diff(f,q1,q2) for f in (*c,lam) for q1 in coords for q2 in coords]
    for coefficient in (*top,bot):
        assert all(sp.simplify(coefficient.coeff(jet)) == 0 for jet in jets)
    assert sp.simplify(2*a*sp.diff(T[0],t)-(w-1)*(1-t*s[0])) == 0

    constant = sp.symbols("constant", real=True)
    Tc = (w-1)*sp.Matrix(coords)/(2*sp.exp(constant))
    plateau = box_vec(c+Tc*lam)-((w-1)*grad(lam)/sp.exp(constant))-Tc*wave(lam)
    assert all(sp.simplify(y) == 0 for y in plateau-box_vec(c))
    # A shear with a missing a^-1 would leave a generic plateau term.
    assert sp.simplify((w-1)*(1-sp.exp(-constant))) != 0
    return {"conjugated_principal": "Box*I5", "constant_plateau_residual": 0,
            "missing_a_inverse_negative_control": "nonzero"}


def energy_controls():
    k1,k2 = sp.symbols("k1 k2", positive=True)
    D = sp.diag(k1,k2)
    B = sp.Matrix(2,2,sp.symbols("B0:4"))
    Y = sp.Matrix(2,2,lambda i,j:B[i,j]/(D[i,i]+D[j,j]))
    assert (D*Y+Y*D-B).applyfunc(sp.cancel) == sp.zeros(2)
    x = sp.symbols("x", positive=True)
    assert sp.integrate(x**2/x**2,(x,0,1)) == 1
    assert sp.integrate(x**2/x**4,(x,0,1)) == sp.oo
    R = sp.symbols("R", positive=True)
    assert R*R**-2 == R**-1
    assert R**-3/R**-2 == 1/R
    return {"sylvester_denominator": "k_i+k_j", "right_low_D_inverse_HS_radial": 1,
            "right_low_D_inverse_squared_HS_negative_control": "divergent",
            "dilation_relative_auxiliary_weight": "1/R"}


def check(phase):
    return {"flat":flat_route(phase), "shear":shear_route(phase),
            "energy":energy_controls()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
