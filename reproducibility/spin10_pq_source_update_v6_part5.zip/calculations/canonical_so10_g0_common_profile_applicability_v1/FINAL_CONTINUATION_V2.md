# Explicit IR symbol binding in final verification

The first final worker completed both independent operand/support/reference
routes,then FAILED parsing the stored IR expression. SymPy resolves E1 to
its built-in exponential-integral function without an explicit locals map.
The complete source,preparation and failed capture remain unchanged.
No E4 step or validation receipt was produced by that failed worker.

validate_v2.py binds f0,f1,E0,E1 explicitly to the already declared symbols.
This changes parsing only,not the polynomial identity or its independent
integer-coefficient test. All source,profile,reference,clock,normalization,
resource and custody requirements remain. One new180s/8GiB verifier under
the standing delegation;no old execution is relabeled PASS or resumed.

Old final navigation bytes are saved and checked against the immutable
first-final preparation. Current navigation points to RESULT_V2.md. Completion
requires validation_receipt_v2.json and capture_validation_v2.json. The
unsuffixed failed final capture remains FAILED;no scientific-state change.
