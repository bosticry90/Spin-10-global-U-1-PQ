from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-common-profile-applicability-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='249a9f11c1ce01ff46ec77c079494cefcf2835e8'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names=set(json.loads((B/'canonical_so10_marked_geometric_primitive_transport_v1/preparation_validation.json').read_bytes())['sha256'])|{'docs/RESEARCH_EXECUTION_HANDOFF_V863.md','calculations/canonical_so10_marked_geometric_primitive_transport_v1/validation_receipt.json','calculations/canonical_so10_marked_geometric_primitive_transport_v1/capture_validation.json'}
extra={
'canonical_so10_absolute_marked_quantum_g0_recovery_v1':['quantum.py','review_v3.py','PROOF.md','validation_receipt.json','native_tables.json.gz','replay_tables.json.gz','identity_tables_v3.json.gz'],
'canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1':['PROOF.md','validation_receipt.json','native_tables.json.gz','replay_tables.json.gz','analytic_review_v2.py','analytic_tables_v2.json.gz'],
'canonical_so10_unmarked_g0_common_kinetic_recovery_v1':['PROOF.md','RECORD.md','derive_v2.py','validation_receipt.json','derivation_tables_v2.json.gz'],
'canonical_so10_heat_clock_applicability_v1':['PROOF_V3.md','RESULT_V3.md','complete_profile_and_clock_evidence_v3.json.gz','validation_receipt_v5.json','capture_validation_v5.json']}
for folder,files in extra.items():
    for n in files:names.add('calculations/'+folder+'/'+n)
enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
assert C.exists()and not(C/'preparation.json').exists()
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings.json',dict(bindings=enc));dump(C/'input_encoding_bindings.json',dict(bindings=enc))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
