from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-common-profile-applicability-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='249a9f11c1ce01ff46ec77c079494cefcf2835e8'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip();assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
old=json.loads((O/'preparation.json').read_bytes());assert old==json.loads((C/'preparation.json').read_bytes())
for n,h in old['sha256'].items():assert digest(R/n)==h,n
failure=json.loads((O/'capture.json').read_bytes());assert failure==json.loads((C/'capture.json').read_bytes())and failure['exit_code']==1 and not failure['calculation_completed']and"KeyError: 'Gamma_vv_n0'"in failure['stdout_and_stderr']
names={row['file']for row in json.loads((O/'input_encoding_bindings.json').read_bytes())['bindings']};enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
dump(O/'input_encoding_bindings_v2.json',dict(bindings=enc));dump(C/'input_encoding_bindings_v2.json',dict(bindings=enc))
for n in['CONTINUATION_V2.md','compute_v2.py','execute_v2.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_v2.json',prep);dump(C/'preparation_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_v2.py')]);dump(O/'capture_v2.json',cap);dump(C/'capture_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
