# Replay operand schema correction

The first worker completed its native comparison,then failed on replay's
absent Gamma_vv_n0 key. Complete source,preparation,capture and partial native
artifact remain unchanged and FAILED as a whole. Replay's actual qualified
operand is closed_DGamma_n0;it is not a separately stored full Ca polynomial.

compute_v2 reads these two actual objects explicitly. Native compares the
full Ca polynomial;replay compares its closed marked kernel. The unsummed
ML/L and probe families supply the independent complete M support in BOTH
routes,including the zero H complement. No full replay-Ca reconstruction is
invented. The shared V804 full unmarked polynomial remains its native operand.
The final report and verifier must disclose this difference in independence.

A direct33-port -EL_Ja K=epsilon check additionally substantiates the selected
field-root premise. The full1286 current-source operation remains authenticated
prior evidence,not a new replay claim. All original scientific conditions and
120s/8GiB/32MiB/8MiB limits remain. A fresh complete restart writes only new
v2 artifacts;no partial cache is promoted. This delegated schema correction
does not authorize or relabel the failed run.
