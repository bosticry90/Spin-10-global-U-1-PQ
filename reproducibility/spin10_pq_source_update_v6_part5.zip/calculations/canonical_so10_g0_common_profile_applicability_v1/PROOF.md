# Actual lower-order data fit the selected M profile boundary

Requires the completed separate final receipt/capture. Domain remains
unshifted A0,g0,first H/M u,intrinsic01,with independent Schwartz endpoints
and all source operations performed before restriction. No new loop amplitude,
finite conversion coefficient or normalization baseline is computed here.

## Current operands,not a final-color shortcut

The epsilon Eulers of the CURRENT V861 primitive reproduce V782's full
ghost matrices L. The sign from canonical C-a order to the a-C mass matrix
is retained. All33 source derivatives independently give -EL_Ja K=epsilon.
The remaining1286-column source operation and its conventions are qualified
prior evidence,not newly replayed by this selected check.

The current H/M U0 densities agree literally with the older full-source qG
operands. Source differentiation precedes restriction,and all45 antighost
probe flows agree with -EL_Ja U. Current S0 antighost and Ja derivatives
also agree with the actual V804 E0/F0 inputs. The physical potential has
no antighost or these source ports;its gradients are not assigned zero.

Every unsummed matrix ML,L,N,Y,ULambda and tangent is retained. All nonempty
ML/L colors and both matrix indices are in12..44. H-probe N/Y/ULambda/tangent
are entirely empty BEFORE any profile is selected. The H linear bosonic
gradient is generally nonzero and is retained;its selected loop return has
an empty quantum partner. No H-profile choice is needed for this selected
zero. This does not say the whole H effective action vanishes.

For the M probe,all internal ghost indices and mixed divB_r/Lambda_r
endpoints lie in M. The actual source sign identities are checked:

    L_s=-i ML_s, N_r=-2i Pi_r ML_r,
    Y_r=+2i Pi_r ML_r, tangent_r=+2i Pi_r ML_r.

The Ja and divB source bubbles cancel as N+Y before applying a profile.
Native's full proper Ca polynomial agrees with the independently stored
absolute marked colors. Replay's older packet stores closed_DGamma_n0,
not a second full Ca polynomial;that different operand is compared explicitly.
Both routes have the complete unsummed matrices and zero H complement.
V804's full unmarked polynomial is its bound native operand,with the qualified
odd-Q operation. No unavailable replay polynomial is invented.

## Signed reference and all required edges

The required coordinates are covered by V847's231 selected M coordinates:
132 vector,33 auxiliary,33 ghost and33 antighost. All858 signed reference
Green entries and their zero complement remain part of the bound packet.
For EACH color r12..44,projecting actual vector entries with dual Fourier
signs gives the complete inverse on y=divB,Lambda:

    G_yLambda = [[xi,-i],[-i,0]].

The two ordered ghost entries are G_Ca=+1/q2 and G_aC=-1/q2. The full mixed
contraction (i,xi/2)G e_Lambda=1 is checked for every color. Thus the extra
heat at that mixed node is retained;it is not collapsed to a two-edge bubble.
Original free-reference reconstruction is inherited from V791;the present
test checks its actual selected entries and the longitudinal projection.

V847's corrected v3 packet/v5 receipt supplies exactly the same scalar edge
profile f_delta exp(-t_new q2) after t_new=2t_old,delta=epsilon. The old proof
edge has chi exp(-t_old q2) on each side. Equality is edgewise,with each
transferred momentum independent;no heat is commuted across a vertex.
Current primitive/probe/source equality supplies the missing same-vertex
premise for these selected data. Unselected profiles remain unchosen.

## The finite-IR root is not replaced silently

Set F_j=f_j E_j. The full proper root and the physical-fixed regulator root
obey the exact identity

    F1(1-F0)^2-F1 F0(E0^-1-1)(1-F0)
       = F1(1-F0)(1-f0).

This remainder is nonzero at finite smoothing. The complete Rall G=1-fE
contains both f(1-E) and1-f;using the heat-only term would discard it.
V782/V786's qualified Gaussian/Schwinger bound makes the corresponding
integrated remainder O(delta2),uniformly in t and the external transfer,
after retaining the common UV subtraction. That analytic result is reused,
not newly integrated. UV finite part precedes IR removal. No p=0,plane-wave
diagonal or independently integrated inverse heat is introduced.

## The 11/36 master survives the correctly rescaled clock

The qualified raw sum is I0-2I1+I3. A symbolic uniform-clock derivation and
independent rational exponential coefficients both give

    I0-2I1+I3 = 1/(3*c*t)+(11/36)p2+O(t).

Here t_abs=t_new=2t_old. The power subtraction must therefore become
1/(6*t_old),not remain1/(3*t_old). This particular sum has NO logarithmic
coefficient,so its finite p2 term is unchanged by a uniform clock change.
V847's log2 shift for a different logarithmic bubble is not a universal
constant to add to every coefficient. All analytic/power prefactor terms
remain in their actual owning expressions.

Wrong clock,one-sided IR,omitted finite-IR remainder,collapsed third heat
and unrescaled power controls are sensitive in their stated objects. The
collapsed two-edge finite coefficient3/8 differs from11/36. These are
analytic controls,not independent physical measurements.

## What this permits,and which normalization target is correct

This establishes selected actual-profile applicability for the measured
absolute C-epsilon and unmarked Lambda-C inputs. It does not evaluate
Cfin=F_kappa-F_heat or fix a coefficient to the negative of a desired remainder.

Within V804's explicitly bounded kinetic family,the correct simultaneous
equations are

    R+H-K=0, R-K+T=0, R=11Q/36,
    K=H+R, T=H on marked rows.

H stays free. The earlier H=K restriction still has its historical marked-only
H-T=R preimage,but leaves the newly measured unmarked residual R. It cannot
be imposed as a universal condition or a counterexample to the broader family.
No connected baseline,kappa,b0 or physical parameter is selected here.

The actual E5 W5 identity is broken geometric Ward transport with whole
insertions;W6 carries insertion/source companions with a normalization change.
V833's unmarked source correction and V834's operator images remain valid.
Their unadopted representative is not an extra fixed physical subtraction
condition. At g1,the nonzero DS carrier and V863's TK insertion must remain;
a homogeneous auxiliary-D equation cannot replace them.

There is also an already achieved operator implication: V853 gives
Q_A F_kappa=I_B[A],and V854 gives B[A]=0 through first u in the fixed bosonic
quotient. Thus the selected formal Slavnov equation is satisfied in that
prospective map. Additional amplitudes are not needed to establish that
implication. It is not yet an admissible common restored physical prescription.
Current-parent reality/background and joint LEFT-derivative applicability,
plus any genuinely fixed finite normalization conditions,must still be settled.
Old actual-pole normalization/physical-span theorems do not automatically
classify a new non-Q-closed finite restoring preimage.

The next economical gate is the augmented current real/source operation and
joint derivative-domain audit,using the existing DSP and V840/V841 owners.
Only a genuinely fixed normalization condition calls for a new coefficient
comparison. The original full background domain is not supplied merely by
A0 data;local background transformations do not preserve A0=0.

## Evidence and limitations

The first worker failed after the native route because the replay packet has
a different schema. Its complete source/capture and partial native artifact
remain FAILED. V2 handles each actual operand separately and restarts fully
under unchanged120s/8GiB limits;it completed25.43s. Separate final verification
is required. Current source/primitive comparisons are fresh;old loop amplitudes,
IR theorem and reference derivations are authenticated/reused,not re-executed.
An unfrozen validator draft also failed its AST parse on missing whitespace
in a conditional expression. Its exact text and diagnostic are retained;
the preparation correction occurred before any final verifier was launched.

Shared action,software,reference,analytic premises and AI authorship limit
independence. No new alpha4 coefficient,full nonlocal amplitude,complete
actual-profile match,QAP,measure,A5,E5 or physical viability is established.
Authority stays34/39 with seven custody NOTPASS;no scientific-state change,
foundational adoption,push or publication.
