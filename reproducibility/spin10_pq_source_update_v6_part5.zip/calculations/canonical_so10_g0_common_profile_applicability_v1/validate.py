from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-common-profile-applicability-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V864_BOUND_FRACTION_WORD_CHECKER',B/'canonical_so10_marked_geometric_primitive_transport_v1/validate.py');x=importlib.util.module_from_spec(sp);sp.loader.exec_module(x);v=x.v;f=x.f
def read(q):return json.loads(q.read_bytes())
def load(q):return json.loads(gzip.decompress(q.read_bytes()))
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def compact(rows):return{(tuple((n,tuple(j))for n,j in w),tuple(k)):F(num,den)for w,cells in rows for k,num,den in cells}
def coefficient(rows):return{tuple(k):F(n,d)for k,n,d in rows}
def matrix(rows):return{(i,j):coefficient(c)for i,j,c in rows}
def family(rows):return{r:matrix(q)for r,q in rows}
def g0(q,D):return{(w,k):val for(w,k),val in q.items()if k[0]==0 and 0<=D-sum(f.dim(n)+len(js)for n,js in w)<=1}
def neg(q):return{k:-z for k,z in q.items()}
def imaginary(q,n,par):
    out=x.mul({((),(0,0,0,16)):F(n)},{((),k):z for k,z in q.items()},par)
    return{k:z for(w,k),z in out.items()}
def scale_matrix(q,n,par):return{ij:imaginary(c,n,par)for ij,c in q.items()}
def psum(*qs):
    out={}
    for q in qs:
        for k,z in q.items():out[k]=out.get(k,0)+z
    return{k:z for k,z in out.items()if z}
def pmul(a,b):
    out={}
    for k,z in a.items():
        for kk,zz in b.items():key=tuple(i+j for i,j in zip(k,kk));out[key]=out.get(key,0)+z*zz
    return{k:z for k,z in out.items()if z}
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='249a9f11c1ce01ff46ec77c079494cefcf2835e8'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    for prepname in['preparation.json','preparation_v2.json']:
        prep=read(O/prepname);assert prep==read(C/prepname)
        for n,h in prep['sha256'].items():assert digest(saved.get(n,R/n))==h,n
    for encname in['input_encoding_bindings.json','input_encoding_bindings_v2.json']:
        enc=read(O/encname);assert enc==read(C/encname)
        for row in enc['bindings']:
            n=row['file'];live=saved.get(n,R/n).read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
            assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(blob).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==blob)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==blob)and(row['exact_equal']or row['only_CRLF_to_LF'])
            if live!=blob:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    fail=read(O/'capture.json');assert fail==read(C/'capture.json')and fail['exit_code']==1 and not fail['calculation_completed']and"KeyError: 'Gamma_vv_n0'"in fail['stdout_and_stderr'];assert(O/'native_complete_g0_profile_applicability.json.gz').exists()
    draft=read(O/'validation_preparation_failure.json');assert not draft['scientific_worker_launched']and draft['phase']=='UNFROZEN_VALIDATOR_AST_PREPARATION'
    try:ast.parse((O/draft['failed_source']).read_bytes().decode('utf-8'));raise AssertionError('PRESERVED_DRAFT_NO_LONGER_FAILS')
    except SyntaxError as err:assert(err.msg,err.lineno,err.offset,err.text)==(draft['message'],draft['line'],draft['offset'],draft['source_line'])
    cap=read(O/'capture_v2.json');assert cap==read(C/'capture_v2.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<q['private_bytes']<=8*1024**3 for q in cap['all_resource_samples']);res=read(O/'result_v2.json');assert res['elapsed_after_imports']<120
    profile=load(B/'canonical_so10_heat_clock_applicability_v1/complete_profile_and_clock_evidence_v3.json.gz');ids=set(profile['selected_M_coordinate_ids']);assert ids==set(range(48,180))|set(range(520,553))|set(range(565,598))|set(range(610,643));q=s.symbols('q0:4');qq=sum(vv*vv for vv in q);xi=s.Symbol('xi');G={(i,j):s.sympify(c)for i,j,c in profile['complete_selected_matrix_entries']['Greference']};expected={}
    for r in range(12,45):
        for mu in range(4):
            for nu in range(4):expected[4*r+mu,4*r+nu]=int(mu==nu)/qq+(xi-1)*q[mu]*q[nu]/qq**2
            expected[4*r+mu,508+r]=-q[mu]/qq;expected[508+r,4*r+mu]=q[mu]/qq
        expected[553+r,598+r]=1/qq;expected[598+r,553+r]=-1/qq
    assert set(expected)==set(G)and len(G)==858 and all(s.cancel(G[k]-z)==0 for k,z in expected.items())
    # Independent inverse of the collapsed quadratic kernel,not an assumed trace zero.
    small=s.Matrix([[0,s.I],[s.I,xi]]).inv();assert small==s.Matrix([[xi,-s.I],[-s.I,0]])and(s.Matrix([[s.I,xi/2]])*small*s.Matrix([0,1]))[0]==1
    E,ff=s.symbols('E_profile f_profile');GF={(i,j):s.sympify(c)for i,j,c in profile['complete_selected_matrix_entries']['G_F']};assert G.keys()==GF.keys()and all(s.cancel(GF[k]-E*ff*z)==0 for k,z in G.items());hp={(i,j):s.sympify(c)for i,j,c in profile['complete_selected_matrix_entries']['heat_product']};ip={(i,j):s.sympify(c)for i,j,c in profile['complete_selected_matrix_entries']['IR_product']};assert set(hp)==set(ip)=={(i,i)for i in ids}and all(s.expand(hp[i,i]-ff*(1-E))==s.expand(ip[i,i]-(1-ff))==0 for i in ids)
    assert profile['complete_selected_matrix_entries']['Preference']==profile['complete_selected_matrix_entries']['Pphysical']and not profile['complete_selected_matrix_entries']['reference_defect']and not profile['complete_selected_matrix_entries']['reference_product']
    operator=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');states={n:dict(rows)for n,rows in operator['states'].items()};unmarked=load(B/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_tables_v2.json.gz');summaries=[]
    native_proper=load(B/'canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1/native_tables.json.gz')
    for rr,owner in zip(res['roles'],['primary','replay']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=load(O/art['file']);assert z['selected_M_coordinate_ids']==sorted(ids)
        old=load(B/'canonical_so10_absolute_marked_quantum_g0_recovery_v1'/(role+'_tables.json.gz'));proper=load(B/'canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1'/(role+'_tables.json.gz'));base=load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'));par=base['joined_parities'][:1331];K={key:val for key,val in v.flat(base['complete_K']).items()if key[1][0]==0};EK=x.epsilon_Eulers(K,par);EJ=v.allE(K,par);L={}
        for r in range(12,45):
            assert neg(EJ[1241+r])==x.atom(1286+r-12);mm=defaultdict(dict)
            for(w,k),val in EK[1286+r-12].items():
                if len(w)==2 and all(not js for n,js in w)and 553<=w[0][0]<598 and 598<=w[1][0]<643:mm[w[1][0]-598,w[0][0]-553][k]=-val
            L[r]=dict(mm)
        assert L==family(old['L'])==family(z['all33_current_epsilon_Euler_L']);ML=family(old['ML']);assert old['ML']==z['all45_original_ML']and set(ML)==set(range(45))and sum(map(len,ML.values()))==600
        assert all(not mm or r>=12 and all(12<=i<45 and 12<=j<45 for i,j in mm)for r,mm in ML.items())and all(L[r]==scale_matrix(ML[r],-1,par)for r in range(12,45))
        b=load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S0=g0(v.flat(b['complete_current_GF_source_base']),4);ES=v.allE(S0,par)
        for r in range(45):assert ES.get(598+r,{})==compact(states['E0'][598+r])and neg(ES.get(1241+r,{}))==compact(states['F0'][598+r])
        fj=load(B/'canonical_so10_full_jet_source_master_bridge'/(owner+'_tables.json.gz'));journal={(row['probe'],row.get('family','proper')):row for row in z['complete_family_support']};assert len(journal)==10
        for pr,probe in enumerate(['H','M']):
            fixture=load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_'+probe+'_even_geometric_insertion_v2.json.gz'));U=g0(v.flat(fixture['complete_selected_U']),4);assert U==g0(compact(fj['probes'][pr]['qG']),4);UE=v.allE(U,par);oldprobe=old['probes'][pr]
            assert all(neg(UE.get(1241+r,{}))==compact(rows)for r,rows in oldprobe['actual_q1a'])
            for name in['N','Y','ULambda','tangent']:
                mm=family(oldprobe[name]);saved=journal[probe,name];assert mm==family(saved['complete_matrices'])and set(mm)==set(range(45))
                if pr==0:assert not any(mm.values())
                else:assert all(not cc or r>=12 and all(i>=12 and j>=12 for i,j in cc)for r,cc in mm.items())
                if name!='ULambda':assert all(mm[r]==(scale_matrix(ML[r],-2 if name=='N'else 2,par)if pr==1 and r>=12 else{})for r in range(45))
            saved=journal[probe,'proper'];deriv=proper['probes'][pr]['proper_derivation'];Q={}
            if role=='native':
                assert saved['proper_operand_kind']=='FULL_PROPER_Ca'and saved['proper_n0_Ca']==deriv['Gamma_vv_n0']and saved['proper_n0_closed_DGamma']is None
                for w,cc in deriv['Gamma_vv_n0']:
                    assert len(w)==2 and all(not js for n,js in w);cn,an=[n for n,js in w];assert 565<=cn<598 and 610<=an<643;Q[an-598,cn-553]=coefficient(cc)
            else:
                assert saved['proper_operand_kind']=='CLOSED_DGamma_KERNEL'and saved['proper_n0_Ca']is None and saved['proper_n0_closed_DGamma']==deriv['closed_DGamma_n0'];Q={(ss,cc):coefficient(co)for ss,cc,co in deriv['closed_DGamma_n0']}
            Qnative={(w[1][0]-598,w[0][0]-553):coefficient(co)for w,co in native_proper['probes'][pr]['proper_derivation']['Gamma_vv_n0']};assert Q==Qnative==matrix(unmarked['cases'][pr]['Q_matrix'])==matrix(saved['complete_Q_matrix']);assert len(Q)==(0 if pr==0 else 57)
            assert saved['boson_gradient_RETAINED']==oldprobe['boson_gradient']
            for case in old['cases']:
                if case['probe']==pr:assert coefficient(case['regulator_ghost'])==Q.get((case['epsilon'],case['C']),{})and not case['QI_p2_coefficient']
        for row in z['all33_mixed_reference_and_ordered_ghost_blocks']:assert row['color']in range(12,45)and row['complete_y_Lambda_inverse']==[['xi','-I'],['-I','0']]and row['ordered_C_a_Green']=='1/q_squared'and row['ordered_a_C_Green']=='-1/q_squared'and row['Z_Lambda_contraction']=='1'
        assert len(z['all33_mixed_reference_and_ordered_ghost_blocks'])==33
        summaries.append(dict(role=role,complete_current_K_ghost_Eulers_and33_Da_roots_verified=True,complete_current_S0_source_and_U0_probe_interfaces_verified=True,unsummed_internal_support_M_before_contraction=True,H_quantum_families_empty_without_H_profile=True,all858_signed_Green_and_zero_complement_verified=True,native_full_Ca_or_replay_closed_D_operand_explicit=role,full1286_K_replay_NOT_claimed=True));print('STAGE '+role+' independent_Fraction_interfaces_complete_M_support_and_reference_verified',flush=True)
    # Independent integer polynomial identity (E0,E1,f0,f1).
    unit={(0,0,0,0):1};e0={(1,0,0,0):1};e1={(0,1,0,0):1};f0={(0,0,1,0):1};f1={(0,0,0,1):1};m=lambda q:{k:-z for k,z in q.items()};F0=pmul(f0,e0);F1=pmul(f1,e1);oneF=psum(unit,m(F0));properpoly=pmul(F1,pmul(oneF,oneF));fixedpoly=pmul(pmul(F1,f0),pmul(psum(unit,m(e0)),oneF));defect=pmul(F1,pmul(oneF,psum(unit,m(f0))));assert psum(properpoly,m(fixedpoly),m(defect))=={}and defect
    # General one-denominator Schwinger formula gives these rational coefficients.
    def schwinger(a,b):return F(1,a+b),-F(b*(2*a+b),2*(a+b)**2)
    lead1,finite1=schwinger(1,1);lead3,finite3=schwinger(1,2);lead=F(1)-2*lead1+lead3;finite=-2*finite1+finite3;assert lead==F(1,3)and finite==F(11,36)and -finite1==F(3,8)!=finite
    math=read(O/'clock_IR_and_normalization_boundary_v2.json');assert math==res['math']and math['Fraction_finite_p2']==[11,36]and math['logarithmic_coefficient']==0 and all(math['controls'].values())and math['complete_existing_kinetic_equations']==unmarked['common_equations']and math['H_K_T_baseline_NOT_chosen']
    sf0,sf1,sE0,sE1=s.symbols('f0 f1 E0 E1');assert s.expand(s.sympify(math['IR_fixed_vs_full_difference'])-sf1*sE1*(1-sf0*sE0)*(1-sf0))==0 and s.expand(s.sympify(math['finite_p2'])-s.Rational(11,36)*s.Symbol('p2'))==0 and math['IR_remainder_NOT_zero_at_finite_delta']
    H,K,T,R0=s.symbols('H K T R');assert s.expand((R0+H-K).subs(K,H+R0))==s.expand((R0-K+T).subs({K:H+R0,T:H}))==0 and s.expand((R0+H-K).subs(K,H))==R0
    # Profile identity and IR root are symbolic transfer identities,not p=0 tests.
    q2,told,tnew,delta,eps=s.symbols('q_squared t_old t_new delta epsilon',positive=True);old=(1-s.exp(-q2/eps**2))**2*s.exp(-2*told*q2);new=(1-s.exp(-q2/delta**2))**2*s.exp(-tnew*q2);assert s.simplify(new.subs({delta:eps,tnew:2*told})-old)==0 and s.simplify(new.subs({delta:eps,tnew:told})-old)!=0
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V864.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V864.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V864.md').read_text()),(O/'RESULT.md',(O/'RESULT.md').read_text())]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2;files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V864.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_SELECTED_G0_ACTUAL_PROFILE_APPLICABILITY_WITH_RETAINED_IR_DEFECT',base_HEAD=head,state_sha256=state,roles=summaries,failed_replay_schema_and_all_sources_preserved=True,finite_master_clock_invariant_fraction=[11,36],IR_defect_RETAINED_until_inherited_ordered_limit=True,normalization_baseline_NOT_selected=True,common_conversion_coefficients_joint_admissibility_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_inputs_software_AI_and_old_analytic_premises_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
