from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-common-profile-applicability-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V864_BOUND_INPUT_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def g0(P,D):return{k:v for k,v in P.items()if k[0]==0 and 0<=D-sum(p.dim(n)+len(j)for n,j in k[1])<=1}
def co(rows):return{tuple(k):F(n,d)for k,n,d in rows if n}
def matrix(rows):return{(i,j):co(cc)for i,j,cc in rows}
def mats(rows):return{r:matrix(mm)for r,mm in rows}
def ico(q,n):
    out={}
    for k,x in q.items():
        kk=list(k);factor=n
        if kk[3]&16:factor=-factor
        kk[3]^=16;out[tuple(kk)]=factor*x
    return out
def scale_mat(q,n,imag=False):return{ij:ico(cc,n)if imag else{k:x*n for k,x in cc.items()}for ij,cc in q.items()}
def em(q):return[[i,j,[[list(k),x.numerator,x.denominator]for k,x in sorted(cc.items())]]for(i,j),cc in sorted(q.items())]
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    profile=a.load(B/'canonical_so10_heat_clock_applicability_v1/complete_profile_and_clock_evidence_v3.json.gz');inds=set(profile['selected_M_coordinate_ids']);expected=set(range(48,180))|set(range(520,553))|set(range(565,598))|set(range(610,643));assert inds==expected and len(inds)==231
    q=s.symbols('q0:4');q2=sum(x*x for x in q);xi=s.Symbol('xi');G={(i,j):s.sympify(c)for i,j,c in profile['complete_selected_matrix_entries']['Greference']};assert len(G)==858 and all(i in inds and j in inds for i,j in G)
    gaussian=[]
    for r in range(12,45):
        yL=s.expand(sum(s.I*q[mu]*G.get((4*r+mu,508+r),0)for mu in range(4)));Ly=s.expand(sum(G.get((508+r,4*r+mu),0)*(-s.I)*q[mu]for mu in range(4)));yy=sum(q[mu]*G.get((4*r+mu,4*r+nu),0)*q[nu]for mu in range(4)for nu in range(4));LL=G.get((508+r,508+r),0)
        assert s.cancel(yL+s.I)==s.cancel(Ly+s.I)==s.cancel(yy-xi)==LL==0
        assert s.cancel(q2*G[553+r,598+r]-1)==s.cancel(q2*G[598+r,553+r]+1)==0
        contraction=s.simplify(s.I*yL+xi*LL/2);assert contraction==1;gaussian.append(dict(color=r,complete_y_Lambda_inverse=[['xi','-I'],['-I','0']],ordered_C_a_Green='1/q_squared',ordered_a_C_Green='-1/q_squared',Z_Lambda_contraction=str(contraction)))
    reports=[]
    ops=a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');states={k:dict(vv)for k,vv in ops['states'].items()}
    for role,owner in[('native','primary'),('replay','replay')]:
        old=a.load(B/'canonical_so10_absolute_marked_quantum_g0_recovery_v1'/(role+'_tables.json.gz'));proper=a.load(B/'canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1'/(role+'_tables.json.gz'));base=a.load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'));A=a.Algebra(base['joined_names'][:1331],base['joined_parities'][:1331]);K={k:cv for k,cv in a.decode(base['complete_K']).items()if k[0]==0};E=a.eulers(A,K,set(range(1286,1319)));currentL={}
        for r in range(12,45):
            mm={}
            for(g,w),cc in E.get(1286+r-12,{}).items():
                if len(w)==2 and all(not js for n,js in w)and 553<=w[0][0]<598 and 598<=w[1][0]<643:mm[w[1][0]-598,w[0][0]-553]={(g,*key):-x for key,x in cc}
            currentL[r]=mm
        assert currentL==mats(old['L']);ML=mats(old['ML']);assert all(not mm or r>=12 and all(i>=12 and j>=12 for i,j in mm)for r,mm in ML.items());assert all(currentL[r]==scale_mat(ML[r],-1,True)for r in range(12,45));family_support=[]
        fj=a.load(B/'canonical_so10_full_jet_source_master_bridge'/(owner+'_tables.json.gz'));currentbase=a.load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S0=g0(a.decode(currentbase['complete_current_GF_source_base']),4);ES=a.eulers(A,S0,set(range(598,643))|set(range(1241,1286)))
        for r in range(45):
            assert ES.get(598+r,{})==p.old(states['E0'][598+r]);assert a.scale(ES.get(1241+r,{}),-1)==p.old(states['F0'][598+r])
        for pr,probe in enumerate(['H','M']):
            fixture=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_'+probe+'_even_geometric_insertion_v2.json.gz'));U=g0(a.decode(fixture['complete_selected_U']),4);assert U==g0(p.old(fj['probes'][pr]['qG']),4);UE=a.eulers(A,U,set(range(1241,1286)));packet=old['probes'][pr]
            assert all(a.scale(UE.get(1241+r,{}),-1)==p.old(rows)for r,rows in packet['actual_q1a'])
            for name in['N','Y','ULambda','tangent']:
                mm=mats(packet[name]);assert set(mm)==set(range(45))
                assert all(not rows for rows in mm.values())if pr==0 else all(not rows or r>=12 and all(i>=12 and j>=12 for i,j in rows)for r,rows in mm.items())
                if name in['N','Y','tangent']:
                    n=-2 if name=='N'else 2;assert all(mm[r]==(scale_mat(ML[r],n,True)if(pr==1 and r>=12)else{})for r in range(45))
                family_support.append(dict(probe=probe,family=name,complete_matrices=[[r,em(rows)]for r,rows in mm.items()],H_quantum_family_empty=pr==0,all_nonempty_loop_indices_M=True))
            Cag=proper['probes'][pr]['proper_derivation']['Gamma_vv_n0'];Q={}
            for w,cc in Cag:
                assert len(w)==2 and all(not js for n,js in w);cn,an=[n for n,js in w];assert 565<=cn<598 and 610<=an<643;Q[an-598,cn-553]=co(cc)
            assert not Q if pr==0 else len(Q)==57
            for case in old['cases']:
                if case['probe']==pr:assert co(case['regulator_ghost'])==Q.get((case['epsilon'],case['C']),{})and not case['QI_p2_coefficient']
            family_support.append(dict(probe=probe,proper_n0_Ca=Cag,complete_Q_matrix=em(Q),boson_gradient_RETAINED=packet['boson_gradient'],source_contact_bubbles_N_plus_Y_cancel_before_profile=True))
        art=save(role+'_complete_g0_profile_applicability.json.gz',dict(selected_M_coordinate_ids=sorted(inds),all33_current_epsilon_Euler_L=[[r,em(mm)]for r,mm in currentL.items()],all45_original_ML=old['ML'],complete_family_support=family_support,current_S0_full_a_and_Ja_Eulers_match_V804=True,current_U0_full_source_and_probe_q1a_match_V782=True,H_linear_boson_gradient_not_declared_zero=True,all33_mixed_reference_and_ordered_ghost_blocks=gaussian,actual_profile_v3_packet_sha256=digest(B/'canonical_so10_heat_clock_applicability_v1/complete_profile_and_clock_evidence_v3.json.gz'),H_actual_profile_NOT_selected_or_needed=True))
        reports.append(dict(role=role,artifact=art,all_selected_loop_endpoints_covered_by_V847=True,complete_H_quantum_family_empty_before_profile=True,no_new_loop_integration=True));print('STAGE '+role+' actual_current_operands_and_unsummed_M_support_verified',flush=True)
    f0,f1,E0,E1,t,c,p2=s.symbols('f0 f1 E0 E1 t c p2',positive=True);F0=f0*E0;F1=f1*E1;ir=s.factor(F1*(1-F0)**2-F1*F0*(1/E0-1)*(1-F0));assert s.expand(ir-F1*(1-F0)*(1-f0))==0 and ir!=0
    z=c*t*p2;master=1/(c*t)-2*(s.exp(-z/2)-s.exp(-z))/(c*t*z)+(s.exp(-2*z/3)-s.exp(-2*z))/(4*c*t*z);finite=s.simplify(s.limit(master-1/(3*c*t),t,0));assert finite==11*p2/36
    fraction_leading=F(1)-2*F(1,2)+F(1,3);fraction_finite=-2*(F(1,8)-F(1,2))+(F(2,9)-F(2))/4;assert fraction_leading==F(1,3)and fraction_finite==F(11,36)
    tt,uu,Q2,delta,eps=s.symbols('t_old t_new q_squared delta epsilon',positive=True);oldprofile=(1-s.exp(-Q2/eps**2))**2*s.exp(-2*tt*Q2);newprofile=(1-s.exp(-Q2/delta**2))**2*s.exp(-uu*Q2);assert s.simplify(newprofile.subs({uu:2*tt,delta:eps})-oldprofile)==0
    HH,KK,TT,RR=s.symbols('H K T R');solution={KK:HH+RR,TT:HH};assert s.expand((RR+HH-KK).subs(solution))==s.expand((RR-KK+TT).subs(solution))==0 and s.expand((RR+HH-KK).subs(KK,HH))==RR
    controls=dict(wrong_clock_sensitive=s.simplify(newprofile.subs({uu:tt,delta:eps})-oldprofile)!=0,one_sided_IR_sensitive=s.simplify((1-s.exp(-Q2/eps**2))*s.exp(-2*tt*Q2)-oldprofile)!=0,dropped_IR_defect_sensitive=ir!=0,collapsed_third_heat_sensitive=F(3,8)!=fraction_finite,unrescaled_power_subtraction_sensitive=s.simplify(1/(3*uu)-1/(3*tt))!=0,old_marked_only_family_leaves_unmarked_R=True);assert all(controls.values())
    udata=a.load(B/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_tables_v2.json.gz');assert udata['normalization_coefficients_not_selected']and not udata['loop_integrations_reexecuted']
    math=dict(IR_fixed_vs_full_difference=str(ir),IR_remainder_NOT_zero_at_finite_delta=True,IR_bound='Inherited UV-first Gaussian/Schwinger C*delta^2,not new integration',clock='t_abs=t_new=2*t_old;delta=epsilon',leading_power='1/(3*c*t)',finite_p2=str(finite),logarithmic_coefficient=0,Fraction_finite_p2=[fraction_finite.numerator,fraction_finite.denominator],complete_existing_kinetic_equations=udata['common_equations'],H_K_T_baseline_NOT_chosen=True,controls=controls);dump(O/'clock_IR_and_normalization_boundary.json',math)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='SELECTED_G0_ACTUAL_OPERANDS_MATCH_M_PROFILE_BOUNDARY_WITH_RETAINED_IR_DEFECT',roles=reports,math=math,common_conversion_coefficients_NOT_newly_evaluated=True,joint_reality_background_and_fixed_normalization_applicability_STILL_OPEN=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps({k:result[k]for k in['scientific_disposition','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
