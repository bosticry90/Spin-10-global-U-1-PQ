# Linked local residues for the physical gauge–scalar seagull

## Color decomposition

Write F(B,x)=g²/2 sum_mu (rho(B_mu)x,rho(B^mu)x) for the
derivative-free part of the physical scalar kinetic action.
Use the frozen covariant action and the V788 joined f and
rho, with the common Wick phase and the Lorentz contraction
retained. In this proof B and x are off-shell ordinary fields.
For a gauge color a let X_a=[T_a,B] and r_a=rho_a x.
Simultaneous adjoint and scalar covariance gives

    D_B F[X_a]+D_x F[r_a]=0.

Differentiate in the scalar direction E_(s,a)=rho_a v_s
and sum in a. Then

    S_s = sum_a D_x² F[r_a,E_(s,a)],
    J_s = sum_a D_B D_x F[X_a,E_(s,a)],
    S_s + J_s = C_s D_x F[v_s].

The identity uses the actual representation Casimir of V919
and preserves all scalar blocks in r_a. It is valid without
choosing external colors, Lorentz components or a scalar mean.
The same scalar triangle as V919 gives -2 S_s in that
normalization. A scalar-only calculation would lose J_s.

The new code evaluates the literal seagull derivatives on
one Lorentz component B=e_b and x=v_s for all 45 b, stripping
the common g² and metric sign. It computes the gauge orbit
from f and independently from the commutator of rho. As
sensitive examples, the ordered triples (S_s,J_s,target)
for Phi at b=0 and 17 are (105,-105,0) and (150,100,250).
For Sigma at b=0 and 12 they are (9/10,-9/10,0) and
(183/20,48/5,75/4). The b=0 scalar term is the corresponding
V917 color weight. The nonzero individual triangles on the
unbroken external color test the relative sign.

## Actual gauge triangle and relative normalization

At the third vertex F use one B port and one x port. The
other vertices are the actual cubic gauge kinetic vertex
and scalar–auxiliary mixing of block s. The cycle consists
of one B–Lambda edge, one ordinary B–B edge, and one scalar
edge. This is the unique triangle for these chosen vertices.
A double link from the mixing to F would instead put a
two-vertex cycle and tree in the inherited sewing. All
contributions from the two B and two x slots at F belong
to its mixed Hessian. The opposite loop traversal is the
second orientation, as in the V919 normalization.

Use P=p², with momentum p entering the mixed B leg, -p
entering the other internal B leg, and zero on the external
B. The raw physical gauge action has cubic coefficient
-g f_(abc) (partial_mu B_nu^a) B^(b,mu) B^(c,nu).
Taking its Hessian and summing the two derivative slots
gives i g f_(abc) V_(mu nu alpha) B^(c,alpha) with

    V_(mu nu alpha)=2 p_alpha eta_(mu nu)
                    -p_mu eta_(nu alpha)-p_nu eta_(alpha mu).
    p^mu V_(mu nu alpha)=p_nu p_alpha-P eta_(nu alpha).

This is -i g V times [T_a,B] in the second color slot,
since f_(abc)=-f_(bac). The scalar cubic Hessian in the
same mixed B orientation is -i g p_mu rho_a x. The mixed
line contributes +ip^mu/P. The ordinary gauge inverse is

    G_BB=(-eta^(-1)+(1-w) p p^t/P)/P.

Consequently the longitudinal width term drops and the
contracted gauge Hessian and its B–B propagator supply
+P_T/P with P_T the transverse projector, relative to
the scalar +1/P. Reversing momentum reverses each odd
factor and keeps the same net sign. The common loop
orientation factor and Wick convention are those fixed
by the V882 calibration used in V919. They apply to both
bosonic triangles. The remaining scalar denominator and
the leading 1/P give a logarithmic symbol. Its angular
average is (D-1)/D times the identity. At D=4 the gauge
coefficient is therefore -2 (3/4) J_s. No ordinary gauge
width changes this ratio. A finite shift proportional
to the four-dimensional residue does not identify first
dimension jets or finite parts of the two kernels.

Let the scalar triangle finite weight be the V919
number -(2 C_s-8)L_s/(2 C_s). The gauge triangle needs
4/3 times that weight. These are constant factors at
fixed contracted species and derivative slots, with the
same block and orientation conventions as the scalar
triangle. Together the chosen local shifts give exactly
sigma³ D_(u_s) F with u_s=g² xi(2 C_s-8)L_s v_s.
Equal scalar and gauge weights fail already on b=0,
leaving S_s/4 in the projected contraction. The calculation
fixes this relative coefficient at the local residue level.
Whether the entire finite map meets all normalization and
Ward conditions remains separate.

## Retained sources and boundary of this comparison

The complete unprobed V879 source polynomial has no retained
source term with Bx, Lambda x, BB or xx ordinary ports. The
literal census covers 24,330 retained-source words, including
12,560 single-scalar terms. Thus substituting a retained-source
vertex directly into either of these specified triangles gives
zero. It does not remove the V916 scalar-source correction
or a derivative of the master insertion.

This completes the derivative-free gauge–scalar kinetic
projection of the two-kernel proposal. Local background
covariance with varying test parameter still uses the
derivative kinetic companion, and a changed kernel must
be evaluated on every matching admissible operator and
source/mark direction. Other loop topologies, including
ghost cycles, are outside this projection. The native and
replay checks share the frozen action and symbolic software.
No new physical parameters, soft amplitudes or authority.
