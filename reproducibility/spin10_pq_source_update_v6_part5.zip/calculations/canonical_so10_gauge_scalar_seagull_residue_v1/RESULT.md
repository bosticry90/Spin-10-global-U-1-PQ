# V920 result

The actual cubic-gauge triangle supplies the gauge orbit term
missing from the V919 scalar triangle on the physical B²x²
kinetic vertex. Its hard tensor is transverse, so the angular
factor is 3/4 at four dimensions for any ordinary gauge width.
The two local finite residue shifts with linked weight ratio
4/3 then give the complete seagull translation at switch degree
three. This relation concerns the local four-dimensional residues.

The actual color controls have nonzero separate triangles on
unbroken external colors and zero sum. A sign reversal, omission
or equal weights leaves a nonzero residue. The joined f calculation
and representation-commutator replay also give the nonzero target
on broken colors. The unprobed retained-source port census finds
no direct replacement of any vertex in these two triangles.
Differentiated master/source and derivative kinetic directions
still require their own comparison.

This verifies the derivative-free projection of a candidate
finite map. The full local Ward and normalization conditions
remain open. Native and replay share the action, convention and
symbolic software. No physical parameter or authority change.
