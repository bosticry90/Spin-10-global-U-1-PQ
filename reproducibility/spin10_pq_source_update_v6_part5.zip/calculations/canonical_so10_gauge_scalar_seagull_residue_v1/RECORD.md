# V920 pre-execution contract

Test whether the derivative-free physical B²x² kinetic vertex
can be translated by the V919 scalar triangle and the additional
actual cubic-gauge triangle with the same scalar–auxiliary mixing.
Use zero transfer for the logarithmic local symbols, the actual
physical Lorentz sign and both orientations. Check whether width
and the V919 scalar weight alone can give the missing gauge orbit
term. Compare both projected hard kernels before selecting linked
finite weights. Do not infer equality of the entire products.

Require the global color covariance argument for the whole
seagull, direct joined f/rho arithmetic with a commutator replay,
and unbroken and broken color controls. The admissible proposal
must use field-independent coefficients at the specified
contracted species and jets, no inverse physical couplings and
no new mass values. Census direct replacements by unprobed retained-source vertices.
A correction applied to other derivatives or
sources must still satisfy their Ward identities. Limit to
the derivative-free seagull projection and its actual local
graph kernels. No authority change or full loop inference.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
