"""Exact color and Lorentz checks for the two seagull residue carriers."""

from collections import defaultdict
import gzip
from itertools import permutations, product
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


COLORS = range(45)
BLOCKS = {"Phi": (0,54,sp.Integer(10)), "Sigma": (54,306,sp.Rational(25,2))}


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def unpack(cells):
    value = 0
    basis = (sp.sqrt(2), sp.sqrt(3), sp.sqrt(5), sp.sqrt(7), sp.I)
    for (g, xi, eta, mask), num, den in cells:
        assert (g, xi, eta) == (0,0,0)
        value += sp.Rational(num,den)*sp.prod(b for i,b in enumerate(basis) if mask & (1 << i))
    return value


def dot(left,right):
    return sp.expand(sum(value*right.get(i,0) for i,value in left.items()))


def apply(matrix, vector):
    output = defaultdict(lambda:sp.S.Zero)
    for j, value in vector.items():
        for i, coefficient in matrix.get(j,()):
            output[i] += value*coefficient
    return {i:sp.expand(v) for i,v in output.items() if sp.expand(v)}


def axpy(output, alpha, vector):
    for i,value in vector.items():
        output[i] += alpha*value


def action_of_bracket(rho, bracket, a,b,vector):
    out = defaultdict(lambda:sp.S.Zero)
    for c,coefficient in bracket.get((a,b),()):
        axpy(out,coefficient,apply(rho[c],vector))
    return out


def commutator(rho,a,b,vector):
    out = defaultdict(lambda:sp.S.Zero)
    axpy(out,1,apply(rho[a],apply(rho[b],vector)))
    axpy(out,-1,apply(rho[b],apply(rho[a],vector)))
    return out


def color_checks(phase):
    role = "primary" if phase == "native" else "replay"
    path = ROOT/"calculations/canonical_so10_physical_current_input_recovery_g1_v1"
    data = read(path/("native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"))
    frame = read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    vacuum = {x:sp.sympify(v) for x,_,v in frame["vacuum"]["VEV"]["entries"]}
    rho = {}
    for a,rows in data["rho"]:
        columns = defaultdict(list)
        for i,j,cells in rows:
            columns[j].append((i,unpack(cells)))
        rho[a] = columns
    bracket = defaultdict(list)
    for (c,a,b),cells in data["f"]:
        bracket[a,b].append((c,unpack(cells)))
    result = {}
    for name,(start,stop,casimir) in BLOCKS.items():
        v = {i:c for i,c in vacuum.items() if start <= i < stop}
        orbit = {a:apply(rho[a],v) for a in COLORS}
        vectors = {}
        for b in COLORS:
            scalar,gauge = 0,0
            for a in COLORS:
                if not orbit[a]:
                    continue
                y = apply(rho[b],orbit[a])
                from_f = action_of_bracket(rho,bracket,a,b,v)
                from_commutator = commutator(rho,a,b,v)
                assert all(sp.expand(from_f.get(i,0)-from_commutator.get(i,0)) == 0
                           for i in from_f.keys() | from_commutator.keys())
                if phase == "native":
                    ad_v = from_f
                    ad_y = action_of_bracket(rho,bracket,a,b,orbit[a])
                else:
                    ad_v = from_commutator
                    ad_y = commutator(rho,a,b,orbit[a])
                scalar += dot(y,y)
                gauge += dot(ad_v,y)+dot(orbit[b],ad_y)
            target = casimir*dot(orbit[b],orbit[b])
            assert sp.expand(scalar+gauge-target) == 0, (name,b)
            if b in (0,1,12,17):
                vectors[str(b)] = [str(sp.expand(vv)) for vv in (scalar,gauge,target)]
            if b in (0,1):
                assert target == 0 and scalar != 0 and gauge != 0
                assert sp.expand(scalar+sp.Rational(3,4)*gauge) != 0
                assert sp.expand(scalar-gauge) != 0
        result[name] = vectors
    assert result["Phi"]["17"] == ["150","100","250"]
    assert result["Sigma"]["12"] == ["183/20","48/5","75/4"]
    return result


def lorentz_checks():
    # Derive the cubic gauge Hessian coefficient from its six action slots.
    # The sign factor is the permutation of the antisymmetric f; the
    # overall action density is -g f (partial_mu B_nu) B^mu B^nu.
    p = sp.Matrix(sp.symbols("p0:4"))
    eta = sp.diag(1,-1,-1,-1)
    P = (p.T*eta*p)[0]
    momenta = (p,-p,sp.zeros(4,1))
    lowers = [eta*q for q in momenta]
    for mu,nu,alpha in product(range(4),repeat=3):
        i = (mu,nu,alpha)
        action = 0
        for a,b,c in permutations(range(3)):
            inversions = (a>b)+(a>c)+(b>c)
            action -= (-1)**inversions*lowers[a][i[b]]*eta[i[a],i[c]]
        tensor = 2*lowers[0][alpha]*eta[mu,nu]-lowers[0][mu]*eta[nu,alpha]-lowers[0][nu]*eta[alpha,mu]
        assert sp.expand(action-tensor) == 0

    lower = eta*p
    transverse = eta-lower*lower.T/P
    vertex_contracted = lower*lower.T-P*eta
    width = sp.symbols("w")
    BB = (-eta+(1-width)*p*p.T/P)/P
    product_matrix = (vertex_contracted*BB).applyfunc(sp.cancel)
    target = (transverse*eta).applyfunc(sp.cancel)
    assert product_matrix == target
    assert (vertex_contracted*p).applyfunc(sp.expand) == sp.zeros(4,1)

    # Both vertices carry -i times their orbit direction. The gauge
    # denominator sign is already in BB, including its longitudinal piece.
    # Reversing momentum on the mixed edge reverses each odd factor.
    for orientation in (-1,1):
        assert (orientation*sp.I)*(-orientation*sp.I) == 1
    relative = sp.Rational(3,4)
    assert (sp.trace(product_matrix)/4).simplify() == relative
    return {"relative_gauge_weight":str(relative),"linked_finite_multiplier":str(1/relative),
            "gauge_raw_coefficient":str(-2*relative),"width_independent":True}


def source_ports(phase):
    root = ROOT/"calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = read(root/f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    count, with_scalar = 0,0
    for _,word,_ in rows:
        fields = [slot for slot,_ in word]
        if not any(643 <= slot < 1286 for slot in fields):
            continue
        count += 1
        scalar = sum(180 <= slot < 508 for slot in fields)
        gauge = sum(slot < 180 for slot in fields)
        auxiliary = sum(508 <= slot < 553 for slot in fields)
        with_scalar += bool(scalar)
        assert not (scalar and gauge or scalar and auxiliary or gauge >= 2 or scalar >= 2)
    assert (count,with_scalar) == (24330,12560)
    return {"retained_source_words":count,"single_scalar_words":with_scalar,
            "direct_replacements_for_selected_ports":0}


def check(phase):
    return {"color":color_checks(phase),"lorentz":lorentz_checks(),"source_ports":source_ports(phase)}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
