from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-current-inventory-g1-recovery-v1-2026-11-07')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_catalog_capture.json')).exists()
if not (O/'catalog_preparation.json').exists():
 prep=json.loads((O/'preparation.json').read_bytes());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==prep['base_HEAD']
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 pairs=[]
 for f in sorted(O.glob('native_*.json.gz')):
  peer=O/f.name.replace('native_','replay_',1);assert f.read_bytes()==peer.read_bytes(),f.name
  pairs.append(dict(native=f.name,replay=peer.name,sha256=digest(f)))
 assert len(pairs)==15
 inputs=dict(prep['input_sha256'])
 for p in O.glob('*_*.json*'):
  if p.name.startswith(('native_','replay_')):inputs[p.relative_to(R).as_posix()]=digest(p)
 for n in ['CATALOG_RECORD.md','catalogs.py','run_catalog.py']:
  with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
 dump(O/'catalog_preparation.json',dict(base_HEAD=prep['base_HEAD'],input_sha256=inputs,source_sha256={n:digest(O/n) for n in ['CATALOG_RECORD.md','catalogs.py','run_catalog.py']},paired_factory_math=pairs,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'catalogs.py'),route]);dump(O/(route+'_catalog_capture.json'),cap);dump(C/(route+'_catalog_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
