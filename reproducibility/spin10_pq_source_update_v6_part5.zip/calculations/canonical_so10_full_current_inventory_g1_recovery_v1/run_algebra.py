from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/full-current-inventory-g1-recovery-v1-2026-11-07')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'algebra_preparation.json').exists()
inputs=dict(json.loads((O/'catalog_preparation.json').read_bytes())['input_sha256'])
for p in O.iterdir():
 if p.is_file() and p.name.startswith(('native_','replay_')):inputs[p.relative_to(R).as_posix()]=digest(p)
for n in ['ALGEBRA_REVIEW_RECORD_V1.md','algebra_review.py','run_algebra.py']:
 with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
dump(O/'algebra_preparation.json',dict(input_sha256=inputs,source_sha256={n:digest(O/n) for n in ['ALGEBRA_REVIEW_RECORD_V1.md','algebra_review.py','run_algebra.py']}))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'algebra_review.py')]);dump(O/'algebra_review_capture.json',cap);dump(C/'algebra_review_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
