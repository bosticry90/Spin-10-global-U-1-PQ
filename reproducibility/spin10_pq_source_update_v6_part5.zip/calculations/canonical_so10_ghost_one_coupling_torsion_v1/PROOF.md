# A ghost-one class killed by g and its actual g0 exclusion

## Polynomial class in the uncut minimal family

Use the W2/W3 real translation-invariant finite-jet ring with the
original independent parameters, and the qualified unshifted minimal
differential. Write g=g10 and represent the real 54 by a symmetric
traceless matrix Phi. The actual field rule is Q Phi=−g[C,Phi]. Use
the numerical H-fixed tensor T=diag(−2 I6,3 I4), proportional to the
actual Phi singlet direction. All first twelve actual H columns of the
C3 map have support on planes within the two blocks and commute with
T. The remaining fixed tensor is a numerical contraction on the
allowed H module. It is held fixed under the Ward operation and is
not a new coupling or an adopted vacuum.

Define local densities

    f = (tr(T Phi))^4,
    a_T = −4 (tr(T Phi))^3 tr(T [C,Phi]).

Here g a_T=Q f is a polynomial identity, proved directly by the
actual field column. It uses coefficient extraction instead of
inverting g. The density f has (d_project,gh,p)=(4,0,0); a_T has
(5,1,1). Both are real in the qualified field frame and are PQ
neutral. From Qg=0 and Q^2=0, g Q a_T=0. Multiplication by the
independent even indeterminate g is injective on the polynomial
cochains, including the exterior coefficients. Therefore Q a_T=0
as a density. No injection claim on the resulting cohomology is used.

The scalar and ghost background action is homogeneous H conjugation.
Their transformation at each point commutes with contraction by T,
and there are no derivative slots on which parameter jets can act.
This gives local W_b a_T=0. Inserting an H ghost into a_T gives zero
by tr(T[C_H,Phi])=tr([T,C_H]Phi)=0, so this representative also passes
the classical H contraction. The geometric H action on these same
source-free slots has the same homogeneous test. These local checks
do not establish a quantum W5 contact normalization.

## Nonexactness with sources and ordinary currents allowed

Specialize g and all independent physical scalar potential parameters
to zero. Use the constant-jet evaluation at B=Abar=0, all sources
and nonminimal fields zero, and all positive jets zero. Retain the
constant traceless X=T+E06+E60 and a single odd generator vartheta
times C06=(E06−E60)/sqrt(2). This evaluation is on the translation-
invariant differential algebra. It does not impose an infrared limit
or make an assertion about compact test functions being constant.

The field images in the uncut minimal chart are Q_0 B=partial C and
Q_0 Phi=Q_0 C=0. The other scalar images vanish as well. Physical
source columns reduce to the free Maxwell or scalar Eulers plus terms
linear in source jets or with positive g. All vanish at this evaluation
because the positive jets, physical potential coefficients and sources
vanish. The ghost source column has only the source divergence at
g=0. The independent nonminimal doublets have zero images at the
same point. These are the exact generator types from the full
classical column and regularity owners. The result extends to their
ordinary prolongations. All ordinary total divergences evaluate to
zero since their coefficients have no explicit spacetime coordinates.
In particular evaluating any source-dependent polynomial primitive
does not require first dropping the source columns of Q.

By direct matrix contraction tr(T X)=60 and
tr(T[C06,X])=−5 sqrt(2). Hence a_T evaluates to
+4,320,000 sqrt(2) vartheta. Independently the actual C3 map sends
the normalized plane ghost to parent columns 15,18,39,42 with
coefficients (−1,+1,+1,−1)/4. The frozen Phi coordinates of T are
the four nonzero VEV direction entries, and X adds sqrt(2) at slot 5.
Evaluating the actual g-linear source-derived Q Phi columns at those
coordinates gives tr(T[Q Phi]_{g^1})=+5 sqrt(2) vartheta and the same
a_T. This rules out a polynomial identity a_T=Q l+div k even in the
unrestricted primitive language, hence also with joint H or basic
restrictions. E2's polynomial canonical map U and its prolongation
fix the original fields and commute with ordinary differentiation.
They fix a_T and f, so a primitive in the gauge-fixed chart would pull
back to a forbidden primitive here. The physical scalar reference
masses belong to the compact loop expansion, not this classical
evaluation.

The class is nonzero and killed by multiplication by g. At a fixed
nonzero g the primitive f/g would remove it. The usual semisimple
classification at fixed coupling therefore cannot supply polynomial
exactness across the free specialization. The cubic representation
anomaly screen is a different calculation and still holds in its
declared scope. This inference concerns application of the published
fixed-theory result to this ring. [Local BRST cohomology in gauge
theories, sections 11–13](https://arxiv.org/abs/hep-th/0002245).

## Actual unprobed g0 family

For this separate calculation keep every physical scalar potential
parameter. At unprobed g0 with rho=theta=0, the five physical kinetic
ASTs reduce to the free gauge curvature and ordinary scalar kinetic
blocks. The 29 potential terms use only scalars. The entire scalar
Hessian may mix scalar directions and still has no gauge, source or
ghost port. The portable GF and field-rule packet has no scalar or
scalar-source incidence at g0. The two V865 routes have 1,278 complete
g0 GF/source rows without scalar or scalar-source incidences. The
width-dependent cubic terms are present in the gauge/ghost block.
V869's relative reference vertices have positive g and drop at g0.
The source-free flat reference is block diagonal with its original
scalar masses and gauge/auxiliary/ghost profiles.

Consequently in this specific compact prescription P=P_S+P_G and
B[P]=B[P_G], including the switch jets. The scalar source Euler is
zero, and none of the gauge/ghost Eulers acts on P_S. The same split
holds after adding beta B. At fixed coefficient each Hessian word
and every subtraction, inverse or paired reference insertion stays
in one block. The trace functional and its heat and finite local
conversion parts are additive on the two blocks. The linear b
contracts within the same block. Connected trees and forests cannot
join the blocks because their vertices and propagators stay in one.
Keep the common source-independent free factor and any separately
retained reference determinant. Neither changes this source test.
This proves that the scalar-dependent part of the actual g0 master
breaking vanishes in this normalized unprobed family, including the
C Phi^4 coefficient of the proposed class. No nonzero amplitude
of a_T is inferred from its algebraic existence.

This exclusion is about the computed prescription and its g0
coefficient. General finite counterterms can mix the blocks and
change an exact representative. The check does not classify all
ghost-one classes, terms invisible at the chosen specialization or
actual first breakings at higher g. The more consequential next
gate is the unprobed common family through every fixed finite g
degree, using the full actual source and GF inputs and proving the
metric/first-dimension-jet bounds for those degrees before expanding
new amplitudes. Full A3 and E5 remain open.
