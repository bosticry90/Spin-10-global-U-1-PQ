# V878 V2 typed scalar-source label adapter

The first worker completed the plane witness and raw g0 checks, then
stopped at literal name equality across the raw and joined charts.
Both have the same 328 scalar field names. The raw map calls the paired
source Jx_sector_i and the joined chart calls it J_x_sector_i. V2 checks
every actual pair with the explicit J-to-J_ name adapter, the 643-slot
source offset and complementary parities. Preserve both source arrays,
the exact first run and all original scientific checks. The change does
not modify a field, source sign, invariant, grade or admissibility test.
