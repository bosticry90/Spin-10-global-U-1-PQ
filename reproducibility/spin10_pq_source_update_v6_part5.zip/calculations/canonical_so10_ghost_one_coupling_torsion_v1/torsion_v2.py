"""Exact plane/source witness and g0 scalar-incidence check."""

import gzip
import json
import sys
from collections import Counter
from functools import lru_cache
from itertools import combinations

import sympy as sp

from execute_v2 import PK, ROOT, read, run_worker


PHYSICAL = PK / "frozen_a10_physical_reconciliation"
V865 = ROOT / "calculations/canonical_so10_joint_common_family_applicability_v1"
PLANES = tuple(combinations(range(10), 2))
g = sp.Symbol("g10")


def load_gzip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


@lru_cache(None)
def exact(text):
    return sp.sympify(text)


def matrix(packet):
    return sp.SparseMatrix(*packet["shape"], {(i, j): exact(value) for i, j, value in packet["entries"]})


def plane(i):
    a, b = PLANES[i]
    return sp.SparseMatrix(10, 10, {(a, b): 1 / sp.sqrt(2), (b, a): -1 / sp.sqrt(2)})


def support(portable, role):
    names = portable["geometry"]["names"]
    scalar_pairs = [(names[i], names[j]) for i, j, _, _ in portable["geometry"]["field_source_h_k"]
                    if names[i].startswith("x_")]
    assert len(scalar_pairs) == 328
    scalar_fields = {z for z, _ in scalar_pairs}
    excluded = {name for pair in scalar_pairs for name in pair}

    def independent(word):
        return all(atom.split("__", 1)[0] not in excluded for atom in word)

    gf = [row for row in portable["gauge_fixing_density"] if exact(row["coefficient"]).subs(g, 0) != 0]
    assert len(gf) == 734 and all(independent(row["word"]) for row in gf)
    flows = portable["master_field_maps"]
    assert len(flows) == 643
    active = [(name, row) for name, rows in flows.items() for row in rows if exact(row["coefficient"]).subs(g, 0) != 0]
    assert len(active) == 225 and len({name for name, _ in active}) == 225
    assert all(name not in scalar_fields and independent(row["word"]) for name, row in active)
    assert any(flows[n] for n in scalar_fields)

    chart = load_gzip(V865 / f"{role}_complete_full_background_extension.json.gz")
    joined = chart["joined_names"]
    indexed = set(range(180, 508)) | set(range(823, 1151))
    locations = {name: i for i, name in enumerate(joined[180:508], 180)}
    assert set(locations) == scalar_fields
    for field, raw_source in scalar_pairs:
        i = locations[field]
        assert raw_source == "J" + field and joined[i + 643] == "J_" + field
        assert chart["joined_parities"][i] == 0 and chart["joined_parities"][i + 643] == 1
    rows = chart["complete_S_GF_source"]
    grade0 = [(word, cells) for grade, word, cells in rows if grade == 0]
    assert len(grade0) == sum(len(cells) for _, cells in grade0) == 1278
    assert all(not (indexed & {i for i, _ in word}) for word, _ in grade0)
    assert any(grade > 0 and indexed & {i for i, _ in word} for grade, word, _ in rows)
    degree = Counter(len(word) for word, _ in grade0)
    assert degree == {2: 678, 3: 600}
    return {"raw_gf_g0_rows": len(gf), "raw_g0_field_columns": len(active), "scalar_pairs": len(scalar_pairs),
            "current_g0_GF_source_rows": len(grade0), "current_g0_GF_source_cubic_rows": degree[3],
            "scalar_incidence_raw_and_current_g0": 0, "positive_grade_scalar_control": True}


def witness(portable, role):
    physical = read(PHYSICAL / f"full_{'primary' if role == 'native' else 'replay'}.json")
    parent = matrix(physical["C3_plane_to_parent"])
    H = parent[:, :12]
    assert H.rank() == 12
    H_support = [row for row in physical["C3_plane_to_parent"]["entries"] if row[1] < 12]
    assert len(H_support) == 43
    assert all((PLANES[i][0] < 6) == (PLANES[i][1] < 6) for i, _, _ in H_support)
    index = PLANES.index((0, 6))
    plane06 = sp.eye(45)[:, index]
    assert H.T * plane06 == sp.zeros(12, 1)
    coeffs = {15: -sp.Rational(1, 4), 18: sp.Rational(1, 4), 39: sp.Rational(1, 4), 42: -sp.Rational(1, 4)}
    c_parent = sp.SparseMatrix(45, 1, {(i, 0): value for i, value in coeffs.items()})
    assert parent * c_parent == plane06

    T = sp.diag(*([-2] * 6 + [3] * 4))
    X = T + sp.SparseMatrix(10, 10, {(0, 6): 1, (6, 0): 1})
    assert X == X.T and sp.trace(X) == 0
    if role == "native":
        for h in range(12):
            gen = sum((H[i, h] * plane(i) for i in range(45) if H[i, h] != 0), sp.zeros(10))
            assert gen * T - T * gen == sp.zeros(10)
        contraction = sp.trace(T * X)
        q_phi = -sp.trace(T * (plane(index) * X - X * plane(index)))
    else:
        basis = read(PK / "frozen_action_ast_a3/A31_embeddings.json")["sectors"]["Phi"]
        E = sp.SparseMatrix(100, 54, {(i, j): exact(c) for i, j, c in basis["embedding_entries"]})
        metric = sp.diag(*map(exact, basis["tensor_metric_diagonal"]))
        t = E.T * metric * T.reshape(100, 1)
        x = E.T * metric * X.reshape(100, 1)
        assert E * t == T.reshape(100, 1) and E * x == X.reshape(100, 1)
        assert t == matrix(physical["vacuum"]["VEV"])[:54, :]
        assert x - t == sp.sqrt(2) * sp.eye(54)[:, 5]
        rho = physical["representation_matrices"]["Phi"]
        for h in range(12):
            row = sum((H[i, h] * (t.T * matrix(rho[i])) for i in range(45) if H[i, h] != 0), sp.zeros(1, 54))
            assert row.applyfunc(sp.expand) == sp.zeros(1, 54)
        contraction = sp.expand((t.T * x)[0])
        fields = {f"x_Phi_{i}": x[i] for i in range(54) if x[i] != 0}
        ghosts = {f"C{i}": value for i, value in coeffs.items()}
        for name, value in ghosts.items():
            assert name not in fields and value != 0
        values = fields | ghosts
        q_phi = sp.Integer(0)
        flows = portable["master_field_maps"]
        for i in range(54):
            if t[i] == 0:
                continue
            for row in flows[f"x_Phi_{i}"]:
                word = row["word"]
                if all(atom in values for atom in word):
                    assert sum(atom in ghosts for atom in word) == 1
                    q_phi += t[i] * sp.expand(exact(row["coefficient"])).coeff(g) * sp.prod(values[atom] for atom in word)
        q_phi = sp.expand(q_phi)
        assert q_phi == -sp.expand((t.T * matrix(rho[index]) * x)[0])
    assert contraction == 60 and q_phi == 5 * sp.sqrt(2)
    result = sp.expand(4 * contraction**3 * q_phi)
    assert result == 4320000 * sp.sqrt(2)
    return {"actual_H_columns": 12, "stored_H_entries_all_within_blocks": len(H_support),
            "tr_TX": str(contraction), "tr_T_QPhi_g1": str(q_phi), "a_T_odd_coefficient": str(result),
            "broken_plane": list(PLANES[index]), "raw_C3_ghost": {str(i): str(c) for i, c in coeffs.items()}}


def checks(role):
    data = load_gzip(ROOT / "tools/portable_dh_v1/inputs.json.gz")
    return {"specialized_class": witness(data, role), "g0_split": support(data, role)}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
