# V878 a named ghost-one polynomial class and actual g0 exclusion

The real H-fixed scalar direction T gives a closed ghost-one density
a_T with g a_T=Q (tr(T Phi))^4. The constant-jet specialization
annihilates every Q image and divergence and leaves a_T nonzero.
The actual normalized plane calculation and the frozen source-column
evaluation agree on +4,320,000 sqrt(2) times the odd ghost generator.
The local H test and its contraction pass. This establishes a named
nonexact class killed by g over the admitted polynomial ring.

The actual unprobed compact g0 common family splits between the
scalar and gauge/ghost/source sectors. The raw input has 734 g0 GF
rows and 225 g0 field columns with no scalar incidence. Both V865
charts have 1,278 g0 GF/source rows with zero scalar or scalar-source
incidence, including the 600 cubic rows. The block-preserving trace,
correction and forests therefore exclude scalar-dependent g0 master
breakings in that selected prescription. All physical scalar potential
parameters remain in this second argument.

The first run stopped on the raw versus joined source name format.
V2 explicitly pairs all 328 scalar sources with the typed offset and
parity check. The original source and failed capture are preserved.
Read [PROOF.md](PROOF.md) and the separate review receipt and capture.
The class identifies a limitation of applying a fixed-coupling
semisimple result across g=0. It supplies no actual anomaly amplitude,
full cohomology classification or broader A3 acceptance.
