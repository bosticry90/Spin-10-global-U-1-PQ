# V878 ghost-one coupling-ring test and actual g0 exclusion

Start at V877 `1739ed39` on main, D:. Test whether fixed-coupling
semisimple anomaly information can establish polynomial exactness in the
W2/W3 and background Ward domain. Separately test whether the actual
unprobed compact common family can produce the proposed scalar-dependent
g0 head. These are different questions with different evidence.

Use the exact unshifted gauge/scalar minimal complex, ordinary finite
jets without explicit coordinates, real Lorentz densities, independent
polynomial physical parameters, no inverse g or masses, and the actual
local H operation. PQ is global and Phi54 is neutral. Freeze the
H-fixed T=diag(−2 I6,3 I4), F=(tr(T Phi))^4, and candidate obtained by
coefficient extraction from QF. In the nonexactness test use the
g=0/all-potential-parameters-zero specialization, Phi=T+E06+E60,
one odd normalized real 06-plane ghost and zero other constant fields
and positive jets. Retain every primitive source slot in the argument.
This specialization is an algebra map, separate from the unprobed
compact quantum family with its general scalar potential intact.

Native uses the normalized plane commutator and the actual C3 H map.
Replay uses the frozen scalar coordinates and actual source-map rows.
Check closure and joint H/horizontal scope structurally, an exact
nonzero normalized coefficient, source-dependent primitive coverage
and both g0 parent routes. Include the full width-dependent g0 GF rows
and guard against a false Gaussian reduction. Authenticate the existing
physical and reference splitting proofs and apply them to the same
correction and forest. No off-block scheme or arbitrary finite mixing
is assumed to satisfy that splitting.

Worker and final review limits are 120 and 180 seconds, 8 GiB sampled
private memory, 350 MiB launch floor, 8 MiB per artifact and 32 MiB
packet. Final E4 retains the 120-second subprocess bound, expected
step exits [0,0,0,0,0,2] and seven unresolved custody references.
Preserve any failed comparison. Success can establish a named
polynomial obstruction to a theorem shortcut and a zero actual g0
scalar-dependent breaking in the selected split prescription. It
cannot establish a realized anomaly, general restoration, physical
viability, protected acceptance or an enlarged coupling ring.
