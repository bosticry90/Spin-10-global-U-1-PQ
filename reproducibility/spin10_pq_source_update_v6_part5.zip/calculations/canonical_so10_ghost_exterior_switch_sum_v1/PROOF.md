# Summing the exterior ghost switches

Use the V894 color-12 lifted V883 group with its actual
vertex weights, normalized proper kernels and massive scalar
feedback. Here sum every exterior ghost quadratic switch
in the Euclidean continuum after the common UV conversion.
The internal switch-only insertions are separate. This
increment tests whether the exterior ghost inverse alone
can cancel the transition contribution.

## Actual switched ghost inverse and choice of switch

In ordered C,a coordinates the free density is
−(partial C)(partial a), and the switch-only contribution
is −(Delta sigma) C a/2, as in V880 and V894. Thus the
operator between C and a is minus K_sigma, where

    K_sigma=−Delta+(Delta sigma)/2.

The two orientations of the inverse carry the usual
opposite signs. The external sources are unswitched.
In this computation all exterior insertions are the
Neumann series of this actual inverse, formed only after
the common UV subtraction. The local counterterms on the
proper core and the regular massive feedback stay fixed.

Let b be smooth nonincreasing, equal to one for t≤0,
zero for t≥1 and strictly between zero and one on an
interval of positive length. Choose
chi(r)=b(log r / ell), with chi(0)=1 and ell positive.
This gives compact smooth radial plateau switches
sigma_R(x)=chi(|x|/R). Define V=Delta chi/2. In four
dimensions the radial formula gives

    r² V=b'/ell+b''/(2 ell²).

Take ell large enough that its supremum in absolute
value is bounded by nu<1. Four-dimensional Hardy
inequality then gives |<u,V u>|≤nu||grad u||².
For completeness this Hardy inequality follows by
expanding the nonnegative integral of
|grad u+(x/|x|²)u|² and integrating its cross term.
The polarized bound also follows by weighted
Cauchy–Schwarz with |x|^-2 and Hardy. Thus K_chi is
coercive on the homogeneous H¹ form space and the
free-inverse form Neumann series converges. The same
nu bound applies to every dilation R. This proves the
sum of all exterior insertions for Schwartz sources
in this Euclidean sector without a perturbative
expansion in the width of the transition.

## Delta source scaling and the Green function

For an ordinary source j Schwartz, put
u_R(y)=R² (K_sigma_R^-1 j)(R y) and j_R(y)=R⁴ j(Ry).
Then K_chi u_R=j_R. Let G0(y)=1/(4 pi² |y|²).
The actual Green function at zero is defined as

    G_chi(.,0)=G0−K_chi^-1(V G0).

The singular delta source itself need not be in the
dual form space. V G0 is smooth compact since V
vanishes near zero. The analogous construction
with G0(.-y) gives Green sources for y near zero.
For Schwartz j the formula is
u_R=G0*j_R−K_chi^-1[V(G0*j_R)]. On any compact
annulus away from zero, G0*j_R tends smoothly to
J G0 with J=integral j. Split the source near zero
and its rapid tails. The near part uses smooth
derivatives of G0 at separated points. For the
tail, local convolution with the integrable
singularity and the rapid seminorm bounds control
all derivatives, by moving derivatives onto j_R
there. Multiplication by V gives convergence in
L^(4/3), and K_chi^-1 takes this to H¹ homogeneous
and L⁴. Interior elliptic estimates away from
zero then give smooth convergence of the correction
on the compact transition region. Thus u_R tends
to J G_chi there, with all seminorms needed on
the support of the transition and its derivatives.

## Positive lower bound for the transition term

Write w=exp(chi/2), W=|grad chi|²/4. Direct
differentiation gives

    (K_chi+W)(w f)=−w^-1 div(w² grad f).

In radial variables the unit delta Green function
of K_chi+W is

    U_+(r)=w(0) w(r)/(2 pi²) integral_r^infty ds/[s³ w(s)²].

The normalization follows from the radial flux,
and w is constant near the origin. Since chi is
nonincreasing, w(s)²≤w(r)² for s≥r. Consequently
U_+(r)≥exp((1−chi(r))/2) G0(r)≥G0(r).
The inverse of K_chi preserves positivity for
real nonnegative sources in its form domain.
Testing with the negative part gives this from
coercivity. The compact W U_+ is in the dual form
space. Both singular Green functions have the
same G0 singularity, so uniqueness in the form
space gives G_chi=U_++K_chi^-1(W U_+)≥U_+.
This avoids assuming pointwise closeness from a
small norm bound on V.

For h=chi²(1−chi), the local term from V894 paired
with the two dressed sources therefore tends to

    m_12 J_a J_C integral h(y) G_chi(y,0)² dy

in the stripped proper sign, with the inherited
minus in the ordered connected ghost coefficient.
The scaling R^4 of the volume cancels the two
R^-2 roots. The integral is strictly positive,
and at least the V894 bare exterior value for
the same switch shape. In particular summing the
exterior ghost switches cannot cancel the transition
term in this sector. Its coefficient is unbounded
as a function of the allowed log width ell, taken
after each fixed-shape R limit. Indeed
integral h/|x|^4=2 pi² ell integral_0^1 b²(1−b) dt,
while the lower Green bound is independent of ell.

## Nonconstant pieces of the lifted group

In the free inverse representation the new root
is G0(p) times jhat(p) minus the Fourier transform
of V_sigma_R K_sigma_R^-1 j. The latter transform
is wide-variable Fourier(V u_R)(R p). Because
V is fixed compact and u_R has uniform smooth
bounds on its support, this root correction is
O((1+R|p|)^-N) for every fixed N. The graphwise
transfer errors of V894 thus still go to zero
against the dressed roots. The root numerators
are uniformly bounded and rapidly decreasing
at large p, which suffices for the two-root log
bound there. For the remaining nonconstant
core, V883 gives the factor p²(1+|log p²|).
A term with at least one new root numerator is
localized at p=O(1/R) or p+K=O(1/R). Scale that
momentum and the independent switch transfers.
The p² gain and the two simple roots bound this
difference by O(R^-2(1+log R)) with integrable
powers and logs in the scaled variables. For
example, when the new numerator is on p, the
p² cancels its own pole and leaves a translated
inverse square times a localized logarithm.
On the other root, shift p by K to obtain the
same local-integrability bound, with Schwartz
switch transfers. The original nonconstant
V894 group therefore has its ordinary uncut
limit also after summing the exterior switches.

These are the Euclidean lifted group and the
exterior inverse for the specified radial shapes.
Internal ghost, gauge and scalar switch insertions,
new switched paths and the Lorentzian common limit
still require evidence. No adjustment of the
V882 common normalization is made. The exact
controls and proof share the action, reference
data, software and AI authorship.
