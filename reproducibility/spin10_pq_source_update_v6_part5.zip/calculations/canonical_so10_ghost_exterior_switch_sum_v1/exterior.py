"""Bound the actual exterior ghost inverse in the radial switch test."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def actual(owner, role, suffix):
    path = ROOT/"calculations"/("canonical_so10_"+owner)/(role+suffix)
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        return json.load(stream)


def ghost_operator(role):
    current = actual("unprobed_compact_all_coupling_v1",role,"_full_current.json.gz")["current"]
    rows = [row for row in current["complete_S_GF_source"]
            if row[0] == 0 and {n for n,_ in row[1]} == {565,610}]
    assert rows == [[0,[[565,[mu]],[610,[mu]]],[[[0,0,0],-1,1]]] for mu in range(4)]
    inverse = actual("regulator_free_inverse_g1_recovery_v1",role,"_inverse.json.gz")
    q = sp.symbols("q0:4")
    P = sum(v*v for v in q)
    K = {(i,j):sp.sympify(v) for i,j,v in inverse["Preference"] if i in (565,610) and j in (565,610)}
    G = {(i,j):sp.sympify(v) for i,j,v in inverse["Greference"] if i in (565,610) and j in (565,610)}
    assert K == {(565,610):-P,(610,565):P}
    assert G == {(565,610):1/P,(610,565):-1/P}
    t = sp.Symbol("t")
    C,a,sigma = (sp.Function(n)(t) for n in ("C","a","sigma"))
    # C-first jet identity and the integrated derivative in C.
    diff = -C.diff(t)*a.diff(t)-(C*a.diff(t,2)+C.diff(t,2)*a)/2
    assert sp.expand(diff+(C*a).diff(t,2)/2) == 0
    lag = sigma*diff
    euler = sp.diff(lag,C)-sp.diff(sp.diff(lag,C.diff(t)),t)+sp.diff(sp.diff(lag,C.diff(t,2)),t,2)
    assert sp.expand(euler+sigma.diff(t,2)*a/2) == 0
    return {"ordered_Ca_inverse_sign":1,"ghost_switch_potential_factor":"1/2"}


def radial_green(role):
    r = sp.Symbol("r",positive=True)
    ell = sp.Symbol("ell",positive=True)
    t = sp.Symbol("t",real=True)
    b = sp.Function("b")(t)
    chi = b.subs(t,sp.log(r)/ell)
    profile_V = (chi.diff(r,2)+3*chi.diff(r)/r)/2
    expected = (b.diff(t)/ell+b.diff(t,2)/(2*ell**2)).subs(t,sp.log(r)/ell)
    assert sp.simplify(r*r*profile_V-expected) == 0
    x = sp.Function("chi")(r)
    V = (x.diff(r,2)+3*x.diff(r)/r)/2
    f = sp.Function("f")(r)
    w = sp.exp(x/2)
    W = x.diff(r)**2/4
    if role == "native":
        wf = w*f
        transformed = -wf.diff(r,2)-3*wf.diff(r)/r+(V+W)*wf
        divergence = -(r**3*w*w*f.diff(r)).diff(r)/(r**3*w)
        assert sp.simplify(transformed-divergence) == 0
    else:
        form = r**3*((w*f).diff(r)**2+V*(w*f)**2)
        transported = r**3*w*w*(f.diff(r)**2-W*f*f)
        current = r**3*w*w*x.diff(r)*f*f/2
        assert sp.simplify(form-transported-current.diff(r)) == 0
    s = sp.Symbol("s",positive=True)
    w0 = sp.Symbol("w0",positive=True)
    F = w0*sp.Integral(1/(s**3*w.subs(r,s)**2),(s,r,sp.oo))/(2*sp.pi**2)
    assert sp.simplify(2*sp.pi**2*r**3*w*w*F.diff(r)) == -w0
    G0 = sp.integrate(s**-3,(s,r,sp.oo))/(2*sp.pi**2)
    assert G0 == 1/(4*sp.pi**2*r**2)
    # Monotonicity permits w(s)^2 <= w(r)^2 under the flux integral.
    lower = sp.simplify(w*G0*w0/(w*w))
    assert sp.simplify((lower/G0).subs(w0,sp.exp(sp.Rational(1,2)))-sp.exp((1-x)/2)) == 0
    return {"hardy_radial_potential":"b'/ell+b''/(2*ell^2)",
            "green_lower_ratio":"exp((1-chi(r))/2)",
            "annulus_integral_growth":"at_least_linear_in_ell"}


def root_scaling():
    R,r = sp.symbols("R r",positive=True)
    u = sp.Function("u")(r)
    V = sp.Function("V")(r)
    y = sp.Symbol("y",positive=True)
    source = sp.Function("j")(r)
    rescaled = R**2*u.subs(r,R*y)
    K = -rescaled.diff(y,2)-3*rescaled.diff(y)/y+V.subs(r,y)*rescaled
    original = -u.diff(r,2)-3*u.diff(r)/r+V.subs(r,r/R)*u/R**2
    assert sp.expand(K-R**4*original.subs(r,R*y)) == 0
    assert sp.simplify(R**4*R**-2*R**-2) == 1
    assert sp.simplify(source.subs(r,R*y)*R**4).has(R)
    return {"rescaled_source_power":4,"transition_net_power":0,
            "nonconstant_gain_power":-2}


def checks(role):
    return {"operator":ghost_operator(role),"radial":radial_green(role),"scale":root_scaling()}


if __name__ == "__main__":
    run_worker(checks,sys.argv[1])
