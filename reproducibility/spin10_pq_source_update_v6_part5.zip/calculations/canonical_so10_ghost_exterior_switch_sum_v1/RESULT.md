# V895 — Exterior ghost switches leave the transition term

The actual Euclidean ghost operator with a compact switch
is K_sigma=−Delta+(Delta sigma)/2 in the inherited ordered
pairing. A sufficiently wide logarithmic radial plateau
gives a coercive form by Hardy inequality. The inverse
sums every exterior switch insertion, uniformly in the
dilation radius for each fixed switch shape.

The rescaled sourced inverse converges on the transition
region to the radial Green function. The ground-state
transform and the radial flux give
G_chi(r,0)≥exp((1−chi(r))/2)/(4 pi² r²)≥G0(r).
Thus the local transition coefficient after the full exterior
sum has at least the bare magnitude for these switches.
It is nonzero for m_12 and the two zero-momentum sources
nonzero, and its magnitude grows at least linearly along the
admissible family of logarithmic widths. The nonconstant
terms still have their ordinary uncut limit.

Require the final receipt and capture. The two checks
share the action, software and AI authorship. The result
concerns the Euclidean lifted group with all exterior
ghost switches and zero internal switch count. Internal
switches, new paths, and the causal weak limit are open.
