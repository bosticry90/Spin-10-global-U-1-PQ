# V895 pre-execution contract

Determine whether summing the actual exterior ghost switch
vertices cancels the V894 soft transition term. Use the
Euclidean continuum following the same UV conversion.
Retain the fixed V879 density, lifted V883 group, massive
feedback, zero internal switch insertion count, and zero A,
retained sources and mass-difference degree. Use a monotone
compact smooth radial plateau with a sufficiently wide log
transition, and unswitched Schwartz sources with compact
Fourier support. Bind the actual free operator and both
source orientations. Keep the inherited signed constant.

Require a uniform form inverse under dilation, the rescaled
source limit on the transition region, a positive comparison
Green bound, and control of the nonconstant group with
dressed roots. Check the operator sign, radial flux, both
ground-state and form identities and scale relation.
Qualify only the sum on the two exterior roots, including
its effect on the lifted group. No Lorentzian sum or
internal switch cancellation is assumed.

Native limit 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor, 8 MiB
artifact, 32 MiB packet. Freeze proof, inputs and code.
Require replay, E4 and exact staged bytes. No new
normalization, inverse coupling or scientific promotion.
