from pathlib import Path
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-base-Noether-interface-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V858_FROZEN_SELECTED_GRADED_OPERATIONS',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def light_linear(A,P):
    out={};kept=discarded=0
    for(g,w),co in P.items():
        ghosts=[(at,n,j)for at,(n,j)in enumerate(w)if 553<=n<598];assert len(ghosts)==1 and all(n<508 or 553<=n<598 for n,j in w);at,n,j=ghosts[0]
        if n>=565:discarded+=1;continue
        ww,s=A.canonical(w[:at]+((1286+n-553,j),)+w[at+1:]);assert s==1;a.put(out,(g,ww),co);kept+=1
    return out,dict(kept_H_ghost_words=kept,discarded_M_ghost_words=discarded,all_input_words_linear_in_one_C_and_bosonic_physical_fields=True)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    roles=[]
    for role,owner,tag in[('native','primary','native_v2'),('replay','replay','replay_v4')]:
        chart=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(chart['all_current_names'],chart['all_current_parities']);T={i:a.decode(q)for i,q in chart['all1286_direct_Tq_columns']};Tp={i:a.decode(q)for i,q in chart['all1286_direct_Tqprime_columns']};flows=a.load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/(tag+'_field_flows.json.gz'));rows=[]
        for g in[0,1]:
            fmap=dict(flows['original_F'+str(g)]);assert set(fmap)==set(range(508))
            for i in range(508):
                image,journal=light_linear(A,p.old(fmap[i]));expected=p.grade(T[i],g);assert image==expected==p.grade(Tp[i],g),('PHYSICAL_GEOMETRIC_GAUGE_FLOW_MISMATCH',role,g,i);rows.append(dict(g=g,field=i,complete_light_gauge_flow=a.encode(image),journal=journal))
        print('STAGE '+role+' all1016_physical_geometric_gauge_columns_match',flush=True)
        parent=[];S={};P={};curr=[{}for mu in range(4)]
        for g in[0,1]:
            z=a.load(B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz'));diff=p.old(z['comparison']['complete_difference']);j=[p.old(q)for q in z['comparison']['four_complete_IBP_currents']];assert diff==p.divergence(A,j);assert not z['comparison']['complete_homogeneous_Euler_normal']and not z['comparison']['nonzero_Euler_ports'];current=p.old(z['complete_current_GF_source_parent']);old=p.old(z['complete_transported_portable_parent']);assert a.plus(old,a.scale(current,-1))==diff
            S=a.plus(S,current);P=a.plus(P,diff);curr=[a.plus(x,y)for x,y in zip(curr,j)];parent.append(dict(g=g,qualified_parent_sha256=digest(B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz')),difference_words=len(diff),current_words=[len(q)for q in j]))
        image=[p.action(A,j,Tp,owner)for j in curr];density=p.action(A,S,Tp,owner);boundary=p.divergence(A,image);residual=a.plus(density,boundary)
        if residual:save(role+'_FAILED_base_geometric_residual.json.gz',a.encode(residual));raise AssertionError('COMPLETE_CURRENT_BASE_GEOMETRIC_NOETHER_FAILED')
        reverse=a.plus(density,a.scale(boundary,-1));physical=a.load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/(tag+'_noether.json.gz'));assert physical['Noether_residuals']==[[],[],[]]and physical['full_density_variations']==[[],[]]
        record=dict(all1016_physical_g0_g1_flow_columns=rows,parent_current_inputs=parent,complete_current_GF_source_base=a.encode(S),complete_parent_difference=a.encode(P),all_four_parent_currents=[a.encode(q)for q in curr],complete_Tqprime_current_base=a.encode(density),all_four_Tqprime_parent_current_images=[a.encode(q)for q in image],complete_divergence_Tqprime_parent_currents=a.encode(boundary),complete_base_residual=a.encode(residual),controls=dict(reversing_current_sign_sensitive=bool(reverse),complete_wrong_current_sign_residual=a.encode(reverse)),physical_Noether_packet_sha256=digest(B/'canonical_so10_physical_current_input_recovery_g1_v1'/(tag+'_noether.json.gz')),physical_Noether_and_full_potential_proof_REUSED_NOT_replayed=True,full_physical_AST_same_as_V854=True,source_complete_T_S_plus_C_S_equals_actual_current_NOT_literal_zero_claim=True)
        art=save(role+'_complete_geometric_base_Noether_interface.json.gz',record);roles.append(dict(role=role,artifact=art,physical_flow_columns=1016,base_density_image_words=len(density),complete_boundary_current_words=[len(q)for q in image],wrong_current_sign_control_sensitive=bool(reverse)));print('STAGE '+role+' source_complete_geometric_base_current_verified',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='COMPLETE_CLASSICAL_GEOMETRIC_BASE_NOETHER_INTERFACE_SUPPORTED',roles=roles,physical_potential_Noether_is_authenticated_dependency_not_new_calculation=True,first_D_jet_profiles_common_quantum_products_W5_E5_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
