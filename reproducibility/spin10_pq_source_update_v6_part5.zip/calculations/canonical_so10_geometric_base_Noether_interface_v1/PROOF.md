# Two separate base geometric Ward legs

V855/V856 checks every current field/source column of Tprime=T+C using
the actual evaluation-dual/Wick and local even-omega frame. V857 checks
the probe action. Neither alone establishes that the recovered BASE action
is the action to which the older geometric Noether identity applies.

## Gauge-fixing and all canonical sources

V846 supplies literal old/current parent densities and four explicit
currents in both routes, separately at g0/g1:

    P=Sold_E-Scurrent_GF=partial_mu j_mu.

Tprime is even and is prolonged to jets evolutionarily, so it commutes
with every ordinary derivative. The qualified old GWP relation is
Tprime Sold=0. V855's complete conjugacy and the stable A/alljets0 ideal
transport that relation; no local background Tb statement is used. Hence

    Tprime Scurrent_GF=-partial_mu(Tprime j_mu).

The present calculation does more than cite this proof: it freshly
reconstructs P/divj, materializes all four Tprime j images, and independently
varies the entire current GF/source density with the actual columns. It
compares the signed identity coefficientwise, retaining every source and
local parameter jet. The two density representatives need not be equal.

Native has literal zero variation and zero image currents. Replay has a
nonzero4872-word density variation, compensated by406 words in each of
four image currents. It is equal as a functional, not as the same density.
The reversed-current control is blind in native and sensitive in replay.
No projection, equations of motion or fitted coefficient explains this zero.

## Separate physical action

V788 reconstructs the actual physical BRST flows and gauge/scalar kinetic
Noether identities in the same current field frame. Each physical flow
contains one C and otherwise only bosonic physical fields. Restrict the
actual H ghost frame to the even geometric parameter, keeping jets:

    C_h -> omega_h (h<12), C_m ->0 (m>=12).

This is a coefficient-linear map on that verified subspace, not a general
map of odd and even algebras. The V855 spatial-connection/light-ghost frame
comparison supplies its actual normalization; matching index numbers alone
would not. Compare all508 columns at each g0/g1 to BOTH T and Tprime,
including zeros, separately in both routes:1016 comparisons per route.

The existing physical kinetic Noether proofs can then be reused under
this coefficient-linear restriction. The complete approved scalar potential
remains an inherited gauge-Euler/29-direction Noether premise with the SAME
physical AST, established in V788/V854. No new potential Euler expansion or
assignment of unknown gradients to zero is performed. The final verifier
authenticates this AST/receipt lineage. Old mathematical proofs are reused,
not relabeled freshly replayed or experimentally validated.

C acts only on sources and the physical action is source free. Its
contribution to C(S) is therefore zero, while its geometric field variation
uses precisely the qualified H-restricted physical flow. Together with
the complete GF/source leg this supports the scoped classical base identity

    T S+C(S)=partial_mu J_mu.

Together with V857 this gives the same base relation for S+uU in the
declared first-probe,g<=1,intrinsic01 quotient. It does not prove a quantum
Ward identity. The whole insertion still requires all source-Hessian and
mixed-product terms. Source-quadratic probes do not permit mean-field
factorization. The ordinary-U covariance of C(S) remains even where the
classical Tprime U density is zero.

Four-dimensional current identities do not establish first-D-jets. Next
map W,c,C(S),C(U) and these actual currents through the SAME fixed metric
constructor, or supply the exact all-D variational/IBP construction. Keep
closed quantum D traces, alpha'_4, heat/IR profiles and common finite
normalization. Full background,QAP,measure,composite products,A5 and physical
viability remain open. The same action/software/arithmetic/AI assumptions
limit all internal agreement. No protected scientific promotion is requested.
