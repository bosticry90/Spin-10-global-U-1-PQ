from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-base-Noether-interface-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='7094f7a8c3ccd54db5c5bab19875dd0c0dd94755'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names=set(json.loads((B/'canonical_so10_geometric_probe_Ward_insertion_v1/preparation_validation.json').read_bytes())['sha256'])|{'docs/RESEARCH_EXECUTION_HANDOFF_V857.md','calculations/canonical_so10_geometric_probe_Ward_insertion_v1/validation_receipt.json','calculations/canonical_so10_geometric_probe_Ward_insertion_v1/capture_validation.json','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_GAUGE_EULER_ADAPTER_RESULT.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_gauge_euler_adapter/validation_receipt.json'}
for role,tag in[('native','native_v2'),('replay','replay_v4')]:
    for g in[0,1]:names.add('calculations/canonical_so10_acceptance_parent_reconciliation_v1/'+role+'_v2_complete_parent_g'+str(g)+'.json.gz')
    for ending in['field_flows.json.gz','noether.json.gz']:names.add('calculations/canonical_so10_physical_current_input_recovery_g1_v1/'+tag+'_'+ending)
for n in['physical_v2.py','physical_v4.py','preparation_v2.json','validation_receipt.json']:names.add('calculations/canonical_so10_physical_current_input_recovery_g1_v1/'+n)
enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
C.mkdir(exist_ok=False)
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings.json',dict(bindings=enc));dump(C/'input_encoding_bindings.json',dict(bindings=enc))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
