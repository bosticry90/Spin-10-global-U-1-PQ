from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-base-Noether-interface-v1-2026-11-08')
sys.path.insert(0,str(B/'canonical_so10_geometric_ward_current_source_chart_v1'));import algebra as a
sp=importlib.util.spec_from_file_location('V858_FROZEN_FRACTION_DIFFERENTIAL_CODEC',B/'canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
sp=importlib.util.spec_from_file_location('V858_FROZEN_INPUT_WORD_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def div(cc,par):
    out={}
    for mu,q in enumerate(cc):
        for k,val in v.de(v.flat(q),mu,par).items():v.add(out,k,val)
    return out
def vary(A,P,T,role):
    return a.plus(*(a.act(A,{k:val for k,val in P.items()if k[0]==h},{i:{k:val for k,val in q.items()if k[0]==g}for i,q in T.items()},role)for h in[0,1]for g in range(2-h)))
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='7094f7a8c3ccd54db5c5bab19875dd0c0dd94755'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation.json');assert prep==a.read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings.json');assert enc==a.read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    cap=a.read(O/'capture.json');assert cap==a.read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=a.read(O/'result.json');assert result['elapsed_after_imports']<180
    ast='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';astsha=digest(R/ast);assert astsha=='f3cec919dfb38b4a32d0f6ad923961d3fc9ba1b7ecf7b6c63f6c2d00c65bf575'and a.read(B/'canonical_so10_physical_current_input_recovery_g1_v1/preparation_v2.json')['input_sha256'][ast]==astsha and a.read(B/'canonical_so10_lifted_probe_master_carrier_reduction_v1/result.json')['lineage']['same_approved_physical_AST']==astsha
    summaries=[]
    for rr,owner,tag in zip(result['roles'],['primary','replay'],['native_v2','replay_v4']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);chart=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=a.Algebra(chart['all_current_names'],chart['all_current_parities']);T={i:a.decode(q)for i,q in chart['all1286_direct_Tq_columns']};Tp={i:a.decode(q)for i,q in chart['all1286_direct_Tqprime_columns']};flows=a.load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/(tag+'_field_flows.json.gz'));rows=[]
        for g in[0,1]:
            source=dict(flows['original_F'+str(g)]);assert set(source)==set(range(508))
            for i in range(508):
                image={};kept=discarded=0
                for(ww,k),val in v.flat(a.encode(p.old(source[i]))).items():
                    tokens=[t for t in ww if 553<=t[0]<598];assert len(tokens)==1 and all(n<508 or 553<=n<598 for n,j in ww);n,j=tokens[0]
                    if n>=565:discarded+=1;continue
                    word,sg=v.canon(tuple((1286+f-553,js)if 553<=f<565 else(f,js)for f,js in ww),A.parities);assert sg==1;v.add(image,(word,k),val);kept+=1
                expected=v.flat(a.encode({k:val for k,val in T[i].items()if k[0]==g}));assert image==expected==v.flat(a.encode({k:val for k,val in Tp[i].items()if k[0]==g}));row=z['all1016_physical_g0_g1_flow_columns'][508*g+i];assert row['field']==i and row['g']==g and v.flat(row['complete_light_gauge_flow'])==expected
                # Journals count grouped words, not expanded coefficients.
                grouped=p.old(source[i]);assert row['journal']['kept_H_ghost_words']==sum(any(553<=n<565 for n,j in w)for(g0,w),cv in grouped.items())and row['journal']['discarded_M_ghost_words']==sum(any(565<=n<598 for n,j in w)for(g0,w),cv in grouped.items())
        S={};P={};curr=[{}for mu in range(4)]
        for g in[0,1]:
            f=B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz');parent=a.load(f);diff=p.old(parent['comparison']['complete_difference']);j=[p.old(q)for q in parent['comparison']['four_complete_IBP_currents']];assert v.flat(a.encode(diff))==div([a.encode(q)for q in j],A.parities)
            current=p.old(parent['complete_current_GF_source_parent']);old=p.old(parent['complete_transported_portable_parent']);assert a.plus(old,a.scale(current,-1))==diff;S=a.plus(S,current);P=a.plus(P,diff);curr=[a.plus(x,y)for x,y in zip(curr,j)];assert z['parent_current_inputs'][g]['qualified_parent_sha256']==digest(f)
        assert S==a.decode(z['complete_current_GF_source_base'])and P==a.decode(z['complete_parent_difference'])and [a.encode(q)for q in curr]==z['all_four_parent_currents'];other='replay'if owner=='primary'else'primary';density=vary(A,S,Tp,other);images=[vary(A,j,Tp,other)for j in curr];assert a.encode(density)==z['complete_Tqprime_current_base']and [a.encode(q)for q in images]==z['all_four_Tqprime_parent_current_images'];bd=div([a.encode(q)for q in images],A.parities);assert bd==v.flat(z['complete_divergence_Tqprime_parent_currents'])and v.delta({},bd)==v.flat(a.encode(density))and not z['complete_base_residual']
        reverse=v.delta(v.flat(a.encode(density)),bd);assert reverse==v.flat(z['controls']['complete_wrong_current_sign_residual'])and bool(reverse)==z['controls']['reversing_current_sign_sensitive']==rr['wrong_current_sign_control_sensitive']
        for D,pp in[(4,S),(4,P),(4,density),*[(3,q)for q in curr+images]]:
            for(g,w),cv in pp.items():assert g<=1 and 0<=D-sum(p.dim(n)+len(j)for n,j in w)<=1
        noether=B/'canonical_so10_physical_current_input_recovery_g1_v1'/(tag+'_noether.json.gz');assert digest(noether)==z['physical_Noether_packet_sha256'];old=a.load(noether);assert old['Noether_residuals']==[[],[],[]]and old['full_density_variations']==[[],[]];summaries.append(dict(role=role,all1016_physical_gauge_flow_columns_checked=True,base_density_image_words=len(density),all_current_image_words=[len(q)for q in images],wrong_current_sign_control_sensitive=bool(reverse),old_physical_Noether_reused_NOT_replayed=True));print('STAGE '+role+' physical_and_full_source_base_interface_independently_verified',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V858.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V858.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V858.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2;files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V858.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_COMPLETE_CLASSICAL_GEOMETRIC_BASE_NOETHER_INTERFACE',base_HEAD=head,state_sha256=state,roles=summaries,physical_AST_sha256=astsha,physical_potential_Noether_is_inherited_authenticated_premise=True,full_source_currents_and_actual_frame_compared=True,first_D_jet_profiles_contacts_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_input_codec_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
