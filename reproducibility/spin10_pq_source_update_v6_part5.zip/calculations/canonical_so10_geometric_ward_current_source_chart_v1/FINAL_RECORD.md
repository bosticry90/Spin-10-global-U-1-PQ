# V855 separate final validation contract

One180s/8GiB sampled final run, same32MiB packet/8MiB artifact bounds.
Authenticate frozen sources, raw/Git newline bindings and old science receipts.
Use expanded Fraction/radical arithmetic to rebuild all complete generator
Euler columns and direct Kgeo from actual geometric field columns. Check
all643 c derivatives, direct difference, complete support/affinity, omega
parity/labels, controls, both route equality and parameter-frame interfaces.
Check external captures/source freezes, unchanged original Git tree/state,
historical README suffix, current navigation and fixed-context E4 once.
Require0,0,0,0,0,2 and seven unresolved, never custody PASS. Preserve any
failure unchanged. No scientific promotion or claim that old calculations
were freshly replayed. Root owns all writes/runs/Git; AI source review read only.
