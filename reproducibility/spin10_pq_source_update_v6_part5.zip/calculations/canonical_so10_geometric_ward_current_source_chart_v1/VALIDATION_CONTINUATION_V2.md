# Bounded final-verifier correction V2

The first final worker FAILED at its control-size assertion: the producer
counts84 grouped (g,word) positions, whereas the independent verifier's
expanded Fraction form has156 (word,g,xi,eta,radical) coefficients. Complete
coefficient equality on that control is retained. All earlier complete
column checks executed; the failed run earns no qualification. Its source,
freeze, capture, drafts and bindings are immutable and retained unchanged.

New validate_v2.py is a distinct source copied from the failed validator,
with only grouped-versus-expanded control counting corrected, current V856
navigation and V2 output/preparation filenames. No mathematical comparison,
input, parity, acceptance or resource obligation is removed. One180s/8GiB
sampled run with the same32MiB/8MiB bounds; E4 has not yet run in the failed
worker and must run once here. Validation receipt/capture V2 own qualification.

Record old grouped84 and expanded156 separately, rather than forcing either
representation to fit the other. No new loop/scientific promotion. Current
AGENTS delegates routine verification-harness correction. Root owns runs.
