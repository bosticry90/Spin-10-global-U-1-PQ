from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-ward-current-source-chart-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='242e5153da0e229538ddf4443de16766f8287458'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V854.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py'}
for folder,files in{
'canonical_so10_geometric_ward_products':['ward.py','preparation.json','validation_receipt.json','DERIVATION.md'],
'canonical_so10_full_jet_source_master_bridge':['primary_inputs.json.gz','replay_inputs.json.gz','primary_tables.json.gz','replay_tables.json.gz','final_review_validation_receipt.json'],
'canonical_so10_fixed_log_candidate_background_g1_v1':['LOCAL_PROOF.md','local_basis.py','validation_receipt.json','primary_local_basis.json.gz','replay_local_basis.json.gz'],
'canonical_so10_acceptance_parent_reconciliation_v1':['validation_receipt.json','compute_parent_v2.py','preparation_c_v2.json'],
'canonical_so10_lifted_probe_master_carrier_reduction_v1':['PROOF.md','validation_receipt.json']}.items():
    for n in files:names.add('calculations/'+folder+'/'+n)
for n in['primary.json','replay.json','validation_receipt.json']:names.add('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry/'+n)
enc=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
C.mkdir(exist_ok=False)
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings.json',dict(bindings=enc));dump(C/'input_encoding_bindings.json',dict(bindings=enc))
for n in['RECORD.md','algebra.py','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
