from pathlib import Path
from hashlib import sha256
import gzip,json,os,threading,time
import algebra as a
R=a.R;O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-ward-current-source-chart-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    return dict(file=n,sha256=digest(O/n),bytes=len(blob))
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    cases=[];peers=[]
    for role in['primary','replay']:
        ch=a.Chart(role);A=ch.A;e=a.read(R/('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry/'+role+'.json'));Traw={ch.raw.index[n]:ch.rows(rr)for n,rr in e['operators']['Tq_geometric'].items()};Praw={ch.raw.index[n]:ch.rows(rr)for n,rr in e['operators']['Tq_transported'].items()};Wraw=ch.rows(e['quantum_fermion_breaking'])
        assert all(not Traw[n]and not Praw[n]for n in ch.extA)
        T=ch.vector(Traw);Tp=ch.vector(Praw);W=ch.transport(Wraw,density=True);Kg=ch.transport(ch.raw_generator(Traw),density=True);Kp=a.plus(Kg,W);direct=ch.current_generator(T)
        if Kg!=direct:save(role+'_FAILED_generator_difference.json.gz',a.encode(a.plus(Kg,a.scale(direct,-1))));raise AssertionError('CURRENT_GENERATOR_INTERFACE_FAILED')
        H=ch.hamiltonian(Kg);Hp=ch.hamiltonian(Kp);assert H==T and Hp==Tp,'ALL1286_HAMILTONIAN_COLUMNS_FAILED'
        EW=a.eulers(A,W,set(range(643)));c={i:a.plus(Tp[i],a.scale(T[i],-1))for i in range(1286)};assert all(not c[i]for i in range(643))and all(c[643+i]==EW.get(i,{})for i in range(643))
        # Push the separately stored E3 source correction, not just Tp-T.
        craw={n:{}for n in Traw}
        for i,j,h,k in ch.pairs:craw[j]=ch.rows(e['source_transport_corrections']['quantum'][ch.raw.names[j]])
        assert ch.vector(craw)==c
        assert all(sum(n<643 for n,j in w)<=1 and not any(j for n,j in w if n<643)and not any(643<=n<1286 for n,j in w)for i in range(643)for(g,w),v in T[i].items())
        assert all(not any(n<643 for n,j in w)and sum(643<=n<1286 for n,j in w)<=1 for i in range(643,1286)for(g,w),v in T[i].items())
        assert all(sum(n<643 for n,j in w)<=1 and not any(643<=n<1286 for n,j in w)for i in range(643,1286)for(g,w),v in c[i].items())
        assert all(sum(n>=1286 for n,j in w)==1 for pp in[W,Kg,Kp,*T.values(),*Tp.values()]for(g,w),v in pp.items())
        oldparitywrong=[i for i in range(643)if c[643+i]!=a.scale(EW.get(i,{}),(-1)**A.parities[i])];wrongjet=a.plus(W,a.scale(ch.transport(Wraw,density=True,omit_time_jets=True),-1));wrongsource=a.plus(Kg,direct);assert oldparitywrong and wrongjet and wrongsource
        blob=dict(field_order=list(A.names[:643]),all_current_names=list(A.names),all_current_parities=list(A.parities),light_parameter_V=[[i,j,[[list(k),v.numerator,v.denominator]for k,v in co]]for(i,j),co in sorted(ch.V.items())],light_parameter_W=[[i,j,[[list(k),v.numerator,v.denominator]for k,v in co]]for(i,j),co in sorted(ch.W.items())],complete_W=a.encode(W),complete_Kgeo=a.encode(Kg),complete_Kprime=a.encode(Kp),all1286_direct_Tq_columns=[[i,a.encode(T[i])]for i in range(1286)],all1286_direct_Tqprime_columns=[[i,a.encode(Tp[i])]for i in range(1286)],all1286_source_difference_columns=[[i,a.encode(c[i])]for i in range(1286)],all643_W_field_Euler_columns=[[i,a.encode(EW.get(i,{}))]for i in range(643)],controls=dict(old_raw_parity_factor_differing_source_ports=oldparitywrong,complete_wrong_time_jet_W_difference=a.encode(wrongjet),complete_wrong_source_density_sign_difference=a.encode(wrongsource)),A0_stable_for_Tq_NOT_Tb=True,current_source_correction_is_EL_W_without_old_parity=True,C_of_P='sum_i c_Ji EL_left_Ji(P);whole product;equals sum_i (-1)^p_i c_Ji Qz_i ONLY when Qz_i=(-1)^p_i EL_Ji(P)',KD_D_odd_master_operation_NOT_identified_with_geometric_Ward=True)
        art=save(role+'_complete_geometric_current_source_chart.json.gz',blob);peers.append(blob);cases.append(dict(role=role,artifact=art,W_words=len(W),Kgeo_words=len(Kg),Kprime_words=len(Kp),Tq_words=sum(map(len,T.values())),Tqprime_words=sum(map(len,Tp.values())),nonzero_c_source_columns=sum(bool(c[i])for i in range(643,1286)),old_parity_control_sensitive_ports=len(oldparitywrong),wrong_time_jet_difference_words=len(wrongjet)));print('STAGE '+role+' full1286_geometric_and_transported_Hamiltonian_columns_match',flush=True)
    assert peers[0]==peers[1],'PRIMARY_REPLAY_CURRENT_INTERFACE_DIFFERENCE'
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='FULL_GEOMETRIC_CURRENT_SOURCE_GENERATOR_INTERFACE_SUPPORTED_AT_A0',roles=cases,source_product_and_physical_Noether_application_require_next_bounded_check=True,common_renormalized_contact_profile_W5_E5_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
