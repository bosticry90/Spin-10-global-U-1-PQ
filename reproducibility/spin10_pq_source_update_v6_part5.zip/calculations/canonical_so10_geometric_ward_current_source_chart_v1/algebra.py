"""Pure exact full-source geometric chart, without an epsilon alphabet."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
import gzip,json,sys
R=Path(__file__).resolve().parents[2];B=R/'calculations'
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient,multiply_coefficients,parse_coefficient
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def plus(*pp):
    out={}
    for p in pp:
        for k,v in p.items():put(out,k,v)
    return out
def phase_power(n):
    i=n-643 if 643<=n<1286 else n
    return 3 if 508<=i<553 else 1 if i<180 and i%4==0 else 2 if 643<=n<1151 else 0
def ph(p):return (((0,0,16 if p%2 else 0),F([1,1,-1,-1][p%4])),)
def scalar(s):
    z=parse_coefficient(s);assert len(z)==1 and z[0][0]==0;return z[0][1]
def factor(p,c):return {k:multiply_coefficients(v,c)for k,v in p.items()if multiply_coefficients(v,c)}
def encode(p):return [[g,[[n,list(j)]for n,j in w],[[list(k),v.numerator,v.denominator]for k,v in co]]for(g,w),co in sorted(p.items())]
def decode(rows):return {(g,tuple((n,tuple(j))for n,j in w)):tuple((tuple(k),F(num,den))for k,num,den in co)for g,w,co in rows}
def atom(n,j=()):return {(0,((n,j),)):ONE}
def derivative(A,p,mu):
    out={}
    for(g,w),v in p.items():
        for at,(n,j)in enumerate(w):
            ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
            if sg:put(out,(g,ww),scale_coefficient(v,sg))
    return out
def jets(A,p,j):
    for mu in j:p=derivative(A,p,mu)
    return p
def eulers(A,p,domain=None):
    parts={}
    for(g,w),v in p.items():
        pref=0
        for at,(n,j)in enumerate(w):
            if domain is None or n in domain:put(parts.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(v,(-1)**(A.parities[n]*pref)))
            pref+=A.parities[n]
    out={}
    for(n,j),q in parts.items():out[n]=plus(out.get(n,{}),scale(jets(A,q,j),(-1)**len(j)))
    return {n:q for n,q in out.items()if q}
def act(A,p,rules,role='primary',odd=False):
    out={};cache={}
    for(g,w),v in p.items():
        pref=0
        for at,(n,j)in enumerate(w):
            if rules.get(n):
                if(n,j)not in cache:cache[n,j]=jets(A,rules[n],j)
                if role=='primary':term=A.product(A.product({(g,w[:at]):scale_coefficient(v,(-1)**pref if odd else 1)},cache[n,j]),{(0,w[at+1:]):ONE})
                else:
                    # Left jet derivative with the varied generator at the left.
                    term=A.product(cache[n,j],{(g,w[:at]+w[at+1:]):scale_coefficient(v,(-1)**(A.parities[n]*pref))})
                for k,c in term.items():put(out,k,c)
            pref+=A.parities[n]
    return out
class Chart:
    def __init__(self,role):
        self.role=role;data=load(R/'tools/portable_dh_v1/inputs.json.gz');geo=data['geometry'];self.raw=Algebra(geo['names'],geo['parities']);self.pairs=geo['field_source_h_k'];self.data=data
        tables=load(B/'canonical_so10_full_jet_source_master_bridge'/(role+'_tables.json.gz'));names=tables['field_order'];assert len(names)==643
        self.A=Algebra(names+['J_'+n for n in names]+['omega_current_'+str(h)for h in range(12)],[int(553<=n<643)for n in range(643)]+[1-int(553<=n<643)for n in range(643)]+[0]*12)
        self.frame=load(B/'canonical_so10_full_jet_source_master_bridge'/(role+'_inputs.json.gz'))['frame'];rawnames=self.frame['field_order'];self.rawpos={n:i for i,n in enumerate(rawnames)};self.F=defaultdict(list);self.T=defaultdict(list)
        for a,i,c in self.frame['physical_to_raw_kernel']['entries']:self.F[i].append((a,scalar(c)))
        for i,a,c in self.frame['physical_to_raw_inverse']['entries']:self.T[i].append((a,scalar(c)))
        V={};W={};VC={};WC={}
        for h in range(12):
            for a,c in self.T[self.rawpos['B'+str(h)+'_1']]:assert a<48 and a%4==1;put(V,(h,a//4),c)
            for a,c in self.F[self.rawpos['B'+str(h)+'_1']]:assert a<48 and a%4==1;put(W,(a//4,h),c)
            for a,c in self.T[self.rawpos['C'+str(h)]]:assert 553<=a<565;put(VC,(h,a-553),c)
            for a,c in self.F[self.rawpos['C'+str(h)]]:assert 553<=a<565;put(WC,(a-553,h),c)
        assert V==VC and W==WC
        for X,Y in[(V,W),(W,V)]:
            prod={}
            for(i,k),c in X.items():
                for(kk,j),v in Y.items():
                    if k==kk:put(prod,(i,j),multiply_coefficients(c,v))
            assert prod=={(h,h):ONE for h in range(12)}
        for mu in range(4):
            for h in range(12):
                assert {(a//4):c for a,c in self.T[self.rawpos['B'+str(h)+'_'+str(mu)]]if a<48 and a%4==mu}=={a:c for(hh,a),c in V.items()if hh==h}
                assert all(a<48 and a%4==mu for a,c in self.T[self.rawpos['B'+str(h)+'_'+str(mu)]])
        self.V=V;self.W=W;self.maps={};self.rawJ={}
        for f,j,hh,kk in self.pairs:
            i=self.rawpos[self.raw.names[f]];self.rawJ[i]=j
            self.maps[f]=plus(*(factor(atom(a),multiply_coefficients(c,ph(phase_power(a))))for a,c in self.T[i]))
            self.maps[j]=plus(*(factor(atom(643+a),multiply_coefficients(c,ph(phase_power(643+a))))for a,c in self.F[i]))
        for h in range(12):self.maps[self.raw.index['omega'+str(h)]]=plus(*(factor(atom(1286+a),c)for(hh,a),c in V.items()if hh==h))
        self.extA={self.raw.index['A'+str(h)+'_'+str(mu)]for h in range(12)for mu in range(4)};self.cache={}
    def rows(self,rr):
        out={}
        for row in rr:
            for k,v in self.raw.rows([row],explicit_g='g'in row).items():put(out,k,v)
        return out
    def transport(self,p,density=False,omit_time_jets=False):
        out={};A=self.A
        for(g,w),v in p.items():
            if any(n in self.extA for n,j in w):continue
            term={(g,()):scale_coefficient(v,-1 if density else 1)}
            for n,j in w:
                key=(n,j,omit_time_jets)
                if key not in self.cache:
                    assert n in self.maps,('UNMAPPED_FULL_GEOMETRIC_PORT',self.raw.names[n]);q={}
                    for(gg,ww),c in self.maps[n].items():
                        assert gg==0 and len(ww)==1
                        put(q,(0,((ww[0][0],j),)),multiply_coefficients(c,ph(0 if omit_time_jets else j.count(0))))
                    self.cache[key]=q
                term=A.product(term,self.cache[key])
            for k,c in term.items():put(out,k,c)
        return out
    def vector(self,rawrules):
        pushed={i:self.transport(rawrules[self.raw.index[n]])for i,n in enumerate(self.frame['field_order'])};pushedJ={i:self.transport(rawrules[self.rawJ[i]])for i in range(643)};out={n:{}for n in range(1286)}
        for i in range(643):
            for a,c in self.F[i]:out[a]=plus(out[a],factor(pushed[i],multiply_coefficients(c,ph(-phase_power(a)))))
            for a,c in self.T[i]:out[643+a]=plus(out[643+a],factor(pushedJ[i],multiply_coefficients(c,ph(-phase_power(643+a)))))
        return out
    def raw_generator(self,T):
        return plus(*(scale(self.raw.product(atom(j),T[f]),-(-1)**self.raw.parities[f])for f,j,h,k in self.pairs))
    def current_generator(self,T):return plus(*(scale(self.A.product(atom(643+i),T[i]),-1)for i in range(643)))
    def hamiltonian(self,K):
        E=eulers(self.A,K,set(range(1286)))
        return {**{i:scale(E.get(643+i,{}),-1)for i in range(643)},**{643+i:E.get(i,{})for i in range(643)}}
