from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,os,re,subprocess,sys,threading,time
import algebra as a
R=a.R;O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-ward-current-source-chart-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def flat(rows):return {(tuple((n,tuple(j))for n,j in w),(g,*k)):F(num,den)for g,w,co in rows for k,num,den in co}
def add(out,k,v):
    out[k]=out.get(k,F(0))+v
    if not out[k]:del out[k]
def canon(word,par):
    odd=[t for t in word if par[t[0]]]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(odd[i]>odd[j]for i in range(len(odd))for j in range(i+1,len(odd)))
def delta(q,p):
    out=dict(q)
    for k,v in p.items():add(out,k,-v)
    return out
def de(q,mu,par):
    out={}
    for(w,k),v in q.items():
        for at,(n,j)in enumerate(w):
            ww,s=canon(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:],par)
            if s:add(out,(ww,k),s*v)
    return out
def allE(q,par):
    out={}
    for(w,k),v in q.items():
        for at,(n,j)in enumerate(w):
            if n>=1286:continue
            part={(w[:at]+w[at+1:],k):v*(-1)**(par[n]*sum(par[t]for t,jj in w[:at])+len(j))}
            for mu in j:part=de(part,mu,par)
            for kk,vv in part.items():add(out.setdefault(n,{}),kk,vv)
    return {n:q for n,q in out.items()if q}
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='242e5153da0e229538ddf4443de16766f8287458'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation.json');assert prep==a.read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings.json');assert enc==a.read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    cap=a.read(O/'capture.json');assert cap==a.read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=a.read(O/'result.json');assert result['elapsed_after_imports']<180;peers=[];summaries=[]
    for rr in result['roles']:
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);peers.append(z);par=z['all_current_parities'];assert len(par)==1298 and par[:643]==[int(553<=i<643)for i in range(643)]and par[643:1286]==[1-v for v in par[:643]]and par[1286:]==[0]*12
        T={n:flat(q)for n,q in z['all1286_direct_Tq_columns']};Tp={n:flat(q)for n,q in z['all1286_direct_Tqprime_columns']};cs={n:flat(q)for n,q in z['all1286_source_difference_columns']};Ew={n:flat(q)for n,q in z['all643_W_field_Euler_columns']};W=flat(z['complete_W']);Kg=flat(z['complete_Kgeo']);Kp=flat(z['complete_Kprime']);assert set(T)==set(Tp)==set(cs)==set(range(1286))and set(Ew)==set(range(643))
        direct={}
        for i in range(643):
            for(w,k),v in T[i].items():
                ww,s=canon(((643+i,()),)+w,par)
                if s:add(direct,(ww,k),-s*v)
        total=dict(Kg)
        for k,v in W.items():add(total,k,v)
        assert direct==Kg and total==Kp, 'GENERATOR_DENSITY_RECONSTRUCTION'
        for K,expected in[(Kg,T),(Kp,Tp)]:
            E=allE(K,par)
            for i in range(643):assert {k:-v for k,v in E.get(643+i,{}).items()}==expected[i]and E.get(i,{})==expected[643+i]
        EW=allE(W,par)
        for i in range(1286):assert cs[i]==delta(Tp[i],T[i])
        for i in range(643):assert not cs[i]and cs[643+i]==Ew[i]==EW.get(i,{})
        assert all(sum(n<643 for n,j in w)<=1 and not any(j for n,j in w if n<643)and not any(643<=n<1286 for n,j in w)for i in range(643)for(w,k),v in T[i].items())
        assert all(not any(n<643 for n,j in w)and sum(643<=n<1286 for n,j in w)<=1 for i in range(643,1286)for(w,k),v in T[i].items())
        assert all(sum(n<643 for n,j in w)<=1 and not any(643<=n<1286 for n,j in w)for i in range(643,1286)for(w,k),v in cs[i].items())
        assert all(sum(n>=1286 for n,j in w)==1 for pp in[W,Kg,Kp,*T.values(),*Tp.values()]for(w,k),v in pp.items())
        # Rebuild actual raw-to-current maps and independently stored corrections.
        ch=a.Chart(role);old=a.read(R/('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry/'+role+'.json'));tr={ch.raw.index[n]:ch.rows(q)for n,q in old['operators']['Tq_geometric'].items()};pr={ch.raw.index[n]:ch.rows(q)for n,q in old['operators']['Tq_transported'].items()};rawW=ch.rows(old['quantum_fermion_breaking']);assert all(not tr[n]and not pr[n]for n in ch.extA)
        for mu in range(4):
            for h in range(12):
                terms=ch.F[ch.rawpos['B'+str(h)+'_'+str(mu)]];assert all(i<48 and i%4==mu for i,c in terms)
                assert {i//4:c for i,c in terms}=={i:c for(i,hh),c in ch.W.items()if hh==h}
        decode_matrix=lambda rows:{(i,j):tuple((tuple(k),F(num,den))for k,num,den in co)for i,j,co in rows}
        assert decode_matrix(z['light_parameter_V'])==ch.V and decode_matrix(z['light_parameter_W'])==ch.W
        assert {n:flat(a.encode(q))for n,q in ch.vector(tr).items()}==T and {n:flat(a.encode(q))for n,q in ch.vector(pr).items()}==Tp and flat(a.encode(ch.transport(rawW,density=True)))==W and flat(a.encode(ch.transport(ch.raw_generator(tr),density=True)))==Kg
        wrong=delta(W,flat(a.encode(ch.transport(rawW,density=True,omit_time_jets=True))));assert wrong==flat(z['controls']['complete_wrong_time_jet_W_difference'])and len(wrong)==84
        ports=[i for i in range(643)if cs[643+i]!={k:v*(-1)**par[i]for k,v in Ew[i].items()}];assert ports==z['controls']['old_raw_parity_factor_differing_source_ports']and len(ports)==12
        assert flat(z['controls']['complete_wrong_source_density_sign_difference'])=={k:2*v for k,v in Kg.items()};assert sum(bool(cs[i])for i in range(643,1286))==rr['nonzero_c_source_columns']==60
        summaries.append(dict(role=role,all1286_two_generator_columns_checked=True,all643_source_Eulers_checked=True,nonzero_c_source_columns=60,parity_sensitive_source_ports=ports,wrong_time_jet_difference_words=84));print('STAGE '+role+' independent_expanded_Fraction_Euler_columns_verified',flush=True)
    assert peers[0]==peers[1]
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V855.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V855.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V855.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2;files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V855.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_COMPLETE_GEOMETRIC_CURRENT_SOURCE_GENERATOR_INTERFACE_AT_A0',base_HEAD=head,state_sha256=state,roles=summaries,all_source_columns_and_zero_complement_checked=True,actual_even_local_omega_distinct_from_odd_D_epsilon=True,geometric_whole_products_heat_profiles_full_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_input_action_codec_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
