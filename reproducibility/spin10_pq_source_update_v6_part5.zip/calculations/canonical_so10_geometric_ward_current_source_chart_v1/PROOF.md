# Geometric Hamiltonian/source chart, distinct from the D operation

This proof concerns the complete original E3 bosonic/nonminimal geometric
quantum transformation at zero background connection. Its local even omega
and every ordinary jet are retained. This is not KD's broken odd epsilon.
Both Tq and Tqprime fix A, so the A/all-jets zero ideal is stable. Tb does
not fix A; no local background Ward theorem is inferred here.

The immutable E3 packets contain the full geometric T, transported Tprime,
all643 correction columns and W=T Psi. GWP establishes their raw chart
Hamiltonians with s_i=(-1)^p_i:

    Kgeo,raw=-sum_i s_i Jraw_i T(zraw_i), Kprime,raw=Kgeo,raw+Wraw.
    Xraw_K z_i=-s_i EL_Ji K, Xraw_K J_i=s_i EL_zi K.

Push raw fields by T*phase_field and sources by F^transpose*phase_source,
using exactly the current FJB frame. Each time jet contributes +i; integrated
densities contribute minus. Vector outputs use inverse field/source phases
and respectively F/T^transpose. The source phases obey
phase_i*phase_Ji=-s_i, so transporting the odd generators gives the current
Hamiltonian convention

    X_K z_i=-EL_Ji K, X_K J_i=EL_zi K.
    Kgeo=-sum_i J_i T(z_i), Kprime=Kgeo+W.

These identities are not accepted from the phase formula alone: the worker
independently pushes every actual vector column and checks all1286 columns
of each current generator against it. It also reconstructs Kgeo directly
from the pushed field rules, compares density coefficients, and separately
pushes the stored source corrections. Zeros and source columns are included.
The final validator uses expanded Fraction/radical left-jet derivatives,
independent of the producer's grouped-coefficient Euler implementation.

Derive light omega from the actual spatial H-connection F/T subblocks.
Check their two inverses, all four Lorentz components, no heavy leakage,
and equality to the independently extracted light-ghost frame. The earlier
V841 real-connection/antilinear analysis supplies the inherited real-form
justification; index coincidence with an odd ghost is not such justification.

The complete current source difference C=Tprime-T is zero on fields and

    c_Ji=EL_zi W.

The old s_i must NOT be copied into this current formula. The current basis
has60 nonzero source columns, compared with56 in the old chart; linear
mixing can change this count. The full643-column comparison is the test.
The incorrect copied parity changes12 source ports. Dropping time-jet Wick
phases changes84 W words. Wrong generator density sign changes the full
Hamiltonian; all controls are coefficient tests, not measured loop effects.

The actual geometric field rules are affine with no ordinary field jets;
the geometric source rules are linear in sources and independent of ordinary
fields. Each c is at most linear in ordinary fields and has no sources.
Consequently its ordinary-field Hessian vanishes, but products do not:

    C(P)=sum_i c_Ji EL_left_Ji P.

If Q_P z_i=s_i EL_Ji P, then C(P)=sum_i s_i c_Ji Q_P z_i. Replacing this
with sum c_Ji Qz_i would lose another current-chart parity. A whole quantum
insertion of C(P) retains both mixed Hessian legs and the c*H_ELJ(P) term;
c_Hessian zero does not remove them or justify mean-field factorization.

The prospective direct Ward route for Sigma_u=S+uU is therefore

    T Gamma_u+[C(Sigma_u)]_Gamma
        =u[Tprime U]_Gamma+M_q,

after the complete base Noether identity, common finite functional and
regulator/measure applicability are proved. This even insertion is not the
odd auxiliary master carrier. No quantum [G], canonical quantum equivalence
or A5 is used by this route. It is also not strict Tprime Gamma=0. Adding
an independent action correction changes Tprime of that correction and
must use the same product prescription.

V855 establishes the complete classical generator/source chart only. The
actual T U+C U, current parent IBP currents, physical508-field Noether leg,
fixed metric/first-D-jet lift of these geometric insertions, finite profile
identification and common normalized products still need applicability.
GWP/old Noether results are authenticated dependencies, not freshly rerun.
Do not infer complete W5/E5 or a vanishing raw regulator from these checks.
Same action, conventions, arithmetic library, Python and AI authorship limit
the independence of all routes; none supplies experimental validation.
