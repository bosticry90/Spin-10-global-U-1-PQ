# Six carrier families are required by the original consistency operation

Actual source-first port projection and two independent enumeration
methods give six Q0 carrier patterns for LambdaCC consistency: BLambdaC,
JaLambdaC,aCC,JBCC,JLambdaCC and JaC. Their22 labelled Lorentz placements
reduce to12 modulo ordinary divergences. The counts precede invariant,
exchange and reality constraints; they are not twelve counterterms.

The first-u operation reaches three patterns for H (aCC,JBCC,JLambdaCC)
and four for M (also JaC), with15/18 raw and8/9 IBP Lorentz placements.
Intrinsic1 has no Lorentz scalar in this particular target. All1286 ports
for each operation, full raw maps/projection journals, independent type
enumerations and exact IBP matrices remain in census_tables.json.gz.
Unknown physical potential terms are excluded by target support/dimension,
not set zero; no full chiral or measure statement follows.

Omitting sources loses four of six original patterns. Linearizing QJa
loses the distinct two-derivative JaC source pattern. Probe field variation
alone keeps only aCC and misses the actual source signatures in both
probes. These are exact operator/type controls, not loop measurements.

This explains why V803's zero JaLambdaC reference cannot stand in for
JaC with two derivatives, or why its selected H vector zero cannot remove
all H companions. No new quantum coefficient has been assigned. The next
smallest target is actual original/first-u JaC, with a fresh complete
returning catalog at that changed external budget and all source/inverse
responses retained before elimination. Do not fit unknown companions to
the measured vector coefficient or assert isolated-gu Q0 closedness.

The worker completed5.596s under120s,8GiBsampled/350MiBfloor/16MiBpacket;
no worker/preparer failure. The final receipt checks sources/data/types/
projections/ranks/controls/resources/state/oldtree and E4once-no-freshD
context, custodyexit2/seven unresolved NOTPASS. Shared classical inputs,
ring/type software and AI author limit independence; no independent
scientist, proof kernel or experiment. State113/34of39,E5/A5open, prior
failures, protected stages and fullgoal unchanged. No remote action.
