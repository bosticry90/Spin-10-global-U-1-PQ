# Source companions required by the actual Lambda-C-C consistency target

This result identifies local carrier and Lorentz-jet requirements in the
original A0, first-u,g1, parity-even Euclidean intrinsic01 domain. It does
not measure a new loop coefficient, construct a counterterm or test full
restoration. V803's selected breaking and V804's lower unmarked coefficient
remain the qualified quantum operands; no unknown companion is set zero.

## Actual operations and the projection boundary

All1286 field/source ports of Q0 and both Q_u0 operators are read before
selection. Source images are (-1)^p Euler S, with the full classical
source Euler rows, and actual physical kinetic E0 is included. The saved
raw maps and selected/rejected rows preserve both zeros and nonzeros.
Only afterwards are output monomials restricted to Lambda and C, with
budgets Lambda<=1 and C<=2. The target is the ghost2,dimension6 coefficient
Lambda C C with two derivatives, not a field-only or source-zero operator.

Physical-potential Eulers are not declared absent. They contain no Lambda
or C. If such an Euler supplied a constant, the required input would still
have to contain Jx Lambda C C, already of field dimension6, beyond a
dimension5 breaking. Nonconstant potential Eulers retain a forbidden
scalar. Hence they cannot change this target census. The same physical
matter/source support and stable-ideal restriction excludes K/fermion
terms here, after the operations. No global chiral or measure zero follows.

The actual target-relevant signatures are Q0B=partial C, Q0a=iLambda,
Q0JB~partial Lambda, Q0JLambda~Omega Lambda, and Q0Ja containing both
boxC and Lambda M C. Other raw terms remain but cannot reach the target.
Q_u0 has antighost, JB and JLambda signatures for both probes. Its Ja
Lambda-C signature is nonzero for M and absent for H because the actual
M_r has no H rows. Its source images cannot be replaced by just the
antighost field flow. All color/Lorentz ports precede these collapsed
type signatures; H/M differences are measured from actual maps.

## Complete single-replacement argument

The ten canonical species types are B,x,Lambda,C,a and their five BV
sources. Their dimensions, ghost numbers, parity and vector/covector
types are the existing ones; in particular JLambda has dimension1 and
Ja dimension2. Consider every nonnegative multiplicity with dimension
budget5, ghost1 and odd parity, with intrinsic coefficient dimension0/1.
One polynomial Q operation replaces one factor by a jet of its actual
image. It cannot remove another forbidden factor. Matching the output
counts to Lambda^1 C^2 therefore gives an exhaustive finite problem.

Direct enumeration of every typed candidate matches the independent
inverse construction target-minus-output-plus-input. Both routes retain
source operations before the mean projection. Their agreement tests the
enumeration; the action/type/ring/AI author remain shared assumptions.

The Q0 result is:

| Breaking carrier | Derivatives | Raw Lorentz placements | Modulo IBP | Quantum status here |
| --- | ---: | ---: | ---: | --- |
| B Lambda C |1|3|2|V803 selected vector reference |
| Ja Lambda C |0|1|1|V803 selected source reference |
| a C C |2|6|3|Distinct companion, unmeasured here |
| JB C C |1|3|2|Distinct companion, unmeasured here |
| JLambda C C |2|6|3|Distinct companion, unmeasured here |
| Ja C |2|3|1|Distinct companion, unmeasured here |
| Total ||22|12||

These are labelled field/jet patterns before color invariance, ghost
exchange, actual coefficient symmetries or physical reality. Twelve is
not a count of independent counterterms or physical parameters. Both C
slots remain independent and carry genuine Grassmann exchange conditions.

For Q_u0 acting on unprobed g1 breakings, H reaches aCC, JBCC and
JLambdaCC:15 raw/8 IBP Lorentz placements. M additionally reaches JaC:
18 raw/9 IBP placements. The known BLambdaC and JaLambdaC carriers do
not substitute for these source columns. A selected H vector zero does
not determine all H companion coefficients.

Intrinsic coefficient dimension1 leaves an odd total Lorentz rank in
this target. With no external background vector in the A0 projection,
there is no Lorentz scalar. Every such typed candidate and its exclusion
are retained. This is not a rejection of massive amplitudes in a different
target or a reason to discard positive-dimensional insertions globally.

## Lorentz completeness and ordinary boundary terms

For three scalar slots and two derivatives, the six raw contractions are
the three p_i^2 and three p_i.p_j. The three relations p_i.sum_j p_j=0
have exact rank3, leaving3. For two scalar slots they have rank2 on the
three contractions, leaving1. For a single vector and one derivative,
there are three vector.p_i placements and one total-derivative relation,
leaving2. The source/auxiliary zero-derivative carrier has one placement.
All ranks use exact rational algebra, not a momentum or physical-parameter
specialization. Ordinary D is even and preserves the fixed labelled
Grassmann slot order. These relations are literal divergences of the
corresponding vector currents, with no equation of motion.

The separate final review also eliminates the last momentum symbolically
and checks the resulting independent Gram/vector map: it annihilates all
IBP relations and has the stated quotient rank. No p_i^2 is set zero.

## Sensitive controls and scientific next step

Dropping all BV sources loses four of Q0's six families, including the
known JaLambdaC and the three distinct source families. Linearizing QJa
loses JaC with two derivatives. Retaining only the probe field variation
keeps just aCC for either H/M and misses their actual source columns.
H's missing JaC probe signature is a genuine support zero, not a blind
claim that H has no source response at all.

At ordergu the full consistency equation includes
Q0 Delta_gu + Q1 Delta_u0 + Q_u0 Delta_g1 + Q_u1 Delta_g0, with all
applicable source, chiral and insertion qualifications retained. A test
on just Delta_gu's BLambdaC coefficient is not this equation. V804 now
supplies the lower Delta_u0 nonminimal reference, but the companion
coefficients in the table have not been computed by this census.

The least expensive next quantum target is the distinct Ja-C two-derivative
coefficient, using the actual full regulator roots/ordinary Hessians and
both original/probe orders. Its external budget has no Lambda. The old
JaLambdaC zero reference and old BLambdaC excluded-port lists cannot be
transferred to it. In particular retain all F1/Fu0/Fu1 and full source
quadratic/inverse responses until a new complete returning catalog proves
which contributions survive; do not infer a two-edge formula from one root.
The relevant hatted support must be reapplied after source operations.

This bounded carrier result sharpens the common restoration question.
It is not a new fitted cancellation, a complete admissible module, a
cohomology theorem or E5/A5 completion. No separate state ledger, physical
benchmark, foundation, publication or remote action is created. Shared
classical action/types, code libraries and AI author limit independence;
there was no worker failure in this increment and no outside validation.
