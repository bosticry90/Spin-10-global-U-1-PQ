from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/g1-consistency-companion-carriers-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('actual_companion_final',O/'census.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=m.read;load=m.load;digest=m.digest;s=m.s
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def independent_Gram_check(lift):
 n=len(lift['slots']);basis=lift['basis'];rels=s.Matrix(lift['relations']) if lift['relations'] else s.zeros(0,len(basis))
 if basis==['1']:image=s.ones(1,1)
 elif basis[0][0]=='vector':
  image=s.zeros(n-1,n)
  for i in range(n-1):image[i,i]=1;image[i,n-1]=-1
 else:
  raw=[(int(a[1:]),int(b[1:])) for a,b in basis];ind=[(i,j) for i in range(n-1) for j in range(i,n-1)];image=s.zeros(len(ind),len(raw));index={key:i for i,key in enumerate(ind)}
  for col,(a,b) in enumerate(raw):
   left=[(a,1)] if a<n-1 else [(i,-1) for i in range(n-1)]
   right=[(b,1)] if b<n-1 else [(i,-1) for i in range(n-1)]
   for i,x in left:
    for j,y in right:image[index[tuple(sorted((i,j)))],col]+=x*y
 assert image*rels.T==s.zeros(image.rows,rels.rows)
 assert image.rank()==lift['quotient']==len(basis)-rels.rank() and rels.rank()==lift['rank']
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 z=load(O/'census_tables.json.gz');r=read(O/'census_result.json');assert digest(O/'census_tables.json.gz')==r['artifact_sha256'] and r['elapsed_after_imports']<120
 assert len(z['species'])==10
 for i in range(5):assert m.dims[5+i]==3-m.dims[i] and m.gh[5+i]==-1-m.gh[i] and m.par[5+i]==1-m.par[i]
 rows_checked=0;words_checked=0;sigs={}
 for label,ports in z['actual_projected_maps'].items():
  assert [v['port'] for v in ports]==list(range(1286));actual=set()
  for row in ports:
   keep=[];bad=[]
   for at,(ww,cc) in enumerate(row['raw']):
    L=sum(508<=n<553 for n,js in ww);G=sum(553<=n<598 for n,js in ww);der=sum(len(js) for n,js in ww)
    if any(not 508<=n<598 for n,js in ww) or L>1 or G>2:bad.append(at)
    else:
     keep.append(row['raw'][at]);cnt=(0,0,L,G,0,0,0,0,0,0);kind=m.species(row['port'])
     assert G==m.gh[kind]+1 and G%2==(m.par[kind]+1)%2 and 2*L+G+der==m.dims[kind]+1
     actual.add((kind,cnt,der))
    words_checked+=1
   assert keep==row['selected'] and bad==row['rejected_raw_indices'];rows_checked+=1
  declared={(i,tuple(c),d) for i,c,d in z['actual_map_signatures'][label]};assert actual==declared;sigs[label]=actual
  direct,rejected=m.direct(actual);assert set(direct)==m.inverse(actual)
  saved={(tuple(v['counts']),v['jets'],v['intrinsic']):v for v in z['census'][label]};assert set(saved)==set(direct)
  for key,v in saved.items():
   assert v['Lorentz']==direct[key]['Lorentz'] and {str(x) for x in v['images']}=={str(x) for x in direct[key]['images']}
   independent_Gram_check(v['Lorentz']);assert v['intrinsic']==0
  assert all(v['intrinsic']==1 and v['reason']=='ODD_LORENTZ_RANK' for v in z['odd_Lorentz_rejections'][label])
 assert rows_checked==3*1286
 assert r['summary']['Q0']==dict(patterns=6,raw_Lorentz=22,after_IBP=12,intrinsic1_patterns=0)
 assert r['summary']['Qu0_H']==dict(patterns=3,raw_Lorentz=15,after_IBP=8,intrinsic1_patterns=0)
 assert r['summary']['Qu0_M']==dict(patterns=4,raw_Lorentz=18,after_IBP=9,intrinsic1_patterns=0)
 assert len(r['controls']['omit_sources_lost'])==4 and r['controls']['linearize_QJa_lost']==[['C','Ja']] and r['controls']['probe_field_only_counts']=={'Qu0_H':1,'Qu0_M':1}
 cap=read(O/'census_capture.json');assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<v['private_bytes']<=8*1024**3 for v in cap['all_resource_samples'])
 print('STAGE all3858ports_and_rawprojections_grades_completecensuses_controls_independent_Gram_elimination_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V805.md'];size=sum(p.stat().st_size for p in files);assert size<16*1024**2
 out=dict(schema='ACTUAL_G1_CONSISTENCY_CARRIER_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_SOURCE_COMPLETE_TARGET_COMPANION_CARRIER_CENSUS',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,actual_ports_checked=rows_checked,raw_words_checked=words_checked,census=r['summary'],independent_last_momentum_Gram_IBP_rank_check=True,all_source_operations_precede_projection=True,physical_potential_and_chiral_support_exclusions_not_global_zeros=True,unknown_quantum_coefficients_not_assigned=True,counts_not_independent_invariant_tensors=True,failures_this_increment=0,worker_seconds_after_imports=r['elapsed_after_imports'],largest_private_sample=max(v['private_bytes'] for v in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
