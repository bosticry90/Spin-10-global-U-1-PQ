# Actual g1 consistency companion carriers

Base59b8a17ce28fb2bd12a1df89281dbea154d5818b/main,V804. CurrentAGENTS,
fullgoal/D:first,state113/34of39,E5/A5open unchanged. Noagents/branch/
worktree/adoption/promotion/protectedactivation/flavor/remoteaction.

Question: which local breaking carriers can feed the Lambda-C-C
dimension6/ghost2 consistency projection under actual Q0 or first-u Q_u0?
V803 measured BLambdaC and JaLambdaC, V804 supplies the lower unmarked
g0 coefficient. This does not justify closing the isolated gu equation.
Before computing more loops, derive the complete necessary companion
carrier space and which source terms cannot be omitted. This is a
specific existing Ward-equation test, not a new benchmark/platform/ledger.

Use original EuclideanA0,constantfirstu,g1,intrinsic coefficient dimensions
0/1,all643fields/sources BEFORE projecting means. Target Lambda^1 C^2,
no B/x/a/BV source means, with all external slots independent until proper
exchange relations. Candidate breakings have dimension5,ghost1,odd parity,
polynomial nonnegative-dimensional coefficients; no inverse coupling/mass.
Background0 and parity-even Lorentz scalar. Do not count color-invariant
operators or unknown coefficients from field-pattern counts.

Build actual Q0 and Q_u0 target-relevant maps from the complete classical
F0/E0 and Fu0/Eu0 operands, source signs (-1)^p, plus actual physical
kinetic E0 where appropriate. Retain raw maps and every projected zero.
Other physical-potential Euler terms are NOT assigned zero. Their absence
from this target follows from support: they have no Lambda/C; a constant
scalar Euler could only retain LambdaCC in an input JxLambdaCC of field
dimension6, already too high for a dimension5 breaking. Fermion mean/K
carriers cannot reach this purely nonminimal target after one Q0 operation,
by the same stable-ideal/support restriction; not a full chiral assertion.

Enumerate all ten physical/BV species types with their actual grades,
all nonnegative factor counts and remaining derivative/coefficient budget.
Project only AFTER action/source differentiation. Direct enumeration and
an inverse single-replacement derivation must agree. Any additional
forbidden factor cannot be removed by one polynomial Q operation. Keep
all actual color/Lorentz ports before collapsing to pattern signatures.

Construct all Lorentz contractions in the surviving pattern class with
labelled ghost slots. Ordinary total derivatives give the momentum-sum
IBP relations. Determine their exact ranks, without imposing equations of
motion or identifying ghost colors. Intrinsic1 produces an odd residual
Lorentz rank in this target and must be checked, not silently dropped.
The counts are carrier/jet patterns before invariant/reality/exchange
constraints, not independent counterterms or quantum amplitudes.

Controls: omit source coordinates, linearize QJa and retain only probe
field variation. They must lose actual supported companion classes where
nonzero; report H/M blind cases. No unknown coefficient is fit to a desired
zero. The next action is actual missing quantum companions using these
typed requirements and changed external budgets, not transferring old
BLambdaC excluded-port zeros.

Freeze before120s worker,8GiBsampled/350MiBfloor/16MiBpacket. Final180s
owns fullsource/type/port/census/rank/control/proof/resource/oldtree/state
validation and E4once-no-freshDcontext0,0,0,0,0,2/seven custodyNOTPASS.
Keep failed/incomplete sources/captures and every oldmodeblob. Local
stagedrawbyte/cachedcheck beforecommit; no push. Shared action/chart/ring/
AIauthor and inherited domain limit independence. FullQAP/measure/
equivalence/E5/A5/viability/fullinvestigation remainOPEN; educationnonblocking.
