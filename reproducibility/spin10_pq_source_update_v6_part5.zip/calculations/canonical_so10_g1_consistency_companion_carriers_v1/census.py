from pathlib import Path
from hashlib import sha256
from itertools import combinations_with_replacement
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('actual_companion_types',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
names=['B','x','Lambda','C','a','JB','Jx','JLambda','JC','Ja']
representatives=[0,180,508,553,598,643,823,1151,1196,1241]
gh=[0,0,0,1,-1,-1,-1,-1,-2,0]
dims=[J.dimension(n) for n in representatives];par=[J.parity(n) for n in representatives]
def species(n):
 if n>=643:return 5+species(n-643)
 return 0 if n<180 else 1 if n<508 else 2 if n<553 else 3 if n<598 else 4
target=(0,0,1,2,0,0,0,0,0,0)
def projected_maps(packet):
 states={k:dict(v) for k,v in packet['states'].items()};phys=dict(packet['physical']['P_E0']);out={};signatures={};journals={}
 for label,FN,EN in [('Q0','F0','E0'),('Qu0_H','Fu0_0','Eu0_0'),('Qu0_M','Fu0_1','Eu0_1')]:
  sig=set();rows=[]
  for n in range(1286):
   if n<643:raw=J.decode(states[FN][n])
   else:
    nn=n-643;raw=J.decode(states[EN][nn])
    if label=='Q0' and nn<508:raw=w.plus(raw,J.decode(phys[nn]))
    raw=w.scale(raw,J.constant((-1)**J.parity(nn)))
   keep={};bad=[]
   for at,(ww,c) in enumerate(sorted(raw.items())):
    cnt=[0]*10;der=0
    for nn,js in ww:cnt[species(nn)]+=1;der+=len(js)
    if any(cnt[i]>target[i] for i in range(10)):bad.append(at);continue
    keep[ww]=c;sig.add((species(n),tuple(cnt),der))
   rows.append(dict(port=n,raw=J.encode(raw),selected=J.encode(keep),rejected_raw_indices=bad))
  out[label]=rows;signatures[label]=sig
 return out,signatures
def vectors(counts):return counts[0]+counts[5]
def lorentz(counts,jets):
 slots=[name+str(j) for name,c in zip(names,counts) for j in range(c)];n=len(slots);v=vectors(counts)
 if v==0 and jets==0:return dict(slots=slots,basis=['1'],relations=[],rank=0,quotient=1)
 if v==0 and jets==2:
  pairs=list(combinations_with_replacement(range(n),2));rows=[]
  for i in range(n):rows.append([int(i==a or i==b) for a,b in pairs])
  rank=s.Matrix(rows).rank();return dict(slots=slots,basis=[['p'+str(a),'p'+str(b)] for a,b in pairs],relations=rows,rank=rank,quotient=len(pairs)-rank)
 if v==1 and jets==1:return dict(slots=slots,basis=[['vector','p'+str(i)] for i in range(n)],relations=[[1]*n],rank=1,quotient=n-1)
 assert (v+jets)%2==1,('UNHANDLED_EVEN_LORENTZ_CLASS',counts,jets)
 return None
def all_counts(at=0,left=5,prefix=()):
 if at==10:yield prefix;return
 for n in range(left//dims[at]+1):yield from all_counts(at+1,left-n*dims[at],prefix+(n,))
def direct(sig):
 found={};rejected=[]
 for cnt in all_counts():
  if sum(a*b for a,b in zip(cnt,gh))!=1 or sum(a*b for a,b in zip(cnt,par))%2!=1:continue
  for intrinsic in [0,1]:
   jets=5-intrinsic-sum(a*b for a,b in zip(cnt,dims))
   if jets<0:continue
   matches=[]
   for n,outs,der in sig:
    if cnt[n] and tuple(cnt[i]-int(i==n)+outs[i] for i in range(10))==target:matches.append([n,list(outs),der])
   if not matches:continue
   assert all(jets+z[2]==2-intrinsic for z in matches)
   lift=lorentz(cnt,jets);key=(cnt,jets,intrinsic)
   if lift:found[key]=dict(counts=list(cnt),pattern=[names[i] for i,c in enumerate(cnt) for j in range(c)],jets=jets,intrinsic=intrinsic,images=matches,Lorentz=lift)
   else:rejected.append(dict(counts=list(cnt),jets=jets,intrinsic=intrinsic,reason='ODD_LORENTZ_RANK'))
 return found,rejected
def inverse(sig):
 out=set()
 for n,outputs,der in sig:
  cnt=tuple(target[i]-outputs[i]+int(i==n) for i in range(10))
  if min(cnt)<0:continue
  if sum(a*b for a,b in zip(cnt,gh))!=1 or sum(a*b for a,b in zip(cnt,par))%2!=1:continue
  for intrinsic in [0,1]:
   jets=5-intrinsic-sum(a*b for a,b in zip(cnt,dims))
   if jets>=0 and lorentz(cnt,jets):out.add((cnt,jets,intrinsic))
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'
 maps,sigs=projected_maps(load(old/'native_inputs.json.gz'));mapsR,sigsR=projected_maps(load(old/'replay_inputs.json.gz'));assert maps==mapsR and sigs==sigsR
 assert dims==[1,1,2,1,1,2,2,1,2,2] and par==[0,0,0,1,1,1,1,1,0,0]
 found={};rejected={};summary={}
 for label,sig in sigs.items():
  classes,bad=direct(sig);assert set(classes)==inverse(sig)
  found[label]=list(classes.values());rejected[label]=bad
  summary[label]=dict(patterns=len(classes),raw_Lorentz=sum(len(v['Lorentz']['basis']) for v in classes.values()),after_IBP=sum(v['Lorentz']['quotient'] for v in classes.values()),intrinsic1_patterns=sum(v['intrinsic']==1 for v in classes.values()))
 sourcefree={x for x in sigs['Q0'] if x[0]<5};sf,_=direct(sourcefree)
 linear={x for x in sigs['Q0'] if not(x[0]==9 and x[1][2])};lin,_=direct(linear)
 probe_field={label:direct({x for x in sig if x[0]<5})[0] for label,sig in sigs.items() if label!='Q0'}
 controls=dict(omit_sources_lost=[v['pattern'] for k,v in {(tuple(x['counts']),x['jets'],x['intrinsic']):x for x in found['Q0']}.items() if k not in sf],linearize_QJa_lost=[v['pattern'] for k,v in {(tuple(x['counts']),x['jets'],x['intrinsic']):x for x in found['Q0']}.items() if k not in lin],probe_field_only_counts={k:len(v) for k,v in probe_field.items()})
 assert summary['Q0']==dict(patterns=6,raw_Lorentz=22,after_IBP=12,intrinsic1_patterns=0)
 assert summary['Qu0_H']==dict(patterns=3,raw_Lorentz=15,after_IBP=8,intrinsic1_patterns=0)
 assert summary['Qu0_M']==dict(patterns=4,raw_Lorentz=18,after_IBP=9,intrinsic1_patterns=0)
 assert len(controls['omit_sources_lost'])==4 and len(controls['linearize_QJa_lost'])==1 and all(n==1 for n in controls['probe_field_only_counts'].values())
 out=dict(schema='ACTUAL_G1_CONSISTENCY_COMPANION_CARRIERS_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',species=[dict(name=n,representative=r,dimension=d,ghost=g,parity=p) for n,r,d,g,p in zip(names,representatives,dims,gh,par)],actual_projected_maps=maps,actual_map_signatures={label:[[i,list(c),j] for i,c,j in sorted(sig)] for label,sig in sigs.items()},census=found,odd_Lorentz_rejections=rejected,summary=summary,controls=controls,physical_potential_not_zeroed_support_exclusion=True,physical_K_fermion_target_exclusion_not_global_chiral_claim=True,all_source_operations_before_projection=True,all1286_ports_per_operator=True,direct_inverse_census_equal=True,counts_not_invariant_tensors_or_measured_amplitudes=True,no_quantum_coefficient_assigned=True,elapsed_after_imports=time.perf_counter()-tick)
 blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'census_tables.json.gz').open('xb') as h:h.write(blob)
 result={k:v for k,v in out.items() if k not in ['species','actual_projected_maps','actual_map_signatures','census','odd_Lorentz_rejections']};result['artifact_sha256']=sha256(blob).hexdigest()
 with (O/'census_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
