from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import json,os,threading,time
O=Path(__file__).resolve().parent
def add(*polys):
 out={}
 for p in polys:
  for k,c in p.items():out[k]=out.get(k,F(0))+c
 return {k:c for k,c in out.items() if c}
def scale(p,c):return {k:c*v for k,v in p.items() if c*v}
def mul(p,q):
 out={}
 for (g,u,x,y,m),c in p.items():
  for (h,v,xx,yy,n),d in q.items():
   if g+h>1 or u+v>1 or m&n:continue
   sign=(-1)**sum((n&((1<<i)-1)).bit_count() for i in range(5) if m&(1<<i))
   key=g+h,u+v,x+xx,y+yy,m|n;out[key]=out.get(key,F(0))+sign*c*d
 return {k:c for k,c in out.items() if c}
ONE={(0,0,0,0,0):F(1)}
def word(ids=(),c=1,g=0,u=0):
 out={(g,u,0,0,0):F(c)}
 for i in ids:out=mul(out,{(0,0,int(i==0),int(i==1),0 if i<2 else 1<<(i-2)):F(1)})
 return out
def partial(p,n):
 out={}
 for (g,u,x,y,m),c in p.items():
  if n<2:
   power=(x,y)[n]
   if not power:continue
   key=g,u,x-int(n==0),y-int(n==1),m;z=power*c
  else:
   bit=1<<(n-2)
   if not m&bit:continue
   key=g,u,x,y,m^bit;z=(-1)**((m&(bit-1)).bit_count())*c
  out[key]=out.get(key,F(0))+z
 return {k:c for k,c in out.items() if c}
def expminus(p):
 out=ONE;power=ONE
 for n in range(1,13):
  power=scale(mul(power,p),F(-1,n));out=add(out,power)
  if not power:break
 assert not power,'INCOMPLETE_FINITE_EXTERIOR_EXPONENTIAL'
 return out
@lru_cache(None)
def moment(n,cov):
 if n%2:return F(0)
 return F(1) if n==0 else (n-1)*cov*moment(n-2,cov)
def integrate(p):
 out={}
 for (g,u,x,y,m),c in p.items():
  if m&15!=15:continue
  value=c*moment(x,F(1,3))*moment(y,F(1,5));key=g,u,0,0,m^15
  out[key]=out.get(key,F(0))+value
 return {k:c for k,c in out.items() if c}
def inverse(p):
 base=p.get((0,0,0,0,0),F(0));assert base
 rest=add(scale(p,1/base),scale(ONE,-1));assert all(g+u>0 for g,u,x,y,m in rest)
 return scale(add(ONE,scale(rest,-1),mul(rest,rest)),1/base)
def encode(p):return [[list(k),c.numerator,c.denominator] for k,c in sorted(p.items())]
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=json.loads((O/'fixture_preparation.json').read_bytes())
 for n,h in prep['source_sha256'].items():assert sha256((O/n).read_bytes()).hexdigest()==h,n
 # x,y are0,1; internal c1,c2,a1,a2 are2..5; external theta is6.
 S0=add(word([0,0]),word([1,1],F(3,2)),word([4,2],2),word([5,3],3))
 R=add(word([0,0],F(1,2)),word([1,1]),word([4,2],F(1,2)),word([5,3],F(1,3)))
 ghostbase=add(word([4,2],F(5,2)),word([5,3],F(10,3)))
 Vg=add(word([0,1],F(1,2),g=1),word([4,3],F(2,3),g=1),word([6,0,4],g=1),word([6,1,3],2,g=1))
 Vu=add(word([0,0],F(1,3),u=1),word([1,1],F(1,4),u=1),word([5,2],F(1,5),u=1),word([4,2],F(1,7),u=1),word([6,1,5],F(3,2),u=1))
 Vgu=add(word([0,1],F(1,7),g=1,u=1),word([5,3],F(1,11),g=1,u=1),word([6,0,2],F(5,4),g=1,u=1),word([6,1,4],F(-2,5),g=1,u=1))
 V=add(Vg,Vu,Vgu);S=add(S0,V);W=expminus(add(ghostbase,V))
 assert W==mul(expminus(ghostbase),add(ONE,scale(V,-1),scale(mul(V,V),F(1,2))))
 invZ=inverse(integrate(W));expect=lambda p:mul(integrate(mul(p,W)),invZ)
 P=[add(word([2]),word([6,0],g=1),word([6,1],u=1),word([5],g=1,u=1)),
    add(word([3],2),word([6,1],g=1),word([4],-1,u=1),word([6,0],g=1,u=1)),
    add(word([0]),word([6,4],g=1),word([1],u=1),word([6,3],g=1,u=1)),
    add(word([1],2),word([6,3],g=1),word([0],u=1),word([6,5],g=1,u=1)),
    add(word([1]),word([6,4],-1,g=1),word([0],u=1),word([6,2],g=1,u=1)),
    add(word([0]),word([6,2],g=1),word([6,5],u=1),word([1],g=1,u=1))]
 assert all(m.bit_count()%2==0 for p in [S,R] for g,u,x,y,m in p)
 assert all(m.bit_count()%2==(1 if n<2 else 0) for n,p in enumerate(P) for g,u,x,y,m in p)
 currents=[];regs=[];divs=[];components=[]
 for n,p in enumerate(P):
  C=mul(p,partial(S,n));K=mul(p,partial(R,n));D=partial(p,n);currents.append(C);regs.append(K);divs.append(D)
  assert expect(add(C,K,scale(D,-1)))=={},('LEFT_IBP_COMPONENT',n)
  components.append(dict(component=n,parity=int(n>=2),current=encode(expect(C)),regulator=encode(expect(K)),local_trace=encode(expect(D))))
 C=add(*currents);K=add(*regs);D=add(*divs);actual=expect(C);rhs=expect(add(D,scale(K,-1)));assert actual==rhs and actual
 assert D and expect(D)
 Wbad=mul(expminus(ghostbase),add(ONE,scale(V,-1)));badZ=inverse(integrate(Wbad));badexpect=lambda p:mul(integrate(mul(p,Wbad)),badZ)
 zbase=integrate(W)[(0,0,0,0,0)]
 wrong=dict(omit_regulator=expect(add(C,scale(D,-1))),extra_odd_matrix_trace_sign=expect(add(C,K,scale(add(*(scale(d,-1 if n>=2 else 1) for n,d in enumerate(divs))),-1))),omit_partition_normalization=add(scale(integrate(mul(C,W)),1/zbase),scale(rhs,-1)),omit_mixed_exponential_weight=badexpect(add(C,K,scale(D,-1))),double_current_Hessian=expect(add(scale(C,2),K,scale(D,-1))))
 assert all(p for p in wrong.values()),'BLIND_WHOLE_FIXTURE_CONTROL'
 gu=lambda p:{k:v for k,v in p.items() if k[0:2]==(1,1)}
 out=dict(schema='LITERAL_FINITE_GAUSSIAN_CURRENT_IBP_FIXTURE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',components=components,whole_current=encode(actual),regulator_reduction=encode(rhs),nonzero_local_trace=encode(expect(D)),whole_weight=encode(W),partition=encode(integrate(W)),wrong_residuals={k:encode(p) for k,p in wrong.items()},mixed_gu_controls_sensitive={k:bool(gu(p)) for k,p in wrong.items()},literal_exterior_and_even_Gaussian_moments=True,extra_matrix_supertrace_sign_used=False,not_a_physical_parameter_point=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'fixture_result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,sort_keys=True);f.write('\n')
 print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','whole_current','nonzero_local_trace','mixed_gu_controls_sensitive','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
