from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/gaussian-current-reduction-g1-v1-2026-11-07')
spec=importlib.util.spec_from_file_location('gaussian_reduction_final_tools',O/'bridge.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
J=v.J
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['source_sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for obj in [prep,read(O/'fixture_preparation.json')]:
  for n,h in obj['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 pairs=[]
 for name in ['own_jet_trace','hessian_euler_rows']:
  a,b=O/('native_'+name+'.json.gz'),O/('replay_'+name+'.json.gz');assert a.read_bytes()==b.read_bytes();pairs.append(dict(name=name,sha256=digest(a)))
 trace=load(O/'native_own_jet_trace.json.gz');expected=['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']
 assert [z['state'] for z in trace['diagonals']]==[z['state'] for z in trace['totals']]==expected
 for diag,total in zip(trace['diagonals'],trace['totals']):
  rows=diag['all643_own_jet_derivatives'];assert [n for n,own in rows]==list(range(643)) and all(not own for n,own in rows)
  assert total['nonzero_diagonal_field_columns']==0 and not total['per_jet_total'] and total['total_trace_zero']
 bridge=load(O/'native_hessian_euler_rows.json.gz');rowcounts={}
 for name,rows in bridge['calculated_rows'].items():
  count=508 if name=='physical_E0' else 180 if name.startswith('physical_E1_B') else 643
  assert [n for n,raw in rows]==list(range(count));rowcounts[name]=count
  g=int(name in ['E1','Eu1_0','Eu1_1'] or name.startswith('physical_E1'))
  for n,raw in rows:
   for word,cells in raw:
    assert sum(1319<=i<1962 for i,js in word)==1 and all(key[0]==g for key,num,den in cells)
    assert sum(J.parity(i) for i,js in word)%2==J.parity(n)
 assert sum(rowcounts.values())==4726 and len(bridge['assessments'])==9 and all(z['complete_match'] for z in bridge['assessments'])
 del bridge;gc.collect()
 # Independently inspect the original complete F maps for each diagonal zero.
 old=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/native_GF_common.json.gz');states=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/native_new_states.json.gz')
 flows={'F0':old['F0'],'F1':states['F1']}
 for pr in [0,1]:flows['Fu0_'+str(pr)]=old['probes'][pr]['source_first_Fu'];flows['Fu1_'+str(pr)]=states['Fu1_'+str(pr)]
 for name,rows in flows.items():
  assert [n for n,raw in rows]==list(range(643))
  for n,raw in rows:assert all(all(i!=n for i,js in word) for word,cells in raw),'ACTUAL_OWN_FIELD_DEPENDENCE'
 assert all(not raw for n,raw in flows['F0'] if 180<=n<508)
 for name in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not raw for n,raw in flows[name] if n<508)
 del old,states,flows;gc.collect()
 f=read(O/'fixture_result.json');assert f['execution_state']=='COMPLETED' and len(f['components'])==6
 assert f['literal_exterior_and_even_Gaussian_moments'] and not f['extra_matrix_supertrace_sign_used'] and f['not_a_physical_parameter_point']
 assert f['whole_current']==f['regulator_reduction'] and f['nonzero_local_trace'] and all(f['wrong_residuals'].values())
 assert f['mixed_gu_controls_sensitive']=={'double_current_Hessian':True,'extra_odd_matrix_trace_sign':False,'omit_mixed_exponential_weight':True,'omit_partition_normalization':True,'omit_regulator':True}
 expected_fixture=[[[0,1,0,0,16],-63,50],[[1,0,0,0,16],143,150],[[1,1,0,0,16],16963,189000]];assert f['whole_current']==expected_fixture
 resources={}
 for stage,limit in [('native_bridge',180),('replay_bridge',180),('fixture',60)]:
  cap=read(O/(stage+'_capture.json'));res=read(O/(stage+'_result.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['execution_state']=='COMPLETED' and cap['post_run_observations_qualified']
  assert res['elapsed_after_imports']<=limit and cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
  resources[stage]=dict(seconds_after_imports=res['elapsed_after_imports'],largest_private_sample=max(z['private_bytes'] for z in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 print('STAGE final paired4726 rows,all643 actual diagonal zeros,support and literal fixture verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
 assert next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V790.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2
 result=dict(schema='GAUSSIAN_CURRENT_REDUCTION_G1_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_ACTUAL_FINITE_GAUSSIAN_OPERATOR_BRIDGE_AND_ZERO_JACOBIAN',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,paired_math=pairs,complete_bridge_rows=rowcounts,bridge_rows_total=4726,diagonal_columns_per_map=643,flow_maps=6,all_actual_own_jet_diagonals_identically_zero=True,actual_diagonal_sign_controls_blind=True,literal_fixture_nonzero_local_trace=True,literal_wrong_controls_all_nonzero=True,literal_mixed_gu_blind_control='EXTRA_ODD_MATRIX_TRACE_SIGN',resources=resources,failures_this_increment=0,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,actual_color_loop_amplitudes_or_QAP_E5_or_viability_claim=False)
 dump(O/'validation_receipt.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
