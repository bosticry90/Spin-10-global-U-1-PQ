from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/gaussian-current-reduction-g1-v1-2026-11-07')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'fixture_preparation.json').exists()
pairs=[]
for name in ['own_jet_trace','hessian_euler_rows']:
 a,b=O/('native_'+name+'.json.gz'),O/('replay_'+name+'.json.gz');assert a.read_bytes()==b.read_bytes();pairs.append(dict(native=a.name,replay=b.name,sha256=digest(a)))
for role in ['native','replay']:
 cap=json.loads((O/(role+'_bridge_capture.json')).read_bytes());assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
for n in ['FIXTURE_RECORD.md','fixture.py','run_fixture.py']:
 with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
dump(O/'fixture_preparation.json',dict(source_sha256={n:digest(O/n) for n in ['FIXTURE_RECORD.md','fixture.py','run_fixture.py']},paired_bridge_math=pairs))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'fixture.py')]);dump(O/'fixture_capture.json',cap);dump(C/'fixture_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
