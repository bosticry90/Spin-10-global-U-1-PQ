from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
spec=importlib.util.spec_from_file_location('gaussian_bridge_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/('physical_v2.py' if ROLE=='native' else 'physical_v4.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=w.J
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
def save(name,data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as f:f.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_GAUSSIAN_BRIDGE_READ_DENIED'
 sys.addaudithook(guard)
 old=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1';full=O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'
 common=load(old/(ROLE+'_GF_common.json.gz'));states=load(full/(ROLE+'_new_states.json.gz'))
 for n in ['F0','E0']:states[n]=common[n]
 for pr in [0,1]:states['Fu0_'+str(pr)]=common['probes'][pr]['source_first_Fu'];states['Eu0_'+str(pr)]=common['probes'][pr]['full_Eu']
 factors=load(full/(ROLE+'_raw_T1_factors.json.gz'));trace_rows=[];total_trace=[]
 for state in ['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  mapping=dict(factors[state] if ROLE=='native' else states[state]);rows=[];totals={}
  for n in range(643):
   P=J.decode(mapping[n]);index=1319+n if ROLE=='native' else n
   jets=sorted({js for word in P for i,js in word if i==index});own=[]
   for js in jets:
    partial=J.leftjet(P,(index,js));own.append([list(js),J.encode(partial)]);J.add(totals.setdefault(js,{}),partial)
   rows.append([n,own])
  trace_rows.append(dict(state=state,all643_own_jet_derivatives=rows))
  total_trace.append(dict(state=state,per_jet_total=[[list(js),J.encode(J.clean(P))] for js,P in sorted(totals.items())],nonzero_diagonal_field_columns=sum(any(raw for js,raw in own) for n,own in rows),total_trace_zero=not any(J.clean(p) for p in totals.values())))
 trace=save('own_jet_trace',dict(diagonals=trace_rows,totals=total_trace,no_extra_matrix_supertrace_sign=True,own_jets_not_integrated_by_parts=True))
 del trace_rows,total_trace,mapping,totals,P;gc.collect()
 print('STAGE '+ROLE+' all643 actual own-jet Jacobian columns',flush=True)
 actual=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0 if ROLE=='native' else 1]
 densities={'E0':J.decode(actual['original'][0]['density'])}
 for pr in [0,1]:densities['Eu0_'+str(pr)]=J.decode(common['probes'][pr]['U'])
 del actual,common;gc.collect()
 calculated={};assessments=[]
 cases=[('E0',None),('E1','S1'),('Eu0_0',None),('Eu0_1',None),('Eu1_0','U1_0'),('Eu1_1','U1_1')]
 for state,ordinary in cases:
  if ordinary is None:half=w.scale(v.tangent(v.tangent(densities[state])),J.constant(F(1,2)))
  else:half=J.decode(load(full/(ROLE+'_ordinary_'+ordinary+'.json.gz'))['quadratic_Taylor_half'])
  grad=J.euler(half,set(range(1319,1962)));expected=dict(factors[state]);rows=[]
  for n in range(643):
   computed=grad.get(1319+n,{});assert computed==J.decode(expected[n]),('GF_HESSIAN_EULER_BRIDGE',state,n)
   rows.append([n,J.encode(computed)])
  calculated[state]=rows;assessments.append(dict(owner='GF',state=state,columns=643,complete_match=True))
  del half,grad,expected,rows;gc.collect()
  print('STAGE '+ROLE+' whole GF Hessian/Euler bridge '+state,flush=True)
 del factors,densities,states;gc.collect()
 phys=O.parent/'canonical_so10_physical_current_input_recovery_g1_v1';prefix='native_v2_' if ROLE=='native' else 'replay_v4_'
 action=load(phys/(prefix+'action.json.gz'));eulers=load(phys/(prefix+'euler.json.gz'))
 half=w.scale(v.tangent(v.tangent(w.plus(J.decode(action['S0_gauge']),J.decode(action['S0_scalar'])))),J.constant(F(1,2)))
 grad=J.euler(half,set(range(1319,1827)));expected=dict(eulers['E0']);rows=[]
 for n in range(508):
  computed=grad.get(1319+n,{});assert computed==v.tangent(J.decode(expected[n])),('PHYSICAL_G0_HESSIAN_EULER_BRIDGE',n);rows.append([n,J.encode(computed)])
 calculated['physical_E0']=rows;assessments.append(dict(owner='physical',state='E0',columns=508,complete_match=True))
 del half,grad,expected,rows;gc.collect()
 for owner in ['gauge','scalar']:
  half=J.decode(load(phys/(prefix+'ordinary_'+owner+'.json.gz'))['quadratic_Taylor_half']);grad=J.euler(half,set(range(1319,1499)));expected=dict(eulers['E1_B_'+owner]);rows=[]
  for n in range(180):
   computed=grad.get(1319+n,{});assert computed==v.tangent(J.decode(expected[n])),('PHYSICAL_G1_HESSIAN_EULER_BRIDGE',owner,n);rows.append([n,J.encode(computed)])
  calculated['physical_E1_B_'+owner]=rows;assessments.append(dict(owner='physical_'+owner,state='E1_B',columns=180,complete_match=True))
  del half,grad,expected,rows;gc.collect()
  print('STAGE '+ROLE+' physical Hessian/Euler bridge '+owner,flush=True)
 newrows=save('hessian_euler_rows',dict(calculated_rows=calculated,assessments=assessments,remaining_physical_g1_scalar_rows_not_needed_because_F0_x_and_Fu0_x_zero=True))
 result=dict(schema='ACTUAL_CURRENT_GAUSSIAN_HESSIAN_JACOBIAN_BRIDGE_V1',route=ROLE,trace=trace,hessian_rows=newrows,all643_GF_columns_per_state=True,GF_states=6,physical_E0_columns=508,physical_E1_B_columns_per_owner=180,elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED')
 dump(O/(ROLE+'_bridge_result.json'),result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
