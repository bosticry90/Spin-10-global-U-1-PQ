# Exact finite-Gaussian reduction of the recovered current

The V789 first-u,g1 current covariance can be reduced to a regulator
insertion in the qualified integrated Gaussian domain. This combines its
marked-Euler and ordinary-inverse routes before their color/profile
evaluation. It does not set the106 vector or12 source candidates, or their
sum, to zero. The remaining regulator contraction still needs calculation.

## Graded identity and exact scope

Work first in a finite set of fluctuation modes eta_z with the same parity
p_z as their original fields. Mean fields and all BV sources are fixed
graded coefficients. Let S2=T1^2 S/2 be the quadratic action, P_z=T1F_z,
and R2 the additional fixed quadratic inverse-kernel term in the qualified
Gaussian. Write H_z=ELleft_eta_z S2 and L_z=ELleft_eta_z R2. In the
normalized Gaussian Wick functional, left integration byparts gives

    0 = < partialleft_eta_z P_z - P_z (H_z+L_z) >,

because parity(P_z)=p_z+1 and p_z(p_z+1) is even. Therefore

    <sum_z P_z H_z> = <sum_z partialleft_eta_z P_z>
                       - <sum_z P_z L_z>.

LEFT differentiation already accounts for moving an odd derivative past
odd external coefficients. An additional hand-inserted matrix supertrace
sign would double-count that sign. The explicit exterior fixture below
tests this choice. The identity is also the defining algebraic Wick
integration-byparts relation for a nonsingular formal graded Gaussian;
it does not require adopting a positive real physical Lambda contour or
a nonperturbative measure. No QAP theorem follows from this finite identity.

The current in V789 is sum(T1F_z)(T1E_z). Its identification with the
left side requires the actual operator bridge

    T1(ELleft_z S) = ELleft_eta_z(T1^2 S/2).

Jets are treated as local independent coordinates while deriving the
functional Euler operators, and spacetime integration byparts uses the
same integrated constant-mark domain already qualified in V787-V789.
No individual free factor is set to zero. A nonconstant local mark would
retain its gradient-current contributions and is outside this reduction.

At selected firstg/firstu and target mean degree3 the inverse expansion has
finitely many relevant words, with V789's complete bound of six vertices.
The identity is a formal coefficient identity for this bounded Gaussian
expansion. It does not infer an infinite all-source resummation, exchange
UV/IR limits or add normalization counterterms. Continuum profile evaluation
and any limiting trace interchange remain separate calculation obligations.

## Actual operator and Jacobian evidence

Native takes own-jet LEFT derivatives from the complete saved T1F factors.
Replay differentiates the full original F maps directly, without reading
native output. Both include all643 fields and full sources/means, separately
for F0,F1,Fu0_H,Fu0_M,Fu1_H,Fu1_M and each possible own-jet order. The
own-jet derivative is retained as an operator coefficient, not replaced by
a functional Euler derivative that could hide cancellations among jets.

Every diagonal field column is identically zero, before summing over z,
in all six maps. There are no residual own-jet entries. Thus the local
Jacobian vanishes throughout the actual firstg/firstu input, without an
extra regulator-dependent cancellation or assumed anomaly subtraction.
The complete paired trace artifact is byte-identical, SHA
ea4cec57a6817479d2939cd540ef091097f6f1d4044d41c9eb6bc1a20e712edb.
Omitting a diagonal trace column or reversing its sign is blind in these
actual zero data; this limitation is not called a sensitive control.

Both routes then compute the new Hessian/Euler bridge rows and compare
them to the existing complete T1E data. These are new operator bridges,
not reruns of the physical or fullcurrent factories. They verify all643
GF/probe columns for E0,E1,Eu0_H,Eu0_M,Eu1_H,Eu1_M; all508 physical
kinetic E0 columns; and180 physical E1_B columns for each gauge/scalar
owner. Total4726 rows. Native prefix and replay LEFT tangent methods are
distinct; the sourceful action, graded polynomial ring and Euler software
remain shared. Complete new rows are byte-identical, SHA
22f4053735e19c17f02c2e0bb52cf28d89c91421b39c0b70025bbf9d30950ee9.

Physical g1 scalar Euler rows beyond the B rows are not claimed absent.
They do not enter this current coefficient because actual F0_x=Fu0_x=0.
Actual probe flows vanish in all508 physical field columns also at g1.
Physical F1_x E0_x is retained by the verified508-row free bridge. The
previous V787 potential exclusions at intrinsic0/1 and zero scalar mean
are reused in their declared domain; no Yukawa/flavor or changed-vacuum
extension is made. All full physical marked and ordinary owners from
V789 are included in the identity, even though the regrouped formula
does not display each of their52 candidate paths separately.

## Literal exterior and even-Gaussian sign fixture

A separate Fraction-based implementation uses two bosons,four internal
odd modes and one external odd coefficient. It does not use the jet or
coefficient-ring software. A finite exterior exponential and exact even
Gaussian moments produce the normalized covariance for independent firstg,
firstu and mixedgu vertices. Each of the six component identities is
checked, including a deliberately nonzero local Jacobian. The exact whole
current, in units of the external odd coefficient theta, is

    (143/150)g - (63/50)u + (16963/189000)gu,

while the local Jacobian is theta*(2g-u). The current equals Jacobian
minus regulator contraction coefficient by coefficient. Literal full
exponentiation also equals the product of the free exterior exponential
and 1-V+V^2/2 at the selected degrees.

All five whole-fixture negative controls have nonzero exact residuals:
omit the regulator, add the extra odd matrix trace sign, omit the
perturbative partition denominator after correct free normalization,
omit the mixed VgVu exponential contribution, or double the current
Hessian. Four are sensitive at gu. The extra odd trace-sign control is
sensitive at g/u and blind at gu because this fixture's local Jacobian
has no gu coefficient; the complete residuals disclose this blind slice.
These rational Hessians are mathematical fixtures, not physical benchmarks.

## Consequence for the next actual contraction

For the actual recovered maps the qualified covariance is therefore

    current = - <sum_z (T1F_z) ELleft_eta_z R2>.

R2 must be the difference between the ACTUAL qualified regulated quadratic
inverse and the physical free quadratic action used in S2. With a heat-only
physical inverse this can be written through E^{-1}-1. With an IR mass or
additional profile f it also contains their inverse defect. The identity
does not permit replacing the regulated inverse by the physical one,
dropping (1-f) pieces, setting heat factors to one, or changing UV-first/IR
limit order. This restriction preserves the finite-profile obligations
already encountered in V783/V786. No finite contact or baseline is fitted.

This is a conditional structural reduction of the full Gaussian current,
with its concrete action/flow bridge verified. It does not numerically
evaluate the remaining tensor. Next build this actual regulator insertion
from the qualified free inverse, with exact odd order and all source ports;
compare its expanded contractions to the already frozen V789 covariance
representation before reading a same-parent QGamma/D target. Begin with
color and momentum-polynomial zeros, then retain all finite heat profiles
and nonlocal terms in the remaining integral comparison.

Native69.129320s,replay65.249359s completed under180s each; fixture
0.035900s under60s. All serial,8GiBsampled/350MiBfloor/64MiBcomplete
newpacket. Final receipt owns binding,complete-row/zero/support,resource,
state/oldtree and E4once/no-fresh checks, with0,0,0,0,0,2 and seven
unresolved custody references NOTPASS. No failed worker this increment.

This demonstrates an exact regrouping with actual-input and independent
small-algebra checks. It does not establish independent scientists: action,
frame,source data,Euler software and AI author are shared. No outside
scientist,proof kernel or empirical test is claimed. Scientific acceptance
is not performed. State113/34of39,E5/A5,common normalization/reality,QAP,
measure/equivalence,physical viability and the full investigation stay open.
