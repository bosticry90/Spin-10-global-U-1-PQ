# Literal Gaussian identity sign fixture, prospective

Use an exact finite exterior algebra independent of the jet/coefficient-ring
software, two independent even Gaussian moments and four internal odd modes,
one external odd coefficient. Rational reference Hessians(3,5) and ghost
masses(5/2,10/3) are mathematical fixtures, not physical parameter points.
Keep exact independent firstg/firstu bookkeeping including mixedgu vertices.
The whole exponential ends finitely in g,u and internal exterior degree;
no terms may be silently truncated beyond the explicitly selectedg<=1,u<=1.

Check per-component LEFT integration byparts and whole current plus regulator
equals actual local Jacobian. The fixture deliberately retains nonzero local
trace. Test omitted regulator, extra odd supertrace sign, omitted normalization,
missing mixed exponential weight and doubled Hessian. Serialize all exact
differences and blind coefficient positions; nonzero wrong controls do not
validate physical assumptions. General identity must have an analytic proof.

One60s worker afterimports,8GiBsampled/350MiBfloor/existing64MiBnewpacket;
serial only after both bridge outputs complete and compared. Preserve any
failed/incomplete source/capture. Full factory/physical inputs are not rerun.
