# Current covariance reduced to a regulator insertion

The actual input bridge is verified in4726 Hessian/Euler rows. Two complete
calculations agree and find every diagonal own-jet Jacobian column zero
for all643 fields across all six original/probe flow maps. A separate exact
exterior/Boson Gaussian fixture verifies the left-derivative signs,
normalization and mixed insertion weights, retaining a nonzero test Jacobian.

In the qualified integrated first-u,g1 Gaussian domain, the recovered
current covariance equals minus the contraction of T1F with the quadratic
regulator's Euler derivative. This combines the original marked-Euler and
ordinary-inverse routes. It does not say their remaining amplitude is zero.
The actual regulated inverse, IR defects and finite heat profiles still
belong in that contraction. The [proof](PROOF.md) gives the identity, actual
bridge, sign controls, domain and dependencies; the [receipt](validation_receipt.json)
owns final validation and resources.

Next evaluate the regulator insertion's actual colors/derivatives/profiles
and reconcile its expansion with V789's frozen106 vector/12 source candidate
representation before same-parent target comparison. No normalization,
physical benchmark or E5/A5 promotion is adopted. State113/34of39 and
custody exit2/seven NOTPASS remain unchanged; the investigation is active.
