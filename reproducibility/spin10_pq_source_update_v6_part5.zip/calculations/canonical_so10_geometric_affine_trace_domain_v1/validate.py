from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-affine-trace-domain-v1-2026-11-08')
sys.path.insert(0,str(B/'canonical_so10_geometric_ward_current_source_chart_v1'));import algebra as a
sp=importlib.util.spec_from_file_location('V860_FROZEN_FRACTION_DERIVATIVE_CODEC',B/'canonical_so10_geometric_ward_current_source_chart_v1/validate_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
sp=importlib.util.spec_from_file_location('V860_FROZEN_GRADED_ACTION',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
H=1298;K=1941
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def grouped(q):
    out={}
    for(w,(g,x,e,m)),cv in q.items():a.put(out,(g,w),(((x,e,m),cv),))
    return out
def polar(q,offset,par):
    out={}
    for(w,k),cv in q.items():
        for at,(n,js)in enumerate(w):
            if n<643:
                ww,sg=v.canon(w[:at]+((offset+n,js),)+w[at+1:],par)
                if sg:v.add(out,(ww,k),sg*cv)
    return out
def kernel(P,par):return polar(polar(v.flat(a.encode(P)),H,par),K,par)
def carrier(i):
    if i<180:return 'B_mu'+str(i%4)
    if i<508:return 'Phi'if i<234 else'Sigma'if i<486 else'phi'if i<506 else'S'
    return 'light_aux'if i<520 else'heavy_aux'if i<553 else'ghost'if i<598 else'light_anti'if i<610 else'heavy_anti'
def matrices_from_Eulers(T,A):
    M=[{}for h in range(12)];aff={};decomp=[]
    for i in range(643):
        E=v.allE(v.flat(a.encode(T[i])),A.parities);lin={}
        for j,q in E.items():
            assert j<643
            for(w,(g,x,e,mask)),cv in q.items():
                assert g==1 and len(w)==1 and 1286<=w[0][0]<H and not w[0][1];h=w[0][0]-1286;a.put(M[h],(i,j),(((x,e,mask),cv),));ww,sg=A.canonical(((j,()),w[0]));assert sg==1;a.put(lin,(g,ww),(((x,e,mask),cv),))
        rest=a.plus(T[i],a.scale(lin,-1));assert all(not any(n<1286 for n,js in w)for(g,w),co in rest.items());aff[i]=rest;decomp.append([i,a.encode(rest),a.encode(lin)])
    return M,aff,decomp
def ell(A,mats,offset):
    rules={}
    for h,M in enumerate(mats):
        for(i,j),co in M.items():
            ww,sg=A.canonical(((offset+j,()),(1286+h,())));assert sg==1;a.put(rules.setdefault(offset+i,{}),(1,ww),co)
    return rules
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='438c79bddaccd1d30511c737ba64f4324a21c28d'
    for n,h in a.read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=a.read(O/'preparation.json');assert prep==a.read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=a.read(O/'input_encoding_bindings.json');assert enc==a.read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256']and row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    cap=a.read(O/'capture.json');assert cap==a.read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=a.read(O/'result.json');assert result['elapsed_after_imports']<180;summaries=[];peers=[]
    for rr,owner in zip(result['roles'],['primary','replay']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']<=8*1024**2;z=a.load(O/art['file']);peers.append(z);ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));names=ch['all_current_names']+['h_'+s for s in ch['all_current_names'][:643]]+['k_'+s for s in ch['all_current_names'][:643]];pars=ch['all_current_parities']+ch['all_current_parities'][:643]+ch['all_current_parities'][:643];assert names==z['current_plus_two_even_polarization_alphabet']and pars==z['current_plus_two_polarization_parities'];A=a.Algebra(names,pars);T={i:a.decode(q)for i,q in ch['all1286_direct_Tq_columns']};mats,aff,decomp=matrices_from_Eulers(T,A);assert decomp==z['all643_affine_field_decompositions'];encoded=[[[i,j,[[list(k),cv.numerator,cv.denominator]for k,cv in co]]for(i,j),co in sorted(M.items())]for M in mats];assert encoded==z['all12_complete_internal_matrices'];traces=[]
        for h,M in enumerate(mats):
            for(i,j),co in M.items():
                assert not any(k[2]&16 for k,cv in co)and M.get((j,i),())==a.scale_coefficient(co,-1)and carrier(i)==carrier(j)
                if i<180:assert(i//4<12)==(j//4<12)
                if 553<=i<598:assert(i-553<12)==(j-553<12)
            for block in sorted({carrier(i)for i in range(643)}):assert all(not M.get((i,i),())for i in range(643)if carrier(i)==block);traces.append([h,block,0])
        assert len(traces)==156 and traces==z['all156_heat_carrier_diagonal_traces']and sum(map(len,mats))==rr['internal_matrix_entries']==7800 and sum(bool(q)for q in aff.values())==rr['nonzero_affine_field_columns']==48
        for i in range(643,1286):assert all(not any(n<643 for n,j in w)for(g,w),co in T[i].items())
        eh=ell(A,mats,H);ek=ell(A,mats,K)
        for i in range(1286):
            rhs=eh.get(H+i,{})if i<643 else{};assert polar(v.flat(a.encode(T[i])),H,pars)==v.flat(a.encode(rhs))
            for mu in range(4):assert polar(v.de(v.flat(a.encode(T[i])),mu,pars),H,pars)==v.de(v.flat(a.encode(rhs)),mu,pars)
        fixture=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_H_even_geometric_insertion_v2.json.gz'));U=a.decode(fixture['complete_selected_U']);f=z['actual_source_quadratic_fixture'];assert U==a.decode(f['complete_U'])and any(sum(643<=n<1286 for n,j in w)>=2 for(g,w),co in U.items());HU=kernel(U,pars);assert HU==v.flat(f['complete_H_U']);other='replay'if owner=='primary'else'primary';TU=p.action(A,U,T,other);left=kernel(TU,pars);right=a.plus(p.action(A,grouped(HU),T,other),p.action(A,grouped(HU),eh,other),p.action(A,grouped(HU),ek,other));assert left==v.flat(a.encode(right))==v.flat(f['complete_H_T_U'])==v.flat(f['complete_T_HU_plus_two_ell_legs'])
        lifted=a.load(B/'canonical_so10_geometric_metric_insertion_lift_v1'/(role+'_complete_geometric_metric_insertions.json.gz'));roots={q['name']:a.decode(q['complete_Euclidean'])for q in lifted['all_fixed_density_roots']};costs=Counter();wordcounts={}
        for block in z['all_C_root_ordered_bilinears']:
            name=block['name'];HH=kernel(roots[name],pars);assert HH==v.flat(block['complete_ordered_h_k_bilinear']);meta=[];Q=grouped(HH)
            for(g,w),co in sorted(Q.items()):
                hs=[(n-H,j)for n,j in w if H<=n<K];ks=[(n-K,j)for n,j in w if K<=n<K+643];assert len(hs)==len(ks)==1;i,ji=hs[0];j,jj=ks[0];cost=4-p.dim(i)-p.dim(j)-len(ji)-len(jj);assert cost>=0 and sum(1286<=n<H for n,js in w)==1;costs[cost]+=1;meta.append([g,i,list(ji),j,list(jj),cost,[[n,list(js)]for n,js in w if n<H]])
            assert meta==block['all_UV_cost_and_label_rows'];wordcounts[name]=len(Q)
        assert dict(costs)=={1:4032}and{str(k):cv for k,cv in costs.items()}==rr['UV_cost_histogram']and wordcounts==rr['C_kernel_words']=={'C_S':1152,'C_U_H':2880,'C_U_M':0}
        base=a.load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S0={k:cv for k,cv in a.decode(base['complete_current_GF_source_base']).items()if k[0]==0};HS0=kernel(S0,pars);hidden={key:cv for key,cv in HS0.items()if any(553<=n<643 for n,j in key[0])};assert hidden==v.flat(z['complete_hidden_g0_ordinary_ghost_H_S0'])and len(grouped(hidden))==rr['hidden_g0_ghost_Hessian_words']==2400;assert z['local_UV_bound']==7 and z['UV_grade_budget']==['g','u','t']and z['hidden_g0_Green_NOT_replaced_by_free_inverse'];summaries.append(dict(role=role,all1286_affine_commutators_and_firstjets_checked=True,internal_entries=7800,heat_carrier_trace_checks=156,full_C_bilinear_words=wordcounts,all4032_kernel_words_keep_local_omega=True,hidden_g0_ghost_Hessian_words=2400));print('STAGE '+role+' independent_affine_matrix_and_Fraction_kernel_checks_complete',flush=True)
    assert peers[0]==peers[1]
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V860.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V860.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V860.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2;files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V860.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_GEOMETRIC_AFFINE_OPERATOR_AND_COEFFICIENTWISE_TRACE_DOMAIN',base_HEAD=head,state_sha256=state,roles=summaries,analytic_IR_UV_and_symmetric_heat_premises_reused_NOT_new_integrals=True,local_UV_bound=7,actual_full_mean_G0_hidden_ghosts_preserved=True,raw_regulator_defect_and_both_first_U_terms_NOT_zeroed=True,actual_unselected_profiles_joint_contacts_full_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_input_codec_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
