from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/geometric-affine-trace-domain-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V860_FROZEN_GRADED_ACTION_CODEC',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
H=1298;K=1941
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    return dict(file=n,bytes=len(blob),sha256=digest(O/n))
def grade(P,g):return {k:v for k,v in P.items()if k[0]==g}
def act(A,P,rules,role):return p.action(A,P,rules,role)
def carrier(i):
    if i<180:return 'B_mu'+str(i%4)
    if i<508:
        return 'Phi'if i<234 else'Sigma'if i<486 else'phi'if i<506 else'S'
    if i<553:return 'light_aux'if i<520 else'heavy_aux'
    if i<598:return 'ghost'
    return 'light_anti'if i<610 else'heavy_anti'
def polar(A,P,which,method):return A.action(P,{i:which+i for i in range(643)},method=method)
def matrix_and_affine(A,T):
    mats=[{}for h in range(12)];affine={};rows=[]
    for i in range(643):
        v={};lin={}
        for(g,w),co in T[i].items():
            fields=[(at,n,j)for at,(n,j)in enumerate(w)if n<643];assert not any(643<=n<1286 for n,j in w)and len(fields)<=1
            if not fields:
                for k,cv in{(g,w):co}.items():a.put(v,k,cv)
            else:
                at,j,js=fields[0];assert not js;remaining=w[:at]+w[at+1:];assert len(remaining)==1 and remaining[0][0]>=1286 and not remaining[0][1]and g==1;h=remaining[0][0]-1286;assert 0<=h<12;a.put(mats[h],(i,j),co);a.put(lin,(g,w),co)
        affine[i]=v;rows.append([i,a.encode(v),a.encode(lin)])
    return mats,affine,rows
def conj(co):return tuple((k,-v if k[2]&16 else v)for k,v in co)
def kernel(A,P,method):return polar(A,polar(A,P,H,method),K,method)
def ell_rules(A,mats,offset):
    out={offset+i:{}for i in range(643)}
    for h,M in enumerate(mats):
        for(i,j),co in M.items():
            ww,sg=A.canonical(((offset+j,()),(1286+h,())));assert sg==1;a.put(out[offset+i],(1,ww),co)
    return out
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    roles=[]
    for role,owner in[('native','primary'),('replay','replay')]:
        ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));names=ch['all_current_names'];pars=ch['all_current_parities'];A=a.Algebra(names+['h_'+s for s in names[:643]]+['k_'+s for s in names[:643]],pars+pars[:643]+pars[:643]);T={i:a.decode(q)for i,q in ch['all1286_direct_Tq_columns']};mats,affine,decomp=matrix_and_affine(A,T);matrixrows=[];trace=[]
        for h,M in enumerate(mats):
            for(i,j),co in M.items():assert co==conj(co)and M.get((j,i),())==a.scale_coefficient(co,-1)and carrier(i)==carrier(j)
            # B,C,a heat color projectors must also preserve H12/M33.
            for(i,j),co in M.items():
                if i<180:assert(i//4<12)==(j//4<12)
                if 553<=i<598:assert(i-553<12)==(j-553<12)
            for block in sorted({carrier(i)for i in range(643)}):
                diagonals=[M.get((i,i),())for i in range(643)if carrier(i)==block];assert not any(diagonals);trace.append([h,block,0])
            matrixrows.append([[i,j,[[list(k),v.numerator,v.denominator]for k,v in co]]for(i,j),co in sorted(M.items())])
        assert len({carrier(i)for i in range(643)})==13 and len(trace)==156
        assert all(not any(n<643 for n,j in w)for i in range(643,1286)for(g,w),co in T[i].items())
        ellH=ell_rules(A,mats,H);ellK=ell_rules(A,mats,K);method='slot'if owner=='primary'else'left'
        # Complete generator and first-jet commutator,source-polynomial safe.
        for n in range(1286):
            lhs=polar(A,T[n],H,method);rhs=ellH.get(H+n,{})if n<643 else{};assert lhs==rhs
            for mu in range(4):assert polar(A,a.derivative(A,T[n],mu),H,method)==a.derivative(A,rhs,mu)
        fixture=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_H_even_geometric_insertion_v2.json.gz'));U=a.decode(fixture['complete_selected_U']);HU=kernel(A,U,method);left=kernel(A,act(A,U,T,owner),method);right=a.plus(act(A,HU,T,owner),act(A,HU,ellH,owner),act(A,HU,ellK,owner));assert left==right,'ACTUAL_SOURCE_QUADRATIC_AFFINE_CONGRUENCE_FAILED';assert any(sum(643<=n<1286 for n,j in w)>=2 for(g,w),co in U.items())
        lifted=a.load(B/'canonical_so10_geometric_metric_insertion_lift_v1'/(role+'_complete_geometric_metric_insertions.json.gz'));roots={q['name']:a.decode(q['complete_Euclidean'])for q in lifted['all_fixed_density_roots']};kernels=[];costs=Counter()
        for name in['C_S','C_U_H','C_U_M']:
            HH=kernel(A,roots[name],method);metadata=[]
            for(g,w),co in sorted(HH.items()):
                hs=[(n-H,j)for n,j in w if H<=n<K];ks=[(n-K,j)for n,j in w if K<=n<K+643];assert len(hs)==len(ks)==1;assert sum(1286<=n<H for n,j in w)==1;i,ji=hs[0];j,jj=ks[0];q=len(ji)+len(jj);cost=4-p.dim(i)-p.dim(j)-q;assert cost>=0;costs[cost]+=1;other=[(n,js)for n,js in w if n<H];assert other and any(1286<=n<1298 for n,js in other);metadata.append([g,i,list(ji),j,list(jj),cost,[[n,list(js)]for n,js in other]])
            kernels.append(dict(name=name,complete_ordered_h_k_bilinear=a.encode(HH),all_UV_cost_and_label_rows=metadata,source_and_mean_dependence_NOT_restricted=True))
        base=a.load(B/'canonical_so10_geometric_base_Noether_interface_v1'/(role+'_complete_geometric_base_Noether_interface.json.gz'));S0=grade(a.decode(base['complete_current_GF_source_base']),0);HS0=kernel(A,S0,method);hidden={k:co for k,co in HS0.items()if any(553<=n<643 for n,j in k[1])};assert hidden,'HIDDEN_G0_GHOST_MEANS_WERE_DELETED'
        record=dict(current_plus_two_even_polarization_alphabet=names+['h_'+s for s in names[:643]]+['k_'+s for s in names[:643]],current_plus_two_polarization_parities=list(A.parities),all643_affine_field_decompositions=decomp,all12_complete_internal_matrices=matrixrows,all156_heat_carrier_diagonal_traces=trace,full1286_generator_and_all_firstjet_commutators_zero=True,actual_source_quadratic_fixture=dict(complete_U=a.encode(U),complete_H_U=a.encode(HU),complete_H_T_U=a.encode(left),complete_T_HU_plus_two_ell_legs=a.encode(right)),all_C_root_ordered_bilinears=kernels,complete_hidden_g0_ordinary_ghost_H_S0=a.encode(hidden),hidden_g0_Green_NOT_replaced_by_free_inverse=True,local_UV_bound=7,UV_grade_budget=['g','u','t'],zero_cost_omega_roots_consume_first_t=True,all_G_quantum_D_trace_profiles_and_raw_heat_defects_RETAINED=True)
        art=save(role+'_complete_geometric_affine_trace_domain.json.gz',record);roles.append(dict(role=role,artifact=art,internal_matrix_entries=sum(map(len,mats)),all156_heat_carrier_traces_zero=True,nonzero_affine_field_columns=sum(bool(q)for q in affine.values()),C_kernel_words={q['name']:len(q['complete_ordered_h_k_bilinear'])for q in kernels},UV_cost_histogram=dict(sorted(costs.items())),hidden_g0_ghost_Hessian_words=len(hidden)));print('STAGE '+role+' actual_affine_carriers_and_full_mean_geometric_kernels_verified',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='GEOMETRIC_AFFINE_OPERATOR_AND_COEFFICIENTWISE_TRACE_DOMAIN_SUPPORTED_PENDING_FINAL_REVIEW',roles=roles,IR_UV_analytic_trace_bounds_inherited_NOT_new_integrals=True,actual_unselected_profiles_common_contacts_full_W5_E5_NOT_qualified=True,raw_heat_regulator_defect='delta_TSigma Cfin - T Cfin; NOT_ASSIGNED_ZERO',elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
