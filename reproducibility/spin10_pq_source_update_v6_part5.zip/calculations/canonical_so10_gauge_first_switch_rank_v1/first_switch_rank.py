"""Compare the first-switch gauge-source square and BaCC bubble."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def load_literal():
    path = ROOT / "calculations/canonical_so10_gauge_plateau_sector_transport_v2/gauge_plateau.py"
    spec = importlib.util.spec_from_file_location("gauge_plateau_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sectors(v,i):
    return 2*int(v>=12)+int(i>=12)


def table():
    return defaultdict(lambda:sp.S.Zero)


def bac_root(f, da, db, dc, Ja):
    root = table()
    outgoing = defaultdict(list)
    nonminimal = defaultdict(list)
    for (b,c), rows in f.items():
        for a,z in rows:
            outgoing[a].append((b,c,z))
    for (a,i,c),z in Ja.items():
        nonminimal[a].append((i,c,-z))

    def add(v,b,c,i,z):
        if b<c:
            root[v,b,c,i] += z
        elif c<b:
            root[v,c,b,i] -= z

    for (i,v,c),za in da.items():
        zb = db.get((i,v,c),0)
        zc = dc.get((i,v,c),0)
        for j,d,z in outgoing[v]:
            add(j,d,c,i,(zb-2*za)*z)
        for b,d,z in outgoing[c]:
            if b<d:
                add(v,b,d,i,-(zc-2*za)*z)
        for j,d,z in nonminimal[i]:
            add(v,c,d,j,za*z)
    return root


def compare(phase):
    gauge = load_literal()
    source = gauge.load_owner()
    _, _, _, f, _, _ = source.owner.inputs(phase)
    clean = source.owner.clean
    J, _, da, db, dc, _, Ja, _ = gauge.literal_tables(source,phase)
    root = clean(bac_root(f,da,db,dc,Ja))
    J_ports = defaultdict(list)
    ordinary = [table() for _ in range(4)]
    K = [table() for _ in range(4)]
    L = [table() for _ in range(4)]
    for (a,v,i),j in J.items():
        J_ports[v,i].append((a,j))
    for (v,b,c,i),z in root.items():
        for a,j in J_ports[v,i]:
            ordinary[sectors(v,i)][a,b,c] -= j*z
    for (i,v,c),z in da.items():
        for a,j in J_ports[v,i]:
            index = sectors(v,i)
            K[index][a,c] -= j*z
            L[index][a,c] += j*(dc.get((i,v,c),0)-z)
    return f, clean, [clean(S) for S in ordinary], [clean(S) for S in K], [clean(S) for S in L]


def plus(*maps):
    result = table()
    for mapping, scale in maps:
        for key,z in mapping.items():
            result[key] += scale*z
    return result


def square(f,K,L):
    result = table()
    kc = defaultdict(list)
    for (a,c),z in K.items():
        kc[c].append((a,z))
    lkc = defaultdict(list)
    for (a,c),z in plus((K,1),(L,1)).items():
        lkc[c].append((a,z))
    for b in range(45):
        for c in range(b+1,45):
            for k,x in f[b,c]:
                for a,y in lkc[k]:
                    result[a,b,c] += x*y
            for k,x in kc[b]:
                for a,y in f[k,c]:
                    result[a,b,c] -= x*y
            for k,x in kc[c]:
                for a,y in f[b,k]:
                    result[a,b,c] -= x*y
    return result


def auxiliary(f, K_HH):
    aux = table()
    for b in range(12,45):
        for c in range(b+1,45):
            for h,z in f[b,c]:
                if h<12:
                    for a in range(12):
                        aux[a,b,c] -= (8*int(a==h)-K_HH.get((a,h),0))*z/2
    return aux


def check(phase):
    f, clean, R, K, L = compare(phase)
    assert [len(x) for x in R] == [0,942,0,216]
    D = [clean(plus((square(f,k,l),1),(root,-1)))
         for k,l,root in zip(K,L,R)]
    assert D[1] == D[2]
    assert D[3] == clean(plus((D[0],-1),(D[1],-2)))
    Q = clean(auxiliary(f,K[0]))
    assert len(Q) == 180 and Q[0,13,14] == 19*sp.sqrt(10)/40
    keys = [(17,1,32),(0,13,14),(0,17,21)]
    pivot = sp.Matrix([[S.get(key,0) for S in (*D,Q)] for key in keys])
    assert list(pivot[0,:]) == [0,sp.Rational(1,10),sp.Rational(1,10),-sp.Rational(1,5),0]
    assert sp.simplify(pivot[:,[0,1,4]].det()) != 0
    assert sp.Matrix([list(pivot[:,0]),list(pivot[:,1])]).rank() == 2
    return {"ordinary_cells_by_sector":[len(x) for x in R],
            "ordinary_residual_rank":2,"rank_with_auxiliary":3,
            "pivot_minor":str(sp.simplify(pivot[:,[0,1,4]].det())),
            "ordinary_sector_conditions":["w_HH=w_MM","w_HM+w_MH=2*w_MM"],
            "auxiliary_s2_condition":"w_MM=w3,MM"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
