# V968 pre-execution contract

Freeze V879 literal current, V945/V946 lower-source
maps, V965 sector ordering and V967 auxiliary pair.
At zero background and zero width in the preserved
transverse gauge-source projection, compare the
two-edge ordinary BaCC first-switch current with the
lower source-square variation. Hold the ghost-source
correction fixed in this comparison. Reconstruct
both tensors directly and test all independent
ordered colors. Retain the V967 independent s² and
s³ coefficients and test the rank at s². No assumption
about other finite quantum directions or the full
compact master is allowed.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
