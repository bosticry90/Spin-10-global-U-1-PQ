# V968 · Gauge first-switch rank

In the selected transverse gauge-source equation the
ordinary BaCC first-switch term has 1,158 nonzero
ordered cells. Its difference from the lower source
square has rank two across the four internal sectors.

Adding the V967 auxiliary color raises the rank to
three. The `s²∂s` equation requires the two-edge
and three-edge MM weights to agree, as well as the
ordinary sector relations. The inherited finite
weights fail the auxiliary condition. Equalizing
those weights would leave the separately tracked
`s³∂s` term.

The test holds the ghost-source correction fixed.
The actual ghost-source support and other compact
products must be checked before a wider conclusion.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
