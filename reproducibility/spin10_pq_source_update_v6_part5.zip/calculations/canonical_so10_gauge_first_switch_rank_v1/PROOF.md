# Gauge first-switch ordinary and auxiliary sector restriction

Work at the local transverse J_B CC jet with b<c.
Use common two-edge graph units as in V967 and strip
one derivative of the common switch. Let d_B,d_C,d_a
denote the three literal derivative placements in
the ordinary B C a density. The uncut grade-two
BaCC master density is a divergence by the classical
master identity. Its derivative on the antighost
can only come from q1 acting on the grade-one
d_a term. The grade-two ordinary quartic carries
no derivative and the free antighost driver is
algebraic. In the BaCC current this determines the
undifferentiated representative as q1(d_a B C a).

The s² divergence transfers to -2s(partial s)
times that current. The derivative of the switched
driver at each derivative placement supplies a
second term. After collecting coefficients, the
resulting grade-two root in units s(partial s) is

    (d_B-2 d_a) (q1 B) C a
      +(d_C-2 d_a) B (q1 C) a
      +d_a B C (q1 a).

The last sign includes the odd C prefix. It is
essential to derive this from the switched density.
The explicit V967 auxiliary correction belongs to
the difference between the symmetric reference and
the literal density and is accounted for separately.
The ordinary BaCC root pairs B and a with J_B B C.
The ghost contraction and left-source reordering
give -j times the root in the common stripped graph
units, with j the raw J_B coefficient.

For each internal (B,ghost) sector S define L_S
from d_C-d_a and K_S from -d_a after contraction
with the lower source. The corrected lower driver
is s² L_S partial C+s(partial s) K_S C. In the
source-first master, keeping the correction to q_C
fixed, its first-switch square is

    (L_S+K_S)[b,c]-[K_S b,c]-[b,K_S c].

This follows by applying q1 to the lower driver
and the lower driver to q1 B. It uses the minus
from the odd derivation passing the source. The
ordinary three-edge gauge plateau transport of
V965 does not provide the missing first-switch
ordinary two-edge map.

Let D_S be the last square minus the ordinary
BaCC bubble. Both literal exports give

    D_HM=D_MH,    D_MM=-D_HH-2 D_HM.

The two remaining columns are independent. Thus
for this ordinary comparison the sector weights
require w_HH=w_MM and w_HM+w_MH=2w_MM. The V967
auxiliary color Q_Lambda is independent of both
columns. In the s² coefficient of the full selected
comparison it comes with w_MM-w3,MM, with minus
sign because it is subtracted. Therefore the
enlarged selected s² system also requires
w_MM=w3,MM. The inherited nonexceptional heat
difference fails that condition. Equalizing the
two weights would leave the separate s³ term
from V967. Nothing in this computation sets it
to zero.

The executable verifies the full ordered color
columns and a rank-three pivot minor in both
exports. The result applies to the selected
first-switch directions with fixed ghost-source
correction. Independent ghost-source responses,
other switch insertions, regulator contacts,
ordinary metric and marked products may affect
the coupled problem. No general obstruction
or new finite prescription is claimed. Both
replays share the action and software.
