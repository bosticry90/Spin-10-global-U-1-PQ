from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-scalar-source-independence-v1-2026-11-07')
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(s);s.loader.exec_module(z);return z
a=module('source_audit_fresh_validation',O/'source_audit.py');b=module('functional_bridge_fresh_validation',O/'functional_bridge.py');read=a.read;load=a.load;digest=a.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def authenticate(folder,prep):
 for n,h in read(folder/prep)['sha256'].items():assert digest(R/n)==h,(prep,n)
def resources(c):
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 for v in c['all_resource_samples'])
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for p in ['preparation.json','functional_preparation.json','final_preparation.json']:authenticate(O,p)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps=[]
 for stem in ['source','functional']:
  c=read(O/(stem+'_capture.json'));r=read(O/(stem+'_result.json'));assert c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified'] and r['execution_state']=='COMPLETED' and r['elapsed_after_imports']<120;resources(c);caps.append(c)
 old=O.parent/'canonical_so10_selected_BV_square_g1_u1_v1';v=read(old/'validation_receipt.json');vc=read(old/'final_capture.json');vr=read(old/'square_v2_result.json')
 assert v['evidence_validation'].startswith('PASS_BOUNDED') and v['scientific_acceptance']=='NOT_PERFORMED' and v['selected_coordinate_squares_freshly_verified']==7716 and v['full_branch_port_compositions_freshly_verified']==19290 and v['historical_custody']=='EXIT2_SEVEN_UNRESOLVED_NOTPASS' and v['failed_workers']==1
 assert vc['exit_code']==0 and vc['calculation_completed'] and vc['post_run_observations_qualified'];resources(vc)
 for p in ['preparation.json','preparation_v2.json','final_preparation.json']:authenticate(old,p)
 for n,h in v['new_files_excluding_pending_receipt_and_final_capture'].items():assert digest(R/n)==h,n
 fail=read(old/'square_capture.json');success=read(old/'square_v2_capture.json');assert fail['exit_code']==1 and not fail['calculation_completed'] and 'NameError' in fail['stdout_and_stderr'] and success['exit_code']==0 and success['calculation_completed']
 for q in [vr['flow_projections']]+[r['artifact'] for r in vr['cases']]:assert digest(old/q['file'])==q['sha256']
 assert vr['all_selected_squares_zero'] and vr['all_native_prefix_LEFT_compositions_equal']
 print('STAGE V812_actual_square_authenticated_not_reexecuted_failed_V1_still_NOTPASS',flush=True)
 replayed=[];results=[]
 def compare_save(name,z):
  blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2 and blob==(O/name).read_bytes(),name
  replayed.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
 def compare_dump(path,z):
  assert path.parent==O and path.name in ['source_result.json','functional_result.json'];saved=read(path)
  assert {k:v for k,v in z.items() if k!='elapsed_after_imports'}=={k:v for k,v in saved.items() if k!='elapsed_after_imports'} and z['elapsed_after_imports']<120
  results.append(dict(file=path.name,fresh_seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
 a.save=compare_save;a.dump=compare_dump;a.main();gc.collect()
 b.a.save=compare_save;b.a.dump=compare_dump;b.main();gc.collect()
 assert replayed==['source_independence_tables.json.gz','functional_bridge_tables.json.gz'] and len(results)==2
 st=load(O/'source_independence_tables.json.gz');ft=load(O/'functional_bridge_tables.json.gz');sr=read(O/'source_result.json');fr=read(O/'functional_result.json')
 assert sr['full_classical_word_count']==19806 and sr['scalar_source_coordinates']==328 and len(st['proper_derivative_checks'])==1286
 assert ft['exception_output_counts']=={'Q1':{'J_x':12560},'Qu1_0':{},'Qu1_1':{}} and len(ft['all_full_source_tadpole_partial_audits'])==3858
 assert sum(len(q['all_original_Jx_positions']) for q in ft['all_full_source_tadpole_partial_audits'])==25120
 assert fr['actual_unknown_amplitude_limit_existence_not_proved'] and fr['no_numerical_aCC_prediction_or_known_remainder_read']
 proof=(O/'PROOF.md').read_text(encoding='utf-8');assert all(s in proof for s in ['NONEMPTY','EXISTING','COMMON','NOT Schwartz','TEST FUNCTIONS','No actual K','nonnegative powers'])
 print('STAGE both_actual_audits_and_complete_artifacts_freshly_reexecuted_qualified_conditional_scope',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(x) for x in p.stdout.splitlines() if x.strip()];exits=[e['exit_code'] for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and next(e for e in events if e['event']=='step_finished' and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V813.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 result=dict(schema='ACTUAL_SOURCE_INDEPENDENCE_FUNCTIONAL_BRIDGE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_SOURCE_SUPPORT_AND_CONDITIONAL_FUNCTIONAL_BRIDGE',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,fresh_replays=results,full_artifacts_recomputed_and_equal=replayed,actual_Jx_sources=328,source_action_words=19806,full_Q1_Qu1_coordinate_rows=3858,Jx_positions_before_selection=25120,potential_partial_terms_only_Jx_output=12560,V812_square='AUTHENTICATED_COMPLETED_RECEIPT_NOT_NEW_SQUARE_EXECUTION',V812_failed_V1='NAMEERROR_PRESERVED_NOTPASS',failed_workers_this_increment=0,raw_Gamma_no_added_source_CT_required=True,finite_formal_WZ_only=True,Schwartz_FP_lemma_conditional_on_existing_common_expansion=True,Gaussian_n0_only_normalization_not_Schwartz=True,no_numerical_aCC_prediction_or_direct_integral_claim=True,largest_sampled_private_bytes=max(x['private_bytes'] for c in caps for x in c['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_restoration_QAP_E5_A5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
