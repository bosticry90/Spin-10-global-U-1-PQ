from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/g0-scalar-source-independence-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_mixed_Ward_positive_coupling':['action_tables_v2.json.gz'],'canonical_so10_new_physical_returning_inventory_g1_recovery_v1':['native_GF_common.json.gz','replay_GF_common.json.gz'],'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json'],'canonical_so10_regulator_free_inverse_g1_recovery_v1':['native_inverse.json.gz','replay_inverse.json.gz','validation_receipt.json','PROOF.md'],'canonical_so10_chiral_probe_support':['primary_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json','DERIVATION.md'],'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz'],'canonical_so10_selected_BV_square_g1_u1_v1':['square_v2_result.json','full_primitive_flow_projections_v2.json.gz','validation_receipt.json'],'canonical_so10_proper_slavnov_source_chain_g1_v1':['PROOF.md','validation_receipt.json'],'canonical_so10_physical_current_input_recovery_g1_v1':['physical_v2.py','physical_v4.py']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V812.md']+['calculations/'+d+'/'+n for d,nn in deps.items() for n in nn]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','source_audit.py','run_audit.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'source_audit.py')]);dump(O/'source_capture.json',cap);dump(C/'source_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
