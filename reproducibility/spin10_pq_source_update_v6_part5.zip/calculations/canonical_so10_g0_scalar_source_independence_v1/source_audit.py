from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter,defaultdict
import gzip,importlib.util,json,os,re,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(n,p):
 sp=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z);return z
v=module('Jx_prefix_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py');vr=module('Jx_LEFT_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py');J=v.J;w=v.w;A=v.A;one=J.constant(1)
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
isJx=lambda n:823<=n<1151
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def source_group(n):return ('J_'+source_group(n-643)) if n>=643 else 'B' if n<180 else 'x' if n<508 else 'Lambda' if n<553 else 'C' if n<598 else 'a'
def patterns(row):
 n=row['coordinate'];out=[]
 for at,(ww,c) in enumerate(row['selected']):
  rest={'Lambda':1,'C':2}
  for i,js in ww:
   key=source_group(i);assert key in rest;rest[key]-=1
  assert min(rest.values())>=0
  pattern=tuple(sorted([source_group(n)]+[key for key,count in rest.items() for _ in range(count)]));out.append(dict(coordinate=n,selected_word_index=at,input_pattern=list(pattern),source_independence_excludes=isJx(n)))
 return out
def controls():
 atom=lambda n:{((n,()),):one}
 z=atom(823);c=atom(553);d=atom(554);b=atom(1319);p=atom(1872);q=atom(1917);zc=J.mul(z,c);unit={():one};assert not J.mul(zc,zc)
 Sb=w.scale(w.plus(J.mul(b,b),J.mul(zc,J.mul(b,b))),J.constant(F(1,2)));Hb=J.leftjet(J.leftjet(Sb,(1319,())),(1319,()));assert Hb==w.plus(unit,zc)
 Zb=w.plus(unit,w.scale(zc,J.constant(F(-1,2))));Gb=w.scale(zc,J.constant(F(1,2)));assert w.scale(w.plus(Zb,w.scale(unit,J.constant(-1))),J.constant(-1))==Gb
 Sf=J.mul(p,q);Rf=J.mul(zc,Sf);weight=w.plus(unit,w.scale(w.plus(Sf,Rf),J.constant(-1)));top={}
 for ww,cc in weight.items():
  if (1872,()) in ww and (1917,()) in ww:top[tuple(t for t in ww if t[0] not in [1872,1917])]=cc
 Zf=w.scale(top,J.constant(-1));assert Zf==w.plus(unit,zc);Gf=w.scale(zc,J.constant(-1));assert w.scale(w.plus(Zf,w.scale(unit,J.constant(-1))),J.constant(-1))==Gf
 db=J.leftjet(Gb,(823,()));df=J.leftjet(Gf,(823,()));assert db==w.scale(c,J.constant(F(1,2))) and df==w.scale(c,J.constant(-1))
 early=lambda P:{ww:cc for ww,cc in P.items() if all(not isJx(n) for n,js in ww)}
 assert not J.leftjet(early(Gb),(823,())) and not J.leftjet(early(Gf),(823,()))
 QGamma=J.mul(z,J.mul(c,d));comm=J.leftjet(QGamma,(823,()));assert comm==J.mul(c,d) and not J.leftjet(atom(0),(823,()))
 return dict(boson=dict(action=J.encode(Sb),Hessian=J.encode(Hb),normalized_Wick_partition=J.encode(Zb),Gamma=J.encode(Gb),source_derivative=J.encode(db)),odd_pair=dict(source_free_action=J.encode(Sf),source_dependent_regulator=J.encode(Rf),literal_Berezin_weight=J.encode(weight),normalized_partition=J.encode(Zf),Gamma=J.encode(Gf),source_derivative=J.encode(df)),early_source_or_fermion_mean_zero_is_blind=True,source_dependent_Q=dict(Gamma=J.encode(atom(0)),QGamma=J.encode(QGamma),graded_commutator_on_Gamma=J.encode(comm)),not_physical_models=True)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['known_consistency_images','consistency_tables.json','hard_response_v2.json']),'QUANTUM_REMAINDER_INPUT_DENIED'
 sys.addaudithook(guard)
 rawactions=load(O.parent/'canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz');audits=[];action_terms=0
 for route in rawactions:
  role='native' if route['role']=='primary' else 'replay';common=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'))
  actions=[('S0',route['original'][0]['density'])]+[('U0_'+str(pr),common['probes'][pr]['U']) for pr in [0,1]]
  for label,raw in actions:
   P=J.decode(raw);hits=[at for at,(ww,c) in enumerate(sorted(P.items())) if any(isJx(n) for n,js in ww)];EL=J.euler(P,set(range(823,1151)));sources=Counter(n for ww in P for n,js in ww if 643<=n<1286);assert not hits and not EL,(role,label,'SCALAR_SOURCE_NOT_ABSENT')
   audits.append(dict(route=role,action=label,terms=len(P),Jx_word_indices=hits,source_indices_and_occurrences=sorted(sources.items()),all328_Jx_Eulers=J.encode({}) if not EL else {str(n):J.encode(p) for n,p in EL.items()},literal_absence_and_Euler_agree=True));action_terms+=len(P)
 print('STAGE all_full_classical_S0_U0_scalar_source_jets_absent_before_restriction',flush=True)
 proper=[];operator=[]
 for role in ['native','replay']:
  packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={key:{n:J.decode(p) for n,p in rows} for key,rows in packet['states'].items()};physical0={n:J.decode(p) for n,p in packet['physical']['P_E0']}
  for n in range(643):
   P=states['F0'][n];assert all(all(i<643 for i,js in ww) and len(ww)<=1 for ww in P);t=v.tangent(v.tangent(P));tr=vr.tangent(vr.tangent(P));assert not t and t==tr;proper.append(dict(route=role,field=n,F0_affine_source_free=True,T2_F0=J.encode(t)))
  for key in ['F0','Fu0_0','Fu0_1']:
   for n in range(180,508):assert not states[key][n]
  for Fkey,Ekey in [('F0','E0'),('Fu0_0','Eu0_0'),('Fu0_1','Eu0_1')]:
   hits=[]
   for n in range(643):
    for kind in [Fkey,Ekey]:
     P=states[kind][n]
     if kind=='E0' and n<508:P=w.plus(P,physical0.get(n,{}))
     for at,(ww,c) in enumerate(sorted(P.items())):
      if any(isJx(i) for i,js in ww):hits.append([kind,n,at])
   assert not hits;operator.append(dict(route=role,operators=[Fkey,Ekey],all1286_full_coordinate_coefficients_Jx_free=True,Jx_hits=hits))
 print('STAGE proper_derivative_zero_and_full_g0_operator_coefficient_audits_complete',flush=True)
 matter=[]
 for role in ['primary','replay']:
  z=load(O.parent/'canonical_so10_chiral_probe_support'/(role+'_inputs.json.gz'));kv=z['K_vertex'];assert kv['origin']=='KCP' and kv['g_degree']==1 and sorted(p[0] for p in kv['ports'])==['K','P','c'];assert z['role_source_copy_count']==z['SMA']['physical_antifield_copies']==1 and z['SMA']['auxiliary_BRST_transform']=='0'
  names=z['names'];geo=z['geometry'];pairs=geo['field_source_h_k'];Jof={i:src for i,src,h,k in pairs};sources=set(Jof.values());idx={name:i for i,name in enumerate(names)};aa=[idx[('bar' if c<12 else 'ub')+str(c)] for c in range(45)];ll=[idx[('b' if c<12 else 'L')+str(c)] for c in range(45)];allowed={Jof[i] for i in aa+ll};rows=[]
  for kind in ['physical_G','physical_QG']:
   for pr,p in enumerate(z[kind]):
    found=sorted({n for g,ww,coef in p['monomials'] for n,js in ww if n in sources});assert set(found)<=allowed;rows.append(dict(generator=kind,probe=pr,source_names=[names[i] for i in found],all_sources_Ja_or_JLambda=True))
  matter.append(dict(route=role,actual_KCP=kv,physical_source_copy_count=1,physical_G_QG_sources=rows,matter_Jx_absence_from_bound_SMA_action_definition=True))
 print('STAGE matter_source_and_full_probe_generator_source_support_checked',flush=True)
 allowed={'q0','q1','q2','q3','xi','eta_H','E_profile','f_profile','F_profile','Mref_Phi_squared','Mref_Sigma_squared','Mref_phi_squared','Mref_S_squared'};matrix_keys=['Pphysical','Preference','Greference','G_F','full_regulator','reference_defect'];reg=[];exprs={}
 @lru_cache(None)
 def parse(expr):
  assert re.fullmatch(r'[0-9A-Za-z_+*/(). \-]+',expr);tokens=set(re.findall(r'[A-Za-z_][A-Za-z_0-9]*',expr));assert tokens<=allowed|{'I','sqrt'},tokens
  p=s.sympify(expr);symbols={str(v) for v in p.free_symbols};assert symbols<=allowed;return sorted(symbols)
 for role in ['native','replay']:
  z=load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'));rows=[]
  for key in matrix_keys:
   packed=[]
   for i,j,expr in z[key]:
    symbols=parse(expr);exprs[expr]=symbols;packed.append([i,j,expr])
   rows.append(dict(matrix=key,entries=len(packed),all_entries_source_and_mean_free=True,raw_math_sha256=sha256(json.dumps(packed,sort_keys=True).encode()).hexdigest()))
  reg.append(dict(route=role,matrices=rows))
 controls_data=controls();assert any(isJx(n) for ww in J.decode(controls_data['boson']['Hessian']) for n,js in ww)
 print('STAGE every_fixed_regulator_expression_and_three_sensitive_source_controls_verified',flush=True)
 old=O.parent/'canonical_so10_selected_BV_square_g1_u1_v1';res=read(old/'square_v2_result.json');flow=load(old/res['flow_projections']['file']);assert digest(old/res['flow_projections']['file'])==res['flow_projections']['sha256'];inverse={label:[] for label in ['Q0','Q1','Qu0_0','Qu0_1','Qu1_0','Qu1_1']}
 for row in flow['all_primitive_maps']:inverse[row['operator']].extend(patterns(row))
 expected={'Q0':{('B','C','Lambda'),('C','C','a'),('C','C','J_B'),('C','C','J_Lambda'),('C','J_a','Lambda'),('C','J_a')},'Q1':{('C','Lambda'),('C','C','J_x')},'Qu0_0':{('C','C','a'),('C','C','J_B'),('C','C','J_Lambda')},'Qu0_1':{('C','C','a'),('C','C','J_B'),('C','C','J_Lambda'),('C','J_a')},'Qu1_0':set(),'Qu1_1':{('C','C','J_x')}}
 summaries={}
 for label,rows in inverse.items():
  got={tuple(q['input_pattern']) for q in rows};assert got==expected[label],(label,got);remaining={tuple(q['input_pattern']) for q in rows if not q['source_independence_excludes']};summaries[label]=dict(all_input_patterns=[list(q) for q in sorted(got)],after_actual_g0_Jx_independence=[list(q) for q in sorted(remaining)])
 assert not summaries['Qu1_1']['after_actual_g0_Jx_independence'] and summaries['Q1']['after_actual_g0_Jx_independence']==[['C','Lambda']]
 art=save('source_independence_tables.json.gz',dict(classical_full_source_audits=audits,proper_derivative_checks=proper,full_Q0_Qu0_Jx_coefficient_audits=operator,matter_source_support=matter,fixed_regulator_audits=reg,distinct_regulator_expressions=[dict(expression=k,free_parameters=v) for k,v in sorted(exprs.items())],negative_controls=controls_data,complete_nonlocal_field_pattern_preimages=inverse,field_pattern_summary=summaries))
 result=dict(schema='ACTUAL_G0_PROPER_SCALAR_SOURCE_INDEPENDENCE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',full_classical_routes_actions_checked=len(audits),full_classical_word_count=action_terms,scalar_source_coordinates=328,all_F0_affine_T2_zero=True,all_scalar_F0_Fu0_zero_before_restriction=True,fixed_regulator_all_expressions_source_free=True,matter_source_is_positive_g1_KCP_only=True,formal_Gamma_g0_and_Gamma_u0_Jx_independent=True,formal_Delta_g0_and_Delta_u0_Jx_independent=True,selected_Qu1_Delta_g0_zero_by_actual_source_support=True,selected_Q1_Delta_u0_needs_only_Lambda_C=True,no_derivative_Lorentz_locality_assumed_in_field_pattern_census=True,raw_proper_prescription_no_added_source_counterterms=True,no_aCC_coefficient_or_WZ_reference_limit_reconstructed=True,field_pattern_summary=summaries,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'source_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
