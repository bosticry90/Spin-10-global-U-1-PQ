# Scalar-source independence and a selected functional consistency prerequisite

Claim IDs within this versioned record: SSI-1 (actual raw g0 source
independence), SSI-2 (nonlocal field-support census), WZ-1 (selected formal
functional identity), TEST-1 (conditional distribution operation), INV-1
(injective aCC image). These are calculation identifiers, not new authority
entries. State113,34/39,E5/A5 remain unchanged. No missing loop coefficient
is an input or output. Both workers denied reads of the numerical known
consistency-remainder containers.

## SSI-1: differentiate before setting sources or means to zero

Use the actual unshifted Euclidean A0 action and original g0/g1, first even
probe u_H/u_M, with the established fixed source-independent regulator and
source-independent reference constant. Gamma is the raw normalized proper
one-loop functional, without an added source-dependent finite counterterm.
Statements are coefficientwise in formal mean/source series with nonnegative
powers. They do not assert existence of an infinite-dimensional measure,
absolute fermion phase, resummed background, or unknown amplitude limit.

The two full source-first classical routes contain no Jx token or derivative
jet in S0, U0_H or U0_M. All328 Jx Euler derivatives vanish independently
of this literal scan. Six route/action audits cover19806 classical words.
No mean/source restriction precedes either operation. Known physical kinetic
actions and the defined physical potential are source-free. The provisional
matter action has one K_P C P source coupling, at positive g1, and no Jx;
its Hessian therefore remains Jx-free even after fermion differentiation.
Both full CPS probe generator packets use sources only Ja/JLambda. Every
expression of both actual fixed regulator matrices/inverses/reference defects
passes the explicit source-/mean-free parameter namespace audit.

At a common finite Gaussian proof stage a source-free Hessian and fixed R
give a source-independent normalized determinant/Pfaffian coefficient. The
first-u derivative is onehalf STr(G U0''); both factors are Jx-free. Hence
Gamma_0 and Gamma_u are Jx-independent before restriction. A second route
uses the qualified proper derivative identity

    Gamma_Ji = (-1)^p_i <T2 F_i/2>.

All643 F0 maps are affine/source-free and T2F0=0 in both prefix/LEFT tangent
implementations. All328 scalar F0/Fu0 maps vanish before restriction. Thus
Gamma_0 is independent of all canonical sources and Gamma_u of Jx. This
second route shares the action, chart and algebra with the first route;
it is not an independent scientific authority.

Full Q0 and Qu0 coefficients, including known physical E0 before variation,
are Jx-free too. The graded commutator of an odd LEFT Jx derivative with
these odd derivations therefore vanishes. Consequently

    Delta_0=Q0 Gamma_0,  Delta_u=Q0 Gamma_u+Qu0 Gamma_0

are Jx-independent. The operator-coefficient premise is necessary: in a
mathematical control Gamma=b is source-free but Qb=z*c*d gives
LEFT_z(QGamma)=c*d. The two other sensitive controls retain source
responses +c/2 (boson action) and -c (source-dependent odd-pair regulator).
Restricting the sources or fermion means before differentiation loses them.
These toys are dimension-unrestricted algebra diagnostics, not physical
Spin(10) parameter points or admissible counterterms.

## SSI-2: field support without a local momentum ansatz

Invert every actual V812 projected primitive flow to the target Lambda C C.
Ordinary derivative jets do not change field counts, so the following census
requires no local Lorentz basis, derivative bound or polynomial momentum
ansatz. It applies coefficientwise to nonlocal formal kernels too.

| operator | possible input field patterns |
|---|---|
|Q0|B Lambda C; JB C C; JLambda C C; a C C; Ja C; Ja Lambda C|
|Q1|Lambda C; Jx C C|
|Qu0_H|JB C C; JLambda C C; a C C|
|Qu0_M|the H patterns and Ja C|
|Qu1_H|none|
|Qu1_M|Jx C C|

SSI-1 removes the Jx patterns when the operand is Delta_0 or Delta_u.
Therefore Pi(Qu1 Delta_0)=0 at the finite-formal level, including nonlocal
kernels. Pi(Q1 Delta_u) uses only Lambda C. This improves the earlier local
Lorentz-only exclusion; it does not assume that exclusion for nonlocal terms.
Every original primitive coordinate/word preimage is preserved.

## WZ-1: actual coordinate square to a functional identity

V812's completed receipt qualifies all7716 selected coordinate squares
(19290 branch/coordinate comparisons) using full source operations before
selection. Its old failed V1 remains failed. This increment authenticates,
rather than freshly reruns, that expensive result. The square of an odd
derivation is an even derivation: paired second-functional-derivative terms
cancel by the graded Leibniz rule. Thus Q2Gamma has only coordinate-square
coefficients multiplying first derivatives of Gamma. A coefficient with a
forbidden mean/source factor or excessive target field count cannot feed
LambdaCC when multiplied by a formal series with nonnegative powers.

The physical-potential exceptions omitted in V812 require a separate check
before using this observation. At unshifted A0 an outer potential gradient
is either scalar-dependent or a constant tadpole. Nonconstant terms retain
a scalar under Q1x=xC; Q0x=Qu0x=Qu1x=0. Unknown physical E1_x remains
unassigned: its variations under the only relevant outer Q0/Qu0 operations
have V812's qualified support exclusions. It is source-free and adds no
Jx derivative to the following audit.

A constant outer tadpole can remove an undifferentiated Jx from a full
inner Q1/Qu1 coefficient. Derivatives of that constant are zero, by the
translation-invariant A0/coupling assumptions. Audit all3858 full coordinate
maps (Q1,Qu1_H,Qu1_M), retaining25120 Jx positions in371 rows before
selection. Literal position removal and LEFT derivatives agree. The12560
nonzero selected partial terms occur only at physical-source Jx OUTPUT
coordinates of Q1, and so multiply Gamma_u,Jx=0. Full Qu1 maps contain no
Jx at all. No source tadpole coefficient or intrinsic3 normalization is
adopted. This closes the specific exception without using its numerical value.

Actual CPS Ihat has P,S,c and hatted derivatives, with no sources. Its
Hamiltonian coefficients retain a fermion mean. The matter KCP coupling and
matter equations preserve P=S=K=0. Such square coefficients times a formal
Gamma derivative still retain a fermion mean. This is a mean-functional
argument; Ihat'' can have a nonzero fermion trace, and is NOT set to zero.
No full chiral master/Qfull2=0 theorem follows.

Write Q=Q0+g Q1+u Qu0+gu Qu1 and Gamma=Gamma_0+g Gamma_g+u Gamma_u+
gu Gamma_gu, with even g,u. Exact free operator-word convolution gives

    Pi_LambdaCC[ Q0 Delta_gu + Q1 Delta_u
                  + Qu0 Delta_g + Qu1 Delta_0 ] = 0,    Delta=QGamma.

The nine expanded words group into Q0Q0 Gamma_gu; (Q0Q1+Q1Q0)Gamma_u;
(Q0Qu0+Qu0Q0)Gamma_g; and
(Q0Qu1+Qu1Q0+Q1Qu0+Qu0Q1)Gamma_0. The actual squares plus the audited
exceptions and fermion support make this selected finite-formal identity
valid in the stated raw prescription. Dropping Qu0 Delta_g changes the
general free-word identity in a negative control. This is INTEGRABILITY,
not Delta=0, a restored symmetry, or an assertion about missing reference
amplitudes. Finite diagnostic D matrices from V811 are not used here; the
continuum jet derivations obey Leibniz.

## TEST-1: conditional source operations on tempered kernels

For a local classical replacement of one mean by a NONEMPTY product of
means and finite derivatives, the induced kernel operation is a transpose
on test functions. It is not multiplication of two quantum insertions.
The relevant selected flows have no constant replacement after the above
tadpole exclusion. Let i:R^(4n)->R^(4m) repeat coordinates, with every old
coordinate represented at least once. This makes i injective/proper and
|i x|>=|x|. For Phi in Schwartz space and a finite multiindex beta, the
chain rule gives a finite sum of restrictions of derivatives of Phi. Hence

    p_(N,alpha)((D_beta Phi) o i)
      <= C_(alpha,beta) sum_(|gamma|<=|alpha|+|beta|) p_(N,gamma)(Phi).

Here p_(N,alpha)(f)=sup_x(1+|x|)^N|D_alpha f(x)|; finite dimension-dependent
constants are harmless. The inequality proves all-order continuity from
S(R^(4m)) to S(R^(4n)), rather than only a finite Gaussian example. Its
transpose is a continuous pushforward S'(R^(4n))->S'(R^(4m)); derivative
transposes have the usual IBP signs. Finite color sums, permutations and
Grassmann signs preserve this continuity. This restricts TEST FUNCTIONS
to a diagonal, not an unknown singular distribution. Constant replacements
would require an integration operation outside this argument; they are not
silently included.

It follows that these fixed classical operations commute with EXISTING
S' limits. If a family has a COMMON, FIXED linear S'-asymptotic finite-part
expansion, apply the same continuous operator coefficientwise; the expansion
and its finite part commute with the operation. This is conditional on the
expansion and its unique coefficient prescription, not a theorem that the
actual unknown aCC kernels possess one. It neither permits different contact
subtractions in different sectors nor changes UV-first/IR-second order.
The full regulator profiles must remain until a qualified joint limit.

For k_eps(x)=exp(-x2/eps2)/(sqrt(pi)*eps), the off-origin pointwise limit is0,
but its pairings with exp(-x2) and with exp(-x2-y2) restricted to y=x tend1.
Thus discarding a contact gives the wrong answer. The stored diagnostic's
field name includes an n=0 normalization integral alongside its n=1,2
Schwartz tests. The constant n=0 function is NOT Schwartz; it is only a
Gaussian normalization check. The all-order claim rests on the displayed
inequality, not that label, those finite tests, or a Lean kernel proof.

## INV-1 and the next discriminating action

Actual Q0a=iLambda, Q0Lambda=Q0C=0 at all45 colors. On aCC kernels this
is i times a continuous injective field rename R. Derivative-bearing
prefix/LEFT controls agree, and the inverse of the Q0 IMAGE I is

    A=-i R^-1(I).

If a FUTURE COMPLETE, qualified reference consistency identity is
i R(A)+K=0, its DEPENDENT prediction would instead be A=+i R^-1(K).
Using the opposite inverse sign fails the explicit control. No actual K is
read or supplied here, and no numerical aCC prediction is made.

The direct full-color/continuum momentum/UV-IR evaluation of V811's two
actual response operators remains an independent required check before
source compatibility or common-normalization claims. First determine whether
the necessary non-aCC inputs and their common reference operations have
qualified kernel-level limits, retaining finite JaLambdaC until its own
reference-zero is justified. If that bridge cannot be established, use the
direct two-response calculation rather than infer an amplitude from closure.

Workers completed42.898s and24.806s under separate120s limits, no failed
worker in this increment. Final review freshly reexecutes both audits and
all artifact/control comparisons, authenticates V812 instead of repeating
its large square, and runs E4 once. All sources/preparations/captures remain
immutable. Shared actions, chart, ring, software and AI author limit error
independence; computational agreement cannot establish those shared physical
assumptions. These results demonstrate source-support diagnosis and a bounded
functional proof, not independent scientists or experimental success.
Full common restoration, source products, QAP/measure/reality/equivalence,
E5/A5, physical viability and the investigation remain open.
