# Actual g0 proper scalar-source independence

Continue52077a3c/main,V812,D: under current AGENTS. Previous turn is verified
progress: selected canonical field/source square vanishes at7716 coordinates,
but Jx survives in Q1/Qu1 and actual quantum source independence was not
established. State113/34of39,E5/A5 open. No agents, adoption, protected
activation/promotion, branch/worktree, remote action or new authority ledger.

Question: are the raw proper one-loop Gamma_g0,Gamma_u0 and therefore
Delta_g0=Q0Gamma_g0,Delta_u0=Q0Gamma_u0+Qu0Gamma_g0 independent of ALL328
scalar BV sources Jx before setting them zero? This is the least expensive
next prerequisite for any integrability prediction of the missing aCC image.
Do not read a known consistency remainder or assign an unknown coefficient.

Use both full classical S0 action densities and full U0 densities (H/M),
native/replay, without field/source restriction. Audit every source token and
jet, and independently compute all Jx Euler derivatives. Require literal Jx
absence and zero Euler rows; an unproved boundary cancellation is not enough.
Physical gauge/scalar kinetic and potential actions are source-free by their
qualified definition; no unknown potential coefficient is evaluated/adopted.
Full physical F0_x/Fu0_x must be zero for all328 scalar ports before projection.
Check all F0 field maps are affine/source-free and T2F0=0. The exact proper
derivative identity Gamma_Ji=(-1)^p<T2F_i/2> gives a second, Gaussian-operator
route: Gamma_g0 all canonical source derivatives vanish; first-u scalar
source derivatives have T2F0_x=T2Fu0_x=0. No scalar-source derivative is
taken only after a mean0 restriction.

Audit the actual matter source definition: SMA has a single physical Nambu
source K_P coupling to CP at positive g1; no Jx. Bind both source pullbacks
and CPS's actual KCP vertex. Scan full physical G/QG generator packets for
their actual source set Ja/JLambda; no scalar or matter source. This is the
defined provisional matter action, not an inferred omission at fermion0.
Its fermion Hessian has no Jx dependence even after fermionic derivatives.
No auxiliary regulator field or source is newly adopted.

For both actual V791 regulator packets, audit every fixed matrix expression
Pphysical,Preference,Greference,G_F,Rall and reference defect. Parse ALL
expressions against the explicit parameter namespace q,xi,eta,reference
masses,heat/IR profiles; no field/source symbol is allowed. This reuses the
qualified free inverse rather than rerunning it. R and the reference
normalization remain fixed and source-free as in V801/803. No inverse heat
factor is separately applied to arbitrary Schwartz means.

At a common finite proof cutoff, source-free Hessians and regulator imply
source-independent normalized determinant/Pfaffian coefficients, including
the first-u derivative onehalf STr(G U0''). This does not construct an
infinite-dimensional measure, absolute Pfaffian phase or new limit. Gamma
here is the already defined raw proper one-loop functional with its
source-independent reference constant, with no added source-dependent finite
counterterms. A changed normalization/source action must be reviewed anew.
Audit full Q0/Qu0 coefficients for Jx absence too: the graded commutator of
the odd LEFT Jx derivative with these odd operators then vanishes. Gamma
source independence alone would not imply Delta independence otherwise.

Controls use explicitly mathematical, dimension-unrestricted nilpotent toy
sources z,c (odd): boson action(1+zc)b2/2 has Gamma_z=c/2; source-free odd
pair action plus source-dependent regulator zc psi1psi2 has Gamma_z=-c.
Literal normalized Gaussian/Berezin coefficients and closed log agree.
Setting sources/fermion means0 before differentiation falsely loses these
terms. A source-dependent odd derivation Qb=z*c*d acting on source-free
Gamma=b gives nonzero LEFT_z(QGamma)=c*d, showing the operator-coefficient
premise is also necessary. These controls are not physical parameters,
renormalizable Spin10 candidates or a benchmark platform.

Using authenticated V812 projected operators, enumerate complete inverse
FIELD patterns for Lambda1,C2 with NO local derivative/Lorentz restriction.
Q1 preimages should be LambdaC or JxCC; Qu1_M only JxCC (H empty).
Actual Jx independence then excludes Qu1Delta_g0 at finite-formal level and
leaves only the lower LambdaC component for Q1Delta_u0. Preserve every
coordinate/word preimage. This proof applies to formal Taylor functionals
with nonnegative mean powers, not arbitrary resummed/nonanalytic backgrounds.
No use of V807's local Lorentz exclusion for an unproved nonlocal kernel.

One120s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact. Freeze inputs/source first, preserve full
captures/failures, no automatic retry. Native/action and proper-derivative
routes share action/chart/ring/AI author; agreement does not validate shared
physics. No aCC coefficient, WZ common-reference commutation, joint-source
limit, restoration, E5/A5, physical viability or whole-goal completion follows.
