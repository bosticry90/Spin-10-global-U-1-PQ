# Final bounded validation

Both120s workers completed, no failed worker. Freeze PROOF/RESULT/handoff,
final sources and dependencies before validation. One240s after-import
review,8GiB sampled-private/350MiB launch floor,64MiB packet/10MiB artifact.
Freshly reexecute BOTH actual audits, comparing every canonical artifact and
all result fields except the new runtime. Redirect only serialization to
exact comparisons; do not modify frozen calculation source or input bytes.
These are repeat calculations, not independent scientific authorship.

Authenticate the V812 completed receipt, preparations, successful and failed
captures, full artifacts and qualified square counts, rather than repeat
its already checked19290 branches. Check exact source copies, all current
preparations and worker resource observations. Confirm the written proof's
explicit restrictions, the n0 normalization clarification, and numerical
remainder exclusion; finite tests are not a Lean proof of the theorem.

Run delegated E4 once, nofresh, using fixed D:e4-context-v4. Require outer0,
steps0,0,0,0,0,2 andexactly7 custody unresolved. Custody staysNOTPASS.
Failure/exhaustion produces a complete capture, no validationreceipt/PASS.
Check unchanged old Git tree/state, completepacket, resource bounds. Commit
only after validation; stageguard verifies all old mode/blobs and new raw
bytes. Local commit only. No scientific authority update, remote push,
restoration claim, unknownaCC measurement or whole-goal completion.
