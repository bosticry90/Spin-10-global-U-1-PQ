# Finite-functional WZ bridge and conditional reference operations

The actual source audit completed42.898s/120. Both full S0/U0 action routes
are Jx-free before restriction; all328 scalar F0/Fu0 maps vanish; T2F0=0 on
all643 canonical fields; matter has only positive-g KCP, and every fixed
regulator expression is source-free. Hence raw proper Gamma_g0,Gamma_u0 and
Delta_g0,Delta_u0 are Jx-independent in the specified finite-formal normalized
prescription. No new source-dependent counterterm/measure phase is admitted.
All6 Q0 field patterns and Q1/Qu1 preimages are enumerated without local
momentum/Lorentz restrictions. Qu1Delta_g0 is zero; Q1Delta_u0 uses LambdaC.

Question: is the finite-formal target identity QDelta=Q2Gamma justified by
the actual known square and the omitted-component support, and what exactly
can be said about carrying classical source substitutions through reference
limits? Do not read the numerical known remainder or reconstruct aCC here.

Audit source derivatives of FULL Q1/Qu1 maps before mean selection. The only
possible outer physical-potential exception in V812 is an A0 constant
tadpole replacing an undifferentiated Jx. Its Jx partial of Q1 must project
only to physical-source output coordinates; it then multiplies Gamma_u0,Jx=0.
All full Qu1 coefficients should be Jx-free; if not, withhold that exception
proof rather than discard it. Derivative Jx jets multiply D(tadpole)=0 only
because original A0 and couplings are translation invariant. Unknown physical
E1_x is source-free, so its Jx derivative is exactly0; its varied physical
terms have V812's support exclusions. This never sets its full value to0.
Other omitted potential terms retain a physical scalar mean under Q1x=xC;
Qu0/Qu1 physical flows are zero. Preserve all full partial/position evidence.

The actual CPS hatted terms have only P,S,c and derivatives, with no sources.
Their Hamiltonian coordinate coefficients retain a fermion mean; likewise
the actual matter source KCP and matter equations preserve P=S=K=0. Such
coefficients cannot survive multiplication by a formal Gamma derivative
with nonnegative mean powers. This is a mean-functional argument: do NOT
set the quantum insertion Ihat'' or its fermion trace to zero from it.

Q is an odd differential derivation. Q2 is even; its second-functional-
derivative terms cancel by graded Leibniz. Expand the full g/u convolutions
symbolically, retaining all4 terms. With V812's actual coordinate squares,
the just-audited physical exceptions and stable fermion ideal, the selected
finite-formal identity is
 Pi_LambdaCC[Q0Delta_gu+Q1Delta_u0+Qu0Delta_g1+Qu1Delta_g0]=0,
where Delta=QGamma for the SAME raw proper functional. This is integrability,
not restoration Delta=0. No full-Q2=0, infinite measure, QAP or counterterm
adoption follows. Keep every remaining input family until separately qualified.

Classical local source substitutions act on kernel distributions by transpose
of finite derivatives and diagonal restriction of SCHWARTZ TEST FUNCTIONS.
For embedding i that repeats coordinates, |i(x)|>=|x|, and chain rule gives
 p_(N,alpha)[(D_beta Phi) o i] <= C_(alpha,beta) sum_(|gamma|<=|alpha|+|beta|)
 p_(N,gamma)[Phi]. This proves continuity at ALL orders; bounded polynomial
checks are diagnostics, not the theorem. Its transpose is a continuous
pushforward S'->S', without pulling an unknown singular distribution back
to a diagonal or multiplying two quantum insertions. Thus these operations
commute with EXISTING distribution limits and with coefficients of a common
fixed linear S'-asymptotic finite-part expansion. This does not prove those
expansions exist for actual unmeasured amplitudes or permit separate contact
choices. Whole profiles and UV-first/IR-second order remain binding.

A normalized Gaussian approximate identity checks the contact distinction:
pointwise limit off0 is0 but pairings with exp(-x2) and exp(-x2-y2) on the
diagonal tend1. Losing that contact is a sensitive wrong-limit control.
Actual Q0a=iLambda and Q0C=Q0Lambda=0 make aCC->LambdaCC a continuous
injective rename times i. Check a derivative-bearing diagnostic polynomial
using prefix/LEFT Q0; inverse of its Q0 image is -i times the rename back.
If an eventual complete identity reads i R(A)+K=0, its dependent prediction
would be A=+i R^-1(K). These two signs must not be confused. No actual K is
read, no numerical prediction is made, and independent direct two-response
integration remains a required check before source-compatibility claims.

One120s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact. Freeze before computation, preserve failure,
no automatic retry. Written functional-analysis proof owns the all-order
lemma; exact algebraic checks diagnose representations, not Lean certification
or empirical validation. Shared action/ring/software/AI author disclosed.
