from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
import importlib.util,json,os,sys,threading,time
import sympy as sp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(s);s.loader.exec_module(z);return z
a=module('source_independence_action_tools',O/'source_audit.py');sq=module('qualified_actual_selected_square_tools',O.parent/'canonical_so10_selected_BV_square_g1_u1_v1/square_v2.py');J=a.J;w=a.w;one=J.constant(1)
def project(P):return {ww:c for ww,c in P.items() if sq.reason(ww) is None}
def rename(P,to_a=False):
 out={}
 for ww,c in P.items():J.put(out,tuple((n+90 if to_a and 508<=n<553 else n-90 if not to_a and 598<=n<643 else n,js) for n,js in ww),c)
 return J.clean(out)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'functional_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['known_consistency_images','consistency_tables.json','hard_response_v2.json']),'NUMERICAL_REMAINDER_INPUT_DENIED'
 sys.addaudithook(guard)
 own=a.read(O/'source_result.json');assert own['formal_Gamma_g0_and_Gamma_u0_Jx_independent'] and a.digest(O/own['artifact']['file'])==own['artifact']['sha256'];source=a.load(O/own['artifact']['file']);assert len(source['proper_derivative_checks'])==1286 and all(not q['T2_F0'] for q in source['proper_derivative_checks'])
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=a.load(base/'native_inputs.json.gz');maps,states,physical=sq.full_maps(packet);sourcepartials=[];counts={};unexpected=[]
 for label in ['Q1','Qu1_0','Qu1_1']:
  count=Counter();hits=[]
  for n,P in maps[label].items():
   eligible={};indexed={};positions=[]
   for at,(ww,c) in enumerate(sorted(P.items())):
    prefix=0
    for pos,(src,js) in enumerate(ww):
     if a.isJx(src):
      rest=ww[:pos]+ww[pos+1:];why=sq.reason(rest)
      if js:status='D_OF_CONSTANT_A0_TADPOLE_ZERO'
      elif why:status=why
      else:
       status='LEFT_PARTIAL_BEFORE_RESTRICTION';eligible[ww]=c;J.put(indexed.setdefault(src,{}),rest,c*((-1)**prefix))
      positions.append([at,pos,src,list(js),status]);hits.append([n,at,pos])
     prefix+=J.parity(src)
   partials=[]
   for src,p in sorted(indexed.items()):
    p=J.clean(p);peer=project(J.leftjet(eligible,(src,())));assert p==peer
    if p:
     count[a.source_group(n)]+=len(p)
     if not a.isJx(n):unexpected.append([label,n,src,J.encode(p)])
    partials.append(dict(input_source=src,projected_LEFT_partial=J.encode(p)))
   sourcepartials.append(dict(operator=label,coordinate=n,all_original_Jx_positions=positions,nonzero_or_canceled_partials=partials))
  counts[label]=dict(count);assert label=='Q1' or not hits,(label,'FULL_QU1_JX_DEPENDENCE')
 assert not unexpected and counts['Q1'] and set(counts['Q1'])=={'J_x'}
 print('STAGE all_potential_tadpole_exceptions_only_physical_sources_and_full_Qu1_Jx_free',flush=True)
 for role in ['primary','replay']:
  z=a.load(O.parent/'canonical_so10_chiral_probe_support'/(role+'_inputs.json.gz'))
  for p in z['hat_vertices']:assert p['origin'].startswith('E_') and sorted(v[0] for v in p['ports'])==['P','S','c']
  assert z['K_vertex']['g_degree']==1 and sorted(p[0] for p in z['K_vertex']['ports'])==['K','P','c']
 # Coupling convolution in a free noncommutative operator-word module.
 labels={(0,0):'Q0',(1,0):'Q1',(0,1):'Qu0',(1,1):'Qu1'};gammas={(0,0):'G0',(1,0):'Gg',(0,1):'Gu',(1,1):'Ggu'};delta=defaultdict(Counter)
 for (g,u),q in labels.items():
  for (h,v),ga in gammas.items():
   if g+h<=1 and u+v<=1:delta[g+h,u+v][q,ga]+=1
 lhs=Counter()
 for (g,u),q in labels.items():
  for (qq,ga),c in delta[1-g,1-u].items():lhs[q,qq,ga]+=c
 rhs=Counter({('Q0','Q0','Ggu'):1,('Q0','Q1','Gu'):1,('Q1','Q0','Gu'):1,('Q0','Qu0','Gg'):1,('Qu0','Q0','Gg'):1,('Q0','Qu1','G0'):1,('Qu1','Q0','G0'):1,('Q1','Qu0','G0'):1,('Qu0','Q1','G0'):1});assert lhs==rhs
 wrong=Counter(lhs)
 for (qq,ga),c in delta[1,0].items():wrong['Qu0',qq,ga]-=c
 assert +wrong!=lhs
 convolution=dict(Delta_components={str(k):[[*word,c] for word,c in sorted(p.items())] for k,p in delta.items()},full_gu_Q_Delta_words=[[*word,c] for word,c in sorted(lhs.items())],exact_Q_squared_grouping=True,omit_Qu0_Delta_g_changes_general_identity=True)
 # Injective a->i Lambda map, including derivative jets and odd signs.
 atom=lambda n,js=():{((n,tuple(js)),):one};P={}
 for mu in range(4):J.add(P,J.mul(J.mul(atom(598,(mu,)),atom(553)),atom(554,(mu,))))
 P=J.clean(P);fullQ0=maps['Q0'];native=sq.v.act(P,fullQ0,odd=True);left={}
 for token in sorted({t for ww in P for t in ww}):J.add(left,J.mul(J.Ds(fullQ0[token[0]],token[1]),J.leftjet(P,token)))
 left=J.clean(left);assert native==left==w.scale(rename(P),J.I)
 back=w.scale(rename(native,True),-J.I);wrongback=w.scale(rename(native,True),J.I);assert back==P and wrongback!=P
 for color in range(45):assert states['F0'][598+color]==w.scale(atom(508+color),J.I) and not states['F0'][508+color] and not states['F0'][553+color]
 injection=dict(diagnostic_aCC=J.encode(P),Q0_image_prefix_and_LEFT=J.encode(native),inverse_minus_i_back=J.encode(back),wrong_plus_i_inverse_difference=J.encode(w.plus(wrongback,w.scale(P,J.constant(-1)))),all45_doublets_checked=True,conditional_complete_WZ_rule='If i R(A)+K=0, A=+i R^-1(K); no actual K supplied.')
 # Exact source-test diagonal Gaussian control; this does not prove the
 # all-order seminorm theorem, whose proof is written and reviewed.
 x=sp.Symbol('x',real=True);eps=sp.Symbol('eps',positive=True);kernel=sp.exp(-x*x/eps**2)/(sp.sqrt(sp.pi)*eps);values=[]
 for n in [0,1,2]:
  integral=sp.integrate(kernel*sp.exp(-n*x*x),(x,-sp.oo,sp.oo));expected=1/sp.sqrt(1+n*eps**2);assert sp.simplify(integral-expected)==0 and sp.limit(integral,eps,0,dir='+')==1;values.append(dict(test_gaussian_power=n,exact_pairing=str(integral),limit=1))
 xp=sp.Symbol('xpos',positive=True);assert sp.limit(kernel.subs(x,xp),eps,0,dir='+')==0
 diagonal=dict(normalized_kernel=str(kernel),Schwartz_test_and_diagonal_pushforward_pairings=values,off_origin_pointwise_limit=0,wrong_discarded_contact_pairing=0,correct_distributional_pairing_limit=1,all_order_continuity_owned_by_written_proof_not_finite_tests=True)
 art=a.save('functional_bridge_tables.json.gz',dict(all_full_source_tadpole_partial_audits=sourcepartials,exception_output_counts=counts,all_exceptions_annihilated_by_Gamma_u0_Jx_independence=not unexpected,full_Qu1_coefficients_Jx_free=True,CPS_hatted_and_KCP_support_checked=True,graded_coupling_convolution=convolution,aCC_LambdaCC_injection=injection,source_test_diagonal_control=diagonal))
 result=dict(schema='SELECTED_FINITE_FUNCTIONAL_WZ_AND_SOURCE_TEST_BRIDGE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',potential_exceptions_only_scalar_source_outputs=True,full_Qu1_Jx_free=True,finite_formal_selected_Q_Delta_equals_zero_supported=True,raw_Gamma_prescription_and_formal_mean_series_required=True,conditional_Schwartz_distribution_reference_commutation_lemma=True,actual_unknown_amplitude_limit_existence_not_proved=True,aCC_image_map_injective_with_phase_i=True,no_numerical_aCC_prediction_or_known_remainder_read=True,no_full_restoration_QAP_or_E5_promotion=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'functional_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
