"""Check ordered compact gauge-source plateau and reference first-switch terms."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def load_owner():
    path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
    spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    return source


def literal_tables(source, phase):
    path = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = source.seagull.read(path / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    J, L, da, db, dc, JC, Ja, JL = [{} for _ in range(8)]
    for grade, word, cells in rows:
        if grade != 1 or len(word) != 3:
            continue
        (a,ea),(b,eb),(c,ec) = word
        slot = None
        if a < 180 and a%4 == 1:
            if b < 180 and 508 <= c < 553:
                assert b%4 == 1 and not (ea or eb or ec)
                slot, key = L, (c-508,a//4,b//4)
            elif 553 <= b < 598:
                if 643 <= c < 823 and (c-643)%4 == 1:
                    assert not (ea or eb or ec)
                    slot, key = J, ((c-643)//4,a//4,b-553)
                elif 598 <= c < 643:
                    assert (ea,eb,ec) in (([1],[],[]),([],[1],[]),([],[],[1]))
                    slot, key = (db if ea else dc if eb else da), (c-598,a//4,b-553)
        elif 553 <= a < b < 598 and 1196 <= c < 1241:
            assert not (ea or eb or ec)
            slot, key = JC, (c-1196,a-553,b-553)
        elif 553 <= a < 598 and 598 <= b < 643 and 1241 <= c < 1286:
            assert not (ea or eb or ec)
            slot, key = Ja, (c-1241,b-598,a-553)
        elif 508 <= a < 553 and 553 <= b < 598 and 1151 <= c < 1196:
            assert not (ea or eb or ec)
            slot, key = JL, (c-1151,a-508,b-553)
        if slot is not None:
            assert key not in slot and all(p[:2] == [0,0] for p,_,_ in cells)
            slot[key] = source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])
    return J, L, da, db, dc, JC, Ja, JL


def check(phase):
    source = load_owner()
    _, _, _, joined, _, _ = source.owner.inputs(phase)
    f = {(a,b,c):z for (b,c),items in joined.items() for a,z in items}
    def H(j):
        return int(j < 12)

    J, L, da, db, dc, JC, Ja, JL = literal_tables(source,phase)
    assert len(J) == len(da) == 1674 and J == da == {k:-z for k,z in f.items()}
    assert len(db) == len(L) == len(Ja) == len(JL) == 334
    assert len(dc) == 668 and len(JC) == 837
    assert L == {k:sp.I*z for k,z in f.items() if k[0] >= 12 and k[1] < 12 <= k[2]}
    assert db == {k:-z for k,z in f.items() if k[2] < 12 <= k[1]}
    assert dc == {k:(H(k[1])-H(k[2]))*z for k,z in f.items() if H(k[1]) != H(k[2])}
    assert JC == {k:z for k,z in f.items() if k[1] < k[2]}
    assert Ja == JL == {k:-z for k,z in f.items() if k[2] < 12 <= min(k[:2])}

    by_source = defaultdict(list)
    by_mixed = defaultdict(list)
    for (a,v,i),z in J.items():
        by_source[v,i].append((a,z))
    for (u,v,b),z in f.items():
        by_mixed[u].append((v,b,z))
    T = defaultdict(lambda: sp.S.Zero)
    counts = defaultdict(int)
    omitted = 0
    for (i,u,c),antighost in da.items():
        F = antighost-db.get((i,u,c),0)
        bracket = (JC.get((i,c,u),0) if c < u else -JC.get((i,u,c),0))
        bracket += Ja.get((u,i,c),0)
        assert F == bracket
        for v,b,z in by_mixed[u]:
            aux = L.get((u,min(v,b),max(v,b)),sp.S.Zero)/sp.I
            external = dc.get((u,v,b),0)-da[u,v,b]
            assert sp.expand(F*(aux+z)-bracket*external) == 0
            assert sp.expand(F*z+bracket*da[u,v,b]) == 0
            for a,j in by_source[v,i]:
                sector = "".join("H" if H(k) else "M" for k in (v,u,i))
                counts[sector] += 1
                T[sector,a,b,c] += j*F*aux
                omitted += int(sp.expand(j*(antighost*(aux+z)-bracket*external)) != 0)

    def square(sector):
        return sp.expand(T[sector,17,1,32]+T[sector,17,32,1]
                         -T[sector,17,13,32]-T[sector,17,32,13])
    square_rows = {k:str(square(k)) for k in sorted(counts) if square(k)}
    assert len(counts) == 8 and omitted
    assert square_rows == {"HMM":"-1/10","MMH":"1/10","MMM":"-1/10"}

    s, ds = sp.symbols("s ds")
    u = s*(1-s)
    assert sp.expand(s**4+s**3*(1-s)) == s**3
    assert sp.expand(s**2*(sp.diff(u,s)*ds+s*ds)-s*u*ds) == 0
    return {"sector_order":"ordinary BB, paired quartet, other ghost",
            "ordered_returning_contractions":sum(counts.values()),
            "all_eight_sectors_match":True,
            "ordered_first_switch_reference_pair_zero":True,
            "prior_square_rows":square_rows,
            "omitted_dB_failures":omitted}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
