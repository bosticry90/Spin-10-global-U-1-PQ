# V965 pre-execution contract

Freeze the V879 literal source and action, V791 inverse,
V943 mixed source triangle, V945 derivative ghost rows
and V961 compact mixed master signs. Compare three
returning triangles at a constant plateau in the local
one-exterior-derivative transverse gauge-source jet.
Keep the derivative on the internal mixed gauge leg and
the nonminimal cancellation in the ghost master root.
Test all ordered color contractions and eight internal
H/M sector labels with both action exports. Match only
the paired mixed/ghost profiles. Check the first derivative of the common switch on the
paired reference roots only. Do not impose equality of
the ordinary H/M profiles or extend to the full first-
switch, longitudinal, metric, nonlocal or marked products.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.

V1 failed at the expected gauge-square sector label. The stored order is ordinary BB, paired mixed quartet, other ghost. The ordinary mixed quartet in the V943 triangle is always M, so the +1/10 row with other ghost H is MMH. Preserve the V1 source, preparation and capture. V2 keeps the exact same witness and all termwise gates with corrected label and the same limits.
