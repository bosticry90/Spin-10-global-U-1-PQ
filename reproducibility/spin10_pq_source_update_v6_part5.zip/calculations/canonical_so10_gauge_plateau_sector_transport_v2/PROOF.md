# Matched gauge-source plateau transport by internal sector

Use output a for J_B, b for the derivative ghost and c
for the other ghost. Let v label ordinary transverse BB,
u the mixed/paired quartet and i the other ordered ghost.
Write h_j=1 for light j, zero otherwise, and m_j=1-h_j.
All terms below are in the source-first master sign,
with one common graph and radial coefficient stripped.

In the V943 ordinary triangle the literal source row is
-f_(a v i) in its original order. The internal derivative
residue is d_a-d_B=-f_(i u c)(1-m_u h_c). Both choices of
the ordinary exterior B at the BB Lambda vertex give
the factor i(h_v-h_b) f_(u v b). The derivative on the
internal antighost and the mixed Green give their common
paired phase. Moving the odd fields to source-first
order and varying across J_B gives the master sign
used here. Define

    A=f_(a v i) f_(i u c) f_(u v b)(1-m_u h_c).

Then the ordinary master coefficient is T=(h_v-h_b) A.
The compact mixed Euler carrier of V961 transfers its
Lambda derivative to the exterior ghost on the plateau.
It keeps the same internal mixed derivative residue,
including the d_B term. Its signed coefficient is +A.
The ghost Euler carrier has oriented source bracket
f_(i c u), with the opposite nonminimal contribution
on c in H and i,u in M. On f support that mask is
1-m_u h_c because [H,M] is in M. Its exterior F port
has d_C-d_a=(1+h_v-h_b) f_(u v b). The odd permutation
cancels the original minus of the source row, giving
the sign of f_(i c u)=-f_(i u c). Thus its signed
coefficient is -(1+h_v-h_b) A. These three terms
cancel before summing over internal indices.

The literal tables check all four derivative/source
patterns and the two nonminimal root signs. The
executable tests every returning contraction in the
ordered jet and independently verifies the prior
gauge-square witness by sector. A control that omits
d_B fails. All three hard kernels contain the common
transverse angular projector. The ordinary and mixed
master terms have F_B(v) F_L(u) F_C(i)/Q^2 after the
hard derivative contraction. The ghost root has
F_B(v) F_C(u) F_C(i)/Q^2 after its Euler collapse.
They agree when the u quartet profiles match, with
no equality needed between ordinary H and M profiles.
This identifies the selected collapsed local primitive,
without equating unexpanded products at separated jets.

At a constant switch s the ordinary term is s^4 T.
The reference master terms together give
s^3(1-s)(-T) in the quantity being subtracted.
The ordered difference is s^3 T on this projection.
On the first common switch jet the mixed root uses
partial(s(1-s))+s partial s=(1-s) partial s from V961.
Including the two spectator switches gives
+s^2(1-s)(partial s) A. In the ghost root the derivative
of the switch at the exterior ghost F port uses -d_a
instead of d_C-d_a. This gives -s^2(1-s)(partial s) A.
They cancel termwise with the same matched profiles.
This check covers the two reference roots only. The
ordinary metric, additional first-switch master roots,
light longitudinal propagators, balanced finite
extensions and marked products require separate tests.
Both literal routes share the model and software.
