# V965 · Matched gauge-source plateau transport

The ordinary mixed triangle and the two compact
reference roots satisfy the plateau relation in all
eight internal H/M sectors. The two reference roots
also cancel on their selected first derivative of the
common switch. Both comparisons use the local transverse
gauge-source jet and matched mixed/ghost quartet profiles.

Both action exports reproduce 58,314 ordered returning
contractions. Omitting the derivative on the internal
mixed gauge leg fails 9,948 comparisons. Matching the
paired quartet does not require a common ordinary H/M
profile.

Version 1 used the wrong order in the expected sector
label of the prior square witness. Its source and capture
remain in D control. The ordinary metric, other first-
switch roots, longitudinal profiles, finite weights and
marked products have separate obligations.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
