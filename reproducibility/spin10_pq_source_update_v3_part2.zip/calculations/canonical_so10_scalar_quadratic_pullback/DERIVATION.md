# SQP1 fixed-parameter scalar quadratic operations

Write H=V''(v), C=diag(10 on Phi54,25/2 on Sigma252,9/2 on phi20,0 on S2),
and TC=V'''(v)[Cv]. All couplings, including stationary mass values and the
independent Higgs mass/root, are held fixed while taking field derivatives.
The reference w_ref and field phi are independent until differentiation.
The current frozen point has zero phi20 VEV and nonzero Phi,Sigma,S radii.

For an actual invariant p_alpha O_alpha, let n_alpha be the sum of its field
Casimirs, counted from the action AST, including conjugate fields. Since the
Casimir is constant on each parent irreducible sector,

    (C phi).V'_alpha = n_alpha V_alpha,
    n_alpha H_alpha = (V'''_alpha)[Cv] + C H_alpha + H_alpha C.

This is a weighted polynomial identity, not stationarity. The gauge potential
parameter pole is the inherited GPC1 dp_alpha=-3n_alpha p_alpha/2 in L*g²
units. SWF1 gives zS=(3-xi)C and BVN1 d=(3+xi)Cv/2 in those same units.
Define alpha=(3+xi)/2, beta=(3-xi)/2. The resulting quadratic operators are

    Hpar = -3(TC+CH+HC)/2,
    Href = alpha TC,
    Hend = beta(CH+HC),
    Hp = Hpar+Href = xi TC/2-3(CH+HC)/2,
    Htotal = Hpar+Href+Hend = xi D2,
    D2 = (TC-CH-HC)/2.

Hp is QTR1's surviving potential operator. Replacing it by Htotal would keep
the mass part of a field endpoint after discarding its kinetic companions.
The complete endpoint trace cancels only as a complete operation. Htotal
instead matches the fixed-reference OFV1 density xi(Ew-Ephi/2), where
Ew=w_ref^T C V'(phi), Ephi=phi^T C V'(phi).

To construct TC without a new third-order tensor, take each nonzero raw
Hessian monomial with radial degrees d_r and external sector legs i,j. Its
fixed-parameter derivative along radius q_r is

    (d_r-leg_ir-leg_jr) H_alpha,ij / q_r.

Contract with C_r q_r and then sum all fixed physical p_alpha. The same
coefficient follows from n_alpha-C_i-C_j after removing the two external
legs. Surviving raw entries have exactly two phi20 external legs whenever
phi20 fields occur; additional zero-VEV phi factors have zero Hessian. The
original raw nonzero support and complete SMF1 transport supply the scope.

For example, an infinitesimal bare-action pullback on a raw Hessian entry is

    (1+e beta C_i)(1+e beta C_j)
      sum_alpha p_alpha(1-3e n_alpha/2) H_alpha,ij
        product_r (1+e alpha C_r)^(d_r-leg_ir-leg_jr),

where e²=0. Taking each first-order term separately gives parameter, reference
and field endpoint matrices. Metrics are fixed physical kinetic maps; their
two endpoint factors and h.c./imaginary coordinate conventions are retained.

At the stationary point let h=H Cv. The tadpoles are tpar=-3h/2, tref=alpha h,
tend=0 and ttotal=xi h/2. They are correlated operations, not a chosen quantum
minimum shift. The potential pole density at the point is zero but its first
and second field derivatives need not be. No physical finite counterterm is
selected by these simple-pole identities.

For any of the45 gauge generators T or the PQ generator, [C,T]=0 and HO=0,
O=T v. Differentiating the invariant parent Ward identity gives

    TC O + H T Cv = T H Cv.

The parameter/reference pullback therefore obeys

    Hp O + alpha H T Cv = T ttotal.

For the complete fixed-reference field quadratic it gives

    D2 O + H T Cv = T h/2.

Both are generally nonzero term by term. In particular do not require the CT
to annihilate the Goldstone orbit. The gauge-fixing Goldstone mass/width terms
and their QTR1 trace cancellations are separate from these potential terms.
The PQ orbit and tuned Higgs zeros remain in the full328-dimensional domain.

As a negative control, tying w_ref=phi before the OFV1 second derivative gives
(TC+CH+HC)/2 rather than D2: the error is CH+HC. Its first derivative at the
stationary point is unchanged, so that first-derivative test cannot certify
reference independence. Preserve this sensitivity limit in the final report.

This is an assembly of previously qualified one-loop UV data. It does not
fix epsilon-suppressed finite terms, x1/general-extra CTs, mass/VEV/tadpole
finite conditions, full C1, the QAP or E5. The parent invariance and earlier
loop poles remain inherited premises, not independently remeasured here.
