"""SQP1 immutable source/input closure and pre-execution resource contract."""
from pathlib import Path
from hashlib import sha256
import json,subprocess

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-quadratic-pullback-v1-2026-10-20')
BASE='712e4cc6b49c6d8101c3a850a199a3c7556628b1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT).decode().strip()=='main'
prior=json.loads((ROOT/'calculations/canonical_so10_quadratic_counterterm_trace/validation_preparation.json').read_bytes())
for name,h in prior['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
CONTROL.mkdir(parents=True,exist_ok=False)
files=list(map(Path,prior['input_sha256']))
for folder in ['canonical_so10_quadratic_counterterm_trace','canonical_so10_gauge_potential_uv',
               'canonical_so10_radial_uv_kernel','canonical_so10_scalar_sm_frame']:
    files.extend(p for p in (ROOT/'calculations'/folder).iterdir() if p.is_file())
files.extend([ROOT/'AGENTS.md',ROOT/'project_state.json',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V389.md'])
for p in list(HERE.iterdir()):
    if p.suffix in ['.py','.md']:
        if p.suffix=='.py':compile(p.read_bytes(),str(p),'exec')
        with (HERE/(p.name+'.source.txt')).open('xb') as out:out.write(p.read_bytes())
files.extend(HERE.iterdir())
tree=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(tree.splitlines())==25004
with (CONTROL/'old_git_tree.txt').open('xb') as out:out.write(tree)
files.append(CONTROL/'old_git_tree.txt')
value={'schema':'C1_SCALAR_QUADRATIC_PULLBACK_PREPARATION_V1','base_commit':BASE,'old_git_blobs':25004,
       'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))},
       'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,
       'sampled_private_limit':8*1024**3,'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2}
with (HERE/'preparation.json').open('xb') as out:out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(value['input_sha256']),'bindings',25004,'old blobs',flush=True)
