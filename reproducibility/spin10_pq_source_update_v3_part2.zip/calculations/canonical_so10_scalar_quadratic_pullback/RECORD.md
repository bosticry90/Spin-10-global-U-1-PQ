# SQP1: the complete gauge-squared scalar potential pullback

Prospective at712e4cc6b49c6d8101c3a850a199a3c7556628b1/main,2026-10-20.
Previous QTR1 qualified the specified C1 quadratic trace reduction; its scalar
potential insertion is the parameter/reference pullback, excluding complete
field endpoints. The radial-only RCP1 does not supply that full operator.
Question: can the current qualified SWF/BVN/GPC/OFV and SMF1 data construct
it exactly, without a new large loop or component-tensor calculation?

Freeze actual original C1 gauge/scalar/ghost action, physical parent/POINT,
fixed coefficient values, complete SMF1 frame/34 Hessian directions, original
raw parent blocks/metrics, AST field occurrences, qualified GPC multipliers,
SWF field pole and BVN reference pole. xi remains symbolic; g10 is not chosen.
Stripped units L*g10^2, L=hbar/(16pi^2 epsilonUV); canonical real328 fields,
35 complete SM multiplicity classes. Higgs root w remains a real algebraic
symbol, with no parameter-dependent vacuum family substituted before field
differentiation. No gauge-fixing term is silently absorbed into a potential.

DERIVATION.md freezes the required first-order operations and Ward checks.
Produce the full weighted radial third derivative TC=V'''[Cv], H_parameter,
H_reference, H_endpoint, D2 and the trace-reduced H_pullback. Check every
coefficient/zero and exact real/transpose, metric and conjugation conditions.
Retain correlated tadpoles and nonstationary Goldstone insertions. Do not
label D2 alone as QTR1's scalar insertion. Keep g0 RSC1 and g4 GQH1 separate;
these known measured operators can be combined later, without a new point lift.

Primary: current physical SMF1 Hessian columns, AST Casimir sums and fixed
radial powers. Replay: original raw Gaussian-integer parent blocks and metric
normalization, qualified GPC pole multipliers and total weighted Euler
homogeneity with both external legs removed. Independent reconstruction of
canonical matrices through the corresponding complete Q,D maps. Both routes
derive their values before the verifier reads the RCP1 radial answer.

Verifier imports no new native helper. Use a literal infinitesimal bare-action
scaling on each original raw parent Hessian monomial, keeping parameter,
reference and endpoint variations as separate dual-number coefficients.
Compare all328 squared positions, then the qualified nine-position RCP1 D2
projection and all45+PQ linearized potential Ward identities. Verify the
Goldstone-projected insertions without declaring tuned or physical zero modes
irrelevant. Structural identities concern the potential and its spurion
reference, not a new whole Slavnov/QAP theorem.

Controls: tying reference to field must change the second curvature by CH+HC;
the first stationary derivative is insensitive and is disclosed. Omission of
the reference or endpoint contribution must change actual full matrices.
Direct O(2) shifted-polynomial expansion must distinguish the fixed-parameter
derivative from differentiating stationary masses, and preserve a nonzero
Goldstone CT. A massless tree direction is not grounds for a zero insertion.
No quantum coefficient is inferred from the value needed for a Ward zero.

Outcomes: qualified exact input assembly under inherited poles/action; a
convention or coefficient discrepancy; or bounded incomplete. Freeze sources,
proof, immutable input closure and controllers before computing. Native120s,
verifier180s AFTER imports,8GiB sampled private NOTpeak,350MiB launch floor,
4MiB package. Full captures before assertions; preserve/version failures.
Sequential independent calculations, compare only completed outputs, then
separate verification. Do not repeat qualified loop integrals or giant tensors.

Same action, parent coefficient/representation data, software and AI analyst
are shared premises. No external scientist/Lean/empirical validation. Sole
authority remains state113/34of39,E5/A5unqualified,HB1/C5blocked,flavorpaused,
C1_GSuncalculated,quartetFAIL3960/648,custodyexit2/seven. Scalar140%/1.94%/
20.27%,matching.745476/missingYukawas remain distinct. No finite scheme,
physical mass/VEV/tadpole condition, foundation or protected promotion adopted.
