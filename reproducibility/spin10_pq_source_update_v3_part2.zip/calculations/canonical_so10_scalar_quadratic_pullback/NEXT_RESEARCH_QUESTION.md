# Next: resolve the surviving C1 trace dependencies

SQP1 now supplies Hp, including the nonstationary Goldstone potential terms.
With RSC1 g0 and GQH1 g4 this removes the need for another large scalar
potential component calculation at this point. Do not repeat the qualified
algebra or choose finite masses/VEVs/tadpoles just to produce a number.

The next dependency question should concern what actually survives the full
counterterm trace: its first-width term, coupling/mass jet and any genuine
additional quadratic operator. QTR1 explicitly kept these. Before measuring
a quantum vector/ghost/width pole, determine whether its coefficient can affect
the selected background F² hard matching coefficient at all.

A bounded structural candidate is the first-width trace Tx1. Investigate the
actual vector-to-ghost covariant derivative identity for Kv, then its F²
projection on the positive heavy color subspace. A constant Cartan curvature
can serve as a coefficient probe only after locality and derivative order are
justified; it is not permission to impose the background EOM on the entire
functional. Preserve arbitrary external momentum until projection and keep D
dependence, including epsilon terms. A nonzero full off-shell trace may have
a different F² hard coefficient. Conversely an unmeasured trace is not zero.

Keep massless unbroken fields and common SM-EFT subtraction explicit. Never
transfer a positive-heavy/analytic expansion result to an infrared massless
loop or call an unseparated scaleless expression zero. Use a nonzero
proper-time/ordered-operator control and a negative control for missing ghost
partners if this route is adopted. Freeze its exact claim/domain before math.

Separately recover the MSbar gauge-coupling UV pole with the actual gauge/
scalar loop-content convention. The full-theory M01 group indices contain
fermion contributions; they must not silently become the gauge/scalar subset
or resume paused flavor. Decide which existing records can establish the
required coupling jet, rather than fitting it to threshold consistency.

If additional operators genuinely survive or the admissible pullback domain
is incomplete, identify their smallest required input and retain that gap.
No constant, finite condition or counterterm is selected from the value
needed to improve the gauge-matching residual. Full finite amplitude tests
and physical gauge refit remain unearned until the complete calculation.
