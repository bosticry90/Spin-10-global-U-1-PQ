# SQP1 supplies the full gauge-squared scalar quadratic input

Completed at base712e4cc6/main, with two agreeing derivations and a separate
bare-action verifier. Receipt SHA256:
`f114ea24ef86152ca0ad2e10c3de0a779d13fcfcc70357d531739aaa5fd153f6`.
This closes the nonradial potential-input gap identified after RCP1 and QTR1.
It is an exact assembly of existing one-loop UV poles, not a new measurement
of a loop amplitude, a finite mass prediction or a numerical C1 result.

With H=V''(v), C the actual sector Casimir matrix and TC=V'''[Cv], the tables
now contain, in stripped L*g10² units,

    Hpar  = -3(TC+CH+HC)/2,
    Href  = (3+xi)TC/2,
    Hend  = (3-xi)(CH+HC)/2,
    Hp    = Hpar+Href = xi TC/2-3(CH+HC)/2,
    Htotal= Hpar+Href+Hend = xi D2,
    D2    = (TC-CH-HC)/2.

Hp is the potential insertion in the QTR1 reduced trace. Htotal instead
contains the mass portion of the complete field-normalization operation.
That operation's kinetic and background-vertex companions must accompany it.
After the QTR1 cancellation, retaining Htotal in place of Hp would therefore
be wrong. The original C1 trace is at tree Feynman gauge xi=1; keeping xi
symbolic here verifies the potential pole family and does not assert QTR1's
gauge-fixing trace reduction for an arbitrary nonminimal tree gauge.

All328 real scalar coordinates,35 SM classes and34 real parent coefficient
directions are included. Eight operator tables, including the tree Hessian
and derived TC, are compared over all107,584 positions each. These are
algebraic positions, not independent quantum integrals. Stored nonzero support:

| Operator | Retained symbolic entries |
| --- | ---: |
| H | 4,851 |
| TC | 4,850 |
| Hpar | 4,850 |
| Href | 4,850 |
| Hend | 4,850 |
| Hp | 4,850 |
| D2 | 2,950 |
| Htotal | 2,950 |

The zero complements and all signs/real-conjugate maps are checked. The Higgs
root remains symbolic and real; support counts are not statements about a
numerical spectrum. No tree zero mode was removed from this domain.

The correlated tadpole is ttotal=xi H Cv/2. Its three radial entries and all
nine radial D2 positions reproduce RCP1 exactly, without using that result to
determine the new coefficients. The full D2 has nonzero gauge-Goldstone and
PQ-Goldstone potential images. In particular the gauge-orbit projected matrix
P D2 P is nonzero. These terms cannot be discarded because the tree potential
has Goldstone zero modes. The g0 RSC1 and g4 GQH1 operators remain separate,
unchanged measured inputs; neither a new finite prescription nor a new g4
point-lift coefficient was inferred from this calculation.

All45 gauge generators and PQ satisfy the action-derived linearized identities

    TC T v + H T Cv = T H Cv,
    Hp T v + (3+xi)H T Cv/2 = T ttotal,
    D2 T v + H T Cv = T H Cv/2.

They are not zero-CT-stationarity tests. Requiring D2 T v=0 would omit the
reference/source-related terms of the actual operation. These are potential
Ward relations, not a new complete quantum Slavnov or QAP theorem.

The primary differentiated current SMF1 coefficient Hessians along the
fixed-parameter radial directions and counted actual AST Casimirs. Replay
reconstructed the operators from the609 original raw parent Hessian terms,
their kinetic metrics and qualified GPC1 multipliers, using the independent
weighted Euler identity after subtracting both external legs. All serialized
matrices, zeros and tadpoles agree. The verifier imported no new native
helper: it expanded the literal bare parameter/reference/endpoint product
using dual numbers, reconstructed all35 classes and canonical operators, then
checked RCP1, the full Ward images and Goldstone projections.

Sensitive controls detect tying the reference to the field before the second
derivative: the error is exactly CH+HC. The first stationary derivative is
insensitive and is explicitly not used to certify that distinction. Omitting
reference or endpoint contributions changes actual full matrices. A separate
shifted O(2) polynomial has a nonzero Goldstone CT lambda*v² and rejects
differentiating a stationary mass family instead of fixed physical couplings.
No unknown coefficient was fitted to a required cancellation.

Commands were prepare.py, run.py, prepare_validation.py and run_validation.py
with python -B in this directory. Frozen bindings1653/1660. Native times after
imports78.8956104s and78.9016057s; verifier97.7027794s. All scientific workers
exit0, no failed scientific executions. Full launch and execution captures are
retained. Samples40/40/50, maximum121,012,224 bytes private allocation, NOT a
peak measurement. Caps120/180s,8GiB sampled,350MiB launch floor,4MiB package
unchanged. Packed tables158,321 bytes each, SHA
e12b9ff2589a7d3c727b0aa57a761c290dc64f3c7e881eadd04cad5ad815b47a;
decompressed1,659,698 bytes, SHA
d46de336a6aedc1f2eb00f8734d4bf6842dc1f5461c1831d21a127cb7923ba96.
One read-only historical-file discovery guessed a nonexistent NEXT document;
it failed before any scientific result was qualified and changed no evidence.

Track B: action homogeneity recovered the needed nonradial operator without a
new giant third-order tensor or repeated loop calculation. The methods still
share the action, old Hessian/AST ancestry, pole premises, software and AI
analyst. No outside, Lean or empirical validation is implied. Old E4/E5 audits
and expensive kernels were authenticated rather than freshly executed. The
analytic scope does not include new epsilon-suppressed finite coefficients,
the unresolved first-width/general-extra quadratic trace, local two-loop
background CT, UV/EFT hard subtraction or full finite C1 amplitude.

All old evidence/state/action/point/scheme/policy bytes remain unchanged.
Scientific authority34/39,state113,E5/A5unqualified,HB1/C5blocked,flavorpaused,
finiteC1_GSuncalculated,quartetFAIL3960/648 and custodyexit2/seven remain.
Scalar140%/1.94%/20.27%, matching.745476 and missingYukawas are distinct
physical limitations and are unaffected. The overall Spin(10)xPQ goal is
active and incomplete.
