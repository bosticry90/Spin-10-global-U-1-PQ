"""SQP1 current-frame radial derivative versus raw-parent weighted Euler route."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,os,sys,threading,time
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from inputs import coeffs,w
xi=s.Symbol('xi',real=True)
CAS={'Phi':s.Integer(10),'Sigma':s.Rational(25,2),'SigmaBar':s.Rational(25,2),
     'phi':s.Rational(9,2),'phiBar':s.Rational(9,2),'S':s.S.Zero,'SBar':s.S.Zero}
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok()
def dec(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals={'w':w,'xi':xi}) for i,j,z in d['entries']})
def enc(M):return {'shape':list(M.shape),'entries':[[i,j,str(z)] for (i,j),z in sorted(tidy(M).todok().items())]}
def read(p):return json.loads(p.read_bytes())
def inflate(blocks,small):
    out={}
    for b,M in zip(blocks,small):
        m=b['multiplicity'];off=b['offset']
        for a in range(b['dimension']):
            for (i,j),z in M.todok().items():out[off+a*m+i,off+a*m+j]=z
    return s.SparseMatrix(328,328,out)

def controls():
    x,y,v,lam=s.symbols('x y v lam',real=True)
    m=s.Symbol('m',real=True);V=m*(x*x+y*y)/2+lam*(x*x+y*y)**2/4
    # A nonzero weighted Casimir is allowed for this polynomial derivative fixture.
    Ephi=x*s.diff(V,x)+y*s.diff(V,y);Ew=v*s.diff(V,x)
    fixed=Ew-Ephi/2;tied=Ephi/2;at={x:v,y:0,m:-lam*v*v}
    A=s.hessian(fixed,(x,y)).subs(at);B=s.hessian(tied,(x,y)).subs(at)
    H=s.hessian(V,(x,y)).subs(at)
    zero(B-A-2*H)
    assert tidy(B-A).todok() and s.diff(fixed,x).subs(at)==s.diff(tied,x).subs(at)
    assert clean(A[1,1])==lam*v*v
    literal=s.expand(V.subs(m,-lam*v*v));assert s.diff(literal,y,2).subs({x:v,y:0})==0
    wrong=s.hessian(V.subs(m,-lam*(x*x+y*y)),(x,y)).subs({x:v,y:0})
    assert tidy(wrong-H).todok()
    return {'tied_reference_second_derivative_detected':True,'first_stationary_derivative_insensitive':True,
            'nonzero_Goldstone_CT':str(A[1,1]),'stationary_family_differentiation_rejected':True}

def main():
    start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=read(HERE/'preparation.json')
    for name,h in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
    role=sys.argv[1];assert role in ['primary','replay']
    slots,cc,degrees,cv,point,_=coeffs()
    old=read(ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json')
    frame=json.loads(gzip.decompress((ROOT/('calculations/canonical_so10_scalar_sm_frame/'+role+'_tables.json.gz')).read_bytes()))
    ast=read(PK/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions']
    weights={n:sum((CAS[t['name']] for t in row['density']['argument']['factors'] if t['node']=='Field'),s.S.Zero) for n,row in ast.items()}
    poles=read(ROOT/('calculations/canonical_so10_gauge_potential_uv/'+role+'_result.json'))
    small={key:[] for key in ['H','TC','Hpar','Href','Hend','Hp','D2','Htotal']}
    print('STAGE all34_parameter_directions_and35_fixed_parameter_thirds',flush=True)
    for ib,(row,block) in enumerate(zip(old['block_inputs'],frame['blocks'])):
        m=len(row['sectors']);assert m==block['multiplicity'] and row['label']==block['label']
        H=s.SparseMatrix(m,m,{});TC=H.copy();Hpar=H.copy()
        if role=='primary':
            for k,slot in enumerate(slots):
                name,_,part=slot.partition(':');p=cc[name]
                p=s.im(p) if part=='im' else s.re(p)
                A=tidy(p*dec(frame['parent_blocks'][ib][k]));H+=A
                # Fixed physical parameters; the two external coordinate legs do not scale with v.
                for (i,j),z in A.todok().items():
                    scales=[]
                    for r in range(3):
                        def leg(sec):return int(sec=='Phi') if r==0 else int(sec in ['Sigma','SigmaBar']) if r==1 else int(sec in ['S','SBar'])
                        power=degrees[name][r]-leg(row['sectors'][i])-leg(row['sectors'][j]);assert power>=0
                        scales.append(power*z/point[r])
                    TC[i,j]+=sum(CAS[sec]*point[r]*scales[r] for r,sec in enumerate(['Phi','Sigma','S']))
                Hpar+=-s.Rational(3,2)*weights[name]*A
        else:
            metrics=list(map(s.Rational,row['metric']))
            for k,i,j,z in row['raw_H34_sparse']:
                name=slots[k].partition(':')[0];value=cv[k]*s.sympify(z)/s.sqrt(metrics[i]*metrics[j])
                H[i,j]+=value
                TC[i,j]+=(weights[name]-CAS[row['sectors'][i]]-CAS[row['sectors'][j]])*value
                multiplier=s.sympify(poles['multipliers_by_slot'][slots[k]])
                Hpar[i,j]+=multiplier*value
        H,TC,Hpar=map(tidy,[H,TC,Hpar]);C=s.diag(*(CAS[sec] for sec in row['sectors']))
        anti=tidy(C*H+H*C);zero(Hpar+s.Rational(3,2)*(TC+anti))
        Href=tidy((3+xi)*TC/2);Hend=tidy((3-xi)*anti/2)
        Hp=tidy(Hpar+Href);D2=tidy((TC-anti)/2);Htotal=tidy(Hp+Hend);zero(Htotal-xi*D2)
        for key,M in zip(small,[H,TC,Hpar,Href,Hend,Hp,D2,Htotal]):small[key].append(M)
    print('STAGE complete328_canonical_transport_and_linearized_Ward',flush=True)
    Q,D,J=map(dec,[frame['Q'],frame['D'],frame['real_conjugation']]);Qi=s.SparseMatrix(328,328,{(i,i):1/D[i,i] for i in range(328)})*Q.H
    full={}
    for key,values in small.items():
        A=inflate(frame['blocks'],values);zero(A.H*D-D*A);zero(A*J-J*A.conjugate())
        M=tidy(Q*A*Qi);zero(M-M.T);zero(M-M.conjugate());full[key]=M
    data=read(PK/('frozen_a10_physical_reconciliation/full_'+role+'.json'));v=dec(data['vacuum']['VEV']);O=dec(data['vacuum']['orbit'])
    C=s.diag(*([10]*54+[s.Rational(25,2)]*252+[s.Rational(9,2)]*20+[0]*2))
    Cv=tidy(C*v);h=tidy(full['H']*Cv);t2=tidy(xi*h/2)
    zero(full['H']*O)
    rhos=[s.SparseMatrix(s.diag(*(dec(data['representation_matrices'][sec][a]) for sec in ['Phi','Sigma','phi','S']))) for a in range(45)]
    pq=s.SparseMatrix(328,328,{})
    for lo,hi,charge in [(54,306,2),(306,326,-2),(326,328,-4)]:
        for i in range(lo,hi,2):pq[i,i+1]=-charge;pq[i+1,i]=charge
    rhos.append(pq)
    for T in rhos:
        orbit=T*v;zero(full['TC']*orbit+full['H']*T*Cv-T*h)
        zero(full['Hp']*orbit+(3+xi)*full['H']*T*Cv/2-T*t2)
        zero(full['D2']*orbit+full['H']*T*Cv-T*h/2)
    # Counterterm Goldstone images must not be discarded.
    assert tidy(full['D2']*O).todok()
    assert tidy(full['Hp'].subs(xi,1)-full['D2']).todok()
    E=s.SparseMatrix(328,3,{})
    for r,(lo,hi) in enumerate([(0,54),(54,306),(326,328)]):
        for i in range(lo,hi):
            if v[i]:E[i,r]=v[i]/point[r]
    radial=tidy(E.T*full['D2']*E);radial_t=tidy(E.T*h/2)
    check=controls()
    payload={'schema':'C1_SCALAR_QUADRATIC_PULLBACK_TABLES_V1',
             'matrices':{n:enc(M) for n,M in full.items()},'blocks':{n:[enc(M) for M in rows] for n,rows in small.items()},
             'carrier_Casimirs':{n:str(z) for n,z in weights.items()},'h':enc(h),'t2':enc(t2),
             't_parameter':enc(-3*h/2),'t_reference':enc((3+xi)*h/2),
             'radial_D2':enc(radial),'radial_t2_without_xi':enc(radial_t),'controls':check,
             'units':'hbar*g10**2/(16*pi**2*epsilon_UV)','xi_symbolic':True}
    raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as out:out.write(packed)
    result={'schema':'C1_SCALAR_QUADRATIC_PULLBACK_NATIVE_V1','execution_state':'COMPLETED','route':role,
            'SM_classes':35,'real_scalar_fields':328,'parameter_directions':len(slots),
            'support':{n:len(M.todok()) for n,M in full.items()},'radial_D2':enc(radial),
            'radial_t2_without_xi':enc(radial_t),'all45_plus_PQ_Ward_relations':True,
            'nonzero_Goldstone_potential_CT_retained':True,'RCP1_target_read':False,
            'controls':check,'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(packed).hexdigest(),
            'table_bytes':len(raw),'packed_bytes':len(packed),'new_loop_or_finite_C1_or_E5':False,
            'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
