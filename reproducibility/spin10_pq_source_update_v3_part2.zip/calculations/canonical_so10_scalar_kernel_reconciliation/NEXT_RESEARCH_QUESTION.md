# Next: complete the actual C1 quadratic counterterm insertion

The full g10^0 scalar-potential counterterm is recovered. Do not return to
unmeasured nonradial scalar U0 tensors: RSC1 supplies all34 global coefficient
polynomials and the full point Hessian/tadpole, with the existing assumptions.
GQH1 supplies the full g10^4 point Hessian; its globally blind point quartics
are not needed merely to identify that quadratic insertion. SWF1/BVN1/OFV1
already supply the relevant scalar field/reference/potential identities.

Recover the actual BFT1 physical reference density and distinguish its
potential Hessian from its gauge-fixing scalar mass, mixed vector/scalar
terms and ghost/auxiliary kernels. Assemble the complete local quadratic
counterterm by differentiating the bare action and field/parameter/reference
pullbacks, preserving both field endpoints. Include scalar delta p,delta Z,
delta w and required delta g/delta xi/other width companions under their
actual frozen definitions. RCP1's radial GF projection vanished because
O^T E=0; this cannot be transferred to nonradial fields.

The fixed-reference g10^2 potential Hessian can be recovered compactly from
the already qualified radial third matrices and Casimirs; no general new
third-order tensor is needed. For C=diag-sectorCasimirs and stationary v,
D2=[sum_k(Cv)_k V'''_k - CH-HC]/2. Keep the reference independent before
specializing, as in RCP1/OFV1. This alone is not the complete unprojected
gauge-fixing counterterm.

First reconcile existing actual C1 input evidence and identify the smallest
missing pole/normalization relationship. Older M06/M07 and gauge kernels
may contain reusable pieces, but RSC1 did NOT validate historical gauge signs
or import the old defective A10 kinetics. Match the actual physical convention
and source/field normalization before reuse; avoid a broad replay or treating
old PASS labels as proof. Do not fit an unknown loop coefficient to enforce
a Ward cancellation or silently set a width/reference counterterm to zero.

The next useful result is one complete, auditable quadratic insertion (or
the exact missing definition preventing it), suitable for the C1 two-loop
subtraction. Keep finite mass/VEV/tadpole conditions and physical input
translations separate from UV poles. No new finite scheme, flavor inputs,
blocked-stage activation, source-functional integration or E5/C1 promotion
is implied. Reassess remaining dependencies before another large calculation.
