# RSC1 — full scalar-potential counterterm recovered and reconciled

The existing unshifted M03/M04/M05 scalar kernels supply the complete
one-loop scalar-potential subtraction for the current parent action. Both
recovery routes and the separate current verifier completed at
cd12c2c03cfbfd532964700961a1782dc4e5c0f0. No new large tensor contraction
was necessary. This is qualified reuse and current transport of inherited
calculations, not a fresh independent measurement of every loop coefficient.

## What is now available

In the current sign convention the scalar loop pole is -L*U0 and the
counterterm is +L*U0, where

    U0 = Tr328[V''(phi)^2]/4,
    L = hbar/(16*pi^2*epsilon_UV).

The recovered global polynomial covers all34 real parent directions:
four quadratic, four cubic and26 quartic. Its coefficient dictionaries
contain342 retained coupling monomials. The vacuum constant is kept
separately; it is not discarded or promoted to a physical cosmological term.
The complete coefficients are in primary_tables.json.gz/replay_tables.json.gz.

The new fixed-point canonical Hessian has4,892 retained symbolic entries
and102,692 exact stored zeros across328x328 positions. The algebraic Higgs
root w remains exact; support counts describe the stored symbolic
representation, not a numerical physical spectrum or separate amplitudes.
All35 SM multiplicity blocks and their implicit cross-state zeros are
reconstructed through the qualified complete SMF1 frame.

The recovered operator reproduces the separately qualified SRC1 potential
value, three tadpoles and nine radial curvatures exactly. The POINT quadratic
is used only after field differentiation for the field-independent value;
parameters remain fixed during differentiation. Thus the previously missing
nonradial scalar-potential subtraction input no longer requires a new
third/fourth-tensor expansion.

This is the g10^0 scalar-loop part. It does not determine the three free
coefficients of the separate g10^4 point lift. It also does not supply a
finite scalar mass, a vacuum displacement or the finite two-loop threshold.

## Why the old evidence applies

For V=V2+V3+V4, write H_k=V_k''. Homogeneous field degree separates the
operator exactly:

| Degree | Contribution | Recovered input |
| --- | --- | --- |
| 0 | Tr(H2^2)/4 | Explicit mass-operator trace |
| 1 | Tr(H2 H3)/2 | Forbidden invariant linear operator; zero |
| 2 | Tr(H2 H4)/2+Tr(H3^2)/4 | M03 pure-scalar traces |
| 3 | Tr(H3 H4)/2 | M04 pure-scalar contractions |
| 4 | Tr(H4^2)/4 | M05 complete26-direction scalar kernel |

The old exact328 parent component basis is matched to every current A31
embedding column, including the self-dual-form orientation and all kinetic
normalizations/zeros. Primary compares ambient tensors; replay uses the
weighted embedding inverse and forward reconstruction. These are the
unchanged parent fields, not an import of the defective historical A10 gauge
action or a field-name/rank-only identification.

The parent component basis hashc66398... differs in meaning from the old
factorized physical-eigenbasis hashaf6354.... Their explicit link is checked;
no old float eigenvectors or masses are used. Contract/plan embedded hashes
are authenticated as their declared logical canonical-payload digests,
separately from raw-file/Git hashes. There was no missing hash repaired by
normalizing/rebinding protected evidence.

The current M03/M04/M05 kernel source bytes equal their source bytes at the
evidence commits eb28ad9d/07f624eb/b137c83b. Nested primary/replay/evidence
bindings, specification hashes and the complete scalar replay comparisons
authenticate. Their original qualifications, exact invariant-basis closure
and complete symbolic contractions remain inherited mathematical premises;
the new13-position SRC1 comparison alone would not prove a global identity.

## Checks on the recovery

Primary extracts explicit scalar-only M03/M04 polynomials and contracts the
M05 primary matrices. Replay reconstructs mass coefficients from its own
sector/cubic traces, cubic coefficients from its4x11 matrices and quartics
from the previously uncompared independent26-matrix artifact. Every exact
symbolic coupling polynomial and zero complement is compared before point
evaluation. Table-specific coupling order and complete Hermitian real/imag
directions are retained. Only symmetric coefficient forms matter for these
commuting coupling variables; no noncommuting physical matrix was reordered.

All parent counterterm values are evaluated once at the actual point and
then held fixed. The complete current Hessian is real and symmetric, with
the proper kinetic/reality transport. All45 gauge and PQ Ward images satisfy
Hct*T v=T*tct. They are nonzero in general: the counterterm is not stationary
at the tree vacuum. The false Hct*T v=0 inference is explicitly rejected.

The separate verifier imports no native helper. It reconstructs complete
polynomial supports, verifies current AST degrees4+4+26, compares all13 SRC1
positions exactly, reconstructs the full328x328 SM-coordinate image and
checks every gauge/PQ image. An exact O2 polynomial anchors
delta m²=4lambda*m², delta lambda=10lambda² and the vacuum m^4/2. Missing
the vacuum constant, reversing the complex-imaginary completion and
differentiating a stationary parameter family all fail their controls.

The old specifications sometimes label positive TrH²/4 as a loop pole.
This recovery fixes it as the counterterm polynomial under the current OFV1
opposite-loop-pole convention before comparing SRC1. The simple-pole
1/epsilon_bar coefficient is transferred; no finite MS-bar prescription is
adopted. Historical gauge/field-conversion terms remain excluded and require
their own convention reconciliation. Negative unshifted mass parameters are
evaluated only in the UV-local polynomial, not used to assert a finite
tachyonic-reference integral exists.

## Execution and limitations

Native/validation preparations bind1,525/1,532 inputs. Times after imports:
35.0451519s primary,34.6380503s replay,40.6304383s verifier. Zero failed
RSC1 native/verifier executions; the earlier GSC1 failures remain preserved
under their own record. Successful resource samples18/18/21; maximum
84,004,864B, NOT a measured peak. Frozen60s native/90s verifier,8GiB sampled
private,350MiB launch floor and4MiB package were unchanged. No expensive
old kernel generator, whole finite loop or eigenbasis run was repeated.

Completed receipt SHA256:
`537e0d12ce964611510133575f0442b30af4f211ed10b13e4bc86907b78bf645`.
Both native gzip tables SHA256:
`ac1cdf0e99535c6c7eeec00ce6c1cbcbfc0b48b8d958634499a4a583eb13f858`;
decompressed SHA256:
`f84e8f894617e8d39e8868c759477bad9b3b771eda77dbf71431927cd62a69fb`.

Track A gains a complete recovered local scalar-potential subtraction input.
Track B demonstrates useful evidence reconciliation and cross-checking,
including correction of raw/logical-hash and parent/eigenbasis distinctions.
The broader reusable-kernel search should have happened earlier: additional
new UV tensor work would have duplicated existing results. GSC1 still
provides a useful separate orbit-cubic map, but recovery now takes priority
over more component calculations. Shared action/oracle ancestry, old kernel
qualifications, software and AI author limit independence; no outside,
Lean or experimental confirmation is claimed.

The complete scalar quadratic insertion still needs the actual gauge-fixing,
field/reference/width/coupling companions, followed by the full two-loop
UV/EFT subtraction and a justified finite prescription. RSC1 does not close
those conditions. State113/34of39, E5/A5unqualified,HB1/C5blocked,flavorpaused,
C1_GSuncalculated,quartetFAIL3960/648,custodyexit2/seven and separate scalar
140%/1.94%/20.27%,matching.745476/missingYukawa warnings remain unchanged.
No old evidence/action/point/source/state/policy/scheme or external action
changed. Whole Spin(10)xPQ investigation remains active and incomplete.
