# RSC1 — recover the full scalar counterterm instead of remeasuring it

Prospective atcd12c2c03cfbfd532964700961a1782dc4e5c0f0/main,2026-10-20.
Previous increment GSC1 completed the full34-orbit cubic reduction, not the
complement/full scalar curvature. Recovery located existing complete M03,
M04 and M05 PURE-SCALAR symbolic kernels with independent replay evidence.
Question: do these supply the current C1 full local scalar counterterm after
an exact convention/source/basis reconciliation? This can avoid a new large
third/fourth-tensor contraction. Do not silently inherit historical gauge
terms or a formal full compiler pass from a component result.

Freeze actual parent hash01323e0f6a025edd6f6669b43e7c730f5350e28d8561e72df89636862ca358ed,
current POINT and fixed coefficients, A31 embeddings/kinetic tensor metrics,
complete SMF1 field map/raw34 Hessians, old exact real_field_basis.json,
M03/M04 primary/replay/evidence/specification and M05 full scalar26 matrices/
uncompared replay/comparison/evidence. Bind relevant old source modules and
their dependencies without reexecuting the expensive kernel generators.

Historical contract/plan SHA fields are LOGICAL canonical-payload digests,
not hashes of pretty-printed raw JSON. Authenticate that declared schema;
also bind raw current/Git bytes separately. The contract's physical_basis
hashaf6354... names a factorized physical eigenbasis. Its underlying parent
component hashc66398... is the exact328 basis used by the scalar kernels.
Only the latter is needed here; no old float eigenvector/mass map is imported.
Current kernel source bytes were checked against their evidence commits:
M03eb28ad9d, M0407f624eb, M05b137c83b. Repeat that Git-binding check in prep.

## Complete operator and normalization

For fixed parent parameters, V=V2+V3+V4 and H_k=V_k'', the already qualified
scalar subtraction is U0=Tr[(H2+H3+H4)^2]/4 multiplying
L=hbar/(16*pi^2*epsilon_UV). Old1/epsilon_bar has the same simple-pole
coefficient; no finite MS-bar convention is adopted. Homogeneous parts are
constant TrH2²/4, linear TrH2H3/2 (zero since no invariant linear operator),
quadratic TrH2H4/2+TrH3²/4 (M03), cubic TrH3H4/2 (M04), and quartic
TrH4²/4 (M05). The actual invariant basis contains4 real quadratic,
4 real cubic and26 real quartic directions. Preserve the vacuum constant
separately: [54(2mPhi²)^2+252(2mSigma²)^2+20(mphi²)^2+2(mS²)^2]/4.
No finite vacuum-energy or tadpole normalization is selected.

The old M03/M04 specifications call the positive TrH²/4 polynomial a
"Pole[V1_scalar]". Here the operator is fixed as the COUNTERTERM U0 under
the current OFV1 convention; the loop contribution is -L U0. Do not import
an ambiguous historical loop/pole label or its historical gauge signs.
This convention is fixed before any SRC1 comparison, not fitted afterward.

Primary reads explicit scalar-only M03 sector ledgers and M04 scalar
polynomials, then contracts the complete M05 primary26x26 matrices. Replay
rebuilds the four scalar mass coefficients from its own sector traces and
cubic contractions, its four cubic coefficients from the4x11 contraction
matrices and its quartics from the uncompared independent26-matrix output.
Compare all exact symbolic coefficient polynomials/implicit zeros before
evaluation, including Hermitian real/imaginary directions. Map legacy
z*_re/z*_im to current z*:re/z*:im; no complex phase/sign convention change.
Every resulting scalar polynomial must be free of g10/xi/gauge fields.
Respect each table's declared coupling order. These matrices index commuting
coupling variables, so compare their symmetric quadratic forms; an
antisymmetric coefficient part contributes identically zero. This does not
permit reordering noncommuting propagator or color matrices.

Prove all328 old canonical basis columns equal the current A31 embeddings,
including exact self-dual form orientation, tensor metric and implicit zeros.
Primary compares ambient columns, replay uses the weighted embedding inverse.
No full eigenstate/field-name/rank-only identification is sufficient. The
old invariant-kernel completeness proofs are inherited, not independently
reproved by a new13-position point test or an expensive fresh kernel run.

Evaluate the full34 scalar counterterm coefficients at the actual parent
point ONCE. They then stay constant under external-field differentiation;
do not differentiate stationary/tuned parameter families. Use the qualified
SMF1 raw34 Hessians and both kinetic endpoints to obtain all35 multiplicity
blocks/full328-field operator. This is a global-coefficient reconstruction,
not a fit to the desired point Hessian; invisible point directions retain
their actual old global values rather than being set to zero.

Native routes may not read SRC1 expected coefficient values before extraction.
The verifier compares the new potential value,3 tadpoles and9 radial curvature
positions with qualified SRC1 exactly, using the POINT quadratic only after
field differentiation. Check the full gauge/PQ Ward images Hct*T v=T*tct;
the nonstationary counterterm Hessian need NOT annihilate the orbit. Confirm
all34 global directions, real/conjugate structure and current kinetic map.
GSC1 is a partial cubic norm and cannot be equated to this full curvature.

Verifier imports no new native helper. Rebuild coefficients through original
scalar trace/matrix data and compare complete polynomial supports. Use exact
O2 TrH² normalization with delta m²=4 lambda*m²,delta lambda=10lambda² and
vacuum m^4/2; reject a missing vacuum constant, complex-imaginary orientation
and stationary-family differentiation. Root reduction/physical branch stay
separate from an algebraic degree-counting identity. No loop coefficient is
chosen from whatever value makes SRC1 or a Ward equation pass.

Outcomes: qualified recovery of full scalar-loop local counterterm input;
an explicit convention/source/normalization discrepancy; genuinely incomplete
old evidence; or bounded incomplete. Any mismatch remains, rather than being
fitted away. Native60s/verifier90s AFTER imports,8GiB sampled private NOTpeak,
350MiB launch floor,4MiB package. Freeze all sources/inputs/proof/controllers;
complete captures before assertions. Authenticate old results, do not rerun
their costly contractions. No old evidence/state/action/source/scheme changes.

This is conditional reuse of old independently derived kernels under their
declared parent/basis/UV assumptions, plus a current exact integration and
nontrivial cross-check. Shared action, source oracle ancestry, software and
AI author remain; no outside/Lean/empirical confirmation. No gauge/field/
VEV/source/finite prescription is inferred from scalar success. State113/
34of39,E5/A5unqualified,HB1/C5blocked,flavorpaused,C1_GSuncalculated,
quartetFAIL3960/648,custodyexit2/seven and scalar/matching/Yukawa warnings
remain. Whole Spin(10)xPQ goal active; no protected promotion or external action.
