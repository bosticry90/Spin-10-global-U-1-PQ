"""Bind both completed native outputs before the separately implemented verifier."""
from pathlib import Path
from hashlib import sha256
import json

HERE = Path(__file__).resolve().parent
prep = json.loads((HERE/'preparation.json').read_bytes())
for name,digest in prep['input_sha256'].items():
    assert sha256(Path(name).read_bytes()).hexdigest() == digest, name
files = list(map(Path,prep['input_sha256']))+[HERE/'preparation.json']
for role in ['primary','replay']:
    cap = json.loads((HERE/(role+'_capture.json')).read_bytes())
    assert cap['execution_state'] == 'COMPLETED' and cap['exit_code'] == 0
    files.extend([HERE/(role+'_capture.json'),HERE/(role+'_result.json'),HERE/(role+'_tables.json.gz')])
value = {'schema':'C1_GS_SCALAR_KERNEL_RECONCILIATION_VALIDATION_PREPARATION_V1',
         'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}}
with (HERE/'validation_preparation.json').open('xb') as out:
    out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('VALIDATION_FROZEN',len(value['input_sha256']),flush=True)
