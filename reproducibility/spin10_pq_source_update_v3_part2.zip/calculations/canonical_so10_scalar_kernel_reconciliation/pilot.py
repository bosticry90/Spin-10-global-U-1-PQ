"""RSC1 pure-scalar global coefficient recovery and current point transport."""
from pathlib import Path
from hashlib import sha256
import gzip
import json
import os
import sys
import threading
import time
import sympy as s
from kernels import authenticate,basis_check,scalar_polynomials,old_to_current,decode,encode,tidy,clean,zero

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from inputs import coeffs,reduce_root

def inflate(blocks,small):
    out={}
    for block,B in zip(blocks,small):
        off=block['offset'];m=block['multiplicity']
        for a in range(block['dimension']):
            for (i,j),z in B.todok().items():out[off+a*m+i,off+a*m+j]=z
    return s.SparseMatrix(328,328,out)

def main():
    start=time.perf_counter();timer=threading.Timer(60,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'preparation.json').read_bytes())
    for name,h in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
    role=sys.argv[1];assert role in ['primary','replay']
    print('STAGE old_logical_evidence_and_exact_parent_basis',flush=True)
    records,basis,contract,plan=authenticate();basis_check(basis,role)
    print('STAGE complete_symbolic_scalar_counterterm_extraction',flush=True)
    polys,env=scalar_polynomials(records,role)
    slots,cc,_,_,point,quad=coeffs();subst={}
    for name,symbol in env.items():
        current=old_to_current(name);n,_,part=current.partition(':')
        subst[symbol]=s.im(cc[n]) if part=='im' else s.re(cc[n])
    delta={old_to_current(n):clean(z.subs(subst)) for n,z in polys.items()};assert set(delta)==set(slots)
    vacuum=clean((54*(2*cc['mPhi2'])**2+252*(2*cc['mSigma2'])**2+20*cc['mphi2']**2+2*cc['mS2']**2)/4)
    a,b,c=q=s.symbols('x y z',real=True)
    p=delta
    V=vacuum+p['mPhi2']*a*a+p['mSigma2']*b*b+p['mS2']*c*c/2+p['muPhi']*a**3/s.sqrt(60)
    V+=(p['lambdaPhi1']+7*p['lambdaPhi2']/60)*a**4+(p['lambdaPhiSigma1']-p['lambdaPhiSigma2']/4)*a*a*b*b
    V+=p['lambdaPhiS']*a*a*c*c/2+p['lambdaSigma1']*b**4+p['lambdaSigmaS']*b*b*c*c/2+p['lambdaS']*c**4/4
    at=dict(zip(q,point));value=reduce_root(V.subs(at),quad)
    t=s.Matrix([clean(s.diff(V,x).subs(at)) for x in q]);radial=s.hessian(V,q).subs(at).applyfunc(clean)
    print('STAGE all35_blocks_and_full_gauge_PQ_Ward_transport',flush=True)
    tab=json.loads(gzip.decompress((ROOT/('calculations/canonical_so10_scalar_sm_frame/'+role+'_tables.json.gz')).read_bytes()))
    small=[]
    for block in tab['parent_blocks']:
        n=block[0]['shape'][0]
        small.append(tidy(sum((delta[slot]*decode(block[k]) for k,slot in enumerate(slots)),s.SparseMatrix(n,n,{}))))
    A=inflate(tab['blocks'],small);Q,D,J=map(decode,[tab['Q'],tab['D'],tab['real_conjugation']])
    Qi=s.SparseMatrix(328,328,{(i,i):1/D[i,i] for i in range(328)})*Q.H
    zero(A.H*D-D*A);zero(A*J-J*A.conjugate());H=tidy(Q*A*Qi);zero(H-H.T);zero(H-H.conjugate())
    PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
    data=json.loads((PK/('frozen_a10_physical_reconciliation/full_'+role+'.json')).read_bytes());v=decode(data['vacuum']['VEV'])
    E=s.SparseMatrix(328,3,{})
    for r,(lo,hi) in enumerate([(0,54),(54,306),(326,328)]):
        for i in range(lo,hi):
            if v[i]:E[i,r]=v[i]/point[r]
    grad=tidy(E*t);zero(E.T*H*E-radial)
    for a in range(45):
        rho=s.SparseMatrix(s.diag(*(decode(data['representation_matrices'][n][a]) for n in ['Phi','Sigma','phi','S'])))
        zero(H*rho*v-rho*grad)
    pq=s.SparseMatrix(328,328,{})
    for lo,hi,charge in [(54,306,2),(306,326,-2),(326,328,-4)]:
        for i in range(lo,hi,2):pq[i,i+1]=-charge;pq[i+1,i]=charge
    zero(H*pq*v-pq*grad)
    assert (H*decode(data['vacuum']['orbit'])).todok(),'COUNTERTERM_NOT_STATIONARY_FALSE_ZERO_CONTROL'
    tables={'schema':'C1_GS_SCALAR_KERNEL_RECONCILIATION_TABLES_V1',
            'parameter_polynomials':{old_to_current(n):str(z) for n,z in polys.items()},
            'delta':{n:str(z) for n,z in delta.items()},'vacuum_constant':str(vacuum),
            'H':encode(H),'blocks':[encode(B) for B in small],'gradient':encode(grad),
            'radial_gradient':encode(t),'radial_Hessian':encode(radial),'potential_value':str(value),
            'loop_factor':'hbar/(16*pi**2*epsilon_UV)','historical_gauge_terms_imported':False,
            'old_physical_eigenbasis_imported':False}
    raw=json.dumps(tables,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as out:out.write(packed)
    result={'schema':'C1_GS_SCALAR_KERNEL_RECONCILIATION_NATIVE_V1','execution_state':'COMPLETED','route':role,
            'directions':34,'quadratic':4,'cubic':4,'quartic':26,'SM_classes':35,'real_fields':328,
            'old_parent_basis_columns_checked':328,
            'parameter_polynomials':tables['parameter_polynomials'],'delta':tables['delta'],
            'potential_value':str(value),'radial_gradient':encode(t),'radial_Hessian':encode(radial),
            'H_nonzero':len(H.todok()),'H_zero':328**2-len(H.todok()),
            'full_gauge_PQ_Ward_image_checked':True,'SRC1_target_values_read':False,
            'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(packed).hexdigest(),
            'full_finite_C1_or_E5_complete':False,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
