"""RSC1 separate coefficient/support, SRC1 and convention verifier."""
from pathlib import Path
from functools import lru_cache
from hashlib import sha256
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
OLD=ROOT/'tools/two_loop_qft_compiler_v1';PK=OLD/'m08_independent_replay_package_v1'
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from inputs import coeffs,reduce_root,w

@lru_cache(None)
def clean(x):return s.cancel(s.expand(x))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok()
def read(p):return json.loads(p.read_bytes())
def dec(row):return s.SparseMatrix(*row['shape'],{(i,j):s.sympify(z,locals={'w':w}) for i,j,z in row['entries']})
def current(n):return n[:-3]+(':re' if n.endswith('_re') else ':im') if n.endswith(('_re','_im')) else n
def digest(d,key='artifact_sha256'):
    raw=dict(d);expected=raw.pop(key)
    assert sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest()==expected

def controls():
    x,y,m,lam,zr,zi,u,v=s.symbols('x y m lam zr zi u v',real=True)
    V=m*(x*x+y*y)/2+lam*(x*x+y*y)**2/4
    U=s.expand(s.trace(s.hessian(V,(x,y))**2)/4)
    expected=m*m/2+(4*lam*m)*(x*x+y*y)/2+(10*lam**2)*(x*x+y*y)**2/4
    assert s.expand(U-expected)==0 and s.expand(U-(expected-m*m/2))==m*m/2
    mon=(x+s.I*y)**2*(u-s.I*v);physical=s.expand((zr+s.I*zi)*mon+s.conjugate((zr+s.I*zi)*mon))
    assert s.expand(physical-2*zr*s.re(mon)+2*zi*s.im(mon))==0
    assert s.expand(physical-(2*zr*s.re(mon)+2*zi*s.im(mon)))!=0
    # m is fixed during differentiation; substituting m=-lam*x^2 first is a different family.
    fixed=s.diff(U,x).subs({m:-lam*v*v,x:v,y:0})
    tied=s.diff(U.subs(m,-lam*x*x),x).subs({x:v,y:0})
    assert s.expand(fixed-tied)!=0
    return {'O2_full_TrH2_polynomial_matches':True,'missing_vacuum_constant_rejected':True,
            'complex_imaginary_orientation_rejected':True,'stationary_family_rejected':True}

def main():
    start=time.perf_counter();timer=threading.Timer(90,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=read(HERE/'validation_preparation.json')
    for name,h in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
    a,b=[read(HERE/(role+'_result.json')) for role in ['primary','replay']];tabs=[]
    for role,result in zip(['primary','replay'],[a,b]):
        packed=(HERE/(role+'_tables.json.gz')).read_bytes();raw=gzip.decompress(packed)
        assert sha256(raw).hexdigest()==result['tables_sha256'] and sha256(packed).hexdigest()==result['packed_sha256']
        tabs.append(json.loads(raw))
    assert tabs[0]==tabs[1];tab=tabs[0]
    print('STAGE all_symbolic_scalar_kernel_coefficients_and_declared_evidence',flush=True)
    p3,r3,p4,r4,p5,r5=[read(OLD/name) for name in ['uvp_m03_primary_attempt2.json','uvp_m03_independent_replay_attempt2.json','uvp_m04_primary_attempt2.json','uvp_m04_independent_replay_attempt2.json','uvp_m05_complete_scalar_v4v4.json','uvp_m05_independent_scalar_replay_uncompared.json']]
    for d in [p3,r3,p4,r4,p5,r5]:digest(d)
    quartics=p5['inventory']['input_quartic_directions'];cubics=['muPhi','muPhiPhi','z6_re','z6_im']
    columns=['lambdaPhi1','lambdaPhi2','lambdaPhiphi1','lambdaPhiphi2','lambdaPhiS','lambdaPhiVector1','lambdaPhiVector2','lambdaVectorS','lambdaS','zK_re','zK_im']
    masses={'Phi':'mPhi2','Sigma':'mSigma2','phi':'mphi2','S':'mS2'};factors={'Phi':2,'Sigma':2,'phi':1,'S':1}
    names=list(masses.values())+cubics+quartics;env={n:s.Symbol(n,real=True) for n in names};derived={}
    ast=read(PK/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions']
    classified={2:set(),3:set(),4:set()}
    for n in names:
        name=current(n).partition(':')[0]
        degree=sum(node['node']=='Field' for node in ast[name]['density']['argument']['factors'])
        classified[degree].add(n)
    assert classified=={2:set(masses.values()),3:set(cubics),4:set(quartics)}
    for sec,mass in masses.items():
        for inner in masses:
            assert set(p3['quartic_trace_table'][sec][inner])==set(r3['quartic_trace_table'][sec][inner])
            for n,z in p3['quartic_trace_table'][sec][inner].items():assert clean(s.sympify(z)-s.sympify(r3['quartic_trace_table'][sec][inner][n]))==0
        assert clean(s.sympify(p3['cubic_trace_table'][sec]['V3_ACD_V3_ACD'],locals=env)-s.sympify(r3['cubic_trace_table'][sec]['V3_ACD_V3_ACD'],locals=env))==0
        total=s.S.Zero
        for inner,mname in masses.items():
            for n,z in p3['quartic_trace_table'][sec][inner].items():
                if n=='zD':assert s.sympify(z)==0;continue
                total+=s.sympify(z)*env[n]*factors[inner]*env[mname]/2
        total+=s.sympify(p3['cubic_trace_table'][sec]['V3_ACD_V3_ACD'],locals=env)/2
        derived[mass]=clean(total/factors[sec])
    for n in cubics:
        P=s.Matrix(p4['scalar_coefficient_matrices'][n]);R=s.Matrix(r4['scalar_coefficient_matrices'][n]);zero(P-R)
        derived[n]=clean((s.Matrix([env[x] for x in cubics]).T*P*s.Matrix([env[x] for x in columns]))[0])
        assert clean(derived[n]-s.sympify(p4['scalar_residues'][n],locals=env))==0
    vector=s.Matrix([env[x] for x in quartics])
    replay_order=r5['inventory']['quartic_input_directions'];permutation=[replay_order.index(x) for x in quartics]
    for n in quartics:
        P=s.Matrix(p5['coefficient_tables'][n]);rawR=s.Matrix(r5['coefficient_tables'][n]);R=rawR.extract(permutation,permutation)
        # Only the symmetric part contributes for commuting coupling variables.
        zero(P+P.T-R-R.T)
        derived[n]=clean((vector.T*P*vector)[0])
    assert len(derived)==34 and set(map(current,derived))==set(tab['delta'])
    support_positions=0
    for n,expr in derived.items():
        actual=s.sympify(tab['parameter_polynomials'][current(n)],locals=env)
        assert s.Poly(expr,*env.values())==s.Poly(actual,*env.values())
        support_positions+=len(s.Poly(expr,*env.values()).terms())
    print('STAGE actual_parent_point_and_SRC1_value_tadpoles_curvature',flush=True)
    slots,cc,_,_,point,quad=coeffs();sub={}
    for n,z in env.items():
        name,_,part=current(n).partition(':');sub[z]=s.im(cc[name]) if part=='im' else s.re(cc[name])
    delta={current(n):clean(expr.subs(sub)) for n,expr in derived.items()}
    for n,value in delta.items():assert clean(value-s.sympify(tab['delta'][n],locals={'w':w}))==0
    source=read(ROOT/'calculations/canonical_so10_scalar_radial_counterterm/primary_result.json')
    pointvalue=s.sympify(tab['potential_value'],locals={'w':w});sourcevalue=s.sympify(source['potential_exact'],locals={'w':w})
    assert reduce_root(pointvalue-sourcevalue,quad)==0
    grad=dec(tab['radial_gradient']);radial=dec(tab['radial_Hessian'])
    zero(grad-s.Matrix([s.sympify(z,locals={'w':w}) for z in source['gradient_exact']]))
    zero(radial-s.Matrix([[s.sympify(z,locals={'w':w}) for z in row] for row in source['curvature_exact']]))
    frame=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_scalar_sm_frame/replay_tables.json.gz').read_bytes()))
    Q,D=dec(frame['Q']),dec(frame['D']);Qi=s.SparseMatrix(328,328,{(i,i):1/D[i,i] for i in range(328)})*Q.H
    zero(Q.H*Q-D)
    H=dec(tab['H']);A=tidy(Qi*H*Q);zero(H-H.T);zero(H-H.conjugate())
    expected_A={}
    for ib,block in enumerate(frame['blocks']):
        off=block['offset'];m=block['multiplicity']
        B=tidy(sum((delta[slot]*dec(frame['parent_blocks'][ib][k]) for k,slot in enumerate(slots)),s.SparseMatrix(m,m,{})))
        zero(B-dec(tab['blocks'][ib]));zero(A[off:off+m,off:off+m]-B)
        for k in range(block['dimension']):
            for (i,j),z in B.todok().items():expected_A[off+k*m+i,off+k*m+j]=z
    zero(A-s.SparseMatrix(328,328,expected_A))
    print('STAGE full_nonstationary_Ward_and_kinetic_reality_checks',flush=True)
    data=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');v=dec(data['vacuum']['VEV']);t=dec(tab['gradient'])
    for a0 in range(45):
        T=s.SparseMatrix(s.diag(*(dec(data['representation_matrices'][sec][a0]) for sec in ['Phi','Sigma','phi','S'])))
        zero(H*T*v-T*t)
    phase=s.SparseMatrix(328,328,{})
    for lo,hi,q in [(54,306,2),(306,326,-2),(326,328,-4)]:
        for i in range(lo,hi,2):phase[i,i+1]=-q;phase[i+1,i]=q
    zero(H*phase*v-phase*t)
    assert (H*dec(data['vacuum']['orbit'])).todok()
    check=controls()
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<4*1024**2
    result={'schema':'C1_GS_SCALAR_KERNEL_RECONCILIATION_VALIDATION_V1','execution_state':'COMPLETED',
            'status':'QUALIFIED_RECOVERY_FULL_SCALAR_POTENTIAL_COUNTERTERM_INPUT',
            'global_parameter_directions':34,'quadratic':4,'cubic':4,'quartic':26,
            'symbolic_nonzero_coupling_monomials':support_positions,'real_fields':328,'SM_classes':35,
            'SRC1_exact_positions_compared':13,'vacuum_constant_retained':True,
            'full_gauge_PQ_nonstationary_Ward_images':True,'historical_gauge_or_eigenbasis_imported':False,
            'old_expensive_kernel_generators_rerun':False,'negative_controls':check,
            'finite_C1_or_E5_or_whole_goal_complete':False,'authority_changed':False,
            'inherited_global_kernel_and_action_premises':True,'input_bindings':len(prep['input_sha256']),
            'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
