"""RSC1 immutable scalar-kernel records; no SRC1 expected values are read."""
from pathlib import Path
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
import gzip
import json
import sympy as s

ROOT=Path(__file__).resolve().parents[2];OLD=ROOT/'tools/two_loop_qft_compiler_v1'
PK=OLD/'m08_independent_replay_package_v1'
DOMAINS=[('Phi',0,54,100),('Sigma',54,252,504),('phi',306,20,20),('S',326,2,2)]
CUBICS=['muPhi','muPhiPhi','z6_re','z6_im']
M04COLS=['lambdaPhi1','lambdaPhi2','lambdaPhiphi1','lambdaPhiphi2','lambdaPhiS','lambdaPhiVector1','lambdaPhiVector2','lambdaVectorS','lambdaS','zK_re','zK_im']
MASS={'Phi':'mPhi2','Sigma':'mSigma2','phi':'mphi2','S':'mS2'}
FACTORS={'Phi':2,'Sigma':2,'phi':1,'S':1}
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok()
def read(path):return json.loads(path.read_bytes())
def logical(d,key='artifact_sha256'):
    work=dict(d);expected=work.pop(key)
    assert sha256(json.dumps(work,sort_keys=True,separators=(',',':')).encode()).hexdigest()==expected
    return expected
def decode(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals={'w':s.Symbol('w',real=True)}) for i,j,z in d['entries']})
def encode(M):return {'shape':list(M.shape),'entries':[[i,j,str(z)] for (i,j),z in sorted(M.todok().items()) if z]}
def old_to_current(n):return n[:-3]+(':re' if n.endswith('_re') else ':im') if n.endswith(('_re','_im')) else n

def authenticate():
    contract=read(OLD/'one_loop_uv_pole_evaluator_contract.json');plan=read(OLD/'uv_pole_evaluator_execution_plan.json')
    ch=logical(contract,'uv_pole_evaluator_contract_sha256');ph=logical(plan,'execution_plan_sha256')
    assert ch=='6e256b9f8b2ed0e7243acc96d96daa854410673f59334b126446666d488ffe92'
    assert ph=='54d792571e20239e7b586360fe04557154fc64a5942865896c35d34b89584101'
    assert plan['contract_sha256']==ch
    assert sha256((ROOT/'calculations/canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md').read_bytes()).hexdigest()==contract['immutable_inputs']['parent_action_sha256']
    records={}
    for stage in ['m03','m04']:
        p,r,e=[read(OLD/('uvp_'+stage+'_'+suffix+'.json')) for suffix in ['primary_attempt2','independent_replay_attempt2','evidence_attempt2']]
        for d in [p,r,e]:logical(d);assert d['contract_sha256']==ch and d['execution_plan_sha256']==ph
        assert e['primary']==p and e['independent_replay']==r and e['verdict']=='PASS'
        assert sha256((OLD/(stage.upper()+'_KERNEL_IMPLEMENTATION_SPEC.md')).read_bytes()).hexdigest()==p['kernel_spec_sha256']
        records[stage]=(p,r)
    p,r,c,e=[read(OLD/n) for n in ['uvp_m05_complete_scalar_v4v4.json','uvp_m05_independent_scalar_replay_uncompared.json','uvp_m05_independent_scalar_replay.json','uvp_m05_evidence_attempt2.json']]
    for d in [p,r,c,e]:logical(d)
    assert e['contract_sha256']==ch and e['execution_plan_sha256']==ph
    assert set(c['direction_residuals'])==set(p['coefficient_tables']) and all(z=='0' for z in c['direction_residuals'].values())
    assert c['primary_scalar_sha256']==p['artifact_sha256'] and c['uncompared_replay_sha256']==r['artifact_sha256']
    assert e['independent_replay']['uncompared_scalar_sha256']==r['artifact_sha256']
    assert e['independent_replay']['scalar_comparison_sha256']==c['artifact_sha256'] and e['verdict']=='PASS'
    assert p['projection_rank']==r['projection_rank']==26 and p['projection_residual']==r['projection_residual']=='0'
    records['m05']=(p,r)
    basis=read(OLD/'real_field_basis.json');h=sha256(json.dumps(basis['basis'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert h==basis['full_basis_sha256']=='c66398b6321988b643af5c12fdbea86c3a2589b7b139450770c6ef72c31a3b5e'
    physical=read(OLD/'physical_basis.json')
    assert physical['parent_component_basis_sha256']==h
    assert physical['factorized_physical_basis_sha256']==contract['immutable_inputs']['physical_basis_sha256']
    return records,basis,ch,ph

def basis_check(basis,role):
    five=list(combinations(range(10),5));index={key:i for i,key in enumerate(five)}
    current=read(PK/'frozen_action_ast_a3/A31_embeddings.json')['sectors']
    for sector,start,n,ambient in DOMAINS:
        old=s.SparseMatrix(ambient,n,{})
        for j,row in enumerate(basis['basis'][start:start+n]):
            assert row['sector']==sector;c=row['components']
            if sector=='Phi':
                for i,k,z in c['Phi']:old[10*i+k,j]=s.sympify(z)
            elif sector=='Sigma':
                for ids,re,im in c['Sigma']:
                    i=index[tuple(ids)];old[i,j]=s.sympify(re);old[252+i,j]=s.sympify(im)
            elif sector=='phi':
                for i,z in c['phi']:
                    z=s.sympify(z);old[i,j]=s.re(z);old[10+i,j]=s.im(z)
            else:z=s.sympify(c['S']);old[0,j]=s.re(z);old[1,j]=s.im(z)
        row=current[sector];E=s.SparseMatrix(ambient,n,{(i,j):s.sympify(z) for i,j,z in row['embedding_entries']})
        T=s.SparseMatrix(ambient,ambient,{(i,i):s.sympify(z) for i,z in enumerate(row['tensor_metric_diagonal'])})
        zero(E.T*T*E-s.eye(n))
        if role=='primary':zero(old-E)
        else:zero(E.T*T*old-s.eye(n));zero(E*(E.T*T*old)-old)

def scalar_polynomials(records,role):
    quartics=records['m05'][0]['inventory']['input_quartic_directions']
    assert len(quartics)==26 and set(quartics)==set(records['m05'][1]['inventory']['quartic_input_directions'])
    names=list(MASS.values())+CUBICS+quartics;assert len(names)==len(set(names))==34
    env={n:s.Symbol(n,real=True) for n in names};polys={}
    stage3=records['m03'][role=='replay'];stage4=records['m04'][role=='replay'];stage5=records['m05'][role=='replay']
    for sector in MASS:
        if role=='primary':z=s.sympify(stage3['sector_ledgers'][sector]['scalar_parameter_counterterm'],locals=env)
        else:
            z=s.S.Zero
            for inside,mname in MASS.items():
                tr=stage3['quartic_trace_table'][sector][inside]
                for name,value in tr.items():
                    if name=='zD':assert s.sympify(value)==0;continue
                    z+=FACTORS[inside]*env[mname]*env[name]*s.sympify(value)/2
            z+=s.sympify(stage3['cubic_trace_table'][sector]['V3_ACD_V3_ACD'],locals=env)/2
            z/=FACTORS[sector]
        polys[MASS[sector]]=clean(z)
    for name in CUBICS:
        if role=='primary':z=s.sympify(stage4['scalar_residues'][name],locals=env)
        else:
            B=s.Matrix(stage4['scalar_coefficient_matrices'][name]);z=(s.Matrix([env[n] for n in CUBICS]).T*B*s.Matrix([env[n] for n in M04COLS]))[0]
        polys[name]=clean(z)
    ordered=stage5['inventory']['input_quartic_directions'] if role=='primary' else stage5['inventory']['quartic_input_directions']
    v=s.Matrix([env[n] for n in ordered])
    for name in quartics:
        B=s.Matrix(stage5['coefficient_tables'][name]);assert B.shape==(26,26)
        polys[name]=clean((v.T*B*v)[0])
    assert set(polys)==set(names) and set().union(*(z.free_symbols for z in polys.values()))<=set(env.values())
    return polys,env
