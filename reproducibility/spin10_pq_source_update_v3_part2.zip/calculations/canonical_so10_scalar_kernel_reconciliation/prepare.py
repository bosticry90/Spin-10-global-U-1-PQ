"""Freeze RSC1 current inputs and explicit old Git/source/evidence identities."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-kernel-reconciliation-v1-2026-10-20')
BASE='cd12c2c03cfbfd532964700961a1782dc4e5c0f0'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT).decode().strip()=='main'
prior=json.loads((ROOT/'calculations/canonical_so10_goldstone_scalar_counterterm/validation_preparation_v3.json').read_bytes())
for name,h in prior['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
CONTROL.mkdir(parents=True,exist_ok=False)
files=list(map(Path,prior['input_sha256']))
files.extend(p for p in (ROOT/'calculations/canonical_so10_goldstone_scalar_counterterm').iterdir() if p.is_file())
old=ROOT/'tools/two_loop_qft_compiler_v1'
for pattern in ['m03_*.py','m04_*.py','m05_*.py','independent_m03*.py','independent_m04*.py','independent_m05_scalar*.py','execute_uvp_m03*.py','execute_uvp_m04*.py']:
    files.extend(old.glob(pattern))
for name in ['uvp_m03_primary_attempt2.json','uvp_m03_independent_replay_attempt2.json','uvp_m03_evidence_attempt2.json',
             'uvp_m04_primary_attempt2.json','uvp_m04_independent_replay_attempt2.json','uvp_m04_evidence_attempt2.json',
             'uvp_m05_complete_scalar_v4v4.json','uvp_m05_independent_scalar_replay_uncompared.json','uvp_m05_independent_scalar_replay.json','uvp_m05_evidence_attempt2.json',
             'one_loop_uv_pole_evaluator_contract.json','uv_pole_evaluator_execution_plan.json','M03_KERNEL_IMPLEMENTATION_SPEC.md','M04_KERNEL_IMPLEMENTATION_SPEC.md',
             'compile_real_field_basis.py','real_field_basis.json','physical_basis.json','preregister_uv_pole_evaluator.py']:
    files.append(old/name)
sources={}
for filename,commit in [('m03_parent_scalar_kernel.py','eb28ad9db3bddee3eb4e0e42fa1f3e4629b240d7'),('m04_parent_scalar_kernel.py','07f624eb8917d669c42796dd77c0ab43f7a6d9ee'),('m05_full_scalar_kernel.py','b137c83bbf0334f95ae6e992d0f577bd4901656b')]:
    path=old/filename;rel=path.relative_to(ROOT).as_posix();raw=subprocess.check_output(['git','show',commit+':'+rel],cwd=ROOT)
    assert raw==path.read_bytes(),rel
    sources[rel]={'historical_commit':commit,'sha256':sha256(raw).hexdigest()}
files.extend([ROOT/'AGENTS.md',ROOT/'project_state.json',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V387.md'])
for path in list(HERE.iterdir()):
    if path.suffix in ['.py','.md']:
        if path.suffix=='.py':compile(path.read_bytes(),str(path),'exec')
        with (HERE/(path.name+'.source.txt')).open('xb') as out:out.write(path.read_bytes())
files.extend(HERE.iterdir())
tree=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(tree.splitlines())==24943
with (CONTROL/'old_git_tree.txt').open('xb') as out:out.write(tree)
files.append(CONTROL/'old_git_tree.txt')
value={'schema':'C1_GS_SCALAR_KERNEL_RECONCILIATION_PREPARATION_V1','base_commit':BASE,'old_git_blobs':24943,
       'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))},
       'old_kernel_sources_equal_evidence_commit':sources,'native_after_imports_seconds':60,'verifier_after_imports_seconds':90,
       'sampled_private_limit':8*1024**3,'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2}
with (HERE/'preparation.json').open('xb') as out:out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(value['input_sha256']),'bindings',24943,'old blobs',flush=True)
