# Complete actual Hessian and scalar bare loop-leg corollary

Use the actual source-left action decomposition qualified by E2:

    S = S_phys + sum_J (J + A_J) R_J,
    V_J = delta_epsilon A_J,
    D = delta_epsilon - sum_J V_J EL_left_J.

S_phys is independent of antighosts and these external sources. The derivative
D is EVEN: epsilon has the antighost parity and each V_J has the source
parity. Constant configuration variations h,k are also even derivations;
their formal components have the parity of the varied fields and may have
spacetime jets. Holding sources fixed in the integrated-field Hessian gives

    D H[h,k] = (D S)''[h,k]
        + sum_J (V_J''[h,k] R_J
                 + V_J'[h] R_J'[k] + V_J'[k] R_J'[h]).

This is an identity of ordered graded local densities, not a cyclic-trace
argument. The actual V_J are affine, so the first sum term vanishes. Both
remaining mixed terms are essential. At J=0 the source part of D S still
has its external source factor after h,k differentiation and drops out.
Thus the full sourcefree Hessian insertion is B_sourcefree'' + C.

The independent direct construction is

    D H = delta_epsilon GF'' - sum_J V_J R_J''.

It does not differentiate V_J in this expression: D acts on the already
formed Hessian. The mixed terms arise when instead commuting D past the
fluctuation variations. All643 actual master maps, all479 active V_J and
their qualified zero complement are retained. Native direct and left-gradient
routes, plus independent exact literal slot differentiation, compare every
coefficient of these TWO constructions. No restriction to selected h,k or
orders0/1 is made. Actual support ends at g2; possible g3 terms are evaluated
and found absent, not silently truncated.

For the retained background/reference family, the reference propagator G,
heat factors and reference determinant depend on the fixed background and
reference data, not the shifted antighosts or sources. Therefore D G=0,
D heat=0 and D Gamma_ref[A]=0. Insert D H in EACH ordered Born position:

    D (G H)^n = sum_(r=0)^(n-1)
                   (G H)^r G (D H) (G H)^(n-1-r).

Proof for arbitrary finite n is ordinary even Leibniz induction: the n+1
case differentiates its first n factors, then its last factor, giving exactly
the n+1 displayed positions. The fixed Gaussian/Fourier prefactor is the
one already qualified for the measured functional. The Born weight
(-1)^(n+1)/n stays on EVERY position; it is never replaced by a guessed
cyclic multiplicity. Noncommuting matrix polynomials check n=1..4 as controls,
not as proof by sampling or an infinite-series truncation.

V255 supplies the fixed-finite-coefficient leading UV-log correspondence
and uniformly integrable remainder in its EXPLICIT formal local heat family.
Even local field/source differentiation here preserves that symbol class.
The result applies coefficient by coefficient, with the complete ordinary
and source finite frontier; it does not exchange an unrestricted resummed
heat trace or an IR limit. Arbitrary historical covariantizations and the
global Quantum Action Principle remain outside this argument.

Consequently the complete bare ordered-loop insertion coefficient may be
obtained by applying D to the independently measured complete ordinary/source
coefficients. This is the loop-leg reduction already established at g1,
now with the actual entire classical D H checked and the full scalar input
coverage supplied by the accepted scalar-component receipt. It gives the
WHOLE retained scalar-linear and scalar-pair result at orders0..5, including
its nonzero coefficients and zero boundary currents. It is not a NEW
independent evaluation of an insertion integral or another Ward cancellation.

The crucial remaining distinction is renormalization. The pointwise product
of the field-dependent V_J with the quantum transformation sector has
connected contractions and local contact normalization obligations. The
bare loop-leg identity does not construct their renormalized time-ordered
products, fix finite contact terms, prove a measure/IR prescription, or show
that the full sourcefree Slavnov identity is restored. The separate32
nonlinear source-primitive flow products are not these gauge-fermion kernels.
The nonzero scalar insertion is not an anomaly and must not be forced to
zero or used to fit a compensating unmeasured term.
