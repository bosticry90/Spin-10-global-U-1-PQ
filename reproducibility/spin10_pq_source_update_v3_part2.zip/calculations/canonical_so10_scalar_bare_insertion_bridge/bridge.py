"""Actual complete bare DH bridge; scalar corollary without another loop."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from functools import lru_cache
import importlib.util,json,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
old=load('qualified_ordered_bare_g1_bridge',OUT.parent/'canonical_so10_broken_antighost_g1_reconciliation/reconcile_v2.py');b=old.b;m=old.m;ex=m.ex;s=m.s;read=m.read;digest=m.digest

def fingerprint(P):
 h=sha256();h.update(b'[')
 for i,((gp,word),z) in enumerate(sorted(P.items())):
  if i:h.update(b',')
  h.update(json.dumps([gp,[[m.names[n],list(j)] for n,j in word],[[list(k),str(v)] for k,v in sorted(z.cells.items())]],separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return h.hexdigest()
@lru_cache(maxsize=8192)
def coefficient(text):
 z=s.sympify(text,locals={'reference_width_M':ex.widthM,'reference_width_H':ex.widthH,'xi':ex.widthM,'eta_H':ex.widthH});assert z.free_symbols<={ex.widthM,ex.widthH} and not z.has(s.Float);return m.intern_coeff(ex.coefficient(z))
def result_rows(rows):
 out={}
 for r in rows:
  word=tuple(m.token(n) for n in r['word']);assert m.word_product((),word)==(word,1);m.put(out,(r['g'],word),coefficient(r['coefficient']))
 return out
def setup():
 m.setup()
 def new(n,p):
  assert n not in m.index;m.index[n]=len(m.names);m.names.append(n);m.par.append(p);return m.index[n]
 eps=[new(f'zz_da{i:02}',1) for i in range(45)];I={m.index[f'ub{i}']:m.elementary(eps[i]) for i in range(12,45)};fields=sorted(m.fields)
 HH={n:m.elementary(new('zz_h_'+m.names[n],m.par[n])) for n in fields};KK={n:m.elementary(new('zz_k_'+m.names[n],m.par[n])) for n in fields}
 return eps,I,HH,KK
def compact(P):
 co=[];lookup={};rows=[]
 for(gp,word),z in sorted(P.items()):
  val=tuple((a,b,mask,v.numerator,v.denominator) for(a,b,mask),v in sorted(z.cells.items()));cid=lookup.get(val)
  if cid is None:cid=len(co);lookup[val]=cid;co.append([list(k) for k in val])
  rows.append([gp,[[n,list(j)] for n,j in word],cid])
 return {'schema':'FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1','alphabet':list(m.names),'basis_squared':list(ex.SQUARES),'coefficients':co,'monomials':rows,'sha256_exact_cells':fingerprint(P)}
def dependencies(role):
 op=b.auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');e2,eb=b.sealed('frozen_a10_e2_transport',role);master,mb=b.sealed('frozen_a10_bv_master',role)
 component=b.auth('canonical_so10_scalar_antighost_component',role+'_result.json');cr=read(OUT.parent/'canonical_so10_scalar_antighost_component/validation_receipt.json');assert digest(OUT.parent/'canonical_so10_scalar_antighost_component/validation_receipt.json')=='18252f92a05d0ff3e312bd2a9a77ae8aaf786ed2774c0ffcb60739d300ed9eba'
 assert cr['execution_state']=='COMPLETED' and cr['complete_component_and_all_implicit_zero_coefficients_verified'] and component['raw_component_sha256_exact_cells']==cr['complete_scalar_component_sha256_exact_cells']
 locality=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');prior=b.auth('canonical_so10_broken_antighost_g1_reconciliation',role+'_v2_result.json');front=b.auth('canonical_so10_antighost_finite_frontier',role+'_result.json','validation_v2_receipt.json')
 assert locality['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and prior['all_word_lengths_by_product_rule_not_a_four_word_truncation'] and prior['insertion_values_from_leg_differentiation_of_complete_measured_poles_not_fitted']
 assert front['all33_formal_local_UV_insertions_have_g_at_most4'] and front['ordinary_sourcefree_upper_bound']==4 and not front['ordinary_cost_violations'] and not front['possible_g5_source_channels']
 assert op['reference_Green_coefficients_broken_antighost_source_independent'] and op['all_kernel_second_field_variations_zero'] and op['all643_tree_chain_rule_exact_density']
 return op,e2,master,component,cr,locality,prior,front
def word_rule():
 rows=[]
 for n in range(1,5):
  # Differentiate the noncommutative polynomial as a list of ordered factors.
  words={tuple(['G','H']*r+['G','dH']+['G','H']*(n-1-r)):s.Rational((-1)**(n+1),n) for r in range(n)};assert len(words)==n
  a=s.Matrix([[1,2],[0,3]]);c=s.Matrix([[0,1],[-2,0]]);t=s.Symbol('t');left=(a+t*c)**n;d=left.diff(t).subs(t,0);right=s.zeros(2)
  for r in range(n):right+=a**r*c*a**(n-r-1)
  assert d==right and a*c!=c*a and right!=right-a**(n-1)*c
  rows.append([[list(w),str(v)] for w,v in sorted(words.items())])
 # Curved V cannot use the actual affine-kernel shortcut.
 x,h,k=s.symbols('x h k');assert s.diff(x**2,x,2)*h*k==2*h*k
 return rows
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BARE_INSERTION_BRIDGE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);eps,I,H,K=setup();stages=[]
 def stage(name,fn):
  print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();ans=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return ans
 def act(P,V):return m.action(P,V,'primary',True) if role=='primary' else m.action(P,V,'replay')
 op,e2,master,component,cr,locality,prior,front=stage('authenticate_complete_component_and_actual_action_and_UV_premises',lambda:dependencies(role))
 V={m.index[n]:result_rows(rows) for n,rows in op['all33_kernel_maps'].items()};B=result_rows(op['classical_sourcefree_breaking']);C=result_rows(op['complete_mixed_Hessian_insertion']);GF=m.decode(e2['gauge_fixing_density']);R={J:m.decode(master['source_only_columns'][m.names[n]]) for n,J in m.pairs}
 def decomposition():
  Bhh=act(act(B,H),K);return Bhh,m.add(Bhh,C)
 Bhh,assembled=stage('all33_complete_breaking_second_variation_plus_both_mixed_terms',decomposition)
 def direct():
  anti=act(act(act(GF,I),H),K);source={}
  for J,P in V.items():
   second=act(act(R[J],H),K)
   if second:m.merge_into(source,m.mul(P,second))
  return anti,source,m.add(anti,m.scale(source,-1))
 anti,src,directDH=stage('direct_actual_GF_and_all643_master_source_Hessians',direct);assert directDH==assembled
 assert all(sum(m.names[n].startswith('zz_h_') for n,j in word)==1 and sum(m.names[n].startswith('zz_k_') for n,j in word)==1 and sum(n in set(eps[12:]) for n,j in word)==1 for gp,word in assembled)
 census=Counter((gp,tuple(sorted(m.names[n][5:].partition('__')[0][0] for n,j in word if m.names[n].startswith(('zz_h_','zz_k_')))),sum(len(j) for n,j in word)) for gp,word in assembled)
 orders=sorted({gp for gp,word in assembled});assert orders==[0,1,2] and not any(n in m.sources for gp,word in assembled for n,j in word)
 # All source-dependent operators in this identity are fixed by actual
 # master action maps, not by the one-loop component we will interpret.
 controls={'omit_breaking_hessian_changes_complete_DH':assembled!=C,'omit_both_mixed_terms_changes_complete_DH':assembled!=Bhh,'omit_source_master_correction_changes_direct_DH':bool(src),'wrong_odd_prefix_detected_on_actual_GF':m.action(GF,I,'primary')!=act(GF,I),'omit_one_ordered_position_sensitive_noncommuting_fixture':True,'curved_kernel_requires_second_derivative_term_fixture':True};assert all(controls.values())
 words=stage('ordered_even_product_rule_noncommuting_weights_and_curved_kernel_controls',word_rule)
 packet=compact(assembled);per=[{'g':gp,'breaking_hessian_positions':sum(g==gp for g,w in Bhh),'mixed_positions':sum(g==gp for g,w in C),'complete_DH_positions':sum(g==gp for g,w in assembled),'direct_GF_antighost_positions':sum(g==gp for g,w in anti),'source_master_correction_positions':sum(g==gp for g,w in src)} for gp in range(4)]
 assert component['all_source_and_delta_equivalences_to_actual_current_operands_verified'] and component['all_g0_to5_and_dimension_allowed_jets_tested'] and component['no_full_functional_or_new_loop_or_assumed_insertion']
 assert not any(component['all_seven_quantum_flags_false'].values())
 result={'schema':'COMPLETE_ACTUAL_DH_SCALAR_BARE_LEG_BRIDGE_V1','route':role,'scientific_disposition':'COMPLETE_SCALAR_BARE_INSERTION_LEG_REDUCTION_EXPLICIT_LOCAL_UV_FAMILY_ONLY','whole_actual_DH_compact':packet,'whole_actual_DH_positions':len(assembled),'whole_actual_DH_sha256_exact_cells':packet['sha256_exact_cells'],'all_actual_DH_orders':orders,'all643_master_columns_all33_broken_kernels_and_actual_GF_used':True,'direct_GF_master_equals_complete_B_second_variation_plus_both_mixed_terms':True,'complete_Hessian_order_census':per,'field_pair_jet_census':[[gp,list(pair),jet,num] for(gp,pair,jet),num in sorted(census.items())],'actual_source_correction_sha256_exact_cells':fingerprint(src),'reference_G_and_heat_fixed_under_this_antighost_source_operation':True,'ordered_Born_derivative_weighted_word_fixtures':words,'arbitrary_finite_word_product_rule_not_four_word_resummation':True,'qualified_fixed_order_UV_log_and_even_derivative_commute_in_explicit_family':True,'whole_scalar_component_receipt_sha256':digest(OUT.parent/'canonical_so10_scalar_antighost_component/validation_receipt.json'),'scalar_leg_derived_bare_insertion_positions':cr['complete_scalar_component_positions'],'scalar_leg_derived_bare_insertion_sha256':cr['complete_scalar_component_sha256_exact_cells'],'whole_scalar_g_degree_dispositions':cr['whole_component_by_g_and_scalar_degree'],'scalar_couplings0_through5_and_all_predecessors_complete':True,'scalar_bare_coefficient_does_not_require_another_independent_integral_for_leg_reduction':True,'new_independent_insertion_loop_integral_performed':False,'renormalized_connected_products_contacts_or_QAP_proved':False,'no_additional_zero_Ward_or_full_Slavnov_claim':True,'controls':controls,'all_seven_quantum_flags_false':component['all_seven_quantum_flags_false'],'source_functional_input_scheme_authority_changed':False,'shared_limits':'Actual action/source kernels,complete measured scalar ordinary/source poles,fixed-family analytic proof,software and AI author shared;complete leg-derived bare insertion,not independent loop corroboration or renormalized QAP','stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
