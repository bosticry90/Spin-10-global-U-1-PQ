"""Complete scalar-bearing antighost support; no loop amplitudes or fitted zeros."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import permutations
from functools import lru_cache
import json,sys,os,time,threading,re
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def auth(folder,name):
 p=OUT.parent/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def freeze(z):return tuple(map(freeze,z)) if isinstance(z,list) else z
def descriptor(r):return {k:v for k,v in r.items() if k!='witness'}
def options(vv,target):
 out={};budget=Counter(target)
 for tag,v in vv.items():
  rows=set()
  for whole in v['ports']:
   for i,j in permutations(range(len(whole)),2):
    a,b=freeze(whole[i]),freeze(whole[j]);ext=tuple(sorted(freeze(p) for k,p in enumerate(whole) if k not in [i,j]))
    if any(Counter(ext)[p]>budget[p] for p in ext) or a[0].startswith('A') or b[0].startswith('A'):continue
    rows.add((a,b,ext))
  out[tag]=sorted(rows)
 return out
def weight(n):return 2 if n.startswith('L') else 1
def solve(profile,vertices,edges,route):
 target=freeze(profile['external_ports']);op=options(vertices,target);wanted=Counter(target);bbwant=tuple(profile['BB_width_roles']);best=None
 assert not profile['scalar_reference_mass_expansions'] and profile['total_external_jets']==0
 for order in sorted(set(permutations(profile['vertex_family']))):
  if any(not op[t] for t in order):continue
  def extend(ext,add):
   e=tuple(sorted(ext+add));return e if not(Counter(e)-wanted) else None
  def edge(a,b):return(a[0],b[0]) in edges
  def bb(a,b):return(a[0],) if a[0].startswith('B') and b[0]==a[0] else()
  def degree(a,b):return weight(a[0])+weight(b[0])-4
  def finish(first,last,ext,width,uv):return edge(last,first) and ext==target and tuple(sorted(set(width+bb(last,first))))==bbwant and uv+degree(last,first)+4==0
  if route=='primary':
   def visit(path,ext,width,uv):
    if len(path)==len(order):return path if finish(path[0][1],path[-1][2],ext,width,uv) else None
    t=order[len(path)]
    for a,b,e in op[t]:
     ex=extend(ext,e)
     if ex is None or(path and not edge(path[-1][2],a)):continue
     ww=tuple(sorted(set(width+(bb(path[-1][2],a) if path else()))))
     if not set(ww)<=set(bbwant):continue
     u=uv+a[1]+b[1]+(degree(path[-1][2],a) if path else 0);ans=visit(path+[(t,a,b,e)],ex,ww,u)
     if ans is not None:return ans
    return None
   ans=visit([],(),(),0)
  else:
   states={}
   for a,b,e in op[order[0]]:states[a,b,e,(),a[1]+b[1]]=[(order[0],a,b,e)]
   for t in order[1:]:
    nxt={}
    for(first,last,ext,width,uv),path in states.items():
     for a,b,e in op[t]:
      if not edge(last,a):continue
      ex=extend(ext,e);ww=tuple(sorted(set(width+bb(last,a))))
      if ex is None or not set(ww)<=set(bbwant):continue
      state=first,b,ex,ww,uv+a[1]+b[1]+degree(last,a);nxt.setdefault(state,path+[(t,a,b,e)])
    states=nxt
   ans=next((path for(first,last,ext,width,uv),path in states.items() if finish(first,last,ext,width,uv)),None)
  if ans is not None:return ans
 return None
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SCALAR_GHOST_SUPPORT_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);old=auth('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json');inv=auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');quart=auth('canonical_so10_fourghost_g4_reduction',role+'_v3_result.json');pole=auth('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json');current=auth('canonical_so10_ghost_mass_g4_integration',role+'_result.json')
 assert len(inv['all_profiles'])==2353 and len(old['all664_updated_scope_rows'])==664 and len(pole['new_actual_g4_ghost_mass_node'])==33 and current['updated_known_terms']==155143 and current['sourcefree_updated_positions']==41452 and current['updated_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241'
 actual={i:r for i,r in enumerate(inv['all_profiles']) if any(n.startswith('a') for n,j in r['external_ports'])};ledger={r['index']:dict(r) for r in old['all664_updated_scope_rows']};assert set(actual)==set(ledger)
 for i,r in actual.items():assert descriptor(r)==ledger[i]['descriptor']
 mass={r['index'] for r in old['actual_supported3_profiles']};assert mass=={2024,2026,2027}
 for i in mass:assert not ledger[i]['complete_scope_match'];ledger[i]['complete_scope_match']='V275_COMPLETE_INTRINSIC_MASS_COHORT';ledger[i]['interpretation']='MEASURED_THREE_FAMILY_COHORT_NOT_INDIVIDUAL_NONZERO';ledger[i]['unbroken_aggregate_only_if_family_unreconciled']=False
 chosen={i:r for i,r in actual.items() if not ledger[i]['complete_scope_match'] and ledger[i]['types'] in [['C','a','x'],['C','a','x','x']]};assert len(chosen)==112 and sum(ledger[i]['coefficient_dimension']==1 for i in chosen)==32 and all(ledger[i]['jets']==0 for i in chosen)
 orbit=defaultdict(set)
 for tag,rows in old['all_literal_orbit_rows_stripped_only_g_and_explicit_xi'].items():
  for r in rows:
   pp=[]
   for name in r['word']:
    m=re.fullmatch(r'x_(Phi|Sigma|phi|S)_([0-9]+)',name)
    if m:pp.append(('X_'+m[1],0))
    else:
     m=re.fullmatch(r'(ub|C|L)([0-9]+)',name);assert m,name;pp.append(({'ub':'a','C':'C','L':'L'}[m[1]]+('H' if int(m[2])<12 else 'M'),0))
   orbit[tag].add(tuple(sorted(pp)))
 assert {k:len(v) for k,v in old['all_literal_orbit_rows_stripped_only_g_and_explicit_xi'].items()}=={'M':432,'Y':6688} and {k:sorted(v) for k,v in orbit.items()}=={k:list(map(freeze,v)) for k,v in old['all_literal_orbit_ports'].items()}
 refine={'D':quart['actual_exported_port_sets']['D'],'F':quart['actual_exported_port_sets']['F'],'O_LX':sorted(orbit['M']),'O_aCX':sorted(orbit['Y'])};vv=inv['actual_sourcefree_vertices'];rv={t:{**v,'ports':refine.get(v['base'],v['ports'])} for t,v in vv.items()};edges={tuple(e) for e in inv['actual_reference_edges']};scalarless={e for e in edges if not any(n.startswith('X_') for n in e)};rows=[]
 print('STAGE '+role+' all112_relaxed_and_refined_complete_cycle_support',flush=True)
 for i,p in sorted(chosen.items()):
  assert solve(p,vv,edges,role) is not None,('RELAXED_ENVELOPE_MISMATCH',i);w=solve(p,rv,edges,role);bare=solve(p,rv,scalarless,role);rows.append({'index':i,'descriptor':descriptor(p),'actual_port_supported':w is not None,'actual_port_witness':w,'supported_without_scalar_reference_edges':bare is not None})
 zeros={r['index'] for r in rows if not r['actual_port_supported']};live={r['index'] for r in rows if r['actual_port_supported']}
 for i in zeros:ledger[i]['complete_scope_match']='THIS_COMPLETE_REFINED_ENVELOPE_NO_PATH';ledger[i]['interpretation']='INDIVIDUAL_STRUCTURAL_ZERO_IN_CONSERVATIVE_PORT_ENVELOPE';ledger[i]['unbroken_aggregate_only_if_family_unreconciled']=False
 summary=[{'g':g,'total':sum(r['g']==g for r in ledger.values()),'complete_scopes':sum(r['g']==g and bool(r['complete_scope_match']) for r in ledger.values()),'unreconciled':sum(r['g']==g and not r['complete_scope_match'] for r in ledger.values())} for g in range(1,5)];groups=defaultdict(list)
 for r in ledger.values():
  if not r['complete_scope_match']:groups[tuple(r['types']),r['g'],r['coefficient_dimension']].append(r['index'])
 controls={'restore_relaxed_ports_restores_some_excluded_profiles':bool(zeros),'omit32_dimensionful_profiles_loses_coverage':sum(ledger[i]['coefficient_dimension']==1 for i in chosen)==32,'remove_scalar_edges_changes_live_support':any(r['actual_port_supported']!=r['supported_without_scalar_reference_edges'] for r in rows),'promote_unbroken_aggregate_would_false_close_individual_scopes':any(not r['complete_scope_match'] and r['unbroken_aggregate_only_if_family_unreconciled'] for r in ledger.values())}
 result={'schema':'SCALAR_GHOST_SUPPORT_AND_FINITE_LEDGER_V1','route':role,'scientific_disposition':'COMPLETE112_PROFILE_REFINED_SUPPORT_PARTITION_NOT_NEW_LOOP_COEFFICIENTS','profiles':rows,'structural_zero_indices':sorted(zeros),'permitted_unreconciled_indices':sorted(live),'all664_updated_scope_rows':[ledger[i] for i in sorted(ledger)],'coupling_order_summary':summary,'remaining_classes':[{'types':list(ty),'g':g,'coefficient_dimension':cd,'indices':sorted(ids)} for(ty,g,cd),ids in sorted(groups.items())],'refined_port_sets':refine,'all32_positive_and80_zero_dimension_scalar_profiles_included':True,'relaxed_envelope_reproduced_for_all112':True,'new_three_mass_profiles_are_measured_cohort_not_individual_nonzero':True,'current_known_terms':current['updated_known_terms'],'current_known_sha256':current['updated_known_sha256'],'sourcefree_positions':41452,'source_positions':146663,'controls':controls,'insensitive_controls':[k for k,z in controls.items() if not z],'all_seven_quantum_flags_false':current['all_seven_quantum_flags_false'],'new_loop_or_color_pole_or_insertion_integral':False,'new_full_functional_materialization_or_variation':False,'full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Inherited relaxed catalogue and non-DF-orbit port envelope,qualified action port extractions,software and AI author;support is not nonzero amplitude,absence is relative to frozen envelope','elapsed_after_imports':time.perf_counter()-tick};assert not any(result['all_seven_quantum_flags_false'].values());print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
