# A complete structural screen of the remaining scalar-ghost families

SGS1/SGS2, parent `3d6a34daad972654e81eec3dd307f25a1e51dd62`.
Qualification requires the completed independent receipt and committed-byte
checks. This report alone is not the validation receipt or authority ledger.

All 112 previously unreconciled scalar-bearing antighost profiles have now
been tested for possible connections using the qualified actual D/F derivative
ports and M/Y scalar-orbit ports. The result is 34 structural zeros and 78
permitted profiles. The zeros are proved no-path results in the conservative
frozen port envelope. A permitted path does not demonstrate a nonzero quantum
coefficient. No loop integral or color coefficient was evaluated here.

The screen includes all 32 positive coefficient-dimension `a*C*x` profiles
and all 80 dimension-zero `a*C*x*x` profiles at g3/g4. Ten of the first class
and 24 of the second are structurally absent. The remaining scalar families
number 22 and 56 respectively. None is classified zero merely because a
coefficient is absent from the current partial functional.

## What is complete and what remains an assumption

Every descriptor is matched to the existing 2,353-profile inventory and its
664 antighost-containing profiles. The relaxed original vertex ports reproduce
all 112 candidate profiles before refinement. Refinement uses the actual
qualified D/F ports and re-extracts M/Y port types from all 432/6,688 retained
literal orbit rows. All scalar sectors are retained in the original domain;
the actual orbit rows have Phi/Sigma support. Other vertices, including S3/S4,
retain the inherited conservative port envelope.

Every permutation of each vertex multiset is checked with repeated vertices,
oriented reference propagators, differentiated ports, exact external multiset,
BB width-role sets and homogeneous ultraviolet degree. All selected profiles
have zero external derivatives and no scalar reference-mass expansion. Their
positive coefficient dimensions are explicitly retained. No extra color,
Jacobi, covariance or Ward cancellation is assumed.

Thus a complete no-path result survives any further restriction of this
envelope. A live witness may still disappear under actual component indices,
kinematic relations or cancellations. Completeness of the original theoretical
catalogue is a shared inherited premise, not a new complete-action theorem.

The native depth-first route and transfer-state route agree on the partition.
An independent backward suffix-reachability method must reproduce every
relaxed/refined classification and verify every native live witness. It also
checks all descriptor and ledger changes, not a diagnostic sample.

## Updated coverage, preserving old evidence

The old V274 ledger is not edited. In a new 664-row record, the three V275
mass profiles are matched to their complete measured three-family cohort,
and the 34 new no-path results are labeled individually structural zeros.
The measured cohort is not relabeled three independently nonzero amplitudes.
Existing collective sums and unbroken-only evidence retain their scopes.

| Order | Total profiles | Complete scope matches | Unreconciled |
| --- | ---: | ---: | ---: |
| g1 | 12 | 12 | 0 |
| g2 | 87 | 87 | 0 |
| g3 | 257 | 148 | 109 |
| g4 | 308 | 44 | 264 |
| Total | 664 | 291 | 373 |

These are catalogue scope classifications, not E5 completion percentages or
counts of measured amplitudes. The 373 unreconciled profiles comprise seven
AAaC, 65 ABaC, 223 BBaC, 22 aCx and 56 aCxx profiles. Some have collective
unbroken-projection evidence; that does not close individual families.

Controls restore the relaxed ports, omit the positive-dimensional class,
remove scalar reference edges and falsely promote collective unbroken evidence.
All change the relevant classifications or coverage; none is reported as an
insensitive success. Exact timings, resource observations and failure counts
are established by completed captures and the receipt. Each worker is bounded
by 120 seconds after imports, 8 GiB sampled private memory and minimum available
commit 350 MiB. The calculation does not reconstruct or vary the full functional.

## Scientific decision value and limits

This removes 34 genuinely impossible connections before another coefficient
calculation. The remaining 78 scalar profiles are a finite investigation target,
not a proposal to evaluate 78 unrelated tensors. Compare their complete families
and common scalar-kinetic/orbit structure to seek a whole-class reduction before
measuring components. Existing S3/S4 identities and actual longitudinal versus
transverse propagator dependence may be useful only after their assumptions
and complete family correspondence are checked. They do not imply zeros here.

In parallel scientific prioritization, retain the distinction between missing
ordinary coefficients and the nonlinear insertion/contact, regulated measure,
QAP and equivalence prerequisites. More graph coefficients cannot automatically
settle those construction questions. The current flat mass cancellation and
source-dependent theorem remain preserved within their own scopes.

The functional stays at 155,143 words/hash
`fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241`,
with 41,452 source-free positions and 146,663 source positions. Authority
remains 34/39, all seven quantum flags false. No new full source-free Slavnov,
QAP, infrared, measure, nonlinear-product, contact, equivalence or E5/A5 theorem
is asserted. HB1/C5 stays blocked; flavor paused. Historical quartet-candidate,
scalar quantum-control, gauge-matching and custody exit 2/seven limitations persist.

This is useful Track B evidence of inexpensive structural exclusion and
evidence reuse. It shares the catalogue, qualified port extractions, action,
software and AI author across methods. It is not independent expert validation,
a fresh byte-identical replay pair, a Lean certificate or experimental evidence.
No action, parameter, benchmark, regulator scheme, policy or authority changed.
