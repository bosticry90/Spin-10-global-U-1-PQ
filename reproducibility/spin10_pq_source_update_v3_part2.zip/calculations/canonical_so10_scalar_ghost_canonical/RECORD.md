# Complete measured scalar-ghost canonical transport V1

Basef4086e6de82f9c09b995e26285ed061715febf11,clean main,no live workers.
Previous goal turn PROGRESS. Full Spin(10)xglobalPQ investigation remains
active. Question: can the COMPLETE newly measured scalar-dependent ghost
pole be represented faithfully in the existing canonical field coordinates,
with inverse and physical-reality evidence sufficient for later integration?
A full transport,normalization mismatch,actual reality failure or bounded
incomplete work are informative outcomes. No fitted Ward coefficients.

Freeze V281 accepted physical receipt/native packets,all643 actual reference
FIELD maps and both inverse products,qualified V280 action/chart matching,
old canonical word/parity conventions and current V276 functional. Use four
physical parameter packets:g3*xi^2*x(5256),g4*eta_H*xi*x(10080),g4*xi^2*x(10224)
andg4*x*x(333540). The receipt contains all coalesced linear packets;the pair
is the authenticated native group g4_xi0_pair. Both own-role inputs must
agree as qualified;this reuses measured poles,not independent new loops.

Retain all45 ghosts/45 antighosts/328 real Cartesian scalars and the complete
zero domains664200 per linear parameter monomial and109260900 symmetric
pair positions. Physical numeric odd order is C0..44,a0..44;switching to
aC costs MINUS. Scalar coordinates commute;diagonal powers and the already
polarized off-diagonal coefficients receive NO new1/2 or factor2. Parameter
powers eta_H/xi are already coalesced and fixed;do not double count the width
xi as a distinct parameter. Normalization hbar/(32pi^2 epsilonUV) unchanged.

Let T map physical field coordinates to raw canonical variables as in the
actual reference kernel,and I its inverse. Verify both full643 products and
all zero carrier blocks from the actual reference arrays,not source-dual
maps or a remembered common helper. Verify all328 scalar rows are the actual
unit permutation,all ghost/antighost labels map to the retained canonical
alphabet,and every canonical word/parity agrees with the qualified Words
implementation. Construct P_can=Pull_T P_phys on the free graded-commutative
polynomial algebra. Native primary expands each actual field monomial;
replay stages the two rectangular odd-coordinate contractions by scalar word.
Apply I to the COMPLETE result and recover every original coefficient/zero.

Squared exact basis(2,3,5,-1,7),I bit8/sqrt7 bit16 remains conservative.
Never drop a root or imaginary component. Report whether canonical coefficients
actually lie in the old four-root ring before any later old-ring consumer.
Store full parameter-resolved canonical word/coefficient packets,with exact
hashes and counts. Prove the field-name/word serialization is bijective and
agrees with actual canonical parity/ordering. No symbolic string conversion
of hundreds of thousands of terms or full-Gamma expansion is needed here.

Physical reality uses the inherited fixed-odd-order antilinear convention.
Check all physical coefficient cells are real under that convention. Build
the actual raw field reality matrix R=conjugate(I)*T and verify R*conjugate(R)=1
and conjugate(T)*R=T in all643 directions. Together with exact pullback
composition and real physical P,this proves reality of the WHOLE transported
polynomial. Verify pullback composition/odd signs/even powers explicitly;
this is a structural full-domain proof,not an unsupported sampled reality
check. A complex canonical coefficient is not silently replaced by its real
part. Independently verify the complete typed matrices and tensor congruences.

Index-only planning canonical_support_cost_plan.json counted4175624 unfiltered
field-map contributions,including3875960 pair contributions. It is sizing,
not scientific evidence or execution permission. Freeze two sequential native
workers and one independent verifier,each300sec AFTER imports/8GiB sampled
private/min350MiB available commit. This covers all forward/inverse transport
and reality/word proofs;no dense109million allocation or science truncation.
Reuse bounded cached exact arithmetic. Preserve exact failed/unfinished runs
and version corrections;no silent resource expansion. Freeze exclusive source
copies,all input bindings,role reads and complete captures before launch.

Preflight all new coefficient/scaling/map/packet metadata types and schemas,
full scalar name bijection,canonical parity/word construction and serializers.
Do not repeat the prior custody assumption that evidence-reference strings
or nulls are booleans. Independent route uses separate rational-radical
arithmetic and coefficient-congruence grouping,actual field arrays without
the common frame helper,complete parameter packets and all inverse zeros.
Sensitive controls:radical/I signs,odd reversal,nilpotence,even scalar
diagonal/cross polynomial behavior,omission/sign/extra Bose factor on a real
nonzero coefficient and discarding a complex canonical component where
sensitive. Distinguish chart-domain separation from observable sensitivity.

No new loop,canonical integration,full Gamma variation or selected new
Slavnov/insertion identity occurs in this transport increment. Successful
transport is a prerequisite for exact-once integration and the COMPLETE
affected scalar broken-antighost component,not a substitute for those tasks.
Current155143-word/hash
fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241,
sourcefree41452/sourceimage146663 remain. Finite inventory369complete/295
unmatched stays;source-dependent38 theorem preserved. Full sourcefreeSlavnov,
QAP,measure/IR,32 nonlinear products,contacts/equivalence,E5/A5/GUT viability
unqualified. Authority34/39/seven false flags,HB1/C5 block,flavor pause,
historical quartet-candidate failure,scalar140% correction,gauge-matching and
custodyexit2/seven limits persist. No scheme,input,benchmark,policy,agent,
branch/worktree,remote/publication,expert,experiment,Lean or full-goal completion.
Shared measured poles/action/prior UV/chart proofs/software/AI author remain
limits. Validate then local commit with exact paths/HEAD-index-worktree bytes
and clean tree;continue the justified dependent integration afterward.
