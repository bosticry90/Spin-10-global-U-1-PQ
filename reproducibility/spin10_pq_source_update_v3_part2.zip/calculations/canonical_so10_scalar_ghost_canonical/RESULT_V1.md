# Prospective canonical scalar-ghost qualification

Qualification requires completed native and independent receipts,all current
input bindings and committed-byte checks. This report alone accepts no result.
Both native workers have completed the full parameter-resolved pullback and
recovered every physical coefficient under the actual inverse field maps.

The proposed canonical tables contain5480 g3*xi^2 scalar-linear positions,
6904 g4*xi^2 linear,6888 g4*eta_H*xi linear and711338 g4 scalar-pair positions.
Their counts differ from physical coordinates because the canonical fields
are mixed. These are exact coefficient positions,not particles or experiments.
No integration or whole source-free identity is inferred from these counts.

Complex canonical coefficients occur;the underlying physical coefficient
packets are real in the inherited fixed-odd-order convention. Full643 matrix
identities R=conjugate(I)*T,R*conjugate(R)=1,conjugate(T)*R=T,complete inverse
coefficient transport and polynomial pullback composition supply the proposed
whole-density physical-reality proof. Do not force the canonical coefficients
to be real. Independent exact rational congruences must reproduce every table
and zero complement,and independently check the full matrix identities.

The sqrt7 basis component persists in24/72/72/3632 canonical parameter positions
for g3xi2/g4xi2/g4etaHxi/pair respectively. This is a mathematical coefficient-
representation issue,not a new interaction or a demonstrated physical anomaly.
The result does not fit wholly in the historical four-root subring. Before
integration,audit the actual current consumer:reuse any already qualified
five-root path or implement and validate a conservative extension without
changing sealed helpers. Never discard sqrt7 or imaginary components. The
mere observation of root7 does not prove which current consumer can handle it.

All328 scalar maps are unit permutations. Scalar diagonal/cross factors,all
2025 odd-word orderings and actual canonical alphabet are retained;no extra
Lorentz copy or1/2 is applied. Negative controls distinguish actual coefficient
omissions/signs/complex parts/cross factors from a source-dual chart difference.
Controls insensitive outside their degree/component scope are labeled.

Primary29.354sec and replay34.949sec are within frozen300sec-after-imports/
8GiB/min350MiB available-commit limits;independent completion remains required.
Shared measured poles/action/reference/prior UV/word conventions,software and
AI author limit independence. No Lean,expert or experimental validation.

Current155143-word functional/sourcefree41452/sourceimage146663 and finite
inventory369/295 remain. Authority34/39/seven false flags,source-dependent38
theorem and all full sourcefreeSlavnov/QAP/measure/IR/product/contact/equivalence/
E5/A5 limitations persist. HB1/C5 blocked,flavor paused,historical quartet-
candidate/scalar140%/gauge-matching/custodyexit2-seven failures not repaired.
The goal stays active. After validation,the dependent task is a competent
consumer plus exact-once sparse integration and the complete affected scalar
antighost component,not a new loop search or an assumed zero insertion.
