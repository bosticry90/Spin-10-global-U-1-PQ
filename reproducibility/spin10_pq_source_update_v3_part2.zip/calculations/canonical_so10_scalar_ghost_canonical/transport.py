"""Complete measured pole pullback through actual field coordinates;no integration."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction as F
from math import lcm
import importlib.util,json,sys,time,threading,os
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
u=load('qualified_exact_integer_radical_operations',OUT.parent/'canonical_so10_scalar_ghost_actual_pole/pole.py');read=u.read;digest=u.digest;add=u.add;mul=u.mul;scale=u.scale;put=u.put;number=u.number
from a10_bv_common import algebra
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';ANTI=[f'bar{i}' if i<12 else f'ub{i}' for i in range(45)];AUX=[f'b{i}' if i<12 else f'L{i}' for i in range(45)]
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)}
def auth(folder,name):
 p=OUT.parent/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def sealed(folder,role):
 p=PKG/folder/(role+'.json');b=read(p.parent/'bindings.json');assert b['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p)
def imatrix(A):
 den=lcm(*(z.denominator for value in A.values() for mask,z in value));return {k:tuple((m,int(z*den)) for m,z in value) for k,value in A.items()},den
def mm(A,B):
 rows=defaultdict(list);out={}
 for(i,j),z in B.items():rows[i].append((j,z))
 for(i,k),z in A.items():
  for j,v in rows.get(k,()):put(out,(i,j),mul(z,v))
 return out
def conj(A):return {k:tuple((m,-z if m&8 else z) for m,z in value) for k,value in A.items()}
def mscale(A,n):return {k:scale(z,n) for k,z in A.items()}
def carrier(i):return 'B' if i<180 else'x' if i<508 else'L' if i<553 else'C' if i<598 else'a'
def kind(n):return 'x' if n.startswith('x_') else'a' if n in ANTI else'L' if n in AUX else'C' if n.startswith('C') else'B'
def frames(ref):
 names=ref['field_order'];assert len(names)==len(set(names))==643;pos={n:i for i,n in enumerate(names)};w=algebra();assert set(names)==set(w.fields) and len(w.pairs)==643
 T0={(i,j):number(z) for i,j,z in ref['physical_to_raw_kernel']['entries']};I0={(i,j):number(z) for i,j,z in ref['physical_to_raw_inverse']['entries']};T,dt=imatrix(T0);I,di=imatrix(I0);identity={(i,i):((0,dt*di),) for i in range(643)};assert mm(T,I)==mm(I,T)==identity
 assert all(carrier(i)==kind(names[j]) for i,j in T) and all(kind(names[i])==carrier(j) for i,j in I)
 R=mm(conj(I),T);dr=di*dt;assert mm(R,conj(R))=={(i,i):((0,dr**2),) for i in range(643)} and mm(conj(T),R)==mscale(T,dr)
 field_source_different=T0!={(j,i):z for(i,j),z in I0.items()};assert field_source_different
 C={(i,j):z for i in range(45) for j,n in enumerate(f'C{k}' for k in range(45)) if(z:=T0.get((553+i,pos[n])))};A={(i,j):z for i in range(45) for j,n in enumerate(ANTI) if(z:=T0.get((598+i,pos[n])))}
 IC={(i,j):z for i,n in enumerate(f'C{k}' for k in range(45)) for j in range(45) if(z:=I0.get((pos[n],553+j)))};IA={(i,j):z for i,n in enumerate(ANTI) for j in range(45) if(z:=I0.get((pos[n],598+j)))}
 C,dc=imatrix(C);A,da=imatrix(A);IC,dic=imatrix(IC);IA,dia=imatrix(IA);scalar={}
 for x in range(328):
  row=[(names[j],z) for(i,j),z in T0.items() if i==180+x];assert len(row)==1 and row[0][1]==((0,F(1)),);n=row[0][0];assert kind(n)=='x' and I0[pos[n],180+x]==((0,F(1)),);scalar[x]=n
 assert len(set(scalar.values()))==328 and all(w.p[n]==0 for n in scalar.values()) and all(w.p[n]==1 for n in [*(f'C{i}' for i in range(45)),*ANTI])
 for c in range(45):
  for a in range(45):
   P=w.mul(w.var(f'C{c}'),w.var(ANTI[a]));assert P=={((f'C{c}',()),(ANTI[a],())):1}
 return C,dc,A,da,IC,dic,IA,dia,scalar,w,{'full643_both_inverse_products_and_zero_carriers':True,'actual_antilinear_R_involution_and_conjugate_T_R_equals_T':True,'all328_scalar_unit_rows_and_canonical_parities':True,'all2025_actual_canonical_odd_words_agree':True,'source_dual_and_field_T_differ_chart_domain_only':field_source_different}
def rows_by_input(A):
 r=defaultdict(list)
 for(i,j),z in A.items():r[i].append((j,z))
 return r
def pull(P,C,A,scalar,route):
 crows=rows_by_input(C);arows=rows_by_input(A);out={}
 if route=='primary':
  for(c,a,ss),z in P.items():
   nn=tuple(sorted(scalar[x] for x in ss))
   for j,v in crows[c]:
    cv=mul(z,v)
    for k,q in arows[a]:put(out,(j,k,nn),mul(cv,q))
 else:
  middle={}
  for(c,a,ss),z in P.items():
   nn=tuple(sorted(scalar[x] for x in ss))
   for j,v in crows[c]:put(middle,(j,a,nn),mul(z,v))
  for(c,a,nn),z in middle.items():
   for k,q in arows[a]:put(out,(c,k,nn),mul(z,q))
 return out
def raw_packet(rows):
 P={};den=lcm(*(d for c,a,ss,h,w,z in rows for m,n,d in z));assert all(h==w==0 for c,a,ss,h,w,z in rows)
 for c,a,ss,h,w,z in rows:
  assert 0<=c<45<=a<90 and ss==sorted(ss) and all(0<=x<328 for x in ss);P[c,a-45,tuple(ss)]=tuple((m,n*(den//d)) for m,n,d in z)
 assert len(P)==len(rows);return P,den
def cells(value,den):return [[m,F(z,den).numerator,F(z,den).denominator] for m,z in value]
def packed(P,den):return [[c,a,list(ss),cells(z,den)] for(c,a,ss),z in sorted(P.items())]
def digest_bytes(z):return sha256(json.dumps(z,separators=(',',':')).encode()).hexdigest()
def canonical_table(P,den,w):
 out=[];seen=set()
 for(c,a,ss),z in P.items():
  word=(f'C{c}',ANTI[a],*ss);assert word==tuple(sorted(word)) and sum(w.p[n] for n in word)==2 and all(n in w.fields for n in word);assert word not in seen;seen.add(word);out.append([list(word),cells(z,den)])
 out.sort(key=lambda r:r[0]);assert len(out)==len(P);return out
def fixtures():
 w=algebra();q=w.mul(w.var('ub12'),w.var('C0'),w.var('x_Phi_0'));assert q=={(('C0',()),('ub12',()),('x_Phi_0',())):-1};assert not w.mul(w.var('C0'),w.var('C0'))
 P=w.mul(w.var('C0'),w.var('ub12'),w.add(w.scale(w.var('x_Phi_0'),2),w.scale(w.var('x_Phi_1'),3)),w.add(w.scale(w.var('x_Phi_0'),2),w.scale(w.var('x_Phi_1'),3)))
 assert sorted(P.values())==[4,9,12] and len(P)==3
 assert mul(((8,1),),((8,1),))==((0,-1),) and mul(((16,1),),((16,1),))==((0,7),)
 return True
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CANONICAL_SCALAR_GHOST_TRANSPORT_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);assert fixtures();r=read(OUT.parent/'canonical_so10_scalar_ghost_actual_pole/validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['scientific_disposition']=='ALL40_ACTUAL_SCALAR_GHOST_PROFILES_FULL_PHYSICAL_POLES_QUALIFIED_NOT_INTEGRATED';d=auth('canonical_so10_scalar_ghost_actual_pole',role+'_result.json');packets=dict(r['coalesced_physical_linear_tables']);packets['g4_etaH0_xi0_scalar2']=d['group_physical_poles']['g4_xi0_pair'];assert set(packets)==set(PARAM)
 print('STAGE '+role+' full643_actual_fields_inverses_reality_and_word_bridge',flush=True);C,dc,A,da,IC,dic,IA,dia,scalar,w,proof=frames(sealed('frozen_a10_e5_full_hessian',role)['retained_reference']);backscalar={n:i for i,n in scalar.items()};out={};hashes={};counts={};metadata={};complex_count={};sqrt7_count={};control={};contributions=0
 for label,rows in packets.items():
  t=time.perf_counter();P,dp=raw_packet(rows);assert all(not(m&8) for z in P.values() for m,v in z);assert all(len(ss)==PARAM[label][3] for c,a,ss in P)
  Crows=rows_by_input(C);Arows=rows_by_input(A);closed=sum(len(Crows[c])*len(Arows[a]) for c,a,ss in P);contributions+=closed;N=pull(P,C,A,scalar,role);dn=dp*dc*da;back=pull(N,IC,IA,backscalar,'replay' if role=='primary' else'primary');db=dn*dic*dia;assert back=={key:scale(z,db//dp) for key,z in P.items()}
  out[label]=canonical_table(N,dn,w);hashes[label]=digest_bytes(out[label]);counts[label]=len(N);complex_count[label]=sum(any(m&8 for m,z in value) for value in N.values());sqrt7_count[label]=sum(any(m&16 for m,z in value) for value in N.values())
  key=next(iter(N));delta={key:N[key]};changed=pull(delta,IC,IA,backscalar,'primary');assert changed;off=next((k for k in N if len(k[2])==2 and k[2][0]!=k[2][1]),None);imag=next((k for k in N if any(m&8 for m,z in N[k])),None)
  if off is not None:assert pull({off:N[off]},IC,IA,backscalar,'primary')
  if imag is not None:assert pull({imag:tuple((m,z) for m,z in N[imag] if m&8)},IC,IA,backscalar,'primary')
  control[label]={'one_nonzero_omission_or_sign_changes_inverse':True,'extra_Bose_factor_on_nonzero_cross_changes_inverse':off is not None,'discard_complex_component_changes_inverse':imag is not None}
  metadata[label]={'physical_positions':len(P),'canonical_parameter_positions':len(N),'unfiltered_forward_field_map_contributions':closed,'physical_integer_denominator':dp,'canonical_integer_denominator':dn,'seconds':time.perf_counter()-t};print('STAGE '+role+' '+label+' canonical='+str(len(N))+' seconds='+str(round(time.perf_counter()-tick,3)),flush=True)
 assert contributions==4175624
 result={'schema':'COMPLETE_ACTUAL_SCALAR_GHOST_CANONICAL_TRANSPORT_V1','route':role,'scientific_disposition':'COMPLETE_CANONICAL_SCALAR_GHOST_POLE_WITH_EXACT_INVERSE_AND_REALITY_PROOF_NOT_INTEGRATION','canonical_parameter_tables':out,'canonical_parameter_hashes':hashes,'canonical_parameter_counts':counts,'canonical_complex_parameter_positions':complex_count,'canonical_sqrt7_parameter_positions':sqrt7_count,'all_canonical_coefficients_in_old_four_root_subring':not any(sqrt7_count.values()),'exact_basis_squared':list(u.SQ),'parameter_packet_powers':PARAM,'full_field_map_and_reality_proof':proof,'all_parameter_packets_complete_inverse_and_implicit_zeros_recovered':True,'physical_coefficients_real_in_fixed_odd_order':True,'canonical_word_map_bijective_in_actual_alphabet':True,'whole_polynomial_reality_by_conjugate_T_R_identity_and_pullback_composition':True,'odd_even_and_diagonal_cross_fixtures_passed':True,'controls':control,'insensitive_controls':['extra Bose-factor control only applies to scalar degree2','dropping imaginary parts is insensitive for a wholly real canonical packet','source-dual/field difference is a full chart-domain control,not asserted observable sensitivity'],'transport_metadata':metadata,'complete_unfiltered_forward_contributions':contributions,'current_known_terms':155143,'current_known_sha256':d['current_known_sha256'],'sourcefree_positions':41452,'sourceimage_positions':146663,'all_seven_quantum_flags_false':d['all_seven_quantum_flags_false'],'new_loop_canonical_integration_or_Slavnov_identity':False,'full_QAP_IR_measure_products_contacts_equivalence_E5_A5':False,'shared_limits':'Same measured poles/action/reference/prior UV/word premises,software and AI author. New complete field pullbacks/inverses and structural reality,not new physical validation','elapsed_after_imports':time.perf_counter()-tick}
 assert not any(result['all_seven_quantum_flags_false'].values());print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
