"""SCL1 sequential native geometry/numerics and independent absolute verifier."""
from pathlib import Path
from hashlib import sha256
import json,sys,gzip
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-laurent-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def auth(p):
    for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
def resource(c):
    assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed']
    assert c['post_run_observations_qualified'] and c['private_allocation_limit_bytes']==8*1024**3
    assert c['launch']['memory']['available_pagefile']>=350*1024**2
    assert c['all_resource_samples'] and all(0<x['private_bytes']<=8*1024**3 for x in c['all_resource_samples'])
def one(role,kind):
    argv=[sys.executable,'-B',str(HERE/(kind+'.py'))]+([] if kind=='verify' else [role])
    c=capture(argv);name=role+'_'+kind;dump(HERE/(name+'_capture.json'),c);dump(CONTROL/(name+'_full_capture.json'),c)
    if c['execution_state']!='COMPLETED':print(c['stdout_and_stderr'],flush=True)
    resource(c);rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
    v=rows[0];assert v['elapsed_after_imports']<(300 if kind=='geometry' else 600)
    dump(HERE/('validation_receipt.json' if kind=='verify' else name+'_result.json'),v)
    print(name,'COMPLETED',v['elapsed_after_imports'],flush=True);return v
prep=json.loads((HERE/'preparation.json').read_bytes());auth(prep)
if sys.argv[1]=='geometry':
    one('primary','geometry');one('replay','geometry')
    ts=[json.loads(gzip.decompress((HERE/(role+'_geometry_tables.json.gz')).read_bytes())) for role in ['primary','replay']]
    assert ts[0]['color_weights']==ts[1]['color_weights'] and ts[0]['exact_Iminus1']==ts[1]['exact_Iminus1'] and ts[0]['simplex_area']==ts[1]['simplex_area']
    print('BOTH_COMPLETE_PROJECTIVE_DOMAINS_AND_EXACT_ENDPOINT_RESIDUES_AGREE',flush=True)
else:
    names=list(map(Path,prep['input_sha256']))+[HERE/'preparation.json']
    for role in ['primary','replay']:
        resource(json.loads((HERE/(role+'_geometry_capture.json')).read_bytes()))
        names += [HERE/(role+'_geometry'+suffix) for suffix in ['_capture.json','_result.json','_tables.json.gz']]
    if sys.argv[1]=='numeric':
        vp={'schema':'SCL1_NUMERIC_PREPARATION','input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
        dump(HERE/'numeric_preparation.json',vp);auth(vp);one('primary','numeric');one('replay','numeric')
    else:
        assert sys.argv[1]=='validate';names += [HERE/'numeric_preparation.json']
        for role in ['primary','replay']:
            resource(json.loads((HERE/(role+'_numeric_capture.json')).read_bytes()))
            names += [HERE/(role+'_numeric'+suffix) for suffix in ['_capture.json','_result.json','_tables.json.gz']]
        vp={'schema':'SCL1_VALIDATION_PREPARATION','input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
        dump(HERE/'validation_preparation.json',vp);auth(vp);one('validation','verify')
