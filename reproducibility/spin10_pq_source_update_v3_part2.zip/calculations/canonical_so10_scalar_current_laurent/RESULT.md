# SCL1: actual bare sunset poles and finite coefficients are now calculated

The positive-heavy four-singlet restriction of the scalar-current sunset now
has an undifferentiated bare Laurent coefficient, including its finite part.
Two different projective decompositions agree, and an independent neutral
momentum/master calculation checks the absolute finite constants. This goes
beyond SCP1's derivative test, which could not determine those constants.

This is the normalized U1_Y projection of a declared component of VSS. It is
NOT the renormalized finite sunset, a complete three-component matching
vector, complete C1_GS, E5/A5 or a gauge-unification result. Actual operator
UV forests and light/EFT matching remain required. Scientific acceptance
NOT_PERFORMED; project_state113 and authority34/39 are unchanged.

Final V3 receipt SHA256:
`0a9f475968efc76504a89491d88a16eb8326eb42d460b4f77919eeff5ef7b0ad`, status
QUALIFIED_BARE_VSS_LAURENT_FOUR_SINGLET_POSITIVE_HEAVY_RESTRICTION.
V1 failed numeric and V2 failed verifier evidence are retained, as are the
corrected V2 native integrations. Do not rerun any completed exclusive
controller under the same output names.

## The actual coefficient and its scope

The qualified SCP1 scalar-current vertex/charge table has exactly eight
nonzero positive-vector routes in the retained four-scalar restriction.
They organize into three channels. The remaining four nonzero light-vector
routes remain recorded and unintegrated, not zero. All other324 scalar
directions remain outside this component calculation.

Use aN=(3/2)g10², aC=aN/5, mH²=426075291/62500000 and r=mH²/aN>0.
The neutral physical, neutral Goldstone and charged channels have mass
arguments(r,r,1), (1/5,1/5,1), (5r,1,1) in their respective mass units.
Measured color weights are1/5,9/5,4. Normalized external charges supply
12/5,3/5,3/5, so the complete3/2-weighted multipliers are18/25,81/50,18/5.
They were recovered from actual model coefficients, not fitted to a pole.

The exact endpoint logarithmic residues sum to zero in both charge families.
Thus the bare double pole vanishes in this retained domain. Individual
sector residues are preserved; canonical zero is established analytically
and independently checked numerically, not imposed by a numerical cutoff.

For Lambda2=-12 Gamma2_Fphys²/(ell²g10²), ell=1/(16pi²), the resulting form is

    Lambda_four-singlet,+,bare2
       = g10² [ P1(r)/epsilon + F0(r) + 2 jN P1(r) ] +O(epsilon),
    jN=log(Qscale²/aN)=log(Qscale²/60)-log(g10²)+log40.

The code and regular integral representation retain arbitrary positive r;
each numerical call must pass the declared convergence test. No uniform
accuracy at untested extreme r, g0 or massless limits is proved. Diagnostic
coefficient values below are rounded for reading; native tables report20
digits, and no physical g, scale or benchmark was adopted.

| diagnostic r | P1(r), bare simple pole | F0(r), constant coefficient at symbolic jN |
|---:|---:|---:|
| 1 | -75.84 | -212.65083704931244472 |
| 2 | -133.44 | -316.51616078455350511 |

These are polynomial coefficients in the retained scale variable, not a
choice jN=0 as a physical matching condition. Charged jC=jN+log5 is included
before adding channels. No function of r was inferred by fitting these two
diagnostics. The convergent integral algorithm defines the r dependence.
Their magnitude/sign cannot assess the full threshold or repair the
historical gauge mismatch: subdivergence subtractions and other diagrams
can materially change the result.

For comparison, unit-charge channel coefficients at base scale Q²=a_case:

| channel | p2 | p1 | bare finite f0 |
|---|---:|---:|---:|
| neutral physical, r=1 | 0 | -0.66666666666666666667 | 3.3544811440455844479 |
| neutral physical, r=2 | 0 | -0.83333333333333333333 | 3.8696084660749677485 |
| neutral Goldstone | 0 | 0.66666666666666666667 | 6.3985553661032716566 |
| charged, r=1 (mass ratio5) | 0 | -21.233333333333333333 | 5.7275402463368610173 |
| charged, r=2 (mass ratio10) | 0 | -37.2 | 28.167753303648517322 |

## Why the finite coefficient is not just a finite master

The new calculation restores the exact common MSbar factor
exp(2gamma_E epsilon)(Qscale²)^(2epsilon) documented in SCP1's normalization
clarification. It retains D=4-2epsilon and the full endpoint continuation.
It does not assign UV zero to a power-sensitive term.

Primary uses six ordered largest-proper-time sectors. Replay uses three
largest-time sectors, each split into a radial triangle and a finite
complement. Their exact simplex coverage is independently checked as
6/12=3(1/8+1/24)=1/2. This is different parameter geometry, not a repeated
evaluation of one sector formula.

For each singular sector the actual kernel is put in the form
int da a^(-2+epsilon) k(a,b,epsilon). Its Taylor terms are integrated with
their exact1/(n-1+epsilon) factors. In particular k0/(epsilon-1) is retained,
as is k1/epsilon. The finite remainder includes log(a), the dimensional
kernel correction, mass logarithms and analytic Taylor-restoration terms.
Primary Taylor degree12/binomial coefficients and replay degree10/quotient
recurrence agree. Every subtracted polynomial is restored; no cutoff or
discarded finite boundary is used.

The radial factor exp(2gamma_E e)Gamma(2e)=1/(2e)+zeta(2)e+... requires
projective coefficients through e¹ and the logarithmic endpoint through e².
Those orders are kept. The universal Gamma-zeta contribution cancels here
because the exact summed double pole is zero. This particular negative
control is INSENSITIVE; it does not justify dropping such terms in other
families or individual sectors. Individual sector data preserve the pieces.

These endpoint continuations define the meromorphic BARE graph. They do not
by themselves construct the actual local UV counterterm action or establish
a renormalized subtraction/Slavnov theorem. No finite normalization was
selected and no pole was fitted away.

## Absolute neutral check and sensitive omissions

The independent general-D Fourier calculation reduces the derivative-current
numerator to bare scalar sunset mass derivatives and factorized tadpole
products. It uses the qualified MVM finite master I and its derivatives only
after including bare A_e terms and the positive-epsilon powers of4/D.
The exact neutral double pole is0 and simple pole is

    [-8xy+x(x+z)+y(y+z)]/(6xy).

For x=y this is -1+z/(3x). The absolute finite coefficients also agree:
maximum scaled master discrepancy5.5376193208352474545e-36, versus required
1e-20. This checks constants lost by SCP1's sixfold derivative. The finite
master convention and action remain shared inherited inputs, not a new
external validation of the physical model.

Several controls have actual nonzero effects. In the unit neutral r=2 case,
deleting the power-sensitive endpoint term changes p1 by-0.25 and f0 by
0.15433585532663476383. Premature D4 in the proper-time kernel changes p1 by
-0.38888888888888888889 and f0 by0.35392928858366116658.

Premature D4 in the independent MOMENTUM reduction is a different mutation:
it changes its angular4/D factors rather than the coordinate kernel's D
trace. There it changes p1 by-1 and f0 by2.5529610277865572855 at r=2.
Do not equate these two mutation definitions. Omitting positive-epsilon
tadpole PRODUCTS changes the neutral r=2 finite coefficient by
-2.1253870807664278611; removing the momentum vertex term changes p1 by+1
and f0 by-2.6188534511521581841. All are measured independently of any desired
pole cancellation. Missing/repeated sectors are also checked by exact area,
complete route census and retained individual coefficients.

Working80digits, Gauss48/80/128, scaled convergence1e-22; all tested last
changes are below35-digit history resolution. Cross-sector discrepancy is
zero at that reporting resolution, not an exact numerical error bound.
20-digit coefficients are reported. Independent master agreement and
distinct decompositions corroborate the numerics; no rigorous error interval
or uniform extreme-r guarantee is claimed.

## Failures, corrections and reproducibility

One native implementation and one verifier failed; neither is relabeled PASS.
Two pre-computation documentation patches were also rejected and preserved
in PREPARATION_EDIT_EVENTS.md. The failures did not change physical inputs.

V1 primary failed its unequal-mass convergence check at5.9144484878327869e-5.
A loop-axis accumulator overwrote an edge index, corrupting the mass map
after the first quadrature node. All-equal masses could not detect it. V2
uses distinct index names and tests forward/reversed-node invariance at
unequal masses to1e-65. A direct emulation of the wrong mass-log map changes
the order result by0.000765203189833579168, demonstrating sensitivity.
The failed source/capture and corrected new sources are retained. Geometry
was reused; the failed numerical worker had no completed numeric result.

The V2 verifier then stopped in SymPy collect() with unsupported multivariable
Derivative atoms, before any absolute master comparison. V3 substitutes
epsilon-independent coefficient symbols BEFORE expanding in epsilon and
evaluates the same mass derivatives afterward. No formula, master constant,
quantum input or tolerance changes. Completed numerical integrations were
reused unchanged. IMPLEMENTATION_CORRECTION_V2.md and VERIFIER_CORRECTION_V3.md
record the versioned continuation and precise failure boundaries.

Commands: python -B prepare.py; run.py geometry; run.py numeric(FAILED V1);
prepare_v2.py; run_v2.py numeric; run_v2.py validate(FAILED V2 verifier);
run_validation_v3.py(COMPLETED final verification). Exclusive names prohibit
rerunning these controllers into old evidence. No scientist was contacted,
no new Lean/tool framework installed and no remote action taken.

Geometry15.1011163/16.6721851s, corrected numerics189.1689355/261.8511134s,
final verifier27.2215338s after imports. Frozen caps300s geometry,600s native/
verifier,8GiB sampled private memory,350MiB launch floor,4MiB new package.
Success sample counts8/9/95/131/15, sampled maxima53035008/53755904/48549888/
51208192/65802240B. Failed native39samples/max48308224B; failed verifier
11samples/max58523648B. These are sampled observations, NOT continuous peaks.
No resource timeout; all completed and failed captures remain available.

2441 initialbindings, V2 continuation2460bindings, all authenticated in the
final validation preparation. Source/data/action, SCP1 heat/P2 and field maps,
SymPy/mpmath and AI authorship remain shared premises. Two AI implementations
are not independent scientists. No independent physics/experimental validation.

Primary/replay geometry raw4884/11063B, gzip924/1623B, rawSHAs
6ff32e4d950717324d1796eff481115c08f0e36b9a15a80db258388577e99adc and
4d6725641d25211df5fbc6c9fdec8184f171ae7e4174d00ed12747b449fd5def.
Corrected numeric raw8252/8079B, gzip2030/2177B, rawSHAs
b59a7fc6386c01f9fec57d01992d3b92d25a0bdb1a3f101f226e21f748850f57 and
e074d0c3e2eab814059763302bedf8475e66a013e1965116b084b2476b31b337.
Different tables preserve different decompositions and Taylor degrees.

## Scientific ceiling and next step

The next indispensable object is the actual current-vertex UV insertion
operators, with their background/curvature terms, then their overlapping
forest assembly and common light/EFT treatment. Remaining simple poles are
not anomalies or physical vector-mass predictions. A local overall F2 pole
may remain after subdivergences; it must be assessed as such, not forced to
zero by fitting an unknown counterterm.

Keep R_VVSS+(C_parent-C_VVSS), not a duplicated full parent insertion. No
VSP1/FCI1/HTB1/EAT1 subtotal, old source polynomial, finite f_fin or VFN1
correlated q result changed. Full C1 remains null, E5/A5 unqualified,
HB1/C5 blocked and flavor humanpaused. QuartetFAIL3960/648, scalar140%/
Euclidean1.94%/timelike20.27%, matching.745476 and missing Yukawas remain
distinct. e4 completed six expected exits without replaying old physics;
custody exit2/seven unresolved references is NOT PASS. No physical scheme,
foundations, action, point, protected authority, branch, publication or push
changed. The original full investigation goal remains active/incomplete.
