"""SCL1 fixed inputs, serialization and resource controls."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,itertools
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
st,tt,ut,D,q1,q2,qv=s.symbols('s t u D q1 q2 qv',positive=True)
a,b=s.symbols('a b',positive=True);LOC={str(v):v for v in [st,tt,ut,D,q1,q2,qv,a,b]}
def read(p):return json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def clean(z):return s.cancel(s.expand(z))
def expr(z):return s.sympify(z,locals=LOC)
def begin(prep='preparation.json',seconds=300):
    start=time.perf_counter();timer=threading.Timer(seconds,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in read(HERE/prep)['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return start
def save(role,kind,tab,start,extra=None):
    raw=(json.dumps(tab,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_'+kind+'_tables.json.gz')).open('xb') as out:out.write(blob)
    v={'schema':'SCL1_'+kind.upper(),'role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)}
    if extra:v.update(extra)
    print('RESULT '+json.dumps(v,sort_keys=True),flush=True)
def nf(z):return mp.nstr(z,35)
