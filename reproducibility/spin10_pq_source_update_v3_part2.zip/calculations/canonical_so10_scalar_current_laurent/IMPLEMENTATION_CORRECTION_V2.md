# SCL1 V2: preserve failed convergence evidence and correct edge-label reuse

V1 primary numeric execution FAILED with exit1 at the r=2 neutral physical
convergence assertion: scaled80/128 difference
0.000059144484878327868811209323376785308, versus required1e-22.
Its complete primary_numeric_capture.json and external full capture remain.
The two equal-mass r=1 orders completed before this, but the worker produced
no completed numeric result/table. Replay numeric and the verifier were NOT
launched. The later controller assertion is downstream of that same worker
failure, not a second scientific result. Preserve all V1 source/snapshots.

Exact cause: one_row assigned dom,j,k=row['order']; after each outer b node,
`for j,z in enumerate(vals): total[j]+=bw*z` left j=2. The next outer node
then read masses[j] as the wrong edge. At all-equal masses this is invisible.
At unequal masses it corrupts M1 and introduces a first-node dependence.
This is an implementation error, not failed physics or a resource timeout.

V2 uses distinct immutable edge names and an axis accumulator name. It adds
a forward/reversed-node processing invariance test at the actual unequal-mass
diagnostic, tolerance1e-65, and a small explicit emulation of the bad mass-log
map that must remain sensitive. No old failed expensive calculation is rerun.
No physical input, subtraction, tolerance, quadrature order or resource cap
changes. Both completed geometry routes are authenticated and reused.

Before V2 computation freeze numeric_v2.py, verify_v2.py, prepare_v2.py,
run_v2.py, this record, all old bindings, geometry evidence, V1 preparation
and failed capture. New exclusive numeric_v2 and receipt_v2 names. Same
Gauss48/80/128, working80/report20,1e-22 convergence/1e-20 route and master
agreement,600s native/verifier,8GiBsampled/350MiBfloor/4MiBwholepackage.
No weakening of scientific acceptance or authority. Any further failure
remains preserved and unqualified; do not manufacture a passing result.
