# SCL1 V3: preserve SymPy failure; keep the absolute neutral check

Both corrected V2 native numerical routes completed without changing their
tolerances. V2 verification then FAILED with exit1 in master_reference.py,
before producing a master coefficient or making any absolute comparison.
SymPy series()->collect() raised `NotImplementedError: Improve MV Derivative
support in collect` on a multivariable Derivative of finite I(x,y,z).
validation_verify_v2_capture.json and its external full capture are retained.
This is a verifier implementation failure, not a mathematical disagreement.

V3 replaces each finite, epsilon-independent master derivative by an opaque
coefficient symbol BEFORE the epsilon expansion; afterward it evaluates the
same mass derivatives. V2 replaced them after series, too late for this
SymPy implementation. No term, coefficient, finite master normalization or
physical premise changes. Original master_reference.py and verify_v2.py stay
unchanged. The absolute finite-coefficient requirement remains1e-20.

Freeze master_reference_v3.py, verify_v3.py, run_validation_v3.py, this record,
all completed native outputs and exact failed-verifier capture before running.
Reuse both completed geometry and V2 numerical routes; no repeated integration.
Same600s verifier/8GiBsampled/350MiBfloor/4MiBwholepackage ceiling. Complete
the original gate, or preserve an unqualified failure/incompleteness. No
authority or protected-stage change and no passing result manufactured.
