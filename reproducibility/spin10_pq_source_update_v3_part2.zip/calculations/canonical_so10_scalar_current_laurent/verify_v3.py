"""SCL1 independent geometry, absolute neutral master and scale controls."""
from data import *
from master_reference_v3 import formula,evaluate as master_eval
def main():
    start=begin('validation_preparation_v3.json',600);mp.mp.dps=80
    G=[packed(HERE/(r+'_geometry_tables.json.gz')) for r in ['primary','replay']]
    T=[packed(HERE/(r+'_numeric_v2_tables.json.gz')) for r in ['primary','replay']]
    old=packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz');P=expr(old['P2']);v=[st,tt,ut]
    assert G[0]['decomposition']=='ordered6' and G[1]['decomposition']=='triangle3_and_complement3'
    assert G[0]['color_weights']==G[1]['color_weights']=={'neutral_physical':'1/5','neutral_Goldstone':'9/5','charged':'4'}
    print('STAGE independent_geometry_and_projective_coverage',flush=True)
    for role,g in zip(['primary','replay'],G):
        for fam,qs in [('neutral',[-1,1,0]),('charged',[-2,1,1])]:
            pk=P.subs({q1:qs[0],q2:qs[1],qv:qs[2]});rows=g['rows'][fam];endpoint=0
            assert len(rows)==6
            if role=='primary':assert {tuple(r['order']) for r in rows}==set(itertools.permutations(range(3)))
            else:assert {tuple(r['order']) for r in rows if r['kind']=='UV'}=={(0,1,2),(1,0,2),(2,0,1)}
            for row in rows:
                shape=list(map(expr,row['shape']));U=clean(shape[0]*shape[1]+shape[0]*shape[2]+shape[1]*shape[2]);sub=dict(zip(v,shape))
                expected=clean(a*pk.subs(sub,simultaneous=True)/U**2)
                if row['kind']=='UV':
                    H=expr(row['H0'])+a*expr(row['H1']);assert clean(U-a*H)==0
                    n0=sum(expr(z)*a**j for j,z in enumerate(row['n0']));n1=sum(expr(z)*a**j for j,z in enumerate(row['n1']))
                    assert clean(n0/H**4-a**2*expected.subs(D,4))==0
                    assert clean(n1/H**4+2*a**2*s.diff(expected,D))==0
                    ep=clean(s.diff(n0/H**4,a).subs(a,0));epint=s.simplify(s.integrate(ep,(b,0,1)))
                    assert epint==s.sympify(row['exact_Iminus1']);endpoint+=epint
                else:
                    assert clean(expr(row['w0'])-expected.subs(D,4))==0
                    assert clean(expr(row['w1'])+2*s.diff(expected,D))==0
                # Direct 2D normalized-simplex Jacobian, including orientation.
                S=sum(shape);alpha=[clean(shape[j]/S) for j in range(2)]
                jac=s.Matrix([[s.diff(q,z) for z in [a,b]] for q in alpha]).det()
                assert clean(jac*jac-a*a/S**6)==0
            assert s.simplify(endpoint-s.sympify(g['exact_Iminus1'][fam]))==0
        assert g['simplex_area']=='1/2'
    # Independently integrate the distinct coverage pieces.
    ar_ordered=s.integrate((s.Rational(1,2))*((1+a)**-2-(1+2*a)**-2),(a,0,1))
    ar_tri=s.integrate(a/(1+a)**3,(a,0,1));ar_out=s.integrate((s.Rational(1,2))*(s.Rational(1,4)-(2+a)**-2),(a,0,1))
    assert ar_ordered==s.Rational(1,12) and ar_tri==s.Rational(1,8) and ar_out==s.Rational(1,24)
    print('STAGE independent_absolute_neutral_masters',flush=True)
    names=['neutral_physical_r1','neutral_physical_r2','neutral_Goldstone','charged_r1','charged_r2'];routeerr=mp.mpf(0)
    for name in names:
        for t in T:assert mp.mpf(t['cases'][name]['last_scaled_change'])<mp.mpf('1e-22')
        xs=[list(map(mp.mpf,t['histories'][name][-1]['bare'])) for t in T]
        for x,y in zip(*xs):
            err=abs(x-y)/(1+abs(x));routeerr=max(routeerr,err);assert err<mp.mpf('1e-20'),('SECTOR_ROUTE_MISMATCH',name,nf(err),nf(x),nf(y))
    references={};referr=mp.mpf(0);mutants={}
    for name,masses in [('neutral_physical_r1',[mp.mpf(1),mp.mpf(1),mp.mpf(1)]),
      ('neutral_physical_r2',[mp.mpf(2),mp.mpf(2),mp.mpf(1)]),
      ('neutral_Goldstone',[mp.mpf(1)/5,mp.mpf(1)/5,mp.mpf(1)])]:
        base=master_eval(masses);references[name]=list(map(nf,base))
        for t in T:
            measured=list(map(mp.mpf,t['histories'][name][-1]['bare']))
            for x,y in zip(base,measured):
                err=abs(x-y)/(1+abs(x));referr=max(referr,err);assert err<mp.mpf('1e-20'),('ABSOLUTE_MASTER_MISMATCH',name,nf(err),nf(x),nf(y))
        mutants[name]={}
        for var in ['no_Ae_products','D4','no_vertex']:
            wrong=master_eval(masses,var);delta=[x-y for x,y in zip(wrong,base)]
            mutants[name][var]=list(map(nf,delta))
    assert all(any(abs(mp.mpf(v))>mp.mpf('1e-30') for c in mutants.values() for v in c[var]) for var in ['no_Ae_products','D4','no_vertex'])
    # Scale restoration is an exact group law, checked before any normalization fit.
    p2,p1,f,j,k=s.symbols('p2 p1 f j k');shift=lambda v,t:[v[0],v[1]+2*t*v[0],v[2]+2*t*v[1]+2*t*t*v[0]]
    assert [clean(x-y) for x,y in zip(shift(shift([p2,p1,f],j),k),shift([p2,p1,f],j+k))]==[0,0,0]
    assert shift([p2,p1,f],0)==[p2,p1,f]
    for r in ['1','2']:
        x,y=[list(map(mp.mpf,t['weighted_total_P2_P1_F0_base_jN0'][r])) for t in T]
        for u,vv in zip(x,y):assert abs(u-vv)<mp.mpf('1e-20')*(1+abs(u))
    coeff,_=formula();controls={n:{k:v for k,v in T[0]['controls'][n].items()} for n in names}
    assert any(mp.mpf(row['omitted_k0_change_finite'])!=0 for row in controls.values())
    assert any(mp.mpf(row['premature_D4_change_finite'])!=0 for row in controls.values())
    value={'schema':'SCL1_VALIDATION','execution_state':'COMPLETED',
      'status':'QUALIFIED_BARE_VSS_LAURENT_FOUR_SINGLET_POSITIVE_HEAVY_RESTRICTION',
      'elapsed_after_imports':time.perf_counter()-start,'sector_route_scaled_error':nf(routeerr),
      'absolute_neutral_master_scaled_error':nf(referr),'neutral_master_reference':references,
      'neutral_exact_p2_p1':[str(coeff[0]),str(coeff[1])],'master_mutant_changes_p2_p1_f0':mutants,
      'controls':controls,'geometry_area':'1/2=6/12=3(1/8+1/24)',
      'complete_positive_heavy_selected_vertex_routes':8,'actual_color_weights':G[0]['color_weights'],
      'arbitrary_positive_r_integral_representation':True,'uniform_extreme_r_numerical_accuracy_proved':False,
      'finite_RENORMALIZED_sunset_C1_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(value,sort_keys=True),flush=True)
if __name__=='__main__':main()
