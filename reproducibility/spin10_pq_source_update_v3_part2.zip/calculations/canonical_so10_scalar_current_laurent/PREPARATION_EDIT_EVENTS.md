# Two rejected pre-computation documentation patches

Both attempted edits targeted RECORD.md and were rejected atomically because
their context did not exist. No scientific calculation had started; no input,
source snapshot or evidence was changed. The successful patch uses the exact
title as its context. These are preparation editing errors, not worker failures.

First exact attempted hunk:
```diff
@@
 before science freeze sources, assumptions, expected evidence, all immutable
```
Diagnostic: `apply_patch verification failed: Failed to find expected lines
in .../RECORD.md: before science freeze sources, assumptions, expected evidence,
all immutable`.

Second exact attempted hunk:
```diff
@@
 a desired cancellation.
+
+The coefficient of the endpoint logarithmic pole is integrated exactly in
+the remaining projective variable. Its analytic value fixes the double-pole
+coefficient only after native quadrature independently agrees. Retain both
+the raw numerical residue and exact coefficient; canonical exact zeros are
+not numerical cutoff declarations or truncated evidence.
```
Diagnostic: `apply_patch verification failed: Failed to find expected lines
in .../RECORD.md: a desired cancellation.`
