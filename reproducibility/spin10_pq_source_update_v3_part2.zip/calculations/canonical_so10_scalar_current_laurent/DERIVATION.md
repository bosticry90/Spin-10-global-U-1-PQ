# SCL1 prospective meromorphic sector and neutral master derivation

SCP1 supplies the ordered geometric P2(D) of the actual VSS vertex. Restore
its previously clarified two-loop normalization. In Lambda2/g10² units the
bare integral is (3/2) W N_e int dsdtdu exp(-xs-yt-zu) U^(-D/2)P2(D),
U=st+su+tu,D=4-2e,N_e=exp(2gamma_E e)(Qscale²)^(2e).

## Two complete projective decompositions

Six ordered sectors: s_i=R,s_j=Ra,s_k=Rab, JacobianR²a, U=R²aH,
H=1+b+ab, M=m_i²+a m_j²+ab m_k². Because P2 is homogeneous degree1,
the radial integral is Gamma(2e)M^(-2e). Write

 k(a,b,e)=a P2(1,a,ab;4-2e) H^(-2+e) M^(-2e).

Then the remaining integral is int dbda a^(-2+e)k. Prove aP2/H² is regular
at a0,b0 by exact rational cancellation, not sampling. The factor a in k is
essential; it is different from the Jacobian's a before extracting a powers.

Independent three largest-time sectors: s_i=R,s_j=RA,s_k=RB, A,B in[0,1].
In the triangle A+B<=1, put A=ab,B=a(1-b), Jacobian a. Now H=1+ab(1-b),
M=m_i²+a[b m_j²+(1-b)m_k²], with the SAME a^(-2+e)k structure.
In the finite complement use A=a,B=1-a+ab, Jacobian a. Its integrand is
a P2(1,A,B) U0^(-2+e) M^(-2e); no endpoint UV subtraction is needed there.

Coverage is exact. The uniform simplex measure is projective Jacobian divided
by(sum proper-time coordinates)^3. Each of six ordered sectors has area1/12.
For each largest-time sector the triangle has area int_0^1 a/(1+a)^3 da=1/8,
its complement area1/24. Thus6/12=3(1/8+1/24)=1/2, the simplex's full area.
These are geometric tests, not assignments of a quantum coefficient.

## Laurent extraction with all subtractions restored

Write k=(v0+e v1) exp(e L), L=log H-2log M, v0=aP2(D4)/H²,
v1=-2a partial_D P2/H². Keep scale restoration separate initially.
For Taylor degreeN, let k_n(e) be the a^n coefficient at a0. Meromorphic
continuation of an absolutely convergent initial domain gives

 int da a^(-2+e) k = sum_(n=0..N) k_n(e)/(n-1+e)
                  +int da a^(-2+e)[k-sum_(n=0..N)k_n(e)a^n].

No finite term is discarded. In particular n0 has1/(e-1), n1 has1/e.
With v0_n,v1_n and L_n denoting Taylor coefficients,
L0=logH0-2logM0,
L_n=(-1)^(n+1)[(H1/H0)^n-2(M1/M0)^n]/n for n>=1,
k_n^0=v0_n, k_n^1=v1_n+sum_j v0_j L_(n-j).
For n1 we also need
k1^2=v1_1 L0+v1_0 L1+v0_1 L0²/2+v0_0 L0 L1.

Let the total projective integral be Aminus1/e+A0+A1 e+O(e²). Then
exp(2gamma_E e)Gamma(2e)=1/(2e)+zeta(2)e+O(e²), hence at base Q²=1

 p2=Aminus1/2, p1=A0/2, f0=A1/2+zeta(2)Aminus1.

For each positive mass unit a_case, j=log(Qscale²/a_case) restores
p2/e²+(p1+2jp2)/e+f0+2jp1+2j²p2. The complete bare finite term is not a
renormalized finite amplitude. Taylor endpoint terms are not yet the actual
opened UV counterterm action. No desired-pole fit or counterterm adoption.

## Actual positive-heavy four-singlet restriction

Reuse the authenticated SCP1 weight table. Positive vector rows exhaust:
neutral physical weight1/5, neutral Goldstone9/5, charged4. Light-vector rows
remain outside this positive-heavy calculation. Scalar charges are normalized
by c²=3/5. Use a UNIT neutral kernel(-1,+1,0) with external factors12/5 and3/5,
and a UNIT charged kernel(-2,+1,+1) with external factor3/5. Including3/2 Wick/
matching normalization, the three total multipliers are18/25,81/50,18/5.

aN=(3/2)g10², aC=aN/5, r=mH²/aN, mH²=426075291/62500000. Neutral physical
mass arguments(r,r,1), Goldstone(1/5,1/5,1), charged(5r,1,1).
jN=log(Qscale²/aN)=L-Ulog+log40; charged jC=jN+log5. No g or scale chosen.
The total is g10²[P2/e²+(P1(r)+2jN P2)/e
                  +F0(r)+2jN P1(r)+2jN²P2].
This expression and the positive-r integral algorithm, not two diagnostic
numbers alone, constitute the amplitude input. All other scalar directions,
massless/multisoft/EFT terms and actual renormalized assembly remain open.

## Independent absolute neutral Fourier/master formula

Keep D before expanding. Put Ax=4/D-1, k=z-2x-2y and J_abc for the normalized
bare scalar master with denominators Px^a Py^b Pv^c. Numerator reduction of
the neutral SCP1 momentum expression gives the UNIT-charge bare integral

 Ax[2J211+2J121+k(J311+J131)+2J301+2J031-J310-J130]
 -(4/D){x[2J311+kJ411+2J401-J410]
          +y[2J131+kJ141+2J041-J140]}
 +(4/D)[J220-J121-J211+(x+y-z)J221].

For all positive indices J_abc=(-1)^(a+b+c-3)/(a-1)!(b-1)!(c-1)! times the
corresponding mass derivatives of bare J111. Zero-index terms factorize:
J_a0c=A_a(x)A_c(z), J_ab0=A_a(x)A_b(y), J_0bc=A_b(y)A_c(z).
A_n=(-1)^(n-1) partial_x^(n-1) Abar(x)/(n-1)!.

Use the qualified MVM convention at Q²=1:
Abar=-x/e+x(logx-1)+e*x[-1-zeta2/2+logx-logx²/2]+O(e²),
J111=-(x+y+z)/(2e²)
 +[A0(x)+A0(y)+A0(z)-(x+y+z)/2]/e
 +I(x,y,z)+Ae(x)+Ae(y)+Ae(z)+O(e).

Expand4/D through e² when multiplying double poles. Retain ALL factorized
products and positive-epsilon tadpoles; unlike SCP1's sixfold derivative,
the undifferentiated integral does NOT annihilate them. I derivatives through
third order suffice. This is an absolute neutral comparison against the
qualified finite master, not a derivative test blind to finite constants.
The MVM implementation, normalization and shared physical inputs are inherited;
their reuse does not independently validate the underlying model.
