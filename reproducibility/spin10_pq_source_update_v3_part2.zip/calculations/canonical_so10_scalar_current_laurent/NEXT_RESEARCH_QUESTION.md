# Next: actual current-loop UV operators and the matching forest

SCL1 supplies the bare Laurent function of the positive-heavy four-singlet
U1 restriction, with absolute finite constants checked. It is not a finite
renormalized amplitude. Do not rerun completed integrations or add them to
the known subtotal before supplying their actual subtractions. Preserve both
failed runs, V2 numeric evidence and the final V3 receipt.

Primary next question: derive the three opened one-loop UV subgraph kernels
of the literal VSS action in this same restriction. Sunset two-edge subgraphs
overlap, so their pole insertions cannot be treated as a product of disjoint
counterterms. Keep the real-field Wick/multiplicity normalization from SCP1.

Use measured vertices and projectors to compute scalar two-point derivative
and mass operators, and vector two-point derivative, mass AND background
curvature operators. A flat mass/kinetic answer alone does not close the
background F2 forest. Preserve the closed-loop pole at D0 and the full
D=4-2epsilon dependence of the remaining trace. A positive-heavy trace can
use the qualified heat/width Ward reductions in their actual scopes.

The restricted four-scalar current matrices need not constitute a full
Spin(10) representation. In particular, projecting the parent quartic
P rho_a rho_b P differs from (P rho_a P)(P rho_b P) when intermediate states
outside P contribute. Do not invent a closed four-field theory or silently
replace the parent seagull. A minimal-operator diagnostic can help derive
current-bubble terms only if its seagull difference is kept explicitly.
Recover the actual contraction from the action, not from the pole that
would cancel SCL1. QMV1's full scalar-loop mass zero is not automatically
the zero of this restricted graph or scalar subset.

After actual subgraph insertions are established, test locality and mass
dependence of the remaining overall F2 pole. It need not be zero: a local
overall renormalization is distinct from a symmetry obstruction. Do not fit
it to favorable gauge matching or unlock the blocked H-basic construction.
Coordinate with VSP1 exactly once: R_VVSS+(C_parent-C_VVSS). Full parent CT
must not be placed independently on each primitive.

Secondary scope/completeness question: the recorded light-vector routes are
neutral under the external U1. With two positive scalar masses, qv0 removes
the vector spin/curvature powers that could worsen the soft denominator.
The undifferentiated momentum integrand may then be locally IR integrable
even with one vector mass0; this must be PROVED for its actual vertex terms.
It is not a statement about differentiated zero-mass masters, other scalar
sectors, multiple light edges or the full family. The positive-mass Taylor
algorithm assumes M0>0 and cannot simply accept M0=0 without a new endpoint
analysis. Qualified MVM zero-mass formulas may assist a properly bounded
continuation. Do not declare the whole massless-vector amplitude scaleless
or zero; all-hard and soft momentum regions still require a matching account.

Select new work for its indispensable role in the actual renormalized C1
construction. No more giant coefficient expansion is justified merely by
remaining component count. Keep g/r/scale and finite normalization freedoms
symbolic. General-width checks, full328 scalar contraction, the other loop
families, nonlinear matching and physical viability remain separate. No
state/foundation/point/scheme/refit, remote/publication or blocked-stage change.
