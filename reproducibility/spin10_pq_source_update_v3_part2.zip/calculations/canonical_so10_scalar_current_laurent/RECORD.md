# SCL1 prospective undifferentiated scalar-current Laurent calculation

The endpoint logarithmic-pole coefficient is also integrated exactly in the
remaining projective variable. Its analytic value fixes the double-pole
coefficient only after native quadrature independently agrees. Retain both
the raw numerical residue and exact coefficient; canonical exact zeros are
not cutoff declarations or silently truncated evidence.

Base559a9761325b728eb1dcb3077706cd7886d6b292/main, state113/34of39 unchanged.
Question: determine the actual bare double pole, simple pole and finite
coefficient for the complete POSITIVE-HEAVY four-singlet restriction of VSS,
as a function of its retained mass ratio. This is the next amplitude input,
not the renormalized full sunset, full C1, a physical unification prediction
or a restoration theorem. Full operator UV forests and light/EFT matching
remain separately required; do not fit them from the bare remainder.

Use SCP1's authenticated P2(D), actual720 vertices/80 weights and corrected
N_e=exp(2gamma_E e)(Qscale²)^(2e). No action/point/width/g/scale/finite scheme
change. r=mH²/[(3/2)g10²]>0 stays symbolic. Its three weighted positive-heavy
channels are neutral physical(r,r,1), neutral Goldstone(1/5,1/5,1), charged
physical/Goldstone(5r,1,1), with measured color sums1/5,9/5,4. All relative
couplings and scales remain consistent. Massless assignments and the other
324 scalar directions are not silently zero or covered by this restriction.

Before science freeze sources, assumptions, expected evidence, all immutable
inputs and Git tree. Two sequential independent geometry routes: six ordered
largest-time sectors versus three largest-time sectors each split into a
radial triangle plus its finite complement. Derive exact Jacobians and area
coverage. New endpoint subtraction is a meromorphic integral identity, NOT
a physical UV counterterm chosen from a desired cancellation.

Extract k0/(e-1),k1/e and regular remainder from k=aP2*H^(-2+e)*M^(-2e).
Keep through e² in k1, through e¹ in regular pieces and the restored Gamma/
measure. Add exact Taylor subtraction of degree12(primary)/10(replay) with
every analytic monomial retained. Use independent binomial/quotient Taylor
recurrences. Preserve the power-sensitive k0 term and all evanescent pieces.

The integral representation must retain arbitrary positive r, with each
numerical use required to pass convergence. Native tests at r=1,2 are
diagnostics, not physical parameter adoption. Neutral-Goldstone shared case
is evaluated once per route. Working80digits/report20; Gauss48/80/128; scaled
last-order agreement1e-22, cross-route1e-20. No uniform numerical guarantee
at untested extreme r. Do not weaken tolerances or silently truncate a tail.

Independent absolute neutral check: derive general-D Fourier numerator
reduction to bare scalar sunset derivatives and tadpole products BEFORE
Laurent expansion. Evaluate the finite master using the qualified MVM
function, not the new proper-time kernel. Include all factorized products,
bare finite A_e terms and D-positive powers. Distinct verifier must check
both neutral channels against it and check scales, poles and controls.
Charged independent sectorization shares SCP1's heat premise; no new charged
momentum derivation or independent physical scientist is claimed.

Caps: geometry native300s each, numerical native600s each, separate verifier
600s;8GiB sampled private memory,350MiB launch floor,new package<=4MiB.
Dependent numerics only after both geometries complete; verifier only after
all completed outputs are frozen. Exclusive captures and receipts; preserve
failed/incomplete sources, runs and explicit classifications. No subagents.

Controls: omitted/repeated sector, Jacobian, k0 power term, wrong Gamma/scale
factor, dropped e/D terms, missing scalar-vertex piece, wrong Taylor-restoration
term, omitted bare A_e product. Record insensitive projections, not just a
passing total. Nonzero poles are not anomalies or renormalized predictions.

Acceptance: complete measured bare Laurent coefficient for the stated
positive-heavy restriction; independent sector and neutral absolute master
agreement; exact symbolic scale/pole relations and meaningful controls;
qualified/incomplete/refuted disposition without authority promotion.
Shared action, masses, SCP heat kernel, SM frame, software/AI remain limits.
No old evidence edits, main change, protected promotion, blocked-stage/flavor
activation, point refit, push/publication. e4 is historical authentication;
custody exit2/seven is not PASS. Goal remains active/incomplete.
