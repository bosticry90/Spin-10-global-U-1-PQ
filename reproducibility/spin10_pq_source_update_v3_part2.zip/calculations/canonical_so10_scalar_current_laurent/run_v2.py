"""SCL1 corrected native calculation and separate validator; no V1 mutation."""
from pathlib import Path
from hashlib import sha256
import json,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-laurent-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def auth(p):
    for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
def resource(c):
    assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
    assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['private_allocation_limit_bytes']==8*1024**3
    assert c['all_resource_samples'] and all(0<x['private_bytes']<=8*1024**3 for x in c['all_resource_samples'])
def one(role,kind):
    argv=[sys.executable,'-B',str(HERE/(kind+'.py'))]+([] if kind=='verify_v2' else [role])
    c=capture(argv);name=role+'_'+kind;dump(HERE/(name+'_capture.json'),c);dump(CONTROL/(name+'_full_capture.json'),c)
    if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
    resource(c);rs=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rs)==1
    v=rs[0];assert v['elapsed_after_imports']<600
    dump(HERE/('validation_receipt_v2.json' if kind=='verify_v2' else name+'_result.json'),v)
    print(name,'COMPLETED',v['elapsed_after_imports'],flush=True)
prep=json.loads((HERE/'preparation_v2.json').read_bytes());auth(prep)
names=list(map(Path,prep['input_sha256']))+[HERE/'preparation_v2.json']
if sys.argv[1]=='numeric':
    vp={'schema':'SCL1_NUMERIC_PREPARATION_V2','input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
    dump(HERE/'numeric_preparation_v2.json',vp);auth(vp);one('primary','numeric_v2');one('replay','numeric_v2')
else:
    assert sys.argv[1]=='validate';names.append(HERE/'numeric_preparation_v2.json')
    for role in ['primary','replay']:
        resource(json.loads((HERE/(role+'_numeric_v2_capture.json')).read_bytes()))
        names += [HERE/(role+'_numeric_v2'+suf) for suf in ['_capture.json','_result.json','_tables.json.gz']]
    vp={'schema':'SCL1_VALIDATION_PREPARATION_V2','input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
    dump(HERE/'validation_preparation_v2.json',vp);auth(vp);one('validation','verify_v2')
