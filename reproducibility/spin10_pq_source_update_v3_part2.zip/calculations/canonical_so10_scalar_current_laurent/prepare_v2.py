"""Freeze delegated SCL1 implementation correction with exact failed evidence."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
def dump(p,b):
    with p.open('xb') as out:out.write(b)
old=json.loads((HERE/'preparation.json').read_bytes());deps=dict(old['input_sha256'])
for n,h in deps.items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==old['base_commit']
fail=json.loads((HERE/'primary_numeric_capture.json').read_bytes())
assert fail['execution_state']=='FAILED' and fail['exit_code']==1
assert 'LAURENT_NOT_CONVERGED' in fail['stdout_and_stderr'] and 'neutral_physical_r2' in fail['stdout_and_stderr']
for name in ['preparation.json','numeric_preparation.json','primary_numeric_capture.json']:
    p=HERE/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for role in ['primary','replay']:
    for suffix in ['_capture.json','_result.json','_tables.json.gz']:
        p=HERE/(role+'_geometry'+suffix);deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['numeric_v2.py','verify_v2.py','prepare_v2.py','run_v2.py','IMPLEMENTATION_CORRECTION_V2.md']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb)
    dump(HERE/(name+'.source.txt'),bb)
    for q in [p,HERE/(name+'.source.txt')]:deps[str(q)]=sha256(q.read_bytes()).hexdigest()
value={'schema':'SCL1_PREPARATION_V2','input_sha256':dict(sorted(deps.items())),
 'base_commit':old['base_commit'],'native_seconds':600,'verifier_seconds':600,
 'private_sample_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_cap':4*1024**2,
 'failed_v1_preserved':True,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation_v2.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode());print('V2_FROZEN',len(deps),'bindings;failedV1unchanged')
