"""SCL1 two genuinely different full projective decompositions."""
from data import *
def main():
    start=begin();role=sys.argv[1];assert role in ['primary','replay']
    old=packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz');P=expr(old['P2']);v=[st,tt,ut]
    # Verify the actual positive-heavy restriction has exactly these routes.
    actual={(r,i,j):s.sympify(z) for r,i,j,z,q in old['weights'] if r>0 and z!='0'}
    groups={'neutral_physical':[(2,0,3),(2,3,0)],'neutral_Goldstone':[(2,1,2),(2,2,1)],'charged':[(1,0,2),(1,2,0),(1,1,3),(1,3,1)]}
    assert set(sum(groups.values(),[]))==set(actual)
    color={k:s.factor(sum(actual[ij] for ij in triples)) for k,triples in groups.items()}
    assert color=={'neutral_physical':s.Rational(1,5),'neutral_Goldstone':s.Rational(9,5),'charged':s.Integer(4)}
    output={}
    for family,charges in [('neutral',[-1,1,0]),('charged',[-2,1,1])]:
        pk=P.subs({q1:charges[0],q2:charges[1],qv:charges[2]});rows=[]
        orders=list(itertools.permutations(range(3))) if role=='primary' else [(0,1,2),(1,0,2),(2,0,1)]
        for order in orders:
            if role=='primary':
                shape=[None]*3;shape[order[0]]=1;shape[order[1]]=a;shape[order[2]]=a*b
                H0,H1=1+b,b;mode='UV'
            else:
                shape=[None]*3;shape[order[0]]=1;shape[order[1]]=a*b;shape[order[2]]=a*(1-b)
                H0,H1=1,b*(1-b);mode='UV'
            H=H0+a*H1;sub=dict(zip(v,shape));F=clean(a*pk.subs(sub,simultaneous=True)/H**2)
            p0=clean(F.subs(D,4));p1=clean(-2*s.diff(F,D));n0=clean(p0*H**4);n1=clean(p1*H**4)
            assert s.denom(n0).has(a)==False and s.denom(n1).has(a)==False
            N0=s.Poly(n0,a);N1=s.Poly(n1,a)
            assert N0.degree()<=8 and N1.degree()<=8
            assert clean(p0-n0/H**4)==0 and clean(p1-n1/H**4)==0
            assert s.denom(p0).subs(a,0)!=0 and s.denom(p0).subs(b,0)!=0
            endpoint=clean(N0.nth(1)/H0**4-4*H1*N0.nth(0)/H0**5)
            exact_endpoint=s.simplify(s.integrate(endpoint,(b,0,1)))
            assert not exact_endpoint.has(s.Integral)
            rows.append({'kind':mode,'order':list(order),'shape':list(map(str,shape)),
              'endpoint_log_density':str(endpoint),'exact_Iminus1':str(exact_endpoint),
              'H0':str(H0),'H1':str(H1),'n0':list(map(str,reversed(N0.all_coeffs()))),'n1':list(map(str,reversed(N1.all_coeffs())))})
            if role=='replay':
                outside=[None]*3;outside[order[0]]=1;outside[order[1]]=a;outside[order[2]]=1-a+a*b
                sub=dict(zip(v,outside));U=clean((st*tt+st*ut+tt*ut).subs(sub,simultaneous=True))
                F=clean(a*pk.subs(sub,simultaneous=True)/U**2)
                rows.append({'kind':'REGULAR','order':list(order),'shape':list(map(str,outside)),
                  'U':str(U),'w0':str(clean(F.subs(D,4))),'w1':str(clean(-2*s.diff(F,D)))})
        output[family]=rows;print('STAGE geometry_'+family,flush=True)
    area=s.Rational(6,12) if role=='primary' else 3*(s.Rational(1,8)+s.Rational(1,24));assert area==s.Rational(1,2)
    save(role,'geometry',{'schema':'SCL1_GEOMETRY','decomposition':'ordered6' if role=='primary' else 'triangle3_and_complement3',
      'rows':output,'color_weights':{k:str(v) for k,v in color.items()},'simplex_area':str(area),
      'exact_Iminus1':{k:str(s.simplify(sum(s.sympify(r['exact_Iminus1']) for r in rows if r['kind']=='UV'))) for k,rows in output.items()},
      'Taylor_degree':12 if role=='primary' else 10,'arbitrary_positive_r_retained':True,
      'renormalized_finite_sunset_or_C1_qualified':False},start)
if __name__=='__main__':main()
