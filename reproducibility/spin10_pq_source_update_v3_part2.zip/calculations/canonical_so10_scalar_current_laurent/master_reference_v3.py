"""SCL1 independent absolute neutral general-D momentum numerator reduction."""
from data import *
sys.path.insert(0,str(CAL/'canonical_so10_vacuum_master_pilot'))
from masters_v2 import sunset
x,y,z,e=s.symbols('x y z e',positive=True);I=s.Function('I')(x,y,z)
@lru_cache(None)
def formula(variant='base'):
    A0=lambda v:v*(s.log(v)-1)
    Ae=lambda v:v*(-1-s.zeta(2)/2+s.log(v)-s.log(v)**2/2)
    J=-(x+y+z)/(2*e**2)+(sum(A0(v) for v in [x,y,z])-(x+y+z)/2)/e+I+sum(Ae(v) for v in [x,y,z])
    def tad(v,n):return (-1)**(n-1)*s.diff(-v/e+A0(v)+(0 if variant=='no_Ae_products' else e*Ae(v)),v,n-1)/s.factorial(n-1)
    def master(aa,bb,cc):
        ns=[aa,bb,cc];vs=[x,y,z]
        if 0 in ns:
            return s.prod(tad(v,n) for v,n in zip(vs,ns) if n)
        orders=[n-1 for n in ns];out=J
        for v,n in zip(vs,orders):out=s.diff(out,v,n)
        return (-1)**sum(orders)*out/s.prod(s.factorial(n) for n in orders)
    F=1 if variant=='D4' else 4/(4-2*e);Ax=F-1;k=z-2*x-2*y;Jm=master
    out=Ax*(2*Jm(2,1,1)+2*Jm(1,2,1)+k*(Jm(3,1,1)+Jm(1,3,1))+2*Jm(3,0,1)+2*Jm(0,3,1)-Jm(3,1,0)-Jm(1,3,0))
    out-=F*(x*(2*Jm(3,1,1)+k*Jm(4,1,1)+2*Jm(4,0,1)-Jm(4,1,0))+y*(2*Jm(1,3,1)+k*Jm(1,4,1)+2*Jm(0,4,1)-Jm(1,4,0)))
    if variant!='no_vertex':out+=F*(Jm(2,2,0)-Jm(1,2,1)-Jm(2,1,1)+(x+y-z)*Jm(2,2,1))
    # Replace finite master derivatives BEFORE series: SymPy collect() cannot
    # handle multivariate Derivative atoms, which are e-independent coefficients.
    atoms=sorted(out.atoms(s.Derivative),key=str);mapping={};ders=[]
    for j,atom in enumerate(atoms):
        powers=dict(atom.variable_count);idx=tuple(int(powers.get(v,0)) for v in [x,y,z]);assert 1<=sum(idx)<=3
        token=s.Symbol('I'+''.join(map(str,idx)));mapping[atom]=token;ders.append((idx,token))
    series=s.series(out.xreplace(mapping),e,0,1).removeO().expand();coeff=[s.simplify(series.coeff(e,p)) for p in [-2,-1,0]]
    assert not any(v.has(s.Derivative) or v.has(I) for v in coeff)
    return coeff,ders
@lru_cache(None)
def imaster_derivative(values,idx):
    vals=tuple(map(mp.mpf,values));return mp.diff(lambda X,Y,Z:sunset(X,Y,Z,q2=1,method='dilog'),vals,idx)
def evaluate(values,variant='base'):
    coeff,ders=formula(variant);env={v:s.Float(mp.nstr(m,85),85) for v,m in zip([x,y,z],values)}
    for idx,token in ders:
        value=imaster_derivative(tuple(map(str,values)),idx);env[token]=s.Float(mp.nstr(value,85),85)
    result=[mp.mpf(str(s.N(v.subs(env),75))) for v in coeff]
    return result
