"""SCL1 convergent endpoint remainders with exact analytic restoration."""
from data import *
@lru_cache(None)
def grid(n):
    out=[]
    with mp.workdps(95):
        for j in range(1,n//2+1):
            x=mp.cos(mp.pi*(mp.mpf(j)-mp.mpf('.25'))/(n+mp.mpf('.5')))
            for it in range(40):
                pn=mp.legendre(n,x);der=n*(x*pn-mp.legendre(n-1,x))/(x*x-1);dx=pn/der;x-=dx
                if abs(dx)<mp.mpf('1e-85'):break
            else:raise ArithmeticError('GAUSS_NODE_FAILURE')
            der=n*(x*mp.legendre(n,x)-mp.legendre(n-1,x))/(x*x-1);w=1/((1-x*x)*der*der)
            out += [((1-x)/2,w),((1+x)/2,w)]
    for k in [0,1,2,5,2*n-1]:assert abs(mp.fsum(w*x**k for x,w in out)-mp.mpf(1)/(k+1))<mp.mpf('1e-70')
    return sorted(out)
def horner(co,x):
    value=mp.mpf(0)
    for c in reversed(co):value=c+x*value
    return value
def fexpr(z,args):return s.lambdify(args,expr(z),modules='mpmath',cse=True)
def compile_row(row):
    r=dict(row)
    if row['kind']=='UV':
        r['fH0']=fexpr(row['H0'],b);r['fH1']=fexpr(row['H1'],b)
        r['fn0']=s.lambdify(b,list(map(expr,row['n0'])),modules='mpmath',cse=True)
        r['fn1']=s.lambdify(b,list(map(expr,row['n1'])),modules='mpmath',cse=True)
    else:
        r['fw0']=fexpr(row['w0'],(a,b));r['fw1']=fexpr(row['w1'],(a,b));r['fU']=fexpr(row['U'],(a,b))
    return r
def jets(nn,H0,H1,N,role):
    if role=='primary':
        ratio=-H1/H0
        return [mp.fsum(nn[j]*mp.mpf((k-j+3)*(k-j+2)*(k-j+1))/6*ratio**(k-j)/H0**4 for j in range(min(k,len(nn)-1)+1)) for k in range(N+1)]
    den=[H0**4,4*H0**3*H1,6*H0**2*H1**2,4*H0*H1**3,H1**4];out=[]
    for k in range(N+1):out.append(((nn[k] if k<len(nn) else 0)-mp.fsum(den[j]*out[k-j] for j in range(1,min(k,4)+1)))/den[0])
    return out
def one_row(row,masses,n,N,role,decomposition):
    g=grid(n);total=[mp.mpf(0)]*3;control=[mp.mpf(0)]*4;dom,j,k=row['order']
    if row['kind']=='REGULAR':
        for av,aw in g:
            for bv,bw in g:
                shape=[0,0,0];shape[dom]=1;shape[j]=av;shape[k]=1-av+av*bv
                M=mp.fsum(m*x for m,x in zip(masses,shape));U=row['fU'](av,bv);v0=row['fw0'](av,bv);v1=row['fw1'](av,bv)
                L=mp.log(U)-2*mp.log(M);weight=aw*bw
                total[1]+=weight*v0;total[2]+=weight*(v1+v0*L)
                # e coefficient omitted by a premature D4 mutation.
                control[3]+=weight*v1
        return total,control
    for bv,bw in g:
        H0,H1=row['fH0'](bv),row['fH1'](bv);nn0,nn1=row['fn0'](bv),row['fn1'](bv)
        M0=masses[dom];M1=(masses[j]+bv*masses[k]) if decomposition=='ordered6' else (bv*masses[j]+(1-bv)*masses[k])
        assert H0>0 and M0>0 and M1>0
        v0=jets(nn0,H0,H1,N,role);v1=jets(nn1,H0,H1,N,role)
        L=[mp.log(H0)-2*mp.log(M0)]+[(-1)**(p+1)*((H1/H0)**p-2*(M1/M0)**p)/p for p in range(1,N+1)]
        ke1=[v1[p]+mp.fsum(v0[j]*L[p-j] for j in range(p+1)) for p in range(N+1)]
        k1e2=v1[1]*L[0]+v1[0]*L[1]+v0[1]*L[0]**2/2+v0[0]*L[0]*L[1]
        restore0=mp.fsum(v0[p]/(p-1) for p in range(2,N+1))
        restore1=mp.fsum(ke1[p]/(p-1)-v0[p]/(p-1)**2 for p in range(2,N+1))
        Iminus=v0[1];I0=-v0[0]+ke1[1]+restore0
        I1=-v0[0]-ke1[0]+k1e2+restore1
        D0=v1[1];D1=-v1[0]+v1[1]*L[0]+v1[0]*L[1]+mp.fsum(v1[p]/(p-1) for p in range(2,N+1))
        for av,aw in g:
            H=H0+av*H1;M=M0+av*M1
            vv0=horner(nn0,av)/H**4;vv1=horner(nn1,av)/H**4;LL=mp.log(H)-2*mp.log(M)
            rem0=vv0-horner(v0,av);rem1=vv1+vv0*LL-horner(ke1,av)
            I0+=aw*rem0/av**2;I1+=aw*(rem1+mp.log(av)*rem0)/av**2
            D1+=aw*(vv1-horner(v1,av))/av**2
        vals=[Iminus,I0,I1]
        for j,z in enumerate(vals):total[j]+=bw*z
        # I0/I1 pieces lost by deleting k0/(e-1), and I0/I1 changes from D4.
        control[0]+=bw*(-v0[0]);control[1]+=bw*(-v0[0]-ke1[0]);control[2]+=bw*D0;control[3]+=bw*D1
    return total,control
def evaluate(tab,family,masses,n,N,role):
    assert len(masses)==3 and all(mp.mpf(m)>0 for m in masses),'POSITIVE_MASSES_REQUIRED'
    rows=[compile_row(row) for row in tab['rows'][family]];values=[];controls=[]
    for row in rows:
        val,con=one_row(row,masses,n,N,role,tab['decomposition']);values.append(val);controls.append(con)
    v=[mp.fsum(row[j] for row in values) for j in range(3)]
    exact=mp.mpf(str(s.N(s.sympify(tab['exact_Iminus1'][family]),90)))
    assert abs(v[0]-exact)<mp.mpf('1e-60')*(1+abs(exact))
    bare=[exact/2,v[1]/2,v[2]/2+mp.zeta(2)*exact]
    con=[mp.fsum(row[j] for row in controls) for j in range(4)]
    return bare,values,{'omitted_k0_change_p1':nf(-con[0]/2),'omitted_k0_change_finite':nf(-con[1]/2),
      'premature_D4_change_p1':nf(-con[2]/2),'premature_D4_change_finite':nf(-con[3]/2),
      'missing_Gamma_zeta2_finite_change':nf(-mp.zeta(2)*exact),'raw_Iminus1':nf(v[0]),'exact_Iminus1':str(tab['exact_Iminus1'][family])}
def converged(tab,family,masses,N,role,label):
    history=[]
    for n in [48,80,128]:
        val,sector,con=evaluate(tab,family,masses,n,N,role);history.append({'order':n,'bare':list(map(nf,val))})
        print('STAGE '+label+'_gauss_'+str(n),flush=True)
    x,y=[list(map(mp.mpf,h['bare'])) for h in history[-2:]]
    err=max(abs(u-v)/(1+abs(v)) for u,v in zip(x,y));assert err<mp.mpf('1e-22'),('LAURENT_NOT_CONVERGED',label,nf(err))
    return val,sector,con,history,err
def main():
    start=begin('numeric_preparation.json',600);role=sys.argv[1];assert role in ['primary','replay'];mp.mp.dps=80
    tab=packed(HERE/(role+'_geometry_tables.json.gz'));N=tab['Taylor_degree'];rows={};histories={};controls={};full_values={}
    cases=[('neutral_physical_r1','neutral',[1,1,1]),('neutral_physical_r2','neutral',[2,2,1]),
      ('neutral_Goldstone','neutral',[mp.mpf(1)/5,mp.mpf(1)/5,1]),
      ('charged_r1','charged',[5,1,1]),('charged_r2','charged',[10,1,1])]
    for name,family,masses in cases:
        val,lastvalues,con,history,err=converged(tab,family,masses,N,role,name);full_values[name]=val
        rows[name]={'base_p2_p1_f0':[mp.nstr(z,20) for z in val],'masses':list(map(nf,masses)),'last_scaled_change':mp.nstr(err,15),
          'per_sector_Iminus1_I0_I1':[[nf(z) for z in row] for row in lastvalues]}
        histories[name]=history;controls[name]=con
    totals={}
    for r in [1,2]:
        pn=full_values['neutral_physical_r'+str(r)];pg=full_values['neutral_Goldstone'];pc=full_values['charged_r'+str(r)]
        ln5=mp.log(5);pc=[pc[0],pc[1]+2*ln5*pc[0],pc[2]+2*ln5*pc[1]+2*ln5**2*pc[0]]
        total=[mp.mpf(18)/25*pn[j]+mp.mpf(81)/50*pg[j]+mp.mpf(18)/5*pc[j] for j in range(3)]
        totals[str(r)]=[mp.nstr(z,20) for z in total]
    save(role,'numeric',{'schema':'SCL1_NUMERIC','decomposition':tab['decomposition'],'Taylor_degree':N,
      'cases':rows,'histories':histories,'controls':controls,'weighted_total_P2_P1_F0_base_jN0':totals,
      'arbitrary_positive_r_algorithm':True,'scale_formula':'g²[P2/e²+(P1+2jN P2)/e+F0+2jN P1+2jN²P2]; jN=L-logg²+log40',
      'working_digits':80,'reporting_digits':20,'renormalized_finite_sunset_C1_qualified':False},start)
if __name__=='__main__':main()
