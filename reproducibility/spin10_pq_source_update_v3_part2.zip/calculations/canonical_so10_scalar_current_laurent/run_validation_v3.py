"""Freeze/capture the V3 absolute-master verifier without altering V1/V2 evidence."""
from pathlib import Path
from hashlib import sha256
import ast,json,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-laurent-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
vp=json.loads((HERE/'validation_preparation_v2.json').read_bytes());deps=dict(vp['input_sha256'])
for n,h in deps.items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
c=json.loads((HERE/'validation_verify_v2_capture.json').read_bytes());assert c['execution_state']=='FAILED' and c['exit_code']==1
assert 'Improve MV Derivative support in collect' in c['stdout_and_stderr']
for name in ['validation_preparation_v2.json','validation_verify_v2_capture.json']:
    p=HERE/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['master_reference_v3.py','verify_v3.py','run_validation_v3.py','VERIFIER_CORRECTION_V3.md']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb)
    q=HERE/(name+'.source.txt')
    with q.open('xb') as out:out.write(bb)
    for f in [p,q]:deps[str(f)]=sha256(f.read_bytes()).hexdigest()
dump(HERE/'validation_preparation_v3.json',{'schema':'SCL1_VALIDATION_PREPARATION_V3','input_sha256':dict(sorted(deps.items())),
 'seconds':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes_cap':4*1024**2,
 'failed_native_V1_and_verifier_V2_preserved':True,'scientific_acceptance':'NOT_PERFORMED'})
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'verify_v3.py')]);dump(HERE/'validation_verify_v3_capture.json',c);dump(CONTROL/'validation_verify_v3_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
assert c['launch']['memory']['available_pagefile']>=350*1024**2
rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
v=rows[0];assert v['elapsed_after_imports']<600;dump(HERE/'validation_receipt_v3.json',v)
print(json.dumps({'execution_state':v['execution_state'],'status':v['status'],'elapsed_after_imports':v['elapsed_after_imports'],
 'sector_route_scaled_error':v['sector_route_scaled_error'],'absolute_neutral_master_scaled_error':v['absolute_neutral_master_scaled_error']},sort_keys=True),flush=True)
