# Reconcile legacy replay convention metadata explicitly

The original primary completed all four groups. Original replay FAILED exit1
after its full field-frame check because full_replay.json lacks the textual
convention object present in full_primary.json. Its mathematical matrices,
metric and representation data are present. Sources,manifests and failed
complete captures remain unchanged; no replay result exists for V1.

V2 explicitly binds the frozen primary convention metadata and first requires
the replay's complete plane map,gauge metric,representation digests,ALL actual
representation matrices and scalar dimensions to equal those in that record.
The replay's own full scalar-source/kinetic correspondence,all coordinate maps,
action-derived Hessians,inverse domains and normalizations remain required.
The earlier qualified half-norm AST theorem applies to these same matrices.
No convention is supplied by an unverified default and no scientific assertion
is skipped. The shared primary metadata dependency is disclosed.

Only metadata lookup/versioned source and I/O paths change. Preserve and reuse
the successful primary;launch only corrected replay. Same180sec-after-imports/
8GiB/min350MiB available-commit limits,all original mathematical checks and
scope ceiling. Independent verification must authenticate the shared metadata
and own replay matrices,not count the shared text as independent physics.

Preflight now checks this legacy metadata asymmetry. Its omission was an
avoidable schema-planning error,similar to earlier legacy-field mistakes;
the failure does not demonstrate a tensor or physical-theory mismatch.
