"""Actual field-frame kinetic/orbit/ghost Hessians;no new pole contraction."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import importlib.util,json,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
p=load('qualified_full_scalar_field_maps',OUT.parent/'canonical_so10_ghost_mass_g4_pole/pole_v2.py');e=p.e;s=p.s;read=p.read;digest=p.digest;PKG=p.PKG;ZERO=p.ZERO;ONE=p.ONE;II=p.II;num=p.num;put=p.put;smul=p.smul;transpose=p.transpose;ANTI=p.ANTI;AUX=p.AUX
def auth(folder,name,receipt='validation_receipt.json'):
 q=OUT.parent/folder/name;r=read(q.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(q)]==digest(q);return read(q)
def packed(A):return [[*k,p.text(z)] for k,z in sorted(A.items())]
def unpack(rows):return {tuple(row[:-1]):num(row[-1]) for row in rows}
@lru_cache(None)
def scalar_coefficient(txt):
 g=s.Symbol('g10');co=s.sympify(txt);z=s.cancel(co/g);assert not z.free_symbols and not z.has(s.Float) and s.expand(co-z*g)==0;return num(str(z))
def coef_hash(A):return digest_bytes([[*k,[[m,v.numerator,v.denominator] for(a,b,m),v in sorted(z.cells.items()) if a==b==0]] for k,z in sorted(A.items())])
def digest_bytes(z):return __import__('hashlib').sha256(json.dumps(z,separators=(',',':')).encode()).hexdigest()
def canon(word):
 if len(set(word))!=len(word):return (),0
 return tuple(sorted(word)),(-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])
def raw_densities(rows,scalar):
 X={};Q={};R={}
 for row in rows['X']:
  ns=row['word'];l=next(n for n in ns if n in AUX);a=next(n for n in ns if n in ANTI);c=next(n for n in ns if n.startswith('C'));put(X,(AUX.index(l),ANTI.index(a),int(c[1:])),num(row['stripped_coefficient'])*(1 if ns.index(a)<ns.index(c) else -1))
 for tag,base in [('Q',Q),('R',R)]:
  for row in rows[tag]:
   w=tuple(45+ANTI.index(n) if n in ANTI else int(n[1:]) for n in row['word']);w,sg=canon(w);assert sg;put(base,w,num(row['stripped_coefficient'])*sg)
 return X,Q,R
def pull4(P,images,route):
 result={}
 if route=='primary':
  for word,z in P.items():
   layer={():z}
   for n in word:
    nxt={}
    for pref,u in layer.items():
     for v,c in images[n].items():w,sg=canon(pref+(v,));put(nxt,w,u*c*sg) if sg else None
    layer=nxt
   for w,c in layer.items():put(result,w,c)
 else:
  @lru_cache(None)
  def pair(a,b):
   out={}
   for i,z in images[a].items():
    for j,v in images[b].items():w,sg=canon((i,j));put(out,w,z*v*sg) if sg else None
   return tuple(out.items())
  # Explicit exterior-square product;all raw terms have C,C,a,a order.
  staged=defaultdict(dict)
  for(a,b,c,d),z in P.items():
   assert a<b<45 and 45<=c<d<90
   for left,u in pair(a,b):put(staged[c,d],left,z*u)
  for(c,d),A in staged.items():
   for right,v in pair(c,d):
    for left,u in A.items():w,sg=canon(left+right);put(result,w,u*v*sg) if sg else None
 return result
def pull3(P,L,A,C,route):
 out={}
 if route=='primary':
  for(l,a,c),z in P.items():
   for j,x in L[l].items():
    for b,y in A[a].items():
     for d,v in C[c].items():put(out,(j,b,d),z*x*y*v)
 else:
  middle=defaultdict(dict)
  for(l,a,c),z in P.items():
   for d,v in C[c].items():put(middle[l],(a,d),z*v)
  stage=defaultdict(dict)
  for l,T in middle.items():
   for(a,d),z in T.items():
    for b,v in A[a].items():put(stage[l],(b,d),z*v)
  for l,T in stage.items():
   for j,v in L[l].items():
    for(b,d),z in T.items():put(out,(j,b,d),z*v)
 return out
def rho_bridge(data,e2,ir,tr,scalar):
 C={(a,int(n[2:])):z for a in range(45) for n,z in ir[f'C{a}'].items()};QQ={(i,j):num(z) for i,j,z in data['C3_plane_to_parent']['entries']};metric={(i,j):num(z) for i,j,z in data['parent_gauge_metric']['entries']};S=smul(QQ,C);Id={(i,i):ONE for i in range(45)};assert smul(transpose(QQ),QQ)==metric and smul(transpose(S),S)==Id and all(not any(m&8 for(a,b,m),v in z.cells.items()) for z in S.values())
 for mu in range(4):assert {(a,int(n[2:].split('_')[0])):z for a in range(45) for n,z in ir[f'B{a}_{mu}'].items()}==C
 byplane=defaultdict(list)
 for(a,b),z in S.items():byplane[a].append((b,z))
 expected={};parent={}
 for sec,ms in data['representation_matrices'].items():
  for a,M in enumerate(ms):
   for i,j,co in M['entries']:
    ii,jj=scalar[f'x_{sec}_{i}'],scalar[f'x_{sec}_{j}'];z=num(co);put(parent,(a,ii,jj),z)
    for b,v in byplane[a]:put(expected,(b,ii,jj),z*v)
 actual={};rawQ={};g=s.Symbol('g10')
 for n,i in scalar.items():
  for row in e2['complete_columns'][n]['source_polynomial']:
   w=row['word'];assert len(w)==2 and all('__' not in t for t in w);c=next(t for t in w if t.startswith('C'));x=next(t for t in w if t in scalar);v=scalar_coefficient(row['coefficient']);a=int(c[1:]);put(rawQ,(a,i,scalar[x]),v)
   for b,u in ir[c].items():put(actual,(int(b[2:]),i,scalar[x]),-v*u)
 assert expected==actual;assert all(z==-actual.get((a,j,i),ZERO) for(a,i,j),z in actual.items());assert all(not any(m&8 for(aa,bb,m),v in z.cells.items()) for z in actual.values())
 back={};adj=defaultdict(list)
 for(a,b),z in S.items():adj[b].append((a,z))
 for(b,i,j),z in actual.items():
  for a,v in adj[b]:put(back,(a,i,j),z*v)
 assert back==parent;rawback={}
 for(b,i,j),z in actual.items():
  for n,v in tr[f'Cp{b}'].items():put(rawback,(int(n[1:]),i,j),-z*v)
 assert rawback==rawQ;return S,actual,parent,rawQ
def hessian(density,mode,route,even_moved=False,wrong_even=False):
 # Typed variables use actual physical indices:scalar180+x,L508+l,odd553+f.
 out={}
 for key,z in density.items():
  if mode=='X':l,a,c=key;word=[(508+l,0),(598+a,1),(553+c,1)]
  elif mode=='Y':x,a,c=key;word=[(180+x,0),(598+a,1),(553+c,1)]
  else:word=[(553+n,1) for n in key]
  if even_moved and mode in ['X','Y']:word=[word[1],word[0],word[2]]
  for i,(ni,pi) in enumerate(word):
   for j,(nj,pj) in enumerate(word):
    if i==j:continue
    if route=='primary':sg=(-1)**((1 if wrong_even else pi)*sum(p for n,p in word[:i])+(1 if wrong_even else pj)*sum(p for k,(n,p) in enumerate(word[:j]) if k!=i)+pj*(pi+1))
    else:sg=(-1)**(pi*sum(p for n,p in word[i+1:])+pj*sum(p for k,(n,p) in enumerate(word[j+1:],start=j+1) if k!=i)+pi)
    rem=[n for k,(n,p) in enumerate(word) if k not in [i,j]]
    if mode in ['Q','R']:rem,cc=canon(tuple(n-553 for n in rem));key2=(ni-553,nj-553,*rem);sg*=cc
    elif mode=='X':
     if (ni>=553)==(nj>=553):continue
     key2=(ni,nj,rem[0]-553)
    else:
     key2=(ni,nj,rem[0]-553) if ni<508 or nj<508 else(ni,nj,rem[0]-180)
    put(out,key2,z*sg)
 return out
def separate(H,mode):
 if mode=='X':return ({(i-508,j-553,k):z for(i,j,k),z in H.items() if i<553},{(i-553,j-508,k):z for(i,j,k),z in H.items() if j<553})
 Z={(i-553,j-553,k):z for(i,j,k),z in H.items() if i>=553 and j>=553};U={(i-180,j-553,k):z for(i,j,k),z in H.items() if i<508};V={(i-553,j-180,k):z for(i,j,k),z in H.items() if j<508};return Z,U,V
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for f,h in prep['input_sha256'].items():assert digest(Path(f))==h,f
 allowed={str(Path(f).resolve()) for f in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  f=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PHYSICAL_SCALAR_GHOST_OPERATOR_WRITE')
  if f.suffix=='.json':assert str(f.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(f))
 sys.addaudithook(guard);stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
 current=auth('canonical_so10_ghost_mass_g4_integration',role+'_result.json');pole=auth('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json');unified=auth('canonical_so10_unified_scalar_ghost_symbol',role+'_v2_result.json');oldscalar=auth('canonical_so10_antighost_g2_scalar_zero','primary_result.json' if role=='primary' else 'replay_v2_result.json');lor=auth('canonical_so10_fourghost_g4_lorentz',role+'_result.json');assert unified['raw_GF_counts']=={'M':432,'Y':6688,'X':276,'Q':648,'R':418}
 w,names,pos,T,I,ir,tr,scalar,S0,A0,Gi,Gp=stage('all643_actual_field_frames_both_inverses_and_zero_carriers',lambda:p.field_check(p.sealed('frozen_a10_e5_full_hessian',role)['retained_reference'],role));data=p.sealed('frozen_a10_physical_reconciliation','full_'+role);e2=p.sealed('frozen_a10_e2_transport',role);shared=p.sealed('frozen_a10_physical_reconciliation','full_primary')
 if role=='replay':assert all(data[k]==shared[k] for k in ['C3_plane_to_parent','parent_gauge_metric','representation_digests','representation_matrices','sector_dimensions'])
 convention=data.get('convention',shared['convention']);assert convention['covariant_derivative']=='d+g10*rho(B)' and convention['scalar_variation']=='-g10*rho(omega)*x' and oldscalar['all328_scalar_directions_retained_no_projected_scalar_inverse']
 assert {r['sector']:r['matrix_digests'] for r in oldscalar['all_four_literal_half_norm_ASTs_and_bound180_real_skew_generators']}==data['representation_digests']
 S,K,parent,rawK=stage('plane_to_actual_HM_isometry_and_full_kinetic_scalar_Q_correspondence',lambda:rho_bridge(data,e2,ir,tr,scalar));rawX,rawQ,rawR=raw_densities(unified['actual_raw_GF_vertex_census'],scalar);L={i:{int(n[2:]):v for n,v in ir[a].items()} for i,a in enumerate(AUX)};A={i:{int(n[2:]):v for n,v in ir[a].items()} for i,a in enumerate(ANTI)};C={i:{int(n[2:]):v for n,v in ir[f'C{i}'].items()} for i in range(45)};images={i:C[i] for i in range(45)}|{45+i:{45+j:z for j,z in A[i].items()} for i in range(45)}
 X=stage('actual_X_density_full_field_transport',lambda:pull3(rawX,L,A,C,role));Q=stage('actual_Q_exterior_four_field_transport',lambda:pull4(rawQ,images,role));R=stage('actual_R_control_transport',lambda:pull4(rawR,images,role));LL={i:{AUX.index(n):v for n,v in tr[f'Lp{i}'].items()} for i in range(45)};AA={i:{ANTI.index(n):v for n,v in tr[f'ap{i}'].items()} for i in range(45)};CC={i:{int(n[1:]):v for n,v in tr[f'Cp{i}'].items()} for i in range(45)};backimages={i:CC[i] for i in range(45)}|{45+i:{45+j:z for j,z in AA[i].items()} for i in range(45)};assert pull3(X,LL,AA,CC,role)==rawX and pull4(Q,backimages,role)==rawQ and pull4(R,backimages,role)==rawR
 Y=unpack(pole['physical_Y_aC_density']);E=unpack(pole['physical_E']);old=auth('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json');assert {tuple(r['word']):num(r['stripped_coefficient']) for r in old['all_literal_orbit_rows_stripped_only_g_and_explicit_xi']['Y']}=={tuple(r['word']):num(r['stripped_coefficient']) for r in unified['actual_raw_GF_vertex_census']['Y']};assert len(Y)==6268 and len(E)==296;p.orbit_inverse(old['all_literal_orbit_rows_stripped_only_g_and_explicit_xi'],E,Y,tr,scalar)
 def derive():
  Hx=hessian(X,'X',role);Hy=hessian(Y,'Y',role);Hq=hessian(Q,'Q',role);Hr=hessian(R,'R',role)
  assert Hx==hessian(X,'X',role,True) and Hy==hessian(Y,'Y',role,True);XX,Xr=separate(Hx,'X');Z,U,V=separate(Hy,'Y');assert Xr=={(j,i,k):-v for(i,j,k),v in XX.items()} and V=={(j,i,k):-v for(i,j,k),v in U.items()} and all(v==-Hq.get((j,i,a,b),ZERO) for(i,j,a,b),v in Hq.items()) and all(v==-Hr.get((j,i,a,b),ZERO) for(i,j,a,b),v in Hr.items());UU,VV=p.orbit_hessian(Y,role);assert {(i,j,k):v for(i,j),P in UU.items() for(k,),v in P.items()}==U and {(i,j,k):v for(i,j),P in VV.items() for(k,),v in P.items()}==V
  RR={}
  for i,j,word,co in lor['classical_operator_tables']['Rbar']:ow=tuple(int(n[2:])+(45 if n.startswith('ap') else 0) for n in word);ow,sg=canon(ow);put(RR,(i,j,*ow),num(co)*sg)
  assert Hr==RR;return XX,Xr,Z,U,V,Hq,Hr
 XX,Xr,Z,U,V,Hq,Hr=stage('all_left_right_Hessians_even_reorder_and_complete_R_match',derive);controls={'omit_plane_to_physical_gauge_bridge_changes_K':K!=parent,'flip_scalar_transformation_sign_changes_K':bool(K),'source_dual_is_not_actual_field_map':s.SparseMatrix(S0)!=s.SparseMatrix(A0),'positive_instead_of_opposite_mixed_X_transpose_changes_input':bool(XX),'reverse_odd_order_changes_X_density':bool(X),'wrong_quartet_factor_changes_Q_and_R_match':bool(Q) and bool(R),'omit_Phi_or_Sigma_scalar_complement_changes_K':any(i<54 for a,i,j in K) and any(54<=i<306 for a,i,j in K),'wrong_even_prefix_fails_moved_X_or_Y_Hessian':hessian(X,'X','primary',True,True)!=hessian(X,'X','primary') or hessian(Y,'Y','primary',True,True)!=hessian(Y,'Y','primary')};assert all(controls.values());counts={'K':len(K),'X_density':len(X),'Q_density':len(Q),'R_density_control':len(R),'X':len(XX),'Xr':len(Xr),'Z':len(Z),'U':len(U),'V':len(V),'Q':len(Hq),'R_match_control':len(Hr)}
 result={'schema':'ACTUAL_SCALAR_GHOST_PHYSICAL_OPERATOR_INPUTS_V2','route':role,'scientific_disposition':'ALL_FOUR_MISSING_PHYSICAL_OPERATOR_GROUPS_EXTRACTED_WITH_FULL_CORRESPONDENCE_NOT_POLE','exact_basis_squared':list(e.SQUARES),'all643_fields_both_inverses_zero_carriers_and_export_correspondence':True,'actual_plane_to_HM_isometry':packed(S),'kinetic_K_matches_actual_scalar_Q_and_inverse_parent_frame':True,'physical_K':packed(K),'physical_X_aC_density':packed(X),'physical_Q_density':[[list(word),p.text(z)] for word,z in sorted(Q.items())],'physical_X':packed(XX),'physical_Xr':packed(Xr),'physical_Z':packed(Z),'physical_Q':packed(Hq),'operator_position_counts':counts,'operator_exact_hashes':{tag:coef_hash(mat) for tag,mat in [('K',K),('X',XX),('Xr',Xr),('Z',Z),('Q',Hq),('R',Hr)]},'complete_sparse_domains':{'K':[45,328,328],'X':[45,90,90],'Xr':[90,45,90],'Z':[90,90,328],'Q_and_R':[90,90,4005],'quartet_density_C2_a2':[990,990]},'all_new_GF_densities_inverse_and_zero_domains_verified':True,'Z_from_same_Y_as_both_complete_qualified_U_V_maps':True,'all20064_actual_R_Hessian_positions_and_zero_complement_match':True,'even_reorder_X_Y_and_opposite_mixed_and_odd_skew_verified':True,'controls':controls,'insensitive_controls':[],'current_known_terms':current['updated_known_terms'],'current_known_sha256':current['updated_known_sha256'],'sourcefree_positions':41452,'sourceimage_positions':146663,'all_seven_quantum_flags_false':current['all_seven_quantum_flags_false'],'new_actual_color_pole_or_integration':False,'new_loop_full_functional_or_full_QAP_E5_A5':False,'shared_limits':'Actual action/reference/source/old scalar and R proofs/frames shared;new full physical correspondence and left/right density Hessians,not new poles or independent scientific endorsement','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};assert not any(result['all_seven_quantum_flags_false'].values());print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
