# Actual scalar-ghost physical operators V1

Baseca63a61b4ea132067a33cd5bb53e567a1d589163,clean main,no live workers.
Previous goal turn PROGRESS. Full Spin(10)xPQ goal stays active. SGO1 closes
the actual-field/normalization gap for K/Kt,X/Xr,Q,Z(s) needed by V279's
common scalar-ghost symbol. No actual loop coefficient or canonical insertion
is calculated here. A map/normalization mismatch is an informative failure,
not permission to fit a matrix to a Ward identity.

Freeze V279 formula/actual raw M/Y/X/Q/R census,V275 complete643 field maps
and physical E/Y,V270 actual D/F/R Hessians,V261 four half-norm scalar AST/
180 bound real-skew parent-plane matrices,actual E2 scalar source columns and
GF density,full reference field inverse/kernel and current V276 functional.
Parent-plane generators are NOT already in the propagator H/M basis. Define
BEFORE calculation S=Q_plane_from_C3 * I_rawC_from_physicalCp. Check Q^tQ
against frozen C3 gauge metric,S real/isometric,and same B/C frame all4
Lorentz directions. Define K_bij=sum_plane S_ab*rho_plane,aij. Independently
require K=-coefficient(Q x_physical)/(g10*Cp),with scalar convention
delta x=-g10 rho(omega)x. Check all328 scalar columns,full45*328^2 domain,
no affine/jet/cross-sector omission,real skewness and exact inverse recovery.
Reconcile the actual kinetic AST/normalization rather than choose a sign.

Use actual FIELD maps,never source-dual maps. Authenticate all643 directions,
both full inverse products and cross-carrier zero domains. All scalar
coordinates remain Cartesian. Exact arithmetic squared basis(2,3,5,-1,7),
retaining I bit8/sqrt7 bit16;preflight ALL new coefficients/maps/representation
rows/source-column types before workers. Reuse qualified arithmetic and
prior poles;do not replay old loop integrations or patch frozen helpers.

Extract X from raw276 L-a-C rows,Q from648 g1 quartet rows,and R from418
g2 rows as a complete normalization control. Primary transports literal
densities then takes left graded Hessians. Replay uses staged exterior-square
map contractions for quartets and literal right Hessians. Compare complete
densities/Hessians and inverse maps,including exact zero complements. X/Xr
and Y/U/V have the opposite mixed transpose;F T=L^t remains distinct. The
new R Hessian MUST match all20064 qualified V270 positions including zero
complement,not just a selected value. Zero B/Lambda backgrounds define these
selected blocks;omitted auxiliary-external blocks are not declared absent.

Z(s) comes from the SAME actual physical6268-row Y density as U/V. Reconcile
raw6688 Y action rows and qualified physical map before deriving every odd
Z coefficient and both mixed U/V maps. Keep g2*xi and external scalar index.
X strips xi;Q strips g1*xi;no extra1/2,factorial or Lorentz copies. Keep all
45/90/328 coordinates and primitive domain/dimension declarations. Do not
infer a missing matrix entry zero from the partial quantum functional.

Every new nondifferentiated Hessian must pass even-field reordering before
qualification;derive left/right signs with differentiated field parity. Check
X/Y opposite mixed transpose,Q/R odd skew,and scalar cross polarization.
Negative controls use source dual instead of field maps,omit the plane frame,
flip scalar-Q sign,mixed-transpose sign,ghost ordering,quartet Bose factor,
drop a scalar sector and mishandle an even field after an odd one. Disclose
insensitive controls;normalization is fixed by action,not covariance alone.

Two sequential native workers plus an independent verifier,each180sec AFTER
imports/8GiB sampled private/min350MiB available commit. This batch adds a
four-odd-index Q transport,complete kinetic-frame/source correspondence and
full new Hessian domains to V275's32sec baseline;the180sec cap is frozen now,
not silently enlarged after a timeout. Prefer sparse/factorized contractions.
Freeze code,expected evidence,role reads,receipt paths and exclusive mirrors.
Preserve failures/version corrections;no truncation or automatic scope expansion.

Independent route uses separate exact arithmetic and actual reference maps
without the common frame helper,congruence/density correspondence and right/
left checks on every coefficient/zero domain. All four groups must have
complete scope evidence or identify the exact missing premise. Full color
contraction of V279's traces remains a subsequent separately frozen increment.

Current155143-word/sourcefree41452/sourceimage146663 functional unchanged.
No loop,new physical pole,parameter search,fullGamma expansion,integration,
benchmark,scheme,input,policy or authority change. Authority34/39/seven flags
false. FullsourcefreeSlavnov,QAP,measure,IR,32 nonlinear products,contacts,
equivalence,E5/A5/GUT viability unqualified. HB1/C5 blocked,flavor paused;
quartet-candidate/scalar140%/gauge-matching/custodyexit2-seven limits persist.
No agent,branch/worktree,remote,publication or full-goal completion. Shared
action/chart/prior proofs/UV/software/AI author limit independence;no Lean,
fresh identical replay,expert or experiment. Validate before local commit and
authenticate exact parent,paths,HEAD/index/worktree bytes and clean tree.
