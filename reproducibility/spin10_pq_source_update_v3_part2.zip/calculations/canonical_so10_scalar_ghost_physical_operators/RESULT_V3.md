# Completed physical-input qualification

The independent verifier completed with receipt
`5e9111e97c80f31d241cb366fcc861608a04b82ca1cede4cbfec8b0d4b90d262`.
The scientific result and limits in RESULT_V2.md are retained. This summary
requires the local committed-byte check and does not replace project_state.json.

All four required groups are now explicit in the actual physical frame:
K12,560 positions; X/Xr1,200 each; Q37,152; Z12,536. The complete plane-to-H/M
isometry and all328 scalar-source columns fix K's normalization and sign.
Raw-Hessian congruence independently reproduces every new table and exact
zero domain,including inverse density maps. Both U/V maps agree with the
same qualified Y density; all20,064 R positions match the old normalization
control. Actual X is not a diagonal replacement.

Original replay FAILED on missing legacy convention metadata after its full
field-map check. The successful primary was preserved and reused. Corrected
replay explicitly reconciles shared primary metadata with its complete actual
matrices and its own scalar transformations; no math check is removed.
Both source versions and complete failed/successful captures remain.

Completed primary47.994sec/499994624 sampled private bytes;corrected replay
28.428sec/523415552;independent43.330sec/774942720. Failed replay parent16.219sec/
383021056. All completed180sec-after-imports/8GiB/min350MiB available-commit
limits and post-run observations pass. Four current binding maps match.
One native failure,zero independent failures;no fresh identical replay pairs.

No pole is newly evaluated or canonically integrated. The next mathematical
task is the sparse or equivalently factorized evaluation of the full common
scalar-ghost symbol,including every scalar-single and scalar-pair profile.
No profile is promoted merely by input availability. Current155143-word
functional and329/335 finite scope counts are unchanged. Authority34/39,
seven false flags,full E5/A5/QAP/measure/IR/contact/equivalence limitations,
HB1/C5 block and flavor pause remain. Shared action/charts/prior proofs/
software/AI author remain limits;no external scientific validation is claimed.
