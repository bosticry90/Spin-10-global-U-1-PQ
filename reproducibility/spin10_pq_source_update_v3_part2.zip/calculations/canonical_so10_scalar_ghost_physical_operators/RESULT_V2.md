# The four missing physical operator groups are explicit

SGO1, parent `ca63a61b4ea132067a33cd5bb53e567a1d589163`.
This report is a prospective qualification gate. Completed independent evidence,
strict input bindings and committed-byte custody are required. Native agreement
alone does not qualify it. The full Spin(10) x PQ investigation remains active.

The four physical operator groups required by V279's common scalar-ghost symbol
have been extracted: kinetic K/Kt, auxiliary/ghost X/Xr, the orderg1 quartic
ghost Hessian Q, and scalar-dependent odd Hessian Z(s). These are classical
action inputs in the actual propagator coordinates. No new quantum coefficient
has been contracted or integrated into the functional.

## Kinetic normalization required a genuine frame bridge

The published real representation matrices use the parent-plane basis. The
reference propagators use the physical H/M basis. They cannot be substituted
for one another directly. The predefined composition

    S = Q_plane_from_C3 * I_rawC_from_physicalCp

is real and isometric. Q^tQ agrees with the frozen C3 gauge metric, and all
four vector components use the same field map as the ghosts. Composing the
180 bound plane generators with S yields the actual kinetic matrices.

All 328 scalar transformation columns give the same result independently:
K is minus the coefficient of g10*Cp*x in the transported classical Qx.
The sign follows the existing scalar variation -g10*rho(omega)*x and covariant
derivative d+g10*rho(B). The parent-frame and raw-source inverse recoveries
are exact, including cross-sector zero entries. K is real and skew in its
scalar indices. The singlet remains Spin(10)-neutral.

The 7,602 parent-plane nonzero entries become 12,560 entries in this H/M
frame. The difference is coordinate support, not changed physical couplings.
The full domain is45*328*328; sparse equality authenticates its implicit
zeros without allocating a dense table. The qualified half-norm kinetic AST
and its Fourier/Wick bridge retain their original scope and normalization.

## Actual density and Hessian tables

| Quantity | Nonzero coefficient positions |
| --- | ---: |
| K | 12,560 |
| X density | 600 |
| X | 1,200 |
| Xr | 1,200 |
| Q density | 3,096 |
| Q Hessian | 37,152 |
| Z(s) | 12,536 |
| Y mixed U and V | 12,536 each |
| Reconstructed R density control | 1,672 |
| R Hessian control | 20,064 |

These are coordinate coefficient counts, not particle counts or measured loop
amplitudes. In particular, actual X is not a diagonal ansatz. Its raw 276 rows
produce 600 physical density positions. All45/90/328 directions remain.

The primary transports literal densities and takes left graded Hessians.
The replay uses staged exterior-square contractions for the quartic density
and right Hessians. Both recover every original X/Q/R density coefficient
under inverse field transport. Field maps are checked across all643 directions,
both full inverse products and the cross-carrier zero domains. Source-dual
maps are not substituted.

The new R calculation is a normalization control: all20,064 positions and
the complete zero complement match V270's already qualified Hessian. Q is
stripped only of g10*xi; X only of xi. No extra Bose, factorial or Lorentz
factor is inserted. Physical odd order is (C45,a45).

Z(s) is differentiated from the same6,268-position physical Y density used
for the qualified U/V maps. Its inverse reproduces the actual6,688 raw Y
rows. Both complete mixed maps and Z retain their g10^2*xi normalization.
The opposite mixed transpose holds for X/Xr and U/V, while the Fourier F
transpose remains distinct. Q/R are antisymmetric in odd derivative indices.
Every relevant even-field reordering is checked before accepting a Hessian.

Only the selected blocks at zero vector/auxiliary backgrounds are claimed.
Other auxiliary-external Hessian blocks are not silently declared absent.
The full Q/R operator domain includes90*90*4005 exterior-pair positions;
zeros follow from complete action differentiation and invertible transport,
not absence from a partial quantum polynomial.

## Verification and the preserved replay failure

The initial primary completed. Initial replay failed after its full field-frame
check because its legacy full_replay.json lacks the primary convention metadata.
The failed source,preparation and complete capture remain immutable.

V2 explicitly authenticates the primary convention record and requires the
replay's complete plane map, gauge metric, dimensions, representation digests
and every representation matrix to match. It still verifies its own scalar
transformation columns and every original tensor/inverse/normalization check.
The successful primary is reused. This is a shared metadata dependency, not
an independent derivation of physical conventions or a relaxed science gate.
The missed schema asymmetry is an avoidable planning failure.

Qualification additionally requires the separate five-radical verifier to use
the actual reference matrices without the common frame helper, derive raw
right Hessians and transport them by full congruence with external-field
pullback. It must compare every new coefficient and zero domain, density
inverse, scalar-source bridge and existing R position, not a diagnostic sample.

Before launch, all18,875 map/representation/GF numeric inputs and all29,754
scalar-source positions were checked in the exact squared basis(2,3,5,-1,7).
Even/odd left-right and even-field-movement checks were preflighted. No old
sqrt7 domain error or untyped metadata fallback is imported. Both native
completed routes are within180sec after imports/8GiB sampled private memory/
minimum350MiB available commit. Final independent execution/resource/failure
classification belongs to the actual completed receipt and captures.

Controls detect omission of the plane bridge, wrong scalar-Q sign, source-dual
versus field-map mismatch, wrong mixed transpose, reversed odd order, an extra
quartet factor, omitted charged scalar sectors and an even-derivative prefix
error. The field/source comparison is a chart-domain check, not a claim that
every observable is sensitive to a wrong map. No insensitive control is
counted as independent physical normalization evidence.

## What changes next

The previously symbolic input gap has moved to explicit physical tables.
The next decision is how to contract V279's complete ordered symbol sparsely,
with every original coupling/width factor and all40 actual profile scopes,
before expanding a large component tensor. First estimate the exact contraction
cost from these supports and reuse the already measured mass/pair results as
controls. Unknown coefficients must be measured from the action, not inferred
from a desired Ward cancellation.

Do not assume the linked diagnostic's simple Y=E*rho relation holds without
checking the model's full nonminimal antighost transformations. The action may
supply additional nonminimal terms. The actual Y table, not that diagnostic
specialization, is the qualified input.

No quantum pole, canonical integration, scalar-input change or protected
promotion occurs. The functional remains155143 words/hash
`fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241`,
sourcefree41452/sourceimage146663; V278's329/335 scope counts remain.
Authority34/39/seven false quantum flags,HB1/C5 block,flavor pause, historical
quartet-candidate/scalar140%/gauge-matching/custodyexit2-seven limits persist.
FullsourcefreeSlavnov,QAP,measure,IR,32 nonlinear products,contacts,equivalence
and E5/A5/GUT viability remain unqualified. No scheme,benchmark,policy or
external action. Shared action/old proofs/charts/software/AI author limit
independence; no fresh identical replay,Lean,expert or experiment is claimed.
