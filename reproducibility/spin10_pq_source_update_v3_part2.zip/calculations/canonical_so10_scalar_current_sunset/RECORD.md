# SCP1 prospective scalar-current sunset normalization contract

Base c8b2bf9cc8b7200b78a3296cd5357e5ca0ee1849/main, state113/34of39.
Question: does the actual kinetic VSS sunset admit a correctly normalized
ordered F2 proper-time kernel suitable for the remaining C1 calculation?
Freeze this contract, derivation, scripts and immutable input hashes BEFORE
science. Reuse VSP1/FCI/QIR scalar frame, actual rho, masses and projectors.
No retuning the scalar point, finite scheme, g, widths or accepted physics.

Domain: BFT source-zero xi1, D=4-2epsilon, physical external curvature,
g>0 and positive edge masses for the normalization pilot. Derive the whole
constant-Cartan F2 kernel with arbitrary conserved charges q1+q2+qv=0,
including both derivative vertices, vector spin, orbital factors, phases and
all29 raw labelled BFT placements. Spectral mass projectors stay on their
actual edges; never commute rho through H. The kernel can serve the full
family, but this increment does not contract all328 mixed scalar modes.

Actual selected subspace: SM singlet blocks0,1,3,4, labelsY=-2,-1,+1,+2.
Two physical masses426075291/62500000, two Goldstone masses(3/10)g^2.
Check restrictions against full H and OO.T. Calculate all45*4*4=720 vertex
amplitudes and5*4*4=80 mass-projector weights, including zeros, normalized
U1 charges and exact selection rules. Retain light-vector weights without
promoting their uncomputed IR domain. The positive neutral and charged-vector
transitions provide actual nonzero tests; do not solve weights from a Ward zero.

Two native routes: full scalar-coordinate vertices and endpoint heat expansion
versus independent open contraction/coordinate index algebra and two-plane
matrix expansion. Separate verifier checks all720/80 coefficients, positive
mass restrictions, Wick normalization, heat equation and endpoint derivatives,
the full symbolic kernel, charge conservation and sensitivity controls.

Compute a genuinely UV/IR-convergent normalization observable: two derivatives
with respect to EACH independent squared edge mass, then restrict to actual
mass relations. This is a sixfold master-mass derivative, not a change to the
physical parameter point or the finite threshold itself. It kills overall
local F2 terms and every one-loop subgraph's degree<=1 mass polynomial.
Compare the neutral sector against an independently reduced Fourier/momentum
propagator calculation using convergent mixed derivatives of the scalar master.
The charged sector retains actual spin/vertex terms and is checked by the
separate heat/index route; this is not an independent charged momentum derivation.

Use six ordered largest-proper-time sectors, positive masses and cancelled
rational endpoint factors. Gauss-Legendre orders48,80,128;60 working digits,
serialize25, scaled successive80/128 agreement1e-28 and cross-route1e-25.
If this fails, preserve inconclusive/failed output; no silent tolerance/order
relaxation. Diagnostic r_neutral=2, r_charged=10 follow the SAME g relation;
keep the full symbolic ratio r=mH2/[(3/2)g²] in the formula. Diagnostic values
are not a physical benchmark. Flat one-loop subgraph UV residues and their
noncommuting mass interpretation are checked; full F2 UV forests remain open.

Caps: model/kernel native180s each, numerical native300s each, verifier300s,
8GiB sampled private allocation,350MiB launch floor, newpackage<=4MiB.
Stage dependency: compare completed native model/kernel tables before freezing
numeric inputs; compare completed numeric outputs before verification. No
subagents; exclusive outputs and full captures; preserve failures/unfinisheds.
Controls: omitted vertex connection, reversed spin, missing orbital/Gaussian
term, bad scalar transpose/dual, wrong Wick/charge/mass assignment, omitted
sector, wrong radial Gamma/factorials, premature D4 at divergent stage. State
which controls are neutral-spin INSENSITIVE and detect them in charged data.

Success: qualified model-weighted ordered kernel and finite normalization
derivative, not a finite renormalized sunset, complete C1, general IR/matching
theorem or E5 promotion. If a derivation/control fails, report exact remaining
dependency. Shared action, frame, projectors, standard heat kernel, software
and AI authorship are shared premises, not independent physical validation.
No refit, new finite constant, old evidence edits, branch, push/publication,
flavor/HB1/C5 activation or protected authority change. Apply e4 and byte seals
before local commit; custody exit2/seven is never PASS. Goal remains active.
