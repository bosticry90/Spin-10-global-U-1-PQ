"""Independent explicit evanescent, orbital and radial normalization controls."""
from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
import sympy as S
import mpmath as mp
HERE=Path(__file__).resolve().parent
start=time.perf_counter();timer=threading.Timer(60,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
prep=json.loads((HERE/'dimensional_preparation.json').read_bytes())
for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tab=load(HERE/'primary_kernel_tables.json.gz');s,t,u,D,q1,q2,qv=S.symbols('s t u D q1 q2 qv',positive=True)
loc={str(v):v for v in [s,t,u,D,q1,q2,qv]};P=S.sympify(tab['P2'],locals=loc);K0=S.sympify(tab['K0'],locals=loc)
h=1/s+1/t+1/u;j0=K0/D
det=-D*j0*(q1*q1*s*s+q2*q2*t*t+qv*qv*u*u)/6
gauss=-D*j0*(q1*q1*s+q2*q2*t+qv*qv*u)/(3*h)
assert S.cancel(det+gauss-S.sympify(tab['pieces']['orbital_gaussian'],locals=loc))==0
e,R=S.symbols('epsilon formal_R');delta=S.cancel(P.subs(D,4-2*e)-P.subs(D,4))
assert S.cancel(delta+2*e*(det+gauss)/D)==0
c=S.sqrt(S.Rational(3,5));point={s:1,t:2,u:3,q1:-2*c,q2:c,qv:c}
coefficient=S.cancel(delta.subs(point)/e);assert coefficient!=0
assert S.limit(delta.subs(point)*R/e,e,0)==coefficient*R
separate={k:str(S.cancel(z.subs(point).subs(D,4))) for k,z in [('determinant',det),('Gaussian',gauss)]}
assert all(S.sympify(z)!=0 for z in separate.values())
mp.mp.dps=70;m=mp.mpf(7)/3
radial=mp.quad(lambda r:r**5*mp.exp(-m*r),[0,1,mp.inf]);expected=120/m**6
assert abs(radial-expected)<mp.mpf('1e-60')
a,b=[load(HERE/(role+'_numeric_tables.json.gz')) for role in ['primary','replay']]
neutral=[mp.mpf(v['results']['neutral']['history'][-1]['sum']) for v in [a,b]]
err=abs(neutral[0]-neutral[1])/(1+abs(neutral[0]));assert err<mp.mpf('1e-25')
result={'schema':'SCP1_DIMENSIONAL_CONTROL','execution_state':'COMPLETED',
 'status':'QUALIFIED_SEPARATE_ORBITAL_EVANESCENT_AND_RADIAL_CONTROLS','elapsed_after_imports':time.perf_counter()-start,
 'actual_charged_diagnostic_D_evanescent_coefficient':str(coefficient),
 'generic_pole_product_finite_response':str(coefficient*R),'pole_residue_measured_here':False,
 'separate_orbital_components':separate,'radial_Gamma6_control':'120/M^6',
 'recorded_45_digit_neutral_scaled_error':mp.nstr(err,15),'undifferentiated_finite_sunset_qualified':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
