# Next: retain and subtract the actual sunset Laurent terms

SCP1's ordered geometric P2 and nonzero actual normalization derivatives now
pass. Do not rerun the completed pilot, treat the derivatives as finite C1,
or drop the loop measure in NORMALIZATION_CLARIFICATION.md. The next missing
object is the undifferentiated graph's Laurent coefficient with its actual
UV subgraphs, followed by light/multisoft matching. Keep the full goal.

Use the same six ordered largest-proper-time sectors. For a permutation i,j,k
write s_i=R,s_j=R a,s_k=R a b, a,b in[0,1]. Put

 U0=a(1+b+ab), M=m_i²+a m_j²+ab m_k²,
 k(a,b,e)=a P2(1,a,ab;D=4-2e)
                 *(1+b+ab)^(-2+e)*M^(-2e).

The undifferentiated ordered coefficient is

 exp(2gamma_E e)(Qscale²)^(2e) Gamma(2e)
                      *int_0^1 db int_0^1 da a^(-2+e) k(a,b,e).

First prove k is regular at a0/b0 for the actual channel and derive its first
two Taylor coefficients k0,k1 from the authenticated kernel. Then the exact
subdivision identity is

 int da a^(-2+e) k = k0/(e-1)+k1/e
                    +int da a^(-2+e)[k-k0-a k1].

This exposes the power-sensitive term and logarithmic subgraph pole before
the overall Gamma(2e) pole. It is a proposed method, not an executed result.
For a finite coefficient keep k1 through e² and the regular integral through
e¹; preserve evanescent D and the common measure. Derive required orders
explicitly rather than assuming finite masters suffice. Further analytic
Taylor subtraction in a can improve endpoint quadrature without deleting
terms; integrate every subtracted monomial with its exact1/(n-1+e) factor.
Do not silently regularize a log endpoint by sampling it away.

Begin with the SAME nonzero physical/Goldstone singlet channels whose color
weights1/5 and4 are now measured, retaining r=mH²/[(3/2)g²] symbolically and
the charged ratio5r. Determine whether this gives a manageable common mass-
ratio implementation before contracting all328 modes. Numeric r=2/10 are
only diagnostics; a finite actual function must retain its parameter domain.
The sixfold derivative supplies an independent normalization constraint but
cannot fix the integration/subtraction constants it annihilated.

Obtain graph-local UV CT attachments from the actual opened one-loop current
and scalar kernels, with CLOSED-loop D evaluated in the UV pole and all
remaining heat/propagator terms retained. Complete background-dependent
subgraph operators are still required: a flat mass/kinetic pole alone does
not close a background F2 forest. Never select a subtraction from the value
needed to cancel the bare remainder. Check locality/mass independence of an
overall F2 pole only AFTER the actual subdivergences are treated; a failure
is a scientific or implementation question, not permission to fit it.

Coordinate this with VSP1: R_VVSS+(C_parent-C_VVSS), not R_VVSS+C_parent.
Reuse QMV's full scalar-loop vector mass theorem; do not repeat it as a new
loop result or equate its zero to a zero finite sunset. No alteration of
FCI/EAT/HTB, VFN's correlated q trace, finite f_fin or benchmark.

Positive-heavy subgraphs are not the whole family. The measured light-vector
weights and other scalar sectors remain. For three edges, multiple light
edges and momentum regions can differ from the factorized VVSS example.
OSF1 handles only its actual one-soft scope. Full finite VSS qualification
requires actual EFT vertices, connected products and common UV/IR subtraction
for those remaining assignments. No scaleless-zero or general IR theorem.

Freeze a new bounded contract and independent normalizations before this
Laurent extraction. Authority34/39, C1null, E5/A5unqualified, HB1/C5blocked,
flavorpaused, all historical evidence/physical caveats remain. No new scheme,
point/refit, foundations, protected acceptance, remote/publication action.
