# SCP1 dimensional-measure clarification

The prospective DERIVATION.md displayed the D-dimensional proper-time
integral without writing its common two-loop MSbar measure factor. Preserve
that frozen source. Its geometric polynomial P2 is correct; the fully
normalized bare formula must be read as

 Gamma2_Fphys2/ell² = -g10^4/8 N_e sum W int ds dt du
                          exp(-xs-yt-zu) U^(-D/2) P2(D),
 Lambda2/g10² = (3/2) N_e sum W int ds dt du
                          exp(-xs-yt-zu) U^(-D/2) P2(D),
 N_e=exp(2 gamma_E epsilon)(Qscale²)^(2 epsilon), D=4-2epsilon.

This is the existing C1 MSbar normalization, not a new subtraction scheme.
For one Gaussian loop, division of mu^(2e)(4pi)^(-D/2) by ell=1/(16pi²)
gives (4pi mu²)^e=exp(gamma_E e)(Qscale²)^e. Two loops square this factor.
As a check, one scalar tadpole is exactly

 exp(gamma_E e)(Qscale²)^e int_0^infinity ds s^(-D/2) exp(-xs)
 =x exp[e(gamma_E-log(x/Qscale²))] Gamma(e-1),

the already qualified MVM1/VQP1 master. No other scale factor or finite
normalization is allowed to replace it in the upcoming Laurent extraction.

The native symbolic tables calculate P2 and its separate spin/vertex/orbital
pieces; none depends on this common measure. The numerical calculations are
the UV/IR-convergent sixfold mass derivative at epsilon0, where N_e=1.
Thus no native output or receipt changes, and no recalculation is needed.
The main verifier did not validate an undifferentiated finite Laurent
coefficient. That claim remains unqualified. For that future calculation
the omitted factor would matter through poles, and MUST be included.

Classification: corrected scientific presentation omission before use in a
divergent calculation; no failed worker or altered physical input. This
clarification is an essential companion to the frozen displayed integral.
