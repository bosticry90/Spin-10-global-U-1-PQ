"""Freeze SCP1 sources/inputs before science; no old replay or evidence mutation."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-sunset-v1-2026-10-20')
BASE='c8b2bf9cc8b7200b78a3296cd5357e5ca0ee1849'
def dump(p,b):
    with p.open('xb') as out:out.write(b)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
p=CAL/'canonical_so10_vector_scalar_quartic/control_preparation.json';deps={str(p):sha256(p.read_bytes()).hexdigest()}
for n,h in json.loads(p.read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n;deps[n]=h
direct=['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V405.md',
 'calculations/canonical_so10_vector_scalar_quartic/controls_receipt.json',
 'calculations/canonical_so10_vector_scalar_quartic/NEXT_RESEARCH_QUESTION.md',
 'calculations/canonical_so10_quantum_vector_mass_uv/DERIVATION.md',
 'calculations/canonical_so10_vacuum_master_pilot/DERIVATION.md',
 'calculations/canonical_so10_vacuum_master_pilot/masters_v2.py']
for n in direct:p=ROOT/n;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['prepare.py','run.py','data.py','kernel.py','numeric.py','verify.py','RECORD.md','DERIVATION.md']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb,filename=str(p))
    dump(HERE/(name+'.source.txt'),bb)
    for q in [p,HERE/(name+'.source.txt')]:deps[str(q)]=sha256(q.read_bytes()).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==25638
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
value={'schema':'SCP1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'state_sha256':state,'kernel_native_seconds':180,'numeric_native_seconds':300,'verifier_seconds':300,
 'private_sample_cap':8*1024**3,'launch_floor':350*1024**2,'new_package_bytes':4*1024**2,
 'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;25638oldGitblobs;no science executed')
