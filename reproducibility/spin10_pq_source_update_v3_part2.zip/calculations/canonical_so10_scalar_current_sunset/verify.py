"""SCP1 independent endpoint/PDE, actual color and finite-derivative controls."""
from data import *
def main():
    start=begin('validation_preparation.json',300);mp.mp.dps=60
    tabs=[packed(HERE/(r+'_kernel_tables.json.gz')) for r in ['primary','replay']];assert tabs[0]==tabs[1];tab=tabs[0]
    nums=[packed(HERE/(r+'_numeric_tables.json.gz')) for r in ['primary','replay']]
    d,rho,E,P,Rh,Ty=setup('replay');A={(i,j):dec(z) for i,j,z in tab['vertices']}
    charges=list(map(s.sympify,tab['charges']));nnz=0
    for i in range(4):
        for j in range(4):
            zero(A[i,j]+A[j,i]);nnz+=len(A[i,j].todok())
            for a,R in enumerate(rho):assert red(A[i,j][a,0]-(E[:,i].T*R*E[:,j])[0])==0
    for r,i,j,z,q in tab['weights']:
        assert red(z)==red((A[i,j].T*P[r]*A[i,j].conjugate())[0])
        zero(Ty*P[r]*A[i,j].conjugate()-s.I*s.sympify(q)*P[r]*A[i,j].conjugate())
    assert s.sympify(tab['neutral_total_color'])>0 and s.sympify(tab['charged_total_color'])>0
    print('STAGE endpoint_and_heat_equation',flush=True)
    # Off-diagonal connection signs verified by direct differentiation of the phase.
    x0,x1,y0,y1,h,B,q=s.symbols('x0 x1 y0 y1 h B q',real=True)
    xx=s.Matrix([x0,x1]);yy=s.Matrix([y0,y1]);zz=xx-yy;J=s.Matrix([[0,1],[-1,0]])
    K=s.exp(s.I*q*B*(xx.T*J*yy)[0]/2-h*(zz.T*zz)[0]/4)
    U=h*s.eye(2)+s.I*q*B*J;V=h*s.eye(2)-s.I*q*B*J
    for mu in range(2):
        for nu in range(2):
            dy=s.diff(K,yy[nu])+s.I*q*B*(J*yy)[nu]*K/2
            dxdy=s.diff(dy,xx[mu])-s.I*q*B*(J*xx)[mu]*dy/2
            expected=U[mu,nu]/2-(U*zz)[mu]*(V*zz)[nu]/4
            assert s.expand(s.simplify(dxdy/K)-expected)==0
    # Coordinate heat PDE at O(B²), with two-plane orbital term.
    z0,z1,z2,z3,ss=s.symbols('z0 z1 z2 z3 ss',real=True);zs=[z0,z1,z2,z3]
    f=-ss**2/6-ss*(z0*z0+z1*z1)/12
    residual=s.diff(f,ss)+sum(z*s.diff(f,z)/ss-s.diff(f,z,2) for z in zs)+(z0*z0+z1*z1)/4
    assert s.expand(residual)==0
    # Independent momentum inverse PDE coefficient.
    pp,x=s.symbols('pp x',positive=True);p0,p1=s.symbols('p0 p1',real=True)
    g=1/(p0*p0+p1*p1+pp+x);Pmom=1/g
    assert s.simplify((s.diff(g,p0,2)+s.diff(g,p1,2))/4-Pmom*(-1/Pmom**3+2*(p0*p0+p1*p1)/Pmom**4))==0
    # Scalar-current flat UV bubble, before any fitted cancellation.
    alpha,xxm,yym,p2=s.symbols('alpha x y p2')
    delta=(1-alpha)*xxm+alpha*yym+alpha*(1-alpha)*p2
    dd=s.integrate(-2*delta,(alpha,0,1));ppc=s.integrate((1-2*alpha)**2,(alpha,0,1))
    assert s.expand(dd+xxm+yym+p2/3)==0 and ppc==s.Rational(1,3)
    tau=s.sympify(tab['neutral_total_color']);neutral_derivative_pole=tau/6
    assert neutral_derivative_pole>0
    # Each potential one-loop subgraph mass polynomial is killed on its two edge masses.
    xxx,yyy,zzz=s.symbols('xxx yyy zzz');poly=3*xxx+5*yyy+7*zzz+11*p2
    for u,v in [(xxx,yyy),(xxx,zzz),(yyy,zzz)]:assert s.diff(poly,u,2,v,2)==0
    pieces={k:expr(v) for k,v in tab['pieces'].items()};full=expr(tab['P2']);assert clean(full-sum(pieces.values()))==0
    assert clean(full-full.xreplace({st:tt,tt:st,q1:q2,q2:q1}))==0
    c=s.sqrt(s.Rational(3,5));point={st:1,tt:2,ut:3,D:4,q1:-2*c,q2:c,qv:c}
    controls={k:str(clean(v.subs(point))) for k,v in pieces.items()};assert all(s.sympify(z)!=0 for z in controls.values())
    htot=1/st+1/tt+1/ut
    novertex=clean(full+(q1-q2)**2/htot-pieces['spin_current_cross'])
    assert clean((novertex-full).subs(point))!=0
    reverse_spin=clean(full-2*pieces['spin_current_cross']);assert clean((reverse_spin-full).subs(point))!=0
    neutral={qv:0,q1:-2*c,q2:2*c};assert clean(pieces['vector_spin'].subs(neutral))==0 and clean(pieces['spin_current_cross'].subs(neutral))==0
    # The complete labelled product-rule census is independent of an evaluated probe.
    words=[('edge2',r,t) for r in range(3) for t in range(3)]
    words += [('edge_edge',r,t) for r in range(3) for t in range(3) if r!=t]
    words += [('edge_vertex',r,v,o) for r in range(3) for v in range(2) for o in range(2)]
    words += [('vertex_vertex',o) for o in range(2)];assert len(words)==29
    errors={}
    for case in ['neutral','charged']:
        a,b=[mp.mpf(n['results'][case]['kernel_mass_derivative']) for n in nums]
        err=abs(a-b)/(1+abs(a));assert err<mp.mpf('1e-25'),('HEAT_FOURIER_OR_MATRIX_ROUTE_DISAGREEMENT',case,a,b)
        errors[case]=mp.nstr(err,15);assert a!=0
        for n in nums:
            out=n['results'][case];assert mp.mpf(out['last_scaled_change'])<mp.mpf('1e-28')
            assert len(out['history'])==3 and [h['order'] for h in out['history']]==[48,80,128]
            assert len(out['history'][-1]['sectors'])==6
            assert all(mp.mpf(v)!=0 for v in out['history'][-1]['sectors'])
    status='QUALIFIED_ORDERED_VSS_F2_KERNEL_AND_ACTUAL_HEAVY_NORMALIZATION_DERIVATIVE'
    print('RESULT '+json.dumps({'schema':'SCP1_VALIDATION','status':status,'execution_state':'COMPLETED',
      'elapsed_after_imports':time.perf_counter()-start,'vertex_domain':720,'vertex_nonzero':nnz,
      'mass_charge_weight_domain':80,'weights_nonzero':sum(s.sympify(z[3])!=0 for z in tab['weights']),
      'raw_placements':29,'neutral_UV_derivative_coefficient':str(neutral_derivative_pole),
      'route_scaled_errors':errors,'actual_charged_kernel_components_at_diagnostic_point':controls,
      'omitted_vertex_connections_detected':True,'reversed_spin_detected_in_charged_probe':True,
      'neutral_spin_control':'INSENSITIVE; charged test required','bad_real_metric_Hermitian_replacement_detected':len(tab['wrong_Hermitian_vertex_control']),
      'omitted_sector_or_wrong_radial_or_Wick_factor':'nonzero_integral_changes',
      'finite_undifferentiated_sunset_C1_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'},sort_keys=True),flush=True)
if __name__=='__main__':main()
