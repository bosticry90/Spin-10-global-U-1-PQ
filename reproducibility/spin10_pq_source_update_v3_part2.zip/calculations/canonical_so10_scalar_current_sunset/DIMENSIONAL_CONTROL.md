# SCP1 final sensitivity supplement, frozen before its execution

The main two-route calculation and distinct verifier have completed. Preserve
their exact bytes. This supplement makes three normalization controls explicit:
separate orbital-determinant/Gaussian contributions; D4 versus4-2epsilon in
the still-divergent kernel; and the radial Gamma(6) of the convergent mass
derivative. Compare the higher-precision recorded neutral sums as well.

The evanescent change multiplied by a FORMAL R/epsilon demonstrates finite
sensitivity, not the actual undifferentiated graph's residue or counterterm.
Those remain unmeasured. No partial breaking is fitted. This supplement must
not be described as full UV forest verification or a finite sunset result.

Freeze source/inputs before computation, exclusive outputs/capture,60s body,
8GiB sampled/350MiBfloor, same4MiB wholepackage. Scientific acceptance remains
NOT_PERFORMED, authority34/39. No source/input change or rerun of old workers.
