"""SCP1 frozen inputs, exact output and resource timer."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,itertools
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,dec,enc,number,point_root
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
st,tt,ut,D,q1,q2,qv=s.symbols('s t u D q1 q2 qv',positive=True)
LOC={str(z):z for z in [st,tt,ut,D,q1,q2,qv]}
def read(p):return json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def clean(z):return s.cancel(s.expand(z))
def expr(z):return s.sympify(z,locals=LOC)
def begin(prep='preparation.json',seconds=180):
    start=time.perf_counter();timer=threading.Timer(seconds,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in read(HERE/prep)['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return start
def save(role,kind,tab,start,extra=None):
    raw=(json.dumps(tab,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_'+kind+'_tables.json.gz')).open('xb') as out:out.write(blob)
    value={'schema':'SCP1_'+kind.upper(),'role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)}
    if extra:value.update(extra)
    print('RESULT '+json.dumps(value,sort_keys=True),flush=True)
def setup(role):
    d=read(PK/('frozen_a10_physical_reconciliation/full_'+role+'.json'))
    rho=[s.SparseMatrix(s.diag(*[dec(d['representation_matrices'][k][a]) for k in ['Phi','Sigma','phi','S']])) for a in range(45)]
    frame=packed(CAL/'canonical_so10_scalar_sm_frame'/f'{role}_tables.json.gz');Q=dec(frame['Q']);ids=[0,1,3,4]
    E=Q[:,[frame['blocks'][i]['offset'] for i in ids]];zero(E.H*E-s.eye(4))
    P=list(map(dec,packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')['projectors']))
    V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding'])
    Ty=s.SparseMatrix(45,45,{});f=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')['f']
    for a,b,c,z in f:
        if V[a,0]:Ty[c,b]+=V[a,0]*s.sympify(z)
    Rh=tidy(sum((V[a,0]*rho[a] for a in range(45)),s.SparseMatrix(328,328,{})));Ty=tidy(Ty)
    return d,rho,E,P,Rh,Ty
