"""SCP1 six-sector convergent mass derivative and independent Fourier reduction."""
from data import *
@lru_cache(None)
def legendre(n):
    out=[];tol=mp.mpf('1e-65')
    with mp.workdps(75):
        for j in range(1,(n+1)//2+1):
            x=mp.cos(mp.pi*(mp.mpf(j)-mp.mpf('.25'))/(n+mp.mpf('.5')))
            for it in range(30):
                p=mp.legendre(n,x);der=n*(x*p-mp.legendre(n-1,x))/(x*x-1);dx=p/der;x-=dx
                if abs(dx)<tol:break
            else:raise ArithmeticError('GAUSS_NODE_NOT_CONVERGED')
            der=n*(x*mp.legendre(n,x)-mp.legendre(n-1,x))/(x*x-1);w=1/((1-x*x)*der*der)
            out.append(((1-x)/2,w));out.append(((1+x)/2,w))
    assert len(out)==n
    for k in [0,1,2,5,2*n-1]:assert abs(sum(w*x**k for x,w in out)-mp.mpf(1)/(k+1))<mp.mpf('1e-55')
    return sorted(out)
def fourier_master_coefficients():
    x,y,z=s.symbols('x y z',positive=True);I=s.Function('I')(x,y,z);k=z-2*x-2*y
    f=s.diff(I,x)+s.diff(I,y)-x*s.diff(I,x,2)-y*s.diff(I,y,2)
    f+=x*k*s.diff(I,x,3)/6+y*k*s.diff(I,y,3)/6+(x+y-z)*s.diff(I,x,y)
    result=s.expand(s.diff(f,x,2,y,2,z,2));terms=[]
    for deriv in sorted(result.atoms(s.Derivative),key=str):
        coef=clean(result.coeff(deriv));powers=dict(deriv.variable_count);idx=tuple(int(powers.get(v,0)) for v in [x,y,z])
        assert min(idx)>=1
        terms.append((idx,coef))
    assert s.expand(result-sum(co*d for d in result.atoms(s.Derivative) for co in [result.coeff(d)]))==0
    return (x,y,z),terms
def sector_functions(tab,role,case):
    a,b=s.symbols('a b',positive=True);v=[st,tt,ut];S=st*tt+st*ut+tt*ut
    c=s.sqrt(s.Rational(3,5));cases={'neutral':([2,2,1],[-2*c,2*c,0]),'charged':([10,1,1],[-2*c,c,c])}
    masses,qs=cases[case];M=sum(x*y for x,y in zip(masses,v));P=expr(tab['P2']).subs({D:4,q1:qs[0],q2:qs[1],qv:qs[2]})
    if case=='neutral' and role=='replay':
        xyz,terms=fourier_master_coefficients();P=0
        for idx,coef in terms:
            n=sum(idx);P+=coef.subs(dict(zip(xyz,masses)))*(-1)**n*s.factorial(n-2)*st**idx[0]*tt**idx[1]*ut**idx[2]/(S*S*M**(n-1))
        integrand=qs[0]**2*P
    else:integrand=120*st**2*tt**2*ut**2*P/(S*S*M**6)
    funcs=[];formula=[]
    for order in itertools.permutations(range(3)):
        vals={v[order[0]]:s.S.One,v[order[1]]:a,v[order[2]]:a*b}
        f=s.factor(clean(a*integrand.subs(vals,simultaneous=True)));num,den=s.fraction(f)
        assert den.subs({a:0})!=0 and den.subs({b:0})!=0,'REMOVABLE_ENDPOINT_NOT_CANCELLED'
        formula.append({'order':list(order),'integrand':str(f)})
        funcs.append(s.lambdify((a,b),f,modules='mpmath',cse=True))
    return funcs,formula
def integrate(funcs,n):
    grid=legendre(n);values=[]
    for f in funcs:
        value=mp.fsum(w1*mp.fsum(w2*f(x,y) for y,w2 in grid) for x,w1 in grid)
        values.append(value)
    return values
def main():
    start=begin('numeric_preparation.json',300);role=sys.argv[1];assert role in ['primary','replay'];mp.mp.dps=60
    tab=packed(HERE/(role+'_kernel_tables.json.gz'));results={};allformula={}
    for case in ['neutral','charged']:
        funcs,formula=sector_functions(tab,role,case);allformula[case]=formula;history=[]
        for n in [48,80,128]:
            vals=integrate(funcs,n);history.append({'order':n,'sectors':[mp.nstr(v,45) for v in vals],'sum':mp.nstr(mp.fsum(vals),45)})
            print('STAGE '+case+'_gauss_'+str(n),flush=True)
        x,y=map(lambda row:mp.mpf(row['sum']),history[-2:]);err=abs(x-y)/(1+abs(y));assert err<mp.mpf('1e-28'),('QUADRATURE_NOT_CONVERGED',case,mp.nstr(err,15))
        assert y!=0 and all(mp.mpf(v)!=0 for v in history[-1]['sectors'])
        weight=s.sympify(tab[case+'_total_color']);normal=mp.mpf(str(s.N(weight,70)))*mp.mpf('1.5')
        results[case]={'history':history,'last_scaled_change':mp.nstr(err,15),
          'kernel_mass_derivative':mp.nstr(y,25),'actual_color_weight':str(weight),
          'scaled_Lambda2_mass_derivative_per_g2':mp.nstr(normal*y,25),
          'meaning':'a_case^6/g10^2 times d_x^2 d_y^2 d_z^2 Lambda2; independent edge masses differentiated before restriction',
          'missing_first_sector_changes_kernel':history[-1]['sectors'][0]}
    xyz,terms=fourier_master_coefficients()
    save(role,'numeric',{'schema':'SCP1_NUMERIC','results':results,'sector_formulas':allformula,
      'neutral_Fourier_derivative_master_coefficients':[[list(i),str(c)] for i,c in terms],
      'ratio_r_neutral':2,'ratio_r_charged':10,'working_digits':60,'reporting_digits':25,
      'tolerance_scaled':'1e-28','finite_undifferentiated_sunset_qualified':False},start)
if __name__=='__main__':main()
