# SCP1 prospective ordered kernel

Scalar kinetic action gives S_VSS=-g Q_mu^a eta_i rho_a,ij D_mu eta_j.
For real antisymmetric rho, two cross scalar Wick pairings and the exponential
factor-1/2 combine to

 Gamma2=-g²/4 sum rho_aij rho_bkl Gv_ab,munu
  (Dx1-Dx2)_mu(Dy1-Dy2)_nu [Gs_ik(x,y) Gs_jl(x,y)].

This is BFT's species-normalized-1/4, not an extra symmetry factor inside a
master. Scalar-loop self contractions and1PR dumbbells are outside this1PI
sunset. Vertices remain covariant derivatives, not ordinary derivatives.

Because masses commute with an unbroken Cartan, resolve each edge into its
own mass/charge spectral projectors. They need not commute with rho at a
vertex. On a magnetic plane J=[[0,1],[-1,0]], F=BJ, and b_j=g q_j B,
the scalar heat kernel is
 U_j(x,y)(4pi s_j)^(-D/2) [s_j b_j/sinh(s_j b_j)]
 exp[-z_plane² b_j coth(s_j b_j)/4-z_perp²/(4s_j)-m_j²s_j].
U_j=exp(i g q_j x F y/2) in A_mu=-F_munu x_nu/2. Their product is1 because
q1+q2+qv=0. The vector edge multiplies its scalar heat kernel by exp(2i b_v uJ).
This is the actual minimal vector operator -Db² delta-2g ad(F)+mass.
Use derivatives at B0 first; no finite-field spin stability assumption.

Endpoint derivatives of a scalar edge are
 Dx K=-(H+i bJ)z K/2, Dy K=(H-i bJ)z K/2,
 Dx_mu Dy_nu K=[(H+i bJ)_munu/2
          -((H+i bJ)z)_mu((H-i bJ)z)_nu/4]K.
H=b coth(bs) in plane and1/s outside. The signs depend on the right-end
cotangent connection. Dropping them removes real background vertex terms.

Write s,t,u for two scalar and vector proper times; a=1/s,b=1/t,c=1/u,
h=a+b+c, U=st+su+tu and j0=(a+b-(a-b)^2/h)/2=(s+t+4u)/(2U).
For charges q1,q2,qv define
 d=(q1²s+q2²t+qv²u)/3,
 j2=[(q1²s+q2²t)/3
       -(2(a-b)(q1²s-q2²t)/3+(q1-q2)^2)/h+(a-b)^2 d/h²]/2,
 j1=[q1+q2-2(a-b)(q1-q2)/h]/2,
 E=-(q1²s²+q2²t²+qv²u²)/6-d/h.

Gaussian z integration and the ordered vector spin contraction give

 K0=D j0,
 P2=2j2+4qv²u²j0-4qv u j1+D j0 E,
 Gamma2_Fphys²/ell²=-g4/8 sum W integral ds dt du
                    exp(-xs-yt-zu) U^(-D/2) P2,
 Lambda2/g²=(3/2) sum W integral exp(-xs-yt-zu) U^(-D/2) P2.

Fphys²=2B² fixes the1/8. W is the actual positive tensor contraction with
three spectral projectors. The spin term includes an antisymmetric-current
cross term; neutral qv0 does not test its sign. K0 and P2 are symmetric under
simultaneous exchange(s,q1,x)<->(t,q2,y). They are even under flipping ALL
charges; flipping qv alone violates the charge rule and is an invalid control.
The covariance of the heat inverse and the two vertices includes all BFT29
labelled variations:15 on three edges,12 edge/vertex and2 between vertices.
No equality to a p=0 constant-connection calculation is asserted.

The heat coefficients and smooth local domain are inherited VQP/WHP inputs.
The new off-diagonal expression is checked against its heat equation and
endpoint connections rather than importing an unrelated finite QED scheme.
Primary literature comparator: Krasnansky hep-th/0607230v2 eq2.2--2.4 and
the original MVM master references. The self-dual QED reduction does not
calculate Spin(10), and its special background/renormalization is NOT adopted.
Source https://arxiv.org/pdf/hep-th/0607230 .

## Independent neutral Fourier check, after convergent mass differentiation

For q1=-q2=q,qv=0 the scalar momentum inverse in a single plane is
 G=1/P+g²q²B²[-1/P³+2p_plane²/P4], P=p²+x.
This follows independently by solving (p²+x)G=1+(gqB)² partial_plane² G/4.
The derivative vertices add+q² partial_p,plane Gx partial_k,plane Gy.
After full rotational integration, the B² coefficient divided by q² is

 (p-k)²[(-1/Px³+4p²/(D Px4))/Py
          +(-1/Py³+4k²/(D Py4))/Px]/Pv
       +8 p.k/(D Px² Py² Pv), Pv=(p+k)²+z.

Take two derivatives with respect to EACH independent x,y,z FIRST. Every
one-loop subgraph counterterm is at most linear in its squared masses and
external momentum squared; differentiation in both masses of that subgraph
kills its residue. Overall local F2 ambiguity is killed too. All remaining
integrals converge for positive masses, so D4 is now legitimate. It was NOT
legitimate in the undifferentiated bare sunset. This derivative cannot fix
the finite constants lost by differentiation.

At D4 the scalar propagator coefficient simplifies to-x/Px4. Algebraic
numerator reduction, modulo factorized terms annihilated by d_x²d_y²d_z²,
gives the neutral integral divided by q² as

 I_x+I_y-x I_xx-y I_yy+x(z-2x-2y)I_xxx/6
                +y(z-2x-2y)I_yyy/6+(x+y-z)I_xy.

I is the MVM finite scalar sunset; its single-mass bare finite additions and
all factorized terms disappear ONLY after the declared derivatives. For
n=i+j+k and mixed derivatives occurring here,
 I_(i,j,k)=(-1)^n Gamma(n-1) integral_simplex
       alpha^i beta^j gamma^k/[U² M^(n-1)], M=x alpha+y beta+z gamma.
This is an independent momentum/master-derivative route, not a derivative
of the same heat code. No differentiated zero-mass limit is used.

Heat route for the same normalization derivative is
 120 integral_simplex alpha² beta² gamma² P2(alpha,beta,gamma)/[U² M6].
The factor120=Gamma(6) comes from the radial integral. Split into six ordered
largest-proper-time sectors: s_i=R,s_j=R a,s_k=R a b, a,b in[0,1], Jacobian
R²a. Cancel removable endpoint factors symbolically. This makes both routes
integrals of regular rational functions on the unit square. No omission of
sectors, hidden factors2!, or numerical endpoint cutoff.

## Actual scalar restriction and UV normalization

Use normalized unit seed columns e_i, i in SM blocks(0,1,3,4), full real-field
projectors S_i=e_i e_i.H. C_aij=e_i.T rho_a e_j uses TRANSPOSE, not e_i.H:
the real two-scalar metric couples conjugate charges. W_rij=C_ij.T Pr C_ij*.
Replay opens the scalar contraction sum_ab Pr_ab rho_a S_j rho_b.T and closes
it on S_i.T. Both formulae agree on all80 entries including mass0 weights.
Directly verify scalar charges qi=(-2,-1,1,2)sqrt(3/5), Ty Pr C*=i qv Pr C*,
qv=-(qi+qj), H e_(0,4)=mH² e, H e_(1,3)=0, Wscalar e_(1,3)=(3/10)e.

Neutral positive probe: r_vector=2, scalar blocks(0,4)/(4,0).
Charged probe: r_vector=1, pairs(0,3),(3,0),(4,1),(1,4).
Their color weights are measured, not defined by desired normalization.
Let aN=(3/2)g² and r=mH²/aN. The neutral masses/aN are(r,r,1); charged
masses/aC are(5r,1,1), aC=(3/10)g²=aN/5. Preserve this relation; do not choose
different favorable couplings in the two probes. The finite diagnostic is
aN6/g² times the neutral mass derivative, or aC6/g² times the charged one.
It is not the undifferentiated finite matching coefficient.

Flat scalar-current one-loop subgraph: the numerator(2k+p)_mu(2k+p)_nu
gives pole[-(x+y)delta-(p²delta-pp)/3]/epsilon. With the actual Gaussian
weight-tau/2, its mass pole cancels the quartic tadpole and the derivative
coefficient is tau/6. Reuse QMV's FULL scalar UV mass theorem; this is a
kernel normalization check in a restricted sector, not another full theorem.
No complete background F2 forest or local two-loop counterterm is fixed here.

Exact-once with VSP1 still requires using C_parent-C_VVSS beside R_VVSS.
This pilot is not added to that subtotal. Full VSS finite coefficients, mixed
momentum regions, multiple soft edges, full EFT matching, all other primitives,
general-width consistency, nonlinear matching, C1 and E5 remain open.
