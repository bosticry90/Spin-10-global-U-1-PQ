"""Freeze and capture the additive completed-input normalization supplement."""
from pathlib import Path
from hashlib import sha256
import ast,json,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-sunset-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
assert json.loads((HERE/'validation_receipt.json').read_bytes())['status']=='QUALIFIED_ORDERED_VSS_F2_KERNEL_AND_ACTUAL_HEAVY_NORMALIZATION_DERIVATIVE'
deps={}
for name in ['DIMENSIONAL_CONTROL.md','dimensional_control.py','run_dimensional_control.py',
 'primary_kernel_tables.json.gz','primary_numeric_tables.json.gz','replay_numeric_tables.json.gz','validation_receipt.json']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb)
    if name in ['DIMENSIONAL_CONTROL.md','dimensional_control.py','run_dimensional_control.py']:
        q=HERE/(name+'.source.txt')
        with q.open('xb') as out:out.write(bb)
        deps[str(q)]=sha256(bb).hexdigest()
    deps[str(p)]=sha256(bb).hexdigest()
dump(HERE/'dimensional_preparation.json',{'schema':'SCP1_DIMENSIONAL_PREPARATION','input_sha256':deps,
 'seconds':60,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':4*1024**2})
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'dimensional_control.py')]);dump(HERE/'dimensional_capture.json',c);dump(CONTROL/'dimensional_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
assert c['launch']['memory']['available_pagefile']>=350*1024**2
records=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(records)==1
r=records[0];assert r['elapsed_after_imports']<60;dump(HERE/'dimensional_receipt.json',r);print(json.dumps(r,sort_keys=True),flush=True)
