# SCP1: an ordered scalar-current sunset kernel and actual normalization test

The VSS sunset now has an explicit weak-background F2 kernel retaining its
derivative vertices, vector spin, orbital factors and charge ordering. Two
actual heavy channels have passed a convergent normalization test. This is
progress toward the missing primitive amplitude, not that finite amplitude
itself. The undifferentiated sunset's UV forests, light/momentum regions and
EFT subtraction remain unqualified, as do complete C1 and E5/A5.

Main validation receipt SHA256:
`c851b233d9c80ac49991a79f1e0aee6b7c4eca83070ffa94c4f973f4f871f123`, status
QUALIFIED_ORDERED_VSS_F2_KERNEL_AND_ACTUAL_HEAVY_NORMALIZATION_DERIVATIVE.
The additive dimensional-control receipt and NORMALIZATION_CLARIFICATION.md
are required companion evidence. Director scientific acceptance NOT_PERFORMED,
state113/34of39 unchanged. Original exclusive outputs/controllers must not
be rerun under the same filenames.
Dimensional-control receipt SHA256:
`123dbef8f28dfe0f1062d9529ef5a5336cfc9a64847cf4e3808afcaab9626615`.

## What was derived and measured

The literal vertex -g10 Q_mu^a eta.T rho_a D_mu eta produces the BFT1 Wick
weight-1/4. The new off-diagonal proper-time derivation keeps the connection
terms on BOTH scalar endpoints and the vector spin exp(2u Omega). All29
raw labelled background placements are retained through the covariant
inverse/vertex product rule, not by setting external momentum to zero.

Let s,t,u denote two scalar and vector proper times, U=st+su+tu. The flat
current numerator after Gaussian integration is D(s+t+4u)/(2U). The F2
polynomial P2 is supplied in both kernel tables and prospectively derived
in DERIVATION.md, with separate scalar-current, vector-spin, spin/current
cross and orbital/Gaussian pieces. It is symmetric under exchanging the
two scalar edges and even under reversing all charges. Spectral projectors
stay on their own edges; no rho/H commutation is assumed.

The charge-resolved kernel is applicable to the retained constant-Cartan
local F2 projection with positive masses. A full328-mode spectral
contraction has not been performed. At this step the actual restriction is
four normalized SM singlet columns, blocks0,1,3,4, with Y=-2,-1,+1,+2.
Their masses are mH²=426075291/62500000 for the two physical scalars and
(3/10)g10² for the two Goldstones. These restrictions were checked against
the full potential Hessian and OO.T, not assigned from the wanted result.

All720 current-vertex positions and80 mass-projector weights were compared,
including688/68 zeros respectively. There are32 nonzero vertex entries and
12 nonzero weights. In the normalized U1 direction c=sqrt(3/5), actual
scalar charges are(-2,-1,1,2)c. Every nonzero vertex passes the charge rule
qv+q1+q2=0 using the actual adjoint matrix and its mass projector.

Two positive-heavy channels provide the normalization pilot:

| channel | vector mass/g10² | scalar edge types | summed measured color weight |
|---|---:|---|---:|
| neutral broken vector | 3/2 | physical Y=-2 and+2, both edge orders | 1/5 |
| charged broken vector | 3/10 | physical Y=+-2 and Goldstone Y=-+1, all four orders | 4 |

The charged vertices connect different scalar masses. Replacing the mass
matrix by a scalar commuting with every generator would remove real model
information. The12 light-vector directions' nonzero selected weights are
also retained in the tables; their massless integrals are not evaluated or
declared zero. No complete family or complete IR matching claim follows.

## A finite and independently checked normalization probe

Before any divergent integral is specialized, differentiate twice with
respect to EACH of the three independent squared edge masses. This sixfold
master-mass derivative is convergent at D4 for positive masses. Each
one-loop subgraph's degree<=1 mass polynomial is killed on its two internal
edge masses, and the overall local F2 ambiguity is removed. This allows
D4 only AFTER this operation, not in the undifferentiated graph.

It is not a variation of the physical scalar point: the master edge masses
are independent mathematical labels while differentiating. The actual
equal-mass relations are imposed afterward with vertices/projectors fixed.
No experimentally measurable observable or new physical benchmark is claimed.
The derivative cannot determine the finite integration/subtraction constants
lost by differentiating, nor prove invariance under arbitrary mass-dependent
finite renormalization conditions.

The heat route gives a six-sector convergent rational integral with radial
factor Gamma(6)=120. In the neutral channel an independent momentum inverse
and covariant-vertex calculation reduces to mixed derivatives of the scalar
sunset master I. Both are then integrated as distinct regular sector kernels.
This comparison agrees, including the background vertex term; it is not two
evaluations of the same dilogarithm or a coefficient fitted to a Ward zero.

Write aN=(3/2)g10², aC=(3/10)g10²=aN/5 and r=mH²/aN. The symbolic kernels
retain arbitrary positive r. At the diagnostic r=2 the neutral edge masses
in aN units are(2,2,1) and charged masses in aC units are(10,1,1), using the
SAME g relation. For Lambda2=-12 Gamma2_Fphys2/(ell²g10²), ell=1/(16pi²),
the measured values are

| channel | a_case^6/g10² times d_x² d_y² d_z² Lambda2 |
|---|---:|
| neutral | -0.009118979759307589973021454 |
| charged | 0.02233579383188762070554209 |

These are nonzero normalized derivative tests, NOT finite C1 coefficients.
No g or matching scale has been adopted. The charged numerical replay uses
the independently constructed two-plane heat kernel, sharing the standard
heat premise; an independent CHARGED momentum derivation was not performed.
The neutral momentum test and the separate endpoint/PDE verifier provide
the distinct normalization checks available in this increment.

Working60digits, reporting25, Gauss-Legendre orders48/80/128. Every one of
the six sectors is nonzero. Last scaled80/128 change is2.81273419601565e-37
in the charged probe; the neutral change is below the45-digit serialized
history resolution. Route discrepancies are zero at25-digit reporting and
also below the recorded45-digit neutral comparison resolution. These are
convergence indicators and numerical corroboration, not rigorous error bounds.
Frozen requirements were1e-28 successive convergence and1e-25 route agreement.

## Subgraph normalization and sensitive controls

The flat one-loop scalar-current numerator gives the pole
[-(x+y)delta-(p²delta-pp)/3]/epsilon before closing the remaining edge.
With the actual neutral tau=1/5 its derivative coefficient is tau/6=1/30.
The associated mass pole cancels its quartic partner. QMV1's complete scalar
UV mass theorem is reused in its qualified scope; this selected kernel check
does not requalify it or complete the background-dependent UV forest.

The verifier independently differentiates the off-diagonal phase to test
right-end connection signs; checks coordinate heat and momentum inverse
equations; recomputes all selected vertices/weights; and checks raw29-word
coverage. Wrong Hermitian replacement of the REAL two-scalar transpose
changes24 weight positions. Missing sectors, Wick/radial normalization and
edge charge/mass assignments are sensitive at the measured inputs.

At the generic actual charged-charge diagnostic(s,t,u)=(1,2,3), D4, the four
kernel pieces are

    scalar-current -1107/605; vector-spin 162/11;
    spin/current cross -126/55; orbital/Gaussian -885/121.

Thus deleting vertex connections, reversing the gyromagnetic spin term or
omitting orbital/Gaussian effects changes the kernel. Neutral-vector spin
and spin/current controls are explicitly INSENSITIVE; the charged probe is
needed. The additive control separates orbital determinant-51/11 and
Gaussian-324/121 and checks the radial integral120/M6 independently.

The same control demonstrates that premature D4 loses885 epsilon/242 in
this diagnostic kernel. Multiplication by a FORMAL R/epsilon would change
the finite part by885R/242. R is not a measured sunset residue, and no finite
correction for the undifferentiated model graph is inferred from this control.

## Normalization clarification, execution and limitations

The prospective D-dimensional display omitted the common loop-measure
factor N_e=exp(2 gamma_E epsilon)(Qscale²)^(2epsilon). The corrected equation
and its exact one-loop normalization derivation are in
NORMALIZATION_CLARIFICATION.md. P2 and all computed epsilon0 convergent
derivatives are unchanged because N_0=1. No source, table, physical input or
receipt was edited. The omitted factor would matter in a Laurent expansion
and is mandatory for the next calculation. This is a retained scientific
presentation correction, not a failed numerical worker.

Primary vertices use literal physical rho products; replay uses sparse
coordinate joins and opens/closes the scalar projector contraction. Primary
P2 uses endpoint current algebra; replay uses explicit two-plane Lorentz
matrices. Their full symbolic tables agree exactly. The two numerical
neutral methods share the same action, convention, spectrum, standard heat
premise, SymPy/mpmath and AI authorship. Qualified scalar SM frame, projectors
and master conventions remain inherited premises, not freshly reconstructed
physics. No external scientist, Lean certificate or empirical confirmation.

Primary literature comparator: [Krasnansky, hep-th/0607230](https://arxiv.org/pdf/hep-th/0607230),
equations2.2--2.4, explicitly treats propagator AND vertex background terms.
Its self-dual QED simplifications and finite renormalization are not adopted
for this Spin(10) calculation. Our off-diagonal derivation/PDE checks and
actual model weights are the evidence here; that paper is not their proof.

Commands python -B prepare.py, run.py kernel, run.py numeric, run.py validate,
then run_dimensional_control.py. Kernel25.1203718/32.3939900s, numerics
29.6202003/47.1251116s, verifier22.4378391s after imports; supplemental
control0.5351939s. Caps180/300/300/60s respectively. Sampled private maxima
65871872/67584000/52510720/65294336/67125248B for13/17/16/25/12 samples;
these are not continuous peak measurements. All passed8GiB sampled and
350MiB launch-floor rules.2401 initialbindings frozen before science;
whole package below4MiB. No failed scientific worker, verifier or timeout.
The short dimensional supplement has only one425984B sample at launch;
it does not establish its body/peak allocation. That sampling limit is retained.

Kernel tables6424raw/1342gzip bytes, rawSHA
3abb2111fdd13030b56b420e89b066934cbf7e7c5e19c4b5de3cf3d9ed92c19c.
Primary numeric6399raw/1583gzip, rawSHA
e0f44e815bf231d539460c60e215915f5ba53bc15915b4c7d4f7b68c38c82b55.
Replay numeric7232raw/1733gzip, rawSHA
ae5784d3dc3634e873625646e823b92fe0a3a95606d159409da7f6992857cdd7.
Different numeric tables preserve the distinct neutral sector expressions.

No VSP1, FCI1, HTB1 or EAT1 subtotal was edited or reintegrated. Continue
with C_parent-C_VVSS alongside R_VVSS, not duplicate graph-local subtraction.
Full finite VSS, light/multisoft/EFT matching, remaining primitive families,
general-width checks, finite f_fin/field/reference conditions, nonlinear
matching and the local background counterterm remain open. Full C1 is null,
E5/A5 unqualified, HB1/C5 blocked, flavor humanpaused. QuartetFAIL3960/648,
scalar140%/Euclidean1.94%/timelike20.27%, matching.745476 and missing Yukawas
remain distinct. e4 completed six expected exits, no fresh old physics replay;
custody exit2/seven unresolved is NOT PASS. No foundation, action, point,
physical scheme, scientific authority, main branch, remote or publication
change. The full investigation goal remains active and incomplete.
