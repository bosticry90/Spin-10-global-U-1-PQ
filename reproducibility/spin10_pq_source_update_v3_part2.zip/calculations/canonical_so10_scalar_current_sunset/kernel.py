"""SCP1 independent current endpoint and Lorentz-matrix kernel routes."""
from data import *
def primary_kernel():
    a,b,c=1/st,1/tt,1/ut;h=a+b+c
    j0=(a+b-(a-b)**2/h)/2;dh=(q1*q1*st+q2*q2*tt+qv*qv*ut)/3
    j2=((q1*q1*st+q2*q2*tt)/3-(2*(a-b)*(q1*q1*st-q2*q2*tt)/3+(q1-q2)**2)/h+(a-b)**2*dh/h**2)/2
    j1=(q1+q2-2*(a-b)*(q1-q2)/h)/2
    orbital=-(q1*q1*st*st+q2*q2*tt*tt+qv*qv*ut*ut)/6-dh/h
    pieces={'scalar_current':2*j2,'vector_spin':4*qv*qv*ut*ut*j0,'spin_current_cross':-4*qv*ut*j1,'orbital_gaussian':D*j0*orbital}
    return clean(D*j0),{k:clean(v) for k,v in pieces.items()}
def replay_kernel():
    B=s.Symbol('B');J=s.Matrix([[0,1],[-1,0]]);I=s.eye(2);h=1/st+1/tt+1/ut
    d=(q1*q1*st+q2*q2*tt+qv*qv*ut)/3
    H1=I*(1/st+B*B*q1*q1*st/3);H2=I*(1/tt+B*B*q2*q2*tt/3)
    L1=H1+s.I*q1*B*J;L2=H2+s.I*q2*B*J
    R1=H1-s.I*q1*B*J;R2=H2-s.I*q2*B*J
    Hinv=I*(1/h-B*B*d/h**2)
    current=(L1+L2-(L1-L2)*Hinv*(R1-R2).T)/2
    spin0=I;spin1=2*s.I*qv*ut*B*J;spin2=2*qv*qv*ut*ut*B*B*I
    j0=(1/st+1/tt-(1/st-1/tt)**2/h)/2
    z2=-(q1*q1*st*st+q2*q2*tt*tt+qv*qv*ut*ut)/6-d/h
    pieces={'scalar_current':s.expand(s.trace(current)).coeff(B,2),
      'vector_spin':s.expand(s.trace(spin2.T*current)).coeff(B,2),
      'spin_current_cross':s.expand(s.trace(spin1.T*current)).coeff(B,2),
      'orbital_gaussian':D*j0*z2}
    return clean(s.trace(current).subs(B,0)+(D-2)*j0),{k:clean(v) for k,v in pieces.items()}
def main():
    start=begin();role=sys.argv[1];assert role in ['primary','replay'];d,rho,E,P,Rh,Ty=setup(role)
    c=s.sqrt(s.Rational(3,5));charges=[-2*c,-c,c,2*c];Hmass=s.Rational(426075291,62500000)
    H=dec(packed(CAL/'canonical_so10_scalar_quadratic_pullback'/f'{role}_tables.json.gz')['matrices']['H']);O=dec(d['vacuum']['orbit']);W=O*O.T
    for i,q in enumerate(charges):
        zero(Rh*E[:,i]-s.I*q*E[:,i]);zero(H*E[:,i]-(Hmass if i in [0,3] else 0)*E[:,i])
        zero(W*E[:,i]-(s.Rational(3,10) if i in [1,2] else 0)*E[:,i])
    print('STAGE actual_singlets_and_720_vertices',flush=True)
    A={}
    for i in range(4):
        for j in range(4):
            if role=='primary':V=tidy(s.SparseMatrix(45,1,{(a,0):(E[:,i].T*rho[a]*E[:,j])[0] for a in range(45)}))
            else:
                out={};ei=E[:,i].todok();ej=E[:,j].todok()
                for a,R in enumerate(rho):
                    z=sum((ei.get((k,0),0)*v*ej.get((l,0),0) for (k,l),v in R.todok().items()),s.S.Zero)
                    if z:out[a,0]=z
                V=tidy(s.SparseMatrix(45,1,out))
            A[i,j]=V
    weights=[];bad=[];opened_cache={};wrong_vertices={}
    for i in range(4):
        for j in range(4):wrong_vertices[i,j]=tidy(s.SparseMatrix(45,1,{(a,0):(E[:,i].H*rho[a]*E[:,j])[0] for a in range(45)}))
    for r,Pr in enumerate(P):
        for i in range(4):
            for j in range(4):
                if role=='primary':v=red((A[i,j].T*Pr*A[i,j].conjugate())[0])
                else:
                    if (r,j) not in opened_cache:
                        Sj=E[:,j]*E[:,j].H;opened=s.SparseMatrix(328,328,{})
                        for (a,b),z in Pr.todok().items():opened+=z*rho[a]*Sj*rho[b].T
                        opened_cache[r,j]=opened
                    opened=opened_cache[r,j]
                    v=red(s.trace(opened*(E[:,i]*E[:,i].H).T))
                assert v.is_nonnegative or v==0,(r,i,j,v)
                q=-(charges[i]+charges[j]);Z=Pr*A[i,j].conjugate();zero(Ty*Z-s.I*q*Z)
                weights.append([r,i,j,str(v),str(q)])
                # Incorrect Hermitian replacement of real-metric transpose.
                wrong=wrong_vertices[i,j]
                badv=red((wrong.T*Pr*wrong.conjugate())[0])
                if badv!=v:bad.append([r,i,j,str(badv-v)])
    assert bad
    get=lambda r,i,j:s.sympify(next(z[3] for z in weights if z[:3]==[r,i,j]))
    neutral=red(get(2,0,3)+get(2,3,0));charged=red(sum(get(1,i,j) for i,j in [(0,2),(2,0),(3,1),(1,3)]))
    assert neutral>0 and charged>0
    print('STAGE ordered_heat_kernel',flush=True)
    K0,pieces=(primary_kernel if role=='primary' else replay_kernel)();P2=clean(sum(pieces.values()))
    assert clean(K0-D*(st+tt+4*ut)/(2*(st*tt+st*ut+tt*ut)))==0
    assert clean(P2-P2.xreplace({st:tt,tt:st,q1:q2,q2:q1}))==0
    assert clean(P2-P2.xreplace({q1:-q1,q2:-q2,qv:-qv}))==0
    save(role,'kernel',{'schema':'SCP1_KERNEL','charges':list(map(str,charges)),'scalar_block_ids':[0,1,3,4],
      'physical_scalar_mass_squared':str(Hmass),'Goldstone_mass_over_g2':'3/10','neutral_vector_mass_over_g2':'3/2',
      'vertices':[[i,j,enc(A[i,j])] for i in range(4) for j in range(4)],'weights':weights,
      'neutral_total_color':str(neutral),'charged_total_color':str(charged),
      'wrong_Hermitian_vertex_control':bad,'K0':str(K0),'P2':str(P2),'pieces':{k:str(v) for k,v in pieces.items()},
      'raw_placements':{'edge':15,'edge_vertex':12,'vertex_vertex':2,'total':29},
      'finite_C1_or_full_sunset_qualified':False},start)
if __name__=='__main__':main()
