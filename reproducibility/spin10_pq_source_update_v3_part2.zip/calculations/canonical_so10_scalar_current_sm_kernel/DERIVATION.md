# SCM1: exact H-commutant current maps before spectral integration

Let Q be SMF1's full frame, D=Q.HQ its diagonal kinetic Gram matrix,
Qi=D^-1Q.H, and W=Q D^-1/2 a unitary frame. Each class alpha has dimension
d_alpha and multiplicity m_alpha. There are35 classes,65 seeds and
sum m_alpha²=177 matrix units E(alpha,i,j), inflated equally at every irrep
state. Their full traces are d_alpha delta_ij. The actual H action is identical
on the multiplicity copies; these units span its COMPLEX commutant. Physical
real scalar mass functions form the inherited conjugation-compatible subspace.

For a real symmetric H-invariant color matrix M define

```
Gamma_M(X)=-sum_ab M_ab rho_a X rho_b.
```

The matrices are the five actual vector mass projectors P_r and their15
positive charge insertions P_r C_v,i, C_v,i=-sum_(h in ideal_i) ad_h²/n_i,
n_i=(1,3,8). VSP's B_r,i uses the OPPOSITE sign. H covariance follows from
the inherited actual representation commutator and [M,ad_h]=0. Thus Gamma_M
maps the177-dimensional space to itself, without assuming [X,rho_a]=0 or
[X,Gamma_M(I)]=0. H-invariant does not mean proportional to the identity in
the multiplicity directions.

## Two complete coefficient constructions

For a normalized highest-state seed e_alpha,i, set U_a=W.Hrho_a E_seed.
With row(beta,n,k),

```
K_M[alpha i j; beta k l]
 = sum_ab,n M_ab conjugate(U_a[beta n k,alpha i]) U_b[beta n l,alpha j].
```

Replay uses R_a=Qi rho_a Q and sums ALL alpha states v as well as beta states n:

```
K_M[alpha i j; beta k l]
 = -sum_ab,v,n M_ab R_a[alpha v i,beta n k]
                         R_b[beta n l,alpha v j]/d_alpha.
```

This is a signed operator trace in a nonorthogonal frame, not a Hermitian
Gram shortcut. Its kinetic adjoint is R_a.H D+D R_a=0. The two derivations
must agree on every matrix unit, including zeros. Bilinear trace duality gives
d_alpha K[alpha i j;beta k l]=d_beta K[beta l k;alpha j i]. Hermitian conjugation
reverses both index pairs. These conditions are checked rather than inferred
from the final amplitude.

For a physical real mass function F(s)=exp[-s Mscalar²], the species weight is
Tr[F(s) Gamma_M(F(t))]. In complex coordinates this retains the same328-real
trace and Wick factors. Hermitian-current class indices relabel the FIRST
real-bilinear charge by conjugation; test the80 SCP four-scalar positions with
that relabeling. No new656-real-field interpretation is introduced.

## The ordered kernel needs only three squared-charge weights

At an actual real-field vertex q1+q2+qv=0. Substitute qv=-q1-q2 into the
qualified P2 and write Aq1²+Bq2²+Cq1q2. Then

```
P2=(A-C/2)q1²+(B-C/2)q2²+(C/2)qv².
```

An independent construction evaluates P2 at(-1,1,0),(1,0,-1),(0,1,-1)
and solves for the same three coefficients. Their exchange symmetry and
general-D derivative factors are preserved.

Ideal averaging gives scalar endpoint weights c_i,alpha Gamma_P_r and
Gamma_P_r c_i,beta, where c_i,alpha=-sum rho_h²/n_i on that actual irrep.
Compute these Casimirs from the action and compare to its actual labels and
dimensions. The vector weight is Gamma_(P_r C_v,i); mass degeneracy alone
does not fix C_v,i. This constructs the three weights for all gauge ideals
without diagonalizing arbitrary multiplicity matrices or assuming a closed
subrepresentation for the earlier four-field restriction.

Contracting the input identity must reproduce every VSP A_r and NEGATIVE B_r,i
block. This supplies independent marginal checks on the complete kernel.
Mass/projector inputs are kept as full small matrices, not commuting scalar
eigenvalues. The six coarse scalar types are physical-positive, soft and four
Goldstone mass projectors; they define180 typed support profiles, while the
177-unit kernel still retains their unresolved physical spectral information.

## A full-model branch follows if the light-map gates pass

Because unbroken generators commute with X in the H-commutant,

```
Gamma_P0(X)=C_H X, C_H=c_U1+3c_SU2+8c_SU3.
```

The quantum-light adjoint charge insertions give Gamma_V0,U1=0 and, in the
actual normalization, Gamma_V0,SU2=2c_SU2 and Gamma_V0,SU3=3c_SU3 as maps.
Test these full177-by177 identities. Only the first two are used for the U1
amplitude. They imply mass spectral projectors are paired diagonally, and all
light quantum vectors are neutral under the external Y background. SLI1's
unit(0,-1,4/3) with finite scale term-2j_m therefore applies to EVERY positive
scalar mass in this branch, not just its four example columns.

Put w_alpha=(3/2)d_alpha c_U1,alpha C_H,alpha. Let Wp sum w over the290
physical-positive directions, Wr over each Goldstone projector, Wg=sum Wr,
and Wtot=Wp+Wg. Define

```
Jp=sum_alpha w_alpha Tr[Pphysical log(H/60)]
Jg=sum_r Wr log(lambda_r/60),
```

with actual Goldstone masses g²lambda_r and L=log(Q²/60),U=log(g²).
No matrix-log zero eigenvalue is taken: use H+60(I-Pphysical), so its null
augmentation contributes log1=0. All eigenvalues of that augmented operator
must be positive. Independent eigenvalue and Cholesky logdet routes retain
all mixing and agree on Jp; the determinant method is valid because w_alpha
is a scalar on that entire class, not on an arbitrary noncommuting insertion.

In Lambda2/g² units the branch coefficients(pole,finite constant,L,U) are

```
bare   =(-Wtot, 4Wtot/3+2(Jp+Jg), -2Wtot, 2Wg),
forest =(-Wtot, Jp+Jg,           -Wtot,   Wg),
Rprime =(-2Wtot,4Wtot/3+3(Jp+Jg),-3Wtot, 3Wg).
```

The vector remaining-loop CT F² trace is zero by ACTUAL U1 neutrality of P0,
not a massless extrapolation of a positive-mass heat theorem. Scalar CTs
are the qualified -2C_H derivative and C_H Mscalar² mass loop operators;
their closure has effective CT mass-3C_H Mscalar². No coefficient is fitted.

The five soft scalar directions require a separate matching disposition.
Gamma_P0=c_H implies mixed physical/soft and Goldstone/soft traces vanish
by orthogonal mass projectors. The all-soft tree current is the actual
restriction of rho_H to the soft carrier with its induced canonical metric.
Under the existing common tree EFT restriction, this SAME density, its
propagators, IR mass delta>0 and graph-local UV operation occur on both sides.
The all-soft bare and forest DIFFERENCES cancel before delta->0; neither
isolated graph is called zero. This is a proof for this actual branch, not a
new general QAP, global auxiliary-mass scheme or full matching theorem.

The branch still has its overall pole; no overall or finite CT is adopted.
The other quantum-vector mass sets, external gauge ideals, primitives and
full C1 remain outside this finite branch result. Do not add it on top of
the already counted SLI four-scalar light subset: that subset is contained
in the present full domain. Parent VVSS forests still require their recorded
parent-minus-current coordination.
