# SCM1: full scalar mixing kernels and a complete U1 light-vector branch

The scalar-current investigation now has exact contraction maps for the FULL
328-real-scalar carrier, rather than only the previously completed four-scalar
restriction. The maps retain all35 SM classes and multiplicity mixing. They
also establish the conditions needed to extend the qualified neutral light-
vector integral to every positive scalar mode in the U1 branch.

Two calculation routes and a separate verifier completed. The final
validation_receipt.json SHA256 is
`9f36782c49c2afacd291cf692a86c57e27e16df6d174ea55cc3920df85596a33`.
The result is bounded computational qualification, not director acceptance,
the full VSS family, finite C1_GS or E5/A5. State113 and34/39 are unchanged.

## Full-domain reduction

The actual SM decomposition has35 classes and65 highest-state seed columns.
All matrices that commute with the unbroken H action are represented by177
independent multiplicity matrix units. These span the complexification used
to calculate physical real-compatible mass functions; they do not introduce
177 new particles or double the328-real-field carrier.

For each vector mass projector and each of its three background charge
insertions, the calculation constructs

```
Gamma_M(X) = -sum_ab M_ab rho_a X rho_b.
```

There are20 complete177-by177 maps:626580 coefficient positions,3188
nonzero and623392 zero. The zero complements and every nonzero coefficient
agree between the two derivations. A nonzero raw current count is not an
independently measured loop or a physical observation.

The general ordered heat kernel needs only three squared-charge weights,
q1²,q2²,qv², after using the actual vertex identity q1+q2+qv=0. Scalar
endpoint weights follow from the ACTUAL irrep Casimirs; the vector weight
uses its full adjoint insertion. A degenerate vector mass set is not assumed
to have one common hypercharge or Casimir. The general-D polynomial and
scalar-edge exchange symmetry are retained.

Input identity contractions reproduce all20 previously qualified VSP
operators on all35 multiplicity blocks, with the correct sign for its B
operators. This is an independent marginal check, not how the new kernel
coefficients were selected. The old80-position four-scalar inventory is also
recovered, including its zeros, using conjugation of the first real-bilinear
slot. That prevents a Hermitian-vs-real field-coordinate error.

The coarse physical mass-type inventory retains290 potential-positive,
5 soft and33 gauge-fixing-positive directions. The latter have ranks
8,1,12,12 at their four actual masses. Across five vector mass sets and
six scalar types on each edge,55 of180 raw profiles have nonzero support:

| Vector mass set | Nonzero coarse profiles |
|---|---:|
|0, light|5|
|1|16|
|2, neutral massive|8|
|3|11|
|4|15|

This is a support classification, not55 newly measured amplitudes. Physical
eigenvalues inside the potential-positive class remain resolved through the
full multiplicity matrices, not this coarse table. Some raw profiles have
zero field-strength charge and need no F² amplitude.

## The light-current maps prove a useful full-model identity

On the complete H-commutant the actual light-vector map is

```
Gamma_P0(X) = C_H X,
C_H = c_U1 +3c_SU2+8c_SU3.
```

The charge-inserted light maps are0 for external U1,2c_SU2 for external
SU2, and3c_SU3 for external SU3. These are full177-by177 map checks,
supported by direct checks of all12 H generators, their action on all
multiplicity copies, color invariance and the actual representation
commutators. They are not dimension-only or diagonal-field probes.

For U1 this means the quantum-light vector is neutral under the background
and its scalar mass projectors pair diagonally. Thus SLI1's unit bare
coefficient(0,-1,4/3), with finite scale term-2log(Q²/m²), applies to all
323 positive scalar directions in this branch. The five soft directions
require their separate matching disposition below. No analogous finite
result for external SU2/SU3 is inferred from the U1 calculation.

## Actual finite U1 coefficients

Keep the same action, xi1 reference, fixed scalar point and dimensional
normalization. With L=log(Q²/60), U=log(g10²), the contribution is g10²
times the coefficients below in the existing Lambda=-12Gamma_F²/(ell²g10²)
normalization. The trace still uses Fphys²=2B² and the original real Wick
weights. No coupling or subtraction scale is chosen.

The exact positive scalar weights are

```
Wphysical =36639/100,
WGold=(123/25,0,75/4,63/100),
WGold,total=243/10,
Wpositive=39069/100.
```

The actual mass-log sums are

```
Jphysical=-635.52751844815132248870999633787048250384378377141,
JGold=     -43.026790573689798710519884431180018861479474009728.
```

Both methods retain all mass mixing. The positive-space log trace is
calculated with H+60(I-Pphysical), whose null-space augmentation becomes1
after division by60 and contributes log1=0. It does not change any physical
mass. One route sums eigenvalue logs; the other uses a Cholesky logdet. The
separate verifier uses a direct determinant. This reduction is valid here
because its weight is a scalar on each ENTIRE SM class; it must not be
transferred to arbitrary noncommuting insertions in the other mass sets.

The resulting coefficients are:

| Contribution | Pole | Finite constant | L | U |
|---|---:|---:|---:|---:|
|Bare| -39069/100 | -836.18861804368224239845976153810100273064651556227 | -39069/50 | 243/5 |
|Proper-subgraph forest| -39069/100 | -678.55430902184112119922988076905050136532325778114 | -39069/100 | 243/10 |
|R-prime sum| -39069/50 | -1514.7429270655233635976896423071515040959697733434 | -117207/100 | 729/10 |

The remaining overall pole is retained. No overall or finite counterterm
has been adopted, and these partial coefficients are not a physical gauge-
unification prediction. This calculation evaluates new model-wide color
and mass contractions using the previously qualified loop integral; it does
not claim fresh independent loop integrations for every scalar mode.

## The soft sector has an actual matching disposition

The soft scalar current has weight81/100, which is nonzero before matching.
The actual projector has rank5, is real and orthogonal, commutes with the
unbroken generators, and has zero gauge-orbit image. Mixed soft/positive
assignments vanish through the actual orthogonal mass projectors and the
proved light-current map, not an assumption about diagrams with light fields.

The all-soft density is exactly the restriction of rho_H to that carrier
with its induced kinetic metric. Under the existing common tree EFT
restriction, the same current, metric, propagators and positive auxiliary
IR mass occur on both sides. Therefore the all-soft bare graph AND its
graph-local proper forests cancel as DIFFERENCES before the IR mass is
removed. Neither isolated all-soft graph is called a scaleless zero.

This is a matching argument for this actual primitive branch. It is not a
global auxiliary-mass prescription, a full EFT/QAP theorem or a replacement
for the remaining one-loop matching insertions and nonlinear conversion.
The positive-scalar light-vector limit retains SLI1's infrared bounds; no
uniform g->0 or massless-scalar extension is asserted.

## Verification and sensitivity

Primary projects ambient currents on normalized highest-state seeds. Replay
uses literal signed traces over every irrep state in the NONorthogonal SM
frame, with inverse D^-1Q.H and the explicit irrep-dimension division. The
separate verifier checks covariance, the full commutant, trace-dual exchange,
conjugation and all marginal operators. It independently closes ambient
physical-H and soft operators, including off-class zero blocks, and checks
the mass logarithms and actual old four-scalar coefficients.

The meaningful controls detect:

* Q.H used as the inverse instead of D^-1Q.H:34 changed kernel positions.
* Omitted full-irrep division:148 changed positions in the light map.
* Dropped off-diagonal multiplicity inputs:60 changed actual H-image entries.
* Collapsed two mass slots into a one-slot marginal:106 changed H-image entries.

These are model-specific failures of tempting simplifications. All20 maps
and their zeros agree exactly. Numeric finite coefficients are compared at
1e-40 with80-digit working precision and50-digit displays. The largest
reported scaled discrepancy is1.36057487957170684074366615718e-50, including
display rounding; it is not a rigorous uncertainty interval or a statement
of physical accuracy.

The methods share the action, fixed point, frame/projectors, inherited heat
and master assumptions, software and AI authorship. Their agreement does
not independently establish those premises or physical viability. No outside
scientist, Lean certificate or experimental confirmation is claimed.

## Assembly, execution and remaining work

This full U1 light-vector result CONTAINS the earlier SLI1 four-scalar light
subset; adding both would double count it. For any proper-subtracted family,
the correct relation to an existing full parent-counterterm subtotal is

```
B_family+C_parent = Rprime_family+(C_parent-C_family).
```

If several proper-subtracted families are grouped, subtract each included
forest from the parent subtotal once. No existing full threshold subtotal,
source functional or authority file was modified in this increment. The
VVSS parent-minus-current coordination and other prescribed counterterms
remain necessary. The new branch has not been blindly added to them.

Sources and2569 input bindings were frozen before computation. Commands:
`python -B calculations/canonical_so10_scalar_current_sm_kernel/prepare.py`,
then `run.py`. These exclusive completed controllers must not be rerun over
their output paths. Primary/replay/verifier completed in58.7710982 /
88.9833383 /105.4728844 seconds under their new600-second full-domain caps.
No preparation, native or verifier execution failed. Private allocations
were sampled30/45/54 times, maxima96,960,512 /103,804,928 /132,386,816 bytes;
these are not continuous peaks. The8GiB sampled cap,350MiB launch floor and
4MiB package bound were respected.

Delegated e4 retains its six expected exits and historical custody exit2/
seven unresolved references, not overall PASS. It is evidence authentication,
not fresh replay or scientific acceptance of the new result.

The next useful target is a complete remaining branch selected from the
actual maps. The neutral massive vector(r2) has zero background charge,
and only six coarse profiles carry F². Its soft/soft assignment requires
actual one-soft matching before a massless limit; mass-type support must
not be mistaken for momentum-region support. The neutral Fourier master
and new full mixing map provide a route without another component tensor.
Full VSS/C1, other primitives, finite normalization and physical matching
remain open. Authority34/39, E5/A5, HB1/C5, flavor pause, historical quartet
failure and scalar quantum-control limitations retain their prior scopes.
