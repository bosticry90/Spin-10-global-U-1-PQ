"""SCM1 separate actual covariance, map, physical probe and determinant audit."""
from data import *

def main():
    start=begin('validation_preparation.json',600);mp.mp.dps=80
    A,B=[packed(HERE/(role+'_tables.json.gz')) for role in ['primary','replay']]
    for key in ['basis','kernels','scalar_Casimir_averages','charge_square_kernel_coefficients','physical_probes']:assert A[key]==B[key],key
    values,color,Ms,fci=inputs('primary');d,rho,V,ad,Ps,frame,Q,Qi,E=values
    basis=[tuple(v) for v in A['basis']];address={v:k for k,v in enumerate(basis)};K=list(map(dec,A['kernels']));cas=[[s.sympify(z) for z in row] for row in A['scalar_Casimir_averages']]
    assert len(basis)==177 and len(K)==20 and len(frame['blocks'])==35 and A['domain_positions']==626580
    gram=dec(frame['D']);rh=[tidy(sum((V[aa,hh]*rho[aa] for aa in range(45)),s.SparseMatrix(328,328,{}))) for hh in range(12)]
    print('STAGE actual_H_covariance_and_complete_commutant',flush=True)
    # Check the actual irrep/multiplicity action and the representation identity
    # required to prove closure; do not assume it from dimension labels alone.
    coords=[]
    for hh,Rh in enumerate(rh):
        R=tidy(Qi*Rh*Q);expected=s.SparseMatrix(328,328,{})
        for b in frame['blocks']:
            off=b['offset'];m=b['multiplicity'];n=b['dimension']
            for state in range(n):
                for copy in range(m):assert gram[off+state*m+copy,off+state*m+copy]==s.sympify(b['state_norms'][state])
            for ii in range(n):
                for jj in range(n):
                    co=R[off+ii*m,off+jj*m]
                    if co:
                        for copy in range(m):expected[off+ii*m+copy,off+jj*m+copy]=co
        zero(R-expected);coords.append(R)
        for M in Ms:zero(M*ad[hh]-ad[hh]*M)
        for aa in range(45):
            expected_r=sum((ad[hh][bb,aa]*rho[bb] for bb in range(45) if ad[hh][bb,aa]),s.SparseMatrix(328,328,{}))
            zero(Rh*rho[aa]-rho[aa]*Rh-expected_r)
        if hh in [0,3,11]:print('STAGE covariance_through_generator_'+str(hh),flush=True)
    for ideal,hs in enumerate([range(1),range(1,4),range(4,12)]):
        C=tidy(-sum((coords[h]*coords[h] for h in hs),s.SparseMatrix(328,328,{}))/len(hs))
        expected=inflate(frame['blocks'],[s.eye(b['multiplicity'])*cas[alpha][ideal] for alpha,b in enumerate(frame['blocks'])]);zero(C-expected)
    # Third independent map identities, all coefficients/zero complements.
    for op,M in enumerate(K):
        out=tidy(M*vectorize([s.eye(b['multiplicity']) for b in frame['blocks']],basis))
        expected=vectorize([dec(v)*(1 if op<5 else -1) for v in color['blocks'][op]],basis);zero(out-expected)
        entries=M.todok()
        for (row,col),z in entries.items():
            aa,ii,jj=basis[row];bb,kk,ll=basis[col]
            assert red(frame['blocks'][aa]['dimension']*z-frame['blocks'][bb]['dimension']*entries.get((address[bb,ll,kk],address[aa,jj,ii]),0))==0
            assert red(s.conjugate(z)-entries.get((address[aa,jj,ii],address[bb,ll,kk]),0))==0
    zero(K[0]-s.diag(*[cas[alpha][0]+3*cas[alpha][1]+8*cas[alpha][2] for alpha,ii,jj in basis]));zero(K[5])
    zero(K[6]-s.diag(*[2*cas[alpha][1] for alpha,ii,jj in basis]));zero(K[7]-s.diag(*[3*cas[alpha][2] for alpha,ii,jj in basis]))
    P=expr(packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz')['P2']);pc=list(map(expr,A['charge_square_kernel_coefficients']))
    assert clean((P-sum(c*z*z for c,z in zip(pc,[q1,q2,qv]))).subs(qv,-q1-q2))==0
    assert clean(pc[0].subs({st:tt,tt:st},simultaneous=True)-pc[1])==0 and clean(pc[2].subs({st:tt,tt:st},simultaneous=True)-pc[2])==0
    print('STAGE independent_ambient_physical_mass_and_soft_probes',flush=True)
    seeds65=[b['offset']+j for b in frame['blocks'] for j in range(b['multiplicity'])]
    one=[s.eye(b['multiplicity']) for b in frame['blocks']];softs=[dec(b['soft']) for b in fci['blocks']];Hs=[dec(b['H']) for b in fci['blocks']]
    Soft=tidy(Q*inflate(frame['blocks'],softs)*Qi);zero(Soft*Soft-Soft);zero(Soft-Soft.H);zero(Soft.conjugate()-Soft);assert red(s.trace(Soft))==5
    zero(dec(d['vacuum']['orbit']).T*Soft);zero(V*V.T-Ps[0]);zero(V.T*V-s.eye(12));zero(ad[0]*Ps[0])
    for Rh in rh:zero((s.eye(328)-Soft)*Rh*Soft)
    ambient=[R*E for R in rho]
    for tag,blocks in [('mass',Hs),('soft',softs)]:
        F=tidy(Q*inflate(frame['blocks'],blocks)*Qi);right=[F*X for X in ambient]
        @lru_cache(256)
        def pair(aa,bb):return ambient[aa].H*right[bb]
        for op in [0,1,2,3,4,5,6,7]:
            direct=tidy(sum((co*pair(aa,bb) for (aa,bb),co in Ms[op].todok().items()),s.SparseMatrix(65,65,{})))
            expected=s.diag(*blocks_from_vector(tidy(K[op]*vectorize(blocks,basis)),frame,address));zero(direct-expected)
    # Recover the old four-real-scalar inventory using the correct conjugation
    # of the first real-bilinear slot, INCLUDING every old zero.
    old=packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz');lookup={(rr,ii,jj):(s.sympify(z),s.sympify(q)) for rr,ii,jj,z,q in old['weights']}
    classes=[0,1,3,4];conj=[3,2,1,0]
    for rr in range(5):
        for ii,alpha in enumerate(classes):
            for jj,beta in enumerate(classes):
                co=red(K[rr][address[alpha,0,0],address[beta,0,0]])
                expected,q=lookup[rr,conj[ii],jj];assert co==expected,(rr,ii,jj,co,expected)
                actual=red(K[5+3*rr][address[alpha,0,0],address[beta,0,0]])
                assert actual==red(co*q*q)
    assert dec(A['physical_probes']['diagonal_only_H_loss']).todok() and dec(A['physical_probes']['collapsed_two_slot_H_loss']).todok()
    wrong=dec(B['wrong_inverse_QH_kernel_A0']);assert tidy(wrong-K[0]).todok()
    # Missing full-irrep division changes the full map wherever d_alpha>1.
    nodim=s.SparseMatrix(177,177,{(i,j):frame['blocks'][basis[i][0]]['dimension']*z for (i,j),z in K[0].todok().items()});assert tidy(nodim-K[0]).todok()
    profiles=A['physical_probes']['profiles'];assert len(profiles)==180
    for row in profiles:
        if row['r']==0 and (row['left']=='soft')!=(row['right']=='soft'):
            assert s.sympify(row['raw'])==0 and all(s.sympify(v)==0 for key in ['q1_squared','q2_squared','qv_squared'] for v in row[key])
        if row['r']==0:assert s.sympify(row['qv_squared'][0])==0
    print('STAGE full_U1_light_branch_determinant_and_matching',flush=True)
    amps=[v['U1_quantum_light_vector_branch'] for v in [A,B]];maxerr=mp.mpf(0);Jp=mp.mpf(0);root=point_root();Wp=s.S.Zero;Wr=[s.S.Zero]*4;Ws=s.S.Zero
    for alpha,b in enumerate(fci['blocks']):
        H=dec(b['H']);Phy=dec(b['physical']);Aug=H+60*(s.eye(H.rows)-Phy)
        val=mp.det(numeric(Aug/60,root));val=real(val);assert val>0
        weight=red(s.Rational(3,2)*b['dimension']*cas[alpha][0]*(cas[alpha][0]+3*cas[alpha][1]+8*cas[alpha][2]))
        actual=real(number(weight,root))*mp.log(val);Jp+=actual
        Wp+=weight*s.trace(Phy);Ws+=weight*s.trace(dec(b['soft']));Wr=[red(x+weight*s.trace(dec(y))) for x,y in zip(Wr,b['gold_mass_projectors'])]
        for amp in amps:
            measured=mp.mpf(amp['rows'][alpha]['weighted_positive_logdet']);err=abs(measured-actual)/(1+abs(actual));maxerr=max(maxerr,err);assert err<mp.mpf('1e-40')
    Wp,Ws=map(red,[Wp,Ws]);Wg=red(sum(Wr));Wt=red(Wp+Wg)
    Jg=sum(real(number(wr,root))*mp.log(real(number(s.sympify(lam),root))/60) for wr,lam in zip(Wr,fci['vector_mass_eigenvalues']))
    for amp in amps:
        assert s.sympify(amp['Wp'])==Wp and s.sympify(amp['Wsoft'])==Ws and s.sympify(amp['Wg'])==Wg and s.sympify(amp['Wpositive'])==Wt
        assert list(map(s.sympify,amp['Wr']))==Wr
        wn,gn=real(number(Wt,root)),real(number(Wg,root))
        expectations={'bare':[-wn,4*wn/3+2*(Jp+Jg),-2*wn,2*gn],
          'forest':[-wn,Jp+Jg,-wn,gn],'Rprime':[-2*wn,4*wn/3+3*(Jp+Jg),-3*wn,3*gn]}
        for name,coeff in expectations.items():
            for v,z in zip(amp['coefficients'][name],coeff):
                target=mp.mpf(str(s.N(z,85))) if isinstance(z,s.Basic) else z
                err=abs(mp.mpf(v)-target)/(1+abs(target));maxerr=max(maxerr,err);assert err<mp.mpf('1e-40')
    # The all-soft tree/EFT identity is at the SAME induced metric, vertices,
    # propagators and delta>0; identical kernels give identical UV projections.
    # It is not an isolated scaleless zero or a theorem about other branches.
    assert red(pairing(softs,K[0]*vectorize(softs,basis),basis,frame,[row[0] for row in cas])*s.Rational(3,2)-Ws)==0
    sli=read(CAL/'canonical_so10_scalar_current_light_vector/validation_receipt.json');assert sli['unit_bare_Laurent']==['0','-1','4/3']
    value={'schema':'SCM1_VALIDATION','execution_state':'COMPLETED',
      'status':'QUALIFIED_FULL_SCALAR_COMMUTANT_KERNEL_AND_U1_QUANTUM_LIGHT_BRANCH',
      'elapsed_after_imports':time.perf_counter()-start,'classes':35,'seed_columns':65,'real_scalar_dimension':328,
      'commutant_dimension':177,'maps':20,'complete_map_positions':626580,'map_nonzero':[len(v.todok()) for v in K],
      'coarse_profiles':180,'coarse_nonzero_profiles':sum(s.sympify(v['raw'])!=0 for v in profiles),
      'physical_counts':A['physical_probes']['counts'],'actual_H_generators_checked':12,
      'wrong_inverse_kernel_change_entries':len(tidy(wrong-K[0]).todok()),
      'missing_irrep_division_change_entries':len(tidy(nodim-K[0]).todok()),
      'diagonal_only_H_loss_entries':len(dec(A['physical_probes']['diagonal_only_H_loss']).todok()),
      'collapsed_mass_slot_loss_entries':len(dec(A['physical_probes']['collapsed_two_slot_H_loss']).todok()),
      'U1_quantum_light_vector_branch':amps[0],'determinant_route_scaled_error':mp.nstr(maxerr,30),
      'all_soft_cancellation_scope':'same induced tree EFT metric/current and shared positive IR mass before limit',
      'full_VSS_or_C1_or_E5_qualified':False,'overall_counterterm_adopted':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(value,sort_keys=True),flush=True)
if __name__=='__main__':main()
