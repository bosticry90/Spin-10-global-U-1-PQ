"""Freeze SCM1 complete-domain sources and immutable ancestry before calculation."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
BASE='229664ef50a78ffd5ebc7725a0a10aa212355ce7'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-sm-kernel-v1-2026-10-20')
def dump(p,raw):
    with p.open('xb') as f:f.write(raw)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
p=CAL/'canonical_so10_scalar_current_light_vector/validation_preparation.json';deps={str(p):sha256(p.read_bytes()).hexdigest()}
for n,h in json.loads(p.read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n;deps[n]=h
direct=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V409.md',
 'calculations/canonical_so10_scalar_current_light_vector/validation_receipt.json',
 'calculations/canonical_so10_scalar_current_light_vector/RESULT.md','calculations/canonical_so10_scalar_current_light_vector/NEXT_RESEARCH_QUESTION.md',
 'calculations/canonical_so10_vector_scalar_quartic/validation_receipt.json','calculations/canonical_so10_vector_scalar_quartic/controls_receipt.json',
 'calculations/canonical_so10_vector_scalar_quartic/data.py','calculations/canonical_so10_vector_scalar_quartic/DERIVATION.md',
 'calculations/canonical_so10_vector_scalar_quartic/RESULT.md','calculations/canonical_so10_scalar_sm_frame/validation_receipt.json']
for name in direct:p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['prepare.py','run.py','data.py','primary.py','replay.py','verify.py','RECORD.md','DERIVATION.md']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb,filename=str(p))
    dump(HERE/(name+'.source.txt'),bb)
    for q in [p,HERE/(name+'.source.txt')]:deps[str(q)]=sha256(q.read_bytes()).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==25819
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
value={'schema':'SCM1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'native_seconds':600,'verifier_seconds':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,
 'whole_package_bytes':4*1024**2,'pair_cache_maxsize':256,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;25819oldblobs;no science executed')
