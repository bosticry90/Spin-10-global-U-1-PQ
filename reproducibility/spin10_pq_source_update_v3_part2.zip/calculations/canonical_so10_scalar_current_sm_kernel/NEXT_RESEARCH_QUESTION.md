# After SCM1: use the full maps to close a complete neutral massive branch

SCM1 supplies complete20 maps on the177-dimensional H commutant across the
full328-real scalar carrier and a full U1 quantum-light-vector contribution.
The new branch contains SLI1's smaller light subset; do not add both. Its
R-prime pole remains and no overall/finite CT has been adopted. Reuse the
qualified maps and loop identities rather than repeating those calculations.

The actual neutral massive vector set r2 is a useful next candidate. Its
adjoint H charge insertions vanish for all three ideals; the full kernel
still retains noncommuting scalar mass mixing. Among its eight nonzero raw
coarse profiles, only these six have field-strength support:

* physical_positive/physical_positive;
* physical_positive/Gold_4 and the reversed assignment;
* Gold_1/Gold_1;
* Gold_4/Gold_4;
* soft/soft.

The zero-charge raw profiles need no F² coefficient. These coarse labels do
not resolve the individual eigenmasses within physical multiplicity blocks.
Do not diagonalize color/mass matrices together or replace Gamma_r2 by its
identity marginal. The new maps provide the exact weights for each actual
scalar spectral pair.

First derive a reusable neutral general-positive-mass bare AND forest kernel
from the authenticated SCL absolute Fourier/master formula and SCU opened
operators. Keep unequal scalar masses, the massive neutral vector, correct
epsilon-positive factors and all tadpole products. Test exact pole locality
after independent construction, without fitting to a beta coefficient.
Retain a form valid across degenerate eigenvalues, rather than dividing by
an eigenvalue difference and ignoring the coincident limit.

The soft/soft mass assignment is not an all-soft momentum-region theorem:
the vector is heavy, and one scalar momentum can be soft while the vector
and other scalar momentum are hard. Open the actual heavy-vector/soft-scalar
one-loop two-point kernel. Its UV and finite mass/derivative pieces must
supply the corresponding EFT matching insertions before the common auxiliary
IR mass is removed. The existing OSF one-soft cancellation can be reused
only after this actual input and normalization are matched. Do not set an
unknown finite Higgs coefficient to zero or count its insertion twice.
Analyze the two-soft region separately; if it is power suppressed, prove
the suppression with its logarithms/contacts rather than calling it scaleless.

Then apply the neutral finite kernel to the full35-class multiplicity data
and the six actual profile types, retaining g,L and allowed finite conditions
symbolically. A complete regulator/matching disposition is required before
qualifying the WHOLE r2 branch. A bounded underdefinition is preferable to
presenting only its convenient positive-mass part as complete.

For final assembly preserve B_family+C_parent=Rprime_family+
(C_parent-C_family); subtract all included graph forests once. Keep the
already measured VVSS and U1-light family in their exact scopes. Other
quantum-vector sets, external gauge factors, primitive families, finiteC1,
overall subtraction, physical matching and E5/A5 remain open. No new point,
finite prescription, source-functional change, HB1/C5/flavor activation or
scientific-authority promotion is justified by the contraction reduction.
