"""SCM1 normalized ambient Gram construction at highest irrep states."""
from data import *

def main():
    start=begin();role='primary';values,color,Ms,fci=inputs(role)
    d,rho,V,ad,Ps,frame,Q,Qi,E=values;basis,address,states,seeds=typed_basis(frame)
    gram=dec(frame['D']);W=Q*s.SparseMatrix(328,328,{(k,k):1/s.sqrt(gram[k,k]) for k in range(328)})
    zero(W.H*W-s.eye(328));zero(V.T*V-s.eye(12));zero(V*V.T-Ps[0])
    grouped=[];print('STAGE full_scalar_highest_state_projections',flush=True)
    for aa,A in enumerate(rho):
        U=tidy(W.H*A*E);groups={}
        for (row,col),z in U.todok().items():
            beta,n,k=states[row];alpha,i=seeds[col];groups.setdefault((beta,n,alpha),[]).append((k,i,z))
        grouped.append(groups)
    @lru_cache(256)
    def pair(aa,bb):
        out={}
        for (beta,n,alpha),xs in grouped[aa].items():
            ys=grouped[bb].get((beta,n,alpha),[])
            for kk,ii,z in xs:
                for ll,jj,t in ys:
                    pos=(address[alpha,ii,jj],address[beta,kk,ll]);out[pos]=out.get(pos,0)+s.conjugate(z)*t
        return out
    kernels=[]
    for ix,M in enumerate(Ms):
        out={}
        for (aa,bb),co in M.todok().items():
            for ij,z in pair(aa,bb).items():out[ij]=out.get(ij,0)+co*z
        kernels.append(tidy(s.SparseMatrix(177,177,out)))
        if ix%5==4:print('STAGE highest_kernel_'+str(ix+1),flush=True)
    # Scalar Casimir eigenvalues are calculated from the actual ambient generators.
    rh=[tidy(sum((V[aa,h]*rho[aa] for aa in range(45)),s.SparseMatrix(328,328,{}))) for h in range(12)]
    cas=[[None]*3 for _ in frame['blocks']]
    for ideal,hs in enumerate([range(1),range(1,4),range(4,12)]):
        C=tidy(-sum((rh[h]*rh[h] for h in hs),s.SparseMatrix(328,328,{}))/len(hs));small=tidy(E.H*C*E);blocks=[]
        for alpha,b in enumerate(frame['blocks']):
            off=b['seed_offset'];m=b['multiplicity'];v=red(small[off,off]);cas[alpha][ideal]=v
            block=small[off:off+m,off:off+m];zero(block-v*s.eye(m));blocks.append(block)
        zero(C-Q*inflate(frame['blocks'],blocks)*Qi)
    kernel_checks(kernels,frame,basis,address,color)
    hdiag=[cas[alpha][0]+3*cas[alpha][1]+8*cas[alpha][2] for alpha,ii,jj in basis]
    zero(kernels[0]-s.diag(*hdiag));zero(kernels[5]);zero(kernels[6]-s.diag(*[2*cas[alpha][1] for alpha,ii,jj in basis]));zero(kernels[7]-s.diag(*[3*cas[alpha][2] for alpha,ii,jj in basis]))
    p=packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz');P=expr(p['P2'])
    reduced=s.Poly(clean(P.subs(qv,-q1-q2)),q1,q2);aa=reduced.coeff_monomial(q1*q1);bb=reduced.coeff_monomial(q2*q2);cc=reduced.coeff_monomial(q1*q2)
    charge=list(map(clean,[aa-cc/2,bb-cc/2,cc/2]))
    assert clean(P.subs(qv,-q1-q2)-sum(z*q for z,q in zip(charge,[q1*q1,q2*q2,(q1+q2)**2])))==0
    soft=tidy(Q*inflate(frame['blocks'],[dec(b['soft']) for b in fci['blocks']])*Qi);zero(soft-soft.H);zero(soft*soft-soft);zero(soft.conjugate()-soft);zero(dec(d['vacuum']['orbit']).T*soft)
    for A in rh:zero(A*soft-soft*A)
    probes=physical_probes(kernels,frame,basis,address,cas,fci);amplitude=branch_amplitude(role,frame,cas,fci)
    save(role,{'schema':'SCM1','basis':list(map(list,basis)),'kernels':list(map(enc,kernels)),
      'scalar_Casimir_averages':[[str(z) for z in row] for row in cas],'charge_square_kernel_coefficients':list(map(str,charge)),
      'physical_probes':probes,'U1_quantum_light_vector_branch':amplitude,
      'domain_positions':20*177**2,'full_C1_or_E5_qualified':False},start)
if __name__=='__main__':main()
