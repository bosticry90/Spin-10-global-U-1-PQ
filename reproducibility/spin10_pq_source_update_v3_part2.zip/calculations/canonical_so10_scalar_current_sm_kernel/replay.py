"""SCM1 literal full-irrep signed traces in the nonorthogonal SM frame."""
from data import *

def main():
    start=begin();role='replay';values,color,Ms,fci=inputs(role)
    d,rho,V,ad,Ps,frame,Q,Qi,E=values;basis,address,states,seeds=typed_basis(frame)
    gram=dec(frame['D']);groups=[];print('STAGE full_scalar_signed_trace_coordinates',flush=True)
    for aa,A in enumerate(rho):
        R=tidy(Qi*A*Q);zero(R.H*gram+gram*R);group={}
        for (row,col),z in R.todok().items():
            alpha,v,ii=states[row];beta,n,kk=states[col]
            group.setdefault((alpha,v,beta,n),[]).append((ii,kk,z))
        groups.append(group)
    @lru_cache(256)
    def pair(aa,bb,bad=False):
        out={}
        for (alpha,v,beta,n),left in groups[aa].items():
            right=groups[bb].get((beta,n,alpha,v),[]);divisor=frame['blocks'][alpha]['dimension']
            # A deliberate Q.H-for-Qi mutation multiplies each outgoing state by D.
            extra=frame['blocks'][alpha]['state_norms'][v] if bad else '1'
            extra=s.sympify(extra)*(s.sympify(frame['blocks'][beta]['state_norms'][n]) if bad else 1)
            for ii,kk,z in left:
                for ll,jj,t in right:
                    pos=(address[alpha,ii,jj],address[beta,kk,ll]);out[pos]=out.get(pos,0)-extra*z*t/divisor
        return out
    kernels=[]
    for ix,M in enumerate(Ms):
        out={}
        for (aa,bb),co in M.todok().items():
            for ij,z in pair(aa,bb).items():out[ij]=out.get(ij,0)+co*z
        kernels.append(tidy(s.SparseMatrix(177,177,out)))
        if ix%5==4:print('STAGE signed_trace_kernel_'+str(ix+1),flush=True)
    bad={}
    for (aa,bb),co in Ms[0].todok().items():
        for ij,z in pair(aa,bb,True).items():bad[ij]=bad.get(ij,0)+co*z
    wrong=tidy(s.SparseMatrix(177,177,bad));assert tidy(wrong-kernels[0]).todok()
    cas=[[red(6*z/b['dimension']) for z in weights(b['label'])] for b in frame['blocks']]
    kernel_checks(kernels,frame,basis,address,color)
    zero(kernels[0]-s.diag(*[cas[alpha][0]+3*cas[alpha][1]+8*cas[alpha][2] for alpha,ii,jj in basis]))
    zero(kernels[5]);zero(kernels[6]-s.diag(*[2*cas[alpha][1] for alpha,ii,jj in basis]));zero(kernels[7]-s.diag(*[3*cas[alpha][2] for alpha,ii,jj in basis]))
    p=packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz');P=expr(p['P2'])
    def at(charges):return clean(P.subs(dict(zip([q1,q2,qv],charges))))
    neutral,left,right=at([-1,1,0]),at([1,0,-1]),at([0,1,-1])
    charge=list(map(clean,[(neutral+left-right)/2,(neutral-left+right)/2,(-neutral+left+right)/2]))
    soft=tidy(Q*inflate(frame['blocks'],[dec(b['soft']) for b in fci['blocks']])*Qi);zero(soft*soft-soft);zero(soft-soft.H);zero(soft.conjugate()-soft)
    for hh in range(12):
        A=tidy(sum((V[aa,hh]*rho[aa] for aa in range(45)),s.SparseMatrix(328,328,{})));zero(A*soft-soft*A);zero(dec(d['vacuum']['orbit']).T*A*soft)
    probes=physical_probes(kernels,frame,basis,address,cas,fci);amplitude=branch_amplitude(role,frame,cas,fci)
    save(role,{'schema':'SCM1','basis':list(map(list,basis)),'kernels':list(map(enc,kernels)),
      'scalar_Casimir_averages':[[str(z) for z in row] for row in cas],'charge_square_kernel_coefficients':list(map(str,charge)),
      'physical_probes':probes,'U1_quantum_light_vector_branch':amplitude,
      'wrong_inverse_QH_kernel_A0':enc(wrong),'domain_positions':20*177**2,'full_C1_or_E5_qualified':False},start)
if __name__=='__main__':main()
