"""SCM1 exact inputs, typed commutant, physical probes and numeric branch."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,enc,dec,inflate,weights,point_root,number,numeric,tr,real,fmt,QUAD
st,tt,ut,D,q1,q2,qv=s.symbols('s t u D q1 q2 qv',positive=True)
LOC={str(z):z for z in [st,tt,ut,D,q1,q2,qv]}
def read(p):return json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def clean(z):return s.cancel(s.expand(z))
def expr(z):return s.sympify(z,locals=LOC)
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def begin(prep='preparation.json',seconds=600):
    start=time.perf_counter();timer=threading.Timer(seconds,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in read(HERE/prep)['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'schema':'SCM1_NATIVE','role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def inputs(role):
    values=load('vsp_inputs',CAL/'canonical_so10_vector_scalar_quartic/data.py').inputs(role)
    color=packed(CAL/'canonical_so10_vector_scalar_quartic'/f'{role}_color_tables.json.gz')
    Ms=[tidy(dec(v)*(1 if k<5 else -1)) for k,v in enumerate(color['M_color'])]
    return values,color,Ms,packed(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_tables.json.gz')
def typed_basis(frame):
    basis=[];states={};seeds={}
    for alpha,b in enumerate(frame['blocks']):
        m=b['multiplicity']
        for ii in range(m):
            seeds[b['seed_offset']+ii]=(alpha,ii)
            for jj in range(m):basis.append((alpha,ii,jj))
        for state in range(b['dimension']):
            for ii in range(m):states[b['offset']+state*m+ii]=(alpha,state,ii)
    address={v:k for k,v in enumerate(basis)}
    assert len(basis)==177 and len(seeds)==65 and len(states)==328
    return basis,address,states,seeds
def vectorize(blocks,basis):return s.SparseMatrix([blocks[a][i,j] for a,i,j in basis])
def blocks_from_vector(v,frame,address):
    return [s.SparseMatrix(b['multiplicity'],b['multiplicity'],{(i,j):v[address[a,i,j],0] for i in range(b['multiplicity']) for j in range(b['multiplicity'])}) for a,b in enumerate(frame['blocks'])]
def image(K,blocks,basis):return tidy(K*vectorize(blocks,basis))
def pairing(X,vec,basis,frame,cas=None):
    return red(sum(frame['blocks'][a]['dimension']*X[a][j,i]*vec[k,0]*(1 if cas is None else cas[a]) for k,(a,i,j) in enumerate(basis)))
def kernel_checks(kernels,frame,basis,address,color):
    one=[s.eye(b['multiplicity']) for b in frame['blocks']];iv=vectorize(one,basis)
    for idx,K in enumerate(kernels):
        expected=vectorize([dec(v)*(1 if idx<5 else -1) for v in color['blocks'][idx]],basis);zero(K*iv-expected)
        kd=K.todok()
        for (row,col),z in kd.items():
            aa,ii,jj=basis[row];bb,kk,ll=basis[col];rr=address[bb,ll,kk];cc=address[aa,jj,ii]
            assert red(frame['blocks'][aa]['dimension']*z-frame['blocks'][bb]['dimension']*kd.get((rr,cc),0))==0
            assert red(s.conjugate(z)-kd.get((cc,rr),0))==0
def physical_probes(kernels,frame,basis,address,cas,fci):
    rows=fci['blocks'];types=[[dec(b['physical']) for b in rows],[dec(b['soft']) for b in rows]]
    types += [[dec(b['gold_mass_projectors'][rr]) for b in rows] for rr in range(4)]
    names=['physical_positive','soft']+['Gold_'+str(rr+1) for rr in range(4)]
    counts=[int(red(sum(b['dimension']*s.trace(X) for b,X in zip(frame['blocks'],row)))) for row in types]
    assert counts==[290,5,8,1,12,12]
    for ib,b in enumerate(rows):
        total=sum((typ[ib] for typ in types),s.SparseMatrix(b['multiplicity'],b['multiplicity'],{}));zero(total-s.eye(b['multiplicity']))
    images=[[image(K,typ,basis) for typ in types] for K in kernels];profiles=[]
    first={};raw={};vweight={}
    for rr in range(5):
        for xx in range(6):
            for yy in range(6):
                raw[rr,xx,yy]=pairing(types[xx],images[rr][yy],basis,frame)
                first[rr,xx,yy]=[pairing(types[xx],images[rr][yy],basis,frame,[row[ii] for row in cas]) for ii in range(3)]
                vweight[rr,xx,yy]=[pairing(types[xx],images[5+3*rr+ii][yy],basis,frame) for ii in range(3)]
    for rr in range(5):
        for xx in range(6):
            for yy in range(6):
                profiles.append({'r':rr,'left':names[xx],'right':names[yy],'raw':str(raw[rr,xx,yy]),
                  'q1_squared':list(map(str,first[rr,xx,yy])),'q2_squared':list(map(str,first[rr,yy,xx])),'qv_squared':list(map(str,vweight[rr,xx,yy]))})
                if (xx==1) != (yy==1):assert raw[0,xx,yy]==0
    # A diagonal-only multiplicity approximation loses actual H terms even in the light map.
    Hs=[dec(b['H']) for b in rows];Hd=[s.diag(*H.diagonal()) for H in Hs]
    loss=tidy(image(kernels[0],Hs,basis)-image(kernels[0],Hd,basis));assert loss.todok()
    marginal=blocks_from_vector(kernels[1]*vectorize([s.eye(b['multiplicity']) for b in frame['blocks']],basis),frame,address)
    false=[tidy(A*H) for A,H in zip(marginal,Hs)]
    collapse=tidy(image(kernels[1],Hs,basis)-vectorize(false,basis));assert collapse.todok()
    return {'type_names':names,'counts':counts,'profiles':profiles,'diagonal_only_H_loss':enc(loss),'collapsed_two_slot_H_loss':enc(collapse)}
def branch_amplitude(role,frame,cas,fci):
    mp.mp.dps=80
    if role=='primary':root=point_root()
    else:
        qa,qb,qc=[mp.mpf(str(s.N(v,115))) for v in QUAD];root=-2*qc/(qb+mp.sqrt(qb*qb-4*qa*qc))
    Wp=s.S.Zero;Wr=[s.S.Zero]*4;Ws=s.S.Zero;Jp=mp.mpf(0);rows=[]
    for alpha,b in enumerate(fci['blocks']):
        dim=b['dimension'];cY=cas[alpha][0];cH=cas[alpha][0]+3*cas[alpha][1]+8*cas[alpha][2]
        wgt=red(s.Rational(3,2)*dim*cY*cH);H=dec(b['H']);P=dec(b['physical']);N=s.eye(H.rows)-P
        zero(H*N);zero(H-H.H);zero(P-P.H)
        M=numeric(H+60*N,root)
        if role=='primary':
            eig,_=mp.eighe(M);assert min(eig)>0;lg=sum(mp.log(z/60) for z in eig)
        else:
            Ch=mp.cholesky(M);assert max(abs(z) for z in M-Ch*Ch.H)<mp.mpf('1e-60')*(1+max(abs(z) for z in M))
            lg=2*sum(mp.log(Ch[k,k]) for k in range(H.rows))-H.rows*mp.log(60)
        lg=real(lg);wp=red(wgt*s.trace(P));ws=red(wgt*s.trace(dec(b['soft'])));wr=[red(wgt*s.trace(dec(v))) for v in b['gold_mass_projectors']]
        Wp+=wp;Ws+=ws;Wr=[red(x+y) for x,y in zip(Wr,wr)];Jp+=real(number(wgt,root))*lg
        rows.append({'block':alpha,'weight_per_multiplicity':str(wgt),'positive_weight':str(wp),'soft_weight':str(ws),
          'Gold_weights':list(map(str,wr)),'weighted_positive_logdet':fmt(real(number(wgt,root))*lg)})
    Wp,Ws=map(red,[Wp,Ws]);Wg=red(sum(Wr));Wt=red(Wp+Wg)
    lams=list(map(s.sympify,fci['vector_mass_eigenvalues']));Jg=sum(real(number(wr,root))*mp.log(real(number(lam,root))/60) for wr,lam in zip(Wr,lams));J=Jp+Jg
    wn=real(number(Wt,root));gn=real(number(Wg,root))
    coefficients={'bare':[str(-Wt),fmt(4*wn/3+2*J),str(-2*Wt),str(2*Wg)],
      'forest':[str(-Wt),fmt(J),str(-Wt),str(Wg)],'Rprime':[str(-2*Wt),fmt(4*wn/3+3*J),str(-3*Wt),str(3*Wg)]}
    return {'axes':['pole','finite_constant','L','Ulog'],'coupling_prefactor':'g10^2','Wp':str(Wp),'Wr':list(map(str,Wr)),
      'Wg':str(Wg),'Wsoft':str(Ws),'Wpositive':str(Wt),'Jphysical':fmt(Jp),'JGold':fmt(Jg),
      'coefficients':coefficients,'rows':rows,'mixed_soft_positive_zero':True,
      'all_soft_parent_minus_common_tree_EFT':'ZERO_AT_SHARED_POSITIVE_IR_MASS_BEFORE_LIMIT',
      'overall_counterterm_adopted':False,'full_C1_or_E5_qualified':False}
