# SCM1 prospective full scalar-current mixing kernels and U1 light-vector branch

Base229664ef50a78ffd5ebc7725a0a10aa212355ce7/main, state113/34of39 unchanged.
Question: reduce the general VSS charge/mass contractions across the FULL
328-real-scalar carrier, preserve mixing, and use a proved reduction to extend
the qualified light-vector U1 integral to its complete scalar domain.

Four bounded claims are tested. C1: compute20 exact maps on the full
177-dimensional complex H-commutant,35 SM classes/65 multiplicity seeds,
626580 positions including zeros. C2: derive the exact three-charge-square
decomposition of the ordered P2 kernel and match actual scalar Casimirs and
vector insertions. C3: retain complete matrix mixing and an actual coarse
5-vector-by6-scalar-type-by6-scalar-type inventory; this is not a count of
measured integral amplitudes or a resolution of every physical mass eigenpair.
C4, only if its preceding gates hold: evaluate the full U1 quantum-LIGHT-vector
branch on all323 positive scalar directions and show its actual all-light EFT
partner cancels before the common IR limit. Other gauge factors/branches remain.

Same physical action, xi1 background reference, point, real metrics, dimensional
C1 prescription, g>0. No coupling, tadpole scheme, physical point, overall CT
or finite normalization is chosen. All177 matrix units are algebraic test
directions; physical inputs obey the inherited real-conjugation condition.
Do not double the328-real carrier or replace full-frame inverse D^-1Q.H by Q.H.

Native primary uses unit-normalized ambient-to-SM highest-state Gram maps.
Replay uses literal signed FULL-IRREP traces in the nonorthogonal SM frame,
with the correct inverse metric and dimension divisions. Both independently
derive all map entries and compare completed outputs before a separate verifier.
Marginals must reproduce all20 VSP quartic operators on all35 blocks. Keep
anti-Hermitian/reality, trace-dual exchange and H-covariance conditions, actual
scalar Casimirs, all three ideal averages, zeros and multiplicities.

The full invariant input mass blocks, soft/physical/Goldstone projectors and
four gauge-orbit masses come from actual FCI/SQP evidence. Retain all5 soft,
290 potential-positive and33 gauge-fixing-positive scalars,12 light/33 heavy
vectors. No beta-function replacement, commuting-matrix collapse or diagonal-
only multiplicity restriction. Controls remove off-diagonal inputs, omit irrep
dimension factors or use Q.H as inverse; state any insensitive test explicitly.

For C4 prove the ACTUAL map identities Gamma_A0(X)=C_H X and
Gamma_V0,U1=0. They imply equal scalar masses and neutral vector background
charge, permitting SLI1's positive-scalar massless-vector kernel. The remaining
vector CT F² trace is zero by neutrality, not a positive-mass boundary theorem.
Mixed soft/positive scalar assignments must vanish through actual projectors.
Construct the all-soft tree/EFT density as the SAME induced representation
and kinetic metric, with the shared positive auxiliary IR mass on both sides.
Bare graph and graph-local proper forests then cancel before that limit.
Do not call either isolated all-soft amplitude zero or borrow a universal EFT
or QAP theorem. If this identification is underdefined, retain that limitation.

Positive mass log traces:80-digit eigenvalue method versus Cholesky/logdet,
including every multiplicity direction. Use H+60(I-Pphysical), whose null-space
augmentation is1 after division by60, not a physical mass. Both must certify
positivity. Keep L=log(Q²/60),U=log(g²) symbolically. Compare numeric coefficients
at1e-40, display50digits; exact rational weights and poles remain exact.
Do not subtract the remaining overall pole or combine a full parent CT twice.

Source/input contracts freeze before computation. Caps600s per native and600s
for separate verifier after imports,8GiB sampled private allocation,350MiB
launch floor,new package4MiB. The larger new full-index scope, not a retry of
an old run, justifies these caps. Preserve all failed/unfinished sources/captures
with no truncation. A mismatch, underdefinition or resource limit stays such.
Shared action/frame/projector/heat/master/software/AI premises are disclosed.
No external scientist/Lean/empirical or full physical-unification claim.

Success is a complete exact structural reduction and, if all dependencies pass,
a complete specified U1 light-vector contribution with its actual matching
disposition. Full VSS/C1, other primitives, source-free E5/A5, protected HB1/C5,
human-paused flavor, finite-normalization and physical-viability gaps remain.
Run delegated e4 and byte seals before local commit. Custody exit2/seven is not
PASS. No old evidence/action/state/main/remote/publication changes. Goalactive.
