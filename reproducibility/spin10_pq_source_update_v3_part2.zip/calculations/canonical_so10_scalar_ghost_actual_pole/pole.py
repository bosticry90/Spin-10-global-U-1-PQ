"""Complete actual scalar-dependent ghost UV pole; sparse exact finite traces."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from fractions import Fraction as F
from math import lcm,prod
import importlib.util,json,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 q=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(q);q.loader.exec_module(u);return u
old=load('qualified_scalar_ghost_input_arithmetic',OUT.parent/'canonical_so10_scalar_ghost_physical_operators/operators_v2.py')
read=old.read;digest=old.digest
SQ=(2,3,5,-1,7);FACT=tuple(tuple(prod(q for bit,q in enumerate(SQ) if a&b&(1<<bit)) for b in range(32)) for a in range(32))
@lru_cache(maxsize=131072)
def mul(A,B):
 d={}
 for a,x in A:
  for b,y in B:d[a^b]=d.get(a^b,0)+x*y*FACT[a][b]
 return tuple((m,z) for m,z in sorted(d.items()) if z)
def add(A,B):
 d=dict(A)
 for m,z in B:d[m]=d.get(m,0)+z
 return tuple((m,z) for m,z in sorted(d.items()) if z)
def scale(A,n):return tuple((m,z*n) for m,z in A if z*n)
def put(A,k,z):
 if z:A[k]=add(A.get(k,()),z)
 if k in A and not A[k]:del A[k]
@lru_cache(None)
def number(txt):
 z=old.num(txt);assert all(a==b==0 for a,b,m in z.cells)
 return tuple((m,v) for(a,b,m),v in sorted(z.cells.items()))
def canon(w):
 if len(set(w))!=len(w):return (),0
 return tuple(sorted(w)),(-1)**sum(a>b for i,a in enumerate(w) for b in w[i+1:])
def auth(folder,name):
 p=OUT.parent/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def matrices(role):
 d=auth('canonical_so10_scalar_ghost_physical_operators','primary_result.json' if role=='primary' else'replay_v2_result.json');m=auth('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json');l=auth('canonical_so10_fourghost_g4_lorentz',role+'_result.json');u=auth('canonical_so10_unified_scalar_ghost_symbol',role+'_v2_result.json');M={k:[] for k in ['A','L','T','R','E','Et','K','Kt','X','Xr','Q','Z','U','V','W','J']}
 def item(tag,i,j,odd,scalar,wh,wm,z):
  w,sg=canon(odd)
  if sg:M[tag].append((i,j,w,tuple(sorted(scalar)),wh,wm,tuple((a,b*sg) for a,b in z)))
 for tag in ['A','L','T','R']:
  for i,j,w,z in l['classical_operator_tables']['Rbar' if tag=='R' else tag]:item(tag,i,j,[int(n[2:])+(45 if n.startswith('ap') else 0) for n in w],(),0,0,number(z))
 for a,i,z in m['physical_E']:item('E',a,i,(),(),0,0,number(z));item('Et',i,a,(),(),0,0,number(z))
 for a,i,j,z in d['physical_K']:item('K',a,i,(),(j,),0,0,number(z));item('Kt',i,a,(),(j,),0,0,number(z))
 for tag in ['X','Xr']:
  for i,j,k,z in d['physical_'+tag]:item(tag,i,j,(k,),(),0,0,number(z))
 for i,j,a,b,z in d['physical_Q']:item('Q',i,j,(a,b),(),0,0,number(z))
 for i,j,x,z in d['physical_Z']:item('Z',i,j,(),(x,),0,0,number(z))
 # Same actual Y density as both qualified mixed maps;left Hessian signs.
 for x,a,c,z in m['physical_Y_aC_density']:
  v=number(z);item('U',x,c,(45+a,),(),0,0,v);item('U',x,45+a,(c,),(),0,0,tuple((t,-b) for t,b in v));item('V',c,x,(45+a,),(),0,0,tuple((t,-b) for t,b in v));item('V',45+a,x,(c,),(),0,0,v)
 for i in range(45):item('W',i,i,(),(),int(i<12),int(i>=12),((0,F(1)),));item('J',i,45+i,(),(),0,0,((0,F(1)),));item('J',45+i,i,(),(),0,0,((0,F(-1)),))
 D={}
 for tag,rows in M.items():
  D[tag]=lcm(*(v.denominator for row in rows for mask,v in row[-1]))
  M[tag]=[(i,j,o,s,h,w,tuple((mask,int(v*D[tag])) for mask,v in z)) for i,j,o,s,h,w,z in rows]
 assert len(M['K'])==12560 and len(M['Q'])==37152 and len(M['X'])==len(M['Xr'])==1200 and len(M['Z'])==len(M['U'])==len(M['V'])==12536
 assert len({(i,j,o,s,h,w) for i,j,o,s,h,w,z in M['U']})==12536 and len({(i,j,o,s,h,w) for i,j,o,s,h,w,z in M['V']})==12536
 assert d['current_known_terms']==155143 and not any(d['all_seven_quantum_flags_false'].values())
 return M,D,u,d
def adjacency(rows,reverse=False):
 d=defaultdict(list)
 for i,j,o,s,h,w,z in rows:d[j if reverse else i].append((i if reverse else j,o,s,h,w,z))
 return d
def boolean_suffix(M,word,reverse=False):
 seq=list(reversed(word)) if reverse else list(word);S=[None]*len(seq);last=adjacency(M[seq[-1]],reverse);S[-1]={i:{j for j,*rest in rows} for i,rows in last.items()}
 for k in range(len(seq)-2,-1,-1):
  nxt=S[k+1];d={}
  for i,rows in adjacency(M[seq[k]],reverse).items():
   q=set()
   for j,*rest in rows:q.update(nxt.get(j,()))
   if q:d[i]=q
  S[k]=d
 return S
def count_paths(M,word):
 A=defaultdict(int)
 for i,j,*rest in M[word[0]]:A[i,j]+=1
 for tag in word[1:]:
  B=adjacency(M[tag]);C=defaultdict(int)
  for(i,k),z in A.items():
   for j,*rest in B.get(k,()):C[i,j]+=z
  A=C
 return sum(z for(i,j),z in A.items() if i==j)
def walk_trace(M,word,reverse=False):
 seq=list(reversed(word)) if reverse else list(word);edges=[adjacency(M[t],reverse) for t in seq];suffix=boolean_suffix(M,word,reverse);last=defaultdict(list)
 for i,rows in edges[-1].items():
  for j,o,s,h,w,z in rows:last[i,j].append((o,s,h,w,z))
 out={};valid=0
 def finish(o,s,h,w,z):
  nonlocal valid
  assert len(o)==2 and o[0]<45<=o[1] and len(s) in (1,2) and h+w<=1,(word,o,s,h,w)
  valid+=1;put(out,(*o,s,h,w),z)
 def extend(start,at,o,s,h,w,z,k):
  if k==len(seq)-1:
   for oo,ss,hh,ww,zz in last.get((at,start),()):
    q,sg=canon(oo+o if reverse else o+oo)
    if sg:finish(q,tuple(sorted(s+ss)),h+hh,w+ww,scale(mul(z,zz),sg))
   return
  if start not in suffix[k].get(at,()):return
  for j,oo,ss,hh,ww,zz in edges[k].get(at,()):
   q,sg=canon(oo+o if reverse else o+oo)
   if sg:extend(start,j,q,tuple(sorted(s+ss)),h+hh,w+ww,scale(mul(z,zz),sg),k+1)
 for start,rows in edges[0].items():
  for j,o,s,h,w,z in rows:
   if start in suffix[1].get(j,()):extend(start,j,o,s,h,w,z,1)
 return out,valid
def gram_pair(M):
 # K Kt first,with sorted scalar polynomial;then trace against full A.
 kr=defaultdict(list)
 for a,i,o,s,h,w,z in M['K']:kr[i].append((a,s[0],z))
 G={}
 for vals in kr.values():
  for a,x,z in vals:
   for b,y,v in vals:put(G,(a,b,tuple(sorted((x,y)))),mul(z,v))
 rows=defaultdict(list)
 for(a,b,s),z in G.items():rows[b,a].append((s,z))
 out={}
 for a,b,o,ss,h,w,z in M['A']:
  for s,v in rows.get((a,b),()):put(out,(*o,s,0,0),mul(z,v))
 return out,len(G)
def pack(A,den):
 return [[a,c,list(s),h,w,[[m,F(v,den).numerator,F(v,den).denominator] for m,v in z]] for(a,c,s,h,w),z in sorted(A.items())]
def dhash(z):return sha256(json.dumps(z,separators=(',',':')).encode()).hexdigest()
def controls():
 assert mul(((1,1),),((1,1),))==((0,2),) and mul(((8,1),),((8,1),))==((0,-1),) and mul(((16,1),),((16,1),))==((0,7),)
 assert canon((45,0))==((0,45),-1) and canon((0,0))[1]==0
 K=[(0,0,(),(0,),0,0,((0,2),)),(0,0,(),(1,),0,0,((0,3),))]
 M={'K':K,'Kt':[(i,a,o,s,h,w,z) for a,i,o,s,h,w,z in K],'A':[(0,0,(0,45),(),0,0,((0,5),))]};A,_=walk_trace(M,['A','K','Kt']);B,_=gram_pair(M);assert A==B and A=={(0,45,(0,0),0,0):((0,20),),(0,45,(0,1),0,0):((0,60),),(0,45,(1,1),0,0):((0,45),)}
 return {'radical_squares_and_I_sign':True,'odd_reversal_and_nilpotence':True,'pair_full_diagonal_cross_Bose_control':True,'scalar_even_ordering_and_pair_grouping':True}
def calculate(M,D,u,role):
 families={k:u['normalized_ordered_family_formulas'][k] for k in ['DMK','FYK','FFMK','FFY','YR','FMKX','FYX','YQ','YKX']};families['PAIR_D']=[[['A','K','Kt'],'3']];tables={};meta={};groups={};gden={};terms={};timer=time.perf_counter()
 for name,form in families.items():
  unit={};den=1;word_data=[]
  for word,co in form:
   cf=number(co);dd=prod(D[t] for t in word)*lcm(*(v.denominator for m,v in cf));den=lcm(den,dd);word_data.append((word,cf,dd))
  for word,cf,dd in word_data:
   tick=time.perf_counter();expected=count_paths(M,word)
   if role=='replay' and name=='PAIR_D':A,gram=gram_pair(M);valid=None
   else:A,valid=walk_trace(M,word,role=='replay');gram=None
   cd=lcm(*(v.denominator for m,v in cf));cs=tuple((m,int(v*cd)) for m,v in cf)
   for key,z in A.items():put(unit,key,scale(mul(z,cs),den//dd))
   word_data_meta={'word':word,'unfiltered_closed_paths':expected,'non_nilpotent_closed_paths':valid,'precontracted_Gram_positions':gram,'nonzero_word_positions':len(A),'seconds':time.perf_counter()-tick}
   meta.setdefault(name,[]).append(word_data_meta)
  rows=pack(unit,den);tables[name]=rows;terms[name]={'nonzero':len(rows),'exact_sha256':dhash(rows),'common_integer_denominator':den}
  group='g4_xi0_pair' if name=='PAIR_D' else'g4_xi1' if name in ['DMK','FYK','FFMK','FFY'] else'g4_xi2' if name=='YR' else'g3_xi2'
  if group not in groups:groups[group]={};gden[group]=den
  newden=lcm(gden[group],den)
  if newden!=gden[group]:groups[group]={k:scale(z,newden//gden[group]) for k,z in groups[group].items()}
  for k,z in unit.items():put(groups[group],k,scale(z,newden//den))
  gden[group]=newden
  print('STAGE '+role+' '+name+' positions='+str(len(rows))+' seconds='+str(round(time.perf_counter()-timer,3)),flush=True)
 packed_groups={g:pack(P,gden[g]) for g,P in groups.items()}
 return tables,terms,meta,packed_groups
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('ACTUAL_SCALAR_GHOST_POLE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);ctrl=controls();M,D,u,d=matrices(role);tables,terms,meta,groups=calculate(M,D,u,role)
 linear=sum(x['unfiltered_closed_paths'] for n,rs in meta.items() if n!='PAIR_D' for x in rs);pair=meta['PAIR_D'][0]['unfiltered_closed_paths'];assert linear==2217632 and pair==8623524
 for g,rs in groups.items():
  assert all(a<45<=c<90 and len(ss)==(2 if g.endswith('pair') else 1) and ss==sorted(ss) and all(0<=x<328 for x in ss) for a,c,ss,h,w,z in rs)
  assert all(h+w==(1 if g=='g4_xi1' else 0) for a,c,ss,h,w,z in rs)
 result={'schema':'ACTUAL_SCALAR_GHOST_COMPLETE_PHYSICAL_POLE_V1','route':role,'scientific_disposition':'COMPLETE_ACTUAL_LINEAR_AND_PAIR_COLOR_POLES_NOT_CANONICAL_INTEGRATION','normalization':'hbar/(32*pi^2*epsilonUV); explicit vertex xi separate from W width eta_H/xi','odd_word_order':'numeric C0..44,a0..44;rows [C,a+45,sorted_scalar_indices,eta_H_power,xi_width_power,radical_cells]','exact_basis_squared':list(SQ),'family_physical_poles':tables,'family_summary':terms,'group_physical_poles':groups,'group_exact_sha256':{g:dhash(P) for g,P in groups.items()},'group_nonzero_positions':{g:len(P) for g,P in groups.items()},'complete_domain_per_linear_width_monomial':45*45*328,'complete_pair_symmetric_domain':45*45*328*329//2,'all40_actual_profile_family_correspondence':u['all40_actual_profile_family_correspondence'],'zero_pair_families_qualified_not_recomputed':['FX','FF','XX'],'actual_excluded_FFMM_profile_preserved':2025,'contraction_metadata':meta,'complete_index_only_ceiling_verified':{'linear':linear,'pair':pair},'matrix_integer_scalings':D,'controls':ctrl,'insensitive_controls':['a width change does not test the complete pair sum;no width-free claim for linear g4xi','shared action and prior common-symbol/Gaussian normalizations are not independently re-proved'],'current_known_terms':155143,'current_known_sha256':d['current_known_sha256'],'sourceimage_positions':146663,'all_seven_quantum_flags_false':d['all_seven_quantum_flags_false'],'canonical_integration_or_simultaneous_sourcefree_identity':False,'full_QAP_IR_measure_products_contacts_equivalence_E5_A5':False,'shared_limits':'Actual matrices,prior Gaussian/Lorentz/UV/action proofs,software,AI author shared;full sparse finite evaluation is not a full quantum restoration or physical test','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
