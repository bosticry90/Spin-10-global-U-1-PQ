# Actual scalar-dependent ghost pole V1

Base446dc0cbac619f1683b7f21e9a98a33fe6186457,main,SGO inputs qualified.
Question: evaluate the COMPLETE remaining scalar-dependent aC local UV pole
specified by V279's nine scalar-linear families and its combined D scalar-pair
family. This addresses all22 linear and18 pair profiles in that actual census;
not another selected-point test. It can yield nonzero measured coefficients,
exact cancellations or bounded incomplete work. No coefficient is chosen to
satisfy a Ward identity. The explicit current action is unchanged.

Freeze the V280 physical K/X/Xr/Q/Z packet,qualified V275 E/Y,qualified V270
A/L/T/Rbar and V279's normalized ordered traces/coupling powers/profile map.
All45 gauge,90 odd and328 scalar directions stay. Odd order C0..44,a0..44
has numeric indices0..89;scalar variables commute. Operator ordering is fixed
before evaluation. J=[[0,I],[-I,0]];W is ordered diagonal eta_H on12 H
directions and xi on33 M directions. W's xi is propagator-width dependence,
distinct from explicit vertex xi. Do not commute W across another operator.
X/Xr and U/V have the qualified opposite mixed transpose;T=L^t.

Use V279's full nine formulas without changes. First four linear families
DMK,FYK,FFMK,FFY carry g4*xi and one W;YR carries g4*xi^2;FMKX,FYX,YQ,YKX
carry g3*xi^2. Scalar-pair D is +3Tr(A K Kt),g4,xi^0;the complete FX/FF/XX
pair sums vanish by V279/V278. Retain these qualified cancellations and the
actual40 profile bridge. Never add the generically nonzero but actually
excluded FFMM profile2025. Use the qualified common leading-symbol/UV
normalization hbar/(32pi^2 epsilonUV);no new integration prescription or
full finite amplitude is introduced. This is direct substitution of the
complete actual Hessians into independently qualified ordered Born formulas.

Output full sparse physical coefficient tables for each nine-family sum,
the pair sum and the four coupling/explicit-xi groups. A row specifies
canonical numeric odd pair,sorted scalar index tuple,eta_H/xi width powers
and exact five-radical coefficient. Complete domains are2025*328 per linear
parameter monomial and2025*328*329/2 for the pair;any a-a/C-C support must be
reported as a mismatch rather than discarded. Include all scalar sectors,
all implicit zeros,closed-path counts and exact table hashes. Do not infer
a zero from absence in the current partial functional. No canonical insertion
or simultaneous Slavnov conclusion occurs in this increment.

Least expensive competent test: sparse exact closed-index contractions.
Index-only planning (not physics) counted2217632 unfiltered linear tuples and
8623524 pair tuples versus109260900 dense pair positions. Native primary
walks ordered forward closed paths with integer-scaled radical coefficients.
Replay walks reversed edges with prepended graded words;pair may use a
precontracted scalar Gram polynomial. Both evaluate the entire domain and
compare only after completion. An independent verifier uses separate exact
rational-radical arithmetic and a different grouping of the pair contraction;
it verifies every new coefficient and zero complement,not sample points.
The prior full Gaussian/Lorentz proof and actual-field/Hessian proofs remain
shared mathematical dependencies,not independently repeated physical premises.

Freeze three sequential workers,each300sec AFTER imports,8GiB sampled private
memory and minimum350MiB available commit. The300sec bound is justified by
the precomputed10.84million sparse tuple ceiling;no dense full-Gamma expansion
or allocation of the109million domain is permitted. Cache bounds must be
explicit;never truncate scientific entries. Preserve timeouts/failed sources/
captures and classify incomplete;no silent resource extension. Preflight all
coefficient types,scalings,profile metadata,derivative signs,domain sizes and
JSON serializers before workers. Use immutable exclusive source copies,
declared role inputs,complete captures and an independently frozen verifier.

Negative controls: radical arithmetic versus rational reconstruction,odd
canonical-order sign/nilpotence,even scalar reorder,pair Bose diagonal/cross
polarization,opposite mixed versus Fourier transpose,one input or output sign
and one missing nonzero coefficient. Record insensitive controls honestly;
do not presume any measured group nonzero. Input provenance and exact-current
maps must be authenticated before computation;independent validation then
compares full physical results and accepted byte maps before a local commit.

Current V276 functional155143 words/hash
fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241
and sourceimage146663 stay. No current scope-ledger count is promoted merely
by operator availability. FullsourcefreeSlavnov,QAP,measure,IR,32 nonlinear
products,contact/equivalence,E5/A5,GUT viability unqualified. Authority34/39,
seven protected flags false,HB1/C5 blocked,flavor paused. Historical quartet
candidate failure,scalar140% correction,gauge-matching/custodyexit2-seven
limits persist. No new scheme,input,benchmark,policy,agent,branch/worktree,
remote/publication,external contact,Lean or full-goal completion. Shared action,
prior proofs,software and AI author limit independence. This contract is
ordinary bounded research under AGENTS.md,not a protected scientific promotion.
