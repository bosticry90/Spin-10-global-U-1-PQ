# Completed actual scalar-dependent ghost pole

Independent receipt a1e1fd90e9a98158c7eed46f5c9b8f7c23cdb385cd08fee588ccb3d52871d47f
completed. This final assessment requires the local committed-byte checks;
it retains the frozen RESULT_V1 qualification requirements and every input.

All nine scalar-linear families and the complete D scalar-pair sum have been
evaluated using the actual physical Hessians. Every coefficient and implicit
zero matches the independent rational-radical polynomial-matrix calculation.
The qualified FX/FF/XX pair cancellations and excluded FFMM profile2025 stay.
The full40-profile bridge is checked in the accepted receipt. No Ward value
or missing coefficient was fitted to produce a desired cancellation.

After combining equal physical parameter powers,the completed density has:

| Coupling/parameter monomial | Scalar degree | Nonzero physical positions |
| --- | --- | --- |
| g10^3 xi^2 | 1 | 5256 |
| g10^4 eta_H xi | 1 | 10080 |
| g10^4 xi^2 | 1 | 10224 |
| g10^4 | 2 | 333540 |

These359100 coefficient positions are organized by parameter monomial and
field indices,not separate particles,experiments or diagrams. The first three
complete tables are in the accepted receipt;the complete pair table is the
authenticated primary_result.json group g4_xi0_pair. Native family/origin
tables remain for audit. Vertex xi and W_M width xi were kept separate during
contraction and correctly coalesced afterward. The normalization remains
hbar/(32pi^2 epsilonUV);numeric C-before-a odd order and sorted scalar products
are explicit. Reversing to an aC density requires its Grassmann minus sign.

Primary forward paths112.099sec/629751808 sampled private bytes;replay reversed
paths plus pair Gram222.425sec/630169600;independent constant-absorption
matrix products173.937sec/1590079488. All300sec-after-imports,8GiB and350MiB
available-commit limits pass with qualified launch/post-run observations.
No native or independent failed execution. Fresh identical replay pairs0.
All3 current input maps(1792/1806/1806),exclusive source copies and captures
must agree at commit. The actual primary/replay matrices and full payloads
agree;stage timings and grouping metadata appropriately differ.

Two non-scientific custody controllers failed before mutation. The first
summed legacy complete_scope_match values;the second incorrectly assumed
booleans. Inspection of the qualified producer established the actual schema:
329 nonempty qualified evidence-reference strings and335 null unmatched rows.
V3 validates those exact reference labels/counts and the inherited summaries,
then reconciles both role maps. Both failed controllers/error records remain
external. No physics worker is rerun or scientific requirement removed.

TrackB: sparse contractions completed the pair's109260900-position zero/nonzero
domain without a dense allocation or full-Gamma expansion. Reverse path order
was substantially slower than forward order;pair precontraction reduced the
cost. A separately grouped rational implementation corroborated every table.
The two missed legacy-schema assumptions are avoidable custody-preflight
failures;the first attempted correction did not inspect the actual producer.
Shared action,Hessian/coordinate/UV/Gaussian premises,software and AI author
remain limits;this is not independent physical or expert validation.

The new accepted40 profile indices are exactly the scalar-dependent unmatched
set in the prior qualified664-profile ledger. The old329/335 ledger is never
edited. Exact set reconciliation at custody therefore yields369 complete and
295 still unmatched in that SAME finite inventory. This is a derivative
coverage statement about existing evidence,not a new physical acceptance or
an exhaustive source-free/QAP theorem. All remaining295 rows contain two
vector fields plus C,a. Their g3/g4 and AA/AB/BB distinctions remain visible.

No canonical transport/integration or selected new Slavnov identity has yet
been performed. The155143-word current functional and sourceimage146663 stay
unchanged. The next justified work is actual-field-to-canonical transport of
these measured scalar-dependent coefficients with inverse/reality/zero-domain
checks,then exact-once sparse integration and the complete affected scalar
antighost component. Estimate mapping cost first;do not expand full Gamma or
assume an independent nonlinear insertion vanishes. Do not start another
vector-loop calculation merely because295 inventory rows remain unmatched.

Full sourcefreeSlavnov,QAP,regulated measure/IR,32 nonlinear products,contacts/
equivalence,E5/A5 and physical viability are unqualified. Authority34/39 and
all seven protected flags remain unchanged;HB1/C5 blocked,flavor paused.
Historical quartet-candidate failure,scalar140% singlet correction,failed
completed gauge-matching approximation and custodyexit2/seven persist. No
new action/input,scheme,benchmark,policy,Lean,external action or completed
Spin(10)xPQ goal. A completed local-pole class does not settle the quantum
construction prerequisites emphasized in the director's latest assessment.
