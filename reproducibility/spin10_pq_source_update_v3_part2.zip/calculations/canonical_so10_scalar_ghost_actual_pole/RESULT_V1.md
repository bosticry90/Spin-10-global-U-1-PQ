# Prospective full physical scalar-ghost pole qualification

This report is a verification gate,not a completed receipt. Qualification
requires both completed native captures,the independently completed receipt,
all frozen input maps and committed-byte checks. No status in project_state
is changed by this report. Base446dc0c;see RECORD.md for the exact scope.

The completed primary evaluates all nine scalar-linear sums and the combined
D scalar-pair sum using actual physical matrices. It reports15280 DMK,18112
FYK,5344 FFMK,9632 FFY,9632 YR,10440 FMKX,10440 FYX,10440 YQ,10496 YKX and
333540 pair positions. Other pair families retain their complete qualified
zero sums;all40 actual profiles remain covered by their explicit family map.
These are exact coefficient supports,not particles,experiments or loop counts.

The four provenance-separated groups have20500 g4*xi-with-W,9632 g4*xi^2,
5256 g3*xi^2 and333540 g4 scalar-pair positions. Propagator W has eta_H in
the12 H directions and xi in33 M directions. Thus these four group counts
are NOT disjoint physical parameter monomials:the g4*xi*W_M contribution and
g4*xi^2 contribution share a physical parameter power and can combine. Keep
their origins explicit;do not infer a final physical support count by adding
them. Complete family/group coefficient tables,not the counts,define the pole.

Each row uses numeric C0..44,a0..44 canonical odd order,sorted Cartesian
scalar indices,eta_H/xi width exponents and exact rational five-radical cells.
No diagonal scalar factor is inserted;off-diagonal scalar products receive
both ordered paths. The pair control verifies this polarization exactly.
Complete sparse equality verifies implicit zeros in664200 linear positions
per parameter monomial and109260900 symmetric-pair positions. The latter
domain was never allocated as a dense array. All scalar sectors are retained.

Primary ordered forward paths and replay reversed ordered paths must match
every family and group. Replay uses K Kt Gram precontraction for the pair.
The independent rational-radical method absorbs field-constant J/W/E/Et
matrices in their actual order,then multiplies polynomial matrices and takes
complete closing traces. Its pair groups K Kt before contracting the full A.
No infinite-dimensional trace cyclicity or commutation of W is assumed.
Independent input-role matrices must also match in their complete domains.

Sensitive negative controls cover radical/I arithmetic,odd order/nilpotence,
even scalar/Bose polarization,one nonzero coefficient sign and one omission.
No control presumes every combined group nonzero;insensitivity is recorded.
Inherited action,field/action correspondence,common UV/Gaussian/Lorentz
normalizations,software and AI author are shared limits. These checks are
computational corroboration,not independent expert or experimental validation.

No new canonical integration or simultaneous source-free Slavnov test is
performed. Current155143-word functional/sourceimage146663 are unchanged.
The329/335 finite profile ledger is not automatically promoted here;new complete
physical coefficient evidence can be reconciled in a subsequent coverage step.
QAP,measure,IR,32 nonlinear products,contacts/equivalence,E5/A5 and physical
GUT viability remain unqualified;authority34/39 and seven false flags persist.
HB1/C5 blocked,flavor paused,historical quartet-candidate failure,scalar140%
correction,gauge matching and custodyexit2/seven limits remain. The wider
Spin(10)xPQ objective stays active. No new inputs,scheme,benchmark or remote
action. The next action depends on completed validation,not this prediction.
