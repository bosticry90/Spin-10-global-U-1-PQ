# SCU1 V1 display-precision verifier failure

Both native calculations completed and their full operators, forests and
controls matched. The separate V1 verifier passed its action-vertex/operator
and endpoint checks, then FAILED at line79: it compared an 18-significant-digit
display to an unrounded quantity with a 1e-18 relative tolerance. Eighteen-digit
rounding can exceed that tolerance; the report precision was already frozen.
No scientific input, raw algebra, finite coefficient or tolerance is changed.

verify_v2.py checks displayed strings against mp.nstr(actual,18) EXACTLY.
It separately checks the UNROUNDED two diagnostic poles with the original
1e-18 tolerance. The old verify.py, run.py, frozen source copies, completed
native outputs and full validation_capture.json remain unchanged. No V1
validation receipt exists. The new controller reuses authenticated completed
native outputs instead of rerunning them, and freezes the repair before use.

The complete failed child traceback and resource samples are in
validation_capture.json, duplicated externally as validation_full_capture.json.
The outer run.py then exited1 at resource(c)'s COMPLETED assertion, as intended.
This is a verification-serialization error, not a scientific discrepancy.
