"""Freeze and execute SCU1 display-comparison repair; preserve old evidence."""
from pathlib import Path
from hashlib import sha256
import ast,json,sys,gzip
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-forests-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
old=json.loads((HERE/'validation_preparation.json').read_bytes());deps=dict(old['input_sha256'])
for n,h in deps.items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
c=json.loads((HERE/'validation_capture.json').read_bytes());assert c['execution_state']=='FAILED' and c['exit_code']==1
assert "printed=mp.mpf(tr['diagnostics']" in c['stdout_and_stderr']
assert not (HERE/'validation_receipt.json').exists()
for name in ['validation_preparation.json','validation_capture.json']:
    p=HERE/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['verify_v2.py','run_validation_v2.py','VERIFIER_CORRECTION_V2.md']:
    p=HERE/name;raw=p.read_bytes()
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    q=HERE/(name+'.source.txt')
    with q.open('xb') as out:out.write(raw)
    for f in [p,q]:deps[str(f)]=sha256(f.read_bytes()).hexdigest()
dump(HERE/'validation_preparation_v2.json',{'schema':'SCU1_VALIDATION_PREPARATION_V2',
 'input_sha256':dict(sorted(deps.items())),'seconds':360,'private_sample_cap':8*1024**3,
 'launch_floor':350*1024**2,'whole_package_bytes':4*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'verify_v2.py')]);dump(HERE/'validation_v2_capture.json',c);dump(CONTROL/'validation_v2_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2
assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
v=rows[0];assert v['elapsed_after_imports']<360;dump(HERE/'validation_receipt_v2.json',v)
print(json.dumps({'execution_state':v['execution_state'],'status':v['status'],'elapsed_after_imports':v['elapsed_after_imports'],
 'bare_mass_derivative':v['bare_mass_derivative'],'proper_time_and_evanescent_error':v['proper_time_and_evanescent_error']},sort_keys=True),flush=True)
