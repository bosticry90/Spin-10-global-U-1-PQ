# After SCU1: complete the singlet restriction without a false massless limit

SCU1 derives the actual positive-heavy current subgraphs and finite forest,
and verifies d_r(Pbare+Pforest)=0. Its remaining overall pole is nonzero;
no overall subtraction or full C1 result has been adopted. Reuse the completed
receipt and operators; do not repeat their large inherited calculations.

The cheapest potentially useful extension is the four nonzero quantum-LIGHT
vector routes already measured by SCP1, with both scalar edges still having
positive masses. Establish first whether the local U1 F² coefficient and
its proposed UV-subtracted representation have a justified infrared domain.
The exchanged neutral light vector has no U1 spin/curvature charge, but its
propagator1/k² is not zero. A soft1/k² power count may support integrability
with positive scalar masses; it is not yet a completed proof for every
subtracted term, contact, exceptional limit or EFT region.

Use the actual neutral Fourier formula and projectors to identify the soft
regions before continuing a massive integral to zero vector mass. SCL1's
largest-vector-time sectors use M0>0; setting M0=0 there is invalid. Find
a convergent representation or a separately justified analytic continuation
that preserves UV/IR distinctions and the original normalization. Only then
calculate the corresponding bare and proper-subgraph coefficients. Do not
impose an answer through mass independence or a desired beta coefficient.

Keep positive g, the actual physical/gauge-orbit masses, all nonzero current
weights, epsilon-positive remaining traces and parent-minus-current quartic
differences. Do not duplicate the SCU1 positive-heavy forest or adopt a new
overall/finite normalization. Qualified one-soft factorization does not
automatically settle multiple-soft regions or the full EFT subtraction.

If this route is underdefined, identify the exact infrared premise rather
than declaring the light amplitude zero or increasing a brute-force cutoff.
The other324 scalar directions and full gauge factors/primitives remain
independent coverage obligations; four-singlet completion is still bounded.
This is ordinary investigation, not HB1/C5/flavor activation or acceptance.
