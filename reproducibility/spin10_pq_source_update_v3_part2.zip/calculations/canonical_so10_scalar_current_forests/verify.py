"""SCU1 separate action-vertex, forest, endpoint and heat verification."""
from data import *

def main():
    start=begin('validation_preparation.json',360);mp.mp.dps=80
    A,B=[packed(HERE/(role+'_tables.json.gz')) for role in ['primary','replay']]
    for key in ['operators','trace','vector_mass_rows','bare_derivative_parts','controls']:
        assert A[key]==B[key],key
    op=A['operators'];rho,E,U,S,Pr,Ty,Rh,H,O,G=setup('primary')
    J=tidy(E.T*E);zero(J.H*J-s.eye(4));T=[s.SparseMatrix(4,4,{}) for _ in range(45)]
    old=packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz')
    # Independent recovery from previously frozen REAL-bilinear VSS vertices,
    # rather than reusing either worker's Hermitian current construction.
    for ii,jj,encoded in old['vertices']:
        column=dec(encoded)
        for aa in range(45):T[aa][ii,jj]=column[aa,0]
    T=[tidy(J.H*M) for M in T]
    for aa,M in enumerate(T):zero(M-dec(op['T'][aa]));zero(M+M.H)
    print('STAGE frozen_real_vertex_and_complete_operators',flush=True)
    PH=tidy(E.H*H*E/s.Rational(426075291,62500000));MG=tidy(E.H*O*O.T*E)
    Plus=s.eye(45)-Pr[0];h=tidy(E.H*Rh*E);Qs=tidy(-h*h);Qv=tidy(-Ty*Ty)
    def match(name,M):zero(tidy(M)-dec(op[name]))
    C=s.SparseMatrix(4,4,{});Bx=C.copy();Bg=C.copy()
    for ii in range(4):
        for jj in range(4):
            for (aa,bb),zz in Plus.todok().items():
                C[ii,jj]-=zz*sum(T[aa][ii,kk]*T[bb][kk,jj] for kk in range(4))
                Bx[ii,jj]-=zz*sum(T[aa][ii,kk]*PH[kk,kk]*T[bb][kk,jj] for kk in range(4))
                Bg[ii,jj]-=zz*sum(T[aa][ii,kk]*MG[kk,kk]*T[bb][kk,jj] for kk in range(4))
            for (aa,bb),zz in G.todok().items():Bg[ii,jj]-=zz*sum(T[aa][ii,kk]*T[bb][kk,jj] for kk in range(4))
    C,Bx,Bg=map(tidy,[C,Bx,Bg]);match('scalar_C',C);match('scalar_Bx',Bx);match('scalar_Bg2',Bg)
    for name,M in [('scalar_loop_slope',-2*C),('scalar_CT_slope',2*C),('scalar_CT_mass_x',-Bx),('scalar_CT_mass_g2',-Bg)]:match(name,M)
    tau=s.SparseMatrix(45,45,{});Mx=tau.copy();Mg=tau.copy();comm=tau.copy()
    for aa in range(45):
        for bb in range(45):
            diag=[sum((T[aa][ii,kk]*T[bb][kk,ii]+T[bb][ii,kk]*T[aa][kk,ii])/2 for kk in range(4)) for ii in range(4)]
            tau[aa,bb]=-sum(diag);Mx[aa,bb]=-sum(PH[ii,ii]*diag[ii] for ii in range(4));Mg[aa,bb]=-sum(MG[ii,ii]*diag[ii] for ii in range(4))
            comm[aa,bb]=-sum(h[ii,ii]*sum(T[aa][ii,kk]*T[bb][kk,ii]-T[bb][ii,kk]*T[aa][kk,ii] for kk in range(4)) for ii in range(4))/6
    tau,Mx,Mg,comm=map(tidy,[tau,Mx,Mg,comm])
    for name,M in [('vector_tau',tau),('vector_loop_slope',tau/6),('vector_loop_mass_x',Mx),('vector_loop_mass_g2',Mg),
      ('vector_loop_curvature_commutator',comm),('vector_loop_curvature_ordering',-tau*Ty/6),('vector_loop_curvature_total',-tau*Ty/3)]:match(name,M)
    zero(comm+Ty*tau/6);zero(tau*Ty-Ty*tau)
    for name,M in [('embedded_P4_scalar_loop_slope',-2*C),('embedded_P4_scalar_mass_x',Bx),('embedded_P4_scalar_mass_g2',Bg)]:
        embedded=dec(op[name]);zero(embedded-E*M*E.H);zero(embedded-embedded.H);zero(embedded-(E*E.H)*embedded*(E*E.H))
    # Parent full-space quartic operator is a distinct frozen result.
    parent=dec(op['parent_scalar_C']);vsp=packed(CAL/'canonical_so10_vector_scalar_quartic/primary_color_tables.json.gz')
    for ii,block in enumerate([0,1,3,4]):assert red(parent[ii,ii]-sum(dec(vsp['blocks'][rr][block])[0,0] for rr in range(1,5)))==0
    assert (parent-C).todok() and dec(op['parent_minus_current_vector_Mx']).todok() and dec(op['parent_minus_current_vector_Mg2']).todok()
    # Flat UV coefficients independently from the closed-D0=4 angular moments.
    n2,n4,n22=s.Rational(1,4),s.Rational(1,8),s.Rational(1,24)
    assert 1-1+8*n2==2 and 16*n4-12*n2+1==0 and 16*n22-4*n2==-s.Rational(1,3)
    # Partial subgraphs overlap: no disjoint-product term is admissible.
    subgraphs=[{0,1},{0,2},{1,2}];assert all(subgraphs[ii]&subgraphs[jj] for ii in range(3) for jj in range(ii))
    print('STAGE independently_differentiated_bare_UV_endpoints',flush=True)
    endpoints={}
    for role in ['primary','replay']:
        geo=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_geometry_tables.json.gz');parts={}
        for family,masses in [('neutral',[r,r,s.S.One]),('charged',[5*r,s.S.One,s.S.One])]:
            deriv=0
            for row in geo['rows'][family]:
                if row['kind']!='UV':continue
                H0,H1=map(expr,[row['H0'],row['H1']]);N0=list(map(expr,row['n0']))
                v00=N0[0]/H0**4;v01=N0[1]/H0**4-4*N0[0]*H1/H0**5
                assert clean(s.integrate(v01,(b,0,1))-s.sympify(row['exact_Iminus1']))==0
                dom,second,third=row['order'];M0=masses[dom]
                M1=masses[second]+b*masses[third] if role=='primary' else b*masses[second]+(1-b)*masses[third]
                deriv-=s.integrate(v01*s.diff(M0,r)/M0+v00*s.diff(M1/M0,r),(b,0,1))
            parts[family]=clean(deriv);assert parts[family]==expr(A['bare_derivative_parts'][family])
        endpoints[role]=clean(s.Rational(18,25)*parts['neutral']+s.Rational(18,5)*parts['charged'])
    assert clean(endpoints['primary']-endpoints['replay'])==0
    tr=A['trace'];K,F=map(expr,[tr['forest_pole'],tr['forest_finite']]);sp=expr(tr['scalar_pole']);vp=expr(tr['vector_pole'])
    assert clean(K-sp-vp)==0 and clean(s.diff(K,r)+endpoints['primary'])==0
    for role in ['primary','replay']:
        oldnum=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_numeric_v2_tables.json.gz')
        for rr in [1,2]:
            p2,p1,f0=map(mp.mpf,oldnum['weighted_total_P2_P1_F0_base_jN0'][str(rr)]);assert p2==0
            k=mp.mpf(str(s.N(K.subs(r,rr),85)));f=mp.mpf(str(s.N(F.subs({r:rr,j:0}),85)))
            for key,actual in [('Rprime_pole',p1+k),('Rprime_finite_constant',f0+f),('Rprime_jN_coefficient',2*p1+k)]:
                printed=mp.mpf(tr['diagnostics'][str(rr)][key]);assert abs(printed-actual)<mp.mpf('1e-18')*(1+abs(actual))
    # Proper-time normalization and the epsilon-positive remaining trace.
    heaterr=mp.mpf(0)
    for scale_log in [mp.mpf(0),mp.mpf('0.71')]:
        ee=mp.mpf(1)/8
        gammaheat=mp.exp(mp.euler*ee+ee*scale_log)*mp.gamma(1+ee)
        intheat=mp.exp(mp.euler*ee+ee*scale_log)*mp.quad(lambda tt:mp.exp(-tt)*tt**ee,[0,1,mp.inf])
        heaterr=max(heaterr,abs(gammaheat-intheat));assert abs(gammaheat-intheat)<mp.mpf('1e-45')
        for rr in [1,2]:
            for row in A['vector_mass_rows']:
                pref=expr(row['prefactor']).subs(r,rr);pp=mp.mpf(str(pref.subs(eps,0)));ev=mp.mpf(str(s.diff(pref,eps)))
                delta=mp.mpf('1e-24');values=[]
                for sign in [-1,1]:
                    evv=sign*delta;HH=mp.exp(mp.euler*evv+evv*scale_log)*mp.gamma(1+evv)
                    values.append(((pp+ev*evv)*HH-pp)/evv)
                error=abs(sum(values)/2-(pp*scale_log+ev));heaterr=max(heaterr,error);assert error<mp.mpf('1e-45')
    print('STAGE sensitive_and_insensitive_controls',flush=True)
    ctrl=A['controls'];assert expr(ctrl['wrong_parent_C_only_pole_shift'])==clean(-s.trace(Qs*(parent-C)))!=0
    assert s.diff(expr(ctrl['wrong_parent_C_only_pole_shift']),r)==0 # explicitly insensitive locality test
    off=tidy(tau-sum((P*tau*P for P in Pr),s.SparseMatrix(45,45,{})));assert len(off.todok())==ctrl['offdiagonal_vector_tau_entries']>0;zero(Qv*off)
    lor=s.SparseMatrix(4,4,{(0,1):1,(1,0):-1});assert s.trace(lor*lor)==-2
    # 1/2 Tr[(2 Ty F)(deltaC F)]. Fphys^2=2 B^2, so divide the
    # single-plane B^2 coefficient by two BEFORE Lambda=-12 Gamma_Fphys^2.
    missed=red(-6*s.trace(lor*lor)*s.trace(Plus*Ty*(-tau*Ty/6)))
    assert missed==expr(ctrl['omitted_curvature_half_CT_double_pole'])!=0
    evchange=clean(-sum(s.diff(expr(row['prefactor']),eps) for row in A['vector_mass_rows']))
    assert evchange==expr(ctrl['omitted_remaining_evanescent_finite_change']) and evchange!=0
    wrong_scalar_embedding_derivative=clean(s.diff(sp/2+vp,r)+endpoints['primary']);assert wrong_scalar_embedding_derivative!=0
    omitted_scalar_kinetic_shift=red(s.trace(Qs*C));assert omitted_scalar_kinetic_shift!=0
    value={'schema':'SCU1_VALIDATION','execution_state':'COMPLETED',
      'status':'QUALIFIED_CURRENT_SUNSET_UV_FOREST_AND_MASS_INDEPENDENT_RPRIME_POLE',
      'elapsed_after_imports':time.perf_counter()-start,'operators_checked_including_zero_complements':True,
      'frozen_real_bilinear_vertex_positions':720,'current_scalar_operator_dimension':4,'embedded_projection_dimension':328,'vector_operator_dimension':45,
      'current_C_diagonal':list(map(str,C.diagonal())),'parent_C_diagonal':list(map(str,parent.diagonal())),
      'trace':tr,'proper_time_and_evanescent_error':mp.nstr(heaterr,25),
      'bare_mass_derivative':cf(endpoints['primary']),'controls':ctrl,
      'wrong_single_scalar_embedding_Rprime_pole_derivative':cf(wrong_scalar_embedding_derivative),
      'omitted_scalar_kinetic_pole_shift':str(omitted_scalar_kinetic_shift),
      'overall_counterterm_adopted':False,'full_renormalized_C1_or_E5_qualified':False,
      'scope':'positive-heavy four-real-scalar VSS restriction, U1 F2, r>0 and g>0',
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(value,sort_keys=True),flush=True)
if __name__=='__main__':main()
