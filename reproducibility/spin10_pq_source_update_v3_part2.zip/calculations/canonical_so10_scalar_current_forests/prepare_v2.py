"""Freeze SCU1 sources, historical bindings and resource contract before science."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-forests-v1-2026-10-20')
BASE='53671c8938a9b8cf037acf9cf2292585748528d5'
def dump(p,raw):
    with p.open('xb') as out:out.write(raw)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
p=CAL/'canonical_so10_scalar_current_laurent/validation_preparation_v3.json';deps={str(p):sha256(p.read_bytes()).hexdigest()}
for n,h in json.loads(p.read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n;deps[n]=h
direct=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
 'docs/RESEARCH_EXECUTION_HANDOFF_V407.md','calculations/canonical_so10_scalar_current_laurent/validation_receipt_v3.json',
 'calculations/canonical_so10_scalar_current_laurent/NEXT_RESEARCH_QUESTION.md',
 'calculations/canonical_so10_width_hard_projection/validation_receipt.json',
 'calculations/canonical_so10_vector_field_normalization_trace/validation_receipt.json',
 'calculations/canonical_so10_finite_counterterm_insertion/validation_receipt_v5.json']
for name in direct:p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['prepare.py','prepare_v2.py','prepare_failed_v1.py.source.txt','PREPARATION_FAILURE_V1.md','run.py','data.py','primary.py','replay.py','verify.py','RECORD.md','DERIVATION.md']:
    p=HERE/name;bb=p.read_bytes()
    if p.suffix=='.py':ast.parse(bb,filename=str(p))
    dump(HERE/(name+'.source.txt'),bb)
    for q in [p,HERE/(name+'.source.txt')]:deps[str(q)]=sha256(q.read_bytes()).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==25747
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
value={'schema':'SCU1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'state_sha256':state,'native_seconds':300,'verifier_seconds':360,
 'private_sample_cap':8*1024**3,'launch_floor':350*1024**2,'new_package_bytes':4*1024**2,
 'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;25747oldGitblobs;no science executed')
