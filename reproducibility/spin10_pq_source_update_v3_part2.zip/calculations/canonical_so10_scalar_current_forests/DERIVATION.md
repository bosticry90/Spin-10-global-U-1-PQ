# SCU1 prospective action-based UV operators and R-prime

Use the same VSS=-g Q eta.T rho Deta vertex as SCP1/SCL1. Let E be four
orthonormal complex charge columns in the real328 field space; P=EE.H is
real. T_a=E.H rho_a E, h=E.H rho_Y E, X=x Pphys+g² MGold, with x=mH² and
MGold=(3/10)Pgold. Let Pplus=sum_(r>0)P_r, G=O.T O. No T_a closure as a
full Spin10 Lie representation is assumed. H covariance still holds since
P commutes with rho_Y: [h,T_a]=sum_b (Ty)_ba T_b.

Define actual current contractions
 C=-sum_ab Pplus_ab T_a T_b,
 Bx=-sum_ab Pplus_ab T_a Pphys T_b,
 Bg=-sum_ab[Pplus_ab T_a MGold T_b+G_ab T_a T_b],
 tau_ab=-Tr(T_a T_b),
 Mx_ab=-Tr[Pphys(T_a T_b+T_b T_a)]/2,
 Mg_ab=-Tr[MGold(T_a T_b+T_b T_a)]/2.
All traces are over actual four real directions, expressed in a unitary
complex basis if desired. Real-field1/2 is not removed by complexifying.

## Scalar subgraph, from the literal derivative vertex

For external scalar momentum p, internal scalar mass m and vector mass z,
the numerator is(p+k)², vector denominator(k-p)²+z. Feynman shift k=l+alpha p
gives l²+(1+alpha)²p² and Delta=(1-alpha)m+alpha z+alpha(1-alpha)p².
The normalized UV pole is
 int_0^1[-2Delta+(1+alpha)²p²]dalpha=2p²-m-z.
The mixed real Gaussian coefficient is-1, so

 Sigma_s,UV/(ell g²/eps)=-2C(-Dbar²)+x Bx+g² Bg.

Replay expands denominators at large k before angular averaging at D0=4;
<n0²>=1/4 supplies the same2p²-m-z. H covariance and UV dimension2 allow
this scalar derivative/mass covariantization; no scalar Lorentz contraction
can supply an additional term linear in F. This does not classify finite
or higher-dimensional terms.

## Vector subgraph and its curvature

The scalar-pair numerator(2k+p)_mu(2k+p)_nu, with closed D0=4, gives
[-(mi+mj)delta-(p²delta-pp)/3]/eps. Its real Gaussian weight-1/2 produces
derivative tau/6 and mass x Mx+g² Mg. To obtain curvature, use the minimal
matrix connection Dbar+g T_a Q_a ONLY as a diagnostic for the current loop.
Its a4 term is-Tr(Omega²)/(24eps). This does not replace the actual parent
seagull; the diagnostic's Q² vertex is kept separately.

The FQ² term has ordered Hessian tau/6[-Dbar²delta+Dbar_nu Dbar_mu].
Changing to canonical Dbar_mu Dbar_nu adds curvature-tau Ty/6. The explicit
2Omega_bar g²[T_a,T_b]Q_aQ_b term adds
-L_ab/6, L_ab=Tr(h[T_a,T_b]). Actual H covariance gives L=Ty tau=tau Ty.
Thus the full canonical UV operator is

 Sigma_v,UV/(ell g²/eps)=(tau/6) K_YM+(x Mx+g² Mg)delta,
 K_YM=-Dbar²delta+Dbar_mu Dbar_nu-2g Ty F_munu.

Both curvature halves are essential. Flat covariantization alone misses
one. Direct matrix traces and H covariance test every45x45 entry, not a
diagonal probe or a favorable Ward completion. No coefficient comes from
SCL1's required remainder. The heat a4 applicability is inherited QDV1,
not a new global determinant/QAP theorem.

The diagnostic seagull uses T_a T_b. The ACTUAL parent seagull uses
E.H rho_a rho_b E, which can have intermediate directions outside P. Their
difference is explicitly calculated using full rho_a E. QMV1's complete
mass-zero theorem cannot be transferred to this restricted current loop.

## Close the pole operators once

Take deltaK_CT=-Sigma_UV, with no finite jets adopted. Scalar
deltaK_s/(ell g²/eps)=2C(-Dbar²)-x Bx-g² Bg. Since background derivatives of
the identity contact vanish in the original C1 dimensional prescription,
the scalar F2 insertion is controlled by

 E_s=-x Bx-g² Bg-2C X,
 Lambda_CT,s/g²=Tr(qs² E_s X^-1 H_eps(X))/(2eps).

Keep all matrices before restricting to the actual diagonal charge spaces.
For the vector, only diagonal mass blocks contribute to a single trace;
off-diagonal operators are NOT zero. Let Qv²=-Ty² and at mass z_r>0 put
t_r=Tr(P_r Qv² tau), b_r=Tr[P_r Qv²(x Mx+g² Mg)]. Then

 Lambda_CT,v/g²=sum_r {-(21/2+eps)t_r/6+(10+eps)b_r/z_r} H_eps(z_r)/eps.

Derivation1 uses K_YM=Kv+Dbar Dbar-z_r and the qualified WHP Ward identity.
Derivation2 separately varies vector kinetic/spin, longitudinal and mass
operators: (10+eps)a, a/2, -(10+eps)b/z for CT a=-tau/6,b=-mass. The1/2
longitudinal term is not a new ghost counterterm. Background identity
contacts and off-shell E=D.F limitations are retained from WHP/VFN.
H_eps=exp(gammaEeps)Gamma(1+eps)(Q²/z)^eps. The finite coefficient includes
the eps-positive prefactor; do not replace it by its D4 pole.
All Lambda coefficients use -12 times Gamma per Fphys², with Fphys²=2B²
for a single magnetic plane. The missing-curvature control divides its
Lorentz-trace B² coefficient by two before this normalization.

These traces count the two scalar-edge embeddings via the full real trace
and the vector edge once. Sunset two-edge subgraphs overlap; there is no
product of their CTs. Rprime=Bbare+CTscalar+CTvector, not a full parent
insertion on this one graph. Coordinate VSP R_VVSS+(C_parent-C_VVSS).

## Independent bare-pole mass dependence

SCL1's projective I0 depends on masses only through its UV endpoint k1^1.
For a largest-time sector, v0=aP2(D4)/H², v00=v0(0), v01=partial_a v0(0).
For masses M0+a M1, the simple-pole mass derivative is exactly

 d_r p1 = -int db [v01 d_r log M0+v00 d_r(M1/M0)].

Use six ordered sectors M1=m_j+b m_k for primary, or three radial triangles
M1=b m_j+(1-b)m_k for replay. Their regular complementary I0 terms have no
mass dependence. Integrate v00, b v00 and v01 as exact rational functions.
Multiply the actual18/25 and18/5 unit-channel weights and keep the neutral
Goldstone derivative0. Only AFTER independently deriving CT operators test
d_r(Pbare+Pforest)=0. A nonzero result is not fixed by fitting CTs.

The remaining constant is anchored to authenticated SCL1 P1(1), not assigned
a rational value by decimal recognition. Finite Rprime is obtained by adding
the measured bare finite coefficient and the independently derived CT trace.
Its remaining overall pole is NOT subtracted/adopted here. Even a local
mass-independent remainder does not prove full renormalization or E5.
