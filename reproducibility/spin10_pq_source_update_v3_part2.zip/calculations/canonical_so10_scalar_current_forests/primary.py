"""SCU1 charge-frame Feynman-parameter/heat derivation and Ward trace."""
from data import *
def main():
    start=begin();role='primary';rho,E,U,S,Pr,Ty,Rh,H,O,G=setup(role)
    mH=s.Rational(426075291,62500000);PH=tidy(E.H*H*E/mH);MG=tidy(E.H*O*O.T*E)
    zero(PH*PH-PH);zero(PH+MG/s.Rational(3,10)-s.eye(4))
    T=[tidy(E.H*R*E) for R in rho];h=tidy(E.H*Rh*E);Qs=tidy(-h*h);Qv=tidy(-Ty*Ty)
    Plus=tidy(sum(Pr[1:],s.SparseMatrix(45,45,{})));Z4=s.SparseMatrix(4,4,{})
    C=Z4.copy();Bx=Z4.copy();Bg=Z4.copy()
    for (aa,bb),z in Plus.todok().items():
        C-=z*T[aa]*T[bb];Bx-=z*T[aa]*PH*T[bb];Bg-=z*T[aa]*MG*T[bb]
    for (aa,bb),z in G.todok().items():Bg-=z*T[aa]*T[bb]
    C,Bx,Bg=map(tidy,[C,Bx,Bg]);tau=s.SparseMatrix(45,45,{});Mx=tau.copy();Mg=tau.copy();L=tau.copy()
    K=[R*E for R in rho];parentx=tau.copy();parentg=tau.copy();parentC=Z4.copy()
    print('STAGE literal_current_and_parent_seagull',flush=True)
    for aa in range(45):
        for bb in range(45):
            V=T[aa]*T[bb]+T[bb]*T[aa]
            tau[aa,bb]=-s.trace(V)/2;Mx[aa,bb]=-s.trace(PH*V)/2;Mg[aa,bb]=-s.trace(MG*V)/2
            L[aa,bb]=s.trace(h*(T[aa]*T[bb]-T[bb]*T[aa]))
            P=(K[aa].H*K[bb]+K[bb].H*K[aa])/2
            parentx[aa,bb]=s.trace(PH*P);parentg[aa,bb]=s.trace(MG*P)
    for (aa,bb),z in Plus.todok().items():parentC+=z*K[aa].H*K[bb]
    tau,Mx,Mg,L,parentx,parentg,parentC=map(tidy,[tau,Mx,Mg,L,parentx,parentg,parentC])
    for aa in range(45):zero(h*T[aa]-T[aa]*h-sum((Ty[bb,aa]*T[bb] for bb in range(45)),Z4))
    zero(L-Ty*tau);zero(tau*Ty-Ty*tau)
    # Actual closed-loop pole coefficients from Feynman parameters, not a fit.
    al,ms,mv,p2=s.symbols('alpha ms mv p2');Delta=(1-al)*ms+al*mv+al*(1-al)*p2
    scalarI=s.integrate(-2*Delta+(1+al)**2*p2,(al,0,1));assert s.expand(scalarI-(2*p2-ms-mv))==0
    vecDD=s.integrate((1-2*al)**2,(al,0,1));assert vecDD==s.Rational(1,3)
    Aloop=-s.expand(scalarI).coeff(p2)*C
    orderCurv=tidy(-tau*Ty/6);commCurv=tidy(-L/6);curv=tidy(orderCurv+commCurv)
    ops={'T':list(map(enc,T)),'scalar_C':enc(C),'scalar_Bx':enc(Bx),'scalar_Bg2':enc(Bg),
      'scalar_loop_slope':enc(Aloop),'scalar_loop_mass_x':enc(Bx),'scalar_loop_mass_g2':enc(Bg),
      'scalar_CT_slope':enc(-Aloop),'scalar_CT_mass_x':enc(-Bx),'scalar_CT_mass_g2':enc(-Bg),
      'vector_tau':enc(tau),'vector_loop_slope':enc(tau*vecDD/2),
      'vector_loop_mass_x':enc(Mx),'vector_loop_mass_g2':enc(Mg),
      'vector_loop_curvature_ordering':enc(orderCurv),'vector_loop_curvature_commutator':enc(commCurv),'vector_loop_curvature_total':enc(curv),
      'parent_scalar_C':enc(parentC),'parent_vector_Mx':enc(parentx),'parent_vector_Mg2':enc(parentg),
      'parent_minus_current_scalar_C':enc(parentC-C),'parent_minus_current_vector_Mx':enc(parentx-Mx),'parent_minus_current_vector_Mg2':enc(parentg-Mg),
      'embedded_P4_scalar_loop_slope':enc(E*Aloop*E.H),'embedded_P4_scalar_mass_x':enc(E*Bx*E.H),'embedded_P4_scalar_mass_g2':enc(E*Bg*E.H)}
    sp=0;sf=0
    for i in range(4):
        xx=s.Rational(3,2)*r*PH[i,i]+MG[i,i]
        effective=-s.Rational(3,2)*r*Bx[i,i]-Bg[i,i]-2*C[i,i]*xx
        prefix=clean(Qs[i,i]*effective/(2*xx));ji=j-s.log(r) if PH[i,i]==1 else j+s.log(s.Rational(3,2)/MG[i,i])
        sp+=prefix;sf+=prefix*ji
    vp=0;vf=0;rows=[]
    for rr,P in enumerate(Pr[1:],1):
        lam=red(s.trace(P*G)/s.trace(P));tw=red(s.trace(P*Qv*tau));mx=red(s.trace(P*Qv*Mx));mg=red(s.trace(P*Qv*Mg))
        bw=clean((s.Rational(3,2)*r*mx+mg)/lam)
        pref=clean(-(s.Rational(21,2)+eps)*tw/6+(10+eps)*bw)
        pp=clean(pref.subs(eps,0));finite=pp*(j+s.log(s.Rational(3,2)/lam))+s.diff(pref,eps)
        vp+=pp;vf+=finite;rows.append({'mass_set':rr,'lambda':str(lam),'tau_charge_trace':str(tw),'mass_trace_over_mass':cf(bw),'prefactor':cf(pref)})
    bare,parts,cert=pole_mass_derivative(role);trace=assemble(role,clean(sp),clean(sf),clean(vp),clean(vf),bare)
    off=tidy(tau-sum((P*tau*P for P in Pr),s.SparseMatrix(45,45,{})));assert off.todok();zero(Qv*off)
    wrongC=clean(-s.trace(Qs*(parentC-C)));assert wrongC!=0
    deltaCurv=tidy(-tau*Ty/6);badDouble=red(12*s.trace(Plus*Ty*deltaCurv));assert badDouble!=0
    controls={'wrong_parent_C_only_pole_shift':cf(wrongC),'wrong_parent_C_only_mass_derivative':'0; locality test INSENSITIVE',
      'omitted_curvature_half_CT_double_pole':str(badDouble),'offdiagonal_vector_tau_entries':len(off.todok()),
      'offdiagonal_tau_F2_trace':'INSENSITIVE; full operator comparison required',
      'omitted_remaining_evanescent_finite_change':cf(-sum(s.diff(expr(v['prefactor']),eps) for v in rows))}
    save(role,{'schema':'SCU1','operators':ops,'trace':trace,'vector_mass_rows':rows,
      'bare_derivative_parts':{k:cf(v) for k,v in parts.items()},'bare_derivative_endpoint_certificate':cert,'controls':controls,
      'embedded_scope':'P4 Sigma P4 only; outside zeros are projection, not full-theory UV zeros',
      'full_renormalized_C1_or_E5_qualified':False},start)
if __name__=='__main__':main()
