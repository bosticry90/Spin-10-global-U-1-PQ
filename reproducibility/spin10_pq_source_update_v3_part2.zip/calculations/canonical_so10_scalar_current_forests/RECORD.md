# SCU1 prospective current-sunset UV subgraphs and subdivided coefficient

Base53671c8938a9b8cf037acf9cf2292585748528d5/main; state113/34of39 unchanged.
Question: derive the actual one-loop UV operators of SCL1's positive-heavy
four-singlet U1 sunset restriction, close their overlapping forest once,
and determine whether the remaining pole is local/mass independent. Use
actual action vertices; never define a coefficient by desired cancellation.

Domain: BFT source-zero xi1, physical real328 scalar/45 vector metrics,
same fixed point and original dimensional C1 prescription. Retain r>0,g>0,
jN=log(Q²/[(3/2)g²]) symbolically. Full other324 scalar, light-vector/EFT,
other primitive, QAP, finite normalization and fullC1 obligations remain.
This is a partial positive-heavy graph grouping, not a new closed theory.

Before computation freeze sources, inputs, assumptions, resource bounds and
expected evidence. Reuse authenticated SCP1 vertices, SCL1 bare Laurent and
WHP/VFN/FCI trace results; do not replay their completed large calculations.
Two sequential native routes: complex charge frame with Feynman parameters
and heat a4 expansion versus real scalar frame, indexed Gram contractions
and direct UV angular Taylor algebra. Compare full matrices including zeros.
The projected scalar current is not a full Spin10 representation. Compute
and retain the DIFFERENCE from the actual parent quartic seagull.

Derive scalar mass and derivative operators and vector mass, derivative and
curvature operators, including derivative ordering and explicit curvature
commutator pieces. Closed-loop UV residue uses D0=4; remaining insertion
trace keeps D=4-2eps. A flat-only vector kernel is insufficient. No equations
of motion, arbitrary field fit or new finite normalization.

Close actual CT=-UV(loop), with real1/2 Gaussian weights, for both scalar
edge embeddings and the vector embedding. Three overlapping subgraphs do
NOT give a product of disjoint CTs. Qualified positive-heavy vector Ward
identity/heat theorem may be reused with its off-shell/contact limitations.
Keep off-diagonal mass/color blocks even when this trace cannot detect them.

Derive the mass-ratio derivative of the actual SCL1 bare simple pole from
its UV endpoint coefficients, independently in its two decompositions.
Test d_r(Pbare+Pforest)=0 without fitting. Anchor the remaining constant
only to the measured bare input; do not rational-fit its decimal value.
Supply finite forest and R-prime coefficients, but do NOT adopt/subtract an
overall local two-loop CT or promote this to finite full renormalization.

Controls: omit either curvature half, scalar kinetic term, overlap embedding,
remaining-loop evanescent coefficient, or neutral mixing; substitute parent
seagull/current operator incorrectly. Disclose controls insensitive in the
F2 trace or the mass-independence test. Shared physical/action/frame/heat/
software/AI premises limit independence. No external scientist/Lean claim.

Caps: native300s each, separate verifier360s after imports,8GiB sampled
private allocation,350MiB launch floor,new package<=4MiB. Exact algebraic
operator/functional coefficients;80digit numeric proper-time controls1e-45.
Assembled bare+forest diagnostics inherit20digit SCL1 input; report18digits
and compare1e-18, not an independent replay/rigorous uncertainty bound.
Exclusive captures/receipts; preserve failed/unfinished runs and corrections.

Success: action-derived complete UV operators/forest for DECLARED restriction
and either verified locality or a qualified mismatch/underdefinition. Actual
remaining pole may be nonzero. Full source-free/E5, C1, physical matching and
authority promotion are outside scope. Preserve old evidence/main; no point,
scheme/foundation/refit, blocked-stage/flavor activation, remote/publication.
Run delegated e4 and byte seals before local commit; custody exit2/seven is
not PASS. Goal remains the full investigation, active and incomplete.
