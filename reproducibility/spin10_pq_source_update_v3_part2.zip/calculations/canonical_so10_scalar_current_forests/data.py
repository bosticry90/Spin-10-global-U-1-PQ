"""SCU1 frozen model inputs, exact IO and bounded execution."""
from pathlib import Path
from hashlib import sha256
import gzip,json,sys,time,threading,os
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,dec,enc
r=s.Symbol('r',positive=True);j=s.Symbol('jN',real=True);eps=s.Symbol('eps',real=True)
b=s.Symbol('b',positive=True);a=s.Symbol('a',positive=True)
LOC={'r':r,'jN':j,'eps':eps,'a':a,'b':b}
def clean(z):return s.cancel(s.expand(z))
def cf(z):return str(clean(z))
def read(p):return json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def expr(z):return s.sympify(z,locals=LOC)
def begin(prep='preparation.json',seconds=300):
    t=time.perf_counter();timer=threading.Timer(seconds,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in read(HERE/prep)['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return t
def save(role,tab,start):
    raw=(json.dumps(tab,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as out:out.write(blob)
    print('RESULT '+json.dumps({'schema':'SCU1_NATIVE','role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def setup(role):
    d=read(PK/('frozen_a10_physical_reconciliation/full_'+role+'.json'))
    rho=[s.SparseMatrix(s.diag(*[dec(d['representation_matrices'][k][a]) for k in ['Phi','Sigma','phi','S']])) for a in range(45)]
    frame=packed(CAL/'canonical_so10_scalar_sm_frame'/f'{role}_tables.json.gz');Q=dec(frame['Q']);ids=[0,1,3,4]
    E=Q[:,[frame['blocks'][i]['offset'] for i in ids]];zero(E.H*E-s.eye(4))
    U=tidy(s.sqrt(2)*s.SparseMatrix.hstack(E[:,0].applyfunc(s.re),E[:,0].applyfunc(s.im),E[:,1].applyfunc(s.re),E[:,1].applyfunc(s.im)))
    zero(U.T*U-s.eye(4));zero(U*U.T-E*E.H);S=tidy(U.T*E);zero(S.H*S-s.eye(4))
    Pr=list(map(dec,packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')['projectors']))
    V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding'])
    Ty=s.SparseMatrix(45,45,{});f=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')['f']
    for aa,bb,c,z in f:
        if V[aa,0]:Ty[c,bb]+=V[aa,0]*s.sympify(z)
    Rh=tidy(sum((V[aa,0]*rho[aa] for aa in range(45)),s.SparseMatrix(328,328,{})));Ty=tidy(Ty)
    H=dec(packed(CAL/'canonical_so10_scalar_quadratic_pullback'/f'{role}_tables.json.gz')['matrices']['H']);O=dec(d['vacuum']['orbit']);G=dec(d['vacuum']['orbit_Gram'])
    return rho,E,U,S,Pr,Ty,Rh,H,O,G
def pole_mass_derivative(role):
    geo=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_geometry_tables.json.gz');out={};cert=[]
    for family,masses in [('neutral',[r,r,s.S.One]),('charged',[5*r,s.S.One,s.S.One])]:
        value=0
        for row in geo['rows'][family]:
            if row['kind']!='UV':continue
            H0=expr(row['H0']);N0=list(map(expr,row['n0']));v00=N0[0]/H0**4
            c0=s.integrate(v00,(b,0,1));c1=s.integrate(b*v00,(b,0,1));cLog=s.sympify(row['exact_Iminus1'])
            dom,second,third=row['order'];M0=masses[dom]
            term=-cLog*s.diff(M0,r)/M0
            if role=='primary':term-=c0*s.diff(masses[second]/M0,r)+c1*s.diff(masses[third]/M0,r)
            else:term-=c1*s.diff(masses[second]/M0,r)+(c0-c1)*s.diff(masses[third]/M0,r)
            value+=term;cert.append({'family':family,'order':row['order'],'v00_int':cf(c0),'b_v00_int':cf(c1),'log_int':str(cLog)})
        out[family]=clean(value)
    return clean(s.Rational(18,25)*out['neutral']+s.Rational(18,5)*out['charged']),out,cert
def assemble(role,scal_pole,scal_fin,vec_pole,vec_fin,bared):
    K=clean(scal_pole+vec_pole);F=clean(scal_fin+vec_fin);assert clean(s.diff(K,r)+bared)==0
    old=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_numeric_v2_tables.json.gz');points={};mp.mp.dps=80
    for rr in [1,2]:
        raw=old['weighted_total_P2_P1_F0_base_jN0'][str(rr)];p1,f0=map(mp.mpf,raw[1:])
        env={r:rr,j:0};k=mp.mpf(str(s.N(K.subs(env),85)));f=mp.mpf(str(s.N(F.subs(env),85)))
        points[str(rr)]={'bare_pole':str(p1),'forest_pole':mp.nstr(k,18),'Rprime_pole':mp.nstr(p1+k,18),
          'forest_finite_at_jN0':mp.nstr(f,18),'Rprime_finite_constant':mp.nstr(f0+f,18),'Rprime_jN_coefficient':mp.nstr(2*p1+k,18)}
    x,y=[mp.mpf(points[rr]['Rprime_pole']) for rr in ['1','2']];assert abs(x-y)<mp.mpf('1e-18')*(1+abs(x))
    return {'scalar_pole':cf(scal_pole),'scalar_finite':cf(scal_fin),'vector_pole':cf(vec_pole),'vector_finite':cf(vec_fin),
      'forest_pole':cf(K),'forest_finite':cf(F),'bare_pole_derivative':cf(bared),'Rprime_pole_derivative':'0','diagnostics':points}
