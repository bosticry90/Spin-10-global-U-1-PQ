# SCU1 preparation-only failure, before any scientific execution

The initial static existence check and prepare.py exited1 because the draft
listed canonical_so10_finite_counterterm_insertion/validation_receipt.json.
The actual final inherited file is validation_receipt_v5.json. No preparation
manifest, source freeze, external control directory or scientific output was
created. Original prepare.py and prepare_failed_v1.py.source.txt are preserved.
prepare_v2.py changes only that path and includes this failure evidence.

The complete short error messages from the two terminal invocations were:

```
AST data.py
AST prepare.py
AST primary.py
AST replay.py
AST run.py
AST verify.py
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
AssertionError: canonical_so10_finite_counterterm_insertion/validation_receipt.json
Traceback (most recent call last):
  File "C:\Users\psboy\Documents\ToE-Next\calculations\canonical_so10_scalar_current_forests\prepare.py", line 22, in <module>
    for name in direct:p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
  File "C:\Program Files\Python310\lib\pathlib.py", line 1126, in read_bytes
    with self.open(mode='rb') as f:
  File "C:\Program Files\Python310\lib\pathlib.py", line 1119, in open
    return self._accessor.open(self, mode, buffering, encoding, errors,
FileNotFoundError: [Errno 2] No such file or directory: 'C:\\Users\\psboy\\Documents\\ToE-Next\\calculations\\canonical_so10_finite_counterterm_insertion\\validation_receipt.json'
```

This is a provenance-preparation engineering error, not a failed scientific
gate or a change in the inherited calculation. Static review also optimized
replay's full-space Gram dot products to omit explicit zero multiplications,
and made the single-plane Fphys²=2B² normalization explicit before freezing.
