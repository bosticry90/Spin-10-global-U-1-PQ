"""SCU1 real-coordinate Gram/UV Taylor derivation and split heat insertion."""
from data import *
def main():
    start=begin();role='replay';rho,E,U,S,Pr,Ty,Rh,H,O,G=setup(role)
    R=[tidy(U.T*A*U) for A in rho];h=tidy(U.T*Rh*U);PH=tidy(U.T*H*U/s.Rational(426075291,62500000));MG=tidy(U.T*O*O.T*U)
    Qs=-h*h;Qv=-Ty*Ty;Plus=tidy(s.eye(45)-Pr[0]);Z4=s.SparseMatrix(4,4,{})
    C=Z4.copy();Bx=Z4.copy();Bg=Z4.copy();parentC=Z4.copy();K=[A*U for A in rho]
    print('STAGE real_coordinate_current_Gram',flush=True)
    for (aa,bb),z in Plus.todok().items():
        C+=z*R[aa].T*R[bb];Bx+=z*R[aa].T*PH*R[bb];Bg+=z*R[aa].T*MG*R[bb];parentC+=z*K[aa].T*K[bb]
    for (aa,bb),z in G.todok().items():Bg+=z*R[aa].T*R[bb]
    C,Bx,Bg,parentC=map(tidy,[C,Bx,Bg,parentC])
    tau=s.SparseMatrix(45,45,{});Mx=tau.copy();Mg=tau.copy();parentx=tau.copy();parentg=tau.copy()
    # Indexed sparse dot products include the full 328-direction intermediate
    # space without spending millions of operations multiplying explicit zeros.
    kd=[A.todok() for A in K]
    for aa in range(45):
        for bb in range(45):
            tau[aa,bb]=sum(R[aa][i,k]*R[bb][i,k] for i in range(4) for k in range(4))
            Mx[aa,bb]=sum(PH[i,i]*R[aa][i,k]*R[bb][i,k] for i in range(4) for k in range(4))
            Mg[aa,bb]=sum(MG[i,i]*R[aa][i,k]*R[bb][i,k] for i in range(4) for k in range(4))
            parentx[aa,bb]=sum(PH[col,col]*value*kd[bb].get((row,col),0) for (row,col),value in kd[aa].items())
            parentg[aa,bb]=sum(MG[col,col]*value*kd[bb].get((row,col),0) for (row,col),value in kd[aa].items())
    tau,Mx,Mg,parentx,parentg=map(tidy,[tau,Mx,Mg,parentx,parentg])
    # Independent large-momentum angular residues in D0=4.
    n2=s.Rational(1,4);n4=s.Rational(1,8);n22=s.Rational(1,24)
    scalarSlope=4*n2-1+4*n2+1;assert scalarSlope==2
    vecLong=4*(4*n4-n2)-8*n2+1;vecTrans=4*(4*n22-n2)
    assert vecLong==0 and vecTrans==-s.Rational(1,3)
    avec=-vecTrans/2
    # Covariant derivative ordering and explicit Omega term independently have equal halves.
    covL=tidy(Ty*tau);ordCurv=tidy(-avec*tau*Ty);expCurv=tidy(-covL/6)
    cv=tidy(ordCurv+expCurv)
    convert=lambda M:tidy(S.H*M*S)
    Tc=list(map(convert,R));Cc,Bxc,Bgc,Pc=map(convert,[C,Bx,Bg,parentC])
    Aloop=convert(-scalarSlope*C)
    ops={'T':list(map(enc,Tc)),'scalar_C':enc(Cc),'scalar_Bx':enc(Bxc),'scalar_Bg2':enc(Bgc),
      'scalar_loop_slope':enc(Aloop),'scalar_loop_mass_x':enc(Bxc),'scalar_loop_mass_g2':enc(Bgc),
      'scalar_CT_slope':enc(-Aloop),'scalar_CT_mass_x':enc(-Bxc),'scalar_CT_mass_g2':enc(-Bgc),
      'vector_tau':enc(tau),'vector_loop_slope':enc(avec*tau),
      'vector_loop_mass_x':enc(Mx),'vector_loop_mass_g2':enc(Mg),
      'vector_loop_curvature_ordering':enc(ordCurv),'vector_loop_curvature_commutator':enc(expCurv),'vector_loop_curvature_total':enc(cv),
      'parent_scalar_C':enc(Pc),'parent_vector_Mx':enc(parentx),'parent_vector_Mg2':enc(parentg),
      'parent_minus_current_scalar_C':enc(Pc-Cc),'parent_minus_current_vector_Mx':enc(parentx-Mx),'parent_minus_current_vector_Mg2':enc(parentg-Mg),
      'embedded_P4_scalar_loop_slope':enc(U*(-scalarSlope*C)*U.T),'embedded_P4_scalar_mass_x':enc(U*Bx*U.T),'embedded_P4_scalar_mass_g2':enc(U*Bg*U.T)}
    # Scalar kinetic and mass determinant responses are kept separately here.
    sp=0;sf=0;qsC=convert(Qs)
    PHc,MGc=map(convert,[PH,MG]);poleS=[]
    for i in range(4):
        xx=s.Rational(3,2)*r*PHc[i,i]+MGc[i,i];ji=j-s.log(r) if PHc[i,i]==1 else j+s.log(s.Rational(3,2)/MGc[i,i])
        kinetic=-qsC[i,i]*(2*Cc[i,i])/2
        mass=qsC[i,i]*(-s.Rational(3,2)*r*Bxc[i,i]-Bgc[i,i])/(2*xx)
        sp+=kinetic+mass;sf+=(kinetic+mass)*ji;poleS.append([cf(kinetic),cf(mass)])
    vp=0;vf=0;rows=[]
    for rr,P in enumerate(Pr[1:],1):
        lam=red(s.trace(G*P)/s.trace(P));tw=red(s.trace(Qv*P*tau));mx=red(s.trace(Qv*P*Mx));mg=red(s.trace(Qv*P*Mg));bw=clean((s.Rational(3,2)*r*mx+mg)/lam)
        aCT=-tw/6;bCT=-bw
        kinetic=(10+eps)*aCT;longitudinal=aCT/2;mass=-(10+eps)*bCT
        pref=clean(kinetic+longitudinal+mass);pp=clean(pref.subs(eps,0));vp+=pp;vf+=pp*(j+s.log(s.Rational(3,2)/lam))+s.diff(pref,eps)
        rows.append({'mass_set':rr,'lambda':str(lam),'tau_charge_trace':str(tw),'mass_trace_over_mass':cf(bw),'prefactor':cf(pref)})
    bare,parts,cert=pole_mass_derivative(role);trace=assemble(role,clean(sp),clean(sf),clean(vp),clean(vf),bare)
    off=tidy(tau-sum((P*tau*P for P in Pr),s.SparseMatrix(45,45,{})));assert off.todok();zero(Qv*off)
    controls={'wrong_parent_C_only_pole_shift':cf(-s.trace(qsC*(Pc-Cc))),'wrong_parent_C_only_mass_derivative':'0; locality test INSENSITIVE',
      'omitted_curvature_half_CT_double_pole':str(red(12*s.trace(Plus*Ty*(-tau*Ty/6)))),
      'offdiagonal_vector_tau_entries':len(off.todok()),'offdiagonal_tau_F2_trace':'INSENSITIVE; full operator comparison required',
      'omitted_remaining_evanescent_finite_change':cf(-sum(s.diff(expr(v['prefactor']),eps) for v in rows))}
    save(role,{'schema':'SCU1','operators':ops,'trace':trace,'vector_mass_rows':rows,
      'bare_derivative_parts':{k:cf(v) for k,v in parts.items()},'bare_derivative_endpoint_certificate':cert,'controls':controls,
      'embedded_scope':'P4 Sigma P4 only; outside zeros are projection, not full-theory UV zeros',
      'full_renormalized_C1_or_E5_qualified':False},start)
if __name__=='__main__':main()
