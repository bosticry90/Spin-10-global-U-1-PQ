# SCU1: action-derived sunset subtractions leave a mass-independent pole

The ultraviolet subgraphs of the previously measured positive-heavy,
four-real-scalar U1 VSS sunset now have explicit operator counterterms.
Two derivations agree on all retained scalar and 45-by-45 vector operators,
including zeros, curvature and mass mixing. The separate verifier reconstructs
the currents from the earlier real-bilinear vertices and qualifies this bounded
result. Final receipt: validation_receipt_v2.json, SHA256
`c662c64a84a2b0ec9e7c83316d33d62aae7aa285f1c90d8a1f9e96c9dcd77886`.

This is the subtraction of proper subgraphs, called R-prime. An overall
two-loop counterterm has NOT been adopted or subtracted. It is not the full
scalar-current family, the finite threshold C1_GS, or E5/A5 restoration.
Scientific authority remains state113, 34/39.

## Scope and actual operators

Use SCL1's same action, reference point, xi1 background gauge, dimensional
measure and four normalized scalar columns in SM blocks0,1,3,4. With
`aN=(3/2)g²`, retain `r=mH²/aN>0`, `jN=log(Q²/aN)` and g>0. Both physical
scalar directions have mass mH²=426075291/62500000; the two gauge-orbit
directions have gauge-fixed mass(3/10)g². Eight positive-vector routes are
included. Four light-vector routes and the other324 scalar directions are
outside this increment. Zeros outside the embedded scalar projector are
projection zeros, not measured full-theory ultraviolet zeros.

DERIVATION.md defines C,Bx,Bg,tau,Mx,Mg from literal current products. The
scalar UV operator is `-2C(-Db²)+mH² Bx+g² Bg`; the vector UV operator is
`(tau/6)K_YM+(mH² Mx+g² Mg)delta`, in ell g²/eps units. K_YM retains its
longitudinal derivative and full `-2g Ty F` curvature. Counterterms are the
negative of these loop operators, not coefficients inferred from a desired
two-loop cancellation. The three two-edge subgraphs overlap; there is no
product of disjoint counterterms.

The two curvature halves come from derivative reordering and the explicit
background-curvature commutator in the scalar heat expansion. Their color
identity is checked on every vector entry. Both halves are necessary.
The vector tau and derivative operator each have33 nonzero entries in2025;
its two mass operators have33 and17. Each curvature half has8. Each reduced
scalar operator is4-by-4; its physical328-by-328 embedding has640 nonzero
entries. These are coefficient-support counts, not independent experiments.

The projected currents are NOT a closed Spin10 representation. Their C
diagonal is(11/10,19/10,19/10,11/10), whereas the actual parent quartic
operator gives(101/10,119/10,119/10,101/10). Full-space intermediate scalar
directions explain the difference. Parent mass-operator differences are also
retained explicitly. Full-theory seagull or mass-zero theorems cannot be
transferred to this current restriction.

## Subtraction and the finite coefficients

In Lambda2/g² units, the proper-subgraph pole is independently derived as

```
K(r) = 57r - 96/25 - 6/(5r).
```

Its scalar part is `-3r-291/25-6/(5r)` and its vector part is `60r+39/5`.
The finite subgraph contribution is

```
K(r) jN + (138/25+6/(5r)) log(r)
          + (57r+42/25) log(5) + 6r+4/5.
```

The last term comes from the epsilon-positive remaining vector trace. It
cannot be recovered by replacing that trace with its D4 pole. The real
Gaussian weight, both scalar embeddings, the vector embedding and
Fphys²=2B² normalization are retained. WHP/VFN identity contacts are used
only in their original C1 background-derivative prescription; no universal
vanishing of regulated Tr1 or general off-shell E=Db.F is asserted.

The six-sector and triangle-sector endpoint formulas independently give
`dPbare/dr=-57-6/(5r²)`. Consequently

```
d/dr [Pbare(r)+K(r)] = 0
```

exactly for r>0. This cancellation was tested AFTER deriving both objects.
No pole was fitted to enforce it. The remaining constant is anchored to
the authenticated SCL1 bare coefficients, not rationalized from a decimal.

Diagnostics below inherit SCL1's20-digit inputs and are displayed to18
significant digits, with jN kept symbolic:

| r | Remaining overall pole | Finite constant at jN=0 | Finite coefficient of jN |
|---|---:|---:|---:|
|1| -23.88 | -111.409020347679435 | -99.72 |
|2| -23.88 | -113.294322329149908 | -157.32 |

These are partial R-prime coefficients, not physical matching predictions.
The nonzero remaining pole has not been declared an anomaly or set to zero.
An overall local subtraction and the full parent assembly remain separate.
In particular, VSP's parent counterterm must be coordinated as
`R_VVSS+(C_parent-C_VVSS)`; this result was not blindly added to that subtotal.

## Verification and controls

Primary uses complex charge columns, Feynman parameters and the covariant
heat curvature. Replay uses real scalar coordinates, indexed Gram products,
large-momentum angular Taylor residues, and separately closes kinetic/spin,
longitudinal and mass insertions. The completed outputs agree before the
dependent verifier starts. The verifier recovers720 old real-bilinear vertex
positions, independently contracts the operators, checks the parent VSP
diagonals, directly differentiates the bare endpoint integrands and checks
proper-time normalization. Its80-digit heat/evanescent discrepancy is
4.479871194619528031610899e-47, below1e-45. This is a numerical check,
not a rigorous error interval or an independent charged two-loop integral.

Controls identify real limits of the selected projection:

* Omitting either curvature half produces a spurious double pole24/5.
* Dropping the remaining-loop epsilon term shifts the finite answer by
  `-6r-4/5`.
* Omitting scalar kinetic subtraction shifts its pole by189/25.
* Counting only half the scalar trace leaves pole derivative
  `(15r²-6)/(10r²)`, generically nonzero.
* Substituting only the parent C changes the pole by-276/5, but leaves its
  mass derivative unchanged. The locality test is INSENSITIVE to that error.
* The vector tau has25 nonzero entries between different mass blocks.
  Their contribution to this single F² trace vanishes. That trace cannot
  validate the off-diagonal operator; the full comparison does.

Both routes share the physical action, reference point, scalar frame, spectral
projectors, inherited heat/master normalization, software and AI authorship.
The vertex replay and negative controls strengthen implementation evidence;
they do not independently validate those premises or the physical model.
No external scientist, Lean certificate or empirical confirmation is claimed.

## Execution and preserved failures

Native primary/replay completed in27.0031546/23.1157118 seconds, within their
300-second caps. Final verifier completed in24.1435458 seconds within360.
Their sampled private allocations peaked at65,265,664 /65,118,208 /
67,563,520 bytes across14/12/13 samples. These are sampled observations,
not continuous peak-memory measurements. The8GiB cap and350MiB launch floor
were respected. New package stays below its4MiB cap.

Two engineering failures remain visible. Preparation initially named a
nonexistent unversioned FCI receipt; no scientific run or manifest existed
then. prepare.py, its source copy and PREPARATION_FAILURE_V1.md preserve it.
prepare_v2.py binds the actual v5 receipt. Later the V1 verifier FAILED at
an overstrict comparison of rounded18-digit display values to unrounded
values. All frozen sources and the complete failed capture remain unchanged.
verify_v2.py requires exact declared display rounding and retains1e-18 for
unrounded diagnostic poles; no physical input, coefficient or raw-value
tolerance changed. No V1 scientific validation receipt exists.

Final commands are `python -B calculations/canonical_so10_scalar_current_forests/prepare_v2.py`,
then the original `run.py` (native calculations completed, V1 verifier failed),
then `run_validation_v2.py`. These exclusive controllers are history, not
commands to rerun over their existing output paths.

The delegated e4 check authenticates existing evidence and expected authority,
structure/read-only/custody exits. It does not rerun or scientifically accept
these calculations. Historical custody must remain exit2/seven, not PASS.

The most useful next action is a bounded infrared treatment of the four
nonzero light-vector singlet routes, before extending their bare/forest
evaluation. A massless vector does not authorize setting its amplitude to
zero, nor using SCL1's strictly positive-mass endpoint algorithm unchanged.
Full scalar/VSS coverage, all other primitives, shared UV/EFT subtraction,
finite normalization, gauge matching, QAP and the protected stages remain.
