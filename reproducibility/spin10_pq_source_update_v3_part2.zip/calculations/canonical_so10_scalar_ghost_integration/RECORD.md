# Exact scalar-ghost integration and complete scalar antighost component V1

Base3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3,main. Previous turn PROGRESS;
full Spin(10)xPQ goal stays active. SGI1 carries the qualified complete scalar
ghost pole through its actual current consumer,exact-once integration and the
ENTIRE affected broken-antighost scalar component. It does not replace the
goal by a selected passing identity. Possible outcomes include a qualified
zero,qualified nonzero component,actual input/representation mismatch or
bounded incomplete work. No coefficient is fitted to obtain a desired zero.

Freeze V282 receipt899b3d9a3aba1357fed9dd14629b62fc8f9501fc6007051023ea8e9de41b66bc,
all canonical packet hashes,actual current V276 recipe and measured source
inputs,full qualified V0/V1 broken-antighost source kernels,and source input/
38-class completeness prerequisites. Use actual canonical FIELD words and
the UNTRANSLATED full328 Cartesian x coordinates. Fixed reference vacuum
coefficients in E/Y do not authorize x->v+x or physical-mass matching. Prior
intrinsic mass pole remains separate;do not double its later VEV descendants.
Keep45 ghost/antighost carriers and all33 broken epsilon directions12..44.

FIRST prove the conservative coefficient encoding bridge. Incoming masks
have basis(2,3,5,I,sqrt7),current m.ex scalar_exact.py has(2,3,5,sqrt7,I).
Use phi(m)=(m&7)|((m&8)<<1)|((m&16)>>1). Verify all32 basis values/all1024
products,conjugation,width monomials and every packet coefficient/word in both
directions. Parameter tuple(g,h,xi,degree) becomes g plus old ex cell
(xi,h,phi(mask)). Reuse the ALREADY qualified actual consumer through
simultaneous_source_slavnov/assessment_v3.py;no new arithmetic engine,no
monkeypatch or edit to sealed helpers. Preserve all complex/root7 components.

SECOND reproduce actual155143-word current known functional and hash
fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241.
Build the new delta from the COMPLETE730610 parameter positions,coalescing
equal canonical field words exactly. Inspect actual preexisting scalar-ghost
projection/coupling provenance BEFORE insertion. Unexpected measured overlap
requires reconciliation,not silent double addition or replacement. Exact
subtraction must recover every prior coefficient/hash;doubling must change
the result;all source and untouched coefficients must remain identical.
Publish an authenticated extended current_tables recipe reusing the qualified
canonical packet and bridge,not another copy of hundreds of thousands of
already recorded coefficients. Normalization remains hbar/(32pi^2 epsilonUV).

THIRD evaluate the complete retained scalar broken-antighost component
 epsilon*d_a Gamma1 - sum_J V_J*EL_left_J Gamma1_source.
Use the actual measured source projection of the SAME updated functional,
not a convenient primitive representative or source subset. Reconcile its
complete source inputs with the qualified146663-position source data,including
source order/derivatives and any recorded boundary relations. All479 nonzero
source-kernel channels and qualified zero channels remain. Verify the even
derivation parity of all kernel terms;ordinary epsilon has antighost parity1.
Primary even slot variation and replay source-Euler/contraction routes must
agree,with explicit currents if required. A boolean named wrong_even in the
old odd-BRST helper is not a reason to use an incorrect parity:for the even
epsilon operation primary uses no odd-prefix sign,replay must derive the
matching gradient sign. Verify typed fixtures and all actual input parities.

The FULL target types are epsilon*C*x and epsilon*C*x*x. Allow all total
g0..5(known source g<=4 and kernel g<=1),jet count<=1 for degree1 and0 for
degree2 from local dimension<=4;prove absent higher contributions by the
actual predecessor census and qualified finite ordinary frontier. Do not
silently throw away differentiated epsilon/source terms or forbid a possible
g5 overlap. Derive a census over EVERY current source row and each permitted
kernel type/jet/coupling route;never infer an unmeasured zero from missing
entries in the partial source-free functional. Include all ordinary prior
scalar-ghost terms if any,not only this increment's node. Check the12 unbroken
antighost dependence-completeness result is preserved by the new delta.

Use actual canonical polynomial coalescence and full-component coefficient
comparisons/hashes. If a nonzero scalar component survives,it is a measured
ordinary/source functional result requiring independent nonlinear insertion/
contact/restoration analysis,not automatically an anomaly. Do NOT assign an
insertion the value needed to cancel it,assume it zero,or promote full QAP.
Distinguish raw-density zero,integrated zero modulo explicit currents,nonzero
component and incomplete computation. No new loop-leg insertion is measured
by this increment. A successful source-free projection is not full Slavnov.

Sizing only:the external integration_support_cost_plan counted719730 new field
word keys,1210 combined coefficient signatures,zero overlap with the old
recipe's WORD UNION and874873 combined word-union upper bound. This is not a
coefficient/integration proof. The source type-only plan inspected all146663
normalized reference rows:66216 eligible,200 active channels,136224 raw
kernel/source position pairs;all planned matches no-jet and degree1. Actual
current-source census must be re-established,not restricted to those reference
indices or assumed identical without proof. These sizes justify two sequential
native workers and one separate verifier,each300sec AFTER imports/8GiB sampled
private/min350MiB available commit. Cache repeated coefficient formatting;
do not perform a full-Gamma variation,allocate dense domains or repeat old
color/UV loops. Preserve exhaustion/failures/version corrections,no truncation
or silent resource extension. Compare completed native outputs before dependent
checks/mutations;all source/capture copies are exclusive and immutable.

A calculation-local compact component packet may intern exact coefficients
and field names to avoid duplicating a million expanded strings. Its schema,
roundtrip,all indices/zeros,hash and scientific scope MUST be validated;this
is serialization of this finite polynomial,not a new benchmark platform or
alternate scientific authority. The delta recipe must reconstruct every actual
coefficient,not just hashes or sample values. Independent validation must
check the full bridge,old/new functional,exact-once properties,all complete
predecessor classifications and component coefficients with a separate exact
arithmetical/graded route. Shared old action/UV/field/source conventions and
AI authorship are limitations,not independent expert validation.

Negative controls:wrong I/root7 bit order,one omitted/sign/repeated delta,
wrong source sign/omission where sensitive,even/odd-prefix and source-order
fixtures,scalar cross factor,changed parameter/width power,missing valid
predecessor and malformed compact coefficient/word indices. Record insensitive
controls. Preflight actual metadata schemas and all new formats before workers;
do not repeat prior string/null/boolean assumptions. Validate bounded completed
work before local commit;authenticate exact parent,paths,source/input maps,
HEAD-index-worktree bytes,receipt and clean tree. Current policy/state bytes
must remain protected. No fresh identical replay pair unless actually run.

Authority34/39/seven false flags;source-dependent38 theorem and finite369/295
coverage stay. Full sourcefreeSlavnov,QAP,measure/IR,32 nonlinear products,
contacts/equivalence,E5/A5/GUT viability remain unqualified. HB1/C5 blocked,
flavor paused;historical quartet-candidate/scalar140%/gauge-matching/custody2-
seven limitations persist. No new input,scheme,benchmark,policy,agent,branch/
worktree,remote/publication,expert/experiment,Lean or completed overall goal.
