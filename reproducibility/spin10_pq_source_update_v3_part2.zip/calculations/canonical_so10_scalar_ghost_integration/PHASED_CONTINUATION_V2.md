# Bounded phased continuation V2

Original SGI1 combined primary timed out;see RUN_DISPOSITION_V1.md. The full
SGI1 scientific objective and every acceptance obligation in RECORD.md remain.
This version changes execution decomposition,not inputs or the required final
result. AGENTS.md delegates this ordinary correction;no routine approval is
needed. Original unused run allowance is not retroactively repurposed.

PHASE A: two new sequential native integration workers and one independent
integration-only verifier,each300sec-after-imports/8GiB sampled private/
min350MiB available commit. Full32/1024/conjugation/width/word bridge,actual
155143 baseline,all730610 parameter coefficients,719730-word delta,exact-once
subtraction/doubling,full updated hash and all untouched/source coefficients
remain required. Cache checks for the1210 exact coefficient signatures and
apply the verified mapping to EVERY word;do not repeat symbolic formatting
per monomial. Preserve failed/source/unfinished versions and full captures.

Phase A additionally records the actual COMPLETE current source projection
and reconciles it with the qualified146663-position source input. Reproduce
the entire preceding ordinary scalar-ghost projection,including any zeros or
nonzero terms,as a checked compact packet. Check unchanged12 unbroken-
antighost dependence. These data permit the dependent component calculation
to reuse the integrated recipe without materializing or rehashing the whole
874873-word known functional again. It must not infer its own missing input
zero from the partial source-free recipe.

Owned A filenames:integration_v2.py/preparation_integration_v2.json,
primary_integration_v2_result/capture.json,replay_integration_v2_result/capture.json,
integration_validation_preparation_v2.json,integration_validation_capture_v2.json,
integration_validation_receipt_v2.json. Freeze exact source/copy/read manifests
before workers. The receipt's scope is INTEGRATION ONLY;it cannot qualify the
scalar component or be confused with a full SGI1 receipt. No new current
recipe is accepted before its complete independent/custody checks.

PHASE B remains a required dependent bounded increment,not an optional result
omitted to achieve a pass. Freeze its exact execution evidence/resource budget
after A supplies accepted projection hashes and actual costs. Reuse A's full
source/projection correspondence and the measured delta,then compute the
ENTIRE33-direction scalar component and actual current-source predecessor
census atg0..5/degrees1,2/allowed jets. Do not rebuild the known functional,
assume insertion zero or fit source coefficients. Independent literal graded
validation and complete compact coefficient evidence remain required. A zero,
nonzero or incomplete component retains the classifications in RECORD.md.

The A allowance above is a new explicit finite commitment after one failure,
not an automatic retry or silent aggregate resource increase. Same per-worker
limits and full scientific obligations hold;source/current-known functional
reproduction is avoided in B only after A has QUALIFIED it. New source text
may reuse frozen V1 helper functions as code,never unqualified failed-run data.
Do not edit failed V1 code or sealed older consumers. The draft V1 verifier
is preserved and classified unexecuted;use a separately frozen A verifier.

Authority34/39/all seven false flags,all blocks/pauses/prior scientific and
custody limitations in RECORD.md remain. Current accepted recipe stays V276
until A qualifies;full SGI1 and the overall Spin(10)xPQ goal stay incomplete.
