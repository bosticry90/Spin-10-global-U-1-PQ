"""Exact-once complete scalar ghost node and full scalar antighost component."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
from fractions import Fraction as F
import importlib.util,json,sys,time,threading,os
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
base=load('qualified_preceding_complete_ghost_recipe',OUT.parent/'canonical_so10_ghost_mass_g4_integration/integration.py');q=base.q;m=base.m;ex=m.ex;s=m.s;read=m.read;digest=m.digest;PKG=m.PKG
incoming=load('qualified_incoming_radical_product',OUT.parent/'canonical_so10_scalar_ghost_actual_pole/pole.py')
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)}
ANTI=[f'bar{i}' if i<12 else f'ub{i}' for i in range(45)]
def auth(folder,name,receipt='validation_receipt.json'):
 p=OUT.parent/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def phi(mask):return (mask&7)|((mask&8)<<1)|((mask&16)>>1)
def bridge_cells(cells,xp=0,hp=0):return ex.Coefficient({(xp,hp,phi(mask)):F(n,d) for mask,n,d in cells})
def reverse_cells(z):return [[phi(mask),v.numerator,v.denominator] for(a,b,mask),v in sorted(z.cells.items(),key=lambda p:phi(p[0][2]))]
def bridge_proof():
 assert incoming.SQ==(2,3,5,-1,7) and ex.SQUARES==(2,3,5,7,-1)
 for a in range(32):
  assert phi(phi(a))==a;A=bridge_cells([[a,1,1]]);assert reverse_cells(A)==[[a,1,1]]
  assert ex.D.to_sympy(A)==incoming.old.e.D.to_sympy(incoming.old.e.Coefficient({(0,0,a):F(1)}))
  cj=ex.Coefficient({(i,j,mask):-v if mask&16 else v for(i,j,mask),v in A.cells.items()});assert reverse_cells(cj)==[[a,-1 if a&8 else 1,1]]
  for b in range(32):
   prod=incoming.mul(((a,1),),((b,1),));assert A*bridge_cells([[b,1,1]])==bridge_cells([[mask,n,1] for mask,n in prod])
 for xp,hp in [(0,0),(2,0),(1,1)]:
  A=bridge_cells([[24,3,5]],xp,hp);assert all((i,j)==(xp,hp) for i,j,mask in A.cells);assert A*bridge_cells([[16,1,1]],1,2)==bridge_cells([[8,21,5]],xp+1,hp+2)
 return {'all32_values_and_inverse_masks':True,'all1024_basis_products':True,'all32_conjugations':True,'all_actual_width_monomials_and_unbounded_exponent_addition':True}
def canonical_data(role):return auth('canonical_so10_scalar_ghost_canonical',role+'_result.json')
def inspect_inputs(role):
 tables,previous,path=base.current_tables(role);data=canonical_data(role);op=auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');primitive=auth('canonical_so10_local_source_primitive',role+'_v2_result.json');closure=read(OUT.parent/'canonical_so10_nonminimal_source_closure/validation_receipt.json');assert closure['execution_state']=='COMPLETED' and closure['all38_current_refined_classes_closed'] and closure['complete_retained_simultaneous_source_local_pole_identity']
 assert previous['updated_known_terms']==155143 and previous['updated_known_sha256']==data['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241' and len(primitive['normalized_source_image'])==146663 and data['all_parameter_packets_complete_inverse_and_implicit_zeros_recovered']
 return tables,previous,path,data,op,primitive
@lru_cache(maxsize=8192)
def format_signature(signature):
 expr=0
 for gp,hp,xp,cells in signature:
  z=bridge_cells(cells,xp,hp);expr+=m.g**gp*ex.D.to_sympy(z).subs({ex.widthM:m.xi,ex.widthH:m.etaH})
 return q.sumtext((str(s.expand(expr)),))
def materialize_node(role,data=None):
 data=canonical_data(role) if data is None else data;parts=defaultdict(list)
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:parts[tuple(word)].append((gp,hp,xp,tuple(tuple(z) for z in cells)))
 node=[]
 for word,items in sorted(parts.items()):
  signature=tuple(sorted(items));value=format_signature(signature);assert value!='0';node.append({'word':list(word),'coefficient':value})
 return node
def direct_delta(data):
 out={};count=0
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:
   key=tuple(m.token(n) for n in word);assert m.word_product((),key)==(key,1);z=bridge_cells(cells,xp,hp);assert reverse_cells(z)==cells;m.put(out,(gp,key),z);count+=1
 assert count==730610;return out
def current_tables(role):
 tables,previous,path=base.current_tables(role);p=OUT/(role+'_result.json');d=auth(OUT.name,p.name);assert d['updated_known_recipe']['previous_recipe_path']==str(path) and d['updated_known_recipe']['previous_recipe_sha256']==digest(path);tables.append(materialize_node(role));return tables,d,p
def establish_epsilon(w):
 assert not any(n.startswith('zz_da') for n in m.names)
 for i in range(45):
  n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1);m.external.add(m.index[n]);w.external[n]=(1,-1,1);w.p[n]=1
 assert len(m.fields)==len(m.sources)==643;return {m.index[f'zz_da{i:02}'] for i in range(12,45)}
def kind(n,E):
 name=m.names[n]
 return 'E' if n in E else'J' if n in m.sources else'x' if name.startswith('x_') else'a' if name in ANTI else'C' if name.startswith('C') else'B' if name.startswith('B') else'A' if name.startswith('A') else'L' if name.startswith('L') or name.startswith('b') else'OTHER'
def target(word,E):
 ty=tuple(sorted(kind(n,E) for n,j in word))
 return len(ty)-2 if ty in [('C','E','x'),('C','E','x','x')] else 0
def project(P,E):
 out={}
 for(gp,word),z in P.items():
  degree=target(word,E)
  if degree:assert 0<=gp<=5 and sum(len(j) for n,j in word)<=2-degree;out[gp,word]=z
 return out
def is_scalar_ghost(word):return tuple(sorted('x' if m.names[n].startswith('x_') else'a' if m.names[n] in ANTI else'C' if m.names[n].startswith('C') else'OTHER' for n,j in word)) in [('C','a','x'),('C','a','x','x')]
def result_poly(rows):
 out={}
 for r in rows:
  word=tuple(m.token(n) for n in r['word']);co=s.sympify(r['coefficient'],locals={'xi':ex.widthM,'eta_H':ex.widthH,'reference_width_M':ex.widthM,'reference_width_H':ex.widthH});assert not co.has(m.g) and not co.has(s.Float);m.put(out,(r['g'],word),ex.coefficient(co))
 return out
def even_action(P,I,role):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
def compact(P):
 values=[];lookup={};rows=[]
 for(gp,word),z in sorted(P.items()):
  cc=tuple((a,b,mask,v.numerator,v.denominator) for(a,b,mask),v in sorted(z.cells.items()));cid=lookup.get(cc)
  if cid is None:cid=len(values);lookup[cc]=cid;values.append([list(k) for k in cc])
  rows.append([gp,[[n,list(j)] for n,j in word],cid])
 return {'schema':'FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1','alphabet':list(m.names),'basis_squared':list(ex.SQUARES),'coefficients':values,'monomials':rows,'sha256_exact_cells':m.fingerprint(P)}
def uncompact(d):
 assert d['schema']=='FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1' and d['alphabet']==m.names and d['basis_squared']==list(ex.SQUARES);values=[]
 for cc in d['coefficients']:
  assert cc and len({(a,b,mask) for a,b,mask,n,v in cc})==len(cc);values.append(ex.Coefficient({(a,b,mask):F(n,v) for a,b,mask,n,v in cc}))
 out={};used=set()
 for gp,word,cid in d['monomials']:
  assert type(cid) is int and 0<=cid<len(values);key=tuple((n,tuple(j)) for n,j in word);assert all(type(n) is int and 0<=n<len(m.names) for n,j in key) and m.word_product((),key)==(key,1) and (gp,key) not in out;out[gp,key]=values[cid];used.add(cid)
 assert used==set(range(len(values))) and m.fingerprint(out)==d['sha256_exact_cells'];return out
def complete_component(updated,prior,delta,op,primitive,E,role):
 source_before={k:z for k,z in prior.items() if any(n in m.sources for n,j in k)};source_after={k:z for k,z in updated.items() if any(n in m.sources for n,j in k)};assert source_before==source_after;S=m.decode(q.rawrows(source_before));assert len(S)==146663 and all(sum(n in m.sources for n,j in word)==1 for gp,word in S) and not any(j for gp,word in S for n,j in word if n in m.sources)
 reference=result_poly(primitive['normalized_source_image']);assert S==reference;V={m.index[J]:result_poly(rows) for J,rows in op['all33_kernel_maps'].items()};assert len(V)==479 and all(J in m.sources for J in V)
 for J,P in V.items():
  for(gp,word),z in P.items():assert gp in [0,1] and sum(n in E for n,j in word)==1 and not any(n in m.sources for n,j in word) and sum(m.par[n] for n,j in word)%2==m.par[J]
 Vp={g:{J:{key:z for key,z in P.items() if key[0]==g} for J,P in V.items() if any(key[0]==g for key in P)} for g in [0,1]};spec=defaultdict(set)
 for J,P in V.items():
  for(gp,word),z in P.items():spec[J].add((gp,tuple(sorted(kind(n,E) for n,j in word)),sum(len(j) for n,j in word)))
 ordered=sorted(S);selected={};routes=defaultdict(list)
 for i,key in enumerate(ordered):
  gp,word=key;J=next(n for n,j in word if n in m.sources);rest=tuple(sorted(kind(n,E) for n,j in word if n!=J));jets=sum(len(j) for n,j in word)
  for gv,ty,kjet in spec.get(J,()):
   both=tuple(sorted(rest+ty));degree=len(both)-2 if both in [('C','E','x'),('C','E','x','x')] else 0
   if degree and jets+kjet<=2-degree:assert 0<=gp+gv<=5;selected[key]=S[key];routes[gp+gv,gv,degree,jets+kjet].append(i)
 oldrows=[r for r in q.rawrows(prior) if is_scalar_ghost(tuple(m.token(n) for n in r['word']))];oldscalar=m.decode(oldrows);ordinary_input=m.add(oldscalar,delta);actual=m.decode([r for r in q.rawrows(updated) if is_scalar_ghost(tuple(m.token(n) for n in r['word']))]);assert actual==ordinary_input
 shift={m.index[f'ub{i}']:m.elementary(m.index[f'zz_da{i:02}']) for i in range(12,45)};ordinary=project(even_action(actual,shift,role),E);source={};slot={}
 for gv,I in Vp.items():
  EL=m.EL_all(selected,set(I));source[gv]=project(m.add(*(m.mul(Q,EL.get(J,{})) for J,Q in I.items())),E);slot[gv]=project(even_action(selected,I,role),E);assert source[gv]==slot[gv]
 raw=m.add(ordinary,m.scale(source[0],-1),m.scale(source[1],-1));N,cur=base.anchor(raw,E);assert N==project(N,E);assert raw==m.add(N,*(m.D(P,mu) for mu,P in enumerate(cur)));per=[]
 for gp in range(6):
  for degree in [1,2]:
   Fpart={key:z for key,z in N.items() if key[0]==gp and target(key[1],E)==degree};per.append({'g':gp,'scalar_degree':degree,'nonzero_positions':len(Fpart),'jet_positions':sum(any(j for n,j in word) for gg,word in Fpart)})
 packet=compact(N);assert uncompact(packet)==N;mut=dict(N)
 if mut:
  key=next(iter(mut));mut[key]=-mut[key];assert mut!=N
 wrong=project(m.action(actual,shift,'primary'),E);source_total=m.add(source[0],source[1]);controls={'omit_or_double_delta_changes_ordinary_component':bool(project(even_action(delta,shift,role),E)),'odd_instead_of_even_prefix_changes_ordinary':wrong!=ordinary,'reverse_source_sign_changes_component':bool(source_total),'omit_source0_changes_component':bool(source[0]),'omit_source1_changes_component':bool(source[1]),'one_actual_component_sign_changes_polynomial':bool(N)}
 census={'all_source_positions':len(S),'source_sha256_exact_cells':m.fingerprint(S),'all_normalized_source_reference_positions_match_actual_current':True,'all_kernel_source_channels':len(V),'all_kernel_parities_same_as_sources_even_D':True,'all_eligible_source_positions':len(selected),'selected_source_sha256_exact_cells':m.fingerprint(selected),'source_rows_order':'sorted(g,canonical typed word) of actual current source polynomial','complete_routes':[{'total_g':gp,'kernel_g':gv,'scalar_degree':degree,'jets':jets,'source_indices':sorted(set(ids))} for(gp,gv,degree,jets),ids in sorted(routes.items())],'all_total_orders0_through5_tested':True,'no_source_jets_in_entire_actual_input_proved':True}
 return {'complete_component':packet,'component_disposition':'RAW_ZERO' if not raw else'INTEGRATED_ZERO_MODULO_EXPLICIT_CURRENTS' if not N else'NONZERO_ORDINARY_SOURCE_COMPONENT_INSERTION_REMAINS_UNMEASURED','ordinary_component_sha256_exact_cells':m.fingerprint(ordinary),'source_component_by_kernel_g':{str(gv):m.description(P) for gv,P in source.items()},'raw_component_sha256_exact_cells':m.fingerprint(raw),'four_explicit_currents':[compact(P) for P in cur],'complete_predecessor_census':census,'whole_component_by_g_and_scalar_degree':per,'old_ordinary_scalar_ghost_positions':len(oldscalar),'controls':controls,'insensitive_controls':[key for key,value in controls.items() if not value]}
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,hsh in prep['input_sha256'].items():assert digest(Path(p))==hsh,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SCALAR_GHOST_INTEGRATION_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);stages=[]
 def stage(name,fn):
  print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();answer=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return answer
 w=m.setup();E=establish_epsilon(w);proof=stage('exact32_1024_conjugation_width_basis_adapter',bridge_proof);tables,previous,path,data,op,primitive=inspect_inputs(role);prior=stage('complete155143_current_known_functional',lambda:q.combine(tables));assert len(prior)==155143 and q.hashrows(q.rawrows(prior))==previous['updated_known_sha256'];node=stage('complete_canonical_packet_materialized_via_existing_consumer',lambda:materialize_node(role,data));delta=stage('all_numeric_packet_words_and_parameter_cells_exactly_decoded',lambda:direct_delta(data));assert m.decode(node)==delta and not any(m.names[n].startswith('bar') for gp,word in delta for n,j in word)
 additions={tuple(m.token(n) for n in row['word']):row['coefficient'] for row in node};assert len(additions)==len(node)==719730 and not set(additions)&set(prior),'UNEXPECTED_PRIOR_MEASURED_OVERLAP_REQUIRES_RECONCILIATION'
 def insert():
  if role=='primary':return dict(prior)|additions
  return q.combine([q.rawrows(prior),node])
 updated=stage('exact_once_sparse_integration',insert);assert len(updated)==874873 and all(updated[k]==z for k,z in prior.items());inverse=dict(updated);double=dict(updated)
 for key,z in additions.items():
  value=q.sumtext(tuple(sorted([updated[key],str(-q.num(z))])));assert value=='0';del inverse[key];double[key]=q.sumtext(tuple(sorted([updated[key],z])));assert double[key]!=updated[key]
 assert inverse==prior and q.hashrows(q.rawrows(inverse))==previous['updated_known_sha256'];assert {k:z for k,z in prior.items() if any(n in m.sources for n,j in k)}=={k:z for k,z in updated.items() if any(n in m.sources for n,j in k)};updated_hash=stage('updated_complete_known_functional_hash',lambda:q.hashrows(q.rawrows(updated)));component=stage('complete_all33_scalar_antighost_component_and_predecessors',lambda:complete_component(updated,prior,delta,op,primitive,E,role))
 result={'schema':'SCALAR_GHOST_EXACT_INTEGRATION_COMPLETE_COMPONENT_V1','route':role,'scientific_disposition':'EXACT_ONCE_COMPLETE_SCALAR_GHOST_INTEGRATION_AND_COMPLETE_SCALAR_COMPONENT','coefficient_basis_adapter_proof':proof,'all730610_parameter_cells_and_words_decode_without_loss':True,'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'add_once_recipe':'materialize_node(role) from qualified canonical packet with checked basis adapter','canonical_packet_path':str(OUT.parent/'canonical_so10_scalar_ghost_canonical'/(role+'_result.json')),'canonical_packet_sha256':digest(OUT.parent/'canonical_so10_scalar_ghost_canonical'/(role+'_result.json'))},'prior_known_terms':len(prior),'prior_known_sha256':previous['updated_known_sha256'],'updated_known_terms':len(updated),'updated_known_sha256':updated_hash,'new_word_positions':len(additions),'changed_existing_word_positions':0,'removed_existing_word_positions':0,'new_delta_g_word_positions':len(delta),'new_delta_sha256_exact_cells':m.fingerprint(delta),'sourcefree_prior_positions':41452,'sourcefree_updated_positions':41452+len(additions),'sourceimage_positions':146663,'exact_subtraction_recovers_entire_prior_and_doubling_changes':True,'all_sources_and_untouched_coefficients_identical':True,'all_new_unbroken_antighost_derivatives_zero':True,'complete_scalar_assessment':component,'all_seven_quantum_flags_false':data['all_seven_quantum_flags_false'],'independent_new_insertion_loop_or_full_Gamma_variation':False,'full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5':False,'shared_limits':'Measured canonical poles/current source/kernel/UV/finite-domain proofs,software and AI author shared. Exact ordinary/source functional component,not independent nonlinear insertion or full quantum restoration','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};assert not any(result['all_seven_quantum_flags_false'].values());print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
