# Prospective Phase A integration qualification

Require completed independent integration_validation_receipt_v3.json,current
source/input/capture/count-correction checks and exact committed-byte custody.
This report alone accepts no result. The whole SGI1 scalar-component goal
remains incomplete until the separate dependent Phase B is qualified.

Both V2 native integration workers completed with identical coefficients and
full updated-known-functional hash
e1e30f1acd769b5d2140613f17d7b75b0f6fdd905f15bb6b009dc2438015fa84.
The known functional grows155143->874873 canonical FIELD words,adding719730
new words with zero prior overlap and no change to any existing coefficient.
The730610 parameter positions merge into723722(g,word) positions. The latter
are different counts;none measures experimental success or E5 completion.

The complete32-basis/1024-product/conjugation/width adapter reuses the existing
five-root consumer. All complex/root7 components and exact parameter powers
remain. Full decode agrees with the measured packets. Exact inverse recovers
the entire original hash;doubling changes every added word. Signature caching
covers all1210 distinct actual coefficient strings and every new word.

Complete source projection remains120219 field words/146663(g,word) positions
and matches the qualified measured source input exactly,with no differentiated
source fields. The complete preceding ordinary scalar-ghost projection is
zero. These are proposed COMPLETE input/projection results for Phase B,not
evidence that its antighost component vanishes or an insertion is renormalized.

One diagnostic count was incorrect in the successful V2 outputs:it added old
g-word positions to new field words. Original results/captures are preserved.
The metadata-only V3 correction changes no coefficient or functional hash.
Correct conventions,subject to independent reconstruction:

| Quantity | Before | After |
| --- | --- | --- |
| All canonical field words | 155143 | 874873 |
| Source-free field words | 34924 | 754654 |
| Source-free(g,word) positions | 41452 | 765174 |
| All(g,word) positions | 188115 | 911837 |

The earlier mixed diagnostic761182 is explicitly superseded,not scientific
evidence. Independent validation must reconstruct the actual prior decoded
source-free polynomial and the delta,not accept these sums by assertion.

Original combined worker failed at300sec(exit124),parent301.691sec/private
peak3650736128;no result accepted. Phased primary234.031sec/3945349120 private,
replay291.642sec/4479041536,completed within the same300sec-after-imports/
8GiB/min350MiB available-commit limits. Independent Phase A remains required.
Original replay/verifier were not executed;their drafts/allowances are not
misrepresented. Metadata correction is not another physics run or fresh replay.

TrackB: after one timeout,the execution was divided to reuse complete source/
projection evidence and avoid rebuilding a large known functional in Phase B.
An actual field-versus-g-word count error was found and preserved. This remains
a bookkeeping limitation. Shared action/poles/source/UV/conventions,coefficient
normal-form software and AI authorship limit independent corroboration.

After A qualifies,use integration_v3.current_tables(role) with its explicit
integration_validation_receipt_v3.json,not V1/V2 entries or the wrong count.
Freeze and compute the COMPLETE33-direction scalar component atg0..5 and
both scalar degrees using the accepted source/projection snapshots. No full
known-functional rebuild,new loop,insertion fit or assumed cancellation.
Source-freeSlavnov,QAP,measure/IR,32 nonlinear products,contacts/equivalence,
E5/A5 remain unqualified;authority34/39/seven false flags,HB1/C5 block,flavor
pause,quartet-candidate/scalar140%/gauge-matching/custody2-seven limits persist.
No physical input,scheme,benchmark,policy,remote action or completed full goal.
