# Preserved incomplete combined run

The original primary worker exited124 at its frozen300-second timer. Parent
wall301.691sec,sampled private peak3650736128 bytes;launch and post-run
observations qualified. primary_capture.json exactly matches the external
primary_full_capture.json. No primary_result.json or validation receipt exists.
The completed stage labels do NOT qualify their unexported intermediate data.
Original code,source copy,preparation and complete failed capture are immutable.
Original replay and independent verifier were not executed. The original
verify.py is an unexecuted draft,not independent evidence.

The run reached scalar-component assembly after coefficient-bridge,baseline,
node/decode,integration and updated-hash stage labels. It proves a resource
failure of the combined execution,not a nonzero physical remainder,quantum
contradiction or accepted integration. The actual accepted current recipe
remains V276155143 words/hashfe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241.

Review found avoidable repeated work:the combined code rebuilds an entire
874873-word array to re-extract a scalar projection whose delta is already
known,decodes that same delta again,and computes negative symbolic strings
per719730 word despite only1210 coefficient signatures. Its scalar phase
then repeats large hashes/anchors after the integration work has consumed
part of the same time budget. There is no competent reason to repeat that
combined approach or merely increase the timer.

Use PHASED_CONTINUATION_V2.md:validate exact integration separately,then reuse
its complete source/ordinary-scalar projection evidence in a bounded dependent
component calculation. Cache coefficient checks by exact signatures but still
cover every word. Scientific domain,coefficients,full-source census,negative
controls and final combined SGI1 completion requirements are unchanged. No
unrecorded intermediate value from this failed worker is reused as evidence.
