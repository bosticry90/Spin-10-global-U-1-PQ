"""Accepted-recipe entry point for metadata-corrected integration-only records."""
from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('phased_complete_integration_functions',OUT/'integration_v2.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
read=u.read;digest=u.digest;q=u.q;m=u.m;core=u.core
def current_tables(role):
 tables,previous,path=core.base.current_tables(role);p=OUT/(role+'_integration_v3_result.json');d=core.auth(OUT.name,p.name,'integration_validation_receipt_v3.json');assert d['updated_known_recipe']['previous_recipe_path']==str(path) and d['updated_known_recipe']['previous_recipe_sha256']==digest(path) and d['sourcefree_position_convention']=='g_power_and_canonical_field_word_widths_in_coefficient';tables.append(core.materialize_node(role));return tables,d,p
