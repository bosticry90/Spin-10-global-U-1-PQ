# Phase A completed: exact integration with corrected conventions

Independent receipt99c192cc7fa6cf22b638af35d787ccc50b8db399851fc5d645a33e355eccba44
completed. Final qualification requires the remaining local committed-byte
checks;the prospective V3 gate and every mathematical obligation are retained.
This accepts INTEGRATION ONLY. The complete SGI1 scalar component remains an
explicit required dependent Phase B,not a passing identity assumed here.

The entire measured scalar-ghost contribution is now integrated once into the
known partial functional:155143->874873 field words,hash
e1e30f1acd769b5d2140613f17d7b75b0f6fdd905f15bb6b009dc2438015fa84.
All719730 new field words were absent before;all old coefficients and all
source terms are identical. Subtraction recovers the complete prior hash,
and doubling changes each new word. The32-basis/1024-product/conjugation/
width adapter preserves every730610 parameter coefficient and723722(g,word)
delta position. No loop coefficient was fitted or remeasured in this step.

Correct counts were independently reconstructed from actual decoded polynomials:
source-free FIELD words34924->754654;source-free(g,word) positions41452->765174;
all(g,word) positions188115->911837. Source input is unchanged120219 field
words/146663(g,word) positions. The native V2 diagnostic mixed count761182 is
preserved and superseded by V3 derived records;no coefficient or hash changed.

The COMPLETE actual source projection equals the qualified measured source
input,has no differentiated source fields,and retains exact fingerprint
b1171c9963ff4d5fc1c1497ab70d781f1c9ea36e77ce5507563fe70d3af8cc88.
The preceding complete ordinary scalar-ghost projection is zero. These proven
facts permit Phase B to use the measured delta and source input without
rebuilding/reformatting the large known functional. The source-free functional
as a whole remains partial;no missing source-free coefficient is set to zero.

The original combined worker timed out at300sec and remains FAILED(exit124),
with no result. Phased native primary234.031sec/3945349120 sampled private,
replay291.642sec/4479041536;independent185.782sec/2101796864. All successful
300sec-after-imports/8GiB/min350MiB available-commit and observation gates pass.
One failed original combined worker,zero new phased-native or independent
failures,zero fresh identical replay pairs. Metadata-only count correction
adds no physics execution. All6 binding maps1849/1861/18/18/1887/1887 and
source/capture/correction copies must agree at custody.

TrackB: one expensive aggregate timeout led immediately to a dependency split
and exact-signature caching. Review also exposed a real raw-word versus
coupling-resolved count error. Both failures/limitations remain recorded.
Independent incoming-radical arithmetic reconstructed the entire delta,
functional hashes,source/projection inputs and count conventions. Shared
action,poles,UV/source/word premises,normal-form library and AI author remain
limits;these are not independent expert or experimental confirmations.

Use integration_v3.current_tables(role) and its explicit
integration_validation_receipt_v3.json. V1 is incomplete;V2 diagnostics are
uncorrected. The new recipe reuses the complete recorded canonical packet
through the checked existing consumer,avoiding another expanded coefficient
archive. It is authenticated executable evidence,not a new scientific authority.

Next freeze Phase B over all33 broken directions,g0..5,scalar degrees1/2 and
all allowed jets. Reuse A's accepted source/projection proof;do not recompute
the whole874873-word known functional. Compute both complete ordinary/source
component and predecessor census with distinct exact routes and explicit
currents. Preserve a nonzero result as a missing insertion/restoration question;
never infer an anomaly,fit an insertion or assume it vanishes.

Source-dependent38 theorem and finite369/295 coverage stay. Full sourcefree
Slavnov,QAP,measure/IR,32 nonlinear products,contacts/equivalence,E5/A5/GUT
viability unqualified. Authority34/39/seven false flags,HB1/C5 block,flavor
pause,quartet-candidate/scalar140%/gauge-matching/custody2-seven failures
unchanged. No physical input,scheme,benchmark,policy,remote or full-goal adoption.
