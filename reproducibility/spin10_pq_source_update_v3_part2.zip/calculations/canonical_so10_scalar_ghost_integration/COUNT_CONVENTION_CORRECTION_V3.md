# Diagnostic count convention correction V3

The first phased primary completed with all coefficients/current-functional
hashes intact,but its inherited sourcefree_updated_positions diagnostic used
41452(old g-word positions)+719730(new FIELD words). Those are different
count conventions. The result is not yet independently qualified. Preserve
the completed V2 native result/capture/source;do not rerun the physics merely
to change this report field. Let the already running V2 replay finish under
its frozen source/resource contract,then compare both complete outputs.

Correct the record through a separately frozen metadata-only derivation:
old41452 is len(the decoded source-free g,word polynomial),as specified in
the qualified V276 producer. The disjoint new delta has723722 g-word positions
and719730 field words. Thus updated source-free g-word count is765174.
The actual source projection has120219 field words/146663 g-word positions.
From155143 total prior field words,the prior source-free FIELD word count is
34924;the updated count is754654 of874873 total field words. The full updated
g-word count is911837. No coefficient,width,coupling,field map,hash,normalization
or physical input changes. Independent validation must reconstruct these
counts from the actual old/new decoded polynomials,not just accept this sum.

Corrected owned records are primary_integration_v3_result.json and
replay_integration_v3_result.json,with explicit field/g-word labels and the
original V2 source/result SHA bindings. A metadata-only30-second derivation
may produce them after both V2 captures complete. Preserve the superseded
mixed count and explain it;do not rewrite the successful V2 data. Use an
explicit integration_validation_receipt_v3.json and integration_v3 current
recipe for acceptance. Its scope remains PHASE A INTEGRATION ONLY;Phase B
component and all final SGI1 obligations remain pending. No heavy native
retry/resource expansion is authorized or needed by this count correction.

Original combined timeout count1 remains;V2 successful science workers are
not failures,but their incorrect diagnostic is a real bookkeeping error.
The first phased attempt missed a count-convention schema distinction. This
correction must not weaken the full coefficient/source/inverse/hash checks
or misclassify the diagnostic as a physical obstruction. Formal authority,
blocks,pauses,old evidence and broader quantum-restoration limits stay.
