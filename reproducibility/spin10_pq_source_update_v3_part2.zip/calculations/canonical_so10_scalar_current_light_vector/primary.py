"""SLI1 actual heat-polynomial integration and frozen route weights."""
from data import *

def main():
    start=begin();role='primary'
    old=packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz')
    P=expr(old['P2']).subs({q1:-1,q2:1,qv:0});U=st*tt+st*ut+tt*ut
    numerator=clean(P*U**2);assert not s.denom(numerator).has(st,tt,ut)
    poly=s.Poly(numerator,st,tt,ut);beta=D/2+2;terms=[];total=0
    print('STAGE integrate_actual_massless_vector_proper_time',flush=True)
    for (ii,jj,kk),coeff in poly.terms():
        assert ii+jj+kk==5 and kk>=0
        factor=s.gamma(kk+1)*s.gamma(beta-kk-1)*s.gamma(ii+kk+2-beta)*s.gamma(jj+kk+2-beta)*s.gamma(ii+jj+kk+3-2*beta)/(s.gamma(beta)*s.gamma(ii+jj+2*kk+4-2*beta))
        ratio=gamma_ratio((coeff*factor).subs(D,4-2*eps));total+=ratio
        irarg=(beta-kk-1).subs(D,4);assert irarg>0
        terms.append({'powers':[ii,jj,kk],'coefficient_D':str(coeff),'gamma_ratio':cf(ratio),'IR_gamma_argument_at_D4':str(irarg)})
    total=clean(total);unit=laurent(total);assert clean(s.limit(P,ut,s.oo)).is_finite is not False
    rho,E,_,_,Pr,Ty,Rh,H,O,G=setup(role)
    PH=tidy(E.H*H*E/s.Rational(426075291,62500000));MG=tidy(E.H*O*O.T*E);T=[tidy(E.H*A*E) for A in rho]
    h=tidy(E.H*Rh*E);Qs=tidy(-h*h);Qv=tidy(-Ty*Ty);C=s.SparseMatrix(4,4,{});Bx=C.copy();Bg=C.copy();parent=C.copy()
    K=[A*E for A in rho]
    for (aa,bb),zz in Pr[0].todok().items():
        C-=zz*T[aa]*T[bb];Bx-=zz*T[aa]*PH*T[bb];Bg-=zz*T[aa]*MG*T[bb];parent+=zz*K[aa].H*K[bb]
    C,Bx,Bg,parent=map(tidy,[C,Bx,Bg,parent]);zero(Pr[0]*G);zero(C-Qs);zero(parent-C)
    scu=packed(CAL/'canonical_so10_scalar_current_forests'/f'{role}_tables.json.gz')['operators']
    for name in ['vector_tau','vector_loop_mass_x','vector_loop_mass_g2']:zero(Qv*Pr[0]*dec(scu[name]))
    routes=[v for v in old['weights'] if v[0]==0 and s.sympify(v[3])!=0];qs=list(map(s.sympify,old['charges']))
    weights={'physical':0,'Goldstone':0}
    for _,ii,jj,ww,qvector in routes:
        assert s.sympify(qvector)==0 and {ii,jj} in [{0,3},{1,2}]
        V=dec(next(col for i0,j0,col in old['vertices'] if i0==ii and j0==jj));zero(Ty*Pr[0]*V)
        group='physical' if {ii,jj}=={0,3} else 'Goldstone';weights[group]+=s.Rational(3,2)*s.sympify(ww)*qs[ii]**2
    weights={k:red(v) for k,v in weights.items()};cp,cf0=scalar_closure(C,Bx,Bg,PH,MG,Qs)
    save(role,{'schema':'SLI1','unit_gamma_ratio':cf(total),'unit_bare_Laurent':list(map(cf,unit)),
      'heat_terms':terms,'P2_large_u_limit':str(clean(s.limit(P,ut,s.oo))),
      'light_routes':routes,'weighted_unit_multipliers':{k:str(v) for k,v in weights.items()},
      'operators':{k:enc(v) for k,v in [('C0',C),('Bx0',Bx),('Bg0',Bg),('parent_C0',parent)]},
      'vector_CT_F2_zero_by_actual_neutral_support':True,
      'assembly':assemble(role,unit,weights,cp,cf0)},start)
if __name__=='__main__':main()
