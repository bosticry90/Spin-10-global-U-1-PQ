# After SLI1: expand the full scalar-current domain through its actual SM structure

The four-scalar U1 restriction now covers all12 nonzero vector-mass routes,
with bare and proper-subgraph coefficients and a justified neutral-vector
infrared limit. Its remaining overall pole has not been subtracted; full
VSS/C1 and matching remain open. Reuse these completed tests; another small
convenient singlet example would not address the full-model coverage gap.

The next bounded question is whether the general ordered kernel's charge
weights can be contracted over the complete328-real-scalar carrier without
expanding every component and repeating equivalent integrals.

Recover the actual35 SM classes,65 multiplicity seed columns, weighted kinetic
metric, physical Hessian, gauge-orbit mass and vector Gram projectors. The
VSP data already provide full20 Casimir/color operators and show genuine
noncommutation with some mass blocks. Do not substitute beta-function counts,
commuting scalar matrices or a single seed for its entire multiplicity space.
The inverse of the full SM frame is D^-1 Q.H, not Q.H alone.

Candidate structural reduction, NOT YET PROVED FOR THIS CALCULATION:
the quadratic charge structures in P2 may be expressed using three weights
q1²,q2²,qv² when the actual vertex obeys q1+q2+qv=0. Averaging each unbroken
simple ideal may replace the scalar endpoint square by its actual irrep
Casimir, while the vector square requires the proper adjoint insertion or
refined vector SM projectors. Degenerate vector masses need not have a
single Casimir or hypercharge square. Test these statements on the actual
action maps and all generators before relying on them.

Construct a complete H-covariant pair/mass-slot inventory with those weights,
including zero complements and multiplicity mixing. Use independent full
contractions and marginal sum rules against the already qualified VSP
operators to detect missed pairs, wrong metric/conjugation and degeneracy
factors. Its success would supply a manageable complete list of genuine
remaining integral families, not measured amplitudes or a completed C1.

Keep5 soft/323 positive scalar directions, all12 light/33 heavy vector
directions and the physical/potential-vs-gauge-fixed mass distinction.
SLI1's proof assumes two positive scalar masses and neutral vector support;
it does not settle massless scalar, charged vector or multiple-soft routes.
Select the next missing amplitude only after this full-domain reduction and
its matching/IR requirements are clear. No new physical point, finite
tadpole prescription, overall counterterm or gauge condition is selected.

The scientific goal remains the full Spin10xPQ investigation, not this
restriction. E5/A5, HB1/C5, flavor pause, finiteC1 acceptance and physical
quantum-control limitations retain their existing protected scopes.
