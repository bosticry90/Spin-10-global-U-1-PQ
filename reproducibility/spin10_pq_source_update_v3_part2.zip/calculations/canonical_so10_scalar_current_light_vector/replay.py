"""SLI1 independent Fourier tensor reduction and real-metric route support."""
from data import *

def main():
    start=begin();role='replay';dd=4-2*eps
    def tad(aa):return s.gamma(aa-dd/2)/s.gamma(aa)
    def I(aa,bb,cc):
        if cc==0:return tad(aa)*tad(bb)
        if aa==0 or bb==0:return s.S.Zero # auxiliary-mass POWER-tadpole limit, verified separately
        return s.gamma(dd/2-cc)*s.gamma(aa+cc-dd/2)*s.gamma(bb+cc-dd/2)*s.gamma(aa+bb+cc-dd)/(s.gamma(aa)*s.gamma(bb)*s.gamma(dd/2)*s.gamma(aa+bb+2*cc-dd))
    def kernel(var='base'):
        factor=s.S.One if var=='angular_D4' else 4/dd
        def NN(nn):return 2*I(nn-1,1,1)-4*I(nn,1,1)-(0 if var=='no_tadpole_products' else I(nn,1,0))
        value=2*(factor-1)*NN(3)-2*factor*NN(4)
        if var!='no_vertex':value+=factor*((0 if var=='no_tadpole_products' else I(2,2,0))-2*I(1,2,1)+2*I(2,2,1))
        return gamma_ratio(value)
    print('STAGE neutral_Fourier_numerator_reduction',flush=True)
    ratio=kernel();unit=laurent(ratio);mutants={name:list(map(cf,laurent(kernel(name)))) for name in ['angular_D4','no_vertex','no_tadpole_products']}
    rho,E,U,S,Pr,Ty,Rh,H,O,G=setup(role);R=[tidy(U.T*A*U) for A in rho]
    PH=tidy(U.T*H*U/s.Rational(426075291,62500000));MG=tidy(U.T*O*O.T*U);h=tidy(U.T*Rh*U);Qs=-h*h
    C=s.SparseMatrix(4,4,{});Bx=C.copy();Bg=C.copy();parent=C.copy();K=[A*U for A in rho]
    for (aa,bb),zz in Pr[0].todok().items():
        C+=zz*R[aa].T*R[bb];Bx+=zz*R[aa].T*PH*R[bb];Bg+=zz*R[aa].T*MG*R[bb];parent+=zz*K[aa].T*K[bb]
    convert=lambda M:tidy(S.H*M*S)
    C,Bx,Bg,parent=map(convert,[C,Bx,Bg,parent]);PH,MG,Qs=map(convert,[PH,MG,Qs]);zero(C-Qs);zero(parent-C)
    weights={'physical':0,'Goldstone':0};routes=[];qs=list(tidy(E.H*Rh*E).diagonal())
    for ii in range(4):
        for jj in range(4):
            # Real two-scalar metric, not the Hermitian current pairing.
            V=s.SparseMatrix(45,1,{(aa,0):(E[:,ii].T*rho[aa]*E[:,jj])[0] for aa in range(45)})
            ww=red((V.T*Pr[0]*V.conjugate())[0])
            if ww==0:continue
            qvector=red(s.I*(qs[ii]+qs[jj]));assert qvector==0;zero(Ty*Pr[0]*V)
            routes.append([0,ii,jj,str(ww),str(qvector)])
            group='physical' if PH[ii,ii]==1 else 'Goldstone';weights[group]+=s.Rational(3,2)*ww*Qs[ii,ii]
    weights={k:red(v) for k,v in weights.items()}
    # Independent closure as kinetic response plus mass response.
    cp=0;cf0=0
    for ii in range(4):
        mass=s.Rational(3,2)*r*PH[ii,ii]+MG[ii,ii]
        kinetic=-Qs[ii,ii]*C[ii,ii];massjet=-Qs[ii,ii]*(s.Rational(3,2)*r*Bx[ii,ii]+Bg[ii,ii])/(2*mass)
        jj=j-s.log(r) if PH[ii,ii]==1 else j+s.log(5)
        cp+=kinetic+massjet;cf0+=(kinetic+massjet)*jj
    Qv=-Ty*Ty;scu=packed(CAL/'canonical_so10_scalar_current_forests'/f'{role}_tables.json.gz')['operators']
    for name in ['vector_tau','vector_loop_mass_x','vector_loop_mass_g2']:zero(Qv*Pr[0]*dec(scu[name]))
    save(role,{'schema':'SLI1','unit_gamma_ratio':cf(ratio),'unit_bare_Laurent':list(map(cf,unit)),
      'Fourier_mutant_unit_Laurent':mutants,'light_routes':routes,'weighted_unit_multipliers':{k:str(v) for k,v in weights.items()},
      'operators':{k:enc(v) for k,v in [('C0',C),('Bx0',Bx),('Bg0',Bg),('parent_C0',parent)]},
      'vector_CT_F2_zero_by_actual_neutral_support':True,
      'assembly':assemble(role,unit,weights,clean(cp),clean(cf0))},start)
if __name__=='__main__':main()
