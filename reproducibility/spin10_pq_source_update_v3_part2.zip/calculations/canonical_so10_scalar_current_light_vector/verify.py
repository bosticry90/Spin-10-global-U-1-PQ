"""SLI1 separate infrared, exact gamma, vertex, forest and mass-limit checks."""
from data import *

def main():
    start=begin('validation_preparation.json',360);mp.mp.dps=80
    A,B=[packed(HERE/(role+'_tables.json.gz')) for role in ['primary','replay']]
    for key in ['unit_gamma_ratio','unit_bare_Laurent','light_routes','weighted_unit_multipliers','operators','assembly']:
        assert A[key]==B[key],key
    unit=list(map(expr,A['unit_bare_Laurent']));assert unit[0]==0 and unit[1]==-1
    print('STAGE uniform_soft_bound_and_UV_IR_separation',flush=True)
    pv=s.symbols('p0:4',real=True);qv4=s.symbols('q0:4',real=True);xx=s.Symbol('x',positive=True)
    pp=sum(z*z for z in pv);qq=sum(z*z for z in qv4);P=pp+xx;R=sum((p-q)**2 for p,q in zip(pv,qv4))+xx
    assert clean(R-P/2-sum((p-2*q)**2 for p,q in zip(pv,qv4))/2-xx/2+qq)==0
    assert clean(8*P-sum((2*p-q)**2 for p,q in zip(pv,qv4))-4*sum((p+q/2)**2 for p,q in zip(pv,qv4))-8*xx+2*qq)==0
    # Cauchy + q²<=x/4 gives the stated R>=P/2 and |p.k|<=3P/2.
    bound=32+128+12;assert bound==172
    rr=s.Symbol('radius',positive=True);delta=s.Symbol('delta',positive=True)
    soft=s.integrate(rr,(rr,0,delta))/(8*s.pi**2);hard=s.integrate(rr**3/(rr**2+xx)**3,(rr,0,s.oo))/(8*s.pi**2)
    assert s.simplify(soft-delta**2/(16*s.pi**2))==0 and s.simplify(hard-1/(32*s.pi**2*xx))==0
    mu=s.Symbol('mu',positive=True)
    powerjets=[-mu,mu*(s.log(mu)-1),mu*(-1-s.zeta(2)/2+s.log(mu)-s.log(mu)**2/2)]
    assert all(s.limit(v,mu,0,dir='+')==0 for v in powerjets)
    assert s.limit(-s.log(mu),mu,0,dir='+')==s.oo # logarithmic tadpole is not the same limit
    # Retain all heat monomials and their proper-time IR gamma factors.
    pk=packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz')
    U=st*tt+st*ut+tt*ut;P2=expr(pk['P2']).subs({q1:-1,q2:1,qv:0})
    N=clean(P2*U**2);terms=s.Poly(N,st,tt,ut).terms();assert len(terms)==len(A['heat_terms'])
    assert max(ijk[2] for ijk,c in terms)<3
    assert clean(s.limit(P2,ut,s.oo)-expr(A['P2_large_u_limit']))==0
    for row in A['heat_terms']:assert s.Rational(row['IR_gamma_argument_at_D4'])>0
    # Numerical gamma evaluation is independent of the workers' recurrence reducer.
    ratio=expr(A['unit_gamma_ratio']);gamma_error=mp.mpf(0)
    for ee in [mp.mpf(1)/8,mp.mpf(1)/4]:
        dd=4-2*ee;beta=dd/2+2;heat=mp.mpf(0)
        for (ii,jj,kk),co in terms:
            co0=mp.mpf(str(s.N(co.subs(D,s.Float(str(dd),85)),85)))
            heat+=co0*mp.gamma(kk+1)*mp.gamma(beta-kk-1)*mp.gamma(ii+kk+2-beta)*mp.gamma(jj+kk+2-beta)*mp.gamma(ii+jj+kk+3-2*beta)/(mp.gamma(beta)*mp.gamma(ii+jj+2*kk+4-2*beta))
        exact=mp.mpf(str(s.N(ratio.subs(eps,s.Float(str(ee),85)),85)))*mp.gamma(ee)**2
        err=abs(heat-exact)/(1+abs(exact));gamma_error=max(gamma_error,err);assert err<mp.mpf('1e-60')
    print('STAGE actual_current_and_complete_route_partition',flush=True)
    rho,E,_,_,Pr,Ty,Rh,H,O,G=setup('primary');h=tidy(E.H*Rh*E);Qs=-h*h;Qv=-Ty*Ty
    J=tidy(E.T*E);T=[s.SparseMatrix(4,4,{}) for _ in range(45)]
    for ii,jj,col in pk['vertices']:
        col=dec(col)
        for aa in range(45):T[aa][ii,jj]=col[aa,0]
    T=[tidy(J.H*M) for M in T]
    C=s.SparseMatrix(4,4,{})
    for (aa,bb),zz in Pr[0].todok().items():C-=zz*T[aa]*T[bb]
    C=tidy(C);zero(C-Qs);zero(C-dec(A['operators']['C0']))
    PH=tidy(E.H*H*E/s.Rational(426075291,62500000));MG=tidy(E.H*O*O.T*E)
    zero(dec(A['operators']['Bx0'])-C*PH);zero(dec(A['operators']['Bg0'])-C*MG);zero(Pr[0]*G)
    for role in ['primary','replay']:
        old=packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz')
        allroutes={(v[0],v[1],v[2]) for v in old['weights'] if s.sympify(v[3])!=0}
        light={(v[0],v[1],v[2]) for v in A['light_routes']};positive={q for q in allroutes if q[0]>0}
        assert len(light)==4 and len(positive)==8 and not light&positive and light|positive==allroutes
        scu=packed(CAL/'canonical_so10_scalar_current_forests'/f'{role}_tables.json.gz')['operators']
        for key in ['vector_tau','vector_loop_mass_x','vector_loop_mass_g2']:zero(Qv*Pr[0]*dec(scu[key]))
    weights={k:expr(v) for k,v in A['weighted_unit_multipliers'].items()};assembly=A['assembly']
    cp,cf0=scalar_closure(C,C*PH,C*MG,PH,MG,Qs)
    assert clean(cp-expr(assembly['light_CT'][0]))==0 and clean(cf0-expr(assembly['light_CT'][1]))==0
    bare=list(map(expr,assembly['light_bare']));light=list(map(expr,assembly['light_Rprime']))
    assert clean(light[1]-bare[1]-cp)==0 and clean(light[2]-bare[2]-cf0)==0
    assert s.diff(light[1],r)==0 and bare[1]!=0 and light[1]!=0
    # The actual complete route partition above establishes multiplicity one.
    # A duplicated measured light input would change the pole, not be invisible.
    assert clean(2*light[1]-light[1])!=0
    print('STAGE independent_positive_mass_neutral_master_limit',flush=True)
    # Import the frozen SCL absolute neutral master in its OWN data namespace.
    # Its completed controllers are not run; only three new positive-mass points are evaluated.
    scldata=load('sli_scl_data',CAL/'canonical_so10_scalar_current_laurent/data.py');saved=sys.modules['data']
    try:
        sys.modules['data']=scldata
        master=load('sli_absolute_neutral',CAL/'canonical_so10_scalar_current_laurent/master_reference_v3.py')
    finally:sys.modules['data']=saved
    histories=[];previous=None
    for zz in [mp.mpf('1e-4'),mp.mpf('1e-10'),mp.mpf('1e-16')]:
        result=master.evaluate([mp.mpf(1),mp.mpf(1),zz]);assert abs(result[0])<mp.mpf('1e-60')
        assert abs(result[1]-(-1+zz/3))<mp.mpf('1e-60')
        err=abs(result[2]-mp.mpf(str(s.N(unit[2],85))))
        if previous is not None:assert err<previous
        previous=err;histories.append({'vector_mass_squared_over_scalar_mass_squared':mp.nstr(zz,20),
          'bare_unit_Laurent':list(map(lambda v:mp.nstr(v,35),result)),'finite_distance_from_exact_massless_result':mp.nstr(err,30)})
    assert previous<mp.mpf('1e-11')
    controls={}
    for name,row in B['Fourier_mutant_unit_Laurent'].items():
        diffs=[clean(expr(x)-y) for x,y in zip(row,unit)];assert any(x!=0 for x in diffs);controls[name]=list(map(cf,diffs))
    # Gamma-zeta2 contribution to the finite part is multiplied by the zero double pole.
    gamma_zeta_insensitive=(unit[0]==0)
    # Combined numerical diagnostics use UNROUNDED heavy20-digit inputs.
    for role in ['primary','replay']:
        old=packed(CAL/'canonical_so10_scalar_current_forests'/f'{role}_tables.json.gz')['trace']
        nums=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_numeric_v2_tables.json.gz')['weighted_total_P2_P1_F0_base_jN0']
        for rr0 in [1,2]:
            vals=list(map(mp.mpf,nums[str(rr0)]));env={r:rr0,j:0};mnum=lambda z:mp.mpf(str(s.N(z.subs(env),85)))
            expected={'full_Rprime_pole':vals[1]+mnum(expr(old['forest_pole'])+light[1]),
              'full_Rprime_finite_at_jN0':vals[2]+mnum(expr(old['forest_finite'])+light[2]),
              'full_Rprime_jN_coefficient':2*vals[1]+mnum(s.diff(expr(old['forest_finite'])+light[2],j))}
            for key,value in expected.items():assert assembly['combined_four_scalar_diagnostics'][str(rr0)][key]==mp.nstr(value,18)
    value={'schema':'SLI1_VALIDATION','execution_state':'COMPLETED',
      'status':'QUALIFIED_LIGHT_VECTOR_LAURENT_IR_DOMAIN_AND_FOUR_SCALAR_RPRIME_COVERAGE',
      'elapsed_after_imports':time.perf_counter()-start,'unit_bare_Laurent':A['unit_bare_Laurent'],
      'light_routes':4,'positive_heavy_routes_reused':8,'total_four_scalar_nonzero_routes':12,'all_route_positions':80,
      'soft_bound_coefficient':172,'soft_integrated_bound':str(bound*soft*hard),
      'gamma_identity_scaled_error':mp.nstr(gamma_error,25),'positive_mass_limit_history':histories,
      'weights':A['weighted_unit_multipliers'],'assembly':assembly,'mutant_Laurent_changes':controls,
      'Gamma_zeta2_finite_control_INSENSITIVE':gamma_zeta_insensitive,
      'no_uniform_g0_or_massless_scalar_claim':True,'overall_counterterm_adopted':False,
      'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(value,sort_keys=True),flush=True)
if __name__=='__main__':main()
