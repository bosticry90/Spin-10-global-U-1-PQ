"""SLI1 capture completed routes, compare, then run a separate verifier."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-current-light-vector-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def auth(v):
    for n,h in v['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
def one(role):
    c=capture([sys.executable,'-B',str(HERE/(role+'.py'))]);name='validation' if role=='verify' else role
    dump(HERE/(name+'_capture.json'),c);dump(CONTROL/(name+'_full_capture.json'),c)
    if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
    assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
    assert c['launch']['memory']['available_pagefile']>=350*1024**2
    assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
    rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
    v=rows[0];assert v['elapsed_after_imports']<(360 if role=='verify' else 300)
    dump(HERE/('validation_receipt.json' if role=='verify' else role+'_result.json'),v)
    print(name,'COMPLETED',v['elapsed_after_imports'],flush=True)
prep=json.loads((HERE/'preparation.json').read_bytes());auth(prep)
one('primary');one('replay')
ts=[json.loads(gzip.decompress((HERE/(role+'_tables.json.gz')).read_bytes())) for role in ['primary','replay']]
for key in ['unit_gamma_ratio','unit_bare_Laurent','light_routes','weighted_unit_multipliers','operators','assembly']:assert ts[0][key]==ts[1][key],key
print('COMPLETED_HEAT_AND_FOURIER_LIGHT_VECTOR_OUTPUTS_AGREE',flush=True)
names=list(map(Path,prep['input_sha256']))+[HERE/'preparation.json']
for role in ['primary','replay']:names += [HERE/(role+suffix) for suffix in ['_capture.json','_result.json','_tables.json.gz']]
vp={'schema':'SLI1_VALIDATION_PREPARATION','input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
dump(HERE/'validation_preparation.json',vp);auth(vp);one('verify')
