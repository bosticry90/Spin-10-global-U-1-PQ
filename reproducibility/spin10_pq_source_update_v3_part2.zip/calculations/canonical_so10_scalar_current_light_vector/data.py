"""SLI1 fixed inputs, exact gamma recurrence, assembly and bounded IO."""
from pathlib import Path
from hashlib import sha256
import gzip,json,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,enc,dec
eps=s.Symbol('eps',positive=True);r=s.Symbol('r',positive=True);j=s.Symbol('jN',real=True)
st,tt,ut,D,q1,q2,qv=s.symbols('s t u D q1 q2 qv',positive=True)
LOC={str(z):z for z in [eps,r,j,st,tt,ut,D,q1,q2,qv]}
def clean(z):return s.cancel(s.expand(z))
def cf(z):return str(clean(z))
def expr(z):return s.sympify(z,locals=LOC)
def read(p):return json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def begin(prep='preparation.json',seconds=300):
    start=time.perf_counter();timer=threading.Timer(seconds,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in read(HERE/prep)['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return start
def setup(role):return load('scu_inputs',CAL/'canonical_so10_scalar_current_forests/data.py').setup(role)
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'schema':'SLI1_NATIVE','role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def gamma_ratio(value):
    """Reduce by Gamma(z+1)=z Gamma(z), retaining eps,1-eps,2eps bases."""
    bases={1:s.Symbol('GE'),-1:s.Symbol('GM'),2:s.Symbol('G2')};mapping={}
    for atom in value.atoms(s.gamma):
        arg=s.expand(atom.args[0]);nn=arg.subs(eps,0);cc=s.diff(arg,eps)
        assert nn.is_Integer and cc in bases and clean(arg-nn-cc*eps)==0,(arg,nn,cc)
        base=1 if cc==-1 else 0;value0=bases[cc];step=cc*eps
        if nn>=base:value0*=s.prod(step+k for k in range(base,int(nn)))
        else:value0/=s.prod(step+k for k in range(int(nn),base))
        mapping[atom]=value0
    out=clean(value.xreplace(mapping)/bases[1]**2)
    assert not out.has(*bases.values(),s.gamma),out
    return out
def laurent(ratio):
    normalized=s.exp(2*s.EulerGamma*eps)*s.gamma(1+eps)**2
    value=s.series(normalized*ratio/eps**2,eps,0,1).removeO().expand()
    return [clean(value.coeff(eps,k)) for k in [-2,-1,0]]
def scalar_closure(C,Bx,Bg,PH,MG,Qs):
    pole=0;finite=0
    for ii in range(4):
        mass=s.Rational(3,2)*r*PH[ii,ii]+MG[ii,ii]
        effective=-s.Rational(3,2)*r*Bx[ii,ii]-Bg[ii,ii]-2*C[ii,ii]*mass
        pref=clean(Qs[ii,ii]*effective/(2*mass));jj=j-s.log(r) if PH[ii,ii]==1 else j+s.log(5)
        pole+=pref;finite+=pref*jj
    return clean(pole),clean(finite)
def assemble(role,unit,weights,ctpole,ctfinite):
    bare=[0,0,0]
    for name,jj in [('physical',j-s.log(r)),('Goldstone',j+s.log(5))]:
        w=weights[name];pieces=[unit[0],unit[1]+2*jj*unit[0],unit[2]+2*jj*unit[1]+2*jj**2*unit[0]]
        bare=[clean(x+w*y) for x,y in zip(bare,pieces)]
    light=[bare[0],clean(bare[1]+ctpole),clean(bare[2]+ctfinite)]
    old=packed(CAL/'canonical_so10_scalar_current_forests'/f'{role}_tables.json.gz')['trace']
    numbers=packed(CAL/'canonical_so10_scalar_current_laurent'/f'{role}_numeric_v2_tables.json.gz')['weighted_total_P2_P1_F0_base_jN0']
    diagnostics={};mp.mp.dps=80
    for rr in [1,2]:
        raw=list(map(mp.mpf,numbers[str(rr)]));env={r:rr,j:0}
        to_mp=lambda z:mp.mpf(str(s.N(z.subs(env),85)))
        fullpole=raw[1]+to_mp(expr(old['forest_pole'])+light[1]);fullfinite=raw[2]+to_mp(expr(old['forest_finite'])+light[2])
        fullj=2*raw[1]+to_mp(s.diff(expr(old['forest_finite'])+light[2],j))
        diagnostics[str(rr)]={'full_Rprime_pole':mp.nstr(fullpole,18),'full_Rprime_finite_at_jN0':mp.nstr(fullfinite,18),'full_Rprime_jN_coefficient':mp.nstr(fullj,18)}
    return {'light_bare':list(map(cf,bare)),'light_CT':[cf(ctpole),cf(ctfinite)],'light_Rprime':list(map(cf,light)),
      'combined_four_scalar_diagnostics':diagnostics,'overall_counterterm_adopted':False,'full_328_scalar_VSS_or_C1_qualified':False}
