# SLI1: the light-vector routes are nonzero and complete the four-scalar restriction

Two distinct calculations and a separate verifier qualify the four nonzero
light-vector contributions to the existing U1 scalar-current sunset. Together
with the authenticated eight positive-heavy routes, the bare and proper-subgraph
coefficients now cover all12 nonzero routes in the declared80-position
FOUR-real-scalar inventory. This is not the full328-real-scalar VSS family,
the complete finite C1_GS threshold or E5/A5 restoration.

The final validation_receipt.json SHA256 is
`a80cd5b0db1619bc08151b9b94dc0efee51ccfbe1b20899f374e269bce164795`.
The action, reference point, physical normalization and state113/34of39 are
unchanged. No overall or finite counterterm or physical benchmark is adopted.

## The massless vector has a justified infrared limit

Each new route contains two equal positive scalar masses and one neutral,
massless quantum vector. Its propagator1/q² is not a zero contribution.
For scalar squared mass x>0 and |q|<=sqrt(x)/2, the literal Fourier F²
integrand is bounded by172/[q²(p²+x)³], including the region p->infinity
while q becomes soft. With the original momentum measure, its integrated
soft ball is at most43delta²/(128pi4 x), and vanishes as delta->0.
The bound is uniform when1/q² is replaced by1/(q²+mu), mu>=0.

The independent proper-time calculation has a finite P2 limit as the vector
time grows and decays as u^-D/2. Its actual integration gamma factors have
no infrared pole at D4. Both arguments retain the separate dimensional UV
continuation. There is no claim of an ordinary common convergence strip
for all unrenormalized terms, nor a uniform massless-scalar/g->0 limit.

The remaining scalar counterterm closures are massive. The massless vector
closure has zero U1 F² coefficient because the measured current lies in
the neutral light-vector direction. All three actual tests
Qv²P0tau=Qv²P0Mx=Qv²P0Mg=0 pass. This is not an application of the earlier
positive-heavy heat-boundary theorem at mass zero or a universal Tr1 zero.

## Exact bare coefficient and proper-subgraph subtraction

The two scalar columns on each route are a conjugate pair in the real-field
metric. The physical and gauge-orbit raw weight sums are24/5 and6/5.
After the actual Wick/matching and external-charge factors, their unit-kernel
multipliers are432/25 and27/25. The gauge-orbit scalar squared mass is
(3/10)g²; it is positive for the retained fixed g>0 domain.

For unit opposite scalar charges and Q²=x, both calculations yield

```
double pole = 0,   simple pole = -1,   finite coefficient = 4/3.
```

They agree as an exact meromorphic gamma identity, not just at one numerical
mass. Before expansion the unit result is exp(2gammaEeps)Gamma(eps)² times

```
-eps(2eps²-5eps+6)/[3(2-eps)(1-eps)(1+2eps)],
```

with the common(Q²/x)^(2eps) factor restored for a general scale. The result
therefore retains the finite term-2log(Q²/x). Scalar/vector dimensional
factors, background endpoint vertices and factorized tadpoles are kept.

Use the existing r=mH²/[(3/2)g²]>0 and jN=log(Q²/[(3/2)g²]). In the
original Lambda2/g² units, the actual new light bare contribution is

```
-459/(25eps) -918jN/25 +864log(r)/25 -54log(5)/25 +612/25.
```

Its actual proper-subgraph counterterms contribute

```
-459/(25eps) -459jN/25 +432log(r)/25 -27log(5)/25.
```

These coefficients come from the action-derived light scalar operators,
not from requiring a zero total. C0=-sum P0_ab TaTb has diagonal
(12/5,3/5,3/5,12/5); Bx0 and Bg0 each have two nonzero entries. The
real and complex routes give the same full4-by-4 operators and zeros.
Here the parent LIGHT seagull equals the projected current contraction.
This does not remove SCU1's nonzero parent-minus-current HEAVY difference.

The light result after proper-subgraph subtraction, R-prime, is

```
-918/(25eps) -1377jN/25 +1296log(r)/25 -81log(5)/25 +612/25.
```

The surviving overall pole is intentional. It is not a symmetry anomaly or
a parameter fitted to force cancellation. No overall local subtraction has
been adopted here. A complete parent assembly must retain the earlier
VVSS coordination R_VVSS+(C_parent-C_VVSS), the other primitives and the
common UV/EFT matching conditions.

## Exact-once completion of the selected restriction

The verifier partitions all80 frozen route positions into four nonzero light
routes, eight nonzero positive-heavy routes and68 zeros, with no overlap or
unassigned nonzero entry. It uses the actual real-bilinear vertices before
transport to Hermitian charge coordinates. Independently recomputed weights
and complete operators agree. A duplicated light contribution changes the
subtotal; its nonzero pole makes that error detectable.

Combining the new analytic coefficients once with SCL1's measured bare and
SCU1's proper-subgraph coefficients gives the following partial R-prime
diagnostics, displayed to18 significant digits from the inherited20-digit
heavy inputs:

| r | Remaining overall pole | Finite constant at jN=0 | Finite coefficient of jN |
|---|---:|---:|---:|
|1| -60.6 | -92.14359918396592 | -154.8 |
|2| -60.6 | -58.0961513252088289 | -212.4 |

The heavy pole anchor remains an authenticated numerical input, not a newly
rationalized exact constant. r1/r2 are mathematical diagnostics, not adopted
couplings or physical benchmark points. The old source functional and earlier
finite-family subtotals are unchanged; no new one-loop source integration
was performed.

## Validation, controls and limits

Primary integrates the authenticated ordered heat polynomial over its massless
proper time and two equal massive times. Replay reduces the neutral Fourier
numerator to massive/massless general-D masters and factorized tadpoles.
The separate verifier checks the infrared sum-of-squares inequalities,
radial integrals, gamma normalization, actual current support, neutral vector
closure and the complete route partition. Direct numerical gamma evaluation
at two noninteger dimensions differs from the exact reduced expression by
at most4.662999537812256779896731e-81 at80-digit working precision. This
is finite-precision corroboration, not a rigorous numerical error interval.

The existing absolute neutral master formula was evaluated at three NEW
positive vector/scalar squared-mass ratios. Their finite distances from the
analytic zero-mass4/3 result are:

| ratio | finite distance |
|---|---:|
|1e-4| 0.00137807671484953188758 |
|1e-10| 3.22011345739817179815e-9 |
|1e-16| 5.06218153172063090680e-15 |

The last meets the predeclared1e-11 limit control; the simple poles reproduce
-1+ratio/3 within1e-60. This finite sequence is not the proof of convergence;
the explicit bound and analytic integration supply the infrared justification.
No massless call was made to SCL1's positive-M0 sector algorithm or its
exclusive completed controllers.

The auxiliary-mass power-tadpole Laurent jets, including their epsilon term,
all vanish as mu->0. A logarithmic tadpole instead leaves-log(mu). The latter
control prevents interpreting every scaleless integral as an unqualified
UV/IR zero. Changes in unit(double pole,simple pole,finite) under the other
controls are:

* Premature angular D4: (0,-1,+1).
* Omit the background vertex: (0,+1,-1/2).
* Omit factorized tadpole products: (-1,-1/6,1/12-pi²/6).

The Gamma-zeta2 finite control is INSENSITIVE because the actual double pole
is zero. It is not used to validate the whole dimensional numerator.
Both routes share the physical action/reference, frame/projectors, inherited
heat and master inputs, gamma recurrence utility, software and AI authorship.
Agreement does not independently validate those premises or the physical model.
No outside scientist, Lean theorem or empirical confirmation is claimed.

## Execution and next action

Sources and2540 input bindings were frozen before science. Commands were
`python -B calculations/canonical_so10_scalar_current_light_vector/prepare.py`
and then `run.py`. These exclusive historical controllers must not be rerun
over existing outputs. Primary/replay/verifier completed in22.6872505 /
23.2367526 /25.2163911 seconds, below300/300/360-second caps. No scientific
worker, verifier or preparation failed. Sampled private allocations were at
most70,107,136 /68,947,968 /70,529,024 bytes across12/13/14 samples, not
continuous peak measurements. The8GiB cap,350MiB launch floor and4MiB new
package limit were respected.

Delegated e4 completed its six expected exits. It authenticates existing
evidence and authority/structure/read-only/custody conditions, not fresh
scientific acceptance. Historical custody remains exit2/seven, never PASS.

The next useful step should reduce the remaining FULL scalar-current domain,
using the actual35 SM classes and spectral/multiplicity matrices, rather
than extend another convenient four-field example. Test whether H covariance
reduces the three quadratic charge weights of the general kernel to actual
scalar/vector Casimir insertions, with full-index sum rules against VSP.
This proposed reduction is not yet calculated or qualified. Preserve mixing,
the five soft scalar directions, light vectors and common matching terms.
All other primitive, overall subtraction, finite-normalization and physical
viability requirements remain; authority stays34/39 and the full goal active.
