# SLI1 prospective light-vector completion of the four-scalar sunset

Base91fc797bf001ff6273b135223e5e97b90637a6e9/main, state113/34of39 unchanged.
Question: do the four actual nonzero light-vector VSS routes have a justified
infrared domain, and what are their bare Laurent and proper-subgraph finite
coefficients? Combine them exactly once with the completed positive-heavy
restriction, without claiming the full scalar-current threshold.

Same action, original C1 dimensional prescription, fixed reference point,
xi1 background gauge, real328 scalar/45 vector metrics. Retain g>0,
r=mH²/[(3/2)g²]>0, jN=log(Q²/[(3/2)g²]) symbolically. Scalar columns are
SM0,1,3,4, charges(-2,-1,1,2)sqrt(3/5). Both scalar masses on each light
route are equal and positive. Quantum-vector mass is exactly zero and its
actual U1 charge is zero; this is NOT a zero amplitude.

Before science freeze all sources, immutable inputs, mathematical assumptions,
caps, expected evidence and failure conditions. Reuse SCP1 vertices, SCL1 bare
heavy result and SCU1 proper-subgraph operators. No repeated heavy numerics.
Native primary integrates the actual heat P2 polynomial over the massless
proper time then the two massive times. Native replay independently reduces
the neutral Fourier numerator to general-D massive/massless vacuum integrals
and factorized tadpoles. They derive their actual weights/current operators
through different contractions and compare completed full outputs first.

IR proof: isolate the actual massless momentum q=p+k; positive scalar masses
control p,k infrared regions. Supply a uniform integrable bound also as p
becomes large with q small. Inspect the proper-time large-u endpoint and
gamma factors separately from UV continuation. Show scalar CT closures remain
massive and the massless vector CT closure has zero U1 F² because the actual
current support is neutral, not by transferring WHP's positive-mass theorem.
Retain the auxiliary-mass limit of scaleless POWER tadpoles explicitly.
No global common-D convergence strip or universal scaleless UV/IR zero claim.

Compute the undifferentiated bare double/simple poles and finite coefficient
with N_e=exp(2gammaEeps)(Q²)^(2eps), all real Wick weights and Fphys²=2B².
Close the overlapping proper subgraphs with remaining-loop H_eps, keeping
evanescent coefficients. Do not infer a coefficient from desired locality.
Sum light and positive-heavy routes once; retain parent-minus-current quartic
differences and the overall pole. No overall/finite CT, scheme, coupling,
tadpole normalization or physical benchmark is adopted.

Separate verifier: reconstruct selected vertices/support, all light operators
including zeros, beta/gamma identities, dimensional series and IR bound.
Use the existing absolute neutral master formula at three NEW positive vector
masses(1e-4,1e-10,1e-16) as a limit control at80digits. Last finite difference
from the analytic zero-mass result must be<1e-11, errors must decrease;
simple poles compare to the exact positive-mass formula at1e-60. This is a
limit diagnostic, not a rigorous finite-mass remainder bound. No M0=0 call
to SCL1's positive-M0 sector algorithm. Numeric diagnostic coefficients inherit
20-digit heavy inputs; display18digits with exact display-rounding checks.

Controls: premature D4 angular numerator, omitted vertex, omitted tadpole
products, omitted/duplicated light amplitude, stronger1/q4 IR singularity,
and scalar-vs-vector CT support. State insensitive Gamma-zeta controls when
bare double pole is zero. Shared action/frame/heat/master/software/AI inputs
remain explicit; no outside scientist or Lean certificate is claimed.

Caps: each native300s and verifier360s after imports;8GiB sampled private
allocation,350MiB launch floor,new package<=4MiB. Exclusively captured outputs,
preserve all failed/unfinished runs. Success requires complete actual route
coverage in the FOUR-scalar restriction and consistent IR/UV/finite derivations;
otherwise retain a mismatch or underdefinition, never fit a cancellation.
Delegate e4 and byte seals before local commit, with custody exit2/seven NOTPASS.
Full324-other-scalar coverage, full gauge factors/primitives, UV/EFT matching,
E5/A5, HB1/C5, human-paused flavor and finiteC1 acceptance remain separate.
