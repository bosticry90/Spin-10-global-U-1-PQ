# SLI1: neutral massless-vector sunset with two equal positive scalar masses

Use SCP1's actual neutral Fourier integrand. Write q=p+k, P=p²+x,
R=k²+x, x>0, D=4-2eps. Divided by its scalar charge squared, the coefficient is

```
(p-k)² [(-1/P³+4p²/(D P4))/R + (-1/R³+4k²/(D R4))/P]/q²
 + 8 p.k/(D P²R²q²).
```

## Infrared domain before evaluating a Laurent series

Only q=0 can be singular; the scalar denominators are positive. For
|q|<=sqrt(x)/2 one has R>=P/2, (2p-q)²<=8P and |p.k|<=3P/2.
The first inequality follows from
R-P/2=|p-2q|²/2+x/2-q². At D4 the two scalar heat terms are bounded by
32/P³ and128/P³ and the vertex term by12/P³. Thus the FULL integrand obeys

```
|f(p,q)| <= 172/[q²(p²+x)³].
```

This controls even the joint soft-q/hard-p region. With d4p/(2pi)4 measure,
integral_p(P^-3)=1/(32pi²x) and integral_|q|<delta(q^-2)=delta²/(16pi²).
The small ball therefore vanishes as delta², uniformly under replacement
q^-2 ->(q²+mu)^-1, mu>=0. Fixed x>0 is essential; no uniform g->0 or
massless-scalar conclusion follows. The same radial estimates admit an IR
neighborhood of D4. The other hard regions require the ORIGINAL dimensional
UV continuation and the proper subgraphs, not this infrared estimate alone.

The scalar UV subgraphs have positive internal scalar mass and a simple
massless vector propagator, also IR integrable. Their remaining closures are
massive. The vector UV subgraph's remaining massless current support is
neutral under the chosen U1: verify Qv² P0 tau=Qv² P0 Mx=Qv² P0 Mg=0 and
Ty P0 C_ij=0 for actual nonzero vertices. Its F² trace is zero by neutrality,
not by WHP's positive-mass boundary proof or universal vanishing of Tr1.
Other off-diagonal operators remain in SCU1 and are not declared zero.

## Heat calculation

Take the authenticated SCP1 polynomial P2(s,t,u,D), charges(-1,1,0).
The massless-vector proper-time integrand is exp[-x(s+t)] U^-D/2 P2,
U=st+u(s+t). Write P2=N/U² with N polynomial. Each term
c_ijk s^i t^j u^k/U^beta has beta=D/2+2. The integral over u and then
s,t is the meromorphic continuation of

```
c_ijk x^(2beta-i-j-k-3)
 Gamma(k+1) Gamma(beta-k-1) Gamma(i+k+2-beta)
 Gamma(j+k+2-beta) Gamma(i+j+k+3-2beta)
 /[Gamma(beta) Gamma(i+j+2k+4-2beta)].
```

The u integral converges at infinity for Re(beta)>k+1 and at zero for k>-1.
Verify the actual maximal k and beta-k-1 at D4: none supplies an IR pole.
P2 has a finite u->infinity limit and the original integrand decays as
u^-D/2. The s,t beta singularities encode UV subgraphs and are continued
meromorphically. This does not assert an ordinary common convergence strip
for every unrenormalized term. The uniform momentum estimate justifies the
IR limit separately, including the hard-p region.

## Independent Fourier reduction

Let I(a,b,c) be the two-loop scalar integral with powers of P,R,q² and
remove the common(4pi)^-D. For a,b,c>0 and equal scalar squared masses x,

```
I(a,b,c)=x^(D-a-b-c) Gamma(D/2-c) Gamma(a+c-D/2)
 Gamma(b+c-D/2) Gamma(a+b+c-D)
 /[Gamma(a)Gamma(b)Gamma(D/2)Gamma(a+b+2c-D)].
```

This follows by first integrating the massless Schwinger time, then using
R=s+t and alpha=s/(s+t). For c=0 use the product of one-loop tadpoles.
An absent scalar denominator and c=1 gives a massive integral times a
scaleless POWER tadpole. Regulate its squared mass by mu>0 first: its
Laurent jets are-mu,mu(logmu-1),mu[-1-zeta2/2+logmu-log²mu/2]. All tend
to zero. A massless logarithmic tadpole instead has logmu and cannot be
discarded this way. No arbitrary finite contact is fixed by this limit.

For N_n=2I(n-1,1,1)-4xI(n,1,1)-I(n,1,0), the neutral kernel is

```
2(-1+4/D)N_3 - 8x N_4/D
 + (4/D)[I(2,2,0)-2I(1,2,1)+2xI(2,2,1)].
```

This keeps the background endpoint-vertex contribution and factorized terms.
The closed D pole cannot replace4/D before multiplying divergent masters.
Compare the result to the heat route as an exact meromorphic gamma identity,
then expand using the frozen exp(2gammaEeps)(Q²)^(2eps) measure. No massless
call to the old positive-M0 sector routine is made.

## Model weights, forest and exact-once assembly

Recover all four actual nonzero light routes and their zero complement from
the real action metric, charge columns and P0. Define the positive current
operator C0=-sum P0_ab T_aT_b and Bx0,Bg0 as in SCU1 with Pplus->P0 and
P0 G P0=0. Keep the distinction from the full parent quartic operator.
The scalar CT effective mass is -mH²Bx0-g²Bg0-2C0X, so the F² closure is
Tr[Qs² effective X^-1 H_eps(X)]/(2eps), not the two-loop bare measure.
The actual vector CT trace is zero by neutral support as above.

Weight the unit neutral result by(3/2)W_ij qi² and its two-loop scale
factor exp(2eps*j_scalar), with j_phys=jN-logr and j_Gold=jN+log5.
The remaining scalar CT uses H_eps=exp(gammaEeps)Gamma(1+eps)exp(eps*j_scalar).
Use the independently derived values, never coefficients inferred from the
desired total pole. Sum with the authenticated SCL1 bare and SCU1 forest
once. The full FOUR-scalar restriction then covers all12 nonzero routes in
the80-position inventory. It is not full328-scalar VSS, the parent quartic
graph, the full EFT subtraction or finiteC1. Retain the overall pole; no
new normalization or overall counterterm is adopted in this increment.
