"""GAB1 freeze actual principal/carrier/current inputs, retaining historical policy bytes."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_massive_mixed_fermion_inverse'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-auxiliary-background-completion-v1-2026-10-23');OLD=CONTROL.with_name('massive-mixed-fermion-inverse-v1-2026-10-23')
BASE='ccba8c86623fb191e004ddfebc59e9fcc874a4b3';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'neutral_support_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/name;add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==33027
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['RESULT.md','validation_receipt.json','neutral_support_v2_receipt.json','neutral_support_v2_capture.json','massive_inverse_recipe.json.gz']:add(PRED/n)
assert digest(PRED/'validation_receipt.json')=='4a59fceecdcf9c61fa046b576ff73be8e2e46030498edb33d2984f6d49944b47'
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'after_seal_full_capture.json')['native_exit']==0
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V562.md','docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
# Authenticate SMP1 historical bytes at its own recorded checkpoint; no new
# AGENTS/charter bytes are substituted into its old manifest.
SMP=CAL/'canonical_so10_sterile_massive_propagator';oldbase=read(SMP/'preparation.json')['base_commit'];checkpoint='a40e4fe91a39afa45a41e595eeb28f3189db7695';subprocess.check_call(['git','merge-base','--is-ancestor',checkpoint,BASE],cwd=ROOT)
assert digest(SMP/'validation_receipt.json')=='53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c'
history=[]
for n in ['RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json','preparation.json','validation_preparation.json','primary_tables.json.gz','replay_tables.json.gz']:
 p=SMP/n;assert sha256(git('show',checkpoint+':'+p.relative_to(ROOT).as_posix())).hexdigest()==digest(p);add(p)
for n in ['preparation.json','validation_preparation.json']:
 for name,h in read(SMP/n)['input_sha256'].items():
  p=Path(name)
  if p.exists() and digest(p)==h:method='CURRENT_BYTES_MATCH_OLD_BINDING'
  else:
   rel=p.resolve().relative_to(ROOT).as_posix();assert sha256(git('show',oldbase+':'+rel)).hexdigest()==h;method='GIT_BLOB_AT_RECORDED_SMP_BASE'
  history.append({'path':name,'old_sha256':h,'authentication':method})
dump(HERE/'historical_SMP_byte_authentication.json',{'checkpoint':checkpoint,'recorded_base':oldbase,'bindings':history,'old_scientific_workers_rerun':False,'new_policy_substituted':False});add(HERE/'historical_SMP_byte_authentication.json')
for folder,names in [('canonical_so10_fermion_gauge_kinetic_pole',['RECORD.md','RESULT.md','validation_receipt.json']),('canonical_so10_fermion_gauge_fermion_vertex',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_fermion_cubic_vector_vertex',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_fermion_auxiliary_gauge_vertex',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_fermionic_background_reference',['DERIVATION.md','RESULT.md','validation_receipt_v2.json']),('canonical_so10_matter_gauge_vertex_finite_color',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_open_fermion_heat_kinetic',['DERIVATION.md','RESULT.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
BOS=CAL/'canonical_so10_local_covariant_reference_witness';add(BOS/'validation_v2_receipt.json')
plane=source('canonical_so10_ghost_triangle_field_insertion','qualified_reference_inputs.json.gz')['reference_fields']['plane_f'];assert len(plane)==720
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables.json.gz');fgt=source('canonical_so10_fermion_gauge_fermion_vertex',role+'_tables.json.gz');fcv=source('canonical_so10_fermion_cubic_vector_vertex','primary_v3_tables.json.gz' if role=='primary' else 'replay_tables.json.gz');fav=source('canonical_so10_fermion_auxiliary_gauge_vertex','primary_v2_tables.json.gz' if role=='primary' else 'replay_tables.json.gz');fb=source('canonical_so10_fermionic_background_reference',role+'_tables_v2.json.gz');q=source('canonical_so10_bosonic_source_onejet_finite','primary_v2_tables.json.gz' if role=='primary' else 'replay_v3_tables.json.gz');op=BOS/(role+'_result.json');add(op);od=read(op)
 gkeys=['combined_phase','loop_left','loop_right']+(['Feynman_left','longitudinal_left'] if role=='primary' else ['carrier_total_Casimir','C_width','adjoint_total_Casimir','adjoint_width_Casimir'])
 favdata={k:fav[k] for k in ['raw_U','selfenergy_Gaussian_unit']+(['plane_U'] if role=='replay' else [])};favdata['outputs']={tag:{side:val[side] for side in ['left','right']} for tag,val in fav['outputs'].items()}
 d={'Y':{k:y[k] for k in ['Tminus','H_new']},'Qraw':q['Qchart'],'Qi':q['Qi'],'UL':fav['auxiliary_UL'],'LH':fb['background_old_from_new'],'old':{'field_order':od['field_order'],'carriers':od['actual12_homogeneous_carrier_matrices']},'plane_f':plane,'GFT':{k:fgt[k] for k in gkeys},'FCV':{k:fcv[k] for k in ['loop_left','loop_right']},'FAV':favdata}
 gz(HERE/(role+'_inputs.json.gz'),d);add(HERE/(role+'_inputs.json.gz'))
v=source('canonical_so10_matter_gauge_vertex_finite_color','primary_tables.json.gz');k=source('canonical_so10_open_fermion_heat_kinetic','primary_tables.json.gz');g0=source('canonical_so10_fermion_gauge_kinetic_pole','primary_tables.json.gz')
gz(HERE/'validation_control_inputs.json.gz',{'current':{part:row['gauge'] for part,row in v['diagonal_H'].items()},'kinetic':{part:row['gauge'] for part,row in k['kinetic_coefficients'].items()},'old_GFK_universal_inverse':g0['universal_inverse'],'MMI_recipe':packed(PRED/'massive_inverse_recipe.json.gz'),'old_SMP':[{key:packed(SMP/(role+'_tables.json.gz'))[key] for key in ['denominator_case0','case0_block_numerator_coefficients']} for role in ['primary','replay']]});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],stdout=out,stderr=err,cwd=ROOT)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'GAB1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('GAB1_FROZEN',len(bind),'bindings',flush=True)
