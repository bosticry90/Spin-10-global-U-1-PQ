"""GAB1 literal inherited flat block and relative-family packaging only."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
prep=read(HERE/'extension_preparation_v2.json')
for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
late=packed(HERE/'validation_control_inputs.json.gz');q=s.Matrix(s.symbols('q0:4'));Q=(q.T*q)[0];w=s.Symbol('w');G=block(s.eye(4)/Q+(w-1)*q*q.T/Q**2,-q/Q,q.T/Q,s.zeros(1));zero(G-dec(late['old_GFK_universal_inverse']));zero(kernel(q,s.Matrix([[w]]))*G-s.eye(5))
r=read(HERE/'validation_receipt.json');assert r['total_remainder_nonzero']==0
YBH=CAL/'canonical_so10_yukawa_background_heat_completion';yr=read(YBH/'validation_receipt_v2.json');assert yr['total_remainder_nonzero']==0 and yr['status']=='QUALIFIED_SELECTED_YUKAWA_BACKGROUND_HEAT_COMPLETION_AND_KINETIC_COMPATIBILITY'
gauge=packed(HERE/'selected_gauge_background_family.json.gz');yuk=packed(YBH/'selected_background_family.json.gz');A0=CAL/'canonical_so10_complete_heat_scalar_response/selected_four_projection_family.json.gz'
entries={'g10^3_I_family':gauge['relative_transport'],'g10_Y10daggerY10':{},'g10_Y126daggerY126':{}}
for j,tag in enumerate(['g10_Y10daggerY10','g10_Y126daggerY126']):
 entries[tag]={part:{side:yuk['relative_background_transport'][part][side][j] for side in ['left','right']} for part in ['chi4','log3over2','fixed']}
assert len(entries)==3
for tag,parts in entries.items():
 for part in ['chi4','log3over2','fixed']:
  for side in ['left','right']:assert len(parts[part][side])==12 and all(dec(z).shape==(16,16) for z in parts[part][side])
recipe={'definition':'explicit independent A_H PP relative completion of existing A_H=0 family','A0_parent':{'path':str(A0.resolve()),'sha256':digest(A0),'coefficients_modified':False},'gauge_background_parent':{'path':str((HERE/'selected_gauge_background_family.json.gz').resolve()),'sha256':digest(HERE/'selected_gauge_background_family.json.gz')},'Yukawa_background_parent':{'path':str((YBH/'selected_background_family.json.gz').resolve()),'sha256':digest(YBH/'selected_background_family.json.gz')},'relative_AH_PP_additions_exactly_once':entries,'gauge_family_factor':'I3 no extra3','conjugate_family_factors':'Y_R Y_Rdagger for right orientation; general symmetric family matrices retained','all_added_terms_have_positive_background_AH_degree':True,'old_AH_zero_four_projection_functional_unchanged_by_degree':True,'all_three_selected_background_relative_kinetic_comparisons_zero':True,'absolute_finite_baseline_selected':False,'full_mixed_AH_source_or_quantum_Slavnov_QAP_phase_proved':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_relative_background_extension.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'status':'QUALIFIED_LITERAL_GFK_FLAT_MATCH_AND_SELECTED_RELATIVE_BACKGROUND_ASSEMBLY','elapsed_after_imports':time.perf_counter()-tick,'literal_old_GFK_flat_positions_compared':25,'old_225_reference_replayed':False,'new_loop_integrals':0,'disjoint_coupling_family_tags_assembled_once':3,'prior_four_AH_zero_projection_coefficients_preserved':True,'full_mixed_AH_source_Slavnov_or_QAP_phase_proved':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','extension_sha256':sha256(blob).hexdigest(),'extension_raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
