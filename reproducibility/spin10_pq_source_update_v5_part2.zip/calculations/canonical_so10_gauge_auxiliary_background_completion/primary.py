"""GAB1 actual raw transport, full-D ordered inverse and direct critical numerators."""
from data import *
from collections import defaultdict
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);PH=tidy(H*H.T);W=xi*s.eye(45)+(eta-xi)*PH;f=defaultdict(list)
for a,b,c,z in d['plane_f']:f[a,b].append((c,s.sympify(z)))
rhos=[]
for h in range(12):
 rh=s.zeros(45)
 for (a,b),rows in f.items():
  if H[a,h]:
   for c,z in rows:rh[c,b]-=H[a,h]*z
 rh=tidy(rh);zero(rh+rh.T);zero(rh*W-W*rh);rhos.append(rh)
Q,Qi,UL,LH=map(dec,[d['Qraw'],d['Qi'],d['UL'],d['LH']]);zero(Q*Qi-s.eye(45));ULi=UL.inv();oldB,oldL=old_blocks(d);phis=[];chart_controls={'skip_vector_chart':0,'skip_auxiliary_chart':0,'skip_background_map':0};inject=tidy(Qi*H);zero(inject[12:,:]);zero(inject[:12,:]-LH)
for h in range(12):
 rb=tidy(sum((LH[a,h]*oldB[a] for a in range(12) if LH[a,h]),s.zeros(45)));rl=tidy(sum((LH[a,h]*oldL[a] for a in range(12) if LH[a,h]),s.zeros(45)));zero(Q*rb*Qi-rhos[h]);zero(ULi*rl*UL-rhos[h]);chart_controls['skip_vector_chart']+=nz(rb-rhos[h]);chart_controls['skip_auxiliary_chart']+=nz(rl-rhos[h]);chart_controls['skip_background_map']+=nz(Q*oldB[h]*Qi-rhos[h]);raw=s.zeros(45)
 for r,a,c,z in d['FAV']['raw_U']['B']:
  if inject[c,h]:raw[r,a]+=s.sympify(z,locals=LOC)*inject[c,h]
 for r,a,c,z in d['FAV']['raw_U']['A']:
  if LH[c,h]:raw[r,a]+=s.sympify(z,locals=LOC)*LH[c,h]
 phi=tidy(UL.T*raw*Qi);zero(phi-rhos[h]);phis.append(phi)
print('STAGE ACTUAL_H_VECTOR_AUXILIARY_AND_DIAGONAL_VERTEX_MATCHED',flush=True)
# Exact full6-Lorentz fixture retains four barred plus two internal directions.
def green(k,W0):
 k=s.Matrix(k);q=(k.T*k)[0];n=k.rows;c=W0.rows;I=s.eye(c)
 return block(s.kronecker_product(s.eye(n),I)/q+s.kronecker_product(k*k.T,W0-I)/q**2,-s.kronecker_product(k,I)/q,s.kronecker_product(k.T,I)/q,s.zeros(c))
def deltaK(r,p,A,rho):
 r,p,A=map(s.Matrix,[r,p,A]);v=r+p;n=p.rows;c=rho.rows;bb=(v.dot(A))*s.eye(n)-(v*A.T+A*v.T)/2
 return block(s.kronecker_product(bb,s.I*rho),s.kronecker_product(A,s.I*rho),-s.kronecker_product(A.T,s.I*rho),s.zeros(c))
p0=s.Matrix([2,1,0,0,1,-1]);r0=s.Matrix([3,2,1,0,1,-1]);W0=s.diag(eta,eta,xi,xi);J=s.Matrix([[0,1],[-1,0]]);rho=s.diag(J,J);RR=s.kronecker_product(s.eye(7),rho);Gp=green(p0,W0);Gr=green(r0,W0);Kp=kernel(p0,W0);Kr=kernel(r0,W0)
zero(Kp*Gp-s.eye(28));zero(Gp*Kp-s.eye(28));zero(Kp.T-kernel(-p0,W0));zero(Gp.T-green(-p0,W0));dk=deltaK(r0,p0,s.I*(r0-p0),rho);zero(dk-(RR*Kp-Kr*RR));dg=tidy(-Gr*dk*Gp);zero(dg-(RR*Gp-Gr*RR))
a,b=s.symbols('F_p F_r');df=RR*(a-b);filtered=tidy(df*Gp*a+b*dg*a+b*Gr*df);expected=RR*a*a*Gp-b*b*Gr*RR;zero(filtered-expected);omit=tidy((filtered-b*Gr*df-expected).subs({a:s.Rational(1,2),b:s.Rational(1,3)}));assert nz(omit)>0;zero((filtered-b*Gr*df-expected).subs(b,a))
constants=[];qq=(p0.T*p0)[0];I4=s.eye(4)
for mu in range(4):
 e=s.eye(6)[:,mu];dG=block(-2*p0[mu]*s.kronecker_product(s.eye(6),I4)/qq**2+s.kronecker_product(e*p0.T+p0*e.T,W0-I4)/qq**2-4*p0[mu]*s.kronecker_product(p0*p0.T,W0-I4)/qq**3,-s.kronecker_product(e,I4)/qq+2*p0[mu]*s.kronecker_product(p0,I4)/qq**2,s.kronecker_product(e.T,I4)/qq-2*p0[mu]*s.kronecker_product(p0.T,I4)/qq**2,s.zeros(4))
 resp=tidy(-Gp*deltaK(p0,p0,e,rho)*Gp);zero(resp-s.I*RR*dG);constants.append(enc(resp))
wrong=Gp.copy();wrong[:24,24:]=-wrong[:24,24:];mixed_control=nz(Kp*wrong-s.eye(28));assert mixed_control>0
kb=p0.copy();kb[4]=kb[5]=0;early=block(s.kronecker_product(s.eye(6),I4)/qq+s.kronecker_product(kb*kb.T,W0-I4)/qq**2,-s.kronecker_product(kb,I4)/qq,s.kronecker_product(kb.T,I4)/qq,s.zeros(4));early_control=nz(Kp*early-s.eye(28));assert early_control>0
bad=s.zeros(4);bad[0,2]=1;bad[2,0]=-1;assert nz(bad*W0-W0*bad)>0
qa=r0-p0;trans=s.eye(6)[:,3];curvature=s.kronecker_product(qa*trans.T-trans*qa.T,rho);assert nz(curvature)>0;zero(curvature-curvature.T);zero(qa*(s.I*qa).T-(s.I*qa)*qa.T)
# New universal auxiliary-reference and both ordered heat numerators.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];g=[s.kronecker_product(z,pa[2]) for z in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]];L=s.kronecker_product(s.diag(1,1,0,0),s.eye(2));R=s.eye(8)-L;IC=s.eye(2);Ta=s.Matrix([[1,1],[1,0]]);Tb=s.Matrix([[2,s.I],[-s.I,3]]);Th=s.diag(1,2)
charge=lambda tt:s.kronecker_product(L,tt)-s.kronecker_product(R,tt.T);swap=lambda tt:s.kronecker_product(R,tt)-s.kronecker_product(L,tt.T)
Va=[s.kronecker_product(z,IC)*charge(Ta) for z in g[:4]];Vb=[s.kronecker_product(z,IC)*charge(Tb) for z in g[:4]];vs=[s.kronecker_product(z,IC)*swap(Th) for z in g[:4]];k=s.symbols('k0:4');D=s.Symbol('D');slash=sum((z*v for z,v in zip(g[:4],k)),s.zeros(8));sl=s.kronecker_product(slash,IC);vsa=sum((z*v for z,v in zip(Va,k)),s.zeros(16));vsb=sum((z*v for z,v in zip(Vb,k)),s.zeros(16))
def avg(z,dim):
 out=0
 for powers,c in s.Poly(s.expand(z),*k).terms():
  if not c or any(v%2 for v in powers):continue
  out+=c*s.prod(s.factorial2(v-1) for v in powers)/s.prod(dim+2*j for j in range(sum(powers)//2))
 return simp(out)
def coefficient(M,target):
 ij=next(ij for ij,z in target.todok().items() if z);x=simp(M[ij]/target[ij]);zero(M-x*target);return x
spin=0;au=[];fh=[];bh=[]
for nu in range(4):
 for Pout,Pin,color in [(R,L,Ta*Th*Tb),(L,R,-Ta.T*Th.T*Tb.T)]:
  op=s.kronecker_product(Pout,IC);ip=s.kronecker_product(Pin,IC);target=s.kronecker_product(g[nu]*Pin,color)
  for hat in g[4:]:
   hi=s.kronecker_product(hat,IC);nf=op*sum((x*hi*vs[nu]*hi*y for x,y in zip(Va,Vb)),s.zeros(16))*ip;nl=(op*vsa*hi*vs[nu]*hi*vsb*ip).applyfunc(lambda z:avg(z,D)/(D+2));cf=coefficient(nf,target)*(D-4)/D;cl=coefficient(nl,target)*(D-4);au.append((simp(cf),simp(cl)));spin+=2*16**2
  hf=(2*k[nu]*op*sum((x*(charge(Th)*sl+sl*swap(Th))*y for x,y in zip(Va,Vb)),s.zeros(16))*ip).applyfunc(lambda z:avg(z,4)/4);hl=(2*k[nu]*op*vsa*(charge(Th)*sl+sl*swap(Th))*vsb*ip).applyfunc(lambda z:avg(z,4)/4);fh.append((coefficient(hf,target),coefficient(hl,target)));spin+=2*16**2
 # Bosonic heat has an additional i from deltaP at momentum -k.
 bf=(4*k[nu]*sum((z*slash*z for z in g[:4]),s.zeros(8))).applyfunc(lambda z:avg(z,4)/4);bl=(4*k[nu]*slash*slash*slash).applyfunc(lambda z:avg(z,4)/4);bh.append((coefficient(bf,g[nu]),coefficient(bl,g[nu])));spin+=2*8**2
assert len(set(au))==len(set(fh))==len(set(bh))==1
eps,m2=s.symbols('epsilon m2',positive=True);rad=(4*s.pi)**eps*s.gamma(eps)*m2**(-eps)/s.gamma(2-eps);af,al=[s.limit(z.subs(D,4-2*eps)*rad,eps,0) for z in au[0]]
assert s.sympify(d['GFT']['combined_phase'])==-s.I;bos_phase=simp((-1)*(-s.I)**2*(-s.I)*s.I);assert bos_phase==1
units={'aux_F':af,'aux_L':al,'ferm_F':fh[0][0],'ferm_L':fh[0][1],'bos_F':bh[0][0]*bos_phase,'bos_L':bh[0][1]*bos_phase}
FFL=project(list(map(dec,d['GFT']['Feynman_left'])),H);LLL=project(list(map(dec,d['GFT']['longitudinal_left'])),H);FF=[FFL,[-x.T for x in FFL]];LL=[LLL,[-x.T for x in LLL]];bos=[[],[]]
for rh in rhos:
 weights=[rh,tidy(rh*(W-s.eye(45)))];Cs=[[],[]]
 for wt in weights:
  for side,ts in enumerate([T,[-x.T for x in T]]):Cs[side].append(tidy(sum((z*ts[a]*ts[b] for (a,b),z in wt.todok().items()),s.zeros(16))))
 for side in range(2):bos[side].append(tidy(units['bos_F']*Cs[side][0]+units['bos_L']*Cs[side][1]))
out=assemble(d,units,FF,LL,*bos);out.update({'chart_control_changed_positions':chart_controls,'method':'actual_f_raw_carrier_and_density_transport_fullD_direct_matrix_Duhamel_and_Clifford_sphere','rho_H':list(map(enc,rhos)),'Phi_diagonal_H':list(map(enc,phis)),'W':enc(W),'full6_green_fixture':enc(Gp),'constant_inverse_response':constants,'pure_gauge_full_filter_identity':True,'first_positive_heat_order_retained':True,'mixed_orientation_control_changes':mixed_control,'early_barred_vector_control_changes':early_control,'omit_right_heat_control_changes':nz(omit),'equal_heat_weights_control_insensitive':True,'width_noncommuting_charge_control_nonzero':True,'all12_actual_vector_auxiliary_carriers_match':True,'all12_actual_diagonal_GF_vertices_match':True,'spin_positions_checked':spin,'auxiliary_angular_units_D':list(map(str,au[0])),'bosonic_heat_phase':str(bos_phase),'curvature_transverse_witness_nonzero_positions':nz(curvature),'pure_gauge_and_zerojet_tests_insensitive_to_curvature_additions':True});finish('primary',out,tick)
