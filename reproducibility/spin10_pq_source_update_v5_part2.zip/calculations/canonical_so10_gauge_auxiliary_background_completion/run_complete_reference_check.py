"""Freeze and execute the post-check without repeating either quantum worker."""
from pathlib import Path
from hashlib import sha256
import json,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-auxiliary-background-completion-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 base=read(HERE/'preparation.json');bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
 for p,h in bind.items():assert digest(Path(p))==h,p
 assert read(HERE/'validation_receipt.json')['total_remainder_nonzero']==0
 for n in ['QUALIFICATION_EXTENSION_V2.md','complete_reference_check.py','run_complete_reference_check.py']:
  p=HERE/n;b=p.read_bytes();assert b'\r' not in b
  if p.suffix=='.py':compile(b,str(p),'exec')
  with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 for p in HERE.iterdir():
  if p.is_file():bind[str(p.resolve())]=digest(p)
 for folder,names in [('canonical_so10_yukawa_background_heat_completion',['selected_background_family.json.gz','validation_receipt_v2.json']),('canonical_so10_complete_heat_scalar_response',['selected_four_projection_family.json.gz','validation_receipt_v2.json'])]:
  for n in names:p=CAL/folder/n;bind[str(p.resolve())]=digest(p)
 dump(HERE/'extension_preparation_v2.json',{**base,'schema':'GAB1_EXTENSION_PREPARATION_V2','input_sha256':dict(sorted(bind.items())),'original_completed_quantum_workers_not_rerun':True})
 print('GAB1_EXTENSION_V2_FROZEN',len(bind),'bindings',flush=True)
 c=capture([sys.executable,'-B',str(HERE/'complete_reference_check.py')]);dump(HERE/'complete_reference_check_capture.json',c);dump(CONTROL/'complete_reference_check_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1;r=rows[0];assert r['elapsed_after_imports']<600 and r['status']=='QUALIFIED_LITERAL_GFK_FLAT_MATCH_AND_SELECTED_RELATIVE_BACKGROUND_ASSEMBLY'
 b=(HERE/'selected_relative_background_extension.json.gz').read_bytes();assert sha256(b).hexdigest()==r['extension_sha256'];dump(HERE/'extension_receipt_v2.json',r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
except BaseException:
 dump(HERE/'extension_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
