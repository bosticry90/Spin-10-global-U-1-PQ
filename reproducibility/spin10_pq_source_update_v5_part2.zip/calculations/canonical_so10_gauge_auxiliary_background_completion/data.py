"""GAB1 immutable IO and exact matrix serialization; derivations are separate."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(maxsize=262144)
def simp(z):return s.simplify(z)
def tidy(m):return s.SparseMatrix(m).applyfunc(simp)
def zero(m):assert not tidy(m).todok()
def nz(m):return len(tidy(m).todok())
eta,xi=s.symbols('eta_H xi',real=True)
LOC={'eta_H':eta,'xi':xi}
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z,locals=LOC) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(s.expand(z))] for (i,j),z in sorted(tidy(m).todok().items())]}
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
def begin(role):
 tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('GAB1_PEER_OR_LATE_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def finish(role,out,tick):
 out.update({'elapsed_after_imports':time.perf_counter()-tick,'construction':'DECLARED_LEADING_FULL_D_GAUGE_AUXILIARY_H_MEMBER_AND_LOCAL_TRANSPORT','family_identity':'I3_NO_EXTRA_FACTOR','new_massive_loop_integrals':0,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'})
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)


def old_blocks(d):
 names=d['old']['field_order'];pos={n:i for i,n in enumerate(names)};B={pos[f'B{a}_{mu}']:(a,mu) for a in range(45) for mu in range(4)};L={pos['b'+str(a) if a<12 else 'L'+str(a)]:a for a in range(45)};bb=[];ll=[]
 for rows in d['old']['carriers']:
  bm=[{} for _ in range(4)];lm={}
  for i,j,z in rows:
   if i in B:
    assert j in B and B[i][1]==B[j][1];a,mu=B[i];b,nu=B[j];bm[mu][a,b]=s.sympify(z,locals=LOC)
   if i in L:assert j in L;lm[L[i],L[j]]=s.sympify(z,locals=LOC)
  mats=[s.SparseMatrix(45,45,m) for m in bm]
  for mat in mats[1:]:zero(mat-mats[0])
  bb.append(mats[0]);ll.append(s.SparseMatrix(45,45,lm))
 return bb,ll

def kernel(k,W):
 k=s.Matrix(k);n=k.rows;c=W.rows;Q=(k.T*k)[0];I=s.eye(c)
 return block(s.kronecker_product(Q*s.eye(n)-k*k.T,I),s.kronecker_product(k,I),-s.kronecker_product(k.T,I),W)

def project(mats,H):
 return [tidy(sum((H[a,h]*mats[a] for a in range(45) if H[a,h]),s.zeros(16))) for h in range(12)]

def assemble(d,units,FF,LL,bos_left,bos_right):
 H=dec(d['Y']['H_new']);pole={};parts={'auxiliary_dimensional':{},'fermion_heat':{},'boson_heat':{}};transport={part:{} for part in ['chi4','log3over2','fixed']}
 for side,j in [('left',0),('right',1)]:
  f=FF[j];l=LL[j];g=project(list(map(dec,d['GFT']['loop_'+side])),H);v=project(list(map(dec,d['FCV']['loop_'+side])),H);aB=project(list(map(dec,d['FAV']['outputs']['B'][side])),H);aA=list(map(dec,d['FAV']['outputs']['A'][side]));pol=[tidy(x+y+z+w) for x,y,z,w in zip(g,v,aB,aA)];pole[side]=list(map(enc,pol))
  aux=[tidy(units['aux_F']*x+units['aux_L']*y) for x,y in zip(f,l)];hf=[tidy(units['ferm_F']*x+units['ferm_L']*y) for x,y in zip(f,l)];hb=bos_left if side=='left' else bos_right
  for key,arr in [('auxiliary_dimensional',aux),('fermion_heat',hf),('boson_heat',hb)]:parts[key][side]=list(map(enc,arr))
  transport['chi4'][side]=[enc(s.zeros(16)) for _ in range(12)];transport['log3over2'][side]=[enc(-x) for x in pol];transport['fixed'][side]=[enc(x-y-z) for x,y,z in zip(aux,hf,hb)]
 return {'old_pole_H':pole,'parts':parts,'relative_transport':transport,'units':{k:str(v) for k,v in units.items()}}
