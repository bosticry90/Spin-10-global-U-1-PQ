"""GAB1 independent old-carrier/Lie route, longitudinal elimination and Schwinger units."""
from data import *
from collections import defaultdict
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);PH=tidy(H*H.T);W=xi*s.eye(45)+(eta-xi)*PH;Q,Qi,UL,LH=map(dec,[d['Qraw'],d['Qi'],d['UL'],d['LH']]);oldB,oldL=old_blocks(d);rhos=[];phis=[];TH=project(T,H)
for h in range(12):
 rb=sum((LH[a,h]*oldB[a] for a in range(12) if LH[a,h]),s.zeros(45));rl=sum((LH[a,h]*oldL[a] for a in range(12) if LH[a,h]),s.zeros(45));rh=tidy(Q*rb*Qi);zero(UL.inv()*rl*UL-rh);zero(rh+rh.T);zero(rh*W-W*rh)
 for a in range(45):zero(sum((rh[e,a]*T[e] for e in range(45) if rh[e,a]),s.zeros(16))-s.I*(TH[h]*T[a]-T[a]*TH[h]))
 phi=s.zeros(45)
 for r,a,c,z in d['FAV']['plane_U']['B']:
  if H[c,h]:phi[r,a]+=s.sympify(z,locals=LOC)*H[c,h]
 for r,a,c,z in d['FAV']['plane_U']['A']:
  if c==h:phi[r,a]+=s.sympify(z,locals=LOC)
 phi=tidy(phi);zero(phi-rh);rhos.append(rh);phis.append(phi)
print('STAGE INDEPENDENT_OLD_CARRIER_LIE_AND_EULER_VERTEX_ROUTE',flush=True)
# Longitudinal/auxiliary block elimination; no inversion of a gauge width.
def green(k,W0):
 k=s.Matrix(k);n=k.rows;c=W0.rows;q=(k.T*k)[0];I=s.eye(c);z=s.zeros(c);L=block(z,s.sqrt(q)*I,-s.sqrt(q)*I,W0).inv();PT=s.eye(n)-k*k.T/q
 return tidy(block(s.kronecker_product(PT,I)/q+s.kronecker_product(k*k.T/q,L[:c,:c]),s.kronecker_product(k/s.sqrt(q),L[:c,c:]),s.kronecker_product(k.T/s.sqrt(q),L[c:,:c]),L[c:,c:]))
p0=s.Matrix([2,1,0,0,1,-1]);r0=s.Matrix([3,2,1,0,1,-1]);W0=s.diag(eta,eta,xi,xi);J=s.Matrix([[0,1],[-1,0]]);rho=s.diag(J,J);RR=s.kronecker_product(s.eye(7),rho);Gp=green(p0,W0);Gr=green(r0,W0);Kp=kernel(p0,W0);Kr=kernel(r0,W0);zero(Kp*Gp-s.eye(28));zero(Gp*Kp-s.eye(28));dg=tidy(-Gr*(RR*Kp-Kr*RR)*Gp);zero(dg-RR*Gp+Gr*RR)
a,b=s.symbols('F_p F_r');df=RR*(a-b);actual=df*Gp*a+b*dg*a+b*Gr*df;expected=RR*a*a*Gp-b*b*Gr*RR;zero(actual-expected);omit=tidy((actual-b*Gr*df-expected).subs({a:s.Rational(1,2),b:s.Rational(1,3)}));assert nz(omit)>0;zero((actual-b*Gr*df-expected).subs(b,a))
k=s.Matrix(s.symbols('q0:6'));Ks=kernel(k,W0);sub=dict(zip(k,p0));constants=[]
for mu in range(4):dk=s.I*RR*Ks.diff(k[mu]).subs(sub);constants.append(enc(tidy(-Gp*dk*Gp)))
wrong=Gp.copy();wrong[:24,24:]=-wrong[:24,24:];mixed_control=nz(Kp*wrong-s.eye(28));assert mixed_control>0
qq=(p0.T*p0)[0];kb=p0.copy();kb[4]=kb[5]=0;I=s.eye(4);early=block(s.kronecker_product(s.eye(6),I)/qq+s.kronecker_product(kb*kb.T,W0-I)/qq**2,-s.kronecker_product(kb,I)/qq,s.kronecker_product(kb.T,I)/qq,s.zeros(4));early_control=nz(Kp*early-s.eye(28));assert early_control>0
bad=s.zeros(4);bad[0,2]=1;bad[2,0]=-1;assert nz(bad*W0-W0*bad)>0
# Independent Schwinger/Gaussian hatted moments and barred Clifford identities.
eps,m2=s.symbols('epsilon m2',positive=True);h=-2*eps;rad=(4*s.pi)**eps*s.gamma(eps)*m2**(-eps);I0=s.limit(h*rad/4,eps,0);J0=s.limit(h*rad/24,eps,0)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];z=s.zeros(2);ii=s.eye(2);g=[block(z,-s.I*x,s.I*x,z) for x in pa]+[block(z,ii,ii,z)];v=s.Symbol('v',positive=True);power=s.integrate(v/(v+4)**3,(v,0,s.oo))/2;rat=[]
for gam in g:
 contraction=sum((x*gam*x for x in g),s.zeros(4));zero(contraction+2*gam);nf=-contraction;ij=next(ij for ij,x in gam.todok().items() if x);coef=simp(nf[ij]/gam[ij]);zero(nf-coef*gam);rat.append(coef)
assert len(set(rat))==1;auxf=rat[0]*I0;auxl=rat[0]*J0;heatf=-4*power*rat[0];heatl=4*power
phase=simp(s.sympify(d['FAV']['selfenergy_Gaussian_unit'])*(-s.I)**2*(-s.I)*s.I);assert phase==1
units={'aux_F':auxf,'aux_L':auxl,'ferm_F':heatf,'ferm_L':heatl,'bos_F':phase*heatf,'bos_L':phase*heatl}
# The proper ordered triple is reconstructed from the adjoint and carrier
# Casimirs, independently of primary's direct raw GFT F/L contractions.
CF,CW,CA,CAW=map(dec,[d['GFT']['carrier_total_Casimir'],d['GFT']['C_width'],d['GFT']['adjoint_total_Casimir'],d['GFT']['adjoint_width_Casimir']]);aH=CA*H;awH=CAW*H;FF=[[],[]];LL=[[],[]]
for side,ts in enumerate([T,[-x.T for x in T]]):
 cf=CF if side==0 else CF.T;cw=CW if side==0 else CW.T
 for h0 in range(12):
  th=sum((H[a,h0]*ts[a] for a in range(45) if H[a,h0]),s.zeros(16));ta=sum((aH[a,h0]*ts[a] for a in range(45) if aH[a,h0]),s.zeros(16));tw=sum((awH[a,h0]*ts[a] for a in range(45) if awH[a,h0]),s.zeros(16));f0=tidy((cf*th+th*cf-ta)/2);w0=tidy((cw*th+th*cw-tw)/2);FF[side].append(tidy(-s.I*f0));LL[side].append(tidy(-s.I*(w0-f0)))
f=defaultdict(list)
for a,b,e,x in d['plane_f']:f[a,b].append((e,s.sympify(x)))
bos=[[],[]]
for rh in rhos:
 cs=[]
 for wt in [rh,tidy(rh*(W-s.eye(45)))]:
  zero(wt+wt.T);co=[0]*45
  for (a,b),x in wt.todok().items():
   for e,y in f[a,b]:co[e]+=x*y
  cs.append(co)
 for side,ts in enumerate([T,[-x.T for x in T]]):bos[side].append(tidy(s.I*sum(((units['bos_F']*cs[0][e]+units['bos_L']*cs[1][e])*ts[e]/2 for e in range(45) if cs[0][e] or cs[1][e]),s.zeros(16))))
out=assemble(d,units,FF,LL,*bos);out.update({'method':'old_carrier_and_Lie_reconstruction_Euler_vertex_longitudinal_elimination_Schwinger_moments_and_commutators','rho_H':list(map(enc,rhos)),'Phi_diagonal_H':list(map(enc,phis)),'W':enc(W),'full6_green_fixture':enc(Gp),'constant_inverse_response':constants,'pure_gauge_full_filter_identity':True,'first_positive_heat_order_retained':True,'mixed_orientation_control_changes':mixed_control,'early_barred_vector_control_changes':early_control,'omit_right_heat_control_changes':nz(omit),'equal_heat_weights_control_insensitive':True,'width_noncommuting_charge_control_nonzero':True,'all12_actual_vector_auxiliary_carriers_match':True,'all12_actual_diagonal_GF_vertices_match':True,'actual_mixed_Lie_positions':12*45*256,'Schwinger_hat_moments':[str(I0),str(J0)],'bosonic_heat_phase':str(phase),'pure_gauge_and_zerojet_tests_insensitive_to_curvature_additions':True});finish('replay',out,tick)
