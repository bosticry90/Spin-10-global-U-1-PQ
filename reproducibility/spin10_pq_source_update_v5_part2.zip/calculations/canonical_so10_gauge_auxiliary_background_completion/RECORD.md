# GAB1: actual gauge/auxiliary background member and marginal gauge heat completion

Base ccba8c86623fb191e004ddfebc59e9fcc874a4b3/main33027 blobs. Previous
turn PROGRESS: YBH selected Yukawa background comparison and MMI matrix/neutral
support checks qualified. Recovery now found SMP1 already supplied the core
massive inverse and family transport. Bind the appended MMI historical scope
correction; preserve all originals. Reuse the known inverse instead of another
massive replay. Scientific state113/authority34/39 remains unchanged.

Question: does an explicitly specified full-D weighted vector/auxiliary
background member recover the actual flat reference and background vertices,
and does its independently calculated g10^3 local open-fermion heat/reference
transport match the kinetic comparison? This closes the remaining gauge part
of the selected marginal background target. The least expensive competent test
uses the existing GFK flat inverse, FAV mixed vertices, actual H carriers and
new universal critical numerators, not a new full643 Hessian or two-loop tensor.

For integer Lorentz dimensiond and Q=k2, use the actual leading mixed block
K=[[Q delta-kk,k],[-k.T,W]], W=eta_H PH+xi PM, with GBB=delta/Q+
(W-I)kk/Q2, GBL=-k/Q, GLB=+k.T/Q and GLL=0. No inverse width is needed.
The mixed signs and Wick contour are inherited from actual GFK/FAV evidence.
Full momentum and Lorentz sewing precede barred physical fermion endpoints.
Dimensional continuation remains formal; no positive-Laplacian assumption
about the mixed K or new quantum trace/IR domain is imported.

Construct the fixed Weyl member with nabla=partial-g rho_H A_H,
KBB=-nabla2 delta+Sym(nabla_mu nabla_nu), KBL=-i nabla_mu,
KLB=+i nabla_nu, KLL=W, and separate positive heat -nabla2 on both sectors.
This is a provisional member, not uniquely recovered or physically adopted.
Match rho_H to actual old643 vector and auxiliary carriers through the FBR
background map and their separate raw-to-plane charts; do not identify raw
labels or auxiliary dual coordinates. Verify [rho_H,W]=0 and the full Lie
intertwiner for all12 H. Reconstruct the actual diagonal B_H+A_H auxiliary
vertex from both raw FAV densities and the independent plane/Euler route.
Its equality to the candidate constant-background current is a prerequisite;
a mismatch stops the proposed full comparison rather than changing inputs.

Primary uses actual structure constants, raw carrier/density transport, direct
mixed-matrix and two-heat variation, explicit split-Clifford auxiliary-current
numerators, D-sphere/Gamma finite parts and literal model color products.
Replay uses old-carrier reconstruction/Lie brackets, transverse-longitudinal
elimination, momentum differentiation, Schwinger hatted moments and independent
commutator color reductions. Reuse the qualified distinct F/L and proper action
pole currents; finite VFC and kinetic targets are withheld until the gate.
Keep the physical fermion right-dual carrier, both bosonic heat endpoints,
all proper mixed placements, positive heat power terms and heat4/heat6 change.

Extract the new S-background insertion on the internal fermion line, the
fermion heat variation and boson heat variation independently. Preserve all
symbolic eta_H,xi,chi4 and all zeros. Then add the derived relative transport
to the measured old diagonal-H finite action current and compare against FHK.
No fitted unknown correction, gauge-width choice, family3 or open-line half.
If two methods agree but the final local remainder is nonzero, preserve a
qualified scoped mismatch. It is not automatically an anomaly. Gamma_ref[A]
and its pure-background phase remain separate by external-P2 degree.

Controls drop a mixed orientation, prematurely bar internal vectors/momenta,
use noncommuting H/M width charges, omit either heat endpoint or a measured
insertion/placement term, change the fermion right dual, or double-count
longitudinal placements. Pure-gauge and constant-background tests are
insensitive to permitted curvature additions; exhibit that limitation rather
than claiming a unique off-flat reference. Wrong raw chart controls must
report their actual sensitivity, including insensitive subspaces.

Freeze eight sources/copies, old receipts and inputs before three sequential
600s-afterimports/8GiB sampled private/350MiB launch commit/16MiB packet stages.
Fresh E4 this goal turn, no --fresh old scientific replay, custodyexit2/seven
NOTPASS. Preserve native failures and version fixes, fail-stop on prerequisite
or method mismatch. Validate before local commit and use before/index/after
seals preserving33027 old blobs. No agents/branches/worktrees/push/outreach,
publication/adoption, flavor activation, HB1/C5 unlock or authority promotion.

Ceiling: explicit leading full-D H reference and selected mass-independent
marginal g3 background local coefficient, complementing the qualified YdagY
member. Not full nonexceptional amplitudes, all hatted/external/massive terms,
quantum source/background equivalence, nonlinear products/QAP, measure/phase,
physical scheme or massive matterC1/E5/A5/GUT. Preserve both scalar failures,
quartetFAIL and all finite freedoms. Shared premises/action/old tensors,
software and AI authorship limit independence. Whole goal ACTIVE/incomplete.
