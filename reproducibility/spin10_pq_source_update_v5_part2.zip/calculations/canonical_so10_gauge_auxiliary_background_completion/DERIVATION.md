# GAB1: mixed reference, background insertion and three finite transports

The known mixed inverse is dimension independent as a tensor formula:

 K=[[Q delta-kk,k],[-k.T,W]],
 G=[[delta/Q+(W-I)kk/Q2,-k/Q],[k.T/Q,0]].

Transverse directions invert with1/Q; the longitudinal/auxiliary2x2 block has
determinantQ. This uses neither an inverseW nor a closed Lorentz trace. The
actual four-dimensional GFK reference and FAV contour fix its signs.

Define rho_h(cb)=-sum_a H_new(a,h) f_ab^c. The matter generators satisfy
sum_e rho_h(e,b) T_e=i[T_H,h,T_b]. Match this carrier to the old raw B and
Lambda carriers using Qraw,LH and UL separately. W commutes with it, since H
preserves PH. The chosen ordered local extension is

 KBB=-nabla2 delta+{nabla_mu,nabla_nu}/2,
 KBL=-i nabla_mu, KLB=+i nabla_nu, KLL=W,
 nabla=partial-g rho_h A_h.

It is a differential-transpose symmetric mixed kernel, not a positive scalar
heat generator. Use the separate P_heat=-nabla2. Curvature additions can
vanish in the flat limit; this member is explicit but not uniquely physical.
For incomingp/outgoingr its first derivative is

 deltaKBB=i g rho[(r+p).A delta-((r+p)_mu A_nu+(r+p)_nu A_mu)/2],
 deltaKBL=i g rho A_mu, deltaKLB=-i g rho A_nu.

For A=i(r-p)omega this equals g rho(Kp-Kr)omega. Thus -Gr deltaK Gp has the
correct endpoint identity. Retain all three terms in delta(F G F.T). At zero
background the two heat factors are scalar, but their variations stay on
opposite ordered ends. For constantA, deltaG=i g rho A_mu partial_kmu G.
The actual gauge-loop boson momentum is -k. The full-D current is compared
with the old actual YM cubic and diagonal FAV B_H+A_H mixed vertex before
using it in a finite quantum comparison.

Write F_h,L_h for the old GFT Feynman and (W-I) longitudinal pole currents.
The new S-reference insertion lies between two mixed fermion propagators.
Its actual gauge/Yukawa-independent phase is the same -i as the proper
fermion gauge triangle. Derive the split-Clifford numerators with barred
external gamma matrices before applying moments. Per formal hatted rank
D-4 their angular units must come from those numerators, not from a Ward
target. A zero pole can still leave a finite part. Replay uses the exact
hat moments I0=FP integral hatk2/(Q+m2)^3 and J_mu,nu=FP integral
hatk2 kbar_mu kbar_nu/(Q+m2)^4, derived by Schwinger Gaussians. The auxiliary
m2 is only a common mathematical local UV completion, not a physical mass.

The two fermion heat variations contain A_H G+G Atilde_H with their actual
order. The boson heat variations contain rho_H G+G rho_H at momentum-k.
Their phases differ. Evaluate the positive finite power radial integrals;
do not infer their constants from pole coefficients. All inverse placements
have heat length4, while old proper action triangles have length6. Their
finite placement change is log(3/2) times the complete old pole current.

Let Aux_h,Hferm_h,Hbos_h denote the independently extracted finite terms.
The new relative current is

 old_relative_h + Aux_h -Hferm_h-Hbos_h-log(3/2)*old_pole_h.

Keep exact model colors and longitudinal placements throughout. Only the gate
compares the result with the independently measured kinetic covariantization.
The reference determinant has no external-P2 component; this degree statement
does not discard its pure-background value or phase. The selected independent
A_H PP local extension vanishes at A_H=0 and preserves old four A0 projections
by degree, not by a new full source/Slavnov proof.
