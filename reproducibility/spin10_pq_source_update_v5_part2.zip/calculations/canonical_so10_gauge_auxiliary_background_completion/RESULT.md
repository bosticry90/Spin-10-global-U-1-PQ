# GAB1: complete selected gauge-background heat transport matches the kinetic coefficient

Qualified within the explicit leading full-D H-background member:
`QUALIFIED_FULL_D_GAUGE_AUXILIARY_H_MEMBER_AND_SELECTED_GAUGE_BACKGROUND_HEAT_COMPATIBILITY`.
Receipt SHA256 `bb912b908c8118bf3a3ce3211c14aeafe2a697ef1312ec2b394d7fcd81aea317`. The literal flat/reference assembly post-check
receipt SHA256 is `ad75131e28f54ca95a0cb4a62d7b8b085e4b9f72fb54d02550f3223aaf468da6`. Scientific/director acceptance not performed;
state113 and authority34/39 remain unchanged.

## The actual mixed reference and background vertices agree

The known mixed block, with Q=k2 and W=eta_H PH+xi PM, is

```
K=[[Q delta-kk,k],[-k.T,W]],
G=[[delta/Q+(W-I)kk/Q2,-k/Q],[k.T/Q,0]].
```

This tensor formula retains the full Lorentz momentum before selecting barred
fermion endpoints. Transverse/longitudinal elimination and direct inversion
agree; no inverse width or mixed-Hessian positivity is assumed. The chosen
local member uses the symmetrized covariant derivative in KBB, opposite
-i nabla/+i nabla mixed entries and separate connection-Laplacian heat on
B and Lambda. It is a declared provisional member, not a uniquely recovered
physical regulator. Literal comparison with all25 old GFK inverse entries
passes without replaying its already qualified225-field calculation.

All twelve actual old643 vector and auxiliary carriers are transported using
their separate Qraw and UL charts and the FBR background-coordinate map.
They agree with rho_h(cb)=-H(a,h)f_ab^c, with [rho_h,W]=0. The independent
route reconstructs the carrier from old matrices and checks all540 mixed
Lie relationships. The raw FAV density route and independent Euler/plane
route both give the same diagonal B_H+A_H mixed current rho_h. Thus the
constant-background leading reference vertices match actual action vertices;
they were not selected from the quantum Ward target.

The six-Lorentz-component inverse, its first background derivative and the
ordered three-term heat variation pass. Both mixed orientations and internal
hatted vector components are necessary. Wrong mixed orientation changes4
fixture positions, early barred restriction changes100, and omission of the
right heat changes144. Equal heat weights are explicitly insensitive. A
transverse curvature witness is nonzero while pure-gauge/zero-jet tests are
insensitive to it; the result does not select all off-flat curvature terms.
The methods compare52,520 construction positions including zeros and retain
48,600 actual vector/auxiliary carrier bridge positions.

## The finite contributions are independently derived

Let F_H,L_H be the previously measured proper fermion-current Feynman and
(W-I) longitudinal pole tensors. The new auxiliary-reference insertion is

```
Aux = -F_H -L_H/6.
```

It comes from two mixed P-S propagators and the actual S background current.
The angular units2(D-4)/D and2(D-4)/[D(D+2)] have zero pole but nonzero finite
parts -1 and -1/6. Primary uses explicit split-Clifford matrices and sphere/
Gamma integrals; replay uses Schwinger hatted moments -1/2 and -1/12 and
independent Clifford contractions. Internal hats were retained until after
the finite extraction. No additional physical sterile vertex is adopted.

The two endpoint heat variations give

```
Hferm = -F_H/2 +L_H/4,
Hbos  = -C_I/2 +C_(W-I)/4,
C_X   = sum_ab (rho_H X)_ab T_a T_b.
```

The bosonic heat phase is+1; the fermion-current phase is inherited -i.
Their signs follow from the actual loop routing and inverse response. The
replay derives the rank-two positive-heat integral and reduces colors through
Lie commutators, independently of the primary's literal ordered products.
All inverse placements have heat length4 instead of the old proper triangles'
length6, giving the separate log(3/2) times complete pole contribution.
The finite-current and kinetic targets were withheld until the late gate.

Adding the measured old relative current and these computed transports gives,
in common g10^3/(16pi2) units on the left,

```
L_H = -i [chi4 CW+(5/12)(CW-CF)] T_H,
CF=(45/8)I16, CW=eta_H CH+xi(CF-CH).
```

This equals the independently measured FHK kinetic covariantization for all
twelve H directions and both chiralities. The right current is the negative
transpose. The finite width-dependent term is generally NONZERO; it is the
remainder that vanishes. The comparison retains symbolic widths and chi4,
with zero/nonzero coefficients checked in all18,432 current/kinetic positions
and43,008 transport positions. Each insertion/heat/placement omission changes
214 combined internal positions. No unknown contribution or finite baseline
was fitted, and no gauge or physical coupling was selected.

## Exact-once relative extension and historical correction

The post-check assembles three disjoint measured relative A_H PP tags:
g10^3 I_family, g10 Y10daggerY10 and g10 Y126daggerY126. The Yukawa terms
reuse the qualified YBH result, not new integrations. All general family
matrices and their conjugate-right orientations remain. The previous four
A_H=0 family is retained by immutable reference; new terms vanish at A_H=0
and do not re-add old proper-source contributions. This is a relative local
extension, not a proof of every mixed background/source Slavnov image.
The gauge recipe packed/raw SHA256 are
`7118117e9f8a2fdfc5e2f47a450cbb7f7911dae818bf36d33b5945adb8f60874` /
`20c3fa6894edba91f8dba387221db179000660c52613f879745cf76268697711`.
The combined relative extension packed/raw SHA256 are
`84ea3710c01a209f2cd3485b19873b95ff1b80a602477d651b1dcc32278b2403` /
`3f658766c4fa5536cc482d5001ad5bb3588260b4faf593a53062a74df18cd850`.

An evidence-recovery correction is also appended at
[MMI1 historical scope correction](../../docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md).
SMP1 had already supplied the one-mode massive inverse and correlated family
transport. MMI1's matrix proof remains valid, but its novelty was overstated.
The gate reduces MMI1 to the actual old SMP outputs at64 coefficient positions;
all agree. All77 old input bindings and its committed bytes are authenticated
without a new scientific replay or substituting current policy bytes. The
missed reuse caused avoidable prior work; algorithm agreement does not turn
that known core into a new physical result. The new neutral-support application
retains its separate scope. No original report, receipt or failure is rewritten.

## Execution, limitations and next action

Primary/replay/gate native0 in37.852143/31.250641/9.576164s afterimports;
20/17/6 samples, private maxima77,557,760/78,483,456/65,040,384B. The post-check
returned0 in3.043622s,2 samples,max57,528,320B. These are sampled observations,
not continuous peaks. Eleven source copies;2170/2178/2189 bindings. Pre-report
packet1,561,956B. All600s/8GiB/350MiB/16MiB limits respected. No scientific
worker or controller failed. Fresh E4 this turn root0,steps0/0/0/0/0/2;
historical custody exit2/seven remains NOTPASS. External before/index/after
seals must preserve all33027 old blobs and both appended scope/claim records.

The selected marginal open-fermion background local gauge and Yukawa inputs
now share the same measured kinetic normalization. This reduces an actual
background dependency, but does not establish full finite chiral restoration,
nonexceptional amplitudes, all external hats, massive matching, quantum source
equivalence, nonlinear products/QAP or measure/Pfaffian phase. Gamma_ref[A]
remains in its pure-background account; external-P2 degree excludes it only
from this calculation. Curvature freedom and physical normalization remain.
Shared action, formal Clifford/dimensional premises, inherited tensors,
software and AI authorship limit independent assurance.

The next high-value question is the remaining closed-fermion finite functional
and its actual Slavnov/phase applicability. First recover the existing
bosonic_fermion_finite_ward and finite_gauge_ward_functional evidence: their
actual-minus-covariant-reference comparison must not be equated with the raw
dimensional-minus-positive-heat member. Reuse existing two-point form factors
before deriving any new closed-loop heat Taylor/power terms. A complete
quadratic gauge/scalar comparison is a sensitive starting point; higher
cubic/quartic companions and parity-odd phase require their own coverage.
The source primitive already retains its hatted auxiliary Euler companion;
re-deriving that algebra alone is not a new quantum construction. Its X_a
are ghost-indexed45-tuples, not constant field-basis rotations.

Both adverse scalar configurations, quartetFAIL, paused flavor, blockedHB1/C5,
all independent finite constants and historical evidence remain. No state,
physical scheme, foundational assumption or protected stage changed. No
agents, branch/worktree, outreach, publication or push. The full Spin(10)xPQ
investigation remains ACTIVE and incomplete; E5/A5 and physical GUT unresolved.
