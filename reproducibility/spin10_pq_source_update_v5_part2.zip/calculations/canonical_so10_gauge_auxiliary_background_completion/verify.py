"""GAB1 compare exact construction/transport, then independently measured finite targets."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');late=packed(HERE/'validation_control_inputs.json.gz');di=packed(HERE/'primary_inputs.json.gz')
units={'aux_F':-1,'aux_L':-s.Rational(1,6),'ferm_F':-s.Rational(1,2),'ferm_L':s.Rational(1,4),'bos_F':-s.Rational(1,2),'bos_L':s.Rational(1,4)}
for k,z in units.items():assert simp(s.sympify(P['units'][k])-z)==0 and simp(s.sympify(R['units'][k])-z)==0,k
construction=0
for key,n,shape in [('rho_H',12,(45,45)),('Phi_diagonal_H',12,(45,45)),('constant_inverse_response',4,(28,28))]:
 assert len(P[key])==len(R[key])==n
 for a,b in zip(P[key],R[key]):
  A,B=dec(a),dec(b);assert A.shape==B.shape==shape;zero(A-B);construction+=A.rows*A.cols
zero(dec(P['full6_green_fixture'])-dec(R['full6_green_fixture']));construction+=28**2
assert construction==52520
for obj in [P,R]:
 for flag in ['pure_gauge_full_filter_identity','first_positive_heat_order_retained','equal_heat_weights_control_insensitive','width_noncommuting_charge_control_nonzero','all12_actual_vector_auxiliary_carriers_match','all12_actual_diagonal_GF_vertices_match','pure_gauge_and_zerojet_tests_insensitive_to_curvature_additions']:assert obj[flag],flag
 for key in ['mixed_orientation_control_changes','early_barred_vector_control_changes','omit_right_heat_control_changes']:assert obj[key]>0,key
 assert obj['bosonic_heat_phase']=='1' and not obj['physical_scheme_adopted']
assert P['curvature_transverse_witness_nonzero_positions']>0 and R['actual_mixed_Lie_positions']==138240
positions=0
for key in ['parts']:
 for family in P[key]:
  for side in ['left','right']:
   for a,b in zip(P[key][family][side],R[key][family][side]):zero(dec(a)-dec(b));positions+=256
for part in ['chi4','log3over2','fixed']:
 for side in ['left','right']:
  for a,b in zip(P['relative_transport'][part][side],R['relative_transport'][part][side]):zero(dec(a)-dec(b));positions+=256
for side in ['left','right']:
 for a,b in zip(P['old_pole_H'][side],R['old_pole_H'][side]):zero(dec(a)-dec(b));positions+=256
assert positions==43008
H=dec(di['Y']['H_new']);T=list(map(dec,di['Y']['Tminus']));TH=project(T,H);current={};rem={};counts={};ncomp=0;total=0
for part in ['chi4','log3over2','fixed']:
 current[part]={};rem[part]={};counts[part]={}
 for side in ['left','right']:
  C=dec(late['kinetic'][part][side]);arr=[];rr=[];nonzero=0
  for h in range(12):
   L=tidy(dec(late['current'][part][side][h])+dec(P['relative_transport'][part][side][h]));charge=TH[h] if side=='left' else -TH[h].T;res=tidy(s.I*L-C*charge);zero(C*charge-charge*C);zero(L+L.H);arr.append(enc(L));rr.append(enc(res));nonzero+=nz(res);ncomp+=256
   if part=='chi4':zero(dec(late['current'][part][side][h])-dec(P['old_pole_H'][side][h]))
  current[part][side]=arr;rem[part][side]=rr;counts[part][side]=nonzero;total+=nonzero
for part in current:
 for a,b in zip(current[part]['left'],current[part]['right']):zero(dec(a).T+dec(b))
assert ncomp==18432
controls={key:sum(nz(dec(z)) for rows in val.values() for z in rows) for key,val in P['parts'].items()}
controls['omit_inverse_placement_log']=sum(nz(dec(z)) for rows in P['old_pole_H'].values() for z in rows)
controls['omit_one_fermion_heat_endpoint']=controls['fermion_heat'];controls['omit_one_boson_heat_endpoint']=controls['boson_heat'];controls['premature_hat0_auxiliary_insertion']=controls['auxiliary_dimensional'];controls['extra_open_line_half']=controls['omit_inverse_placement_log']
for v in controls.values():assert v>0
# Historical scope check: reduce MMI1 to the already qualified SMP1 one-mode
# algebra and compare actual old outputs, without rerunning the old inverse.
assert late['MMI_recipe']['inverse_blocks']['PS']=='(-i*Q*H+B*A*H)*Delta^-1' and late['MMI_recipe']['inverse_blocks']['SS']=='(-i*B*(Q+C*A)+u*A)*Delta^-1'
b,h=s.symbols('b h',real=True);m,mb=s.symbols('m mbar');gb=s.Matrix([[0,1],[1,0]]);chi=s.diag(1,-1);PL=(s.eye(2)+chi)/2;PR=s.eye(2)-PL;A=PL*m+PR*mb;At=PL*mb+PR*m;Q=b*b+h*h;history_positions=0
for sign in [1,-1]:
 gh=sign*chi;B=b*gb;HH=h*gh;basis=[s.eye(2),chi,gb,gh,chi*gb,chi*gh,gb*gh,chi*gb*gh];nums=[-s.I*Q*B+b*b*At,-s.I*Q*HH+B*A*HH,-s.I*Q*HH+HH*A*B,-s.I*B*(Q*s.eye(2)+At*A)+h*h*A]
 for old in late['old_SMP']:
  assert simp(s.sympify(old['denominator_case0'],locals={'b':b,'h':h,'m':m,'mbar':mb})-(Q*Q+b*b*m*mb))==0
  for values,new in zip(old['case0_block_numerator_coefficients'],nums):
   got=sum((s.sympify(z,locals={'b':b,'h':h,'m':m,'mbar':mb})*bas for z,bas in zip(values,basis)),s.zeros(2));zero(got-new);history_positions+=4
assert history_positions==64
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
status='QUALIFIED_FULL_D_GAUGE_AUXILIARY_H_MEMBER_AND_SELECTED_GAUGE_BACKGROUND_HEAT_COMPATIBILITY' if total==0 else 'QUALIFIED_FULL_D_GAUGE_AUXILIARY_H_MEMBER_AND_SCOPED_NONZERO_BACKGROUND_REMAINDER'
recipe={'status':status,'leading_operator':'KBB=-nabla2 delta+Sym(nabla_mu nabla_nu); KBL=-i nabla_mu; KLB=+i nabla_nu; KLL=W','connection':'nabla=partial-g10*rho_H*A_H','rho_H':P['rho_H'],'W':P['W'],'heat':'separate -nabla2 on B and Lambda, F*Kinv*F.T, retain all3 first variations','relative_transport':P['relative_transport'],'selected_g3_background_current':current,'kinetic_remainders':rem,'previous_A0_and_Yukawa_members_preserved':'new independent A_H PP local term; no old coefficient overwritten','physical_scheme_or_historical_unique_reference_adopted':False,'full_quantum_source_phase_QAP_or_massive_matching_proved':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_gauge_background_family.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'status':status,'elapsed_after_imports':time.perf_counter()-tick,'construction_positions_compared':construction,'vector_auxiliary_H_carrier_bridge_positions':48600,'finite_transport_color_positions_compared':positions,'kinetic_current_positions_compared':ncomp,'remainder_nonzero_counts':counts,'total_remainder_nonzero':total,'derived_units':P['units'],'negative_control_changed_positions':controls,'mixed_orientation_control_changes':P['mixed_orientation_control_changes'],'early_barred_vector_control_changes':P['early_barred_vector_control_changes'],'omit_right_heat_control_changes':P['omit_right_heat_control_changes'],'curvature_nonunique_member_limit_preserved':True,'full_D_principal_reference_and_actual_constant_background_vertices_match':True,'historical_SMP_scalar_reduction_positions_compared':history_positions,'MMI_core_interpreted_as_known_inverse_matrix_reexpression':True,'physical_scheme_adopted':False,'full_nonexceptional_background_or_Slavnov_QAP_phase_qualified':False,'new_massive_loop_integrals':0,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','family_sha256':sha256(blob).hexdigest(),'family_raw_sha256':sha256(raw).hexdigest(),'primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
