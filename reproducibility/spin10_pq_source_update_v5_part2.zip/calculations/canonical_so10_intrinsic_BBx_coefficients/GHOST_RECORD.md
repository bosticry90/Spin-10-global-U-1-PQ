# IBB3: complete actual zero-jet ghost BBx contribution

Freeze after IBB2 paired vertex verification. Bind only classical S0/Su
projections from qualified IKG1 and old/probe PGV currents/seagulls, not
its Bx quantum coefficients or a desired scalar translation. Use the new
fresh literal QG seagull checks. Natives deny peers and prior counterterms.

For the ordinary Gaussian -Tr log M, set MB=-i AC_b q.B_b and
MBB=onehalf Gamma_aCBB;cd Bc.Bd. The complete firstu/reference-linear
coefficient consists of the triangle -Tr(G MB G MB G S) and bubble
+Tr(G MBB G S), including all probe/current/scalar placements. At zero
external jets q.e squared averages to1/D; the two -i factors convert the
triangle sign to +. Store full symmetric ordered external colors: the
actual density is sum_cd F_cd,i Bc.Bd xi, not onehalf that sum.

T=Sym_cd Tr[(AC0_c AC0_d)Su_i+(ACu_c AC0_d+AC0_c ACu_d)S0_i].
B=onehalf Tr[Gamma0_cd Su_i+Gammau_cd S0_i].
Derive the paired Grassmann-Hessian Gaussian sign/half independently.
Actual ACu=0 must be checked, not extrapolated to probe seagulls.

Angular coefficients: F2(D)=B, F3(D)=T/D. Heat lengths2m are4/6. The
qualified zero-jet DIM-heat rule gives
 C=chi4(B+T/4)+log(3/2)T/4+T/8.
The last term is -2partial_D(T/D)|4, not a first-momentum heat jet.
No physical finite baseline is chosen. Keep chi4 symbolic/distinct from
b0/kappa, g powers distinct, and retain the common nonexceptional/IR
completion. No isolated scaleless p0 integral or chiral measure claim.

Primary contracts explicit ordered color paths, replay sparse flattened
matrix trace products; compare all45*45*328 positions for both probes,
including zeros and external-color symmetry. Retain triangle/bubble owners
and late analytic angular/DIM assembly. Controls omit either scalar owner,
probe seagull, the action's factor1/2, D jet, or flip Gaussian sign. Report
insensitive controls where structural zeros occur. No unknown fitted input.

Same two300s workers/180s verifier,8GiB sampled/350MiB floor/64MiB packet.
Freeze all input/source/copy hashes before native launch. Exhaustion is
incomplete; preserve exact failures and do not silently extend limits.
This completes the selected GHOST class only; complete bosonic BBx and
Euler/QAP/source reality/E5 and physical viability remain open. No agents,
protected authority/state changes, scheme/benchmark adoption or remote action.
