The first coverage review failed on the auxiliary port label: the immutable
IKS schema names it L, while this new reviewer expected Lambda. Preserve
coverage.py, frozen source/capture and controller failure. coverage_v2.py
uses exactly L in those port comparisons; every vertex-family/word/zero
requirement is unchanged. New separately named manifests/captures/receipt,
same180s/8GiB/350MiB/64MiB limits, no numerical native rerun. This is a
schema-label error, not evidence of a missing action vertex. The corrected
review must still prove actual coverage before a complete BB/X claim.
