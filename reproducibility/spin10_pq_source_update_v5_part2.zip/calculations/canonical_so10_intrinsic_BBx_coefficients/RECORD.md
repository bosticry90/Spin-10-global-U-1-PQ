# IBB2+: actual zero-jet BBx coefficients

Freeze October25,2026 at base61c83647d622ff28aefdf7dd3877d9e21cafd302.
Previous goal turn PROGRESS. Recover clean main/no matching live workers;
State113/34of39,E5/A5 OPEN,custodyexit2/sevenNOTPASS unchanged.

Scientific question: measure the missing complete ordinary zero-jet uBBx
coefficient at one intrinsic GF-reference grade, using IBB1's qualified
54-skeleton reduction. It is required before testing a common scalar Euler
conversion. Bx/potential coefficients cannot supply it. Same original
unshifted SMA/CSW/EDS,A0,constant firstu,all45 colors/328scalars,bothprobes,
symbolic g10,xi,eta_H. Local UV jets use the inherited nonexceptional/common
IR completion, not an isolated scaleless physical trace at p0.

Least expensive prerequisite is the actual missing quartic seagull input.
IBB2 primary differentiates full canonical QG quartic density twice and
retains both external B placements; replay differentiates all four legs
directly. Wick action minus and all time-vector phases are retained. Full
four-Lorentz projection must equal A_abcd delta_internal+H_abcd e e when
the two external vectors have the same polarization e. This completely
determines the rotationally invariant B.B*x zero-jet carrier; no finite
momentum or antisymmetric external-Lorentz structure is being discarded
from that carrier. Keep full ordered external color indices and their
symmetry. Store Gamma4; H_BB(B)=onehalf Gamma4_cd Bc Bd, not Gamma4 itself.
Fresh probe ghost seagulls must match qualified PGV aCBB conventions,
including Grassmann orientation and Wick factors. Old GF ghost seagulls
are qualified reused action inputs, not assumed zero.

Derive physical YM Gamma4 from the adopted curvature: density polarization
of the commutator square versus color-matrix anticommutators must agree.
The scalar vertices remain factorized exact identities from the qualified
covariant kinetic action: Gamma_xx;BcBd=-{Rc,Rd},
Gamma_Ba,xj;Bc,xi=-{Ra,Rc}_ji. Prove by free ordered word polarization
and check the antisymmetric-real-matrix density independently; do not expand
328^2*45^2 entries merely to materialize these identities. No action or
coordinate chart is changed. No expected quantum correction is an input.

Dependent stages are frozen separately after prerequisite verification.
First exploit the full ghost topology at zero external jets: actual
MB=-i AC(q.B), MBB=onehalf Gamma_aCBB B B. Its ordinary Gaussian log has
 -Tr(G MB G MB G S)+Tr(G MBB G S).
With MB's Fourier i factors retained, the triangle angular coefficient
is +Tr(AC_B AC_B S)/D and the bubble +onehalf Tr(Gamma_BB S).
Include both firstu placements and actual scalar S0/Su, all ordered color
and implicit zero positions. If ACu=0 is reused, recheck it from actual
current tables and retain probe seagulls. Compare direct color paths vs
independent flattened matrix trace products, paired graded Hessian Gaussian
sign/half and actual action limits. Determine complete finite DIM-heat
coefficient with each heat length and analytic D numerator before any
counterterm comparison. A nonzero coefficient is not a Slavnov anomaly.

Then derive full bosonic Lorentz-D kernels using the actual B/BB/BX/X
vertices and complete inverse, keeping auxiliary and both mixed endpoints,
both noncommuting UN orders, probe BB/Bnu/Xnu and heat lengths m2..5.
Use universal kernels and ordered sparse products before full tensors.
An incomplete stage never qualifies the complete BBx coefficient. Output
must retain family ownership, parameter degrees and zero complements.

Each paired bounded stage: sequential primary/replay300s after imports,
verifier180s,8GiB sampled-private,350MiB available-pagefile launchfloor.
Whole packet64MiB prospectively accommodates the two-external-color tensor
(45-fold larger carrier than Bx) and independent stage outputs. No dense
unnecessary scalar-rank expansion. Freeze each actual input/source/copy
hash before its computation; verify completed outputs before dependents.
Preserve failures/unfinished captures and sources; no silent input/limit/
acceptance changes or fitting unknown contributions. A later expensive
stage requires a justified new continuation if its boundary is exhausted.

Possible outcomes: complete selected coefficient, structural zero, exact
remainder, underdefined prerequisite or bounded incomplete calculation.
The result can advance the actual quantum-construction dependency, not
establish physical viability/full QAP/E5 or change authority. No partial
scalar translation or scheme installed, chi4/b0/kappa remain distinct.
Shared action/charts/qualified helpers/compiler/Python/libraries/AI author
limit independence. No agents,branch/worktree,push,publication,outreach,
flavor/HB1C5 activation or protected scientific promotion. All historical
evidence and project_state.json remain unchanged.
