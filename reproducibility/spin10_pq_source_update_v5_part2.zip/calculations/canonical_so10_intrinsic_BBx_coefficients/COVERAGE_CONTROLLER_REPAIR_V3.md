V2 coverage preparation stopped before native launch because it tried to
create an already preserved source copy of the unchanged original review
record. Preserve v2 controller/failure. V3 authenticates existing copies
byte-for-byte and only creates absent copies; it does not overwrite them.
The v2 worker and all scientific gates are unchanged. The first v2
preparation manifest still does not exist and is created only once now.
Same180s/8GiB/350MiB/64MiB limits; no failed run counted as PASS.
