# IBB7 coverage audit before completion claim

Freeze after all native family verifiers, independently of the in-flight
BB/X addition. Revisit the actual immutable IKS ordered words/Green paths;
select the BB/X group and classify every actual BB/BBu/X/Xn/Xnu port and
origin. They must all be supplied by IBB3 ghost or IBB4-6 bosonic inputs,
or by the qualified full-symbol quadratic inverse U/N/Nu already reused.
Unexpected ordinary scalar/auxiliary/probe vertices invalidate completion;
do not just ignore them because an evaluated class passed. All748 selected
words must map, including duplicates, cyclic starts and Grassmann signs.
No action coefficient is calculated or inferred from the word counts.

180s review,8GiB sampled,350MiB floor,64MiB packet. Bind inputs/source/copies
before execution. Independent read-only inputs and disjoint coverage_* output
names permit this audit alongside the BB/X addition; neither reads the other's
live files. Final result requires both completed receipts. Preserve a failed
coverage result and narrow any claim if an unprovided input is found.
