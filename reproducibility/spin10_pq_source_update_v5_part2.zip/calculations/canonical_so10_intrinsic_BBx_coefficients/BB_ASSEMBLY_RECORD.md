# IBB7: complete selected BB/X bubble assembly

Prospective dependent stage, launch only after IBB6 paired verification.
Assemble the BB/X term of IBB1, using each qualified vector/probe/D,
scalar-seagull and ghost-seagull owner exactly once. This is the complete
BB/X BUBBLE contribution, not the full BBx coefficient: B/BX bubbles and
B/B/X triangles remain. The measured ghost triangle zero does not eliminate
the latter's bosonic counterparts. Preserve these distinctions in outputs.

F_m(D)=IBB6 vector tensors plus IBB5 scalar F3,-F4 and IBB3 ghost B at m2.
The full selected zero-jet finite conversion is
 chi4*P+log(3/2)F3(4)+log2 F4(4)+J,
 P=sum F_m(4), J=-2partial_D sum F_m(D)|4.
No first-momentum heat derivative is present in this zero-jet carrier.
Keep the four basis tensors chi4,log2,log3,fixed. chi4 remains symbolic and
unrelated to b0/kappa; don't install a partial counterterm or fit a shift.
The local relative construction uses its existing common nonexceptional/
IR completion. A vanishing pole in one subfamily doesn't delete its finite
log heat-length difference. Parameter degrees, all ordered external colors
and scalar zero complements stay. Matrix additions versus disjoint keyed
coordinate additions must agree; preserve source-family ownership.

One300s assembly worker after imports with independent addition checks,
8GiB sampled,350MiB floor,64MiB whole packet, inputs/source/copy hashes frozen
before launch. Completed paired inputs are prerequisites, not permission to
skip checks. Preserve exact failures/unfinished captures. Acceptance remains
bounded mathematical evidence, not fullEuler/QAP/E5/scientific promotion.
