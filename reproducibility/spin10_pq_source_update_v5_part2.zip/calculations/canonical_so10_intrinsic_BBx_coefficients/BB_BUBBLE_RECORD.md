# IBB4: complete BB/X bosonic bubble Lorentz kernels

Freeze after IBB2/3 verification. This is the BB/X member of the complete
IBB1 sum, not the triangle or B/BX member. Reuse only bound arcs/trace4
definitions from IBK2; do not run that worker entry point or import its
quantum coefficients. Zero external jets mean -halfTr(Gbar HBB Gbar HX).
Retain direct/inverse mixed E2/E3 arcs and each heat length, scalar/vector
and both reverse mixed endpoints. No momentum derivative/heat-jet term.

Full actual input classes: old HBB vector YM, old HBB scalar kinetic,
probe HBB vector quartic, X0 mixed Bx, and source-derived Xnu internalBB.
Other BBu/Xn ghost paths are in IBB3. The aligned external polarization
carrier uses HBB vector A delta+H e e; color multiplication later supplies
Gamma4/2. Physical YM H=-A. The scalar HBB is a symmetric K matrix,
K=-{Rc,Rd}/2. The relevant scalar row is n_a^T K R_a x in that order.
No dense scalar rank-four materialization. Xnu contributes D_ab,i delta.

Primary finite matrix traces vs replay closed-index sums establish the
analytic-D angular average (parallel+(D-1)transverse)/D. Closed-vector
Xnu/A terms need all D-2 spectators; retain them before subtraction.
Tests must detect their omission and all heat lengths/endpoint directions.
All kernel cases/coefficient zeros must agree before actual contraction.
The kernels are independent of an expected scalar translation. They do
not supply actual BBx coefficients, a full Euler correction or QAP/E5.

Same two300s/180s,8GiB sampled,350MiB floor,64MiB whole packet. Freeze
inputs/source/copies before native launch; preserve failures unchanged.
Current AGENTS and protected authority34of39/E5 OPEN remain binding.
