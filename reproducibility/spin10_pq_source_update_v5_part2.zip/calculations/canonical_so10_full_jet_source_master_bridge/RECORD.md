# FJB1: complete A0 first-probe source/master bridge through intrinsic1

Prospective at7b81a92e, clean main/no matching workers. Prior goal turn
PROGRESS. Current authority/state unchanged; no agents or remote actions.
Question: does q0G equal stored QG as a local functional when all vector
components and spacetime jets are retained? This is needed before the
regulated u tangent/Hessian can be interpreted. Constant-field UWB and
free principal SMP results alone do not cover nonlinear derivative terms.

Use original643 bosonic/nonminimal field/source pairs, A0, constant probes,
all source degrees0/1/2 and intrinsic degrees0/1. Include all dynamic B
components; no external zero-jet restriction before classical variation.
Positive spacetime jets are independent graded generators. An intrinsic
degree>=2 ideal is stable because the actual operations have no negative
intrinsic coefficients. The actual G/QG depend only on nonminimal sources,
so the physical action's a/Lambda-independent Euler columns suffice;
the scalar potential/fermionic action is not deleted from the theory.

Primary: transport all applicable GF density rows before Euler variation.
Replay: take raw left-jet derivatives, integrate by parts, then transport
the resulting covectors. Both recover full qJa/qJL with their spacetime
derivatives. Scalar/nonminimal field and homogeneous cotangent maps reuse
qualified ISD/USR inputs. Full qB is newly transported from the original
CSW vector maps. Wick the entire density, including time derivatives and
the removed Euler-port field phase. Source derivatives precede restriction.

Each native gets G, actual action/maps/charts and no QG or quantum T/F.
Compare their complete derived q0G polynomials. Only subsequent review
reads the separately frozen QG and performs an exact local comparison.
If densities differ by integration by parts, preserve the exact difference,
derive an explicit local current and check its divergence equals that
difference. A nonzero Euler residual or unmatched current is an unresolved
defect, not a passing first-probe master relation.

Verify types, all four momentum/derivative directions, intrinsic grading,
source phases and required actual source responses. Include sensitive
omission controls where the actual support permits. Tests at selected
momenta cannot establish the polynomial identity. Exact jet equality or
an explicit current implies the polarized two-fluctuation-leg identity
at arbitrary internal momentum; it supplies no continuum trace-domain or
finite-part interchange theorem.

Native300s/role,review180s afterimports,8GiB sampled private,350MiB launch
available-pagefile floor,32MiB packet. Freeze sources/input hashes before
execution and preserve failures/incomplete results. Do not silently expand
resources or change scientific requirements. Current policy governs new
execution; historical contracts and receipts retain their original bytes.

An inherited base classical master/nilpotence premise may yield a u
closure corollary via Jacobi, but it must be identified and scoped; do not
present it as fresh direct q0QG execution. No hatted curvature/source
support assumption is supplied merely by computational agreement. No
quantum remainder is fitted. No full QAP/measure, regulated cancellation,
physical viability, E5/A5 or protected-stage promotion follows. Shared
action, charts, exact ring, algorithms and AI author limit independence.
