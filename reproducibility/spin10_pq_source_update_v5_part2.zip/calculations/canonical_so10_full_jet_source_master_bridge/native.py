from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from functools import lru_cache
from collections import Counter
import gzip,json,os,sys,threading,time
import sympy as s
from jets import *
from coefficient_ring import coefficient,g,xi,eta
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in json.loads((O/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and (p.name.startswith(peer) or p.name.startswith('stored_QG') or p.name.startswith('review_')):raise PermissionError('FJB_NATIVE_TARGET_OR_PEER_DENIED')
        if p.parent.name in ['canonical_so10_remaining_u_contact_vertices','canonical_so10_u_pair_contact_model']:raise PermissionError('FJB_FULL_QG_OR_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
data=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()))
@lru_cache(None)
def co(v):return coefficient(s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}))
xs=data['xs'];Ls=[('b' if i<12 else 'L')+str(i) for i in range(45)];ants=[('bar' if i<12 else 'ub')+str(i) for i in range(45)];cs=['C'+str(i) for i in range(45)]
phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+xs+Ls+cs+ants;ni={n:i for i,n in enumerate(phys)}
raw=data['frame']['field_order'];T={};F={}
for i,j,v in data['frame']['physical_to_raw_inverse']['entries']:T.setdefault(raw[i],[]).append((j,co(v)))
for i,j,v in data['frame']['physical_to_raw_kernel']['entries']:F.setdefault(raw[j],[]).append((i,co(v)))
def split(token):
    n,sep,js=token.partition('__');return n,tuple(int(c) for c in js)
def factor_phase(n,js):
    z=phase(ni[n])
    for mu in js:
        if mu==0:z=times(z,I)
    return z
def transport_word(word,value):
    out={():value}
    for n,js in word:out=mul(out,{((i,js),):v for i,v in T[n]})
    return out
def convert(i):return 643+508+i if i<45 else 643+598+i-45 if i<90 else 643+553+i-90 if i<135 else 553+i-135 if i<180 else 598+i-180 if i<225 else 508+i-225
def unmapped(rows):
    out={}
    for w,v in rows:put(out,tuple((convert(i),()) for i in w),co(v))
    return clean(out)
maps=data['maps'];flows={convert(i):unmapped(z) for i,z in maps['field_maps']}
for c,mat in enumerate(data['R']):
    for i,j,v in mat['entries']:put(flows.setdefault(180+i,{}),((553+c,()),(180+j,())),co(v))
for i,z in maps['source_maps']:flows[convert(i)]=unmapped(z)

# Full vector flow, including the derivative of the ghost.
vector_partition=Counter()
for output,rows in data['vector_field_maps'].items():
    assert output in ni and ni[output]<180
    for row in rows:
        word=[split(n) for n in row['word']]
        if any(n.startswith('A') for n,js in word):vector_partition['A0_excluded']+=1;continue
        assert all(n in ni for n,js in word)
        value=co(row['coefficient'])
        for n,js in word:value=times(value,factor_phase(n,js))
        poly=transport_word(word,value)
        for out,v in F[output]:
            inverse_phase=-phase(out) if phase(out) in [I,-I] else phase(out)
            z=flows.setdefault(out,{})
            for w,c in poly.items():put(z,w,times(c,times(v,inverse_phase)))
        vector_partition['retained_raw']+=1
flows={i:clean(z) for i,z in flows.items()}
print('STAGE fields '+str(time.perf_counter()-tick),flush=True)

# Full GF Euler columns, including derivative terms and both vector fields.
gf={};grad={};partition=Counter()
for row in data['GF']:
    word=[split(n) for n in row['word']]
    if any(n.startswith('A') for n,js in word):partition['A0_excluded']+=1;continue
    assert all(n in ni for n,js in word)
    if not any(n in Ls or n in ants for n,js in word):partition['no_relevant_Euler_port']+=1;continue
    nd=4-sum(dimension(ni[n])+len(js) for n,js in word)
    assert nd>=0
    if nd>1:partition['intrinsic_above1']+=1;continue
    partition['retained_raw']+=1
    value=-co(row['coefficient'])
    for n,js in word:value=times(value,factor_phase(n,js))
    if role=='primary':add(gf,transport_word(word,value))
    else:
        for j,(n,js) in enumerate(word):
            if n not in Ls and n not in ants:continue
            sign=(-1)**(parity(ni[n])*sum(parity(ni[t]) for t,ts in word[:j]))
            # Raw Euler total derivatives precede the constant covector chart.
            term=transport_word(word[:j]+word[j+1:],value*sign)
            term=Ds(term,js)
            for out,v in T[n]:
                z=grad.setdefault(out,{})
                for w,c in term.items():put(z,w,times(c,v)*((-1)**len(js)))
if role=='primary':grad=euler(clean(gf),set(range(508,553))|set(range(598,643)))
grad={i:clean(z) for i,z in grad.items() if clean(z)}
for f,z in grad.items():add(flows.setdefault(NF+f,{}),z,(-1)**parity(f))
flows={i:clean(z) for i,z in flows.items() if clean(z)}
for out,z in flows.items():
    for word,value in z.items():
        assert sum(parity(i) for i,js in word)%2==(parity(out)+1)%2
        assert degree(word,dimension(out)+1) in [0,1],(out,word)
print('STAGE Euler '+str(time.perf_counter()-tick),flush=True)
audit=data['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];lookup={n:i for i,n in enumerate(phys)}
for f,J,h,k in geo['field_source_h_k']:lookup[base[J]]=NF+ni[base[f]]
def density(packet,pdim):
    out={};auditcount=Counter()
    for gp,tokens,ci in packet['monomials']:
        if any(names[i] not in lookup for i,js in tokens):auditcount['A0_excluded']+=1;continue
        word=tuple((lookup[names[i]],tuple(js)) for i,js in tokens)
        nd=degree(word,pdim)
        if nd not in [0,1]:auditcount['other_intrinsic']+=1;continue
        value=Coeff([((gp,xp,ep,mask),Fraction(n,d)) for xp,ep,mask,n,d in packet['coefficients'][ci]])
        value=-value
        for i,js in word:
            value=times(value,phase(i))
            for mu in js:
                if mu==0:value=times(value,I)
        put(out,word,value);auditcount['retained_raw']+=1
    return clean(out),dict(auditcount)
@lru_cache(None)
def jetflow(i,js):return Ds(flows.get(i,{}),js)
def vary(poly,source_terms=True):
    out={}
    for word,value in poly.items():
        prefix=0
        for j,(i,js) in enumerate(word):
            if i>=NF and not source_terms:prefix+=parity(i);continue
            rem=word[:j]+word[j+1:];dr=sum(dimension(k)+len(ks) for k,ks in rem)
            for w,c in jetflow(i,js).items():
                if 4-dr-sum(dimension(k)+len(ks) for k,ks in w) in [0,1]:
                    put(out,word[:j]+w+word[j+1:],times(value,c)*((-1)**prefix))
            prefix+=parity(i)
    return clean(out)
tables={'field_order':phys,'GF_gradient':[[i,encode(z)] for i,z in sorted(grad.items())],
        'operation':[[i,encode(z)] for i,z in sorted(flows.items())],'probes':[]};results=[]
for probe,packet in enumerate(audit['physical_G']):
    G,inv=density(packet,3);qG=vary(G)
    elementary=vary(G,False);control=dict(qG);add(control,elementary,-1);control=clean(control)
    assert control,'Actual source-Euler omission insensitive'
    tables['probes'].append({'G':encode(G),'qG':encode(qG),'source_omission_difference':encode(control)})
    counts=Counter((degree(w,4),sum(i>=NF for i,js in w),sum(len(js) for i,js in w)) for w in qG)
    results.append({'probe':probe,'G_terms':len(G),'qG_terms':len(qG),'input_partition':inv,'qG_intrinsic_source_jet_counts':[[list(k),v] for k,v in sorted(counts.items())],'source_omission_changed_terms':len(control)})
    print('STAGE qG '+str(probe)+' '+str(len(qG))+' '+str(time.perf_counter()-tick),flush=True)
raw=(json.dumps(tables,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
out={'schema':'FJB1_FULL_JET_CLASSICAL_FIRST_PROBE','role':role,'probes':results,'GF_partition':dict(partition),'vector_partition':dict(vector_partition),'GF_gradient_terms':sum(len(z) for z in grad.values()),'operation_terms':sum(len(z) for z in flows.values()),'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
