# FJB2: finite doublet consistency and its applicability boundary

Prospective after the FJB1 native and late comparison completed: both
routes give qG=stored QG exactly through intrinsic1, with all B/jets at A0.
Determine whether finite BV consistency can reduce the next u response,
while retaining the classical curvature and ordinary unprobed breaking.

At finite polynomial/mode order let q0=(Sigma0,.), X_G=(G,.),
H=q0G, A0=(Sigma0,Sigma0)/2. Do NOT assume A0=0. For an arbitrary even
Gamma=Gamma0+rho Gamma_rho+u Gamma_u, define
Delta=(Sigma0+rho G+u H,Gamma)+rho*d_u Gamma. Derive coefficients by left
rho differentiation before the probes are restricted. Verify

 Delta_u=q0 Delta_rho-X_G Delta0+(A0,Gamma_rho).

Use three non-master exact Grassmann fixtures and direct coefficient
extraction versus the component formula. Controls omit curvature, the
unprobed breaking and the u action response; require actual sensitivity.
The shared UWB finite algebra is explicitly reused, not external proof.
No quantum coefficient or desired T/F remainder is read.

For actual application reuse the qualified CSW base master premise and
CPS/SMA hatted support. New FJB1 establishes the needed concrete q0G=QG
coefficient identity. Jacobi gives q0QG=(Ihat,G)=0 in the retained quotient,
since G has only Ja/JL sources and Ihat contains C/P/S with no sources or
a/Lambda. This corollary inherits the base classical premise; it is NOT a
fresh direct evaluation of q0QG. On the bosonic external locus every first
Euler derivative of quadratic-matter Ihat retains a matter variable, so
the curvature bracket with Gamma_rho vanishes after differentiation.
This does not set internal hatted loop insertions to zero.

At a common finite cutoff this supplies a consistency relation. Applying
it to renormalized/local finite parts requires the applicable common domain
and the source/product/variation interchange. Two sequential variations
must not be licensed by a theorem for one variation. If that bridge is
unproved, retain this as a conditional reduction and pursue the direct
ordered u cutoff construction. Do not infer a quantum coefficient from
minus an existing remainder or from classical nilpotence alone.

Native300/review180s afterimports,8GiB sampled/350MiB launchfloor/32MiB
packet. Freeze sources and added inherited dependencies before execution.
Preserve failures. No authority promotion or physical-scheme choice.
