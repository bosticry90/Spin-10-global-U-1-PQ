from pathlib import Path
from fractions import Fraction
from collections import Counter
import json,gzip,time,threading,os
from jets import *
from coefficient_ring import coefficient,g,xi,eta
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tables=load(O/'comparison_tables.json.gz');NF=643
par=lambda i:int(i%NF>=553)
def canon(word):
    odd=[i for i in word if par(i)]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for j,a in enumerate(odd) for b in odd[j+1:])
def putm(out,word,p,value):
    w,sg=canon(word)
    if sg and value:out[w,p]=out.get((w,p),ZERO)+sg*value
def plus(out,z,sg=1):
    for k,v in z.items():out[k]=out.get(k,ZERO)+sg*v
def mm(A,B):
    out={}
    for (w,p),v in A.items():
        for (ww,pp),c in B.items():putm(out,w+ww,tuple(x+y for x,y in zip(p,pp)),times(v,c))
    return clean(out)
def diffm(poly,i):
    out={}
    for (w,p),v in poly.items():
        for j,k in enumerate(w):
            if i==k:
                ww=w[:j]+w[j+1:];sg=(-1)**(par(i)*sum(par(t) for t in w[:j]))
                out[ww,p]=out.get((ww,p),ZERO)+sg*v
    return clean(out)
def variation(poly,flow):
    out={}
    for (w,p),v in poly.items():
        for j,i in enumerate(w):
            for (ww,pp),c in flow.get(i,{}).items():putm(out,w[:j]+ww+w[j+1:],tuple(x+y for x,y in zip(p,pp)),times(v,c)*((-1)**sum(par(t) for t in w[:j])))
    return clean(out)
z=(0,0,0,0)
def mom(*js):return tuple(js.count(i) for i in range(4))
half=Coeff([((0,0,0,0),Fraction(1,2))]);S={};old={};Bonly={};Lonly={}
for m,q in [(0,1),(1,-1)]:
    opp=1-m
    for a0 in range(45):
        L=508+a0;C=553+a0;ant=598+a0
        for mu in range(4):
            i=4*a0+mu
            for nu in range(4):
                j=4*a0+nu
                if mu==nu:
                    for k in range(4):putm(S,(opp*NF+i,m*NF+j),mom(k,k),half)
                putm(S,(opp*NF+i,m*NF+j),mom(mu,nu),-half)
            putm(S,(opp*NF+i,m*NF+L),mom(mu),q*half)
            putm(S,(opp*NF+L,m*NF+i),mom(mu),-q*half)
            old[m*NF+i]={((m*NF+C,),mom(mu)):q*I};Bonly[m*NF+i]=old[m*NF+i]
        putm(S,(opp*NF+L,m*NF+L),z,times(half,coefficient(eta if a0<12 else xi)))
        old[m*NF+ant]={((m*NF+L,),z):I};Lonly[m*NF+ant]=old[m*NF+ant]
        for k in range(4):putm(S,(opp*NF+ant,m*NF+C),mom(k,k),constant(1))
    for i in range(180,508):
        for k in range(4):putm(S,(opp*NF+i,m*NF+i),mom(k,k),half)
S=clean(S);assert not variation(S,old)
baseline_controls=[len(variation(S,Bonly)),len(variation(S,Lonly))];assert all(baseline_controls)
outputs=[];evidence=[]
for probe,row in enumerate(tables['probes']):
    QG=decode(row['stored_QG']);source1={w:v for w,v in QG.items() if len(w)==2 and sum(i>=NF for i,js in w)==1}
    response=euler(source1,set(range(NF,2*NF)))
    flows={};support=Counter()
    for src,poly in response.items():
        f=src-NF
        for w,c in poly.items():
            assert len(w)==1 and w[0][0]<NF
            i,js=w[0];c=c*((-1)**par(f));nd=dimension(f)+1-dimension(i)-len(js)
            assert nd in [0,1]
            support[nd,'B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a']+=1
            for m,q in [(0,1),(1,-1)]:
                factor=c
                for mu in js:factor=times(factor,q*I)
                putm(flows.setdefault(m*NF+f,{}),(m*NF+i,),mom(*js),factor)
    flows={i:clean(p) for i,p in flows.items()}
    direct=variation(S,flows);replay={}
    for i,response_i in flows.items():plus(replay,mm(response_i,diffm(S,i)))
    replay=clean(replay);assert direct==replay
    def encm(poly):return [[list(w),list(p),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (w,p),c in sorted(poly.items())]
    evidence.append({'probe':probe,'linear_field_response':[[i,encm(p)] for i,p in sorted(flows.items())],'free_action_variation':encm(direct)})
    outputs.append({'probe':probe,'linear_response_entries':sum(len(p) for p in flows.values()),'support_per_orientation':[[list(k),v] for k,v in sorted(support.items())],'pairing_preserved':not direct,'variation_terms':len(direct)})
raw=(json.dumps(evidence,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (O/'free_tangent_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'FJB3_ACTUAL_U_FREE_PAIRING_TEST','probes':outputs,'old_free_pairing_preserved':True,'partial_old_tangent_control_terms':baseline_controls,'elapsed_after_imports':time.perf_counter()-tick,'full_regulated_trace_coefficient_claim':False}
with (O/'free_tangent_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
