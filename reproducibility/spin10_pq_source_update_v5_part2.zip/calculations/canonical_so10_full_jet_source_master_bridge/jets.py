"""Exact differential-polynomial operations; jet coordinates are independent."""
from functools import lru_cache
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import Coeff,ZERO,constant,I

NF=643
def parity(i):return int(i>=553) if i<NF else 1-int(i-NF>=553)
def dimension(i):return (2 if 508<=i<553 else 1) if i<NF else 3-dimension(i-NF)
def phase(i):
    if i>=NF:
        f=i-NF
        return -I if 508<=f<553 else I if f<180 and f%4==0 else constant(-1) if f<508 else constant(1)
    return -I if 508<=i<553 else I if i<180 and i%4==0 else constant(1)
@lru_cache(200000)
def times(a,b):return a*b
def canonical(word):
    odds=[t for t in word if parity(t[0])]
    if len(odds)!=len(set(odds)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for j,a in enumerate(odds) for b in odds[j+1:])
def put(out,word,v):
    if not v:return
    w,sg=canonical(word)
    if sg:out[w]=out.get(w,ZERO)+sg*v
def clean(z):return {k:v for k,v in z.items() if v}
def add(out,z,sign=1):
    for w,v in z.items():out[w]=out.get(w,ZERO)+sign*v
def mul(A,B):
    out={}
    for w,v in A.items():
        for ww,c in B.items():put(out,w+ww,times(v,c))
    return clean(out)
def D(poly,mu):
    out={}
    for word,value in poly.items():
        for j,(i,jets) in enumerate(word):
            put(out,word[:j]+((i,tuple(sorted(jets+(mu,)))),)+word[j+1:],value)
    return clean(out)
def Ds(poly,jets):
    for mu in jets:poly=D(poly,mu)
    return poly
def leftjet(poly,token):
    out={}
    for word,value in poly.items():
        for j,t in enumerate(word):
            if t==token:
                w=word[:j]+word[j+1:]
                sign=(-1)**(parity(t[0])*sum(parity(a[0]) for a in word[:j]))
                out[w]=out.get(w,ZERO)+sign*value
    return clean(out)
def euler(poly,ids=None):
    partial={}
    for word,value in poly.items():
        for j,t in enumerate(word):
            if ids is not None and t[0] not in ids:continue
            w=word[:j]+word[j+1:];sign=(-1)**(parity(t[0])*sum(parity(a[0]) for a in word[:j]))
            z=partial.setdefault(t,{});z[w]=z.get(w,ZERO)+sign*value
    out={}
    for (i,jets),z in partial.items():add(out.setdefault(i,{}),Ds(clean(z),jets),(-1)**len(jets))
    return {i:clean(z) for i,z in out.items() if clean(z)}
def degree(word,totaldim):return totaldim-sum(dimension(i)+len(jets) for i,jets in word)
def encode(z):return [[[[i,list(js)] for i,js in w],[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for w,c in sorted(z.items())]
def decode(rows):
    from fractions import Fraction
    return {tuple((i,tuple(js)) for i,js in w):Coeff([(tuple(k),Fraction(n,d)) for k,n,d in cs]) for w,cs in rows}
