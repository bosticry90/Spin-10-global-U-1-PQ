from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/full-jet-source-master-bridge-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(json.loads((O/'review_preparation.json').read_bytes())['input_sha256'])
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['DOUBLET_RECORD.md','doublet.py','run_doublet.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
        bindings[str(p)]=H(p)
    for name in ['calculations/canonical_so10_u_source_ward_bridge/algebra.py','calculations/canonical_so10_chiral_probe_support/RESULT.md','calculations/canonical_so10_chiral_probe_support/DERIVATION.md','calculations/canonical_so10_chiral_probe_support/validation_receipt.json','calculations/canonical_so10_sterile_matter_action/ACTION_V1.md','calculations/canonical_so10_sterile_matter_action/validation_receipt.json']:
        bindings[str(R/name)]=H(R/name)
    dump(O/'doublet_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    result=capture([sys.executable,'-B',str(O/'doublet.py')])
    dump(O/'doublet_capture.json',result);dump(C/'doublet_full_capture.json',result)
    assert result['exit_code']==0 and result['calculation_completed'] and result['post_run_observations_qualified']
    assert json.loads((O/'doublet_result.json').read_bytes())['elapsed_after_imports']<300
except BaseException:
    dump(O/'doublet_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
