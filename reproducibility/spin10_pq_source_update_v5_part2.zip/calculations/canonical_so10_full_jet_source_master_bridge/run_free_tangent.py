from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/full-jet-source-master-bridge-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(json.loads((O/'doublet_preparation.json').read_bytes())['input_sha256'])
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['FREE_TANGENT_RECORD.md','free_tangent.py','run_free_tangent.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
        bindings[str(p)]=H(p)
    for p in [O/'comparison_tables.json.gz',O/'review_result.json',R/'calculations/canonical_so10_source_master_principal_bridge/native.py',R/'calculations/canonical_so10_source_master_principal_bridge/validation_receipt.json']:
        bindings[str(p)]=H(p)
    dump(O/'free_tangent_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    result=capture([sys.executable,'-B',str(O/'free_tangent.py')])
    dump(O/'free_tangent_capture.json',result);dump(C/'free_tangent_full_capture.json',result)
    assert result['exit_code']==0 and result['calculation_completed'] and result['post_run_observations_qualified']
    assert json.loads((O/'free_tangent_result.json').read_bytes())['elapsed_after_imports']<300
except BaseException:
    dump(O/'free_tangent_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
