# Classical first-probe bridge and the remaining ordered u response

## What the new coefficient comparison proves

FJB1 constructs q0G from the actual field rules and Euler columns of the
original action. Sources are varied before restriction. All dynamic B
components and jets remain; only the fixed A0 background and intrinsic
degree>=2 quotient are imposed. Both routes agree exactly with stored QG
as DIFFERENTIAL POLYNOMIALS, not merely after dropping a divergence.
The quotient is stable because every operation coefficient has nonnegative
intrinsic degree. Thus field polarizations, including two fluctuation legs
with arbitrary symbolic loop momentum, preserve this identity. Four
derivative directions remain independent; no momentum axis was sampled.

This freshly checks a concrete previously inherited classical premise.
It does not newly establish the full base classical master theorem or the
common continuum trace domain. The physical/matter potential is irrelevant
to the retained Ja/JLambda Euler columns because it has no a/Lambda
arguments; it has not been removed from the action.

Let A0=(Sigma0,Sigma0)/2. Jacobi gives q0^2 F=(A0,F). Under the inherited
CSW base master premise A0=Ihat, the qualified CPS/SMA conjugate-port
support gives (Ihat,G)=0: Ihat contains C,P,S and hatted derivatives with
no sources/a/Lambda; G's only sources are Ja/JLambda, with no matter or
matter sources. Shared ordinary fields do not supply conjugate ports.
Consequently q0QG=0 in this same quotient follows from FJB1 and Jacobi.
This is an inherited-premise corollary, not a fresh direct q0QG replay.
The full operation remains curved outside this restricted generator class.

## A finite consistency relation cannot silently become a contact theorem

For arbitrary even Gamma=Gamma0+rho Gamma_rho+u Gamma_u, set H=q0G and
Delta=(Sigma0+rho G+u H,Gamma)+rho*d_u Gamma. Left rho differentiation
before restriction gives

 Delta0=q0 Gamma0,
 Delta_rho=Gamma_u-q0 Gamma_rho+X_G Gamma0,
 Delta_u=q0 Gamma_u+X_H Gamma0,

where X_G=(G,.) is even and [q0,X_G]=X_H. Hence

 Delta_u=q0 Delta_rho-X_G Delta0+(A0,Gamma_rho).

FJB2 tests this with non-master source2 actions; omitting curvature, the
unprobed breaking or the u action response is detected. For the actual
bosonic external locus, every first Euler derivative of quadratic-matter
Ihat retains a matter variable, so its curvature bracket vanishes after
the indicated source/field differentiation. This does NOT remove internal
hatted loop insertions or their finite contributions.

The finite identity is a possible independent check of a direct u result.
To infer a renormalized/contact identity from separately extracted heat
finite parts requires the correct common variation/product domain. A
theorem for one variation does not by itself license two sequential
insertions. Keep this applicability issue explicit rather than define an
unknown quantum term as minus a desired remainder.

## Which free-root cancellation survives

Write V=V0+u H_u and M=M0+u M_u. UWB's finite ordered cutoff family has

 C_n^u=(-1)^n STr[(G0 V0)^n M_u
       +sum_(j=0)^(n-1) (G0 V0)^j G0 H_u (G0 V0)^(n-1-j) M0],

with heat factor E^n-E^(n+1). SMP's qualified finite Gaussian argument
proves STr[(G0 V)^n M_f]=0 for the COMPLETE original free tangent M_f
and arbitrary even graded Hessian V. Differentiating that polynomial
identity in u removes the entire H_u-insertion sum with root M_f.
Neither mixed endpoint alone is zero; fresh partial controls give360
terms each. This is a finite pairing/coefficient argument, not arbitrary
cyclicity of a continuum finite-part trace.

The same cancellation cannot be transferred to M_u's constant linear
part. FJB3 derives that part from actual source differentiation of QG and
finds a nonzero variation of the fixed reference action for BOTH probes.
Its input blocks are B/Lambda at intrinsic0, plus scalar x at intrinsic1
for the broken probe. Literal variation, Euler contraction and a separate
analytic ghost-Euler route agree on the whole nonzero polynomial. Thus
the pairing-preservation premise used in SMP is false for this tangent.
This does not prove its complete regulated trace is nonzero.

At the retained T target the positive grades are (u,nu,Ja,C,x), total5;
at F they are (u,nu,JLambda,C,C,x), total6. The resummed G0 has grade0;
all remaining eligible vertices have positive grade, as established in
UOR/USR from the actual action. M_u and H_u each consume u. The complete
original-free-root H_u groups vanish as above. Every other M0 root has
positive grade. Thus the surviving T words have at most4 heat edges and
F words at most5. In the existing adjacent heat-length normalization,

 [log5]Cutoff_T=C4_T,
 [log5]Cutoff_F=C4_F-C5_F.

The F fifth-edge contribution must remain. FJB3 invalidates a proposed
justification for deleting the M_u free root; it does not assert C5_F is
nonzero or complete this contraction. Source-dependent tangents and all
H_u/source responses remain in the original expression. Establish their
applicable first-variation trace domain and evaluate the ordered C4/C5
groups from actual matrices. A finite doublet consistency relation may
check the result only within a demonstrated common coefficient domain.
