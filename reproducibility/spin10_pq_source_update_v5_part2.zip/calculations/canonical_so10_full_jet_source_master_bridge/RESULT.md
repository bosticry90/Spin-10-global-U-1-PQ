# Full derivative master bridge verified; the u free root must remain

The actual first-probe relation q0G=QG now agrees coefficientwise with all
dynamic vector components and spacetime derivatives retained at A0,
through intrinsic degree1. A second result shows that the new u tangent
does NOT preserve the fixed Gaussian pairing, so the original free-root
zero theorem cannot be applied to it. These results justify the next
ordered u calculation without supplying or fitting its quantum answer.

## Evidence

Two native routes independently assemble full GF Euler columns: transport
the density then differentiate, versus differentiate raw density then
transport the covectors. They use qualified scalar/nonminimal maps and
newly transport all3724 raw vector-flow rows. All29244 A0 GF rows remain,
giving79865 gradient terms and108252 operation terms. Source degrees0/1/2
remain, as do independent jets in all four directions.

Native calculation datasets contain G and no QG or quantum remainder.
Original full-input and target bytes are hashed for custody, not parsed
as native operands. Only the later comparison reads stored QG. The
complete derived polynomials agree:

| Probe | G terms | q0G=QG nonzero terms | Density difference | Source-response omission changes |
| --- | ---: | ---: | ---: | ---: |
|0|144|252|0|6844|
|1|4560|86821|0|230605|

The comparison includes implicit zeros. No integration-by-parts correction
was needed. The fallback current constructor was not exercised; no general
homotopy implementation is qualified. Probe1 retains1705 quadratic-source terms. Its intrinsic1
component includes10304 BBx,1184 derivative-Bx,5248 Ca x,296 Lambda x and
296 Ja x terms. The1072 intrinsic>=2 input rows are explicitly outside
this quotient; they are not declared zero in the full theory.

Under the separately inherited CSW base master premise and qualified
CPS/SMA hatted support, Jacobi then gives q0QG=(Ihat,G)=0 in this quotient.
This corollary is derived, not a fresh direct q0QG computation. Existing
full-master statements in CPS are preserved; FJB adds model-specific
coefficient evidence for an inherited premise rather than new physical
foundations or a quantum-restoration theorem.

FJB2 independently compares finite probe-coefficient extraction and the
curved consistency formula

 Delta_u=q0 Delta_rho-X_G Delta0+(A0,Gamma_rho).

Three exact source2/non-master fixtures agree. Omitting curvature,
unprobed breaking or u action response changes50/57/48 terms respectively.
These are finite algebra controls. Their regulator-removal/contact
applicability is explicitly not supplied by this calculation.

## The consequential negative result

The source-free linear u field response is extracted AFTER differentiating
the actual QG sources. Its reference-action variation is nonzero:

| Probe | Response entries, paired modes | Pairing-defect terms | Pairing preserved? |
| --- | ---: | ---: | --- |
|0|120|480|No|
|1|922|3688|No|

Per orientation the unbroken response has48 B and12 Lambda entries.
The broken response has132 B,33 Lambda and296 intrinsic1 scalar entries.
Literal odd variation and Euler contraction agree. Separate review recovers
the response directly from QG source monomials, then reconstructs the
entire defect using the analytic ghost Euler column p^2 C(-p), without
constructing or differentiating the full free density. The original
complete free BRST tangent still gives zero; omitting either of its mixed
blocks gives360 nonzero terms. No physical reference or scheme is changed.

## Focused result-to-claim assessment

**Supported claim.** The classical derivative/source prerequisite is now
checked in a materially larger domain than UWB's constant-field module.
The u root has a demonstrably different Gaussian property from the
original free BRST root. The original complete-free-root H_u insertion
sum can still be removed by differentiating SMP's arbitrary-Hessian
polynomial identity; the u free root cannot be removed on that basis.

**Limits and alternatives.** A nonzero pairing defect does not establish
a nonzero full heat-trace coefficient, an infrared obstruction or anomaly.
Other ordered terms may cancel it. The correct retained formal log5
targets are C4_T and C4_F-C5_F. No actual u C4/C5 color tensor or finite
loop coefficient has been calculated here. The finite doublet relation
is a control, conditional on an applicable common finite-part/product
domain if used after regulator removal. One-variation trace theorems
do not automatically license multiple insertions.

**Significance and AI limits.** This work replaces an inherited classical
premise with a concrete differentiated-action check, and rejects an
unjustified transfer of a vanishing theorem. Different transport,
variation and analytic-Euler routes test implementation errors while
sharing the action, charts, exact ring, software and AI author. No
external validation, formal proof-assistant result or empirical evidence
is claimed. The coefficient counts are not completion percentages.

**Next discriminating action.** Construct the model-specific ordered u
cutoff C4/C5 family with the actual free and source-dependent tangents,
H_u legs and fixed-reference factors. Check the first-variation trace/IR
hypotheses for those actual blocks, then select a bounded full required
class or witness with an independent calculation. Keep C5_F and all
correlated source responses until an applicable identity or calculation
disposes of them. Do not use minus the known T/F remainder as an operand.

## Validation and preservation

Native primary/replay88.4283/93.6746s;late comparison12.8698s;finite
doublet0.0670s;free-tangent1.3500s;final review0.8933s afterimports. All
completed within frozen300/180s limits. Largest sampled private allocation
1493348352B,not continuous peak. Packet6594453B before reports. Full
sources,captures,inputs and controls are preserved; no native failed.
Read-only lookup/display errors are recorded separately, not scientific
failures. E4 and byte-custody outcomes are in their actual captures/seal.

Authority34/39,state113,E5/A5 OPEN and custody exit2/seven unresolved remain.
No foundation,benchmark,scheme,physical normalization,protected stage or
remote/publication action changed. chi4,b0,kappa and infrared freedoms
stay distinct. Full investigation remains active and incomplete.
