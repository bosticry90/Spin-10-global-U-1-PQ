# FJB3: actual u free tangent versus fixed Gaussian pairing

Prospective after FJB1/2. The full q0G=QG bridge now permits extraction of
the actual u field tangent. Test whether its constant linear part preserves
the fixed free Gaussian pairing. SMP's complete original free q0 tangent
does preserve that pairing; this does not imply the new u tangent does.
Its use as an automatic free-root zero would otherwise be unjustified.

Extract q_u phi=(-1)^p Euler_J QG from the authenticated classical QG
BEFORE source restriction, then keep the source-free linear field response.
Keep all643 physical fields and all four symbolic momentum components,
both opposite modes, intrinsic0/1. Sources2 are not discarded globally;
they cannot contribute to this specific source-free linear tangent after
the required derivative. Retain separate B,Lambda,scalar input blocks.

Use the exact fixed free action already constructed/checked in SMP1:
transverse B kinetic, B/Lambda mixing, actual eta_H/xi Lambda width,
ghost Laplacian and scalar identity kinetic. This is a mass-independent
reference test, not a new physical quadratic action or scheme. Primary
literal odd Leibniz variation versus replay Euler-gradient contraction
must agree coefficientwise. Recover zero for the COMPLETE old free
tangent and nonzero omissions of its two mixed blocks as sensitivity
controls. Measure the u variation without presuming zero or nonzero.

A nonzero variation disproves the pairing-preservation premise for this
tangent. It does not demonstrate a nonzero complete heat-trace coefficient,
an infrared failure, anomaly or E5 obstruction. Keep the actual u root
and source/interaction responses in the ordered regulator expression.
The old free-root theorem can still be differentiated with respect to
an arbitrary even Hessian perturbation for its original fixed tangent.

Native300s/review180s,8GiB sampled/350MiB launchfloor/32MiB packet. Freeze
sources, original SMP construction and its receipt before execution. No
quantum T/F target or finite normalization is an input. Shared ring,
action, reference conventions and AI authorship limit independence.
