from pathlib import Path
from fractions import Fraction
import sys,json,time,threading,os
O=Path(__file__).resolve().parent
sys.path.insert(0,str(O.parent/'canonical_so10_u_source_ward_bridge'))
from algebra import Algebra
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
odd={2,3,4,5,9};a=Algebra(lambda i:int(i in odd));pairs=list(zip(range(4),range(4,8)))
def bracket(f,g):return a.bracket(f,g,pairs)
def poly(words,seed):
    z={}
    for j,w in enumerate(words):a.put(z,w,Fraction(seed+j,j%3+1))
    return a.clean(z)
def zero_probes(z):return {w:v for w,v in z.items() if 8 not in w and 9 not in w}
out=[]
for seed in (2,3,5):
    S=poly([(0,0),(1,1),(2,3),(4,2,0,0),(5,3,1),(7,1),(6,2,3),(7,7,0),(7,4,2,1),(4,5,2,3)],seed)
    G=poly([(3,1),(7,5,0),(4,0,1),(6,2,0)],seed+1)
    H=bracket(S,G);A=a.scale(bracket(S,S),Fraction(1,2))
    gamma0=poly([(0,0,1),(7,7,0),(4,5,2,3),(6,2,3),(7,4,2,1)],seed+2)
    gammar=poly([(4,0),(5,1),(7,3),(6,2,0),(3,0,1)],seed+3)
    gammau=poly([(1,1),(7,7),(4,2,1),(5,3,0)],seed+4)
    rho={(9,):1};u={(8,):1}
    Sext=a.add(S,a.mul(rho,G),a.mul(u,H))
    Gamma=a.add(gamma0,a.mul(rho,gammar),a.mul(u,gammau))
    assert all(sum(a.parity(i) for i in w)%2==0 for w in Sext)
    assert all(sum(a.parity(i) for i in w)%2==0 for w in Gamma)
    Delta=a.add(bracket(Sext,Gamma),a.mul(rho,a.diff(Gamma,8)))
    D0=zero_probes(Delta);Dr=zero_probes(a.diff(Delta,9));Du=zero_probes(a.diff(Delta,8))
    component_r=a.add(gammau,a.scale(bracket(S,gammar),-1),bracket(G,gamma0))
    component_u=a.add(bracket(S,gammau),bracket(H,gamma0))
    assert Dr==component_r and Du==component_u
    qDr=bracket(S,Dr);GD0=bracket(G,D0);curvature=bracket(A,gammar)
    rhs=a.add(qDr,a.scale(GD0,-1),curvature)
    assert Du==rhs
    controls={'omit_curvature':len(curvature),'omit_unprobed_breaking':len(GD0),
              'omit_u_action_response':len(bracket(H,gamma0))}
    assert all(controls.values()),controls
    out.append({'seed':seed,'Delta_u_terms':len(Du),'Delta_rho_terms':len(Dr),'sensitive_control_terms':controls})
result={'schema':'FJB2_FINITE_CURVED_DOUBLET_CONSISTENCY','fixtures':out,'classical_quantum_limit_interchange_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'doublet_result.json').open('xb') as f:f.write((json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);timer.cancel()
