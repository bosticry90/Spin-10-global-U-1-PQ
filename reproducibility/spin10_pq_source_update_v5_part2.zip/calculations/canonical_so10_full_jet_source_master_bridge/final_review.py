from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,gzip,time,threading,os
from jets import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for p,h in json.loads((O/'final_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
qg=load(O/'comparison_tables.json.gz')['probes'];free=load(O/'free_tangent_tables.json.gz')
def decmode(rows):return {(tuple(w),tuple(p)):Coeff([(tuple(k),Fraction(n,d)) for k,n,d in cs]) for w,p,cs in rows}
def canon(word):
    pp=lambda i:int(i%NF>=553)
    odd=[i for i in word if pp(i)]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for j,a in enumerate(odd) for b in odd[j+1:])
def putmode(out,w,p,v):
    w,sg=canon(w)
    if sg:out[w,p]=out.get((w,p),ZERO)+sg*v
checks=[]
for probe,(Q,F) in enumerate(zip(qg,free)):
    expected={}
    for w,c in decode(Q['stored_QG']).items():
        if len(w)!=2 or sum(i>=NF for i,js in w)!=1:continue
        src=[t for t in w if t[0]>=NF][0];field=[t for t in w if t[0]<NF][0]
        assert NF+598<=src[0]<2*NF and not src[1],(src,field)
        f=src[0]-NF;i,js=field
        for m,q in [(0,1),(1,-1)]:
            value=-c
            for mu in js:value=times(value,q*I)
            pp=tuple(js.count(mu) for mu in range(4))
            putmode(expected.setdefault(m*NF+f,{}),(m*NF+i,),pp,value)
    expected={i:clean(z) for i,z in expected.items()}
    actual={i:decmode(rows) for i,rows in F['linear_field_response']}
    assert actual==expected
    # Independent analytic ghost-Euler route: E_a(m)=p^2 C(-m).
    # No construction/differentiation of the full reference density here.
    variation={}
    for out,poly in expected.items():
        m,f=divmod(out,NF);ghost=(1-m)*NF+553+f-598
        for (w,p),c in poly.items():
            for mu in range(4):
                pp=list(p);pp[mu]+=2;putmode(variation,w+(ghost,),tuple(pp),c)
    variation=clean(variation)
    assert variation==decmode(F['free_action_variation'])
    assert variation
    checks.append({'probe':probe,'response_entries':sum(len(z) for z in expected.values()),'pairing_defect_terms':len(variation),'independent_analytic_ghost_Euler_route_equal':True})
assert json.loads((O/'review_result.json').read_bytes())['all_functional_identities']
fixture=json.loads((O/'doublet_result.json').read_bytes())
assert all(all(v['sensitive_control_terms'].values()) for v in fixture['fixtures'])
for n in ['primary','replay','review','doublet','free_tangent']:
    c=json.loads((O/(n+'_capture.json')).read_bytes())
    assert c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
out={'schema':'FJB_FINAL_BOUNDED_REVIEW','free_tangent_checks':checks,'all_completed_scopes_verified':True,'full_quantum_or_trace_limit_claim':False,'scientific_acceptance':'NOT_PERFORMED','elapsed_after_imports':time.perf_counter()-tick}
with (O/'final_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
