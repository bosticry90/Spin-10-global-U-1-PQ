from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import gzip,json,os,threading,time
from jets import *
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for p,h in json.loads((O/'review_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
p,r=(load(O/(role+'_tables.json.gz')) for role in ['primary','replay'])
assert p==r,'Complete native tables disagree'
data=load(O/'primary_inputs.json.gz');packets=load(O/'stored_QG_inputs.json.gz')
names=data['audit']['names'];geo=data['audit']['geometry'];old=geo['names'];phys=p['field_order'];ni={n:i for i,n in enumerate(phys)};lookup=dict(ni)
for f,J,h,k in geo['field_source_h_k']:lookup[old[J]]=NF+ni[old[f]]
def expected(packet):
    out={};partition=Counter()
    for gp,tokens,ci in packet['monomials']:
        if any(names[i] not in lookup for i,js in tokens):partition['A0_excluded']+=1;continue
        word=tuple((lookup[names[i]],tuple(js)) for i,js in tokens)
        if degree(word,4) not in [0,1]:partition['other_intrinsic']+=1;continue
        value=Coeff([((gp,xp,ep,mask),Fraction(n,d)) for xp,ep,mask,n,d in packet['coefficients'][ci]])
        value=-value
        for i,js in word:
            value=times(value,phase(i))
            for mu in js:
                if mu==0:value=times(value,I)
        put(out,word,value);partition['retained_raw']+=1
    return clean(out),dict(partition)
def current_for(poly):
    currents=[{} for _ in range(4)]
    groups={}
    for w,v in poly.items():groups.setdefault(len(w),{})[w]=v
    for N,z in groups.items():
        assert N>0
        partial={}
        for word,value in z.items():
            for j,t in enumerate(word):
                if not t[1]:continue
                sign=(-1)**(parity(t[0])*sum(parity(a[0]) for a in word[:j]))
                ww=word[:j]+word[j+1:];out=partial.setdefault(t,{})
                out[ww]=out.get(ww,ZERO)+sign*value
        inv=Coeff([((0,0,0,0),Fraction(1,N))])
        for (i,js),P in partial.items():
            for j,mu in enumerate(js):
                differentiated=Ds(clean(P),js[:j])
                for word,value in differentiated.items():put(currents[mu],((i,js[j+1:]),)+word,times(value,inv)*((-1)**j))
    return [clean(z) for z in currents]
checks=[];evidence={'probes':[]}
for index,packet in enumerate(packets):
    target,partition=expected(packet);native=decode(p['probes'][index]['qG']);difference=dict(native);add(difference,target,-1);difference=clean(difference)
    E=euler(difference)
    currents=current_for(difference) if not E else [{} for _ in range(4)]
    divergence={}
    for mu,z in enumerate(currents):add(divergence,D(z,mu))
    reconstruction=dict(divergence);add(reconstruction,difference,-1);reconstruction=clean(reconstruction)
    evidence['probes'].append({'stored_QG':encode(target),'density_difference':encode(difference),'Euler_residual':[[i,encode(z)] for i,z in sorted(E.items())],'current':[encode(z) for z in currents],'current_reconstruction_residual':encode(reconstruction)})
    checks.append({'probe':index,'qG_terms':len(native),'stored_QG_terms':len(target),'density_difference_terms':len(difference),'Euler_residual_terms':sum(len(z) for z in E.values()),'current_terms_by_mu':[len(z) for z in currents],'current_reconstruction_residual_terms':len(reconstruction),'input_partition':partition,'functional_identity':not E and not reconstruction})
    print('STAGE comparison '+str(index)+' '+str(checks[-1]),flush=True)
raw=(json.dumps(evidence,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (O/'comparison_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'FJB1_LATE_MASTER_COMPARISON','native_full_tables_equal':True,'checks':checks,'all_functional_identities':all(z['functional_identity'] for z in checks),'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED','continuum_trace_or_quantum_restoration_claim':False}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
