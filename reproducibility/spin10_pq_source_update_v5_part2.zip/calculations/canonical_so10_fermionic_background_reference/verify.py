"""FBR1 separate actual coefficient, background-frame and construction gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz');bos=packed(HERE/'bosonic_member_inputs.json.gz')
zero(dec(P['background_old_from_new'])-dec(R['background_old_from_new']));H=dec(d['Y']['H_new']);Qraw=dec(d['Qraw']);LH=dec(P['background_old_from_new']);zero(Qraw[:,:12]*LH-H)
positions=0
for key in ['carrier_P','carrier_S']:
 assert len(P[key])==len(R[key])==12
 for a,b in zip(P[key],R[key]):
  A,B=dec(a),dec(b);assert A.shape==B.shape==(64,64);zero(A-B);zero(A-A.H);positions+=64**2
for key in ['current_P','current_S']:
 assert len(P[key])==len(R[key])==12
 for pp,rr in zip(P[key],R[key]):
  assert len(pp)==len(rr)==4
  for a,b in zip(pp,rr):
   A,B=dec(a),dec(b);assert A.shape==B.shape==(64,64);zero(A-B);zero(A+A.T);positions+=64**2
assert positions==491520
for a,b in zip(P['T_H'],R['T_H']):zero(dec(a)-dec(b))
for obj in [P,R]:
 assert obj['mixed_Lie_positions']==138240 and obj['scalar_background_bridge_positions']==1291008 and obj['inert_auxiliary_actual_H_failure_count']==12
 assert obj['generic_flat_symbol_and_current_transpose_checks'] and obj['source_pullback_unchanged'] and obj['first_pure_gauge_ordered_filter_identity']
 assert obj['paired_mode_auxiliary_Pfaffian_ratio']=='4/5' and obj['wrong_right_heat_equal_weights_insensitive'] and obj['equal_heat_radius_limit']=='t*exp(-t*b)'
 assert obj['quantum_BRST_auxiliary']=='qS=0_UNCHANGED' and obj['physical_Nambu_antifield_copies']==1 and obj['local_only_no_analytic_trace_or_phase_theorem']
 assert not any(obj[k] for k in ['finite_background_loop_coefficient_computed','auxiliary_background_factor_discarded','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
assert P['wrong_right_heat_nonzero_fixture_positions']>0 and R['wrong_right_heat_nonzero_physical4D_fixture']
assert P['wrong_same_carrier_actual_H_sensitive']==R['wrong_same_carrier_actual_H_sensitive'] and any(P['wrong_same_carrier_actual_H_sensitive'])
assert bos['primary']['explicit_covariant_operator']==bos['replay']['explicit_covariant_operator'] and len(bos['primary']['field_order'])==643
for obj in bos.values():assert digest(Path(obj['path']))==obj['sha256']
# Check the two independent operator-word coefficients of the ordered heat
# variation, without invoking any infinite trace cyclicity.
f,h=s.symbols('F_p F_r');left=s.expand((f-h)*f+f*h-f*f);right=s.expand(-f*h+h*(f-h)+h*h);assert left==right==0
for a,b in zip(P['carrier_P'],P['carrier_S']):assert dec(a).shape==dec(b).shape==(64,64)
recipe={'definition':'old643_covariant_member(Aold=LH*Anew) direct_sum massless_SMA_candidate_covariant_block','bosonic_member':bos['primary'],'background_old_from_new':P['background_old_from_new'],'fermion_H_carrier_P':P['carrier_P'],'fermion_H_carrier_S':P['carrier_S'],'ordinary_reference_currents_P':P['current_P'],'ordinary_reference_currents_S':P['current_S'],'formal_hatted_reference_current':'-i*Ctot*Gammahat_PS*diag(A_H,B_H):PS=hatGamma*B_H,SP=hatGamma*A_H','heat_domain':'P_X=-nabla_X^2,X=diag(A,B)','heat_cotangent':'P_Xswap=-nabla_Xswap^2; Gaussian right heat is F_X.T','filtered_inverse':'F_X*Dcov_inverse*F_Xswap*C_inverse','one_background_derivative':'deltaF*G*Fdual-F*G*deltaD*G*Fdual+F*G*deltaFdual; Duhamel on each heat','auxiliary_factor':'Pf(C barGamma nabla_B[A])/Pf(C barGamma partial) is background dependent; any normalized quotient must be explicitly declared','qS':'0 unchanged','physical_scheme_adopted':False,'historically_unique_reference_recovered':False,'finite_loop_or_measure_phase_theorem':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'candidate_background_reference.json.gz').open('xb') as f0:f0.write(blob)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_EXPLICIT_FERMIONIC_BACKGROUND_REFERENCE_AND_FIRST_POSITIVE_HEAT_VARIATION_NOT_ADOPTED_SCHEME','elapsed_after_imports':time.perf_counter()-tick,'physical_carrier_current_positions_compared':positions,'scalar_H_background_chart_bridge_positions':1291008,'mixed_H_full45_Lie_positions':138240,'all12_actual_H_generators_and_transpose_currents_checked':True,'old643_witness_preserved_with_explicit_background_chart_map':True,'flat_SMA_operator_and_single_source_pullback_preserved':True,'auxiliary_background_carrier_forced_in_fixed_block_diagonal_class':True,'background_member_unique_or_physically_adopted':False,'inert_auxiliary_background_failures':12,'same_carrier_control_sensitive_H_directions':sum(bool(v) for v in P['wrong_same_carrier_actual_H_sensitive']),'same_carrier_control_insensitive_H_directions':sum(not v for v in P['wrong_same_carrier_actual_H_sensitive']),'wrong_right_heat_nonzero_fullhat_fixture_positions':P['wrong_right_heat_nonzero_fixture_positions'],'equal_heat_weight_control_insensitive':True,'ordered_first_positive_heat_variation_and_pure_gauge_identity':True,'paired_mode_auxiliary_Pfaffian_ratio':'4/5','auxiliary_background_factor_discarded':False,'candidate_required_auxiliary_reference_quotient_exposed_not_adopted':True,'formal_full_reference_coordinates':1027,'strict4D_interacting_coordinates_after_explicit_quotient':835,'finite_background_loop_coefficient_computed':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','candidate_sha256':sha256(blob).hexdigest(),'candidate_raw_sha256':sha256(raw).hexdigest(),'primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
