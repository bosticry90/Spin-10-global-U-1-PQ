"""FBR1 actual split-C covariance and directly constructed P/S currents."""
from data import *
from collections import defaultdict
tick=begin('primary');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
g=[s.kronecker_product(z,s.eye(2)) for z in g8];C=s.kronecker_product(g8[0]*g8[2]*g8[5],pa[1]);chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL;Z=s.zeros(16);R=block(PL,PR,-PR,-PL);Ri=block(PL,-PR,PR,-PL)
d=packed(HERE/'primary_inputs.json.gz');zero(R-dec(d['SMA']['R']));zero(Ri-dec(d['SMA']['R_inverse']));zero(s.SparseMatrix.hstack(PL,-PR)-dec(d['SMA']['source_pullback']))
t=s.Matrix(2,2,s.symbols('t0:4'));I2=s.eye(2);A=s.kronecker_product(PL,t)-s.kronecker_product(PR,t.T);B=s.kronecker_product(PR,t)-s.kronecker_product(PL,t.T);zero(s.kronecker_product(C.inv(),I2)*A.T*s.kronecker_product(C,I2)+B)
X=block(A,s.zeros(32),s.zeros(32),B);Xs=block(B,s.zeros(32),s.zeros(32),A);CC=s.diag(s.kronecker_product(C,I2),s.kronecker_product(C,I2));zero(X.T*CC+CC*Xs)
GG=[s.diag(s.kronecker_product(z,I2),s.kronecker_product(z,I2)) for z in g[:4]]+[block(s.zeros(32),s.kronecker_product(z,I2),s.kronecker_product(z,I2),s.zeros(32)) for z in g[4:]]
for gam in GG:zero(gam*X-Xs*gam);zero((CC*gam*X).T+CC*gam*X)
for i in range(6):
 for j in range(i,6):zero(GG[i]*GG[j]+GG[j]*GG[i]-2*int(i==j)*s.eye(64))
# The hatted intertwining equation determines the auxiliary background carrier.
ht=s.kronecker_product(g[4],I2);zero(ht.inv()*B*ht-B)
inert=block(A,s.zeros(32),s.zeros(32),s.zeros(32));inertSharp=block(B,s.zeros(32),s.zeros(32),s.zeros(32));assert nz(GG[4]*inert-inertSharp*GG[4])>0
same=block(A,s.zeros(32),s.zeros(32),A);sameSharp=block(B,s.zeros(32),s.zeros(32),B);assert nz(GG[4]*same-sameSharp*GG[4])>0
print('STAGE SPLIT_SMA_FLAT_COVARIANCE_AND_FORCED_AUXILIARY_CARRIER',flush=True)
T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);zero(H.T*H-s.eye(12));TH=[tidy(sum((H[a,h]*T[a] for a in range(45)),s.zeros(16))) for h in range(12)]
Qraw,Qi=map(dec,[d['Qraw'],d['Qi']]);zero(Qraw*Qi-s.eye(45));inject=tidy(Qi*H);zero(inject[12:,:]);LH=tidy(inject[:12,:]);zero(Qraw[:,:12]*LH-H);assert LH.det()!=0
oldrho,newrho=scalar_frames(d)
for h in range(12):zero(sum((LH[a,h]*oldrho[a] for a in range(12) if LH[a,h]),s.SparseMatrix(328,328,{}))+sum((H[a,h]*newrho[a] for a in range(45) if H[a,h]),s.SparseMatrix(328,328,{})))
f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,s.sympify(z)))
for h,th in enumerate(TH):
 zero(th-th.H)
 for a in range(45):
  target=s.zeros(16)
  for b in range(45):
   if H[b,h]:
    for e,z in f[b,a]:target+=H[b,h]*z*T[e]
  zero(th*T[a]-T[a]*th-s.I*target)
for h in range(12):
 for j in range(12):assert simp(s.trace(TH[h]*TH[j])-2*int(h==j))==0
L=s.diag(1,1,0,0);Q=s.eye(4)-L;eps=s.Matrix([[0,1],[-1,0]]);C4=s.diag(eps,-eps);IC=s.eye(16);XP=[];XS=[];JP=[];JS=[]
for th in TH:
 ap=tidy(s.kronecker_product(L,th)-s.kronecker_product(Q,th.T));as0=tidy(s.kronecker_product(Q,th)-s.kronecker_product(L,th.T));XP.append(enc(ap));XS.append(enc(as0));JP.append([]);JS.append([])
 for gam in g4:
  for charge,slot in [(ap,JP[-1]),(as0,JS[-1])]:
   current=tidy(-s.I*s.kronecker_product(C4*gam,IC)*charge);zero(current+current.T);slot.append(enc(current))
print('STAGE ALL12_ACTUAL_H_CARRIERS_CURRENTS_AND_540_MIXED_LIE_CHECKS',flush=True)
# First pure-gauge heat variation on a full-hat massless reference fixture.
toy=s.diag(1,2);a=A.subs(dict(zip(s.symbols('t0:4'),list(toy))));b=B.subs(dict(zip(s.symbols('t0:4'),list(toy))));x=block(a,s.zeros(32),s.zeros(32),b);xs=block(b,s.zeros(32),s.zeros(32),a)
p=[2,1,0,0,1,-1];r=[3,2,0,0,1,-1];P=sum(v*v for v in p);RR=sum(v*v for v in r);gp=sum((z*v for z,v in zip(GG,p)),s.zeros(64));gr=sum((z*v for z,v in zip(GG,r)),s.zeros(64));G1=-s.I*gp/P;G2=-s.I*gr/RR;deltaD=(gr-gp)*x;deltaG=-G2*deltaD*G1;zero(deltaG-s.I*(x*G1-G2*xs))
u,v=s.symbols('F_p F_r');dFu=s.I*x*(u-v);dFv=s.I*xs*(u-v);actual=dFu*G1*u+v*deltaG*u+v*G2*dFv;expect=s.I*(x*u*u*G1-v*v*G2*xs);zero(actual-expect)
wrong=dFu*G1*u+v*deltaG*u+v*G2*dFu;wrongcount=nz((wrong-expect).subs({u:s.Rational(1,2),v:s.Rational(1,3)}));assert wrongcount>0;zero((wrong-expect).subs(v,u))
aa,bb,tt=s.symbols('a b t',positive=True);div=(s.exp(-tt*bb)-s.exp(-tt*aa))/(aa-bb);equal=s.limit(div,aa,bb);assert simp(equal-tt*s.exp(-tt*bb))==0
# Strict4D paired-mode Gaussian exhibits the new auxiliary reference factor.
as1=Q-L;mom=[2,1,0,0];D0=s.I*sum((z*w for z,w in zip(g4,mom)),s.zeros(4));DA=D0-s.I*g4[0]*as1;K0=C4*D0;KA=C4*DA
ratio=s.factor(KA.det()/K0.det());assert ratio==s.Rational(4,5)
finish('primary',{'method':'actual_SMA_split16_charge_congruence_direct_H_currents_and_ordered_filter_product','background_old_from_new':enc(LH),'scalar_background_bridge_positions':12*328**2,'T_H':list(map(enc,TH)),'carrier_P':XP,'carrier_S':XS,'current_P':JP,'current_S':JS,'mixed_Lie_positions':540*256,'generic_flat_symbol_and_current_transpose_checks':True,'forced_auxiliary_carrier':'X_S=PR*T-PL*T.T_WITHIN_FIXED_BLOCK_DIAGONAL_LIFT','source_pullback_unchanged':True,'filter_rule':'F_X*Kcov_inverse*F_X_transpose = F_X*Dcov_inverse*F_Xswap*C_inverse','first_pure_gauge_ordered_filter_identity':True,'equal_heat_radius_limit':'t*exp(-t*b)','wrong_right_heat_nonzero_fixture_positions':wrongcount,'wrong_right_heat_equal_weights_insensitive':True,'wrong_same_carrier_actual_H_sensitive':[len((dec(p0)-dec(s0)).todok()) for p0,s0 in zip(XP,XS)],'inert_auxiliary_actual_H_failure_count':sum(bool(dec(s0).todok()) for s0 in XS),'paired_mode_auxiliary_Pfaffian_ratio':str(ratio),'auxiliary_quotient':'EXPLICIT_CANDIDATE_Pf_S[A]/Pf_S[0]_MUST_BE_RETAINED_OR_DECLARED_NOT_DISCARDED','local_only_no_analytic_trace_or_phase_theorem':True},tick)
