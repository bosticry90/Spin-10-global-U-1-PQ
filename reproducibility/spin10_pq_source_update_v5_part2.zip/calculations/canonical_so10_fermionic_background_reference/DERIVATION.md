# FBR1: a candidate covariant extension requires two background carriers

First identify the background basis. The old643 witness uses the actual E3
raw light parameters with unit B_h<-partial omega_h, h=0..11. Let Qraw map
raw C3 ghosts to the current parent plane, Qi=Qraw^-1, and H_new embed the
current twelve orthonormal generators. Set L_H=(Qi H_new)[:12,:], requiring
the remaining33 rows zero. Then Qraw[:,:12] L_H=H_new, and the old reference
is used as Kbos,cov[Aold=L_H Anew], without altering old coefficients. The
new bosonic homogeneous carriers are sum_u L_H[u,h]rho_old,u. Their scalar
blocks must equal the actual -rho_scalar(H_new), fixing the relative sign
and the common H carrier before adjoining fermions. This is a coordinate
pullback on a new reference recipe, not a rebind of historical evidence.

Let A(T)=PL T-PR T.T, B(T)=PR T-PL T.T. The literal flat SMA operator is

    D0=[[barGamma.partial,hatGamma.partial],
        [hatGamma.partial,barGamma.partial]], K0=Ctot D0.

Barred Gamma anticommutes with chirality, hatted Gamma commutes. Charge
transpose gives C^-1 A.T C=-B, and likewise Bsharp=-A. A block-diagonal
background field generator with physical block A and auxiliary block Y must
obey Gamma_hat Y=B Gamma_hat. Invertibility of any nonzero hatted Clifford
generator and its chirality commutation require Y=B. This is uniqueness within
that fixed block-diagonal carrier problem, not uniqueness of every background
operator: curvature terms vanishing at A_H=0 can still change a reference.

Set X=diag(A,B), Xswap=diag(B,A). The full barred/hat SMA Clifford coefficients
Gamma_PS obey Gamma_PS X=Xswap Gamma_PS and X.T Ctot=-Ctot Xswap. Consequently
X.T K0(derivative)+K0(derivative)X=0 at constant parameter. The local extension

    nabla_X=partial-ig X_h A_H^h,
    Kcov=Ctot sum_I Gamma_PS^I nabla_X,I

is a local first-order alternating differential kernel. Its ordinary currents
are diagonal barGamma A/barGamma B; formal hatted background currents are
off-diagonal hatGamma B/hatGamma A. All background currents are explicit;
none changes the quantum interaction vertices or flat A0 member. The physical
external background limit has A_hat=0, but internal hatted momenta remain.
The physical mass PLM+PRMdagger remains H-compatible by the authenticated
YCT covariance. The quantum source is still one K_P qP and qS remains0.

There is an independent construction in the original Xi=(psi,chi_c) variables.
Assign the background carriers T to all Dirac psi components and -T.T to
chi_c, then pull through the unchanged SMA map Xi=R(P,S). The result is
diag(A,B). The full Dirac background current, including its hatted reference
directions, gives exactly the diagonal barred and off-diagonal hatted currents
above by R.T K_Xi R. This background connection is vectorlike on regulator
Dirac variables; the quantum gauge/BRST vertices remain the original chiral
ones. The distinction is essential and is not a new physical matter multiplet.

This reference is a new provisional completion. Its ordinary S-background
current was not part of the original A0 free auxiliary factor. At hats0
Kcov factors into physical and auxiliary Gaussian blocks. The auxiliary
Pfaffian Pf(C barGamma nabla_B[A_H]) is now background dependent. A normalized
physical quotient would have to divide by that specified factor and retain
its contribution in the reference-subtraction account. No infinite-dimensional
phase, finite determinant or historical normalization is supplied by this
factorization. A paired-mode finite Gaussian verifies the dependence without
interpreting a constant pure-gauge mode as a physical observable.

## Heat acts on fields and on their evaluation-dual space

Define P_X=-nabla_X^2 and F_X=exp(-t P_X). For the alternating Gaussian the
covariant damped inverse is

    Gt=F_X Kcov^-1 F_X.T.

Transpose includes derivative adjoints. C^-1 X.T C=-Xswap implies
C^-1 F_X.T C=F_Xswap. Thus for the D_PS inverse the same formula is

    Dt^-1=F_X Dcov^-1 F_Xswap.

At A_H=0 both heat operators are the old scalar heat factor and the flat
calculation is exactly recovered. Off flat the two carriers must be tracked;
using F_X on the right is generally wrong. This proof does not assume that
heat commutes with the inverse at nonzero background.

For a first background insertion with incoming p and outgoing r,

    delta P_X[r,p]=-g X_h (r+p).delta A_h,
    delta F_X[r,p]=-integral_0^t exp[-(t-s)r²] deltaP_X exp[-s p²]ds.

The divided difference is (exp(-tp²)-exp(-tr²))/(r²-p²), with equal-radius
limit t exp(-tp²). For a pure gauge deltaA=i(r-p)lambda,

    deltaF_X=ig X lambda (F_p-F_r),
    deltaD=g Gamma.(r-p) X lambda,
    deltaD^-1=ig(X lambda D_p^-1-D_r^-1 Xswap lambda).

In the complete filtered product retain ALL THREE ordered variations:

    delta(F_X D^-1 F_Xswap)
     =deltaF_X D^-1 F_Xswap
      -F_X D^-1 deltaD D^-1 F_Xswap
      +F_X D^-1 deltaF_Xswap.

The result is precisely ig[X lambda (F_p² D_p^-1)
 -(F_r² D_r^-1) Xswap lambda]. The wrong right heat leaves the nonzero
term ig F_r D_r^-1 (X-Xswap)lambda(F_p-F_r). This can be insensitive when
X=Xswap or F_p=F_r; those special cases are not credited as validation.
No finite loop coefficient, subtraction baseline or quantum Ward target is
used. This supplies an explicitly ordered first-variation ingredient for a
future regulated background calculation, not its integrated finite answer.

The enlarged reference is the old qualified643 block plus384 formal SMA
coordinates (192 P and192 S),1027 total at strict4D counting. Removing the
auxiliary reference factor leaves835 interacting coordinates, with the
normalization caveat above. Counts refer to formal integration coordinates,
not physical particles. The new massless fermion principal symbol is the
actual invertible split Clifford symbol; the old mixed weighted symbol is
retained by direct sum. Analytic heat, IR, multiple-product and quantum-phase
assumptions still require their own construction.
