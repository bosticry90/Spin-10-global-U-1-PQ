# FBR1: explicit fermionic background member and first heat variation

Qualified within the declared provisional massless Euclidean reference:
`QUALIFIED_EXPLICIT_FERMIONIC_BACKGROUND_REFERENCE_AND_FIRST_POSITIVE_HEAT_VARIATION_NOT_ADOPTED_SCHEME`. Receipt V2 SHA256
`2bce95c8003e5b87e8de85e3f7fcf801a5b359fd690877105bb69beb85c6f706`. Scientific/director acceptance was not performed;
state113 and authority34/39 are unchanged. This is a constructed candidate,
not recovery or adoption of a uniquely required physical prescription.

The old643-field bosonic witness has a different background basis. Both
methods derive the explicit invertible map L_H=(Qraw^-1 H_new)[:12], verify
its zero heavy complement, and check all1,291,008 scalar carrier positions.
The existing bosonic operator is used at Aold=L_H Anew with all old bytes
unchanged. Its original and clarified receipts retain their distinct scopes.

The physical background charge A=PL T-PR T.T fixes the auxiliary background
charge B=PR T-PL T.T within the tested block-diagonal covariant lift. This is
required by the actual hatted kinetic mixing. qS=0, the physical quantum
vertices and the single physical source pullback are unchanged. A new
reference background current is not an additional physical fermion or a
changed quantum BRST law. All twelve actual H generators and540 mixed
H/full45 Lie identities pass (138,240 color positions). Direct construction
and the independent vectorlike-Dirac pullback agree at491,520 physical
carrier/current positions, including zeros. The formal hatted currents are
specified by the unchanged map and split-Clifford congruence; replay is not
a new component expansion of every hatted current.

The positive-heat Gaussian filter is F_X Kcov^-1 F_X.T. In D_PS coordinates
its right heat is the distinct F_Xswap, with X=diag(A,B) and Xswap=diag(B,A).
The three ordered variations of the two heats and the inverse reproduce the
first pure-gauge endpoint identity. Primary uses a full-hat matrix fixture;
replay independently checks word coefficients and a physical-spin resolvent.
The wrong right heat leaves128 nonzero positions in the full-hat fixture.
Actual same-carrier controls are sensitive in8 H directions, insensitive
in4; equal heat weights are also insensitive. These controls cannot certify
an untested direction merely by giving zero.

At strict4D the new auxiliary reference Pfaffian depends on A_H. A paired
finite-mode determinant and a direct Pfaffian both give ratio4/5. It must
be retained or explicitly divided in a candidate normalization account;
no infinite-dimensional phase, finite reference determinant, physical
quotient or historical normalization is adopted. The direct sum has1027
formal coordinates;835 after an explicitly declared strict4D auxiliary
quotient is conditional bookkeeping, not a particle count or a normalization
theorem. The candidate recipe is stored in candidate_background_reference.json.gz,
packed SHA256 `336559916376b456b3d4ed1de8a0e36711d0f99855759d7740f44379a469542d`,
raw SHA256 `b2338d0ccfdb663202d0a79d47240141b0576a50708574bc5169d35fc2ec3420`.

## Execution and preserved failure

Original primary stopped at a structurally unsimplified complex determinant
ratio after its frame/carrier/heat checks. Exact expansion gives20/25, but
factor() left an unequal expression tree. It remains FAILED; its sources,
manifest, complete native capture and controller failure are preserved.
Original replay and gate were not launched. V2 changes only exact expression
canonicalization to simplify(), with the same expected4/5 and all requirements.
The new primary/replay/gate returned native0 in129.164030/48.433913/4.241399s
after imports. They have65/25/3 memory samples, maxima69,447,680/65,654,784/
56,610,816 bytes (sampled observations, not continuous peaks). Original failure
has69 samples, maximum69,705,728 bytes. Fourteen source copies and1930/1948/
1955 initial/continuation/validation bindings are retained. The pre-report
packet is1,488,887 bytes. All600s/8GiB/350MiB/16MiB bounds were respected.
Fresh E4 this logical turn returned root0, step exits0/0/0/0/0/2; historical
custody remains exit2 with seven unresolved references, NOTPASS. External
before/index/after seals must pass before each dependent local mutation.

## Interpretation and next calculation

The supplied fermionic-sector reviews were reviewed as historical reference,
not substituted for current receipts. Their distinction between coherent UV
counterterms, finite chiral restoration and physical viability is preserved.
The current four A0 projections advance beyond their earlier open-line priority;
this construction addresses the next background prerequisite.

Next derive the actual finite Yukawa two-point/one-background response under
this explicit member. In particular, an S background current can connect two
P-S mixed propagators inside a loop. It vanishes in a strict4D numerator but
can leave a finite dimensional contribution. Compute that term before using
a background Ward comparison; retain both Duhamel heat variations and the
reference determinant separately. Do not identify the earlier action vertex
with the complete background derivative or choose its missing term from a
Ward target. General family Yukawa matrices and all328 scalar inputs remain.

The construction does not establish a finite background loop coefficient,
analytic trace/IR domain, positive-mass chiral propagator, full multiple-product
QAP, measure/Pfaffian phase, physical scheme conversion, massive matterC1,
E5/A5 or physical unification. Shared action, split-Clifford assumptions,
imported tensors, software and AI authorship limit independent assurance.
Both adverse scalar configurations, quartetFAIL, paused flavor, blockedHB1/C5,
all finite freedoms and historical evidence remain. No agents, new branch,
worktree, outreach, publication, push or protected promotion occurred. Whole
investigation remains ACTIVE and incomplete.
