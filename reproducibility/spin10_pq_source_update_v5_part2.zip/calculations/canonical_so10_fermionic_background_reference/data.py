"""FBR1 immutable IO and exact matrix serialization; derivations are separate."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(maxsize=262144)
def simp(z):return s.simplify(z)
def tidy(m):return s.SparseMatrix(m).applyfunc(simp)
def zero(m):assert not tidy(m).todok()
def nz(m):return len(tidy(m).todok())
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(s.expand(z))] for (i,j),z in sorted(tidy(m).todok().items())]}
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
def scalar_frames(d):
 dims=[('Phi',54),('Sigma',252),('phi',20),('S',2)];names=d['BOSON']['field_order'];pos={name:i for i,name in enumerate(names)};index={};offset=0
 for sec,n in dims:
  for j in range(n):index[pos[f'x_{sec}_{j}']]=offset+j
  offset+=n
 assert offset==328
 old=[]
 for rows in d['BOSON']['carriers']:
  entries={}
  for i,j,z in rows:
   if i in index:assert j in index;entries[index[i],index[j]]=s.sympify(z)
  old.append(s.SparseMatrix(328,328,entries))
 current=[s.SparseMatrix(328,328,{}) for _ in range(45)];offset=0
 for sec,n in dims:
  for a,row in enumerate(d['scalar_Rnew'][sec]):
   for i,j,z in row['entries']:current[a][i+offset,j+offset]=s.sympify(z)
  offset+=n
 return old,current
def begin(role):
 tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('FBR1_PEER_DENIED')
 sys.addaudithook(audit);return tick
def finish(role,out,tick):
 out.update({'elapsed_after_imports':time.perf_counter()-tick,'construction':'DECLARED_PROVISIONAL_BACKGROUND_MEMBER_NOT_HISTORICAL_SCHEME_RECOVERY','quantum_BRST_auxiliary':'qS=0_UNCHANGED','physical_Nambu_antifield_copies':1,'family_multiplicity':'I3_NO_EXTRA_LOOP_FACTOR','old_bosonic_direct_summand':643,'formal_P_S_coordinates':384,'formal_full_reference_coordinates':1027,'interacting_after_explicit_auxiliary_quotient_strict4D':835,'finite_background_loop_coefficient_computed':False,'auxiliary_background_factor_discarded':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'})
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
