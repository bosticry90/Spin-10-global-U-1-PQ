"""FBR1 independent Dirac background pullback and scalar heat-word algebra."""
from data import *
tick=begin('replay');I2=s.eye(2);Z2=s.zeros(2);pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[block(Z2,-s.I*z,s.I*z,Z2) for z in pa]+[block(Z2,I2,I2,Z2)]
L=s.diag(1,1,0,0);Q=s.eye(4)-L;eps=s.Matrix([[0,1],[-1,0]]);C4=s.diag(eps,-eps);RR=block(L,Q,-Q,-L);RI=block(L,-Q,Q,-L);zero(RI*RR-s.eye(8));zero(RR.T-RI)
t=s.Matrix(2,2,s.symbols('u0:4'));IL=s.eye(2);r=s.kronecker_product(RR,IL);ri=s.kronecker_product(RI,IL);diracCharge=s.diag(s.kronecker_product(s.eye(4),t),-s.kronecker_product(s.eye(4),t.T))
physicalCharge=s.kronecker_product(L,t)-s.kronecker_product(Q,t.T);auxCharge=s.kronecker_product(Q,t)-s.kronecker_product(L,t.T);zero(ri*diracCharge*r-s.diag(physicalCharge,auxCharge))
# In chirality blocks hat intertwiners preserve L/R, so the other carrier is
# forced to exchange the two blocks; an inert S fails for every nonzero T.
zero(s.kronecker_product(L,IL)*auxCharge+s.kronecker_product(L,t.T));zero(s.kronecker_product(Q,IL)*auxCharge-s.kronecker_product(Q,t))
d=packed(HERE/'replay_inputs.json.gz');T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);TH=[]
Qraw,Qi=map(dec,[d['Qraw'],d['Qi']]);zero(Qi*Qraw-s.eye(45));inject=tidy(Qi*H);zero(inject[12:,:]);LH=tidy(inject[:12,:]);zero(Qraw[:,:12]*LH-H);assert LH.det()!=0
oldrho,newrho=scalar_frames(d)
for h in range(12):zero(oldrho[h]+sum((Qraw[a,h]*newrho[a] for a in range(45) if Qraw[a,h]),s.SparseMatrix(328,328,{})))
for h in range(12):
 entries={}
 for (a,j),z in H.todok().items():
  if j==h:
   for ij,v in T[a].todok().items():entries[ij]=entries.get(ij,0)+z*v
 TH.append(tidy(s.SparseMatrix(16,16,entries)))
AD=[s.zeros(45) for h in range(12)]
for b,a,e,z in d['plane_f']:
 for h in range(12):
  if H[b,h]:AD[h][e,a]+=H[b,h]*s.sympify(z)
for h,th in enumerate(TH):
 zero(th-th.H)
 for a in range(45):zero(th*T[a]-T[a]*th-s.I*sum((AD[h][e,a]*T[e] for e in range(45) if AD[h][e,a]),s.zeros(16)))
for h in range(12):
 for j in range(12):assert simp(s.trace(TH[h]*TH[j])-2*int(h==j))==0
IC=s.eye(16);r16=s.kronecker_product(RR,IC);ri16=s.kronecker_product(RI,IC);XP=[];XS=[];JP=[];JS=[]
for th in TH:
 dc=s.diag(s.kronecker_product(s.eye(4),th),-s.kronecker_product(s.eye(4),th.T));new=tidy(ri16*dc*r16);ap=new[:64,:64];as0=new[64:,64:];zero(new[:64,64:]);zero(new[64:,:64]);XP.append(enc(ap));XS.append(enc(as0));JP.append([]);JS.append([])
 for gam in g4:
  z=s.zeros(64);old=block(z,-s.I*s.kronecker_product(C4*gam,th.T),s.I*s.kronecker_product(C4*gam,th),z);got=tidy(r16.T*old*r16);zero(got[:64,64:]);zero(got[64:,:64]);jp=got[:64,:64];js=got[64:,64:];zero(jp+jp.T);zero(js+js.T);JP[-1].append(enc(jp));JS[-1].append(enc(js))
print('STAGE INDEPENDENT_DIRAC_PULLBACK_ALL12_PHYSICAL_CURRENTS',flush=True)
# Independent noncommutative-word coefficient proof of the THREE heat terms.
u,v,XPword,XRword=s.symbols('u v XG_p G_rXswap');co=s.expand((u-v)*u*XPword+v*(XPword-XRword)*u+v*XRword*(u-v)-(u*u*XPword-v*v*XRword));assert co==0
# Concrete physical4-spin fixture verifies the resolvent and wrong-right heat.
toy=s.diag(1,2);a=s.kronecker_product(L,toy)-s.kronecker_product(Q,toy.T);b=s.kronecker_product(Q,toy)-s.kronecker_product(L,toy.T);p=[2,1,0,0];r=[3,2,0,0];P=sum(z*z for z in p);R2=sum(z*z for z in r)
gp=s.kronecker_product(sum((z*w for z,w in zip(g4,p)),s.zeros(4)),I2);gr=s.kronecker_product(sum((z*w for z,w in zip(g4,r)),s.zeros(4)),I2);G1=-s.I*gp/P;G2=-s.I*gr/R2;deltaD=(gr-gp)*a;zero(-G2*deltaD*G1-s.I*(a*G1-G2*b))
assert nz(G2*(a-b))>0
# The first heat derivative from its Schwinger parameter has the same divided
# difference, including the equal-radius value; no heat/inverse commutation.
aa,bb,tt=s.symbols('a b t',positive=True);z=s.Symbol('s');exp=s.exp(-(tt-z)*aa-z*bb);boundary=s.exp(-tt*bb)-s.exp(-tt*aa);assert simp(s.diff(exp,z)-(aa-bb)*exp)==0
assert simp(s.limit(boundary/(aa-bb),aa,bb)-tt*s.exp(-tt*bb))==0
def pf(A):
 if not A.rows:return s.S.One
 return s.expand(sum((-1)**(j+1)*A[0,j]*pf(A.extract([k for k in range(A.rows) if k not in [0,j]],[k for k in range(A.rows) if k not in [0,j]])) for j in range(1,A.rows)))
as1=Q-L;D0=s.I*sum((z*w for z,w in zip(g4,p)),s.zeros(4));DA=D0-s.I*g4[0]*as1;K0=C4*D0;KA=C4*DA;paired=lambda k:block(s.zeros(4),k,-k.T,s.zeros(4));ratio=s.factor(pf(paired(KA))/pf(paired(K0)));assert ratio==s.Rational(4,5)
finish('replay',{'method':'vectorlike_Dirac_background_through_actual_PS_change_scalar_word_heat_identity_and_direct_Pfaffian','background_old_from_new':enc(LH),'scalar_background_bridge_positions':12*328**2,'T_H':list(map(enc,TH)),'carrier_P':XP,'carrier_S':XS,'current_P':JP,'current_S':JS,'mixed_Lie_positions':540*256,'generic_flat_symbol_and_current_transpose_checks':True,'forced_auxiliary_carrier':'X_S=PR*T-PL*T.T_WITHIN_FIXED_BLOCK_DIAGONAL_LIFT','source_pullback_unchanged':True,'filter_rule':'F_X*Kcov_inverse*F_X_transpose = F_X*Dcov_inverse*F_Xswap*C_inverse','first_pure_gauge_ordered_filter_identity':True,'equal_heat_radius_limit':'t*exp(-t*b)','wrong_right_heat_nonzero_physical4D_fixture':True,'wrong_right_heat_equal_weights_insensitive':True,'wrong_same_carrier_actual_H_sensitive':[len((dec(p0)-dec(s0)).todok()) for p0,s0 in zip(XP,XS)],'inert_auxiliary_actual_H_failure_count':sum(bool(dec(s0).todok()) for s0 in XS),'paired_mode_auxiliary_Pfaffian_ratio':str(ratio),'auxiliary_quotient':'EXPLICIT_CANDIDATE_Pf_S[A]/Pf_S[0]_MUST_BE_RETAINED_OR_DECLARED_NOT_DISCARDED','local_only_no_analytic_trace_or_phase_theorem':True},tick)
