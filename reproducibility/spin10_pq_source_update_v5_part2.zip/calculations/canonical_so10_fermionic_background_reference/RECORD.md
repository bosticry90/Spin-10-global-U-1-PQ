# FBR1: enlarged fermionic background reference and its first heat variation

Base70d1a01bd1255e975b0394ca4b183a0c194f5178/main32843blobs. WholegoalACTIVE,
state113/34of39 unchanged. Recover AGENTS,V558, the actual SMA action/source,
old643-field covariant witness, YCT and CSW receipts. No agents, branches,
worktrees, remote actions, physical scheme or foundational adoption.

Question: does the actual flat massless SMA reference admit an explicit local
H-background covariant member with a correctly paired positive-heat filter?
What additional auxiliary current/normalization does that member require?
This is a prerequisite for a controlled background extension of the four
qualified A0 matter projections and eventual physical background matching.
The least expensive competent test is a classical operator/heat-variation
construction, before extracting another finite loop coefficient.

Keep the frozen scalar/gauge643 reference as an authenticated direct summand.
Its old raw light-ghost/background index is not presumed equal to the current
orthonormal H_new index. Derive Aold=(Qi*H_new)[:12] Anew from the actual
canonical-to-parent chart, check its zero heavy complement and invertibility,
and verify all328 scalar carriers against the old E3 witness before direct sum.
Physical Nambu P and auxiliary S have the SAME flat SMA mixed symbol; no
new particle or quantum BRST variation is introduced. qP=ig c A P,qS=0 stay.
For background transformations, fix X_P=PL T-PR T.T and determine X_S from
the literal hatted kinetic mixing and its cotangent transpose. Do not assume
an inert auxiliary or silently identify background action with quantum BRST.
The construction is a declared provisional background member, not recovery
of a uniquely required historical P_A or adoption of its normalization.

Primary uses the actual split16-spin/C witness to derive the full block
congruences; replay independently pulls a vectorlike background connection
through the original Dirac-to-P/S map, with physical4-spin components.
Construct all12 actual H
carrier and current matrices, retaining familyI3 and all conjugate charges.
Check all540 mixed H/full45 Lie relations against actual plane f and H_new;
reuse the qualified scalar/Yukawa covariance instead of repeating its large
tensor calculation. Full flat coefficients, alternating current transpose,
principal inverse and source pairing must remain. Missing or wrong auxiliary
background charge must leave a detected remainder. No unknown loop target.

Derive the field and cotangent heat operators separately. A correct Gaussian
filter is F_X K^-1 F_X.T; in the D_PS inverse it has the corresponding distinct
right-dual heat, not an unexamined second F_X. Derive the first Duhamel/Fourier
variation and pure-gauge propagator identity before a loop calculation. Retain
noncommuting order and the equal-momentum heat limit. A wrong right carrier
must be detected in a generic nonzero control and its actual H sensitivity
reported, including insensitive directions rather than false failures.

At hats0 the candidate's S block has an H-dependent auxiliary Pfaffian. Display
that factor and a direct paired-mode Pfaffian control proving it cannot be
called field independent. Any quotient is only an explicit candidate reference
normalization, not a computed full determinant or a physically adopted finite
prescription. Keep Gamma_ref[A] and its derivatives open. Do not normalize
away background terms in the original theory or old evidence.

Freeze eight sources/copies, types, assumptions, actual input hashes, evidence,
controls and ceilings before workers. Three sequential600s-afterimport stages,
sampledprivate8GiB, launch availablecommit350MiB, storedpacket16MiB. Fresh E4
thisgoalturn (no --fresh), expected steps0/0/0/0/0/2 and seven custodyNOTPASS.
Stop on a native failure, preserve full sources/captures, repair only by a
frozen continuation. Validate before a local commit; passing before/index/
after custody must preserve every prior blob. Authority ceiling: explicit
classical covariant member and first positive-heat variation, not finite
background loop matching, full chiral restoration, products/QAP/measure/phase,
massiveC1,E5/A5 or GUT. Preserve all failed scalar/quartet evidence, flavorpause,
HB1/C5 blocks and finite freedoms. Shared action, analytic split-Clifford
premises, previous tensors, software and AI author limit independence.
