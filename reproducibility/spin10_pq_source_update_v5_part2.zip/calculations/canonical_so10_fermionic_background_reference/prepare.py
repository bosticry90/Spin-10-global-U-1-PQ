"""FBR1 freeze the actual flat operator, H chart bridge and candidate contract."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_complete_heat_scalar_response'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermionic-background-reference-v1-2026-10-23');OLD=CONTROL.with_name('complete-heat-scalar-response-v1-2026-10-23')
BASE='70d1a01bd1255e975b0394ca4b183a0c194f5178';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/(name+'.json.gz');add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32843
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt_v2.json','verify_v2_capture.json','RESULT.md','validation_preparation_v2.json']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V558.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
BOS=CAL/'canonical_so10_local_covariant_reference_witness';bp=BOS/'validation_v2_receipt.json';assert digest(bp)=='271707fd55abc61eff288b45791f9796babacd5efe3b9b442a381a07cbac6bc1';add(bp);br=read(bp)
assert br['all643_actual_H_carriers_and48_affines_verified'] and br['all4131_ordered_entries_reconstructed_by_independent_multiplicities'] and br['only_this_explicit_local_member_and_formal_local_jet_recursion_qualified']
for n in ['RECORD.md','DERIVATION.md','RESULT.md','witness.py','witness.py.source.txt','validation_receipt.json','validation_capture.json','validation_v2_capture.json']:add(BOS/n)
for folder,names in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','RECORD.md','RESULT.md','primary.py','primary.py.source.txt','replay.py','validation_receipt.json']),('canonical_so10_yukawa_carrier_transport',['RESULT.md','validation_receipt.json']),('canonical_so10_chiral_sterile_comparison',['RECORD.md','RESULT.md','validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
assert digest(CAL/'canonical_so10_sterile_matter_action/validation_receipt.json')=='21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
plane=source('canonical_so10_ghost_triangle_field_insertion','qualified_reference_inputs')['reference_fields']['plane_f'];assert len(plane)==720
boson_refs={}
for role in ['primary','replay']:
 bo=BOS/(role+'_result.json');matches=[h for p,h in br['input_sha256'].items() if Path(p).resolve()==bo.resolve()];assert matches==[digest(bo)];add(bo);b=read(bo);assert len(b['field_order'])==643 and b['explicit_operator_positions']==4131 and b['all1597_actual_flat_K_entries_recovered']
 assert set(b['actual48_field_affines'])=={f'B{i}_{mu}' for i in range(12) for mu in range(4)}
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables');sma=source('canonical_so10_sterile_matter_action',role+'_tables');sc=source('canonical_so10_scalar_source_finite_comparison',role+'_tables');q=source('canonical_so10_bosonic_source_onejet_finite','primary_v2_tables' if role=='primary' else 'replay_v3_tables')
 # The peer outputs have different evidence details, so only supply the same
 # established flat source map needed in this role's construction.
 if role=='replay':smap=source('canonical_so10_sterile_matter_action','primary_tables')
 else:smap=sma
 gz(HERE/(role+'_inputs.json.gz'),{'Y':{k:y[k] for k in ['Tminus','H_new']},'SMA':{k:smap[k] for k in ['R','R_inverse','source_pullback']},'BOSON':{'field_order':b['field_order'],'carriers':b['actual12_homogeneous_carrier_matrices']},'Qraw':q['Qchart'],'Qi':q['Qi'],'scalar_Rnew':sc['classical_Rnew'],'plane_f':plane});add(HERE/(role+'_inputs.json.gz'))
 boson_refs[role]={'path':str(bo.resolve()),'sha256':digest(bo),'explicit_covariant_operator':b['explicit_covariant_operator'],'field_order':b['field_order']}
gz(HERE/'bosonic_member_inputs.json.gz',boson_refs);add(HERE/'bosonic_member_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],stdout=out,stderr=err,cwd=ROOT)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'FBR1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('FBR1_FROZEN',len(bind),'bindings',flush=True)
