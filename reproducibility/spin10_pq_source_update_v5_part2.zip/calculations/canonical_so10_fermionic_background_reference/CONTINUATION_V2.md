# FBR1 continuation V2: canonicalize the exact determinant comparison

The original primary stopped after the actual-H/frame/Lie and full-hat heat
checks, at an unsimplified determinant ratio. Its source, preparation, complete
capture and controller failure remain immutable. Replay and gate were NOT
LAUNCHED. A small diagnostic recomputed detD0=25 and detDA=(4-2i)(4+2i)=20;
the old factor() representation compared structurally unequal to 4/5. This is
an assertion-normalization failure, not a changed reference or failed covariance.

V2 uses exact simplify() for the paired-mode ratio in both methods. No matrix,
input, expected value, claim, scientific requirement or resource ceiling changes.
Preserve the original failed run; primary/replay/gate now use new V2 paths and
frozen sources. All inherited1930 bindings are authenticated before launch;
add the failed native evidence and all new sources/copies. Reuse this turn's
completed fresh E4 result, not a second replay. Sequential600s afterimports,
8GiB sampled private,350MiB launch availablecommit,16MiB packet. Native failure
stops the controller. No adoption, finite-loop result, scientific promotion,
remote action or alteration of old evidence. Authority remains34/39.
