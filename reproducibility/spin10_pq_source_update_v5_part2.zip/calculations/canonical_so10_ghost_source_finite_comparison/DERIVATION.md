# GSF1: resolved kernels determine the finite source coefficient

Prospective analytic derivation;complete native checks must qualify it.

## Actual complete proper source family

The literal master source has only g*J_C*C*C,with J_C even. Both source
ghosts must be internal;otherwise the sole remaining quantum source edge is
a bridge and the graph is1PR. For the dimension4,ghost0,no-jet J_Ccc target,
one-loop counting leaves either two cubic GF vertices or one GF quartic.
The authenticated full GF inventory and all643 reference directions retain:

 SFF:two ordinary aBC derivative vertices,g3;
 SGX:ordinary aBC plus auxiliary aLambdaC,g2xi;
 SR:four-ghost quartic at g2xi,with sourceg givesg3xi;
 SQ:four-ghost quartic at gxi,with sourceg givesg2xi.

The two-auxiliary cubic possibility vanishes by G_LambdaLambda0. Scalar/
reference-mass insertions have positive coefficient dimension and lower the
UV degree;no inverse mass occurs in the admitted local ring. Other quartics
have only one antighost and cannot join both internal source ghosts. Physical
matter vertices have no antighosts;adding a closed fermion insertion is1PR or
increases loop order. The old exact family inventories prove these exclusions
from the actual action,not generic gauge-fixing assumptions.

## Why the full-D kernels are specified,not guessed from D4 poles

Each ordinary cubic vector index is paired with its derivative momentum.
The only Lorentz contraction is k^mu G_BB,mu,nu k^nu. For the actual full
inverse G_BB=-eta/Q+(1-w)kk/Q²,this is -w in ANY dimension. Both transverse
and longitudinal terms are essential. In projector language
G_BB=-(P_T+wP_L)/Q,kP_T0,kP_Lk=Q,which gives the same result without a
numeric metric trace. The mixed triangle has kG_BL=+i and G_LBk=-i in
the inherited conventions;its critical scalar is also dimension independent.
The bubble has two ghost edges and no Lorentz index. There is therefore no
unfixed D-dependent numerator or closed delta_mu^mu in any of these kernels.

All derivative placements,odd orientations,identical-vertex factors and
source signs remain those of the literal Born and routed Wick kernels.
Their archived controls supply the exact scalar coefficients after that
pointwise full-D contraction. External-ghost derivatives improve UV degree
and givezero in this no-jet local coefficient. This does not make their
general nonlocal amplitudes vanish. Thus u_D=u4 for each resolved family,
and its negative dimension jet -2du_D/dD iszero.

## Radial finite part with a common infrared completion

For an auxiliary positive m²,not a physical mass choice,

 (16pi²)I_dim=(4pi)^epsilon Gamma(epsilon)(m²)^(-epsilon),
 (16pi²)I_heat=(1+x)exp(x)E1(x)-1,x=c*t*m².

The first finite coefficient is log(4pi)-gamma_E-log(m²). The second is
-gamma_E-log(c*t*m²)-1. With the already inherited finite-part convention
chi4=1+log(16pi)-n_log,the local comparison is

 I_dim,FP-I_heat,FP=[chi4+log(c/4)]/(16pi²).

Replay derives the same result from integral_0^infty ds*s*exp(-m²s)/
(s+ct)^2 by integration by parts,without copying the radial result. The
auxiliary m cancels. Keep the real common n_log/chi4 symbolic.
Off-shell/joint test-field kernels have locally integrable separate soft
nodes;the Taylor proxy is used only to isolate its UV-leading homogeneous
coefficient. Its O(r^-5) remainder is UV convergent and has zero relative
local limit. One must not set all external momenta0 in an unregulated
massless integral or infer a full scaleless amplitudezero.

The old family convention is hbar/(32pi²epsilon) with pole multiplier2i
times the literal Minkowski Born kernel. The finite1/(16pi²) coefficient
is i times that same kernel. Hence the resolved old coefficient is divided
by2 in the new finite convention;this is a unit conversion,not an additional
ghost-pair or Nambu half. The old families already have their exact symmetry
and exterior factors. No color coefficient is fitted.

Consequently each triangle contributes (chi4+log(3/2))*old_family/2;
each bubble contributes chi4*old_family/2. There is no remaining rational
fixed direction for these dimension-independent kernels. Ordinary SR has
its outside xi restored once;the lower SGX/SQ families both carry g2xi
outside once. SFF's formal reference-width atoms are translated only by
the historically verified reference_width_H/M=eta_H/xi correspondence.

## Exterior source transport and actual tree check

The archived physical ghosts use C_old=Qold*C_raw and the current plane
C_new=Qnew*C_raw. SVT supplies L=Qnew*Qold^-1 and Linv. The even source
has J_old=L.T*J_new. Therefore the output index transforms with L and both
ghost inputs with Linv. For each old ordered coefficient N_I,uv,u<v,the
new ordered coefficient is

 N_i,ab=sum_Iuv L_iI N_I,uv
        *(Linv_ua Linv_vb-Linv_ub Linv_va),a<b.

Replay instead fills a full antisymmetric matrix per old source,transports
through raw C3 and into the current plane,and takes its upper triangle.
There is NO extra1/2 when returning from that matrix to an ordered ghost
density. Equal-color coefficients arezero by exterior algebra.

Before transporting loop answers,compare the actual literal tree J_Ccc
from both old source families with Qnew*QCold(Qnew^-1*Cnew) from the raw
current master maps. The actual physical convention qP=ig c^a T_a P and
[T_a,T_b]=i f_ab^s T_s requires QC_s=-g f_ab^s C_a C_b for a<b.
Check this actual tree,source dual and all zero entries. Inverses alone
would not establish source/ghost conventions. The old source loop cannot
be transported merely because the spaces have the same dimension.

Current reality and the12 residual-H tensor identities follow from the
actual frame bridge and are also checked on the finite coefficient tensors.
No scalar/physical baseline or future quantum source relation is fixed.
The missing KccP comparison must still combine this proper ghost-source
amplitude with PSF's proper KPcP amplitude and the actual CMS insertion;
it is not the old MSP counterterm primitive.
