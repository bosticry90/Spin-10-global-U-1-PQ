"""GSF1 exact exterior tensor transport;no Ward targets or counterterms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
PARTS=['chi4','log3over2','fixed'];ALIASES={'reference_width_H':'eta_H','reference_width_M':'xi'}
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('GSF1_PEER_OR_EXPECTED_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_complete_matter_source_breaking','canonical_so10_matter_source_primitive','canonical_so10_coupled_fermion_finite_counterterm','canonical_so10_complete_heat_vector_response'] and p.name.endswith('.gz'):raise PermissionError('GSF1_HIGHER_SOURCE_OR_CORRECTION_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def coeff(z):
 for a,b in ALIASES.items():z=z.replace(a,b)
 return Q(z)
def unpack(rows):
 out={}
 for s,a,b,z in rows:assert 0<=s<45 and 0<=a<b<45;out[s,a,b]=coeff(z)
 return out
def pack(d):return [[s,a,b,textq(z)] for (s,a,b),z in sorted(d.items()) if z]
def accumulate(d,key,z):
 d[key]=add(d.get(key,Z),z)
 if not d[key]:del d[key]
def scale_t(d,z):return {k:prod(v,z) for k,v in d.items() if prod(v,z)}
def sum_t(*aa):
 out={}
 for d in aa:
  for k,z in d.items():accumulate(out,k,z)
 return out
def rowmap(m):
 out=defaultdict(list)
 for (i,j),z in m.d.items():out[i].append((j,z))
 return out
def wedge_transport(d,outmap,inmap):
 oo=rowmap(trans(outmap));ii=rowmap(inmap);out={}
 for (s,a,b),z in d.items():
  for r,x in oo[s]:
   for u,y in ii[a]:
    for v,w in ii[b]:
     if u!=v:accumulate(out,(r,min(u,v),max(u,v)),prod(z,prod(x,prod(y,prod(w,ONE if u<v else Q(-1))))))
 return out
def matrix_transport(d,outmap,inmap):
 mats={}
 for (s,a,b),z in d.items():
  m=mats.setdefault(s,Mat(45,45));m.d[a,b]=z;m.d[b,a]=neg(z)
 oo=rowmap(trans(outmap));out={}
 for s,m in mats.items():
  new=mul(mul(trans(inmap),m),inmap)
  for (a,b),z in new.d.items():
   if a<b:
    for r,x in oo[s]:accumulate(out,(r,a,b),prod(x,z))
 return out
def old_tree(rows):
 out={}
 for row in rows:
  w=row['word'];ss=[int(n[3:]) for n in w if n.startswith('JCp')];cc=[int(n[2:]) for n in w if n.startswith('Cp')];assert len(ss)==1 and len(cc)==2 and cc[0]!=cc[1]
  accumulate(out,(ss[0],min(cc),max(cc)),prod(coeff(row['coefficient']),ONE if cc[0]<cc[1] else Q(-1)))
 return out
def raw_tree(maps):
 out={};g=sy.Symbol('g10')
 for name,rows in maps.items():
  s=int(name[1:])
  for row in rows:
   cc=[int(n[1:]) for n in row['word']];assert len(cc)==2 and cc[0]!=cc[1]
   poly=sy.Poly(sy.sympify(row['coefficient'],locals={'g10':g}),g);assert poly.monoms()==[(1,)]
   accumulate(out,(s,min(cc),max(cc)),prod(Q(str(poly.nth(1))),ONE if cc[0]<cc[1] else Q(-1)))
 return out
def finite_families(d,transport):
 out={};orders={'SFF_triangle':'g3','SR_bubble':'g3','SGX_triangle':'g2xi','SQ_bubble':'g2xi'}
 for name,order in orders.items():
  old=unpack(d['ordinary' if order=='g3' else 'lower']['family_poles'][name]);fac=Q('1/2')
  if name!='SFF_triangle':fac=prod(fac,Q('xi'))
  current=transport(scale_t(old,fac));out[name]={p:(current if p=='chi4' or p=='log3over2' and name.endswith('triangle') else {}) for p in PARTS}
 return out
def finish(role,families,tree,units,tick,method):
 total={o:{p:{} for p in PARTS} for o in ['g3','g2xi']}
 for name,parts in families.items():
  order='g3' if name in ['SFF_triangle','SR_bubble'] else 'g2xi'
  for p,v in parts.items():total[order][p]=sum_t(total[order][p],v)
 out={'role':role,'method':method,'elapsed_after_imports':time.perf_counter()-tick,'family_coefficients':{n:{p:pack(v) for p,v in parts.items()} for n,parts in families.items()},'finite_coefficients':{o:{p:pack(v) for p,v in parts.items()} for o,parts in total.items()},'tree_QC':pack(tree),'finite_units':units,'width_aliases':ALIASES,'complete_ghost_source_domain':{'sources':45,'ghosts':45,'ordered_antisymmetric_slots':44550,'equal_color_zeros':2025,'full_ordered_components':91125},'quantum_coefficient_fitted':False,'highest_KccP_response_computed':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
