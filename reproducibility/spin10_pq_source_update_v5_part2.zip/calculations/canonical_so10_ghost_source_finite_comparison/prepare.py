"""GSF1 freeze actual resolved old families and current source/ghost frames."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';PRED=CAL/'canonical_so10_complete_heat_vector_response'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-source-finite-comparison-v1-2026-10-23');OLD=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-vector-response-v1-2026-10-23')
BASE='b1cbea69f310c2ef6deeb20e6ec8e22aacc803ec';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32639
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json']:add(PRED/n)
for n in ['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V553.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
for n in ['postcommit_seal.json','before_commit_seal.json','successful_index_gate.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for n in ['A10_E5_GHOST_SOURCE_RESULT_V1.md','A10_E5_GHOST_SOURCE_G3_RESULT_V1.md','a10_e5_ghost_source.py','a10_e5_ghost_source_g3.py','a10_e5_ghost_source_control.py','a10_e5_ghost_source_g3_control.py','a10_e5_nonminimal_source.py','a10_e5_auxiliary_vertex.py']:add(PK/n)
archives={}
for key,folder,qualified in [('lower','frozen_a10_e5_ghost_source','actual_source_pole_qualified'),('ordinary','frozen_a10_e5_ghost_source_g3','actual_g3_JC_pole_qualified')]:
 f=PK/folder;receipt=read(f/'validation_receipt.json');assert receipt[qualified] and receipt['historical_custody_exit']==2 and not receipt['failed_attempts_counted_as_PASS']
 for name in ['validation_receipt.json','bindings.json','controls.json','primary.json','replay.json']:add(f/name)
 for name in ['controls.json','primary.json','replay.json']:
  p=f/name;rel=p.relative_to(ROOT).as_posix();assert digest(p)==receipt['new_sha256'][rel],rel
 archives[key]={role:read(f/(role+'.json')) for role in ['primary','replay']};archives[key]['controls']=read(f/'controls.json')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 q=HERE/(n+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 add(p);add(q)
ref=CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz';add(ref);plane_f=packed(ref)['reference_fields']['plane_f']
for role in ['primary','replay']:
 svp=CAL/'canonical_so10_source_vector_finite_transport'/(role+'_v2_tables.json.gz');bsp=CAL/'canonical_so10_bosonic_source_onejet_finite'/(( 'primary_v2' if role=='primary' else 'replay_v3')+'_tables.json.gz');yp=CAL/'canonical_so10_yukawa_carrier_transport'/(role+'_tables.json.gz');bp=PK/'frozen_a10_bv_master'/(role+'.json')
 for p in [svp,bsp,yp,bp]:add(p)
 sv=packed(svp);bs=packed(bsp);y=packed(yp);bv=read(bp)
 ordinary=archives['ordinary'][role];lower=archives['lower'][role];ctrl=archives['ordinary']['controls'];ctl=archives['lower']['controls']
 assert ordinary['units'].startswith('hbar/(32*pi^2*epsilon_UV)') and lower['units'].startswith('hbar/(32*pi^2*epsilon_UV)')
 gz(HERE/(role+'_inputs.json.gz'),{'ordinary':{'family_poles':ordinary['family_poles'],'tree_source':ordinary['vertices']['S']},'lower':{'family_poles':lower['family_poles'],'tree_source':lower['vertices']['S']},'frame':{**{k:sv[k] for k in ['L','Li','Qold','Qold_inverse']},**{k:bs[k] for k in ['Qchart','Qi']}},'Y':{'H_new':y['H_new']},'raw_QC':{f'C{i}':bv['source_only_columns'][f'C{i}'] for i in range(45)},'plane_f':plane_f,'controls':{'ordinary':{k:ctrl[k] for k in ['triangle_per_reference_width','bubble_pole','common_UV_multiplier','heat_profiles']},'lower':{k:ctl[k] for k in ['unit_poles','Minkowski_pole_multiplier','heat_profiles']}}});add(HERE/(role+'_inputs.json.gz'))
gz(HERE/'validation_control_inputs.json.gz',{'ordinary_canonical':archives['ordinary']['primary']['canonical_full_g_cubed_density'],'lower_canonical':archives['lower']['primary']['canonical_full_g_squared_xi_density']});add(HERE/'validation_control_inputs.json.gz')
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(OLD/n)
assert read(OLD/'readiness_result.json')['step_exits']==[0,0,0,0,0,2]
dump(CONTROL/'readiness_reuse.json',{'source':str(OLD/'readiness_result.json'),'sha256':digest(OLD/'readiness_result.json'),'same_goalturn_fresh_command_authenticated_not_repeated':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'GSF1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('GSF1_FROZEN',len(bind),'bindings',flush=True)
