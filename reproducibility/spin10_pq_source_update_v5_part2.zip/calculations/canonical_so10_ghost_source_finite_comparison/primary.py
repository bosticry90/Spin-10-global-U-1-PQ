"""GSF1 dimension-free full inverse and direct exterior dual transport."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz')
q,w=sy.symbols('Q width',nonzero=True);eps=sy.Symbol('epsilon');m,c=sy.symbols('m2 c',positive=True);x=sy.Symbol('x',positive=True)
ordinary=sy.expand(-1+(1-w));assert ordinary==-w
mixed=sy.I*q/q;assert mixed==sy.I
dim=sy.limit((4*sy.pi)**eps*sy.gamma(eps)*m**(-eps)-1/eps,eps,0)
heat=(1+x)*sy.exp(x)*sy.expint(1,x)-1
assert sy.limit(heat+sy.EulerGamma+sy.log(x)+1,x,0,dir='+')==0
heatfp=-sy.EulerGamma-sy.log(c*m)-1;diff=sy.expand_log(dim-heatfp,force=True)
assert sy.simplify(diff-1-sy.log(4*sy.pi*c))==0
units={'triangle_length':6,'bubble_length':4,'old32_to_finite16':'1/2','triangle_chi4':'1','triangle_log3over2':'1','triangle_fixed':'0','bubble_chi4':'1','bubble_log3over2':'0','bubble_fixed':'0','dimension_jet':'0','radial_comparison':str(diff)}
L,Li,oldQ,oldQi,newQ,newQi=map(dec,[d['frame'][k] for k in ['L','Li','Qold','Qold_inverse','Qchart','Qi']])
zero(minus(mul(L,Li),ident(45)));zero(minus(mul(L,oldQ),newQ));zero(minus(mul(oldQi,Li),newQi))
t0=old_tree(d['ordinary']['tree_source']);assert t0==old_tree(d['lower']['tree_source'])
tree=wedge_transport(t0,L,Li);actual=wedge_transport(raw_tree(d['raw_QC']),newQ,newQi);assert tree==actual
expected={(s,a,b):neg(Q(z)) for a,b,s,z in d['plane_f'] if a<b};assert tree==expected
families=finite_families(d,lambda v:wedge_transport(v,L,Li))
finish('primary',families,tree,units,tick,'full_D_k_G_k_contractions_radial_finite_part_and_direct_exterior_transport')
