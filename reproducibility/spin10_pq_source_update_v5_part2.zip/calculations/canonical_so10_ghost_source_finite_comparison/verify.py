"""GSF1 full exterior domain,actual raw tree/pole bridge and H tensor gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['family_coefficients','finite_coefficients','tree_QC','width_aliases','complete_ghost_source_domain']:assert P[k]==R[k],k
for k in set(P['finite_units'])-{'radial_comparison'}:assert P['finite_units'][k]==R['finite_units'][k]
assert sy.simplify(sy.sympify(P['finite_units']['radial_comparison'])-sy.sympify(R['finite_units']['radial_comparison']))==0
assert P['finite_units']['triangle_length']==6 and P['finite_units']['bubble_length']==4 and P['finite_units']['old32_to_finite16']=='1/2'
assert d['controls']['ordinary']['triangle_per_reference_width']=='2' and d['controls']['ordinary']['bubble_pole']=='-2'
assert d['controls']['lower']['unit_poles']=={'triangle:a':'-2','triangle:B':'2','triangle:c':'0','bubble:a':'-2'}
assert d['controls']['ordinary']['common_UV_multiplier']=='2*I' and d['controls']['lower']['Minkowski_pole_multiplier']=='2*I'
L,Li,newQ,newQi=map(dec,[d['frame'][k] for k in ['L','Li','Qchart','Qi']]);tree=unpack(P['tree_QC']);assert tree
controls={'wrong_tree_source_half':len(tree),'wrong_exterior_swap_sign':len(tree)}
bad=wedge_transport(old_tree(d['ordinary']['tree_source']),Li,Li);controls['wrong_source_dual_output']=len(sum_t(bad,scale_t(tree,Q(-1))))
positions=0;families={name:{p:unpack(rows) for p,rows in pp.items()} for name,pp in P['family_coefficients'].items()}
for name,parts in families.items():
 order='g3' if name in ['SFF_triangle','SR_bubble'] else 'g2xi'
 old=unpack(d['ordinary' if order=='g3' else 'lower']['family_poles'][name]);fac=Q('1/2') if name=='SFF_triangle' else Q('xi/2')
 assert wedge_transport(parts['chi4'],Li,L)==scale_t(old,fac)
 assert not parts['fixed']
 assert parts['log3over2']==(parts['chi4'] if name.endswith('triangle') else {})
 positions+=3*44550
controls['wrong_heat4_for_triangles']=sum(len(v['log3over2']) for n,v in families.items() if n.endswith('triangle'))
controls['wrong_heat6_for_bubbles']=sum(len(v['chi4']) for n,v in families.items() if n.endswith('bubble'))
assert all(controls.values())
def canonical_source(rows,power):
 out={};g=sy.Symbol('g10')
 for row in rows:
  ww=row['word'];ss=[int(n[2:]) for n in ww if n.startswith('JC')];cc=[int(n[1:]) for n in ww if n.startswith('C')];assert len(ss)==1 and len(cc)==2 and cc[0]!=cc[1]
  poly=sy.Poly(sy.sympify(row['coefficient'],locals={'g10':g}),g);assert poly.monoms()==[(power,)]
  accumulate(out,(ss[0],min(cc),max(cc)),prod(Q(str(poly.nth(power))),ONE if cc[0]<cc[1] else Q(-1)))
 return out
for order,power,key in [('g3',3,'ordinary_canonical'),('g2xi',2,'lower_canonical')]:
 expected=scale_t(matrix_transport(canonical_source(late[key],power),newQ,newQi),Q('1/2'))
 assert unpack(P['finite_coefficients'][order]['chi4'])==expected
# H variation acts on the even source dual and both odd ghost coordinates.
H=dec(d['Y']['H_new']);f={(a,b,s):Q(z) for a,b,s,z in d['plane_f']};hchecks=0
for h in range(12):
 r={}
 for a in range(45):
  for j in range(45):
   z=Z
   for c in range(45):
    if (cc:=H.d.get((c,h),Z)) and (ff:=f.get((c,j,a),Z)):z=add(z,prod(cc,ff))
   if z:r[a,j]=z
 rows=rowmap(Mat(45,45,r));cols=rowmap(trans(Mat(45,45,r)))
 for order,parts in P['finite_coefficients'].items():
  for part,rr in parts.items():
   t=unpack(rr);out={}
   for (s,a,b),z in t.items():
    for i,v in cols[s]:accumulate(out,(i,a,b),neg(prod(v,z)))
    for j,v in rows[a]:
     if j!=b:accumulate(out,(s,min(j,b),max(j,b)),prod(z,prod(v,ONE if j<b else Q(-1))))
    for j,v in rows[b]:
     if a!=j:accumulate(out,(s,min(a,j),max(a,j)),prod(z,prod(v,ONE if a<j else Q(-1))))
    assert all(exponent[3]==0 for exponent,value in z)
   assert not out,(h,order,part,len(out));hchecks+=1
counts={o:{p:len(v) for p,v in parts.items()} for o,parts in P['finite_coefficients'].items()}
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for obj in [P,R]:assert not any(obj[k] for k in ['quantum_coefficient_fitted','highest_KccP_response_computed','free_constant_selected','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_PROPER_GHOST_SOURCE_FINITE_COMPARISON','elapsed_after_imports':time.perf_counter()-tick,'four_action_resolved_families_compared':4,'family_coefficient_positions_compared':positions,'finite_total_positions_compared':2*3*44550,'all45_sources_ghosts_and_exterior_zero_complement_match':True,'actual_master_QC_and_physical_Lie_tree_match':True,'raw_canonical_full_poles_reconstruct_chi4_over2':True,'source_dual_and_no_extra_ghost_half_verified':True,'all12_H_covariance_tensor_checks':hchecks,'finite_units':P['finite_units'],'finite_nonzero_counts':counts,'negative_controls':controls,'finite_IR_full_amplitude_computed':False,'highest_KccP_response_computed':False,'quantum_coefficient_fitted':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
