"""GSF1 projector/proper-time proof and full antisymmetric raw-C3 matrices."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');eps=sy.Symbol('epsilon');m,c=sy.symbols('m2 c',positive=True);x=sy.Symbol('x',positive=True);Q0,w=sy.symbols('Q width',nonzero=True)
# k P_T k=0,k P_L k=Q0;no numerical trace or dimension enters.
assert sy.expand(-(0+w*Q0)/Q0)==-w
assert sy.I*Q0/Q0==sy.I
# Proper-time integral after u=s+ct:integral e^-m u/u and u^-2.
proper=sy.exp(x)*(sy.expint(1,x)-(sy.exp(-x)-x*sy.expint(1,x)))
assert sy.simplify(proper-((1+x)*sy.exp(x)*sy.expint(1,x)-1))==0
heat_constant=sy.limit(proper+sy.log(x),x,0,dir='+');assert heat_constant==-sy.EulerGamma-1
dim_constant=sy.diff((4*sy.pi)**eps*sy.gamma(1+eps)*m**(-eps),eps).subs(eps,0)
diff=sy.expand_log(dim_constant-(heat_constant-sy.log(c*m)),force=True);assert sy.simplify(diff-1-sy.log(4*sy.pi*c))==0
units={'triangle_length':6,'bubble_length':4,'old32_to_finite16':'1/2','triangle_chi4':'1','triangle_log3over2':'1','triangle_fixed':'0','bubble_chi4':'1','bubble_log3over2':'0','bubble_fixed':'0','dimension_jet':'0','radial_comparison':str(diff)}
L,Li,oldQ,oldQi,newQ,newQi=map(dec,[d['frame'][k] for k in ['L','Li','Qold','Qold_inverse','Qchart','Qi']])
zero(minus(mul(oldQ,oldQi),ident(45)));zero(minus(mul(newQ,newQi),ident(45)))
def through_raw(v):return matrix_transport(matrix_transport(v,oldQi,oldQ),newQ,newQi)
t0=old_tree(d['lower']['tree_source']);assert t0==old_tree(d['ordinary']['tree_source']);tree=through_raw(t0)
actual=matrix_transport(raw_tree(d['raw_QC']),newQ,newQi);assert tree==actual
expected={(s,a,b):neg(Q(z)) for a,b,s,z in d['plane_f'] if a<b};assert tree==expected
families=finite_families(d,through_raw)
finish('replay',families,tree,units,tick,'projector_identity_proper_time_finite_part_and_two_stage_antisymmetric_matrix_transport')
