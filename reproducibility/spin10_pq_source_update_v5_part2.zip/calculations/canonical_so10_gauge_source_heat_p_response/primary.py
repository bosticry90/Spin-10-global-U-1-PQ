"""GHP1 exact barred source/endpoints,heat jets and joint hat integral."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');k=sy.symbols('k0:4');p=sy.symbols('p0:4');hat=sy.Symbol('hatQ');b=sum(x*x for x in k);pp=sum(x*x for x in p);kp=sum(x*y for x,y in zip(k,p));Q0=b+hat;R0=Q0-2*kp+pp
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gam=[sy.kronecker_product(pa[1],m) for m in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];s=sum((v*g for v,g in zip(k,gam)),sy.zeros(4));v=sum((x*g for x,g in zip(p,gam)),sy.zeros(4));A=v*(s-v)*s;B=s*(s-v)*v;L=s*(s-v)*s
assert not (A-B).applyfunc(sy.expand).todok() and not (A-(b*v-pp*s)).applyfunc(sy.expand).todok()
assert not (A-L+R0*s-hat*s).applyfunc(sy.expand).todok()
D=sy.Symbol('D');us=4/D;ul=2/D+12/(D*(D+2));assert sy.factor(us-ul-2*(D-4)/(D*(D+2)))==0
eps,m=sy.symbols('epsilon m2',positive=True);dim=4-2*eps;radial=sy.gamma(4-eps)*sy.gamma(eps)*(4*sy.pi/m)**eps/(6*sy.gamma(2-eps));insertion=sy.limit(2*(dim-4)/(dim*(dim+2))*radial,eps,0)
t,z=sy.symbols('t z',positive=True);length=sy.integrate((sy.exp(-6*t*z)-sy.exp(-4*t*z))/z,(z,0,sy.oo));assert sy.simplify(sy.expand_log(length+sy.log(sy.Rational(3,2)),force=True))==0
# Positive radial coefficient from4t*k_i slash/Q² is4t*(1/4)/(c*t).
jet6=sy.Rational(1,6);jet4=sy.Rational(1,4);pair=jet6-jet4;odd=-jet6;heat=sy.simplify(pair+odd)
units={'heat_length_log':'-1','heat_pair_Taylor':str(pair),'heat_odd_endpoint_Taylor':str(odd),'heat_total_fixed':str(heat),'dimensional_fixed':str(insertion),'relative_log':'1','relative_fixed':str(insertion-heat)}
ML=list(map(dec,d['MVS']['loop_left']));MR=list(map(dec,d['MVS']['loop_right']));partner=[scale(plus(a,trans(b)),II) for a,b in zip(ML,MR)]
finish('primary',units,{'length_difference':str(length),'joint_hat_integral':str(insertion),'source_angular':str(us),'longitudinal_angular':str(ul),'heat6_Taylor':'1/6','heat4_Taylor':'1/4','odd_endpoint_before_variation':'0_by_parity','exact_source_endpoint_and_hat_remainders':0,'matrix_positions_checked':48},partner,d,tick,'explicit_Clifford_exact_source_longitudinal_identity_Gamma_joint_moment_and_ordered_source_colors')
