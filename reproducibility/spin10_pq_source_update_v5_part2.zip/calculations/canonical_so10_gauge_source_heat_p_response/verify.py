"""GHP1 complete bare/heat/relative p response and late compact comparison."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['units','source_partner','response_p','derived_traceless_dimensional_kinetic_representative']:assert P[k]==R[k],k
for k in ['joint_hat_integral','heat6_Taylor','heat4_Taylor']:assert sy.simplify(sy.sympify(P['scalar_integrals'][k])-sy.sympify(R['scalar_integrals'][k]))==0
assert sy.simplify(sy.expand_log(sy.sympify(P['scalar_integrals']['length_difference'])-sy.sympify(R['scalar_integrals']['length_difference']),force=True))==0
assert P['units']=={'heat_length_log':'-1','heat_pair_Taylor':'-1/12','heat_odd_endpoint_Taylor':'-1/6','heat_total_fixed':'-1/4','dimensional_fixed':'-1/6','relative_log':'1','relative_fixed':'1/12'}
T=list(map(dec,d['Y']['Tminus']));H=dec(d['Y']['H_new']);partner=list(map(dec,P['source_partner']));cw=dec(d['GFK']['gauge_kinetic_left']);count={};positions=0
for a,t in zip(partner,T):zero(plus(a,trans(star(a))));zero(minus(a,minus(mul(cw,t),mul(t,cw))))
for group,sides in P['response_p'].items():
 count[group]={}
 for side in ['left','right']:
  aa=list(map(dec,sides[side]));count[group][side]=sum(len(m.d) for m in aa);positions+=45*256
  for a in aa:zero(plus(a,trans(star(a))))
  for h in range(12):zero(combine([H.d.get((c,h),Z) for c in range(45)],aa))
 assert sides['right']==[enc(trans(dec(m))) for m in sides['left']]
 for c in range(45):
  get=lambda group:dec(P['response_p'][group]['left'][c]);zero(minus(get('heat_total_fixed'),plus(get('heat_pair_Taylor'),get('heat_odd_endpoint_Taylor'))));zero(minus(get('relative_fixed'),minus(get('dimensional_fixed'),get('heat_total_fixed'))));zero(plus(get('relative_log'),get('heat_length_log')))
assert positions==161280
for side in ['left','right']:
 assert P['response_p']['dimensional_fixed'][side]==late['GTT']['g3'][side]['p']
 for part,group in [('log3over2','relative_log'),('fixed','relative_fixed')]:assert P['response_p'][group][side]==late['VFC']['partial_p_q_images'][part]['gauge'][side]['p']
 for tag in ['g2','gY10','gY126']:assert all(not dec(m).d for m in late['GTT'][tag][side]['p'])
# Preserve z_psi:project the old full symbolic family to its trace-zero part.
old=late['CFC']['F_left'];loc={'eta_H':WH,'xi':WM,'z_psi':sy.Symbol('z_psi',real=True)};fm=sy.SparseMatrix(*old['shape'],{(i,j):sy.sympify(z,locals=loc) for i,j,z in old['entries']});fm=(fm-sy.trace(fm)*sy.eye(16)/16).applyfunc(sy.expand);assert not any(v.has(loc['z_psi']) for v in fm)
oldzero=dec({'shape':[16,16],'entries':[[i,j,str(z)] for (i,j),z in fm.todok().items()]});derived=dec(P['derived_traceless_dimensional_kinetic_representative']);zero(minus(derived,oldzero));positive=scale(derived,Q(-1));oldpositivechanges=len(minus(derived,positive).d);assert oldpositivechanges==16
for c,t in enumerate(T):zero(minus(minus(mul(derived,t),mul(t,derived)),dec(P['response_p']['dimensional_fixed']['left'][c])))
# Equal widths are an insensitive projection,not a selected physical gauge.
def samewidth(z):
 v={}
 for (h,x,r,j),q in z:v[0,h+x,r,j]=v.get((0,h+x,r,j),0)+q
 return canon(v)
for m in partner:zero(Mat(16,16,{ij:samewidth(z) for ij,z in m.d.items()}))
D,w=sy.symbols('D width');wrong=4/D+(w-1)*24/(D*(D+2));correct=w*4/D;bb_error=sy.factor(-2*sy.diff(wrong-correct,D).subs(D,4));assert sy.simplify(bb_error-(w-1)/3)==0
ml=list(map(dec,d['MVS']['loop_left']));mr=list(map(dec,d['MVS']['loop_right']));endpointchanges={'omit_left':sum(len(m.d) for m in ml),'omit_right':sum(len(m.d) for m in mr)};assert all(v>0 for v in endpointchanges.values())
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for x in [P,R]:assert not any(x[k] for k in ['physical_scheme_adopted','quantum_coefficient_fitted','full_q_or_nonlinear_Slavnov_QAP_measure_phase_E5A5_qualified','z_psi_selected'])
print('RESULT '+json.dumps({'status':'QUALIFIED_ACTUAL_TWO_WIDTH_GAUGE_SOURCE_HEAT_P_RESPONSE','elapsed_after_imports':time.perf_counter()-tick,'response_color_positions_compared':positions,'units':P['units'],'actual_source_partner_equals_CW_commutator':True,'actual_GTT_bare_dimensional_p_matches':True,'actual_VFC_FHK_PSF_relative_p_matches':True,'g2_and_Yukawa_p_exclusions_authenticated':True,'all45_ghosts_and_zero_complements_match':True,'H12_projection_zero_and_insensitive':True,'equal_width_projection_zero_and_insensitive':True,'derived_negative_traceless_CW_over6_equals_old_CFC_F0':True,'old_positive_compact_diagnostic_changed_positions':oldpositivechanges,'old_positive_compact_failure_preserved':True,'z_psi_selected':False,'source_endpoint_omission_changed_positions':endpointchanges,'wrong_barred_BB_dimension_jet_error':str(bb_error),'response_nonzero_counts':count,'no_loop_momentum_translation_needed':True,'q_slot_response_derived':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_nonlinear_Slavnov_QAP_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
