"""GHP1 fixed color partner and bounded actual constant-ghost response IO."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('GHP1_PEER_OR_WARD_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_ghost_triangle_field_insertion','canonical_so10_coupled_fermion_finite_counterterm','canonical_so10_open_fermion_heat_kinetic','canonical_so10_proper_matter_source_finite','canonical_so10_matter_gauge_vertex_finite_color'] and p.name.endswith('.gz'):raise PermissionError('GHP1_INSERTION_OR_COUNTERTERM_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def trace(a):
 z=Z
 for i in range(min(a.r,a.c)):z=add(z,a.d.get((i,i),Z))
 return z
def finish(role,units,scalars,partner,d,tick,method):
 T=list(map(dec,d['Y']['Tminus']));cw=dec(d['GFK']['gauge_kinetic_left']);cf=dec(d['GFK']['full_internal_Casimir']);comm=[minus(mul(cw,t),mul(t,cw)) for t in T]
 for a,b in zip(partner,comm):zero(minus(a,b))
 for t in T:zero(minus(mul(cf,t),mul(t,cf)))
 response={name:{'left':[enc(scale(p,Q(co))) for p in partner],'right':[enc(scale(trans(p),Q(co))) for p in partner]} for name,co in units.items()}
 traceless=minus(cw,scale(ident(16),prod(trace(cw),Q('1/16'))));kinetic=scale(traceless,Q(units['dimensional_fixed']))
 doc={'method':method,'units':units,'scalar_integrals':scalars,'source_partner':list(map(enc,partner)),'response_p':response,'derived_traceless_dimensional_kinetic_representative':enc(kinetic),'role':role,'elapsed_after_imports':time.perf_counter()-tick,'ordinary_order':'g10^3/(16*pi^2)','gauge_widths':'eta_H_and_xi_symbolic','constant_ghost_projection':'q=0,p_hat=0,p_E^2>0','source_partner_matches_actual_CW_commutator':True,'source_both_endpoints_retained':True,'transverse_CF_p_component_zero':True,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_q_or_nonlinear_Slavnov_QAP_measure_phase_E5A5_qualified':False,'z_psi_selected':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(doc,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':doc['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
