"""GHP1 freeze actual source endpoints and constant-ghost Ward kernels."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-source-heat-p-response-v1-2026-10-23');PRED=CAL/'canonical_so10_yukawa_heat_ward_response'
BASE='8ffdfddea2fbd48f3070c8833ce77ce859c8bb18';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32466
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json','primary_tables.json.gz','replay_tables.json.gz']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V548.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [
 ('canonical_so10_matter_vector_source_pole',['RECORD.md','DERIVATION.md','RESULT.md','primary.py','replay.py','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_fermion_gauge_kinetic_pole',['RECORD.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_ghost_triangle_field_insertion',['RECORD.md','RESULT.md','comparison_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_gauge_fermion_insertion',['RECORD.md','DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_coupled_fermion_finite_counterterm',['DERIVATION.md','RESULT.md','family_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),
 ('canonical_so10_proper_matter_source_finite',['DERIVATION.md','validation_receipt.json']),
 ('canonical_so10_open_fermion_heat_kinetic',['DERIVATION.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
for role in ['primary','replay']:
 yp=CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz');add(yp);y=packed(yp)
 g=packed(CAL/('canonical_so10_fermion_gauge_kinetic_pole/'+role+'_tables.json.gz'));m=packed(CAL/('canonical_so10_matter_vector_source_pole/'+role+'_tables.json.gz'))
 keys=['loop_left','loop_right'] if role=='primary' else ['symmetric_spinor_products']
 d={'Y':{k:y[k] for k in ['Tminus','H_new']},'GFK':{k:g[k] for k in ['gauge_kinetic_left','full_internal_Casimir']},'MVS':{k:m[k] for k in keys}}
 assert m['phase_including_derivative']=='1' and m['UV_unit']=='1' and m['formal_order']=='g10^3'
 gz(HERE/(role+'_inputs.json.gz'),d);add(HERE/(role+'_inputs.json.gz'))
q=CAL/'canonical_so10_matter_gauge_vertex_finite_color/comparison_tables.json.gz';add(q)
cfc=packed(CAL/'canonical_so10_coupled_fermion_finite_counterterm/family_tables.json.gz')
controls={'GTT':packed(CAL/'canonical_so10_ghost_triangle_field_insertion/comparison_tables.json.gz')['complete_cPP_components'],'VFC':packed(q),'CFC':cfc['family']['gauge']}
gz(HERE/'validation_control_inputs.json.gz',controls);add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and not d['active_A10_M08_python_processes'] and d['files_written']==0
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'GHP1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('GHP1_FROZEN',len(bind),'bindings',flush=True)
