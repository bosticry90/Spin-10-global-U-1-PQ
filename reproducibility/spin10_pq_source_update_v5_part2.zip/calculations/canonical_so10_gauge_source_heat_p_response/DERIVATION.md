# GHP1: source endpoints must precede constant-ghost heat differentiation

Set Q=k²,R=(k-p)²,b=bar_k²,s=bar_slash(k),v=bar_slash(p),p_hat0.
The actual full BB contraction at the ghost/source vertex gives Wk/Q
BEFORE barred fermion endpoints. Therefore the source uses the full Q
denominator,not b in place of Q. At q=0 the external-C derivative vanishes;
the actual remaining GF tensor is UA-UB. Both ordered source endpoints
have numerator

 v(s-v)s=s(s-v)v=b v-p² s.

Define A_s=(b v-p² s)/(Q²R),L_s=s(s-v)s/(Q²R). Actual ordered Clifford
algebra gives

 A_s-L_s = -s/Q² + hat_k²*s/(Q²R).

The first term is an odd tadpole;the second is the actual hatted defect.
There is no loop-momentum translation in this constant-ghost identity.
The two source colors are ML and MR.T in the actual Euler convention.
Their common p partner is P_c=i(ML_c+MR_c.T),not an auxiliary commutator
assumed in advance. Recover it independently from actual ordered MVS
tensors or its symmetric spinor-product reduction. Compare to the actual
longitudinal kinetic commutator [CW,T_c];the transverse CF commutator
must independently be zero. This supplies the model color Ward partner,
not a color coefficient fitted to a desired finite response.

In strict4D the exact scalar heat factors are
 H_s=exp[-2t(2Q+R)],H_k=exp[-2t(Q+R)].
Source A_s at p0 iszero;kinetic L_s at p0 is+s/Q². At first p jet both
unheated kernels give v/Q² at strict4D. Thus the length mismatch yields
P_c*16pi² integral(e^-6tQ-e^-4tQ)/Q². Heat Taylor terms must also remain.
Equivalently use the exact endpoint identity to split

 H_s A_s-H_k L_s=(H_s-H_k)L_s-H_s*s/Q² (strict4D).

Differentiating the first coefficient contributes the difference of the
length6 andlength4 positive Gaussian power integrals. Differentiating
the second odd endpoint contributes its length6 power integral. Their
sum equals minus the length4 kinetic heat Taylor constant. Do not erase
the unvaried odd integral before differentiating its regulator. No extra
routing boundary or Yukawa scalar-current term is added to this identity.

For the dimensional term retain internal hat rankh=D-4 until integration.
The odd term has zero parity integral in a common rotation-invariant
completion. The first p jet of hat_k²*s/(Q²R) is
2*hat_k²*(k.p)*s/Q⁴. Its normalized joint angular moment is
2h/[D(D+2)] times the logarithmic radial integral. Independently,
the actual critical source/kinetic units are4/D and2/D+12/[D(D+2)];
their difference equals2(D-4)/[D(D+2)]. Fresh Gamma integration fixes its
finite coefficient;it is not determined from an old F or a relative target.

Domain:with q=0,p²>0 the actual source numerator saves one power at the
merged massless ghost/vector node,so pole<=3 in4D. At k=p the actual
fermion numerator saves one power;first p differentiation leaves pole<=2.
Longitudinal two-point entries are also locallyintegrable,with numerator
retained. Positive heat gives UV decay. These explicit majorants admit
the selected constant-ghost restriction and first p variation;they are
not a theorem for arbitrary exceptional momenta or composite products.
After the common UV symbol is subtracted,the difference is integrable;
heat derivatives of its lower homogeneous terms vanish by power bounds.
Use a smooth positive auxiliary completion for each critical moment if
needed,with the same subtraction on both sides. No scaleless full diagram
is assignedzero or physical IR normalization altered.

After independent dimensional and heat calculations,form their relative
p coefficient and compare to the stored GTT bare insertion and FHK/PSF
relative image. The source/kinetic inverse signs,full-D contraction and
both source endpoints are already fixed by the action. The p test cannot
qualify q,where external ghost derivatives and gauge vertices remain.

The finite dimensional coefficient also predicts a trace-zero kinetic
commutator representative from the measured CW. Test its sign against
the preserved CFC family only AFTER deriving the integral. Subtracting
the trace merely isolates its commutator representative;it leaves the
original free z_psi family and positive-sign failed diagnostic intact.
