# GHP1: actual two-width gauge/source constant-ghost p response

Base8ffdfddea2fbd48f3070c8833ce77ce859c8bb18/main32466oldblobs.
PreviousgoalturnPROGRESSVFC andYHT. WholeSpin(10)xPQ ACTIVE/incomplete,
state113/34of39. Recover AGENTS/preflight/current receipts;no live worker
or uncommitted work. No physical input or scheme is changed.

Scientific question:derive the ACTUAL ordinary g10³ cPP p response of the
gauge/source one-loop family at external ghost q=0,physical p_hat0,p_E²>0.
Use actual MVS GF-source endpoints,full BB inverse and SMA physical pp
numerator/source signs. Do not transfer the Yukawa N/X formula to gauge.
Keep eta_H,xi general and all45 ghosts/16carrier components/bothchiralities.
The q slot,full background and nonlinear multiple-source extension stayopen.

Derive the exact source-spin/longitudinal-kernel identity at arbitrary
ordinary p before heat/Taylor expansion,including internal hats. Derive
all positive-heat endpoint factors before canceling inverses. The odd
tadpole has zero unvaried integral but a nonzero differentiated heat
weight;retain it. Fresh dimreg joint hatted/barred moments determine the
bare p insertion. Never assign it from a counterterm or observed remainder.

Primary uses explicit barred4 gamma matrices for exact source endpoints,
longitudinal kernel and first p jet;direct Gamma/radial integrals for
dimensional term;actual ordered MVS endpoint matrices for the source color.
Replay uses formal Clifford identities,independent Gaussian joint moments
and positive heat differentiation;independent MVS symmetric-product and
GFK species/Casimir data for color. Both construct the actual source
partner i(ML+MR.T) and independently test its relation to [CW,T]. Keep
nonadjoint source pieces;do not use the auxiliary anti-Hermitian shortcut.

This admits the constant-ghost restriction only after explicit soft bounds:
the merged ghost/vector source node has an actual fermion/derivative
numerator leaving pole<=3;the longitudinal physical two-point node is
locallyintegrable;first p variations at fixed p²>0 have pole<=3. No
exceptional full zero-momentum integral,constant vacuum or arbitrary IR
contact is adopted. Smooth common UV completions may compute local
constants;prove their integrable remainder contributeszero at t0.

Both calculations finish before the gate reads GTT's complete measured
bare p insertion,FHK/PSF's relative p comparison or CFC's constructed F.
Require full agreement,including zeros,reality/rightmomentumreversal,H12
covariance and actual old bare/relative coefficients. Preserve any mismatch.
The earlier POSITIVE compact F diagnostic failed;test any newly derived
formula only as a LATE comparison. Its coefficient must follow from the
hatted integral,not a fitted rescaling. Free z_psi remains symbolic;trace
projection of F does not choose z_psi. Old failure evidence stays unchanged.

Controls omit the odd endpoint heat term,eachsourceendpoint,vector-jet
GF branch,dimension continuation,full-D BB contraction,transpose routing,
or average widths. Explicitly record insensitive H/equal-width projections.
q-only GFI/Yukawa/bosonic-source carriers and lower-source p0 exclusions
are authenticated structural inputs,not new expensive model integrations.

Freeze eight sources/copies,derivation/immutable packets/limits first.
Sequential P/R/gate600safterimports,8GiB sampledprivate,350MiB launchfloor,
16MiB storedpacket. Fresh E4 this goalturn plus newbytepreflight. Custody
exit2sevenNOTPASS. Stopfirstfailure,preserve full captures/failed sources,
version corrections. No agents,branch/worktree,reset,resource expansion,
adoption,protectedstageactivation,push,publication or outreach.

Ceiling:actual selected ordinary gauge/source constant-ghost p response
and relative Ward comparison,not complete q/nonlinear Slavnov restoration,
QAP/products,measure/phase,physical chiral prescription,massiveC1,E5/A5 or
physical GUT. Bothscalarwarnings,quartetFAIL,flavorpause,HB1/C5 blocks,
custody and all distinct free constants remain. Shared action/data/analytic
assumptions,Python/SymPy and AI author are not independent science.
