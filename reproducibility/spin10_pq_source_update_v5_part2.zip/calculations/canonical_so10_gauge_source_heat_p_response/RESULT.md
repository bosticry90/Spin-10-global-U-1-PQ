# GHP1: actual two-width gauge/source heat p response

The selected ordinary g10³ constant-ghost p response is qualified for the
actual source and longitudinal fermion kernels. In common g10³/(16pi²)
units,with P_c=[CW,T_c],the result is

```
R_heat,p = -[log(3/2)+1/4]*P_c,
R_dim,p  = -P_c/6,
R_dim,p-R_heat,p = [log(3/2)+1/12]*P_c.
```

Both regulator responses were calculated before reading the stored GTT
insertion or VFC/FHK/PSF relative p image. They agree exactly with those
late comparators. This independently explains the previously measured
ordinary p remainder;it does not qualify the q slot or full nonlinear
Slavnov/QAP/source construction. No physical prescription is adopted.

Receipt validation_receipt.json SHA256
587dc13e1f076b5ce0ab738e79a8ff77b4a1cee2ddf90152d6ef4466d7ba84ae,
status QUALIFIED_ACTUAL_TWO_WIDTH_GAUGE_SOURCE_HEAT_P_RESPONSE.
State113/authority34of39 unchanged;scientific/director acceptance
NOT_PERFORMED. Whole investigation ACTIVE/incomplete.

## Exact source endpoints determine the regulated kernel

Both actual source spin orientations reduce to b*v-p²*s,where
b=bar_k²,s=bar_slash(k),v=bar_slash(p). Against the actual longitudinal
kernel L=s(s-v)s/(Q²R),Q=k²,R=(k-p)²,the exact identity is

```
A_source-L = -s/Q² + hat_k²*s/(Q²R).
```

This is a new actual gauge/source identity,not a Yukawa formula with a
Casimir replacement. The full-D BB contraction at the source is performed
before restricting physical spin endpoints. The model source partner is
i(ML+MR.T),using both nonadjoint source matrices. Primary reconstructs it
from actual ordered MVS matrices;replay uses the independent symmetric
spinor-product reduction. Both equal the independently supplied actual
[CW,T_c]. The transverse CF commutator vanishes separately.

The strict4D source has heat exp[-2t(2Q+R)] and the kinetic kernel has
exp[-2t(Q+R)]. The exact odd tadpole is zero before p variation,but its
heat depends on p. It cannot be dropped before differentiating. The
positive-heat groups are

| Group | p coefficient multiplying P_c |
| --- | ---: |
| Length6 versus4 mismatch | -log(3/2) |
| Paired heat Taylor difference | -1/12 |
| Odd source-endpoint heat Taylor term | -1/6 |
| Total fixed heat term | -1/4 |

The dimensional hatted term has first p jet
2*hat_k²*(k.p)*s/Q⁴. Actual joint moments give2h/[D(D+2)],h=D-4,
not the product2h/D² of uncorrelated averages. Independent Gamma/radial
and Gaussian calculations give its finite coefficient-1/6. Source and
longitudinal angular units4/D and2/D+12/[D(D+2)] differ by the same
2(D-4)/[D(D+2)]. No inverse coupling/width or fitted normalization appears.

The admitted projection is q_ghost=0,p_hat0,p_E²>0,not arbitrary
exceptional momenta. Actual source numerators leave merged soft degree<=3;
the first fermion-momentum derivative is locallyintegrable. This justifies
the selected restriction and first variation before using common smooth
UV completions. No full scaleless integral is assignedzero or physical
IR contact added. No loop-momentum translation is needed for this identity.

## Complete retained comparison and the old compact diagnostic

All161,280 retained response positions,including zeros,agree between
routes. Each nonzero direction has512 positions per chirality. Right p
matrices are the transpose,as required by physical momentum reversal.
All12 H projections and the counterfactual equal-width limit arezero;
they are insensitive controls,so the test retains all45 ghost directions.
The actual lower-order and Yukawa p exclusions are authenticated from
the completed GTT catalogue. They are not newly re-integrated.

Omitting either source endpoint changes720 positions. Dropping the odd
heat endpoint or paired heat term changes the finite response. Performing
the source BB contraction in the barred subspace gives a finite unit error
(w-1)/3,despite the same pole. Joint hatted/barred moments and internal
dimensions must therefore remain through the finite calculation.

The independently derived dimensional coefficient predicts

```
F0 = -(CW-Tr(CW)I/16)/6.
```

Only after deriving-1/6 from the integral did the verifier compare this
expression with the old CFC family. It equals the actual trace-zero F0
exactly. The earlier POSITIVE-sign compact diagnostic still differs at16
positions and remains FAILED in its original evidence. This result does
not reverse or relabel that failed test. It establishes a differently
signed relation from the actual Ward kernel,without fitting a rescaling.
Subtracting the trace does not choose the old free z_psi;its family remains.

## Execution and next scientific action

Eight source copies and1381/1389 initial/validation bindings frozen before
sequential primary/replay/gate. Native exits0;3.8805480/1.6955995/2.6646162s
afterimports. Their3/2/2 private-memory samples have maxima57,954,304/
53,137,408/58,937,344 bytes,not peaks. Frozen600s each/8GiB sampledprivate/
350MiB launchfloor/16MiB packet respected. No failed worker,gate or
controller. Complete sources/native captures are retained internally and
externally in gauge-source-heat-p-response-v1-2026-10-23. Fresh E4 command
executed this goalturn,native0,steps0,0,0,0,0,2;new bytepreflight ran.
Historical custody remains exit2/seven unresolved NOTPASS.

The next indispensable target is the complete ordinary q response with
external ghost derivatives and nonlinear source products. The p identity
does not justify dropping UC or using only H projections there. A useful
bounded route is to derive the actual one-loop cutoff/source Ward operator
from the finite graded Gaussian and Legendre/source identities,then expand
its positive-heat Born words for the cPP target. Include the source/Euler
connected term that cancels the classical nonlinear R''*E term. Fix all
graded signs and inherited Wick factors before interpreting the operator.
After inverse cancellations retain(1-E) factors,E=exp(-2tP),rather than an
uncontrolled inverse heat. YHT and this new p identity are independent
normalization controls,not substitutes for a complete q calculation.

Shared physical action,source/scalar conventions,representation data,
analytic assumptions,Python/SymPy and AI author limit independence. This
is bounded computational/analytic corroboration,not external scientific
or physical validation. Full q/nonlinear source restoration,products/QAP,
measure/phase,physical chiral prescription,massive matterC1,E5/A5 and
unification remain open. Both adverse scalar benchmarks,quartetFAIL,
flavorpause,HB1/C5 blocks,custody and distinct free constants remain.
No old evidence,physical input,state,foundation or scheme changed;no
agents,branch/worktree,reset,outreach,publication or remote push.
