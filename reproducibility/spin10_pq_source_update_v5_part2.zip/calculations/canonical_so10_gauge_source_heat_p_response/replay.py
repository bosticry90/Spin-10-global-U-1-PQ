"""GHP1 formal Clifford free inverse and independent Gaussian/source reduction."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');b,qt,rt,pk,p2,h=sy.symbols('barQ Q R kp p2 hatQ');slash,pslash=sy.symbols('slash pslash',commutative=False)
As=b*pslash-p2*slash;Ls=(b-2*pk)*slash+b*pslash;assert sy.expand(As-Ls+(b-2*pk+p2)*slash)==0
assert sy.expand(As-Ls+(qt-2*pk+p2)*slash-h*slash).subs(qt,b+h).expand()==0
J=sy.symbols('J0:4');g=sy.exp(sum(x*x for x in J)/4);origin=dict.fromkeys(J,0);mom=sy.diff(g,J[0],2).subs(origin);sphere=mom/(sy.Rational(4,2));assert sphere==sy.Rational(1,4)
t,z=sy.symbols('t z',positive=True);length=-sy.integrate(1/z,(z,4,6));jet6=4*t*sphere/(6*t);jet4=4*t*sphere/(4*t);pair=sy.factor(jet6-jet4);odd=-jet6;heat=sy.factor(pair+odd)
# Full joint hat/bar moment: h delta/[D(D+2)],not h/D times delta/D.
eps,hh=sy.symbols('epsilon hat_rank');D=4-2*eps;regular=2*hh/(D*(D+2))*sy.gamma(4-eps)/(6*sy.gamma(2-eps))*sy.gamma(1+eps);insertion=sy.simplify(sy.diff(regular.subs(hh,-2*eps),eps).subs(eps,0))
units={'heat_length_log':'-1','heat_pair_Taylor':str(pair),'heat_odd_endpoint_Taylor':str(odd),'heat_total_fixed':str(heat),'dimensional_fixed':str(insertion),'relative_log':'1','relative_fixed':str(insertion-heat)}
partner=[scale(dec(m),Q('2*I')) for m in d['MVS']['symmetric_spinor_products']]
finish('replay',units,{'length_difference':str(length),'joint_hat_integral':str(insertion),'Gaussian_component_moment':str(sphere),'heat6_Taylor':str(jet6),'heat4_Taylor':str(jet4),'odd_endpoint_before_variation':'0_by_parity','exact_source_endpoint_and_hat_remainders':0},partner,d,tick,'formal_ordered_source_inverse_identity_Gaussian_joint_hat_moment_symmetric_color_reduction')
