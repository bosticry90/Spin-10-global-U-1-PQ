# An odd-order translation error is corrected; the selected pole and c/h tests pass

The action-level audit identifies a real error in the earlier vacuum/source
interpretation. GTT stored the ordinary ghost-vector vertex in antighost-first
a C order. The later GVC/VSC sewing combined it with a scalar vertex written
in ghost-first C a order without the required odd-interchange minus sign.

The previous paired-mode Gaussian check inherited that wrongly ordered source.
It correctly checked its Gaussian, but could not validate the omitted action
translation. This is a shared interpretation failure across those checks.
The correction and its consequences are documented in CORRECTION_SCOPE.md;
all historical sources, outputs, receipts and failures remain unchanged.

## Action audit and exact transport

Primary parses5640 literal ordinary GF rows in explicit C-left order at all
four Lorentz components. Replay independently reconstructs the density from
1494 mu0 Euler/field-map products and exterior odd ordering. They agree on all
273375 raw jet positions, including zeros. The literal four-component checks
cover1093500 positions; these are Lorentz copies, not additional independent
physics tests. The sign conversion changes1410 nonzero stored jet positions.

With the actual Wick factors and paired B/Lambda propagators, both source
methods give the effective orbit unit-1 relative to the OLD GTT V table.
This changes no free propagator, physical parameter, scalar vertex or radial
moment. Each affected orbit graph has that ordinary vertex exactly once.
Linearity therefore transports its qualified expression with one minus sign.
Both old quantum methods yield identical corrected coefficients; this is not
a new independent integration of their loops.

The late gate checks138240 corrected GVC positions and44280 source positions,
then138240 Euler comparison positions and335872 inherited h-candidate slots.
Both symbolic Yukawa carriers, both chiralities, all45 ghosts and the full
328-source zero complement are retained. Source scalar/orbit/total each have
424 nonzero positions. The126 matter components each have85 nonzero positions
per chirality;10 is zero at this v only, not in the general theory.

## What changes scientifically

Put D_R=B_R K v, K=Cs,I-Cs,H, and A_R,c=i(Tc^T D_R+D_R Tc), with the common
g³xiY/(16pi²) c-sector factor suppressed. The corrected full source column is

    Ltotal,c = rho_c K v

at ALL14760 source/ghost positions. Its source Euler image remains +B_R Lc,
and the corrected insertion/source relation B_R Lpiece=-2 Rpiece holds for
each scalar/orbit/total contribution and its conjugate. The earlier failed
400-position proportionality diagnostics depended on the untranslated orbit;
they do not describe this corrected source. Their historical results remain.

The corrected extra dimensional insertion is

    Rdim,c = -A_c/2,
    Rdim,h = -B K h/2.

Thus the previously specified HPR candidate Cv, with coefficient+1/2, cancels
both ISOLATED selected components. The earlier1/2 versus9/50 conflict no longer
excludes that candidate for the actual corrected inputs. No new counterterm
coefficient was fitted, and no counterterm or physical scheme was adopted.
This does not complete the full source-containing normalization family.

The UV-pole image of the EXTRA mass/source comparison is also exactly zero.
This uses actual MFC minus YHC(v) mass coefficients, polynomial xi grade
extraction without inverse widths, and the corrected proper source Euler
column. Ordinary HSC/JMF contributions at x=v remain owned separately.

## Finite comparison and the remaining heat calculation

V2 independently derives the conjugate mass image with U=-T.T and retains
chi4,ell=log(3/2),fixed components separately. All138240 positions agree with
the full previously extracted finite image. The compact result is

    b Crel,extra,c = -(1/2 + (17/25)ell) A_c,
    b Crel,h       = -(1/2 + ell) B K h.

The chi4 component cancels separately; no baseline value was selected.
The h expression is inherited from qualified HWB/VTF. The c expression now
includes the missing properly ordered source column exactly once.

One direct ordered heat group is also evaluated: HWB's actual n2 quadratic
kernel is linear in its external odd scalar vertex, so substituting the
correct C a x coefficient gives its color factor B_R Lscalar,c. The same
finite radial difference is log(6/4). Its measured value is

    Rheat,n2,c = (17/25)ell A_c.

It equals the algebraic target Rdim,c-b Crel,extra,c at all46080 positions
across both carriers/chiralities, including zeros. This is a useful finite
check with distinct source and open-line normalizations. It DOES NOT prove
that all other ordered heat-root groups cancel. Their complete inventory and
independent summed coefficient remain the next obligation. A difference of
already defined expressions is not relabeled as a complete measured trace.

The source finite member still has heatlength4 for the scalar bubble and6
for the orbit word. Both are already owned by C_bStokes; no second copy is
added to C_joint. chi4,b0,kappa and invariant finite freedoms remain distinct.

## Scope review, execution and limits

Thirteen actual preparation manifests across HSC/JMF/HWB/MFC/HPR contain6741
recorded input bindings and no later GVC/VSC binding. This is a targeted static
dependency review, not a fresh replay or a global runtime audit. Their older
qualifications are neither withdrawn nor independently re-proved by this work.
GTT's own antighost-first calculations stay in their original convention.

Receipts:

- validation_receipt.json SHA256
  9668b172b67615880310262d5bf5ef33182126d7834fd054ad3164228335c4ce.
- finite_receipt_v2.json SHA256
  4a6ebf060177d8dceaea4b145aae923951e93a135ba0782a04354d0de5536984.

Corrected-family packed/raw SHA256:
092f670dc51051f41de026fc674e051591aa8731f60586a02474e4a7685547e7 /
0754dd46d757274bdc5d47930133d33c5928122dd0eee36b4d4c1a4b8233e3dc.
Finite-review packed/raw:
f31634d9f00552c7809215ed27f868579d45276eff1b8524e9bf457638e26fde /
b96d0ab6cc7d0ee50bd3554d081349e972ff9630a3821279a969e833054fe906.

Native P/R/gate/V2 exits0/0/0/0, times3.440914/2.461268/13.870911/7.958355s.
Sample counts3/2/8/5, max sampled private73187328/168714240/82980864/63262720B;
sampled values are not peaks.600s/8GiB/350MiB/16MiB bounds held. Twelve exact
source copies,140/148/173 bindings;246998B pre-report packet. No new failed
native worker/verifier. A read-only wildcard search returned a Windows path
syntax error; the actual V2 manifest review uses Path.glob and completed.
The substantive scientific interpretation failure is preserved explicitly.

Current delegated E4 preservation/custody checks are captured separately,
with expected exits0/0/0/0/0/2; custody remains sevenNOTPASS. Inspect the final
external before/index/after seal for local-commit completion and preservation
of all33616 older blobs. State113/authority34/39 is unchanged.

TrackA gains an action-corrected coupled source/mass prerequisite and selected
c/h candidate agreement. TrackB records an important limitation: two agreeing
Gaussian methods shared an unverified vertex-order interpretation. Actual
action/Euler reconstruction and a separate pole check exposed it. No external
scientific confirmation or proof-assistant formalization is claimed. Same
physics assumptions, data, Python/SymPy and AI author remain shared limits.

Next enumerate the complete extra GF-v ordered heat-root support using actual
CSW tangents, then calculate the n3/n4 groups independently. Keep diagonal
ghost/vector/scalar/auxiliary/matter tangents and constant B<-partial C and
a<-Lambda roots. Do not infer their sum from the desired n2-only answer.
Full nonlinear source/contact/QAP, measure/chiral phase, Lorentzian/causal and
physical vacuum limits, massive C1, E5/A5 and physical GUT remain unqualified.
All adverse benchmark evidence, quartet failure and blocked stages remain.
Whole investigationACTIVE/incomplete; no agents/branch/worktree/push/outreach.
