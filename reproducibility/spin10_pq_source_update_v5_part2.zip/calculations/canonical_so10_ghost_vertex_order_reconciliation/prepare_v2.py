from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='89e6dc95bb11dda636517d39ef7e1e7e2d84a218'
assert read(HERE/'validation_receipt.json')['pole_Slavnov_image_zero'];bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
for folder in ['canonical_so10_complete_heat_scalar_response','canonical_so10_joint_marginal_fermion_normalization','canonical_so10_tangent_heat_ward_bridge','canonical_so10_fermion_mass_finite_comparison','canonical_so10_vacuum_tangent_insertion_routing']:
 for p in (CAL/folder).glob('*preparation*.json'):
  if 'input_sha256' in read(p):bind[str(p)]=digest(p)
for n in ['FINITE_REVIEW_V2.md','finite_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 bind[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'GOR1_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GOR1_V2_FROZEN',len(bind),'bindings',flush=True)
