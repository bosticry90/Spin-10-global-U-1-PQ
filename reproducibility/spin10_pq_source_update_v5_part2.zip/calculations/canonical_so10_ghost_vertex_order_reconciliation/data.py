from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(maxsize=131072)
def simp(z):return s.simplify(z)
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def tidy(m):return s.SparseMatrix(m).applyfunc(simp)
def zero(m):assert not tidy(m).todok()
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(simp(z))] for (i,j),z in sorted(s.SparseMatrix(m).todok().items()) if simp(z)!=0]}
def clean(d):return {k:simp(v) for k,v in d.items() if simp(v)!=0}
def rows(d):return [[*k,str(z)] for k,z in sorted(clean(d).items())]
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('GOR1_PEER_DENIED')
   if p.parent.name in ['canonical_so10_vacuum_ghost_matter_companion','canonical_so10_vacuum_scalar_source_finite'] and p.suffix=='.gz':raise PermissionError('GOR1_LATE_QUANTUM_TARGET_DENIED')
 sys.addaudithook(audit);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'full_QAP_E5A5_qualified':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
