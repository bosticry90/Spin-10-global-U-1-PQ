# Exact scope of the ghost-order correction

The new evidence is GOR1's actual literal-density and Euler/field-map audit,
its qualified coefficient transport and finite review. No old evidence byte
is edited, rebound or reclassified as a different historical execution.

| Earlier evidence | What remains true | Interpretation superseded here |
| --- | --- | --- |
| GTT raw ordinary jets | Correct a-before-C coefficient tables and their original convention | They cannot be inserted directly as C-before-a scalar-source coefficients |
| GVC V3 scalar/orbit computations | The exact arithmetic for their specified vertices, both routes and preserved failures | The orbit needs the extra minus when translated to the common Ca order; the old total is not the actual selected insertion |
| GVC V4 one-direction conflict | Its algebraic diagnostic for the old total | The 1/2 versus9/50 conflict and8/25 remainder do not exclude the candidate for the corrected selected quantum components |
| GVC V5 paired Gaussian | The Gaussian equals its completed square for its GIVEN sources | Its assumed B source was not derived in the scalar's Ca order; it does not corroborate the actual positive orbit sign |
| VSC source column and V2 Euler bridge | Exact sewing/Euler comparison for the old signed input | The orbit and total must be translated; the old400-position compact diagnostic is not evidence against the corrected source identity |

The corrected orbit sign is relative to the old GTT V table. Free Green
functions, action, Wick contour, scalar source phase, radial units, masses,
couplings and normalization freedoms are unchanged. It is not a new physical
scheme or an arbitrary sign change to make a Ward equation pass. Both action
audits determined the order before access to GVC/VSC quantum outputs.

The correction is propagated by exact linearity: every affected orbit graph
contains that ordinary vertex once. It is not a new independent integration.
The late gate uses both previously completed quantum methods and compares
their full corrected coefficients and zeros. Their shared action, libraries,
source definitions and AI author remain important common-error limitations.

HPR's negative h insertion is unaffected; HPI's earlier positive trial stays
withheld. HWB's tangent identity and VTF's source phase remain in their own
qualified conventions. HSC/JMF/MFC/HPR/HWB's13 examined preparation manifests
contain6741 recorded input bindings and no later GVC/VSC binding. This limited
static review is not a new replay or a guarantee against undocumented runtime
dependencies. It supplies no reason to withdraw those results on this basis.
Nor does it independently reaffirm all their premises.

All parameter-specific physical failures, the flavor pause, HB1/C5 blocks,
historical quartet failure, scientific authority34/39 and historical custody
exit2/sevenNOTPASS remain exactly as before. The new isolated candidate test
does not qualify a full renormalized contact/source family or E5/A5.
