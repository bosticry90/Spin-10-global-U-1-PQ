"""GOR1 Euler/master-field derivation and independent exterior/Wick signs."""
from data import *
t=begin('replay');g=s.Symbol('g10');raw={j:defaultdict(lambda:s.S.Zero) for j in ['a','B','c']};d=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz');e1=read(PK/'frozen_a10_e1_fermion/replay.json');count=0
def canonical_odd_word(ids):
 mask=0;sgn=1
 for i in ids:
  assert not mask&(1<<i);sgn*=(-1)**(mask>>(i+1)).bit_count();mask|=1<<i
 return sgn
assert canonical_odd_word([0,1])==1 and canonical_odd_word([1,0])==-1
for name,erows in e1['Euler_columns'].items():
 if name not in d['master_field_maps']:continue
 parity=int(name.startswith(('bar','ub')));shift=-(-1)**parity
 for er in erows:
  for mr in d['master_field_maps'][name]:
   w=er['word']+mr['word'];base=[n.split('__')[0] for n in w]
   if len(w)!=3:continue
   bb=[i for i,n in enumerate(base) if n.startswith('B')];aa=[i for i,n in enumerate(base) if n.startswith(('bar','ub'))];cc=[i for i,n in enumerate(base) if n.startswith('C')]
   if len(bb)!=1 or len(aa)!=1 or len(cc)!=1:continue
   b,a,c=bb[0],aa[0],cc[0];jets=[i for i,n in enumerate(w) if '__' in n];assert len(jets)==1;pos=jets[0];mu=int(w[pos].split('__')[1]);r,nu=map(int,base[b][1:].split('_'));assert mu==nu
   if mu!=0:continue
   an=int(base[a][3:] if base[a].startswith('bar') else base[a][2:]);cn=int(base[c][1:]);order=[0 if k==c else 1 for k in sorted([a,c])];sgn=canonical_odd_word(order);j='a' if pos==a else 'B' if pos==b else 'c'
   co=simp(shift*sgn*s.sympify(er['coefficient'])*s.sympify(mr['coefficient'])/g);assert not co.free_symbols;raw[j][r,an,cn]+=co;count+=1
raw={j:clean(z) for j,z in raw.items()};G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz')
for j,z in raw.items():
 old={(r,a,c):s.sympify(v) for r,a,c,v in G['raw_jets'][j]}
 for k in set(z)|set(old):assert simp(z.get(k,0)+old.get(k,0))==0,(j,k)
# Independent paired Wick contractions: -1/2*(J_i G_ij J_j+transpose).
q,g,xi,V,O=s.symbols('q g xi V O',nonzero=True);JBp=s.I*g*V*q;JBm=-s.I*g*V*q;JL=s.I*g*xi*O
uplus=simp(-s.Rational(1,2)*(JBm*(1/q)*JL+JL*(1/q)*JBm)/(g*g*xi*V*O));uminus=simp(-s.Rational(1,2)*(JBp*(-1/q)*JL+JL*(-1/q)*JBp)/(g*g*xi*V*O))
finish('replay',{'method':'actual_Euler_times_field_maps_exterior_C_left_order_and_two_Wick_pairings','raw_C_left_jets':{j:rows(z) for j,z in raw.items()},'Euler_product_rows_mu0':count,'GTT_raw_density_order':'a_C_B','common_scalar_density_order':'C_a_x','ordinary_to_common_order_sign':-1,'paired_effective_units':[str(uminus),str(uplus)],'source_B_plus_unit_in_old_V':'I','old_GVC_VSC_quantum_outputs_read':False},t)
