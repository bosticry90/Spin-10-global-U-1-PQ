# GOR1 V2: finite image, one heat group and targeted dependency review

The completed native action audit proves that ordinary GTT jets are aC while
the later scalar vertex is Ca. Both independent routes give one minus sign
when converting the former to the latter. The action-derived paired Gaussian
then gives orbit unit-1 in oldV units; its old+1 computation is conditional
on an incorrectly ordered source. No old source/output byte has been changed.
The late gate transports all orbit components linearly, checks corrected
source Ltotal=rho_c K v and verifies the extra pole Slavnov image is zero.
The fixed HPR Cv(+1/2) now cancels both isolated dimensional c/h pieces.

Next bounded followup, frozen before execution: compress the already computed
FINITE comparison image, including both chiralities, and test a direct heat
group without claiming the uncomputed complete heat response. Derive the
conjugate mass image independently with U=-T.T, not a guessed common sign.
The full finite parents and source terms were already fixed before this test.

HWB's literal n2 open quadratic kernel is linear in its external odd scalar
vertex. Replace that external h*a*x coefficient by the actual C*a*x(v)
coefficient, in the now common Ca order. The two endpoints, Nambu1/2 and
root M_PC retain exactly the same exterior positions. Its color coefficient
is -i sum_a L_Ta(B F_ca)=-B sum_a rho_a F_ca=B Lscalar,c.
The radial weight remains log(6/4), independently known Frullani/Gamma and
finite at both ends. This measures the n2 DIRECT GF-SCALAR ROOT GROUP only.
Do not infer the other rooted groups vanish because this group matches an
algebraic target. No new full-heat or multiple-insertion applicability premise.

Compare that independently normalized group with the already computed target
Rdim-bC_extra at all45 ghosts/both carriers/chiralities/zero complement.
Record any nonzero complement explicitly. Extract exact compact coefficients
against A_c=i(Tc.T D+D Tc) only after tables are fixed; no parameter fitting
or counterterm adoption. chi4,ell and fixed constants remain independent.

Audit actual preparation manifests of HSC/JMF/HWB/MFC/HPR for dependencies on
the later GVC/VSC calculations. A zero static match only establishes absence
in examined declared bindings, not a global runtime audit or fresh replay.
Do not withdraw or reaffirm unrelated theorems without a real dependency.

Same600s/8GiB sampled/350MiB/16MiB and poleblind Python-B. New source copies
and manifest bind completed inputs before native projection. Failures retained.
Authority34/39/custody2sevenNOTPASS/physical warnings/blocked stages unchanged.
