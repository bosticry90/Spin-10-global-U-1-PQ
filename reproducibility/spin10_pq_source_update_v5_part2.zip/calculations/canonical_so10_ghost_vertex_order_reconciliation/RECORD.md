# GOR1: action-level odd ordering before vacuum Slavnov assembly

Frozen before calculations. Base89e6dc95bb11dda636517d39ef7e1e7e2d84a218,
main33616oldblobs; state113/34of39 unchanged. Whole goalACTIVE/incomplete.
Recovery native0, no active workers, last external afterseal native0/clean.

Question: do the GTT ordinary ghost-vector tables and GVC/VSC scalar vertices
use the same odd density order when sewn into the positive-v calculation?
Review identified GTT's extraction sign as -1 when C precedes a, whereas
GVC/VSC scalar extraction uses -1 when C follows a. This is a possible order
translation error, not yet a qualified correction. Do not alter old evidence.

Primary: extract literal GF ordinary jets in explicit C-left a-right order,
all4 Lorentz components with actual Wick factors. Compare to old raw GTT
tables only as an authenticated vertex representation. Derive paired-mode
B/L sources from the resulting vertex and complete the Gaussian square.
Replay: derive the ordinary density from original Euler columns times field
maps, retain graded shift, canonicalize exterior C,a, use plane intertwiners;
evaluate the Gaussian by independent source Wick contraction. Both deny old
GVC/VSC quantum outputs after byte authentication; no desired cancellation
tensor or counterterm coefficient is used to determine an input sign.

Separate late gate: compare both audit results, all273375 raw coefficient
positions (three jets x45^3), literal Lorentz-copy checks and zero complement.
If an orientation change is proved, derive its effect by linearity on the
completed GVC/VSC primary/replay coefficients: the orbit vertex occurs exactly
once in each declared orbit graph; direct scalar graphs have none. This is
exact transport of qualified graph expressions, not a fresh loop integration.
Both old routes must yield identical corrected tensors. Preserve originals,
all failure records and any old diagnostic that becomes source-order dependent.

Then test complete corrected source pole vs rho_c K v, and compare its actual
Euler image to corrected GVC; retain any nonzero remainder. Apply generic HSC
source/Euler phase before J0, no extra Nambu half. Extract positive-xi grade
from actual MFC-YHC(v) polynomial, not by allowing inverse widths. Combine its
field image with the measured source column into the extra finite comparison.
Keep chi4,ell=log(3/2),fixed components separate. Pole compatibility is tested
before interpreting finite cancellation. Only afterward test the existing
Cv(a=1/2) candidate fixed by HPR against the corrected isolated c/h components.
No unknown quantum coefficient, baseline or physical input is adjusted.

Admissible parents for this EXTRA coefficient-dimension1 cPP class: a proper
mass PP coefficient, and JxCv through its physical scalar Euler column.
The old coefficient-dimension0 HSC/JMF parents evaluated at x=v remain a
separate already qualified ordinary class. KP cP already has dimension4 and
cannot gain v; JB Cv has no zero-jet Lorentz index; E_Lambda/E_a have no tree
PP; JC sources vanish from this physical source-free projection. No equation
of motion quotient, inverse parameter or resummed physical mass reference.
VTF Jh supplies h only and is included in the corresponding tangent image.

Caps: sequential600s after imports,8GiB sampled private,350MiB available-
commit launchfloor,16MiB stored packet. Poleblind Python-B, exact source copies,
manifest before native workers; preserve failed/exhausted stages; no agents.
Use distinct routes and sensitive controls; report insensitive controls.
Validate before local commit, external before/index/after seals preserving
all33616oldblobs. Reuse authenticated completed VSC E4, custody2sevenNOTPASS.

Ceiling: actual order conversion, transported selected quantum coefficients,
extra local finite Slavnov comparison image and isolated candidate test.
No full heat trace integration/normalization family, nonlinear source/QAP,
multiple-insertion/measure/phase/causal/physical vacuum/C1/E5A5/GUT theorem.
No scheme/benchmark/flavor/HB1C5 activation or foundation/state promotion.
Shared action/data/software/AI author remain common-error limits. TrackB
tests a suspected shared interpretation error beyond Gaussian sign agreement;
TrackC voluntary. Next action is the actual full selected regulated identity
if prerequisites pass, otherwise diagnose the exact failed prerequisite.
