from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
D=packed(HERE/'order_corrected_vacuum_family.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-x.T for x in T]
v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV']);K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz')['kernel_chi4']);Ls=dec(D['source']['scalar']);Lo=dec(D['source']['orbit']);Lt=dec(D['source']['total']);parts=['chi4','log3over2','fixed'];models=[];positions=0;group_positions=0
def proportional(mats,ref):
 chosen=next(((j,k,z) for j,m in enumerate(ref) for k,z in m.todok().items()),None)
 if chosen is None:
  assert all(not tidy(x).todok() for x in mats);return {'reference_zero':True,'all_maps_zero':True}
 j,k,z=chosen;ratio=simp(mats[j][k]/z);rem=[tidy(a-ratio*b) for a,b in zip(mats,ref)];assert all(not x.todok() for x in rem)
 return {'reference_zero':False,'ratio':str(ratio),'nonproportional_remainder_nonzero':0,'full_positions_checked':45*256}
for idx,carrier in enumerate(['10','126']):
 B=dec(Y['B'+carrier]);mass=s.Matrix(16,16,list(B*K*v));A=[tidy(s.I*(x.T*mass+mass*x)) for x in T];AA=[tidy(s.I*(x.T*s.conjugate(mass)+s.conjugate(mass)*x)) for x in U];rec={'carrier':carrier,'compact_finite':{},'compact_n2_heat':{}}
 for side,BB,gen,ref in [('holo',B,T,A),('anti',s.conjugate(B),U,AA)]:
  images={};targets={};n2=tidy(BB*Ls);srcmap={'chi4':BB*Lt,'log3over2':BB*Lo,'fixed':s.zeros(256,45)}
  for p in parts:
   dm=dec(D['models'][idx]['mass_extra_by_finite_part'][p]);dm=dm if side=='holo' else s.conjugate(dm);arr=[];target=[]
   for c,tc in enumerate(gen):
    mm=tidy(s.I*(tc.T*dm+dm*tc)+s.Matrix(16,16,list(srcmap[p][:,c])));old=dec(D['models'][idx]['finite_extra_Slavnov_image'][p][c]);zero(mm-(old if side=='holo' else s.conjugate(old)));arr.append(mm);positions+=256
    ins=dec(D['models'][idx][('' if side=='holo' else 'anti_')+'total'][c]) if p=='fixed' else s.zeros(16);target.append(tidy(ins-mm))
   images[p]=arr;targets[p]=target;rec['compact_finite'][side+'_'+p]=proportional(arr,ref)
  for c in range(45):
   zero(targets['chi4'][c]);zero(targets['fixed'][c]);zero(targets['log3over2'][c]-s.Matrix(16,16,list(n2[:,c])));group_positions+=256
  n2arr=[s.Matrix(16,16,list(n2[:,c])) for c in range(45)];rec['compact_n2_heat'][side]=proportional(n2arr,ref)
  rec[side+'_algebraic_target_minus_direct_n2_remainder_nonzero']=0
 models.append(rec)
audit=[]
for folder in ['canonical_so10_complete_heat_scalar_response','canonical_so10_joint_marginal_fermion_normalization','canonical_so10_tangent_heat_ward_bridge','canonical_so10_fermion_mass_finite_comparison','canonical_so10_vacuum_tangent_insertion_routing']:
 for p in sorted((CAL/folder).glob('*preparation*.json')):
  d=read(p)
  if 'input_sha256' not in d:continue
  hits=[key for key in d['input_sha256'] if any(z in key for z in ['canonical_so10_vacuum_ghost_matter_companion','canonical_so10_vacuum_scalar_source_finite'])];assert not hits
  audit.append({'path':str(p),'sha256':digest(p),'input_bindings_examined':len(d['input_sha256']),'later_GVC_VSC_bindings':hits})
assert audit
out={'status':'QUALIFIED_CORRECTED_FINITE_IMAGE_SELECTED_N2_HEAT_GROUP_AND_SCOPED_DEPENDENCY_REVIEW','finite_coefficients_checked':positions,'n2_group_target_positions_checked':group_positions,'models':models,'dependency_manifests':audit,'new_complete_heat_trace_qualified':False,'n2_only_not_complete_other_root_groups':True,'uncomputed_root_complement_independently_zero_proved':False,'full_counterterm_family_QAP_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','elapsed_after_imports':time.perf_counter()-t}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'finite_image_review_v2.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({**out,'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
