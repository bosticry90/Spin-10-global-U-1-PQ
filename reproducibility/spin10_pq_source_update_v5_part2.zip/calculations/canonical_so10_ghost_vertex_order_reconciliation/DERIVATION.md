# GOR1: density order, conditional Gaussian signs and pole compatibility

The actual GTT primary coefficient extractor uses

    odd=-1 if position(C)<position(a) else1.

This is a coefficient of a C B, with antighost first. In contrast, the GVC
and VSC scalar GF extractors use -1 if position(C)>position(a) else1, which
is a coefficient of C a x. These are legitimate separate conventions, but
they differ by one odd interchange. A source J_B even in the quantum B field
must use one explicit density order before scalar and orbit vertices are sewn.

Re-extract the actual action, not just those code lines. For a Minkowski
Lorentz contraction, temporal continuation gives action(-1)*i*i=+1;
spatial continuation gives action(-1)*metric(-1)=+1. Therefore a normalized
ordinary coefficient has the same sign in the Euclidean density. Fourier
partial->iq then fixes each derivative jet. The GF Lambda-x term instead
has action(-1)*Lambda(-i)=+i. Scalars and ghosts remain unchanged.

For zero external ghost momentum, p_a=-q,p_B=q. Let V_old=UA_old-UB_old
refer to the original GTT antighost-first coefficients. If action extraction
confirms the expected order conversion, the C-left source is +ig V_old q C a,
not the -ig V_old q C a assumed by GVC's later paired-mode review. The latter
review tested its given source and Gaussian consistently; it did not derive
that source's odd order from the original GF density. A conditional Gaussian
agreement cannot settle this omitted translation. The new native results,
not this prospective argument, determine the qualified orientation.

Use paired fields B+,B-,Lambda+,Lambda- and actual symmetric paired Green
matrix with G_B+,Lambda-=-q/Q, G_B-,Lambda+=+q/Q and transposes. Substitute
the action-derived ordinary sources and +igxi O x at both Lambda endpoints.
The cross coefficient from -J^T G J/2 is independently recovered by two
Wick pairings. Keep the original V5 calculation as exact historical evidence.

Linearity: each GVC and VSC orbit graph has precisely one ordinary GF vertex.
Their direct GF-scalar graph has none. A proven sign conversion at that vertex
therefore changes each orbit component by that sign, with all loop moments,
source phases, other Wick factors, scalar coefficients and physical inputs
unchanged. No additional graph integration or fitted counterterm is needed.

For the positive-v comparison, let D_R=B_R K v and
A_R,c=i(Tc^T D_R+D_R Tc). The ordinary HSC class at x=v stays separately
accounted for. The extra proper mass comparison is obtained from the actual
MFC-YHC(v) coefficients. Its known GF-auxiliary structure is
-(chi4+ell+1/2)D_R, but the gate re-extracts it rather than using a desired
Ward target. In each finite component the mass field image is iL_T(deltaM).
The extra source Euler image is +B_R L_c, source-left, with no extra half.
Thus the extra comparison image is

    bC_extra = iL_T[CM-CY(v)] + B_R[chi4 Ltotal+ell Lorbit].

All common g³xiY/(16pi²) factors are stripped only after polynomial grade
extraction. The chi4 term is also the UV-pole compatibility test. The h image
uses the already qualified HWB mass derivative and VTF Jh source contribution:
bC_h=-(ell+1/2)BKh. No c contribution is silently assigned to Jh at h0.

The dimensional insertion is independently measured GVC for c and HPR for h.
The fixed HPR candidate Cv has coefficient+1/2, with field images +A_c/2 and
+BKh/2. Test these only after the corrected quantum inputs are established.
Even success concerns those isolated selected components. It neither proves
the full source counterterm family nor supplies a missing multiple-product
domain or the actual complete heat-response calculation by subtraction.

Preserve operator ownership in C_bStokes and retain chi4,b0,kappa and all
invariant normalization freedoms symbolically. Any inferred heat difference
is a target unless independently justified by the common operator domain and
complete ordered trace. Do not label a computed algebraic remainder an anomaly.
