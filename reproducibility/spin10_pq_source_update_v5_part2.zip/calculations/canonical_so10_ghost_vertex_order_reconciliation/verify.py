from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method']
assert P['raw_C_left_jets']==R['raw_C_left_jets'];assert P['ordinary_to_common_order_sign']==R['ordinary_to_common_order_sign']==-1
assert P['paired_effective_units']==R['paired_effective_units']==['-1','-1'];assert not P['old_GVC_VSC_quantum_outputs_read'] and not R['old_GVC_VSC_quantum_outputs_read']
GG=CAL/'canonical_so10_vacuum_ghost_matter_companion';SS=CAL/'canonical_so10_vacuum_scalar_source_finite'
gp,gr=[packed(GG/(n+'_tables.json.gz')) for n in ['primary','replay']];sp,sr=[packed(SS/(n+'_tables.json.gz')) for n in ['primary','replay']]
source={};source_positions=0
for part in ['scalar','orbit','total']:
 a=dec(sp['scalar']) if part=='scalar' else -dec(sp['orbit']) if part=='orbit' else dec(sp['scalar'])-dec(sp['orbit'])
 b=dec(sr['scalar']) if part=='scalar' else -dec(sr['orbit']) if part=='orbit' else dec(sr['scalar'])-dec(sr['orbit']);zero(a-b);zero(a-s.conjugate(a));source[part]=tidy(a);source_positions+=328*45
phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');v=dec(phys['vacuum']['VEV']);K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz')['kernel_chi4']);kv=K*v;off=0;refparts=[]
for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
 rho=list(map(dec,phys['representation_matrices'][sec]));vv=kv[off:off+n,0];off+=n;refparts.append(s.SparseMatrix.hstack(*[tidy(r*vv) for r in rho]))
ref=s.SparseMatrix.vstack(*refparts);source_rem=tidy(source['total']-ref);oldsource_rem=tidy(dec(sp['total'])-ref)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));models=[];gvc_positions=0;euler_positions=0;h_positions=0;counts={};candidate_pass=True;pole_pass=True;controls={}
MFC=CAL/'canonical_so10_fermion_mass_finite_comparison';YHC=CAL/'canonical_so10_yukawa_vertex_heat_comparison'
mp,mr=[packed(MFC/(n+'_tables.json.gz')) for n in ['primary','replay']];yp=packed(YHC/'primary_tables.json.gz');yr=packed(YHC/'replay_v3_tables.json.gz');xi=s.Symbol('xi');parts=['chi4','log3over2','fixed']
def proj(tab):
 out=s.zeros(256,1)
 for i,j,z in tab['entries']:
  if v[j]:out[i]+=s.sympify(z)*v[j]
 return s.Matrix(16,16,list(out))
def grade(m):
 out=s.zeros(*m.shape)
 for (i,j),z in s.SparseMatrix(m).todok().items():
  pol=s.Poly(s.expand(z),xi);assert all(mon==(1,) for mon,c in pol.terms() if c!=0),(i,j,z);out[i,j]=pol.coeff_monomial(xi)
 return tidy(out)
for idx,carrier in enumerate(['10','126']):
 B=dec(Y['B'+carrier]);D=s.Matrix(16,16,list(B*kv));A=[tidy(s.I*(z.T*D+D*z)) for z in T];mom={};finite={};cormodel={'carrier':carrier};counts[carrier]={};controls[carrier]={};Euler={}
 for part in ['scalar','orbit','total']:
  for side in ['', 'anti_']:
   label=side+part;arr=[]
   for c in range(45):
    if part=='scalar':a,b=dec(gp['models'][idx][label][c]),dec(gr['models'][idx][label][c])
    elif part=='orbit':a,b=-dec(gp['models'][idx][label][c]),-dec(gr['models'][idx][label][c])
    else:a=dec(gp['models'][idx][side+'scalar'][c])-dec(gp['models'][idx][side+'orbit'][c]);b=dec(gr['models'][idx][side+'scalar'][c])-dec(gr['models'][idx][side+'orbit'][c])
    zero(a-b);zero(a-a.T);arr.append(tidy(a));gvc_positions+=256
   cormodel[label]=[enc(x) for x in arr];counts[carrier][label]=sum(len(x.todok()) for x in arr)
  e=tidy(B*source[part]);ae=tidy(s.conjugate(B)*source[part]);Euler[part]=e
  for c in range(45):
   zero(s.Matrix(16,16,list(e[:,c]))+2*dec(cormodel[part][c]));zero(s.Matrix(16,16,list(ae[:,c]))+2*dec(cormodel['anti_'+part][c]));euler_positions+=2*256
  cormodel['Euler_'+part]=enc(e);cormodel['anti_Euler_'+part]=enc(ae)
 for part in parts:
  ym=sum((proj(yp['models'][idx][n][part]) for n in ['exchange','scalar_left','scalar_right']),s.zeros(16));ymr=sum((proj(yr['models'][idx][n][part]) for n in ['exchange','scalar_left','scalar_right']),s.zeros(16));zero(ym-ymr)
  delta=grade(dec(mp['models'][idx]['total'][part])-ym);deltar=grade(dec(mr['models'][idx]['total'][part])-ymr);zero(delta-deltar);mom[part]=delta
  source_e=Euler['total'] if part=='chi4' else Euler['orbit'] if part=='log3over2' else s.zeros(256,45)
  image=[]
  for c,z in enumerate(T):image.append(tidy(s.I*(z.T*delta+delta*z)+s.Matrix(16,16,list(source_e[:,c]))))
  finite[part]=image
 pole_rems=finite['chi4'];pole_ok=all(not x.todok() for x in pole_rems);pole_pass&=pole_ok
 crems=[tidy(dec(cormodel['total'][c])+A[c]/2) for c in range(45)];c_ok=all(not x.todok() for x in crems)
 BK=tidy(B*K);hrem=tidy(-BK/2+BK/2);h_ok=not hrem.todok();h_positions+=2*256*328;candidate_pass&=c_ok and h_ok
 oldrem=[tidy(dec(gp['models'][idx]['total'][c])+A[c]/2) for c in range(45)];controls[carrier]['omit_order_conversion_c_candidate_changed']=sum(len(x.todok()) for x in oldrem)
 controls[carrier]['wrong_candidate_sign']=sum(len(tidy(dec(cormodel['total'][c])-A[c]/2).todok()) for c in range(45))
 cormodel.update({'mass_extra_by_finite_part':{p:enc(x) for p,x in mom.items()},'finite_extra_Slavnov_image':{p:[enc(x) for x in a] for p,a in finite.items()},'pole_image_zero':pole_ok,'candidate_c_remainders':[enc(x) for x in crems],'candidate_h_remainder':enc(hrem),'isolated_candidate_c_h_pass':c_ok and h_ok,'h_dimensional_kernel':enc(-BK/2),'h_candidate_image':enc(BK/2),'formal_heat_target_NOT_qualified_response':{p:[enc(tidy((dec(cormodel['total'][c]) if p=='fixed' else s.zeros(16))-finite[p][c])) for c in range(45)] for p in parts}})
 models.append(cormodel)
assert not source_rem.todok() and pole_pass and candidate_pass
assert controls['126']['omit_order_conversion_c_candidate_changed']>0 and oldsource_rem.todok()
artifact={'schema':'GOR1_ACTION_ORDER_CORRECTED_SELECTED_VACUUM_QUANTUM_COEFFICIENTS','origin':'EXACT_LINEAR_TRANSPORT_OF_COMPLETE_GVC_VSC_GRAPH_COMPONENTS_NOT_FRESH_INTEGRATION','ordinary_to_Cleft_order_sign':-1,'source':{k:enc(x) for k,x in source.items()},'finite_source_chi4':enc(source['total']),'finite_source_log3over2':enc(source['orbit']),'full_source_compact_remainder':enc(source_rem),'full_source_identity':'Ltotal_c=rho_c K v','models':models,'previous_GVC_VSC_orbit_interpretation_superseded':True,'old_sources_outputs_and_failures_unchanged':True,'full_heat_response_qualified':False,'full_counterterm_family_or_QAP_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'order_corrected_vacuum_family.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_ACTION_ORDER_CORRECTION_SELECTED_VACUUM_COEFFICIENTS_AND_POLE_COMPATIBILITY','independent_raw_jet_positions':3*45**3,'literal_Lorentz_positions':P['literal_Lorentz_positions_checked'],'GVC_coefficient_positions_compared':gvc_positions,'source_coefficient_positions_compared':source_positions,'Euler_coefficient_positions_compared':euler_positions,'h_candidate_positions':h_positions,'paired_effective_units':P['paired_effective_units'],'corrected_full_source_compact_identity':True,'old_source_compact_remainder_nonzero':len(oldsource_rem.todok()),'source_component_nonzero':{p:len(x.todok()) for p,x in source.items()},'corrected_GVC_counts':counts,'pole_Slavnov_image_zero':pole_pass,'isolated_fixed_Cv_candidate_c_h_pass':candidate_pass,'controls':controls,'old_GVC_VSC_orbit_interpretation_superseded':True,'old_records_edited':False,'no_fresh_loop_integrations':True,'complete_heat_response_or_counterterm_family_qualified':False,'full_QAP_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
