"""GOR1 literal C-left density, explicit Wick factors and completed square."""
from data import *
t=begin('primary');g=s.Symbol('g10');raw={j:[defaultdict(lambda:s.S.Zero) for _ in range(4)] for j in ['a','B','c']};count=0
for row in packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['GF']:
 w=row['word'];base=[n.split('__')[0] for n in w]
 if len(w)!=3:continue
 aa=[i for i,n in enumerate(base) if n.startswith(('bar','ub'))];cc=[i for i,n in enumerate(base) if n.startswith('C')];bb=[i for i,n in enumerate(base) if n.startswith('B')]
 if len(aa)!=1 or len(cc)!=1 or len(bb)!=1:continue
 a,c,b=aa[0],cc[0],bb[0];jets=[i for i,n in enumerate(w) if '__' in n];assert len(jets)==1;pos=jets[0];mu=int(w[pos].split('__')[1]);r,nu=map(int,base[b][1:].split('_'));assert mu==nu
 anti=int(base[a][3:] if base[a].startswith('bar') else base[a][2:]);ghost=int(base[c][1:]);j='a' if pos==a else 'B' if pos==b else 'c'
 co=simp((-1 if c>a else 1)*[1,-1,-1,-1][mu]*s.sympify(row['coefficient'])/g);assert not co.free_symbols;raw[j][mu][r,anti,ghost]+=co;count+=1
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');audit={};changed=0
for j in raw:
 raw[j]=list(map(clean,raw[j]));old={(r,a,c):s.sympify(z) for r,a,c,z in G['raw_jets'][j]}
 for mu in range(4):
  for k in set(old)|set(raw[j][mu]):assert simp(raw[j][mu].get(k,0)+old.get(k,0))==0,(j,mu,k)
  assert raw[j][mu]==raw[j][0]
 changed+=len(old);audit[j]=rows(raw[j][0])
# The Wick sign of normalized Lorentz jets is +1 for both temporal/spatial.
wick_time=(-1)*s.I*s.I;wick_space=(-1)*(-1);wick_orbit=(-1)*(-s.I);assert wick_time==wick_space==1 and wick_orbit==s.I
q,w,gg,xi,V,O,zp,zm,xp,xm=s.symbols('q w g xi V O Ca_plus Ca_minus x_plus x_minus',nonzero=True);Q=q*q
Green=s.Matrix([[0,w/Q,0,-q/Q],[w/Q,0,q/Q,0],[0,q/Q,0,0],[-q/Q,0,0,0]]);assert Green==Green.T
# C-left UA/UB=-oldUA/UB and p_a=-q,p_B=q derive +ig Vold q.
ua,ub=s.symbols('ua ub');canonical=s.expand(s.I*((-ua)*(-q)+(-ub)*q));assert s.simplify(canonical-s.I*(ua-ub)*q)==0
J=s.Matrix([s.I*gg*V*q*zm,-s.I*gg*V*q*zp,s.I*gg*xi*O*xm,s.I*gg*xi*O*xp]);mean=-Green*J;eff=s.expand(-(J.T*Green*J)[0]/2);square=s.expand((mean.T*Green.inv()*mean)[0]/2+(J.T*mean)[0]);assert s.expand(eff-square)==0
units=[simp(eff.coeff(zm).coeff(xp)/(gg*gg*xi*V*O)),simp(eff.coeff(zp).coeff(xm)/(gg*gg*xi*V*O))]
finish('primary',{'method':'literal_GF_C_left_all_Lorentz_jets_Wick_and_paired_Gaussian_square','raw_C_left_jets':audit,'literal_ordinary_rows':count,'GTT_raw_density_order':'a_C_B','common_scalar_density_order':'C_a_x','ordinary_to_common_order_sign':-1,'derivative_normalized_Wick_factor':str(wick_time),'source_B_plus_unit_in_old_V':'I','paired_effective_units':list(map(str,units)),'old_vertex_sign_changed_nonzero_positions':changed,'literal_Lorentz_positions_checked':4*3*45**3,'paired_Gaussian_equals_square':True,'old_GVC_VSC_quantum_outputs_read':False},t)
