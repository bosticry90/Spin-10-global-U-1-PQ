from pathlib import Path
O=Path(__file__).resolve().parent
x=(O/'native.py').read_text(encoding='utf-8');old="return dl**(-e)*mp.gammainc(e,dl*s1,dl*s2) if s2>s1 else mp.mpf(0)";new="return dl**(-e)*((mp.e1(dl*s1)-mp.e1(dl*s2)) if not e else (mp.gammainc(e,dl*s1,mp.inf)-mp.gammainc(e,dl*s2,mp.inf))) if s2>s1 else mp.mpf(0)";assert x.count(old)==1;x=x.replace(old,new).replace("read(O/'preparation.json')","read(O/'preparation_v2.json')",1).replace("(O/(role+'_tables.json.gz'))","(O/(role+'_v2_tables.json.gz'))",1)
with(O/'native_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(x)
x=(O/'verify.py').read_text(encoding='utf-8').replace('validation_preparation.json','validation_preparation_v2.json').replace("(r+'_tables.json.gz')","(r+'_v2_tables.json.gz')")
with(O/'verify_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(x)
print('GENERATED_FIS1_V2_EQUIVALENT_E1_UPPER_GAMMA')
