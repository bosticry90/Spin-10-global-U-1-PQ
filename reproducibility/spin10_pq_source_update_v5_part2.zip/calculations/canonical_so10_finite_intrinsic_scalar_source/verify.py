from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']];assert a['source_vectors']==b['source_vectors'] and a['controls']==b['controls'] and a['literal_Euclidean_source_unit']==b['literal_Euclidean_source_unit']=='1' and a['Srho_positions']==b['Srho_positions']==[0,296];mp.mp.dps=80;worst=mp.mpf(0);positions=0;changed=0
for x,y in zip(a['rows']+a['paths'],b['rows']+b['paths']):
 for k in ['K','leading','bound']+(['wrong_extra_length'] if 'wrong_extra_length'in x else['path_limit']):
  err=abs(mp.mpf(x[k])-mp.mpf(y[k]))/max(1,abs(mp.mpf(x[k])),abs(mp.mpf(y[k])));worst=max(worst,err);assert err<mp.mpf('1e-35'),(x,k,err);positions+=1
 assert 0<=mp.mpf(x['leading'])-mp.mpf(x['K'])<=mp.mpf(x['bound'])+mp.mpf('1e-55')
 if 'wrong_extra_length'in x:changed+=int(abs(mp.mpf(x['wrong_extra_length'])-mp.mpf(x['K']))>mp.mpf('1e-35'))
nn=[len(z['entries']) for z in a['source_vectors']];assert nn[0]==0
e=s.Symbol('epsilon');dd=(s.exp(e*s.log(3))-s.exp(e*s.log(2)))/(e*(1-e));assert s.simplify(s.limit(dd,e,0)-s.log(s.Rational(3,2)))==0
out={'schema':'FIS1_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'actual_intrinsic_classical_cancellation_reused_before_heat':True,'literal_Hessian_Born_and_Berezin_source_unit_agree':True,'scalar_ghost_dual_frame_and_metric_routes_agree':True,'raw_source_Qx_positions':29754,'target_positions_including_zeros':656,'nonzero_scalar_source_positions':nn,'H_covariance_positions':a['H_covariance_positions'],'model_controls':a['controls'],'finite_kernel_cases':18,'joint_paths':9,'numeric_comparisons':positions,'maximum_scaled_discrepancy':mp.nstr(worst,30),'wrong_extra_length_sensitive_cases':changed,'strict_heat_limit':'log(3/2)','DIM_minus_heat_conversion':'-log(3/2)','joint_path_limit':'exp(-a)*log(3/2)','unrestricted_joint_limit_unique':False,'kernel_bound':'0<=Nc^e*d(e)-K<=2cq*Nc^e*d(e)','source_heat_exchange_control_insensitive_by_symmetry':True,'source_vectors_do_not_establish_full_first_grade_Ward_restoration':True,'full_chiral_QAP_measure_phase_scheme_E5_A5':False,'scientific_authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
