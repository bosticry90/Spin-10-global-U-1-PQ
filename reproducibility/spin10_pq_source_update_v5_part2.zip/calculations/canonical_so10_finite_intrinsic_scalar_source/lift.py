from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'lift_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]};results=[]
for role in ['primary','replay']:
 d=load(O/(role+'_v2_tables.json.gz'));y=load(O.parent/'canonical_so10_yukawa_carrier_transport'/(role+'_tables.json.gz'));groups=[]
 for z in d['source_vectors']:
  T=dec(z);assert all(s.simplify(v-s.conjugate(v))==0 for v in T.todok().values());masses={}
  for key in ['B10','B126']:
   B=dec(y[key])
   if role=='primary':v=cl(B*T)
   else:
    vv={}
    for (i,j),b in B.todok().items():
     if T[j,0]!=0:vv[i,0]=vv.get((i,0),0)+b*T[j,0]
    v=cl(s.SparseMatrix(256,1,vv))
   M=s.Matrix(16,16,lambda i,j:v[i*16+j,0]);assert not cl(M-M.T).todok();masses[key]=enc(M)
  groups.append(masses)
 results.append(groups)
assert results[0]==results[1];hat=load(O.parent/'canonical_so10_chiral_probe_support/primary_inputs.json.gz')['hat_vertices'];assert len(hat)==3 and all(all(p in ['P','S','c'] for p,j in row['ports']) for row in hat)
M=dec(results[0][1]['B126']);old=load(O.parent/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');PN=dec(old['P_N']);assert not cl(M-PN*M*PN).todok();nz=list(M.todok().values());assert len(nz)==1;co=nz[0];ratio=s.simplify(co/dec(old['mass126'])[15,15]);assert not dec(results[0][1]['B10']).todok()
for TH in old['SM_generators']:assert not cl(dec(TH).T*M+M*dec(TH)).todok()
e=s.Symbol('epsilon');d=(3**e-2**e)/(e*(1-e));assert s.simplify(s.limit(d,e,0)-s.log(s.Rational(3,2)))==0
out={'schema':'FIS1_RELATIVE_BV_LIFT','elapsed_after_imports':time.perf_counter()-tick,'mass_directions':results[0],'mass126_neutral_coefficient':str(co),'mass126_ratio_to_existing_vacuum_tensor':str(ratio),'general_Y10_and_Y126_not_selected':True,'fixed_full_YCT_maps_and_independent_weighted_sums_agree':True,'literal_scalar_vector_real_and_full_H_covariant':True,'actual_Ihat_x_Jx_independence_checked':True,'Q_full_curvature_retained_B_ext_squared_F_equals_Ihat_bracket_F_zero':True,'relative_generator':'-log(3/2)*u_r*integral(Jx*T_r)','full_Euler_and_higher_probe_companions_required':True,'ordinary_quantum_mass_or_full_Ward_companion_measured':False,'full_physical_reality_phase_mixing_QAP_E5_A5_claim':False,'new_baseline_scheme_or_authority_selected':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
