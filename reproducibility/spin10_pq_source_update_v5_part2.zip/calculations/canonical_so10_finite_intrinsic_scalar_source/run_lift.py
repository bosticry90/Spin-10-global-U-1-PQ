from pathlib import Path
from hashlib import sha256
import json,ast,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/finite-intrinsic-scalar-source-v1-2026-10-25');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'validation_preparation_v2.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 Y=O.parent/'canonical_so10_yukawa_carrier_transport';m=read(Y/'validation_preparation.json')['input_sha256'];P=O.parent/'canonical_so10_chiral_probe_support';pm=read(P/'validation_preparation.json')['input_sha256']
 for role in ['primary','replay']:
  p=Y/(role+'_tables.json.gz');assert H(p)==m[str(p)];b[str(p)]=H(p)
 p=P/'primary_inputs.json.gz';assert H(p)==pm[str(p)];b[str(p)]=H(p)
 for p in [Y/'validation_preparation.json',Y/'validation_receipt.json',Y/'RESULT.md',P/'validation_preparation.json',O/'validation_preparation_v2.json',O/'validation_receipt_v2.json',O/'verify_v2_capture.json']:b[str(p)]=H(p)
 for n in ['LIFT_RECORD.md','lift.py','run_lift.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
  b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
 dump(O/'lift_preparation.json',{'input_sha256':b,'seconds_after_imports':120,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'lift.py')]);dump(O/'lift_capture.json',z);dump(C/'lift_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in z['all_resource_samples'])<=8*1024**3;rr=[json.loads(x[7:]) for x in z['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<120;dump(O/'lift_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<12*1024**2;print('COMPLETED_FIS1_LIFT',rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'lift_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
