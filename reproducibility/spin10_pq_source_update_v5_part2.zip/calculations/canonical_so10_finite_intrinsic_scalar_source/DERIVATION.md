# Intrinsic scalar-source finite kernel and correlated conversion

## Complete cycle and source convention

The target is rho_r Jx_i, with no ordinary mean fields, first intrinsic
coefficient dimension1. A one-loop1PI graph with only two-port insertions
is a cycle. Actual Qx is homogeneous C*x. The source Jx therefore has one
ghost and one scalar internal port. The only complete intrinsic paths to
rho are its direct a*x current S_r, or its a*B/a*Lambda current J_r followed
by one GF mixing N0(b,x). Other action vertices either have three internal
ports or exceed coefficient grade1. The separately translated scalar/mass
terms are not members of this intrinsic target.

EDS1/2 supply the actual full-symbol identity S_r=J_r G0 N0. This is
rechecked on the complete actual matrices before integration. It is not
an equality between separately assigned loop counterterms.

Literal Euclidean normalization is Gamma1=onehalf STrlogH. External source
order is rho Jx. At an elementary scalar/ghost node use ordered vertices
`a rho alpha x` and `J c beta x`, free scalar Green gs, G_Ca=gc,
G_aC=-gc. The quadratic Born term -onequarter STr[(G0 V)^2] is
`+gs gc alpha beta rho J`. Independent scalar elimination/Berezin
integration gives the same unit. This fixes source sign and multiplicity;
there is no guessed scalar2, fermion family trace or open-line half.

## Actual source tensor and metric transport

Let Tx,Tc,Ta map physical coordinates to the inherited raw coordinates,
and Fx,Fc,Fa be their inverses. Raw scalar kinetic metric is the qualified
identity. Retain

```
Gx_phys=Fx Fx^T,
Gca_phys=Fc Gca_raw Fa^T,
Rphys_c=Fx [sum_a Tc[a,c] Rraw_a] Tx.
```

Rraw is the complete actual Qx coefficient in source*ghost*scalar order,
including g10. The source vector is

```
T_r,i=sum_(c,a,k,j) Rphys_c[i,k] Gca_phys[c,a] S_r[a,j] Gx_phys[k,j].
```

Primary contracts literal Qx indices with propagated physical currents.
Replay pulls the current back first,
Sraw=Fa^T S_r Fx, and uses B=Sraw^T Gca_raw^T before contracting the
raw representation matrices, then applies Fx to the output. These
are the same field/source tensor under distinct multiplication associations.
Full inverse/metric checks precede assuming any identity metric. In this
actual frame both physical metrics do equal I; replacing them by I is
therefore an honestly insensitive control, not evidence for arbitrary charts.

## Positive heat distinguishes the two paths

Set Q=k²,R=(k-p)²,q=p_E²>0,c=2t,E_X=exp(-cX). Direct rho/current-source
bubble has E_Q E_R. The GF inverse path has an extra mixed bosonic edge
of momentum R, hence E_Q E_R². Their complete source contribution is

```
Gamma_(rho_r Jx_i)=hbar/(16pi²) T_r,i K(c,epsilon,q),
K=N integral E_Q E_R(1-E_R)/(QR),
N=exp(gamma_E epsilon)*(mu_R²)^epsilon.
```

The momentum integral uses the inherited normalized scalar-bubble measure.
Each nonexceptional IR node has degree2, locally integrable for D>2.
The heat factor regulates UV for c>0. Bare algebraic cancellation at c0
does not set this filtered kernel to zero.

For x in(0,1),Delta=q x(1-x),
s1=c max(1/(1-x),1/x),s2=c max(1/(1-x),2/x). The first calculation is

```
K=N integral_0^1 Delta^(-epsilon)
       [Gamma(epsilon,Delta*s1)-Gamma(epsilon,Delta*s2)]dx.
```

The bracket is exactly0 for x>=2/3. At epsilon0 it is E1(Delta*s1)-
E1(Delta*s2), avoiding mpmath's unsupported finite-interval Gamma(0,a,b).

The second calculation differentiates the heat length lambda in I_(1,lambda).
After a different proper-time integration,

```
K=N c^epsilon integral_1^2 d lambda integral_0^(1/(1+lambda))
       y^(-epsilon) exp[-cq lambda(1-lambda*y)]dy.
```

The y integral is evaluated with ordinary 1F1 and its Beta normalization.
The remaining lambda integral is one dimensional. This representation is
positive on0<=epsilon<1 and supplies the uniform bound directly.

Define

```
d(epsilon)=(3^epsilon-2^epsilon)/[epsilon(1-epsilon)], d(0)=log(3/2).
0 <= N c^epsilon d(epsilon)-K
  <= 2cq N c^epsilon d(epsilon).
```

The bound follows from0<=1-exp(-z lambda(1-lambda*y))<=2z. It controls
all epsilon/heat paths in the bounded domain. Strict epsilon0 heat removal
gives log(3/2). At c0 before dimensional removal, the identical unfiltered
direct and inverse integrands cancel exactly, giving0. Along
cq=exp(-a/epsilon), K tends exp(-a)log(3/2). There is no unique unrestricted
joint limit for this ISOLATED source kernel. This is not a failure of an
already ordered finite-part prescription and does not decide the combined
Ward group. The strict-heat-to-dimensional relative conversion is the
local coefficient -log(3/2) T_r, without a common-log or chi4 choice.

Interchanging the Q/R heat assignment is invisible to this scalar integral
under k->p-k. Increasing the inverse edge length instead gives log2 in
the strict heat limit and is a sensitive error. Distinguish these controls.

## Correlated BV lift; quantum companions remain unmeasured

For F_r=integral Jx_i T_r,i set Z=-log(3/2)u_r F_r. The local relative
conversion can be embedded algebraically as

```
deltaSigma=B_ext Z,  B_ext=(Sigma_ext,.)+d.
```

At first probe degree its rho component is -log(3/2)rho_r F_r, and its
ordinary companion is -log(3/2)u_r QF_r. QF uses the complete E_x of the
actual action and sources. It is not obtained by setting E_x=0. If used
at higher probe degree, retain the full (Sigma_ext,F), including nonzero
brackets with the original G/QG. No claim that(G,F)=0 is made.

The actual augmented master curvature is Ihat. Thus graded Jacobi gives
B_ext² Z=(Ihat,Z). Ihat has only C,P,S and hatted derivatives, no x/Jx;
T is constant in the dynamical fields. Consequently this bracket vanishes
in the inherited master domain while Q_full curvature remains nonzero
on general functionals. This is a classical consistency statement for a
calculated relative conversion, not a full quantum-restoration theorem.

The separately checked YCT maps give B10 T_r=0 for both probes. For r1,
unvec(B126 T_1)=5sqrt(30)g10²xi²/8 P_N. This predicts the mass-function
direction in the ordinary companion with arbitrary symmetric Y126. It
is not an independently measured fermion correction or a physical neutrino
mass shift. Higher ordinary/source companions, physical source reality,
measure/phase and complete first-grade quantum compatibility remain open.

Primary literature provides methodological context: enlarged-BRST Nielsen
identities govern gauge-parameter Green functions [Gambino and Grassi](https://arxiv.org/abs/hep-ph/9907254v3).
Gauge-fixing parameters and vacuum-coordinate dependence require correlated
treatment in other models [Kim](https://arxiv.org/abs/1508.07104v1).
Neither paper supplies this model's tensors, heat convention or coefficients.
