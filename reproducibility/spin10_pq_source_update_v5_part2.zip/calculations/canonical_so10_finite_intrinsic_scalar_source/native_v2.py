from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('FIS1_PEER_DENIED')
sys.addaudithook(guard)
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v!=0}
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   sg=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(4) if a&(1<<i));out[a|b]=s.expand(out.get(a|b,0)+sg*x*y)
 return {k:v for k,v in out.items() if v!=0}
def word(seq,co=1):
 z={0:s.sympify(co)}
 for i in seq:z=mul(z,{1<<i:1})
 return z
xsym,gs,gc,al,be=s.symbols('x gs gc alpha beta',nonzero=True)
if role=='primary':
 action=add({0:xsym**2/(2*gs)},word([3,2],1/gc));pert=add(word([3,0],al*xsym),word([1,2],be*xsym));p=[0,1,1]
 def dd(A,i):
  if i==0:return {k:v for k,z in A.items() if(v:=s.diff(z,xsym))!=0}
  bit=1<<(2 if i==1 else 3);out={}
  for k,z in A.items():
   if k&bit:out[k^bit]=(-1)**((k&(bit-1)).bit_count())*z
  return out
 def hess(A):return [[{k:(-1)**(p[j]*(p[i]+1))*v for k,v in dd(dd(A,i),j).items()} for j in range(3)] for i in range(3)]
 K=hess(action);V=hess(pert);kn=s.Matrix([[a.get(0,0) for a in row] for row in K]);gn=kn.inv();assert gn[1,2]==gc and gn[2,1]==-gc and gn[0,0]==gs
 M=[[{} for j in range(3)] for i in range(3)]
 for i in range(3):
  for j in range(3):
   for k in range(3):M[i][j]=add(M[i][j],{m:gn[i,k]*v for m,v in V[k][j].items()})
 tr={}
 for i in range(3):
  for j in range(3):tr=add(tr,{k:-s.Rational(1,4)*(-1)**p[i]*v for k,v in mul(M[i][j],M[j][i]).items()})
 unit=s.simplify(tr[3]/(gs*gc*al*be))
else:
 # Eliminate the Gaussian scalar first. Its square of two even currents
 # supplies a*rho*J*c; integrate the remaining ghost exactly.
 free=add({0:s.S.One},word([3,2],-1/gc));z=add(free,word([3,0,1,2],gs*al*be));unit=s.simplify(-z[15]/free[12]/(gs*gc*al*be))
assert unit==1
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));xs=d['xs'];xid={n:i for i,n in enumerate(xs)};g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
ref=d['frame'];order=ref['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+xs+[('b' if i<12 else'L')+str(i) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar' if i<12 else'ub')+str(i) for i in range(45)];ri={n:i for i,n in enumerate(order)};pi={n:i for i,n in enumerate(phys)};TI=dec(ref['physical_to_raw_inverse']);TF=dec(ref['physical_to_raw_kernel'])
def block(ns):return TI.extract([ri[n] for n in ns],[pi[n] for n in ns]),TF.extract([pi[n] for n in ns],[ri[n] for n in ns])
Tx,Fx=block(xs);Tc,Fc=block(['C'+str(i) for i in range(45)]);Ta,Fa=block([('bar' if i<12 else'ub')+str(i) for i in range(45)])
for A,F in [(Tx,Fx),(Tc,Fc),(Ta,Fa)]:assert not cl(A*F-s.eye(A.rows)).todok() and not cl(F*A-s.eye(A.rows)).todok()
Graw=dec(ref['raw_ghost_Green']);Gca=cl(Fc*Graw*Fa.T);Gx=cl(Fx*Fx.T);assert not cl((Tx.T*Tx)*Gx-s.eye(328)).todok()
rawrows=[];Rraw=[s.SparseMatrix(328,328,{}) for a in range(45)]
for n,rows in d['source_Qx'].items():
 i=xid[n]
 for row in rows:
  ww=row['word'];assert len(ww)==2 and all('__' not in z for z in ww);c0=next(z for z in ww if z.startswith('C'));x0=next(z for z in ww if z.startswith('x_'));a=int(c0[1:]);j=xid[x0];v=parse(row['coefficient']);assert s.Poly(v,g).monoms()==[(1,)];Rraw[a][i,j]+=v;rawrows.append((i,a,j,v))
assert len(rawrows)==29754 and all(not cl(M+M.T).todok() for M in Rraw)
G0,N0=dec(d['endings']['G0']),dec(d['endings']['N0']);outvectors=[];controls=[];currents=[];Hchecks=[]
for probe,z in enumerate(d['endings']['rho']):
 J,S=dec(z['J']),dec(z['direct']);assert not cl(S-J*G0*N0).todok();assert not dec(z['total']).todok()
 if role=='primary':
  B=cl(Tx*Gx*S.T*Gca.T*Tc.T);raw=s.zeros(328,1)
  for i,a,j,v in rawrows:raw[i]+=v*B[j,a]
  raw=cl(raw)
 else:
  Sraw=cl(Fa.T*S*Fx);B=cl(Sraw.T*Graw.T);raw=cl(sum((Rraw[a]*B[:,a] for a in range(45)),s.zeros(328,1)))
 vec=cl(Fx*raw);outvectors.append(enc(vec));currents.append(len(S.todok()))
 # Full H covariance of the computed scalar vector, with actual ghost chart.
 for h0 in range(12):
  RH=cl(sum((Tc[a,h0]*Rraw[a] for a in range(45) if Tc[a,h0]),s.zeros(328)));assert not cl(RH*raw).todok()
 Hchecks.append(12*328)
 # Explicit metric controls are computed even when a metric happens to be I.
 def wrong(gxx,gcc):
  BB=cl(Tx*gxx*S.T*gcc.T*Tc.T);vv=s.zeros(328,1)
  for i,a,j,v in rawrows:vv[i]+=v*BB[j,a]
  return cl(Fx*vv-vec)
 controls.append({'wrong_identity_scalar':len(wrong(s.eye(328),Gca).todok()),'wrong_identity_ghost':len(wrong(Gx,s.eye(45)).todok()),'omit_direct_or_inverse':len(vec.todok()),'extra_scalar_half':len(vec.todok())})
print('STAGE FIS1 '+role+' full source sign,frames,actual scalar contractions,H covariance complete',flush=True)
mp.mp.dps=80;fmt=lambda x:mp.nstr(x,60)
def kval(e,z,q,mu,wrong=False):
 N=mp.exp(mp.euler*e)*mu**e;c=z/q;end=3 if wrong else 2
 if role=='primary':
  def fun(x):
   u=x*(1-x);dl=q*u;s1=c*max(1/(1-x),1/x);s2=c*max(1/(1-x),end/x)
   return dl**(-e)*((mp.e1(dl*s1)-mp.e1(dl*s2)) if not e else (mp.gammainc(e,dl*s1,mp.inf)-mp.gammainc(e,dl*s2,mp.inf))) if s2>s1 else mp.mpf(0)
  return N*mp.quad(fun,[0,mp.mpf(1)/2,mp.mpf(end)/(end+1),1])
 def length(lam):return mp.exp(-z*lam)*(1+lam)**(e-1)*mp.hyp1f1(1-e,2-e,z*lam**2/(1+lam))/(1-e)
 return N*c**e*mp.quad(length,[1,end])
rows=[]
for e0 in ['0','0.05','0.2']:
 for z0,q0 in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  # Two massless-denominator labels exchange under k->p-k. This second
  # assignment is a normalization symmetry, not an extra independent graph.
  for orientation in ['Q_R','R_Q']:
   ee,zz,qq=map(mp.mpf,[e0,z0,q0]);kk=kval(ee,zz,qq,mp.mpf('1.5'));N=mp.exp(mp.euler*ee)*mp.mpf('1.5')**ee;c=zz/qq;dd=(3**ee-2**ee)/(ee*(1-ee)) if ee else mp.log(mp.mpf(3)/2);refv=N*c**ee*dd;assert 0<=refv-kk<=2*zz*refv+mp.mpf('1e-65');rows.append({'epsilon':e0,'cq':z0,'q':q0,'orientation':orientation,'K':fmt(kk),'leading':fmt(refv),'bound':fmt(2*zz*refv),'wrong_extra_length':fmt(kval(ee,zz,qq,mp.mpf('1.5'),True))})
 print('STAGE FIS1 '+role+' epsilon '+e0+' complete',flush=True)
paths=[]
for e0 in ['0.1','0.05','0.025']:
 for a0 in ['0.5','1','2']:
  ee,av=map(mp.mpf,[e0,a0]);zz=mp.exp(-av/ee);qq=mp.mpf(2);kk=kval(ee,zz,qq,mp.mpf('1.5'));N=mp.exp(mp.euler*ee)*mp.mpf('1.5')**ee;dd=(3**ee-2**ee)/(ee*(1-ee));refv=N*(zz/qq)**ee*dd;assert abs(kk-refv)<=2*zz*refv+mp.mpf('1e-65');paths.append({'epsilon':e0,'a':a0,'K':fmt(kk),'leading':fmt(refv),'bound':fmt(2*zz*refv),'path_limit':fmt(mp.exp(-av)*mp.log(mp.mpf(3)/2))})
out={'schema':'FIS1_INTRINSIC_SCALAR_SOURCE','role':role,'literal_Euclidean_source_unit':str(unit),'raw_source_Qx_positions':len(rawrows),'source_vectors':outvectors,'Srho_positions':currents,'Gx_phys_identity':not cl(Gx-s.eye(328)).todok(),'Gca_phys_identity':not cl(Gca-s.eye(45)).todok(),'all_frame_inverse_and_scalar_metric_orders_checked':True,'H_covariance_positions':Hchecks,'controls':controls,'rows':rows,'paths':paths,'strict_heat_limit':'log(3/2)','unfiltered_DIM_kernel':'0','relative_DIM_minus_strict_heat':'-log(3/2)','unrestricted_joint_limit_unique':False,'heat_exchange_insensitive_by_scalar_bubble_symmetry':True,'complete_intrinsic_rho_Jx_only_not_full_first_grade_Ward':True,'scientific_authority_changed':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_v2_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
