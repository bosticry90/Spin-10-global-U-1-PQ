# A nonzero finite intrinsic scalar-source contribution

October25,2026. PROGRESS, based on38248bac8bad03eb719a911c310251ef5d127dba.
The complete selected intrinsic rho-Jx kernel is now calculated. Its
unbroken-probe component is0; its broken-probe component has20 nonzero
scalar-coordinate coefficients. The unfiltered classical ending still
cancels, but the actual fixed-heat paths have different edge counts and
leave a finite contribution. This does not establish an anomaly or full
first-grade Ward restoration. State113/authority34of39 stay unchanged.

## What was calculated

Original unshifted action/SMA/CSW, one-loop literal Euclidean source
normalization, A0,u0, one rho and one Jx, no ordinary mean fields, first
INTRINSIC coefficient-dimension-one GF/reference terms. All328 scalar
coordinates and45 ghosts are retained. Sources are differentiated before
restriction, at nonexceptional Euclidean transfer p²=q>0. No scalar
translation, new vacuum, flavor fit, physical mass or scheme was chosen.

This is the source term Gamma_(rho Jx) that multiplies the classical
Yukawa E_x(PP) in the next finite fermion Ward problem. The grade0
calculation excluded it only because no scalar path existed at that grade.
That exclusion does not apply here.

The actual two-port source cycle has exactly two intrinsic families: a
direct rho a*x bubble, and rho a*B/a*Lambda followed by one GF scalar
mixing. The complete unfiltered equality S_r=J_r G0 N0 is rechecked first.
The extra mixed edge on the second path supplies another heat factor.
The source/Euler normalization is derived by graded-Hessian Born traces
and independent scalar elimination/Berezin integration. Both give unit+1
for the declared rho Jx order in Gamma1=onehalf STrlogH. No additional
family trace, scalar multiplicity or Minkowski i is assigned.

All29,754 actual Qx source terms and the field/source dual chart enter the
contraction. The scalar and ghost metrics are derived before contraction;
they happen to be I in this physical chart. Replacing them by I is
therefore an insensitive control and is reported as such.

## Actual finite source vector

In common hbar/(16pi²) units the complete coefficient is

```
Gamma_(rho_r Jx_i)=T_r,i K(c,epsilon,q),
K=N integral exp[-c(Q+R)](1-exp[-cR])/(QR),
Q=k²,R=(k-p)²,c=2t,N=exp(gamma_E epsilon)*(mu_R²)^epsilon.
```

Both matrix routes agree across656 scalar positions including zeros.
T_0=0. T_1 contains4 Phi54 and16 Sigma252 positions, all proportional
to g10²xi². Phi/Sigma coordinate labels are preserved in the compressed
tables; no phi20 or singlet-S contribution is invented. These are
algebraic coordinates, not20 independent particles or experiments.
All12 unbroken-generator covariance checks pass on the complete vector.
The computed scalar vector is real in this chart; this alone does not
prove the full physical source-involution or Lorentzian reality conditions.

## Finite heat and the order of limits

The primary split upper-gamma parameter integral and replay differentiated
heat-length/1F1 integral agree, including the nonlocal cq dependence and
epsilon terms. Their positive representation gives

```
d(epsilon)=(3^epsilon-2^epsilon)/[epsilon(1-epsilon)], d(0)=log(3/2),
0<=N c^epsilon d(epsilon)-K<=2cq N c^epsilon d(epsilon).
```

This proves the strict-heat finite limit **K->log(3/2)**. The corresponding
unfiltered dimensional kernel is0 because its two complete integrands
cancel before integration. Hence the calculated relative DIM-minus-heat
conversion is **-log(3/2) T_r**. Its local momentum-independent limit is
not a new common-log choice or an identification with chi4,kappa or b0.

The isolated kernel has **no unique unrestricted joint limit**. Along
cq=exp(-a/epsilon) its limit is exp(-a)log(3/2); dimensional-first and
strict-heat limits differ. This does not invalidate a prescribed iterated
finite-part construction. It means the grade0 whole-group limit theorem
cannot be imported into this individual source term. The correlated
ordinary, hatted and regulator-root contributions still have to be combined.

## A calculated relative conversion has a correlated lift

With F_r=integral Jx_i T_r,i, the source conversion is the rho component
of B_ext[-log(3/2)u_r F_r]. Its first ordinary companion is
-log(3/2)u_r QF_r, with the FULL actual E_x action/source Euler operator.
Higher probe companions from the same operator must stay if the lift is
later used beyond first degree. In particular, no(G,F)=0 shortcut is used.

Actual Ihat has no x or Jx. Therefore(Ihat,F_r)=0, so the inherited
curved-master Jacobi relation makes this relative lift classically
consistent without declaring Q_full nilpotent. This is an algebraic
completion of a measured component conversion, not measurement of the
remaining quantum terms or adoption of a physical subtraction scheme.

Both full YCT scalar maps give B10 T_r=0. For the broken probe,

```
unvec(B126 T_1)=5sqrt(30)g10²xi²/8 P_N
             =(25g10²xi²/4) M126(v).
```

P_N is the previously qualified neutral projector. The two symmetric
family Yukawa matrices remain arbitrary. This is the mass-FUNCTION
direction of the proposed relative ordinary companion, not a predicted
observable neutrino mass correction. It uses the complete scalar map,
including its physical complement, and does not reopen flavor or adopt
the provisional matter realization as new foundational authority.

## Verification and preserved failure

The numerical table has9 unique(epsilon,cq,q) parameter points and their
9 heat-exchange symmetry assignments, plus9 joint-limit paths:18 finite
assignments/108 scalar comparisons in the receipt. Exchange Q<->R is
analytically insensitive for this scalar bubble; the two assignments are
not independent new loop calculations. Arithmetic uses80 digits,60 stored,
1e-35 scaled gate. Stored primary/replay discrepancy is0, a finite numerical
agreement rather than exact integration. Wrong extra heat length changes
all18 finite assignments. Omitting a direct/inverse term or adding a
spurious scalar half changes20 actual source-vector positions for the
broken probe; unbroken and identity-metric controls are honestly insensitive.

Original primary failed on mpmath's unimplemented finite-interval Gamma
at epsilon0 after the algebra stage. It produced no scientific table or
receipt. Its exact source/copy, preparation, full capture and controller
failure are preserved. V2 uses E1(a)-E1(b) at0 and upper-gamma subtraction
at positive epsilon. No scientific condition, input or resource cap changed.

Completed P/R/verifierV2 took81.3355328/9.4493434/.2901807s afterimports;
the relative-lift check took6.5046779s. Their42/6/1/4 samples reached
77,488,128/75,927,552/401,408/54,259,712B. The failed primary's5 samples
reached75,321,344B. These are sampled observations, not continuous peaks.
The300s native and120s lift limits,8GiBsampled/350MiBfloor/12MiBpacket held.
The pre-report packet was401,671B with14 source copies;
bindings44/60/68/84 authenticate initial/V2/validation/lift stages.

Validation receipt SHA256:
`a0a545c51ee0730ccf2313d64adaa481798590e2c043c8c16d093365f82ac20e`.
Lift receipt SHA256:
`6b9f0c906291d750675d17986d8f7b1a2339c1162e80b94416053c809d29f64f`.
Fresh delegated E4 completed native0 with steps[0,0,0,0,0,2]. Historical
custody stays exit2/sevenNOTPASS. Captures/readiness/seals are also retained
under the external finite-intrinsic-scalar-source-v1-2026-10-25 directory.
No historical blob, failed run or project_state.json is rewritten.

## Significance and next discriminating test

This replaces an unjustified finite extrapolation of a bare zero with an
actual nonzero, source-normalized heat kernel and its precise conversion.
The result supplies a concrete first-grade dependency while preserving the
distinction between a quantum measurement and a constructed companion.
The source/frame/regulator assumptions, action, software and AI author
are shared; these checks are internal corroboration, not external scientific
or experimental validation. The analytic bounds/Jacobi argument are
human-readable same-AI derivations, not proof-assistant certificates.

Next derive the complete ordered intrinsic u-response of the mixed
boson-scalar propagator from the actual EDS U,N0,Nr. Preserve the distinct
heat lengths before testing its fermion sewing. Then calculate the
complete first-grade ordinary/source/hatted/root Ward group and compare
with the predicted relative companion without fitting it. Translated
mass/scalar families and the massive inverse's separate IR issue remain
independent obligations. Full chiral products, QAP, phase/measure,
physical limits, unification and E5/A5 remain open.
