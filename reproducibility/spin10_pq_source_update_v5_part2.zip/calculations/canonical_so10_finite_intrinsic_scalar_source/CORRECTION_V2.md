# Zero-epsilon incomplete-gamma evaluation

Original primary completed its statistics/frame/tensor/H-covariance stage,
then mpmath.gammainc(0,a,b) raised NotImplementedError before any numerical
table was written. Its original native.py/source copy, preparation,
full failed capture and controller_failure.json remain exact FAILED evidence.
Original replay/verifier never launched; no original validation receipt exists.

V2 evaluates Gamma(0,a)-Gamma(0,b) as E1(a)-E1(b) at epsilon0. At positive
epsilon it subtracts the two upper incomplete-gamma functions. These are
the same analytic kernel and limits. No physical input, source coefficient,
comparison gate, 300-second cap or memory/packet requirement changes.
Both roles use new versioned outputs; no old failed source is edited/rebound.
