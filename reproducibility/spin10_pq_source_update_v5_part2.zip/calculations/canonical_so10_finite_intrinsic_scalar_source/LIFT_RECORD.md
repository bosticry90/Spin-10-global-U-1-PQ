# Relative source-contact conversion and its correlated scalar direction

Freeze after FIS1 V2 P/R/verifier terminal completion. Do not repeat the
finite kernels or change their outputs. The measured Euclidean source
coefficient is nonzero for broken rho, and its strict-heat/DIM relative
conversion is -log(3/2) times the measured vector T. Determine the actual
general-Yukawa mass-function direction and a correlated BV lift BEFORE
asking whether the still-unmeasured ordinary first-grade finite terms agree.

Authenticate FIS inputs/sources/receipts and both complete YCT B10/B126 maps
against their original bindings. Primary sparse matrix multiplication and
replay direct scalar-coordinate accumulation must agree for each of the
256x1 mass tensors/zeros. No choice of either symmetric family Yukawa matrix,
physical mass, flavor point, width or finite baseline. Keep Phi/S zero Yukawa
as the actual parent support, never drop the Sigma physical complement.
Use model H generators/neutral projector only AFTER the mass direction is
derived. Counts are coefficient positions, not physical species.

For F_r=integral Jx_i T_r,i, source ghostnumber-1/parityodd/dimension3,
the relative source conversion is the rho component of
deltaSigma=B_ext[-log(3/2)*u_r F_r], B_ext=(Sigma_ext,.)+d.
Retain the FULL ordinary/source Euler E_x in (Sigma_ext,F); no classical
field equation is set0. At first probe degree the companion is
-log(3/2)*u_r*QF_r. Higher probe companions in the complete operator formula
must stay if later used beyond that degree; do not infer(G,F)=0 from shared
ordinary fields. Q_full remains curved by Ihat. Because actual Ihat has
only C,P,S/hat derivatives and no x/Jx, (Ihat,F)=0 and B_ext²F=0 in the
inherited master domain. This is a classical BV consistency lift of a
calculated relative conversion, NOT measurement of its ordinary companions.

Check actual hatted-vertex support, constant real T, H covariance and
scalar/family mass symmetries. Do not infer a full physical source-involution,
Lorentzian reality/phase or simultaneous finite mixing theorem from these
tests. Baselines remain unspecified; do not identify with kappa,b0,chi4.
The B_R T result predicts the mass-function direction of the relative
ordinary companion; it is not an independent quantum fermion measurement.

One reviewer/constructor120s afterimports,8GiBsampledprivate,350MiBfloor,
wholepacket12MiB. Freeze source/copies/new inputs before execution. Preserve
failures, original failed primary and successful V2. No foundational/action/
scheme adoption, E5/A5 promotion, HB1/C5/flavor activation, agents or external
actions. Shared action, CSW/SMA/YCT and reference limits, software/AIauthor
limit independence. Next meaningful test: complete actual first-grade
ordinary/source/hatted/root quantum group, including translated scalar
support, before any finite-restoration claim.
