from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();b={};assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='38248bac8bad03eb719a911c310251ef5d127dba'
E=O.parent/'canonical_so10_probe_mass_dimension_one';m=read(E/'ending_validation_preparation.json')['input_sha256'];p=R/'tools/portable_dh_v1/inputs.json.gz';assert H(p)==m[str(p)];pd=load(p);b[str(p)]=H(p);xs=[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]
for role in ['primary','replay']:
 ip=E/('ending_'+role+'_inputs.json.gz');tp=E/('ending_'+role+'_tables.json.gz');assert H(ip)==m[str(ip)] and H(tp)==m[str(tp)];d,z=load(ip),load(tp);data={'xs':xs,'source_Qx':{n:pd['master_field_maps'][n] for n in xs},'frame':d['frame'],'endings':{k:z[k] for k in ['G0','N0','rho']},'extraction':'ACTUAL_CLASSICAL_QX_FRAME_AND_INTRINSIC_RHO_ENDING_NO_QUANTUM_TARGET_OR_CANDIDATE'};dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for p in [ip,tp,dst]:b[str(p)]=H(p)
for folder,ns in [('canonical_so10_probe_mass_dimension_one',['RECORD.md','ENDING_RECORD.md','SYMBOL_RECORD.md','RESULT.md','ending_validation_preparation.json','ending_validation_receipt.json','symbol_receipt.json']),('canonical_so10_scalar_source_g3_color',['RESULT.md','validation_receipt.json']),('canonical_so10_finite_probe_nielsen_ward',['DERIVATION.md','REVIEW.md','validation_receipt.json']),('canonical_so10_finite_probe_transfer_ward',['DERIVATION.md','REVIEW.md','validation_receipt_v2.json']),('canonical_so10_chiral_probe_support',['DERIVATION.md','validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V607.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_FIS1',len(b),flush=True)
