from pathlib import Path
from hashlib import sha256
import json,ast
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();b=dict(read(O/'preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
assert read(O/'controller_failure.json')['stage']=='primary' and read(O/'primary_capture.json')['execution_state']=='FAILED' and 'NotImplementedError' in read(O/'primary_capture.json')['stdout_and_stderr']
for n in ['CORRECTION_V2.md','generate_v2.py','native_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
for n in ['preparation.json','preparation_capture.json','primary_capture.json','controller_failure.json']:b[str(O/n)]=H(O/n)
with(O/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'original_primary':'FAILED_UNIMPLEMENTED_ZERO_EPSILON_GAMMA_NOT_RELABELLED','scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_FIS1_V2',len(b),flush=True)
