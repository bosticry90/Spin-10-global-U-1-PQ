# FIS1: complete intrinsic first-grade rho-Jx kernel

Frozen before computation, October25,2026, base38248bac8bad03eb719a911c310251ef5d127dba,
35739oldblobs. Question: does the actual intrinsic scalar ending, whose
UNFILTERED direct and inverse pieces cancel in EDS1/2, still vanish in the
fixed positive-heat construction? It supplies Gamma_(rho Jx), multiplied by
the classical Yukawa E_x(PP) in the first positive-dimensional finite Ward
group. The grade0 NFP/NVT source omission cannot be transferred to this grade.
Resolve this complete small source class before expanding massive fermion loops.

Original unshifted action/SMA/CSW, A0,u0, one rho0/rho1, one scalar BV source
Jx, no external ordinary fields, coefficient mass dimension1 INTRINSIC GF
reference coefficients only. Retain all328 real canonical scalar directions,
45ghosts, actual scalar and ghost metrics/frames. No scalar translation,
new physical vacuum, Yukawa/flavor choice or mass benchmark is adopted.
Sources are differentiated BEFORE restriction. Independent Euclidean rho
transfer p and opposite Jx transfer -p, p²=q>0, external hats0.

Complete one-loop1PI support: source Jx*R_x(C,x) has two internal ports;
rho contributes a*x direct, or a*B/a*Lambda with ONE intrinsic GF quadratic
N0(b,x). The former is a bubble, latter triangle. Every other interaction
would have three internal ports or a second positive-dimensional coefficient.
The actual unshifted Qx has no affine term; all literal terms are C*x.
G has no Jx source port. Its other source terms retain excluded external
sources. Positive-dimensional scalar-potential/cubic-GF vertices do not fit
this two-source, no-ordinary-field cycle. Ghost masses have coefficient
dimension2. Intrinsic reference terms are not the separate translated subset.

Use authenticated EDS actual Jrho,Srho,G0,N0, full-symbol proof and raw
canonical Qx from portableDH, checked against qualified scalar-source
kinetic/source identity metrics. Independently transport fields and sources
with evaluation-dual charts. Never identify physical scalar Green with I
without checking: Gx_phys=Fx Fx^T, Gca_phys=Fc Gca_raw Fa^T. Reconstruct the
source operator Rphys_c=Fx(sum_a Tc[a,c]Rraw_a)Tx. Preserve complex raw/physical
frames. No old loop coefficient/counterterm enters native inputs.

At fixed reference the direct path has E_Q E_R; the N0 path has E_Q E_R²,
because the extra mixed bosonic edge has momentum R=(k-p)². Actual bare
Srho-JrhoG0N0=0 must first be reauthenticated. The filtered ending may
therefore be proportional to(1-E_R)Srho. Evaluate actual tensors; zero,
nonzero and input/sign/domain failures all remain admissible. Do not set an
unknown coefficient from the desired Ward equation.

Literal Euclidean convention: Gamma1=onehalf STrlogH, ghost G_Ca=+Gca/Q,
G_aC=-Gca^T/Q, scalar Green=Gx/Q. Ordered vertices a*rho*S*x and
Jx*C*R*x. Derive the sign/unit by full graded-Hessian Born trace versus
direct boson elimination/Berezin expansion with both external odd sources.
Compare the actual Qx source tensor in this convention before any physical
fermion amplitude; no additional i, family factor or scalar2 is guessed.
Physical/SMA fermion normalization and full Ward assembly stay separate.

Primary literal Qx index contraction in physical propagated frame; replay
pulls the ending back first, contracts source representation matrices and
pushes the output with the dual chart. Test all328 positions, both probes,
all zeros, full H-covariance of the actual result and honest metric controls.
Retain finite polynomial g,width coefficients. No complete counterterm
admissibility/reality proof is inferred from a single vector check.

Universal actual radial kernel K=I_(1,1)-I_(1,2),
I_(1,lambda)=N integral E_Q E_R^lambda/(QR),c2t,N=e^(gamma_E e)muR²^e.
Primary split Feynman-parameter upper-gamma difference; replay differentiate
the heat length, integrate the remaining proper time analytically using
ordinary1F1, then integrate lambda1..2. Retain full epsilon and cq dependence.
18finitecases:e0,.05,.2,cq .01,.2,1.5,q .5,2,5,muR²1.5;80digits/60stored,
1e-35scaledgate. Ninepaths:e .1,.05,.025,a .5,1,2,cq=exp(-a/e).

Investigate strict-heat vs dimensional and unrestricted joint limits using
K/(Nc^e) and d(e)=(3^e-2^e)/[e(1-e)], d0=log(3/2). A uniform positive
heat-length representation can bound the remainder by2cq*Nc^e*d(e).
Do NOT assume a unique joint limit or use the grade0 whole-group theorem
for this isolated kernel. Determine the relative conversion only from
actual calculations; keep any baseline freedom symbolic. No finite term
is installed in the action to force cancellation. No anomaly verdict.

Controls: omit direct/inverse, falsely omit extra heat edge, change its
length to3, source order/sign, extra identical-scalar half, wrong scalar/
ghost identity metric. Swapping Q/R heat placement can be insensitive for
this scalar bubble; establish/report that symmetry instead of crediting
it as a new sensitive control. If model tensor vanishes, retain that zero
and use nonzero synthetic sign/metric controls without calling them model data.

Sequential primary/replay/verifier each300s afterimports,8GiBsampledprivate,
350MiBlaunchfloor,12MiBpacket. Freeze inputs and source copies before runs;
preserve failures/incomplete captures, no automatic widening. The scientific
ceiling is this complete intrinsic source kernel and its limit/conversion
properties, not full first-grade Ward cancellation, translated/massive
amplitudes, chiralQAP, measure/phase, physical limits or E5/A5. State113/34of39
unchanged,custody2sevenNOTPASS. No agents/branches/worktrees/push/outreach/
publication/adoption/flavor/HB1C5/promotion. Shared action, charts, CSW/EDS
analytic continuation, software and AI author limit independence.
