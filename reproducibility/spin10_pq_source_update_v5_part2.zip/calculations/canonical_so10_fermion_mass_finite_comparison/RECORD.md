# MFC1: complete local mass-linear comparison and a projected VEV diagnostic

Previous goal turn PROGRESS: actual aeb5642 postcommit seal confirms the VTF
result and all33329 previous blobs preserved; current tree clean33367blobs,
no matching scientific workers. Baseaeb564236dce9572869029cad2f9421238f4d3e2,
main,state113/authority34of39 unchanged. Both new director assessments are
reviewed reference material, not new calculation receipts or acceptance.

Question: determine the complete dimension-one proper fermion two-point
DIM-minus-heat local comparison in the existing Cartesian reference, then
test its projected relation to the independently measured proper Yukawa and
J-h comparisons. A nonzero comparison defect is an allowed result. It is
not automatically a full Slavnov defect, obstruction or anomaly.

Actual partition must be recovered, not selected from the desired answer.
CSW/FBR use massless SMA K0, scalar positive reference masses and the actual
643-field bosonic reference with NO Bx or Lambda-x entries. Cartesian M(x)
is an interaction. The linear M(v) and both orbit bilinears therefore sit in
V. Each proper mass graph has three damped reference edges: heatlength6.
The algebraic massive SMP inverse is available for a separate resummation;
its existence never silently changed the previously frozen heat reference.
No physical scheme or benchmark is adopted by this calculation.

Freeze nonexceptional Euclidean external physical fermions/hats0, A_H=0,
full-D bosonic derivative contractions, barred spin rank4 and internal hats,
one formal power of M or orbit, both widths and general symmetric Y10/Y126.
This is the COMPLETE polynomial local mass-linear parent under power counting,
not the resummed massive amplitude, tadpole/pole mass or physical C1. Its IR
completion is common in the two regulator members; take no physical p=0 or
constant-vacuum trace limit. Existing VTS z/h remains explicitly provisional.

Qualified FMU supplies all five graph supports, actual phases and unexpanded
D-angular kernels; YPP supplies the pointwise critical pure-Yukawa zero.
Primary differentiates actual angular units and uses raw FMU endpoint tensors.
Replay derives the same finite units from Gaussian moments and positive-mass
radial-completion differences, and reconstructs color through the independent
fermion-Casimir/covariance endpoint expressions. Compare every16x16 mass
coefficient including zeros and factorize the untouched general3x3 families.
Keep both kinetic Bx and auxiliary Lambda-x orientations individually before
testing their sum. No old pole is assigned a convenient finite coefficient.

Independently prove the reference-parameter identity:
G_t=(H+K0(E^-1-1))^-1. For a constant insertion U, a fixed-reference
variation gives -E²G0UG0; co-varying K0 supplies the additional regulator
vertex U(E^-1-1) and gives -E G0UG0. Test the ordered noncommuting identity
on exact matrices and retain the resulting heat4/heat6 finite difference.
Changing K0 without that regulator transport is a negative control, not an
adopted alternative prescription. Reference determinant remains separately
retained; it has no external-P two-point coefficient in this comparison.

Only after mass extraction, contract both independently measured YHC proper
vertices with the actual VEV and compare VTF's half-background matching sign.
The diagnostic is D=Cmass-CY(v)-Chat(v), with field half-factors canceled by
an explicit generic parameter-map identity. These are RAW relative-parent
comparisons. This does not assume that they alone exhaust the full extended
chiral source/counterterm system or constitute its actual quantum breaking.
Preserve any exact nonzero D; do not choose chi4 or add a fitted primitive.

Gate independently checks units, all five terms, both routes/zero complements,
reality/mass symmetry, actual H-null relations, source sign and reference
placement. Controls omit either mixing family, wrong Wick sign, earlyD4,
wrong heatlength, naive massive numerator, extra half/family3, wrong source
sign. Report summed-pole insensitivities rather than claim universal controls.

Freeze8sources/copies plus inputs before sequential P/R/V600safterimports,
8GiB sampledprivate/350MiBlaunch/16MiBpacket. New delegated E4 native exits
must remain0/0/0/0/0/2,custody2sevenNOTPASS. Preserve failures/version repairs;
no broadened resources, agents or expensive qualified replay. Before/index/
after seals preserve33367oldblobs prior to local commit. Scholarly context:
arxiv2004.14398v2 distinguishes finite chiral restoring terms from ordinary
multiplicative normalization; arxiv1305.1548v3 distinguishes scalar/VEV factors.
Neither paper supplies this model's finite answer.

Ceiling: complete selected local mass-linear relative coefficient, an exact
reference-placement control and a qualified projected comparison diagnostic.
Not full hPP insertion/extended massive Slavnov restoration, all source/
products/QAP/measure/globalphase, background/hats, physical vacuum/causal/
Lorentzian/massiveC1,E5/A5 or GUT. Free constants remain symbolic/distinct.
Both adverse scalar points, quartetFAIL, flavorpause,HB1/C5blocks,state and
historical custody unchanged. No physical adoption/branch/worktree/push/
outreach/publication. Shared action, old tensors, regulator hypotheses,
software and AI authorship remain common-error limits.
