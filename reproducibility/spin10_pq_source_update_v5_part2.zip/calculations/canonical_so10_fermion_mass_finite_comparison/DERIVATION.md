# MFC1: reference placement, finite integrals and the meaning of the comparison

The current Cartesian quantum contract uses K0,fermion=Ctot times the massless
split SMA block. The actual retained643 reference has scalar reference masses
but no Bx/Lambda-x entries. Thus M(v), the physical kinetic Bx orbit and the
GF Lambda-x orbit each appear as one V insertion. The degree-one proper
self-energy has the two external-matter cubic vertices plus that insertion,
so all five graphs have three positive-heat reference edges, length6.
Their common critical contribution has logarithmic degree. There is no
external-momentum heat Taylor jet multiplying a lower-order power divergence
in this zero-jet mass coefficient. Higher mass powers are UV-subleading and
cannot enter a dimension-one polynomial local mass coefficient.

The actual unexpanded FMU angular units are

    F=-16/D, L=-24/[D(D+2)],
    kinetic_left/right=-4i/D, auxiliary_left/right=+4i/D.

Their phases were fixed from the common Wick transformation, not a desired
mass cancellation. For any such unit u(D), the relative integral is

    (chi4+log(3/2))*u(4)-2*u'(4).

This is derived from the same critical radial kernel and two regulator
members. The second term is a finite first dimension jet, not a pole fit.
The scalar-current derivative is FULL-dimensional before the barred fermion
projection, as in the independently qualified YHC comparison.

Independently, write a rank-2a barred numerator with a=1,2. Gaussian moments
give (2)_a/(D/2)_a and the massive radial integral gives
(D/2)_a/(a+1)!, leaving a D-independent factor in the dimensional integral.
At D4 the corresponding heat radial completions differ from the scalar
bubble by the convergent constants

    c_a=int_0^infinity dy y[y^a/(1+y)^(a+2)-1/(1+y)^2],
    c_1=-1/2, c_2=-5/6.

They are present in the heat integral and must be subtracted from the
dimensional finite coefficient. This reproduces relative ratios1/2,5/6.
The common heatlength6 adds log(6/4) relative to the known bubble convention.
Common positive-IR completions/nonexceptional external momenta are used
before extracting the local coefficient. The critical remainder has common
integrable UV/IR completion and vanishes from the relative local map. This
does not justify a physical zero-momentum or resummed massive trace limit.

Let J_Q(M)=sum Qab Ta^T M Tb and C_Q=sum Qab Ta Tb. The pole endpoint maps
from the actual action are

    E=-4J_I-(J_W-J_I),
    KL=C_W^T M+J_W, KR=M C_W+J_W,
    AL=-xi(C_I^T M+J_I), AR=-xi(M C_I+J_I).

At the actual reference mass both H endpoint actions vanish and J_H=0.
Therefore kinetic and auxiliary endpoints cancel pairwise BEFORE D4 and
with identical heat weights. Their individual finite terms remain retained.
For the scalar10 reference mass all these maps vanish; this does not remove
general Y10 interactions. The actual126 map obeys J_I=(5/8)M, J_W=xi J_I.
The critical pure-Yukawa mass class vanishes by the qualified unconjugated
scalar-map polarization, not by setting the Yukawa matrices to numbers.

## Exact reference-variation control

At flat scalar heat E, let H(lambda)=K0+lambda U+V. If K0 is fixed, the free
variation of the damped inverse is -E²G0UG0. If K0(lambda)=K0+lambda U is
co-varied, R_t changes by U(E^-1-1) and the total inverse variation is
-E G0UG0. The difference is E(1-E)G0UG0. U need not commute with G0.
Sewing the other self-energy edge supplies a heat4 versus heat6 difference.
Its relative local conversion changes by -log(3/2) times the mass pole map.
Moving a mass into a reference without transporting this term therefore
changes a finite answer. The identity is at fixed positive cutoff and is
not an unproved manipulation of a renormalized infinite trace. Reference
subtraction is retained; its P-independent term cannot supply this P² map.

## Projected comparison with Yukawa and vacuum-source parents

Use the actual YHC xPP map contracted with v, including both ordered scalar
currents. VTF defines the relative source addition +chi4 JKh and, with the
tree convention -Jh, Chat(v)=-chi4 B K v. Retain the actual YCT frame.

For arbitrary common fermion half-map F and scalar half-field mass image Z,
the bookkeeping definitions for relative parameter translations give

    deltaY(v)=CY(v)-F^T M-MF-Z,
    delta_v_required=CM-F^T M-MF-deltaY(v),
    delta_v_required-Z-Chat(v)=CM-CY(v)-Chat(v).

This cancellation does not assume F or Z has any preferred numerical value.
It does not prove that ordinary parameter translations exhaust finite chiral
restoration. An exact nonzero last expression identifies a missing term in
that projected parent comparison, not an anomaly or a no-counterterm theorem.
The actual extended source/heat insertion or an admissible correlated finite
completion must be examined before any restoration conclusion. No baseline
chi4,b0,kappa or physical mass may be fitted to erase the expression.
