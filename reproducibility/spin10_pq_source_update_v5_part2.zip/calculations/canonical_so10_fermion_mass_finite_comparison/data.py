"""MFC1 immutable IO/serialization; new finite derivations remain separate."""
from pathlib import Path
from hashlib import sha256
import json,gzip,os,sys,time,threading
import sympy as s
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
FMU_DIR=CAL/'canonical_so10_fermion_mass_uv';YHC_DIR=CAL/'canonical_so10_yukawa_vertex_heat_comparison';VTF_DIR=CAL/'canonical_so10_vacuum_tangent_source_finite'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
D=s.Symbol('D');eta,xi,chi=s.symbols('eta_H xi chi4',real=True)
LOC={'eta_H':eta,'xi':xi,'chi4':chi}
PARTS=('chi4','log3over2','fixed');TERMS=('exchange','kinetic_left','kinetic_right','auxiliary_left','auxiliary_right')
def tidy(m):return s.SparseMatrix(m).applyfunc(s.simplify)
def zero(m):assert not tidy(m).todok()
@lru_cache(maxsize=65536)
def coeff(z):return s.sympify(z,locals=LOC)
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):coeff(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(s.expand(z))] for (i,j),z in sorted(tidy(m).todok().items())]}
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('MFC1_PEER_DENIED')
   if p.parent in [YHC_DIR,VTF_DIR] and p.suffix=='.gz':raise PermissionError('MFC1_LATE_FINITE_COMPARATOR_DENIED')
 sys.addaudithook(audit);return tick
def finish(role,out,tick):
 out.update({'elapsed_after_imports':time.perf_counter()-tick,'physical_scheme_adopted':False,'finite_baseline_selected':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','resummed_massive_amplitude_calculated':False,
 'full_mass_VEV_chiral_Slavnov_QAP_measure_phase_E5A5_or_physical_C1_qualified':False})
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
