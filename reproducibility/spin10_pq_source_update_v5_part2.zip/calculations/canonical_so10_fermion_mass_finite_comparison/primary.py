"""MFC1 actual FMU angular derivative and directly contracted endpoint colors."""
from data import *
tick=begin('primary');old=packed(FMU_DIR/'primary_tables.json.gz')
angular=[s.sympify(z).subs(s.Symbol('d'),D) for z in old['angular_units']]
pole=[s.simplify(z.subs(D,4)) for z in angular]
fixed=[s.simplify(-2*s.diff(z,D).subs(D,4)) for z in angular]
assert pole==list(map(s.sympify,old['UV_units']))
# Complete critical-radial comparison has heat6. Zero-jet mass degree has no
# lower power/heat Taylor term. All integrable completion constants cancel.
unit=[{'uD':str(a),'pole':str(p),'fixed':str(f),'ratio':str(s.simplify(f/p))} for a,p,f in zip(angular,pole,fixed)]
models=[]
for m in old['models']:
 M=dec(m['M']);JI=dec(m['J_I']);JH=dec(m['J_H']);JW=xi*JI+(eta-xi)*JH
 colors=[JI,JW-JI]+[dec(m[n])/pole[j] for j,n in enumerate(TERMS[1:],2)]
 parts={}
 for j,n in enumerate(TERMS):
  if n=='exchange':A=pole[0]*colors[0]+pole[1]*colors[1];B=fixed[0]*colors[0]+fixed[1]*colors[1]
  else:A=pole[j+1]*colors[j+1];B=fixed[j+1]*colors[j+1]
  parts[n]={'chi4':enc(A),'log3over2':enc(A),'fixed':enc(B)}
 total={p:enc(sum((dec(parts[n][p]) for n in TERMS),s.zeros(16))) for p in PARTS}
 models.append({'carrier':m['carrier'],'M':enc(M),'parts':parts,'total':total})

# Noncommuting exact finite-mode resolvent control; E is scalar at flat A_H0.
K=s.Matrix([[2,1,0],[1,3,1],[0,1,4]]);U=s.Matrix([[1,0,1],[0,-1,0],[1,0,2]])
G=K.inv();e=s.Symbol('e',positive=True)
assert K*U!=U*K
fixed_ref=-e**2*G*U*G
transport=-e**2*G*(U*(1/e-1))*G
co_varied=-e*G*U*G
zero(fixed_ref+transport-co_varied)
zero(co_varied-fixed_ref+e*(1-e)*G*U*G)
finish('primary',{'method':'actual_FMU_angular_dimension_jets_and_direct_endpoint_color_tensors',
 'units':unit,'models':models,'heat_length':6,'reference_fermion_massless_Cartesian':True,
 'mass_and_both_orbit_terms_are_Born_insertions':True,
 'fixed_reference_mass_derivative':'-E^2*G0*U*G0','co_varied_reference_mass_derivative':'-E*G0*U*G0',
 'reference_transport_identity_remainder':0,'reference_control_matrix_positions':9,
 'pureY3_local_mass_zero':'AUTHENTICATED_POINTWISE_POLARIZATION_NOT_MASSIVE_AMPLITUDE_ZERO'},tick)
