from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/fermion-mass-finite-comparison-v1-2026-10-23')
OLD=CONTROL.with_name('vacuum-tangent-source-finite-v1-2026-10-23')
BASE='aeb564236dce9572869029cad2f9421238f4d3e2';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
CONTROL.mkdir(parents=True,exist_ok=False);bind={}
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==33367
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['postcommit_seal.json','after_seal_full_capture.json','seal.py']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'after_seal_full_capture.json')['native_exit']==0
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V571.md','docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for fo in ['canonical_so10_fermion_mass_uv','canonical_so10_vacuum_tangent_source_finite','canonical_so10_yukawa_vertex_heat_comparison','canonical_so10_sterile_massive_propagator','canonical_so10_sterile_matter_action','canonical_so10_fermionic_background_reference','canonical_so10_cutoff_source_ward_operator','canonical_so10_yukawa_carrier_transport','canonical_so10_auxiliary_scalar_mass_interface','canonical_so10_joint_marginal_fermion_normalization']:
 for n in ['RECORD.md','DERIVATION.md','RESULT.md']:
  p=CAL/fo/n
  if p.exists():add(p)
 for pat in ['*receipt*.json','*tables*.json.gz']:
  for p in (CAL/fo).glob(pat):add(p)
for fo,n in [('canonical_so10_sterile_matter_action','ACTION_V1.md'),('canonical_so10_fermionic_background_reference','candidate_background_reference.json.gz'),('canonical_so10_vacuum_tangent_source_finite','selected_vacuum_source_relative_member.json.gz')]:add(CAL/fo/n)
for n in ['frozen_a10_e5_full_hessian/primary.json','frozen_a10_physical_reconciliation/full_primary.json']:add(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'/n)
for tag in ['b1443272-efc3-4501-ada7-997710904d96','afc5c5d0-7218-40c3-972a-08495b09c26d']:add(Path('C:/Users/psboy/.codex/attachments')/tag/'Pasted text.txt')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:
 r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],stdout=out,stderr=err,cwd=ROOT)
ev=[json.loads(t) for t in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if t.strip()]
steps=[t['exit_code'] for t in ev if t.get('event')=='step_finished']
dump(CONTROL/'readiness_native_exit.json',{'native_exit':r.returncode,'step_exits':steps,'historical_custody':'EXIT2_SEVEN_NOTPASS' if steps==[0,0,0,0,0,2] else 'UNQUALIFIED','scientific_acceptance':'NOT_PERFORMED'})
assert r.returncode==0 and steps==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_native_exit.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'MFC1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('MFC1_FROZEN',len(bind),'bindings',flush=True)
