"""MFC1 late finite-parent and projected mass/VEV comparison gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for path,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(path))==h,path
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
assert P['method']!=R['method']
for k in P:
 if k not in ['method','elapsed_after_imports']:assert P[k]==R[k],k
assert P['heat_length']==6 and P['reference_transport_identity_remainder']==0
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];names=ref['field_order']
for i,j,z in ref['reference_Hessian_raw_C3']['entries']:
 assert not ((names[i].startswith('x_') and names[j].startswith(('B','L'))) or (names[j].startswith('x_') and names[i].startswith(('B','L'))))
fbr=packed(CAL/'canonical_so10_fermionic_background_reference/candidate_background_reference.json.gz')
assert 'massless_SMA' in fbr['definition'] and not fbr['physical_scheme_adopted'] and not fbr['historically_unique_reference_recovered']
v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')
Yp=packed(YHC_DIR/'primary_tables.json.gz');Yr=packed(YHC_DIR/'replay_v3_tables.json.gz')
V=packed(VTF_DIR/'selected_vacuum_source_relative_member.json.gz');K=dec(V['kernel_chi4'])
assert V['relative_action_addition_sign']==1 and V['relative_half_background_normalization_sign']==-1 and V['overall_factor']=='g10^2*xi/(16*pi^2)'
assert not V['physical_scheme_adopted'] and not V['finite_baseline_selected']
logr=s.log(s.Rational(3,2));comparisons=[];positions=0;control={}
oldfmu=packed(FMU_DIR/'primary_tables.json.gz')
def project_y(parent,vec):
 assert parent['shape']==[256,328] and vec.shape==(328,1)
 # The full parent is an authenticated qualified input. Only its contraction
 # with this actual reference vector is a new calculation, not a fresh replay
 # of every general-scalar coefficient.
 out=s.SparseMatrix(256,1,{})
 for i,j,z in parent['entries']:
  if vec[j]:out[i,0]+=coeff(z)*vec[j]
 return out
for idx,(pm,rm) in enumerate(zip(P['models'],R['models'])):
 M=dec(pm['M']);zero(M-M.T)
 for n in TERMS:
  for part in PARTS:
   a=dec(pm['parts'][n][part]);zero(a-dec(rm['parts'][n][part]));zero(a-a.T)
   positions+=256
 for part in PARTS:
  zero(dec(pm['parts']['kinetic_left'][part])+dec(pm['parts']['auxiliary_left'][part]))
  zero(dec(pm['parts']['kinetic_right'][part])+dec(pm['parts']['auxiliary_right'][part]))
  zero(dec(pm['total'][part])-sum((dec(pm['parts'][n][part]) for n in TERMS),s.zeros(16)))
 zero(dec(pm['total']['chi4'])-dec(oldfmu['models'][idx]['proper_mass_gauge_pole']))
 mass=chi*dec(pm['total']['chi4'])+logr*dec(pm['total']['log3over2'])+dec(pm['total']['fixed'])
 yparts={}
 for part in PARTS:
  yy=sum((project_y(Yp['models'][idx][n][part],v) for n in ['exchange','scalar_left','scalar_right']),s.zeros(256,1))
  yyR=sum((project_y(Yr['models'][idx][n][part],v) for n in ['exchange','scalar_left','scalar_right']),s.zeros(256,1))
  zero(yy-yyR);yparts[part]=s.Matrix(16,16,list(yy))
 yv=chi*yparts['chi4']+logr*yparts['log3over2']+yparts['fixed']
 B=dec(yc['B10' if idx==0 else 'B126']);source= -xi*chi*s.Matrix(16,16,list(B*K*v))
 defect=tidy(mass-yv-source)
 # Independent late compact coefficient follows separate endpoint algebra,
 # not a value supplied to either finite scientific worker.
 expected= -s.Rational(25,2)*xi*(logr+s.Rational(1,2))*M
 zero(defect-expected);zero(defect.diff(chi))
 zero(dec(pm['total']['chi4'])+s.Rational(5,8)*(3+xi)*M)
 zero(dec(pm['total']['fixed'])+s.Rational(5,48)*(7+5*xi)*M)
 comparisons.append({'carrier':pm['carrier'],'mass_comparison':enc(mass),'Yukawa_comparison_at_v':enc(yv),
  'half_background_source_matching':enc(source),'raw_projected_comparison_defect':enc(defect),
  'defect_independent_of_chi4':True,'mass_VEV_normalization_relation_zero':not bool(defect.todok())})
 if idx==1:
  for name,mat in {
   'omit_kinetic_fixed':dec(pm['parts']['kinetic_left']['fixed'])+dec(pm['parts']['kinetic_right']['fixed']),
   'omit_auxiliary_fixed':dec(pm['parts']['auxiliary_left']['fixed'])+dec(pm['parts']['auxiliary_right']['fixed']),
   'wrong_auxiliary_sign_fixed':-2*(dec(pm['parts']['auxiliary_left']['fixed'])+dec(pm['parts']['auxiliary_right']['fixed'])),
   'early_D4_total_fixed':dec(pm['total']['fixed']),
   'wrong_mass_heat4_log':logr*dec(pm['parts']['exchange']['chi4']),
   'naive_mass_numerator_fixed':2*dec(oldfmu['models'][idx]['J_I'])+(xi-1)*dec(oldfmu['models'][idx]['J_I'])/3,
   'wrong_source_matching_sign':-2*source,
   'extra_open_half':mass/2,'extra_family3':2*mass}.items():
   n=len(tidy(mat).todok());assert n>0;control[name]=n
  # Canceling both mixed groups is invisible to the total, so do not count it
  # as a sensitive omission test. All individual columns were checked above.
  zero(sum((dec(pm['parts'][n]['fixed']) for n in TERMS[1:]),s.zeros(16)))
  control['omit_both_mixed_groups_total_fixed_INSENSITIVE']=0

# Arbitrary field half maps cancel from this projected parameter comparison.
f=s.Matrix(2,2,s.symbols('f0:4'));mm=s.Matrix([[s.Symbol('m0'),s.Symbol('m1')],[s.Symbol('m1'),s.Symbol('m2')]])
cy=s.Matrix(2,2,s.symbols('cy0:4'));cm=s.Matrix(2,2,s.symbols('cm0:4'));zz=s.Matrix(2,2,s.symbols('z0:4'));chat=s.Matrix(2,2,s.symbols('h0:4'))
dy=cy-f.T*mm-mm*f-zz;vv=cm-f.T*mm-mm*f-dy
zero(vv-zz-chat-(cm-cy-chat))
Y=s.Matrix(3,3,lambda i,j:s.Symbol('u'+str(min(i,j))+str(max(i,j)),real=True)+s.I*s.Symbol('v'+str(min(i,j))+str(max(i,j)),real=True))
zero(Y-Y.T)
for row in comparisons:
 a=dec(row['mass_comparison']);full=s.kronecker_product(Y,a);zero(full-full.T)
 zero(full.conjugate().T-s.kronecker_product(Y.conjugate(),a.conjugate()))
assert comparisons[0]['mass_VEV_normalization_relation_zero'] and not comparisons[1]['mass_VEV_normalization_relation_zero']
recipe={'schema':'MFC1_COMPLETE_SELECTED_LOCAL_MASS_COMPARISON_AND_RAW_VEV_DIAGNOSTIC','heat_reference':'EXISTING_CARTESIAN_MASSLESS_SMA_WITH_MASS_ORBIT_IN_V',
 'overall_factor':'g10^2*Y_R/(16*pi^2)','heat_length':6,'models':P['models'],'projected_comparisons':comparisons,
 'finite_mass_unit_126':'-(5/8)*(3+xi)*(chi4+log(3/2))-(5/48)*(7+5*xi)',
 'raw_projected_126_defect_unit':'-(25/2)*xi*(log(3/2)+1/2)',
 'defect_is_actual_Slavnov_breaking_or_anomaly_theorem':False,'finite_parameters_selected':False,'physical_scheme_adopted':False,
 'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'local_mass_comparison_member.json.gz').open('xb') as out:out.write(blob)
result={'status':'QUALIFIED_COMPLETE_LOCAL_MASS_COMPARISON_AND_PROJECTED_VEV_DIAGNOSTIC',
 'individual_coefficient_positions_compared':positions,'model_carriers':2,'proper_mass_heat_length':6,
 'all_four_mixed_terms_retained_and_pairwise_cancel':True,'physical_reference_adopted':False,
 'finite_mass_unit_126':recipe['finite_mass_unit_126'],'raw_projected_126_defect_unit':recipe['raw_projected_126_defect_unit'],
 'raw_projected_defect_zero':False,'raw_projected_defect_independent_of_chi4':True,
 'defect_disposition':'NONZERO_RAW_PARENT_COMPARISON_NOT_FULL_SLAVNOV_OR_OBSTRUCTION',
 'controls_changed_mass_matrix_positions':control,'reference_transport_identity_remainder':0,
 'general_family_matrices_symbolic':True,'resummed_massive_amplitude_calculated':False,
 'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),
 'full_mass_VEV_chiral_Slavnov_QAP_measure_phase_E5A5_or_physical_C1_qualified':False,
 'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39',
 'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
