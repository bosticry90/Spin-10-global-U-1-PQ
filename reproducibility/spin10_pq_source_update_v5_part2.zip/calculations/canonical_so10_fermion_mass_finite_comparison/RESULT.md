# Finite local fermion mass comparison and projected vacuum diagnostic

MFC1 completes the dimension-one, mass-linear DIM-minus-heat proper fermion
two-point comparison in the existing Cartesian reference. Both derivations
and the dependent verifier completed with native exit 0. This is a local
polynomial comparison, not a resummed massive amplitude or physical pole mass.

The reference recovered from CSW/FBR is massless in its SMA fermion block.
Its bosonic part has positive scalar reference masses and no scalar/vector
or scalar/auxiliary orbit mixing. Consequently the mass insertion and both
orbit insertions belong to the interaction. All five supported proper graphs
have three damped reference edges, with heat length 6. No reference or physical
renormalization scheme was changed.

With the common factor g10^2/(16 pi^2) suppressed, the complete result is

    C_M = M126 [-(5/8)(3+xi)(chi4+log(3/2))
                -(5/48)(7+5xi)].

The scalar-10 reference mass is zero; its general Yukawa interactions remain.
Both general complex symmetric three-family Yukawa matrices stay symbolic.
No extra family multiplicity or open-line Pfaffian half was introduced.

The first route differentiates the authenticated unexpanded FMU angular
units and uses its direct endpoint contractions. The second derives finite
units through Gaussian moments and convergent radial completion differences,
then reconstructs endpoints from independent Casimir and covariance formulas.
All 7,680 individual matrix coefficient slots agree, including zeros. Both
kinetic orientations and both auxiliary orientations are retained separately.
They cancel pairwise before the four-dimensional limit with identical heat
weights. The critical pure-Yukawa mass zero is inherited from its qualified
polarization proof; no general finite massive Yukawa amplitude is set to zero.

An ordered reference-variation identity was also checked on noncommuting
exact matrices. Varying an interaction at fixed reference and varying the
reference together with its regulator differ by an explicit heat insertion.
Omitting that transport changes the relative local coefficient by
-log(3/2) times the exchange pole map. This is a diagnostic, not adoption of
the alternative reference. The reference determinant remains retained.

## The projected comparison is nonzero

The verifier contracts the independently measured YHC proper scalar vertex
with the actual vacuum and uses VTF's source matching sign from tree -J h.
For D = C_M - C_Y(v) - C_hat(v), it obtains

    D126 = -(25/2) xi [log(3/2)+1/2] M126,
    D10 = 0,

again with the common g10^2/(16 pi^2) suppressed. This result is independent
of chi4. An explicit generic parameter-map identity shows that common fermion
and scalar half-field maps cancel from this diagnostic. Choosing a preferred
field normalization or finite baseline therefore cannot remove it.

This is a raw parent comparison. It has not yet been identified with the
complete extended hPP Slavnov breaking, nor has the admissible correlated
finite counterterm space been exhausted. It is neither an anomaly finding
nor a no-counterterm theorem. The next calculation must derive the actual
extended source insertion and regulator response before assessing restoration.

Controls detect omitted single mixing groups, wrong auxiliary sign, early
four-dimensional reduction, wrong heat length, naive mass numerator, wrong
source sign, and spurious half or family factors. Omitting both mixing groups
is explicitly insensitive in their summed fixed term, since the groups cancel;
that control is not represented as detecting an error.

## Evidence and limits

Receipt SHA256:
50ed678f56b7dc358ec32f3374df544a41183ab937205a1bd5d49a59493d404d.
Artifact packed SHA256:
cac42c88e6080f671939ecc32e8206520ab8a08df577ff99ad17d517ab0706c5.
Artifact raw SHA256:
83fcf9ebc925810e26f3bb5da00fb615d618cafe0baeb32b62267a92df3f6e35.

Primary/replay/verifier took 1.992352/4.231946/4.469572 seconds after imports.
Their sampled private memory maxima were 50,499,584/53,182,464/74,665,984 bytes;
these are samples, not measured peaks. All frozen 600-second, 8-GiB private,
350-MiB launch-floor and 16-MiB packet limits held. Eight source copies,
98 preparation bindings and 106 validation bindings preserve the calculation.
No MFC scientific worker or controller failure occurred. Full native captures
are retained internally and in the external control directory. The new E4
audit completed with root exit 0 and step exits 0/0/0/0/0/2; historical custody
remains exit 2 with seven unresolved references, never PASS.

The supplied assessments were reviewed as context and bound at preparation.
They support a discriminating calculation with unchanged premises, rather
than fitting unknown terms to improve the benchmark. This increment follows
that distinction. Its independent mathematical routes still share action,
old tensors, regulator assumptions, software and AI authorship. They are
computational corroboration, not independent scientific confirmation.

The provisional z/h extension, full massive/source/QAP construction, physical
vacuum and causal limits, global phase, physical C1 and full E5/A5 remain open.
Authority stays 34/39 and project_state.json is unchanged. All prior adverse
physical results, quartet failure, paused flavor, HB1/C5 boundaries and
historical evidence are preserved. No physical scheme or benchmark is adopted.
