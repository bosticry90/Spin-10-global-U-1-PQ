"""MFC1 Gaussian/radial-completion integral route and independent Casimir endpoints."""
from data import *
tick=begin('replay');old=packed(FMU_DIR/'replay_tables.json.gz')
eps=s.Symbol('epsilon');y=s.Symbol('y',positive=True)
radial=[]
for a in [1,2]:
 c=s.integrate(s.cancel(y*(y**a/(1+y)**(a+2)-1/(1+y)**2)),(y,0,s.oo))
 radial.append(c)
assert radial==[-s.Rational(1,2),-s.Rational(5,6)]
# Gaussian physical barred rank4 moments times the massive radial factors:
# (2)_a/(D/2)_a * (D/2)_a/(a+1)! = 1. The finite heat completion c_a
# remains after that dimensional cancellation and determines the finite jet.
for a in [1,2]:
 b=s.rf(2,a)/s.rf(D/2,a);rad=s.rf(D/2,a)/s.factorial(a+1)
 assert s.simplify(b*rad)==1
b1=4/D;b2=24/(D*(D+2));angular=[-4*b1,-b2,-s.I*b1,-s.I*b1,s.I*b1,s.I*b1]
pole=[s.simplify(v.subs(D,4)) for v in angular]
ratios=[-radial[0],-radial[1],-radial[0],-radial[0],-radial[0],-radial[0]]
fixed=[p*q for p,q in zip(pole,ratios)]
unit=[{'uD':str(s.factor(a)),'pole':str(p),'fixed':str(f),'ratio':str(q)} for a,p,f,q in zip(angular,pole,fixed,ratios)]
CI,CH=map(dec,[old['C_I'],old['C_H']]);CW=xi*CI+(eta-xi)*CH;models=[]
for m in old['models']:
 M=dec(m['M']);JI=dec(m['J_I']);JH=dec(m['J_H']);JW=xi*JI+(eta-xi)*JH
 # The independent Casimir/covariance route: these are endpoint tensors,
 # not the old stored kinetic/auxiliary pole columns.
 endpoints={'exchange':(-4*JI-(JW-JI),-2*JI-s.Rational(5,6)*(JW-JI)),
 'kinetic_left':(CW.T*M+JW,(CW.T*M+JW)/2),
 'kinetic_right':(M*CW+JW,(M*CW+JW)/2),
 'auxiliary_left':(-xi*(CI.T*M+JI),-xi*(CI.T*M+JI)/2),
 'auxiliary_right':(-xi*(M*CI+JI),-xi*(M*CI+JI)/2)}
 parts={n:{'chi4':enc(v[0]),'log3over2':enc(v[0]),'fixed':enc(v[1])} for n,v in endpoints.items()}
 total={p:enc(sum((dec(parts[n][p]) for n in TERMS),s.zeros(16))) for p in PARTS}
 models.append({'carrier':m['carrier'],'M':enc(M),'parts':parts,'total':total})
# Independent derivative-of-inverse proof in an exact nonnormal basis.
l,e=s.symbols('lambda e');K=s.Matrix([[2,1,0],[1,3,1],[0,1,4]]);U=s.Matrix([[1,0,1],[0,-1,0],[1,0,2]])
deriv=(e*(K+l*U).inv()).diff(l).subs(l,0)
rhs=-e*K.inv()*U*K.inv();zero(deriv-rhs)
fixed_ref=-(e*K.inv())*U*(e*K.inv());regulator_part=-(e*K.inv())*(U*(1/e-1))*(e*K.inv())
zero(fixed_ref+regulator_part-rhs)
finish('replay',{'method':'barred_Gaussian_moments_radial_completion_integrals_and_Casimir_endpoints',
 'units':unit,'models':models,'heat_length':6,'reference_fermion_massless_Cartesian':True,
 'mass_and_both_orbit_terms_are_Born_insertions':True,
 'fixed_reference_mass_derivative':'-E^2*G0*U*G0','co_varied_reference_mass_derivative':'-E*G0*U*G0',
 'reference_transport_identity_remainder':0,'reference_control_matrix_positions':9,
 'pureY3_local_mass_zero':'AUTHENTICATED_POINTWISE_POLARIZATION_NOT_MASSIVE_AMPLITUDE_ZERO'},tick)
