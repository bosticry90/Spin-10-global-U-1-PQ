"""GTT1 complete triangle comparison, exact-once cPP assembly and fixed g2 test."""
from data import *
from collections import defaultdict,Counter
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def nz(M):return len(s.SparseMatrix(M.applyfunc(s.simplify)).todok())
def zero(M):assert not nz(M)
def rows(rr):
 out={}
 for row in rr:
  key=tuple(row[:3]);assert key not in out and all(0<=i<45 for i in key);out[key]=s.sympify(row[3],locals={'xi':WM,'eta_H':WH})
 return out
def same(a,b):
 for key in set(a)|set(b):assert s.simplify(a.get(key,0)-b.get(key,0))==0,key
pj={j:rows(P['raw_jets'][j]) for j in ['a','B','c']};rj={j:rows(R['raw_jets'][j]) for j in ['a','B','c']}
dif={j:{k:s.simplify(pj[j].get(k,0)-rj[j].get(k,0)) for k in set(pj[j])|set(rj[j])} for j in pj};same(dif['a'],dif['B']);same(dif['a'],dif['c'])
boundary={k:v for k,v in dif['a'].items() if v};same(rows(P['raw_H']),rows(R['raw_H']))
for j in ['a','B','c']:
 # A shared change of all three jets is an explicitly retained total
 # derivative, not a change of the conserved-momentum vertex.
 assert all(s.simplify(v-s.conjugate(v))==0 for v in rows(P['plane_jets'][j]).values())
for key in ['plane_V','plane_A','plane_H']:same(rows(P[key]),rows(R[key]))
ref=packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields'];same(rows(P['plane_V']),rows(ref['old_plane_V']));same(rows(P['plane_H']),rows(ref['old_plane_H']))
for key in ['raw_Gca','raw_aux_map','C3_chart']:zero(dec(P[key])-dec(R[key]))
assert P['literal_counts']['a']==3480 and P['literal_counts']['B']==720 and P['literal_counts']['H']==276 and P['literal_counts']['c']>0
for obj in [P,R]:
 assert obj['source_chart_remainder']==obj['free_E_arbitrary_internal_hat_remainder']=='0'
 assert obj['cumulant_units']==['1','1'] and obj['ordinary_phases']==['-I','-I'] and obj['auxiliary_phases']==['I','I']
 assert obj['I0']=='-1/2' and obj['J']=='-1/12' and obj['wrong_J']=='-1/8'
 assert obj['Taylor_coefficients']==[['1/6','1/3'],['1/6','-1/6']]
 assert not obj['extra_family_or_Nambu_half'] and not obj['source_primitive_read_to_fit_quantum_input'] and not obj['full_QAP_Slavnov_or_physical_scheme_claimed']
assert P['word_signs']==[[-1]*6,[-1]*6] and R['simplex_moments']==['1/2','1/6','1/6'] and R['convergent_auxiliary_mass_remainder']=='0'
assert sorted(P['supported_witnesses'])==sorted(R['supported_witnesses']) and len(P['supported_witnesses'])==8
grades=Counter(json.loads(w)[5] for w in P['supported_witnesses']);assert grades=={3:6,2:2}
counts={};controls={};reality={};compared=0
for degree in ['2','3']:
 cc=Counter();ctrl=Counter();real=Counter()
 for jet in ['p','q']:
  for chirality in ['left','right']:
   assert len(P[chirality][degree][jet])==len(R[chirality][degree][jet])==45
   for a in range(45):
    M=dec(P[chirality][degree][jet][a]);zero(M-dec(R[chirality][degree][jet][a]));cc[chirality+'_'+jet]+=nz(M);compared+=16**2
    oriented=[]
    for i in range(2):
     v=dec(P[chirality+'_orientations'][degree][i][jet][a]);zero(v-dec(R[chirality+'_orientations'][degree][i][jet][a]));oriented.append(v);compared+=16**2
    zero(M-oriented[0]-oriented[1])
    if chirality=='left':
     ctrl['omit_orientation0_'+jet]+=nz(oriented[0]);ctrl['omit_orientation1_'+jet]+=nz(oriented[1]);ctrl['wrong_mixed_orientation_sign_'+jet]+=nz(M-(oriented[0]-oriented[1]))
  for a in range(45):
   lp=dec(P['left'][degree]['p'][a]);lq=dec(P['left'][degree]['q'][a]);rp=dec(P['right'][degree]['p'][a]);rq=dec(P['right'][degree]['q'][a]);zero(rp-lp.T);zero(rq-(lp-lq).T)
   M=lp if jet=='p' else lq;badC=dec(P['omit_C_jet_left'][degree][jet][a]);badA=dec(P['unweighted_angle_left'][degree][jet][a]);zero(badA-dec(R['unweighted_angle_left'][degree][jet][a]));compared+=16**2
   if not boundary:zero(badC-dec(R['omit_C_jet_left'][degree][jet][a]));compared+=16**2
   ctrl['omit_external_C_derivative_'+jet]+=nz(M-badC);ctrl['unweighted_angle_'+jet]+=nz(M-badA)
   if jet=='q':ctrl['omit_momentum_reversal_q']+=nz(rq+lq.T)
   real[jet]+=nz(lp.H+lp if jet=='p' else lq.H-lq+lp)
 counts[degree]=dict(cc);controls[degree]=dict(ctrl);reality[degree]=dict(real)
 assert cc['left_q']>0 and cc['right_q']>0
 if degree=='2':assert cc['left_p']==cc['right_p']==0
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);f={tuple(row[:3]):s.sympify(row[3]) for row in ref['plane_f']};hrows=[]
for h in range(12):
 rr=defaultdict(list)
 for a in range(45):
  by=defaultdict(lambda:s.S.Zero)
  for (b,aa,e),co in f.items():
   if aa==a and HF[b,h]:by[e]+=HF[b,h]*co
  rr[a]=[(e,s.simplify(co)) for e,co in by.items() if s.simplify(co)!=0]
 hrows.append(rr)
cov_nonzero={}
for degree in ['2','3']:
 cov_nonzero[degree]={}
 for jet in ['p','q']:
  mm=list(map(dec,P['left'][degree][jet]));bad=[]
  for h in range(12):
   th=sum((HF[b,h]*T[b] for b in range(45) if HF[b,h]),s.zeros(16))
   for a in range(45):
    d=(-s.I*(th*mm[a]-mm[a]*th)-sum((co*mm[e] for e,co in hrows[h][a]),s.zeros(16))).applyfunc(s.simplify)
    if nz(d):bad.append([h,a,enc(d)])
  cov_nonzero[degree][jet]=bad
# Independent graded kinetic variation and its retained boundary current.
def add(A,B):
 out=dict(A)
 for key,co in B.items():out[key]=s.expand(out.get(key,0)+co)
 return {k:v for k,v in out.items() if v!=0}
def wedge(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(6) if a&(1<<i))*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def word(ww,co):
 out={0:co}
 for i in ww:out=wedge(out,{1<<i:1})
 return out
# c0,dc1,barpsi2,dbarpsi3,psi4,dpsi5; x/gamma are even spectators.
flow=wedge(word([0,2],s.I),word([5],1));dq=add(word([1,4],-s.I),word([0,5],-s.I));flow=add(flow,{key:-v for key,v in wedge(word([2],1),dq).items()});representative=word([1,2,4],-s.I);assert flow==representative
euler=add(word([0,3,4],s.I),word([0,2,5],s.I));divergence=add(add(word([1,2,4],s.I),word([0,3,4],s.I)),word([0,2,5],s.I));assert euler==add(representative,divergence)
assert s.simplify((-s.I)*s.I)==1
MSP=packed(CAL/'canonical_so10_matter_source_primitive/primary_tables.json.gz');MSR=packed(CAL/'canonical_so10_matter_source_primitive/replay_tables.json.gz');source={};rem={};matching=Counter()
for side,chirality in [('left','X_left'),('right','X_right')]:
 source[side]=[];rem[side]={'p':[],'q':[]}
 for a in range(45):
  x=dec(MSP[chirality]['3'][a]);zero(x-dec(MSR[chirality]['3'][a]));body=-s.I*x;source[side].append(enc(body))
  for jet in ['p','q']:
   d=(dec(P[side]['2'][jet][a])+(body if jet=='q' else s.zeros(16))).applyfunc(s.simplify);rem[side][jet].append(enc(d));matching[side+'_'+jet]+=nz(d)
match_disposition='SELECTED_G2_KINETIC_CHANNEL_CANCELS_MOD_RETAINED_CURRENT' if not any(matching.values()) else 'NONZERO_FIXED_G2_KINETIC_MATCHING_REMAINDER_PRESERVED'
# Exact-once twelve-support assembly, preserving all formal coupling roles.
ib=packed(CAL/'canonical_so10_matter_breaking_support/primary_tables.json.gz');allw=set(ib['targets']['cPP']['candidate']);gf=set(P['supported_witnesses']);gauge=set();yuk=set()
for w in allw:
 origins=sorted(ib['vertices'][n]['origin'] for n in json.loads(w)[0])
 if origins in [['E_P','PPB','PPB'],['E_S','PPB','PPB']]:gauge.add(w)
 if origins in [['E_P','PPx','PPx'],['E_S','PPx','PPx']]:yuk.add(w)
assert len(gauge)==len(yuk)==2 and len(gf)==8 and len(gf|gauge|yuk)==12 and gf|gauge|yuk==allw and not(gf&gauge or gf&yuk or gauge&yuk)
GP=packed(CAL/'canonical_so10_gauge_fermion_insertion/primary_tables.json.gz');GR=packed(CAL/'canonical_so10_gauge_fermion_insertion/replay_tables.json.gz');YP=packed(CAL/'canonical_so10_yukawa_finite_vertex_ward/primary_tables.json.gz');YR=packed(CAL/'canonical_so10_yukawa_finite_vertex_ward/replay_tables.json.gz');assembly={};assembly_counts={};assembly_compared=0
for tag in ['g2','g3','gY10','gY126']:
 assembly[tag]={};nn=Counter()
 for side in ['left','right']:
  assembly[tag][side]={'p':[],'q':[]}
  for jet in ['p','q']:
   for a in range(45):
    if tag in ['g2','g3']:
     degree=tag[1:];v=dec(P[side][degree][jet][a]);w=dec(R[side][degree][jet][a])
     if tag=='g3' and jet=='q':v+=dec(GP[side][a]);w+=dec(GR[side][a])
    else:
     idx=0 if tag=='gY10' else 1;v=s.I*dec(YP['fermion_vertex_'+side][idx][a]) if jet=='q' else s.zeros(16);w=s.I*dec(YR['fermion_vertex_'+side][idx][a]) if jet=='q' else s.zeros(16)
    zero(v-w);assembly[tag][side][jet].append(enc(v));nn[side+'_'+jet]+=nz(v);assembly_compared+=16**2
 assembly_counts[tag]=dict(nn)
for side in ['left','right']:
 for idx in range(2):zero(dec(YP['family_'+side][idx])-dec(YR['family_'+side][idx]))
family={'g2':{'left':enc(s.eye(3)),'right':enc(s.eye(3))},'g3':{'left':enc(s.eye(3)),'right':enc(s.eye(3))},'gY10':{'left':YP['family_left'][0],'right':YP['family_right'][0]},'gY126':{'left':YP['family_left'][1],'right':YP['family_right'][1]}}
extra={'g2_fixed_source_companion':source,'g2_matching_remainders':rem,'literal_minus_Euler_boundary_current':[[*key,str(co)] for key,co in sorted(boundary.items())],'internal_H_covariance_remainders':cov_nonzero,'complete_cPP_components':assembly,'family_factors':family,'source_Euler_boundary_current_unit':'I','source_kinetic_representative_unit':'-I','source_kinetic_Fourier_q_unit':'1','all12_supports_exact_once':True}
raw=(json.dumps(extra,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'comparison_tables.json.gz').open('xb') as out:out.write(blob)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
covcounts={degree:{jet:len(v) for jet,v in tab.items()} for degree,tab in cov_nonzero.items()}
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_GF_GHOST_FINITE_FIELD_INSERTION','elapsed_after_imports':time.perf_counter()-start,'triangle_supports':8,'ordinary_g3_supports':6,'auxiliary_g2_supports':2,'full_cPP_supports_assembled_exactly_once':12,'literal_density_positions':dict(P['literal_counts']),'new_external_ghost_derivative_retained':True,'literal_Euler_boundary_current_positions':len(boundary),'plane_vertex_nonzero_positions':{j:len(rows(P['plane_jets'][j])) for j in ['a','B','c']},'triangle_matrix_positions_compared':compared,'nonzero_positions':counts,'controls':controls,'analytic_reality_remainder_positions':reality,'internal_H_nonzero_blocks':covcounts,'selected_g2_matching_disposition':match_disposition,'selected_g2_matching_remainder_positions':dict(matching),'complete_cPP_matrix_positions_assembled_compared':assembly_compared,'complete_cPP_component_nonzero_positions':assembly_counts,'factorized_general_family_matrices_retained':True,'comparison_tables_sha256':sha256(blob).hexdigest(),'comparison_raw_sha256':sha256(raw).hexdigest(),'source_Euler_boundary_current_retained':True,'g3_counterterm_matching_and_complete_Slavnov_QAP_measure_phase_massive_matching_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
