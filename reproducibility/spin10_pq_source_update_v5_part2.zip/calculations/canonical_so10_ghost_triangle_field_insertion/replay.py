"""GTT1 Euler density, independent Berezin/Schwinger route and Lie reduction."""
from data import *
from collections import defaultdict
from itertools import combinations
start=begin('replay');g=s.Symbol('g10')
def expr(v):return s.sympify(v,locals={'g10':g,'xi':WM,'eta_H':WH})
def clean(d):return {key:s.simplify(v) for key,v in d.items() if s.simplify(v)!=0}
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return clean(out)
def scale(z,A):return clean({k:z*v for k,v in A.items()})
def wedge(A,B,n=8):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(n) if a&(1<<i))*x*y
 return clean(out)
def word(ww,co):
 out={0:co}
 for i in ww:out=wedge(out,{1<<i:1})
 return out
F,Q0,al,be,de,B,L=s.symbols('F Q alpha beta delta B Lambda',nonzero=True);units=[]
for EW,VW in [([0,6,5,2],[3,4]),([0,6,3,4],[5,2])]:
 action={}
 for ww,co in [([4,5],-F),([6,7],-Q0),(EW,al),(VW,be*B),([7,1],de*L)]:action=add(action,word(ww,co))
 term=out={0:s.S.One}
 for n in range(1,5):term=scale(-s.Rational(1,n),wedge(term,action));out=add(out,term)
 internal=sum(1<<i for i in range(4,8));Z={key^internal:co for key,co in out.items() if key&internal==internal};assert set(Z)=={0,15} and s.expand(Z[0]-F*Q0)==0
 units.append(s.simplify(Z[15]*F*Q0/(Z[0]*al*be*de*B*L)))
# Actual chiral matrix order: hats commute with A, barred gammas swap A.
def cliff(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():out[a^b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(6) if a&(1<<i))*x*y
 return clean(out)
tl,tr=s.symbols('tL tR');AA={0:(tl+tr)/2,15:(tl-tr)/2};At={0:(tl+tr)/2,15:(tr-tl)/2}
for nu in range(4):assert not add(cliff({1<<nu:1},AA),scale(-1,cliff(At,{1<<nu:1})))
for nu in [4,5]:assert cliff({1<<nu:1},AA)==cliff(AA,{1<<nu:1})
# E_PS=-i At hatr, E_SP=+i hatk A; actual i*E gives +/- signs.
ep=s.simplify(s.I*(-s.I));es=s.simplify(s.I*s.I)
ordinary_phases=[s.simplify(units[0]*es*(-s.I)*(-s.I)*(-s.I)),s.simplify(units[1]*ep*(-s.I)*(-s.I)*(+s.I))]
aux_phases=[s.simplify(units[0]*es*(-s.I)*(-s.I)*(+s.I)*(+1)),s.simplify(units[1]*ep*(-s.I)*(-s.I)*(+s.I)*(-1))]
data=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz');E1=read(PK/'frozen_a10_e1_fermion/replay.json');raw={j:defaultdict(lambda:s.S.Zero) for j in ['a','B','c']}
for name,erows in E1['Euler_columns'].items():
 if name not in data['master_field_maps']:continue
 parity=int(name.startswith(('bar','ub')));shift=-(-1)**parity
 for er in erows:
  for mr in data['master_field_maps'][name]:
   ww=er['word']+mr['word'];base=[n.split('__')[0] for n in ww]
   if len(ww)!=3:continue
   bs=[i for i,n in enumerate(base) if n.startswith('B')];aas=[i for i,n in enumerate(base) if n.startswith(('bar','ub'))];cs=[i for i,n in enumerate(base) if n.startswith('C')]
   if len(bs)!=len(aas) or len(bs)!=len(cs) or len(bs)!=1:continue
   b,a,c=bs[0],aas[0],cs[0];jets=[i for i,n in enumerate(ww) if '__' in n];assert len(jets)==1;pos=jets[0];mu=int(ww[pos].split('__')[1]);r,nu=map(int,base[b][1:].split('_'));assert mu==nu
   if mu!=0:continue
   anti=int(base[a][3:] if base[a].startswith('bar') else base[a][2:]);key=r,anti,int(base[c][1:]);which='a' if pos==a else 'B' if pos==b else 'c'
   co=s.simplify(shift*(-1 if c<a else 1)*expr(er['coefficient'])*expr(mr['coefficient'])/g);assert not co.has(g,WH,WM);raw[which][key]+=co
raw={j:clean(v) for j,v in raw.items()};HR=defaultdict(lambda:s.S.Zero)
for name in [f'ub{i}' for i in range(12,45)]:assert [r for r in data['master_field_maps'][name] if len(r['word'])==1]==[{'coefficient':'-1','word':['L'+name[2:]]}]
for row in E1['polynomial_parts']['heavy_cubic']:
 ww=row['word'];co=expr(row['coefficient']);odd=0
 for pos,name in enumerate(ww):
  if name.startswith('ub'):
   rest=list(ww);rest[pos]='L'+name[2:];la=next(n for n in rest if n.startswith('L'));aa=next(n for n in rest if n.startswith('ub'));cc=next(n for n in rest if n.startswith('C'));sgn=-1 if rest.index(cc)<rest.index(aa) else 1
   HR[int(la[1:]),int(aa[2:]),int(cc[1:])]+=-co*(-1)**odd*sgn/WM
  odd+=1
HR=clean(HR)
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['C3_plane_to_parent']);Qi=Q.inv();FM=dec(E1['charts']['blocks']['heavy_dual']['field_embedding']);Ai=s.SparseMatrix.hstack(Q[:,:12],FM).inv();CG=Qi*Ai.T
def rows(M):return {i:[(j,v) for (ii,j),v in M.todok().items() if ii==i] for i in range(45)}
qr,ar=rows(Qi),rows(Ai)
def transport(d,first):
 out=defaultdict(lambda:s.S.Zero)
 for (r,a,c),v in d.items():
  for rr,x in first[r]:
   for aa,y in ar[a]:
    for cc,z in qr[c]:out[rr,aa,cc]+=v*x*y*z
 return clean(out)
plane={j:transport(v,qr) for j,v in raw.items()};H=transport(HR,ar)
V=clean({k:plane['a'].get(k,0)-plane['B'].get(k,0) for k in set(plane['a'])|set(plane['B'])});A=clean({k:plane['a'].get(k,0)-plane['c'].get(k,0) for k in set(plane['a'])|set(plane['c'])})
for (r,a,c),v in H.items():assert s.simplify(v+H.get((a,r,c),0))==0
# Shifted Schwinger simplex: numerator k-s becomes yu+zv-s. The
# hatted Gaussian moment times the denominator prefactor is h Gamma/2.
y,z=s.symbols('y z');eps,h=s.symbols('epsilon h');simplex=lambda v:s.integrate(s.integrate(v,(z,0,1-y)),(y,0,1))
area=simplex(1);mean_y=simplex(y);mean_z=simplex(z);Pp,Qq=s.symbols('p q');regscale=h*s.gamma(1+eps)/2
finite=lambda v:s.simplify(s.diff(v.subs(h,-2*eps),eps).subs(eps,0))
int1=finite(regscale*(mean_y*Pp+mean_z*(Pp+Qq)-area*(Pp+Qq)));int2=finite(regscale*(mean_y*(Pp+Qq)+mean_z*Pp-area*Pp))
taylor=[[s.diff(int1,Pp),s.diff(int1,Qq)],[s.diff(int2,Pp),s.diff(int2,Qq)]]
I0=finite(h*s.gamma(1+eps)/(2*s.factorial(2)));J=finite(h*s.gamma(1+eps)/(4*s.factorial(3)));D=4-2*eps;Jbad=finite(h*(D+2)*s.gamma(1+eps)/(24*D));bad_taylor=[[-I0+4*Jbad,-I0+2*Jbad],[-I0+4*Jbad,2*Jbad]]
assert s.limit(h*s.gamma(1+eps)/12,h,0)==0
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-v.T for v in T];HF=dec(Y['H_new']);W=WH*HF*HF.T+WM*(s.eye(45)-HF*HF.T);fc=defaultdict(list)
for a,b,e,co in packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:fc[a,b].append((e,s.sympify(co)))
def reduce(tab,weight,gen):
 sym=[s.zeros(16) for _ in range(45)];nc=defaultdict(lambda:s.S.Zero);wr=defaultdict(list)
 for (b,r),co in s.SparseMatrix(weight).todok().items():wr[r].append((b,co))
 for (r,a,c),co in tab.items():
  for b,v in wr[r]:
   sym[c]+=co*v*(gen[b]*gen[a]+gen[a]*gen[b])/2
   for e,f in fc[b,a]:nc[c,e]+=co*v*f/2
 grouped=defaultdict(list)
 for (c,e),co in clean(nc).items():grouped[c].append((e,co))
 anti=[s.I*sum((co*gen[e] for e,co in grouped[c]),s.zeros(16)) for c in range(45)]
 return [M.applyfunc(s.expand) for M in sym],[M.applyfunc(s.expand) for M in anti]
def calculate(gen,joint,tt,aa):
 SV,AV=reduce(V,W,gen);SA,AA=reduce(aa,I0*s.eye(45)+joint*(W-s.eye(45)),gen);SH,AH=reduce(H,s.eye(45),gen)
 parts={'3':[],'2':[]}
 for i,sign in enumerate([1,-1]):
  CV=[s0+sign*a0 for s0,a0 in zip(SV,AV)];CA=[s0+sign*a0 for s0,a0 in zip(SA,AA)];CH=[s0+sign*a0 for s0,a0 in zip(SH,AH)]
  parts['3'].append({'p':[enc(ordinary_phases[i]*tt[i][0]*v) for v in CV],'q':[enc(ordinary_phases[i]*(tt[i][1]*v+sign*a)) for v,a in zip(CV,CA)]})
  parts['2'].append({'p':[enc(aux_phases[i]*WM*tt[i][0]*v) for v in CH],'q':[enc(aux_phases[i]*WM*tt[i][1]*v) for v in CH]})
 # Independent collected sum; do not use the serialized oriented tables.
 total={'3':{'p':[],'q':[]},'2':{'p':[],'q':[]}}
 for c in range(45):
  total['3']['p'].append(enc(ordinary_phases[0]*((tt[0][0]+tt[1][0])*SV[c]+(tt[0][0]-tt[1][0])*AV[c])))
  total['3']['q'].append(enc(ordinary_phases[0]*((tt[0][1]+tt[1][1])*SV[c]+(tt[0][1]-tt[1][1])*AV[c]+2*AA[c])))
  total['2']['p'].append(enc(aux_phases[0]*WM*((tt[0][0]+tt[1][0])*SH[c]+(tt[0][0]-tt[1][0])*AH[c])))
  total['2']['q'].append(enc(aux_phases[0]*WM*((tt[0][1]+tt[1][1])*SH[c]+(tt[0][1]-tt[1][1])*AH[c])))
 return total,parts
left,orientL=calculate(T,J,taylor,A);right,orientR=calculate(U,J,taylor,A);bad_uc,_=calculate(T,J,taylor,plane['a']);bad_angle,_=calculate(T,Jbad,bad_taylor,A)
ib=packed(CAL/'canonical_so10_matter_breaking_support/replay_tables.json.gz');witnesses=[]
for w in ib['targets']['cPP']['candidate']:
 oo=sorted(json.loads(n)[0] for n in json.loads(w)[0])
 if oo in [['E_C','GF','PPB'],['E_S','GF','PPB']]:witnesses.append(w)
serialize=lambda d:[[*key,str(co)] for key,co in sorted(d.items())]
finish('replay',{'method':'Euler_master_and_primitive_variation_Berezin_shifted_simplex_and_scalar_Lie','raw_jets':{j:serialize(v) for j,v in raw.items()},'raw_H':serialize(HR),'plane_jets':{j:serialize(v) for j,v in plane.items()},'plane_V':serialize(V),'plane_A':serialize(A),'plane_H':serialize(H),'raw_Gca':enc(CG),'raw_aux_map':enc(Ai),'C3_chart':enc(Q),'source_chart_remainder':'0','free_E_arbitrary_internal_hat_remainder':'0','cumulant_units':list(map(str,units)),'ordinary_phases':list(map(str,ordinary_phases)),'auxiliary_phases':list(map(str,aux_phases)),'I0':str(I0),'J':str(J),'wrong_J':str(Jbad),'Taylor_coefficients':[[str(v) for v in row] for row in taylor],'simplex_moments':list(map(str,[area,mean_y,mean_z])),'convergent_auxiliary_mass_remainder':'0','left':left,'right':right,'left_orientations':orientL,'right_orientations':orientR,'omit_C_jet_left':bad_uc,'unweighted_angle_left':bad_angle,'supported_witnesses':witnesses,'extra_family_or_Nambu_half':False,'source_primitive_read_to_fit_quantum_input':False,'full_QAP_Slavnov_or_physical_scheme_claimed':False},start)
