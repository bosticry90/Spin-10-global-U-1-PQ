"""GTT1 source freeze, restricted reference extraction and honest readiness reuse."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-triangle-field-insertion-v1-2026-10-23');BASE='a2d4057b7dc3dc5a5a626d468b85bec887839630'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));bind={}
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
def add(p,want=None):
 p=p.resolve();h=digest(p)
 if want:assert h==want,str(p)
 bind[str(p)]=h
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V523.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/research_session_preflight.py']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(PK/'export_a10_e5_antighost_vector.py')
for n in ['frozen_a10_e1_fermion/primary.json','frozen_a10_e1_fermion/replay.json','frozen_a10_physical_reconciliation/full_primary.json','frozen_a10_physical_reconciliation/full_replay.json']:add(PK/n)
add(ROOT/'tools/portable_dh_v1/inputs.json.gz','7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb')
deps={
 'canonical_so10_sterile_matter_action':(['ACTION_V1.md','primary.py','validation_receipt.json'],'21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41'),
 'canonical_so10_yukawa_carrier_transport':(['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'4e39b499d32e4203c1d159e5946abfaf9adb05552e9a43c3005c8ee04eee312b'),
 'canonical_so10_matter_breaking_support':(['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'ed1596f57675dd7dfc94c10854c6bdd00184157bf875e4821a28b0bca046243f'),
 'canonical_so10_matter_auxiliary_source_pole':(['primary_tables.json.gz','validation_preparation.json','validation_receipt.json'],'3184454449bab57749e1b5ea0add1ac8ef6a38f4542392ecafbd6a9c88b4ccb4'),
 'canonical_so10_matter_vector_source_pole':(['DERIVATION.md','validation_receipt.json'],'d73871d191316b7582b8d6322367481a36a7ccbfd425fc006ebe149f72592fa2'),
 'canonical_so10_complete_matter_source_breaking':(['qualified_reference_inputs.json.gz','validation_preparation.json','validation_receipt.json'],'c6eee8c9655d4acc68ffdc7f3e729a8541b2a4d1091fa3ef59c58334ffd6eb6a'),
 'canonical_so10_quartic_ghost_source_insertion':(['DERIVATION.md','validation_receipt.json'],'2e8d4600a9f30e73ca720edd70677b16b0fa92d53bc95882c9a6370039ec9ee4'),
 'canonical_so10_yukawa_finite_vertex_ward':(['DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'19c30c658e3662845a57026fbeaa0ce9e4a82d779c42eb274b298bcdeb5c20cb'),
 'canonical_so10_gauge_fermion_insertion':(['RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'c3247d4515b18a2f4df147eaf928bfdb33c2fb4713d11b79a28367e1925455a9'),
 'canonical_so10_matter_source_primitive':(['DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json','validation_receipt.json'],'c0e178079368b7f841ef0c44d2b76035a289a761dc8d427b4a6a4732119638c2')}
for folder,(names,rh) in deps.items():
 for n in names:add(CAL/folder/n,rh if n=='validation_receipt.json' else None)
for folder,names in [('canonical_so10_matter_auxiliary_source_pole',['primary_tables.json.gz']),('canonical_so10_complete_matter_source_breaking',['qualified_reference_inputs.json.gz']),('canonical_so10_yukawa_finite_vertex_ward',['primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_gauge_fermion_insertion',['primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_matter_source_primitive',['primary_tables.json.gz','replay_tables.json.gz'])]:
 old=read(CAL/folder/'validation_preparation.json')['input_sha256']
 for n in names:assert digest(CAL/folder/n)==old[str((CAL/folder/n).resolve())]
mas=packed(CAL/'canonical_so10_matter_auxiliary_source_pole/primary_tables.json.gz');cms=packed(CAL/'canonical_so10_complete_matter_source_breaking/qualified_reference_inputs.json.gz')['reference_fields']
assert mas['raw_ghost_Green']==cms['raw_ghost_Green']
reference={'raw_ghost_Green':mas['raw_ghost_Green'],'raw_auxiliary_plane_map':mas['raw_auxiliary_plane_map'],'old_plane_V':cms['V_plane'],'old_plane_H':cms['H_plane'],'plane_f':cms['plane_f']}
ex={'reference_fields':reference,'old_source_UV_loop_targets_excluded':True,'source_sha256':{str(CAL/folder/n):digest(CAL/folder/n) for folder,n in [('canonical_so10_matter_auxiliary_source_pole','primary_tables.json.gz'),('canonical_so10_complete_matter_source_breaking','qualified_reference_inputs.json.gz')]}}
with (HERE/'qualified_reference_inputs.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(ex,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
add(HERE/'qualified_reference_inputs.json.gz')
source=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/matter-source-primitive-v1-2026-10-23')
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json','postcommit_seal.json']:add(source/n)
add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-fermion-insertion-v1-2026-10-23/postcommit_seal.json'))
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==31442
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:
 with (CONTROL/n).open('xb') as f:f.write((source/n).read_bytes())
ready=read(source/'readiness_result.json');assert ready['native_exit']==0 and ready['step_exits']==[0,0,0,0,0,2] and not ready['fresh_historical_science_requested']
precommand=[sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')]
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:rr=subprocess.run(precommand,cwd=ROOT,stdout=out,stderr=err)
snapshot=read(CONTROL/'prelaunch_preflight.json');assert rr.returncode==0 and snapshot['git_HEAD']==BASE and snapshot['state_sha256']=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8' and snapshot['files_written']==0
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
with (CONTROL/'readiness_reuse.json').open('xb') as f:f.write((json.dumps({'fresh_readiness_command_here':False,'source_was_fresh_in_prior_goal_turn':True,'fresh_byte_preflight_here':True,'fresh_byte_preflight_native_exit':rr.returncode,'scientific_replay_or_acceptance_inferred':False,'source_sha256':{str(source/n):digest(source/n) for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']}},sort_keys=True)+'\n').encode())
add(CONTROL/'readiness_reuse.json')
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'GTT1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GTT1_FROZEN',len(bind),'bindings',flush=True)
