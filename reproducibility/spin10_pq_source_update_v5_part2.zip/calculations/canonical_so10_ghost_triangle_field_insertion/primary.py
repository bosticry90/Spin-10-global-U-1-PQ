"""GTT1 literal action jets, oriented Taylor integrals and ordered color matrices."""
from data import *
from collections import defaultdict,Counter
from itertools import permutations
start=begin('primary');g=s.Symbol('g10')
def expr(v):return s.sympify(v,locals={'g10':g,'xi':WM,'eta_H':WH})
def clean(d):return {key:s.simplify(v) for key,v in d.items() if s.simplify(v)!=0}
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
raw={j:[defaultdict(lambda:s.S.Zero) for _ in range(4)] for j in ['a','B','c']};HR=defaultdict(lambda:s.S.Zero);counts=Counter()
for row in packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']:
 word=row['word'];base=[n.split('__')[0] for n in word]
 if len(word)!=3:continue
 aa=[i for i,n in enumerate(base) if n.startswith(('bar','ub'))];cc=[i for i,n in enumerate(base) if n.startswith('C')];bb=[i for i,n in enumerate(base) if n.startswith('B')]
 if len(aa)!=1 or len(cc)!=1:continue
 a,c=aa[0],cc[0];anti=int(base[a][3:] if base[a].startswith('bar') else base[a][2:]);ghost=int(base[c][1:]);odd=-1 if c<a else 1
 if len(bb)==1:
  b=bb[0];jets=[i for i,n in enumerate(word) if '__' in n];assert len(jets)==1;pos=jets[0];mu=int(word[pos].split('__')[1]);r,nu=map(int,base[b][1:].split('_'));assert mu==nu
  j='a' if pos==a else 'B' if pos==b else 'c';co=s.simplify(odd*([1,-1,-1,-1][mu])*expr(row['coefficient'])/g);assert not co.has(g,WH,WM)
  raw[j][mu][r,anti,ghost]+=co;counts[j]+=1
 else:
  ll=[i for i,n in enumerate(base) if n[0] in ['L','b'] and n[1:].isdigit()]
  if len(ll)!=1 or any('__' in n for n in word):continue
  r=int(base[ll[0]][1:]);co=s.simplify(odd*expr(row['coefficient'])/WM);assert not co.has(g,WH,WM);HR[r,anti,ghost]+=co;counts['H']+=1
for j in raw:
 raw[j]=[clean(v) for v in raw[j]]
 for mu in range(1,4):assert raw[j][mu]==raw[j][0]
HR=clean(HR)
ref=packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields'];Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['C3_plane_to_parent']);Qi=Q.inv();UL=dec(ref['raw_auxiliary_plane_map']);CG=dec(ref['raw_ghost_Green']);zero(Q*CG*UL.inv().T-s.eye(45))
def rowmap(M):return {i:[(j,v) for (ii,j),v in M.todok().items() if ii==i] for i in range(45)}
qr,ur=rowmap(Qi),rowmap(UL)
def transport(d,first):
 out=defaultdict(lambda:s.S.Zero)
 for (r,a,c),co in d.items():
  for b,x in first[r]:
   for u,y in ur[a]:
    for v,z in qr[c]:out[b,u,v]+=co*x*y*z
 return clean(out)
plane={j:transport(raw[j][0],qr) for j in raw};H=transport(HR,ur)
V=clean({k:plane['a'].get(k,0)-plane['B'].get(k,0) for k in set(plane['a'])|set(plane['B'])});A=clean({k:plane['a'].get(k,0)-plane['c'].get(k,0) for k in set(plane['a'])|set(plane['c'])})
for (r,a,c),co in H.items():assert s.simplify(co+H.get((a,r,c),0))==0
# Exact three-even-vertex word signs in both physical endpoint orientations.
words=[[[0,6,5,2],[3,4],[7,1]],[[0,6,3,4],[5,2],[7,1]]];units=[];signs=[]
for ww in words:
 ss=[]
 for perm in permutations(range(3)):
  w=sum((ww[i] for i in perm),[]);ss.append((-1)**sum(w[i]>w[j] for i in range(8) for j in range(i+1,8)))
 signs.append(ss);units.append(-s.Rational(sum(ss),6))
# Momentum conservation at every endpoint, scalar component of vector law.
k,p,q=s.symbols('k p q');routes=[[p+(k-p)-k,-(p+q)+k+(p+q-k),(p-k)+q+(k-p-q)],[-(p+q)+k+(p+q-k),p-k+(k-p),(k-p-q)+q+(p-k)]];assert all(s.expand(z)==0 for row in routes for z in row)
ordinary_phases=[s.simplify(units[0]*(-1)*(-s.I)*(-s.I)*(-s.I)),s.simplify(units[1]*(+1)*(-s.I)*(-s.I)*(+s.I))]
aux_phases=[s.simplify(units[0]*(-1)*(-s.I)*(-s.I)*s.I*(+1)),s.simplify(units[1]*(+1)*(-s.I)*(-s.I)*s.I*(-1))]
# Actual free defect for independent internal hats; no qhat0 assumption
# is made for the INTERNAL ghost. Only the external physical P hat is0.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];gg=[s.kronecker_product(v,pa[2]) for v in g4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
ch=s.prod(gg[:4]);PL=(s.eye(8)+ch)/2;PR=s.eye(8)-PL;tl,tr=s.symbols('tL tR');AA=tl*PL+tr*PR;At=tl*PR+tr*PL
slash=lambda vv,gm:sum((v*M for v,M in zip(vv,gm)),s.zeros(8));bk=slash(s.symbols('bk0:4'),gg[:4]);br=slash(s.symbols('br0:4'),gg[:4]);hk=slash(s.symbols('hk0:2'),gg[4:]);hr=slash(s.symbols('hr0:2'),gg[4:]);O=s.zeros(8)
Nk=bk.row_join(hk).col_join(hk.row_join(bk));Nr=br.row_join(hr).col_join(hr.row_join(br));GA=AA.row_join(O).col_join(O.row_join(O));GAt=At.row_join(O).col_join(O.row_join(O));B=((bk-br)*AA).row_join(O).col_join(O.row_join(O))
EE=(s.I*Nk*GA-s.I*GAt*Nr-s.I*B).applyfunc(s.expand);expected=O.row_join(-s.I*At*hr).col_join((s.I*hk*AA).row_join(O));zero(EE-expected)
zero((s.I*EE)[:8,8:]-At*hr);zero((s.I*EE)[8:,:8]+hk*AA)
eps,h=s.symbols('epsilon h');D=4-2*eps;rg0=h*s.gamma(1+eps)/4;rg1=h*s.gamma(1+eps)/24
finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0));I0,J=finite(rg0),finite(rg1);Jbad=finite(h*(D+2)*s.gamma(1+eps)/(24*D))
# Literal derivative of rational propagators, prior to angular integration.
K,k0=s.symbols('K k0');den=K*(K-2*k0*p+p*p)*(K-2*k0*(p+q)+(p+q)**2)
ratios=[(k0-p-q)/den,(k0-p)/den]
def moment(z,joint):
 poly=s.Poly(s.expand(s.cancel(z*K**4)),K,k0);answer=0
 for mon,co in poly.terms():
  assert mon in [(1,0),(0,2)];answer+=co*(I0 if mon==(1,0) else joint)
 return s.simplify(answer)
taylor=[[moment(s.diff(z,ext).subs({p:0,q:0}),J) for ext in [p,q]] for z in ratios]
bad_taylor=[[moment(s.diff(z,ext).subs({p:0,q:0}),Jbad) for ext in [p,q]] for z in ratios]
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-v.T for v in T];HF=dec(Y['H_new']);W=WH*HF*HF.T+WM*(s.eye(45)-HF*HF.T)
def contract(tab,weight,gen,reverse=False):
 out=[s.zeros(16) for _ in range(45)];wr=defaultdict(list)
 for (b,r),co in s.SparseMatrix(weight).todok().items():wr[r].append((b,co))
 for (r,a,c),co in tab.items():
  for b,v in wr[r]:out[c]+=co*v*(gen[a]*gen[b] if reverse else gen[b]*gen[a])
 return [M.applyfunc(s.expand) for M in out]
def calculate(gen,joint,tt,aa):
 cv=contract(V,W,gen);cvr=contract(V,W,gen,True);ca=contract(aa,I0*s.eye(45)+joint*(W-s.eye(45)),gen);car=contract(aa,I0*s.eye(45)+joint*(W-s.eye(45)),gen,True);ch=contract(H,s.eye(45),gen);chr=contract(H,s.eye(45),gen,True)
 oriented={'3':[],'2':[]}
 for i,(cc,dd,hh) in enumerate([(cv,ca,ch),(cvr,car,chr)]):
  oriented['3'].append({'p':[enc(ordinary_phases[i]*tt[i][0]*v) for v in cc],'q':[enc(ordinary_phases[i]*(tt[i][1]*v+(1 if i==0 else -1)*a)) for v,a in zip(cc,dd)]})
  oriented['2'].append({'p':[enc(aux_phases[i]*WM*tt[i][0]*v) for v in hh],'q':[enc(aux_phases[i]*WM*tt[i][1]*v) for v in hh]})
 total={degree:{jet:[enc(dec(oriented[degree][0][jet][c])+dec(oriented[degree][1][jet][c])) for c in range(45)] for jet in ['p','q']} for degree in ['2','3']}
 return total,oriented
left,orientL=calculate(T,J,taylor,A);right,orientR=calculate(U,J,taylor,A);bad_uc,_=calculate(T,J,taylor,plane['a']);bad_angle,_=calculate(T,Jbad,bad_taylor,A)
ib=packed(CAL/'canonical_so10_matter_breaking_support/primary_tables.json.gz');witnesses=[]
for w in ib['targets']['cPP']['candidate']:
 oo=sorted(ib['vertices'][n]['origin'] for n in json.loads(w)[0])
 if oo in [['E_C','GF','PPB'],['E_S','GF','PPB']]:witnesses.append(w)
rows=lambda d:[[*key,str(co)] for key,co in sorted(d.items())]
finish('primary',{'method':'literal_all_jet_GF_density_direct_endpoint_words_rational_Taylor_and_ordered_colors','raw_jets':{j:rows(raw[j][0]) for j in raw},'raw_H':rows(HR),'literal_counts':dict(counts),'plane_jets':{j:rows(v) for j,v in plane.items()},'plane_V':rows(V),'plane_A':rows(A),'plane_H':rows(H),'raw_Gca':enc(CG),'raw_aux_map':enc(UL),'C3_chart':enc(Q),'source_chart_remainder':'0','free_E_arbitrary_internal_hat_remainder':'0','word_signs':signs,'cumulant_units':list(map(str,units)),'ordinary_phases':list(map(str,ordinary_phases)),'auxiliary_phases':list(map(str,aux_phases)),'I0':str(I0),'J':str(J),'wrong_J':str(Jbad),'Taylor_coefficients':[[str(z) for z in row] for row in taylor],'left':left,'right':right,'left_orientations':orientL,'right_orientations':orientR,'omit_C_jet_left':bad_uc,'unweighted_angle_left':bad_angle,'supported_witnesses':witnesses,'extra_family_or_Nambu_half':False,'source_primitive_read_to_fit_quantum_input':False,'full_QAP_Slavnov_or_physical_scheme_claimed':False},start)
