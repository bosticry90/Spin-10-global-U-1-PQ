# GTT1: complete cPP input and a measured lower-order cancellation

Qualified within the frozen mass-independent, physical-external-hats0,
one-loop Euclidean one-jet domain. All eight GF ghost-triangle supports
are calculated. The full twelve-support cPP catalogue is then assembled
exactly once with the separately qualified gauge and Yukawa edge inputs.
Receipt SHA256:
`610e974608e4d4f711708a7018a0981a857180cdc852a36807cdb7fa5be42d4a`.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

## Quantum coefficients and selected source comparison

The six ordinary g10^3 and two auxiliary g10^2 supports retain both endpoint
orientations. With external psi momentum p, barpsi momentum-(p+q) and ghost
q, the left derivative coefficients are Lp and Lq. Their conjugates obey

`Rp=Lp^T`, `Rq=(Lp-Lq)^T`.

This includes the required reversal p->-p-q. A coefficientwise minus
transpose would be wrong when Lp is nonzero.

| Triangle component | Left p | Left q | Right p | Right q |
| --- | ---: | ---: | ---: | ---: |
|Auxiliary g10^2|0|592|0|592|
|Ordinary g10^3|512|720|512|720|

Counts are nonzero exact matrix positions, not independent experiments.
All45 ghost directions, both chiralities and zero complements are retained.
Common loop factor1/(16pi^2), gauge families I3 without an extra3 or half.

The complete g10^2 kinetic-channel comparison succeeds independently:

`Delta_aux,cPP + (b_Sigma C_src,MSP1)_kinetic = 0`

modulo the explicitly retained boundary current. The quantum triangle
workers deny access to the source primitive's tables after input-byte
authentication. Only the subsequent verifier performs the comparison.
Every left/right p/q remainder is zero. No coefficient was assigned from
the desired cancellation, and no new finite baseline was selected.

In particular, the source coefficient X^[3]=i x already fixed by MSP1
contributes +g10^2 barslash(q)x. Its Euler density differs from the
derivative-ghost representative by
`partial_mu[i c barpsi gamma_mu x psi]`, which remains recorded.
The elementary qK=0 rule is unchanged; this uses b_Sigma's source/Euler
operation, as distinguished in MSP1.

## Why the external ghost derivative matters

The full actual GF density has3,480 antighost-jet,720 vector-jet and1,440
external-ghost-jet positions, plus276 auxiliary positions. The earlier
source-pole calculation correctly excluded the last derivative class in
its different derivative-free target. It cannot be omitted here.
The normalized plane tensors have720/880/1,472 nonzero positions for
UA/UB/UC. Momentum conservation leaves

`V=UA-UB`, `A=UA-UC`.

The direct literal density and independent E1 Euler/master reconstruction
agree exactly; their total-derivative difference is zero in this packet.
All three jets and the auxiliary H tensor reproduce their independent
effective-vertex references and actual C3/dual-map normalizations.

Let CV_c=sum W_br V[r,a,c]TbTa, with reversed product CVrev, and
CA_c=sum ((5I+W)/12)_br A[r,a,c]TbTa, with CArev. The ordinary result is

`Lp=-i(CV+CVrev)/6`,
`Lq=-i(CV/3-CVrev/6-CA+CArev)`.

For CH_c=sum H[r,a,c]TrTa, the auxiliary result is

`Lp_aux=i xi(CH+CHrev)/6`,
`Lq_aux=i xi(CH/3-CHrev/6)`.

The actual H antisymmetry makes the auxiliary p terms cancel collectively.
Neither oriented contribution is zero. The complete formulas derive from
actual mixed-fermion, ghost and ordered BB/BL propagators before comparison.

## Independent methods and controls

Primary uses all-mu literal GF extraction, actual free PS blocks for
independent internal hats, three-even-vertex word signs, rational Taylor
derivatives, joint Gaussian moments and ordered matrix products. Replay
uses E1 Euler/master reconstruction and auxiliary primitive variation,
exact Berezin Gaussian integrals in both orientations, shifted Schwinger
simplex moments and scalar-Lie/symmetric-product color reduction.

Both derive I0=-1/2 and J=-1/12 in16pi^2 units. The shifted vector kernels
give p/6+q/3 and p/6-q/6. All368,640 compared triangle/control positions and
the zero complement agree. Analytic reality and all12 internal H color
covariance tests have zero remainders. This is not a full local-background
completion of the derivative density.

Deleting UC changes715 ordinary q positions. Omitting momentum reversal
changes512. An unweighted angular factor changes512 p and720 q positions.
Dropping either orientation changes720 p/q positions in the ordinary class
and592 in each auxiliary oriented contribution. The completed auxiliary
sum is correctly insensitive to the external-C derivative, momentum-
reversal shortcut and unweighted-angle control: its antisymmetry removes
those effects. That selected cancellation alone therefore cannot certify
the global derivative or conjugation conventions.

## Exact-once assembly and remaining question

The comparison packet stores the complete factorized cPP input:

| Formal component | Left p | Left q | Right p | Right q |
| --- | ---: | ---: | ---: | ---: |
|g10^2|0|592|0|592|
|g10^3, including GFI1|512|720|512|720|
|g10 Y10daggerY10|0|720|0|720|
|g10 Y126daggerY126|0|720|0|720|

The Yukawa insertions are authenticated YVF1 inputs with the separately
qualified actual-action conversion; general complex symmetric family
matrices and their right factors remain symbolic. No numerical flavor
point or average family trace is used. All184,320 assembled color positions
agree between input routes. The twelve supports partition into8 new GF
triangles,2 qualified GFI1 gauge edges and2 qualified YVF1 Yukawa edges,
with no duplicate or omitted support.

The complete g10^3 field/source counterterm matching is still unresolved.
Its nonzero p component constrains a possible fermion kinetic correction;
its q component must also fit the actual gauge-vertex/source correction.
Derive those coupled admissible images before solving for a correction.
Do not interpret this input assembly or the g10^2 cancellation as a full
Slavnov/QAP/measure theorem. cBPP/cxPP and positive-mass-dimension sectors,
physical chiral reference and massive matching remain separate.

Primary159.0062266s, replay96.5465882s, gate288.7146497s after imports,
native0.80/49/145 observed samples; largest sampled private bytes
73,887,744/188,694,528/120,471,552, not continuous peaks.600s/8GiB sampled/
350MiB launch-floor/16MiB bounds respected. Eight source copies,75 initial
84 validation bindings; no frozen worker/gate failure. Package remains
under16MiB. Complete comparison tables SHA256:
`3ef4563f6ff94f11f86db15bdd25484edba22dfe9757a72ac0a212f880c0f05f`.

Fresh byte preflight ran here. MSP1's earlier E4 command is authenticated
prior-turn evidence, not a fresh readiness command or old-science replay
in this turn. Historical custody remains exit2/seven NOTPASS. External
controls: `C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-triangle-field-insertion-v1-2026-10-23`.

Both adverse scalar benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks and
all old evidence remain. No state promotion, physical scheme, publication
or remote action. Shared action/data/software/AI author limits independent
scientific validation. Full E5/A5 and physical unification remain unqualified.
