# GTT1: fixed two-orientation field insertion

External psi momentum p, barpsi momentum-(p+q), ghost q; hats of p,q zero.
Orientation1 has E at psi, internal fermion k, ghost k-p, vector l=k-p-q.
At GF the antighost momentum is p-k and vector momentum k-p-q. Thus

 i g[UA(p-k)+UB(k-p-q)+UC q]
 =-i g[V(k-p)+(UB-UC)q], V=UA-UB.

The actual physical E_SP block is -g hatGamma.k A, the mixed propagator
is -i hatGamma.k/k2, and the ordinary gauge action vertex is -ig barGamma A.
Their product is +g2. The GF derivative supplies the remaining -i g.
After contracting the BB numerator, its UV-homogeneous vector expression is

 W V gamma.l + A gamma.q + A(W-I)gamma.l(l.q)/l2, A=UA-UC.

Orientation2 has E at barpsi, fermion k, ghost k-p-q, vector l=k-p. The
GF derivative is +i g[V(k-p)-A q]. E_PS=+g Atilde hatGamma.k makes the
fermion/gauge/E product -g2, again giving overall-i g3. Its vector
expression is W V gamma.l-A gamma.q-A(W-I)gamma.l(l.q)/l2. Both open
three-even-vertex Berezin cumulants are checked separately, not assumed.

The two linear Taylor integrals in16pi2 units are

 int hatk2*(k-p-q)_mu/[k2(k-p)2(k-p-q)2] -> p_mu/6+q_mu/3,
 int hatk2*(k-p)_mu/[k2(k-p-q)2(k-p)2] -> p_mu/6-q_mu/6.

Use I0=FP int hatk2/(k2+m2)^3=-1/2 and
J_mu,nu=FP int hatk2 kbar_mu kbar_nu/(k2+m2)^4=-delta/12.
Denominator Taylor gives2J(2p+q), numerator shifts give-I0(p+q) or-I0p.
The A terms give-I/2-(W-I)/12=-(5I+W)/12 in orientation1 and its negative
in orientation2. A direct shifted Schwinger simplex independently tests
these coefficients. Positive auxiliary mass terms introduced by replacing
the longitudinal denominator are UV-convergent with explicit h and vanish;
they are not omitted power-sensitive physical terms. External nonexceptional
momenta define the amplitude; the mass is only local UV rearrangement.

Define Q_A=(5I+W)/12, CV_c=sum W_br V[r,a,c] TbTa and
CA_c=sum Q_A,br A[r,a,c] TbTa. Reverse the ordered products for CVrev/CArev.
The complete ordinary coefficients, before model evaluation, are

 Lp=-i(CV+CVrev)/6,
 Lq=-i(CV/3-CVrev/6-CA+CArev).

For auxiliary H, Euclidean vertex+i xi H and G_BL at the fermion first
endpoint give +l/l2 in orientation1 and-l/l2 in orientation2. Both final
phases are+i g2 xi. With CH_c=sum H[r,a,c]TrTa,

 Lp_aux=+i xi(CH+CHrev)/6,
 Lq_aux=+i xi(CH/3-CHrev/6).

The actual antisymmetry H_ra,c=-H_ar,c is verified before using it. It
annuls Lp_aux collectively, not either oriented contribution. Replay
splits every ordered product into its anticommutator and i f*T/2 parts.
No adjoint-only simplification is assumed for the ordinary field tensor.

Using actual U=-T.T gives Rp=Lp.T and Rq=(Lp-Lq).T, equivalently
R(p,q)=-L(-p-q,q).T. Momentum reversal is required before the transpose.
For real normalized vertices this also yields Lp.H=-Lp and Lq.H=Lq-Lp;
these are analytic finite-kernel checks, not a physical phase theorem.

Selected g2 source comparison: MSP1 has Csrc=-g2 K c X^[3]P/(16pi2),
X=i x^e T_e. Its massless kinetic Euler companion, after retaining the
boundary current and polarizing the two Nambu placements, is +g2
barslash(q)x/(16pi2). In ordinary Dirac notation the negative source flow
is delta psi=-i c x psi, delta barpsi=+i c barpsi x, whose kinetic variation
is -i(partial c)barpsi gamma x psi. Its Euler representative differs by
the retained divergence partial_mu[i c barpsi gamma_mu x psi]; Fourier
partial->+i q gives +qslash x. Derive this with graded Euler calculus
before comparing x=-i X to the independent auxiliary Lq. No target fit.
