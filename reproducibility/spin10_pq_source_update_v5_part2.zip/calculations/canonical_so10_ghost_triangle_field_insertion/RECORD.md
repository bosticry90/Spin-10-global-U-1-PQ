# GTT1: complete GF ghost triangles in the finite cPP breaking

Previous goal turn PROGRESS: verified source primitive MSP1 and paired
gauge-edge field insertion GFI1. Current complete objective remains active
and incomplete. Basea2d4057b7dc3dc5a5a626d468b85bec887839630/main31442.

Question: what are the complete eight GF ghost-triangle contributions to
the local finite cPP breaking, and does the independently measured g2
component cancel with MSP1's fixed kinetic Euler companion? Six ordinary
g3 supports and two auxiliary g2 supports complete this required family.
They must be calculated before comparison with a counterterm. Success,
an exact nonzero matching remainder or underdefinition are valid outcomes.
Do not assign a loop coefficient from the desired cancellation.

Reuse IBS1's complete typed candidate catalogue, actual SMA1 action/free
PS/source conventions, QSI1's normalized action insertion i*g E_current,
actual GF33092 density, E1 Euler/master maps, YCT generators/H frame and
actual physical C3/dual-antighost charts. Authenticate CMS1's extracted
old V/H/f fields for cross-checks only, excluding old source-UV answers.
Bind MSP1's fixed primitive for the later verifier; workers deny its tables.
Current state113/34of39, current AGENTS/CHARTER/local/solo/epistemic policy
and V523 remain immutable inputs. No flavor point or physical scheme.

Scope: one-loop, mass-independent Euclidean nonexceptional amplitudes,
physical external p,q with hats0; internal momenta retain hats and actual
PS mixing. Target cPP has dimension5/ghost1 in SMA1's ghost-dimension1
convention and one ordinary external jet. Retain p and q coefficients
separately; right-source conjugation includes reversal p->-p-q, not a
coefficientwise minus transpose. I3 family identity, no extra3/half.

The ordinary source-pole calculation MVS1 legitimately excluded external
C derivatives in its derivative-free UV target. This finite target must
include UA,UB,UC for antighost/vector/external-ghost derivatives. All
three are reconstructed from the actual action. Momentum conservation
leaves V=UA-UB and A=UA-UC. Verify raw densities exactly or retain an
explicit total-derivative current if the Euler form changes all three by
the same tensor. Never omit UC by reusing a UV-only vertex table.

Primary: literal all-mu GF extraction and source/Clifford block sewing;
three-even-vertex word sign at each endpoint orientation; actual Fourier
routing, mixed inverse signs, direct Taylor derivative and joint Gaussian
moments. Direct ordered TbTa/TaTb model contractions after chart transport.
Replay: independent E1 Euler/master density reconstruction (all three
jets), auxiliary primitive variation, exact Grassmann Gaussian in both
orientations; shifted Schwinger/Feynman simplex integrals and scalar-Lie/
symmetric-product color reduction. No peer output or primitive-target read.

Acceptance: all eight typed supports exactly once, each original jet and
auxiliary term retained; independent raw/effective vertex and complete p/q
matrix agreement including zeros for all45 ghosts, both chiralities and
g2/g3 orders. Check covariance, analytic reality and momentum-reversal
transpose. Controls omit UC, a mixed orientation, momentum reversal,
matrix order, h sign or joint angular correlation. Report true sensitivity.
Compare the completed g2 quantum coefficient with independently derived
massless kinetic Euler image of the fixed MSP1 source term. A nonzero
remainder is preserved and classified, not fitted away or called anomaly.
Ordinary g3 field/source matching is not asserted from this one test.

Freeze eight sources/copies plus input hashes before sequential workers.
Each600s after imports,8GiB sampled private cap,350MiB launch floor,16MiB
package. Compile first; stop on failure/exhaustion and preserve full
sources/captures before any versioned correction. Current preflight is
fresh; earlier MSP1 E4 command is authenticated prior-turn evidence, NOT
called a fresh command or fresh historical science in this turn. Fresh
prelaunch byte snapshot plus every actual input binding/resource capture
protects this increment; no unnecessary expensive old scientific replay.
Historical custody remains exit2/seven NOTPASS.

After the independent triangle comparison, assemble the twelve-support
cPP component exactly once with qualified GFI1 and YVF1 inputs. Keep g2,
g3 and factorized gY10dagY10/gY126dagY126 separate. This is an assembly of
existing measured inputs, not a fit or a physical scheme. Its full g3
field/source counterterm matching is not claimed here. cBPP/cxPP, full Slavnov/QAP/products/measure/phase, physical
chiral reference and massive C1 remain unqualified. E5/A5 and authority
unchanged. Both adverse scalar benchmarks,quartetFAIL,flavor pause,HB1/C5
blocks and all old evidence persist. No agents,branch/worktree,reset,
publication,outreach or push. Shared inputs/software/AI authorship limit
independence. Actual finite operator/integral identities determine this
bounded result; no external theorem supplies the model's unknown answer.
