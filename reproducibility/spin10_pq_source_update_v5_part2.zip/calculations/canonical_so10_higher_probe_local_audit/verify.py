from pathlib import Path
from hashlib import sha256
import gzip,json,time,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']]
for k in a:
 if k!='role':assert a[k]==b[k],k
assert len(a['types'])==11
source_zero=not any(a[k] for k in ['source_higher_kernel','source_AB1_G1','source_G1_BA1']);assert a['source_drop_LL_higher_nonzero_positions']>0
# Late old-kernel comparison. Same canonical action name order; compare
# polynomial coefficients semantically, not copied hash/serialization fields.
cg=O.parent/'canonical_so10_probe_chiral_ghost_kernel';old=load(cg/'primary_v2_tables.json.gz');probe={i for i,n in enumerate(old['names']) if n in ['mw_u0','mw_u1','mw_rho0','mw_rho1']}
def flatten(rows,cut=False):
 out={}
 for i,j,p in rows:
  for gp,w,ci in p['monomials']:
   if cut and sum(n in probe for n,jet in w)>2:continue
   out[i,j,gp,tuple((n,tuple(jet)) for n,jet in w)]=p['coefficients'][ci]
 return out
assert flatten(a['source_kernel_without_any_probe_degree_truncation'],True)==flatten(old['H_effective'])
ep=read(O.parent/'canonical_so10_even_probe_vertices/validation_receipt.json');assert ep['two_full_density_vs_Euler_routes_agree'] and ep['ghost_finite_transfer_g_word_positions']==[0,0] and ep['other_scalar_finite_transfer_positions']==[0,0] and all(ep['compact_bosonic_factorization_matches_all_colors'])
hp=read(O.parent/'canonical_so10_first_probe_local_module/endpoint_validation_receipt.json');lfm=read(O.parent/'canonical_so10_first_probe_local_module/validation_receipt.json');program=load(O.parent/'canonical_so10_first_probe_local_module/primary_tables.json.gz');assert lfm['complete_projected_unshifted_first_probe_bare_local_cancellation'] and hp['all_tested_principal_endings_affine_and_higher_intrinsic_scalar_coefficients_zero'];assert not program['full_Q_assumed_nilpotent'] and all(row['candidate_BV_overlap_pairs']==0 for row in program['actual_G_QG_vs_candidate_BV_ports']);assert all(t['fields'].count('u')==1 and t['fields'].count('rho')==0 for t in program['concrete_functional_program'])
pv=read(O.parent/'canonical_so10_probe_vector_response/loop_validation_receipt_v2.json');rv=read(O.parent/'canonical_so10_rho_probe_vector_response/validation_receipt.json');assert pv['all_higher_even_probe_marginal_vector_local_coefficients_zero'] and rv['positive_even_probe_rho_vector_local_quantum_coefficients_zero']
jetzero=all(not a[k]['entries'] for k in ['generic_jet_null_U_G_U','generic_jet_inverse_response_remainder','generic_jet_current_inverse_remainder','generic_free_inverse_left','generic_free_inverse_right']) and all(not m['entries'] for m in a['actual_current_polarization']+a['mixed_color_projector_products'])
coverage=[]
for ty in a['types']:
 f=ty['fields'];nr=f.count('rho')
 if'KP'in f:label='source_Schur_full_polynomial';ok=source_zero
 elif ty['jet_degree']:label='full_transfer_jet_affinity';ok=jetzero
 elif ty['mass_degree']:label='HP_EDS_intrinsic_zero_jet';ok=hp['all_tested_principal_endings_affine_and_higher_intrinsic_scalar_coefficients_zero']
 elif'B'in f:label='RPV' if nr else'PVR';ok=rv['positive_even_probe_rho_vector_local_quantum_coefficients_zero'] if nr else pv['all_higher_even_probe_marginal_vector_local_coefficients_zero']
 elif'x'in f:label='UCS_RXS_linear_scalar_sewing_of_affine_ending';ok=jetzero and a['marginal_scalar_probe_terms_absent']
 else:label='UNCOVERED';ok=False
 coverage.append({'type':ty,'evidence':label,'covered_with_declared_graph_reference_premises':bool(ok)})
missing=[row for row in coverage if not row['covered_with_declared_graph_reference_premises']];extension=not missing and source_zero and jetzero and a['marginal_scalar_probe_terms_absent']
out={'schema':'HPA1_VALIDATION_RECEIPT','elapsed_after_imports':time.perf_counter()-tick,'distinct_full_vector_and_outer_product_jet_methods_agree':True,'complete_untruncated_left_vs_right_Grassmann_Schur_methods_agree':True,'type_enumeration_count':len(a['types']),'higher_type_coverage':coverage,'uncovered_types':missing,'all_higher_source_kernel_coefficients_zero':source_zero,'late_old_CGK_degree2_limit_matches':True,'marginal_scalar_probe_terms_absent':a['marginal_scalar_probe_terms_absent'],'finite_transfer_jet_affinity':jetzero,'source_drop_LL_higher_sensitive_positions':a['source_drop_LL_higher_nonzero_positions'],'one_fixed_candidate_first_variation_affine_by_actual_ports_not_Q_nilpotence':True,'projected_formal_probe_dependent_bare_local_cancellation_extended_to_higher_powers':extension,'unprobed_hatted_defect_claimed_zero':False,'new_integrals_or_finite_multiple_insertion_QAP_measure_or_physical_limit':False,'Hbasic_C5_or_scientific_authority_promoted':False,'primary_packed_sha256':H(O/'primary_tables.json.gz'),'replay_packed_sha256':H(O/'replay_tables.json.gz')}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
