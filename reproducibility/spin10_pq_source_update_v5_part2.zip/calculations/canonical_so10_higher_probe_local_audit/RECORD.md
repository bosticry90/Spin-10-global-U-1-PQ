# HPA1: higher-probe local carrier sufficiency audit

Freeze2026-10-25 before computation. Base6374392a/main; RPV1 has completed
and may be used only through its actual verified receipt. Question: do the
remaining jet and source algebraic dependencies support extension of the
projected first-probe bare-local result to higher formal probe powers?
This is a sufficiency TEST, not an assumption that every required carrier
is covered. Preserve uncovered patterns and failed premises explicitly.

Keep the exact LFM1 projected domain: original unshifted SMA, external
physical P and KP; other external anchors/BV sources,sterile/hatted fields,
independent backgroundA/partners0. Full internal PS/SP and BL/LB retained.
Mass-independent nonexceptional Euclidean bare local reference and its
qualified dimensional continuation. Parameters remain polynomial; no new
finite normalization,physical vacuum or benchmark. Full Q remains curved.

1. Enumerate the complete higher-probe breaking TYPES with dimension5,
ghost1,odd parity and two P/KP spinor ports. Even u has dimension0,so classify
skeletons times arbitrary commuting u powers, rather than truncating them
because source degree is unbounded. Rho has dimension1/ghost1/odd parity:
at most2 rho labels fit; two rhos must be distinct. Primary uses multisets,
replay a dimension/ghost generating polynomial. One-rho types require at
least one extra u to be higher order; zero-rho types at least two u. Retain
the two-rho KP-P possibility, not only the previous ten first-probe types.
Do not interpret type counts as invariant-tensor ranks or C5 completion.

2. Prove the jet kernel identities with INDEPENDENT adjoining momenta.
Authenticate actual EPV finite-transfer scalar/ghost quadratic zeros and
AC=AU=0; actual rho A=0. Match the HP current polarization H=V W/2 using
all92 actual rows. For each color projector, use the measured full kernel
U(k,l)=[[-2 k l,w k],[-w l,w^2/2]] and actual G0(k). Primary performs
literal vector/auxiliary block multiplication; replay uses the outer-product
factorization with formal momentum inner products. Check U(k,l)G0(l)U(l,m)=0,
-G0(k)U(k,l)G0(l)=Gr(k,l),Jprobe(k)Gr(k,l)=0, and both inverse orders.
No k=l shortcut; full k^2 is its bosonic norm, not a barred replacement.
The algebra uses only vector inner products, no dimension trace. Actual
P_r P_s=0 for r!=s handles mixed-color paths. This proves affinity of the
ghost ending and repeated bosonic insertions at finite transfers, including
derivatives of u/rho/C. It is not a new regulated trace/product domain.

Use the saturated one-loop support principle: connected1PI one-loop quantum
graphs have every vertex of internal degree2 (E=V and minimum degree2).
Scan actual full physical G/QG densities for source-free marginal scalar
terms and all marginal quantum-port patterns. If new scalar marginal probe
vertices occur, do NOT infer scalar completeness from endpoint affinity.
If absent, new probe vertices in the ordinary one-jet/scalar target reduce
to quadratic bosonic insertions and measured ghost currents. Higher valence
vertices cannot fit those1PI cycles. Ghost/scalar quadratic symbols vanish
by the FULL EPV result, not a constant-u sample. Reuse the EUL/RXS/UCS raw
PS/SP graph/sewing premises; no new integrated moment is assigned a value.
Scalar leading local coefficients have zero external jet budget, so the
qualified universal scalar sewing of the affine ending is linear. Intrinsic
dimension-one zero-jet endings remain separately covered by EDS/HP, not
silently transferred to massive or finite amplitudes.

3. Recompute the complete constant-field Schur ghost kernel WITHOUT CGK's
historical degree2 truncation. Extract only actual Haa,Hab,Hba,S_marginal
and Gu from authenticated action-derived CGK inputs/tables. With affine
action and inverse, Haa-Hab*Gu*Hba has maximal probe degree3. Use canonical
Grassmann products for independent odd C/rho labels. Primary left-associates
the full product; replay right-associates. Test all degree2 AND3 coefficients,
Hab1*Gu1 and Gu1*Hba1 before quantum sewing. No expected Heff or source tensor
is read by workers. Late verifier may compare degree<=2 with old Heff.
If all higher kernel coefficients vanish, CGK's linear source sewing gives
the full higher bare local KP-P zero, including rho0*rho1. No finite contact
or arbitrary multiple-insertion product follows. Drop LL as a sensitive
control, and preserve all nonzero lower coefficients and controls.

4. Only AFTER these calculations compare the type envelope with completed
RPV/PVR/HP/CGK and LFM evidence. The existing candidate is affine in u and
its actual G/QG BV port overlap is0, so its first full variation has no
higher probe image; verify those actual program/port facts instead of
assuming full Q nilpotence. An extension disposition requires ALL types,
all input/graph premises and new identities. Otherwise report the exact
uncovered dependency, not an anomaly or completed higher module.

Controls: wrong adjoining current momentum,omitted auxiliary current,
omitted LL in Schur inverse, and at least one jet transfer removed. Record
sensitive/insensitive outcomes, not a requested cancellation. Freeze sources
and inputs before sequential P/R/V each300s after imports,8GiB sampled private,
350MiB floor,whole HPA packet16MiB. RPV retains its own12MiB/180s caps.
All failures/captures immutable; no silent cap changes or evidence truncation.

Authority ceiling: projected FORMAL probe-dependent bare-local first-variation
statement only, conditional on the inherited graph/reference premises. No
claim that the unprobed hatted defect disappears, full chiral restoration,
finite products,measure/phase,QAP/physical limit or E5/A5. No H-basic/HB1/C5,
flavor,foundational/benchmark/scheme adoption,push/publication/outreach,agents
or branch/worktree. State113/34of39,custody2/sevenNOTPASS unchanged. Shared
action,inputs,software,reference and AI author are not independent scientists.
