from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
w=s.Symbol('w',real=True);k=s.Matrix(s.symbols('k0:4'));l=s.Matrix(s.symbols('l0:4'));K2=(k.T*k)[0];I=s.eye(4);G=s.Matrix.vstack(s.Matrix.hstack(I/K2+(w-1)*k*k.T/K2**2,-k/K2),s.Matrix.hstack(k.T/K2,s.zeros(1)));K=s.Matrix.vstack(s.Matrix.hstack(K2*I-k*k.T,k),s.Matrix.hstack(-k.T,s.Matrix([[w]])));a=s.Matrix.vstack(k,s.Matrix([[w/2]]));b=s.Matrix.hstack(-2*k.T,s.Matrix([[w]]));clean=lambda M:s.SparseMatrix(M).applyfunc(s.cancel)
checks={'G_a':clean(G*a-s.Matrix.vstack(w*k/(2*K2),s.ones(1))),'b_G':clean(b*G-s.Matrix.hstack(-w*k.T/K2,s.Matrix([[2]]))),'K_G':clean(K*G-s.eye(5)),'G_K':clean(G*K-s.eye(5)),'b_G_a':clean(b*G*a)};assert all(not M.todok() for M in checks.values())
U=lambda x,y:s.Matrix.vstack(s.Matrix.hstack(-2*x*y.T,w*x),s.Matrix.hstack(-w*y.T,s.Matrix([[w*w/2]])));erased=clean(U(k,l)-U(k,k));assert erased.todok()
d=load(O/'primary_inputs.json.gz')['endpoint'];g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});curr=[dec(x['J']) for x in d['rho']]+[dec(x['Ju']) for row in d['mixed'] for x in row];gr=[dec(x['Gr']) for x in d['probe_quadratics']];count=0
for J in curr:
 bad=s.SparseMatrix(J)
 for(i,j),v in list(bad.todok().items()):
  if j>=45:bad[i,j]=0
 for G1 in gr:count+=len((bad*G1).applyfunc(s.expand).todok())
hp=read(O.parent/'canonical_so10_first_probe_local_module/endpoint_validation_receipt.json');ep=read(O.parent/'canonical_so10_even_probe_vertices/validation_receipt.json');assert count==hp['controls']['omit_auxiliary_current_null_positions']==1290 and ep['erasing_u_transfer_changes_quadratic_positions']==[240,660]
v=read(O/'validation_receipt_v2.json');assert v['projected_formal_probe_dependent_bare_local_cancellation_extended_to_higher_powers'] and not v['unprobed_hatted_defect_claimed_zero'] and not v['Hbasic_C5_or_scientific_authority_promoted'];assert read(O/'replay_capture.json')['execution_state']=='FAILED' and read(O/'controller_failure.json')['execution_state']=='FAILED'
out={'schema':'HPA1_APPLICABILITY_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'outer_factors_and_both_free_inverse_orders_exact_rational_zero':True,'proof_uses_only_vector_norm_not_D_trace':True,'fresh_omit_auxiliary_all92_current_positions':count,'generic_erased_transfer_nonzero_matrix_positions':len(erased.todok()),'actual_EPV_erased_transfer_positions_reauthenticated_not_reintegrated':[240,660],'failed_V1_not_relabelled':True,'all11_declared_types_covered_with_inherited_reference_graph_premises':True,'finite_products_QAP_measure_phase_or_authority_promoted':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
