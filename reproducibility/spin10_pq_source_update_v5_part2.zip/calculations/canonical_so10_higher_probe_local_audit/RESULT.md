# The fixed correction extends to the higher projected local probe sector

PROGRESS,2026-10-25,base6374392a/main. The completed HPA2 audit and separate
applicability review support a coefficientwise formal extension of the
projected first-probe bare-local cancellation to higher probe powers.
All eleven declared higher-probe carrier types are covered under the stated
inherited graph/regulator premises. One fixed candidate suffices in this
projected local sector; no new coefficient or finite baseline was fitted.

This is a relative PROBE-DEPENDENT one-loop statement. It does not remove
the unprobed nonzero hatted insertion,prove full chiral restoration or
construct the finite renormalized products,measure,QAP or physical limits.
State113/scientific authority34of39,E5/A5 and custody2/sevenNOTPASS unchanged.

## Meaning of the result

Let B_local(u,rho) denote the actual projected bare-local fermionic
first-variation coefficient in the inherited reference. Let C be the
single already-qualified LFM correction. The supported statement is

    [B_local+Q_full C]_(positive formal probe degree)=0

in the original unshifted SMA projection with external physicalP andKP,
other external anchors/BV sources,sterile/hatted fields,independent A and
background partners0. Internal PS/SP,ghost and BL/LB components remain.
Q_full is curved: Q_full^2=(Ihat,.). Nilpotence is not assumed. The same
nonzero Ihat is retained. This notation is not an unrestricted identity
for a fully defined finite effective action or its convergent probe sum.

LFM1 supplies the first-probe result. The new work tests the previously
missing higher pieces. It is a local operator/graph consequence with reused
analytic sewing,not a new radial integration or independent physical test.
All assumptions,acceptance conditions and resource caps were frozen before
computation in RECORD.md,CORRECTION_V2.md and REVIEW_RECORD.md.

## Complete type envelope and quantum-port support

Two enumerations agree: multiset enumeration and a finite dimension/ghost
generating polynomial. Treat even u as arbitrary formal commuting powers,
not as a positive-dimensional variable whose expansion could be truncated.
Rho has dimension1,ghost1,odd parity. With dimension5,ghost1,odd density
and two spinor/source ports,the higher carrier skeletons are:

| Skeleton | Further u power | Local budget | Evidence |
|---|---|---|---|
| C PP | at least2 | one jet | independent-transfer ending/inverse affinity |
| rho PP | at least1 | one jet | same,actual rho current |
| C B PP | at least2 | no jet | PVR/LVR2 |
| rho B PP | at least1 | no jet | new RPV1 |
| C x PP | at least2 | no jet | scalar support audit and linear UCS/RXS sewing |
| rho x PP | at least1 | no jet | same and rho ending independent of u |
| C PP | at least2 | intrinsic coefficient dimension1,no jet | EDS/HP |
| rho PP | at least1 | intrinsic coefficient dimension1,no jet | EDS/HP |
| CC KP P | at least2 | no jet | untruncated Schur kernel |
| rho C KP P | at least1 | no jet | untruncated Schur kernel |
| rho0 rho1 KP P | arbitrary | no jet | untruncated Schur kernel |

The two rho labels remain independent; a repeated identical odd label is0.
These are field-content TYPES,not independent invariant tensors or C5 ranks.
Nonnegative coefficient dimensions and polynomial parameters are retained.
No inverse coupling/mass is introduced to erase a type. Higher scalar,
vector,source and dimension-one local coefficients have zero external jet
budget; constant-field tests cover their local coefficients only,not their
finite/nonlocal amplitudes. The one-jet types require the separate full
transfer proof below. First-probe boundary currents remain as qualified;
higher integrand identities are established before Taylor/IBP reduction.

The full actual physical G/QG densities were scanned before interpreting
scalar completeness. Their source-free marginal parts contain NO scalar
field. The heavy G's296 positive-coefficient-dimension entries and heavy
QG's18104 such entries remain explicitly classified outside this zero-
dimension scalar target; they are not erased from the theory. All source
and external-anchor occurrences are counted separately. Actual marginal
patterns include nonlinear BBB/BBBB,LambdaBB,aCBB and aaCC,not just the
desired simple currents. Their additional internal ports are retained in
the support argument.

For the admitted connected1PI one-loop insertion graphs,E=V and every
vertex has internal degree>=2. Sum(degrees)=2E therefore forces degree2
at every vertex. In the ordinary one-jet/scalar target,extra source-free
nonlinear probe vertices cannot enter without an additional external field
or another loop. The quadratic ghost/scalar possibilities are excluded by
the authenticated FULL finite-transfer EPV symbols,not a constant-u sample.
Thus additional even probes only modify the bosonic inverse or measured
ghost ending in those targets. This extends the qualified EUL/UCS/RXS
graph reductions; it is not a claim about unrestricted connected products
with bridges,multiple loops or new external source sectors.

## Independent-momentum jet identities

At each color projector the measured kernel factors as

    U(k,l)=a(k)b(l), a(k)=(k,w/2), b(l)=(-2l,w).
    G0(k)a(k)=(w k/(2k2),1), b(l)G0(l)=(-w l/l2,2).

Consequently b(l)G0(l)a(l)=0. Mixed-color products vanish by actual
P_r P_s=0. Primary literal vector/auxiliary multiplication and replay
outer-product/norm algebra agree on U(k,l)G0(l)U(l,m)=0 and the complete
Gr=-G0 U G0 tensor with k,l,m INDEPENDENT. Both inverse orders are checked.
The proof uses only vector inner products,no Lorentz trace count; the
explicit component witness is supplemented by the dimension-free norm
argument,not mistaken for a proof of a new analytic dimensional trace.

All92 actual probe/rho current rows satisfy H=V W/2. Actual new AC=AU=0
and rho A=0 are authenticated separately. Hence their momentum is the
adjoining BOSON momentum. J_probe(k)Gr(k,l)=0 before Taylor expansion.
Replacing it by the other endpoint's momentum gives a nonzero polynomial
witness. Fresh auxiliary-current removal changes1290 actual null-product
positions. The generic erased-transfer symbol is nonzero,while the actual
EPV240/660 transfer controls are authenticated REUSE,not newly integrated.

These identities prove exact principal inverse affinity and ghost-ending
affinity coefficientwise at arbitrary probe transfers. Repeated quadratic
insertions and probe-current/inverse cross terms vanish,so the higher
one-jet families vanish before integration. They do not establish a common
finite-part/trace domain for those kernels.

The actual lack of marginal scalar probe vertices then makes the qualified
UCS/RXS scalar sewing a linear functional of that same affine B-side ending.
No additional higher-probe scalar coefficient is generated in this local
zero-jet reference. The all328 scalar/generic Yukawa maps remain covered
by the qualified unrestricted-mass operator,not a chosen flavor point.
Intrinsic dimension-one zero-jet endings remain a separate authenticated
EDS/HP result in the original unshifted model; no physical Mstar or changed
vacuum is silently substituted.

## Full source polynomial without the old cutoff

Workers received ONLY authenticated actual Haa,Hab,Hba,S_marginal and Gu,
not the old effective-kernel/source answer. The Grassmann algebra retains
all independent C/rho labels. Original CGK truncated products at degree2;
the new calculation has NO probe-degree truncation.

Actual action/Hessian/inverse degrees are at most1. The full Schur kernel
Haa-Hab Gu Hba therefore has maximum degree3. Primary left-associates the
complete canonical product; replay right-associates it. Both obtain the
same full polynomial,with34472 degree0 and26072 degree1 ghost-kernel
g/word/color positions and no degree2 or3 terms. The additional products
Hab1 Gu1 and Gu1 Hba1 are identically0. Since the polynomial bound is
proved,no untested tail is called zero. Only after this comparison does
the verifier read old CGK Heff: its degree<=2 limit matches exactly.

Dropping LL leaves17712 nonzero higher GHOST-KERNEL positions. These are
not the earlier645 source-Lie positions or independent counterterms; the
representation differs. CGK's inherited linear source sewing transfers
the new kernel zero to all higher local KP-P source terms,including the
two-rho carrier. The nonzero lower coefficients are preserved. No finite
contact subtraction,renormalized composite product or new QAP follows.

## One unchanged candidate and scope of qualification

The late audit reauthenticates LFM's four-term candidate program. Each term
is affine in u. Its actual G/QG conjugate BV-port overlap is0. CPS supplies
the unchanged matter/source rows and Ihat support; shared ordinary C is not
a BV bracket by itself. Therefore its first FULL variation has no higher
probe image,without asserting Q_full^2=0. All11 higher types are accounted
for by the new jet/source proofs,RPV/PVR and the qualified scalar/intrinsic
reductions. There is no uncovered type within this declared projection.

This earns a bounded formal relative bare-local extension. It does NOT
qualify the full physical/sterile/hatted field functional,arbitrary BV
sources,independent backgrounds,finite connected products,chiral measure/
phase,Lorentzian/constant-vacuum limits,massive matching or E5/A5. H-basic/
HB1/C5 and flavor remain protected. Kappa,b0,chi4 stay distinct/unselected.

## Execution, failure and custody

Original primary completed10.5438198s. Original replay failed at its rational
outer-product comparison BEFORE source output: expansion alone left norm
denominators uncancelled. Its exact source,source copy,complete two-sample
capture and controller failure remain FAILED. Original verification never
launched and has no receipt. The primary polynomial-scaled proof already
had a zero target difference; the correction did not change the equation.

V2 uses exact rational cancellation for the same zero-matrix predicate,
authenticates/reuses the completed primary and reruns only replay/verifier.
They complete10.1924519/1.2803074s; the separate applicability review takes
1.9335486s. No expected coefficient,physical input,domain or assertion was
weakened. The original failed source is not rewritten or rebound.

Primary7samples/max334020608B; failed replay2/max186585088B; corrected replay
7/max331145216B; verifier2/max260579328B; review2/max121745408B. Samples
are not continuous peak bounds. Caps300s/8GiB-sampled/350MiB-floor/16MiB
held; review180s. There are13 exact source copies,bindings57 original,
74 V2,79 validation,44 review. Packet~2.56MB before this report.
Receipts:

- validation_receipt_v2.json:
  51b2387d3d94404d4e934d5f4661c367ce7eb877b76b66978870b21b0c55eac4
- review_receipt.json:
  cd5a0c67954d31cee1719e264b0ec7b51834e33e0dae0b9c4ebaab81655dbb97

Current E4 native0/exits[0,0,0,0,0,2],custodysevenNOTPASS; authenticated
historical reuse,not fresh scientific replay or acceptance. External full
captures/readiness/before/index/postcommit seals share RPV's control folder
C:/Users/psboy/.codex/research-control-records/ToE-Next/rho-probe-vector-response-v1-2026-10-25/.
Before local commit check all frozen inputs,failed/completed statuses and
18 source copies across both packets; preserve all35421 prior tracked blobs.
No remote push or publication is authorized.

The AI-capability result is a dependency-completeness argument using actual
action support,operator reduction and untruncated exterior algebra,not just
more successful coefficient counts. The failed rational comparator is a
real workflow error and is preserved. Shared action,graph/reference premises,
data,SymPy/exact-algebra software and AI authorship limit independence.
There is no external scientific or experimental validation.

## Next scientific dependency

The local probe-dependent obstacle has narrowed. The next question is the
actual REGULATED finite chiral construction. TPW's fixed-lift T_kappa theorem
is bosonic,two probes and one Slavnov tangent; CPS and the present local
identities do not automatically extend its trace/product domain to the
SMA P/S hatted insertion and fermionic source derivatives.

Recover the actual CSW/SQP/TPW regulator and full mixed P/S prescription,
including the order of heat/UV/evanescent limits,before selecting a finite
two-probe fermionic source or ordinary-field test. Do not replace that
prescription with an assumed scalar heat factor on each propagator,drop
source derivatives because a source-zero block is probe independent,or
infer finite contact cancellation from this bare-local zero. A legitimate
outcome may be an explicit compatible domain,measured finite correction,
or a precisely identified missing definition. No favorable normalization
or physical scheme is to be silently adopted. Full investigation remains
ACTIVE and incomplete; prior physical exclusions remain unchanged.
