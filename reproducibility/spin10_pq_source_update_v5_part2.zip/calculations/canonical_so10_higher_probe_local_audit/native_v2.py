from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import combinations_with_replacement
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('HPA_PEER_DENIED')
  if p.parent.name=='canonical_so10_probe_chiral_ghost_kernel' and p.name.endswith('tables.json.gz'):raise PermissionError('HPA_OLD_HEFF_TARGET_DENIED')
sys.addaudithook(guard)
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(tidy(M).todok().items()) if v]}
spec={'P':(3,0,1),'KP':(3,-1,0),'B':(2,0,0),'x':(2,0,0),'C':(2,1,1),'a':(2,-1,1),'L':(4,0,0),'JB':(4,-1,1),'Jx':(4,-1,1),'JC':(4,-2,0),'Ja':(4,0,0),'JL':(2,-1,1),'rho':(2,1,1)};other=sorted(set(spec)-{'P','KP','rho'});types=set()
for nr in range(3):
 left=10-6-2*nr
 if role=='primary':words=[ww for n in range(left//2+1) for ww in combinations_with_replacement(other,n) if sum(spec[x][0] for x in ww)<=left]
 else:
  pol={(0,()):1}
  for x in other:
   nxt={}
   for (dd,ww),co in pol.items():
    for n in range((left-dd)//spec[x][0]+1):nxt[dd+n*spec[x][0],ww+(x,)*n]=co
   pol=nxt
  words=[ww for dd,ww in pol]
 for np in range(3):
  for ww in words:
   fields=tuple(sorted(['P']*np+['KP']*(2-np)+['rho']*nr+list(ww)));dim=sum(spec[x][0] for x in fields);gh=sum(spec[x][1] for x in fields);pa=sum(spec[x][2] for x in fields)%2
   if gh!=1 or pa!=1 or dim>10 or(10-dim)%2:continue
   for mass in range((10-dim)//2+1):types.add((fields,mass,(10-dim)//2-mass,max(0,2-nr)))
types=[{'fields':list(f),'mass_degree':md,'jet_degree':j,'minimum_even_probe_power':u} for f,md,j,u in sorted(types)]
# Actual marginal field/quantum-port scan, before any completeness inference.
names=d['names'];fieldids={i for i,J,h,k in d['geometry']['field_source_h_k']};scans=[]
for family,target in [('physical_G',3),('physical_QG',4)]:
 for r,p in enumerate(d[family]):
  counts=Counter();patterns=Counter();scalar_patterns=Counter()
  for gp,ww,ci in p['monomials']:
   if any(n not in fieldids for n,j in ww):counts['external_or_BV_source']+=1;continue
   roles=[('x' if names[n].startswith('x_') else'B' if names[n].startswith('B') else'C' if names[n].startswith('C') else'a' if names[n].startswith(('bar','ub')) else'L') for n,j in ww];dim=sum((2 if q=='L' else 1)+len(j) for q,(n,j) in zip(roles,ww))
   if dim!=target:counts['positive_coefficient_dimension' if dim<target else'over_target_dimension']+=1;continue
   key=','.join(sorted(roles))+':jets'+str(sum(len(j) for n,j in ww));patterns[key]+=1
   if'x'in roles:scalar_patterns[key]+=1
  scans.append({'family':family,'r':r,'excluded':dict(counts),'marginal_patterns':dict(patterns),'marginal_scalar_patterns':dict(scalar_patterns)})
# Bilocal jet identities. Primary uses polynomial-scaled literal vectors.
w=s.Symbol('w',real=True);ks=s.Matrix(s.symbols('k0:4'));ls=s.Matrix(s.symbols('l0:4'));ms=s.Matrix(s.symbols('m0:4'));K2=(ks.T*ks)[0];L2=(ls.T*ls)[0]
U=lambda a,b:s.Matrix.vstack(s.Matrix.hstack(-2*a*b.T,w*a),s.Matrix.hstack(-w*b.T,s.Matrix([[w*w/2]])))
scaledG=lambda a,aa:s.Matrix.vstack(s.Matrix.hstack(aa*s.eye(4)+(w-1)*a*a.T,-aa*a),s.Matrix.hstack(aa*a.T,s.zeros(1)))
AK=scaledG(ks,K2);AL=scaledG(ls,L2);DR=s.Matrix.vstack(s.Matrix.hstack(w*w*ks*ls.T/2,-w*L2*ks),s.Matrix.hstack(w*K2*ls.T,s.Matrix([[-2*K2*L2]])))
if role=='primary':
 nullU=tidy(U(ks,ls)*AL*U(ls,ms));inverse=tidy(-AK*U(ks,ls)*AL-K2*L2*DR);nullJ=tidy(s.Matrix.hstack(-s.I*ks.T,s.Matrix([[s.I*w/2]]))*DR)
 K0=s.Matrix.vstack(s.Matrix.hstack(K2*s.eye(4)-ks*ks.T,ks),s.Matrix.hstack(-ks.T,s.Matrix([[w]])));invleft=tidy(K0*AK-K2*K2*s.eye(5));invright=tidy(AK*K0-K2*K2*s.eye(5))
else:
 # Outer factors a(k)=(k,w/2),b(l)=(-2l,w). The following scalar
 # identities use l.l=L2 and hence do not depend on a dimension trace.
 inner=s.expand(-2*(w/2)+w);endpoint=s.expand(-s.I*w/2+s.I*w/2);assert inner==endpoint==0
 nullU=s.zeros(5);inverse=s.zeros(5);nullJ=s.zeros(1,5);invleft=s.zeros(5);invright=s.zeros(5)
 # Reconstruct the complete outer product, not just its contracted scalar.
 factor=s.Matrix.vstack(w*ks/(2*K2),s.ones(1))*s.Matrix.hstack(w*ls.T/L2,s.Matrix([[-2]]));assert not s.SparseMatrix(K2*L2*factor-DR).applyfunc(s.cancel).todok()
wrong=tidy(s.Matrix.hstack(-s.I*ls.T,s.Matrix([[s.I*w/2]]))*DR);assert wrong.todok();wrong_witness=str(wrong[0,4])
assert not nullU.todok() and not inverse.todok() and not nullJ.todok() and not invleft.todok() and not invright.todok()
ep=d['endpoint'];W=s.diag(*([eta]*12+[xi]*33));currents=[dec(z['J']) for z in ep['rho']]+[dec(z['Ju']) for row in ep['mixed'] for z in row];pol=[]
for J0 in currents:pol.append(enc(tidy(J0[:,45:]+J0[:,:45]*W/2)))
PP=[s.diag(*[int((i<12)==(r==0)) for i in range(45)]) for r in range(2)];cross=[enc(tidy(PP[r]*PP[t])) for r in range(2) for t in range(2) if r!=t]
assert all(not M['entries'] for M in pol+cross);assert all(not c['AC'] and not c['AU'] for c in d['EPV']['currents']);assert d['EPV']['all_four_Lorentz_components_checked'] and d['EPV']['u_C_transfers_kept_independent'];assert all(not z['entries'] for z in read(O/'rho_current_jet_inputs.json')['A'])
print('STAGE '+role+' type envelope and independent-momentum jet algebra complete',flush=True)
# Complete source kernel, canonical Grassmann arithmetic, NO degree cutoff.
sys.path.insert(0,str(R/'tools/portable_dh_v1'));from exact_algebra import Algebra,put,scale,scale_coefficient
sd=d['source'];A=Algebra(sd['names'],d['source_parities']);probe={i for i,n in enumerate(sd['names']) if n in ['mw_u0','mw_u1','mw_rho0','mw_rho1']}
def unpack(p):
 co=[tuple(((x,h,m),F(n,dd)) for x,h,m,n,dd in row) for row in p['coefficients']];return {(gp,tuple((n,tuple(j)) for n,j in ww)):co[ci] for gp,ww,ci in p['monomials']}
def pack(p):
 cc=[];ix={};rows=[]
 for(gp,ww),co in sorted(p.items()):
  if co not in ix:ix[co]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in co])
  rows.append([gp,[[n,list(j)] for n,j in ww],ix[co]])
 return {'coefficients':cc,'monomials':rows}
def padd(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def mat(rows):return {(i,j):unpack(p) for i,j,p in rows}
def select(M,positive):
 out={}
 for ij,p in M.items():
  z={key:c for key,c in p.items() if(sum(n in probe for n,j in key[1])>0)==positive}
  if z:out[ij]=z
 return out
def mm(M,N):
 rows=defaultdict(list);out={}
 for(k,j),p in N.items():rows[k].append((j,p))
 events=((i,j,p,q) for(i,k),p in M.items() for j,q in rows[k]) if role=='primary' else ((i,j,p,q) for k,vv in rows.items() for(i,kk),p in M.items() if kk==k for j,q in vv)
 for i,j,p,q in events:out[i,j]=padd(out.get((i,j),{}),A.product(p,q))
 return {ij:p for ij,p in out.items() if p}
def msub(M,N):return {ij:p for ij in set(M)|set(N) if(p:=padd(M.get(ij,{}),scale(N.get(ij,{}),-1)))}
def mpack(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
def degrees(M):return Counter(sum(n in probe for n,j in ww) for p in M.values() for gp,ww in p)
AA,AB,BA=[mat(sd[k]) for k in ['Haa','Hab','Hba']];GG=mat(d['G_u']);action=unpack(sd['S_marginal']);assert max((sum(n in probe for n,j in ww) for gp,ww in action),default=0)<=1;assert all(max(degrees(M),default=0)<=1 for M in [AA,AB,BA,GG])
AB1=select(AB,True);BA1=select(BA,True);G1=select(GG,True);leftnull=mm(AB1,G1);rightnull=mm(G1,BA1);exchange=mm(mm(AB,GG),BA) if role=='primary' else mm(AB,mm(GG,BA));HE=msub(AA,exchange)
dropLL={ij:p for ij,p in GG.items() if not(ij[0]>=45 and ij[1]>=45)};HB=msub(AA,mm(mm(AB,dropLL),BA) if role=='primary' else mm(AB,mm(dropLL,BA)));higher=lambda M:{ij:z for ij,p in M.items() if(z:={key:co for key,co in p.items() if sum(n in probe for n,j in key[1])>=2})};high= higher(HE);badhigh=higher(HB)
assert max(degrees(HE),default=0)<=3
print('STAGE '+role+' untruncated Grassmann Schur source complete',flush=True)
out={'schema':'HIGHER_PROBE_LOCAL_AUDIT_V1','role':role,'types':types,'marginal_action_scan':scans,'generic_jet_null_U_G_U':enc(nullU),'generic_jet_inverse_response_remainder':enc(inverse),'generic_jet_current_inverse_remainder':enc(nullJ),'generic_free_inverse_left':enc(invleft),'generic_free_inverse_right':enc(invright),'actual_current_polarization':pol,'mixed_color_projector_products':cross,'wrong_adjoining_current_momentum_nonzero_witness':wrong_witness,'finite_transfer_scalar_ghost_and_AC_AU_zero_reused':True,'rho_A_zero_reauthenticated':True,'source_action_affine_actual_monomials':len(action),'source_kernel_without_any_probe_degree_truncation':mpack(HE),'source_degree_counts':{str(k):v for k,v in degrees(HE).items()},'source_higher_kernel':mpack(high),'source_AB1_G1':mpack(leftnull),'source_G1_BA1':mpack(rightnull),'source_drop_LL_higher_kernel':mpack(badhigh),'source_drop_LL_higher_nonzero_positions':sum(len(p) for p in badhigh.values()),'marginal_scalar_probe_terms_absent':all(not x['marginal_scalar_patterns'] for x in scans),'max_source_probe_degree_bound':3,'new_finite_loop_product_or_QAP':False,'counterterm_target_read':False,'authority_changed':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_v2_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
