# Exact rational comparison continuation

HPA1 primary completed10.5438198s with its exact polynomial-scaled vector
proof and untruncated Schur calculation. Replay V1 FAILED at the outer-product
comparison before producing a table: expansion did not cancel rational norm
denominators. Its original source/source copy, full capture and controller
failure remain. This was not a measured quantum remainder or PASS.

The unchanged target is K2*L2*Gr_outer-DR=0 at independent nonzero momenta.
New native_v2.py uses exact rational cancellation for that comparison only;
it still requires a zero matrix. No physical input, expected equation,
domain, zero complement, assertion or resource limit is weakened. New replay
uses distinct V2 preparation/output/capture paths. The completed original
primary is AUTHENTICATED REUSE, not reclassified as a new execution. New
verifier compares it with the corrected independently associated replay.

Same300s after-import cap per new replay/verifier,8GiB sampled private,
350MiB launch floor,whole HPA16MiB; RPV remains separate12MiB. This delegated
symbolic-harness correction does not retroactively turn the old failure into
success or expand an exhausted run. All scientific ceilings in RECORD.md hold.
