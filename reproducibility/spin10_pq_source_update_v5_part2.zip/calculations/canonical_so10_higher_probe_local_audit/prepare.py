from pathlib import Path
from hashlib import sha256
import ast,gzip,json
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={}
def bind(p,m,key='input_sha256'):
 assert H(p)==read(m)[key][str(p)],p;b[str(p)]=H(p);b[str(m)]=H(m);return load(p)
cg=O.parent/'canonical_so10_probe_chiral_ghost_kernel';hp=O.parent/'canonical_so10_first_probe_local_module';ep=O.parent/'canonical_so10_even_probe_vertices';rx=O.parent/'canonical_so10_probe_scalar_support';rp=O.parent/'canonical_so10_rho_probe_vector_response';pv=O.parent/'canonical_so10_probe_vector_response'
for role in ['primary','replay']:
 x=bind(cg/(role+'_v2_tables.json.gz'),cg/'validation_preparation_v2.json');ci=bind(cg/(role+'_inputs.json.gz'),cg/'preparation_v2.json','native_input_sha256');ei=bind(ep/(role+'_tables.json.gz'),ep/'validation_preparation.json');hi=bind(hp/('endpoint_'+role+'_inputs.json.gz'),hp/'endpoint_preparation.json');mi=bind(hp/(role+'_inputs.json.gz'),hp/'preparation.json')
 z={'source':{k:x[k] for k in ['names','Haa','Hab','Hba','S_marginal']},'source_parities':ci['parities'],'G_u':ci['G_u'],'endpoint':hi,'EPV':{'currents':[{k:c[k] for k in ['AC','AU']} for c in ei['currents']],'all_four_Lorentz_components_checked':ei['all_four_Lorentz_components_checked'],'u_C_transfers_kept_independent':ei['u_C_transfers_kept_independent']},'physical_G':mi['physical_G'],'physical_QG':mi['physical_QG'],'names':mi['names'],'geometry':mi['geometry']}
 p=O/(role+'_inputs.json.gz')
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(p)]=H(p)
z=bind(rx/'quantum_primary_inputs.json.gz',rx/'quantum_validation_preparation_v3.json');p=O/'rho_current_jet_inputs.json'
with p.open('xb') as f:f.write((json.dumps({'A':[v['A'] for v in z['V_A_H']]},sort_keys=True)+'\n').encode())
b[str(p)]=H(p)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V600.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/portable_dh_v1/exact_algebra.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for folder,ns in [(cg,['validation_receipt_v2.json','DERIVATION.md']), (hp,['validation_receipt.json','endpoint_validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz']), (ep,['validation_receipt.json','LOOP_RECORD.md']), (rp,['validation_receipt.json','RECORD.md']), (pv,['validation_receipt.json','loop_validation_receipt_v2.json','review_receipt.json']), (O.parent/'canonical_so10_probe_ghost_scalar_kernel',['QUANTUM_RECORD.md','RESULT_V2.md','quantum_validation_receipt.json']), (O.parent/'canonical_so10_chiral_probe_support',['RESULT.md','validation_receipt.json'])]:
 for n in ns:
  p=folder/n;b[str(p)]=H(p)
assert read(rp/'validation_receipt.json')['positive_even_probe_rho_vector_local_quantum_coefficients_zero']
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_HPA1',len(b),flush=True)
