from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());b=dict(read(O/'preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
for n in ['preparation.json','preparation_capture.json','primary_capture.json','primary_result.json','primary_tables.json.gz','replay_capture.json','controller_failure.json']:
 p=O/n;b[str(p)]=H(p)
assert read(O/'primary_capture.json')['execution_state']=='COMPLETED' and read(O/'replay_capture.json')['execution_state']=='FAILED' and not(O/'replay_tables.json.gz').exists()
for n in ['CORRECTION_V2.md','prepare_v2.py','native_v2.py','verify_v2.py','run_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'whole_packet_cap':16*1024**2,'reuse_original_primary_not_new_execution':True,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_HPA2',len(b),flush=True)
