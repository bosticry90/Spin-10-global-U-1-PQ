# HPA tensor/control applicability review

Freeze before execution. Check the analytic identities underlying the replay
outer-product route explicitly: G0(k)a(k)=(wk/(2k2),1),
b(k)G0(k)=(-wk/k2,2),both K0/G0 inverse orders. Use exact rational reduction
at nonzero independent vector momenta and explain the dimension-free norm
argument, without interpreting a finite vector witness as a new trace theorem.
Freshly delete auxiliary components in all92 actual HP current rows and count
the changed Gr products. Remove an independent transfer from the generic U
symbol and record nonzero support, while retaining the actual qualified EPV
240/660 transfer controls as authenticated REUSE. Authenticate all parent
bindings/receipts and keep the failed V1 replay classified FAILED.

This review strengthens applicability of the completed bounded extension;
it does not add a new unknown quantum input or promote authority. Sequential
review180s after imports,8GiB sampled,350MiB floor,whole HPA16MiB. Preserve
source/capture/failure; no old source edits,cap widening or omitted assertions.
