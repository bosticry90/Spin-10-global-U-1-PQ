# Actual conversion pair versus the earlier sole canonical lift

Freeze after FIM1 and FIM2 paired outputs/verifiers completed. Reauthenticate
all executed sources/inputs and actual receipts; do not rerun expensive
qualified kernels. Review120s,8GiBsampled/350MiBfloor/12MiBwholepacket.

Check the analytic5sqrt(cq) proof constants, actual ordinary loop color and
mass-function/source normalization before comparing with FIS's relative
canonical lift. FIM uses the inherited SMA/FYS inverse correction, with
mass-function direction measured explicitly and its conjugate derived
separately. FIS F=integralJx*T has QF mass-function direction B_R*T, with
the full E_x; no extra physical-Nambu half multiplies that mass function.

Let M_T=unvec(B_R*T). The ordinary loop Cmix*J is measured independently;
its unfiltered DIM member is0. Thus its calculated relative DIM-minus-heat
mass conversion is -Cmix*log(4/3). The sole FIS canonical lift predicts
-M_T*log(3/2) for that same mass-function direction. Compare the ACTUAL
calculated tensor, not a fitted Wardzero. A nonzero mismatch is a legitimate
negative result for that sole candidate, not a first-failure of P/R agreement.

Keep the free common canonical baseline beta symbolically. If it shifts
source and ordinary partners together, it cannot be used as an independent
parameter to hide a mismatch while preserving the measured source transport.
Report full2048positions/twoYmaps/twoprobes/bothchiralities/zeros, exact
nonzero remainders and controls. Preserve all earlier FIS results in their
qualified scopes: sourcekernel and classicalBVlift stay valid even if the
lift does not equal this newly calculated ordinary conversion.

No full bracket/Euler/root finite Wardidentity is claimed by this comparison.
The ordered regulator insertion, physical-sourceEuler/contact terms and
complete first-grade domain must be derived before an anomaly/removability
or restoration verdict. Do not silently install an extra ordinary finite
term or adopt a new scheme. Source/higher-probe classical companions and
all common finite baselines remain explicit. No protected scientific
promotion or foundation/benchmark/physicalmass/flavor/HB1C5 change.
