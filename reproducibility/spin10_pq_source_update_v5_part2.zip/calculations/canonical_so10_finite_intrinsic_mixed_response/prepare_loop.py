from pathlib import Path
from hashlib import sha256
import json,gzip,ast
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b=dict(read(O/'validation_preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
Y=O.parent/'canonical_so10_yukawa_carrier_transport';P=O.parent/'canonical_so10_probe_fermion_onejet';ym=read(Y/'validation_preparation.json')['input_sha256'];pm=read(P/'validation_preparation.json')['input_sha256']
for role in ['primary','replay']:
 yp=Y/(role+'_tables.json.gz');pp=P/(role+'_tables.json.gz');assert H(yp)==ym[str(yp)] and H(pp)==pm[str(pp)];y,p=load(yp),load(pp);z=load(O/(role+'_tables.json.gz'));data={'Tminus':y['Tminus'],'RB':p['RB'],'B10':y['B10'],'B126':y['B126'],'mixed_A_B':[row['direct_A'] for row in z['rows']],'extraction':'ONLY_ACTUAL_CLASSICAL_GAUGE_YUKAWA_AND_INTRINSIC_MIXED_PROPAGATOR_NO_FIS_QUANTUM_TARGET'};dst=O/('loop_'+role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for p0 in [yp,pp,dst]:b[str(p0)]=H(p0)
for p in [Y/'validation_preparation.json',Y/'validation_receipt.json',P/'validation_preparation.json',O/'validation_preparation.json',O/'validation_receipt.json',O/'verify_capture.json']:b[str(p)]=H(p)
for folder,ns in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_fermion_yukawa_self_energy',['RECORD.md','RESULT.md','validation_receipt.json']),('canonical_so10_fermion_gauge_kinetic_pole',['RECORD.md','RESULT.md','validation_receipt.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['LOOP_RECORD.md','prepare_loop.py','loop.py','verify_loop.py','run_loop.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'loop_preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'worker_seconds_after_imports':450,'verifier_seconds_after_imports':120,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_FIM2',len(b),flush=True)
