from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
loc={z:s.Symbol(z,real=True) for z in ['g10','xi','eta_H']};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(lambda x:s.simplify(s.expand_log(x,force=True)));enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
a=load(O/'loop_primary_tables.json.gz');F=read(O.parent/'canonical_so10_finite_intrinsic_scalar_source/lift_receipt.json');L32=s.log(s.Rational(3,2));L43=s.log(s.Rational(4,3));L83=s.log(s.Rational(8,3));beta=s.Symbol('beta',real=True);positions=0;nonzero=0;res=[]
for r,z in enumerate(a['colors']):
 groups={}
 for key in ['B10','B126']:
  M=dec(F['mass_directions'][r][key]);sides={}
  for side in ['left','right']:
   MM=M if side=='left' else M.H;C=dec(z[key][side]);actual=-L43*C;pred=-L32*MM;diff=cl(actual-pred);assert not cl(diff-L83*MM).todok();assert not cl((actual+beta*MM)-(pred+beta*MM)-diff).todok();positions+=256;nonzero+=len(diff.todok());sides[side]=enc(diff)
  groups[key]=sides
 res.append(groups)
e=s.Symbol('epsilon');d=2/(2-e)*(4**e-3**e)/(e*(1-e));assert cl(s.Matrix([[s.limit(d,e,0)-L43]])).is_zero_matrix;assert s.Rational(3,2)/(s.Rational(5,4)*s.Rational(1,4))==s.Rational(24,5)<5
op=load(O/'primary_tables.json.gz');eds=load(O.parent/'canonical_so10_probe_mass_dimension_one/ending_primary_tables.json.gz');aux_control=[]
G=dec(eds['G0']);N=dec(eds['N0'])
for z in eds['probe_quadratics']:
 Gr=dec(z['Gr']);wrong=s.SparseMatrix(Gr)
 for i in range(45):
  for j in range(45):wrong[i+45,j+45]=0
 delta=cl(-(wrong-Gr)*N);aux_control.append({'B_output':len(delta[:45,:].todok()),'Lambda_output':len(delta[45:,:].todok())})
assert nonzero==2 and positions==2048
out={'schema':'FIM2_RELATIVE_PAIR_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'actual_relative_conversion_compared_to_old_FIS_sole_lift':True,'complete_mass_component_positions_including_zeros':positions,'nonzero_remainder_positions_both_chiralities':nonzero,'relative_pair_remainder':res,'common_canonical_baseline_cannot_remove_remainder':True,'sole_classical_FIS_lift_equals_measured_ordinary_conversion':False,'earlier_FIS_kernel_and_classical_lift_remain_valid_within_scope':True,'uniform_fractional_power_remainder_bound_constant_checked':'24/5<5','Gr_LL_omission_controls_by_output':aux_control,'full_Ward_root_Euler_or_anomaly_restoration_verdict':False,'finite_scheme_or_extra_counterterm_installed':False,'scientific_authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
