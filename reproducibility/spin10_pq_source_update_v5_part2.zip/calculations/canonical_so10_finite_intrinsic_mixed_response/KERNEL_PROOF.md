# Ordered intrinsic mixed response and its ordinary fermion kernel

This derivation uses the frozen FIM1/FIM2 contracts. Qualification requires
actual paired outputs and separate receipts; the proof text is not an
alternate authority ledger.

## Exact first-grade inverse response

Let b=(B_long,Lambda). At first intrinsic scalar-mixing grade use

```
H_bb=K0+uU, H_bx=t(N0+uNr), H_xx=Q I.
```

Expand the ordered inverse in u,t before restricting fields. The mixed
coefficient has the two paths

```
A=-G0 Nr, B=G0 U G0 N0=-Gr N0,
G_bx,ut=E_b E_x [A+E_b B]Gx.
```

The scalar-u path is absent by EPV's complete zero marginal scalar
quadratic symbol. Direct sparse multiplication and independent color2x2
blocks give A+B=0 on the FULL90x328 actual domain, not only B output.
For the broken probe A,B each have592 positions, including296 B and296
Lambda. The light probe is0 by support. No result was fitted.

EDS2's actual longitudinal scaling gives A(k)=Rb^-1 A(1),B(k)=Rb^-1 B(1),
Rb=diag(k I_B,I_L). The transpose at opposite momentum is derived with
Pb=diag(-I_B,I_L). In the B output, a late actual-coefficient check gives
A_B=-2i Srho, B_B=+2i Srho. Thus the vector-scalar propagator is

```
G_Bmu,x,ut=-2i Srho * k_mu/Q² * E_Q²(1-E_Q).
```

Its scalar-vector reverse endpoint has the opposite momentum sign. The
Lambda output remains in the operator record. There is no direct LambdaPP
matter vertex, so it does not enter this ordinary open-fermion loop.
Deleting Gr_LL is sensitive in the full mixed output but insensitive to
this B-only matter projection; these are different controls.

## Universal spinor and actual color

Use the qualified SMA physical-physical block -i bar_slash(R)/R and FYS
open-line inverse correction -sum V_i G_PP V_j Delta_ij, with no closed
fermion half. The vertices are

```
V_B=-ig bar_gamma(PL T_a-PR T_a^T),
V_x=PL m_i+PR m_i^dagger.
```

Keep both endpoint orders and the derivative adjoint of Delta_xB. The
scalar Lorentz numerator is bar_k.(bar_k-p); antisymmetric gamma terms
integrate0 because the exact scalar weights contain only one external p.
This is shown after the ordered products, not by commuting gamma matrices.
A barred Clifford/projector witness with a noncommuting2x2 mass and charge
checks relative signs. It is not a four-matrix BMHV representation: the
full P/S inverse is inherited and internal hats stay in Gaussian moments.

Writing W_ai=A_B, the actual holomorphic mass coefficient is

```
Cmix_R=-g sum_ai W_ai (T_a^T m_R,i+m_R,i T_a).
```

Its conjugate is derived separately using +g W_ai(T_a m_i^dagger+
m_i^dagger T_a^T). Actual W is imaginary and both expressions obey the
required adjoint relation. Primary sums(a,i) directly; replay first
accumulates each color's mass matrix. Neither native reads the FIS source
vector, mass lift or a desired counterterm. Generic symmetric family
Y_R multiplies the computed16x16 tensor; it is not replaced by a trace,
chosen numerical texture or extra family3.

## Two finite-epsilon integral routes

Set Q=k²,R=(k-p)²,q=p_E²>0,c=2t,N=exp(gamma_E e)(mu_R²)^e. The scalar kernel is

```
J=N integral E_Q²(1-E_Q) E_R*(bar_k²-k.p)/(Q² R).
```

Primary evaluates the literal barred Gaussian as S2-S3, retaining the
actual repeated-denominator weights(alpha-lambda*c). Each face has
s0=c max(lambda/(1-x),1/x),Delta=q x(1-x), and upper gamma functions.
The barred Gaussian mean is2/s-q x(1-x), not D/(2s) with hats omitted.

Replay uses (Q+R-q)/2-hat_k², keeping all heat differences combined.
The Q^-2 tadpole difference is a compact proper-time integral; the bubble,
Q^-2R^-1 and hatted differences share their actual parameter integrands.
The factor1-E_Q improves Q0 softness. These COMBINED pieces are IR
integrable; their individual lambda2 andlambda3 critical pieces are not
assigned separate ordinary integrals or unrelated IR contact constants.

## Uniform local limit, without assuming a unique joint limit

Differentiate S_lambda in lambda and integrate lambda2..3. With alpha=c v,
beta=c w, v>=lambda,w>=1, h=vw/(v+w), z=cq,

```
J/(Nc^e)=int_2^3 d lambda int_lambda^infty dv int_1^infty dw
 (v+w)^(-2+e) exp(-z h) [2/(v+w)-z vw/(v+w)²].
```

At z0 this equals

```
dJ(e)=2/(2-e)*(4^e-3^e)/[e(1-e)], dJ(0)=log(4/3).
```

The difference from dJ has positive integrand
(v+w)^(-3+e)[2(1-exp(-x))+x exp(-x)],x=z h.
Use1-exp(-x)<=sqrt(x),x exp(-x)<=sqrt(x),h<=(v+w)/4.
For0<=e<=1/4 the remaining double integral is bounded by
1/[(2-e-1/2)(1-e-1/2)]<=16/5. The lambda interval has length1.
Hence

```
0<=dJ(e)-J/(Nc^e)<= (24/5)sqrt(cq) <=5sqrt(cq).
```

This proves strict-heat J->log(4/3), independent of nonexceptional q.
The two heat lengths are3 and4; substituting the source bubble's2 and3
would give the wrong constant. In unfiltered DIM the complete mixed
inverse derivative is identically0. Along cq=exp(-a/e), the isolated
J tends exp(-a)log(4/3), so it has no unique unrestricted joint limit.
This does not decide the combined ordinary/source/hatted/root Ward group
or invalidate an already prescribed iterated finite-part construction.

The finite component conversion must be compared with FIS only after the
independent loop is completed. Even a nonzero mismatch to the proposed
source-based lift would be a missing quantum-group dependency, not an
anomaly verdict or permission to fit a convenient normalization.
