# FIM2: actual ordinary intrinsic uPP finite loop

Freeze after FIM1 P/R/verifier completed. Its bare fullmixedresponse is0;
for broken probe A_B=-2i Srho, B_B=+2i Srho, and filtered vector-scalar
propagator is -2i Srho*k_mu*E_Q²(1-E_Q)/Q². Lambda response is retained
in the operator record; no direct LambdaPP matter vertex exists. Calculate
the complete selected ordinaryuPP intrinsic first-grade quantum contribution,
then compare with the FIS source conversion/predicted companion only LATE.

Same original unshifted SMA, one constant u, physical PP, externalhats0,
Euclideanp²=q>0,A0, intrinsiccoefficientdimension1 only. One gauge and one
Yukawa endpoint are required for the mixed B-x line. There are two oriented
endpoints, a directNr path and U+N0 inverse path. No intrinsic physical
fermion mass exists in the unshifted action (MDS1 reuse); translated scalar/
mass vertices are another class. Other intrinsic vertices have too many
internal ports for a1PIcycle with only two externalfermions. Probes have no
matter vertex and actualmarginalscalaruquadratic0. Keep all328scalars,45colors,
both chiralities and arbitrary symmetricY10/Y126. No physicalfit/adoption.

Reuse SMA/FYS open-line inverse correction -sum V_i G_PP V_j G_boson, with
NO closed-loop half or extra family3. V_B=-ig bar_gamma(PLT-PRT^T),
V_x=PLm_i+PRm_i^dagger, G_PP=-i bar_slash(R)/R. Opposite mixed scalar/vector
endpoint is transpose at opposite momentum, not an unlabelled conjugate.
Primary explicit barred-Clifford/projector witness with noncommuting2x2 internal
mass/charge; replay ordered chirality routing. The fullPS principal inverse is
inherited from SMA, not re-proved with a four-matrix BMHV representation.
Lorentz antisymmetric terms
integrate0 because the exact two-node scalar kernel has only externalp.
Do not drop internal analytic hats from barred Gaussian moments.

Actual model color: independently contract the FIM A_B tensor and YCT full
maps with BOTH ordered products T^T m and mT; derive conjugate independently.
Primary direct(a,i)sum; replay first accumulates each color's scalar mass
matrix. Hermitianconjugation/symmetricmass and exactzeros must agree.
ActualphysicalTB comes from originalYCTTminus and PFJ's checked RB. No FIS
quantum vector, mass lift or counterterm may be read by native workers.

Universal kernel J=N int E_Q²(1-E_Q)E_R*(bar_k²-k.p)/(Q²R).
Its two heat lengths are3 and4, unlike FIS source2 and3. Primary literal
barred Gaussian S2-S3. Replay cancels denominators:
bar_k²-k.p=(Q+R-q)/2-hat_k². Keep the heat DIFFERENCES combined in each
IR-critical piece. The factor1-E_Q makes the combined Q^-2 tadpole/bubble
pieces IRintegrable; their separate lambda2/lambda3 pieces are not assigned
independent IR extensions. Evaluate the tadpole difference by compact proper
time, bubble/hat differences by combined parameter integrands.

80digits/60stored,1e-35scaledgate.9unique finitecases:e0,.1,.2,
cq .01,.2,1.5,q .5,2,5,muR²1.5;9jointpaths e .1,.05,.025,a .5,1,2,
cq=exp(-a/e),q2. Derive/check leading
dJ(e)=2/(2-e)*(4^e-3^e)/[e(1-e)], dJ0=log(4/3).
Uniformbound0<=dJ-J/(Nc^e)<=5sqrt(cq),0<=e<=1/4:
differentiateheatlengthlambda2..3, use1-exp(-x)<=sqrt(x), xexp(-x)<=sqrt(x),
vw/(v+w)<= (v+w)/4, then two proper-time integrals bounded explicitly.
Report isolatedjointpathdependence instead of importing NFP whole limit.

First quantum outputs precede late comparisons with FIS B_R*T/sourcevector.
Wrong scalar-mass commutator, mixedendpoint sign, scalarhalf/family3,
wrong heat length/source log and omit hats are sensitive where actual;
report honestzero/e0insensitivity. The coefficient is not assigned from
a desired Wardzero or from FIS's relative canonical lift.

P/R450s each afterimports, verifier120s,8GiBsampled/350MiBfloor/12MiBpacket.
Freeze new sources/inputs/captures, retain failures without relabel. This is
a new bounded continuation, not expansion of FIM1's120s allowance.
Ceiling: complete intrinsicordinaryuPP one-loop input in stateddomain.
Full combinedE_P/E_xsourceEuler,hatted/root Wardgroup remains a separate
necessary comparison; no anomaly or fullrestoration from a partial mismatch.
No physicalscheme/baseline/benchmark,flavor/HB1C5 or E5A5/authority promotion.
Sharedaction,SMA/FYS/EDS/YCT/CSW reference,software/AIauthorlimitindependence.
