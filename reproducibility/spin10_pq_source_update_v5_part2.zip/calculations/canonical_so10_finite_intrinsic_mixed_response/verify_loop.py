from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'loop_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('loop_'+r+'_tables.json.gz')) for r in ['primary','replay']];assert a['colors']==b['colors'] and a['wrong_mass_commutator_controls']==b['wrong_mass_commutator_controls'];mp.mp.dps=80;worst=mp.mpf(0);n=0;hat=0;ins=0
for x,y in zip(a['rows']+a['paths'],b['rows']+b['paths']):
 for k in ['J','leading','bound']+(['omit_hats'] if 'omit_hats'in x else['path_limit']):
  err=abs(mp.mpf(x[k])-mp.mpf(y[k]))/max(1,abs(mp.mpf(x[k])),abs(mp.mpf(y[k])));worst=max(worst,err);assert err<mp.mpf('1e-35'),(x,k,err);n+=1
 assert 0<=mp.mpf(x['leading'])-mp.mpf(x['J'])<=mp.mpf(x['bound'])+mp.mpf('1e-55')
 if 'omit_hats'in x:
  changed=abs(mp.mpf(x['omit_hats'])-mp.mpf(x['J']))>mp.mpf('1e-35');hat+=int(changed);ins+=int(not changed)
loc={z:s.Symbol(z,real=True) for z in ['g10','xi','eta_H']};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);F=load(O.parent/'canonical_so10_finite_intrinsic_scalar_source/primary_v2_tables.json.gz');Y=load(O.parent/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');comp=[]
for r,z in enumerate(a['colors']):
 v=dec(F['source_vectors'][r]);rr={}
 for key in ['B10','B126']:
  B=dec(Y[key]);vm=B*v;M=s.Matrix(16,16,lambda i,j:vm[16*i+j,0]);C=dec(z[key]['left']);diff=cl(C+2*M);rr[key]={'loop_nonzero_positions':len(C.todok()),'Cmix_plus_2_B_T_positions':len(diff.todok())}
 comp.append(rr)
out={'schema':'FIM2_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'actual_ordinary_spin_chiral_color_and_IR_safe_kernel_routes_agree':True,'new_finite_kernel_cases':9,'joint_paths':9,'numeric_comparisons':n,'maximum_scaled_discrepancy':mp.nstr(worst,30),'hatted_omission_sensitive_cases':hat,'hatted_e0_insensitive_cases':ins,'late_source_color_comparison':comp,'mass_commutator_controls':a['wrong_mass_commutator_controls'],'strict_heat_loop_kernel':'log(4/3)','source_kernel_log3over2_not_substituted':True,'joint_path_limit':'exp(-a)*log(4/3)','unique_unrestricted_joint_limit':False,'complete_combined_Ward_source_hatted_root_qualified':False,'full_QAP_measure_phase_scheme_E5_A5_or_authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
