# Ordinary finite intrinsic mass term and a failed sole-lift comparison

October25,2026. PROGRESS, baseafbbcf6d43c305564d0871b23e39d36547c72477.
Two completed results: the full intrinsic mixed-propagator u response has
been derived, and its complete selected ordinary fermion loop has been
calculated. The latter does **not** implement the earlier FIS source-only
canonical lift by itself. The exact remaining conversion tensor is
nonzero. This is a scoped negative candidate result, not an anomaly or
complete Ward-restoration verdict. Execution and validity checks completed;
the sole-candidate comparison is INSUFFICIENT within the tested component.
State113/authority34of39 and E5/A5 remain unchanged.

## Scientific domain

Original unshifted SMA/CSW, one constant even probe u_r, A0, physical
external PP, external hats0, nonexceptional Euclidean p²=q>0, first
INTRINSIC coefficient-dimension-one gauge-fixing/reference insertions.
All328 scalar directions,45 colors and both mass chiralities remain.
This is a formal first-grade term, not a full massive amplitude, scalar
translation or new physical mass/vacuum/flavor point. The complete general
symmetric Y10/Y126 family matrices are retained. The YCT realization
remains provisional in its established scope; no foundational adoption.

## Complete mixed response before the loop

The actual ordered inverse derivative has two paths,

```
A=-G0 Nr, B=G0 U G0 N0=-Gr N0,
G_bx,ut=E_b E_x (A+E_b B)Gx.
```

Direct sparse multiplication and independent2x2color blocks agree across
177,120 direct/inverse/total positions including zeros. The unbroken
probe is0. For the broken probe each path has592 positions, and their
unfiltered sum is0 on both B and Lambda outputs. They must not be
discarded separately. Actual full momentum scaling and opposite-momentum
derivative adjoints are checked using the qualified EDS2 Lorentz shapes.
This does not establish a new general massive inverse/IR theorem.

In the vector output the independently compared classical coefficients are
A_B=-2i Srho and B_B=+2i Srho. Therefore

```
G_Bmu,x,ut=-2i Srho*k_mu/Q² * E_Q²(1-E_Q).
```

The additional heat factor belongs to the inverse U insertion. The
opposite scalar-vector endpoint has the derivative-adjoint sign. Dropping
direct/inverse or flipping one mixed inverse changes592 operator positions;
omitting Nr_B/Nr_L changes592/296. Erasing Gr_LL changes296 Lambda-output
positions and0 B-output positions, so that particular control is
insensitive in the subsequent ordinary matter loop. Full auxiliary
components remain preserved for later Ward/source use.

## Actual ordinary fermion loop

The1PI intrinsic class has one gauge and one Yukawa endpoint, with the
mixed response between them. Remaining intrinsic vertices have too many
internal ports or exceed the grade. There is no intrinsic physical mass
in the unshifted matter action; translated mass insertions are separate.

The inherited SMA/FYS open-line rule is -V_i G_PP V_j Delta_ij, with no
closed-loop half or extra family3. Both endpoint orders are retained.
A barred Clifford/projector witness with noncommuting internal charge
and mass checks the relative signs; replay uses ordered chirality
routing. The full P/S inverse is inherited, and analytic internal hat
rank -2epsilon stays inside the scalar numerator integration.

Writing W=A_B, the measured holomorphic color tensor is

```
Cmix_R=-g10 sum_ai W_ai(T_a^T m_R,i+m_R,i T_a).
```

Its conjugate is calculated separately and passes the adjoint relation.
Primary sums(a,i) directly; replay accumulates each color's mass matrix
first. Both use actual YCT maps and the checked physical gauge frame.
Neither native reads the FIS source vector, mass lift or a counterterm.
The two routes give zero B10 for both probes and zero B126 for the
unbroken probe. The broken B126 result is

**Cmix_126= -5sqrt(30)g10²xi²/4 P_N.**

The scalar kernel in common1/(16pi²) units is

```
J=N integral E_Q²(1-E_Q)E_R*(bar_k²-k.p)/(Q²R),
Q=k²,R=(k-p)²,c=2t,N=exp(gamma_E epsilon)*(mu_R²)^epsilon.
```

The ordinary inverse-propagator mass contribution is Cmix_R*J, multiplied
by the arbitrary family Y_R and its conjugate in the declared chiral
blocks. It is not an observable neutrino mass shift.

Primary literal barred Gaussian S2-S3 and replay denominator-canceled,
IR-safe heat differences agree on the complete finite-epsilon kernels.
Separate critical lambda2/lambda3 tadpole/bubble pieces are not given
independent IR extensions. The common heat difference improves their
softness before integration.

The analytic bound is

```
dJ(e)=2/(2-e)*(4^e-3^e)/[e(1-e)], dJ(0)=log(4/3),
0<=dJ(e)-J/(Nc^e)<=5sqrt(cq), 0<=e<=1/4.
```

It follows from a positive heat-length representation and explicit
fractional-power inequalities, as detailed in KERNEL_PROOF.md. Thus the
strict-heat limit is **J->log(4/3)**. The unfiltered dimensional member
is0 by the full mixed inverse identity. Along cq=exp(-a/e), isolated J
tends exp(-a)log(4/3); it has no unique unrestricted joint limit. This
does not invalidate an ordered finite-part prescription or settle the
combined first-grade Ward group.

## Discriminating late comparison: the sole FIS lift is insufficient

Only after both ordinary-loop natives completed did the checker read the
old FIS source vector T. On the full two-probe/two-map domain it finds

```
Cmix_R=-2 M_T,R,  M_T,R=unvec(B_R T).
```

This is an independently computed ordinary-loop consequence of the actual
source/mass covariance, not a fitted loop input. The unfiltered ordinary
member is0, so its calculated relative DIM-minus-heat conversion is
`-Cmix_R log(4/3)=+2M_T,R log(4/3)`.

The earlier FIS source kernel required relative source conversion
`-T log(3/2)`. Its constructed sole canonical lift predicts ordinary
mass-function companion `-M_T,R log(3/2)`. That prediction differs from
the newly measured ordinary conversion. The exact remainder is

**R_R = M_T,R [2log(4/3)+log(3/2)] = M_T,R log(8/3).**

For broken B126 its coefficient is
`5sqrt(30)g10²xi² log(8/3)/8 P_N`, with its separately checked conjugate.
All other mass-map/probe components are0. The review compares2,048 matrix
positions including zeros and retains two nonzero positions, one in each
chirality. SymPy's receipt serializes the coefficient as the equivalent
logarithm of a positive constant raised to the polynomial coefficient;
the exact factored equality above is checked before serialization.

A common free canonical baseline shifts source and ordinary partners
together and leaves this remainder unchanged. It cannot be used as an
extra independent parameter to hide the mismatch. The FIS source kernel
and its classical BV completion remain correct in their qualified scopes.
The new result rejects using that **sole** completion as proof that the
actual measured relative conversion pair is implemented.

This is not the complete local Slavnov breaking, a classification of
every finite counterterm or evidence that no renormalized prescription
exists. The source/Euler phases and ordered regulator insertion must be
combined explicitly before any restoration, removability or obstruction
theorem. No extra finite term has been silently installed to make the
comparison vanish, and no physical scheme has been adopted.

## Validation, resources and provenance

FIM1 P/R/verifier completed in1.4356670/1.4635188/.6434101s afterimports.
The separately frozen FIM2 continuation had450s worker caps and120s
verifier; it did not enlarge FIM1's120s allowance. FIM2 P/R/verifier
completed in257.5136205/256.1231964/3.0735527s. Review completed1.7061336s.
All executions completed native0 on their original frozen sources;
no FIM worker, controller or verifier failed.

FIM1 samples2/2/1 reached49,537,024/49,778,688/393,216B. FIM2 samples
129/129/3 reached61,800,448/59,162,624/49,700,864B. Review2 samples
reached58,437,632B. These are sampled observations, not continuous peaks.
The8GiBsampled/350MiBfloor/12MiBpacket limits held. The pre-report packet
was242,357B with13 source copies; bindings34/42/72/82/94 authenticate
operator, validation, loop, loop-validation and review stages.

There are9 finite cases and9 joint paths,80digits/60stored,72 scalar
comparisons with1e-35 scaled gate. Stored maximum discrepancy is0, a
numerical corroboration rather than exact integration. Hatted omission
changes6 finite cases and is insensitive at the3 epsilon0 cases. The
wrong symmetric-mass commutator changes the one surviving mass position;
all structurally zero model components are honestly insensitive.

Receipts SHA256:

- Operator:6fadbc2c21d68c0e7e50e6d5cd94f6b0ba7b4b01c278da21c7b2fe81d3353d46.
- Ordinaryloop:f5713012991f6ec638f8ab1b6916efb5581bc3578d4f012047fd193f52149167.
- Review:e13c10912acb983d69ce62f47e5ea26c26d38b5bc085eeae132c7710570ef7d2.

Fresh delegated E4 completed native0, steps[0,0,0,0,0,2]. Historical
custody remains exit2/sevenNOTPASS; authentication is not scientific
acceptance. Complete captures/readiness/preservation checks are retained
under external finite-intrinsic-mixed-response-v1-2026-10-25. All old
evidence and project_state.json are protected. The earlier FIS library
failure remains preserved in its unchanged folder.

## Next scientific decision

Derive the complete intrinsic rhoPP first-variation group in one convention,
including the physical/scalar source Euler terms, actual hatted insertion
and ordered positive-heat regulator response. Extract the regulator tangent
from the actual G source gradients before restricting sources, and calculate
its complete target words independently. Do not assign it the remainder
above merely to restore the identity. Determine whether the measured
conversion pair and additional correlated terms admit the required common
renormalized definition, retaining every nonzero mismatch.

This turn demonstrates useful negative discrimination after a prior
constructed candidate, rather than more favorable fitted cancellations.
Shared action, source/Clifford conventions, SMA/FYS/EDS/YCT/CSW premises,
software and AI author limit independence. There is no external scientific
or experimental validation. Translated scalar/mass families, physical
source reality/phase, full chiral QAP/measure, causal/physical limits,
E5/A5 and physical unification remain unresolved.
