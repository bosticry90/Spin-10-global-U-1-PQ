from pathlib import Path
from hashlib import sha256
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('FIM_PEER_DENIED')
  if p.parent.name=='canonical_so10_finite_intrinsic_scalar_source':raise PermissionError('FIM_COUNTERTERM_AND_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);g,xi,eta=s.symbols('g10 xi eta_H',real=True);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));K,G,N=map(dec,[d['K0'],d['G0'],d['N0']]);P=s.diag(*([-1]*45+[1]*45));assert not cl(K*G-s.eye(90)).todok() and not cl(G*K-s.eye(90)).todok() and not cl(G.T-P*G*P).todok()
kk=s.Symbol('k',positive=True);Rb=s.diag(*([kk]*45+[1]*45));Ri=s.diag(*([1/kk]*45+[1]*45));E=s.Symbol('E');rows=[]
def assoc(A,B):
 if role=='primary':return cl(A*B)
 assert A.rows==A.cols==90 and A.cols==B.rows
 for (i,j),v in A.todok().items():assert i%45==j%45
 out=s.SparseMatrix(90,B.cols,{})
 for a in range(45):
  aa=[a,45+a];ab=A.extract(aa,aa);bb=B.extract(aa,list(range(B.cols)));cc=ab*bb
  for (i,j),v in s.SparseMatrix(cc).todok().items():out[aa[i],j]=v
 return cl(out)
for z in d['probe_quadratics']:
 U,Nr,Gr=map(dec,[z['U'],z['Nr'],z['Gr']]);assert not cl(Gr+G*U*G).todok() and not cl(U.T-P*U*P).todok();A=-assoc(G,Nr);B=-assoc(Gr,N);total=cl(A+B)
 scaledA=-Ri*G*Ri*Rb*Nr;scaledB=-Ri*Gr*Ri*Rb*N;assert not cl(scaledA-Ri*A).todok() and not cl(scaledB-Ri*B).todok()
 # Scalar-to-boson reverse endpoint derived separately, with derivative adjoint.
 reverseA=-Nr.T*P*G;reverseB=-N.T*P*Gr;assert not cl(reverseA-A.T*P).todok() and not cl(reverseB-B.T*P).todok()
 noLL=s.SparseMatrix(Gr)
 for i in range(45):
  for j in range(45):noLL[i+45,j+45]=0
 dropLL=cl(-noLL*N-B);NrB=s.SparseMatrix(Nr)
 for (i,j),v in list(NrB.todok().items()):
  if i<45:NrB[i,j]=0
 dropNrB=cl(-G*NrB-A);NrL=s.SparseMatrix(Nr)
 for (i,j),v in list(NrL.todok().items()):
  if i>=45:NrL[i,j]=0
 dropNrL=cl(-G*NrL-A);wrongG=P*G*P;wrong=cl(-wrongG*Nr+G*Nr)
 rows.append({'direct_A':enc(A),'inverse_B':enc(B),'unfiltered_total':enc(total),'filtered_E2_coefficient':enc(A),'filtered_E3_coefficient':enc(B),'controls':{'drop_direct':len(A.todok()),'drop_inverse':len(B.todok()),'drop_Gr_LL':len(dropLL.todok()),'drop_Nr_B':len(dropNrB.todok()),'drop_Nr_L':len(dropNrL.todok()),'flip_mixed_inverse_sign':len(wrong.todok())},'symbolic_k_and_reverse_endpoint_checked':True})
# Neumann series distinguishes a direct mixed perturbation from the two
# ordered bosonic inverse paths; do not commute free factors.
Gb,Gx,U0,N0,Nu=s.symbols('Gb Gx U N Nu',commutative=False);u,t=s.symbols('u t',commutative=True);V=s.Matrix([[u*U0,t*N0+u*t*Nu],[0,0]]);Gd=s.diag(Gb,Gx);expansion=Gd-Gd*V*Gd+Gd*V*Gd*V*Gd;co=s.expand(expansion[0,1]).coeff(u,1).coeff(t,1);assert s.expand(co-(-Gb*Nu*Gx+Gb*U0*Gb*N0*Gx))==0
out={'schema':'FIM1_INTRINSIC_MIXED_RESPONSE','role':role,'rows':rows,'all90_by328_positions_and_zero_complement':True,'full_mixed_inverse_in_both_orders':True,'independent_neumann_path_derivation':True,'fixed_heat_edge_lengths':'E_b*E_x*(A+E_b*B)*Gx','constant_u_only_and_first_intrinsic_coefficient_grade1':True,'new_fermionic_loop_coefficient_or_Ward_restoration':False,'scientific_authority_changed':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
