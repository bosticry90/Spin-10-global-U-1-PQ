from pathlib import Path
from hashlib import sha256
import json,gzip,ast,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={};assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='afbbcf6d43c305564d0871b23e39d36547c72477'
E=O.parent/'canonical_so10_probe_mass_dimension_one';m=read(E/'ending_validation_preparation.json')['input_sha256']
for role in ['primary','replay']:
 p=E/('ending_'+role+'_tables.json.gz');assert H(p)==m[str(p)];d=load(p);b[str(p)]=H(p);z={k:d[k] for k in ['K0','G0','N0','probe_quadratics']};z['extraction']='ACTUAL_CLASSICAL_EDS_MIXED_HESSIANS_NO_RHO_TARGET_OR_QUANTUM_COUNTERTERM';dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for folder,ns in [('canonical_so10_probe_mass_dimension_one',['ENDING_RECORD.md','SYMBOL_RECORD.md','RESULT.md','ending_validation_preparation.json','ending_validation_receipt.json','symbol_receipt.json']),('canonical_so10_even_probe_vertices',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_finite_intrinsic_scalar_source',['RESULT.md','DERIVATION.md','validation_receipt_v2.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V608.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':120,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_FIM1',len(b),flush=True)
