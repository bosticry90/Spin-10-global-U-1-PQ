# FIM1: actual first intrinsic mixed inverse response

Freeze before computation, October25,2026, baseafbbcf6d43c305564d0871b23e39d36547c72477,
35790oldblobs. FIS1 measured a nonzero intrinsic scalar-source heat kernel.
Its proposed relative ordinary companion remains unmeasured. Before a
fermionic integral determine the exact full boson-scalar u response,
including the unequal heat lengths of its actual paths. This is the next
indispensable operator input, not another general coefficient catalogue.

Original unshifted action/SMA/CSW, A0, one CONSTANT even u_r, first INTRINSIC
coefficient dimension1, no ordinary backgrounds beyond external physical
fermions when later sewn. Work here on90 longitudinal B/Lambda and328scalar
slots, symbolic nonzero central k=|momentum|, both widths and polynomialg10.
Transverse scalar-mixing exclusion and full-D Lorentz shapes are qualified
EDS2 reuse, not a new momentum-domain theorem. This constant-u operator
does not establish a full transferred finite first-grade quantum amplitude.
No scalartranslation, mass/flavor choice or vacuum/scheme adoption.

Reuse actual EDS K0,G0,U_r,Gr,N0,Nr, all complete matrices and zero complement.
The coefficient of u*t in the inverse of
[[K0+uU,t(N0+uNr)],[tNsharp,QI]] has two paths:
A=-G0 Nr, B=G0 U G0 N0=-Gr N0.
EPV's actual marginal scalar u Hessian is0, so no Gx Uxx Gx path exists at
this grade. No omitted matter loop or classical equation is set0 here.

At fixed positive heat the exact derivative is
G_bx,u,t=E_b E_x [A+E_b B]Gx. The extra E_b belongs to the U insertion,
not to the direct Nr path. For constant-u all internal bosonic momenta
coincide and E_b=E_x=E(Q); do NOT remove its edge count. Restore
A(k)=Rb(k)^-1 A(1), B(k)=Rb(k)^-1 B(1), Rb=diag(kI_B,I_L),Gx=1/k².
Keep Lambda output until complete support is assessed. Store A,B,total
UNFILTERED and filtered polynomial coefficients separately. A bare zero
is a hypothesis, not an imposed success condition.

Primary full sparse ordered multiplication; replay independent2x2colorblock
contractions after checking actualblockdiagonality. Also derive both
Neumann-series paths from a two-label inverse with noncommuting free words;
check opposite momentum transpose using Pb=diag(-I_B,I_L), not Hermitian
conjugation. General Q0 and full massive/IR limits are outside this target.

Only after complete native outputs, compare actual B-output coefficients
with qualified Srho as a classical endpoint check. Report the actual ratio
if it exists; do not infer a finite loop from it or force a desired zero.
Controls omit direct/inverse, erase Gr_LL, omit one Nr block, merge heat
lengths or flip one mixed inverse orientation. Include honest zero/control
insensitivities. No FIS proposed counterterm or ordinary quantum target may
be read by native workers. All90*328 positions/probe and zeros must compare.

Two sequential workers/verifier120s each afterimports,8GiBsampledprivate,
350MiBfloor,12MiBpacket. Freeze inputs/sources before computation. Retain
failures and failed source/captures. Ceiling: actual operator response and
properly scoped heat/transpose consequence, not a new integratedfermion
amplitude, full Wardrestoration/QAP/measure/phase, physical benchmark/E5A5.
State113/34of39 andcustody2sevenNOTPASS unchanged. LiveAGENTS/noagents/
branch/worktree/push/outreach/publication/adoption/flavor/HB1C5/promotion.
Shared action/reference/EDS/EPV/CSW/software/AIauthor limit independence.
