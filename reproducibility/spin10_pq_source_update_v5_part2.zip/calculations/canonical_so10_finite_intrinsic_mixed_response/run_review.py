from pathlib import Path
from hashlib import sha256
import json,ast,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/finite-intrinsic-mixed-response-v1-2026-10-25');read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'loop_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 F=O.parent/'canonical_so10_finite_intrinsic_scalar_source';m=read(F/'lift_preparation.json')['input_sha256']
 for n in ['lift_preparation.json','lift_receipt.json']:
  p=F/n;b[str(p)]=H(p)
 for p,h in m.items():assert H(Path(p))==h,p
 for n in ['REVIEW_RECORD.md','review.py','run_review.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
  b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
 for n in ['KERNEL_PROOF.md','loop_validation_preparation.json','loop_validation_receipt.json','loop_verify_capture.json']:b[str(O/n)]=H(O/n)
 dump(O/'review_preparation.json',{'input_sha256':b,'seconds_after_imports':120,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'review.py')]);dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in z['all_resource_samples'])<=8*1024**3;rr=[json.loads(x[7:]) for x in z['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<120;dump(O/'review_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<12*1024**2;print('COMPLETED_FIM2_REVIEW',rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'review_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
