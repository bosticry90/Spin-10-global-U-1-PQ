from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(450,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'loop_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('loop_'+('replay' if role=='primary' else'primary')):raise PermissionError('FIM2_PEER_DENIED')
  if p.parent.name=='canonical_so10_finite_intrinsic_scalar_source':raise PermissionError('FIM2_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);g,xi,eta=s.symbols('g10 xi eta_H',real=True);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
d=json.loads(gzip.decompress((O/('loop_'+role+'_inputs.json.gz')).read_bytes()));TP=list(map(dec,d['Tminus']));RB=dec(d['RB']);T=[cl(sum((RB[a,b]*TP[a] for a in range(45) if RB[a,b]),s.zeros(16))) for b in range(45)];assert all(not cl(x-x.H).todok() for x in T)
# Independent universal open-line spin/endpoint phases. The inherited FYS
# rule is -V_i G_PP V_j Delta_ij, without a closed-loop half.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];chi=s.prod(gam);PL=(s.eye(4)+chi)/2;PR=s.eye(4)-PL;W0,g0=s.symbols('W g',real=True);tt=pa[1]+pa[2]/3;mm=s.Matrix([[1+s.I,2],[2,3-s.I]]);k=[1,2,3,1];r=[2,-1,1,3];K=sum((k[i]*gam[i] for i in range(4)),s.zeros(4));RR=sum((r[i]*gam[i] for i in range(4)),s.zeros(4));dot=sum(k[i]*r[i] for i in range(4));tau=s.kronecker_product(PL,tt)-s.kronecker_product(PR,tt.T);MA=s.kronecker_product(PL,mm)+s.kronecker_product(PR,mm.H)
if role=='primary':
 VB=-s.I*g0*s.kronecker_product(K,s.eye(2))*tau;GG=-s.I*s.kronecker_product(RR,s.eye(2));Q=-(VB*GG*MA*W0+MA*GG*VB*(-W0));LL=s.zeros(2);RR0=s.zeros(2)
 for i in range(4):
  for j in range(4):LL+=PL[j,i]*Q[2*i:2*i+2,2*j:2*j+2];RR0+=PR[j,i]*Q[2*i:2*i+2,2*j:2*j+2]
 LL=cl(LL/(s.trace(PL)*dot));RR0=cl(RR0/(s.trace(PR)*dot));assert not cl(LL+g0*W0*(tt.T*mm+mm*tt)).todok() and not cl(RR0-g0*W0*(tt*mm.H+mm.H*tt.T)).todok()
else:
 # Gamma flips chiral charge; mass does not. Keep both ordered endpoints.
 a,b,c0=s.symbols('T TT M',commutative=False);left=s.expand(-g0*W0*(b*c0+c0*a));assert left==-g0*W0*b*c0-g0*W0*c0*a
 assert not cl((tt.T*mm+mm*tt).T-(tt.T*mm+mm*tt)).todok()
colors=[];comm=[]
for z in d['mixed_A_B']:
 A=dec(z)[:45,:];groups={};bad={}
 for key in ['B10','B126']:
  B=dec(d[key]);cols={i:s.Matrix(16,16,lambda j,k:B[j*16+k,i]) for i in sorted({i for a,i in A.todok()})};left=s.zeros(16);right=s.zeros(16);wrong=s.zeros(16)
  if role=='primary':
   for (a,i),w in A.todok().items():
    m=cols[i];left-=g*w*(T[a].T*m+m*T[a]);right+=g*w*(T[a]*m.H+m.H*T[a].T);wrong-=g*w*(T[a].T*m-m*T[a])
  else:
   for a in range(45):
    m=sum((A[a,i]*cols[i] for i in cols if A[a,i]),s.zeros(16));mr=sum((A[a,i]*cols[i].H for i in cols if A[a,i]),s.zeros(16));left-=g*(T[a].T*m+m*T[a]);right+=g*(T[a]*mr+mr*T[a].T);wrong-=g*(T[a].T*m-m*T[a])
  left,right,wrong=map(cl,[left,right,wrong]);assert not cl(left-left.T).todok() and not cl(right-left.H).todok();groups[key]={'left':enc(left),'right':enc(right)};bad[key]=len(cl(wrong-left).todok())
 colors.append(groups);comm.append(bad)
print('STAGE FIM2 '+role+' actual ordinary mixed loop colors and independent chiralities complete',flush=True)
mp.mp.dps=80;fmt=lambda x:mp.nstr(x,60)
def kernel(e,z,q,mu,omit_hat=False):
 c=z/q;N=mp.exp(mp.euler*e)*mu**e;interval=[0,mp.mpf(1)/4,mp.mpf(1)/3,1]
 @lru_cache(None)
 def js(x,lam):
  u=x*(1-x);dl=q*u;lo=c*max(lam/(1-x),1/x);y=dl*lo;j0=mp.e1(y) if not e else dl**(-e)*mp.gammainc(e,y,mp.inf)
  if not e:j0=mp.e1(y)
  jm=dl**(1-e)*mp.gammainc(e-1,y,mp.inf);jp=dl**(-1-e)*mp.gammainc(e+1,y,mp.inf);return u,j0,jm,jp
 def diffs(x):
  u,j02,jm2,jp2=js(x,2);u,j03,jm3,jp3=js(x,3);return u,j02-j03,2*jm2-3*jm3,jp2-jp3,2*j02-3*j03
 def direct(x):
  u,d0,dm,dp,dc=difs=diffs(x);return 2*(1-x)*d0-2*c*dm-q*u*(1-x)*dp+c*q*u*dc
 def rational(x):
  u,d0,dm,dp,dc=diffs(x);db=(1-x)*dp-c*dc;dh=-e*((1-x)*d0-c*dm);return d0/2-q*db/2-(0 if omit_hat else dh)
 if role=='primary' and not omit_hat:J=N*mp.quad(direct,interval)
 else:
  td=N*c**e*mp.exp(-z)*(mp.quad(lambda y:y**(-e)*mp.exp(z*y),[0,mp.mpf(1)/4])+mp.quad(lambda y:(1/y-3)*y**(-e)*mp.exp(z*y),[mp.mpf(1)/4,mp.mpf(1)/3]));J=N*mp.quad(rational,interval)+td/2
 dd=2/(2-e)*(4**e-3**e)/(e*(1-e)) if e else mp.log(mp.mpf(4)/3);lead=N*c**e*dd;bound=5*N*c**e*mp.sqrt(z);return J,lead,bound
rows=[]
for e0 in ['0','0.1','0.2']:
 for z0,q0 in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  e,z,q=map(mp.mpf,[e0,z0,q0]);J,L,B=kernel(e,z,q,mp.mpf('1.5'));Jbad,_,_=kernel(e,z,q,mp.mpf('1.5'),True);assert 0<=L-J<=B+mp.mpf('1e-55');rows.append({'epsilon':e0,'cq':z0,'q':q0,'J':fmt(J),'leading':fmt(L),'bound':fmt(B),'omit_hats':fmt(Jbad)})
 print('STAGE FIM2 '+role+' epsilon '+e0+' complete',flush=True)
paths=[]
for e0 in ['0.1','0.05','0.025']:
 for a0 in ['0.5','1','2']:
  e,a=map(mp.mpf,[e0,a0]);z=mp.exp(-a/e);J,L,B=kernel(e,z,mp.mpf(2),mp.mpf('1.5'));assert 0<=L-J<=B+mp.mpf('1e-55');paths.append({'epsilon':e0,'a':a0,'J':fmt(J),'leading':fmt(L),'bound':fmt(B),'path_limit':fmt(mp.exp(-a)*mp.log(mp.mpf(4)/3))})
out={'schema':'FIM2_ORDINARY_INTRINSIC_UPP','role':role,'colors':colors,'wrong_mass_commutator_controls':comm,'rows':rows,'paths':paths,'sourcefree_open_line_no_half_or_family3':True,'strict_heat_J':'log(4/3)','unfiltered_DIM_kernel':'0','unrestricted_joint_limit_unique':False,'complete_intrinsic_ordinary_class_only_not_full_Ward':True,'scientific_authority_changed':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/('loop_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
