# NFP1 applicability and fixed-candidate finite comparison

Freeze after native P/R/verifier terminal completion. Reauthenticate original
sources/inputs and receipts; do not rerun expensive kernels or alter their
normalization. Review remains180s/8GiBsampled/350MiBfloor/12MiBpacket.

1. Check a full split-Clifford free physical/sterile block BEFORE projection:
L=[[barR,hatR],[hatR,barR]],L²=Rfull I,Dt=iL,Gt=-i E_R L/Rfull.
Both DtGt and GtDt equal E_R I. Physical Euler times the PP block is
E_R(1-hatR²/Rfull). The missing term is precisely the mixed insertion,
not permission to drop S or internal hats. An8spin witness tests algebra;
analytic hat rank remains-2epsilon. No noninteger Hilbert-space claim.

2. Prove the uniform group bound using actual split moments forlambda2.
Mu0=a0=1/6, a(e)<1,|a'|<4; h>=3 andh<=2/u imply Mx<=1/2,M2<3.
logh<=4h^(1/4) gives |Mu'|<=pi sqrt2/2<3. The sum is bounded by
Nc^e[(7+4/3)e+(1+3e)cq] <=Nc^e(10e+2cq). Explicitly note dimensionless
c*muR²<=1 bounds Nc^e. This controls the WHOLE group, not its separate
hat/root limits, scalar or source kernels independently.

3. Support/domain: all G first gradients retain an omitted bosonic/source
anchor, so no (G,Gamma) survives this target. The physical source Euler term
cannot be deleted because Gamma_(rho KP P) is nonzero. EB/Ex supplies no
extra term: rho-JB has affine insertion0 plus actual weighted antisymmetric
color trace0, rho-Jx has no marginal a-x/B-x/Lambda-x path. Other classical
Euler columns vanish on this formal grade/physical ideal. The actual Ihat
and Q_full curvature are retained. Root unheated-unit term has softdegree3,
source numerator softdegree3 atQ0 and1 atR0; D>=7/2 suffices. Separate
1/Q² and1/(Q²R) terms have degree4 and are not separately IR-integrable.

4. Root reduction is conditional on the inherited full CSW source-Hessian
identity, whose ordinary/source four legs are not re-proved here. The actual
complete target cycle and full nonminimal current/inverse relation reduce
its nonminimal roots before integration; both sides carry E_Q². The remaining
adjacent fermion inverse defect is E_R-1. This is an operator reduction,
not independent fresh component expansion of the full835-field trace.
Free-edge factors commute here; a fresh global swapped-order diagnostic
would be insensitive. Authenticate CSW's already-qualified8 wrong-order
fixtures rather than falsely crediting a new test. Wrong NODE placement is
freshly tested in the main kernels and is sensitive. Lambda1 is only a
diagnostic assignment; actual co-variation changes C2->C1 while S2 stays.

5. Late fixed-candidate test. Authenticate PFJ's original construction F and
check the unmodified current LFM kinetic program. For the constant-rho,
ordinary PP projection, d[u Lsym(F)] supplies iF. Other four-part candidate
terms require C,B,x or KP at this projection and do not contribute. Compare
iF to NEW finite group iCU/6 and to old bare PFJ only AFTER the new kernels.
Use both chiralities/transposes and all zeros. A pass earns this selected
finite comparison, not full restoration, uniqueness or a new counterterm.
No finite normalization is fitted; the common scalar freedom remains.
The old F was originally constructed from bare local data, so this test is
a new finite applicability test with shared normalization premises, not an
independent new prediction of every field/source coefficient.

Primary mathematical checks use DLMF13.4.1 with ordinary1F1=Gamma(b)*boldM
from13.2.4; do not import Olver's normalizedM without itsGamma factor.
External literature, action, source/sign conventions, software and AI author
remain shared assumptions. No external expert/experiment/proof assistant,
scheme/foundation/benchmark adoption, full QAP/measure/E5/A5 promotion.
