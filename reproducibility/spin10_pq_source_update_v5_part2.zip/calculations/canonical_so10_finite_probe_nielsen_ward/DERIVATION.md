# Prospective complete constant-probe first-variation reduction

Use the actual CPS/CSW augmented action and all source-Hessian legs:

 b_ext Gamma1,t=onehalf STr(Gt Ihat'')-STr M_ext+STr(Gt Rt M_ext).

The independent rho coefficient includes dGamma/du. At physical PP backgrounds
all first G gradients vanish only after the full anchor/source audit. The
remaining classical source Euler legs are E_P, E_B and E_x. The latter two
have no compatible rho-J quantum primitive in this target by the audited
field/color support, so the nontrivial source primitive is rho K_P P.
STr M has no rhoPP by field content, not by an unrestricted measure theorem.

Actual constant-rho G has vector current -i V k and auxiliary current i H,
with V=-w/2,H=-w²/4 in each selected physical color. Keeping G_LB=+k/Q,
(Jrho G0)_B=i*w²*k/(4Q). Multiplication by G_Ca=1/Q gives the ending identity

 GuBB_mu,nu=-2i k_mu*(Jrho G0)_B,nu*G_Ca=w²*k_mu*k_nu/(2Q²).

It is checked on actual matrices and currents before quantum integration,
including B/Lambda separately. With fixed reference both sides have E_Q².
This is the complete nonminimal inverse/current relation needed by this
cycle; no extra unlabelled marginal vertices fit the1PI target. In the
full-source congruence the paired nonminimal inverse defects group into
this identity. They cannot be dropped individually. Co-varying the reference
replaces E_Q² on the left by E_Q and leaves a genuine additional defect.

For the source triangle K(-p),C(k),f(p-k) and B(-k),barf(k-p),P(p), the
ordered G vertex is a(-k)rho B(k). Six-odd-coordinate Wick/Berezin checks
give the same triangle sign. Momentum fixes the propagator +i Rbar/R.
Vector and auxiliary phases then multiply W V and -H, respectively. Thus
Gamma_(rho KP P) has color g²(C_V-C_H), with C_V=sum WV*TB*TC and
C_H=sum H*TB*TC. This coefficient is derived, not assigned from Gu.
Its scalar spinor kernel is S_lambda below; the reversed orientation is
retained for the conjugate Euler leg. Two polarizations of the ONE Nambu
source give2(C_V-C_H), not an additional source copy or determinant half.

Set N=exp(gammaE e)muR²^e,u=x(1-x),Delta=qu,s0=c*max(lambda/(1-x),1/x),
Jn=Delta^(-e-n)Gamma(e+n,Delta*s0). Primary integrates the literal barred
source numerator bar_k²-k.p, whose Gaussian mean is2/s-uq:

 S_lambda=N integral[2(1-x)J0-2lambda*c*Jminus1
                    -q*u*(1-x)J1+lambda*c*q*u*J0]dx.

Replay uses bar_k²-k.p=(Q+R-q)/2-hat_k², but keeps (R-q)/(Q²R) combined.
Its Gaussian numerator is D/(2s)-q*x*(2-x),D4-2e. The separate T=integral1/Q²
and B=integral1/(Q²R) terms would each have soft degree4 at Q0 and are not
ordinary integrable kernels near e0. Their common combined numerator vanishes
at Q0 and is retained. The hat scalar moment has rank-2e. This gives a
distinct safe parameter representation, not independent finite IR constants.

C_lambda is the independently measured FCP ordinary response. After color
contraction the full source reduction must itself show2(C_V-C_H)=-C_U,
where C_U=w²*C_r/2 is obtained independently from Gu. Then the full left group
is C_U*(C_lambda-S_lambda), with both ordered source legs accounted for.

The unintegrated barred Clifford identity is

 Kbar Rbar Kbar -[Pbar Rbar Kbar+Kbar Rbar Pbar]/2 = Rbar² Kbar,
 Pbar=Kbar-Rbar.

The physical/source matrices remain ordered until the identity is proved.
The full mixed P/S inverse yields Rbar²=R-hat_k². The hatted portion is the
actual SMA mixed-PS insertion, with both orientations/phases retained:

 H_lambda=-Hv_lambda,
 Hv_lambda=-e*N integral x[(1-x)J0-lambda*c*Jminus1]dx.

The remaining adjacent inverse uses D_R Gt_R=E_R I before continuum tracing.
Its explicit ordered cutoff defect has root kernel

 R_lambda/p=N integral E_Q^lambda(E_R-1) Kbar/(Q²).

The subtracted unit term is an absolutely integrable odd heat kernel; its
integral is0. Its soft degree3 must be checked before using that oddness.
Consequently the independently integrated root is

 A_lambda=N*c^e integral_0^(1/(lambda+1))
           (1-(lambda+1)y)y^-e exp[-cq(1-y)]dy
 =N*c^e*(lambda+1)^(e-1)*exp(-cq)
       *1F1(1-e;3-e;cq/(lambda+1))/[(1-e)(2-e)].

Test the finite-cutoff identity C_lambda-S_lambda=H_lambda+A_lambda.
For lambda2 this is the actual complete reduced CSW group. Lambda1 describes
a mismatched heat replacement unless its separate reference variation is
included; it must not be called a second physical Ward prescription.
In particular actual co-variation of the u reference changes C2 to C1 but
does not change the u0 rho-source primitive S2. The simultaneous lambda1
pair is only a mathematical heat-assignment control; it is not the actual
co-varied full Ward group. Its separate reference response must be retained.

Zero-heat dimensional analytic continuation gives
S_DIM=(1-e/2)I_DIM and H_DIM=N*q^-e*Gamma(1+e)Beta(2-e,2-e),limit1/6.
Strict e0 heat constants and relative finite comparison must be derived by
actual split-face integrals, not from requiring equality with FCP.

Joint limit for actual lambda2: write h=max(2/(1-x),1/x),
Mu(e)=intu*h^e,Mx(e)=intx*h^(e-1),M2(e)=intu²*h^(1+e),
a(e)=3^(e-1)/[(1-e)(2-e)]. Then
eB=H_DIM-Nc^e Mu+RB,0<=RB<=eNq c^(1+e)M2/(1+e),
0<=2ec*N intx Jminus1<=2eNc^e Mx/(1-e),
|A-Nc^e a(e)|<=Nc^e*cq*a(e).
On0<=e<=1/4: a<1,|a'|<4,Mu0=a0=1/6,|Mu'|<3,Mx<=1/2,M2<3,
using h<=2/u and logh<=4*h^(1/4). These imply the conservative bound

 |H_2+A_2-H_DIM|<=N*c^e*(10e+2cq).

Nc^e is bounded when c*muR²<=1. Thus the WHOLE group has joint limit1/6
without restricting e logc. Along cq=exp(-a/e), the hatted/root shares tend
(1-exp(-a))/6 and exp(-a)/6. Separate limits do not commute. No renormalized
source-product theorem outside this nonexceptional coefficient is inferred.

All independent quantities and colors are computed before FCP/PFJ comparisons.
Primary mathematical comparators: https://dlmf.nist.gov/8.7.E3,
https://dlmf.nist.gov/13.4.E1. Physics comparators:
https://arxiv.org/abs/hep-ph/9907254v3 and https://arxiv.org/abs/1904.08231v3.
Their coefficients/regulators are not adopted or used to fit this result.
