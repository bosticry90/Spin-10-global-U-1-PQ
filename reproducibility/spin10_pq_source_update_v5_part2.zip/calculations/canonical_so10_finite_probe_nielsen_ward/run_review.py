from pathlib import Path
from hashlib import sha256
import json,sys,ast,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/finite-probe-nielsen-ward-v1-2026-10-25');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 F=O.parent/'canonical_so10_probe_fermion_onejet';m=read(F/'construction_validation_preparation.json')['input_sha256'];p=F/'construction_tables.json.gz';assert H(p)==m[str(p)];b[str(p)]=H(p);b[str(F/'construction_validation_preparation.json')]=H(F/'construction_validation_preparation.json')
 for folder,ns in [('canonical_so10_probe_fermion_onejet',['construction_check_receipt.json','construction_receipt.json']),('canonical_so10_first_probe_local_module',['RESULT.md','validation_receipt.json','primary_tables.json.gz','validation_preparation.json'])]:
  for n in ns:
   p=O.parent/folder/n;b[str(p)]=H(p)
 for n in ['REVIEW.md','review.py','run_review.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 for n in ['REVIEW.md','review.py','run_review.py','REVIEW.md.source.txt','review.py.source.txt','run_review.py.source.txt','validation_receipt.json','verify_capture.json','validation_preparation.json']:b[str(O/n)]=H(O/n)
 dump(O/'review_preparation.json',{'input_sha256':b,'scientific_acceptance':'NOT_PERFORMED','explicit_file_list':True})
 z=capture([sys.executable,'-B',str(O/'review.py')]);dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in z['all_resource_samples'])<=8*1024**3;rr=[json.loads(x[7:]) for x in z['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'review_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<12*1024**2;print('COMPLETED_NFP1_REVIEW',rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'review_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
