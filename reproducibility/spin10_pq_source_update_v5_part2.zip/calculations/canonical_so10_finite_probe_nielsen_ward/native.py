from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from itertools import permutations
import gzip,json,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(450,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('NFP_PEER_DENIED')
  if p.parent.name in ['canonical_so10_probe_fermion_onejet','canonical_so10_finite_constant_probe_fermion'] and ('tables'in p.name or 'receipt'in p.name):raise PermissionError('NFP_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);d=load(O/(role+'_inputs.json.gz'));names=d['names'];base=d['base_names'];pairs=d['field_source_pairs'];source_to_field={names.index(base[J]):base[i] for i,J,h,k in pairs};allowed={j for j,n in source_to_field.items() if n in [('bar' if a<12 else'ub')+str(a) for a in range(45)]+[('b' if a<12 else'L')+str(a) for a in range(45)]};aud=[]
for G in d['physical_G']:
 assert all(len(row[1])>=2 for row in G['monomials']);ports={n for gg,word,cc in G['monomials'] for n,j in word if n in source_to_field};assert ports<=allowed
 ax=[]
 for gg,word,cc in G['monomials']:
  nn=[names[n] for n,j in word]
  if len(word)==2 and any(n.startswith('x_') for n in nn) and any(n in [('bar' if a<12 else'ub')+str(a) for a in range(45)] for n in nn):assert all(not j for n,j in word);ax.append(word)
 aud.append({'G_positions':len(G['monomials']),'source_ports':len(ports),'first_gradient_has_an_anchor':True,'a_x_quadratics_positive_dimension_only':len(ax)})
assert all(len({a,b,c})==3 for a,b,c,v in d['physical_f'])
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v) for i,j,v in z['entries']});clean=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(clean(M).todok().items()) if v]};T=list(map(dec,d['Tminus']));RB,RC=dec(d['RB']),dec(d['RC']);assert RB==RC;TB=[clean(sum((RB[a,b]*T[a] for a in range(45) if RB[a,b]),s.zeros(16))) for b in range(45)];TC=[clean(sum((RC[a,b]*T[a] for a in range(45) if RC[a,b]),s.zeros(16))) for b in range(45)]
def wedge(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   sg=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(6) if a&(1<<i));out[a|b]=s.expand(out.get(a|b,0)+sg*x*y)
 return {k:v for k,v in out.items() if v!=0}
def word(seq,co=1):
 out={0:co}
 for i in seq:out=wedge(out,{1<<i:1})
 return out
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v!=0}
if role=='primary':
 vertices=[[3,0],[2,4],[5,1]];unit=s.Rational(sum((-1)**sum(ww[i]>ww[j] for i in range(6) for j in range(i+1,6)) for perm in permutations(range(3)) for ww in [sum((vertices[i] for i in perm),[])]),6)
else:
 D0,Q0,al,be,de=s.symbols('D0 Q0 al be de',nonzero=True);act={}
 for seq,co in [([5,4],D0),([3,2],Q0),([3,0],al),([2,4],be),([5,1],de)]:act=add(act,word(seq,co))
 term=ex={0:s.S.One}
 for n in range(1,4):term={k:-v/s.Integer(n) for k,v in wedge(term,act).items()};ex=add(ex,term)
 unit=s.simplify(-ex[63]/ex[60]*D0*Q0/(al*be*de))
assert unit==1;phaseV=s.simplify(unit*(-s.I)*s.I*(-s.I)*s.I);phaseH=s.simplify(unit*s.I*s.I*(-s.I)*s.I);assert phaseV==1 and phaseH==-1
# One physical source, both independent kinetic Euler polarizations.
DM=s.Symbol('DM');left=wedge(word([2],DM),word([0,1]));right=wedge(word([1],-DM),word([0,2]));euler=add(left,right);assert euler=={7:2*DM}
eta,xi=s.symbols('eta_H xi');W=s.diag(*([eta]*12+[xi]*33));colors=[]
for r,ker in enumerate(d['V_A_H']):
 V,A,HH=[dec(ker[k]) for k in ['V','A','H']];expectedV=s.diag(*(([-eta/2]*12+[0]*33) if r==0 else([0]*12+[-xi/2]*33)));assert not A.todok() and not clean(V-expectedV).todok()
 assert not clean(HH-V*W/2).todok() and all(i==j for i,j in V.todok()) and all(i==j for i,j in HH.todok())
 def contract(M,reverse=False):
  return clean(sum((v*(TC[a]*TB[b] if reverse else TB[b]*TC[a]) for(b,a),v in M.todok().items()),s.zeros(16)))
 CV,CH=contract(W*V),contract(HH);source=clean(phaseV*CV+phaseH*CH)
 ids=range(12) if r==0 else range(12,45);ww=eta if r==0 else xi;CU=clean(sum((ww**2*TB[a]*TB[a]/2 for a in ids),s.zeros(16)));hatcolor=clean(sum((s.sympify(ph)/s.I*contract(M,rev) for M,phs in [(W*V,d['hatted_oriented_B_phases']),(HH,d['hatted_oriented_L_phases'])] for rev,ph in enumerate(phs)),s.zeros(16)));assert not clean(2*source+CU).todok() and not clean(hatcolor-CU).todok();colors.append({'source':enc(source),'Euler_two_legs':enc(2*source),'ordinary_CU':enc(CU),'direct_hatted':enc(hatcolor)})
w,E=s.symbols('w E');G=s.Matrix([[w,-1],[1,0]]);U=s.Matrix([[-2,w],[-w,w*w/2]]);Gu=-(G*U*G);J=s.Matrix([[s.I*w/2,-s.I*w*w/4]]);ending=(J*G)[0,0];assert s.simplify(-2*s.I*ending-Gu[0,0])==0 and s.simplify(E*E*(-2*s.I*ending)-E*E*Gu[0,0])==0
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gg=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];kv=s.Matrix(s.symbols('k0:4'));pv=s.Matrix(s.symbols('p0:4'));K=sum((kv[i]*gg[i] for i in range(4)),s.zeros(4));P=sum((pv[i]*gg[i] for i in range(4)),s.zeros(4));Rr=K-P;assert not clean(K*Rr*K-(P*Rr*K+K*Rr*P)/2-(Rr*Rr)*K).todok();Snum=s.expand(s.trace(Rr*K)/4);assert Snum==s.expand((kv.T*kv)[0]-(kv.T*pv)[0]);rk=s.Symbol('R',positive=True);er=s.Symbol('E_R');hat=s.Symbol('hat2');assert s.expand((rk-hat)-rk+hat)==0
print('STAGE NFP '+role+' actual source support,statistics,Euler,current and ordered Clifford identities complete',flush=True)
ee=s.Symbol('epsilon');x=s.Symbol('x',positive=True);chi=s.Symbol('chi4',real=True);constants={}
for lam in [1,2]:
 split=s.Rational(1,lam+1);lnpart=s.integrate(2*(1-x)*s.log(1-x),(x,0,split))+s.integrate(2*(1-x)*s.log(lam*x),(x,split,1));bd=s.integrate(2*lam*x,(x,0,split))+s.integrate(2*(1-x),(x,split,1))+s.Rational(1,2);hs=s.simplify(-lnpart-bd);rel=s.simplify(chi+s.Rational(1,2)-s.log(2)-hs);constants[str(lam)]={'source_absolute_heat_H':str(hs),'source_DIM_minus_heat':str(rel)}
mp.mp.dps=100;fmt=lambda z:mp.nstr(z,75)
def calc(e,c,q,mu,lam,source=True):
 N=mp.exp(mp.euler*e)*mu**e;cut=mp.mpf(1)/(lam+1);interval=[0,cut,1]
 @lru_cache(None)
 def ks(x):
  u=x*(1-x);dl=q*u;lo=c*max(lam/(1-x),1/x);y=dl*lo;return u,dl**(-e)*mp.gammainc(e,y,mp.inf),dl**(1-e)*mp.gammainc(e-1,y,mp.inf),dl**(-e-1)*mp.gammainc(e+1,y,mp.inf)
 def Psource(x):
  u,j0,jm,jp=ks(x);return 2*(1-x)*j0-2*lam*c*jm-q*u*(1-x)*jp+lam*c*q*u*j0
 def Rcombined(x):
  u,j0,jm,jp=ks(x);return (2-e)*((1-x)*j0-lam*c*jm)-q*x*(2-x)*((1-x)*jp-lam*c*j0)
 def h0(x):
  u,j0,jm,jp=ks(x);return -e*((1-x)*j0-lam*c*jm)
 def hvec(x):
  u,j0,jm,jp=ks(x);return -e*x*((1-x)*j0-lam*c*jm)
 def directWard(x):
  u,j0,jm,jp=ks(x);return (1-x)*(3*x-1)*j0-lam*c*(3*x-1)*jm+q*x*(1-x)**3*jp-lam*c*q*x*(1-x)**2*j0
 if source:
  if role=='primary':SS=N*mp.quad(Psource,interval)
  else:SS=N*(mp.quad(lambda x:ks(x)[1],interval)/2+mp.quad(Rcombined,interval)/2-mp.quad(h0,interval))
 else:SS=None
 Hv=N*mp.quad(hvec,interval) if e else mp.mpf(0)
 if role=='primary':AA=N*c**e*mp.quad(lambda y:(1-(lam+1)*y)*y**(-e)*mp.exp(-c*q*(1-y)),[0,mp.mpf(1)/(lam+1)]);WD=N*mp.quad(directWard,interval)
 else:AA=N*c**e*(lam+1)**(e-1)*mp.exp(-c*q)*mp.hyp1f1(1-e,3-e,c*q/(lam+1))/((1-e)*(2-e));WD=AA-Hv
 HD=N*q**(-e)*mp.gamma(1+e)*mp.beta(2-e,2-e);bound=N*c**e*(10*e+2*c*q)
 wrongroot=N*c**e*(lam+2)**(e-1)*mp.exp(-c*q)*mp.hyp1f1(1-e,3-e,c*q/(lam+2))/((1-e)*(2-e))-AA
 return {'source_S':None if SS is None else fmt(SS),'direct_hatted_H':fmt(-Hv),'positive_heat_root_A':fmt(AA),'whole_Ward':fmt(WD),'dimensional_H':fmt(HD),'uniform_actual_bound':fmt(bound),'wrong_root_node':fmt(wrongroot),'difference_from_dimensional':fmt(WD-HD)}
rows=[]
for lam in [1,2]:
 for e0 in ['0','0.1','0.2']:
  for z0,q0 in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
   ev,zv,qv=map(mp.mpf,[e0,z0,q0]);row=calc(ev,zv/qv,qv,mp.mpf('1.5'),lam);row.update({'lambda':lam,'epsilon':e0,'cq':z0,'q':q0});rows.append(row)
  print('STAGE NFP '+role+' lambda '+str(lam)+' epsilon '+e0+' finite complete',flush=True)
paths=[]
for e0 in ['0.1','0.05','0.025']:
 for a0 in ['0.5','1','2']:
  ev,av=map(mp.mpf,[e0,a0]);cv=mp.exp(-av/ev)/2;row=calc(ev,cv,mp.mpf(2),mp.mpf('1.5'),2,False);assert abs(mp.mpf(row['difference_from_dimensional']))<=mp.mpf(row['uniform_actual_bound'])+mp.mpf('1e-70');row.update({'epsilon':e0,'a':a0,'hatted_limit_share':fmt((1-mp.exp(-av))/6),'root_limit_share':fmt(mp.exp(-av)/6)});paths.append(row)
print('STAGE NFP '+role+' all joint paths complete',flush=True)
out={'schema':'NFP1_FINITE_SOURCE_WARD','role':role,'source_support_audit':aud,'source_triangle_unit':str(unit),'source_vector_phase':str(phaseV),'source_auxiliary_phase':str(phaseH),'one_Nambu_source_Euler_legs':2,'colors':colors,'nonminimal_filtered_current_inverse_identity':True,'ordered_Clifford_Ward_identity':True,'constant_rho_PP_Jacobian_zero_by_field_degree':True,'rhoJB_color_trace_zero_by_actual_antisymmetry':True,'rhoJx_no_marginal_boson_scalar_path':True,'source0_imposed_only_after_derivatives':True,'IR_critical_separate_tadpole_split_rejected':True,'constants':constants,'source_dimensional_ratio':'1-epsilon/2','hatted_DIM_limit':'1/6','whole_actual_joint_limit':'1/6','root_hatted_separate_limits_do_not_commute':True,'rows':rows,'paths':paths,'new_physical_scheme_or_full_chiral_QAP_measure_or_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
