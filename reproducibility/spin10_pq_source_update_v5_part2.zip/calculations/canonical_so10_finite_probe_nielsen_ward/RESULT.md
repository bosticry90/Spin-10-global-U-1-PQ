# NFP1: selected finite first-probe Ward group

October 25, 2026. Bounded result completed and checked under the live AGENTS.md
delegation, based on `6fab3086cf9f3dcfd0775e4d176cc9fbf0893ca2`.
Scientific acceptance and E5/A5 promotion have not been performed.

The missing source primitive has been calculated. Together with the earlier
ordinary probe response it obeys the reduced finite-cutoff first-variation
identity, and the **whole group has joint regulator-removal limit 1/6** in
the normalized units below. It is nonzero. The unmodified, previously fixed
kinetic counterterm cancels this selected finite coefficient. No new
coefficient or finite normalization was fitted.

## Exact scope and dependencies

This is the original unshifted SMA/CSW construction, one loop, parity-even
physical fermion two-point projection, external hatted momentum zero,
nonexceptional Euclidean momentum `q=p_E^2>0`, background `A=0`, and one
constant independent rho probe at a time. All positive-dimensional orbit,
mass and interaction insertions are at **formal grade zero**. This restriction
does not erase finite mass-dependent physics by local power counting, select
zero Yukawas as a physical benchmark, or establish the massive amplitude.

The full split physical/sterile fermion block, actual G source currents,
mixed vector/auxiliary inverse and source gradients are retained before
projection. Q_full remains curved; Ihat is unchanged and nonzero. The actual
fixed-reference assignment has `lambda=2`. A simultaneous lambda=1 kernel
pair is a mathematical diagnostic, not an alternative physical Ward identity:
co-varying only the u reference changes the ordinary C2 to C1 while the
rho-source primitive S2 stays unchanged.

The root reduction uses the inherited CSW full source-Hessian four-leg
identity and the complete target-cycle support argument. This is **an
operator reduction conditional on that qualified identity**, not a fresh
component replay of the full 835-field root trace. `RECORD.md`,
`DERIVATION.md` and `REVIEW.md` specify the analytic premises and tests.

## Why the source contribution is indispensable

The full actual G audit shows that its first gradients retain an omitted
anchor in this target; hence `(G,Gamma1)` vanishes after differentiation and
restriction. G has only the actual nonminimal source ports, not matter K
ports. This does not remove `Gamma_(rho K_P P)`: classical physical-fermion
Euler derivatives multiply a nonzero source primitive. Two conjugate
polarizations belong to the **one** physical Nambu source. There is no extra
copy, family trace or open-line determinant half.

The other nonzero classical Euler legs are BPP and xPP. Their associated
rho-J kernels do not contribute here: the affine insertion has no intrinsic
loop, the marginal JB contraction is an actual weighted antisymmetric
color trace, and Jx has no marginal a-x/B-x/Lambda-x reference path. The
rhoPP Jacobian term is absent by field degree in this projection. None of
these exclusions is a general measure theorem.

For `K(-p), C(k), f(p-k)` and `B(-k), barf(k-p), P(p)`, the routed internal
fermion propagator is `+i bar_slash(k-p)/R`. Literal even-vertex permutations
and a distinct Berezin calculation give the same source-triangle sign.
The vector and auxiliary phases multiply `WV` and `-H`. Their actual color
sum is `g10^2(CV-CH)`, and both Euler legs independently give
`2(CV-CH)=-CU`, where `CU=w_r^2 C_r/2` comes from the ordinary mixed inverse.
Here `w_0=eta_H`, `w_1=xi`; the physical Spin(10) Casimir is 45/8 times I16.

## Actual kernels and finite identity

Write `Q=k^2`, `R=(k-p)^2`, `c=2t`, and
`N=exp(gamma_E*epsilon)*(mu_R^2)^epsilon`. Normalization of the momentum
integral is the inherited FCP convention. The new source scalar kernel is

```
S_lambda = N integral exp[-c(lambda Q+R)]
                 (bar_k^2-k.p)/(Q^2 R).
```

Primary calculation integrates the literal barred Clifford/Gaussian
numerator. Replay uses `(Q+R-q)/2-hat_k^2`, retaining `(R-q)/(Q^2 R)`
as a common term. Splitting this into a separate 1/Q^2 tadpole and
1/(Q^2 R) bubble would create two critically IR-singular integrals. The
combined numerator has soft degree 3 at Q=0, and is integrable for D>=7/2.
The replay therefore introduces no arbitrary IR extension constants.

The direct mixed-PS insertion gives `H_lambda=-Hv_lambda`, with analytic
hat rank `-2 epsilon`. The actual nonminimal ending obeys

```
(Jrho G0)_B = i w^2 k/(4Q),
GuBB_mu,nu = -2i k_mu (Jrho G0)_B,nu G_Ca.
```

Both sides have two filtered Q edges, E_Q^2, at fixed reference. Paired
nonminimal roots are reduced with this equality before integration. The
remaining ordered fermion inverse has `D_R Gt_R=E_R I`; its defect E_R-1
produces the independently integrated root

```
A_lambda = N c^epsilon integral_0^(1/(lambda+1))
             (1-(lambda+1)y) y^(-epsilon) exp[-cq(1-y)] dy.
```

The unheated unit term removed here is an absolutely integrable odd
heat kernel of soft degree 3. A compact quadrature and an ordinary 1F1
formula give separate evaluations of A. The required Gamma normalization
of DLMF's normalized hypergeometric function is retained.

The checked identity is

**C2 - S2 = H2 + A2.**

C2 was already measured in FCP1 and was denied to the new native
calculations. Its comparison is late. The ordered Clifford identity and
both source Euler legs are checked before those comparisons.

The strict heat finite part of S2 is
`-gamma_E-log(cq)-log(3)`. Its dimensional analytic continuation is
`S_DIM=(1-epsilon/2) I_DIM`. Thus the independently obtained DIM-minus-heat
coefficient is **chi4+log(3/2)+1/2**, the same as for C2. Their shared finite
conversion cancels in the group without selecting chi4.

For 0<=epsilon<=1/4 and positive compact q/mu_R^2, the derivation and review
give the uniform bound

```
|H2+A2-H_DIM| <= N c^epsilon (10 epsilon+2cq),
H_DIM = N q^(-epsilon) Gamma(1+epsilon) Beta(2-epsilon,2-epsilon).
```

With c*mu_R^2<=1, N c^epsilon is bounded. Consequently the **whole group**
has joint limit 1/6 along arbitrary epsilon-log(c) paths. Separate limits
do not commute: along `cq=exp(-a/epsilon)`, the hatted and root shares tend
to `(1-exp(-a))/6` and `exp(-a)/6`. Dropping either term is invalid.

## Previously fixed candidate and finite freedom

Only after the new finite group and main verifier completed, review
authenticated PFJ's original F and the unchanged LFM kinetic program.
The other parts of that candidate require C, B, x or K_P and cannot enter
this selected rhoPP projection. The old F is `-w_r^2 C_r/12`; hence

```
i F + i CU/6 = 0.
```

Both chiralities/transposes and the zero complement agree across 1,024
matrix positions. Doubling the old candidate leaves 62 nonzero positions.
This is a new finite applicability test of a fixed candidate originally
constructed from bare local data. It shares the original action and
normalization premises; it is not an independent prediction of all old
source coefficients, complete restoration or proof of uniqueness.

In the selected scalar extension directions, finite baseline compatibility
requires `beta_u=beta_K`; their common value remains free. No complete
mixing-space classification, identification with kappa/b0, physical scheme
adoption, or value for chi4 has been made.

## Completed evidence and limitations

Main validation: 18 finite cases, nine joint paths, 100-digit arithmetic,
75 stored digits, 180 scalar comparisons and a 1e-40 scaled gate. Stored
primary/replay maximum discrepancy is 0; this is a finite numerical
agreement, not exact integration. Late FCP group residual is below 6.1e-75.
Sensitive omissions change 18 source-kernel cases, 21 hatted cases and all
27 root cases. Six epsilon=0 hatted controls are correctly insensitive.
Wrong root-node placement changes all 27 cases. The free-edge global order
control is insensitive here; eight earlier CSW wrong-order fixtures were
reauthenticated, not credited as fresh tests.

Primary/replay/verifier times after imports were
223.9280925/218.8935774/0.2909169 seconds; review took 1.3489016 seconds.
Their 113/110/1/2 sampled private-memory observations reached
68,673,536/69,111,808/393,216/51,859,456 bytes. These are sampled maxima,
not continuous peaks. The frozen 450-second native and 180-second review
caps, 8-GiB sampled allocation limit, 350-MiB launch floor and 12-MiB packet
limit held. The pre-report packet was 289,884 bytes. All four captures
report COMPLETED/native 0; no failed or incomplete NFP1 run is relabeled.
Preparation/validation/review bind 50/58/75 inputs; nine source copies
preserve exact executed source bytes. Main validation uses an explicit
file list, avoiding the previous increment's accidental binding of future
review drafts. The previous failure remains intact in its original folder.

Validation receipt SHA256:
`b228b34e929d16a610ec01300181739fa8d6bcb661138430b0cd57e979aa0ed0`.
Review receipt SHA256:
`5661d7dd6939ac553222c448dfcb5dce0f43a3ea54409822fba8dad07ec8398a`.
The fresh delegated E4 check returned native 0 with steps [0,0,0,0,0,2].
Historical custody remains exit 2, seven NOTPASS references. Authentication
is not scientific acceptance. Full captures and preservation checks are
also retained under the external `finite-probe-nielsen-ward-v1-2026-10-25`
control directory.

Shared action, source frames, hatted sewing conventions, inherited CSW
identity, software and AI author limit independence. An eight-spin Clifford
witness checks algebra, not a Hilbert space of noninteger dimension. No
external review, experimental validation, full massive amplitude,
nonconstant-probe theorem, full chiral QAP, measure/phase, causal physical
limit or E5/A5 completion follows. State113 and authority34/39 stay unchanged.
The supplied research assessment and five external references were already
reviewed in the preserved PVR1 reference intake; their older next-step
recommendation does not require repeating subsequently qualified work.

## Next smallest scientific question

Restore independent probe transfer in this first-variation identity. A
varying probe has two different bosonic momenta and two independent
physical-fermion momenta. Derive its ordered current/inverse relation,
source Euler endpoints and cutoff defects before expanding components.
The constant result and older bare p/q jets do not automatically supply
its finite connected-product or hatted extension. A valid ordered
reduction may avoid a large three-point tensor expansion; an incomplete
domain or indispensable new kernel must remain explicit if it does not.
