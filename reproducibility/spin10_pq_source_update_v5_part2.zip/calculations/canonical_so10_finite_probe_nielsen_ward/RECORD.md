# NFP1: complete selected first-probe finite Ward group

Freeze before computation, October25,2026, base6fab3086cf9f3dcfd0775e4d176cc9fbf0893ca2.
Question: what is the complete constant-rho physical-fermion first-variation
group at one loop, rather than the ordinary uPP primitive alone? The missing
rho KP P source kernel must be calculated independently, with both Euler
polarizations of the SINGLE physical Nambu source retained. This is the next
dependency after FCP1, not a claim about all chiral or physical quantum theory.

Original unshifted SMA/CSW, parity-even ordinary physical PP projection,
p_hat0,q=pE²>0,A0,constant independent rho0/rho1 one at a time, u0 after
source/probe differentiation. FORMALgrade0 in positive-dimensional orbit/
mass/interaction insertions. Generic Yukawas remain, other finite grades,
varying-probe transfers and multiple insertions stay outside this bounded
target. Reuse actual EPV/FCP bosonic inverse and CPS augmented master defect,
SMA physical/sterile mixing and GTT/PFJ hatted oriented sewing premises.
Q_full remains curved; Ihat is unchanged/nonzero, not assumed nilpotent.

Audit full actual G source ports/anchor degree before restrictions. At the
target (G,Gamma1)=0 only if every first G gradient has an omitted anchor.
Classical nonzero Euler legs are P kinetic plus BPP/xPP currents. Check that
Gamma_(rho JB) and Gamma_(rho Jx) cannot feed this projection: affine parts
have zero intrinsic loop insertion; marginal nonlinear JB color trace is
actual antisymmetric f contracted with a diagonal rho current, and Jx has
no compatible x/B or x/L reference edge. Retain Gamma_(rho KP P), not source0
block independence. Jacobian rhoPP must be excluded by actual field degree.

Calculate the source primitive from actual G currents V,H and source KCP
and BPP vertices. Derive ghost/fermion Wick signs by literal even-vertex
permutations and independent Berezin integration. Fix loop momenta BEFORE
phases: K(-p), C(k), f(p-k); gauge B(-k),barf(k-p),P(p); rho a(-k),B(k).
Thus the internal f propagator is +i bar_slash(k-p)/R, not -i at that momentum.
Keep B and Lambda contributions and physical/source frames separately.
Derive both source Euler legs using one source, not two duplicated K sources.

Compute the full scalar source kernel S_lambda with weight
exp[-c(lambda Q+R)]*(bar_k²-k.p)/(Q²R),Q=k²,R=(k-p)²,c2t.
lambda2 is the actual fixed reference. lambda1 only diagnoses co-variation.
Primary literal barred Clifford/Gaussian, replay rational numerator reduction
with a COMMON IR-safe combined moment. Do NOT split (R-q)/(Q²R) into two
separately critically singular integrals without defining their IR extension.
Keep internal hats with analytic rank-2epsilon and all nonlocal functions.

Independently calculate the direct hatted mixed-PS kernel and the ordered
cutoff root. Use the actual nonminimal endpoint identity BEFORE integration:
GuBB=-2i k_mu*(Jrho G0)_B,nu*G_Ca (orientation as DERIVATION), including all
auxiliary terms. It has TWO filtered Q edges on both sides. This collapses
the complete nonminimal rooted family in the CSW first-variation expression;
the remaining fermion adjacent inverse is D_R Gt_R=E_R I, with defect E_R-1.
Retain its full split P/S block before physical projection. Root kernel is
the positive-heat, derivative-adjoint ordered expression, not negative of a
desired Ward remainder. Verify closure by the actual complete1PI envelope,
the classical ending identity, and both ordered Clifford source Euler legs.

Target finite-cutoff identity is to be TESTED, not imposed on unknown source
or hatted coefficients. Compare the independently derived left group with
the direct hatted and edge-root kernels. Late FCP/PFJ comparisons are allowed
only after outputs. If root closure/domain is incomplete, preserve that exact
premise instead of calling the full group qualified. No arbitrary finite
counterterm coefficient may be adjusted to obtain equality.

18finitecases asFCP:lambda1/2,e0,.1,.2,cq .01,.2,1.5,q .5,2,5,muR²1.5.
Ninejointpaths foractual lambda2:e .1,.05,.025,a .5,1,2,cq=exp(-a/e),q2.
100digits/75stored,1e-40scaledcomparison. Prove group joint-limit bounds
for0<=e<=1/4,positive compact q/muR²,c muR²<=1, without assuming separate
hat/root limits commute. Numerical paths corroborate an analytic bound.
Retain shared finite normalization symbolically; no chi4,zeta,kappa,b0 choice.

Controls:omit/reverse/halve source Euler term; omit Lambda current; wrong
internal propagator momentum; omit hatted/edge-root terms, incorrect heat
length, omit physical-source gradient before J0; diagnose separately singular
IR split and swapped root order; report insensitive e0 and zero positions.
Freeze sources/inputs BEFORE sequentialP/R/V each450s afterimports, review180s,
8GiBsampledprivate/350MiBfloor/12MiBpacket. Explicit validation file list avoids
binding future review drafts. Preserve all failures/incomplete sources/captures.
Protect35659oldGitblobs,state113/34of39,custody2sevenNOTPASS. No agents/branch/
worktree/push/outreach/publication,scheme/foundation/benchmark adoption,
flavor/HB1C5 or E5/A5promotion. Goalactiveincomplete. Shared action,source
conventions,analytic reference,software/AIauthor limit independence.

Nielsen identities from enlarged BRST (Gambino/Grassi,hep-ph/9907254v3) and
cutoff BRST (1904.08231v3) guide the question, not this model's coefficients.
The present identity is a specific finite first-variation construction, not
the general SM Nielsen theorem or a quantum-measure/phase acceptance process.
