from pathlib import Path
from hashlib import sha256
import json,gzip,ast,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={};F=O.parent/'canonical_so10_probe_fermion_onejet';Z=O.parent/'canonical_so10_probe_vector_response';geo=load(R/'tools/portable_dh_v1/inputs.json.gz')['geometry']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='6fab3086cf9f3dcfd0775e4d176cc9fbf0893ca2'
m=read(F/'validation_preparation.json')['input_sha256'];zm=read(Z/'preparation.json')['input_sha256']
for role in ['primary','replay']:
 ip=F/(role+'_inputs.json.gz');tp=F/(role+'_tables.json.gz');zp=Z/(role+'_inputs.json.gz');assert H(ip)==m[str(ip)] and H(tp)==m[str(tp)] and H(zp)==zm[str(zp)]
 d,t,z=load(ip),load(tp),load(zp);assert d['names'][:len(geo['names'])]==geo['names'];data={'names':d['names'],'parities':d['parities'],'physical_G':d['physical_G'],'field_source_pairs':geo['field_source_h_k'],'base_names':geo['names'],'Tminus':d['Tminus'],'RB':t['RB'],'RC':t['RC'],'V_A_H':t['V_A_H'],'hatted_oriented_B_phases':t['B_phases'],'hatted_oriented_L_phases':t['L_phases'],'physical_f':z['physical_f'],'extraction':'ACTUAL_CLASSICAL_G_CURRENTS_FRAMES_AND_QUALIFIED_HATTED_SEWING_PHASES_NO_PFJ_AMPLITUDES_OR_MOMENTS'};dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for p in [ip,tp,zp,dst]:b[str(p)]=H(p)
for p in [F/'validation_preparation.json',Z/'preparation.json',R/'tools/portable_dh_v1/inputs.json.gz']:b[str(p)]=H(p)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V605.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for folder,ns in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_chiral_probe_support',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_probe_fermion_onejet',['DERIVATION.md','validation_receipt.json']),('canonical_so10_sourcequadratic_primitive_probe',['DERIVATION.md','validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_finite_constant_probe_fermion',['DERIVATION.md','RESULT.md','validation_receipt.json','review_receipt_v2.json','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['RECORD.md','DERIVATION.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':450,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_NFP1',len(b),flush=True)
