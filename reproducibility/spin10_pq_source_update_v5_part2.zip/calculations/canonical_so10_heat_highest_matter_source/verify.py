"""HMS1 complete source response and late extension of the fixed common family."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz');late=packed(HERE/'validation_control_inputs.json.gz')
for k in ['response','pieces','nonzero_counts','negative_controls']:assert P[k]==R[k],k
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
positions=0;emb={};ct_remainders={}
for group,orders in P['response'].items():
 for order,sides in orders.items():
  l=untab(sides['left']);r=untab(sides['right']);positions+=2*990*256
  for k in set(l)|set(r):zero(plus(l.get(k,ZERO),trans(star(l.get(k,ZERO)))));zero(plus(r.get(k,ZERO),trans(l.get(k,ZERO))))
assert positions==6082560
for order,power in [('g4','4'),('g3xi','3')]:
 emb[order]={};ct_remainders[order]={}
 for side,ts in [('left',T),('right',U)]:
  get=lambda group:untab(P['response'][group][order][side])
  assert not get('relative_chi4')
  assert table(get('dimensional_fixed'))==late['CMS_total'][side][power]
  assert not linear((get('heat_length_log'),ONE),(get('relative_log'),ONE))
  assert not linear((get('heat_total_fixed'),ONE),(get('relative_fixed'),ONE),(get('dimensional_fixed'),Q(-1)))
  X=list(map(dec,late['MSP_X']['X_'+side][power]));old=linear((ce(ts,f,X),Q(-1)));assert not linear((get('dimensional_fixed'),ONE),(old,ONE))
  fixed=linear((old,ONE),(get('relative_fixed'),ONE));rem=linear((fixed,ONE),(get('heat_total_fixed'),ONE));assert not rem
  emb[order][side]={'fixed_image':sparse(fixed),'length_log_image':sparse(get('relative_log'))};ct_remainders[order][side]=nz(rem)
  for part in PARTS:
   bits=P['pieces'][part][order][side]
   assert table(linear((unsparse(bits['proper_matter_source']),ONE),(unsparse(bits['proper_ghost_source']),ONE)))==table(get({'chi4':'relative_chi4','log3over2':'relative_log','fixed':'relative_fixed'}[part]))
for order in ORDERS:assert all(P['negative_controls'][order].values())
assert P['negative_controls']['tree_omit_ghost_source_Euler']>0 and P['negative_controls']['tree_extra_ghost_half']>0
assert d['PSF']==late['CHV_recipe']['relative_onejet_parents']['SRC']
assert late['CHV_recipe']['all_selected_onejet_and_vector_remainders_zero'] and not late['CHV_recipe']['full_source_or_background_functional_image_qualified']
recipe={'definition':'previous_common_CHV_family+actual_GSF_JCcc_comparison','previous_CHV_family':late['CHV_recipe'],'new_proper_ghost_source_coefficients':d['GSF'],'highest_source_images':emb,'all_three_selected_projection_remainders_zero':True,'new_term_has_no_sourcefree_cPP_cBPP_image':True,'parameters_left_symbolic':['z_psi','z_10','z_126','chi4'],'other_kappa_b0_uR_zeta_not_identified_or_selected':True,'full_source_or_background_functional_image_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_three_projection_family.json.gz').open('xb') as out:out.write(blob)
for obj in [P,R]:assert not any(obj[k] for k in ['independent_component_heat_integration','quantum_coefficient_fitted','primitive_read_to_fit_quantum_response','free_constant_selected','physical_scheme_adopted','full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_HIGHEST_MATTER_SOURCE_HEAT_RESPONSE_AND_COMMON_THREE_PROJECTION_FAMILY','elapsed_after_imports':time.perf_counter()-tick,'response_coefficient_positions_compared':positions,'all45_ghosts_990_pairs_both_chiralities_zero_complement_match':True,'reality_right_negative_transpose_checked':True,'actual_tree_source_cotangent_ghost_Euler_normalization_checked':True,'CMS_bare_plus_cycles_reassembled_independently_of_MSP':True,'relative_chi4_image_zero_without_selecting_chi4':True,'old_fixed_primitive_image_rederived_after_quantum_extraction':True,'common_selected_onejet_vector_highest_source_family_constructed':True,'all_selected_highest_source_remainders':ct_remainders,'nonzero_counts':P['nonzero_counts'],'negative_controls':P['negative_controls'],'family_sha256':digest(HERE/'selected_three_projection_family.json.gz'),'family_raw_sha256':sha256(raw).hexdigest(),'independent_component_heat_integration':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
