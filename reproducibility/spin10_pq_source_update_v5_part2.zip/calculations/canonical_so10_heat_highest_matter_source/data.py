"""HMS1 exact two-parent source cochain and finite-response IO."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import combinations
import json,gzip,sys,os,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
PAIRS=list(combinations(range(45),2));PARTS=['chi4','log3over2','fixed'];ORDERS=['g4','g3xi'];SIDES=['left','right'];ZERO=Mat(16,16)
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('HMS1_PEER_OR_PRIMITIVE_DENIED')
   if p.parent.name in ['canonical_so10_matter_source_primitive','canonical_so10_coupled_fermion_finite_counterterm','canonical_so10_complete_heat_vector_response'] and p.name.endswith('.gz'):raise PermissionError('HMS1_CORRECTION_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def table(tab):return [enc(tab.get(k,ZERO)) for k in PAIRS]
def untab(rows):
 assert len(rows)==990
 return {k:dec(m) for k,m in zip(PAIRS,rows) if m['entries']}
def sparse(tab):return [[a,b,enc(v)] for (a,b),v in sorted(tab.items()) if v.d]
def unsparse(rows):return {(a,b):dec(m) for a,b,m in rows}
def linear(*args):
 out={}
 for tab,z in args:
  for k,v in tab.items():out[k]=plus(out.get(k,ZERO),scale(v,z))
 return {k:v for k,v in out.items() if v.d}
def nz(tab):return sum(len(m.d) for m in tab.values())
def ce(T,f,M):
 out={}
 for a,b in PAIRS:
  v=scale(minus(minus(mul(T[a],M[b]),mul(M[b],T[a])),minus(mul(T[b],M[a]),mul(M[a],T[b]))),neg(II))
  for e,z in f[a,b]:v=minus(v,scale(M[e],z))
  if v.d:out[a,b]=v
 return out
def ghost(N,T):
 out={}
 for s,a,b,z in N:out[a,b]=plus(out.get((a,b),ZERO),scale(T[s],prod(II,Q(z))))
 return {k:v for k,v in out.items() if v.d}
def source_matrices(d,order,part,side):
 sg='ordinary' if order=='g4' else 'auxiliary';fac=ONE if order=='g4' else Q('xi')
 return [scale(dec(m),fac) for m in d['PSF'][sg][part][side]]
def finish(role,relative,pieces,dim,controls,tick,method):
 response={};counts={}
 for group in ['relative_chi4','relative_log','relative_fixed','dimensional_fixed','heat_length_log','heat_total_fixed']:
  response[group]={};counts[group]={}
  for order in ORDERS:
   response[group][order]={};counts[group][order]={}
   for side in SIDES:
    if group=='dimensional_fixed':v=dim[order][side]
    elif group=='heat_length_log':v=linear((relative['log3over2'][order][side],Q(-1)))
    elif group=='heat_total_fixed':v=linear((dim[order][side],ONE),(relative['fixed'][order][side],Q(-1)))
    else:v=relative[{'relative_chi4':'chi4','relative_log':'log3over2','relative_fixed':'fixed'}[group]][order][side]
    response[group][order][side]=table(v);counts[group][order][side]=nz(v)
 out={'role':role,'method':method,'elapsed_after_imports':time.perf_counter()-tick,'response':response,'pieces':pieces,'nonzero_counts':counts,'negative_controls':controls,'open_family_factor':'I3_no_extra_three_or_Nambu_half','actual_source_operation':'dM+i sumN*T','independent_component_heat_integration':False,'quantum_coefficient_fitted':False,'primitive_read_to_fit_quantum_response':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
