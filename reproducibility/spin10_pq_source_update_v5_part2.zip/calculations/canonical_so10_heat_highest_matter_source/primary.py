"""HMS1 actual CE/source Euler operation before comparison with any primitive."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');TL=list(map(dec,d['Y']['Tminus']));TR=[scale(trans(t),Q(-1)) for t in TL];f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
treeN=d['GSF_tree'];relative={p:{} for p in PARTS};pieces={p:{} for p in PARTS};controls={}
for side,T in [('left',TL),('right',TR)]:
 treeM=[scale(t,II) for t in T];cc=ce(T,f,treeM);gg=ghost(treeN,T);assert not linear((cc,ONE),(gg,ONE));assert nz(cc)>0 and nz(gg)>0
controls['tree_omit_ghost_source_Euler']=nz(cc);controls['tree_extra_ghost_half']=nz(gg)
for part in PARTS:
 for order in ORDERS:
  relative[part][order]={};pieces[part][order]={}
  for side,T in [('left',TL),('right',TR)]:
   M=source_matrices(d,order,part,side);mimage=ce(T,f,M);nimage=ghost(d['GSF']['g3' if order=='g4' else 'g2xi'][part],T);v=linear((mimage,ONE),(nimage,ONE));relative[part][order][side]=v
   pieces[part][order][side]={'proper_matter_source':sparse(mimage),'proper_ghost_source':sparse(nimage)}
   if part=='chi4' and side=='left':controls[order]={'omit_ghost_source_Euler':nz(nimage),'omit_proper_matter_source':nz(mimage)}
dim={}
for order,power in [('g4','4'),('g3xi','3')]:dim[order]={side:linear((untab(d['CMS']['cycles'][side][power]),ONE),(untab(d['CMS']['bare'][side][power]),ONE)) for side in SIDES}
finish('primary',relative,pieces,dim,controls,tick,'CE_commutator_source_cotangent_then_actual_ghost_Euler_and_independent_CMS_sum')
