"""HMS1 immutable raw proper sources and separate measured CMS insertion."""
from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_ghost_source_finite_comparison'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/heat-highest-matter-source-v1-2026-10-23');OLD=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-source-finite-comparison-v1-2026-10-23');READY=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/complete-heat-vector-response-v1-2026-10-23')
BASE='fa5b121f9aa61e53c7a6da840f2609a3a025d2a2';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/(name+'.json.gz');add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32671
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json']:add(PRED/n)
for n in ['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V554.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
for n in ['postcommit_seal.json','before_commit_seal.json','successful_index_gate.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for folder in ['canonical_so10_complete_matter_source_breaking','canonical_so10_matter_source_primitive','canonical_so10_proper_matter_source_finite','canonical_so10_complete_heat_vector_response']:
 for n in ['RESULT.md','DERIVATION.md','validation_receipt.json']:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 q=HERE/(n+'.source.txt')
 with q.open('xb') as f:f.write(raw)
 add(p);add(q)
ref=source('canonical_so10_ghost_triangle_field_insertion','qualified_reference_inputs')['reference_fields']['plane_f']
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables');psf=source('canonical_so10_proper_matter_source_finite',role+'_tables');gsf=source('canonical_so10_ghost_source_finite_comparison',role+'_tables');cms=source('canonical_so10_complete_matter_source_breaking',role+'_tables')
 from itertools import combinations
 assert cms['external_pairs']==[list(v) for v in combinations(range(45),2)]
 gz(HERE/(role+'_inputs.json.gz'),{'Y':{'Tminus':y['Tminus'],'H_new':y['H_new']},'plane_f':ref,'PSF':psf['source_matrices'],'GSF':gsf['finite_coefficients'],'GSF_tree':gsf['tree_QC'],'CMS':{'cycles':{s:cms[s] for s in ['left','right']},'bare':{s:cms['bare_'+s] for s in ['left','right']}},'outside_xi_in_GSF_and_CMS_already_present':True});add(HERE/(role+'_inputs.json.gz'))
cms=source('canonical_so10_complete_matter_source_breaking','primary_tables');msp=source('canonical_so10_matter_source_primitive','primary_tables');chv=source('canonical_so10_complete_heat_vector_response','selected_correction_family')
gz(HERE/'validation_control_inputs.json.gz',{'CMS_total':{s:cms['total_'+s] for s in ['left','right']},'MSP_X':{k:msp[k] for k in ['X_left','X_right']},'CHV_recipe':chv});add(HERE/'validation_control_inputs.json.gz')
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(READY/n)
assert read(READY/'readiness_result.json')['step_exits']==[0,0,0,0,0,2]
dump(CONTROL/'readiness_reuse.json',{'source':str(READY/'readiness_result.json'),'sha256':digest(READY/'readiness_result.json'),'same_goalturn_fresh_command_authenticated_not_repeated':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'HMS1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('HMS1_FROZEN',len(bind),'bindings',flush=True)
