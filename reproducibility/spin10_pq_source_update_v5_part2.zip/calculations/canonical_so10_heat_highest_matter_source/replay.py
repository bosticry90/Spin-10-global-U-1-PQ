"""HMS1 three graded endpoints and independent current collection."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');TL=list(map(dec,d['Y']['Tminus']));TR=[scale(trans(t),Q(-1)) for t in TL];f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
def endpoints(T,M):
 out={}
 for a,b in PAIRS:
  on_source=scale(minus(mul(T[a],M[b]),mul(T[b],M[a])),neg(II));on_field=scale(minus(mul(M[a],T[b]),mul(M[b],T[a])),neg(II));on_ghost=ZERO
  for e,z in f[a,b]:on_ghost=minus(on_ghost,scale(M[e],z))
  v=plus(plus(on_source,on_field),on_ghost)
  if v.d:out[a,b]=v
 return out
def ghost_current(N,T):
 bypair=defaultdict(list)
 for s,a,b,z in N:bypair[a,b].append((s,Q(z)))
 return {k:scale(combine([z for s,z in rr],[T[s] for s,z in rr]),II) for k,rr in bypair.items()}
relative={p:{} for p in PARTS};pieces={p:{} for p in PARTS};controls={}
for side,T in [('left',TL),('right',TR)]:
 cc=endpoints(T,[scale(t,II) for t in T]);gg=ghost_current(d['GSF_tree'],T);assert not linear((cc,ONE),(gg,ONE));assert nz(cc)>0 and nz(gg)>0
controls['tree_omit_ghost_source_Euler']=nz(cc);controls['tree_extra_ghost_half']=nz(gg)
for part in PARTS:
 for order in ORDERS:
  relative[part][order]={};pieces[part][order]={}
  for side,T in [('left',TL),('right',TR)]:
   M=source_matrices(d,order,part,side);mimage=endpoints(T,M);nimage=ghost_current(d['GSF']['g3' if order=='g4' else 'g2xi'][part],T);v=linear((mimage,ONE),(nimage,ONE));relative[part][order][side]=v;pieces[part][order][side]={'proper_matter_source':sparse(mimage),'proper_ghost_source':sparse(nimage)}
   if part=='chi4' and side=='left':controls[order]={'omit_ghost_source_Euler':nz(nimage),'omit_proper_matter_source':nz(mimage)}
dim={o:{} for o in ORDERS}
for order,power in [('g4','4'),('g3xi','3')]:
 for side in SIDES:
  tab={}
  for pair,aa,bb in zip(PAIRS,d['CMS']['bare'][side][power],d['CMS']['cycles'][side][power]):
   m=plus(dec(aa),dec(bb))
   if m.d:tab[pair]=m
  dim[order][side]=tab
finish('replay',relative,pieces,dim,controls,tick,'separate_graded_K_C_P_endpoints_and_grouped_ghost_Euler_current')
