# HMS1: complete selected K_PccP heat response and common three-projection family

Basefa5b121f9aa61e53c7a6da840f2609a3a025d2a2/main32671blobs. Wholegoal
ACTIVE/incomplete,state113/34of39 unchanged. CurrentgoalturnPROGRESSCHV/GSF.
RecoveractualGit/processes,AGENTS,V554,qualifiedsourceandoperatorreceipts.
Noagents/newbranch/worktree/push/publication/outreach/physicaladoption.

Question:derive the complete mass-independent,no-jet K_PccP heat response
from the actual source/cotangent operation and test whether the already
fixed common CHM/CHV family extends with the measured GSF J_Ccc coefficient.
The only local comparison parents are properKPcP(PSF) and properJ_Ccc(GSF).
Use both chiralities,all45 ghosts/990orderedpairs/all16x16 coefficients,
ordinaryg4 and lowerg3xi. The open-familyI3 is retained,no extra3 or half.

Derive the source cochain and J_C MATTER Euler term before quantum comparison.
Actual tree M=iT,N=-f must givezero;this fixes the orientation/ordered-pair
normalization without reading a quantum target. Primary uses CE commutators;
replay uses the three separately graded source,ghost and matter endpoint
contributions. The independently measured CMS bare+cycles supply Rdim.
No MSP/CFC/common correction target is read by scientific workers. Only the
late gate reads the fixed primitive and prior selected family. No unknown
quantum coefficient,sign,baseline or physical parameter is fitted.

Freeze eight source/copies,typed/source proof,immutable actual inputs,expected
evidence,negative controls and ceiling before workers. Complete all implicit
zeros and compare individual matter-source and ghost-source contributions.
Zero/nonzero heat components are permissible outcomes;do not impose a desired
fixedzero. Retain commonchi4 symbolically and restore the PSF outsidexi ONCE;
GSF lower tensors and CMS source input already contain xi. Three sequential
stages600safterimports,8GiB sampledprivate,350MiB launch floor,16MiB packet.
Reuse thisgoalturn's freshCHV E4 honestly,newbyte/processpreflight. Stop first
failure,preserve full sources/captures;version repairs only. Validate then
passing before/index/after gates for local commit.

Ceiling:common selected onejet/vector/KccP finite family if all tests pass,
not full source-functional or chiral restoration. Scalar,JCccc/background/
hatted/positive-mass,multipleproducts/QAP,measure/phase,physicalchiral scheme,
massiveC1,E5/A5/GUT remain unqualified. Keep all finite freedoms and protected
adverse scalar points,quartetFAIL,flavorpause,HB1/C5blocks,custody2/seven.
Shared action,coefficient archives,analytic assumptions,helpers and AI author
are common-error limits,not independent science or experimental confirmation.
