# HMS1: the ghost-source Euler column is necessary

Prospective derivation;native calculations and separate gate required.

## Complete local parents and analytic domain

The target K_P C C P has gh1,dimension5,one even physical Nambu source,
two odd ghosts and one odd matter field,with no derivatives. For a dimension4,
ghost0 local comparison functional,the only parents are K_P C P and J_C C C.
Field-only parents have source-independent classical field flows and cannot
create K_P. The vector/scalar/antighost/auxiliary source Euler columns contain
no K_P term:the classical physical qP depends only on C and P. Multi-source
or higher-field parents exceed dimension4 or retain unallowed fields/sources.
The inactive sterile source has no vertex. Positive-mass/hatted derivatives
belong to other targets. This is an actual source-Hessian classification,
not an assertion that every source-functional component is now included.

CSW/CHM supply the complete one-variation Gaussian/source identity and stable
physical external ideal,with actual SMA hatted defect kept. The joint Schwartz
domain also allows one external K_P:its sourceHessian vertex retains a labeled
transfer,and does not introduce a new unlabelled constant fermion mass chain.
Thus the finite-part comparison Rheat=Rdim-bSigmaCrel applies here. CMS supplies
the independent complete32-support dimensional input,including six paired
physical/sterile zeros,the quartic ghost family and ordinary/mixed cycles.
The input is reassembled as bare+cycles before consulting any primitive.

## Source signs and two actual endpoint descriptions

Use source-left Sigma=...+K_P ig C^a T_a P,QC_s=-g f_ab^s C_aC_b(a<b).
The source/cotangent operation has highest-source part

 bK_P=-ig K_P C^a T_a,
 bC_s=-g f_ab^s C_aC_b,
 bP=ig C^a T_a P.

These are statements about bSigma,not a change of the elementary qK0 rule.
Odd-left variation of Gamma_M=K_P C^a M_a P gives g*K_P(dM)_ab C_aC_bP,

 dM_ab=-i([T_a,M_b]-[T_b,M_a])-sum_s f_ab^s M_s.

Independently,the three direct endpoint groups are
 -i(T_a M_b-T_b M_a),
 -sum_s f_ab^s M_s,
 -i(M_a T_b-M_b T_a).
Their sum gives the same cochain without rearranging noncommuting matrices.
The actual opposite chirality uses U=-T.T and its own proper M_R,not a
special antisymmetric-source approximation.

The full ghost-source Euler column contains

 bJ_C,s|matter=+ig K_P T_s P.

For the actual ordered source coefficient Gamma_N=J_C,s N_s,ab C_aC_b,
moving P through the two ghosts has positive sign. Its target contribution
is +ig K_P(sum_s N_s,ab T_s)C_aC_bP. There is NO extra1/2. The actual tree
M_a=iT_a,N_s,ab=-f_ab^s obeys dM+iNT0. Test it before the quantum amplitudes;
omitting the ghost-source Euler term or using a half fails this unit.

The complete local comparison image is therefore dM+iNT. PSF ordinaryg3
and GSF ordinaryg3 produceg4;their lowerg2xi families produceg3xi. Multiply
the factored PSF auxiliary M byxi once. GSF's lower N and CMS already contain
xi and must not be multiplied again. No new Yukawa proper-source class exists
in this dimension-zero1PI incidence domain;familyI3 remains symbolic.

## Quantum response and the common family

Keep relativechi4/log(3/2)/fixed directions separate. Rheat,lengthlog is
minus the derived relativelog image;Rheat,fixed=Rdim-relativefixed. A fixed
zero is a possible calculated result,not an imposed acceptance condition.
The complete relativechi4 image must satisfy actual UV compatibility with
the already qualified field/source poles,without fixing chi4.

Only after native response packets agree,read the old MSP primitive X,
whose source correction is -K_P C X P. Its highest-source image is -dX and
was fixed before this finite comparison. New field-only CFC corrections do
not affect K_PccP. Define the extension of the common CHV family by adding
the actual measured GSF J_Ccc comparison. Its image is old_MSP_image plus
the calculated dM+iNT. Test its sum with the independently computed heat
response coefficientwise. The added J_Ccc term has no source-free cPP or
cBPP image at sources0,so the earlier two projections remain the same common
functional. Keep the earlier zpsi/z10/z126/chi4 freedoms unselected.

This is a common THREE-selected-projection theorem if it succeeds,not the
full source functional. In particular a KccP component need not be CE-closed
in isolation when coupled ghost-source JCccc breaking remains. Do not impose
an unproved isolated closedness condition or infer complete nilpotence from
these selected results. Scalar/local-background,positive-mass/hatted,
multiple-insertion,measure/phase and physical renormalization remain separate.
