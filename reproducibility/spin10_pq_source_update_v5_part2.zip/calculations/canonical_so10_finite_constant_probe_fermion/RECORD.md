# FCP1: actual finite constant-probe physical-fermion response

Freeze before computation, October25,2026, based51742f868decda2a2c625d6752d827a7e9fc197.
Previous goal turn PROGRESS. Question: what is the complete nonexceptional
finite response with one constant even probe u and two physical fermion mean
fields in the actual fixed-reference heat construction? Does co-varying the
reference instead omit a finite term? This is the next actual chiral connected
building block after the selected closed-loop quadratic joint comparison.

Scope: original unshifted SMA, parity-even open physical fermion inverse
two-point coefficient, p_hat0,q=p_E²>0,A0, other external mean fields/BV sources0
AFTER extracting this uPP derivative. Constant probe transfer0 is explicit.
Take FORMAL DEGREE0 in all positive-dimensional interaction/orbit/mass
insertions, not the entire massive amplitude or a new zero-Yukawa benchmark.
No inverse-q argument discards positive-dimensional finite physics: those
other formal grades remain uncalculated. Generic Yukawas remain in the action;
their free scalar propagation has no marginal u insertion at this grade.

Reuse actual qualified EPV marginal quadratic symbols/zero ghost/scalar
blocks and FHK/SMA open-line phase/normalization. Re-derive full fixed-cutoff
inverse variation -E G0 U E G0 with all BB/BL/LB/LL blocks before matter
endpoints, and prove why only BB connects this target. Saturated1PIone-loop
degree2-vertex argument excludes nonlinear u aCB vertices without declaring
their amplitudes zero generally. Actual GuBB=+w² kk/(2Q²) must follow from
the full matrices; w=eta_H on12 and xi on33. No new fermion-Lambda vertex.
Use actual classical Tminus and H_new, compute color CH,CM by two routes;
no extra family3 or Nambu half on this open line.

Primary: literal barred gamma numerator and critical D-sphere moments, with
full internal dimensionD=4-2e/barredrank4. Fixed-reference heat weight has
two boson edges and one fermion edge exp[-c(2Q+R)],c=2t,Q=k²,R=(k-p)².
Derive exact finite-epsilon Schwinger/Gaussian amplitude. Compare co-varied
reference weight exp[-c(Q+R)] independently, without using it as the answer.
For Q^-2 the correct repeated-edge proper-time weight is alpha-lambda*c,
alpha>=lambda*c, lambda2fixed versus1co-varied. Derive rather than assume.

Replay: first cancel the exact rational numerator into scalar bubble, shifted
odd tadpole, vector moment and internal-hat moments; integrate those pieces
separately, preserving positive heat. At e0 hats vanish, at e>0 they do not.
Derive its dimensional beta/Gamma ratio and full heat finite constant from
the actual moving lower face. Primary critical symbol and replay exact
off-shell constants must give the same dimensional-minus-heat coefficient.
Only after independent outputs compare old FHK lambda1 and its color data.
Unknown lambda2 finite coefficient is never fitted to a Ward image.

Numerics100digits/75stored,1e-40scaledagreement,9cases per lambda1/2:
e0,.1,.2;z=cq .01,.2,1.5; q .5,2,5 respectively,muR²1.5. Exact nonlocal
parameter functions retained, not replaced by a local logarithm alone.
Prove heat asymptotic error O(z*(1+abs(logz))) at e0 by compact v>=lambda/(lambda+1),
incomplete-gamma recurrences and E1 remainder; no q0 or joint e/t theorem
inferred. Derive dimension dependence before e0 so evanescent finite terms
remain. n_log/chi4/zeta/kappa/b0 and finite baselines symbolic/unselected.

Controls: co-varyreference without Rt transport, wrong alpha weight, omit
shifted odd heat term, omit internal hats, discard first external heat jet,
extra open-line half/family3, erase auxiliary slots before inverse, replace
actual H projector by an averaged width. Record insensitive e0/zero positions.
Acceptance: full matrix/pole/finite/nonlocal route agreement with exact
asymptotic proof, complete typed support and actual regulator variation;
not a desired zero. Mismatch/underdefinition/incomplete preserved explicitly.

Freeze inputs/sources before sequentialP/R/V, each300safterimports,8GiBsampled
private,350MiBlaunchfloor,12MiBwholepacket. Preserve failed/incomplete attempts,
no silent cap changes. Existing same-turn E4 from SBJ can be authenticated
because old bytes/policy unchanged; not a new scientific replay/acceptance.
Protect all35612oldblobs,state113/34of39,custody2sevenNOTPASS. No agents,
branches/worktrees,push/outreach/publication,physicalscheme/benchmark/foundation
adoption,flavor/HB1C5 or E5/A5promotion. Sharedaction/analyticreference/library/
AIauthor limit independence. Goalactive/incomplete. Primary mathematical
standards DLMF8.7.3/5.12.1 and old actual FHK are comparators, not coefficient fits.
