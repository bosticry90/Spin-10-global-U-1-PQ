# FCP1: a finite fermionic probe response and its regulator transport

## Qualified bounded result

The actual constant-even-probe, two-physical-fermion response has been
calculated with its fixed-reference heat factors. Its dimensional-minus-heat
relative coefficient is

    chi4 + log(3/2) + 1/2.

The corresponding co-varied-reference response has coefficient chi4+5/12.
The actual fixed-minus-co-varied heat amplitude therefore has finite limit
-log(3/2)-1/12. The difference follows from the regulator variation and two
independently derived integrals; it is not assigned from a desired Ward zero.

This is an actual finite probe-connected building block beyond the earlier
bare local calculation. It does not qualify the full probe Slavnov group,
source products, physical renormalization scheme, quantum measure or E5/A5.

## Exact scope, support and normalization

Base d51742f868decda2a2c625d6752d827a7e9fc197/main, October25,2026.
Original unshifted SMA, parity-even physical fermion inverse two-point
coefficient, p_hat0,q=p_E²>0,A0, constant probe transfer0. Other mean fields
and BV sources are restricted only after extracting this ordinary uPP target.
The result is FORMAL DEGREE0 in positive-dimensional interaction/orbit/mass
insertions. Positive-dimensional finite contributions can involve inverse q;
they are not excluded by local dimension counting and remain uncalculated.
This is not a new massless physical benchmark or an adopted zero-Yukawa model.

Actual EPV marginal symbols and their complete ghost/scalar quadratic zeros,
SMA free physical/sterile prescription, and FHK's open-line phase and Gaussian
normalization are authenticated inputs. They are not newly rederived action
or phase theorems. The full vector/auxiliary inverse is retained before matter
endpoints. For each color and general k, the new calculation obtains

    Gu=-G0 U G0,
    GuBB=+w² k_mu k_nu/(2Q²), GuBL=-w k_mu/Q,
    GuLB=+w k_nu/Q, GuLL=-2, Q=k².

There is no ordinary Lambda-P-P vertex. Thus only BB survives the actual
matter endpoints of this target. Scalar marginal probe quadratic0 excludes
the Yukawa loop's probe response at this formal grade, while generic Yukawas
remain in the action. Nonlinear u aCB vertices have internal degree3 with no
permitted extra external label and cannot enter this one-loop1PI cycle:
E=V and minimum internal degree2 force every vertex's internal degree2.
These statements do not exclude source/KP descendants or other field grades.

Near k0 the actual numerator is O(k²), giving soft degree2 after Q²R;
near k=p its constant numerator vanishes, giving soft degree at most1.
This justifies the individual nonexceptional integral near epsilon0. It does
not justify a constant-probe diagonal pullback of a whole source-product theorem.

## The reference variation determines the heat placement

At fixed reference, Rt=K0(E^-1-1), E=exp(-cQ),c=2t, gives
deltaGt=-E G0 U E G0=E² Gu. Co-varying K0 changes Rt and gives E Gu.
Their difference is (E²-E)Gu, derived on full matrices before the integral.
At these matter endpoints only, the co-varied BB change matches a width
derivative; its BL/LB/LL change is not the ordinary width derivative.

The fixed-reference loop has TWO bosonic heat edges plus one fermion heat
edge: exp[-c(2Q+R)],R=(k-p)². The co-varied comparator has exp[-c(Q+R)].
It is wrong to use the comparator as the fixed-reference response without
the regulator transport. No isolated inverse-heat continuum trace is used.

In inherited common i*bar_slash(p)/(16pi²) inverse-propagator units, let
lambda=2 for fixed reference and1 for the comparator. The numerator is

    N_mu=(bar_k²-2k.p)bar_k_mu+bar_k² p_mu.

A literal barred Clifford calculation derives it from
bar_slash(k)bar_slash(k-p)bar_slash(k). Bar rank4 stays fixed; D=4-2epsilon
and internal hats are retained until dimensional integration. There is no
closed-fermion spin multiplicity or family3 factor on this open line.

For Q^-2 the proper-time weight is alpha-lambda*c, alpha>=lambda*c,
with beta>=c. Setting s=alpha+beta,x=beta/s gives
s0=c*max(lambda/(1-x),1/x), split at x=1/(lambda+1). The shifted barred
Gaussian numerator is p_mu[(1+3x)/s-q*x²(1-x)]. DERIVATION.md records the
resulting exact finite-epsilon incomplete-gamma integral. This full nonlocal
function is retained, not replaced by a logarithm or local polynomial.

The independent route cancels the rational numerator before integration:

    N_mu/(Q²R)=k_mu/Q²+p_mu/(QR)-q k_mu/(Q²R)
                                -hat_k²(k_mu+p_mu)/(Q²R).

It integrates the scalar/vector/hat terms and the denominator-cancelled
shifted odd heat integral separately. That odd term is positive and nonzero;
it cannot be discarded as an undamped odd tadpole. Analytic hat rank=-2epsilon,
not a finite matrix witness dimension, supplies the separate hat contribution.

## Finite constants, model colors and comparison

The independently recovered dimensional ratio is

    C_DIM/I_DIM=(epsilon²-6epsilon+6)/[2(3-2epsilon)],
    I_DIM=exp(gamma_E epsilon)(mu_R²/q)^epsilon
                           Gamma(epsilon)Beta(1-epsilon,1-epsilon).

Its pole coefficient is1 and its finite difference from the scalar bubble
is -1/3. At strict epsilon0 the complete heat constants are

    C1=-gamma_E-log(cq)+1/4-log2+O(cq*(1+abs(log(cq)))),
    C2=-gamma_E-log(cq)+1/6-log3+O(cq*(1+abs(log(cq)))).

One route derives the finite comparison from the literal critical D-sphere
unit 2/D+12/[D(D+2)] and the first external heat jet. The other derives these
absolute constants by integrating the actual moving Schwinger faces. The
negative dimension jet is2/3; the two heat jets are1/4 and1/6. Both give the
displayed relative coefficients. The earlier scalar-bubble convention chi4
is kept symbolic, with the SBJ auxiliary scale reparametrization retained;
no n_log,chi4,zeta,kappa,b0 or physical finite baseline is selected.

The action's model coefficient multiplying C2 is g10²*w_r²*C_r/2:
w0=eta_H,w1=xi, C_H=sum_ab(H_new H_new^T)ab TaTb, C_M=C_F-C_H,
C_F=(45/8)I16. Direct projector contraction and independently rotated H-basis
sum of squares agree. C_H/C_M have15/16 nonzero matrix positions per
chirality, respectively. General family identity is retained without an
extra factor3. Color Hermiticity and all12 H commutators pass. Conjugate
right color follows the inherited transpose; diagonal color reality here
does not test arbitrary noncommuting source conjugation.

## Verification, failure preservation and scientific limits

All18 finite kernels (lambda1/2, nine epsilon/heat cases each) agree at the
stored75digits after100digit work, against the frozen1e-40 scaled gate.
The reported stored discrepancy0 is not a claim of exact numerical integration.
Four additional small-heat checks pass. Exact recurrences and positive bounds
give |remainder|<=16z(1+abs(logz)),0<z=cq<=1/10, for both lambdas.
This is a strict heat-endpoint bound, not a joint-epsilon theorem for this
new three-edge primitive or an exceptional/physical-vacuum limit.

Omitting the shifted odd term changes18cases; omitting internal hats changes12
and is correctly insensitive in six epsilon0 cases. Wrong alpha weight changes
all18. Removing auxiliary inverse entries changes25 generic matrix positions.
Averaging H/M projectors changes32 actual color positions. Extra open-line
half/family3 changes31 nonzero color positions; deleting the heat jet changes
both scalar units. Controls do not prove full chiral measure or source signs.

P/R/verifier completed128.2291150/125.6376869/.2759265seconds after imports;
review V2 completed.3974971seconds. Native/verification caps300s,review180s,
8GiB sampled-private,350MiB launch floor,12MiB packet held. Samples65/64/1/1,
sampled private maxima63,193,088/64,155,648/393,216/798,720bytes are not
continuous memory peaks. Preparation/validation/reviewV2 bindings46/57/74;
ten source copies plus three actual failed-attempt source copies retained.

One review preparation failure remains FAILED. The main verifier had frozen
review drafts present while native work was running; I subsequently amended
them under an incorrect assumption that they were not yet bound. The V1 review
controller rejected the changed hash BEFORE any review worker/source freeze.
All actual rejected sources are preserved. The original drafts were restored
only after their reconstructed bytes matched the original hashes; no manifest
or recorded hash was refreshed. V2 executes the amended review under distinct
paths. P/R/verifier calculations were unchanged and were not rerun. See
REVIEW_RECOVERY_V2.md and review_failed_attempt_sources.json. The launcher’s
complete decoded tool output and controller traceback are preserved; a separate
raw launcher stream had not been captured and is not claimed. The new native
worker captures are complete. This is an avoidable orchestration error, not
a failed physics calculation or evidence against the finite kernel.

Validation receipt SHA256
b2c67df5f34c5fbd80cd47c54ac8893c645d70bc9b4c725087546aa23797cee0;
reviewV2 receipt162e8bd8dfa8e17cf4787054f6c0c48a88cfab39ca4b67a0ee29cd0b8718a190.
Fresh E4 native0,steps[0,0,0,0,0,2]; custody remains exit2/sevenNOTPASS,
not scientific acceptance. External captures/before/index/postcommit seals:
C:/Users/psboy/.codex/research-control-records/ToE-Next/finite-constant-probe-fermion-v1-2026-10-25/.
All35612 prior Git blobs and state113 remain protected. The routes share
action/reference/phase premises, classical data, special-function algorithms,
Python/SymPy/mpmath and AI author. Agreement is internal corroboration, not
external scientific/experimental validation. DLMF gamma/beta identities and
the qualified old FHK lambda1 result are mathematical normalization standards.

## Next meaningful action

Use this primitive in the actual FIRST-PROBE finite Ward projection, rather
than naming its finite transport the whole Slavnov correction. Derive the
complete constant-rho,two-physical-fermion group from CSW's full source-Hessian
congruence and the augmented probe action. Keep dGamma/du, ordinary and BV
Euler legs, direct Ihat insertion, ordered regulator roots and any reference
variation distinct. Determine support/IR bounds before evaluating new kernels;
do not assign a missing rho coefficient from the negative of this answer.
The numerical similarity to earlier heat-length contacts is a comparator,
not proof that those terms complete the identity.

Varying probes, independent transfers,KP descendants, positive-dimensional
finite grades, massive matching, arbitrary backgrounds, chiral trace/products,
measure/phase,QAP,causal/physical-vacuum limits and E5/A5 remain open. Unprobed
Ihat is nonzero and Q_full curved. State113/34of39 unchanged, state SHA
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
No physical scheme, benchmark, action or foundation changed; flavor/HB1/C5
remain paused/blocked. Whole Spin(10)xPQ goal ACTIVE and INCOMPLETE.
