# Prospective complete finite constant-probe kernel

Reuse actual EPV marginal U and free G, retain all mixed blocks. At a unit
longitudinal momentum each color has G0=[[w,-1],[1,0]],
U=[[-2,w],[-w,w²/2]]. At general k the vector/auxiliary weights restore
Gu=-G0 U G0 with BB=+w² kk/(2Q²), BL=-w k/Q,LB=+w k/Q,LL=-2.
Only B has an ordinary marginal physical-matter cubic current at the target;
there is no Lambda-P-P vertex. Ghost/scalar marginal uquadratics are qualified
zero. All source derivatives are extracted before imposing their absence in
THIS ordinary uPP target; KP/source descendants remain separate.

At fixed reference Rt=K0(E^-1-1),E=exp(-cQ),deltaGt=-E G0 U E G0.
Co-varying K0 changes Rt too and gives -E G0UG0. Their difference is
E(1-E)G0UG0, not permission to replace two heat factors by one. After the
actual matter endpoints this is the same longitudinal numerator with the
difference of lambda2/lambda1 heat weights. Finite-mode algebra precedes
continuum expressions; no inverse heat is used as an unbounded trace.

In common i*bar_slash(p)/(16pi²) inverse-propagator units the actual numerator
after FHK's fixed open-line convention is

 N_mu=(bar_k²-2k.p)bar_k_mu+bar_k² p_mu,
 C_lambda(e,c,q)=Nnorm integral e^[-c(lambda Q+R)] N_mu/(Q²R) /p_mu,
 Nnorm=exp(gammaE e)muR²^e, D=4-2e.

The polynomial is gamma_bar(k)gamma_bar(k-p)gamma_bar(k), not a full-dimensional
spinor trace. Analytic hats enter the Gaussian dimension and rational Ward
decomposition; do not set bar_k²=Q before integration.

Schwinger alpha>=lambda*c,beta>=c,weight(alpha-lambda*c),s=alpha+beta,
x=beta/s,k=l+xp. Then s>=s0=c*max(lambda/(1-x),1/x),splitx=1/(lambda+1).
The actual barred Gaussian numerator is p_mu[(1+3x)/s-q*x²(1-x)].
Set u=x(1-x),Delta=qu,b=1+3x,a=(1-x)b,
Jn=Delta^(-e-n)Gamma(e+n,Delta s0). The direct scalar coefficient is

 C_lambda=Nnorm integral[a J0-lambda*c*b Jminus1-q*u² J1
                                         +lambda*c*q*x*u J0]dx.

Independent unshifted cancellation gives

 N_mu/(Q²R)=k_mu/Q²+p_mu/(QR)-q k_mu/(Q²R)
                           -hat_k²(k_mu+p_mu)/(Q²R).

The shifted odd term has its own denominator-cancelled heat domain:

 A_lambda=Nnorm*c^e integral_0^(1/(lambda+1))
                 (1-(lambda+1)y)y^-e exp[-cq(1-y)]dy.

Remaining coefficients are I=Nnorm integral J0,
qJ=Nnorm*q integral[u J1-lambda*c*x J0],
Hsum=-e*Nnorm integral(1+x)[(1-x)J0-lambda*c*Jminus1].
Thus C_lambda=A_lambda+I-qJ-Hsum. The hat rank is h=-2e, not the number of
explicit witness matrices. A does not vanish as an odd tadpole with heat.

At c0 use dimensional analytic continuation, not divergent heat integrals
evaluated at0. The ratio C_DIM/I_DIM follows from beta integrals of
a-eu. I_DIM=Nnorm*q^-e Gamma(e)Beta(1-e,1-e). Derive the ratio and its
epsilon0 finite term before comparing to FHK. Primary separately Taylor
averages the literal numerator over D-sphere and retains the first heat jet
on the odd power symbol. Their pole/dimension/heat finite data must agree.

At strict e0, using incomplete-gamma recurrences with v=max(lambda*x,1-x),

 C_lambda=-gammaE-log(cq)+H_lambda+O(cq*(1+abs(log(cq)))),
 H_lambda=-integral a*log(v)dx
          -lambda*integral b/max(lambda/(1-x),1/x)dx -integral u dx.

Derive H1 and H2 by actual split integrals, not by adjusting known constants.
The functions v are bounded away from0. Recurrence expressions have the
form [a+O(cq)polynomial]E1(cqv)-[lambda*b/h+u]exp(-cqv), with finite
integrable coefficients. E1+gamma+log=O(cqv) and |exp(-cqv)-1|<=cqv
give the stated uniform compact-q remainder. No endpoint/small-mass physical
limit or simultaneous chiral source-product theorem is implied.

Model factor: g10²*(w_r²/2)*C_r on each chirality, C_H=sum_ab(P_H)ab TaTb,
P_H=H_new H_new^T,C_M=C_F-C_H. Replay rotates Ta to the12actual H columns
before summing squares. Reuse no kinetic quantum target in the contractions.
After completion, compare the old FHK scalar unit/color and actual EPV U.
No extra family3 or closed-determinant half on an open matter line.
