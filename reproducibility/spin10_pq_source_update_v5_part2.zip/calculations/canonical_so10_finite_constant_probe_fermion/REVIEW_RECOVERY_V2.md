# Review continuation after a pre-execution binding failure

The FCP1 P/R/verifier completed. While those workers were running, draft
REVIEW.md/review.py/run_review.py were authored. The main validation preparer
automatically bound every file then present, including these review drafts.
They were subsequently amended under an incorrect assumption that they were
not frozen yet. The V1 review controller caught the changed REVIEW.md hash
BEFORE launching any review worker or creating source copies/preparation.
review_failure.json remains FAILED; there is no V1 review receipt/capture.

All three actual failed-attempt source byte sequences are preserved as
*.attempt_failed.txt; review_failed_attempt_sources.json records their hashes
and the prior bound hashes. The original two draft files were reconstructed
from their prior text only after SHA256 matched the EXISTING validation
manifest, then restored byte-for-byte. No manifest, old hash or native output
was changed or rebound. The main P/R/verifier sources and calculations were
never modified. The amended review is now REVIEW_V2.md/review_v2.py, with its
own preparation/controller/capture/receipt paths. This is recovery of exact
frozen bytes, not replacement of historical policy or acceptance evidence.

V2 retains all scientific conditions, adds the intended explicit soft-support
and late EPV/FHK review, and preserves180s/8GiBsampled/350MiBfloor/12MiBcaps.
No primary/replay integral is rerun. The two mathematically equivalent
polynomial/matrix comparisons use simplified zero differences, authored before
their first review execution. No scientific assertion or tolerance is weakened.
No chiral source/QAP, scheme, benchmark, foundation or authority is promoted.
