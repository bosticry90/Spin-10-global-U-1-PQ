from pathlib import Path
from hashlib import sha256
import gzip,json,ast,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='d51742f868decda2a2c625d6752d827a7e9fc197'
F=O.parent/'canonical_so10_open_fermion_heat_kinetic';m=read(F/'preparation.json')['input_sha256'];b[str(F/'preparation.json')]=H(F/'preparation.json')
for role in ['primary','replay']:
 p=F/(role+'_inputs.json.gz');assert H(p)==m[str(p)];b[str(p)]=H(p);d=load(p);data={'Tminus':d['Y']['Tminus'],'H_new':d['Y']['H_new'],'extraction':'CLASSICAL_GENERATORS_AND_H_COLUMNS_ONLY_NO_KINETIC_QUANTUM_TARGET'};dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V604.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
for folder,ns in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_even_probe_vertices',['DERIVATION.md','RESULT.md','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz','validation_preparation.json']),('canonical_so10_probe_auxiliary_resolvent',['DERIVATION.md','RESULT.md','validation_receipt_v2.json']),('canonical_so10_open_fermion_heat_kinetic',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_chiral_scalar_bubble_joint_fp',['DERIVATION.md','RESULT.md','validation_receipt.json','review_receipt.json'])]:
 for n in ns:
  p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['RECORD.md','DERIVATION.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_FCP1',len(b),flush=True)
