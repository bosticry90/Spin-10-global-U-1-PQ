from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,sys,time,threading,os,math,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('FCP_PEER_DENIED')
  if p.parent.name in ['canonical_so10_open_fermion_heat_kinetic','canonical_so10_even_probe_vertices'] and('tables'in p.name or 'receipt'in p.name):raise PermissionError('FCP_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
load=lambda p:json.loads(gzip.decompress(p.read_bytes()));d=load(O/(role+'_inputs.json.gz'));dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v) for i,j,v in z['entries']});clean=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(clean(M).todok().items()) if v]};T=list(map(dec,d['Tminus']));HH=dec(d['H_new']);assert HH.shape==(45,12) and clean(HH.T*HH)==s.eye(12);PH=clean(HH*HH.T);CF=clean(sum((t*t for t in T),s.zeros(16)))
if role=='primary':CH=clean(sum((v*T[a]*T[b] for(a,b),v in PH.todok().items()),s.zeros(16)))
else:
 TH=[clean(sum((HH[a,j]*T[a] for a in range(45) if HH[a,j]),s.zeros(16))) for j in range(12)];CH=clean(sum((t*t for t in TH),s.zeros(16)))
CM=clean(CF-CH);assert CF==s.Rational(45,8)*s.eye(16) and clean(CH-CH.conjugate().T)==s.zeros(16) and clean(CM-CM.conjugate().T)==s.zeros(16)
TH=[clean(sum((HH[a,j]*T[a] for a in range(45) if HH[a,j]),s.zeros(16))) for j in range(12)];assert all(not clean(C*t-t*C).todok() for C in [CH,CM] for t in TH)
k=s.Matrix(s.symbols('k0:4'));p=s.Matrix(s.symbols('p0:4'));w=s.Symbol('w');Q=(k.T*k)[0];kk=k*k.T;G=s.Matrix.vstack(s.Matrix.hstack(s.eye(4)/Q+(w-1)*kk/Q**2,-k/Q),s.Matrix.hstack(k.T/Q,s.zeros(1)));U=s.Matrix.vstack(s.Matrix.hstack(-2*kk,w*k),s.Matrix.hstack(-w*k.T,s.Matrix([[w*w/2]])));Gu=clean(-G*U*G);expected=s.Matrix.vstack(s.Matrix.hstack(w*w*kk/(2*Q**2),-w*k/Q),s.Matrix.hstack(w*k.T/Q,s.Matrix([[-2]])));assert not clean(Gu-expected).todok();Gbad=G.copy();Gbad[:4,4]=s.zeros(4,1);Gbad[4,:4]=s.zeros(1,4);aux_bad=len(clean(-Gbad*U*Gbad-Gu).todok());E=s.Symbol('E');assert not clean((-E**2*G*U*G)-(-E*G*U*G)-E*(1-E)*G*U*G).todok()
D=s.Symbol('D',positive=True);ee=s.Symbol('epsilon');qq=s.Symbol('q',positive=True);chi=s.Symbol('chi4',real=True);x=s.Symbol('x',positive=True);normratio=(ee**2-6*ee+6)/(2*(3-2*ee));a=(1-x)*(1+3*x);b=1+3*x;uu=x*(1-x)
if role=='primary':
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];sk=sum((k[i]*gam[i] for i in range(4)),s.zeros(4));sp=sum((p[i]*gam[i] for i in range(4)),s.zeros(4));raw=clean(sk*(sk-sp)*sk);num=[s.expand(s.trace(gam[i]*raw)/4) for i in range(4)];assert all(s.expand(num[i]-((Q-2*(k.T*p)[0])*k[i]+Q*p[i]))==0 for i in range(4))
 def avg(z):
  out=0
  for pp,co in s.Poly(s.expand(z),*k).terms():
   if any(v%2 for v in pp):continue
   rr=sum(pp)//2;out+=co*s.prod(s.factorial2(v-1) for v in pp)/s.prod(D+2*j for j in range(rr))
  return s.factor(out)
 uD=avg(Q-2*k[0]**2+2*k[0]**2*Q);assert s.simplify(uD-(2/D+12/(D*(D+2))))==0;jet=s.simplify(-2*s.diff(uD,D).subs(D,4));pole=uD.subs(D,4);constants={}
 for lam in [1,2]:
  h=s.simplify(2*avg(Q*k[0]**2).subs(D,4)/(lam+1));rel=chi+s.log(s.Rational(lam+1,2))+jet-h;Hconst=s.simplify(s.Rational(2,3)-s.log(2)-(rel-chi));constants[str(lam)]={'heat_positive_jet':str(h),'relative':str(rel),'absolute_heat_H':str(Hconst)}
else:
 # Independent denominator-cancelled numerator, with h=-2epsilon moments.
 uD=2/D+12/(D*(D+2));jet=s.Rational(2,3);pole=s.Integer(1);assert s.simplify(s.Rational(1,2)+(3-ee)*(1-ee)/(2*(3-2*ee))-normratio)==0;constants={}
 for lam in [1,2]:
  split=s.Rational(1,lam+1);lnpart=s.integrate(a*s.log(1-x),(x,0,split))+s.integrate(a*s.log(lam*x),(x,split,1));boundary=s.integrate(lam*b*x,(x,0,split))+s.integrate(b*(1-x),(x,split,1))+s.integrate(uu,(x,0,1));Hconst=s.simplify(-lnpart-boundary);rel=s.simplify(chi+s.Rational(2,3)-s.log(2)-Hconst);constants[str(lam)]={'heat_positive_jet':str(s.Rational(1,2*(lam+1))),'relative':str(rel),'absolute_heat_H':str(Hconst)}
print('STAGE FCP '+role+' full inverse,actual color,numerator and exact constants complete',flush=True)
mp.mp.dps=100;fmt=lambda z:mp.nstr(z,75)
def calc(e,c,q,mu,lam):
 N=mp.exp(mp.euler*e)*mu**e;cut=mp.mpf(1)/(lam+1);interval=[mp.mpf(0),cut,mp.mpf(1)]
 @lru_cache(None)
 def kernels(x):
  u=x*(1-x);dl=q*u;s0=c*max(lam/(1-x),1/x);z=dl*s0
  return u,dl**(-e)*mp.gammainc(e,z,mp.inf),dl**(1-e)*mp.gammainc(e-1,z,mp.inf),dl**(-e-1)*mp.gammainc(e+1,z,mp.inf)
 def direct(x):
  u,j0,jm,jp=kernels(x);bb=1+3*x;return (1-x)*bb*j0-lam*c*bb*jm-q*u*u*jp+lam*c*q*x*u*j0
 def wrong(x):
  u,j0,jm,jp=kernels(x);return lam*c*((1+3*x)*jm-q*x*u*j0)
 if role=='primary':C=N*mp.quad(direct,interval);A=Hat=Iv=qJ=None;bad=N*mp.quad(wrong,interval)
 else:
  A=N*c**e*mp.quad(lambda y:(1-(lam+1)*y)*y**(-e)*mp.exp(-c*q*(1-y)),[0,mp.mpf(1)/(lam+1)]);Iv=N*mp.quad(lambda x:kernels(x)[1],interval);qJ=N*q*mp.quad(lambda x:kernels(x)[0]*kernels(x)[3]-lam*c*x*kernels(x)[1],interval);Hat=-e*N*mp.quad(lambda x:(1+x)*((1-x)*kernels(x)[1]-lam*c*kernels(x)[2]),interval) if e else mp.mpf(0);C=A+Iv-qJ-Hat;bad=None
 return {'C':fmt(C),'shifted_odd_A':None if A is None else fmt(A),'hat_sum':None if Hat is None else fmt(Hat),'bubble_I':None if Iv is None else fmt(Iv),'vector_qJ':None if qJ is None else fmt(qJ),'wrong_alpha_weight_difference':None if bad is None else fmt(bad)}
rows=[]
for lam in [1,2]:
 for e0 in ['0','0.1','0.2']:
  for z0,q0 in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
   ev,zv,qv=map(mp.mpf,[e0,z0,q0]);row=calc(ev,zv/qv,qv,mp.mpf('1.5'),lam);row.update({'lambda':lam,'epsilon':e0,'cq':z0,'q':q0});rows.append(row)
  print('STAGE FCP '+role+' lambda '+str(lam)+' epsilon '+e0+' finite complete',flush=True)
small=[]
for lam in [1,2]:
 hc=mp.mpf(1)/(2*(lam+1))-mp.log(lam+1)
 for z0 in ['0.00001','0.00000001']:
  z=mp.mpf(z0);row=calc(mp.mpf(0),z/2,mp.mpf(2),mp.mpf('1.5'),lam);error=mp.mpf(row['C'])+mp.euler+mp.log(z)-hc;assert abs(error)<=16*z*(1+abs(mp.log(z)));small.append({'lambda':lam,'cq':z0,'finite_constant_error':fmt(error),'bound':fmt(16*z*(1+abs(mp.log(z))))})
print('STAGE FCP '+role+' all nonlocal and smallheat tests complete',flush=True)
eta,xi,g=s.symbols('eta_H xi g10',real=True);colors={'CF':enc(CF),'CH':enc(CH),'CM':enc(CM),'probe0':enc(g*g*eta*eta*CH/2),'probe1':enc(g*g*xi*xi*CM/2)};out={'schema':'FINITE_CONSTANT_PROBE_FERMION_V1','role':role,'colors':colors,'u_D':str(uD),'pole':str(pole),'negative_dimension_jet':str(jet),'dimensional_ratio':str(normratio),'dimensional_finite_minus_scalar_bubble':'-1/3','constants':constants,'fixed_reference_two_boson_heat_factors_derived':True,'full_mixed_inverse_before_matter_endpoints':True,'generic_omit_auxiliary_inverse_positions':aux_bad,'averaged_projector_color_difference':len(clean(CH-s.Rational(12,45)*CF).todok())+len(clean(CM-s.Rational(33,45)*CF).todok()),'no_extra_open_line_family3_or_half':True,'formal_positive_dimension_degree0_only':True,'rows':rows,'small_heat':small,'full_chiral_sources_products_QAP_measure_or_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
