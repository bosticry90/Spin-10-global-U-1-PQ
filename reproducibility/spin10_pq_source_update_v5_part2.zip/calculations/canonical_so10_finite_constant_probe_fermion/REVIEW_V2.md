# FCP1 support, asymptotic and actual reference-transport review

Freeze before this dependent review. It runs only after native P/R and their
verifier have completed. No old action or new source is edited.

Review support in the explicitly stated formal positive-dimension grade0:
ordinary two-matter cubic vertices have B or x fluctuating partners. Scalar
marginal probe quadratic0 is inherited EPV, so only B/physical-fermion loop
can carry the insertion. Nonlinear marginal uvertices have internaldegree3
with no allowed extra external label, so cannot join a1PIone-loop cycle
(E=V,mininternaldegree2). This is not exclusion of positive-dimension finite
amplitudes, derivative-u terms, source/KP descendants or two-transfer products.
The full G0/U multiplication must precede projection to B endpoints.

For p²>0 the actual numerator is O(k²) near k0, while Q²R is O(k4),
so the local soft degree is2. At k=p its constant numerator vanishes,
leaving degree at most1 after the R denominator. Check these polynomial
facts before interpreting a constant probe. They justify this individual
nonexceptional integral near epsilon0, not a diagonal pullback of the full
Schwartz source-product theorem. Reauthenticate actual EPV ghost/scalar
quadratic zeros and the old FHK lambda1 fixed unit only after native outputs.

Check reference variation on full matrices: deltaGfixed=E²Gu,
deltaGcovaried=EGu and their difference=(E²-E)Gu. Thus the matter kernel
is precisely the lambda2-minus-lambda1 heat integral; its finite constant
must be derived from the completed two kernels, not a negative Ward target.
At these endpoints only, co-varied response has the same BB change as a
width derivative; its BL/LB/LL change is NOT the ordinary width derivative.

At e0 write h=max(lambda/(1-x),1/x),v=u*h and E1=Gamma(0,zv). Recurrences
give the complete integrand
[a+lambda*z*u*(b+x)]E1(zv)-[lambda*b/h+u]exp(-zv),
a=(1-x)(1+3x),b=1+3x,u=x(1-x). Forlambda1/2,v in[1/2,2],0<z<=1/10:
integral a=1, 0<=a<=4/3,lambda*u*(b+x)<=5/2,
lambda*b/h+u<=3, and lambda*b/h+u>=0. With
0<=E1(y)+gammaE+logy<=y and |exp(-y)-1|<=y,
the remainder is bounded by16*z*(1+abs(logz)). This proves the frozen
small-heat claim, rather than just fitting its numerical checks.

Check both relative constants and their difference from actual completed
outputs. Quantify discarded heatjet, extra openlinehalf/family3 and averaged
projector controls in addition to the earlier measured odd/hat/weight controls.
Right color is inherited transpose; diagonal reality here cannot test general
noncommuting source conjugation. The finite normalization remains free.
Caps180safterimports,8GiBsampled/350MiBfloor,12MiBwholepacket. Preserve failed
or incomplete captures; no full QAP/physical scheme or authority promotion.
