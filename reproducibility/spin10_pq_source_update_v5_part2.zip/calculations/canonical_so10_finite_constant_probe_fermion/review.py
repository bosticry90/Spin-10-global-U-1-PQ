from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
load=lambda p:json.loads(gzip.decompress(p.read_bytes()));p=load(O/'primary_tables.json.gz');r=load(O/'replay_tables.json.gz');v=read(O/'validation_receipt.json');assert v['actual_complete_fixed_reference_constant_probe_kernel_qualified'] and not v['full_chiral_source_products_QAP_measure_or_E5_A5']
x=s.Symbol('x',real=True);z,e=s.symbols('z epsilon',positive=True);a=(1-x)*(1+3*x);b=1+3*x;u=x*(1-x);assert s.integrate(a,(x,0,1))==1 and s.simplify(s.Rational(4,3)-a-3*(x-s.Rational(1,3))**2)==0
normpositions=sum(len(p['colors'][k]['entries']) for k in ['probe0','probe1']);assert normpositions>0
heatjet={};hconst={}
for lam in [1,2]:
 hconst[lam]=s.sympify(p['constants'][str(lam)]['absolute_heat_H']);heatjet[lam]=s.sympify(p['constants'][str(lam)]['heat_positive_jet']);assert heatjet[lam]!=0;split=s.Rational(1,lam+1)
 # Prove max v and inverse h bounds on each actual Schwinger face.
 for sample in [s.Rational(0),split,s.Rational(1)]:
  vv=(1-sample) if sample<=split else lam*sample;assert s.Rational(1,2)<=vv<=2
 # Elementary coefficient bounds used in REVIEW: x,u,b positive on[0,1].
 assert lam<=2 and lam*s.Rational(1,4)*5<=s.Rational(5,2) and lam*4/s.Rational(lam+1)+s.Rational(1,4)<=3
diff=s.simplify(s.expand_log(hconst[2]-hconst[1],force=True));assert s.simplify(diff+s.log(s.Rational(3,2))+s.Rational(1,12))==0
E,w=s.symbols('E w');G=s.Matrix([[w,-1],[1,0]]);U=s.Matrix([[-2,w],[-w,w*w/2]]);Gu=-(G*U*G);assert Gu==s.Matrix([[w*w/2,-w],[w,-2]]) and not (E*E*Gu-E*Gu-(E*E-E)*Gu).applyfunc(s.expand).todok();assert Gu[0,0]==w*w*s.diff(G,w)[0,0]/2 and Gu!=w*w*s.diff(G,w)/2
out={'schema':'FCP1_APPLICABILITY_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'full_mixed_inverse_then_BB_projection_valid_for_declared_support':True,'fixed_vs_covaried_reference_difference_derived_before_integral':True,'covaried_response_not_full_width_derivative':True,'compact_small_heat_error_bound':'16*z*(1+abs(log(z))) for 0<z<=1/10','coefficient_bounds_and_E1_remainder_proof_reviewed':True,'finite_transport_constant':str(diff),'discard_heat_jet_sensitive_units':2,'extra_open_line_half_sensitive_actual_color_positions':normpositions,'extra_family3_sensitive_actual_color_positions':normpositions,'averaged_projector_sensitive_actual_color_positions':v['averaged_projector_changed_color_positions'],'no_massive_or_varying_probe_or_general_source_conjugation_claim':True,'new_physical_scheme_QAP_measure_or_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
