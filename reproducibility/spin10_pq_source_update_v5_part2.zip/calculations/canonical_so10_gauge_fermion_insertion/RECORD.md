# GFI1: actual paired gauge-loop cPP insertion

Current goal turn PROGRESS: MSP1 constructed and verified an explicit
primitive for the measured KccP source breaking. Its source-free Euler
companions are retained but not independently matched. Whole objective
active/incomplete. Baseb5078fa7c6497cdb7b4c8ffa0031f8f9e50f7630/main31414.

Question: what is the independently derived finite local cPP contribution
from IBS1's paired E_P/E_S gauge-fermion-edge family? This supplies two
actual missing supports in the field sector, instead of inferring the
answer from the selected restoring source primitive. The two Yukawa-edge
supports already have YVF1's actual free-sewing insertion. Eight ghost/
gauge/auxiliary triangle supports remain separate. Do not call this the
complete cPP breaking or use its missing components to enforce a zero.

Freeze current AGENTS/CHARTER/state113/V522/local/solo/epistemic policy,
IBS1 complete typed graph witnesses/receipt, SMA1 action/source/free PS
conventions, QSI1 action insertion i*g times the current E, YVF1 exact
paired free-sewing proof, YCT actual T/H matrices, and OFK1 action-derived
ordinary open-gauge phase as a later normalization comparator. Current
turn MSP1 readiness is authenticated reuse, not a second E4 command.
Physical inputs, source rules, widths and symbolic Yukawa matrices fixed.

Scope: mass-independent one-loop formal Euclidean nonexceptional domain,
physical external hats0. The paired insertion has one external ghost q
and physical P legs; its local ordinary-jet budget is1. Exact free sewing
gives i hatk^2 A barslash(q)/(k^2 r^2) in current convention. The q factor
permits degree0 Taylor of the remaining graph. All propagator endpoints
and both E blocks are formed before Taylor projection. Convergent
evanescent remainder vanishes; a positive auxiliary mass isolates the UV
coefficient without changing any physical mass or exceptional-IR claim.

Both ends of this BB line are actual fermion gauge vertices, hence barred
by SMA1. This differs from CMS1's both-bosonic full-D ghost cycles. Keep
the full denominator momentum. Gauge vertex in the action is -ig barGamma
A; insertion action is i*gE_current. All fermionic statistics and relative
signs must be derived independently, not borrowed from a desired Ward
identity. No full-AC reference or chi substitution is used.

Primary: literal free PS matrices, projected barred gamma chains and
Gaussian radial moments with h=-2epsilon. Derive the three-even-vertex
word/cumulant sign. Sew actual ordered Tb Ta Tc matrices and width frame.
Replay: Clifford-word/charge flips, exact Grassmann Gaussian for the
insertion and ordinary self-energy signs, independent Schwinger/Dirichlet
moments, and color reduction by Casimir/double commutator using actual f.
No peer output access; compare all45 directions and both source chiralities.

Essential moments: hatk^2/(k^2+m^2)^3 and hatk^2 kbar_mu kbar_nu/
(k^2+m^2)^4. Their finite coefficients and relative normalization are
derived, not assigned. A factorized unweighted angular average misses
their mixed hatted/barred correlation. Test that mistake, analytic h sign,
omission of an E block or longitudinal numerator, color commutation,
ordinary right transpose and extra half/family3. Report insensitive
unit-width limits honestly. No source counterterm coefficient fits a loop.

Acceptance: independent complete spin/phase/radial and full color tensor
comparison, all zero complements, exact graph-family reconciliation and
reality/cotangent/H covariance as applicable. Both nonzero coefficients
and genuine structural zeros are meaningful. No claim of full field or
source Slavnov restoration, physical scheme, QAP/measure/phase, massive
threshold, E5/A5 or physical unification. Family extension I3, no extra3.

Freeze eight sources/copies and immutable input hashes before workers.
Sequential600s after imports,8GiB sampled private cap,350MiB launch floor,
16MiB package. Compile prelaunch. Preserve first failures/captures and
version corrections; never weaken acceptance. No agents,new branch/
worktree,reset,publication,outreach or remote push. Authority34/39/state113
unchanged. Both adverse scalar benchmarks,quartetFAIL,flavor pause,HB1/C5
blocks,custody2/seven NOTPASS persist. Shared premises/action/software/AI
author limit independent scientific validation. Pure finite algebra and
explicit primitive Feynman integrals determine this increment; no new
literature theorem is used as a model-specific answer.
