"""GFI1 independent complete gauge-edge insertion gate with sensitive controls."""
from data import *
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def nz(M):return len(s.SparseMatrix(M.applyfunc(s.expand)).todok())
def z(M):assert not nz(M)
assert P['spin_coefficients']==R['spin_coefficients'] and len(P['spin_coefficients'])==64
for obj in [P,R]:
 assert s.sympify(obj['insertion_cumulant_unit'])==1 and s.sympify(obj['ordinary_cumulant_unit'])==-1
 assert s.sympify(obj['current_phase'])==-s.I and s.sympify(obj['action_conversion_phase'])==1
 assert s.sympify(obj['ordinary_gauge_phase'])==-s.I and s.sympify(obj['ordinary_Yukawa_phase'])==s.I
 assert s.sympify(obj['hatted_radial_finite'])==-s.Rational(1,2) and s.sympify(obj['mixed_hatted_barred_radial_finite'])==-s.Rational(1,12)
 assert s.sympify(obj['wrong_unweighted_radial_finite'])==-s.Rational(1,8) and s.sympify(obj['wrong_h_sign_radial_finite'])==s.Rational(1,2)
 assert s.sympify(obj['Feynman_unit'])==1 and s.sympify(obj['longitudinal_unit'])==s.Rational(1,6) and s.sympify(obj['wrong_longitudinal_unit'])==s.Rational(1,4)
 assert obj['free_sewing_remainder']=='0' and obj['action_insertion_conversion']=='i*g10' and obj['actual_fermion_vector_ends_barred']
 assert not obj['extra_family_or_open_half'] and obj['remaining_ghost_triangle_supports']==8 and not obj['full_cPP_or_finite_restoration_qualified']
assert P['insertion_word_signs']==[-1]*6 and P['ordinary_word_signs']==[-1]*2 and min(P['omitted_E_block_nonzero_positions'])>0
assert sorted(P['supported_witnesses'])==sorted(R['supported_witnesses']) and len(P['supported_witnesses'])==2
for w in P['supported_witnesses']:
 ww=json.loads(w);assert ww[3:]==[1,0,3,0,0]
z(dec(P['W'])-dec(R['W']))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));H=dec(Y['H_new']);f={}
for a,b,e,co in packed(CAL/'canonical_so10_complete_matter_source_breaking/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b,e]=s.sympify(co)
left=list(map(dec,P['left']));right=list(map(dec,P['right']));nnl=nnr=badang=commuted=omitlong=nonadj=0;compared=0
for a in range(45):
 for key in ['left','right','Feynman_left','longitudinal_left','wrong_unweighted_left','wrong_commuting_left']:z(dec(P[key][a])-dec(R[key][a]));compared+=16**2
 z(right[a]+left[a].T);z(left[a]-left[a].H);z(right[a]-right[a].H)
 z(left[a]-dec(P['Feynman_left'][a])-dec(P['longitudinal_left'][a])/6)
 z(left[a].subs({WH:1,WM:1})-s.Rational(13,8)*T[a])
 nnl+=nz(left[a]);nnr+=nz(right[a]);badang+=nz(left[a]-dec(P['wrong_unweighted_left'][a]));commuted+=nz(left[a]-dec(P['wrong_commuting_left'][a]));omitlong+=nz(left[a]-dec(P['Feynman_left'][a]))
 projection=sum((s.simplify(s.trace(T[e]*left[a])/2)*T[e] for e in range(45)),s.zeros(16));nonadj+=nz(left[a]-projection)
 z((left[a]-dec(P['wrong_unweighted_left'][a])).subs({WH:1,WM:1}))
for h in range(12):
 th=sum((H[b,h]*T[b] for b in range(45) if H[b,h]),s.zeros(16))
 for a in range(45):
  rhs=sum((H[b,h]*co*left[e] for (b,aa,e),co in f.items() if aa==a and H[b,h]),s.zeros(16));z(-s.I*(th*left[a]-left[a]*th)-rhs)
# Previously measured ordinary phase is a normalization comparator only;
# the independent Berezin derivation above chooses no loop coefficient.
old=packed(CAL/'canonical_so10_open_fermion_finite_kinetic/primary_tables.json.gz');assert old['gauge_open_phase']=='-i' and old['Yukawa_open_phase']=='+i'
assert nnl==nnr>0 and badang>0 and commuted>0 and omitlong>0
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_PAIRED_GAUGE_FERMION_FINITE_INSERTION','elapsed_after_imports':time.perf_counter()-start,'paired_gauge_supports_complete':2,'external_ghost_directions':45,'full_internal_tensor_positions_compared':compared,'complete_spin_coefficients_compared':64,'left_nonzero_positions':nnl,'right_nonzero_positions':nnr,'positions_outside_adjoint_projection':nonadj,'current_phase':'-i','actual_action_phase':1,'Feynman_finite_unit':'1','longitudinal_finite_unit':'1/6','gauge_action_coupling_order':3,'controls':{'premature_unweighted_angular_changes':badang,'color_commutation_changes':commuted,'longitudinal_omission_changes':omitlong,'wrong_hat_sign_changes':nnl,'extra_half_or_family_three_changes':nnl,'ordinary_right_transpose_changes':nnr,'omit_E_block_sensitive':True,'unit_width_angular_control_correctly_insensitive':True},'all12_H_covariance_remainders':'0','complete_source_free_cPP_or_Slavnov_QAP_measure_phase_massive_matching_qualified':False,'remaining_GF_ghost_triangles':8,'Yukawa_edge_insertion_is_qualified_dependency_not_recomputed':True,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
