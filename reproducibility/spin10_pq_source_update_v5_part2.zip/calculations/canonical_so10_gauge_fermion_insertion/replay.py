"""GFI1 Berezin statistics, Schwinger moments and double-commutator color route."""
from data import *
from collections import defaultdict
from itertools import combinations,product
start=begin('replay')
def clean(A):return {key:s.expand(co) for key,co in A.items() if s.expand(co)!=0}
def add(A,B):
 out=dict(A)
 for key,co in B.items():out[key]=out.get(key,0)+co
 return clean(out)
def scale(c,A):return clean({key:c*co for key,co in A.items()})
def wedge(A,B,n):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(n) if a&(1<<i))*x*y
 return clean(out)
def word(ww,co,n):
 out={0:co}
 for i in ww:out=wedge(out,{1<<i:1},n)
 return out
def exponential(action,n):
 out=term={0:s.S.One}
 for j in range(1,n//2+1):term=scale(-s.Rational(1,j),wedge(term,action,n));out=add(out,term)
 return out
F1,F2,al,v1,v2,B=s.symbols('F1 F2 alpha v1 v2 B',nonzero=True);action={}
for ww,co in [([4,5],-F1),([6,7],-F2),([0,1,5,6],al),([3,4],v1*B),([7,2],v2*B)]:action=add(action,word(ww,co,8))
ex=exponential(action,8);internal=sum(1<<i for i in range(4,8));Z={key^internal:co for key,co in ex.items() if key&internal==internal};assert set(Z)=={0,15} and s.expand(Z[0]-F1*F2)==0
# -log and conversion from canonical Pbar to oriented barP P each give-.
insertion=s.simplify(Z[15]*F1*F2/(Z[0]*al*v1*v2*B**2))
F,v,w=s.symbols('F v w',nonzero=True);ordinary={}
for ww,co in [([2,3],-F),([1,2],v*B),([3,0],w*B)]:ordinary=add(ordinary,word(ww,co,4))
ex=exponential(ordinary,4);inside=(1<<2)|(1<<3);ZO={key^inside:co for key,co in ex.items() if key&inside==inside};assert set(ZO)=={0,3} and ZO[0]==F
ordinary_unit=s.simplify(ZO[3]*F/(ZO[0]*v*w*B**2))
# Independent Clifford word normalization of the paired free numerator.
def cliff(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():out[a^b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(6) if a&(1<<i))*x*y
 return clean(out)
r=s.symbols('r0:4');q=s.symbols('q0:4');hh=s.symbols('h0:2');tl,tr=s.symbols('tL tR');AA={0:(tl+tr)/2,15:(tl-tr)/2};At={0:(tl+tr)/2,15:(tr-tl)/2};br={1<<i:r[i] for i in range(4)};bq={1<<i:q[i] for i in range(4)};hat={1<<(i+4):hh[i] for i in range(2)}
part1=scale(s.I,cliff(cliff(cliff(add(br,bq),At),hat),hat));part2=scale(-s.I,cliff(cliff(cliff(hat,hat),AA),br));paired=add(part1,part2);assert not add(paired,scale(-s.I*sum(v*v for v in hh),cliff(AA,bq)))
spin={}
for nu,ch in product(range(4),range(2)):
 summed={}
 for mu in range(4):summed=add(summed,cliff(cliff({1<<mu:1},{1<<nu:1}),{1<<mu:1}))
 assert summed=={1<<nu:-2}
 for a,b,c in product(range(2),repeat=3):spin[f'{nu}_{ch}_{a}{b}{c}']=str(-2 if a==b==c==ch else 0)
eps,h=s.symbols('epsilon h');base=s.gamma(1+eps)
# Schwinger denominator factors: 1/Gamma(3),1/Gamma(4). The separate
# Gaussian hatted/barred variances supply h/(2u) and h/(4u^2).
reg0=h*base/(2*s.factorial(2));reg1=h*base/(4*s.factorial(3));D=4-2*eps;badreg=h*(D+2)*base/(24*D)
finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0))
i0,i1,bad1=map(finite,[reg0,reg1,badreg]);wrong_h=s.simplify(s.diff(reg0.subs(h,2*eps),eps).subs(eps,0));fu=-2*i0;lu=-2*i1;badunit=-2*bad1
current_phase=s.simplify(insertion*(-s.I)**2*s.I);actual=s.simplify(s.I*current_phase)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[-a.T for a in T];H=dec(Y['H_new']);PH=H*H.T;W=WH*PH+WM*(s.eye(45)-PH)
fc=defaultdict(list)
for a,b,e,co in packed(CAL/'canonical_so10_complete_matter_source_breaking/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:fc[a,b].append((e,s.sympify(co)))
def reduce_color(Q,gen):
 CQ=sum((co*gen[b]*gen[c] for (b,c),co in s.SparseMatrix(Q).todok().items()),s.zeros(16));out=[]
 for a in range(45):
  d=defaultdict(lambda:s.S.Zero)
  for (b,c),co in s.SparseMatrix(Q).todok().items():
   for u,v in fc[c,a]:
    for e,w in fc[b,u]:d[e]-=co*v*w
  DD=sum((co*gen[e] for e,co in clean(d).items()),s.zeros(16));out.append(((CQ*gen[a]+gen[a]*CQ-DD)/2).applyfunc(s.expand))
 return out,CQ
F,_=reduce_color(s.eye(45),T);L,_=reduce_color(W-s.eye(45),T);FR,_=reduce_color(s.eye(45),U);LR,_=reduce_color(W-s.eye(45),U)
left=[(actual*(fu*f+lu*l)).applyfunc(s.expand) for f,l in zip(F,L)];right=[(actual*(fu*f+lu*l)).applyfunc(s.expand) for f,l in zip(FR,LR)];bad=[(actual*(fu*f+badunit*l)).applyfunc(s.expand) for f,l in zip(F,L)];_,CQ=reduce_color(fu*s.eye(45)+lu*(W-s.eye(45)),T);commuted=[(Ta*CQ).applyfunc(s.expand) for Ta in T]
ib=packed(CAL/'canonical_so10_matter_breaking_support/replay_tables.json.gz');witnesses=[]
for w in ib['targets']['cPP']['candidate']:
 origins=sorted(json.loads(n)[0] for n in json.loads(w)[0])
 if origins in [['E_P','PPB','PPB'],['E_S','PPB','PPB']]:witnesses.append(w)
finish('replay',{'method':'exact_Grassmann_Gaussian_Clifford_words_Schwinger_moments_double_commutator_reduction','spin_coefficients':spin,'insertion_cumulant_unit':str(insertion),'ordinary_cumulant_unit':str(ordinary_unit),'current_phase':str(current_phase),'action_conversion_phase':str(actual),'ordinary_gauge_phase':str(s.simplify(ordinary_unit*(-s.I)**2*(-s.I))),'ordinary_Yukawa_phase':str(s.simplify(ordinary_unit*(-s.I))),
 'hatted_radial_finite':str(i0),'mixed_hatted_barred_radial_finite':str(i1),'wrong_unweighted_radial_finite':str(bad1),'wrong_h_sign_radial_finite':str(wrong_h),'Feynman_unit':str(fu),'longitudinal_unit':str(lu),'wrong_longitudinal_unit':str(badunit),
 'left':list(map(enc,left)),'right':list(map(enc,right)),'Feynman_left':list(map(enc,F)),'longitudinal_left':list(map(enc,L)),'wrong_unweighted_left':list(map(enc,bad)),'wrong_commuting_left':list(map(enc,commuted)),'W':enc(W),'supported_witnesses':witnesses,'free_sewing_remainder':'0','action_insertion_conversion':'i*g10','actual_fermion_vector_ends_barred':True,'extra_family_or_open_half':False,'remaining_ghost_triangle_supports':8,'full_cPP_or_finite_restoration_qualified':False},start)
