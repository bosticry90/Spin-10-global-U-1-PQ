# GFI1: the actual gauge-edge insertion before field/source assembly

Use the actual free PS defect, with physical qhat0,

 [S(k) E_current S(r)]_PP=i hatk^2 A barslash(q)/(k^2 r^2).

Its two off-diagonal blocks are both needed. The remaining two gauge
vertices come from -ig barGamma_mu A_b B_b^mu. For a physical left open
line the ordered color product is Tb Ta Tc. The right charged carrier is
U_a=-Ta^T. The symmetric width contraction transfers it to minus the
transpose; it is derived again using the actual U matrices.

The three-vertex source-free Gaussian has even action vertices (eta*c is
even). Integrating the internal fermions and the bosonic B^2 gives unit+1
for the oriented eta*c*barP*P insertion. In contrast the two-vertex
ordinary self-energy has unit-1. This independently reproduces OFK1's
ordinary gauge phase -i and Yukawa phase+i from the actual action
couplings/free propagator. It is not a sign fitted to the insertion image.

The paired numerator already supplies q, so set all other ordinary
external momenta to0 for the local coefficient. The two barred gamma
chains obey sum_mu barGamma_mu barslash(q) barGamma_mu=-2 barslash(q).
The actual vector numerator is

 delta_bar,mu,nu I+(W-I) kbar_mu kbar_nu/k^2,
 W=eta_H PH+xi PM.

In16pi^2 units its two required radial residues are

 FP integral hatk^2/(k^2+m^2)^3=-1/2,
 FP integral hatk^2 kbar_mu kbar_nu/(k^2+m^2)^4=-delta_bar,mu,nu/12.

The second follows from the joint angular moment h delta/(D(D+2)) and
the radial k^4 Gamma integral. Replacing it by the product of scalar
angular averages h/D and delta/D gives a wrong finite relative1/4
instead of1/6. No positive witness rank is used as the analytic h.

Thus the current-convention tensor is proportional to

 -i g^2 barslash(q) PL * S_a(Q),
 Q=I+(W-I)/6,
 S_a(Q)=sum_bc Q_bc Tb Ta Tc.

The overall coefficient is independently checked from the frozen
cumulant/radial/spin calculation before comparison. Multiplication by
the actual action insertion i*g yields the physical bare insertion
coefficient +g^3 S_a(Q) in common1/(16pi^2) units.

Replay reduces the ordered color tensor without commuting its matrices:

 S_a(Q)={C_Q,Ta}/2-D_Q,a/2,
 C_Q=sum_bc Q_bc TbTc,
 D_Q,a=sum_bc Q_bc[Tb,[Tc,Ta]]
       =-sum_bcuv Q_bc f_ca^u f_bu^v Tv.

This expression and direct ordered multiplication must agree for every
coefficient, including the component outside the simple adjoint span.
The already measured Yukawa-edge insertion converts separately from
current +i X_R,a/2 to action -g X_R,a/2; it is not recomputed or used to
choose the gauge tensor. Eight GF ghost triangles remain necessary for
complete cPP coverage and for comparison with MSP1's Euler descendants.
