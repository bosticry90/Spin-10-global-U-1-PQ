# GFI1: complete paired gauge-fermion finite insertion

The paired E_P/E_S gauge-fermion-edge family has a qualified nonzero local
finite coefficient in the frozen mass-independent Euclidean domain.
Receipt SHA256:
`c3247d4515b18a2f4df147eaf928bfdb33c2fb4713d11b79a28367e1925455a9`.
Both native derivations and the independent gate returned0. Scientific
acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

For all45 physical ghost directions, common1/(16pi^2) and with the actual
action insertion, the left open-line coefficient is

`+g10^3 barslash(q) PL S_a(Q)`,
`S_a(Q)=sum_bc Q_bc T_b T_a T_c`,
`Q=I+(W-I)/6=(5I+W)/6`, `W=eta_H PH+xi PM`.

The right color coefficient is independently calculated with U_a=-T_a^T
and equals minus the transpose of the left. Each chirality has720 nonzero
internal positions. The three-family lift is I3, with no extra3 or half.
The coefficient is derived from the actual action, not assigned from a
source counterterm or a desired Ward cancellation.

Both fermion endpoints are barred by the actual SMA1 gauge vertex. This
does not change CMS1's full-D rule for vector lines with two bosonic ghost
endpoints. The current-convention free PS sewing is
`i hatk^2 A barslash(q)/(k^2 r^2)`, formed before dropping either block or
Taylor expanding. The ordinary q factor leaves only a degree0 Taylor of
the rest for this local one-jet target. UV-convergent evanescent remainders
vanish within the nonexceptional domain; no exceptional-momentum or physical
massive limit is inferred.

The correlated angular moments are decisive:

`FP int hatk^2/(k^2+m^2)^3=-1/2`,
`FP int hatk^2 kbar_mu kbar_nu/(k^2+m^2)^4=-delta_mu_nu/12`.

The barred spin contraction is-2. Thus the Feynman and longitudinal units
are1 and1/6. Replacing the joint hatted/barred moment by a product of
unweighted angular averages gives a wrong1/4 longitudinal unit. This
changes all720 nonzero left positions generically, while correctly being
insensitive at eta_H=xi=1. That limit gives the independently checked
`S_a(I)=(13/8)T_a`.

The exact Grassmann Gaussian gives insertion cumulant+1 and ordinary
self-energy cumulant-1. With the actual action vertices these reproduce
ordinary gauge phase-i and Yukawa phase+i, independently agreeing with
OFK1's phase comparator. The paired insertion has current phase-i g^2;
the qualified action conversion i*g makes the displayed +g^3 coefficient.
No reference chi substitution or full chiral-comparator theorem is used.

Primary uses literal PS blocks, projected barred gamma chains, Gaussian
moments and ordered matrix products. Replay uses Clifford words, a full
Grassmann Gaussian, Schwinger moments and the different color reduction
`S_a(Q)={C_Q,T_a}/2-D_Q,a/2`, with
`C_Q=sumQ_bc TbTc`, `D_Q,a=sumQ_bc[Tb,[Tc,Ta]]`.
All69,120 internal matrix positions across result/parts/controls and64
spin coefficients agree, including zeros. Internal H-equivariance of the
color tensor holds for all12 generators. This is not a full local-H
completion of the derivative density: its background/gauge field
companions remain separate.

Its projection outside the simple adjoint-generator span has696 nonzero
matrix positions. This is a measured ordered-color structure, not a new
particle or an anomaly finding. It must be compared with the complete
field/source normalization, rather than replaced by an averaged Casimir.
Commuting the color matrices, omitting the longitudinal numerator, wrong
h sign, an ordinary right transpose or extra half/family3 each changes720
positions. Omitting either PS insertion block is independently detected.

This closes two gauge-edge supports in IBS1's cPP catalogue. The two
Yukawa-edge supports already have YVF1's separately qualified insertion;
their action conversion is -g X_R,a/2 from the current +i X_R,a/2. They
are not recomputed or used to choose the new gauge coefficient. Eight
GF ghost-triangle supports are still uncalculated in this field component.
No exact-once assembly of the full cPP breaking is claimed yet.

Primary20.7452087s, replay3.9608570s, independent gate22.0372109s after
imports, native0. Sample counts11/3/12, sampled private maxima
64,376,832/63,295,488/61,771,776bytes, not continuous peaks.600s/8GiB
sampled/350MiB launch-floor/16MiB package limits upheld. Eight immutable
source copies,47 initial56 validation bindings; no frozen worker/gate
failure. Current-turn MSP1 E4 readiness is authenticated reuse, not a
second command or fresh historical science replay. Custody2/seven NOTPASS.
External controls: `C:/Users/psboy/.codex/research-control-records/ToE-Next/gauge-fermion-insertion-v1-2026-10-23`.

Next calculate the actual GF ghost triangles, preserving both ordinary
derivative placements and auxiliary BL orientation. The auxiliary g^2
subset is the complete lower-coupling cPP class and can first be compared
with MSP1's g^2 Euler companion; ordinary triangles need both original
antighost-jet and vector-jet tensors, not just their zero-momentum
difference. Derive them before testing the complete field-source relation.

Full finite Slavnov/QAP/products/measure/phase, physical chiral scheme,
massive C1/E5A5/physical unification remain unqualified. Both adverse scalar
benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks,custody limitations and
all old evidence remain. Shared action/data/software/AI author limits
independence. No physical normalization or flavor point is selected.
