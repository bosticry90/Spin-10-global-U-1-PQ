"""GFI1 literal paired PS matrices, barred spin chain and ordered color sewing."""
from data import *
from collections import defaultdict
from itertools import combinations,permutations,product
start=begin('primary')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],a) for a in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gs=[s.kronecker_product(G,pa[2]) for G in g4]+[s.kronecker_product(s.eye(4),a) for a in pa[:2]]
chi=s.prod(gs[:4]);P=[(s.eye(8)+chi)/2,(s.eye(8)-chi)/2];U=s.kronecker_product(s.eye(4),s.Matrix([1,0]));P4=[(s.eye(4)+s.prod(g4))/2,(s.eye(4)-s.prod(g4))/2]
rv=s.symbols('r0:4');qv=s.symbols('q0:4');hv=s.symbols('h0:2');tl,tr=s.symbols('tL tR')
slash=lambda vv,gg:sum((v*G for v,G in zip(vv,gg)),s.zeros(8))
br=slash(rv,gs[:4]);bq=slash(qv,gs[:4]);hat=slash(hv,gs[4:]);A=P[0]*tl+P[1]*tr;At=P[1]*tl+P[0]*tr;O=s.zeros(8)
Nk=(br+bq).row_join(hat).col_join(hat.row_join(br+bq));Nr=br.row_join(hat).col_join(hat.row_join(br))
E=O.row_join(-s.I*At*hat).col_join((s.I*hat*A).row_join(O));sewn=(-Nk*E*Nr).applyfunc(s.expand);zero(sewn[:8,:8]-s.I*sum(v*v for v in hv)*A*bq)
omit=[]
for sl in [(slice(0,8),slice(8,16)),(slice(8,16),slice(0,8))]:
 bad=s.MutableDenseMatrix(E);bad[sl[0],sl[1]]=s.zeros(8);omit.append(len(s.SparseMatrix((-Nk*bad*Nr-sewn)[:8,:8].applyfunc(s.expand)).todok()))
spin={}
for nu,ch in product(range(4),range(2)):
 basis=g4[nu]*P4[ch]
 for a,b,c in product(range(2),repeat=3):
  NN=U.H*P[1-ch]*sum((gm*P[b]*P[a]*gs[nu]*gm*P[c] for gm in gs[:4]),s.zeros(8))*P[ch]*U
  co=s.simplify(s.trace(basis.H*NN)/2);zero(NN-co*basis);spin[f'{nu}_{ch}_{a}{b}{c}']=str(co)
# Three even action vertices and explicit oriented external barP P order.
words=[[0,1,5,6],[3,4],[7,2]];signs=[]
for perm in permutations(range(3)):
 ww=sum((words[j] for j in perm),[]);signs.append((-1)**sum(ww[i]>ww[j] for i in range(8) for j in range(i+1,8)))
insertion_unit=-s.Rational(sum(signs),6)
ordinary_words=[[1,2],[3,0]];ordinary_signs=[]
for perm in permutations(range(2)):
 ww=sum((ordinary_words[j] for j in perm),[]);ordinary_signs.append((-1)**sum(ww[i]>ww[j] for i in range(4) for j in range(i+1,4)))
ordinary_unit=s.Rational(sum(ordinary_signs),2)
eps,h=s.symbols('epsilon h');D=4-2*eps;gamma=s.gamma(1+eps)
R0=h/D*(D/4)*gamma;R1=h/(D*(D+2))*(D*(D+2)/24)*gamma;wrong=h/D**2*(D*(D+2)/24)*gamma
finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0))
i0,i1,wrong1=map(finite,[R0,R1,wrong]);wrong_h=s.simplify(s.diff(R0.subs(h,2*eps),eps).subs(eps,0))
spinunit=s.sympify(spin['0_0_000']);funit=s.simplify(spinunit*i0);lunit=s.simplify(spinunit*i1);badunit=s.simplify(spinunit*wrong1)
current_phase=s.simplify(insertion_unit*(-s.I)**2*s.I);action_phase=s.simplify(s.I*current_phase)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));RT=[-M.T for M in T];H=dec(Y['H_new']);PH=H*H.T;W=WH*PH+WM*(s.eye(45)-PH)
def sew(Q,gen):return [(sum((co*gen[b]*gen[a]*gen[c] for (b,c),co in s.SparseMatrix(Q).todok().items()),s.zeros(16))).applyfunc(s.expand) for a in range(45)]
F=sew(s.eye(45),T);L=sew(W-s.eye(45),T);FR=sew(s.eye(45),RT);LR=sew(W-s.eye(45),RT)
left=[(action_phase*(funit*f+lunit*l)).applyfunc(s.expand) for f,l in zip(F,L)];right=[(action_phase*(funit*f+lunit*l)).applyfunc(s.expand) for f,l in zip(FR,LR)]
bad=[(action_phase*(funit*f+badunit*l)).applyfunc(s.expand) for f,l in zip(F,L)];Q=funit*s.eye(45)+lunit*(W-s.eye(45));CQ=sum((co*T[b]*T[c] for (b,c),co in s.SparseMatrix(Q).todok().items()),s.zeros(16));commuted=[(Ta*CQ).applyfunc(s.expand) for Ta in T]
ib=packed(CAL/'canonical_so10_matter_breaking_support/primary_tables.json.gz');witnesses=[]
for w in ib['targets']['cPP']['candidate']:
 if sorted(ib['vertices'][n]['origin'] for n in json.loads(w)[0]) in [['E_P','PPB','PPB'],['E_S','PPB','PPB']]:witnesses.append(w)
finish('primary',{'method':'literal_PS_sewing_projected_barred_gamma_Gaussian_moments_ordered_matrix_products','spin_coefficients':spin,'omitted_E_block_nonzero_positions':omit,'insertion_cumulant_unit':str(insertion_unit),'ordinary_cumulant_unit':str(ordinary_unit),'insertion_word_signs':signs,'ordinary_word_signs':ordinary_signs,
 'current_phase':str(current_phase),'action_conversion_phase':str(action_phase),'ordinary_gauge_phase':str(s.simplify(ordinary_unit*(-s.I)**2*(-s.I))),'ordinary_Yukawa_phase':str(s.simplify(ordinary_unit*(-s.I))),
 'hatted_radial_finite':str(i0),'mixed_hatted_barred_radial_finite':str(i1),'wrong_unweighted_radial_finite':str(wrong1),'wrong_h_sign_radial_finite':str(wrong_h),'Feynman_unit':str(funit),'longitudinal_unit':str(lunit),'wrong_longitudinal_unit':str(badunit),
 'left':list(map(enc,left)),'right':list(map(enc,right)),'Feynman_left':list(map(enc,F)),'longitudinal_left':list(map(enc,L)),'wrong_unweighted_left':list(map(enc,bad)),'wrong_commuting_left':list(map(enc,commuted)),'W':enc(W),'supported_witnesses':witnesses,'free_sewing_remainder':'0','action_insertion_conversion':'i*g10','actual_fermion_vector_ends_barred':True,'extra_family_or_open_half':False,'remaining_ghost_triangle_supports':8,'full_cPP_or_finite_restoration_qualified':False},start)
