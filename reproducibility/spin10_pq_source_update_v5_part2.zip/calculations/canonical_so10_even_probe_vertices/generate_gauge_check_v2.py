from pathlib import Path
O=Path(__file__).resolve().parent
t=(O/'check_gauge.py').read_text(encoding='utf-8')
assert t.count("gauge_validation_preparation.json")==1
t=t.replace('gauge_validation_preparation.json','gauge_validation_preparation_v2.json')
assert t.count("dec=lambda d:")==1
t=t.replace('dec=lambda d:',"from functools import lru_cache\n@lru_cache(None)\ndef parse(z):return s.sympify(z,locals=loc)\ndec=lambda d:")
t=t.replace('s.sympify(z,locals=loc) for i,j,z','parse(z) for i,j,z')
assert t.count("RC=dec(P['RC']);T=")==1
t=t.replace("RC=dec(P['RC']);T=","RC=dec(P['RC']);RA=dec(P['RA']);T=")
old="expected=dec(J['q_projection_candidate'][r]['plane_'+ch][a]);zero(K[a]-expected)"
new="expected=dec(J['q_projection_candidate'][r]['plane_left'][a]) if ch=='left' else sum((RA.T[b,a]*dec(J['q_projection_candidate'][r]['physical_right'][b]) for b in range(45) if RA.T[b,a]),s.zeros(16));zero(K[a]-expected)"
assert t.count(old)==1;t=t.replace(old,new)
with(O/'check_gauge_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('GENERATED_QVC_CHECKER_V2_NO_OLD_SOURCE_CHANGED')
