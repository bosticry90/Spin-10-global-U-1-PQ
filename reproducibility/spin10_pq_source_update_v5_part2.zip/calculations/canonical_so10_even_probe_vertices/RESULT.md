# EPV1/EUL1/QVC1: complete first-probe fermionic three-jet comparison

Disposition: PROGRESS. All results below have completed verification;
two original implementation/harness failures remain FAILED and preserved.
This is a bare evanescent-insertion calculation and subsequent counterterm
construction in the inherited mass-independent Euclidean local UV family.
It is not a complete finite quantum-action-principle or physical matching
result. State113/34of39 and project_state.json remain unchanged.

## Scientific question and reference intake

V592 supplied one common local candidate for selected ordinary rho*PP and
K_P-source projections. Its u*C*PP p,q,s image was a COUNTERTERM image,
not a quantum measurement. The necessary next question was whether the
actual action yields the same complete three-jet quantum tensor.

The director's new assessment, "A deeper assessment of the latest quantum
research", was read from attachment eb0c0e55-6875-46f7-82df-19623ef1a359.
Its exact UTF-8 file SHA256 is
1e789e00a50c3fc681b18b7b5d71eba67aab86b9c0f8aaf665c57af107eb9dff.
Its recommendations to test complete correlated identities, preserve
finite contacts and avoid coefficient accumulation were applied to this
next indispensable comparison. It is contextual reference material, not
an input defining an unknown loop coefficient or an authority promotion.
Its historical physical claims/citations were not freshly externally
validated by this increment. The earlier source-product and finite-contact
obligations remain separate from the bare test performed here.

The starting checkpoint is main41ec6faa731dd1758cc9eac22c7f86ed06296916.
Preflight recovered a clean tracked tree, no matching live research Python
worker, State113 and the current V592 handoff. Authenticated inputs include
the actual QG/G densities, physical643-field/source maps, Tminus, plane_f,
GTT/GFI/SMA hatted numerator and endpoint conventions. The latter analytic
and regulator-domain premises are REUSED, not newly proved Clifford/QAP
theorems. No old scientific calculation or policy evidence was rewritten.

## EPV1: full local-probe symbols, not only constant-u propagation

For field leg momenta -k,+l and independent probe transfer s=k-l, primary
density Hessians and replay full Euler linearization agree, including
derivatives of u, Grassmann signs and all relevant zero complements.
Both ghost and scalar marginal quadratic symbols vanish at finite transfer.
This closes the warning that a constant-u structural zero might conceal
derivative-u vertices. It does not assert zero massive scalar amplitudes.

For each selected color, with w0=eta_H,w1=xi, the measured bosonic kernel is

    U_r(k,l) = [[-2 k_mu l_nu, w k_mu],[-w l_nu,w^2/2]].

It gives the ORDERED first-probe derivative

    -G0(k) U_r(k,l) G0(l)
       = [[w^2 k_mu l_nu/(2 k^2 l^2),-w k_mu/k^2],
          [w l_nu/l^2,                 -2]].

The compact factorization was tested after deriving the actual symbols,
for all12/33 colors and four vector components. k and l were not equated.
The late constant-s0 comparison recovers all authenticated PAR1 symbols.
Erasing the transfer changes240/660 quadratic positions. A generic5x5
wrong-order propagator control changes six positions.

The actual new ghost currents have AC=AU=0 for both probes. Light-probe
V/H also vanish. Heavy-probe V/H each have600 entries, with H=(xi/2)V;
they have coupling orderg10^0, not an assumed commong10. Merging AC and AU
is therefore INSENSITIVE here. They must nevertheless be kept distinct
until their actual values have been established. Scalar/ghost insertions
are excluded from the subsequent target by the FULL symbols, not s0 alone.

## EUL1: independently measured full u*C*PP tensor

Keep external P momentum p, ghost momentum q and probe momentum s separate.
The complete selected one-loop1PI support comprises new uQG ghost-current
triangles, old GF ghost triangles with a single quadratic bosonic insertion,
and paired gauge-fermion-edge diagrams with the same insertion. The actual
field roles and one-loop cycle/weighted jet bounds exclude other families
as stated in LOOP_RECORD.md. Fixed-source quantum inputs do not license
deleting source derivatives from later Ward operations.

Primary differentiates complete four-denominator rational expressions
before UV rearrangement and uses physical ordered color matrices. Replay
cancels numerator factors exactly, derives shifted Schwinger moments,
transports plane-basis propagators, and reduces the gauge edge through a
double commutator. Both retain the authenticated full-D hatted prescription.
Neither native worker reads the PFJ1 correction or its peer's result.

The independently derived vector moments for the two orientations are
(p/6+(q+s)/3) and (p/6-(q+s)/6). The old derivative-C current has +/-J*q
with J=-1/12, but no s term. I0=-1/2. The gauge edge supplies its q/6
coefficient independently of the counterterm. All actual coupling orders,
including g10^2 contributions, are retained until assembly.

All691200 complete matrix/part positions agree, including zeros. Counts
below are nonzero physical-coordinate matrix positions per chirality;
they are not independent experiments or independent normalization freedoms.

| Probe | Quantum p | Quantum q | Quantum s | Surviving coupling |
|---|---:|---:|---:|---|
| u0 | 448 | 500 | 556 | g10^3 eta_H^2 |
| u1 | 448 | 581 | 464 | g10^3 xi^2 |

Every assembled g10^2 p/q/s position is zero. For the heavy probe the new
current and old mixed-propagator pieces are individually nonzero in q/s
and cancel there. Deleting either changes464 positions. For the light
probe both controls are insensitive, as the corresponding pieces vanish.
Deleting the Lambda^2-dependent BB update, double-counting the insertion,
using the unweighted angular moment, or merging q and s changes the actual
result. Full control counts and right momentum-reversal tests are in the
receipt. Right p=leftp.T, q=(leftp-leftq).T, s=(leftp-lefts).T hold.

Only after independent quantum completion was the old PFJ1 candidate read.
Its kinetic/source pieces cancel p and s exactly for both probes and
chiralities. q retains576/581 physical positions in each chirality. Thus
the old candidate alone FAILS this newly complete selected comparison.
This is a scientific remainder, not an anomaly verdict or an unknown
quantum term assigned a convenient value.

## QVC1: one extended local candidate and its retained companions

Set K_ra to the NEGATIVE of that measured q remainder, transported to real
plane coordinates. It includes its actual g10^3 width-squared polynomial;
there is no division by g10 or a width and no finite constant selection.
The right coefficient is independently derived, then checked as -K_left.T.
Real-plane K is Hermitian and transforms correctly under all12 actual
unbroken generators. Its715/720 plane positions differ from576/581 physical
positions because the field coordinates differ.

In the common1/(16pi^2) units the new candidate is

    C_full = C_probe - i sum_ra u_r B_mu^a barP gamma_mu K_ra P.

C_probe is the UNCHANGED PFJ1 kinetic plus K_P-source functional. A literal
nine-ODD-coordinate variation with arbitrary component matrices derives
the new vertex images, preserving the nonlinear QB term:

    u*C*PP: p=0, q=K_ra, s=0;
    rho*BPP: -i K_rb;
    u*B_b*C_c*PP: g10([K_rb,T_c]-i sum_a f_bc^a K_ra).

The old source-Euler companion g10^4[x_rc,T_b] is retained and added exactly
once. So are the inherited mass/hatted programs and boundary currents.
The new derivative-free term has no K_P and cannot alter the selected old
source projection. It also cannot alter rho*PP at B0. Its q image cancels
the measured residual while its p/s images vanish. This establishes one
COMMON candidate for all three selected projections, not just separate
counterterms that happen to work in isolation.

The separate checker uses replay quantum data, independently transported
right data, the component gauge variation and momentum reversal. All
4469760 retained positions, including zeros, pass. Omitting/reversing the
new q vertex changes576/581 positions; its p/s controls are honestly
insensitive. Omitting rho*BPP loses715/720 positions. Dropping the nonlinear
QB part changes11440/11520 positions. All12 actual global-H contractions
and real-plane reality/right-conjugation checks pass. These do not prove
the full varying-background functional.

Per chirality, the new u*BC*PP program has24104/25056 nonzero plane positions;
with the old source Euler term it has27680/26560. These are COUNTERTERM
images, not quantum measurements. In particular, the nonzero rho*BPP and
u*BC*PP quantum inputs remain uncalculated. The next direct dependency is
the former zero-ordinary-jet tensor, as specified in NEXT_RHO_BPP.md.

## Failures, resources and authentication

Two original runs failed and remain exact, unrelabelled evidence:

1. Original EUL1 primary stopped before producing amplitudes. SymPy returns
   [((0,0),0)] for Poly(0); the reducer applied its nonzero-monomial support
   assertion before testing the zero coefficient. V2 skips only exact zero
   coefficients; every nonzero support assertion and resource limit remains.
2. Original QVC1 checker requested nonexistent plane_right in an earlier
   diagnostic that stores right data physically. V2 transports the actual
   physical_right with RA.T and caches identical immutable expression
   parsing. It does not replace right quantum input with -left.T. No quantum
   worker or completed constructor was repeated for this harness repair.

Neither failure has a completed scientific validation receipt. Their frozen
sources, source copies, manifests, full captures and controller failures
remain. The later corrected receipts validate the corrected executions only.
No new preparer, EPV1 verifier, EUL1-V2 worker/verifier or QVC1 constructor
failed. Each successful stage's complete resource samples are preserved.

| Completed stage | Seconds after imports | Samples | Max sampled private bytes |
|---|---:|---:|---:|
| EPV primary | 3.1362510 | 2 | 220839936 |
| EPV replay | 3.8431635 | 3 | 304201728 |
| EPV verifier | 0.5786996 | 2 | 67969024 |
| EUL primary V2 | 36.5621630 | 20 | 91926528 |
| EUL replay V2 | 84.2284880 | 43 | 87269376 |
| EUL verifier V2 | 52.1468308 | 27 | 84287488 |
| QVC constructor | 91.9434244 | 49 | 145985536 |
| QVC checker V2 | 68.3905269 | 37 | 135909376 |

These are sampled observations, not continuous memory peaks. EPV stages
had300s caps and their original16MiB packet ceiling. EUL stages had600s
caps under a new frozen32MiB continuation. QVC stages had300s caps under
that same whole-packet32MiB ceiling. All had8GiB sampled-private ceilings
and350MiB available-commit launch floors. All completed caps held. The
final packet is approximately2.2MB before these result/handoff additions.
Original failed workers have4/64 samples and54222848/133849088B maxima.

There are28 source copies. Preparation/validation binding counts are
47/55 (EPV),87 (original EUL),103/112 (EUL V2),126/131 (QVC original),
and144 (QVC checker V2). Authentication does not replay a calculation.

Receipt SHA256 values:

- EPV validation:70db6cd8cd8e9434053d7d68c1256006ca7fcca18a0fde1fd1b0b6fe3e26a900
- EUL V2:3d341dd225272df306eee9e59e8bb25c9ae58a93172d09790202c5a6bf4661f3
- QVC construction:a81f9c4b8242bead936d473897946a19505e28b51ed1f61c5645deeb289b5196
- QVC checker V2:d8952be558c2aa73549f7829be3afaeb7f4e516811d95eb82ba0e7ac4e75b476

Current E4 readiness completes with native0 and exits[0,0,0,0,0,2]. The seven
historical unresolved references remain NOTPASS. This authenticates/reuses
sealed historical E4 evidence; it is not fresh E5 acceptance. Full captures
and before/index/postcommit preservation seals are held externally under
C:/Users/psboy/.codex/research-control-records/ToE-Next/
even-probe-vertices-v1-2026-10-24/. All34750 previous tracked blobs and
project_state.json must remain unchanged through the local commit.

## Significance and limits

This increment measures a complete required three-jet class, rejects the
insufficient old candidate in its q projection, and constructs/checks one
correlated extension. It demonstrates action-level vertex reduction,
different momentum/color derivations, graded operator construction and
sensitive controls. Two avoidable implementation/schema errors remain part
of the AI-capability evidence; caching corrected orchestration cost without
removing scientific comparisons. No separate benchmark platform was created.

The routes share the action, field maps, analytic domain, GTT/GFI/SMA premises,
software and AI author. They provide computational corroboration rather
than independent scientific validation of the premises. Finite heat/contact
products, complete augmented Ward/QAP identities, local-background completion,
measure/global phase, causal/constant-vacuum limits, massive fermion matching,
physical unification and E5/A5 remain open. kappa,b0,chi4 remain distinct and
unselected. Prior scalar/benchmark/quartet failures and flavor/HB1C5 boundaries
are preserved. No foundation, scheme or canonical action was adopted.
