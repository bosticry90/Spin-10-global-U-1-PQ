from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest()
old=json.loads((O/'gauge_validation_preparation.json').read_bytes())['input_sha256']
for p,h in old.items():assert H(Path(p))==h,p
assert json.loads((O/'gauge_failure.json').read_bytes())['stage']=='gauge_check'
assert json.loads((O/'gauge_check_capture.json').read_bytes())['exit_code']==1
for n in ['GAUGE_CHECK_CORRECTION_V2.md','generate_gauge_check_v2.py','check_gauge_v2.py','prepare_gauge_check_v2.py','run_gauge_check_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(old)
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
with(O/'gauge_validation_preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_limit':8*1024**3,'launch_floor':350*1024**2,'packet_limit':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_QVC_CHECKER_V2',len(b))
