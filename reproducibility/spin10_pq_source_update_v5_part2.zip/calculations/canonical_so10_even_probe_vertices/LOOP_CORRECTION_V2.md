# Preserve the first worker failure; admit the zero Taylor polynomial

Original loop primary exited1 in the rational moment reducer before any
amplitude/table/result. Its complete source/copy/capture and loop_failure
remain unchanged;original replay/verifier did not launch. SymPy Poly(0)
returns a zero coefficient at monomial(0,0). The reducer asserted the
NONZERO monomial support before testing whether that coefficient was zero.
The p/s derivatives of the A*q numerator are exactly zero and must map to0.

V2 skips a coefficient ONLY when it equals exact0,then applies the same
unchanged allowed(1,0)/(0,2) monomial checks and radial moments. A direct
Poly(0) assertion records this library representation. No nonzero tensor,
input,kinematic identity,domain,resource cap or comparison is removed.
New source,manifest,output and capture names preserve the failed version.
This is an implementation correction,not fitting a quantum coefficient.
