# EPV1: actual local-u vertices needed by the three-jet fermion test

Base/main41ec6faa731dd1758cc9eac22c7f86ed06296916. V592 is PROGRESS.
Current preflight:clean tracked tree,no matching live research Python workers,
State113/34of39 unchanged,custodyexit2/sevenNOTPASS. Whole goal active/incomplete.

Question: what are the FULL finite-transfer marginal quadratic and ghost-
current vertices of the actual u_r QG_r action? PAR1 gave only constant-u
principal propagation. A quadratic density that is a boundary at constant u
can leave derivative-u interactions. Those must be established before the
complete u*C*PP quantum p/q/s calculation is competent. This is a necessary
action-level reduction,not a second status ledger or a new regulator scheme.

Freeze actual two QG densities,physical643-field/source maps,graded/Wick
conventions,and mass-independent Euclidean local/test-field domain. u even,
dimension0/ghost0; C,a dimension1,ghost+/-1; B dim1,Lambda dim2. Keep all
four Lorentz components. Full source/field support is authenticated CPS/TPW
reuse; no matter/source row is changed. This target retains source-free
quadratics at weighted derivative degree4-di-dj and marginal aCB/aLambdaC
currents. Other scalar/orbit terms are excluded only by positive dimension
for the later one-jet target,not declared zero massive amplitudes.

Use independent first/second momenta k,l and external even-probe transfer
s=k-l,not a single constant momentum. Primary differentiates the actual
density twice and forms(-ik)^I(il)^J. Replay first takes the complete
Euler derivative,then linearizes it,retaining every derivative-u coefficient
with Fourier i*s and second-field i*l. Compare full exact polynomials
after k=l+s,including all ghost/scalar zero complements. Only the subsequent
verifier compares the s=0 limit to authenticated PAR1 symbols.

Extract aCB currents with derivatives on a,B,C,u separately. Primary uses
literal ordered density;replay derives the full graded Euler-a expression.
Retain V=Ua-UB,AC=Ua-UC,AU=Ua-Uu,with u and C independently labeled.
Auxiliary aLambdaC coefficients retain actual g and width powers. Do not
strip a guessed common coupling or assign a coefficient from a desired
fermionic cancellation. The bare quartic/current assembly is not computed
from the previously constructed counterterm images.

After independent agreement,test whether the actual bosonic quadratic kernel
has a compact factorized form and whether the ghost kernel begins at s^0,
s^1 or s^2. These are outcomes,not premises. Controls erase probe momentum,
commute the quadratic vertex past a propagator,or merge even-probe and ghost
jets; report which are actually sensitive. A constant-u check alone cannot
validate any newly nonzero s term. Keep failures and exact source/capture bytes.

Sequential primary/replay/verifier300 seconds after imports each,8GiB sampled
private,350MiB launch floor,whole packet16MiB. Freeze inputs/source snapshots
before execution. Mismatch/resource exhaustion is failed/incomplete,not a
physical anomaly or PASS. No cap expansion or evidence truncation.

Next,derive the complete one-loop support and use these actual vertices
to calculate all p,q,s coefficients before comparing PFJ1's correction.
Shared action,frames,analytic premises,software and AI authorship limit
independence. No agents,branch/worktree,push,outreach,publication,physical
benchmark/scheme/foundation adoption,flavor/HB1C5 activation or promotion.
Full QAP,chiral measure/phase,massive/physical matching and E5/A5 remain open.
