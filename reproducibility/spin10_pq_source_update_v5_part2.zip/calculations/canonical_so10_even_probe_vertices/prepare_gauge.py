from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;R=O.parents[1]
H=lambda p:sha256(p.read_bytes()).hexdigest()
old=json.loads((O/'loop_validation_preparation_v2.json').read_bytes())['input_sha256']
for p,h in old.items():assert H(Path(p))==h,p
v=json.loads((O/'loop_validation_receipt_v2.json').read_bytes())
assert v['all_independent_quantum_arrays_agree'] and v['complete_quantum_positions_compared']==691200
assert all(x['q_only_gauge_vertex_route_available'] for x in v['q_projection_diagnostics'])
for n in ['GAUGE_COMPLETION.md','construct_gauge.py','check_gauge.py','prepare_gauge.py','run_gauge.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(old)
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
with(O/'gauge_preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'sampled_private_limit':8*1024**3,'launch_floor':350*1024**2,'packet_limit':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_QVC1',len(b))
