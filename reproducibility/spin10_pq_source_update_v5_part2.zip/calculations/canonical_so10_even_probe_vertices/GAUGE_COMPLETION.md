# QVC1: a local vertex for the measured ghost-momentum remainder

EUL1 V2 completed before this construction. Primary/replay quantum arrays
agree in all 691200 retained matrix/part positions, including zeros. Only
after that comparison, the unchanged PFJ1 candidate leaves p=s=0 and q
remainders with 576/581 positions in each chirality. The g10^2 pieces cancel;
the remainder is polynomial g10^3 times eta_H^2 or xi^2. It is not a new
finite normalization, a physical scheme choice, or an anomaly finding.

Construct from that MEASURED remainder, in the same 1/(16pi^2) units,

    K_ra = -(R_quantum,q + R_PFJ,q)_ra,
    C_vertex = -i sum_ra u_r B_mu^a barP gamma_mu K_ra P.

K includes its actual g10^3. It is not divided by a coupling or a width.
Use real plane B/C coordinates for this formula; physical coordinates are
transported with the authenticated frame. The right coefficient is derived
separately from its measured remainder, then checked as K_R=-K_L^T.

With du=rho, QP=i g C_a T_a P, QbarP=-i g C_a barP T_a and
QB_a=partial C_a+g f_bc^a B_b C_c, the exact new ordinary images are

    u*C*PP:       p=0, q=K_ra, s=0;
    rho*BPP:      -i K_rb;
    u*B_b*C_c*PP: g ([K_rb,T_c]-i sum_a f_bc^a K_ra).

Derive these signs by a literal odd polynomial variation with arbitrary
matrix entries, independent ghost/probe coordinates and the full nonlinear
QB term. No integration by parts is needed for this derivative-free vertex.
Retain both chiralities and all 45x45 gauge/ghost companions. Also retain the
UNCHANGED PFJ1 source-Euler g10^4 [x_rc,T_b] companion. The kinetic and
source terms, their mass/hatted programs and boundary currents are unchanged.

The completed local C_probe+C_vertex must cancel the independently measured
rho*PP and u*C*PP projections simultaneously, while preserving the old
K-source projection. This does NOT calculate rho*BPP or u*C*BPP quantum
inputs. Their retained counterterm images define the next tests. Do not
infer those quantum values from this construction. Background connection
completion is separate from the quantum B field; no inhomogeneous local-H
law is assigned to a homogeneous fluctuation to manufacture a restriction.
This packet checks global-H covariance/reality and ordinary selected images,
not a full varying-background renormalized construction.

Constructor: derive K directly from primary quantum arrays plus PFJ1 images,
then compute the component commutator/structure-constant programs. Checker:
use replay quantum arrays, momentum reversal and the alternative expression
g(K_b T_c-T_c K_b-i f_bc^a K_a); compare all matrix positions and both
chiralities. Verify the generic odd density identity, source preservation,
rho*PP preservation, coupling types, Hermiticity and all twelve actual
unbroken-generator contractions. Test omitting/reversing the new vertex,
omitting its rho companion and omitting its nonlinear QB term. Record any
insensitive control honestly. No presumed zero quantum remainder is fitted.

Freeze sources and actual input/output receipts before construction. Each
constructor/checker has 300 seconds after imports, 8GiB sampled private,
350MiB launch floor; whole EPV1/EUL1/QVC1 packet 32MiB. Preserve the original
EUL1 zero-polynomial implementation failure and all its frozen bytes. A
new failure is not PASS; no caps or scientific requirements are weakened.

State113/34of39, E5/A5 open, historical custody exit2/seven NOTPASS remain.
No canonical action adoption, finite constants selection, benchmark/scheme
change, flavor/HB1C5 activation, agent, branch/worktree, push or publication.
Shared action, frames, loop/domain premises, software and AI author limit
independence. Full finite heat/contact/QAP, measure/global phase, massive
physical matching and unification are not established by this construction.
