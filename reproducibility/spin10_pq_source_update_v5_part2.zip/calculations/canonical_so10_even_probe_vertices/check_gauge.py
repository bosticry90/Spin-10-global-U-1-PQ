from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'gauge_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']})
clean=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def zero(M):assert not clean(M).todok()
def nz(M):return len(clean(M).todok())
D=load(O/'gauge_tables.json.gz');P=load(O/'loop_replay_v2_tables.json.gz');C=load(O.parent/'canonical_so10_probe_fermion_onejet/construction_tables.json.gz');J=load(O/'loop_comparison_v2_tables.json.gz');inp=load(O/'loop_replay_inputs.json.gz')
RC=dec(P['RC']);T=list(map(dec,inp['Tminus']));fc=defaultdict(list)
for b,c,a,z in inp['plane_f']:fc[b,c].append((a,s.sympify(z)))
positions=0;controls=[];diagnostics=[]
for r in range(2):
    ctrl=Counter();diag={};KK={ch:list(map(dec,D['candidate'][r]['plane'][ch])) for ch in ['left','right']}
    for ch,key in [('left','left_ucPP'),('right','right_ucPP')]:
        K=KK[ch];Tp=T if ch=='left' else[-t.T for t in T];x=list(map(dec,C['x_source'][r]));x=x if ch=='left' else[-xx.T for xx in x]
        for a in range(45):
            expected=dec(J['q_projection_candidate'][r]['plane_'+ch][a]);zero(K[a]-expected)
            degree={(mon) for v in K[a].todok().values() for mon,co in s.Poly(v,g,xi,eta).terms() if co}
            assert degree<=({(3,0,2)} if r==0 else{(3,2,0)})
            for jet in ['p','q','s']:
                base=list(map(dec,C[key][r][jet]));old=g**3*sum((RC[c,a]*base[c] for c in range(45) if RC[c,a]),s.zeros(16))
                value=sum((RC[c,a]*K[c] for c in range(45) if RC[c,a]),s.zeros(16)) if jet=='q' else s.zeros(16)
                zero(value-dec(D['candidate'][r]['ucPP_image'][ch][jet][a]));zero(dec(P['amplitudes'][r][ch]['total'][jet][a])+old+value)
                if ch=='left':ctrl['omit_vertex_'+jet]+=nz(value);ctrl['reverse_vertex_'+jet]+=nz(2*value)
                positions+=512
            zero(dec(D['companions'][r][ch]['rho_BPP'][a])+s.I*K[a]);positions+=256
            if ch=='left':ctrl['omit_rho_BPP']+=nz(K[a])
        for b in range(45):
            for c in range(45):
                G=g*(K[b]*Tp[c]-Tp[c]*K[b]-s.I*sum((f*K[a] for a,f in fc[b,c]),s.zeros(16)))
                zero(G-dec(D['companions'][r][ch]['u_BC_PP_new_vertex'][b][c]));positions+=256
                S=g**4*(x[c]*Tp[b]-Tp[b]*x[c])
                zero(G+S-dec(D['companions'][r][ch]['u_BC_PP_total_with_old_source'][b][c]));positions+=256
                if ch=='left':ctrl['omit_nonlinear_QB']+=nz(dec(D['companions'][r][ch]['QB_nonlinear_part'][b][c]))
        if ch=='left':
            for h in range(12):
                Th=sum((RC[c,h]*T[c] for c in range(45) if RC[c,h]),s.zeros(16))
                for b in range(45):
                    transverse=sum((RC[c,h]*dec(D['companions'][r][ch]['u_BC_PP_new_vertex'][b][c]) for c in range(45) if RC[c,h]),s.zeros(16));zero(transverse)
            for a in range(45):zero(K[a]-K[a].H);zero(KK['right'][a]+K[a].T)
    # Original ordinary rho*PP is unchanged: the new term contains B.
    Q=load(O.parent/'canonical_so10_probe_fermion_onejet/replay_tables.json.gz');F=dec(C['F'][r])
    for ch,FF in [('left',F),('right',F.T)]:
        zero(dec(Q['amplitudes'][r][ch]['total']['p'])+s.I*FF);zero(dec(Q['amplitudes'][r][ch]['total']['q'])+s.I*FF/2)
    diag={'full_ucPP_p_q_s_both_chiralities_zero':True,'ordinary_rho_PP_and_old_K_source_projections_preserved':True,'g3_times_one_width_squared_only':True,'real_plane_Hermiticity_and_right_conjugation':True,'twelve_actual_H_covariance_contractions_zero':True,'rho_BPP_and_uBCPP_quantum_measured':False}
    controls.append(dict(ctrl));diagnostics.append(diag)
assert all(D['generic_checks'].values()) and D['old_kinetic_source_mass_hatted_and_boundaries_unchanged'] and not D['rho_BPP_and_uBCPP_quantum_measured'] and not D['physical_scheme_or_canonical_action_adopted'] and not D['full_QAP_or_authority_changed']
print('RESULT '+json.dumps({'schema':'EVEN_PROBE_GAUGE_VERTEX_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'matrix_positions_checked_including_zeros':positions,'controls':controls,'diagnostics':diagnostics,'all_new_companions_retained':True,'counterterm_construction_not_independent_quantum_measurement':True,'full_QAP_or_authority_changed':False,'shared_action_frames_quantum_premises_software_AI_author':True},sort_keys=True),flush=True);timer.cancel()
