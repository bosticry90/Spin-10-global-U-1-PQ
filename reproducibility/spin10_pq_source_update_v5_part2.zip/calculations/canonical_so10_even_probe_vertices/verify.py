from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,sys,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'primary_tables.json.gz');Z=load(O/'replay_tables.json.gz')
for key in ['names','parities','quadratic_transfer','currents','selected_densities','selection_counts','block_transfer_counts']:assert P[key]==Z[key],key
A=Algebra(P['names'],P['parities']);u=[A.index['mw_u'+str(i)] for i in range(2)];k=[A.index['mw_q'+str(i)] for i in range(4)];l=[A.index['ev_l'+str(i)] for i in range(4)];st=[A.index['ev_s'+str(i)] for i in range(4)]
bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];cn=[A.index['C'+str(i)] for i in range(45)]
def add(*pp):
 out={}
 for p in pp:
  for key,c in p.items():put(out,key,c)
 return out
def unpack(pkt):
 cc=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in row) for row in pkt['coefficients']]
 return {(g,tuple((n,tuple(j)) for n,j in w)):cc[c] for g,w,c in pkt['monomials']}
def elem(n):return {(0,((n,()),)):ONE}
def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
def mul(*pp):
 p=scalar(1)
 for q in pp:p=A.product(p,q)
 return p
def sub(p,mp):
 out={}
 for(g,w),c in p.items():
  z={(g,()):c}
  for n,j in w:assert not j;z=mul(z,mp.get(n,elem(n)))
  out=add(out,z)
 return out
M=[{(i,j):unpack(p) for i,j,p in rr} for rr in P['quadratic_transfer']]
old=load(O.parent/'canonical_so10_probe_auxiliary_resolvent/primary_tables.json.gz')
for r in range(2):
 zeroS={n:{} for n in st};actual={ij:sub(p,zeroS) for ij,p in M[r].items()};actual={ij:p for ij,p in actual.items() if p}
 expected={(i,j):sub(unpack(p),{k[i]:elem(l[i]) for i in range(4)}) for i,j,p in old['U_symbols'][r]};expected={ij:p for ij,p in expected.items() if p}
 assert actual==expected,'LATE_CONSTANT_U_PAR_LIMIT_MISMATCH'
compact=[];ghost=[];scalars=[];erased=[];distinguish=[]
bset={n for bb in bn for n in bb};lset=set(ln);gset=set(an+cn)
for r in range(2):
 pred={};uu=elem(u[r]);w=scalar('eta_H' if r==0 else 'xi')
 for c in (range(12) if r==0 else range(12,45)):
  for mu in range(4):
   kk=add(elem(l[mu]),elem(st[mu]))
   for nu in range(4):pred[bn[c][mu],bn[c][nu]]=mul(scalar(-2),uu,kk,elem(l[nu]))
   pred[bn[c][mu],ln[c]]=mul(uu,w,kk);pred[ln[c],bn[c][mu]]=mul(scalar(-1),uu,w,elem(l[mu]))
  pred[ln[c],ln[c]]=mul(scalar('1/2'),uu,w,w)
 actual={ij:p for ij,p in M[r].items() if ij[0] in bset|lset and ij[1] in bset|lset}
 compact.append(actual==pred)
 gg={ij:p for ij,p in M[r].items() if ij[0] in gset or ij[1] in gset};ghost.append(sum(len(p) for p in gg.values()))
 scalars.append(sum(len(p) for(i,j),p in M[r].items() if i not in bset|lset|gset or j not in bset|lset|gset))
 erased.append(sum(len(add(p,scale(sub(p,{n:{} for n in st}),-1))) for p in M[r].values()))
 cur=P['currents'][r];cc={key:{tuple(row[:3]):unpack(row[3]) for row in cur[key]} for key in cur}
 distinguish.append(sum(len(add(cc['AC'].get(ij,{}),scale(cc['AU'].get(ij,{}),-1))) for ij in set(cc['AC'])|set(cc['AU'])))
for obj in [P,Z]:assert obj['all_four_Lorentz_components_checked'] and obj['u_C_transfers_kept_independent'] and not obj['new_quantum_coefficients_measured'] and not obj['authority_changed']
# Natural finite-matrix ordering control for the longitudinal5x5 blocks.
qv=s.Matrix([1,0,0,0]);lv=s.Matrix([0,1,0,0]);ww=s.symbols('w');G=lambda v:((s.eye(4)+(ww-1)*v*v.T).row_join(-v)).col_join(v.T.row_join(s.zeros(1)))
UU=(-2*qv*lv.T).row_join(ww*qv).col_join((-ww*lv.T).row_join(s.Matrix([[ww**2/2]])))
ordered=-G(qv)*UU*G(lv);wrong=-UU*G(qv)*G(lv);order_sensitive=len(s.SparseMatrix((ordered-wrong).applyfunc(s.expand)).todok());assert order_sensitive>0
print('RESULT '+json.dumps({'schema':'EVEN_PROBE_VERTICES_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'two_full_density_vs_Euler_routes_agree':True,'late_constant_PAR_symbol_limit_matches':True,'compact_bosonic_factorization_matches_all_colors':compact,'ghost_finite_transfer_g_word_positions':ghost,'other_scalar_finite_transfer_positions':scalars,'erasing_u_transfer_changes_quadratic_positions':erased,'merging_C_and_u_current_jets_changes_positions':distinguish,'finite_matrix_wrong_order_sensitive_positions':order_sensitive,'block_transfer_counts':P['block_transfer_counts'],'new_fermion_loop_or_full_QAP_claim':False,'authority_changed':False,'shared_action_reference_algebra_AI_author':True},sort_keys=True),flush=True);timer.cancel()
