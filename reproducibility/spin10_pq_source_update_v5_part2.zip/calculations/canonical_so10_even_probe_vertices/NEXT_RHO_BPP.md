# Next actual quantum dependency: first-rho*BPP, zero ordinary jets

This is a target note, not an executed or preauthorized historical run.
Freeze a new bounded continuation after recovering current evidence and
confirming QVC1 validation. The completed three-jet calculation does not
supply this quantum input, and the new counterterm image is not its value.

The new local vertex has a nonzero rho*BPP image -i K_rb. Thus measuring the
actual first-rho*BPP bare insertion is the smallest direct test of whether
the SAME local correction extends beyond its previously matched ordinary
rho*PP, K-source and u*C*PP projections. Retain both probes, chiralities,
all 45 vector directions, and the physical/real-plane frame distinction.
This target has zero ordinary external jets by mass-independent dimension
counting; it is not a finite heat/contact or massive physical amplitude.

First classify the actual action support, before integrating. Candidate
one-loop cycles include the prior rhoG triangle with an additional gauge
emission on its fermion, ghost or bosonic edge, and the actual rhoG aBB
vertex with one external B. Mixed B/Lambda propagation and any marginal
auxiliary/vector cubic vertices must be checked explicitly. This list is
a question to test for completeness, not a declared proven inventory.

Reuse authenticated physical_G, gauge-fixing density, Tminus, plane_f and
frame inputs. Derive literal versus Euler rhoG vertices, complete relevant
bosonic cubic symbols and ordinary ghost currents from those classical
inputs. Establish exclusions using actual field roles, positive dimensions
and a bridgeless one-loop cycle. Do not infer that scalar/auxiliary paths
vanish from the external field names. Keep E_C/E_S/E_P roles until actual
hatted endpoint/jet bounds justify a deletion. Any reused hatted numerator,
Clifford convention or analytic domain must be named as inherited evidence.

Measure the complete allowed tensor independently, then compare it with
the unchanged old counterterm plus the retained -i K image. Do not recover
the unknown quantum answer from that image, from a desired Ward cancellation,
or by assuming full Q_full nilpotence at finite hats. Preserve nonzero
remainders and distinguish missing inputs, failed candidates and genuine
obstructions within a complete declared counterterm domain.

The separately retained u*C*BPP program and its quantum comparison remain
another obligation. A successful rho*BPP comparison would not establish
their equality, the full finite QAP, local-background completion, global
measure/phase consistency, massive thresholds, physical unification or
E5/A5. kappa,b0,chi4 remain distinct and unselected. Current protected
authority and blocked-stage boundaries stay unchanged.
