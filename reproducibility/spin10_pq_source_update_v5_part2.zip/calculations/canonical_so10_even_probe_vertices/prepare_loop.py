from pathlib import Path
from hashlib import sha256
import gzip,json,ast
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;F=O.parent/'canonical_so10_probe_fermion_onejet';G=O.parent/'canonical_so10_ghost_triangle_field_insertion'
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
v=read(O/'validation_receipt.json');assert v['compact_bosonic_factorization_matches_all_colors']==[True,True] and v['ghost_finite_transfer_g_word_positions']==[0,0] and v['other_scalar_finite_transfer_positions']==[0,0]
b=dict(read(O/'validation_preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
for role in ['primary','replay']:
 ep=O/(role+'_tables.json.gz');fp=F/(role+'_inputs.json.gz');gp=G/(role+'_tables.json.gz');gr=G/'qualified_reference_inputs.json.gz'
 assert H(fp)==read(F/'validation_preparation.json')['input_sha256'][str(fp.resolve())]
 for p in [gp,gr]:assert H(p)==read(G/'validation_preparation.json')['input_sha256'][str(p.resolve())]
 for p in [ep,fp,gp,gr]:b[str(p)]=H(p)
 e=load(ep);f=load(fp);old=load(gp);ref=load(gr)
 data={'frame':f['frame'],'Tminus':f['Tminus'],'new_currents':e['currents'],'baseline_GF':{a:old[n] for a,n in [('V','plane_V'),('A','plane_A'),('H','plane_H')]},'plane_f':ref['reference_fields']['plane_f'],'extraction':'CLASSICAL_VERTICES_FRAMES_ONLY_NO_COUNTERTERM_OR_EXPECTED_LOOP_TARGETS'}
 dst=O/('loop_'+role+'_inputs.json.gz')
 with dst.open('xb') as ff:ff.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for folder,names in {'canonical_so10_gauge_fermion_insertion':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_ghost_triangle_field_insertion':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_matter_breaking_support':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json']}.items():
 for n in names:p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['LOOP_RECORD.md','loop.py','prepare_loop.py','verify_loop.py','run_loop.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as ff:ff.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
for p in [O/'validation_receipt.json',O/'validation_preparation.json',F/'construction_tables.json.gz',F/'construction_receipt.json',F/'construction_check_receipt.json']:
 b[str(p)]=H(p)
assert H(F/'construction_tables.json.gz')==read(F/'construction_receipt.json')['packed_sha256']
nb={str(p):H(p) for p in [R/'AGENTS.md',R/'project_state.json',O/'loop.py',O/'loop_primary_inputs.json.gz',O/'loop_replay_inputs.json.gz']}
with(O/'loop_preparation.json').open('xb') as ff:ff.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':32*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_EUL1',len(b))
