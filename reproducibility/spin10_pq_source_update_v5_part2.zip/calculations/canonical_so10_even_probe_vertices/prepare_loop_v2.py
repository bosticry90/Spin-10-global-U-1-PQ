from pathlib import Path
from hashlib import sha256
import json,ast
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest()
prep=json.loads((O/'loop_preparation.json').read_bytes());b=dict(prep['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
for name in ['LOOP_CORRECTION_V2.md','generate_loop_v2.py','prepare_loop_v2.py','loop_v2.py','verify_loop_v2.py','run_loop_v2.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(O/(name+'.source.txt'))
for name in ['loop_preparation.json','loop_preparation_capture.json','loop_primary_capture.json','loop_failure.json']:b[str(O/name)]=H(O/name)
nb=dict(prep['native_input_sha256']);del nb[str(O/'loop.py')];nb[str(O/'loop_v2.py')]=H(O/'loop_v2.py')
with(O/'loop_preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':prep['limits'],'original_zero_polynomial_failure_preserved':True,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_EUL1_V2',len(b))
