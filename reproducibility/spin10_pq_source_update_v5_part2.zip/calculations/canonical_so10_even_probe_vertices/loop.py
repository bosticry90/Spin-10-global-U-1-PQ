from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1]
prep=read(O/'loop_preparation.json')
for p,h in prep['native_input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.name=='construction_tables.json.gz' or(p.parent.resolve()==O and p.name==('loop_replay_tables.json.gz' if role=='primary' else 'loop_primary_tables.json.gz')):raise PermissionError('EUL_TARGET_OR_PEER_DENIED')
  if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   assert p.resolve()==O/('loop_'+role+'_tables.json.gz')
sys.addaudithook(guard)
d=load(O/('loop_'+role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};I16=s.eye(16)
dec=lambda x:s.SparseMatrix(*x['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in x['entries']})
enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(s.expand(z))] for(i,j),z in sorted(s.SparseMatrix(M).todok().items()) if s.expand(z)!=0]}
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
def clean(tab):return {key:s.expand(v) for key,v in tab.items() if s.expand(v)!=0}
def cp(pkt):
 out=0
 for power,word,cid in pkt['monomials']:
  assert not word
  for xp,hp,mask,n,den in pkt['coefficients'][cid]:
   v=s.Rational(n,den)*g**power*xi**xp*eta**hp
   for k,p in enumerate([2,3,5,7]):
    if mask&(1<<k):v*=s.sqrt(p)
   if mask&16:v*=s.I
   out+=v
 return s.expand(out)
TP=list(map(dec,d['Tminus']));fr=d['frame'];order=fr['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]
Ti=dec(fr['physical_to_raw_inverse']);Q=dec(fr['Q']);Ad=dec(fr['Adual'])
block=lambda names:Ti.extract([order.index(n) for n in names],[phys.index(n) for n in names])
RC=(Q*block(['C'+str(i) for i in range(45)])).applyfunc(s.expand);RB=(Q*block([f'B{i}_0' for i in range(45)])).applyfunc(s.expand)
RA=(Ad*block([('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)])).applyfunc(s.expand);RL=(Ad*block([('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)])).applyfunc(s.expand)
zero(RC*RA.T-s.eye(45));zero(RB*RL.T-s.eye(45));zero(RB-RC);zero(RB*RB.T-s.eye(45))
TB=[sum((RB[k,a]*TP[k] for k in range(45) if RB[k,a]),s.zeros(16)).applyfunc(s.expand) for a in range(45)];TC=[sum((RC[k,a]*TP[k] for k in range(45) if RC[k,a]),s.zeros(16)).applyfunc(s.expand) for a in range(45)]
W=s.diag(*([eta]*12+[xi]*33));base={key:{tuple(row[:3]):s.sympify(row[3],locals=loc)*(xi if key=='H' else g) for row in d['baseline_GF'][key]} for key in ['V','A','H']};new=[{key:{tuple(row[:3]):cp(row[3]) for row in tab[key]} for key in ['V','AC','AU','H']} for tab in d['new_currents']]
row=lambda M:{i:[(j,v) for(ii,j),v in M.todok().items() if ii==i] for i in range(45)}
rb,ra,rc,rl=map(row,[RB,RA,RC,RL])
def transport(tab,L):
 out=defaultdict(lambda:s.S.Zero)
 for(b,a,c),v in tab.items():
  for bb,x in L[b]:
   for aa,y in ra[a]:
    for cc,z in rc[c]:out[bb,aa,cc]+=v*x*y*z
 return clean(out)
basephys={key:transport(tab,rl if key=='H' else rb) for key,tab in base.items()} if role=='primary' else {}
@lru_cache(None)
def pair(b,a,right,rev):
 B=-TB[b].T if right else TB[b];C=-TC[a].T if right else TC[a]
 if role=='primary':return B*C if not rev else C*B
 out=s.zeros(16)
 for i in range(45):
  if not RB[i,b]:continue
  for j in range(45):
   if not RC[j,a]:continue
   A0=-TP[i].T if right else TP[i];B0=-TP[j].T if right else TP[j]
   out+=RB[i,b]*RC[j,a]*(A0*B0 if not rev else B0*A0)
 return out.applyfunc(s.expand)
def contract_phys(tab,weight,right,rev):
 out=[s.zeros(16) for _ in range(45)];wr=defaultdict(list)
 for(b,r),v in s.SparseMatrix(weight).todok().items():wr[r].append((b,v))
 for(r,a,c),v in tab.items():
  for b,x in wr[r]:out[c]+=x*v*pair(b,a,right,rev)
 return [M.applyfunc(s.expand) for M in out]
def contract_base(key,physicalweight,right,rev,mixed=False):
 if role=='primary':return contract_phys(basephys[key],physicalweight,right,rev)
 pw=(RB*physicalweight*(RL.T if mixed else RB.T)).applyfunc(s.expand);gens=[-T.T for T in TP] if right else TP;out=[s.zeros(16) for _ in range(45)];wr=defaultdict(list)
 for(b,r),v in s.SparseMatrix(pw).todok().items():wr[r].append((b,v))
 for(r,a,c),v in base[key].items():
  for b,x in wr[r]:out[c]+=x*v*(gens[b]*gens[a] if not rev else gens[a]*gens[b])
 return [sum((RC[c,j]*out[c] for c in range(45) if RC[c,j]),s.zeros(16)).applyfunc(s.expand) for j in range(45)]
fc=defaultdict(list)
for a,b,k,v in d['plane_f']:fc[a,b].append((k,s.sympify(v)))
def edge(DB,right):
 if role=='primary':
  B=[-T.T for T in TB] if right else TB;C=[-T.T for T in TC] if right else TC
  return [sum((v*B[b]*C[a]*B[c] for(b,c),v in s.SparseMatrix(DB).todok().items()),s.zeros(16)).applyfunc(s.expand) for a in range(45)]
 DP=(RB*DB*RB.T).applyfunc(s.expand);gens=[-T.T for T in TP] if right else TP;CD=sum((v*gens[b]*gens[c] for(b,c),v in s.SparseMatrix(DP).todok().items()),s.zeros(16));out=[]
 for a in range(45):
  coeff=defaultdict(lambda:s.S.Zero)
  for(b,c),v in s.SparseMatrix(DP).todok().items():
   for u,f in fc[c,a]:
    for z,h in fc[b,u]:coeff[z]-=v*f*h
  DD=sum((v*gens[z] for z,v in clean(coeff).items()),s.zeros(16));out.append((CD*gens[a]+gens[a]*CD-DD)/2)
 return [sum((RC[c,j]*out[c] for c in range(45) if RC[c,j]),s.zeros(16)).applyfunc(s.expand) for j in range(45)]
eps,h=s.symbols('epsilon h');D=4-2*eps;finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0));I0=finite(h*s.gamma(1+eps)/4);J=finite(h*s.gamma(1+eps)/24);Jbad=finite(h*(D+2)*s.gamma(1+eps)/(24*D))
if role=='primary':
 K,k,p,q,ss=s.symbols('K k p q ss');r1=K-2*k*p+p*p;lB1=K-2*k*(p+q+ss)+(p+q+ss)**2;lG1=K-2*k*(p+q)+(p+q)**2;r2=lB1;lB2=r1;lG2=K-2*k*(p+ss)+(p+ss)**2
 Vrat=[(k-p-q-ss)*lG1/(K*r1*lB1*lG1),(k-p)*lG2/(K*r2*lB2*lG2)];Arat=[(k-p-q-ss)*(k*q-(p+q)*q)/(K*r1*lB1*lG1),-(k-p)*(k*q-(p+ss)*q)/(K*r2*lB2*lG2)]
 def moment(z,joint):
  out=0
  for mon,v in s.Poly(s.expand(s.cancel(z*K**4)),K,k).terms():assert mon in [(1,0),(0,2)];out+=v*(I0 if mon==(1,0) else joint)
  return s.simplify(out)
 def times(joint):return [[moment(s.diff(v,t).subs({p:0,q:0,ss:0}),joint) for t in [p,q,ss]] for v in Vrat],[[moment(s.diff(v,t).subs({p:0,q:0,ss:0}),joint) for t in [p,q,ss]] for v in Arat]
else:
 y,z,p,q,ss=s.symbols('y z p q ss');simp=lambda v:s.integrate(s.integrate(v,(z,0,1-y)),(y,0,1));area=simp(1);my=simp(y);mz=simp(z);reg=h*s.gamma(1+eps)/2
 a=finite(reg*(my*p+mz*(p+q+ss)-area*(p+q+ss)));b=finite(reg*(my*(p+q+ss)+mz*p-area*p))
 fixed=[[s.diff(v,t) for t in [p,q,ss]] for v in [a,b]]
 def times(joint):
  if joint==J:return fixed,[[0,J,0],[0,-J,0]]
  return [[-I0+4*joint,-I0+2*joint,-I0+2*joint],[-I0+4*joint,2*joint,2*joint]],[[0,joint,0],[0,-joint,0]]
tt,at=times(J);badtt,badat=times(Jbad)
assert tt==[[s.Rational(1,6),s.Rational(1,3),s.Rational(1,3)],[s.Rational(1,6),-s.Rational(1,6),-s.Rational(1,6)]]
print('STAGE '+role+' independent_four_denominator_or_simplex_three_jet_kernels_complete',flush=True)
allparts=[];cores=[]
for r in range(2):
 w=eta if r==0 else xi;proj=s.diag(*([1 if (i<12)==(r==0) else 0 for i in range(45)]));DB=w*w*proj/2;DM=w*proj;cr={}
 for right in [False,True]:
  cr[right]={}
  for rev in [False,True]:
   cr[right][rev]={
    'newV':contract_phys(new[r]['V'],W,right,rev),'newAC0':contract_phys(new[r]['AC'],s.eye(45),right,rev),'newAC1':contract_phys(new[r]['AC'],W-s.eye(45),right,rev),'newAU0':contract_phys(new[r]['AU'],s.eye(45),right,rev),'newAU1':contract_phys(new[r]['AU'],W-s.eye(45),right,rev),'newH':contract_phys(new[r]['H'],s.eye(45),right,rev),
    'oldV':contract_base('V',DB,right,rev),'oldA':contract_base('A',DB,right,rev),'oldH':contract_base('H',DM,right,rev,True)}
  cr[right]['edge']=edge(DB,right)
 cores.append(cr)
def assemble(r,joint,tv,ta):
 result={}
 for right in [False,True]:
  cr=cores[r][right];pieces={name:{jet:[s.zeros(16) for _ in range(45)] for jet in ['p','q','s']} for name in ['new_current','old_BB_insertion','old_BL_insertion','gauge_edge']}
  for c in range(45):
   for ii,rev in enumerate([False,True]):
    co=cr[rev];sign=1 if ii==0 else -1
    for jj,jet in enumerate(['p','q','s']):
     nv=-s.I*tv[ii][jj]*co['newV'][c]+s.I*tv[ii][jj]*co['newH'][c]
     if jet in ['q','s']:
      key='AC' if jet=='q' else'AU';nv+=-s.I*sign*(I0*co['new'+key+'0'][c]+joint*co['new'+key+'1'][c])
     pieces['new_current'][jet][c]+=g*g*nv
     pieces['old_BB_insertion'][jet][c]+=-s.I*g*g*(tv[ii][jj]*co['oldV'][c]+ta[ii][jj]*co['oldA'][c])
     pieces['old_BL_insertion'][jet][c]+=s.I*g*g*tv[ii][jj]*co['oldH'][c]
   pieces['gauge_edge']['q'][c]=g**3*(-2*joint)*cr['edge'][c]
  pieces={name:{jet:[enc(M) for M in mm] for jet,mm in jets.items()} for name,jets in pieces.items()}
  total={jet:[enc(sum((dec(pieces[name][jet][c]) for name in pieces),s.zeros(16))) for c in range(45)] for jet in ['p','q','s']}
  result['right' if right else'left']={'total':total,'pieces':pieces}
 return result
actual=[assemble(r,J,tt,at) for r in range(2)];wrongangle=[assemble(r,Jbad,badtt,badat) for r in range(2)]
print('STAGE '+role+' all_action_families_and_all_coupling_orders_assembled',flush=True)
out={'schema':'EVEN_PROBE_FERMION_THREE_JET_V1','role':role,'RC':enc(RC),'RA':enc(RA),'RB':enc(RB),'RL':enc(RL),'Taylor_V':[[str(v) for v in row] for row in tt],'Taylor_A':[[str(v) for v in row] for row in at],'I0':str(I0),'J':str(J),'wrong_J':str(Jbad),'amplitudes':actual,'wrong_unweighted':wrongangle,'no_ghost_scalar_insertion_by_complete_finite_transfer':True,'all_gauge_ghost_current_and_propagator_families_exact_once':True,'counterterm_target_read':False,'full_QAP_measure_phase_or_physical_matching':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('loop_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
