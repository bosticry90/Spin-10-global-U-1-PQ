from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import gzip,json,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'loop_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'loop_primary_tables.json.gz');Z=load(O/'loop_replay_tables.json.gz');g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']})
enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(s.expand(z))] for(i,j),z in sorted(s.SparseMatrix(M).todok().items()) if s.expand(z)!=0]}
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
def nz(M):return len(s.SparseMatrix(M).applyfunc(s.expand).todok())
for key in ['RC','RA','RB','RL','Taylor_V','Taylor_A','I0','J','wrong_J']:assert P[key]==Z[key],key
assert P['Taylor_V']==[['1/6','1/3','1/3'],['1/6','-1/6','-1/6']] and P['Taylor_A']==[['0','-1/12','0'],['0','1/12','0']]
for obj in [P,Z]:
 assert obj['no_ghost_scalar_insertion_by_complete_finite_transfer'] and obj['all_gauge_ghost_current_and_propagator_families_exact_once'] and not obj['counterterm_target_read'] and not obj['authority_changed'] and not obj['full_QAP_measure_phase_or_physical_matching']
counts=[];controls=[];compared=0
for r in range(2):
 ct=Counter();ctrl=Counter()
 for ch in ['left','right']:
  for jet in ['p','q','s']:
   for a in range(45):
    M=dec(P['amplitudes'][r][ch]['total'][jet][a]);zero(M-dec(Z['amplitudes'][r][ch]['total'][jet][a]));compared+=256;ct[ch+'_'+jet]+=nz(M)
    parts={name:dec(dd[jet][a]) for name,dd in P['amplitudes'][r][ch]['pieces'].items()}
    zero(M-sum(parts.values(),s.zeros(16)))
    for name,V in parts.items():zero(V-dec(Z['amplitudes'][r][ch]['pieces'][name][jet][a]));compared+=256
    if ch=='left':
     ctrl['omit_new_current_'+jet]+=nz(parts['new_current']);ctrl['omit_Lambda_squared_'+jet]+=nz(parts['old_BB_insertion']+parts['gauge_edge']);ctrl['double_quad_insertion_'+jet]+=nz(parts['old_BB_insertion']+parts['old_BL_insertion']+parts['gauge_edge']);ctrl['omit_mixed_propagator_'+jet]+=nz(parts['old_BL_insertion'])
     bad=dec(P['wrong_unweighted'][r][ch]['total'][jet][a]);zero(bad-dec(Z['wrong_unweighted'][r][ch]['total'][jet][a]));ctrl['unweighted_angle_'+jet]+=nz(M-bad)
     ct['g2_'+jet]+=nz(M.applyfunc(lambda z:s.expand(z).coeff(g,2)));ct['g3_'+jet]+=nz(M.applyfunc(lambda z:s.expand(z).coeff(g,3)))
 for a in range(45):
  lp,lq,ls=[dec(P['amplitudes'][r]['left']['total'][j][a]) for j in ['p','q','s']];rp,rq,rs=[dec(P['amplitudes'][r]['right']['total'][j][a]) for j in ['p','q','s']]
  zero(rp-lp.T);zero(rq-(lp-lq).T);zero(rs-(lp-ls).T);ctrl['merge_q_s']+=nz(lq-ls)
 counts.append(dict(ct));controls.append(dict(ctrl))
print('STAGE verifier full_quantum_families_three_jets_and_chiralities_agree_before_counterterm',flush=True)
# Existing correction is read only AFTER independent full quantum comparison.
C=load(O.parent/'canonical_so10_probe_fermion_onejet/construction_tables.json.gz');RC=dec(P['RC']);RA=dec(P['RA']);inp=load(O/'loop_primary_inputs.json.gz');TP=list(map(dec,inp['Tminus']));fc=defaultdict(list)
for a,b,k,z in inp['plane_f']:fc[a,b].append((k,s.sympify(z)))
remainders=[];remcounts=[];candidate=[];diagnostics=[]
for r in range(2):
 rr={};nn={}
 for ch,key in [('left','left_ucPP'),('right','right_ucPP')]:
  rr[ch]={}
  for jet in ['p','q','s']:
   orig=list(map(dec,C[key][r][jet]));target=[g**3*sum((RC[c,a]*orig[c] for c in range(45) if RC[c,a]),s.zeros(16)) for a in range(45)]
   residual=[(dec(P['amplitudes'][r][ch]['total'][jet][a])+target[a]).applyfunc(s.expand) for a in range(45)]
   rr[ch][jet]=list(map(enc,residual));nn[ch+'_'+jet]=sum(nz(M) for M in residual)
 remainders.append(rr);remcounts.append(nn)
 KP=[-dec(z) for z in rr['left']['q']];KR=[-dec(z) for z in rr['right']['q']];Kplane=[sum((RA.T[a,c]*KP[a] for a in range(45) if RA.T[a,c]),s.zeros(16)).applyfunc(s.expand) for c in range(45)]
 p_s_zero=all(nn[ch+'_'+jet]==0 for ch in ['left','right'] for jet in ['p','s']);herm=sum(nz(M-M.H) for M in Kplane);right=sum(nz(KR[a]+KP[a].T) for a in range(45));hcov=[]
 for hh in range(12):
  TH=sum((RC[k,hh]*TP[k] for k in range(45) if RC[k,hh]),s.zeros(16));rem=0
  for a in range(45):
   act=TH*Kplane[a]-Kplane[a]*TH
   for k in range(45):
    if not RC[k,hh]:continue
    for b,f in fc[k,a]:act-=s.I*RC[k,hh]*f*Kplane[b]
   rem+=nz(act)
  hcov.append(rem)
 candidate.append({'physical_left':list(map(enc,KP)),'plane_left':list(map(enc,Kplane)),'physical_right':list(map(enc,KR))})
 diagnostics.append({'p_s_remainders_zero':p_s_zero,'q_vertex_plane_Hermiticity_remainder_positions':herm,'q_vertex_right_conjugation_remainder_positions':right,'q_vertex_global_H_remainder_positions':hcov,'q_only_gauge_vertex_route_available':p_s_zero and herm==right==0 and not any(hcov)})
packet={'schema':'EVEN_PROBE_THREE_JET_COMPARISON_V1','remainders':remainders,'q_projection_candidate':candidate,'diagnostics':diagnostics,'new_gauge_counterterm_implemented_or_physical_scheme_adopted':False,'rho_BPP_quantum_companion_measured':False}
raw=(json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'loop_comparison_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'schema':'EVEN_PROBE_FERMION_THREE_JET_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'complete_quantum_positions_compared':compared,'nonzero_positions':counts,'controls':controls,'all_independent_quantum_arrays_agree':True,'late_PFJ_candidate_remainder_positions':remcounts,'q_projection_diagnostics':diagnostics,'comparison_packed_sha256':sha256(blob).hexdigest(),'comparison_raw_sha256':sha256(raw).hexdigest(),'all_sourcefree_probe_quantum_restoration_or_full_QAP':False,'authority_changed':False,'shared_action_GTT_GFI_normalization_software_AI_author':True},sort_keys=True),flush=True);timer.cancel()
