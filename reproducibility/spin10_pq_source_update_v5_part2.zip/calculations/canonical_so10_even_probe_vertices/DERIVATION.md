# EPV1: a local even probe carries its own transfer

In the actual density u*QG,let varied field i have momentum-k,field j+l,
and u have+s,where k=l+s. The full bilinear symbol is

 K_ij(k,l)=(-1)^[p_j(p_i+1)] sum_IJ (-ik)^I(il)^J
           partial_left,jJ partial_left,iI(u QG_E).

Equivalently take E_i=sum_I(-D)^I partial_left,iI(uQG_E),then its graded
linearization with second-field jet i*l and coefficient-u jet i*s. The
former formula retains two leg momenta;the latter exposes derivatives of
u explicitly. Their equality tests adjoints,odd signs and transfer routing.
At s0 this reduces to PAR1's qualified ordinary Hessian,not vice versa.

For a current u a C B,canonicalize the odd order as a C. Literal derivative
coefficients Ua,UB,UC,Uu obey conservation of all four incoming momenta.
Euler-a removes derivatives on the first odd field and yields

 u C*dB coefficient UB-Ua,
 u*dC*B coefficient UC-Ua,
 (du)*C*B coefficient Uu-Ua.

Thus V,AC,AU are their negatives and remain defined even when a total
derivative changes all literal coefficients. Do not replace AC and AU by
one tensor merely because the two labels meet at the same vertex.

The later propagator correction is the ORDERED -G0(k) K_u(k,l) G0(l).
The constant-u inverse is not enough to infer its s terms. Its bosonic,
ghost and possible other marginal blocks must all be assessed before a
loop-family exclusion. No new quantum coefficient is calculated here.
