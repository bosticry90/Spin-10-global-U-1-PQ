from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,time,threading,os,sympy as s

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'gauge_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']})
enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(s.expand(z))] for(i,j),z in sorted(s.SparseMatrix(M).todok().items()) if s.expand(z)!=0]}
clean=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def zero(M):assert not clean(M).todok()
def nz(M):return len(clean(M).todok())

def generic_density():
    # Nine ODD coordinates: barP(2),P(2),C(2),dC(2),rho(1).
    def add(*pp):
        out=defaultdict(lambda:s.S.Zero)
        for p in pp:
            for k,v in p.items():out[k]+=v
        return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
    def mul(p,q):
        out=defaultdict(lambda:s.S.Zero)
        for a,x in p.items():
            for b,y in q.items():
                if not a&b:out[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(9) if a&(1<<i))*x*y
        return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
    def word(ww,c=1):
        p={0:c}
        for i in ww:p=mul(p,{1<<i:1})
        return p
    u,B0,B1,gg=s.symbols('u B0 B1 gg');B=[B0,B1]
    K=[s.Matrix(2,2,s.symbols('k'+str(a)+'_0:4')) for a in range(2)]
    T=[s.Matrix(2,2,s.symbols('t'+str(a)+'_0:4')) for a in range(2)]
    f={(b,c,a):s.Symbol('f'+str(b)+str(c)+str(a)) for b in range(2) for c in range(2) for a in range(2)}
    qb={a:add(word([6+a]),*(word([4+c],gg*f[b,c,a]*B[b]) for b in range(2) for c in range(2))) for a in range(2)}
    qp={}
    for i in range(2):
        qp[2+i]=add(*(word([4+a,2+j],s.I*gg*T[a][i,j]) for a in range(2) for j in range(2)))
        qp[i]=add(*(word([4+a,j],-s.I*gg*T[a][j,i]) for a in range(2) for j in range(2)))
    def act(p):
        out={}
        for mask,v in p.items():
            ww=[i for i in range(9) if mask&(1<<i)]
            out=add(out,mul(word([8],s.diff(v,u)),word(ww)))
            for a in range(2):out=add(out,mul({k:z*s.diff(v,B[a]) for k,z in qb[a].items()},word(ww)))
            for at,i in enumerate(ww):
                if i in qp:out=add(out,mul(mul(word(ww[:at],v*(-1)**at),qp[i]),word(ww[at+1:])))
        return out
    density=add(*(word([i,2+j],-s.I*u*B[a]*K[a][i,j]) for a in range(2) for i in range(2) for j in range(2)))
    expected=add(*(add(word([8,i,2+j],-s.I*B[a]*K[a][i,j]),word([6+a,i,2+j],-s.I*u*K[a][i,j])) for a in range(2) for i in range(2) for j in range(2)))
    for b in range(2):
        for c in range(2):
            D=gg*(K[b]*T[c]-T[c]*K[b]-s.I*sum((f[b,c,a]*K[a] for a in range(2)),s.zeros(2)))
            expected=add(expected,*(word([4+c,i,2+j],u*B[b]*D[i,j]) for i in range(2) for j in range(2)))
    assert not add(act(density),{k:-v for k,v in expected.items()})
    return {'literal_nine_odd_coordinate_density_variation':True,'arbitrary_matrices_and_all_nonlinear_QB_terms':True,'no_IBP_or_commuting_fermion_substitution':True}

generic=generic_density()
P=load(O/'loop_primary_v2_tables.json.gz');C=load(O.parent/'canonical_so10_probe_fermion_onejet/construction_tables.json.gz')
inp=load(O/'loop_primary_inputs.json.gz');RC=dec(P['RC']);RA=dec(P['RA']);T=list(map(dec,inp['Tminus']));fc=defaultdict(list)
for b,c,a,z in inp['plane_f']:fc[b,c].append((a,s.sympify(z)))
candidate=[];companions=[];stats=[]
for r in range(2):
    Kr={};physical={};qq={}
    for ch,key in [('left','left_ucPP'),('right','right_ucPP')]:
        oldq=list(map(dec,C[key][r]['q']))
        physold=[g**3*sum((RC[c,a]*oldq[c] for c in range(45) if RC[c,a]),s.zeros(16)) for a in range(45)]
        physical[ch]=[clean(-dec(P['amplitudes'][r][ch]['total']['q'][a])-physold[a]) for a in range(45)]
        Kr[ch]=[clean(sum((RA.T[a,c]*physical[ch][a] for a in range(45) if RA.T[a,c]),s.zeros(16))) for c in range(45)]
        qq[ch]={j:[enc(physical[ch][a] if j=='q' else s.zeros(16)) for a in range(45)] for j in ['p','q','s']}
    for a in range(45):zero(Kr['right'][a]+Kr['left'][a].T);zero(Kr['left'][a]-Kr['left'][a].H)
    out={};ct={}
    for ch in ['left','right']:
        Tc=T if ch=='left' else[-Ta.T for Ta in T]
        xr=list(map(dec,C['x_source'][r]));xr=xr if ch=='left' else[-x.T for x in xr]
        gauge=[];total=[];nonlinear=[]
        for b in range(45):
            grow=[];trow=[];nrow=[]
            for c in range(45):
                nl=clean(-s.I*g*sum((f*Kr[ch][a] for a,f in fc[b,c]),s.zeros(16)))
                D=clean(g*(Kr[ch][b]*Tc[c]-Tc[c]*Kr[ch][b])+nl)
                S=clean(g**4*(xr[c]*Tc[b]-Tc[b]*xr[c]))
                grow.append(enc(D));trow.append(enc(D+S));nrow.append(enc(nl))
            gauge.append(grow);total.append(trow);nonlinear.append(nrow)
        rho=[enc(-s.I*K) for K in Kr[ch]]
        out[ch]={'rho_BPP':rho,'u_BC_PP_new_vertex':gauge,'u_BC_PP_total_with_old_source':total,'QB_nonlinear_part':nonlinear}
        ct[ch]={'K':sum(nz(K) for K in Kr[ch]),'rho_BPP':sum(len(z['entries']) for z in rho),'u_BC_new':sum(len(z['entries']) for rr in gauge for z in rr),'u_BC_total':sum(len(z['entries']) for rr in total for z in rr)}
    candidate.append({'plane':{ch:list(map(enc,Kr[ch])) for ch in Kr},'physical':{ch:list(map(enc,physical[ch])) for ch in physical},'ucPP_image':qq});companions.append(out);stats.append(ct)
    print('STAGE gauge construction probe '+str(r)+' full companions retained',flush=True)
packet={'schema':'EVEN_PROBE_GAUGE_VERTEX_CONSTRUCTION_V1','candidate':candidate,'companions':companions,'generic_checks':generic,'statistics':stats,'old_kinetic_source_mass_hatted_and_boundaries_unchanged':True,'rho_BPP_and_uBCPP_quantum_measured':False,'physical_scheme_or_canonical_action_adopted':False,'full_QAP_or_authority_changed':False}
raw=(json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'gauge_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'statistics':stats,'generic_checks':generic,'new_quantum_companions_measured_or_authority_changed':False},sort_keys=True),flush=True);timer.cancel()
