# EUL1 bounded continuation: complete first-u*C*PP quantum p,q,s tensor

EPV1 native/replay/verifier completed before this continuation. They derive
the full local-u quadratic symbol,including ghost/scalar zero complements:
ghost and scalar insertions vanish even at finite transfer. Both actual
bosonic kernels match the factorized form below on every color/component.
The new-current AC=AU=0 is measured,not imposed; heavy V/H remain nonzero.

For first/second leg momenta k,l and s=k-l,within each selected color,

 U_r(k,l)=[[-2 k_mu l_nu,w k_mu],[-w l_nu,w^2/2]],
 deltaG=-G0(k)U_r(k,l)G0(l)
       =[[w^2 k_mu l_nu/(2 k^2 l^2),-w k_mu/k^2],
         [w l_nu/l^2,-2]].

u multiplies this expression. The scalar products k^2,l^2 are not set equal.
This follows from direct matrix multiplication using each endpoint's own
momentum. It is a first-probe propagator derivative,not a new physical inverse.
Use explicit insertions OR this deltaG,never both. Omitting the quadratic
Lambda^2 vertex removes the BB update entirely and is a sensitive control.

Complete saturated first-u*C*PP one-jet graph content:
1. E+PPB+new uQG aCB/aLambdaC current triangles.
2. Old GF ghost triangles with one quadratic bosonic uQG insertion.
3. Paired gauge-fermion-edge E_P/E_S loops with that bosonic insertion.
Ghost/scalar quadratic insertions are excluded by the COMPLETE finite-transfer
EPV1 symbols. No u matter vertex exists(CPS1). Marginal scalar-current triangles
cannot carry a single uncontracted Lorentz derivative; actual scalar/vev
coefficients reduce the jet budget. Higher-valence/extra unlabelled vertices
cannot fit a bridgeless one-loop cycle. Retain all actual coupling powers,
including potentially cancelling g10^2 terms; do not assume only g10^3.

Primary: full four-denominator rational Taylor before UV rearrangement,
actual physical vertices and ordered color products. Replay: exact
numerator/denominator reduction and shifted Schwinger moments,plane-basis
propagator transport and independent double-commutator gauge-edge reduction.
The bosonic/ghost frames and all orientation statistics are qualified PFJ/GTT
inputs; constants are not fitted to a counterterm. Internal hats and the
full-D endpoint prescription remain as in the inherited analytic domain.

First orientation uses ghost r=k-p,fermion k,boson at matter lB=k-p-q-s,
and at GF lG=k-p-q. Second uses ghost k-p-q-s,lB=k-p,lG=k-p-s.
The BB update gives gamma.lB*[V*lG^2 +/- A*(lG.q)]/(lB^2*lG^2).
Taylor its FULL rational form before canceling factors. V moments are
(p/6+(q+s)/3),(p/6-(q+s)/6). The A moment is +/-J*q only,J=-1/12.
There is no A*s term in the OLD GF vertex; u is on another node.
For a NEW current the external u and C share a vertex but retain independent
AC and AU; apply the ordinary three-denominator formula to each jet separately.

The paired gauge-edge numerator already supplies external-C momentum q.
Thus all other external transfers can be zero in that local one-jet term.
It contributes +g10^3 sum deltaW_bc Tb Ta Tc*q/6,deltaW=w^2 P_r/2,
with no p/s term. This uses the qualified GFI hatted numerator and action
normalization;it is not inferred from field counterterm images.

Freeze new sources and restricted classical inputs before execution. Native
workers are denied PFJ construction tables and peer outputs. The verifier
compares complete quantum arrays first;only THEN reads the existing PFJ
candidate and reports the complete p/q/s remainder,including all g powers.
A remainder is not an anomaly verdict. If only q remains,it may define a
new gauge-vertex correction without changing the previously matched rho*PP
or K-source projections;its correlated rho*BPP quantum test would remain.
Never force p/s to zero or divide by g to fit a desired result.

Sequential primary/replay/verifier600 seconds after imports each,8GiB sampled,
350MiB launch floor,whole EPV1+EUL1 packet32MiB. This is a NEW frozen full-loop
continuation,not an expansion of a failed EPV1 run. Preserve all failures,
unfinished results and complete captures. Test missing new currents,missing
Lambda^2 insertion,unweighted angular moments,merging q/s and double-counting
the propagator derivative;record insensitive controls honestly.

State113/34of39,custodyexit2/sevenNOTPASS unchanged. No agents,branches,
worktrees,push,outreach,publication,physical normalization/benchmark/scheme
adoption,flavor/HB1C5 activation or promotion. Shared action,normalization,
analytic reference/domain,software and AI author limit independence. Bare
selected comparison is not full finite QAP,measure/phase,physical matching
or E5/A5. If a bounded result completes,assess its actual next dependency.
