from pathlib import Path
import json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/even-probe-vertices-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
stage='gauge_check_preparation_v2'
try:
 p=subprocess.run([sys.executable,'-B',str(O/'prepare_gauge_check_v2.py')],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8');c={'native_exit':p.returncode,'stdout_and_stderr':p.stdout};dump(O/'gauge_check_preparation_v2_capture.json',c);dump(C/'gauge_check_preparation_v2_full_capture.json',c);print(p.stdout,flush=True);assert p.returncode==0
 stage='gauge_check_v2';c=capture([sys.executable,'-B',str(O/'check_gauge_v2.py')]);dump(O/'gauge_check_v2_capture.json',c);dump(C/'gauge_check_v2_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300
 dump(O/'gauge_validation_receipt_v2.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
except BaseException:
 dump(O/'gauge_check_failure_v2.json',{'stage':stage,'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
