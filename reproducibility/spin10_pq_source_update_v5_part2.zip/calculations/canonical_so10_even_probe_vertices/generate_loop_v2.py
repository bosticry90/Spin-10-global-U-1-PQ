from pathlib import Path
import ast
O=Path(__file__).resolve().parent
n=(O/'loop.py').read_text(encoding='utf-8').replace("'loop_preparation.json'","'loop_preparation_v2.json'").replace("'loop_'+role+'_tables.json.gz'","'loop_'+role+'_v2_tables.json.gz'").replace("'loop_replay_tables.json.gz' if role=='primary' else 'loop_primary_tables.json.gz'","'loop_replay_v2_tables.json.gz' if role=='primary' else 'loop_primary_v2_tables.json.gz'")
old="for mon,v in s.Poly(s.expand(s.cancel(z*K**4)),K,k).terms():assert mon in [(1,0),(0,2)];out+=v*(I0 if mon==(1,0) else joint)"
new="for mon,v in s.Poly(s.expand(s.cancel(z*K**4)),K,k).terms():\n   if v==0:continue\n   assert mon in [(1,0),(0,2)]\n   out+=v*(I0 if mon==(1,0) else joint)"
assert old in n;n=n.replace(old,new)
n=n.replace("def times(joint):return", "assert s.Poly(0,K,k).terms()==[((0,0),0)]\n def times(joint):return",1)
v=(O/'verify_loop.py').read_text(encoding='utf-8').replace("'loop_validation_preparation.json'","'loop_validation_preparation_v2.json'").replace("'loop_primary_tables.json.gz'","'loop_primary_v2_tables.json.gz'").replace("'loop_replay_tables.json.gz'","'loop_replay_v2_tables.json.gz'").replace("'loop_comparison_tables.json.gz'","'loop_comparison_v2_tables.json.gz'")
for name,src in [('loop_v2.py',n),('verify_loop_v2.py',v)]:
 ast.parse(src)
 with(O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(src)
