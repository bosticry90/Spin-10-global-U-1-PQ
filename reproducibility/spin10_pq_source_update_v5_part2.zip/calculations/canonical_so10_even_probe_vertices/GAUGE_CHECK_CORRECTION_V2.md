# QVC1 checker V2: stored right-frame schema and exact parsing cache

The constructor completed in 91.9434244s and its full tables/receipt survive.
The original checker FAILED with KeyError('plane_right') after its first
left-chiral checks. EUL1 stores physical_left, plane_left and physical_right;
it never claimed a stored plane_right. This is a checker schema error, not
a scientific mismatch or a completed validation. Preserve its exact source,
source copy, validation preparation, full capture and controller failure.

V2 changes only the checker. For the right comparison, transport the ACTUAL
stored physical_right using the authenticated RA.T, exactly as the left
plane frame was defined. Do not substitute -K_left.T for the right quantum
input. Both chiral inputs still enter independently before the conjugation
test. Cache SymPy parsing of identical immutable expression strings with
unchanged locals; this removes repeated deserialization, not comparisons.
Every matrix position, source/rho preservation, nonlinear QB, reality,
covariance and negative control remains. No constructor or quantum worker
is repeated. All earlier manifests and sources stay unchanged.

Freeze new sources and both failed/successful historical evidence before
the corrected check. Same 300s after imports/8GiB sampled/350MiB floor and
32MiB whole packet; no scientific or resource requirement is relaxed.
The failure remains FAILED even if the corrected checker completes.
