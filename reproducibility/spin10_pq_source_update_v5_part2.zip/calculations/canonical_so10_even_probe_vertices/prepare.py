from pathlib import Path
from hashlib import sha256
import json,gzip,ast,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;K=O.parent/'canonical_so10_probe_chiral_ghost_kernel';P=O.parent/'canonical_so10_probe_auxiliary_resolvent'
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='41ec6faa731dd1758cc9eac22c7f86ed06296916'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V592.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
for folder,names in {'canonical_so10_probe_fermion_onejet':['RESULT.md','NEXT_THREE_JETS.md','validation_receipt.json','construction_check_receipt.json'],'canonical_so10_probe_chiral_ghost_kernel':['DERIVATION.md','RESULT.md','validation_receipt_v2.json','validation_preparation_v2.json'],'canonical_so10_probe_auxiliary_resolvent':['DERIVATION.md','RESULT.md','validation_preparation_v2.json','validation_receipt_v2.json'],'canonical_so10_chiral_probe_support':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_two_probe_lifted_ward':['PROOF.md','validation_receipt_v2.json']}.items():files.extend(O.parent/folder/n for n in names)
assert H(O.parent/'canonical_so10_probe_fermion_onejet/validation_receipt.json')=='95ffc029fa652a459f62ac446607f6950122d86fc0ea727ee59ccbfc2d117dc0'
for role in ['primary','replay']:
 p=K/(role+'_inputs.json.gz');assert H(p)==read(K/'validation_preparation_v2.json')['input_sha256'][str(p.resolve())];files.append(p);d=load(p)
 data={n:d[n] for n in ['names','parities','physical_QG','geometry']};data['extraction']='ACTUAL_CLASSICAL_QG_ONLY_NO_NEW_LOOP_OR_COUNTERTERM_TARGETS'
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
 p=P/(role+'_tables.json.gz');assert H(p)==read(P/'validation_preparation_v2.json')['input_sha256'][str(p.resolve())];files.append(p)
for n in ['RECORD.md','DERIVATION.md','build_native.py','native.py','verify.py','prepare.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 files.extend([p,O/(n+'.source.txt')])
b={str(p):H(p) for p in set(files)};nb={str(p):H(p) for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'native.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz']}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'base':base,'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':300,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_EPV1',len(b))
