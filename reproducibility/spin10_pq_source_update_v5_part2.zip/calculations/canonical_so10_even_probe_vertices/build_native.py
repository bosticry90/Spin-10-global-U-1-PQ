from pathlib import Path
import ast
O=Path(__file__).resolve().parent
old=(O.parent/'canonical_so10_probe_auxiliary_resolvent/native.py').read_text(encoding='utf-8')
prefix=old[:old.index(' inp=')].replace('threading.Timer(120,','threading.Timer(300,')
prefix=prefix.replace(" A=Algebra(geo['names']+extra,geo['parities']+[0,0,1,1]+[1]*45+[0]*52)"," extra += ['ev_l'+str(i) for i in range(4)]+['ev_s'+str(i) for i in range(4)]\n A=Algebra(geo['names']+extra,geo['parities']+[0,0,1,1]+[1]*45+[0]*60)")
tail=r'''
 inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));assert inp['names']==list(A.names)[:-8]
 ls=[A.index['ev_l'+str(i)] for i in range(4)];ss=[A.index['ev_s'+str(i)] for i in range(4)];km={qs[i]:add(elem(ls[i]),elem(ss[i])) for i in range(4)}
 zeroS={n:{} for n in ss};bose=bset|set(ln);aset=set(an);cset=set(cn);dims={n:2 if n in ln else1 for n in fields}
 def cleanmat(M):return {ij:p for ij,p in M.items() if p}
 def ma(*MM):
  out={}
  for M in MM:
   for ij,p in M.items():out[ij]=add(out.get(ij,{}),p)
  return cleanmat(out)
 def el(p):
  out={}
  for(n,j),v in grad(p).items():
   if n in fields:out[n]=add(out.get(n,{}),scale(DD(v,j),(-1)**len(j)))
  return {n:p for n,p in out.items() if p}
 def h_literal(p):
  out={}
  for(n,I),p0 in grad(p).items():
   if n not in fields:continue
   for(m,J),z in grad(p0).items():
    if m not in fields:continue
    fac=scalar((-1)**(A.parities[m]*(A.parities[n]+1)))
    for mu in I:fac=mul(fac,scalar('-I'),elem(qs[mu]))
    for mu in J:fac=mul(fac,scalar('I'),elem(ls[mu]))
    out[n,m]=add(out.get((n,m),{}),sub(mul(fac,z),km))
  return cleanmat(out)
 def h_euler(p):
  out={}
  for n,E in el(p).items():
   for(m,J),z in grad(E).items():
    if m not in fields:continue
    fac=scalar((-1)**(A.parities[m]*(A.parities[n]+1)))
    for mu in J:fac=mul(fac,scalar('I'),elem(ls[mu]))
    uimages={uu:elem(uu) for uu in u}
    # Explicit coefficient derivatives on u carry its OWN transfer s.
    zz={}
    for(g,w),co in z.items():
     term={(g,()):co}
     for t,j in w:
      assert t in u
      term=mul(term,elem(t))
      for mu in j:term=mul(term,scalar('I'),elem(ss[mu]))
     zz=add(zz,term)
    out[n,m]=add(out.get((n,m),{}),mul(fac,zz))
  return cleanmat(out)
 quad=[];cur=[];densities=[];counts=[]
 for rr,uu in enumerate(u):
  full=unpack(inp['physical_QG'][rr]);qp={};cp={};stat=defaultdict(int)
  for(g,w),co in full.items():
   if len(w)==2 and all(n in fields for n,j in w):
    if sum(len(j) for n,j in w)==4-sum(dims[n] for n,j in w):qp[g,w]=co;stat['marginal_quadratic_density']+=1
    else:stat['positive_dimension_quadratic']+=1
   if len(w)==3 and all(n in core for n,j in w) and sum(n in aset for n,j in w)==1 and sum(n in cset for n,j in w)==1 and sum(n in bose for n,j in w)==1:
    if sum(len(j) for n,j in w)==4-sum(dims[n] for n,j in w):cp[g,w]=co;stat['marginal_current_density']+=1
    else:stat['positive_dimension_current']+=1
  Q=wick(mul(elem(uu),qp));C=wick(mul(elem(uu),cp));densities.append([pack(Q),pack(C)])
  M=h_literal(Q) if role=='primary' else h_euler(Q);quad.append(M)
  tensors={key:[{} for _ in range(4)] for key in ['Ua','UB','UC','Uu']};HH={};ap={n:i for i,n in enumerate(an)};cc={n:i for i,n in enumerate(cn)};bb={n:(i,mu) for i,v in enumerate(bn) for mu,n in enumerate(v)};ll={n:i for i,n in enumerate(ln)}
  if role=='primary':
   for(g,w),co in C.items():
    ai=next(i for i,(n,j) in enumerate(w) if n in aset);ci=next(i for i,(n,j) in enumerate(w) if n in cset);bi=next(i for i,(n,j) in enumerate(w) if n in bose);ui=next(i for i,(n,j) in enumerate(w) if n==uu);sg=-1 if ci<ai else1;z={(g,()):scale_coefficient(co,sg)};aa=ap[w[ai][0]];cn0=cc[w[ci][0]];jets=[(i,j) for i,(n,j) in enumerate(w) if j]
    if w[bi][0] in ll:
     assert not jets;key=(ll[w[bi][0]],aa,cn0);HH[key]=add(HH.get(key,{}),mul(z,scalar('-I')));continue
    b,mu=bb[w[bi][0]];assert len(jets)==1 and jets[0][1]==(mu,);at=jets[0][0];kind='Ua' if at==ai else'UB' if at==bi else'UC' if at==ci else'Uu';key=(b,aa,cn0);tensors[kind][mu][key]=add(tensors[kind][mu].get(key,{}),z)
   for key in tensors:
    for mat in tensors[key][1:]:assert cleanmat(mat)==cleanmat(tensors[key][0])
   TT={k:cleanmat(v[0]) for k,v in tensors.items()}
   def dif(a,b):return cleanmat({ij:add(a.get(ij,{}),scale(b.get(ij,{}),-1)) for ij in set(a)|set(b)})
   vv=dif(TT['Ua'],TT['UB']);ac=dif(TT['Ua'],TT['UC']);au=dif(TT['Ua'],TT['Uu'])
  else:
   vv0=[{} for _ in range(4)];ac0=[{} for _ in range(4)];au0=[{} for _ in range(4)]
   for a,E in el(C).items():
    if a not in aset:continue
    for(g,w),co in E.items():
     assert len(w)==3;cn0=next(n for n,j in w if n in cset);bnode=next(n for n,j in w if n in bose);aa=ap[a];cn0i=cc[cn0];z={(g,()):co};jets=[(n,j) for n,j in w if j]
     if bnode in ll:
      assert not jets;key=(ll[bnode],aa,cn0i);HH[key]=add(HH.get(key,{}),mul(z,scalar('-I')));continue
     b,mu=bb[bnode];assert len(jets)==1 and jets[0][1]==(mu,);n=jets[0][0];target=vv0 if n==bnode else ac0 if n==cn0 else au0;key=(b,aa,cn0i);target[mu][key]=add(target[mu].get(key,{}),scale(z,-1))
   for mats in [vv0,ac0,au0]:
    for M0 in mats[1:]:assert cleanmat(M0)==cleanmat(mats[0])
   vv,ac,au=map(lambda mats:cleanmat(mats[0]),[vv0,ac0,au0])
  cur.append({'V':vv,'AC':ac,'AU':au,'H':cleanmat(HH)});counts.append(dict(stat))
 print('STAGE '+role+' actual_finite_transfer_quadratics_and_three_current_jets_complete',flush=True)
 def pm(M):return [[*ij,pack(p)] for ij,p in sorted(M.items())]
 def blocks(M):
  count=defaultdict(int)
  for(i,j),p in M.items():
   kind=('B' if i in bset else'L' if i in ln else'a' if i in aset else'C' if i in cset else'x')+('B' if j in bset else'L' if j in ln else'a' if j in aset else'C' if j in cset else'x')
   for g,w in p:count[kind+'_s'+str(sum(n in ss for n,jj in w))]+=1
  return dict(sorted(count.items()))
 out={'schema':'EVEN_PROBE_VERTICES_V1','role':role,'names':list(A.names),'parities':list(A.parities),'quadratic_transfer':[pm(M) for M in quad],'currents':[{key:pm(M) for key,M in tab.items()} for tab in cur],'selected_densities':densities,'selection_counts':counts,'block_transfer_counts':[blocks(M) for M in quad],'all_four_Lorentz_components_checked':True,'u_C_transfers_kept_independent':True,'new_quantum_coefficients_measured':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'block_transfer_counts':out['block_transfer_counts']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
'''
tail=tail.replace('else1','else 1')
source=prefix+tail;ast.parse(source)
with(O/'native.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
