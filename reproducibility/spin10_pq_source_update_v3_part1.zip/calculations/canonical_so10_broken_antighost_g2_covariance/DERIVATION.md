# Order2 H-completion and local uniqueness

For I=g I1+g^2 I2+..., I0=0 and T=T0+g T1, the order2 Ward equation is
T0 I2+T1 I1=0 as an integrated functional. All symbols here include their
actual recorded powers; no coupling is divided out of a physical input.

The candidate uses BH-AH and, for each actual ghost rho from
T C_i=g rho_i,j,a omega_a C_j,
(D_mu D_nu C)_i=partial_mu partial_nu C_i
-g rho_i,j,a[(partial_mu A_nu^a) C_j+A_nu^a partial_mu C_j
+A_mu^a partial_nu C_j]+O(g^2).
Only derivatives present in measured I1 are covariantized. Both pieces are
fixed before the Ward test. Differences caused by this prescription must be
listed even if they cancel each other; individual nonzero pieces are controls.

Two completions of the same I0,I1 and flat I2 differ at order2 by local A-
invisible Delta with T0 Delta=0 modulo boundaries. T0 epsilon=T0 C=0; only
AH/BH transform, both by partial omega. A local Lorentz scalar of dimension4,
ghost0, linear epsilon(dimension1,ghost-1), with at least one A, has exactly
one C and either A times a derivative of epsilon/C, AA, ABH or ABM. No source,
inverse derivative/mass/coupling, or Lorentz-index background spurion is allowed.
Positive-dimensional coefficients cannot create another scalar A structure.
Terms derivative-on-A are reduced by the explicit four IBP currents. Fermion
pairs, auxiliary, scalar or extra ghosts would exceed dimension or leave
unpaired Lorentz/ghost number. This is the ACTUAL restricted ring, not a claim
about nonlocal/finite/IR terms or the full effective action.

Thus the complete candidate space per epsilon/C pair has24 derivative
structures,78 AA,144 ABH and396 ABM, total642. The V251 injectivity calculation
uses only these actual leading affines; it is independent of the H charge of
epsilon/C, whose homogeneous transformations start at g. Distinct epsilon/C
labels give disjoint polynomial words and a direct sum of identical blocks.
The inherited642 exact pivot certificate therefore implies injectivity for
all33*45 pairs (953370 dimensions) without a repeated dense rank calculation.
This implication requires explicit matching of actual leading transformations,
grades, derivative conventions and the no-source polynomial space.

The actual insertion's membership/covariance is a dependency theorem, not a
new momentum integral: V255 gives the local ordered leading-log word and H
covariance for the explicit Weyl reference/heat family; actual master/source
transformations and V256 [TH,D]=0 pass to the insertion, with J=0 H-stable.
V263 obtains its complete flat order2 coefficients from action-measured poles,
including both source orders. D fixes reference/heat and the A-only reference
determinant, whose retained derivative is zero. No divergent infinite-trace
cyclicity, all-order QAP, historical unique scheme or measure theorem is used.
The locality/covariance membership statement is valid only in that formal
family and under its inherited finite-jet/power-counting assumptions. If any
of these premises cannot be authenticated/matched, candidate verification
alone must remain conditional and must not qualify an actual off-flat pole.
