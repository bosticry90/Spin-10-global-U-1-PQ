# All33 order2 background completion V1

Recovered clean main1ea797fce1367cd239a687addc410d6bcfae2316, no live workers.
Goal remains full Spin(10)xPQ completion; previous V263 PROGRESS. AG2H asks
whether the complete measured flat order2 loop-leg insertion has a unique
H-covariant local completion in the EXPLICIT formal Weyl UV family, and what
its A-dependent order2 coefficients are. Zero correction, nonzero correction
or a precise missing premise are all valid outcomes. No Ward-fitted pole.

Reuse V263 all33 flat6608 coefficients/currents and qualified source/ordinary
coverage, V258 g1 insertion408, V257 g0 zero, V256 actual epsilon module and
[TH,D]=0, V251 exact local Ward/Euler injectivity, V255 actual ordered heat
local UV/covariance proof and V259 dimension frontier. Actual E3 supplies all
1334 maps, including both affine vector connections and the ghost carrier.
No input, reference, scheme, primitive, functional or authority changes.

The least expensive test is the complete order2 H variation T0 I2+T1 I1.
Retain all45 ghost directions, all33 epsilon directions, all epsilon/omega
jets, both symbolic widths, actual coupling powers and graded multiplication.
Never treat every epsilon as H-inert or a vanishing flat variation as itself
an off-flat quantum calculation. Keep raw variations and explicit currents.

A candidate is specified BEFORE evaluation: replace BH by BH-A in I2 (I2
is at most linear in B), and covariantize the differentiated ghosts of I1
with D=partial-g*rho_C(A). Keep only order2. Derive rho_C from the actual E3
map, not a chosen matrix, and retain the ordered double derivative's three
terms. This is a fixed construction, not solving unknown coefficients from
an intended cancellation. A nonzero remainder must be preserved.

Qualify the actual off-flat completion only if: the candidate reproduces all
flat coefficients; its order2 H variation is a total derivative; the actual
formal UV insertion has the same locality, power/dimension, epsilon, ghost,
source-zero and polynomial assumptions; and the V251 leading-affine kernel
injectivity extends componentwise to every epsilon/ghost pair. Leading T0
must be nonzero ONLY on AH and BH, both equal partial omega, and zero on
all epsilon and ghost carriers. Homogeneous g1 epsilon transformations remain
essential to the inhomogeneous order2 test. Do not confuse T0 with full TH.

Two sequential read-only native routes120sec after imports,8GiB sampledprivate,
minimum350MiB availablecommit, then a separate independent symbolic verifier.
Freeze code, controller, exact role read inventory and all inputs before run.
Primary uses even ordered slots; replay left gradients. Independent ordinary
polynomial implementation checks every coefficient, current, actual rho and
both completion pieces. Reuse the qualified642-rank certificate without
materializing953370 duplicate columns. Prove the direct-sum relabeling; do
not call a shared inherited certificate an independent new rank computation.

Controls remove the epsilon H carrier, either candidate completion piece,
reverse covariant-derivative sign, or make BH homogeneous. Report insensitive
controls explicitly, especially if the net A correction is zero. Preserve
all failed versions/full captures, no retries under overwritten filenames.
Source mirrors use exclusive writes or exact equality checks; never replace
a frozen controller display copy. New version required for a correction.

Authority34/39, all seven flags false. Full QAP, measure, IR, contacts,
nonlinear products, quantum equivalence, sourcefree Slavnov and E5/A5 remain
unqualified. Historical quartet failure/custodyexit2-seven references and
scalar quantum-control/gauge matching warnings unchanged. HB1/C5 blocked,
flavor paused. No branches,worktrees,agents,remote actions or benchmark/scheme
adoption. Validate before local commit; exact scope and omitted checks stated.
Track B tests a whole-order structural completion instead of a large tensor
expansion. Shared actions/flat poles/analytic premises/software/AI authorship
remain; no Lean/expert/experimental or independently integrated new pole.
