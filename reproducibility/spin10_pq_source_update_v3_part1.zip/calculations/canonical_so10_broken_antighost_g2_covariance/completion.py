"""Actual all33 g2 H relation and fixed local covariant completion."""
from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent

def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u

a=load('actual_g2_H_types',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;l=a.l;s=a.s;ex=a.ex;read=a.read;digest=a.digest

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('G2_COVARIANCE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);w=m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return v
 def act(P,I):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
 def gp(P,n):return {key:z for key,z in P.items() if key[0]==n}
 for i in range(45):n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1)
 E={m.index[f'zz_da{i:02}'] for i in range(12,45)};A={m.index[f'A{i}_{mu}'] for i in range(12) for mu in range(4)};BH={m.index[f'B{i}_{mu}'] for i in range(12) for mu in range(4)};C={m.index[f'C{i}'] for i in range(45)}
 e3,eb=b.sealed('frozen_a10_e3_symmetry',role);T={m.index[n]:m.decode(rows) for n,rows in e3['operators']['Tb_geometric_and_transported'].items()};assert len(T)==1334
 module=b.auth('canonical_so10_broken_antighost_dependency_audit',role+'_v2_result.json');assert module['H_multiplet_covariance_qualified'] and not module['all1367_H_D_commutator_residuals'] and len(module['actual_H_epsilon_module_rows'])==180
 for i in range(12,45):T[m.index[f'zz_da{i:02}']]=m.decode([{'word':[om,f'zz_da{j:02}'],'coefficient':co} for ii,j,om,co in module['actual_H_epsilon_module_rows'] if ii==i])
 T0={n:gp(P,0) for n,P in T.items() if gp(P,0)};T1={n:gp(P,1) for n,P in T.items() if gp(P,1)};assert set(T0)==A|BH
 for i in range(12):
  for mu in range(4):assert T0[m.index[f'A{i}_{mu}']]==T0[m.index[f'B{i}_{mu}']]==m.D(m.elementary(m.index[f'omega{i}']),mu)
 assert all(g in [0,1] for P in T.values() for g,key in P) and not E&set(T0) and not C&set(T0)
 assert all(all(any(n in m.sources for n,j in key) for g,key in T[J]) for J in m.sources)
 g1=b.auth('canonical_so10_broken_antighost_g1_reconciliation',role+'_v2_result.json');g2=b.auth('canonical_so10_broken_antighost_g2_leg',role+'_v5_result.json','validation_v2_receipt.json');I1=h.from_result(g1['all33_g1_anchored_insertion_from_measured_loop_leg_derivative']);I2=h.from_result(g2['all33_flat_g2_anchored_insertion']);assert len(I1)==408 and len(I2)==6608 and all(g==1 for g,key in I1) and all(g==2 for g,key in I2)
 assert all(not any(n in A for n,j in key) for P in [I1,I2] for g,key in P)
 assert all(sum(n in BH for n,j in key)<=1 for g,key in I2)
 def ward(P,Q):return m.add(act(P,T0),act(Q,T1))
 raw=stage('complete_actual_T0_I2_plus_T1_I1',lambda:ward(I2,I1));rawN,rawJ=a.odd_anchor(raw,E)
 deltaB={m.index[f'B{i}_{mu}']:m.scale(m.elementary(m.index[f'A{i}_{mu}']),-1) for i in range(12) for mu in range(4)}
 partB=stage('fixed_BH_minus_AH_order2_construction',lambda:act(I2,deltaB))
 def covghost():
  out=[];rho=[]
  for n in sorted(C):
   for (g,key),co in T1.get(n,{}).items():
    om=[t for t in key if m.names[t[0]].startswith('omega')];cc=[t for t in key if t[0] in C];assert g==1 and len(key)==2 and len(om)==len(cc)==1 and not om[0][1] and not cc[0][1];rho.append([m.names[n],m.names[cc[0][0]],m.names[om[0][0]],str(ex.D.to_sympy(co))])
  for (g,key),co in I1.items():
   jets=[(pos,n,j) for pos,(n,j) in enumerate(key) if j]
   if not jets:continue
   assert len(jets)==1;pos,n,jj=jets[0];assert n in C and len(jj)==2;mu,nu=jj
   pieces=[]
   for (gr,word),r in T1.get(n,{}).items():
    oi=next(int(m.names[v][5:]) for v,j in word if m.names[v].startswith('omega'));ci=next(v for v,j in word if v in C);amu=m.elementary(m.index[f'A{oi}_{mu}']);anu=m.elementary(m.index[f'A{oi}_{nu}']);c=m.elementary(ci)
    H=m.add(m.mul(m.D(anu,mu),c),m.mul(anu,m.D(c,mu)),m.mul(amu,m.D(c,nu)));pieces.append(m.mul({(gr,()):m.cscale(r,-1)},H))
   replacement=m.add(*pieces);before={(g,key[:pos]):co};after={(0,key[pos+1:]):ex.coefficient(s.S.One)};out.append(m.mul(m.mul(before,replacement),after))
  return m.add(*out),rho
 partD,rho=stage('actual_ghost_rho_ordered_covariant_second_derivative',covghost);delta=m.add(partB,partD);candidate=m.add(I2,delta);res=stage('candidate_complete_order2_H_identity',lambda:ward(candidate,I1));N,J=a.odd_anchor(res,E)
 flat=lambda P:{key:z for key,z in P.items() if not any(n in A for n,j in key[1])};assert flat(candidate)==I2 and flat(delta)=={} and all(g==2 for g,key in candidate)
 loc=b.auth('canonical_so10_ub12_background_locality',role+'_v2_result.json','validation_v2_receipt.json');assert loc['all642_actual_Ward_Euler_column_rank']==642 and len(loc['exact_sparse_pivot_certificate'])==642 and len(loc['actual96_affine_columns_rank48'])==48 and loc['ghost_index_identity_tensorization']
 labels=[tuple(z[0]) for z in loc['exact_sparse_pivot_certificate']];assert len(set(labels))==642 and Counter(t[0] for t in labels)==Counter({'A_eps_dC':12,'A_deps_C':12,'AA':78,'ABH':144,'ABM':396})
 assert all((w.grades|w.external)[f'C{i}']==(1,1,1) for i in range(45)) and all((w.grades|w.external)[f'ub{i}']==(1,-1,1) for i in range(12,45))
 for P in [I1,I2,candidate,delta]:
  for g,key in P:
   grades=[(1,-1,1) if n in E else (w.grades|w.external)[m.names[n]] for n,j in key];assert sum(gr[0]+len(j) for gr,(n,j) in zip(grades,key))==4 and sum(gr[1] for gr in grades)==0 and sum(gr[2] for gr in grades)%2==0 and sum(n in E for n,j in key)==1 and not any(n in m.sources for n,j in key)
 uv=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');front=b.auth('canonical_so10_antighost_finite_frontier',role+'_result.json','validation_v2_receipt.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and uv['inherited_actual_H_action_Ward_no_EOM_and4002_Lie_checks_authenticated'] and uv['explicit4131_entry_local_reference_and_weighted_principal_authenticated'] and module['field_part_D_tangent_zero_external_sources_not_integrated']
 assert front['all33_formal_local_UV_insertions_have_g_at_most4'] and front['explicit_reference_class_only_no_arbitrary_added_covariantization']
 assert g2['insertion_from_differentiating_complete_action_calculated_poles_not_fitted'] and g2['reference_heat_Gamma_ref_fixed_under_antishift_and_sources'] and not g2['source_functional_input_benchmark_scheme_authority_changed']
 wrongE={n:P for n,P in T1.items() if n not in E};wrongB={n:P for n,P in T0.items() if n not in BH}
 ctrl={'omit_epsilon_H_carrier_changes_order2_identity':bool(a.odd_anchor(m.add(act(candidate,T0),act(I1,wrongE)),E)[0]),'omit_BH_minus_AH_piece_changes_order2_identity':bool(a.odd_anchor(ward(m.add(I2,partD),I1),E)[0]),'omit_covariant_ghost_piece_changes_order2_identity':bool(a.odd_anchor(ward(m.add(I2,partB),I1),E)[0]),'reverse_covariant_derivative_sign_changes_order2_identity':bool(a.odd_anchor(ward(m.add(I2,partB,m.scale(partD,-1)),I1),E)[0]),'incorrectly_homogeneous_BH_changes_order2_identity':bool(a.odd_anchor(m.add(act(candidate,wrongB),act(I1,T1)),E)[0])}
 qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in g2['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'ALL33_G2_LOCAL_H_COMPLETION_V1','route':role,'scientific_disposition':'ALL33_G2_OFFFLAT_COMPLETION_IN_EXPLICIT_FORMAL_LOCAL_UV_FAMILY' if not N else 'FIXED_COVARIANT_CONSTRUCTION_HAS_ORDER2_REMAINDER_UNQUALIFIED','input_g1_positions':len(I1),'input_flat_g2_positions':len(I2),'actual1334_H_maps_plus33_epsilon_carriers':len(T),'actual180_epsilon_module_rows':module['actual_H_epsilon_module_rows'],'actual_ghost_rho':rho,'actual96_leading_affine_columns_only_AH_BH':True,'all_source_zero_and_leading_epsilon_ghost_invariance_matched':True,'flat_order2_H_variation':l.rows(raw),'flat_order2_H_anchor':l.rows(rawN),'four_flat_order2_H_currents':list(map(l.rows,rawJ)),'fixed_B_minus_A_piece':l.rows(partB),'fixed_covariant_ghost_piece':l.rows(partD),'net_background_completion':l.rows(delta),'complete_order2_candidate':l.rows(candidate),'complete_order2_H_variation':l.rows(res),'complete_order2_H_anchor':l.rows(N),'four_complete_order2_H_currents':list(map(l.rows,J)),'all_candidate_flat_coefficients_reproduced':True,'all642_rank_certificate_and_actual_leading_map_membership_matched':True,'local_A_invisible_kernel_direct_sum_blocks':33*45,'local_A_invisible_kernel_direct_sum_rank':642*33*45,'rank_extension_proof_not_new_dense_rank':'DERIVATION.md;actual T0 trivial on all epsilon/C, identical affine A/BH action;disjoint epsilon/C labels','formal_local_UV_covariance_membership_dependencies_matched':True,'offflat_qualified_only_if_no_H_anchor':not N,'background_response_can_cancel_between_fixed_pieces':not delta,'controls':ctrl,'insensitive_controls_explicit':[k for k,v in ctrl.items() if not v],'new_independent_momentum_integral_or_general_heat_measure_QAP_theorem':False,'known_functional_source_input_benchmark_scheme_policy_authority_changed':False,'all_seven_quantum_flags_false':flags,'full_QAP_IR_measure_products_contacts_equivalence_Slavnov_E5_A5_proved':False,'shared_limits':'Actual H/action/flat measured poles,qualified642 certificate,formal locality and covariance premises,software and AI author shared;not independent loop/Lean/expert/experiment','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
