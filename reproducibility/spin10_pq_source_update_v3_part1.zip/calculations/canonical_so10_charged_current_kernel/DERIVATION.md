# CCK1: absolute charged kernel with its proper forest

The inherited ordered heat coefficient P2 is quadratic in the charges.
Conservation qv=-q1-q2 converts Aq1²+Bq2²+Cq1q2 to three edge weights
(A-C/2)q1²+(B-C/2)q2²+(C/2)qv². The old action-derived SCM maps provide
these weights in future model contractions. No common scalar Casimir is
substituted for the vector insertion.

## Absolute master conversion

Let U=st+su+tu and N=P2 U², a degree5 polynomial. In the two-loop Gaussian
exp[-s p²-t k²-u(p+k)²], define A=(t+u)/U, B=(s+u)/U, C=-u/U.
Its moments are

```
<p²>=DA/2, <k²>=DB/2, <p.k>=DC/2,
<p⁴>=D(D+2)A²/4, <k⁴>=D(D+2)B²/4,
<p²k²>=D²AB/4+DC²/2,
<(p.k)²>=DAB/4+D(D+1)C²/4,
<p²(p.k)>=D(D+2)AC/4, <k²(p.k)>=D(D+2)BC/4.
```

Construct a finite basis of proper-time monomials times these moments.
Their general-D polynomial identity with N is the conversion certificate.
Proper times translate to raised propagator powers with their factorials;
p²=Pa-x,k²=Pb-y,(p+k)²=Pv-z. Candidate terms are screened so no negative
propagator index or two absent edges occur. One absent edge gives the
actual product of two massive tadpoles. Remaining positive indices are
mass derivatives of the ordinary absolute sunset. Keep the O(eps) tadpole
coefficient when products generate a finite term. Substitute independent
master derivative symbols before the epsilon series.

This conversion leaves no inverse mass-difference denominators. D4 is
used to select a nonsingular linear basis, never to freeze the physical
Lorentz trace; the certificate is proved at general D before expansion.
Replay integrates the original heat polynomial with endpoint-restored
projective domains, providing a different absolute calculation.

## Actual subgraph forest

The scalar UV kernel follows from the literal numerator (p+k)² and the
real Gaussian sign. It has slope -2 and mass +(y+z). After its NEGATIVE
pole is closed on the x scalar edge, the effective mass is -(2x+y+z).
The opposite edge has x/y exchanged. Scalar Lorentz dimension excludes
a new independent term linear in F at this UV order.

The vector loop from (2k+p)_mu(2k+p)_nu has its real -1/2 factor. Its
UV derivative is tau/6 K_YM and mass (x+y)tau/2. The two equal curvature
halves in K_YM are the inherited SCU result, one from derivative ordering
and one from the explicit connection curvature. This current-loop
diagnostic does not replace the parent seagull with a restricted one.

For normalization, use scalar background generator diag(rJ,sJ), mass
diag(xI2,yI2), and actual real skew currents
T1=t[[0,I2],[-I2,0]], T2=t[[0,J],[J,0]]. Their vector charge is r-s,
q1=-r,q2=s, total color norm W=8t² and current unit (3/2)W=12t².
Evaluate the complete real traces before extracting the three charge
weights. The scalar forest contains H_eps(x)/eps and H_eps(y)/eps;
the vector closure uses the inherited (21/2+eps) kinetic coefficient
and (10+eps) mass coefficient, with H_eps(z)/eps. This retains finite
terms from epsilon-positive factors. The forest is calculated before
testing mass independence of the remaining pole.

H_eps(m)=exp(gamma_E eps)Gamma(1+eps)(Q²/m)^eps. No finite graph
counterterm is adopted. The graph-local Rprime is bare+its three proper
subgraph CTs. There is no product of overlapping two-edge forests.
The full parent insertion is separate and must subtract these already
included forests once. The reduced heavy-tadpole bridge remains separate.

The general finite coefficient at Q²=1 is retained as a master expression.
For normalized masses X=x/z,Y=y/z the jz=log(Q²/z) coefficient is
2Pbare+Pforest. Soft or massless edges are outside this positive-mass
calculation. Actual hard/EFT matching must be established before applying
any such limit to a complete model branch.
