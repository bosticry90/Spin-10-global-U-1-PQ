# CCK1 verification: equivalent master representations are not independent

Source review before launching final verification identified an invalid
assumption in the original verify.py. It attempted to prove finite scalar
exchange and neutral equivalence by comparing coefficients of differently
reduced vacuum-master derivatives as independent polynomial variables.
These derivatives satisfy integration-by-parts identities. Different valid
Gaussian reductions need not give identical coefficient strings in that
redundant representation.

The original verifier and its frozen source remain unchanged and UNEXECUTED.
There is no failed V1 verifier run or V1 receipt. This is a prelaunch
verification-design correction, not a scientific mismatch and not evidence
of already passing finite master values.

V2 proves the same exact exchange and general-mass neutral equalities before
integration: the general-D Gaussian/Wick certificates and the original heat
polynomials have those identities. For strictly positive masses their
integrals agree in a common convergent dimensional strip and by meromorphic
continuation. That proves the relevant Laurent identities without imposing
false independence on the master derivatives. V2 also challenges the actual
master values at an unequal point, in addition to every original heat,
known-integral, scaling, forest and negative-control check.

No primary/replay kernel, heat calculation, action, normalization, scientific
obligation, numerical tolerance or resource cap changes. The final verifier
keeps its 600-second limit. The V2 controller freezes the corrected verifier,
this explanation and itself alongside all original and completed evidence.
