"""CCK1 frozen inputs, absolute master utilities and bounded execution."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,os,threading,importlib.util,itertools
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
st,tt,ut,D=s.symbols('s t u D',positive=True);q1,q2,qv=s.symbols('q1 q2 qv',real=True)
x,y,z,eps=s.symbols('x y z eps',positive=True);a,b=s.symbols('a b',positive=True)
Hx,Hy,Hz=s.symbols('Hx Hy Hz');LOC={str(v):v for v in [st,tt,ut,D,q1,q2,qv,x,y,z,eps,a,b,Hx,Hy,Hz]}
U=st*tt+st*ut+tt*ut;FAMILIES=['left','right','vector']
def clean(v):return s.cancel(s.expand(v))
def expr(v):return s.sympify(v,locals=LOC)
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep,seconds):
    start=time.perf_counter();watch=threading.Timer(seconds,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for n,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    return start
def save(role,kind,value,start):
    raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_{kind}_tables.json.gz').open('xb') as out:out.write(blob)
    print('RESULT '+json.dumps({'role':role,'schema':'CCK1_'+kind.upper(),'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
@lru_cache(None)
def old_math():return load('cck_old_ncm',CAL/'canonical_so10_neutral_current_matching/data.py').old_math()
def input_P2(role):return expr(packed(CAL/'canonical_so10_scalar_current_sunset'/f'{role}_kernel_tables.json.gz')['P2'])
def decompose(P):
    v=s.Poly(clean(P.subs(qv,-q1-q2)),q1,q2);A=v.coeff_monomial(q1*q1);B=v.coeff_monomial(q2*q2);C=v.coeff_monomial(q1*q2)
    out=[clean(A-C/2),clean(B-C/2),clean(C/2)]
    assert clean((sum(c*q*q for c,q in zip(out,[q1,q2,qv]))-P).subs(qv,-q1-q2))==0
    return out
def forest_jets(forest):
    pole=clean(forest.subs({Hx:1,Hy:1,Hz:1,eps:0}))
    finite=clean(s.diff(forest,eps).subs({Hx:1,Hy:1,Hz:1,eps:0})-s.diff(forest,Hx).subs(eps,0)*s.log(x)-s.diff(forest,Hy).subs(eps,0)*s.log(y)-s.diff(forest,Hz).subs(eps,0)*s.log(z))
    return {'prefactor_H':str(clean(forest)),'pole':str(pole),'finite_Q1':str(finite),'evanescent':str(clean(s.diff(forest,eps).subs({Hx:1,Hy:1,Hz:1})))}
@lru_cache(None)
def finite_master_coefficients():
    from_master=old_math()[0]
    return from_master
@lru_cache(None)
def formula_functions():
    tab=packed(HERE/'primary_kernel_tables.json.gz');out={}
    for family in FAMILIES:
        jet=[expr(v) for v in tab['kernels'][family]['bare_Laurent']]
        tokens=sorted(set().union(*(v.free_symbols for v in jet))-{x,y,z},key=str)
        assert all(str(v).startswith('I') and len(str(v))==4 for v in tokens)
        out[family]=(s.lambdify([x,y,z,*tokens],jet,modules='mpmath',cse=True),tokens)
    return out
def evaluate_formula(family,masses):
    fun,tokens=formula_functions()[family];master=finite_master_coefficients();args=[]
    for token in tokens:
        idx=tuple(map(int,str(token)[1:]));args.append(master.imaster_derivative(tuple(map(str,masses)),idx))
    return list(map(mp.mpf,fun(*masses,*args)))
