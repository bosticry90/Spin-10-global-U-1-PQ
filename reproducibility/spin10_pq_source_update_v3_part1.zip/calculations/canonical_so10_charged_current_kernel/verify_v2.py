"""CCK1 independent Wick certificate, absolute heat and known-limit replay."""
from data import *
def close(a,b,tol='1e-20'):
    e=abs(a-b)/(1+abs(b));assert e<mp.mpf(tol),(mp.nstr(a,30),mp.nstr(b,30),mp.nstr(e,12));return e
def Wick_certificate(row,P):
    Pp,Kk,Qq=s.symbols('Pp Kk Qq');A,B,C=(tt+ut)/U,(st+ut)/U,-ut/U
    cov=s.Matrix([[A,C,A+C],[C,B,B+C],[A+C,B+C,A+B+2*C]])
    result=0
    for item in row:
        average=0
        for powers,co in s.Poly(s.sympify(item['momentum_numerator']),Pp,Kk,Qq).terms():
            ids=[i for i,n in enumerate(powers) for _ in range(n)]
            if len(ids)==0:val=1
            elif len(ids)==1:val=D*cov[ids[0],ids[0]]/2
            else:
                assert len(ids)==2;i,j=ids
                val=D*D*cov[i,i]*cov[j,j]/4+D*cov[i,j]**2/2
            average+=co*val
        result+=expr(item['weight'])*s.prod(v**n for v,n in zip([st,tt,ut],item['proper_powers']))*average
    assert clean((result-P)*U**2)==0
def main():
    start=begin('validation_preparation_v2.json',600);mp.mp.dps=80
    primary=packed(HERE/'primary_kernel_tables.json.gz');replay=packed(HERE/'replay_kernel_tables.json.gz');heat=packed(HERE/'replay_heat_tables.json.gz')
    poles=[];certsizes={};controls={};numeric_error=mp.mpf(0);regression_error=mp.mpf(0)
    for family in FAMILIES:
        row=primary['kernels'][family];P=expr(row['P2']);assert clean(P-expr(replay['P2'][family]))==0
        assert row['forest']==replay['forests'][family]
        Wick_certificate(row['conversion_certificate'],P);certsizes[family]=len(row['conversion_certificate'])
        jet=list(map(expr,row['bare_Laurent']));assert jet[0]==0
        pole=expr(row['Rprime_pole']);assert pole.is_Rational;poles.append(str(pole))
        assert not any(v.has(s.Derivative) for v in jet)
        controls[family]={'omitted_Ae_finite_change':row['no_Ae_finite_change'],
          'omitted_Ae_sensitive':expr(row['no_Ae_finite_change'])!=0,'omitted_remaining_forest_evanescent':row['forest']['evanescent']}
    # Exact scalar exchange includes the finite master derivative slots.
    left=list(map(expr,primary['kernels']['left']['bare_Laurent']));right=list(map(expr,primary['kernels']['right']['bare_Laurent']))
    vector=list(map(expr,primary['kernels']['vector']['bare_Laurent']));swap={x:y,y:x}
    for v in left+right+vector:
        for atom in v.free_symbols:
            name=str(atom)
            if name.startswith('I') and len(name)==4:swap[atom]=s.Symbol('I'+name[2]+name[1]+name[3])
    # Master derivatives satisfy integration-by-parts identities. They are
    # NOT independent polynomial variables: prove exchange BEFORE integration
    # using the general-D Wick certificates, then test the actual master values.
    PP={family:expr(primary['kernels'][family]['P2']) for family in FAMILIES}
    heat_swap={st:tt,tt:st,q1:q2,q2:q1}
    assert clean(PP['left'].subs(heat_swap,simultaneous=True)-PP['right'])==0
    assert clean(PP['vector'].subs(heat_swap,simultaneous=True)-PP['vector'])==0
    oldP=input_P2('primary').subs({q1:-1,q2:1,qv:0})
    assert clean(PP['left']+PP['right']-oldP)==0
    # Every certificate identity integrates in a common positive-mass strip
    # and then meromorphically continues in D. These exact integral identities
    # establish general-mass exchange/neutral equivalence without pretending
    # different noncanonical master-derivative representations are independent.
    neutral=packed(CAL/'canonical_so10_neutral_current_matching/primary_kernel_tables.json.gz')
    for aa,bb,want in zip(left[:2],right[:2],neutral['bare_positive_Laurent'][:2]):assert clean(aa+bb-expr(want))==0
    assert clean(expr(primary['kernels']['left']['forest']['pole'])+expr(primary['kernels']['right']['forest']['pole'])-expr(neutral['forest_pole']))==0
    assert clean(expr(primary['kernels']['left']['forest']['finite_Q1'])+expr(primary['kernels']['right']['forest']['finite_Q1'])-expr(neutral['forest_finite_Q1']))==0
    print('STAGE exact_three_weight_certificate_and_neutral_limit_passed',flush=True)
    for name,row in heat['cases'].items():
        masses=list(map(mp.mpf,row['masses']));actual=list(map(mp.mpf,row['bare']));want=evaluate_formula(row['family'],masses)
        for aa,bb in zip(actual,want):numeric_error=max(numeric_error,close(aa,bb))
        assert mp.mpf(row['last_scaled_change'])<mp.mpf('1e-22')
        print('STAGE absolute_master_'+name,flush=True)
    # Numerically challenge the noncanonical master identities at the
    # genuinely unequal point as well as the full exact preintegral proofs.
    mv=list(map(mp.mpf,[1,2,3]));rv=[mv[1],mv[0],mv[2]]
    ll=evaluate_formula('left',mv);rr=evaluate_formula('right',rv)
    vv=evaluate_formula('vector',mv);vvs=evaluate_formula('vector',rv)
    ncm=old_math()[0].evaluate(mv);nr=evaluate_formula('right',mv)
    for aa,bb,cc,dd,nn,rt in zip(ll,rr,vv,vvs,ncm,nr):
        numeric_error=max(numeric_error,close(aa,bb),close(cc,dd),close(aa+rt,nn))
    scaled_rows={}
    for family in FAMILIES:
        base=list(map(mp.mpf,[1,2,3]));factor=mp.mpf(2);first=evaluate_formula(family,base);second=evaluate_formula(family,[factor*v for v in base])
        close(second[0],first[0]);close(second[1],first[1]);close(second[2],first[2]-2*mp.log(factor)*first[1])
        ff=primary['kernels'][family]['forest'];cfin=s.lambdify([x,y,z],expr(ff['finite_Q1']),modules='mpmath');cp=s.lambdify([x,y,z],expr(ff['pole']),modules='mpmath')
        observed=second[2]+cfin(*[factor*v for v in base]);wanted=first[2]+cfin(*base)-mp.log(factor)*(2*first[1]+cp(*base))
        numeric_error=max(numeric_error,close(observed,wanted));scaled_rows[family]={'factor':'2','finite_before':mp.nstr(first[2]+cfin(*base),35),'finite_after':mp.nstr(observed,35)}
    old=packed(CAL/'canonical_so10_scalar_current_laurent/primary_numeric_v2_tables.json.gz');regressions={}
    for label,masses in [('charged_r1',[5,1,1]),('charged_r2',[10,1,1])]:
        value=[mp.mpf(0)]*3
        for fam,weight in zip(FAMILIES,[4,1,1]):
            vv=evaluate_formula(fam,list(map(mp.mpf,masses)));value=[aa+weight*bb for aa,bb in zip(value,vv)]
        want=list(map(mp.mpf,old['histories'][label][-1]['bare']))
        for aa,bb in zip(value,want):regression_error=max(regression_error,close(aa,bb,'1e-30'))
        regressions[label]=list(map(lambda v:mp.nstr(v,35),value))
    print('STAGE old_actual_charged_integrals_and_common_mass_scaling_passed',flush=True)
    # Missing vector charge cannot reproduce the actual charged diagnostic.
    vector_probe=evaluate_formula('vector',list(map(mp.mpf,[1,2,3])));assert any(abs(v)>mp.mpf('1e-20') for v in vector_probe)
    evan=expr(primary['kernels']['vector']['forest']['evanescent']);evan_probe=evan.subs({x:1,y:2,z:3});assert evan_probe!=0
    J=s.Matrix([[0,-1],[1,0]]);tau=4*s.eye(2);Ty=J;omitted_half=-tau*Ty/6
    assert any(v!=0 for v in omitted_half);assert (-tau*Ty/3)-(-tau*Ty/6)==omitted_half
    assert any(v['omitted_Ae_sensitive'] for v in controls.values())
    controls['missing_vector_charge_at_123']=list(map(lambda v:mp.nstr(-v,35),vector_probe))
    controls['omitted_forest_evanescent_at_123']=str(-evan_probe)
    controls['omitted_curvature_half_nonzero_operator_entries']=sum(v!=0 for v in omitted_half)
    out={'schema':'CCK1_VALIDATION','execution_state':'COMPLETED',
      'status':'QUALIFIED_THREE_CHARGE_POSITIVE_MASS_CURRENT_KERNEL_AND_ACTUAL_FORESTS','elapsed_after_imports':time.perf_counter()-start,
      'Rprime_poles':dict(zip(FAMILIES,poles)),'Gaussian_certificate_terms':certsizes,
      'absolute_heat_max_scaled_error':mp.nstr(numeric_error,30),'known_charged_max_scaled_error':mp.nstr(regression_error,30),
      'old_charged_regressions':regressions,'mass_rescaling':scaled_rows,'controls':controls,
      'positive_masses_only':True,'complete_charged_model_branch':False,'overall_counterterm_adopted':False,'full_C1_or_E5_qualified':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
