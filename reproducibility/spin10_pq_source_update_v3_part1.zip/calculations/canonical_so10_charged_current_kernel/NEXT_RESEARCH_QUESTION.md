# After CCK1: close an actual charged branch with its mixed one-soft input

Reuse the complete three-charge positive-mass kernel and SCM's full maps.
Do not recalculate the entire component current tensor or confuse this
kernel with a complete charged model branch. NCM's complete neutral r2
branch and SCM's U1 quantum-light branch are already qualified separately.

The actual SCM coarse support suggests r3 as the least complicated first
massive charged candidate. Its squared vector mass is 25g10². All11 raw
nonzero profiles have F² support: physical/physical; physical/soft and
reverse; physical/Gold1,physical/Gold3,physical/Gold4 and their reverses;
Gold1/Gold4 and reverse. Unlike r1/r4, this set has no additional soft/soft
or soft/Goldstone profile. These are inherited support statements, not
newly measured amplitudes or eigenmass classifications.

Before its complete spectral sum, derive the mixed one-soft matching term:
one external soft Higgs scalar, with an actual positive-mass scalar and
the r3 vector in the hard self-energy. The new essential functions are
the zero-momentum mass term and momentum-linear kinetic term of that
two-positive-mass one-loop kernel. Retain its epsilon coefficients,
coincident hard masses, real Gaussian factors and the correct charge
placement. Derive the response to any auxiliary mass actually present in
its propagators; do not import NCM's internal-soft-mass derivative when
the internal scalar here is positive and independent of that regulator.

Each ordered single soft cut has its own multiplicity. NCM's 1/3 included
two equivalent soft cuts in a different soft/soft assignment. Recover the
actual factor from the present real trace instead of transferring it.
Use the actual background-covariant two-point matching and OSF conditions
to include both the full/EFT subtraction and the separately retained
reduced-kernel heavy-tadpole bridge. Keep any common unknown finite Higgs
normalization symbolic and cancel it only where the matched equations
justify that cancellation.

Then apply the completed kernels to all r3 positive spectral pairs and
the actual mixed soft/positive profiles. Prove that the general charge
maps and scalar mixing remain intact; no common-Casimir or simultaneous
diagonalization shortcut. Bound precision/cost before the spectral sum.
Only after all admitted profiles have a matching disposition can the
complete branch be qualified. A genuine missing premise should remain
underdefinition rather than a positive-only branch claim.

The quantum-light SU2/SU3 cases also need charged-vector and soft-vector
treatment; the U1 neutral-vector result does not establish them. Other
massive vector sets, all remaining primitive families, overall/finite
normalizations, complete C1, physical matching and E5/A5 remain open.
The full Spin(10)xPQ objective stays active and incomplete.
