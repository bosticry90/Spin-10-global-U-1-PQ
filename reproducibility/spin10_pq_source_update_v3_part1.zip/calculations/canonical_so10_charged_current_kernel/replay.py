"""CCK1 direct conserved-charge probes and projective heat geometry."""
from data import *
def probe_coefficients(P):
    values=[clean(P.subs(dict(zip([q1,q2,qv],v)))) for v in [(-1,1,0),(1,0,-1),(0,1,-1)]]
    N,A,B=values;return [clean((N+A-B)/2),clean((N-A+B)/2),clean((-N+A+B)/2)]
def independent_forests():
    n2=s.Rational(1,4);n4=s.Rational(1,8);n22=s.Rational(1,24)
    scalar=4*n2-1+4*n2+1;longitudinal=4*(4*n4-n2)-8*n2+1;transverse=4*(4*n22-n2)
    assert scalar==2 and longitudinal==0 and transverse==-s.Rational(1,3)
    # Actual real two-plane Gram counts: W=8t², scalar C=2t² I4,
    # tau=4t² I2. Scalar1/2 trace/(3W/2) yields1/6 per plane;
    # vector tau trace/(3W/2) yields2/3. Both curvature halves are inherited.
    scalar_factor=s.Rational(2)*2/(2*s.Rational(3,2)*8)
    assert scalar_factor==s.Rational(1,6)
    vfactor=s.Rational(8)/(s.Rational(3,2)*8)
    pieces=[-scalar_factor*(scalar*x+y+z)*Hx/x,-scalar_factor*(scalar*y+x+z)*Hy/y,
      vfactor*((s.Rational(21,2)+eps)*transverse/2+(10+eps)*(x+y)/(2*z))*Hz]
    return {fam:forest_jets(v) for fam,v in zip(FAMILIES,pieces)}
def geometry(P,role):
    variables=[st,tt,ut];rows=[]
    orders=list(itertools.permutations(range(3))) if role=='primary' else [(0,1,2),(1,0,2),(2,0,1)]
    for order in orders:
        shape=[None]*3;shape[order[0]]=1
        if role=='primary':shape[order[1]]=a;shape[order[2]]=a*b;H0,H1=1+b,b
        else:shape[order[1]]=a*b;shape[order[2]]=a*(1-b);H0,H1=s.S.One,b*(1-b)
        H=H0+a*H1;sub=dict(zip(variables,shape));F=clean(a*P.subs(sub,simultaneous=True)/H**2)
        p0=clean(F.subs(D,4));p1=clean(-2*s.diff(F,D));N0=s.Poly(clean(p0*H**4),a);N1=s.Poly(clean(p1*H**4),a)
        assert N0.degree()<=8 and N1.degree()<=8
        endpoint=clean(N0.nth(1)/H0**4-4*H1*N0.nth(0)/H0**5)
        exact=s.simplify(s.integrate(endpoint,(b,0,1)));assert not exact.has(s.Integral)
        rows.append({'kind':'UV','order':list(order),'shape':list(map(str,shape)),'H0':str(H0),'H1':str(H1),
          'n0':list(map(str,reversed(N0.all_coeffs()))),'n1':list(map(str,reversed(N1.all_coeffs()))),
          'endpoint_log_density':str(endpoint),'exact_Iminus1':str(exact)})
        if role=='replay':
            outside=[None]*3;outside[order[0]]=1;outside[order[1]]=a;outside[order[2]]=1-a+a*b
            sub=dict(zip(variables,outside));UU=clean(U.subs(sub,simultaneous=True));F=clean(a*P.subs(sub,simultaneous=True)/UU**2)
            rows.append({'kind':'REGULAR','order':list(order),'shape':list(map(str,outside)),'U':str(UU),
              'w0':str(clean(F.subs(D,4))),'w1':str(clean(-2*s.diff(F,D)))})
    return rows
def main():
    start=begin('preparation.json',300);pieces=probe_coefficients(input_P2('replay'));forests=independent_forests();geos={}
    for role in ['primary','replay']:
        rows={}
        for family,P in zip(FAMILIES,pieces):
            print('STAGE heat_geometry_'+role+'_'+family,flush=True);rows[family]=geometry(P,role)
        geos[role]={'decomposition':'ordered6' if role=='primary' else 'triangle3_and_complement3','rows':rows,
          'Taylor_degree':12 if role=='primary' else 10,
          'exact_Iminus1':{family:str(clean(sum(expr(r['exact_Iminus1']) for r in rr if r['kind']=='UV'))) for family,rr in rows.items()}}
    save('replay','kernel',{'schema':'CCK1_REPLAY','P2':{f:str(v) for f,v in zip(FAMILIES,pieces)},'forests':forests,
      'geometries':geos,'positive_masses_only':True,'complete_charged_model_branch':False},start)
if __name__=='__main__':main()
