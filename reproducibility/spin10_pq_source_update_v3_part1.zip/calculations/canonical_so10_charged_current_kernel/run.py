"""CCK1 sequential dependency stages, complete captures and exclusive files."""
from pathlib import Path
from hashlib import sha256
import sys,json,gzip
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/charged-current-kernel-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
    with p.open('xb') as out:out.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def one(name,script,seconds):
    c=capture([sys.executable,'-B',str(HERE/script)]);dump(HERE/(name+'_capture.json'),c);dump(CONTROL/(name+'_full_capture.json'),c)
    if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
    assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
    assert c['launch']['memory']['available_pagefile']>=350*1024**2
    assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
    results=[json.loads(line[7:]) for line in c['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')];assert len(results)==1
    value=results[0];assert value['elapsed_after_imports']<seconds
    dump(HERE/('validation_receipt.json' if name=='validation' else name+'_result.json'),value)
    print(name,'COMPLETED',value['elapsed_after_imports'],flush=True)
def prep(name,paths):dump(HERE/(name+'.json'),{'schema':'CCK1_'+name.upper(),'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}})
initial=json.loads((HERE/'preparation.json').read_bytes())
for p,h in initial['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
paths=list(map(Path,initial['input_sha256']))+[HERE/'preparation.json'];stage=sys.argv[1]
if stage=='kernel':
    one('primary_kernel','primary.py',300);one('replay_kernel','replay.py',300)
    a=json.loads(gzip.decompress((HERE/'primary_kernel_tables.json.gz').read_bytes()));b=json.loads(gzip.decompress((HERE/'replay_kernel_tables.json.gz').read_bytes()))
    for fam in ['left','right','vector']:
        assert a['kernels'][fam]['P2']==b['P2'][fam];assert a['kernels'][fam]['forest']==b['forests'][fam]
    dump(HERE/'kernel_comparison.json',{'status':'COMPLETED_CHARGE_AND_FOREST_COMPARISON_ONLY','independent_validation':'PENDING'})
    print('COMPARED_ALL_CHARGE_POLYNOMIALS_AND_ACTUAL_FORESTS',flush=True)
else:
    assert stage in ['heat','validate'];paths+=[HERE/'kernel_comparison.json']
    assert json.loads((HERE/'kernel_comparison.json').read_bytes())['status']=='COMPLETED_CHARGE_AND_FOREST_COMPARISON_ONLY'
    for role in ['primary','replay']:paths += [HERE/(role+'_kernel'+suffix) for suffix in ['_capture.json','_result.json','_tables.json.gz']]
    if stage=='heat':prep('heat_preparation',paths);one('replay_heat','heat.py',600)
    else:
        paths += [HERE/'heat_preparation.json']+[HERE/('replay_heat'+suffix) for suffix in ['_capture.json','_result.json','_tables.json.gz']]
        prep('validation_preparation',paths);one('validation','verify.py',600)
