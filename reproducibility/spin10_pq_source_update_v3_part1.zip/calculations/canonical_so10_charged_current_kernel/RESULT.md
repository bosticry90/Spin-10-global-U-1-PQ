# CCK1: three-charge current kernel and actual graph-local forest

Qualified within the declared positive-mass domain by
validation_receipt_v2.json, SHA256
19ef4e88094128111c0557455efe880a12479fd4ec253bccf67eb1ef88b29be5.
The symbolic routes, actual heat calculations and separate V2 verifier
completed with all required checks passing. Scientific acceptance is not
performed; authority remains 34/39.

## Scope and significance

The result supplies a general unequal-positive-mass bare and Rprime kernel
for the VSS contribution to the two-loop background gauge threshold. It
retains both scalar charge weights and the vector charge weight. This is
the reusable mathematical input needed for the remaining charged-vector
mass branches; it is not yet one of those complete model amplitudes.

The action, xi1 reference, scalar point, dimensional normalization and
background F² convention remain those of the inherited C1 investigation.
Scalar/scalar/vector squared masses x,y,z are strictly positive. The actual
vertex obeys q1+q2+qv=0. No physical point, finite normalization, subtraction
scheme or overall two-loop counterterm is selected.

The action-derived heat numerator has the exact decomposition

```
P2=P_left q1²+P_right q2²+P_vector qv².
```

The primary polynomial extraction and replay's independent charge probes
agree at general D. The separate vector weight must be retained even when
a vector mass set is degenerate. SCM's full maps already provide these
three charge contractions for future model spectra; no extra large color
tensor is generated here.

## Absolute finite kernel

Primary converts the inherited heat polynomial into Gaussian momentum
moments and then the absolute massive vacuum master and tadpole products.
Its linear basis has 55 admissible candidates, rank18 on18 monomials;
the left/right/vector certificates retain 12/12/9 terms. D4 only selects
an independent basis: the resulting polynomial identities hold at GENERAL
D before D=4-2eps is substituted. No physical Lorentz trace is frozen at4.

Every candidate keeps nonnegative propagator indices with at most one
absent edge. An absent edge yields the product of two actual massive
tadpoles. No logarithmic massless integral is declared zero. The finite
master expressions retain the O(eps) tadpole terms that can multiply UV
poles. The kernels have no inverse eigenvalue differences or inverse
mass-discriminant denominators and retain coincident masses.

Replay directly integrates the original heat polynomials with exact
endpoint restoration. It uses the six ordered sectors and, independently,
the three radial triangles plus three regular complements. These domains
and the absolute Fourier/master route are mathematically different
calculations; they retain common action, regulator and normalization
premises.

The three bare double poles vanish. The unit bare simple poles are

| Weight | Bare simple pole |
| --- | --- |
| q1² | (-4x+y+z)/(6x) |
| q2² | (x-4y+z)/(6y) |
| qv² | (-20x-20y+5z)/(6z) |

The full finite expressions, derivative tokens and exact Gaussian
certificates are in primary_kernel_tables.json.gz. Iabc denotes the
corresponding mass derivative of the absolute finite sunset. These
derivatives are related by integration by parts; their coefficients in
different reductions must not be compared as independent variables.

## Actual forests before the locality test

The scalar loop is derived from the literal current numerator. Its UV
slope is -2 and its mass term is +(internal scalar mass+vector mass).
Closing its negative pole on the x edge gives -(2x+y+z), including the
kinetic contribution; closing the other edge exchanges x and y.

The vector loop has derivative tau/6 K_YM and mass (x+y)tau/2. The full
canonical curvature contains both inherited SCU halves. The actual real
two-plane current model checks its covariance and normalization, without
assuming it supplies a closed full Spin(10) representation. The diagnostic
current seagull is not substituted for the physical parent seagull.

The normalization follows from two real skew currents connecting two real
charged planes: W=8t² and the unit current weight is (3/2)W=12t². Primary
uses their complete real matrix traces and Feynman-parameter UV residues;
replay uses the angular residues and indexed real Gaussian multiplicities.
The three forest prefactors are

```
C_left   = -(2x+y+z) H_eps(x)/(6x eps),
C_right  = -(x+2y+z) H_eps(y)/(6y eps),
C_vector = [-(7/6+eps/9)+(10/3+eps/3)(x+y)/z] H_eps(z)/eps,
H_eps(m)=exp(gamma_E eps)Gamma(1+eps)(Q²/m)^eps.
```

The vector coefficients retain the epsilon-positive remaining-loop trace.
At Q²=1 its finite forest is the negative mass-log times the pole
prefactor, plus (x+y)/(3z)-1/9. The last term cannot be dropped by using
only the D4 pole. There is no product of overlapping two-edge subgraph
counterterms.

Only AFTER constructing these forests is the remaining overall pole
tested. The result is

```
P_Rprime = -q1²-q2²-qv²/3.
```

It is independent of x,y,z and remains unsubtracted. Neither its locality
nor its nonzero value is a full renormalization theorem or anomaly verdict.
For X=x/z,Y=y/z and jz=log(Q²/z), the complete positive-mass coefficient
is its finite Rprime expression at (X,Y,1), plus jz times
2Pbare(X,Y,1)+Pforest(X,Y,1). The bare and remaining-loop scale factors
are kept distinct.

## Verification design and limitations

The prospective verifier was corrected before it was launched. Its original
source would have compared noncanonical finite master derivatives as if
they were independent. V2 instead proves scalar exchange and the general-
mass neutral equality at the general-D heat/Wick identity level, where
the statement is exact, and separately challenges the actual master values
numerically. Equality in the common positive-mass convergent strip extends
meromorphically to the same Laurent coefficients. The original verify.py
and frozen copy remain UNEXECUTED, with no failed V1 capture or V1 receipt.
This prelaunch review is not evidence of already passing finite values.

All three heat coefficients were evaluated at (1,2,3) and (2,2,2), using
Gauss orders48/80/128. Both projective domains were used at (1,2,3); the
ordered-six domain was used for the coincident case. Every last scaled
change passes1e-22. The maximum scaled discrepancy across absolute heat,
master, neutral/exchange and common-mass-rescaling checks is
1.4046825886622592e-41. Reported convergence histories have35 digits and
final raw heat values45; these are observed comparisons, not rigorous
error intervals or a uniform precision bound over all masses.

The independently evaluated finite charged combinations4left+right+vector
at (5,1,1) and (10,1,1) reproduce the old SCL values
5.7275402463368610173409266807218254 and
28.167753303648517322059486574920053. Their maximum scaled discrepancy
is1.4992503748125937e-35, within the frozen1e-30 requirement. The old
results were authenticated/reused, not rerun or modified.

Controls are sensitive to missing vector charge: at (1,2,3), omission
changes the bare simple pole by+5/2 and finite term by
-0.318851466136661792087715742801674. Omitting the remaining-vector
epsilon jet changes the finite forest by-2/9 there. Removing a curvature
half changes two entries of the tested charged operator. Each of the
three actual master reductions has a nonzero generic finite change when
epsilon tadpole products are omitted. That mutation is representation-
dependent and tests sensitivity of the actual reduction, not a universal
physical prescription. Scalar forest epsilon jets themselves vanish;
their scalar entries do not test the vector-evanescence error.

## Execution and reproducibility

Commands: python-B prepare.py; run.py kernel; run.py heat;
run_validation_v2.py. All use exclusive evidence names and must not be
rerun into completed paths. There were no failed or canceled scientific
worker/verifier executions. The original verifier was corrected before
launch, with its original source retained. Preparations bind2,647 initial
inputs and2,665 final verification inputs, including the qualified ancestry
and unchanged source copies. Heat preflight authenticates primary output
hashes, but the heat calculation does not consume its formula values.

Primary/replay symbolic calculations took8.9686606/30.3244696 seconds,
heat382.0971146 seconds and verification40.3808268 seconds after imports.
Their sample counts/maximal sampled private allocations are5/58,482,688,
16/57,819,136,191/51,671,040 and21/61,669,376 bytes. These are sampled
observations, not continuous peaks. Frozen caps300seconds per symbolic
worker,600seconds heat and verifier,8GiB private sampled,350MiB launch
floor and4MiB package were respected. No resource timeout or truncation.

Primary kernel raw6,863/gzip1,578 bytes; raw SHA256
79bb1961c68956708dc060bee3b27ad669b919e260040385c114fa593fddc330.
Replay kernel raw22,114/gzip2,503 bytes; raw SHA256
258aa5a4baa1855d7323daa19c3c11f77b7def9195df27988cd6ee07145a6e61.
Heat raw8,461/gzip1,143 bytes; raw SHA256
4d4889731e1db532063ebd5a5495072ac9b9561580245c98abb32226feae7e0c.
Packed hashes, source bytes, all native captures and receipts are retained.

This calculation does not include soft or massless edges. Such limits
require their own common hard/EFT matching, not substitution into the
positive-mass remaining-vector formula. There is no completed full
charged-spectrum sum, overall subtraction, full finite C1_GS, gauge
unification or E5/A5 result. The heavy-reduced Higgs kernel and its HTB/OSF
bridge remain separate; no old subtotal or source functional is edited.

When a family is later included, preserve
B_family+C_parent=Rprime_family+(C_parent-C_family) and subtract every
already included graph forest once. Do not add an earlier contained
four-scalar subset again. Shared action, point, heat/master conventions,
software and AI authorship limit independence. No external scientist,
Lean or experimental confirmation is claimed. State113/34of39, HB1/C5
block, human-paused flavor, quartet failure, distinct scalar-correction
diagnostics, historical gauge mismatch and missing Yukawas remain.

The delegated e4 command completed six expected steps, including historical
custody exit2/seven unresolved references, which is not PASS. It authenticates
the earlier bounded evidence and authority/structure/custody conditions; it
does not replay or scientifically accept this new result. External captures,
readiness JSON lines and before/index/HEAD seals are retained in
C:/Users/psboy/.codex/research-control-records/ToE-Next/charged-current-kernel-v1-2026-10-20.
The seal preserves all25,899 prior Git blobs and every protected state byte.
No push or publication is performed. The full investigation goal remains
active and incomplete; the next dependency is specified separately.
