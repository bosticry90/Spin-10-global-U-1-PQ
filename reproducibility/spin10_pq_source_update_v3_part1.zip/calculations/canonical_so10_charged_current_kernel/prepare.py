"""Freeze CCK1 assumptions, sources, qualified ancestry and byte baseline."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='329b96533abdeb096763da08abdea42f8071da80'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/charged-current-kernel-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as f:f.write(v)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
parent=ROOT/'calculations/canonical_so10_neutral_current_matching/validation_preparation_v2.json'
deps={str(parent):sha256(parent.read_bytes()).hexdigest()}
for name,h in json.loads(parent.read_bytes())['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name;deps[name]=h
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V411.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
 'calculations/canonical_so10_neutral_current_matching/validation_receipt_v2.json',
 'calculations/canonical_so10_neutral_current_matching/primary_kernel_tables.json.gz',
 'calculations/canonical_so10_neutral_current_matching/RESULT.md',
 'calculations/canonical_so10_neutral_current_matching/NEXT_RESEARCH_QUESTION.md',
 'calculations/canonical_so10_scalar_current_forests/validation_receipt_v2.json',
 'calculations/canonical_so10_scalar_current_forests/DERIVATION.md',
 'calculations/canonical_so10_scalar_current_sm_kernel/validation_receipt.json',
 'calculations/canonical_so10_scalar_current_sm_kernel/DERIVATION.md']:
    p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','heat.py','verify.py','prepare.py','run.py']:
    p=HERE/name;raw=p.read_bytes()
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    copy=HERE/(name+'.source.txt');dump(copy,raw)
    for fp in [p,copy]:deps[str(fp)]=sha256(fp.read_bytes()).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==25899
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
value={'schema':'CCK1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'kernel_seconds':300,'heat_seconds':600,'verification_seconds':600,'sampled_private_cap':8*1024**3,
 'launch_floor':350*1024**2,'whole_package_bytes':4*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;25899oldblobs;no science executed')
