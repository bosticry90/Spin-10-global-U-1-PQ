"""CCK1 actual endpoint-restored heat integrals, no primary formula input."""
from data import *
def main():
    start=begin('heat_preparation.json',600);mp.mp.dps=80
    tab=packed(HERE/'replay_kernel_tables.json.gz');quad=old_math()[1];cases={}
    for label,masses,roles in [('unequal',[1,2,3],['primary','replay']),('coincident',[2,2,2],['primary'])]:
        masses=list(map(mp.mpf,masses))
        for role in roles:
            geo=tab['geometries'][role]
            for family in FAMILIES:
                name=label+'_'+role+'_'+family
                value,sectors,control,history,error=quad.converged(geo,family,masses,geo['Taylor_degree'],role,'cck_'+name)
                cases[name]={'masses':list(map(str,masses)),'domain':role,'family':family,'bare':list(map(lambda v:mp.nstr(v,45),value)),
                  'history':history,'last_scaled_change':mp.nstr(error,30),'endpoint_controls':control}
    save('replay','heat',{'schema':'CCK1_HEAT','cases':cases,'working_digits':80,'convergence_tolerance':'1e-22',
      'primary_formula_read_before_calculation':False,'positive_masses_only':True},start)
if __name__=='__main__':main()
