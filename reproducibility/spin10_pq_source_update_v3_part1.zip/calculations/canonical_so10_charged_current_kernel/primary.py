"""CCK1 exact Gaussian-to-momentum certificate and real-current UV closure."""
from data import *
Pp,Kk,Qq=s.symbols('Pp Kk Qq');Pa,Pb,Pv=s.symbols('Pa Pb Pv',positive=True)
def moments():
    A,B,C=(tt+ut)/U,(st+ut)/U,-ut/U
    p2,k2,dot=Pp,Kk,(Qq-Pp-Kk)/2
    return [(s.S.One,s.S.One), (p2,D*A/2),(k2,D*B/2),(dot,D*C/2),
      (p2*p2,D*(D+2)*A*A/4),(k2*k2,D*(D+2)*B*B/4),
      (p2*k2,D*D*A*B/4+D*C*C/2),(dot*dot,D*A*B/4+D*(D+1)*C*C/4),
      (p2*dot,D*(D+2)*A*C/4),(k2*dot,D*(D+2)*B*C/4)]
def conversion(P):
    basis=[];polys=[]
    for numerator,average in moments():
        degree=s.Poly(numerator,Pp,Kk,Qq).total_degree();proper_degree=degree+1
        for aa in range(proper_degree+1):
            for bb in range(proper_degree-aa+1):
                cc=proper_degree-aa-bb
                den=[aa+1,bb+1,cc+1];terms=s.Poly(s.expand(numerator.subs({Pp:Pa-x,Kk:Pb-y,Qq:Pv-z})),Pa,Pb,Pv)
                powers=[[n-v for n,v in zip(den,mon)] for mon,co in terms.terms()]
                if any(min(ns)<0 or ns.count(0)>1 for ns in powers):continue
                poly=clean(st**aa*tt**bb*ut**cc*average*U**2);assert s.denom(poly).has(st,tt,ut)==False
                basis.append((aa,bb,cc,numerator));polys.append(s.Poly(poly,st,tt,ut))
    target=s.Poly(clean(P*U**2),st,tt,ut);mons=sorted(set(target.monoms()).union(*(set(p.monoms()) for p in polys)))
    B=s.Matrix([[p.coeff_monomial(mon) for p in polys] for mon in mons]);rhs=s.Matrix([target.coeff_monomial(mon) for mon in mons])
    B0=B.subs(D,4);columns=list(B0.rref()[1]);rows=list(B0[:,columns].T.rref()[1])
    small=B.extract(rows,columns);weights=small.inv(method='DM')*rhs.extract(rows,[0]);weights=list(map(clean,weights))
    assert all(clean(v)==0 for v in B[:,columns]*s.Matrix(weights)-rhs)
    certificate=[];integrand=0
    for col,w in zip(columns,weights):
        if w==0:continue
        aa,bb,cc,num=basis[col];factor=s.factorial(aa)*s.factorial(bb)*s.factorial(cc)
        integrand+=w*factor*num.subs({Pp:Pa-x,Kk:Pb-y,Qq:Pv-z})/(Pa**(aa+1)*Pb**(bb+1)*Pv**(cc+1))
        certificate.append({'proper_powers':[aa,bb,cc],'momentum_numerator':str(num),'weight':str(w)})
    return s.expand(integrand),certificate,{'candidate_count':len(basis),'rank_at_D4':len(columns),'monomial_count':len(mons),'general_D_identity':True}
def reduce_master(integrand,no_Ae=False):
    If=s.Function('I')(x,y,z);vs=[x,y,z]
    A0=lambda v:v*(s.log(v)-1)
    Ae=lambda v:v*(-1-s.zeta(2)/2+s.log(v)-s.log(v)**2/2)
    sunset=-(x+y+z)/(2*eps**2)+(sum(A0(v) for v in vs)-sum(vs)/2)/eps+If+sum(Ae(v) for v in vs)
    def tad(v,n):return (-1)**(n-1)*s.diff(-v/eps+A0(v)+(0 if no_Ae else eps*Ae(v)),v,n-1)/s.factorial(n-1)
    def integral(ns):
        assert min(ns)>=0 and ns.count(0)<=1
        if 0 in ns:return s.prod(tad(v,n) for v,n in zip(vs,ns) if n)
        orders=[n-1 for n in ns];out=sunset
        for v,n in zip(vs,orders):out=s.diff(out,v,n)
        return (-1)**sum(orders)*out/s.prod(s.factorial(n) for n in orders)
    out=0
    for term in s.Add.make_args(integrand):
        powers=term.as_powers_dict();ns=[-int(powers.get(v,0)) for v in [Pa,Pb,Pv]]
        coef=clean(term*s.prod(v**n for v,n in zip([Pa,Pb,Pv],ns)));assert not coef.has(Pa,Pb,Pv)
        out+=coef*integral(ns)
    mapping={If:s.Symbol('I000')}
    for atom in out.atoms(s.Derivative):
        orders=dict(atom.variable_count);idx=[int(orders.get(v,0)) for v in vs];mapping[atom]=s.Symbol('I'+''.join(map(str,idx)))
    out=out.xreplace(mapping).subs(D,4-2*eps)
    jet=s.series(out,eps,0,1).removeO().expand();return [clean(jet.coeff(eps,k)) for k in [-2,-1,0]]
def forests():
    r,ss,t=s.symbols('r ss t',nonzero=True);J=s.Matrix([[0,-1],[1,0]]);I2=s.eye(2);zero=s.zeros(2)
    T=[t*s.BlockMatrix([[zero,I2],[-I2,zero]]).as_explicit(),t*s.BlockMatrix([[zero,J],[J,zero]]).as_explicit()]
    h=s.diag(r*J,ss*J);Ty=(r-ss)*J;mass=s.diag(x,x,y,y);Hs=s.diag(Hx,Hx,Hy,Hy)
    for aa in range(2):assert all(clean(v)==0 for v in h*T[aa]-T[aa]*h-sum((Ty[bb,aa]*T[bb] for bb in range(2)),s.zeros(4)))
    tau=s.Matrix(2,2,lambda aa,bb:-s.trace(T[aa]*T[bb]));W=s.trace(tau);unit=s.Rational(3,2)*W
    color=-sum((A*A for A in T),s.zeros(4));B=-sum((A*mass*A for A in T),s.zeros(4))
    # Feynman-parameter pole of the actual scalar numerator and actual vector loop.
    alpha,p2,mi,mj=s.symbols('alpha p2 mi mj');Delta=(1-alpha)*mi+alpha*mj+alpha*(1-alpha)*p2
    scalar=clean(s.integrate(-2*Delta+(1+alpha)**2*p2,(alpha,0,1)));assert scalar==2*p2-mi-mj
    vector_delta=clean(s.integrate(-2*Delta,(alpha,0,1)));vector_pp=clean(s.integrate((1-2*alpha)**2,(alpha,0,1)))
    assert vector_delta==-mi-mj-p2/3 and vector_pp==s.Rational(1,3)
    effective=-B-z*color-2*color*mass
    scalar_closure=clean(s.trace((-h*h)*effective*mass.inv()*Hs)/(2*unit))
    massV=(x+y)*tau/2;charge=-Ty*Ty
    vector_closure=clean((-(s.Rational(21,2)+eps)*s.trace(charge*tau)/6+(10+eps)*s.trace(charge*massV)/z)*Hz/unit)
    physical=clean((scalar_closure+vector_closure).subs({r:-q1,ss:q2}));A=s.Poly(physical,q1,q2)
    # This polynomial is already conserved: qv²=(q1+q2)².
    cross=A.coeff_monomial(q1*q2);pieces=[clean(A.coeff_monomial(q1*q1)-cross/2),clean(A.coeff_monomial(q2*q2)-cross/2),clean(cross/2)]
    for aa in range(2):
        for bb in range(2):assert clean(s.trace(h*(T[aa]*T[bb]-T[bb]*T[aa]))-(Ty*tau)[aa,bb])==0
    return {fam:forest_jets(v) for fam,v in zip(FAMILIES,pieces)}, {'total_color_norm':str(W),'current_unit':str(unit),'scalar_UV':str(scalar),'vector_delta_UV':str(vector_delta),'vector_pp_UV':str(vector_pp),'actual_covariance_and_curvature_halves_checked':True}
def main():
    start=begin('preparation.json',300);pieces=decompose(input_P2('primary'));ff,normalization=forests();kernels={}
    for family,P in zip(FAMILIES,pieces):
        print('STAGE gaussian_conversion_'+family,flush=True)
        integrand,certificate,rank=conversion(P);jet=reduce_master(integrand)
        noae=reduce_master(integrand,True);pole=expr(ff[family]['pole']);finite=expr(ff[family]['finite_Q1'])
        kernels[family]={'P2':str(P),'bare_Laurent':list(map(str,jet)),'forest':ff[family],
          'Rprime_pole':str(clean(jet[1]+pole)),'Rprime_finite_Q1':str(clean(jet[2]+finite)),
          'jz_coefficient':str(clean(2*jet[1]+pole)),'conversion_certificate':certificate,'basis':rank,
          'no_Ae_finite_change':str(clean(noae[2]-jet[2]))}
    save('primary','kernel',{'schema':'CCK1_PRIMARY','kernels':kernels,'normalization':normalization,
      'positive_masses_only':True,'complete_charged_model_branch':False,'overall_counterterm_adopted':False},start)
if __name__=='__main__':main()
