# CCK1 prospective three-charge scalar-current kernel

Base329b96533abdeb096763da08abdea42f8071da80/main. State113/34of39 unchanged.
Question: derive the complete unequal-positive-mass VSS bare/graph-forest
kernel for the three independent conserved-charge weights q1²,q2²,qv².
This supplies missing reusable finite integrals for the remaining full
charged-vector branches. It is not a positive-only model branch, full C1,
matching theorem, overall CT adoption or physical unification result.

Same actual VSS action/current, background F² normalization and xi1 C1
reference as SCP/SCL/SCU/SCM/NCM. x,y,z are strictly positive scalar/scalar/
vector squared masses; q1+q2+qv=0. No new width, finite scheme, point, scale
or coupling is selected. Inherit qualified endpoint/heat kernel and
canonical vector curvature from their actual records. Distinct new routes
test the reduction/closure, not independent correctness of those premises.

Primary: convert the actual general-D P2 heat numerator to Gaussian momentum
moments, with an exact polynomial identity certificate; expand its rational
propagators into the absolute vacuum master and tadpoles through finite
order. Derive scalar/vector forest normalization using two real charged
planes and their actual covariant current matrices. Derive the open-loop
UV slopes/masses with Feynman parameters before any locality test.

Replay: obtain the three charge coefficients from independent conserved-
charge probes, retain both scalar orderings and the vector spin/current
cross terms, and construct full projective heat domains. Derive open UV
residues by large-momentum angular averages and close the real Wick factors
with the inherited canonical curvature. Keep epsilon-positive remaining-
vector terms. Compare completed charge polynomials/forests before using
either route in dependent validation.

Gaussian reduction chooses a D4-independent column basis only as an
algebraic algorithm; the resulting identity must hold at GENERAL D near4
before setting D=4-2eps. Allowed propagator moments may cancel at most one
edge and never generate a negative propagator power. No unseparated
logarithmic scaleless integral may be discarded. Failure to span the actual
polynomial is a preserved reduction failure, not permission to fit physics.

Direct heat validation: all three coefficient functions at (x,y,z)=(1,2,3)
and (2,2,2), ordered-six decomposition, Gauss48/80/128. Independently also
use triangle-three plus complement-three for all three functions at(1,2,3).
Existing SCL convergent endpoint subtraction, degrees12/10,80workingdigits,
each final scaled change<1e-22; absolute master/heat agreement<1e-20.
The unequal case tests distinct masses; the equal case retains coincidence.
No uniform numerical-error claim at all positive masses is earned.

Final separate verifier: authenticate all sources/receipts; compare exact
charge decomposition, forest and polynomial certificates; test exchange,
common-mass rescaling, all positive-mass pole locality; recover the NCM
neutral GENERAL-mass formula and both existing charged SCL diagnostic
histories. Keep overall poles rather than fit a required value. Negative
controls: missing vector charge, absent remaining-loop epsilon jet, missing
curvature half, and omitted epsilon tadpole products. Report any control
insensitivity. No new large component tensor or full spectrum contraction.

Stages sequential: frozen kernel primary/replay(300seconds each), compare;
then actual heat evaluations(600seconds total worker); then separate final
verification(600seconds). Each starts timer after imports with daemon
watchdog and pole-blind sitecustomize.8GiB sampled private cap,350MiB launch
floor,4MiB package. Preserve complete failed/unfinished captures and sources;
version corrections without weakening scientific tests or caps. No subagents.

Success: a qualified general-positive-mass three-weight kernel and actual
forests, or a precise mismatch/underdefinition/inconclusive disposition.
It does not close any charged branch's possible soft regions; select the
next full model branch from actual SCM mass support afterward. Keep
B_family+C_parent=Rprime_family+(C_parent-C_family), HTB/OSF bridge and
all old subtotals/source functional unchanged. Do not add contained smaller
subsets twice. Shared action/heat/master/frame/software/AI limitations remain.
e4/custody/seals before local commit; custody2/seven is NOTPASS. Authority,
E5/A5, HB1/C5, human-paused flavor and physical viability unchanged.
