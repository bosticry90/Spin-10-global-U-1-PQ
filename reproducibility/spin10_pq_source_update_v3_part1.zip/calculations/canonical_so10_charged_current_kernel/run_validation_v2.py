"""CCK1 freeze/capture corrected prelaunch verifier, preserving original source."""
from pathlib import Path
from hashlib import sha256
import json,sys,ast
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/charged-current-kernel-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
parent=json.loads((HERE/'heat_preparation.json').read_bytes());deps=dict(parent['input_sha256'])
for n,h in deps.items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
assert not (HERE/'validation_capture.json').exists() and not (HERE/'validation_receipt.json').exists()
for name in ['heat_preparation.json','replay_heat_capture.json','replay_heat_result.json','replay_heat_tables.json.gz']:
    p=HERE/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['verify_v2.py','run_validation_v2.py','VERIFIER_PRELAUNCH_CORRECTION_V2.md']:
    p=HERE/name;raw=p.read_bytes()
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    q=HERE/(name+'.source.txt')
    with q.open('xb') as f:f.write(raw)
    for fp in [p,q]:deps[str(fp)]=sha256(fp.read_bytes()).hexdigest()
dump(HERE/'validation_preparation_v2.json',{'schema':'CCK1_VALIDATION_PREPARATION_V2','input_sha256':dict(sorted(deps.items())),
 'verifier_seconds':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':4*1024**2,
 'original_verifier_unexecuted':True,'scientific_acceptance':'NOT_PERFORMED'})
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'verify_v2.py')]);dump(HERE/'validation_v2_capture.json',c);dump(CONTROL/'validation_v2_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2
assert c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1
v=rows[0];assert v['elapsed_after_imports']<600;dump(HERE/'validation_receipt_v2.json',v)
print(json.dumps({'status':v['status'],'elapsed_after_imports':v['elapsed_after_imports'],'Rprime_poles':v['Rprime_poles'],
 'absolute_heat_max_scaled_error':v['absolute_heat_max_scaled_error'],'known_charged_max_scaled_error':v['known_charged_max_scaled_error']},sort_keys=True),flush=True)
