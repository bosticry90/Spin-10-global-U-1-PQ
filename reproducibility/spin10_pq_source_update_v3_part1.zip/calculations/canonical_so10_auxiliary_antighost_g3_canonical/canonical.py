"""Physical g3 Lambda-a-C tensor to actual canonical coordinates."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import product
import json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,canonical,decode_typed,rows,ANTI,AUX
from a10_e5_measured_functional_v3 import frames
from a10_e3_symmetry_common import act
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def auth(folder,name,receipt='validation_receipt.json'):
 p=OUT.parent/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def sealed(folder,role):
 p=PKG/folder/(role+'.json');r=read(p.parent/'bindings.json');assert r['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p)
@lru_cache(None)
def num(z):return s.sympify(z,locals={'g10':g})
def density(P,w,physical):
 out={}
 for (ell,a,c),z in sorted(P.items()):
  L=f'Lp{ell}' if physical else AUX[ell];aa=f'ap{a}' if physical else ANTI[a];C=f'Cp{c}' if physical else f'C{c}'
  for word,sign in w.mul(w.var(L),w.var(aa),w.var(C)).items():out[word]=out.get(word,0)+g**3*z*sign
 return canonical(out)
def axis(P,M,j):
 col=defaultdict(list)
 for (i,k),z in M.todok().items():
  if z:col[k].append((i,z))
 out=defaultdict(lambda:s.S.Zero)
 for key,z in P.items():
  for i,c in col[key[j]]:out[key[:j]+(i,)+key[j+1:]]+=z*c
 return {key:s.expand(z) for key,z in out.items() if s.expand(z)!=0}
def transform(P,Ms):
 for j,M in enumerate(Ms):P=axis(P,s.SparseMatrix(M),j)
 return P
def pack(M):return [[i,j,str(s.expand(z))] for (i,j),z in sorted(M.todok().items()) if s.expand(z)!=0]

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AUX3_CANONICAL_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 pole=auth('canonical_so10_auxiliary_antighost_g3',role+'_result.json','validation_v2_receipt.json');Z={tuple(r[:3]):num(r[3]) for r in pole['physical_complete_g3_auxiliary_pole']};assert len(Z)==776 and pole['full_physical_positions']==91125 and pole['zero_complete_complement']==90349 and all(s.expand(s.conjugate(z)-z)==0 for z in Z.values())
 w,forward,back,S,A,Gi,Gp=stage('actual_frozen_field_and_source_dual_frames',lambda:frames(role));assert all(s.expand(z)==0 for z in S.T*A-s.eye(45)) and all(s.expand(z)==0 for z in Gi*Gp-s.eye(45))
 ref=sealed('frozen_a10_e5_full_hessian',role)['retained_reference'];names=ref['field_order'];pos={n:i for i,n in enumerate(names)};T={(i,j):num(z) for i,j,z in ref['physical_to_raw_kernel']['entries']};Ti={(i,j):num(z) for i,j,z in ref['physical_to_raw_inverse']['entries']}
 for ns,off,F,B in [(AUX,508,S.T,A),(ANTI,598,S.T,A),([f'C{i}' for i in range(45)],553,Gp,Gi)]:
  rawset={pos[n] for n in ns};pset=set(range(off,off+45))
  assert all(j in rawset for (i,j),z in T.items() if i in pset) and all(i in rawset for (i,j),z in Ti.items() if j in pset)
  for i,j in product(range(45),repeat=2):assert s.expand(T.get((off+i,pos[ns[j]]),0)-F[i,j])==0 and s.expand(Ti.get((pos[ns[i]],off+j),0)-B[i,j])==0
 for i in range(45):
  for physical in [f'Lp{i}',f'ap{i}',f'Cp{i}']:assert canonical(w.replace(back[physical],forward))==w.var(physical)
  for raw in [AUX[i],ANTI[i],f'C{i}']:assert canonical(w.replace(forward[raw],back))==w.var(raw)
 P=stage('ordered_physical_density_single_scalar_copy',lambda:density(Z,w,True));R=stage('three_independent_tensor_axis_pullback',lambda:transform(Z,[S,S,Gp.T]));direct=density(R,w,False)
 node=stage('graded_polynomial_density_pullback',lambda:canonical(w.replace(P,back))) if role=='primary' else direct;assert node==direct and w.grade(node,(4,0,0)) and canonical(w.replace(node,forward))==P
 recovered=stage('complete_inverse_tensor_axes_and_all_physical_zero_slots',lambda:transform(R,[A.T,A.T,Gi.T]));assert recovered==Z
 assert all(recovered.get(key,0)==Z.get(key,0) for key in product(range(45),repeat=3))
 active={n for word in node for n,j in word};allowed_fields=set(AUX)|set(ANTI)|{f'C{i}' for i in range(45)};assert active<=allowed_fields and all(not j for word in node for n,j in word)
 star={n:canonical(w.replace({word:s.conjugate(z) for word,z in forward[n].items()},back)) for n in active};reality=stage('full_C3_antilinear_density_reality_fixed_Grassmann_order',lambda:canonical(w.replace({word:s.conjugate(z) for word,z in node.items()},star)));assert reality==node
 e3=sealed('frozen_a10_e3_symmetry',role);images={n:decode_typed(e3['operators']['Tb_geometric_and_transported'][n]) for n in active};assert all(not j for I in images.values() for word in I for n,j in word)
 ward=stage('actual_complete12_parameter_local_H_variation',lambda:canonical(act(node,w,images,role,0)));assert not ward
 controls={}
 bad=density(transform(Z,[A,S,Gp.T]),w,False);controls['wrong_auxiliary_primal_dual_changes_coefficients']=bad!=node
 bad=density(transform(Z,[S,A,Gp.T]),w,False);controls['wrong_antighost_primal_dual_changes_coefficients']=bad!=node
 bad=density(transform(Z,[S,S,Gi.T]),w,False);controls['wrong_ghost_primal_inverse_changes_coefficients']=bad!=node
 controls['reverse_external_odd_order_changes_nonzero_node']=canonical(w.scale(node,-1))!=node;controls['halve_measured_normalization_changes_node']=canonical(w.scale(node,s.Rational(1,2)))!=node
 for kind,ns in [('auxiliary',set(AUX)),('antighost',set(ANTI)),('ghost',{f'C{i}' for i in range(45)})]:controls['omit_'+kind+'_H_carrier_changes_Ward']=bool(canonical(act(node,w,{n:Q for n,Q in images.items() if n not in ns},role,0)))
 qc=sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in pole['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'ORDINARY_G3_AUXILIARY_CANONICAL_EXTRACTION_V1','route':role,'scientific_disposition':'COMPLETE_ACTUAL_G3_AUXILIARY_CANONICAL_TENSOR_REALITY_AND_LOCAL_H_INVARIANCE','new_actual_g3_auxiliary_antighost_node':rows(node),'canonical_node_positions':len(node),'physical_density':rows(P),'physical_positions':len(P),'canonical_raw_tensor':[[*key,str(z)] for key,z in sorted(R.items())],'physical_roundtrip_tensor':[[*key,str(z)] for key,z in sorted(recovered.items())],'all91125_physical_positions_and90349_zeros_preserved':True,'all6075_full_reference_block_positions_and_zero_cross_carriers_match':True,'all135_field_roundtrips_both_directions':True,'full_density_and_tensor_inverse_roundtrips':True,'three_field_axis_matrices':{'S':pack(S),'A':pack(A),'Gi':pack(Gi),'Gp':pack(Gp)},'physical_to_raw_field_maps_not_source_map_substitution':True,'antilinear_C3_reality':True,'complex_canonical_coefficient_positions':sum(s.expand(z-s.conjugate(z))!=0 for z in node.values()),'actual_local_H_variation':rows(ward),'all12_local_H_parameters_no_derivative_images':True,'Ward_zero_does_not_determine_normalization_or_detect_invariant_doubling':True,'controls':controls,'insensitive_controls':[k for k,v in controls.items() if not v],'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV),one zerojet scalar density,all external slots independent','shared_primary_classical_frame_dependency_declared':True,'source_functional_input_benchmark_scheme_policy_authority_changed':False,'canonical_integration_source_identity_or_new_loop_done':False,'all_seven_quantum_flags_false':flags,'full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Same measured physical tensor,actual classical full frame/source chart/H maps,software and AI author;not independent pole integration,Lean,expert or experimental validation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
