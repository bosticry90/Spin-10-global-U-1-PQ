# Tensor/field transport and normalization

Let a_raw=A a_phys,L_raw=A L_phys,C_raw=Ginv C_phys. Actual frozen frames
satisfy S^T A=I and Ginv Gphys=I. Thus physical fields are
 a_phys=S^T a_raw,L_phys=S^T L_raw,C_phys=Gphys C_raw.
For the ordered physical tensor Z[l,a,c], the raw tensor is
 R[i,j,k]=sum_lac S[i,l] S[j,a] Gphys[c,k] Z[l,a,c].
The three raw-by-physical axis matrices are S,S,Gphys^T. Inverse axes are
A^T,A^T,Ginv^T. These statements must match the actual643-coordinate T and
Tinverse, not merely the algebraic invertibility of a convenient chart.
The relevant physical slots are Lambda508..552,C553..597,a598..642. Check
all6075 block positions and no cross-carrier nonzero entries, as well as
both field/density roundtrips. The inherited historical quartet-normalization
failure is not discharged by this distinct test.

The raw density is built with the actual graded product of Lambda,a,C,
retaining its canonical C-before-antighost sign. No index of the rank-three
tensor is symmetrized or identified; auxiliary is even, both ghosts odd.
The existing hbar/(32pi^2 epsilon) convention and exact g10^3 are preserved.
Reality uses the declared physical-real chart, not coefficientwise reality
of complex canonical components. H invariance is tested with the actual
homogeneous field maps, all12 omega parameters and their local status.
Because these zero-jet fields have no derivative inhomogeneity, exact density
invariance gives the selected local statement. It neither fixes a scalar
normalization nor proves a complete Slavnov or quantum-equivalence theorem.
