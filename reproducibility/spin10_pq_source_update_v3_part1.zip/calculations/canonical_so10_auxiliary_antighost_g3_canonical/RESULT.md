# Canonical extraction of the ordinary order3 auxiliary pole

Both native routes transport the qualified776-position physical tensor to236
canonical coefficient positions, with20 individually complex coefficients.
All45^3 physical positions, including90349 zeros, are recovered by the inverse
map. Every135 field map roundtrips in both directions, and all6075 relevant
positions of the actual643-field reference T/Tinverse match, including zero
cross-carrier entries. The inherited shared primary classical plane matrix
is explicitly declared for both routes; no peer quantum coefficient is read.

The actual antilinear C3 reality operation preserves the full density despite
complex components. The complete local-H variation of the new node is exactly
zero, with all12 parameters retained and no derivative inhomogeneity for its
zero-jet fields. Omitting any one auxiliary/antighost/ghost H carrier spoils
that test. Wrong primal/dual field or ghost maps, reversed odd order and a
half normalization each change the canonical tensor. Invariance alone cannot
catch invariant doubling or fix normalization; full measured-tensor and
roundtrip checks supply that evidence.

The coefficient multiplies hbar*g10^3/(32pi^2 epsilon_UV); there is one scalar
copy and no added Bose/ghost factor. new_actual_g3_auxiliary_antighost_node is
the measured canonical node. It has NOT been integrated into the quantum
functional or tested in a new source identity. Qualification requires a
completed independent receipt using the actual full-reference entries rather
than merely the same frames helper, all coefficients/zeros, reality, H maps,
controls and strict input/capture checks, followed by committed-byte checks.
This report alone is prospective, not that receipt.

No new loop or physics input, quantum prescription, benchmark or authority
change. Existing normalization failures remain, including the historical
quartet mismatch. Authority34/39 and seven false flags, functional155110/
sourcefree40309/sourceimage146663 unchanged. E5/A5,sourcefreeSlavnov,QAP,
measure,IR,products,contacts and quantum equivalence remain unqualified.
Historical custodyexit2/seven references and scalar/gauge-matching warnings
stay separate. HB1/C5 blocked,flavor paused. All failures/copies remain exact;
new copies exclusive. No fresh byte-identical loop replay,Lean,expert or
experimental validation. Actual pole/charts/action/UV premises/software and
AI authorship remain shared; this is distinct computational corroboration.

Next after qualification: authenticate the exact incoming functional and its
coupling-resolved C-Lambda-a projection before exact-once integration. Existing
words may carry lower powers of g; a stable word count cannot establish absence
of the new coefficient. Preserve the source image and recover the original
functional exactly by subtraction. Only after that should a complete selected
order3 epsilon-C-Lambda source/leg test be considered.
