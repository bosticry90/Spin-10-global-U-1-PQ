# Ordinary g3 auxiliary pole: canonical extraction V1

Recovered clean main2073fb634f4a00461a767fe22ec5908e59f2351a, no live matching
workers. Previous goal turn PROGRESS. Full Spin(10)xPQ goal remains active.
QuestionAC3:does the newly qualified776-position physical Lambda-a-C pole
transport into the ACTUAL canonical coordinates with every coefficient,
implicit zero,Grassmann sign,normalization and reality condition preserved?
This is canonical extraction and a selected local-H invariance check only.
No quantum-functional integration, source identity, new loop or new scheme.

Freeze V266 actual physical tensor and completed validation_v2_receipt,
qualified classical charts and raw/physical643-field reference T/Tinverse,
actual E3 H transformations and quantum-contract flags. The maps must match
all three45x45 blocks of the actual full reference, including zero complement
and no cross-carrier entries. Do not substitute a convenient source/field
map. All inherited physical-normalization failures remain separate and
unresolved; a mismatch here blocks this extraction rather than authorizing
a frame change to obtain a desired coefficient.

Least expensive test: graded polynomial substitution of the physical density
versus three explicit tensor-axis contractions, followed by exact inverse
roundtrip, all135 field roundtrips in BOTH directions, complete C3 antilinear
reality and the actual12-parameter local-H action. Auxiliary and antighost
back maps have source.T coefficients; ghost back map is Cphys. The independent
verifier must reconstruct these directly from the actual full reference
T/Tinverse instead of merely calling the same frames helper.

The density is hbar*g10^3/(32pi^2 epsilon) Lambda_l a_a Z[l,a,c] C_c.
It is zero-jet and has a single scalar copy, NOT four Lorentz copies. No extra
Bose/ghost1/2, contraction of external slots or source substitution. Full
physical domain45^3 includes90349 zeros and776 measured nonzeros. All raw
positions must roundtrip to exactly that tensor. C3 reality is coefficient
conjugation transported through the physical real chart with fixed ordered
Grassmann products; do not silently replace it with an operator adjoint.

Explicitly authenticate the inherited frames helper's shared PRIMARY
classical plane_to_C3_field matrix even on replay. It is a frozen common
classical dependency, not a peer quantum output or scientific independence.
Both own-role physical/reconstruction records remain separately bound.

Two sequential read-only native120sec-after-imports/8GiB sampledprivate/
minimum350MiB availablecommit plus separate independent validation. Primary
uses polynomial pullback, replay tensor-axis maps. Freeze exact source,
controller,all dependencies and role JSON reads before computation. New
copies exclusive, no overwritten frozen mirrors; preserve failures/full
captures and correct only with new versions. Controls wrong primal/dual or
ghost map, reverse external odd order, halve normalization and omit a real
carrier in the H test. Report any insensitive control explicitly. A zero
Ward variation cannot determine normalization or detect invariant doubling.

Validate before local commit. Authority34/39, seven false flags and source/
known functional/input/benchmark/scheme/policy unchanged. Full E5/A5,QAP,
measure,IR,contacts,products,equivalence and sourcefreeSlavnov unqualified.
Historical quartet failure,custodyexit2/seven references,scalar quantum/gauge
matching warnings remain. HB1/C5 blocked,flavor paused. No agents,branches/
worktrees,remote,publishing or promotion. TrackB tests consequential actual-
coordinate matching and exact assembly readiness, not a larger functional.
Shared action/charts/flat poles/UV premises/software/AI author remain limits.
