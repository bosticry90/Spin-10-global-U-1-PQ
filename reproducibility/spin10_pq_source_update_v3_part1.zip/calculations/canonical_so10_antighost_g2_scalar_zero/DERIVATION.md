# Scalar kinetic Hessian, full scalar inverse and selected UV coefficient

For every sector the actual action is one half of the real canonical norm
of D_mu x=partial_mu x+g rho_a B_mu^a x. Put x=s+phi with constant external s,
and expand around zero external vector. Let T_ai=(rho_a s)_i and N=T^T.
At quadratic fluctuation order the relevant kinetic expression is
 1/2 sum_mu (partial_mu phi+g T^T B_mu)^T
                  (partial_mu phi+g T^T B_mu).
The g B phi part of D does not multiply a background derivative in this
constant-s quadratic coefficient. Ordinary differentiation fixes all contact,
Fourier, Bose and1/2 factors. It gives scalar principal Q I, mixed blocks
+i g q_mu T and -i g q_nu N, and g^2 delta_mu,nu TN in the gauge Hessian.

The scalar Schur complement at orderg^2 is
 g^2 (delta_mu,nu-q_mu q_nu/Q)TN.
Both end auxiliary/vector Green blocks are proportional to q, so its
longitudinal projection vanishes. The full inverse Born route must give the
same zero from its two individually nonzero pieces, not a fitted contact.
This is an index-independent rectangular block identity; complete328 scalar
support and its unit leading inverse must be established in the actual chart.
Two symbolic finite-color/matter Fourier polarizations check factors and signs
but do not substitute for that arbitrary-dimension identity.

The ghost bilinear Gaussian current from two X_{L,a,C} vertices couples only
to L. Its source-free one-loop coefficient contains the LL inverse response
and a ghost Green function. The selected scalar-pair response has no scalar
coupling in the ghost principal itself; its full LL orderg^2 contribution is
the contact/exchange pair. All eight catalogue profiles must be exactly these
four sector pairs; S3/S4 are actually zero in S if every rho_S=0. Full spinor/
quintic tensor potentials are not discarded; any positive-dimensional mass/
VEV coefficient exceeds this external aCxx dimension-four budget, and no
potential vertex appears in the complete selected bare catalogue. No EOM use.

The actual Minkowski scalar principal is P-Mref^2. Under the qualified p0=iq0
and scalar congruence x_M=i x_E it becomes Q+Mref^2. With the existing vector
congruence R=diag(1,-i,-i,-i) and formal g_E=-i g_M,
D_M x_M=-R D_E x_E, so +1/2 eta(D_M x_M)^2 becomes +1/2(D_E x_E)^2.
All derivative and interaction phases must be checked together. This is an
analytic normalization bridge for a zero, not a new physical coupling/scheme.

At the selected homogeneous UV order, replace Q+Mref^2 by Q only in its
leading symbol, not in the finite integral. V255 relates the complete ordered
unheated leading symbol to the logarithm. Different heat placements may
leave finite pieces. Vanishing of a whole scaleless integral or the finite/IR
amplitude is never inferred. Qualification requires completed native outputs,
independent receipt and committed-byte verification with all scope limits.
