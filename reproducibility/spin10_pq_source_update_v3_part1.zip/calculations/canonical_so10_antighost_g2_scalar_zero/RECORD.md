# g10^2 scalar-pair antighost coefficient V1

Previous goal turn: PROGRESS (V259 finite frontier and V260 complete vector
cohort validated/committed). Recovered HEAD c19bedbae55c0dd0ddd8eb38e55cc68004766e36,
clean main, no matching live calculations. Keep the full investigation goal.

Question AG2S: can the eight remaining g10^2 scalar-pair aC no-derivative
profiles be closed using the ACTUAL canonical scalar kinetic action and
complete328 scalar principal inverse? V260's vector result does not answer it.
This tests a genuine source-free coverage gap by the least expensive competent
method before a new component-loop compiler. Success, nonzero result and exact
missing-premise/inconclusive are all legitimate outcomes. No fitted identities.

Freeze all four literal +1/2(Dx)^2 ASTs, their bound180 representation matrices
and canonical dimensions54+252+20+2, actual scalar chart and full107584-position
scalar principal blocks, actual full45 mixed reference, V255 UV theorem and
V259/V260 results. Preserve kinetic factors, phases, masses/VEVs, source and
width conventions, background reference and seven false quantum flags. The
Spin(10) singlet has a proposed two-profile zero only if all45 actual rho_S
matrices are proved zero. Gauge-PQ claims are outside this test.

Primary: exact noncommutative6-block inverse Born coefficient with formal
rectangular T:scalar->gauge and N:gauge->scalar and arbitrary color width W.
Derive T_ai=(rho_a x)_i, N=T^T and contact TN from the actual kinetic AST,
including its factor1/2. Replay: eliminate the scalar principal block first,
then contract the resulting transverse gauge kernel with both longitudinal
mixed propagators. Use complete symbolic Fourier polarization as a factor/
Bose-sign control. Independent verification uses ordinary SymPy operators,
actual representation support/digests, full scalar frame/principal zero support,
both route graph witnesses and the Wick normalization bridge.

For constant external scalar x, the proposed kinetic Hessian has mixed blocks
K_Bphi=+i g q T, K_phiB=-i g q N, scalar principal Q, and gauge contact
g^2 delta_mu,nu TN. Their exchange/contact longitudinal contractions MAY
cancel. It must follow from actual action differentiation, not assigning a
mass vertex to make it work. The complete ghost bilinear uses two actual X
vertices and the LL inverse response; retain all proper-cycle multiplicities
via Gaussian elimination/Schur complement, not informal diagram counting.

Scalar potential/VEV Eulers are not set to zero. Use the dimension-four ring
and complete catalogue to prove their absence only from THIS coefficient.
Reference mass terms are lower symbol order; the formal UV correspondence is
not a finite/IR-amplitude theorem. No off-flat A completion, other positive-
dimension sector, ordinary g2 completion, g3/g4 or full E5 claim is authorized.

Negative controls: omit the scalar exchange, alter the contact normalization,
reverse one mixed Fourier sign, rescale one scalar principal, omit an abstract
scalar-sector complement and falsely treat the singlet matrices as charged.
Retain controls that are insensitive as such; width changes need not affect
this specific scalar path. Do not silently call six nonzero family pieces zero:
only each complete scalar-sector pair is a candidate zero, plus genuine S zeros.

Two sequential own-role read-only native120sec afterimports/8GiB sampledprivate/
min350MiB availablecommit and independent bounded verifier. Freeze code,
controller and input/read manifests first; preserve failed sources and full
captures with versioned corrections. Validate before localcommit. No agents,
branches/worktrees, authority/policy/functional/source/input/benchmark/scheme
change, remote action, flavor resumption or HB1/C5 activation. Formal authority
34/39, E5/A5/QAP/measure/contacts/products/equivalence/IR unqualified. Track B:
judge useful structural gap closure and avoidance of false zero transfer; shared
action, reference, catalogue, software and AI author limit scientific independence.
