# Replay continuation V2: actual scalar coordinates instead of legacy label

Primary V1 completed; replay V1 failed before algebra on scalar_coordinates.
The actual full_replay.json has the same four sector dimensions, representation
matrices and digests but omits that legacy label list. Preserve both captures,
original code, controller, preparation and completed primary output.

V2 derives all328 expected canonical field names, dimensions, ghost numbers
and parities from the current actual alphabet and confirms the complete
reference-map/principal checks remain. If a historical label list is present,
its328 count remains checked. No scientific coordinate/domain obligation is
removed and no physical matrix or convention changes. New source changes
only the preparation pointer and this schema-aware coordinate check.

Reuse the completed primary, execute only a corrected replay at the same
120sec/8GiB/minimum350MiB limits, then perform full independent verification.
A failed legacy-label read is not a scientific zero and is never accepted.
