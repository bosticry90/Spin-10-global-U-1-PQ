# Selected scalar-pair antighost local logarithm V1

Both completed native routes obtain a zero combined one-loop local logarithmic
coefficient for all eight flat/bare g10^2 aCxx profiles with no derivatives or
dimensionful coefficients. This is a structural reduction from the actual
kinetic action, not a new loop integration. Qualification still requires the
completed independent receipt and committed-byte checks; this report alone
is not such a receipt.

## Exact scope and mechanism

The parent action has four actual real half-norm kinetic ASTs, with canonical
dimensions54+252+20+2=328. All180 generator matrices match their bound digests
and are real and skew. Nonzero entries: Phi1122, Sigma6300, phi180, S0.
All45 S matrices are zero, so its two catalogue S3/S4 profiles have actual
zero vertices. This is Spin(10) neutrality, not a statement about global PQ.

The other six profiles cancel only in three complete scalar-sector pairs:
Phi1926/1927, Sigma1974/1975 and phi2004/2005. The singlet profiles are1956/1957.
Neither charged sector's contact or exchange family is individually zero.
For arbitrary rectangular T_ai=(rho_a x)_i and its opposite map N, the exact
mixed inverse yields
 LL_exchange = TN/Q, LL_contact = TN/Q, LL2 =0.
The common sign/subtraction is derived from the actual kinetic Hessian and
inverse series. It is not fitted to an antighost or Slavnov cancellation.
The scalar-first Schur route instead obtains the transverse gauge response
(delta_mu,nu-q_mu q_nu/Q)TN, which both longitudinal B/L endpoints annihilate.
The block identity is valid for arbitrary gauge/scalar dimensions and any
fixed gauge-coordinate congruence: both mixed blocks and their contact
transform together. No orthogonality assumption about the C3 chart is needed.

The actual scalar frame is an identity permutation of all328 canonical fields.
Both complete scalar principal matrices have328 diagonal entries,107256 exact
implicit zeros over107584 positions, and no mixed nonscalar reference entries.
All four reference masses are retained in their records; only the homogeneous
UV principal is used here. The dimension-four external aCxx coefficient leaves
no positive mass/VEV dimension. The complete eight-profile inventory contains
only the two X vertices and S3/S4 kinetic partners, not a scalar potential
vertex. No scalar Euler equation or vacuum stationarity is imposed.

The ghost bilinear Gaussian reduction uses the LL response between two actual
X_{L,a,C} vertices. All graph placements, relative contact/exchange factors and
external-scalar Bose polarizations follow from the quadratic half-norm and
complete inverse. A121-position symbolic two-color/three-scalar Fourier
polarization tests the factor1/2 and relative signs; the general rectangular
block theorem and complete actual scalar-principal checks establish the full
328-direction domain. The finite fixture alone would not establish that scope.

The scalar analytic bridge x_M=i x_E, with the inherited vector congruence and
formal g_E=-i g_M, maps D_M x_M to -R D_E x_E and the scalar principal to
Q+Mref^2. It fixes the relative scalar/mixed/contact phases. No new physical
gauge, complex coupling, reference or Wick prescription is adopted.
V255's qualified ordered-heat correspondence transfers the vanishing leading
unheated symbol to this local logarithm. Finite differences from heat placements
and infrared behavior remain outside the result; no whole scaleless integral
is used to infer a separate UV zero.

## Verification boundary and records

Primary22.401sec afterimports/90296320sampledprivatebytes; corrected replay
22.731sec/91725824bytes. Both within120sec/8GiB/minimum350MiB availablecommit.
Replay V1 failed before algebra on a legacy scalar_coordinates label missing
from its older representation record. V2 uses all actual canonical names,
grades and the complete reference map. The original failure and completed
primary are retained; the primary was reused rather than rerun. No failed
execution is accepted and no fresh byte-identical replay is claimed.

The independent verifier must compare both complete native outputs, actual
ASTs/representation digests, all scalar frame/principal support, the arbitrary
rectangular inverse, all121 Fourier slots, scalar Wick phases and both actual
cycle witnesses. It retains the distinction between two singlet zeros and
three paired charged-sector zeros. Controls omit/change contact/exchange,
flip one mixed phase, change one scalar inverse normalization, omit a formal
scalar complement and alter the zero S matrix digest. Width changes are
insensitive for this particular scalar intermediate path and are not counted
as sensitive controls. Final verifier performance/counts belong to its receipt.

No source/known-functional/input/benchmark/scheme/policy/authority change.
Known functional155110, sourcefree40309, sourceimage146663 remain. Seven
quantum flags false; full sourcefreeSlavnov, QAP, measure, contacts/products,
equivalence, IR and E5/A5 unqualified. Authority34/39, custodyexit2/seven
references and historical failures remain unchanged. This does not complete
g10^2: the explicit-A derivative profile and off-flat response remain separate,
as do all positive-dimensional and higher g10^3/g10^4 obligations.

The next smallest useful investigation is the remaining explicit-background
ACa one-derivative g10^2 profile. Inspect its actual color contraction and
complete existing unbroken-antighost evidence before declaring a zero or
reconstructing it from a desired Ward identity. Do not reopen a full expansion.

Track B: the different scalar Hessian was checked directly rather than assuming
V260's vector cancellation transfers. A real singlet overapproximation was
removed and a complete coefficient cohort reduced without a dense loop tensor.
The replay schema failure remains an implementation limitation. Action,
reference/representation data, catalogue, prior UV proof, software and AI author
are shared; no Lean, independent scientist, experiment or full quantum
construction is claimed.
