"""Actual canonical scalar kinetic g2 antighost cohort via rectangular inverse."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent

def load(n,p):
 q=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(q);q.loader.exec_module(z);return z
a=load('qualified_scalar_frontier_helpers',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;read=a.read;digest=a.digest;PKG=a.PKG
z=load('qualified_ordered_color_algebra',OUT.parent/'canonical_so10_antighost_g2_vector_zero/zero_v2.py');q=z.q;Q=z.Q;sc=z.sc;letter=z.letter;add=z.add;mul=z.mul;scale=z.scale;ser=z.ser;dot=z.dot;rowmul=z.rowmul
DIMS={'Phi':54,'Sigma':252,'phi':20,'S':2}
@lru_cache(None)
def num(txt):return s.sympify(txt)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(j in args[1] for j in 'wax+'):raise PermissionError('G2_SCALAR_ZERO_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();ans=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return ans
 from m08_local_functional_ast import add as AA,mul as MM,scalar,field,derivative,tensor,parameter
 def contract(expr,idx,lor=False):return {'node':'LorentzContraction' if lor else 'GroupContraction','expression':expr,'contracted_indices':list(idx),'parity':0,**({'metric':'diag(1,-1,-1,-1)'} if lor else {})}
 ap=PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';ab=read(ap.parent/'bindings.json');assert ab['byte_sha256'][ap.relative_to(ROOT).as_posix()]==digest(ap);action=read(ap);physical,pb=b.sealed('frozen_a10_physical_reconciliation','full_'+role);assert physical['sector_dimensions']==DIMS and len(physical['scalar_coordinates'])==328 and physical['representation_digests']==action['representation_digests'];rep=[]
 def actual_kinetics():
  for sec,n in DIMS.items():
   D=AA(derivative('mu',field('x_'+sec,indices=('i',))),contract(MM(parameter('g10',mass_dimension=0),tensor('RepresentationGenerator','rho_'+sec,('a','i','j')),field('B',indices=('a','mu')),field('x_'+sec,indices=('j',))),('a','j')));expected=contract(contract(MM(scalar(s.Rational(1,2)),D,D),('i',)),('mu',),True);actual=next(r for r in action['local_terms'] if r['term_id']=='kinetic_'+sec);assert actual['density']==expected and action['index_domains'][sec]==n
   matrices=physical['representation_matrices'][sec];assert len(matrices)==45;count=0;dd=[]
   for k,r in enumerate(matrices):
    assert r['shape']==[n,n];entries={(i,j):num(co) for i,j,co in r['entries']};assert len(entries)==len(r['entries']) and all(0<=i<n and 0<=j<n for i,j in entries);assert all(s.simplify(co+entries.get((j,i),0))==0 and s.simplify(co-s.conjugate(co))==0 for (i,j),co in entries.items());count+=len(entries)
    canonical={'shape':[n,n],'entries':[[i,j,str(s.simplify(co))] for (i,j),co in sorted(entries.items())]};hh=__import__('hashlib').sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert hh==physical['representation_digests'][sec][k];dd.append(hh)
   assert (count==0)==(sec=='S');rep.append({'sector':sec,'dimension':n,'generators':45,'nonzero_entries':count,'matrix_digests':dd,'all_real_skew':True,'actual_S_spin10_singlet':sec=='S'})
  return rep
 reps=stage('literal_four_half_norm_ASTs_all180_real_skew_matrices_and_S_zero',actual_kinetics)
 def reference():
  core,cb=b.sealed('frozen_a10_e5_full_hessian',role);rr=core['retained_reference'];names=rr['field_order'];T={(i,j):num(co) for i,j,co in rr['physical_to_raw_kernel']['entries']};I={(i,j):num(co) for i,j,co in rr['physical_to_raw_inverse']['entries']};scalarindices={i for i,n in enumerate(names) if n.startswith('x_')};assert len(scalarindices)==328
  for i in range(180,508):
   row=[(j,co) for (ii,j),co in T.items() if ii==i];assert len(row)==1 and row[0][0] in scalarindices and row[0][1]==1;assert I.get((row[0][0],i),0)==1
  assert not any((i in range(180,508))!=(j in scalarindices) for i,j in T if i in range(180,508) or j in scalarindices)
  pp=s.symbols('p0_ref:4',real=True);P=pp[0]**2-sum(x*x for x in pp[1:]);loc=dict(zip(map(str,pp),pp));blocks={};massnames=set()
  for key,label in [('reference_Hessian_raw_C3','K'),('reference_Green_raw_C3','G')]:
   entries={}
   for i,j,co in rr[key]['entries']:
    if i not in scalarindices and j not in scalarindices:continue
    assert i in scalarindices and j in scalarindices
    val=s.sympify(co,locals=loc);mass={a:0 for a in val.free_symbols if str(a).startswith('Mref_')};massnames|=set(map(str,mass));entries[i,j]=s.cancel(val.xreplace(mass))
   assert entries=={(i,i):P if label=='K' else 1/P for i in scalarindices};blocks[label]=len(entries)
  assert len(massnames)==4;assert Counter(names[i].split('_')[1] for i in scalarindices)==Counter(DIMS)
  mr=s.Symbol('Mref_squared');PE=P.xreplace({pp[0]:s.I*q[0],**{pp[i]:q[i] for i in range(1,4)}});assert s.expand(-PE+mr-Q-mr)==0
  actual=b.auth('canonical_so10_ub12_reference_symbol',role+'_v2_result.json');assert len(actual['all45_mixed_principal_blocks'])==45 and actual['all45_ghost_orientation_pairs_and328_scalar_principals_checked'];return {'scalar_directions':328,'full_scalar_slot_domain':328**2,'principal_nonzero':blocks,'principal_implicit_zeros_exact':328**2-328,'mass_names':sorted(massnames),'scalar_raw_physical_frame_is_identity_permutation':True,'Wick_scalar_i_phase_recovers_Q_plus_Mref_squared':True}
 refinfo=stage('actual_all328_scalar_chart_and107584_principal_slot_domain',reference)
 def ordered():
  W=letter('W');TT=letter('T');NN=letter('N');TN=mul(TT,NN);K0=[[sc(Q*int(i==j)-q[i]*q[j]) for j in range(4)] for i in range(4)];GB=[[add(sc(int(i==j)/Q-q[i]*q[j]/Q**2),scale(W,-q[i]*q[j]/Q**2)) for j in range(4)] for i in range(4)];G5=[row+[sc(s.I*q[i]/Q)] for i,row in enumerate(GB)]+[[sc(-s.I*x/Q) for x in q]+[{}]];G=[row+[{}] for row in G5]+[[{}]*5+[sc(1/Q)]]
  V1=[[{} for j in range(6)] for i in range(6)];V2=[[{} for j in range(6)] for i in range(6)]
  for i in range(4):
   V1[i][5]=scale(TT,s.I*q[i]);V1[5][i]=scale(NN,-s.I*q[i]);V2[i][i]=TN
  end=[G[i][4] for i in range(6)];exchange=dot(rowmul(rowmul(rowmul(G[4],V1),G),V1),end);contact=dot(rowmul(G[4],V2),end);assert exchange==contact==scale(TN,1/Q)
  if role=='primary':answer=add(exchange,scale(contact,-1))
  else:
   reduced=[[scale(TN,int(i==j)-q[i]*q[j]/Q) for j in range(4)] for i in range(4)];answer=add(*(scale(reduced[i][j],q[i]*q[j]/Q**2) for i in range(4) for j in range(4)));assert not answer
  assert not answer;assert add(exchange,scale(contact,-2)) and add(exchange,contact)
  kap=s.Symbol('wrong_scalar_principal_factor');wrong=add(scale(exchange,1/kap),scale(contact,-1));assert wrong
  omitted=scale(mul(letter('T_omitted'),letter('N_omitted')),1/Q);assert omitted
  return {'mixed_B_scalar':[[ser(V1[i][5]),ser(V1[5][i])] for i in range(4)],'gauge_contact_TN_diagonal':ser(TN),'LL_scalar_exchange':ser(exchange),'LL_scalar_contact':ser(contact),'combined_LL2':ser(answer),'wrong_contact_factor':ser(add(exchange,scale(contact,-2))),'wrong_one_mixed_phase':ser(add(scale(exchange,-1),scale(contact,-1))),'wrong_scalar_principal':ser(wrong),'omitted_scalar_complement':ser(omitted)}
 algebra=stage('full_rectangular_B_L_scalar_inverse_vs_scalar_Schur_first',ordered)
 def polarization():
  g=s.Symbol('gg');hh,kk=s.symbols('h k');TT=s.Matrix(2,3,lambda a,i:s.Symbol('t_'+str(a)+'_'+str(i)));bp=s.symbols('bp0:8');bm=s.symbols('bm0:8');xp=s.symbols('xp0:3');xm=s.symbols('xm0:3');L=0
  for mu in range(4):
   for i in range(3):
    plus=s.I*q[mu]*xp[i]+g*sum(TT[a,i]*bp[4*a+mu] for a in range(2));minus=-s.I*q[mu]*xm[i]+g*sum(TT[a,i]*bm[4*a+mu] for a in range(2));L+=(hh*plus+kk*minus)**2/2
  pol=s.expand(L).coeff(hh,1).coeff(kk,1);minus=list(bm)+list(xm);plus=list(bp)+list(xp);pos=[]
  for i,f in enumerate(minus):
   for j,h in enumerate(plus):
    value=s.diff(pol,f,h)
    if i<8 and j<8:expected=g*g*int(i%4==j%4)*sum(TT[i//4,a]*TT[j//4,a] for a in range(3))
    elif i<8:expected=s.I*g*q[i%4]*TT[i//4,j-8]
    elif j<8:expected=-s.I*g*q[j%4]*TT[j//4,i-8]
    else:expected=Q*int(i==j)
    assert s.expand(value-expected)==0;pos.append([i,j,str(s.expand(value))])
  # Exact analytic phases: x_M=i x_E, partial_M=i R partial_E,
  # B_M=R B_E, g_E=-i g_M, no new physical parameter choice.
  R=[1,-s.I,-s.I,-s.I];eta=[1,-1,-1,-1]
  for mu in range(4):assert s.I*R[mu]*s.I==-R[mu] and eta[mu]*R[mu]**2==1 and g*R[mu]*s.I==-R[mu]*(-s.I*g)
  return {'exact_generic_two_color_three_scalar_Fourier_slots':121,'half_norm_double_polarization_all_slots':pos,'all4_scalar_Wick_derivative_interaction_phases_match':True,'finite_polarization_is_control_not_328_component_loop_replacement':True}
 fixture=stage('literal_half_norm_Fourier_double_polarization_and_Wick_factors',polarization)
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');profiles=[]
 for i,row in enumerate(inv['all_profiles']):
  ty=sorted('x' if n.startswith('X_') else n[0] for n,j in row['external_ports'])
  if row['g']==2 and ty==['C','a','x','x'] and row['total_external_jets']==0:
   scalarroles=[n[2:] for n,j in row['external_ports'] if n.startswith('X_')];assert len(set(scalarroles))==1;sec=scalarroles[0];fam=tuple(sorted(t.split('_g')[0] for t in row['vertex_family']));assert fam in [('S3','S3','X','X'),('S4','X','X')] and row['vertex_coefficient_dimension']==0 and not row['scalar_reference_mass_expansions'] and row['witness']['Taylor_degree']==row['witness']['raw_UV_degree']==0;profiles.append({'index':i,'sector':sec,'family':list(fam),'external_ports':row['external_ports'],'classification':'ACTUAL_SPIN10_SINGLET_VERTICES_ZERO' if sec=='S' else 'ZERO_ONLY_AFTER_SAME_SECTOR_CONTACT_EXCHANGE_SUM'})
 assert len(profiles)==8 and Counter(r['sector'] for r in profiles)==Counter({sec:2 for sec in DIMS});uv=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');parent=b.auth('canonical_so10_antighost_g2_vector_zero',role+'_v2_result.json','validation_v2_receipt.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and parent['complete_ghost_bilinear_Schur_block_proof_with_first_order_F_dressing'];qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in parent['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'ANTIGHOST_G2_SCALAR_ZERO_V1','route':role,'scientific_disposition':'COMPLETE8_BARE_G2_SCALAR_PAIR_ANTIGHOST_LOCAL_LOG_ZERO','all_four_literal_half_norm_ASTs_and_bound180_real_skew_generators':reps,'actual_scalar_reference_full_domain':refinfo,'rectangular_noncommuting_scalar_response':algebra,'half_norm_polarization_and_Wick_bridge':fixture,'all8_actual_profiles':profiles,'two_actual_S_profiles_individually_zero_six_only_as_three_pairs':True,'all328_scalar_directions_retained_no_projected_scalar_inverse':True,'complete_bosonic_Gaussian_X_LL_ghost_bilinear_reduction':True,'mass_VEV_potential_Eulers_not_set_zero_only_selected_dimension4_absence':True,'leading_unheated_symbol_zero_implies_formal_log_not_finite_heat_IR_zero':True,'offflat_A_other_g2_or_positive_dimension_g3_g4_not_claimed':True,'controls':{'drop_exchange_keeps_nonzero_contact':True,'wrong_contact_coefficient_nonzero':True,'wrong_one_mixed_Fourier_sign_nonzero':True,'wrong_scalar_principal_factor_nonzero':True,'omit_formal_scalar_complement_nonzero':True,'S_zero_generator_support_and_digest_excludes_charged_S_assertion':all(r['nonzero_entries']==0 for r in reps if r['sector']=='S')},'insensitive_control':'Changing W does not affect this scalar-intermediate path;not claimed as a sensitive width test','all_seven_quantum_flags_false':flags,'functional_source_input_benchmark_scheme_authority_changed':False,'full_QAP_measure_IR_contacts_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual kinetic/representation/reference/catalogue inputs,prior UV theorem,software and AI author shared;generic block proof plus complete scalar chart checks,not new pole integration,Lean,expert or experiment','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
