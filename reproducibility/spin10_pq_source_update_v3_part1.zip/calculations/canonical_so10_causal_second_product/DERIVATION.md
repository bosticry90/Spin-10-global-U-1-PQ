# CSP1 — a normalized two-vertex product on the actual graded multiplet

Prospective pending computations and separate validation. This proves a
two-vertex, through-one-loop construction, not the induction for every Tn.

## 1. Reference and contraction order

Use the complete CWB1 off-shell graded Wick algebra, C_F=iG_F, and the inherited
source-left convention. Let Gamma12 be the even constant cross contraction
operator with the right derivative in slot1 and left derivative in slot2.
Its value on z_i tensor z_j is C_F,ij. External BV sources and backgrounds
have no propagators. At distinct vertex points define

 T2(F,G)=m[1+hbar Gamma12+(hbar^2/2) Gamma12^2](F tensor G)
              + terms with three or more cross contractions.

The omitted terms have at least two loops in a connected two-vertex graph.
The one-edge term is a tree, even if its two vertices have high polynomial
degree. For composite vertices the two-edge term retains all uncontracted
fields and sources, not just a vacuum projection. Self edges are absent because
T1(F)=F; use CWB1 beta=1+hbar beta1 when comparing a heat-normalized input.
Do not confuse this with dropping the physical singlet tadpole.

All actual matrix components and their finite jets enter this formula. The
weighted double inverse in BB retains its quadratic numerator. FBR1/CWB1 give
its Feynman orientation and finite scaling degree; ghost and mixed entries
are included with their ordered signs. Products of two such Feynman kernels
exist off the coincidence diagonal by the common wavefront orientation.
Their scaling degrees are finite; their local extensions are tempered in the
Schwartz/compact-switch domain. LBE1/MLB1 supply the actual component bridge.
The reference's indefinite gauge/ghost components do not require a positive
Hilbert norm for this algebraic construction.

## 2. One extension convention, not independently chosen favorable values

For the two-edge coefficient apply the inherited analytic finite part and
the COMPLETE HMM1 local heat comparison, then the MLB1 Lorentzian boundary.
This defines R_H on the two-edge kernels with c=4. Include power finite parts,
the full numerator/heat jets and the common symbolic kappa. The ordered matrix
products are never commuted. The uncontracted polynomial and source factors
multiply the extended distribution after the Wick expansion.

A root/momentum routing is only an auxiliary analytic calculation choice.
For example its uncorrected shift defect is local and need not vanish. The
HMM1 correction is essential: R_H is defined by agreement with the full
Euclidean heat coefficient, not by declaring the bare analytic root invariant.
One can average over the two contracted legs and the two vertex orders, with
the Koszul sign, before extending. This changes neither the heat coefficient
nor the matched extension. Equality follows first in the convergent Euclidean
regulated integral (change of loop variable and graded Wick relabeling), then
for its linear finite part and unique analytic boundary. Thus the SAME R_H
is graded permutation covariant. No new coefficient is selected to enforce
this property.

At T2 there is no nontrivial proper collision subdiagonal: the only collision
is x=y. Any local difference in extending its two-edge kernel is supported
there. On a strict causal-order region no such difference contributes. C_F
there is W in the specified order; the product above equals the equally
truncated F star G (or its reversed graded order). This proves causal
factorization at this order. It does not prove the subdiagonal compatibility
required at T3 and higher. Translation covariance follows from difference
kernels and constant local extension coefficients.

## 3. Graded multiplet jets and the action Ward identity

For any labeled n-field monomial, introduce commuting derivative momenta
p_i, with species/parity attached to its slots. Let

 P=sum_i p_i,       r_i=p_i-P/n,       sum_i r_i=0.

Over characteristic zero this is an invertible linear decomposition into
P and n-1 independent r_i. It is equivariant under EVERY slot permutation.
The supercommutative field quotient is the image of the signed permutation
projector, including permutations of species labels. P is invariant and the
r-space is stable; hence that projector acts trivially on the polynomial
algebra in P. Its image factors as polynomials in P tensor the balanced
graded multiplet space. This proves the needed multiplet version, including
odd repeated species/derivative slots; it assumes no parity=2*dimension rule.
For n=0 the coefficient is a constant; n=1 has r=0. Sources can be labeled
slots too, but are never integrated covariance directions.

Define extensions on balanced contracted jet tensors, then define total
derivatives by differentiating the FULL extended distribution. Equivalently
R_H[P^alpha t_bal]=P^alpha R_H[t_bal]. This is compatible with the actual
heat matching: total external momentum is independent of loop momentum;
the SAME damping multiplies all numerator terms in this linear identity.
Both heat finite part and the corrected analytic boundary commute with
this multiplication. No separate finite choice is made for each jet.

In a Wick coefficient a total derivative of a vertex differentiates either
an uncontracted field/source or one of its contracted legs. The ordinary
graded product rule and the last identity add these into the full vertex
derivative. Thus T2(partial_mu F,G)=partial_xmu T2(F,G), and similarly in
the second slot, as distributions. Compact switching gives the equivalent
integration-by-parts identity. Derivatives of switching/source coefficients
are retained. This is the off-shell AWI, not a free-equation quotient.

In particular K*C_F=i delta I is NONZERO, whereas K*W=0. The differentiated
one-edge term contains this tree contact. Replacing the off-shell quotient
by the free field equation would already contradict the above normalization.
Higher derivatives of light-cone or step distributions are derivatives of
the entire distribution, not pointwise differentiated values away from it.

## 4. Field independence and first source/Slavnov insertions

Choose R_H once on contracted species/jet tensors, independently of the
surrounding uncontracted fields. Expand all vertex polynomials by their left/
right derivatives before restriction to zero fields or sources. Since the
reference contraction is field independent, differentiating the result
leaves R_H unchanged and differentiates the uncontracted factors. Pair
counting is exactly the derivative of the two input polynomials; thus the
graded chain rule for field independence holds. Local field variations with
jets follow by the same AWI/product rule. The construction is one coherent
Wick expansion, not unrelated extensions of individual full amplitudes.

For an external source J, T2(J X,G)=J T2(X,G) with its recorded ordering;
delta_J must precede J=0. The general polynomial/jet domain contains the
actual source-rule insertions and their first variations. The inherited
one-loop first-variation extension supplies them in the same R_H convention.
Nonlinear Q is NOT a constant field derivative: [Q,T2] can have nonzero
contraction/contact terms. This construction defines those terms; it neither
sets them to zero nor supplies a complete Slavnov/QAP theorem.

## 5. Nonzero measured normalization and finite freedoms

The actual LIB1 two-edge insertion tensor T has368 canonical coefficients
(304 physical), with W368 and L1712 source-related descendants and948 local
Bose contact words. Its connected product has Fourier transform

 -i[log(mu^2/(-P-i0))-gamma_E+1-2log2+kappa]/(16pi^2).

In the effective-action convention the same ordered Born slots give
hbar*T*B_F/(32pi^2). These phases are not the same normalization as the
T2 cross-contraction coefficient; preserve the fixed factors of i and the
1/2 Wick multiplicity. The nonzero tensor and rank2 descendant equations
reuse kK=kD=kC=kappa, not a numerical fit and not an identification with b0.
Different allowed finite normalizations would change local T2 contacts;
here the existing heat-matched member is used as a mathematical construction,
without adopting it as a new physical renormalization scheme.

## 6. Boundary of this result and next decision

This constructs T2 through one-loop counting on compact local vertices of
the actual free graded system. Finite tests corroborate signs, multiplicities,
jet decomposition and source order; the distributional conclusion depends
on the qualified inputs and arguments above. No complete new Spin(10) loop
tensor is extracted. Retain Gamma_ref[A], its phase/member ambiguity, and
the absence of a global constant-vacuum limit. No rotation of a fixed positive
heat cutoff into Lorentzian S' is performed.

Next: T3 and general one-loop causal induction must sew the same local cycle
extensions with trees at proper subdiagonals and preserve these simultaneous
normalizations. The scalar causal/QAP literature does not prove that step
for this multiplet merely by citation. Full nonlinear Ward/Slavnov restoration,
multiple insertions, physical state positivity/unitarity, QAP and E5/A5 remain
unqualified. The separate scalar/Yukawa/gauge-matching frontier remains.

Primary mathematical comparisons: Dütsch–Fredenhagen, especially balanced
fields and off-shell AWI, https://arxiv.org/abs/hep-th/0403213 ;
Brennecke–Dütsch, axioms for time ordering and the QAP,
https://arxiv.org/abs/0801.1408 . Their scalar statements are guides; the
graded multiplet argument and actual reference inputs are stated here.
