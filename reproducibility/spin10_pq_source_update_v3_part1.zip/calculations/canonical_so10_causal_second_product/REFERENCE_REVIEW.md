# Director reference review, 2026-10-19

This is literature context, not scientific authority or an adopted model.
The supplied causal-progress attachment agrees with the V366 boundary:
free Wick algebra and matched coefficient distributions do not yet supply
the interacting Tn family. CSP1 takes its suggested bounded T2 step; the
physical singlet/Sigma/Yukawa limitations remain distinct.

Nick Cammarata's Goodfire essay calls itself a working hypothesis, proposes
recursive generalization as an alternative interpretation of familiar
polysemantic examples, and reports preliminary language-model audits. Its
vision results do not establish interpretability of the model executing this
research. Mechanistic inspection would require actual weights/activations
and controlled interventions, which this chat does not have. Retain this as
an AI interpretability watch item; output proofs/replays remain necessary.
Source: https://already-clean.goodfire.com/ (primary essay inspected).

Roshan–Show, PRL137,111802 (8 September2026), studies a long-lived decoupled
heavy neutrino changing charged-lepton equilibration and leptogenesis through
the expansion history. Negligible contribution to light neutrino masses
does not imply cosmological irrelevance. This is model analysis, not detection.
Source: https://doi.org/10.1103/nfkx-q6z7 (publisher abstract inspected).

King–Roshan–Show, arXiv2610.18334v1 (13 October2026), considers both decoupled
lightest and heaviest states in a minimal gauged B-L model, including gauge
production, dilution and conditional cosmic-string GW spectral breaks.
Detector reach is a forecast under that model's assumptions, not an observed
signal or a prediction of ToE-Next. Source:
https://arxiv.org/abs/2610.18334v1 (abstract/version metadata inspected).

The cited 2024 SO(10) example is specifically SUPERSYMMETRIC and has its own
two-stage breaking, thresholds and metastable strings. Its particle spectrum,
fit and topology are not imported into this project's action. Source:
https://doi.org/10.1103/PhysRevD.109.055025 (publisher abstract inspected).
The 2026 string/leptogenesis comparison likewise constrains specified global/
local B-L models, not an arbitrary Spin(10) embedding:
https://doi.org/10.1103/jl16-84ps (publisher abstract inspected; full text not
accessed). No external paper's detailed calculations were independently replayed.

Future high-value seam, conditional on director-authorized matter/flavor work:
derive actual RH-neutrino/Yukawa/CP spectrum and B-L/PQ breaking chain; determine
production and lifetime, whether matter domination occurs, and then solve
leptogenesis/reheating, BBN/relic and PQ dilution conditions. Defect predictions
require the actual global groups, quotient identifications and vacuum topology;
a generic U(1) string spectrum is insufficient. Only then derive conditional
GW observables. The preprint is a benchmark for that dependency chain, not a
reason to choose missing Yukawas or resume the human-paused sector now.

Both items inform how future questions are selected. Neither alters 34/39,
acceptance requirements, present causal priority, action or physical scheme.
