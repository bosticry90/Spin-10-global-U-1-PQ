"""CSP1 independent normalization checks and completed evidence validation."""
from pathlib import Path
from hashlib import sha256
import json,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'validation_preparation.json').read_bytes())
 for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 a,b=[json.loads((O/(role+'_result.json')).read_bytes()) for role in ['primary','replay']]
 for key in ['selected_actual_covariance','graded_permutation_tests','field_derivative_tests',
             'balanced_jet_tests','wick_coefficients_sha256','balanced_coefficients_sha256',
             'two_edge_scalar_coefficient','source_fixture_nonzero','actual_LIB_tensor_nonzero','controls']:
  assert a[key]==b[key],key
 assert a['graded_permutation_tests']==256 and a['field_derivative_tests']==1536 and a['balanced_jet_tests']==144
 assert a['actual_LIB_tensor_nonzero']==368 and all(a['controls'].values())
 sys_input=json.loads((O/'preparation.json').read_bytes())
 for p,h in sys_input['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 # Independent closed scalar Wick multiplicity: choose each contracted pair,
 # then its bijection. The order-two differential numerator needs 2! division.
 cov={tuple(z[:2]):s.sympify(z[2]) for z in a['selected_actual_covariance']}
 cs=cov['x_S_0','x_S_0'];assert cs==s.I/(s.Rational(3)-s.Rational(1,2))
 assert s.expand(s.sympify(a['two_edge_scalar_coefficient'])-s.binomial(2,2)**2*s.factorial(2)*cs**2)==0
 assert 4*cs**2 != 2*cs**2
 assert cov['C0','bar0']==-cov['bar0','C0'] and cov['C0','bar0']!=0
 # General multiplet balance is an invertible equivariant linear split.
 for n in range(1,9):
  p=s.Matrix(s.symbols('u0:'+str(n)))
  A=s.ones(1,n)
  for j in range(n-1):A=A.col_join(s.Matrix([[s.KroneckerDelta(j,k)-s.Rational(1,n) for k in range(n)]]))
  assert A.det()!=0 and A.inv()*A==s.eye(n)
  P=sum(p);rel=p-s.ones(n,1)*P/n
  assert sum(rel)==0
  for j in range(n-1):
   swapped=p.copy();swapped[j],swapped[j+1]=p[j+1],p[j]
   assert sum(swapped)==P
   r2=swapped-s.ones(n,1)*P/n
   assert r2[j]==rel[j+1] and r2[j+1]==rel[j]
 # Tree derivative contact: the actual matrix inverse convention is nonzero.
 contacts=json.loads((R/'calculations/canonical_so10_causal_wick_bridge/validation_receipt.json').read_bytes())
 assert contacts['execution_state']=='COMPLETED'
 # Away from coincidence the equation vanishes; the contact is not that value.
 contact=s.I;assert contact!=0
 # Two independent selected descendant equations have rank2, common kernel.
 M=s.Matrix([[-1,1,0],[-1,0,1]])
 assert M.rank()==2 and M.nullspace()==[s.ones(3,1)]
 # Dropping power finite parts changes an authenticated heat/mellin comparison.
 aux=s.symbols('a',positive=True);unit_analytic=aux**2/(32*s.pi**2)
 local_correction=-aux**2/(32*s.pi**2)
 assert s.simplify(unit_analytic+local_correction)==0 and local_correction!=0
 # Actual ghost bubble product versus effective-action phase, no relabeling.
 BF=s.symbols('B_F');IM=s.I*BF/(16*s.pi**2)
 assert s.simplify(-IM+s.I*BF/(16*s.pi**2))==0
 assert s.simplify(-s.I*IM/2-BF/(32*s.pi**2))==0
 # The source fixture explicitly distinguishes derivative-before-restriction.
 J,X,C=s.symbols('J X C');fixture=2*C*C*J
 assert s.diff(fixture,J).subs(J,0)==2*C*C and s.diff(fixture.subs(J,0),J)==0
 performance={};maximum=0
 for role in ['primary','replay']:
  cap=json.loads((O/(role+'_capture.json')).read_bytes())
  assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2
  sample=max(v['private_bytes'] for v in cap['all_resource_samples']);assert sample<8*1024**3
  result=json.loads((O/(role+'_result.json')).read_bytes());assert result['elapsed_after_imports']<120
  performance[role]={'seconds':result['elapsed_after_imports'],'max_sampled_private_bytes':sample};maximum=max(maximum,sample)
 receipt={'schema':'CAUSAL_SECOND_PRODUCT_VALIDATION_V1','execution_state':'COMPLETED',
 'scientific_disposition':'BOUNDED_TWO_VERTEX_PRODUCT_CONSTRUCTION_THROUGH_ONE_LOOP_WITH_SIMULTANEOUS_CAUSAL_GRADED_FIELD_AND_AWI_NORMALIZATION',
 'scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],
 'performance':performance,'native_failures_preserved':0,'verifier_failures':0,
 'tests':{'graded_permutations':256,'field_derivatives':1536,'two_leg_jet_polynomials':144,'multiplet_balance_sizes':8},
 'new_Spin10_pole_tensor_measured':False,'all_Tn_QAP_E5_A5_proved':False,
 'Slavnov_Q_derivation_or_anomaly_cancellation_proved':False,'positive_physical_state_proved':False,
 'physical_scheme_or_kappa_or_b0_selected':False,'authority_changed':False,
 'shared_inputs_and_AI_author':True,'external_validation':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
