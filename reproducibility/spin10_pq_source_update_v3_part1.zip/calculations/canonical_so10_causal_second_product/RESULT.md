# CSP1 result — first causal interacting product, through one loop

The bounded T2 construction is qualified under its inherited reference and
distributional premises. One common two-vertex product now has causal
factorization, graded permutations, translation covariance, field independence
and off-shell action/jet Ward normalization. The scope is finite compact
local polynomial vertices of the actual643-field graded free system, through
two cross contractions. This is one loop in connected graph counting; its
term is hbar^2 in T2, not hbar. It is not the full interacting Tn theorem.

The construction uses the actual C_F=iG_F, the CWB1 initial-input dictionary,
and the inherited heat/Mellin/Lorentzian extension with two-edge heat length4.
Sources stay uncontracted and are differentiated before restriction. Jets
differentiate entire distributions; K*C_F=i delta is retained. No free field
equation quotient is imposed. A permutation-equivariant split into total and
balanced momenta gives the graded multiplet AWI argument without assuming
the scalar theorem covers odd integer-dimension ghosts automatically.

At T2 the only collision set is the full diagonal. Local extensions do not
alter strict causal-order regions, where the product equals the corresponding
truncated Wick star product. The proof of field independence uses a common
extension for contracted species/jet tensors, independent of residual field
factors. An uncorrected analytic root is not treated as routing invariant;
the complete local heat comparison is essential, including power finite parts.

This is a structural composition of qualified inputs. No new full Spin(10)
pole tensor was measured, and the all-vertex statement does not follow from
finite sample counts. The actual nonzero LIB1 bubble T368canonical/304physical,
W368,L1712 and948 Bose contact words are authenticated/reused, not remeasured.
Their connected-product and effective-action phases remain distinct. The
common finite constant remains kappa; no relation to b0 or IR constants is
invented. No new physical subtraction scheme or benchmark is selected.

Two distinct native algorithms completed: disjoint signed pair matchings and
the exponential contraction operator with factorial multiplicities. Each
checked256 graded permutations,1536 field derivatives and144 two-contracted-
leg jet identities. The fixtures use selected actual mixed, ghost, scalar
reference entries and an external auxiliary source. They do not measure a
physical amplitude at the diagnostic momentum/widths. General coverage uses
the explicit distributional and graded multiplet proof in DERIVATION.md.
Independent verification also checked invertible multiplet splits for1..8
slots, closed scalar Wick coefficients, descendant rank2/common constant,
source restriction order, tree contact convention, finite power matching and
the distinct bubble phases. Some analytic controls reuse qualified earlier
proofs; they are not fresh model-wide contact/loop calculations.

One failed verifier is preserved. It caught a shared native diagnostic parser
error: all p0_refN indices had been read as zero. Original natives completed
at another regular point, but were not qualified for the intended diagnostic
point. V2 uses the trailing index and checks the exact symbol set. Both native
routes were rerun, rather than reinterpreting the failed comparison as PASS.
No scientific formula, domain, tolerance or resource cap was relaxed. The
independent expected scalar covariance2i/5 now agrees; the two-edge scalar
fixture coefficient is -8/25. The original captures and sources remain intact.
Several overly broad read-only outputs and one PowerShell positional-glob
navigation error were corrected by focused reads; no scientific workers were
launched by those navigation errors.

Successful native runtimes after imports:1.974509/2.054123seconds. Separate
verification0.154017seconds. Largest successful native private sample
162,684,928B, NOT a true peak.120s native/180s verifier,8GiB sampled allocation,
350MiB launch available-commit floor and4MiB package limits respected. Original
diagnostics and the failed verifier captures are also retained for the seal.

Completed validation_receipt_v2.json SHA256
`dcefb81b9d3c17cc90ecdb6be5deb2c53288be9a9bd7913d8f472cea9b63d9f6`.
49 original/70 V2/75 final evidence bindings. Execution validation is distinct
from director scientific acceptance, which is not performed here.

Track B: the gain is composing a nontrivial interacting product from complete
existing ingredients and exposing the next genuine causal requirement. The
failure is a shared parser mistake that survived two native methods and was
detected by a separately derived diagnostic. The methods share action,
covariances, software and AI author. The scalar causal-renormalization literature
is a mathematical standard, not independent verification of this mixed model.
No Lean certificate, external scientist, experiment or access to the research
model's internal mechanisms is claimed.

The director's latest reference attachment and five primary literature sources
are reconciled in REFERENCE_REVIEW.md. AI interpretability stays WATCH; the
RH-neutrino/B-L/PQ/defect/GW chain is a future model-dependent physics seam.
The supersymmetric2024 SO(10) example is not this model. Matter/flavor remains
human-paused, and missing Yukawas are not replaced by convenient values.

Remaining: T3/proper-subdiagonal sewing and the general one-loop causal
induction; nonlinear Slavnov/contact consistency; multiple insertions, full
QAP, measure and quantum equivalence; Gamma_ref[A]/historical-member phase;
physical states/unitarity and global/constant-vacuum limits. In particular Q
is not asserted to be a derivation of T2. Defining its contact defect does not
prove that defect zero. No E5/A5 completion is inferred.

Before extending the formal sequence, compare the remaining causal induction
question with the separate physical-control frontier. Repeating selected
free/bubble/radial fixtures is no longer justified. A T3 test must actually
address proper collisions and source/jet partners. Physical analysis must
retain the failed uniform scalar weakening and the nonzero two-loop Yukawa
carrier; a scalar-only estimate cannot establish complete quantum control.

State113/authority34of39/seven flags false, source/partialGamma and old evidence
unchanged. E5/A5 unqualified,HB1/C5blocked,C1_GSuncalculated,flavorpaused,
quartetFAIL3960/648,custodyexit2/seven. Scalar140%,Euclidean1.94% and timelike
20.27% diagnostics remain different quantities, with no successful physical
gauge matching or controlled benchmark asserted. Local-only research.
