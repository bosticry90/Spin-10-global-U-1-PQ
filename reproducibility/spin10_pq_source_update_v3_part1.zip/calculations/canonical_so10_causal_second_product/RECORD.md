# CSP1 — first interacting causal product, through one loop

Prospective contract. Base9ce1292defc9477d40aa6d2fb5cd4dc683fcd186,
clean main; V366 and its completed CWB1/MLB1/HMM1/LBE1/LIB1 inputs reused.
Question: do these inputs construct a single T2, rather than only separate
coefficient extensions, satisfying causal factorization, graded permutations,
translation covariance, field independence and the off-shell action Ward
identity through the two-cross-contraction term? The latter is one loop in
the connected effective-action counting, not order hbar in T2 itself.

Domain: finite compactly supported off-shell local polynomial vertices in
all643 integrated fields and external BV/background sources, arbitrary fixed
finite ordinary jets. Positive scalar reference masses and both symbolic
widths, actual raw/physical dual frames and odd orientation unchanged. Sources
are uncontracted graded coefficients, differentiated before restriction. No
free-equation quotient, global switching/constant-vacuum limit, or positivity
of the unphysical reference is assumed. The primary construction is flat
reference and translated local vertices, not a new fully covariant off-flat
reference determinant or physical scheme.

Acceptance: explicit T2 formula through zero/one/two cross edges; proof that
the same extensions give all five conditions above; graded multiplet/jet
argument, including derivative contacts and source differentiations. Match the
fixed-flat heat two-edge family by the inherited local Mellin comparison and
Lorentzian boundary, with c=4, and the measured LIB1 nonzero tensor/descendants.
Show what remains for Tn,n>=3 and the nonlinear Slavnov identity. Do NOT claim
that Q is a derivation of T2 or that a Ward anomaly vanishes by this construction.

Native routes: disjoint signed matchings versus repeated constant contraction
operator divided by factorial, using actual frozen reference entries at a
regular diagnostic momentum. Exact graded permutation and field-derivative
checks, an external-source-before-zero fixture, and a two-contracted-leg
balanced momentum transformation in all four spacetime directions. Independent
verification uses closed Wick coefficients, independently differentiated
balanced variables, proof review and authenticated nonzero heat/Lorentz bubble
normalizations. Finite fixtures test implementations; the all-vertex statement
depends on the explicit algebraic/distributional proof, not sample counts.

Sensitive controls: omit the 1/2 in two contractions; wrong ghost order;
differentiate after source restriction; erase K*C_F=i delta; use different
finite constants for descendants; discard finite power terms in the matching.
Identify insensitive projections explicitly. No unmeasured pole is fitted.

Bind this contract, proof, sources, original W1-W7, live policy/state, frozen
reference and completed input receipts before computation. Sequential native
120s after imports/verifier180s,8GiB sampled allocation NOT true peak,
350MiB available-commit launch floor,4MiB new package. Exact symbolic arithmetic;
no relaxed tolerances or truncated domains. Preserve failures and version any
correction. Possible outcomes: bounded construction, exact incompatibility,
precise underdefinition or incomplete resource-limited work.

Track B: test structural composition of previously qualified objects, against
the primary causal/AWI literature, rather than expand the full quantum action.
Shared action, data, libraries and AI author remain; no mechanistic access to
the research model, independent scientist, Lean or experimental validation.
The user-supplied interpretability/neutrino literature is reference steering,
not new model evidence or authorization to resume human-paused flavor.

Authority ceiling34/39, state113 unchanged. E5/A5 remain unqualified, HB1/C5
blocked,C1_GS uncalculated,quartet FAIL3960/648,custody exit2/seven. Preserve
scalar140%/matching/Yukawa limitations and distinct kappa,b0,IR ambiguities.
No old evidence, action, benchmark, policy, scheme, source functional, branch,
remote, publication or outreach changes. Local commit only after validation.
