# CSP1 diagnostic momentum continuation V2

The first independent verifier FAILED its explicit scalar covariance check.
The native routes had used name[1] for the momentum index. The frozen symbols
are p0_ref0,...,p0_ref3: their index is the final character. Both natives
therefore sampled (2,2,2,2) instead of the intended regular point (2,1,0,0).
The selected scalar covariance was -2i/17 rather than 2i/5. Agreement between
two routes sharing this parser did not detect the shared error; the independent
closed reference check did. The original runs remain mathematical diagnostics
at another regular point, but do not satisfy the intended point acceptance.

V2 changes only diagnostic symbol parsing, adds a complete assertion for the
four index names, and uses versioned captures/results/preparations. Preserve
all original sources,49 bindings, both captures and failed verifier capture.
Rerun both native routes, then the same independent checks. No physics,
normalization, formulas, tolerances, domains or resource caps are changed.
The derivative/permutation acceptance is not reduced to accommodate failure.
