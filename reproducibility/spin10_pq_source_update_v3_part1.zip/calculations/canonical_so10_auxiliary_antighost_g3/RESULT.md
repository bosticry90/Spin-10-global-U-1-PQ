# Ordinary order3 Lambda-antighost-ghost pole: measured result

Both native routes calculate a nonzero complete physical tensor with776
nonzero positions and90349 exact zeros in the full45^3=91125 domain. Ordinary
g10^3 DU and FFU are measured from the actual D/F/U action, not assigned to
make a Ward or Slavnov relation vanish. Neither canonical integration nor
an insertion consistency test has yet been performed.

The finite graded Gaussian calculation retains both DU and all6 FFU Born
orders. Independent connected Wick pairing agrees. In units
hbar*g10^3/(32pi^2 epsilon_UV), the Lorentz/graded DU unit is
2(3+reference_width_H*reference_width_M); only FFU's internal-derivative
assignment ca survives, with unit -2 reference_width_H*reference_width_M.
External derivatives give zero at the specified zero external momentum.
Full4-dimensional projector identities and the scalar UV residue normalize
these statements; an unseparated scaleless integral is never used.

The two complete color contractions are identical, each with776 nonzero
positions. Hence the width-dependent contributions cancel exactly in their
sum, leaving six times the common color tensor. This is width independence
of THIS COMPLETE local coefficient, not the complete effective action or
physical gauge independence. Both contributing CM families are nonzero.
The CH FFU profile1862 is zero after the actual derivative/color selection;
DU1924 and FFU1925 provide the two nonzero CM contributions. None is assumed
zero from field labels or from an unbroken-sector theorem.

Literal D25902 BB-Hessian positions and U334 H/M coefficients are checked in
all4 Lorentz copies against independently indexed P2/N1. Fa/Fc counts1340/334
match the actual derivative parser and the independently calculated classical
matrices. All45 color/ghost directions and both symbolic widths are retained.
The full actual principal/ghost-orientation qualification is authenticated.
The physical density uses Lambda_l a_a Z[l,a,c] C_c, canonical real orthonormal
coordinates and no additional cross-Bose factor. The toy Hessian fixes it.

Qualification still requires a COMPLETED independent receipt covering every
coefficient/zero, graded normalization, actual chart/input correspondences,
source-free profile scope and negative controls, followed by exact committed-
byte checks. Native agreement alone is insufficient. A different color method
should use the actual adjoint/projector form and an ordered sum over U,
without importing the native contraction or selecting its desired values.

The field named all_CLa_orders_coverage_after_this_class in the native output
contains the UNCHANGED prior coverage header from V265, including the three
formerly unmatched entries. It is an authenticated historical header, not
an updated family-status ledger. Qualification of these three new profiles
comes from the new completed receipt; do not edit the old header/ledger or
interpret its None entries as a scientific result about the measured tensor.

No quantum functional/source/input/benchmark/scheme/policy/authority changes.
All prior failed/inadequate evidence, including the separate V263 copy-custody
correction, remains. New sources/controllers use exclusive copies and strict
manifests. Native/independent timing and failure counts belong to the final
receipt. No new byte-identical replay, Lean/expert/experimental endorsement,
full regulated measure/IR/QAP or all-order theorem is claimed. Actions,charts,
classical export,reference/UV premises,software and AI author remain shared.

Authority34/39 and seven flagsfalse, known functional155110/sourcefree40309/
sourceimage146663 unchanged. SourcefreeSlavnov,E5/A5,measure,contacts/products,
equivalence,IR and physical GUT viability remain unqualified. Historical
quartet normalization failure,custodyexit2/seven references,scalar quantum
warning and gauge matching limitations remain. HB1/C5 blocked,flavor paused.
Next, if the coefficient validates, qualify its canonical extraction exactly
once before any integration or use in the complete order3 insertion relation.
