# Independent verifier V2: exact ghost residual normalization

The first independent worker failed in its principal-check stage. Its generic
mixed5x5 left/right inverse tests passed. The subsequent ghost2x2 assertion
used structural Matrix equality and failed on an unsimplified Q/Q expression.
The failure is an avoidable verifier implementation error, not a measured
quantum contradiction. Exact rational cancellation gives four zero residual
entries. The diagnostic source and output are preserved externally.

Keep verify.py, its source copy, original validation_preparation.json,
validation_capture.json and external validation_full_capture.json unchanged.
No completed validation receipt was produced by that failed worker. All
native pole sources,manifests,outputs,captures and every physical/action,
coefficient,normalization and mathematical requirement remain unchanged.

A new verify_v2.py replaces ONLY the structural ghost equality with exact
entrywise rational-zero tests of BOTH inverse orders. An explicit wrong-sign
ghost inverse must fail this test. The same finite Grassmann/Schur proof,
all4 D/F/U copies,indexed/adjoint matches,all91125 coefficients/zeros,complete
profile scope and negative controls remain mandatory. New controller and
strict manifest have unique names/exclusive copies. Reuse completed native
runs; rerun the full independent verifier only under the same120sec/8GiB/
minimum350MiB bounds. No numerical tolerance, physics/authority change,
old manifest rebinding or scientific acceptance waiver is permitted.
