# Actual DU/FFU auxiliary pole: finite normalized route

The local target has dimension4, no external derivatives and no coefficient
mass dimension. Its leading UV integrand is homogeneous degree-4. The actual
profile inventory permits only DU and FFU. External Lambda is supplied by U;
its two internal ports are B. In DU the remaining D ports are external a,C.
In FFU both F vertices have an internal B and an oriented internal ghost;
external a,C attach one to each. No Lambda self-propagator or scalar edge
is inserted. Internal color sums include every H/M and ghost direction.

Use physical canonical density ordering a Lambda C and define D_hm[a,c]
as the actual BB Hessian coefficient of a C B_h.B_m, U_lhm as the coefficient
of Lambda_l B_h.B_m, and Fa_b,Fc_b by (partial a) B_b Fa_b C and
 a B_b Fc_b partial C, after the qualified explicit F IBP convention.
All four Lorentz copies and the signs converting canonical C-before-a words
are checked. Actual U support, not an assumed symmetry, must establish which
(h,m) pairs occur. The selected colour contraction is first derived from
finite toy vertices, with no actual numerical coefficients supplied.

For distinct internal species h,m, the toy DU vertices are a_e C_e B_h.B_m
and Lambda_e B_h.B_m. The full i/2 logdet cross coefficient has both ordered
words and the actual off-diagonal Bose Hessian entries. A connected Wick
expansion with -i i^n/n! and propagators iG supplies the independent route.
For FFU the toy vertices have the two possible derivative placements on each
F, external a_e and C_e, plus Lambda_e B_h.B_m. All6 ordered words/pairings
are retained. A derivative on an external odd field vanishes at the selected
zero external momenta; surviving internal derivatives retain their signs.

G_BB^{mu nu}(q)=-eta^{mu nu}/Q+(1-w)q^mu q^nu/Q^2, G_ca=1/Q,G_ac=-1/Q.
The generic5x5 mixed inverse and actual45 width roles authenticate this
principal. Projector identities P_T^2=P_T, P_L^2=P_L, P_T P_L=0, trP_T=3
and trP_L=1 give the Lorentz bubble factor(3+w_h w_m)/Q^2; the derivative
triangle is longitudinal in both B legs. These are cross-checks, not a
substitution for deriving the graded determinant/ghost weights.

After finite ordered/connected units are derived, contract the complete
D_hm U_lhm and U_lhm(Fc_h Fa_m+Fc_m Fa_h) tensors with those units. There is
no Bose1/2 added to a cross h,m density coefficient: the toy Hessian already
fixes its multiplicity. The actual U color support and any vanishing Fa/Fc
blocks must be derived, including their implicit zero slots, never assumed.

The existing scalar UV residue in the same Minkowski convention is
integral d4q/(2pi)^4 (q^2-m_IR^2+i0)^-2 = i/(16pi^2 epsilon_UV)+finite.
In the stated32pi^2 normalization it is2i. A UV-shell logarithm with r0>0
or a positive auxiliary IR mass separates it from an unseparated scaleless
integral. V255 justifies the formal local leading-log extraction; none of
this calculates a finite scattering amplitude, global IR limit or full QAP.

A raw nonzero pole is not an anomaly or a failed Slavnov identity. A zero
is not full sourcefree consistency. Exact zero complements and controls,
actual action/coordinate correspondences, every3 profile witness, individual
versus collective-family meaning and all inherited limitations must be retained.
