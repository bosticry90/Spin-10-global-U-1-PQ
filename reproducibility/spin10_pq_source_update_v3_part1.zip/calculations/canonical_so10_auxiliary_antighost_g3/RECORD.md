# Complete ordinary order3 auxiliary-antighost-ghost pole V1

Base78857f5597ba58c8d4179b4b4ad8c5dae95cef6f, clean main/no live workers;
previous bounded increment V265 PROGRESS. Full Spin(10)xPQ goal remains active.
QuestionAG3:calculate the actual ordinary g10^3 Lambda-a-C local logarithmic
UV pole for every45^3 physical tensor position, including exact zeros, from
unchanged D,F,U vertices. Three actual profiles1862,1924,1925 exhaust the
remaining bare class:FFU(CH),DU(CM),FFU(CM), with LM,aM. Earlier orders1/2
are qualified; no order4 member in the complete existing catalogue. This is
not a fitted Slavnov companion, insertion normalization or new benchmark.

Freeze the qualified classical export and its actual GF/coordinate linkage,
indexed P2/N1, literal Fa/Fc and all45 internal colors, actual principal Green
blocks/ghost orientation, V265 exact cycle witnesses and scalar/reference
budget. No target Ward remainder, desired coefficient or peer result read.
Workers read ONLY own-role declared classical/domain records. The old
quantum-source color record is used for its classical Fa/Fc tensors only.
Keep both widths symbolic and all external a/C/L directions. Do not infer
an individual zero from a vanishing complete sum.

Derive kinematic/graded units BEFORE releasing color. DU:two B internal lines
between the actual D(a,C;B,B) and U(L;B,B) Hessians. FFU:two B lines and one
oriented ghost line, both placements of external a/C and both internal color
orientations. Zero external momentum is a homogeneous UV-shell extraction;
never set a whole scaleless integral to zero or infer IR/finite amplitudes.
No positive-dimensional insertion can supply this dimension-zero coefficient.
Retain all4 Lorentz directions, real-boson i/2 determinant and every1/n Born
word (2 bubble and6 triangle orders), or the complete connected Wick expansion.
Use actual Fourier Hessian left/right signs, no divergent-trace cyclicity.

Primary uses finite graded matrix traces and exact multiquadratic sparse
color contraction; replay uses literal Gaussian Wick pairings and independently
indexed color/matrix multiplication. Units and ordered contributions must
agree. Reconstruct D/U in all4 Lorentz copies, their actual P2/N1 match, both
Fa/Fc matrices and ghost/antighost canonical orientation before contraction.
Actual U support and all45 principal inverse blocks must be checked. Any
contradictory support or normalization is a preserved failure, not discarded.

Normalize by the existing Minkowski radial UV residue i/(16pi^2 epsilon),
i.e. radial2i in units hbar*g10^3/(32pi^2 epsilon_UV). Calibrate finite graded
Gaussian signs independently; verify the scalar positive-IR-mass residue
without confusing UV and IR. Complete physical tensor tables, family pieces,
zero complement and exact source/known-functional nonmutation are required.
No canonical insertion/integration or full sourcefree identity is included.

Controls omit one ordered word, reverse external odd order, omit transverse/
longitudinal propagators or either family, and restrict a nonzero internal
state. Zero/insensitive controls are reported as such. Differentiate D's
identical Bose slots correctly even if actual U makes them irrelevant.
No target coefficient may be chosen from a desired identity or reused from
an old measured sector. Both zero/nonzero pole and precise incompleteness
are legitimate scientific outcomes.

Two sequential read-only native120sec-after-imports/8GiB sampledprivate/
minimum350MiB availablecommit plus separate bounded independent verifier.
Freeze code/controller/inputs/explicit role read paths before workers;
exclusive copies, exact failures and full captures, newversion corrections.
No fresh byte-identical replay claims unless actually done. Validate before
localcommit. No agents,branch/worktree,remote,promotion,physical scheme/input/
benchmark change or flavor/HB1 activation. Authority34/39 and sevenflagsfalse;
full E5/A5,QAP,measure,IR,contacts/products/equivalence/sourcefreeSlavnov remain
unqualified. Historical custodyexit2/seven references,quartet normalization
failure,scalar quantum-control warning and gauge matching gaps stay separate.
TrackB tests whole-class closure with small graded units and structural reuse;
shared actions,charts,reference/software/AI author are not independent scientists.
