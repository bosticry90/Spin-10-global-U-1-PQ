"""Complete ordinary g3 auxiliary-antighost-ghost physical pole."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import permutations,product
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,canonical
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace

def load(n,p):
 q=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(q);q.loader.exec_module(u);return u
f=load('qualified_radical_arithmetic',Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-companion-DF-v1-2026-10-17/verify.py'))
lf=load('qualified_actual_F_derivative_parser',OUT.parent/'canonical_so10_ghost_companion_FFF/pole_v2.py')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
E=(1,-1,-1,-1);q=list(s.symbols('ag3_q0:4',real=True));K,GH,GM,PG,WH,WM=s.symbols('ag3_K ag3_GH ag3_GM ag3_PG reference_width_H reference_width_M',nonzero=True)

def auth(folder,name,receipt='validation_receipt.json'):
 p=OUT.parent/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)

def finite(family,role,flipghost=False):
 w=alphabet();w.fields={n:(1,0,0) for n in ['uL','vL','uR','vR']};w.fields.update({'cg':(1,1,1),'ag':(1,-1,1)});w.grades=w.fields;w.external={};w.pairs=[];w.p={n:gr[2] for n,gr in w.fields.items()}
 for n,t in [('ae',(1,-1,1)),('ce',(1,1,1)),('Le',(2,0,0))]:register(w,n,t)
 v=w.var
 Vs=[w.mul(v('ae'),v('ce'),v('uL'),v('uR')),w.mul(v('Le'),v('vL'),v('vR'))] if family=='DU' else [w.mul(v('ae'),v('uL'),v('cg')),w.mul(v('Le'),v('vL'),v('vR')),w.mul(v('ag'),v('uR'),v('ce'))]
 green={('uL','vL'):GH,('vL','uL'):GH,('uR','vR'):GM,('vR','uR'):GM,('cg','ag'):(-1 if flipghost else 1)/PG,('ag','cg'):(1 if flipghost else -1)/PG};target=w.mul(v('ae'),v('Le'),v('ce'));word,sg=next(iter(target.items()));n=len(Vs);orders=[]
 if role=='primary':
  names=list(w.fields);par=[w.p[k] for k in names];G={(i,j):{():z} for i,k in enumerate(names) for j,l in enumerate(names) if (z:=green.get((k,l),0))};Hs=[]
  for P in Vs:
   H=Fourier_vertex(P,w,'primary',q,q,{});Hs.append({(i,j):cell for i,row in enumerate(H) for j,cell in enumerate(row) if cell})
  for order in permutations(range(n)):
   A=G
   for count,i in enumerate(order):A=multiply(A,Hs[i],w);A=multiply(A,G,w) if count<n-1 else A
   orders.append(s.cancel(s.I*(-1)**(n+1)*trace(A,w,par).get(word,0)/(2*n*sg)))
 else:
  ext={'ae','ce','Le'}
  def pair(legs):
   if not legs:return s.S.One
   first=legs[0];z=0
   for i,other in enumerate(legs[1:],1):
    g=green.get((first,other),0)
    if g:z+=(-1)**(w.p[first]*sum(w.p[k] for k in legs[1:i]))*s.I*g*pair(legs[1:i]+legs[i+1:])
   return z
  for order in permutations(Vs):
   polys=[((),s.S.One)]
   for P in order:polys=[(word+key,z*co) for word,z in polys for key,co in P.items()]
   value=0
   for whole,co in polys:
    inside=[k for k,j in whole if k not in ext];outside=[k for k,j in whole if k in ext];cross=(-1)**sum(w.p[k]*w.p[l] for i,(k,j) in enumerate(whole) if k not in ext for l,jj in whole[i+1:] if l in ext);outer=w.mul(*(v(k) for k in outside)).get(word,0)/sg;value+=co*cross*outer*pair(inside)
   orders.append(s.cancel(-s.I*s.I**n*value/s.factorial(n)))
 total=s.cancel(sum(orders));return total,orders

def avg(P,wrong=False):
 out=0
 for term in s.Add.make_args(s.expand(P)):
  if term==0:continue
  powers=term.as_powers_dict();ns=[int(powers.get(z,0)) for z in q];rr=int(powers.get(K,0));assert sum(ns)+2*rr==-4,(term,ns,rr)
  if any(n%2 for n in ns):continue
  weight=s.S.One
  for j in range(sum(ns)//2):weight/=4+2*j
  for mu,n in enumerate(ns):weight*=s.factorial2(n-1) if n else 1;weight*=1 if wrong else E[mu]**(n//2)
  out+=term/s.prod(z**n for z,n in zip(q,ns))/K**rr*weight
 return s.expand(2*s.I*out)

def units(role):
 D,Do=finite('DU',role);F,Fo=finite('FFU',role);assert s.cancel(D+s.I*GH*GM)==0 and s.cancel(F-s.I*GH*GM/PG)==0
 d,u,e,V=s.symbols('ag3_d ag3_u ag3_e ag3_V');H=s.Matrix([[1/GH,d+u],[d+u,1/GM]]);cross=s.diff(s.I*s.log(H.det())/2,d,u).subs({d:0,u:0});assert s.simplify(cross-D)==0
 H=s.Matrix([[1/GH,V-e/PG],[V-e/PG,1/GM]]);cross=s.diff(s.I*s.log(H.det())/2,e,V).subs({e:0,V:0});assert s.simplify(cross-F)==0
 eta=s.diag(*E);p=s.Matrix(q);Q=(p.T*eta*p)[0];G=lambda W:-eta/K+(1-W)*p*p.T/K**2;A=G(WH);B=G(WM);LD=s.expand(s.trace(eta*A*eta*B));LF=s.expand(((-s.I*eta*p).T*A*eta*B*(s.I*eta*p))[0]/K)
 rawD=s.expand(D/(GH*GM)*LD);rawF=s.expand(F/(GH*GM/PG)*LF);uD=avg(rawD);uF=avg(rawF)
 # Complete generic projector/Lorentz proof,not a single momentum fixture.
 assert s.cancel((LD-(3+WH*WM)/K**2).subs(K,Q))==0 and s.cancel((LF-WH*WM/K**2).subs(K,Q))==0
 if role=='replay':
  assert s.expand(uD-2*(3+WH*WM))==0 and s.expand(uF+2*WH*WM)==0
 eps,m=s.symbols('ag3_eps ag3_positive_IR_mass_squared',positive=True);assert s.limit(eps*s.gamma(eps)*m**(-eps),eps,0)==1
 ctrl={'omit_one_bubble_word_changes_unit':s.cancel(sum(Do[:-1])-D)!=0,'omit_one_triangle_word_changes_unit':s.cancel(sum(Fo[:-1])-F)!=0,'reverse_external_odd_order_changes_nonzero_units':D!=0 and F!=0,'reverse_oriented_internal_ghost_changes_triangle':s.cancel(finite('FFU',role,True)[0]-F)!=0,'omit_transverse_changes_DU_unit':s.expand(uD-2*WH*WM)!=0,'omit_longitudinal_changes_FFU_unit':uF!=0,'wrong_angular_metric_changes_a_unit':s.expand(avg(rawD,True)-uD)!=0 or s.expand(avg(rawF,True)-uF)!=0};assert all(ctrl.values())
 return {'DU':str(s.factor(uD)),'FFU_ca':str(s.factor(uF)),'FFU_aa':'0','FFU_ac':'0','FFU_cc':'0','finite_DU_orders':list(map(str,Do)),'finite_FFU_orders':list(map(str,Fo)),'finite_DU_sum':str(D),'finite_FFU_sum':str(F),'all_four_Lorentz_projector_identity':True,'positive_IR_mass_UV_residue_separated':True,'controls':ctrl}

@lru_cache(None)
def num(z):return s.sympify(z,locals={'reference_width_H':WH,'reference_width_M':WM}) if isinstance(z,str) else s.sympify(z)
def exact(z):return f.field(str(s.expand(num(z))))
def unpack(z):
 assert all(a==b==0 for (a,b,mask),v in z);return s.expand(sum(s.Rational(v.numerator,v.denominator)*s.sqrt(f.rad[mask]) for (a,b,mask),v in z))
def literal(ex):
 Ds=[];Us=[]
 for label in ['D_vectorpair_ghost','F_ghost_and_auxiliary']:
  for row in ex['vertices'][label]:
   vs=[n for n in row['word'] if n.startswith('Bp')]
   if len(vs)==2 and not any(n.startswith('Ap') for n in row['word']):assert len({n.rsplit('_',1)[1] for n in vs})==1
 for mu in range(4):
  D=defaultdict(lambda:s.S.Zero);U=defaultdict(lambda:s.S.Zero)
  for row in ex['vertices']['D_vectorpair_ghost']:
   vs=[n for n in row['word'] if n.startswith('Bp')]
   if len(vs)!=2 or any(n.startswith('Ap') for n in row['word']) or not all(n.endswith('_'+str(mu)) for n in vs):continue
   a=int(next(n[2:] for n in row['word'] if n.startswith('ap')));c=int(next(n[2:] for n in row['word'] if n.startswith('Cp')));i,j=[int(n[2:].split('_')[0]) for n in vs];z=-num(row['coefficient'])/E[mu];D[i,j,a,c]+=(2 if i==j else 1)*z
   if i!=j:D[j,i,a,c]+=z
  for row in ex['vertices']['F_ghost_and_auxiliary']:
   vs=[n for n in row['word'] if n.startswith('Bp')];ls=[n for n in row['word'] if n.startswith('Lp')]
   if len(vs)!=2 or len(ls)!=1 or any(n.startswith('Ap') for n in row['word']) or not all(n.endswith('_'+str(mu)) for n in vs):continue
   i,j=sorted(int(n[2:].split('_')[0]) for n in vs);ell=int(ls[0][2:]);U[ell,i,j]+=num(row['coefficient'])/E[mu]
  Ds.append({key:s.expand(z) for key,z in D.items() if s.expand(z)!=0});Us.append({key:s.expand(z) for key,z in U.items() if s.expand(z)!=0})
 assert all(d==Ds[0] for d in Ds) and all(u==Us[0] for u in Us);assert all(ell>=12 and h<12<=m for ell,h,m in Us[0]);F=lf.literal_F(ex['vertices']['F_ghost_and_auxiliary']);return Ds[0],Us[0],F

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AG3_POLE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_OR_DESIRED_POLE',str(p))
 sys.addaudithook(guard);stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return v
 uni=stage('finite_graded_Gaussian_units_all_orders_and_full_Lorentz_UV_log',lambda:units(role));print('UNITS '+json.dumps(uni,sort_keys=True,separators=(',',':')),flush=True)
 ex=read(Path(prep['pure_classical_export']));oldp=OUT.parent/'canonical_so10_ghost_companion_D_bubbles/preparation.json';oldr=read(oldp.parent/'validation_receipt.json');assert oldr['execution_state']=='COMPLETED' and oldr['input_sha256'][str(oldp)]==digest(oldp) and read(oldp)['input_sha256'][str(Path(prep['pure_classical_export']))]==digest(Path(prep['pure_classical_export']))
 D,U,F=stage('all4_actual_D_U_F_copies_and_HM_support',lambda:literal(ex));op=auth('canonical_so10_constant_background_operators',role+'_result.json');col=auth('canonical_so10_gauge_source_g2_color',role+'_result.json');Dr={}
 for (i,j),rows in op['P2']:
  if i<12 or j<12:continue
  for a,c,z in rows:
   Dr[i-12,j-12,a,c]=(2 if i==j else 1)*num(z)
   if i!=j:Dr[j-12,i-12,a,c]=num(z)
 assert D==Dr
 Nr={(v,ell,j):num(z) for v,rows in op['N1'] for ell,j,z in rows};Ur={(ell,i,j):z for (v,ell,j),z in Nr.items() if v>=12 and (i:=v-12)<j};assert U==Ur
 Fc={};Fa={}
 for kind,label,dst in [('a','Fa_tensors',Fa),('c','Fc_tensors',Fc)]:
  for bb,rows in enumerate(col[label]):
   for a,c,z in rows:dst[bb,a,c]=num(z)
  assert dst=={(v-12,a,c):z for (v,a,c),z in F[kind].items() if v>=12}
 symbol=auth('canonical_so10_ub12_reference_symbol',role+'_v2_result.json');assert symbol['all45_ghost_orientation_pairs_and328_scalar_principals_checked'] and symbol['no_width_g_or_reference_mass_inverted_in_principal'];assert symbol['all45_mixed_principal_blocks']==[[i,'eta_H' if i<12 else 'xi','-p_squared^4'] for i in range(45)]
 cov=auth('canonical_so10_higher_antighost_coverage',role+'_result.json');target=cov['selected_smallest_whole_class_target'];assert target['indices']==[1862,1924,1925] and len(cov['selected3_actual_profile_witnesses'])==3
 if role=='replay':D,U=Dr,Ur
 def colors():
  ds={};fs={};Dby=defaultdict(list)
  for (h,m,a,c),z in D.items():
   if h<12<=m:Dby[h,m].append((a,c,z))
  if role=='primary':
   left=defaultdict(list);right=defaultdict(list)
   for (bb,a,k),z in Fc.items():left[bb,k].append((a,exact(z)))
   for (bb,k,c),z in Fa.items():right[bb,k].append((c,exact(z)))
   @lru_cache(None)
   def M(h,m):
    P={}
    for l,r in [(h,m),(m,h)]:
     for k in range(45):
      for a,x in left.get((l,k),[]):
       for c,y in right.get((r,k),[]):f.accumulate(P,(a,c),f.mul(x,y))
    return P
   for (ell,h,m),u in U.items():
    uu=exact(u)
    for a,c,z in Dby[h,m]:f.accumulate(ds,(ell,a,c),f.mul(uu,exact(z)))
    for (a,c),z in M(h,m).items():f.accumulate(fs,(ell,a,c),f.mul(uu,z))
   return {key:unpack(z) for key,z in ds.items()},{key:unpack(z) for key,z in fs.items()}
  matrices={kind:[s.SparseMatrix(45,45,{(a,c):z for (b,a,c),z in data.items() if b==bb}) for bb in range(45)] for kind,data in [('a',Fa),('c',Fc)]};dm={key:s.SparseMatrix(45,45,{(a,c):z for a,c,z in rows}) for key,rows in Dby.items()};dd=defaultdict(lambda:s.S.Zero);ff=defaultdict(lambda:s.S.Zero);cache={}
  for (ell,h,m),u in U.items():
   if (h,m) not in cache:cache[h,m]=matrices['c'][h]*matrices['a'][m]+matrices['c'][m]*matrices['a'][h]
   for (a,c),z in dm.get((h,m),s.SparseMatrix(45,45,{})).todok().items():dd[ell,a,c]+=u*z
   for (a,c),z in cache[h,m].todok().items():ff[ell,a,c]+=u*z
  return {key:s.expand(z) for key,z in dd.items() if s.expand(z)!=0},{key:s.expand(z) for key,z in ff.items() if s.expand(z)!=0}
 dc,fc=stage('complete_all45_color_contractions_before_any_symmetry_comparison',colors);du={key:s.expand(num(uni['DU'])*z) for key,z in dc.items()};ff={key:s.expand(num(uni['FFU_ca'])*z) for key,z in fc.items()};total={key:s.expand(du.get(key,0)+ff.get(key,0)) for key in set(du)|set(ff)};du={key:z for key,z in du.items() if z!=0};ff={key:z for key,z in ff.items() if z!=0};total={key:z for key,z in total.items() if z!=0}
 def pack(P):return [[*key,str(s.expand(z))] for key,z in sorted(P.items()) if z!=0]
 assert not any(c<12 for ell,a,c in du)
 assert all(all(0<=i<45 for i in key) and not z.has(s.Float) and s.expand(s.conjugate(z)-z)==0 for P in [du,ff,total] for key,z in P.items());assert all(ell>=12 and a>=12 for ell,a,c in set(du)|set(ff))
 controls={'omit_DU_family_changes_total':bool(du),'omit_FFU_family_changes_total':bool(ff),'reverse_relative_FFU_sign_changes_total':bool(ff),'half_DU_Bose_weight_changes_total':bool(du),'omit_transverse_changes_actual_tensor':bool(dc),'C_H_FFU_profile_is_zero_by_actual_tensor':not any(c<12 for ell,a,c in ff),'C_H_DU_support_absent_in_actual_profile_not_fitted':not any(c<12 for ell,a,c in du)}
 qcpath=PKG/'frozen_a10_e5_quantum_contract'/(role+'.json');qb=read(qcpath.parent/'bindings.json');assert qb['byte_sha256'][qcpath.relative_to(ROOT).as_posix()]==digest(qcpath);qc=read(qcpath);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
 result={'schema':'COMPLETE_ORDINARY_G3_AUXILIARY_ANTIGHOST_POLE_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_ACTUAL_ORDINARY_G3_AUXILIARY_CLASS_POLE_CALCULATED','units':uni,'actual_D_BB_Hessian_positions':len(D),'actual_U_HM_Lambda_coefficients':[[ell,h,m,str(z)] for (ell,h,m),z in sorted(U.items())],'actual_Fa_Fc_positions':[len(Fa),len(Fc)],'all4_Lorentz_copies_and_indexed_P2_N1_Fa_Fc_match':True,'all45_principal_vector_width_and_ghost_orientation_inputs_matched':True,'complete_DU_color_before_unit':pack(dc),'complete_FFU_color_before_unit':pack(fc),'physical_DU_pole':pack(du),'physical_FFU_pole':pack(ff),'physical_complete_g3_auxiliary_pole':pack(total),'full_physical_positions':45**3,'nonzero_complete_positions':len(total),'zero_complete_complement':45**3-len(total),'selected3_actual_profiles':cov['selected3_actual_profile_witnesses'],'all_CLa_orders_coverage_after_this_class':cov['selected_class_all_admitted_orders'],'C_H_FFU_profile_zero_after_actual_derivative_and_color_selection':not any(c<12 for ell,a,c in ff),'families_not_individually_assumed_zero':True,'controls':controls,'insensitive_controls_reported':[k for k,v in controls.items() if not v],'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) Lambda_l a_a Z[l,a,c] C_c;physical real orthonormal coordinates;no extra cross-Bose factor','leading_UV_shell_log_not_scaleless_integral_finite_or_IR_amplitude':True,'no_Ward_or_desired_coefficient_or_current_Gamma_read':True,'new_canonical_integration_or_source_insertion_or_full_identity':False,'source_functional_input_benchmark_scheme_policy_authority_changed':False,'all_seven_quantum_flags_false':flags,'full_QAP_IR_measure_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual action/classical export and indexed charts,qualified principal/UV/domain premises,software and AI author shared;finite Gaussian and color reconstructions,not independent expert/experiment/Lean or full restoration','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
