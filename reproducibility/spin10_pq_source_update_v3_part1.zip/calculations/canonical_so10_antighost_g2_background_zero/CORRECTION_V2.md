# Native V2 explicit gauge-fixing read inventory

V1 failed before vertex extraction because E2 transport bindings.json was
absent from the inherited read whitelist. Preserve worker/controller/source
copies, preparation and full primary failure. No V1 result or replay exists.

V2 lists every new sealed/authenticated result read in this worker explicitly,
including E2 role result and bindings, and checks each is present/frozen before
launch. Typed alphabet's qualified read list is retained. New source changes
only the preparation filename. All action, vertex, metric, coupling, parity,
normalization, domain and negative-control checks remain. Two sequential
120sec/8GiB/min350MiB runs plus independent verification; no resource expansion.

This repeats a preventable read-inventory error from earlier work. Task-local
preparation now validates the explicit literal dependencies rather than
assuming that an ancestor's unused read list already contains them. It is
not a reason to weaken strict readers or declare failed workers successful.
