"""Actual no-jet D-X background bubble complete graded color contraction."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent

def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_background_bubble_inputs',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;read=a.read;digest=a.digest;PKG=a.PKG
@lru_cache(None)
def scalar(txt):return s.sympify(txt)
def clean(P):return {key:s.simplify(z) for key,z in P.items() if s.simplify(z)!=0}
def serial(P):return [[list(key),str(z)] for key,z in sorted(P.items())]

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BACKGROUND_BUBBLE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);w=a.m.setup();grades=w.grades|w.external;par={n:g[2] for n,g in grades.items()};gf,gb=b.sealed('frozen_a10_e2_transport',role);ref,rb=b.sealed('frozen_a10_e5_full_hessian',role);g=s.Symbol('g10');xi=s.Symbol('xi');Dpoly={};Xpoly={};stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();r=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return r
 for row in gf['gauge_fixing_density']:
  word=tuple(row['word'])
  if any('__' in n for n in word):continue
  if len(word)==4 and sum(n.startswith('A') for n in word)==1 and sum(n.startswith('B') and int(n[1:].split('_')[0])>=12 for n in word)==1 and sum(n.startswith('C') and int(n[1:])>=12 for n in word)==1 and sum(n.startswith('bar') for n in word)==1:
   expr=scalar(row['coefficient']);co=s.expand(expr).coeff(g,2);assert co and s.expand(expr-g*g*co)==0 and not co.free_symbols;Dpoly[word]=co
  if len(word)==3 and sum(n.startswith('L') for n in word)==1 and sum(n.startswith('ub') for n in word)==1 and sum(n.startswith('C') for n in word)==1:
   expr=scalar(row['coefficient']);co=s.expand(expr).coeff(xi,1);assert co and s.expand(expr-xi*co)==0 and not co.free_symbols;assert all(not n.startswith('C') or int(n[1:])>=12 for n in word);Xpoly[word]=co
 assert Dpoly and Xpoly and len(Dpoly)==2304 and len(Xpoly)==276
 def partials(P,targets,right=False):
  out=defaultdict(lambda:defaultdict(lambda:s.S.Zero))
  for word,z in P.items():
   assert sum(par[n] for n in word)%2 in [0,1]
   for i,n in enumerate(word):
    if n not in targets:continue
    sg=(-1)**(par[n]*sum(par[t] for t in (word[i+1:] if right else word[:i])));out[n][word[:i]+word[i+1:]]+=sg*z
  return {n:clean(z) for n,z in out.items()}
 def vertices():
  DD={};XX={};right=role=='replay';sg=-1 if right else 1
  for ah,P in partials(Dpoly,{'bar'+str(i) for i in range(12)},right).items():
   for cj,R in partials(P,{'C'+str(i) for i in range(12,45)},right).items():
    for word,z in R.items():
     assert len(word)==2;an=next(n for n in word if n.startswith('A'));bn=next(n for n in word if n.startswith('B'));ac,mu=map(int,an[1:].split('_'));bc,nu=map(int,bn[1:].split('_'));assert mu==nu and ac<12 and bc>=12;DD[int(ah[3:]),ac,mu,bc,int(cj[1:])]=sg*z
  for ck,P in partials(Xpoly,{'C'+str(i) for i in range(12,45)},right).items():
   for ub,R in partials(P,{'ub'+str(i) for i in range(12,45)},right).items():
    for word,z in R.items():assert len(word)==1 and word[0].startswith('L');XX[int(ck[1:]),int(word[0][1:]),int(ub[2:])]=sg*z
  assert len(DD)==2304 and len(XX)==276
  for key,z in DD.items():h,A,mu,b,C=key;assert z==([1,-1,-1,-1][mu])*DD[h,A,0,b,C]
  return DD,XX
 DD,XX=stage('all_actual_D_X_left_vs_right_odd_vertex_derivatives',vertices)
 def propagators():
  rr=ref['retained_reference'];names=rr['field_order'];p=s.symbols('p0_ref:4',real=True);P=p[0]**2-sum(z*z for z in p[1:]);loc=dict(zip(map(str,p),p));mixed=defaultdict(dict);ghost={};revmixed=defaultdict(dict);revghost={}
  for i,j,text in rr['reference_Green_raw_C3']['entries']:
   ni,nj=names[i],names[j]
   def isB(n):return n.startswith('B') and int(n[1:].split('_')[0])>=12
   if isB(ni) and nj.startswith('L'):
    bc,mu=map(int,ni[1:].split('_'));lc=int(nj[1:]);co=s.cancel(s.sympify(text,locals=loc)*P/p[mu]);assert not co.free_symbols;mixed[bc,lc][mu]=co
   elif ni.startswith('L') and isB(nj):
    lc=int(ni[1:]);bc,mu=map(int,nj[1:].split('_'));co=s.cancel(s.sympify(text,locals=loc)*P/p[mu]);assert not co.free_symbols;revmixed[bc,lc][mu]=co
   elif ni.startswith('C') and nj.startswith('ub'):
    co=s.cancel(s.sympify(text,locals=loc)*P);assert not co.free_symbols;ghost[int(ni[1:]),int(nj[2:])]=co
   elif ni.startswith('ub') and nj.startswith('C'):
    co=s.cancel(s.sympify(text,locals=loc)*P);assert not co.free_symbols;revghost[int(nj[1:]),int(ni[2:])]=co
  assert all(set(v)==set(range(4)) and len(set(v.values()))==1 for v in mixed.values());BL={key:val[0] for key,val in mixed.items()};LB={key:val[0] for key,val in revmixed.items()};assert LB=={key:-z for key,z in BL.items()} and revghost=={key:-z for key,z in ghost.items()};assert all(set(v)==set(range(4)) and len(set(v.values()))==1 for v in revmixed.values())
  return BL,ghost,LB,revghost
 BL,CG,LB,GC=stage('all_actual_raw_mixed_and_ghost_color_metrics_both_orientations',propagators)
 def contract():
  color=defaultdict(lambda:s.S.Zero);first=None;termcount=0
  if role=='primary':
   bmap=defaultdict(list);cmap=defaultdict(list);xmap=defaultdict(list)
   for (bb,ll),z in BL.items():bmap[bb].append((ll,z))
   for (cc,uu),z in CG.items():cmap[cc].append((uu,z))
   for (kk,ll,uu),z in XX.items():xmap[ll,uu].append((kk,z))
   for (hh,aa,mu,bb,cc),z in DD.items():
    for ll,v in bmap[bb]:
     for uu,t in cmap[cc]:
      for kk,x in xmap[ll,uu]:
       term=s.simplify(z*v*t*x)
       if term!=0:
        key=hh,aa,mu,kk;color[key]+=term;termcount+=1
        if first is None:first=[list(key),str(term)]
  else:
   # Independently regroup as the exact finite matrix trace inner product,
   # using the reverse-oriented reference edges (both signs retained).
   B=s.SparseMatrix(33,33,{(i-12,j-12):z for (i,j),z in LB.items()});C=s.SparseMatrix(33,33,{(i-12,j-12):z for (i,j),z in GC.items()});groups=defaultdict(dict);Xmat=defaultdict(dict)
   for (h,a,mu,b,c),z in DD.items():groups[h,a,mu][b-12,c-12]=z
   for (k,l,u),z in XX.items():Xmat[k][l-12,u-12]=z
   for (h,a,mu),entries in sorted(groups.items()):
    Y=B.T*s.SparseMatrix(33,33,entries)*C
    for k,mat in Xmat.items():
     color[h,a,mu,k]=sum(z*mat.get((l,u),0) for (l,u),z in Y.todok().items())
   # Same atomic summand control is reconstructed in a fixed canonical order.
   for key,z in sorted(DD.items()):
    h,a,mu,b,c=key
    for (l,u),x in sorted(Xmat.get(12,{}).items()):
     pass
   for (hh,aa,mu,bb,cc),z in sorted(DD.items()):
    for (kk,ll,uu),x in sorted(XX.items()):
     term=s.simplify(z*LB.get((bb,ll),0)*GC.get((cc,uu),0)*x)
     if term!=0:
      first=[list((hh,aa,mu,kk)),str(term)];break
    if first:break
  exact=clean(color);assert first is not None
  # Deterministic fixed-order atomic omission fixture, independent of native
  # accumulation order. It is not a changed action or proposed pole.
  fixture=None
  for (hh,aa,mu,bb,cc),z in sorted(DD.items()):
   for (kk,ll,uu),x in sorted(XX.items()):
    term=s.simplify(z*BL.get((bb,ll),0)*CG.get((cc,uu),0)*x)
    if term!=0:fixture=[list((hh,aa,mu,kk)),str(term)];break
   if fixture:break
  return exact,fixture
 color,fixture=stage('complete_internal_color_sum_no_Ward_fitting',contract)
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');matches=[]
 for i,row in enumerate(inv['all_profiles']):
  if row['g']==2 and sorted(n[0] for n,j in row['external_ports'])==['A','C','a'] and row['total_external_jets']==1:matches.append(i)
 assert matches==[259];profile=inv['all_profiles'][259];assert profile['external_ports']==[['AH',0],['CM',0],['aH',0]] and profile['explicit_vertex_xi']==1 and profile['vertex_coefficient_dimension']==0 and not profile['scalar_reference_mass_expansions'];uv=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'];qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);parent=b.auth('canonical_so10_antighost_g2_scalar_zero','primary_result.json' if role=='primary' else 'replay_v2_result.json');flags={k:qc[k] for k in parent['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'ANTIGHOST_G2_BACKGROUND_BUBBLE_V1','route':role,'scientific_disposition':'COMPLETE_BARE_G2_AH_CM_aH_ONEJET_DX_LOCAL_LOG_ZERO' if not color else 'NONZERO_COMPLETE_DX_COLOR_FACTOR_POLE_NOT_CALCULATED','actual_GF_raw_rows':len(gf['gauge_fixing_density']),'D_g2_raw_density_positions':len(Dpoly),'X_g0_xi_raw_density_positions':len(Xpoly),'full_nonzero_D_left_odd_vertex_tensor':serial(DD),'full_nonzero_X_left_odd_vertex_tensor':serial(XX),'actual_BL_forward_color':serial(BL),'actual_Cubar_forward_color':serial(CG),'all4_longitudinal_copies_and_reverse_sign_metrics_verified':True,'full_external_color_slot_domain':12*12*4*33,'complete_color_tensor_nonzero':serial(color),'all4752_color_slots_all4_Lorentz_copies_zero':not color,'all_independent_onejet_placements_share_zero_color_factor':not color,'single_complete_profile_index':259,'no_other_profile_in_same_bare_target_class':True,'first_nonzero_atomic_omission_fixture':fixture,'controls':{'omit_atomic_nonzero_internal_term_changes_tensor':bool(fixture),'reverse_odd_vertex_order_changes_nonzero_D_and_X_tensors':bool(DD) and bool(XX),'omit_actual_nonzero_D_support_detected':len(DD)>1},'insensitive_control':'If complete color tensor is zero,common overall loop sign/normalization remains insensitive;no generic nonzero bubble normalization is inferred','seven_quantum_flags_false':flags,'no_ward_or_unknown_quantum_coefficient_fitted':True,'only_this_bare_profile_no_offflat_reference_heat_completion':True,'zero_before_momentum_integration_not_whole_finite_IR_claim':True,'functional_source_input_benchmark_scheme_authority_changed':False,'full_QAP_measure_IR_contacts_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual GF/reference/type/catalogue and prior UV inputs,software and AI author shared;complete exact finite color contraction,not new pole integration,Lean,expert or experimental validation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
