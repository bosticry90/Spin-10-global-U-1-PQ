# g10^2 explicit-background antighost bubble V1

Previous bounded increment V261: PROGRESS, eight scalar-pair profiles qualified
and committed. Current main19b1c26bc5029dbd515d18b970b49965f18f36e5 clean, no
live calculation. Goal remains completion of the full Spin(10)xPQ investigation.

AG2A asks whether catalogue profile259 (AH,CM,aH,onejet,g2,D X,explicitxi1)
has zero complete color contraction. It is the last unreconciled bare g2
antighost target class in V259 after V260/V261, not the last E5 obligation.
Recover actual D and X vertices from the unchanged gauge-fixing action. Reuse
the actual raw-C3 B/L and ghost/antighost inverse metrics; do not replace them
by a convenient identity or infer a zero from the unbroken Ward theorem.

Freeze actual typed643-field alphabet, all33092 GF rows, source/master/frame
and full retained reference,16-vertex/2353-profile catalogue,V259 finitebound,
V260/V261 proofs and seven false quantum flags. Primary left odd Euler
partials and sparse complete contraction; replay right odd partials with exact
left/right parity bridge and ordered matrix contraction. Independent ordinary
polynomial derivatives and reverse-oriented propagators verify both nonzero
vertex tensors and the complete color result. All4 Lorentz copies, all12
background and12 unbroken-antighost directions, all33 coset ghosts/internal
states remain. Retain all implicit zeros and both independent one-derivative
placements; their common color factor must vanish before calling both zero.

The actual D vertex has no jets and a coefficient g2; X has no jets and common
xi. Extract these polynomial factors exactly. Every selected mixed propagator
must be longitudinal and every selected ghost propagator have the same
massless denominator, with their actual color/dual coefficients. Sum ALL
internal color pairs before classifying. If color tensor is nonzero, preserve
its full exact table and classify as measured color factor only; the one-loop
UV coefficient remains uncalculated until a later normalization/pole test.
Never fit a missing contribution to a Ward remainder.

No scalar, vev, mass, other source or off-flat reference/heat term is discarded:
only this one complete bare profile is tested, with coefficient dimension0.
V255 formal UV correspondence applies only after the correct complete leading
symbol is established. No entire finite/IR amplitude, sourcefreeSlavnov,
QAP,measure/contact/product/equivalence or E5/A5 conclusion follows.

Controls: remove one nonzero internal contraction term, reverse an odd derivative
order and detect its effect on the NONZERO vertex tensor, omit a declared
external/internal support component; record insensitivity of a common overall
loop sign/normalization if the complete tensor is zero. This zero cannot
calibrate a generic nonzero bubble UV pole. No reliance on heavy-only Jacobi.

Sequential own-role primary/replay120sec afterimports/8GiB sampledprivate/
min350MiB plus independent bounded validation. Freeze sources/controllers/
input-read inventories; preserve every failed run and corrections by version.
Validate before localcommit. No agents,branch/worktree,remoteaction,policy,
project_state,source/functional,input,physicalscheme or benchmark change.
Authority34/39; HB1/C5 blocked and flavor paused. Track B: actual coverage gap
closure without another large expression or fitted identity; shared action,
charts, catalogue, software, prior UV theorem and AI author limit independence.
