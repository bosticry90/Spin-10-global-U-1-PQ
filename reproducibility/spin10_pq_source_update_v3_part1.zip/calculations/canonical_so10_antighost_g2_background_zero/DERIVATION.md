# Actual ordered D-X color factor

Select the complete no-jet g2 A_H B_M C_M bar_H density D and no-jet g0
xi L_M ubar_M C_M density X from the actual gauge-fixed action. Do not assume
their physical-adjoint form. The precise external/quantum left derivative
order is D_{bar,C}=partial_C^L partial_bar^L D and
X_{C,ubar}=partial_ubar^L partial_C^L X. Even residual fields remain ordered.
For homogeneous even D/X and two odd derivatives this equals minus the same
right-derivative sequence; verify both complete nonzero tensors.

The bubble has one internal mixed B-L and one C-ubar edge. Strip only their
shared momentum functions: G_BL=Gcolor_BL p_mu/P and G_Cubar=Gcolor_Cubar/P.
Keep the actual raw color/dual coefficients. At each external (bar_h,A_a,C_k),
the common color factor is
 sum_{b,c,l,u} D_{h,a;b,c} Gcolor_BL(b,l) Gcolor_Cubar(c,u) X_{k;l,u}.
The reverse-oriented reference edges may supply common signs but their full
coefficients must be checked explicitly. If this ENTIRE tensor is zero, every
one-jet numerator placement has zero UV coefficient without evaluating a
scaleless integral or fitting a Ward completion. If nonzero, it is a color
factor, not yet a normalized measured pole.

The catalogue supplies exactly one profile in this external type/order and
its full proper-cycle predecessor content. Verify its actual witness and
actual vertex support, derivative placement, polynomial factors and reference
edges in both native routes. No different family or reference-background A
insertion can be silently identified with this bare D-X profile. The quantum
reference itself may respond to A and remains a separate completion problem.

All4 Lorentz copies must share their actual eta weights and longitudinal
propagator coefficients. A color zero before momentum integration avoids
any UV/IR cancellation ambiguity, but does not evaluate the wider regulated
amplitude. A common overall loop sign or factor is insensitive for a zero;
nonzero vertex orientation fixtures and omission controls carry that part of
the verification. Exact finite tensor contractions use no divergent-trace
cyclicity or physical equations of motion.
