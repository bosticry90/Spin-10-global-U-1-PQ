# Last bare g10^2 antighost class: actual D-X color zero

Both native routes find the full color contraction of the ordinary g10^2
AH CM aH one-derivative D-X profile259 exactly zero. The result comes from
actual gauge-fixing vertices and reference inverse metrics, not an assigned
Ward companion. Qualification requires the completed independent receipt
and committed-byte checks; this report alone is not that receipt.

## Complete nonzero input tensors, complete zero output

The unchanged33092-row gauge-fixing density supplies2304 no-jet g10^2 D
coefficients and276 no-jet xi X coefficients. The complete two-odd-derivative
vertex tensors are nonzero. Native primary uses left derivatives; replay uses
right derivatives with the exact parity bridge. Every D Lorentz copy retains
its actual eta weight. All33 mixed B/L and33 ghost/antighost forward color
metric entries, their four longitudinal copies and both reverse orientations
are checked against the full raw-C3 Green function. No convenient replacement
of the reference metric is made.

Sparse ordered internal-state summation and regrouped finite matrix contraction
agree across the full12 aH x12 AH x4 Lorentz x33 CM=19008-position external
color domain. Every coefficient is zero. The intermediate summands are not:
removing one term gives a nonzero defect, with the frozen fixture at
(h=4,A=11,mu=0,C=12) equal to -2sqrt(2). An opposite odd derivative order changes
the nonzero vertex tensor; comparing those tensors prevents the final zero
from hiding an ordering error.

The selected mixed and ghost propagators share their exact momentum factors
p_mu/P and1/P, independently of internal color. Thus both independent one-jet
placements have the same zero color factor. No bubble integral, whole
scaleless integral or UV/IR cancellation is used. This does not calibrate the
common sign or normalization of a generic NONZERO bubble amplitude; that
control is insensitive for an exact zero. The profile's Taylor/raw UV degree
is one and the catalogue contains no other ordinary profile in its exact
external/order class.

## Planned independent coverage implication

Before independent execution, include the cheap set-completeness audit implied
by the frozen V259 inventory. Its g10^2 antighost subset has87 profiles.
64 already match inherited complete measured scopes; V260's fourteen vector
and V261's eight scalar profiles have qualified structural zero evidence.
Together with259 these are candidate disjoint complete coverage87=64+14+8+1.
The independent verifier must prove the exact index-set equality in both
catalogues and authenticate every reused result/receipt before qualifying
that implication. Family pieces that cancel only collectively must retain
that classification, not be promoted to individually measured zeros.

A successful87-profile audit establishes completeness relative to the ordinary
bare catalogue. It does NOT establish full background-reference/heat coverage,
complete off-flat coefficients, a simultaneous antighost identity, source-free
Slavnov restoration or a complete quantum construction. Those distinctions
remain central to using the new evidence correctly.

## Verification and limitations

Native primary/replay13.191/14.145sec afterimports, sampledprivate
392810496/378580992bytes, within120sec/8GiB/min350MiB. V1 failed before algebra
because the E2 action binding was absent from an inherited read list. V2
freezes and prechecks explicit new literal result/binding reads; all original
failure/source/controller/manifest bytes remain. The repeated preventable
read-inventory error is a Track B limitation, not a scientific obstruction.
The independent receipt supplies its final actual performance/failure counts.
No fresh byte-identical replay pair is claimed.

The independent method must recover both exact vertex tensors from ordinary
left Euler derivatives, verify the opposite order, reproduce every propagator
entry and reverse sign, evaluate every external color slot, authenticate
profile259 with both actual cycle witnesses and check complete bare-g2 scope.
Controls remove a nonzero internal term/support and reverse odd ordering on
nonzero tensors. Common global loop normalization remains uncalibrated here.

No source/known-functional/input/benchmark/scheme/policy/authority change.
Known functional155110/sourcefree40309/sourceimage146663 and seven false
quantum flags remain. Authority34/39, historical custodyexit2/seven references,
quartet failure, singlet quantum-control warning and gauge-matching limitations
are unaffected. Full E5/A5,QAP,measure,contacts,products,equivalence and IR
remain unqualified; HB1/C5 blocked and flavor paused.

The next useful dependency is the complete flat g10^2 broken-antighost
source/insertion relation. Reuse the now-complete ordinary bare inputs and
qualified source poles, enumerate V0*source2 and V1*source1 explicitly, and
apply a justified loop-leg derivative reduction. First distinguish flat
coefficients from off-flat response of the reference/heat operators. The
bare87-profile audit alone cannot supply those missing background terms.
A full huge functional expansion remains unnecessary until its dependencies
are established.

Track B: actual color contraction closed a final bare-g2 class and permits a
finite completeness audit rather than another selected Ward check. Gauge-
fixing/reference/catalogue and prior measured scopes, software and AI author
remain shared. This is exact computational corroboration with bounded
independence, not a new loop normalization, Lean certificate, external expert
confirmation or experimental GUT validation.
