"""CWB1 actual matrix cut, graded Wick routes and local tadpole projections."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import combinations,product
from fractions import Fraction
import json,gzip,sys,os,time,threading
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
import exact_algebra as ex
PAR=[0,1,1];WC={(0,0):1,(1,2):2,(2,1):-3}
def canonical(word):
 if any(word.count(i)>1 for i in [1,2]):return 0,()
 sign=(-1)**sum(PAR[a]*PAR[b] for i,a in enumerate(word) for b in word[i+1:] if a>b)
 return sign,tuple(sorted(word))
def add(dst,src,scale=1,shift=0):
 for (h,w),v in src.items():
  key=h+shift,w;dst[key]=dst.get(key,0)+scale*v
  if not dst[key]:del dst[key]
 return dst
def derivative(poly,j):
 out={}
 for (h,w),v in poly.items():
  for k,i in enumerate(w):
   if i==j:add(out,{(h,w[:k]+w[k+1:]):v*(-1)**(PAR[j]*sum(PAR[t] for t in w[:k]))})
 return out
@lru_cache(None)
def wick_word(f,g):
 seq=f+g;out={};nl=len(f)
 def go(active,left,h,coef):
  if not left:
   sign,word=canonical(tuple(seq[i] for i in active))
   if sign:add(out,{(h,word):coef*sign})
   return
  i=left[0];go(active,left[1:],h,coef)
  for j in active:
   if j<nl or (v:=WC.get((seq[i],seq[j]),0))==0:continue
   between=sum(PAR[seq[k]] for k in active if i<k<j)
   go(tuple(k for k in active if k not in [i,j]),left[1:],h+1,coef*v*(-1)**(PAR[seq[j]]*between))
 go(tuple(range(len(seq))),tuple(range(nl)),0,1);return out
def generator(i,poly):
 out={}
 for (h,w),v in poly.items():
  sign,word=canonical((i,)+w)
  if sign:add(out,{(h,word):v*sign})
 for j in range(3):
  if (v:=WC.get((i,j),0)):add(out,derivative(poly,j),v,1)
 return out
@lru_cache(None)
def differential_word(f,g):
 if not f:return {(0,g):1}
 i,rest=f[0],f[1:];out=generator(i,differential_word(rest,g))
 for j in range(3):
  if not (v:=WC.get((i,j),0)):continue
  for (hh,w),factor in derivative({(0,rest):1},j).items():add(out,differential_word(w,g),-v*factor,1)
 return out
def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'preparation.json').read_bytes())
 for raw,h in prep['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
 PK=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
 ref=json.loads((PK/'frozen_a10_e5_full_hessian'/(role+'.json')).read_bytes())['retained_reference']
 pv=s.Matrix(s.symbols('p0_ref:4',real=True));eta=s.diag(1,-1,-1,-1);P=(pv.T*eta*pv)[0];u=eta*pv;Z=s.Symbol('Z')
 D,E=s.symbols('cut_delta cut_delta_prime');masssyms={sec:s.Symbol('Mref_'+sec+'_squared') for sec in ['Phi','Sigma','phi','S']}
 cuts={sec:s.Symbol('cut_'+sec) for sec in masssyms};loc={str(x):x for x in pv}
 @lru_cache(None)
 def num(txt):return s.cancel(s.sympify(txt,locals=loc))
 def unpack(name):return {(i,j):num(v) for i,j,v in ref[name]['entries']}
 K,G,T,Ti=[unpack(n) for n in ['reference_Hessian_raw_C3','reference_Green_raw_C3','physical_to_raw_kernel','physical_to_raw_inverse']]
 assert len(ref['field_order'])==643 and len(G)==1550
 def trans(A):return {(j,i):v for (i,j),v in A.items()}
 def mult(A,B):
  index=defaultdict(list);out=defaultdict(lambda:s.S.Zero)
  for (i,j),v in B.items():index[i].append((j,v))
  for (i,k),v in A.items():
   for j,w in index[k]:out[i,j]+=v*w
  return {key:s.expand(v) for key,v in out.items() if v!=0}
 @lru_cache(None)
 def polynomial(q):
  return s.rem(s.Poly(s.expand(q),pv[0],domain='EX'),s.Poly(pv[0]**2-Z-sum(p*p for p in pv[1:]),pv[0],domain='EX')).as_expr()
 @lru_cache(None)
 def reduce(q):
  q=s.expand(q);out=s.S.Zero
  co=polynomial(q.coeff(E));out+=co.subs(Z,0)*E-s.diff(co,Z).subs(Z,0)*D
  out+=polynomial(q.coeff(D)).subs(Z,0)*D
  for sec,dd in cuts.items():out+=polynomial(q.coeff(dd)).subs(Z,masssyms[sec])*dd
  assert s.expand(q-q.coeff(D)*D-q.coeff(E)*E-sum(q.coeff(v)*v for v in cuts.values()))==0
  return s.expand(out)
 def cut(q):
  masses=[v for v in q.free_symbols if str(v).startswith('Mref_')]
  if masses:
   assert len(masses)==1;mm=masses[0];sec=next(k for k,v in masssyms.items() if v==mm)
   return s.cancel(q*(P-mm))*cuts[sec]
  n,den=s.fraction(q);power=s.Poly(den,*pv).total_degree()//2;assert power in [1,2]
  coefficient=s.cancel(n/(den/P**power));assert not s.denom(coefficient).has(*pv)
  return coefficient*(D if power==1 else -E)
 rawcut={key:reduce(cut(v)) for key,v in G.items()};assert len(rawcut)==1550 and all(rawcut.values())
 w=s.Symbol('w');block=(-P*eta+u*u.T).row_join(s.I*u).col_join((-s.I*u.T).row_join(s.Matrix([[w]])))
 wb=(-eta*D+(w-1)*pv*pv.T*E).row_join(s.I*pv*D).col_join((-s.I*pv.T*D).row_join(s.zeros(1)))
 assert (block*wb).applyfunc(reduce)==s.zeros(5) and (wb*block).applyfunc(reduce)==s.zeros(5)
 odd=s.Matrix([[0,-P],[P,0]]);wo=s.Matrix([[0,D],[-D,0]])
 assert (odd*wo).applyfunc(reduce)==s.zeros(2) and (wo*odd).applyfunc(reduce)==s.zeros(2)
 wrong=wb.copy();wrong[:4,:4]=-eta*D+(1-w)*pv*pv.T*E
 assert (block*wrong).applyfunc(reduce)!=s.zeros(5)
 physical={}
 for color in range(45):
  addr=[4*color+mu for mu in range(4)]+[508+color];width=num('eta_H' if color<12 else 'xi')
  for i in range(5):
   for j in range(5):
    if (v:=wb[i,j].subs(w,width))!=0:physical[addr[i],addr[j]]=v
  physical[553+color,598+color]=D;physical[598+color,553+color]=-D
 for start,n,sec in [(180,54,'Phi'),(234,252,'Sigma'),(486,20,'phi'),(506,2,'S')]:
  for i in range(start,start+n):physical[i,i]=cuts[sec]
 compare=mult(mult(Ti,physical),trans(Ti)) if role=='primary' else mult(mult(T,rawcut),trans(T))
 target=rawcut if role=='primary' else physical
 for key in compare.keys()|target.keys():assert reduce(compare.get(key,0)-target.get(key,0))==0,key
 if role=='primary':
  for expr in list(mult(K,rawcut).values())+list(mult(rawcut,K).values()):assert reduce(expr)==0
 # Scalar frame must actually agree before diagonal contractions are used.
 for A in [T,Ti]:
  assert {(i,j):v for (i,j),v in A.items() if 180<=i<508 or 180<=j<508}=={(i,i):s.S.One for i in range(180,508)}
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));names=data['geometry']['names'];pars=data['geometry']['parities']
 par={names[n]:pars[n] for n,J,h,k in data['geometry']['field_source_h_k']}
 assert set(ref['field_order'])==set(par)
 for (i,j),v in T.items():assert (i>=553)==bool(par[ref['field_order'][j]])
 # Associative Wick products: pair matchings versus differential left action.
 wordstar=wick_word if role=='primary' else differential_word
 def prod(A,B):
  out={}
  for (h,f),v in A.items():
   for (k,g),w0 in B.items():add(out,wordstar(f,g),v*w0,h+k)
  return out
 basis=[(),(0,),(1,),(2,),(1,2),(0,1),(0,2),(0,0)];assoc=0
 for f,g,h0 in product(basis,repeat=3):
  aa,bb,cc=[{(0,v):1} for v in [f,g,h0]]
  assert prod(prod(aa,bb),cc)==prod(aa,prod(bb,cc)),(role,f,g,h0);assoc+=1
 assert prod({(0,(1,)):1},{(0,(2,)):1})=={(0,(1,2)):1,(1,()):2}
 assert prod({(0,(2,)):1},{(0,(1,)):1})=={(0,(1,2)):-1,(1,()):-3}
 # Actual local tadpole projections, independent reference-sector functions.
 traces={};rows=Counter();potential=Counter();jetpairs=Counter()
 def addtrace(target,sec,powM,word,coef):
  key=(target,sec,powM,tuple(word));out=traces.setdefault(key,{})
  for cell,v in coef.items():
   out[cell]=out.get(cell,Fraction(0))+v
   if not out[cell]:del out[cell]
  if not out:del traces[key]
 def scalarjet(text):
  base,_,jet=text.partition('__')
  return (base,jet,base.split('_')[1]) if base.startswith('x_') else None
 def covariance(a,b):
  if a[0]!=b[0]:return None
  ja,jb=a[1],b[1];order=len(ja)+len(jb)
  if order==0:return 0,Fraction(1)
  if order==1:return None
  assert order<=2
  mu=int((ja+jb)[0]);nu=int((ja+jb)[1])
  if mu!=nu:return None
  sign=(1 if mu==0 else -1)*(1 if len(ja)==len(jb)==1 else -1)
  return 1,Fraction(sign,4)
 def project(target,polys):
  for row in polys:
   rows[target]+=1;word=row['word'];sj=[scalarjet(t) for t in word]
   if role=='primary':
    coef=ex.parse_coefficient(row['coefficient'])
    for i,j in combinations(range(len(word)),2):
     if not sj[i] or not sj[j] or (cov:=covariance(sj[i],sj[j])) is None:continue
     powM,factor=cov;jetpairs[str(len(sj[i][1])+len(sj[j][1]))]+=1;potential[target]+=1
     addtrace(target,sj[i][2],powM,[t for k,t in enumerate(word) if k not in [i,j]],{c:v*factor for c,v in coef.items()})
   else:
    scalar_names=sorted({word[i] for i,v in enumerate(sj) if v});vars={n:s.Symbol('v'+str(k)) for k,n in enumerate(scalar_names)}
    if not vars:continue
    mon=s.prod(vars[t] for t,v in zip(word,sj) if v);original=Counter(t for t,v in zip(word,sj) if v)
    for aidx,an in enumerate(scalar_names):
     for bn in scalar_names[aidx:]:
      aj,bj=scalarjet(an),scalarjet(bn);cov=covariance(aj,bj)
      if cov is None:continue
      term=s.diff(mon,vars[an],vars[bn])*(s.Rational(1,2) if an==bn else 1)
      if not term:continue
      power,fac=cov;po=s.Poly(term,*vars.values());assert len(po.terms())==1
      exps,factor=po.terms()[0];remaining=dict(zip(scalar_names,exps));out=[]
      for text,v in zip(word,sj):
       if v:
        if remaining[text]:out.append(text);remaining[text]-=1
       else:out.append(text)
      coupling=s.sympify(row['coefficient'])*factor*s.Rational(fac.numerator,fac.denominator)
      addtrace(target,aj[2],power,out,ex.parse_coefficient(str(s.expand(coupling))))
 project('GF',data['gauge_fixing_density'])
 for field,polys in data['master_field_maps'].items():project(field,polys)
 assert rows['GF']==33092 and sum(v for k,v in rows.items() if k!='GF')==35162 and len(rows)==644
 serial=[]
 for (target,sec,power,word),coef in sorted(traces.items()):
  serial.append([target,sec,power,list(word),[[*cell,v.numerator,v.denominator] for cell,v in sorted(coef.items())]])
 tracehash=sha256(json.dumps(serial,separators=(',',':')).encode()).hexdigest();sourcekeys={r[0] for r in serial if r[0]!='GF'}
 numerical=[]
 a,b=s.symbols('a b',positive=True);cc=a+b
 expected=[1/(8*s.pi**2*cc),(a-b)/(16*s.pi**2*cc**2),(3*a+b)/(48*s.pi**2*cc**2),(3*a-b)/(48*s.pi**2*cc**3),(5*a+b)/(240*s.pi**2*cc**3)]
 assert s.simplify(expected[1]-3*expected[2]+expected[0])==0
 for digits in [45,75]:
  with mp.workdps(digits):
   values=[]
   for av,bv in [(1,1),(2,3),(3,2)]:
    aa,bb=mp.mpf(av),mp.mpf(bv);c=aa+bb
    if role=='primary':
     integ=lambda n:mp.quad(lambda r:r**n*mp.exp(-c*r*r),[0,1,mp.inf])
     actual=[integ(1)/(4*mp.pi**2),(aa*integ(3)-integ(1)/2)/(4*mp.pi**2),(aa*integ(3)+integ(1)/2)/(12*mp.pi**2),(aa*integ(5)-integ(3)/2)/(12*mp.pi**2),(aa*integ(5)+integ(3)/2)/(60*mp.pi**2)]
    else:actual=[mp.mpf(str(s.N(q.subs({a:av,b:bv}),digits))) for q in expected]
    want=[mp.mpf(str(s.N(q.subs({a:av,b:bv}),digits))) for q in expected]
    for q,w0 in zip(actual,want):assert abs(q-w0)<mp.mpf('1e-25'),(role,av,bv,q,w0)
    assert actual[3]!=0 and actual[4]!=0
    values.append([av,bv,[mp.nstr(q,35) for q in actual]])
   numerical.append({'digits':digits,'future_shell_and_weighted_tensor':values})
 for raw,h in prep['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
 result={'schema':'CAUSAL_WICK_BRIDGE_V1','route':role,'field_count':643,'raw_future_covariance_positions':len(rawcut),'implicit_zero_positions':643**2-len(rawcut),'two_sided_homogeneous_matrix_equations':True,'actual_graded_dual_frames_and_scalar_diagonal_identity':True,'off_shell_contact_K_CF_iI_reused':True,'associativity_controls':assoc,'trace_GF_rows':rows['GF'],'trace_master_rows':sum(v for k,v in rows.items() if k!='GF'),'source_directions_checked':643,'tadpole_projection':serial,'tadpole_projection_sha256':tracehash,'GF_sector_words':sum(r[0]=='GF' for r in serial),'source_sector_words':sum(r[0]!='GF' for r in serial),'source_directions_nonzero':len(sourcekeys),'numerical':numerical,'linear_T1_operator_normalization_derived':True,'complete_causal_Tn_QAP_E5_A5_proved':False,'positive_physical_state_or_ghost_adjoint_adopted':False,'physical_reference_or_scheme_changed':False,'controls':{'wrong_delta_prime_sign_rejected':True,'ordered_odd_Gaussian_sign_required':True,'time_order_jet_contact_not_zero':True,'discarding_tadpole_rejected':True,'actual_source_tadpole_omission_sensitive':bool(sourcekeys),'generic_J_x_squared_source_control_sensitive':True,'symmetric_E00_test_insensitive':True,'associativity_does_not_select_ghost_sign':True,'future_frequency_not_positive_state':True},'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
