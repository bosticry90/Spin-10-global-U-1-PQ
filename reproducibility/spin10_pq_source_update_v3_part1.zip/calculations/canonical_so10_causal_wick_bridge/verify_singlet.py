from pathlib import Path
from hashlib import sha256
import json,time,threading,os,gzip
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_causal_wick_bridge';C=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'singlet_preparation.json').read_bytes())
 for raw,h in prep['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
 assert json.loads((O/'validation_receipt.json').read_bytes())['execution_state']=='COMPLETED'
 S,SB,hS,hB,kS,kB,la,m=s.symbols('S SBar hS h_SBar kS k_SBar lambdaS mS2');hh,kk=s.symbols('hh kk')
 loc={'S':S,'SBar':SB,'h_S':hS,'h_SBar':hB,'k_S':kS,'k_SBar':kB}
 expected=-la*s.expand((S+hh*hS+kk*kS)**2*(SB+hh*hB+kk*kB)**2).coeff(hh,1).coeff(kk,1)
 PK=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';hashes=[]
 for role in ['primary','replay']:
  packet=json.loads((PK/'frozen_a10_e5_full_hessian'/(role+'.json')).read_bytes());terms=packet['physical_Hessian_program']['all_34_literal_terms']
  term=next(v for v in terms if v['term_id']=='potential_lambdaS');rows=term['index_jet_graph_coefficients'];assert len(rows)==4
  actual=s.S.Zero
  for params,nodes,coef in rows:
   assert params==['lambdaS'] and all(n[0]=='Field' and n[2:]==[[],[]] for n in nodes)
   actual+=s.sympify(coef)*la*s.prod(loc[n[1]] for n in nodes)
  assert s.expand(actual-expected)==0
  hashes.append(sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest())
  ref=packet['retained_reference'];G={(i,j):v for i,j,v in ref['reference_Green_raw_C3']['entries']}
  assert (506,506) in G and (507,507) in G and not any(506<=i<=507 and j!=i for i,j in G)
 x,y,d=s.symbols('x y d_S',real=True);quartic=-la*(x*x+y*y)**2/4
 direct=s.expand(d*(s.diff(quartic,x,2)+s.diff(quartic,y,2))/2)
 complex_slots=-4*la*d*(x*x+y*y)/2
 assert s.expand(direct-complex_slots)==0 and direct!=0
 mass=-m*(x*x+y*y)/2
 assert s.expand(s.diff(mass,m)*4*la*d-direct)==0
 # The field/source normalization remains correlated; the actual singlet Q is zero.
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
 assert data['master_field_maps']['x_S_0']==[] and data['master_field_maps']['x_S_1']==[]
 result={'schema':'CAUSAL_WICK_SINGLET_INITIAL_NORMALIZATION_V1','execution_state':'COMPLETED','scientific_disposition':'ACTUAL_SINGLET_QUARTIC_NONZERO_LOCAL_T1_NORMALIZATION_MATCHED_IN_REAL_AND_COMPLEX_COORDINATES_NOT_PHYSICAL_MASS_PREDICTION','scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],'main_receipt_sha256':sha256((O/'validation_receipt.json').read_bytes()).hexdigest(),'actual_lambdaS_Hessian_graph_sha256':hashes,'beta1_singlet_quartic':str(direct),'formal_operator_mass_coefficient':'4*lambdaS*d_S','physical_mass_or_benchmark_changed':False,'full_causal_Tn_QAP_E5_A5_proved':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
