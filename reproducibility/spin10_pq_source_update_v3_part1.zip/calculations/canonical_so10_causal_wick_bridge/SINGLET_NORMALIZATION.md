# An actual nonzero T1 normalization: the singlet quartic

The complete GF and source-rule self-contraction projections cancel. They
therefore cannot alone provide a nonzero model-specific initial-normalization
control. This supplement uses the ACTUAL potential_lambdaS Hessian from both
frozen full-Hessian packets; it does not introduce a diagnostic interaction.

Its four ordered Hessian terms are those of the physical action density
-lambdaS*S^2*SBar^2. The canonical singlet has two real coordinates x,y with
unit kinetic Hessian, as fixed by the retained reference and physical real
structure. The complex kinetic normalization gives |S|^2=(x^2+y^2)/2,
independent of an overall singlet phase. Thus the same action term is

    F_S=-lambdaS*(x^2+y^2)^2/4.

Using the previously fixed n1 heat covariance d_S and both real directions,

    beta1(F_S)=d_S*(partial_x^2+partial_y^2)F_S/2
              =-2lambdaS*d_S*(x^2+y^2)
              =-4lambdaS*d_S*SBar*S.

The independent complex-slot contraction counts four S/SBar pairs and gives
the same result. It is nonzero as a symbolic normalization direction; a
particular scale/kappa choice could make d_S zero and would be an insensitive
control. No such choice is made. Its local structure is already present in
the original singlet mass term -mS2*SBar*S, with the corresponding formal
order-hbar operator-normalization coefficient 4lambdaS*d_S. This is not a
new physical parameter, a benchmark mass change or a pole-mass prediction.

The singlet's two actual classical Q maps vanish. This does not remove the
quartic tadpole or justify discarding physical scalar terms just because the
GF/source traces are zero. It also does not repair the recorded large singlet
physical loop correction. The supplement verifies a quantum-operator dictionary
at first order, not physical perturbative control or full causal QAP.
