# Next: assemble one normalized causal product, using the completed free/T1 input

CWB1 supplies the actual graded free Wick algebra, origin-valid future cuts,
time-order derivative contacts and a local heat-compatible T1 normalization.
MLB1/HMM1 supply the complete declared one-loop coefficient map and local
matching. Do not repeat a selected free boundary or another radial fixture.

The next scientific question is whether these ingredients define ONE causal
Tn/vertex map on the required local operator domain with its simultaneous
initial conditions, graded permutations, translation covariance, field
independence and action/jet identities. Check the actual original W1-W7/A2-A4
requirements and intended QAP theorem rather than invoking a scalar theorem
or strengthening the gate with optional higher-order equivalence.

A structural assembly should polarize the action Hessian in independent local
vertices, use the common one-loop cycle map and tree sewing, and include
beta1 in the local input dictionary. Check that local diagonal extensions
agree at proper subdiagonals with lower-order causal factorizations. A local
counterterm on one cycle must be sewn with all its external/tree/source
partners, not inserted only in a favorable projected amplitude.

For action-Ward normalization use the off-shell local-functional quotient by
integration by parts, or a proved graded multiplet balanced-field decomposition.
Do not quotient by the free field equation: K*C_F=i delta is essential.
Field/source differentiation and physical Euler terms must commute with the
same extension convention. Preserve the actual odd orientation, source-left
order and the distinct connected/1PI/Born phases.

Distinguish a general compactly switched local-polynomial operator domain from
the earlier actual constant-insertion family and from global unit/adiabatic
limits. A new class of unlabelled constant vector mass chains would require a
new infrared argument; it cannot be silently imported from the fixed action.
Compact local insertions retain their switching label and are a different
case. Establish that the chosen domain is sufficient for the original local
one-loop insertion question before claiming a general QAP bridge.

Keep Gamma_ref[A] and its phase/historical-member ambiguity explicit. Neither
the GF/source zero tadpole traces nor the nonzero singlet operator normalization
fixes that determinant or physical masses. Preserve all kappa/b0/IR constants.
A valid outcome is a complete bounded normalized construction or an exact
remaining axiom/contact/product premise. Underdefinition is not an anomaly.
No automatic E5/A5 promotion, blocked HB1/C5 activation, flavor resumption or
new physical benchmark. Retain separate quantum-control/gauge-matching tasks.
