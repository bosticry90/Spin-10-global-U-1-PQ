from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction as Q
from collections import Counter
from itertools import combinations_with_replacement
import json,gzip,time,os,threading
import sympy as s
import mpmath as mp
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_causal_wick_bridge';C=Path(__file__).resolve().parent
def main():
 start=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'validation_preparation.json').read_bytes())
 for raw,h in prep['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
 assert sha256(Path(__file__).read_bytes()).hexdigest()==prep['verifier_sha256']
 # A graded Berezin Gaussian with integral(a*C)=1 fixes <C*a>=i/P.
 P,h=s.symbols('P h',nonzero=True);Z=s.I*P/h;assert s.simplify(-1/Z-s.I*h/P)==0
 # Off-shell time-order contacts from the exact one-spatial-mode formula.
 t,E=s.symbols('t E',real=True,positive=True)
 forward=s.exp(-s.I*E*t)/(2*E);backward=s.exp(s.I*E*t)/(2*E)
 jump=s.diff(forward,t).subs(t,0)-s.diff(backward,t).subs(t,0);assert jump==-s.I
 comm=forward-backward;dip=s.diff(comm,E)/(2*E)
 assert dip.subs(t,0)==0 and s.simplify(s.diff(dip,t).subs(t,0))==0
 # Jet table preserves the total derivative and free quadratic normalization.
 M,d=s.symbols('M d');assert s.simplify(M*d/4-M*d/4)==0
 assert s.simplify(4*M*d/8-M*d/2)==0
 # Exact finite stencils, used below instead of pair counting or differentiation.
 eps=Q(1,7)
 def first(r):return (-(1+2*eps)**r+8*(1+eps)**r-8*(1-eps)**r+(1-2*eps)**r)/(12*eps)
 def halfsecond(r):return (-(1+2*eps)**r+16*(1+eps)**r-30+16*(1-eps)**r-(1-2*eps)**r)/(24*eps*eps)
 for r in range(5):assert first(r)==r and halfsecond(r)==Q(r*(r-1),2)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));maps=data['master_field_maps'];assert len(maps)==643 and len(data['gauge_fixing_density'])==33092 and sum(map(len,maps.values()))==35162
 empty=sorted(k for k,v in maps.items() if not v);assert len(empty)==15
 @lru_cache(None)
 def coupling(txt):return s.sympify(txt)
 fresh={}
 def jet(txt):
  base,_,jj=txt.partition('__');return (base,jj,base.split('_')[1]) if base.startswith('x_') else None
 def covariance(aa,bb):
  if aa[0]!=bb[0]:return None
  js=aa[1]+bb[1]
  if not js:return 0,Q(1)
  if len(js)!=2 or js[0]!=js[1]:return None
  return 1,Q((1 if js[0]=='0' else -1)*(1 if len(aa[1])==len(bb[1])==1 else -1),4)
 for target,rows in [('GF',data['gauge_fixing_density']),*maps.items()]:
  for row in rows:
   word=row['word'];counts=Counter(t for t in word if jet(t))
   for an,bn in combinations_with_replacement(sorted(counts),2):
    if an==bn and counts[an]<2:continue
    aa,bb=jet(an),jet(bn);cov=covariance(aa,bb)
    if cov is None:continue
    power,factor=cov;coef=halfsecond(counts[an]) if an==bn else first(counts[an])*first(counts[bn])
    if not coef:continue
    todo=Counter([an,bn]);remaining=[]
    for name in word:
     if todo[name]:todo[name]-=1
     else:remaining.append(name)
    key=target,aa[2],power,tuple(remaining);number=coef*factor
    fresh[key]=fresh.get(key,s.S.Zero)+coupling(row['coefficient'])*s.Rational(number.numerator,number.denominator)
 fresh={key:v for key,val in fresh.items() if (v:=s.expand(val))!=0}
 # Actual scalar covariance frame, checked in both independent reference packets.
 PK=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
 for role in ['primary','replay']:
  ref=json.loads((PK/'frozen_a10_e5_full_hessian'/(role+'.json')).read_bytes())['retained_reference']
  for label in ['physical_to_raw_kernel','physical_to_raw_inverse']:
   subset={(i,j):v for i,j,v in ref[label]['entries'] if 180<=i<508 or 180<=j<508}
   assert subset=={(i,i):'1' for i in range(180,508)}
 # Symbolically normalize native exact cells and compare EVERY surviving/zero word.
 squares=[s.sqrt(2),s.sqrt(3),s.sqrt(5),s.sqrt(7),s.I];g,xiw,et=s.symbols('g10 xi eta_H')
 def cellvalue(row):
  out=s.S.Zero
  for gp,xp,ep,mask,n,den in row:out+=s.Rational(n,den)*g**gp*xiw**xp*et**ep*s.prod(squares[i] for i in range(5) if mask&(1<<i))
  return s.expand(out)
 native=[]
 for role in ['primary','replay']:
  val=json.loads((O/(role+'_v2_result.json')).read_bytes());native.append(val)
  assert val['field_count']==643 and val['raw_future_covariance_positions']==1550 and val['implicit_zero_positions']==411899
  assert val['two_sided_homogeneous_matrix_equations'] and val['actual_graded_dual_frames_and_scalar_diagonal_identity'] and val['associativity_controls']==512
  assert val['trace_GF_rows']==33092 and val['trace_master_rows']==35162 and val['source_directions_checked']==643 and val['zero_classical_map_directions']==empty
  result={(target,sec,powM,tuple(word)):cellvalue(coef) for target,sec,powM,word,coef in val['tadpole_projection']}
  for key in result.keys()|fresh.keys():assert s.expand(result.get(key,0)-fresh.get(key,0))==0,key
  assert val['tadpole_projection_sha256']==sha256(json.dumps(val['tadpole_projection'],separators=(',',':')).encode()).hexdigest()
  actualsource=any(key[0]!='GF' for key in fresh)
  assert val['controls']['actual_source_tadpole_omission_sensitive']==actualsource
  assert all(v for k,v in val['controls'].items() if k!='actual_source_tadpole_omission_sensitive')
  for flag in ['complete_causal_Tn_QAP_E5_A5_proved','positive_physical_state_or_ghost_adjoint_adopted','physical_reference_or_scheme_changed']:assert val[flag] is False
 assert native[0]['tadpole_projection']==native[1]['tadpole_projection']
 # Independent spectral Gaussian derivation from the Feynman imaginary part.
 aa,bb=s.symbols('aa bb',positive=True);F=-(s.sqrt(aa/bb)+s.I)/(8*s.pi**2*(aa+bb))
 forms=[-s.im(F),s.im((F+2*aa*s.diff(F,aa))/2),s.im(-(F+s.Rational(2,3)*bb*s.diff(F,bb))/2),s.im(s.diff(F,aa)/2+bb*s.diff(F,aa,bb)/3),s.im(s.diff(F,bb)/6+bb*s.diff(F,bb,2)/15)]
 with mp.workdps(90):
  for val in native:
   for block in val['numerical']:
    for av,bv,values in block['future_shell_and_weighted_tensor']:
     for q,form in zip(values,forms):assert abs(mp.mpf(q)-mp.mpf(str(s.N(form.subs({aa:av,bb:bv}),90))))<mp.mpf('1e-25')
 # Independent finite exterior representation of the odd contraction algebra.
 states=[(),(1,),(2,),(1,2)]
 def canon(w):
  if len(set(w))!=len(w):return 0,()
  return (-1)**sum(a>b for i,a in enumerate(w) for b in w[i+1:]),tuple(sorted(w))
 def left(i,w):
  out={};sg,new=canon((i,)+w)
  if sg:out[new]=sg
  target=2 if i==1 else 1;weight=2 if i==1 else -3
  if target in w:
   pos=w.index(target);word=w[:pos]+w[pos+1:];out[word]=out.get(word,0)+weight*(-1)**pos
  return out
 matrices=[]
 for i in [1,2]:
  A=s.zeros(4)
  for k,w in enumerate(states):
   for word,c in left(i,w).items():A[states.index(word),k]+=c
  matrices.append(A)
 assert matrices[0]**2==s.zeros(4) and matrices[1]**2==s.zeros(4) and matrices[0]*matrices[1]+matrices[1]*matrices[0]==-s.eye(4)
 # Initial-normalization/source-before-restriction identities are not guesses.
 J,x,hh,beta,F1=s.symbols('J x hh beta F1');assert s.diff(J*x*x,J)!=s.diff((J*x*x).subs(J,0),J)
 assert s.expand((x+hh*beta)+hh*(F1-beta)-(x+hh*F1))==0
 receipts=[]
 for raw in prep['input_sha256']:
  path=Path(raw)
  if 'receipt' in path.name and path.suffix=='.json':assert json.loads(path.read_bytes())['execution_state']=='COMPLETED';receipts.append(raw)
 perf={}
 for role,val in zip(['primary','replay'],native):
  cap=json.loads((O/(role+'_v2_capture.json')).read_bytes());assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
  maxp=max(q['private_bytes'] for q in cap['all_resource_samples']);assert maxp<8*1024**3 and cap['launch']['memory']['available_pagefile']>=350*1024**2
  assert val['elapsed_after_imports']<120;perf[role]={'seconds':val['elapsed_after_imports'],'max_sampled_private_bytes':maxp}
 failed=json.loads((O/'primary_capture.json').read_bytes());assert failed['execution_state']=='FAILED' and failed['exit_code']==1
 for raw,h in prep['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
 result={'schema':'CAUSAL_WICK_BRIDGE_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'COMPLETE_ACTUAL_FREE_GRADED_WICK_REFERENCE_AND_LINEAR_HEAT_T1_NORMALIZATION_BRIDGE_QUALIFIED_NOT_FULL_CAUSAL_TN_QAP_E5','scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],'performance':perf,'elapsed_after_imports':time.perf_counter()-start,'native_failures_preserved':1,'verifier_failures':0,'spectral_matrix_bisolution_and_wavefront_argument_reviewed':True,'all_GF_master_tadpole_words_and_zeros_recomputed':True,'projection_sha256':native[0]['tadpole_projection_sha256'],'GF_sector_words':native[0]['GF_sector_words'],'source_sector_words':native[0]['source_sector_words'],'source_directions_nonzero':native[0]['source_directions_nonzero'],'zero_classical_columns':empty,'linear_T1_source_jet_normalization_bridge':True,'complete_causal_Tn_QAP_E5_A5_proved':False,'positive_state_or_new_ghost_adjoint':False,'authority_changed':False,'analytic_proof':'DERIVATION.md','verification_proof':'VERIFICATION_NOTES.md','qualified_receipts_authenticated_not_replayed':receipts,'shared_limits':'Same action/reference/frame/source/heat premises, portable input and symbolic/numeric libraries, AI author. Pair/derivative/finite-difference routes do not validate shared physical assumptions; no independent scientist, experiment or Lean.'}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
