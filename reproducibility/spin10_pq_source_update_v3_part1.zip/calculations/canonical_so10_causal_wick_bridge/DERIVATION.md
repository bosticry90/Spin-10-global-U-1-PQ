# CWB1 — future-frequency kernels, off-shell contacts and initial normalization

Prospective until native calculations and independent verification complete.
This increment constructs the free Wick/initial-normalization input. The
complete interacting causal Tn assembly is not assumed to follow from it.

## 1. Actual matrix future-frequency covariance

Use eta=(+---), P=p^2 and the frozen W1 covariance C_F=i G_F (hbar suppressed).
Let d_s=delta(P-s), e_0=delta'(P), with the common future factor 2pi theta(p0).
For every color, after this factor is omitted, the actual 5-block is

 W_BB=-eta d_0+(w-1)p p^t e_0,
 W_B Lambda=i p d_0, W_Lambda B=-i p^t d_0, W_Lambda Lambda=0.

The ordered odd pair is W_Ca=d_0, W_aC=-d_0. Each of the328 scalar directions
has W_xx=d_(Mref_sector_squared). Physical-to-raw covariance transport is
Ti W Ti^t, as fixed by FCR1. No source is an integrated covariance direction.

The cut is linear on the ACTUAL coherent rational reference: a simple
(P-s+i0)^-1 gives +d_s after multiplying its boundary jump by i; a massless
double inverse gives -e_0. Its numerator must remain. The covariance matrix
above is obtained from all1550 raw nonzero inverse entries, not an independently
guessed spectral completion. Its full zero complement and643 field directions
are checked. Constant field/source dual frames preserve the grading.

In particular the distribution identities are P d_0=0, P e_0=-d_0 and
(P-s)d_s=0. Substituting them gives K W=W K=0 on both sides of the actual
matrix, including the scalar--auxiliary mixed signs and both widths. This is
a bisolution, as required for a free contraction, rather than another inverse.
The retarded/Feynman inverses remain different objects with their delta source.

Define the massless tensor theta(p0)p^mu p^nu e_0 by differentiation of the
future shell family, or equivalently by half the momentum derivative of
theta(p0)d_0 followed by multiplication by p. The possible derivative of
theta has support at the momentum origin; its unique extension below scaling
degree4 is zero at the relevant derivative degree. Thus there is no missing
cone-tip delta. The scalar shell has scaling degree2, the tensor degree2 and
the linear mixed entry degree1. The bare e_0 without its numerator remains
critical and is not assigned an arbitrary infrared constant here.

These kernels are tempered and have the future-frequency Hadamard wavefront
orientation. In position space the tensor is a finite derivative/multiplication
of the scalar future-frequency kernel, so it adds no opposite wavefront
directions. Positive scalar masses are the usual shell submersions. Constant
graded frames preserve this property. This supplies the matrix bridge rather
than importing a scalar positive-Laplacian theorem for the mixed operator.

## 2. Causal commutator, time ordering and off-shell contact

With graded transpose W^gt_ij(p)=(-1)^(p_i p_j) W_ji(-p),

    W-W^gt = i(G_ret-G_adv).

The numerator-dressed delta-prime has the same homogeneous origin convention
as the actual causal dipole. The matrix relations follow from the coherent
simple/double boundary jumps, and are checked with the ordered odd pair.
For positive/negative time away from coincidence, the Feynman covariance is
the corresponding graded time ordering of W. The dipole commutator and its
first time derivative vanish at equal time, being a mass derivative of the
scalar equal-time commutator. Hence its at-most-two derivatives in the base
BB entry introduce no extra unrecorded time-order contact. First mixed
derivatives similarly use the zero scalar equal-time field commutator.

DERIVATIVE INSERTIONS are different. The covariant jet normalization is to
differentiate the full C_F distribution, including derivatives of its step
functions. The actual identities are

    K C_F=C_F K=i delta I,       K W=W K=0.

For a scalar (Box+m^2)C_F=-i delta. Canonical step ordering of differentiated
free fields away from equal time misses this contact. Consequently one must
not simultaneously set the free equation to zero as an off-shell input
functional and require the action-Ward derivative identity. The original
retained-source setup is off shell and never licenses that quotient.

On the complex graded off-shell polynomial/microcausal algebra define
F star G=m exp(hbar Gamma_W)(F tensor G), with the right/left functional
derivative signs fixed so z_i star z_j=z_i z_j+hbar W_ij. The contraction
operators on slots12,13,23 are even constant-coefficient superoperators and
commute with the Koszul tensor signs. Both associative parenthesizations
therefore equal m3 exp[hbar(Gamma12+Gamma13+Gamma23)]. Wavefront orientation
makes these contractions legitimate on the microcausal domain. Translations
act by automorphisms. This constructs an associative formal algebra, not a
positive physical state, a new ghost Hermitian adjoint or a full T-product.

Indeed at w=1 the B0B0 shell has the opposite sign to a positive scalar shell.
Ghosts have their graded odd pairing. Future-frequency SUPPORT does not mean
positivity of a Hilbert-space quadratic form. The finite star controls test
associativity but cannot by themselves select the correct physical ghost sign;
the odd Gaussian/Berezin and ordered reference equations do that separately.

## 3. A sensitive weak-shell check

For f=exp(-a p0^2-b|pvec|^2), a,b>0, and normalized d4p/(2pi)^4, put c=a+b.
The future shell with its2pi factor pairs as

    D[f]=1/(8pi^2 c).

Let E_munu=2pi theta(p0)p^mu p^nu delta'(P). The independent component tests are

 E00[f]=(a-b)/(16pi^2 c^2),
 E11[f]=(3a+b)/(48pi^2 c^2),
 E01[p0 p1 f]=(3a-b)/(48pi^2 c^3),
 E12[p1 p2 f]=(5a+b)/(240pi^2 c^3).

The trace is E00-3E11=-D. These are obtained both by differentiating a
positive-mass future shell at mass squared0 with its FULL numerator and by
integration by parts of the distributional momentum derivative. Weighted
off-diagonal tests are nonzero for the chosen anisotropies; the unweighted
ones would be insensitive. A symmetric a=b test is insensitive to E00 and
cannot replace the other tests.

## 4. Heat tadpoles and T1(F)=F

The causal convention normalizes T0(1)=1 and T1(F)=F on its chosen local
operator alphabet. The actual heat determinant has a linear one-vertex term,
so simply equating it with that T1 would discard tadpoles. The proper bridge
is a correlated local order-hbar operator normalization.

The n1 heat length is c=2. For a positive scalar reference mass squared M,
the actual coincident covariance finite part is

    d_M = M[gamma_E+log(2M/mu^2)-kappa]/(16pi^2).

Its sign follows from C_F=i/(P-M+i0), the Wick loop measure i and the inherited
Born convention. The common logarithmic ambiguity has L=-M/(16pi^2), hence
the displayed minus kappa. No value of kappa is selected. All massless entries
and their admissible low jets have zero flat n1 heat finite part because their
complete radial expressions are powers with no constant, not because an
unregulated integral was declared scaleless zero. This limited flat statement
does not remove their interacting or background tadpoles.

For scalar jets of total order<=2, the covariance table is

 d(x_i,x_j)=delta_ij d_M,
 d(partial_mu x_i,x_j)=0,
 d(partial_mu x_i,partial_nu x_j)=delta_ij eta_munu M d_M/4,
 d(x_i,partial_mu partial_nu x_j)=-delta_ij eta_munu M d_M/4.

It follows from the FULL heat moments: integral q_mu q_nu/(q^2+M) has finite
Euclidean value -delta_munu M d_M/4, since the unit trace's finite part is
zero. The Lorentzian numerator and covariance phases give the table above.
It obeys the required total-derivative relations. The actual scalar frames
are checked before using a diagonal scalar contraction in the portable maps;
if they were nontrivial they would have to be transported instead.

For any admitted local polynomial F define beta1(F) as the sum of all one-pair
self-contractions with this jet table, including the usual factor1/2 for its
second derivative. It is linear, local, real in the inherited physical
structure, ghost-number and dimension preserving, and retains external sources.
Equivalently beta1(F)=1/2<d, F^(2)> as a local functional with all derivative
placements. The formula covers the complete physical action without requiring
a new expansion of all34 physical densities. Its concrete complete GF and
all643 source-rule projections are independently calculated here; the physical
potential's full canonical coefficient table is not extracted by this test.

Because d is field/source independent, beta1 commutes with their functional
derivatives and with total derivatives using the full jet table. In particular
beta1(sum J_z R_z)=sum J_z beta1(R_z) with the original source-left order.
If an actual projection is zero, omission of it is an insensitive control;
a nonzero J*x^2 fixture still tests source-before-restriction normalization.
Do not claim an actual sensitive source test if the measured trace vanishes.

Write beta(F)=F+hbar beta1(F). Its inverse is F-hbar beta1(F) modulo hbar2.
If the normalized causal loop contribution has its one-vertex tadpole removed,

 Gamma_T(beta(F))=F+hbar beta1(F)
                     +hbar[Gamma_heat,1(F)-beta1(F)]
                 =F+hbar Gamma_heat,1(F) modulo hbar2.

All connected n>=2 loop vertices use F, not its hbar correction, at this order.
This is a true initial-normalization bridge, not changing T1's axiom or setting
the measured tadpole to zero. It reuses the independently fixed heat finite
part instead of fitting an unknown source normalization. It is a local
renormalized-operator normalization; it is NOT a claim that d is the value of
a globally smooth Lorentz-invariant tempered Hadamard state difference.

## 5. What remains for the causal vertex construction

The free graded algebra, time-order contacts and local T1 bridge are necessary
inputs to a causal Tn/vertex construction; they do not prove all its axioms.
The remaining assembly must use the MLB1/HMM1 loop map, tree sewing and local
extension, with graded permutations, causal factorization, field independence
and action/jet normalization imposed simultaneously on the stated compact
local operator domain. It must distinguish a general compactly switched
operator domain from the fixed unlabelled constant-insertion family and from
global adiabatic limits. A generic scalar theorem or a finite associativity
fixture does not supply those remaining hypotheses.

No complete QAP, measure, global quantum equivalence, physical positivity,
constant-vacuum or E5/A5 claim is made. The reference-background determinant
and its phase/historical-member ambiguity are retained; a flat local
normalization does not divide away its response. kappa and b0 remain distinct.
No source/action coefficient or physical scheme/benchmark is adopted.

Reference standards: Brennecke--Duetsch, https://arxiv.org/pdf/0801.1408,
section3 and Theorem5.2, require a properly normalized causal product before
their QAP result; Duetsch--Fredenhagen, https://arxiv.org/pdf/hep-th/0403213,
section3.2, treats the off-shell action-Ward extension problem. Those scalar
frameworks motivate the requirements, not validate the present mixed/odd
matrix or complete its interacting construction. Shared assumptions,
software and AI authorship remain limitations; this is not a Lean proof.
