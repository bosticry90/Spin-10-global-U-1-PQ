# CWB1 result: actual free Wick algebra and the heat-compatible T1 bridge

The complete frozen 643-field reference now has an explicit graded
future-frequency covariance suitable for an off-shell Wick algebra. Its
homogeneous field equations, causal commutator, Feynman/contact relations
and coordinate frames are qualified within the declared flat reference scope.
A correlated local first-order operator normalization reconciles the heat
one-vertex term with T1(F)=F without deleting tadpoles or source terms.

Main completed receipt SHA256:
`df7244abe289f6ab480b58ac31c3b380a94d85d3896d0e2ab990269ad1b55540`.
Actual singlet supplement completed receipt SHA256:
`bd985d4481239ffbdf7cb4ea28b469454a580d8d5587791811919dd9c5fda852`.
Execution and bounded evidence validation completed; director scientific
acceptance was not performed. Authority stays 34/39, E5/A5 unqualified.

## Free construction, including all zero entries

The construction covers all 1,550 nonzero raw covariance positions and
411,899 implicit zero positions. It retains all 45 mixed vector/auxiliary
blocks, both symbolic widths, the 45 ordered odd pairs and all 328 scalar
directions with positive reference masses. The actual constant raw/physical
and dual maps are retained; scalar-frame identity is checked before the
portable canonical scalar contractions are used.

The covariance is the coherent future-frequency cut of the actual Feynman
inverse. With its common 2pi*theta(p0) factor omitted, the physical vector block is

    -eta*delta(P)+(w-1)*p*p^t*delta'(P),

the mixed entries are +i*p*delta(P) and -i*p^t*delta(P), the auxiliary diagonal
is zero, and the ordered ghost entries are +delta(P), -delta(P). Scalars use
delta(P-Mref^2). Both K*W=0 and W*K=0 hold, including the numerator-dressed
double pole. The bare critical delta-prime is not assigned an infrared
normalization. The full tensor has its origin-valid distributional extension.

The graded commutator equals i times the already qualified retarded-minus-
advanced inverse. Future-frequency wavefront orientation allows the Wick
contractions on the declared microcausal off-shell domain. Constant even
contraction operators give an associative formal graded star product. The
two native implementations use pair matchings versus differential left
action, with 512 finite associativity fixtures each; the all-order algebraic
argument supplies the general statement. The finite fixtures do not prove
the interacting time-ordered construction.

Future-frequency support is not a positive Hilbert-space state. The gauge
time component already gives an indefinite quadratic form, and the ghosts
have their required odd pairing. No new ghost Hermitian adjoint or physical
positivity convention is adopted.

The time-order distinction is consequential: K*C_F=i*delta*I while K*W=0.
Differentiating time-ordered kernels must retain their local contacts.
Quotienting by the free field equation and then imposing the same off-shell
action-Ward identity would incorrectly remove a nonzero contact. The present
construction retains the original off-shell/source convention.

## The initial-normalization result

The actual n1 flat heat covariance for a positive scalar reference mass
squared M is

    d_M=M[gamma_E+log(2M/mu^2)-kappa]/(16pi^2).

The admissible low scalar jets have the correlated Lorentzian contact table
specified in DERIVATION. All massless flat n1 reference finite parts vanish
by their complete heat radial signatures, without declaring arbitrary
interacting scaleless amplitudes zero. kappa remains symbolic and distinct
from the earlier b0 baseline.

Define beta1(F) as the sum of all one-pair self-contractions of a local F with
this fixed table. It is local, linear and preserves the field/source grading,
dimensions, total derivatives and inherited real structure. Sources are kept
external and differentiated before restriction. This is an operator/input
normalization, not a change to the T1 axiom or to a physical benchmark.

The complete 33,092 GF rows and 35,162 master-map rows give zero projections
under beta1 in every reference sector. All 643 directions, including the
15 exactly empty classical maps, are included. The empty projection hash is
`4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945`.
These are qualified complete zero projections, not missing entries. Actual
source-tadpole omission is therefore INSENSITIVE in this test. The separate
J*x^2 source fixture remains sensitive; it must not be confused with an
actual nonzero source contribution.

The physical action is not zero under this operator. The actual singlet
quartic Hessian in both frozen packets supplies the nonzero control

    beta1[-lambdaS*(x^2+y^2)^2/4]
        =-2lambdaS*d_S*(x^2+y^2)
        =-4lambdaS*d_S*SBar*S.

Real-coordinate differentiation and complex S/SBar pair contraction agree.
This local structure is already the original singlet mass direction. Its
formal operator-normalization coefficient is 4lambdaS*d_S; no mass shift is
adopted, no scale/kappa value is fitted and no pole-mass or quantum-control
prediction follows. The complete physical 34-density canonical tadpole
table was not expanded; the universal operator formula covers those local
operators, and the actual singlet term is independently verified.

At strictly one-loop order, using F+hbar*beta1(F) as the normalized input
and removing that same n1 term from the normalized loop part reproduces
F+hbar*Gamma_heat,1(F). The inverse operator normalization is explicit modulo
hbar^2. This supplies the missing initial-condition dictionary while retaining
all measured heat terms and correlated source conventions.

## Verification, failures and remaining scope

Successful native primary/replay took 33.787317/33.744723 seconds after imports.
The main verifier took 1.501699 seconds and singlet verification 0.832935
seconds. Native shell tests use 45/75 digits, independent verification 90
digits, with 1e-25 agreement. All runtime and launch/sample memory bounds
were respected. Largest observed private-memory sample was 195,805,184 bytes,
not a true peak; the new package is below 4 MiB.

Primary V1 failed its census assertion because a Counter updated only on
nonempty rows omitted the 15 exactly zero classical maps. V2 initializes every
column and explicitly records the zero names, keeping all 643 required.
The original source/preparation/full failed capture remain. Both native
roles were rerun because V1 produced no completed result. One native failed;
no verifier failed. No incomplete run was relabeled PASS.

There are 41 original, 51 V2, 64 main-verification and 74 singlet bindings.
Pair-slot, symbolic derivative and independent finite-difference calculations
agree on every GF/source coefficient and zero. The verifier also checks
independent Feynman-imaginary-part shell formulas, an exterior representation,
the Berezin sign, equal-time contact and jet/free-quadratic normalization.
Read-only navigation had missing paths/glob and overbroad outputs; actual
inventories and targeted reads recovered the needed singlet Hessian. Those
were navigation overhead, not failed scientific workers.

Underlying action/reference/large loop evidence and broad E4 were not freshly
replayed. Their completed qualifications and exact input bytes were reused.
New raw/index/HEAD bytes and all old tracked blobs are sealed separately.
Methods share action/reference/domain/Wick assumptions, portable data,
libraries and AI authorship. This is not independent scientists, experiment
or Lean certification of the physical premises.

The remaining task is the interacting causal Tn/vertex construction with
simultaneous causal factorization, graded permutation, field independence
and action/jet normalization on a precise operator domain. Free associativity
and a T1 bridge do not prove those axioms or a full QAP. The reference-background
determinant and its absolute phase/historical member choice remain retained.
Global products/equivalence, physical states, adiabatic/vacuum limits and
full E5/A5 remain unqualified. Historical quartet failure, scalar quantum-
control/gauge-matching concerns, HB1/C5 block, paused flavor, uncalculated C1_GS
and custody exit2/seven references are unchanged. No old evidence, source
functional, policy, action, physical scheme or authority changed.
