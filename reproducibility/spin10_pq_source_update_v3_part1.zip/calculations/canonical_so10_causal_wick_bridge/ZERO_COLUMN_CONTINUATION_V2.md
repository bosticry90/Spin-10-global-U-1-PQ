# V2 continuation — retain all zero source columns

Primary V1 completed the matrix/spectral checks, graded associativity fixtures
and local trace computation, then failed its target-counter assertion. The
frozen master input has643 keys and35162 rows, including15 exactly empty
classical maps. A Counter updated only inside the row loop omitted those15
keys. Empty maps are qualified zero directions, not absent evidence.

V2 initializes each target counter before iterating its rows and explicitly
reports the zero-column names. Preserve V1 source/preparation/full failed
capture. Replay V1 never launched. Both native roles must be rerun because V1
produced no completed result. No formula, coefficient, source convention,
tolerance, precision or cap changes. All643 directions remain required.
