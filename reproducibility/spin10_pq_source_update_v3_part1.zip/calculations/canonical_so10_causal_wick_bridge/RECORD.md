# CWB1 contract — actual free Wick algebra and the T1 normalization bridge

Previous goal turn PROGRESS, MLB1 commit
b1e089bfdbd7ed18b3be5feca7b9f8842c89d0d7. Preflight clean main/no matching
workers/452 declared-byte bindings authenticated only. State v113,34/39.

Question: can the complete 643-field causal/Feynman reference support the
graded off-shell Wick algebra needed for the causal vertex construction, and
can its heat one-vertex term be reconciled with T1(F)=F without discarding
tadpoles, derivative contacts or correlated source normalizations? This is
the next concrete initial-condition prerequisite, not a universal QAP claim.

Freeze actual reference raw/physical/dual frames, ordered odd signs, positive
scalar reference masses, symbolic widths, all external BV sources and ordinary
jets. Reuse FCR1/FBR1/LBE1/HMM1/MLB1, original W1-W7, portable complete GF and
all field-map inputs. No scalar-only replacement or positive physical state
is presumed. The existing order-preserving real structure is not silently
replaced by a Hermitian ghost adjoint.

Acceptance: construct all future-frequency covariance entries and implicit
zeros, check both homogeneous field equations, graded commutator and Feynman
relations including the numerator-dressed double pole and origin; derive the
off-shell derivative contact and associative graded Wick product. Construct
the linear one-loop local operator normalization beta1 from the actual flat
heat tadpole, including its scalar jet table. Compute its complete GF and
source-rule projections with both methods, retaining every zero direction.
The universal local formula covers the physical action too; its full physical
canonical table need not be expanded merely to verify T1 normalization.

Primary: cut the actual rational reference and transport its physical blocks;
pair-slot contraction on exact coefficient cells for every GF/master row.
Replay: independent physical cut/bisolution reduction and inverse frame
comparison; scalar polynomial second derivatives for local contractions.
Independent verification checks kernels, weak shell tests, exact local tables
and source/jet normalization. Meaningful controls distinguish wrong delta-prime
sign, ghost order, missing time-order contact, loss of tadpole, premature source
restriction and a false positive-state inference. Mark any actually zero
projection as insensitive to its omission; use a declared nonzero fixture.

The n1 heat length is 2 and the logarithmic ambiguity is retained as kappa.
No finite constant is fitted. No action/source coefficient or benchmark is
adopted or modified. Full causal Tn factorization, simultaneous general
normalization and QAP require their own assembly proof; neither the free
algebra nor a working T1 bridge automatically proves them. Constant-vacuum,
global field/source equivalence and arbitrary multiple products remain outside.

Before computation bind proof, sources, completed input receipts, live policy,
state/handoff V365 and frozen reference/portable bytes. Sequential native caps
120s after imports; verifier180s. Sampled private cap8GiB (not true peak),
350MiB available-commit launch floor,4MiB new package. Numeric45/75digits,
agreement1e-25; verifier90digits. Preserve every failed source/capture before
correction; do not weaken acceptance. Do not repeat expensive qualified
action/loop calculations unnecessarily. A bounded incompatibility or missing
normalization premise is a valid outcome, not automatically an anomaly.

No old evidence, policy/state, physical scheme/reference, source functional,
branch, remote, publication/outreach or protected blocked/paused work changes.
No E5/A5 promotion. Quartet, scalar quantum-control/gauge-matching limits and
custody exit2/seven remain. Multiple AI/software routes share premises and
authorship; no outside expert, experimental or Lean validation is asserted.
