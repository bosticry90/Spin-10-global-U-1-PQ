# CWB1 independent verification

The homogeneous spectral equation has an independent whole-matrix derivation:
take the coherent boundary jump of the already qualified two-sided inverse
K G=G K=I. K is polynomial and has no boundary jump, so both homogeneous
equations follow for the exact frozen raw reference. This reuses the complete
FCR1/FBR1 qualifications; it is not a scalar substitution for an unverified
matrix. The native routes additionally construct/compare all raw cut entries
and their frames directly. Scalar frame identity is rechecked before using
diagonal contractions on the portable canonical variables.

Future shell/tensor weak values are independently recovered from the imaginary
parts of FBR1's scalar Feynman Gaussian and its differentiated tests. The
graded odd Gaussian sign is fixed by Berezin integration, not by assuming a
commuting ghost covariance. Equal-time scalar and dipole mode derivatives
fix the time-order contact and show exactly where off-shell equations cannot
be discarded. A free Wick algebra is complex and graded here; neither physical
Hilbert positivity nor a new ghost Hermitian adjoint is introduced.

The actual tadpole projections are recomputed using exact finite-difference
stencils, independent of the slot-pair and scalar-polynomial derivative routes.
All 33,092 GF and 35,162 master rows, all643 directions including15 empty maps,
all nonzero coefficients and their zero complement are compared. The scalar
jet table makes beta1(partial_mu[x partial_nu x]) vanish and beta1(S0_scalar)
vanish; retaining the contact jets is necessary. The universal beta1 formula
covers other local physical operators, but their complete34-density canonical
tables are not claimed as newly measured results.

The initial-normalization identity is strictly order hbar. Adding beta1(F)
to the operator input cancels its subtraction from the normalized loop part,
without changing T1's axiom or fitting a finite constant. Source differentiation
commutes with beta1 because its scalar contractions are source independent.
Any actual zero source trace is marked omission-insensitive; the J*x^2 fixture
is separately sensitive. kappa, b0 and reference masses are not fitted.

These results supply free Wick and T1 inputs. Full interacting causal Tn
factorization and its simultaneous action/jet/field/source axioms still need
assembly on a precise operator domain. No general QAP or E5/A5 inference is
licensed by a finite associative example or the published scalar framework.
