# Finite antighost ultraviolet frontier V1

The actual coupling/dimension census supports an upper bound of g10^4 for
all 33 broken-antighost one-loop local logarithmic insertions in the explicit
Weyl reference family. This is a finite-frontier theorem, not an evaluation
of the remaining coefficients or a full antighost/E5 restoration theorem.
Qualification requires the completed independent validation receipt and the
subsequent committed-byte check; this report alone is not that receipt.

Every admissible two-internal-port choice of the 16 ordinary vertex types has
positive external/coefficient cost and coupling degree no greater than that
cost. All 122,016 selections from the actual B0 and C insertion rows obey the
same bound. Of these, 2,272 require positive-dimensional coefficients; none
was discarded. Summing the engineering-dimension budget of a local density
bounds the total coupling degree by four, at every word length. Native direct
external costs and complementary internal dimensions agree. The verifier
independently checks the finite generating-polynomial support, rather than
merely repeating the native dynamic program.

The Weyl D and D^2 background terms preserve this budget. The qualified
weighted principal inverse introduces no inverse g10 or physical mass; the
V255 formal ordered-heat theorem supplies the leading-log correspondence.
The result is restricted to that explicit local family and its inherited
formal momentum/infrared qualifications. It does not cover arbitrary added
covariant terms or a uniquely recovered historical physical prescription.

A second check uses all 146,663 measured source coefficient positions and the
actual source-kernel channels. The g10^1 kernels use vector/scalar sources;
the g10^4 source poles use JL13 through JL44. Their supports are disjoint.
There is no possible g10^5 source correction from these inputs. This is a
support proof, not a coefficient fitted to a Slavnov cancellation.

## Evidence frontier

All 664 ordinary antighost profiles in the qualified 2,353-profile flat/bare
catalogue are classified, with explicit H/M roles, derivatives, widths,
families and coefficient dimensions. Newly reused complete scopes are:

| Earlier measured scope | Additional matched profiles |
| --- | ---: |
| g10^2 four-ghost quartet | 7 |
| g10^3 four-ghost quartet | 14 |
| g10^2 auxiliary/antighost/ghost | 3 |
| g10^2 vector/antighost/ghost, both derivative placements | 42 |

Together with prior matches, 209 profiles have complete matched scope evidence;
455 remain EVIDENCE_NOT_RECONCILED_HERE. Those statuses do not establish missing
amplitudes, zeros or anomalies. Of the unreconciled profiles, 427 have only
broken antighosts; the others contain an unbroken antighost projection whose
aggregate dependence is already fixed by a separate theorem. That theorem
covers the sum, not individual families or the pure-heavy complement.

There are 37 positive-dimensional profiles: five ghost/antighost mass-class
profiles at g10^4, twelve scalar/ghost/antighost profiles at g10^3 and twenty
at g10^4. Scalar-reference mass-expansion lists happen to be empty for this
antighost catalogue; omission of such expansions is consequently not claimed
as a sensitive control. Positive coefficient dimensions remain essential.

The smallest lower-order unreconciled cohorts include one explicit-background
ACa one-derivative profile, fourteen BBaC no-derivative profiles and eight
scalar-pair aC profiles at g10^2. Three auxiliary/aC profiles at g10^3 and
higher vector/scalar/four-ghost cohorts also remain. The machine-readable
summary retains all 25 target classes and each exact profile index. A bare
catalogue match does not close the separate off-flat reference/heat response.

## Verification, limitations and next action

Both native runs completed. The independent verifier must authenticate both
full captures, compare exact descriptors, check each route's actual cycle
witnesses, recompute the costs and source support, and verify complete legacy
scope matching. Negative controls retain the positive mass/VEV cost, reject
an inflated coupling degree, detect omitted dimensionful profiles and prevent
promoting the unbroken aggregate theorem to all 33 broken directions.

One preparation/controller event failed before scientific workers launched:
the unbroken theorem's receipt is validation_v5_receipt.json, not the default
filename. Its errors and unfrozen worker/controller bytes are preserved with
PRELAUNCH_CORRECTION.md. The initial preparation command was inline; no original
standalone preparation script exists for it. Neither native scientific run
failed. Final verifier performance and execution counts belong to its receipt.
No fresh byte-identical replay pair is claimed.

No loop integral or new pole was calculated. Known functional (155,110 words),
source image, inputs, physical scheme, benchmark and scientific authority
remain unchanged. All seven quantum assumption flags remain false; full
source-free Slavnov restoration, QAP, measure, contacts, infrared conditions,
equivalence and E5/A5 are unqualified. Authority remains 34/39; custody exit 2
and seven unresolved references are not promoted. Historical quartet failure,
scalar quantum-control warning and gauge-matching limitations remain separate.

The least expensive next test is a structural reconciliation of the earliest
unmatched g10^2 sectors. In particular, test whether the actual longitudinal
mixed propagators and full Yang-Mills Hessian force a cancellation between
BBaC contact and exchange families. Derive any identity from the unchanged
action with complete unbroken/broken intermediate states and all widths;
projected-heavy Jacobi shortcuts or symmetry-fitted coefficients are invalid.
If it fails, preserve the actual missing tensor rather than assume a zero.

Shared action, catalogue, grading, prior measured scopes, normalization,
software and AI author limit independence. The checks corroborate exact
bookkeeping and a dimension bound; they are not new loop integration, Lean
certificates, expert review or experimental validation. Track B gains a finite
completion frontier and reuse of existing evidence, while the missed scalar
and dimensionful cohorts document why selected identities alone were
insufficient.
