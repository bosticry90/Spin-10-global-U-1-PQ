# Prelaunch qualified-receipt correction

The first unfrozen preparation failed before creatingpreparation.json because
it guessed validation_receipt.json for the unbroken-antighost theorem. The
actualcompleted qualified receipt isvalidation_v5_receipt.json. The following
controller alsofailedbeforelaunchwhen no preparationexisted. No nativeor
verifier processwascreated,no scientificcalculationran. Fullreportedexception
andunfrozen source/controllerbytes arepreserved externally. BindtheactualV5
receipt;neverrebindorreplacehistoricalevidence. Nativeauthreceives thesame
explicitfilename. No scope,math,input orresourcechange. Workerfailurecount0;
prelaunch/controller failureevent1 (twoexceptions inone failed launchcall).
