# Coupling order is bounded by the external dimension budget

One-loop localdensities have engineeringdimension4. Everyordinarycycle vertex
has exactlytwointernal fluctuation ports. Define c_v as thesumofdimensions/
externaljets ofits remainingports pluspositivecoefficientdimension. Theactual
catalogue has c_v>=1:zero-cost field-independentprincipalkernels belonginKref,
not arbitraryrepeatedinteractionvertices. Mass/reference-subtractionvertices
havecost2;orbitvertices retainpositiveVEVcost. Test g_v<=c_v onALLports.

For an actualantighost-Hessian insertionroot,epsilon hasdimension1 andeach
h_i/k_i has thedimensionofits actualfield. Derivativesretaintheirjetcost.
Coefficientdimension is4minusalltoken/jetdimensions (withtheactuallocal-action
homogeneity andnonnegative mass/VEV ring). For C thisisthedisplayedtwo-fluctuation
row;for B0 itischeckedovereverytwoquantum-field slotselection beforepossible
cancellations. Define c_root as dimensionofall externaltokens includingepsilon
pluscoefficientdimension. Test g_root<=c_root ratherthan guessingfromrootvalence.
For a UVlogarithm,c_root+sum c_v+Taylor/mass costs=4,so
 g_total=g_root+sum g_v<=c_root+sum c_v<=4.
Thefinitebound holds forallwordlengths,notjustsampledBornwords. Thepositive
cost alsoimpliesatmostfourinteraction/root factors. A bounded integerknapsack
computes thelargestallowedg for budgets0..4 andcross-checks everyactualroot.
Ifanactualinequalityfails,theproposedboundisrefuted,not rescuedbydroppingit.

TheWeylreference usesD=partial-g rhoA. ItsD^2 expansion hasgA*partial,
g(partialA),g^2AA;their externalcostsare respectively1,2,2. Thefirstorder
mixedblock replacement hasgA ofcost1. Zeroth-orderreference masses have
positivecoefficientdimension andg0. TheactualHcarriers preservefieldweights.
Inverse-symbol recursionsretainlocalpolynomialjets withnonnegativeg andno
inversephysicalmass;closedmixedweights telescope. Theheatgenerator uses the
sameD^2;orderedDuhamel factorsdonotgenerateextra g. V255 supplies theleading
log correspondence,notafinite/globalIR theorem. Extraarbitrarycovariantization
vertices thatviolatethiscouplingcounting areoutsidetheexplicitWeylfamily.

Thereisalso a source-channel check. D fieldpart hasg0;sourcekernelV hasatmost
itsactualrecordedgorders. Ordinaryantighostpoledegree isboundedfromthevertices.
Sourcepole gorders andactualV sourcechannelsareknown. If V1 andg4sourcepoles
have disjointsourcechannels,thepossibleg5sourcecorrection iszero bysupport,
not bya loopnormalizationfit. Checkthisexplicitly;do notassumeit fromnames.

Thebound doesnot evaluate orders2..4. Inparticular,theflat/bare2353-profile
catalogue isnotfullbackgroundreference/heatcoverage. Atg1,V258reconcilesall
12antighostprofiles;higherprofiles mustbematchedtospecificqualifiedfamilies.
Dimensionfulghost/antighost terms aredistinct fromdimension-zeroquartets and
cannotinherittheirzeros. Anunbroken-antighost identity canfixa SUMprojection
containingbar_H,while individualprofiles andpureheavy components remain
unmeasured. It isincorrecttocountthat asfullfamilycoverage.
