"""Actual finite coupling-cost bound and conservative higher-antighost coverage."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
a=load('actual_antighost_finite_types',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;s=a.s;read=a.read;digest=a.digest;PKG=a.PKG
def rdim(n):return 2 if n.startswith('L') else 1
def kinds(row):return tuple(sorted('x' if n.startswith('X_') else n[0] for n,j in row['external_ports']))
def family(row):return tuple(sorted(t.split('_g')[0] for t in row['vertex_family']))

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('FINITE_FRONTIER_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);w=m.setup();grades=w.grades|w.external;fieldnames={m.names[n] for n in m.fields};sources={m.names[n] for n in m.sources};stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');vertices=inv['actual_sourcefree_vertices'];old=b.auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');costs=[];badports=[]
 for tag,V in sorted(vertices.items()):
  for pp,ports in enumerate(V['ports']):
   for i,j in combinations(range(len(ports)),2):
    if ports[i][0].startswith('A') or ports[j][0].startswith('A'):continue
    ext=sum(rdim(n)+jet for k,(n,jet) in enumerate(ports) if k not in [i,j]);cost=ext+V['cd'];entry=[tag,pp,i,j,V['g'],ext,V['cd'],cost];costs.append(entry)
    if cost<1 or V['g']>cost:badports.append(entry)
 assert len(vertices)==16
 def typ(token):
  base,sep,jets=token.partition('__')
  if base.startswith(('zz_h_','zz_k_')):g=grades[base[5:]]
  elif base.startswith('zz_da'):g=(1,-1,1)
  else:g=grades[base]
  return g[0]+len(jets),g[1],g[2],base
 def roots():
  hist=Counter();bad=[];selected=0;positive=0;mincost=9;maxg=0;bounds=[]
  for label,rows in [('C',old['complete_mixed_Hessian_insertion']),('B0',old['classical_sourcefree_breaking'])]:
   for ri,row in enumerate(rows):
    tt=[typ(n) for n in row['word']];assert sum(t[1] for t in tt)==0 and sum(t[2] for t in tt)%2==0;assert sum(t[3].startswith('zz_da') for t in tt)==1;cd=4-sum(t[0] for t in tt);assert cd>=0
    if label=='C':inside=[i for i,t in enumerate(tt) if t[3].startswith(('zz_h_','zz_k_'))];assert len(inside)==2;selections=[tuple(inside)]
    else:selections=list(combinations([i for i,t in enumerate(tt) if t[3] in fieldnames],2))
    for i,j in selections:
     external=sum(t[0] for k,t in enumerate(tt) if k not in [i,j]);cost=external+cd if role=='primary' else 4-tt[i][0]-tt[j][0];assert cost==external+cd and cost>=1;selected+=1;positive+=int(cd>0);mincost=min(mincost,cost);maxg=max(maxg,row['g']);hist[label,row['g'],cost,cd]+=1;bounds.append((row['g'],cost))
     if row['g']>cost:bad.append({'kind':label,'row':ri,'slots':[i,j],'g':row['g'],'cost':cost,'coefficient_dimension':cd,'word':row['word']})
  return {'histogram':[[*key,value] for key,value in sorted(hist.items())],'two_slot_selections':selected,'positive_coefficient_dimension_selections':positive,'minimum_external_cost':mincost,'maximum_root_g':maxg,'violations':bad},bounds
 rootinfo,rootbounds=stage('all_actual_B_C_root_grades_and_every_two_slot_budget',roots)
 # Unbounded integer budget with positive costs proves all word lengths.
 items=sorted({(r[4],r[7]) for r in costs});best=[0]*5
 for budget in range(1,5):best[budget]=max([0]+[gp+best[budget-c] for gp,c in items if c<=budget])
 derived=max(gp+best[4-cost] for gp,cost in rootbounds);ordinary_bound=best[4];bound4=not badports and not rootinfo['violations'] and derived<=4
 for row in inv['all_profiles']:assert row['g']<=ordinary_bound
 prim=b.auth('canonical_so10_local_source_primitive',role+'_v2_result.json');assert prim['all643_source_maps_match'] and prim['current_source_positions']==146663;sourceorders=defaultdict(set)
 for row in prim['normalized_source_image']:
  JJ=[n.partition('__')[0] for n in row['word'] if n.partition('__')[0] in sources];assert len(JJ)==1;sourceorders[JJ[0]].add(row['g'])
 vorders={J:{r['g'] for r in rows} for J,rows in old['all33_kernel_maps'].items()};pairs=defaultdict(list)
 for J,gs in vorders.items():
  for gv in gs:
   for gg in sourceorders.get(J,set()):pairs[gv+gg].append([J,gv,gg])
 source_bound=max(pairs);g5=pairs.get(5,[]);v1=sorted(J for J,gs in vorders.items() if 1 in gs);s4=sorted(J for J,gs in sourceorders.items() if 4 in gs);sourcecheck=source_bound<=4 and not g5
 witness=b.auth('canonical_so10_local_covariant_reference_witness',role+'_result.json','validation_v2_receipt.json');assert witness['explicit_covariant_operator']['derivative']=='D_mu=partial_mu-g10 sum_a rho_a A^a_mu';assert all(len(word)<=2 for i,j,word,z in witness['explicit_covariant_operator']['entries']);assert witness['same_actual_weighted_principal_symbol'] and witness['formal_H_covariance_from_actual_pairing_Lie_and_affine_rules']
 # Exact elementary D/D^2 expansion costs;coefficient order remains displayed.
 background=[['g A partial',1,1],['g partial(A)',1,2],['g^2 A A',2,2],['mixed_first_order_gA',1,1]];assert all(gp<=co for name,gp,co in background)
 symbol=b.auth('canonical_so10_ub12_reference_symbol',role+'_v2_result.json');assert symbol['no_width_g_or_reference_mass_inverted_in_principal'];uv=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log']
 frontier=b.auth('canonical_so10_sourcefree_coverage_frontier',role+'_result.json');prior={i:'PRIOR_'+name for name,z in frontier['qualified_matched_cohorts'].items() for i in z['indices']};g1=b.auth('canonical_so10_broken_antighost_g1_reconciliation',role+'_v2_result.json')
 for rec in g1['sourcefree_g1_antighost_profile_evidence']:prior[rec['index']]='G1_'+rec['evidence']
 q2,q2b=b.sealed('frozen_a10_e5_quartic_companion','primary_v3' if role=='primary' else 'replay_v2');q3,q3b=b.sealed('frozen_a10_e5_quartic_g3',role);aux2,auxb=b.sealed('frozen_a10_e5_auxiliary_next',role+'_bound');dg,dgb=b.sealed('frozen_a10_e5_derivative_gauge',role)
 assert q2b['complete_selected_actual_quartet_qualified'] and q2['domain']=={'antighost_directions':45,'ghost_directions':45,'implicit_zeros_exact':True,'independent_pair_slots':980100};assert set(q2['family_poles'])=={'box','mixed_triangle','ordinary_triangle','quartic_bubble'} and q2['program']['arbitrary_light_heavy_reference_widths_retained']
 assert q3b['new_actual_g3_quartet_loop_calculated'] and q3['domain']=={'antighost':45,'antisymmetric_pair_slots':980100,'ghost':45,'implicit_zeros_exact':True};assert set(q3['bound_family_poles'])=={'GGGX_box','GGQ_triangle','GXR_triangle','GXW_triangle','QR_bubble','WQ_bubble'} and q3['program']['no_slot_or_width_cutoff']
 assert auxb['complete_selected_actual_auxiliary_next_pole_qualified'] and aux2['domain']=={'all45_aux_anti_ghost':True,'all_tensor_slots':91125,'g_degree':2,'zeros_exact':True};assert dgb['new_actual_derivative_loop_calculated'] and dg['domain']['all_tensor_slots']==182250 and dg['domain']['implicit_zeros_exact'] and dg['domain']['independent_derivative_placements']==2
 sets={'LEGACY_G2_QUARTET':{tuple(sorted(z)) for z in [('F','F','X','X'),('F','Q','X'),('D','X','X'),('Q','Q')]},'LEGACY_G3_QUARTET':{tuple(sorted(z)) for z in [('F','F','F','X'),('F','F','Q'),('F','R','X'),('D','F','X'),('Q','R'),('D','Q')]},'LEGACY_G2_AUXILIARY':{tuple(sorted(z)) for z in [('F','F','X'),('F','U','X'),('R','X'),('D','X')]},'LEGACY_G2_DERIVATIVE_GAUGE':{tuple(sorted(z)) for z in [('F','F','X'),('F','U','X'),('F','G3','X'),('F','Q'),('D','X')]}}
 table=[];groups=defaultdict(list);newcohorts=Counter()
 for i,row in enumerate(inv['all_profiles']):
  if not any(n.startswith('a') for n,j in row['external_ports']):continue
  ty=kinds(row);gp=row['g'];cd=row['vertex_coefficient_dimension']+2*len(row['scalar_reference_mass_expansions']);js=row['total_external_jets'];fam=family(row);match=prior.get(i);candidate=None
  if cd==0 and not row['scalar_reference_mass_expansions']:
   if ty==('C','C','a','a') and js==0 and gp in [2,3]:candidate='LEGACY_G'+str(gp)+'_QUARTET'
   elif ty==('C','L','a') and js==0 and gp==2:candidate='LEGACY_G2_AUXILIARY'
   elif ty==('B','C','a') and js==1 and gp==2:candidate='LEGACY_G2_DERIVATIVE_GAUGE'
  if match is None and candidate and fam in sets[candidate]:match=candidate;newcohorts[candidate]+=1
  roles=[n for n,j in row['external_ports']];aggregateH='aH' in roles;heavy_only=not aggregateH and any(n=='aM' for n in roles);descriptor={k:v for k,v in row.items() if k!='witness'}
  rec={'index':i,'types':list(ty),'g':gp,'jets':js,'coefficient_dimension':cd,'descriptor':descriptor,'family':list(fam),'complete_cohort_match':match,'family_measurement_status':'MATCHED_COMPLETE_SCOPE' if match else 'EVIDENCE_NOT_RECONCILED_HERE','unbroken_aggregate_projection_known_not_individual_family':aggregateH,'pure_heavy_antighost_projection':heavy_only};table.append(rec);groups[ty,js,gp,cd].append(rec)
 unbroken=b.auth('canonical_so10_unbroken_antighost_completeness',role+'_result.json','validation_v5_receipt.json');node=b.auth('canonical_so10_unbroken_ghost_quartic_integration',role+'_result.json');assert unbroken['scientific_disposition']=='COMPLETE_UNBROKEN_LOCAL_POLE_DEPENDENCE_MOD_INDEPENDENT_AND_BOUNDARY' and unbroken['current_sourcefree_positions']==40309 and unbroken['barH_independent_functional_and_broken33_unconstrained'];assert node['updated_known_terms']==155110 and node['updated_known_sha256']=='ce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1'
 N4=node['new_derived_g4_unbroken_ghost_quartic_node'];assert all(any(n.partition('__')[0].startswith('bar') for n in r['word']) for r in N4)
 summary=[]
 for (ty,j,gp,cd),rr in sorted(groups.items()):summary.append({'types':list(ty),'jets':j,'g':gp,'coefficient_dimension':cd,'profiles':len(rr),'matched_complete_cohort_profiles':sum(bool(r['complete_cohort_match']) for r in rr),'unreconciled_profiles':sum(not r['complete_cohort_match'] for r in rr),'unreconciled_pure_heavy_profiles':sum(not r['complete_cohort_match'] and r['pure_heavy_antighost_projection'] for r in rr),'families':sorted({tuple(r['family']) for r in rr}),'indices':[r['index'] for r in rr]})
 positive=[r['index'] for r in table if r['coefficient_dimension']>0];mass=[r['index'] for r in table if r['descriptor']['scalar_reference_mass_expansions']];unknownheavy=[r['index'] for r in table if not r['complete_cohort_match'] and r['pure_heavy_antighost_projection']]
 controls={'drop_positive_coefficient_dimensions_breaks_orbit_cost_positivity':any(r[6]>0 and r[5]==0 for r in costs),'inflate_cost1_vertex_to_g5_breaks_test':any(r[7]==1 and 5>r[7] for r in costs),'omit_dimensionful_profiles_changes_antighost_frontier':bool(positive),'promote_unbroken_node_to_all_heavy_is_detected':any(r['pure_heavy_antighost_projection'] for r in table) and all(any(n.partition('__')[0].startswith('bar') for n in r['word']) for r in N4)};assert all(v for k,v in controls.items() if k!='omit_dimensionful_profiles_changes_antighost_frontier' or positive)
 qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
 result={'schema':'FINITE_ANTIGHOST_UV_FRONTIER_V1','route':role,'scientific_disposition':'FINITE_G_LE4_BOUND_AND_PRECISE_REMAINING_ANTIGHOST_COHORTS' if bound4 and sourcecheck else 'PROPOSED_BOUND_NOT_QUALIFIED_EXACT_COST_OR_SOURCE_COUNTEREXAMPLES_RETAINED','all16_ordinary_vertex_two_port_costs':costs,'ordinary_cost_violations':badports,'actual_B_C_root_budget':rootinfo,'ordinary_budget_knapsack_0through4':best,'derived_broken_root_coupling_upper_bound':derived,'ordinary_sourcefree_upper_bound':ordinary_bound,'all33_formal_local_UV_insertions_have_g_at_most4':bound4,'source_channel_maximum_combined_g':source_bound,'possible_g5_source_channels':g5,'V1_source_channels':v1,'source_g4_channels':s4,'independent_source_channel_bound_at_most4':sourcecheck,'Weyl_D_D2_heat_background_vertex_costs':background,'explicit_reference_class_only_no_arbitrary_added_covariantization':True,'all_antighost_profile_scope_classification':table,'target_class_summary':summary,'new_legacy_complete_cohort_matches':dict(sorted(newcohorts.items())),'positive_dimension_antighost_profile_indices':positive,'scalar_reference_mass_expansion_antighost_indices':mass,'unreconciled_pure_heavy_profile_indices':unknownheavy,'unbroken_projection_is_aggregate_not_family_measurement':True,'current_unbroken_g4_node_positions':len(N4),'no_new_pole_or_greater_order_completion_claim':True,'bare_catalogue_not_full_offflat_reference_heat_coefficient_coverage':True,'controls':controls,'insensitive_control_if_mass_list_empty':'No scalar-reference expansion antighost profile exists in this catalogue if list is empty;mass-expansion omission is then not a sensitive antighost control','all_seven_quantum_flags_false':flags,'source_functional_input_benchmark_scheme_authority_changed':False,'full_QAP_measure_IR_contacts_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual catalogue,local action grading,earlier root/source/unbroken proofs and legacy measured family scopes,software/AI author shared;coverage matching not fresh integration or independent scientific validation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
