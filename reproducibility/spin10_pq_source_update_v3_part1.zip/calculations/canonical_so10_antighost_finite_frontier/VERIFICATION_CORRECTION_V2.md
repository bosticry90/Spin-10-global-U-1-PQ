# Verifier continuation V2

The first independent verifier reached its final target-class comparison and
failed. The expected family tuples were compared with JSON family lists
inside dictionaries; its recursive tuple helper did not descend into dicts.
The complete failed source, source copy, frozen manifest and captures remain.
No validation receipt was created and the failed run is not accepted.

V2 compares complete JSON-normalized summaries, retaining every class, family,
index, dimension, match and projection field. No mathematical requirement or
native output changes. A changed count or family still fails the comparison.
Both successful native runs are reused; no new physics calculation is added.
The corrected verifier is another 120-second/8-GiB/minimum350-MiB bounded run.

The V1 manifest also omitted external imported helper source files. V2 freezes
all custom modules reachable from its imported ordinary-polynomial helpers,
including their transitive custom modules. Their current bytes are additional
explicit shared dependencies, not independently reproduced physics. V1 is
unqualified for both the failed comparison and this provenance omission.
One failed verifier is preserved separately from the one prelaunch preparation/
controller event. The native scientific failure count remains zero.
