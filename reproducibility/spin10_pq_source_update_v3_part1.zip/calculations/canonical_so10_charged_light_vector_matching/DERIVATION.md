# CLM1 ordered integration and opened scalar-loop closure

Reuse SCM1's qualified equal-mass reduction rather than rerun its177units.
In its notation K0=diag(c1+3c2+8c3),K5=0,K6=diag(2c2),K7=diag(3c3).
The actual unbroken action is an irrep matrix tensored with the multiplicity
identity. Thus its current commutes with the full scalar mass operator,
including H mixing. Orthogonal scalar spectral projectors force equal
scalar eigenvalues on both legs. The vector charge remains nonzero for
SU2/SU3. This is not the neutral-vector specialization of a charged kernel.

Set the scalar squared masses to m>0 and the vector to delta>0. Work first
in dimensionless units m=1,d=delta/m,with jm=log(Q²/m). The original CCK
charge polynomials satisfy P2*U²=sum c(D)s^i t^j u^k,i+j+k=5,
beta=4-eps,U=st+(s+t)u. u integration at delta=0 gives

```
(st)^(k+1-beta)/(s+t)^(k+1)
*Gamma(k+1)Gamma(beta-k-1)/Gamma(beta).
```

The change s+t=a,s/(s+t)=v supplies Gamma(2eps) from a and an Euler beta
factor from v. The resulting formula is in RECORD.md. Independent index
shifts yield convergent Euler integrals before meromorphic continuation.
No isolated scaleless integral or unregulated convergence strip is asserted.
Integer recurrences factor exp(2gamma eps)Gamma(1+eps)^2; its linear term
vanishes and quadratic term is zeta2. Retain full D=4-2eps coefficients.

For the vector-soft region expand only st/[(s+t)u]. The retained n terms
have p=3+n-k<=0 and contribute d^(p-eps),with the two Gamma factors
Gamma(k-3-n+eps),Gamma(i+j+n-2+eps). Every next p is at least1 and Gamma
poles are at most double,so the omitted Laurent terms vanish as positive
powers times log^n(d),n<=2. Scalar positive masses exclude a separate
unsuppressed soft-scalar region in this unit. The individual soft scalar-
charge coefficients cancel collectively;they are not zero by term deletion.

## Actual opened heavy scalar loop

Let Bm=exp(gamma eps)Gamma(eps)(Q²/m)^eps and
Hdelta=exp(gamma eps)Gamma(1+eps)(Q²/delta)^eps. Integration by parts in
the actual two-current scalar bubble gives its mass moment A_m/m=Bm/(eps-1).
Its kinetic moment at zero vector momentum is Bm: the Feynman-parameter
q²delta and q_mu q_nu integrals have coefficients-1/3 and+1/3. This follows
from int k_mu k_nu/(k²+m)²=delta_mu_nu A_m/2 and
int_0^1 alpha(1-alpha)=1/6,int_0^1(1-2alpha)^2=1/3. Keep the actual
Wick/color normalization of CCK. Full scalar determinant covariance fixes
the kinetic/curvature companions;the excluded scalar seagull is a mass
operator through dimension4. Higher local background terms are suppressed
in this light-vector soft closure and retain the existing C1 identity-contact
convention,not a universal Tr1zero assertion.

The CCK vector forest,derived there from the actual self-energy and its
Lorentz heat contraction,has prefactor

```
Fvector(eps,d)=Fmass(eps)/d-Fkin(eps),
Fmass=(20+2eps)/3,Fkin=(21+2eps)/18.
```

Opened bubble plus light-vector heat therefore gives the independently
defined soft closure

```
Sbare=Bm Hdelta [Fmass/(d(eps-1))+Fkin],
Sct=Hdelta/eps [Fmass/d-Fkin].
```

This must agree with the summed soft heat expansion;it is a test,not a
choice of its coefficient. In the exact calculation their poles cancel,
and the finite remainder is

```
Sren=-(20/(3d))(jm+1)+(7/6)jm.
```

It is nonzero and power-sensitive. It is the one-soft matching term of
this current family,not a new adopted vector mass parameter. Its parent
must still be coordinated with seagull/other families in complete matching.
Scalar proper forests tend to pole-1/2 and finite-jm/2 per charge axis.
The vector forest is the same operator in full and soft closures and
cancels once before delta is removed. Thus the matched hard kernel is
Bhard+Cscalar,not Bhard+another copy of the vector forest.

The measured unit result,subject to the separate validation receipt,is

| Charge axis | Overall pole | Finite at jm=0 | Coefficient of jm |
| --- | ---: | ---: | ---: |
| left scalar | -1 | 2/3 | -3/2 |
| right scalar | -1 | 2/3 | -3/2 |
| vector | -1/3 | 13/18 | -2/3 |

The scalar sum recovers qualified SLI1. That does not determine the new
vector13/18. Common scale and exact-once parent-minus-family forests remain
necessary;overall poles are retained. This is not a complete r0 spectral
result,full finite C1,or physical unification conclusion.
