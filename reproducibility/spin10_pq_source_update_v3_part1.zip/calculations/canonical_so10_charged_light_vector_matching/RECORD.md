# CLM1: charged light-vector scalar-current matching kernel

Base1eb24da4d38f9016d3458d3d230008c6d3827548/main. Previous goal turn
PROGRESS: complete R1C1 qualified/committed. Whole Spin(10)xPQ ACTIVE/incomplete.
Preflight clean,no live workers,state113/34of39 unchanged. This increment
asks for the complete three-charge VSS unit kernel with two equal positive
scalar squared masses m>0 and a light vector carrying common positive
auxiliary squared mass delta>0 before full/EFT subtraction. d=delta/m->0,
D=4-2eps,jm=log(Q²/m). Same action,xi1 C1 reference,heat normalization,
real Wick factors and graph-local proper forests;no physical scheme change.

Why this test: r1/r2/r3/r4 are complete,but r0 SU2/SU3 is missing. Existing
SCM1 primary/replay/verifier already prove K0=diag(c1+3c2+8c3),K5=0,
K6=diag(2c2),K7=diag(3c3) on all177units and actual irrep/multiplicity
action. Reuse this qualified reduction;don't rederive a large spectrum.
It forces equal scalar masses,while vector-charge maps remain nonzero.
SCM1's completed U1 branch only tests the zero-vector-charge projection.
Naively setting vector mass z=0 in CCK positive formulas is unqualified.

Freeze actual28degree5 MSM heat monomials and authenticate P2*U² against
CCK independently,with U=st+su+tu and beta=4-eps. Scope is the whole
equal-positive-scalar/light-vector unit,all three charge axes,not a pilot
or a favorable subgroup. Use existing full-EFT graph difference at shared
positive IR mass and actual opened heavy-scalar-loop Taylor terms. No
missing soft coefficient inferred from a desired finite answer or pole.

Proposed primary method: integrate u first at delta=0,then s+t and s/(s+t).
For monomial s^i t^j u^k, i+j+k=5,the meromorphic hard integral is
m^(-2eps)Gamma(2eps)Gamma(k+1)Gamma(beta-k-1)
Gamma(i+k+2-beta)Gamma(j+k+2-beta)
/[Gamma(beta)Gamma(i+j+2k+4-2beta)]. Independent analytic index shifts
justify a convergence domain before continuation;no isolated massless
integral is called zero. Keep D dependence through poles.

Derive the actual vector-soft Taylor contribution by expanding
(1+st/[(s+t)u])^(-beta). For n>=0,its power is d^(p-eps),p=3+n-k,
with coefficient(-1)^n(beta)_n/n! times
Gamma(k-3-n+eps)Gamma(i+j+n-2+eps)
Gamma(i+n+1)Gamma(j+n+1)/Gamma(i+j+2n+2).
Retain every p<=0 term;prove excluded powers are positive with bounded
Gamma pole order. This is a complete asymptotic census,not a guessed
one-soft constant. Distinguish this momentum region from mass-type support.

Coordinate the actual CCK forests at x=y=1,z=d,Q²/m=exp(jm),including
their epsilon-dependent finite terms and log d. Check whether the full
vector forest is exactly the counterterm of the derived soft vector loop.
Only if that equality is established may it cancel once in
(Bfull+Cscalar+Cvector)-(Ssoft+Cvector_soft).
The remaining scalar forests must be retained. Keep all overall poles.
If additional unsuppressed terms or mismatched forests occur,preserve
them and report incomplete matching or underdefinition;don't force a result.

Independent normalization test: direct uncombined Gamma Cauchy at110digits,
48/80nodes radius1/32 and80nodes radius1/64,changes<1e-40 andimaginary<1e-80.
Replay old positive CCK dilog master/direct derivatives at FIXED240digits,
d1e-44/1e-50/1e-56 with actual full proper forests and derived soft subtraction.
Compare all pole/finite/scale axes,requiring matched convergence/agreement
<1e-35. Do not select coefficients from the new hard table in either numeric
route. Preserve native huge values and form matched values before display.
Use propagated display ulps for reconstruction,not a weakened matching gate.

Separate verifier checks independent Gamma recurrence,all28monomials,scalar
exchange,complete soft census/forest equality,numeric histories and common
scale jm0,2/7. Scalar neutral sum must reproduce qualified SLI1 but cannot
determine the vector coefficient. Controls: omitted soft contribution,
improper vector-forest subtraction/finite epsilon term,early D4 and any
actual subleading soft Taylor omission. Disclose insensitive projections.

Before initial calculation freeze source copies and transitive R1 ancestry.
Caps300seconds exact,600 per numeric/verifier,240 replay digits,8GiB sampled
private memory,350MiB launchfloor,4MiB new package. No silent cap increase,
partial-cache resume,failed-evidence editing or premature cancellation.
Possible outcomes: complete kernel;disagreement requiring diagnosis;
underdefined matching;resource inconclusive. Only a full correctly matched
unit kernel qualifies CLM1;model r0 spectral sums are a subsequent dependency.

No overall counterterm,physical g/scale/point,Higgs finite normalization or
tadpole scheme is chosen. OSF common finite-Higgs treatment and HTB bridge
remain separate. Bfamily+Cparent=Rprime_family+(Cparent-Cfamily),exact once.
No old subtotal/source polynomial modified. FullC1,E5/A5 unqualified,
HB1/C5blocked,flavorhumanpaused,quartetFAIL,custodyexit2/seven NOTPASS retained.
Scientific acceptance NOT_PERFORMED;no protected activation,push/publication,
outreach,branch/worktree. Shared action,numerator,IR/master/reference/software
and AI authorship limit independence;no Lean/external scientist/empirical proof.
TrackB evaluates structural reuse and a new genuine light-charge region.
Two initial source lookups used nonexistent filenames and failed read-only;
the actual file inventory was then recovered. No scientific worker had run.
