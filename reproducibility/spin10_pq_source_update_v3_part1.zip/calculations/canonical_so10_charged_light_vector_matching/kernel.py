"""CLM1 ordered hard integral and complete light-vector soft Taylor census."""
from data import *

def gm(n):
    return s.prod(v-eps for v in range(1,n)) if n>=1 else 1/s.prod(v-eps for v in range(n,1))
def gp(n):
    return s.prod(v+eps for v in range(1,n)) if n>=1 else 1/s.prod(v+eps for v in range(n,1))
def jets(ratio,logscale=0):
    regular=clean(eps**2*ratio);assert s.denom(regular).subs(eps,0)!=0
    vv=[clean(s.diff(regular,eps,n).subs(eps,0)/s.factorial(n)) for n in range(3)]
    # exp(2gamma eps)Gamma(1+eps)^2=1+zeta2 eps²+O(eps³).
    return [vv[0],clean(vv[1]+logscale*vv[0]),clean(vv[2]+logscale*vv[1]+(logscale**2/2+s.zeta(2))*vv[0])]

def main():
    start=begin('preparation.json',300);heat,cck,neutral=inputs();U=st*tt+st*ut+tt*ut;beta=4-eps
    families={};census={};hh=heat['hard_heat_terms'];assert {k:len(v) for k,v in hh.items()}=={'left':10,'right':10,'vector':8}
    for fam,rows in hh.items():
        polynomial=sum(expr(r['coefficient_D'])*st**r['powers'][0]*tt**r['powers'][1]*ut**r['powers'][2] for r in rows)
        assert clean(polynomial-expr(cck['kernels'][fam]['P2'])*U**2)==0
        hard=0;soft={};records=[]
        for row in rows:
            i,j,k=row['powers'];assert i+j+k==5 and min(i,j,k)>=0
            co=expr(row['coefficient_D']).subs(D,4-2*eps)
            hard+=co*s.factorial(k)*gm(3-k)*gp(3-i)*gp(3-j)/(gm(4)*s.prod(v+2*eps for v in range(k+1)))
            rr=[]
            for n in range(max(k-3+1,0)):
                p=3+n-k
                value=co*(-1)**n*s.rf(beta,n)/s.factorial(n)*gp(k-3-n)*gp(i+j+n-2)
                value*=s.factorial(i+n)*s.factorial(j+n)/s.factorial(i+j+2*n+1)
                soft[p]=soft.get(p,0)+value;rr.append({'n':n,'power':p})
            records.append({'powers':[i,j,k],'retained_soft':rr,'next_soft_power':3+max(k-2,0)-k})
        hard=clean(hard);soft={p:clean(v) for p,v in soft.items()}
        bare=jets(hard,2*jm)
        sj=[s.S.Zero]*3
        for p,R in soft.items():
            vv=jets(R,2*jm-s.log(d));sj=[clean(a+d**p*b) for a,b in zip(sj,vv)]
        forest=cck['kernels'][fam]['forest'];cp=clean(expr(forest['pole']).subs({x:1,y:1,z:d}));cf=clean(expr(forest['finite_Q1']).subs({x:1,y:1,z:d})+cp*jm)
        if fam=='vector':
            hard_ct=[0,0,0];soft_ct=[0,cp,cf]
        else:
            hard_cp=clean(cp.subs(d,0));hard_ct=[0,hard_cp,hard_cp*jm];soft_ct=[0,0,0]
        sren=[clean(a+b) for a,b in zip(sj,soft_ct)]
        matched=[clean(a+b) for a,b in zip(bare,hard_ct)]
        families[fam]={'hard_Gamma_ratio':str(hard),'hard_bare_Laurent':list(map(str,bare)),
          'soft_Gamma_ratios_by_power':{str(p):str(v) for p,v in soft.items()},'soft_bare_Laurent':list(map(str,sj)),
          'full_forest_pole':str(cp),'full_forest_finite':str(cf),'soft_forest_Laurent':list(map(str,soft_ct)),
          'soft_Rprime_Laurent':list(map(str,sren)),'remaining_hard_forest_Laurent':list(map(str,hard_ct)),
          'matched_Laurent':list(map(str,matched))}
        census[fam]=records;print('STAGE hard_and_soft_'+fam,flush=True)
    save('primary','kernel',{'schema':'CLM1_EXACT_KERNEL','families':families,'heat_region_census':census,
      'Gamma_common_factor':'exp(2EulerGamma eps)Gamma(1+eps)^2','complete_model_r0':False,
      'scientific_acceptance':'NOT_PERFORMED','full_C1_or_E5_qualified':False,'overall_counterterm_adopted':False},start)
if __name__=='__main__':main()
