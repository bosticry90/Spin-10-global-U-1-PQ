"""CLM1 uncombined Gamma sampling vs old-master light-mass matching."""
from data import *

def primary(start):
    mp.mp.dps=110;heat,_,_=inputs();functions={}
    for fam,rows in heat['hard_heat_terms'].items():
        functions[fam]=[(tuple(v['powers']),s.lambdify(D,expr(v['coefficient_D']),modules='mpmath')) for v in rows]
    history=[];previous=None;maximum=mp.mpf(0);leak=mp.mpf(0)
    softpowers={fam:sorted({3+n-k for (i,j,k),co in rows for n in range(max(k-2,0))}) for fam,rows in functions.items()}
    for nodes,radius in [(48,mp.mpf(1)/32),(80,mp.mpf(1)/32),(80,mp.mpf(1)/64)]:
        out={fam:{'hard':[mp.mpc(0)]*3,**{str(p):[mp.mpc(0)]*3 for p in softpowers[fam]}} for fam in functions}
        for node in range(nodes):
            ee=radius*mp.exp(2j*mp.pi*node/nodes);beta=4-ee;common=mp.exp(2*mp.euler*ee)
            for fam,rows in functions.items():
                vals={key:mp.mpc(0) for key in out[fam]}
                for (i,j,k),co in rows:
                    c=co(4-2*ee)
                    vals['hard']+=c*common*mp.gamma(2*ee)*mp.gamma(k+1)*mp.gamma(beta-k-1)*mp.gamma(i+k+2-beta)*mp.gamma(j+k+2-beta)/(mp.gamma(beta)*mp.gamma(i+j+2*k+4-2*beta))
                    for n in range(max(k-2,0)):
                        p=3+n-k
                        vals[str(p)]+=c*common*(-1)**n*mp.rf(beta,n)/mp.factorial(n)*mp.gamma(k-3-n+ee)*mp.gamma(i+j+n-2+ee)*mp.gamma(i+n+1)*mp.gamma(j+n+1)/mp.gamma(i+j+2*n+2)
                for key,value in vals.items():
                    regular=ee**2*value
                    for axis in range(3):out[fam][key][axis]+=regular/(ee**axis*nodes)
        leak=max(leak,max(abs(mp.im(v)) for f in out.values() for row in f.values() for v in row));assert leak<mp.mpf('1e-80')
        if previous is not None:
            change=max(abs(v-w)/(1+abs(v)) for fam in out for key in out[fam] for v,w in zip(out[fam][key],previous[fam][key]));assert change<mp.mpf('1e-40');maximum=max(maximum,change)
        history.append({'nodes':nodes,'radius':mp.nstr(radius,40),'Laurent':{f:{k:[mp.nstr(mp.re(v),80) for v in row] for k,row in layers.items()} for f,layers in out.items()}})
        previous=out;print('STAGE Gamma_all_regions_'+str(nodes)+'_'+str(radius),flush=True)
    save('primary','numeric',{'schema':'CLM1_UNCOMBINED_GAMMA_NUMERIC','history':history,'working_digits':110,
      'max_scaled_change':mp.nstr(maximum,40),'max_imaginary':mp.nstr(leak,40),'new_hard_target_read':False},start)

def replay(start):
    mp.mp.dps=240;old=load('clm_old_cck',CAL/'canonical_so10_charged_current_kernel/data.py');_,cck,_=inputs()
    forests={fam:cck['kernels'][fam]['forest'] for fam in ['left','right','vector']}
    F=expr(forests['vector']['prefactor_H']).subs({x:1,y:1,z:d,s.Symbol('Hz'):1})
    mass=clean(s.limit(d*F,d,0));kin=clean(mass/d-F)
    # Opened actual heavy scalar bubble A_m/m=Bm/(eps-1),kinetic=Bm.
    pref=clean(mass/(d*(eps-1))+kin)
    sb0=clean(pref.subs(eps,0));sb1=clean(s.diff(pref,eps).subs(eps,0))
    cp=expr(forests['vector']['pole']).subs({x:1,y:1,z:d})
    cf=expr(forests['vector']['finite_Q1']).subs({x:1,y:1,z:d})
    sr=clean(sb1+sb0*(2*jm-s.log(d))+cf+cp*jm);assert clean(sb0+cp)==0
    soft=s.lambdify([d,jm],sr,modules='mpmath');softscale=s.lambdify(d,s.diff(sr,jm),modules='mpmath')
    funcs={f:(s.lambdify(d,expr(v['pole']).subs({x:1,y:1,z:d}),modules='mpmath'),s.lambdify(d,expr(v['finite_Q1']).subs({x:1,y:1,z:d}),modules='mpmath')) for f,v in forests.items()}
    history=[];previous=None;change=mp.mpf(0)
    for ds in ['1e-44','1e-50','1e-56']:
        dv=mp.mpf(ds);native={};matched={};bare_all={}
        for fam in ['left','right','vector']:
            bare=old.evaluate_formula(fam,[1,1,dv]);pfunc,ffunc=funcs[fam];pp=pfunc(dv);ff=ffunc(dv)
            values=[bare[1]+pp,bare[2]+ff,2*bare[1]+pp];native[fam]=values[:];bare_all[fam]=bare[:]
            if fam=='vector':values[1]-=soft(dv,0);values[2]-=softscale(dv)
            matched[fam]=values
        if previous is not None:
            change=max(abs(v-w)/(1+abs(v)) for fam in matched for v,w in zip(matched[fam],previous[fam]));assert change<mp.mpf('1e-35')
        history.append({'d':ds,'bare':{f:[mp.nstr(v,120) for v in vals] for f,vals in bare_all.items()},
          'native_Rprime':{f:[mp.nstr(v,120) for v in vals] for f,vals in native.items()},'matched':{f:[mp.nstr(v,80) for v in vals] for f,vals in matched.items()}})
        previous=matched;print('STAGE old_master_light_vector_'+ds,flush=True)
    save('replay','numeric',{'schema':'CLM1_OLD_MASTER_MATCHED_LIGHT_VECTOR','history':history,'working_digits':240,
      'last_scaled_change':mp.nstr(change,40),'opened_scalar_soft_Rprime':str(sr),'mass_heat_coefficient':str(mass),'kinetic_heat_coefficient':str(kin),'new_hard_target_read':False},start)

def main():
    role=sys.argv[1];start=begin('numeric_preparation.json',600)
    for p,h in json.loads((HERE/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    (primary if role=='primary' else replay)(start)
if __name__=='__main__':main()
