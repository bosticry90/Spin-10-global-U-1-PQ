# CLM1 independent numeric continuation

Exact4.99268s calculation completed without a failure. All28monomials are
authenticated. The vector soft powers are-1 and0;scalar soft sums vanish
identically. Before qualification verify both rational hard and soft Gamma
reductions independently. No source or requirement is changed after output.

Primary110digits samples UNCOMBINED hard/soft Gamma functions from the old
heat monomials,without reading new exact hard coefficients.48/80nodes at
rho1/32 and80rho1/64;scaled changes<1e-40,imaginary leakage<1e-80. Report80digits.
Replay FIXED240digits uses old CCK dilog master/direct mass derivatives at
x=y=1,z=d1e-44/1e-50/1e-56,actual full old CCK forests at common jm,then
subtracts opened-loop Sbare+Sct. Derive that soft expression from the old
forest's mass/kinetic coefficients and A_m/m=Bm/(eps-1),not the new hard
target. Require last changes<1e-35. Form matched values at240digits before
reporting;native120digits,matched80. Later comparison tolerance1e-35.

Each worker retains600s/8GiBsampled/350MiBfloor/4MiBpackage;no silent extension.
The finite vector13/18 is a prospective measured result,not an input to either
numeric worker. Explicit source copies/preparations precede execution.
Separate verifier checks all native stages,soft pole cancellation,exact-once
forests and common scale jm0,2/7. Preserve meaningful earlyD4,omitted soft,
vector forest epsilon and subleading-Taylor controls with their sensitivities.
Scientific acceptance NOT_PERFORMED;authority34/39,fullC1/E5 unchanged.
