# CLM1: charged light-vector scalar-current kernel

Qualified in the frozen xi1 C1 reference and common-IR graph-matching domain.
Scientific acceptance NOT_PERFORMED;state113/authority34of39 unchanged.
Final receipt SHA256 c0b9d1f59ff1199f7909474dbeae4896ce17a17ca3af6121bfdf1a49c5e9ae57.

Two equal positive scalar squared masses m and vector delta>0 are retained
before full/EFT subtraction. For d=delta/m->0,jm=log(Q²/m),the result is:

| Charge | Overall pole | Finite at jm=0 | Coefficient of jm |
| --- | ---: | ---: | ---: |
| left | -1 | 2/3 | -3/2 |
| right | -1 | 2/3 | -3/2 |
| vector | -1/3 | 13/18 | -2/3 |

The vector13/18 is independently measured,not transferred from the neutral
or two-soft-vector19/18 result. Overall poles remain;no physical finite or
vector mass counterterm is adopted. The complete r0 model sum is a separate
dependency. SCM1 already proves its equal-scalar-mass reduction on177units.
Reusing that result avoided a redundant spectrum expansion.

Ordered beta/Gamma integrals of all28 actual P2 monomials give the hard part.
The u-soft Taylor census retains every d^p with p<=0. Scalar soft sums
cancel collectively;the vector powers are-1 and0. The next powers start1
and Gamma poles are at most double. No isolated massless logarithm is zeroed.
DERIVATION.md specifies the analytic-index continuation and actual opened
heavy-scalar bubble: A_m/m=Bm/(eps-1),kinetic=Bm. Its contraction with the
light-vector heat matches the soft expansion exactly,including curvature,
longitudinal and epsilon terms inherited from the full CCK normalization.

The renormalized one-soft term is Sren=-(20/(3d))(jm+1)+(7/6)jm.
It is nonzero and power-sensitive. Its UV pole cancels the actual vector
forest before delta removal. Thus the matched hard term has scalar forests
but the vector forest cancels between full and soft contributions. It is
not omitted from the full-family counterterm ledger: Cfamily=Cscalar+Cvector
and Csoft=Cvector. Preserve Bfull+Cparent-Sbare-Csoft=
Rprime_matched+(Cparent-Cfamily). Subtract the whole included Cfamily once,
even though only scalar forests survive in the hard representation.
Other scalar/vector/seagull parent contributions and one-loop matching
insertions remain necessary;this does not adopt a physical vector mass.

Primary numeric sampling uses uncombined Gamma factors at110digits with
48/80nodes,rho1/32 then80rho1/64. Replay uses old positive CCK dilog master
and direct derivatives at FIXED240digits,x=y=1,z=d1e-44/1e-50/1e-56,
actual old forests and independently reopened scalar-loop soft subtraction.
Neither numeric route reads the new hard coefficients for selection. Native
120digit values and matched80digit values are retained;subtraction is formed
at240digits before display. All axes and jm0,2/7 are independently checked.

max_scaled_Gamma_error: 1.34880871833059802034376e-58.
max_scaled_old_master_error: 4.09754976366952040387166496024448100536e-43.
max_scaled_combined_scale_error: 5.519778528016662082134933600329109045754e-43.
max_native_reconstruction_error: 2.500000000026163371444689504717138483761e-64.

Controls use actual coefficients. Dropping Sren changes finite terms by
-8.5714285714e56 atd1e-56,jm2/7,but cannot change poles. Omitting subleading
soft Taylor terms leaves a nonzero double-pole error-40/9 in the vector
closure. EarlyD4 changes scalar pole-7/36/vector+1/36 and finite terms.
A one-sided missing forest-epsilon term changes finite values by
-(6-d)/(9d);the same omission on both sides cancels in the matched hard
kernel and is explicitly insensitive there. Duplicating the vector forest
adds its nonzero pole(40-7d)/(6d). Common Gamma-zeta control is insensitive
because full hard double poles vanish. The scalar neutral sum recovers
qualified SLI1 but does not determine the vector coefficient.

Commands python -B calculations/canonical_so10_charged_light_vector_matching/
prepare.py;run.py;run_numeric.py;run_validation.py. Do not rerun exclusive
completed output paths. Sources and3,048 ancestry bindings were frozen.
No failed scientific/controller/verifier runs,timeouts,cancellations or
truncation. Three initial read-only source lookups used nonexistent names;
actual rg file inventory was recovered. No old evidence was edited.

| Worker | Seconds after imports | Max sampled private bytes |
| --- | ---: | ---: |
| primary_kernel | 4.992680299968924 | 52305920 |
| primary_numeric | 20.27370100002736 | 48717824 |
| replay_numeric | 126.19359859998804 | 61480960 |
| validation | 3.1970843999879435 | 52764672 |

Caps300seconds exact,600 numeric/verifier,8GiBsampled,350MiB launchfloor,
4MiBpackage. Memory is sampled,not a continuous peak. Shared action,
numerator,reference/IR/matching/master conventions,software and AI authorship
limit independence. No Lean,external scientist or empirical confirmation.
TrackB demonstrates structural reuse and correct retention of a genuine
power-sensitive soft term,not agreement of independently validated physics.

| Table | Raw SHA256 | Gzip SHA256 |
| --- | --- | --- |
| primary_kernel | fd2417d3e60d017a20ee7018bce1ae3f652012c1f9c2a60f90b2ebfeac27fc31 | bd50600cc3d271e5834081a0798a84e5571895782f3911760ebd0a4cb4e92f7f |
| primary_numeric | 47c823c5dabdcee896b26aa5d3a30cf30c210791ddf902c9d4e33ac46ba95354 | d20b92c53496e5820c4d4fca168f2a4fa4a9ca92f68fe49f365745f398ea98f9 |
| replay_numeric | 1bd830b7da61e7427ed22084744f4aed2bd74183e700421a4d0f9e0d9c2893ca | 22caeb4d3d05b5dc0bace65ef774c3cbdcf423abf464ad9d8d2a081357b99e3c |

Before local commit e4 must retain six expected exits,custody2/seven NOTPASS,
and raw/index/HEAD seals must preserve all26,312 prior Git blobs/state bytes.
This authenticates historical evidence;it is not new-science replay or director
acceptance. FullC1/E5/A5 unqualified,HB1/C5 blocked,flavor humanpaused,quartet
failure and physical scalar/gauge/Yukawa limitations remain. No branch,
worktree,publication,push or protected activation. Whole goal ACTIVE/incomplete.
