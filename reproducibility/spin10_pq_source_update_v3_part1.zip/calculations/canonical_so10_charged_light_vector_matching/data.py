"""CLM1 fixed-domain exact and high-precision kernel helpers."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
eps,D,d,jm=s.symbols('eps D d jm',real=True)
st,tt,ut=s.symbols('s t u',positive=True)
x,y,z=s.symbols('x y z',positive=True)
LOC={str(v):v for v in [eps,D,d,jm,st,tt,ut,x,y,z]}
def expr(v):return s.sympify(v,locals=LOC)
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep,seconds):
    start=time.perf_counter();w=threading.Timer(seconds,lambda:os._exit(124));w.daemon=True;w.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,kind,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_{kind}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'schema':'CLM1_'+kind.upper(),'role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def inputs():
    heat=packed(CAL/'canonical_so10_mixed_scalar_soft_matching/primary_kernel_tables.json.gz')
    cck=packed(CAL/'canonical_so10_charged_current_kernel/primary_kernel_tables.json.gz')
    neutral=packed(CAL/'canonical_so10_neutral_current_matching/primary_kernel_tables.json.gz')
    return heat,cck,neutral
