# Next: complete r0 model sum in all three ideals

Use this qualified CLM1 kernel with existing SCM1 exact equal-mass reduction,
all35SMclasses/177units/328scalars. No new spectrum tensor is needed. Per
class with dimension d_alpha,scalar Casimir averages c_i and
cH=c1+3c2+8c3,the one-endpoint weights are(3/2)d_alpha cH c_i;the vector
weights are(3/2)d_alpha(0,2c2,3c3). Keep full physical H mixing through a
spectral log trace,all positive Gold masses and soft projectors. Prove/use
the existing actual unbroken current/multiplicity action,not just labels.

With equal scalar masses,combine the two endpoint units only after their
actual equal weights are established. Keep the vector13/18 and its scale
coefficient-2/3. Positive-carrier sums use physical logdet plus exact Gold
mass logs;primary eigenvalues,replay Cholesky and a separate direct determinant
check can avoid individual mass-pair integration. Soft/positive pairs vanish
through actual orthogonal projectors and the proved current action. All-soft
full/EFT graph-local vertices,metric,propagators and forests must agree at
the SAME positive auxiliary mass in every gauge ideal before subtraction;
non-Abelian vector-charge soft weights are not zero.

Reproduce the previously qualified full U1 branch byte-authenticated but not
double counted. Full r0 would complete VSS primitives across all five vector
mass sets,in the declared reference/graph-matching scope. It would not complete
full finite C1,physical gauge matching or E5/A5. All remaining primitives,
parent-minus-full-family forests,overall counterterms,finite normalizations,
matching insertions and nonlinear conversion still require reconciliation.
Do not add independent j_r=0 columns without common scale conversion.
