"""Freeze CLM1 exact kernel with complete qualified threshold ancestry."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='1eb24da4d38f9016d3458d3d230008c6d3827548'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/charged-light-vector-matching-v1-2026-10-20')
def dump(p,b):
    with p.open('xb') as f:f.write(b)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
parent=ROOT/'calculations/canonical_so10_r1_scalar_current';deps={};checked={}
for prep in sorted(parent.glob('*preparation*.json')):
    deps[str(prep)]=sha256(prep.read_bytes()).hexdigest()
    for n,h in json.loads(prep.read_bytes())['input_sha256'].items():
        if n not in checked:checked[n]=sha256(Path(n).read_bytes()).hexdigest()
        assert checked[n]==h,n
        if n in deps:assert deps[n]==h,n
        deps[n]=h
for p in sorted(parent.iterdir()):
    if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
assert sha256((parent/'validation_receipt_v2.json').read_bytes()).hexdigest()=='c9c5223134d528da9015efdf8f33f2c2b956e379283d980fb739256e2639a5fc'
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V417.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:
    p=ROOT/n;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['RECORD.md','data.py','kernel.py','prepare.py','run.py']:
    p=HERE/n;raw=p.read_bytes()
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    q=HERE/(n+'.source.txt');dump(q,raw);deps[str(p)]=deps[str(q)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==26312
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'CLM1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),'exact_seconds':300,
 'numeric_seconds':600,'replay_working_digits':240,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':4*1024**2,
 'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;26312oldblobs;no science executed')
