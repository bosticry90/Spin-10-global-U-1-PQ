# A common extension for actual insertion descendants

This is a bounded formal one-loop Euclidean comparison at pure scalar means
and J=0 AFTER source differentiation. It does not assume full quantum Slavnov
restoration. Keep local insertion probes and independent nonexceptional momenta.

Split the existing K into Ktree+Kaux. Source-left differentiation gives

 Kaux=-sum_i JL_i X_i,   Caux=QKaux,
 QKaux=-sum_i (QJL_i)X_i+sum_i JL_i QX_i.

On scalar means,the sourcefree QJL_i is M_i,s*x_s. All first derivatives of
Kaux vanish there,but the quantum primitive has a required source coefficient

 I_Kaux^(1)(x)=-sum_i JL_i(x) integral dy [T_i,r K_heat(x-y)/2] x_r(y).

Here T contains the actual g4*xi2 factor and the inherited hbar bookkeeping is
suppressed. The Hessian of Caux on these means is independently
-sum_i M_i,s*x_s H_Xi. Therefore its bubble coefficient is

 L_s,r=-sum_i M_i,s T_i,r.

It must also be computed from the actual QKaux density and actual GF Y vertex,
not defined by this equality. The quantum linearized Slavnov expression has
one-loop part Q I_Kaux^(1)+(Gamma1,Kaux). The second term vanishes because every
first derivative of Kaux vanishes on this projection. The first term keeps
QJL_i=M_i,s*x_s,so it has exactly the independently calculated matrix L.
This checks a selected insertion compatibility equation,not every regulator
breaking that could enter a full renormalized QAP.

For the actual marked operator Dminus=delta_a-V_J partial_left_J,

 Dminus I_Kaux^(1)|J0=+sum_i V_JL_i I_Xi^(1).

Every V_JL_i is an actual constant coefficient times one eps marker,with no
integrated field dependence. Direct DminusKaux and its bubble define
W_a,r independently. Their comparison is W_a,r=sum_i V_i,a T_i,r.
Source differentiation MUST precede J=0. Reversing the source orientation
changes this kernel;the older384 scalar projection could not detect that sign.

The same calculation tests the retained fixed-source special-shear equation.
Every Kaux source flow contains JL,so I_source,aux=0 on the stated projection.
The complete Ktree density obeys Ctree+XJtree R=0;linearity cancels those paired
insertions without rerunning identical loops. The reference regulator response
X R_t has two odd fields and one B/Lambda field,with no scalar. Its second
variation is zero on pure scalar means,so its one-loop insertion vanishes before
any inverse-heat manipulation. The special formal heat-Jacobian is the previously
qualified zero. Thus the only nonzero scalar-pair pieces in this complete
selected shear coefficient are I_Caux^(1) and S_Lambda*I_X^(1),with opposite
independently measured matrices. This does not construct a global measure.

Retain the ordered bilocal L. At a local probe sigma(x),its kernel is
sigma(x)*x_s(x)*L_s,r*K(x-y)*x_r(y);interchanging x,y also moves the probe.
An antisymmetric L need not give a zero nonlocal insertion. For a local contact
delta(x-y),only the canonical Bose-symmetric polynomial local(L) survives.
The analysis must report both rather than using an unapproved quotient.

The measured scalar heat function and finite matching constant are the same
for these two-vertex kernels. Give the three extensions finite parameters
kK,kD,kC. Their nonlocal parts agree only if the actual matrix comparisons pass.
The remaining contact equations are

 W*(kD-kK)=0,       local(L)*(kC-kK)=0.

These are homogeneous constraints constructed from measured tensors and actual
operators. No unknown quantum inhomogeneity is chosen to enforce them. Determine
the rank from nonzero coefficient witnesses;an insensitive projection supplies
no equation. Setting all three to a common symbolic kappa constructs one family
for this sector. The earlier b0 remains a distinct unresolved normalization.

Physical reality and local contact H covariance use the inherited actual
evaluation-dual maps:ordinary rho was dual to Lambda;the contracted scalar-pair
matrix uses two scalar primal inverse maps. Eps transforms as the antighost
variation,not as a BV source. No raw complex chart is silently called real.

The resulting finite-sector family is not simultaneous quantum nonemptiness
for all operators. Other source products,off-flat nonlocal companions,
Lorentzian/IR/measure hypotheses and full Slavnov/QAP still require proof.
