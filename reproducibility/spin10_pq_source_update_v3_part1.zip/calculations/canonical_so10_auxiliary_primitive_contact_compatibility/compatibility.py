from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,importlib.util,json,os,sys,time,threading
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('qualified_contact_jet_algebra',R/'calculations/canonical_so10_correlated_contact_lift/lift.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u;ONE=u.ONE
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed=set(prep['read_json_by_role'][role])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PRIMITIVE_CONTACT_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_PRIMITIVE_CONTACT_JSON',str(p))
 sys.addaudithook(guard);data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k'];fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs};coords=fields|sources;Jof={n:J for n,J,h,k in pairs};fieldof={J:n for n,J,h,k in pairs}
 elem=lambda name,j=():{(0,((A.index[name],j),)):ONE};const=lambda text:{(g,()):co for g,co in u.parse_coefficient(text)};mul=A.product;add=v.combine;neg=lambda Q:v.scale(Q,-1)
 def mm(left,right):
  out={};rows=defaultdict(list)
  for (k,j),co in right.items():rows[k].append((j,co))
  for (i,k),co in left.items():
   for j,cv in rows[k]:out[i,j]=add(out.get((i,j),{}),mul(co,cv))
  return {key:co for key,co in out.items() if co}
 transpose=lambda mat:{(j,i):co for (i,j),co in mat.items()}
 def equalmat(left,right):return all(left.get(key,{})==right.get(key,{}) for key in left.keys()|right.keys())
 cp=R/f'calculations/canonical_so10_correlated_contact_lift/{role}_result.json';cr=read(cp.parent/'validation_receipt.json');assert cr['execution_state']=='COMPLETED' and cr['input_sha256'][str(cp)]==digest(cp)
 bp=R/f'calculations/canonical_so10_auxiliary_insertion_source_bubble/{role}_v2_result.json';br=read(bp.parent/'validation_receipt.json');assert br['execution_state']=='COMPLETED' and br['input_sha256'][str(bp)]==digest(bp)
 jr=read(R/'calculations/canonical_so10_triangular_heat_transport/validation_receipt.json');assert jr['execution_state']=='COMPLETED' and jr['formal_prescribed_field_heat_Jacobian_trace_zero_without_cyclicity_or_heat_limit']
 for folder in ['frozen_a10_e2_transport','frozen_a10_e3_symmetry','frozen_a10_e5_full_hessian']:
  fp=P/folder/(role+'.json');binding=read(fp.parent/'bindings.json');assert binding['byte_sha256'][fp.relative_to(R).as_posix()]==digest(fp)
 old=read(cp);Kaux=v.unpack(A,old['actual_20_Kaux']);Ktree=v.unpack(A,old['Ktree']);Rfield={A.index[n]:A.rows(rows) for n,rows in data['master_field_maps'].items()};E2=read(P/f'frozen_a10_e2_transport/{role}.json');E3=read(P/f'frozen_a10_e3_symmetry/{role}.json')
 KL=u.left_gradients(A,Kaux);qmap=dict(Rfield)
 for n in KL.keys()&sources:
  previous=v.unpack(A,old['actual_consumed_Qsource_maps'][A.names[n]]);actual=A.rows(E2['complete_columns'][A.names[n]]['source_polynomial']);assert previous==actual;qmap[n]=previous if role=='primary' else actual
 Caux=v.act(A,Kaux,qmap,1,role);Ctree=v.act(A,Ktree,qmap,1,role);assert add(Caux,Ctree)==v.unpack(A,old['complete_C_QK'])
 def flows(K):
  grad=u.left_gradients(A,K)
  return ({n:v.scale(grad.get(J,{}),-(-1)**A.parities[n]) for n,J,h,k in pairs},{J:v.scale(grad.get(n,{}),(-1)**A.parities[n]) for n,J,h,k in pairs})
 XF,XS=flows(Kaux);TF,TS=flows(Ktree);assert not any(TF.values());assert sum(bool(Q) for Q in XS.values())==21 and sum(bool(Q) for Q in TS.values())==17
 for n,Q in XF.items():assert Q==v.unpack(A,old['all643_nonzero_field_flows'].get(A.names[n],[]))
 for J,Q in XS.items():assert add(Q,TS[J])==v.unpack(A,old['all643_nonzero_source_flows'].get(A.names[J],[]))
 srcaux={};srctree={}
 for J in sources:
  if XS[J]:v.merge(srcaux,mul(XS[J],Rfield[fieldof[J]]))
  if TS[J]:v.merge(srctree,mul(TS[J],Rfield[fieldof[J]]))
 assert not add(Ctree,srctree)
 scalarids={n for n in fields if A.names[n].startswith('x_')}
 pscalar=lambda Q:{key:co for key,co in Q.items() if all(n in scalarids for n,j in key[1])}
 jzero=lambda Q:{key:co for key,co in Q.items() if not any(n in sources for n,j in key[1])}
 assert not jzero(srcaux) and all(not pscalar(KL.get(n,{})) for n in coords)
 Lnames=[('b' if i<12 else 'L')+str(i) for i in range(45)];scalar=[f'x_{sec}_{i}' for sec,count in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(count)];si={A.index[n]:i for i,n in enumerate(scalar)};GF=A.rows(data['gauge_fixing_density']);EL=v.euler(A,GF,{A.index[n] for n in Lnames},role)
 M={};Mp={}
 for i,name in enumerate(Lnames):
  n=A.index[name];gf=pscalar(EL[n]);qcol=pscalar(A.rows(E2['complete_columns'][A.names[Jof[n]]]['source_polynomial']));assert gf==qcol;Mp[i]=gf
  for (gp,w),co in gf.items():assert len(w)==1 and not w[0][1];u.put(M.setdefault((i,si[w[0][0]]),{}),(gp,()),co)
 X={i:XF[A.index[name]] for i,name in enumerate(Lnames) if XF[A.index[name]]};assert len(X)==20
 assert not add(Kaux,*(mul({(0,((Jof[A.index[Lnames[i]]],()),)):ONE},Q) for i,Q in X.items()))
 hmap={n:{(0,((hh,()),)):ONE} for n,J,hh,kk in pairs};kmap={n:{(0,((kk,()),)):ONE} for n,J,hh,kk in pairs};variation={h for n,J,h,k in pairs}|{k for n,J,h,k in pairs}
 second=v.act(A,v.act(A,Caux,hmap,0,role),kmap,0,role);projected={key:co for key,co in second.items() if all(n in variation|scalarids for n,j in key[1])}
 expected={};XSsecond={}
 for i,Q in X.items():XSsecond[i]=v.act(A,v.act(A,Q,hmap,0,role),kmap,0,role);v.merge(expected,neg(mul(Mp[i],XSsecond[i])))
 assert projected==expected
 print('STAGE',role,'actual_Kaux_QKaux_full_Hessian_source_products_and_M_bridge',flush=True)
 D={A.index[f'ub{i}']:{(0,((A.index[f'zz_da{i:02}'],()),)):ONE} for i in range(12,45)};Dplus=dict(D)
 for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=neg(A.rows(rows,True));Dplus[A.index[name]]=A.rows(rows,True)
 DK=v.act(A,Kaux,D,0,role);DKplus=v.act(A,Kaux,Dplus,0,role);epsids={A.index[f'zz_da{i:02}']:i for i in range(12,45)}
 WR={epsids[n]:Q for n,Q in u.left_gradients(A,jzero(DK)).items() if n in epsids};WRplus={epsids[n]:Q for n,Q in u.left_gradients(A,jzero(DKplus)).items() if n in epsids}
 assert all(WRplus.get(i,{})==neg(Q) for i,Q in WR.items())
 V={}
 for i,name in enumerate(Lnames):
  Q=A.rows(data['all33_kernel_maps'].get(A.names[Jof[A.index[name]]],[]),True)
  for (gp,w),co in Q.items():assert len(w)==1 and w[0][0] in epsids and not w[0][1];u.put(V.setdefault((i,epsids[w[0][0]]),{}),(gp,()),co)
 # Extract actual scalar ghost kernels directly from QKaux,without using M*T.
 CR={};Y={}
 for (gp,w),co in jzero(Caux).items():
  ss=[n for n,j in w if n in scalarids]
  if len(w)==3 and len(ss)==1 and all(not j for n,j in w):u.put(CR.setdefault(si[ss[0]],{}),(gp,tuple((n,j) for n,j in w if n!=ss[0])),co)
 for (gp,w),co in GF.items():
  ss=[n for n,j in w if n in scalarids]
  if len(w)==3 and len(ss)==1 and sum(A.parities[n] for n,j in w)==2 and all(not j for n,j in w):u.put(Y.setdefault(si[ss[0]],{}),(gp,tuple((n,j) for n,j in w if n!=ss[0])),co)
 ref=read(P/f'frozen_a10_e5_full_hessian/{role}.json')['retained_reference'];order=ref['field_order'];pos={n:i for i,n in enumerate(order)};odd={A.index[n] for n in order if A.parities[A.index[n]]};mom=s.symbols('p0_ref0:4');Pm=mom[0]**2-sum(q*q for q in mom[1:]);N={}
 for i,j,text in ref['reference_Green_raw_C3']['entries']:
  a,b=A.index[order[i]],A.index[order[j]]
  if a in odd and b in odd:N[a,b]=const(str(s.cancel(Pm*s.sympify(text,locals=dict(zip(map(str,mom),mom))))))
 def hessian(Q0):
  out={}
  for i,dQ in u.left_gradients(A,Q0).items():
   for j,ddQ in u.left_gradients(A,dQ).items():assert i in odd and j in odd and all(not w for gp,w in ddQ);out[i,j]=ddQ
  return out
 NY={r:mm(N,hessian(Q)) for r,Q in Y.items()}
 def trace(left,right):
  out={}
  for (i,j),co in left.items():out=add(out,neg(mul(co,right.get((j,i),{}))))
  return out
 def wick(Q1,Q2):
  out={}
  for (gp,w),co in Q1.items():
   for (gq,z),cv in Q2.items():
    assert len(w)==len(z)==2
    i,j=w[0][0],w[1][0];k,l=z[0][0],z[1][0];cross=add(neg(mul(N.get((i,k),{}),N.get((j,l),{}))),mul(N.get((i,l),{}),N.get((j,k),{})))
    out=add(out,v.scale(mul({(gp,()):co},mul({(gq,()):cv},cross)),2))
  return out
 def loops(insertions):
  out={}
  for i,Q in insertions.items():
   nq=mm(N,hessian(Q))
   for r,RQ in Y.items():
    a=trace(nq,NY[r]);b=wick(Q,RQ);assert a==b
    if a:out[i,r]=a if role=='primary' else b
  return out
 L=loops(CR);W=loops(WR);Wplus=loops(WRplus);assert equalmat(Wplus,{key:neg(co) for key,co in W.items()})
 measured=read(R/f'calculations/canonical_so10_auxiliary_insertion_source_bubble/{role}_v2_result.json');T={(row['rho_index'],row['scalar_index']):v.unpack(A,row['coefficient']) for row in measured['canonical_tensor']};assert len(T)==368
 expectedL={key:neg(co) for key,co in mm(transpose(M),T).items()};expectedW=mm(transpose(V),T);assert equalmat(L,expectedL) and equalmat(W,expectedW)
 localL={};localW={}
 for (a,b),co in L.items():v.merge(localL,mul(co,mul(elem(scalar[a]),elem(scalar[b]))))
 for (a,b),co in W.items():v.merge(localW,mul(co,mul(elem(f'zz_da{a:02}'),elem(scalar[b]))))
 # Complete special-regulator response support:field degree3 with no scalar.
 touched=[]
 for i,j,text in ref['reference_Hessian_raw_C3']['entries']:
  if order[i] not in [Lnames[a] for a in X]:continue
  n=order[j];assert n.startswith('B') or n in Lnames;touched.append([order[i],n,text])
  Q=mul(X[Lnames.index(order[i])],elem(n));Q2=v.act(A,v.act(A,Q,hmap,0,role),kmap,0,role);assert not {key:co for key,co in Q2.items() if all(a in variation|scalarids for a,jj in key[1])}
 assert len(touched)==100
 # Physical scalar contact and marked-Ward maps.
 TT={(i,j):const(text) for i,j,text in ref['physical_to_raw_kernel']['entries']};Ti={(i,j):const(text) for i,j,text in ref['physical_to_raw_inverse']['entries']};S={(a,b):Ti[pos[name],180+b] for a,name in enumerate(scalar) for b in range(328) if (pos[name],180+b) in Ti}
 physicalL=mm(mm(transpose(S),L),S);anti=[('bar' if i<12 else 'ub')+str(i) for i in range(45)];EA={(a,b):Ti[pos[name],598+b] for a,name in enumerate(anti) for b in range(45) if (pos[name],598+b) in Ti};physicalW=mm(mm(transpose(EA),W),S)
 assert all(not(cell[2]&16) for mat in [physicalL,physicalW] for coP in mat.values() for co in coP.values() for cell,z in co)
 H={A.index[n]:A.rows(rows) for n,rows in E3['operators']['Tb_geometric_and_transported'].items()}
 for i in range(12,45):
  n=A.index[anti[i]];out={}
  for (gp,w),co in H[n].items():
   ww=[]
   for a,j in w:
    if A.names[a].startswith(('bar','ub')):k=int(A.names[a][3:] if A.names[a].startswith('bar') else A.names[a][2:]);assert k>=12;ww.append((A.index[f'zz_da{k:02}'],j))
    else:ww.append((a,j))
   ww,sg=A.canonical(tuple(ww));u.put(out,(gp,ww),u.scale_coefficient(co,sg))
  H[A.index[f'zz_da{i:02}']]=out
 assert not v.act(A,localL,H,0,role) and not v.act(A,localW,H,0,role)
 rank=int(bool(W))+int(bool(localL));assert W
 constraint=s.Matrix(([[-1,1,0]] if W else [])+([[-1,0,1]] if localL else []));assert constraint.rank()==rank and constraint*s.Matrix([1,1,1])==s.zeros(rank,1)
 controls={'omit_quantum_primitive_leaves_Ward_remainder':bool(W),'wrong_Dplus_source_sign_changes_measured_Ward_kernel':any(W[key]!=Wplus[key] for key in W),'unequal_Ward_contact_constants_fail':bool(localW),'unequal_Slavnov_contact_constants_sensitive':bool(localL),'omit_M_changes_ordered_scalar_kernel':bool(L),'source_products_Kaux_J0_control_insensitive':True,'common_free_kappa_satisfies_actual_constraints':True}
 packmat=lambda mat:[{'row':i,'column':j,'coefficient':u.pack(A,co)} for (i,j),co in sorted(mat.items()) if co]
 result={'schema':'ACTUAL_AUXILIARY_PRIMITIVE_CONTACT_COMPATIBILITY_V1','route':role,'scientific_disposition':'SELECTED_COMMON_EUCLIDEAN_PRIMITIVE_WARD_AND_SHEAR_CONTACT_EXTENSION_FAMILY_NOT_FULL_QAP','Kaux_terms':len(Kaux),'Caux_terms':len(Caux),'Kaux_first_gradient_nonzero_columns':len(KL),'all1286_first_gradient_scalar_projections_zero':True,'source_flows_aux21_tree17_union37_verified':True,'whole_Ctree_plus_tree_source_product_zero':True,'whole_aux_source_product_J0_zero':True,'actual_M_nonzero':len(M),'actual_M':packmat(M),'full643_field_projected_QKaux_second_variation_positions':len(projected),'full_projected_Hessian_equals_minus_M_HX':True,'direct_Ward_33x328_domain':10824,'Ward_nonzero':len(W),'Ward_tensor':packmat(W),'Slavnov_ordered328x328_domain':107584,'Slavnov_ordered_nonzero':len(L),'Slavnov_ordered_tensor':packmat(L),'local_Slavnov_contact_polynomial':u.pack(A,localL),'local_Slavnov_contact_positions':len(localL),'local_Ward_contact_positions':len(localW),'physical_ordered_Slavnov_nonzero':len(physicalL),'physical_Ward_nonzero':len(physicalW),'physical_ordered_Slavnov_tensor':packmat(physicalL),'physical_Ward_tensor':packmat(physicalW),'physical_reality_and_local_H_contact_checks':True,'actual100_regulator_partners':touched,'one_loop_pure_scalar_regulator_Hessian_zero_before_heat_limit':True,'Gamma1_Kaux_bracket_projection_zero_by_all_gradient_columns':True,'primitive_one_loop_source_coefficient':'-JL_i*T_i,s*K_heat*x_s/2;source differentiation precedes J0','Ward_independent_tensor_equals_Vtranspose_T':True,'Slavnov_independent_tensor_equals_minus_Mtranspose_T':True,'nonlocal_heat_function_reused_authenticated_not_recomputed':measured['heat_kernel_16pi2'],'finite_matching_constant':measured['heat_matching_delta_16pi2'],'three_contact_constants_order':['kK','kD','kC'],'actual_contact_constraint_rows':[list(map(int,row)) for row in constraint.tolist()],'actual_contact_constraint_rank':rank,'remaining_contact_parameter_dimension':3-rank,'common_symbolic_kappa_family_exists_in_this_sector':True,'b0_stays_distinct_and_unfixed':True,'local_probe_and_ordered_bilocal_matrix_retained':True,'controls':controls,'global_limits':'selected one-loop Euclidean scalar/source projections and special-shear identity only;full BRST-regulator QAP,offflat nonlocal Ward,Lorentzian/IR/measure and all operator-contact sectors unproved','shared_limits':'qualified action,source maps,T kernel,reference/frame,exact algebra,software and AI author;not independent physical assumptions or external/Lean verification','no_Gamma_scheme_authority_or_protected_change':True,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
