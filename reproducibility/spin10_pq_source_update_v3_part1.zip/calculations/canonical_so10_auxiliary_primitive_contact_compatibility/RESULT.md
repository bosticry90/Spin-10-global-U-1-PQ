# A common finite extension for an actual primitive and its descendants

Prospective qualification requires the completed separate validation receipt
and exact committed-byte checks. Both native routes completed;this report is
frozen before independent verification. No normalization is adopted in Gamma.

The existing20-term Kaux has Kaux=-sum JL_i X_i in the actual source-left
order. Its quantum primitive therefore contains the measured nonzero source
coefficient -JL_i*T_i,r*K_heat*x_r/2. It vanishes at J=0,but its source derivative
does not. Setting sources to zero before differentiation loses the required
quantum term and fails the new checks.

The descendant coefficients were computed from the actual differentiated
densities,not assigned the values needed by the relation:

| Target | Full coefficient positions | Nonzero |
|---|---:|---:|
| Dminus Kaux,marked33 directions x328 scalars |10824|368|
| QKaux,ordered328x328 scalar bilocal kernel |107584|1712|

The first tensor equals V_JL^T*T. The second equals -M^T*T,where the432-entry
M is independently obtained from the actual GF and QJL action columns.
The complete643-field second variation of QKaux has736 retained scalar-mean
positions and agrees with -M(x)H_X,including every omitted-block zero.
Its local Bose contact polynomial has948 positions. Ordered bilocal and
local contact data are stored separately;no constant-probe shortcut is used.
Physical reality and local contact H covariance pass in the actual charts.

The one-loop linearized Slavnov comparison retains Q I_Kaux^(1). All1286
first derivatives of Kaux vanish on pure scalar means,so (Gamma1,Kaux)
vanishes there without evaluating unmeasured physical Euler functions.
This establishes the stated projected insertion compatibility;it does not
establish all BRST-regulator/QAP breaking terms in the full theory.

There is also a complete selected fixed-source special-shear comparison.
All21 Kaux source flows contain JL and their whole source-product insertion
vanishes at J=0. The17 Ktree source flows obey Ctree+XJtree R=0 as an exact
density,so those paired whole insertions cancel by linearity. The full37 maps
are preserved. The actual100 regulator partners contain only B/Lambda fields:
X R_t is cubic and its Hessian is zero on pure scalar means before any
inverse-heat limit. The previously qualified zero formal special Jacobian is
retained as an explicit premise. The remaining scalar-pair kernels I_Caux
and S_Lambda I_X have opposite independently calculated matrices.
This is a selected formal one-loop Euclidean statement,not a global measure
or quantum-equivalence theorem.

The finite heat function and its local matching constant are authenticated
from6212325. Give the measured extension directions independent finite
constants kK,kD,kC. Their nonlocal functions agree;the remaining local equations
are genuinely nontrivial:

    W*(kD-kK)=0,       local(L)*(kC-kK)=0.

Actual nonzero coefficient witnesses give rank2,leaving

    kK=kD=kC=kappa

with one unrestricted common real kappa within THESE THREE directions.
This does not count the freedom in the full nine-carrier mixing module.
No numerical constant is selected and the older b0 is not identified with kappa.
The extension family is nonempty for this selected primitive/descendant sector;
nonemptiness of the simultaneous full quantum prescription is still unproved.

Reversing the D source orientation changes the actual nonzero Ward kernel.
Omitting the quantum primitive,omitting M or assigning one descendant a
different finite constant also fails the sensitive checks. The Kaux source
product omission control is explicitly insensitive at J=0;its vanishing is
proved by its external JL factor,not mistaken for a generic product zero.

Next priority:determine whether a COMMON finite-part construction applies to
the complete ordered positive-heat special-shear coefficient class,including
the connected products and the nonzero regulator response away from this
projection. Use the existing complete inverse-heat reduction and uniform UV
symbol bounds. Prove the finite/power subtraction and operator-domain
requirements rather than extending a leading-log theorem by assertion.
This would generalize a real constructed sector instead of accumulating
unrelated selected kernels. Full Ward/Slavnov,QAP,Lorentzian/IR/measure and
physical field/source equivalence remain separate obligations.

Separate verification must reconstruct QKaux,DminusKaux,all107584/10824
positions,source products,736 Hessian positions,948 contacts,actual frames,
local H,regulator support and rank2 using its own polynomial/jet/Wick code.
Shared action,T kernel,reference,software and AI authorship remain scientific
common-error limits;no Lean,outside expert or experimental validation.
Read receipts for actual times,memory and failed execution counts.

Gamma874873/source146663,source38,369/664,295 unmatched vector profiles,
authority113/34of39 and all protected failures,blocks/pauses,custody2/seven
remain unchanged. Full E5/A5 and physical GUT viability remain unqualified.
