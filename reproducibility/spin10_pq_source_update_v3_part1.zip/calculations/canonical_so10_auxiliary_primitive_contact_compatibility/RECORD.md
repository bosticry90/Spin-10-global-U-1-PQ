# Actual primitive/descendant contact compatibility V1

Base62123254bb5e6ebd5e5e2ad1fcbf5f486fadb914,main. Previous turn PROGRESS.
Question:does the measured nonzero auxiliary-insertion kernel admit one common
Euclidean extension with its actual source primitive and corrected Ward/Slavnov
descendants? Derive every coefficient from the action before comparing them.
This is not a fabricated M c=-r or a full quantum-restoration theorem.

Use the ENTIRE existing20-term Kaux sector of the qualified K,with Ktree and
its source products retained for the complete selected shear equation.
Kaux=-sum JL_i X_i in source-left order. New target projections:
1. Primitive I_Kaux linear JL and scalar at one loop,g4*xi2.
2. Actual Dminus Kaux:marked eps*x,g4*xi3,all33 directions/328 scalars.
3. Actual QKaux:scalar pair,g5*xi3,all328x328 ORDERED bilocal coefficients.
Keep a local insertion probe;do not hide an antisymmetric bilocal matrix by
assuming constant probe or equal external momentum squares.

Freeze the actual measured T368/physical304 and its heat kernel/receipt;Kaux,
Ktree,Cfull,Qsource/action maps,GF/M/Y,full90 odd inverse,all33 Dminus kernels,
physical dual/primal frames and E3 H maps. No new loop needed for T itself.
Compute descendants directly from QKaux and DminusKaux,then their independent
odd Hessian/Wick bubble contractions. Compare to separately formed products
-M^T*T and V_JL^T*T. M is actual scalar part of QJL=EL_Lambda S;derive it both
from GF differentiation and E2 columns. Do not set any unmeasured coefficient.

Required completeness evidence:
- All1286 first derivatives of Kaux vanish on pure scalar/no-source means,
  so the (Gamma1,Kaux) contribution vanishes in this projection without any
  unmeasured physical Euler values. Retain the source derivative of I_Kaux:
  I_Kaux^1=-sum JL I_X^1;it is essential and nonzero before J=0.
- Full643-field h/k second variation of QKaux projected onto scalar means
  equals -sum M(x) H_X,with no omitted even,mixed,jet or source block.
- All21 Kaux source flows contain JL,so their whole product insertion vanishes
  at J=0;the17 Ktree source flows give Ctree+sum XJtree R=0 as a complete density.
  Neither discards the37 full source maps or declares their generic products zero.
- The special regulator response has actual100 touched reference B/Lambda
  entries. X_field R_t is cubic with no scalar coefficient;its full Hessian
  vanishes on pure scalar means BEFORE inverse-heat/loop limits. The inherited
  zero formal special Jacobian remains a premise,not a global measure theorem.

Compute ordered scalar bilocal matrix L and its local Bose-symmetric image
separately. A skew bilocal matrix can contribute for a varying local probe,
even if its contact image vanishes. Do not force a contact constraint if that
projection is insensitive. W=V_JL^T*T must be measured;wrong Dplus orientation
is a meaningful control where W is nonzero.

Let independent finite constants be kK,kD,kC for the actual primitive,Ward and
Slavnov-descendant extensions. Their nonlocal heat functions are measured,
not adjustable. Derive the actual LOCAL homogeneous compatibility system from
W(kD-kK) and local(L)(kC-kK). Determine rank/free parameters honestly. A common
free kappa is a candidate finite sector family,NOT the old b0 or an adopted
physical scheme. No global Slavnov/QAP hypothesis is imported to obtain zero.

Primary:actual source-left Q/D action,prefix Hessians,full trace contractions.
Replay:independent E2 source columns,reversed graded differentiation,Wick
contractions and sparse products. Separate verifier:own graded polynomial
algebra/factorized contractions,all coefficient positions,source-vanishing
proofs,rank and negative controls. Shared action/software/AI premises disclosed.
Controls:omit quantum primitive/source derivative,flip D source sign,omit M,
give descendant a different finite constant,ignore probe/Bose distinction.

Two sequential native120sec AFTER imports/8GiB sampled private;verifier180sec/
8GiB;350MiB available-commit launch floor,newbytes<5MiB. Freeze then launch
separate calls,reject existing outputs/live owned workers,preserve failures.
No Gamma,authority,state,policy,old evidence,scheme,benchmark or remote change.
Authority113/34of39,source38,Gamma874873/source146663,369/664,295 vector poles,
custody2/seven,protected blocks/pauses and full E5/A5 unqualification remain.
