# Full-color longitudinal response through quadratic vector order

Use the literal F=partial B-partial B+g[B,B] and invariant color pairing.
Linearizing E_nu=-D_mu F_mu,nu gives the exact Hessian
 K_mn=-D^2 delta_mn+D_n D_m+g ad(F_nm)
     =-D^2 delta_mn+D_m D_n-2g ad(F_mn).
These are off-shell action derivatives. At constant external B, its equation
of motion starts at g^2 B^3; the Hessian gauge-orbit identity is therefore
homogeneous through B^2. No equation of motion is set to zero in the functional.

Put D_m=i q_m+g A_m, A_m=ad(B_m). All A matrices remain noncommuting.
 K0_mn=Q delta_mn-q_m q_n,
 K1_mn=-2i(q.A)delta_mn+i(q_m A_n+q_n A_m),
 K2_mn=-sum A_r^2 delta_mn+A_m A_n-2[A_m,A_n].
Actual full45 Lie/Jacobi/invariant-pairing facts identify the adjoint
commutator with ad([B_m,B_n]); a projected-heavy replacement does not.

Check K1 q=i K0 A, q^T K1=i A^T_L K0, q^T K1 q=0,
and K1 A+i K2 q=0. T_L means contraction of Lorentz indices only, with
color order retained. The actual Wick/reference pairing supplies the flat
mixed blocks, up to a common fixed analytic continuation and congruence:
 G_BB=P_T/Q-W q q^T/Q^2, G_BL=i q/Q, G_LB=-i q^T/Q, G_LL=0.
Arbitrary color W need not commute with any A. K0 G_BB K0=K0.
Consequently q^T(K1 G_BB K1-K2)q=0, though its contact and exchange pieces
are individually nonzero. Linear mixed gauge-fixing U,V corrections have a
factor q^T K1 q and vanish at this order. Both complete5x5 and reduced inverse
expansions must agree; relative contact/exchange factors come from the inverse
series, not a fitted Ward completion.

Expanding the graded boson/ghost quadratic determinant to one external ghost
and one antighost contracts two actual X_{L,a,C} off-diagonal Hessians with
one ghost Green function and the LL block of the bosonic inverse. All proper
cycle orders from that Schur complement are retained. At g2 B^2: the zeroth
LL block is zero; ghost-F dressing multiplies the zero first-order LL block;
the second LL block is the complete contact/exchange/mixed sum above. This
makes the selected ordinary-cycle integrand zero before UV angular/radial
integration. The common graded sign/normalization is irrelevant only AFTER
the complete ordered matrix coefficient is shown to vanish.

The actual14 catalogue profiles contain five individual kinematic-zero
FG3XX/G3UXX cases and nine G4XX/G3G3XX contact/exchange cases in three external
H/H,H/M,M/M cohorts. Only the complete full-color sum is asserted zero for
those nine, not each H/M intermediate piece. Engineering dimension4 and no
external derivatives/masses imply zero Taylor order for this UV coefficient;
reference masses or external momentum corrections are lower UV degree. V255
identifies its leading heat-regulated logarithm within the inherited formal
local family. Off-flat background A and all other antighost targets remain
outside the result. A completed native output and independent receipt are
required before this proposed cancellation is qualified.
