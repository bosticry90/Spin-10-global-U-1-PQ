# Native continuation V2: explicit action-read inventory

V1 failed before its algebra stages: the strict reader rejected the physical
action bindings.json, absent from the inherited read whitelist. No native
result or replay was produced. Preserve zero.py, its source copy, preparation,
controller and full failed primary capture unchanged.

V2 explicitly declares the actual action AST/bindings and all newly read parent
result receipts for the same role. All bytes are frozen; this does not grant
peer-result access or change mathematics, physical inputs or resource limits.
Source changes only select the new preparation filename. Continue with two
sequential120sec/8GiB/minimum350MiB native runs and independent verification.
