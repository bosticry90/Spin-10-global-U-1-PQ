# Exact analytic convention bridge for the independent verifier

No new physical Wick/regulator scheme is adopted. This algebraic change of
variables connects the already qualified actual physical reference matrix to
the universal Euclidean identity used for a zero coefficient.

The actual Minkowski5x5 block is [-P eta+u u^T, i u; -i u^T,w], with
eta=diag(1,-1,-1,-1), u=eta p. Put p=(i q0,q1,q2,q3) and
S=diag(1,-i,-i,-i,-i). Then S^T K_M(p) S is exactly
[Q I-q q^T, i q; -i q^T,-w]. Its inverse is
S^{-1}G_M(p)S^{-T}. Thus the arbitrary noncommuting W lemma includes both
actual widths with W=-eta_H or -xi. No width is selected numerically.

For interactions, write R=diag(1,-i,-i,-i), B_M=R B_E. Componentwise
partial_M= i R partial_E. Therefore
 F_M,mu,nu=i R_mu R_nu F_E,mu,nu(g_E), g_E=-i g_M.
Since eta_mu R_mu^2=1, -F_M^2/4 becomes +F_E^2/4. Cubic and quartic
Hessians thus transform with their same relative inverse-series coefficients;
the formal analytic coupling g_E is not a new physical input. A zero at its
second degree remains zero when expressed in real original g_M.
The independent verifier checks every5x5 entry and all16 Lorentz pairs of
these derivative/bracket and metric factors, not a selected momentum point.
All external X/ghost coordinate factors multiply an already zero LL tensor.

This bridge is a normalization proof for this algebraic zero, not a contour,
finite amplitude, infrared, measure or global quantum-construction theorem.
