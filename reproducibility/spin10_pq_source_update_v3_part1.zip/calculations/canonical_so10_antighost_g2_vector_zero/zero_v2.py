"""Actual full-color g2 vector/ghost zero via ordered longitudinal inverse."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations,permutations
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent

def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('actual_g2_vector_types',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;read=a.read;digest=a.digest;PKG=a.PKG
q=s.symbols('q0:4',real=True);Q=sum(z*z for z in q)
def clean(P):return {w:s.cancel(z) for w,z in P.items() if s.cancel(z)!=0}
def sc(z):return {():s.sympify(z)} if z!=0 else {}
def letter(n):return {(n,):s.S.One}
def add(*rows):
 d=defaultdict(lambda:s.S.Zero)
 for row in rows:
  for w,z in row.items():d[w]+=z
 return clean(d)
def scale(P,z):return clean({w:z*c for w,c in P.items()})
def mul(*rows):
 d=sc(1)
 for row in rows:
  p=defaultdict(lambda:s.S.Zero)
  for w,z in d.items():
   for v,c in row.items():p[w+v]+=z*c
  d=clean(p)
 return d
def comm(A,B):return add(mul(A,B),scale(mul(B,A),-1))
def ser(P):return [[list(w),str(z)] for w,z in sorted(P.items())]
def dot(row,col):return add(*(mul(x,y) for x,y in zip(row,col)))
def rowmul(row,M):return [dot(row,[M[i][j] for i in range(len(row))]) for j in range(len(M[0]))]
def jacobi(f):
 inner=defaultdict(list);outer=defaultdict(list);terms=defaultdict(lambda:s.S.Zero)
 for (a,b,c),z in f.items():
  if b<c:inner[a].append((b,c,z))
  outer[c].append((a,b,z))
 for e in inner:
  for c,d,z in inner[e]:
   for a,b,v in outer[e]:
    if b==c or b==d:continue
    triple=(b,c,d);sg=(-1)**sum(x>y for i,x in enumerate(triple) for y in triple[i+1:]);terms[a,tuple(sorted(triple))]+=sg*z*v
 return {k:s.simplify(v) for k,v in terms.items() if s.simplify(v)!=0}

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('G2_VECTOR_ZERO_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 # Authenticate the exact full physical Yang-Mills AST, not an action guessed
 # from the desired Ward cancellation.
 from m08_local_functional_ast import add as AA,mul as MM,scalar,field,derivative,tensor,parameter
 def contract(expr,idx,lor=False):return {'node':'LorentzContraction' if lor else 'GroupContraction','expression':expr,'contracted_indices':list(idx),'parity':0,**({'metric':'diag(1,-1,-1,-1)'} if lor else {})}
 B=lambda c,mu:field('B',indices=(c,mu));F=AA(derivative('mu',B('a','nu')),MM(scalar(-1),derivative('nu',B('a','mu'))),contract(MM(parameter('g10',mass_dimension=0),tensor('StructureConstant','f_plane',('a','b','c')),B('b','mu'),B('c','nu')),('b','c')));expected=contract(contract(MM(scalar(s.Rational(-1,4)),F,F),('a',)),('mu','nu'),True);ap=PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';binding=read(ap.parent/'bindings.json');assert binding['byte_sha256'][ap.relative_to(ROOT).as_posix()]==digest(ap);assert next(x for x in read(ap)['local_terms'] if x['term_id']=='gauge')['density']==expected
 ref,rb=b.sealed('frozen_a10_e5_full_hessian',role);master,mb=b.sealed('frozen_a10_bv_master',role);rr=ref['retained_reference'];names=rr['field_order'];T={(i,j):s.sympify(z) for i,j,z in rr['physical_to_raw_kernel']['entries']};I={(i,j):s.sympify(z) for i,j,z in rr['physical_to_raw_inverse']['entries']};C=s.zeros(45);Ci=s.zeros(45)
 for j in range(45):
  for i in range(45):
   C[i,j]=T.get((4*i,names.index('B'+str(j)+'_0')),0);Ci[j,i]=I.get((names.index('B'+str(j)+'_0'),4*i),0)
 assert (C*Ci-s.eye(45)).applyfunc(s.simplify)==s.zeros(45)
 def full_lie():
  raw={(i,j,k):s.sympify(z) for i,j,k,z in master['geometry']['f']};f=defaultdict(lambda:s.S.Zero);co={i:[(j,C[j,i]) for j in range(45) if C[j,i]] for i in range(45)};ii={j:[(b,Ci[j,b]) for b in range(45) if Ci[j,b]] for j in range(45)}
  for (i,j,k),z in raw.items():
   for aa,x in co[i]:
    for bb,y in ii[j]:
     for cc,t in ii[k]:f[aa,bb,cc]+=z*x*y*t
  f={key:s.simplify(z) for key,z in f.items() if s.simplify(z)!=0}
  assert all(s.simplify(z+f.get((bb,aa,cc),0))==0 and s.simplify(z+f.get((aa,cc,bb),0))==0 and s.simplify(z-s.conjugate(z))==0 for (aa,bb,cc),z in f.items());assert not jacobi(f)
  return f,raw
 f,raw=stage('actual_full45_real_invariant_pairing_and_Jacobi',full_lie)
 actualsymbol=b.auth('canonical_so10_ub12_reference_symbol',role+'_v2_result.json');assert len(actualsymbol['all45_mixed_principal_blocks'])==45 and actualsymbol['all45_ghost_orientation_pairs_and328_scalar_principals_checked'];prior=b.auth('canonical_so10_ub12_g1_bare_frontier',role+'_v2_result.json');assert prior['literal_gauge_minus_quarter_F_squared_verified'] and prior['actual_all_mixed_reference_edges_longitudinal_all4_components']==94
 def universal():
  A=[letter('A'+str(i)) for i in range(4)];W=letter('W');U=[letter('U'+str(i)) for i in range(4)];V=[letter('V'+str(i)) for i in range(4)];qa=add(*(scale(A[i],q[i]) for i in range(4)));sq=add(*(mul(z,z) for z in A));K0=[[sc(Q*int(i==j)-q[i]*q[j]) for j in range(4)] for i in range(4)];K1=[[add(scale(qa,-2*s.I*int(i==j)),scale(A[j],s.I*q[i]),scale(A[i],s.I*q[j])) for j in range(4)] for i in range(4)]
  if role=='primary':K2=[[add(scale(sq,-int(i==j)),mul(A[i],A[j]),scale(comm(A[i],A[j]),-2)) for j in range(4)] for i in range(4)]
  else:K2=[[add(scale(sq,-int(i==j)),mul(A[j],A[i]),comm(A[j],A[i])) for j in range(4)] for i in range(4)]
  right=[add(*(scale(K1[i][j],q[j]) for j in range(4))) for i in range(4)];left=[add(*(scale(K1[i][j],q[i]) for i in range(4))) for j in range(4)];qkq=add(*(scale(right[i],q[i]) for i in range(4)));assert not qkq
  for i in range(4):assert right[i]==scale(dot(K0[i],A),s.I) and left[i]==scale(dot(A,[K0[j][i] for j in range(4)]),s.I);assert not add(dot(K1[i],A),scale(add(*(scale(K2[i][j],q[j]) for j in range(4))),s.I))
  GG=[[add(sc(int(i==j)/Q-q[i]*q[j]/Q**2),scale(W,-q[i]*q[j]/Q**2)) for j in range(4)] for i in range(4)]
  for i in range(4):
   for j in range(4):assert dot(rowmul(K0[i],GG),[K0[k][j] for k in range(4)])==K0[i][j]
  exchange=dot(rowmul(left,GG),right);contact=add(*(scale(K2[i][j],q[i]*q[j]) for i in range(4) for j in range(4)));assert exchange==contact and contact
  fullG=[row+[sc(s.I*q[i]/Q)] for i,row in enumerate(GG)]+[[sc(-s.I*z/Q) for z in q]+[{}]];fullK=[row+[sc(s.I*q[i])] for i,row in enumerate(K0)]+[[sc(-s.I*z) for z in q]+[W]]
  for i in range(5):
   for j in range(5):assert dot(fullK[i],[fullG[k][j] for k in range(5)])==dot(fullG[i],[fullK[k][j] for k in range(5)])==sc(int(i==j))
  VK1=[row+[U[i]] for i,row in enumerate(K1)]+[V+[{}]];VK2=[row+[{}] for row in K2]+[[{}]*5]
  if role=='primary':
   one=scale(dot(rowmul(fullG[4],VK1),[fullG[i][4] for i in range(5)]),-1);two=add(dot(rowmul(rowmul(rowmul(fullG[4],VK1),fullG),VK1),[fullG[i][4] for i in range(5)]),scale(dot(rowmul(fullG[4],VK2),[fullG[i][4] for i in range(5)]),-1))
  else:
   one=scale(qkq,-1/Q**2);two=scale(add(exchange,scale(contact,-1)),1/Q**2)
   # Both possible mixed U/V insertions are killed independently, with
   # noncommutative matrices on either side of the common qK1q factor.
   assert not dot(left,[sc(z) for z in q]) and not dot([sc(z) for z in q],right)
  assert not one and not two
  wrongcurv=[[add(scale(sq,-int(i==j)),mul(A[i],A[j])) for j in range(4)] for i in range(4)];curvdef=[add(dot(K1[i],A),scale(add(*(scale(wrongcurv[i][j],q[j]) for j in range(4))),s.I)) for i in range(4)];assert any(curvdef)
  wrongcontact=add(exchange,contact);assert wrongcontact and exchange
  projector=letter('OMITTED_COLOR_COMPLEMENT');projected_defect=dot(rowmul(left,[[scale(projector,(Q*int(i==j)-q[i]*q[j])/Q**2) for j in range(4)] for i in range(4)]),right);assert projected_defect
  return {'K0':[[ser(P) for P in row] for row in K0],'K1':[[ser(P) for P in row] for row in K1],'K2':[[ser(P) for P in row] for row in K2],'contact':ser(contact),'exchange':ser(exchange),'g1_LL':ser(one),'g2_LL':ser(two),'wrong_contact_sign':ser(wrongcontact),'missing_color_complement_defect':ser(projected_defect),'curvature_omission_full_Ward_defects':[ser(P) for P in curvdef]}
 algebra=stage('noncommuting_YM_and_complete_or_reduced_mixed_inverse',universal)
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');selected=[]
 for i,row in enumerate(inv['all_profiles']):
  if row['g']==2 and sorted(n[0] for n,j in row['external_ports'])==['B','B','C','a'] and row['total_external_jets']==0:
   fam=tuple(sorted(z.split('_g')[0] for z in row['vertex_family']));assert fam in [('F','G3','X','X'),('G3','U','X','X'),('G3','G3','X','X'),('G4','X','X')];assert row['vertex_coefficient_dimension']==0 and not row['scalar_reference_mass_expansions'] and row['witness']['Taylor_degree']==0;selected.append({'index':i,'family':list(fam),'external_ports':row['external_ports'],'BB_width_roles':row['BB_width_roles'],'explicit_vertex_xi':row['explicit_vertex_xi'],'classification':'INDIVIDUAL_LONGITUDINAL_KINEMATIC_ZERO' if fam in [('F','G3','X','X'),('G3','U','X','X')] else 'ZERO_ONLY_AFTER_COMPLETE_FULL_COLOR_CONTACT_EXCHANGE_COHORT_SUM'})
 assert len(selected)==14 and sum(r['classification'].startswith('INDIVIDUAL') for r in selected)==5
 uv=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');front=b.auth('canonical_so10_antighost_finite_frontier',role+'_result.json','validation_v2_receipt.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and front['all33_formal_local_UV_insertions_have_g_at_most4'];qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in front['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'ANTIGHOST_G2_VECTOR_ZERO_V1','route':role,'scientific_disposition':'COMPLETE14_BARE_G2_BBaC_COMBINED_LOCAL_LOG_ZERO_BEFORE_INTEGRATION','literal_actual_gauge_F_squared_AST_exact':True,'actual_raw_structure_constants':len(raw),'full45_physical_structure_constants':[[*key,str(z)] for key,z in sorted(f.items())],'all_full45_physical_structure_constants_real_fully_antisymmetric_Jacobi':True,'actual45_physical_principal_blocks_and94_mixed_blocks_authenticated':True,'noncommuting_hessian_and_inverse_algebra':algebra,'all14_actual_profiles':selected,'five_individual_zero_profiles_nine_collective_contact_exchange_profiles':True,'inverse_series_relative_contact_exchange_coefficients_not_fitted':True,'complete_ghost_bilinear_Schur_block_proof_with_first_order_F_dressing':True,'arbitrary_noncommuting_width_and_mixed_U_V_retained':True,'no_equation_of_motion_quotient_or_onshell_condition':True,'zero_before_UV_integration_not_whole_finite_or_IR_amplitude':True,'only_flat_bare_cohort_no_offflat_or_other_antighost_claim':True,'controls':{'omit_contact_gives_nonzero_exchange':True,'flip_contact_sign_gives_nonzero':True,'change_contact_coefficient_changes_nonzero_exchange':True,'drop_curvature_breaks_full_hessian_Ward_identity':True,'drop_intermediate_color_complement_breaks_general_cancellation':True},'insensitive_control':'q^T K2 q alone cannot detect antisymmetric curvature;the full K1 A+i K2 q test detects it','all_seven_quantum_flags_false':flags,'functional_source_input_benchmark_scheme_authority_changed':False,'full_QAP_measure_IR_contacts_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual frozen action/family/reference/type charts and full-color structure constants,prior symbolic proofs,software and AI author shared;not independent expert,Lean or experimental validation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
