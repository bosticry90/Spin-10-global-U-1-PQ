# Independent continuation V2: central rational normalization

The first independent verifier failed its exact5x5 inverse assertion. It used
expand(expression*Q^2)==0, which is not a complete zero test for coefficients
with central momentum-polynomial denominators. Its source, frozen manifest
and full failed capture remain unchanged; no receipt was created.

V2 retains all full ordered matrix assertions. For equality it collects each
noncommuting word separately and cancels only that word's central rational
coefficient. It never reorders A,W,U,V or deletes a term. If any reduced
coefficient is nonzero, the same scientific gate fails. This is a proposed
engineering correction, not acceptance of the native result. Both completed
native routes are reused; no new pole, action or resource change.

All original Wick, full Lie, profile, Schur, negative-control and authority
checks remain required in a separately frozen120sec/8GiB/minimum350MiB run.
Record one failed native reader run and one failed independent verifier.
