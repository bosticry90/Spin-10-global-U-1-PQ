# Selected g10^2 vector/antighost cohort: combined UV zero

The two completed native routes obtain a zero combined leading logarithmic
coefficient for all fourteen flat/bare BBaC profiles at g10^2, with no external
derivatives or masses. This is a structural integrand reduction, not a new
loop integration. Qualification requires the completed independent receipt,
its actual coefficient/domain checks and subsequent committed-byte verification.
The present report is not itself a validation receipt.

## What is actually zero

The full-color ordinary Yang-Mills Hessian and mixed B/L inverse have vanishing
LL blocks at zeroth, first and second order in a constant external vector B.
The second-order inverse includes its quartic contact, two-cubic exchange and
both mixed gauge-fixing insertions, with matrix multiplication order retained.
The ghost bilinear Schur contribution has two actual X_{L,a,C} vertices.
At g10^2 B^2 it uses LL2*ghost0, LL1*ghost1 or LL0*ghost2. All vanish. Thus the
complete selected homogeneous UV symbol is zero before radial integration.

The individual contact and exchange numerators are nonzero and equal:
 q^T K1 G_BB K1 q = q^T K2 q.
Their relative subtraction follows from the inverse series. It is not chosen
to make a Ward identity cancel. Five FG3XX/G3UXX profiles vanish individually.
Nine G4XX/G3G3XX profiles vanish only in their three complete external H/H,
H/M and M/M cohorts, including both H and M internal color sectors. Individual
width-tagged or family pieces are not thereby measured or separately zero.
The exact indices are 451-455, 811-815 and 1398-1401.

The cancellation holds for arbitrary noncommuting color widths W and arbitrary
linear mixed gauge-fixing blocks U,V. It therefore includes both symbolic
reference widths. The proof uses no physical equations of motion, numerical
momenta, heavy-only Lie bracket, unknown fitted pole or infinite-dimensional
trace cyclicity. The off-shell Hessian identity is derived by differentiating
the literal action; its higher cubic-background equation-of-motion term is
outside this quadratic coefficient, not set to zero in the functional.

## Actual action and normalization

The exact parent -F^2/4 action AST is authenticated. All 1,674 physical
structure-constant entries are real and fully antisymmetric, and their full
45-direction Jacobi tensor is zero. The actual raw tensor and constant
raw/physical frame remain dependencies. The replay derives the curvature
ordering from the Euler linearization instead of the reordered Hessian form.
No 33-direction projected Jacobi assumption is used.

The actual45 physical principal blocks and94 raw mixed longitudinal blocks
are authenticated from their qualified reference checks. The independent
verifier must additionally check WICK_NORMALIZATION_BRIDGE.md: the exact
five-block congruence, both width signs and all Lorentz interaction phases.
This is a formal analytic proof of relative conventions, not adoption of a
new physical Wick prescription or coupling. The independent calculation uses
noncommuting SymPy operators, the full mixed inverse, the original raw Jacobi
tensor, a complete frame roundtrip and both route-specific graph witnesses.

Zero refers to the leading homogeneous unheated UV symbol and its logarithm
under V255's qualified formal ordered-heat correspondence. Contact and
exchange graphs have different heat placements and may leave finite terms.
Neither the full regulated integrand nor a finite/infrared amplitude is claimed
zero. No whole scaleless integral is used to infer a separate UV zero.

## Validation and research boundary

Native primary/replay complete in39.664/25.255seconds after imports, sampled
private171,253,760/169,840,640bytes. Independent verification retains the same
120second/8GiB/minimum350MiB limits. A native V1 failed before algebra because
its reader omitted the action binding file; original source/manifest/full
capture are preserved. V2 changes only the preparation pointer and explicit
input/read inventory. The failed worker is not accepted. Final independent
execution counts and performance belong to its receipt.

Controls remove or sign-flip the contact, alter its coefficient, omit an
intermediate color complement and remove the curvature from the full Hessian
Ward identity. Each creates a nonzero defect. The doubly longitudinal K2
contraction alone is insensitive to its antisymmetric curvature; that
limitation is explicitly retained rather than counted as a sensitive test.

No old integral, full polynomial, known functional, source coefficient,
benchmark, reference input, physical scheme, policy or authority is changed.
All seven quantum flags remain false. Full source-free Slavnov, QAP, measure,
composite/contact/infrared conditions, equivalence and E5/A5 remain unqualified.
Authority34/39, custody exit2/seven unresolved references, historical quartet
failure, scalar quantum-control warning and gauge-matching limitations remain.

This closes one earliest unmeasured bare cohort, not the full g10^2 or g10^4
frontier. Eight g10^2 scalar-pair aC profiles, one explicit-A derivative profile,
other scalar/mass targets, higher orders and off-flat reference responses are
separate. Do not convert the nine collective zeros to individual family
measurement records or silently rewrite V259's earlier classification.
The next smallest competent task is to inspect the scalar-pair aC quartet's
actual longitudinal gauge/scalar response and determine whether an analogous
structural identity applies, preserving scalar-background Euler terms.

Track B: structural reduction avoided a dense color/Lorentz coefficient
compiler while retaining noncommuting matrices, both widths and complete
intermediates. The reader failure remains an implementation weakness. Action,
reference, type/normalization assumptions, prior UV proofs, software and AI
author remain shared. These checks are not independent scientists, Lean
certificates, experimental evidence or a completed quantum construction.
