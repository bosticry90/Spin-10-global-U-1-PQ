# g10^2 BBaC proper-cycle cancellation V1

Question AG2V: do the complete fourteen remaining flat/bare g10^2 BBaC
no-derivative profiles have a vanishing combined local logarithmic coefficient?
This can close an actual earliest unknown antighost cohort. Do not infer a
zero from absent words, a Ward-fitted companion or the higher g1 theorem.

Freeze unchanged literal gauge action -F^2/4, actual complete45 Lie/invariant
metric, actual raw/physical reference and mixed propagators, 16-vertex catalogue,
V249 Taylor identity, V252 all45 physical principal blocks, V255 formal UV theorem
and V259 finite frontier. All masses, widths, reference/vacuum/kinetic/source
conventions stay. No new pole integration, benchmark, regulator scheme, quantum
prescription or authority adoption. No physical EOM quotient is allowed.

Least expensive competent test: derive the ordinary constant-vector Yang-Mills
Hessian from the literal action, including its curvature term and noncommuting
color order. Keep the full45 intermediate color identity. For nonzero Euclidean
q, use arbitrary noncommuting color width W in the flat mixed B/L inverse.
Expand its LL Green block through second order in constant external B. Include
arbitrary linear B-dependent mixed gauge-fixing blocks U,V. The two-X ghost
cycle is proportional to this block. Ghost-F dressing multiplies its first
order block. Test the complete inverse-series/contact relative coefficients,
not coefficients chosen to force a symmetry. Derive from matrix inverse and
actual Schur complement for the external-ghost quadratic sector.

Native primary: exact free-word color algebra and complete5x5 inverse Born
products. Replay: Euler linearization form of the YM Hessian and reduced
longitudinal contractions. Independent verifier: ordinary noncommuting SymPy
operators, mixed block inverse, ordered inverse coefficient check and both
actual catalogue witnesses. Actual F^2 AST, full Lie/invariant-metric and all
mixed-reference qualifications must match. If a premise fails, preserve
INCONCLUSIVE; never assume every selected profile separately vanishes.

Expected alternatives: combined14-class UV zero (some only after contact and
exchange sum); nonzero complete integrand requiring a later measured pole;
or exact missing normalization/coverage premise. Retain H/H,H/M,M/M external
classes and H/M internal sums separately. A projected-heavy Jacobi/inverse is
not permitted. No off-flat A completion or other g2 scalar/mass/source/g3/g4
claim follows. No radial integration or fullGamma expansion is authorized here.

Negative controls: omit/sign-flip the contact, change its Hessian coefficient,
drop the curvature from the Hessian Ward test, and delete a formal intermediate
color complement. Disclose that the fully longitudinal quadratic contraction
alone is insensitive to the antisymmetric curvature term. The off-shell
Hessian identity tests that term; no on-shell assumption is imposed.

Sequential own-role primary/replay each120sec after imports/8GiB sampledprivate/
minimum350MiB availablecommit plus separate bounded independent verification.
Freeze sources/controllers/input hashes before workers. Preserve failures and
new versions; compare complete results, validate before localcommit. No agents,
branch/worktree, remote action, source/functional/policy/project_state change.
All seven quantum flags false; authority34/39. Full sourcefreeSlavnov, QAP,
measure, products/contacts/IR, equivalence, E5/A5 and physical GUT remain open.
Shared action, catalogue, inherited reference and Lie proofs, software and AI
author are not independent science/Lean/experiment. Track B tests structural
reduction of an actual gap rather than another large tensor expansion.
