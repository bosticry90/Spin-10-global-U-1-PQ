"""Exact measured auxiliary integration and complete zerojet insertion component."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent

def load(n,p):
 q=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(q);q.loader.exec_module(u);return u
old=load('qualified_full_current_recipe',OUT.parent/'canonical_so10_unbroken_ghost_quartic_integration/integration.py');q=old.q;m=old.m;h=old.h;l=old.l;s=q.s;read=q.read;digest=q.digest;PKG=q.PKG

def auth(folder,name,receipt='validation_receipt.json'):
 p=OUT.parent/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def current_tables(role):
 tables,previous,path=old.current_tables(role);p=OUT/(role+'_v2_result.json');d=auth(OUT.name,p.name);assert d['updated_known_recipe']['previous_recipe_path']==str(path) and d['updated_known_recipe']['previous_recipe_sha256']==digest(path);tables.append(d['new_actual_g3_auxiliary_antighost_node']);return tables,d,p

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AUX3_INTEGRATION_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);w=m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 canonical=auth('canonical_so10_auxiliary_antighost_g3_canonical',role+'_result.json');nodeRows=canonical['new_actual_g3_auxiliary_antighost_node'];P=m.decode(nodeRows);assert len(P)==236 and all(g==3 for g,key in P) and not canonical['actual_local_H_variation']
 tables,previous,path=old.current_tables(role);prior=stage('full_incoming155110_recipe_and_exact_hash_once',lambda:q.combine(tables));oldhash=q.hashrows(q.rawrows(prior));assert len(prior)==previous['updated_known_terms']==155110 and oldhash==previous['updated_known_sha256']=='ce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1'
 @lru_cache(None)
 def typ(word):return tuple(sorted(h.kind(n) for n,j in word))
 def isclass(word):return len(word)==3 and not any(j for n,j in word) and typ(word)==('C','L','a')
 before=m.decode([r for r in q.rawrows(prior) if isclass(tuple(m.token(n) for n in r['word']))]);assert not any(g==3 for g,key in before)
 additions={tuple(m.token(n) for n in r['word']):r['coefficient'] for r in nodeRows};assert len(additions)==236
 def insert():
  updated=dict(prior)
  if role=='primary':
   affected={k:prior[k] for k in additions if k in prior};new=q.combine([q.rawrows(affected),nodeRows])
   for k in additions:
    if k in new:updated[k]=new[k]
    else:updated.pop(k,None)
  else:
   for key,z in additions.items():
    value=q.sumtext(tuple(sorted([updated.get(key,'0'),z])))
    if value!='0':updated[key]=value
    else:updated.pop(key,None)
  return updated
 updated=stage('sparse236_coefficient_exact_once_inverse_double_source_checks',insert);changed={k for k in set(prior)|set(updated) if prior.get(k)!=updated.get(k)};assert changed==set(additions);inverse=dict(updated);double=dict(updated)
 for key,z in additions.items():inverse[key]=q.sumtext(tuple(sorted([updated.get(key,'0'),str(-q.num(z))])));double[key]=q.sumtext(tuple(sorted([updated.get(key,'0'),z])))
 inverse={k:z for k,z in inverse.items() if z!='0'};double={k:z for k,z in double.items() if z!='0'};assert inverse==prior and double!=updated
 assert {k:z for k,z in prior.items() if k not in changed}=={k:z for k,z in updated.items() if k not in changed};source_before={k:z for k,z in prior.items() if any(n in m.sources for n,j in k)};source_after={k:z for k,z in updated.items() if any(n in m.sources for n,j in k)};assert source_before==source_after
 sf=m.decode([r for r in q.rawrows(prior) if not any(m.token(n)[0] in m.sources for n in r['word'])]);assert len(sf)==40309 and m.fingerprint(sf)=='ad385556b964a8a3d32511d578ba6e2ad20209a148f2c835c29599bcacbc6c7a';new_sf=m.add(sf,P);assert len(new_sf)==40545;after=stage('updated_zerojet_auxiliary_projection_vs_compiled_delta',lambda:m.decode([r for r in q.rawrows(updated) if isclass(tuple(m.token(n) for n in r['word']))]));assert after==m.add(before,P) and {k:z for k,z in after.items() if k[0]==3}==P
 # Append tests only after incoming field/source indices are fixed.
 for i in range(45):n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1)
 E={m.index[f'zz_da{i:02}'] for i in range(12,45)};shift={m.index[f'ub{i}']:m.elementary(m.index[f'zz_da{i:02}']) for i in range(12,45)}
 def kind(n):return 'E' if n in E else h.kind(n)
 def target(word):return not any(j for n,j in word) and tuple(sorted(kind(n) for n,j in word))==('C','E','L')
 def project(F,gp=None):return {key:z for key,z in F.items() if (gp is None or key[0]==gp) and target(key[1])}
 def act(F,I):return m.action(F,I,'primary',True) if role=='primary' else m.action(F,I,'replay')
 def anchor(F):return m.add(*(m.mul(m.elementary(e),Q) for e,Q in m.EL_all(F,E).items()))
 op=auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');assert op['all643_source_left_Eulers_match_actual_master'] and op['all643_tree_chain_rule_exact_density'] and op['all_kernel_second_field_variations_zero'];V={m.index[J]:h.from_result(rows) for J,rows in op['all33_kernel_maps'].items()};Vs={g:{J:{key:z for key,z in Q.items() if key[0]==g} for J,Q in V.items() if any(key[0]==g for key in Q)} for g in [0,1]};assert all(g in [0,1] for Q in V.values() for g,key in Q)
 specs=defaultdict(set)
 for gv,JJ in Vs.items():
  for J,Q in JJ.items():
   for gp,word in Q:
    if not any(j for n,j in word):specs[J].add((gv,tuple(sorted(kind(n) for n,j in word))))
 def support(word):
  if any(j for n,j in word):return []
  Js=[n for n,j in word if n in m.sources]
  if len(Js)!=1:return []
  J=Js[0];rest=tuple(sorted(kind(n) for n,j in word if n!=J));return [(gv,J) for gv,ty in specs.get(J,set()) if tuple(sorted(ty+rest))==('C','E','L')]
 prim=auth('canonical_so10_local_source_primitive',role+'_v2_result.json');assert prim['all643_source_maps_match'] and prim['current_source_positions']==146663;Srows=prim['normalized_source_image'];matches=defaultdict(set);eligible=[];jetrows=0
 for i,r in enumerate(Srows):
  word=tuple(m.token(n) for n in r['word']);jetrows+=int(any(j for n,j in word));ss=support(word)
  if ss:eligible.append(r)
  for gv,J in ss:
   if 0<=gv+r['g']<=4:matches[gv,r['g']].add(i)
 selected_norm=h.from_result(eligible);selected_actual=m.decode([r for r in q.rawrows(source_before) if support(tuple(m.token(n) for n in r['word']))]);assert selected_norm==selected_actual,'CURRENT_ZEROJET_SOURCE_NORMALIZED_PREDECESSORS_MISMATCH'
 def source_parts():
  parts={};census=[]
  for gp in range(5):
   for gv in [0,1]:
    gg=gp-gv;ids=matches.get((gv,gg),set());S=h.from_result([Srows[i] for i in sorted(ids)]);EL=m.EL_all(S,set(Vs[gv]));raw=m.add(*(m.mul(Q,EL.get(J,{})) for J,Q in Vs[gv].items()));A=project(raw,gp);B=project(act(S,Vs[gv]),gp);assert A==B;parts[gp,gv]=A;census.append({'total_g':gp,'kernel_g':gv,'source_g':gg,'matching_source_row_indices':sorted(ids),'active_source_channels':sorted(m.names[J] for J,Q in EL.items() if Q),'target_positions':len(A)})
  return parts,census
 parts,census=stage('all_actual_source_rows_V0_V1_support_Euler_slot_products',source_parts);ordinary=project(act(after,shift));per={};total={}
 for gp in range(5):
  O=project(ordinary,gp);N=m.add(O,m.scale(parts[gp,0],-1),m.scale(parts[gp,1],-1));assert anchor(N)==N;total[gp]=N;per[str(gp)]={'ordinary':l.rows(O),'V0_source':l.rows(parts[gp,0]),'V1_source':l.rows(parts[gp,1]),'loop_leg_insertion':l.rows(N),'four_boundary_currents':[[],[],[],[]]}
 g0=auth('canonical_so10_antighost_g0_cycle_exclusion',role+'_v2_result.json');g1=auth('canonical_so10_broken_antighost_g1_reconciliation',role+'_v2_result.json');g2=auth('canonical_so10_broken_antighost_g2_leg',role+'_v5_result.json','validation_v2_receipt.json');assert g0['all45_ordinary_antighost_and643_source_g0_UV_coefficients_zero'];assert total[1]==project(h.from_result(g1['all33_g1_anchored_insertion_from_measured_loop_leg_derivative']),1) and total[2]==project(h.from_result(g2['all33_flat_g2_anchored_insertion']),2)
 cov=auth('canonical_so10_higher_antighost_coverage',role+'_result.json');assert {r['g'] for r in cov['selected_class_all_admitted_orders']}=={1,2,3} and cov['selected_smallest_whole_class_target']['indices']==[1862,1924,1925];broken_after={key:z for key,z in after.items() if any(n in shift for n,j in key[1])};assert len(broken_after)==sum(len(r['ordinary']) for r in per.values())
 coverage=auth('canonical_so10_source_coverage_reconciliation',role+'_result.json');pos=auth('canonical_so10_auxiliary_source_nojet_uv',role+'_result.json');assert len(coverage['profiles'])==177 and not coverage['incomplete_profiles'] and all(r['complete'] for r in pos['positive_source_coverage_after_this_input'])
 module=auth('canonical_so10_broken_antighost_dependency_audit',role+'_v2_result.json');assert module['H_multiplet_covariance_qualified'] and not module['all1367_H_D_commutator_residuals'];p=PKG/'frozen_a10_e3_symmetry'/(role+'.json');bind=read(p.parent/'bindings.json');assert bind['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);e3=read(p);TI={m.index[n]:m.decode(rows) for n,rows in e3['operators']['Tb_geometric_and_transported'].items()}
 for i in range(12,45):TI[m.index[f'zz_da{i:02}']]=m.decode([{'word':[om,f'zz_da{j:02}'],'coefficient':co} for ii,j,om,co in module['actual_H_epsilon_module_rows'] if ii==i])
 Hrem={str(gp):l.rows(act(N,TI)) for gp,N in total.items()};Hpass=not any(Hrem.values());front=auth('canonical_so10_antighost_finite_frontier',role+'_result.json','validation_v2_receipt.json');uv=auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert front['all33_formal_local_UV_insertions_have_g_at_most4'] and uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and uv['inherited_actual_H_action_Ward_no_EOM_and4002_Lie_checks_authenticated']
 assert not total[0] and not total[4];source4J={m.token(n)[0] for r in Srows if r['g']==4 for n in r['word'] if m.token(n)[0] in m.sources};assert not source4J&set(Vs[1])
 Onew=project(act(P,shift),3);controls={'omit_or_double_new_ordinary_pole_changes_g3_insertion':bool(Onew),'reverse_new_external_odd_order_changes_g3_insertion':bool(m.scale(Onew,2)),'reverse_actual_source_sign_changes_target':bool(m.add(*(m.scale(Q,2) for Q in parts.values()))),'omit_V0_source3_changes_g3_target':bool(parts[3,0]),'omit_V1_source2_changes_g3_target':bool(parts[3,1])}
 qcpath=PKG/'frozen_a10_e5_quantum_contract'/(role+'.json');bind=read(qcpath.parent/'bindings.json');assert bind['byte_sha256'][qcpath.relative_to(ROOT).as_posix()]==digest(qcpath);qc=read(qcpath);flags={k:qc[k] for k in canonical['all_seven_quantum_flags_false']};assert not any(flags.values())
 result={'schema':'AUXILIARY_G3_INTEGRATION_AND_COMPLETE_ZEROJET_INSERTION_V2_READS_CORRECTED','preserved_failed_native_read_inventory':1,'route':role,'scientific_disposition':'EXACT_ONCE_AUXILIARY_G3_INTEGRATION_AND_COMPLETE_FORMAL_AUXILIARY_INSERTION_COMPONENT' if Hpass else 'EXACT_INTEGRATION_COMPLETE_COEFFICIENTS_H_REMAINDER_OFFFLAT_UNQUALIFIED','new_actual_g3_auxiliary_antighost_node':nodeRows,'new_node_positions':236,'prior_known_terms':len(prior),'prior_known_sha256':oldhash,'updated_known_terms':len(updated),'updated_known_sha256':q.hashrows(q.rawrows(updated)),'new_word_positions':len(set(updated)-set(prior)),'changed_existing_word_positions':len(changed&set(prior)),'removed_existing_word_positions':len(set(prior)-set(updated)),'source_projection_unchanged_and_all_untouched_coefficients_identical':True,'exact_subtraction_recovers_prior_and_double_changes':True,'current_g3_auxiliary_absent_before_and_measured_after':True,'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'add_once_key':'new_actual_g3_auxiliary_antighost_node','qualified_canonical_node_path':str(OUT.parent/'canonical_so10_auxiliary_antighost_g3_canonical'/(role+'_result.json'))},'sourcefree_prior_positions':len(sf),'sourcefree_updated_positions':len(new_sf),'sourcefree_updated_sha256_exact_cells':m.fingerprint(new_sf),'source_rows_all146663_checked':len(Srows),'source_rows_with_positive_total_jets_excluded_from_zerojet_target':jetrows,'selected_zerojet_source_positions':len(selected_norm),'selected_source_matches_actual_incoming_functional':True,'complete_V0_V1_target_predecessor_census':census,'all_orders0through4_auxiliary_insertion_component':per,'all_source_slot_Euler_target_projections_identical':True,'actual_all33_local_H_component_remainders':Hrem,'H_multiplet_covariant':Hpass,'formal_local_component_no_A_derivative_or_mass_fits_dimension4':True,'g0_g4_and_all_greater_than4_component_zero_in_declared_family':True,'g1_g2_component_matches_prior_qualified_insertions':True,'ordinary_CLa_class_complete_all_admitted_orders_and_all_source_scopes_retained':True,'possible_g5_source_overlap_absent_by_actual_channel_support':True,'ordinary_auxiliary_broken_antighost_positions':len(broken_after),'ordinary_unbroken_antighost_positions_outside_target':len(after)-len(broken_after),'controls':controls,'insensitive_source_omission_controls':[k for k,v in controls.items() if not v],'known_source_image_inputs_benchmark_scheme_policy_authority_changed':False,'new_independent_insertion_loop_or_full_Gamma_variation':False,'all_seven_quantum_flags_false':flags,'full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Qualified actions,poles,source-normalized representative,actual V/H and formal local-UV/ring premises,software and AI author shared;leg-derived complete component,not new independent insertion integration or full restoration','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
