# V2 explicit predecessor-read inventory correction

The first native primary failed at the read guard for V263's completed
validation_v2_receipt.json. The parent capture records84.8700261sec and
1010405376 sampled private bytes. Full incoming reconstruction,sparse exact
addition and source products had run, but no RESULT or qualified result file
was produced. The run remains FAILED, not a scientifically accepted partial
result. Replay was not launched. It is an avoidable task dependency error.

Preserve integration.py and sourcecopy,run.py and sourcecopy,preparation.json,
primary_capture.json and external primary_full_capture.json unchanged. V2
adds the actual V263 final receipt and own-role native_v5 records to the
frozen read inventory; it bypasses no guard. Preparation mechanically checks
EVERY literal auth(folder,role+suffix,receipt) in the new worker, file presence,
receipt completion and exact result digest before launch. Historical recipe
IO remains frozen. The future current_tables helper points to V2 result
names, since V1 has no completed record; this is explicit recipe metadata,
not a changed mathematical input. New paths/sourcecopies are exclusive.

All scientific checks,canonical node,ordinary/source coefficients,expected
hashes,types,scope and180sec-after-imports/8GiB/min350MiB bounds are identical.
The failed process left no reusable qualified functional cache, so fresh V2
primary/replay are necessary. Do not infer success from completed intermediate
stages or erase that repeated reconstruction cost from Track B. Final
independent verification must bind/authenticate the failed capture and counts
as well as rerun every acceptance check. No authority or physics change.
