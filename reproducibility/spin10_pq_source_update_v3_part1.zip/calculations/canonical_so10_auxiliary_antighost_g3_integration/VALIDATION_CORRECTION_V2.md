# Independent V2 zerojet-domain assertion correction

The first independent verifier failed at its final domain assertion because
its generator referenced j without binding a token variable. This NameError
occurred after complete functional/hash,source support,component and H checks,
but no completed validation receipt was produced. The run remains FAILED,
not a qualified partial result. Native V2 results and every scientific check
remain unchanged. Preserve verify.py/source,validation_preparation.json,
validation_capture.json and external validation_full_capture.json exactly.

verify_v2.py fixes only that explicit predicate to test every jet in each
word and its complete epsilon-C-Lambda type. It adds failed-verifier custody
checks, retains EVERY mathematical requirement and reruns the full independent
verification. A task-local standard-library symtable preflight must expose
the old undefined j and find no undefined global names in V2 before launch.
This is code hygiene, not a proof of scientific assumptions or a new platform.
Resource bounds remain180sec-after-imports/8GiB/min350MiB. No input,pole,source,
normalization,authority or acceptance change; no native rerun is needed.

The new source,manifest and capture/controller filenames are versioned. The
FIRST SUCCESSFUL receipt is written exclusively to validation_receipt.json,
which does not exist after the failed first verifier. It has explicit V2
schema/source hashes and failure counts. No receipt is overwritten,rebound,
aliased or attributed to V1. This keeps the already frozen native V2
current_tables helper's declared receipt endpoint usable without editing
its scientific source or adding a second recipe interface. Both FAILED
attempt captures remain independently authenticated before commit.
