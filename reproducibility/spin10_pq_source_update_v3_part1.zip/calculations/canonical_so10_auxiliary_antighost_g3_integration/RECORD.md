# Exact-once auxiliary integration and complete epsilon-C-Lambda component V1

Base9426034bca8838f761ab07c4ce806444c410f156, clean main, previous increment
V267 PROGRESS; full Spin(10)xPQ goal remains active. AI1:integrate the qualified
236-position g10^3 canonical pole exactly once into the actual current known
functional. AI2:determine the complete zero-jet epsilon-C-Lambda loop-leg
component for all33 broken directions over the finite g<=4 formal local UV
family. This is a whole field-content component, not full E5 restoration.

Freeze V267 actual canonical node/receipt, V266 complete three-profile pole,
V265 all C-Lambda-a admitted profiles/orders, V257 order0 absence, V258 g1,
V263 complete flatg2 insertion, V264 actual g2 completion, V259 finite bound,
V244 actual affine V0/V1 maps and classical B/C chain, V256 actual epsilon H
module/[TH,D], V255 local ordered-heat theorem. Sourceimage146663 and all177
plus5 dimensionful source scopes, incoming full155110-word recipe/hash and
sourcefree40309-cell projection are immutable. Every physical input,source,
width,coefficient,normalization and action remains. No fitted identity zero.

Reconstruct the full incoming recipe/hash ONCE per native route, then update
only affected236 coefficients. Prove absence of its g3 C-Lambda-a coefficient
before addition; lower g orders in those same words are retained. Exact
subtraction must recover every original coefficient/hash; doubling must
change the result. Source projection and all untouched coefficients identical.
Independent reconstruction should combine all new tables once, recover old
state by subtraction, and reproduce both complete hashes. No full variation
or repeat of expensive qualified loop calculations.

Explicit resource decision BEFORE computation:two sequential read-only native
runs and an independent verifier, each180sec AFTER imports,8GiB sampledprivate,
minimum350MiB availablecommit. The previous current full integration took
124.18sec(native) and87.24sec(independent), dominated by reconstruction and
full recombination. New sparse236-entry update avoids a second full recombine;
180sec accommodates measured serialization overhead without repeating a known
undersized120sec attempt. This is a new delegated bounded contract, not a
silent expansion/retry of any old frozen run. Full captures and exact failure
states mandatory. New source/controller copies exclusive, no frozen overwrite.

For the selected component, use actual Danti Gamma_sf minus V^J Euler_left_J
Gamma_src at fixed J=0/reference/heat, by the qualified ordered loop-leg
identity. Only complete ordinary C-Lambda-a poles can contribute its zerojet
ordinary term. Allg0..4 class coverage must be matched, including catalogue
absence at g4 and actual g0 proof. Other unmeasured sectors do not become
complete. Match EVERY actual V0/source_g and V1/source_(g-1) predecessor.
Do not assume visually convenient JL channels are the only ones.

Enumerate all146663 source rows and2589 kernel rows by exact source,coupling,
field types and jets BEFORE contraction. A total positive jet cannot give a
zerojet epsilon-C-Lambda coefficient without EOM/inverse derivatives; those
are forbidden. Preserve the exclusion census. Match selected zerojet source coefficients to the actual incoming functional,
not merely to a convenient representative. Compute all actually supported
products with correct source-left signs and compare direct source-slot action.
All epsilon derivatives/boundary assumptions are retained in the support
proof; do not transfer other classes' nonzero currents to zerojet targets.
Keep actual zero source projections as complete zeros, not omission controls
claimed sensitive. Match g1/g2 projections to their already qualified inputs.

Use all33 actual epsilon carriers in the H action. The target has dimension
1+1+2=4, ghost0, no source. In the qualified local polynomial ring no extra
A, derivative or positive-dimensional spurion fits. Thus any completion of
THIS component in the explicit formal Weyl UV family is the same zerojet
node, conditional on matching V255 locality/[TH,D] and finite-bound premises.
Nonlocal/finite/IR terms and arbitrary historical schemes are outside it.
A nonzero coefficient or H remainder must be preserved, never fitted away.

Negative controls:duplicate/omit new ordinary pole, reverse odd/source sign,
omit an actually nonzero source predecessor, falsely include g5 overlap.
Report insensitive zero-piece controls explicitly. Compare every new tensor,
complete hashes,source/ordinary scope,currents and H remainder independently.
Validate before local commit. No agent/branch/worktree,remote,promotion,new
benchmark/scheme,policy/authority change. Sole authority34/39,sevenflagsfalse;
E5/A5,QAP,measure,IR,products,contacts,equivalence,fullsourcefreeSlavnov remain
unqualified. Historical quartet/custodyexit2-seven/scalarquantum/gaugethreshold
failures stay separate. HB1/C5 blocked,flavor paused. Shared actions,measured
poles,source chart/catalogue/UV premises,software and AI authorship remain.
