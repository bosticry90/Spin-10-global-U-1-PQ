# Exact integration and zerojet auxiliary component

The new density is a measured g3 ordinary Lambda-a-C pole, not a counterterm
chosen from a Ward relation. Prior recipe materialization and its155110-word
hash are independently qualified. Sparse coefficient addition is exact on
its236-word support; subtracting the same polynomial restores every prior
coefficient and the original hash. Unchanged words,including every source
word,retain their exact serialized coefficients. Future recipe evaluation
must reproduce the new whole hash, not just its word count.

Actual Danti is an even shift of each broken antighost by odd epsilon. With
actual compensating external source shift -V, V''=0 and the complete actual
classical chain give DH=B0''+V'_h R'_k+V'_k R'_h. Differentiating every ordered
Born leg at fixed reference/heat and extracting its qualified local logarithm
therefore yields I=Danti Gamma_sf-V^J Euler_left_J Gamma_src, modulo the
recorded currents. No independent new insertion integral or full QAP is
claimed. Reference determinant is retained, with D derivative0 by A-only
and source-independent dependence, not deleted.

Project to exactly one epsilon,one ghost C,one Lambda and zero jets. Danti
does not change other field labels; ordinary terms of another field content
or positive jet cannot contribute. The ordinary C-Lambda-a class is complete
in all admitted couplings1,2,3; g0 vanishes by the actual g0 cycle proof and
g4 has no profile in the full catalogue. Positive coefficient dimensions do
not fit dimension2+1+1=4. The explicit-family finite frontier excludes g>4.

For source terms, total jets remain nonnegative under local multiplication
and integration by parts. A derivative on epsilon or J shifts to other fields
or annihilates a constant; it cannot create a zerojet term. Therefore enumerate
all source rows and actual V rows and retain ONLY pairs whose exact source,
g sum,zero jets and field multiset after removing J equal epsilon,C,Lambda.
This is a complete support reduction, not an unmeasured coefficient assumed
zero. For retained rows, compute source-left Eulers and a distinct direct
even source-slot action. Compare exact target projections. Actual V0/Sg and
V1/S(g-1) may both matter; source_0 is independently zero and V2 is absent
in the actual maps. Any g5 source overlap is checked rather than presumed.

Zerojet expressions linear in odd epsilon obey the signed left Euler anchor
I=sum epsilon_i Euler_left_epsilon_i I as exact densities. Thus currents of
this target are zero; other full insertions' nonzero currents are preserved.
The exact g1/g2 projections must agree with V258/V263. Test the actual full
local-H action including the180-row epsilon carrier, not a singlet shortcut.

With epsilon dimension1, C dimension1 and Lambda dimension2, an A-invisible
local polynomial difference in this component cannot fit dimension4. V255
formal locality/covariance and V256 [TH,D] therefore fix its off-flat component
in the explicit Weyl UV family to the same zerojet coefficients. This says
nothing about other derivative/vector/scalar/quartet components,finite/IR
nonlocal terms,the regulated measure or a unique historical physical scheme.
