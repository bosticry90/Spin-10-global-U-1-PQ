# BVN1 — source map and ordered one-loop bubble

Keep the physical C1 Euclidean gauge fermion

    Psi = barc_a (F_a-xi*b_a/2),
    F_a = Dbar.Q_a + xi*g*(rho_a w)^T eta,    w=v+chi.

The invariant action depends on eta+w. Give the external pair the rules
s chi=q, s q=0, and s eta=-g*rho(c)(eta+w)-q. The total scalar therefore
has exactly the original C1 gauge transformation. The inherited gauge BRST
algebra plus the doublet gives s^2 eta=0 without a scalar equation of motion.
With K_i s eta_i added, restricting chi=q=K=0 recovers the original action,
including its ghost mass and scalar-ghost vertex. This is a source probe of
that gauge; no equivalence to the different formal E1 source gauge is used.

Apply the graded Leibniz rule to s Psi=bF-xi*b^2/2-barc*sF. The q terms in
s[(rho_a w)^T eta] are (rho_a q)^T eta-(rho_a w)^T q. Reordering odd fields
with rho^T=-rho gives the new ordered terms

    Vq = -xi*g*q_i*barc_a*(rho_a)_{ij}*(eta+w)_j,
    VK = -g*K_l*c_a*(rho_a)_{lk}*(eta+w)_k,
    Vtree = -K_l*q_l.

The q-barc-w and K-c-w vertices are retained. Their single ghost exchange
has one bridge, loop order0 and is 1PR. The unique one-loop 1PI Kq graph uses
one eta from each vertex and one scalar plus one oriented ghost edge.
No invariant or gauge-fixing term contains K otherwise; hence higher vertices
cannot contribute to this local Kq pole at one loop. A missing/changed source
orientation changes the measured sign. External derivatives are forbidden
by dimension for this local dimension4 Kq coefficient.

In the K,q,barc,c order, Vq*VK has coefficient
xi*g^2*K_l*q_i*barc_a*c_b*rho_a,ij*rho_b,lk*eta_j*eta_k.
The Gaussian contraction is <barc_a c_b>=-(Gc)_{ba}. The connected effective
action is -<Vq VK>_c, so these two signs give the positive Kq loop coefficient.
Its color contraction is

    sum_{a,j} rho_a,ij*rho_a,lj = -sum_a (rho_a^2)_{il} = C2_il.

The same sign follows by completing the ghost square: for
S=barc B c+barc J+Jbar c, the remaining action is -Jbar B^-1 J.
Here J=xi*g*q*rho*eta and Jbar=-g*K*rho*eta, giving the same positive term.
There is no extra factor1/2: distinct source vertices cancel the expansion
factor1/2, and the internal scalar/ghost are distinct species.

For arbitrary positive scalar and ghost IR masses a,b, the leading integrand
is 1/[(k^2+a)(k^2+b)]. Its normalized simple UV residue is1. This follows both
from the large-k term1/k^4 and from the Feynman parameter integral of
Gamma(epsilon)[x*a+(1-x)*b+x(1-x)*p^2]^-epsilon. Independently,
(A(a)-A(b))/(b-a) has residue1 because A(a) has residue-a; its a=b limit
-A'(a) has residue1. No scaleless integral or whole finite part is discarded.
Mass/VEV mixing changes negative-degree UV remainders, not this dimensionless
local residue. All physical internal masses remain relevant to finite terms.

Thus the actual source-probe loop and its cancelling source counterterm are

    Gamma1_Kq,pole = +hbar*g^2*xi/(16*pi^2*epsUV) * K C2 q,
    deltaGamma_Kq,pole = -1/2 * K deltaZhat q,
    deltaZhat_pole = +2*hbar*g^2*xi*C2/(16*pi^2*epsUV).

The second line is fixed by the declared source normalization:
K_B=Z^-1/2 K, q_B=Z^1/2 Zhat^1/2 q, so -K_B q_B=-K sqrt(Zhat)q.
Using the independently calculated SWF1 scalar deltaZ gives the correlated
background-coordinate pole within this bookkeeping prescription,

    delta w_pole = (deltaZ+deltaZhat)w/2
                 = hbar*g^2*(3+xi)*C2*w/(32*pi^2*epsUV).

This is not the displacement of the quantum minimum, a finite VEV condition,
or an identity inferred from UTP1 tadpole cancellation. Its source definition
and normalization are part of its scope. The constant block-scalar Casimirs
ensure residual-H covariance of K C2 q and compatibility with real fields.
The singlet gauge contribution vanishes, not its whole quantum correction.

The external background BRST construction and the Zhat comparator are from
[Sperling, Stoeckinger and Voigt1305.1548v3](https://arxiv.org/abs/1305.1548).
The physical finite C1 mass/VEV/tadpole prescription remains a separate
construction; the on-shell masses used in Martens1011.2927 are not adopted.
