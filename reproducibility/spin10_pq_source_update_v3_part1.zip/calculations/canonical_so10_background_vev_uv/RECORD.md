# BVN1 — a mapped background-reference UV bookkeeping probe

Prospective at d2d61f86445e8ddf8106c63f6d7c7d87b6030bc2/main,2026-10-20.
Question: can a nonpropagating background BRST doublet expose the reference
normalization pole of the actual physical C1 linear Rxi gauge, separately
from the quantum-scalar pole SWF1 and radial tadpole UTP1?

The original C1 finite-amplitude gate requires VEV/field/mass/tadpole inputs;
it does not fully choose the finite normalization conditions. BVN1 does not
choose those conditions, add a physical field, resume flavor or adopt the
historical E1 action. The new external variables are a calculation probe;
their zero-source restriction must reproduce the actual BFT1 C1 action.

Freeze the map in DERIVATION before execution. In canonical real coordinates
write total scalar eta+w, w=v+chi, s chi=q, s q=0 and
s eta=-g rho(c)(eta+w)-q. Use the original gauge fermion with fixed-reference
w replacing v, plus the external source K_i s eta_i. At chi=q=K=0 the
physical C1 gauge/scalar/ghost action is unchanged. All45 actual normalized
rho matrices and all328 real scalar fields remain. External q,K are odd,
ghost numbers+1,-1; with c and barc of dimension1 and BRST dimension1,
q,K have dimension2. This dimensional convention introduces no propagator.

Target: the one-loop 1PI local Kq simple UV pole from the actual q-barc-eta
and K-c-eta vertices. Retain the source-linear reference vertices in the
inventory and distinguish their one-particle-reducible exchange from the
one-loop bubble. Do not set v=0 to hide it. No inverse VEV or coupling.

Primary: signed Grassmann Wick expansion of the two source vertices and
direct full-matrix color contraction, plus large-k logarithmic residue.
Replay: complete the ghost Gaussian square with odd sources, shifted-loop
Feynman parameter bubble, and representation-index contraction from the
independent supplied replay packet. Neither reads the other's result.
Verifier: a finite exterior-algebra matrix representation evaluates the
normalized Berezin Gaussian directly, including the reference exchange;
positive-mass divided differences and their degenerate limit fix the UV
residue. Reuse the qualified SWF1 group data only after deriving this new
quantum coefficient. Check source orientation, square-root factor2,
singlet/width limits, full sparse matrix and correlated field/reference law.

Compute only the UV pole. The source normalization prescription is specified
as K_B=Z^-1/2 K and w_B=Z^1/2 Zhat^1/2 w, q_B similarly. State the resulting
Zhat and background pole within this explicit bookkeeping family; do not
equate it with the physical vacuum displacement or claim all source/mass/
potential counterterms close. The admissible source extension and its
restriction are the applicability test, not an earned all-order QAP.

Exact symbolic/rational arithmetic. Caps30s native/60s verifier AFTER imports,
8GiB sampled private NOT peak,350MiB launch-commit floor,4MiB package.
Freeze source/code/controllers/inputs before math; compare completed native
outputs before the separately implemented verifier. Full captures before
assertions, preserve every failure, no silent resource/acceptance expansion.
Possible outcomes: qualified mapped source-probe input, map/sign discrepancy,
underdefinition or bounded inconclusiveness. No fit to a tadpole or matching
residual is permitted. Published comparator1305.1548v3 eq23, not discovery.

Shared action/representation/source-map premises, software and AI author
remain. No external, Lean or experimental validation. No old evidence,
project state, action, point, source functional, main, scheme, policy or
remote/publication change. State113/34of39, E5/A5 unqualified, HB1/C5 blocked,
flavor paused, finite C1_GS uncalculated, quartetFAIL3960/648 and custodyexit2/
seven remain; scalar quantum-control/gauge-matching warnings unchanged.
