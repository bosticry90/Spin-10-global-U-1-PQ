# Next: test the coupled gauge-dependent radial counterterms

BVN1 supplies a mapped background-reference pole. It does not choose the
physical vacuum displacement or finite normalization. The next informative
check is whether independently derived g10^2 potential/parameter poles,
SWF1 field normalization and BVN1 reference normalization reproduce the
actual g10^2*xi tadpole pole already measured in UTP1.

Derive the potential-parameter g10^2 pole using the actual Landau-limit
constant-scalar Hessian and SWF1 field pole, before reading the UTP1 target.
At xi=0 transverse vector propagation annihilates the constant-background
scalar/vector mixing. The local one-loop potential has scalar g^0 and
vector g^4 pieces but no g^2 piece; massless/IR statements must be made
about UV symbols, not unseparated scaleless integrals. This fixes a known
Casimir-weighted rescaling of each independent parent-potential coefficient.

Count the actual field occurrences in every frozen potential AST, including
complex conjugates and mass/cubic directions. Keep the phi mass independent;
do not differentiate a tree stationary/Higgs-tuned family to calculate a
quantum counterterm. Compare the resulting radial tadpole CT to the old
measured coefficient only after assembly. A mismatch is an actual diagnostic,
not permission to tune the potential or reference shift.

A selected pole cancellation would check the coupled map and a real C1
counterterm subspace; it would not close g^0/g^4 poles, all mass/width/gauge
counterterms, finite normalization, full threshold matching or quantum control.
Retain every original physical benchmark and unknown Yukawa dependency.
