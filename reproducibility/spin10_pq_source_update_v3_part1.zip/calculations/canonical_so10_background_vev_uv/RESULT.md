# BVN1 — mapped background-source pole, separate from the physical vacuum

The two native calculations and independent verifier completed at base
d2d61f86445e8ddf8106c63f6d7c7d87b6030bc2. With the explicit external-source
map in DERIVATION, the actual C1 gauge fermion gives

\[
 \Gamma_{1,Kq,\mathrm{pole}}=
 \frac{\hbar g_{10}^2\xi}{16\pi^2\epsilon_{\mathrm{UV}}}K C_2q,
 \qquad
 \delta\widehat Z_{\mathrm{pole}}=
 \frac{2\hbar g_{10}^2\xi}{16\pi^2\epsilon_{\mathrm{UV}}}C_2.
\]

Together with the independently calculated SWF1 field pole, the chosen
bookkeeping normalization implies

\[
 \delta w_{\mathrm{pole}}=
 \frac{\delta Z+\delta\widehat Z}{2}w
 =\frac{\hbar g_{10}^2}{16\pi^2\epsilon_{\mathrm{UV}}}
 \frac{3+\xi}{2}C_2w.
\]

The Casimirs are (10,25/2,9/2,0) on (Phi54,Sigma252,phi20,S2).
The full Kq matrix has 326 nonzero diagonals and 107,258 zero positions
for generic xi. The singlet gauge pole vanishes; its complete quantum
correction has not been declared zero. The matrix is real and block scalar,
so it respects the inherited residual background representation.

The map introduces only nonpropagating calculation sources. The total
scalar eta+v+chi retains the original C1 BRST transformation; chi,q form a
doublet, and the gauge fermion reduces exactly to BFT1 when chi=q=K=0.
No formal E1 source action was imported. The source normalization
K_B=Z^-1/2 K and q_B=Z^1/2 Zhat^1/2 q makes the counterterm
-K deltaZhat q/2, fixing the square-root factor2. This is a pole in the
specified source-probe prescription. It is not an adopted finite physical
VEV condition, a displacement of the quantum minimum or proof that the
complete C1 counterterm action closes.

## Checks and evidence

The primary uses the explicitly ordered Grassmann Wick product and full
rho*rho^T matrix contraction. The replay completes the ghost Gaussian
square, uses a positive-mass Feynman-parameter bubble residue and derives
the group contraction through indices from the supplied replay packet.
The distinct source vertices cancel the expansion factor1/2; there is no
extra half in the loop. Neither native route reads the other's result.

The verifier imports no native helper. A 16-dimensional exterior-algebra
matrix representation evaluates the normalized Berezin integral directly.
It returns the same positive loop coefficient, including the relative
minus from the effective action and the oriented antighost contraction.
It also retains the nonzero reference exchange proportional to w^2/B.
That exchange is a tree, one-bridge, 1PR source graph, not part of the 1PI
loop pole. Setting w=0 prematurely was not used to exclude it.

Positive-mass tadpole divided differences and their degenerate limit give
UV residue1. A nonzero finite divided-difference control is retained; it
is not used as a pole or assigned a convenient finite subtraction. Wrong
source orientation and a missing square-root factor leave nonzero pole
residuals. Zero-source restriction and the graded gauge-fermion sign were
checked separately before native comparison. Existing SWF1 group evidence
was authenticated and reused, not represented as independent new physics.

The result matches the background-source comparator in
[Sperling, Stoeckinger and Voigt,1305.1548v3, eq23](https://arxiv.org/abs/1305.1548).
Matching that pole does not adopt their entire source/normalization framework.

Execution commands are prepare.py, run.py, prepare_validation.py and
run_validation.py under this directory, using python -B in that order.
Frozen bindings:1,176 native/1,181 verifier. Times after imports:
3.0218198/2.8098587 s native and0.6788188 s verifier. No failed native or
verifier runs. Largest private-memory sample49,459,200 bytes, not a peak.
Caps30/60 s after imports,8GiB sampled,350MiB launch floor,4MiB package
unchanged. Source copies and full captures precede the final receipt.

Shared action, representation data, source-map assumptions, software and AI
authorship remain limitations. This is computational corroboration under
those premises, not external, Lean or empirical validation. Full simultaneous
potential/mass/gauge/source counterterms and finite conditions were not
constructed; no expensive previous loop calculation or custody audit was
repeated. All historical evidence, state113/34of39 and blocked/paused stages
remain unchanged. Finite C1_GS and full E5/A5 remain unqualified.
