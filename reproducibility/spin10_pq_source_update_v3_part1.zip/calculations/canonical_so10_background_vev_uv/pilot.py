"""BVN1 signed Wick vs ghost Schur complement; exact source-probe UV pole."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json
import os
import sys
import threading
import time
import sympy as s

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACKET=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation'

@lru_cache(None)
def clean(z):
    return s.cancel(s.expand(z))

def wedge(left,right):
    result={}
    for a,z in left.items():
        for b,w in right.items():
            if set(a)&set(b):
                continue
            sign=(-1)**sum(i>j for i in a for j in b)
            key=tuple(sorted(a+b))
            result[key]=clean(result.get(key,0)+sign*z*w)
    return result

def main():
    start=time.perf_counter()
    timer=threading.Timer(30,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():
        assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    role=sys.argv[1];assert role in ['primary','replay']
    xi,g,tk,tq,x,w,A,B=s.symbols('xi g tk tq x w A B',nonzero=True)
    if role=='primary':
        # Fixed exterior order K,q,barc,c. The only 1PI term uses x from both vertices.
        Vq={(1,2):-xi*g*tq*(x+w)}
        VK={(0,3):-g*tk*(x+w)}
        ordered=wedge(Vq,VK)[(0,1,2,3)]
        # Gamma=-<Vq VK>, <barc c>=-1/B, <x^2>=1/A.
        loop=clean(-(-1/B)*s.expand(ordered).coeff(x,2)/A)
        exchange=clean(-(-1/B)*s.expand(ordered).coeff(x,0))
        k2,a,b=s.symbols('k2 a b',positive=True)
        pole=s.limit(k2**2/((k2+a)*(k2+b)),k2,s.oo)
        packet=json.loads((PACKET/'full_primary.json').read_bytes())
    else:
        # Completing the odd-source Gaussian square leaves -Jbar*B^-1*J.
        J={(1,):xi*g*tq*(x+w)}
        Jbar={(0,):-g*tk*(x+w)}
        remaining=clean(-wedge(Jbar,J)[(0,1)]/B)
        loop=clean(s.expand(remaining).coeff(x,2)/A)
        exchange=clean(s.expand(remaining).coeff(x,0))
        e=s.symbols('epsilon',positive=True)
        a,b,p2=s.symbols('a b p2',positive=True)
        z=s.symbols('z',real=True)
        integrand=e*s.gamma(e)*(z*a+(1-z)*b+z*(1-z)*p2)**(-e)
        pole=s.integrate(s.limit(integrand,e,0),(z,0,1))
        packet=json.loads((PACKET/'full_replay.json').read_bytes())
    assert clean(loop-xi*g**2*tk*tq/(A*B))==0
    assert clean(exchange-xi*g**2*tk*tq*w**2/B)==0
    assert pole==1
    casimirs,entries={},[]
    offset=0
    for sector,size in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
        rows=packet['representation_matrices'][sector]
        assert len(rows)==45
        if role=='primary':
            operator=s.SparseMatrix(size,size,{})
            for row in rows:
                rho=s.SparseMatrix(size,size,{(i,j):s.sympify(z) for i,j,z in row['entries']})
                assert not (rho+rho.T).todok()
                operator+=rho*rho.T
            operator=operator.applyfunc(clean)
            value=clean(s.trace(operator)/size)
            assert not (operator-value*s.eye(size)).todok()
        else:
            indices=[clean(sum((s.sympify(z)**2 for _,_,z in row['entries']),s.S.Zero)) for row in rows]
            assert len(set(indices))==1
            value=clean(45*indices[0]/size)
        casimirs[sector]=str(value)
        for i in range(size):
            if value:
                entries.append([offset+i,offset+i,str(clean(xi*value))])
        offset+=size
    assert offset==328 and len(entries)==326
    # A prior independently measured field pole, read only after the new source kernel.
    field=json.loads((ROOT/'calculations/canonical_so10_scalar_wavefunction_uv/primary_result.json').read_bytes())
    background={}
    for sector,value in casimirs.items():
        assert field['Casimirs'][sector]==value
        fieldZ=clean((3-xi)*s.sympify(value))
        background[sector]=str(clean((fieldZ+2*xi*s.sympify(value))/2))
    result={
        'schema':'C1_GS_BACKGROUND_VEV_UV_NATIVE_V1','route':role,
        'loop_sign':1,'tree_source_sign':-1,'bubble_UV_residue':str(pole),
        'toy_1PI_loop':str(loop),'toy_1PR_reference_exchange':str(exchange),
        'Casimirs':casimirs,'Kq_stripped_sparse':entries,
        'deltaZhat_per_sector':{name:str(clean(2*xi*s.sympify(value))) for name,value in casimirs.items()},
        'delta_w_over_w_per_sector':background,
        'loop_factor':'hbar*g10**2/(16*pi**2*epsilon_UV)',
        'domain':[328,328],'nonzero_generic_xi':len(entries),'zero_complement_generic_xi':328**2-len(entries),
        'finite_physical_VEV_or_scheme_adopted':False,
        'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    timer.cancel()

if __name__=='__main__':
    main()
