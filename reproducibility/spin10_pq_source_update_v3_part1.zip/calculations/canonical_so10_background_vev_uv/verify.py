"""BVN1: literal exterior-matrix Berezin integral and positive-mass UV checks."""
from pathlib import Path
from hashlib import sha256
import json
import os
import threading
import time
import sympy as s

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def clean(z):
    return s.cancel(s.expand(z))

def main():
    start=time.perf_counter()
    timer=threading.Timer(60,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'validation_preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():
        assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    xi,g,tk,tq,x,w,A,B=s.symbols('xi g tk tq x w A B',nonzero=True)
    creators=[]
    for i in range(4):
        op=s.zeros(16)
        for mask in range(16):
            if not mask&(1<<i):
                op[mask|(1<<i),mask]=(-1)**((mask&((1<<i)-1)).bit_count())
        creators.append(op)
    assert all(a*b+b*a==s.zeros(16) for a in creators for b in creators)
    K,q,barc,c=creators
    action=B*barc*c-xi*g*tq*(x+w)*q*barc-g*tk*(x+w)*K*c
    assert action**3==s.zeros(16)
    exponential=s.eye(16)-action+action**2/2
    assert exponential[12,0]==-B
    # Normalized Berezin integral extracts barc*c; negative logarithm gives Gamma.
    fixed_scalar_Gamma=clean(-exponential[15,0]/exponential[12,0])
    actual_loop=clean(s.expand(fixed_scalar_Gamma).coeff(x,2)/A)
    reference_exchange=clean(s.expand(fixed_scalar_Gamma).coeff(x,0))
    expected=xi*g**2*tk*tq/(A*B)
    assert clean(actual_loop-expected)==0
    assert clean(reference_exchange-xi*g**2*tk*tq*w**2/B)==0
    # Source-map sign, derived before any comparison to native output.
    h0,h1,v0,v1,q0,q1,t=s.symbols('h0 h1 v0 v1 q0 q1 t',real=True)
    rho=s.Matrix([[0,-t],[t,0]])
    hv,vv,qv=s.Matrix([h0,h1]),s.Matrix([v0,v1]),s.Matrix([q0,q1])
    Fq=((rho*qv).T*hv-(rho*vv).T*qv)[0]
    assert s.Matrix([s.diff(Fq,z) for z in [q0,q1]]).applyfunc(clean)==(-rho*(hv+vv)).applyfunc(clean)
    # The zero-source restriction is w=v and eta+w equals the original total scalar.
    chi=s.Matrix(s.symbols('chi0 chi1'))
    assert (hv+vv+chi).subs({chi[0]:0,chi[1]:0})==hv+vv
    # Positive-mass subtraction, including coincident masses; pole is independent of IR data.
    a,b=s.symbols('a b',positive=True)
    divided=clean((-a+b)/(b-a))
    degenerate=-s.diff(-a,a)
    assert divided==degenerate==1
    mu=s.symbols('mu',positive=True)
    finiteA=lambda z:z*(s.log(z/mu)-1)
    finite_divided=(finiteA(a)-finiteA(b))/(b-a)
    assert s.simplify(s.limit(finite_divided,b,a)+s.log(a/mu))==0
    # Finite parts are generally nonzero and not substituted for the UV residue.
    assert s.simplify(finite_divided.subs({a:mu,b:2*mu}))!=0
    z,zh,eps=s.symbols('z zh eps',real=True)
    source_bare=-s.sqrt(1+z)*s.sqrt(1+zh)/s.sqrt(1+z)
    assert s.diff(source_bare,zh).subs(zh,0)==-s.Rational(1,2)
    background_linear=s.diff(s.sqrt((1+eps*z)*(1+eps*zh)),eps).subs(eps,0)
    assert background_linear==(z+zh)/2
    # Reuse authenticated SWF1 group evidence, not its integral as this new loop.
    old=json.loads((ROOT/'calculations/canonical_so10_scalar_wavefunction_uv/validation_receipt.json').read_bytes())
    casimirs=old['Casimirs'];expected_sparse=[];offset=0;zhat={};background={}
    for sector,size in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
        cv=s.sympify(casimirs[sector])
        for i in range(size):
            if cv:
                expected_sparse.append([offset+i,offset+i,str(clean(xi*cv))])
        zhat[sector]=str(clean(2*xi*cv))
        background[sector]=str(clean(((3-xi)*cv+2*xi*cv)/2))
        offset+=size
    assert len(expected_sparse)==326 and offset==328
    assert background=={'Phi':'5*xi + 15','Sigma':'25*xi/4 + 75/4','phi':'9*xi/4 + 27/4','S':'0'}
    # A wrong source orientation doubles, rather than removes, the actual loop pole.
    wrong_source_residual=[clean(xi*s.sympify(casimirs[name])+xi*s.sympify(casimirs[name])) for name in ['Phi','Sigma','phi']]
    wrong_sqrt_residual=[clean(xi*s.sympify(casimirs[name])-xi*s.sympify(casimirs[name])/2) for name in ['Phi','Sigma','phi']]
    assert all(value!=0 for value in wrong_source_residual+wrong_sqrt_residual)
    for role in ['primary','replay']:
        actual=json.loads((HERE/(role+'_result.json')).read_bytes())
        assert actual['Kq_stripped_sparse']==expected_sparse
        assert actual['Casimirs']==casimirs and actual['deltaZhat_per_sector']==zhat
        assert actual['delta_w_over_w_per_sector']==background
        assert actual['loop_sign']==1 and actual['tree_source_sign']==-1
    receipt={
        'schema':'C1_GS_BACKGROUND_VEV_UV_VALIDATION_V1','execution_state':'COMPLETED',
        'disposition':'QUALIFIED_MAPPED_EXTERNAL_BACKGROUND_SOURCE_PROBE',
        'input_bindings':len(prep['input_sha256']),
        'Berezin_matrix_loop':str(actual_loop),'retained_1PR_reference_exchange':str(reference_exchange),
        'source_extension_zero_restriction_matches':True,'positive_mass_UV_residue':str(divided),
        'degenerate_mass_UV_residue':str(degenerate),'nonzero_finite_control_retained':True,
        'Casimirs':casimirs,'deltaZhat_per_sector':zhat,'delta_w_over_w_per_sector':background,
        'full_matrix_positions':328**2,'nonzero_generic_xi':326,'zero_complement_generic_xi':107258,
        'wrong_source_and_square_root_controls_nonzero':True,
        'finite_physical_VEV_or_complete_prescription_adopted':False,
        'native_failures':0,'verifier_failures':0,'authority':'34/39_UNCHANGED',
        'external_or_Lean_or_empirical_validation':False,
        'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True)
    timer.cancel()

if __name__=='__main__':
    main()
