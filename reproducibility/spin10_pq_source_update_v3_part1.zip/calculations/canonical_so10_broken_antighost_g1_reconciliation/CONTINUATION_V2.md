# V2 scientific coverage reconciliation

V1 primary FAILED at the strict ordinaryg1 antighost profile-coverage gate,
after the completeB''+C and directGF/master DH1 coefficient equality passed.
It did not qualify any insertion pole. Source/preparation/fullcapture retained;
noV1replay. This is a scientific coverage gap,not relabeled an engineering PASS.

The proposed missingcohort is G3-X-X with externalB,C,a atonejet. The earlier
V249 lemma used literalF^2 and allactual mixedpropagators,and proved the cubic
numerator withTWOlongitudinalgaugelegs starts atO(k_B^2),independentofcolor.
The G3XX profiles haveexactlythose twointernalmixededges andzerojetXi vertices.
Thus noTaylor term oftotaldegree1 can survive,regardlessofdenominator expansion
orwhich externalfield carries thederivative. V2 mustcheck the actualprofile
family,absenceofBBedges,allfour exactpolynomials andthe qualifiedgenericlemma;
any otherunmatchedprofile stillfails. This adds justifiedevidence;it doesnot
relaxcoverage orassign an unknown coefficient froma desiredidentity.

Freeze twoV2native andindependent validation runs withunchanged120sec/8GiB/
350MiB limits. No action/input/scheme/benchmark/authority change. Independent
validator mustreconstruct double-longitudinal cubic firstTaylorzero andevery
profile mapping,notmerely trustthenewlabel. Full quantumobligations unchanged.
