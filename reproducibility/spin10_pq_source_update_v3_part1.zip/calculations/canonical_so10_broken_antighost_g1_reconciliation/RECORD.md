# Complete broken-antighost g1 reconciliation and loop-leg reduction V1

Base54dc608d7a03d6f85f00b66580bbc26d64a8136c. Previous goal turn PROGRESS.
Question:which complete g1 predecessors are needed for all33 broken directions,
and can qualified ordinary/source loop coefficients determine their ordered
insertion coefficient by legitimate loop-leg differentiation? Reuse evidence
before another integral. No physical coupling/input/scheme is changed.

Freeze actualE2/master actions,V244 allB/C insertion coefficients,16-vertex
2353-profile sourcefree inventory,177-profile source coverage and five
positive-dimensional input coverage,current146663 sourceimage and qualified
ordinaryg1 auxiliary/leadingghost/source poles. Preserve historical auxiliary
candidateFAIL and actual pole values. OrdinaryΓg1 antighost support must be
proved complete from profiles and actual H/M domains,not polynomial absence.

Construct ALL33 DHg1 coefficients by two routes:B0g1 second variation plusC1,
and direct actualGFg1 antighost Hessian minusV0 timesactualR1 secondvariation.
Keep allh/k parities,epsilon derivatives andsource-left multiplication order.
Bsource vanishes onlyafter fixedJ=0;do not omit itsclassification. ProveV1 R0''0
using actualg0source affinity. Verify entire tensor,notonefieldpair. Compile
complete rooted g1 B/C support with actualH/M edges,all16vertices,external
jets,masses/orbits andpositive-dimensional bounds. Forward/backward closure;
no arbitraryvertex truncation. No abstract support is a measurednonzero pole.

Reconcile everyordinaryg1 antighost sourcefree profile to actualleadingghost
zero or auxiliaryg1 measurement including zero complements. Recover exact
33auxiliary*33antighost*45ghost domain andlight alternatives;do notinfer the
factor ordering from49005. Check currentlosslessprojection additions have
no otherg1 antighostcohort. Reconcile leadingg1sourceprofiles/currentimage;
retainallpositive-dimensional sources andsourcecorrection kernels.

Compute DΓg1 by exact variation of complete action-calculated input poles,
using source leftEulers andactualfull33 V. D1Γ0=0 follows separately fromV257
allg0source/antighost zeros andnonnegativeg. Ifinputcoverage iscomplete,the
orderedBorn chainrule identifies this derivative with the actualDH insertion
coefficient in the explicitformalUV family. This is diagram-leg differentiation,
not fitting an unknown coefficient tocancel a Ward remainder. It is NOT an
independent new integration;disclose inheritedloopnormalizations andshared
inputs. Ifcoverage/proofpremise fails,preserve exactmissingprofile andclaim
only the verified partialderivative. No independent insertion replay claimed.

UV-log derivative interchange must follow V255 fixedfinitecoefficient local
bounds;D leavesA,Kref,F fixed. RetainALLordered positions andBorn1/n weights.
No infinite-tracecyclicity,finiteheat-factor merging,scalelessintegralzero,
EOM orcountertermfit. Authenticateub12g1 CL20/twojet4 result asan actualoverlap
control,notvaluesforotherdirections. Record explicitcurrents forjetanchoring.
Backgroundcompletion mayuse V256Hmodule andV251localA-kernel uniqueness only
withpreciseorders/ring;do notadopt unspecifiedhistoricalreference orscheme.

Two sequentialnative runs plusindependentverifier,each120sec afterimports,
8GiB sampledprivate,350MiB availablecommit. Own-roleJSON guards,frozeninputs/
code/controller,completecaptures;allfailurespreserved.Newversiononlyforfixes.
Independentordinarypolynomial/Booleanrouting checks andnegativecontrols for
missingBterm,missingauxiliarypole,missingg1sourcepole andwronggradedprefix.
No fullΓexpansion,oldqualifiedintegralreplay,newparametersearch,benchmark,
physicalinput/policy/authoritychange. Sevenflagsfalse,E5/A5unqualified,authority
34/39,HB1/C5blocked,flavorpaused,custody2/sevennotPASS. Solo/sharedaction,charts,
priorloops,software/AIauthor;notexpert/Lean/experimentalcertification.
