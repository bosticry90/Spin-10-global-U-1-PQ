# Why measured-loop differentiation is an insertion calculation

The explicit formal UV loop family is i/2 sum_n(-1)^(n+1)/n STr[(G_t deltaH)^n].
The EVEN antighost operator D shiftsa by oddlocalepsilon andJ by-V,leavingA,
referenceG andheat unchanged. Product differentiation gives the EXACT ordered
sum over everyfactor position with insertion G_t(DH). No tracecyclicity is
used. At a fixedcoupling/field/localdegree onlyfinitelymany words contribute;
V255 uniformUVremainders justify commutingD andthelog coefficient. Thus
D(PoleΓ1) equalsPole oftheorderedDH insertions. This is legitimate action-loop
leg differentiation if,andonlyif,theinputΓ1 projection iscomplete. It cannot
be replaced by choosing unmeasured coefficients tofit a desiredidentity.

V244 gives DH=B''+C with BOTH orderedV'R' terms,actualV''0. At fixedJ=0,the
Hessian of Bsource remains proportionaltoJ andvanishes;B0'' isretained. Atg1,
HGF1 canbe varied directly andsourcevariation subtractsV0 R1'';V1 R0''=0
becauseactualR0 isaffine. This provides a distinctcoefficientwise construction
ofDH1 from the actualaction,not from the desiredpole. Compare ALL33directions
andallfluctuationpairs,including localtestfunction derivatives.

V257 proves ordinary/source antighostΓ0 andall33insertion0 vanish inthisexplicit
UVfamily. SinceD hasnonegativeg,atg1 onlyD0Γ1 contributes. RecoverΓ1 inputfrom
qualified ordinaryauxiliary,leadingghost andsourcepole records. The graph
catalogue mustshow that allg1 antighostclasses are either thatcompleteauxiliary
scope orqualified leadingghostzero;fieldroles/jets/domains areessential.
Currentpolynomialabsencealone isnotinputcompleteness. Sourcecoverage mustinclude
positive-dimensional classes andtruezero complements,notjustpresentg1words.

The resulting nonzero inhomogeneous antighostcoefficient canbe represented by
an epsilon-anchored localdensity plusfourboundarycurrents. It isNOT a homogeneous
DΓ=0 assertion,anindependentnewintegral,or fullQAP/Slavnovrestoration. Priorub12
CL andtwojetmeasurements provide independent overlap checks onnormalization;
otherdirections relyonthe explicitlydisclosed loop-legreduction. Renormalized
finite/contact/compositeproducts,globalmeasure/IR andquantumequivalence remain.

Background scope:V256 provesD(epsilon) Hcovariant whenepsilontransformsinthe
actualbroken-antighostcarrier. V255giveslocalH-covariant UVcoefficients in the
explicitWeylclass,V257g0zero. Atg1 anydifferenceoftwocovariantcompletions with
the sameflatdensity obeysleadingT0 andvanishesatA=0. EpsilonisinertatT0 even
foranontrivialHcarrier. The V251642-column-per-ghost localA-invisiblekernel
istheninjective separatelyforeachepsilon. ThisestablishesUNIQUEcompletion
ifitexists;theactualorderedlocalBornfamilyprovidesexistence. It doesNOT show
A-dependentrawdensitiesvanish,norautomaticallywrite thatcompletionexplicitly.
No claimofschemeindependence forarbitrarycovariantizationsorphysicalIRremoval.
