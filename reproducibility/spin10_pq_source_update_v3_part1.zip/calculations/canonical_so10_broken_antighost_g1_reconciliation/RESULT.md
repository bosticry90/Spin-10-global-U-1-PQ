# Complete first-order broken-antighost loop-leg reduction V2

Prospective qualification requires completed independent validation_receipt
and committed-byte checks. Neither this report nor native agreement alone is
acceptance. No new independent loop integration is claimed. Authority34/39.

The complete first-order calculation can be reduced to existing action-derived
loop coefficients by legitimate diagram-leg differentiation. The result is a
NONZERO inhomogeneous antighost coefficient across all33 broken directions:
276 epsilon-C-Lambda positions plus132 epsilon-C twojet positions,408total,
with four boundary currents of33 positions each. It is not DΓ=0,and not a
new independent Slavnov cancellation or a completed quantum-restoration proof.

Complete input coverage

The ordinaryg1 antighost projection has12 supported logarithmic profiles in
the qualified2353-profile bare-action catalogue. All are now matched:
 5 F-X ghost-kinetic profiles:qualified complete logarithmic zero;
 3 F-X-X/Q-X auxiliary profiles:qualified measured auxiliary coefficient;
 4 G3-X-X vector/ghost profiles:kinematic first-Taylor zero.
The auxiliary domain is33 auxiliary directions by33 antighost directions by45
ordinary ghosts,including all49005 positions and its H-ghost zero complement.
Actual profiles require LM/aM;light alternatives cannot be silently inferred
from a tensor count. The historically failed inactive candidate remainsFAIL;
the measured action pole isused unchanged. Its canonical node has276positions.

V1 correctly FAILED the coverage gate because the4 vector profiles were not
reconciled. V2 supplies their missing evidence without weakening the gate.
They haveexactlytwo mixedlongitudinal gauge legs andzerojetXi vertices. The
actualYang-Mills cubic contraction with q,r=-q-k is proportionalto
 k_rho*(q dot k)-q_rho*k^2,
which starts at O(k^2). Allfour Lorentz components andall94 mixedreference
blocks arechecked. No totaldegree1 Taylor coefficient can survive,including
when derivatives are assigned toexternal ghosts. No color assumption or
on-shell/EOM condition isused. This is a justified new application of V249's
generic lemma,not reuse ofthe special ub12 numerical value.

All177 dimension-zero sourceprofiles andfive positive-dimensional input
classes remainqualified. Atg1 thetwo supported profiles arethe leading SB-X
source derivative. The complete132-position g1 sourceimage matches the
independently measured canonicalJB-partialC node exactly. Later sourcefree
integrations have nootherg1 antighost cohort,and thesource image is unchanged.
No zero is inferred merely from an absent entry in a partial functional.

Actual insertion and coefficient reduction

B1'' has9912 positions,C1 has16176;their exact sum has15272. A distinct
calculation differentiates the actualGFg1 density and subtracts V0 times the
actualmaster R1 Hessian. It agrees on EVERY coefficient for ALL33 directions,
not only the oldfixedfieldpair. Bsource disappears onlyafter fixedJ=0;V1R0''
vanishes because actualR0 isaffine. Both mixedV'R' terms,gradedsource ordering
andlocalepsilon derivatives remain. The proof doesnotcallub12 field-independent.

The full ordinarypole variation and source correction give an exact408-position
raw DΓg1 density. Anchoringepsilon yields the408-position representative and
four explicitcurrents;allcoefficients,including their widths andsigns,arefixed
by the qualifiedloop inputs. The independently measured ub12 overlap matches
all24 positions (20CL+4twojet). Otherdirections use the disclosed loop-leg
reduction,not a new independent insertion integration.

The reduction differentiates every ordered factor of each Born word with its
original1/n weight. D leaves referenceG/heat/A fixed. V255's finite-coefficient
UV bound permits commuting that derivative andthe logarithmic extraction.
Consequently the pole of the complete orderedDH insertion is the derivative
of the complete measuredpole. This is action-loop differentiation,not fitting
an unknown insertion to a desired Ward cancellation. It remainsessential that
the12-profile andsourceinput completeness premises havebeen established.

The independent rooted g1 census retains20 ORIENTED profiles perdirection:
6 twojet-C,8 onejet-B-C,6 nojet-C-Lambda. This descriptor retains h/k ordering
androotjet placements;its count is not theolder coarser10-profile ub12 count.
All16 ordinaryvertices,masses/orbits,externaljet assignments andproper reference
edges areconsidered. Scalar routes cannotclose atthis order. The onlypossible
coefficient classes arethe three listedabove;the finalvector coefficient in
the differentiated completepole iszero,notassigned toforce symmetry.

Background and larger quantum boundary

V256 supplies actualH-multiplet covariance withtransformingepsilon,V257 gives
zero g0 insertion,and V255 supplieslocalUV covariance in theexplicitWeylfamily.
TheleadingT0 action on epsilon isinert. Differences oflocalg1 completions with
sameflatdata lie in theV251 A-invisiblekernel,which isinjective perghost and
epsilon. Thus the flatnode fixes the integratedlocalcompletion in thisfamily.
Itsdensity has noB/A,so noadditionalA-dependentfunctional atg1 is required;
rawbackground boundarydensities are notclaimed individuallyzero. This isnot
an arbitraryhistoricalscheme or finite/globalIR theorem.

Execution and interpretation

One failedscientific V1coverage run ispreserved,notrelabeled anengineering PASS.
No V1replayran. V2native17.624/17.378sec,private1246150656/1241116672bytes.
Independent verification pending atreportfreeze,with120sec/8GiB/350MiB limits.
Paired tensors/poles/profile descriptors agree;inheritedforward/backward
catalogue CYCLE WITNESSES can differ. Eachroute's actualwitness mustbechecked
againstthe sameprofile,ports andedges ratherthan demandedbyteidentical.
No freshbyte-identical replaypairs claimed. Noaccepted input/Γ/source/policy/
benchmark/scheme/authority changed. Failedquartet normalization remains.

Independent checks reconstruct all15272 DH1 positions withordinarypolynomial
arithmetic,rederive thelongitudinalcubic zero,checkbothcataloguewitnesses,
recountall12/2 sourcefree/sourceprofiles andfivepositiveinputclasses,verify
all408coefficients/currents,and depth-first enumerateeveryrootedenvelope.
Sharedaction/chart/reference,priorloopcoefficients/normalizations,catalogues,
software andAIauthor remainsharedpremises. This isnot independentexpert,
experimental orLean certification. The reduction isnot independentintegration.

FullsourcefreeSlavnov,QAP,measure,contacts,physicalIR,equivalence,E5/A5 and
physicalGUTviability remainunqualified;allsevenflagsfalse,authority34/39.
Known155110/sourcefree40309 areunchanged,asareJacobian/32products/128sourcejets/
508physicalprograms,scalarquantumwarning,HB1/C5block,flavorpause andcustody2/seven.

Next:reassess the complete broken-antighost obligation using the new loop-leg
method andfinitecoupling-order census. Determine which higher-order projections
alreadyhave complete measuredpoles andwhich actuallyrequire missing sourcefree
or composite/renormalization inputs. Do notautomatically begin another selected
integral or mistake the newinhomogeneousrelation forfullQAP/restoration.
