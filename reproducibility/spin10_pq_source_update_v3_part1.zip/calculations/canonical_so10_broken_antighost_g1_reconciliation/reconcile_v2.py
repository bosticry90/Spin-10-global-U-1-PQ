"""Complete g1 pole predecessors,actual DH1 and ordered loop-leg reduction."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import permutations,combinations_with_replacement
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
a=load('actual_g1_antighost_helpers',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;l=a.l;s=a.s;read=a.read;digest=a.digest;PKG=a.PKG

def frole(n):
 if n.startswith('x_'):return 'X_'+n.split('_')[1]
 if n.startswith('ub'):return 'aM'
 if n.startswith('bar'):return 'aH'
 if n.startswith('b'):return 'LH'
 if n.startswith('L'):return 'LM'
 if n.startswith('C'):return 'CH' if int(n[1:])<12 else 'CM'
 if n.startswith('B'):return 'BH' if int(n[1:].split('_')[0])<12 else 'BM'
 if n.startswith('A'):return 'AH'
 raise AssertionError(n)
def dim(r):return 2 if r.startswith('L') else 1
def frozen(z):return tuple(map(frozen,z)) if isinstance(z,(list,tuple)) else z

def rooted(roots,vertices,edges,route):
 options=set()
 for tag,V in vertices.items():
  if V['g']>1:continue
  for ports in V['ports']:
   for i,j in permutations(range(len(ports)),2):
    p,q=ports[i],ports[j]
    if p[0].startswith('A') or q[0].startswith('A'):continue
    ext=tuple(sorted(ports[k] for k in range(len(ports)) if k not in [i,j]));assert sum(dim(r)+j for r,j in ext)+V['cd']>=1;options.add(frozen((tag,p,q,ext)))
 options=sorted(options);states={};profiles=set();tad=set();g0=set()
 for root in roots:
  gp,fam,ports,outer,ej=root;states[root,ports[0][0],ports[1][0],outer,(),(),(),1]=True
 for depth in range(4):
  nxt={}
  for root,start,end,outer,tags,scalars,bb,active in states:
   rg,fam,ports,initial,ej=root;gp=rg+sum(vertices[t]['g'] for t in tags);cd=sum(vertices[t]['cd'] for t in tags);external=1+ej+sum(dim(r)+j for r,j in outer)
   if (end,start) in edges:
    ss=set(scalars)|({end[2:]} if end.startswith('X_') else set());bs=set(bb)|({end} if end.startswith('B') and start.startswith('B') else set());delta=4-external-cd;assert delta>=0
    for mn in range(delta//2+1):
     if mn and not ss:continue
     for masses in combinations_with_replacement(sorted(ss),mn) if mn else [()]:
      tay=delta-2*mn;rank=sum(r.startswith(('B','A')) for r,j in outer)+ej+sum(j for r,j in outer)+tay
      P=(root,tuple(sorted(tags)),outer,ej+sum(j for r,j in outer)+tay,cd+2*mn,tuple(masses),tuple(sorted(bs)),tay)
      if gp==0:g0.add(P)
      if gp!=1 or rank%2:continue
      if active==1 and tay>0:tad.add(P)
      else:profiles.add(P)
   if depth==3:continue
   for tag,p,q,extra in options:
    V=vertices[tag]
    if gp+V['g']>1 or external+sum(dim(r)+j for r,j in extra)+cd+V['cd']>4:continue
    if route=='primary':
     if (end,p[0]) not in edges:continue
     st,ed=start,q[0];edge=(end,p[0])
    else:
     if (q[0],start) not in edges:continue
     st,ed=p[0],end;edge=(q[0],start)
    ss=tuple(sorted(set(scalars)|({edge[0][2:]} if edge[0].startswith('X_') else set())));bs=tuple(sorted(set(bb)|({edge[0]} if edge[0].startswith('B') and edge[1].startswith('B') else set())));nxt[root,st,ed,tuple(sorted(outer+extra)),tuple(sorted(tags+(tag,))),ss,bs,min(2,active+bool(extra))]=True
  states=nxt
 return sorted(profiles),sorted(tad),sorted(g0)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert route in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][route]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('G1_RECONCILIATION_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+route+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 def act(P,I):return m.action(P,I,'primary',True) if route=='primary' else m.action(P,I,'replay')
 def new(n,par):m.index[n]=len(m.names);m.names.append(n);m.par.append(par);return m.index[n]
 tests=[new('zz_da'+str(i).zfill(2),1) for i in range(45)];E=set(tests[12:]);Danti={m.index['ub'+str(i)]:m.elementary(tests[i]) for i in range(12,45)};fields=sorted(m.fields);HH={n:m.elementary(new('zz_h_'+m.names[n],m.par[n])) for n in fields};KK={n:m.elementary(new('zz_k_'+m.names[n],m.par[n])) for n in fields}
 old=b.auth('canonical_so10_broken_antighost_operator',route+'_v2_result.json','validation_v2_receipt.json');V={m.index[n]:h.from_result(rows) for n,rows in old['all33_kernel_maps'].items()};V0={J:{key:z for key,z in P.items() if key[0]==0} for J,P in V.items()};V0={J:P for J,P in V0.items() if P};assert all(gp>=0 for P in V.values() for gp,key in P)
 B1=h.from_result([r for r in old['classical_sourcefree_breaking'] if r['g']==1]);C0=h.from_result([r for r in old['complete_mixed_Hessian_insertion'] if r['g']==0]);C1=h.from_result([r for r in old['complete_mixed_Hessian_insertion'] if r['g']==1]);Bhh=stage('all33_B1_hessian_and_complete_B_C_assembly',lambda:act(act(B1,HH),KK));combined=m.add(Bhh,C1)
 e2,eb=b.sealed('frozen_a10_e2_transport',route);master,mb=b.sealed('frozen_a10_bv_master',route);GF1={key:z for key,z in m.decode(e2['gauge_fixing_density']).items() if key[0]==1};R={J:m.decode(master['source_only_columns'][m.names[n]]) for n,J in m.pairs};assert all(len(key)<=1 for J,P in R.items() for gp,key in P if gp==0)
 def direct():
  Q=act(act(act(GF1,Danti),HH),KK);pieces=[]
  for J,P in V0.items():
   R1={key:z for key,z in R[J].items() if key[0]==1}
   if R1:pieces.append(m.mul(P,act(act(R1,HH),KK)))
  return m.add(Q,m.scale(m.add(*pieces),-1))
 directDH=stage('direct_actual_GF_master_leg_derivative_all_g1_positions',direct);assert directDH==combined
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',route+'_v2_result.json');vertices=inv['actual_sourcefree_vertices'];edges=set(map(tuple,inv['actual_reference_edges']));coverage=b.auth('canonical_so10_source_coverage_reconciliation',route+'_result.json');assert not coverage['incomplete_profiles'] and not coverage['catalogue_extra_scopes'] and len(coverage['profiles'])==177
 kin=b.auth('canonical_so10_ub12_g1_bare_frontier',route+'_v2_result.json');assert kin['literal_gauge_minus_quarter_F_squared_verified'] and kin['vector_ghost_onejet_class_kinematic_zero_before_color_and_integrals'];assert len(kin['four_exact_double_longitudinal_cubic_polynomials'])==4
 tt=s.Symbol('t')
 for text in kin['four_exact_double_longitudinal_cubic_polynomials']:
  p=s.Poly(s.sympify(text),tt);assert p.coeff_monomial(1)==0 and p.coeff_monomial(tt)==0
 anti_profiles=[];unmatched=[];ghost_indices=[];aux_indices=[];vector_indices=[]
 for idx,row in enumerate(inv['all_profiles']):
  if row['g']!=1 or not any(r.startswith('a') for r,j in row['external_ports']):continue
  roles=sorted(r for r,j in row['external_ports']);types=sorted(r[0] if not r.startswith('X_') else 'x' for r in roles);cd=row['vertex_coefficient_dimension']+2*len(row['scalar_reference_mass_expansions']);why=None
  if types==['C','a'] and row['total_external_jets']==2 and cd==0:why='QUALIFIED_COMPLETE_LEADING_GHOST_KINETIC_ZERO';ghost_indices.append(idx)
  elif types==['C','L','a'] and row['total_external_jets']==0 and cd==0 and 'LM' in roles and 'aM' in roles and row['explicit_vertex_xi']==2 and set(row['vertex_family'])<={'F_g1_e0_c0_n3_j1','Q_g1_e1_c0_n4_j0','X_g0_e1_c0_n3_j0'}:why='QUALIFIED_AUXILIARY_M33_A33_C45_MEASUREMENT';aux_indices.append(idx)
  elif types==['B','C','a'] and row['total_external_jets']==1 and cd==0 and row['explicit_vertex_xi']==2 and sorted(row['vertex_family'])==['G3_g1_e0_c0_n3_j1','X_g0_e1_c0_n3_j0','X_g0_e1_c0_n3_j0'] and not row['BB_width_roles']:
   why='ACTUAL_DOUBLE_LONGITUDINAL_G3_FIRST_TAYLOR_ZERO';vector_indices.append(idx)
  anti_profiles.append({'index':idx,'profile':row,'evidence':why})
  if why is None:unmatched.append(idx)
 print('PROFILE_GROUP_COUNTS '+json.dumps({'ghost':len(ghost_indices),'auxiliary':len(aux_indices),'vector_kinematic_zero':len(vector_indices),'unmatched':unmatched}),flush=True)
 assert not unmatched and inv['leading_ghost_twojet_g1_xi_existing_complete_zero_matched'] and len(ghost_indices)==5
 leading_ghost,lb=b.sealed('frozen_a10_e5_ghost_companion',route);assert leading_ghost['complete_ghost_kinetic_companion_calculated'] and leading_ghost['kinetic_log_coefficient']==0
 parent,pb=b.sealed('frozen_a10_e5_auxiliary_vertex',route);assert pb['complete_selected_actual_auxiliary_cubic_pole_qualified'] and parent['actual_group_tensors']['all_external_tensor_entries_including_zeros']==49005 and parent['actual_group_tensors']['H_external_ghost_functional_vertex_zero'] and parent['complete_selected_pole_calculated']
 assert len(parent['comparison']['actual_pole_matrices'])==33 and all(z['shape']==[33,45] for z in parent['comparison']['actual_pole_matrices']) and parent['comparison']['all49005_entries_compared'] and not parent['comparison']['match']
 measured,meb=b.sealed('frozen_a10_e5_measured_functional',route+'_v3');Aux=m.decode(measured['sectors']['auxiliary_g1']);assert len(Aux)==276
 base=b.auth('canonical_so10_e5_remaining_obligations',route+'_result.json');knownanti=h.from_result([r for r in base['complete_sourcefree_polynomial'] if r['g']==1 and any(n.partition('__')[0].startswith(('ub','bar')) for n in r['word'])]);assert knownanti==Aux
 for folder,key,raw in [('canonical_so10_sourcefree_reconciliation','sourcefree_lossless_delta_from_V217',False),('canonical_so10_auxiliary_companion_canonical','new_actual_g3_auxiliary_companion_node',True),('canonical_so10_ghost_companion_integration','new_actual_g3_ghost_companion_node',True),('canonical_so10_unbroken_ghost_quartic_integration','new_derived_g4_unbroken_ghost_quartic_node',True)]:
  data=b.auth(folder,route+'_result.json');P=m.decode(data[key]) if raw else h.from_result(data[key]);assert not any(gp==1 and any(m.names[n].startswith(('bar','ub')) for n,j in word) for gp,word in P)
 current=data;assert current['updated_known_terms']==155110 and current['updated_known_sha256']=='ce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1' and current['source_projection_and_all_untouched_coefficients_identical']
 primitive=b.auth('canonical_so10_local_source_primitive',route+'_v2_result.json');assert primitive['all643_source_maps_match'] and primitive['current_source_positions']==146663;S1=h.from_result([r for r in primitive['normalized_source_image'] if r['g']==1]);lead,sb=b.sealed('frozen_a10_e5_source_vertex',route);assert lead['actual_leading_source_poles_qualified'] and lead['inventory']['all643_pairs_retained'];assert S1==m.decode(lead['canonical_normalization']['gauge_source_derivative_projection']);assert all(sum(n in m.sources for n,j in word)==1 and any(m.names[n].startswith('JB') for n,j in word) for gp,word in S1)
 pos=b.auth('canonical_so10_auxiliary_source_nojet_uv',route+'_result.json');assert len(pos['positive_source_coverage_after_this_input'])==5 and all(r['complete'] for r in pos['positive_source_coverage_after_this_input']);g1source=[r for r in coverage['profiles'] if r['g']==1];assert g1source and all(r['target']=='C_JB__j1' and r['evidence']=='leading_source' and r['status']=='MATCHED_QUALIFIED_SCOPE' for r in g1source)
 EL=m.EL_all(S1,set(V0));source=m.add(*(m.mul(P,EL[J]) for J,P in V0.items()));ordinary=act(Aux,Danti);pole=m.add(ordinary,m.scale(source,-1));N,J=a.odd_anchor(pole,E)
 bg=b.auth('canonical_so10_ub12_background_locality',route+'_v2_result.json','validation_v2_receipt.json');overlap={key:z for key,z in N.items() if any(n==tests[12] for n,j in key[1])};assert overlap==h.from_result(bg['measured_flat_g1_insertion']) and len(overlap)==24
 @lru_cache(None)
 def envelope(roots):return rooted(roots,vertices,edges,route)
 def profiles_by_direction():
  out={}
  for i in range(12,45):
   def roots(P,fam):
    rows=a.l.rows({key:z for key,z in P.items() if any(n==tests[i] for n,j in key[1])});ret=set()
    for row in rows:
     inside=[];outside=[];ej=0
     for n in row['word']:
      base,sep,jet=n.partition('__');jj=len(jet)
      if base.startswith(('zz_h_','zz_k_')):inside.append((frole(base[5:]),jj))
      elif base.startswith('zz_da'):ej=jj
      else:outside.append((frole(base),jj))
     assert len(inside)==2 and 1+ej+sum(dim(r)+j for r,j in inside+outside)==4;ret.add((row['g'],fam,tuple(inside),tuple(sorted(outside)),ej))
    return ret
   rr=tuple(sorted(roots(C0,'C0')|roots(combined,'DH1')));P,T,Z=envelope(rr);assert not Z;out[str(i)]={'roots':rr,'profiles':P,'one_vertex_positive_Taylor_exclusions':T,'target_counts':[[list(k[0]),k[1],k[2],n] for k,n in sorted(Counter((tuple(sorted(r[0] for r,j in p[2])),p[3],p[4]) for p in P).items())]}
  return out
 frontier=stage('complete_all33_bare_rooted_g1_predecessor_envelope',profiles_by_direction)
 controls={'remove_B_hessian_changes_actual_DH1':combined!=C1,'remove_measured_auxiliary_changes_pole_anchor':a.odd_anchor(m.scale(source,-1),E)[0]!=N,'remove_measured_source_changes_pole_anchor':a.odd_anchor(ordinary,E)[0]!=N}
 badN,badJ=a.odd_anchor(pole,E,omit_sign=True);controls['wrong_odd_anchor_prefix_breaks_density_current_identity']=pole!=m.add(badN,*(m.D(P,mu) for mu,P in enumerate(badJ)))
 words=[]
 for n in range(1,5):
  expected={tuple(['G','V']*r+['G','Q']+['G','V']*(n-1-r)):s.Rational((-1)**(n+1),n) for r in range(n)};assert len(expected)==n;words.append([[list(w),str(z)] for w,z in sorted(expected.items())]);controls['omit_one_ordered_position_n'+str(n)]={w:z for ii,(w,z) in enumerate(expected.items()) if ii}!=expected
 assert all(controls.values())
 locality=b.auth('canonical_so10_ordered_multiheat_uv_log',route+'_v2_result.json');module=b.auth('canonical_so10_broken_antighost_dependency_audit',route+'_v2_result.json');gzero=b.auth('canonical_so10_antighost_g0_cycle_exclusion',route+'_v2_result.json');assert locality['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and module['H_multiplet_covariance_qualified'] and gzero['all33_broken_g0_log_insertion_coefficients_zero']
 qc,qb=b.sealed('frozen_a10_e5_quantum_contract',route);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
 result={'schema':'COMPLETE_BROKEN_ANTIGHOST_G1_RECONCILIATION_V1','route':route,'scientific_disposition':'COMPLETE_G1_PREDECESSORS_ACTUAL_DH1_AND_MEASURED_LOOP_LEG_REDUCTION_EXPLICIT_LOCAL_UV_FAMILY','actual_B1_second_variation_positions':len(Bhh),'actual_C1_positions':len(C1),'complete_DH1_positions':len(combined),'all_complete_DH1_coefficients':l.rows(combined),'direct_GF_master_DH1_equals_B_hessian_plus_C_all_positions':True,'sourcefree_g1_antighost_profile_evidence':anti_profiles,'sourcefree_g1_ghost_zero_profile_indices':ghost_indices,'sourcefree_g1_auxiliary_measured_profile_indices':aux_indices,'sourcefree_g1_vector_kinematic_zero_profile_indices':vector_indices,'unmatched_g1_antighost_profiles':unmatched,'current_g1_auxiliary_node':l.rows(Aux),'g1_source_profile_evidence':g1source,'positive_dimensional_input_classes_all5_complete':True,'current_complete_g1_source_node':l.rows(S1),'all33_ordinary_pole_variation':l.rows(ordinary),'all33_source_correction':l.rows(source),'all33_DGamma_g1_raw':l.rows(pole),'all33_g1_anchored_insertion_from_measured_loop_leg_derivative':l.rows(N),'four_exact_boundary_currents':list(map(l.rows,J)),'actual_ub12_overlap24_exact':True,'rooted_g1_frontier':frontier,'all_ordered_Born_derivative_weighted_words_through4':words,'all_word_lengths_by_product_rule_not_a_four_word_truncation':True,'insertion_values_from_leg_differentiation_of_complete_measured_poles_not_fitted':True,'new_independent_loop_integral_or_all33_explicit_insertion_replay':False,'explicit_local_UV_family_only_no_global_QAP_or_physical_scheme':True,'all_seven_quantum_flags_false':flags,'controls':controls,'current_functional_source_input_benchmark_scheme_authority_changed':False,'full_sourcefree_Slavnov_QAP_measure_IR_contacts_E5_A5_proved':False,'shared_limits':'Actual action/reference,prior source/auxiliary/ghost poles and normalization,profile relaxation,SymPy and AI author shared;leg differentiation not independent pole integration or expert validation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
