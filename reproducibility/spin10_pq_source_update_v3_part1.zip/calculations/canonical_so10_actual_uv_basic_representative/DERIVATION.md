# Source-complete actual residue and its explicit algebraic reduction

1. Let R denote the entire normalized one-loop local logarithmic residue of
H=S^(2),including the reference determinant. The inherited theorem proves
QR=0 modulo an ordinary divergence in the specified formal UV family. At a
fixed local dimension/coupling/external degree this residue uses finitely many
symbol terms. The ordered heat theorem identifies it with the integrated
unheated residue; it does NOT replace the covariant inverse by a flat inverse.

2. Change only the auxiliary reference SPLITTING of the same H:
Kcov=Kflat+D(A), Vcov=Vflat-D(A). Both references are source-independent.
The ordered inverse identity is
 (1+(1+d)^(-1)(v+j-d))^(-1)(1+d)^(-1)=(1+v+j)^(-1),
where d=Kflat^-1D,v=Kflat^-1Vflat_without_sources,j=Kflat^-1H_source.
Every factor retains order. This follows by multiplying on the left by
1+v+j; its inverse at external degree0 is1. The geometric formal inverse is
unique. A nonnegative number of reference-mass insertions affects a given
UV residue because each lowers degree. The pre-existing actual principal
inverse handles principal constant blocks. D vanishes at A=0 and hence has
positive external degree; no infinite fixed-degree d expansion is used.

For each source, derivative R_J is the normalized integrated residue of
H^-1 H_J/2,with the inherited graded trace conventions. Thus changing the
reference splitting changes no source coefficient. Integrating the source
scaling parameter from0to1 reconstructs every positive source degree,dividing
only by positive integers. The source-independent Gamma_ref may change the
source-free integration constant; it remains in R and in B below. No finite
trace cyclicity,finite product limit,or arbitrary regulator independence is
inferred. Local residue cyclicity and full reference countervertices are
indispensable. The native finite word checks challenge this algebraic proof.

3. Actual source-dependent local density types have d<=4,gh0,even and no
inverse dimensional coefficient. Q has project dimension1,so canonical
source dimensions are JB/Jx/JC/Ja=2,JL=1. B,x,A,C,a have dimension1,L has2.
The source-free propagating field content and physical AST are those of the
qualified conservative frontiers. The integer type enumeration yields33
coefficient-dimension0 single-source patterns,12 with positive coefficient
dimension,and3 multiple-source patterns; all3 saturate dimension4. The
matched graph census supplies every possible coupling/width/derivative scope,
including mass/reference insertions and the UV/IR-separated no-jet zero.
The 19 inherited scope records and complete zero complements are assumptions
backed by their completed receipts,not newly recalculated amplitudes.
Together with2 this identifies the COMPLETE source projection of R with the
measured146663-position pole. A missing entry in partial Gamma is never used.

4. The qualified actual primitive gives R_source=(QK)_source-div(theta).
Its full source-free image,all508 physical Euler programs and currents stay.
Consequently P=R-QK has a source-free functional representative,using the
recorded theta. QR=Q^2K=0 gives QP=0 in the functional quotient. The current
form matters: if QP=div(m),then P-Pi P=QHP+div(Hm),using the qualified retract.
Density representatives include the source-jet normalization current; signs
are fixed by the displayed R_source equation,not a density-zero assumption.

5. On source-free functions the transported N/U homotopy has hLambda=-a,
ha=0 and fixes B,x,C,A. Count assigns degree1 to a,Lambda and their jets;
Pi deletes both a,Lambda. The full source maps are NOT naive deletion. Actual
643-field rules verify {Q,h}=n,Pi Q=QPi and this restriction agrees with the
previous complete source-inclusive retract. It preserves reality,Tb and jets.
Thus H=sum_(n>0)h/n introduces no inverse physical parameter. Pi P has ghost
number0 but its only remaining positive/negative-ghost candidates are C and
none,respectively. It is independent of C,so B=Pi P contains only physical
B,x,external A and parameters. Q B=0 and iota B=0 give Tqprime B=0 via the
qualified Cartan identity. Tb B=0 follows from the actual background covariance
of R,K and the retract. Hence B is basic and R=B+Q(K+L) modulo currents,
L=HP. This is for the actual residue whose source part was measured,not for
arbitrary source cocycles over the coupling ring. It does not eliminate known
minimal coupling-torsion examples or equate intrinsic and induced quotients.

6. L is source-free,dimension3,gh-1,odd,local and real. Its bounded type space
consists of one antighost with even dimension<=2 material,or two antighosts
and one ghost. Lorentz parity and actual covariance can reduce this space;
no claim that every typed pattern is an invariant independent coefficient.
The construction specifies L by a finite local operator algorithm,not a fitted
array. To turn this algebraic decomposition into a full E5 adequacy theorem,
its one-probe/first-descendant renormalized insertion domain and required
replacement law still need a scope-complete proof. The existing fullK probes
are different objects. At orderhbar a correlated canonical counterterm Q(K+L)
does not require silently adopting a global constant-strength field map.
No quantum-admissible L or full arbitrary-counterterm stability is inferred.
