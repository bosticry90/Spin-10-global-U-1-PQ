"""Actual UV source coverage and source-free restriction; no new loop tensor."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
from itertools import combinations_with_replacement,product
import json,gzip,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
T={'B':(1,0,0),'x':(1,0,0),'A':(1,0,0),'C':(1,1,1),'a':(1,-1,1),'L':(2,0,0),'JB':(2,-1,1),'Jx':(2,-1,1),'JC':(2,-2,0),'Ja':(2,0,0),'JL':(1,-1,1)}
def plus(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out

def typed(role,source_count=1,dim=4,gh=0):
 names=sorted(T);out=[]
 if role=='primary':
  words=(w for length in range(1,dim+1) for w in combinations_with_replacement(names,length))
 else:
  def visit(i,w,d):
   if i==len(names):yield tuple(w);return
   n=names[i]
   for k in range((dim-d)//T[n][0]+1):yield from visit(i+1,w+[n]*k,d+k*T[n][0])
  words=visit(0,[],0)
 for w in words:
  d=sum(T[n][0] for n in w)
  if not w or d>dim or sum(n.startswith('J') for n in w)!=source_count or sum(T[n][1] for n in w)!=gh or sum(T[n][2] for n in w)%2!=(gh%2):continue
  for j in range(dim-d+1):out.append((tuple(w),j,dim-d-j))
 return sorted(out)

def mul(a,b,cap):
 out={}
 for w,c in a.items():
  for v,d in b.items():
   if len(w+v)<=cap:
    out[w+v]=out.get(w+v,F(0))+c*d
 return {w:c for w,c in out.items() if c}
def add(*pp):
 out={}
 for p in pp:
  for w,c in p.items():out[w]=out.get(w,F(0))+c
 return {w:c for w,c in out.items() if c}
def neg(p):return {w:-c for w,c in p.items()}
def inverse_one(x,N):
 I={():F(1)};a=I;out=I
 for n in range(1,N+1):a=mul(a,neg(x),N);out=add(out,a)
 return out

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed=prep['read_json_by_role'][role]
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(s in args[1] for s in 'wax+'):raise PermissionError('AUB_NATIVE_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('AUB_UNDECLARED_JSON',str(p))
 sys.addaudithook(guard)
 auth=prep['artifacts'][role]
 def get(label):
  d=auth[label];p=Path(d['path']);assert digest(p)==d['sha256'];return read(p)
 print('STAGE '+role+' complete_type_scope_bridge',flush=True)
 allsingle=typed(role);zero=[x for x in allsingle if x[2]==0];positive=[x for x in allsingle if x[2]>0];multi=typed(role,2);assert len(zero)==33 and len(positive)==12 and len(multi)==3 and not typed(role,3)
 front=get('frontier');coverage=get('coverage');multiple=get('multiple');dimensionful=get('dimensionful');nojet=get('nojet');pos=get('positive');assert zero==[(tuple(w),j,c) for w,j,c in front['type_patterns']]
 assert not coverage['incomplete_profiles'] and not coverage['catalogue_extra_scopes'] and len(coverage['profiles'])==177 and len(coverage['required_scope_groups'])==28
 assert len(coverage['excluded_patterns'])==15
 expected_positive=[(tuple(r['types']),r['jets'],r['coefficient_dimension']) for r in coverage['positive_dimension_single_source_patterns']];assert positive==sorted(expected_positive)
 allowed_positive=[x for x in positive if (sum(n in ['A','B','JB'] for n in x[0])+x[1])%2==0]
 assert len(allowed_positive)==5
 assert sorted('_'.join(w) for w,j,c in allowed_positive)==sorted(dimensionful['targets'])
 assert get('multiple_assessment')['all_multiple_source_local_one_loop_log_poles_zero_in_retained_system']
 # These are authenticated complete original results, not absent rows interpreted as zeros.
 assert nojet['positive_source_coverage_after_this_input']==5 and nojet['nojet_local_UV']['all_source_ghost_positions']==2025 and nojet['nojet_local_UV']['nonzero_positions']==0
 assert get('uv')['complete_formal_one_loop_log_UV_Slavnov_identity_mod_currents'] and not get('uv')['current_partial_Gamma_claimed_complete']
 print('STAGE '+role+' ordered_reference_splitting_identity',flush=True)
 N=5;I={():F(1)};d={('d',):F(1)};v={('v',):F(1),('j',):F(1)};B=inverse_one(d,N);relative=add(v,neg(d))
 if role=='primary':cov=mul(inverse_one(mul(B,relative,N),N),B,N)
 else:
  # Solve Y+B relative Y=B coefficient by coefficient, without inverting that series.
  X=mul(B,relative,N);cov={}
  for degree in range(N+1):
   rhs=add(B,neg(mul(X,cov,N)))
   cov.update({w:c for w,c in rhs.items() if len(w)==degree})
 flat=inverse_one(v,N);assert cov==flat and all('d' not in w for w in cov)
 wrong=mul(inverse_one(mul(B,v,N),N),B,N);wrong_source={w:c for w,c in add(wrong,neg(flat)).items() if 'j' in w};assert wrong_source
 source_words=sum('j' in w for w in flat)
 print('STAGE '+role+' whole_actual_source_fingerprint_and_primitive',flush=True)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);fields={i for i,J,h,k in geo['field_source_h_k']};sources={J for i,J,h,k in geo['field_source_h_k']};elem=lambda n:{(0,((n,()),)):ONE}
 def rows(rr):
  out={}
  for r in rr:
   for key,co in A.rows([r],explicit_g='g' in r).items():put(out,key,co)
  return out
 primitive=get('primitive');S=rows(primitive['normalized_source_image']);assert len(S)==146663 and all(sum(n in sources for n,j in w)==1 for g,w in S)
 actual_hash=A.fingerprint(S);snapshot=get('integration')['dependent_source_and_scalar_snapshot'];assert actual_hash==snapshot['actual_source_sha256_exact_cells']=='b1171c9963ff4d5fc1c1497ab70d781f1c9ea36e77ce5507563fe70d3af8cc88'
 assert snapshot['all146663_actual_source_positions_equal_qualified_normalized_input'] and snapshot['actual_source_has_no_differentiated_source_fields']
 assert primitive['all643_source_maps_match'] and primitive['boundary_current_matches'] and not primitive['source_image_residual'] and not primitive['qualified_boundary_current_residual']
 K=rows(primitive['full_K']);assert len(K)==3847 and primitive['strict_local_H_generator_invariance'] and len(primitive['retained508_physical_Euler_program_companion'])==508
 print('STAGE '+role+' complete_sourcefree_retract_restriction',flush=True)
 nonmin={i for i in fields if A.names[i].startswith(('L','b','ub','bar'))};aux={i for i in nonmin if A.names[i].startswith(('L','b')) and not A.names[i].startswith('bar')};anti=nonmin-aux;assert len(aux)==len(anti)==45
 mate={i:A.index[('ub'+A.names[i][1:]) if A.names[i].startswith('L') else ('bar'+A.names[i][1:])] for i in aux};assert set(mate.values())==anti
 q={i:rows(data['master_field_maps'][A.names[i]]) for i in fields};hmap={i:scale(elem(mate[i]),-1) for i in aux}
 def h(p,wrong=False):
  out={}
  for(g,w),co in p.items():
   pref=0
   for at,(n,jets) in enumerate(w):
    if n in aux:
     token=(mate[n],jets)
     if role=='primary':word,sg=A.canonical(w[:at]+(token,)+w[at+1:]);sg*=(-1)**pref
     else:word,sg=A.canonical((token,)+w[:at]+w[at+1:]);sg*=(-1)**(A.parities[n]*pref)
     if sg:put(out,(g,word),scale_coefficient(co,sg if wrong else -sg))
    pref+=A.parities[n]
  return out
 def pi(p):return {key:co for key,co in p.items() if not any(n in nonmin for n,j in key[1])}
 retract=get('retract');checks=Counter();wrong_h=[];wrong_pi=[]
 for i in sorted(fields):
  Qh=scale(q[mate[i]],-1) if i in aux else {};actual=plus(Qh,h(q[i]));expected=elem(i) if i in nonmin else {};assert actual==expected,A.names[i]
  assert rows(retract['homotopy_columns'][A.names[i]])==hmap.get(i,{})
  assert rows(retract['projection_columns'][A.names[i]])==pi(elem(i))
  assert rows(retract['count_columns'][A.names[i]])==expected
  assert pi(q[i])==(q[i] if i not in nonmin else {}),A.names[i]
  if plus(scale(Qh,-1),h(q[i],True))!=expected:wrong_h.append(A.names[i])
  pa={k:z for k,z in q[i].items() if not any(n in aux for n,j in k[1])}
  if (q[i] if i not in aux else {})!=pa:wrong_pi.append(A.names[i])
  checks['fields']+=1
 assert wrong_h and wrong_pi
 primitive_types=typed(role,0,3,-1);Lorentz=[x for x in primitive_types if (sum(t in ['A','B','JB'] for t in x[0])+x[1])%2==0]
 assert all(w.count('a')-w.count('C')==1 and w.count('a') in [1,2] for w,j,c in primitive_types)
 # Constructive functional reduction theorem, with independent rational relation check.
 # Vector basis R,B,QK,QL,div(theta),div(Hm). The proof uses Rsource=(QK)source-div(theta).
 residual_relation={'R':1,'B':-1,'QK':-1,'QL':-1};current_terms=['source_jet_theta','H_of_QP_current'];assert len(current_terms)==2
 controls={'omit_multiple_source_zero_refuses_coverage':True,'omit_dimensionful_translation_source_mismatch':bool(primitive['controls']['omit_intrinsic_translation_source_residual']),'one_AXG_momentum_insufficient':coverage['ordinary_jet_quotients']['scalar_vector_threefield_onejet']['quotient_dimension']==2,'omit_reference_countervertex_nonzero_source_words':len(wrong_source),'reverse_homotopy_failed_field_columns':len(wrong_h),'auxiliary_only_projection_failed_field_columns':len(wrong_pi),'boundary_currents_not_assumed_density_zero':True}
 assert all(controls.values())
 result={'schema':'ACTUAL_UV_BASIC_REPRESENTATIVE_V1','route':role,'scientific_disposition':'QUALIFIED_ACTUAL_ONE_LOOP_UV_SOURCE_COMPLETENESS_AND_CONSTRUCTIVE_CLASSICAL_BASIC_REPRESENTATIVE_ONLY','all643_sourcefree_retract_columns_checked':checks['fields'],'single_source_dimension_zero_patterns':len(zero),'positive_dimension_patterns':len(positive),'allowed_positive_dimension_patterns':[[list(w),j,c] for w,j,c in allowed_positive],'multiple_source_patterns':[[list(w),j,c] for w,j,c in multi],'qualified_graph_profiles':177,'qualified_scopes':28,'actual_source_positions':len(S),'actual_source_sha256_exact_cells':actual_hash,'full_primitive_positions':len(K),'physical_Euler_programs_retained':508,'source_current_retained':True,'ordered_reference_inverse_degree':N,'ordered_reference_inverse_source_words':source_words,'ordered_reference_inverse_zero_residual':True,'reference_determinant_retained':True,'nonminimal_field_count':len(nonmin),'sourcefree_primitive_type_domain':[[list(w),j,c] for w,j,c in primitive_types],'Lorentz_allowed_primitive_types':[[list(w),j,c] for w,j,c in Lorentz],'constructive_decomposition':'R=B+Q(K+H(R-QK)) modulo the explicitly retained source normalization and homotopy currents; B=Pi(R-QK)','known_partial_Gamma_used_as_complete':False,'unmeasured295_vector_coefficients_computed':False,'B_or_L_component_tensors_extracted':False,'universal_minimal_cohomology_or_quotient_comparison':False,'quantum_admissibility_of_all_L_primitives_proved':False,'full_E5_A5_or_physical_equivalence':False,'inverse_g_used':False,'actual_residue_not_arbitrary_counterterm_scope':True,'controls':controls,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
