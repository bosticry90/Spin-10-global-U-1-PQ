# V3 four-current zero-complement schema correction

V2 matched the actual146663-position source fingerprint and ordered inverse,
then stopped before a result at a list truth-value assertion. The inherited
current residual is a list of four empty polynomial arrays,not an empty list.
V3 requires every current residual to vanish. The current identity and its
boundary conventions are unchanged. All V2 source/preparation/captures remain.
The dimensionful omission control now checks its actual432 nonzero positions
rather than truth of a summary dictionary. Two failed primaries and one
prelaunch-controller syntax incident remain excluded from qualification.
This is a bounded schema correction under unchanged AUB1 obligations,not a
weakened criterion or changed scientific input. Two complete V3 routes and
separate independent validation are required.
