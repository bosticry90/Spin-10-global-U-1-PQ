# V2 historical-schema correction

The V1 primary stopped before producing any scientific result. It compared
the existing five-entry positive_source_coverage_after_this_input list to
integer5. V2 checks its length and every complete flag,retaining the independent
2025-slot/no-nonzero coefficient checks. No mathematical obligation,input or
pole changed. V1 code,preparation,controller and complete capture remain.
The corrected runs are a new bounded continuation of the unchanged AUB1
contract,not retroactive qualification of V1. One failed native,one prelaunch
controller syntax incident are preserved. Two completed V2 routes and separate
independent validation remain required.
