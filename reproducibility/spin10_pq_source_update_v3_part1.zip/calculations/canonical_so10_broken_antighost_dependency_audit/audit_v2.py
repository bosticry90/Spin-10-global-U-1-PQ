"""Actual broken-antighost kernels,H-module covariance and insertion dependencies."""
from pathlib import Path
from collections import Counter,defaultdict
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
a=load('qualified_antighost_local_maps',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;l=a.l;s=a.s;read=a.read;digest=a.digest;PKG=a.PKG

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('BROKEN_DEPENDENCY_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);w=m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);tt=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-tt});return z
 def act(P,I):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
 tests=[]
 for i in range(45):n='zz_da'+str(i).zfill(2);m.index[n]=len(m.names);tests.append(len(m.names));m.names.append(n);m.par.append(1)
 broken=list(range(12,45));ET=set(tests[12:]);anti={i:m.index['ub'+str(i)] for i in broken};di={anti[i]:m.elementary(tests[i]) for i in broken}
 prior=b.auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');e2,eb=b.sealed('frozen_a10_e2_transport',role);e3,ec=b.sealed('frozen_a10_e3_symmetry',role);core,cb=b.sealed('frozen_a10_e5_full_hessian',role)
 shifts={m.index[n]:m.decode(rows) for n,rows in e2['source_shifts'].items()}
 V=stage('actual33_Frechet_kernel_reconstruction',lambda:{J:act(P,di) for J,P in shifts.items()});V={J:P for J,P in V.items() if P};saved={m.index[n]:h.from_result(rows) for n,rows in prior['all33_kernel_maps'].items()};assert V==saved and len(V)==479
 T={m.index[n]:m.decode(rows) for n,rows in e3['operators']['Tb_geometric_and_transported'].items()};assert len(T)==1334;closure=True;module=[];adj={i:set() for i in broken}
 for i in broken:
  rows=[]
  for row in e3['operators']['Tb_geometric_and_transported']['ub'+str(i)]:
   other=[n for n in row['word'] if not n.startswith('omega')];assert len(other)==1 and other[0].startswith('ub') and '__' not in other[0];j=int(other[0][2:]);closure=closure and j in broken;assert j in broken
   om=next(n for n in row['word'] if n.startswith('omega'));assert '__' not in om;adj[i].add(j);adj[j].add(i);rows.append({'word':[om,'zz_da'+str(j).zfill(2)],'coefficient':row['coefficient']});module.append([i,j,om,row['coefficient']])
  T[tests[i]]=m.decode(rows)
 D={**di,**{J:m.scale(P,-1) for J,P in V.items()}}
 def comms():
  out={}
  for n in sorted(T):
   R=m.add(act(T[n],D),m.scale(act(D.get(n,{}),T),-1))
   if R:out[m.names[n]]=l.rows(R)
  return out
 residual=stage('all1367_actual_H_D_columns_including_epsilon_jets',comms)
 # Omitting the nontrivial epsilon carrier must spoil the field-column test.
 inert={n:P for n,P in T.items() if n not in ET};control_col=next(anti[i] for i in broken if T[tests[i]]);bad=m.add(act(inert[control_col],D),m.scale(act(D[control_col],inert),-1));assert bad
 seen=set();blocks=[]
 for i in broken:
  if i in seen:continue
  todo=[i];comp=[];seen.add(i)
  while todo:
   j=todo.pop();comp.append(j)
   for k in sorted(adj[j]-seen):seen.add(k);todo.append(k)
  blocks.append(sorted(comp))
 assert [12] in blocks
 def direction(key):
  ii=[tests.index(n) for n,j in key if n in ET];assert len(ii)==1;return ii[0]
 per={i:{'kernel_rows':0,'source_columns':set(),'quantum_degree_counts':Counter(),'quantum_field_kinds':Counter(),'source_kinds':Counter(),'kernel_coupling_orders':Counter(),'derivative_epsilon_rows':0,'source_breaking_rows':0,'sourcefree_breaking_rows':0,'mixed_rows':0,'mixed_coupling_orders':Counter(),'mixed_pair_kinds':Counter(),'mixed_external_degree_counts':Counter()} for i in broken}
 for J,P in V.items():
  for (gp,key),z in P.items():
   i=direction(key);r=per[i];r['kernel_rows']+=1;r['source_columns'].add(m.names[J]);qfields=[n for n,j in key if n in m.fields];assert len(qfields)<=1;r['quantum_degree_counts'][str(len(qfields))]+=1;r['source_kinds'][h.kind(J)]+=1;r['kernel_coupling_orders'][str(gp)]+=1
   for n in qfields:r['quantum_field_kinds'][h.kind(n)]+=1
   r['derivative_epsilon_rows']+=int(any(n in ET and jj for n,jj in key))
 def epsrow(row):
  eps=[n.partition('__')[0] for n in row['word'] if n.startswith('zz_da')];assert len(eps)==1;return int(eps[0][5:])
 for key,lab in [('classical_source_breaking','source_breaking_rows'),('classical_sourcefree_breaking','sourcefree_breaking_rows')]:
  for row in prior[key]:per[epsrow(row)][lab]+=1
 for row in prior['complete_mixed_Hessian_insertion']:
  r=per[epsrow(row)];r['mixed_rows']+=1;r['mixed_coupling_orders'][str(row['g'])]+=1;pair=[n.partition('__')[0][5:] for n in row['word'] if n.startswith(('zz_h_','zz_k_'))];assert len(pair)==2;assert all(n in m.index and m.index[n] in m.fields for n in pair);r['mixed_pair_kinds'][','.join(sorted(h.kind(m.index[n]) for n in pair))]+=1
  ext=[n for n in row['word'] if not n.startswith(('zz_da','zz_h_','zz_k_'))];r['mixed_external_degree_counts'][str(len(ext))]+=1
 for i,r in per.items():
  r['source_columns']=sorted(r['source_columns'])
  for k,v in list(r.items()):
   if isinstance(v,Counter):r[k]=dict(sorted(v.items()))
 assert per[12]['quantum_degree_counts']=={'0':21,'1':40};assert per[12]['source_breaking_rows']==per[12]['sourcefree_breaking_rows']==0 and per[12]['mixed_rows']==824
 assert sum(r['mixed_rows'] for r in per.values())==99272 and sum(r['kernel_rows'] for r in per.values())==2589
 transport=b.auth('canonical_so10_source_primitive_transport',role+'_result.json');old=transport['auxiliary_nonlinear_product_insertions'];assert set(old)=={'L'+str(i) for i in range(13,45)}
 oldsummary={n:{'rows':len(rows),'coupling_orders':dict(sorted(Counter(str(r['g']) for r in rows).items())),'word_degrees':dict(sorted(Counter(str(len(r['word'])) for r in rows).items()))} for n,rows in old.items()}
 # Read-only next-frontier census,not a pole or a completeness theorem.
 gf=m.decode(e2['gauge_fixing_density']);g0=Counter()
 for (gp,key),z in gf.items():
  if gp==0 and len(key)>=3:g0[','.join(sorted(h.kind(n) for n,j in key))+';jets='+str(sum(len(j) for n,j in key))]+=1
 names=core['retained_reference']['field_order'];edges=Counter(','.join(sorted([h.kind(m.index[names[i]]),h.kind(m.index[names[j]])])) for i,j,z in core['retained_reference']['reference_Green_raw_C3']['entries'])
 locality=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert locality['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and not locality['physical_IR_measure_QAP_contacts_full_sourcefree_Slavnov_E5_A5_proved']
 # Actual integrated-field part of D is constant in all integrated fields;
 # external source entries are deliberately excluded from a measure trace.
 assert all(not any(n in m.fields for gp,key in P for n,j in key) for P in di.values());source_linear_total=sum(int(r['quantum_degree_counts'].get('1',0)) for r in per.values());assert source_linear_total==1992 and all(r['quantum_degree_counts'].get('1',0)>0 for r in per.values())
 x,y,hb,cov=s.symbols('mean_x mean_y hbar connected_xy');assert s.expand((x*y+hb*cov)-x*y)==hb*cov and hb*cov!=0
 qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
 result={'schema':'BROKEN_ANTIGHOST_DEPENDENCY_AUDIT_V1','route':role,'scientific_disposition':'ALL33_ACTUAL_CLASSICAL_H_COVARIANT_KERNELS_AND_INSERTION_DEPENDENCIES' if not residual else 'ACTUAL_KERNELS_CLASSIFIED_H_COVARIANCE_REMAINDER_PRESERVED','all33_actual_E2_Frechet_maps_match_V244':True,'all33_kernels_are_field_dependent_but_affine':True,'per_direction':{str(i):r for i,r in per.items()},'actual_H_epsilon_module_rows':module,'actual_H_invariant_coordinate_blocks_not_irreducibility_claim':blocks,'all1367_H_D_commutator_residuals':residual,'H_multiplet_covariance_qualified':not residual,'all_parameter_epsilon_derivatives_retained':True,'g0_GF_nonlinear_word_census_not_loop_verdict':dict(sorted(g0.items())),'actual_reference_Green_edge_kind_census':dict(sorted(edges.items())),'prior32_source_primitive_product_summary_DISTINCT_transformation':oldsummary,'prior32_nonzero_measure_diagnostic_and_products_retained':True,'field_part_D_tangent_zero_external_sources_not_integrated':True,'continuum_measure_or_composite_normalization_proved':False,'one_loop_dependency':'Bsource/B0 Hessian plus both ordered mixed Vprime Rprime terms;Vdoubleprime zero,connected products not zero','existing_pole_coverage':'ub12 g0/g1 qualified in explicit local UV family only;no new pole or other32 completion inferred','V255_handoff_field_independence_sentence_refuted_by_actual40_rows':True,'V255_theorem_uses_actual_full_kernel_and_H_commutator_not_false_sentence':True,'controls':{'omit_epsilon_H_carrier_breaks_actual_nontrivial_field_column':bool(bad),'false_ub12_field_independence_refuted':per[12]['quantum_degree_counts']['1']==40,'mean_product_omits_connected_one_loop_fixture':True},'actual_new_quantum_coefficient_or_full_loop_inventory_measured':False,'seven_false_quantum_flags':flags,'source_functional_benchmark_scheme_authority_changed':False,'full_QAP_contacts_IR_measure_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Actual E2/E3/master,V244 kernels and mixed tensor,V219 flow,V255 analytic class,software and AI author shared;not independent expert confirmation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
