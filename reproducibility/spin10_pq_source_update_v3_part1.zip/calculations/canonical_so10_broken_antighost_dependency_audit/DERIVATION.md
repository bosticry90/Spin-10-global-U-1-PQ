# Actual broken-antighost multiplet and one-loop dependencies

Let S=Sphys+sum_J(J+A_J)R_J,with source-left convention fixed by V244.
D(epsilon)=delta_anti(epsilon)-sum_J V_J(epsilon) E_J^L,
V_J=delta_anti A_J. Each actual V is affine in quantum fields;epsilon is an
external odd local test field and D is EVEN. Background fields remain fixed.
The local H action extends to epsilon with the SAME homogeneous antighost
carrier,including the factor g and undifferentiated local omega. Thus all
jets transform by differentiating the complete epsilon*omega product.

A genuine covariance test is [D,T_H] on every actual field/source/background
and every epsilon column. Merely setting epsilon inert would test only an
H-singlet direction. For an H multiplet it gives a false failure. Conversely,
labeling directions as a multiplet does not prove the kernel/source columns
transform correctly. The audit retains all local parameter derivatives and
checks actual operators. This proves covariance of the combined local test
operation if all residuals vanish;it does not prove a quantum Ward identity.

The actual D field part is an additive test-function shift,so its derivative
with respect to EVERY integrated field is zero. A finite-dimensional field
translation has unit Berezinian. Sources are external,so their field-dependent
shift cannot be added to the integrated-field trace or used to cancel a field
Jacobian. The source-primitive transformation of V219 is a DIFFERENT map with
nonzero field supertrace and32 nonlinear L products;those obligations remain.
No global continuum/IR measure theorem follows from the translation fact.

For constant even variations h,k at fixed sources,V244 proves exactly
 DH[h,k]=B''[h,k]+sum_J[(delta_h V_J)(delta_k R_J)
                              +(delta_k V_J)(delta_h R_J)],
 B=sum_J(J+A_J)delta_anti R_J.
All V'' terms vanish only because actual V is affine. The mixed part C need
not vanish. ub12 is a concrete example:B12=0 but C12 has824 positions.
This is why the false field-independence sentence cannot be used as a proof.

In a fixed-mean loop expansion,V(field) affine does NOT imply
 <V R>=V(mean)<R>.
The linear part of V contracts with the linear fluctuation part of R to give
a connected two-point contribution already at one loop. Its ordered quadratic
form is exactly the two mixed terms C above (including graded order). No new
coefficient may be inferred from the value needed to restore an identity.
The actual ordered Born variation inserts B''+C in every allowed position.
At fixed local UV order V255 provides locality/log-symbol correspondence in
its explicit reference class. It does not authorize merging all heat factors
into a single full propagator for the finite regulated amplitude,or define
finite/renormalized composite products automatically.

The present audit counts classical coefficients and dependency types only.
A nonzero B or C is not a measured nonzero pole or anomaly. Existing ub12 g0/g1
and unbroken/source theorems cannot be counted as complete evidence for a new
broken direction. Classical H covariance can justify organizing future work
by multiplets;it cannot supply unmeasured quantum values. Full source-free
Slavnov,QAP,IR,measure,contacts,equivalence,E5/A5 and authority remain unchanged.
