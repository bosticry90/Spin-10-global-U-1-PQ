# V2 canonical test-word correction

V1 primary FAILED after reconstructing the actual33 Frechet kernels. The
new epsilon transformation rows were supplied to the strict decoder with
epsilon before omega,although the extended alphabet places omega first.
Since omega is even,this correction has no Grassmann sign or coefficient
change. V2 retains the exact action,kernels,scope and all covariance/census
checks;only the synthetic row order is corrected. Source/preparation/full
failed capture preserved. No V1 replay ran. Two sequential V2 native runs
and independent verification retain120sec/8GiB/350MiB limits under AGENTS.
