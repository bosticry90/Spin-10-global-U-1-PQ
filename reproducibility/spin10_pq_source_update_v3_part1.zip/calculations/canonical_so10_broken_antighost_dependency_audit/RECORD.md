# Broken-antighost dependency and covariance audit V1

Base f97f60125ebde868d0a1f478ad6d8e24bba781b4. Previous goal turn PROGRESS.
Question:what are the actual remaining33 broken-antighost kernels,which form
a covariant local H multiplet,and what one-loop insertion dependencies do they
imply? Reuse V244 complete kernels/breaking/mixed Hessian and V255 local-word
theorem before any new loop calculation. This can correct navigation errors,
qualify an actual covariance statement or identify its exact failure.

The V255 handoff's phrase D12 was field-independent is incorrect. Authenticated
V243/V244 data already show21 background/constant and40 quantum-field-dependent
ub12 kernel rows. The theorem DERIVATION7 used the full kernel and actual1334
commutators,not that false premise. Preserve old handoff/receipts unchanged;
record the correction and check its scope here. All33 kernels must be classified
by actual rows;do not conflate them with32 source-primitive L13..44 flow maps.

Freeze actual E2 source shifts,master source action,E3 local H columns,all33
V244 kernels,classical Bsource/B0 and99272 mixed-Hessian positions;authenticate
source-primitive transport and V255 receipt. Types:all643 quantum fields and
sources,48 A backgrounds,33 local odd epsilon_i dimension1 ghost-1 fori12..44.
D field part shifts antighost_i byepsilon_i;D J=-V_J;D A=0. Extend H to epsilon
by the actual antighost homogeneous carrier. No EOM,field elimination,source
fit,reference/width/input or scheme change. All original Grassmann order kept.

Two distinct native methods reconstruct the Frechet kernel from actual E2
and compare V244. Check [D,T_H] on all1334 actual columns and33 test columns,
retaining derivative-parameter/epsilon jets. If nonzero,preserve every residual
and classify covariance unqualified;never infer multiplet closure by labels.
Census each direction's independent/linear quantum fields,source columns,
classical breaking,coupling/field/derivative patterns,mixed insertion pairs.
Compare the old32 flow products by exact labels/content,not similar counts.
Finite field-part tangent of D is zero;any translation-Jacobian observation
must be distinguished from source-dependent composite/measure equivalence.

No new pole will be measured. General one-loop dependency uses the actual
identity DH=B''+C (V''=0). Bsource at fixedJ=0 and B0 stay distinct;connected
V'R' corrections cannot be dropped. Within V255 formal local class,these are
local ordered Born insertions;finite/renormalized products still need an
explicit prescription. Establish exact required coefficient classes,not their
unknown values or a full QAP/Slavnov theorem. Reconcile what existing receipts
actually cover and identify the next least expensive missing calculation.

Two sequential read-only native runs plus independent verifier,each120seconds
after imports,8GiB sampledprivate,350MiB minimum availablecommit. Own-role JSON
read guards,immutable sources/controller/input hashes,complete captures. Preserve
failed/unfinished runs,correct only through new frozen versions. Distinct
slot-insertion/left-partial routes;independent sparse ordinary-polynomial H
covariance and row census. Sensitive epsilon-carrier omission and false
field-independence controls;disclose any insensitive checks. No fullGamma,
full Hessian reconstruction,parameter search,new benchmark,quantum loops or
protected scientific promotion. Local commit only after completed validation.
Allseven flagsfalse,E5/A5 unqualified,authority34/39,blocked/paused work unchanged.
Shared action/chart/E2/E3/software/AI author;not independent expert confirmation.
