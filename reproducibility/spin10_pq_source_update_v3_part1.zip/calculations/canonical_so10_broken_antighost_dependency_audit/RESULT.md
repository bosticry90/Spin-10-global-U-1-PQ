# Actual broken-antighost covariance and dependency audit V2

Prospective qualification requires completed independent receipt and committed
byte checks. Native agreement alone is not scientific acceptance. No new quantum
pole or source-free identity is claimed. Authority remains34/39.

All33 broken-antighost kernels reconstructed from the actual E2 source shifts
match qualified V244 exactly:479 active source columns,2589 coupling-resolved
rows,597 quantum-field-independent and1992 linear in quantum fields. ALL33
kernels are field dependent but affine. The V255 handoff sentence calling D12
field-independent was false:ub12 has21 background/constant plus40 linear rows.
Preserve that handoff unchanged as history. V255's actual derivation used all61
kernel entries,the full mixed insertion,and actual1334 H commutators;it did
not assume kernel field independence,so that bounded theorem is unchanged.

Extending the local H action to the33 epsilon test functions by the actual
antighost carrier gives ZERO commutator on all1367 columns:643 fields,643
sources,48 backgrounds,33 test functions. Both epsilon and gauge-parameter
jets are retained. The primary uses even slot insertion;replay uses the signed
left-partial implementation. Omitting epsilon's H transformation produces a
nonzero field-column defect. The actual kernel multiplet is classically
H covariant. No quantum amplitude is supplied by this fact.

The carrier has nine invariant coordinate blocks:
 [12];[13,14,19];[15,16,20,21,24,25];[17,18,22,23,26,27];
 [28];[29];[30,31,34,35,39,40];[32,33,36,37,41,42];[38,43,44].
These are coordinate blocks,not a certified irreducible decomposition or
permission to calculate one favorable representative per block. Only12 is
H inert;single-coordinate blocks28 and29 still have nonzero H transformations.

The per-direction evidence table covers1016 source-breaking positions,9696
sourcefree-breaking positions and all99272 mixed-Hessian positions. Only12
has zero classical breaking. Its824 mixed positions remainnonzero. Acrossall33,
mixed support has552 positions atg0,16176 atg1,82544 atg2. Field-pair kinds are
BB,BC,CC,CL,Ca;no scalar field is in these mixed pairs. Counts are polynomial
positions,not measured loop coefficients or physical processes.

One-loop dependency classification

The actual classical identity DH=B''+C retains BOTH ordered mixed V'R' terms.
V'' vanishes because kernels are affine;C does not vanish. In a fixed-mean loop
expansion the linear part of V can contract with the linear fluctuation part
of R,so <VR> cannot be replaced by V(mean)<R>. Within the V255 explicit formal
local UV class these are well-defined local ordered Born-insertion questions.
Their pole coefficients must still be calculated or supported by qualified
zeros. Finite products/contact subtraction and continuum measure remain separate.
Do not merge all heat factors into an unheated full inverse for finite terms.

The integrated FIELD part of D is a constant antighost test shift;its entire
field tangent is zero. A finite-mode translation has unit Berezinian. External
source shifts are not integrated fields and cannot cancel a field Jacobian.
This does not settle the continuum measure or quantum equivalence. The earlier
source-primitive L13..L44 transformation is a DIFFERENT map;all32 quadratic
product inventories and its nonzero supertrace remain. Similar counts do not
identify the two transformations or resolve their renormalization obligations.

No additional broken-direction pole is qualified here. Existing ub12g0/g1
and unbroken/source theorems keep their exact scopes. The following small
read-only census identifies the next cheap test rather than measuring it:
all276 g0 nonlinear GF words have type C,L,a with no derivatives. Actual
reference Green nonzero edge kinds are BB(752),BL(376),Ca(94),xx(328),with no
LL or mixed scalar/nonminimal edge. This suggests a g0 closed-cycle exclusion
for external antighosts,but full quadratic-reference and physical-action
coverage must be checked before turning that observation into a pole zero.

Validation and research capability

One V1 native failed on synthetic epsilon/omega NONCANONICAL_INPUT ordering.
Because omega is even,reversing those two factors introduces no sign or
coefficient change. V2 preserves all scientific checks,failed source/capture
and120sec/8GiB/350MiB limits. Native primary6.152sec/replay6.208sec,private peaks
597606400/593321984bytes. Independent verification pending at report freeze.
It reconstructs actual Frechet kernels and every extended commutator using an
ordinary-polynomial route,then separately recounts every kernel/breaking/mixed
position and the topology census. Fresh byte-identical replay pairs claimed0.

This audit caught an incorrect recent planning premise and prevented its
transfer to further work. It also establishes classical covariance across the
complete remaining kernel multiplet. Shared actual actions,E2/E3,prior mixed
tensor,locality theorem,software and AI author limit independence. No expert,
Lean or experimental certificate. No source,functional,input,scheme,benchmark
or protected authority change. Seven quantum flagsfalse;full QAP/IR/contacts/
measure/sourcefree Slavnov/E5/A5 unqualified. Existing failures/blocks preserved.

Next smallest action:check complete actual g0 quadratic-reference matching,
physical scalar separation and source-Hessian degree,then certify or refute
the proposed closed-cycle exclusion for all external antighost directions.
Only after that select the smallest genuinely unmeasured insertion coefficient.
