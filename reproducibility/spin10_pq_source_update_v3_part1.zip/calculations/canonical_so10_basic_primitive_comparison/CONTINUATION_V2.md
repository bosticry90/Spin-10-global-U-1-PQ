# BPC1 V2 continuation after an insensitive omission control

PrimaryV1 FAILED at the assertion that EACH of three actual fixtures must
change if EITHER chart is omitted. It had passed the45 Noether identities
and the reached fixture's full1286 canonical-column comparison. No qualified
result or replay was produced. Original source,preparation and full capture
remain immutable. The failed control does not identify a mathematical
counterexample to the primitive theorem.

V2 retains every full canonical-column/basic/source/current requirement.
It records actual omission sensitivity separately for every fixture and
calibrates both omissions on the bound PBL paired-H primitive,whose hash
must reproduce the previous qualified result. This small calibration is
necessary to test the new code in a case that distinguishes both maps;
it is not a new loop calculation or replay of the expensive PBL proof.
No insensitive control may be reported as sensitive. Interpret any newly
observed invariance explicitly after the runs. Native caps120/120seconds,
verifier180seconds,8GiB sampledprivate/350MiB floor/8MiB package unchanged.
No physical input,source sign,operator or scientific authority is changed.
