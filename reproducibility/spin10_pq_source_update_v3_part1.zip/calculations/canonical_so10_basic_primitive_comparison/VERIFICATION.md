# BPC1 completed qualification

Actual completed receipt:validation_receipt_v2.json,SHA256
14bf18c1d0585e9d47c975ff4e95ada0959b4f98cde0e37f96f01651aad7b743. Scientific disposition:
QUALIFIED_INTRINSIC_INDUCED_ALGEBRAIC_BASIC_EXACT_IMAGE_EQUALITY_IN_DECLARED_POLYNOMIAL_LANGUAGE.
PrimaryV2 14.557248s,replayV2 15.011167s,
independentV2 12.394262s after imports. Largest observed
sampled private allocation 733126656B,not a true peak-memory guarantee.
All remain below120/120/180seconds,8GiB sampledprivate and8MiB package.
All111 independent-validation input bytes remain authenticated unchanged.

## New evidence and reused premises

The native routes verify the45-dimensional adjoint projection inside
End(ad so10),dimension2025,with Gram8 and complete sparse transpose
factorization. Primary uses real10x10 planes;replay uses the actual first10
scalar copy. The independent verifier reconstructs the bracket from the raw
ghost action and its physical gauge frame. The trace-pairing proof covers
arbitrary unknown z,not only the numerical controls.

All45 global Noether generators match actual signed source Euler columns
and physical representations. All1286 beta Hamiltonian field/source columns
are checked for each. The scalar representation has7602 plane-basis nonzero
positions;these are algebraic entries,not physical particles or loop integrals.
The complete physical Euler/master/Noether programs are reused as qualified
premises. Neither a fresh expansion of all508 physical Euler tensors nor a
new quantum amplitude is claimed. The whole34-term AST is freshly checked
atg0;an independent functional Euler calculation proves the free Maxwell
Noether divergence needed for the finite polynomial current shift.

Three actual C=U N_chart^-1 fixtures compare all1286 Hamiltonian columns by
native Euler gradients versus direct conjugation. Independent right-to-left
suffix polarization freshly matches every one of the3858 columns,including
all zero complements and their hashes. PostC primitive positions are1014,
1155 and1749. The closed and same-image nonbasic fixtures each have64
contraction positions;the basic PM fixture has zero. Subtracting the closed
generator reproduces the basic primitive exactly.

The PM primitive is INVARIANT under the nonminimal point map. Omitting N
is therefore INSENSITIVE for that fixture. It remains sensitive to omitted U.
Both other fixtures change under either omission. The independently calibrated
paired-H primitive reproduces its previous qualified hash and detects both
omissions. No insensitive control is relabeled as sensitive.

The H-centralizer/background-A diagnostic has20 nonzero colour coefficients
in its derivativeomega Lorentz0 projection. The covariant sum over allfour
Lorentz directions has80 derivativeomega positions. Additional A*omega
terms are not counted in80;the independent derivativeomega coefficient alone
is decisive. No preferred Lorentz direction is adopted. Constantomega/A0
would erase this diagnostic and is explicitly insufficient.

## Preserved failures and independence limits

NativeV1 FAILED at an overstrong negative-control assertion on the PM fixture.
It is preserved with its original source/preparation/full capture. V2 retains
all physical,source,column,current and comparison obligations and records the
actual per-fixture sensitivity;the paired-H calibration checks new code.

VerifierV1 FAILED at an input-name whitelist that omitted the frozen potential's
Phi,Sigma,SigmaBar,phi,phiBar,S,SBar aliases. V2 recognizes those declared names
through the action index domains and referenced A31 metadata/interpreter.
The same g0 degree requirement passes. The embedding metadata is authenticated,
not newly scientifically requalified. Original verifier/preparation/full
capture remain unchanged. One failed native,one failed verifier;no completed
native was rerun for the validation repair.

Shared action/master/Noether proofs,source conventions,coordinate maps,analytic
predecessors,Python/SymPy and AI authorship remain. No Lean theorem certificate,
independent scientist,experiment or physical-scheme validation is supplied.
Old completed loops and broad audit are reused,not rerun.

The comparison is at grades(4,0) for exact images and(3,-1) for primitives.
It is not an isomorphism theorem at every ghost number or operator dimension.
CoChains use original fields/sources/externalA;omega is a local variation
parameter,not an extra counterterm field. The g cancellations occur in
coefficient equations or modulo ordinary derivatives,NOT in BRST cohomology.
The old unweighted coupling torsion is not erased.

State113/authority34of39,E5/A5unqualified,custodyexit2/seven and all protected
blocked/paused stages/physical warnings remain unchanged.
