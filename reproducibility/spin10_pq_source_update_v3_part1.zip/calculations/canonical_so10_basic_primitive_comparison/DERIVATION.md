# BPC1 proposed proof,subject to frozen independent qualification

## 1. Reduce an arbitrary full primitive without assuming Ward invariance

Let F=QG modulo an ordinary divergence,and suppose F belongs to the declared
joint basic local-functional domain. Work first in the qualified beta chart.
The old nonminimal maps satisfy pQ=Qp,QH+HQ=1-p,and p/H preserve the joint
basic domain. Thus pF=Q(pG) modulo currents is basic,even if pG is not.
The complete positive-dimensional primitive census permits only

 G_min=-JB.(N B+M A_H)-Jx.(U x+v)+JC.z.C+div(k.JB).

All coefficients are arbitrary admitted real polynomials with their actual
mass grades. v has dimension1. No source-free negativeghost primitive or
minimal sourcequadratic term exists. Div(kJB) is an explicit ordinary current;
its local probe descendants must be retained,not silently set zero as a density.
The only ghost factors of the minimal primitive occur in JC.z.C.

The JC.C.C coefficient of QG_min has t=-g*d_CE z. Basicness of the IMAGE
therefore gives d z(h,b)=0 for all h in H,b in so10,coefficientwise. This
uses formal g being a nonzero divisor,not a 1/g primitive. Do not assume z
H-equivariant:the generator itself need not be background invariant.

## 2. Remove the inner adjoint component explicitly

Use the actual compact orthonormal45-plane metric,with ad_i skew and
sum ad_i^2=-8I. For arbitrary z in End(ad g),define

 y=(1/8)sum_i[e_i,z(e_i)],   pi_ad(z)=ad_y,   w=z-ad_y.

Hilbert-Schmidt pairing gives <ad_v,z>=8<v,y> and <ad_v,ad_y>=8<v,y>.
Hence pi_ad is the orthogonal projection onto the45-dimensional adjoint
submodule,inside End(ad g) of dimension2025. No2025-square inverse is used.
The projection intertwines the full compact adjoint action. The orthogonal
complement is stable under commutators with ad_h,by skew-adjointness.

The mixed CE equation is

 [ad_h,z]+ad_(z h)=0.

Substitute z=ad_y+w. Jacobi cancels the inner component,leaving
[ad_h,w]+ad_(w h)=0. The first term is orthogonal to ad(g);the second belongs
to ad(g). Both vanish. The actual zero center then gives w h=0,and the
remaining equation gives H-equivariance of w. This is a COMPLETE module
argument,not a fit of z coefficients or an assumption about their measured values.

## 3. The subtracted generator is closed for the actual action

The constant-colour Spin10 generator for this SAME y is

 J_y=-JB.[y,B]-Jx.rho_y*x+JC.[y,C].

Its field flows are V_B=[y,B],V_C=[y,C],V_x=rho_y*x;all nonminimal beta
flows vanish. It is generally not basic. The scalar term is essential.
The scalar representation is the actual54+252+20+2 real representation,
and the evaluated sources use its actual inverse-dual convention.
This is not globalPQ and it does not rescale the physical gauge coupling.

A direct proof of closure uses the COMPLETE ghost-source identity

 Q(JC.y)=div(JB.y)-g J_y.

All45 identities are reconstructed from the actual source action with left
Euler/ordinary-IBP signs and independently from the physical representations.
The physical action has no ghosts,so this source Euler column has no omitted
physical-action term. It does NOT follow that its next Q variation omits
physical Eulers:QJB includes the FULL actual physical Euler program.

The inherited full master identity gives
 g QJ_y=div(QJB.y). At g0,QJB is the free Maxwell Euler column E0;the literal
34-term action and old Noether certificate give div E0=0 off shell. Expand
QJB=E0+sum_(n>=1)g^n E_n. Then

 QJ_y=div(sum_(n>=1)g^(n-1)E_n.y).

This explicit finite polynomial current contains the physical and source
programs,with NO inverse g. Cancellation of g on local functionals is also
justified because ordinary differentiation acts coefficientwise on this
polynomial ring. The current construction makes that justification concrete.
No source-polynomial-only approximation or physical equation of motion is used.

Equivalently,the actual covariant physical action is invariant under the
constant colour rotation,and the source action intertwines it. The source
identity/master proof above supplies the stronger signed action-based check.
For an arbitrary polynomial y(g,parameters),its coefficients remain spacetime
constant,so the same construction applies coefficientwise with the same currents.

## 4. Horizontal primitive and the independent external-background condition

Set G1=G_min-J_y. The image QG1 remains pF modulo the polynomial current.
Its ghost matrix is w,which kills H;hence iota G1=0 as a functional. The
qualified Cartan identity and basicness of pF give Tq G1=0 modulo currents.
This conclusion does not follow for the ORIGINAL generator before subtraction.

In the beta chart Tb-Tq acts only on external A_H,with
Aext A_H=D[A_H]omega. The sole explicit-A primitive carrier is -JB.M.A_H.
Therefore

 Tb G1=-JB.M.D[A_H]omega modulo currents.

Since [Q,Tb]=0 and Tb(pF)=0,Q(TbG1)=0 modulo a current. Its independent
JB source coefficient is the commutator of the actual BRST rule with the
external-only vector shift M D[A]omega:

 -g [M D[A]omega,C].

Signs are derived from the actual source-left commutator. The sign is not
important to zero,but must still match. Arbitrary derivativeomega jets force
[M h,C]=0 for every gauge direction C. The FULL so10 center is zero,so M=0.
A nonzero H-centralizer vector is not a full-gauge center and cannot evade
this test. Physical/source-free Euler terms cannot cancel an independent
JB.C.domega source coefficient. A constant-omega specialization would miss it.
Thus G1 is also Tb-invariant,so it is a joint basic primitive.

## 5. Reconstruct the full primitive and equality of exact-image spaces

Let Cchart=U N_chart^-1 be the SAME qualified canonical chart to E2.
The actual full basic primitive is

 G_basic=Cchart(pG-J_y)+H'F,

with the beta interpretation of pG and H' the transported nonminimal homotopy.
Because F is basic,H'F is basic. The identity QH'+H'Q=1-p' and the previous
minimal result give QG_basic=F modulo the explicit transported currents.
All operations preserve real structure,positive mass grades and the polynomial
ring. H' is not asserted to be Hamiltonian;its OUTPUT is an admitted odd
primitive,and is implemented as such. Basic quadratic-source examples from
SQP1 remain part of the preserved evidence.

It follows at the specified grades that
 B_basic intersect Q(K_full)=Q(K_basic) modulo ordinary currents,
where K_full is the entire stated local primitive language,without imposing
background invariance in advance. The converse inclusion is immediate from
Cartan/background closure. This is the exact-image comparison missing after
PBL1's representative surjectivity. The old nonhorizontal raw ghost image is
not withdrawn;its quotient replacement and its literal failure remain distinct.

## 6. Quantum scope and independent evidence

The sourcefree/one-source/two-source general first-probe constructions provide
the existing formal one-loop connected-insertion route for G_basic and J_y.
All physical Euler programs,source derivatives before zeroing,local probes,
reference determinant,raw heat/Jacobian,power and first-dimension-jet finite
conversions remain. A polynomial boundary current becomes a derivative-probe
insertion;it is not zero after localization. No global unit-strength field
change or naive mean-field substitution is inferred. At an orderhbar action
normalization,loop generator/measure cross effects begin at hbar2;unit probes
retain their own one-loop responses.

This comparison is an algebraic equality in the explicit gauge/scalar local
language,with a bounded quantum-implementation route. It is not all-order
QAP,full A5/E5,a physical-parameter catalog,HB1/C5 activation or a physical GUT.
The actual full quantum/physical acceptance obligations remain separate.
The action,older master/Noether and analytic proofs,coordinate maps,software
and AI authorship are shared dependencies,not independent expert validation.
