"""Independent exact-image comparison and all actual canonical Euler columns."""
from pathlib import Path
from hashlib import sha256
from itertools import product,combinations,combinations_with_replacement
import json,gzip,sys,os,time,threading
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_basic_primitive_comparison'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BPC_VERIFY_WRITE')
sys.addaudithook(readonly);prep=read(O/'preparation_v2.json');a=read(O/'primary_v2_result.json');b=read(O/'replay_v2_result.json')
assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_v2_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 for v in prep['artifacts'][role].values():
  assert digest(Path(v['path']))==v['sha256']
  if 'receipt' in v:assert digest(Path(v['receipt']))==v['receipt_sha256']
get=lambda label:read(Path(prep['artifacts']['replay'][label]['path']))
def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(z) for i,j,z in p['entries']})
def nz(m):return {k:s.expand(v) for k,v in m.todok().items() if s.expand(v)!=0}
phys=get('physical');Q=mat(phys['C3_plane_to_parent']);Qi=Q.inv();data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10')
print('STAGE verifier adjoint_projection_from_raw_ghost_kernel_and_trace_proof',flush=True)
f={};outcols={a:[(i,v) for(i,aa),v in Q.todok().items() if aa==a] for a in range(45)};inrows={a:[(j,v) for(aa,j),v in Qi.todok().items() if aa==a] for a in range(45)}
def accum(d,k,v):
 w=s.expand(d.get(k,0)+v)
 if w:d[k]=w
 else:d.pop(k,None)
for aa in range(45):
 for row in data['master_field_maps'][f'C{aa}']:
  bb,cc=[int(x[1:]) for x in row['word']];v=-s.expand(s.sympify(row['coefficient'])).coeff(g,1)
  for b0,c0,sg in [(bb,cc,1),(cc,bb,-1)]:
   for i,v0 in outcols[aa]:
    for j,v1 in inrows[b0]:
     for k,v2 in inrows[c0]:accum(f,(i,j,k),sg*v*v0*v1*v2)
assert len(f)==720
ad=[s.MutableSparseMatrix(45,45,{(i,k):v for(i,j,k),v in f.items() if j==h}) for h in range(45)];adj=lambda v:sum((v[i]*ad[i] for i in range(45) if v[i]!=0),s.zeros(45))
gram=s.Matrix(45,45,lambda i,j:s.trace(ad[i].T*ad[j]));assert gram==8*s.eye(45)
def py(Z):
 return s.Matrix([s.expand(s.trace(ad[i].T*Z)/8) for i in range(45)])
# The45 Gram constraints give projection idempotence/rank. Its720 nonzero
# transpose coefficients plus all zero positions cover every End(ad) input.
for i,r,c in product(range(45),repeat=3):assert f.get((i,c,r),0)==f.get((r,i,c),0)
for i in range(45):assert py(ad[i])==s.eye(45)[:,i]
QH=Q[:,:12];PH=(QH*(QH.T*QH).inv()*QH.T).applyfunc(s.simplify);PM=s.eye(45)-PH;yidx=a['chosen_nonbasic_physical_generator'];y=s.eye(45)[:,yidx];Z=ad[yidx]+PM;W=Z-adj(py(Z));assert py(Z)==y and not nz(W-PM) and not nz(W*QH)
assert py(-ad[yidx])==-y and py(ad[yidx])!=(-y)
for h in range(12):
 ah=adj(Q[:,h]);assert not nz(ah*Z-Z*ah+adj(Z*Q[:,h]));assert not nz(ah*W-W*ah)
 assert py(ah*Z-Z*ah)==ah*py(Z)
# Universal proof:the ad-submodule is stable and ad_h is internally skew,
# so <ad_v,[ad_h,w]>=-<ad_[h,v],w>=0 for any orthogonal w. Projecting
# [ad_h,w]+ad_(wh)=0 therefore yields ad_(wh)=0,and Gram8 gives wh=0.
# This is a symbolic Hilbert-Schmidt proof,not finite-sample extrapolation.
L=s.Matrix([[0,s.Symbol('l0'),s.Symbol('l1')],[-s.Symbol('l0'),0,s.Symbol('l2')],[-s.Symbol('l1'),-s.Symbol('l2'),0]]);U=s.Matrix(3,3,s.symbols('u0:9'));V=s.Matrix(3,3,s.symbols('v0:9'))
assert s.expand(s.trace(U.T*(L*V-V*L))+s.trace((L*U-U*L).T*V))==0
print('STAGE verifier complete_primitive_carriers_and_full_actual_Noether_current',flush=True)
source={'JB':(2,-1,1,1),'Jx':(2,-1,1,0),'JC':(2,-2,0,0)};field={'A':(1,0,0,1),'B':(1,0,0,1),'x':(1,0,0,0),'C':(1,1,1,0)};patterns=[]
for ns in [1,2]:
 for ss in combinations_with_replacement(sorted(source),ns):
  for nf in range(3):
   for ff0 in combinations_with_replacement(sorted(field),nf):
    ww=sorted(ss+ff0);dd,gh,pa,lo=[sum(source[n][i] for n in ss)+sum(field[n][i] for n in ff0) for i in range(4)]
    if dd>3 or gh!=-1 or pa%2!=1:continue
    for nd in range(4-dd):
     if (lo+nd)%2:continue
     for js in product(range(nd+1),repeat=len(ww)):
      if sum(js)==nd:patterns.append([ww,list(js),3-dd-nd])
assert sorted(patterns)==[[['A','JB'],[0,0],0],[['B','JB'],[0,0],0],[['C','JC'],[0,0],0],[['JB'],[1],0],[['Jx'],[0],1],[['Jx','x'],[0,0],0]]
action=get('action');assert len(action['local_terms'])==34
def degree(n):
 kind=n['node']
 if kind=='ExactScalar':return {(0,0)} if s.sympify(n['value'])!=0 else set()
 if kind=='Parameter':return set() if n['name']=='g10' else {(0,0)}
 if kind=='Field':
  assert n['name'] in ['B','x_Phi','x_Sigma','x_phi','x_S'];return {(0,1)} if n['name']=='B' else {(1,0)}
 if kind in ['StructureConstant','RepresentationGenerator','InvariantTensor']:return {(0,0)}
 if kind=='PartialDerivative':return degree(n['argument'])
 if kind in ['GroupContraction','LorentzContraction']:return degree(n['expression'] if 'expression' in n else n['argument'])
 if kind=='OrderedProduct':
  out={(0,0)}
  for p in n['factors']:out={(a+c,b+d) for a,b in out for c,d in degree(p)}
  return out
 if kind=='Add':return set().union(*(degree(p) for p in n['terms']))
 raise AssertionError(kind)
deg=[degree(t['density']) for t in action['local_terms']];assert deg[0]=={(0,2)} and all(ds and all(sc>=2 and bc==0 for sc,bc in ds) for ds in deg[1:])
# Fresh functional Euler proof of free Maxwell divergence,with Minkowski
# metric. Constant colour/source frame coefficients commute with derivatives.
coords=s.symbols('X0:4');B=[s.Function('b'+str(i))(*coords) for i in range(4)];eta=(1,-1,-1,-1);fb=lambda mu,nu:s.diff(B[nu],coords[mu])-s.diff(B[mu],coords[nu]);L0=-sum(eta[mu]*eta[nu]*fb(mu,nu)**2 for mu,nu in product(range(4),repeat=2))/4
E0=[s.diff(L0,B[mu])-sum(s.diff(s.diff(L0,s.diff(B[mu],x)),x) for x in coords) for mu in range(4)];assert s.expand(sum(s.diff(E0[mu],coords[mu]) for mu in range(4)))==0
e2=get('e2');programs={n:v['physical_program'] for n,v in e2['complete_columns'].items() if v['physical_program']};assert len(programs)==508
assert a['polynomial_Noether_current_program']['all180_gauge_physical_programs_retained'] and not a['polynomial_Noether_current_program']['physical_Eulers_put_on_shell']
# Only div E0 is removed. QJB-E0 is shifted coefficientwise as a program
# for this SAME action. This cancels g modulo ordinary derivatives,not in
# BRST cohomology,where the older coupling torsion can still survive.
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values());names=sorted(fields|sources);ghosts={A.index[f'C{i}'] for i in range(45)};physical={i for i in fields if A.names[i].startswith(('B','x_'))}
def elem(n,j=()):
 if isinstance(n,str):n=A.index[n]
 return {(0,((n,j),)):ONE}
def plus(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def mul(*pp):
 out={(0,()):ONE}
 for p in pp:out=A.product(out,p)
 return out
def D(p,mu):
 out={}
 for(gp,ww),co in p.items():
  for at,(n,j) in enumerate(ww):
   w1,sg=A.canonical(ww[:at]+((n,tuple(sorted(j+(mu,)))),)+ww[at+1:])
   if sg:put(out,(gp,w1),scale_coefficient(co,sg))
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def grad(p):
 # Right-to-left suffix polarization. For odd G,left/right gradients agree.
 out={}
 for(gp,ww),co in p.items():
  assert sum(A.parities[n] for n,j in ww)%2==1
  suffix=0
  for at in reversed(range(len(ww))):
   n,j=ww[at];put(out.setdefault((n,j),{}),(gp,ww[:at]+ww[at+1:]),scale_coefficient(co,(-1)**(A.parities[n]*suffix)));suffix+=A.parities[n]
 return out
def ELodd(p):
 out={n:{} for n in names}
 for(n,j),pp in grad(p).items():
  if n in out:out[n]=plus(out[n],scale(DD(pp,j),(-1)**len(j)))
 return out
def sub(p,mp):
 out={}
 for(gp,ww),co in p.items():
  q={(gp,()):co}
  for n,j in ww:q=mul(q,DD(mp.get(n,elem(n)),j))
  out=plus(out,q)
 return out
def sc(p,z):return mul(A.rows([{'coefficient':str(z),'word':[]}],explicit_g=False),p)
# Reconstruct the45 generators from independently bound Noether physical
# covectors and a direct ghost-source Euler derivative (even source action).
old=get('regularity')['Noether'];Sghost=plus(*(mul(elem(Jof[i]),A.rows(data['master_field_maps'][A.names[i]],explicit_g=False)) for i in ghosts));ghost_el={i:{} for i in ghosts}
for(gp,ww),co in Sghost.items():
 for at,(n,j) in enumerate(ww):
  if n in ghosts:
   assert not j;sg=(-1)**sum(A.parities[n]*A.parities[k] for k,js in ww[:at]);put(ghost_el[n],(gp,ww[:at]+ww[at+1:]),scale_coefficient(co,sg))
raw=[]
for i in range(45):
 N=plus(A.rows(old['ghost_antifield_columns'][f'JC{i}'],explicit_g=False),ghost_el[A.index[f'C{i}']]);free=plus(*(D(elem(f'JB{i}_{mu}'),mu) for mu in range(4)));assert {k:v for k,v in N.items() if k[0]==0}==free and all(gp in [0,1] for gp,ww in N)
 raw.append(scale({(gp-1,ww):v for(gp,ww),v in N.items() if gp},-1))
gens=[]
for i in range(45):
 G=plus(*(sc(raw[k],Qi[k,i]) for k in range(45) if Qi[k,i]!=0));expected=a['all45_global_Noether_generators'][i];assert A.fingerprint(G)==expected['primitive_sha256'] and len(G)==expected['primitive_positions'];gens.append(G)
print('STAGE verifier fresh_all1286_canonical_columns_for_all_three_fixtures',flush=True)
nm={A.index[n]:A.rows(v,explicit_g=False) for n,v in get('regularity')['nonminimal']['point_maps'].items()};Umap={A.index[J]:plus(elem(J),A.rows(v,explicit_g=False)) for J,v in e2['source_shifts'].items()};C=lambda p:sub(sub(p,nm),Umap)
basic=plus(*(mul(elem(f'JC{i}'),elem(f'C{i}')) for i in range(12,45)),*(scale(mul(elem(f'JB{i}_{mu}'),elem(f'B{i}_{mu}')),-1) for i in range(12,45) for mu in range(4)));Gy=gens[yidx];allG=[Gy,basic,plus(Gy,basic)]
for G,expected in zip(allG,a['all_actual_canonical_fixtures']):
 K=C(G);assert A.fingerprint(K)==expected['postC_primitive_sha256'];ev=ELodd(K);H={**{i:scale(ev[Jof[i]],-(-1)**A.parities[i]) for i in fields},**{Jof[i]:scale(ev[i],(-1)**A.parities[i]) for i in fields}}
 assert {A.names[n]:A.fingerprint(H[n]) for n in names}==expected['all1286_columns']
 assert (K!=sub(G,Umap))==expected['missing_N_changes_fixture'] and (K!=sub(G,nm))==expected['missing_U_changes_fixture']
assert sub(basic,nm)==basic and not a['all_actual_canonical_fixtures'][1]['missing_N_changes_fixture']
GH=plus(*(mul(elem(f'JC{i}'),elem(f'C{i}')) for i in range(12)),*(scale(mul(elem(f'JB{i}_{mu}'),plus(elem(f'B{i}_{mu}'),scale(elem(f'A{i}_{mu}'),-1))),-1) for i in range(12) for mu in range(4)))
assert A.fingerprint(C(GH))==a['paired_H_control_same_as_PBL_primitive_hash'] and C(GH)!=sub(GH,nm) and C(GH)!=sub(GH,Umap)
assert plus(C(allG[2]),scale(C(Gy),-1))==C(basic)
print('STAGE verifier full_Lorentz_background_source_obstruction_and_comparison_proof',flush=True)
Zv=mat(a['H_centralizer_not_gauge_center_vector']);AZ=adj(Zv);assert nz(AZ) and all(not nz(adj(Q[:,h])*Zv) for h in range(12));rawAd=(Qi*AZ*Q).applyfunc(s.expand);assert nz(rawAd)==nz(mat(a['background_obstruction_adjoint']))
zr=Qi*Zv;domega=elem('omega0',(0,));flow={A.index[f'B{i}_0']:sc(domega,zr[i]) for i in range(45) if zr[i]!=0};observed=0
for i in range(45):
 for mu in range(4):
  q=A.rows(data['master_field_maps'][f'B{i}_{mu}'],explicit_g=False);got={}
  for(gp,ww),co in q.items():
   for at,(n,j) in enumerate(ww):
    if n in flow:got=plus(got,scale(mul({(gp,ww[:at]):co},DD(flow[n],j),{(0,ww[at+1:]):ONE}),-1))
  expected=plus(*(sc(mul(A.rows([{'coefficient':'g10','word':[]}],explicit_g=False),domega,elem(f'C{j}')),-rawAd[i,j]) for j in range(45) if rawAd[i,j]!=0)) if mu==0 else {}
  assert got==expected;observed+=len(got)
assert observed==len(a['background_obstruction_adjoint']['entries'])==20
# The other Lorentz directions repeat the same colour tensor with their own
# independent derivativeomega jets. The covariant contraction has80 entries.
assert not nz(rawAd[:,:12]) and nz(rawAd[:,12:])
fail=read(O/'primary_capture.json');assert fail['execution_state']=='FAILED' and 'assert K!=sub(G,U) and K!=sub(G,nm)' in fail['stdout_and_stderr']
# Proof review:the nonminimal homotopy preserves the BASIC IMAGE,not an
# arbitrary primitive;G_basic=C(pG-J_y)+H'F and the explicit current ledger
# give the same image. h itself is not a canonical transformation.
out={'schema':'BASIC_PRIMITIVE_COMPARISON_INDEPENDENT_V1','execution_state':'COMPLETED','scientific_disposition':'QUALIFIED_INTRINSIC_INDUCED_ALGEBRAIC_BASIC_EXACT_IMAGE_EQUALITY_IN_DECLARED_POLYNOMIAL_LANGUAGE','input_sha256':vp['input_sha256'],'primitive_patterns_checked':6,'actual_adjoint_projection_rank':45,'ambient_End_dimension':2025,'all45_actual_Noether_generators_matched':True,'all508_physical_Euler_programs_and34_term_action_retained':True,'free_Maxwell_divergence_and_polynomial_current_proof_reviewed':True,'fresh_canonical_columns_independently_compared':3858,'PM_point_map_omission_insensitive_and_explicitly_retained':True,'paired_H_both_chart_omission_calibration_sensitive':True,'source_Ward_obstruction_one_Lorentz_component_positions':20,'derivativeomega_four_Lorentz_component_positions':80,'arbitrary_nonbackground_invariant_primitive_covered_by_inner_adjustment':True,'nonminimal_basic_reconstruction_and_current_ledger_reviewed':True,'no_inverse_g_or_cancellation_in_BRST_cohomology':True,'bounded_first_probe_quantum_route_reused_not_full_A5':True,'failed_native_workers_preserved':1,'failed_verifier_workers':0,'authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
