"""Basic exact-image primitive comparison,actual adjoint/Noether/canonical maps."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from itertools import combinations,product
from fractions import Fraction as F
import json,gzip,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BPC_NATIVE_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('BPC_UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);get=lambda label:read(Path(prep['artifacts'][role][label]['path']))
 @lru_cache(None)
 def scalar(text):return s.expand(s.sympify(text))
 def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):scalar(v) for i,j,v in p['entries']})
 def nz(m):return {ij:s.expand(v) for ij,v in m.todok().items() if s.expand(v)!=0}
 def mpack(m):return {'shape':list(m.shape),'entries':[[*ij,str(s.simplify(v))] for ij,v in sorted(nz(m).items())]}
 phys=get('physical');Q=mat(phys['C3_plane_to_parent']);Qi=Q.inv();rho={sec:[mat(p) for p in rr] for sec,rr in phys['representation_matrices'].items()};pairs=list(combinations(range(10),2));unit=1/s.sqrt(2);f={}
 print('STAGE '+role+' complete_adjoint_orthogonal_projection_and_nonbasic_closed_control',flush=True)
 if role=='primary':
  mm=[s.MutableSparseMatrix(10,10,{(i,j):unit,(j,i):-unit}) for i,j in pairs]
 else:mm=[m.extract(range(0,20,2),range(0,20,2)) for m in rho['phi']]
 # Both matrices realize the same normalized45-plane basis;replay uses the
 # actual first real10 scalar copy rather than constructing plane matrices.
 for a in range(45):
  for b in range(45):
   br=mm[a]*mm[b]-mm[b]*mm[a]
   for c,(i,j) in enumerate(pairs):
    if br[i,j]!=0:f[c,a,b]=s.expand(s.sqrt(2)*br[i,j])
 assert len(f)==720
 prior=get('pbl');assert prior['adjoint_Casimir']==-8 and prior['full_adjoint_commutators_checked']==2025
 ad=[s.MutableSparseMatrix(45,45,{(c,b):v for(c,aa,b),v in f.items() if aa==a}) for a in range(45)]
 gram=s.Matrix(45,45,lambda i,j:sum(v*nz(ad[j]).get(k,0) for k,v in nz(ad[i]).items()));assert gram==8*s.eye(45)
 # The coefficient transpose identity covers ALL2025 input endomorphism
 # basis positions,including zeros;Gram8 proves the projection identities.
 assert {(a,r,c):v/8 for(a,c,r),v in f.items()}=={(a,r,c):v/8 for(r,a,c),v in f.items()}
 def proj_y(z):
  out=s.zeros(45,1)
  for(c,i,j),v in f.items():out[c]+=v*z[j,i]/8
  return out.applyfunc(s.expand)
 def adj(y):return sum((y[i]*ad[i] for i in range(45) if y[i]!=0),s.zeros(45))
 QH=Q[:,:12];PH=(QH*(QH.T*QH).inv()*QH.T).applyfunc(s.simplify);PM=s.eye(45)-PH
 assert not nz(proj_y(PH)) and not nz(proj_y(PM))
 for i in range(45):assert proj_y(ad[i])==s.eye(45)[:,i]
 yidx=next(i for i in range(45) if any(nz(adj(Q[:,h])*s.eye(45)[:,i]) for h in range(12)));y=s.eye(45)[:,yidx];z=ad[yidx]+PM;w=z-adj(proj_y(z))
 assert proj_y(z)==y and not nz(w-PM) and not nz(w*QH)
 for h in range(12):
  ah=adj(Q[:,h]);assert not nz(ah*z-z*ah+adj(z*Q[:,h]));assert not nz(ah*w-w*ah)
 assert nz(PH*QH) and any(nz(adj(Q[:,h])*PH-PH*adj(Q[:,h])+adj(PH*Q[:,h])) for h in range(12))
 assert proj_y(-ad[yidx])==-y and proj_y(ad[yidx])!=(-y)
 print('STAGE '+role+' all45_actual_global_Noether_source_identities_and_scalar_terms',flush=True)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);fields={i for i,J,hh,kk in geo['field_source_h_k']};Jof={i:J for i,J,hh,kk in geo['field_source_h_k']};sources=set(Jof.values());names=sorted(fields|sources);ghosts={A.index[f'C{i}'] for i in range(45)};physical={i for i in fields if A.names[i].startswith(('B','x_'))}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 def plus(*pp):
  out={}
  for p in pp:
   for k,v in p.items():put(out,k,v)
  return out
 def mul(*pp):
  q={(0,()):ONE}
  for p in pp:q=A.product(q,p)
  return q
 @lru_cache(None)
 def coeff(c):return A.rows([{'coefficient':str(c),'word':[]}],explicit_g=False)
 def sc(p,c):return mul(coeff(c),p)
 def D(p,mu):
  out={}
  for(gp,ww),co in p.items():
   for at,(n,j) in enumerate(ww):
    w1,sg=A.canonical(ww[:at]+((n,tuple(sorted(j+(mu,)))),)+ww[at+1:])
    if sg:put(out,(gp,w1),scale_coefficient(co,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def grad(p):
  out={}
  for(gp,ww),co in p.items():
   parity=0
   for at,(n,j) in enumerate(ww):
    put(out.setdefault((n,j),{}),(gp,ww[:at]+ww[at+1:]),scale_coefficient(co,(-1)**(A.parities[n]*parity)));parity+=A.parities[n]
  return out
 def EL(p,domain=None):
  domain=names if domain is None else domain;out={n:{} for n in domain}
  for(n,j),pp in grad(p).items():
   if n in out:out[n]=plus(out[n],scale(DD(pp,j),(-1)**len(j)))
  return out
 def sub(p,mp):
  out={}
  for(gp,ww),co in p.items():
   q={(gp,()):co}
   for n,j in ww:q=mul(q,DD(mp.get(n,elem(n)),j))
   out=plus(out,q)
  return out
 def act(p,flow,odd=False):
  if role=='primary':return plus(*(mul(DD(flow[n],j),pp) for(n,j),pp in grad(p).items() if flow.get(n)))
  out={}
  for(gp,ww),co in p.items():
   pref=0
   for at,(n,j) in enumerate(ww):
    if flow.get(n):out=plus(out,mul({(gp,ww[:at]):scale_coefficient(co,(-1)**pref if odd else 1)},DD(flow[n],j),{(0,ww[at+1:]):ONE}))
    pref+=A.parities[n]
  return out
 def ham(p):
  el=EL(p);return {**{i:scale(el[Jof[i]],-(-1)**A.parities[i]) for i in fields},**{Jof[i]:scale(el[i],(-1)**A.parities[i]) for i in fields}}
 Rfields={i:A.rows(data['master_field_maps'][A.names[i]],explicit_g=False) for i in physical|ghosts};Sphysical_source=plus(*(mul(elem(Jof[i]),Rfields[i]) for i in physical));Sghost_source=plus(*(mul(elem(Jof[i]),Rfields[i]) for i in ghosts))
 Nfull=EL(plus(Sphysical_source,Sghost_source),ghosts);Nghost=EL(Sghost_source,ghosts);old=get('regularity')['Noether'];assert old['source_left_divergence_sign']==1 and old['off_shell_zero_dependency']=='qualified gauge/scalar Noether identities'
 rawJ=[]
 for a in range(45):
  Np=A.rows(old['ghost_antifield_columns'][f'JC{a}'],explicit_g=False);assert Nfull[A.index[f'C{a}']]==plus(Np,Nghost[A.index[f'C{a}']])
  dJ=plus(*(D(elem(f'JB{a}_{mu}'),mu) for mu in range(4)));assert {k:v for k,v in Nfull[A.index[f'C{a}']].items() if k[0]==0}==dJ
  assert all(gp in [0,1] for gp,ww in Nfull[A.index[f'C{a}']]);rawJ.append(scale({(gp-1,ww):v for(gp,ww),v in Nfull[A.index[f'C{a}']].items() if gp>0},-1))
 e2=get('e2');programs={n:v['physical_program'] for n,v in e2['complete_columns'].items() if v['physical_program']};assert len(programs)==508 and all(e2['complete_columns'][f'JB{a}_{mu}']['physical_program'] for a in range(45) for mu in range(4))
 act0=get('action');assert len(act0['local_terms'])==34
 # Maxwell divergence is identically zero on symmetric third jets;constant
 # parent/source metric maps commute with it. Nongauge g0 terms have no B.
 eta=[1,-1,-1,-1];div={}
 for mu,nu in product(range(4),repeat=2):
  k=(mu,tuple(sorted((mu,nu,nu))));div[k]=div.get(k,0)+eta[mu]*eta[nu]
  k=(nu,tuple(sorted((mu,mu,nu))));div[k]=div.get(k,0)-eta[mu]*eta[nu]
 assert all(v==0 for v in div.values())
 globalgens=[];ysumm=[];full_scalar_count=0
 for a in range(45):
  ar=(Qi*ad[a]*Q).applyfunc(s.expand);V={i:{} for i in fields}
  for (out,inn),co in nz(ar).items():
   V[A.index[f'C{out}']]=plus(V[A.index[f'C{out}']],sc(elem(f'C{inn}'),co))
   for mu in range(4):V[A.index[f'B{out}_{mu}']]=plus(V[A.index[f'B{out}_{mu}']],sc(elem(f'B{inn}_{mu}'),co))
  for sec,rr in rho.items():
   for(out,inn),co in nz(rr[a]).items():V[A.index[f'x_{sec}_{out}']]=plus(V[A.index[f'x_{sec}_{out}']],sc(elem(f'x_{sec}_{inn}'),co));full_scalar_count+=1
  if role=='primary':G=plus(*(sc(rawJ[b],Qi[b,a]) for b in range(45) if Qi[b,a]!=0))
  else:G=plus(*(scale(mul(elem(Jof[i]),vv),-(-1)**A.parities[i]) for i,vv in V.items() if vv))
  # Both routes independently check the signed source-Euler identity.
  expected=plus(*(sc(rawJ[b],Qi[b,a]) for b in range(45) if Qi[b,a]!=0));assert G==expected
  H=ham(G);assert all(H[i]==V[i] for i in fields)
  dual={Jof[i]:{} for i in fields}
  for i,vv in V.items():
   for(n,j),pp in grad(vv).items():
    assert not j and all(not ww for gp,ww in pp);dual[Jof[n]]=plus(dual[Jof[n]],scale(mul(elem(Jof[i]),pp),-1))
  assert all(H[J]==dual[J] for J in sources)
  globalgens.append(G);ysumm.append({'physical_generator':a,'primitive_positions':len(G),'primitive_sha256':A.fingerprint(G),'all1286_beta_hamiltonian_columns_verified':True})
 assert full_scalar_count==7602
 print('STAGE '+role+' actual_nonminimal_transport_basic_primitive_and_Ward_obstruction',flush=True)
 nm={A.index[n]:A.rows(rr,explicit_g=False) for n,rr in get('regularity')['nonminimal']['point_maps'].items()};U={A.index[J]:plus(elem(J),A.rows(rr,explicit_g=False)) for J,rr in e2['source_shifts'].items()};Ui={A.index[J]:plus(elem(J),scale(A.rows(rr,explicit_g=False),-1)) for J,rr in e2['source_shifts'].items()}
 C=lambda p:sub(sub(p,nm),U);Ci=lambda p:sub(sub(p,Ui),nm)
 PMraw=s.diag(*([0]*12+[1]*33));basic=plus(*(mul(elem(f'JC{a}'),elem(f'C{a}')) for a in range(12,45)),*(scale(mul(elem(f'JB{a}_{mu}'),elem(f'B{a}_{mu}')),-1) for a in range(12,45) for mu in range(4)))
 ib={A.index[f'C{h}']:elem(f'omega{h}') for h in range(12)};Gy=globalgens[yidx];nonbasic=plus(Gy,basic);assert act(Gy,ib,True) and not act(basic,ib,True)
 result_fixtures=[];domain=get('domain');Ip={A.index[n]:A.rows(rr,explicit_g=False) for n,rr in domain['transported_contraction_columns'].items()};ops=get('e3')['operators'];Tb={A.index[n]:A.rows(rr,explicit_g=False) for n,rr in ops['Tb_geometric_and_transported'].items() if n in A.index};Tq={A.index[n]:A.rows(rr,explicit_g=False) for n,rr in ops['Tq_transported'].items() if n in A.index}
 for label,G in [('nonbasic_closed_global',Gy),('basic_PM',basic),('nonbasic_same_nonzero_image',nonbasic)]:
  K=C(G);assert Ci(K)==G;H=ham(K);Hb=ham(G);conj={n:C(act(Ci(elem(n)),Hb)) for n in names};assert H==conj
  I=act(K,Ip,True);assert I==C(act(G,ib,True))
  if label=='basic_PM':assert not I and not act(K,Tb) and not act(K,Tq)
  else:assert I
  assert K!=sub(G,U) and K!=sub(G,nm)
  result_fixtures.append({'label':label,'postC_primitive_positions':len(K),'postC_primitive_sha256':A.fingerprint(K),'all1286_columns':{A.names[n]:A.fingerprint(H[n]) for n in names},'iota_positions':len(I),'iota_sha256':A.fingerprint(I),'lost_N_or_U_detected':True})
 assert plus(C(nonbasic),scale(C(Gy),-1))==C(basic)
 # A nonzero H-centralizer is not the center of all so10.
 Z=s.Matrix([s.re(v).expand(complex=True) for v in Q[:,12]])
 if not any(Z):Z=s.Matrix([s.im(v).expand(complex=True) for v in Q[:,12]])
 AZ=adj(Z);assert nz(AZ) and all(not nz(adj(Q[:,h])*Z) for h in range(12))
 zzraw=Qi*Z;GA=plus(*(sc(mul(elem(f'JB{a}_0'),elem('A0_0')),-zzraw[a]) for a in range(45) if zzraw[a]!=0));assert not act(GA,ib,True)
 # In the minimal chart Tq fixes A and Z commutes with H,so GA is
 # horizontal/quantum-H invariant but its Q image fails background invariance.
 rawAdZ=(Qi*AZ*Q).applyfunc(s.expand);wardtensor=mpack(rawAdZ);assert wardtensor['entries'];witness=next((i,j,v) for i,j,v in wardtensor['entries'])
 wrong_scalar=plus(*(p for(gp,ww),co in Gy.items() for p in [{(gp,ww):co}] if not any(A.names[n].startswith('Jx_') for n,j in ww)))
 assert wrong_scalar!=Gy and any(nz(rho[sec][yidx]*rho[sec][j]-rho[sec][j]*rho[sec][yidx]) for sec in rho for j in range(45))
 # Full zero-center implication uses invertible adjoint Casimir/Gram,not H.
 current_program={'definition':'QJ_y=div shift_g_positive(QJB.y);QJB(g0)=E_free_Maxwell and div E_free=0','all180_gauge_physical_programs_retained':True,'all508_physical_programs_bound':len(programs),'physical_action_terms':34,'source_master_Noether_identity_reused_with_actual45_source_columns':True,'physical_Eulers_put_on_shell':False,'current_contains_no_inverse_g':True}
 out={'schema':'BASIC_PRIMITIVE_COMPARISON_V1','route':role,'scientific_disposition':'INTRINSIC_INDUCED_ALGEBRAIC_EXACT_IMAGE_COMPARISON_PENDING_INDEPENDENT_VALIDATION','adjoint_projection_rank':45,'ambient_endomorphism_dimension':2025,'adjoint_Gram_diagonal':8,'full_sparse_projection_transpose_factor_checked':True,'all45_global_Noether_generators':ysumm,'global_scalar_representation_positions_checked':full_scalar_count,'polynomial_Noether_current_program':current_program,'chosen_nonbasic_physical_generator':yidx,'all_actual_canonical_fixtures':result_fixtures,'H_centralizer_not_gauge_center_vector':mpack(Z),'background_obstruction_adjoint':wardtensor,'actual_nonzero_source_Ward_witness':witness,'wrong_scalar_source_omission_changes_generator_and_commutator':True,'constant_omega_Azero_control_insensitive_to_derivativeomega_obstruction':True,'unknown_primitive_or_quantum_breaking_coefficients_fitted':False,'nonminimal_basic_H_preservation_and_quantum_first_probe_theorems_reused':True,'intrinsic_induced_equality_requires_completed_independent_proof_validation':True,'E5_A5_HB1_C5_or_physical_promotion':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
