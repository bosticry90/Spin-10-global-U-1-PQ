# BPC1 independent verification V2

V1 verifier FAILED at a literal AST Field-name assertion. It recognized only
B and x_Phi/x_Sigma/x_phi/x_S;the SAME frozen potential also uses Phi,Sigma,
SigmaBar,phi,phiBar,S,SBar. No missing quantum field or changed action was found.
Original verifier,preparation and complete capture remain unchanged.

V2 explicitly recognizes these declared scalar aliases/conjugates using the
actual action index domains,referenced A31 embedding metadata and frozen AST
interpreter conjugation rules. The g0 degree test still requires all nongauge
terms to have no B and at least two scalar factors. No arbitrary name is
accepted,and no field,coefficient or physics assumption changes. Both completed
native V2 outputs are NOT rerun. One failed native and one failed verifier
remain part of TrackB. Same180second verifier/8GiB sampledprivate/350MiB floor;
no package or acceptance relaxation. Full canonical-column and current checks
still required before qualification.
