# BPC1:basic primitives for basic exact images

Qualification requires the completed independent receipt and committed-byte
check. Both native V2 routes agree on the proposed equality of exact-image
subspaces in the specified algebraic polynomial gauge/scalar language:

 B_basic intersect Q(K_full)=Q(K_basic) modulo ordinary currents.

K_full is not restricted to background-invariant generators in advance.
This is the other comparison direction after PBL1. It does not activate
HB1/C5,qualify E5/A5 or adopt a physical quantum renormalization scheme.

## Why a closed generator must be removed

An original primitive need not be basic even when its image is basic.
Decompose its minimal ghost matrix z into ad_y+w using the actual compact
metric and y=(1/8)sum_i[e_i,z(e_i)]. The45-dimensional adjoint projection is
constructed inside the2025-dimensional endomorphism module. From the mixed-H
CE condition on the IMAGE,orthogonal projection proves w(H)=0.

The explicit closed generator
J_y=-JB[y,B]-Jx*rho_y*x+JC[y,C]
removes the inner component without changing the integrated image. All45
constant-colour generators are checked against the actual signed ghost-source
Euler identity and physical representations,including the scalar-source terms.
The complete Noether/master identity supplies their polynomial boundary currents;
physical Eulers are retained as programs for the actual34-term action.

The adjusted primitive is horizontal and quantum-H invariant. Its only possible
external-background carrier then has form JB*M*A. The source coefficient of
Q(TbG) forces [M*domega,C]=0,so the zero center of FULL so10 forces M=0.
A nonzero H-centralizer direction cannot evade this condition. The previous
basic-preserving nonminimal homotopy reconstructs the full basic primitive.
This proves equality of the stated exact-image spaces if validation passes.

The proof is coefficientwise over the declared polynomial ring. Only the
numerical adjoint Gram inverse1/8 occurs. The Noether current uses an exact
positive-g coefficient shift AFTER isolating the free Maxwell divergence.
This does not cancel g in BRST cohomology or erase the old unweighted coupling
class. No inverse coupling,mass,width,field or differential operator is adopted.

## Actual calculations and controls

Primary derives global generators from the actual source Euler columns;
replay derives them from real representation matrices and evaluation-dual maps.
All45 beta-generator Hamiltonian field/source columns are checked. Three
actual transported fixtures compare all643 field+643 source columns,including
zero complements. The independent verifier must rederive those columns.
The nonbasic closed generator has a64-position contraction;subtracting it from
the nonbasic same-image fixture gives the nonzero basic PM primitive.

One nativeV1 failure is preserved:the code incorrectly required every fixture
to change when either chart was omitted. The PM primitive is invariant under
the nonminimal point map,so that omission is INSENSITIVE there. V2 records
per-fixture sensitivities and freshly calibrates both chart omissions against
the qualified paired-H primitive. Both canonical-column comparisons and all
scientific conditions remain unchanged.

The source-Ward obstruction is a colour tensor. A displayed Lorentz0 component
is a diagnostic projection of the covariant sum over allfour directions,not
an adopted preferred direction or an altered model. Constantomega/A0 would
miss the derivativeomega term. All physical/source current contributions remain.

## Scope and next acceptance decision

Together with PBL1's representative construction,this addresses both algebraic
comparison directions at the stated grades,in the fixed source language.
The earlier complete0/1/2-source first-probe constructions supply the bounded
formal one-loop implementation route for the resulting generators. Their
reference determinant,connected products,physical Euler programs,raw heat/
Jacobian,power and first-dimension-jet finite conversions remain required.

It does not establish arbitrary multiple-insertion normalization,all-loop QAP,
physical measures,Lorentzian/causal/constant-vacuum limits,universal physical
parameter stability or a viable GUT. Shared action/master/Noether premises,
coordinate maps,software,analytic predecessor proofs and AI authorship remain
limitations. No independent expert/experiment or Lean certificate is supplied.

Authority34/39 and state113 unchanged;E5/A5unqualified,custodyexit2/seven,
HB1/C5blocked,flavorpaused. Quartet failure,scalar quantum-control/gauge-matching
warnings,matter/PQ and broader physical issues remain. No old evidence,action,
policy,state,scheme,benchmark,remote push,outreach or publication change.
