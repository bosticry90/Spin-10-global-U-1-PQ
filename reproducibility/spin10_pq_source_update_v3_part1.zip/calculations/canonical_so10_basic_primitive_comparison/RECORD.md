# BPC1:intrinsic versus induced exact primitive comparison

Base2e297339/main. Previousgoalturn PROGRESS. Question:for any admitted real
local polynomial oddG of grades(3,-1,odd),does a joint-basic image F=QG modulo
ordinary currents admit a joint-basic primitive G_basic in the SAME language?
Do not assume the originalG is background invariant. This is the missing
algebraic comparison direction after PBL1,not activation of HB1/C5/catalogs
or scientific promotion. Keep project_state sole authority34/39.

Freeze source,derivation,controller,immutable own-route inputs and expected
controls before scientific computation. Two sequential120second-after-import
workers,separate180second verifier;8GiB sampledprivate,350MiB available-commit
floor,8MiB package. Preserve failed/unfinished runs;no silent truncation or
expanded caps. Reuse old master,Cartan,nonminimal and first-probe proofs,
not old loop replays or295-vector coefficients.

The full positive project-dimension ring,all finite ordinary jets and local
background-parameter jets remain. Formalg is not a zero divisor;no inverse
g/mass/width/field/derivative. GlobalPQ is not gauged. Minimal primitives have
only JB B,JB A,divJB,Jx x,Jx*dimension1,JC C. Bound source-jet currents.

Construct the orthogonal projection End(ad so10)->ad so10 with actual
Casimir/metric normalization. A mixed-H CE-closed z may contain ad_y. Derive
its removal using the COMPLETE classical globalSpin10 Noether primitive,
including scalar sources. Authenticate the actual34-term physical action,
all508 physicalEuler programs and full source master identity. Verify every
one of45 generator columns by actual ghost-source Euler differentiation
versus physical real representation matrices. Its Q image is a polynomial
current,not zero by setting Eulers on shell or declaring source polynomials
complete physical Eulers.

Prove the adjusted minimal primitive horizontal,then quantum-H invariant by
Cartan. Derive the external-A source obstruction from Q(TbG)=0;use full so10
center,not merely H center. Apply the existing basic-preserving nonminimal
retract to reconstruct the full primitive and currents. Do not use h as a
canonical change of integration fields.

Actual nonbasic closed colour-rotation plus a nonzero basic PM-normalization
fixture must retain its image and become basic after subtraction. Transport
both with the same N/U maps and compare all1286 Hamiltonian columns,including
zero complements,then independently verify those columns. Controls:wrong
projection sign/normalization;z=P_H invalidity;omitted scalar-source part;
nonzero H-centralizer/background-A example;lost N/U companions;constant-omega
insensitivity;old nonhorizontal ghost witness. No unknown quantum data fitted.

Success qualifies equality of intrinsic and induced algebraic exact-image
subspaces at this degree,and,combined with PBL1,the specified algebraic
comparison. It does not establish arbitrary physical parameter stability,
all-order QAP/A5,E5,quantum measures,global/vacuum/Lorentzian equivalence or
physical grand unification. Reuse bounded common first-probe normalization
only with its stated domain and full current/measure/reference terms.
No historical evidence/action/policy/state/benchmark/scheme/push/outreach or
publication change. Main remains;no branch/worktree. Custodyexit2/seven,
blocked/paused stages and physical failures unchanged.
