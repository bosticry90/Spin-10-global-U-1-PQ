# What the two algebraic comparisons establish

This is a scoped evidence reconciliation,not director acceptance or a change
to project_state. The original closure-versus-adequacy distinction remains.

| Requirement | Current evidence and limit |
| --- | --- |
| Joint basic differential closure | Earlier full Cartan/source/background evidence retained. |
| Original raw ghost-rescaling counterterm | Still nonhorizontal in its literal test;the +domega source-Euler witness remains. |
| Named and general primitive quantum replacements | FGR1/SPP1/SQP1/OSP1 provide the bounded formal one-loop first-probe constructions;W5 GWP1 retains complete connected source products. |
| Basic representative for every fixed-Q/Tb algebraic counterterm | PBL1 constructs it in the stated polynomial gauge/scalar language. |
| Basic primitive for an already-basic full exact image | BPC1 constructs it without restricting the original primitive to be background invariant. |
| Intrinsic versus induced algebraic comparison | The two exact-image spaces agree at the stated degree. Together with PBL1,this gives the specified algebraic comparison,not every ghost-number cohomology. |
| Physical parameter/normalization stability for every possible class | Still not proved. Neither comparison classifies all basic classes into the original physical parameter list. |
| Actual measured UV residue physical span | PCS1 remains qualified for the actual parity-even bosonic residue;that scope is smaller than all possible algebraic counterterms. |
| Full quantum prescription and physical domains | Arbitrary multiple insertions,all-loop QAP/measure/equivalence and Lorentzian/causal/constant-vacuum limits remain outside these results. |

The primitive correction is a CLOSED actual global-colour Noether generator,
not a fitted counterterm. Its scalar-source contribution and full physical
Euler current are necessary. Its image is an ordinary divergence;it need not
be basic itself. No globalPQ charge is promoted into the gauge algebra.

For F=QG+div k,write QF=div m and work in the beta chart. The current ledger
is explicit: pF=QpG+div(pk),QJ_y=div J_y,current,and
Q(HF)=F-pF-div(Hm). Thus the constructed primitive pG-J_y+HF has
Q image F modulo the sum of those ordinary currents. The SAME canonical
charts transport them. Local probes turn divergences into derivative-probe
insertions,which remain in the existing first-probe construction.
The positive-g current shift removes only the independently established
free-Maxwell divergence. It never divides a BRST class by the coupling.

The actual field/source quantum meaning retains the common finite map,
reference determinant,raw heat/Jacobian,power/dimension-jet conversions and
whole connected products. Basicness is not inferred from a naive mean-field
replacement or cancellation of field traces against external source traces.
The algebraic theorem alone is not full A5 or a physical subtraction scheme.

A necessary next scientific check concerns remaining BASIC classes and their
coupling/free-limit admissibility. Polynomial cohomology can contain
infinitesimal directions not obviously realized by a physical normalization
family. Conversely,a candidate that fails nonlinear extension or prescribed
coupling normalization must not be declared a quantum anomaly. Determine
those obligations explicitly before asserting universal physical stability.

No HB1/C5 activation,catalog replacement,blocked-stage resumption or scientific
promotion. Authority remains34/39;E5/A5unqualified,custodyexit2/seven,
quartet failure,scalar quantum-control/matching and matter/PQ questions remain.
