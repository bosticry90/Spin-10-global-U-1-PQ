from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
from collections import defaultdict
import ast,gzip,importlib.util,json,os,sys,time,threading
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('qualified_contact_jet_algebra',R/'calculations/canonical_so10_correlated_contact_lift/lift.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u;ONE=u.ONE
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed=set(prep['read_json_by_role'][role])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INSERTION_BUBBLE_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_INSERTION_BUBBLE_JSON',str(p))
 sys.addaudithook(guard);data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k'];Jof={A.names[n]:A.names[J] for n,J,h,k in pairs};fields={n for n,J,h,k in pairs}
 elem=lambda name,j=():{(0,((A.index[name],j),)):ONE};const=lambda co:{(g,()):z for g,z in u.parse_coefficient(co)};mul=A.product;add=v.combine;neg=lambda Q:v.scale(Q,-1)
 hmap={n:{(0,((hh,()),)):ONE} for n,J,hh,kk in pairs};kmap={n:{(0,((kk,()),)):ONE} for n,J,hh,kk in pairs}
 prototypes={'1':{(0,()):ONE},'x':elem('x_Phi_0'),'L':elem('L12'),'Ja':elem(Jof['ub12']),'JL*C':mul(elem(Jof['L13']),elem('C14')),'Ca':mul(elem('C13'),elem('ub14')),'xx':mul(elem('x_Phi_0'),elem('x_Phi_1')),'AA':mul(elem('A0_0'),elem('A1_0')),'AB':mul(elem('A0_0'),elem('B1_0')),'BB':mul(elem('B0_0'),elem('B1_0')),'partial.A':elem('A0_0',(0,)),'partial.B':elem('B0_0',(0,))}
 second={name:v.act(A,v.act(A,Q,hmap,0,role),kmap,0,role) for name,Q in prototypes.items()};intrinsic=sorted(name for name,Q in second.items() if Q);assert intrinsic==['BB','Ca','xx']
 raw=read(P/f'frozen_a10_e5_full_hessian/{role}.json');ref=raw['retained_reference'];order=ref['field_order'];pos={n:i for i,n in enumerate(order)};odd={A.index[n] for n in order if A.parities[A.index[n]]};assert len(odd)==90 and not raw['auxiliaries_eliminated']
 mom=s.symbols('p0_ref0:4');Pm=mom[0]**2-sum(q*q for q in mom[1:]);N={}
 for i,j,text in ref['reference_Green_raw_C3']['entries']:
  ni,nj=A.index[order[i]],A.index[order[j]]
  if ni not in odd or nj not in odd:continue
  co=s.cancel(Pm*s.sympify(text,locals=dict(zip(map(str,mom),mom))));assert not co.free_symbols;N[ni,nj]=const(str(co))
 for (i,j),co in N.items():assert N.get((j,i),{})==neg(co)
 e2=read(P/f'frozen_a10_e2_transport/{role}.json');lift=read(R/f'calculations/canonical_so10_correlated_contact_lift/{role}_result.json');X={name:v.unpack(A,rows) for name,rows in lift['all643_nonzero_field_flows'].items()};assert len(X)==20
 Lnames=[('b' if i<12 else 'L')+str(i) for i in range(45)];anames=[('bar' if i<12 else 'ub')+str(i) for i in range(45)];Qa={name:A.rows(e2['complete_columns'][name]['source_polynomial']) for name in anames}
 def hessian(Q0):
  out={}
  for i,dQ in u.left_gradients(A,Q0).items():
   if i not in fields:continue
   for j,ddQ in u.left_gradients(A,dQ).items():
    if j not in fields:continue
    assert i in odd and j in odd and all(not word for gp,word in ddQ)
    out[i,j]=v.scale(ddQ,(-1)**(A.parities[j]*(A.parities[i]+1)))
  return out
 HX={name:hessian(Q0) for name,Q0 in X.items()};HS={name:hessian(Q0) for name,Q0 in Qa.items()}
 def mm(left,right):
  rows=defaultdict(list);out={}
  for (k,j),co in right.items():rows[k].append((j,co))
  for (i,k),co in left.items():
   for j,cv in rows[k]:out[i,j]=add(out.get((i,j),{}),mul(co,cv))
  return {k:co for k,co in out.items() if co}
 def tr2(left,right,odd_trace=True):
  out={}
  for (i,j),co in left.items():out=add(out,v.scale(mul(co,right.get((j,i),{})),-1 if odd_trace else 1))
  return out
 NX={name:mm(N,H) for name,H in HX.items()};NS={name:mm(N,H) for name,H in HS.items()}
 tad={name:add(*(neg(co) for (i,j),co in matrix.items() if i==j)) for name,matrix in NX.items()};assert not any(tad.values())
 a12=A.index['ub12'];c12=A.index['C12'];relevant=[(A.names[i],A.names[j]) for i,j in N if i==a12 or j==a12];assert set(relevant)=={('ub12','C12'),('C12','ub12')}
 assert all(c12 not in [n for gp,w in Q0 for n,j in w] for Q0 in X.values())
 def ghost_terms(Q0):return {w:{(gp,()):co} for (gp,w),co in Q0.items() if len(w)==2 and all(n in odd for n,j in w)}
 def wick(Q1,Q2):
  out={}
  for w,co in ghost_terms(Q1).items():
   for z,cv in ghost_terms(Q2).items():
    i,j=w[0][0],w[1][0];k,l=z[0][0],z[1][0]
    conn=add(neg(mul(N.get((i,k),{}),N.get((j,l),{}))),mul(N.get((i,l),{}),N.get((j,k),{})))
    out=add(out,v.scale(mul(mul(co,cv),conn),2))
  return out
 coeff={};other={}
 for i,L in enumerate(Lnames):
  for k,anti in enumerate(anames):
   direct=tr2(NX.get(L,{}),NS[anti]);paired=wick(X.get(L,{}),Qa[anti]);assert direct==paired
   coeff[i,k]=direct if role=='primary' else paired
   if direct:assert all(gp==3 and all(xx==1 and hh==0 for (xx,hh,mask),q in co) for (gp,w),co in direct.items())
 generic=mul(elem('C12'),elem('ub12'));modelN={(c12,a12):const('1'),(a12,c12):const('-1')};modelH=hessian(generic)
 assert tr2(mm(modelN,modelH),mm(modelN,modelH))==const('-2') and wick(generic,generic)==const('-2')
 nonzero={k:co for k,co in coeff.items() if co};print('STAGE',role,'actual_all2025_source_bubble_positions_two_methods',len(nonzero),flush=True)
 # Physical evaluation-dual maps for both the ordinary rho_L and BV Ja.
 T={};Ti={}
 for row,dst in [(r,T) for r in ref['physical_to_raw_kernel']['entries']]+[(r,Ti) for r in ref['physical_to_raw_inverse']['entries']]:
  i,j,text=row;dst[i,j]=const(text)
 left={(a,i):T[508+a,pos[L]] for a in range(45) for i,L in enumerate(Lnames) if (508+a,pos[L]) in T};right={(k,b):T[598+b,pos[anti]] for k,anti in enumerate(anames) for b in range(45) if (598+b,pos[anti]) in T}
 physical=mm(mm(left,nonzero),right);imag={key:{(gp,w):tuple((cell,z) for cell,z in co if cell[2]&16) for (gp,w),co in Q0.items() if any(cell[2]&16 for cell,z in co)} for key,Q0 in physical.items()};assert not any(imag.values())
 # Source-dual local-H action on the local contact density,not the whole
 # nonlocal flat amplitude. rho is external/even and not a canonical source.
 names=list(A.names)+[f'probe_rho{i}' for i in range(45)];AA=u.Algebra(names,list(A.parities)+[0]*45);H={AA.index[n]:AA.rows(rows) for n,rows in read(P/f'frozen_a10_e3_symmetry/{role}.json')['operators']['Tb_geometric_and_transported'].items()};rho={AA.index[Jof[L]]:AA.index[f'probe_rho{i}'] for i,L in enumerate(Lnames)}
 for i,L in enumerate(Lnames):
  hi=H[AA.index[Jof[L]]];out={}
  for (gp,w),co in hi.items():
   assert len(w)==2 and sum(n in rho for n,j in w)==1 and all(not j for n,j in w)
   word=tuple((rho.get(n,n),j) for n,j in w);word,sg=AA.canonical(word);u.put(out,(gp,word),u.scale_coefficient(co,sg))
  H[AA.index[f'probe_rho{i}']]=out
 density={}
 for (i,k),co in nonzero.items():
  mon=AA.product({(0,((AA.index[f'probe_rho{i}'],()),)):ONE},{(0,((AA.index[Jof[anames[k]]],()),)):ONE});v.merge(density,AA.product(co,mon))
 Hres=v.act(AA,density,H,0,role);assert not Hres
 # Actual positive-heat scalar loop; no noncommuting color is rearranged.
 z,t,p2,mu2,r,uvar=s.symbols('z t p2 mu2 r u',positive=True);E1=lambda y:s.expint(1,y)
 closed=2*E1(2*z)-E1(z)+(s.exp(-z)-s.exp(-2*z))/z
 if role=='primary':
  primitive=uvar*E1(2*z*uvar)-s.exp(-2*z*uvar)/(2*z);assert s.simplify(s.diff(primitive,uvar)-E1(2*z*uvar))==0;assert s.simplify(2*(primitive.subs(uvar,1)-primitive.subs(uvar,s.Rational(1,2)))-closed)==0
 else:
  boundary=-(s.exp(-t*p2)-s.exp(-2*t*p2))/(t*t*p2);assert s.simplify(s.diff(closed.subs(z,t*p2),t)-boundary)==0
 assert s.simplify(s.diff(closed,z)+(s.exp(-z)-s.exp(-2*z))/z**2)==0
 finite=s.limit(closed+s.log(z),z,0,dir='+');expected=1-2*s.log(2)-s.EulerGamma;assert s.simplify(finite-expected)==0
 # Independent numerical check of the finite-heat function at nonzero p.
 mp.mp.dps=50;errors=[]
 for zz in [mp.mpf(1)/16,mp.mpf(1)/3,mp.mpf(2)]:
  quad=2*mp.quad(lambda uu:mp.e1(2*zz*uu),[mp.mpf('.5'),1]);value=2*mp.e1(2*zz)-mp.e1(zz)+(mp.exp(-zz)-mp.exp(-2*zz))/zz;err=abs(quad-value);assert err<mp.mpf('1e-45');errors.append(str(err))
 a=s.symbols('a',positive=True);riesz=2**(4-2*a)*s.pi**2*s.gamma(2-a)/s.gamma(a)*p2**(a-2);Fprimitive=-s.diff(riesz,a).subs(a,1)+s.log(mu2)*riesz.subs(a,1);Fextension=s.simplify(p2*Fprimitive/4/(16*s.pi**4));target=(s.log(mu2/p2)+2*s.log(2)-2*s.EulerGamma)/(16*s.pi**2);assert s.simplify(Fextension-target)==0
 logprimitive=s.log(mu2*r*r)/(r*r);assert s.simplify(-(s.diff(logprimitive,r,2)+3*s.diff(logprimitive,r)/r)/4-1/r**4)==0;assert s.limit(r*r*s.log(r),r,0,dir='+')==0
 flux=s.simplify(2*s.pi**2*r**3*s.diff(1/r**2,r));assert flux==-4*s.pi**2
 local=1+s.EulerGamma-4*s.log(2);heatfinite=(s.log(mu2/p2)+expected)/(16*s.pi**2);assert s.simplify(Fextension+local/(16*s.pi**2)-heatfinite)==0
 # Ordinary scalar Legendre fixture for the affine source translation;
 # the graded case uses the fixed j_z*z order and no integration over J.
 j,b,phi,K=s.symbols('j b phi K');W=(j+b)**2/(2*K);GG=s.expand((W-j*phi).subs(j,K*phi-b));assert s.expand(GG+K*phi**2/2-b*phi)==0
 controls={'wrong_ordinary_trace_changes_nonzero_tensor':bool(nonzero) and any(tr2(NX[L],NS[anti],False)!=coeff[i,k] for i,L in enumerate(Lnames) if L in NX for k,anti in enumerate(anames)),'omit_factor_two_changes_nonzero_tensor':bool(nonzero),'forbidden_C12_free_tadpole_is_nonzero':bool(N.get((c12,a12))) and bool(N.get((a12,c12))),'wrong_heat_leg_changes_finite_constant':s.simplify(expected-(expected+s.log(2)))!=0,'drop_finite_matching_contact_changes_extension':local!=0,'wrong_affine_source_sign_fails':s.expand(GG+K*phi**2/2+b*phi)!=0,'source_free_only_drops_two_affine_mixing_families':not second['Ja'] and not second['JL*C'],'a12_ref_pair_no_C12_in_actual_X':True}
 pack=lambda table:[{'rho_index':i,'Ja_index':j,'coefficient':u.pack(A,co)} for (i,j),co in sorted(table.items()) if co]
 record={'schema':'ACTUAL_AUXILIARY_INSERTION_SOURCE_BUBBLE_V1','route':role,'scientific_disposition':'ACTUAL_SOURCE_JA_INSERTION_KERNEL_AND_HEAT_MATCHED_EUCLIDEAN_COINCIDENCE_EXTENSION_FAMILY' if nonzero else 'COMPLETE_SELECTED_SOURCE_JA_INSERTION_BUBBLE_ZERO_WITH_AFFINE_KERNEL_REDUCTION','raw12_integrated_Hessian_positions':{name:len(Q0) for name,Q0 in second.items()},'intrinsic_quadratic_families':intrinsic,'nine_affine_insertion_loop_zeros_not_zero_mixing_or_multiprobe_contacts':True,'actual20_X_odd_Hessian_entries':sum(len(H) for H in HX.values()),'all20_free_tadpoles_zero':True,'actual_a12_Green_row_column':relevant,'full45_by45_canonical_domain':2025,'active20_by45_domain':900,'canonical_nonzero':len(nonzero),'canonical_tensor':pack(nonzero),'canonical_density_sha256':AA.fingerprint(density),'full45_by45_physical_domain':2025,'physical_nonzero':len(physical),'physical_tensor':pack(physical),'all_physical_coefficients_real':not any(imag.values()),'local_contact_H_residual_positions':len(Hres),'local_contact_H_covariant_not_full_offflat_kernel_Ward':True,'two_vertex_sector_complete_at_g3_xi':True,'normalization':'Gamma_rho_Ja=hbar*T*I_t/2;I_t scalar Euclidean bubble;T is actual normalized pole in hbar/(32pi^2 epsilonUV)','heat_kernel_16pi2':'2*E1(2*s)-E1(s)+(exp(-s)-exp(-2*s))/s,s=t*p_E^2>0','heat_finite_constant':str(expected),'differential_extension_finite_constant':str(2*s.log(2)-2*s.EulerGamma),'heat_matching_delta_16pi2':str(local),'arbitrary_local_extension_parameter':'real kappa retained;not identified with prior scalar b0 or adopted as a physical scheme','relative_common_heat_rescaling':'-log(alpha)*T in the same 32pi^2 normalization','finite_heat_quad_errors':errors,'distribution_domain':'tempered Euclidean x-space extension of1/(16pi^4*x^4);nonexceptional p_E^2>0;no Lorentzian/QAP/simultaneous restoration theorem','IR_component_bound':'excluded epsilon balls contribute <=epsilon^2/(2pi^2*p_E^2),uniform t;epsilon<|p|/2;no p=0 or full-theory IR removal','all_source_partners_and37_source_flow_products_still_required_globally':True,'controls':controls,'control_sensitivity_zero_tensor_case':'odd-sign/factor controls insensitive if the computed whole tensor is zero;generic one-pair fixture has T=-2','shared_limits':'same action,reference,source maps,Wick/real charts,software and AI author;distinct trace/Wick/radial routes are computational corroboration,not independent physical validation','no_Gamma_b0_scheme_authority_or_protected_change':True,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(record,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
