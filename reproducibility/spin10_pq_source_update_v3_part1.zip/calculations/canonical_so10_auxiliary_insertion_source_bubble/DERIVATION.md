# One actual kernel and a matched family of coincidence extensions

For an external probe rho,adding rho*O_affine with
O_affine=a[J,A]+b_z[J,A,partial] z shifts only the ordinary Legendre sources
and a field-independent term. At fixed mean fields Gamma changes by that same
affine functional. Thus its intrinsic loop insertion vanishes exactly. A
derivative on B shifts j_B by minus the derivative on rho,and the explicit
current partial(rho B) remains. External JL is not integrated:JL*C is affine.
Of the12 raw patterns only BB,xx,Ca have nonzero integrated Hessians. The
covariant D.q is also affine in B at fixed A. Finite operator mixing with these
affine directions and contacts between multiple probes remain separate.

For the actual special shift O_i=X_L^i=g^2*xi*beta_ij C_j*a12 and source
vertex Ja_k*Qa_k,use the same full odd inverse and graded Hessian convention
as the qualified action. With P=p_M^2,N=P*G_odd,the two ordered n2 Born
positions give the actual coefficient

 T_ik=STr_odd(N H_Oi N H_Qak)

in hbar/(32pi^2 epsilonUV) units. The scalar Minkowski residue is2i in these
units and the two Born positions each carry -i/4. No commuting color shortcut
or discarded opposite odd orientation is allowed. Equivalently T is twice the
connected four-odd Wick contraction of the two densities using covariance N.
For one pair with N=[[0,1],[-1,0]],O=Qa=C*a,this gives T=-2.

All20 free tadpoles vanish if the actual a12 row/column pairs only with C12
and no O_i contains C12. The source coefficient has one g1 Ja ghost vertex;
all other mean fields are zero. At total g3*xi the quadratic insertion plus
this vertex exhausts the one-loop sector. A scalar mass/reference vertex is
in a disconnected block,while positive-g ghost mass insertions change the
coupling order. This argument is specific to the stated coefficient.

The normalized loop contribution is hbar*T_ik*I_t(p)/2. At flat background the
actual dual heat factors give one exp(-2tq^2) per propagator. Schwinger parameters
alpha,beta>=2t and Gaussian integration yield,with s=t*p_E^2>0,

 16pi^2 I_t(p)=integral_0^1 du E1(2s*max(u,1-u))
             =2 E1(2s)-E1(s)+(exp(-s)-exp(-2s))/s.

Independently,dI_t/dt follows by differentiating the two heat legs;the two
Gaussian/Schwinger boundary integrals give

 d(16pi^2 I_t)/dt=-(exp(-tp^2)-exp(-2tp^2))/(t^2*p^2).

The decaying boundary at t=infinity fixes the same expression. Therefore

 16pi^2 I_t=-log(t*p^2)-gamma_E+1-2log2+O(t*p^2).

Subtract the divergent -log(t*mu^2),retaining symbolic mu and an arbitrary real
local finite coefficient. The matched finite kernel is

 B_heat(p;mu)=log(mu^2/p^2)-gamma_E+1-2log2.

Common heat rescaling t->alpha*t shifts it by -log(alpha). This is not the
384 scalar P12 contact tensor and does not determine its baseline b0.

For the explicit distribution construction,use Fourier convention
F(f)(p)=integral exp(-ipx)f(x)dx,inverse measure dp/(2pi)^4. The free scalar
kernel is D(x)=1/(4pi^2*x^2). Its square is smooth away from x=0 and has scaling
degree4. The primitive log(mu^2*x^2)/x^2 is locally integrable and tempered.
Define R_mu=-Delta primitive/4 as a distribution. Off the origin R_mu=1/x^4;
its delta freedom is precisely a finite local constant at this scaling degree.

The Gaussian/Schwinger Fourier calculation gives

 F[(x^2)^(-a)]=2^(4-2a)*pi^2*Gamma(2-a)/Gamma(a)*(p^2)^(a-2), 0<a<2.

Differentiating at a=1 yields

 F[R_mu]/(16pi^4)=[log(mu^2/p^2)+2log2-2gamma_E]/(16pi^2).

Consequently the actual heat-matched extension of D(x)^2 is

 K_heat,mu=R_mu/(16pi^4)
       +(gamma_E+1-4log2)*delta(x)/(16pi^2).

Adding kappa*delta/(16pi^2) is an explicit nonempty family for THIS component.
It is a mathematical witness,not adoption of a physical subtraction scheme.
Multiply by the measured T/2 and keep source dual maps. A kappa*T contact
density must pass actual local-H and physical-reality checks. More general
allowed local mixing tensors are not fixed by this one coefficient.

At fixed nonexceptional p and epsilon<|p|/2,the omitted balls |q|<epsilon and
|q+p|<epsilon each obey denominator bound1/(q+p)^2<=4/p^2 after a shift.
The heat numerator is<=1. Their combined integral is bounded by
epsilon^2/(2pi^2*p^2),uniform in t. This justifies removing the temporary IR
restriction for this coefficient,not taking p->0 or removing physical IR
restrictions throughout the theory.

The extension exists as a Euclidean tempered distribution and its heat matching
is explicit. We do not claim that all Lorentzian source products,nonlinear
field transformations,measure terms and Ward/Slavnov contacts share this
prescription. Those simultaneous compatibility equations remain outstanding.

Reference standards:Brunetti--Fredenhagen Theorem5.3 concerns finite-scaling-
degree extensions and local ambiguity (https://arxiv.org/pdf/math-ph/9903028).
Freedman--Johnson--Latorre develop derivative representations of singular
kernels (https://doi.org/10.1016/0550-3213(92)90240-C). Our normalization and
model coefficient are derived and checked here;these works do not validate
the shared Spin(10) premises or establish this model's full QAP.
