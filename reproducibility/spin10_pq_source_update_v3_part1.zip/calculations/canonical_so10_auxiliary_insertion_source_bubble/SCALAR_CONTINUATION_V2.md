# Scalar-linear continuation after the complete source zero

Both completed V1 routes find the entire45x45 rho/Ja coefficient zero. This is
a scientific zero,not a failed execution. Every Qa ghost vertex lacks C12;
the actual a12 propagator requires C12 at the companion vertex. The result
and its sources/captures remain immutable and require separate validation.

The actual GF contains6688 scalar/ghost density terms,including384 with C12.
The next competent test is the COMPLETE rho_i*x_s coefficient at g4*xi^2,
all45x328=14760 canonical positions and their physical evaluation-dual images.
No desired value or nonzero support count is supplied. Scalars are full unshifted
Cartesian coordinates,not adoption of a new vacuum. Implicit dimension1
background/VEV factors in the fixed Y coefficient remain as declared inputs.

At zero other mean fields/sources,the Hessian has no odd/even mixing. The
probe loop stays in the odd block. The only linear-x odd interaction is the
actual g2*xi Y density. The zero-field odd kinetic block is the frozen reference;
any remaining zero-field ghost mass is positive-g and cannot enter g4*xi^2
after X(g2*xi) and Y(g2*xi). Verify this census and preserve its true coupling
degrees. Thus the two-vertex bubble exhausts this coefficient,including finite
nonexceptional momentum dependence. No scalar/vector/auxiliary graph is
discarded merely for convenience.

Compute T_is=STr(N H_Xi N H_Ys) and independently twice the connected four-odd
Wick contraction. Retain all14760 positions,all zeros,g4*xi^2 normalization,
canonical/physical tensor agreement,actual source-dual rho transport,scalar
primal inverse transport and local contact H covariance/physical reality.
Wrong source/field duality is a control where sensitive. No Ja result is
refitted or reclassified. Reuse the completed source zero with explicit hashes.

The actual scalar loop is the same I_t(p) derived in V1,now multiplied by a
separately measured T_is. Complete and independently verify its heat finite
part and explicit Euclidean distribution extension,including local matching
constant and arbitrary real kappa. If T vanishes,report zero honestly. Neither
kappa nor this g4*xi^2 coefficient is the older g3*xi^2 scalar baseline b0.
No inference of simultaneous QAP/Slavnov/field-equivalence or physical scheme.

Standing delegation authorizes this new bounded increment:two sequential120s/
8GiB native workers and one180s/8GiB separate verifier of BOTH completed
sectors and analytic construction.350MiB available-commit floor;newbytes<5MiB.
Freeze/launch separately,no automatic reuse of old execution allowances.
All original scientific obligations,authority and protected boundaries persist.
