# Actual auxiliary insertion/source bubble and coincidence extension V1

Base62c834f120ada2c06648ae71a4c7213e01773015,main. Previous turn PROGRESS.
Question:can the actual dimension2 auxiliary insertion be reduced to its
intrinsic quadratic kernels,and can one COMPLETE source partner sector be
calculated and extended to coincidence without fitting a Ward remainder?
This is a quantum-construction increment,not another global coverage audit.

Freeze actual20 canonical X_L shifts,all45 Qa columns/source vertices,full90
odd reference inverse,physical evaluation-dual frame,E3 source/background maps,
positive-heat Born and Wick normalization,12-pattern module and receipts.
Keep both odd orientations,all45 source/target directions,all2025 coefficient
positions and implicit zeros. No old Dplus input. No Gamma integration.

First establish exact single-probe Legendre/Hessian reduction:of12 raw module
families,nine are affine in integrated fields. Their fixed-mean-field intrinsic
loop insertion is zero;this is NOT zero finite mixing or zero multi-insertion
contacts. Only BB,xx,Ca are intrinsically quadratic. Retain local-probe boundary
currents for partial.B and all external source terms Ja/JL*C.

Selected complete sector:one rho_i*X_L^i probe and one Ja_k,order g3*xi,flat
external background/all other mean fields and BV sources zero AFTER Hessian.
External probe/source momenta p,-p with p_E^2>0. The actual free tadpole must
be checked over the full odd inverse;X uses no C12 and a12 pairs only with C12.
No auxiliary/physical graph is dropped without coupling,field and block proof.
All source Ja linear-L terms have zero integrated Hessian;the only remaining
g3*xi loop is the two-vertex ghost bubble. Potential/reference scalar mass
insertions cannot enter that ghost loop. Higher-g ghost mass insertions are
outside this declared coupling coefficient,not globally zero.

Primary:actual graded odd Hessians and sparse matrix supertrace.
Replay:literal four-odd Gaussian/Wick contractions,disconnected subtraction,
both cross pairings and inherited Minkowski UV normalization.
T_ik=STr(N H_Xi N H_Qak),N=P*G_odd,includes g3*xi.
Generic1-pair fixture T=-2 fixes sign/factor in the same normalization.
No expected nonzero coefficient is supplied:zero or nonzero are valid outcomes.
Require complete canonical/physical tensor equality and physical reality.
Check local H covariance of the LOCAL contact density rho*T*Ja using actual
evaluation-dual source maps. This is not an off-flat nonlocal Ward theorem.

At A=0 each G_t has exp(-2t q^2). Derive the ACTUAL nonexceptional bubble
I_t=integral exp[-2t(q^2+(q+p)^2)]/[q^2(q+p)^2] with measure dq/(2pi)^4.
Primary:Schwinger parameters/Feynman split. Replay:heat-time differentiation,
Gaussian integration and boundary I_infinity=0. Independently match the
closed E1 form,finite constant,scale law and normalization.

Construct a tempered Euclidean diagonal extension using
R_mu(1/x^4)=-Delta[log(mu^2*x^2)/x^2]/4. Prove off-origin equality,local
integrability of the primitive,scaling degree4 and the delta normalization
Delta(1/x^2)=-4pi^2 delta. Derive Fourier normalization by Gaussian/Riesz
integration and match the actual heat finite part INCLUDING its finite local
constant. Keep an arbitrary real local extension parameter kappa;do not equate
it with the earlier b0 or adopt a physical subtraction prescription.

Retain the actual temporary IR restriction. For THIS nonexceptional component
only,prove removal of the two excluded epsilon-balls changes I_t by at most
epsilon^2/(2pi^2*p^2),uniformly in t,epsilon<|p|/2. No p=0/full-theory IR claim.
No causal/Lorentzian distribution or complete QAP is inferred from this
Euclidean coefficient extension. Other insertion/source families and nonlinear
products remain required for simultaneous Ward/Slavnov compatibility.

Controls:wrong odd trace/sign,missing factor2,wrong heat leg count,wrong finite
local constant,source affine sign,current omission,wrong physical source frame
(report any insensitivity),and forbidden C12 tadpole countermodel. Separate
verifier uses own coefficient algebra/Hessian/Wick method and analytic radial/
Riesz checks. Shared action,reference,frame,software and AI author disclosed.

Two sequential native120sec AFTER imports/8GiB sampled private,one separate
verifier180sec/8GiB;350MiB available-commit floor,new bytes<5MiB. Freeze/launch
separate calls;reject existing output/live owned workers;preserve failed runs.
No policy/state/old evidence/physical input/scheme/benchmark/remote changes.
Authority113/34of39,Gamma874873/source146663,source38,369/664,295 vector poles,
custody2/seven,all protected failures and blocks/pauses remain unchanged.
