# An actual insertion kernel with a matched Euclidean contact extension

Prospective qualification requires the separate completed validation receipt
and committed-byte checks. Four native workers completed with no scientific
failure. One prelaunch tool-script parsing error occurred before execution;
the corrected continuation preparation is preserved. No failed evidence erased.

The single-probe Legendre definition fixes intrinsic loop insertions for nine
of the12 raw families because they are affine in integrated fields. This
includes Ja and JL*C with external BV sources retained. Only BB,xx,Ca require
intrinsic quadratic kernels. This does NOT eliminate finite mixing into affine
operators or contacts between multiple probes.

First complete target:rho_i*X_L^i with one Ja source at g3*xi. All2025 positions
are zero in both routes. This follows from the actual reference a12 pairing:
the companion source vertex would need C12,but none of the45 Qa images contains
it. The20 free insertion tadpoles also vanish. The zero is retained;it is not
replaced by a convenient nonzero source coefficient.

The new scalar continuation uses the ACTUAL6688-term GF Y density. Its384
C12-containing terms permit a nontrivial contraction. The COMPLETE rho_i*x_s
sector at g4*xi^2 has

| Coordinates | Full positions | Nonzero | Zero |
|---|---:|---:|---:|
| Canonical45x328 |14760|368|14392|
| Physical45x328 |14760|304|14456|

The actual sparse supertrace and direct four-odd Wick contraction agree in
every position. The physical map uses the ordinary-source dual for rho and
the scalar primal inverse for x;all physical coefficients are real. The local
rho*T*x contact density satisfies all12 actual H equations. This is covariance
of the local tensor,not a full off-flat nonlocal Ward identity.

Both zero and nonzero sectors are calculated from the unchanged action,not
from the value required by an identity. The odd block closes at zero other
mean fields/sources. Its only g0 bilinear is the188-position two-jet reference
kinetic block. No zero-field mass can add an omitted same-order loop. Thus the
two-vertex ghost bubble exhausts this declared scalar coefficient,including
its nonexceptional momentum dependence. No whole-theory coefficient inventory
or physical vacuum is changed.

Let T be the exported tensor,including g4*xi^2. In hbar/(32pi^2) units the
actual finite-heat coefficient is T times

  2 E1(2s)-E1(s)+(exp(-s)-exp(-2s))/s, s=t*p_E^2>0.

It equals T[-log(t*p_E^2)-gamma_E+1-2log2+O(t*p_E^2)].
The arbitrary-scale finite part is therefore

  T[log(mu^2/p_E^2)-gamma_E+1-2log2+kappa].

The independent source rho is orderhbar0. This is not the effect of inserting
an orderhbar field redefinition,whose loop transport starts at a different
order. It is not the old384 scalar contact target at g3*xi^2 and determines
neither its b0 nor any physical benchmark parameter.

There is now an explicit tempered EUCLIDEAN coincidence extension for this
kernel. With R_mu=-Delta[log(mu^2*x^2)/x^2]/4,define

  K_heat,mu=R_mu/(16pi^4)
          +(gamma_E+1-4log2+kappa)*delta(x)/(16pi^2).

Its Fourier transform is the actual heat finite part above. The primitive is
locally integrable;the off-origin kernel is1/(16pi^4*x^4),with scaling degree4.
The extension parameter kappa stays real and free. A kappa*T local direction
passes the actual contact H and reality checks. No physical subtraction scheme
is adopted and no equality between kappa and the earlier b0 is asserted.

The temporary IR restriction can be removed for THIS p_E^2>0 component:
the omitted balls are bounded by epsilon^2/(2pi^2*p_E^2),uniform in heat time.
No p=0 limit,physical global IR removal or Lorentzian/causal extension is claimed.

This is more than a power-counting space:one actual nonzero quantum kernel and
an individual heat-matched coincidence-extension family are constructed. It is
less than a simultaneous quantum prescription. The other insertion classes,
37 correlated source-flow products,Slavnov descendants,off-flat companions,
measure and contact compatibility still require justification. An arbitrary
local tensor chosen to cancel a remainder would not supply that justification.

Next priority:test the Ward/Slavnov descendants and correlated source-product
extensions of this measured kernel with a common linear subtraction map.
Determine which defect is independently fixed and which contact conditions
remain free. Do not accumulate unrelated kernels or infer QAP from this result.
b0 stays symbolic;the295 vector poles remain secondary.

Separate validation must reconstruct all14760 canonical and physical positions
with a factorized Wick formula and independent coefficient parser,all2025
source zeros,actual dual maps/local H,heat integration and an independent Riesz
Laurent derivation of the finite matching constant. Shared action,reference,
charts,software and AI authorship remain common-premise limits;no Lean/expert
or experimental validation. Read receipt for actual timings/memory/controls.

Gamma874873/source146663,source38,369/664,authority34/39 and all protected
failures,blocks/pauses,custody exit2/seven remain unchanged. Full E5/A5 and
physical Spin(10)xPQ viability remain unqualified.
