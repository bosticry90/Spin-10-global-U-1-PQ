# Actual Ward mixed-term zero, not a sensitive omission control

V2 computed the complete Slavnov and Ward Hessians and both complete chain
identities agreed. It then failed a proposed negative-control assertion
that omitting the mixed chain terms must change BOTH results. For this
Kaux, D-minus has constant relevant source-kernel columns: its mixed chain
terms vanish. The proposed Ward omission control is therefore insensitive.
That does not remove the need to retain mixed terms in other insertions.

V3 requires the full Ward chain equality AND verifies each mixed Ward term
is zero. The Slavnov mixed-term omission must still give a nonzero remainder;
the D-plus sign, source-first and odd-sign controls remain required. Preserve
the complete failed V2 capture and sources. No coefficient, identity, type,
domain, limit or scientific acceptance condition is weakened.
