# Read-guard ordering correction

The first primary worker failed during input-byte authentication, before any
scientific calculation. Its JSON read allowlist correctly restricted the
calculation to its own route but was incorrectly applied also to hashing
all frozen evidence, including the prior control question. The complete
failed capture and frozen V1 sources are preserved.

V2 hashes all immutable input bytes first, then installs the role-specific
scientific JSON parse guard. It reads no new result or opposite native
route for calculation. No mathematics, input coefficient, acceptance or
resource limit changes. Only the failed primary was launched in V1.
