# A common formal first-probe normalization is constructed

Within the fixed Euclidean test-field and lifted-operator construction,
the finite subtraction now extends to the actual auxiliary primitive and
its source-dependent first-insertion identities. The selected old
heat-matched contact family is reproduced with one free kappa. This is a
bounded construction of first-probe products, not the complete QAP or E5/A5.

## What is new

The actual Kaux contains20 terms. Its full QKaux contains1,144 density
positions, and its corrected marked D-minus image contains40. The full
643-field second variation of QKaux contains9,968 positions; all of them,
including the zero complement, agree with the explicit differentiated
chain rule. Its four contributions have2,384,3,672,3,672 and1,592
positions before their sums combine. Omitting the mixed terms fails.

The primitive and Ward-image Hessians each have40 positions. For this
particular primitive the Ward mixed chain terms individually vanish.
Their omission is an insensitive control, explicitly recorded rather than
presented as independent evidence. Reversing the Ward source sign does
change the full insertion.

All sources remain until after differentiation. The whole auxiliary
source-product partner has216 positions. Together with the actual
auxiliary Euler contribution it satisfies the complete classical
primitive identity. Setting sources to zero first would lose20 nonzero
primitive source derivatives. The independent verifier reconstructs the
needed source Euler maps from the actual gauge-fixing plus source density,
rather than accepting the native result.

## The common map and finite matching

For the fixed lifted words, define

    T_kappa(A_D) = tau_h,mu(A4) - d_D alpha_D(A_D)|4
                    + [kappa - 1 - log(16*pi)] alpha4(A4)/2.

The corresponding normalized loop functional is
Gamma1,R[S_rho]=Gamma_ref[A]+(i/2)T_kappa(L_D[S_rho]), with the
inherited whole-functional reality projection where required. Its
difference from the actual heat finite part is the complete local
subtraction already constructed, retaining all positive heat jets and
power-prefactor convolutions. This is a candidate prescription family;
no physical scheme has been adopted.

The conversion1+log(16*pi) is independently derived. In units16pi^2,
the massless scalar bubble has:

| Construction | Finite constant, apart from log(mu^2/p_E^2) |
| --- | --- |
| Four-dimensional hard cutoff | 1 |
| Hard cutoff minus the first dimension jet | log(4*pi)-gamma_E+2 |
| Actual dual-heat prescription | 1-gamma_E-2log2 |

The dimension-jet result also follows from the independent
D-dimensional Schwinger/Gamma formula. Their difference from the heat
constant is1+log(16*pi). Thus the residue coefficient is
lambda=kappa-1-log(16*pi), leaving kappa free. The sphere normalization
cannot be suppressed.

The previously qualified368 Ward and1,712 ordered scalar descendant
coefficients are authenticated and reused, not counted as new loop
measurements. Their internal ghost bubble has no closed Lorentz index,
so the same conversion applies to the primitive and both descendants.
It reproduces their common kK=kD=kC=kappa family. It is distinct from
the older position-space differential-extension conversion.

Common heat-time rescaling shifts both the heat matching conversion and
kappa by log(alpha), leaving lambda unchanged. This establishes no
relation between kappa, b0 or the separately fixed infrared extension.

## Source and product terms retained

The first left probe derivative defines the insertion from this SAME
normalized functional, rather than assigning independent finite
coefficients to each descendant. The augmented classical action is not
assumed to satisfy the master equation. Its actual breaking is retained.
The differentiated sourced master-Hessian identity gives

    Q I_Kaux^(1) + (Gamma1,R,Kaux) = I_QKaux^(1).

The source bracket must remain outside the old scalar projection.
The corrected antighost Ward operation likewise gives the first-probe
identity

    D-minus Gamma1,R = I_(D-minus S)^(1)
                       + I_(V_J R_J)^(1)
                       - d_J Gamma1,R[V(phi)].

The last two terms are the connected source-product correction. A whole
product insertion and a source derivative with an externally held
direction are different operations; their difference has not been set
to zero. These equations are constructive operator-level identities.
No complete new canonical tensor for their full finite terms is claimed.

## Domain and limitations

Each retained probe has an independent Schwartz momentum-transfer label.
It cannot lengthen an unlabeled constant reference chain. The inherited
joint-kernel proof extends to the first probe and its first Slavnov
variation: the worst single unlabeled tangent has soft degree3 in four
dimensions. The individual free-edge approximants and the actual
prescribed IR family retain the same limit. Momentum delta terms remain.

Probes are scalar or internal evaluation-dual variables; their full
densities have dimension4 and ghost number0. The fixed rational metric
lift and local first-jet module therefore persist. The proof uses that
lift; it is not a universal trace on arbitrary integer-order operators.

No diagonal multiple-insertion restriction, constant-probe or adiabatic
limit was taken. The result does not construct the entire mixing module,
the complete nonlinear special-shear normalization, full b0/operator
transport, measure, quantum field/source equivalence or QAP. b0 remains
distinct and free. The nonzero actual finite shear-regulator response
must still be retained; a vanishing logarithm does not remove it.

## Verification and failures

Both native routes agree on the complete insertion polynomials and fully
computed Hessians. The separate verifier uses its own graded
differentiation, actual action Euler maps and an independent radial,
Gamma-logarithm and heat-quadrature derivation. Three positive-heat
quadratures agree with the exact heat function. Negative controls detect
source orientation, premature source removal, odd signs, missing
Slavnov mixed terms and missing finite/sphere normalization.

The successful native runs took5.07 and4.42 seconds after imports;
verification took4.49 seconds. Sampled private memory remained below584MB,
within the120/120/180-second and8GiB limits.

Two native failures and one verifier failure are preserved: an input
authentication/read-guard ordering error before science, an overstrong
Ward omission-control fixture despite matching complete chains, and a
documentation phrase check sensitive to a line break after the verifier's
scientific checks had passed. Corrected versions retain every scientific
acceptance condition. These are actual orchestration/control weaknesses,
not evidence for quantum inconsistency.

The methods share the action, geometry, reference, prior analytic
domain/master premises, exact algebra, software and AI analyst.
Agreement tests implementation; it does not validate the shared physical
premises. There is no external expert, experimental or Lean certificate.

## Standing and next decision

The next bounded question is the remaining full special-shear/operator
transport: can its nonlinear mean, source-product and finite regulator
terms be carried by the same prescription with b0 kept symbolic?
The first-probe construction supplies a defined starting map, but it
does not justify dropping those terms or assuming a diagonal product.

Authority remains project_state113/34of39 with all seven quantum flags
false. The measured Gamma874,873/source146,663 coupling-resolved input,
source38 theorem,369/664 antighost ledger and295 unmeasured vector
profiles are unchanged. Historical custody remains exit2/seven,
not PASS. The quartet failure, scalar quantum-control and gauge-matching
issues, HB1/C5 block and flavor pause remain. No old evidence, state,
action, policy or physical benchmark changed; no push/publication/outreach.
The overall Spin(10) x U(1)PQ investigation remains incomplete.
