"""Full auxiliary probe chains and two finite-normalization derivations."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,importlib.util,json,os,sys,time,threading
import sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1]
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
spec=importlib.util.spec_from_file_location('inherited_contact_algebra',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ('primary','replay')
 prep=read(O/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PROBE_WORKER_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('UNDECLARED_PROBE_JSON',str(p))
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
 A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
 fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs}
 Jof={n:J for n,J,h,k in pairs};fieldof={J:n for n,J,h,k in pairs}
 old=read(R/f'calculations/canonical_so10_correlated_contact_lift/{role}_result.json')
 K=v.unpack(A,old['actual_20_Kaux']);assert len(K)==20
 E2=read(P/f'frozen_a10_e2_transport/{role}.json')
 q={A.index[n]:A.rows(rows) for n,rows in data['master_field_maps'].items()}
 nonminimal={n for n in fields if A.names[n].startswith(('ub','bar','L','b'))}
 for n in nonminimal:q[Jof[n]]=A.rows(E2['complete_columns'][A.names[Jof[n]]]['source_polynomial'])
 neg=lambda x:v.scale(x,-1);add=v.combine;mul=A.product
 elem=lambda n:{(0,((n,()),)):u.ONE}
 act=lambda f,m,p:v.act(A,f,m,p,role)
 hmap={n:elem(h) for n,J,h,k in pairs};kmap={n:elem(k) for n,J,h,k in pairs}
 h=lambda f:act(f,hmap,0);k=lambda f:act(f,kmap,0)
 Hess=lambda f:k(h(f))
 C=act(K,q,1)
 D={A.index[f'ub{i}']:elem(A.index[f'zz_da{i:02}']) for i in range(12,45)}
 for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=neg(A.rows(rows,True))
 DK=act(K,D,0)
 HK=Hess(K);HC=Hess(C);HD=Hess(DK)
 active={n for gp,w in K for n,j in w}
 def chain(m,parity):
  mh={n:h(m.get(n,{})) for n in active};mk={n:k(m.get(n,{})) for n in active}
  mhk={n:k(mh[n]) for n in active}
  parts=[act(HK,m,parity),act(k(K),mh,parity),act(h(K),mk,parity),act(K,mhk,parity)]
  return parts
 qp=chain(q,1);dp=chain(D,0)
 assert HC==add(*qp) and HD==add(*dp)
 assert HC!=qp[0] and HD!=dp[0]
 assert not act(C,q,1),'ACTUAL_Q_SQUARED_K'
 gradients=u.left_gradients(A,K);X={n:v.scale(gradients.get(J,{}),-(-1)**A.parities[n]) for n,J,h0,k0 in pairs}
 XS={J:v.scale(gradients.get(n,{}),(-1)**A.parities[n]) for n,J,h0,k0 in pairs}
 X={n:f for n,f in X.items() if f};XS={J:f for J,f in XS.items() if f}
 assert len(X)==20 and len(XS)==21
 product={};fieldpart={}
 for J,f in XS.items():v.merge(product,mul(f,q[fieldof[J]]))
 for n,f in X.items():v.merge(fieldpart,mul(f,q[Jof[n]]))
 assert not add(C,product,fieldpart)
 jzero=lambda f:{key:co for key,co in f.items() if not any(n in sources for n,j in key[1])}
 assert not jzero(product) and product
 # Source-first and source-zero-first genuinely differ in the whole primitive.
 source_columns={J:gradients[J] for J in gradients if J in sources}
 assert len(source_columns)==20 and not jzero(K) and any(jzero(f) for f in source_columns.values())
 eids={A.index[f'zz_da{i:02}']:i for i in range(12,45)}
 Dcols={eids[n]:f for n,f in u.left_gradients(A,DK).items() if n in eids}
 for i,f in Dcols.items():
  assert all(not any(n in eids for n,j in w) for gp,w in f)
  assert all(sum(A.parities[n] for n,j in w)%2==0 for gp,w in f)
 assert all(sum(A.parities[n] for n,j in w)%2==1 for gp,w in K)
 assert all(sum(A.parities[n] for n,j in w)%2==0 for gp,w in C)
 print('STAGE',role,'complete_actual_hessian_chains_and_source_products',flush=True)

 # Independent Schwinger/Gamma and sphere/Stokes normalizations.
 e=s.Symbol('e');dim=s.Symbol('D');p2=s.Symbol('p2',positive=True);mu2=s.Symbol('mu2',positive=True)
 schwinger=(4*s.pi)**e*s.gamma(1+e)*s.gamma(1-e)**2/s.gamma(2-2*e)*(mu2/p2)**e
 sch_const=s.expand(s.diff(schwinger,e).subs(e,0)).expand(log=True,force=True)
 sphere=2*s.pi**(dim/2)/s.gamma(dim/2)/(2*s.pi)**dim
 sphere_slope=s.expand((s.diff(sphere,dim)/sphere).subs(dim,4))
 hard_const=s.log(mu2/p2)+1
 stokes_const=s.expand(hard_const-2*sphere_slope).expand(log=True,force=True)
 assert s.simplify(sch_const-stokes_const)==0
 heat_const=s.log(mu2/p2)+1-s.EulerGamma-2*s.log(2)
 delta=s.expand(sch_const-heat_const).expand(log=True,force=True)
 assert s.simplify(delta-(1+s.log(16*s.pi)))==0
 kap=s.Symbol('kappa',real=True);b0=s.Symbol('b0',real=True);lam=kap-delta
 assert s.simplify(sch_const+lam-heat_const-kap)==0 and s.diff(lam,b0)==0
 measured=read(R/f'calculations/canonical_so10_auxiliary_insertion_source_bubble/{role}_v2_result.json')
 compatible=read(R/f'calculations/canonical_so10_auxiliary_primitive_contact_compatibility/{role}_result.json')
 assert s.simplify(s.sympify(measured['heat_finite_constant'])-(1-s.EulerGamma-2*s.log(2)))==0
 assert compatible['Ward_nonzero']==368 and compatible['Slavnov_ordered_nonzero']==1712
 assert compatible['actual_contact_constraint_rank']==2 and compatible['remaining_contact_parameter_dimension']==1
 # The bubble's entire internal Hessian support is odd, with no Lorentz numerator.
 rows=measured['actual20_X_odd_Hessian_entries']
 assert rows and measured['all20_free_tadpoles_zero'] and measured['canonical_nonzero']==368
 # The exact density enforces the stronger support property independently.
 for n,f in X.items():
  assert all(A.names[n].startswith('L') and len(w)==2 and all(A.parities[a] for a,j in w) and all(not j for a,j in w) for gp,w in f)
  assert all(a!=A.index['C12'] for gp,w in f for a,j in w)
 alpha=s.Symbol('alpha',positive=True)
 assert s.simplify((kap+s.log(alpha))-(delta+s.log(alpha))-lam)==0
 wrongD={n:f for n,f in D.items() if n in fields}
 wrongD.update({A.index[n]:A.rows(rows,True) for n,rows in data['all33_kernel_maps'].items()})
 wrong=act(K,wrongD,0)
 scalarids={n for n in fields if A.names[n].startswith('x_')}
 pscalar=lambda f:{key:co for key,co in f.items() if all(n in scalarids for n,j in key[1])}
 controls={
 'omit_Q_mixed_hessian_terms_nonzero':bool(add(HC,neg(qp[0]))),
 'omit_D_mixed_hessian_terms_nonzero':bool(add(HD,neg(dp[0]))),
 'wrong_Dplus_changes_full_insertion':wrong!=DK,
 'source_zero_before_primitive_derivative_loses20_columns':len(source_columns)==20 and not jzero(K),
 'wrong_odd_prefix_changes_QK':v.act(A,K,q,1,'primary',True)!=C,
 'omit_sphere_first_jet_changes_finite_bubble':s.simplify(sch_const-hard_const)!=0,
 'omit_dimensional_to_heat_matching_changes_finite_contact':delta!=0,
 'scalar_projection_cannot_validate_Gamma_K_bracket':all(not pscalar(f) for f in gradients.values()),
 'b0_is_not_fixed_or_identified_by_this_match':s.diff(lam,b0)==0}
 assert all(controls.values())
 # Freeze full operator polynomials, fully evaluated Hessian hashes/zero complements.
 packed={key:u.pack(A,f) for key,f in [('Kaux',K),('QKaux',C),('Dminus_marked_Kaux',DK),('whole_aux_source_product',product)]}
 result={
 'schema':'AUXILIARY_PROBE_RENORMALIZATION_V1','route':role,
 'scientific_disposition':'COMMON_FORMAL_FIRST_PROBE_NORMALIZATION_WITH_FULL_AUXILIARY_SOURCE_CHAINS_AND_HEAT_MATCHED_KAPPA_NOT_FULL_QAP_A5_E5',
 'full_operator_polynomials':packed,
 'X20':{A.names[n]:u.pack(A,f) for n,f in X.items()},
 'unmarked_D_columns':{str(i):u.pack(A,f) for i,f in Dcols.items()},
 'operator_positions':{key:len(f) for key,f in [('Kaux',K),('QKaux',C),('Dminus_marked_Kaux',DK),('whole_aux_source_product',product)]},
 'Hessian_fully_computed':{key:{'positions':len(f),'sha256':A.fingerprint(f)} for key,f in [('Kaux',HK),('QKaux',HC),('Dminus_marked_Kaux',HD)]},
 'hessian_mixed_terms_positions':{'Q':[len(f) for f in qp],'D':[len(f) for f in dp]},
 'source_gradient_nonzero_columns':len(source_columns),'all643_field_variation_directions_included':True,
 'same_whole_C_plus_source_product_plus_X_Euler_zero':True,
 'actual_source_coordinates_retained':sorted(A.names[n] for gp,w in C for n,j in w if n in sources),
 'selected_kernel_no_closed_vector_D_trace':True,
 'bubble_hard_constant':'log(mu2/p2)+1',
 'bubble_dimensional_constant':str(sch_const),
 'bubble_stokes_constant':str(stokes_const),
 'bubble_heat_constant':str(heat_const),
 'delta_star':str(delta),'residue_lambda':'kappa-1-log(16*pi)',
 'kK_kD_kC_common_kappa_constraints_reused_not_new_loop':compatible['actual_contact_constraint_rows'],
 'same_formal_functional_defines_first_insertions_and_source_connected_correction':True,
 'Slavnov_source_bracket_Gamma1_Kaux_retained':True,
 'b0_distinct_free_complete_transport_not_claimed':True,
 'domain':'joint Euclidean Schwartz first probe and first Q variation with fixed lifted words; no diagonal multi-insertion or constant-probe limit',
 'controls':controls,
 'limitations':'Full nonlinear b0/special-shear/contact mixing,QAP,measure,A5,E5,physical IR/causal/Lorentzian and all295 vector coefficients remain unqualified; no scheme adoption or Gamma changes',
 'shared_limits':'Action,reference,geometry,old domain and master identities,Python/SymPy,frozen algebra and AI analyst; no independent physical or Lean validation',
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
