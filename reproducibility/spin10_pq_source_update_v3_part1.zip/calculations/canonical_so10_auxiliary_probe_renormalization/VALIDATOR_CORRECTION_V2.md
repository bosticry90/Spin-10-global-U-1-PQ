# Documentation-whitespace validation fixture

The first separate verifier completed its independent action-Euler,
source-full Hessian and finite-bubble calculations successfully. It then
failed a documentation-completeness string test: "no closed vector" crossed
a line break in the frozen derivation. V2 normalizes whitespace for that
text-only fixture. The mathematical checks, sources and native results
remain unchanged. Preserve the complete failed validation capture and V1
verifier. New failed workers: two native, one verifier, all retained.
