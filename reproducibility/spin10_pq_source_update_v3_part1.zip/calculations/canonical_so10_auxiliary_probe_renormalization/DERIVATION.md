# A common lifted first-probe normalization

Prospective argument; actual coefficient checks and domain review required.

1. Add rho O to the actual even source-linear action, with the probe types
in RECORD. Keep the fixed reference and its actual covariant heat factors.
The full loop Hessian includes all643 field directions and source backgrounds.
O is Kaux, QKaux, an unmarked D-minus Kaux, or X_i. No source is set to
zero before differentiation. Their linear combinations include the full
auxiliary source product, not its product of expectation values.

For each first probe coefficient, every insertion has an independent
external Schwartz probe label. The old zero-label constant mixed chains
are unchanged; probe vertices cannot lengthen those chains without adding
a transfer label. The actual dressed edge exponents are BB2,BL1,Bx1,xx0,
Ca2. One unlabeled constant symmetry tangent gives exponent at most3,
below the four-dimensional critical value4. Probe-dependent tangents have
labels. Rooted transfer variables therefore give the same joint L1
majorant as V310 for the first probe and its first Q variation. Ordinary
derivatives add polynomial numerators, not new soft denominators.
The individual free-edge smooth approximants and actual covariant IR
profiles have the same joint limit; keep distributional momentum deltas.
This does NOT restrict the probe transfers to zero, identify their points,
or prove a multiple-product diagonal extension. If a test requires such a
restriction, it is outside this construction.

The UV class remains rational metric-natural. External scalar probes add
no Lorentz traces; dimensions are nonnegative, each total probe density
has dim4 gh0. Q annihilates the probes. The relevant local module remains
rank<=4 including probe jets. Thus the inherited first dimension jet and
the single-probe derivations commute in this module. No generic
four-dimensional cyclic trace, chiral extension or new physical regulator
is being asserted.

2. On the admitted LIFTED words define, with fixed UV subtraction scale mu,

 T_kappa(A_D)=tau_h,mu(A4)-d_D alpha_D(A_D)|4
                    +(kappa-delta_star)*alpha4(A4)/2.

tau_h subtracts all powers and logarithms, with the qualified common IR
prescription held fixed. alpha includes the sphere normalization and all
closed vector D traces. delta_star below is a derived finite conversion,
not an anomaly coefficient. For logarithm L_D[S_rho], let

 Gamma1,R[S_rho]=Gamma_ref[A]+(i/2) T_kappa(L_D[S_rho]).

Use the inherited complete real projection if needed. Its difference from
the actual heat finite part is the COMPLETE local Lheat/first-jet
counterterm, including positive heat jets and prefactors times power
divergences. This is a constructed candidate prescription family, not an
adopted physical scheme. The Stokes theorem proves T_kappa([A_D,B_D])=0
on these lifted words modulo the x current. Differential tangent traces
are zero. The residue term is cyclic there. Lift data cannot be discarded.

The all-n ordered logarithm variation and the common joint domain then
give I_O^(1)=EL_rho^L Gamma1,R|0=(i/2)T_kappa(G H_O).
This formula defines the insertion; it does not assume multiplication
commutes with renormalization. For local probes it means the full test-
function kernel with derivative currents, not just a constant rho vertex.
The IR/nonlocal part is unchanged, and the difference is a local extension.

3. Determine delta_star from the actual scalar bubble, with p_E^2>0.
In units16pi^2 its hard finite part is log(mu^2/p_E^2)+1. One derives
this by the four-dimensional angular average
<1/(q+p)^2>=1/max(q^2,p^2), splitting the radial integral at |p|.
The D-dimensional Schwinger integral is

 (4pi)^(-2+e) Gamma(e) Gamma(1-e)^2/Gamma(2-2e)
                      *(mu^2/p_E^2)^e, D=4-2e.

Its pole-subtracted constant is log(mu^2/p_E^2)+log(4pi)-gamma_E+2.
Independently s4'/s4=-log2-log(pi)/2-(1-gamma_E)/2;
hard minus alpha prime gives exactly the same constant. The actual
dual-heat bubble has constant log(mu^2/p_E^2)+1-gamma_E-2log2.
Hence delta_star=1+log(16pi). Choosing the residue coefficient
lambda=kappa-delta_star produces the existing heat-matched extension
plus kappa. This leaves kappa arbitrary; no value is fitted.

The selected measured T,W,L are internal odd-ghost contractions with no
closed vector index. Their D-lifts have no extra D factor; the same
universal bubble conversion applies to all three. This is different from
the older position-space differential-extension conversion
gamma_E+1-4log2. Under common heat-time rescaling alpha, delta_star
and kappa both shift by log alpha, so lambda is invariant. This does
not identify kappa with b0 or alter the fixed IR extension parameter.

4. For S_rho not necessarily master-invariant, put
B_rho=(S_rho,S_rho)/2, Q_rho=(S_rho,.).
Twice differentiating this ACTUAL tree expression gives

 Q_rho H_rho+M_rho^sharp H_rho+H_rho M_rho=H_Brho.

The same ordered trace argument, without assuming B_rho=0, gives
(S_rho,Gamma1,R[S_rho])=I_Brho^(1).
For the odd left rhoK coefficient this is

 Q I_Kaux^(1)+(Gamma1,R,Kaux)=I_QKaux^(1).

The second term is required outside the old scalar projection. Full
Hessian chain identities in the native runs check every mixed term.
There is no assertion that QKaux can be replaced by a scalar kernel.

For corrected D-minus=delta_a-V_J d_J, field-independent antighost shift,
B_a=D-minus S:

 D-minus Gamma1,R=I_Ba^(1)
                  + I_(V_J R_J)^(1)-d_J Gamma1,R[V(phi)].

The last two terms are the connected source-product correction, both
defined by this SAME functional. In the second, the source direction is
held external during differentiation and substituted afterwards. In the
first, V R is a whole product insertion. Do not set their difference to
zero or take it as a product of means. This is an operator prescription
for first-probe identities, not a measured complete contact tensor.

5. The selected old nonlocal ordered L and its local Bose contact are
distinct and retained. The common family above matches their already
qualified constraints kK=kD=kC=kappa. It does not exhaust the nine-family
mixing module, fix every other finite contact, or prove full QAP.

The earlier homogeneous finite order-hbar canonical counterterm b0 QKfull
remains separate. If transported, its probe companions are
b0(O,Kfull) from the same augmented classical functional, with the
corresponding operator/source transport. A fixed D-minus image of QKfull
is not zero. This increment does not compute or adopt that complete
b0-transport system, impose new b0 conditions or identify it with kappa.

The actual finite special-shear heat response is not zero and must remain
in Lheat. A primitive defining T_kappa can subtract that independently
defined local finite response; a zero logarithm alone cannot do so.
This increment does not promote that observation to a full renormalized
special-shear, quantum measure or field/source-equivalence theorem.
