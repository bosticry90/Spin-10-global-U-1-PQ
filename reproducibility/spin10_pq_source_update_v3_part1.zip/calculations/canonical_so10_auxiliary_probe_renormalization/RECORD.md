# Common auxiliary first-probe subtraction, V1

Question APR1: can the constructed lifted one-loop subtraction define the
actual auxiliary primitive, its full source/Slavnov/corrected Ward
descendants and their selected heat-matched contact constants together?
Base 2a101e4ed8517361eba5612d3708a1404349c1f0, main. Prospective contract;
no result is accepted until paired calculations and separate validation.

Reuse the qualified formal finite primitive, joint Born/first-Q IR domain,
actual full master/Hessian/source maps and selected common-kappa kernel.
The inexpensive competent test is full polynomial Hessian chain rules and
an independent finite bubble matching, plus an explicit extension-domain
proof. Repeating 295 vector tensors or the whole measured Gamma adds no
needed input. Success constructs a bounded first-probe normalization map;
failure/underdefinition preserves the precise domain or sign obstruction.

Types: full Cartesian Euclidean external Schwartz fields/sources; fixed
metric-natural dimension lift, actual mixed reference and dual heat words.
Kaux odd dim3 gh-1, rhoK odd dim1 gh+1; QKaux even dim4 gh0,
rhoQ even dim0 gh0; unmarked D_a-minus Kaux even dim2 gh0,
evaluation-dual rhoD^a even dim2 gh0. Twenty X_i are even dim2 gh0
with even dual dim2 probes. Marked D has even total parity, not unmarked
D's odd parity. Probes are external, not canonical pairs. Keep ALL sources,
ordinary jets, parameter derivatives and currents. The real structure is
order-preserving, not an extra Hermitian ghost adjoint.

Construct only the first probe jets and their first full Slavnov variation
as joint distributions. No diagonal multiple-insertion pullback, constant
probe or adiabatic limit, general QAP, quantum measure/A5, causal/Lorentzian
or physical vacuum assertion. The augmented action need not solve the
master equation. Retain its actual tree breaking, (Gamma1,Kaux), and
connected source-product correction. No mean-product factorization.

Method P: actual wordwise left variations and explicit chain terms;
Schwinger/Gamma expansion for finite bubble. Method R: suffix/gradient
reordering with Koszul signs; cutoff angular mean and sphere first jet.
Both use frozen algebra but may read only their own inherited route.
Compare complete actual full-field Hessian polynomials and zero complements;
store complete insertion polynomials and exact hashes/counts of fully
computed Hessians, not a silently truncated dense tensor. Existing 368/1712
selected tensors are authenticated and matched, not rerun as new loops.
Separate verifier uses its own graded differentiation, no new native helper,
checks full insertion polynomials/Hessian chain and scalar finite matching.
Shared action, geometry, reference, old domain proofs, algebra/runtime and
AI analyst remain common-error limits; no external or Lean certificate.

Freeze code, derivation and immutable inputs before workers. Native limits
120 seconds after imports each, verifier180; sampled private8GiB with the
existing available-commit floor. Store full captures before acceptance.
Output/new-package byte ceiling5MiB. Resource exhaustion is incomplete,
not an obstruction. Preserve every failed run/source. Native computation
must not write or read the other route/new expected output.

Controls: remove mixed Hessian terms, reverse D source orientation, set
sources zero before differentiating, use wrong Grassmann signs, drop sphere
normalization or finite matching shift, identify independent kappa and b0.
Insensitive controls must be labeled. All-n/domain arguments, not finite
counts, supply the formal scope.

No action, physical scheme, benchmark, old evidence/state/policy, Gamma,
source38 theorem, seven false quantum flags or34/39 authority changes.
b0 and kappa stay distinct/free. No blocked/paused activation, push,
publication or outreach. Custody exit2/seven is not PASS. A positive
result does not complete E5/A5 or the overall investigation.
