# BRT1 V2:retain scalar-source changes in the full four-direction family

Both V1 numerical routes completed and agree:the supported skew gauge module
has dimension4,the kernel of its ghost-bracket CE map is the2-dimensional
inner-adjoint subspace,and the2-dimensional nonzero ghost-head quotient fails
the ghost Jacobi extension test. These numerical results are preserved.

The prospective interpretation that those two inner directions could be
removed as trivial FULL shifted cocycles is not justified. G_K for K=ad_y
rotates vectors and ghosts but has no scalar flow. The CLOSED full Noether
generator also has -Jx*rho_y*x. Therefore QG_K need not be a divergence,
and its shifted scalar-source coefficient can survive even when dK=0.
Do NOT identify the2-dimensional ghost-head quotient with the complete
BRST class space of the four cocycles. The original prospective report is
retained as RESULT_V1_PROSPECTIVE.md and is superseded by the V2 analysis.

V2 uses allFOUR exact rotation directions and their scalar-source heads.
A faithful real10 scalar subblock already tests the necessary second-order
condition. The full scalar source program is retained for all328 fields;
no claim to expand its entire roughly106million-position domain is needed
for a decisive obstruction. Derive its H-colour projection and a positive
quadratic Gram certificate on allfour parameters. Independently verify the
full leading ghost-plus-scalar source rank and polynomial exact-image test.

V1 completed workers are NOT rerun. New own-role V2 calculations consume the
authenticated completed V1 space and compute the additional source test.
Final independent verification must also validate V1's complete module and
ghost-Jacobi evidence before qualifying the combined result. No failed
worker occurred in V1;this is a preserved scientific-interpretation correction.
No physical action,scheme,parameter or acceptance criterion is relaxed.
Same120/120second native and180second verifier caps,8GiB sampledprivate,
350MiB available-commit floor and8MiB package. No E5/A5/authority promotion.
