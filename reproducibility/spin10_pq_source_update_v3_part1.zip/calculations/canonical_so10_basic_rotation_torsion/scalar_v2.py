"""Full four-direction scalar-source nilpotence and leading-class correction."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement,product
import json,gzip,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start();role=sys.argv[1];prep=read(O/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BRT_V2_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('BRT_V2_JSON',str(p))
 sys.addaudithook(guard);get=lambda k:read(Path(prep['artifacts'][role][k]['path']));v1=get('v1')
 def rat(v):
  v=s.cancel(v);assert v.is_Rational;return F(int(v.p),int(v.q))
 def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):s.Rational(z) for i,j,z in p['entries']})
 def nz(m):return {ij:rat(v) for ij,v in m.todok().items() if v!=0}
 def packet(m):return {'shape':list(m.shape),'entries':[[*ij,str(v)] for ij,v in sorted(nz(m).items())]}
 def add(out,k,v):
  z=out.get(k,F(0))+v
  if z:out[k]=z
  else:out.pop(k,None)
 def rk(rows):
  piv={}
  for rr in rows:
   r={j:F(v) for j,v in rr.items() if v}
   while r:
    j=min(r);c=r[j]
    if j not in piv:piv[j]={k:v/c for k,v in r.items()};break
    for k,v in piv[j].items():add(r,k,-c*v)
  return len(piv)
 K=[mat(p) for p in v1['full_skew_basis']];assert len(K)==4;PH=mat(get('pbl')['H_projector']);UH=s.Matrix.hstack(*PH.columnspace());pair=list(combinations(range(10),2));mono=list(combinations_with_replacement(range(4),2));phys=get('physical');rho=[]
 for p in phys['representation_matrices']['phi']:
  m=s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(z) for i,j,z in p['entries']});rho.append(m.extract(range(0,20,2),range(0,20,2))*s.sqrt(2))
 planes=[s.MutableSparseMatrix(10,10,{(i,j):1,(j,i):-1}) for i,j in pair]
 assert rho==planes and s.Matrix(45,45,lambda i,j:s.trace(rho[i].T*rho[j]))==2*s.eye(45)
 ff={}
 for a,b in product(range(45),repeat=2):
  c=rho[a]*rho[b]-rho[b]*rho[a]
  for out,(i,j) in enumerate(pair):
   if c[i,j]:ff[out,a,b]=rat(c[i,j])
 adj=[s.MutableSparseMatrix(45,45,{(a,b):int(v) for(a,cc,b),v in ff.items() if cc==c}) for c in range(45)];ad=lambda v:sum((v[i]*adj[i] for i in range(45) if v[i]!=0),s.zeros(45));rr=lambda v:sum((v[i]*rho[i] for i in range(45) if v[i]!=0),s.zeros(10));H=[ad(UH[:,i]) for i in range(12)]
 print('STAGE '+role+' all_four_ghost_and_faithful_scalar_leading_source_heads',flush=True)
 T=[];Rho=[]
 for k in K:
  a=[ad(k[:,i]) for i in range(45)];t={};r=[rr(k[:,i]) for i in range(45)]
  for u,v in combinations(range(45),2):
   vec=k*adj[u][:,v]-a[u][:,v]-adj[u]*k[:,v]
   if nz(vec):t[u,v]=vec
  T.append(t);Rho.append(r)
 rows=[]
 zero=s.zeros(45,1)
 for u,v in combinations(range(45),2):
  vs=[T[i].get((u,v),zero) for i in range(4)];outs=set().union(*(set(i for(i,j) in nz(vec)) for vec in vs),set(out for(out,a,b) in ff if a==u and b==v))
  for out in outs:
   vals=[rat(vec[out]) for vec in vs]+[ff.get((out,u,v),F(0))]
   if any(vals):rows.append({j:z for j,z in enumerate(vals) if z})
 for c in range(45):
  keys=set().union(*(set(nz(Rho[i][c])) for i in range(4)),set(nz(rho[c])))
  for ij in keys:
   vals=[rat(Rho[i][c][ij]) for i in range(4)]+[-rat(rho[c][ij])];rows.append({j:z for j,z in enumerate(vals) if z})
 assert rk(rows)==5
 print('STAGE '+role+' actual_scalar_square_and_complete_H_projection',flush=True)
 scalar={};projected={};blocks={(h,m):{} for h in range(12) for m in range(10)};hrow={c:[(h,rat(UH[c,h])) for h in range(12) if UH[c,h]!=0] for c in range(45)}
 AK=[[ad(k[:,i]) for i in range(45)] for k in K]
 for u,v in combinations(range(45),2):
  for m,(i,j) in enumerate(mono):
   vt=K[i]*T[j].get((u,v),zero)
   if i!=j:vt+=K[j]*T[i].get((u,v),zero)
   if role=='primary':
    S=Rho[i][u]*Rho[j][v]-Rho[j][v]*Rho[i][u]
    if i!=j:S+=Rho[j][u]*Rho[i][v]-Rho[i][v]*Rho[j][u]
    S+=rr(vt);assert not nz(S+S.T);nv=s.Matrix([S[a,b] for a,b in pair])
   else:
    nv=AK[i][u]*K[j][:,v]+vt
    if i!=j:nv+=AK[j][u]*K[i][:,v]
   for(c,col),z in nz(nv).items():
    add(scalar.setdefault((c,u,v),{}),m,z)
    for h,co in hrow[c]:add(blocks[h,m],(u,v),co*z)
   pv=PH*nv
   for(c,col),z in nz(pv).items():add(projected.setdefault((c,u,v),{}),m,z)
 G=s.Matrix(4,4,lambda i,j:sum(s.trace((K[i]*h).T*(K[j]*h)) for h in H));assert G.T==G;minors=[s.factor(G[:n,:n].det()) for n in range(1,5)];assert all(z>0 for z in minors)
 LDL,DD=G.LDLdecomposition(hermitian=False);assert LDL*DD*LDL.T==G and all(DD[i,i]>0 for i in range(4))
 for h in range(12):
  for m,(i,j) in enumerate(mono):
   B=s.MutableSparseMatrix(45,45,{ij:s.Rational(v.numerator,v.denominator) for ij,v in blocks[h,m].items()});B=B-B.T;expected=K[i]*K[j]*H[h]
   if i!=j:expected+=K[j]*K[i]*H[h]
   assert not nz(B-expected),(h,m,'ACTUAL_SCALAR_N_H_COEFFICIENT')
 for m,(i,j) in enumerate(mono):
  co=0
  for h in range(12):
   B=s.MutableSparseMatrix(45,45,{ij:s.Rational(v.numerator,v.denominator) for ij,v in blocks[h,m].items()});B=B-B.T;co-=s.trace(B.T*H[h])
  assert s.expand(co-(G[i,j] if i==j else 2*G[i,j]))==0
 def hsh(d):return sha256(json.dumps([[*k,[str(row.get(i,0)) for i in range(10)]] for k,row in sorted(d.items()) if row],separators=(',',':')).encode()).hexdigest()
 # Ghost-rule term is included above but is insensitive after H projection.
 assert all(not nz(PH*k) for k in K)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10');counts={'JC':0,'Jx':0}
 for n,rows0 in data['master_field_maps'].items():
  if n.startswith('x_') or (n.startswith('C') and n[1:].isdigit()):
   label='Jx' if n.startswith('x_') else 'JC'
   for row in rows0:
    z=s.Poly(s.sympify(row['coefficient']),g);assert z.degree()==1 and z.eval(0)==0;counts[label]+=1
 out={'schema':'BASIC_ROTATION_FULL_SCALAR_V2','route':role,'scientific_disposition':'FOUR_PARAMETER_BASIC_CLASS_AND_FAITHFUL_SCALAR_EXTENSION_OBSTRUCTION_PENDING_INDEPENDENT_VALIDATION','completed_v1_numeric_space_reused_not_rerun':True,'rotation_family_dimension':4,'ghost_head_quotient_dimension_only':2,'full_leading_source_plus_coupling_rank':5,'four_independent_full_cocycle_directions_not_quotiented_by_inner':True,'faithful_scalar_subblock_real_dimension':10,'full_scalar_program_domain':328,'scalar_actual_square_normalization':'-(1/2)*rho0(Nbar)','full_scalar_colour_tensor_nonzero_positions':len(scalar),'full_scalar_colour_tensor_sha256':hsh(scalar),'H_projected_scalar_tensor_nonzero_positions':len(projected),'H_projected_scalar_tensor_sha256':hsh(projected),'scalar_positive_Gram':packet(G),'positive_Gram_principal_minors':[str(z) for z in minors],'positive_Gram_L':packet(LDL),'positive_Gram_D':packet(DD),'all120_H_matrix_coefficient_identities_checked':True,'trace_combination_equals_positive_Gram_checked':True,'only_zero_of_full_four_parameter_family_passes_necessary_scalar_condition':True,'omitted_ghost_rule_term_in_H_projection_insensitive_disclosed':True,'actual_source_rows_with_explicit_g':counts,'inner_gauge_rotations_not_assumed_full_closed_generators':True,'full_physical_Euler_and_source_currents_retained_as_bound_programs':True,'quantum_normalization_admissibility_or_anomaly_verdict':False,'new_pole_integrated_or_authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
