# BRT1/V2 completed combined qualification

Completed receipt validation_receipt.json SHA256
e64e0f41764368f723ca983b46f28930ed84fd7fa7b9dabecb73f5d76782282c. Disposition:
QUALIFIED_FOUR_BASIC_ROTATION_COCYCLE_DIRECTIONS_WITH_COMPLETE_NECESSARY_SCALAR_EXTENSION_OBSTRUCTION_AND_EXPLICIT_QUANTUM_SCOPE_LIMITS.
V1 primary/replay 4.860675/6.030269s;
V2 scalar primary/replay 53.807899/52.179230s;
independent combined 25.732382s after imports. Largest
observed sampled private allocation 469524480B,not a true peak guarantee.
Every native is below120seconds,the verifier below180seconds,with8GiB sampled
private/350MiB launch floor/8MiB package. All98 validation input bytes unchanged.

## Complete finite-space and source evidence

Primary rational elimination has rank524 on528 bivector unknowns. Replay
constructs exact kernel vectors from the commuting Y/Z adjoint polynomials
and proves the matching rank modulo1000003. Four independent exact nullvectors
and the modular lower bound certify the complete rational kernel. The independent
verifier uses a DIFFERENT physical45-coordinate commutator constraint matrix
and another prime 1000037;its rank is again524.
No dimension was inferred from a few trial matrices. H and M centralizers
have dimension1 each,checked independently by a full-gauge constraint rank43.

The two-dimensional CE ghost-head quotient and its3048-position Jacobi tensor
remain valid numerical evidence. The independent adjoint-commutator method
reconstructs its complete hash and implicit zeros over638550 positions.
Mixed coefficients vanish;omitting them is INSENSITIVE in this example.

V2 corrects the interpretation to retain ALLfour full cocycle directions.
Native scalar-matrix commutators and colour-torsion contractions agree on
1040 supported colour positions and584 H-projected positions,with all ten
quadratic parameter monomials retained. Independent direct graded polynomial
composition of the scalar and ghost rules reconstructs both COMPLETE hashes,
including the actual -(1/2)rho0(Nbar) normalization. This is the faithful10
subblock,not a claim to materialize all328-scalar coefficient positions.

All120 H matrix/coefficient identities are verified. Their trace combination
gives the exact positive4x4 Gram with principal minors
1224/25,1997568/625,129019392/625,21675257856/15625.
The completed-square form in RESULT_V2 is strictly positive for every nonzero
real four-parameter vector. Thus no nonzero direction in this complete family
passes the necessary scalar-source extension equation. The metric is an
internal compact linear-algebra metric,not a positivity assertion about a
regulated quantum operator or the physical ghost Hilbert space.

The scalar Jx*x*C leading-source projection uses the complete six minimal
primitive carriers. It is applied AFTER source Euler extraction;physical Eulers
remain source-free and cannot cancel that coefficient. Joint source rank5
with the physical coupling direction proves four independent class directions
in this family modulo the stated parameter/exact/current span. The earlier
stationary JC projection detects only the two bracket-changing directions.
No full BRST-cohomology classification is claimed.

## Currents,applicability and independent limits

The whole34-term g0 AST and a fresh two-colour Maxwell variation verify the
free physical current. The source-current product rule is also retained.
All508 physical Euler programs and the same N/U transport remain bound as
programs;they are not freshly expanded or placed on shell. The positive-g
shift is on a finite polynomial density/current,not on a BRST class or a
Laurent primitive. At second classical order,local scalar-source types have
no B/derivative-ghost term;Q0x=Q0C=0,so a local second-order counterterm cannot
repair the displayed scalar-source square atg0. Nonminimal projection preserves
this necessary condition without treating its homotopy as canonical.

All443 QC and29754 Qx tree source rows are freshly checked to contain g.
The existing source-independent,g-regular local UV extraction argument is
conditional on its qualified reference/symbol premises. This is not a proof
of uniform g->0 limits for arbitrary finite nonlocal kernels or a newly
adopted condition on every finite W6 prescription.

## Preserved scientific correction and execution record

No native or verifier worker failed. One prelaunch patch-anchor attempt failed
without changing its target file;the corrected edit preceded verifier freeze.
A MORE IMPORTANT scientific-interpretation correction is preserved:V1's inner
adjoint kernel removes ghost-bracket changes,but cannot be discarded as a
trivial FULL shifted cocycle because its scalar-source correction survives.
RESULT.md and RESULT_V1_PROSPECTIVE.md remain unqualified historical prose;
use RESULT_V2.md. The correction is not a retraction of PBL1/BPC1 or of V1's
numerical ranks/hashes. Completed V1 workers were not rerun.

Shared action/master/Noether and primitive-census proofs,source/coordinate
conventions,older analytic constructions,Python/SymPy and AI authorship remain.
No Lean certificate,independent scientist,experiment or physical prescription
validation is supplied. The quantum functional and all old evidence remain
unchanged. Authority34/39,state113,E5/A5unqualified,custodyexit2/seven.
