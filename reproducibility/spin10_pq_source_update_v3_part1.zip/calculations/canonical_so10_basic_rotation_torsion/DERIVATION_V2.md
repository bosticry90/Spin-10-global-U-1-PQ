# Full rotation-family source test after the interpretation correction

Use the complete four-dimensional real skew H-equivariant K space established
by V1. G_K=-JB K B+JC K C has scalar field flow zero. Its shifted first-order
BRST corrections nevertheless have scalar rule r_x=+rho_(KC)*x and ghost
rule r_C=-t_K(C,C)/2,t_K=-dK. The old positive-g current construction defines
every D_K as a complete polynomial functional,with the source current too.

## Full leading source rank,not a quotient by closed gauge-algebra maps

Atg0,the scalar-source coefficient Jx*x*C of a polynomial QG is zero in the
minimal grade3 primitive language:Q0x=Q0C=0;Q0JC=divJB;Q0JB and Q0Jx have
physical SOURCE-FREE Eulers,and there is no minimal sourcequadratic primitive.
Source Euler extraction must precede the projection. Source-free Euler terms
are not set on shell;they cannot supply an independent Jx coefficient.
The nonminimal cochain projection commutes with Q and preserves exact images.
Ordinary currents have zero source Euler derivative. Thus the leading scalar
source head is an independent test even when the ghost head vanishes.

For allfour K_i,compute their ghost heads t_i and the faithful scalar10 heads
rho0(K_i C),where rho0=sqrt2*rho. Compare them with the physical coupling
head (F,-rho0 C). All physical potential/kinetic/background directions have
zero such leading source heads modulo polynomial exact normalizations.
A rank5 joint certificate proves that no nonzero combination of these four
D_K lies in that stated physical-parameter plus polynomial-exact span.
It does not classify all possible basic cohomology or actual quantum poles.

## Necessary scalar nilpotence on the full four-parameter family

Let K=sum_i a_i K_i. At second order in the formal classical normalization
parameter,the g0 scalar-source equation requires

 N_K(u,v)=[Ku,Kv]+K t_K(u,v)=0.

The actual scalar square is -rho(N_K) on every physical scalar block,with
normalizations retained. The real10 block is faithful,so a nonzero colour
component is already decisive. In the integer frame bracket F=sqrt2*f,
Nbar has rational coefficients and the actual scalar square is
-(1/2)rho0(Nbar). Compute it independently through scalar matrix commutators
and through the colour Nijenhuis expression,retaining the ghost-rule term.

Since K maps into M,P_H K=0. The H projection of N_K is therefore the H
projection of [Ku,Kv]. The K*t term is PRESENT in the full expression but
INSENSITIVE in this selected projection. For h in H,write A_h=sqrt2 ad_h.
Its bilinear coefficient matrix obeys

 <h,Nbar_K(e_a,e_b)>=(K^2 A_h)_(a,b).

This follows from invariant compact pairing,K^T=-K and [K,A_h]=0;derive the
sign with actual matrices. Therefore N_K=0 implies K^2 A_h=0 for every h.
For real skew K this also implies K A_h=0. Equivalently the nonnegative form

 sum_h ||K A_h||_HS^2 = sum_ij a_i a_j G_ij,
 G_ij=sum_h Tr((K_i A_h)^T(K_j A_h))

must vanish. A positive-definite exact4x4 Gram matrix is a COMPLETE certificate
that only K=0 passes this necessary scalar-source condition throughout the
chosen finite family. Prove positivity by exact principal minors/LDL,not a
floating sample. The scalar10 faithful extraction/H projection and all
quadratic cross coefficients are checked against the independently measured
colour tensor. Failure here excludes nonzero polynomial CLASSICAL master
extensions of this family,not arbitrary quantum prescriptions or the model.

The H trace contraction satisfies
 -sum_h <K^2 A_h,A_h>=sum_h||K A_h||^2,
so the positivity certificate is an explicit combination of actual necessary
source equations,not a rank calculation on invented equations. Normalizations
use only numerical compact metrics. Every physical/source current remains.

## Quantum boundaries

All actual JC AND Jx tree source vertices carry g. The source-independent
reference/inverse-symbol and coupling-linear local UV construction retain
that factor where their existing premises apply. These g0 source directions
are not generated there. Do not automatically turn this into a new condition
on every finite W6 insertion normalization or identify a failed classical
family with a quantum anomaly. General quantum admissibility remains a
separate construction question. No new pole is measured or integrated.
