"""Complete H-equivariant skew gauge rotations,source torsion and Jacobi test."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement,product,permutations
from fractions import Fraction as F
import json,gzip,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BRT_NATIVE_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('BRT_UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);get=lambda label:read(Path(prep['artifacts'][role][label]['path']))
 def rat(v):
  v=s.cancel(v);assert v.is_Rational;return F(int(v.p),int(v.q))
 def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(z) for i,j,z in p['entries']})
 def nz(m):return {ij:rat(v) for ij,v in m.todok().items() if v!=0}
 def packet(m):return {'shape':list(m.shape),'entries':[[i,j,str(v)] for(i,j),v in sorted(nz(m).items())]}
 def writehash(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 def add(d,k,v):
  vv=d.get(k,F(0))+v
  if vv:d[k]=vv
  else:d.pop(k,None)
 def echelon(rows,mod=None):
  piv={}
  for orig in rows:
   if mod is None:r={j:F(v) for j,v in orig.items() if v}
   else:r={j:(v.numerator*pow(v.denominator,-1,mod))%mod for j,v in orig.items() if v};r={j:v for j,v in r.items() if v}
   while r:
    p=min(r);c=r[p]
    if p not in piv:
     if mod is None:piv[p]={j:v/c for j,v in r.items()}
     else:
      inv=pow(c,-1,mod);piv[p]={j:v*inv%mod for j,v in r.items()}
     break
    for j,v in piv[p].items():
     w=r.get(j,0)-c*v
     if mod is not None:w%=mod
     if w:r[j]=w
     else:r.pop(j,None)
  return piv
 def rref(rows):
  piv=echelon(rows)
  for p in reversed(sorted(piv)):
   for q in sorted(piv):
    if q>=p:break
    if p in piv[q]:
     c=piv[q][p]
     for j,v in piv[p].items():add(piv[q],j,-c*v)
  return [piv[p] for p in sorted(piv)]
 def span(mats):
  rows=rref([{i*45+j:v for(i,j),v in nz(m).items()} for m in mats]);return [s.MutableSparseMatrix(45,45,{divmod(k,45):s.Rational(v.numerator,v.denominator) for k,v in r.items()}) for r in rows]
 def normvec(v):
  j=next(i for i,x in enumerate(v) if x!=0);return v/v[j]
 print('STAGE '+role+' actual_rational_gauge_frame_H_center_and_M_centralizer',flush=True)
 phys=get('physical');Q=mat(phys['C3_plane_to_parent']);Qi=Q.inv();pbl=get('pbl');PH=mat(pbl['H_projector']);PM=s.eye(45)-PH;pair=list(combinations(range(10),2));ff={}
 if role=='primary':
  planes=[s.MutableSparseMatrix(10,10,{(i,j):1,(j,i):-1}) for i,j in pair]
  for a,b in product(range(45),repeat=2):
   br=planes[a]*planes[b]-planes[b]*planes[a]
   for c,(i,j) in enumerate(pair):
    if br[i,j]:ff[c,a,b]=F(int(br[i,j]))
 else:
  data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10');temp={};oc={a:[(i,v) for(i,aa),v in Q.todok().items() if aa==a] for a in range(45)};ir={a:[(j,v) for(aa,j),v in Qi.todok().items() if aa==a] for a in range(45)}
  for a in range(45):
   for row in data['master_field_maps'][f'C{a}']:
    b,c=[int(t[1:]) for t in row['word']];v=-s.expand(s.sympify(row['coefficient'])).coeff(g,1)*s.sqrt(2)
    for bb,cc,sg in [(b,c,1),(c,b,-1)]:
     for i,x in oc[a]:
      for j,y in ir[bb]:
       for k,z in ir[cc]:temp[i,j,k]=s.expand(temp.get((i,j,k),0)+sg*v*x*y*z)
  ff={k:rat(v) for k,v in temp.items() if v!=0}
 assert len(ff)==720 and set(ff.values())=={F(1),F(-1)} and pbl['adjoint_Casimir']==-8
 assert get('bpc')['adjoint_projection_rank']==45
 adj=[s.MutableSparseMatrix(45,45,{(c,b):int(v) for(c,aa,b),v in ff.items() if aa==a}) for a in range(45)];ad=lambda v:sum((v[i]*adj[i] for i in range(45) if v[i]!=0),s.zeros(45));UH=s.Matrix.hstack(*PH.columnspace());UM=s.Matrix.hstack(*PM.columnspace());assert UH.shape==(45,12) and UM.shape==(45,33)
 AH=[ad(UH[:,i]) for i in range(12)]
 if role=='primary':
  yh=s.Matrix.vstack(*(a*UH for a in AH)).nullspace();zm=s.Matrix.vstack(*(a*UM for a in AH)).nullspace();assert len(yh)==len(zm)==1;Y=normvec(UH*yh[0]);Z=normvec(UM*zm[0])
 else:
  cas=sum((a.T*a for a in AH),s.zeros(45));ker=cas.nullspace();assert len(ker)==2
  yv=[PH*v for v in ker if any(PH*v)];zv=[PM*v for v in ker if any(PM*v)];assert yv and zv;Y=normvec(yv[0]);Z=normvec(zv[0]);assert all(normvec(v)==Y for v in yv) and all(normvec(v)==Z for v in zv)
 AY=ad(Y);AZ=ad(Z);assert not nz(AY*AZ-AZ*AY) and not nz(PM*Y) and not nz(PH*Z)
 print('STAGE '+role+' complete528_variable_skew_module_exact_and_modular_rank',flush=True)
 left=(UM.T*UM).inv()*UM.T;wedges=list(combinations(range(33),2));ix={w:i for i,w in enumerate(wedges)};rows=[]
 for h in AH:
  rr=left*h*UM;assert not nz(h*UM-UM*rr);cols={j:[(i,rat(v)) for(i,k),v in rr.todok().items() if k==j] for j in range(33)};this=[{} for w in wedges]
  for col,(a,b) in enumerate(wedges):
   for i,v in cols[a]:
    if i!=b:add(this[ix[tuple(sorted((i,b)))]],col,v if i<b else -v)
   for j,v in cols[b]:
    if a!=j:add(this[ix[tuple(sorted((a,j)))]],col,v if a<j else -v)
  rows.extend(r for r in this if r)
 prime=1000003;assert s.isprime(prime);modp=echelon(rows,prime);rankmod=len(modp)
 if role=='primary':
  piv=echelon(rows);rank=len(piv);assert rank==rankmod;free=[i for i in range(528) if i not in piv];null=[]
  for j in free:
   v={j:F(1)}
   for p in reversed(sorted(piv)):
    co=-sum(c*v.get(k,0) for k,c in piv[p].items() if k!=p)
    if co:v[p]=co
   L=s.MutableSparseMatrix(33,33,{(a,b):s.Rational(v[k].numerator,v[k].denominator) for k,(a,b) in enumerate(wedges) if k in v});L=L-L.T;null.append(UM*L*UM.T)
  basis=span(null)
 else:
  candidates=[]
  for degree in [1,3,5]:
   for a in range(degree+1):candidates.append(AY**a*AZ**(degree-a))
  basis=span(candidates);rank=528-len(basis);assert rankmod==rank,'EXACT_KERNEL_AND_MODULAR_RANK_BOUNDS_DO_NOT_MEET'
 assert len(basis)+rank==528
 for K in basis:
  assert not nz(K+K.T) and not nz(K*PH) and all(not nz(h*K-K*h) for h in AH)
 gram=s.Matrix(45,45,lambda i,j:s.trace(adj[i].T*adj[j]));assert gram==16*s.eye(45)
 def inner(K):return sum((s.trace(a.T*K)*a/16 for a in adj),s.zeros(45))
 innerbasis=span([AY,AZ]);assert len(innerbasis)==2
 residual=span([K-inner(K) for K in basis]);qdim=len(residual);assert qdim==2,'QUOTIENT_DIMENSION_REQUIRES_NEW_EXACT_PROJECTIVE_SOLVER'
 for K in residual:assert not nz(inner(K)) and not nz(K+K.T) and not nz(K*PH)
 print('STAGE '+role+' complete_CE_source_heads_and_quadratic_Jacobi_tensor',flush=True)
 def ce(K):
  out={};cols={j:[(i,v) for(i,jj),v in nz(K).items() if jj==j] for j in range(45)};rs={i:[(j,v) for(ii,j),v in nz(K).items() if ii==i] for i in range(45)}
  for(a,b,c),v in ff.items():
   # t=-dK=K f-[K.,.]-[.,K.]
   for aa,w in cols[a]:add(out,(aa,b,c),w*v)
   for bb,w in rs[b]:add(out,(a,bb,c),-w*v)
   for cc,w in rs[c]:add(out,(a,b,cc),-w*v)
  return out
 heads=[ce(K) for K in residual];assert all(heads) and not ce(AY) and not ce(AZ)
 for t in heads:
  for(a,b,c),v in t.items():assert t.get((b,c,a),0)==v and t.get((b,a,c),0)==-v
  for a in range(45):
   m=s.MutableSparseMatrix(45,45,{(b,c):s.Rational(v.numerator,v.denominator) for(aa,b,c),v in t.items() if aa==a});assert not nz(PH.T*m)
 def canonical(w):
  if len(set(w))!=len(w):return (),0
  return tuple(sorted(w)),(-1)**sum(w[i]>w[j] for i in range(len(w)) for j in range(i+1,len(w)))
 def jacobi(ts):
  # Map (output,three sorted input colours)->quadratic parameter vector.
  monos=list(combinations_with_replacement(range(len(ts)),2));mi={m:i for i,m in enumerate(monos)};out={}
  if role=='primary':
   qs=[{a:[((b,c),-v) for(aa,b,c),v in t.items() if aa==a and b<c] for a in range(45)} for t in ts]
   for j,k in product(range(len(ts)),repeat=2):
    for a in range(45):
     for(b,c),outer in qs[k][a]:
      for word,v in qs[j][b]:
       ww,sg=canonical(word+(c,))
       if sg:add(out.setdefault((a,ww),{}),mi[tuple(sorted((j,k)))],outer*v*sg/2)
      for word,v in qs[j][c]:
       ww,sg=canonical((b,)+word)
       if sg:add(out.setdefault((a,ww),{}),mi[tuple(sorted((j,k)))],-outer*v*sg/2)
  else:
   inside=[{e:[(b,c,v) for(ee,b,c),v in t.items() if ee==e and b<c] for e in range(45)} for t in ts];outside=[{e:[(a,d,v) for(a,ee,d),v in t.items() if ee==e] for e in range(45)} for t in ts]
   for j,k in product(range(len(ts)),repeat=2):
    for e in range(45):
     for b,c,v in inside[k][e]:
      for a,d,w in outside[j][e]:
       ww,sg=canonical((b,c,d))
       if sg:add(out.setdefault((a,ww),{}),mi[tuple(sorted((j,k)))],sg*v*w/2)
  return {k:v for k,v in out.items() if v},monos
 Jall,monosall=jacobi([ff]+heads);assert all(all(monosall[j][0]>0 and monosall[j][1]>0 for j in r) for r in Jall.values()),'BASE_JACOBI_OR_LINEAR_CE_COMPATIBILITY_FAILED'
 J,monos=jacobi(heads);assert monos==[(0,0),(0,1),(1,1)] and J
 jrows=[{i:v for i,v in row.items()} for k,row in sorted(J.items())];jrref=rref(jrows);alph,beta=s.symbols('alpha beta',real=True);monexpr=[alph**2,alph*beta,beta**2];polys=[sum(s.Rational(v.numerator,v.denominator)*monexpr[i] for i,v in row.items()) for row in jrref];chart=None
 for p in polys:
  q=s.Poly(p.subs(alph,1),beta,domain=s.QQ)
  if not q.is_zero:chart=q if chart is None else s.gcd(chart,q)
 assert chart is not None;chart=chart.monic();roots=[] if chart.degree()==0 else s.polys.polytools.real_roots(chart);axis=all(s.expand(p.subs({alph:0,beta:1}))==0 for p in polys)
 for root in roots:assert all(s.simplify(p.subs({alph:1,beta:root}))==0 for p in polys)
 witnesses=[];piv={}
 for key,row in sorted(J.items()):
  cand=echelon([*piv.values(),row])
  if len(cand)>len(piv):witnesses.append({'output':key[0],'input':list(key[1]),'coefficients':[str(row.get(i,0)) for i in range(3)]});piv=cand
  if len(piv)==len(jrref):break
 # Head-rank certificate against physical unweighted gauge coupling f.
 headrows=[];keys=sorted(set().union(*(set(t) for t in heads),set(ff)))
 for key in keys:headrows.append({j:tt.get(key,F(0)) for j,tt in enumerate(heads+[ff]) if tt.get(key,0)})
 headrank=len(echelon(headrows));assert headrank==qdim+1
 cross=any(row.get(1,0) for row in J.values());Jpacket=[[a,list(w),[str(row.get(i,0)) for i in range(3)]] for(a,w),row in sorted(J.items())]
 # Wrong-skew and wrong-inner-subtraction controls are kept separate from
 # CE:adding an inner map leaves a CE head unchanged and is INSENSITIVE there.
 assert nz(PM+PM.T);mix=adj[0]+residual[0];wrong=mix+inner(mix);assert nz(inner(wrong)) and ce(mix)==ce(residual[0])
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10');assert all(s.expand(s.sympify(row['coefficient'])).subs(g,0)==0 for a in range(45) for row in data['master_field_maps'][f'C{a}'])
 e2=get('e2');assert sum(bool(v['physical_program']) for v in e2['complete_columns'].values())==508;assert len(get('action')['local_terms'])==34
 out={'schema':'BASIC_ROTATION_TORSION_V1','route':role,'native_method':'exact rational common-kernel elimination' if role=='primary' else 'odd-polynomial exact nullvectors and modular rank sandwich','scientific_disposition':'COMPLETE_BASIC_ROTATION_CLASS_AND_NECESSARY_EXTENSION_DIAGNOSTIC_PENDING_INDEPENDENT_VALIDATION','integer_frame_bracket_nonzero':len(ff),'physical_bracket_scale':'1/sqrt(2)','H_center_dimension':1,'M_centralizer_dimension':1,'H_center_vector':packet(Y),'M_centralizer_vector':packet(Z),'M_column_basis':packet(UM),'skew_bivector_variables':528,'nonzero_constraint_rows':len(rows),'constraint_rank':rank,'modular_prime':prime,'modular_rank':rankmod,'full_skew_module_dimension':len(basis),'full_skew_basis':[packet(K) for K in basis],'inner_dimension':2,'quotient_dimension':qdim,'quotient_basis':[packet(K) for K in residual],'CE_heads_integer_frame':[[[a,b,c,str(v)] for(a,b,c),v in sorted(t.items())] for t in heads],'head_plus_physical_coupling_rank':headrank,'all_linear_CE_and_base_Jacobi_coefficients_zero':True,'quadratic_Jacobi_domain':45*14190,'quadratic_Jacobi_nonzero_positions':len(J),'quadratic_Jacobi_sha256':writehash(Jpacket),'Jacobi_constraint_rank':len(jrref),'Jacobi_constraint_rref':[[str(row.get(i,0)) for i in range(3)] for row in jrref],'Jacobi_witness_rows':witnesses,'real_projective_solution_chart_polynomial':str(chart.as_expr()),'real_projective_solution_chart_roots':[str(q) for q in roots],'real_projective_solution_beta_axis_allowed':axis,'only_zero_real_combination_passes_necessary_Jacobi':not roots and not axis,'omitted_cross_terms_control_sensitive':cross,'inner_addition_CE_control_insensitive_orthogonal_projection_detects':True,'full_cocycle_and_free_current_constructed_as_bound_program':True,'full508_physical_Euler_programs_and34_term_action_retained':True,'stationary_head_nonexactness_uses_qualified_full_projection':True,'actual_JC_source_vertex_has_explicit_g':True,'new_pole_measured_or_partial_quantum_functional_changed':False,'finite_quantum_prescription_admissibility_or_anomaly_verdict':False,'authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
