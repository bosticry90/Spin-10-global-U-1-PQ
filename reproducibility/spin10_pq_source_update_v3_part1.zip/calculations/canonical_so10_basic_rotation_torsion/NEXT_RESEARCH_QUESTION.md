# Proposed next bounded test:quantum normalization-degree compatibility

UNTESTED;freeze the actual W1-W7/finite-map inputs and a new acceptance
contract before computation. Reuse the completed BRT1/V2 ranks and scalar
Gram;do not repeat the finite matrix census or activate HB1/C5/C1_GS stages.

Determine whether the explicit affine formal one-loop family
Gamma_a=Gamma_kappa+hbar*sum a_i D_i can extend in the SAME polynomial,
local-counterterm quantum prescription through orderhbar2 at quadratic degree
in a. This targets admissibility,not another local coefficient count.

First derive the loop/normalization-degree filtration from the actual path
integral and source conventions. Every a-dependent tree vertex is orderhbar;
one-loop graphs with one such insertion are hbar2 but only linear in a;
two insertions with a loop start athbar3. Explicit second-order finite
counterterms are local. Check whether reference/measure/source/contact
normalizations or parameter/source maps can add another hbar2 a^2 term,
and whether the family is genuinely affine at its already specified order.
Do not assume this filtration if the declared prescription permits a different
operation. Retain all ordinary/probe currents and canonical source derivatives.

If the filtration holds,extract the hbar2 a^2 Slavnov coefficient. Test whether
a local counterterm can cancel its actual leading scalar source projection.
Use the SAME four-direction positive Gram and the complete local source census;
no independent quantum amplitude is then needed in this sector. Explain why
nonlocal loop terms are absent there instead of applying the stationary local
projection to an unrestricted nonlocal effective action. A failure would
exclude this specified AFFINE quantum normalization extension under its stated
premises,not establish an anomaly of the baseline theory.

If it does not hold,identify the actual missing/candidate terms and their
order. A broader nonaffine source/contact family or an unproved higher-product
construction is not covered by the affine argument. State the exact missing
normalization/analytic premise;do not add one to eliminate an unwanted class.

Secondary:match the explicit JC/Jx g factor with actual g-regular UV versus
finite-map assumptions. Do not exchange the g->0,IR and UV-finite-part limits
without proof or adopt inverse g. The actual measured residue's parameter
span remains qualified,and its source coefficients have not been changed.

This question keeps scientific attention on the validity of the quantum
prescription. No new physical scheme,model,parameter point,publication or
protected authority is authorized by a successful algebraic compatibility test.
