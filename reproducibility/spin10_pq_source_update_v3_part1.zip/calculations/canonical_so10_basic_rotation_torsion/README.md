# BRT1 evidence navigation

Read [RESULT_V2.md](RESULT_V2.md) and the completed validation receipt.
RESULT.md and RESULT_V1_PROSPECTIVE.md preserve the earlier unqualified
interpretation;INTERPRETATION_CORRECTION_V2.md explains its limitation.
V1 correctly classifies the ghost-bracket quotient. V2 retains scalar-source
changes and tests the full four-dimensional rotation family. All original
sources/results are preserved. No quantum functional was modified.
