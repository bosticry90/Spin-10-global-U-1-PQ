# BRT1 proposed derivation and acceptance boundary

## Complete finite rotation space

Use the actual compact gauge algebra g=so10 with orthonormal plane basis,
physical structure constants f=F/sqrt2 and integer F. Let P_H be the bound
rank12 projection and P_M=1-P_H. Define

 V={K real:K^T=-K,K P_H=0,[ad_h,K]=0 for every h in H}.

Choose a rational full-rank45x33 column basis U of P_M. Every such supported
skew K has a unique K=U L U^T with L skew33x33. This is a bijection:the inverse
uses only the constant rational Gram(U)^-1. With ad_h U=U R_h,invariance is
R_h L+L R_h^T=0. This provides a complete528-variable rational linear problem,
not an enumeration of a large counterterm catalog. Scaling ad by sqrt2 removes
the common radical without changing these kernels.

Primary exact rational elimination proves rank/nullspace. Replay constructs
exact candidates from odd monomials of total degree1,3,5 in commuting
A_Y=sqrt2 ad_Y,A_Z=sqrt2 ad_Z. Y is the actual center of H and Z the actual
M centralizer. Their dimensions are measured,not assumed. Every candidate is
skew,H-equivariant and kills H. A modular rank lower bound,with all denominators
invertible,plus independent exact nullvectors is a rigorous rational rank
certificate. If these bounds do not meet,the calculation is incomplete.

Canonical RREF spans in physical45x45 coordinates compare routes independent
of their chosen nullspace bases. The BPC adjoint projection removes inner maps:
pi_ad K=sum_i <A_i,K>A_i/16 for A_i=sqrt2 ad_i. Its complement gives the
finite quotient. The complete inner subspace of V consists of adjoint vectors
centralizing H;zero center proves there are no extra inner maps. No physical
gauge coupling or field is divided in these numerical operations.

## A finite polynomial basic class without a polynomial primitive

For K in V define G_K=-JB*K*B+JC*K*C. Its scalar field flow is zero. Since
K kills H and intertwines H,this primitive is horizontal and invariant under
both classical H operations. The same canonical N/U conjugation transports it.
The source-left commutator with the actual BRST rules gives

 dr_B=-g*dK(B,C), dr_C=+g*dK(C,C)/2, dr_x=+g*rho_(KC)*x.

Thus the full source heads carry g. The ordinary contribution is the complete
-E_Bphys(g).K B,not a source-polynomial-only approximation. Atg0,the physical
B action is free Maxwell with the constant compact colour metric. For real
skew K its density variation is exactly zero. Ordinary first variation gives

 QG_K|g0=div Theta0,
 Theta0^mu=(partial L0/partial(partial_mu B))*K B+JB^mu*K C.

The source term is essential;it comes from ordinary IBP of divJB times KC.
Every remaining coefficient of QG_K-divTheta0 has positive g power. Define
D_K by exact positive-g coefficient shift of that numerator. This is a finite
polynomial FUNCTIONAL and current program,not a Laurent primitive G_K/g.
Its ordinary part retains every coefficient of E_Bphys-E0 and the same action;
source parts are the displayed heads with g removed. Canonical charts transport
the entire density/current,including reference widths and scalar/source maps.

Q D_K=0 as a functional:apply Q and use the coefficientwise ordinary-current
identity. Basicness follows similarly or from its explicit heads and Cartan.
Cancellation of g here takes place in coefficient equations/modulo ordinary
derivatives,which act coefficientwise on the ring. It does NOT imply that g
is injective on BRST cohomology. In fact g[D_K]=0 because gD_K=QG_K modcurrent.

The leading ghost head is t_K=-d_f K. If K has a nonzero component orthogonal
to the inner adjoint maps,its CE differential is nonzero by the qualified
adjoint Casimir homotopy. The old stationary projection atg0 kills Q of EVERY
polynomial primitive and every ordinary current,while retaining JC and
undifferentiated C. It sees the nonzero t_K head of D_K. Hence such a class
is nonexact in this polynomial complex. The same invertible polynomial charts
preserve this conclusion;no equation of motion or ghostzero quotient is used.

The scalar potentials/kinetic and background normalizations contribute no
stationary JC head. A physical unweighted coupling tangent contributes f,
whose mixed H bracket is nonzero. The new heads have zero H contractions.
A rank certificate comparing all t_K directions and f tests independence from
this stated physical/normalization span. It does not refute the previously
qualified physical span of the ACTUAL measured bosonic UV residue.

## Complete quadratic extension test,not an anomaly verdict

Let t(alpha)=sum_j alpha_j t_j,with alpha real bookkeeping coefficients of
these candidate normalization directions,not adopted physical couplings.
The leading ghost rule is q_delta C=-t(alpha)(C,C)/2. Its exact square gives
all JC*C*C*C source coefficients of the orderepsilon2,g0 master condition.
The independent route evaluates t(t(a,b),c)+cyclic directly. Sparse algorithms
retain the full45*choose(45,3) domain and every parameter cross term.

A polynomial classical master-normalization family S+epsilon D+epsilon2 D2
would require QD2+(D,D)/2=0 modcurrent. The stationary projection kills Q0D2
but retains this Jacobi coefficient. A nonzero result therefore excludes that
combination from THAT polynomial classical extension. It does not alone
establish a quantum anomaly:general renormalized connected insertions and
prescription changes have additional applicability requirements.

For the measured quotient dimension,the homogeneous quadratic equations are
classified exactly. In two parameters,use a!=0 chart a=1 and univariate gcd/
real-root isolation,plus the a=0 axis. Do not infer a real solution set from a
coefficient count or numerical roots. If the quotient dimension is different,
retain complete evidence and classify as incomplete until an adequate exact
solver/contract is established rather than silently testing only two directions.

## Quantum applicability and remaining assumptions

The actual source action has an explicit g multiplying every JC vertex. A
source-independent reference regulator and a coupling-linear local UV extraction
with no inverse-g symbol coefficients preserve that factor on graph-generated
UV contributions. Verify the actual source rows and existing reference/high-
momentum premises before using this limited argument. This is not automatically
a restriction on EVERY allowable finite renormalized source-normalization map.
W6 includes compatible finite insertion/mixing freedom;an extra module-linearity
or free-limit condition cannot be adopted merely to remove a formal class.

Keep distinct:nonexact algebraic classes,nonlinear classical extension,
actual measured UV poles,and differences between fully specified quantum
prescriptions. Reconcile the result with the actual contracts. No new physical
parameter,scheme or authority is adopted. Quantum-control/matching,full QAP/
A5/E5,arbitrary products and physical/global limits remain separate obligations.
