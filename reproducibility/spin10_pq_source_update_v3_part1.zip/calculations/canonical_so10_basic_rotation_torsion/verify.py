"""Independent physical-commutator module rank,current and full Jacobi check."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement,product
import json,gzip,sys,os,time,threading
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_basic_rotation_torsion'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BRT_VERIFY_WRITE')
sys.addaudithook(readonly);prep=read(O/'preparation_v2.json');a=read(O/'primary_result.json');b=read(O/'replay_result.json');exclude=['route','native_method','elapsed_after_imports']
assert {k:v for k,v in a.items() if k not in exclude}=={k:v for k,v in b.items() if k not in exclude}
for role in ['primary','replay']:
 cap=read(O/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 for v in prep['artifacts'][role].values():
  assert digest(Path(v['path']))==v['sha256']
  if 'receipt' in v:assert digest(Path(v['receipt']))==v['receipt_sha256']
get=lambda label:read(Path(prep['artifacts']['replay'][label]['path']))
def rat(x):
 x=s.cancel(x);assert x.is_Rational;return F(int(x.p),int(x.q))
def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):s.Rational(z) for i,j,z in p['entries']})
def nz(m):return {ij:rat(v) for ij,v in m.todok().items() if v!=0}
def add(d,k,v):
 q=d.get(k,F(0))+v
 if q:d[k]=q
 else:d.pop(k,None)
def rank_mod(rows,prime):
 piv={}
 for row in rows:
  r={j:(v.numerator*pow(v.denominator,-1,prime))%prime for j,v in row.items()};r={j:v for j,v in r.items() if v}
  while r:
   p=max(r);c=r[p]
   if p not in piv:
    inv=pow(c,-1,prime);piv[p]={j:v*inv%prime for j,v in r.items()};break
   for j,v in piv[p].items():
    q=(r.get(j,0)-c*v)%prime
    if q:r[j]=q
    else:r.pop(j,None)
 return len(piv)
print('STAGE verifier actual_scalar_bracket_and_direct_physical_skew_constraints',flush=True)
phys=get('physical')
rho=[]
for p in phys['representation_matrices']['phi']:
 m=s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(z) for i,j,z in p['entries']});rho.append(m.extract(range(0,20,2),range(0,20,2))*s.sqrt(2))
plane=list(combinations(range(10),2));ff={}
for i,j in product(range(45),repeat=2):
 c=rho[i]*rho[j]-rho[j]*rho[i]
 for k,(r,c0) in enumerate(plane):
  if c[r,c0]!=0:ff[k,i,j]=rat(c[r,c0])
assert len(ff)==720 and set(ff.values())=={F(1),F(-1)}
adj=[s.MutableSparseMatrix(45,45,{(c,j):int(v) for(c,ii,j),v in ff.items() if ii==i}) for i in range(45)];ad=lambda v:sum((v[i]*adj[i] for i in range(45) if v[i]!=0),s.zeros(45))
PH=mat(get('pbl')['H_projector']);PM=s.eye(45)-PH;U=mat(a['M_column_basis']);assert U.shape==(45,33) and U.rank()==33 and not nz(PH*U);UH=s.Matrix.hstack(*PH.columnspace());Hs=[ad(UH[:,i]) for i in range(12)];wedges=list(combinations(range(33),2));physwedges=list(combinations(range(45),2));pi={p:i for i,p in enumerate(physwedges)}
uc=[{i:v for(i,jj),v in nz(U).items() if jj==j} for j in range(33)];rows=[]
def wedge_add(target,u,v,col):
 for i,x in u.items():
  for j,y in v.items():
   if i!=j:add(target[pi[tuple(sorted((i,j)))]],col,x*y*(1 if i<j else -1))
for H in Hs:
 HU=H*U;hc=[{i:v for(i,jj),v in nz(HU).items() if jj==j} for j in range(33)];block=[{} for p in physwedges]
 for col,(u,v) in enumerate(wedges):wedge_add(block,hc[u],uc[v],col);wedge_add(block,uc[u],hc[v],col)
 rows.extend(r for r in block if r)
prime=int(s.nextprime(1000033));assert s.isprime(prime) and prime!=a['modular_prime'];rank=rank_mod(rows,prime);assert rank==524==a['constraint_rank']
basis=[mat(p) for p in a['full_skew_basis']];quot=[mat(p) for p in a['quotient_basis']];assert len(basis)==4 and len(quot)==2
for K in basis+quot:assert not nz(K+K.T) and not nz(K*PH) and all(not nz(H*K-K*H) for H in Hs)
def flatrows(ms):return [{i*45+j:v for(i,j),v in nz(m).items()} for m in ms]
assert rank_mod(flatrows(basis),prime)==4 and rank_mod(flatrows(quot),prime)==2
# A rank>=524 and four independent exact nullvectors gives exact rank524.
Y=mat(a['H_center_vector']);Z=mat(a['M_centralizer_vector']);assert not nz(PM*Y) and not nz(PH*Z)
centrows=[]
for H in Hs:
 for i in range(45):centrows.append({j:v for(ii,j),v in nz(H).items() if ii==i})
assert rank_mod(centrows,prime)==43 and all(not nz(H*Y) and not nz(H*Z) for H in Hs)
AY,AZ=ad(Y),ad(Z);assert rank_mod(flatrows([AY,AZ]),prime)==2 and rank_mod(flatrows([AY,AZ]+quot),prime)==4
gram=s.Matrix(45,45,lambda i,j:s.trace(adj[i].T*adj[j]));assert gram==16*s.eye(45)
for K in quot:assert all(s.trace(A.T*K)==0 for A in adj)
print('STAGE verifier full_source_heads_and_adjoint_commutator_Jacobi_tensor',flush=True)
heads=[]
for K,pk in zip(quot,a['CE_heads_integer_frame']):
 T={};ak=[ad(K[:,i]) for i in range(45)]
 for i,j in product(range(45),repeat=2):
  v=K*adj[i][:,j]-ak[i][:,j]-adj[i]*K[:,j]
  for(k,col),co in nz(v).items():T[k,i,j]=co
 assert [[*key,str(v)] for key,v in sorted(T.items())]==pk;heads.append(T)
 for out in range(45):
  m=s.MutableSparseMatrix(45,45,{(b,c):s.Rational(v.numerator,v.denominator) for(a0,b,c),v in T.items() if a0==out});assert not nz(PH.T*m)
for T in heads:
 for(a0,b,c),v in T.items():assert T.get((b,c,a0),0)==v and T.get((b,a0,c),0)==-v
Ts=[[s.MutableSparseMatrix(45,45,{(a0,b):s.Rational(v.numerator,v.denominator) for(a0,ii,b),v in T.items() if ii==i}) for i in range(45)] for T in heads];J={}
for i,j in combinations(range(45),2):
 for m,(aa,bb) in enumerate([(0,0),(0,1),(1,1)]):
  if aa==bb:
   M=-Ts[aa][i]*Ts[aa][j]+Ts[aa][j]*Ts[aa][i]
   for c in range(45):
    if(c,i,j) in heads[aa]:M+=s.Rational(heads[aa][c,i,j].numerator,heads[aa][c,i,j].denominator)*Ts[aa][c]
  else:
   M=-Ts[0][i]*Ts[1][j]+Ts[1][j]*Ts[0][i]-Ts[1][i]*Ts[0][j]+Ts[0][j]*Ts[1][i]
   for c in range(45):
    for x,y in [(0,1),(1,0)]:
     if(c,i,j) in heads[x]:M+=s.Rational(heads[x][c,i,j].numerator,heads[x][c,i,j].denominator)*Ts[y][c]
  for(out,c),v in nz(M).items():
   if c>j:add(J.setdefault((out,(i,j,c)),{}),m,v/2)
J={k:v for k,v in J.items() if v};packet=[[out,list(w),[str(row.get(i,0)) for i in range(3)]] for(out,w),row in sorted(J.items())];jh=sha256(json.dumps(packet,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert jh==a['quadratic_Jacobi_sha256'] and len(J)==3048
assert not any(row.get(1,0) for row in J.values()) and not a['omitted_cross_terms_control_sensitive']
assert J[1,(2,5,13)]=={0:F(4)} and J[5,(6,7,8)]=={2:F(-32)}
# Two independently computed coefficients force alphaÃ‚Â²=betaÃ‚Â²=0. This
# proves the real solution set directly,independently of native gcd/root code.
assert a['Jacobi_constraint_rref']==[['1','0','0'],['0','0','1']] and a['only_zero_real_combination_passes_necessary_Jacobi']
headrows=[]
for key in sorted(set(ff).union(*(set(T) for T in heads))):headrows.append({j:T.get(key,F(0)) for j,T in enumerate(heads+[ff]) if T.get(key,0)})
assert rank_mod(headrows,prime)==3
print('STAGE verifier complete_free_current_and_stationary_class_applicability',flush=True)
action=get('action');assert len(action['local_terms'])==34;aliases=['Phi','Sigma','SigmaBar','phi','phiBar','S','SBar','x_Phi','x_Sigma','x_phi','x_S']
def degree(n):
 k=n['node']
 if k=='ExactScalar':return {(0,0)} if s.sympify(n['value'])!=0 else set()
 if k=='Parameter':return set() if n['name']=='g10' else {(0,0)}
 if k=='Field':
  assert n['name']=='B' or n['name'] in aliases;return {(0,1)} if n['name']=='B' else {(1,0)}
 if k in ['StructureConstant','RepresentationGenerator','InvariantTensor']:return {(0,0)}
 if k=='PartialDerivative':return degree(n['argument'])
 if k in ['GroupContraction','LorentzContraction']:return degree(n['expression'] if 'expression' in n else n['argument'])
 if k=='OrderedProduct':
  out={(0,0)}
  for p in n['factors']:out={(a+c,b+d) for a,b in out for c,d in degree(p)}
  return out
 if k=='Add':return set().union(*(degree(p) for p in n['terms']))
 raise AssertionError(k)
degs=[degree(t['density']) for t in action['local_terms']];assert degs[0]=={(0,2)} and all(ds and all(sc>=2 and bc==0 for sc,bc in ds) for ds in degs[1:])
x=s.symbols('X0:4');B=[[s.Function(f'b{a0}_{mu}')(*x) for mu in range(4)] for a0 in range(2)];eta=[1,-1,-1,-1];Fmn=lambda a0,mu,nu:s.diff(B[a0][nu],x[mu])-s.diff(B[a0][mu],x[nu]);L=-sum(eta[mu]*eta[nu]*Fmn(a0,mu,nu)**2 for a0,mu,nu in product(range(2),range(4),range(4)))/4;k=s.symbols('k');K=s.Matrix([[0,k],[-k,0]]);V=[[sum(K[a0,b0]*B[b0][mu] for b0 in range(2)) for mu in range(4)] for a0 in range(2)]
E=[[s.diff(L,B[a0][mu])-sum(s.diff(s.diff(L,s.diff(B[a0][mu],xx)),xx) for xx in x) for mu in range(4)] for a0 in range(2)];Theta=[sum(s.diff(L,s.diff(B[a0][mu],x[nu]))*V[a0][mu] for a0,mu in product(range(2),range(4))) for nu in range(4)]
delta=sum(s.diff(L,s.diff(B[a0][mu],x[nu]))*s.diff(V[a0][mu],x[nu]) for a0,mu,nu in product(range(2),range(4),range(4)));assert s.expand(delta)==0
assert s.expand(-sum(E[a0][mu]*V[a0][mu] for a0,mu in product(range(2),range(4)))-sum(s.diff(Theta[nu],x[nu]) for nu in range(4)))==0
# Ordinary differentiation of JB K C supplies BOTH source terms. Its even
# Leibniz sign does not acquire an extra Grassmann interchange.
j0,j1,c0,c1,dj0,dj1,dc0,dc1=s.symbols('j0 j1 c0 c1 dj0 dj1 dc0 dc1');source=s.Matrix([j0,j1]).T*K*s.Matrix([c0,c1]);dsource=sum(s.diff(source[0],q)*dq for q,dq in [(j0,dj0),(j1,dj1),(c0,dc0),(c1,dc1)])
assert s.expand(dsource-(s.Matrix([dj0,dj1]).T*K*s.Matrix([c0,c1]))[0]-(s.Matrix([j0,j1]).T*K*s.Matrix([dc0,dc1]))[0])==0
e2=get('e2');assert sum(bool(v['physical_program']) for v in e2['complete_columns'].values())==508
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10');source_rows=sum(len(data['master_field_maps'][f'C{i}']) for i in range(45));assert source_rows>0
for i in range(45):
 for row in data['master_field_maps'][f'C{i}']:
  co=s.Poly(s.sympify(row['coefficient']),g);assert co.degree()==1 and co.eval(0)==0
# Stationary quotient:Q0B=dC,Q0C=Q0x=0,Q0JC=divJB,and physical Eulers
# vanish at all physical fields/jets zero (g0 AST has no linear scalar term).
# Nonminimal doublet images vanish too. All ordinary derivatives vanish
# without explicit coordinates. Therefore these nonzero JC heads survive
# every polynomial exact/current correction. This is not cancellation of g
# on BRST cohomology;gD=QG is instead precisely its torsion relation.
print('STAGE verifier all_four_scalar_sources_by_direct_graded_polynomial_composition',flush=True)
a2=read(O/'primary_scalar_v2_result.json');b2=read(O/'replay_scalar_v2_result.json');assert {k:v for k,v in a2.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b2.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_scalar_v2_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
Ks=[mat(p) for p in a['full_skew_basis']];monos=list(combinations_with_replacement(range(4),2));mi={p:i for i,p in enumerate(monos)};planes=rho;T4=[];R4=[]
for K in Ks:
 ak=[ad(K[:,i]) for i in range(45)];t={}
 for c,d in combinations(range(45),2):
  nv=K*adj[c][:,d]-ak[c][:,d]-adj[c]*K[:,d]
  for(out,col),v in nz(nv).items():t[out,c,d]=v
 T4.append(t);R4.append([sum((K[i,c]*planes[i] for i in range(45) if K[i,c]!=0),s.zeros(10)) for c in range(45)])
# Direct graded Leibniz on r_j(C)x includes q_i C and the minus from C.
# Both physical representation/bracket normalizations supply1/sqrt2.
scalar_poly={};Rentries=[[(c,p,q,v) for c in range(45) for(p,q),v in nz(rs[c]).items()] for rs in R4];byrow=[{q:[(d,r,v) for d,qq,r,v in rr if qq==q] for q in range(10)} for rr in Rentries];tg=[{c:[(aa,bb,v) for(cc,aa,bb),v in t.items() if cc==c] for c in range(45)} for t in T4]
for i,j in product(range(4),repeat=2):
 m=mi[tuple(sorted((i,j)))]
 for c,p,q,v in Rentries[j]:
  for aa,bb,w in tg[i][c]:add(scalar_poly.setdefault((p,q,aa,bb),{}),m,-v*w/2)
  for d,r,w in byrow[i][q]:
   if c!=d:add(scalar_poly.setdefault((p,r,min(c,d),max(c,d)),{}),m,-v*w*(1 if c<d else -1)/2)
scalar_poly={k:v for k,v in scalar_poly.items() if v}
for(p,q,c,d),row in scalar_poly.items():assert p!=q and scalar_poly.get((q,p,c,d),{})=={m:-v for m,v in row.items()}
N={};Nproj={};planeidx={ij:c for c,ij in enumerate(plane)}
for(p,q,c,d),row in scalar_poly.items():
 if p<q:N[planeidx[p,q],c,d]={m:-2*v for m,v in row.items()}
phcols={c:[(r,v) for(r,cc),v in nz(PH).items() if cc==c] for c in range(45)}
for(c,u,v),row in N.items():
 for out,k in phcols[c]:
  for m,co in row.items():add(Nproj.setdefault((out,u,v),{}),m,k*co)
Nproj={k:v for k,v in Nproj.items() if v}
def nhash(d):return sha256(json.dumps([[*k,[str(row.get(i,0)) for i in range(10)]] for k,row in sorted(d.items()) if row],separators=(',',':')).encode()).hexdigest()
assert nhash(N)==a2['full_scalar_colour_tensor_sha256'] and nhash(Nproj)==a2['H_projected_scalar_tensor_sha256']
assert len(N)==a2['full_scalar_colour_tensor_nonzero_positions'] and len(Nproj)==a2['H_projected_scalar_tensor_nonzero_positions']
print('STAGE verifier exact_positive_source_equation_certificate_and_leading_class_rank',flush=True)
G=s.Matrix(4,4,lambda i,j:sum(s.trace((Ks[i]*H).T*(Ks[j]*H)) for H in Hs));assert nz(G)==nz(mat(a2['scalar_positive_Gram']))
L=mat(a2['positive_Gram_L']);Dg=mat(a2['positive_Gram_D']);assert L*Dg*L.T==G and all(Dg[i,i]>0 for i in range(4))
minors=[s.factor(G[:k,:k].det()) for k in range(1,5)];assert [str(v) for v in minors]==a2['positive_Gram_principal_minors'] and all(v>0 for v in minors)
blocks={(h,m):{} for h in range(12) for m in range(10)};hcols={c:[(h,rat(UH[c,h])) for h in range(12) if UH[c,h]!=0] for c in range(45)}
for(c,u,v),row in N.items():
 for h,k in hcols[c]:
  for m,co in row.items():add(blocks[h,m],(u,v),k*co)
for m,(i,j) in enumerate(monos):
 trace_co=0
 for h,H in enumerate(Hs):
  B=s.MutableSparseMatrix(45,45,{ij:s.Rational(v.numerator,v.denominator) for ij,v in blocks[h,m].items()});B=B-B.T;expected=Ks[i]*Ks[j]*H
  if i!=j:expected+=Ks[j]*Ks[i]*H
  assert not nz(B-expected);trace_co-=s.trace(B.T*H)
 assert trace_co==(G[i,j] if i==j else 2*G[i,j])
# Positivity covers every real combination in the complete four-dimensional
# kernel. It is an explicit combination of ACTUAL necessary scalar equations.
leadrows=[]
for key in sorted(set(ff).union(*(set(t) for t in T4))):
 if key[1]>=key[2]:continue
 leadrows.append({j:t.get(key,F(0)) for j,t in enumerate(T4+[ff]) if t.get(key,0)})
for c in range(45):
 for p,q in product(range(10),repeat=2):
  vals=[rat(R4[i][c][p,q]) for i in range(4)]+[-rat(planes[c][p,q])]
  if any(vals):leadrows.append({i:v for i,v in enumerate(vals) if v})
assert rank_mod(leadrows,prime)==5==a2['full_leading_source_plus_coupling_rank']
# Atg0 none of the complete minimal grade3 primitive carriers produces
# Jx*x*C. Source Euler extraction precedes projection;source-free physical
# Eulers remain and cannot supply that independent source coefficient.
src={'JB':(2,-1,1,1),'Jx':(2,-1,1,0),'JC':(2,-2,0,0)};fld={'A':(1,0,0,1),'B':(1,0,0,1),'x':(1,0,0,0),'C':(1,1,1,0)};patterns=[]
for ns in [1,2]:
 for ss in combinations_with_replacement(sorted(src),ns):
  for nf in range(3):
   for fs in combinations_with_replacement(sorted(fld),nf):
    ww=sorted(ss+fs);dd,gh,pa,lo=[sum(src[n][i] for n in ss)+sum(fld[n][i] for n in fs) for i in range(4)]
    if dd>3 or gh!=-1 or pa%2!=1:continue
    for nd in range(4-dd):
     if (nd+lo)%2:continue
     for js in product(range(nd+1),repeat=len(ww)):
      if sum(js)==nd:patterns.append([ww,list(js),3-dd-nd])
assert sorted(patterns)==[[['A','JB'],[0,0],0],[['B','JB'],[0,0],0],[['C','JC'],[0,0],0],[['JB'],[1],0],[['Jx'],[0],1],[['Jx','x'],[0,0],0]]
counts={'JC':0,'Jx':0}
for n,rr in data['master_field_maps'].items():
 if n.startswith('x_') or (n.startswith('C') and n[1:].isdigit()):
  lab='Jx' if n.startswith('x_') else 'JC'
  for row in rr:
   pp=s.Poly(s.sympify(row['coefficient']),g);assert pp.degree()==1 and pp.eval(0)==0;counts[lab]+=1
assert counts==a2['actual_source_rows_with_explicit_g']
out={'schema':'BASIC_ROTATION_TORSION_AND_FULL_SCALAR_INDEPENDENT_V2','execution_state':'COMPLETED','scientific_disposition':'QUALIFIED_FOUR_BASIC_ROTATION_COCYCLE_DIRECTIONS_WITH_COMPLETE_NECESSARY_SCALAR_EXTENSION_OBSTRUCTION_AND_EXPLICIT_QUANTUM_SCOPE_LIMITS','input_sha256':vp['input_sha256'],'independent_physical_constraint_rank':rank,'independent_modular_prime':prime,'complete_rotation_module_dimension':4,'ghost_CE_kernel_inner_dimension':2,'ghost_head_quotient_dimension_only':2,'full_rotation_cocycle_leading_source_and_coupling_rank':5,'ghost_Jacobi_domain_positions':638550,'ghost_Jacobi_nonzero_positions':3048,'full_ghost_Jacobi_hash_checked':jh,'full_scalar_colour_tensor_hash_checked':nhash(N),'scalar_H_projection_hash_checked':nhash(Nproj),'all120_actual_scalar_H_matrix_identities_and_positive_trace_certificate_checked':True,'positive_definite_four_parameter_Gram_checked':True,'only_zero_full_rotation_combination_passes_this_necessary_classical_extension_test':True,'full_scalar_family_class_dimension_not_replaced_by_two_ghost_classes':True,'six_minimal_primitive_patterns_checked':sorted(patterns),'whole34_term_action_and_complete_free_physical_source_current_checked':True,'all508_physical_Euler_programs_bound_not_freshly_expanded':True,'actual_source_rows_with_explicit_g':counts,'omitted_ghost_term_in_H_projection_insensitive_disclosed':True,'omitted_cross_ghost_Jacobi_control_insensitive_disclosed':True,'finite_quantum_admissibility_and_anomaly_verdict_not_established':True,'no_inverse_g_or_BRST_cohomology_cancellation':True,'authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,'failed_native_workers':0,'failed_verifier_workers':0,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
