# BRT1:basic orthogonal gauge-basis directions and polynomial admissibility

Base513c3da7/main. Previousgoalturn PROGRESS. Test the COMPLETE finite space of
real skew endomorphisms K of the actual45-dimensional gauge algebra satisfying
K P_H=0 and [ad_h,K]=0. Quotient its closed inner-adjoint directions,construct
any nonzero leading basic source classes,and test their necessary Jacobi
extension conditions collectively. Do not assume dimensions or a preferred
outcome. This is a stability/admissibility diagnostic,not HB1/C5/catalog
activation,anomaly classification or adoption of new physical parameters.

Freeze source,derivation,controller and immutable own-route inputs before
computation. Two sequential120second-after-import routes;separate180second
verifier.8GiB sampledprivate,350MiB available-commit floor,8MiB package.
Preserve every failure/incomplete run,raise at resource exhaustion,never
truncate a coefficient domain. No old expensive loops/audits/295-vector
coefficients or full physical Euler expansion.

Use the actual compact real gauge frame,H projection and full so10 bracket,
positive polynomial parameter/source grades,all328 physical scalars and the
same N/U maps. GlobalPQ is not a gauge generator. No inverse g/mass/width.
Derive H center and M centralizer from the actual12 H matrices. Describe the
skew module with33-dimensional M coordinates and528 possible bivectors.
Primary exact-rational elimination and replay modular rank plus independent
exact kernel construction must certify the SAME complete nullspace. Native
replay may use fixed odd polynomials through degree5 in commuting adjoint
Y/Z;failure to span the kernel is incomplete,not permission to truncate it.

Use the actual numerical adjoint projection to remove all inner directions.
Build complete linear CE source heads for every remaining direction. Establish
the full finite polynomial cocycle/current program from the unchanged action,
including all physical Euler programs,ghost/gauge/scalar source companions,
field/source duals and N/U transport. No measured pole is created or integrated.
Use the old stationary ghost-source quotient to test nonexactness and compare
the admitted physical parameter/normalization span,without dividing BRST
cohomology by g.

Compute the COMPLETE quadratic ghost-Jacobi tensor for all parameter
combinations in this finite quotient. Distinct graded-exterior and Lie-Jacobi
routes must agree,including implicit zeros. Certify real projective solutions
of its homogeneous quadratic equations exactly. Nonzero coefficients are
normalization algebra,not measured amplitudes. A failed Jacobi condition is
an obstruction to the specified polynomial CLASSICAL master-family extension,
not automatically a quantum anomaly or a failure of the regulated theory.

Inspect actual W6/coupling/free-limit and parameter-linearity assumptions.
Distinguish this algebraic class space from graph-generated local UV poles
and from permitted finite prescription changes. Do not silently add a new
normalization axiom or choose a subtraction to exclude an unwanted class.
If quantum admissibility is underdefined,identify that exact premise.

Controls:inner rotations give zero CE head;wrong skewness/Hequivariance/H
support are detected;stationary head cannot be erased by polynomial exact
terms;f coupling tangent differs from H-horizontal heads;omitting cross
Jacobi terms must be assessed sensitively;zero combination passes;no constant
omega or sourcezero shortcut. Keep insensitive controls explicit.

Success is a completed finite-space diagnostic with actual coefficients,
rank/zero complements,current proof,extension conditions and applicability
classification. It is not universal physical stability or E5/A5. Authority
34/39,state113,custodyexit2/seven,blocked/paused stages/physical warnings
unchanged. No old evidence,action,scheme,policy,state,benchmark,branch/worktree,
remote push,publication or outreach change. Preserve main and local-only commit.
