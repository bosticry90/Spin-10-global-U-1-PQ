# Loop-leg identity and the complete flat g2 coefficient

Let Danti shift the33 broken antighosts by independent odd test functions eps.
Together with the compensating external-source variation -V^J partial_J it
is an EVEN derivation D. Sources are external coordinates, not integrated.
The actual kernels V have onlyg0/g1 components and are affine in quantum
fields; they remain field-dependent. In particular, V0 is not presumed constant.

The unchanged action satisfies Danti S_GF=V^J R_J+B0, with master source action
sumJ R_J. AtJ=0, the source-linear Bsource vanishes under fixed-source even
field polarizations. Applying two arbitrary EVEN quantum polarizations h,k
and using V''=0 gives
 DH = Danti H_GF - V R''
    = B0''+V'_hR'_k+V'_kR'_h.
The derivative weights/parities reside in the actual polynomial maps. This
is a universal even Leibniz identity conditional on qualified actual chain
rule/maps, not a new numerical claim from one convenient field pair. Its g2
pre-Hessian density is checked from actual GF2,V0R2,V1R1 and B02. The inherited
V244 mixed tensor remains bound; no fresh dense-Hessian qualification is claimed.

At fixed reference and heat factors, each finite ordered Born product obeys
its ordinary product rule. Retain all n possible H derivative positions with
coefficient(-1)^(n+1)/n; no cyclic merging of an infinite trace is needed.
The local dimension budget bounds contributing factors at each prescribed
coefficient, and V255's explicit-family finite-jet estimates justify extraction
of its local logarithm after this derivative. The reference/background
functional Gamma_ref[A] has derivative0 because A is fixed and its operator
has no anti or source dependence. The older nonlinear primitive's nonzero
Jacobian and products are distinct and untouched.

Consequently, once actual ordinary/source POLE INPUTS are complete, the
selected insertion pole is obtained by loop-leg differentiation:
 I2 = Danti Gamma_sf2 - V0^J Euler_left_J Gamma_src2
                          - V1^J Euler_left_J Gamma_src1,
modulo the explicitly retained boundary currents. Gamma_src0=0 is separately
proved, and V2=0 is checked in the actual maps. The source image used here was
calculated from the action and assembled before this target; no coefficient
is inferred from the value required for a zero result.

Equivalent representatives use direct source-slot variation instead of its
Euler form. Their odd-epsilon Euler anchors must agree; their raw densities
may differ by explicit currents. Likewise the ordinary slot derivative and
sum eps Euler_left_anti Gamma_sf2 agree only as integrated representatives.
All four currents and predecessor pieces are retained. No test function is
assumed constant and no source is substituted for a ghost.

Only A and all A-jets are set to0 for this statement. Danti and source Euler
maps do not vary A; this projection commutes with the derivative operations.
Actual background-reference/heat responses are separate, so complete87 bareg2
coverage alone is not off-flat completeness. A nonzero I2 is an actual broken-
antighost insertion coefficient in the tested local prescription, not an
anomaly or a full Slavnov remainder. A zero I2 would likewise not establish
full restoration. E5/A5 and the global QAP/measure/IR/contact/equivalence
conditions remain unqualified in either case.
