# Custody continuation V5: restore the first frozen controller mirror

The pre-commit audit found a real protocol violation: prepare_v3 and prepare_v4
rewrote controller_source.txt after it was frozen. The actual run_v2/v3/v4
controllers, source copies, workers and physics inputs remained unchanged,
but the shared display-copy path could not satisfy earlier manifests.
The previous independent validator checked only its current input set and
missed this earlier-version drift. Its completed receipt remains intact;
it is insufficient for final checkpoint qualification.

Every expected mirror version is now preserved with its exact recorded digest
in controller_v2/v3/v4_mirror_recovered.source.txt. The original unversioned
path is restored to its FIRST frozen V2 bytes. controller_mirror_custody_recovery.json
records the unchanged original manifests and the exact archived bytes for
later historical snapshots. Older V3/V4 snapshot manifests still do not hash
the restored path in the live checkout; this is explicitly a recovered custody
failure, not a new PASS or a silent rebind. They can authenticate their exact
archived historical bytes. No old manifest, receipt, worker or actual controller
has been edited, and no physics input changed.

V5 creates only uniquely named controller_v5_source.txt and never overwrites
an existing source copy. Its strict new manifest binds the restored original
mirror and every recovery archive. New primary/replay and an independent
verifier must all complete under the SAME120sec/8GiB/min350MiB limits. V4's
mathematically completed runs are not used as the final qualified runs. The
new verifier audits every historical manifest and the explicit mirror-only
failure/resolution, in addition to all original scientific checks.

Counts so far: one prelaunch event, two failed native workers, two completed
V4 native runs unqualified for checkpoint custody, one completed independent
validation insufficient for historical-copy custody. No resource extension,
scientific acceptance reduction, functional/source/input/authority change or
protected historical custody promotion is made. The global exit2/seven
unresolved references remain a separate unchanged obligation.
