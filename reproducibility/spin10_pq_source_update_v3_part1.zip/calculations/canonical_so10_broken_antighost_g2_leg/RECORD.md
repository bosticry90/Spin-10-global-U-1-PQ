# Complete flat g10^2 broken-antighost loop-leg assessment V1

Previous goal turn PROGRESS: V261/V262 qualify scalar/background zeros and
all87 bareg2 antighost profile scopes. Recovered6325064f17e54299e3ea5de06314781f958ddacb,
clean main/no live matching processes. Goal remains full Spin(10)xPQ completion.

AG2L: determine the complete FLAT g2 broken-antighost insertion coefficient
for all33 directions by justified differentiation of already measured one-loop
ordinary/source poles. This closes an entire coupling-order dependency, not
another chosen zero. Both zero and nonzero coefficients are legitimate; do
not adjust a source term to make a consistency identity cancel.

Freeze V244 actualB0/Bsource/C and all479 V maps, actual E2/master actions,
V256 affine-kernel/module facts, V257 g0 zeros, V258 g1 leg theorem, V259 finite
g<=4 bound, V260-V262 complete bareg2 scopes, source catalogue177 and five
positive-dimensional coverage targets, current146663 sourceimage, exact
ordinary measured g2 quartet/auxiliary/derivative-gauge and ghost kinetic
poles/current lossless recipe. Preserve both widths,masses/VEVs,alljets and
original normalization failures. Allcurrent coefficients/inputs remain fixed.

Ordinary g2 antighost input must equal the actual three legacy sectors plus
the independently measured ordinary ghost kinetic addition, including zeros
from complete87 scope. Prove no later recipe addition supplies anotherg2
antighost term. Select source orders1 and2 from COMPLETE measured sourceimage.
Retain EVERY V0*source2 and V1*source1 predecessor; prove absence of source0
by V257 and absence of V2 by actual maps, not polynomial omission. Include
positive-dimensional source coverage even when its contraction proves zero.

Least expensive competent test: compute Danti Gamma_sf2 minus the two source
left-Euler contractions, anchor odd epsilon and preserve all four boundary
currents. A distinct even source/field slot variation supplies an integrated
comparison; never assume its raw density is identical if source jets occur.
Check direct ordinary Euler variation against slot derivative as well.
Apply A/all A-jets=0 only for this declared FLAT statement; show projection
commutes with these derivatives. Do not infer missing off-flat reference terms.

Classical insertion matching uses the qualified exact chain rule and affine
V''=0: DH=B0''+V'_hR'_k+V'_kR'_h. Recheck its g2 pre-Hessian density from the
actual GF/sourceR and V0/V1, retaining Bsource only vanishing at fixedJ=0.
A universal pair of EVEN field polarizations yields the whole inherited
mixed-Hessian formula. Do not rerun a huge qualified DH tensor or rooted
search just for bookkeeping. Record the actual g2 root counts/dependencies;
no fresh independent insertion-loop integration is claimed.

For each finite ordered Born word, derivative acts at EVERY H insertion with
its original1/n weight; G/heat/reference have no antighost or J dependence
and D leaves A fixed. V255 formal finite-jet UV bounds justify local pole
interchange in the explicit Weyl family. Preserve source-left/Grassmann order;
use no infinite divergent-trace cyclicity,EOM,whole-scaleless-zero, fitted
counterterm or old nonlinear field-Jacobian shortcut. Gamma_ref[A] is retained
and has D derivative0 by A-only dependence, not by discarding the determinant.

Two sequential own-role read-only native120sec afterimports/8GiB sampledprivate/
minimum350MiB availablecommit plus separate bounded independent verification.
Distinct prefix/replay slot/left-Euler routes and ordinary-SymPy verifier.
Freeze explicit literal result/binding reads before workers to avoid repeating
inherited-whitelist failures. Preserve failed sources/captures,correct only by
newversion. Validate beforelocalcommit; no agents,branches/worktrees,remote,
source/functional/input/benchmark/scheme/policy/authority change. Sevenflags
false,authority34/39,E5/A5 unqualified,HB1/C5blocked,flavorpaused,custody2/seven.

Controls omit V0*source2,V1*source1,ordinary quartet or a nonzero predecessor;
reverse a source sign and odd anchoring prefix; omit an ordered Born leg.
If an actual component control is insensitive, preserve that limitation and
use a justified nonzero fixture rather than claim success. TrackB assesses
whole-order closure and avoiding full-expression expansion. Shared actions,
charts,measured normals,software and AI author are not independent scientists.
