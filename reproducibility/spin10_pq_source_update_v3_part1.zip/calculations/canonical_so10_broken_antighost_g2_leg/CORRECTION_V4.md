# Native continuation V4: summary helper index

The V3 scientific worker reached the final type summary and failed because
h.kind expects an integer field index; the call passed its display name.
The full failed source/preparation/controller/capture remain. All intermediate
assertions ran, but no completed result was emitted or qualified; do not treat
that unfinished run as a scientific PASS or a reusable computation cache.

V4 changes only the preparation pointer and this summary argument. A metadata
preflight checks the helper on actual canonical field indices before launch.
No equation, input, normalization, predecessor, boundary current or scientific
acceptance condition changes. Two native routes and the independent verifier
must still complete under120sec/8GiB/min350MiB limits. Two failed scientific
workers and one separate prelaunch event are now preserved. This repeated
interface/reporting failure is an implementation limitation, not physics.
