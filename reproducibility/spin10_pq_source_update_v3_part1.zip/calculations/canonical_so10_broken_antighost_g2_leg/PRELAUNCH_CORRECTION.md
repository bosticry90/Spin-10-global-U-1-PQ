# Prelaunch continuation: qualified ghost result version

The initial preparation aborted on a nonexistent unversioned ghost-kinetic
canonical result. Its qualified files are primary_v4_result.json and
replay_v4_result.json under the completed existing validation receipt. The
following original controller also failed because no preparation manifest had
been created; neither command launched a scientific worker.

Original leg.py/source copy, controller, preparation script/source copy and
reported errors remain. The corrected leg_v2.py changes only this qualified
result pointer. prepare_v2.py explicitly binds V4 bytes/receipt, reports any
missing dependency pathname before launch, and preserves prior failed sources.
The first completed preparation.json will freeze leg_v2 and run_v2. Scientific
inputs/mathematics/resources remain unchanged; there is one prelaunch failure
event, zero failed scientific workers at this point. No original capture of a
worker exists, because there was no worker. The reported prelaunch errors are
preserved in the external prelaunch_failure.txt.
