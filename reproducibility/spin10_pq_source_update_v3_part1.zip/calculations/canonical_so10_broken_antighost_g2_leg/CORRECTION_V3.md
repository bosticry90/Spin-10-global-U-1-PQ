# Native continuation V3: actual ghost-node key

The first scientific worker (leg_v2.py) passed the actual flat classical chain
rule and failed at the ordinary pole comparison on an outdated JSON key.
V4's correct key is new_actual_g2_ghost_kinetic_node. The original incomplete
worker, full capture, source/controller and frozen preparation remain unchanged;
no partial result is qualified. No replay ran.

leg_v3.py changes only the preparation filename and exact qualified field key.
prepare_v3.py additionally checks the actual V4 node schema/184 positions in
both role records before freezing. All scientific equations, source pieces,
coverage/current requirements and limits remain. Reuse no unexported partial
calculation: run two bounded120sec/8GiB/min350MiB native routes and independent
validation. One failed native worker and the separate prelaunch event are
preserved; ordinary corrections are within standing AGENTS.md delegation.
