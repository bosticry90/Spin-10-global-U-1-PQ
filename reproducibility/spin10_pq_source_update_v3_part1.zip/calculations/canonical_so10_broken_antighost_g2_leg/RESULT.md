# Complete flat g10^2 broken-antighost insertion: nonzero leg-derived pole

Both completed native routes obtain a nonzero6608-position insertion tensor
for all33 broken directions in the declared flat one-loop local-logarithmic
prescription. This is a legitimate loop-leg derivative of complete previously
measured poles, not a coefficient chosen to make a Ward/Slavnov identity zero.
Qualification requires the completed independent receipt and subsequent
committed-byte checks; this report alone is not that receipt.

## Complete measured inputs and source compensation

The current4530-position ordinary g2 antighost input is reproduced exactly:
quartet1302, auxiliary276, derivative-vector2768 and ordinary ghost kinetic184.
Its earlier baseline plus lossless ghost/mixing delta match the actual legacy
measured sectors. All later current-functional additions have no additional
g2 antighost term. V262 independently established87/87 complete bare profile
scope evidence; its structural zeros are retained as complete cohort sums.
The actual GF2 also contains no unrepresented nojet two-field antighost mass
vertex. No missing ordinary pole is inferred zero from stored word absence.

The source image contains all132 g1 and26380 g2 coefficient positions within
the qualified146663-position source input. The sourceg2 dimension-zero census
has28 complete profile records; all five positive-dimensional source targets
are also covered. Both actual predecessor orders are included:
 V0*source2:5636 flat product positions from229 active source channels;
 V1*source1:720 positions from128 active source channels.
Two V0 channels have zero source2 Euler and248 V1 channels have zero source1
Euler in the complete measured input. Their exclusion is algebraic support,
not an unmeasured-zero assumption. Source0 quantum poles are separately zero
by V257, and the actual V maps have no order2. Widths and all scalar/VEV terms
remain in the input even where their relevant contraction vanishes.

## Actual insertion tensor

The ordinary pole variation has5060 positions; its complete source-compensated
raw representative has7688. After exact odd-test-function anchoring:

| Anchored field class | Jets | Nonzero positions |
| --- | ---: | ---: |
| epsilon B C | 1 | 3648 |
| epsilon C C antighost | 0 | 2556 |
| epsilon C auxiliary | 0 | 276 |
| epsilon C | 2 | 128 |

The sum is6608, covering every broken test direction12..44, including actual
zero tensor complements. Four explicit boundary currents each contain489
positions. The result is an integrated local-functional coefficient modulo
those currents, not a raw density that vanishes term by term. The pole uses
the existing canonical one-loop units and inherited measured normalizations.
It is not a physical scattering amplitude or an anomaly verdict.

Exact source Euler contractions and even source-slot replacements agree. In
the current source-normalized representative those raw source forms are
identical and their additional source-current difference is zero; this is
reported rather than counted as an extra nonzero-boundary test. The ordinary
slot/Euler and combined epsilon-current comparisons remain nontrivial. The
source image is reused as its qualified measured representative modulo the
recorded inherited boundary convention; no quantum canonical generator is
adopted or used as a physical field redefinition.

## Why loop-leg differentiation is justified here

The actual flat classical order2 chain rule is independently testable before
any Hessian expansion:21644 positions from D_GF2 minus28252 source products
equal the qualified7444-position B02. The complete source-linear Bsource has
1016 positions and vanishes only at fixedJ=0. All actual V kernels are affine,
so two EVEN field polarizations give the inherited insertion root B0'' plus
BOTH ordered mixed V'R' terms. The82544 C2 positions remain authenticated
inherited data. No fresh dense DH2 tensor or root graph search is claimed.

D leaves the actual reference Green function, A-only heat prescription and
Gamma_ref[A] fixed. The determinant is retained and has derivative0, not
discarded. Every ordered Born insertion position and its original1/n weight
is retained; the proof applies at all finite word lengths. The V255 formal
finite-jet UV bounds and V259 dimension budget justify extracting the local
logarithm after this derivative in the explicit Weyl family. No divergent
trace cyclicity, EOM, scaleless-integral inference or fitted counterterm is used.
The quantum-measure obligations of the earlier nonlinear32-field primitive
are distinct and remain unresolved.

Only A and its jets are projected to zero. Quantum B_H is retained. The actual
projection commutes with the relevant field/source variations. This does NOT
supply off-flat reference/heat coefficients or a universally determined
historical physical prescription. Nor does this derivative construction
constitute a new independent insertion-loop integration; all inherited
normalization assumptions remain visible.

## Execution, verification and scope

Completed primary/replay28.017/28.298sec afterimports, sampledprivate
901713920/873840640bytes. Limits120sec/8GiB/min350MiB. The independent verifier
must recompute original inputs, source/ordinary variations, all6608 entries,
all currents, actual classical chain rule and the structural ordered-leg proof.
Controls omit either source predecessor, remove the ordinary quartet, reverse
the source sign, corrupt the odd prefix and omit an ordered Born leg. Every
native control is sensitive; its independent counterpart remains required.

One prelaunch preparation/controller event failed on the ghost result version.
Two scientific workers failed: an outdated ghost-node JSON key, then an
incorrect field-name argument to an index-based summary helper. The initial
metadata inspection printed that the old key was absent but did not gate the
launch; that was avoidable. V3 added the correct schema check; V4 added actual
helper-type metadata checks. All original sources/manifests/full captures are
preserved, no unfinished result accepted, no resources expanded. No fresh
byte-identical replay pair is claimed. Final independent counts/performance
belong to its actual receipt.

No source/known-functional/input/benchmark/scheme/policy/authority change.
Known functional155110/sourcefree40309/sourceimage146663 unchanged. Seven
quantum flags false; authority34/39. Full sourcefreeSlavnov,QAP,measure,
contacts/products,equivalence,IR and E5/A5 unqualified. Historical quartet
normalization failure, singlet quantum warning, gauge-matching failure and
custodyexit2/seven references remain. HB1/C5 blocked,flavorpaused.

The next decision-relevant test is whether this complete flat order2 insertion
can be extended within the explicit local covariant family. First check its
actual H-covariance relation with the qualified g1 insertion and correct
epsilon carrier; only then reuse the conditional local A-kernel uniqueness
argument with all its hypotheses. If it fails, retain the exact missing
background response rather than declaring the flat result a full quantum
identity. Completing an entire restoration dependency remains the priority.

Track B: this closes a full coupling-order input/leg problem and returns an
honest nonzero coefficient without another full-functional expansion. The
multiple interface/reporting errors remain significant implementation
limitations. Actions,measured poles/normalizations,reference/catalogue,type
charts,prior UV proof,software and AI author are shared; the evidence is
computational corroboration,not Lean,expert,experiment or physical GUT proof.
