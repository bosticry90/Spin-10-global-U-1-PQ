# Final flat g2 result: V5 scientific runs and corrected custody gate

This version supersedes RESULT.md ONLY as the checkpoint qualification record.
The mathematical statement, action/normalization inputs and scope are unchanged:
the complete flat all33 broken-antighost g10^2 loop-leg insertion is nonzero
with6608 coefficient positions. Both source predecessor orders are required.
All4530 ordinary inputs,132 source1 and26380 source2 positions, four489-position
boundary currents, classical affine-kernel chain rule and ordered Born-leg
proof remain the acceptance requirements. Exact coefficient tables belong to
the new primary_v5/replay_v5 outputs; no old completed run is the final native.
The final independent receipt must be validation_v2_receipt.json and complete
its strict current-input PLUS historical source-mirror failure audit.

The initial independent receipt completed its mathematics but missed an old
controller display-copy overwrite. Preparations V3/V4 rewrote a filename
already frozen under V2. This violated the source-custody rule. Actual code,
controllers, data, inputs and full captures remained, but this was not an
acceptable checkpoint. All original manifests/receipts are preserved, not
edited to report a pass. Exact V2/V3/V4 mirror bytes are recovered by their
original digests; the first unversioned path is restored and the historical
later-path mismatches explicitly remain classified in the recovery record.
See CUSTODY_CORRECTION_V5.md and controller_mirror_custody_recovery.json.

New native V5 runs use a uniquely named controller_v5_source.txt and a strict
current manifest. All source copies are written exclusively or checked for
exact equality, never overwritten. The new independent gate authenticates
every original historical manifest body and mirror archive, accepts NO
unexplained mismatch, and distinguishes those failed historical snapshot
paths from the current strict V5 inputs. It also repeats every original
mathematical check. The old validation remains completed but insufficient
for historical-copy custody; it is not presented as the final qualification.
No old manifest is rebound and no physics or scientific acceptance condition
is relaxed. These corrections require no new physical scheme or authority.

Execution history: one prelaunch event, two failed native workers (wrong node
key and summary type), two mathematically completed V4 native runs unqualified
for checkpoint custody, and one completed V1 independent validation with an
inadequate historical mirror check. Final V5 primary/replay and the new
independent verifier must meet the original120sec/8GiB/min350MiB limits. Their
actual performance/failure counts are in the final receipt. No fresh
byte-identical replay pairs, independent insertion integration or dense new
Hessian proof are claimed. Restoring a hash mirror does not itself validate
mathematics: new native runs and the complete independent gate remain required.

The result is still a leg derivative of independently action-calculated
ordinary/source poles in the specified formal local UV family. It is not a
zero Slavnov relation, an anomaly, a full off-flat amplitude or restoration of
the theory. The source-normalized representative and its inherited boundary
convention remain; the four new currents describe that representation. Full
QAP,measure,IR,contacts/products,equivalence and E5/A5 stay unqualified.
Scientific authority34/39, known functional155110/sourcefree40309/sourceimage
146663, seven false flags, historical quartet failure and physical scalar
quantum-control/gauge-matching problems remain. Global custodyexit2/seven
references is a distinct unchanged obligation. HB1/C5 blocked,flavorpaused.

The useful scientific gain is a complete nonzero order2 insertion for every
broken direction with all predecessor pieces and currents. The next smallest
test is its H-covariant off-flat completion, starting with the actual epsilon
module and T0 I2+T1 I1. Any use of local A-kernel uniqueness must establish
all assumptions; it is not permission to fit an unmeasured pole. No source,
input,physical benchmark,scheme,policy or authority has been changed.

Track B: exact algebra/input assembly succeeded, while repeated interface
mistakes and the frozen-copy overwrite expose substantial engineering
limitations. Recovery is explicit and every failed/inadequate record remains.
Shared actions,poles,charts,software and AI authorship limit independence;
there is no Lean,external expert,experimental or full-theory endorsement.
