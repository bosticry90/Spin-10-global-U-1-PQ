# Complete antighost/source zeroth-order UV support exclusion V2

Prospective qualification requires completed independent receipt and committed
byte verification. Native agreement alone is not final acceptance. Formal
coefficient extraction in g10 is not a physical g10=0 choice. Scalar couplings,
reference widths/masses and all643 fields remain. Authority34/39 unchanged.

Result:in the explicit Weyl-reference formal one-loop local UV family,all45
ordinary antighost and all643 source coefficients atg10^0 vanish. Independently,
all33 actual broken-antighost g0 logarithmic insertion coefficients vanish.
This closes the entire zeroth-order antighost/source projection,not the full
quantum action,any higher g order,or the scalar/auxiliary effective potential.

Complete input coverage

All34 literal physical ASTs were checked:the g0 gauge part is quadraticBB,
scalar kinetic parts quadraticxx,and all nonlinear physical interactions
are purelyscalar,including after vacuum shifts. The four actual scalar
representation families Phi,Sigma,phi,S identify coordinate and conjugate
spellings without mistaking invariant-field names for new field types.

The actual g0 GF nonlinear interaction has276 zero-jet C-L-a monomials.
There is no g0 background-dependent quadratic interaction. All517 actual
nonminimal quadratic Fourier-Hessian positions match the complete reference
block exactly. The earlier full413449-position GF comparison and45 physical
Maxwell blocks are authenticated,not repeated. All225 g0 master source words
are affine in quantum fields,so their fixed-source fluctuation Hessian iszero.
No source shifts contain inverseg. Scalar mass differences stay in deltaH.

Every actual reference propagator is retained. Nonzero type edges are
BB,BL,LB,Ca,aC,xx;LL is exactlyzero. The complete typed W=GdeltaH graph is
 B->C(external a),B->a(external C),C->C(external L),
 C->L(external C),a->L(external a),a->a(external L),x->x(scalar).
Only three edges lie on directedcycles:C->C,a->a,x->x. Thus any closed Born
word at ANY length has only auxiliary or scalar external fields. External
antighost/ghost edges cannot close. This type graph over-approximates every
actual color/Lorentz graph;absence of support requires no cancellations,
scaleless integral or fitted coefficient. Colors/signs cannot restore an
absent path. Finite graph reachability and simple-cycle enumeration agree.

The actual V244 breaking terms start at positiveg. All552 C0 mixed-insertion
positions have fluctuation pairCL and no extra field besidesepsilon. Their
marked W edges B->C and a->L cannot lie on a cycle. Every ordered word with
one C0 insertion therefore vanishes independently of D Gamma. The ordinary
Gamma0 source/antighost projection is alreadyzero,and allD kernels have
nonnegativeg,so D_iGamma0=0 too. Both sides are established separately rather
than assigning an unknown insertion the value needed for an identity.

Background and quantum limits

The explicit Weyl witness D=partial-g rho A and its heat regulator have
background Hessian/heat vertices at positiveg. Theg0 UV statements therefore
extend to that explicit local family off flat background. Arbitrary additional
curvature covariantizations need not have this coupling count and are outside
this result. No unique historical or adopted physical prescription is claimed.
Reference determinant is source/antighost independent and retained. Fixed
UV-smoothing IR changes cannot alter this log;finite IR amplitudes and global
measure/removal are not established. Scalar/auxiliary potentials may remain.

Independent verification uses a different proof:ordering blocks B,C,a,x,L
makes W uppertriangular. Its diagonal blocks contain only external L/scalars;
marked C0 insertions are strictly uppertriangular. This proves the all-word-
length statement even for noncommuting color/field blocks. Boolean support
matrix controls adding LL,adding a B-bearing vertex or adding a g0 source
Hessian open the forbidden cycles. They are structural controls,not claimed
nonzero amplitudes of an altered physical model.

V1 native failed on an incorrect scalar-name prefix assumption in the AST
gate. V2 binds invariant/conjugate/coordinate names to actual representation
families;no action/domain/graph/acceptance condition changed. Original source,
preparation and fullcapture preserved;noV1replay. V2 native4.989/4.940sec,
private peaks495206400/478953472bytes. Independent verifier pending at report
freeze. Limits120sec/8GiB/350MiB retained;fresh byte-identical replaypairs0.
Shared action/chart/GF/reference,V244/principal/locality proofs,software and
AI author limit independence;not expert,Lean or experimental confirmation.

Known155110/sourcefree40309 and allsourcecoefficients remainunchanged. The
oldquartet failure,nonzero Jacobian,32 nonlinear primitive products,128source
jets,508physicalprograms,2197unreconciled genericprofiles andscalarquantum
warnings remain. Fullsourcefree Slavnov,QAP,measure,IR,contacts,equivalence and
E5/A5 unqualified;sevenflagsfalse,authority34/39. No benchmark/input/scheme or
blocked/paused work change. Whole Spin(10)xglobalU(1)PQ investigation incomplete.

Next smallest scientific question:reconcile the complete g1 predecessor
inventory for the other32 broken directions using actualB''+C and the g0
triangular support,then reuse measured g1 nonminimal/source coefficients.
Prioritize a complete coupling-order relation over another isolated tensor.
Do not import the special B12=0 condition into directions with nonzero B.
