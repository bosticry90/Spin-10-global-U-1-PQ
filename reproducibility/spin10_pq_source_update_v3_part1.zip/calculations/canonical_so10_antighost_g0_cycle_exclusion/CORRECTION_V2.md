# V2 actual scalar-family naming correction

V1 primary FAILED at the physical AST type gate because it assumed every
scalar field used the x_ coordinate prefix. Actual invariant potential nodes
also use Phi,Sigma,SigmaBar,phi,phiBar,S,SBar. V2 binds each actual scalar family
to the four keys of the authenticated physical representation matrices,
including conjugate and coordinate spellings. This changes no mathematical
field content,action or acceptance condition. All34 physical terms and every
source/GF/reference/graph check remain. Original source/preparation/fullcapture
retained;noV1replay. Two sequential V2 native and independent validation runs
retain120sec/8GiB/350MiB limits under standing AGENTS delegation.
