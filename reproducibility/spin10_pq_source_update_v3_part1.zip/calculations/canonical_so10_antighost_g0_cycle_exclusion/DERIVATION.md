# Complete typed-cycle proof at zeroth gauge-coupling order

This is coefficient extraction in g10,not a physical g10=0 adoption. Widths,
scalar masses/potential and every nonminimal field remain. The complete34-term
physical action has no antighost or source. Its g0 gauge kinetic part is BB
quadratic,and g0 scalar kinetic parts are xx quadratic. All potential terms
are scalar only,including after vacuum shifts. The matched nonminimal
quadratic GF terms belong in Kref;scalar reference mass differences remain in
deltaH. The actualg0 source action is affine in quantum fields,so its fluctuation
Hessian vanishes. Allotherg0 nonminimal interaction is Xi*L*a*C.

Keep every reference edge;notably GLL=0 while GBL is nonzero. The TYPE graph
is a safe over-approximation of every actual color/Lorentz graph. An Xi vertex
with external a has HessianCL;its internal L must propagate toB. No g0
interaction has a B fluctuation,so that path cannot close. More generally,
W=GdeltaH has B->C/a, C/a->L, C->C, a->a and x->x edges. B has no incoming
edge,L has no outgoing edge. The only cyclic edges are the two ghost-sector
self loops with externalL and scalar-sector loops. Thus no finite closed Born
word at any length contains an external antighost or ghost. This is absence
of support before color integration,graded signs,UV integration or summation.
Reference determinant is antighost/source independent as well.

The actualD_i source terms do not undo that conclusion:Gamma1(g0) has no source
coefficient,and the operation contains no negative g powers. Hence
 [D_i Gamma1]_(g0)=0 for all45 antighost directions as an ordinary local UV
coefficient,with full source-left conventions. No expectation-value factorization
is used. Scalar/auxiliary effective-action terms may remain nonzero.

Independently,V244 supplies Bsource/B0 and the two mixed Hessian insertions.
Atg0 B=0 for all33 broken directions. Every C0 term has fluctuation pairCL
and no externalfield other thanepsilon. Its marked W edges are B->C or a->L,
neither cyclic in the g0 graph. Therefore EVERY ordered Born word with one
actualC0 insertion vanishes by support. This proves the insertiong0 zero as
well,without choosing it to matchD_iGamma1. Both sides were checked separately.

The explicit Weyl covariant reference and P=-Dbar_H^2 have A dependence with
positiveg10 powers;theg0 statements therefore cover their background-dependent
formal UV coefficients too. Nonquadratic GF g0 words carry noA;anylinear field
term haszero Hessian. This restriction is essential:an arbitrary added local
curvature member need not share its coupling counting. No universal historical
regulator claim is made. V255 supplies local UV-log correspondence and UV-finite
IR-change stability,not a whole finite amplitude/global measure theorem.

A finite directed edge lies on some closed walk iff its end can reach its
start. If such a walk exists,erasing loops produces a simple cycle containing
the edge. Therefore finite reachability or simple-cycle enumeration certifies
all word lengths. Structural mutations adding GLL or a B-bearing vertex make
marked antighost edges cyclic;adding a g0 source Hessian makes a source edge
cyclic. These demonstrate premise sensitivity,not nonzero physical amplitudes.
