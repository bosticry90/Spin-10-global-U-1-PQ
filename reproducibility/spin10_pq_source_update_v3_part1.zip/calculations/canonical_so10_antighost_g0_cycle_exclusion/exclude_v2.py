"""Complete actual g0 action support and all-length marked-cycle exclusion."""
from pathlib import Path
from collections import Counter
from itertools import product
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
a=load('actual_g0_support_helpers',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;s=a.s;read=a.read;digest=a.digest;PKG=a.PKG

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('G0_CYCLE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+role+' '+n,flush=True);t0=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-t0});return z
 action,ab=b.sealed('frozen_a10_executable_reconciliation','M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1');core,cb=b.sealed('frozen_a10_e5_full_hessian',role);e2,eb=b.sealed('frozen_a10_e2_transport',role);master,mb=b.sealed('frozen_a10_bv_master',role);ref=core['retained_reference'];names=ref['field_order'];terms=action['local_terms']
 physical_rep,pb=b.sealed('frozen_a10_physical_reconciliation','full_'+role);scalar_sectors=set(physical_rep['representation_matrices']);assert scalar_sectors=={'Phi','Sigma','phi','S'}
 def is_scalar(n):return (n[2:] if n.startswith('x_') else n[:-3] if n.endswith('Bar') else n) in scalar_sectors
 Fnames=sorted({x['name'] for term in terms for x in walk(term['density']) if x.get('node')=='Field'});gg=s.Symbol('formal_g_counter');fs={n:s.Symbol('formal_field_'+n) for n in Fnames}
 def signatures(n):
  typ=n['node']
  if typ=='Field':return {(0,(n['name'],))}
  if typ in ['ExactScalar','RepresentationGenerator','StructureConstant']:return {(0,())}
  if typ=='Parameter':return {(int(n['name']=='g10'),())}
  if typ in ['GroupContraction','LorentzContraction','PartialDerivative']:return signatures(n['expression'] if 'expression' in n else n['argument'])
  if typ=='Add':return set().union(*(signatures(x) for x in n['terms']))
  assert typ=='OrderedProduct',typ;out={(0,())}
  for child in n['factors']:out={(g+k,tuple(sorted(f+v))) for g,f in out for k,v in signatures(child)}
  return out
 def positive(n):
  typ=n['node']
  if typ=='Field':return fs[n['name']]
  if typ in ['ExactScalar','RepresentationGenerator','StructureConstant']:return s.S.One
  if typ=='Parameter':return gg if n['name']=='g10' else s.S.One
  if typ in ['GroupContraction','LorentzContraction','PartialDerivative']:return positive(n['expression'] if 'expression' in n else n['argument'])
  if typ=='Add':return sum(map(positive,n['terms']))
  assert typ=='OrderedProduct',typ;return s.prod(map(positive,n['factors']))
 def physical():
  out={}
  for term in terms:
   if role=='primary':sig=signatures(term['density'])
   else:
    poly=s.Poly(positive(term['density']),gg,*[fs[n] for n in Fnames]);sig={(p[0],tuple(n for n,k in zip(Fnames,p[1:]) for _ in range(k))) for p,c in poly.terms()}
   zero={f for g,f in sig if g==0};assert zero
   if term['term_id']=='gauge':assert zero=={('B','B')}
   else:assert all(all(is_scalar(n) for n in f) for f in zero)
   if term['term_id'].startswith('kinetic_'):assert all(len(f)==2 for f in zero)
   out[term['term_id']]=[[g,list(f)] for g,f in sorted(sig)]
  assert len(out)==34 and set(out)=={t['term_id'] for t in core['physical_Hessian_program']['all_34_literal_terms']};return out
 physical_support=stage('all34_literal_physical_action_g0_support',physical)
 gf=m.decode(e2['gauge_fixing_density']);g0={key:z for key,z in gf.items() if key[0]==0};nonlinear=[];background_quad=[]
 for (gp,key),z in g0.items():
  fields=[n for n,j in key if n in m.fields]
  if len(fields)>=3:
   assert len(key)==3 and sorted(h.kind(n) for n in fields)==['C','L','a'] and all(not j for n,j in key);nonlinear.append(key)
  if len(fields)==2 and any(n not in m.fields for n,j in key):background_quad.append(key)
 assert len(nonlinear)==276 and not background_quad
 S=m.decode(master['source_polynomial']);source0={key:z for key,z in S.items() if key[0]==0};assert source0 and all(sum(n in m.sources for n,j in key)==1 and sum(n in m.fields for n,j in key)<=1 for gp,key in source0)
 KH={(i,j):s.sympify(z) for i,j,z in ref['reference_Hessian_raw_C3']['entries']};KGF={(i,j):s.sympify(z) for i,j,z in ref['literal_GF_Fourier_Hessian']['entries']};nonphysical={ij:z for ij,z in KH.items() if any(h.kind(m.index[names[k]]) in ['C','a','L'] for k in ij)};assert len(KGF)==517 and KGF==nonphysical and ref['literal_GF_all_413449_entries_matched']
 assert ref['auxiliary_auxiliary_Green_zero'];Gs={(h.kind(m.index[names[i]]),h.kind(m.index[names[j]])) for i,j,z in ref['reference_Green_raw_C3']['entries']};assert Gs=={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x')}
 principal=b.auth('canonical_so10_ub12_reference_symbol',role+'_v2_result.json');assert len(principal['all45_mixed_principal_blocks'])==45 and principal['all45_ghost_orientation_pairs_and328_scalar_principals_checked']
 assert core['complete_source_and_GF_Hessian']['g0_source_Hessian_zero'] and core['complete_source_and_GF_Hessian']['all_source_correction_minimum_g_power_at_least_one']
 old=b.auth('canonical_so10_broken_antighost_operator',role+'_v2_result.json','validation_v2_receipt.json');assert all(r['g']>0 for k in ['classical_source_breaking','classical_sourcefree_breaking'] for r in old[k]);C0=[r for r in old['complete_mixed_Hessian_insertion'] if r['g']==0];assert len(C0)==552
 for row in C0:
  hs=[n.partition('__')[0][5:] for n in row['word'] if n.startswith(('zz_h_','zz_k_'))];eps=[n for n in row['word'] if n.startswith('zz_da')];assert len(hs)==2 and sorted(h.kind(m.index[n]) for n in hs)==['C','L'];assert len(eps)==1 and len(row['word'])==3
 H=[('C','L','a'),('a','L','C'),('C','a','L'),('x','x','scalar')];marked=[('C','L','epsilon')];states=sorted({'B','C','L','a','x'})
 def edges(G,V):return sorted({(i,k,mark) for x,y,mark in V for j,k in {(x,y),(y,x)} for i,jj in G if jj==j})
 def cyclic(E):
  if role=='primary':
   reach={(i,i) for i in states}|{(i,j) for i,j,k in E}
   for k in states:
    for i in states:
     for j in states:
      if (i,k) in reach and (k,j) in reach:reach.add((i,j))
   return [e for e in E if (e[1],e[0]) in reach]
  out=set()
  for start in states:
   def visit(current,seen,path):
    for e in E:
     if e[0]!=current:continue
     if e[1]==start:out.update(path+[e])
     elif e[1] not in seen:visit(e[1],seen|{e[1]},path+[e])
   visit(start,{start},[])
  return sorted(out)
 E=edges(Gs,H);cyc=stage('all_word_length_cycle_support_and_marked_insertion',lambda:cyclic(E));assert {z for i,j,z in cyc}=={'L','scalar'} and not any(z in ['a','C'] for i,j,z in cyc)
 markedE=edges(Gs,H+marked);assert not any(k=='epsilon' for i,j,k in cyclic(markedE))
 controls={'add_LL_propagator_opens_antighost_cycle':any(k=='a' for i,j,k in cyclic(edges(Gs|{('L','L')},H))),'add_g0_BC_vertex_opens_antighost_cycle':any(k=='a' for i,j,k in cyclic(edges(Gs,H+[('B','C','a')]))),'add_g0_source_Hessian_opens_source_cycle':any(k=='J' for i,j,k in cyclic(edges(Gs,H+[('C','a','J')])))};assert all(controls.values())
 witness=b.auth('canonical_so10_local_covariant_reference_witness',role+'_result.json','validation_v2_receipt.json');assert witness['explicit_covariant_operator']['derivative']=='D_mu=partial_mu-g10 sum_a rho_a A^a_mu';assert core['finite_cutoff_loop_program']['cutoff']=='F_Lambda=exp[-(-Dbar_H^2)/Lambda^2] on each actual H carrier; dual action on the right; source independent'
 local=b.auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert local['unheated_complete_classical_minus4_symbol_alone_determines_leading_log']
 qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
 result={'schema':'ALL_ANTIGHOST_G0_CYCLE_EXCLUSION_V1','route':role,'scientific_disposition':'ALL45_ANTIGHOST_AND643_SOURCE_G0_UV_ZEROS_AND_ALL33_BROKEN_G0_INSERTION_ZEROS_EXPLICIT_WEYL_FAMILY','all34_physical_support_signatures':physical_support,'g0_GF_nonlinear_zerojet_C_L_a_words':len(nonlinear),'g0_GF_background_quadratic_interactions':len(background_quad),'g0_master_source_word_positions':len(source0),'g0_master_source_Hessian_zero_actual_field_degree_checked':True,'all517_actual_GF_quadratic_reference_entries_match_no_nonminimal_residual':True,'full413449_literal_comparison_and45_Maxwell_blocks_authenticated_not_replayed':True,'actual_Green_type_edges':[list(e) for e in sorted(Gs)],'complete_overapproximate_Born_type_edges':[list(e) for e in E],'all_word_length_cyclic_edges':[list(e) for e in cyc],'all552_actual_C0_positions_CL_no_other_fields':True,'Bsource_B0_have_no_g0_positions':True,'marked_insertion_cycle_edges':[list(e) for e in cyclic(markedE) if e[2]=='epsilon'],'all45_ordinary_antighost_and643_source_g0_UV_coefficients_zero':True,'all33_broken_g0_log_insertion_coefficients_zero':True,'no_scalar_or_auxiliary_effective_potential_zero_claim':True,'no_scaleless_integral_or_fitted_coefficient_used':True,'explicit_Weyl_background_positive_g_only_not_arbitrary_covariantizations':True,'finite_amplitudes_or_global_IR_measure_QAP_contacts_sourcefree_Slavnov_E5_A5_proved':False,'controls_structural_not_nonzero_modified_model_amplitudes':controls,'seven_false_quantum_flags':flags,'source_functional_benchmark_scheme_authority_changed':False,'shared_limits':'Actual action,E2/master,retainedGF/reference,V244insertions,V252/V255 and SymPy/AIauthor shared;typed support proves absence,not numerical amplitudes or expert confirmation','stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

def walk(x):
 if isinstance(x,dict):
  yield x
  for y in x.values():yield from walk(y)
 elif isinstance(x,list):
  for y in x:yield from walk(y)
if __name__=='__main__':main()
