# A concrete local module for the nonlinear auxiliary insertion

Prospective qualification gate:require the completed separate receipt and
committed-byte checks. Two native routes have completed;this report is prepared
before independent validation. No renormalized prescription is adopted.

The actual project dimensions give a dimension2,ghost0,even auxiliary shift.
Its complete local Lorentz-scalar power-counting envelope has12 raw patterns:

    1,x,L,Ja,aC,JL*C,x*x,A.A,A.B,B.B,partial.A,partial.B.

Identity and x carry dimensionful coefficient deficits2 and1. All other
patterns have deficit0. Actual parameter and H-tensor support must still be
imposed;this list does not declare12 nonzero mixing constants. The coefficient
ring is polynomial in the existing parameters,not inverse physical scales.
No finite g truncation or new numerical parameter was introduced.

Exactly two families involve BV sources:Ja and JL*C. Two-source expressions,
Jx*C,JB*C and JC*C*C exceed this operator dimension. This follows from the
actual project grades,not from earlier source-free pole zeros. A single
insertion and a source-free restriction are distinct assumptions;the latter
would remove two admitted families here.

Local background covariance permits a complete parameterization through nine
carrier families:1,x,L,Ja,aC,JL*C,Sym2(x),D.q,Sym2(q). Their coefficient tensors
are the kernels of rho_target(h)T-T rho_carrier(h) for every actual unbroken
generator,subject to the inherited real evaluation-dual involution. We have
not calculated numerical intertwiner bases,ranks or the physical reality of
every free tensor. Individual Hom spaces can vanish. This is an exact
kernel-defined module parameterization,not a solved finite mixing matrix.

The two affine connections are retained. All180 actual q=B-A_H transformation
columns have their inhomogeneous derivative terms cancel. The actual vector
carrier has230 nonzero cells. The45 covariant divergences contain1148 exact
coefficient positions,and all their local-H covariance equations vanish.
The wrong connection sign fails. Noncommuting carrier order is preserved.

All90 actual Qa/QJL primitive images,2385 positions,fit this same module with
their coefficient-dimension deficits. All90 H/Q compatibility checks vanish.
The20 actual special shifts have20 raw terms and obey all45 target H equations,
including the zero-component complement. These checks use the actual E2/E3
action/source columns;they do not substitute a convenient textbook BRST map.

The corrected Dminus source kernels have309 nonzero positions across90
nonminimal source columns. Only aC,Ja,JL*C in the12-pattern module can respond
to Dminus. All33 marked broken directions are retained. Source-sign reversal
changes the source columns;the source-free aC projection alone is insensitive.
No old Dplus image is imported as a Ward relation.

Thus the local domain and actual symmetry constraint-generating operations
are now concrete. A future M c=-r must use these maps and an independently
constructed quantum defect r,with all differentiated insertions and boundary
currents. For a local probe,the divergence relation includes the explicit
current partial_mu(rho B^mu),and likewise A. No EOM or premature density
integration-by-parts quotient is used.

The remaining construction gap is precise:the actual separated-point
insertion/source-product kernels,their finite scaling degree and compatible
diagonal extension/subtraction have not been established. The published
extension theorems require such inputs;this module cannot replace them.
b0 remains symbolic. No claim of simultaneous quantum nonemptiness,no-go,
QAP,measure/IR validity,source-free Slavnov restoration or E5/A5 is made.

Next priority:derive the actual one-loop insertion/source-product kernels from
the positive-heat Born prescription and determine their extension applicability
in this module,including the two source families. If a required prescription
is undefined,identify its exact condition;do not solve a fabricated quantum
right-hand side or choose b0=0. The295 vector coefficients remain secondary.

Read completed receipts for timings,private-memory peaks and controls. Native
direct-multiset/prefix and recursive-degree/reversed-action routes share the
same action and exact algebra. The separate verifier uses its own SymPy parser,
rational radical ring and left-derivative/jet algebra to reconstruct the actual
coefficient relations. All methods share scientific premises,software ecosystem
and AI authorship;none is Lean,outside expert or experimental validation.

No Gamma,source38 standing,369/664 inventory,authority34/39,old evidence,
protected blocks/pauses or historical custody status changes. Full quantum
restoration and the wider Spin(10)xPQ physical investigation remain incomplete.
