# Actual auxiliary-insertion contact module V1

Base1214adb39e21674d12a7e8362a915d36c4b83fe1,main. Previous turn PROGRESS.
Director priority:construct actual insertion/mixing objects before any invented
linear solvability test. Ordinary delegated bounded research;no new scheme.

Question:what is the complete power-counting Lorentz-scalar local mixing
module for the actual nonlinear auxiliary shift X_Lambda,including its sources,
and what actual Ward/Slavnov/background operators constrain it? This advances
the first three contact-construction steps,not quantum nonemptiness.

Use actual TYPES from the measured-functional control,not remembered textbook
grades:C,a have project dimension1;Ja2,JL1;Jx/JB/JC2. Operator X_Lambda has
(d_project,gh,p)=(2,0,0). Coefficients lie in the existing polynomial parameter
ring,with nonnegative dimension;dimensionful deficits stay explicit. No
inverse coupling,mass,VEV or fixed b0. All643 fields and sources stay declared.
One insertion probe rho has dimension2,ghost/parity0 and transforms in the
dual target representation. It is external,not a new canonical pair.

Acceptance domain:all local ordinary jets of operator dimension<=2,ghost0,
even parity,Lorentz scalar,including identity with dimension2 coefficient.
No EOM,source-free restriction or erased integration-by-parts current. Complete
raw type enumeration must agree between direct multisets and degree recursion.
Expected12 raw patterns are derived in DERIVATION,not actual measured poles.
Maximum source number is1;do not transfer old source-free pole zeros to finite
insertions. Source Ja and JL*C are retained. Identity/x coefficients require
actual dimensionful/H-intertwiner support and are not automatically nonzero.

Under homogeneous local H covariance,parameterize the module by nine carrier
families with actual H-intertwiner kernels:1,x,L,Ja,aC,JL*C,Sym2(x),D.q,Sym2(q),
q=B-A_H embedded in45. Prove the actual all180 affine shifts cancel and actual
45 covariant divergences transform homogeneously. Do not assume the scalar,
vector,ghost,auxiliary or source carriers have the same raw coordinate matrices.
Export exact constraint-generating maps/H-fingerprints,not an uncomputed rank
or a claimed basis of all numerical invariant tensors. Reality requires the
inherited evaluation-dual involution and real coefficient constraints.

Authenticate all20 actual field shifts and their complete90 primitive inputs
Qa_i and QJL_i from E2. Check every term fits the raw module with explicit
coefficient dimension deficits. Check actual H covariance for these90 images
and the whole45-component special shift. Types of Q-images have dimension+1,
ghost+1,parity+1. Source kernels for actual corrected Dminus are frozen portable
maps;only raw aC,Ja,JL*C can vary in this module. Export actual Dminus/J source
row fingerprints and the graded operation recipe,retaining all33 directions.
No old Dplus image is used. Derive consistency equations symbolically from
these actual maps;the independent quantum inhomogeneity r remains unmeasured.

Primary:multiset enumeration,prefix/evolutionary action,mu0 extraction of actual
vector carrier. Replay:integer-degree recursion,reversed graded action,mu3
carrier extraction. Separate verifier:own integer enumeration,ordinary rational
coefficient/jet checks and independent noncommuting covariance identity;validate
all native exact residuals/hashes and literal operator dependencies. Meaningful
controls:wrong Ja/C dimensions,drop sources,wrong affine shift,wrong connection
sign,commute noncommuting carriers,wrong D source orientation. A selected
projection insensitive to a sign is not a global control.

Scaling-degree extension literature is guidance only. The actual separated-
point kernels/scaling bounds,diagonal extension and common Ward-compatible
subtraction are not constructed by a local type module. Preserve that missing
premise rather than claiming a QAP from matrix rank. b0 stays symbolic and
no finite counterterm or renormalization prescription is adopted.

Two sequential native workers120seconds AFTER imports each/8GiB sampled
private;separate verifier180seconds/8GiB. Launch floor350MiB available commit;
new bytes<5MiB. Freeze then launch separate calls,reject existing outputs/live
owned workers,preserve failed sources/captures and exact corrected versions.
No Gamma/authority/policy/old evidence changes. State113/34of39,source38,
369/664 and295 unmeasured vector profiles,custody2/seven,all protected failures,
blocks/pauses and all quantum unqualified obligations remain unchanged.
