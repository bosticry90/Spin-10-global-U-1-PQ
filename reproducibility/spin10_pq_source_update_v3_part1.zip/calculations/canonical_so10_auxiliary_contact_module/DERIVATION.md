# A dimension-two insertion module,not a renormalization prescription

The actual special shift is X_Lambda^i=g10^2*xi*Z^i_j C^j*a12 in the canonical
chart. Remove neither its coefficient nor the order C then a. The inherited
evaluation-dual maps govern physical reality. Both odd fields have project
dimension1,so the operator dimension is2 and ghost/parity are0. These are the
actual project grades;changing to asymmetric standard dimensions without
transforming every source grade gives a different,incorrect enumeration.

Dimension<=2 and ghost0 permit at most two dimension1 variables or one
dimension2 variable. Impose even parity and Lorentz contraction. The complete
raw patterns,with coefficient dimension deficits,are

    1 [deficit2], x [deficit1],
    L,Ja,aC,JL*C,x*x,A.A,A.B,B.B,partial.A,partial.B [deficit0].

Empty-word derivatives vanish. At this degree,at most two vector indices occur,
so their contraction or the vector divergence exhausts Lorentz scalars. No
epsilon-tensor invariant is omitted. Jx*C and JB*C have dimension3;JC*C*C and
all two-source ghost-neutral structures have dimension>=4. They cannot mix
with this dimension2 operator in the nonnegative polynomial ring. This is a
power-counting exclusion for this insertion,not a vanishing loop theorem.

For a local probe,rho*partial_mu B^mu and -(partial_mu rho)*B^mu differ by
partial_mu(rho B^mu). Keep this current. The operator density is not quotiented
by discarding a divergence before introducing rho. The same applies to A.

Use the two actual affine connections. q=B-A_H is homogeneous,including all
broken B directions with A_H=0 there. Let W=g*rho(omega),mathcalA_mu=g*rho(A_mu).
Then delta q=Wq,delta mathcalA_mu=partial_mu W+[W,mathcalA_mu]. Consequently

 delta[(partial_mu-mathcalA_mu)q]
   =partial_mu(Wq)-(partial_mu W+[W,mathcalA_mu])q-mathcalA_mu Wq
   =W(partial_mu-mathcalA_mu)q.

No factor was commuted. At dimension2,a covariant scalar can depend on the
connection through D_mu q^mu or q_mu q^mu. An independent field-strength tensor
has antisymmetric Lorentz indices and no scalar contraction at this degree.
Thus a complete homogeneous-H parameterization uses nine carrier families

    1,x,L,Ja,a*C,JL*C,Sym2(x),D.q,Sym2(q).

Each carries an arbitrary allowed intertwiner into the actual target auxiliary
representation. This is a kernel-defined module,not a numerical intertwiner
basis or a statement that all nine Hom spaces are nonzero. Use the separately
extracted actual carrier matrices. For every unbroken generator h the constant
coefficient tensor T satisfies rho_target(h)T-T rho_carrier(h)=0,with tensor
products and graded symmetrization as appropriate. Couple this to the inherited
real involution T=conj_target*T*conj_carrier;do not identify primal and dual charts.
Mass/VEV spurions must satisfy their actual invariant transformation rules.

The actual odd derivation Q=(S,.) and even marked Ward operation

    Dminus=delta_a-sum_J V_J partial^L_J

act by graded Leibniz rules and prolong ordinary jets. In this dimension2
domain,Dminus only acts on a*C,Ja,JL*C. In particular,dropping all sources
removes two potentially relevant mixing families. The full QJL and Qa images
are already fixed by the action and provide90 exact dimension2/ghost0
polynomials. They supply concrete normalization/compatibility relations,not
values to fit an unknown quantum remainder. Their differentiated Ward and
Slavnov images define actual constraint columns for any admitted T.

For a proposed renormalization map R,write E_I=R(O_I). At first differing order,
finite changes are linear combinations of these admitted local operators with
their complete source/probe transport. Ward/background/Slavnov defects have
the form R(delta O)-delta_R R(O),including the prescribed insertion and contact
terms. Only after those defects are independently constructed can one solve
M c=-r using the actual operations above. The present calculation constructs
the local domain and operator recipe;it does not supply r or choose b0.

Brunetti--Fredenhagen,Theorems5.2--5.3,prove extension results for distributions
already defined away from a point with finite scaling degree;point-supported
ambiguities are bounded derivatives of delta. They do not construct the
project's required mixed heat-regulated kernels or simultaneous Ward identities.
https://arxiv.org/pdf/math-ph/9903028 (pp23--25 in PDF numbering).

Hollands emphasizes constructing time-ordered products subject to compatible
renormalization/Ward conditions and analyzing their remaining contact freedom.
Its Yang--Mills construction is not an automatic theorem for this nonlinear
source/auxiliary/heat prescription. The actual kernel and hypothesis matching
remain necessary here. https://arxiv.org/pdf/0705.3340 (introduction,sections3--4).

These are primary reference standards,not external validation or a newly
adopted causal scheme. Known pole/relative transport and a classical S+bC
family do not establish a nonempty simultaneous quantum contact family.
