from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations_with_replacement
import ast,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
spec=importlib.util.spec_from_file_location('qualified_jet_algebra',R/'calculations/canonical_so10_correlated_contact_lift/lift.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ONE=u.ONE

def literal(path,name):
 tree=ast.parse(path.read_text(encoding='utf-8'))
 return next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
T=literal(P/'a10_e5_measured_functional_control_v2.py','TYPES');ETA=literal(P/'a10_executable_action.py','ETA')

def kind(n):
 for pre,k in [('zz_da','eps'),('omega','omega'),('Jx_','Jx'),('JB','JB'),('JC','JC'),('Jub','Ja'),('Jbar','Ja'),('JL','JL'),('Jb','JL'),('ub','a'),('bar','a'),('x_','x'),('L','L'),('b','L'),('C','C'),('B','B'),('A','A')]:
  if n.startswith(pre):return k
 raise AssertionError(('UNKNOWN_KIND',n))

def enumerate_types(types,method):
 result=[]
 def save(word):
  d=sum(types[k][0] for k in word)
  if sum(types[k][1] for k in word) or sum(types[k][2] for k in word)%2:return
  for jets in range(3-d):
   if not word and jets:continue
   if (sum(k in ['A','B','JB'] for k in word)+jets)%2:continue
   result.append([list(word),jets,2-d-jets])
 names=sorted(types)
 if method=='primary':
  for count in range(3):
   for word in combinations_with_replacement(names,count):
    if sum(types[k][0] for k in word)<=2:save(word)
 else:
  def walk(i,word,d):
   if i==len(names):save(word);return
   k=names[i]
   for count in range((2-d)//types[k][0]+1):walk(i+1,word+[k]*count,d+count*types[k][0])
  walk(0,[],0)
 return sorted(result)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed=set(prep['read_json_by_role'][role])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CONTACT_MODULE_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_CONTACT_MODULE_JSON',str(p))
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=[(n,J) for n,J,h,k in data['geometry']['field_source_h_k']];fields={n for n,J in pairs};sources={J for n,J in pairs}
 assert len(fields)==len(sources)==643
 assert T=={'B':(1,0,0),'x':(1,0,0),'A':(1,0,0),'C':(1,1,1),'a':(1,-1,1),'L':(2,0,0),'JB':(2,-1,1),'Jx':(2,-1,1),'JC':(2,-2,0),'Ja':(2,0,0),'JL':(1,-1,1)}
 module=enumerate_types(T,role);expected=[[[],0,2],[['x'],0,1],[['L'],0,0],[['Ja'],0,0],[['C','a'],0,0],[['C','JL'],0,0],[['x','x'],0,0],[['A','A'],0,0],[['A','B'],0,0],[['B','B'],0,0],[['A'],1,0],[['B'],1,0]];assert module==sorted(expected)
 grades=dict(T,eps=(1,-1,1),omega=(0,0,0))
 def grade(P,ceiling,gh,par):
  signatures=Counter()
  for (gp,w),co in P.items():
   kk=[kind(A.names[n]) for n,j in w];dim=sum(grades[k][0]+len(j) for k,(n,j) in zip(kk,w));assert dim<=ceiling and sum(grades[k][1] for k in kk)==gh and sum(A.parities[n] for n,j in w)%2==par
   signatures[tuple(sorted(kk)),sum(len(j) for n,j in w),ceiling-dim]+=1
  return [[list(k),j,d,c] for (k,j,d),c in sorted(signatures.items())]
 manifest=read(R/'tools/portable_dh_v1/manifest.json')
 for p,h in manifest['files_sha256'].items():assert digest(R/'tools/portable_dh_v1'/p)==h
 E2=read(P/f'frozen_a10_e2_transport/{role}.json');E3=read(P/f'frozen_a10_e3_symmetry/{role}.json');columns=E2['complete_columns'];H={A.index[n]:A.rows(rows) for n,rows in E3['operators']['Tb_geometric_and_transported'].items()};assert E2['full_source_nilpotence_established']
 anti=sorted(n for n in fields if kind(A.names[n])=='a');JL=sorted(J for J in sources if kind(A.names[J])=='JL');assert len(anti)==len(JL)==45
 Qn={n:A.rows(columns[A.names[n]]['source_polynomial']) for n in anti+JL};assert all(columns[A.names[n]]['physical_program'] is None for n in Qn)
 primitive=[]
 for n,Q in Qn.items():
  sig=grade(Q,2,0,0);assert all([ks,j,d] in module for ks,j,d,count in sig);primitive.append({'coordinate':A.names[n],'positions':len(Q),'sha256':A.fingerprint(Q),'raw_signatures':sig})
 print('STAGE',role,'all90_action_primitive_images_fit_exact_dimension_two_module',flush=True)
 hres={n:v.combine(v.act(A,Q,H,0,role),v.scale(v.act(A,H[n],Qn,1,role),-1)) for n,Q in Qn.items()};assert not any(hres.values())
 lift=read(R/f'calculations/canonical_so10_correlated_contact_lift/{role}_result.json');X={A.index[n]:v.unpack(A,rows) for n,rows in lift['all643_nonzero_field_flows'].items()};assert len(X)==20
 for Q in X.values():assert all(g==2 and all(x==1 and eta==0 for (x,eta,mask),number in co) for (g,w),co in Q.items());assert grade(Q,2,0,0)==[[['C','a'],0,0,len(Q)]]
 L=sorted(n for n in fields if kind(A.names[n])=='L');xres={n:v.combine(v.act(A,X.get(n,{}),H,0,role),v.scale(v.act(A,H[n],X,0,role),-1)) for n in L};assert not any(xres.values())
 # Extract the actual vector carrier independently from mu0 versus mu3.
 mu0=0 if role=='primary' else 3;rho={}
 for i in range(45):
  hi=H[A.index[f'B{i}_{mu0}']]
  for (gp,w),co in hi.items():
   if len(w)==1:assert gp==0 and w==((A.index[f'omega{i}'],(mu0,)),) and i<12 and co==ONE;continue
   assert gp==1 and len(w)==2
   vec=next((n,j) for n,j in w if kind(A.names[n])=='B');om=next((n,j) for n,j in w if kind(A.names[n])=='omega');assert not vec[1] and not om[1];j,mu=map(int,A.names[vec[0]][1:].split('_'));assert mu==mu0;h=int(A.names[om[0]][5:]);rho[i,j,h]=co
 q={(i,mu):v.combine({(0,((A.index[f'B{i}_{mu}'],()),)):ONE},v.scale({(0,((A.index[f'A{i}_{mu}'],()),)):ONE},-1) if i<12 else {}) for i in range(45) for mu in range(4)}
 def carrier(images,i):
  out={}
  for (a,j,h),co in rho.items():
   if a==i:v.merge(out,A.product({(1,((A.index[f'omega{h}'],()),)):co},images[j]))
  return out
 affres=[]
 for i in range(45):
  for mu in range(4):affres.append(v.combine(v.act(A,q[i,mu],H,0,role),v.scale(carrier({j:q[j,mu] for j in range(45)},i),-1)))
 assert not any(affres)
 divergence={};wrong={}
 for i in range(45):
  der={};connection={}
  for mu in range(4):
   v.merge(der,v.scale(v.total(A,q[i,mu],mu),ETA[mu]))
   for (a,j,h),co in rho.items():
    if a==i:v.merge(connection,v.scale(A.product({(1,((A.index[f'A{h}_{mu}'],()),)):co},q[j,mu]),ETA[mu]))
  divergence[i]=v.combine(der,v.scale(connection,-1));wrong[i]=v.combine(der,connection)
 divres={i:v.combine(v.act(A,Q,H,0,role),v.scale(carrier(divergence,i),-1)) for i,Q in divergence.items()};assert not any(divres.values())
 wrongdiv={i:v.combine(v.act(A,Q,H,0,role),v.scale(carrier(wrong,i),-1)) for i,Q in wrong.items()};assert any(wrongdiv.values())
 print('STAGE',role,'actual90_primitive45_shift180_affine45_covariant_divergence_H_checks',flush=True)
 D={A.index[f'ub{i}']:{(0,((A.index[f'zz_da{i:02}'],()),)):ONE} for i in range(12,45)}
 for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=v.scale(A.rows(rows,True),-1)
 dsource=[]
 for n in sorted(sources):
  if kind(A.names[n]) not in ['Ja','JL']:continue
  Q=D.get(n,{});k=kind(A.names[n]);grade(Q,T[k][0],T[k][1],T[k][2]);dsource.append({'coordinate':A.names[n],'positions':len(Q),'sha256':A.fingerprint(Q)})
 assert sum(bool(D.get(n)) for n in sources if kind(A.names[n]) in ['Ja','JL'])>0
 # No other admitted raw family has an a or an active BV source.
 activepatterns=[row for row in module if any(k in ['a','Ja','JL'] for k in row[0])];assert activepatterns==sorted([[['C','a'],0,0],[['Ja'],0,0],[['C','JL'],0,0]])
 wrongT=dict(T,Ja=(1,0,0));controls={'wrong_Ja_dimension_opens_two_source_mixing':[['Ja','Ja'],0,0] in enumerate_types(wrongT,role),'dropping_sources_loses_Ja_and_JLC':sum(any(k.startswith('J') for k in row[0]) for row in module)==2,'same_affine_shift_required':any(v.combine(H[A.index[f'B{i}_{mu}']],v.scale(carrier({j:q[j,mu] for j in range(45)},i),-1)) for i in range(12) for mu in range(4)),'wrong_covariant_connection_sign_fails':bool(any(wrongdiv.values())),'Dplus_source_orientation_changes_nonzero_source_columns':bool(any(D.get(n) for n in sources if kind(A.names[n]) in ['Ja','JL'])),'aC_projection_alone_insensitive_to_D_source_sign':True}
 assert all(controls.values())
 result={'schema':'ACTUAL_AUXILIARY_CONTACT_MODULE_V1','route':role,'scientific_disposition':'COMPLETE_DIMENSION_TWO_LOCAL_TYPE_MODULE_AND_ACTUAL_COVARIANCE_OPERATOR_COLUMNS_NOT_RENORMALIZED_EXTENSION','types':T,'raw12_type_module':module,'no_multiple_BV_source_or_Jx_JB_JC_at_dimension_two':True,'homogeneous_H_nine_carrier_families':['1','x','L','Ja','a*C','JL*C','Sym2(x)','D.q','Sym2(q)'],'intertwiner_definition':'For each actual h:rho_target(h)T-T*rho_carrier(h)=0;graded tensor/symmetric products and actual evaluation-dual reality. Kernel-defined complete parameterization;individual Hom ranks/nonzero coefficients uncomputed.','actual20_shift_terms':sum(len(Q) for Q in X.values()),'actual20_shift_sha256':{A.names[n]:A.fingerprint(Q) for n,Q in X.items()},'actual90_Qa_QJL_primitive_columns':primitive,'actual90_H_Q_primitive_residuals_zero':True,'actual45_H_X_residuals_zero':True,'actual180_q_affine_residuals_zero':True,'actual_vector_rho_nonzero_cells':len(rho),'actual45_covariant_divergence':{str(i):{'positions':len(Q),'sha256':A.fingerprint(Q)} for i,Q in divergence.items()},'actual45_covariant_divergence_H_residuals_zero':True,'actual90_Dminus_nonminimal_source_columns':dsource,'only_three_raw_Dminus_active_families':activepatterns,'coupling_and_mass_policy':'actual X g2*xi;other coefficients polynomial with explicit nonnegative dimension deficits;no numerical g truncation or inverse physical parameter','probe_boundary_currents':'rho*d_mu B_mu=-(d_mu rho)*B_mu+d_mu(rho B_mu),and similarly A;retain this current;no density quotient','consistency_operator_recipe':{'Ward':'delta_a O - sum V_J partial_left_J O with all33 marked eps directions and jet prolongation','Slavnov':'Q=(S,.) actual E2 columns;odd graded Leibniz and jets;QO has dimension+1 ghost+1 parity+1','background':'actual E3 H maps and intertwiner equations','quantum_RHS':'not constructed;do not solve an invented M c=-r','reality':'inherited physical evaluation-dual involution,not raw coefficient reality'},'remaining_distributional_premise':'actual separated-point insertion/source kernels,finite scaling degree and compatible diagonal extension/subtraction remain to be established;the local module alone is not an extension theorem or QAP','b0':'SYMBOLIC_UNFIXED','no_actual295_poles_Gamma_scheme_or_authority_change':True,'controls':controls,'shared_limits':'actual action/source/reference/type/real-chart premises,portable exact algebra,software and AI author;paired implementations do not validate physical assumptions or outside/Lean endorsement','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
