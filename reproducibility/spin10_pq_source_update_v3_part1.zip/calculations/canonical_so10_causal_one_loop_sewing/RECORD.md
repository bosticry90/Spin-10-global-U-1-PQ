# COS1 — sew the one-loop cores, starting with the T3 partial diagonal

Prospective contract, base744cc38513a90370a29a759de390730d23adc62c, main.
Previous turn PROGRESS: CSP1 qualified T2 through one-loop counting. Current
preflight clean/no matching workers/452 byte bindings authenticated only.

Question: does the same heat-matched cycle extension define compatible causal
products when a proper loop collision is attached to other vertices? A T3
bubble with a bridge is the first case. The least expensive competent method
is structural: every connected one-loop graph has one cycle with trees
attached. Test the partial-diagonal subtraction order, then prove the finite-n
assembly using independent core/tree coordinates rather than expand T3 tensors.
Success should discharge the actual one-loop graph-sewing problem at every
fixed finite vertex order, not merely supply another selected radial example.

Freeze the643-field free reference, actual odd orientation and raw/physical
frames, positive scalar reference masses, symbolic eta_H/xi, all external BV
sources/background labels and finite ordinary jets. Domain: off-shell finite
compactly supported local polynomial vertices; through one TOTAL graph loop,
not a fixed hbar power in Tn. No self edges in T1-normalized products. CWB1 beta1
retains their heat-input dictionary. Unlabelled constant insertion coefficient
results remain separate: no physical adiabatic/constant-vacuum limit is added.

Reuse completed CSP1, CWB1, LBE1/HMM1/MLB1 and LIB1. Acceptance: prove unique
cycle-plus-forest decomposition and an invertible integral coordinate split;
tensor the inherited extended cycle with full Feynman bridge distributions;
prove proper-subdiagonal compatibility, causal factorization, permutations,
field independence, translation and the same graded off-shell AWI. Derive the
regulated subtraction with the ATTACHED heat family before its finite part,
including power/log divergence, ordered matrix factors and all required heat
jets. Distinguish this from taking a bare full-graph finite part. Show the
actual reference permits nonzero power-sensitive carriers and nonlocal bridge
heat jets. Do not infer a complete summed quantum coefficient from one carrier.

Primary: enumerate labeled edge multisets and classify components/cycles by
connectivity and leaf removal; compute exact coordinate determinants; expand
ordered heat products as Laurent polynomials. Replay: construct cycles plus
rooted forests and trees from Prüfer words, assemble disconnected components
by partitions; reconstruct coordinates; use triangular coefficient convolution.
Compare complete graph sets through n=6, not samples of those finite sets.
The all-finite-n claim requires the graph/distribution proof. Native finite
graphs and diagnostic heat tests do not independently prove the analytic inputs.

Independent verifier: closed rooted-forest/cycle census and component recursions,
matrix/rational finite-part checks, a Schwinger-parameter radial calculation
distinct from native heat integration, and proof/dependency review. Controls:
omit a two-cycle, a bridge, source-before-zero, inverse-coordinate Jacobian,
finite tree heat jets, or matrix order; add a second loop or drop derivative
contacts. Generic controls remain labeled generic. Recover actual GF monomials
and raw Green residues rather than assuming an action-supported power carrier.

Before computation bind proof, native/verifier sources, policies/state/V367,
original W1-W7, frozen action/reference and completed input receipts. Sequential
native120s/verifier180s after imports;8GiB sampled private allocation NOT true
peak,350MiB available-commit launch floor,4MiB package. Exact graph/rational
work; numerical45/75 digits versus independent90, agreement1e-25. No domain
truncation on resource failure. Preserve failures/version corrections.

Possible dispositions: qualified bounded one-loop assembly, explicit failed
gluing, underdefinition, or resource-limited inconclusiveness. No fitted finite
normalization, inverted physical coupling or new adopted scheme. Primary causal
forest/AWI literature supplies standards, not an automatic scalar-to-gauge
certificate. Shared action/reference, code libraries and AI author disclosed.
Track B question: can one structural proof replace indefinite selected-identity
accumulation, including the ordering errors it exposes?

Ceiling34/39/state113 unchanged. Full nonlinear MWI/Slavnov restoration, general
QAP, all-loop/multiple-insertion prescription, measure, physical states/unitarity,
Gamma_ref[A]/member phase and global limits remain separate unless specifically
proved. HB1/C5blocked,C1_GSuncalculated,flavorpaused,quartetFAIL3960/648,
custodyexit2/seven,scalar140%/matching/Yukawa issues preserved. No old evidence,
policy/action/state/source functional/benchmark/branch/remote/publication change.
Validate before local commit. After assembly assess original quantum-construction
requirements and physical priorities; do not automatically start T4 examples.
