# COS1 result — one-loop causal products assembled at finite vertex order

The bounded graph-assembly result is qualified under the explicitly reused
reference and distributional premises. The existing extended one-loop cycle
kernels now define one normalized causal vertex family at every fixed finite
vertex order on the compact, off-shell local-polynomial domain. This goes
beyond constructing T2 or a selected T3 coefficient. It does not construct
all-loop QFT, prove a nonlinear Slavnov identity or promote E5/A5.

The structural reason is that a connected one-loop graph has exactly one
cycle, with rooted trees attached. Independent cycle and bridge difference
coordinates form an integral linear isomorphism. Tensoring the qualified
extended cycle with the complete Feynman bridge distributions therefore
defines the graph at its proper and total diagonals. All such graphs use the
same core normalizations and source/jet rules. A disconnected graph retains
at most ONE loop in total. Higher-loop terms cannot return to this sector
when additional cross edges are added.

This supplies proper-subdiagonal compatibility and causal factorization in
the declared domain. The inherited graded Wick expansion, balanced multiplet
jets, field-independent contracted kernels and full distributional derivatives
supply graded permutations, translation, field/source independence and the
off-shell AWI together. K C_F=i delta is retained, not replaced by an off-shell
free-equation quotient. The proof includes correlated source/auxiliary partners;
it does not assert that nonlinear Q commutes with the time-ordering map.

The crucial new subtraction qualification is

 FP(C_t B_t)=C_R B0+sum_(j>=1) A_j B_j,
 lim[(C_t-D_t) B_t]=C_R B0,

where D_t is the divergent local cycle part and B_t is its COMPLETE attached
heat forest. Subtracting D_t B0 instead of D_t B_t misses finite terms. For a
massive scalar bridge B1=-c+cM/(Q+M), the missed term includes a nonlocal
propagator along the bridge; it is not merely a total-diagonal contact. The
actual raw temporal vector bridge similarly retains a width-dependent
longitudinal term. The scalar M=0 and vector w=1 limits are explicitly
insensitive to their respective nonlocal components, not evidence for their
absence in the actual symbolic reference domain.

The constructed connected-product prescription subtracts the local cycle
counterterm with ALL its finite-cutoff attachments before the limit. This is
an explicit compatible forest extension of the existing core normalization.
It is not the naive finite part of an unsubtracted whole graph, nor a claim
that an underdefined historical prescription already implemented it. No free
finite number is fitted, and no member is adopted as a physical scheme.
Existing kappa, b0 and IR ambiguities remain distinct. One-vertex divergent
partners are treated the same way before CWB1 beta1 supplies its finite
initial dictionary; the singlet tadpole is not discarded.

The actual frozen GF vertices B0_0*C14*partial0(ub14) and
B0_0*partial0(C14)*ub14, with their real ordered Green residues, give a
nonzero carrier -g10^2/2. The actual B0_0 bridge is
(2/3)[1/Q+(eta_H-1)q0^2/Q^2] after the specified Euclidean substitution.
This establishes action support for a power-sensitive topology. It is NOT
a newly measured summed ghost/vector amplitude. The independently checked
radial basis is I_t=1/(256 pi^2 t); diagram phases, multiplicities and other
families would still be needed for any complete physical coefficient.
No missing vector-quartic tensor has been inferred or integrated.

Two distinct complete diagnostic graph constructions agree through six
labeled vertices: edge multisets/connectivity/leaf removal versus explicit
cycles, rooted forests, Prüfer trees and component partitions. Per route,
10,933 connected one-loop coordinate maps were checked by determinants
versus explicit inverse reconstruction. Complete finite graph sets include
both parallel-edge cycles and disconnected forests, with global loop grading.
At six vertices there are10,140 connected one-loop graphs,17,912 graphs with
one total loop and2,932 forests. These are untyped mathematical diagnostics,
not independently measured Spin(10) amplitudes or project-coverage percentages.
The all-finite-order statement rests on the unique-cycle/tensor proof, not
extrapolation from these counts.

Independent verification uses closed cycle/rooted-forest counts, component
recursions, a nontrivial core-coordinate fixture, noncommuting two-branch
subtraction matrices, rational bridge jets and a distinct90-digit Schwinger
integral. Native radial/angle checks at45/75 digits agree within1e-25. The
finite matrix controls distinguish lost heat jets and changed multiplication
order; the source fixture distinguishes differentiation before restriction.
No sensitive negative control is claimed where its parameter limit is zero.

The cycle-normalization supplement additionally enumerated complete connected
quadratic Wick pairings through six vertices, with the raw one-vertex case
separated from T1=id. It recovers1/(2n) for an even cycle and the doubled odd
supertrace, with the ghost sign produced by Wick ordering itself. Using
W=-i hbar log Z and C_F=iG gives the inherited Born factor -i hbar/(2n) on
(GM)^n, M=-V. A second ghost-loop minus, missing bosonic1/2 or covariance i
would fail. This supplies the general polarization/multiplicity bridge to
the heat-matched core amplitudes, retaining the separate loop boundary phase.

A scope review also closed a finite-jet gap before qualification. The displayed
HMM1 formula covered J<=2 for the actual action; arbitrary fixed balanced
operator derivatives can require J>2. FINITE_JET_DOMAIN.md proves the general
correction (-1)^(J+1)*a^J/(2J), before angular normalization, with the existing
logarithmic and complete Duhamel finite jets retained. Extra vertex momentum
polynomials do not worsen the soft degrees. The same uniform boundary proof
therefore extends after finitely many additional ultraviolet subtractions.
The independent supplement checks J=1..8 by gamma/beta versus rational products
and80 heat-jet selections. This satisfies the original finite operator domain
without adding physical EFT couplings or claiming a larger unlabelled IR domain.

Completed main validation_receipt.json SHA256
`c645bc339bf4309b2e6f3676d3b3483d812c06cd7c67f889052f9404cf9bcdea`.
Completed cycle_receipt.json SHA256
`cd9cf70aa8f8c4e4e89458b333fff9db9a85b43f166b7e1f5ae96add41ac320a`.
Completed jets_receipt.json SHA256
`6e7fd344c8f62bda59a9d2795c821c0f2a2124a354a19a90489ef9532c613fd9`.
49initial/54main/64cycle/74jets bindings. Native2.677995/2.429307seconds after imports;
main verifier0.253960s/cycle0.286306s/jets0.310345s. Largest native private sample189,501,440B,
NOT true peak. All120/180s,8GiB sampled,350MiB launch-commit and4MiB package
limits respected; exact completed captures retained. No failed scientific
worker or verifier. A prelaunch schema query used a nonexistent gf key and
patch-context attempts failed before mutation; these were corrected without
scientific execution or altered acceptance. Broad read output was narrowed.

Track B: the meaningful gain is a complete structural assembly and a specific
ordering error it prevents, rather than another large coefficient expansion.
The forest mechanism and causal method are established QFT mathematics;
the model-specific work is matching their actual mixed/graded inputs and
normalizations. All routes share action data, software and AI author. No
outside scientist, experiment, mechanistic access or Lean certificate is
claimed. The scalar forest theorem's independent-regulator hypotheses were
not silently assumed; the one-loop tensor construction is explicit here.

Remaining limitations: the common family is formal, fixed-reference and
compactly switched, through one total loop. Generic local vertex products
exist in that domain; compatibility of multiple nonlinear Ward/equivalence
insertions is a further condition. No all-loop convergence, physical-state
positivity/unitarity, global constant-vacuum limit or unlabelled constant-chain
causal equivalence follows. The separate constant-insertion coefficient
results retain their earlier scope. Gamma_ref[A], its phase/member ambiguity,
full quantum measure/source equivalence and protected E5/A5 obligations remain.

NEXT: compare the original W1-W7/A1-A5 requirements and the actual normalized
family with the QAP theorem, proving the graded mixed-field version and its
correct dimension bound rather than importing a scalar formula. Relate its
insertion normalization to the already qualified finite Slavnov primitive.
Do not repeat T4/T5 examples merely to extend graph counts. Physical scalar
control, unfrozen Yukawas and incomplete gauge matching remain independent
priorities; no missing flavor input is selected to rescue the benchmark.

State113/34of39/seven flags false unchanged. HB1/C5blocked,C1_GSuncalculated,
flavorhumanpaused,quartetFAIL3960/648,custodyexit2/seven. Scalar140%/1.94%/20.27%
diagnostics retain their distinct meanings. No old evidence, action, state,
source functional, policy, physical benchmark/scheme, branch, remote or
publication/outreach changed. Execution validation is not director acceptance.
