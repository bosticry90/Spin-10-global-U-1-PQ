from pathlib import Path
from hashlib import sha256
from math import factorial
import json,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent

def pairings(n,odd):
 seq=[(i,j) for i in range(n) for j in range(2)];count=total=0
 def walk(active,edges,sign):
  nonlocal count,total
  if not active:
   adj=[set() for _ in range(n)]
   for a,b in edges:adj[a].add(b);adj[b].add(a)
   seen={0};todo=[0]
   while todo:
    a=todo.pop()
    for b in adj[a]-seen:seen.add(b);todo.append(b)
   if len(seen)==n:count+=1;total+=sign
   return
  i=active[0];a,ty=seq[i]
  for place,j in enumerate(active[1:],start=1):
   b,tt=seq[j]
   if a==b and n!=1:continue
   if odd and ty==tt:continue
   sg=sign
   if odd:
    # Sequence is a,C at every vertex. The ordered reference a-to-C is -G.
    sg*=(-1)**(place-1)*(-1 if ty==0 else 1)
   walk(tuple(k for k in active if k not in (i,j)),edges+[(a,b)],sg)
 walk(tuple(range(2*n)),[],1)
 return count,total

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'cycle_preparation.json').read_bytes())
 for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 mainreceipt=json.loads((O/'validation_receipt.json').read_bytes());assert mainreceipt['execution_state']=='COMPLETED'
 rows=[]
 for n in range(1,7):
  bc,bs=pairings(n,False);gc,gs=pairings(n,True)
  expected=1 if n==1 else 2**(n-1)*factorial(n-1)
  assert bc==bs==expected and gc==factorial(n-1) and gs==-factorial(n-1)
  boson=s.Rational(bs,2**n*factorial(n));ghost=s.Rational(gs,factorial(n))
  assert boson==s.Rational(1,2*n) and ghost==-s.Rational(1,n)
  # W=-i hbar logZ; use exact I, never machine complex powers.
  bw=s.simplify(-s.I*s.I**(2*n)*boson);gw=s.simplify(-s.I*s.I**(2*n)*ghost)
  assert bw==s.I*(-1)**(n+1)/(2*n) and gw==s.I*(-1)**n/n
  assert s.simplify(bw-(-s.I/(2*n))*(-1)**n)==0
  assert s.simplify(gw-(-s.I/(2*n))*(-2)*(-1)**n)==0
  rows.append({'n':n,'bosonic_connected_pairings':bc,'odd_connected_pairings':gc,'odd_signed_sum':gs,'boson_W_coefficient':str(bw),'odd_pair_W_coefficient':str(gw)})
 assert rows[1]['boson_W_coefficient']=='-I/4'
 assert s.Rational(1,2)!=1 and (-1)*(-1)!=-1
 n=3;correct=-s.I*s.I**(2*n)/(2*n);wrong=-s.I*s.I**n/(2*n);assert s.simplify(correct-wrong)!=0
 result={'schema':'CAUSAL_ONE_LOOP_SEWING_CYCLE_NORMALIZATION_V1','execution_state':'COMPLETED',
 'scientific_disposition':'WICK_MULTIPLICITIES_AND_ODD_ORIENTATION_MATCH_GENERAL_BORN_SUPERTRACE_NORMALIZATION',
 'scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],
 'main_receipt_sha256':sha256((O/'validation_receipt.json').read_bytes()).hexdigest(),
 'complete_pairing_censuses':rows,'arbitrary_n_argument':'unique_cycle_and_permutation_count_in_CYCLE_NORMALIZATION.md',
 'raw_n1_is_separate_input_dictionary':True,'authority_changed':False,'full_QAP_E5_A5_proved':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
