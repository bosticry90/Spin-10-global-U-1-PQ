"""COS1 graph exhaustion, integral coordinates and ordered heat forests."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement,permutations,product
from collections import Counter,deque
import json,gzip,sys,time,threading,os
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent

def canonical(edges):return tuple(sorted(tuple(sorted(e)) for e in edges))
def components(n,edges):
 adj=[set() for _ in range(n)]
 for a,b in edges:adj[a].add(b);adj[b].add(a)
 unseen=set(range(n));out=[]
 while unseen:
  root=min(unseen);todo=[root];unseen.remove(root);comp=[]
  while todo:
   a=todo.pop();comp.append(a)
   for b in adj[a]&unseen:unseen.remove(b);todo.append(b)
  out.append(tuple(sorted(comp)))
 return out

def core_and_parents(n,edges):
 adj=[[] for _ in range(n)]
 for a,b in edges:adj[a].append(b);adj[b].append(a)
 degree=list(map(len,adj));todo=deque(i for i,d in enumerate(degree) if d==1)
 while todo:
  a=todo.popleft();degree[a]=0
  for b in adj[a]:
   if degree[b]:
    degree[b]-=1
    if degree[b]==1:todo.append(b)
 core=tuple(i for i,d in enumerate(degree) if d)
 assert len(core)>=2 and all(degree[i]==2 for i in core)
 parents={};seen=set(core);todo=deque(core)
 while todo:
  a=todo.popleft()
  for b in adj[a]:
   if b not in seen:seen.add(b);parents[b]=a;todo.append(b)
 assert len(seen)==n
 return core,parents

def determinant(M):
 a=[row[:] for row in M];n=len(a);den=1;sign=1
 if n==0:return 1
 for k in range(n-1):
  if a[k][k]==0:
   j=next(i for i in range(k+1,n) if a[i][k]);a[k],a[j]=a[j],a[k];sign=-sign
  pivot=a[k][k]
  for i in range(k+1,n):
   for j in range(k+1,n):
    num=a[i][j]*pivot-a[i][k]*a[k][j];assert num%den==0;a[i][j]=num//den
  for i in range(k+1,n):a[i][k]=0
  den=pivot
 return sign*a[-1][-1]

def coordinates(n,core,parents,role):
 root=min(core);columns=[i for i in range(n) if i!=root]
 descriptors=[(i,root) for i in core if i!=root]+sorted(parents.items())
 A=[[int(i==a)-int(i==b) for i in columns] for a,b in descriptors]
 if role=='primary':assert abs(determinant(A))==1
 else:
  row_for={a:j for j,(a,b) in enumerate(descriptors)};xs={root:[0]*(n-1)}
  for i in core:
   if i!=root:xs[i]=[int(j==row_for[i]) for j in range(n-1)]
  def fill(i):
   if i not in xs:xs[i]=[a+int(j==row_for[i]) for j,a in enumerate(fill(parents[i]))]
   return xs[i]
  B=[fill(i) for i in columns]
  assert all(sum(A[i][k]*B[k][j] for k in range(n-1))==int(i==j) for i in range(n-1) for j in range(n-1))

def brute(n):
 pairs=list(combinations(range(n),2));out=set()
 for e in range(n+1):
  for edges in combinations_with_replacement(pairs,e):
   if any(v>2 for v in Counter(edges).values()):continue
   if e-n+len(components(n,edges))<=1:out.add(edges)
 return out

def trees(n):
 if n==1:return {()}
 out=set()
 for word in product(range(n),repeat=n-2):
  deg=[1]*n
  for i in word:deg[i]+=1
  edges=[]
  for a in word:
   leaf=next(i for i,d in enumerate(deg) if d==1);edges.append((leaf,a));deg[leaf]-=1;deg[a]-=1
  a,b=[i for i,d in enumerate(deg) if d==1];edges.append((a,b));out.add(canonical(edges))
 return out

def cycles(n):
 out=set()
 for k in range(2,n+1):
  for core in combinations(range(n),k):
   outer=[i for i in range(n) if i not in core];cycle_edges=[]
   if k==2:cycle_edges=[[(core[0],core[1])]*2]
   else:
    for tail in permutations(core[1:]):
     if tail[0]>tail[-1]:continue
     seq=(core[0],)+tail;cycle_edges.append(list(zip(seq,seq[1:]+seq[:1])))
   forests=[]
   for pp in product(range(n),repeat=len(outer)):
    parents=dict(zip(outer,pp));valid=True
    for i in outer:
     seen=set();j=i
     while j not in core:
      if j in seen:valid=False;break
      seen.add(j);j=parents[j]
     if not valid:break
    if valid:forests.append(list(parents.items()))
   for cyc,forest in product(cycle_edges,forests):out.add(canonical(cyc+forest))
 return out

def partitions(n):
 def rec(i,blocks):
  if i==n:yield tuple(tuple(b) for b in blocks);return
  for j in range(len(blocks)):
   blocks[j].append(i);yield from rec(i+1,blocks);blocks[j].pop()
  blocks.append([i]);yield from rec(i+1,blocks);blocks.pop()
 yield from rec(0,[])

def constructed(n,library):
 out=set()
 for blocks in partitions(n):
  for cyclic in [-1]+[i for i,b in enumerate(blocks) if len(b)>1]:
   choices=[library[len(block),int(i==cyclic)] for i,block in enumerate(blocks)]
   for selected in product(*choices):
    edges=[]
    for block,graph in zip(blocks,selected):edges.extend((block[a],block[b]) for a,b in graph)
    out.add(canonical(edges))
 return out

def matrix(j,k):return s.Matrix([[2+j+k,1-j],[k+1,3-j+k]])
def fp(expr,t,ell):return expr.applyfunc(lambda z:s.expand(z).coeff(t,0).coeff(ell,0))
def convolution(left,right,J):
 out=[s.zeros(2) for _ in range(J+1)]
 for i in range(J+1):
  for j in range(J+1-i):out[i+j]+=left[i]*right[j]
 return out

def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'preparation.json').read_bytes())
 for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 library={};census=[];coordinate_checks=0
 for n in range(1,7):
  if role=='replay':library[n,0]=trees(n);library[n,1]=cycles(n);graphs=constructed(n,library)
  else:graphs=brute(n)
  if n==3:
   assert ((0,1),(0,1),(1,2)) in graphs and ((0,1),(0,2),(1,2)) in graphs
  if n==4:
   assert ((0,1),(0,1),(2,3),(2,3)) not in graphs
  ct=cu=f=u=0;hist=Counter()
  for edges in graphs:
   comps=components(n,edges);L=len(edges)-n+len(comps);assert L in [0,1]
   if L==0:f+=1
   else:u+=1
   if len(comps)==1:
    if L==0:ct+=1
    else:
     cu+=1;core,parents=core_and_parents(n,edges);hist[len(core)]+=1;coordinates(n,core,parents,role);coordinate_checks+=1
  if role=='replay':assert ct==len(library[n,0]) and cu==len(library[n,1])
  census.append({'n':n,'forests':f,'one_loop_graphs':u,'connected_trees':ct,'connected_one_loop':cu,
   'core_sizes':dict(sorted(hist.items())),'graph_set_sha256':sha256(json.dumps(sorted(graphs),separators=(',',':')).encode()).hexdigest()})
 # Direct Laurent multiplication versus triangular ordered convolution.
 t,ell=s.symbols('t ell');A1,A2,F,L=[matrix(i,5) for i in range(4)];jet_rows=[]
 for m in range(5):
  polynomials=[[matrix(j,k) for j in range(3)] for k in range(m)]
  if role=='primary':
   B=s.eye(2)
   for jets in polynomials:B=B*sum((t**j*jets[j] for j in range(3)),s.zeros(2))
   D=A2/t**2+A1/t+L*ell;C=D+F
   bare=fp(C*B,t,ell);ren=fp((C-D)*B,t,ell);B0=B.subs(t,0)
  else:
   jets=[s.eye(2),s.zeros(2),s.zeros(2)]
   for branch in polynomials:jets=convolution(jets,branch,2)
   B0=jets[0];bare=F*jets[0]+A1*jets[1]+A2*jets[2];ren=F*jets[0]
  assert ren==F*B0
  if m:assert bare!=ren
  jet_rows.append({'branches':m,'bare':list(bare),'renormalized':list(ren)})
 assert A1*matrix(1,0)!=matrix(1,0)*A1
 # Retrieve the real action carrier and raw propagators; no new physical pole.
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
 targets=[['B0_0','C14','ub14__0'],['B0_0','C14__0','ub14']]
 selected=[next(v for v in data['gauge_fixing_density'] if v['word']==w) for w in targets]
 g=s.symbols('g10');coefs=[s.sympify(v['coefficient']) for v in selected]
 PK=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
 ref=json.loads((PK/'frozen_a10_e5_full_hessian'/(role+'.json')).read_bytes())['retained_reference'];names=ref['field_order']
 green={(i,j):s.sympify(v) for i,j,v in ref['reference_Green_raw_C3']['entries']}
 p=s.symbols('p0_ref0 p0_ref1 p0_ref2 p0_ref3');P=p[0]**2-sum(z*z for z in p[1:]);ic,ia,ib=[names.index(v) for v in ['C14','ub14','B0_0']]
 carrier=s.factor(coefs[0]*coefs[1]*(P*green[ic,ia])*(P*green[ia,ic]));assert carrier==-g*g/2
 q=s.symbols('q0 q1 q2 q3',real=True);Q=sum(z*z for z in q);w=s.symbols('eta_H');sub=dict(zip(p,[s.I*q[0],*q[1:]]))
 bridge=s.cancel(green[ib,ib].subs(sub));expected=s.Rational(2,3)*(1/Q+(w-1)*q[0]**2/Q**2)
 assert s.cancel(bridge-expected)==0
 c,M,z=s.symbols('c M z',positive=True)
 if role=='primary':b1=s.diff(s.exp(-c*t*z)/(z+M),t).subs(t,0);v1=s.diff(s.exp(-c*t*Q)*bridge,t).subs(t,0)
 else:b1=-c*z/(z+M);v1=-c*Q*bridge
 assert s.cancel(b1-(-c+c*M/(z+M)))==0
 assert s.cancel(v1+s.Rational(2,3)*c*(1+(w-1)*q[0]**2/Q))==0
 assert s.cancel(b1+c)!=0 and s.cancel((b1+c).subs(M,0))==0
 assert s.cancel((v1+s.Rational(2,3)*c).subs(w,1))==0
 J,B=s.symbols('J B');fixture=J*B*b1
 assert s.diff(fixture,J).subs(J,0)==B*b1 and s.diff(fixture.subs(J,0),J)==0
 nums=[];digits=45 if role=='primary' else 75
 with mp.workdps(digits):
  for tt in [mp.mpf(1),mp.mpf(1)/2,mp.mpf(3)/2]:
   if role=='primary':rad=mp.quad(lambda r:r*mp.exp(-4*tt*r*r),[0,1,mp.inf])/(32*mp.pi**2)
   else:
    avg=mp.quad(lambda a:mp.sin(a)**2*mp.cos(a)**2,[0,mp.pi])/mp.quad(lambda a:mp.sin(a)**2,[0,mp.pi])
    rad=avg*mp.gamma(1)/(8*mp.pi**2*2*(4*tt))
   expected=1/(256*mp.pi**2*tt);assert abs(rad-expected)<mp.mpf('1e-35')
   nums.append([mp.nstr(tt,12),mp.nstr(rad,digits)])
 result={'schema':'CAUSAL_ONE_LOOP_SEWING_NATIVE_V1','role':role,'census':census,'coordinate_graphs_checked':coordinate_checks,
 'ordered_finite_parts':str(jet_rows),'actual_GF_rows':selected,'actual_power_carrier':str(carrier),
 'actual_raw_vector_bridge_E':str(s.factor(bridge)),'scalar_bridge_first_heat_jet':str(s.factor(b1)),
 'radial_values':nums,'native_precision':digits,
 'controls':{'parallel_two_cycle_retained':True,'global_loop_projection':True,'bridge_Jacobian_unimodular':True,
 'finite_heat_tree_jets_nonzero':True,'matrix_order_sensitive':True,'source_before_zero':True,
 'scalar_massless_nonlocal_control_insensitive':True,'vector_w1_nonlocal_control_insensitive':True},
 'new_complete_Spin10_tensor_measured':False,'full_QAP_E5_A5_or_physical_scheme_proved':False,
 'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
