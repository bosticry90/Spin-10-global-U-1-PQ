# COS1 finite-jet domain closure supplement

Scope review after the graph/cycle checks identified a genuine proof obligation:
the HMM1 displayed power formula stops at the retained dimension-four action's
quartic divergence, whereas COS1 permits specified finite composite-operator
degrees and balanced internal jets. External total derivatives alone commute
with an extension; higher BALANCED derivatives can raise its ultraviolet degree.
Do not silently transfer the action-only formula to that larger operator domain.

This supplement closes that obligation without adopting higher-dimensional
physical interactions. General local operators are external insertion arguments;
the physical action/parameter ring remains unchanged. At every specified finite
degree the number of additional local subtraction terms is finite.

Each finite local field jet multiplies a free component propagator by a finite
momentum polynomial. It introduces no new denominator and does not worsen its
infrared singular order. All vertices here carry compact/Schwartz labels. The
MLB1 node proper-time powers and Gaussian-moment bounds therefore still apply:
extra polynomial moments only add nonnegative numerator powers and a finite
number of test-function seminorms. No new unlabelled zero-transfer mass chain,
bare massless double inverse or multiple constant tangent is admitted this way.

In the ultraviolet only the highest polynomial symbol degree changes. Subtract
the FINITE homogeneous expansion from that highest degree through degree-4;
the remaining symbol again has the same r^-5 bound. The joint soft completion,
uniform complex-metric estimate and Laurent-boundary argument are unchanged.
The Cauchy circle can still avoid the other integer poles. Coordinate jets and
their polynomial momentum multipliers commute with the final boundary map.

Here is the additional radial subtraction explicitly. For an angularly averaged
homogeneous term r^(2J-4), J>=1 integer, and the SAME infrared-safe root weight
[a/(r^2+a)]^z,

 A_J(z)=a^J Gamma(J) Gamma(z-J)/(2 Gamma(z)).

Its finite value at z=0 is (-1)^J a^J/(2J), since
Gamma(z-J)/Gamma(z)=1/product_(l=1..J)(z-l). The positive-heat radial integral
is Gamma(J)/[2(ct)^J] and has zero finite constant. Thus the heat-minus-analytic
local correction, before the angular factor1/(8pi^2), is

                  (-1)^(J+1) a^J/(2J).

For J=1,2 these are exactly HMM1's +a/2 and -a^2/4. J>2 is the required finite
extension, not an omitted power term. Using a common hard radius R subtracts
R^(2J)/(2J) from both finite parts and leaves this correction unchanged.
The auxiliary a cancels in the matched coefficient, not a new physical scale.

The J=0 logarithmic term is the existing
[log(mu^2/a)-gamma_E-log c]/2. For an explicitly vanishing heat vertex term
t^j r^(2J-4), j>0, its only extra finite radial contribution is
Gamma(J)/(2c^J) when j=J>0. All other such powers are either divergent subtractions
or vanish in the finite limit. This is the same complete Duhamel-jet rule as
HMM1, now at arbitrary fixed finite UV degree. At a fixed local/interaction
order only finitely many heat jets contribute; none are silently truncated.
Odd radial powers from odd homogeneous numerators have zero angular integral.

Consequently each required finite contracted-species/jet tensor has a common
heat-matched extension. Graded relabeling and total external momentum identities
are retained by applying this ONE linear operation to the complete numerator,
not choosing separate constants for related jets. All core premises of the
COS1 construction hold on its declared finite local-operator domain. For the
actual renormalizable action/first variation, J<=2 remains sufficient; the
larger normalization space does not add physical EFT couplings or activate C5.

Supplement acceptance: independently compare the gamma/beta radial expression
with the finite rational product at J=1..8, hard-radius cancellation, and finite
ordered heat-jet selection. Check J=1,2 recover the authenticated old formula,
and omission of J=3 loses a nonzero a^3/6 term. The arbitrary-J conclusion is
the displayed gamma recursion and polynomial-symbol proof, not extrapolation
from eight examples. Bind all completed main/cycle receipts and frozen sources
before execution.180s verifier,8GiB sampled,350MiB floor,4MiB entire package;
exact arithmetic, no physics/normalization/tolerance change. Preserve failures.
No all-loop QAP, nonlinear Ward compatibility or E5/A5 is inferred.
