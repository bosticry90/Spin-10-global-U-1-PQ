# COS1 — one-loop causal graph sewing, including the power-contact subtraction

Prospective until native routes and separate verification complete. The theorem
below uses the inherited qualified component extensions; it does not reprove
their analytic domain or promote them to a physical quantum scheme.

## 1. The graph class, loop grading and the actual reference

Expand finite local vertices by graded Wick contractions of the fixed643-field
C_F=iG_F. Sources/backgrounds are external uncontracted coefficients. Give each
ordinary field jet its original parity; a contraction is even. No self edges
occur in T1-normalized products; retain the CWB1 local beta1 input dictionary
when comparing heat tadpoles, including its nonzero singlet quartic direction.
In a raw heat graph a one-vertex self loop also has its divergent local part;
subtract that part with its attached heat trees by section3 before using beta1
for the finite input normalization. Normal ordering deletes neither its divergent
counterterm partners nor its finite physical operator direction.

For a graph with N labeled vertices, E cross edges and C connected components,
L=E-N+C is its total loop number, including isolated components in C. Retain
L<=1. Do NOT truncate by E alone or call this an hbar truncation of Tn: a connected
tree at n vertices has n-1 contractions and a one-loop graph n contractions.
Adding cross edges cannot lower L. Hence omitted higher-loop subgraphs cannot
return to this sector during causal products; projecting L<=1 after gluing is
consistent. A disconnected retained graph has forests and at most one unicyclic
component, not one loop independently in every component.

Every connected graph with L=0 is a tree. With L=1, repeatedly remove leaves.
The remaining nonempty graph is a unique cycle. Its length k is at least2;
k=2 is TWO parallel edges, not two different cycles. All other edges are bridges
forming a forest rooted at the cycle vertices. No other parallel multiplicity
or overlapping loop divergence is possible at L=1. These statements follow
from the first Betti number E-N+1=1, independently of field types or numerators.
Actual zero contractions simply delete typed graph terms; they create no new
topologies. Matrix/odd factors and derivative labels remain on their edges.

## 2. Coordinates provide a global extension of every attached tree

For a cycle core S choose a cycle vertex a. Coordinates on the connected graph,
modulo its common translation, can be chosen as

 u_i=x_i-x_a for i in S except a;
 v_j=x_j-x_parent(j) for every noncore vertex j.

The inverse is x_i=x_a+u_i on the core and
x_j=x_parent(j)+v_j along each rooted tree. Successive leaf elimination makes
this an integral triangular linear isomorphism with determinant +/-1. The
core coordinates count k-1 and the bridge coordinates N-k. Thus no distribution
restriction to a singular surface and no missing Jacobian is hidden here.
For a tree choose an arbitrary root and use its edge differences alone.
Disconnected components tensor independently; component translations are free
coordinates and may be combined with a global translation by another unimodular
change. Uncontracted smooth field/source factors multiply the final kernels.

Let R_H(C)(u) be the inherited heat-matched extended cycle distribution, using
CSP1 when k=2 and HMM1/MLB1 at any fixed finite k. Define the connected kernel

 R_H(G)=pullback[ R_H(C)(u) tensor product_(bridges e) C_F,e(v_e) ].

For a tree use only the tensor product of its full bridge distributions.
Tensor products of tempered distributions exist; pullback by this invertible
linear map exists. No wavefront transversality at a partial diagonal is guessed.
Cycle cores have the inherited finite scaling degree and Feynman orientation.
Derivatives include the complete contact terms, not derivatives of pointwise
off-diagonal values. K C_F=i delta remains a nonzero tree contact.

This formula extends all partial and total diagonals at once for the graph.
A proper subset either contains the whole unique cycle, in which case its
extension is exactly the same R_H(C) sewn to a smaller forest, or contains no
whole cycle, in which case its internal graph is a forest with already defined
distributional edge coordinates. Nested collisions just tensor/sew the same
factors in a different order. There is no overlapping second loop to require
a new independent subgraph normalization in this sector.

## 3. Why a bare whole-graph finite part is the wrong gluing operation

This is essential even at T3. Write the COMPLETE regulated cycle expansion as

 C_t=sum_(j=1..J) t^-j A_j + L log(1/(t mu^2)) + C_R + o(1),

where A_j,L are local distributions on its core diagonal. For renormalizable
action/first-variation vertices the inherited dimension bound gives J<=2;
arbitrary specified finite composite degree may require more jets, never silent
truncation. Attach the full regulated forest B_t=B0+tB1+... before subtraction.
In fixed tensor/matrix order,

 FP(C_t B_t)=C_R B0+sum_(j=1..J) A_j B_j.

Thus FP is not multiplicative. The subtraction implementing the core prescription
in the connected product is D_t B_t with
D_t=sum t^-j A_j+L log(1/(t mu^2)), not D_t B0. Consequently

 lim[(C_t-D_t) B_t]=C_R B0

as tensor distributions in the independent coordinates. This follows from
convergence of the renormalized core, convergence of the regulated bridge
distributions and continuity of tensor products. For several bridge edges,
B_j is the sum of every ordered product of their heat jets of total order j.
The same subtraction is the graph obtained by inserting the local divergent
cycle counterterm with all its tree/source partners at the finite cutoff.
It introduces no independently fitted finite coefficient.

The required convention is an explicit connected-product forest subtraction
extending the existing core normalization. It is NOT a claim that an undeclared
historical bare-FP convention already included these terms, nor physical adoption
of a unique renormalization scheme. The W1-W7 admissible class allows a constructed
compatible member. kappa and every existing core finite freedom remain symbolic;
neither b0 nor an IR constant is fixed by this extension.

The missed terms need not be supported only on the TOTAL graph diagonal.
For an actual positive reference scalar bridge, Q=p_E^2, M=Mref_squared>0,

 B_t=e^-ctQ/(Q+M),
 B1=-c Q/(Q+M)=-c+cM/(Q+M).

A quadratic core divergence A1/t produces A1 B1 in the bare FP. The second
term is nonlocal along the remaining bridge, while local on the core diagonal.
It can therefore spoil factorization at a proper diagonal. For a raw temporal
vector bridge the actual Euclidean continuation gives

 G00,E=(2/3)[1/Q+(w-1)q0^2/Q^2],
 B1=-(2c/3)[1+(w-1)q0^2/Q].

The longitudinal part is likewise nonpolynomial for generic symbolic w.
At w=1 this particular nonlocal control is insensitive; do not hide it by a
convenient width. At M=0 the scalar example loses its nonlocal part too. The
full subtraction remains necessary in all cases where the local part survives.

## 4. Actual action-supported carrier and independent nonzero control

The frozen GF density contains both
 +(i sqrt(2) g10/2) B0_0 C14 partial0 ub14 and
 -(i sqrt(2) g10/2) B0_0 partial0 C14 ub14.
The actual raw Green entries are G_C14,ub14=1/P and G_ub14,C14=-1/P.
Their ordered coefficient/residue carrier is -g10^2/2, nonzero. Two contracted
ghost legs have a q0^2/Q^2 leading radial basis. The actual B0_0 bridge is the
width-dependent kernel above. This verifies a real action-supported route for
the power-sensitive topology, not a new summed ghost/vector amplitude.
Momentum derivative phases, diagram multiplicities and other families must be
included before interpreting a physical coefficient; no such tensor is claimed.

The radial basis itself is unambiguous:

 I_t=integral d4q/(2pi)^4 e^-4tQ q0^2/Q^2=1/(256 pi^2 t).

Angular averaging gives q0^2->Q/4. An independent Schwinger representation gives
I_t=integral_0^infinity s ds/[32pi^2(s+4t)^3], with the same result. A third
bridge e^-2tQ/(Q+M) makes the bare finite term -2 Q/[256pi^2(Q+M)] nonzero;
subtracting the local core divergence with that SAME finite heat bridge removes
it. This control is a specified radial/bridge kernel, not a complete measured
Spin(10) counterterm. Agreement checks the forest ordering and normalization.

## 5. One finite-order vertex-functional map and its axioms

Sum the above distributions over all signed Wick matchings with total L<=1,
retaining the ordinary symmetry/factorial weights from the exponential of
the EVEN cross-contraction operator. For disconnected graphs tensor their
components and keep at most one unicyclic component. At fixed n and finite
vertex degrees this sum is finite; no convergence of an infinite perturbation
series is asserted. This defines Tn^[<=1] at every fixed finite n, with T0=1
and T1=id. The two-vertex member is the same CSP1 product.

On a strict causal partition the Feynman cross edges equal the appropriately
ordered W contractions. A singular cycle cannot cross that partition at a
nonempty coincident core: its coincident vertices would belong to both ordered
groups. Cross-group pieces therefore use their ordinary off-core boundary;
cycles wholly in one group retain exactly the lower-order R_H(C). The tensor
formula then gives causal factorization with the same loop projection. Independent
tree coordinates prove agreement on intersections of causal patches, including
proper collisions inside either group. No new partial-diagonal coefficient is
chosen by a desired Ward cancellation.

Relabeling vertices changes the Wick sign and tensor coordinates coherently.
Each common core extension has its inherited graded permutation convention;
the bridge tensor and unimodular pullback preserve it. These are equality of
distributions, not just pointwise equality away from diagonals. Difference
coordinates and translating local labels give translation covariance.

Field independence follows because the extended contracted species/jet kernel
is fixed independently of uncontracted fields; graded differentiation of the
Wick expansion differentiates its residual factors and matches the differentiated
inputs. For jets, use the CSP1 equivariant graded balanced-field decomposition
at EACH vertex. Extend balanced contracted jets and differentiate full
distributions for total derivatives. The tensor/pullback operations are linear
and commute with the full product rule, including derivatives acting on both
core and bridge coordinates. Hence the off-shell AWI and integration by parts
hold under compact switching. Source derivatives precede source restriction.
No free-EOM quotient or erasure of bridge delta currents is used.

This prescription constructs a normalized ONE-LOOP causal vertex family on the
fixed reference and compact local domain, conditional on the explicitly reused
qualified core/distribution inputs. The core 1PI amplitudes match the existing
heat finite-part convention, using full local power matching and separate
Born/connected/1PI phases. Connected products match its correlated forest
extension, NOT the naive finite part of the unsubtracted entire bare graph.
Literal finite positive heat is never rotated as a Lorentzian S' distribution.

## 6. Completeness of the topology reduction and limits

The unique-cycle theorem proves all finite-n graph coverage. For validation,
complete labeled graphs through n=6 are generated by two distinct methods.
Connected trees number n^(n-2) for n>=2. A cycle core of size k>=3 has
(k-1)!/2 unoriented labeled cycles; a two-core has one parallel-edge cycle.
For a prescribed root set k, attached forests number k*n^(n-k-1) when k<n,
and1 when k=n. These formulas and component recursions give independent census
checks. Finite counts do not replace the graph/distribution proof.

This does not invoke the general multi-parameter forest theorem without checking
its hypotheses: one-loop uniqueness avoids overlapping independent cycle
subtractions and is proved directly above. Standard primary comparisons are
Dütsch–Fredenhagen–Keller–Rejzner, https://arxiv.org/abs/1311.5424 , especially
its regulated forest recursion; Dütsch–Fredenhagen,
https://arxiv.org/abs/hep-th/0403213 , off-shell AWI; and Brennecke–Dütsch,
https://arxiv.org/abs/0801.1408 , normalized causal-product/QAP prerequisites.
Their scalar statements are not certificates for the actual mixed reference.

The theorem does not prove that nonlinear Q is a derivation of Tn, that its
contact anomaly vanishes, all-loop/multiple-independent-insertion normalization,
physical positivity/unitarity, a measure equivalence or full E5/A5. First source/
Q insertion vertices have a common prescription, but nonlinear Ward defects
must still be evaluated or controlled by an applicable theorem. Gamma_ref[A],
its phase and historical-member ambiguity are retained. No unlabelled global
constant-insertion/physical-vacuum limit is inferred from compact switching.

Next assess the original one-loop QAP/Slavnov requirements against this actual
normalized family and the already qualified finite primitive, rather than
manufacture more T4/T5 examples. Keep the scalar/gauge/Yukawa physical viability
assessment separate, including its genuine missing flavor inputs.
