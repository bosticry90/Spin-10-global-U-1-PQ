"""COS1 independent closed census, forest subtraction and radial check."""
from pathlib import Path
from hashlib import sha256
from math import comb,factorial
import json,time,threading,os
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'validation_preparation.json').read_bytes())
 for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 a,b=[json.loads((O/(role+'_result.json')).read_bytes()) for role in ['primary','replay']]
 for key in ['census','coordinate_graphs_checked','ordered_finite_parts','actual_GF_rows',
 'actual_power_carrier','actual_raw_vector_bridge_E','scalar_bridge_first_heat_jet','controls']:
  assert a[key]==b[key],key
 # Prüfer/rooted-forest formulas and independent connected-component recurrence.
 T={1:1};U={1:0};F={0:1};G={0:0};total_coords=0
 for n in range(1,7):
  T[n]=1 if n==1 else n**(n-2);bycore={}
  for k in range(2,n+1):
   nc=1 if k==2 else factorial(k-1)//2
   forest=1 if k==n else k*n**(n-k-1)
   bycore[str(k)]=comb(n,k)*nc*forest
  U[n]=sum(bycore.values());F[n]=sum(comb(n-1,k-1)*T[k]*F[n-k] for k in range(1,n+1))
  G[n]=sum(comb(n-1,k-1)*(U[k]*F[n-k]+T[k]*G[n-k]) for k in range(1,n+1))
  row=a['census'][n-1]
  assert row['n']==n and row['connected_trees']==T[n] and row['connected_one_loop']==U[n]
  assert row['forests']==F[n] and row['one_loop_graphs']==G[n] and row['core_sizes']==bycore
  total_coords+=U[n]
 assert U[3]==7 and U[4]==63 and U[5]==722 and U[6]==10140
 assert a['coordinate_graphs_checked']==total_coords==10933
 # A two-loop disconnected graph must be excluded globally, despite each
 # component individually having one loop. E-N+C=4-4+2=2.
 assert 4-4+2==2 and 3-3+1==1
 # Nontrivial bridge/core coordinate fixture, with a nonzero-labeled root.
 core=(2,3);parents={0:1,1:2,4:3,5:4};root=2;cols=[0,1,3,4,5]
 descriptors=[(3,2)]+sorted(parents.items())
 A=s.Matrix([[int(i==x)-int(i==y) for i in cols] for x,y in descriptors])
 assert abs(A.det())==1 and A*A.inv()==s.eye(5) and A.det()**4==1
 # Matrix products in a forest subtraction are ordered, not scalar shortcuts.
 A2=s.Matrix([[1,2],[0,3]]);A1=s.Matrix([[2,0],[1,1]]);C=s.Matrix([[0,1],[2,3]])
 B=[s.Matrix([[1,1],[0,2]]),s.Matrix([[2,0],[3,1]]),s.Matrix([[0,2],[1,1]])]
 D=[s.Matrix([[2,1],[1,0]]),s.Matrix([[1,3],[0,2]]),s.Matrix([[2,0],[1,3]])]
 t=s.symbols('t');bt=sum((B[j]*t**j for j in range(3)),s.zeros(2));dt=sum((D[j]*t**j for j in range(3)),s.zeros(2))
 div=A2/t**2+A1/t;full=(div+C)*bt*dt
 finite=full.applyfunc(lambda z:s.expand(z).coeff(t,0))
 excess=A1*(B[1]*D[0]+B[0]*D[1])+A2*(B[2]*D[0]+B[1]*D[1]+B[0]*D[2])
 assert finite==C*B[0]*D[0]+excess and excess!=s.zeros(2)
 forest=(full-div*bt*dt).applyfunc(lambda z:s.expand(z).coeff(t,0))
 assert forest==C*B[0]*D[0]
 wrong=(full-div*B[0]*D[0]).applyfunc(lambda z:s.expand(z).coeff(t,0))
 assert wrong!=forest and A1*B[1]!=B[1]*A1
 # Positive reference mass gives a genuinely nonlocal missed proper-diagonal term.
 Q,M,c=s.symbols('Q M c',positive=True)
 j1=s.diff(s.exp(-c*t*Q)/(Q+M),t).subs(t,0)
 assert s.cancel(j1+c-c*M/(Q+M))==0
 assert s.denom(s.cancel(j1+c))==M+Q and s.cancel((j1+c).subs(M,0))==0
 w,q0,q1=s.symbols('w q0 q1');longitudinal=(w-1)*q0*q0/(q0*q0+q1*q1)
 assert s.denom(s.cancel(longitudinal))!=1 and longitudinal.subs(w,1)==0
 J=s.symbols('J');assert s.diff(J*j1,J).subs(J,0)==j1 and s.diff((J*j1).subs(J,0),J)==0
 # Actual carrier is not a fitted remainder or summed measured amplitude.
 g=s.symbols('g10');assert s.sympify(a['actual_power_carrier'])==-g*g/2
 assert len(a['actual_GF_rows'])==2 and a['new_complete_Spin10_tensor_measured'] is False
 # Independent Schwinger-parameter representation at90 digits.
 with mp.workdps(90):
  for aa,bb in zip(a['radial_values'],b['radial_values']):
   assert aa[0]==bb[0];tt=mp.mpf(aa[0])
   independent=mp.quad(lambda ss:ss/(32*mp.pi**2*(ss+4*tt)**3),[0,4*tt,mp.inf])
   exact=1/(256*mp.pi**2*tt)
   assert abs(independent-exact)<mp.mpf('1e-70')
   assert abs(mp.mpf(aa[1])-independent)<mp.mpf('1e-25') and abs(mp.mpf(bb[1])-independent)<mp.mpf('1e-25')
 for folder,name in [('causal_second_product','validation_receipt_v2.json'),('causal_wick_bridge','validation_receipt.json'),('heat_mellin_matching','validation_receipt.json'),('mellin_lorentzian_boundary','validation_receipt.json')]:
  v=json.loads((R/'calculations'/('canonical_so10_'+folder)/name).read_bytes());assert v['execution_state']=='COMPLETED'
 performance={}
 for role in ['primary','replay']:
  cap=json.loads((O/(role+'_capture.json')).read_bytes());res=json.loads((O/(role+'_result.json')).read_bytes())
  assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and res['elapsed_after_imports']<120
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2
  sample=max(v['private_bytes'] for v in cap['all_resource_samples']);assert sample<8*1024**3
  performance[role]={'seconds':res['elapsed_after_imports'],'max_sampled_private_bytes':sample}
 result={'schema':'CAUSAL_ONE_LOOP_SEWING_VALIDATION_V1','execution_state':'COMPLETED',
 'scientific_disposition':'BOUNDED_FINITE_VERTEX_ORDER_ONE_LOOP_CAUSAL_FAMILY_ASSEMBLED_WITH_CORE_FOREST_SUBTRACTION_UNDER_QUALIFIED_INPUTS',
 'scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],'performance':performance,
 'coordinate_graphs_checked_per_route':total_coords,'complete_untyped_graphs_through_n':6,
 'graph_census_closed_form_verified':True,'finite_heat_bridge_jets_required':True,
 'nonlocal_proper_diagonal_control_verified':True,'actual_GF_power_carrier_nonzero':True,
 'complete_new_Spin10_amplitude_measured':False,'native_failures':0,'verifier_failures':0,
 'full_all_loop_QAP_E5_A5_or_physical_scheme_proved':False,'Slavnov_Q_derivation_or_anomaly_zero_proved':False,
 'constant_vacuum_or_positive_physical_state_proved':False,'authority_changed':False,
 'shared_inputs_software_and_AI_author':True,'external_validation':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
