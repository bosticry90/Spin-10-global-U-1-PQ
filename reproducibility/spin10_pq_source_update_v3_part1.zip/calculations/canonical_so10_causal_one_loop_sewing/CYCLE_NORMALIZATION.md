# COS1 cycle normalization supplement

The graph-sewing routes and their separate verifier completed. Before using
the result as a heat-matched vertex-family construction, check one remaining
composition detail explicitly: the general Wick cycle multiplicity and phase
must agree with the inherited one-loop supertrace at arbitrary finite order,
not merely at the previously checked two-vertex bubble.

Freeze W1 Z=integral exp(iS/hbar), W=-i hbar log Z, C_F=iG and the original
source-left odd order. Write a quadratic even vertex as z^t V z/2. Connected
perfect pairings of the2n labeled half edges form one cycle. For n>=2 their
number is2^(n-1)(n-1)!, including the parallel-edge n=2 cycle. For n=1 its raw
self contraction is1. Dividing by the n factors1/2 at the vertices and by n!
from the exponential gives1/(2n). The n=1 local cycle is handled by CWB1's
initial-normalization dictionary, not inserted as a self edge into T1=id.

With interaction factors(i/hbar)^n and contractions(i hbar G)^n, -i hbar log Z
therefore has bosonic coefficient i hbar (-1)^(n+1)/(2n) on (GV)^n. Equivalently,
with the inherited Born M=-V, this is -i hbar/(2n) times (GM)^n.

For one ordered odd pair C,a, use G_Ca=G and G_aC=-G. For vertices a v C,
connected pairings correspond to the(n-1)! cyclic permutations. The Wick sign
is - for every closed cycle: permutation parity(-1)^(n-1) times the n ordered
a-to-C signs(-1)^n equals -1. No extra fermion-loop minus is added afterwards.
The resulting coefficient is i hbar(-1)^n/n. This is exactly the same Born
formula with the odd supertrace factor-2 of the doubled pair and overall1/2.
Matrix paths and external odd sources retain their Koszul/ordered factors;
no color matrices are commuted. General Hessian polarization attaches these
quadratic half-edge identities at each vertex of an arbitrary local polynomial.
External tree branches do not alter the unique cycle symmetry factor.

Supplement acceptance: enumerate every connected no-self Wick pairing for
n=2..6, plus the explicitly separated raw n=1 normalization; compute odd signs
directly by crossing parity. Independently compare with the cycle/permutation
formulas, the W1 phase and M=-V convention. k=2 must give -i/4 per ordered Born
trace; changing covariance iG to G, omitting the bosonic1/2 or adding a second
ghost-loop sign must fail. Authenticate main receipt and frozen sources first.
This tests all finite diagnostic sets; the displayed counting argument gives
the arbitrary-n conclusion. No new model tensor or quantum-loop integral.

Use the same180s verifier/8GiB sampled/350MiB floor/4MiB total-package caps.
Exact rational/complex arithmetic only. Preserve any failure and do not alter
the completed main evidence. No scientific authority, physical scheme, kappa,
b0, old evidence, branch or publication change. This supplement does not prove
a nonlinear Ward/Slavnov identity, multiple Ward-insertion compatibility or QAP.
