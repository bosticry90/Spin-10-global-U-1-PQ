from pathlib import Path
from hashlib import sha256
import json,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'jets_preparation.json').read_bytes())
 for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 z=s.symbols('z');a,c,t,R0=s.symbols('a c t R',positive=True);rows=[]
 for J in range(1,9):
  # Route1: beta integral's gamma ratio. Route2: exact finite rational product.
  gamma=a**J*s.gamma(J)*s.gamma(z-J)/(2*s.gamma(z))
  rational=a**J*s.factorial(J-1)/(2*s.prod(z-k for k in range(1,J+1)))
  assert s.simplify(s.expand_func(gamma)-rational)==0
  analytic=s.limit(gamma,z,0);finite_product=rational.subs(z,0)
  assert s.simplify(analytic-finite_product)==0 and analytic==(-1)**J*a**J/(2*J)
  hard_analytic=analytic-R0**(2*J)/(2*J);hard_heat=-R0**(2*J)/(2*J)
  correction=s.simplify(hard_heat-hard_analytic)
  assert correction==(-1)**(J+1)*a**J/(2*J)
  # Heat powers: the finite constant occurs exactly when heat jet j=J.
  for j in range(10):
   expr=s.gamma(J)*t**(j-J)/(2*c**J)
   finite=s.expand(expr).coeff(t,0)
   assert finite==(s.gamma(J)/(2*c**J) if j==J else 0)
  rows.append({'J':J,'analytic_finite_part':str(analytic),'heat_minus_analytic':str(correction)})
 assert rows[0]['heat_minus_analytic']=='a/2' and rows[1]['heat_minus_analytic']=='-a**2/4'
 assert s.simplify(a**3/6)!=0
 # Polynomial momentum insertion improves or preserves the actual soft order.
 actual=[(1,0),(1,1),(2,1),(2,2),(3,3)]
 for n,m in actual:
  for degree in range(13):assert 2*n-(m+degree)<=2*n-m<4
 assert json.loads((O/'validation_receipt.json').read_bytes())['execution_state']=='COMPLETED'
 assert json.loads((O/'cycle_receipt.json').read_bytes())['execution_state']=='COMPLETED'
 result={'schema':'CAUSAL_ONE_LOOP_SEWING_FINITE_JET_DOMAIN_V1','execution_state':'COMPLETED',
 'scientific_disposition':'FINITE_POLYNOMIAL_JET_CORE_DOMAIN_CLOSED_WITH_GENERAL_POWER_FINITE_PART_FORMULA',
 'scientific_acceptance':'NOT_PERFORMED','input_sha256':prep['input_sha256'],
 'radial_checks':rows,'heat_jet_selection_checks':80,'extra_numerators_do_not_worsen_soft_degree':True,
 'new_physical_EFT_interactions_adopted':False,'authority_changed':False,'full_QAP_E5_A5_proved':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
