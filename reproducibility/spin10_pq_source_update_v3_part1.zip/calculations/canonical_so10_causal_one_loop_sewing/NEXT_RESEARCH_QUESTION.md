# Next decision — apply the constructed one-loop family to the original QAP target

COS1 completes the bounded one-loop causal graph-sewing requirement, under
its qualified core premises. Stop expanding isolated T4/T5 examples. The next
question is whether the ORIGINAL retained-source quantum insertion problem
has a QAP in this constructed compactly switched formal domain, and exactly
how that result compares with the Euclidean heat finite primitive already
qualified. Do not silently replace this by all-loop/nonperturbative QFT.

Read W1-W7/A1-A5 and Brennecke–Dütsch arXiv0801.1408 Theorem5.2/proof. The
published theorem uses a scalar notation. Prove the actual vector/odd-field
version using the643-field two-sided inverse K C_F=i delta, left BV/source
orientation, off-shell jets and the common causal products. Basic axioms,
translation, field independence and scaling are inputs; nonlinear Q is not
automatically a derivation. Quantum anomalies must remain explicit.

The scalar dimension formula cannot be copied unchanged: dimensions differ
between B/x(1),C(0),a/Lambda(2). For a variation component R_i the local
Euler insertion has dimension dim(R_i)+4-dim(z_i). The actual BRST operation
has standard dimension0, so the total Slavnov breaking remains standard
dimension4, project dimension5/ghost1/odd, as in the ORIGINAL contract.
Check the full source/Euler terms and the physical action, not only source
transformations or a favorable projection. No inverse physical coupling.

Match the common vertex functional/graded Legendre and source insertion
normalization to the actual heat-defined Gamma and beta1 dictionary. COS1's
forest subtraction is constructed explicitly: a bare full-graph FP is not
interchangeable with it. Do not infer that every old connected product used
this extension already. The original finite K0 and logarithmic consistency
results are completed inputs, not tasks to redo; establish their exact domain
overlap with the causal normalization before claiming stronger restoration.

Preserve Gamma_ref[A]/its phase/member choice, all finite/IR constants,
unlabelled/global vacuum limitations and multiple nonlinear Ward-product
requirements. A bounded one-loop QAP/restoration result, precise remaining
normalization premise or obstruction is useful; none silently promotes E5/A5.
Matter/flavor stays human-paused. Keep physical-control and gauge-matching
questions separate, using the existing nonzero Yukawa carrier and failed
uniform scalar weakening rather than inventing convenient physical inputs.
