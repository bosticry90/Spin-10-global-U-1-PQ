from pathlib import Path
from hashlib import sha256
import ast,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/original-Ja-ghost-bubble-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={};preps=[]
for p in sorted(O.glob('*preparation*.json')):
    preps.append(p.name)
    for name,h in read(p)['input_sha256'].items():
        assert digest(Path(name))==h,(p.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'native_capture.json','review_capture.json','structure_capture.json','e4_capture.json'}
seen=set();samples={}
for p in O.glob('*capture*.json'):
    seen.add(p.name);cap=read(p)
    assert cap['launch']['creation_after_observation'] and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    assert p.name in accepted and cap['execution_state']=='COMPLETED' and cap['exit_code']==0
    assert cap['calculation_completed'] and cap['post_run_observations_qualified']
assert seen==accepted and not list(O.glob('*controller_failure*.json'))
a=read(O/'native_result.json');b=read(O/'validation_receipt.json');c=read(O/'structural_validation_receipt.json')
assert a['elapsed_after_imports']<300 and all(z['elapsed_after_imports']<180 for z in [b,c])
assert a['source_original_ghost_rows']==334 and a['original_nonzero_source_columns']==32
assert a['base_T0_nonzero']==0 and a['base_one_source_trace_nonzero']==0
assert all(z['source_domain']==2025 and z['T1_nonzero']==0 and z['one_source_U_nonzero']==0 for z in a['probe_summary'])
assert [z['source_ghost_vertices'] for z in a['probe_summary']]==[0,600,0,600]
assert a['actual_reference']['P_is_identity'] and a['actual_reference']['all4_actual_ghost_Euler_kinetic_matrices_match_inverse_P']
assert a['actual_reference']['colour_Q_is_45_not_scalar_transport']
assert [z['actual_scalar_identity_entries'] for z in a['actual_reference']['actual_scalar_transport_identity']]==[328,328]
assert digest(O/'tensor_tables.json.gz')==a['tensor_sha256']
assert digest(O/'ordered_trace_tables.json.gz')==c['ordered_trace_sha256']
assert b['base_all2025_coefficients_and_zeros_equal'] and b['both_probes_all2025_coefficients_and_zeros_equal']
assert b['all45_one_source_traces_equal'] and b['actual_Ghost_Euler_inverse_matches_reference']
assert b['finite_Berezin_base_second_derivative']=='-33/25' and b['finite_Berezin_firstu_second_derivative']=='-38/25'
assert b['wrong_metric_statistics_and_half_factor_controls_sensitive_in_finite_fixture']
assert b['original_zero_H_Ja_premise']=='REFUTED_BY_ORIGINAL_GHOST_VERTICES'
assert b['heat_finite_constant']=='-gamma_E+1-log(2)'
assert c['all45_original_and_both45_probe_odd_Hessians_equal_coefficientwise'] and c['all_original_pair_products_zero']
assert c['original_source_A_support']=='a_M_row,C_H_column'
assert c['reverse_vertex_control_trace']=='8*g10**2/5'
assert c['raw_metric_as_canonical_model_control_changed_positions']==0
assert all(z['no_HM_reverse_block'] and z['individual_mixed_trace_nonzero_positions']==0 and not z['deleting_one_ordered_trace_sensitive'] for z in c['ordered_probe_structure'])
assert c['ordered_probe_structure'][1]['U_blocks']==[[['M','M'],600]]
assert all(not z['full_connected_Ward_QAP_E5_physical_claim'] for z in [a,b,c])
assert b['finite_A1_A2_not_chosen'] and c['finite_A1_A2_not_chosen']
text=(O/'RESULT.md').read_text()
assert 'Focused result-to-claim assessment' in text and 'not a gauge anomaly' in text
assert 'absent-Hessian explanation must not be cited' in text
assert 'INSENSITIVE' in (O/'PROOF_CLARIFICATION.md').read_text()
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished'];exits=[z['exit_code'] for z in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
assert read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='07cc063e3b329deb6e7852ee3a4c80fc6e4e06a1'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<16*1024**2
out={'schema':'OGB_FINAL_EVIDENCE_REVIEW','evidence_validation':'PASS_NONZERO_ORIGINAL_HESSIANS_WITH_STRUCTURAL_ZERO_PROPER_KERNEL',
 'preparations':preps,'input_bindings_authenticated':len(bindings),'source_copies_equal':len(copies),
 'accepted_completed_captures':sorted(accepted),'failed_scientific_captures_preserved':[],
 'original_absent_H_Ja_premise':'REFUTED_CONCLUSION_RECOVERED_BY_FULL_TRACE',
 'actual_full643_scalar_frame_replaces_vacuous_colour_Q_predicate':True,
 'model_trace_controls_insensitive_disclosed':True,'finite_nonzero_Berezin_controls_sensitive':True,
 'full_connected_Ward_QAP_E5_or_physical_claim':False,'finite_normalizations_not_chosen':True,
 'analytic_proofs_not_formal_assistant_certified':True,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,
 'old_tracked_tree_unchanged':True,'largest_accepted_private_sample':max(samples.values()),
 'largest_all_captures_private_sample':max(samples.values()),'memory_samples_not_true_peak':True,
 'packet_bytes_before_final_capture_and_seal':size,'elapsed_after_imports':time.perf_counter()-tick,
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
