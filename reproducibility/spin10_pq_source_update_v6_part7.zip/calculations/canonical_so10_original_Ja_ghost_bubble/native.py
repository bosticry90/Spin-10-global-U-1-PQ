from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
from algebra import *
O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
tables=[];summary=[]
for role in ['primary','replay']:
    um=load(R/f'calculations/canonical_so10_u_maximal_heat_cutoff/{role}_inputs.json.gz')
    fi=load(R/f'calculations/canonical_so10_full_jet_source_master_bridge/{role}_inputs.json.gz')
    core=read(R/f'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/{role}.json')['retained_reference']
    P,G,H,ref=reference(fi['frame'],core)
    # Independent action Euler check of the transformed ghost reference sign.
    gf={i:J.decode(z) for i,z in um['GF_gradient']};kin=[{} for _ in range(4)]
    for r in range(45):
        for w,c in gf.get(598+r,{}).items():
            if len(w)!=1 or not 553<=w[0][0]<598:continue
            i,js=w[0];assert len(js)==2 and js[0]==js[1]
            kin[js[0]][r,i-553]=-c
    assert all(K==kin[0] for K in kin)
    ident45={(i,i):J.constant(1) for i in range(45)}
    assert mul(P,kin[0])==mul(kin[0],P)==ident45,('REFERENCE_VS_ACTUAL_GHOST_EULER_SIGN',role)
    ref['all4_actual_ghost_Euler_kinetic_matrices_match_inverse_P']=True
    src={}
    for w,c in um['source_action']:J.put(src,tuple((convert(i),()) for i in w),co(c))
    first=J.euler(J.clean(src),set(range(1241,1286)));AA=[];source_rows=[]
    for r in range(45):
        A={};z=first.get(1241+r,{})
        assert z.get(((508+r,()),),J.ZERO)==co('-I')
        for w,c in z.items():
            if len(w)==1:assert w==((508+r,()),);continue
            assert len(w)==2 and all(not js for i,js in w)
            (i,js),(j,ks)=w;assert 553<=i<598 and 598<=j<643
            A[j-598,i-553]=-c
        AA.append(A);source_rows.append(len(A))
    XA=[mul(P,A) for A in AA]
    T0={(r,t):pairtrace(XA[r],XA[t]) for r in range(45) for t in range(45)}
    assert all(v==T0[t,r] for (r,t),v in T0.items())
    rawP={(i,j):co(v) for i,j,v in fi['frame']['raw_ghost_Green']['entries']}
    badXA=[mul(rawP,A) for A in AA]
    ref['raw_metric_as_canonical_changed_T0_positions']=sum(pairtrace(badXA[r],badXA[t])!=T0[r,t] for r in range(45) for t in range(45))
    probes=[]
    for probe,encoded in enumerate(um['QG']):
        Q=J.decode(encoded)
        U0odd={w:c for w,c in Q.items() if len(w)==2 and all(553<=i<643 for i,js in w)}
        assert not U0odd,('UNACCOUNTED_GHOST_U0_HESSIAN',probe,J.encode(U0odd))
        two=[(w,c) for w,c in Q.items() if sum(1241<=i<1286 for i,js in w)>=2]
        assert len(two)==[12,33][probe] and all(len(w)==2 and all(1241<=i<1286 and not js for i,js in w) for w,c in two)
        deriv=J.euler(Q,set(range(1241,1286)));UU=[];ports=Counter()
        for r in range(45):
            U={}
            for w,c in deriv.get(1241+r,{}).items():
                if any(i>=643 for i,js in w):continue
                if len(w)!=2:continue
                kinds=tuple('B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a' for i,js in w)
                ports[kinds]+=1
                if kinds==('C','a'):
                    assert not any(js for i,js in w)
                    U[w[1][0]-598,w[0][0]-553]=-c
                else:assert kinds==('B','B'),('UNEXPECTED_SOURCE_HESSIAN_PORT',probe,r,kinds)
            UU.append(U)
        XU=[mul(P,U) for U in UU]
        T1={(r,t):pairtrace(XA[r],XU[t])+pairtrace(XU[r],XA[t]) for r in range(45) for t in range(45)}
        assert all(v==T1[t,r] for (r,t),v in T1.items())
        powers=sorted({tuple(key[:3]) for c in T1.values() for key,v in c.terms})
        probes.append({'probe':probe,'U_ghost':[encode_matrix(U) for U in UU],
          'all2025_labelled_T1':[[r,t,encode_coeff(c)] for (r,t),c in sorted(T1.items())],
          'source_one_U_traces':[encode_coeff(-trace(X)) for X in XU],
          'U0_odd_Hessian_rows':0,'JaJa_source_contacts':len(two),'JaJa_field_Hessian_rows':0,
          'source_Hessian_ports':[[list(k),n] for k,n in sorted(ports.items())]})
        summary.append({'role':role,'probe':probe,'source_domain':2025,'T1_nonzero':sum(bool(c) for c in T1.values()),
          'T1_parameter_powers':powers,'one_source_U_nonzero':sum(bool(trace(X)) for X in XU),
          'source_ghost_vertices':sum(len(U) for U in UU),'even_BB_source_vertices':ports.get(('B','B'),0),
          'bare_firstu_zero_disposition':'REFUTED_BY_MEASURED_TENSOR' if any(T1.values()) else 'MEASURED_ZERO_REQUIRING_FULL_TRACE'})
    tables.append({'role':role,'reference':ref,'P':encode_matrix(P),'G90':encode_matrix(G),'H90':encode_matrix(H),
      'original_A':[encode_matrix(A) for A in AA],'original_A_rows':source_rows,
      'all2025_labelled_T0':[[r,t,encode_coeff(c)] for (r,t),c in sorted(T0.items())],
      'source_one_A_traces':[encode_coeff(-trace(X)) for X in XA],'probes':probes})
    print('STAGE '+role+' original and mixed source traces',flush=True)
assert {k:v for k,v in tables[0].items() if k!='role'}=={k:v for k,v in tables[1].items() if k!='role'}
blob=gzip.compress((json.dumps({'schema':'OGB_ACTUAL_SOURCE_TENSORS','routes':tables},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'tensor_tables.json.gz').open('xb') as f:f.write(blob)
base=tables[0];T0={(r,t):decode_coeff(c) for r,t,c in base['all2025_labelled_T0']}
out={'schema':'OGB1_ORIGINAL_AND_FIRST_PROBE_GHOST_BUBBLE','source_original_ghost_rows':sum(base['original_A_rows']),
 'original_nonzero_source_columns':sum(bool(n) for n in base['original_A_rows']),
 'base_T0_nonzero':sum(bool(c) for c in T0.values()),'base_T0_parameter_powers':sorted({tuple(k[:3]) for c in T0.values() for k,v in c.terms}),
 'base_one_source_trace_nonzero':sum(bool(decode_coeff(z)) for z in base['source_one_A_traces']),
 'probe_summary':summary,'actual_reference':base['reference'],'tensor_sha256':sha256(blob).hexdigest(),
 'unknown_A1_A2_not_chosen':True,'full_connected_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'native_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
