# OGB delegated checkpoint validation

Prospective after native, independent90-field and full source-Hessian
reviews. Run python -B tools/research_check.py e4 ONCE, no --fresh.
Expected native0, steps[0,0,0,0,0,2], terminalCOMPLETED, custody2/seven
NOTPASS. Preserve full capture/events. Elapsed<300s,8GiB sampled,
350MiB available-pagefile launch floor. Changed exits/counts require
review; successful authentication is not scientific gate acceptance.
