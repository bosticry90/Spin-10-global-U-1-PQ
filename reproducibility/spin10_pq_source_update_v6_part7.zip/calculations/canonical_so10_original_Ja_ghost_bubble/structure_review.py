from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
from algebra import *
O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'structure_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
target=load(O/'tensor_tables.json.gz')['routes'][0]
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz');ops={i:J.decode(z) for i,z in fj['operation']}
P=decode_matrix(target['P']);AA=[decode_matrix(z) for z in target['original_A']]
def odd_hessian(poly):
    out={}
    for i in range(553,643):
        first=J.leftjet(poly,(i,()))
        if not first:continue
        for j in range(553,643):
            second=J.leftjet(first,(j,()))
            assert not second or set(second)=={()}
            if second:out[i-553,j-553]=second[()]
    return out
def expected(H):return {(c,a+45):-v for (a,c),v in H.items()}|{(a+45,c):v for (a,c),v in H.items()}
for r,A in enumerate(AA):
    density={w:-c for w,c in ops.get(598+r,{}).items()}
    assert odd_hessian(density)==expected(A),('ORIGINAL_SOURCE_HESSIAN_COEFFICIENT',r)
assert all(a>=12 and c<12 for A in AA for a,c in A),('ORIGINAL_VERTEX_NOT_H_TO_M',)
assert all(not mul(A,B) for A in AA for B in AA)
first_r=next(r for r,A in enumerate(AA) if A);A=AA[first_r]
reverse=pairtrace(mul(P,A),mul(P,transpose(A)));assert reverse
ordered=[];extra=[]
for probe,row in enumerate(target['probes']):
    U=[decode_matrix(z) for z in row['U_ghost']]
    Q=J.decode(fj['probes'][probe]['qG'])
    grad=J.euler(Q,set(range(1241,1286)))
    for r in range(45):
        source=grad.get(1241+r,{})
        # Source derivatives first; all other source/ordinary mean labels
        # are zero only in the completed field-Hessian projection.
        source={w:c for w,c in source.items() if all(553<=i<643 for i,js in w)}
        assert odd_hessian(source)==expected(U[r]),('PROBE_SOURCE_HESSIAN_COEFFICIENT',probe,r)
    blocks=Counter(('H' if a<12 else 'M','H' if c<12 else 'M') for M in U for a,c in M)
    D={(r,t):pairtrace(mul(P,AA[r]),mul(P,U[t])) for r in range(45) for t in range(45)}
    assert all(v==-D[t,r] for (r,t),v in D.items())
    nonzero=sum(bool(v) for v in D.values())
    no_reverse=not any(a<12 and c>=12 for M in U for a,c in M)
    if no_reverse:assert nonzero==0
    ordered.append({'probe':probe,'U_blocks':[[list(k),n] for k,n in sorted(blocks.items())],
      'no_HM_reverse_block':no_reverse,'individual_mixed_trace_nonzero_positions':nonzero,
      'ordered_sum_zero':True,'deleting_one_ordered_trace_sensitive':nonzero>0})
    extra.append({'probe':probe,'all2025_first_ordered_traces':[[r,t,encode_coeff(v)] for (r,t),v in sorted(D.items())]})
out={'schema':'OGB3_FULL_SOURCE_HESSIAN_AND_BLOCK_REVIEW','evidence_validation':'PASS_NONZERO_HESSIANS_WITH_EXACT_ZERO_PROPER_TRACES',
 'all45_original_and_both45_probe_odd_Hessians_equal_coefficientwise':True,
 'original_source_A_support':'a_M_row,C_H_column','all_original_pair_products_zero':True,
 'ordered_probe_structure':ordered,'reverse_vertex_control_source':first_r,
 'reverse_vertex_control_trace':str(expression(reverse.terms)),
 'delete_original_vertex_zero_trace_control':'INSENSITIVE_TO_OMISSION; full nonzero Hessian comparison required',
 'wrong_statistics_sign_of_zero_model_trace':'INSENSITIVE; finite nonzero Berezin calibration required',
 'raw_metric_as_canonical_model_control_changed_positions':target['reference']['raw_metric_as_canonical_changed_T0_positions'],
 'full643_scalar_transport_replaces_vacuous_colour_Q_predicate':True,
 'finite_A1_A2_not_chosen':True,'full_connected_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=gzip.compress((json.dumps(extra,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'ordered_trace_tables.json.gz').open('xb') as f:f.write(blob)
out['ordered_trace_sha256']=sha256(blob).hexdigest()
with(O/'structural_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
