# Original ghost-source Hessians: nonzero vertices, zero proper traces

The original Ja action contains334 ghost coefficient rows in32 source
directions. Its field Hessian is nonzero. The inherited CTS explanation
that only -iJaLambda occurs, and therefore H_Ja vanishes, is refuted by
the complete original source action. Nevertheless, the actual original
and both first-probe proper two-Ja tensors are zero at all2025 labelled
positions. Their one-source traces are zero at all45 positions.

This zero is now derived from the actual matrix support: the original
source maps H into M, and neither probe supplies the reverse ghost block.
Every ordered mixed trace is separately zero. Native determinant
contractions, an independent90-field alternating-Hessian supertrace and
coefficientwise differentiated source Hessians agree. See
[clarification](PROOF_CLARIFICATION.md), [native result](native_result.json),
[independent review](validation_receipt.json) and
[structural review](structural_validation_receipt.json).

## Focused result-to-claim assessment

| Evidence | Supported claim and boundary |
| --- | --- |
| All334 original source coefficients; all45 original and both45 probe odd Hessians compared coefficientwise | The original nonzero Hessian is retained. A zero traced result alone cannot validate its extraction. |
| All2025 original and both2025 first-u coefficients, including zeros; all45 one-source traces | The specified bare proper source-only ghost contribution vanishes through firstu at zero means. This is not the complete connected Ward response. |
| Original A support a_M,C_H; probe1 U support a_M,C_M,600 rows; no reverse block | The zero has a model-specific structural proof. No finite normalization is set to make it vanish. |
| Reversing source13 gives8g10^2/5; finite Berezin second derivatives -33/25 and -38/25 | Nonzero controls test the support and Gaussian signs/factors. Deleting A, reversing the sign of zero or using the raw metric is insensitive in the zero model tensor. |
| Full643 T/F scalar blocks have328 identity entries with no cross-carrier mixing | The scalar transport premise survives a real test. The earlier STS colour-Q predicate was vacuous and is not reused as evidence. |
| Actual ordered positive-heat bubble with finite constant -gamma_E+1-log2 and joint two-node L1 bound | The corrected proper kernel fits the inherited UV-first/free-edge-IR construction. Setting transfer momentum to zero before extension is not justified. |

The CTS bare-zero conclusion survives with this corrected justification.
Its absent-Hessian explanation must not be cited. Its general P_i,Q_ij
program explicitly allows source Hessians and has a domain bound that
includes this simpler kernel. The ESM/RAS/STS even classical responses
and tadpole restrictions are not claims that ghost fluctuations are
absent. No dependency on this later erroneous explanation has been
identified in the38-class theorem; it was not independently replayed.
This targeted audit neither withdraws nor newly qualifies unrelated
quantum identities.

The scientific gain is a corrected necessary input and a stronger error
control. A wrong projection argument produced a correct zero, and several
trace-only controls could not detect the mistake. Whole-Hessian comparison
and a nonzero finite-action calibration were necessary. These are
internally corroborated analytic/computational results with shared action,
data, software and AI authorship. The analytic domain proof is not
formal-assistant certified. This is not a gauge anomaly, experimental
validation, a complete quantum construction or a viable unified theory.

## Execution and remaining work

Native5.4396983s, independent review5.7991040s and structural review
4.6566340s after imports, all completed on their first declared execution.
Complete captures and input/source hashes are preserved. Native300s,
review180s,8GiB sampled private-memory ceiling,350MiB available-pagefile
launch floor and16MiB packet bound apply. Resource samples are not true
peaks. E4 is run once without --fresh; its exact outcome is owned by the
final validation receipt. Expected custody exit2/seven unresolved remains
NOTPASS, regardless of successful evidence authentication.

Finite A1/A2,chi4,kappa,b0 and infrared normalization freedom remain
symbolic. State113/34of39 and E5/A5 OPEN are unchanged. No new physical
benchmark, scalar reference, action, scheme or source space is adopted.
All sources, general mean fields, physical K, repeated Slavnov products,
global phase/measure, causal/vacuum limits and physical viability remain
separate obligations. The295 vector profiles were not replayed.

The next smallest discriminating action is the actual paired one-Ja and
ordinary antighost-source Ward jet. Keep the original334 vertices and the
full7728-position broken ghost remainder. Derive the mixed ports from the
action before using the distinct positive-heat GtRt and RtGt orders.
Determine the joint infrared degree and same-functional UV subtraction
with the connected mean and tadpole terms retained. The proper two-Ja
zero established here cannot replace that connected calculation.
