from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/original-Ja-ghost-bubble-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='07cc063e3b329deb6e7852ee3a4c80fc6e4e06a1'
    C.mkdir(parents=True,exist_ok=True)
    with(C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD']))
    files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
      'docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md',
      'docs/RESEARCH_EXECUTION_HANDOFF_V666.md',
      'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
    inherited={}
    for folder in ['canonical_so10_connected_ward_transport','canonical_so10_scalar_tadpole_sewing','canonical_so10_connected_two_source_loop_domain']:
        base=R/'calculations'/folder
        for prep in base.glob('*preparation*.json'):inherited.update(read(prep).get('input_sha256',{}))
        seal=read(base/'final_review_validation_receipt.json');inherited.update({str(R/p):h for p,h in seal['new_files_sha256'].items()});files.append(base/'final_review_validation_receipt.json')
    for folder,names in {
      'canonical_so10_full_jet_source_master_bridge':['jets.py','native.py','primary_inputs.json.gz','replay_inputs.json.gz','replay_tables.json.gz'],
      'canonical_so10_intrinsic_full_source_descent':['coefficient_ring.py'],
      'canonical_so10_u_maximal_heat_cutoff':['primary_inputs.json.gz','replay_inputs.json.gz'],
      'canonical_so10_connected_two_source_loop_domain':['PROOF.md','RESULT.md','native_result.json','validation_receipt.json'],
      'canonical_so10_scalar_tadpole_sewing':['PROOF.md','native_v2.py','validation_receipt_v3.json'],
      'canonical_so10_connected_ward_transport':['RESULT.md','diagnostic_result.json']}.items():
        for name in names:
            p=R/'calculations'/folder/name
            # A frozen source not previously used directly can be authenticated
            # through its owning full-jet final seal rather than guessed bytes.
            expected=inherited.get(str(p))
            if expected is None and folder=='canonical_so10_full_jet_source_master_bridge':
                owner=read(R/'calculations'/folder/'final_review_validation_receipt.json');expected=owner['new_files_sha256'].get(p.relative_to(R).as_posix())
            assert digest(p)==expected,('NO_AUTHENTICATED_OWNER',str(p));files.append(p)
    for role in ['primary','replay']:
        p=R/f'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/{role}.json'
        assert digest(p)==inherited.get(str(p));files.append(p)
    # NSP's explicit A_i formula is the existing comparator; custody is not replay.
    p=R/'calculations/canonical_so10_nonminimal_source_products/PROOF.md'
    raw=subprocess.check_output(['git','hash-object','--no-filters','--',p.relative_to(R).as_posix()],text=True).strip()
    assert raw==subprocess.check_output(['git','rev-parse','HEAD:'+p.relative_to(R).as_posix()],text=True).strip();files.append(p)
    for p in list(O.iterdir()):
        if p.is_file():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    files.extend(p for p in O.iterdir() if p.is_file())
    dump(O/'preparation.json',{'base_HEAD':'07cc063e3b329deb6e7852ee3a4c80fc6e4e06a1',
       'input_sha256':{str(p):digest(p) for p in files},'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'native.py')]);dump(O/'native_capture.json',cap);dump(C/'native_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED OGB1 original and probe ghost source tensors',flush=True)
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
