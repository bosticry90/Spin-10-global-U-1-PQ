# A source restriction does not remove its quantum field Hessian

Prospective until actual matrices and independent review complete.

## 1. Extract from the original action before setting ghosts to zero

In the actual Euclidean source chart,
 Sigma_Ja_r=-i Lambda_r-B[r,c,a] C_c a_a.
The first term is its even-locus restriction. The second has a genuine
odd-field Hessian at zero means. Source linearity implies Sigma_JaJa=0;
it does NOT imply H_Ja=0. The original source vertices are generally
orderg10; the first-probe source ghost vertex can start at a different
coupling order, as CWT's complete g10^0 remainder demonstrates.

Use the signed canonical reference propagator
 G_Ca=P/q^2, G_aC=-P^T/q^2,
with P derived from the ACTUAL full643 field frame/reference, not assumed
to be the raw45 ghost metric or a matrix with a guessed sign. The Wick
rotation and global Euclidean action sign cancel on the homogeneous
degree-2 ghost Green coefficient; constant field congruences remain.
An independent inverse-Hessian reconstruction checks the result.

Write the ghost action in a,C order as a^T K C. Its source matrices are

 K(J,u)=K0+Ja_r A_r+u Ja_r U_r+u K_u0+...,
 (A_r)_(a c)=B[r,c,a],
 (U_r)_(a c)=-[coefficient of Ja_r C_c a_a in QG].

The normalized ghost Gaussian gives Gamma1=-Tr log K. This fixes the
loop sign and removes field-independent Berezin orientation factors.
It is corroborated by the full alternating90-field graded supertrace.

## 2. The complete relevant source derivatives

At J=phi0, the unprobed labelled two-source derivative is

 Gamma1,rs = T0_rs I_t(p), T0_rs=Tr(P A_r P A_s).

If the actual U0 ghost Hessian and JaJa field Hessian vanish, NSP's FIVE
groups reduce at firstu to TWO ordered mixed-bubble terms, giving

 [u]Gamma1,rs=T1_rs I_t(p),
 T1_rs=Tr(P A_r P U_s+P U_r P A_s).                          (1)

These zero premises must be audited in the actual complete polynomial.
Even BB or mixed scalar/auxiliary U0 blocks cannot join this loop because
the original A_r forces it into the ghost sector. Cubic/quartic source0
ghost vertices have zero field Hessian at the declared zero means, but
remain in the action and in other connected/source derivatives.
U_rs from the JaJa SOURCE contact is field-independent and has zero FIELD
Hessian. It is not silently omitted from the source action.

The source-one traces are -Tr(P A_r) and -Tr(P U_r) in the same reduction;
if nonzero, they multiply the actual massless heat tadpole1/(16pi^2 t).
Their vanishing must be measured, not inferred from field parity. Finite
A1 source normalizations remain separate even if the bare traces are0.

Store all2025 LABELLED second-derivative positions. The functional has
Ja_r Ja_s T_rs/2 summed over ordered r,s; diagonal monomial coefficients
and labelled second derivatives must not be confused. Source exchange
requires T_rs=T_sr, with ordinary commuting even Ja directions.

## 3. Actual heat kernel and finite normalization freedom

The forced loop has two massless ghost edges with their original ordered
positive heat factors. Non-derivative source vertices therefore give

 I_t(p)=integral dq/(2pi)^4 e^-t[q^2+(q+p)^2]/[q^2(q+p)^2].

For K=p_E^2>0,
 16pi^2 I_t=2 integral_(1/2)^1 E1(t K x)dx,
 FP_mu I_t=[log(mu^2/K)-gamma_E+1-log2]/(16pi^2).              (2)

Schwinger parameters a,b>=t, v=a+b,x=a/v, yield the lower radial limit
v>=t/min(x,1-x) and prove(2). This universal factor was previously checked
as a scalar majorant; here it multiplies the newly measured ACTUAL ghost
source tensors. Its small-t log coefficient is -1/(16pi^2). No missing
finite constant is fitted. The renormalized proper product can also
contain a symbolic admissible symmetric A2_rs; neither its complete
mixing ranks nor its compatibility with the full Ward equation is fixed
by this one contribution.

Keep nonzero p or independently smeared Schwartz sources. The joint loop/
transfer majorant |q|^-2|q+p|^-2 in8D has locally-L1 nodes. UV subtraction
leaves the inherited hard q^-5 remainder and log(p^2) is locally integrable.
The actual finite-part/IR order is unchanged. Restricting p0 FIRST gives
a critical q^-4 kernel and is not licensed. This is a proper quantum
kernel, not a constant-vacuum physical matching observable.

## 4. Correct the affected inference without discarding unrelated work

CTS's statement that the original Ja field Hessian vanishes is false
outside the even field restriction. Its general P_i=H_i+H_phi[y_i]
program and two-node domain bound already have room for this extra
proper term: it has no external tree pole and a better joint bound.
An existence theorem may therefore be retained only with explicit
inclusion of the corrected full-source kernel. Its old bare-zero
subclaim must not be cited as qualified evidence for quantum cancellation.

The ESM/RAS/ST S classical even mean response, auxiliary/scalar tadpole
projections and their limits have a different reason for restricting
ghost MEANS; they do not erase internal ghost fluctuations. The NSP
ordered source-product formula explicitly retained A_i and is the
appropriate comparator. A targeted dependency assessment, not an
automatic rerun/withdrawal of every earlier theorem, is required.

The full scalar transport is also audited directly: the full643 T/F
blocks on the328 scalar coordinates must be the identity with no scalar
cross-carrier mixing. A test against the45-colour frame.Q cannot establish
that fact. If the actual full transport confirms it, the STS reference
covariance conclusion survives with a corrected verification basis.

This calculation does not assemble the other Legendre terms, the actual
paired one-Ja/ordinary-ghost-source Ward residual, all source normalizations,
QAP,global phase/measure,causal/vacuum limits,E5/A5 or physical viability.
Nonzero proper coefficients are not by themselves anomalies.
