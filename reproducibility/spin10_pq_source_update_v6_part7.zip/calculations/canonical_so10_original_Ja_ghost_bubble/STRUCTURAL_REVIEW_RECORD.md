# OGB3: explain the measured zero and test the nonzero Hessians

Prospective after native and independent90-field trace review completed.
Both found all2025 base and both first-u tensors zero, while the original
action has334 ghost source rows in32 source directions and the broken
probe has600 ghost source rows. The zero must not be attributed to an
absent original Hessian. Determine the actual H/M block reason or the
required ordered-trace cancellation before qualifying its interpretation.

Check every nonzero coefficient and zero of the original/probe90x90 odd
source Hessians against independent literal graded differentiation of
the full-jet field maps/q0G, not only their zero traces. Classify A and U
blocks. Test whether A forces H-to-M propagation and U has no reverse
block; if a reverse block exists, retain the full ordered traces and test
their exact cancellation instead. Do not delete a term merely because
the sum is0. Keep all finite-colour products and positive-heat ordering.

Controls: reversing one nonzero A vertex creates a potential returning
cycle and should give a nonzero finite trace. Deleting all A vertices or
flipping the sign of an already zero traced quantity can be INSENSITIVE;
report that fact. The nonzero finite Berezin calibration, not the zero
model result, tests the loop sign/factor/metric conventions. Confirm the
full643 scalar T/F identity replaces the vacuous45-colourQ check.

Same immutable inputs/action/limits/authority:180s afterimports,8GiBsampled,
350MiBlaunch,16MiBpacket. Source copies, hashes, captures and any failures
preserved. No physical modification, parameter fit or scientific promotion.
