from collections import defaultdict
from functools import lru_cache
from fractions import Fraction
from pathlib import Path
import sys
import sympy as s
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import coefficient,expression,g,xi,eta
@lru_cache(None)
def co(z):return coefficient(s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta}))
def clean(A):return {k:v for k,v in A.items() if v}
def add(A,B,sign=1):
    out=dict(A)
    for k,v in B.items():out[k]=out.get(k,J.ZERO)+sign*v
    return clean(out)
def mul(A,B):
    rows=defaultdict(list);out={}
    for (i,j),v in B.items():rows[i].append((j,v))
    for (i,k),v in A.items():
        for j,w in rows[k]:out[i,j]=out.get((i,j),J.ZERO)+J.times(v,w)
    return clean(out)
def transpose(A):return {(j,i):v for (i,j),v in A.items()}
def trace(A):return sum((v for (i,j),v in A.items() if i==j),J.ZERO)
def pairtrace(A,B):return sum((J.times(v,B.get((j,i),J.ZERO)) for (i,j),v in A.items()),J.ZERO)
def encode_coeff(c):return [[list(k),v.numerator,v.denominator] for k,v in c.terms]
def decode_coeff(z):return J.Coeff([(tuple(k),Fraction(n,d)) for k,n,d in z])
def encode_matrix(A):return [[i,j,encode_coeff(v)] for (i,j),v in sorted(A.items())]
def decode_matrix(A):return {(i,j):decode_coeff(v) for i,j,v in A}
def convert(i):return 1151+i if i<45 else 1241+i-45 if i<90 else 1196+i-90 if i<135 else 553+i-135 if i<180 else 598+i-180 if i<225 else 508+i-225
def raw_ghost_indices(names):
    return [i for i,n in enumerate(names) if n.startswith('C') or n.startswith('bar') or n.startswith('ub')]
def reference(frame,core):
    names=frame['field_order'];assert names==core['field_order']
    assert frame['physical_to_raw_kernel']['shape']==frame['physical_to_raw_inverse']['shape']==[643,643]
    odd=raw_ghost_indices(names);assert len(odd)==90;pos={i:j for j,i in enumerate(odd)}
    F={(i-553,pos[j]):co(z) for i,j,z in frame['physical_to_raw_kernel']['entries'] if i>=553}
    T={(pos[i],j-553):co(z) for i,j,z in frame['physical_to_raw_inverse']['entries'] if j>=553}
    identity={(i,i):J.constant(1) for i in range(90)}
    assert mul(F,T)==mul(T,F)==identity
    pp=s.symbols('p0_ref0:4',real=True);loc=dict(zip(map(str,pp),pp));p2=pp[0]**2-sum(v*v for v in pp[1:])
    unit={pp[0]:1,pp[1]:0,pp[2]:0,pp[3]:0}
    raw=[]
    for key,power in [('reference_Hessian_raw_C3',1),('reference_Green_raw_C3',-1)]:
        A={}
        for i,j,z in core[key]['entries']:
            if i not in pos and j not in pos:continue
            assert i in pos and j in pos
            value=s.sympify(z,locals=loc);constant=s.simplify(value.subs(unit))
            assert s.simplify(value-constant*p2**power)==0
            A[pos[i],pos[j]]=co(str(constant))
        raw.append(A)
    H=mul(mul(transpose(T),raw[0]),T);G=mul(mul(F,raw[1]),transpose(F))
    assert mul(H,G)==mul(G,H)==identity
    assert all(v==-G.get((j,i),J.ZERO) for (i,j),v in G.items())
    assert all((i<45)!=(j<45) for i,j in G)
    P={(i,j-45):v for (i,j),v in G.items() if i<45}
    scalar=[]
    for key in ['physical_to_raw_kernel','physical_to_raw_inverse']:
        entries=[(i,j,z) for i,j,z in frame[key]['entries'] if 180<=i<508 or 180<=j<508]
        assert len(entries)==328 and all(i==j and s.sympify(z)==1 for i,j,z in entries)
        scalar.append({'matrix':key,'actual_scalar_identity_entries':len(entries)})
    assert frame['Q']['shape']==[45,45]
    return P,G,H,{'ghost_Green_rows':len(G),'P_entries':len(P),'P_is_identity':P=={(i,i):J.constant(1) for i in range(45)},
      'actual_scalar_transport_identity':scalar,'colour_Q_is_45_not_scalar_transport':True}
