from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import gzip,json,os,sys,threading,time
import sympy as s
import mpmath as mp
from algebra import *
O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz')
ops={i:J.decode(z) for i,z in fj['operation']};gf={i:J.decode(z) for i,z in fj['GF_gradient']}
# Independently invert the action-derived canonical ghost Euler coefficient.
K={}
for r in range(45):
    for w,c in gf.get(598+r,{}).items():
        if len(w)==1 and 553<=w[0][0]<598 and w[0][1]==(3,3):K[r,w[0][0]-553]=-c
Kmat=s.SparseMatrix(45,45,{ij:expression(v.terms) for ij,v in K.items()});Pmat=Kmat.inv()
P={ij:co(str(s.simplify(v))) for ij,v in Pmat.todok().items()}
G90={(i,j+45):v for (i,j),v in P.items()}|{(j+45,i):-v for (i,j),v in P.items()}
def hessian(poly):
    H={}
    for w,c in poly.items():
        if len(w)!=2 or not all(553<=i<643 and not js for i,js in w):continue
        # right_j left_i of an even quadratic odd polynomial: the remaining
        # linear polynomial is odd, so the right derivative equals left.
        for at,(i,js) in enumerate(w):
            j=w[1-at][0];H[i-553,j-553]=H.get((i-553,j-553),J.ZERO)+((-1)**at)*c
    return clean(H)
HA=[]
for r in range(45):
    density={w:-c for w,c in ops.get(598+r,{}).items()}
    HA.append(hessian(density))
XA=[mul(G90,A) for A in HA]
half=J.Coeff([((0,0,0,0),Fraction(1,2))])
T0={(r,t):J.times(half,pairtrace(XA[r],XA[t])) for r in range(45) for t in range(45)}
allU=[]
for probe in [0,1]:
    Q=J.decode(fj['probes'][probe]['qG']);HU=[]
    assert not {w:c for w,c in Q.items() if len(w)==2 and all(553<=i<643 for i,js in w)}
    source2=[w for w in Q if sum(1241<=i<1286 for i,js in w)>=2]
    assert len(source2)==[12,33][probe] and all(len(w)==2 for w in source2)
    for r in range(45):
        source=(1241+r,());pol={}
        for w,c in Q.items():
            if source not in w:continue
            remain=tuple(token for token in w if token!=source)
            if len(remain)==2 and all(553<=i<643 and not js for i,js in remain):J.put(pol,remain,c)
        HU.append(hessian(J.clean(pol)))
    XU=[mul(G90,U) for U in HU]
    T1={(r,t):J.times(half,pairtrace(XA[r],XU[t])+pairtrace(XU[r],XA[t])) for r in range(45) for t in range(45)}
    allU.append((HU,XU,T1))
print('STAGE replay full alternating source traces',flush=True)
# Only after completing the independent matrices, read native targets.
tables=load(O/'tensor_tables.json.gz');target=next(z for z in tables['routes'] if z['role']=='primary')
assert P==decode_matrix(target['P']) and G90==decode_matrix(target['G90'])
assert T0=={(r,t):decode_coeff(v) for r,t,v in target['all2025_labelled_T0']}
assert [J.times(-half,trace(X)) for X in XA]==[decode_coeff(v) for v in target['source_one_A_traces']]
for probe,(HU,XU,T1) in enumerate(allU):
    want=target['probes'][probe]
    assert T1=={(r,t):decode_coeff(v) for r,t,v in want['all2025_labelled_T1']}
    assert [J.times(-half,trace(X)) for X in XU]==[decode_coeff(v) for v in want['source_one_U_traces']]

# A direct finite Berezin determinant fixes loop sign/factors without a mapper.
def em(A,B):
    out={}
    for a,v in A.items():
        for b,w in B.items():
            if a&b:continue
            sign=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(4) if a>>i&1)
            out[a|b]=s.expand(out.get(a|b,0)+sign*v*w)
    return {k:v for k,v in out.items() if v!=0}
v,w,u=s.symbols('v w u');K0=s.Matrix([[2,1],[1,3]]);A=s.Matrix([[1,2],[3,-1]]);B=s.Matrix([[2,1],[1,4]])
U=s.Matrix([[0,1],[2,3]]);V=s.Matrix([[4,-1],[1,2]]);KK=K0+v*A+w*B+u*(v*U+w*V)
# exp(-a K C), canonical C0,C1,a0,a1 order; orientation cancels on normalization.
X={(1<<j)|(1<<(i+2)):KK[i,j] for i in range(2) for j in range(2)}
XX=em(X,X);Z=s.expand(XX[15]/2);normalized=s.cancel(Z/Z.subs({v:0,w:0,u:0}))
assert s.simplify(normalized-KK.det()/K0.det())==0
F=-s.log(normalized);at={v:0,w:0,u:0};P0=K0.inv()
base=s.simplify(s.diff(F,v,w).subs(at));mixed=s.simplify(s.diff(F,v,w,u).subs(at))
assert base==s.trace(P0*A*P0*B) and mixed==s.trace(P0*A*P0*V+P0*U*P0*B)
assert base!=0 and base!=s.trace(A*B)
assert base!=-base and mixed!=0

# Exact same positive-heat family; fresh finite constant and profile checks.
mp.mp.dps=42;rows=[];KKnum=mp.mpf('.7')
for ts in ['.2','.02','.002']:
    tt=mp.mpf(ts)
    normalized=2*mp.quad(lambda x:mp.e1(tt*KKnum*x),[mp.mpf('.5'),1])
    z=tt*KKnum
    closed=2*(mp.e1(z)-mp.exp(-z)/z-mp.e1(z/2)/2+mp.exp(-z/2)/z)
    assert abs(normalized-closed)<mp.mpf('1e-37')
    finite=normalized+mp.log(tt)
    target_finite=-mp.log(KKnum)-mp.euler+1-mp.log(2)
    rows.append({'t':ts,'normalized_heat_bubble':mp.nstr(normalized,36),'coordinate_difference':mp.nstr(normalized-closed,6),'finite_part_error':mp.nstr(abs(finite-target_finite),12)})
assert mp.mpf(rows[-1]['finite_part_error'])<mp.mpf(rows[0]['finite_part_error'])
shape=read(O/'native_result.json')
assert digest(O/'tensor_tables.json.gz')==shape['tensor_sha256']
out={'schema':'OGB2_FULL_ODD_SUPERTRACE_AND_BEREZIN_REVIEW',
 'evidence_validation':'PASS_ACTUAL_ORIGINAL_AND_FIRST_PROBE_PROPER_GHOST_KERNEL',
 'base_all2025_coefficients_and_zeros_equal':True,'both_probes_all2025_coefficients_and_zeros_equal':True,
 'all45_one_source_traces_equal':True,'actual_Ghost_Euler_inverse_matches_reference':True,
 'finite_Berezin_base_second_derivative':str(base),'finite_Berezin_firstu_second_derivative':str(mixed),
 'wrong_metric_statistics_and_half_factor_controls_sensitive_in_finite_fixture':True,
 'actual_heat_bubble_profile_checks':rows,'heat_finite_constant':'-gamma_E+1-log(2)',
 'finite_A1_A2_not_chosen':True,'original_zero_H_Ja_premise':'REFUTED_BY_ORIGINAL_GHOST_VERTICES',
 'full_connected_Ward_QAP_E5_physical_claim':False,'analytic_kernel_extension_not_formal_assistant_certified':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
