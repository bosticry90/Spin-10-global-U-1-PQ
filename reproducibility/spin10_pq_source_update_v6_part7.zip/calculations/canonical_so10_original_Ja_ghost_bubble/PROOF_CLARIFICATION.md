# The zero proper kernel has a nonzero source Hessian

Native OGB1, independent OGB2 and the coefficientwise OGB3 source-Hessian
review have completed. This clarification records the actual reason for
the measured zeros; it does not rewrite the prospective derivation or CTS.

The original source action has334 ghost coefficient rows in32 of45 Ja
directions. In a,C order its nonzero A_r matrices have only rows a_M and
columns C_H, where H has12 and M has33 directions. The canonical ghost
Green coefficient P is the identity, derived from the actual full field
frame and checked against the inverse ghost Euler operator in all four
momentum directions. Thus A_r A_s=0 for every ordered pair. In particular
Tr(P A_r P A_s)=0 and Tr(P A_r)=0. The source Hessians themselves do not
vanish. Source linearity gives Sigma_JaJa=0, not H_Ja=0.

For probe0, the ghost U_r matrices are zero. For probe1, all600 nonzero
ghost source coefficients have a_M,C_M support. There is no a_H,C_M
return block. Each ordered mixed trace Tr(P A_r P U_s) vanishes separately,
as does its partner and every one-source trace. The measured zero is not
a cancellation between two unmeasured ordered terms. Both complete
2025-position ordered trace arrays, including zeros, are preserved.

The first-probe JaJa source contacts have no field Hessian; the actual
source-free U0 ghost Hessian is also zero at the declared zero means.
The nonzero even BB source vertices cannot close a loop forced into the
ghost block by A_r. Higher ghost vertices remain in the action and can
contribute to other mixed or sewn derivatives. These restrictions justify
the specific NSP five-group reduction used here, not a general Gaussian
replacement for the full broken probe.

The90-field odd Hessians of all45 original source directions and both
sets of45 probe directions were reconstructed by literal graded
differentiation of the independently derived field maps and q0G. Every
coefficient and zero agrees with the native determinant matrices. A
reversed source13 vertex produces Tr(P A_13 P A_13^T)=8g10^2/5, so the
support control is nonzero and sensitive. This reversed vertex is a
diagnostic change, not an interaction added to the physical action.

Deleting all original A vertices, flipping the sign of a zero trace or
dropping one of these individually zero ordered mixed traces does not
change the model result. Using the raw ghost metric in place of the
canonical one changes zero T0 positions. These controls are INSENSITIVE
here. The nonzero finite Berezin calibration, with second derivatives
-33/25 and first-u -38/25, independently tests the metric, odd loop sign
and factor1/2. Its numbers are diagnostics, not Spin(10) coefficients.

The common heat bubble and its extension remain as derived in OGB1/2.
The zero tensors multiply that kernel before any limit. Consequently this
bare proper source-only contribution is zero without assigning values
to finite A1 or A2. Its joint two-node L1 bound is stronger than the CTS
bound with sewn external trees. The old CTS absent-Hessian premise is
refuted; its particular bare-zero conclusion is recovered by this full
source calculation. The general CTS P_i,Q_ij operator/domain program
retains its H_i terms and can include this corrected kernel. This is a
targeted repair, not an independent replay of the whole connected proof.

Separately, the actual643x643 physical_to_raw_kernel and inverse have328
scalar identity entries and no entries mixing a scalar row or column
with another carrier. This is the required scalar frame test. The old
45x45 colour frame.Q has no scalar entries, so the STS predicate on those
entries was vacuous. The scalar-frame conclusion is recovered with the
actual full matrices. Historical code and its receipt remain unchanged.

No full connected Ward identity follows. Mixed ordinary/BV derivatives
can open additional ports, and the proper source-only trace zero cannot
delete their original ghost interactions. Finite contacts, tadpoles,
the master-defect term, source transport and regulator sewing must still
be treated together in the paired expression of CWT.
