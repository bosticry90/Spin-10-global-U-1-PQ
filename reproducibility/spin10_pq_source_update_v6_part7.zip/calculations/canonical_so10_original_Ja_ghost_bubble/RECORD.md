# OGB1: the original Ja ghost vertices and their proper one-loop kernel

Prospective at07cc063e3b329deb6e7852ee3a4c80fc6e4e06a1/main. Previous
goalturn CWT PROGRESS. Current preflightclean/no matching workers; current
AGENTS/highestV666/actualsource and product proofs read. Goal ACTIVE.
State113/34of39,E5/A5 OPEN,custody2/seven NOTPASS unchanged. No agents,
new checkout,remote action,scheme adoption orblocked-stage activation.

Question: what is the actual original and first-u proper two-Ja kernel
at zero ordinary means/sources? The CTS statement that the ORIGINAL Ja
field Hessian vanishes used its even-locus -iJaLambda restriction. The
actual source action also contains -Ja B C a, as CWT's full source-phase
checks and the original maps show. Even-locus tree data cannot exclude
a ghost quantum loop. Before using the connected Ward jet, calculate
this missing proper input and assess the affected claims narrowly.

Target: original ghost source matrices A_r and first-probe matrices U_r,
their exact reference-metric traces across all45x45 source positions,
the source-one traces and the actual common positive-heat bubble kernel.
Retain g10,xi,eta_H and phases symbolically; identify the coupling orders
from the result, never fit them. Both probes and intrinsic01 retained.
This is a proper/1PI contribution, not the full connected Ward residual.

Same unshiftedSMA/CSW/EDS,A0,independent Schwartz source directions,
positive scalar REFERENCE masses and UVFP THENIR. All other sources are
zero only AFTER derivatives. Actual JaJa QG contact has zero FIELD Hessian;
that does not eliminate the inverse/source responses. The complete NSP
five-term formula remains the comparator. Audit U0's ghost Hessian instead
of assuming it zero. If an extra group survives, retain it and withhold
the claimed full kernel until accounted for.

Least expensive competent test: extract the actual ghost source densities
and reference metric, reduce the forced ghost loop to a matrix trace, and
match the common heat bubble. Do not expand unrelated295vector profiles,
physical fermion masses or previously completed threshold primitives.
This directly supplies or excludes a needed quantum Ward input and tests
the AI workflow's projection-to-quantum inference.

Inputs: actual UMH original source action/QG, independently derived FJB
field maps/q0G, full643 physical/raw frame and retained reference, ESM/CTS/
CWT/NSP evidence. Preserve historical data/policies/receipts. Bind current
AGENTS for this new work. Agreement cannot validate the shared action or
physical premises; canonical source signs stay those already measured.

Native method: action-derived45x45 ghost determinant matrices with exact
coefficient-ring contraction. Independent review: original field-flow/
q0G-derived source vertices, the actual90-field alternating Hessian and
graded supertrace, and finite Berezin/determinant controls of signs and
factors. All2025 positions and zero complements, source exchange, one-point
traces and heat/UV normalization must agree. No conjugate/Hermitian
pairing is substituted for the inherited bilinear one.

Frozen falsifiers: a nonzero original H_Ja refutes the blanket zero-Hessian
premise; a nonzero trace establishes a real missing proper term. A zero
trace still requires its complete contraction, not a field restriction.
Deleting the original ghost vertex, using the wrong reference metric,
wrong odd sign/factor and omitting U0/seagull when actually present are
sensitive controls where applicable. Insensitive controls must be reported.
An incomplete domain is underdefinition, not a gauge anomaly.

Also audit the actual full643 scalar frame: frame.Q is a45-colour matrix,
so testing its nonexistent scalar entries was vacuous in STS. Verify
the REAL full transport blocks and scalar identity before reusing that
claim. This does not presume a change to the scalar reference or action.

Freeze source copies/types/assumptions/input hashes before computation.
Native300s/review180s afterimports,8GiBsampled private,350MiB available
pagefile launch floor,16MiBpacket. Preserve full failures/unfinished runs;
no silent resource expansion or evidence truncation. E4once/no--fresh and
raw-index/all-old-bytes/state preservation before local commit.

Possible results: a measured nonzero kernel and corrected dependency;
a structural trace zero; or an explicit missing contraction/extension.
If the extra loop has the standard two-node bound, it can be included in
the existing extension theorem without withdrawing unrelated tadpole or
source-product work. Do not automatically discard/reaffirm38classes or
promote E5/A5. Keep finite A1/A2 and other baselines symbolic. Complete
connected Ward cancellation, phase/measure,causal/vacuum and physical
viability remain separate. Focused result-to-claim review must report the
original erroneous inference and its actual downstream consequences.
