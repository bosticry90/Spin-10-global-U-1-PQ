# The ordinary auxiliary companion from the two BB Lambda vertices

Use the A=0 transverse slice at g2 and the ordinary
exterior pair Lambda_l, B_b. The V879 literal spatial
BB Lambda coefficient is +i f_(l h m), with h light and
m broken. If the first vertex carries exterior Lambda,
the other can carry exterior B through either a physical
YM cubic or another BB Lambda. For the latter the mixed
edge must join the first broken B port to the second
broken Lambda port. The ordinary BB is light and the
exterior B is broken. Its color is

    sum_(h,m) (i f_(l h m))(i f_(m h b)) = C_H|M[l,b].

For the YM route the stripped color is the negative
of that tensor. The executable verifies both matrices
and their support, including the entry (20,23).

Let q be the momentum on the light ordinary BB and
k on the broken mixed line, with p=q+k the transfer
from the full switched B spectator. The ordered free
Green is G_(B Lambda)=-k G_(C a) in this Euclidean
chart and G_(Lambda B) has the opposite sign.
The literal reference and profiled entries verify the
identity in both routes. Since P_T(q) q=0,

    -P_T(q) k/(q^2 k^2) = -P_T(q) p/(q^2 k^2).

The BBL–BBL proper bosonic log term has a minus sign.
The two distinct spectator placements and the two
internal block orders multiply -1/4 by four. Thus the
raw LambdaB loop is +C_H|M times the projected
light-BB and broken-ghost kernel times p. Relative to
the literal P_(Lambda B)=-p its ordinary coefficient
is -W C_H|M. For the lower source, contracting the
C-first words reorders the external J_B and C once.
The lower graph and this Grassmann sign give the raw
C-first coefficient in units +W. Taking the left
odd source derivative gives w=-W relative to the
unit tree driver, whose literal C-first coefficient
is -1. The companion is therefore w C_H|M, exactly
the V950 target. Equality here uses the same H BB
and matched broken mixed and ghost profiles. It is
an equality of the projected kernels, independent
of a numerical choice of their finite constant.

The YM cubic has tensor
delta_(ab)(q-k)_mu+delta_(bmu)(p_B-q)_a+
delta_(mua)(k-p_B)_b. Under swapping the two internal
momenta and indices it changes sign. The symmetric
BB Lambda contraction transposes the product of
transverse projectors. Hence the integrand is odd
under loop momentum exchange with matched light and
broken BB profiles. This cancels the entire YM
route in the indicated prescription. The independent
numerical tensor control has a nonzero pair which
cancels on exchange. Different profiles or a
normalization which does not preserve that routing
identity are outside this zero.

Keeping labeled switches gives the auxiliary local
term s_Lambda Lambda C_H|M div(s_B B). The switch
derivative must travel with the B spectator.
The choice of both exterior fields Lambda is
another two-edge width projection and is not
included here. The geometric and marked equations
and equality of all profile sectors remain open.
Both routes share the model, symbolic software
and AI authorship.
