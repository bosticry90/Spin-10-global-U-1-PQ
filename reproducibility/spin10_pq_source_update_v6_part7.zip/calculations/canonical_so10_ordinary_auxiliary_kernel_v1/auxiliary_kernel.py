"""Check the ordinary auxiliary two-vertex color and line identity."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull
clean = source.owner.clean


def check(phase):
    _, _, _, f, K, _ = source.owner.inputs(phase)
    root = ROOT / "calculations"
    folder = root / "canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    vertices = {}
    free_source = 0
    for g,word,cells in rows:
        if g == 0 and len(word) == 2:
            (c,dc),(j,dj) = word
            if 553 <= c < 598 and j == 643+4*(c-553)+1:
                assert dc == [1] and not dj and cells == [[[0,0,0],-1,1]]
                free_source += 1
        if g != 1 or len(word) != 3:
            continue
        (a,da),(b,db),(l,dl) = word
        if b >= 180 or a%4 != 1 or not 520 <= l < 553:
            continue
        assert b%4 == 1 and not(da or db or dl)
        assert all(p[:2] == [0,0] for p,_,_ in cells)
        a,b,l = a//4,b//4,l-508
        z = seagull.unpack([([0,*p],n,d) for p,n,d in cells])
        assert a < 12 <= b and z == sp.I*dict(f[a,b])[l]
        vertices[l,a,b] = z
    assert len(vertices) == 334 and free_source == 45
    paired, cubic = defaultdict(lambda:sp.S.Zero), defaultdict(lambda:sp.S.Zero)
    for (l,h,m),z in vertices.items():
        for b,coeff in f[h,m]:
            if b >= 12:
                paired[l,b] += z*vertices[m,h,b]
                cubic[l,b] += z*sp.I*coeff
    paired, cubic = clean(paired), clean(cubic)
    cm = {(a,b):z for b in range(12,45) for a,z in K[b].items()}
    assert paired == cm and cubic == source.add({},cm,-1)
    assert len(paired) == 56 and paired[20,23] == -sp.Rational(1,5)

    free = root / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
    inv = seagull.read(free / f"{phase}_inverse.json.gz")
    q = sp.symbols("q0:4")
    seen = set()
    for key in ("Greference","G_F"):
        G = {(i,j):v for i,j,v in inv[key]}
        for a,mu in product(range(12,45),range(4)):
            b,l,c,d = 4*a+mu,508+a,553+a,598+a
            items = G[b,l],G[l,b],G[c,d],mu
            if items not in seen:
                F,R,S = map(sp.sympify,items[:3])
                assert sp.cancel(F+q[mu]*S) == 0
                assert sp.cancel(R-q[mu]*S) == 0
                seen.add(items)
    P = {(i,j):v for i,j,v in inv["Preference"]}
    assert all(sp.sympify(P[508+a,4*a+mu]) == -q[mu] for a,mu in product(range(12,45),range(4)))

    def transverse(k):
        return sp.eye(4)-k*k.T/(k.dot(k))
    k = sp.Matrix([0,1,3,0])
    q = sp.Matrix([1,2,0,0])
    ext = sp.Matrix([2,1,4,1])
    def projection(k,q):
        T = transverse(k)*transverse(q)
        return (sp.trace(T)*(q-k)+T*(ext-q)+T.T*(k-ext)).applyfunc(sp.expand)
    p = k+q
    assert projection(k,q) != sp.zeros(4,1)
    assert projection(k,q) == -projection(q,k)
    assert transverse(q)*k == transverse(q)*p
    assert transverse(q)*p == sp.Matrix([-sp.Rational(2,5),sp.Rational(1,5),3,0])
    return {"literal_auxiliary_vertices":len(vertices),"casimir_nonzeros":len(paired),
            "retained_color_20_23":str(paired[20,23]),
            "mixed_primitive_matches_ghost_within_broken_quartet":True,
            "matched_BB_BBB_routing_cancels":True,
            "tree_relative_auxiliary_matches_V950":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
