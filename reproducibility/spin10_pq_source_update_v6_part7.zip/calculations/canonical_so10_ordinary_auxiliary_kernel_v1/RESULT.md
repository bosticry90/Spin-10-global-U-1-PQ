# V953 result — ordinary auxiliary projected kernel

The proper two-BB-Lambda graph gives the broken light
Casimir in the ordinary LambdaB coefficient. Its
projected kernel matches the lower light-BB and
broken-ghost kernel when the mixed and ghost
profiles match within the broken quartet. The
tree-relative sign gives exactly the V950
auxiliary companion w C_H|M.

Both literal routes reproduce 334 spatial vertices,
56 color entries and the two mixed line orders.
The competing YM cubic route cancels by exchange
for matched light and broken BB profiles. The
compact spectator gives s_Lambda Lambda C_H|M
div(s_B B), with the derivative on the B switch
retained.

No numerical weight has been chosen. The separate
Lambda-Lambda width coefficient and independent
profile and marked equations remain open. Both
routes share the action, conventions and software.
