# V953 pre-execution contract

Test the actual ordinary auxiliary companion requested by
V950. Freeze the V879 BB Lambda vertex, V791 mixed and
ghost Green orders, and the transverse width-zero
projection. Compare the two-BB-Lambda and BB-Lambda–YM
routes with their literal signs. The surviving pair is
tested against the light BB and broken ghost kernel
when the broken mixed and ghost profiles match.

Check the full color matrices, free tree sign and
nondegenerate Lorentz controls in both frozen inputs.
Keep compact switch derivatives and the distinct width
companion separate. No finite coefficient or physical
normalization is adopted.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor, 8 MiB
artifact and 32 MiB packet. No authority change.
