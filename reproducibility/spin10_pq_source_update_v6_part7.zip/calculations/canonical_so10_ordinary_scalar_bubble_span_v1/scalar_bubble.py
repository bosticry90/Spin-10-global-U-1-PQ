"""Test the ordinary scalar kinetic color target and a bubble span."""

import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def check(phase):
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    phi = {a: sp.SparseMatrix(54,54,{(i,j):z for (i,j),z in data.items() if i < 54 and j < 54})
           for a,data in entries.items()}
    identity = sp.eye(54)
    zero = sp.zeros(54)
    AH = -sum((phi[h]**2 for h in range(12)),zero)
    AG = -sum((phi[h]**2 for h in range(45)),zero)
    assert AG.applyfunc(sp.expand) == 10*identity

    singlet = 12
    center = {0:sp.sqrt(30)/10,5:sp.sqrt(2)/2,8:sp.S.One}
    assert all(not f[h,singlet] and not source.bracket(f,{h:1},center) for h in range(12))
    rho = phi[singlet]
    rho_center = sum((z*phi[i] for i,z in center.items()),zero).applyfunc(sp.expand)
    assert rho != zero and rho_center != zero
    required = -8*rho

    def skew_bubble(a_range, b):
        out = zero.copy()
        for a in a_range:
            square = phi[a]*b+b*phi[a]
            out += (square*phi[a]+phi[a]*square)/2
        return out.applyfunc(sp.expand)

    light = skew_bubble(range(12),rho)
    full = skew_bubble(range(45),rho)
    assert light == (-AH*rho-rho*AH).applyfunc(sp.expand)
    assert full == -16*rho
    ratios = {}
    for i,j in sorted(rho.todok()):
        ratios.setdefault(sp.simplify(light[i,j]/rho[i,j]),(i,j))
    assert len(ratios) >= 2
    two = sorted(ratios.items(),key=lambda pair:pair[1])[:2]
    cert = [[i,j,str(rho[i,j]),str(light[i,j]),str(z)] for z,(i,j) in two]
    hc = skew_bubble(range(45),rho_center)
    assert hc == -16*rho_center
    assert required != zero
    # At the broken singlet the two unequal ratios force equal
    # sector weights. The center then forces their common weight
    # to vanish, contradicting the nonzero broken target.
    h,m = sp.symbols("weight_H weight_M")
    equations = [sp.sympify(row[4])*(h-m)-16*m+8 for row in cert]
    assert sp.solve(equations,(h,m)) == {h:sp.Rational(1,2),m:sp.Rational(1,2)}
    assert sp.solve(equations+[m],(h,m)) == []
    return {"broken_singlet_target":"-8 rho_12",
            "light_center_target":"zero",
            "bubble_ratio_witnesses":cert,
            "full_bubble_coefficient":"-16 rho",
            "two_bubble_color_weights_suffice":False}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
