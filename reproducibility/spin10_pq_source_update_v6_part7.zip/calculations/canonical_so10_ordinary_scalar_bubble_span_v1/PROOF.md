# Ordinary scalar kinetic companion and the two seagull bubble colors

At the unit switch keep the scalar driver of V944 and
the lower derivative gauge map L_B=8 P_M+C_H from V945.
The V788 ordinary physical scalar current has Euler
g (partial x)^t rho x against the gauge field.
A change of the linear gauge driver contributes
g (partial x)^t rho(L_B partial C) x in its kinetic
projection. A matching ordinary Bxx correction with
scalar driver fixed therefore needs the same kinetic
tensor with generator -rho(L_B b) on external B color b.
This is also the first-order scalar kinetic change
under B_old=(I-t L_B)B.

The selected V936 and V943 proper maps have exactly
one ghost edge. They cannot yield a source-free
coefficient with only B,x,x external. Each ordinary
vertex contains ghosts in pairs, so the two vertices
meeting that edge would leave unpaired ghost leaves
in that contraction. This is a port-support statement
for those specific maps. It does not exclude a
different ordinary kernel or its quantum coefficient.

As a candidate extra family, use the physical BBxx
seagull and Bxx cubic with one ordinary gauge and
one scalar edge. In the skew external scalar color
slot the resulting two candidate tensors, up to
common orientation factors, are

    R_S(b) = (1/2) sum_(a in S) {{rho_a,rho_b},rho_a},
    S=H or M.

The inner anticommutator is from the seagull BB
Hessian. The outer symmetrization takes the skew
part of its product with the Bxx generator, since
the first is symmetric and the second skew. This
test concerns these two color directions with
constant weights. It does not fix their allowed
Lorentz or finite extensions.

In Phi, C_G=8I in the adjoint and -sum rho_a^2=10 I,
so R_H+R_M=-16 rho_b. For the broken H-singlet b=e12,
L_B b=8b, and rho_b commutes with the light Casimir
A_H=-sum_(a in H) rho_a^2. Thus R_H=-{A_H,rho_b}.
The executable obtains two unequal entry ratios
R_H/rho_b in this same color. Matching -8 rho_b
there forces equal bubble weights. On the real light
central direction L_B=0 while the Phi generator is
nonzero. Equal bubble weights give a nonzero
multiple of that generator unless both vanish.
The two bubble directions cannot meet both targets.

This result leaves other ordinary scalar maps,
including the mixed gauge-auxiliary scalar triangle,
and further quantum source or kinetic companions
open. It does not require any chosen finite weight
or physical normalization. Both routes share the
action, conventions, software and authorship.
