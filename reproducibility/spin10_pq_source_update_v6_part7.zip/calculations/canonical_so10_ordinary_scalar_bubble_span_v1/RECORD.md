# V948 pre-execution contract

Test the ordinary scalar kinetic companion forced by the
V945 lower gauge driver, with scalar source fixed at the
V944 color value. Freeze the Phi representation, joined
color bracket, V788 kinetic carrier and the BBxx seagull.

Check a nonzero broken-singlet target and the light-center
zero. Identify the support of the already selected
one-ghost-edge maps in the source-free bosonic sector.
Test the two H/M BBxx–Bxx bubble color directions in the
specified skew external scalar slot. Compare exact matrices
and coefficient controls in both frozen routes. Other
ordinary diagrams and source changes are kept open.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.
