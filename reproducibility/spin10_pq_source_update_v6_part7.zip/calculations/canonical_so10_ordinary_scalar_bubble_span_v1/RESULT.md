# V948 result — ordinary scalar kinetic target and the bubble restriction

The V945 lower gauge source with the V944 scalar driver
requires an ordinary Bxx coefficient with generator
-rho(L_B b). The selected one-ghost-edge contacts cannot
produce this bosonic coefficient because their two
ordinary ghost vertices would leave unmatched external
ghosts.

In the Phi block the two light/broken seagull-cubic
bubble color directions also fail the simultaneous
target. Two scalar-coordinate entries at the same
broken H-singlet require equal bubble weights. On the
light center the required coefficient vanishes while
the equal-weight bubble is a nonzero multiple of the
center generator. The nonzero broken target excludes
zero weights. Both frozen exports reproduce the
witnesses.

The exclusion applies to these two bubble color
directions with the scalar driver fixed. A mixed
gauge-auxiliary scalar triangle or additional
ordinary and source normalizations can change the
comparison. No finite coefficient or physical
normalization is adopted. Both routes share the model,
symbolic software and authorship.
