from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-normalization-transfer-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('proper_norm_final',O/'anchor_v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=m.read;digest=m.digest;load=m.load;A=m.A;J=m.J
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['final_preparation.json','preparation.json','preparation_v2.json','preparation_v3.json','transfer_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 anchor=load(O/'anchor_tables_v3.json.gz');ar=read(O/'anchor_result_v3.json');tr=read(O/'transfer_result.json');ref=load(O/'proper_reference.json.gz')
 assert ar['artifact_sha256']==digest(O/'anchor_tables_v3.json.gz') and tr['artifact_sha256']==digest(O/'proper_reference.json.gz')
 assert ar['nonzero_colors']==57 and len(anchor['proper_Ja_Lambda_colors'])==4050 and len(anchor['controls'])==57 and anchor['wrong_extra_width_projector_difference']
 M={int(k):A.decode_matrix(v) for k,v in anchor['M'].items()};N=[{int(k):A.decode_matrix(v) for k,v in z.items()} for z in anchor['N']]
 nz=0
 for pr,a,b,n,det,replay in anchor['proper_Ja_Lambda_colors']:
  v=A.decode_coeff(n);assert v==A.decode_coeff(replay)==A.pairtrace(N[pr][a],M[b]) and A.decode_coeff(det)==-v
  nz+=bool(v)
 assert nz==57
 for pr,a,b,sign,half,transpose in anchor['controls']:
  v=A.pairtrace(N[pr][a],M[b]);assert A.decode_coeff(sign)==-2*v and A.decode_coeff(half)==J.times(-v,J.constant(Q(1,2))) and A.decode_coeff(transpose)==A.pairtrace(A.transpose(N[pr][a]),M[b])-v
 assert len(anchor['free_divB_Lambda_blocks'])==45 and anchor['source_differentiation_precedes_mean_restriction'] and anchor['ordered_ghost_sign_checked'] and anchor['normalized_Gamma_ghost_minus_logdet']
 assert len(ref['M_vector_all_positions'])==91125 and sum(any(row[k] for k in ['p_log','p_rational','ell_log','ell_rational']) for row in ref['M_vector_all_positions'])==1126
 assert ref['proper_equals_negative_full_current_by_actual_operator_identity'] and ref['all_finite_8_8_30_profiles_inherited_unchanged'] and not ref['common_normalization_or_restoring_primitive_adopted']
 assert tr['loop_integrations_reexecuted']==0 and tr['all_rational_log_coefficients_checked']==364500 and tr['new_g0_anchor_matches_qualified_proper_action_M_and_N']
 caps=[]
 for fn,seconds in [('anchor_capture_v3.json',ar['elapsed_after_imports']),('transfer_capture.json',tr['elapsed_after_imports'])]:
  c=read(O/fn);assert c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified'] and seconds<120;caps.append(c)
 for fn in ['anchor_capture.json','anchor_capture_v2.json']:
  c=read(O/fn);assert c['exit_code']==1 and not c['calculation_completed'];caps.append(c)
 for c in caps:assert c['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in c['all_resource_samples'])
 pf=read(O/'transfer_preparer_failure.json');assert pf['exit_code']==1 and not pf['scientific_worker_launched']
 print('STAGE actual4050anchors_57nonzero_allcontrols_allproperreference_authentication_and_failures_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V803.md'];size=sum(p.stat().st_size for p in files);assert size<32*1024**2
 out=dict(schema='ACTUAL_PROPER_NORMALIZATION_TRANSFER_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_NORMALIZED_PROPER_SLAVNOV_FINITE_AND_ORDERED_REFERENCE_COMPARISON',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,actual_source_Euler_trace_exterior_anchor_positions=4050,nonzero_anchors=57,proper_rational_log_coefficients_checked=364500,proper_M_nonzero=1126,source_reference_zero_finite_kernel_retained=True,selected_Euclidean_proper_current_comparison_qualified=True,loop_integrals_reexecuted=0,common_restoring_primitive_or_baseline_adopted=False,failed_workers=[dict(source='anchor.py',exit_code=1,classification='FAILED_WRONG_EXTRA_WIDTH_PROJECTOR_PREMISE'),dict(source='anchor_v2.py',exit_code=1,classification='FAILED_COEFF_FRACTION_DIAGNOSTIC_TYPE')],failed_preparers=1,worker_seconds_after_imports=dict(anchor_v3=ar['elapsed_after_imports'],transfer=tr['elapsed_after_imports']),largest_private_sample=max(x['private_bytes'] for c in caps for x in c['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
