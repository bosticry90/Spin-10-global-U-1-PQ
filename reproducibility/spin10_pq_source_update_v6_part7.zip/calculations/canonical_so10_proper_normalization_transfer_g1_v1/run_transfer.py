from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-normalization-transfer-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'transfer_preparation.json').exists()
cap=json.loads((O/'anchor_capture_v3.json').read_bytes());assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
names=[]
for folder in ['canonical_so10_vector_physical_ward_g1_recovery_v1','canonical_so10_vector_ghost_divergence_companion_g1_v1','canonical_so10_vector_mixed30_g1_recovery_v1','canonical_so10_source_expanded_regulator_reconciliation_g1_v1','canonical_so10_vector_expanded_regulator_reconciliation_g1_v1']:
 names+=['calculations/'+folder+'/'+n for n in ['validation_receipt.json','PROOF.md']]
names+=['calculations/canonical_so10_vector_mixed30_g1_recovery_v1/'+n for n in ['hard_response_v2.json.gz','native_raw_colors.json.gz','replay_raw_colors.json.gz']]+['calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/'+n for n in ['validation_receipt.json','native_tables.json.gz','replay_tables.json.gz']]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['transfer.py','run_transfer.py','PROOF.md']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'transfer_preparation.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},anchor_outputs_frozen_before_late_current_use=True,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'transfer.py')]);dump(O/'transfer_capture.json',cap);dump(C/'transfer_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
