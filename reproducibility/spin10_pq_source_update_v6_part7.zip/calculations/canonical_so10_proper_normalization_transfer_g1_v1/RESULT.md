# Actual proper Slavnov comparison qualified in the selected Euclidean sector

The actual proper Gaussian normalization is checked from the model's full
source Euler rows. Antighost and ghost Euler ports independently give the
same M and N matrices. All643-port Ja Hessian support is audited before
restriction. Trace and complete exterior determinant minors agree on4050
proper Ja-Lambda coefficients, including57 nonzero M coefficients and
the full zero complement. Wrong total sign, extra onehalf, N transpose
and the erroneously added projector width are sensitive. Both ordered
ghost covariances and all45 actual divB/Lambda mixed blocks agree with
the qualified g0 proper completion. V3 completed11.203s under120s.

Together with V800's full source pairing, V801's proper chain and V802's
independently constructed actual KQ/KD and24 explicit master/IBP proofs,
this fixes QGamma1=-C_Q for the selected first-u,g1 Euclidean projection.
The scoped hatted insertion is excluded after source operations, not
globally set zero. The actual model operands and determinant normalization
precede the late finite-current transfer. No desired proper answer was
used to construct them; no qualified loop integral was repeated.

The full finite vector result is the negative of the qualified physical8,
ghost8 and mixed30 kernels, with every profile and mean/source subtraction
retained. All91125 M color positions and364500 rational/log coefficients
are checked. In p_B+ell_Lambda+c_C=0 convention the ordered reference is

    -Cf/(16 pi^2) * [(p+2ell)/12
       +log(9/8){chi_M(B)p-chi_H(B)(p+2ell)}].

There are1126 nonzero M positions:526 B_H and600 B_M. The H probe reference
is zero by the qualified returning support and actual proper bridge. The
source ordered reference is zero, but its finite kernel, the negative of
T(K_Lambda-K_Ja), is retained and generally nonzero. Both zero complements
have their full color-domain types. Transfer completed4.667s under120s.
UV-first joint-Schwartz/IR proofs and whole products are inherited through
the exact identity, rather than new integration or pointwise limits.

Two real failures remain: V1's new test mistook the unit projector for a
gauge-width projector; V2 passed that correction then passed Fraction to
a Coeff-only product in its diagnostic. Neither wrote an accepted anchor
table. Original source/preparation/full captures remain. V3 corrects only
those test/code errors, with unchanged physical operands and gates. A
later preparer named a nonexistent physical8 receipt; its full controller
capture/source remain, and the corrected preparer binds the actual V2
receipt/PROOF_V2. No scientific transfer ran under the failed preparer.
These implementation/interpretation failures qualify the AI capability
assessment; they are not refutations of the underlying physical action.

The exact result is an actual normalized one-loop Slavnov breaking in a
specified Euclidean sector. It is not a completed restoring primitive,
an anomaly/no-go classification, real Minkowski prescription or an adopted
common normalization. The g0 H-T=11Q/36/free-baseline law is unchanged.
Lower-order, unprobed and source companion equations must enter the next
common-module test; the isolated gu coefficient is not assumed Q0 closed.

Final evidence validation owns all manifests/sources/actual/inherited
operands, controls/resources/oldtree/state and E4once-no-fresh on D:.
Historical custodyexit2/seven unresolved stays NOTPASS. Shared action,
ring/chart/software/AI author and inherited integrals limit independence.
No independent scientist, proof kernel, experiment or physical validation.
State113/34of39,E5/A5open; all protected boundaries and fullgoal persist.
