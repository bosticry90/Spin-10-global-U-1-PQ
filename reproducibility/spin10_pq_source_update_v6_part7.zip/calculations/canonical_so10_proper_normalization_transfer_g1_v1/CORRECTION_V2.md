# Correct the projector premise, preserve the failed calibration

The first anchor worker failed its N=-2iPi M check before writing any
anchor table, exit1. Its source/record/preparation/capture remain unchanged.
The actual matrices extracted independently from a and C Euler ports
already agreed before this failed assertion. No physical input changed.

The new RECORD incorrectly identified Pi_H/Pi_M with eta_H/xi times a
projector. This conflicts with the already qualified source action:
canonical_so10_regulator_source_colors_g1_recovery_v1/final_review.py
line32 requires N[r]=mat_scale(M[r],-2i) on the selected H/M indices,
zero elsewhere. Pi is a UNIT projector; M already contains its gauge-width
dependence. This is a test-premise/interpretation error, not a new gauge
choice, fitted factor or rescue of changed physical parameters.

V2 authenticates that exact qualified source/receipt and uses the unit
projector in the unchanged matrix identity. Retain the wrong extra-width
matrix difference as an explicit sensitive control with full coefficients.
All4050 positions, actual Ja-Hessian support, exterior-minor/trace equality,
nonzero anchors, free mixed/ghost blocks and sign/half/transpose controls
remain mandatory. Same120s/8GiBsampled/350MiBfloor/32MiB packet; this new
bounded correction does not alter the old run. Use new V2 output names.
No late finite-current target may construct the normalization anchor.
