# Proper Gaussian normalization and the selected one-loop Slavnov equation

All statements concern the original Euclidean A0, first-u,g1,intrinsic01
BLambdaC and JaLambdaC projection with full source operations first.
They are not a real Minkowski restoring prescription or a full QAP claim.

## Actual g0 normalization, rather than an arbitrary Gaussian example

The source Euler rows of the actual action give E_a=Lambda_b M_b C+...
and E_C=-Lambda_b a M_b+..., independently. The two full port extractions
agree. The actual uJa ghost Hessian similarly gives N_s=-2i Pi_s M_s,
where Pi is the UNIT H/M projector. Its gauge-width dependence is already
inside M. The incorrect extra-width premise and a later coefficient-type
error were caught and preserved as failed V1/V2 runs, not accepted results.

The all643-port Ja scan shows that a second integrated-field derivative
of the Ja-linear u action has only this C-a block. Other Ja Euler terms
are field-independent, so their field Hessian is zero. The restriction
is made after Euler/source operations. Thus the actual proper Ja_s Lambda_b
coefficient at g0 comes from the ghost determinant with

    D=K+Lambda_b M_b+u Ja_s N_s.

In canonical C,a order, exp(-a D C)=1+D C a for one pair. Its normalized
Berezin partition is D/K; Gamma_ghost=-logdet(D/K), with no extra half.
Equivalently the supertrace half counts two odd coordinates. The mixed
Ja-Lambda coefficient is +Tr(N_s M_b) times the common ordered G_F bubble.
The direct trace agrees in all4050 positions with the complete exterior
two-index determinant minors and the log-partition subtraction. There
are57 nonzero coefficients, all in M. Wrong total sign, an extra bosonic
half and N transpose each change every nonzero anchor. A simultaneous
reversal of both ghost edges is blind here; V791's actual inverse and
ordered covariance checks supply the missing sign test. The whole zero
complement is retained rather than sampled.

This also matches the already qualified g0 proper tadpole functional:

    Gamma1_u,tad=-2 sum_s Pi_s Z_s Tr(M_s G_Lambda),
    Z_s=i divB_s+Omega_s Lambda_s/2-iJa_s+a M_s C,
    G_Lambda=(K+Lambda M)^-1.

Its first Lambda expansion is +2 Pi_s Z_s Lambda_b Tr(M_s M_b) times
the same bubble, giving -2i Pi_s Tr(M_s M_b) in Ja_s Lambda_b, exactly
the newly extracted N trace. No tadpole or source term is normalized away.
The v-v subset has fermion means and cannot supply this specific neutral
Ja-Lambda coefficient. The late matrix comparison to V782 is authentication
and a same-action check, not a construction operand for the new anchor.

## Actual free mixed block and the Taylor half

With Fourier y=divB and the second leg carrying -q, actual V791 G_F gives

    G_(y,Lambda)=F [[Omega,-i],[-i,0]],
    G_Ca=F/q2, G_aC=-F/q2, F=fE.

All45 color blocks are checked directly from the authenticated matrix
packet, including both ghost orders. The even unprofiled inverse is
[[0,i],[i,Omega]], exactly the inverse used by the g0 proper completion.
The recorded B0/Lambda Wick phases are inherited from V791's independent
actual-action/frame check, not selected by requiring an amplitude sign.

For the actual U=sum Pi Z^2, even Taylor differentiation gives
T2U/2=sum Pi[(TZ)^2+Z T2Z]. The source Ja part has only the ghost Hessian
above; its one-pair Berezin coefficient fixes the minus-logdet sign and
removes any possible extra factor onehalf. The bosonic mixed block uses
the usual determinant half with both coordinates. This is the same
normalization as V785/786 and the V801 non-master proper-chain proof.
No field-independent reference constant fixes a source or mean contact.
The source-quadratic terms are retained in the full operators even though
their own field Hessian may vanish in this particular anchor.

## From independently constructed proper kernels to finite integrals

The proper determinant derivatives are
Gamma_phi=<T2E/2>, Gamma_J=(-1)^p<T2F/2>. In the LEFT convention of V800,
QGamma=<KQ+KD>, with precisely V802's independently constructed operators.
The exact even product rule and its actual24-case IBP verification give

    I_B1=QGamma+C_Q,  C_Q=<sum TF TE>.

V802 retains the full hatted insertion, then excludes its selected first-u
coefficient by a stable-ideal support proof after external operations.
It does not assume the full chiral master breaking or measure vanishes.
Consequently QGamma=-C_Q in the stated projection, at the same positive
profile and before the ordered limits. This conclusion is derived through
actual proper operators, source pairing, the normalized determinant and
the full product/master identity; it is not Gamma assigned a desired value.

V798/V799 already identify the full expanded source/vector C_Q with the
ordered regulator contraction, including physical and omitted-port
companions. The independently qualified finite physical8, ghost8 and
mixed30 evaluations therefore transfer with an overall minus sign. There
is no new loop integral in this transfer. Both probes' full zero complements
and the1126 nonzero M positions remain; counts alone are not the argument.
The source finite kernel is the negative of T(K_Lambda-K_Ja), generically
nonzero at positive profiles, with the qualified zero ordered reference.
The vector finite expression is the negative sum of those full8+8+30
kernels. Transverse twelve and separated physical/scalar/free-port support
exclusions retain their original scopes, not new global zeros.

In the V797 local-reference convention p_B+ell_Lambda+c_C=0, the vector
proper Slavnov coefficient is

    -Cf/(16 pi^2) * {
        (p+2ell)/12
        + log(9/8)[chi_M(B) p-chi_H(B)(p+2ell)] }.

The H probe and the source ordered reference are zero in this selected
coefficient. The M vector reference is nonzero at1126 color positions,
526 B_H and600 B_M. The transfer checks every rational/log coefficient
against the actual saved Cf, and retains all91125 positions per probe.

The finite inverses and whole mean subtraction remain paired as in V801:
QGamma=I_BR1-Dreg-Jac. Dsource, Dreg and marked D_epsilon are distinct;
no missing historical VDI tensor is inferred. Separate inverse heat/IR
factors are not standalone Schwartz maps. The current derivations' common
joint-Schwartz bounds and UV-first then IR reference, with the pure-IR
kernel retained until its removal bound, transfer linearly through the
proved operator equality. No pointwise interchange or early p=0 limit
is introduced. Scalar constant reference chains retain their earlier
all-length nonreturning proof; the six-vertex g/u bound alone is insufficient.

## Meaning and remaining work

This completes the selected actual proper/current comparison in the
qualified Euclidean one-loop domain. It does not establish a full source-
complete restoring primitive, reality/background compatibility, common
marked/unmarked normalization, global measure/phase, full QAP or quantum
equivalence. In particular a nonzero breaking coefficient is neither an
anomaly classification nor a no-go result. Lower-order, unprobed and
source companions can enter the consistency equation. Do not assume the
isolated gu coefficient is Q0 closed or fit extra terms to force it so.

The g0 compatibility H-T=11Q/36 and its free connected baseline are not
refitted or adopted here. Next examine the existing full admissible common
module and its lower/source companion equations, using this actual proper
coefficient as qualified input. Shared action/chart/ring/AI author and
inherited integrals limit independence; no external experiment, proof
kernel, independent scientists or protected scientific acceptance.
