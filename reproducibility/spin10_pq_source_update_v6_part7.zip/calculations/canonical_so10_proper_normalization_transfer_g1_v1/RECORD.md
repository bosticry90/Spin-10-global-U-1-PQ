# Actual proper normalization anchor and finite-current transfer

Base9e6bb1e6938f85312ed1a47c7e6858cb90522753/main,V802. CurrentAGENTS,
fullgoal,D:first,state113/34of39,E5/A5open unchanged. Noagents/newbranch/
worktree/remoteaction/foundationaladoption/protectedpromotion. Ordinary
scientific derivation is delegated; education voluntary/nonblocking.

Question: does the actual proper Gaussian have the same sign, T2 half
and ordered ghost convention as the evaluated V799 current? The cheapest
competent new check is the actual g0 proper Ja-Lambda coefficient. It has
a full source-derived two-ghost Hessian, with nonzero matrix colors, and
is already present in the qualified g0 proper tadpole functional. No
new loop integration or physical parameter selection is needed.

Keep source differentiation before restriction. From actual E0 and Eu0
all643 ports extract M_b from E0_a's Lambda_b C and independently from
minus E0_C's Lambda_b a. Extract N_s from Eu0_a's Ja_s C and independently
from minus Eu0_C's Ja_s a, both probes, all45 colors. Scan all Ja-bearing
Eu0 field words to prove only this ghost Hessian survives a second field
derivative; source-only linear field terms have zero field Hessian.
N_s=-2i Pi_s M_s must follow from actual full source action; do not fit Pi.
Pi_H=eta_H projectorH,Pi_M=xi projectorM, as in the qualified action.

For D=K+Lambda_b M_b+u Ja_s N_s, literal normalized Berezin integration
gives Gamma_ghost=-logdetD. The Ja-Lambda coefficient is +Tr(N_s M_b)
times the common two-edge G_F bubble. Native trace and replay complete
two-index exterior determinant minors plus log subtraction must agree in
all2025 positions per probe. Require an actual nonzero anchor; preserve
its full zero complement. Wrong overall sign, extra bosonic half and
transposed N must be sensitive where nonzero. A simultaneous ghost-edge
sign reversal is blind to this two-edge anchor; V791's full inverse test
owns that sign. No actual loop coefficient is chosen as a target operand.

Use actual V791 G_F matrices for all45 colors and Fourier y=divB: y-y,
y-Lambda,Lambda-y,Lambda-Lambda must equal
F[[Omega,-i],[-i,0]], F=fE. This matches V785/786's proper Gaussian
completion, with the same action Wick convention. Check the ordered
ghost pair G_Ca=F/q2,G_aC=-F/q2 and normalized one-pair Berezin factor.
No standalone inverse heat, chosen gauge width or new baseline.

Freeze source/inputs before120s after-import anchor,8GiB sampled-private,
350MiB launch floor,32MiB packet. Preserve failures and exact captures.
Only after the anchor outputs are frozen may a bounded120s late transfer
authenticate/reuse V795/796/797/798/799 finite evaluations and the qualified
g0 proper formulas. Together with V800 source pairing,V801 proper-chain
identity,V802 actual independently constructed KQ/KD/master and scoped
hatted support, this determines QGamma from its actual proper operators
through the same regulated Gaussian. It is not Gamma defined as a desired
current cancellation. Do not reintegrate qualified loops without need.

The transfer must retain full finite8+8+30 profiles, whole mean/source
subtraction, source kernel and UV-first joint-Schwartz/IR limits. Report
only the original Euclidean selected first-u g1 equation and local
reference. A separate real Minkowski/background/source-complete restoring
primitive and common normalization are not thereby adopted. Lower/source/
unprobed companions remain required; no isolated-gu closedness assumption.

Final180s binds all sources, actual operands and inherited receipts,
controls/resources/state/oldtree/E4once-no-freshDcontext expected exits
0,0,0,0,0,2/seven unresolved custodyNOTPASS. Local staged-raw-byte/mode
checks before commit, preservemain and oldevidence. No E5/A5/measure/QAP/
equivalence/viability or whole-investigation completion claim.
