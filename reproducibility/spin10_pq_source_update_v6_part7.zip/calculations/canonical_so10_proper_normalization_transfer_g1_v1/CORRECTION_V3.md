# Preserve the V2 coefficient-type failure

V2 passed the corrected actual unit-projector identity but failed while
serializing the first nonzero half-factor control: Coeff multiplication
requires a Coeff operand; the code passed Fraction. Exit1/source/capture
remain unchanged, with no completed anchor table or PASS. This is an AI
implementation/type error, not a failed physical normalization equation.

V3 makes only that operand J.constant(Fraction(1,2)), retaining the same
half-factor diagnostic and all scientific conditions. New source/output/
preparation names; same120s/8GiBsampled/350MiBfloor/32MiB bound. No policy,
input, actual projector or original failed evidence is modified.
