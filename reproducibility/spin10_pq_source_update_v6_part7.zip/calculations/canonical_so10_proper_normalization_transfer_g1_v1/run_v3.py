from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-normalization-transfer-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'preparation_v3.json').exists()
prep=json.loads((O/'preparation_v2.json').read_bytes())
for n,h in prep['sha256'].items():assert digest(R/n)==h,n
names=['calculations/canonical_so10_regulator_source_colors_g1_recovery_v1/'+n for n in ['validation_receipt.json','final_review.py']]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['CORRECTION_V3.md','anchor_v3.py','run_v3.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'preparation_v3.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'anchor_v3.py')]);dump(O/'anchor_capture_v3.json',cap);dump(C/'anchor_capture_v3.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
