# Use the actual physical8 owning receipt

run_transfer.py failed before freeze or scientific-worker launch because
it named physical_ward/validation_receipt.json. The actual completed
physical8 receipt and written review are validation_receipt_v2.json and
PROOF_V2.md. Preserve the failed controller source and full tool capture.
No scientific transfer was executed under that preparer, and no result
is inferred. V2 authenticates the actual owning V2 receipt/review; all
other operands, source, acceptance conditions and120s bound are unchanged.
