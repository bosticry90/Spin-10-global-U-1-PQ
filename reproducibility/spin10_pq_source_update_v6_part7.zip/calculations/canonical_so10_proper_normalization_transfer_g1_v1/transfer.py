from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('late_actual_proper_norm',O/'anchor_v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;A=m.A;read=m.read;load=m.load;digest=m.digest
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'transfer_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 anchor=load(O/'anchor_tables_v3.json.gz');ar=read(O/'anchor_result_v3.json');assert digest(O/'anchor_tables_v3.json.gz')==ar['artifact_sha256'] and ar['nonzero_colors']==57
 g0=load(O.parent/'canonical_so10_absolute_marked_quantum_g0_recovery_v1/native_tables.json.gz')
 assert anchor['M']=={str(b):z for b,z in g0['ML']}
 for pr in [0,1]:assert anchor['N'][pr]=={str(b):z for b,z in g0['probes'][pr]['N']}
 hard=load(O.parent/'canonical_so10_vector_mixed30_g1_recovery_v1/hard_response_v2.json.gz')
 colors=load(O.parent/'canonical_so10_vector_mixed30_g1_recovery_v1/native_raw_colors.json.gz')['all_positions'];assert len(colors)==len(hard['all_positions'])==45**3
 out=[];counts={'B_H':0,'B_M':0};keys=['p_log','p_rational','ell_log','ell_rational']
 for row,old in zip(colors,hard['all_positions']):
  a,b,c=[row[k] for k in ['B','Lambda','C']];assert [a,b,c]==[old[k] for k in ['B','Lambda','C']]
  cf=A.decode_coeff(row['Cf']);expected=dict(p_rational=J.times(cf,J.constant(Q(1,12))),ell_rational=J.times(cf,J.constant(Q(1,6))),p_log=cf*(1 if a>=12 else -1),ell_log=cf*(-2 if a<12 else 0))
  assert all(A.decode_coeff(old[k])==expected[k] for k in keys)
  proper={k:A.encode_coeff(-expected[k]) for k in keys};assert all(A.decode_coeff(proper[k])+A.decode_coeff(old[k])==J.ZERO for k in keys)
  if cf:counts['B_H' if a<12 else 'B_M']+=1
  out.append(dict(B=a,Lambda=b,C=c,**proper))
 assert counts==dict(B_H=526,B_M=600) and hard['H_probe_all_positions_zero_by_empty_catalog']
 data=dict(schema='PROPER_SLAVNOV_G1_ORDERED_REFERENCE_V1',domain='ORIGINAL_EUCLIDEAN_A0_FIRST_U_INTRINSIC_01',M_vector_all_positions=out,H_vector_zero_complement=dict(colors_per_leg=45,total_positions=45**3,zero_by_qualified_empty_returning_catalog_and_actual_proper_master_bridge=True),source_zero_complement=dict(probes=[0,1],colors_per_leg=45,positions_per_probe=45**3,zero_ordered_reference_not_zero_finite_profile=True),normalization=hard['normalization'],proper_equals_negative_full_current_by_actual_operator_identity=True,not_definition_of_uncomputed_Gamma=True,all_finite_8_8_30_profiles_inherited_unchanged=True,independent_new_loop_integrations=0,nonzero_M_vector=counts,source_and_lower_g_u_companions_kept=True,common_normalization_or_restoring_primitive_adopted=False,scientific_acceptance='NOT_PERFORMED')
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'proper_reference.json.gz').open('xb') as h:h.write(blob)
 result=dict(schema='ACTUAL_PROPER_FINITE_CURRENT_TRANSFER_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',new_g0_anchor_matches_qualified_proper_action_M_and_N=True,all_M_vector_positions_checked=45**3,all_rational_log_coefficients_checked=4*45**3,M_vector_nonzero=1126,B_H=526,B_M=600,H_vector_zero_by_support=True,source_ordered_reference_zero_finite_kernel_retained=True,actual_proper_identity_not_target_assignment=True,Euclidean_only_not_real_Minkowski_restoring_prescription=True,finite_8_8_30_and_whole_source_mean_subtraction_retained=True,UV_first_joint_Schwartz_then_IR_reused=True,loop_integrations_reexecuted=0,artifact_sha256=sha256(blob).hexdigest(),elapsed_after_imports=time.perf_counter()-tick)
 with (O/'transfer_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
