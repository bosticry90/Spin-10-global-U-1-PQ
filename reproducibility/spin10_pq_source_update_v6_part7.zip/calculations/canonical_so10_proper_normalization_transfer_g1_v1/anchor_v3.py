from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('actual_norm_ring',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;A=m.w.A;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def matrix_maps(packet,route):
 states={k:dict(v) for k,v in packet['states'].items()};M={b:{} for b in range(45)};Ns=[];support=[]
 for r in range(45):
  raw=states['E0'][598+r] if route=='a' else states['E0'][553+r]
  for ww,c in J.decode(raw).items():
   if len(ww)!=2 or any(js for n,js in ww):continue
   ff=553 if route=='a' else 598
   if 508<=ww[0][0]<553 and ff<=ww[1][0]<ff+45:
    b=ww[0][0]-508;j=ww[1][0]-ff;M[b][(r,j) if route=='a' else (j,r)]=c if route=='a' else -c
 for pr in [0,1]:
  N={b:{} for b in range(45)};journal=[]
  for n,raw in states['Eu0_'+str(pr)].items():
   for at,(ww,c) in enumerate(J.decode(raw).items()):
    ja=[t for t in ww if 1241<=t[0]<1286]
    if not ja:continue
    fields=[t for t in ww if t[0]<643]
    disposition='FIELD_AFFINE_SOURCE_ONLY_EULER_HESSIAN_ZERO'
    if fields:
     assert len(fields)==len(ja)==1 and len(ww)==2 and not ja[0][1] and not fields[0][1]
     nn=fields[0][0];assert (598<=n<643 and 553<=nn<598) or (553<=n<598 and 598<=nn<643)
     disposition='ORDERED_GHOST_HESSIAN'
     if route=='a' and n>=598:N[ja[0][0]-1241][n-598,nn-553]=c
     if route=='C' and n<598:N[ja[0][0]-1241][nn-598,n-553]=-c
    journal.append([n,at,disposition])
  Ns.append(N);support.append(journal)
 return M,Ns,support
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation_v3.json')['sha256'].items():assert digest(R/n)==h,n
 old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'
 M,Ns,support=matrix_maps(load(old/'native_inputs.json.gz'),'a');Mr,Nr,supportR=matrix_maps(load(old/'replay_inputs.json.gz'),'C');assert M==Mr and Ns==Nr
 zero=J.ZERO;xi=J.Coeff([((0,1,0,0),Q(1))]);eta=J.Coeff([((0,0,1,0),Q(1))]);enc=m.w.enc;rows=[];controls=[]
 assert all(A.add(z,A.transpose(z))=={} for z in M.values())
 for pr,N in enumerate(Ns):
  for b in range(45):
   pi=J.constant(1) if (pr==0 and b<12) or (pr==1 and b>=12) else zero
   assert N[b]=={ij:J.times(-2*J.I,J.times(pi,c)) for ij,c in M[b].items() if J.times(pi,c)}
  for a in range(45):
   for b in range(45):
    n,z=N[a],M[b];trN=A.trace(n);trM=A.trace(z);assert not trN and not trM
    native=A.pairtrace(n,z);det=zero
    for i in range(45):
     for j in range(i+1,45):
      for x,y,sg in [(n.get((i,i),zero),z.get((j,j),zero),1),(z.get((i,i),zero),n.get((j,j),zero),1),(n.get((i,j),zero),z.get((j,i),zero),-1),(z.get((i,j),zero),n.get((j,i),zero),-1)]:
       if x and y:det+=sg*J.times(x,y)
    replay=-(det-J.times(trN,trM));assert native==replay
    rows.append([pr,a,b,enc(native),enc(det),enc(replay)])
    if native:controls.append([pr,a,b,enc(-2*native),enc(J.times(-native,J.constant(Q(1,2)))),enc(A.pairtrace(A.transpose(n),z)-native)])
 assert controls and all(all(x for x in row[3:]) for row in controls)
 wrongwidth=[]
 for pr,N in enumerate(Ns):
  for b in range(45):
   om=eta if b<12 else xi
   bad=A.add({ij:J.times(om,c) for ij,c in N[b].items()},N[b],-1)
   if bad:wrongwidth.append([pr,b,A.encode_matrix(bad)])
 assert wrongwidth

 print('STAGE actual_full_source_ports_N_and_M,all4050proper_trace_exterior_minors_and_controls',flush=True)
 inv=load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1/native_inverse.json.gz');cache={}
 def sy(t):
  if t not in cache:cache[t]=s.sympify(t)
  return cache[t]
 gf={(i,j):sy(t) for i,j,t in inv['G_F']};q=s.symbols('q0:4');F=s.Symbol('E_profile')*s.Symbol('f_profile');q2=sum(x*x for x in q);blocks=[]
 for b in range(45):
  om=s.Symbol('eta_H' if b<12 else 'xi');L=508+b;B=[4*b+mu for mu in range(4)]
  yy=sum(q[mu]*q[nu]*gf.get((B[mu],B[nu]),0) for mu in range(4) for nu in range(4))
  yl=s.I*sum(q[mu]*gf.get((B[mu],L),0) for mu in range(4));ly=-s.I*sum(gf.get((L,B[mu]),0)*q[mu] for mu in range(4))
  vals=[s.cancel(yy),s.cancel(yl),s.cancel(ly),gf.get((L,L),0)];expect=[F*om,-s.I*F,-s.I*F,0];assert all(s.cancel(v-e)==0 for v,e in zip(vals,expect))
  assert s.cancel(gf[553+b,598+b]-F/q2)==0 and s.cancel(gf[598+b,553+b]+F/q2)==0
  blocks.append([b,*map(str,vals)])
 H=s.Matrix([[0,s.I],[s.I,s.Symbol('Omega')]]);G=s.Matrix([[s.Symbol('Omega'),-s.I],[-s.I,0]]);assert H*G==s.eye(2)
 # Literal one-pair Berezin extraction in canonical C,a order:
 # exp(-a D C)=1+D C a; Z(D)/Z(K)=D/K, Gamma=-log(D/K).
 out=dict(schema='ACTUAL_PROPER_GHOST_SOURCE_NORMALIZATION_ANCHOR_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',M={str(k):A.encode_matrix(v) for k,v in M.items()},N=[{str(k):A.encode_matrix(v) for k,v in z.items()} for z in Ns],Ja_Hessian_support_native=support,Ja_Hessian_support_replay=supportR,source_differentiation_precedes_mean_restriction=True,proper_Ja_Lambda_colors=rows,nonzero_colors=len(controls),controls=controls,wrong_extra_width_projector_difference=wrongwidth,free_divB_Lambda_blocks=blocks,ordered_ghost_sign_checked=True,ghost_edge_double_sign_anchor_blind_inherited_inverse_control=True,normalized_Gamma_ghost_minus_logdet=True,all_actual_mixed_and_ghost_free_ports_checked=True,elapsed_after_imports=time.perf_counter()-tick,loop_integral_not_reexecuted=True)
 blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'anchor_tables_v3.json.gz').open('xb') as h:h.write(blob)
 result={k:v for k,v in out.items() if k not in ['M','N','Ja_Hessian_support_native','Ja_Hessian_support_replay','proper_Ja_Lambda_colors','controls','free_divB_Lambda_blocks','wrong_extra_width_projector_difference']};result['artifact_sha256']=sha256(blob).hexdigest()
 with (O/'anchor_result_v3.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
