# Interacting Phi54 cycle with the scalar switching boundary

Use the physical scalar kinetic AST and the V872/V892 fixed-flat
reference in the same 643-field theory. Select two ordinary B
mean labels in one light color, zero retained sources and A,
and only Phi54 internal propagators. Work at g² and one loop,
at zero scalar mass-difference degree and positive Phi reference
mass squared M. Select each fixed finite number n of scalar
switch-only quadratic insertions. This is a coefficientwise
statement about the actual compact parent.

## Physical vertices and the finite compact boundary

The physical AST is half the square of
D_B x=partial x+g rho(B)x. The transported reference carrier
satisfies r=−rho. With both light B labels the vertices are
the same V1(B), V2(B) as V892 with A replaced by B. In
particular the first symbol is i g r_h (2q+p)·B and the
second is −g² r(B_mu)^2. Keep both vertices and their metric
contractions before restricting to transverse external means.
The V787 first-order rows and the literal second-order AST
check both signs and the nonzero seagull. At zero scalar
mean, potential terms above degree two in x have no selected
Hessian. Match the scalar quadratic to M at degree zero in
the mass difference. Other field sectors and mixed scalar
edges belong to different selected contributions.

At zero B, the literal scalar kinetic density and its
Euler-normal quadratic reference differ by
partial_mu(x partial^mu x)/2. With switch sigma, integrate
this term by parts twice. It gives (Box sigma)x²/4 and
hence the actual Hessian Q_sigma=(Box sigma) I/2.
In Euclidean signature this is +Delta_E sigma/2. It is a
g0 potential at the boundary, even if B has support strictly
inside the plateau. The Euclidean integration by parts and
the Minkowski density Wick map give the same sign.

Let sigma_R(x)=chi(x/R), chi smooth compact, equal to one
on a neighborhood of the origin. Start from real transverse
Schwartz B labels with Fourier support in a compact set
of real spacelike p, bounded away from the light cone.
They have antisymmetric Schwartz potentials D with
B_mu=partial^nu D_nu,mu, obtained by division by the
nonzero p² on the Fourier support. Choose a smaller
compact cutoff eta_R inside the plateau of sigma_R and put
B_R=partial^nu(eta_R D_nu,mu). These are compact transverse
means and converge to B in Schwartz space at every inverse
power of R. Every jet of B_R is in the plateau, so the
switched linear vertex V1(sigma_R B_R) is V1(B_R),
and the switched quadratic vertex sigma_R V2(B_R)
is V2(B_R). The distinction between those two switch
rules is essential away from this support condition.

Use the compact classical sources determined by stationarity
for these prescribed means, and the same slice in the
continued direct coefficient. The sources may vary with the
prescribed mean and R. The compact one-loop Legendre
identity is W_1=F(phi_0,J,A); the shift of the stationary
point cancels between the action and ordinary source
pairing at this order. This evaluates the same connected
coefficient on the prescribed classical mean. The proof
does not infer compact support for means of arbitrary
sources. For the transverse g0 vector source the boundary
quadratic terms vanish on the mean support; j_Lambda=0
by transversality. The internal scalar Q_sigma need not
vanish on the two or more loop edges.

A separate check uses the two ordinary source roots in
the no-Q raw coefficient. For j=−K0 B_R the transverse
root factors give f_delta(p)^2 exp(−4t p²). With the
core's power 3/(8t) from V892, subtracting D_t B_0 would
leave −3 p²/2 times f_delta² in P0 units. The full
regulated D_t B_t removes that term. Only after the common
conversion and K0 G_F=1 contact is compact support used
to kill exterior switch-only chains. At t=0 the two
direct root profiles tend to one on spacelike support.

## Converted loop and fixed-order weak limit

In the common cyclic trace let G_theta=(1+theta G Q)^-1 G.
For the B² component the two terms are
Tr(G_theta V2)/2−Tr(G_theta V1 G_theta V1)/4.
At theta^n the terms are the n+1 edge seagull cycle and
the n+2 edge two-linear-vertex cycles with every split
of the n insertions between the two branches. This follows
also by expanding the absolute trace-log and using cyclic
rotation. In the raw heat prescription the clocks are
2(n+1) and 2(n+2). The cyclic expansion is used after
the common conversion. The compact cycle extensions and
tempered boundary values are those of COS1, with b and
the local terms on the same parent. A local mixed Q,B
counterterm vanishes on the compact plateau slice because
the supports of Q and B_R are disjoint. The same argument
includes derivatives of local counterterms. At n=0 the
massive Feynman form factor is the V892 converted result
by the actual vertex identity, with B_R in place of A.

At n>=1 let k_1,...,k_n be the independent switch transfers
and p the first B transfer. The other B transfer is
−p−sum k_i. The normalized massive one-loop kernels
are tempered in these variables by the compact cycle
construction and its finite local extension. For all
|k_i| sufficiently small, uniformly on a slightly enlarged
compact spacelike p support, their Feynman parameter
denominator is

    M − sum_(i<j) alpha_i alpha_j (P_i−P_j)^2 − i0.

At k_i=0 every difference is 0 or ±p, so the real part
is at least M on the whole simplex. At fixed n, continuity
on the compact simplex and p region gives a lower bound
M/2 on a small transfer neighborhood. The two derivative
vertices give at most a quadratic loop numerator.
After the specified local subtraction the parameter
integrands on that neighborhood are polynomials, log
Delta, or powers of Delta with finite coefficients.
They give a smooth bounded kernel there. The seagull
branch obeys the same argument. This uses the analytic
massive boundary on the selected region, rather than
rotating a positive heat profile or a test function.

The Fourier switch factor is
Qhat_R(k)=−k_M² R^4 chihat(R k)/2. Its L1 norm is O(R^-2).
Outside any fixed neighborhood of k=0 each Schwartz
seminorm of the localized factor decreases faster than any
power of R. The unlocalized seminorms grow by at most a
power of R at every fixed derivative order. Insert a
partition into the small k region and its complement.
In the inner region use boundedness of the kernel and
the product L1 bound O(R^-2n). The remaining p factor is
Schwartz. Replacing B_R by B in this argument has an error
smaller than any inverse power by the Schwartz convergence
and temperateness, since all other seminorms grow only
polynomially. Outside the inner region, at least one
localized switch factor has rapid seminorm decay. Continuity
of the tempered distribution gives rapid decay of that
part too. This establishes the weak limit of each fixed
boundary count, with rate O(R^-2n) for n>=1. The n=0
term tends to the nonzero interacting scalar cycle by
tempered continuity and the V892 normalization match.

## Nonblind mass-insertion and source checks

At n=1 the two grouped terms are
−Tr(G Q G V2)/2 and +Tr(G Q G V1 G V1)/2.
At zero insertion transfer the group equals the M
derivative of the converted two-B kernel. This follows
from dG/dM=−G² with the same analytic conversion and
first dimension jet. It keeps the seagull partner and
does not differentiate a raw word at its old clock.
In the stripped transverse form factor the derivative
is −integral (1−2u)^2/[M+u(1−u)z] du, nonzero.
At z=9M/4 its value times M is
−(16/9)[(5/6)log 4−1]. Thus the suppressed kernel is
nonzero. A constant mass insertion is a kernel
diagnostic; the compact Q_sigma itself integrates to zero.
The nonlocal two-B shape at n=0 remains nonzero under
any choice of the inherited symbolic Laurent constant.

The limit here concerns the one-loop physical Phi54
contribution to the two-B coefficient on the stated
transverse mean slice, with each finite boundary count.
Summing all boundary counts at unit strength, other
scalar mass-difference terms, arbitrary causal products,
and the massless mixed gauge/ghost limit require separate
arguments. In particular this does not establish the
infrared normalization assumptions of Duch's weak
adiabatic theorem [primary paper](https://arxiv.org/abs/1801.10147).
V883's paired massless constraint remains relevant.
Both exact routes share model inputs, conventions, software
and AI authorship.
