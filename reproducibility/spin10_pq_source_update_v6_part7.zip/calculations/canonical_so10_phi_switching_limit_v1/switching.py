"""Physical Phi54 vertices and weak switching controls."""

import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


def load(path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as file:
            return json.load(file)
    return json.loads(path.read_bytes())


def calculation(owner, name):
    return load(ROOT/"calculations"/("canonical_so10_"+owner)/name)


def coefficient(cells, grade):
    total = sp.S.Zero
    for (g, xi, eta, mask), num, den in cells:
        assert (g, xi, eta) == (grade, 0, 0) and mask < 16
        radical = sp.prod(p for i, p in enumerate((2, 3, 5, 7)) if mask & (1 << i))
        total += sp.Rational(num, den)*sp.sqrt(radical)
    return sp.expand(total)


def physical(role):
    packet = "native_v2" if role == "native" else "replay_v4"
    owner = "physical_current_input_recovery_g1_v1"
    density = calculation(owner, packet+"_action.json.gz")
    coefficients = calculation(owner, packet+"_coefficients.json.gz")
    rho = {(i,j): coefficient(cells, 0) for i,j,cells in dict(coefficients["rho"])[0]
           if i < 54 and j < 54}
    assert len(rho) == 98 and all(rho[j,i] == -val for (i,j),val in rho.items())
    assert sum(val*val for val in rho.values()) == 12

    rows = [dict() for _ in range(4)]
    for word, cells in density["S1_scalar"]:
        (port, port_jet), (i, left), (j, right) = word
        if port >= 4 or not (180 <= i < 234 and 180 <= j < 234):
            continue
        assert not port_jet and left+right == [port]
        key = (i-180,j-180) if left else (j-180,i-180)
        assert key not in rows[port]
        rows[port][key] = coefficient(cells, 1)
    assert all(table == rho for table in rows)
    free = [word for word,c in density["S0_scalar"] if 180 <= word[0][0] < 234 and
            coefficient(c, 0) == sp.Rational(1, 2)]
    assert free == [[[i,[mu]],[i,[mu]]] for i in range(180,234) for mu in range(4)]

    ref = calculation("current_background_reference_bridge_v1", "result_a.json")["compared"]
    reference = {(i-180,j-180): sp.sympify(c) for i,j,c in ref["twelve_current_homogeneous_carriers"][0]
                 if 180 <= i < 234 and 180 <= j < 234}
    assert reference == {key: -val for key,val in rho.items()}
    assert [180,180,[],"Mref_Phi_squared"] in ref["transported_ordered_Weyl_coefficients"]
    for mu in range(4):
        assert [180,180,[mu,mu],"-1"] in ref["transported_ordered_Weyl_coefficients"]

    action = load(PK/"frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json")
    term = next(x for x in action["local_terms"] if x["term_id"] == "kinetic_Phi")
    density_ast = term["density"]
    assert density_ast["metric"] == "diag(1,-1,-1,-1)"
    prefactor, left, right = density_ast["expression"]["expression"]["factors"]
    assert prefactor["value"] == "1/2" and left == right and left["node"] == "Add"
    derivative, gauge = left["terms"]
    assert derivative["node"] == "PartialDerivative" and derivative["argument"]["name"] == "x_Phi"
    assert [part["name"] for part in gauge["expression"]["factors"]] == ["g10","rho_Phi","B","x_Phi"]
    seagull = sum(val*val for (i,j),val in rho.items() if j == 0)/2
    assert seagull == sp.Rational(4, 5)
    return {"actual_cubic_rows": sum(map(len, rows)), "reference_trace": 12,
            "actual_B0_squared_x180_squared_density_over_g2": str(seagull)}


def boundary():
    t = sp.Symbol("t")
    x = sp.Function("x")(t)
    s = sp.Function("sigma")(t)
    lag = s*(sp.diff(x,t)**2+x*sp.diff(x,t,2))/2
    euler = sp.diff(lag,x)-sp.diff(sp.diff(lag,sp.diff(x,t)),t)+sp.diff(sp.diff(lag,sp.diff(x,t,2)),t,2)
    assert sp.expand(euler) == x*sp.diff(s,t,2)/2
    assert sp.expand(euler).subs(s,t*t).doit() == x
    R,k = sp.symbols("R k", positive=True)
    chi = sp.Function("chi")
    q = -k*k*R**4*chi(R*k)/2
    p = sp.Symbol("p", positive=True)
    assert q.subs(k,p/R)/R**4 == -p*p*chi(p)/(2*R**2)
    return {"switch_Hessian_factor": "1/2", "nonconstant_switch_witness": 1,
            "fixed_count_power": "-2*n"}


def loop_controls(role):
    v = sp.Symbol("v", positive=True)
    z = sp.Symbol("z", positive=True)
    M = sp.Symbol("M", positive=True)
    t = sp.Symbol("t", positive=True)
    w = (1-2*v)**2
    if role == "native":
        result = -sp.integrate(w/(1+sp.Rational(9,4)*v*(1-v)), (v,0,1))
    else:
        a = sp.Rational(5,3)
        primitive = -v+a*sp.log((a+v)/(a-v))/2
        assert sp.cancel(sp.diff(primitive,v)-v*v/(a*a-v*v)) == 0
        result = -sp.Rational(16,9)*(primitive.subs(v,1)-primitive.subs(v,0))
    expected = -sp.Rational(16,9)*(sp.Rational(5,6)*sp.log(4)-1)
    assert sp.simplify(sp.expand_log(result-expected, force=True)) == 0
    assert sp.integrate(w,(v,0,1)) == sp.Rational(1,3)
    exact = sp.series(3*(sp.exp(-4*t*z)-1)/(8*t),t,0,1).removeO()
    assert exact == -3*z/2
    g = 1/(v+M)
    u1,u2 = sp.symbols("V1 V2")
    assert sp.expand(sp.diff(g*u2/2-g*g*u1*u1/4,M)-(-g*g*u2/2+g**3*u1*u1/2)) == 0
    return {"M_times_converted_mass_response_at_z_over_M_9_over_4": str(expected),
            "actual_clocks_one_boundary": [4,6],
            "wrong_unregulated_forest_finite_over_P0": str(exact)}


def checks(role):
    return {"physical": physical(role), "boundary": boundary(), "loop": loop_controls(role)}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
