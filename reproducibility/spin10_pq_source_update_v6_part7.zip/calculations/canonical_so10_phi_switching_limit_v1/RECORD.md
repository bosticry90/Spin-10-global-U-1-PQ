# V893 pre-execution contract

Test the physical Phi54 g² one-loop B two-point coefficient
with the actual compact switching boundary, on a transverse
classical mean slice. Keep the common causal and direct
normalization from V892, true clocks, full regulated roots,
positive Phi reference mass, zero scalar mass-difference degree,
and zero A and retained sources. Fix a compact spacelike Fourier
support away from the light cone and real compact dilated
switches. Retain each fixed number of switch-only scalar
quadratic vertices. Use the compact source stationarity map.

Bind both physical g1 routes, literal quartic AST, the current
reference and its switch-current calculation, COS1, V871 and
V892. Check actual cubic and quartic coefficients and both
signs of the scalar derivative convention. Derive the boundary
Hessian and a nonzero constant-insertion diagnostic for the
complete seagull plus triangle. Test omission of the regulated
source roots in the UV subtraction. Show uniform small-switch
transfer analyticity at each fixed count and rapid tail decay
against the actual tempered extensions. No inverse coupling.

Native limit 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch commit floor, 8 MiB
artifact and 32 MiB packet. Freeze proof, sources and owner
bytes, require replay and exact staged bytes. The ceiling is
this selected interacting massive coefficient at each fixed
boundary count. No summation of the count, unrestricted
Lorentzian products or model-wide weak adiabatic claim.
