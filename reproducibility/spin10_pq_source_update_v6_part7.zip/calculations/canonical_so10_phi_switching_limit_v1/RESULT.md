# V893 — Physical Phi loop with its switching boundary

The actual physical B kinetic bubble and seagull have the
same normalized form factor as the Phi54 reference kernel
on the chosen mean slice. Both routes match 392 literal
cubic rows. The quartic is lowered from the covariant AST,
with the B0 squared x180 squared coefficient 4 g²/5.
The ordinary source roots require the full regulated UV
forest subtraction. Replacing it by unregulated roots
would leave a finite transverse term.

The literal free scalar density and its Euler-normal
reference produce the actual switch Hessian Q_sigma=
(Box sigma)/2 at zero scalar mass-difference degree.
The single-insertion loop kernel is nonzero: its grouped
zero-transfer limit is the mass derivative of the
converted two-B kernel. For each fixed positive boundary
count n, spacelike transfer analyticity and tempered tail
bounds give O(R^-2n) for the compact dilated switches.
The zero-boundary term converges to the nonzero direct
interacting cycle on the prescribed transverse mean slice.

Require the final replay receipt and capture. The result
uses inherited normalization and the actual scalar block.
The routes share the action, software and AI authorship.
It covers each finite boundary count separately. A sum at
unit boundary strength, arbitrary mean/source labels,
massless coupled loops, full causal equivalence and
E5/A5 remain open.
