from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/new-physical-returning-inventory-g1-recovery-v1-2026-11-06')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_capture.json')).exists()
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='e8afd45f5be4182933159d3925b8eb07b922ae8f'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/LOCAL_STORAGE_LAYOUT_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V787.md',
 'calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/quantum.py','calculations/canonical_so10_full_jet_source_master_bridge/jets.py',
 'calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
 'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz','calculations/canonical_so10_mixed_Ward_positive_coupling/validation_receipt.json']
 for r in ['primary','replay']:names.append('calculations/canonical_so10_full_jet_source_master_bridge/'+r+'_tables.json.gz')
 physical='calculations/canonical_so10_physical_current_input_recovery_g1_v1/'
 names += [physical+n for n in ['validation_receipt.json','PROOF.md','physical_v2.py','physical_v4.py']]
 for prefix in ['native_v2_','replay_v4_']:
  names += [physical+prefix+n+'.json.gz' for n in ['marked_kernels','ordinary_gauge','ordinary_scalar']]
 names=sorted(set(names))
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n]),n
 for n in ['RECORD.md','inventory.py','run.py']:
  with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
 digest=lambda p:sha256(p.read_bytes()).hexdigest()
 dump(O/'preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in ['RECORD.md','inventory.py','run.py']},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD']))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'inventory.py'),route]);dump(O/(route+'_capture.json'),cap);dump(C/(route+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
