"""Exact controls for the finite paired ghost/source transport."""

from collections import Counter, defaultdict
from functools import cache
import json
import sys

import sympy as sp

from execute import PK, run_worker


z_h, z_m, g, xi = sp.symbols("zH zM g10 xi")
symbols = {"zH": z_h, "zM": z_m, "g10": g, "xi": xi}


@cache
def coef(text):
    return sp.sympify(text, locals=symbols)


def packet(owner, route):
    return json.loads((PK / ("frozen_a10_" + owner) / (route + ".json")).read_bytes())


def ghost(name):
    return name.startswith("C") and name[1:].isdigit()


def antighost(name):
    return name.startswith("ub") and name[2:].isdigit()


def odd(name):
    return ghost(name) or antighost(name)


def canonical(word):
    odd_order = [name for name in word if odd(name)]
    if len(set(odd_order)) != len(odd_order):
        return tuple(sorted(word)), 0
    swaps = sum(a > b for i, a in enumerate(odd_order) for b in odd_order[i+1:])
    return tuple(sorted(word)), (-1)**swaps


def reduced(rows):
    return {key: value for key, expr in rows.items() if (value := sp.expand(expr)) != 0}


def compare_shift(frozen):
    maps = frozen["finite_maps"]
    weights = {f"C{i}": coef(maps[f"C{i}"][0]["coefficient"]) for i in range(45)}
    assert Counter(weights.values()) == {z_h: 12, z_m: 33}
    expected = defaultdict(dict)
    for row in frozen["generating_fermion_difference"]:
        word = row["word"]
        assert len(word) == 3 and ghost(word[0]) and all(antighost(x) for x in word[1:])
        assert weights[word[0]] == z_m and all(weights["C"+x[2:]] == z_m for x in word[1:])
        coefficient = coef(row["coefficient"])
        assert coefficient.subs(z_m, 1) == 0 and z_h not in coefficient.free_symbols
        for i, name in enumerate(word):
            key = tuple(word[:i] + word[i+1:])
            slot = expected["J"+name]
            slot[key] = slot.get(key, 0) + (-1)**i * coefficient/z_m
    assert len(frozen["generating_fermion_difference"]) == 138
    actual = {}
    assert len(maps) == 1286
    for name, rows in maps.items():
        linear = [coef(row["coefficient"]) for row in rows if row["word"] == [name]]
        expected_weight = weights.get(name, 1/weights[name[1:]] if name.startswith("JC") else sp.S.One)
        assert linear == [expected_weight], name
        shift = defaultdict(lambda: sp.S.Zero)
        for row in rows:
            word = tuple(row["word"])
            if word == (name,):
                continue
            assert len(word) == 2 and all(odd(x) for x in word)
            shift[word] += coef(row["coefficient"])/sp.prod(weights.get(x, 1) for x in word)
        if shift:
            actual[name] = reduced(shift)
    assert actual == {name: reduced(rows) for name, rows in expected.items()}
    counts = Counter()
    for name, rows in actual.items():
        counts["JC" if name.startswith("JC") else "Jub"] += len(rows)
    assert counts == {"JC": 138, "Jub": 276}
    assert len(actual) == 66
    assert frozen["transported_contraction_columns"]["C0"] == [{"coefficient": "1/zH", "word": ["omega0"]}]
    assert frozen["fixed_contraction_defect"] == [{"coefficient": "zH - 1", "word": ["omega0__0"]}]
    return weights, actual, dict(counts)


def support(word):
    if len(word) == 3 and sum(ghost(x) for x in word) == sum(antighost(x) for x in word) == 1:
        if any(x.startswith("L") and x[1:].isdigit() for x in word):
            return "L"
    if len(word) == 4 and sum(ghost(x) for x in word) == sum(antighost(x) for x in word) == 2:
        return "four_ghost"
    return None


def literal_action(frozen, weights, shift, route):
    result = defaultdict(lambda: sp.S.Zero)
    for row in packet("bv_master", route)["source_polynomial"]:
        word = row["word"]
        retained = [i for i, x in enumerate(word) if x.startswith("J")]
        assert len(retained) == 1
        i = retained[0]
        for replacement, value in shift.get(word[i], {}).items():
            key, sign = canonical(word[:i] + list(replacement) + word[i+1:])
            if sign:
                assert support(key), key
                result[key] += sign*value*coef(row["coefficient"])
    result = reduced(result)

    def cell_map(rows, undo_scale):
        cells = {}
        for row in rows:
            if support(row["word"]):
                key, sign = canonical(row["word"])
                assert key not in cells and sign != 0
                factor = sp.prod(weights.get(x, 1) for x in key) if undo_scale else 1
                cells[key] = sign*coef(row["coefficient"])/factor
        return cells

    original = cell_map(packet("e2_transport", route)["gauge_fixing_density"], False)
    forward = cell_map(frozen["finite_source_action"], True)
    observed = reduced({key: forward.get(key, 0)-original.get(key, 0) for key in forward.keys() | original.keys()})
    assert result == observed
    l_word = ("C12", "L13", "ub44")
    q_word = ("C13", "C44", "ub13", "ub44")
    assert sp.simplify(result[l_word] - sp.sqrt(2)*sp.I*xi*(1-z_m)/(4*z_m)) == 0
    assert sp.simplify(result[q_word] - 2*g*xi*(z_m-1)/(5*z_m)) == 0
    traces = defaultdict(lambda: sp.S.Zero)
    for word, value in result.items():
        if support(word) == "L":
            c, lam, a = word
            assert c.startswith("C") and lam.startswith("L") and a.startswith("ub")
            assert value.free_symbols <= {z_m, xi}
            if c[1:] == a[2:]:
                traces[lam] += value
        else:
            assert value.free_symbols <= {g, xi, z_m, z_h}
            assert value.subs(g, 0) == 0
    assert not reduced(traces)
    counts = Counter(support(word) for word in result)
    return {"source_free_shift_rows": dict(counts), "heavy_tadpole_trace": 0,
            "auxiliary_witness": str(sp.factor(result[l_word])),
            "quartic_witness": str(sp.factor(result[q_word]))}


def normalized_controls():
    # One ghost pair with the C endpoint scaled. Compare inverse congruence
    # with using the old IR inverse and a resummed quadratic letter.
    f = sp.Rational(1, 4)
    t = sp.diag(2, 1)
    g_f = sp.Matrix([[0, f], [-f, 0]])
    t_inv = t.inv()
    new = t_inv*g_f*t_inv.T
    wrong = f/(1+(2-1)*f)
    assert new[0, 1] == sp.Rational(1, 8) and wrong == sp.Rational(1, 5)

    # Exact normalized rooted ghost coefficient with two independent
    # source leaves and one ordinary background root.
    theta, k, p, r, ell = sp.symbols("theta k p r ell", nonzero=True)
    coefficient = k/(p+theta*r*ell)
    first = sp.diff(coefficient, theta).subs(theta, 0)
    second = sp.diff(coefficient, theta, 2).subs(theta, 0)/2
    assert first == -k*r*ell/p**2 and second == k*r**2*ell**2/p**3
    s = sp.Symbol("s", positive=True)
    residual = sp.integrate((1-sp.exp(-s))**2-1, (s, 0, sp.oo))
    assert residual == -sp.Rational(3, 2)
    return {"transported_profile": str(new[0, 1]), "old_profile_resummed": str(wrong),
            "mixed_response_first": str(first), "mixed_response_second": str(second),
            "quartic_radial_residual_over_epsilon_squared": str(residual)}


def checks(role):
    route = "primary" if role == "native" else "replay"
    frozen = packet("e5_quotient", route)
    weights, shift, counts = compare_shift(frozen)
    return {"finite_shift": counts, "action": literal_action(frozen, weights, shift, route),
            "normalized": normalized_controls()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
