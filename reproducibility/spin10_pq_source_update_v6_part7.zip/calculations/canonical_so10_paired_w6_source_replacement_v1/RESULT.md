# V891 — Finite W6 source replacement in the paired Euclidean map

The exact two-parameter ghost/source pullback factors into a
constant field change with transported covariance and an
external-source translation. The latter gives the whole
parent S_theta=S+theta P. Its connected insertion is the
derivative of the same normalized functional, including
the proper and rooted terms at every required theta order.

Both frozen routes reproduce 414 quadratic source-shift
rows and the complete source-free difference in the
allowed support, with 276 auxiliary–ghost and 648
four-ghost rows. The auxiliary tadpole trace vanishes.
The quartic seagull has a zero uncut massless finite part
and a paired cutoff residual proportional to epsilon^2.
The new mixed gauge/auxiliary–ghost loop has the derivative
gain needed for the paired forest, leaving the massive
cancellation intact. Finite covariance transport and a
nonzero mixed source control distinguish the complete
replacement from keeping the old regulated inverse or
retaining only the first insertion.

Require the final replay receipt and capture. This
qualifies this family's action/insertion replacement at
tree and one loop in the direct paired Euclidean domain.
The two routes share the action, mathematical chart,
software and AI authorship. General causal realization,
renormalized observable equivalence and A5 remain open.
