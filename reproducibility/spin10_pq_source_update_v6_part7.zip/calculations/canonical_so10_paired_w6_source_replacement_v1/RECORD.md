# V891 pre-execution contract

Test the actual W6 two-parameter finite ghost/source family on
the direct paired Euclidean tree/one-loop map. Keep the full
643-field parent and retained sources, real invertible Laurent
units, positive reference, paired profiles, A and the V887
independent smooth compact Fourier tests at each finite g and
scalar mass-difference degree. Transport the flat and
background references by the constant field change. Freeze
one exact residual source-shift direction and all its finite
coefficient derivatives. No fixed physical normalization.

Bind the sealed canonical quotient, both E2/BV routes and the
paired proofs. Derive every quadratic source shift by the
graded fermion derivative and compare the whole supported
action difference to the frozen finite action after inverse
scaling. Require literal cubic and quartic witnesses and
the actual zero auxiliary tadpole trace. Check finite
profile transport and nonzero mixed connected coefficients
on exact controls. Prove the additional massless forest
bounds. Fail on any unmapped source term, extra vertex type,
wrong sign or mismatched transport.

Limits are native 120 s, final 180 s including E4 cap of
120 s, 8 GiB sampled private, 350 MiB launch commit floor,
8 MiB artifact, 32 MiB packet. Freeze code/proof and owner
bytes. Final replay and exact staged bytes are required.
Ceiling is this family's paired Euclidean action/source
replacement and derivatives of the common normalized map
through one loop. General causal products, observable
equivalence, protected E5/A5 and physical viability remain
outside scope.
