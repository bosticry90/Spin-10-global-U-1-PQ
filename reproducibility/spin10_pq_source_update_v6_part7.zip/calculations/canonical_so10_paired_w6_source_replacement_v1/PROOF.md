# Finite ghost/source transport in the paired Euclidean map

Take the qualified two-parameter canonical pullback V'=U_Gamma V.
Write V as the constant ordinary field matrix t and inverse
evaluation dual t_J. All parameters are real Laurent units.
Gamma=Psi−V Psi contains only the heavy cubic ghost fermion.
In the original pullback coordinates the retained source is
t_J(J−s E_z Gamma), with s_i=(-1)^p_i. Set y=t z, j'=j t^-1
and J'=t_J J. The chain rule puts the residual translation
at fixed y in the form

    Delta J_i(y)=−s_i E_yi(V^-1 Psi−Psi).

This is U_{Gamma'} with Gamma'=V^-1 Gamma. It is a field-dependent
external-source translation. It changes no integration variable.
The parent is affine in the retained sources and Delta J is
independent of J. Thus its action replacement is exact:

    S_theta[y,J']=S[y,J']+theta P[y],
    P=sum_i Delta J_i E^L_Ji S.

Use the displayed order. theta interpolates this residual shift
at fixed units, so it does not vary t or the reference. The
414 nontrivial finite shifts are all in the JC or
heavy antighost source columns. The two routes compare the
complete shifted support below. The physical action and A are
spectators. Operators and insertion sources transport along
the same map. In particular the actual iota C_H becomes
omega_H/z_H and the fixed-iota free difference remains nonzero.

## Constant transport and the full connected derivative

Transport the flat covariance to t^-1 G_f t^-sharp and the
background reference by congruence. The regulator acts with
the same flat profile in the corresponding entries. At finite
mode count the Berezinian is the product of the 12 H and 33 M
ghost factors per retained mode. It is field, source and A
independent, and cancels in the normalized ratio. At the formal
forest level the same result follows by contracting inverse
t factors on every internal endpoint. All traces are conjugate,
all exterior ordinary sources use j', and the same reference
determinant enters once. The fixed normalization transports
the full local b term and each true clock. Keeping the old
covariance and resumming a new quadratic vertex at fixed profile
would give a different regulator map.

For one deformation strength with all retained sources kept,

    d W_theta/d theta = I^W_P[S_theta].

This is differentiation of the complete normalized functional,
including both its proper determinant and its rooted mean.
Mixed ordinary, retained and insertion derivatives act on that
same family. Even though P is source free, a mixed derivative
through the mean or a propagator can be nonzero. An exact
Gaussian fixture exhibits both a nonzero first mixed response
and a nonzero next theta coefficient. The difference at theta=1
is the formal integral of I^W_P[S_theta] from zero to one.
It is not a single insertion evaluated at theta=0.

## The direct paired boundary for this new parent

The only extra vertices are L=Lambda_M a_M C_M and four
ghosts, with zero derivatives. The gamma derivatives in
J_aM multiply -Lambda_M+g C_H a_M. The ones in J_CM
multiply g C C. No new constant Hessian, physical potential,
background or scalar vertex appears. This uses the actual
source driver, not just a dimension-based permission. At
each fixed number of independent test labels the number of
these new vertices is bounded: after collapsing constant
chains, the connected identity sum_v(deg v−2)=2 ell−2
allows only finitely many vertices of degree at least three.
The degree-one deficits are bounded by the label count.
Hence theta=1 is coefficientwise finite at tree and one loop.

The heavy dual-basis color tensor in the cubic fermion is
t^{ij}_k=f^i_{ak}(G_M^-1)^{aj}. The actual returning ghost
inverse is the paired diagonal evaluation inverse. The
cubic trace t^{ij}_j vanishes by antisymmetry against the
symmetric inverse Gram. Antisymmetry in i,j handles the
other antighost. This zero holds before taking the paired
limit. The quartic seagull is a pure massless power at zero
loop transfer. Its common T_kappa finite part is zero and
the radial paired residual is -3 epsilon^2/2, before the
four-dimensional angular and ordered Wick factors. Its
remaining aC exits can contribute only the ordinary logs.
A second cubic sewn to the seagull gives at least three exits.
There is no direct massive tadpole sewing at a ghost port.

The new L−F two-port has mixed B Lambda order one and ghost
order two. F has one derivative, bounded by the sum of the
two line momenta. The resulting total order is at most two.
The shifted Gaussian estimate gives O(epsilon^2) at bounded
transfer. The UV-converted uncut coefficient has soft order
p^2 up to logs by dilation and the same finite-part rule.
L−L and L−Y vanish by the unchanged Lambda Lambda and
Lambda x inverses. The mixed Lambda B inverse cannot gain
a massive dressing through a constant Lambda x chain.
Thus the V887 massive aC cancellation and the BB group
are unchanged. The new L cut-cycle singleton gains at
its auxiliary port. A quartic already has the strict
valence margin. The ordinary forced-zero and paired forest
estimates therefore extend without assigning a momentum
label to constant theta. The new Hessian letters have one
or two ordinary fields of positive total dimension. The
same hard symbol subtraction, whole b normalization and
regulated D_t B_t apply with their actual word lengths.

In the compact parent the change is theta sigma P with the
same switching jets. This algebraic observation retains the
currents and supplies no compact-to-uncut limit. The direct
paired result is a selected W6 insertion realization of
the two-parameter family through one loop. Equality of
renormalized physical observables, arbitrary nonlinear
composite transport, causal realization and A5 require
separate justification.
