# V950 pre-execution contract

Compute the ordinary lower ghost kinetic and polarized
switch companions of the V945 two-edge normalization.
Freeze the V879 derivative placements, four H/M internal
sectors, and preserved transverse derivative identity.
Compare every literal sector matrix and the V945 source
matrix. Retain the left and right exterior switch terms
until the end and verify the light spectator coefficient.

Derive the necessary free auxiliary companion in the
common stripped convention with q_a fixed. Do not
assign a finite value to the ordinary auxiliary graph
or infer compact master closure. Native 120 s, final
180 s including E4 cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
No authority change.
