"""Reconstruct the lower gauge source map with all literal derivatives."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    F = {}
    for g, word, cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (b,db), (c,dc), (a,da) = word
        if b >= 180 or b%4 != 1 or not 553 <= c < 598:
            continue
        if 598 <= a < 643:
            assert sum(bool(d) for d in (db,dc,da)) == 1 and all(d in ([],[1]) for d in (db,dc,da))
            derivative = "B" if db else "C" if dc else "a"
            key = b//4,a-598,c-553,derivative
            assert key not in F
            F[key] = unpack(cells)
    assert {d:sum(k[3]==d for k in F) for d in ("B","C","a")} == {"B":334,"C":668,"a":1674}
    choices = [defaultdict(lambda:defaultdict(lambda:sp.S.Zero)) for _ in range(4)]
    left, right, switch_left, switch_right = choices
    for (b,a,c,d),z in F.items():
        if d == "a":
            left[b,c][a] += z
            right[b,a][c] -= z
            switch_right[b,a][c] -= z
        elif d == "C":
            left[b,c][a] -= z
            right[b,a][c] += z
            switch_left[b,c][a] -= z

    def contract(A,B):
        result = defaultdict(lambda:defaultdict(lambda:sp.S.Zero))
        for (b,k),ports in A.items():
            sector = ("H" if b<12 else "M")+("H" if k<12 else "M")
            for a,x in ports.items():
                for c,y in B.get((b,k),{}).items():
                    result[sector][a,c] += x*y
        return {sector:source.owner.clean(result[sector]) for sector in ("HH","HM","MH","MM")}

    ordinary = contract(left,right)
    compact_left = contract(switch_left,right)
    compact_right = contract(left,switch_right)
    compact_both = contract(switch_left,switch_right)
    C = defaultdict(lambda:sp.S.Zero)
    for h in range(12):
        for j in range(45):
            for k,x in f[h,j]:
                for i,y in f[h,k]:
                    C[i,j] -= x*y
    C = source.owner.clean(C)
    Ch = {(i,j):z for (i,j),z in C.items() if i < 12 and j < 12}
    Cm = {(i,j):z for (i,j),z in C.items() if i >= 12 and j >= 12}
    Ph = {(i,i):sp.S.One for i in range(12)}
    Pm = {(i,i):sp.S.One for i in range(12,45)}
    expected = {"HH":Ch,"HM":source.add({},Cm,4),"MH":{},"MM":source.add(source.add({},Pm,8),Cm,-2)}
    assert ordinary == expected

    def total(mats):
        out = {}
        for matrix in mats.values():
            out = source.add(out,matrix)
        return out

    actual = total(ordinary)
    LB = source.add(C,Pm,8)
    assert source.add(actual,LB,-1) == Cm
    assert len(actual) == 75
    light = lambda matrix:{(i,j):z for (i,j),z in matrix.items() if i < 12}
    assert not light(total(compact_left)) and not light(total(compact_both))
    assert light(total(compact_right)) == source.add({},Ph,8)
    assert light(actual) == Ch
    return {"ordinary_ghost_kinetic_nonzeros":len(actual),
            "ordinary_ghost_minus_lower_gauge_driver":"C_H|M",
            "light_compact_right_switch":"8 I_H",
            "light_compact_left_switch":0,"light_compact_double_switch":0,
            "projected_compact_nonzero_counts":[len(total(m)) for m in (compact_left,compact_right,compact_both)]}


def unpack(cells):
    assert all(p[:2] == [0,0] for p,_,_ in cells)
    return seagull.unpack([([0,*p],n,d) for p,n,d in cells])


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
