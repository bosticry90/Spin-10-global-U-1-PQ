# V950 result — ordinary ghost kinetic and compact auxiliary companion

The lower ordinary two-cubic ghost kinetic contact has
75 nonzero color entries. Its full matrix exceeds the
V945 lower gauge driver by the broken light Casimir
C_H restricted to M. With the free antighost driver
held fixed this is the required stripped companion
coefficient of Lambda div B.

Keeping the switch labels at both ordinary vertices
gives the expected light right-switch term 8 I_H.
The light left-switch and double-switch terms vanish.
The resulting ordinary compact light-antighost
coefficient is the exact spectator counterpart of
the V946 lower gauge-source term.

Both routes reproduce the full ordinary sector
matrices. No finite auxiliary graph coefficient,
changed antighost driver or compact master identity
has been adopted. The two routes share the model,
software and AI authorship.

Next test the actual auxiliary ordinary graph and
carry the scalar quadratic partner of the V949
ordinary kinetic bubble. A species-weight conclusion
for a fixed scalar quadratic does not automatically
extend to the linked scalar kinetic identity.
