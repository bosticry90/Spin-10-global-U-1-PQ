# Ordinary ghost kinetic and compact light-antighost companions

Apply the V945 transverse rule to an ordinary pair of
BCa cubics with one internal BB and one ghost line.
At the left vertex the antighost is external, and at
the right vertex the ghost is external. With labeled
switches s_a and s_C, the derivative contrasts are

    s_a (d_a-d_C) partial a - (partial s_a) d_C a,
    s_C (d_C-d_a) partial C - (partial s_C) d_a C.

These are the literal direct external derivatives
and the derivatives transferred from the internal
ghost. The internal B divergence vanishes in this
transverse prescription. The common Grassmann and
diagram factors are kept outside the matrices in the
same stripped convention as V945.

The complete ordinary kinetic matrices by internal
(B,ghost) sector are

    HH=C_H|H, HM=4 C_H|M, MH=0, MM=8 P_M-2 C_H|M.

Their sum is K=8 P_M+C_H|H+2 C_H|M. The lower source
matrix is L_B=8 P_M+C_H. Thus the ordinary kinetic
matrix exceeds the source matrix by C_H|M.
With q_a fixed and the free quadratic signs used in
V930, the needed correction to Lambda div B has
stripped coefficient K-L_B. Indeed its variation
together with the new q_B term gives L_B+A against
Lambda box C, and the ghost kinetic variation gives
the opposite of K. A possible auxiliary graph or
changed antighost driver has a separate actual
normalization equation.

For light external a, the literal derivative is
only d_a. The left and double exterior switch
terms vanish. The right switch term has exactly
8 I_H, consistent with replacing J_B^H by partial
a_H at the same vertex in V946. On common switches
this gives 8 sigma (partial sigma) partial a_H . C_H
in stripped notation, with the last C denoting the
ordinary light ghost. Integrating by parts against
a constant local C does not eliminate a general
compact switch. No fixed gauge fermion or marked
identity is inferred to supply it.

Both frozen routes reproduce the full displayed
color matrices and light switch projections. They
share the model, conventions, software and authorship.
