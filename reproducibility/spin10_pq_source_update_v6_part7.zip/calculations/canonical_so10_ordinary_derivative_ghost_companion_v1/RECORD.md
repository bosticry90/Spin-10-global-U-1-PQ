# V933 pre-execution contract

Test whether the V932 reciprocal ghost response remains
compatible with the ordinary derivative-ghost kernel when
linear Qa is permitted to move. Freeze the signed V879
g1 ordinary current in both routes, the joined f and K
matrices, the V932 off-orbit coefficient convention, and
the transverse Maxwell free form. Work at A=0, unit switch,
constant ordinary B jet and first derivative of a or C, at
the xi-independent cubic grade induced by a g2 linear map.

Recover the complete derivative tensor on all four axes
and test its H/M structure. Use the fixed h=1,b=30,c=23
antisymmetrized projection, retain general linear ghost
and gauge maps commuting with the H action, and leave the
independent ordinary cubic contribution symbolic. Compare
the literal derivative tensor at one symmetric covariant
and one skew test map. Fail on disagreement in the sign,
support, projection or replay. The result can specify the
necessary independent coefficient or give a bounded
incompatibility when the ordinary coefficient is held
fixed. It cannot infer a zero for an unmeasured amplitude.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
No scientific promotion.
