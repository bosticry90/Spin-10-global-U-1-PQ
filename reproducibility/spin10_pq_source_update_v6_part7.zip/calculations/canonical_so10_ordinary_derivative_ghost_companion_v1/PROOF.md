# Ordinary derivative ghost companion of the reciprocal ghost map

At unit switch with A=0 let b and c be the external gauge
and ghost colors. Hold the ordinary B jet constant. Integration
by parts moves the a derivative to C and changes its sign.
Strip the common temporal sign and use the V879 current order
C before a. The complete ordinary derivative color tensor is

    F(b,c) = [b,c] + [P_H b,c] - [b,P_H c].

The latter two terms together are symmetric in b,c. The
executable extracts both derivative placements from the literal
current, verifies the exact tensor in all four Lorentz axes
and checks the relative axis signs. No retained source
or physical matter term enters this projection.

Let U change the gauge field linearly and K change the ghost
linearly, in the convention of V932. The antighost change
acts on the output of F. In the antisymmetric projection at
b,c in M with [b,c]=0, F(b,c)=F(c,b)=0, so this output change
drops. Even if U or K have mixed blocks, their H components
inserted into F with the other argument in M output M. The
H output of the antisymmetric first-order variation is then

    (1/2) P_H ([(U+K)b,c] + [b,(U+K)c]).

Pair with h in H. By invariance of the color form and covariance
of the M blocks of U and K under h, the expression equals

    (1/2) <[h,b], (U+K+U^t+K^t)c>.

Transverse Maxwell preservation makes U skew. This argument
allows the linear Qa normalization to be transported. It uses
the ordinary derivative ghost coefficient directly.

The selected colors are h=e1, b=e30 and c=e23. The exact
joined bracket is [e1,e30]=e20/2 and [e30,e23]=0. The
antisymmetrized variation therefore equals

    (K[20,23] + K[23,20])/4.

An a.div B gauge fermion gives a term proportional to
[b,c] in this projection. An a.B.B gauge fermion gives a
symmetric input tensor when varied with q_0 B=partial C.
Neither changes the antisymmetrized witness. An auxiliary
shift by aC meets a derivative of B in the mixed gauge term,
which drops at constant B. Its scalar and width terms have
different field content. Other independently prescribed
ordinary cubic or gauge kinetic changes remain separate.

V932 requires both reciprocal entries to be epsilon_Phi/5
under the same ghost-map convention. Thus transporting the
free antighost driver merely moves an obligation to the
ordinary derivative ghost tensor. In the stated units this
canonical change contributes +epsilon_Phi/10 and needs an
independent -epsilon_Phi/10 if the combined coefficient is
required to be zero. The fixed ordinary kernel excludes this
route on the symbolic log family. The result does not set
the independent ordinary coefficient to zero or cover an
independent Maxwell change. The two input routes share the
action, symbolic software and AI authorship.
