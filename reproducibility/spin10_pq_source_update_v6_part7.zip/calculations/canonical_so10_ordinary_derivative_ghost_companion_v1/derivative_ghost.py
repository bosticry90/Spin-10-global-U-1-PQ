"""Recover the ordinary derivative-ghost tensor and its forced companion."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


OWNER = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
SPEC = importlib.util.spec_from_file_location("nonlinear_source_owner", OWNER)
source = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, K, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    raw = [defaultdict(lambda: sp.S.Zero) for _ in range(4)]
    derivative_rows = 0
    for g, word, cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (B, dB), (C, dC), (a, da) = word
        if B >= 180 or not 553 <= C < 598 or not 598 <= a < 643 or dB:
            continue
        mu = B % 4
        assert (dC, da) in (([mu], []), ([], [mu]))
        assert all(p[:2] == [0, 0] for p, _, _ in cells)
        z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
        raw[mu][B//4, a-598, C-553] += z if dC else -z
        derivative_rows += 1
    expected = {}
    for (b, c), outputs in f.items():
        for a, z in outputs:
            factor = 1 + int(b < 12) - int(c < 12)
            if factor:
                expected[b, a, c] = factor*z
    signs = []
    for result in raw:
        simplified = source.owner.clean(result)
        sign = sp.cancel(simplified[0, 2, 1]/expected[0, 2, 1])
        assert sign in (1, -1)
        assert simplified == {key: sign*z for key, z in expected.items()}
        signs.append(int(sign))
    assert signs[0] == 1
    assert derivative_rows == 9368 and len(expected) == 1340

    h, b, c = 1, 30, 23
    h_action = {j: dict(f[h, j]) for j in range(45)}
    assert not f[b, c]
    assert h_action[b] == {20: sp.Rational(1, 2)}
    assert K[c][20] == K[20][c] == -sp.Rational(1, 5)

    # Independent evaluation of the derivative tensor with a particular
    # H-covariant symmetric map and a skew control on the selected plane.
    for j in range(45):
        assert source.on_colors(K, h_action[j]) == source.on_colors(h_action, K[j])
    D = source.owner.clean(raw[0])

    def variation(U, W):
        def ordered(x, y):
            return sp.expand(sum(z*D.get((i, h, y), 0) for i, z in U[x].items())
                             +sum(z*D.get((x, h, i), 0) for i, z in W[y].items()))
        return (ordered(b, c)-ordered(c, b))/2

    zero = {j: {} for j in range(45)}
    assert variation(zero, K) == -sp.Rational(1, 10)
    assert variation(h_action, zero) == variation(zero, h_action) == 0

    # The two source projections fix the symmetric pair in V932.
    # The literal derivative tensor then has the specified nonzero
    # companion. Keep its independent ordinary contribution symbolic.
    eps, k1, k2, ordinary = sp.symbols("epsilon_Phi k1 k2 d_ordinary")
    induced = (k1+k2)/4
    equations = (k1-eps/5, k2-eps/5, induced+ordinary)
    solution, = sp.solve(equations, (k1, k2, ordinary), dict=True)
    assert solution[ordinary] == -eps/10
    fixed, = sp.solve(equations + (ordinary,), (k1, k2, ordinary, eps), dict=True)
    assert fixed[eps] == 0
    return {"literal_derivative_rows": derivative_rows, "reduced_nonzero_per_axis": len(expected),
            "lorentz_signs": signs, "witness": {"a": h, "B": b, "C": c, "ad_h_B": "e20/2"},
            "antisymmetric_induced": "epsilon_Phi/10", "ordinary_required": "-epsilon_Phi/10",
            "fixed_ordinary_forces_epsilon_Phi_zero": True}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
