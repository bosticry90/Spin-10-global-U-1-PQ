# The source-linearity restriction is unnecessary for the exact Taylor step

The older [mixed-probe proof](../canonical_so10_mixed_probe_slavnov/DERIVATION.md)
states source-linearity in its master-Hessian step. Current U0 contains Ja²,
so that literal hypothesis cannot simply be assumed. Here the relevant
algebraic step is proved with arbitrary source dependence. It does not extend
the continuum trace/domain theorem merely by changing its wording.

Let Sigma be even and let s_i=(-1)^p_i. In the actual source-left chart set

    F_i=s_i EL^L_Ji Sigma, E_i=EL^L_zi Sigma,
    B=sum_i F_i E_i,
    Q_Sigma=sum_i F_i EL^L_zi+s_i E_i EL^L_Ji.

All sources remain external. Take the even ordinary field Taylor operation
T,with its graded fluctuation legs and sources/labels fixed. Put H=T²Sigma/2.
The ordinary product rule gives

    T²B/2=sum_i [(T²F_i/2)E_i+(TF_i)(TE_i)+F_i(T²E_i/2)].

T commutes with the full LEFT source derivative; hence
EL_Ji H=s_i T²F_i/2, without any assumption on Sigma_JJ. Since p(E_i)=p_i
and p(F_i)=p_i+1, E_i commutes with T²F_i. Therefore exactly

    Q_Sigma H=sum_i [F_i(T²E_i/2)+(T²F_i/2)E_i],
    T²B/2=Q_Sigma H+sum_i (TF_i)(TE_i).

This retains the nonlinear source-Euler leg. It is the term that cannot be
dropped when F depends on sources. No separate extra Sigma_JJ term is added:
such dependence is already inside FULL F,E and their source derivatives.
Nor is B assumed zero or Q_Sigma assumed nilpotent. In jet calculus use the
qualified Euler/adjoint convention and retain the corresponding currents.
Two even field polarizations give the equivalent Hessian-chain congruence,
with the actual differential tangent and its graded evaluation-dual adjoint.
The source-variation term uses Sigma_J=sF, not F's source independence.

## One functional fixes the finite breaking insertion

Reuse V845's source-quadratic nonmaster action with local-mark analogue epsilon
and independent odd rho. Define B from Sigma_rho FIRST, then use the SAME
finite Gaussian parent Sigma_rho+beta B,with beta odd and placed LEFT. A
direct derivative of its normalized logarithm yields

    LEFT_beta Gamma1[Sigma_rho+betaB]|beta0
       =<T²B/2>_(Sigma_rho).

The right side uses the FULL g/u/rho covariance and normalization. It is not
the product of mean fields,an independently chosen contact or a beta-deformed
B label. The beta/rho mixed order is LEFT_rho LEFT_beta Gamma. The opposite
order has minus sign. Keep beta until after action/source derivatives; setting
it or sources zero prematurely removes actual terms.

This new derivative is compared to V845's qualified full_I_B rather than
designing a new fixture. Direct Gaussian moments/Berezin integration and a
separate boson Schur determinant compute the same functional. Four nilpotent
labels can require fourth order: all series retain it and prove fifth power
zero. A zero fourth coefficient is a measured support fact,not a truncation.
The fixture is a mathematical sign/normalization check,not a new Spin(10) loop.

## Continuum construction remains a separate applicability question

If the ACTUAL augmented lifted parent and its full breaking insertion satisfy
the admitted word/IR/reference/tangent conditions, define both Gamma_kappa and
the beta insertion by the SAME lifted finite functional and its full Cfin
conversion. The beta*u*rho coefficient then has an operator-defined meaning.
This conditional consequence requires that applicability proof; it is not
furnished by the finite fixture or this Taylor identity.

Retain the V847 clock shift,heatpower-prefactor terms,reference determinant,
firstDjet and all generated breaking/contact normalizations. V848's fixed
classical tensor lift does not evaluate the loop dimensionjet. Bare DS/Ihat
projected zeros do not independently set renormalized beta*u*rho contacts zero.
Selected-M A0/V830-plane bounds do not extend fullbackground,chiral,unselected
profiles,QAP,A5 or physicalviability. HomogeneousD invariance remains distinct
from the actual geometricW5 acceptance target. No physicalscheme is adopted.

The exact product rule and inherited normalized Gaussian identities are the
mathematical anchors. Shared action,software,conventions and AI authorship
limit independence; no human/experimental/Lean validation is asserted. This
removes a specific algebraic hypothesis gap while keeping the remaining
analytic and normalization obligations explicit.
