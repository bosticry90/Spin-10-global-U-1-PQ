from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from functools import lru_cache
import gzip,json,math,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;BROOT=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/nonlinear-source-insertion-extension-v1-2026-11-08')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
ONE={(0,0,(0,)*6,()):F(1)}
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def clean(q):return{k:v for k,v in q.items()if v}
def decode(rows):return{(g,u,tuple(ee),tuple(6+i for i in range(9)if mm&(1<<i))):F(n,d)for g,u,ee,mm,n,d in rows if n}
def add(*qs):
    out={}
    for q in qs:
        for k,v in q.items():out[k]=out.get(k,F(0))+v
    return clean(out)
def scale(q,c):return{k:v*c for k,v in q.items()if v*c}
def mul(q,r):
    out={}
    for(g,u,ee,odd),v in q.items():
        for(gg,uu,ff,oo),c in r.items():
            if g+gg>1 or u+uu>1 or set(odd)&set(oo):continue
            sign=(-1)**sum(i>j for i in odd for j in oo);key=g+gg,u+uu,tuple(x+y for x,y in zip(ee,ff)),tuple(sorted(odd+oo));out[key]=out.get(key,F(0))+v*c*sign
    return clean(out)
def atom(n):
    ee=[0]*6;odd=()
    if n<6:ee[n]=1
    else:odd=(n,)
    return{(0,0,tuple(ee),odd):F(1)}
def derivative(q,n):
    out={}
    for(g,u,ee,odd),v in q.items():
        if n<6:
            if not ee[n]:continue
            ff=list(ee);v*=ff[n];ff[n]-=1;key=g,u,tuple(ff),odd
        else:
            if n not in odd:continue
            at=odd.index(n);v*=(-1)**at;key=g,u,ee,odd[:at]+odd[at+1:]
        out[key]=out.get(key,F(0))+v
    return clean(out)
FIELDS=[0,1,6,7];SOURCES=[8,9,3,2];PAR=[0,0,1,1];QUANT=[4,5,10,11]
def T(q):return add(*(mul(atom(j),derivative(q,i))for i,j in zip(FIELDS,QUANT)))
def t2(q):return scale(T(T(q)),F(1,2))
def powers(q):
    out=[ONE]
    for n in range(5):out.append(mul(out[-1],q))
    assert not out[5]
    return out
@lru_cache(None)
def moment(n,c):return F(0)if n%2 else F(1)if n==0 else(n-1)*c*moment(n-2,c)
def expect_free(q):
    out={}
    for(g,u,ee,odd),v in q.items():
        nq=sum(i in odd for i in[10,11])
        if nq==1:continue
        v*=moment(ee[4],F(1,2))*moment(ee[5],F(1,3))*(F(2,3)if nq==2 else F(1))
        ff=(*ee[:4],0,0);key=g,u,ff,tuple(i for i in odd if i not in[10,11]);out[key]=out.get(key,F(0))+v
    return clean(out)
def unit(q,kind,cut=4):
    pp=powers(add(q,scale(ONE,-1)))
    return add(*(scale(pp[n],(-1)**n if kind=='inverse'else F((-1)**(n+1),n))for n in range(0 if kind=='inverse'else 1,cut+1)))
def gaussian(S,reg,cut=4):
    Q2=add(t2(S),t2(reg));base=add(mul(atom(4),atom(4)),scale(mul(atom(5),atom(5)),F(3,2)),scale(mul(atom(11),atom(10)),F(3,2)));V=add(Q2,scale(base,-1));pp=powers(V);Z=expect_free(add(*(scale(pp[n],F((-1)**n,math.factorial(n)))for n in range(cut+1))));Zi=unit(Z,'inverse',cut);Gamma=scale(unit(Z,'log',cut),-1)
    return Gamma,Z,lambda P:mul(expect_free(mul(P,add(*(scale(pp[n],F((-1)**n,math.factorial(n)))for n in range(cut+1))))),Zi),pp[4]
def ops(S):
    E=[derivative(S,i)for i in FIELDS];ff=[scale(derivative(S,j),(-1)**p)for j,p in zip(SOURCES,PAR)]
    Q=lambda P:add(*(mul(f,derivative(P,i))for f,i in zip(ff,FIELDS)),*(scale(mul(e,derivative(P,j)),(-1)**p)for e,j,p in zip(E,SOURCES,PAR)))
    Bb=add(*(mul(f,e)for f,e in zip(ff,E)));KQ=add(*(mul(f,t2(e))for f,e in zip(ff,E)));KD=add(*(mul(t2(f),e)for f,e in zip(ff,E)));KC=add(*(mul(T(f),T(e))for f,e in zip(ff,E)))
    assert t2(Bb)==add(KQ,KD,KC)==add(Q(t2(S)),KC)
    return Bb,KQ,KD,KC,Q(t2(S))
def mixed(q,g=None):return{k:v for k,v in q.items()if k[1]==1 and(g is None or k[0]==g)}
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='01d3ae5300ab32dc63ee5adfec0b2a56907ccf16'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    pp=read(O/'preparation.json');assert pp==read(C/'preparation.json');nav={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    for n,h in pp['sha256'].items():assert digest(nav[n]if n in nav else R/n)==h,n
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified'];assert all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])and read(O/'result.json')['elapsed_after_imports']<60
    z=load(O/'complete_nonlinear_beta_calibration.json.gz');assert digest(O/'complete_nonlinear_beta_calibration.json.gz')==read(O/'result.json')['packet_sha256']
    old=load(BROOT/'canonical_so10_marked_regulator_parent_g1_v1/finite_marked_regulator_calibration.json.gz');S=decode(old['complete_marked_action']);reg=decode(old['fixed_regulator']);assert S==decode(z['original_V845_action'])and reg==decode(z['regulator'])
    Bb,KQ,KD,KC,QH=ops(S)
    for key,value in[('complete_source_quadratic_breaking',Bb),('complete_KQ',KQ),('complete_KD_source_Euler_leg',KD),('complete_KC',KC),('complete_T2_B',t2(Bb)),('complete_Q_H',QH)]:assert decode(z[key])==value,key
    Gamma0,Z0,expected,V04=gaussian(S,reg);assert Gamma0==decode(old['Gamma_direct'])
    marked=add(S,mul(atom(14),Bb));assert marked==decode(z['complete_beta_parent']);ops(marked)
    Gamma,Z,_,V4=gaussian(marked,reg);IB=derivative(Gamma,14);wanted=expected(t2(Bb));assert IB==wanted==decode(old['full_I_B'])==decode(z['complete_beta_insertion'])==decode(z['complete_normalized_expected_insertion'])
    assert Gamma==decode(z['Gamma_direct'])==decode(z['Gamma_Schur'])and Z==decode(z['partition'])and V4==decode(z['retained_fourth_interaction_power'])
    br=derivative(IB,13);reverse=derivative(derivative(Gamma,13),14);assert br==scale(reverse,-1)==decode(z['complete_beta_rho_insertion'])and reverse==decode(z['opposite_LEFT_order'])
    assert mixed(br)==decode(z['mixed_u_rho'])and mixed(br,1)==decode(z['mixed_gu_rho'])and len(mixed(br))==13 and len(mixed(br,1))==11
    wrong=gaussian(add(S,mul(Bb,atom(14))),reg)[0];wrongside=add(derivative(wrong,14),scale(IB,-1));early={k:v for k,v in IB.items()if not k[2][2]and not k[2][3]and 8 not in k[3]and 9 not in k[3]};earlydiff=add(early,scale(IB,-1));trunc=add(derivative(gaussian(marked,reg,cut=2)[0],14),scale(IB,-1))
    assert wrongside==decode(z['wrong_beta_side_difference'])and earlydiff==decode(z['early_source_zero_difference'])and trunc==decode(z['truncated_quadratic_difference'])and scale(KD,-1)==decode(z['source_Euler_leg_omission'])
    assert KD and all(mixed(q)for q in[derivative(wrongside,13),br,derivative(earlydiff,13),derivative(trunc,13)])
    assert all(z['controls'].values())and all(z['mixed_control_sensitivities'].values())
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'
    assert b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V849.md)'in live;links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V849.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V849.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8')),(O/'PROOF.md',(O/'PROOF.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[v['exit_code']for v in events if v['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(v for v in events if v['event']=='step_finished'and v['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V849.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_ARBITRARY_SOURCE_TAYLOR_AND_SAME_FUNCTIONAL_BETA_INSERTION_CALIBRATION',base_HEAD=head,state_sha256=state,independent_exterior_tuple_Gaussian_all_coefficients_match=True,source_Euler_Hessian_leg_retained=True,beta_LEFT_parent_and_old_IB_exact=True,mixed_u_rho_terms=13,mixed_gu_rho_terms=11,fifth_power_zero_fourth_retained_and_actually_zero=True,all_controls_and_mixed_signs_checked=True,actual_continuum_domain_contact_and_common_restoration_NOT_established=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_conventions_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','mixed_u_rho_terms','mixed_gu_rho_terms','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
