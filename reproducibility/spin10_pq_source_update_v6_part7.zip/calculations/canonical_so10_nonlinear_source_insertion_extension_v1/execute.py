from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/nonlinear-source-insertion-extension-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='01d3ae5300ab32dc63ee5adfec0b2a56907ccf16'
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V848.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md'}
for folder in['canonical_so10_mixed_probe_slavnov','canonical_so10_quadratic_probe_completion','canonical_so10_finite_normalization_probe_lift','canonical_so10_proper_slavnov_source_chain_g1_v1','canonical_so10_marked_regulator_parent_g1_v1','canonical_so10_augmented_metric_lift_v1']:
    root=R/'calculations'/folder
    for n in['PROOF.md','DERIVATION.md','RESULT.md','validation_receipt.json','compute_fixture.py','chain.py','finite_marked_regulator_calibration.json.gz']:
        if(root/n).exists():names.add((root/n).relative_to(R).as_posix())
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
for n in['RECORD.md','PROOF.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='01d3ae5300ab32dc63ee5adfec0b2a56907ccf16',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
