from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,importlib.util,json,math,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/nonlinear-source-insertion-extension-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('NSI_inherited_marked_fixture',B/'canonical_so10_marked_regulator_parent_g1_v1/compute_fixture.py');f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f);a=f.a;a.NO=9
plus=a.plus;scale=a.scale;mul=a.mul;at=a.atom;partial=a.partial;t2=a.t2;tangent=a.tangent;zero={};one=a.ONE;beta=14;rho=13;eps=12
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def powers(v):
    out=[one]
    for n in range(1,6):out.append(mul(out[-1],v))
    assert not out[5],'FULL_NIL_FIFTH_POWER_NOT_ZERO'
    return out
def unit(z,kind,cut=4):
    r=plus(z,scale(one,-1));p=powers(r)
    if kind=='inverse':return plus(*(scale(p[n],(-1)**n)for n in range(cut+1)))
    return plus(*(scale(p[n],F((-1)**(n+1),n))for n in range(1,cut+1)))
def gaussian(S,reg,cut=4):
    Q2=plus(t2(S),t2(reg));base=plus(a.term([4,4]),a.term([5,5],F(3,2)),a.term([11,10],F(3,2)));V=plus(Q2,scale(base,-1));pp=powers(V)
    assert all(g+u+bool(mm&(1<<(rho-a.NE)))+bool(mm&(1<<(beta-a.NE)))>0 for g,u,ee,mm in V),'UNACCOUNTED_NONNIL_QUADRATIC_VERTEX'
    weight=plus(*(scale(pp[n],F((-1)**n,math.factorial(n)))for n in range(cut+1)));Z=a.free_expect(weight);Zi=unit(Z,'inverse',cut);Gamma=scale(unit(Z,'log',cut),-1)
    expect=lambda P:mul(a.free_expect(mul(P,weight)),Zi)
    A=[[a.setzero(partial(partial(Q2,i),j),a.QUANT)for j in[4,5]]for i in[4,5]];d0=[[scale(one,F(1,2)),zero],[zero,scale(one,F(1,3))]];A0=[[scale(one,2),zero],[zero,scale(one,3)]];X=a.matmul(d0,[[plus(A[i][j],scale(A0[i][j],-1))for j in range(2)]for i in range(2)]);mp=[[[one,zero],[zero,one]]]
    for n in range(1,6):mp.append(a.matmul(mp[-1],X))
    assert all(not z for row in mp[5]for z in row)
    inverse=a.matmul([[plus(*(scale(mp[n][i][j],(-1)**n)for n in range(cut+1)))for j in range(2)]for i in range(2)],d0)
    boson=scale(plus(*(scale(mp[n][i][i],F((-1)**(n+1),n))for n in range(1,cut+1)for i in range(2))),F(1,2));linear=[a.setzero(partial(Q2,i),[4,5])for i in[4,5]]
    eff=plus(a.setzero(Q2,[4,5]),scale(plus(*(a.product(linear[i],inverse[i][j],linear[j])for i in range(2)for j in range(2))),F(-1,2)));c={}
    for(g,u,ee,mm),v in eff.items():
        assert ee[4]==ee[5]==0 and mm&48==48,'SCHUR_GHOST_QUADRATIC_DEGREE'
        c[g,u,ee,mm^48]=c.get((g,u,ee,mm^48),F(0))+v
    schur=plus(boson,scale(unit(scale(a.clean(c),F(-2,3)),'log',cut),-1))
    if cut==4:assert Gamma==schur,'FULL_WICK_SCHUR_DISAGREEMENT'
    return dict(Q2=Q2,V=V,V4=pp[4],Z=Z,Gamma=Gamma,Schur=schur,expect=expect)
def operations(S):
    E=[partial(S,i)for i in a.FIELDS];ff=[scale(partial(S,j),(-1)**p)for j,p in zip(a.SOURCES,a.PAR)]
    Q=lambda P:plus(*(mul(v,partial(P,i))for v,i in zip(ff,a.FIELDS)),*(scale(mul(v,partial(P,j)),(-1)**p)for v,j,p in zip(E,a.SOURCES,a.PAR)))
    B0=plus(*(mul(v,e)for v,e in zip(ff,E)));H=t2(S);KQ=plus(*(mul(v,t2(e))for v,e in zip(ff,E)));KD=plus(*(mul(t2(v),e)for v,e in zip(ff,E)));KC=plus(*(mul(tangent(v),tangent(e))for v,e in zip(ff,E)))
    assert t2(B0)==plus(KQ,KD,KC)==plus(Q(H),KC)and Q(H)==plus(KQ,KD)
    return dict(E=E,F=ff,Q=Q,B=B0,H=H,KQ=KQ,KD=KD,KC=KC)
def mixed(P,g=None):return{k:v for k,v in P.items()if k[1]==1 and(g is None or k[0]==g)}
def main():
    tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    old=load(B/'canonical_so10_marked_regulator_parent_g1_v1/finite_marked_regulator_calibration.json.gz');decode=lambda rows:{(g,u,tuple(ee),mm):F(n,d)for g,u,ee,mm,n,d in rows}
    S=decode(old['complete_marked_action']);reg=decode(old['fixed_regulator']);ops=operations(S);z=gaussian(S,reg);assert a.encode(z['Gamma'])==old['Gamma_direct']and ops['B']
    inserted=plus(S,mul(at(beta),ops['B']));zb=gaussian(inserted,reg);ib=partial(zb['Gamma'],beta);expected=z['expect'](t2(ops['B']));assert ib==expected==decode(old['full_I_B'])
    # The full source-quadratic action and beta-deformed action both obey the
    # exact Hessian lemma; no master-zero assumption is used.
    opb=operations(inserted);beta_rho=partial(ib,rho);reverse=partial(partial(zb['Gamma'],rho),beta);assert beta_rho==scale(reverse,-1)
    wrong=gaussian(plus(S,mul(ops['B'],at(beta))),reg);wrongside=plus(partial(wrong['Gamma'],beta),scale(ib,-1));no_sourceleg=scale(ops['KD'],-1)
    early=a.setzero(ib,a.SOURCES);truncated=gaussian(inserted,reg,cut=2);truncdiff=plus(partial(truncated['Gamma'],beta),scale(ib,-1))
    controls=dict(omit_source_Euler_Hessian_leg=bool(no_sourceleg),wrong_beta_side=bool(wrongside),reverse_LEFT_beta_rho=bool(beta_rho),early_source_zero=bool(plus(early,scale(ib,-1))),truncate_quadratic=bool(truncdiff))
    sensitivities={name:bool(mixed(P))for name,P in [('wrong_beta_side',partial(wrongside,rho)),('reverse_LEFT_beta_rho',beta_rho),('early_source_zero',partial(plus(early,scale(ib,-1)),rho)),('truncate_quadratic',partial(truncdiff,rho))]}
    assert all(controls.values())and mixed(beta_rho),'FINITE_CONTROL_OR_MIXED_INSERTION_INSENSITIVE'
    artifact=dict(original_V845_action=a.encode(S),regulator=a.encode(reg),complete_source_quadratic_breaking=a.encode(ops['B']),complete_KQ=a.encode(ops['KQ']),complete_KD_source_Euler_leg=a.encode(ops['KD']),complete_KC=a.encode(ops['KC']),complete_T2_B=a.encode(t2(ops['B'])),complete_Q_H=a.encode(ops['Q'](ops['H'])),complete_beta_parent=a.encode(inserted),Gamma_direct=a.encode(zb['Gamma']),Gamma_Schur=a.encode(zb['Schur']),partition=a.encode(zb['Z']),complete_beta_insertion=a.encode(ib),complete_normalized_expected_insertion=a.encode(expected),complete_beta_rho_insertion=a.encode(beta_rho),opposite_LEFT_order=a.encode(reverse),mixed_u_rho=a.encode(mixed(beta_rho)),mixed_gu_rho=a.encode(mixed(beta_rho,1)),retained_fourth_interaction_power=a.encode(zb['V4']),all_fifth_powers_zero=True,source_Euler_leg_omission=a.encode(no_sourceleg),wrong_beta_side_difference=a.encode(wrongside),early_source_zero_difference=a.encode(plus(early,scale(ib,-1))),truncated_quadratic_difference=a.encode(truncdiff),controls=controls,mixed_control_sensitivities=sensitivities,beta_parent_same_hessian_identity_checked=True,continuum_actual_model_domain_and_contact_normalization_NOT_qualified=True)
    blob=gzip.compress((json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=8*1024**2
    with(O/'complete_nonlinear_beta_calibration.json.gz').open('xb')as h:h.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ARBITRARY_SOURCE_TAYLOR_IDENTITY_AND_SAME_FUNCTIONAL_BREAKING_INSERTION_CALIBRATED',source_linear_hypothesis_NOT_needed_for_exact_Taylor_step=True,both_Gaussian_routes_equal=True,old_V845_full_IB_transferred_by_exact_same_parent=True,mixed_u_rho_terms=len(mixed(beta_rho)),mixed_gu_rho_terms=len(mixed(beta_rho,1)),fourth_power_terms_retained=len(zb['V4']),controls=controls,mixed_control_sensitivities=sensitivities,packet_sha256=digest(O/'complete_nonlinear_beta_calibration.json.gz'),elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
