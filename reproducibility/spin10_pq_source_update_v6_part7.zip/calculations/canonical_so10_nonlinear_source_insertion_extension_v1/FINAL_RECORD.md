# Separate V849 exterior-algebra validation

One180s afterimports,8GiBsampled/350MiBfloor,32MiBpacket/8MiBartifact. Root
owns execution/Git; AI proof reviews read only. Freeze allsources/copies,
proof/result/actualinputs/captures before computation. No authoritychange.

Do not import the producer or old finite algebra. Use sorted EXTERIOR TUPLES
instead of bitmasks and independent left derivative/product signs. Rebuild
the exact current fixture from the bound V845 action; derive FULL F/E/B/QH/
T²B and sourceleg,then the SAME beta-left parent. Direct Gaussian moments
with explicit ordered ghost covariance supply normalizedpartition/log and
insertion,including fourthorder and fifthpowerzero. Compare every recorded
coefficient,all oddorders,oldfull_I_B and nonzero mixedu/rho/gu evidence.
Recompute all controls/negative differences,not merelysummarybooleans. Review
the generic arbitrarysource-degree proof and its restricted continuum inference.

Authenticate exactpreparation/sourcecopies/oldreceipt bindings,captures/resources,
state and Git tree. Current README/guide navigation is separate from original
savedbytebindings. E4fixedcontextonce: outer0/steps0,0,0,0,0,2/sevenNOTPASS.
Whole failure/overflow preserved. Exactstaging before localcommit; no push.
