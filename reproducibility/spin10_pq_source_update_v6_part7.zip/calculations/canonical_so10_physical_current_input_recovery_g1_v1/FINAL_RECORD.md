# Final physical-input validation, prospective

NativeV2 and replayV4 completed all nine mathematical artifact pairs and
their complete raw bytes agree. Freeze final validation of all artifacts,
source/input bindings, failedV1/V3 captures, successful resources, raw frame
block semantics and final proof/result/handoff. Recheck complete scalar
identity and Lorentz-block transport, exact free-current divergence and
cubic Hessian polarization/Taylor-half identities from the retained full
tables. These checks do not execute or accept any loop amplitude.

Final180s,8GiBsampled,350MiBlaunchfloor,64MiBcompletepacket. Load large
artifacts sequentially and release them; never truncate tables or weaken
an obligation to fit. E4 once on verifiedD:context,no--fresh,expected
0,0,0,0,0,2 and seven unresolved custody referencesNOTPASS. Save full captures
before assertions. Receipt excludes its own pending bytes and final outer
capture. Preserve oldtree/state and all failed source/capture bytes. No
scientific promotion,physical adoption,protected activation or remote action.
