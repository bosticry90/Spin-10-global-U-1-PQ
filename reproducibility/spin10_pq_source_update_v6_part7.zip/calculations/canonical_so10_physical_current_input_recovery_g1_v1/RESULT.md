# Physical action and current inputs recovered through g1

Both complete derivations agree byte-for-byte on all nine physical artifact
pairs. The reconstructed action contains20088 gauge cubic and50240 scalar–
vector terms. All868 needed physical Euler columns agree, and the raw
200920-term g1 Noether contraction is an explicit divergence with all four
currents retained. This supplies the physical input absent from the surviving
gauge-fixing/source-response calculation.

The physical marked current has200880 gauge and200960 scalar terms atg1.
Full source-first physical probe field maps vanish at508 columns for each
probe; inverse-U ordinary vertices still remain necessary. Complete physical
BBB/Bxx Taylor Hessians retain both labeled orders and the even1/2 factor.
The1080-term free physical marked kernel is removed only as an explicit
integrated constant-mark divergence. Potential terms are excluded from the
intended zero-scalar-mean intrinsic01 channels by differentiated arity, while
their full contracted Noether qualification is reused, not freshly expanded.

The [proof](PROOF.md) states the independent action/BRST bridge, field
grading and exact scope. The [receipt](validation_receipt.json) owns full
artifact/source/input/resource and E4 validation. Native162.431747s and
replay153.991273s completed under300s each. Two early harness/schema failures
are preserved separately; no failed run is called PASS.

Next combine the actual g0 gauge-fixing current/U kernels with these physical
owners and derive the returning classes before integration. The raw physical
kernels have not been evaluated as loop amplitudes, and the missing later
M-sector executable evidence remains missing. Shared action/software/AI author
limit independence; no outside scientist, proof kernel or experiment is
claimed. State113/34of39 and E5/A5 remain unchanged.
