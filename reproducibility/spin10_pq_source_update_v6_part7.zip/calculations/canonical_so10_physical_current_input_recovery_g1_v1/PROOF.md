# Recovered physical action and current inputs through g1

This is the existing conditional gauge/scalar Spin(10) × global U(1)PQ
candidate, in its original unshifted Euclidean A0 chart, intrinsic01 and
first constant u. The reconstruction supplies one-loop input kernels, not
an adopted physical action, vacuum, amplitude or complete quantum identity.
The868 Euler columns below are the columns needed by this current:508
g0 physical B/x columns and180 g1 vector columns in each of the gauge and
scalar owners. They are not a claim to enumerate all higher-order Euler
coefficients or a Yukawa/fermion sector.

## A physical action independent of the BRST comparison target

Native lowers the actual five kinetic ASTs of the frozen executable action.
The raw Lorentz coefficients are -1/4 for gauge F² and1/2 for each of
Phi54,Sigma252,phi20,S2. The field/time-jet Wick phases and density minus
produce the inherited Euclidean +F²/4 and +(D x)²/2 weights in all four
directions. No sign or kinetic coefficient is chosen from a Ward residual.

Let P map raw C3 gauge coordinates to the physical plane basis and T map
canonical gauge coordinates to the raw ones. The native action uses O=PT.
Its exact orthogonality is checked. Scalar transport is the identity; the
full raw/canonical block conditions are verified in final review. The plane
structure constants and all four actual scalar representation sets are
transported with O. This gives1674 nonzero canonical f entries and12560
scalar representation entries. Only after physical construction does native
read the original field-flow target. The whole f/rho set agrees with every
canonical vector/scalar BRST field column, including zeros.

Replay starts from separately replayed source-derived BRST flows and closed
covariant formulas. The two routes thus test the physical action/BRST bridge
from different directions. The same inherited frame, exact ring and action
remain shared inputs. A frame/physical-convention mistake common to those
inputs is outside what agreement alone can settle.

Writing qB=partial C+g f B C and qx=-g rho(C)x, the recovered densities are

    L0=F0²/4+(partial x)²/2,
    L1_gauge=g f_abc F0_a,mu,nu B_b,mu B_c,nu/2,
    L1_scalar=g (partial_mu x_i) rho_a,ij B_a,mu x_j.

There are810 gauge and1312 scalar terms in L0,20088 gauge cubic terms
and50240 scalar–vector terms in L1. All Lorentz components and scalar
owners are retained. The native coefficient guard denies early reads of
the BRST target; both native/replay workers deny peer artifacts.

## Full source-first physical flows and potential scope

All508 original physical field maps are checked. The g0 scalar maps vanish;
the g0 vector map is exactly partial C. Both probe physical field maps are
computed by full source Euler differentiation of U=QG before any mean
restriction. All508 columns vanish for each probe in this domain. Thus
there is no explicit-u physical marked current here. This does NOT remove
the u dependence of the ordinary inverse/Hessian: the gauge-fixing U vertices
must still be included in the subsequent loop calculation.

Every one of the29 nonkinetic physical AST terms is inspected for scalar
arity, derivative/vector content and parameter dimension. They have no
vector or derivative ports, and scalar arity d with coefficient dimension
4-d. In intrinsic01, d>=3. A potential T1E_x leaves d-2>=1 mean scalar
factors; an ordinary potential T2S leaves the same minimum. Since the
intended BLambdaC and LambdaJaC projections have zero scalar means and
the remaining factors have nonnegative scalar arity, neither can return
there. The d2 mass terms have intrinsic dimension2, outside this increment.
This is a typing/arity exclusion after differentiation, not an adopted
massless vacuum, a scalar-loop theorem in other projections or deletion
of scalar kinetic vertices.

The complete off-shell potential Noether invariance remains an authenticated
existing contracted-action dependency, not a fresh expansion of its large
invariant tensors. No potential parameters, vacuum shifts or historical
benchmarks are changed. Yukawa/flavor work is not resumed.

## Exact Euler and Noether comparison

Native differentiates the actual densities. Replay uses
E0_B=-box B+partial divB, E0_x=-box x,
E1_B,gauge=-g f[(divB)B+2B.partial B-B.partial B with exchanged Lorentz
indices], and E1_B,scalar=g (partial x)rho x. All868 full columns and
their complements agree. The g1 scalar Euler does not enter this current
because its actual g0 scalar flow partner is zero, rather than because the
scalar action is absent.

Both routes retain the raw contraction I=sum_z F_z E_z and four explicit
currents. Native derives the currents by first variation of the action;
replay uses the covariant expressions. At g0 and in each g1 owner,

    I0=div J0,  I1_gauge=div J1_gauge,  I1_scalar=div J1_scalar.

The raw I0 has1080 terms; I1_gauge has100440 and I1_scalar100480, a total
of200920. None is relabeled a zero density. Each complete density-minus-
divergence residual is zero. Direct kinetic density variations
Q0L1+Q1L0 are also zero separately in gauge and scalar owners. No equation
of motion is imposed and all derivatives of the ghost remain.

## Marked and ordinary kernels, with their quantum coordinates

For even tangent eta, form the physical marked current
sum_z(T1F_z)(T1E_z), keeping mean C distinct from quantum etaC. Native
uses in-place jet replacement; replay uses eta times each LEFT jet partial,
with parity-prefix signs and canonical reordering. Tangent offset1319 and
independent second-direction offset1962 match the surviving chart convention.
The complete g1 marked kernels contain200880 gauge and200960 scalar
terms. They are nonzero input polynomials, not nonzero loop amplitudes.

The physical g0 marked kernel has1080 terms. It is exactly I0 with both
factors replaced by quantum directions, and its four transported currents
are preserved. It may be removed as an integrated divergence only in this
constant-mark Gaussian domain. A nonconstant local mark would retain its
gradient-current term; no local marked QAP follows.

The complete ordinary cubic Taylor kernels are retained in both forms:
T_eta²S1, its1/2 Taylor factor, and ordered T_eta T_kappa S1. Both physical
BBB and Bxx owners remain. The labeled Hessian orders and even factorials
are checked; the scalar owner is not discarded on the strength of a source
channel or gauge-only result. Returning-type/color pruning is still needed.

Full wrong expressions retain the effect of reversing the g1 field flow,
omitting either physical owner, collapsing quantum C into mean C, and
omitting the B0 Wick field phase while keeping the time-jet phase. Their
nonzero differences test conventions and vertices; no loop sensitivity is
inferred merely because a vertex polynomial changes.

## Evidence, failures and significance

All nine mathematical artifact pairs are byte-identical: coefficients,
action, field flows, Eulers, Noether currents, marked kernels, gauge and
scalar ordinary Hessians, and controls. They include complete nonzero and
zero data, not only samples or digests. Native162.431747s and replay153.991273s
completed under their300s bounds; sampled private memory is reported in the
receipt and is not a continuous peak. The complete packet bound is64MiB.

Failed native V1 used canonical ghost positions in the raw frame order.
V2 uses recorded raw C names and preserves the original matrix equality.
Replay V3 failed on an unused architecture key absent from the replay
schema. V4 makes that unused read native-only and preserves the replay's
own source data. Both failed sources/captures remain FAILED; neither action
calculation was silently repeated. These are actual AI implementation
failures, alongside the demonstrated recovery and distinct verification.

This restores the physical action/current prerequisites that the source-only
calculation could not supply. It does not recover the missing October
current inventory or establish the reported nine-M frontier. The next
smallest test combines these physical kernels with the actual g0 gauge-
fixing current and U Hessians to determine the NEW physical returning
classes. This can prove scalar/nonreturning exclusions before expensive
integrals, while preserving both physical marked and ordinary owners.
The remaining g1 gauge-fixing current inventory and full covariance comparison
must then be joined before interpreting any M amplitude or common normalization.

The evidence authenticates a conditional calculation in the existing candidate,
not foundational adoption, external review or empirical truth. Shared action,
frame, ring, software and AI author constrain independence. No proof kernel
or outside scientist is claimed. State113/34of39,E5/A5 and all protected
stages remain unchanged; custody exit2/seven unresolved remains NOTPASS.
