"""Actual physical kinetic action and source-first current input recovery."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('physical_recovery_quantum',O.parent/'canonical_so10_absolute_marked_quantum_g0_recovery_v1/quantum.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
J=w.J;A=w.A;parity0=J.parity
J.parity=lambda n:parity0(n-1962) if n>=1962 else parity0(n-1319) if n>=1319 else 1 if n>=1286 else parity0(n)
G=J.Coeff([((1,0,0,0),F(1))]);one=J.constant(1);half=J.constant(F(1,2));zero=J.ZERO
atom=lambda i,js=():{((i,tuple(js)),):one}
def polyadd(*ps):return w.plus(*ps)
def put(p,word,c):J.put(p,tuple((i,tuple(js)) for i,js in word),c)
def grade(P,n,strip=False):
 return J.clean({word:J.Coeff([(((0 if strip else a),b,c,m),v) for (a,b,c,m),v in cc.terms if a==n]) for word,cc in P.items()})
def act(P,Q,odd=False):
 out={};cache={}
 for word,c in P.items():
  pref=0
  for pos,(n,js) in enumerate(word):
   if Q.get(n):
    if (n,js) not in cache:cache[n,js]=J.Ds(Q[n],js)
    for word2,z in cache[n,js].items():J.put(out,word[:pos]+word2+word[pos+1:],J.times(c,z)*((-1)**pref if odd else 1))
   pref+=J.parity(n)
 return J.clean(out)
def tangent(P,offset=1319):
 out={}
 for word,c in P.items():
  for at,(n,js) in enumerate(word):
   if n>=643:continue
   sign=(-1)**(J.parity(n)*sum(J.parity(i) for i,jj in word[:at]))
   J.put(out,((offset+n,js),)+word[:at]+word[at+1:],c*sign)
 return J.clean(out)
def multiply_sum(maps1,maps2,keys):
 out={}
 for n in keys:J.add(out,J.mul(maps1.get(n,{}),maps2.get(n,{})))
 return J.clean(out)
def save(name,data,artifacts):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 path=O/(ROLE+'_v3_'+name+'.json.gz')
 with path.open('xb') as f:f.write(blob)
 artifacts[name]=dict(file=path.name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2,'COMPLETE_PACKET_LIMIT'
 gc.collect()
def matrices(packet):return {(i,j):A.co(v) for i,j,v in packet['entries']}
def physical_coefficients(frame,evidence,architecture,xnames):
 P=matrices(architecture['C3_to_plane_field']);assert P==matrices(frame['Q'])
 T={(i//4,j//4):A.co(v) for i,j,v in frame['physical_to_raw_inverse']['entries'] if i<180 and j<180 and i%4==j%4==0}
 for mu in range(4):assert T=={(i//4,j//4):A.co(v) for i,j,v in frame['physical_to_raw_inverse']['entries'] if i<180 and j<180 and i%4==j%4==mu}
 assert T=={(int(frame['field_order'][i][1:]),j-553):A.co(v) for i,j,v in frame['physical_to_raw_inverse']['entries'] if frame['field_order'][i].startswith('C') and 553<=j<598}
 U=A.mul(P,T);identity={(i,i):one for i in range(45)}
 assert A.mul(A.transpose(U),U)==identity and A.mul(U,A.transpose(U))==identity
 assert all(not(k[3]&16) for c in U.values() for k,v in c.terms)
 byplane=defaultdict(list)
 for (i,j),c in U.items():byplane[i].append((j,c))
 fp={}
 for c,b,d,value in evidence['ward']['plane_structure_constants']:
  z=A.co(value)
  for key,val in [((c,b,d),z),((c,d,b),-z)]:
   assert key not in fp or fp[key]==val;fp[key]=val
 f={}
 for (i,j,k),c in fp.items():
  for a,x in byplane[i]:
   for b,y in byplane[j]:
    for d,z in byplane[k]:
     key=(a,b,d);f[key]=f.get(key,zero)+J.times(J.times(J.times(c,x),y),z)
 f={k:v for k,v in f.items() if v};rho={a:{} for a in range(45)}
 expected=[];offset=0
 for sec in ['Phi','Sigma','phi','S']:
  dim=evidence['sector_dimensions'][sec]
  expected += ['x_'+sec+'_'+str(i) for i in range(dim)]
  assert len(evidence['representation_matrices'][sec])==45
  for i,mat in enumerate(evidence['representation_matrices'][sec]):
   for rr,cc,value in mat['entries']:
    z=A.co(value)
    for a,c in byplane[i]:
     key=(offset+rr,offset+cc);rho[a][key]=rho[a].get(key,zero)+J.times(z,c)
  offset+=dim
 assert expected==xnames and offset==328
 rho={a:{ij:c for ij,c in m.items() if c} for a,m in rho.items()}
 assert all(A.add(m,A.transpose(m))=={} for m in rho.values())
 assert all(f.get((a,b,c),zero)==-f.get((b,a,c),zero)==-f.get((a,c,b),zero) for a,b,c in f)
 return U,f,rho
def parse_kinetic_terms(action):
 assert len(action['local_terms'])==34 and action['physical_term_count']==34
 def strip(z):
  while z['node'] in ['GroupContraction','LorentzContraction']:
   if z['node']=='LorentzContraction':assert z['metric']=='diag(1,-1,-1,-1)'
   z=z['expression']
  return z
 def coeffbody(z):
  z=strip(z);c=F(1)
  if z['node']=='OrderedProduct':
   factors=[]
   for p in z['factors']:
    if p['node']=='ExactScalar':c*=F(p['value'])
    else:factors.append(p)
   if len(factors)==1:return c,strip(factors[0])
  return c,z
 gauge=None;scalars=[];wick=[]
 for row in action['local_terms'][:5]:
  z=strip(row['density']);assert z['node']=='OrderedProduct' and len(z['factors'])==3
  raw=F(z['factors'][0]['value']);aa,bb=z['factors'][1:];assert aa==bb and aa['node']=='Add'
  if row['sector']=='GAUGE_KINETIC':
   assert raw==F(-1,4) and len(aa['terms'])==3;terms={}
   for term in aa['terms']:
    c,p=coeffbody(term)
    if p['node']=='PartialDerivative':
     assert p['argument']['name']=='B';terms[p['index'],tuple(p['argument']['indices'])]=c
    else:
     assert c==1 and p['node']=='OrderedProduct'
     pp=p['factors'];assert [n['node'] for n in pp]==['Parameter','StructureConstant','Field','Field']
     assert pp[0]['name']=='g10' and pp[1]['name']=='f_plane' and pp[1]['indices']==['a','b','c']
     assert pp[2]['name']==pp[3]['name']=='B' and pp[2]['indices']==['b','mu'] and pp[3]['indices']==['c','nu']
   assert terms=={('mu',('a','nu')):F(1),('nu',('a','mu')):F(-1)};gauge=raw
  else:
   sec=row['scalar_sector'];assert row['sector']=='SCALAR_KINETIC' and raw==F(1,2) and len(aa['terms'])==2
   d,nonlinear=aa['terms'];assert d['node']=='PartialDerivative' and d['index']=='mu' and d['argument']['name']=='x_'+sec
   p=strip(nonlinear);assert p['node']=='OrderedProduct';pp=p['factors']
   assert [n['node'] for n in pp]==['Parameter','RepresentationGenerator','Field','Field']
   assert pp[0]['name']=='g10' and pp[1]['name']=='rho_'+sec and pp[2]['name']=='B' and pp[3]['name']=='x_'+sec
   assert pp[1]['indices']==['a','i','j'] and pp[2]['indices']==['a','mu'] and pp[3]['indices']==['j'];scalars.append(sec)
 assert gauge is not None and scalars==['Phi','Sigma','phi','S']
 eta=(1,-1,-1,-1)
 for mu in range(4):
  im=J.I if mu==0 else one
  scalarwick=-J.constant(F(1,2)*eta[mu])*J.times(im,im);assert scalarwick==half
  for nu in range(4):
   inn=J.I if nu==0 else one;phase=J.times(im,inn)
   val=-J.constant(gauge*eta[mu]*eta[nu])*J.times(phase,phase);assert val==J.constant(F(1,4))
   wick.append([mu,nu,w.enc(val)])
 return dict(kinetic_AST_count=5,raw_gauge_coefficient=str(gauge),raw_scalar_coefficient='1/2',gauge_Euclidean_weights=wick,scalar_Euclidean_weight='1/2')
def potential_types(action):
 def degree(n):
  kind=n['node']
  if kind in ['ExactScalar','InvariantTensor','KroneckerMetric','StructureConstant','RepresentationGenerator']:return {(0,0,0,0)}
  if kind=='Parameter':return {(0,0,0,n['mass_dimension'])}
  if kind=='Field':return {(int(n['name']!='B'),int(n['name']=='B'),0,0)}
  if kind=='PartialDerivative':return {(a,b,d+1,m) for a,b,d,m in degree(n['argument'])}
  if kind in ['GroupContraction','LorentzContraction']:return degree(n['expression'] if 'expression' in n else n['argument'])
  if kind=='OrderedProduct':
   out={(0,0,0,0)}
   for p in n['factors']:out={tuple(a+b for a,b in zip(x,y)) for x in out for y in degree(p)}
   return out
  if kind=='Add':return set().union(*(degree(p) for p in n['terms']))
  raise AssertionError(('UNSUPPORTED_POTENTIAL_NODE',kind))
 records=[]
 for row in action['local_terms'][5:]:
  ds=degree(row['density']);assert ds and all(b==d==0 and a>=2 and a+m==4 for a,b,d,m in ds)
  assert all(a>=3 for a,b,d,m in ds if m<=1)
  records.append(dict(term_id=row['term_id'],all_arities=[list(z) for z in sorted(ds)],minimum_retained_mean_x_after_T1E=min((a-2 for a,b,d,m in ds if m<=1),default=None)))
 return records
def build_action(f,rho):
 s0g={};s0x={};s1g={};s1x={}
 for a in range(45):
  for mu in range(4):
   for nu in range(4):
    ff=polyadd(atom(4*a+nu,(mu,)),w.scale(atom(4*a+mu,(nu,)),-one))
    J.add(s0g,w.scale(J.mul(ff,ff),J.constant(F(1,4))))
 for i in range(328):
  for mu in range(4):J.add(s0x,w.scale(J.mul(atom(180+i,(mu,)),atom(180+i,(mu,))),half))
 for (a,b,c),z in f.items():
  for mu in range(4):
   for nu in range(4):
    ff=polyadd(atom(4*a+nu,(mu,)),w.scale(atom(4*a+mu,(nu,)),-one))
    J.add(s1g,w.scale(J.mul(ff,J.mul(atom(4*b+mu),atom(4*c+nu))),J.times(G,z)*half))
 for a,m in rho.items():
  for (i,j),z in m.items():
   for mu in range(4):J.add(s1x,w.scale(J.mul(atom(180+i,(mu,)),J.mul(atom(4*a+mu),atom(180+j))),J.times(G,z)))
 return J.clean(s0g),J.clean(s0x),J.clean(s1g),J.clean(s1x)
def flow_coefficients(Q):
 f={};rho={a:{} for a in range(45)};F0={};F1={}
 for n in range(508):
  p=Q.get(n,{});F0[n]=grade(p,0);F1[n]=grade(p,1)
  assert p==polyadd(F0[n],F1[n])
  expected=atom(553+n//4,(n%4,)) if n<180 else {}
  assert F0[n]==expected
  for word,c in grade(p,1,True).items():
   assert len(word)==2 and not any(js for i,js in word)
   a,b=[i for i,js in word]
   assert 553<=b<598
   if n<180:
    assert a<180 and a%4==n%4
    key=n//4,a//4,b-553
    if key in f:assert f[key]==c
    f[key]=c
   else:
    assert 180<=a<508
    key=(n-180,a-180);rho[b-553][key]=-c
 return f,rho,F0,F1
def source_probe_flows(src):
 out=[]
 for pr in [0,1]:
  U=J.decode(src['probes'][pr]['qG']);der=J.euler(U,set(range(643,1151)))
  flow={n:der.get(643+n,{}) for n in range(508)}
  out.append(flow)
 return out
def closed_euler(f,rho):
 e0={n:{} for n in range(508)};e1g={n:{} for n in range(180)};e1x={n:{} for n in range(180)}
 for a in range(45):
  for mu in range(4):
   p={}
   for nu in range(4):J.add(p,atom(4*a+mu,(nu,nu)),-1);J.add(p,atom(4*a+nu,tuple(sorted((mu,nu)))))
   e0[4*a+mu]=J.clean(p)
 for i in range(328):e0[180+i]=J.clean({((180+i,(mu,mu)),):-one for mu in range(4)})
 for (a,b,c),z in f.items():
  for mu in range(4):
   for nu in range(4):
    p=e1g[4*a+mu]
    J.add(p,w.scale(J.mul(atom(4*b+nu,(nu,)),atom(4*c+mu)),-J.times(G,z)))
    J.add(p,w.scale(J.mul(atom(4*b+nu),atom(4*c+mu,(nu,))),-2*J.times(G,z)))
    J.add(p,w.scale(J.mul(atom(4*b+nu),atom(4*c+nu,(mu,))),J.times(G,z)))
 for a,m in rho.items():
  for (i,j),z in m.items():
   for mu in range(4):J.add(e1x[4*a+mu],w.scale(J.mul(atom(180+i,(mu,)),atom(180+j)),J.times(G,z)))
 return e0,{n:J.clean(p) for n,p in e1g.items()},{n:J.clean(p) for n,p in e1x.items()}
def first_variation_current(L,flow):
 theta=[{} for mu in range(4)]
 for word,c in L.items():
  for at,(n,js) in enumerate(word):
   if not js:continue
   assert len(js)==1 and n<508
   J.add(theta[js[0]],J.mul({word[:at]+word[at+1:]:c},flow.get(n,{})))
 return [w.scale(J.clean(p),-one) for p in theta]
def closed_currents(f,rho,F0,F1):
 c0=[{} for mu in range(4)];cg=[{} for mu in range(4)];cx=[{} for mu in range(4)]
 for a in range(45):
  for mu in range(4):
   for nu in range(4):
    ff=polyadd(atom(4*a+nu,(mu,)),w.scale(atom(4*a+mu,(nu,)),-one))
    J.add(c0[mu],J.mul(ff,F0[4*a+nu]),-1);J.add(cg[mu],J.mul(ff,F1[4*a+nu]),-1)
 for (a,b,c),z in f.items():
  for mu in range(4):
   for nu in range(4):J.add(cg[mu],w.scale(J.mul(J.mul(atom(4*b+mu),atom(4*c+nu)),F0[4*a+nu]),-J.times(G,z)))
 for i in range(328):
  for mu in range(4):J.add(cx[mu],J.mul(atom(180+i,(mu,)),F1[180+i]),-1)
 return [J.clean(p) for p in c0],[J.clean(p) for p in cg],[J.clean(p) for p in cx]
def div(current):return polyadd(*(J.D(p,mu) for mu,p in enumerate(current)))
def wrong_wick_free(S0g):
 eta=(1,-1,-1,-1);values=[]
 for keep_B0_phase in [True,False]:
  out={}
  for a in range(45):
   for mu in range(4):
    for nu in range(4):
     dmu=J.I if mu==0 else one;dnu=J.I if nu==0 else one
     bmu=J.I if mu==0 and keep_B0_phase else one;bnu=J.I if nu==0 and keep_B0_phase else one
     ff=polyadd(w.scale(atom(4*a+nu,(mu,)),J.times(dmu,bnu)),w.scale(atom(4*a+mu,(nu,)),-J.times(dnu,bmu)))
     J.add(out,w.scale(J.mul(ff,ff),J.constant(F(eta[mu]*eta[nu],4))))
  values.append(J.clean(out))
 assert values[0]==S0g
 delta=polyadd(values[1],w.scale(S0g,-one));assert delta
 return delta
def main():
 global ROLE
 ROLE=sys.argv[1];assert ROLE in ['native','replay'];role='primary' if ROLE=='native' else 'replay'
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=w.read(O/'preparation_v3.json')
 for n,h in prep['input_sha256'].items():assert w.digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert w.digest(O/n)==h,n
 target=str((R/('calculations/canonical_so10_full_jet_source_master_bridge/'+role+'_tables.json.gz')).resolve())
 peerprefix=str((O/('replay_' if ROLE=='native' else 'native_')).resolve());phase={'flow_allowed':ROLE=='replay'}
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve())
   if p==target:assert phase['flow_allowed'],'PHYSICAL_ACTION_DEFINED_FROM_FLOW_TARGET_DENIED'
   assert not p.startswith(peerprefix),'NEW_NATIVE_PEER_READ_DENIED'
 sys.addaudithook(guard)
 H=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
 action=w.read(H/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
 evidence=w.read(H/('frozen_a10_physical_reconciliation/full_'+role+'.json'))
 architecture=w.read(H/('frozen_a10_bv_master/'+role+'.json'))['architecture']
 framepacket=w.load(R/('calculations/canonical_so10_full_jet_source_master_bridge/'+role+'_inputs.json.gz'))
 ast=parse_kinetic_terms(action);pot=potential_types(action);artifacts={}
 if ROLE=='native':
  U,f,rho=physical_coefficients(framepacket['frame'],evidence,architecture,framepacket['xs'])
  S0g,S0x,S1g,S1x=build_action(f,rho)
  phase['flow_allowed']=True
  src=w.load(Path(target));Q={n:J.decode(p) for n,p in src['operation']}
  ff,rr,F0,F1=flow_coefficients(Q);assert f==ff and rho==rr,'ACTUAL_PHYSICAL_BRST_FRAME_MISMATCH'
 else:
  src=w.load(Path(target));Q={n:J.decode(p) for n,p in src['operation']}
  f,rho,F0,F1=flow_coefficients(Q)
  S0g,S0x,S1g,S1x=build_action(f,rho);U=None
 S0=polyadd(S0g,S0x);probe=source_probe_flows(src)
 save('coefficients',dict(f=[[list(k),w.enc(v)] for k,v in sorted(f.items())],rho=[[a,w.em(m)] for a,m in sorted(rho.items())],
                          actual_AST_Wick=ast,potential_scope=pot),artifacts)
 save('action',dict(S0_gauge=J.encode(S0g),S0_scalar=J.encode(S0x),S1_gauge=J.encode(S1g),S1_scalar=J.encode(S1x)),artifacts)
 save('field_flows',dict(original_F0=[[n,J.encode(F0[n])] for n in range(508)],original_F1=[[n,J.encode(F1[n])] for n in range(508)],
                           full_source_first_probe_flows=[[[n,J.encode(p[n])] for n in range(508)] for p in probe]),artifacts)
 print('STAGE '+ROLE+' actual physical action/BRST bridge and full probe source Euler',flush=True)
 if ROLE=='native':
  ee=J.euler(S0,set(range(508)));e0={n:ee.get(n,{}) for n in range(508)}
  gg=J.euler(S1g,set(range(180)));ss=J.euler(S1x,set(range(180)))
  e1g={n:gg.get(n,{}) for n in range(180)};e1x={n:ss.get(n,{}) for n in range(180)}
  current0=first_variation_current(S0,F0)
  current1g=[polyadd(a,b) for a,b in zip(first_variation_current(S0g,F1),first_variation_current(S1g,F0))]
  current1x=first_variation_current(S0x,F1)
 else:e0,e1g,e1x=closed_euler(f,rho);current0,current1g,current1x=closed_currents(f,rho,F0,F1)
 save('euler',dict(E0=[[n,J.encode(e0[n])] for n in range(508)],E1_B_gauge=[[n,J.encode(e1g[n])] for n in range(180)],E1_B_scalar=[[n,J.encode(e1x[n])] for n in range(180)]),artifacts)
 i0=multiply_sum(F0,e0,range(508))
 i1g=polyadd(multiply_sum(F1,e0,range(180)),multiply_sum(F0,e1g,range(180)))
 i1x=polyadd(multiply_sum(F1,e0,range(180,508)),multiply_sum(F0,e1x,range(180)))
 assert not polyadd(i0,w.scale(div(current0),-one)),'PHYSICAL_FREE_NOETHER_CURRENT_MISMATCH'
 assert not polyadd(i1g,w.scale(div(current1g),-one)),'PHYSICAL_GAUGE_G1_NOETHER_CURRENT_MISMATCH'
 assert not polyadd(i1x,w.scale(div(current1x),-one)),'PHYSICAL_SCALAR_G1_NOETHER_CURRENT_MISMATCH'
 gaugevar=polyadd(act(S0g,F1,True),act(S1g,F0,True));scalarvar=polyadd(act(S0x,F1,True),act(S1x,F0,True))
 assert not gaugevar and not scalarvar,'NONZERO_PHYSICAL_KINETIC_GAUGE_VARIATION'
 save('noether',dict(I0=J.encode(i0),I1_gauge=J.encode(i1g),I1_scalar=J.encode(i1x),
                    current0=[J.encode(p) for p in current0],current1_gauge=[J.encode(p) for p in current1g],current1_scalar=[J.encode(p) for p in current1x],
                    full_density_variations=[J.encode(gaugevar),J.encode(scalarvar)],Noether_residuals=[[],[],[]]),artifacts)
 print('STAGE '+ROLE+' all868 physical Euler columns and explicit g0/g1 Noether currents',flush=True)
 te0={n:tangent(p) for n,p in e0.items()};te1g={n:tangent(p) for n,p in e1g.items()};te1x={n:tangent(p) for n,p in e1x.items()}
 tf0={n:tangent(p) for n,p in F0.items()};tf1={n:tangent(p) for n,p in F1.items()}
 k0=multiply_sum(tf0,te0,range(508))
 k1g=polyadd(multiply_sum(tf1,te0,range(180)),multiply_sum(tf0,te1g,range(180)))
 k1x=polyadd(multiply_sum(tf1,te0,range(180,508)),multiply_sum(tf0,te1x,range(180)))
 shifted_i0=act(i0,{n:atom(1319+n) for n in range(643)})
 # Every i0 term is bilinear, so replacing ALL factors differs from one
 # first variation. Perform literal all-factor substitution instead.
 transported={}
 for word,c in i0.items():put(transported,[(1319+n,js) for n,js in word],c)
 assert k0==transported
 kcurrent=[]
 for cur in current0:
  p={}
  for word,c in cur.items():put(p,[(1319+n,js) for n,js in word],c)
  kcurrent.append(J.clean(p))
 assert not polyadd(k0,w.scale(div(kcurrent),-one))
 probe_kernels=[]
 for pr in [0,1]:
  tpu0={n:tangent(grade(p,0)) for n,p in probe[pr].items()};tpu1={n:tangent(grade(p,1)) for n,p in probe[pr].items()}
  ku0=multiply_sum(tpu0,te0,range(508))
  ku1=polyadd(multiply_sum(tpu1,te0,range(508)),multiply_sum(tpu0,te1g,range(180)),multiply_sum(tpu0,te1x,range(180)))
  probe_kernels.append(dict(probe=pr,u_g0=J.encode(ku0),u_g1=J.encode(ku1)))
 save('marked_kernels',dict(g0=J.encode(k0),g1_gauge=J.encode(k1g),g1_scalar=J.encode(k1x),g0_explicit_currents=[J.encode(p) for p in kcurrent],
                           probes=probe_kernels,mean_and_quantum_fields_distinct=True,eta_offset=1319),artifacts)
 del tf0,tf1,te0,te1g,te1x;gc.collect()
 for label,L in [('gauge',S1g),('scalar',S1x)]:
  t2=tangent(tangent(L));ordered=tangent(tangent(L),1962)
  save('ordinary_'+label,dict(full_T2_same_eta=J.encode(t2),quadratic_Taylor_half=J.encode(w.scale(t2,half)),
                            full_T_eta_T_kappa_ordered=J.encode(ordered),all_four_vector_components_retained=True),artifacts)
  del t2,ordered;gc.collect()
 print('STAGE '+ROLE+' physical marked kernels and both ordinary Hessian orders',flush=True)
 # Preserve full meaningful wrong expressions at the density/kernel level.
 wrongflow=polyadd(w.scale(multiply_sum(F1,e0,range(508)),J.constant(-2)))
 collapsed={}
 for word,c in polyadd(k1g,k1x).items():put(collapsed,[(n-1319 if 1319+553<=n<1319+598 else n,js) for n,js in word],c)
 controls=dict(wrong_B0_Wick_phase_minus_Euclidean=J.encode(wrong_wick_free(S0g)),reverse_g1_field_flow_Noether_residual=J.encode(wrongflow),omit_gauge_owner=J.encode(i1g),omit_scalar_owner=J.encode(i1x),
               collapse_quantum_C_minus_original=J.encode(polyadd(collapsed,w.scale(polyadd(k1g,k1x),-one))),
               g0_nonconstant_mark_requires_current=[J.encode(p) for p in kcurrent],loop_amplitude_sensitivity_claim=False)
 save('controls',controls,artifacts)
 summary=dict(schema='PHYSICAL_G0_G1_ACTION_CURRENT_INPUT_RECOVERY_V1',route=ROLE,
  canonical_f_nonzero=len(f),scalar_representation_entries=sum(len(m) for m in rho.values()),
  physical_source_columns=508,physical_Euler_columns=868,source_first_probe_physical_nonzero_columns=[sum(bool(p) for p in z.values()) for z in probe],
  action_terms=dict(S0_gauge=len(S0g),S0_scalar=len(S0x),S1_gauge=len(S1g),S1_scalar=len(S1x)),
  physical_Noether_density_terms=dict(g0=len(i0),g1_gauge=len(i1g),g1_scalar=len(i1x)),
  physical_marked_kernel_terms=dict(g0=len(k0),g1_gauge=len(k1g),g1_scalar=len(k1x)),
  source_free_potential_expanded=False,potential_mean_arity_proof=True,all_noether_residuals_zero=True,
  original_free_physical_current_is_explicit_divergence=True,artifacts=artifacts,
  elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED',physical_adoption_or_loop_amplitude_claim=False)
 with (O/(ROLE+'_v3_result.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(summary,f,sort_keys=True);f.write('\n')
 print('RESULT '+json.dumps({k:v for k,v in summary.items() if k!='artifacts'},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
