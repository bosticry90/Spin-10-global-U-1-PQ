# Distinct LEFT tangent replay, prospective V3

Native V2 is running under its unchanged contract and sources. The replay
has not launched. Use a separately frozen V3 replay source to strengthen
the current/Hessian check: derive each even tangent as eta_i times its
LEFT jet partial, retaining its parity-prefix sign and canonical reordering,
rather than reusing the native in-place replacement helper.

Physical coefficients still come from replayed BRST flows, the Euler
columns/currents from the closed covariant formulas, and all physical/
source inputs and Wick conventions remain unchanged. Only the method for
constructing the tangent/Hessian polynomials differs. This is no new
physical model, no relaxation of acceptance and no repeat of a completed
replay. All output/preparation/capture names use distinct V3 paths. Native
V2 and failed native V1 remain intact. Require complete mathematical artifact
comparison between native V2 and replay V3 after both complete.

Replay300s afterimports,8GiBsampled,350MiBfloor,64MiB complete packet,
same as the original physical input contract. Preserve failures; no silent
retry/resource expansion or dropping of physical/scalar/source terms.
