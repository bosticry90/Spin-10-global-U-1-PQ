# Physical action/current input recovery through g1, prospective V1

1. Question: which actual physical marked and ordinary vertices must enter
the missing unmarked current comparison? The surviving mixed-source action
contains gauge-fixing/source terms, not the physical kinetic action. V762–766
report that both physical owners matter to BLambdaC. Their missing tables
are specifications, not computational inputs.
2. Claim: reconstruct the original unshifted Euclidean A0 gauge/scalar
physical kinetic density through g0/g1, its necessary Euler columns and
Noether currents, and the physical T1F*T1E and ordinary T2S1 kernels. Keep
all four vector components, actual basis matrices, source-first probe flow
and distinct quantum/mean coordinates. No loop amplitude is computed here.
3. Domain/ceiling: one-loop input,firstconstant-u,g0/g1,intrinsic01, intended
integrated proper BLambdaC/LambdaJaC domain, all508 physical B/x fields.
Gauge/scalar only; no Yukawa/flavor resumption, new vacuum, benchmark,
physical action adoption, full QAP/measure, protected stage or E5/A5 claim.
4. Inputs: actual five kinetic ASTs, their physical representation/plane
structure tables, canonical source-frame and full source-derived original/
probe operations, approved scalar potential AST/type and old Noether
certificates. Authenticate their current Git bytes and frozen manifests.
No missing October coefficients, counts or desired amplitude are operands.
5. Native: lower the actual kinetic AST shape and signs, Wick rotate with
the inherited density minus/field and time-jet phases, transport its plane
fields via C3-to-plane times canonical-to-raw frame. Build full densities
and literal functional Euler columns. Compare their f/rho to actual BRST
field columns only AFTER physical construction, not by defining the action
to pass the symmetry test. Derive the four currents from first variation.
6. Replay: reconstruct the covariant kinetic coefficients from separately
replayed actual field flows, then use closed Maxwell/Yang-Mills/scalar Euler
formulas and explicit covariant first-variation currents. Compare complete
densities, all retained columns/kernels and zeros to the native method.
Shared chart/algebra/action/AIauthor remain; this is not outside validation.
7. Scope proof: g0 scalar field flow is checked, not imported. Determine
all physical probe field flows by full source Euler differentiation before
any mean restriction. Retain nonzero explicit-u physical currents if found;
do not assume the historical Fu_phys0 claim. The g1 E_x term can be omitted
from this current only if its actual g0 F_x partner is zero. Store g0 E_B/x,
g1 E_B gauge and scalar parts separately with all column complements.
8. Potentials remain contracted. Check every actual nonkinetic AST's field
content, scalar arity, parameter dimension and absence of vector/derivative
ports. In intrinsic01 any potential T1E_x leaves forbidden nonzero mean x
after T1F, so it cannot meet the intended zero-scalar-mean current. Prove
this with arity/source-flow bounds before excluding it. Its full off-shell
Noether invariance is an authenticated existing dependency, not a fresh
potential expansion. Do not infer scalar loop absence from the gauge-only
physical BBB result; retain scalar kinetic branches until matching proves
their lack of returning endpoints in the subsequent inventory.
9. Meaningful tests: literal Q0L1+Q1L0 density invariance in the kinetic
sector; complete physical Euler contraction equals an explicit divergence
at g0/g1; g0 T1F*T1E is the transported free Noether divergence, retained
with currents before removal in an integrated constant-mark domain. This
does not license its removal for a nonconstant local mark. Keep both
ordinary Hessian orders/even halves and distinct mean C/quantum etaC.
Controls omit physical ordinary/marked terms, wrong field/Euler sign,
wrong time Wick phase, omitted scalar/gauge owner and mean/eta collapse.
Report actual sensitivity; vertex changes do not prove loop sensitivity.
10. Resources: each serial native/replay route300s after imports,8GiB
sampled private,350MiB available-commit floor,complete64MiB packet. The
larger scope includes full physical g1 currents and ordered cubic Hessians,
not an extension of an old contract. Save separate complete artifacts to
release working memory; never silently truncate to fit. On failure retain
sources/captures and reassess, not automatic repeated expensive execution.
Final review180s with E4 once/no-fresh verifiedD:context,0,0,0,0,0,2 and
seven unresolved custodyNOTPASS. Sources and inputs frozen before launch.
11. Falsifiers/outcomes: a physical/BRST frame mismatch, nonzero unexplained
Noether remainder, missing scalar owner or nonzero source-first flow defeats
the corresponding simplification. A typed vertex inventory is not a nonzero
amplitude or a model failure. Preserve full failure/unfinished evidence;
correct routine harness errors prospectively without changing physical inputs.
12. Result/next decision: after validation, use actual physical marked and
ordinary kernels with the surviving gauge-fixing ones to recover the
returning BLambdaC current inventory and its minimal amplitudes. No blind
nine-M restart or kinetic refit. State113/34of39,E5/A5 unchanged; original
objective active. No agents,new branch/worktree,old evidence editing,remote
push,publication,outreach,spending or foundational acceptance.
