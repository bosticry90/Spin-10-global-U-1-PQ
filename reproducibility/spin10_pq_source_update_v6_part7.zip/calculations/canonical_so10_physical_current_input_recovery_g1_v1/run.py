from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/physical-current-input-recovery-g1-v1-2026-11-06')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_capture.json')).exists()
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='0ee9b5f781f124a8a84fadbc10914ee8853d98eb'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/LOCAL_STORAGE_LAYOUT_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V786.md',
 'docs/recovery_2026_11_06/RESEARCH_EXECUTION_HANDOFF_V762.md','docs/recovery_2026_11_06/RESEARCH_EXECUTION_HANDOFF_V764.md','docs/recovery_2026_11_06/RESEARCH_EXECUTION_HANDOFF_V765.md','docs/recovery_2026_11_06/RESEARCH_EXECUTION_HANDOFF_V766.md',
 'calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/quantum.py','calculations/canonical_so10_full_jet_source_master_bridge/jets.py',
 'calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
 'calculations/canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1/validation_receipt.json']
 for r in ['primary','replay']:
  names+=['calculations/canonical_so10_full_jet_source_master_bridge/'+r+'_'+suffix for suffix in ['inputs.json.gz','tables.json.gz']]
  names+=['tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation/full_'+r+'.json',
          'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_bv_master/'+r+'.json']
 for n in ['frozen_a10_executable_reconciliation','frozen_a10_physical_reconciliation','frozen_a10_bv_master','frozen_a10_bv_integration','frozen_a10_e2_transport','frozen_a10_e3_symmetry']:
  names.append('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'+n+'/bindings.json')
 names+=['tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json',
         'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_bv_integration/primary.json',
         'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e2_transport/primary.json']
 names=sorted(set(names))
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n]),n
 for n in ['RECORD.md','physical.py','run.py']:
  with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
 digest=lambda p:sha256(p.read_bytes()).hexdigest()
 dump(O/'preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in ['RECORD.md','physical.py','run.py']},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD']))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'physical.py'),route]);dump(O/(route+'_capture.json'),cap);dump(C/(route+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
