from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/physical-current-input-recovery-g1-v1-2026-11-06')
spec=importlib.util.spec_from_file_location('physical_final_tools',O/'physical_v4.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=w.J;A=w.A
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['source_sha256'].items():assert digest(R/n)==h,n
 for name in ['preparation.json','preparation_v2.json','preparation_v3.json','preparation_v4.json']:
  prep=read(O/name)
  for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
  for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 native=read(O/'native_v2_result.json');replay=read(O/'replay_v4_result.json')
 assert set(native['artifacts'])==set(replay['artifacts']) and len(native['artifacts'])==9
 for name,a in native['artifacts'].items():
  b=replay['artifacts'][name]
  assert a['sha256']==b['sha256'] and digest(O/a['file'])==a['sha256'] and digest(O/b['file'])==b['sha256']
  assert (O/a['file']).read_bytes()==(O/b['file']).read_bytes(),name
 assert {k:z for k,z in native.items() if k not in ['route','elapsed_after_imports','artifacts']}=={k:z for k,z in replay.items() if k not in ['route','elapsed_after_imports','artifacts']}
 assert native['physical_Euler_columns']==868 and native['physical_source_columns']==508
 assert native['source_first_probe_physical_nonzero_columns']==[0,0]
 assert native['canonical_f_nonzero']==1674 and native['scalar_representation_entries']==12560
 # Recheck actual raw/canonical block semantics independently of both
 # physical coefficient methods. In particular raw ghosts are name-indexed.
 for role in ['primary','replay']:
  fr=load(R/('calculations/canonical_so10_full_jet_source_master_bridge/'+role+'_inputs.json.gz'))['frame']
  for key in ['physical_to_raw_inverse','physical_to_raw_kernel']:
   entries=fr[key]['entries']
   scalars=[(i,j,c) for i,j,c in entries if 180<=i<508 or 180<=j<508]
   assert len(scalars)==328 and all(i==j and A.co(c)==J.constant(1) for i,j,c in scalars)
   assert all(i<180 and j<180 and i%4==j%4 for i,j,c in entries if i<180 or j<180)
 del fr;gc.collect()
 coefficients=load(O/native['artifacts']['coefficients']['file'])
 assert len(coefficients['potential_scope'])==29
 assert all(z['minimum_retained_mean_x_after_T1E'] is None or z['minimum_retained_mean_x_after_T1E']>=1 for z in coefficients['potential_scope'])
 assert len(coefficients['actual_AST_Wick']['gauge_Euclidean_weights'])==16
 del coefficients;gc.collect()
 euler=load(O/native['artifacts']['euler']['file']);assert [len(euler[k]) for k in ['E0','E1_B_gauge','E1_B_scalar']]==[508,180,180]
 del euler;gc.collect()
 flows=load(O/native['artifacts']['field_flows']['file'])
 assert len(flows['original_F0'])==len(flows['original_F1'])==508
 assert all(len(z)==508 and all(not p for n,p in z) for z in flows['full_source_first_probe_flows'])
 assert all(not p for n,p in flows['original_F0'] if n>=180)
 del flows;gc.collect()
 noether=load(O/native['artifacts']['noether']['file'])
 assert [len(noether[k]) for k in ['I0','I1_gauge','I1_scalar']]==[1080,100440,100480]
 assert all(len(noether[k])==4 for k in ['current0','current1_gauge','current1_scalar'])
 assert noether['full_density_variations']==[[],[]] and noether['Noether_residuals']==[[],[],[]]
 i0=J.decode(noether['I0']);j0=[J.decode(p) for p in noether['current0']]
 assert not w.plus(i0,w.scale(v.div(j0),-J.constant(1)))
 del noether,i0,j0;gc.collect()
 marked=load(O/native['artifacts']['marked_kernels']['file'])
 assert [len(marked[k]) for k in ['g0','g1_gauge','g1_scalar']]==[1080,200880,200960]
 assert marked['eta_offset']==1319 and marked['mean_and_quantum_fields_distinct']
 assert all(not row['u_g0'] and not row['u_g1'] for row in marked['probes'])
 free=J.decode(marked['g0']);cur=[J.decode(p) for p in marked['g0_explicit_currents']]
 assert not w.plus(free,w.scale(v.div(cur),-J.constant(1)))
 del marked,free,cur;gc.collect()
 action=load(O/native['artifacts']['action']['file'])
 ordinary_counts={}
 for name in ['gauge','scalar']:
  L=J.decode(action['S1_'+name]);p=load(O/native['artifacts']['ordinary_'+name]['file'])
  same=J.decode(p['full_T2_same_eta']);half=J.decode(p['quadratic_Taylor_half']);ordered=J.decode(p['full_T_eta_T_kappa_ordered'])
  assert same==w.scale(half,J.constant(2))
  identified={};diagonal={}
  for word,c in ordered.items():
   J.put(identified,tuple((n-643 if n>=1962 else n,js) for n,js in word),c)
  for word,c in same.items():J.put(diagonal,tuple((n-1319 if n>=1319 else n,js) for n,js in word),c)
  assert J.clean(identified)==same and J.clean(diagonal)==w.scale(L,J.constant(6))
  ordinary_counts[name]=dict(same_eta=len(same),ordered=len(ordered),Taylor_half=len(half),complete_cubic_polarization=True)
  del L,p,same,half,ordered,identified,diagonal;gc.collect()
 del action;gc.collect()
 controls=load(O/native['artifacts']['controls']['file'])
 keys=['reverse_g1_field_flow_Noether_residual','omit_gauge_owner','omit_scalar_owner','collapse_quantum_C_minus_original','wrong_B0_Wick_phase_minus_Euclidean']
 assert all(controls[k] for k in keys) and not controls['loop_amplitude_sensitivity_claim']
 control_counts={k:len(controls[k]) for k in keys};del controls;gc.collect()
 print('STAGE complete paired physical/source/frame/Noether/Hessian/control checks',flush=True)
 failures={}
 for filename,text in [('native_capture.json','assert T=='),('replay_v3_capture.json',"KeyError: 'architecture'")]:
  cap=read(O/filename);assert cap['exit_code']!=0 and not cap['calculation_completed'] and text in cap['stdout_and_stderr']
  failures[filename]='FAILED_PRESERVED'
 resources={}
 for stem,result in [('native_v2',native),('replay_v4',replay)]:
  cap=read(O/(stem+'_capture.json'))
  assert cap['exit_code']==0 and cap['calculation_completed'] and cap['execution_state']=='COMPLETED' and cap['post_run_observations_qualified']
  assert result['elapsed_after_imports']<=300 and cap['launch']['memory']['available_pagefile']>=350*1024**2
  assert cap['all_resource_samples'] and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
  resources[stem]=dict(seconds_after_imports=result['elapsed_after_imports'],largest_private_sample=max(z['private_bytes'] for z in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4']
 et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED')
 dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()]
 exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]
 assert events[-1]['execution_state']=='COMPLETED'
 custody=next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')
 assert custody['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
 subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V787.md']
 size=sum(p.stat().st_size for p in files);assert size<=64*1024**2
 out=dict(schema='PHYSICAL_CURRENT_INPUT_RECOVERY_G1_VALIDATION_V1',execution_state='COMPLETED',
 evidence_validation='PASS_COMPLETE_PAIRED_PHYSICAL_ACTION_CURRENT_KERNEL_INPUTS',scientific_acceptance='NOT_PERFORMED',
 base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,
 paired_artifacts={name:a['sha256'] for name,a in native['artifacts'].items()},complete_all9_math_artifact_pairs_byte_equal=True,
 physical_Euler_columns=868,source_first_physical_probe_columns_per_probe=508,source_first_physical_probe_flows_zero=True,
 physical_Noether_terms=native['physical_Noether_density_terms'],physical_marked_terms=native['physical_marked_kernel_terms'],
 ordinary_counts=ordinary_counts,control_counts=control_counts,
 potential_expansion='NOT_RERUN; DIFFERENTIATED_ARITY_EXCLUSION_AND_AUTHENTICATED_OFFSHELL_DEPENDENCY',
 loop_amplitudes_or_physical_adoption_claim=False,failures=failures,resources=resources,
 E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',
 old_mode_blob_entries_preserved=len(old.splitlines()),old_tracked_files='GIT_DIFF_UNCHANGED; ALL_PREPARED_INPUT_HASHES_MATCH',
 new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},
 packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,
 full_QAP_E5_or_physical_viability_claim=False)
 dump(O/'validation_receipt.json',out)
 print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
