# Unused replay architecture lookup, prospective V4 correction

Native V2 completed in162.431747s with complete physical action/current
artifacts. Replay V3 FAILED before any replay coefficient construction:
the raw BV replay record has no architecture key. The native route needs
that primary architecture for its physical plane-frame transport; the
distinct replay instead derives coefficients from the replayed field flows
and never uses that variable. The source read it unconditionally.

V4 makes only that metadata read conditional on the native branch. It does
not supply a primary architecture in place of missing replay evidence, alter
any BRST/physical input, omit a used scientific calculation or rerun native.
The replay's own frame, field/source maps, closed Eulers/currents and LEFT
tangent method remain unchanged. V3 source/preparation/capture remainFAILED;
distinctV4 paths own any new outputs. No V3 artifacts were produced.

Same300s/8GiBsampled/350MiBfloor/64MiBcompletepacket and all physical,
Noether, source, Hessian and control obligations. Preserve further failures
and reassess repeated problems; do not weaken the mathematical comparison.
