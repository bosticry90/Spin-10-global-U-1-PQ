from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/physical-current-input-recovery-g1-v1-2026-11-06')
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
route=sys.argv[1];assert route=='replay';assert not (O/'replay_v4_capture.json').exists()
if not (O/'preparation_v4.json').exists():
 old=json.loads((O/'preparation.json').read_bytes())
 for n,h in old['input_sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h,n
 for n in ['REPLAY_SCHEMA_CONTINUATION_V4.md','physical_v4.py','run_v4.py']:
  with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
 names=['RECORD.md','FRAME_CONTINUATION_V2.md','REPLAY_SCHEMA_CONTINUATION_V4.md','physical_v4.py','run_v4.py']
 dump(O/'preparation_v4.json',dict(base_HEAD=old['base_HEAD'],input_sha256=old['input_sha256'],source_sha256={n:sha256((O/n).read_bytes()).hexdigest() for n in names},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'physical_v4.py'),'replay']);dump(O/'replay_v4_capture.json',cap);dump(C/'replay_v4_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
