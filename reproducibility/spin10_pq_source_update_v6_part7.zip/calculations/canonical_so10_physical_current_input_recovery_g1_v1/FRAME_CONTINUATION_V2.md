# Raw versus canonical ghost positions, prospective V2 correction

V1 native FAILED before physical coefficient/action construction. Its
source/capture/preparation remain unchanged. The actual frame row order
places raw C0..C44 at508..552, while the canonical output ghost columns
are553..597. The check compared the right canonical columns to the wrong
raw rows by assuming both orders were the same.

V2 indexes raw C rows through the recorded field_order names, and retains
the exact equality of the ghost and vector color transformations. No
matrix, physical coefficient or requirement is changed. Use distinct V2
sources/preparation/captures/artifacts; V1 remains FAILED. Both routes keep
the300s/8GiBsampled/350MiBfloor/64MiBcompletepacket bounds. No silent rerun
of a completed expensive calculation; V1 had written no action artifacts.

The unchanged initial record also required a wrong-time-Wick-phase control.
The V2 source implements that missing control by reconstructing the raw
free gauge density with the B0 phase deliberately omitted, while retaining
time-jet phases. Its difference from the correctly transported Euclidean
action is stored in full. This supplies an existing verification obligation;
it changes no scientific input or acceptance threshold.
