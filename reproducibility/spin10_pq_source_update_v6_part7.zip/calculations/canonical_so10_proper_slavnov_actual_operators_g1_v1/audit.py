from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import gc,gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('proper_audit',O/'factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def rh(rows):return sha256((json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def word(row):return tuple((n,tuple(js)) for n,js in row)
def check_projection(raw,selected,journal,target,degree,intrinsic=False):
 kept=journal['kept_raw_indices'];bad={}
 for rec in journal['rejected']:
  for i in rec['raw_indices']:assert i not in bad;bad[i]=rec['reason']
 assert len(kept)+len(bad)==len(raw) and set(kept).isdisjoint(bad) and set(kept)|set(bad)==set(range(len(raw)))
 assert selected==[raw[i] for i in kept]
 for i,row in enumerate(raw):assert m.reason(word(row[0]),target,degree,intrinsic)==bad.get(i)
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'audit_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 packet=load(O/'native_inputs.json.gz');states={k:dict(v) for k,v in {**packet['states'],**packet['physical']}.items()}
 nr=read(O/'native_result.json');units_checked=0;factors_checked=0;raw_words=0
 for channel,target in m.TARGET.items():
  factors=load(O/('native_proper_factors_'+channel+'.json.gz'));fm={}
  for f in factors['factors']:
   n=f['field'];name=f['state'];degree=f['quantum_degree'];original=states[name].get(n,[])
   assert f['original_terms']==len(original) and f['original_math_sha256']==rh(original)
   if degree==2:
    elig=f['T2_eligibility'];ii=elig['kept_original_indices'];bb={}
    for row in elig['rejected']:
     for at in row['original_indices']:assert at not in bb;bb[at]=row['reason']
    assert len(ii)+len(bb)==len(original) and set(ii).isdisjoint(bb) and set(ii)|set(bb)==set(range(len(original)))
    # Recompute the necessary replacement bound directly on serialized words.
    for at,(ww,cc) in enumerate(original):
     fields=0;badcount=0;counts=[0]*3;fixed=[0]*4;why=None
     for nn,js in ww:
      s=m.slot(nn)
      if nn<643:
       fields+=1
       if s is None:badcount+=1
       else:counts[s]+=1
      else:
       if s is None:why='FORBIDDEN_FIXED_SOURCE';break
       fixed[s]+=1
     if not why and any(a>b for a,b in zip(fixed,target)):why='FIXED_SOURCE_BUDGET_EXCEEDED'
     if not why and fields<2:why='LESS_THAN_TWO_FIELD_FACTORS'
     if not why and badcount+sum(max(a-b,0) for a,b in zip(counts,target[:3]))>2:why='MORE_THAN_TWO_REQUIRED_FIELD_REPLACEMENTS'
     assert why==bb.get(at)
    raw=f['full_T2_half_of_eligible']
   else:raw=original
   check_projection(raw,f['selected'],f['projection'],target,degree)
   key=name,n,degree;assert key not in fm;fm[key]=rh(f['selected']);factors_checked+=1
  del factors;gc.collect()
  for row in nr['cases']:
   if row['channel']!=channel:continue
   z=load(O/row['units']['file']);proper=load(O/row['math']['file']);seen=set();sums={'Qfield':{},'Dsource':{}}
   expected={(kind,left,right,n) for left,right in z['branches'] for n in range(643) for kind in ['Qfield','Dsource']}
   for unit in z['units']:
    kind,left,right,n=(unit[k] for k in ['kind','left','right','field']);key=kind,left,right,n;assert key not in seen;seen.add(key)
    ld,rd=(0,2) if kind=='Qfield' else (2,0)
    assert unit['left_math_sha256']==fm[left,n,ld] and unit['right_math_sha256']==fm[right,n,rd]
    raw=unit['raw_product'];selected=[raw[i] for i in unit['kept_raw_indices']]
    check_projection(raw,selected,unit,target,2,True);J.add(sums[kind],J.decode(selected));raw_words+=len(raw);units_checked+=1
   for kind,left,right,n,why in z['zero_units']:
    key=kind,left,right,n;assert key not in seen;seen.add(key);assert why in ['ZERO_SAFE_LEFT_FACTOR','ZERO_SAFE_RIGHT_FACTOR','ZERO_GRADED_PRODUCT']
    ld,rd=(0,2) if kind=='Qfield' else (2,0)
    if why=='ZERO_SAFE_LEFT_FACTOR':assert fm[left,n,ld]==rh([])
    if why=='ZERO_SAFE_RIGHT_FACTOR':assert fm[right,n,rd]==rh([])
   assert seen==expected and len(seen)==z['complete_dispositions']
   for kind in sums:assert J.encode(J.clean(sums[kind]))==proper[kind]
   print('STAGE audit '+channel+' '+row['owner']+' '+row['case'],flush=True);del z,proper,sums;gc.collect()
 assert raw_words==nr['total_nonzero_raw_product_words']==1371212
 out=dict(schema='ACTUAL_PROPER_OPERATOR_AUDIT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all_original_input_hashes_and_eligibility_partitions=True,all_factor_and_raw_product_projection_journals=True,all_branch_port_dispositions_unique_and_complete=True,all_saved_product_sums_equal_proper_kernels=True,raw_product_words=raw_words,nonzero_units_checked=units_checked,factors_checked=factors_checked,T2_not_recomputed_native_replay_pairs_inherited=True,graded_product_implementation_shared=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'audit_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
