# Operand authentication before replay and dependent checks

Nativecompleted219.909395s/300s. Its copied classicaloperandpacket was
hash-checked against preparation while the worker was live; both role
packets were byte-identical. No packet mutation occurred. The factory
readguard denies upstream GFcommon/currentcontainers and sealedcurrent
targets after inputauthentication. All its operands were copied before
freeze, with the recordedsha. Dependentchecks must authenticate these
packet hashes explicitly again, not infer contents from filenames.

The original preparer named an optional legacyphysicalreceipt_v3 path;
the actual owning file is physical_current_input_recovery_g1_v1/
validation_receipt.json. Its absence did not change any physicalinput
bytes; the existing classicalEuler bytes were already authenticated.
The checked replay controller now binds/authenticates the correct
owningreceipt and explicitownoperandsha BEFORE launching the unchanged
frozen replay factory. Finalreview must bind this supplementalpreparation
andbothpacket hashes aswell. No native rerun or oldreceipt rewrite.
This is an authentication/controller correction, not a failed scientific
run or a relaxed qualification requirement. Same300s and128MiBpacket.
