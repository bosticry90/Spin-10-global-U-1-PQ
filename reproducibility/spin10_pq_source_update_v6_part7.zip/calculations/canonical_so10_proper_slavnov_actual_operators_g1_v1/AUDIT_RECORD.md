# Complete proper-operator serialization and projection audit

This audit checks the new target-specific pruning and aggregation evidence;
it does not repeat qualified physics factories. Bind both native/replay
operand hashes and all fifty paired artifacts before launch. Independently
scan every saved original word for the fixed-source and two-replacement
eligibility bounds. Check every retained/rejected index partition, original
polynomial hash, factor projection, product projection, unique full branch
port disposition, factor linkage and final sum. Count all 1,371,212 raw
nonzero product words. Missing physical E1_x is not introduced as zero.

The audit reuses the coefficient ring and projection type functions and
does not independently reimplement graded multiplication or reexecute the
two T2 derivations. Their shared-error limits remain. The raw saved sums
must equal the independently paired proper kernels. A source or index
failure is evidence-validation failure, not a changed scientific gate.

Freeze before this separate 300-second after-import bounded audit, 8GiB
sampled private /350MiB launch floor /128MiB whole packet. Execute serially
after the dependent comparison ends. Preserve any failed source/capture.
Final180s owns bytes/resources/authority/oldtree and E4once-no-fresh, not a
silent extension of any scientific or audit worker. No promotion or push.
