# Isolated final three cases and complete case-evidence collection

Both whole-comparison coordinators exhausted their frozen300s limits,
exit124. V1 completed11 cases; V2 freshly checked those cases and completed
10 more. Its capture records21 successful STAGE lines. Neither parent
execution is PASS. Preserve all sources, captures and output bytes.

The repeated large-vector reconstruction consumed most of V2's allowance.
Do not repeat that expensive qualified case work. A new isolated120s worker
computes only source/physical original_g1, probe0_g1 and probe1_g1, from
actual independent proper kernels and actual full raw physical current.
Its original case retains both gauge and scalar current operands. Probe
currents vanish by the same actual action/probe support, not by fitting.
Use the unchanged grouped IBP identity and full reconstruction. Save new
late_v3 files, never overwrite a partial or completed V2 file.

After this worker completes, a separate120s case collector authenticates
all source/input/output hashes, maps exactly24 unique expected cases to
their original case files, checks normal forms and recorded reconstruction,
matches every one of the21 earlier cases to its actual terminal STAGE
capture, retains the four omission controls, and creates the aggregate
result. Outputs and complete source/capture provenance are bound before
collection. Case-level completed algebra may be reused from an incomplete
parent; this does not convert either parent execution into PASS. No missing
or unprinted case is inferred complete. The source/proper word audit and
final E4/oldtree/state checks remain separately mandatory.

Both new workers retain8GiB sampled-private/350MiB launch floor/128MiB
whole packet. These are justified, smaller isolated computations under
current standing delegation; the two old300s allowances remain immutable.
Two timeouts demonstrate an AI resource-estimation/orchestration failure,
not a refutation or a license to weaken the scientific checks. If the final
three cases survive or fail reconstruction, preserve and report that result.
No numeric Gamma coefficient or protected promotion is accepted here.
