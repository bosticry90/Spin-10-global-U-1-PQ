from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict,Counter
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
sp=importlib.util.spec_from_file_location('proper_actual_taylor',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/('physical_v2.py' if ROLE=='native' else 'physical_v4.py'));v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
w=v.w;J=v.J;one=J.constant(1);half=J.constant(F(1,2))
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def mh(p):return sha256((json.dumps(J.encode(p),sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2,'COMPLETE_PROPER_OPERATOR_PACKET_LIMIT'
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def slot(n):return 0 if n<180 else 1 if 508<=n<553 else 2 if 553<=n<598 else 3 if 1241<=n<1286 else None
TARGET={'vector':(1,1,1,0),'source':(0,1,1,1)}
def reason(word,target,qdegree,intrinsic=False):
 counts=[0]*4;quantum=0
 for n,js in word:
  if 1319<=n<1962:quantum+=1;continue
  k=slot(n)
  if k is None:return 'FORBIDDEN_MEAN'
  counts[k]+=1
 if quantum!=qdegree:return 'WRONG_QUANTUM_DEGREE'
 if any(a>b for a,b in zip(counts,target)):return 'MEAN_BUDGET_EXCEEDED'
 if intrinsic:
  d=sum(J.dimension(n-1319 if 1319<=n<1962 else n)+len(js) for n,js in word)
  if 5-d not in [0,1]:return 'INTRINSIC_OUTSIDE_01'
 return None
def project(P,target,qdegree,intrinsic=False):
 out={};kept=[];bad=defaultdict(list)
 for at,(word,c) in enumerate(sorted(P.items())):
  why=reason(word,target,qdegree,intrinsic)
  if why:bad[why].append(at)
  else:out[word]=c;kept.append(at)
 return out,dict(kept_raw_indices=kept,rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(bad.items())])
def eligible(P,target):
 out={};kept=[];bad=defaultdict(list)
 for at,(word,c) in enumerate(sorted(P.items())):
  counts=[0]*3;fixed=[0]*4;forbidden=0;fields=0;why=None
  for n,js in word:
   if n<643:
    fields+=1;k=slot(n)
    if k is None:forbidden+=1
    else:counts[k]+=1
   else:
    k=slot(n)
    if k is None:why='FORBIDDEN_FIXED_SOURCE';break
    fixed[k]+=1
  if not why and any(a>b for a,b in zip(fixed,target)):why='FIXED_SOURCE_BUDGET_EXCEEDED'
  if not why and fields<2:why='LESS_THAN_TWO_FIELD_FACTORS'
  excess=forbidden+sum(max(a-b,0) for a,b in zip(counts,target[:3]))
  if not why and excess>2:why='MORE_THAN_TWO_REQUIRED_FIELD_REPLACEMENTS'
  if why:bad[why].append(at)
  else:out[word]=c;kept.append(at)
 return out,dict(kept_original_indices=kept,rejected=[dict(reason=k,original_indices=ids) for k,ids in sorted(bad.items())])
def cases(physical=False):
 out=[]
 for grade in [0,1]:
  branches=([('F0','P_E0')] if grade==0 else [('F1','P_E0'),('F0','P_E1_gauge'),('F0','P_E1_scalar')]) if physical else ([('F0','E0')] if grade==0 else [('F1','E0'),('F0','E1')])
  out.append(dict(case='original_g'+str(grade),g=grade,u=0,probe=None,branches=branches))
  for pr in [0,1]:
   if physical:branches=[('Fu0_'+str(pr),'P_E0')] if grade==0 else [('Fu1_'+str(pr),'P_E0'),('Fu0_'+str(pr),'P_E1_gauge'),('Fu0_'+str(pr),'P_E1_scalar')]
   else:branches=[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))] if grade==0 else [('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))]
   out.append(dict(case='probe'+str(pr)+'_g'+str(grade),g=grade,u=1,probe=pr,branches=branches))
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=json.loads((O/'preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
  p=str(Path(os.fsdecode(args[0])).resolve());assert not p.startswith(peer),'PEER_PROPER_OPERAND_OR_OUTPUT_DENIED'
  assert not ('GF_common' in p or 'assembled_GF_kernels' in p or 'raw_T1_factors' in p or 'hard_response' in p),'OLD_CURRENT_CONTAINER_TARGET_DENIED'
  assert not any(t in p for t in ['canonical_so10_vector_mixed30_g1_recovery','canonical_so10_regulator_source_colors_g1_recovery','canonical_so10_vector_expanded_regulator_reconciliation','canonical_so10_source_expanded_regulator_reconciliation']),'SEALED_CURRENT_TARGET_DENIED'
 sys.addaudithook(guard)
 packet=load(O/(ROLE+'_inputs.json.gz'));states={k:dict(rows) for k,rows in packet['states'].items()};states.update({k:dict(rows) for k,rows in packet['physical'].items()})
 assert all(list(dict(packet['states'][k]))==list(range(643)) for k in packet['states'])
 assert all(sum(n<643 for n,js in word)<=1 for n,raw in states['F0'].items() for word,c in J.decode(raw).items()),'F0_NOT_AFFINE'
 assert all(not raw for k in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1'] for n,raw in states[k].items() if n<508),'PROBE_PHYSICAL_FLOW_NOT_ZERO'
 assert all(sum(n<643 for n,js in word)<=1 for n,raw in states['P_E0'].items() for word,c in J.decode(raw).items()),'PHYSICAL_KINETIC_E0_NOT_LINEAR'
 allart=[];summaries=[];total_products=0
 for channel,target in TARGET.items():
  cache={};factor_rows=[]
  def factor(name,n,degree):
   key=name,n,degree
   if key in cache:return cache[key]
   if name.startswith('P_E1_') and 180<=n<508:raise AssertionError(('UNCOMPUTED_PHYSICAL_E1_SCALAR_PORT_REQUIRED',name,n))
   P=J.decode(states[name].get(n,[]));row=dict(state=name,field=n,quantum_degree=degree,original_terms=len(P),original_math_sha256=mh(P))
   if degree==2:
    elig,eligjournal=eligible(P,target);raw=w.scale(v.tangent(v.tangent(elig)),half);row.update(T2_eligibility=eligjournal,full_T2_half_of_eligible=J.encode(raw))
   else:raw=P
   selected,journal=project(raw,target,degree);row.update(projection=journal,selected=J.encode(selected));factor_rows.append(row);cache[key]=selected
   return selected
  for owner,physical in [('GF',False),('physical',True)]:
   for case in cases(physical):
    sums={'Qfield':{},'Dsource':{}};jaomit={};units=[];zeros=[]
    for left,right in case['branches']:
     for n in range(643):
      for kind,ld,rd in [('Qfield',0,2),('Dsource',2,0)]:
       lp=factor(left,n,ld)
       if not lp:zeros.append([kind,left,right,n,'ZERO_SAFE_LEFT_FACTOR']);continue
       rp=factor(right,n,rd)
       if not rp:zeros.append([kind,left,right,n,'ZERO_SAFE_RIGHT_FACTOR']);continue
       raw=J.mul(lp,rp)
       if not raw:zeros.append([kind,left,right,n,'ZERO_GRADED_PRODUCT']);continue
       selected,journal=project(raw,target,2,True);J.add(sums[kind],selected)
       units.append(dict(kind=kind,left=left,right=right,field=n,left_math_sha256=mh(lp),right_math_sha256=mh(rp),raw_product=J.encode(raw),**journal));total_products+=len(raw)
       if kind=='Qfield' and left.startswith('Fu0'):
        ja={word:z for word,z in lp.items() if any(1241<=nn<1286 for nn,js in word)}
        omitted,_=project(J.mul(ja,rp),target,2,True);J.add(jaomit,omitted)
    assert len(units)+len(zeros)==2*643*len(case['branches'])
    sums={k:J.clean(z) for k,z in sums.items()};jaomit=J.clean(jaomit)
    math=save('proper_'+channel+'_'+owner+'_'+case['case'],dict(channel=channel,owner=owner,case=case['case'],g=case['g'],u=case['u'],probe=case['probe'],Qfield=J.encode(sums['Qfield']),Dsource=J.encode(sums['Dsource']),omit_mean_Ja_Q_difference=J.encode(w.scale(jaomit,J.constant(-1))),all643_ports_per_branch=True))
    unit=save('units_'+channel+'_'+owner+'_'+case['case'],dict(branches=case['branches'],units=units,zero_units=zeros,complete_dispositions=len(units)+len(zeros)))
    summaries.append(dict(channel=channel,owner=owner,case=case['case'],Qfield_terms=len(sums['Qfield']),Dsource_terms=len(sums['Dsource']),omit_mean_Ja_changed_terms=len(jaomit),math=math,units=unit));allart.extend([math,unit]);del units,zeros,sums,jaomit;gc.collect()
    print('STAGE '+ROLE+' '+channel+' '+owner+' '+case['case']+' Q'+str(summaries[-1]['Qfield_terms'])+' D'+str(summaries[-1]['Dsource_terms']),flush=True)
  factors=save('proper_factors_'+channel,dict(channel=channel,factors=factor_rows,source_Eulers_precede_all_restrictions=True,T2_eligibility_replacements_bound=2,unknown_physical_E1_x_never_read=True));allart.append(factors);del cache,factor_rows;gc.collect()
 result=dict(schema='ACTUAL_PROPER_SLAVNOV_OPERATORS_G1_V1',route=ROLE,execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=summaries,artifacts=allart,total_nonzero_raw_product_words=total_products,F0_affine_all643=True,physical_E0_kinetic_linear_all508=True,unknown_physical_E1_x_bypassed_by_zero_F0_Fu0=True,physical_probe_flows_all508_zero=True,source_and_mean_differentiation_complete_before_restriction=True,elapsed_after_imports=time.perf_counter()-tick,Gaussian_loop_amplitudes_not_yet_evaluated=True,current_target_not_read=True)
 with (O/(ROLE+'_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','total_nonzero_raw_product_words','elapsed_after_imports','current_target_not_read']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
