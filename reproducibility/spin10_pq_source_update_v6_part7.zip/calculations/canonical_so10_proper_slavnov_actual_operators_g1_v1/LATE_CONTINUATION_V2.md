# Bounded continuation after incomplete IBP comparison

V1 late_compare.py exhausted its frozen 300-second after-import limit,
exit124. Its original sources, preparation, full capture and eleven
completed case files remain unchanged. There is no V1 whole-result PASS.
This is computational incompleteness, not a nonzero scientific residual.
All eleven saved cases reported normal form zero before exhaustion.

V2 is a new 300-second bounded continuation under current standing
delegation, with the same 8GiB sampled-private, 350MiB launch floor and
128MiB whole-packet bound. No historical resource allowance is changed.
Actual proper operators and inputs are unchanged. There is no rerun of
the two completed proper factories and no change to the action or gate.

V2 groups rest polynomials by the distinguished ghost and its jets before
using the same repeated Leibniz identity. This is a linear regrouping of
the termwise proof, with all four boundary currents and the full normal
form retained. Completed V1 cases are reused only after fresh comparison
with actual Q+ D+ rawcurrent, and direct reconstruction of their full
divergence. Small g0 cases additionally compare the newly grouped result
with the old termwise currents and normal form. All remaining cases and
the source controls are calculated with the grouped method. A failed
parent calculation may contain completed mathematical cases; neither
authentication nor their reuse converts the parent execution into PASS.

Freeze all preserved files, sources, operands and new source bytes before
launch. Missing outputs, surviving normals, resource exhaustion or failed
reconstruction stay explicit. Final evidence validation must report the
incomplete V1 run separately from the completed cases and V2 disposition.
No protected scientific acceptance, amplitude transfer or goal completion.
