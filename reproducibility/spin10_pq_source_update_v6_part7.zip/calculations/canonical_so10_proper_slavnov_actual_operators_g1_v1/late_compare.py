from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('proper_late',O/'factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def isC(n):return 553<=n<598 or 1872<=n<1917
def normal_form(P):
 currents=[{} for _ in range(4)];normal={};pivot_counts=[0,0]
 for word,c in P.items():
  at=[i for i,(n,js) in enumerate(word) if 553<=n<598]
  if at:assert len(at)==1;pivot_counts[0]+=1
  else:at=[i for i,(n,js) in enumerate(word) if 1872<=n<1917];assert len(at)==1;pivot_counts[1]+=1
  pos=at[0];n,jets=word[pos];rest={word[:pos]+word[pos+1:]:J.constant(1)}
  cp=c*((-1)**sum(J.parity(i) for i,js in word[:pos]))
  for r,mu in enumerate(jets):
   cr=w.scale(J.mul({((n,tuple(jets[r+1:])),):J.constant(1)},rest),cp*((-1)**r))
   J.add(currents[mu],cr);rest=J.D(rest,mu)
  J.add(normal,w.scale(J.mul({((n,()),):J.constant(1)},rest),cp*((-1)**len(jets))))
 currents=[J.clean(p) for p in currents];normal=J.clean(normal)
 divergence={}
 for mu,cur in enumerate(currents):J.add(divergence,J.D(cur,mu))
 assert J.clean(divergence)==w.plus(P,w.scale(normal,J.constant(-1))),'FULL_IBP_RECONSTRUCTION'
 return currents,normal,pivot_counts
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'late_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 frozen=read(O/'proper_pairs_frozen.json');assert len(frozen['pairs'])==50
 for row in frozen['pairs']:assert digest(O/row['native'])==digest(O/row['replay'])==row['sha256']
 C=R/'calculations'
 gf0=load(C/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/native_GF_common.json.gz')
 gf1=load(C/'canonical_so10_full_current_inventory_g1_recovery_v1/native_assembled_GF_kernels.json.gz')
 phys=load(C/'canonical_so10_physical_current_input_recovery_g1_v1/native_v2_marked_kernels.json.gz')
 rows=[];art=[];allzero=True;controls=[]
 for channel,target in m.TARGET.items():
  for owner in ['GF','physical']:
   for case in m.cases(owner=='physical'):
    name='proper_'+channel+'_'+owner+'_'+case['case'];proper=load(O/('native_'+name+'.json.gz'))
    Q=J.decode(proper['Qfield']);D=J.decode(proper['Dsource'])
    if owner=='GF':
     if case['g']==0:raw=J.decode(gf0['K0'] if case['probe'] is None else gf0['Ku'][case['probe']])
     else:raw=J.decode(next(a['kernel'] for a in gf1['assemblies'] if a['channel']==channel and a['case']==case['case'].removesuffix('_g1')))
    elif case['probe'] is not None:raw={}
    elif case['g']==0:raw=J.decode(phys['g0'])
    else:raw=w.plus(J.decode(phys['g1_gauge']),J.decode(phys['g1_scalar']))
    current,journal=m.project(raw,target,2,True);raw_count=len(raw);del raw
    residual=w.plus(Q,D,current);currents,normal,pivots=normal_form(residual);allzero=allzero and not normal
    a=save('late_'+channel+'_'+owner+'_'+case['case']+'.json.gz',dict(channel=channel,owner=owner,case=case['case'],current_raw_terms=raw_count,current_projection=journal,selected_current=J.encode(current),proper_Q_math_sha256=m.mh(Q),proper_D_math_sha256=m.mh(D),raw_residual=J.encode(residual),boundary_currents=[J.encode(p) for p in currents],normal_form=J.encode(normal),exact_full_reconstruction=True,pivot_mean_and_quantum_counts=pivots))
    art.append(a);rows.append(dict(channel=channel,owner=owner,case=case['case'],current_terms=len(current),raw_residual_terms=len(residual),boundary_terms=[len(p) for p in currents],normal_terms=len(normal)))
    # Small nonzero source cases demonstrate sensitivity without a redundant
    # large normalization. All blind cases remain reported as such.
    if channel=='source' and owner=='GF' and case['case'] in ['probe1_g0','probe0_g1']:
     tests={'omit_Dsource':w.plus(residual,w.scale(D,J.constant(-1))),'omit_mean_Ja_Q':w.plus(residual,J.decode(proper['omit_mean_Ja_Q_difference']))}
     for cn,P in tests.items():
      cc,nn,pp=normal_form(P);controls.append(dict(case=case['case'],control=cn,normal_terms=len(nn),artifact=save('control_'+case['case']+'_'+cn+'.json.gz',dict(raw_residual=J.encode(P),boundary_currents=[J.encode(z) for z in cc],normal_form=J.encode(nn),exact_full_reconstruction=True))))
    print('STAGE '+channel+' '+owner+' '+case['case']+' residual'+str(len(residual))+' normal'+str(len(normal)),flush=True)
    del Q,D,current,journal,residual,currents,normal,proper;gc.collect()
 result=dict(schema='ACTUAL_PROPER_CURRENT_MASTER_IBP_COMPARISON_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=rows,artifacts=art,controls=controls,all_normal_forms_zero=allzero,actual_proper_outputs_frozen_before_current_read=True,complete_raw_current_including_free_divergences=True,no_equations_of_motion=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'late_result.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','all_normal_forms_zero','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
