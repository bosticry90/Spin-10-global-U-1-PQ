from pathlib import Path
from hashlib import sha256
import gc,gzip,json,os,re,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'collect_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 c1=read(O/'late_capture.json');c2=read(O/'late_capture_v2.json');c3=read(O/'remaining_capture.json')
 assert c1['exit_code']==c2['exit_code']==124 and not c1['calculation_completed'] and not c2['calculation_completed']
 assert c3['exit_code']==0 and c3['calculation_completed'] and c3['post_run_observations_qualified']
 pattern=r'^STAGE (vector|source) (GF|physical) (\S+) residual(\d+) normal(\d+)$'
 def stages(c):
  z={}
  for line in c['stdout_and_stderr'].splitlines():
   m=re.match(pattern,line)
   if m:z[tuple(m.group(i) for i in [1,2,3])]=(int(m.group(4)),int(m.group(5)))
  return z
 s1,s2,s3=stages(c1),stages(c2),stages(c3);assert len(s1)==11 and len(s2)==21 and len(s3)==3
 assert set(s1).issubset(s2) and set(s2).isdisjoint(s3)
 cases=['original_g0','probe0_g0','probe1_g0','original_g1','probe0_g1','probe1_g1']
 expected={(channel,owner,case) for channel in ['vector','source'] for owner in ['GF','physical'] for case in cases}
 assert set(s2)|set(s3)==expected
 rows=[];art=[]
 for channel,owner,case in sorted(expected):
  key=channel,owner,case
  prefix='late_v3_' if key in s3 else 'late_' if key in s1 else 'late_v2_'
  p=O/(prefix+channel+'_'+owner+'_'+case+'.json.gz');z=load(p)
  assert (z['channel'],z['owner'],z['case'])==key and z['exact_full_reconstruction'] and not z['normal_form']
  count=len(z['raw_residual']);assert (count,0)==(s3 if key in s3 else s2)[key]
  if key in s1:assert s1[key]==s2[key]
  assert len(z['boundary_currents'])==4 and sum(z['pivot_mean_and_quantum_counts'])==count
  rows.append(dict(channel=channel,owner=owner,case=case,current_terms=len(z['selected_current']),raw_residual_terms=count,boundary_terms=[len(v) for v in z['boundary_currents']],normal_terms=0))
  art.append(dict(file=p.name,sha256=digest(p),bytes=p.stat().st_size,case_calculation_completed_and_reconstruction_checked=True,parent_execution='COMPLETED' if key in s3 else 'FAILED_TIMEOUT_INCOMPLETE'))
  del z;gc.collect()
 controls=[]
 for case in ['probe1_g0','probe0_g1']:
  for control in ['omit_Dsource','omit_mean_Ja_Q']:
   p=O/('control_v2_'+case+'_'+control+'.json.gz');z=load(p);assert z['exact_full_reconstruction'] and z['normal_form']
   controls.append(dict(case=case,control=control,normal_terms=len(z['normal_form']),artifact=dict(file=p.name,sha256=digest(p),bytes=p.stat().st_size)))
 result=dict(schema='ACTUAL_PROPER_CURRENT_MASTER_IBP_COMPARISON_COLLECTED_V3',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=rows,artifacts=art,controls=controls,all_normal_forms_zero=True,all24_case_calculations_completed=True,all24_exact_reconstructions_already_executed_before_case_STAGES=True,collector_reexecutes_algebra=False,incomplete_parent_executions_NOTPASS=2,previous11_cases_reconstructed_again_in_V2=True,complete_raw_current_including_free_divergences=True,actual_proper_outputs_frozen_before_current_read=True,no_equations_of_motion=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'collect_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','all_normal_forms_zero','all24_case_calculations_completed','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
