# Actual proper Slavnov field/source kernels through g1

Basee348c143bc897a6587a83db0f5867b69bf4d137a/main,V801. Priorincrement
PROGRESS: exact non-master/source-quadratic proper chain with7sensitive
gu controls, allsources retained. CurrentAGENTS/charter/fullgoal/D:first.
State113/34of39,E5/A5open unchanged. Noagents/branch/worktree/adoption/
promotion/protectedactivation/flavor/remoteaction. Educationnonblocking.

Scientific question: what are the actual proper QfieldGamma1 andDsource
local quadratic insertion kernels for the source/vector first-u,g1
Slavnov equation, rather than the alreadycomputed T1F*T1E covariance?
These operators are required to compare the same regulated parent and
assess finite restoration. Compute their complete coefficients first;
do not use the known covariance or an oldnine-M/VDI reported tensor as
an operand. Their identity/integration comparison is a LATE separate
step only after both proper outputs are frozen. No new benchmark platform.

Scope originalunshiftedEuclideanA0,gauge/scalar643-field properGaussian,
constantu,gradesg0/g1,probesH/M,intrinsic01,meanBLambdaC andLambdaJaC,
all45colors/4Lorentz,all643field andfullsource complements BEFORErestriction.
QualifiedV788/V789 full F/E states, V787 physicalkineticE0 andE1_B gauge/
scalar, V800LEFTsourceHamiltonian pairing, V801properchain. Physical
potential/fermion/hatted domains retain their prior qualified scopes;
not a fullchiralB0 assumption. Keepall source-quadraticu terms.

Prospective exact operators, even fieldTaylorT, sourcesfixed:
 KQ=sum meanF*T²E/2, KD=sum(T²F/2)*meanE.
For each g/u coefficient use the full convolution of F/E states:
 originalg0 F0E0;
 probeg0 Fu0E0+F0Eu0;
 originalg1 F1E0+F0E1;
 probeg1 Fu1E0+Fu0E1+F1Eu0+F0Eu1.
KQ/KD differentiate their respective factor, not both. MeanFu0_a includes
Ja and must remain (T1Fu0 alone loses it). Actual source differentiation
has already occurred in full F/E states before any mean-plane selection.

NativeprefixT² versus replayLEFTjetT², same complete classical operands.
Independent proper outputs include allzero fields/dispositions, raw
eligible T² factors/half, exact selection/rejection rows, allnonzero
products before finalprojection, summedkernels and sourceconstantJa
omission diagnostic. MissingT²half changes nonzero kernels. No loop
amplitude sensitivity inferred merely from polynomial change.

Safe eligibility BEFORE fieldT² is explicitly limited: BV sources are
fixed byT, so forbidden source factors or excessJa source budget cannot
be repaired. For other mean factors, two replacements can remove at most
two total excess/forbidden integrated factors. If forbiddenCount plus
sum max(allowedSlotCount-target,0)>2, or fewer than2fieldfactors, T²
cannot contribute. Prove/review this count rule; retain originalinput
hash and everyeligible/rejected rawindex. Then derive ALL T² of eligible
polynomial, retain its fullraw rows before the ordinary safe projection.
Meanfactors are independently projected only afterfullsourceEulers. A
zero safe mean partner justifies skipping its product, recorded explicitly.
Final product quantumdegree2/meanbudget/intrinsic01 projection unchanged.
This is a target-competent pruning proof, not a partialT² claimedcomplete.

Preparation copies only classical F/E/U operands from GFcommon containers,
which also hold oldcurrent fields. Worker never reads those containers
or current/gamma target artifacts; copied input packets contain no K0/Ku,
marked covariance, hardresponse or oldquantum target. Byteauthentication
of upstream containers is distinct from numericalcurrent use. Newstates
are classicalEuler/flow operands, not current products. Peerinputs/outputs
are denied in scientificworkers. Existing action/reference factories not
rerun. Exacttransport/ring/Euler/AIauthor shared limitations disclosed.

Physicalowner separate: actual E0 all508 and E1_B180 eachgauge/scalar;
verify E0kineticlinear andT²0. UnknownphysicalE1_x values are NOT serialized
as0: they are bypassed only because actualF0_x/Fu0_x andtheirTaylor maps
are0. SourcefreeDphysical F1_x''*E0_x has forbidden meanx inthisdeclared
unshifteddomain; earlierpotential exclusion reused withits scope.
PhysicalE1_B gaugeANDscalar remain inKQ, physicalE0_B inKD. Explicit
physicalu-currentroots vanish only byactualprobephysicalflows0 and
Sphys independentu; physicalordinaryBBB inverseinsertions still retained
in subsequent Gaussian contraction. No change to physical action or inputs.

Native/replay300s eachafterimports,8GiBsampledprivate/350MiBlaunchfloor,
128MiBcompletepacket; vector/sourceproperT² largerthanpreviousT1
comparator and this new bound is frozen beforecomputation. No oldallowance
changed. Final180s; preservefailed/incomplete sources/captures, observe
exhaustion, no silentexpansion/truncation. SyntaxparseactualPython3.10
beforefreeze. Native/replay serial; dependentlatechecks afterboth complete.

Later separate boundedreview may compare KQ+KD to the independently
frozen covariance and T²B/2, retaining explicit integrated currents.
Do not assume thefullchiralIhat insertion0: CPS permits only scoped
fermionmeans/K0 block-independence, withsourceoperationsfirst. Scalar
referenceconstantchains may not be bounded by g/u counting alone;
prove their nonreturning support beforeusing the usual6-vertex catalog.
Inverseheat/inversef externalmean terms are paired wholeproducts only.
No newquantumcounterterm, baseline, normalizationscheme or parameterfit.
GammaEuclidean/i/Wick normalization must be calibrated beforeamplitude
transfer. CommonH-T=11Q/36 freebaseline retained, not refitted.

Owningfinalreceipt must separate newproperoperator evidence from inherited
loops/proofs and any unfinishedmodelcomparison. E4once/no-freshDcontext
0,0,0,0,0,2/seven custodyNOTPASS, oldtree/state unchanged, stagedrawbytes/
modes beforelocalcommit. No scientificacceptance/QAP/measure/equivalence/
E5/A5/viability/goalcompletion claim. Continue mostinformative nextstep.
