from pathlib import Path
from hashlib import sha256
import gc,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('remaining_actual_proper',O/'late_compare_v2.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in m.read(O/'remaining_preparation.json')['sha256'].items():assert m.digest(R/n)==h,n
 phys=m.load(R/'calculations/canonical_so10_physical_current_input_recovery_g1_v1/native_v2_marked_kernels.json.gz')
 raw=w.plus(J.decode(phys['g1_gauge']),J.decode(phys['g1_scalar']));del phys;gc.collect()
 target=m.m.TARGET['source'];current,journal=m.m.project(raw,target,2,True);raw_count=len(raw);del raw;gc.collect()
 rows=[];art=[]
 for case in ['original_g1','probe0_g1','probe1_g1']:
  proper=m.load(O/('native_proper_source_physical_'+case+'.json.gz'));Q=J.decode(proper['Qfield']);D=J.decode(proper['Dsource'])
  cur=current if case=='original_g1' else {};jj=journal if case=='original_g1' else dict(kept_raw_indices=[],rejected=[])
  residual=w.plus(Q,D,cur);currents,normal,pivots=m.normal_form(residual)
  a=m.save('late_v3_source_physical_'+case+'.json.gz',dict(channel='source',owner='physical',case=case,current_raw_terms=raw_count if case=='original_g1' else 0,current_projection=jj,selected_current=J.encode(cur),proper_Q_math_sha256=m.m.mh(Q),proper_D_math_sha256=m.m.mh(D),raw_residual=J.encode(residual),boundary_currents=[J.encode(p) for p in currents],normal_form=J.encode(normal),exact_full_reconstruction=True,pivot_mean_and_quantum_counts=pivots))
  art.append(a);rows.append(dict(channel='source',owner='physical',case=case,current_terms=len(cur),raw_residual_terms=len(residual),boundary_terms=[len(p) for p in currents],normal_terms=len(normal)))
  print('STAGE source physical '+case+' residual'+str(len(residual))+' normal'+str(len(normal)),flush=True)
 result=dict(schema='ISOLATED_REMAINING_PROPER_CURRENT_CASES_V3',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=rows,artifacts=art,all_normal_forms_zero=all(r['normal_terms']==0 for r in rows),elapsed_after_imports=time.perf_counter()-tick)
 m.dump(O/'remaining_result.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','all_normal_forms_zero','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
