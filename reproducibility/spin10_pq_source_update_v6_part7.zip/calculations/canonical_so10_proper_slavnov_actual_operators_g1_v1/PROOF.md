# Actual proper operators and their integrated master comparison

This packet constructs the proper operators from classical operands. It
does not define an unknown proper amplitude by subtracting a known current.
The fifty native/replay artifacts were frozen in proper_pairs_frozen.json
before the late current comparison. Both routes retain all 643 source
Euler ports before applying the selected mean plane. The native route uses
prefix substitution; replay uses LEFT jet differentiation. The action,
coefficient ring, chart, field numbering, some helpers and AI author are
shared. Agreement is an implementation cross-check, not independent
scientists, a formal proof kernel or experimental validation.

## Operator identity and safe pruning

Let F_i=(-1)^p_i EL_(J_i)S and E_i=EL_(phi_i)S, with the source-Hamiltonian
convention verified in V800. Field Taylor T is even, with fixed sources.
The independently constructed kernels are

    KQ = sum F_i (T^2 E_i)/2,
    KD = sum (T^2 F_i)/2 E_i.

Each coefficient contains the full g/u convolution recorded in RECORD.
The source term KD has the sign of (-1)^p_i E_i Gamma_(J_i), because
Gamma_(J_i)=(-1)^p_i <T^2 F_i/2>. No extra ghost sign is introduced after
this LEFT pairing. The even Taylor product rule gives

    KQ + KD + KC = T^2(sum F_i E_i)/2,
    KC = sum (TF_i)(TE_i).

The mean budgets used by the code are upper bounds, not exact counts.
Keeping every sub-budget word allows the subsequent inverse expansion to
supply external means. Intrinsic coefficient dimensions zero and one and
quantum degree two are kept, as in the qualified current construction.
For a candidate factor, any fixed forbidden source or excess Ja cannot be
removed by field Taylor differentiation. For integrated fields, two Taylor
replacements can remove at most two forbidden/excess factors in total.
The recorded eligibility test is therefore a necessary condition for a
contributing T^2 word. It cannot exclude a valid contribution. Complete
T^2/2 is computed on every eligible original word and retained before
factor and product projections. No partial Taylor expression is labelled
the full unrestricted T^2 polynomial. Every input index and every branch
port has a retained disposition, including zero partners.

Unknown physical E1_scalar-field ports are not set to zero. They can be
bypassed only because the actual F0 and probe field flows, and their
Taylor maps, vanish at those ports. E0 is the actual linear kinetic Euler
map of all 508 physical fields. Both gauge and scalar contributions to
E1_B remain, as does the nonzero Dsource F1_B'' E0_B contribution. A
nonzero scalar mean in E0_x lies outside this selected mean plane. The
potential exclusion is reused only in its previously justified intrinsic
zero-scalar-mean scope. This does not exclude scalar ordinary insertions
from another amplitude or count constant reference chains by g/u alone.

## A complete integration-by-parts test in this projection

Each selected word has a unique mean ghost C, if a mean C is present.
Otherwise ghost number one and the two-fluctuation degree force a unique
quantum C. The mean and quantum ghosts are independent jet generators.
Move this distinguished odd C to the front with its graded permutation
sign, then transfer its ordered derivative jets to the other factors.
For jets mu_0,...,mu_(k-1), successive Leibniz identities give

    (D_mu0 ... D_mu(k-1) C) A
      = sum_r D_mur [(-1)^r
          (D_mu(r+1) ... D_mu(k-1) C)
          (D_mu0 ... D_mu(r-1) A)]
        + (-1)^k C D_mu0 ... D_mu(k-1) A.

Ordinary D is even. Canonical multiplication retains all odd signs.
Summing the last term supplies the LEFT functional Euler coefficient of
this distinguished C. It is a complete IBP normal form for the class
linear in that ghost. A zero is established only after checking the full
raw polynomial equals the divergence of the four saved currents plus
the saved normal form. No momentum specialization, equation of motion,
individual-factor zero or integrated-free-group deletion is used. Old
raw KC includes the previously retained free divergence. Its integrated
form is not substituted as an operand.

This is a comparison of actual local operator kernels. Gaussian
contraction with the same qualified regulated inverse respects a local
divergence on the common translation-invariant test domain. The existing
finite 8+8+30 loop evaluations can be transferred only after the explicit
normalization and domain bridge, not just because polynomial counts agree.
KQ and KD are individually nonzero. In particular, mean Fu0_a contains a
Ja term invisible to TFu0; its omission is an operator diagnostic with
saved residuals. Polynomial sensitivity alone is not new loop-amplitude
sensitivity.

## The hatted insertion is retained before the selected restriction

The full provisional chiral action has Ihat rather than an identically
zero master breaking. This packet authenticates and reuses CPS's actual
support theorem and its source-sensitive counterexample. It does not
recalculate its matter/Clifford coefficients or infer an unrestricted
chiral identity from the bosonic comparison.

For the specific external channels here, differentiate only with respect
to B, Lambda, C, Ja and u; no physical matter source K or fermion mean is
an external variable. Set P=S=K=0 only after those operations. The ideal
generated by P,S,K is stable under every listed derivative. Hence the
boson/fermion mixed Hessian blocks, which carry a factor in that ideal,
remain zero under these external operations. The fermion Hessian may
depend on B and scalar means but has no u, Lambda or Ja dependence. The
actual Ihat has C,P,S and hatted derivatives and no BV sources; its
surviving second-derivative block on this plane is purely fermionic and
also has no u, Lambda or Ja. Its mixed ghost/fermion blocks still carry
a fermion mean and vanish in the same stable ideal.

Thus onehalf STr(G Ihat'') is a fermion-block trace independent of u,
Lambda and Ja on this selected plane. The first-u BLambdaC and JaLambdaC
coefficients vanish before trace limits. Arbitrarily many ordinary
fermion B insertions do not supply u or Lambda. A derivative with respect
to physical K or a fermion mean would not preserve this argument; those
source classes remain open. CPS's nonzero u^2 K eta p Schur/Berezin
counterexample expressly forbids extending this support zero to them.
No global Ihat, anomalous measure, Pfaffian phase or full QAP zero follows.

The qualified universal chain is I_B1=Q Gamma1+C_Q, with B=Ihat for the
full action. The tested bosonic product identity and the scoped hatted
support supply its selected operator bridge. Numerical model Gamma
coefficients, Wick/reality conventions, a restoring primitive, common
normalization and protected E5/A5 acceptance still require their own
justification. The common H-T law and free baseline are not refitted here.
