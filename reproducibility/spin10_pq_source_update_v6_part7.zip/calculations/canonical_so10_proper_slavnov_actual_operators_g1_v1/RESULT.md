# Actual proper field/source operators satisfy the selected master bridge

The two actual-model constructions agree byte for byte on all fifty
mathematical artifacts. They use full classical source Euler operands,
not the old current or a desired quantum answer, to construct
KQ=sum F T2E/2 and KD=sum T2F/2 E. All643 ports precede mean restriction;
all45 colors, four Lorentz components, both H/M probes and g0/g1 branches
remain. Mean Fu0_a's Ja contribution and physical Euler companions stay.

The late comparison verifies KQ+KD+KC is a divergence in all24 cases:
two channels times GF/physical owners times six g/u/probe cases. Every
case retains its full raw residual, four explicit boundary currents,
zero ghost-Euler normal form and exact raw reconstruction. Raw KC includes
the free divergence. No equation of motion or early momentum restriction
is used. The largest residual has744,064 terms; it is not assigned zero
termwise. Individual proper Q and source operators are nonzero.

The complete word audit checks24,860 factor records,3,751 nonzero units
and1,371,212 raw product words, original hashes, every eligibility and
projection partition, factor linkage, unique full branch dispositions
and all sums. It reuses graded multiplication and coefficient software;
it does not independently reexecute the two Taylor constructions.

Four actual source operator controls remain nonzero after IBP:

| Case | Omission | Normal-form terms |
| --- | --- | ---: |
| M first-u g0 | Dsource |19584 |
| M first-u g0 | mean Ja in Q |600 |
| H first-u g1 | Dsource |3248 |
| H first-u g1 | mean Ja in Q |1624 |

These are local-operator sensitivities, not newly integrated amplitudes.
Blind or zero branches are retained in the full proper artifacts.

## Inherited chiral support and remaining inference

PROOF derives the selected first-u hatted insertion zero from CPS's
actual support, after B/Lambda/C/Ja/u operations. The P=S=K ideal is
stable under precisely those operations; the surviving fermion trace
has no u/Lambda/Ja. Physical K or fermion derivatives would invalidate
that restriction. CPS's sensitive Schur/Berezin counterexample is retained.
The full hatted defect remains nonzero, with measure/phase/QAP open.

The exact proper chain now has actual local model operands and a complete
integrated master/current bridge. This supplies the needed operator
comparison for the qualified regulated Gaussian, rather than inferring
it from covariance counts. Numerical Gamma/Wick calibration and the
finite-reference transfer from V799 remain explicit next work. No new
loop integration, adopted restoring primitive, common baseline, reality
or full counterterm classification is claimed here. The H-T kinetic
compatibility law and free connected baseline are unchanged.

## Execution, validation and capability limits

Proper native/replay completed219.909/195.908s under their separate300s
bounds. Two whole-IBP coordinators exhausted300s, exit124, after11 and21
cases respectively. Both sources, captures and outputs remain INCOMPLETE,
not PASS. V2 freshly reconstructed the earlier eleven cases. An isolated
worker completed the final three physical source cases in32.754s, and
the case collector authenticated all24 completed case proofs in23.772s.
The collector matches actual STAGE captures and saved proofs; it does
not reexecute their algebra. The full word audit completed64.985s.

The timeouts expose an AI resource-estimation/orchestration failure;
grouping and isolating the unfinished cases avoided repeating the heavy
completed work again. There was no nonzero surviving scientific normal
form or weakened gate. Maximum sampled private allocation across these
workers was8,316,035,072 bytes, below8GiB; samples are not a true peak.
Both authentication/controller correction and superseded unexecuted
final drafts are preserved, as documented in OPERAND_REVIEW and
FINAL_RECORD_V2. No original receipt or frozen source was edited.

Shared action/chart/ring/helpers and AI authorship limit independence.
The demonstrated capability is exact large sourceful operator construction,
complete type-based pruning audit and explicit IBP verification. It is
not independent scientists, experimental validation or a new AI platform.

The owning final receipt checks all bytes/resources/oldtree/state and
E4once-no-fresh on D:. Expected historical custodyexit2 with seven
unresolved references remains NOTPASS. Scientific acceptance is separate.
State113/34of39,E5/A5 open; flavor/HB1/C5 boundaries remain. Full scientific
goal is active. Continue actual proper normalization/domain transfer,
then the source-complete common restoration/dependency review. No push.
