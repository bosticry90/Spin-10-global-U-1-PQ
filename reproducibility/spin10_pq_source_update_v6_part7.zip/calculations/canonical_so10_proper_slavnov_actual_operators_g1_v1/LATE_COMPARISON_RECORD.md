# Late actual quadratic master/product comparison

Execute ONLY after native/replay complete and all50 proper mathematical
artifacts agree byte-for-byte. Freeze their hashes/results/captures before
reading oldcurrent targets. This is a new300s bounded dependent algebra
review, not a silent extension of either300s factory or final180s. Same
8GiBsampled/350MiBfloor/128MiBwholepacket. Sources/inputs frozenfirst.

Compare actual KQ+KD with oldKC from V788g0 fullGFcurrent and V789g1
fullGFcurrent, plus actualV787physicalg0/g1 markedkernels. Use oldraw
current, not just alreadypruned free groups. Allwholefree divergences
and physical Noether currents stay in the sum. Currentinputs are late
comparators, never construction operands forKQ/KD. Authenticate their
owning receipts and native/replay bytepair; no expensivefactoryreruns.

KQ+KD+KC is T²(sumF E)/2 by the verified evenTaylorproductrule. Test
its integrated-functional zero on BOTHchannels, allg/u/probes and both
GF/physical owners. Normalization is fixed by actual sourcefullaction
andT²/2, not fitted fromloopcancellation. No equationofmotion is used.
If a residual survives, preserve it and classify incomplete/counterexample
in the declared scope; do not change coefficients or erase a current.

An explicit IBP normal form is complete here: every selected oddghost1
word has one meanC, or (if meanC absent) one quantumC. Both are independent
jet generators. Choose that UNIQUEC as distinguished field, transfer
all its derivatives to the remaining factors with alternating signs,
and record the full four boundary currents. The normalform is C with
no jets times its LEFT functional Euler coefficient. Source/mean counts
and intrinsic grading commute with ordinary derivatives. Check the full
identity rawresidual=divcurrents+normalform, then require normalform0.
No momentum specialization or individual factor zero is permitted.
Test omission ofDsource and of the meanJa Q contribution as operator
controls where actual nonzero data exist, disclose blind cases; their
operator sensitivity is not a new loop-amplitude sensitivity claim.

This establishes the actual local proper product/master bridge in the
bosonic643-field projection, not yet a full chiralB0 assertion. Retain
Ihat insertion in the universal V801 equation. The qualifiedCPS support
will be authenticated: G/QG no physicalmatter/source and Ihat'' only
fermionic on P=S=K=0; mixed blocks0, fermionblock probe-independent.
Derive explicitly whether the selected first-u JaLambdaC/BLambdaC
Ihat1 trace thenvanishes, aftersourceoperations, before transferring
the current reference. Do not substitute a source0 block observation
for an untested differentiatedsource identity. PhysicalKmean0 is a
declared selectedprojection, not fullmeasure/globalchiralclaim.

No new Gamma amplitude is defined as minusknowncurrent. Propercoefficients
are already independently frozen; the comparison verifies the exact
operator equality before contraction with the SAME regulated inverse.
Only after this may the V799 evaluated finite/currentreference be used
as inherited evidence through the established chain, with all profiles
and normalization freedoms retained. No adoptedcounterterm or protected
promotion. FullQAP/measure/equivalence/reality/E5/A5/viability remainOPEN.
