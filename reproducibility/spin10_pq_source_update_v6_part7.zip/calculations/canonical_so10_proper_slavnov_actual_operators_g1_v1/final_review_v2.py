from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def qualified(name,seconds):
 cap=read(O/(name+'_capture.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'],name
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
 z=read(O/(name+'_result.json'));assert z['execution_state']=='COMPLETED' and z['elapsed_after_imports']<seconds
 return cap,z
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for role,h in prep['operand_sha256'].items():assert digest(O/(role+'_inputs.json.gz'))==h,role
 for pn in ['replay_preparation_checked.json','late_preparation.json','late_preparation_v2.json','remaining_preparation.json','collect_preparation.json','audit_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps={};results={}
 for name,seconds in [('native',300),('replay',300),('audit',300),('remaining',120),('collect',120)]:caps[name],results[name]=qualified(name,seconds)
 late=results['collect'];failed=[]
 for fn in ['late_capture.json','late_capture_v2.json']:
  c=read(O/fn);assert c['exit_code']==124 and not c['calculation_completed'] and c['execution_state']=='FAILED'
  assert c['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in c['all_resource_samples']);failed.append(c)
 assert late['all24_case_calculations_completed'] and late['incomplete_parent_executions_NOTPASS']==2 and not late['collector_reexecutes_algebra']
 pairs=read(O/'proper_pairs_frozen.json')['pairs'];assert len(pairs)==50
 for row in pairs:assert digest(O/row['native'])==digest(O/row['replay'])==row['sha256']
 assert results['native']['total_nonzero_raw_product_words']==results['replay']['total_nonzero_raw_product_words']==results['audit']['raw_product_words']==1371212
 assert len(results['native']['cases'])==len(results['replay']['cases'])==len(late['cases'])==24
 assert late['all_normal_forms_zero'] and all(row['normal_terms']==0 for row in late['cases'])
 assert len(late['controls'])==4 and all(row['normal_terms']>0 for row in late['controls'])
 for row in late['artifacts']+[r['artifact'] for r in late['controls']]:assert digest(O/row['file'])==row['sha256']
 cps=read(R/'calculations/canonical_so10_chiral_probe_support/validation_receipt.json')
 assert cps['both_full_generators_and_QG_matter_BV_brackets_zero'] and cps['classical_augmented_defect']=='UNCHANGED_NONZERO_IHAT'
 assert cps['source_differentiation_before_zero_superGaussian_control_nonzero'] and not cps['full_chiral_QAP_measure_phase_physical_restoration']
 assert all(results['audit'][k] for k in ['all_original_input_hashes_and_eligibility_partitions','all_factor_and_raw_product_projection_journals','all_branch_port_dispositions_unique_and_complete','all_saved_product_sums_equal_proper_kernels'])
 print('STAGE all50properpairs,completewordaudit,24masterIBPcases,4sensitivecontrols,scopedchiraldependencyverified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V802.md'];size=sum(p.stat().st_size for p in files);assert size<128*1024**2
 out=dict(schema='ACTUAL_PROPER_SLAVNOV_OPERATORS_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_PROPER_OPERATOR_AND_INTEGRATED_MASTER_BRIDGE',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,proper_native_replay_artifact_pairs=50,proper_raw_product_words=1371212,proper_cases=24,integrated_master_cases_zero=24,source_operator_controls_sensitive=4,hatted_first_u_selected_zero_by_stable_ideal_proof=True,global_chiral_or_measure_zero_claim=False,failed_or_incomplete_workers=[dict(source=src,exit_code=124,classification='RESOURCE_TIMEOUT_INCOMPLETE_NOT_SCIENTIFIC_PASS',completed_cases=count) for src,count in [('late_compare.py',11),('late_compare_v2.py',21)]],completed_case_proofs_reused_without_promoting_parent_executions=True,previous11_reconstructed_again_in_V2=True,last3_completed_in_isolated_worker=True,worker_seconds_after_imports={**{k:v['elapsed_after_imports'] for k,v in results.items()},'case_collection':late['elapsed_after_imports']},largest_private_sample=max(x['private_bytes'] for cap in list(caps.values())+failed for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,numerical_Gamma_normalization_transfer_pending=True,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
