# Same-map inverse test for the auxiliary-source leg

Use the V1123 g2 J_Lambda C C a source carrier and the
V1122 compact G ramp. Work at t3 g4 and first charged
width, with fixed lower products. This test keeps one
common field-independent finite map for the outward and
inverse contractions. For internally contracted free
Eulers use the matched-profile composite prescription,
with no independent width tag on an inherited collapsed
product. These are explicit premises of the exclusion.

The degree-three relative master coefficient from N_3 is

    B'_R N_3(V,V,V)/3! - N_3(V,V,B_1(V))/2!.

Polarize the three labels. When E_Lambda R is exterior
to the contractions, field independence identifies the
outward differentiation on J_Lambda with replacing that
same uncontracted source by E_Lambda R in the inverse
insertion. Graded odd order is unchanged because the
two placements give the same even Euler coefficient.
The diagonal Taylor factors give the same polarized
multiplicity. In the exact V1123 M control the two signed
terms are +19 div B/80 and -19 div B/80 before the
common factors. Their sum is zero. The equality is on
the same retained-source functional with the exterior
test jets kept, before imposing stationarity.

For an internal Euler use the actual V791 ordered row

    E_Lambda R = (-p^T, xi).

Against the complete matched free inverse it gives zero
on B and the common profile h on Lambda. In particular,
the width derivative of the vector part and the width
derivative of the row supply opposite p^T/p² terms.
Omitting either term or giving the two contractions
different profiles is nonblind. No free stationary
equation is substituted for this returning row.

The only g2 J_Lambda source has a broken auxiliary
source and three broken ghost ports. If the Euler
is returned, the other returning port at that vertex
is a ghost or antighost. An adjacent g1 ordinary vertex
on the odd edge must then be BCa. To have the Euler
return to Lambda and still leave the selected exterior
B C C a, the other g1 vertex must be BB Lambda,
with one B returning to the BCa and one B exterior.
The literal inventory has exactly one H and one M B
in every such vertex. The exterior B is broken in the
V1122 projection. The surviving propagating vector
edge is therefore H. Both odd profiles and the H
inverse are independent of charged width, and the
collapsed Lambda Euler is width independent as well.

The g0 plus g2 alternatives cannot restore this branch
on the selected ramp. Gauge and ghost g0 principal
remainders have only switch derivatives after subtracting
the reference. These derivatives vanish on the plateau.
A scalar g0 quadratic cannot close on the source's
remaining odd and gauge/auxiliary ports. The explicit
g0 LambdaCa term at width one has an excess exterior
slot with a width-zero g2 partner. At g1 the explicit
width CCaa also has an excess slot, and the scalar
mixing row lacks the ghost/vector closure. These exclusions
keep the matched free width quadratic in the reference.

Thus the nonzero external source triangle does not
supply the required relative G shift at first width
under these premises. Its external contribution cancels.
The internal alternative has zero charged-width slope
in the fixed collapsed prescription. This does not
exclude a new finite normalization of that internal
composite, different returning source types, or a
correlated change of lower data. It does not give a
full common Ward obstruction.
