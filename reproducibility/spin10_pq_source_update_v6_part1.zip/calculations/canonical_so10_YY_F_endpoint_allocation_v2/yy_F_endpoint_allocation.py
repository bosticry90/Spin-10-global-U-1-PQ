"""Audit the charged F endpoint under explicit finite-map premises."""
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"
r = sp.Rational


def checked_owner(name):
    path = C / f"canonical_so10_YY_{name}" / "result.json"
    return json.loads(path.read_bytes())["checks"]


def projected_H():
    k = sp.Matrix([2, 1, -3, 5])
    u = sp.Matrix([1, -2, 4, 2])
    h, eta, z = sp.symbols("h_H eta_H z")
    longitudinal = k * k.T / k.dot(k)
    transverse = sp.eye(4) - longitudinal
    mixed = h * longitudinal
    maxwell = h * transverse * (transverse + eta * longitudinal)
    returning = -k - z * u
    assert (mixed * returning - h * returning - z * h * transverse * u).expand() == sp.zeros(4, 1)
    assert (maxwell * returning + z * h * transverse * u).expand() == sp.zeros(4, 1)
    assert transverse * u != sp.zeros(4, 1)
    assert mixed * (-k) == -h * k
    assert (maxwell * (-k)).expand() == sp.zeros(4, 1)
    l, b, Q = sp.symbols("ell_L ell_H Q", positive=True)
    c2 = 2*l
    c3 = c2+b
    c4 = c3+l
    cov = sp.exp(-c3*Q)
    flat = sp.exp(-c4*Q)
    assert sp.simplify(cov - flat - sp.exp(-c2*Q)*sp.exp(-b*Q)*(1-sp.exp(-l*Q))) == 0
    assert sp.simplify(sp.log(c4/c2)-sp.log(c3/c2)-sp.log(c4/c3)) == 0
    assert sp.simplify((flat/cov).subs({l:1,b:1,Q:1})) == sp.exp(-1)
    return ["2*ell_L", "2*ell_L+ell_H", "3*ell_L+ell_H"]


def contact_control():
    # Exact signed-permutation quadrature for the traced rank-two
    # projection of the balanced O(4) tensor on this graph.
    n = sp.Matrix([r(1,2)]*4)
    diagonal = sp.zeros(4)
    for bits in range(16):
        direction = sp.diag(*[(-1)**((bits >> i)&1) for i in range(4)])*n
        P = direction*direction.T
        diagonal += (sp.eye(4)-P)*direction.dot(direction)**2/16
    assert diagonal == r(3,4)*sp.eye(4)
    assert sp.trace(diagonal) == 3
    return str(diagonal[0,0])


def allocation():
    previous = checked_owner("charged_mixed_master_companions_v1")
    H = checked_owner("F_H_euler_closure_v1")
    assert H["literal_L_and_H_euler_sources"] == [334,334]
    s = -sp.Matrix([r(entry) for entry in previous["F_master_increment_before_stored_sign"]])
    K_F = s / r(15, 8)
    L_total = sp.Matrix([[1,1,0,0]])
    H_total = sp.Matrix([[0,0,1,1]])
    maxwell_swap = sp.Matrix([[1,0,1,0]])
    H_mixed = sp.Matrix([[0,0,0,1]])
    L_mixed = sp.Matrix([[0,1,0,0]])
    minimal = L_total.col_join(H_total).col_join(maxwell_swap).col_join(L_mixed)
    fixed = L_total.col_join(H_total).col_join(maxwell_swap).col_join(H_mixed)
    assert abs(minimal.det()) == abs(fixed.det()) == 1
    tagged = minimal.inv() * sp.Matrix([0,0,0,1])
    assert list(tagged) == [-1,1,1,-1]
    assert fixed * tagged == sp.Matrix([0,0,0,-1])
    extended = fixed.col_join(L_mixed)
    witness = sp.Matrix([[1,1,-1,-1,-1]])
    assert witness * extended == sp.zeros(1,4)
    for t in s:
        assert (witness * sp.Matrix([0,0,0,0,t]))[0] == -t
    assert L_total * tagged == sp.zeros(1,1)
    P = sp.symbols("P")
    generalized_tag = -2*(P-r(1,4))*K_F
    assert generalized_tag.subs(P,-r(11,16)) == s
    assert sp.solve(generalized_tag[1],P) == [r(1,4)]
    gap = 8*r(-11,16) - 8*r(1,4)
    assert gap == -r(15,2)
    return {"tagged_signed_shift_per_j":list(map(str,s)),
            "required_H_mixed_shift_per_j":list(map(str,-s)),
            "isolated_split_allocation_multipliers":list(map(int,tagged)),
            "five_equation_left_witness":list(map(int,witness)),
            "linked_pure_oriented_gap":str(gap)}


def check(phase):
    return {"decorated_H_clock":projected_H(),
            "balanced_contact_projection":contact_control(),
            **allocation()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
