# Conditional finite allocation on the complete charged F split

In the V1093 exchanged assignment, the H inverse has
a B port at G and a Lambda port at F. In the real
stripped convention K_BLambda G_LambdaB = P_L,
where P_L projects onto the H line momentum k.
The matching Maxwell contraction is P_T at any H
width. The Action Ward rule moves the returning G
ghost derivative to the H line and the exterior
ghost or switch. With the exterior transfer retained
as u, the returning vector is -k-u. The longitudinal
and transverse terms together give that vector.
On the unjetted plateau the mixed arm gives -h_H k
and the Maxwell arm gives zero.

The collapsed H operand is the charged lower B B
and ghost word. The fixed-flat split has a further
charged profile relative to the covariant one.
The UV clocks are 2 ell_L, 2 ell_L+ell_H and
3 ell_L+ell_H for the undecorated, covariant and
fixed-flat words. Their radial differences give
the corresponding logarithm ratios. Both decorated
operands retain the removed H line profile.

For local changes write the signed arms in order
(L Maxwell, L mixed, H Maxwell, H mixed).
Preserving both complete Euler relations at fixed
decorated lower and fixed regulator gives x1+x2=0
and x3+x4=0. Preserving the V1091 Maxwell swap as
the common Action Ward relation on this projection
gives x1+x3=0. Preserving the standalone normalized
H mixed relation at fixed lower gives x4=0. These
four rows are invertible.

V1086's 2(P-1/4) factor describes a conditional
converted whole endpoint. It does not assign this
shift to a separate actual mixed arm. If read as a
net change of complete L Euler under the fixed-lower
premise, the first row already excludes it. For the
distinct mixed-only allocation test, put the signed
V1086 number s in L mixed. The two full Euler rows
and Maxwell swap give the unique allocation
(-s,s,s,-s). It requires the standalone H mixed
response to change by -s. The witness
(1,1,-1,-1,-1) annihilates the five-row system and
pairs with the proposed right side to give -s.
The first proper row is blind and the other two
are nonblind.

The V1082 conditional trace -11/16 gives signed
s=(0,-19/2672,+19/5344) per charge. If the link
is preserved, the four fixed relations allow only
P=1/4. The difference of the two oriented pure
cut combinations 8P is then -15/2 in conditional
target minus allowed units.

The standalone normalized H constraint is stronger
than the bare projector identity. To see why, on
the typed graph take balanced F and G jet slots
lambda,gamma, charged and H mixed indices rho,sigma,
and the charged ordinary B B indices mu,nu. An
O(4)-invariant full-diagonal tensor on these balanced
slots is proportional to the sphere average of

    (delta_mu,nu-n_mu n_nu) n_rho n_sigma n_lambda n_gamma.

The literal lambda=rho, gamma=sigma trace gives
3 delta_mu,nu/4. This tensor can be transported
under typed graph relabeling and extended to total
derivatives by the Action Ward rule. It changes the
projected T4 word at fixed T2. This projected
counterexample concerns balanced jets, covariance
and field independence. It does not satisfy or test
all common Euler, marked or geometric conditions.
A composite field equation would have to fix this
direction, or correlate it with other responses.
Thus the certificate is conditional. It does not
admit a new finite map or decide the complete sum.
