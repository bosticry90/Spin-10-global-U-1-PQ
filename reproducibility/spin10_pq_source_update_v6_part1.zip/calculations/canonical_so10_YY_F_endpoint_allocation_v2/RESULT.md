# Fixed lower F endpoint allocation

The bare projected H mixed collapse retains the
H heat profile. Its Maxwell complement vanishes at
zero exterior jet. The lower operand has distinct
covariant, fixed-flat and undecorated clocks.

With both normalized Euler relations, the Maxwell
swap and the standalone H mixed relation fixed,
the four signed local changes are forced to zero.
Keeping only the two Euler relations and the swap,
a hypothetical allocation of the V1086 tag to L
mixed requires (-s,s,s,-s). Its H mixed change is
(0,19/2672,-19/5344) per charge. An exact left
witness excludes that allocation if the standalone
H relation stays fixed. Reading the tag as a whole
L change is already incompatible with the fixed
complete L Euler relation.

A balanced covariant local tensor has a nonzero
projection on the H mixed word at fixed T2. The
standalone normalized equality therefore requires
an extra premise beyond the bare identity and
Action Ward rule. The complete common normalization
and proper sum remain open.
