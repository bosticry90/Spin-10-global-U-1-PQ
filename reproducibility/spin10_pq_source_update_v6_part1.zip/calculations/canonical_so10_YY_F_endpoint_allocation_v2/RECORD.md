# V1094 execution contract

Question. Can a tagged F change fit the complete
Euler equations, Maxwell swap and a fixed standalone
H mixed normalization?

Inputs. V1086 tag and phases, V1091 literal Maxwell
swap, V1092 differentiated L Euler, V1093 literal
H response and lower attachments.

Test. Retain the exterior G transfer and compare the
three clocks. Verify an exact finite allocation and
left witness. Distinguish whole and mixed-only tag
assignments. Construct a nonblind projected local
control to distinguish bare transport from an
independently preserved normalized identity.

Bounds. 120 s native and 180 s replay with E4 caps.
No amplitude expansion, finite baseline, protected
promotion or general causal normalization claim.

V2 preserves the V1 failed capture. Its zero Maxwell
control expands the symbolic width before comparison.
The operands, premises and acceptance are unchanged.
