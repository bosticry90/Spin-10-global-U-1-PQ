"""Extend the charged four-cycle census to an H auxiliary end."""
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"
r = sp.Rational


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def census():
    old = load("charged_four_cycle_inventory_v2","yy_charged_four_cycle_inventory")
    mixed = {("B","l"),("l","B")}
    old_rows = old.inventory()["ordered_field_support"]
    count_no_ghost = 0
    all_mixed = []
    for i,row in enumerate(old_rows):
        slots = [(a["ports"][1],b["ports"][0]) for a,b in zip(row,row[1:])]
        if all(e in mixed | {("B","B")} for e in slots):
            count_no_ghost += 1
        if all(e in mixed for e in slots):
            all_mixed.append(i)
    assert len(old_rows)==112 and count_no_ghost==40
    assert all_mixed==[24,31,104,111]

    all_new = {}
    counts = []
    for endpoint in (0,3):
        choices = [old.options(i) for i in range(4)]
        outer = ("l","B") if endpoint==0 else ("B","l")
        choices[endpoint] = [("master_mixed",1,True,*outer,"C")]

        def valid(row):
            ext = tuple(sorted("".join(v[5] for v in row)))
            return ext==old.EXT and sum(v[1] for v in row)==5 and sum(v[2] for v in row)==1

        by_vertex = {row for row in product(*choices)
                     if valid(row) and all((a[4],b[3]) in old.EDGES for a,b in zip(row,row[1:]))}
        by_edge = set()
        for e0,e1,e2 in product(old.EDGES,repeat=3):
            ports = (("l" if endpoint==0 else "B",e0[0]),(e0[1],e1[0]),
                     (e1[1],e2[0]),(e2[1],"l" if endpoint==3 else "B"))
            sets = [[v for v in opts if v[3:5]==pair] for opts,pair in zip(choices,ports)]
            by_edge.update(row for row in product(*sets) if valid(row))
        assert by_edge == by_vertex and len(by_edge)==19
        distribution = Counter(sum((a[4],b[3]) in mixed for a,b in zip(row,row[1:]))
                               for row in by_edge)
        counts.append([distribution[i] for i in range(4)])
        all_new["GUVF"[endpoint]] = [[list(v) for v in row] for row in sorted(by_edge)]
    return counts,all_new,all_mixed


def colors(phase):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    f,P,S,Q,h,j,modes,flat = two.inputs(phase)
    H,M = flat.ideal.H,flat.ideal.M
    L = S[3]
    J = sp.zeros(33)
    for i,z in h.items():
        for k in M:
            for b,v in f[i,k]:
                J[b-12,k-12] += z*v/j
    J = (L*J*L).applyfunc(sp.simplify)

    def rotate(operand):
        out = (J*flat.vec(operand)).applyfunc(sp.simplify)
        return {i:out[i-12] for i in M if out[i-12]}

    def center(c,a):
        return flat.images.matrix({
            (u-12,v-12):sum(z*t*Q[u,v,b,d] for b,z in c.items() for d,t in a.items())
            for u,v in product(M,repeat=2)})

    def sew(T,F,G):
        if phase=="native":
            return flat.trace(P,S,T,F,G,3,3)
        X = {h:L*F[h] for h in H}
        Y = {h:T*L*G[h] for h in H}
        return sp.Matrix([sp.expand(sum(P[i][h,k]*sum(X[h][l]*Y[k][l] for l in range(33))
                             for h,k in product(H,repeat=2) if P[i][h,k]))
                          for i in flat.ideal.spectra])

    c,d,e,v = modes
    d3 = {27:r(1,2),32:-r(1,2)}
    d4 = {28:r(1,2),31:r(1,2)}
    assert rotate(d3)==d4
    W = sp.Matrix(flat.family.representative()[0][3,3])
    W += sp.Matrix(flat.family.direction()[0][3,3])/1002
    rows = []
    for b,c1,c2,a in ((d,c,d,d),(c,c,e,v),(c,c,d3,d4)):
        values = [sp.zeros(3,1),sp.zeros(3,1)]
        for cx,ce,s in ((c1,c2,1),(c2,c1,-1)):
            T = center(cx,a)
            F,G = flat.ordinary_end(f,b),flat.ordinary_end(f,ce)
            values[0] += s*sew(T,flat.ordinary_end(f,rotate(b)),G)
            values[1] += s*sew(T,F,flat.ordinary_end(f,rotate(ce)))
        rows.append([str(sp.simplify(x.dot(W))) for x in values])
    return rows


def angular():
    p = sp.Matrix(sp.symbols("p:4"))
    a,b = sp.eye(4)[:,0],sp.eye(4)[:,1]
    Q = p.dot(p)
    eta = sp.symbols("eta_H")
    L = p*p.T/Q
    G = (sp.eye(4)+(eta-1)*L)/Q
    assert sp.cancel((p.T*G*b)[0]-eta*p.dot(b)/Q)==0
    assert sp.cancel((p.T*G*a)[0]*Q*p.dot(a)/Q**2-eta*p[0]**2/Q**2)==0
    sphere_second = sp.eye(4)/4
    assert (a.T*sphere_second*b)[0]==0
    assert (a.T*sphere_second*a)[0]==r(1,4)
    return str(eta/4)


def check(phase):
    counts,rows,original = census()
    owner = json.loads((C/"canonical_so10_YY_F_H_euler_closure_v1/result.json").read_bytes())
    assert owner["checks"]["literal_L_and_H_euler_sources"]==[334,334]
    return {"H_mixed_counts":counts,"H_mixed_ordered_support":rows,
            "H_BB_all_charged_mixed_rows":original,
            "all_mixed_ordinary_raw_weighted_per_j":colors(phase),
            "stripped_H_angular_coefficient":angular()}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
