# Charged four-cycle support with an exchanged H mixed closure

Keep the V1089 grade, three L edges and typed
ordinary and master field inventory. V1093 verifies
the second LEFT F_B assignment in both action
charts. It puts Lambda_H at the master and B_H at
its other endpoint. At the master the L return is
then B and the remaining exterior field is C.
Lambda_Lambda is zero. A gauge or ghost alternative
at that same H endpoint cannot be added to this
assignment.

At each endpoint retain only this new master option.
Enumerate the vertices first and the edges first.
Both orderings give 19 patterns per endpoint.
Counting the number of mixed charged edges gives
(6,10,3,0) at each endpoint. These 38 patterns are
disjoint from the 112 patterns with an H B B closure.
No pattern in the new class has all three charged
edges mixed. These are field support counts within
the inherited inventory. Couplings, phases, widths,
and actual amplitudes still distinguish patterns.

The earlier H B B set has 40 patterns with all
charged edges gauge or mixed. Four of them have
three mixed charged edges. X is the ordinary B B C a
quartic with both B returning. Y is the ordinary
B B Lambda with an exterior center B_h. The two
closure endpoints have charged Lambda returns.
Moving the mixed derivatives to ghost jets would
put like C ports at X, one C and one a at Y, and
a at each charged closure endpoint. This identifies
the directed numerical ghost type. It does not
identify the ordinary quartic color with the
literal J_Lambda C C a source in V1087. Nor does
field independence assign a previously excluded
like-C product the old opposite-C-a normalization.

In the common-ray hard limit the charged mixed
numerators give Q(A.p), where Q=p.p. The master
Lambda derivative contracts the H B B inverse with
p on that ray. Its remaining longitudinal component
is eta_H (p.B)/Q. The resulting rotational average
has coefficient eta_H(A.B)/4 times the log-degree
radial symbol, with common phases stripped.
At independent transfers the derivative also
produces a whole exterior or switching derivative.
The strict transverse H zero does not justify
setting the actual eta_H or transfer to zero.
The heat profiles and any split lower operands
must stay on their respective lines.

For the raw color check use the ordinary quartic
Q[u,v,c,a], before Wick, endpoint and inverse
phases. Project both charged ports to L and use
the V1087 exterior fixtures with alternating
ghost order. Rotate the exterior B for one cut
and the exterior C for the other. Both action
charts agree on the three exact weighted pairs.
Opposition of the raw colors is a diagnostic.
A statement about the complete graph sum needs
the ordered signs, finite clocks and normalized
endpoint equations.

The term whole endpoint in the V1094 tag refers to
the two charged propagator derivative arms at Y
in V1086. F is a mixed Euler in both of those
terms. Thus the literal F carrier is the L mixed
arm of V1094 if its conditional normalized
propagator transfer is retained. It is distinct
from the combined L Maxwell plus L mixed Euler
equation. This clarifies the attachment without
adopting that transfer as an admitted finite map.
