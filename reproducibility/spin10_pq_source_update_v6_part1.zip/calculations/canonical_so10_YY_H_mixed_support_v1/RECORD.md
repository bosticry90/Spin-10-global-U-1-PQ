# V1095 execution contract

Question. Which charged returning patterns have an
exchanged H auxiliary closure, and where does the
all-mixed charged like-ghost type occur?

Inputs. V1089 vertex and edge inventory, V1093
literal H assignment, V1061 spectator, V1087
like-ghost fixtures and the ordinary quartic.

Test. Compare edge-first and vertex-first counts.
Distinguish all-mixed charged paths from exchanged
H mixed closure. Verify the symbolic H width
projection and raw ordinary quartic colors in
both literal charts. Keep phases, actual
normalization and transfer completion outside
this raw projection.

Bounds. 120 s native and 180 s replay with E4 caps.
No new loop integration, baseline or promotion.
