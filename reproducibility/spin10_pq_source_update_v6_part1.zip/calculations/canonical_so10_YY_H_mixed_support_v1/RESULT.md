# Exchanged H support and all-mixed charged paths

The exchanged H B Lambda closure adds 38 labeled
patterns to the scoped V1089 census. Each endpoint
gives 19 patterns, with mixed charged edge counts
(6,10,3,0). No new pattern has three mixed charged
edges.

The original H B B closure has four all-mixed
charged patterns. Their common-ray hard factor is
eta_H(A.B)/4 with phases stripped. The ordinary
quartic colors on the three fixtures give raw
pairs (0,0), (19/6680,-19/6680) and
(-209/80160,209/80160) per charge. Those raw pairs
are not the full ordered graph comparison.
The directed like-C type is distinct from its
literal source color and from the old opposite
ghost normalization.
