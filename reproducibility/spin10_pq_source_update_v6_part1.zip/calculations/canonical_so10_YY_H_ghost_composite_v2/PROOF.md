# Actual H ghost companion of the exchanged mixed Euler

Use the V1099 H mixed assignment, with B_L
and C_F at F and B_H at G. The preimage of
the mixed closure has the F port d a_H in
place of d Lambda_H. Keep the returning
d C_L and exterior a at G. The odd global
free generator from V1003 has Q0 a=i Lambda
and Q0 B=d C. On the preimage it acts at F
with -i after crossing C_F. At G it acts
with +1 on B_H. The X and Y ordinary
operands are retained in this tagged
variation. Only these two variations
close on the chosen H pair.

In the ordered Fourier convention the
F mixed term uses (-i)(+ik) G_LambdaB.
The ghost term uses (+ik)(-ik) G_aC.
Here G_LambdaB=k^T/Q and G_aC=-1/Q.
The H tensor signs are opposite. The new
H ghost pair is adjacent and adds no Wick
crossing. The existing reversed L pair
gains two crossings, preserving its sign.
The profiles match within the H quartet.
This is a bare equality on the paired
returns. A common finite numerical map
must intertwine the normalized global Q0
on this preimage to inherit the equality.

There is a literal proper carrier for the
ghost term. The g1 source C_H a_b J_a,e
has coefficient f_(h,b,e). The LEFT
driver is minus this source derivative.
The free antighost Euler is -box C_e.
After restoring C_H,box C_e,a_b order,
the coefficient is -f_(h,b,e). The Action
Ward rule keeps the whole derivative and
the exterior or switch derivatives.
At zero exterior transfer it converts
C_H box C_e to -d C_H.d C_e. The
resulting coefficient is +f_(h,b,e),
opposite the ordinary G color f_(h,e,b).
The literal F B_L C_F a_H ordinary port
is also opposite the exchanged F_B
source color. These two differences
cancel in the sewn carrier. Both charts
verify 334 rows for each ingredient and
give the same exact weighted color.
A g1 ordinary or retained-source G
with two C returns lacks the required
balanced degree-two jet. The proper
master placement therefore has to be
included explicitly.

Under normalized global Q0 covariance
on this tagged preimage the new proper
G ghost term has the negative of the
H mixed shift. For V1099 that term is
(0,-19/2672,+19/5344) per charge after
the common stored minus. The original
four-arm sum is zero, so these five
placements alone have this nonzero sum.
The selected H relation allows a ghost
companion and does not require a zero
standalone H coefficient. GQAP1 permits
a local composite term and does not by
itself impose the zero-anomaly version
of this identity on a proposed map.

The full normalized Q0 applicability,
the other split placements of the
H-ghost product, common background
transport and all other W3 terms
remain to be tested. No complete
Slavnov obstruction follows.
