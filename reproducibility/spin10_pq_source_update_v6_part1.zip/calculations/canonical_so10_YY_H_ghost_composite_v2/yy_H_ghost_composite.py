"""Verify the free-Q0 ghost companion of the H mixed Euler."""
from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal(phase):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    f,P,S,Q,h,charge,modes,flat = two.inputs(phase)
    raw = flat.ordinary.alg.read(C/"canonical_so10_unprobed_compact_all_coupling_v1"/
                                 f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    ports = flat.ordinary.ports
    F,Ga,Hmaster = defaultdict(lambda:sp.S.Zero),{},{}
    for g,word,cells in raw:
        if g!=1 or len(word)!=3:
            continue
        (i,di),(j,dj),(k,dk) = word
        if 553<=i<565 and 610<=j<643 and 1253<=k<1286:
            assert not (di or dj or dk)
            Ga[i-553,j-598,k-1241] = ports.decode(cells,1,False)
        if 48<=i<180 and i%4==0 and 565<=j<598:
            if 598<=k<610:
                assert sorted(di+dj+dk)==[0]
                F[i//4,k-598,j-553] += (int(bool(dk))-int(bool(di)))*ports.decode(cells,1,False)
            elif 643<=k<691 and (k-643)%4==0:
                assert not (di or dj or dk)
                Hmaster[i//4,(k-643)//4,j-553] = -ports.decode(cells,1,False)
    F = {k:v for k,v in F.items() if v}
    Gexpect = {(h,b,e):z for h,b in product(range(12),range(12,45)) for e,z in f[h,b]}
    Fexpect = {(u,h,c):z for u,h in product(range(12,45),range(12)) for c,z in f[u,h]}
    assert Ga==Gexpect and F==Fexpect and len(F)==len(Ga)==334
    assert Hmaster=={k:-v for k,v in F.items()}
    assert Ga=={(h,b,e):-v for (h,e,b),v in Ga.items()}
    H,M = flat.ideal.H,flat.ideal.M
    J = sp.zeros(33)
    for i,z in h.items():
        for k in M:
            for b,v in f[i,k]:
                J[b-12,k-12] += z*v/charge
    L = S[3]
    J = (L*J*L).applyfunc(sp.simplify)
    c,d,e,v = modes
    d3 = {27:sp.Rational(1,2),32:-sp.Rational(1,2)}
    d4 = {28:sp.Rational(1,2),31:sp.Rational(1,2)}
    rows = []
    for b,c1,c2,a in ((d,c,d,d),(c,c,e,v),(c,c,d3,d4)):
        value = sp.zeros(3,1)
        for cx,cf,s in ((c1,c2,1),(c2,c1,-1)):
            T = flat.images.matrix({
                (u-12,w-12):sum(z*t*Q[u,k,l,w] for k,z in b.items() for l,t in cx.items())
                for u,w in product(M,repeat=2)})
            Fport = {h:flat.vec({u:sum(z*F.get((u,h,k),0) for k,z in cf.items())
                                 for u in M}) for h in H}
            Gport = {h:flat.vec({u:sum(z*Ga.get((h,k,u),0) for k,z in a.items())
                                 for u in M}) for h in H}
            if phase=="native":
                value += s*flat.trace(P,S,J*T,Fport,Gport,3,3)
            else:
                X = {h:L*Fport[h] for h in H}
                Y = {h:J*T*L*Gport[h] for h in H}
                value += s*sp.Matrix([sp.expand(sum(P[i][h,k]*sum(X[h][l]*Y[k][l] for l in range(33))
                                     for h,k in product(H,repeat=2) if P[i][h,k]))
                                     for i in flat.ideal.spectra])
        rows.append(value.applyfunc(sp.simplify))
    W = sp.Matrix(flat.family.representative()[0][3,3])
    W += sp.Matrix(flat.family.direction()[0][3,3])/1002
    measured = [sp.simplify(v.dot(W)) for v in rows]
    return [len(Ga),len(F)], measured, [list(map(str,row)) for row in rows]


def signs():
    I = sp.I
    k = sp.Matrix(sp.symbols("k:4"))
    Q = k.dot(k)
    H_mixed = (-I)*(I*k)*(k.T/Q)
    H_ghost = (I*k)*(-I*k.T)*(-1/Q)
    assert H_mixed == -H_ghost and H_mixed != sp.zeros(4)
    # The extra odd pair is adjacent and contributes no Wick
    # crossing. The returning L pair gains two intervening slots.
    def gap(w,a,b):
        return w.index(b)-w.index(a)-1
    old = ["s","v","f","cv","a"]
    new = ["s","v","f","ah","ch","cv","a"]
    assert gap(new,"ah","ch")==0 and gap(new,"v","cv")==gap(old,"v","cv")+2

    # At G, C_H box C_L and the balanced derivative pair have
    # opposite local symbols after the total-transfer term.
    p,q = sp.Matrix(sp.symbols("p:4")),sp.Matrix(sp.symbols("q:4"))
    lap = -q.dot(q)
    balanced = -p.dot(q)
    assert sp.expand(lap+balanced+(p+q).dot(q))==0
    assert sp.expand(lap.subs(dict(zip(q,-p)))+balanced.subs(dict(zip(q,-p))))==0
    return "-1"


def allocation(measured):
    path = C/"canonical_so10_YY_F_balanced_contact_v1/result.json"
    values = json.loads(path.read_bytes())["checks"]["projected_signed_shift_per_j"]
    arms = [sp.Matrix(list(map(sp.Rational,row))) for row in values]
    Hghost = -arms[3]
    assert Hghost == arms[1]
    assert -sp.Rational(-15,8)*sp.Matrix(measured) == Hghost
    assert sum(arms,sp.zeros(3,1)) == sp.zeros(3,1)
    assert sum(arms,sp.zeros(3,1))+Hghost != sp.zeros(3,1)
    return list(map(str,Hghost))


def check(phase):
    counts,measured,ideals = literal(phase)
    return {"J_a_and_F_BCa_literal_color_counts":counts,
            "H_ghost_ideal_rows":ideals,
            "H_ghost_to_H_mixed_ratio":signs(),
            "conditional_extra_H_ghost_proper_per_j":allocation(measured)}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
