# H ghost companion of the balanced F allocation

The free-Q0 preimage has a literal H ghost
companion with a degree-two G Euler jet.
Both charts confirm the source and ghost
endpoint signs and weighted colors.

If the common finite map preserves Q0
on this preimage, the new proper term is
(0,-19/2672,+19/5344) per charge after
the stored sign. Its sum with the four
V1099 placements is nonzero. This is a
new required contribution for that
normalization hypothesis. Other split
placements and the complete W3 comparison
remain open.
