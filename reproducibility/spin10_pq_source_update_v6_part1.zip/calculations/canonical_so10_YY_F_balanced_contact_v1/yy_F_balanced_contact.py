"""Construct projected balanced finite contacts for the four F arms."""
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"
r = sp.Rational


def checked_owner(name):
    path = C / f"canonical_so10_YY_{name}" / "result.json"
    return json.loads(path.read_bytes())["checks"]


def graph_rows():
    old = checked_owner("charged_four_cycle_inventory_v2")["ordered_field_support"]
    prefix = [("ordinary_ghost","BC","a"),("ordinary_quartic","aB","BC")]
    for row,y,f in ((66,("ordinary_YM","BB",""),("master_Maxwell","BB","C")),
                    (67,("ordinary_YM","BB",""),("master_mixed","lB","C")),
                    (70,("ordinary_mixed","lB",""),("master_mixed","lB","C"))):
        compact = [(v["type"],"".join(v["ports"]),v["exterior_L"]) for v in old[row]]
        assert compact == [*prefix,y,f]
    H = checked_owner("H_mixed_support_v1")["H_mixed_ordered_support"]["F"]
    wanted = [*prefix,("ordinary_mixed","Bl",""),("master_mixed","Bl","C")]
    assert sum([(v[0],v[3]+v[4],v[5]) for v in row]==wanted for row in H)==1
    return [66,67,70]


def contractions(phase):
    I = sp.eye(4)

    def M(y,mu):
        e = I[:,mu]
        return 2*y[mu]*I-y*e.T-e*y.T

    def K(f):
        return f.dot(f)*I-f*f.T

    BB = sp.zeros(4)
    for mu,i,l in product(range(4),repeat=3):
        f,y = I[:,i],I[:,l]
        BB[:,mu] += M(y,mu)*K(f)*y
    assert BB==-9*I

    # Each contraction has a normalized trace on two of the
    # sphere slots and needs only the second angular moment.
    if phase=="native":
        directions = [sp.Matrix([r(z,2) for z in signs]) for signs in product((-1,1),repeat=4)]
    else:
        directions = [z*I[:,k] for k,z in product(range(4),(-1,1))]
    aux,H,Maxwell = sp.zeros(4),sp.zeros(4),sp.zeros(4)
    for n in directions:
        projector = I-n*n.T
        aux += n*n.T*n.dot(n)
        H += projector*n.dot(n)**2
        for mu in range(4):
            Maxwell[:,mu] += projector*M(n,mu)*n*n.dot(n)
    D = len(directions)
    assert aux/D == I/4 and H/D == 3*I/4 and Maxwell/D == -3*I/4
    return [BB[0,0],aux[0,0]/D,Maxwell[0,0]/D,-H[0,0]/D]


def compare(factors):
    BB,aux,Maxwell,H = factors
    dp = -r(15,16)
    s = 2*dp
    coefficients = sp.Matrix([s/9,4*dp,-4*dp/3,4*s/3])
    signs = [BB*coefficients[0],
             aux*coefficients[1]+Maxwell*coefficients[2],
             -BB*coefficients[0],H*coefficients[3]]
    assert signs == [-s,s,s,-s]
    group = sp.Matrix([[1,1,0,0],[0,0,1,1],[1,0,1,0]])*sp.Matrix(signs)
    assert group == sp.zeros(3,1)
    old = checked_owner("charged_mixed_master_companions_v1")
    K = sp.Matrix(list(map(r,old["F_master_increment_before_stored_sign"])))/s
    projected = [list(map(str,-z*K)) for z in signs]
    V1094 = checked_owner("F_endpoint_allocation_v2")
    assert projected[1]==V1094["tagged_signed_shift_per_j"]
    assert projected[3]==V1094["required_H_mixed_shift_per_j"]
    return {"balanced_contact_coefficients":list(map(str,coefficients)),
            "unit_signed_allocation":list(map(str,signs)),
            "projected_signed_shift_per_j":projected,
            "two_Euler_and_swap":list(map(str,group))}


def check(phase):
    factors = contractions(phase)
    return {"old_graph_indices_BB_Lmax_Laux":graph_rows(),
            "local_contraction_factors":list(map(str,factors)),
            **compare(factors)}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
