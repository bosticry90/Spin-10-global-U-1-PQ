# Projected balanced finite allocation for the charged F group

Keep the V1093 actual four-arm group in the V1086
hard metric convention. The X quartic returns B_L
and a_L, and the ordinary ghost at G returns B_H
and C_L. The two other vertices are the charged
spectator Y and the F master. The four local
numerical tensors below have support on the full
diagonal of their respective ordered returning
graphs. They leave every T2 and T3 value fixed.

On the all-ordinary gauge path use identity
Lorentz tensors on the three gauge lines for the
additional local contact. In the balanced
returning jets at F,Y,G choose

    <f_i f_k y_l g_m> = a delta_i,k delta_l,m.

The Yang-Mills tensor is M_(jb;mu)(y)=
2 y_mu delta_j,b-y_j delta_b,mu-y_b delta_j,mu.
The F Euler is K_(bc)(f)=f^2 delta_b,c-f_b f_c.
First trace the f moment to give (d-1) delta_b,c.
Then M dot g with the y,g moment gives
(1-d) delta_j,mu. In d=4 the entire factor is
-9a. The coefficient is in the common K_F color
convention. The Y ordinary cubic has the literal
V1090 phase; the reversed a,C Wick and inverse
signs cancel. The F source color reverses when
the two B returns exchange which one carries the
Euler. The Maxwell swap therefore contributes
+9a on the exchanged H arm. Both assignments
use the same local returning tensor.

On the L mixed Euler there are two distinct
charged split types. The L auxiliary split uses
two charged mixed lines between X and F via Y.
The sphere tensor is n_j n_mu n_r n_s with
the paired endpoint trace r=s. It gives
delta_j,mu/4. The L Maxwell split has one
charged mixed line and the transverse charged
B B line. Its tensor is T_(j alpha)(n)
M_(alpha beta;mu)(n) n_beta times the paired
F,G trace n.n. On the unit sphere M(n)n=
n n_mu-e_mu, so its average is
-3 delta_j,mu/4. These are the two V1086
angular coefficients in the same phase
convention, now used as independently
specified local tensors.

On the H mixed assignment put Lambda_H at F,
B_H at G, and the ordinary mixed Y between
the two charged lines. The V1094 balanced
sphere tensor gives 3 delta_j,mu/4 before
the outgoing Euler sign. The exchanged
source and phase of V1093 give the signed
factor -3/4. This uses the same ideal
projector on the H closure as the other
arms, with the different H field pair kept.

The four numerical tensors are on balanced
returning jet types and can be extended to
total derivatives by the Action Ward rule
and to reorderings by graded permutation.
The metric factors are local tensor choices.
The off-diagonal propagators, all profiles,
and the proper subdiagonal forest remain
those of the inherited prescription. The
log-degree projection admits a constant
full-diagonal shift. The slots need no
reference-origin tag or unreturned
spectator label. They do distinguish the
actual returning species and relative jet
at each vertex. In particular the lower
source with its derivative at X is distinct
from the F-derivative assignments here.

For the conditional Delta P=-15/16 choose
the four amplitudes in order
(BB,L aux,L Maxwell,H mixed) as
(-5/24,-15/4,+5/4,-5/2).
The resulting signed unit arms are

    (15/8,-15/8,-15/8,15/8).

They annihilate the two complete projected
Euler rows and the Maxwell-swap row. On the
same three exterior pivots their weighted
signs reproduce the V1094 required s and
minus s in the mixed arms. This verifies
a projected realization rather than merely
a solvable scalar matrix. It changes the
standalone H mixed coefficient and hence
fails if that separate normalization is
imposed at fixed lower.

The proposed tensors are tested on the
selected plateau and inherited metric
projection. A common renormalized extension
must still determine their independent
source and compact-background descendants,
their marked products and the normalized
composite Q0 or master Ward equation.
The construction is not an adopted
normalization or a full W3/W5 result.
