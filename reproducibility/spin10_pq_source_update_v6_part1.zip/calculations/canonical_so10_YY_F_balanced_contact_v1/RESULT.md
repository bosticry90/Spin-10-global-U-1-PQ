# Projected balanced F contact

Four explicit local numerical tensors realize
the V1094 redistribution in the selected hard
metric projection. The signed unit arms are
(15/8,-15/8,-15/8,15/8) before the common
color and stored sign. Both complete Euler
rows and the Maxwell-swap row sum to zero
at fixed lower values. The L mixed shift
reproduces the V1086 tag and the H mixed
shift has the opposite sign on every pivot.

The standalone H mixed equation would detect
this change. The common background, composite,
source and marked requirements remain to be
tested before admitting the finite map.
