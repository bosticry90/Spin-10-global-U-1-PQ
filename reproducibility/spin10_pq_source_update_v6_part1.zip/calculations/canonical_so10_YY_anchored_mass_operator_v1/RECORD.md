# V1010 pre-execution contract

Freeze V1009, V1008, V1007,
V1006, V1004, V927 and W6.
Test one external real mass
tag r_s=m_s−M_* in the
symmetric rank-two T2
contact, with M_* anchored.
Compare its physical
tangent with the genuine
switched mass insertion
and a marginal T3 AWI
direction. Derive the
unique cubic and quartic
plateau weights, a nonblind
ordinary mass operator
witness and its lower
master transport. Test
optional scalar fusion
separately. No normalization
or operator adoption.

Native 120 s, final 180 s,
E4 120 s, 8 GiB sampled private,
350 MiB launch floor,
8 MiB artifact, 32 MiB packet.
