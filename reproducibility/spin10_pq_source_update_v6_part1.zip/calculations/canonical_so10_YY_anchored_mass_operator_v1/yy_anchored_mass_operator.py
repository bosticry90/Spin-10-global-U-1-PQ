"""Check the anchored mass tag and its compulsory physical insertion."""

import json
import sys

import sympy as sp

from execute import PK, run_worker


def allocate():
    C,M,L,d,r,t,nu,z = sp.symbols("C M L d r t nu z",real=True)
    k = 2*C-8
    proper = (k*t*t+8*t**3)*(L-t*d/M)-k*t*t*L
    kinetic = 8*M*L*t*t+z*d*t**3-2*C*nu*r*t*t
    W = proper-t*kinetic/(M+t*d)
    fixed = sp.diff(W,d).subs({d:0,r:0})
    physical = sp.diff(W.subs(r,d),d).subs(d,0)
    assert sp.simplify(physical-fixed-2*C*nu*t**3/M)==0
    P = sp.Poly(sp.simplify(M*physical),t)
    assert sp.expand(P.nth(3)-(-k+2*C*nu))==0
    assert sp.expand(P.nth(4)-(8*L-8-z))==0
    sol = sp.solve([P.nth(3),P.nth(4)],(nu,z))
    assert sp.simplify(sol[nu]-k/(2*C))==0
    assert sp.expand(sol[z]-8*(L-1))==0
    assert sp.simplify(2*C*(L-1)-8*C*(k*(L-1)/(8*C))-sol[z])==0
    assert sp.simplify(physical.subs(sol))==0

    T2 = -2*C*nu*r*t*t
    assert sp.expand(T2.diff(r).subs(sol)+k*t*t)==0
    contact = nu*r*sp.eye(4)/4
    AA,BB,AB = -contact,-contact,contact
    assert AA+AB==BB+AB==sp.zeros(4)
    assert -sp.trace(AA)==-sp.trace(BB)==sp.trace(AB)==nu*r

    e,h = sp.symbols("e h")
    master_e = -k*e*t*t*(1-t)-2*C*e*t**3
    tag = sp.diff(master_e.subs(e,e+nu*r),r)*h
    assert sp.expand(tag-nu*h*(-k*t*t*(1-t)-2*C*t**3))==0
    assert sp.simplify(tag.subs(t,1).subs(sol)+k*h)==0
    assert sp.simplify(sp.solve(sol[z]+2*C,L)[0]+k/8)==0
    assert -sp.Rational(12,8)+sp.Rational(17,8)==sp.Rational(5,8)
    return {"cubic_tag_weights":["3/5","17/25"],
            "required_kinetic_total_z":"8*(L-1)",
            "tagged_two_vertex_mass_operator":"-k*t^2*v.x",
            "tagged_master_unit_over_orbit":"-k*h",
            "scalar_fusion_reference_log_ratio":"5/8"}

def literal(phase):
    role = "primary" if phase=="native" else "replay"
    frame = json.loads((PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json").read_bytes())
    v = {i:sp.sympify(z) for i,_,z in frame["vacuum"]["VEV"]["entries"]}
    mass = json.loads((PK/"frozen_a10_cotangent_adapter"/f"{role}.json").read_bytes())
    rows,weights = [],[]
    for label,start,stop,C in (("Phi",0,54,sp.Integer(10)),("Sigma",54,306,sp.Rational(25,2))):
        k = 2*C-8
        v2 = sp.expand(sum(z*z for i,z in v.items() if start<=i<stop))
        rows.append(str(k*v2))
        weights.append(str(k/(2*C)))
        raw = mass["all_coordinate_mass_covectors"][label]
        assert raw["all_coordinates"]==stop-start
        assert raw["canonical_mass_covector_coefficient"]==-2
    assert rows==["720","51/5"] and weights==["3/5","17/25"]
    return {"ordinary_mass_operator_orbit_magnitudes":rows}


def fixed_split():
    m,M,anchor,mu2 = sp.symbols("m M M_anchor mu2",positive=True)
    r = m-anchor
    L = sp.log(mu2/M)
    assert sp.diff(r,m)==1 and sp.diff(r,M)==0
    assert sp.diff(-L,M)==1/M
    return {"anchored_tag_inert_at_fixed_physical_mass":True,
            "native_rezeroed_lambda_reference_derivative":"1/M"}


def check(phase):
    return allocate() | literal(phase) | fixed_split()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
