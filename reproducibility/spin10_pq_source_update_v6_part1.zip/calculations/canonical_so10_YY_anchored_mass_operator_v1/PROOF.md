# Explicit anchored physical-mass tag and its operator tangent

Use V1008's
fixed-reference
plateau family.
Keep the positive
reference mass M
and the anchored
normalization
labels L and
lambda=-L.
Set k=2 C_s-8.
Introduce a real
external mass
tag r=m-M_*
with a fixed
anchor M_*.
Take M_*=M
at the baseline.
The tag is not
an extra
ordinary
vertex.

Shift the V1004
mixed derivative
trace contact
c0 by nu r.
Equivalently
change the
symmetric
tensor h_2
by -nu r/4.
Both rank-two
Euler constants
move by nu r.
The ordinary
bubble and the
two derivative
weights stay
fixed. This
preserves the
AWI and matched
free quartet
relation in
the tested
numerical
class. The
dimension-two
contact coefficient
uses no inverse
physical mass
or coupling.

The tag induces
the one-port
coefficient
-2 C_s nu r
at switch
degree two.
After the
original Y
bridge its
leading contribution
is +2 C_s nu r t³/M
against G_s.
In the physical
direction r=d_s
this cancels
the V1008 cubic
exactly when

    nu = k/(2 C_s).

The literal
values are 3/5
for Phi and
17/25 for Sigma.
The independent
quartic equation
then requires
z_s=8(L_s-1).
Compared with
the V1008
moving analytic
reference
z_s=2 C_s(L_s-1),
the genuine
marginal kinetic
T3 change is
-k(L_s-1).
In the positive
triangle
normalization
it is a
cross trace
shift
-k(L_s-1)/(2 C_s).
The V1009
oriented rank-two
AWI tensor
supplies precisely
this trace
for h_3=k(L_s-1)/(8 C_s).
This part has
switch degree
three before
sewing. The
tagged T2
and genuine
T3 terms have
different
origins and
coefficients.

On this
restricted
plateau class
the two switch
conditions
therefore
have an explicit
solution.
It does not
claim the
remaining
ordinary,
retained-source,
background and
marked partners
of the new
T3 product.
In particular
the same
kernel must
also act on
the actual
scalar-potential
Hessians as
in V919.


## The actual mass tangent

Let X= sigma h D_s
be the original
physical mass
direction, with
local real mass
test h and unit
scalar Hessian.
For a constant
tag variation
first, the chain
rule on the
physical diagonal
gives

    d_m Z_(r(m))(P(m))[h]
       = D_P Z_r[X] + hbar N_r[P;h].

The displayed
local representative
of the extra
operator is

    N_r[P;h] =
        -k g² xi ∫ sigma² h v_s^t x.

It is nonzero
in the actual
blocks. A radial
ordinary scalar
source tests it:
at the matched
reference plateau
the scalar
stationary
root is
-G_M j_x.
With j_x
along v_s
the absolute
orbit factors
k ||v_s||²
are 720 and
51/5. The
radial free
inverse is
positive in
the Euclidean
test. No affine
shift of an
ordinary linear
source is used.

The original
mass vertex
has two scalar
legs and no
ghost or mixed
leg. It cannot
replace either
contracted
endpoint in
the relevant
T2 map.
The genuine
kinetic mass
replacement
starts at T3.
Thus the
new t²
mass operator
cannot be
identified with
the original
unchanged
insertion.
At first
loop it can
be represented
by the trial
renormalized
replacement
X+hbar N_r,
provided the
rest of the
operator
dictionary is
transported.
This is a
candidate
operator
comparison,
not a proof of
its full local
h-jet family.

At fixed lambda
the corresponding
tag variation
of the lower
inverse master
in g³ xi orbit
units is

    nu [ -k sigma²(1-sigma)
                         -2 C_s sigma³ ] x C.

The first term
is from the
Euler contact
in the inverse
transfer.
The second is
the kinetic
one-port in
B'[P]N.
V1007's
leading marked
root detects
the first term
after multiplying
by nu. A complete
higher-switch
marked comparison
must also carry
the second.
The cubic
profile repair
therefore needs
a changed mass
and mixed
operator
dictionary.

If the optional
V1009 scalar
fusion is fixed
as well, it
sets z_s=-2 C_s.
The plateau
quartic equation
then requires
L_s=-k_s/8.
For the two
active blocks
this requires
log(M_Sigma/M_Phi)
=5/8 in the
common reference
family. No
special reference
ratio or
normalization
is chosen.
Both fusions
would additionally
carry the
V1009 ordinary
BB companion.

Under a true
fixed-parent
split variation
the physical m
is fixed and
the anchor M_*
stays fixed.
The explicit
tag then has
no variation.
This fact
does not
transport the
base L or
lambda labels
through a
changed reference
covariance.
In particular
recomputing
lambda=-L(M)
has derivative
+1/M whereas
a fixed label
has derivative
zero. V927's
quadratic
perturbative
agreement
problem remains
separate from
the tag.
No source,
master or
normalization
is adopted.
Both routes
share the
action and
symbolic software.
