# V1010 · Anchored mass operator

A real explicit
mass tag in
the V1004
rank-two T2
contact can
supply the
cubic switch
coefficient
excluded from
the genuine
mass-inserted
T3 span.
The required
slopes are
3/5 and 17/25.
A separate
marginal T3
AWI contact
then fixes
the quartic
coefficient
at z_s=8(L_s-1).
The tested
first mass
plateau polynomial
vanishes with
those two
choices.

The physical
mass derivative
of the tagged
map necessarily
adds the
local linear
scalar operator

    -k_s g² xi sigma² h v_s^t x.

The actual
radial source
witness factors
are 720 and
51/5.
The bare
switched mass
vertex cannot
supply this
two-vertex
operator.
Its lower
master tangent
has an
individually
nonzero
unit-switch
orbit coefficient
-k_s h.

Keeping the
optional scalar
fusion would
also require
L_s=-k_s/8
on each block.
At common
reference
normalization
this fixes
their log
ratio to 5/8.
No such
ratio is
chosen.

The anchored
tag is inert
under a
true fixed-parent
split with
fixed physical
mass. The
base reference
labels still
need their
own transport.
The physical
mass operator
and its
mixed partners
would need
an extended
normalization
dictionary.
No adoption
or authority
change.

See the [proof](PROOF.md)
and [receipt](validation_receipt.json).
Seven historical
custody references
remain unresolved.
