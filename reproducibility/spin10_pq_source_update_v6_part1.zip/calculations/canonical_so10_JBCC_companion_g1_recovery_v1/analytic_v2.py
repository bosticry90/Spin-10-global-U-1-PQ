from pathlib import Path
from fractions import Fraction as Q
import importlib.util,json,os,threading,time
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JBCC_analytic_colors',O/'colors.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
J=z.J;A=z.A;read=z.read;load=z.load;digest=z.digest

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'analytic_preparation_v2.json')['sha256'].items():assert digest(R/n)==h,n
 colors=load(O/'color_tables.json.gz');gauss=load(O/'gaussian_tables.json.gz');L={c:A.decode_matrix(p) for c,p in colors['matrices']['L']};T={a:A.decode_matrix(p) for a,p in colors['matrices']['T']};choice=colors['fixture_choice'];ix=choice['internal_colors'];a=choice['JB'];cc=choice['C_first'];dd=choice['C_second']
 subL=[{(i,j):L[c].get((ix[i],ix[j]),J.ZERO) for i in range(3) for j in range(3)} for c in [cc,dd]];subT={(i,j):T[a].get((ix[i],ix[j]),J.ZERO) for i in range(3) for j in range(3)}
 kcd=A.pairtrace(A.mul(subL[0],A.transpose(subT)),subL[1]);kdc=A.pairtrace(A.mul(subL[1],A.transpose(subT)),subL[0]);assert kcd==-kdc and kcd
 fixture_rows=[]
 for fx in gauss['cases']:
  D=s.sympify(fx['D']);F=s.sympify(fx['F']);K=s.sympify(fx['K']);G=F*K.inv();DI=F*D.inv();profiles=fx['external_profiles'];saved={name:{mask:A.decode_coeff(c) for mask,c in rows} for name,rows in fx['CR_branches'].items()};preds={}
  for name,H in [('aC',s.eye(4)-F),('B',-F*(s.eye(4)-F)),('total',(s.eye(4)-F)**2)]:
   sums=[]
   for cp,dp in [(profiles[0],profiles[1]),(profiles[1],profiles[0])]:
    val=sum((s.Rational(cp[x])*s.Rational(dp[zz])*s.Rational(profiles[2][y])*G[y,x]*H[x,zz]*DI[zz,y] for x in range(4) for zz in range(4) for y in range(4)),s.Integer(0));sums.append(J.constant(Q(int(val.p),int(val.q))))
   # 2i Fu0 times i*DI Lambda-B covariance, with actual exterior exchange.
   pred=J.times(J.constant(-2),J.times(kcd,sums[0])-J.times(kdc,sums[1]));preds[name]=pred
   target=A.decode_coeff(fx['target_CR']) if name=='total' else saved[name].get(7,J.ZERO);assert pred==target,(fx['profile'],name,str(pred),str(target))
  assert not saved['Lambda'].get(7,J.ZERO) and preds['total']==preds['B']+preds['aC']
  fixture_rows.append(dict(profile=fx['profile'],actual_subblock_K=A.encode_coeff(kcd),B=A.encode_coeff(preds['B']),aC=A.encode_coeff(preds['aC']),total=A.encode_coeff(preds['total']),actual_finite_coordinate_kernel_verified=True))
 print('STAGE actual_coordinate_kernel_both_root_components_matches_both_literal_Gaussians',flush=True)
 # Independent exact UV moments: radial Frullani differences and rational
 # two-Schwinger-domain integral, without zero-momentum limit transfer.
 u=s.symbols('u',positive=True);radial=s.log(s.Rational(3,2))-s.log(s.Rational(4,3));expected=s.log(s.Rational(9,8));assert s.simplify(s.expand_log(radial-expected,force=True))==0
 weights=[1,-2,1];rational=(u-2)*sum(w/(u+a)**2 for a,w in enumerate(weights));moment=s.integrate(s.cancel(rational),(u,2,s.oo));assert s.simplify(s.expand_log(moment-expected,force=True))==0
 roots=[]
 for name,ww,ex in [('aC',[1,-1,0],s.log(s.Rational(3,2))),('B',[0,-1,1],-s.log(s.Rational(4,3)))]:
  val=s.integrate(s.cancel((u-2)*sum(w/(u+a)**2 for a,w in enumerate(ww))),(u,2,s.oo));assert s.simplify(s.expand_log(val-ex,force=True))==0;roots.append(dict(root=name,Schwinger_moment=str(val),reference=str(ex)))
 # Exact finite p!=0,r=0 expression: positive E1 integrals and endpoint form.
 checks=[]
 for prec in [70,90]:
  mp.mp.dps=prec
  for xp in [mp.mpf(1)/3,mp.mpf(2)]:
   direct=mp.mpf(0);closed=mp.mpf(0);parts=[]
   for aa,wgt in enumerate(weights):
    alpha=aa+1;x0=mp.mpf(1)/(aa+2)
    pos=mp.quad(lambda x:mp.e1(xp*(1-x)),[0,x0])+mp.quad(lambda x:mp.e1(xp*alpha*x),[x0,1])
    phi=lambda k,x:x*mp.e1(k*x)-mp.exp(-k*x)/k
    end=phi(xp,1)-phi(xp,1-x0)+phi(xp*alpha,1)-phi(xp*alpha,x0)
    assert abs(pos-end)<mp.mpf(10)**(-(prec-12));direct+=wgt*pos;closed+=wgt*end;parts.append(dict(a=aa,positive_parameter_integral=str(pos),closed_endpoint=str(end)))
   checks.append(dict(precision_digits=prec,t_p_squared=str(xp),direct=str(direct),closed=str(closed),absolute_error=str(abs(direct-closed)),parts=parts))
 # Algebraic ingredients of the written joint-source majorants.
 x=s.symbols('x',nonnegative=True);assert s.integrate(1/(1+x)**2,(x,0,s.oo))==1
 far=16*(s.integrate(x*s.exp(-x/2),(x,0,1))+s.integrate(s.exp(-x/2)/x,(x,1,s.oo)))
 far_bound=16*(s.Rational(1,2)+2*s.exp(-s.Rational(1,2)));assert far_bound.is_finite is True and far_bound.is_positive is True
 sep=s.symbols('sep',positive=True);delta=s.symbols('delta',positive=True)
 assert s.simplify((4+2+2)*4*delta**2/sep**2-32*delta**2/sep**2)==0
 assert s.simplify(4*4*(delta**2/2)/sep**2-8*delta**2/sep**2)==0
 proper=[];P={};nz=0
 for row in colors['all91225_colors']:
  a,c,d=row['JB'],row['C_first'],row['C_second'];k=A.decode_coeff(row['K']);nz+=bool(k)
  proper.append(dict(JB=a,C_first=c,C_second=d,coordinate_div_JB_full_ordered_color_log9over8=A.encode_coeff(k),rational=[],Fourier_i_times_pJB_log9over8=A.encode_coeff(k),canonical_c_lt_d_log9over8=A.encode_coeff(k*2) if c<d else [],ghost_diagonal_zero=(c==d)))
  if k:
   for mu in range(4):J.put(P,((643+4*a+mu,(mu,)),(553+c,()),(553+d,())),k)
 P=J.clean(P);assert all(sum(J.dimension(n)+len(js) for n,js in ww)==5 and sum(J.parity(n) for n,js in ww)%2==1 for ww in P)
 packet=dict(schema='ACTUAL_JBCC_FINITE_KERNEL_AND_PROPER_REFERENCE_V1',finite_full_ordered_color_functional='2i sum K_acd JB_mu(-p-r) C_c(p) C_d(r) V_mu(p,r)',V_integrand='(1-F_l)^2 F_(l+p) F_(l-r) (l-r)_mu / ((l+p)^2 (l-r)^2)',exact_ghost_exchange='V(p,r)+V(r,p)=-(p+r)_mu I_F(p,r)',I_integrand='(1-F_l)^2 F_(l+p) F_(l-r)/((l+p)^2 (l-r)^2)',F='f_delta*exp(-t*q2); f_delta=(1-exp(-q2/delta2))^2',Schwinger_E='sum_a=0,1,2 [1,-2,1]_a int_sigma,tau>=t (at+sigma+tau)^-2 exp(-(at*(sigma*p2+tau*r2)+sigma*tau*(p+r)^2)/(at+sigma+tau)) / (16pi2)',ordered_reference='log(9/8)/(16pi2)',coordinate_proper_reference='sum_acd K_acd (partial_mu JB_a,mu) C_c C_d *log(9/8)/(16pi2), overall g10*u',coefficient_convention='FULL sum over ordered c,d; no extra1/2; canonical c<d coefficient2K',all91125_proper_rows=proper,coordinate_proper_reference_log=J.encode(P),original_and_H_probe_zero_complements_by_V808_scoped_proper_identity=True,not_full_common_normalization_adoption=True,UV_power_or_log_t_subtraction='NONE_FOR_THIS_MEASURED_WHOLE_PROFILE',exceptional_p_plus_r_zero='scalar E kernel may diverge pointwise; use joint Schwartz distribution, not standalone value',joint_UV_majorant_16pi2='far_const +16*t^2*(1+|p|+|r|)^4*[130+8 log(3*(1+|p|+|r|)/(2|p+r|))]',whole_IR_difference_bound_16pi2='32 delta^2/|p+r|^2',pure_IR_UV_remainder_bound_16pi2='8 delta^2/|p+r|^2',UV_first_then_IR_joint_source_proof_written=True,no_residual_delta_contact_by_joint_L1_majorant=True,scientific_acceptance='NOT_PERFORMED')
 art=z.save('proper_reference_v2.json.gz',packet)
 out=dict(schema='ACTUAL_JBCC_HEAT_KERNEL_REFERENCE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',actual_finite_Gaussian_kernel_checks=fixture_rows,radial_reference=str(expected),independent_Schwinger_reference=str(moment),root_references=roots,numerical_positive_parameter_checks=checks,uniform_far_majorant=str(far_bound),original_symbolic_far_integral=str(far),far_finiteness_proved_by_integrable_comparison=True,full_color_positions=45**3,nonzero_ordered_K=nz,coordinate_canonical_jet_terms=len(P),only_log9over8_no_rational_contact=True,no_new_subtraction_or_normalization=True,joint_UV_then_IR_proof_not_formal_kernel_certified=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 z.dump(O/'analytic_result_v2.json',out);print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['actual_finite_Gaussian_kernel_checks','numerical_positive_parameter_checks','root_references']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
