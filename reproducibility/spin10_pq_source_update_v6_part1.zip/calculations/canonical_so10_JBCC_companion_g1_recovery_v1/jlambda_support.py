from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JL_actual_algebra',O/'colors.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
sp=importlib.util.spec_from_file_location('JL_LEFT_Taylor',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py');vr=importlib.util.module_from_spec(sp);sp.loader.exec_module(vr)
J=z.J;w=z.w;read=z.read;load=z.load;digest=z.digest
isJL=lambda n:1151<=n<1196

def filter_source(P):
 zero={};linear={};keep=[];bad=defaultdict(list)
 for at,(ww,c) in enumerate(sorted(P.items())):
  fixed=[n for n,js in ww if n>=643];ns=sum(isJL(n) for n in fixed)
  why='OTHER_FIXED_SOURCE' if any(not isJL(n) for n in fixed) else 'MULTIPLE_JL' if ns>1 else None
  if why:bad[why].append(at)
  else:(linear if ns else zero)[ww]=c;keep.append(at)
 return zero,linear,dict(kept_original_indices=keep,rejected=[dict(reason=k,original_indices=v) for k,v in sorted(bad.items())])
def eligible(P):
 out={};keep=[];bad=defaultdict(list)
 for at,(ww,c) in enumerate(sorted(P.items())):
  fields=[n for n,js in ww if n<643];nc=sum(553<=n<598 for n in fields);needed=len(fields)-nc+max(nc-2,0)
  why='LESS_THAN_TWO_FIELDS' if len(fields)<2 else 'MORE_THAN_TWO_REPLACEMENTS_REQUIRED' if needed>2 else None
  if why:bad[why].append(at)
  else:out[ww]=c;keep.append(at)
 return out,dict(kept_original_indices=keep,rejected=[dict(reason=k,original_indices=v) for k,v in sorted(bad.items())])
def project(P,exactJL=True):
 out={};keep=[];bad=defaultdict(list)
 for at,(ww,c) in enumerate(sorted(P.items())):
  nc=ns=qq=0;dim=0;why=None
  for n,js in ww:
   if 1319<=n<1962:qq+=1;dim+=J.dimension(n-1319)+len(js)
   else:
    dim+=J.dimension(n)+len(js)
    if 553<=n<598:nc+=1
    elif isJL(n):ns+=1
    else:why='FORBIDDEN_MEAN';break
  if not why and (qq!=2 or nc>2 or ns>1 or (exactJL and ns!=1)):why='WRONG_UPPER_QUANTUM_SOURCE_COUNTS'
  if not why and 5-dim not in [0,1]:why='INTRINSIC_OUTSIDE_01'
  if why:bad[why].append(at)
  else:out[ww]=c;keep.append(at)
 return out,dict(kept_raw_indices=keep,rejected=[dict(reason=k,raw_indices=v) for k,v in sorted(bad.items())])
def normal(P):
 groups={};curr=[{} for _ in range(4)];norm={}
 for ww,c in P.items():
  at=[i for i,(n,js) in enumerate(ww) if isJL(n)];assert len(at)==1;pos=at[0];n,jets=ww[pos];sg=(-1)**sum(J.parity(i) for i,js in ww[:pos]);J.put(groups.setdefault((n,jets),{}),ww[:pos]+ww[pos+1:],c*sg)
 for (n,jets),rest in groups.items():
  for r,mu in enumerate(jets):
   for ww,c in rest.items():J.put(curr[mu],((n,tuple(jets[r+1:])),)+ww,c*((-1)**r))
   rest=J.D(rest,mu)
  for ww,c in rest.items():J.put(norm,((n,()),)+ww,c*((-1)**len(jets)))
 curr=[J.clean(p) for p in curr];norm=J.clean(norm);div={}
 for mu,p in enumerate(curr):J.add(div,J.D(p,mu))
 assert J.clean(div)==w.plus(P,w.scale(norm,J.constant(-1)))
 direct={}
 for n,p in J.euler(P,range(1151,1196)).items():J.add(direct,J.mul({((n,()),):J.constant(1)},p))
 assert J.clean(direct)==norm
 return curr,norm

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'jlambda_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(base/'native_inputs.json.gz');pr=load(base/'replay_inputs.json.gz');assert pn==pr
 states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()};catalogbase=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';ordinary=[]
 for role in ['native','replay']:
  packet=load(catalogbase/(role+'_inputs.json.gz'));rows=[]
  for block in packet['ordinary']:
   ids=[i for i,(ww,c) in enumerate(block['quadratic_Taylor_half']) if any(isJL(n) for n,js in ww)]
   if ids:assert block['g']==1
   rows.append(dict(owner=block['owner'],g=block['g'],u=block['u'],all_JL_raw_indices=ids))
  ordinary.append(dict(route=role,rows=rows))
 for label in ['F0','E0','Fu0_0','Eu0_0','Fu0_1','Eu0_1']:assert all(not any(isJL(n) for n,js in ww) for p in states[label].values() for ww in p),'G0_SOURCE_JL_PRESENT'
 for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[label][n] for n in range(508))
 for label in ['F0','F1']:assert all(all(n<643 for n,js in ww) for i in range(508) for ww in states[label][i])
 filtered={};factors=[]
 def f(label,n):
  key=label,n
  if key not in filtered:
   p=states[label][n];p0,p1,journal=filter_source(p);filtered[key]=p0,p1;factors.append(dict(state=label,field=n,original=J.encode(p),source_filter=journal,source_free=J.encode(p0),one_source=J.encode(p1)))
  return filtered[key]
 cases=[('original_g1',[('F1','E0'),('F0','E1')])]+[('probe'+str(pr)+'_g1',[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))]) for pr in [0,1]]
 results=[];evidence=[]
 for label,branches in cases:
  native={};replay={};wrong={};journal=[]
  for left,right in branches:
   for n in range(643):
    P0,P1=f(left,n);Q0,Q1=f(right,n);direct=w.plus(J.mul(P1,Q0),J.mul(P0,Q1));rp={};bad={};tokens=sorted({t for P in [P1,Q1] for ww in P for t in ww if isJL(t[0])})
    for token in tokens:
     atom={((token[0],token[1]),):J.constant(1)};dP=J.leftjet(P1,token);dQ=J.leftjet(Q1,token);one=J.mul(dP,Q0);two=J.mul(P0,dQ);part=w.plus(one,w.scale(two,J.constant((-1)**(J.parity(n)+1))));J.add(rp,J.mul(atom,part));J.add(bad,J.mul(atom,w.plus(one,two)))
    rp=J.clean(rp);bad=J.clean(bad);assert direct==rp
    J.add(native,direct);J.add(replay,rp);J.add(wrong,bad);journal.append(dict(left=left,right=right,field=n,full_one_source_product=J.encode(direct),wrong_unsigned_source_rule_product=J.encode(bad)))
  native=J.clean(native);replay=J.clean(replay);wrong=J.clean(wrong);assert native==replay
  elig,ej=eligible(native);tn=w.scale(z.m.v.tangent(z.m.v.tangent(elig)),J.constant(F(1,2)));tr=w.scale(vr.tangent(vr.tangent(elig)),J.constant(F(1,2)));assert tn==tr
  selected,pj=project(tn);curr,norm=normal(selected)
  diff=w.plus(wrong,w.scale(native,J.constant(-1)));wrongelig,wij=eligible(diff);wt=w.scale(z.m.v.tangent(z.m.v.tangent(wrongelig)),J.constant(F(1,2)));wi,wj=project(wt);wc,wn=normal(wi)
  evidence.append(dict(case=label,branches=branches,all_branch_port_products=journal,full_source_master_density=J.encode(native),T2_eligibility=ej,full_T2_half_eligible=J.encode(tn),projection=pj,selected_T2_master=J.encode(selected),currents=[J.encode(p) for p in curr],normal=J.encode(norm),wrong_source_rule=dict(raw_density_difference=J.encode(diff),T2_eligibility=wij,full_T2_half=J.encode(wt),projection=wj,selected_difference=J.encode(wi),currents=[J.encode(p) for p in wc],normal_difference=J.encode(wn))))
  row=dict(case=label,full_source_density_terms=len(native),selected_T2_terms=len(selected),normal_terms=len(norm),wrong_source_rule_raw_difference_terms=len(diff),wrong_source_rule_normal_difference_terms=len(wn));results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 # Reuse only completed owning-receipt g0 witnesses, restrict away JB.
 owning=read(catalogbase/'replay_master_v2_result.json');restricted=[]
 for row in owning['cases']:
  if not row['case'].endswith('_g0'):continue
  old=load(catalogbase/row['artifact']['file']);P,_=project(J.decode(old['full_residual']),False);curr=[];div={}
  for mu,p in enumerate(old['currents']):
   c,_=project(J.decode(p),False);curr.append(J.encode(c));J.add(div,J.D(c,mu))
  assert J.clean(div)==P;restricted.append(dict(case=row['case'],source=row['artifact'],residual=J.encode(P),currents=curr,exact_reconstruction=True))
 assert len(restricted)==3
 out=dict(schema='ACTUAL_JLAMBDA_CC_PROPER_SUPPORT_V1',ordinary_source_grade_audits=ordinary,complete_filtered_F_E=factors,cases=evidence,g0_source_free_witness_restrictions=restricted,physical_support_premises_checked=True,all_sources_before_restriction=True,source_JL_positive_g1_loop_completion_rule=True,scientific_acceptance='NOT_PERFORMED')
 art=z.save('jlambda_support_tables.json.gz',out)
 result=dict(schema='ACTUAL_JLAMBDA_CC_SUPPORT_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=results,all_full_source_product_rule_and_Taylor_replays_equal=True,all_g0_witness_restrictions_reconstructed=True,all_normal_forms_zero=all(r['normal_terms']==0 for r in results),finite_formal_proper_zero_supported=all(r['normal_terms']==0 for r in results),no_global_QAP_or_anomaly_claim=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 z.dump(O/'jlambda_support_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
