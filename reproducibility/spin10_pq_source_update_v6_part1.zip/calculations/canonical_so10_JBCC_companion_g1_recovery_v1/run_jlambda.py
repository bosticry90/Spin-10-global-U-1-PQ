from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JBCC-companion-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'jlambda_preparation.json').exists()
for pn in ['preparation.json','gaussian_preparation.json','analytic_preparation.json','analytic_preparation_v2.json','consistency_preparation.json']:
 for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,n
base=R/'calculations/canonical_so10_ghost_source_companion_catalog_g1_v1';own=json.loads((base/'replay_master_v2_result.json').read_bytes());names=[base/'replay_master_v2_result.json',base/'native_JLambdaCC_catalog.json.gz',base/'replay_JLambdaCC_catalog.json.gz',R/'calculations/canonical_so10_chiral_probe_support/DERIVATION.md']+[base/r['artifact']['file'] for r in own['cases'] if r['case'].endswith('_g0')]
for p in names:
 n=p.relative_to(R).as_posix();assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['JLAMBDA_SUPPORT_RECORD.md','jlambda_support.py','run_jlambda.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'jlambda_preparation.json',dict(sha256={**{p.relative_to(R).as_posix():digest(p) for p in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'jlambda_support.py')]);dump(O/'jlambda_capture.json',cap);dump(C/'jlambda_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
