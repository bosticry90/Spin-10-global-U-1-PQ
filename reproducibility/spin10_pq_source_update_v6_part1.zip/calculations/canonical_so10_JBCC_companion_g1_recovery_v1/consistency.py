from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JBCC_consistency_colors',O/'colors.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
sp=importlib.util.spec_from_file_location('known_consistency_IBP_reuse',O.parent/'canonical_so10_known_consistency_images_g1_v1/images.py');im=importlib.util.module_from_spec(sp);sp.loader.exec_module(im)
J=z.J;w=z.w;A=z.A;read=z.read;load=z.load;digest=z.digest

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'consistency_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(base/'native_inputs.json.gz');pr=load(base/'replay_inputs.json.gz');assert pn==pr
 states={k:dict(rows) for k,rows in pn['states'].items()};phys=dict(pn['physical']['P_E0']);q0={n:J.decode(raw) for n,raw in states['F0'].items()};qGF=dict(q0);divs=[]
 for a in range(45):
  div={}
  for mu in range(4):
   n=4*a+mu;pg=J.decode(states['E0'][n]);pp=J.decode(phys[n]);q0[643+n]=w.plus(pg,pp);qGF[643+n]=pg;J.add(div,J.D(pp,mu))
  div=J.clean(div);assert not div,'PHYSICAL_KINETIC_EULER_NOT_TRANSVERSE';divs.append(dict(color=a,physical_E0_divergence=J.encode(div)))
 proper=load(O/'proper_reference_v2.json.gz');P=J.decode(proper['coordinate_proper_reference_log']);full=im.prefix(P,q0);left=im.gradient(P,q0);assert full==left
 gf=im.prefix(P,qGF);assert full==gf,'PHYSICAL_COMPANION_DID_NOT_CANCEL_BY_ACTUAL_DIVERGENCE'
 image,journal=im.target(full);cur,norm=im.normal_form(image)
 old=O.parent/'canonical_so10_known_consistency_images_g1_v1';previous=load(old/'probe1_known_sum_log9over8.json.gz');oldP=J.decode(previous['known_partial_sum']);oldN=J.decode(previous['normal']);total=w.plus(oldP,image);tc,tn=im.normal_form(total);assert tn==w.plus(oldN,norm)
 controls=[]
 for name,delta in [('omit_new_JBCC',w.scale(image,J.constant(-1))),('wrong_extra_half_JBCC',w.scale(image,J.constant(F(-1,2))))]:
  cc,nn=im.normal_form(delta);controls.append(dict(control=name,raw_difference=J.encode(delta),currents=[J.encode(p) for p in cc],normal_difference=J.encode(nn),normal_terms=len(nn)))
 # Fixed-label late comparison, not a target used to derive K.
 colors=load(O/'color_tables.json.gz');cf=load(O.parent/'canonical_so10_vector_mixed30_g1_recovery_v1/native_raw_colors.json.gz')['all_positions'];assert len(cf)==45**3
 late=[];mismatches=0
 for row,oldrow in zip(colors['all91225_colors'],cf):
  a,c,d=[row[k] for k in ['JB','C_first','C_second']];assert [a,c,d]==[oldrow[k] for k in ['B','Lambda','C']]
  residual=A.decode_coeff(row['K'])-A.decode_coeff(oldrow['Cf']);mismatches+=bool(residual);late.append([a,c,d,A.encode_coeff(residual)])
 packet=dict(schema='MEASURED_JBCC_Q0_AND_KNOWN_CONSISTENCY_UPDATE_V1',coordinate_JBCC_log_operand=J.encode(P),all45_physical_divergence_checks=divs,required_full_JB_operations=[[n,J.encode(p)] for n,p in sorted(q0.items()) if n>=643],full_odd_prefix_image=J.encode(full),full_LEFT_image=J.encode(left),physical_companion_difference=J.encode(w.plus(full,w.scale(gf,J.constant(-1)))),target_projection=journal,selected_JBCC_image=J.encode(image),JBCC_IBP_currents=[J.encode(p) for p in cur],JBCC_normal=J.encode(norm),previous_known_log_sha256=digest(old/'probe1_known_sum_log9over8.json.gz'),new_known_log_sum=J.encode(total),new_known_log_IBP_currents=[J.encode(p) for p in tc],new_known_log_normal=J.encode(tn),controls=controls,all91125_late_K_minus_Cf_residuals=late,rational_unchanged_sha256=digest(old/'probe1_known_sum_rational.json.gz'),all_new_source_operations_before_projection=True,no_missing_coefficient_zeroed_or_fitted=True,not_complete_consistency_or_obstruction=True,scientific_acceptance='NOT_PERFORMED')
 art=z.save('consistency_tables.json.gz',packet)
 out=dict(schema='JBCC_CONSISTENCY_INCORPORATION_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',JBCC_operand_terms=len(P),JBCC_full_image_terms=len(full),JBCC_target_terms=len(image),JBCC_normal_terms=len(norm),previous_known_log_normal_terms=len(oldN),new_known_log_raw_terms=len(total),new_known_log_normal_terms=len(tn),rational_normal_terms_unchanged=10112,full_prefix_LEFT_equal=True,all45_physical_divergences_zero=True,late_K_minus_Cf_nonzero=mismatches,control_normal_terms={c['control']:c['normal_terms'] for c in controls},artifact=art,missing_aCC_JLambdaCC_and_Qu0_Delta_g1_not_zeroed=True,elapsed_after_imports=time.perf_counter()-tick)
 z.dump(O/'consistency_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
