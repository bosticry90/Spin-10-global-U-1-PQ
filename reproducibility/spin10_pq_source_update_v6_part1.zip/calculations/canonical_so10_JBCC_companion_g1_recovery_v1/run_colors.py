from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JBCC-companion-g1-v1-2026-11-07')
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(p,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with p.open('xb') as h:h.write(blob)
assert not (O/'preparation.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='71427a990178be32122d2586cf7bebfe7abaf560'
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V808.md']
for folder,files in [('canonical_so10_ghost_source_companion_catalog_g1_v1',['validation_receipt.json','PROOF.md','native_inputs.json.gz','replay_inputs.json.gz','native_JBCC_catalog.json.gz','replay_JBCC_catalog.json.gz','source_grade_result.json','master_pairs_verified.json']),('canonical_so10_proper_slavnov_actual_operators_g1_v1',['factory.py','native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json']),('canonical_so10_gaussian_current_reduction_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_proper_slavnov_source_chain_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_regulator_free_inverse_g1_recovery_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_proper_normalization_transfer_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_physical_current_input_recovery_g1_v1',['physical_v2.py','physical_v4.py']),('canonical_so10_absolute_marked_quantum_g0_recovery_v1',['quantum.py']),('canonical_so10_original_Ja_ghost_bubble',['algebra.py']),('canonical_so10_full_jet_source_master_bridge',['jets.py']),('canonical_so10_intrinsic_full_source_descent',['coefficient_ring.py'])]:names+=['calculations/'+folder+'/'+n for n in files]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','colors.py','run_colors.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
for rr in ['native','replay']:
 p=load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1'/(rr+'_inputs.json.gz'));st=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(rr+'_inputs.json.gz'))['states']
 out=dict(GF0_ordinary=p['ordinary'][0]['quadratic_Taylor_half'],S1_ordinary=p['ordinary'][3]['quadratic_Taylor_half'],roots=[z for z in p['roots'] if z['state'] in ['Fu0_0','Fu0_1']],**{k:st[k] for k in ['F1','E0','Fu0_0','Fu0_1']},classical_raw_operands_only=True)
 save(O/(rr+'_operands.json.gz'),out)
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
C.mkdir(parents=True,exist_ok=False)
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'colors.py')]);dump(O/'color_capture.json',cap);dump(C/'color_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
