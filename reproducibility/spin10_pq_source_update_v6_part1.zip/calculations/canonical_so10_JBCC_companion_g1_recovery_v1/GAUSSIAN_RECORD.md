# Actual-coefficient finite Gaussian source-sign test V1

The completed color worker derives1126 nonzero K entries, antisymmetric
in the two C labels; transpose error changesall1126; omitting Pi is blind.
It verifies all643 Fu0 maps/both probes and every full R_Fu0 Preference
root, including all4 derivative/Laplacian components. No loop sign assigned.

Question: do literal normalized Gaussian moments and independent boson
Schur/ghost inverse elimination agree on the actual odd-JB,theta_c,theta_d
coefficient and CQ=-CR sign for the two returning root pieces? Use actual
3-color subblock selected by the completed table: JB0,C13,C14,internal
12/13/14. This diagnostic projection is not a physical benchmark or closed
Lie-algebra adoption; full45 color contraction remains the stage1 result.

Finite coordinate space4, D=U diag(J,2J) U^T, J=[[0,1],[-1,0]], U the
rational Householder for(1,2,3,4). K=-D2; F=U diag(2/3,2/3,2/5,2/5) U^T.
Fixed F commutes D/K, independent of means/sources; F is a diagnostic
profile, not a replacement continuum heat function. Xi remains symbolic.
Boson free action H0=[[0,-iD],[iD,xi]], regulated inverse H0/F.
G_BB=xi F K^-1,G_BL=-i F D^-1,G_LB=i F D^-1,G_LL=0.
Ghost free action a K c, regulated inverse K/F, ordered<c a>=F K^-1.
Use full free Gaussian and physical S0 separately; R=(F^-1-1)H0 fixed.

Retain independent odd theta1/theta2/JB chi. Two frozen source profiles:
A theta1=e0,theta2=e0,chi=e1; B theta1=e0,theta2=e2,chi=e3. Exact exterior
coefficient theta1 theta2 chi, no external generators identified. Actual
interactions Lambda a L(theta) and chi B T c. No physical width/coupling
value chosen; only finite diagnostic D/F/source profiles are rational.
U is carried by Fu0 root only, and g by the JB ordinary vertex, exactly as
the complete four graph catalog permits. Other root components are retained.

Primary: finite Gaussian expansion exp(-V) through external degree3,
exact because4 external factors vanish; bosonic Wick moments and ordered
ghost moments. Anchor all2/4-ghost signs by literal normalized2-pair
Berezin integration for a non-diagonal marginal covariance of this actual
free Gaussian. Preserve full weight polynomials/partition/inverse,
observables, normalized CQ/CR/Jacobian and all used moment caches.
All finite Gaussian moments are algebraic; no positive Lambda measure or
nonperturbative contour is inferred.

Independent: integrate bosons by actual symmetric covariance and conditional
mean -G J; Sghost_eff=Sghost_free-J_y G_yz J_z/2. Extract even exterior
coefficient ghost matrix and invert as A-A V A (higher external orders
vanish). Compare normalized observables and determinant/partition with
primary result. This uses only2-ghost contractions, distinct from the
primary4-ghost Wick sums. Both derive from the same actual frozen action.
CQ=<Fu0_tangent * LEFT_a Sphys>,CR=<Fu0_tangent * R_ac c>.
Check CQ+CR=Jac, actual Jac0, without adding a manual ghost trace sign/half.

Controls: independently reverse root-B or root-a relative sign; extra
half; omit partition inverse. Save exact differences and actual sensitivity/
blindness. At least one nonzero target coefficient is necessary for a sign
claim; if both are zero, report the fixture as blind/inconclusive rather
than certify sign. The coefficient value is not a continuum loop result.

One180s after-import worker,8GiB sampled private/350MiB launch pagefile
floor; same64MiB packet/10MiB per artifact. Full sources/capture retained;
no automatic retry or coefficient fit. Freeze record/source/current color
artifact before launch. No source-product/QAP/measure/reality/E5/A5 claim.
Shared action/vertices/ring/AI author limit independence; literal Berezin,
Wick and Schur identities anchor signs, not physical adequacy.
