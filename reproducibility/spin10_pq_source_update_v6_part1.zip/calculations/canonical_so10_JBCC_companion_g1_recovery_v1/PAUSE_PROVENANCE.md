# Pause and execution provenance

The human pause notice preceded the launch of analytic V1 in this chat.
Launching that worker violated the human-pause boundary. Its source,
preparation, complete monitored capture and terminal exit1 remain preserved.
Authorization at launch: NOT_AUTHORIZED_AFTER_HUMAN_PAUSE. Scientific
execution classification: FAILED_VERIFICATION_ASSERTION, NOTPASS. No new
committed checkpoint or project_state promotion resulted. The pause was
then acknowledged, the same terminal handle checked, and the goal was
reported paused. Do not describe V1 as an already-running authorized job.

Color and Gaussian workers completed before the pause. Their exact sources,
inputs and captures are authenticated separately. The user's later explicit
reactivation and continuation request authorize the new V2 analytic run
and subsequent work; they do not retroactively authorize V1. All analytic
checks were rerun under the new frozen V2 record after resumption. No
scientific acceptance is inferred from the old partial analytic execution.

This is a workflow/AI-control failure record, not a physical refutation or
new authority ledger. It does not change current policy, historical policy
hashes, scientific state or the boundaries on paused/protected research.
