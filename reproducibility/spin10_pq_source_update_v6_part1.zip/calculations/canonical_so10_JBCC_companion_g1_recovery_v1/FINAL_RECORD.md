# JBCC coefficient and source-consistency final validation V1

One180s after-import worker,8GiB sampled private/350MiB launch pagefile
floor,64MiB packet/10MiB per generated artifact. Freeze all current files,
proof/result/pause provenance and handoff BEFORE execution. No new scope
or resource allowance is inferred from a successful local commit.

Authenticate every stage preparation/source copy/input and successful full
capture; preserve analytic V1 exit1/FAILED and its unauthorized pause-boundary
classification. V2 is separate resumed execution, not a relabeling of V1.
Verify all L/T input extractions,45-color contractions/exchange/control
rows and complete Fu0 root reconstructions; fresh actual finite Gaussian
fixtures/Schur signs; finite-kernel root factors and exact UV moments,
explicit comparison majorant and written joint-source proof. Recheck
proper full-sum/canonical-ghost convention and all91125 reference rows.

Reexecute full Q0 source variation/physical divergences, target projection,
IBP/Euler normals/control differences and late fixed-label K=Cf comparison;
known rational bytes unchanged. Verify JLambda source filtering, per-port
products, graded source-jet rule, zero source densities/Taylor normals,
ordinary-source g grades and completed g0 proof restrictions. No quantum
coefficient fitted or missing aCC contribution zeroed. Actual proper/CPS/
Jacobian support inherited only at its stated target and finite prescription.

Run E4 exactly once, no --fresh, existing D evidence context. Save full
stdout/stderr before assertions; expected0,0,0,0,0,2 and seven historical
custody unresolved NOTPASS. Check project_state exact bytes/old Git tree,
resource observations and packet size. Receipt validates bounded evidence;
no scientific promotion, full QAP/viability/goal completion, or remote action.
