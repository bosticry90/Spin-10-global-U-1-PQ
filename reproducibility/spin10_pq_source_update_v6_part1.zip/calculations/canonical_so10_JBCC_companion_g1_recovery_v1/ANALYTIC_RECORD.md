# Whole JBCC heat kernel and ordered-reference derivation V1

Inputs: completed actual color/Fu0-root reconstruction and two normalized
actual-coefficient Gaussian fixtures. Freeze before calculation; no old
vector response or V807 consistency normal is a construction operand.

Derive at a finite common proof cutoff: boson conditional mean with the
actual BL inverse combines Fu0_B and Fu0_aC into2i Pi(1-F)(a L C).
The Lambda-root/explicit-JB terms have two quantum C and zero normalized
covariance at this source grade; retain and verify their zero in both
fixtures. Move symmetric(1-F) across the integrated root and cancel R G
as whole operators: Rghost Gghost=1-F. No standalone inverse heat acts
on a Schwartz source. Connected odd-JB Wick signs then give the full
ordered-color functional2i K_cd C_c(p) C_d(r) JB_mu(-p-r) V_mu(p,r),
 V_mu=int (1-F_l)^2 F_(l+p)F_(l-r)(l-r)_mu /
              [(l+p)^2(l-r)^2] d4l/(2pi)^4.
This fixed factor includes the actual Fu0 factor2 and normalized Gaussian
weights; do not multiply by the two equivalent rooted orientation labels.

First verify this coordinate-kernel formula for EACH of the actual finite
Gaussian fixtures and each root component separately. Use actual projected
K_sub, not the full color trace scaled to fit the fixture. Primary direct
Wick and independent Schur outputs stay immutable.

K_cd=-K_dc and odd C exchange symmetrize V. Reflection l->-l gives EXACT
 V(p,r)+V(r,p)=-(p+r) I_F(p,r),
 I_F=int (1-F_l)^2 F_(l+p)F_(l-r)/den.
Thus full ordered-color density is i K_cd j_mu JB_mu C_c C_d I_F,
j=-(p+r), NO extra1/2. The canonical c<d coefficient is twice the full-sum
row. Source momentum i*j translates partial on JB in the coordinate density.

For E_l=exp(-t l2), derive the two-Schwinger kernel with a=0,1,2 and weights
1,-2,1. Radial Frullani and independent rational Schwinger-domain integral
must give log(9/8); root-aC gives log(3/2), root-B gives -log(4/3).
No UV power/log(t) subtraction is introduced. Check a finite r=0 closed
E1 expression against direct positive1-parameter quadrature at two scales
and70/90-digit precisions; these diagnostics do not certify the limit.

Write actual joint-source proof, not a pointwise-zero-momentum argument.
For j!=0, loop near-region bound uses R=1+|p|+|r|,
 int_|l|<=2R 1/(|l+p|2 |l-r|2) <=
 pi2[130+8 log(3R/(2|j|))]. Far heat bound uniform in external momenta.
Multiply near part by16 t2 R4 for the whole squared profile. This provides
an integrable polynomial/log majorant against every joint Schwartz source;
rescaling establishes the a.e. constant UV limit. Exceptional j=0 has a
log singularity; do not claim an unregularized scalar pointwise value there.

For f_delta(q)=(1-exp(-q2/delta2))2 and F=fE, whole telescoping plus the
Gaussian/Riesz convolution and separation inequality give
 |16pi2(I_F-I_E)| <=32 delta2/|j|2, uniformt,p,r forj!=0.
At fixed delta, UV gives log(9/8)/(16pi2) plus the pure-IR localized kernel
 int (1-f_l)2 f_(l+p) f_(l-r)/den; its16pi2 bound is8delta2/|j|2.
Both1/|j|2 and the vector bound1/|j| are locally integrable in4 dimensions;
joint Schwartz pairing proves IR removal and excludes a residual delta
contact. Prove UV-first then IR, not exchanged unsubtracted limits.

If all analytic/model-kernel/sign/majorant checks pass, output all45^3
proper reference rows and exact coordinate log density, preserving the
full-sum/canonical-ghost convention. No rational coefficient fitted, no
normalization/counterterm adopted. Any mismatch FAILED; no automatic retry.
One120s after-import worker,8GiB sampled private/350MiB launch floor,
same64MiB packet/10MiB per artifact. No full-QAP/reality/measure/E5/A5 or
physical viability claim. Shared action/ring/source assumptions/AI author;
mathematical checks are not independent physical verification.
