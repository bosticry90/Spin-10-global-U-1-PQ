from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gc,importlib.util,json,os,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JBCC-companion-g1-v1-2026-11-07')
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
z=module('JBCC_final_colors',O/'colors.py');im=module('JBCC_final_IBP',O.parent/'canonical_so10_known_consistency_images_g1_v1/images.py');gs=module('JBCC_final_Gaussian',O/'gaussian.py');jl=module('JBCC_final_JL',O/'jlambda_support.py')
J=z.J;w=z.w;A=z.A;read=z.read;load=z.load;digest=z.digest;dump=z.dump

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','gaussian_preparation.json','analytic_preparation.json','analytic_preparation_v2.json','consistency_preparation.json','jlambda_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps={};seconds={}
 for cf,rf,bound in [('color_capture.json','color_result.json',120),('gaussian_capture.json','gaussian_result.json',180),('analytic_capture_v2.json','analytic_result_v2.json',120),('consistency_capture.json','consistency_result.json',120),('jlambda_capture.json','jlambda_support_result.json',120)]:
  cap=read(O/cf);res=read(O/rf);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<r['private_bytes']<=8*1024**3 for r in cap['all_resource_samples']);caps[cf]=cap;seconds[cf]=res['elapsed_after_imports']
 failed=read(O/'analytic_capture.json');assert failed['exit_code']==1 and not failed['calculation_completed'] and failed['post_run_observations_qualified'] and 'assert far.is_finite' in failed['stdout_and_stderr']
 assert 'NOT_AUTHORIZED_AFTER_HUMAN_PAUSE' in (O/'PAUSE_PROVENANCE.md').read_text(encoding='utf-8') and all(0<r['private_bytes']<=8*1024**3 for r in failed['all_resource_samples'])
 native=load(O/'native_operands.json.gz');replay=load(O/'replay_operands.json.gz');colors=load(O/'color_tables.json.gz');cr=read(O/'color_result.json');assert digest(O/'color_tables.json.gz')==cr['artifact']['sha256']
 L={c:A.decode_matrix(p) for c,p in colors['matrices']['L']};T={a:A.decode_matrix(p) for a,p in colors['matrices']['T']};lr={c:{} for c in range(45)};tr={a:{} for a in range(45)};tmu={}
 for at,(ww,cs) in enumerate(native['GF0_ordinary']):
  if len(ww)==3 and not any(js for n,js in ww) and 553<=ww[0][0]<598 and 1827<=ww[1][0]<1872 and 1917<=ww[2][0]<1962:lr[ww[0][0]-553][ww[1][0]-1827,ww[2][0]-1917]=-A.decode_coeff(cs)
 for ww,cs in native['S1_ordinary']:
  if not any(643<=n<823 for n,js in ww):continue
  jb,b,c=[n for n,js in ww];a,mu=divmod(jb-643,4);bb,nu=divmod(b-1319,4);assert mu==nu and not any(js for n,js in ww);tmu.setdefault((a,bb,c-1872),{})[mu]=z.strip(A.decode_coeff(cs))
 for (a,b,c),row in tmu.items():assert set(row)==set(range(4)) and len(set(row.values()))==1;tr[a][b,c]=row[0]
 assert L==lr and T==tr
 e0=dict(replay['E0'])
 for c in range(45):
  assert all(r>=12 for r,i in L[c]) and all(not L[c].get((r,r),J.ZERO) for r in range(45))
 for a in range(45):assert not A.add(T[a],A.transpose(T[a]))
 for pr in [0,1]:
  flows={n:J.decode(p) for n,p in replay['Fu0_'+str(pr)]};assert all(not p for n,p in flows.items() if not 598<=n<643)
  for r in range(45):
   om=J.Coeff([((0,0,1,0) if r<12 else (0,1,0,0),F(1))]);atom={((508+r,()),):J.constant(1)};Z=w.plus(J.decode(e0[508+r]),w.scale(atom,J.times(-om,J.constant(F(1,2)))))
   expected=w.scale(Z,J.times(J.I,J.constant(2))) if (r<12)==(pr==0) else {};assert flows[598+r]==expected
  root=colors['Fu0_root_reconstructions'][pr];raw=next(row['raw_root'] for row in native['roots'] if row['state']=='Fu0_'+str(pr) and row['family']=='preference');assert root['full_reconstructed_root']==raw and root['all_four_laplacian_components']
 PI={(r,r):J.constant(1) for r in range(12,45)};partials={(a,c):A.mul(A.mul(PI,L[c]),A.transpose(T[a])) for a in range(45) for c in range(45)}
 assert len(colors['all91225_colors'])==45**3
 for row in colors['all91225_colors']:
  a,c,d=[row[k] for k in ['JB','C_first','C_second']];v=A.pairtrace(partials[a,c],L[d]);vs=A.pairtrace(partials[a,d],L[c]);assert v==A.decode_coeff(row['K']) and vs==A.decode_coeff(row['K_swapped']) and not v+vs and A.decode_coeff(row['wrong_T_without_transpose_difference'])==-2*v
 print('STAGE full_vertices_Fu0_roots_91125_colors_and_exchange_controls_verified',flush=True)
 gaussian=load(O/'gaussian_tables.json.gz');gr=read(O/'gaussian_result.json');assert digest(O/'gaussian_tables.json.gz')==gr['artifact']['sha256']
 for fx in gaussian['cases']:
  fresh=gs.fixture(colors['fixture_choice'],L,T,fx['profile'],fx['external_profiles']);assert fresh==fx
  assert fx['target_CR'] and A.decode_coeff(fx['target_CQ'])==-A.decode_coeff(fx['target_CR']) and fx['Jacobian']==[]
 ar=read(O/'analytic_result_v2.json');ref=load(O/'proper_reference_v2.json.gz');assert digest(O/'proper_reference_v2.json.gz')==ar['artifact']['sha256']
 u=s.symbols('u',positive=True);moment=s.integrate(s.cancel((u-2)*(u**-2-2*(u+1)**-2+(u+2)**-2)),(u,2,s.oo));assert s.simplify(s.expand_log(moment-s.log(s.Rational(9,8)),force=True))==0
 bound=8+32*s.exp(-s.Rational(1,2));assert bound.is_finite is True and bound.is_positive is True and str(bound)==ar['uniform_far_majorant'] and ar['far_finiteness_proved_by_integrable_comparison']
 for row in ar['numerical_positive_parameter_checks']:assert float(row['absolute_error'])<1e-55
 P={};assert len(ref['all91125_proper_rows'])==45**3
 for row,raw in zip(ref['all91125_proper_rows'],colors['all91225_colors']):
  a,c,d=[row[k] for k in ['JB','C_first','C_second']];assert [a,c,d]==[raw[k] for k in ['JB','C_first','C_second']];k=A.decode_coeff(raw['K']);assert A.decode_coeff(row['coordinate_div_JB_full_ordered_color_log9over8'])==k and not row['rational']
  assert A.decode_coeff(row['canonical_c_lt_d_log9over8'])==(2*k if c<d else J.ZERO)
  for mu in range(4):J.put(P,((643+4*a+mu,(mu,)),(553+c,()),(553+d,())),k)
 P=J.clean(P);assert J.encode(P)==ref['coordinate_proper_reference_log'] and len(P)==2252
 print('STAGE actual_Gaussians_independent_Schur_reference_moment_and_full_sum_convention_verified',flush=True)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(base/'native_inputs.json.gz');pr=load(base/'replay_inputs.json.gz');assert pn==pr;del pr
 states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()};phys={n:J.decode(p) for n,p in pn['physical']['P_E0']};q0=dict(states['F0']);qGF=dict(q0)
 for a in range(45):
  div={}
  for mu in range(4):
   n=4*a+mu;q0[643+n]=w.plus(states['E0'][n],phys[n]);qGF[643+n]=states['E0'][n];J.add(div,J.D(phys[n],mu))
  assert not J.clean(div)
 co=load(O/'consistency_tables.json.gz');rr=read(O/'consistency_result.json');assert digest(O/'consistency_tables.json.gz')==rr['artifact']['sha256'];full=im.prefix(P,q0);assert full==im.gradient(P,q0)==im.prefix(P,qGF) and J.encode(full)==co['full_odd_prefix_image']==co['full_LEFT_image']
 selected,pj=im.target(full);cur,norm=im.normal_form(selected);assert pj==co['target_projection'] and J.encode(selected)==co['selected_JBCC_image'] and [J.encode(p) for p in cur]==co['JBCC_IBP_currents'] and J.encode(norm)==co['JBCC_normal']
 old=O.parent/'canonical_so10_known_consistency_images_g1_v1';previous=load(old/'probe1_known_sum_log9over8.json.gz');total=w.plus(J.decode(previous['known_partial_sum']),selected);tc,tn=im.normal_form(total);assert J.encode(total)==co['new_known_log_sum'] and [J.encode(p) for p in tc]==co['new_known_log_IBP_currents'] and J.encode(tn)==co['new_known_log_normal'] and len(tn)==10964
 for control in co['controls']:
  factor=-1 if control['control']=='omit_new_JBCC' else F(-1,2);delta=w.scale(selected,J.constant(factor));cc,nn=im.normal_form(delta);assert J.encode(delta)==control['raw_difference'] and [J.encode(p) for p in cc]==control['currents'] and J.encode(nn)==control['normal_difference'] and len(nn)==6756
 assert digest(old/'probe1_known_sum_rational.json.gz')==co['rational_unchanged_sha256']
 cf=load(O.parent/'canonical_so10_vector_mixed30_g1_recovery_v1/native_raw_colors.json.gz')['all_positions']
 for kr,cfr,res in zip(colors['all91225_colors'],cf,co['all91125_late_K_minus_Cf_residuals']):assert [kr[k] for k in ['JB','C_first','C_second']]==[cfr[k] for k in ['B','Lambda','C']]==res[:3] and not res[3] and A.decode_coeff(kr['K'])==A.decode_coeff(cfr['Cf'])
 print('STAGE actual_source_variation_IBP_updated_partial_sum_and_late_tensor_relation_verified',flush=True)
 js=load(O/'jlambda_support_tables.json.gz');jr=read(O/'jlambda_support_result.json');assert digest(O/'jlambda_support_tables.json.gz')==jr['artifact']['sha256'] and jr['all_normal_forms_zero']
 fc={}
 for row in js['complete_filtered_F_E']:
  raw=states[row['state']][row['field']];p0,p1,fj=jl.filter_source(raw);assert J.encode(raw)==row['original'] and fj==row['source_filter'] and J.encode(p0)==row['source_free'] and J.encode(p1)==row['one_source'];fc[row['state'],row['field']]=p0,p1
 for case in js['cases']:
  B={};wrong={};assert len(case['all_branch_port_products'])==643*len(case['branches'])
  for row in case['all_branch_port_products']:
   n=row['field'];P0,P1=fc[row['left'],n];Q0,Q1=fc[row['right'],n];direct=w.plus(J.mul(P1,Q0),J.mul(P0,Q1));reconstructed={};unsigned={}
   for token in sorted({t for p in [P1,Q1] for ww in p for t in ww if jl.isJL(t[0])}):
    atom={((token[0],token[1]),):J.constant(1)};one=J.mul(J.leftjet(P1,token),Q0);two=J.mul(P0,J.leftjet(Q1,token));J.add(reconstructed,J.mul(atom,w.plus(one,w.scale(two,J.constant((-1)**(J.parity(n)+1))))));J.add(unsigned,J.mul(atom,w.plus(one,two)))
   assert direct==J.clean(reconstructed) and J.encode(direct)==row['full_one_source_product'] and J.encode(J.clean(unsigned))==row['wrong_unsigned_source_rule_product'];J.add(B,direct);J.add(wrong,J.clean(unsigned))
  B=J.clean(B);assert J.encode(B)==case['full_source_master_density']==[];el,ej=jl.eligible(B);taylor=w.scale(z.m.v.tangent(z.m.v.tangent(el)),J.constant(F(1,2)));target,journal=jl.project(taylor);jc,jn=jl.normal(target);assert J.encode(taylor)==case['full_T2_half_eligible'] and ej==case['T2_eligibility'] and journal==case['projection'] and J.encode(target)==case['selected_T2_master'] and [J.encode(p) for p in jc]==case['currents'] and J.encode(jn)==case['normal']==[]
 for row in js['g0_source_free_witness_restrictions']:
  a=load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1'/row['source']['file']);p,_=jl.project(J.decode(a['full_residual']),False);div={};cc=[]
  for mu,raw in enumerate(a['currents']):q,_=jl.project(J.decode(raw),False);cc.append(J.encode(q));J.add(div,J.D(q,mu))
  assert J.clean(div)==p and J.encode(p)==row['residual'] and cc==row['currents']
 catalogbase=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1'
 for role in ['native','replay']:
  inputs=load(catalogbase/(role+'_inputs.json.gz'))
  for raw,row in zip(inputs['ordinary'],next(a['rows'] for a in js['ordinary_source_grade_audits'] if a['route']==role)):
   ids=[i for i,(ww,c) in enumerate(raw['quadratic_Taylor_half']) if any(jl.isJL(n) for n,js0 in ww)];assert ids==row['all_JL_raw_indices']
   if ids:assert raw['g']==1
  cat=load(catalogbase/(role+'_JLambdaCC_catalog.json.gz'));assert all(not c['complete_cycles'] for c in cat['cases'])
 for label in ['F0','E0','Fu0_0','Eu0_0','Fu0_1','Eu0_1']:assert all(not any(jl.isJL(n) for n,js0 in ww) for p in states[label].values() for ww in p)
 for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[label][n] for n in range(508))
 for label in ['F0','F1']:assert all(all(n<643 for n,js0 in ww) for i in range(508) for ww in states[label][i])
 print('STAGE JLambda_proper_zero_actual_source_grade_products_and_inherited_witnesses_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 oldtree=(C/'old_git_tree.txt').read_bytes();assert oldtree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V809.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='ACTUAL_JBCC_REFERENCE_CONSISTENCY_AND_JLAMBDA_ZERO_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_JBCC_FINITE_REFERENCE_AND_JLAMBDA_PROPER_ZERO_WITH_FAILURE_PRESERVED',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,all91125_color_rows_and1126_nonzeros_verified=True,full_Fu0_source_normalization_and_roots_verified=True,actual_finite_Gaussians_reexecuted_and_Schur_equal=True,whole_finite_kernel_and_joint_UV_IR_proof_written_not_formal_kernel_certified=True,JBCC_reference='sum_ordered_cd K_acd divJB_a Cc Cd *log(9/8)/(16pi2), overallg10u',canonical_ghost_factor2_explicit=True,known_rational_normal_terms=10112,new_known_log_normal_terms=10964,late_K_equals_Cf_all91125=True,JLambda_finite_formal_proper_zero_original_H_M_supported=True,remaining_quantum_family_for_this_carrier_census='aCC including required unprobed contribution',failed_workers=1,failed_analytic_V1='FAILED_VERIFICATION_ASSERTION_NOTPASS',analytic_V1_authorization='NOT_AUTHORIZED_AFTER_HUMAN_PAUSE',V2_and_later_authorized_after_explicit_resumption=True,all_old_failed_sources_and_manifests_unchanged=True,worker_seconds_after_imports=seconds,largest_successful_private_sample=max(r['private_bytes'] for cap in caps.values() for r in cap['all_resource_samples']),largest_failed_private_sample=max(r['private_bytes'] for r in failed['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(oldtree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_normalization_QAP_E5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
