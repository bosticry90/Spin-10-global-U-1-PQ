from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JBCC-companion-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'consistency_preparation.json').exists()
for pn in ['preparation.json','gaussian_preparation.json','analytic_preparation.json','analytic_preparation_v2.json']:
 for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,n
cap=json.loads((O/'analytic_capture_v2.json').read_bytes());assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
names=['calculations/canonical_so10_known_consistency_images_g1_v1/'+n for n in ['images.py','validation_receipt.json','PROOF.md','probe1_known_sum_log9over8.json.gz','probe1_known_sum_rational.json.gz']]+['calculations/canonical_so10_vector_mixed30_g1_recovery_v1/native_raw_colors.json.gz']
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['CONSISTENCY_RECORD.md','consistency.py','run_consistency.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'consistency_preparation.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},new_quantum_reference_frozen_before_old_normal_read=True,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'consistency.py')]);dump(O/'consistency_capture.json',cap);dump(C/'consistency_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
