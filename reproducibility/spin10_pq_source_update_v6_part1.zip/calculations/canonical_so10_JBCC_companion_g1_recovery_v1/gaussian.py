from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
from functools import lru_cache
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JBCC_gaussian_colors',O/'colors.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
J=z.J;A=z.A;read=z.read;load=z.load;digest=z.digest;one=J.constant(1);zero=J.ZERO
N=12

def const(x):
 x=s.Rational(x);return J.constant(Q(int(x.p),int(x.q)))
def clean(P):return {k:c for k,c in P.items() if c}
def add(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=out.get(k,zero)+c
 return clean(out)
def scale(P,c):return clean({k:J.times(v,c) for k,v in P.items()})
def esign(a,b):return (-1)**sum((b&((1<<i)-1)).bit_count() for i in range(3) if a&(1<<i))
@lru_cache(None)
def canon(g):
 if len(set(g))!=len(g):return (),0
 return tuple(sorted(g)),(-1)**sum(a>b for i,a in enumerate(g) for b in g[i+1:])
def mul(P,Q):
 out={}
 for (a,b,g),c in P.items():
  for (aa,bb,gg),cc in Q.items():
   if a&aa:continue
   ghosts,sg=canon(g+gg)
   if not sg:continue
   sign=sg*esign(a,aa)*((-1)**(len(g)*aa.bit_count()));key=a|aa,tuple(sorted(b+bb)),ghosts
   out[key]=out.get(key,zero)+J.times(c,cc)*sign
 return clean(out)
def bvar(i):return {(0,(i,),()):one}
def gvar(i):return {(0,(),(i,)):one}
def ext(i):return {(1<<i,(),()):one}
unit={(0,(),()):one}
def db(P,i):
 out={}
 for (mask,b,g),c in P.items():
  nn=b.count(i)
  if nn:
   ll=list(b);ll.remove(i);key=mask,tuple(ll),g;out[key]=out.get(key,zero)+c*nn
 return clean(out)
def dg(P,i):
 out={}
 for (mask,b,g),c in P.items():
  if i in g:
   at=g.index(i);key=mask,b,g[:at]+g[at+1:];out[key]=out.get(key,zero)+c*((-1)**(mask.bit_count()+at))
 return clean(out)
def enc(P):return [[a,list(b),list(g),A.encode_coeff(c)] for (a,b,g),c in sorted(P.items())]
def ee(P):return {a:c for (a,b,g),c in P.items() if not b and not g}
def ep(P):return {(a,(),()):c for a,c in P.items()}
def eenc(P):return [[a,A.encode_coeff(c)] for a,c in sorted(P.items())]
def eadd(*ps):return ee(add(*(ep(p) for p in ps)))
def escale(P,c):return ee(scale(ep(P),c))
def emul(P,Q):return ee(mul(ep(P),ep(Q)))
def einverse(P):
 assert P.get(0)==one
 nil={a:c for a,c in P.items() if a};term={0:one};out=dict(term)
 for i in range(1,4):term=emul(term,escale(nil,J.constant(-1)));out=eadd(out,term)
 assert not emul(term,nil) and emul(P,out)=={0:one}
 return out

def fixture(choice,L,T,profile_name,profs):
 ix=choice['internal_colors'];a=choice['JB'];cc=choice['C_first'];dd=choice['C_second'];lc=[{(i,j):L[c].get((ix[i],ix[j]),zero) for i in range(3) for j in range(3)} for c in [cc,dd]];ta={(i,j):T[a].get((ix[i],ix[j]),zero) for i in range(3) for j in range(3)}
 hv=s.Matrix([1,2,3,4]);U=s.eye(4)-2*hv*hv.T/(hv.dot(hv));jj=s.Matrix([[0,1],[-1,0]]);D=U*s.diag(jj,2*jj)*U.T;K=-D*D;F=U*s.diag(s.Rational(2,3),s.Rational(2,3),s.Rational(2,5),s.Rational(2,5))*U.T
 assert D.T==-D and F.T==F and F*D==D*F
 AG=F*K.inv();DI=F*D.inv();RR=K*(F.inv()-s.eye(4));xi=J.Coeff([((0,1,0,0),Q(1))]);x=s.Symbol('xi',real=True)
 H=s.BlockMatrix([[s.zeros(4),-s.I*D],[s.I*D,x*s.eye(4)]]).as_explicit();GG=s.BlockMatrix([[x*AG,-s.I*DI],[s.I*DI,s.zeros(4)]]).as_explicit();FF=s.diag(F,F);assert H*GG==FF and GG*H==FF and GG.T==GG
 bg={};cg={}
 for co in range(3):
  for u in range(4):
   for v in range(4):
    i,j=co*4+u,co*4+v;cg[i,j]=const(AG[u,v]);bg[i,j]=J.times(xi,const(AG[u,v]));bg[i,N+j]=J.times(-J.I,const(DI[u,v]));bg[N+i,j]=J.times(J.I,const(DI[u,v]))
 assert all(bg.get((i,j),zero)==bg.get((j,i),zero) for i in range(2*N) for j in range(2*N))
 @lru_cache(None)
 def bm(word):
  if not word:return one
  if len(word)%2:return zero
  i=word[0];out=zero
  for at in range(1,len(word)):
   c=bg.get((i,word[at]),zero)
   if c:out=out+J.times(c,bm(word[1:at]+word[at+1:]))
  return out
 @lru_cache(None)
 def gm(word):
  if not word:return one
  if len(word)%2:return zero
  i=word[0];out=zero
  for at in range(1,len(word)):
   j=word[at]
   cov=cg.get((i,j-N),zero) if i<N<=j else -cg.get((j,i-N),zero) if j<N<=i else zero
   if cov:out=out+J.times(cov,gm(word[1:at]+word[at+1:]))*((-1)**(at+1))
  return out
 def free_expect(P):
  out={}
  for (mask,b,g),c in P.items():
   mom=J.times(bm(b),gm(g))
   if mom:out[mask]=out.get(mask,zero)+J.times(c,mom)
  return clean(out)
 def product_expect(P,Q):
  out={}
  for (mask,b,g),c in P.items():
   for (mm,bb,gg),cc in Q.items():
    if mask&mm:continue
    ghosts,sign=canon(g+gg)
    if not sign:continue
    mom=J.times(bm(tuple(sorted(b+bb))),gm(ghosts))
    if not mom:continue
    sign*=esign(mask,mm)*((-1)**(len(g)*mm.bit_count()));at=mask|mm
    out[at]=out.get(at,zero)+J.times(J.times(c,cc),mom)*sign
  return clean(out)
 # Literal two-pair Berezin marginal anchors all ordered 2/4-ghost signs.
 sub=s.Matrix([[AG[i,j] for j in [0,1]] for i in [0,1]]);ki=sub.inv();Ssub={}
 for i in range(2):
  for j in range(2):Ssub=add(Ssub,scale(mul(gvar(N+i),gvar(j)),const(ki[i,j])))
 wsub=dict(unit);term=dict(unit)
 for n in range(1,3):term=scale(mul(term,scale(Ssub,J.constant(-1))),J.constant(Q(1,n)));wsub=add(wsub,term)
 top=(0,1,N,N+1);zsub=wsub.get((0,(),top),zero);assert len(zsub.terms)==1 and zsub.terms[0][0]==(0,0,0,0);iz=J.constant(1/zsub.terms[0][1]);anchor=[]
 for mask in range(16):
  gs=tuple(top[i] for i in range(4) if mask&(1<<i));P={(0,(),gs):one};num=mul(P,wsub).get((0,(),top),zero);val=J.times(num,iz);assert val==gm(gs)
  anchor.append([list(gs),A.encode_coeff(val)])
 # Actual action vertices and every root component.
 VL={};VJ={};Sghost={};FaB=[{} for i in range(N)];FaL=[{} for i in range(N)];FaA=[{} for i in range(N)]
 for co in range(3):
  for u in range(4):
   at=co*4+u;FaL[at]=scale(bvar(N+at),J.times(J.I,xi))
   for v in range(4):
    FaB[at]=add(FaB[at],scale(bvar(co*4+v),const(-2*D[u,v])))
    Sghost=add(Sghost,scale(mul(gvar(N+at),gvar(co*4+v)),const(K[u,v])))
   for other in range(3):
    for e in [0,1]:
     val=J.times(lc[e][co,other],J.constant(profs[e][u]))
     if val:
      aa=mul(gvar(N+other*4+u),ext(e));VL=add(VL,scale(mul(bvar(N+at),aa),val));FaA[at]=add(FaA[at],scale(aa,J.times(J.constant(2),J.times(J.I,val))))
    val=J.times(ta[co,other],J.constant(profs[2][u]))
    if val:VJ=add(VJ,scale(mul(mul(ext(2),bvar(at)),gvar(other*4+u)),val))
 Fa=[add(FaB[i],FaL[i],FaA[i]) for i in range(N)];Sphys=add(Sghost,VL,VJ);V=add(VL,VJ);weight=dict(unit);term=dict(unit)
 for n in range(1,4):term=scale(mul(term,scale(V,J.constant(-1))),J.constant(Q(1,n)));weight=add(weight,term)
 assert not mul(term,V),'NON_NILPOTENT_EXTERNAL_ACTION'
 CRparts={name:{} for name in ['B','Lambda','aC']};CQ={};Jac={}
 for i in range(N):
  co,u=divmod(i,4);reg={}
  for v in range(4):reg=add(reg,scale(gvar(co*4+v),const(RR[u,v])))
  for name,part in [('B',FaB[i]),('Lambda',FaL[i]),('aC',FaA[i])]:CRparts[name]=add(CRparts[name],mul(part,reg))
  CQ=add(CQ,mul(Fa[i],dg(Sphys,N+i)));Jac=add(Jac,dg(Fa[i],N+i))
 CR=add(*CRparts.values());Z=free_expect(weight);assert Z.get(0)==one;Zi=einverse(Z);norm=lambda P:emul(product_expect(P,weight),Zi)
 qr=norm(CQ);rr=norm(CR);jj=norm(Jac);parts={name:norm(p) for name,p in CRparts.items()};assert eadd(qr,rr)==jj and not jj
 print('STAGE '+profile_name+' normalized_Wick_and_literal_Berezin_anchor',flush=True)
 # Boson elimination, followed by an even-exterior ghost matrix inverse.
 Jy=[db(V,i) for i in range(2*N)];means=[];Veff={}
 for i in range(2*N):
  mean={}
  for j in range(2*N):
   val=bg.get((i,j),zero)
   if val:
    mean=add(mean,scale(Jy[j],-val));Veff=add(Veff,scale(mul(Jy[i],Jy[j]),J.times(val,J.constant(Q(-1,2)))))
  means.append(mean)
 Ve={}
 for (mask,b,g),c in Veff.items():
  assert not b and len(g)==2 and g[0]<N<=g[1] and mask.bit_count()==2
  key=g[1]-N,g[0];Ve.setdefault(key,{})[mask]=-c
 gs={(i,j):({0:cg[i,j]} if cg.get((i,j)) else {}) for i in range(N) for j in range(N)}
 for (i,j),entry in Ve.items():
  for r in range(N):
   if not cg.get((r,i)):continue
   for col in range(N):
    if cg.get((j,col)):gs[r,col]=eadd(gs[r,col],escale(entry,-J.times(cg[r,i],cg[j,col])))
 schurZ={0:one}
 for (i,j),entry in Ve.items():
  if cg.get((j,i)):schurZ=eadd(schurZ,escale(entry,cg[j,i]))
 assert schurZ==Z,'NORMALIZED_PARTITION_SCHUR_VS_WICK'
 def conditional(P):
  out={}
  for (mask,b,g),c in P.items():
   rest={(mask,(),g):c}
   if not b:out=add(out,rest)
   elif len(b)==1:out=add(out,mul(rest,means[b[0]]))
   else:
    assert len(b)==2
    out=add(out,scale(rest,bg.get((b[0],b[1]),zero)),mul(rest,mul(means[b[0]],means[b[1]])))
  return out
 def schur_expect(P):
  CP=conditional(P);out={}
  for (mask,b,g),c in CP.items():
   assert not b
   if not g:out=eadd(out,{mask:c})
   else:
    assert len(g)==2
    if g[0]<N<=g[1]:out=eadd(out,emul({mask:c},gs[g[0],g[1]-N]))
  return out,CP
 qsch,qcond=schur_expect(CQ);rsch,rcond=schur_expect(CR);assert qsch==qr and rsch==rr
 assert eadd(*parts.values())==rr
 controls=dict(flip_B_root_difference=eenc(escale(parts['B'],J.constant(-2))),flip_aC_root_difference=eenc(escale(parts['aC'],J.constant(-2))),extra_half_difference=eenc(escale(rr,J.constant(Q(-1,2)))),omit_partition_inverse_difference=eenc(eadd(product_expect(CR,weight),escale(rr,J.constant(-1)))))
 print('STAGE '+profile_name+' independent_boson_Schur_even_ghost_inverse',flush=True)
 return dict(profile=profile_name,actual_colors=choice,external_profiles=profs,D=str(D),F=str(F),K=str(K),Rghost=str(RR),free_boson_covariance=[[i,j,A.encode_coeff(c)] for (i,j),c in sorted(bg.items()) if c],free_ordered_Ca_covariance=[[i,j,A.encode_coeff(c)] for (i,j),c in sorted(cg.items()) if c],literal_two_pair_anchor=dict(marginal_covariance=str(sub),inverse=str(ki),action=enc(Ssub),weight=enc(wsub),partition=A.encode_coeff(zsub),all16_moments=anchor),VL=enc(VL),VJ=enc(VJ),Sghost=enc(Sghost),Fa_components=dict(B=[enc(p) for p in FaB],Lambda=[enc(p) for p in FaL],aC=[enc(p) for p in FaA]),full_external_weight=enc(weight),partition=eenc(Z),partition_inverse=eenc(Zi),CQ_observable=enc(CQ),CR_observable=enc(CR),Jacobian_observable=enc(Jac),CQ=eenc(qr),CR=eenc(rr),Jacobian=eenc(jj),CR_branches={k:eenc(v) for k,v in parts.items()},Schur_effective_ghost_action=enc(Veff),Schur_even_ghost_matrix=[[i,j,eenc(p)] for (i,j),p in sorted(Ve.items())],Schur_Ca_inverse=[[i,j,eenc(p)] for (i,j),p in sorted(gs.items()) if p],Schur_partition=eenc(schurZ),Schur_CQ=eenc(qsch),Schur_CR=eenc(rsch),conditional_CQ=enc(qcond),conditional_CR=enc(rcond),controls=controls,target_CR=A.encode_coeff(rr.get(7,zero)),target_CQ=A.encode_coeff(qr.get(7,zero)),not_continuum_amplitude=True)

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'gaussian_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 table=load(O/'color_tables.json.gz');L={c:A.decode_matrix(p) for c,p in table['matrices']['L']};T={a:A.decode_matrix(p) for a,p in table['matrices']['T']};choice=table['fixture_choice']
 profiles=[('A',[[1,0,0,0],[1,0,0,0],[0,1,0,0]]),('B',[[1,0,0,0],[0,0,1,0],[0,0,0,1]])]
 cases=[fixture(choice,L,T,name,p) for name,p in profiles];nonzero=sum(bool(c['target_CR']) for c in cases)
 art=z.save('gaussian_tables.json.gz',dict(schema='ACTUAL_JBCC_NORMALIZED_GAUSSIAN_SIGN_V1',cases=cases,full_actual_45_color_tensor_not_replaced_by_fixture=True))
 out=dict(schema='ACTUAL_JBCC_GAUSSIAN_SIGN_RESULT_V1',execution_state='COMPLETED' if nonzero else 'INCONCLUSIVE',scientific_acceptance='NOT_PERFORMED',nonzero_target_fixtures=nonzero,all_primary_Wick_literal_Berezin_anchor_and_independent_Schur_equal=True,CQ_equals_negative_CR_and_actual_Jacobian_zero=True,actual_odd_JB_and_independent_mean_ghosts=True,no_manual_ghost_half_or_trace_sign=True,artifact=art,targets=[dict(profile=c['profile'],CQ=c['target_CQ'],CR=c['target_CR']) for c in cases],elapsed_after_imports=time.perf_counter()-tick)
 z.dump(O/'gaussian_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
 assert nonzero,'ALL_FIXTURES_BLIND_NO_SIGN_CLAIM'
if __name__=='__main__':main()
