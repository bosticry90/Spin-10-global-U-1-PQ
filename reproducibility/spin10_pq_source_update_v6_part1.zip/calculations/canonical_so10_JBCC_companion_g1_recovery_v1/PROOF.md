# Measured JBCC companion, joint-source limit and remaining consistency input

## Claim, scope and actual inputs

The four V808 M-probe JBCC candidates now have an actual finite kernel and
ordered local reference in the original Euclidean A0,firstg/firstu,
intrinsic01 prescription. Overall hbar*g10*u is suppressed where stated.
No physical width/coupling value, normalization or counterterm is selected.
All45 colors, all4 Lorentz components and full source operations precede
restrictions. V808's actual target-master/source-grade/physical/CPS proof,
V801's LEFT proper chain, V790's full diagonal Jacobian0 and V803/V791's
actual determinant/inverse conventions give QGamma=-CQ=CR in this target.
This does not prove a continuum QAP, real physical measure, common composite
products, full restoration, E5/A5 or physical viability.

Full ordinary Taylor halves define L_c[r,i] as the Lambda_r a_i C_c
coefficient and T_a[b,i] as the JB_a,mu B_b,mu C_i coefficient. Replay
uses actual E0_Lambda and F1_B; all four Lorentz T components agree.
All full Fu0 field maps/both probes are independently rebuilt as

    Fu0_a,r = 2i Pi_r Z_r,
    Z_r = i divB_r + Omega_r Lambda_r/2 - i Ja_r
          + sum_(i,c) a_i L_c[r,i] C_c.

Every full Preference R_Fu0 root is reconstructed with actual Fourier
phases and all four ghost Laplacian components; reference-defect roots are
zero. Nonreturning Lambda/Ja/other components are retained until the complete
catalog excludes them. The root projection Pi is the unit probe projector,
not another gauge width. Couplingg1 is extracted polynomially from T.

Native sparse contraction and independent matrix trace give

    K_acd = sum_(r,i,b) Pi_r L_c[r,i] T_a[b,i] L_d[b,r]
          = Tr(Pi L_c T_a^T L_d).

All91125 positions are saved,1126 nonzero, with K_acd=-K_adc. Wrong T
transpose changesall1126; omitting Pi is blind in the actual support.
The V1 table key 'all91225_colors' is a spelling error; its actual length
and loop bounds are91125=45^3. Original bytes remain unchanged.
A late comparison, performed only after the new reference was frozen,
finds K=Cf at every matching V797 vector color position, with no fitted
multiplier, inverse width or use of that table to construct K.

## Actual-coefficient sign and normalization

The two finite tests retain independent odd theta1,theta2 and JB source chi,
using actual color subblock(JB0,C13,C14,internal12/13/14). They are diagnostic
projections, not a closed Lie algebra, a physical benchmark or an adopted
regulator. Xi remains symbolic. Four coordinate modes with a rational skew
D and source-independent F(D^2) retain noncommuting source profiles. Full
normalized Gaussian moments, partition/inverse and both root types are saved.

Primary ordered Wick sums are anchored by literal normalized two-pair
Berezin integration, including the four-ghost signs. Independent elimination
integrates the bosons and inverts the even-exterior ghost matrix. Both
nonzero fixtures agree, including CQ=-CR, actual Jac0 and root-by-root
relative signs. The bare coefficient of theta1 theta2 chi is

    A: CR= -38216 sqrt(10) xi^2 /20503125,
    B: CR= -87584 sqrt(10) xi^2 /474609375,

with CQ the opposite. No manual ghost trace sign or extra half is added.
These values are finite-coordinate diagnostics, not continuum amplitudes.
The complete coordinate kernel below matches BOTH fixtures separately for
the B root, antighost root and their sum. Dropping partition normalization
is blind for these actual traceless subblocks; the normalized partition is
still explicitly retained. Each relative-root sign and extra-half control
has its saved exact difference; none is inferred from names of currents.

## Whole finite-profile kernel

Derive first at a common finite proof cutoff with fixed R. The actual
BL inverse gives the conditional B contribution to Fu0 as -2i F(a L C).
Together with the antighost part it is2i(1-F)(a L C). Explicit-JB and
Lambda-root terms have two quantum C and zero covariance at this source
grade, as checked in both finite models. Since F is symmetric and the root
is integrated, move(1-F) onto the regulator leg, and cancel the WHOLE
Rghost Gghost=1-F before removing any cutoff. No standalone inverse heat
operator is applied to a Schwartz source and no continuum cyclic-trace
identity is assumed. Connected Grassmann contractions give

    CR = 2i sum_acd int JB_a,mu(-p-r) C_c(p) C_d(r) K_acd V_mu(p,r),

    V_mu = int d4l/(2pi)^4
      (1-F_l)^2 F_(l+p)F_(l-r) (l-r)_mu /
          [(l+p)^2(l-r)^2],
    F_q=f_delta(q) exp(-t q^2), f_delta=(1-exp(-q^2/delta^2))^2.

The four rooted/oriented labels are a complete envelope, not four unit
amplitudes. Actual normalized Gaussian weights already account for endpoint
orientation. Multiplying the formula by that count would be wrong.

Odd C exchange and antisymmetric K allow symmetric V. Reflection l->-l
proves at finite profiles

    V(p,r)+V(r,p)=-(p+r)_mu I_F(p,r),
    I_F=int d4l/(2pi)^4 (1-F_l)^2 F_(l+p)F_(l-r)/den.

Thus the FULL ordered-color functional is i K_acd j_mu JB_mu C_c C_d I_F,
j=-(p+r). There is no additional1/2. A canonical c<d monomial has coefficient
twice the full-sum row. With i*j on JB translating to a source derivative,
the ordered reference is

    QGamma_JBCC = g10*u*log(9/8)/(16pi^2)
          * sum_acd K_acd (partial_mu JB_a,mu) C_c C_d.

All91125 full-sum rows and2252 canonical coordinate jet words are retained.
There is no rational coefficient and no new UV power/log(t) subtraction in
this measured whole profile. Original/H-probe coefficients are zero by the
V808 scoped finite proper bridge and their empty catalogs. These zeros do
not extend to changed prescriptions or a general normalization theorem.

## UV-first, then IR, with joint sources

For E_q=exp(-t q^2), use weights w=(1,-2,1). Gaussian integration and two
Schwinger parameters give

 16pi^2 I_E = sum_(a=0,1,2) w_a int_(sigma,tau>=t) d sigma d tau
    exp[-(at(sigma p^2+tau r^2)+sigma tau |p+r|^2)/(at+sigma+tau)]
    /(at+sigma+tau)^2.

The radial moment is the convergent Frullani combination

    int_0^infinity (exp(-2s)-2exp(-3s)+exp(-4s)) ds/s = log(9/8).

Independently, the rational Schwinger-domain integral
int_2^infinity (u-2)[u^-2-2(u+1)^-2+(u+2)^-2]du gives the same constant.
The antighost root gives log(3/2), the B root -log(4/3). Finite r=0 E1
endpoint formulas agree with positive parameter quadratures at70/90 digits
and two scales. These are diagnostics; the following bounds justify the
limit rather than a pointwise zero-momentum calculation.

Put j=p+r and R=1+|p|+|r|. For j!=0, in |l|<=2R use h=(1-E_l)^2<=16t^2R^4.
After a=l+p, the near loop lies in |a|<=3R. Split at |a|=2|j| and around
balls of radius |j|/2 at each pole. The two small balls each contribute at
most pi^2; the remaining inner ball contributes at most128pi^2. Outside,
1/(|a|^2|a-j|^2)<=4/|a|^4. Consequently

    int_near 1/den <= pi^2[130+8 log(3R/(2|j|))].

In |l|>2R, denominator>=|l|^4/16 and the heat product<=exp(-t|l|^2/2).
After rescaling, a uniform far majorant in16pi^2 units is
16 int_0^infinity min(s,s^-1) exp(-s/2)ds, bounded by
8+32exp(-1/2). The explicit comparison uses s exp(-s/2)<=s on[0,1]
and exp(-s/2)/s<=exp(-s/2) on[1,infinity). Thus

    16pi^2 I_E <= far_const
       +16t^2 R^4[130+8 log(3R/(2|j|))].

For0<t<=1 this is a polynomial/logarithmic majorant integrable against
any joint Schwartz source in(p,r). Rescale q=sqrt(t)l. Away from q=0,
the integrand tends to the radial integrand. In a small q ball outside
2sqrt(t)R, h<=|q|^4 controls the denominator; inside the shrinking ball
the near estimate is O(t^2 R^4[1+log(R/|j|)]). This proves the a.e. UV
limit log(9/8) and its joint-source convergence by dominated convergence.
At exceptional j=0,p!=0 the unregularized scalar E kernel may diverge
logarithmically; no standalone pointwise value there is asserted.

For the whole IR difference, telescoping and0<=F<=E<=1 give the numerator
bound4exp(-l^2/delta^2)+2exp(-(l+p)^2/delta^2)+2exp(-(l-r)^2/delta^2).
Use

    1/den <=2/|j|^2(1/|l+p|^2+1/|l-r|^2),
    int exp(-(l-b)^2/delta^2)/|l-a|^2 d4l <=pi^2 delta^2.

The second estimate follows from a positive Schwinger representation; its
maximum is at a=b. Therefore, uniformly in t,p,r for j!=0,

    |16pi^2(I_F-I_E)| <=32 delta^2/|j|^2.

At fixed delta, expand h_F-h_E=2(1-E)E(1-f)+E^2(1-f)^2. The localized
first term and shifted-profile differences vanish as t->0 by the same
joint dominators; the second yields

    I_IR,delta=int (1-f_l)^2 f_(l+p)f_(l-r)/den d4l/(2pi)^4.

Since(1-f)^2<=4exp(-2l^2/delta^2), its16pi^2 bound is8delta^2/|j|^2.
Then delta->0. Both |j|^-2 and the vector bound |j|^-1 are locally
integrable in four external j dimensions. Joint Schwartz pairings give
UV-first/IR-second convergence and exclude an additional delta-supported
contact. No interchange of unsubtracted limits, early p=r=0 substitution
or unbounded standalone regulator trace is used. This is a written analytic
proof with exact/diagnostic checks, not proof-assistant kernel certification.

## Incorporation into the measured consistency sum

Using actual full Q0JB=E0_B+physicalE0_B and F0, prefix odd variation and
LEFT-jet gradients agree BEFORE projection. All45 physical kinetic Euler
divergences vanish explicitly; the physical companion cancels in divJB.
The new image has2252 words and its complete Lambda-Euler/IBP normal has6756.
Four explicit currents reconstruct it. Omitting JBCC or inserting a false
half changes6756 normal words. Adding this independently measured term to
V807 gives8860 raw logarithmic words and10964 normal words. The rational
normal stays10112. Counts are representation sizes, not severity measures.

The new sum remains incomplete. Its increase in word count is neither an
obstruction nor evidence that the missing terms will cancel. No coefficient
was chosen from the remainder. The unprobed proper JBCC coefficient is zero
in its qualified scope; Qu0 acting on other breaking carriers remains a
separate required contribution. V807's Qu1 Delta_g0 exclusion is unchanged.

## JLambdaCC: the previously missing proper prerequisite

The empty V808 raw JLambdaCC catalog is now supplemented by an actual
source/master proof. Every ordinary JLambda word isg1; there are334 in
originalS1, none in g0 or the probes' ordinary inputs. All g0 F/E maps
have no JLambda. At overallg1 a g1 source-free kernel cannot acquire
JLambda through any inverse expansion. Complete g1 source kernels are
therefore sufficient for this source target.

For original/H/M, all643-port g/u convolutions at exact one JLambda jet
are constructed from actual F/E AFTER their Euler/source operations.
Filtering other fixed sources is safe under field Taylor. Native direct
source products match the independent LEFT source-jet product rule,
including its parity sign and derivative-source jets. Every summed source
master density is exactly0 before Taylor. Prefix and LEFT Taylor, four IBP
currents and direct source Euler agree on the zero. The unsigned-source
control is blind at this target; it is not a sign-sensitive validation.
The actual668 nonzero one-source factors and their zero product partners
remain in the full record, rather than discarding those source ports.

Three completed V808 g0 GF witnesses restrict to the new source-free C<=2
budget and still reconstruct exactly. Physical g1 kernels are source-free
and excluded by the same grade rule; probe physical flows vanish. Physical
g0 proof restriction and actual hatted/CPS source-stable ideal retain their
qualified assumptions. No unknown physical E1_x is setzero. Hence the V801
proper chain and V790 Jacobian result apply in this target. Together with
all three empty V808 raw catalogs they support a finite formal proper
JLambdaCC zero for original/H/M in THIS prescription. They do not imply
global hatted, measure, phase, QAP or background-resummation zero.

Within the complete V805 carrier census this leaves the aCC family as the
remaining unmeasured quantum input for this LambdaCC test, including its
unprobed contribution where Qu0 requires it. V808 has4 original and112 M
candidates, H empty; its actual original root is R_F1 with BB endpoints
and one mean C, followed by the two g0 ghost vertices. Reducing those
operators before amplitude expansion is the next justified step. Its own
proper comparison scope must still be established, rather than inherited
from the JBCC calculation.

## Failures, authorization and AI capability

Color/Gaussian checks completed before the human pause. Analytic V1 was
launched after the pause signal; that was an authorization/workflow failure,
recorded in PAUSE_PROVENANCE.md, not retroactively approved by resumption.
It also FAILED its opaque SymPy far.is_finite query and produced no full
analytic result. Exact source/preparation/capture stay NOTPASS. After explicit
reactivation, V2 reran every analytic check under a new frozen record and
proved finiteness by an integrable comparison. No original bytes were edited.

Demonstrated AI capability here is actual-source coefficient reconstruction,
Berezin/sign diagnosis, a whole-profile joint-source proof and source-support
closure of a missing proper input. The CAS flag failure and pause handling
are concrete limitations. All methods share action/chart, exact ring, some
helpers, data and AI author. Formalization is NOT_ATTEMPTED; successful
assertions and independent algorithms do not validate shared physical
assumptions or experimental truth. Final evidence validation authenticates
these bounded claims without director acceptance or scientific promotion.
