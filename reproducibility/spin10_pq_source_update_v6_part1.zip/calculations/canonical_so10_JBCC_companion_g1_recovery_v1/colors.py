from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JBCC_actual_vertex_tools',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w;A=w.A;one=J.constant(1)
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
atom=lambda n,js=():{((n,tuple(js)),):one}
def strip(c):
 assert all(k[0]==1 for k,v in c.terms)
 return J.Coeff([((0,b,e,r),v) for (g,b,e,r),v in c.terms])
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 native=load(O/'native_operands.json.gz');replay=load(O/'replay_operands.json.gz');L={c:{} for c in range(45)};T={a:{} for a in range(45)};Lids=[];Tids=[];mu_seen={}
 for at,(ww,cs) in enumerate(native['GF0_ordinary']):
  if len(ww)!=3 or any(js for n,js in ww):continue
  ns=[n for n,js in ww]
  if 553<=ns[0]<598 and 1827<=ns[1]<1872 and 1917<=ns[2]<1962:
   c,r,i=ns[0]-553,ns[1]-1827,ns[2]-1917;assert (r,i) not in L[c];L[c][r,i]=-A.decode_coeff(cs);Lids.append(at)
 for at,(ww,cs) in enumerate(native['S1_ordinary']):
  if not any(643<=n<823 for n,js in ww):continue
  assert len(ww)==3 and not any(js for n,js in ww);jb,b,cc=[n for n,js in ww];assert 643<=jb<823 and 1319<=b<1499 and 1872<=cc<1917
  aa,mu=divmod(jb-643,4);bb,nu=divmod(b-1319,4);assert mu==nu
  key=aa,bb,cc-1872;mu_seen.setdefault(key,{})[mu]=strip(A.decode_coeff(cs));Tids.append(at)
 for (a,b,i),row in mu_seen.items():assert set(row)==set(range(4)) and len(set(row.values()))==1;T[a][b,i]=row[0]
 LR={c:{} for c in range(45)};TR={a:{} for a in range(45)};e0=dict(replay['E0']);f1=dict(replay['F1'])
 for r in range(45):
  for ww,c in J.decode(e0[508+r]).items():
   if len(ww)==2 and not any(js for n,js in ww) and 553<=ww[0][0]<598 and 598<=ww[1][0]<643:LR[ww[0][0]-553][r,ww[1][0]-598]=-c
 for a in range(45):
  rows=[]
  for mu in range(4):
   out={}
   for ww,c in J.decode(f1[4*a+mu]).items():
    assert len(ww)==2 and not any(js for n,js in ww);b,cc=[n for n,js in ww];assert b<180 and 553<=cc<598 and b%4==mu
    out[b//4,cc-553]=strip(c)
   rows.append(out)
  assert all(p==rows[0] for p in rows);TR[a]=rows[0]
 assert L==LR and T==TR
 # Reconstruct the complete source-derived Fu0 maps before using catalog support.
 flows=[];roots=[]
 for pr in [0,1]:
  actual={n:J.decode(p) for n,p in replay['Fu0_'+str(pr)]};pred={n:{} for n in range(643)}
  for r in range(45):
   if (r<12)!=(pr==0):continue
   om=J.Coeff([((0,0,1,0) if r<12 else (0,1,0,0),F(1))]);p=w.plus(w.scale(atom(508+r),J.times(J.I,om)),w.scale(atom(1241+r),J.constant(2)))
   for mu in range(4):J.add(p,w.scale(atom(4*r+mu,(mu,)),J.constant(-2)))
   for cc in range(45):
    for (rr,i),c in L[cc].items():
     if rr==r:J.add(p,w.scale(J.mul(atom(598+i),atom(553+cc)),J.times(J.I,J.times(J.constant(2),c))))
   pred[598+r]=J.clean(p)
  assert actual==pred
  full={}
  for r in range(45):
   P=m.v.tangent(pred[598+r])
   for ww,c in P.items():
    at=[(pos,n,js) for pos,(n,js) in enumerate(ww) if 1319<=n<1962];assert len(at)==1;pos,n,js=at[0]
    k=tuple(js.count(mu) for mu in range(4));phase=[one,J.I,-one,-J.I][len(js)%4]
    word=ww[:pos]+((n,()),)+ww[pos+1:]+((2515+r,()),)
    for mu in range(4):
     ll=tuple(2*int(nu==mu) for nu in range(4))+(0,)*4;key=(word,k+ll);canon,sg=J.canonical(word);key=canon,k+ll
     if sg:full[key]=full.get(key,J.ZERO)+J.times(c,phase)*sg
  full={k:c for k,c in full.items() if c};encoded=[[[[n,list(js)] for n,js in ww],list(mon),A.encode_coeff(c)] for (ww,mon),c in sorted(full.items())]
  raw=next(row for row in native['roots'] if row['state']=='Fu0_'+str(pr) and row['family']=='preference')['raw_root'];assert encoded==raw
  ref=next(row for row in native['roots'] if row['state']=='Fu0_'+str(pr) and row['family']=='reference')['raw_root'];assert ref==[]
  flows.append(dict(probe=pr,all643_full_maps_verified=True,nonzero_ports=[n for n,p in pred.items() if p]));roots.append(dict(probe=pr,full_reconstructed_root=encoded,reference_defect_zero=True,all_four_laplacian_components=True))
 # Native direct sparse color loops; all45 field matrices were extracted first.
 by_i=defaultdict(list);by_br=defaultdict(list);nativeK={}
 for a,mat in T.items():
  for (b,i),c in mat.items():by_i[i].append((a,b,c))
 for d,mat in L.items():
  for (b,r),c in mat.items():by_br[b,r].append((d,c))
 for cc,mat in L.items():
  for (r,i),lc in mat.items():
   if r<12:continue
   for a,b,tt in by_i[i]:
    for d,ld in by_br[b,r]:
     key=a,cc,d;nativeK[key]=nativeK.get(key,J.ZERO)+J.times(J.times(lc,tt),ld)
 nativeK={k:c for k,c in nativeK.items() if c}
 # Distinct trace route, no reading nativeK as a construction operand.
 PI={(r,r):one for r in range(12,45)};replayK={}
 for a in range(45):
  for cc in range(45):
   partial=A.mul(A.mul(PI,LR[cc]),A.transpose(TR[a]))
   for d in range(45):
    val=A.pairtrace(partial,LR[d])
    if val:replayK[a,cc,d]=val
 assert nativeK==replayK
 rows=[];skew=transpose_changes=omitPi_changes=0
 for a in range(45):
  for cc in range(45):
   for d in range(45):
    k=nativeK.get((a,cc,d),J.ZERO);kd=nativeK.get((a,d,cc),J.ZERO);skew+=bool(k+kd)
    # T is actually skew; transpose error is therefore a sign control.
    wrong=A.pairtrace(A.mul(A.mul(PI,L[cc]),T[a]),L[d]);transpose_changes+=bool(wrong-k)
    if a==0 and cc==0 and d==0:pass
    rows.append(dict(JB=a,C_first=cc,C_second=d,K=A.encode_coeff(k),K_swapped=A.encode_coeff(kd),exchange_sum=A.encode_coeff(k+kd),wrong_T_without_transpose_difference=A.encode_coeff(wrong-k)))
 # Dropping Pi is blind only if actual L has no H output rows; test full tensors.
 noPi={}
 for a in range(45):
  for cc in range(45):
   pt=A.mul(L[cc],A.transpose(T[a]))
   for d in range(45):
    val=A.pairtrace(pt,L[d])
    if val:noPi[a,cc,d]=val
 omitPi_changes=sum(noPi.get(key,J.ZERO)!=nativeK.get(key,J.ZERO) for key in set(noPi)|set(nativeK))
 choice=None
 for (a,cc,d),k in sorted(nativeK.items()):
  if cc==d:continue
  for r in range(12,45):
   for i in range(12,45):
    lc=L[cc].get((r,i),J.ZERO)
    if not lc:continue
    for b in range(12,45):
     if T[a].get((b,i)) and L[d].get((b,r)) and len({r,i,b})==3:choice=dict(JB=a,C_first=cc,C_second=d,internal_colors=sorted([r,i,b]));break
    if choice:break
   if choice:break
  if choice:break
 assert choice,'NO_NONZERO_ACTUAL_THREE_COLOR_FIXTURE_SUBBLOCK'
 tables=dict(schema='ACTUAL_JBCC_FULL_VERTICES_AND_COLOR_TENSOR_V1',matrices=dict(L=[[c,A.encode_matrix(p)] for c,p in L.items()],T=[[a,A.encode_matrix(p)] for a,p in T.items()]),GF0_ordinary_raw_indices=Lids,S1_JB_ordinary_raw_indices=Tids,all_four_Lorentz_T_components_equal=True,Fu0_flows=flows,Fu0_root_reconstructions=roots,all91225_colors=rows,fixture_choice=choice,K_definition='Tr(Pi_M L_c T_a^T L_d)',all_source_operations_before_graph_support=True,no_amplitude_or_loop_sign_assigned=True)
 art=save('color_tables.json.gz',tables)
 out=dict(schema='ACTUAL_JBCC_COLOR_RECONSTRUCTION_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all_color_positions=45**3,nonzero_K=len(nativeK),exchange_sum_nonzero=skew,wrong_T_transpose_changed=transpose_changes,omit_Pi_changed=omitPi_changes,actual_fixture_choice=choice,all_full_Fu0_maps_and_Preference_roots_verified=True,independent_trace_equal=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'color_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
