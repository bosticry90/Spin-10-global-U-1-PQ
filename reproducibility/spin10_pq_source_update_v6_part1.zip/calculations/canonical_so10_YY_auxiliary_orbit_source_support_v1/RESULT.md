# V1027 broken auxiliary source-support result

The two literal J_Lambda source families have 334 and 3,344 rows. The degree-one family has a typed proper return only with a light exterior ghost. The degree-two family cannot reach the width-free ordinary Lambda emitter on two ghost ports within the allowed grade. The original proper source family therefore gives no g³ J_Lambda Lambda_M C_M at xi-degree zero.

The V1025 algebraic auxiliary trial would require the paired antighost driver in the free nonminimal comparison. Its independent direct marked coefficient at epsilon18,Lambda17,C12 is +4i sqrt(10)/15 in the declared units. Native and replay retain all 33 Lambda-epsilon rows and agree on that phase.

The next ordinary candidate has both odd Y ports internal. Its composite free-field, independent-transfer and marked tests determine whether it can supply a new finite direction.
