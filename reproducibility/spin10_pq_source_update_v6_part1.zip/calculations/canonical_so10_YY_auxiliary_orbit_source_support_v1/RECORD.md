# Bounded auxiliary source-support test V1027

Freeze the V1025 skew auxiliary image, the V1026 restricted joint result, the V879 complete source exports and V791 free ordered inverse. Test both literal source grades, the allowed ordinary auxiliary emitters, the ghost-sector return and the selected width degree. Check the trial marked coefficient in the V836 and V848 charts, with the actual nonminimal signs and independent compact label.

Accept only the typed proper-source support result and the direct marked companion. Independent ordinary kernels, alternate normalization prescriptions and full source/marked restoration are outside this test. Preserve the seven unresolved custody references and existing scientific authority.
