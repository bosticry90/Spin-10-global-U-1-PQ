"""Classify the literal auxiliary source support of the skew orbit image."""
import importlib.util
from collections import Counter
import sys

import sympy as sp

from execute import ROOT, run_worker


spec = importlib.util.spec_from_file_location(
    "ports_owner", ROOT/"calculations/canonical_so10_YY_ideal_gauge_marked_ports_v1/yy_ideal_gauge_marked_ports.py")
ports = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ports)
ideal,owner,alg = ports.ideal,ports.owner,ports.alg


def census(phase):
    raw = alg.read(ports.CALC/"canonical_so10_unprobed_compact_all_coupling_v1"/
                   f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    count_source,count_ordinary = Counter(),Counter()
    light_ghost_exterior = set()
    for g,word,cells in raw:
        ids = [i for i,_ in word]
        if any(1151<=i<1196 for i in ids):
            assert all(p[:-1]==[0,0] for p,_,_ in cells)
            assert all(not jets for _,jets in word)
            assert 1163<=ids[-1]<1196
            if g==1:
                assert len(ids)==3 and 520<=ids[0]<553 and 553<=ids[1]<565
            else:
                assert g==2 and len(ids)==4
                assert 565<=ids[0]<598 and 565<=ids[1]<598 and 610<=ids[2]<643
            count_source[g] += 1
        if any(520<=i<553 for i in ids) and all(i<643 for i in ids):
            signature = "".join("B" if i<180 else "x" if i<508 else
                                "L" if i<553 else "C" if i<598 else "a" for i in ids)
            widths = {(p[0],p[1]) for p,_,_ in cells}
            assert widths==({(0,0)} if signature in ("BBL","BL") else {(1,0)})
            if signature=="BBL":
                assert g==1 and ids[0]//4 in ideal.H and ids[1]//4 in ideal.M
            count_ordinary[g,signature] += 1
        if g==1 and len(ids)==3 and ids[0]<48 and 553<=ids[1]<598 and 598<=ids[2]<610:
            light_ghost_exterior.add(ids[1]-553)
    assert count_source=={1:334,2:3344}
    assert count_ordinary=={(1,"BBL"):1336,(0,"LCa"):600,(1,"xL"):296,
                            (0,"BL"):132,(0,"LL"):33}
    assert light_ghost_exterior and light_ghost_exterior<=set(ideal.H)
    return [count_source[1],count_source[2]],sorted(light_ghost_exterior)

def marked(phase):
    if phase=="native":
        rows = alg.read(ports.CALC/"canonical_so10_cartan_generator_residual_g1_v1"/
                        "v2_fixed_ward_and_old_affine_endpoints.json.gz")["complete_K"]
    else:
        rows = alg.read(ports.CALC/"canonical_so10_augmented_metric_lift_v1"/
                        "tensor_0.json.gz")["input_polynomial_Minkowski"]
    output = {}
    for word,cells in rows:
        ids = [i for i,_ in word]
        if len(ids)!=2 or not (520<=ids[0]<553 and 1286<=ids[1]<1319):
            continue
        assert ids[0]-520==ids[1]-1286 and all(not jets for _,jets in word)
        assert all(p[:-1]==[0,1,0] for p,_,_ in cells)
        value = alg.unpack([([0,0,0,p[-1]],n,d) for p,n,d in cells])
        output[ids[0]-508] = value if phase=="native" else sp.I*value
    assert output=={i:-sp.I/2 for i in ideal.M}
    return output


def check(phase):
    counts,exterior = census(phase)
    vacuum,_,rho,f,_,_ = owner.inputs(phase)
    v = {i:z for i,z in vacuum.items() if i<54}
    E = {a:alg.apply(rho[a],v) for a in owner.COLORS}
    assert not E[12] and E[17] and E[18]
    V = sp.expand(sp.Rational(16,3)*dict(f[12,17])[18])
    assert V == -8*sp.sqrt(10)/15
    K = marked(phase)
    direct = sp.expand(K[18]*V)
    assert direct == 4*sp.I*sp.sqrt(10)/15
    return {"literal_source_counts":counts,"returning_exterior_ghost_colors":exterior,
            "selected_broken_proper_source_absent":True,
            "mark_diagonal_rows":len(K),"trial_marked_e18_L17_C12":str(direct)}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
