# Late relation to the recovered lower kinetic direction

The new JaC color/kernel outputs are complete and frozen before this
comparison. A useful least-cost question is whether their actual T matrix
is symmetric and shares the previously measured g0 kinetic Q direction
through the POLYNOMIAL relation Q+xi*T=0. Test every H/M source-color
cell; never divide by xi or a physical coupling. Both zero and nonzero
residual are valid review outcomes and must be saved. A nonzero residual
does not change the new measured coefficient or trigger a fitted factor.
No normalization coefficients, parameters or physical baseline are chosen.

Separate60s review, same8GiBsampled/350MiBfloor/64MiBpacket, exact inputs/
sources frozen first. Source coefficient and analytic artifacts are
construction-independent comparators; the old lower Q is read only late.
The result supports or rejects a tensor correlation, not full consistency,
reality/background completion or a common quantum prescription.
