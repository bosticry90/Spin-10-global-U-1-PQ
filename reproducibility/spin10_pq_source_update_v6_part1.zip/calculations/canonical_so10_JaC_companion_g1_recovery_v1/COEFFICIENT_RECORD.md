# Four-root color, Wick-sign and scalar-master calculation

The two completed catalogs agree byte-for-byte, SHA256
088dc1dddc9d29069b57f0e6538bbc4009183b089dc9030fbd6d6f30068ca1d9.
Original/H have no cycles; M has four rooted orientations, only F1 ghost
roots and the g0u1 Ja mass vertex. All other states/owners were retained
before the new catalog eliminated them. No scalar chain returns.

Next120s coefficient worker: native derives D/A from the actual newly
selected raw polarized Pref root, all four l_mu² coefficients separately;
replay derives them from LEFT derivatives of full F1. Native extracts N
from the full classical U0 ordinary ghost Hessian; replay from full Eu0_a
JaC. All45 internal colors precede the new catalog's M restriction. Copy
only these classical operands from upstream containers; no old current
or unknown proper target is a construction operand. Retain full row matches.

Compute both ghost-root placements before transposition. With one skew
N insertion, the candidate combined color is Tr[(D-A)N], rather than the
two-insertion D+A. Validate against each actual branch and opposite-root
ordering; preserve the whole4050-position H/M table including zeros and
controls. A zero total is allowed and is not replaced by a fitted value.

Fix the overall current/regulator sign independently from literal normalized
Grassmann integration of a two-pair ghost action using actual nonzero
model D/A/N entries. Keep the external mean C odd and source insertion
even/nilpotent, all partition terms and LEFT Eulers. Compare each branch
to ordered covariance contraction and prove C_Q+C_R=Jac, rather than
calling either trace expression the current by name. Test both compact
trace orientations and retain a mismatch with an older label if found.
This is a diagnostic finite Gaussian, not a physical parameter choice.
The physical proper equation follows the actual V801/V802 chain, not a
desired sign. No extra half/manual ghost-loop sign.

Then a separate120s analytic worker derives the complete finite scalar
kernel with original F=fE, its power subtraction and ordered reference,
using exact Schwinger integration and independent heat expansion/direct
quadrature where useful. Establish the same common Schwartz/IR domain,
retaining finite pure-IR defects until their bounds. Do not discard a
power divergence or assume a pointwise root zero determines the integral.
No baseline/contact is selected. Same8GiBsampled/350MiBfloor/64MiBpacket;
freeze each worker before execution. If a prior source-trace label has a
sign error, preserve original bytes and issue a qualified scope correction,
without transferring it to unrelated vector amplitudes or source reference
zeros. Final review owns all evidence and remaining scientific limits.
