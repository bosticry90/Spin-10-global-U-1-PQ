# Scalar heat master, proper coefficient and source-trace label audit

The completed new coefficient worker gives57 nonzero M colors,
T_cs=Tr[(D_c-A_c)N_s], zero H. Omitting A or replacing D-A by D+A is
BLIND on this particular full two-index color table: Tr(A N)=0 in every
position. Preserve that limitation; the four root orientations were kept.

Actual-model two-pair Grassmann integration checked each D/A branch and
C_Q+C_R=Jac with full normalized weight/LEFT Eulers. It fixes
 C_Q=-T B_F, C_R=+T B_F, proper QGamma=+T B_F.
This is not inferred from an old trace label. The older V798 written
compact C_Q formula and named coordinate-fixture current appear with the
opposite overall sign. The prior literal polynomial comparison is a
different, independently preserved object. A bounded late audit will
derive the correct sign from the same typed old fixture inputs, compare
the actual saved old number and retain the exact discrepancy. Do not
silently edit old sources/proofs/receipts, flip unrelated vector amplitudes
or use a source reference zero to validate a finite sign.

Freeze before this separate120s analytic/late-audit worker, same8GiBsampled/
350MiBfloor/64MiBpacket. New scalar kernel is
 B_F(p)=integral(1-F(q)) F(q+p)/(q+p)^2 d4q/(2pi)^4.
Derive the auxiliary E-profile kernel by exact Schwinger integration and
independent Gaussian Taylor moment, and check nonzero p2 by quadrature.
Keep its computed power subtraction and prove a polynomial Schwartz
majorant, not an unbounded pointwise expansion. Bound B_F-B_E uniformly
in t,p before IR removal with f=(1-exp(-q2/delta2))^2; retain all pure-IR
pieces and exclude surviving delta contacts through the same bound.

Transfer to every4050 source-color slot only after these actual-order,
normalization and domain proofs. Original/H support zero comes from the
complete new catalog; no new hatted insertion is assigned zero globally.
The selected actual upper-budget master/source pairing and Ja-stable
matter ideal from V802/803 apply to this sub-budget. No new common finite
baseline or source contact is adopted. Sign/half controls can be tested
on the nonzero proper reference; A/transposition omissions remain blind
here, while omitted marked mass roots may change finite kernels/powers
without changing their p2 reference. Keep these scopes distinct.
