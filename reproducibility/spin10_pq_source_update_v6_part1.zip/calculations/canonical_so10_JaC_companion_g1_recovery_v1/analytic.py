from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import gzip,importlib.util,json,os,threading,time
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JaC_analytic_coefficients',O/'coefficients.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=m.read;load=m.load;digest=m.digest;J=m.J;A=m.A
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'analytic_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 t,p2,z,u=s.symbols('t p2 z u',positive=True);I0=1/t;I1=(s.exp(-t*p2/2)-s.exp(-t*p2))/(t*t*p2);B=I0-I1
 sch=s.integrate(s.exp(-t*p2)*s.exp(t*t*p2*u),(u,0,1/(2*t)));assert s.simplify(sch-I1)==0
 expansion=s.series(B,t,0,3);moment=s.integrate((u-1)/u**3,(u,2,s.oo));assert moment==s.Rational(3,8)
 assert s.limit(t*B,t,0)==s.Rational(1,2) and s.simplify(s.limit(B-1/(2*t),t,0)/p2)==moment
 remainder=s.integrate((1-u/2)**2,(u,0,1))/4;assert remainder==s.Rational(7,48)
 mp.mp.dps=60;quadrature=[]
 for x in [mp.mpf(1)/3,mp.mpf(1),mp.mpf(2),mp.mpf(5)]:
  direct=mp.quad(lambda a:mp.exp(-(1+a)*x/(2+a))/(2+a)**2,[0,1,mp.inf]);closed=(mp.exp(-x/2)-mp.exp(-x))/x;error=abs(direct-closed);assert error<mp.mpf('1e-45')
  quadrature.append(dict(p2=str(x),direct_Schwinger_I1=str(direct),closed_I1=str(closed),absolute_error=str(error)))
 # Exact positive Gaussian/Riesz convolution bound used in the written
 # whole-profile proof: integral exp(-q²/d²)/|q+p|² <= pi² d².
 a=s.symbols('a',positive=True);riesz=s.integrate(1/(1+a)**2,(a,0,s.oo));assert riesz==1
 coeff=load(O/'coefficient_tables.json.gz');proper=[];nonzero=0
 for row in coeff['all4050_colors']:
  T=A.decode_coeff(row['T_D_minus_A']);ref=J.times(T,J.constant(Q(3,8)));nonzero+=bool(ref)
  proper.append(dict(probe=row['probe'],C=row['C'],Ja=row['Ja'],proper_QGamma_p2=A.encode_coeff(ref),covariance_current_p2=A.encode_coeff(-ref),raw_regulator_p2=A.encode_coeff(ref),proper_power_1_over_t=A.encode_coeff(J.times(T,J.constant(Q(1,2)))),wrong_global_sign_difference=A.encode_coeff(-2*ref),wrong_extra_half_difference=A.encode_coeff(J.times(-ref,J.constant(Q(1,2))))))
 assert nonzero==57
 # Late audit of V798's SAME fixed coordinate fixture, not an operand in
 # construction of the new model sign/colors or heat master.
 hv=s.Matrix([1,2,3,4]);U=s.eye(4)-2*hv*hv.T/(hv.dot(hv));j=s.Matrix([[0,1],[-1,0]]);deriv=U*s.diag(j,2*j)*U.T;profile=U*s.diag(s.Rational(1,2),s.Rational(1,2),s.Rational(2,3),s.Rational(2,3))*U.T
 kr=s.kronecker_product;K=kr(s.eye(3),-deriv*deriv);F=kr(s.eye(3),profile);G=F*K.inv();RR=(F.inv()-s.eye(12))*K;eps=lambda c:s.Matrix(3,3,lambda a,b:s.LeviCivita(c,a,b))
 C=kr(s.eye(3),s.diag(-2,1,2,4));L=kr(eps(0),s.diag(2,-1,3,1));N=-2*s.I*kr(eps(1),s.diag(1,3,-2,4));D=kr(eps(2),s.eye(4));AA=2*D
 GL=-G*L*G;GN=-G*N*G;GLN=G*L*G*N*G+G*N*G*L*G
 oldplus=s.trace(D*C*(GLN*K+GL*N+GN*L))+s.trace(AA.T*C*(K*GLN+L*GN+N*GL))
 literal_CQ=-s.trace(D*C*(GLN*K+GL*N+GN*L))-s.trace(AA.T*C*(K*GLN+L*GN+N*GL))
 raw_CR=-s.trace(D*C*GLN*RR)-s.trace(AA.T*C*RR*GLN);assert literal_CQ==-raw_CR==-oldplus and literal_CQ!=0
 old=read(O.parent/'canonical_so10_source_expanded_regulator_reconciliation_g1_v1/analytic_result_v2.json');assert s.simplify(s.sympify(old['direct_expanded_current'])-oldplus)==0
 audit=dict(old_V798_named_direct_current=str(oldplus),correct_actual_LEFT_current=str(literal_CQ),correct_raw_regulator=str(raw_CR),current_plus_raw_regulator='0',old_named_current_minus_actual=str(oldplus-literal_CQ),old_literal_polynomial_comparison_not_changed=True,old_Dyson_matrix_identities_remain_true=True,old_zero_ordered_source_reference_unchanged=True,V793_current_equals_minus_raw_regulator_convention_retained=True,unrelated_vector_amplitudes_not_recomputed_or_flipped=True)
 packet=dict(schema='ACTUAL_JAC_G1_FINITE_AND_ORDERED_REFERENCE_V1',source_color_rows=proper,original_zero_complement=dict(color_positions=2025,finite_zero_by_complete_returning_catalog=True),normalization='overall g10*u/(16*pi^2); original Euclidean A0; proper coefficient +T*B_F',finite_kernel='B_F=integral (1-Fq)*F(q+p)/(q+p)^2, F=fE',auxiliary_heat_kernel=str(B),power_subtraction='T/(2t)',ordered_reference='+3*T*p2/8',UV_subtracted_majorant='0<=B_E-1/(2t)<=3*p2/8',UV_remainder_bound='7*t*p2^2/48',IR_uniform_bound_16pi2_units='|B_F-B_E|<=4*delta^2',UV_first_then_IR=True,source_trace_label_audit=audit,not_common_normalization_adoption=True,scientific_acceptance='NOT_PERFORMED')
 blob=gzip.compress((json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'proper_reference.json.gz').open('xb') as h:h.write(blob)
 result=dict(schema='ACTUAL_JAC_G1_SCALAR_MASTER_AND_LATE_TRACE_AUDIT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',heat_expansion=str(expansion),proper_p2_multiplier='3/8',new_nonzero_M_coefficients=nonzero,Schwinger_quadrature=quadrature,independent_UV_moment=str(moment),polynomial_joint_Schwartz_majorant=True,whole_IR_uniform_removal_bound=True,no_standalone_inverse_heat_map=True,source_trace_label_audit=audit,artifact_sha256=sha256(blob).hexdigest(),elapsed_after_imports=time.perf_counter()-tick)
 with (O/'analytic_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<64*1024**2
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
