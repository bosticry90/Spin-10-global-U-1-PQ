from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gc,gzip,importlib.util,itertools,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
sp=importlib.util.spec_from_file_location('new_JaC_raw_root_helpers',O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/roots.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp2=importlib.util.spec_from_file_location('new_JaC_edges',O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/inventory.py');v=importlib.util.module_from_spec(sp2);sp2.loader.exec_module(v)
TARGET=(0,0,1,1);read=m.read;load=m.load;digest=m.digest
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<64*1024**2
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def paths(classes,u,probe,method,mode='actual',omit=None):
 def allowed(a):
  owner=a['owner'];other=None if probe is None else 1-probe
  if probe is None and ('probe' in owner or 'Fu' in owner):return False
  if other is not None and (owner=='GF_probe'+str(other) or owner in ['R_Fu0_'+str(other),'R_Fu1_'+str(other)]):return False
  return True
 marks=[i for i,a in enumerate(classes) if a['kind']=='marked' and allowed(a)]
 ordinary=[i for i,a in enumerate(classes) if a['kind']=='ordinary' and allowed(a) and not(omit=='inverse_U' and a['u'] and not any(a['external']))]
 assert all(any(classes[i]['external']) or classes[i]['g'] or classes[i]['u'] for i in ordinary)
 out=set();bound=4
 def valid(g,uu,e):return g<=1 and uu<=u and all(a<=b for a,b in zip(e,TARGET))
 for root in marks:
  r=classes[root];g0,u0,e0=r['g'],r['u'],tuple(r['external'])
  if not valid(g0,u0,e0):continue
  for ro in [0,1]:
   start=r['quantum'][ro];last=r['quantum'][1-ro]
   if method=='native':
    def dfs(last,g,uu,e,path):
     if (g,uu,e)==(1,u,TARGET) and v.edge(last,start,mode):out.add((root,ro,tuple(path)))
     if len(path)==bound:return
     for i in ordinary:
      a=classes[i];gg=g+a['g'];vv=uu+a['u'];ee=v.addtuple(e,tuple(a['external']))
      if not valid(gg,vv,ee):continue
      for orient in [0,1]:
       if v.edge(last,a['quantum'][orient],mode):dfs(a['quantum'][1-orient],gg,vv,ee,path+[(i,orient)])
    dfs(last,g0,u0,e0,[])
   else:
    bags=[]
    def collect(at,items,g,uu,e):
     if (g,uu,e)==(1,u,TARGET):bags.append(tuple(items))
     if len(items)==bound:return
     for j in range(at,len(ordinary)):
      i=ordinary[j];a=classes[i];gg=g+a['g'];vv=uu+a['u'];ee=v.addtuple(e,tuple(a['external']))
      if valid(gg,vv,ee):collect(j,items+[i],gg,vv,ee)
    collect(0,[],g0,u0,e0)
    for bag in bags:
     for order in sorted(set(itertools.permutations(bag))):
      for orientations in itertools.product([0,1],repeat=len(order)):
       current=last;ok=True
       for i,orient in zip(order,orientations):
        a=classes[i]
        if not v.edge(current,a['quantum'][orient],mode):ok=False;break
        current=a['quantum'][1-orient]
       if ok and v.edge(current,start,mode):out.add((root,ro,tuple(zip(order,orientations))))
 return [[r,ro,[[i,o] for i,o in path]] for r,ro,path in sorted(out)]
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'catalog_preparation.json')
 for n,h in prep['sha256'].items():assert digest(R/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_NEW_JAC_OUTPUT_DENIED'
 sys.addaudithook(guard)
 roots=load(O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1'/(ROLE+'_root_assemblies.json.gz'))['assemblies'];groups=[];signatures=set()
 for row in roots:
  raw=row['raw_root'];selected=[];bad=defaultdict(list);by=defaultdict(list)
  for at,(ww,mon,cells) in enumerate(raw):
   word=tuple((n,tuple(js)) for n,js in ww);why=m.classify(word,TARGET)
   if why:bad[why].append(at);continue
   qq=[];ext=[0]*4
   for n,js in ww:
    if 1319<=n<1962:qq.append(v.tag(n-1319))
    elif 1962<=n<2605:qq.append(v.tag(n-1962))
    else:ext[v.mean(n)]+=1
   assert all(key[0]==row['g'] for key,num,den in cells)
   sig=('R_'+row['state'],'marked',row['g'],row['u'],tuple(qq),tuple(ext));by[sig].append(len(selected));selected.append(raw[at])
  disposition='RETAINED';diagonal=None
  if row['state']=='F0' and row['family']=='preference':
   assert row['free_proof']['whole_free_zero'] and raw==row['free_proof']['raw_free'] and not row['free_proof']['graded_exchange_at_l_minus_k'];disposition='WHOLE_FREE_F0_ZERO_BEFORE_ORDINARY_INSERTIONS'
  if row['family']=='reference':
   diagonal=m.encode(m.diagonal(m.decode(selected)))
   if diagonal:save('reference_diagonal_failure_'+row['state'],dict(selected=selected,diagonal=diagonal));raise AssertionError('NONZERO_NEW_REFERENCE_DIAGONAL')
   disposition='NEW_SELECTED_WHOLE_REFERENCE_DIAGONAL_ZERO'
  if disposition=='RETAINED':signatures.update(by)
  groups.append(dict(state=row['state'],family=row['family'],g=row['g'],u=row['u'],raw_root_terms=len(raw),raw_root_math_sha256=m.mhash(raw),selected=selected,kept_raw_indices=[at for at,(ww,mon,cells) in enumerate(raw) if m.classify(tuple((n,tuple(js)) for n,js in ww),TARGET) is None],rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(bad.items())],groups=[dict(signature=[a,b,c,d,list(e),list(f)],selected_indices=ids) for (a,b,c,d,e,f),ids in sorted(by.items())],disposition=disposition,whole_reference_diagonal=diagonal))
 del roots;gc.collect();whole=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(ROLE+'_whole_inventory.json.gz'));ordinary=[]
 for block,rec in enumerate(whole['projections']['source']):
  retained=[];rejected=[]
  for group in rec['groups']:
   a,b,c,d,e,f=group['signature']
   if b!='ordinary':continue
   if any(x>y for x,y in zip(f,TARGET)):rejected.append(group);continue
   sig=(a,b,c,d,tuple(e),tuple(f));signatures.add(sig);retained.append(group)
  ordinary.append(dict(old_source_block=block,raw_vertex_math_sha256=rec['raw_mathematical_sha256'],raw_vertex_terms=rec['raw_word_count'],retained_groups=retained,rejected_groups=rejected,old_discarded_cannot_reenter_subset=True))
 del whole;gc.collect()
 classes=[dict(id=i,owner=a,kind=b,g=c,u=d,quantum=list(e),external=list(f)) for i,(a,b,c,d,e,f) in enumerate(sorted(signatures))];cases=[]
 for label,u,probe in [('original',0,None),('probe0',1,0),('probe1',1,1)]:
  actual=paths(classes,u,probe,ROLE);wrong={name:paths(classes,u,probe,ROLE,mode=mode) for name,mode in [('wrong_HM','mix_HM'),('wrong_LL','LL'),('wrong_unrestricted','unrestricted')]};omit=paths(classes,u,probe,ROLE,omit='inverse_U')
  active={q for root,ro,p in actual for i in [root]+[j for j,o in p] for q in classes[i]['quantum']}
  rootscount=Counter(classes[r]['owner'] for r,ro,p in actual)
  # An arbitrary scalar zero-arity chain can be erased without changing
  # grade/means or same-sector free connectivity. No reduced scalar cycle
  # therefore excludes every chain length, not a truncation by this bound.
  scalar=[z for z in actual if any(q.startswith('x') for i in [z[0]]+[j for j,o in z[2]] for q in classes[i]['quantum'])]
  if scalar:save('scalar_cycle_failure_'+label,dict(classes=classes,complete_cycles=actual,scalar_cycles=scalar));raise AssertionError('SCALAR_CHAINS_REQUIRE_RESUMMED_CONTINUATION')
  cases.append(dict(case=label,u=u,probe=probe,complete_cycles=actual,root_counts=dict(sorted(rootscount.items())),active_quantum_types=sorted(active),scalar_reduced_cycles=scalar,arbitrary_scalar_zeroarity_chains_nonreturn=True,max_vertices=max((len(p)+1 for r,ro,p in actual),default=0),wrong=wrong,omit_inverse_U=omit))
  print('STAGE '+ROLE+' JaC '+label+' cycles'+str(len(actual))+' roots'+json.dumps(dict(rootscount),sort_keys=True),flush=True)
 packet=save('catalog',dict(target=list(TARGET),root_groups=groups,ordinary_subset_provenance=ordinary,classes=classes,cases=cases,all643_field_sources_inherited_from_full_raw_roots=True,total_vertex_bound=5,scalar_chain_erasure_proof_required=True,candidates_not_amplitudes=True))
 result=dict(schema='ACTUAL_JAC_G1_RETURNING_CATALOG_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,artifact=packet,cases=[{k:v for k,v in z.items() if k not in ['complete_cycles','wrong','omit_inverse_U','scalar_reduced_cycles']}|dict(cycles=len(z['complete_cycles']),wrong_counts={k:len(v) for k,v in z['wrong'].items()},omit_inverse_U_cycles=len(z['omit_inverse_U'])) for z in cases],class_count=len(classes),elapsed_after_imports=time.perf_counter()-tick)
 with (O/(ROLE+'_catalog_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
