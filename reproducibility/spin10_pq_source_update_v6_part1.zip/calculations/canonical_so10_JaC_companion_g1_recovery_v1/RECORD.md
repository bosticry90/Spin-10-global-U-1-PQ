# Actual two-derivative Ja-C companion at g1

Basecba51d54e6c4b8ff52a53887d0af72dadefe204e/main,V805. Fullgoal read,
currentAGENTS/D:first,state113/34of39,E5/A5open unchanged. Noagents/new
branch/worktree/adoption/promotion/protectedactivation/flavor/remoteaction.
Ordinary scientific discretion delegated; education voluntary/nonblocking.

Question: what are the original and first-u g1 proper Slavnov coefficients
Ja_s C_c with two derivatives? V805 proves this carrier can enter the
LambdaCC consistency equation and is distinct from V803's JaLambdaC.
Compute actual returning inputs, ordered contractions and finite reference;
do not set unknown companions to fit the measured vector coefficient.

Scope original unshifted EuclideanA0,g1,u0/u1,both H/M probes,intrinsic01,
all45 colors/fullsourceoperations before restriction. Mean budget in the
established (B,Lambda,C,Ja) alphabet is(0,0,1,1). The scalar p2 Lorentz
coefficient has intrinsic0; intrinsic1 has no parity-even Lorentz scalar
at this target. No physical widths/couplings/baseline are selected.

Reuse complete V792 raw roots for allF0/F1/Fu0/Fu1 states and both Pref/
reference families, with the independent quantum halves/momenta kept.
Freshly project every raw root and retain exact rejected/kept indices.
F0 is removed only by its qualified WHOLE free exchange identity before
ordinary insertions; Fu0/Fu1 free groups remain. Reference removal requires
the new selected whole diagonal proof, not individual-field zeros.
The V800 completed Hamiltonian check already authenticates every F field
map used by these roots. Do not substitute its old incomplete source QJ
table; all proper/source operations use the completed convention.

For ordinary classes, the new budget is a subset of the qualified V789
upper source budget(0,1,1,1). Existing discarded means cannot be repaired
by a contraction, so reuse is safe. Refilter every ordinary signature,
retaining full raw-vertex hash/index provenance and physical owners; do
not import any old returning-path or excluded-port result. Physical S1
gauge/scalar cubic Hessians each leave a forbidden B/x mean in this new
budget, but retain their disposition before excluding them.

Native oriented DFS and replay multisets/all orders/halfedges must agree
exactly for(1,0) and(1,1) grades. All nonreference g0u0 ordinary vertices
have positive mean arity; zero-arity ordinary costs g or u. Two external
means plus at most two costly zero-arity vertices give a conservative
five-total-vertex bound. Constant scalar reference/potential chains are
not counted by g/u: erase any such x-to-x zero-arity chain from a cycle.
If the complete reduced catalog has no scalar cycle, arbitrary chain
length cannot create one. If a scalar cycle survives, classify that part
incomplete and retain it for a separate resummed inverse; never truncate.

Matter/source K is outside the643 gauge/scalar input, not assignedzero.
On the declared zero-matter/source plane, probe generators commute with
the matter action and have no matter ports; Ja enters only nonminimal
ghost/probe Hessians, not the fermion block. No one-loop Ja-containing
fermion cycle can return without a forbidden mixed matter mean. The
hatted trace is Ja/u independent after the permitted external operations;
keep that scoped CPS proof, not a global chiral/measure zero.

V802's full upper-budget actual proper KQ/KD/master identity restricts
to this sub-budget because derivatives/IBP preserve mean counts. V803
fixes the same proper Gaussian normalization. V790/V799's finite Gaussian
current/regulator identity is structural for these full F/E operands,
not a transfer of old amplitude counts. Check its application to the new
owners explicitly before identifying proper QGamma=-C_Q. Keep source
quadratics and inverse responses, all F1/Fu0/Fu1 branches and original
order until a new complete catalog/support proof permits their exclusion.

After the catalogs freeze, derive actual ordered color/derivative kernels
from retained raw root/ordinary rows and the same inverse. Keep both
ghost orientations, noncommuting profile placement, whole mean subtraction
and all active quantum sectors. Use distinct derivations/negative controls
where nonzero. Evaluate only the new scalar masters needed, including
power subtraction and qualified UV-first joint-Schwartz/IR reference.
No old physical/contact tensor is a fitted operand or desired answer.

Catalog native/replay180s each serial,8GiBsampled/350MiBfloor/64MiBpacket;
subsequent coefficient/analytic workers120s each if needed, prospective
sources/inputs frozen separately. Final180s owns bindings/resources/state/
oldtree,E4once-no-freshDcontext0,0,0,0,0,2/seven custodyNOTPASS. Preserve
all failed/unfinished sources/full captures, no silent allowance expansion.
Stage rawbytes/modes/cachedcheck beforelocalcommit, mainpreserved/nopush.
Acceptance ceiling actual selected companion, not all-source restoration,
QAP/measure/equivalence/E5/A5/viability/fullinvestigationcompletion. Shared
action/chart/analytic premises/ring/software/AIauthor limit independence.
