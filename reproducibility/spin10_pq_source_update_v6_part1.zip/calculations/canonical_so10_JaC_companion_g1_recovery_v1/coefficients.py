from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JaC_actual_coeff_tools',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w;A=w.A;zero=J.ZERO;one=J.constant(1)
load=lambda p:json.loads(gzip.decompress(p.read_bytes()));read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def strip(c):
 assert all(g==1 for (g,b,e,r),v in c.terms)
 return J.Coeff([((0,b,e,r),v) for (g,b,e,r),v in c.terms])
def mats():return {c:{} for c in range(45)}
def plus(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=out.get(k,zero)+c
 return {k:c for k,c in out.items() if c}
def scale(p,c):return {k:J.times(v,c) for k,v in p.items() if J.times(v,c)}
def mul(p,q):
 out={}
 for (u,a),c in p.items():
  for (v,b),d in q.items():
   if u+v>1 or a&b:continue
   sg=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(5) if a&(1<<i));key=u+v,a|b;out[key]=out.get(key,zero)+sg*J.times(c,d)
 return {k:c for k,c in out.items() if c}
def atom(i):return {(0,1<<i):one}
def deriv(p,i):return {(u,mask^(1<<i)):c*((-1)**((mask&((1<<i)-1)).bit_count())) for (u,mask),c in p.items() if mask&(1<<i)}
def enc(p):return [[u,mask,A.encode_coeff(c)] for (u,mask),c in sorted(p.items())]
def fixture(D,AA,N):
 choice=None
 for pr in [0,1]:
  for c in range(45):
   for src in range(45):
    for i in range(12,45):
     for j in range(i+1,45):
      if (D[c].get((i,j),zero) or AA[c].get((i,j),zero)) and N[pr][src].get((j,i),zero):choice=pr,c,src,i,j;break
     if choice:break
    if choice:break
   if choice:break
  if choice:break
 assert choice
 pr,c,src,i,j=choice;idx=[i,j];d={(a,b):D[c].get((idx[a],idx[b]),zero) for a in range(2) for b in range(2)};aa={(a,b):AA[c].get((idx[a],idx[b]),zero) for a in range(2) for b in range(2)};n={(a,b):N[pr][src].get((idx[a],idx[b]),zero) for a in range(2) for b in range(2)}
 k=F(3);f=F(2,5);rr=k/f-k;g=f/k;S0={};SR={};SN={};PC=[{},{}];PA=[{},{}]
 for a in range(2):
  S0=plus(S0,scale(mul(atom(2+a),atom(a)),J.constant(k)));SR=plus(SR,scale(mul(atom(2+a),atom(a)),J.constant(rr)))
  for b in range(2):
   if n[a,b]:SN=plus(SN,{(1,mask):cc for (u,mask),cc in scale(mul(atom(2+a),atom(b)),n[a,b]).items()})
   PC[a]=plus(PC[a],scale(mul(atom(4),atom(b)),d[a,b]));PA[a]=plus(PA[a],scale(mul(atom(4),atom(2+b)),aa[a,b]))
 S=plus(S0,SN);total=plus(S,SR);term={(0,0):one};weight=dict(term)
 for nn in range(1,4):
  term=scale(mul(term,scale(total,J.constant(-1))),J.constant(F(1,nn)));weight=plus(weight,term)
 assert not term
 def integrate(p):return {(u,mask^15):c for (u,mask),c in p.items() if mask&15==15}
 Z=integrate(weight);z=Z[0,0];assert len(z.terms)==1 and z.terms[0][0]==(0,0,0,0);z0=z.terms[0][1]
 inv={(0,0):J.constant(1/z0)}
 if Z.get((1,0)):inv[1,0]=J.times(-Z[1,0],J.constant(1/z0**2))
 expect=lambda p:mul(integrate(mul(p,weight)),inv)
 lit={};jac={};polys={}
 for name,PP,start in [('D',PC,0),('AT',PA,2)]:
  direct={};reg={};jj={}
  for a,P in enumerate(PP):direct=plus(direct,mul(P,deriv(S,start+a)));reg=plus(reg,mul(P,deriv(SR,start+a)));jj=plus(jj,deriv(P,start+a))
  qv=expect(direct);rv=expect(reg);assert plus(qv,rv)==jj
  tn=A.pairtrace(d,n) if name=='D' else A.pairtrace(A.transpose(aa),n)
  predicted=J.times(tn,J.constant(g*(1-f)));assert rv.get((1,16),zero)==predicted and qv.get((1,16),zero)==-predicted
  lit[name]=dict(CQ=enc(qv),CR=enc(rv),Jac=enc(jj),color=A.encode_coeff(tn),CQ_u=A.encode_coeff(qv.get((1,16),zero)),CR_u=A.encode_coeff(rv.get((1,16),zero)),wrong_plus_trace_CQ_u=A.encode_coeff(predicted),wrong_minus_trace_CQ_u=A.encode_coeff(-predicted));polys[name]=dict(P=[enc(p) for p in PP],current=enc(direct),regulator=enc(reg))
 assert any(row['CQ_u'] for row in lit.values())
 cov=[dict(i=a,j=b,literal=enc(expect(mul(atom(a),atom(b))))) for a in range(4) for b in range(4)]
 return dict(actual_color_choice=list(choice),K=str(k),F=str(f),not_physical_parameter_point=True,Sphysical=enc(S),Sregulator=enc(SR),weight=enc(weight),partition=enc(Z),partition_inverse=enc(inv),branch_polynomials=polys,branches=lit,all16_ordered_covariances=cov,current_equals_negative_raw_regulator_by_literal_integration=True,compact_current_has_minus_trace_sign=True)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'coefficient_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 packet=load(O/'coefficient_native_inputs.json.gz');replay=load(O/'coefficient_replay_inputs.json.gz');cat=load(O/'native_catalog.json.gz');root=next(z for z in cat['root_groups'] if z['state']=='F1' and z['family']=='preference')
 D=mats();AA=mats();seen={};rawindices=[]
 for at,(ww,mon,cs) in enumerate(root['selected']):
  if len(ww)!=3 or any(js for n,js in ww) or not 553<=ww[0][0]<598:continue
  c=ww[0][0]-553;n1=ww[1][0];n2=ww[2][0]
  if 1872<=n1<1917 and 2560<=n2<2605:kind='D';r=n2-2560;i=n1-1872;sg=-1
  elif 1917<=n1<1962 and 2515<=n2<2560:kind='A';r=n2-2515;i=n1-1917;sg=1
  else:continue
  mus=[mu for mu in range(4) if mon[4+mu]==2 and sum(mon)==2];assert len(mus)==1 and all(mon[j]==0 for j in range(4));mu=mus[0];v=strip(A.decode_coeff(cs))*sg;key=kind,c,r,i;seen.setdefault(key,{})[mu]=v;rawindices.append(at)
 for (kind,c,r,i),row in seen.items():assert set(row)==set(range(4)) and len(set(row.values()))==1;(D if kind=='D' else AA)[c][r,i]=row[0]
 F1={n:J.decode(p) for n,p in replay['F1']};dR=mats();aR=mats()
 for start,out in [(553,dR),(598,aR)]:
  for r in range(45):
   for i in range(45):
    partial=w.scale(J.leftjet(F1[start+r],(start+i,())),J.constant(-1))
    for ww,c in partial.items():
     if len(ww)==1 and not ww[0][1] and 553<=ww[0][0]<598:out[ww[0][0]-553][r,i]=strip(c)
 assert D==dR and AA==aR
 NN=[];NR=[];ordinary_indices=[]
 for pr in [0,1]:
  N=mats();nr=mats();ids=[]
  for at,(ww,cs) in enumerate(packet['U0_ordinary'][pr]):
   if len(ww)==3 and all(not js for n,js in ww) and 1241<=ww[0][0]<1286 and 1872<=ww[1][0]<1917 and 1917<=ww[2][0]<1962:N[ww[0][0]-1241][ww[2][0]-1917,ww[1][0]-1872]=-A.decode_coeff(cs);ids.append(at)
  eu=dict(replay['Eu0_'+str(pr)])
  for r in range(45):
   for ww,c in J.decode(eu[598+r]).items():
    if len(ww)==2 and not any(js for n,js in ww) and 553<=ww[0][0]<598 and 1241<=ww[1][0]<1286:nr[ww[1][0]-1241][r,ww[0][0]-553]=c
  assert N==nr;NN.append(N);NR.append(nr);ordinary_indices.append(ids)
 assert all(not z for z in NN[0].values()) and all(A.add(v,A.transpose(v))=={} for N in NN for v in N.values())
 fullmat=dict(D=[[c,A.encode_matrix(v)] for c,v in D.items()],A=[[c,A.encode_matrix(v)] for c,v in AA.items()],N=[[[c,A.encode_matrix(v)] for c,v in N.items()] for N in NN])
 rows=[];counts=[]
 for pr,N in enumerate(NN):
  nz=pluschanged=omitA=0
  for c in range(45):
   for src in range(45):
    td=A.pairtrace(D[c],N[src]);ta=A.pairtrace(A.transpose(AA[c]),N[src]);total=td+ta
    direct=sum((J.times(z,N[src].get((i,r),zero)) for (r,i),z in D[c].items()),zero)+sum((J.times(z,N[src].get((r,i),zero)) for (r,i),z in AA[c].items()),zero);assert total==direct==A.pairtrace(A.add(D[c],AA[c],-1),N[src])
    activeD={(i,j):z for (i,j),z in D[c].items() if i>=12 and j>=12};activeA={(i,j):z for (i,j),z in AA[c].items() if i>=12 and j>=12};assert total==A.pairtrace(A.add(activeD,activeA,-1),N[src])
    wrong=A.pairtrace(A.add(D[c],AA[c]),N[src])-total;om=td-total;nz+=bool(total);pluschanged+=bool(wrong);omitA+=bool(om)
    rows.append(dict(probe=pr,C=c,Ja=src,D=A.encode_coeff(td),A_transpose=A.encode_coeff(ta),T_D_minus_A=A.encode_coeff(total),wrong_D_plus_A_difference=A.encode_coeff(wrong),omit_A_difference=A.encode_coeff(om),proper_equals_positive_raw_CR_kernel_color=A.encode_coeff(total)))
  counts.append(dict(probe=pr,positions=2025,nonzero=nz,wrong_D_plus_A_changed=pluschanged,omit_A_changed=omitA))
 fx=fixture(D,AA,NN)
 out=dict(schema='ACTUAL_JAC_G1_COLORS_AND_LITERAL_WICK_SIGN_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',matrices=fullmat,root_raw_selected_indices=rawindices,all_four_root_laplacian_components_verified=True,ordinary_selected_indices=ordinary_indices,all4050_colors=rows,counts=counts,literal_model_coefficient_fixture=fx,CQ='-T*B(F); T=Tr[(D-A)N]',CR='+T*B(F)',proper_QGamma='+T*B(F) by actual proper master chain',trace_sign_not_inferred_from_old_label=True,elapsed_after_imports=time.perf_counter()-tick)
 blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'coefficient_tables.json.gz').open('xb') as h:h.write(blob)
 result={k:v for k,v in out.items() if k not in ['matrices','root_raw_selected_indices','ordinary_selected_indices','all4050_colors','literal_model_coefficient_fixture']};result['artifact_sha256']=sha256(blob).hexdigest()
 with (O/'coefficient_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<64*1024**2
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
