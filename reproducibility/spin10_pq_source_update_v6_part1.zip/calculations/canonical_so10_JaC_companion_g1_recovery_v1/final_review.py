from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import ast,gc,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JaC-companion-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('JaC_final_coeffs',O/'coefficients.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=m.read;load=m.load;digest=m.digest;J=m.J;A=m.A
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def classify(ww):
 count=[0]*4;quant=[0,0]
 for n,js in ww:
  if 1319<=n<1962:quant[0]+=1
  elif 1962<=n<2605:quant[1]+=1
  elif n<180:count[0]+=1
  elif 508<=n<553:count[1]+=1
  elif 553<=n<598:count[2]+=1
  elif 1241<=n<1286:count[3]+=1
  else:return 'FORBIDDEN_MEAN'
 if quant!=[1,1]:return 'NOT_ONE_OF_EACH_QUANTUM_HALFEDGE'
 if any(a>b for a,b in zip(count,[0,0,1,1])):return 'EXTERNAL_PROFILE_EXCEEDED'
 return None
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['catalog_preparation.json','coefficient_preparation.json','analytic_preparation.json','late_tensor_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps={};seconds={}
 for name,cf,rf,bound in [('native','native_catalog_capture.json','native_catalog_result.json',180),('replay','replay_catalog_capture.json','replay_catalog_result.json',180),('coefficient','coefficient_capture.json','coefficient_result.json',120),('analytic','analytic_capture.json','analytic_result.json',120),('late_tensor','late_tensor_capture.json','late_tensor_result.json',60)]:
  cap=read(O/cf);res=read(O/rf);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);caps[name]=cap;seconds[name]=res['elapsed_after_imports']
 assert (O/'native_catalog.json.gz').read_bytes()==(O/'replay_catalog.json.gz').read_bytes()
 cat=load(O/'native_catalog.json.gz');old=load(O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/native_root_assemblies.json.gz')['assemblies'];checked=0
 assert len(cat['root_groups'])==len(old)==12
 for saved,raw in zip(cat['root_groups'],old):
  assert (saved['state'],saved['family'])==(raw['state'],raw['family']);rr=raw['raw_root'];kept=[];rejected={}
  for i,row in enumerate(rr):
   why=classify(row[0])
   if why:rejected[i]=why
   else:kept.append(i)
  assert saved['kept_raw_indices']==kept and saved['selected']==[rr[i] for i in kept]
  bad={i:z['reason'] for z in saved['rejected'] for i in z['raw_indices']};assert bad==rejected
  assert sum(len(g['selected_indices']) for g in saved['groups'])==len(kept)
  if raw['family']=='reference':assert saved['whole_reference_diagonal']==[] and saved['disposition']=='NEW_SELECTED_WHOLE_REFERENCE_DIAGONAL_ZERO'
  if raw['state']=='F0' and raw['family']=='preference':assert raw['free_proof']['whole_free_zero'] and saved['disposition']=='WHOLE_FREE_F0_ZERO_BEFORE_ORDINARY_INSERTIONS'
  checked+=len(rr)
 del old;gc.collect();whole=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/native_whole_inventory.json.gz')
 for saved,raw in zip(cat['ordinary_subset_provenance'],whole['projections']['source']):
  assert saved['raw_vertex_math_sha256']==raw['raw_mathematical_sha256'] and saved['raw_vertex_terms']==raw['raw_word_count']
  actual=[x for x in raw['groups'] if x['signature'][1]=='ordinary' and all(a<=b for a,b in zip(x['signature'][5],[0,0,1,1]))];bad=[x for x in raw['groups'] if x['signature'][1]=='ordinary' and not all(a<=b for a,b in zip(x['signature'][5],[0,0,1,1]))]
  assert saved['retained_groups']==actual and saved['rejected_groups']==bad
 del whole;gc.collect();assert [len(x['complete_cycles']) for x in cat['cases']]==[0,0,4]
 for case in cat['cases']:
  assert case['arbitrary_scalar_zeroarity_chains_nonreturn'] and not case['scalar_reduced_cycles']
  for rid,ro,path in case['complete_cycles']:
   used=[cat['classes'][i] for i in [rid]+[j for j,o in path]];assert sum(x['g'] for x in used)==1 and sum(x['u'] for x in used)==case['u'] and [sum(x['external'][k] for x in used) for k in range(4)]==[0,0,1,1] and len(used)<=5
 assert cat['cases'][2]['root_counts']=={'R_F1':4} and cat['cases'][2]['active_quantum_types']==['CM','aM']
 co=load(O/'coefficient_tables.json.gz');ref=load(O/'proper_reference.json.gz');an=read(O/'analytic_result.json');assert read(O/'coefficient_result.json')['artifact_sha256']==digest(O/'coefficient_tables.json.gz') and an['artifact_sha256']==digest(O/'proper_reference.json.gz')
 D={c:A.decode_matrix(v) for c,v in co['matrices']['D']};AA={c:A.decode_matrix(v) for c,v in co['matrices']['A']};NN=[{c:A.decode_matrix(v) for c,v in row} for row in co['matrices']['N']]
 nz=0
 for col,r in zip(co['all4050_colors'],ref['source_color_rows']):
  pr,c,src=col['probe'],col['C'],col['Ja'];assert [pr,c,src]==[r['probe'],r['C'],r['Ja']]
  T=A.pairtrace(A.add(D[c],AA[c],-1),NN[pr][src]);assert T==A.decode_coeff(col['T_D_minus_A']);v=J.times(T,J.constant(F(3,8)));nz+=bool(v)
  assert A.decode_coeff(r['proper_QGamma_p2'])==v and A.decode_coeff(r['raw_regulator_p2'])==v and A.decode_coeff(r['covariance_current_p2'])==-v and A.decode_coeff(r['proper_power_1_over_t'])==J.times(T,J.constant(F(1,2)))
  assert not col['wrong_D_plus_A_difference'] and not col['omit_A_difference']
 assert nz==57 and co['all_four_root_laplacian_components_verified']
 fx=co['literal_model_coefficient_fixture'];dec=lambda p:{(u,mask):A.decode_coeff(c) for u,mask,c in p}
 assert m.mul(dec(fx['partition']),dec(fx['partition_inverse']))=={(0,0):J.constant(1)}
 for row in fx['branches'].values():
  assert not m.plus(dec(row['CQ']),dec(row['CR']),m.scale(dec(row['Jac']),J.constant(-1))) and A.decode_coeff(row['CQ_u'])==-A.decode_coeff(row['CR_u'])
 assert any(r['CQ_u'] and r['CQ_u']!=r['wrong_plus_trace_CQ_u'] for r in fx['branches'].values())
 late=read(O/'late_tensor_result.json');assert len(late['all4050_residuals'])==4050 and all(not a and not b for pr,c,ss,a,b in late['all4050_residuals'])
 audit=an['source_trace_label_audit'];assert audit['correct_actual_LEFT_current']=='-238*I/2025' and audit['correct_raw_regulator']=='238*I/2025' and audit['old_named_current_minus_actual']=='476*I/2025'
 assert an['proper_p2_multiplier']=='3/8' and an['independent_UV_moment']=='3/8' and max(float(z['absolute_error']) for z in an['Schwinger_quadrature'])<1e-45
 vector=(R/'calculations/canonical_so10_vector_expanded_regulator_reconciliation_g1_v1/analytic.py').read_bytes().decode('utf-8');tree=ast.parse(vector);mainnode=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');functions={n.name:ast.get_source_segment(vector,n) for n in mainnode.body if isinstance(n,ast.FunctionDef)}
 assert 'hp.T' in functions['direct'] and '-sum(' in functions['regulated'] and 'R.T' in functions['regulated'] and 'analytic_result_v2' not in vector
 print('STAGE allnewrootprojections_ordinaryprovenance_fourcycles_4050colors_literalWicksign_heat_IR_tensor_and_scoped_oldlabel_correction_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 oldtree=(C/'old_git_tree.txt').read_bytes();assert oldtree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V806.md'];size=sum(p.stat().st_size for p in files);assert size<64*1024**2
 out=dict(schema='ACTUAL_JAC_G1_COMPANION_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_JAC_G1_FINITE_PROPER_COMPANION_WITH_SCOPED_TRACE_SIGN_CORRECTION',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'catalog_preparation.json')['base_HEAD'],state_sha256=state,catalog_pairs_byte_equal=True,raw_root_rows_checked=checked,returning_cycles=dict(original=0,H=0,M=4),proper_color_slots=4050,proper_nonzero_M=57,proper_reference_multiplier='3/8',retained_power_multiplier='1/(2t)',proper_equals_raw_regulator_opposite_covariance_current=True,literal_actual_model_coefficient_sign_check=True,whole_IR_UV_proofs_written_not_formal_kernel_certified=True,lower_Q_plus_xi_T_and_T_symmetry_verified=True,prior_V798_compact_current_label='CONTRADICTED_FOR_LITERAL_CQ_OLD_BYTES_PRESERVED',prior_V793_current_minus_raw_regulator_convention_retained=True,prior_vector_interface_static_check_only_not_loop_replay=True,unknown_remaining_companions_not_assigned=True,failures_this_increment=0,worker_seconds_after_imports=seconds,largest_private_sample=max(x['private_bytes'] for cap in caps.values() for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(oldtree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
