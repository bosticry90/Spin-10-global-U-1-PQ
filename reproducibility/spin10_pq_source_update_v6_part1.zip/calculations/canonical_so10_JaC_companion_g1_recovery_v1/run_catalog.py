from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JaC-companion-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
role=sys.argv[1];assert role in ['native','replay'];assert not (O/(role+'_catalog_capture.json')).exists()
if not (O/'catalog_preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='cba51d54e6c4b8ff52a53887d0af72dadefe204e'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V805.md']
 for folder,files in [('canonical_so10_regulator_vertices_g1_recovery_v1',['validation_receipt.json','roots.py','PROOF.md','native_root_assemblies.json.gz','replay_root_assemblies.json.gz']),('canonical_so10_full_current_inventory_g1_recovery_v1',['validation_receipt.json','native_whole_inventory.json.gz','replay_whole_inventory.json.gz']),('canonical_so10_same_parent_slavnov_g1_recovery_v1',['validation_receipt.json','pairing_result_v4.json']),('canonical_so10_g1_consistency_companion_carriers_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_proper_slavnov_actual_operators_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_proper_normalization_transfer_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_gaussian_current_reduction_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1',['inventory.py']),('canonical_so10_chiral_probe_support',['validation_receipt.json','DERIVATION.md'])]:names+=['calculations/'+folder+'/'+n for n in files]
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 for n in ['RECORD.md','catalog.py','run_catalog.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'catalog_preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'catalog.py'),role]);dump(O/(role+'_catalog_capture.json'),cap);dump(C/(role+'_catalog_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
