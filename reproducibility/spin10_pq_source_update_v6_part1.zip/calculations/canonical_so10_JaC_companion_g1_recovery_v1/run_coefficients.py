from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JaC-companion-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'coefficient_preparation.json').exists()
assert (O/'native_catalog.json.gz').read_bytes()==(O/'replay_catalog.json.gz').read_bytes()
names=[]
for role in ['native','replay']:
 p=R/('calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/'+role+'_inputs.json.gz');q=R/('calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_GF_common.json.gz')
 for z in [p,q]:assert z.read_bytes()==subprocess.check_output(['git','show','HEAD:'+z.relative_to(R).as_posix()],cwd=R);names.append(z.relative_to(R).as_posix())
 states=load(p)['states'];common=load(q)
 packet={k:states[k] for k in ['F1','Eu0_0','Eu0_1']};packet['U0_ordinary']=common['probe_ordinary'];packet['only_classical_operands_no_old_current_member']=True
 blob=gzip.compress((json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/('coefficient_'+role+'_inputs.json.gz')).open('xb') as h:h.write(blob)
for n in ['COEFFICIENT_RECORD.md','coefficients.py','run_coefficients.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'coefficient_preparation.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},new_catalogs_and_classical_packets_frozen_before_colors=True,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'coefficients.py')]);dump(O/'coefficient_capture.json',cap);dump(C/'coefficient_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
