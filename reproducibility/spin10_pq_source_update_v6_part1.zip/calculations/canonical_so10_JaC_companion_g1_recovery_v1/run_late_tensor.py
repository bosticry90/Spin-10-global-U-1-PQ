from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/JaC-companion-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'late_tensor_preparation.json').exists()
name='calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/kinetic_tables.json.gz';assert (R/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name],cwd=R)
for n in ['LATE_TENSOR_RECORD.md','late_tensor.py','run_late_tensor.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'late_tensor_preparation.json',dict(sha256={name:digest(R/name),**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'late_tensor.py')]);dump(O/'late_tensor_capture.json',cap);dump(C/'late_tensor_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
