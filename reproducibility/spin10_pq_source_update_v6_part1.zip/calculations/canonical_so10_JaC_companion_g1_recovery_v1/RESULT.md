# The two-derivative Ja-C proper companion is measured

The new first-u,g1 M coefficient has57 nonzero color entries. In the
original Euclidean convention, with overall g10*u/(16pi2), it is

    proper QGamma_JaC = T_cs Ja_s C_c B_F(p),
    T_cs=Tr[(D_c-A_c)N_s],
    FP_UV_then_IR = (3/8) T_cs Ja_s C_c p2.

Its derived power term is T/(2t), retained before the qualified common
power subtraction. At Ja12,C12 the finite p2 coefficient is6xi; no width
or coupling value was assigned. All nonzero Ja/C indices are M. All4050
H/M color slots and every zero are retained. Original unprobed g1 and
H-probe coefficients vanish at finite profiles by their complete catalogs.
This is distinct from the previously measured zero JaLambdaC reference.

Native DFS and replay bags/all orders agree on the entire new catalog.
There are four M root orientations, only original F1 ghosts and one U0
Ja mass. All six full root states, physical ordinary owners, source
quadratics and zeroarity inverse responses were retained before support
elimination. Scalar chains cannot return at any length by the explicit
chain-erasure argument. Both catalogs took13.453/13.517s under180s.

Actual raw-root extraction and LEFT F1 differentiation give the same D/A;
actual ordinary Hessian and full source Euler give the same N. All four
root Laplacian components are checked. The4.664s coefficient worker
verifies both opposite-root placements and all color contractions. On
this two-index table Tr(A N)=0: omission of A or D+A versus D-A is blind,
and is not presented as an amplitude-sensitive control.

Literal normalized Grassmann integration with actual model coefficients
fixes C_Q=-T B_F, raw C_R=+T B_F, and proper QGamma=+T B_F. Sign and
extra-half errors change every nonzero proper reference. Exact Schwinger
integration, an independent Gaussian moment and direct quadrature give
the3/8 multiplier. A polynomial Schwartz majorant controls UV finite
part; |B_F-B_E|<=4delta2 in16pi2 units uniformly in t,p controls the
whole IR difference. The1.475s analytic worker retains the full finite
kernel, power term and pure-IR bound, not a pointwise root limit.

A late review independently finds the polynomial relation Q+xi*T=0 and
T=T^T in all4050 positions, with Q the qualified lower g0 kinetic tensor.
No inverse gauge width/coupling or fitted factor is used. This tensor
correlation does not select H,K,T normalization matrices or prove the
whole consistency equation. Its0.0825s review saves all residuals.

The same literal check identifies an older source compact-trace semantic
error: V798's named current fixture +238i/2025 is the raw-regulator sign;
the literal LEFT current is-238i/2025. Its literal polynomial comparison
and true Dyson matrix identities are unchanged; the old sources/receipts
remain unedited. V793 already distinguishes current=-raw regulator, and
its zero ordered source reference is unchanged. V799's vector interface
retains the full Hessian transpose and explicit negative raw regulator;
this specific source compact-sign substitution does not occur there.
That static interface review is not a fresh vector-loop replay. See
PROOF for the exact affected interpretation and limits.

No worker or preparer failed this increment. The older semantic error
illustrates a shared-error limit that symbolic agreement alone missed.
Final validation owns complete projections/ports/raw provenance, catalogs,
literal sign, masters/tensor relations/controls/resources, unchanged
oldtree/state and E4once-no-fresh with custodyexit2/seven unresolved NOTPASS.
Shared action/chart/ring/analytic assumptions/AI author remain; no outside
scientist, proof kernel or experiment is claimed.

This measures one required source companion. Next form the actual known
portions of LambdaCC consistency: Q0 of the measured vector and this
JaC coefficient, and Q1 of V804's lower unmarked coefficient. Keep all
source operations before restriction and all unprobed/higher-source
unknowns explicit. The remaining aCC/JBCC/JLambdaCC quantum companions
are not fitted or set zero. Full normalization/reality/background/product/
QAP/measure/equivalence/E5/A5/viability/investigation remain open. Authority
stays113/34of39; protected boundaries and main preserved; no remote action.
