from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('JaC_late_tensor_coeffs',O/'coefficients.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=m.read;load=m.load;digest=m.digest;A=m.A;J=m.J
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'late_tensor_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 actual=load(O/'coefficient_tables.json.gz');old=load(O.parent/'canonical_so10_absolute_marked_quantum_g0_recovery_v1/kinetic_tables.json.gz');xi=J.Coeff([((0,1,0,0),F(1))]);rows=[];counts=[]
 for pr in [0,1]:
  T={(r['Ja'],r['C']):A.decode_coeff(r['T_D_minus_A']) for r in actual['all4050_colors'] if r['probe']==pr};Q=A.decode_matrix(old['cases'][pr]['Q_matrix']);nz=sym=0
  for a in range(45):
   for b in range(45):
    rel=Q.get((a,b),J.ZERO)+J.times(xi,T[a,b]);skew=T[a,b]-T[b,a];nz+=bool(rel);sym+=bool(skew);rows.append([pr,a,b,A.encode_coeff(rel),A.encode_coeff(skew)])
  counts.append(dict(probe=pr,Q_plus_xi_T_nonzero=nz,T_minus_transpose_nonzero=sym))
 out=dict(schema='JAC_LOWER_KINETIC_POLYNOMIAL_TENSOR_REVIEW_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all4050_residuals=rows,counts=counts,polynomial_no_division_by_width_or_coupling=True,no_normalization_adopted=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'late_tensor_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='all4050_residuals'},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
