# The Ja-C proper companion is nonzero at first-u,g1

The domain is original unshifted EuclideanA0,intrinsic01,constant u,
source-first operations and independently Schwartz Ja,C, with overall
g10*u/(16pi2) suppressed where indicated. This is a new carrier with
two derivatives, not the earlier zero JaLambdaC ordered reference.

## Complete returning support at the changed budget

Both new catalog routes agree byte-for-byte. Every V792 raw root is
reprojected to (B,Lambda,C,Ja) budget(0,0,1,1), retaining all source
coordinates and both independent quantum halves before selection. All
F0/F1/Fu0/Fu1 and Pref/reference families receive full dispositions.
F0's whole free quadratic is zero before any ordinary inverse response;
no individual F0 term is discarded. The new selected reference diagonal
vanishes as a whole. The old ordinary upper source budget contains the
new one, so refiltering its full source-first signatures is safe: a
forbidden mean cannot be repaired by contracting the remaining quantum
ends. Raw vertex hashes and original monomial-index provenance remain.

All original and H catalogs are empty. M has four labelled root/edge
orientations: the two original F1 ghost roots and the single U0 Ja
ghost mass. No other flow, inverse-U quadratic or physical owner returns.
Both native DFS and replay bags/all orders/halfedges use a proved
five-total-vertex bound, not an assumed two-edge answer. H/M edge mixing
creates spurious paths; a false free LL edge is blind on the actual M
four-word set. The complete wrong/omission lists are retained.

The reduced catalogs have no scalar cycle. Erasing any number of
zero-arity scalar reference/potential insertions preserves its same-sector
connectivity, external means and g/u cost. Such chains therefore cannot
create a missing scalar cycle, at any length. This excludes their return
without truncating an arbitrary g0 mass series. Physical g1 cubic
Hessians leave forbidden B/x means in this budget. Matter and its BV
source are not set zero before differentiation: no Ja-dependent fermion
block or admissible mixed mean supplies a returning Ja cycle here. The
hatted trace is Ja/u independent in the permitted stable ideal, so it
has zero selected coefficient, not a global chiral/measure zero.

## Actual root, ordinary and color reconstruction

Native extracts D_c,A_c from the newly retained complete polarized F1
root, separately checking all four l_mu2 monomials and their original
minus/plus ghost-inverse entries. Replay derives the same matrices by
LEFT derivatives of full F1. Native derives N_s from the U0 quadratic
Taylor half; replay from source-first Eu0_a. All45 internal colors are
retained before the catalog's M restriction. Complete matrices agree.
The actual field/Euler pairing is V800's completed one; no old incomplete
source QJ map or guessed contact is used.

In the actual convention P_C=D_c C_c etaC and P_a=A_c C_c etaa, while
the physical ghost action is a H C, H=K+u Ja N. Its LEFT Euler columns
are -H^T a and H C. Ordered covariances are G_Ca=G and G_aC=-G^T.
Consequently the literal covariance current is

    C_Q=-Tr[D C G H]-Tr[A^T C H G].

The one-source inverse coefficient G_N=-G0 N G0 obeys
G_N K+G0 N=-G_N R and K G_N+N G0=-R G_N. Thus the Ja coefficient is
the negative of the raw regulator contraction, as required by the
actual zero-Jacobian Gaussian identity. No manual ghost-loop sign or
extra half is inserted. With one skew N, full opposite-root transposition
gives

    T_cs=Tr[D_c N_s]+Tr[A_c^T N_s]=Tr[(D_c-A_c)N_s],
    C_Q=-T B_F, C_R=+T B_F.

Native trace and independent explicit index contractions agree in all4050
H/M positions. There are57 nonzero M entries and zero H. On this particular
two-index table Tr(A N)=0 everywhere: D+A and omission of A are BLIND
controls despite their generally incorrect operator interpretation.
All four root orientations and the full raw A contribution were retained
before the color cancellation. No such zero is transferred to three-point
or other source targets.

A literal normalized two-pair Grassmann integral uses actual nonzero
model D/A/N entries, an external odd mean C and a nilpotent even source
insertion. The full action, regulator, exponential, partition/inverse,
all16 ordered covariances and both branch observables are saved. Each
branch satisfies C_Q+C_R=Jac; its nonzero current coefficient matches the
minus trace above and rejects the plus trace. These finite K/F assignments
test algebra, not physical gauge/coupling parameters or a benchmark.

## The new scalar master and ordered distributional reference

The root-adjacent regulated inverse cancels its own free inverse only,
leaving

    B_F(p)=integral d4q/(2pi)^4 (1-F_q) F_(q+p)/(q+p)^2,
    F=fE, E=exp(-tq2), f=(1-exp(-q2/delta2))^2.

At f=1, exact Schwinger integration gives, in16pi2-normalized units,

    B_E=1/t-[exp(-tp2/2)-exp(-tp2)]/(t2 p2)
       =1/(2t)+3p2/8-7t p4/48+O(t2 p6).

The independently integrated Gaussian Taylor moment is3/8. Four direct
Schwinger quadratures at nonzero p2 agree with the exact kernel below
1e-45; these are mathematical momentum checks, not fitted physical points.
The derived power coefficient1/(2t) is retained and subtracted by the
existing common heat finite-part rule, not by a new finite normalization.

For all Euclidean p and t>0,

    B_E-1/(2t)=(1/(2t)) integral_0^1
                      [1-exp(-tp2(1-v/2))] dv,
    0<=B_E-1/(2t)<=3p2/8,
    |B_E-1/(2t)-3p2/8|<=7t p4/48.

This polynomial majorant proves the UV finite part on the common
independent-source Schwartz pairing, with momentum conservation retained.
It is not a pointwise argument used in place of the integral.

At finite delta, compare the WHOLE B_F and B_E integrands. Since
1-f_q<=2 exp(-q2/delta2), their absolute difference is bounded by
2 exp(-q2/delta2)/|q+p|2+2 exp(-|q+p|2/delta2)/|q+p|2.
The Gaussian/Riesz convolution is at most pi2 delta2 uniformly in p.
Hence, in16pi2 units, |B_F-B_E|<=4 delta2 uniformly in t,p. Each
difference has a dominated UV limit, and this same bound then removes
it in the IR reference. No power subtraction changes, no residual delta
contact survives the uniform bound, and no standalone inverse-heat map
or unrestricted interchange of limits is assumed.

V802's actual upper-budget KQ/KD/master IBP identity restricts to JaC
because field counts commute with ordinary derivatives and IBP. V803 fixes
the same proper determinant normalization. With the scoped hatted support,
QGamma=-C_Q=C_R, so the actual ordered reference is

    [QGamma1]_g,u,JaC = +(3/8) T_cs Ja_s C_c p2/(16pi2).

All4050 coefficients, their power terms and sign/half controls are saved.
The unprobed coefficient is zero at finite profiles by its empty complete
catalog. H is likewise zero. A simultaneous overall sign or extra half
changes all57 nonzero proper reference entries. Omitting a marked mass
root changes the full finite kernel/power terms but can be blind to p2
after subtraction; the evidence does not call that a sensitive finite-
reference control.

## Scoped correction to the older compact source-trace label

The literal model check exposes the missing minus from transposing the
ghost Euler column in V798's displayed compact current formula. Its
actual literal polynomial comparison remains unchanged. Its Dyson matrix
identities are true, but the named coordinate-fixture C_Q evaluates the
raw regulator sign. Reconstructing the SAME fixed12-coordinate inputs
gives actual C_Q=-238i/2025 and C_R=+238i/2025. The old named current was
+238i/2025; the discrepancy is476i/2025. The old analytic fixture therefore
does not verify the literal C_Q meaning it claimed. Original sources,+proofs, numbers, captures and receipts remain unedited; this later review
qualifies the affected interpretation rather than relabelling history.

V793 already explicitly uses current=-raw regulator and its ordered
source color/kernel convention is retained. The JaLambdaC ordered
reference remains zero, but that zero alone could never validate a finite
sign. The new JaC result uses the fresh literal sign check instead of
the V798 trace label. No unrelated vector amplitude is flipped. V799's
full-vector matrix interface retains H^T and an explicit negative raw
regulator contraction, unlike the source compact formula; any static
dependency check of that fact is not a fresh replay of its vector loops.

## Meaning and next scientific action

One of V805's distinct missing source companions is now measured. Its
nonzero value can enter LambdaCC consistency through the nonlinear QJa
term. It neither forces an anomaly nor supplies the other aCC/JBCC/
JLambdaCC quantum coefficients. The common kinetic plane of V804 stays
symbolic/unadopted; no coefficient is fitted to rescue restoration.
Next derive the actual contribution of this JaC term and the known lower
coefficient to the complete consistency equation, then select the still
missing source/antighost companions by their actual operator images.

Shared action/chart/ring, inherited proper/domain identities and AI author
limit independence. The older compact-trace semantic error is an actual
AI capability limitation caught by a literal actual-coefficient check;
agreement between two symbolic trace expressions did not validate their
physical meaning. No independent scientist, proof kernel or experiment.
Full QAP/measure/phase/equivalence/E5/A5/viability and the investigation
remain open, with project_state.json the sole scientific authority.
