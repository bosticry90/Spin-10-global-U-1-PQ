# Ordered phases of the four all-mixed charged paths

Use V1095 rows 24,31,104,111, with the H B B
closing line and three charged B Lambda or
Lambda B lines. Follow G,U,V,F. Strip only the
common determinant, inverse chart convention
and overall stored minus. In Fourier convention
exp(i p.(x_left-x_right)) the mixed signs are
minus for B Lambda and plus for Lambda B.
Reversing the ordered type together with the
momentum arrow gives the same inverse factor.

The literal mixed spectator at Y gives -i j J
in B Lambda order and its transpose in Lambda
B order, for charge-normalized skew J. The
signed mixed edge product times this Y factor
is +i j in each row. The 334 matching LEFT
source and ordinary B B Lambda endpoint pairs
are f_(h,c,u) and i f_(h,b,u). Relative to
E_h(z)_u=f_(h,u,z) their signs are -1 and
-i. The master derivative acts at the left
charged end for the first two rows and the
right charged end for the last two. This
gives +p,+p,-p,-p on the common ray. Bringing
the exterior odd fields into (C_X,C_master,a_X)
order supplies one minus in every row.

The product gives (+,+,-,-) for the path
matrices (J T,T J,J T,T J). The first two
rows put E(C) at the left and E(B) at the right.
The other two rows use the reverse endpoints.
T is the symmetric ordinary quartic matrix.
With the symmetric H and L projectors,
transposition maps the first two rows to the
B-left representation, reversing the J sign.
The signed row list relative to the raw rotate-B
and rotate-C projections F,G of V1095 is
(-G,F,F,-G). The two charts also give this
comparison by direct sew of the literal matrices.

With the conditional W_LL representative,
the common sum is (0,19/1670,-209/20040) per
charge. The strict hard metric multiplies it
by eta_H/4. Thus the two nonblind rows are
nonzero in the ordered common-clock fixture.
The raw rotate-B and rotate-C opposition
cannot be used to infer their cancellation.

Independent transfer must precede the strict
projection. With H momentum k directed F to
G, the master vectors are k+P_G or -k+P_F.
The contraction with the H inverse keeps
P_G or P_F times that inverse. These transfer
terms can survive a transverse H control away
from the unjetted plateau. A whole derivative
must retain its exterior and switch pieces.

For the log-degree hard metric of this ordinary
four-edge word, the common profile length is
3 ell_L+ell_H. Comparing two matched positive
length choices shifts the Euclidean finite
part by the negative log of the length ratio
times the hard coefficient in dQ/(16 pi^2)
units. This follows from the V976 relative
formula at maximum unheated degree -4. There
is no positive transfer heat jet at this
degree for the ordinary unsplit word. It is
distinct from differentiating a cutoff line
or collapsing an Euler operand.

This is the signed hard slice of four actual
paths. The complete proper, source and marked
sum must carry other classes, full profile
attachments, local normalization and the
common chart factors. No such total follows.
