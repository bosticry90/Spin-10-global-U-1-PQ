"""Check ordered phases and the relative hard profile of four mixed paths."""
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"
r = sp.Rational


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def phases():
    inv = {("B","l"):-1,("l","B"):1}
    owner = json.loads((C/"canonical_so10_YY_charged_four_cycle_inventory_v2/result.json").read_bytes())["checks"]
    rows = owner["ordered_field_support"]
    values = []
    for i in (24,31,104,111):
        row = rows[i]
        G,U,V,F = row
        end = 0 if G["type"]=="master_mixed" else 3
        assert row[end]["type"]=="master_mixed"
        Y = next(v for v in (U,V) if v["type"]=="ordinary_mixed")
        edges = [(a["ports"][1],b["ports"][0]) for a,b in zip(row,row[1:])]
        edge_sign = sp.prod(inv[e] for e in edges)
        flipped = [(b,a) for a,b in reversed(edges)]
        assert sp.prod(-inv[e] for e in flipped)==edge_sign
        y_phase = sp.I*inv[tuple(Y["ports"])]
        derivative = 1 if end==0 else -1
        base = ("m","x","a") if end==0 else ("x","a","m")
        target = [base.index(k) for k in ("x","m","a")]
        parity = (-1)**sum(a>b for j,a in enumerate(target) for b in target[j+1:])
        assert parity==-1
        z = sp.prod((edge_sign,y_phase,derivative,parity,-1,-sp.I))
        values.append(int(z))
    assert values==[1,1,-1,-1]
    return values


def colors(phase,signs):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    owners = load("charged_mixed_master_companions_v1","yy_charged_mixed_master_companions")
    spectator = load("reference_spectator_agreement_v2","yy_reference_spectator_agreement")
    f,P,S,Q,h,j,modes,flat = two.inputs(phase)
    assert owners.literal_endpoints(phase,flat,f)==334
    assert spectator.literal_ports(phase)[0]==[12,12,12]
    H,M = flat.ideal.H,flat.ideal.M
    L = S[3]
    J = sp.zeros(33)
    for i,z in h.items():
        for k in M:
            for b,v in f[i,k]:
                J[b-12,k-12] += z*v/j
    J = (L*J*L).applyfunc(sp.simplify)
    assert J.T==-J and J*L==J
    W = sp.Matrix(flat.family.representative()[0][3,3])
    W += sp.Matrix(flat.family.direction()[0][3,3])/1002

    def center(c,a):
        T = flat.images.matrix({
            (u-12,v-12):sum(z*t*Q[u,v,b,d] for b,z in c.items() for d,t in a.items())
            for u,v in product(M,repeat=2)})
        assert T.T==T
        return T

    def sew(T,F,G):
        if phase=="native":
            return flat.trace(P,S,T,F,G,3,3)
        X = {h:L*F[h] for h in H}
        Y = {h:T*L*G[h] for h in H}
        return sp.Matrix([sp.expand(sum(P[i][h,k]*sum(X[h][l]*Y[k][l] for l in range(33))
                             for h,k in product(H,repeat=2) if P[i][h,k]))
                          for i in flat.ideal.spectra])

    c,d,e,v = modes
    d3 = {27:r(1,2),32:-r(1,2)}
    d4 = {28:r(1,2),31:r(1,2)}
    assert J*flat.vec(d3)==flat.vec(d4)
    old = json.loads((C/"canonical_so10_YY_H_mixed_support_v1/result.json").read_bytes())["checks"]
    old_rows = old["all_mixed_ordinary_raw_weighted_per_j"]
    ordered = []
    for b,c1,c2,a in ((d,c,d,d),(c,c,e,v),(c,c,d3,d4)):
        ideal = [sp.zeros(3,1) for _ in signs]
        for cx,ce,s in ((c1,c2,1),(c2,c1,-1)):
            T = center(cx,a)
            F,G = flat.ordinary_end(f,b),flat.ordinary_end(f,ce)
            matrices = (J*T,T*J,J*T,T*J)
            operands = ((G,F),(G,F),(F,G),(F,G))
            for i,(z,K,(left,right)) in enumerate(zip(signs,matrices,operands)):
                ideal[i] += z*s*sew(K,left,right)
        row = [sp.simplify(v.dot(W)) for v in ideal]
        F,G = map(r,old_rows[len(ordered)])
        assert row==[-G,F,F,-G]
        ordered.append(row)
    return ordered


def transfers():
    k = sp.Matrix([2,1,-3,5])
    P_F = sp.Matrix([1,4,0,0])
    P_G = sp.Matrix([0,-1,5,1])
    B = sp.Matrix([0,0,1,2])
    h,eta = sp.symbols("h_H eta_H")
    Q = k.dot(k)
    C_H = h*(sp.eye(4)+(eta-1)*k*k.T/Q)/Q
    for sign,P in ((1,P_G),(-1,P_F)):
        d = sign*k+P
        raw = (d.T*C_H*B)[0]
        split = sign*h*eta*k.dot(B)/Q+(P.T*C_H*B)[0]
        assert sp.expand(raw-split)==0
        assert sp.expand(raw.subs(eta,0)) != 0
    return True


def check(phase):
    signs = phases()
    rows = colors(phase,signs)
    totals = list(map(sum,rows))
    eta = sp.symbols("eta_H")
    return {"signed_row_phase":signs,
            "signed_rows_per_j":[list(map(str,row)) for row in rows],
            "signed_sum_per_j_before_angular":list(map(str,totals)),
            "angular_sum_per_j":[str(eta*x/4) for x in totals],
            "master_transfer_remainders_checked":transfers()}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
