# V1098 execution contract

Question. Do the four V1095 all-mixed charged
paths cancel when ordered Wick and endpoint
phases are retained?

Inputs. V1089 ordered paths, V1095 raw colors,
V1061 literal spectator, V1086 endpoint and
phase conventions, V976 relative profiles.

Test. Compare relative phases and direct
weighted contractions in both charts. Keep
independent master transfers in an exact
control. Report the common-ray hard slice
with explicit exterior orientation and
remaining common factors.

Bounds. 120 s native and 180 s replay with E4 caps.
No new loop integration, complete proper sum
or finite normalization adoption.
