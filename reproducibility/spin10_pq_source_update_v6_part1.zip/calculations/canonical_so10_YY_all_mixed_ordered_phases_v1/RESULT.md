# Ordered hard slice of the all-mixed paths

The four paths have signed raw projections
(-G,F,F,-G) in V1095's two-cut notation.
All four add in the two nonblind fixtures.
Their signed common-clock sum per charge
before the hard metric is
(0,19/1670,-209/20040).

Multiplying by eta_H/4 gives
(0,19 eta_H/6680,-209 eta_H/80160)
before the common outer convention. The
retained transfer derivative survives a
transverse H control off the unjetted
projection. This is a hard contribution,
with the other coupled paths and finite
normalizations still required.
