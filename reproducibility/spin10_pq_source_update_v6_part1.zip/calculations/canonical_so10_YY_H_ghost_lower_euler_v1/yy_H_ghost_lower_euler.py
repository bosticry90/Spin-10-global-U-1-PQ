"""Check the compact lower H Euler, ghost and decorated T2 transport."""
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"


def transfers(phase):
    a,b = sp.symbols("a b")
    u = sp.Matrix([2,0,0,0])
    if phase=="native":
        F,G = sp.Matrix([0,1,0,0]),sp.Matrix([1,1,1,0])
    else:
        F,G = sp.Matrix([1,0,0,1]),sp.Matrix([0,1,1,1])
    v,w = u+a*F,u+a*F+b*G
    Q,V,W = u.dot(u),v.dot(v),w.dot(w)
    T = sp.eye(4)-u*u.T/Q
    Lh = v*v.T/V
    H = sp.Function("h_L")(Q)*sp.Function("h_H")(V)*sp.Function("h_L")(W)
    mixed = H*T*Lh*w/(Q*W)
    maxwell = H*T*(sp.eye(4)-Lh)*w/(Q*W)
    ghost = -H*T*v/(Q*V)
    complete = H*T*w/(Q*W)

    def assert_zero(A):
        assert A.applyfunc(sp.cancel)==sp.zeros(4,1)

    assert_zero(mixed+maxwell-complete)
    assert_zero(mixed+ghost+H*T*(v-u)*(w-v).dot(w)/(Q*V*W))
    assert_zero(maxwell.subs(b,0))
    assert_zero(mixed.subs(a,0))
    assert_zero((mixed+ghost).subs(b,0))
    diff = (mixed+ghost).subs({a:1,b:1}).applyfunc(sp.simplify)
    assert diff!=sp.zeros(4,1)

    rows = [[1,0],[0,1],[-1,0],[1,1]]
    H0 = H.subs({a:0,b:0})
    for word,row in zip((mixed,maxwell,ghost,complete),rows):
        da = word.diff(a).subs({a:0,b:0})
        db = word.diff(b).subs({a:0,b:0})
        assert_zero(da-row[0]*H0*T*F/Q**2)
        assert_zero(db-row[1]*H0*T*G/Q**2)
    return rows


def normalization():
    lower = json.loads((C/"canonical_so10_YY_H_ghost_lower_transfer_v1/result.json").read_bytes())["checks"]
    kappa = sp.Rational(lower["required_lower_contact_per_raw_F_rotation"])
    assert kappa == -sp.Rational(15,8)
    # Variables (ghost, mixed, Maxwell) on the P_F direction.
    ordinary = sp.Matrix([[1,1,0],[0,1,1],[1,0,0]])
    solution = ordinary.inv()*sp.Matrix([0,0,kappa])
    assert solution==sp.Matrix([kappa,-kappa,kappa])
    extend = ordinary.col_join(sp.Matrix([[0,0,1]]))
    z = sp.Matrix([[1,-1,-1,1]])
    assert z*extend==sp.zeros(1,3)
    # Chosen sign of the witness pairs positively with -kappa.
    assert (z*sp.Matrix([0,0,kappa,0]))[0]==-kappa
    return [-1,1],list(map(int,z))


def check(phase):
    rows = transfers(phase)
    ratios,z = normalization()
    return {"ordered_first_transfer_rows":rows,
            "normalized_lower_H_partner_ratios":ratios,
            "fixed_standalone_Maxwell_left_witness":z,
            "independent_transfer_difference_nonzero":True}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
