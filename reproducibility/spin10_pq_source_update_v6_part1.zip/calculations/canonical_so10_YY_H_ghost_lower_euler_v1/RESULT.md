# Lower H Euler and ghost partners

With independent transfers the first hard
jets are P_F, P_G, -P_F and P_F+P_G for
H mixed, Maxwell, ghost and full H.
The mixed plus ghost difference survives
at second transfer order. Both profile
decorations remain attached.

Preserving the normalized H pair and
full H Euler at fixed lower requires
opposite mixed and equal Maxwell shifts
for a ghost P_F contact. The bare Maxwell
has zero P_F response at P_G=0. Holding
its separate normalized value excludes
that repair in the tested class.
