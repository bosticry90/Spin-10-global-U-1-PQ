# Compact H Euler and ghost transport of the lower product

Use the V1103 unsplit graph and its H mixed Q0
partner. Retain u,v,w independently. Write
H=h_L(u) h_H(v) h_L(w), T for the transverse
projector at u and L_v for the longitudinal
projector at v. Strip the common color and
phase with the H mixed contribution positive.
The regulated vectors are

    mixed   = H T L_v w/(u^2 w^2),
    Maxwell = H T (I-L_v) w/(u^2 w^2),
    ghost   = -H T v/(u^2 v^2),
    full H  = H T w/(u^2 w^2).

The mixed and Maxwell sum equals full H. The
mixed plus ghost difference is exactly
-H T P_F (P_G.w)/(u^2 v^2 w^2). It is nonzero
at independent transfers and has zero linear
hard jet. The literal G Laplacian retains
the exterior or switch derivative difference
against the balanced G expression.

The first hard jets in units H T/u^4 are
P_F, P_G, -P_F, P_F+P_G in the displayed order.
Every numerator is already first order, so
profile differentiation adds no first-order
term. The bare standalone Maxwell is exactly
zero at P_G=0. Mixed and ghost then coincide
with opposite signs.

The full H lower word is L B B and L ghost
with the removed H profile retained. The
literal G ghost lower word is L B B and H
ghost with the removed L profile retained.
Their transfers are P_F+P_G and P_F.
The base clocks are 2 ell_L and ell_L+ell_H,
respectively, and both decorated clocks are
2 ell_L+ell_H. The V1097 relative coefficient
is 3/4 times the log of the base to decorated
clock ratio for each transverse contraction.

Preserving normalized H Q0 pairing and full
H Euler at fixed lower, a ghost P_F shift g
requires H mixed h=-g and Maxwell m=g.
The Maxwell shift is a new P_F response of
a standalone operand with zero bare P_F
response at P_G=0. Preserving its separate
normalized value excludes the proposed repair.
The row witness (1,-1,-1,1) on Q0, full H,
ghost tag and Maxwell pairs with 15/8 in
the unit V1103 contact convention. Holding
normalized G ghost-Euler transport to its
fixed lower decorated bubble would also
prevent a change of g.

The fixed standalone relations are composite
premises. Bare identities and the inherited
T2 tensor leave the normalized local T3
relations to be established. A change of
composite normalization requires these
partners and the proper and marked tests.
