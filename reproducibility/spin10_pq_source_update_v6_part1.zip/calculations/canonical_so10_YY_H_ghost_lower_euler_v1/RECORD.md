# V1104 execution contract

Question. Which compact H partners does
the proposed lower ghost change require?

Inputs. V1103 lower graph, V1100 Q0 signs,
V1093 exchanged Euler and V1097 tensor.

Test. Compare the regulated mixed, Maxwell,
ghost and complete H vectors at independent
transfer. Derive the hard first jets and
fixed-lower row witness. Preserve both
profile decorations and exterior currents.

Bounds. 120 s native and 180 s replay with
E4 caps. No imposed composite premise,
new amplitude, or complete W3 result.
