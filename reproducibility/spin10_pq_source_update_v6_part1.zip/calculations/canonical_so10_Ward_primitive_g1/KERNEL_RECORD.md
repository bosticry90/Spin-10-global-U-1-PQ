# WPG connected integrand continuation

Support V2 completed8.949381s. Proper first-u,g1 words:6 unbroken,
16 broken, all lack a typed free-G cycle. Exact roots are retained;
this structural zero still needs separate review. G1 mixed mean forcing
has only B/Lambda outputs;296 affine scalar primitive terms are retained
but are linear-source responses. Reference g0 B tadpole has no cubic
return; all45 Lambda ghost traces vanish after their full off-diagonal
matrices were retained. Do not claim nonlinear means themselves zero.

Next compute the remaining actual first-u,g1 connected reference
integrand at every33x45x2 position. Use the full number-conserving ghost
quadratic form from original and probe densities AFTER selecting the
source coefficient. Substitute the proved complete g0 source means,
including both theta=rho*epsilon and Ja, their u variations, and the
direct primitive ghost root. Retain the g1 ghost seagull/source contacts,
derivatives on both ghosts and on background fields. A scalar background
or g1 mean correction is excluded only by the reviewed support/tadpole
argument; unexpected additional return invalidates completeness.

Use exact symbolic p=(P,0,0,0),q=(Q,R,0,0), the generic two-momentum
Euclidean plane. E_p stays symbolic. The bubble has both positive heats,
E_q E_(q+p)/(q2(q+p)2); retain both ordered responses, using only an
explicit heat-convergent momentum relabeling for their equality. Keep
the one-propagator ghost contact E_q/q2 separately. No inverse heat,
coupling fitting, chosen finite A or numerical cancellation is allowed.
If the integrand is nonzero, derive its reduction/UV/finite/IR status
before declaring a connected coefficient. All zero positions remain
explicit. Both local power terms and finite remnants must be retained.

Native180/review180s afterimports,8GiB sampled/350MiB launch/16MiB
packet unchanged. Keep all finite parent-A Legendre terms symbolic,
no kappa/b0/chi4 identification or full Ward/QAP/E5/physical claim.
