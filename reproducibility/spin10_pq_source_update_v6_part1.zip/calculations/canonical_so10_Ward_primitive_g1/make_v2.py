from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'support.py').read_text()
old="if len(w)==2 and 553<=w[0][0]<598 and w[1][0]==w[0][0]+45:\n            assert not w[0][1] and not w[1][1];diag-=c"
new="if len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643:\n            assert not w[0][1] and not w[1][1]\n            if w[1][0]==w[0][0]+45:diag-=c"
assert src.count(old)==1;src=src.replace(old,new).replace("O/'preparation.json'","O/'preparation_v2.json'").replace("O/'support_tables.json.gz'","O/'support_tables_v2.json.gz'").replace("O/'support_result.json'","O/'support_result_v2.json'")
with(O/'support_v2.py').open('xb') as f:f.write(src.encode())
