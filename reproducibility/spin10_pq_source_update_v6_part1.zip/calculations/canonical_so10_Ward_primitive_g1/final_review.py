from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import ast,gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-g1-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={}
for prep in O.glob('*preparation*.json'):
    for name,h in read(prep)['input_sha256'].items():
        assert digest(Path(name))==h,(prep.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'support_capture_v2.json':'support_v2.py','kernel_capture_v2.json':'kernel_v2.py','review_capture.json':'verify.py','e4_capture.json':None}
failed={'support_capture.json':('support.py','UNEXPECTED_G0_AUXILIARY_TADPOLE_RETURN'),'kernel_capture.json':('kernel.py',"unsupported operand type(s) for ** or pow(): 'Coeff' and 'int'")}
samples={};seen=set()
for p in O.glob('*capture*.json'):
    cap=read(p);seen.add(p.name)
    assert cap['launch']['creation_after_observation'] and cap['post_run_observations_qualified']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    if p.name in failed:
        worker,signature=failed[p.name]
        assert cap['exit_code']==1 and cap['execution_state']=='FAILED' and not cap['calculation_completed'] and signature in cap['stdout_and_stderr']
        assert cap['command'][-2:]==['-B',str(O/worker)]
    else:
        assert p.name in accepted and cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
        worker=accepted[p.name]
        assert cap['command'][-2:]==['-B',str(O/worker)] if worker else cap['command'][-3:]==['-B','tools/research_check.py','e4']
assert seen==set(accepted)|set(failed)
assert sorted(p.name for p in O.glob('*controller_failure*.json'))==['controller_failure.json','kernel_controller_failure.json']
v=read(O/'validation_receipt.json');n=read(O/'support_result_v2.json');k=read(O/'kernel_result_v2.json')
assert v['evidence_validation']=='PASS_ACTUAL_G1_REFERENCE_CONNECTED_PRIMITIVE_KERNEL'
assert [(p['complete_nonempty_marked_words'],p['typed_supported_words']) for p in n['probes']]==[(6,0),(16,0)]
assert n['K_g1_affine_output_positions']=={'x':296} and n['K_g1_BL_endpoint_outputs']==['B']
assert len(n['reference_g0_Lambda_tadpole_traces'])==45 and not any(z['ghost_trace'] for z in n['reference_g0_Lambda_tadpole_traces'])
assert n['table_sha256']==digest(O/'support_tables_v2.json.gz') and k['table_sha256']==digest(O/'kernel_tables_v2.json.gz')
assert k['complete_color_positions']==2970 and k['nonzero_bubble_positions']==57 and k['nonzero_contact_positions']==0
assert v['three_full4D_action_cases']==3 and v['color_positions_checked_per_case']==2970 and v['offdiagonal_ghost_positions_retained']==600
assert v['omitted_primitive_root_controls_sensitive']==57 and v['omitted_changed_means_controls_sensitive']==57
assert v['mixed_mean_not_assigned_zero'] and v['unknown_scalar_tadpole_not_assigned_zero'] and v['reference_UV_FP_then_IR_zero']
assert not v['physical_finite_delta_Ward_identity_claim'] and not v['full_Ward_QAP_E5_physical_claim']
assert all(z['elapsed_after_imports']<180 for z in [v,n,k])
rows=load(O/'kernel_tables_v2.json.gz')['complete_color_table'];assert len(rows)==2970 and len({(r['probe'],r['epsilon'],r['Ja']) for r in rows})==2970
for r in rows:
    assert not r['connected_contact_numerator']
    poly=r['connected_bubble_numerator']
    if poly:
        assert r['probe']==1 and [key for key,c in poly]==[[1,0,0,0],[2,0,0,0],[3,0,0,0]]
        coeff=lambda cells:{tuple(key):F(a,b) for key,a,b in cells}
        a,b,c=[coeff(cells) for key,cells in poly];assert a==c and b=={key:-2*z for key,z in a.items()}
text=(O/'PROOF.md').read_text();assert 'FIRST actual exception' in text and 'mixed mean itself has NOT' in text
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
events=read(O/'e4_events.json');steps=[e for e in events if e['event']=='step_finished'];exits=[e['exit_code'] for e in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and sum(z['seconds'] for z in steps)<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='0c569a88bf05e92a4299fc75cfabf7ee6ed7011e' and git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
assert len((C/'old_git_tree.txt').read_bytes().splitlines())==41551
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'schema':'WPG_FINAL_EVIDENCE_REVIEW','evidence_validation':v['evidence_validation'],'input_bindings_authenticated':len(bindings),
 'source_copies_equal':len(copies),'accepted_completed_captures':sorted(accepted),'failed_captures':sorted(failed),'failure_counted_PASS':False,
 'actual_g1_reference_kernel_qualified':True,'proper_and_reference_nonlinear_tadpole_zero_scope_checked':True,
 'full_Ward_QAP_E5_physical_claim':False,'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,
 'old_tracked_tree_unchanged':True,'largest_accepted_private_sample':max(samples[z] for z in accepted),
 'largest_all_captures_private_sample':max(samples.values()),'memory_samples_not_true_peak':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
