# WPG: actual next-order Ward-primitive response

Prospective after clean preflight at0c569a88bf05e92a4299fc75cfabf7ee6ed7011e,
main,highestV677,no matching workers. Previous goal turn PROGRESS: WPC
actualg0 kernel and reference connected transport. Full goal remains
active;state113/34of39,E5/A5 OPEN,custody2/sevenNOTPASS unchanged.

Question: which actual first-u,g1 epsilon/Ja loop and nonlinear-mean
terms must be evaluated next? Same unshifted formal Euclidean reference,
intrinsic01, fixed KD, nonnegative coupling ring, Schwartz directions,
all33 broken epsilon and45 Ja directions, both probes. Do not replace
KD with a u-dependent generator or use g0 mean zeros at g1.

First extract complete source-differentiated quadratic roots from the
actual primary action/probes and all canonical O_s. Keep sources until
differentiation. Enumerate every ordered marked Born word with total
epsilon*u*Ja and gauge degree1, including direct mixed vertices and
the unmarked g1 reference interaction. Use the actual free propagator
block graph (including B/Lambda mixing and zero LambdaLambda) only to
prove structural zeros, never to label supported paths nonzero without
their contractions. Scalar/matter blocks at g0 are retained as full
blocks; unexpected mixed support fails the proposed reduction.

Classify the ghost-free cubic/source endpoint support needed by the
g1 mixed stationary response. Include the actual physical34-term action
and its coupling grades, scalar-auxiliary bilinear links and the full
U/K source terms. Determine which output fields can occur; do not
pretend that a support bound computes the mean itself. Derive the g0
reference one-loop B/Lambda tadpoles from actual vertices and graded
traces before claiming any tadpole contraction zero. Scalar tadpoles
and arbitrary finite parent-A jets remain unspecified unless actually
needed and derived. No zero-tadpole normalization is authorized.

Native180/review180s afterimports,8GiB sampled private ceiling,350MiB
available-pagefile launch floor,16MiB packet. Freeze immutable input
hashes and source copies before workers. Preserve failures/incompletes,
new version for routine correction, no silent resource expansion.

Expected evidence: exact root/word inventory with zero complements,
stationary-output support proof or its explicit counterexample, actual
reference tadpole traces, distinct replay/action review and sensitive
controls. Any supported unresolved term stays unresolved. Then select
the least expensive required quantum kernel; no automatic295-profile
expansion. E4once/nofresh, final byte/resource audit and old/raw/state
preservation before local commit. Noagents/newbranch/remote/protected
activation, adoption, authority promotion or physical validation claim.
Shared action/regulator/software/AIauthor limits remain explicit.
