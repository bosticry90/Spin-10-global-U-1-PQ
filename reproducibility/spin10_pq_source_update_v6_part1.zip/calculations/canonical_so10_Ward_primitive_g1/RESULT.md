# WPG: next-order connected Ward-primitive kernel

At first u,g10^1, the selected epsilon/Ja reference quantum response is
now calculated at all2970 color/probe positions. The proper contribution
is zero by complete ordered block support. The connected response is
generally NONZERO at finite heat:

    W1_ref=g10 C_sr E_p(1-E_p)^2 Pi_t(p), C_sr=-T_WPC,sr/2.

There are57 nonzero coefficients, all in the broken probe;2913 are
zero. Example C12,12=8 xi^2. The one-propagator contact numerator is
zero before integration. The common reference UV-finite-part-then-IR
Schwartz limit is zero. No finite contact baseline has been fixed.

[Derivation and limits](PROOF.md), [complete integrand](kernel_tables_v2.json.gz),
[action-based review](validation_receipt.json), [support](support_result_v2.json).

## Focused result-to-claim assessment

The evidence establishes the complete reference kernel at this selected
coupling order. Independent multigraded path checking confirms proper
zeros. Derivative-first replay action evaluation agrees at all2970
positions for each of three full4D momentum pairs. Controls deleting
the primitive root or changed means each change57 positions. Counts
are coverage, not physical confirmation.

The nonlinear mean itself is not zero-proved at g1. Its output is
bounded to B/Lambda; the actual reference g0 tadpole contraction vanishes
because B has no cubic return and all45 Lambda ghost traces vanish.
Unknown scalar tadpoles are not normalized away. This is stronger than
assuming the earlier quadratic-sector zero survives unchanged.

Finite parent-A jets, including the nonlinear-mean/tadpole term, remain
symbolic. Reference-loop cancellation does not establish their Ward
normalization, full QAP/measure/equivalence or physical viability.
Shared action, data, libraries, reference assumptions and AI authorship
limit what replay agreement validates. Failed support/kernel runs are
preserved with exact causes; the corrected results do not erase them.

Next assess the actual finite-parent transport equation using the g0
and g1 primitive inputs, and identify any remaining required coefficient
before another expansion. State113/34of39 and E5/A5 OPEN are unchanged.
Historical custody remains exit2/seven unresolved, NOTPASS. Full goal
remains active and incomplete; no physical or foundational adoption.
