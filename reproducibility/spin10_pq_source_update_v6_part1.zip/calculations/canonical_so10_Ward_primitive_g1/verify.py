from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict,Counter
from itertools import product
import gzip,json,os,sys,threading,time
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
I=J.I;ONE=J.constant(1);Z=J.ZERO
sc=lambda c,n:J.times(c,J.constant(n))
def powc(c,n):
    out=ONE
    for k in range(n):out=J.times(out,c)
    return out
def gpart(P,g):return J.clean({w:J.Coeff([((0,x,e,m),z) for (gg,x,e,m),z in c.terms if gg==g]) for w,c in P.items()})
def keep(P):return {w:c for w,c in P.items() if all(n<643 for n,js in w)}
def typ(n):return 'B' if n<180 else 'x' if n<508 else 'L' if n<553 else 'C' if n<598 else 'a' if n<643 else 'source'
def omega(n):return J.Coeff([((0,0,1,0),F(1))]) if n<12 else J.Coeff([((0,1,0,0),F(1))])
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz');gf={n:J.decode(p) for n,p in fj['GF_gradient']}
action=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[1];S={}
for row in action['original']:J.add(S,J.decode(row['density']))
Us=[J.decode(p['qG']) for p in fj['probes']]
K={}
for a in range(12,45):
    z=dict(gf[508+a]);J.put(z,((1241+a,()),),-I);J.put(z,((508+a,()),),sc(omega(a),F(-1,2)))
    K[a]=J.clean({w:J.times(-I,c) for w,c in z.items()})
# Ordinary Euler first, then its linear field support, independently of
# native density-quadratic extraction. Derivative placements are retained.
def qtypes(P):
    out=set()
    for n,z in J.euler(keep(P),set(range(643))).items():
        for w,c in z.items():
            if len(w)==1:out.add(tuple(sorted([typ(n),typ(w[0][0])])))
    return out
def srctypes(P):
    out=set()
    for n,z in J.euler(P,set(range(1241,1286))).items():out|=qtypes(z)
    return out
prop={'B':{'B','L'},'L':{'B'},'x':{'x'},'C':{'a'},'a':{'C'}};labels=list(prop)
def target_trace(categories,wrong=False):
    # Each entry is a polynomial in (g,theta,u,Ja). Dynamic matrix
    # multiplication sums all ordered paths without reading native words.
    entries=defaultdict(set)
    for fam,g,marks,ts in categories:
        if wrong and fam=='K' and g==1:ts={('C','a')}
        degree=g,int(bool(marks&1)),int(bool(marks&2)),int(bool(marks&4))
        for a,b in ts:
            for row,col in [(a,b),(b,a)]:
                for src in labels:
                    if row in prop[src]:entries[src,col].add(degree)
    paths={(a,a,(0,0,0,0)) for a in labels};hit=False
    for n in range(1,5):
        new=set()
        for start,mid,d in paths:
            for out in labels:
                for e in entries[mid,out]:
                    f=tuple(x+y for x,y in zip(d,e))
                    if all(x<=1 for x in f):new.add((start,out,f))
        paths=new;hit|=any(a==b and d==(1,1,1,1) for a,b,d in paths)
    return hit
cats=[]
for pr,U in enumerate(Us):
    c=[]
    for g in [0,1]:
        kt=set().union(*(qtypes(gpart(p,g)) for p in K.values()))
        c += [('K',g,1,kt),('U',g,2,qtypes(gpart(U,g))),('Ja',g,4,srctypes(gpart(S,g))),('UJa',g,6,srctypes(gpart(U,g)))]
        if g:c.append(('V',g,0,qtypes(gpart(S,g))))
    cats.append(c);assert not target_trace(c)
assert target_trace(cats[1],True),'WRONG_GHOST_K1_ROOT_CONTROL_INSENSITIVE'
# g0 reference tadpole: derive the full ghost matrix directly from the
# replay auxiliary Euler, and retain off-diagonal positions before trace.
traces=[];offdiag=0;L={}
for a in range(45):
    P=gpart(gf[508+a],0);diag=Z
    for w,c in P.items():
        if len(w)==2:
            assert 553<=w[0][0]<598 and 598<=w[1][0]<643 and not w[0][1] and not w[1][1]
            if w[0][0]+45==w[1][0]:diag-=c
            else:offdiag+=1
    assert not diag;traces.append(diag)
    if a>=12:
        mat={}
        for w,c in gpart(K[a],0).items():
            if len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643:mat[w[1][0]-598,w[0][0]-553]=-c
        L[a]=mat
assert offdiag>0 and traces[12]+ONE!=Z
# Check source-plane first correction and mixed forcing output support.
# g0 bosonic B/L sectors are quadratic (already whole-density checked in
# WPC); g0 scalar interactions cannot mix a B/L endpoint with a single x.
for P in [S]+Us:
    plain=keep(gpart(P,0))
    assert not any(len(w)>2 and all(n<553 for n,js in w) for w in plain)
    for w,c in keep(gpart(P,1)).items():
        if len(w)==3:
            for at,(n,js) in enumerate(w):
                if all(typ(nn) in ['B','L'] for nn,jj in w[:at]+w[at+1:]):assert typ(n) in ['B','L']
    for n,z in J.euler(gpart(P,1),set(range(1241,1286))).items():
        for out,grad in J.euler(keep(z),set(range(643))).items():
            for w,c in grad.items():
                if len(w)==1 and typ(w[0][0]) in ['B','L']:assert typ(out) in ['B','L']
for ts in [qtypes(gpart(S,1))]+[qtypes(gpart(U,1)) for U in Us]:assert all('x' in t for t in ts)
for a,P in K.items():
    assert qtypes(gpart(P,1))<={('B','B')}
    assert all(typ(w[0][0])=='x' for w in keep(gpart(P,1)) if len(w)==1)
print('STAGE independent graded block paths and reference tadpole/support proof',flush=True)
# Derivative-first original ghost action. These are left a then left C
# derivatives of each actual monomial, BEFORE field/source substitution.
def ghost_terms(P):
    terms=[]
    for w,c in P.items():
        gs=[(n,js) for n,js in w if 553<=n<643]
        if len(gs)!=2:continue
        aa=[t for t in gs if t[0]>=598];cc=[t for t in gs if t[0]<598]
        if len(aa)!=1 or len(cc)!=1:
            # Such a block would require an excluded source/zero background;
            # retain a hard failure if its even backgrounds can survive.
            assert any(180<=n<508 or 643<=n<1241 for n,js in w);continue
        bg=J.leftjet(J.leftjet({w:c},aa[0]),cc[0]);assert len(bg)==1
        bw,co=next(iter(bg.items()));terms.append((aa[0],cc[0],bw,co))
    return terms
preparedS=ghost_terms(S);preparedU=[ghost_terms(U) for U in Us]
def putpoly(out,k,c):
    out[k]=out.get(k,Z)+c
def bgproduct(a,b):
    out={}
    for (ua,ta,ja),c in a.items():
        for (ub,tb,jb),d in b.items():
            if ua+ub>1 or ta is not None and tb is not None or ja is not None and jb is not None:continue
            putpoly(out,(ua+ub,ta if ta is not None else tb,ja if ja is not None else jb),J.times(c,d))
    return {k:c for k,c in out.items() if c}
def stationary(a,E):
    om=omega(a);G=[[sc(om,E),sc(-I,E)],[sc(-I,E),Z]]
    vec=lambda vv:[sum((J.times(G[i][j],vv[j]) for j in range(2)),Z) for i in range(2)]
    YJ=[-c for c in vec([Z,-I])];YT=[-c for c in vec([ONE,sc(J.times(-I,om),F(1,2))])]
    H=[[-2*ONE,J.times(I,om)],[J.times(I,om),sc(J.times(om,om),F(1,2))]]
    rhs=[sum((J.times(H[i][j],YJ[j]) for j in range(2)),Z)+[2*ONE,J.times(-I,om)][i] for i in range(2)]
    YUJ=[-c for c in vec(rhs)]
    assert all(not sum((J.times(H[i][j],YT[j]) for j in range(2)),Z) for i in range(2))
    return YJ,YT,YUJ
def backgrounds(pr,p,E,omit=False):
    pp=sum(x*x for x in p);out={}
    for a in range(45):
        YJ,YT,YUJ=stationary(a,E);selected=a<12 if pr==0 else a>=12
        for mu in range(4):
            vals={(0,None,a):J.times(sc(I,p[mu]/pp),YJ[0])}
            if a>=12:vals[0,a,None]=J.times(sc(-I,p[mu]/pp),YT[0])
            if selected and not omit:vals[1,None,a]=J.times(sc(I,p[mu]/pp),YUJ[0])
            out[4*a+mu]=vals
        vals={}
        if a>=12:vals[0,a,None]=YT[1]
        if selected and not omit:vals[1,None,a]=YUJ[1]
        out[508+a]=vals;out[1241+a]={(0,None,a):ONE}
    return out
def substitute(terms,up,pr,p,E,bg):
    out=[]
    for aa,cc,w,c in terms:
        for g in [0,1]:
            cf=J.Coeff([((0,x,e,m),z) for (gg,x,e,m),z in c.terms if gg==g])
            if not cf:continue
            poly={(up,None,None):cf}
            for n,js in w:
                options={}
                for key,val in bg.get(n,{}).items():
                    net=1 if key[1] is not None else -1
                    for mu in js:val=J.times(val,sc(I,net*p[mu]))
                    putpoly(options,key,val)
                poly=bgproduct(poly,options)
            for (u,th,ja),val in poly.items():
                if th is not None or ja is not None:out.append((u,g,th,ja,aa,cc,val))
    return out
def vertices(terms,q,p):
    out={}
    for u,g,th,ja,aa,cc,c in terms:
        net=int(th is not None)-int(ja is not None)
        for mu in aa[1]:c=J.times(c,sc(-I,q[mu]+net*p[mu]))
        for mu in cc[1]:c=J.times(c,sc(I,q[mu]))
        mat=out.setdefault((u,g,th,ja),{});putpoly(mat,(aa[0]-598,cc[0]-553),c)
    return {k:{ij:c for ij,c in mat.items() if c} for k,mat in out.items()}
def measured(V,W,ss,r,no_primitive=False):
    vv=V
    if no_primitive:
        vv={key:dict(mat) for key,mat in V.items()}
        m=vv.setdefault((0,0,ss,None),{})
        for ij,c in L[ss].items():putpoly(m,ij,-c)
    value=Z
    for ua in [0,1]:
        for ga in [0,1]:
            AA=vv.get((ua,ga,ss,None),{});BB=W.get((1-ua,1-ga,None,r),{})
            # Explicit two ordered matrix products and their factor one-half.
            left=sum((J.times(c,BB.get((j,i),Z)) for (i,j),c in AA.items()),Z)
            right=sum((J.times(c,AA.get((j,i),Z)) for (i,j),c in BB.items()),Z)
            assert left==right;value-=sc(left+right,F(1,2))
    contact=sum((c for (i,j),c in V.get((1,1,ss,r),{}).items() if i==j),Z)
    return value,contact
cases=[([F(2),F(0),F(0),F(0)],[F(-1,3),F(4,5),F(0),F(0)],F(1,3)),
       ([F(1),F(2),F(-1),F(0)],[F(2),F(-1),F(3),F(1)],F(2,5)),
       ([F(3,2),F(-1,2),F(1),F(2)],[F(-2),F(1,3),F(1),F(-1)],F(3,7))]
allvalues=[];controls=[]
for ci,(p,q,E) in enumerate(cases):
    result={};sensitive=0;means_sensitive=0
    for pr in [0,1]:
        bg=backgrounds(pr,p,E);terms=substitute(preparedS,0,pr,p,E,bg)+substitute(preparedU[pr],1,pr,p,E,bg)
        for a,mat in L.items():
            for (i,j),c in mat.items():terms.append((0,0,a,None,(598+i,()),(553+j,()),c))
        V=vertices(terms,q,p);W=vertices(terms,[x+y for x,y in zip(q,p)],p)
        if ci==0:
            bg0=backgrounds(pr,p,E,True);t0=substitute(preparedS,0,pr,p,E,bg0)+substitute(preparedU[pr],1,pr,p,E,bg0)
            for a,mat in L.items():
                for (i,j),c in mat.items():t0.append((0,0,a,None,(598+i,()),(553+j,()),c))
            V0=vertices(t0,q,p);W0=vertices(t0,[x+y for x,y in zip(q,p)],p)
        for ss in range(12,45):
            for r in range(45):
                actual=measured(V,W,ss,r);result[pr,ss,r]=actual
                if ci==0:
                    sensitive+=measured(V,W,ss,r,True)!=actual;means_sensitive+=measured(V0,W0,ss,r)!=actual
    assert len(result)==2970;allvalues.append(result)
    if ci==0:controls=[sensitive,means_sensitive];assert sensitive>0 and means_sensitive>0
    print('STAGE derivative-first full4D action comparison '+str(ci),flush=True)
# Only now read the native connected and earlier g0 coefficient tables.
native=load(O/'kernel_tables_v2.json.gz');earlier=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
prior={(r['probe'],r['epsilon'],r['Ja']):J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in r['proper_Gamma_tensor']]) for r in earlier['complete_color_table']}
def coeff(cells):return J.Coeff([(tuple(k),F(n,d)) for k,n,d in cells])
for row in native['complete_color_table']:
    key=row['probe'],row['epsilon'],row['Ja'];poly=row['connected_bubble_numerator'];contact=row['connected_contact_numerator']
    assert all(k[1:]==[0,0,0] for k,c in poly) and not contact
    C=sc(prior[key],F(-1,2))
    assert {tuple(k):coeff(c) for k,c in poly}==({(1,0,0,0):C,(2,0,0,0):-2*C,(3,0,0,0):C} if C else {})
    for case,vals in zip(cases,allvalues):
        E=case[2];expected=sc(C,E*(1-E)**2)
        assert vals[key]==(expected,Z),('INDEPENDENT_ACTION_MISMATCH',key)
assert sum(bool(c) for c in prior.values())==57
# Finite heat response is genuinely nonzero. Scalar heat bubble is the
# authenticated WPC result; this checks its new external factor/limit.
mp.mp.dps=38;values=[]
for tt in ['0.2','0.02','0.002']:
    t=mp.mpf(tt);z=2*t;E=mp.exp(-2*t)
    B=2*mp.e1(z)-mp.e1(z/2)+2*(mp.exp(-z/2)-mp.exp(-z))/z
    val=E*(1-E)**2*B/(16*mp.pi**2);assert val>0
    values.append(str(val))
assert mp.mpf(values[-1])<mp.mpf(values[0])
out={'schema':'WPG_SEPARATE_DERIVATIVE_FIRST_ACTION_REVIEW','evidence_validation':'PASS_ACTUAL_G1_REFERENCE_CONNECTED_PRIMITIVE_KERNEL',
 'proper_typed_word_counts':[6,16],'proper_multigraded_block_target_zero':True,'wrong_K1_ghost_root_control_sensitive':True,
 'reference_auxiliary_tadpole_traces_zero':45,'offdiagonal_ghost_positions_retained':offdiag,
 'g1_mixed_mean_only_B_L_outputs':True,'mixed_mean_not_assigned_zero':True,'unknown_scalar_tadpole_not_assigned_zero':True,
 'g1_first_endpoint_correction_scalar_only':True,'three_full4D_action_cases':3,'color_positions_checked_per_case':2970,
 'nonzero_connected_bubble_positions':57,'zero_contact_positions':2970,'coefficient_relation':'C_g1=-T_g0/2',
 'omitted_primitive_root_controls_sensitive':controls[0],'omitted_changed_means_controls_sensitive':controls[1],
 'finite_heat_scalar_controls':values,'reference_UV_FP_then_IR_zero':True,'physical_finite_delta_Ward_identity_claim':False,
 'arbitrary_finite_parent_A':'UNFIXED_ALL_FIVE_LEGENDRE_TERMS','full_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
