# WPG separate review and common-limit test

Prospective after supportV2/kernelV2. Proposed result: every g1 proper
root word is structurally zero, while the remaining connected integrand
has57 nonzero bubble positions and zero contact trace. No finite/IR or
full connected claim is inferred until the completeness proof is checked.

Use replay GF/action/probes and derive each auxiliary primitive from its
Euler relation, not from the native kernel table. Apply LEFT ghost
derivatives to the action BEFORE Fourier/source-mean substitution. Derive
the actual g0 stationary endpoints by the mixed Gaussian inverse and
the full u/source contact. Evaluate all2970 color positions at three
generic, including non-collinear, four-momentum pairs, with exact rational
momenta and heat values. The second vertex uses q+p directly, rather
than the native polynomial shift. Compare after both ordered responses.

Check proper zeros by a separate truncated multigraded block-matrix
product, not native cyclic enumeration alone. Independently classify
the g1 mean outputs and first endpoint corrections. Account for the
physical34-term action and the g0 scalar sector. Test the actual g0
Lambda tadpole trace using replay GF, with full off-diagonal matrices.
Do not assume the mixed mean itself zero or impose a tadpole condition.

Compare the proposed coefficient relation to the measured WPC g0 tensor
only AFTER independent calculation. Use negative controls deleting the
primitive root and/or changed means; record sensitive and insensitive
controls honestly. Use the authenticated WPC heat bubble and its common
UV-FP-then-IR proof, verify the new external heat factor and its finite-
profile nonzero term. Keep1-f inverse/source defects, arbitrary finite
parent-A jets and all authority limits explicit. No new physical scheme.

Review180s afterimports,8GiB sampled/350MiB launch/16MiB packet unchanged.
Shared action/library/analyst/regulator/AIauthor limits remain; no claim
of external verification or physical validation. Preserve all failed runs.
