# WPG kernel V2: coefficient scalar and power operations

Kernel V1 FAILED at its endpoint expansion because Coeff does not
implicitly multiply Fraction values. Inspection also identifies the
unsupported Coeff power operation in jet phases. These are implementation
errors, not failed physical gates; no kernel table was completed.
Preserve the failed source, capture and controller record.

V2 uses explicit constant coefficients and an iterated exact product
for phase powers. These operations are type-checked against I^0=1,
I^2=-1 and the one-half coefficient before the expansion. All inputs,
scientific requirements and180s/8GiB/350MiB/16MiB limits are unchanged.
