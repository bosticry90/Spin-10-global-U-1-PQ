from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from itertools import product
from collections import Counter,defaultdict
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
sp=importlib.util.spec_from_file_location('raw_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
def grade(P,g):return J.clean({w:J.Coeff([(k,z) for k,z in c.terms if k[0]==g]) for w,c in P.items()})
def locus(P):return {w:c for w,c in P.items() if all(i<643 for i,js in w)}
def kind(i):return 'B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a' if i<643 else 'Ja' if i>=1241 else 'other_source'
def types(P):return sorted({tuple(sorted(kind(i) for i,js in w)) for w in P})
def quadratic(P):return {w:c for w,c in locus(P).items() if len(w)==2}
def source_roots(P):return {r:quadratic(z) for r,z in J.euler(P,set(range(1241,1286))).items()}
def join_roots(d):
    out={}
    # Retain color/direction provenance; do not sum different source columns.
    for r,P in d.items():
        for w,c in P.items():out[r,w]=c
    return out
def roottypes(P):return {tuple(sorted(kind(i) for i,js in w)) for w in P}
ct=load(R/'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');A=u.Algebra(ct['geometry']['names'],ct['geometry']['parities'])
K={}
for i,pp in ct['components'].items():
    z={}
    for (g,w),c in v.unpack(A,pp).items():J.put(z,w,J.Coeff([((g,x,e,m),q) for (x,e,m),q in c]))
    K[int(i)-1286+12]=J.clean(z)
action=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0]
S={}
for row in action['original']:J.add(S,J.decode(row['density']))
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');Us=[J.decode(p['qG']) for p in fj['probes']]
root_tables=[];word_tables=[];completeness=[]
freeS=quadratic(grade(S,0));assert roottypes(freeS)<={('B','L'),('L','L'),('C','a')}
# The g0 physical scalar quadratic block is resummed in Gx. Gauge-fixing
# quadratic entries below are part of the fixed reference, not Born vertices.
prop={'B':{'B','L'},'L':{'B'},'x':{'x'},'C':{'a'},'a':{'C'}}
def cycle(rootlist):
    options=[]
    for rt in rootlist:
        opts=set()
        for a,b in rt:opts|={(a,b),(b,a)}
        if not opts:return False
        options.append(sorted(opts))
    return any(all(combo[(i+1)%len(combo)][0] in prop[pair[1]] for i,pair in enumerate(combo)) for combo in product(*options))
for pr,U in enumerate(Us):
    roots=[]
    def addroot(name,g,marks,pp):
        roots.append({'name':name,'g':g,'marks':marks,'quadratic_types':[list(t) for t in sorted(roottypes(pp))],'positions':len(pp)})
        root_tables.append({'probe':pr,'name':name,'g':g,'marks':marks,'density':J.encode(pp)})
    for g in [0,1]:
        for s in range(12,45):addroot(f'K{s}_g{g}',g,1,quadratic(grade(K[s],g)))
        # Marked roots aggregate support only. Exact per-color polynomials
        # remain separate in the output table above/below.
        for label,Ps,marks in [('U',U,2),('Ja',S,4),('UJa',U,6)]:
            ps=grade(Ps,g)
            if label=='U':addroot(f'U_g{g}',g,marks,quadratic(ps))
            else:
                for r,pp in source_roots(ps).items():addroot(f'{label}{r-1241}_g{g}',g,marks,pp)
        addroot(f'V_g{g}',g,0,quadratic(grade(S,g)) if g else {})
        for ss,pp in K.items():
            assert not any(source_roots(grade(pp,g)).values()),'PRIMITIVE_HAS_UNACCOUNTED_MIXED_FIELD_HESSIAN'
    aggregate={}
    for rt in roots:
        label=rt['name'].split('_g')[0]
        family='K' if label.startswith('K') else 'UJa' if label.startswith('UJa') else 'Ja' if label.startswith('Ja') else label
        key=family,rt['g'],rt['marks'];aggregate.setdefault(key,set()).update(tuple(t) for t in rt['quadratic_types'])
    categories=[(name,g,marks,ts) for (name,g,marks),ts in sorted(aggregate.items()) if ts]
    words=[]
    for n in range(1,5):
        for combo in product(categories,repeat=n):
            if sum(z[1] for z in combo)!=1 or sum(z[2] for z in combo)!=7:continue
            # Marks are independent degree-one variables; forbid overlaps.
            if any(sum(bool(z[2]&bit) for z in combo)!=1 for bit in [1,2,4]):continue
            possible=cycle([z[3] for z in combo])
            words.append({'word':[[z[0],z[1]] for z in combo],'typed_cycle_possible':possible})
    word_tables.append({'probe':pr,'nonempty_categories':[[n,g,m,[list(t) for t in sorted(ts)]] for n,g,m,ts in categories],'ordered_words':words})
    completeness.append({'probe':pr,'complete_nonempty_marked_words':len(words),'typed_supported_words':sum(w['typed_cycle_possible'] for w in words),'roots':roots})
    print('STAGE complete actual g1 proper-root words '+str(pr),flush=True)
# The g1 mixed stationary forcing: two g0 source endpoints have support
# B/L. Analyze every cubic output and every direct Ja-quadratic endpoint.
forcing=[]
for label,P in [('S',S)]+[(f'U{p}',z) for p,z in enumerate(Us)]:
    P=grade(P,1);plain=locus(P)
    candidates=[];outputs=set()
    for w,c in plain.items():
        if len(w)!=3:continue
        for at,(i,js) in enumerate(w):
            if all(kind(n) in ['B','L'] for n,jj in w[:at]+w[at+1:]):outputs.add(kind(i));candidates.append((i,w))
    direct=set()
    for r,z in J.euler(P,set(range(1241,1286))).items():
        for w,c in locus(z).items():
            if len(w)!=2:continue
            for at,(i,js) in enumerate(w):
                if kind(w[1-at][0]) in ['B','L']:direct.add(kind(i))
    forcing.append({'density':label,'g1_cubic_outputs_from_BL_endpoints':sorted(outputs),'g1_direct_Ja_outputs_from_BL_endpoint':sorted(direct),'cubic_positions_with_output_mark':len(candidates)})
Koutputs=set();Kaffine=Counter()
for ss,P in K.items():
    for w,c in locus(grade(P,1)).items():
        if len(w)==1:Kaffine[kind(w[0][0])]+=1
        if len(w)!=2:continue
        for at,(i,js) in enumerate(w):
            if kind(w[1-at][0]) in ['B','L']:Koutputs.add(kind(i))
physical=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
def shapes(node):
    n=node['node']
    if n=='Field':return {(tuple([node['name']]),0,0)}
    if n=='Parameter':return {((),0,int(node['name']=='g10'))}
    if n in ['ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return {((),0,0)}
    if n=='PartialDerivative':return {(f,d+1,g) for f,d,g in shapes(node['argument'])}
    if n=='LocalActionTerm':return shapes(node['density'])
    if n in ['LorentzContraction','GroupContraction']:return shapes(node.get('expression',node.get('argument')))
    if n=='Add':return set().union(*(shapes(z) for z in node['terms']))
    if n=='OrderedProduct':
        out={((),0,0)}
        for z in node['factors']:out={(tuple(sorted(a+b)),d+e,g+k) for a,d,g in out for b,e,k in shapes(z)}
        return out
    raise AssertionError(n)
ps=set().union(*(shapes(z) for z in physical['local_terms']));assert len(physical['local_terms'])==34
assert all(not any(n in ['C','a','Lambda'] or n.startswith('J') for n in fs) for fs,d,g in ps)
bshapes=sorted(z for z in ps if 'B' in z[0] and z[2]<=1)
assert all((fs.count('B')==2 and len(fs)==2 and g==0) or (fs.count('B')==3 and len(fs)==3 and g==1) or (fs.count('B')==1 and len(fs)==3 and g==1) for fs,d,g in bshapes)
# Reference g0 Lambda tadpole from the original action, after all source
# derivatives. Its only quadratic return is the ghost mass; derive the
# full diagonal sum, rather than importing a zero normalization.
tadpoles=[]
for rr,z in J.euler(grade(S,0),set(range(508,553))).items():
    H=quadratic(z);diag=J.ZERO
    for w,c in H.items():
        if len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643:
            assert not w[0][1] and not w[1][1]
            if w[1][0]==w[0][0]+45:diag-=c
        else:raise AssertionError(('UNEXPECTED_G0_AUXILIARY_TADPOLE_RETURN',rr,w))
    tadpoles.append({'Lambda':rr-508,'ghost_trace':J.encode({():diag}) if diag else []})
baseB=J.euler(grade(S,0),set(range(180)));assert not any(quadratic(p) for p in baseB.values())
qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
out={'schema':'WPG_ACTUAL_G1_PRIMITIVE_SUPPORT_AND_TADPOLE_CENSUS','probes':completeness,'stationary_forcing':forcing,
 'K_g1_BL_endpoint_outputs':sorted(Koutputs),'K_g1_affine_output_positions':dict(Kaffine),'physical34_B_shapes':[[list(fs),d,g] for fs,d,g in bshapes],
 'reference_g0_B_tadpole_no_cubic_return':True,'reference_g0_Lambda_tadpole_traces':tadpoles,
 'full_connected_g1_kernel_measured':False,'arbitrary_finite_A_chosen':False,'full_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=gzip.compress((json.dumps({'roots':root_tables,'word_inventory':word_tables},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'support_tables_v2.json.gz').open('xb') as f:f.write(blob)
out['table_sha256']=sha256(blob).hexdigest()
with(O/'support_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:z for k,z in out.items() if k!='probes'},sort_keys=True),flush=True);timer.cancel()
