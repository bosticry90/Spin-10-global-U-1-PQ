from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
from collections import defaultdict,Counter
from math import comb
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I
# Kinematic monomials: (external heat power,P power,Q power,R power).
def clean(a):return {k:c for k,c in a.items() if c}
def add(a,b):
    out=dict(a)
    for k,c in b.items():out[k]=out.get(k,Z)+c
    return clean(out)
def scale(a,c):return clean({k:J.times(v,c) for k,v in a.items()})
def mul(a,b):
    out={}
    for ka,ca in a.items():
        for kb,cb in b.items():
            k=tuple(a+b for a,b in zip(ka,kb));out[k]=out.get(k,Z)+J.times(ca,cb)
    return clean(out)
def shift(a,sg=1):
    out={}
    for (e,p,q,r),c in a.items():
        assert q>=0
        for j in range(q+1):
            k=e,p+q-j,j,r;out[k]=out.get(k,Z)+c*(comb(q,j)*sg**(q-j))
    return clean(out)
unit={(0,0,0,0):ONE};pp={(0,1,0,0):ONE};qq={(0,0,1,0):ONE};rr={(0,0,0,1):ONE}
def omega(i):return J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))])
def encode(P):return [[list(k),[[list(kk),z.numerator,z.denominator] for kk,z in c.terms]] for k,c in sorted(P.items())]
def ecoef(cells):return J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in cells])
def mmput(M,key,ij,P):
    if not P:return
    m=M.setdefault(key,{});m[ij]=add(m.get(ij,{}),P)
def endpoint(n,js,probe):
    # return u power,theta color,Ja color,background momentum sign,poly
    choices=[]
    if n<180:
        if n%4:return []
        a=n//4;om=omega(a)
        choices.append((0,None,a,-1,{(1,-1,0,0):I}))
        if a>=12:choices.append((0,a,None,1,{(1,-1,0,0):J.times(I,om)*F(1,2)}))
        selected=a<12 if probe==0 else a>=12
        if selected:choices.append((1,None,a,-1,{(1,-1,0,0):-J.times(I,om),(2,-1,0,0):J.times(I,om)}))
    elif 508<=n<553:
        a=n-508
        if a>=12:choices.append((0,a,None,1,{(1,0,0,0):I}))
        if a<12 if probe==0 else a>=12:choices.append((1,None,a,-1,{(1,0,0,0):2*I,(2,0,0,0):-2*I}))
    elif 1241<=n<1286:choices.append((0,None,n-1241,-1,unit))
    else:return []
    if any(mu!=0 for mu in js):return []
    return [(up,th,ja,sg,mul(P,{(0,len(js),0,0):(I*sg)**len(js)})) for up,th,ja,sg,P in choices]
def stripgrade(c,g):return J.Coeff([((0,x,e,m),z) for (gg,x,e,m),z in c.terms if gg==g])
def compile_mass(dens,up,probe,M):
    audit=Counter()
    for w,c in dens.items():
        ghosts=[(n,js) for n,js in w if 553<=n<643]
        if len(ghosts)!=2:continue
        cc=[(n-553,js) for n,js in ghosts if n<598];aa=[(n-598,js) for n,js in ghosts if n>=598]
        other=[(n,js) for n,js in w if not 553<=n<643]
        choices=[endpoint(n,js,probe) for n,js in other]
        if any(not z for z in choices):audit['zero_background_or_other_source']+=1;continue
        assert len(cc)==len(aa)==1,'ANOMALOUS_GHOST_BLOCK_ON_G0_MEAN_LOCUS'
        for g in [0,1]:
            cf=stripgrade(c,g)
            if not cf:continue
            for combo in product(*choices):
                us=up+sum(z[0] for z in combo);ths=[z[1] for z in combo if z[1] is not None];jas=[z[2] for z in combo if z[2] is not None]
                if us>1 or len(ths)>1 or len(jas)>1:continue
                if not ths and not jas:
                    assert not up,'UNMARKED_U_GHOST_HESSIAN_SURVIVES'
                    continue # original free ghost operator is in G0
                th=ths[0] if ths else None;ja=jas[0] if jas else None;net=int(th is not None)-int(ja is not None)
                P={(0,0,0,0):-cf}
                for z in combo:P=mul(P,z[4])
                for mu in cc[0][1]:P=mul(P,scale(qq if mu==0 else rr if mu==1 else {},I))
                for mu in aa[0][1]:
                    moment=add(scale(qq,-ONE),scale(pp,J.constant(-net))) if mu==0 else scale(rr,-ONE) if mu==1 else {}
                    P=mul(P,scale(moment,I))
                mmput(M,(us,g,th,ja),(aa[0][0],cc[0][0]),P);audit['surviving_substitution_terms']+=1
    return dict(audit)
act=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0];S={}
for row in act['original']:J.add(S,J.decode(row['density']))
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
allrows=[];audits=[];vertex_tables=[]
for probe in [0,1]:
    M={};a=compile_mass(S,0,probe,M);b=compile_mass(J.decode(fj['probes'][probe]['qG']),1,probe,M)
    for ss,rows in qt['L'].items():
        for i,j,cells in rows:mmput(M,(0,0,int(ss),None),(i,j),{(0,0,0,0):ecoef(cells)})
    # Remove zero matrix entries after combining all direct/mean vertices.
    M={key:{ij:P for ij,P in mat.items() if P} for key,mat in M.items()};M={k:m for k,m in M.items() if m}
    audits.append({'probe':probe,'original':a,'probe_vertices':b,'matrix_vertex_groups':len(M)})
    vertex_tables.append({'probe':probe,'vertices':[[list(k),[[i,j,encode(P)] for (i,j),P in sorted(mat.items())]] for k,mat in sorted(M.items(),key=lambda z:str(z[0]))]})
    for ss in range(12,45):
        for r in range(45):
            bubble={}
            for ua,ga,ub,gb in [(0,0,1,1),(0,1,1,0),(1,0,0,1),(1,1,0,0)]:
                AA=M.get((ua,ga,ss,None),{});BB=M.get((ub,gb,None,r),{})
                for (i,j),P in AA.items():
                    if (j,i) in BB:bubble=add(bubble,scale(mul(P,shift(BB[j,i])),-ONE))
            contact={}
            for (i,j),P in M.get((1,1,ss,r),{}).items():
                if i==j:contact=add(contact,P)
            allrows.append({'probe':probe,'epsilon':ss,'Ja':r,'connected_bubble_numerator':encode(bubble),'connected_contact_numerator':encode(contact)})
    print('STAGE complete g1 connected ghost integrand '+str(probe),flush=True)
blob=gzip.compress((json.dumps({'vertex_tables':vertex_tables,'complete_color_table':allrows},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'kernel_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPG_ACTUAL_G1_CONNECTED_GHOST_INTEGRAND','complete_color_positions':len(allrows),
 'nonzero_bubble_positions':sum(bool(z['connected_bubble_numerator']) for z in allrows),'nonzero_contact_positions':sum(bool(z['connected_contact_numerator']) for z in allrows),
 'audits':audits,'table_sha256':sha256(blob).hexdigest(),'finite_UV_IR_result_not_yet_inferred':True,
 'full_Ward_QAP_E5_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'kernel_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
