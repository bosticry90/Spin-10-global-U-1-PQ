# First-u,g1 Ward-primitive quantum response

## Exact claim and domain

This continues WPC at the same unshifted formal Euclidean A0, intrinsic
order01, one-loop, fixed Dminus primitive KD and Schwartz source domain.
The coefficient is first u, one theta_s=rho epsilon_s (s12..44), one
Ja_r (r0..44), and gauge powerg10^1, for both declared probes. rho and
epsilon are odd; theta is even. No source-free physical vacuum or
constant-source limit is taken. Existing canonical chart, graded
Gaussian and reference assumptions are inherited, not revalidated as
physical facts. The result concerns the reference functional; arbitrary
finite parent A is kept separately.

The new result is

    W1_ref[theta_s u Ja_r]_g1
      =g10 C_pr,sr E_p(1-E_p)^2 Pi_t(p),
    C_pr,sr=-T_WPC,pr,sr/2,
    E_p=exp(-2t p_E^2).

Pi_t is the actual two-positive-heat massless bubble constructed in
WPC, not a fitted master kernel. There are57 nonzero C positions and
2913 zeros. Every nonzero entry belongs to the broken probe. For
example C_broken,12,12=8 xi^2. The relation to WPC is a checked exact
coefficient identity AFTER independent derivation; it was not used to
generate this quantum input. The finite-heat result is generally nonzero.
Its common reference UV-finite-part-then-IR Schwartz limit is zero.

## Proper diagrams: complete zero by block structure

Differentiate sources BEFORE restricting all sources other than Ja to
zero. Extract the ordinary quadratic roots from the actual canonical
KD components, full GF/source density, and whole U=QG. Denote by K the
theta root, U the probe root, J the Ja root, UJ their direct mixed root,
and V an unmarked g1 quadratic reference interaction. Their nonempty
field blocks are:

| Root | Gauge power | Ordinary quadratic block |
| --- | --- | --- |
| K | 0 | Ca |
| K | 1 | BB |
| J | 1 | Ca |
| U | 0 | BB, BLambda, LambdaLambda |
| U, broken probe | 1 | Bx, Lambdax |
| UJ, broken probe | 0 | Ca |
| UJ, broken probe | 1 | BB |
| V | 1 | Lambdax |

Original J at g0 has no ordinary Hessian. Direct KJ ordinary Hessians
vanish in all33 directions. All scalar/matter g0 reference blocks stay
fully resummed in their own propagator blocks, with matter hat mixing
retained. The free nonminimal graph is BB and BLambda/LambdaB,
LambdaLambda=0; ghosts return only C/a. No g0 nonminimal-scalar/matter
propagator is introduced.

Marked coupling/source degrees bound a Born word to at most4 roots.
The native inventory retains6 ordered words in the unbroken probe and
16 in the broken probe. None has a compatible field cycle. This is
zero BEFORE a trace, UV subtraction or momentum limit. A separate
multigraded block-matrix multiplication checks all ordered paths
without reading that enumeration. Replacing the actual BB K_g1 root
by an artificial Ca root produces a nonzero target path, a sensitive
control. All2970 proper coefficients are therefore zero at g1 in this
projection; the result is not absence of g1 interactions generally.

The executable physical action has34 local terms. At gauge power<=1
its vector structures are the free BB term and g1 BBB/Bxx vertices.
It has no a,C,Lambda or nonminimal source. The full matter source
conjugates remain zero in this projection. A physical/matter loop cannot
connect to K_g0's ghost root with one g1 link; K_g1's bosonic root
already costs g1 and has no source-Ja bosonic g0 return. Scalar and
matter loops are excluded by this coupling/block argument, not by
setting their masses or tadpoles to zero.

## Nonlinear means and the tadpole branch

At g0 the exact source endpoints are in B/Lambda. The ghost-free
original nonminimal action and U_g0 are quadratic, and K_g0 is affine.
The g0 scalar sector is independent of B/Lambda on this reference;
its possible interacting scalar Hessian and tadpoles are retained.

G1 bilinear source/reference roots mix only a scalar with B/Lambda.
K_g1 has296 affine scalar positions. Thus the g1 correction to a FIRST
endpoint may be scalar. This does not make a g1 mixed scalar mean:
in a g0 scalar nonlinear vertex the other g0 endpoint would be B/Lambda,
which has no such port. The ghost g0 nonlinear vertices also have no
return on zero ghost means and these even endpoints. Direct derivative
checks of all g1 nonminimal/probe cubic and Ja-quadratic vertices show
that the mixed forcing outputs only B or Lambda; K_g1's quadratic
endpoint outputs B. The physical BBB term also outputs B, while Bxx
cannot consume two B/Lambda endpoints. This exhausts the source-degree
two forcing, including first-u changes. The mixed mean itself has NOT
been shown zero: only its field support is bounded.

The one-loop reference g0 B tadpole has no cubic return: the physical
vector action is free at g0 and nonminimal g0 ghost backgrounds involve
Lambda, not B. The Lambda tadpole has only the actual Ca mass return.
All45 matrices are retained before the free color-diagonal trace. All45
traces vanish. Replay GF differentiation independently checks these
traces with600 off-diagonal ghost positions retained. Adding a diagonal
mass entry changes the trace; deleting an off-diagonal entry alone is
not a valid sensitivity test for this contraction.

Consequently the g0 reference tadpole contracted with the g1 mixed
mean is zero by its ACTUAL field support and trace. The g1 tadpole
multiplies WPC's proved zero g0 mixed mean. Unknown scalar tadpoles
multiply a zero scalar mixed response at this order. No scalar or
auxiliary tadpole normalization has been selected. The arbitrary finite
parent-A tadpole is not covered by this reference trace argument.

Likewise a scalar g1 FIRST endpoint cannot enter a g0 mixed proper
kernel: K_g0 and the other g0 source endpoint lie in the nonminimal/
ghost block, which decouples from scalars. Together with the proper
zero, these facts reduce the remaining three Legendre mean branches
to the ghost determinant evaluated on the actual g0 means. K_g1's BB
tadpole is source independent at this order; a further returning g1
vertex would cost g2. This is the completeness argument for the next
calculation, rather than the assumption that the ghost determinant
represents every general product.

## Complete remaining connected integrand

For each color with selected-probe indicator Pi, use the WPC stationary
equations including the source-only contacts:

    y=E Ja-u Pi Omega E(1-E)Ja-Omega E theta/2,
    Lambda=2i u Pi E(1-E)Ja+i E theta,
    B(k)=-i k y(k)/k^2.

The theta,Ja source contacts in the primitive and -u Pi Ja^2 in U
were retained in deriving these endpoints. The u theta response is
zero by the exact Gaussian inverse, not a quantum tadpole condition.
All background ghost-pair terms from the actual S and U at g0/g1 are
substituted. Quartic ghosts vanish in the quadratic ghost form at
zero ordinary ghost mean; excluded-source or scalar-background terms
are counted rather than treated as absent from the parent action.
The direct theta L_s primitive is then included. Derivatives on a,C,
B,Lambda and Ja retain their Fourier momenta and signs.

Native computation keeps exact external heat powers and Laurent
monomials in p=(P,0,0,0), q=(Q,R,0,0). This plane represents generic
two-momentum Euclidean scalar kinematics. Powers of1/P arise solely
from known external vector responses; no inverse coupling is used.
For a ghost vertex with external P_ext, the C momentum is q and the
a momentum is -q-P_ext. The second bubble vertex has external -p
and C momentum q+p. Both ordered inverse terms are included with
their one-half weight. Their equality uses the explicit q relabeling
in the absolutely convergent positive-heat expression and the finite
color trace, not an unqualified infinite-trace cyclic rearrangement.

At target degree u*g1*theta*Ja the ghost determinant contains at most
two marked vertices, because its unmarked u ghost Hessian is zero.
The connected term has a bubble and a direct one-ghost-propagator
contact, with signs respectively minus and plus from W1=-Gamma1,
Gamma1_ghost=-Tr log M. The contact numerator vanishes at ALL2970
positions after exact color/ordered-derivative summation, BEFORE its
power-sensitive integral. No scaleless tadpole has been assigned zero.
The complete bubble numerator reduces to C E(1-E)^2, with all P,Q,R
dependence canceling exactly. The internal positive heat factors and
q^2(q+p)^2 denominator remain, yielding the stated Pi_t kernel.

The independent replay route differentiates the action with LEFT a
then LEFT C derivatives before substituting the means. It derives the
g0 stationary response by multiplying the actual2x2 Gaussian inverse
and the full u/source Hessian, not by copying endpoint expressions.
It evaluates all2970 positions at three exact rational four-momentum
pairs, including p and q with components outside the native plane,
and applies q+p directly rather than the native polynomial shift.
All8910 comparisons agree, including zero contacts and the zero
complement. Removing the primitive root changes57 positions; omitting
the u-changed means changes57. Finite Berezin normalization and the
paired odd-marker sign are inherited from WPC's separately qualified
action-based tests; no new general Grassmann Hessian theorem is claimed.

Only after this derivation are the C coefficients compared with WPC:
C=-T_WPC/2 at every position. No quantum coefficient was fitted.

## UV, finite normalization and common IR domain

Reuse the authenticated two-positive-heat bubble:

    Pi_t(p)=B(2t p_E^2)/(16pi^2),
    Pi_t=[-log(t p_E^2)-gamma_E+1-2log2+o(1)]/(16pi^2).

The new external factor E(1-E)^2=O(t^2 p_E^4) suppresses the UV
logarithm. Hence the complete connected reference has zero logarithmic
and finite part in Schwartz pairing, even though it is nonzero at
finite heat. There is no surviving power term because the contact
numerator is already identically zero. Numeric finite-heat controls
are positive and nonzero, and approach zero; they are diagnostics,
not a physical parameter choice or a proof replacing the analytic bound.

For the WPC auxiliary proof family f_delta=(1-exp(-p^2/delta^2))^2,
F=fE, the stationary Gaussian formulas refer to that auxiliary free
covariance. They do NOT assert the physical fixed-R inverse identity
at finite delta: H_t(fE G0)=f I, with nonzero defect1-f. The complete
UV parent subtraction is transported through the SAME mean before
the IR limit. After its UV finite part, the exterior factor becomes
f(1-f)^2 and is generally NONZERO at finite delta. Pi_FP,delta(0)
remains the nonzero WPC value

    [log(mu^2/delta^2)+4log3-10log2]/(16pi^2).

At p=delta v, the profiled bubble is logarithmically bounded in delta
and v, while1-f=2exp(-v^2)-exp(-2v^2). Thus Schwartz pairing of this
complete reference kernel is O(delta^4(1+abs(log delta))) and tends
to zero. Endpoint inverse/source-defect differences carry1-f with
the same localization after the actual denominators have canceled.
This inherits WPC's joint locally-integrable bubble proof and its
UV-FP-before-IR order; it does not interchange zero-momentum values,
invent an independent sewn subtraction or identify the IR freedom
with a spacetime UV contact. In the unprofiled case split bounded p
from the Schwartz tail and use the O(t^2 p^4) factor and bubble bounds.

For general finite A keep the complete expression

    -[A_ij+A_i,phi[y_j]+A_j,phi[y_i]
       +A_phi,phi[y_i,y_j]+A_phi[y_ij]].

Unlike g0, y_ij at g1 is not assigned zero. In particular A's B/Lambda
first jets need not satisfy the reference loop trace argument. No
finite normalization or relation among kappa,b0,chi4 has been chosen.
The reference zero is not a complete finite-normalization Ward theorem.

## Execution, errors and result-to-claim boundary

Support V1 failed because it rejected an off-diagonal Ca entry before
the free color trace; V2 retains the entire block and then contracts
its diagonal. Kernel V1's FIRST actual exception was unsupported
Coeff exponentiation in a jet phase. The V2 record also identified a
potential Fraction multiplication issue before it was reached; its
description of Fraction as the first failure is imprecise. The exact
capture and sources are preserved and control the classification.
V2 uses explicit constant coefficients and exact repeated products.
Neither failed execution is PASS and no physical input changed.

Support V2 8.949381s, kernel V2 8.625411s, independent review27.043355s
afterimports. All within180s/8GiB sampled/350MiB launch/16MiB packet.
These are shared-action/library/regulator/AIauthor internal results,
not independent scientists, external mathematical endorsement or new
experimental support. They qualify an actual next-order reference
kernel and its common limit. They do not qualify arbitrary finite A,
the whole quantum Ward equation, multiple products, measure/global
phase, QAP/E5/A5 or the physical Spin(10) hypothesis.

Next assess the finite-parent normalization/transport equation using
both actual g0 and g1 primitive results, before automatically expanding
g2 or295 vector profiles. If the target identity genuinely requires a
higher-order primitive coefficient, derive its exact support and the
new tadpole contractions first; the present zeros cannot be imported.
