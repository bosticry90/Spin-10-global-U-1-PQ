from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-g1-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
    with p.open('xb') as f:f.write(blob)
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='0c569a88bf05e92a4299fc75cfabf7ee6ed7011e'
    C.mkdir(parents=True,exist_ok=True)
    with(C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD']))
    bindings={}
    names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
     'docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V677.md',
     'tools/portable_dh_v1/exact_algebra.py','calculations/canonical_so10_correlated_contact_lift/lift.py','calculations/canonical_so10_connected_contact_lift/lift_v2.py',
     'calculations/canonical_so10_full_jet_source_master_bridge/jets.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
     'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz','calculations/canonical_so10_mixed_Ward_positive_coupling/validation_receipt.json',
     'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz','calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz',
     'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json',
     'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']
    wpc=R/'calculations/canonical_so10_Ward_primitive_canonical';seal=read(wpc/'final_review_validation_receipt.json')
    for name,h in seal['new_files_sha256'].items():assert digest(R/name)==h,name
    names += [p.relative_to(R).as_posix() for p in wpc.iterdir() if p.name in ['canonical_tables.json.gz','quantum_tables.json.gz','final_review_validation_receipt.json','validation_receipt_v2.json','PROOF.md']]
    for name in names:
        p=R/name;assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+name]),name;bindings[str(p)]=digest(p)
    for p in list(O.iterdir()):
        if p.is_file():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    for p in O.iterdir():
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'preparation.json',{'base_HEAD':'0c569a88bf05e92a4299fc75cfabf7ee6ed7011e','input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'support.py')]);dump(O/'support_capture.json',cap);dump(C/'support_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED WPG actual next-order support',flush=True)
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
