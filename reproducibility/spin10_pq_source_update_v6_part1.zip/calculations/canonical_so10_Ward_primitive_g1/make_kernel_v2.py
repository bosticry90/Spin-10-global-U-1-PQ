from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'kernel.py').read_text()
assert src.count('J.times(I,om)*F(1,2)')==1 and src.count('(I*sg)**len(js)')==1
src=src.replace('J.times(I,om)*F(1,2)','J.times(J.times(I,om),J.constant(F(1,2)))').replace('(I*sg)**len(js)','cpow(I*sg,len(js))')
src=src.replace('Z=J.ZERO;ONE=J.constant(1);I=J.I','Z=J.ZERO;ONE=J.constant(1);I=J.I\ndef cpow(c,n):\n    out=ONE\n    for k in range(n):out=J.times(out,c)\n    return out\nassert cpow(I,0)==ONE and cpow(I,2)==-ONE and J.times(J.constant(F(1,2)),J.constant(2))==ONE')
src=src.replace("O/'kernel_preparation.json'","O/'kernel_preparation_v2.json'").replace("O/'kernel_tables.json.gz'","O/'kernel_tables_v2.json.gz'").replace("O/'kernel_result.json'","O/'kernel_result_v2.json'")
with(O/'kernel_v2.py').open('xb') as f:f.write(src.encode())
src=(O/'run_kernel.py').read_text()
src=src.replace("read(O/'preparation_v2.json')","read(O/'kernel_preparation.json')")
src=src.replace("['KERNEL_RECORD.md','kernel.py','run_kernel.py']","['KERNEL_V2_RECORD.md','make_kernel_v2.py','kernel_v2.py','run_kernel_v2.py']")
src=src.replace("dump(O/'kernel_preparation.json'","dump(O/'kernel_preparation_v2.json'").replace("O/'kernel.py'","O/'kernel_v2.py'")
src=src.replace("O/'kernel_capture.json'","O/'kernel_capture_v2.json'").replace("C/'kernel_full_capture.json'","C/'kernel_full_capture_v2.json'")
src=src.replace("O/'kernel_controller_failure.json'","O/'kernel_controller_failure_v2.json'")
with(O/'run_kernel_v2.py').open('xb') as f:f.write(src.encode())
