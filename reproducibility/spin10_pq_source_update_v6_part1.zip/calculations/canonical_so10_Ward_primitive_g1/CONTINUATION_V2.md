# WPG V2: complete ghost block before trace contraction

V1 FAILED after both proper-root inventories at the auxiliary tadpole
support assertion. It incorrectly rejected an off-diagonal Ca vertex
instead of retaining the full ghost matrix and then taking its diagonal
free-propagator contraction. Exact first rejected word:Lambda520's
C566,a612. This is an implementation error in the contraction test,
not a physical exclusion or failed symmetry gate. Preserve all V1
source bytes and complete capture/controller failure as FAILED.

V2 retains every ordinary ghost-pair entry, checks their derivative/type
support, and contracts only equal free ghost colors for the trace.
All other scientific obligations and180s/8GiB/350MiB/16MiB limits are
unchanged. No old input/receipt is rebound. No zero tadpole is imposed.
