# V1093 exchanged H Euler closure

Both literal charts give 334 source rows in each of the
two opposite F_B assignments. The H mixed closure stays
nonzero at eta_H=0, when the old ordinary H carrier
vanishes. It reduces to a distinct decorated lower
product. Its hard term has a log clock and no positive
heat jet on this projection.

The complete grouped increment is constrained when both
normalized Euler equations and lower products are fixed.
This does not yet determine the individual arms.
See [proof](PROOF.md).
