"""Verify the exchanged H Euler assignment of the charged F-master."""
from importlib.util import module_from_spec, spec_from_file_location
import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT/"calculations"
r = sp.Rational


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal(phase):
    flat = load("equal_profile_higher_root_v1","yy_equal_profile_higher_root")
    f,_,_,_ = flat.color_operands(phase)
    ports = flat.ordinary.ports
    path = C/"canonical_so10_unprobed_compact_all_coupling_v1"/f"{phase}_full_current.json.gz"
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        rows = json.load(stream)["current"]["complete_S_GF_source"]
    L,H = {},{}
    for g,word,cells in rows:
        if g!=1 or len(word)!=3:
            continue
        (i,di),(j,dj),(k,dk) = word
        if not (i<180 and 565<=j<598 and 643<=k<823 and i%4==(k-643)%4==0):
            continue
        a,c,b = i//4,j-553,(k-643)//4
        if (a<12)==(b<12):
            continue
        assert not (di or dj or dk)
        z = -ports.decode(cells,1,False)
        if a<12:
            L[a,c,b] = z
        else:
            H[b,c,a] = z
    assert len(L)==len(H)==334 and L.keys()==H.keys()
    assert all(L[h,c,b]==dict(f[h,c])[b]==-H[h,c,b] for h,c,b in L)
    return [len(L),len(H)]


def matrix(value):
    return value.applyfunc(sp.cancel)


def h_closure():
    source = load("split_mixed_reference_contact_v1","yy_split_mixed_reference_contact")
    p,q = sp.Matrix([2,0,0,0]),sp.Matrix([0,1,0,0])
    hp,hq,hH,eta = sp.symbols("h_p h_q h_H eta_H",nonzero=True)
    Kp,Kq = source.K(p,0),source.K(q,0)
    Cp,Cq = hp*source.G(p,0),hq*source.G(q,0)
    CH = hH*source.G(-q,eta)
    KH = source.K(-q,eta)
    D = Kq-Kp
    cov = Cq-Cp
    flat = -Cp*D*Cq
    reg = -Cp*((1/hq-1)*Kq-(1/hp-1)*Kp)*Cq
    assert matrix(KH*CH)==hH*sp.eye(5)
    assert matrix(KH[:4,:4]*CH[:4,:4]*q)==sp.zeros(4,1)
    assert matrix(KH[:4,4:]*CH[4:,:4]*q)==hH*q
    assert matrix(CH[:4,:4]*q)==hH*eta*q
    lower = Cp[:4,:4]*(p-q)
    assert matrix(cov[:4,:4]*q)==matrix(lower)
    assert matrix(flat[:4,:4]*q)==matrix(hq*lower)
    assert matrix(reg[:4,:4]*q)==matrix((1-hq)*lower)
    missing = matrix(-hH*reg[:4,:4]*q)
    sub = {hp:r(225,4096),hq:r(1,8),hH:r(1,8),eta:0}
    sample = matrix(missing.subs(sub))
    assert sample==r(1575,1048576)*q
    L = matrix((reg*Kq)[:4,:4]*CH[:4,:4]*q)
    assert matrix(L.subs(sub))==sp.zeros(4,1)
    return list(map(str,sample))


def colors():
    path = C/"canonical_so10_YY_charged_mixed_master_companions_v1/result.json"
    old = json.loads(path.read_bytes())["checks"]
    F = sp.Matrix(list(map(r,old["F_master_increment_before_stored_sign"])))
    K = F/(-r(15,8))
    H = -r(3,4)*K
    both = -r(5,4)*K
    assert H==sp.Matrix([0,r(19,6680),-r(19,13360)])
    assert both==sp.Matrix([0,r(19,4008),-r(19,8016)])
    return [list(map(str,v)) for v in (H,both)]


def check(phase):
    trace = (sp.eye(4)-sp.diag(1,0,0,0)).trace()/4
    assert trace==r(3,4)
    return {"literal_L_and_H_euler_sources":literal(phase),
            "omitted_H_closure_at_eta_zero":h_closure(),
            "strict_H_and_total_eta_one_before_stored_sign":colors(),
            "H_hard_angular_trace":"3/4",
            "H_hard_log_coefficient_in_right_orientation":"3/8",
            "independent_F_increment_at_fixed_complete_lowers":"0"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
