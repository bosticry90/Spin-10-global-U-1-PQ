# Exchanged H Euler on the charged F-master split

Retain the V1086 X quartic and the ordinary ghost at G.
The literal F_B source has two returning assignments.
In one its B_H returns to G and its Euler acts on L.
In the other its B_L returns to the charged cut and
its Euler acts on H. The two f coefficients are
opposite. Both archived charts reproduce 334 rows
per assignment at the selected polarization.

The H mixed assignment puts the Lambda at the master
F, and G still supplies its literal B_H. The center
reference acts trivially on H itself. Its differentiated
contribution comes from the remaining charged split.
In the right ordered convention the combined BB-source
Euler is

    [C'_L K_q]_BB C_H,BB - C'_L,BB [K_H C_H]_BB.

The second term reduces to -H_H C'_L,BB. For the
ordinary G ghost derivative on the unjetted projection
its contracted vector is parallel to the H momentum.
The H Maxwell arm is then transverse and the mixed
arm alone supplies H_H times that vector. In the
chosen orientation use that vector q.

At broken width zero the charged covariant difference
obeys C'_L,BB q=C_p,BB(p-q). The fixed-flat term is
h_q C_p,BB(p-q). The regulator is the same expression
with factor 1-h_q. This is a lower transverse product
with its removed H profile still attached. It remains
nonzero in the exact eta_H=0 fixture. The old L Euler
on the ordinary H closure vanishes in that fixture.
Keeping only the old ordinary H path loses a
contribution.

The L compensation has two lower products. Its
Maxwell part retains L BB, L ghost and H BB. Its
auxiliary part has L B Lambda in place of L BB.
The H collapse reduces to a lower L BB and ghost
word, decorated by the H profile and the extra
charged flat factor. The H hard difference is
+3/8 times the three-to-four log in right radial
units. No positive heat jet is generated here
because p-q already supplies the first transfer.
Changing the sign to V1086 exterior units gives
the strict H angular factor -3/4. The saved
literal color is nonblind on both mixed pivots.

Holding all these lower products and the regulator
dictionary fixed while preserving both complete
Euler equations forces zero independent change in
the grouped F contribution. This does not fix the
individual arms separately. The separate H mixed
normalized equation needs its own check before
using it to constrain the allocation of V1086.
The shared action and numerical conventions remain
assumptions of both replays.
