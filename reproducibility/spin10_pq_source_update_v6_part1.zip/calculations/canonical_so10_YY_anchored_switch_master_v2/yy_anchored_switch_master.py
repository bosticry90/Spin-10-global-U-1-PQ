"""Check the full lower switch-jet transfer of the enlarged map."""

import sys

import sympy as sp

from execute import run_worker


def local():
    u = sp.Symbol("u")
    s,x,c = (sp.Function(v)(u) for v in ("sigma","X","c"))
    C,M,L,d,e,b,h,lam,omega = sp.symbols("C M L d e b h lambda omega",real=True)
    k = 2*C-8
    nu = k/(2*C)
    gamma = lam-b
    c0 = e+nu*d-M*lam
    S = s*s-s
    source_B = lam*s*(-x.diff(u,2)+(M+s*d+s.diff(u,2)/2)*x)
    source_N = (lam*s.diff(u)*x.diff(u)+gamma*(s.diff(u)*x).diff(u)
                +b*(S*x.diff(u)).diff(u)+gamma*(S*x).diff(u,2)+c0*S*x)
    source = -k*s*(source_B-source_N)
    mixed = (-2*C*s*(c0*s*s*x+gamma*s*s.diff(u,2)*x+b*(s*s.diff(u)).diff(u)*x)
             +2*(2*C-4)*b*((s*s*s.diff(u)*x).diff(u)-s*s.diff(u)**2*x))

    coefficient = k*lam*s*s*x.diff(u)+omega*s*s.diff(u)*x
    direct_F = s*s*c.diff(u)
    inverse_F = (s*s-s)*c.diff(u)-s.diff(u)*c
    assert sp.expand(direct_F-inverse_F-(s*c).diff(u))==0
    tri_F = -s*coefficient.diff(u)
    boundary = -4*C*h*s**3*s.diff(u,2)*x
    tri_mass = -8*C*h*s**4*d*x
    total = source+mixed+tri_F+boundary+tri_mass

    terms = [2*k*lam+8*b-omega,(C-12)*lam+8*b-omega,
             k*(2*lam-b)-omega,-4*C*h]
    jets = [s*s*s.diff(u)*x.diff(u),s*s*s.diff(u,2)*x,
            s*s.diff(u)**2*x,s**3*s.diff(u,2)*x]
    constant = (-k*e*s*s*(1-s)+k*d*s*s*(1-s)*((L-1)*s-nu))*x
    partial = {h:k*(L-1)/(8*C),lam:-L}
    complete = partial | {e:-4*M*L/C}
    difference = total-constant-sum(a*z for a,z in zip(terms,jets))
    assert sp.simplify(difference.subs(partial)+2*(C*e+4*L*M)*x*s**3)==0
    assert sp.simplify(difference.subs(complete))==0
    unit = total.subs({s:1,s.diff(u):0,s.diff(u,2):0},simultaneous=True)
    assert sp.simplify(unit.subs(complete))==0
    assert sp.expand(terms[0]-terms[1]-(3*C-4)*lam)==0

    # Keep both placements nonblind against loss of either literal switch term.
    explicit_F = coefficient*(direct_F-inverse_F)
    assert sp.expand(explicit_F-c*tri_F-(coefficient*s*c).diff(u))==0
    assert sp.expand(explicit_F-coefficient*s*c.diff(u))!=0
    assert sp.expand(total-(total-boundary))!=0
    assert [3*v-4 for v in (sp.Integer(10),sp.Rational(25,2))]==[26,sp.Rational(67,2)]
    return {"plateau_and_unit_specialization_match":True,
            "full_F_inverse_switch_derivative_required":True,
            "third_quadratic_switch_hessian_required":True,
            "gradient_difference_over_orbit":"(3*C-4)*lambda",
            "gradient_difference_Casimir_factors":["26","67/2"],
            "scalar_second_derivative_only_cancels":True}


def check(phase):
    return local()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
