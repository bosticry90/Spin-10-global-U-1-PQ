# V1012 pre-execution contract

Freeze V1011, V1010, V1006,
V1005, V1004, V1001 and
V893. Complete the selected
variable-switch g³ xi xC
master of the enlarged
trial map through first
physical mass difference.
Retain the literal third
slot quadratic boundary
and the full inverse
kinetic current. Allow any
Lorentz-covariant lower
trace split that preserves
the scalar p² collapse and
the V1011 plateau tuning.
Require independent local
expansion, plateau and
missing-term controls.
No higher-sector or
global restoration claim.

Native 120 s, final 180 s,
E4 120 s, 8 GiB sampled private,
350 MiB launch floor,
8 MiB artifact, 32 MiB packet.

Native v1 left the V1003
profile constraint on e
unsubstituted, despite
freezing it in the proof.
The exact leftover was
-2(C e+4 L M) X sigma^3.
Preserve the complete
failed packet. V2 checks
that leftover as a
negative control and
applies the originally
declared e=-4ML/C in
the target checks.
No proof assumption,
input, tolerance or
resource limit changed.
