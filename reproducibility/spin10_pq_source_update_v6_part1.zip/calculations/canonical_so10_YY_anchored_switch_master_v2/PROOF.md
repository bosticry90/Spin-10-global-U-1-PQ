# Variable-switch master of the enlarged mass triangle map

Use the V1011
map at fixed
reference M,
zero background
and one physical
mass difference
d=m-M.
Keep lambda=-L,
k=2 C_s-8,
nu=k/(2 C_s),
h_3=k(L-1)/(8 C_s)
and e=-4ML/C_s.
Let X=E^t x
in each ghost
color and
write c for
the external
ghost.
Strip g³ xi
and common
loop units.

The two lower
T2 derivative
weights obey
a+b=lambda.
The scalar
collapse
p² change is
alpha=a-gamma,
where gamma
is the cross
trace weight.
For any plateau
t the scalar
collapse
contributes
-k alpha
t²(1-t)p².
The tuned T3
kinetic direction
has t³
after its
inverse
placement.
Hence
cancellation
of the p²
term at
every plateau
requires
alpha=0.
Then gamma=a
=lambda-b.
The symmetric
V1004 choice
has b=gamma
=lambda/2,
but we keep
b arbitrary.
The tagged
zero jet
is e+nu d.

## The returning inverse and the third quadratic slot

The V1011
ordinary Bx
map applied
to the F
vertex with
external
vector label U
is, after
integration
by parts,

    ∫ U.[tau sigma² ∂X
                   + omega sigma (∂sigma) X],

where
tau=k lambda
after tuning
w and
omega=-4(C_s-4)h_3.
The K and M
inputs carry
their separate
switches,
here equal.
For the
ordinary F
slot U=sigma B.
Its direct
master image
has
U=sigma² ∂c.

In the
inverse master
term the
actual V1001
scalar current
has

    U=(sigma²-sigma)∂c-(∂sigma)c.

The second
term is
required
by the
literal
switched
scalar
Euler. Their
difference
is
∂(sigma c).
The net
kinetic
triangle
contribution
is consequently

    -∫ sigma c div[
       tau sigma² ∂X
                       +omega sigma(∂sigma) X].

The reference
split also
gives a
literal scalar
quadratic third
slot with
Hessian

    sigma d + (Laplace sigma)/2.

The second
term is the
V893 difference
of the
kinetic
density
and its
Euler-normal
reference.
The ordinary
one-port
from the
same rank-two
contact is
-8 C_s h_3
times sigma²
and that
Hessian
multiplying
v_s^t x.
Its direct
master image
adds

    -8 C_s h_3
      sigma³ [sigma d+(Laplace sigma)/2] X c.

The compact
K replacement
with BxxC
has no
contracted
scalar derivative.
If F is
quadratic,
the relative
derivative
rank is one,
from the
mixed edge.
The finite
triangle
change at
that rank
is zero
by V1009.
The M
replacement
Lambda x C
is zero in
the literal
grade by
V999.
A higher
potential
third slot
leaves too
many scalar
means for
this lower
projection.
These support
checks retain
the full
g³ xi xC
part of the
specified map.

## The residual in independent switch jets

Add the
scalar–ghost
source and
mixed T2
terms of
V1006 with
gamma=lambda-b
and the
tagged e.
The second
derivative
of X alone
cancels.
The constant
coefficient
is the
V1011 plateau
result,

    -k e sigma²(1-sigma)
      +k d sigma²(1-sigma)
                         [(L-1)sigma-nu].

There are
four remaining
switch-jet
coefficients.
In the order

    sigma² (∂sigma).∂X,
    sigma² (Laplace sigma) X,
    sigma |∂sigma|² X,
    sigma³ (Laplace sigma) X,

they are

    2 k lambda + 8 b - omega,
    (C_s-12) lambda + 8 b - omega,
    k(2 lambda-b)-omega,
    -4 C_s h_3.

The fourth
is the
literal
quadratic
third slot.
It would be
lost if the
kinetic
densities
were equated
before
switching.
If the
gradient of
the F
inverse
current is
omitted,
the difference
of the
vector
labels is
only
sigma ∂c
rather than
∂(sigma c),
and the
local jet
comparison
changes.

Subtracting
the second
coefficient
from the
first gives

    (3 C_s-4) lambda.

It is independent
of b and
omega.
The local
jets of
sigma, X
and the
ghost test
can be
varied
independently
on a small
patch.
The sigma²
and sigma³
Laplace
coefficients
are distinct
under changes
of the
constant
part of
sigma.
Thus this
trial map
cannot remove
all switch
gradients
while
canceling the
plateau
kinetic term
in both
blocks.
At distinct
reference
masses at
least one
lambda is
nonzero,
and both
Casimirs
satisfy
3 C_s-4>0.

This is a
nonzero
transported
compact
master
direction,
consistent
with a
zero unit
specialization.
It does
not impose
a homogeneous
master at
nonunit
switch.
A comparison
with the
full marked,
source and
background
operators
remains
necessary.
No mass
weak-limit
extension or
authority
change.
The routes
share
the action
and symbolic
software.
