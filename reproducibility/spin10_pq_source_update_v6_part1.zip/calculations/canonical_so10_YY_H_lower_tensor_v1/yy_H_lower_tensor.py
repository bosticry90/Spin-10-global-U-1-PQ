"""Recover the H-collapse lower tensor in the inherited CSP1 member."""
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"
r = sp.Rational


def tensor():
    x = sp.symbols("x",positive=True)
    k = sp.symbols("k",positive=True)
    P = sp.symbols("P",positive=True)
    Delta = x*(1-x)*P
    feynman = sp.cancel(2*x*(1-x)**2*P/(2*Delta))
    assert feynman==1-x
    A = sp.integrate(feynman,(x,0,1))

    # With the external momentum set to a unit direction, the
    # anisotropy is a pure U_2 spherical projection.
    u = sp.symbols("u",real=True)
    U2 = sp.chebyshevu(2,u)
    assert sp.expand(u**2-(1-u**2)/3-U2/3)==0
    normalized_overlap = sp.integrate(U2**2*sp.sqrt(1-u**2),(u,-1,1))*2/sp.pi
    assert normalized_overlap==1
    below = sp.integrate(2*k**3*normalized_overlap/3,(k,0,1))
    above = sp.integrate(2*normalized_overlap/(3*k**3),(k,1,sp.oo))
    assert (below,above)==(r(1,6),r(1,3))
    B = below+above
    assert A==B==r(1,2)
    B0,xi = sp.symbols("B0 xi")
    base = B0+(xi-1)*(B0-A)/4
    axis = (xi-1)*A
    assert sp.expand(4*base+axis-(3+xi)*B0)==0
    assert sp.diff(base,B0)==(3+xi)/4
    return {"anisotropic_by_two_routes":[str(A),str(B)],
            "broken_zero_isotropic":str(base.subs(xi,0)),
            "broken_zero_longitudinal_difference":str(axis.subs(xi,0))}


def clocks():
    h,l = sp.symbols("ell_H ell_L",positive=True)
    c2,c3,c4 = 2*l,2*l+h,3*l+h
    mu,kappa,P = sp.symbols("mu kappa P",positive=True)
    base = sp.log(mu**2/P)-sp.EulerGamma+1-sp.log(c2)+kappa
    original = sp.log(mu**2/P)-sp.EulerGamma+1-sp.log(4)+kappa
    assert sp.simplify(base-original+sp.log(c2/4))==0
    extra = [-r(3,4)*sp.log(c/c2) for c in (c3,c4)]
    assert sp.simplify(extra[0]-extra[1]-r(3,4)*sp.log(c4/c3))==0
    assert sp.simplify(((extra[0]-extra[1])/2).subs({h:1,l:1})-r(3,8)*sp.log(r(4,3)))==0
    return {"equal_length_UV_offsets_over_delta":
            [str(v.subs({h:1,l:1})) for v in extra],
            "removed_H_profile_clock_log_residue":"3/4"}


def check(phase):
    owner = (C/"canonical_so10_causal_second_product"/"DERIVATION.md").read_text(encoding="utf-8")
    assert "COMPLETE HMM1" in owner and "c=4" in owner
    assert "gamma_E+1-2log2+kappa" in owner
    h = json.loads((C/"canonical_so10_YY_F_endpoint_allocation_v2"/"result.json").read_bytes())["checks"]
    assert h["balanced_contact_projection"]=="3/4"
    return {**tensor(),**clocks()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
