# Absolute H-collapse lower tensor

In the inherited CSP1 member the width-zero
lower B B and ghost tensor, in stripped
1/(16 pi^2) units, is

    (3 B0/4+1/8) delta - (1/2) p p^T/p^2,

where B0 is log(mu^2/p^2)-gamma_E+1-log(2 ell_L)
plus the common symbolic kappa. Two distinct
calculations give the longitudinal difference.

The covariant and fixed-flat attachments change
only the isotropic coefficient by their known
clock logarithms. This reproduces the V1093
covariant-minus-flat shift. The inherited lower
value is fixed within this member. V1094's
separate composite normalization condition still
requires its own common-map equation.
