# Inherited transverse lower tensor for the exchanged H collapse

Use the V1093 H projection with its common chart,
color and Wick phase stripped. The lower word has
one charged B B inverse and one charged ghost
inverse. At nonexceptional Euclidean transfer p,
write P=p.p and strip the common 1/(16 pi^2).
The width-zero B B numerator is the transverse
projector on the B momentum k. The two denominators
are k^2 and (k+p)^2. The scalar part is the CSP1
matched massless bubble. CSP1 section 2 fixes its
extension for all actual components via the
complete HMM1 comparison and the causal boundary.
CSP1 section 5 gives the common scalar member at
clock 4. The relative clock change of V976 is
minus log(c/4) on its finite bracket. Thus for
c=2 ell_L the lower scalar bracket is

    B0 = log(mu^2/P)-gamma_E+1-log(2 ell_L)+kappa.

Kappa remains the common symbolic member. This
calculation uses the Euclidean bracket and does
not absorb the causal boundary or outer chart
factor into its coefficient.

The tensor to subtract is the finite part of
k_mu k_nu/[k^4 (k+p)^2]. Its exact trace equals
the scalar bubble before finite part. The
coefficient of p_mu p_nu/P is one half. To
calculate it, use the parameter denominator
x k^2+(1-x)(k+p)^2 and shift k by (1-x)p.
The anisotropic term is convergent after
projection. The shifted numerator contributes
(1-x)^2 p_mu p_nu, the scalar cubed denominator
gives 1/[2 x(1-x)P], and the parameter
measure is 2 x dx. The coefficient reduces
to the integral of 1-x. Any correction to the
shift in the UV divergent isotropic piece
is handled by matching the exact trace.

An independent anisotropy calculation puts
p on a unit axis. The difference of the
longitudinal and one transverse angular
numerator is U_2(cos theta)/3. The angular
expansion of the other denominator has
degree-two coefficient (min(r,1)/max(r,1))^2
divided by max(r,1)^2. Its overlap with U_2
under the normalized 4D measure is one.
The radial integrals below and above r=1
give 1/6 and 1/3. The UV cutoff can be removed
in this anisotropic comparison. With both
line arguments fixed, angular correction
from the shifted cutoff vanishes in the
UV limit and the paired IR limit is
nonexceptional as in V948. No coincident
pole limit is needed.

The absolute width-zero tensor is therefore

    (3 B0/4 + 1/8) delta_mu,nu - (1/2) p_mu p_nu/P.

The extra collapsed H profile changes the
isotropic part by -(3/4) log(c3/c2).
The extra flat charged profile changes it
by a further -(3/4) log(c4/c3). The three
clocks are c2=2 ell_L, c3=c2+ell_H, c4=c3+ell_L.
The finite anisotropic coefficient is the same
in all three. The V1093 covariant-minus-flat
coefficient is +(3/4) log(c4/c3) in dQ units,
equivalently +(3/8) log(c4/c3) in dr/r units.
The IR profiles and independent transferred
momenta are retained before the matched limit.
Removing the H profile would erase the
covariant offset against the undecorated lower
and change the fixed-flat comparison. The
original profile is part of the fixed operand.

This recovers the inherited lower value in
the specified member. A new balanced T4 local
contact can shift the composite equality at
this same lower value, as V1094 shows. The
linear free equation and Action Ward rule are
insufficient to fix that contact. The selected
H free Q0 preimage has a returning H antighost
at F and a returning H gauge field at G. Its
variation replaces the mixed return by a
ghost return. After the G derivative moves,
the ghost Euler is multiplied by other fields
at G, including a charged field that is still
contracted. This is a composite equation even
though the unheated free operator is linear.

Brennecke and Duetsch, Remark 5.1 and Theorem
5.2, distinguish the linear field equation
from possible local terms for composite
insertions. Duetsch and Boas derive a separate
condition for the composite in equation (95).
These comparisons explain the distinction.
They do not prove applicability of either full
theorem to the current source and compact
background domain. The actual common W3/W5
normalization remains open.

[Primary causal QAP source](https://arxiv.org/pdf/0801.1408)
[Primary Master Ward source](https://arxiv.org/pdf/hep-th/0111101)
