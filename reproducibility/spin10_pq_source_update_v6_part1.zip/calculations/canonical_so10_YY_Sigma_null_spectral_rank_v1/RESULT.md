# V1030 Sigma high-center null restriction

The high-center rank-12 spectral sector is in the kernel of the Sigma orbit map. Three actual auxiliary master rows on that sector are blind to every V1029 ghost projection and the older source and reverse triangles. They constrain the four Q weights independently of cross-species sharing.

Combining those rows with the five literal affine probes and the symbolic reference normalization gives exact ranks 5 and 6. The left witness returns 17. Thus the full tested spectral triangle family cannot repair Sigma through the previous gauge projector weights, even with independent scalar-edge coefficients.

A spectral projection on the internal mixed gauge edge is a separate candidate because its ordinary ghost image can survive these null auxiliary rows.
