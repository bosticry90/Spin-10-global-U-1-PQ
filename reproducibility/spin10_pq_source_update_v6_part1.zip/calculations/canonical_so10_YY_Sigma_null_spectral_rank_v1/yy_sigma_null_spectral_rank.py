"""Certify the Sigma null-orbit obstruction with independent scalar-edge weights."""
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import ROOT, run_worker


spec = importlib.util.spec_from_file_location(
    "spectral_owner",ROOT/"calculations/canonical_so10_YY_ghost_spectral_image_v1/yy_ghost_spectral_image.py")
spectral = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spectral)
ideal,owner,alg = spectral.ideal,spectral.owner,spectral.alg
ports = spectral.both.ports
r,zero = sp.Rational,sp.S.Zero
labels = ("M",0,2,3)


def orbit(E,v):
    return ideal.plus(*((z,E[k]) for k,z in v.items()))


def spectral_null(E,Q):
    for j in ideal.M:
        assert not orbit(E,spectral.sector_colors(Q,j))


def master(phase,rho,f,P,E,Q):
    cases = [({17:1,22:1},{13:1},172),
             ({17:1,22:1},{43:1},68),
             ({19:1,24:1},{17:1,22:-1},204)]
    for j,_,_ in cases:
        vector = sp.Matrix([j.get(k,zero) for k in ideal.M])
        assert Q*vector==vector and not orbit(E,j)
    def projection(d,h):
        if d=="M":
            return {h:1} if h in ideal.M else {}
        return {i:P[d][i,h] for i in ideal.H if P[d][i,h]} if h in ideal.H else {}
    paired = {(d,h,b):owner.act(rho,projection(d,h),E[b])
              for d,h,b in product(labels,owner.COLORS,ideal.M)}
    marked,_ = ports.raw_ports(phase,f)
    for j,_,_ in cases:
        for d in labels:
            terms = [(j[e]*z,paired[d,h,b]) for (h,b,e,mu),z in marked.items() if mu==0 and e in j]
            assert not ideal.plus(*terms)
    raw = alg.read(ports.CALC/"canonical_so10_unprobed_compact_all_coupling_v1"/
                   f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    sums = [[zero]*4 for _ in cases]
    for g,word,cells in raw:
        if g!=2 or len(word)!=4:
            continue
        (p,_),(q,_),(c,_),(a,_) = word
        if q>=180 or not 553<=c<598 or not 598<=a<643 or p%4:
            continue
        a,c = a-598,c-553
        for n,(j,ghost,x) in enumerate(cases):
            if a not in j or c not in ghost:
                continue
            assert q%4==0 and all(not jets for _,jets in word)
            z = r(4,3)*j[a]*ghost[c]*ports.decode(cells,2,False)
            for h,b in ((p//4,q//4),(q//4,p//4)):
                if b in ideal.M:
                    for k,d in enumerate(labels):
                        sums[n][k] += z*paired[d,h,b].get(x,zero)
    rows = [[sp.expand(z) for z in row] for row in sums]
    assert [row[0] for row in rows]==[sp.sqrt(30)/30,sp.sqrt(30)/60,-2*sp.sqrt(15)/15]
    return [[sp.cancel(z/row[0]) for z in row] for row in rows]

def affine(ad,P,K,sectors,rho,E):
    center = {h:6*P[0][h,0] for h in ideal.H if P[0][h,0]}
    assert P[2][:,9] == sp.eye(12)[:,9]
    assert P[3][:,1] == sp.eye(12)[:,1]
    probes = [(center,{43:1},2,205,3*sp.sqrt(6)/20,0,0),
              (center,{13:1},1,137,-sp.sqrt(6)/10,0,0),
              (center,{17:1,22:-1},3,73,sp.sqrt(3)/20,0,0),
              ({9:1},{17:1,22:-1},3,73,-sp.sqrt(30)/40,2,0),
              ({1:1},{17:1,22:-1},3,172,-sp.sqrt(30)/40,0,3)]
    rows = []
    for h,b,sector,x,expected,v2,v3 in probes:
        vec = sp.Matrix([b.get(k,zero) for k in ideal.M])
        assert sectors[sector]*vec==vec
        U = owner.act(rho,h,orbit(E,b))
        assert U[x]==expected
        transfer = sum((z*ad[k][12:,12:]*vec for k,z in h.items()),sp.zeros(33,1))
        def to_orbit(column):
            return orbit(E,{c:column[c-12] for c in ideal.M if column[c-12]})
        assert to_orbit(transfer)==U
        row = [sp.cancel(to_orbit(K[i]*transfer).get(x,zero)/U[x]) for i in ideal.spectra]
        rows.append(row+[v2,v3])
    A = sp.Matrix(rows)
    coeff = A.inv()*sp.ones(5,1)
    assert coeff == sp.Matrix([r(5,3),r(5,9),r(5,12),0,0])
    return [str(z) for z in coeff]


def check(phase):
    vacuum,_,rho,f,_,_ = owner.inputs(phase)
    ad,P = ideal.projectors(f)
    K,sectors,_ = spectral.spectral(ad,P)
    v = {i:z for i,z in vacuum.items() if 54<=i<306}
    E = {a:alg.apply(rho[a],v) for a in owner.COLORS}
    spectral_null(E,sectors[4])
    rows = master(phase,rho,f,P,E,sectors[4])
    coeff = affine(ad,P,K,sectors,rho,E)
    L = sp.Symbol("L")
    Cs = r(25,2)
    k = 2*Cs-8
    q = k*(L-1)/Cs
    d = -q*(2*Cs-10)+k*L
    assert sp.expand(d-(17-r(5,2)*q))==0
    M = sp.Matrix([row+[0] for row in rows]+[
        [-1,0,1,0,r(5,27)],[-1,0,0,1,r(5,36)],[r(5,2),0,0,0,1]])
    rhs = sp.Matrix([0,0,0,0,0,17])
    w = sp.Matrix(list(map(r,("-89/2","287/20","122/5","-237/20","43/5","1"))))
    assert M.T*w==sp.zeros(5,1) and (w.T*rhs)[0]==17
    ranks = [M.rank(),M.row_join(rhs).rank()]
    assert ranks==[5,6]
    return {"normalized_null_master_rows":[[str(z) for z in row] for row in rows],
            "Sigma_null_spectral_rank":sectors[4].rank(),
            "affine_ideal_coefficients":coeff,"rank_and_augmented":ranks,
            "left_witness_value":str((w.T*rhs)[0]),
            "all_spectral_triangles_blind":True,
            "scalar_edge_weights_independent":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
