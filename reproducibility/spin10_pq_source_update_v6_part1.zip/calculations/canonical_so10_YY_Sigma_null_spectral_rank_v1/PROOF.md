# Sigma null-orbit restriction of the spectral triangle family

Use the fixed-flat V1018/V1026 affine equations, the unit derivative-free g⁴ xi auxiliary master test, and the full V1029 spectral projectors on the two YFF ghost edges. Allow the coefficients of the older Q, J, source and reverse triangles to differ between scalar species. Those graphs carry an internal scalar line. The YFF coefficient acts on internal gauge and ghost colors, so its exterior scalar spectator cannot distinguish the species. The restriction below remains valid even if every allowed YFF coefficient is free.

The entire rank-12 broken sector with center Casimir 5/12 lies in ker E_Sigma. In particular j=e17+e22 and j=e19+e24 belong to this sector. Any tested spectral projection or H-intertwining endomorphism on the ghost edge at the E endpoint preserves it. The light adjoint action at the returning F vertex preserves it as well. Every such YFF column vanishes on these j. The original S and reverse V columns are also zero there, because their formulas factor through E_j. The Q auxiliary coefficient T_j itself vanishes on these rows by the literal BB Lambda contraction. Its ordinary antighost term can survive.

Retain both ordered BB Hessian placements. Three actual Sigma master cells give the following rows in column order (q_M,q_0,q_2,q_3):

    (c13, j17+j22, x172)     (1,−1/12,−3/4,−2/3)
    (c43, j17+j22, x68)      (1, 1/6, −3/2,−8/3)
    (c17−c22, j19+j24,x204)  (1,−1/4,0,0)

The unnormalized broken-edge entries are sqrt(30)/30, sqrt(30)/60 and −2sqrt(15)/15. The cells force q_0=4q_M, q_2=2q_M/3 and q_3=q_M/4.

## Actual affine constraints

Subtract the common broken baseline from the light coefficients as in V1018. Put u_i=−2 delta j_i+delta q_i, v_i=delta j_i/2−delta q_i. Use the center tangent 6 P_0 e0 on the broken vectors e43, e13, e17−e22. They lie in the charged singlet, triplet and lower active doublet spectral sectors respectively. The corresponding U=R_h E_B has nonzero entries at x205, x137 and x73. Then use e9 and e1 on e17−e22, with nonzero entries at x73 and x172. The actual values in both charts verify the respective scalar Casimir and adjoint terms.

The five equations give (u_0,u_2,u_3,v_2,v_3)=d(5/3,5/9,5/12,0,0). Hence delta q_2=−5d/27 and delta q_3=−5d/36. The original normalization has C_Sigma=25/2, k=17, q_M=34(L_Sigma−1)/25 and d=17−(5/2)q_M. Keep the reference log symbolic. Combining the three master rows and two affine relations forces simultaneously d=(9/5)q_M and d=(27/5)q_M. They give q_M=d=0, inconsistent with the last relation.

In master, affine, reference order the exact witness (−89/2,287/20,122/5,−237/20,43/5,1) annihilates the coefficient matrix and returns 17 on the right side. Both exact ranks are 5 and 6. This excludes the expanded fixed-flat family on Sigma even with species-independent freedoms relaxed for the older scalar-line maps. It leaves different numerical kernels on the internal mixed gauge edge, linked products and genuinely different ordinary or source maps open.
