# V1032 two active Sigma rows

Two literal active lower-doublet master rows give a raw sum of −7 sqrt(15) q_M/100. All six light mixed-edge Q columns cancel individually, as do the ordered source and reverse triangle columns. The tested YFF projectors reduce to the same source columns on these external color vectors. The result retains the complete null-sector freedom.

The original unprojected broken-edge baseline therefore needs q_M=0. At the actual shared reference relation this gives L_Sigma=1, which is incompatible with the V1031 Phi J-only trial L_Phi=1 at distinct masses.

The initial native run gave the same raw witness and exposed two incorrect entries in the drafted normalized reverse columns. The original packet is preserved. The corrected table was validated in both exports. Other Phi log choices and a separately projected broken ordinary edge remain open.
