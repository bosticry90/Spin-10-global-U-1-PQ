"""Check the active Sigma two-row obstruction at the current common log trial."""
from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


spec = importlib.util.spec_from_file_location(
    "mixed_owner",ROOT/"calculations/canonical_so10_YY_mixed_spectral_Ward_master_v1/yy_mixed_spectral_ward_master.py")
mixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mixed)
spectral,ideal,owner,alg,ports = mixed.spectral,mixed.ideal,mixed.owner,mixed.alg,mixed.ports
triangle = spectral.triangle
r,zero = sp.Rational,sp.S.Zero

j = {17:r(1,2),22:-r(1,2)}
cases = [({17:r(1,2),22:-r(1,2)},210),({18:r(1,2),21:r(1,2)},206)]


def gauge_rows(phase,rho,f,paired):
    marks,_ = ports.raw_ports(phase,f)
    T = [ideal.plus(*((-r(4,3)*z*j[e],paired[k,h,b])
                     for (h,b,e,mu),z in marks.items() if mu==0 and e in j))
         for k in range(7)]
    raw = alg.read(ports.CALC/"canonical_so10_unprobed_compact_all_coupling_v1"/
                   f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    L = defaultdict(lambda:zero)
    for g,word,cells in raw:
        if g!=2 or len(word)!=4:
            continue
        (p,_),(q,_),(c,_),(a,_) = word
        if q>=180 or not 553<=c<598 or a-598 not in j or p%4:
            continue
        c,a = c-553,a-598
        for n,(ghost,x) in enumerate(cases):
            if c not in ghost:
                continue
            assert q%4==0 and all(not jets for _,jets in word)
            z = -r(4,3)*j[a]*ghost[c]*ports.decode(cells,2,False)
            for h,b in ((p//4,q//4),(q//4,p//4)):
                if b in ideal.M:
                    for k in range(7):
                        L[n,k] += z*paired[k,h,b].get(x,zero)
    return [[sp.expand(owner.act(rho,ghost,T[k]).get(x,zero)-L[n,k]) for k in range(7)]
            for n,(ghost,x) in enumerate(cases)]

def check(phase):
    vacuum,_,rho,f,_,_ = owner.inputs(phase)
    ad,P = ideal.projectors(f)
    _,sectors,_ = spectral.spectral(ad,P)
    v = {i:z for i,z in vacuum.items() if 54<=i<306}
    E = {a:alg.apply(rho[a],v) for a in owner.COLORS}
    for C in [j,*[ghost for ghost,_ in cases]]:
        x = sp.Matrix([C.get(k,zero) for k in ideal.M])
        assert sectors[3]*x==x
    _,paired = mixed.contractions(rho,P,E,sectors)
    Q = gauge_rows(phase,rho,f,paired)
    forward,reverse = triangle.balances(phase,f)
    t = sp.Matrix([0,-2,1,0,0,0,0])
    l = sp.Matrix([0,0,0,0,4,-r(4,3),1])
    T = sp.Matrix(Q)
    assert [sp.expand(z) for z in (T[0,:]+T[1,:])]==[-7*sp.sqrt(15)/100]+[zero]*6
    G = T*sp.Matrix(mixed.candidate)
    assert list(G)==[-7*sp.sqrt(15)/300,-7*sp.sqrt(15)/150]
    responses = []
    for ghost,x in cases:
        sum_cols = [zero]*6
        for b,z in j.items():
            for c,w in ghost.items():
                row = triangle.columns(forward,reverse,rho,P,E,b,c)
                for k,vect in enumerate(row):
                    sum_cols[k] += z*w*vect.get(x,zero)
        responses.append([sp.expand(z) for z in sum_cols])
    # Order qM, free triplet, free doublet, V ideals, S ideals.
    A = G.row_join(T*t).row_join(T*l)
    V = sp.Matrix(responses)
    A = A.row_join(V[:,3:]).row_join(V[:,:3])
    normalized = [[sp.cancel(A[i,k]/G[i]) for k in range(A.cols)] for i in range(2)]
    assert normalized == [[1,0,-r(4,7),r(1,56),r(15,28),r(25,28),0,r(15,56),r(15,28)],
                          [1,0,r(2,7),-r(1,112),-r(15,56),-r(25,56),0,-r(15,112),-r(15,56)]]
    raw = [sp.expand(z) for z in (A[0,:]+A[1,:])]
    assert raw==[-7*sp.sqrt(15)/100]+[zero]*8
    ell = sp.Symbol("ell",nonzero=True,real=True)
    qM = r(34,25)*((1-ell)-1)
    assert sp.expand(raw[0]*qM)!=0
    return {"two_active_rows":[[str(z) for z in row] for row in normalized],
            "two_active_raw_sum_per_qM":str(raw[0]),
            "free_null_weights_and_triangle_columns_annihilated":True,
            "all_spectral_YFF_reduce_to_three_columns":True,
            "current_common_Phi_log_trial_excluded":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
