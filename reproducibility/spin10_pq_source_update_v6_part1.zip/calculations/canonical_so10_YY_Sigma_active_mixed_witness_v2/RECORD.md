# Bounded active Sigma test V1032

Freeze the V1031 null solution and free directions, the literal master exports and V1025 ordered triangle colors. Test two active lower-doublet rows with full raw gauge contractions and all six source/reverse columns. Keep the shared reference mass relation exact. Require the raw left witness before and after null-sector substitution and equality in both charts.

The ceiling is the active obstruction to the current fixed-baseline common Phi trial. Other Phi normalizations, independently projected broken-ordinary contacts and the linked causal/marked problem are outside the certificate. No protected scientific promotion. Historical custody exit 2 remains unresolved.

The initial native calculation completed and authenticated the raw witness. Its result revealed two inconsistent reversed-column entries in the frozen proof table. Preserve the original packet and capture. The corrected version uses the literal values and asserts them before final replay. The raw witness and scientific scope remain fixed.
