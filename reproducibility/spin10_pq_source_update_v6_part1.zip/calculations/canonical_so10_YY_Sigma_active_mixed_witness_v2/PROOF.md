# Two active Sigma rows at the common Phi trial log

Use the V1031 H-ordinary mixed-spectral family and keep its original unprojected broken-ordinary Q baseline. The total lower kinetic derivative and the fixed-flat reference are held fixed. Work at unit switch in the derivative-free g⁴ xi auxiliary master comparison. Allow all six light/mixed Q directions and all V1025 source and reversed ordinary directions. The test allows those older scalar-line weights independently across Phi and Sigma.

Take the external auxiliary j=(e17−e22)/2. Use the ordered rows (c,x)=((e17−e22)/2,x210) and ((e18+e21)/2,x206). Each external color vector lies in the lower active rank-12 spectral sector. Therefore any tested product of spectral ghost projectors in YFF is either zero on these rows or has exactly the corresponding S_i column. Allowing independent S_i weights on Sigma already includes this span, even if the common spectator constraint is relaxed.

Compute the ordinary auxiliary BB Lambda term and both BB C a placements with their literal signs. The sum of the two raw rows cancels the six light/mixed Q columns separately, before any null-sector relations are imposed. The raw broken Q sum is −7 sqrt(15)/100. The ordered S_i and V_i columns cancel separately as well. For a control, insert the complete null-sector family from V1031, with free triplet coordinate t=Q3T and doublet coordinate l=Q3L. Their differences relative to the displayed solution are (delta Q0T,delta Q3T)=(-2t,t) and (delta Q0L,delta Q2L,delta Q3L)=(4l,−4l/3,l). In order (q_M,t,l,V0,V2,V3,S0,S2,S3) the normalized rows are

    (1,0,−4/7, 1/56,15/28,25/28, 0,15/56,15/28)
    (1,0, 2/7,−1/112,−15/56,−25/56, 0,−15/112,−15/56).

Their raw divisors are −7 sqrt(15)/300 and −7 sqrt(15)/150. Both exports give the same raw witness. Thus this active Sigma test forces q_M=0 with the original broken-edge baseline retained.

The actual relation q_M=34(L_Sigma−1)/25 then requires L_Sigma=1. The V1031 Phi J-only trial is at L_Phi=1. The common reference relation L_Phi−L_Sigma=log(M_Sigma/M_Phi) for positive distinct reference masses excludes this joint trial at the fixed baseline. This does not classify Phi away from its trial log, an independently projected broken-ordinary edge, different ordinary or source kernels, or the whole marked and causal problem.
