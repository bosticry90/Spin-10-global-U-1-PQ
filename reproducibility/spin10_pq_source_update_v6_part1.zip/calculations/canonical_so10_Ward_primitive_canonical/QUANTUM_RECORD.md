# WPC quantum continuation: first supported proper/connected coefficient

Canonical transport completed in10.949157s: all1286 columns,all33 epsilon
normalizations and whole Hessian agree. The auxiliary GF comparison has
zero residual; the full-source QJL comparison has32 nonzero components.
Preserve all32 corrections; test their ordinary-field Hessians before
using a quantum Euler-insertion relation. They must not be silently
dropped, especially in connected products.

Compute the COMPLETE first-u,g0 coefficient with one marked epsilon_s
(s12..44) and one Ja_r (r0..44), at zero other sources/ordinary ghosts,
in the original unshifted A0 Euclidean reference. This is the first
coupling order supported by the measured Ca root; the BB root startsg1
and remains for the subsequent ordered calculation. Do not select a
single favorable color or treat this order as full Ward restoration.
The fixed K_D primitive is inserted in S+uQG; no u-dependent replacement
of the Ward operator is adopted.

Derive ghost matrices from the actual action BEFORE source restriction:
L_s from the canonical epsilon component, N_pr from the full QG source
Euler, and all actual ghost-pair background matrices. Check free ghost
normalization from all45 actual GF Euler columns. Verify original Ja
field Hessian and free-u ghost quadratic vanish atg0 on this locus.
Anomalous/derivative or nonlinear-background ghost terms must be retained
until excluded by actual support; unexpected surviving terms fail the
reduced-kernel premise, not get discarded. Include all2970 color/probe
positions, including zeros. No coefficient is fitted to a target.

Use a formal odd insertion marker rho with the already Schwartz-smeared
epsilon direction: rho*epsilon_s is an even coefficient. No constant
physical probe/adiabatic limit is taken. Convert the POLARIZED Hessian
through the original graded Gaussian; validate the restricted number-
conserving ghost reduction by finite Berezin/action checks. The proper
reference response has two ordered positive-heat inverse terms. Evaluate
their actual color coefficient and massless heat bubble, distinguishing
log divergence, nonlocal finite part and a symbolic allowed local contact.
The same bubble scalar alone does not identify this contact with kappa,
b0,chi4 or determine every mixing entry.

Derive the COMPLETE connected rho/Ja coefficient by the same regulated
classical mean. Verify the g0 Gaussian B/Lambda/source sector and its
free mixed propagator, including the source-only contact and u square.
Compute both mean branches, both-mean term and nonlinear-mean term in
addition to the proper product. Prove any zero nonlinear mean from this
actual quadratic sector, not a zero-tadpole normalization. Retain arbitrary
finite A contributions symbolically. Keep epsilon and Ja heat labels
independent before momentum conservation.

Use E_p=exp(-2t p2), the inherited F^2 heat convention. Derive the exact
two-edge scalar heat integral and its reference finite part. For the IR
proof approximant f=(1-exp(-p2/delta2))2, calculate/retain nonzero finite-
delta terms. Its Gaussian covariance fE G0 is a proof family, not the
actual fixed-R inverse: record the1-f inverse/source defect. No silent
E->fE substitution in an asserted physical finite-delta Ward identity.
Prove the common UV-FP-then-IR Schwartz limit with all root denominators
cancelled; pointwise zero-momentum values alone cannot justify it.

Native180/review180s,8GiB sampled/350MiB launch/16MiB packet unchanged.
References and verification share action/chart/software/AIauthor. Success
is a bounded actual one-loop kernel and its declared mean transport,
not full fixed-operator Ward/QAP/measure/E5 or physical viability.
