from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'verify.py').read_text()
assert src.count('cc*E**k')==1
src=src.replace('cc*E**k','cc*J.constant(E**k)').replace("O/'validation_receipt.json'","O/'validation_receipt_v2.json'")
with(O/'verify_v2.py').open('xb') as f:f.write(src.encode())
src=(O/'run_review.py').read_text().replace("['preparation.json','quantum_preparation.json']","['preparation.json','quantum_preparation.json','review_preparation.json']")
src=src.replace("['REVIEW_RECORD.md','verify.py','run_review.py']","['REVIEW_V2_RECORD.md','make_review_v2.py','verify_v2.py','run_review_v2.py']")
src=src.replace("O/'review_preparation.json'","O/'review_preparation_v2.json'").replace("O/'verify.py'","O/'verify_v2.py'")
src=src.replace("O/'review_capture.json'","O/'review_capture_v2.json'").replace("C/'review_full_capture.json'","C/'review_full_capture_v2.json'")
src=src.replace("O/'review_controller_failure.json'","O/'review_controller_failure_v2.json'")
with(O/'run_review_v2.py').open('xb') as f:f.write(src.encode())
