# WPC final evidence and preservation audit

Freeze the proof, result, reference intake and handoff after successful
V2 review. Run the delegated E4 command once, no --fresh. Expected steps
0,0,0,0,0,2 and terminal COMPLETED; custody remains seven unresolved,
NOTPASS. E4 authenticates its existing checkpoint, not new scientific
acceptance of WPC. Do not promote project_state.json.

Authenticate every prospective binding and source copy, actual outputs,
all2970 color entries and the independent-heat cubic factorization.
Keep V1 review's failed capture/controller record as FAILED. Check
per-worker resource observations including that failure; sample maxima
are not true peaks. Bound final audit180s,8GiB/350MiB/16MiB unchanged.
Preserve all41490 old tracked modes/blobs and exact raw new bytes before
any local main commit. No remote push, protected activation or adoption.
