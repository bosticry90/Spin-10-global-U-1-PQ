from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time,math
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('qualified_raw_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=load(R/'tools/portable_dh_v1/inputs.json.gz');raw=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
ct=load(O/'canonical_tables.json.gz');A=u.Algebra(ct['geometry']['names'],ct['geometry']['parities']);EPS=1286;HD=1319;KD=1962
frame=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_inputs.json.gz')['frame'];pos={raw.index[n]:i for i,n in enumerate(frame['field_order'])}
T=defaultdict(list);F=defaultdict(list)
for i,j,c in frame['physical_to_raw_inverse']['entries']:T[i].append((j,u.parse_coefficient(c)[0][1]))
for i,j,c in frame['physical_to_raw_kernel']['entries']:F[j].append((i,u.parse_coefficient(c)[0][1]))
mc=u.multiply_coefficients;sc=u.scale_coefficient;one=u.ONE;ii=u.parse_coefficient('I')[0][1]
maps={}
for n,src,h,k in pairs:
    maps[n]=[(j,c) for j,c in T[pos[n]]];maps[src]=[(643+j,c) for j,c in F[pos[n]]]
    maps[h]=[(HD+j,c) for j,c in T[pos[n]]];maps[k]=[(KD+j,c) for j,c in T[pos[n]]]
for i in range(12,45):
    maps[raw.index[f'zz_da{i:02}']]=[(EPS+j-610,c) for j,c in T[pos[raw.index[f'ub{i}']]]]
    assert all(EPS<=j<EPS+33 for j,c in maps[raw.index[f'zz_da{i:02}']])
def phase(j):
    j=j if j<1286 else j-HD if HD<=j<KD else j-KD if j>=KD else None
    if j is None:return one
    return tuple(((0,0,m),z) for (g,x,e,m),z in J.phase(j).terms)
def transform(P,density=False):
    colored={}
    for (g,w),c in P.items():
        assert not any(raw.names[n].startswith('A') for n,js in w)
        z={(g,()):c}
        for n,js in w:z=A.product(z,{(0,((j,js),)):b for j,b in maps[n]})
        v.merge(colored,z)
    out={}
    for (g,w),c in colored.items():
        c=sc(c,-1 if density else 1)
        for n,js in w:
            c=mc(c,phase(n))
            for mu in js:
                if mu==0:c=mc(c,ii)
        u.put(out,(g,w),c)
    return out
rawtab=load(R/'calculations/canonical_so10_antighost_Ward_Hamiltonian/hamiltonian_tables.json.gz');P=transform(v.unpack(raw,rawtab['generator']),True)
assert P==v.unpack(A,ct['K']),'REPLAY_SPLIT_CHART_DENSITY_MISMATCH'
Ee=v.euler(A,P,set(range(1286)),'replay');flow={}
for n in range(643):
    if Ee[643+n]:flow[n]=u.scale(Ee[643+n],-1)
    if Ee[n]:flow[643+n]=Ee[n]
assert flow=={int(i):v.unpack(A,p) for i,p in ct['D'].items()}
hm={i:{(0,((HD+i,()),)):one} for i in range(643)};km={i:{(0,((KD+i,()),)):one} for i in range(643)}
HH=v.act(A,v.act(A,P,km,0,'replay'),hm,0,'replay');assert HH==v.unpack(A,ct['Hessian'])
comp=v.euler(A,P,set(range(EPS,EPS+33)),'replay');assert comp=={int(i):v.unpack(A,p) for i,p in ct['components'].items()}
# Each epsilon occurs once, with at most one derivative. Move epsilon to
# the left before integrating it by parts; preserve the explicit current.
curr=[{} for mu in range(4)]
for (g,w),c in P.items():
    slots=[(at,n,js) for at,(n,js) in enumerate(w) if EPS<=n<EPS+33];assert len(slots)==1
    at,n,js=slots[0];assert len(js)<=1
    if js:
        co=sc(c,(-1)**sum(A.parities[a] for a,b in w[:at]))
        v.merge(curr[js[0]],A.product({(0,((n,()),)):one},{(g,w[:at]+w[at+1:]):co}))
reconstructed={}
for i,pp in comp.items():v.merge(reconstructed,A.product({(0,((i,()),)):one},pp))
assert not u.combine(P,u.scale(reconstructed,-1),u.scale(u.combine(*(v.total(A,c,mu) for mu,c in enumerate(curr))),-1))
print('STAGE replay split chart, complete flow/Hessian and explicit epsilon currents',flush=True)
def as_J(pp):
    out={}
    for (g,w),c in pp.items():J.put(out,w,J.Coeff([((g,x,e,m),z) for (x,e,m),z in c]))
    return J.clean(out)
def g0(pp):return J.clean({w:J.Coeff([(k,z) for k,z in c.terms if k[0]==0]) for w,c in pp.items()})
def ghost_matrix(pp):
    # Independent left differentiation of the original action, a then C.
    out={}
    for aa,qq in J.euler(pp,set(range(598,643))).items():
        for cc,z in J.euler(qq,set(range(553,598))).items():
            if () in z:out[aa-598,cc-553]=z[()]
    return out
def unpack_matrix(rows):return {(i,j):J.Coeff([((0,x,e,m),Fraction(n,d)) for x,e,m,n,d in cells]) for i,j,cells in rows}
def trace_product(a,b):
    # Form the full sparse matrix product before its diagonal trace.
    byrow=defaultdict(list)
    for (i,j),c in b.items():byrow[i].append((j,c))
    product={}
    for (i,k),c in a.items():
        for j,d in byrow[k]:product[i,j]=product.get((i,j),J.ZERO)+J.times(c,d)
    return sum((c for (i,j),c in product.items() if i==j),J.ZERO)
def ce(c):return [[x,e,m,z.numerator,z.denominator] for (g,x,e,m),z in c.terms]
qt=load(O/'quantum_tables.json.gz');fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz')
replayaction=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[1]
base=g0(J.decode(replayaction['original'][0]['density']));original_ghost={}
for w,c in base.items():
    gh=[n for n,js in w if 553<=n<643];oth=[(n,js) for n,js in w if not 553<=n<643]
    if len(gh)!=2 or any(n>=643 for n,js in oth):continue
    if len(oth)==0:continue # the separately checked free ghost kinetic term
    assert len(oth)==1 and 508<=oth[0][0]<553 and not oth[0][1],'ORIGINAL_GHOST_BACKGROUND_NOT_AUXILIARY_LINEAR'
    J.put(original_ghost,w,c)
ML={r:ghost_matrix(J.leftjet(original_ghost,(508+r,()))) for r in range(45)}
assert all(ML[r]==unpack_matrix(qt['M_Lambda'][str(r)]) for r in range(45))
L={a:ghost_matrix(g0(as_J(comp[EPS+a-12]))) for a in range(12,45)}
assert all(L[a]==unpack_matrix(qt['L'][str(a)]) for a in L)
independent={};rootcounts=Counter();proper=0;heat_sensitive=0;uv_insensitive=0
for pr in [0,1]:
    U=g0(J.decode(fj['probes'][pr]['qG']));sources=J.euler(U,set(range(1241,1286)))
    for r in range(45):
        N=ghost_matrix(sources.get(1241+r,{}));ys=[ghost_matrix(J.leftjet(U,(4*r+mu,(mu,)))) for mu in range(4)]
        assert ys[0]==ys[1]==ys[2]==ys[3]
        assert N==unpack_matrix(qt['probes'][pr]['N_direct'][str(r)]) and ys[0]==unpack_matrix(qt['probes'][pr]['M_y'][str(r)])
        selected=r<12 if pr==0 else r>=12
        for a in range(12,45):
            t=trace_product(L[a],N);my=trace_product(L[a],ys[0]);ml=trace_product(L[a],ML[r]);proper+=bool(t)
            c=[-t,t-my-2*J.I*ml*int(selected),my+4*J.I*ml*int(selected),-2*J.I*ml*int(selected)]
            # Expand -(1-E)[T+E*Y+2i*Pi*E(1-E)*LML].
            assert sum(c,J.ZERO)==J.ZERO
            independent[pr,a,r]=(t,c)
for row in qt['complete_color_table']:
    t,c=independent[row['probe'],row['epsilon'],row['Ja']]
    assert ce(t)==row['proper_Gamma_tensor'] and [ce(cc) for cc in c]==row['connected_physical_heat_coefficients']
    rootcounts[row['physical_heat_root_multiplicity_at_one']]+=1
    if t:
        # Proper-only control differs at a finite heat value, regardless of
        # whether another incomplete endpoint subset also has a UV root.
        E=Fraction(1,2);value=sum((cc*J.constant(E**k) for k,cc in enumerate(c)),J.ZERO)
        heat_sensitive+=value!=-t
    if c[0]+c[1]+c[2]+c[3]==J.ZERO:uv_insensitive+=1
assert proper==57 and len(independent)==2970
print('STAGE replay action derivatives and all2970 proper/connected color positions',flush=True)
# Full free-vector inverse: no assumption of a pure scalar propagator.
p=s.Matrix([1,2,-1,3]);p2=(p.T*p)[0];Om=s.symbols('Omega',real=True)
KK=s.zeros(5);GG=s.zeros(5)
for i in range(4):
    for j in range(4):KK[i,j]=p2*int(i==j)-p[i]*p[j];GG[i,j]=s.Rational(int(i==j),p2)+(Om-1)*p[i]*p[j]/p2**2
    KK[i,4]=p[i];KK[4,i]=-p[i];GG[i,4]=-p[i]/p2;GG[4,i]=p[i]/p2
KK[4,4]=Om
assert s.simplify(KK*GG)==s.eye(5)
y,lam,Jj,theta,uu,E=s.symbols('y lam J theta u E');I=s.I
Z=I*y+Om*lam/2-I*Jj
S=(I*lam*y+Om*lam**2/2)/E-I*Jj*lam+uu*Z**2+theta*(y-Jj-I*Om*lam/2)
H=s.hessian(S,(y,lam));rhs=-s.Matrix([s.diff(S,k).subs({y:0,lam:0}) for k in (y,lam)])
mean=(H.inv()*rhs).applyfunc(s.simplify)
expected=s.Matrix([E*Jj-uu*Om*E*(1-E)*Jj-Om*E*theta/2,2*I*uu*E*(1-E)*Jj+I*E*theta])
assert all(s.simplify(s.diff(mean[k]-expected[k],uu,n).subs(uu,0))==0 for k in range(2) for n in [0,1])
assert all(s.diff(mean[k],Jj,theta)==0 for k in range(2))
assert s.diff(S,Jj,theta)==-1 and s.diff(S,Jj,2)==-2*uu
# Direct finite Berezin integration, using independent exterior products
# and a commuting nilpotent J marker. rho*epsilon is an even coefficient.
def mul(a,b):
    out={}
    for (ma,ja),x in a.items():
        for (mb,jb),z in b.items():
            if ma&mb or ja+jb>1:continue
            sg=(-1)**sum((mb&((1<<i)-1)).bit_count() for i in range(8) if ma&(1<<i))
            key=ma|mb,ja+jb;out[key]=out.get(key,0)+sg*x*z
    return {k:s.expand(vv) for k,vv in out.items() if vv}
def add(a,b):
    z=dict(a)
    for k,c in b.items():z[k]=s.expand(z.get(k,0)+c)
    return {k:c for k,c in z.items() if c}
def word(ids,coef=1,j=0):
    out={(0,j):coef}
    for i in ids:out=mul(out,{(1<<i,0):1})
    return out
berezin_values=[]
for model in range(3):
    M=s.Matrix([[2+model,1,0],[-1,3,1],[1,0,4]]);L0=s.Matrix([[1,2,-1],[0,1,1],[2,0,-1]]);N0=s.Matrix([[0,1,2],[-1,2,0],[1,-2,1+model]])
    SS={}
    for i in range(3):
        for j in range(3):
            SS=add(SS,word([3+i,j],M[i,j]));SS=add(SS,word([6,7,3+i,j],L0[i,j]));SS=add(SS,word([3+i,j],N0[i,j],1))
    exp={(0,0):s.Integer(1)};power=exp
    for n in range(1,7):power=mul(power,{k:-c/n for k,c in SS.items()});exp=add(exp,power)
    zz={(mask^63,j):c for (mask,j),c in exp.items() if mask&63==63};constant=zz[0,0];zz={k:s.cancel(c/constant) for k,c in zz.items()};del zz[0,0]
    # log(1+z)=z-z^2/2 suffices for these two nilpotent endpoints.
    logz=add(zz,{k:-c/2 for k,c in mul(zz,zz).items()});actual=-logz.get((192,1),0)
    target=s.trace(M.inv()*L0*M.inv()*N0);assert s.simplify(actual-target)==0
    h=lambda B:s.BlockMatrix([[s.zeros(3),-B.T],[B,s.zeros(3)]]).as_explicit()
    G=h(M).inv();ordered=s.trace(G*h(L0)*G*h(N0)+G*h(N0)*G*h(L0))/4
    assert s.simplify(ordered-target)==0 and target!=0
    berezin_values.append(str(actual))
print('STAGE actual Gaussian endpoints, nonlinear-mean zero and finite Berezin sign',flush=True)
mp.mp.dps=42;errors=[]
for z in [mp.mpf(1)/5,mp.mpf(2),mp.mpf(7)]:
    exact=2*mp.e1(z)-mp.e1(z/2)+2*(mp.exp(-z/2)-mp.exp(-z))/z
    independent_integral=mp.quad(lambda w:(mp.exp(-z/(1+w))-(mp.exp(-z/w) if w else 0))/z,[0,mp.mpf(1)/8,mp.mpf(1)/2,1])
    errors.append(str(abs(exact-independent_integral)));assert abs(exact-independent_integral)<mp.mpf('1e-35')
zz=mp.mpf('1e-15');B=2*mp.e1(zz)-mp.e1(zz/2)+2*(mp.exp(-zz/2)-mp.exp(-zz))/zz
assert abs(B+mp.log(zz)+mp.euler-1+mp.log(2))<mp.mpf('1e-13')
# Finite-delta zero-momentum bubble, calculated independently by quadrature
# and a Frullani sum. Keep this nonzero term before the Schwartz limit.
t=mp.mpf(2)/7;delta=mp.mpf(3)/5;a=4*t
profile=mp.quad(lambda x:mp.exp(-a*x)*(-mp.expm1(-x/delta**2))**4/x,[0,1,4,mp.inf])
frullani=-sum((-1)**j*math.comb(4,j)*mp.log(a+j/delta**2) for j in range(5))
assert abs(profile-frullani)<mp.mpf('1e-35') and profile>0
native=read(O/'quantum_result.json');canonical=read(O/'canonical_result.json')
assert digest(O/'quantum_tables.json.gz')==native['table_sha256'] and digest(O/'canonical_tables.json.gz')==canonical['table_sha256']
out={'schema':'WPC_SEPARATE_REPLAY_ACTION_GAUSSIAN_AND_ANALYTIC_REVIEW','evidence_validation':'PASS_BOUNDED_G0_KERNEL_AND_REFERENCE_MEAN_TRANSPORT',
 'canonical_flow_columns':1286,'canonical_density_positions':len(P),'canonical_Hessian_positions':len(HH),
 'epsilon_IBP_current_positions':[len(c) for c in curr],'complete_color_positions':2970,'proper_nonzero':proper,'proper_zero_complement':2970-proper,
 'physical_heat_root_counts':[[k,n] for k,n in rootcounts.items()],'proper_only_finite_heat_controls_sensitive':heat_sensitive,
 'UV_root_alone_does_not_validate_endpoint_completeness':True,'full_action_endpoint_and_source_contacts_checked':True,
 'nonlinear_mixed_mean_zero_from_stationarity_not_zero_tadpole':True,'finite_Berezin_three_models':berezin_values,
 'bubble_independent_integral_absolute_errors':errors,'finite_profile_bubble_nonzero':str(profile/(16*mp.pi**2)),
 'physical_finite_delta_Ward_identity_claim':False,'arbitrary_finite_parent_A':'SYMBOLIC_ALL_FIVE_LEGENDRE_TERMS',
 'full_Ward_QAP_E5_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
