from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
from exact_algebra import add_coefficients as ac
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'quantum_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
ct=load(O/'canonical_tables.json.gz');A=u.Algebra(ct['geometry']['names'],ct['geometry']['parities']);EPS=ct['geometry']['EPS']
K={int(i):v.unpack(A,p) for i,p in ct['components'].items()}
one=u.ONE;ii=u.parse_coefficient('I')[0][1];mc=u.multiply_coefficients;sc=u.scale_coefficient
def plusc(*cs):
    z=()
    for c in cs:z=ac(z,c)
    return z
def addm(M,N):
    out=dict(M)
    for ij,c in N.items():out[ij]=ac(out.get(ij,()),c)
    return {ij:c for ij,c in out.items() if c}
sm=lambda M,c:{ij:mc(vv,c) for ij,vv in M.items() if mc(vv,c)}
def pair(M,N):return plusc(*(mc(c,N.get((j,i),())) for (i,j),c in M.items()))
def enc(c):return [[x,e,m,z.numerator,z.denominator] for (x,e,m),z in c]
def em(M):return [[i,j,enc(c)] for (i,j),c in sorted(M.items())]
def from_J(rows):
    out={}
    for w,cells in rows:
        gs=defaultdict(list)
        for (g,x,e,m),num,den in cells:gs[g].append(((x,e,m),Fraction(num,den)))
        for g,c in gs.items():u.put(out,(g,tuple((i,tuple(j)) for i,j in w)),tuple(c))
    return out
gp0=lambda P:{(g,w):c for (g,w),c in P.items() if g==0}
def mass(P):
    out={};anomalous={}
    for (g,w),c in gp0(P).items():
        if len(w)!=2 or any(not 553<=n<643 for n,j in w):continue
        assert all(not j for n,j in w),'G0_GHOST_ROOT_HAS_UNEXPECTED_DERIVATIVE'
        cs=[n-553 for n,j in w if n<598];aa=[n-598 for n,j in w if n>=598]
        if len(cs)!=1 or len(aa)!=1:anomalous[g,w]=c;continue
        ij=aa[0],cs[0];out[ij]=ac(out.get(ij,()),sc(c,-1))
    assert not anomalous,'ANOMALOUS_GHOST_ROOT_SURVIVES_REQUESTED_SOURCE_LOCUS'
    return out
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');gf={i:from_J(p) for i,p in fj['GF_gradient']};ops={i:from_J(p) for i,p in fj['operation']}
L={s:mass(K[EPS+s-12]) for s in range(12,45)};ML={i:mass(gf[508+i]) for i in range(45)}
for i in range(45):
    lin={(g,w):c for (g,w),c in gp0(gf[598+i]).items() if len(w)==1}
    expected={(0,((553+i,(mu,mu)),)):sc(one,-1) for mu in range(4)}
    assert lin==expected,'ACTUAL_FREE_GHOST_EULER_NORMALIZATION_MISMATCH'
    assert gp0(ops[598+i])=={(0,((508+i,()),)):ii},'G0_Ja_SOURCE_IS_NOT_AFFINE'
for s in range(12,45):assert not addm(L[s],sm(ML[s],ii)),'AUXILIARY_GF_PRIMITIVE_GHOST_RELATION_FAILS'
extras={int(i):v.unpack(A,p) for i,p in ct['full_source_QJL_comparison_remainders'].items()}
assert all(sum(n<643 for n,j in w)<=1 for P in extras.values() for g,w in P),'SOURCE_COMPANION_HAS_NONZERO_ORDINARY_HESSIAN'
width=[u.parse_coefficient('eta_H' if i<12 else 'xi')[0][1] for i in range(45)]

# Check the actual primitive affine endpoints before using their Gaussian
# response. A zero ordinary Hessian does not remove these terms.
for s in range(12,45):
    affine={(0,((1241+s,()),)):sc(one,-1),(0,((508+s,()),)):sc(mc(ii,width[s]),Fraction(-1,2))}
    for mu in range(4):affine[0,((4*s+mu,(mu,)),)]=one
    assert {key:c for key,c in gp0(K[EPS+s-12]).items() if len(key[1])==1}==affine,'PRIMITIVE_AFFINE_ENDPOINT_MISMATCH'
    assert all(len(w)==1 or len(w)==2 and all(553<=n<643 and not js for n,js in w) for g,w in gp0(K[EPS+s-12])),'G0_PRIMITIVE_HAS_AN_UNACCOUNTED_ENDPOINT'

# MWP reconstructed the entire gauge-fixing and source density, not the
# transverse physical action. The latter's free transverse block has zero
# divergence; its longitudinal inverse is bound separately to MWC.
base=from_J(load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0]['original'][0]['density'])
base_locus={key:c for key,c in gp0(base).items() if all(n<553 or 1241<=n<1286 for n,js in key[1])}
free_expected={}
for i in range(45):
    u.put(free_expected,(0,((508+i,()),(508+i,()))),sc(width[i],Fraction(1,2)))
    u.put(free_expected,(0,((508+i,()),(1241+i,()))),sc(ii,-1))
    for mu in range(4):u.put(free_expected,(0,((4*i+mu,(mu,)),(508+i,()))),ii)
assert base_locus==free_expected,'ACTUAL_G0_GF_SOURCE_GAUSSIAN_MISMATCH'
def elem(i,j=()):return {(0,((i,j),)):one}
Z=[]
for i in range(45):
    z={(0,((508+i,()),)):sc(width[i],Fraction(1,2)),(0,((1241+i,()),)):sc(ii,-1)}
    for mu in range(4):u.put(z,(0,((4*i+mu,(mu,)),)),ii)
    Z.append(z)
probes=[];rows=[];ghost_audits=[]
for probe in [0,1]:
    U=gp0(from_J(fj['probes'][probe]['qG']))
    Ufree={};source_excluded=0;ghost_quartic=0;BG={('Lambda',i):{} for i in range(45)};BG.update({('Ja',i):{} for i in range(45)});BY={(i,mu):{} for i in range(45) for mu in range(4)}
    for (g,w),c in U.items():
        if any(n>=643 and not 1241<=n<1286 for n,j in w):source_excluded+=1;continue
        ghosts=[(n,j) for n,j in w if 553<=n<643];other=[(n,j) for n,j in w if not 553<=n<643]
        if not ghosts:u.put(Ufree,(g,w),c);continue
        if len(ghosts)>2:ghost_quartic+=1;continue
        assert len(ghosts)==2 and len(other)==1,'UNSUPPORTED_G0_GHOST_BACKGROUND_DEGREE'
        assert all(not j for n,j in ghosts),'UNSUPPORTED_G0_INTERNAL_GHOST_DERIVATIVE'
        cc=[n-553 for n,j in ghosts if n<598];aa=[n-598 for n,j in ghosts if n>=598]
        assert len(cc)==len(aa)==1,'ANOMALOUS_G0_GHOST_BACKGROUND_BLOCK'
        n,js=other[0];ij=aa[0],cc[0];value=sc(c,-1)
        if 508<=n<553 and not js:target=BG['Lambda',n-508]
        elif 1241<=n<1286 and not js:target=BG['Ja',n-1241]
        elif n<180 and js==(n%4,):target=BY[n//4,n%4]
        else:raise AssertionError(('UNSUPPORTED_G0_BACKGROUND_PORT',n,js))
        target[ij]=ac(target.get(ij,()),value)
    expected={}
    for i in range(45):
        if i<12 if probe==0 else i>=12:v.merge(expected,A.product(Z[i],Z[i]))
    assert Ufree==expected,'COMPLETE_FREE_U_SECTOR_NOT_THE_ACTUAL_Z_SQUARE'
    My={}
    for i in range(45):
        assert BY[i,0]==BY[i,1]==BY[i,2]==BY[i,3],'G0_VECTOR_GHOST_BACKGROUND_NOT_A_DIVERGENCE'
        My[i]=BY[i,0]
    grad=v.euler(A,U,set(range(1241,1286)),'primary');N={i:mass(grad[1241+i]) for i in range(45)}
    assert all(N[i]==BG['Ja',i] for i in range(45))
    probes.append({'probe':probe,'N_direct':{str(i):em(p) for i,p in N.items()},'M_y':{str(i):em(p) for i,p in My.items()},'M_Lambda':{str(i):em(BG['Lambda',i]) for i in range(45)}})
    ghost_audits.append({'probe':probe,'other_source_terms_restricted_AFTER_differentiation':source_excluded,'quartic_ghost_words_zero_at_zero_ghost_mean':ghost_quartic,'free_U_verified_Z_square':True})
    for s in range(12,45):
        R0=L[s];R1=sm(ML[s],ii)
        for r in range(45):
            selected=r<12 if probe==0 else r>=12
            N0=N[r];N1=addm(My[r],sm(ML[r],sc(ii,2 if selected else 0)));N2=sm(ML[r],sc(ii,-2 if selected else 0))
            proper=pair(R0,N0);assert proper==pair(N0,R0)
            connected=[]
            for a,RR in enumerate([R0,R1]):
                for b,NN in enumerate([N0,N1,N2]):connected.append([a,b,enc(sc(pair(RR,NN),-1))])
            def dc(cells):return tuple(((x,e,m),Fraction(n,d)) for x,e,m,n,d in cells)
            physical=[() for i in range(4)]
            for a,b,c in connected:physical[a+b]=ac(physical[a+b],dc(c))
            assert not plusc(*physical),'COMPLETE_CONNECTED_REFERENCE_HAS_NONZERO_UV_LOG_AFTER_MEAN_TRANSPORT'
            mult=0
            if any(physical):
                for derivative in range(4):
                    val=plusc(*(sc(c,__import__('math').factorial(k)//__import__('math').factorial(k-derivative)) for k,c in enumerate(physical) if k>=derivative))
                    if val:break
                    mult+=1
            else:mult=None
            rows.append({'probe':probe,'epsilon':s,'Ja':r,'proper_Gamma_tensor':enc(proper),
              'connected_W_independent_heat_coefficients':connected,'connected_physical_heat_coefficients':[enc(c) for c in physical],
              'physical_heat_root_multiplicity_at_one':mult,'nonlinear_mean_branch_zero_by_quadratic_stationarity':True})
nonzero=[r for r in rows if r['proper_Gamma_tensor']]
out={'schema':'WPC_FIRST_ACTUAL_G0_WARD_PRIMITIVE_QUANTUM_KERNEL','complete_proper_color_positions':len(rows),
 'nonzero_proper_color_positions':len(nonzero),'zero_complement_positions':len(rows)-len(nonzero),
 'proper_two_ordered_ghost_responses_included':True,'all_source_companion_ordinary_Hessians_zero':True,
 'full_source_companion_components_retained':len(extras),'ghost_sector_support_audits':ghost_audits,
 'actual_affine_primitive_and_full_GF_source_Gaussian_checked':True,
 'connected_reference_UV_finite_part_zero_after_full_mean_transport':True,
 'proper_finite_kernel_scalar':'[log(mu^2/p_E^2)-gamma_E+1-2log(2)]/(16*pi^2)',
 'finite_local_contact_matrix':'SYMBOLIC_UNFIXED_NOT_IDENTIFIED_WITH_KAPPA_B0_CHI4',
 'higher_gauge_orders_full_Ward_QAP_E5_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=gzip.compress((json.dumps({'L':{str(i):em(p) for i,p in L.items()},'M_Lambda':{str(i):em(p) for i,p in ML.items()},'probes':probes,'complete_color_table':rows},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'quantum_tables.json.gz').open('xb') as f:f.write(blob)
out['table_sha256']=sha256(blob).hexdigest()
with(O/'quantum_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
