from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-canonical-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
    with p.open('xb') as f:f.write(blob)
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='6dba270618d57d5e57354edac79eee47873268f7'
    C.mkdir(parents=True,exist_ok=True)
    with(C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD']))
    names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md',
     'docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V676.md',
     'tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py',
     'calculations/canonical_so10_connected_contact_lift/lift_v2.py','calculations/canonical_so10_correlated_contact_lift/lift.py',
     'calculations/canonical_so10_antighost_Ward_Hamiltonian/hamiltonian_tables.json.gz',
     'calculations/canonical_so10_antighost_Ward_Hamiltonian/primitive_tables.json.gz',
     'calculations/canonical_so10_antighost_Ward_Hamiltonian/final_review_validation_receipt.json',
     'calculations/canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz',
     'calculations/canonical_so10_full_jet_source_master_bridge/replay_inputs.json.gz',
     'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz',
     'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz',
     'calculations/canonical_so10_full_jet_source_master_bridge/jets.py',
     'calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
     'calculations/canonical_so10_mixed_Ward_covariance_census/PROOF.md',
     'calculations/canonical_so10_mixed_Ward_covariance_census/final_review_validation_receipt.json',
     'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz',
     'calculations/canonical_so10_mixed_Ward_finite_normalization/PROOF.md',
     'calculations/canonical_so10_nonminimal_source_products/PROOF.md',
     'calculations/canonical_so10_nonminimal_source_products/SOURCE_PRODUCT_SCOPE.md',
     'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']
    bindings={}
    for name in names:
        p=R/name;assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+name]),name
        bindings[str(p)]=digest(p)
    for p in list(O.iterdir()):
        if p.is_file():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines())
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    for p in O.iterdir():
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'preparation.json',{'base_HEAD':'6dba270618d57d5e57354edac79eee47873268f7','input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'transport.py')]);dump(O/'transport_capture.json',cap);dump(C/'transport_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED WPC full canonical Ward field/source/epsilon transport',flush=True)
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
