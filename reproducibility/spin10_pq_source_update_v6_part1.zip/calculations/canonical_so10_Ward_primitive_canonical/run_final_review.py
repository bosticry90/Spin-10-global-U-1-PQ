from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-canonical-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
    with p.open('xb') as f:f.write(blob)
try:
    bindings={}
    for prep in O.glob('*preparation*.json'):
        for p,h in read(prep)['input_sha256'].items():assert digest(Path(p))==h,(prep.name,p);bindings[p]=h
    for p in list(O.iterdir()):
        if p.suffix in ['.py','.md'] and not(O/(p.name+'.source.txt')).exists():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    cap=capture([sys.executable,'-B','tools/research_check.py','e4']);dump(O/'e4_capture.json',cap);dump(C/'e4_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    dump(O/'e4_events.json',[json.loads(line) for line in cap['stdout_and_stderr'].splitlines() if line.strip()])
    for p in list(O.iterdir())+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V677.md',C/'old_git_tree.txt',Path('C:/Users/psboy/.codex/attachments/13b33a65-f412-422a-b90d-cbd41e9a1f77/Pasted text.txt')]:
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'final_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'final_review.py')]);dump(O/'final_review_capture.json',cap);dump(C/'final_review_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    v=read(O/'final_review_result.json');assert v['elapsed_after_imports']<180
    files=sorted([p for p in O.rglob('*') if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V677.md']);size=sum(p.stat().st_size for p in files);assert size<16*1024**2
    receipt={'schema':'WPC_FINAL_VALIDATION_AND_NEW_BYTE_SEAL','base_HEAD':'6dba270618d57d5e57354edac79eee47873268f7',
      'new_files_sha256':{p.relative_to(R).as_posix():digest(p) for p in files},'evidence_validation':v['evidence_validation'],
      'full_Ward_QAP_E5_physical_claim':False,'actual_g0_primitive_quantum_claim':True,'E4_step_exits':v['E4_step_exits'],'custody':v['custody'],'state_sha256':v['state_sha256'],
      'largest_accepted_private_sample':max(v['largest_accepted_private_sample'],max(z['private_bytes'] for z in cap['all_resource_samples'])),
      'largest_all_captures_private_sample':max(v['largest_all_captures_private_sample'],max(z['private_bytes'] for z in cap['all_resource_samples'])),
      'memory_samples_not_true_peak':True,'new_files_bytes_excluding_this_receipt':size,'scientific_acceptance':'NOT_PERFORMED','self_hash_excluded':True}
    dump(O/'final_review_validation_receipt.json',receipt)
    print('SEALED '+json.dumps({k:v for k,v in receipt.items() if k!='new_files_sha256'},sort_keys=True),flush=True)
except BaseException:
    dump(O/'final_review_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
