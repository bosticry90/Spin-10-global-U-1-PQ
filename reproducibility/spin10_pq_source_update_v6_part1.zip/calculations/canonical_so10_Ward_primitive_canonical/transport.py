from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=load(R/'tools/portable_dh_v1/inputs.json.gz');raw=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
frame=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz')['frame'];phys=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz')['field_order']
assert len(phys)==643;rawfields=frame['field_order'];raw_of={raw.index[name]:i for i,name in enumerate(rawfields)};Jof={n:j for n,j,h,k in pairs}
source_of={j:raw_of[n] for n,j,h,k in pairs};h_of={h:raw_of[n] for n,j,h,k in pairs};k_of={k:raw_of[n] for n,j,h,k in pairs}
pars=[J.parity(i) for i in range(1286)]+[1]*33+[J.parity(i) for i in range(643)]*2
cnames=phys+[f'Jcanonical_{i}' for i in range(643)]+[f'epsilon_{i}' for i in range(12,45)]+[f'h_{i}' for i in range(643)]+[f'k_{i}' for i in range(643)]
A=u.Algebra(cnames,pars);EPS=1286;H=1319;KDIR=1962
T=defaultdict(list);F=defaultdict(list)
for i,j,text in frame['physical_to_raw_inverse']['entries']:T[i].append((j,u.parse_coefficient(text)[0][1]))
for i,j,text in frame['physical_to_raw_kernel']['entries']:F[j].append((i,u.parse_coefficient(text)[0][1]))
one=u.ONE;ii=u.parse_coefficient('I')[0][1]
def phase(i):
    c=J.phase(i);assert all(g==x==e==0 for (g,x,e,m),z in c.terms)
    return tuple(((0,0,m),z) for (g,x,e,m),z in c.terms)
def inverse(c):
    return u.scale_coefficient(c,-1) if c in [ii,u.scale_coefficient(ii,-1)] else c
eps_raw={raw.index[f'zz_da{i:02}']:i for i in range(12,45)}
maps={};unmapped=[]
for n in range(len(raw.names)):
    output=[]
    if n in raw_of:
        for j,c in T[raw_of[n]]:output.append((j,u.multiply_coefficients(c,phase(j))))
    elif n in source_of:
        for j,c in F[source_of[n]]:output.append((643+j,u.multiply_coefficients(c,phase(643+j))))
    elif n in h_of:
        for j,c in T[h_of[n]]:output.append((H+j,u.multiply_coefficients(c,phase(j))))
    elif n in k_of:
        for j,c in T[k_of[n]]:output.append((KDIR+j,u.multiply_coefficients(c,phase(j))))
    elif n in eps_raw:
        old=raw_of[raw.index[f'ub{eps_raw[n]}']]
        for j,c in T[old]:
            assert 610<=j<643,'BROKEN_EPSILON_CHART_LEAVES_DECLARED_DOMAIN'
            output.append((EPS+j-610,c))
    if output:maps[n]={(0,((j,()),)):c for j,c in output}
def transport(P,density=False,eps_correct=True):
    out={};removed=0
    for (g,w),c in P.items():
        if any(raw.names[n].startswith('A') for n,j in w):removed+=1;continue
        z={(g,()):u.scale_coefficient(c,-1 if density else 1)}
        for n,jets in w:
            assert n in maps,('UNDECLARED_RAW_COORDINATE',raw.names[n])
            mp=maps[n]
            if n in eps_raw and not eps_correct:mp={(0,((EPS+eps_raw[n]-12,()),)):one}
            q=v.jets(A,mp,jets)
            for mu in jets:
                if mu==0:q={key:u.multiply_coefficients(value,ii) for key,value in q.items()}
            z=A.product(z,q)
        v.merge(out,z)
    return out,removed
tabs=load(R/'calculations/canonical_so10_antighost_Ward_Hamiltonian/hamiltonian_tables.json.gz')
Kraw=v.unpack(raw,tabs['generator']);K,removed=transport(Kraw,True)
E=v.euler(A,K,set(range(1286)),'primary');flow={}
for i in range(643):
    f=u.scale(E[643+i],-1);src=E[i]
    if f:flow[i]=f
    if src:flow[643+i]=src
D_raw={raw.index[name]:v.unpack(raw,p) for name,p in tabs['actual_D'].items()};Dt={}
for n,j,h,k in pairs:
    old=raw_of[n]
    if D_raw.get(n):
        p,_=transport(D_raw[n])
        for i,c in F[old]:v.merge(Dt.setdefault(i,{}),{key:u.multiply_coefficients(value,u.multiply_coefficients(c,inverse(phase(i)))) for key,value in p.items()})
    if D_raw.get(j):
        p,_=transport(D_raw[j])
        for i,c in T[old]:v.merge(Dt.setdefault(643+i,{}),{key:u.multiply_coefficients(value,u.multiply_coefficients(c,inverse(phase(643+i)))) for key,value in p.items()})
Dt={i:p for i,p in Dt.items() if p};assert flow==Dt,'FULL_CANONICAL_WARD_VECTOR_FIELD_TRANSPORT_MISMATCH'
for a in range(45):assert flow.get(598+a,{})==({(0,((EPS+a-12,()),)):one} if a>=12 else {})
wrong,_=transport(Kraw,True,False);eps_control=bool(u.combine(wrong,u.scale(K,-1)))
pt=load(R/'calculations/canonical_so10_antighost_Ward_Hamiltonian/primitive_tables.json.gz');Hr,_=transport(v.unpack(raw,pt['field_Hessian']),True)
elem=lambda i:{(0,((i,()),)):one};hm={i:elem(H+i) for i in range(643)};km={i:elem(KDIR+i) for i in range(643)}
Hc=v.act(A,v.act(A,K,hm,0,'primary'),km,0,'primary');assert Hc==Hr,'CANONICAL_HESSIAN_TRANSPORT_MISMATCH'
components=v.euler(A,K,set(range(EPS,EPS+33)),'primary')
def from_J(rows):
    out={}
    for w,cells in rows:
        grouped=defaultdict(list)
        for (g,x,e,m),num,den in cells:grouped[g].append(((x,e,m),Fraction(num,den)))
        word=tuple((i,tuple(j)) for i,j in w)
        for g,c in grouped.items():u.put(out,(g,word),tuple(c))
    return out
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');gf={i:from_J(p) for i,p in fj['GF_gradient']};ops={i:from_J(p) for i,p in fj['operation']}
resgf={};resfull={};source_terms={}
for a in range(12,45):
    width=u.parse_coefficient('xi')[0][1]
    target=u.combine(gf[508+a],{(0,((1241+a,()),)):u.scale_coefficient(ii,-1)},{(0,((508+a,()),)):u.scale_coefficient(width,Fraction(-1,2))})
    target={key:u.multiply_coefficients(value,u.scale_coefficient(ii,-1)) for key,value in target.items()}
    difference=u.combine(components[EPS+a-12],u.scale(target,-1))
    if difference:resgf[a]=difference
    targetfull=u.combine(ops[1151+a],{(0,((508+a,()),)):u.scale_coefficient(width,Fraction(-1,2))})
    targetfull={key:u.multiply_coefficients(value,u.scale_coefficient(ii,-1)) for key,value in targetfull.items()}
    full=u.combine(components[EPS+a-12],u.scale(targetfull,-1))
    if full:resfull[a]=full
pack=lambda p:u.pack(A,p)
blob=gzip.compress((json.dumps({'geometry':{'names':cnames,'parities':pars,'EPS':EPS,'H':H,'K':KDIR},
 'K':pack(K),'Hessian':pack(Hc),'components':{str(i):pack(p) for i,p in components.items()},
 'D':{str(i):pack(p) for i,p in sorted(flow.items())},'auxiliary_GF_comparison_remainders':{str(i):pack(p) for i,p in resgf.items()},
 'full_source_QJL_comparison_remainders':{str(i):pack(p) for i,p in resfull.items()}},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'canonical_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPC_ACTUAL_CANONICAL_WARD_PRIMITIVE_TRANSPORT','canonical_density_positions':len(K),'canonical_Hessian_positions':len(Hc),
 'all1286_vector_field_columns_equal':True,'all33_Da_epsilon_identity':True,'raw_A0_density_terms_removed':removed,
 'epsilon_chart_omission_control_sensitive':eps_control,'auxiliary_GF_comparison_nonzero_components':len(resgf),
 'full_source_QJL_comparison_nonzero_components':len(resfull),'independent_quantum_coefficients_measured':False,
 'table_sha256':sha256(blob).hexdigest(),'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'canonical_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
