from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import ast,gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-canonical-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={}
for prep in O.glob('*preparation*.json'):
    for name,h in read(prep)['input_sha256'].items():
        assert digest(Path(name))==h,(prep.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'transport_capture.json':'transport.py','quantum_capture.json':'quantum.py','review_capture_v2.json':'verify_v2.py','e4_capture.json':None}
failed={'review_capture.json':'verify.py'};samples={};seen=set()
for p in O.glob('*capture*.json'):
    cap=read(p);seen.add(p.name)
    assert cap['launch']['creation_after_observation'] and cap['post_run_observations_qualified']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    if p.name in failed:
        assert cap['exit_code']==1 and cap['execution_state']=='FAILED' and not cap['calculation_completed']
        assert "'Fraction' object has no attribute 'terms'" in cap['stdout_and_stderr']
        assert cap['command'][-2:]==['-B',str(O/failed[p.name])]
    else:
        assert p.name in accepted and cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
        if accepted[p.name]:assert cap['command'][-2:]==['-B',str(O/accepted[p.name])]
        else:assert cap['command'][-3:]==['-B','tools/research_check.py','e4']
assert seen==set(accepted)|set(failed)
assert sorted(p.name for p in O.glob('*controller_failure*.json'))==['review_controller_failure.json']
v=read(O/'validation_receipt_v2.json');n=read(O/'canonical_result.json');q=read(O/'quantum_result.json')
assert v['evidence_validation']=='PASS_BOUNDED_G0_KERNEL_AND_REFERENCE_MEAN_TRANSPORT'
assert n['canonical_density_positions']==2430 and n['canonical_Hessian_positions']==3872 and n['all1286_vector_field_columns_equal'] and n['all33_Da_epsilon_identity']
assert n['auxiliary_GF_comparison_nonzero_components']==0 and n['full_source_QJL_comparison_nonzero_components']==32 and n['epsilon_chart_omission_control_sensitive']
assert n['table_sha256']==digest(O/'canonical_tables.json.gz') and q['table_sha256']==digest(O/'quantum_tables.json.gz')
assert q['complete_proper_color_positions']==2970 and q['nonzero_proper_color_positions']==57 and q['zero_complement_positions']==2913
assert q['connected_reference_UV_finite_part_zero_after_full_mean_transport'] and not q['higher_gauge_orders_full_Ward_QAP_E5_physical_claim']
assert v['proper_only_finite_heat_controls_sensitive']==57 and v['epsilon_IBP_current_positions']==[33]*4
assert v['physical_heat_root_counts']==[[None,2913],[3,57]] and v['nonlinear_mixed_mean_zero_from_stationarity_not_zero_tadpole']
assert not v['physical_finite_delta_Ward_identity_claim'] and not v['full_Ward_QAP_E5_physical_claim']
tab=json.loads(gzip.decompress((O/'quantum_tables.json.gz').read_bytes()));rows=tab['complete_color_table']
assert len(rows)==2970 and len({(r['probe'],r['epsilon'],r['Ja']) for r in rows})==2970
def dc(c):return {(x,e,m):Fraction(n,d) for x,e,m,n,d in c}
def scaled(c,n):return {k:z*n for k,z in dc(c).items() if z*n}
for r in rows:
    T=r['proper_Gamma_tensor']
    assert r['connected_W_independent_heat_coefficients']==[[a,b,[[x,e,m,z.numerator,z.denominator] for (x,e,m),z in sorted(scaled(T,mul).items())]] for a,b,mul in [(0,0,-1),(0,1,2),(0,2,-1),(1,0,1),(1,1,-2),(1,2,1)]]
    assert all(dc(c)==scaled(T,mul) for c,mul in zip(r['connected_physical_heat_coefficients'],[-1,3,-3,1]))
assert {r['probe'] for r in rows if r['proper_Gamma_tensor']}=={1}
assert all(z['elapsed_after_imports']<180 for z in [n,q,v])
events=read(O/'e4_events.json');steps=[e for e in events if e['event']=='step_finished'];exits=[e['exit_code'] for e in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and sum(z['seconds'] for z in steps)<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='6dba270618d57d5e57354edac79eee47873268f7' and git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
assert len((C/'old_git_tree.txt').read_bytes().splitlines())==41490
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
out={'schema':'WPC_FINAL_EVIDENCE_REVIEW','evidence_validation':v['evidence_validation'],'input_bindings_authenticated':len(bindings),
 'source_copies_equal':len(copies),'accepted_completed_captures':sorted(accepted),'failed_captures':sorted(failed),
 'failure_counted_PASS':False,'actual_g0_proper_and_reference_connected_kernel_claim':True,'full_Ward_QAP_E5_or_physical_claim':False,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,'old_tracked_tree_unchanged':True,
 'largest_accepted_private_sample':max(samples[k] for k in accepted),'largest_all_captures_private_sample':max(samples.values()),
 'memory_samples_not_true_peak':True,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
