# Actual Ward primitive: canonical chart and first quantum response

## Domain and dependencies

This is the coefficient of first u and gauge power g10^0, one marked
broken epsilon_s (s=12..44) and one Ja_r (r=0..44), for both existing
probes. Fields/sources are those of the unshifted formal Euclidean A0
reference. External directions are Schwartz smeared; no constant-vacuum
or adiabatic limit is taken. Gamma=Gamma0+hbar Gamma1+..., W1=-Gamma1
at the regulated classical mean. The ghost calculation below is a
restricted consequence of the complete graded action, not a replacement
of its Hessian for general nonminimal-source products. Types, inputs and
resource limits were frozen in RECORD/QUANTUM_RECORD/REVIEW_RECORD.

Dependencies are the qualified DWH raw Hamiltonian, actual primary and
replay F/T charts, full-jet action/source/probe data, MWP reconstructed
gauge-fixing/source density, and MWC free mixed inverse. This proof uses
the same action, reference and algebra libraries as those calculations.
It is internal analytic/computational evidence, not a formal-assistant
proof or independent validation of the physical premises.

## Canonical transport, including the external directions

If physical=F raw and raw=T physical, ordinary coordinates and their
polarizations use T, source covectors use F transpose. Marked epsilon
directions use the antighost T block as well. Apply the inherited Wick
phases to fields and sources, an additional i for each time derivative,
and the density minus sign. The standard canonical odd-generator flow
is Xphi=-Euler_J K, XJ=Euler_phi K. Transplanting the signed raw bracket
without this transport would be incorrect.

The transported K_D has2430 positions, its ordinary polarized Hessian
3872. All1286 field/source columns equal direct transport of Dminus,
including all33 Da=epsilon normalizations and all zero columns. A replay
calculation substitutes color first and Wick phases second, and reverses
the h/k polarization order. Both routes agree. Omitting the epsilon
rotation changes K and fails its normalization control.

Write K_D=sum epsilon_s O_s+div j, with epsilon on the LEFT. Functional
Euler differentiation, rather than coefficient extraction, gives O_s.
The four explicit IBP currents each have33 positions; review constructs
them from the derivative-epsilon terms and verifies the full density
identity. These currents have not been thrown away as density zeros.

For every broken s, the exact auxiliary-gauge-fixing relation is

    O_s=-i(E_Lambda_s GF-i Ja_s-Omega_s Lambda_s/2).

Replacing E_Lambda GF-iJa with the full source-dependent QJLambda
leaves32 nonzero components. Those corrections are preserved in the
canonical table. Their ordinary-field Hessians vanish; their densities
are not zero. They cannot be discarded in a general connected identity.
This calculation uses the actual O_s and its own affine endpoints.

## Actual action support at gauge order zero

On the requested post-differentiation source locus, the original Ja
source vertex is affine: Qa=i Lambda in all45 directions. The free
ghost Euler operator is -box C. With Sghost=a^T M C, the free momentum
matrix is p^2 times identity. Each ghost-pair background of the original
g0 action is linear in Lambda; this is checked directly on the replay
action density, separately from its GF gradients. Define its matrices
M_Lambda_r. O_s has a Ca root L_s=-i M_Lambda_s, and the complete affine
part

    O_s,affine=y_s-Ja_s-i Omega_s Lambda_s/2,  y_s=div B_s.

There is no BB root at this gauge order. The measured BB root starts at
g1 and is not covered here. Scalar/matter channels do not couple to
these g0 endpoints; the scalar-auxiliary source response starts at g1.
Consequently their possibly nontrivial source-independent factors do
not contribute this coefficient. This is a coupling/support restriction,
not a claim that the scalar or matter theory is free.

The complete g0 U=QG ghost-free sector is sum Pi_r Z_r^2, where

    Z_r=i y_r+Omega_r Lambda_r/2-i Ja_r,

and Pi selects the actual unbroken or broken probe. This includes the
source-only Ja^2 contact. All ghost-pair U backgrounds are affine in
Ja,Lambda,y, with no internal ghost derivatives or anomalous CC/aa
blocks on this locus. The broken probe has4128 quartic-ghost words;
their field Hessians vanish at zero ordinary ghost mean. They are
counted before the restriction. Unexpected surviving backgrounds would
fail this reduction, rather than be omitted. Sources are differentiated
before restriction. Let N_pr=Euler_Ja_r U's ghost matrix, Y_pr the y_r
ghost matrix. The full source companion data remain in the parent.

## Proper quantum kernel and its action-based sign

Insert rho K_D, with rho odd; rho epsilon_s is even. At fixed means the
actual coefficient is

    Gamma1[rho epsilon_s u Ja_r]=T_pr,sr Pi_t(p),
    T_pr,sr=Tr(L_s N_pr).

Both ordered inverse responses are retained. Their reduced expression
is the sum with weight1/4 in the doubled ghost Hessian; it reduces to
the color trace above, not twice or minus that trace. To check the
semantic action/Hessian bridge, review performs direct Berezin
integration of three nonsymmetric three-pair Gaussian actions including
rho and epsilon as independent odd generators. The mixed -log Z
coefficients13/29,513/1681,559/2809 agree with the two ordered doubled
Hessian terms and the color formula. This tests an action-based sign
and normalization, rather than two uses of a shared Hessian conversion.

Every2970 color/probe position is independently recomputed from replay
action derivatives, including2913 zeros. There are57 nonzero positions,
all in the broken probe. For example T_broken,12,12=-16 xi^2. No value
was fitted to a Ward target.

With the inherited positive heat E_q=exp(-2t q^2),

    Pi_t(p)=integral d4q/(2pi)^4 E_q E_(q+p)/(q^2(q+p)^2)
           =B(z)/(16pi^2), z=2t p_E^2,
    B(z)=2 E1(z)-E1(z/2)+2(exp(-z/2)-exp(-z))/z.

Schwinger parameters s,r>=2t give
B(z)=2 integral_(1/2)^1 dx E1(z x). Integrating E1 gives the displayed
formula. Integrating one Schwinger parameter first instead gives
B(z)=integral_0^1 dw [exp(-z/(1+w))-exp(-z/w)]/z. Separate quadrature at
z=1/5,2,7 agrees below1e-35 absolute. As t decreases,

    Pi_t=[-log(t p_E^2)-gamma_E+1-2log2+o(1)]/(16pi^2).

Removing -log(mu^2 t) gives the nonlocal finite reference kernel

    [log(mu^2/p_E^2)-gamma_E+1-2log2]/(16pi^2).

There is no power UV divergence in this bubble. A finite local
extension/mixing matrix remains symbolic and is not identified with
kappa,b0 or chi4. This reference expression does not select its value.

## Actual regulated means and all five connected terms

The full free vector/auxiliary inverse is retained. In momentum space
K_BB=p^2 delta-pp, K_BLambda=p, K_LambdaB=-p, K_LambdaLambda=Omega;
G_BB=(delta+(Omega-1)pp/p^2)/p^2, G_BLambda=-p/p^2,
G_LambdaB=p/p^2, G_LambdaLambda=0. Direct5x5 multiplication checks the
inverse without replacing the vector by a scalar field. Taking the
divergence gives the longitudinal covariance

    H0=[[0,i],[i,Omega]], H0^-1=[[Omega,-i],[-i,0]].

For each color, the actual longitudinal density on this locus is

    (i Lambda y+Omega Lambda^2/2)/E -i Ja Lambda
       +u Pi Z^2 +theta(y-Ja-i Omega Lambda/2), theta=rho epsilon.

The original GF/source density and the whole Ufree density are checked
coefficientwise against these expressions. In particular -theta Ja
and -u Pi Ja^2 are retained. Solving stationarity, to first u, gives

    y=E Ja-u Pi Omega E(1-E)Ja-Omega E theta/2,
    Lambda=2i u Pi E(1-E)Ja+i E theta.

The mixed theta/Ja mean derivative is zero because the actual sector
is quadratic with a source-independent Hessian. No quantum tadpole
has been normalized to zero. The full remaining one-loop tadpole is
multiplied by this proved zero mean derivative at g0. This argument
does not persist automatically at g1 or for other source products.

At independent heat labels E_epsilon and E_Ja the effective ghost roots
are L_s+i E_epsilon M_Lambda_s and
N_pr+E_Ja Y_pr+2i Pi_r E_Ja(1-E_Ja)M_Lambda_r. The connected coefficient
is their negative traced product times Pi_t. These are the proper,
two single-mean and both-mean contributions. The fifth, nonlinear-mean
branch is zero by the just-derived stationary equations. A Utheta
ghost term multiplies the zero original Ja ghost vertex in this
coefficient and contributes zero by actual support.

The computed color identities give the stronger exact factorization

    W1_reference=-T_pr,sr (1-E_epsilon)(1-E_Ja)^2 Pi_t(p).

Momentum conservation equates the external squared momenta, so this is
-T(1-E_p)^3 Pi_t. All57 nonzero positions have a third-order root at
E=1. The other2913 positions vanish as complete polynomials. Finite-heat
controls are sensitive in all57 positions: the proper-only answer
differs. The UV root alone is not a completeness test: an incomplete
subset can also have a root. The action/endpoint checks and finite-heat
coefficient comparison are needed.

For a general finite parent functional A, keep its entire Legendre
transport symbolically:

    -[A_ij+A_i,phi[y_j]+A_j,phi[y_i]
       +A_phi,phi[y_i,y_j]+A_phi[y_ij]].

Here y_ij=0 at this order, but no A tadpole or other jet is assigned
zero. Use full B/source responses for A, not the reduced ghost-only
description. No complete arbitrary-A mixing prescription or cancellation
is proved. The reference-kernel zero is not a normalization theorem.

## Infrared proof family and ordered finite part

The reference bubble is logarithmic in external momentum and locally
integrable jointly in p near zero. Its infrared scaling degree is0<4;
there is no additional delta(p) ambiguity consistent with this bound.
This is not the earlier critical p^-4 infrared contact problem.

For an explicit free-edge smoothing family put
f_delta(p)=(1-exp(-p^2/delta^2))^2 on each edge. Replacing the free
Gaussian covariance by f E G0 is an auxiliary proof family, not an
identity for the physical fixed-R inverse at finite delta. In fact
H_t(f E G0)=f I, so its inverse/source defect1-f is nonzero and must
be retained in such a comparison. The stationary formulas with F=fE
refer specifically to that auxiliary Gaussian action.

The zero-momentum loop bubble in this family is explicitly nonzero:

    Pi_t,delta(0)=-sum_(j=0)^4 (-1)^j binom(4,j)
                    log(4t+j/delta^2)/(16pi^2).

This follows by expanding (1-exp(-x/delta^2))^4 in the radial integral
integral_0^infty dx exp(-4t x)(1-exp(-x/delta^2))^4/x. Independent
quadrature verifies the Frullani sum. Its UV finite part is

    [log(mu^2/delta^2)+4log3-10log2]/(16pi^2).

At finite delta the external heat factor after UV subtraction is
(1-f_delta)^3, not zero. The UV subtraction is that of the common
parent functional transported through the SAME regulated mean. One
must not replace it by a separately guessed sewn subtraction.

To justify the subsequent Schwartz IR limit, set p=delta v. The
profiled finite-part bubble is (log(mu^2/delta^2)+b(v))/(16pi^2), where
b is bounded on compact v sets and grows at most logarithmically.
This follows by subtracting the common large-loop 1/q^4 coefficient:
near either loop origin the profile removes the pole; in the outer
region ordinary expansion gives an integrable remainder. Splitting
the loop into neighborhoods of0,-v and their complement yields the
stated bound uniformly on compact v sets, and the usual logarithmic
large-v bound. Meanwhile1-f_delta=2exp(-v^2)-exp(-2v^2).
Thus pairing (1-f_delta)^3 times the bubble with a Schwartz test
function is bounded by C delta^4(1+abs(log delta)), and tends to zero.
This also bounds endpoint inverse/source-defect differences here:
the actual y/Lambda contractions have canceled external propagator
denominators, and differences of their finite polynomials in f,E
contain1-f. No zero-momentum point value is interchanged with the
integral. The analogous global delta^4 bound is NOT asserted for the
proper bubble alone, which lacks the external Gaussian localization.

For the unprofiled reference, (1-E_p)^3 Pi_t tends to zero in the same
Schwartz sense: split at bounded p, use O(t^3 p^6 abs(log t)) there,
and Schwartz decay plus the heat-bubble bounds in the complement.
The common UV-FP-then-IR reference construction therefore exists in
this g0 coefficient. This proves neither a finite-delta physical Ward
identity nor a limit for arbitrary multiple insertions or finite A.

## Verification disposition and next inference

First review FAILED on a Coeff-times-Fraction type error in a finite-
heat control. Full failed source, capture and controller failure are
retained. V2 explicitly converts the scalar to a coefficient constant;
the complete review passes in8.617769s. V2's controller freezes all new
bytes and bindings; its worker also rechecks the unchanged V1 science
input manifest. Final review authenticates both manifests and source
copies. Native transport10.949157s, quantum7.656919s after imports.

This is an actual nonzero proper primitive quantum kernel and its
complete reference mean transport in one entire coupling coefficient.
It is not full fixed-operator Ward restoration, a contact mixing theorem,
QAP/measure/equivalence, E5/A5, or physical viability. The least expensive
next test is actual g1 support and stationary-response analysis, where
the BB root and scalar-auxiliary endpoints first enter; do not import
the g0 nonlinear-mean zero or automatically expand295 vector profiles.
