# WPC: actual canonical Ward primitive and its first quantum coefficient

Prospective at6dba270618d57d5e57354edac79eee47873268f7/main after clean
preflight,no matching workers,currentAGENTS/highestV676/actualreceipts.
Previous goal turn MGT/DWH PROGRESS. Same full active goal;state113/34of39,
E5/A5 OPEN,custody2/sevenNOTPASS unchanged. No agents,newcheckout,remote,
adoption,promotion or protected activation.

Question: what is the actual canonical primitive/insertion kernel needed
by the current quantum Ward comparison? Begin with COMPLETE coordinate
transport, not a guessed ghost determinant or a new counterterm ansatz.
Same unshifted Euclidean A0,first-u,nonnegative polynomial ring,
intrinsic0/1 and independent Schwartz marked epsilon/nonminimal-source
directions. Native180/review180s afterimports,8GiB sampled private ceiling,
350MiB launch floor,16MiB packet. Freeze hashes/source copies before each
worker; preserve failures; E4once/nofresh and old/raw/state preservation.

Stage1: use actual primary F/T frame and raw DWH generator/Hessian/maps.
Transport ordinary fields with T, covectors with F^T, BOTH h/k directions,
and all33 marked epsilon directions with the antighost T chart. Apply
the existing Wick/time-derivative phases and density sign. Exclude only
the fixed background A0 monomials. Fail if a broken epsilon acquires
an undeclared unbroken component. Compare all1286 canonical Hamiltonian
columns against the directly transported Dminus vector field. Check
Da=epsilon and the source contact exactly. Compare transport of the
complete polarized Hessian with two derivatives of the transported action.

Extract epsilon components by functional Euler differentiation, retaining
their explicit boundary current; simple coefficient extraction would
miss derivative-epsilon terms. Test, without fitting, whether the result
is the expected auxiliary-Euler combination. Report ANY residual fully
and distinguish full-source versus restricted-source statements. Do not
infer a quantum identity from a failed classical comparison.

Stage2 only after the transport gate: identify the ACTUAL g0 proper
first-u epsilon/Ja kernel from its canonical ghost and source matrices,
including the zero complement. Validate the number-conserving ghost
shortcut on this precise source locus; retain anomalous sectors until
their post-differentiation absence is proved. Use graded Gaussian/Berezin
and ordered inverse-response checks, not shared Hessian agreement alone.
Match the scalar heat bubble and distinguish ultraviolet logarithm,
nonlocal finite term,finite local ambiguity and IR contribution. Preserve
free finite contact matrices; do not identify them with kappa,b0 or chi4.

Then derive ALL connected mean branches in this same g0 sector before
claiming a connected coefficient. Affine scalar/vector/auxiliary/source
terms may not be discarded because their proper field Hessian is zero.
Use the actual free mixed propagator and source/probe action. A qualified
zero,nonzero response,missing premise or bounded incomplete result are
all acceptable. Higher-gauge/vector families follow actual missing input,
not a preference for easier calculations. No full QAP/E5/physical claim.

This is an internal calculation with shared action/chart/regulator/exact
software/AIauthor. Agreement does not independently validate those premises
or the physical model. New numerical normalizations are not selected.
