# WPC separate action, chart and analytic review

Prospective after completed native transport and g0 quantum calculation.
Native result:57/2970 proper color positions nonzero; connected reference
heat polynomial has a root at E=1. These are proposed bounded results,
not a full quantum Ward identity. Do not weaken them if review fails.

Reconstruct the canonical density using the replay frame with color
substitution BEFORE Wick phases. Check the complete Hamiltonian flow,
reverse-polarized Hessian and marked-epsilon Euler components. Construct
the epsilon integration-by-parts currents explicitly. Recompute ghost
matrices from replay action derivatives and compare every color position
and zero; reconstruct the original ghost background from the density,
not only from the auxiliary gradient. Source restrictions follow source
derivatives. Unexpected surviving sectors fail the reduced premise.

Independently solve the actual 2x2 free longitudinal stationary equations
with the source-only contacts and uZ-square. Check both endpoints and
their mixed derivative, and compare the two ordered Gaussian ghost
responses with direct finite Berezin integration of a nonsymmetric
matrix action, including paired odd rho/epsilon markers. Test missing
endpoint/heat controls without assuming the UV zero is sensitive to them.

Derive the exact heat bubble, independently integrate its Schwinger
representation, and check its UV constant. Retain the nonzero finite-IR
profile bubble and inverse/source defect. Prove only the common
reference-kernel Schwartz limit; do not claim an exact physical Ward
identity for the auxiliary fE Gaussian family. All finite parent-A
derivatives remain symbolic; no new normalization is selected.

Review180s after imports,8GiB sampled/350MiB launch/16MiB packet.
Same action/regulator/exact libraries/AI author; this is distinct internal
reconstruction, not external physical validation or formal-assistant proof.
