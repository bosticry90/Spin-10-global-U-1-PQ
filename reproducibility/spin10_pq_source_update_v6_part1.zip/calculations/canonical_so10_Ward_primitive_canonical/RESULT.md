# WPC: first actual Ward-primitive quantum coefficient

The canonical Dminus primitive and its first-u,g0 one-loop epsilon/Ja
response have been calculated, including every33x45x2 color/probe
position. Native transport and quantum runs completed, and the separate
replay/action/Berezin/analytic review passes within the frozen scope.
The first review's type-error failure is preserved; it is not PASS.

- Canonical density2430 positions; polarized Hessian3872. All1286 flow
  columns and all33 marked epsilon normalizations agree. All four
  epsilon IBP currents are explicit,33 positions each.
- Auxiliary GF Euler comparison has zero residual. Replacing it with
  full source QJLambda leaves32 components, all retained. Their ordinary
  Hessians are zero; their affine source effects cannot be erased.
- Proper quantum tensor:57 nonzero positions,2913 zeros, all nonzero
  positions in the broken probe. Example T_12,12=-16 xi^2. Its reference
  finite scalar kernel is [log(mu^2/p_E^2)-gamma_E+1-2log2]/(16pi^2).
- Complete connected reference response is
  -T(1-E_epsilon)(1-E_Ja)^2 Pi_t; after momentum conservation it has
  the cubic heat factor(1-E_p)^3. All five Legendre branches were
  evaluated: the mixed nonlinear mean is zero by actual g0 stationarity,
  with source-only contacts retained. No zero-tadpole condition is used.
- A nonzero finite-IR profile bubble is retained. The common reference
  UV-finite-part-then-IR limit is zero in Schwartz pairing, with the
  auxiliary profile's inverse/source defect1-f explicitly distinguished
  from a physical finite-delta Ward identity.

[Proof](PROOF.md), [native quantum result](quantum_result.json),
[complete coefficients](quantum_tables.json.gz),
[separate review](validation_receipt_v2.json).

## Focused result-to-claim assessment

Evidence supports a bounded actual g0 proper quantum kernel and its
reference connected mean transport. This is stronger than an ansatz or
a classical generator comparison:57 coefficients are measured nonzero,
the entire zero complement is checked, and action-based Berezin tests
check the graded semantic bridge. The finite-heat controls are sensitive
in all57 positions; the UV zero alone is insufficient to establish
complete endpoints. Shared action, chart, regulator, exact libraries
and AI authorship remain shared-error limits. This is not new
experimental support for the Spin(10) hypothesis.

The connected reference zero does not fix the finite local contact
matrix or the parent-A contributions, which remain symbolic and
unidentified with kappa,b0,chi4. It does not establish the full quantum
Ward equation, multiple products, physical-source measure or E5/A5.
The BB root and scalar-auxiliary endpoints enter at g1 and remain
unmeasured in this primitive response. Neither the selected zero nor
the proper nonzero term is an anomaly verdict.

The next discriminating action is to derive the complete g1 support
and mixed stationary equations from the existing action, then determine
which kernels and tadpole contractions are actually needed. Retain
all source derivatives and scalar endpoints. Do not assume the g0
nonlinear-mean zero at g1 or expand the295 vector profiles without an
identified dependence. State113/34of39 and E5/A5 OPEN are unchanged;
historical custody remains exit2/seven unresolved, NOTPASS.
