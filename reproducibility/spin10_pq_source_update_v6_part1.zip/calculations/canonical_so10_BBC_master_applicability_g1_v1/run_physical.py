from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/BBC-master-applicability-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
for n,h in json.loads((O/'preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
cap=json.loads((O/'master_scope_capture.json').read_bytes());assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
deps={'canonical_so10_proper_slavnov_source_chain_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_gaussian_current_reduction_g1_v1':['validation_receipt.json','PROOF.md','native_own_jet_trace.json.gz','replay_own_jet_trace.json.gz'],'canonical_so10_chiral_probe_support':['validation_receipt.json','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz'],'canonical_so10_regulator_free_inverse_g1_recovery_v1':['validation_receipt.json','PROOF.md']};names=['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['PHYSICAL_RECORD.md','physical_bridge.py','run_physical.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'physical_preparation.json',dict(sha256={**json.loads((O/'preparation.json').read_bytes())['sha256'],**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'physical_bridge.py')]);dump(O/'physical_bridge_capture.json',cap);dump(C/'physical_bridge_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
