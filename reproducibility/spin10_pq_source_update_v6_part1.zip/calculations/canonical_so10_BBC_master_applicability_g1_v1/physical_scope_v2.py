from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('BBC_physical_scope_reuse_tools',Path(__file__).resolve().with_name('master_scope.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);J=m.J;O=m.O;R=m.R;one=m.one
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in m.read(O/'physical_preparation_v2.json')['sha256'].items():assert m.digest(R/n)==h,n
 cap=m.read(O/'physical_bridge_capture.json');assert cap['exit_code']==124 and not cap['calculation_completed']and cap['post_run_observations_qualified'];assert not(O/'physical_bridge_result.json').exists()
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=m.load(base/'native_inputs.json.gz');assert packet==m.load(base/'replay_inputs.json.gz');states={name:dict(rows)for name,rows in packet['states'].items()};old=O.parent/'canonical_so10_physical_current_input_recovery_g1_v1';receipt=m.read(old/'validation_receipt.json');assert receipt['evidence_validation']=='PASS_COMPLETE_PAIRED_PHYSICAL_ACTION_CURRENT_KERNEL_INPUTS';interfaces=[]
 for suffix,key in[('field_flows',None),('euler',None),('noether',None)]:assert(old/('native_v2_'+suffix+'.json.gz')).read_bytes()==(old/('replay_v4_'+suffix+'.json.gz')).read_bytes(),suffix
 flows=m.load(old/'native_v2_field_flows.json.gz');euler=m.load(old/'native_v2_euler.json.gz');noether=m.load(old/'native_v2_noether.json.gz')
 for name,key in[('F0','original_F0'),('F1','original_F1')]:
  target=dict(flows[key]);assert len(target)==508
  for n in range(508):assert states[name][n]==target[n],(name,n,'FULL_PHYSICAL_FLOW_INTERFACE');interfaces.append([name,n,m.digest(old/'native_v2_field_flows.json.gz'),True])
 for name,key in[('P_E0','E0'),('P_E1_gauge','E1_B_gauge'),('P_E1_scalar','E1_B_scalar')]:
  assert packet['physical'][name]==euler[key],name
  for n,poly in euler[key]:interfaces.append([name,n,m.digest(old/'native_v2_euler.json.gz'),True])
 assert all(not states['F0'][n]for n in range(180,508));zeros=[]
 for name in['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  for n in range(508):assert not states[name][n];zeros.append([name,n,[]])
 assert all(not poly for rows in flows['full_source_first_probe_flows']for n,poly in rows);assert packet['physical_E1_x_not_computed_or_zeroed'];assert noether['Noether_residuals']==[[],[],[]]and noether['full_density_variations']==[[],[]]
 profiles={};controls=[];wordcounts={}
 for name,N in[('I0',2),('I1_gauge',3),('I1_scalar',3)]:
  census=Counter();rows=noether[name];wordcounts[name]=len(rows)
  for ww,cells in rows:
   assert len(ww)==N and all(n<598 for n,js in ww)and sum(553<=n<598 for n,js in ww)==1;census[sum(n<180 for n,js in ww),sum(180<=n<508 for n,js in ww),sum(553<=n<598 for n,js in ww),sum(len(js)for n,js in ww)]+=1
  profiles[name]=[[*pr,num]for pr,num in sorted(census.items())]
  if name=='I0':continue
  row=next(row for row in rows if any(553<=n<598 and not js for n,js in row[0]));mono=J.decode([row]);E=J.euler(mono,set(range(553,598)));assert E;controls.append(dict(owner=name,actual_added_monomial=J.encode(mono),complete_perturbation_Euler=[[n,J.encode(q)]for n,q in sorted(E.items())],nonzero_functional_residual_with_original_currents=True))
 phys=m.save('physical_Noether_BBC_applicability_v2.json.gz',dict(owning_complete_Noether_proof=dict(file=(old/'native_v2_noether.json.gz').relative_to(R).as_posix(),sha256=m.digest(old/'native_v2_noether.json.gz'),native_replay_all_arrays_equal=True,Noether_residuals=noether['Noether_residuals']),fresh_complete_operand_interfaces=interfaces,all2032_probe_physical_flow_zero_columns=zeros,full_Noether_word_profiles=profiles,full_Noether_word_counts=wordcounts,monomial_functional_controls=controls,pre_Taylor_identity_reused_not_fresh_full_Noether_expansion=True,source_identity_applies_to_any_later_even_Taylor_and_BBC_projection=True,unknown_E1_x_bypassed_not_zeroed=True,old_V1_timeout124_stays_INCOMPLETE_NOTPASS=True,whole_owner_omission_would_be_blind_by_separate_invariance_NOT_EXECUTED_IN_V1=True));print('STAGE qualified_full_physical_Noether_inputs_match_and_BBC_scope_verified',flush=True)
 own=[];nonzero=[]
 for name in['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  for n in range(643):
   P=J.decode(states[name][n]);jets=sorted({js for ww in P for i,js in ww if i==n});rows=[]
   for js in jets:
    q=J.leftjet(P,(n,js));rows.append([list(js),J.encode(q)])
    if q:nonzero.append([name,n,list(js),J.encode(q)])
   own.append(dict(state=name,field=n,all_present_own_jet_derivatives=rows,all_absent_own_jets_zero=True))
 jac=m.save('BBC_full_own_jet_trace_v2.json.gz',dict(all3858_full_source_field_columns=own,all_nonzero_own_jet_derivatives=nonzero,zero_before_mean_source_restriction=True,not_global_chiral_measure_zero=True));assert not nonzero;assert m.read(O/'master_scope_result.json')['all_six_GF_master_divergences_exact']
 cps=(O.parent/'canonical_so10_chiral_probe_support/DERIVATION.md').read_text(encoding='utf-8');assert 'fermion block and Ihat' in cps and 'no u/rho dependence' in cps and 'does not prove a source' in cps
 out=dict(schema='BBC_PHYSICAL_MASTER_SCOPE_AND_FINITE_PROPER_BRIDGE_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',physical_master_pre_Taylor='REUSED_QUALIFIED_V788_FULL_IDENTITIES_WITH_FRESH_COMPLETE_OPERAND_INTERFACES',all_physical_source_packet_operands_match_qualified_Noether=True,all2032_probe_physical_columns_zero=True,Noether_word_counts=wordcounts,all3858_own_jet_columns_zero_before_restriction=True,GF_full_BBC_pre_Taylor_master_reused=True,hatted_first_u_BBC_trace_zero='WRITTEN_CPS_STABLE_IDEAL_u_INDEPENDENCE_SCOPE_APPLICATION_NOT_NEW_CLIFFORD_RUN',finite_proper_relation='QGamma1=-C_Q=C_R in selected first-u BBC finite formal Gaussian domain',whole_regulator_mean_subtraction_retained=True,unprobed_BBC_zero_NOT_CLAIMED=True,quantum_BBC_amplitude_and_UV_IR_limit_NOT_YET_CALCULATED=True,physical_artifact=phys,own_jet_artifact=jac,old_V1_timeout124_INCOMPLETE_NOTPASS=True,full_QAP_E5_A5_viability_restoration_NOT_CLAIMED=True,elapsed_after_imports=time.perf_counter()-tick);m.dump(O/'physical_bridge_result_v2.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
