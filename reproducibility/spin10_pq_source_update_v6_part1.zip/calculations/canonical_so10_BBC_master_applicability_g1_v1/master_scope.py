from pathlib import Path
from fractions import Fraction as Fr
from collections import Counter
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('BBC_actual_master_helpers',O.parent/'canonical_so10_aCC_operator_reduction_g1_v1/master.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);J=a.J;w=a.w;one=J.constant(1);zero=J.ZERO
def read(p):return json.loads(p.read_bytes())
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def profile(ww):
 b=sum(n<180 for n,js in ww);c=sum(553<=n<598 for n,js in ww);ab=sum(598<=n<643 for n,js in ww);return b,c,ab,len(ww)-b-c-ab,len(ww),sum(J.dimension(n)+len(js)for n,js in ww)
def new_allowed(pr,totaldim=5):
 b,c,ab,other,n,d=pr;return n>=2 and max(b-2,0)+max(c-1,0)+ab+other<=2 and totaldim-d in[0,1]
def old_allowed(pr,totaldim=5):
 b,c,ab,other,n,d=pr;return n>=2 and b+other+max(ab-1,0)+max(c-2,0)<=2 and totaldim-d in[0,1]
def select(P,totaldim=5):return{ww:c for ww,c in P.items()if new_allowed(profile(ww),totaldim)}
def plus(*ps):return w.plus(*ps)
def scale(P,c):return w.scale(P,c)
def literal_mul(P,Q):
 out={}
 for ww,c in P.items():
  for vv,d in Q.items():
   combined=ww+vv;odds=[token for token in combined if J.parity(token[0])]
   if len(odds)!=len(set(odds)):continue
   sg=(-1)**sum(x>y for at,x in enumerate(odds)for y in odds[at+1:]);key=tuple(sorted(combined));out[key]=out.get(key,zero)+J.times(c,d)*sg
 return J.clean(out)
def first_order_current(P):
 out=[{}for mu in range(4)];nojet={};inventory=Counter()
 for ww,c in P.items():
  jets=sum(len(js)for n,js in ww);inventory[len(ww),jets]+=1
  if not jets:nojet[ww]=c;continue
  assert len(ww)==4 and jets==1,'NEW_ENVELOPE_UNEXPECTED_DERIVATIVE_DEGREE'
  pos=next(at for at,(n,js)in enumerate(ww)if js);n,js=ww[pos];J.put(out[js[0]],ww[:pos]+((n,()),)+ww[pos+1:],J.times(c,J.constant(Fr(1,4))))
 out=[J.clean(q)for q in out];div={}
 for mu,q in enumerate(out):J.add(div,J.D(q,mu))
 return out,J.clean(div),nojet,[[n,d,num]for(n,d),num in sorted(inventory.items())]
def owner_case(old,label):
 if label in['original_g0','original_g1','probe0_g0']:
  z=load(old/('master_'+label+'.json.gz'));return J.decode(z['source_free_eligible_density']),[J.decode(q)for q in z['currents']]
 if label in['probe0_g1','probe1_g0']:
  z=load(old/('master_v2_'+label+'.json.gz'));return J.decode(z['source_free_eligible_density']),[J.decode(q)for q in z['currents']]
 assert label=='probe1_g1';z=load(old/'master_v3_density.json.gz');curr=[{}for mu in range(4)]
 for name in['master_v4_sector_2.json.gz','master_v4_sector_3.json.gz','master_v5_sector_4.json.gz']:
  q=load(old/name);assert not q['Euler_remainder']
  for mu,pp in enumerate(q['currents']):J.add(curr[mu],J.decode(pp))
 return J.decode(z['source_free_eligible_density']),[J.clean(q)for q in curr]
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(base/'native_inputs.json.gz');assert packet==load(base/'replay_inputs.json.gz');states={name:{n:J.decode(poly)for n,poly in rows}for name,rows in packet['states'].items()};old=O.parent/'canonical_so10_aCC_operator_reduction_g1_v1';receipt=read(old/'validation_receipt.json');assert receipt['all9645_actual_source_free_port_products_independently_reconstructed']and receipt['all_GF_master_remainders_zero']and receipt['failed_parent_cases_not_reclassified'];comm=load(old/'master_Taylor_commutation.json.gz');assert comm['all4_mu_prefix_LEFT_commutators_zero']and comm['quantum_generators_T_zero'];cache={};factors=[]
 def groups(label,n):
  key=label,n
  if key in cache:return cache[key]
  raw=states[label][n];P={ww:c for ww,c in raw.items()if all(i<643 for i,js in ww)};G={}
  for ww,c in P.items():pr=profile(ww);assert old_allowed(pr)==a.allowed(a.profile(ww));G.setdefault(pr,{})[ww]=c
  factors.append(dict(state=label,field=n,sourceful_math_sha256=sha256(json.dumps(J.encode(raw),sort_keys=True).encode()).hexdigest(),complete_source_free_words=J.encode(P),group_profiles_and_word_counts=[[list(pr),len(q)]for pr,q in sorted(G.items())]));cache[key]=G;return G
 cases=[('original_g0',[('F0','E0')]),('original_g1',[('F1','E0'),('F0','E1')])]
 for pr in[0,1]:cases += [('probe'+str(pr)+'_g0',[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))]),('probe'+str(pr)+'_g1',[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))])]
 summaries=[];portcount=0;allpass=True
 for label,branches in cases:
  total={};last={};ports=[];paircount=0
  for at,(left,right)in enumerate(branches):
   for n in range(643):
    L=groups(left,n);M=groups(right,n);out={};peer={};journal=[];count=0
    for lp,l in sorted(L.items()):
     for rp,r in sorted(M.items()):
      pr=tuple(x+y for x,y in zip(lp,rp));new=new_allowed(pr);prior=old_allowed(pr);extra=new and not prior
      if extra:J.add(out,J.mul(l,r));J.add(peer,literal_mul(l,r));count+=len(l)*len(r)
      journal.append([list(lp),list(rp),list(pr),new,prior,extra])
    out=J.clean(out);peer=J.clean(peer);assert out==peer,(label,left,right,n,'FULL_NEW_PRODUCT_LITERAL_REPLAY');J.add(total,out)
    if at==len(branches)-1:J.add(last,out)
    ports.append(dict(left=left,right=right,field=n,all_group_pair_dispositions=journal,complete_new_product=J.encode(out),all_literal_coefficients_equal=True,all_evaluated_word_pairs=count));paircount+=count;portcount+=1
  total=J.clean(total);last=J.clean(last);curr,div,nojet,inv=first_order_current(total);remainder=plus(total,scale(div,-one));oldP,oldJ=owner_case(old,label);oldP=select(oldP);oldJ=[select(q,4)for q in oldJ];olddiv={}
  for mu,q in enumerate(oldJ):J.add(olddiv,J.D(q,mu))
  assert J.clean(olddiv)==oldP,(label,'REUSED_PROJECTED_CURRENT_NOT_EXACT');full=plus(oldP,total);fullJ=[plus(x,y)for x,y in zip(oldJ,curr)];fullDiv={}
  for mu,q in enumerate(fullJ):J.add(fullDiv,J.D(q,mu))
  assert plus(full,scale(J.clean(fullDiv),-one))==remainder;degree=int(label.endswith('g1'));assert all(k[0]==degree for coef in full.values()for k,v in coef.terms)
  omit=plus(total,scale(last,-one));oc,od,on,oi=first_order_current(omit);omitr=plus(omit,scale(od,-one));monomial={};monE={}
  nonempty=total or next((J.decode(row['complete_new_product'])for row in ports if row['complete_new_product']),{})
  if nonempty:
   ww,c=next(iter(sorted(nonempty.items())));monomial={ww:c};monE=J.euler(monomial,set(n for n,js in ww))
  art=save('master_scope_'+label+'.json.gz',dict(case=label,branches=branches,all643_port_branch_decisions=ports,complete_new_extra_density=J.encode(total),new_degree_jet_inventory=inv,new_zerojet_density=J.encode(nojet),new_four_currents=[J.encode(q)for q in curr],complete_new_master_remainder=J.encode(remainder),projected_reused_density=J.encode(oldP),projected_reused_four_currents=[J.encode(q)for q in oldJ],full_BBC_envelope_density=J.encode(full),full_BBC_envelope_four_currents=[J.encode(q)for q in fullJ],full_master_remainder=J.encode(remainder),controls=dict(omit_last_branch_full_new_density=J.encode(omit),omit_last_branch_remainder=J.encode(omitr),half_new_current_complete_difference=J.encode(plus(total,scale(div,J.constant(Fr(-1,2))))),monomial=J.encode(monomial),full_monomial_Euler=[[n,J.encode(q)]for n,q in sorted(monE.items())],sensitivity=dict(omit_last=bool(omitr),half_current=bool(plus(total,scale(div,J.constant(Fr(-1,2))))),monomial=bool(monE))),old_parent_failed_executions_NOT_RECLASSIFIED=True,reused_current_identity_projected_not_old_products_rerun=True));matched=not remainder;allpass&=matched;row=dict(case=label,artifact=art,new_density_words=len(total),new_remainder_words=len(remainder),full_BBC_envelope_words=len(full),full_current_words=[len(q)for q in fullJ],all_new_port_literal_replays_equal=True,evaluated_new_word_pairs=paircount,GF_master_exact_divergence=matched);summaries.append(row);print('STAGE '+label+' new='+str(len(total))+' remainder='+str(len(remainder)),flush=True);del oldP,oldJ,full,fullJ;gc.collect()
 assert portcount==9645;factorart=save('master_scope_source_factors.json.gz',dict(all_source_operations_precede_source_zero=True,complete_source_free_factor_inventory=factors,profile_columns=['B','C','a','other','field_count','field_and_jet_dimension'],all9645_port_decisions_stored=True,quantum_T2_commutes_D_by_reused_generator_proof=True))
 out=dict(schema='BBC_SOURCEFREE_GF_MASTER_ENVELOPE_EXTENSION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ALL_SIX_GF_MASTER_PREREQUISITES_MATCH'if allpass else'NONZERO_NEW_CLASSICAL_MASTER_REMAINDER_PRESERVED',all_six_GF_master_divergences_exact=allpass,cases=summaries,all9645_port_decisions_and_literal_new_products=True,source_factors_artifact=factorart,old_failed_master_workers_still_FAILED_INCOMPLETE_NOTPASS=True,physical_hatted_proper_current_BBC_bridges_NOT_YET_QUALIFIED=True,no_new_loop_amplitude_or_normalization=True,common_restoration_E5_A5_viability_goal_completion_NOT_CLAIMED=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'master_scope_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
