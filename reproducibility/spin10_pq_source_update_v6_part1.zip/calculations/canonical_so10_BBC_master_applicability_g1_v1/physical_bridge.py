from pathlib import Path
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('BBC_master_scope_tools',Path(__file__).resolve().with_name('master_scope.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);J=m.J;w=m.w;O=m.O;R=m.R;one=m.one
def ghost_normal(P):
 normal={};curr=[{}for mu in range(4)]
 for ww,coef in P.items():
  ats=[at for at,(n,js)in enumerate(ww)if 553<=n<598];assert len(ats)==1;at=ats[0];n,js=ww[at];sg=(-1)**sum(J.parity(i)for i,jj in ww[:at]);rest={ww[:at]+ww[at+1:]:coef*sg}
  while js:
   mu=js[-1];js=js[:-1];J.add(curr[mu],J.mul({((n,js),):one},rest));rest=m.scale(J.D(rest,mu),-one)
  J.add(normal,J.mul({((n,()),):one},rest))
 normal=J.clean(normal);curr=[J.clean(q)for q in curr];div={}
 for mu,q in enumerate(curr):J.add(div,J.D(q,mu))
 assert m.plus(J.clean(div),normal)==P,'PHYSICAL_LITERAL_IBP_RECONSTRUCTION';peer={}
 for n,q in J.euler(P,set(range(553,598))).items():J.add(peer,J.mul({((n,()),):one},q))
 assert J.clean(peer)==normal,'PHYSICAL_LEFT_EULER_REPLAY';return normal,curr
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in m.read(O/'physical_preparation.json')['sha256'].items():assert m.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=m.load(base/'native_inputs.json.gz');assert packet==m.load(base/'replay_inputs.json.gz');states={label:{n:J.decode(q)for n,q in rows}for label,rows in packet['states'].items()};physical={label:{n:J.decode(q)for n,q in rows}for label,rows in packet['physical'].items()}
 for name in['F0','F1']:
  for n in range(508):
   for ww,c in states[name][n].items():assert all(i<598 for i,js in ww)and sum(553<=i<598 for i,js in ww)==1
 assert all(not states['F0'][n]for n in range(180,508));zeros=[]
 for label in['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  for n in range(508):assert not states[label][n];zeros.append([label,n,[]])
 assert all(len(ww)<=1 and all(n<508 for n,js in ww)for q in physical['P_E0'].values()for ww in q)
 for name in['P_E1_gauge','P_E1_scalar']:assert all(n<180 and all(len(ww)<=2 and all(i<508 for i,js in ww)for ww in q)for n,q in physical[name].items())
 B0={};B1={};omit_scalar={};omit_gauge={};ports=[]
 for n in range(508):
  p0=J.mul(states['F0'][n],physical['P_E0'][n]);p1=J.mul(states['F1'][n],physical['P_E0'][n]);p1g=J.mul(states['F0'][n],physical['P_E1_gauge'].get(n,{}));p1s=J.mul(states['F0'][n],physical['P_E1_scalar'].get(n,{}));J.add(B0,p0);J.add(B1,m.plus(p1,p1g,p1s))
  if n<180:J.add(omit_scalar,m.plus(p1,p1g));J.add(omit_gauge,m.plus(p1s))
  else:J.add(omit_gauge,p1)
  ports.append(dict(field=n,F0_E0=J.encode(p0),F1_E0=J.encode(p1),F0_E1_gauge=J.encode(p1g),F0_E1_scalar=J.encode(p1s),unknown_E1_x_bypassed_by_actual_F0_zero=n>=180))
 B0=J.clean(B0);B1=J.clean(B1);omit_scalar=J.clean(omit_scalar);omit_gauge=J.clean(omit_gauge);n0,c0=ghost_normal(B0);n1,c1=ghost_normal(B1);ns,cs=ghost_normal(omit_scalar);ng,cg=ghost_normal(omit_gauge);assert not n0 and not n1,'ACTUAL_PHYSICAL_MASTER_NOT_ZERO'
 art=m.save('physical_master_before_Taylor.json.gz',dict(all508_port_products=ports,physical_g0_density=J.encode(B0),physical_g0_four_currents=[J.encode(q)for q in c0],physical_g0_Euler_normal=J.encode(n0),physical_g1_density=J.encode(B1),physical_g1_four_currents=[J.encode(q)for q in c1],physical_g1_Euler_normal=J.encode(n1),all2032_probe_physical_zero_columns=zeros,unknown_physical_E1_x_NOT_COMPUTED_or_ZEROED=True,controls=dict(omit_scalar_F1_E0_full_density=J.encode(omit_scalar),omit_scalar_full_Euler_normal=J.encode(ns),omit_gauge_F1_E0_and_F0_E1_full_density=J.encode(omit_gauge),omit_gauge_full_Euler_normal=J.encode(ng),scalar_omission_sensitive=bool(ns),gauge_omission_sensitive=bool(ng)),no_potential_or_mass_renormalization=True));assert ns and ng,'PHYSICAL_MASTER_OMISSION_CONTROLS_BLIND';print('STAGE complete_physical_master_before_Taylor g0='+str(len(B0))+' g1='+str(len(B1)),flush=True)
 own=[];nonzero=[]
 for label in['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  for n in range(643):
   P=states[label][n];jets=sorted({js for ww in P for i,js in ww if i==n});rows=[]
   for js in jets:
    q=J.leftjet(P,(n,js));rows.append([list(js),J.encode(q)])
    if q:nonzero.append([label,n,list(js),J.encode(q)])
   own.append(dict(state=label,field=n,all_present_own_jet_derivatives=rows,all_absent_own_jets_zero=True))
 jac=m.save('BBC_full_own_jet_trace.json.gz',dict(all3858_field_columns=own,all_nonzero_own_jet_derivatives=nonzero,zero_before_mean_or_source_restriction=True,not_a_claim_of_global_chiral_measure_zero=True));assert not nonzero,'BBC_DIAGONAL_OWN_JET_JACOBIAN_NONZERO'
 gf=m.read(O/'master_scope_result.json');assert gf['all_six_GF_master_divergences_exact'];prior=m.read(O.parent/'canonical_so10_proper_slavnov_source_chain_g1_v1/validation_receipt.json');assert prior['scientific_acceptance']=='NOT_PERFORMED';cps=m.read(O.parent/'canonical_so10_chiral_probe_support/validation_receipt.json');assert cps.get('scientific_acceptance','NOT_PERFORMED')=='NOT_PERFORMED';proof=(O.parent/'canonical_so10_chiral_probe_support/DERIVATION.md').read_text(encoding='utf-8');assert 'fermion block and Ihat' in proof and 'no u/rho dependence' in proof and 'does not prove a source' in proof
 out=dict(schema='BBC_PHYSICAL_MASTER_AND_FINITE_PROPER_BRIDGE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',physical_g0_and_g1_master_before_any_Taylor_exact=True,all2032_probe_physical_columns_zero=True,physical_g0_words=len(B0),physical_g1_words=len(B1),all3858_own_jet_columns_zero_before_restriction=True,GF_full_BBC_pre_Taylor_master_reused=True,hatted_first_u_BBC_trace_zero='WRITTEN_CPS_STABLE_IDEAL_AND_u_INDEPENDENT_BLOCK_SCOPE_APPLICATION_NOT_NEW_CLIFFORD_RUN',finite_proper_relation='QGamma1=-C_Q=C_R in selected first-u BBC formal Gaussian domain',whole_regulator_mean_subtraction_retained=True,unprobed_BBC_zero_NOT_CLAIMED=True,quantum_BBC_amplitude_and_UV_IR_limit_NOT_YET_CALCULATED=True,physical_artifact=art,own_jet_artifact=jac,full_QAP_E5_A5_viability_or_restoration_NOT_CLAIMED=True,elapsed_after_imports=time.perf_counter()-tick);m.dump(O/'physical_bridge_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
