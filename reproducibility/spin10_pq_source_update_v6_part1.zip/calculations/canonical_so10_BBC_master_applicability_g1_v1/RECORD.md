# Actual BBC master applicability before another normalization ansatz

Continue70e2254866ba996501cbffe1aec941e80ce870d1/main,V824,D:repo.
Previous goal turn PROGRESS; preflight clean/no matching Python workers,
declared byte authentication only. Current AGENTS, state113/34of39,
E5/A5/full goal open. No agents/branch/worktree/adoption/protected activation/
push/external actions; flavor paused/HB1C5 blocked; education nonblocking.

V823/V824 excluded specific completion families for a FIXED source correction.
Their constructed BBC remainder is not the unmeasured actual quantum BBC
breaking. W2 supplies a local real counterterm envelope, not a completed
finite-probe source-cohomology basis; HB1/C5 remains blocked. Do not invent
another arbitrary source ansatz or assume its missing companions vanish.
The next valuable alternative is the actual BBC quantum input, beginning
with its classical master/proper applicability, not a guessed amplitude.

W3's actual equation is S(Gamma)=[S(S_R)]_Gamma+M_s. It does not generally
set every quantum variation to zero. Establish the BBC master prerequisites
before transferring any existing proper/current bridge to this new target.
This first stage qualifies ONLY the source-free GF master operand and its
two-Taylor domain, not the physical/hatted/proper/loop/limit obligations.

Original unshifted Euclidean A0, firstg/firstu H/M, intrinsic0/1, all643
ports/all45 colors/all4 vector components. External target B<=2,C<=1,
all other means0; allow two arbitrary quantum replacements. The necessary
pre-Taylor envelope is
 max(n_B-2,0)+max(n_C-1,0)+n_a+n_other<=2,
 with field count>=2 and coefficient intrinsic degree0/1. This is an upper
envelope, not a declaration every retained term contributes. Sources are
set zero only AFTER the qualified source/Euler operations in the packets.

Reuse V810's QUALIFIED case-level master densities and currents, not its
failed parent executions. Five completed case artifacts and the M-g1
335968-word density/separate V4 N2/N3 and V5 N4 currents were independently
reconstructed/validated by its final receipt. Old V1-V4 executions remain
FAILED/INCOMPLETE NOTPASS. Do not rebind historical policy or infer a PASS
from their old captures. New calculations bind current AGENTS.

The old envelope was other+max(a-1,0)+max(C-2,0)<=2. Project the already
qualified densities/currents into the intersection and reuse their exact
divergence identity. Field counts commute with even total derivatives;
current dimension4 and density dimension5 selections retain the same
intrinsic degree. Do not falsely commute a fixed dimension slice with D.
Calculate ONLY the NEW outside-old, inside-BBC-envelope products from the
actual complete source-free F/E maps for all6 original/H/M g0/g1 cases.
Keep all9645 port/branch decisions and full new products. Grouped primary
multiplication must equal independent literal word/sign multiplication
for EVERY new port product; no sampled color/port comparisons.

For the new density, classify every word by field/jet/intrinsic degree.
Dimensional power counting implies any derivative-bearing newly admitted
sector has field degree4 and exactly one jet. Verify rather than assume.
Its scaling current replaces the differentiated token by its unjetted field
in its actual Grassmann position with factor1/4. Save all four complete
currents and verify the exact divergence. Any zero-jet remainder must cancel
pointwise for a vanishing master functional in this no-explicit-coordinate
ring. Preserve a nonzero remainder as a failed prerequisite, never erase it.

Save full new density, projected reused part, complete combined currents,
full remainder and all port dispositions. Preserve omitted-last-branch,
half-current and actual monomial-Euler controls, disclosing blind cases.
The even Taylor derivation commutes with D on generators, hence throughout
the finite jet algebra; inherited qualified generator checks may be reused.
A proven exact pre-Taylor divergence licenses its projected T2/2 identity
without another huge loop/Taylor expansion. This supplies no quantum integral.

Freeze300s after imports/8GiB sampled private/350MiB launch commit floor/
64MiB complete packet/10MiB artifact. Full inputs/sources frozen before run,
complete captures/failed/unfinished runs preserved. No truncation, silent
resource expansion or automatic retry. Deny dependent predictions and
assembled consistency remainders; no coefficient fit or input normalization.

If the GF prerequisite matches, next audit physical-master restrictions,
hatted u support and the actual proper LEFT/Jacobian/inverse chain in BBC.
Do not transfer the aCC or BLambdaC scope by name alone. If it fails,
retain the actual classical insertion and revise the intended quantum
comparison; it is not automatically a theory obstruction. Common QAP/
measure/products/reality/background/equivalence/E5A5 remain open. Shared
action/chart/ring/software/AI author, not Lean/outside scientist/experiment.
Final validation/E4 once with seven custody NOTPASS/local commit separate.
