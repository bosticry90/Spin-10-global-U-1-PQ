# Physical applicability continuation V2

V1 timed out at its180s limit, exit124, with no physical artifact/result.
Full source/preparation/capture preserved, INCOMPLETE NOTPASS. Do not infer
any V1 physical identity or later Jacobian check completed. Its large fresh
Noether expansion and repeated Euler/control passes are unnecessary because
V788 already qualified the COMPLETE pre-Taylor physical Noether densities,
not merely a BLambdaC projection. Inspecting V1 also found its whole-owner
omission controls would be blind: each owner is separately a divergence.
That control issue was not the observed runtime failure and was not executed
to a verdict. No physical input or scientific acceptance requirement changes.

New180s bound (same as V1),8GiB sampled/350MiB floor/64MiB packet/10MiB
artifact. No automatic partial cache or expanded allowance. Reuse the
QUALIFIED V788 native/replay action/flow/Euler/Noether proof, not unfinished
V1 work. Verify every physical F0/F1 and E0/E1_B row in the current source
packets equals those qualified Noether operands. Authenticate complete
native/replay Noether arrays/currents and owning receipt. This is inherited
Noether proof with FRESH complete interface/scope checks, not fresh expanded
Noether multiplication. Preserve that distinction in results.

Inspect every full Noether word: field degrees2/3, exactly one ghost, no
source/antighost. The pre-Taylor divergence identity is independent of the
later BBC projection. The qualified even T/D commutation therefore carries
it to the new upper domain. Retain all owner dependencies and full profile
census. Potential support exclusions and unknown E1_x bypass remain as in
PHYSICAL_RECORD. All2032 probe physical flow zeros are freshly checked.

Replace the prospective blind owner controls by actual undifferentiated-
ghost monomial perturbations in EACH complete gauge/scalar Noether density.
Their explicit LEFT Euler_C must be nonzero; the old correct currents leave
that exact nonzero residual when the monomial is added. This tests the local
functional identity without dropping an entire invariant owner.

Freshly perform the originally required all3858 full-source diagonal own-jet
checks; all absent jets form an exact zero complement. Reuse the old full
Hessian/Euler/proper chain and CPS support theorem with the explicit BBC
u-independence reasoning in PHYSICAL_RECORD. No new Clifford calculation,
loop amplitude, UV/IR limit or unprobed-BBC zero. Only a finite first-u
proper/current relationship may follow. Keep V1 timeout NOTPASS, protected
boundaries, authority and all earlier failed routes unchanged.
