from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/BBC-master-applicability-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json'],'canonical_so10_aCC_operator_reduction_g1_v1':['master.py','master_original_g0.json.gz','master_original_g1.json.gz','master_probe0_g0.json.gz','master_v2_probe0_g1.json.gz','master_v2_probe1_g0.json.gz','master_v3_density.json.gz','master_v4_sector_2.json.gz','master_v4_sector_3.json.gz','master_v5_sector_4.json.gz','master_Taylor_commutation.json.gz','validation_receipt.json','PROOF.md'],'canonical_so10_coupled_lower_kinetic_log_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_log_source_restoring_preimage_g1_v1':['validation_receipt.json','PROOF.md']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V824.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']+['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='70e2254866ba996501cbffe1aec941e80ce870d1'
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['RECORD.md','master_scope.py','run_scope.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'master_scope.py')]);dump(O/'master_scope_capture.json',cap);dump(C/'master_scope_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
