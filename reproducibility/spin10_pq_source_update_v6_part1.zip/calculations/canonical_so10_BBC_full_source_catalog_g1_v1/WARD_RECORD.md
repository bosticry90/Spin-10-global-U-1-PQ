# New BBC right-root test, frozen before computation

Both completed full-source inventories agree byte-for-byte: original0,
H0,M2 typed paths, with no scalar return. Those two orientations both
connect the R_F1 R-side B to an original GF Lambda leg. Before expanding a
noncollinear tensor, the least expensive competent test is whether its
ACTUAL selected C_F/B_R/B_mean root annihilates that longitudinal free edge.
No aCC F1_BB Ward result is presumed to cover this different root.

Bind both new catalogs/results/captures, the initial preparation, actual
qualified V791 native/replay complete inverse packets, V825 proper proof
and current AGENTS. Source/Taylor derivatives precede target selection.
For the exact returning root class, sum ALL four R-side B components
times l_mu, keeping every color, mean B vector index, F quantum ghost,
all12 momentum powers and exact coefficient-ring monomials. Primary ring
addition is compared with literal Fraction accumulation of each serialized
coefficient atom. Retain the COMPLETE contractions, not only a zero flag.

Read actual G_F B/Lambda and Lambda/B entries for all45 colors, check they
are respectively minus/plus E*f*q_mu/q_squared with no cross-color entry.
Both root orientations must meet the required Lambda endpoint in the
measured paths. Keep both mean B copies conceptually commuting; no exchange
antisymmetry or color-zero assumption is used. Momentum l is the root R
leg, not the other root momentum or an arbitrary external momentum.

Controls: wrong contraction with k_mu; diagonal-only R/mean-B Lorentz
sum. Preserve full nonzero differences and explicitly disclose blind
controls. A NONZERO proper l contraction is a completed failed Ward shortcut,
NOT an anomaly or amplitude; proceed to full tensor evaluation later. If
zero, both complete paths vanish before other color/Grassmann/momentum
contractions, since the adjacent free B/Lambda edge has precisely that l
direction and a common even radial profile. This would establish the
first-u finite current zero by a new full-color operator proof. A continuum
zero may only follow for the grouped smooth finite-profile expression;
no independent divergent factor or inverse-heat tempered map is inferred.
No unprobed proper zero, common normalization or E5/A5 claim follows.

One worker120s after imports/8GiB sampled private/350MiB floor, same64MiB
packet/10MiB artifact. Freeze new source/copies/hash bindings before run;
full capture repo+D before judging. Failure/exhaustion remains incomplete,
not retry or truncation. Final validation will fresh replay this completed
test, compare complete artifacts/nonruntime results, then E4 once. Shared
action/source/ring/software/AI authorship; no independent scientist claim.
