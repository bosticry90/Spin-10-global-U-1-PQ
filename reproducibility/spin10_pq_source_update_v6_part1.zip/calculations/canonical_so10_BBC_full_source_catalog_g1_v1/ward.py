from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
import sympy as sy
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('BBC_right_root_exact_algebra',O/'catalog.py');b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b);J=b.m.J;A=b.m.m.A;load=b.load;read=b.read;digest=b.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def contract(rows,momentum,diagonal=False):
 out={};literal={};kept=[]
 for at,(word,mon,cc)in enumerate(rows):
  means=[(pos,n)for pos,(n,js)in enumerate(word)if 0<=n<180];ff=[(pos,n-1319)for pos,(n,js)in enumerate(word)if 1872<=n<1917];rr=[(pos,n-1962)for pos,(n,js)in enumerate(word)if 1962<=n<2142]
  assert len(means)==len(ff)==len(rr)==1 and len(word)==3 and all(not js for n,js in word)
  pos,n=rr[0];color,mu=divmod(n,4)
  if diagonal and means[0][1]%4!=mu:continue
  powers=list(mon);powers[momentum+mu]+=1;key=color,tuple((n,tuple(js))for j,(n,js)in enumerate(word)if j!=pos),tuple(powers);out[key]=out.get(key,J.ZERO)+A.decode_coeff(cc);kept.append(at)
  for atom,num,den in cc:
   lk=key,tuple(atom);literal[lk]=literal.get(lk,Fr())+Fr(num,den)
 out={k:c for k,c in out.items()if c};literal={k:c for k,c in literal.items()if c};expanded={(key,tuple(atom)):v for key,c in out.items()for atom,v in c.terms};assert expanded==literal,'RING_VERSUS_LITERAL_FRACTION_ROOT_CONTRACTION'
 return dict(input_indices=kept,complete_contraction=[[color,[[n,list(js)]for n,js in word],list(mon),A.encode_coeff(c)]for(color,word,mon),c in sorted(out.items())],all_literal_fraction_atoms_equal=True,nonzero_positions=len(out))
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'ward_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 cn=load(O/'native_BBC_catalog.json.gz');assert cn==load(O/'replay_BBC_catalog.json.gz');pn=load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1/native_inverse.json.gz');assert pn==load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1/replay_inverse.json.gz')
 cases=cn['cases'];assert[len(z['complete_cycles'])for z in cases]==[0,0,2]
 root=next(z for z in cn['roots']if z['state']=='F1'and z['family']=='preference');sig=['R_F1','marked',1,0,['CM','BM'],[1,0,0,0]];groups=[z for z in root['groups']if z['signature']==sig];assert len(groups)==1;selected=groups[0]['selected_indices'];rows=[root['selected'][i]for i in selected]
 contractions={name:contract(rows,mom,diag)for name,mom,diag in[('right_l',4,False),('wrong_right_k',0,False),('diagonal_right_l',4,True)]};zero=not contractions['right_l']['complete_contraction'];print('STAGE '+json.dumps({k:v['nonzero_positions']for k,v in contractions.items()},sort_keys=True),flush=True)
 q=sy.symbols('q0:4',real=True);E,f=sy.symbols('E_profile f_profile',positive=True);loc={str(s):s for s in[*q,E,f]};sq=sum(t*t for t in q);G={(i,j):sy.sympify(v,locals=loc)for i,j,v in pn['G_F']if(i<180 and 508<=j<553)or(508<=i<553 and j<180)};edges=[]
 for col in range(45):
  for mu in range(4):
   i=4*col+mu;j=508+col;left=G.get((i,j),sy.S.Zero);right=G.get((j,i),sy.S.Zero);assert sy.simplify(left+E*f*q[mu]/sq)==0 and sy.simplify(right-E*f*q[mu]/sq)==0;edges.append(dict(color=col,mu=mu,B_Lambda=str(left),Lambda_B=str(right),both_longitudinal_exact=True))
 assert len(G)==360 and len(edges)==180
 decisions=[]
 for path in cases[2]['complete_cycles']:
  r,ro,chain=path;rc=cn['classes'][r];assert[rc[k]for k in['owner','kind','g','u','quantum','external']]==sig
  i,orient=chain[0]if ro==0 else chain[-1];node=cn['classes'][i];endpoint=node['quantum'][orient if ro==0 else 1-orient];assert endpoint=='LM'and node['owner']=='GF_original';decisions.append(dict(path=path,R_side_B_neighbor_class=i,neighbor_endpoint=endpoint,common_profile_and_direction_exact=True,removed_by_complete_right_l_contraction=zero))
 art=save('BBC_right_root_tables.json.gz',dict(schema='ACTUAL_BBC_RIGHT_ROOT_CONTRACTION_TABLES_V1',source_root_selected_indices=selected,complete_returning_root=rows,contractions=contractions,all45_actual_mixed_free_inverse_edges=edges,both_path_decisions=decisions,scalar_cycles_absent_in_complete_catalog=True,first_u_current_zero_by_operator_proof=zero,unprobed_proper_zero_not_claimed=True))
 out=dict(schema='BBC_ACTUAL_RIGHT_ROOT_TEST_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',complete_native_ring_literal_fraction_contractions_equal=True,complete_returning_root_words=len(rows),all45_actual_longitudinal_inverse_edges_checked=True,both_path_interfaces_checked=True,actual_right_l_contraction_zero=zero,control_counts={k:v['nonzero_positions']for k,v in contractions.items()},scientific_disposition='FIRST_U_BBC_CURRENT_ZERO_BY_FULL_RIGHT_ROOT_OPERATOR_PROOF'if zero else'RIGHT_ROOT_SHORTCUT_FAILS_AMPLITUDE_STILL_REQUIRED',unprobed_proper_BBC_zero_NOT_CLAIMED=True,common_restoration_E5A5_NOT_CLAIMED=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);dump(O/'ward_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
