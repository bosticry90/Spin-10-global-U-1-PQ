from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/BBC-full-source-catalog-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(420,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','ward_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 artifacts=[];fresh=[];caps=[]
 for script,role,resname,capname,bound in[('catalog.py','native','native_result.json','native_capture.json',180),('catalog.py','replay','replay_result.json','replay_capture.json',180),('ward.py',None,'ward_result.json','ward_capture.json',120)]:
  cap=read(O/capname);res=read(O/resname);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['execution_state']=='COMPLETED'and res['elapsed_after_imports']<bound;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);caps.append(cap)
  sp=importlib.util.spec_from_file_location('fresh_BBC_'+resname.replace('.','_'),O/script);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
  if role:m.ROLE=role
  def compare_save(name,z):
   name=role+'_'+name+'.json.gz'if role else name;blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),('FRESH_ARTIFACT_DIFFERS',name);artifacts.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
  def compare_dump(path,z):
   assert path==O/resname;assert{k:v for k,v in res.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'},resname;assert z['elapsed_after_imports']<bound;fresh.append(dict(result=resname,seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
  m.save=compare_save;m.dump=compare_dump;m.main();del m;gc.collect()
 assert len(fresh)==len(artifacts)==len(set(artifacts))==3
 cn=load(O/'native_BBC_catalog.json.gz');assert cn==load(O/'replay_BBC_catalog.json.gz')and len(cn['roots'])==12 and len(cn['ordinary'])==8 and len(cn['classes'])==75 and[len(z['complete_cycles'])for z in cn['cases']]==[0,0,2]
 for case in cn['cases']:assert not case['scalar_reduced_cycles']and case['scalar_all_length_nonreturn_by_erasure']
 for row in cn['roots']:assert sorted(row['kept_raw_indices']+[i for z in row['rejected']for i in z['raw_indices']])==list(range(row['raw_root_terms']))
 for row in cn['ordinary']:assert sorted(row['kept_raw_indices']+[i for z in row['rejected']for i in z['raw_indices']])==list(range(row['raw_word_count']))
 assert all(sum(z['external'])+z['g']+z['u']>=1 for z in cn['classes'])
 w=read(O/'ward_result.json');wt=load(O/w['artifact']['file']);assert w['actual_right_l_contraction_zero']and w['complete_returning_root_words']==22416 and w['control_counts']==dict(right_l=0,wrong_right_k=22416,diagonal_right_l=11208);assert len(wt['all45_actual_mixed_free_inverse_edges'])==180 and len(wt['both_path_decisions'])==2 and all(z['removed_by_complete_right_l_contraction']for z in wt['both_path_decisions']);assert not wt['contractions']['right_l']['complete_contraction']and all(z['all_literal_fraction_atoms_equal']for z in wt['contractions'].values())
 prior=read(O.parent/'canonical_so10_BBC_master_applicability_g1_v1/validation_receipt.json');assert prior['evidence_validation']=='PASS_BOUNDED_BBC_MASTER_AND_FINITE_PROPER_CURRENT_APPLICABILITY'and prior['selected_finite_BBC_proper_relation']=='QGamma1=-C_Q=C_R'and prior['unprobed_BBC_zero_NOT_CLAIMED'];assert wt['unprobed_proper_zero_not_claimed']
 print('STAGE fresh3results_3artifacts_complete_source_inventory_and_actual_root_zero_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();pp=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=pp.returncode,seconds=time.perf_counter()-et,stdout=pp.stdout,stderr=pp.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert pp.returncode==0
  
 events=[json.loads(x)for x in pp.stdout.splitlines()if x.strip()];exits=[e['exit_code']for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(e for e in events if e['event']=='step_finished'and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V826.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='BBC_FULL_SOURCE_AND_RIGHT_ROOT_ZERO_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_FIRST_U_BBC_PROPER_RESPONSE_ZERO',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,fresh_replays=fresh,complete_artifacts_freshly_recomputed=artifacts,all643_fields_all45_colors_precede_return_support=True,all_raw_root_and_ordinary_index_dispositions_verified=True,catalog_counts_original_H_M=[0,0,2],native_DFS_replay_multiset_complete_artifacts_equal=True,actual22416_word_C_F_B_R_right_l_zero=True,wrong_k_nonzero_positions=22416,diagonal_only_nonzero_positions=11208,all45_actual_mixed_inverse_edges_checked=True,first_u_finite_proper_BBC_response='ZERO_FROM_ACTUAL_CURRENT_PLUS_V825_PREMISES',grouped_zero_reference='WRITTEN_EXACT_ZERO_FINITE_PROFILE_SCOPE_ARGUMENT_NOT_NEW_NONZERO_MOMENTUM_INTEGRAL',unprobed_proper_BBC_zero_NOT_CLAIMED=True,V823_V824_counterterm_spillover_not_quantum_input_and_failures_preserved=True,no_full_counterterm_cohomology_basis_claim_no_HB1_C5_activation=True,common_restoration_E5_A5_viability_not_claimed=True,shared_action_software_AI_author_not_external_independence=True,largest_primary_sampled_private_bytes=max(x['private_bytes']for cap in caps for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
