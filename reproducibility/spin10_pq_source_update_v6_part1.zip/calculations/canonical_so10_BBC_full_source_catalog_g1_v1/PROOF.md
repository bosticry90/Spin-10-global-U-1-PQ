# Actual first-probe BBC response: complete inventory and a new operator zero

BBC-Q-1 is the complete original/H/M g1 typed returning inventory from
full source-derived inputs in the original Euclidean A0/intrinsic0/1
constant-mark prescription. BBC-Q-2 removes its two M candidates by an
ACTUAL C_F/B_R right-root contraction, not the old aCC B_F/B_R Ward claim.
Together with V825 this gives the selected FIRST-u proper BBC response
QGamma1_BBC=C_R,BBC=0. It does not give an unprobed proper zero, common
restoration, an accepted finite normalization, E5/A5 or physical viability.

## Complete envelope and independently ordered enumeration

Use all12 full raw roots and all8 ordinary Taylor halves, each constructed
from the action with source/Euler operations before source zero. The old
selected catalogs and constructed correction residuals are denied inputs.
All643 bosonic/ghost coordinates and45 colors precede H/M/type collapse;
hatted fermions remain covered separately by the V825 stable-ideal proof.
Each raw word is either retained or rejected with its original exact index.
Quantum F/R copies remain distinct. The mean envelope is B<=2,C<=1 and
no other means/sources; it is a necessary upper support, not an amplitude.

The whole free F0 paired-exchange identity is checked on its FULL raw
polynomial before inverse insertions. Each target's reference diagonal is
checked separately. All other F1/Fu0/Fu1 roots remain in the class inventory,
including11872 selected Fu1_M preference words. Thus no earlier selected
Fu1 zero was assumed. Physical gauge60264 and scalar50240 selected ordinary
words remain before support. There are75 retained type classes. Every
nonreference class has positive external-count+g+u cost, bounding the
overall B2C,g1,u1 target by5 vertices, including the root. Unprobed g1 has
the smaller cost bound automatically. Both endpoint orientations are kept.

Native oriented DFS and replay multiset/order/orientation enumeration
read their respective FULL native/replay input packets, not each other's
answers. Their complete4,595,986-byte compressed mathematical catalogs are
byte-identical. Both use inherited type/edge definitions; this is different
enumeration order with shared definitions, not independent physical input.
The complete original and H catalogs are empty. M contains exactly2 typed
paths, the two reversed orientations of the following owner sequence:

    R_F1: (C_M,B_M), one B mean, g1
    GF_original: (Lambda_M,a_M), one C mean, g0
    GF_probe_M: (C_M,a_M), one B mean, g0/u1.

All physical scalar/gauge and other nonminimal roots were tested, not
discarded first. No scalar reduced path returns. Same-scalar zero-cost
reference insertions cannot create one: their erasure keeps endpoints,
means and grades. Grade-carrying vertices are already enumerated and are
not erased. Physical masses/potentials were not reset or adopted.

Wrong H/M edges give8 M paths, wrong LL edges4, versus actual2. Omitting
zero-mean inverse-u vertices leaves2 and is blind here. All three controls
are also blind in the empty original/H cases. Complete control paths remain
saved. Typed paths are not independent amplitudes or nonzero color tensors.

## Full actual C_F/B_R contraction

The measured returning root class is fixed by owner/g/u/types/means, not
selected from a desired remainder. Its complete22416 raw words include all
external B colors/vector indices and internal M ghost/vector colors,
all four R-side vector components and exact momentum/coefficient atoms.
There is one F quantum ghost, one R quantum vector and one B mean per word.
No root mean/quantum jets are left outside the12 momentum powers. Let l
denote the R-side vector momentum. The full coefficient polynomial obeys

    sum_mu l_mu R_(C_F,B_R_mu;B_mean)(k,l)=0

for EVERY retained color/mean/other-momentum coefficient. Primary coefficient
ring accumulation and literal Fraction accumulation of every serialized
coefficient atom agree exactly, including every zero. No equation of motion,
external momentum alignment, color fit or Bose antisymmetry is used.
The two B means commute; no equal-color term was discarded by statistics.

Controls preserve complete differences: replacing l_mu by k_mu leaves22416
nonzero positions; retaining only equal R/mean-B vector indices leaves11208.
These show why the correct momentum and all four vector components matter.
Neither nonzero control is a physical breaking.

The actual qualified V791 G_F matrix is read in both native/replay forms.
For all45 colors and all4 vector components it has precisely

    G_(B_mu,Lambda)=-E(q)f(q)q_mu/q_squared,
    G_(Lambda,B_mu)=+E(q)f(q)q_mu/q_squared,

with no cross-color mixed edge. Both returning path orientations meet this
Lambda endpoint on the R-side B leg. The edge therefore multiplies EXACTLY
the tested l_mu contraction, up to a common scalar profile and orientation
sign. It is zero before the other vertices, color sums, Grassmann loop
signs, momentum integrals, external Bose exchange or Taylor factors could
affect it. No unknown coefficient was selected to make it vanish.

This is a new root proof for the new BBC target. Reusing aCC's F1_BB
right-Ward result without these22416 terms and mixed-edge interfaces would
not have sufficed. All Fu roots/ordinary owners excluded by COMPLETE
returning support remain preserved in the full inventory.

## Proper interpretation and the grouped zero reference

V825 supplies QGamma1=-C_Q=C_R for first-u BBC, with complete GF/physical
master support, all own-jet columns zero and the scoped hatted insertion.
The empty H inventory and removed M paths thus give FIRST-u proper BBC=0.
The original raw inventory is empty as well, but V825 did NOT establish
the unprobed proper/hatted premise; no unprobed proper zero follows here.

The zero holds for each common positive finite heat/IR profile, arbitrary
external momenta and all vector/color polarizations. On the R-side edge,
the whole root factor (F_l^-1-1) combines with G_F,l to1-F_l; the split
heat/IR representation has the same pairing. Its common scalar factor
does not depend on the summed R vector component. The retained f_delta
regularizes the mixed q/q_squared edge at the origin. After pairing, the
other two finite-profile edges retain UV heat decay. Thus this is an
identically zero grouped finite-profile kernel, with no residual delta
function or independent divergent factor assigned a value. Its zero
distribution has zero ordered UV-first/IR-second limit in S'. This is a
written scope argument for this EXACT ZERO, not a new nonzero momentum
integration or a transfer of V819's general aCC limit theorem. No separate
inverse-heat/IR operator on arbitrary Schwartz fields is claimed.

This result supplies the actual missing first-u BBC input raised by
V823/V824. Their constructed nonzero BBC counterterm spillover is distinct
and stays nonzero; both previously excluded fixed-companion normalization
routes remain excluded. The new zero cannot be changed to rescue them.
The W2 type envelope is still not a qualified full finite-probe source/
cohomology basis. No HB1/C5 activation or foundational adoption occurs.

## Significance, limits and next competent work

The useful result is a full action-derived quantum input determined by
support and a sensitive exact identity instead of an unnecessary large
tensor expansion. It strengthens the need to solve the correlated source
normalization problem: the previous candidate spillover cannot be called
an unmeasured quantum BBC companion anymore in this first-u domain.
Other unprobed/source-dependent quantum inputs and normalization freedoms
must be accounted for before a global restoration/no-go verdict.

Next reconcile the actual zero with the complete measured source-family
normalization equations, identify remaining unmeasured required patterns
from full source/g/u/dimension support, and distinguish missing quantum
inputs from unqualified counterterm-basis claims. Do not invent finite
coefficients, repeat the already excluded kinetic-only routes, or infer
that six LambdaCC parents exhaust the full Slavnov functional. Blocked
HB1/C5 and human-paused work remain boundaries. Each new test is frozen.

Shared action/ring/normalization/edge definitions/source helpers/AI author
and inherited physical/hatted proofs limit independence. No Lean, outside
scientist or experiment is claimed. Track B demonstrates efficient exact
operator reduction and exposes blind controls honestly. Final validation,
execution completion and scientific acceptance stay separate. State113/
34of39 and seven unresolved historical custody references stay unchanged.
