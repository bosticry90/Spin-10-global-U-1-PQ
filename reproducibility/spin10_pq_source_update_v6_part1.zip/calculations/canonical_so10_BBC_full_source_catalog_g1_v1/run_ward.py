from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/BBC-full-source-catalog-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
for role in['native','replay']:
 z=json.loads((O/(role+'_capture.json')).read_bytes());assert z['exit_code']==0 and z['calculation_completed']and z['post_run_observations_qualified']
assert(O/'native_BBC_catalog.json.gz').read_bytes()==(O/'replay_BBC_catalog.json.gz').read_bytes()
for n in['WARD_RECORD.md','ward.py','run_ward.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
names=['calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/'+n for n in['native_inverse.json.gz','replay_inverse.json.gz']]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
bindings={**json.loads((O/'preparation.json').read_bytes())['sha256'],**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}};dump(O/'ward_preparation.json',dict(sha256=bindings,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'ward.py')]);dump(O/'ward_capture.json',cap);dump(C/'ward_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
