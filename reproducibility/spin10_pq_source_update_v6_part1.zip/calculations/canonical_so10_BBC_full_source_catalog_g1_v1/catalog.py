from pathlib import Path
from collections import Counter
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('BBC_full_raw_catalog_helpers',O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/catalog.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
ROLE=sys.argv[1]if __name__=='__main__'else'native';read=m.read;load=m.load;digest=m.digest

def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')

def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/(ROLE+'_'+name+'.json.gz')).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))

def mean(n):return 0 if 0<=n<180 else 1 if 553<=n<598 else None

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();assert ROLE in['native','replay']
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(s in p for s in['aCC_reference_integrability_prediction','log_source_restoring_preimage','coupled_lower_kinetic_log','native_aCC_catalog.json','replay_aCC_catalog.json','native_JBCC_catalog.json','replay_JBCC_catalog.json','native_JLambdaCC_catalog.json','replay_JLambdaCC_catalog.json']),'OLD_SELECTED_CATALOG_OR_DESIRED_REMAINDER_DENIED'
 sys.addaudithook(guard);m.mean=mean;m.save=save
 packet=load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1'/(ROLE+'_inputs.json.gz'));assert len(packet['roots'])==12 and len(packet['ordinary'])==8
 target=(2,1,0,0);roots=[];ordinary=[];sigs=set()
 for row in packet['roots']:
  z,s=m.project_root(row,target);roots.append(z);sigs.update(s)
 for row in packet['ordinary']:
  z,s=m.project_ordinary(row,target);ordinary.append(z);sigs.update(s)
 classes=[dict(id=i,owner=a,kind=b,g=g,u=u,quantum=list(q),external=list(e))for i,(a,b,g,u,q,e)in enumerate(sorted(sigs))]
 assert all(sum(z['external'])+z['g']+z['u']>=1 for z in classes),'ZERO_COST_NONREFERENCE_VERTEX'
 for raw,z in zip(packet['roots'],roots):assert sorted(z['kept_raw_indices']+[i for row in z['rejected']for i in row['raw_indices']])==list(range(len(raw['raw_root'])))
 for raw,z in zip(packet['ordinary'],ordinary):assert sorted(z['kept_raw_indices']+[i for row in z['rejected']for i in row['raw_indices']])==list(range(len(raw['quadratic_Taylor_half'])))
 cases=[];summary=[]
 for label,u,probe in[('original',0,None),('probe0',1,0),('probe1',1,1)]:
  actual=m.paths(classes,target,u,probe,ROLE);wrong={n:m.paths(classes,target,u,probe,ROLE,mode=mode)for n,mode in[('wrong_HM','mix_HM'),('wrong_LL','LL')]};omitted=m.paths(classes,target,u,probe,ROLE,omit='inverse_U')
  scalar=[z for z in actual if any(q.startswith('x')for i in[z[0]]+[j for j,o in z[2]]for q in classes[i]['quantum'])];root_counts=dict(sorted(Counter(classes[r]['owner']for r,ro,p in actual).items()));active=sorted({q for r,ro,p in actual for i in[r]+[j for j,o in p]for q in classes[i]['quantum']});used=sorted({i for r,ro,p in actual for i in[r]+[j for j,o in p]})
  cases.append(dict(case=label,u=u,probe=probe,complete_cycles=actual,wrong=wrong,omit_inverse_U=omitted,root_counts=root_counts,active_quantum_types=active,used_class_ids=used,scalar_reduced_cycles=scalar,scalar_all_length_nonreturn_by_erasure=not scalar,max_vertices=max((len(p)+1 for r,ro,p in actual),default=0)))
  row=dict(case=label,cycles=len(actual),root_counts=root_counts,active_quantum_types=active,scalar_reduced_cycles=len(scalar),max_vertices=cases[-1]['max_vertices'],wrong_counts={k:len(v)for k,v in wrong.items()},omit_inverse_U_cycles=len(omitted));summary.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 # Route is intentionally absent from the mathematical artifact to permit exact comparison.
 art=save('BBC_catalog',dict(schema='FULL_RAW_BBC_SOURCE_REGULATOR_CATALOG_V1',target=list(target),external_means=['B','C','unused','unused'],roots=roots,ordinary=ordinary,classes=classes,cases=cases,total_vertex_bound=5,all643_fields_before_type_collapse=True,all45_colors_before_type_collapse=True,no_color_amplitude_Grassmann_loop_sign_or_proper_zero_claim=True))
 out=dict(schema='BBC_FULL_SOURCE_CATALOG_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',route=ROLE,artifact=art,summary=summary,all_raw_root_and_ordinary_indices_disposed=True,global_F0_exchange_and_new_reference_diagonals_checked=True,all643_fields_before_support=True,no_aCC_Fu1_or_internal_M_exclusion_transferred=True,scalar_resummation_analysis_required=any(q['scalar_reduced_cycles']for q in summary),old_selected_catalog_and_desired_remainder_denied=True,no_BBC_amplitude_UVIR_common_restoration_E5A5_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/(ROLE+'_result.json'),out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
