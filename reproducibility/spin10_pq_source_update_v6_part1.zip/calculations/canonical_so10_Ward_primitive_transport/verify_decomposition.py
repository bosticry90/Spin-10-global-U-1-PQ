from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
import ast,gzip,json,os,sys,threading,time
import numpy as np
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'decomposition_review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
ONE=J.constant(1);I=J.I;Z=J.ZERO;prime=1009
roots=[next(x for x in range(prime) if x*x%prime==v%prime) for v in [2,3,5,7,-1]];ii=roots[4]
eye=np.eye(45,dtype=np.int64);zero=np.zeros((45,45),dtype=np.int64)
tree=ast.parse((O/'verify_v2.py').read_bytes());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['evaluator','arr','tensor','dot','mass','tr2','dc','old','mat','sc']]
exec(compile(ast.Module(body=selected,type_ignores=[]),'qualified-exact-and-modular-helpers','exec'))
width=[J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))]) for i in range(45)]
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[mat(z) for z in cov['symmetric_basis']+cov['skew_basis']]
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz');gf={i:J.decode(p) for i,p in fj['GF_gradient']}
ML={};L={}
for a in range(45):
    M={}
    for w,c in gf[508+a].items():
        if len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643 and all(not js for n,js in w):
            co=J.Coeff([((0,x,e,m),q) for (g,x,e,m),q in c.terms if g==0])
            if co:M[w[1][0]-598,w[0][0]-553]=-co
    ML[a]=M
    if a>=12:L[a]={ij:J.times(-I,c) for ij,c in M.items()}
# Derive the full explicit-u map from source stationarity and the actual
# color Gram, rather than a previous kernel value or coefficient fit.
Gram={}
for s in range(12,45):
    for r in range(45):
        co=J.times(I,sum((J.times(c,ML[r].get((j,i),Z)) for (i,j),c in L[s].items()),Z))
        if co:Gram[s,r]=co
def mm(A,B):
    byrow=defaultdict(list);out={}
    for (i,j),c in B.items():byrow[i].append((j,c))
    for (i,k),c in A.items():
        for j,d in byrow[k]:out[i,j]=out.get((i,j),Z)+J.times(c,d)
    return {k:c for k,c in out.items() if c}
explicit=load(O/'explicit_tables_v3.json.gz');lookup={}
for fam in ['A','B']:
    for n,V in enumerate(basis):
        M={}
        if fam=='A':
            M=dict(V)
            for (i,j),c in V.items():M[j,i]=M.get((j,i),Z)+c
        GM=mm(Gram,M);GB=mm(Gram,V if fam=='B' else {})
        for s in range(12,45):
            for r in range(45):
                a,b=GM.get((s,r),Z),GB.get((s,r),Z)
                lookup[fam,n,s,r]={k:c for k,c in [(0,b),(1,a-2*b),(2,b-2*a),(3,a)] if c}
for row in explicit['complete_color_table']:
    assert {k:dc(c) for k,c in row['heat22']}==lookup[row['family'],row['tensor'],row['epsilon'],row['Ja']]
assert len(explicit['complete_color_table'])==41580
print('STAGE exact Gram derivation of all41580 independent explicit-u coefficients',flush=True)
qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
Uops=[]
for pr in [0,1]:
    U=qt['probes'][pr];Uops.append([{int(i):{(a,b):old(c) for a,b,c in rows} for i,rows in U[label].items()} for label in ['M_y','M_Lambda','N_direct']])
decomp=load(O/'decomposition_tables_v2.json.gz');native=load(O/'kernel_tables.json.gz');oldcases=defaultdict(list);cases=defaultdict(list)
for r in native['complete_color_table']:oldcases[r['probe'],r['family'],r['tensor']].append(r)
for r in decomp['complete_color_table']:cases[r['probe'],r['family'],r['tensor']].append(r)
def epoly(rows,E,f):return sum(pow(E,k,prime)*f(dc(c)) for k,c in rows)%prime
def mm_mod(A,B):return dot(A,B)
def eval_group(Hb,Fb,Et,bank,K,reg,X0,Hu,Fu,G,Ub,Lt):
    Xb=-dot(G,(dot(Hb[0],X0)+Fb[0])%prime)%prime
    Xu=-dot(G,(dot(Hu,X0)+Fu)%prime)%prime
    Xbu=(dot(dot(dot(G,Hu),G),(dot(Hb[0],X0)+Fb[0])%prime)+dot(dot(dot(G,Hb[0]),G),(dot(Hu,X0)+Fu)%prime)-dot(G,(dot(Hb[1],X0)+Fb[1])%prime))%prime
    original=lambda X:np.einsum('ir,ijk->rjk',X[45:],Ml)%prime
    v00=original(X0);v00[45:]=(v00[45:]+Lt)%prime
    vu=(original(Xu)+mass(Ub,X0))%prime;vu[:45]=(vu[:45]+Ub[2])%prime
    vb=(original(Xb)+mass(bank[0],X0))%prime;vb[:45]=(vb[:45]+bank[0][2])%prime
    vbu=(original(Xbu)+mass(Ub,Xb)+mass(bank[0],Xu)+mass(bank[1],X0))%prime;vbu[:45]=(vbu[:45]+bank[1][2])%prime
    t0,tu,tb,tbu=[a[45:] for a in [v00,vu,vb,vbu]];j0,ju,jb,jbu=[a[:45] for a in [v00,vu,vb,vbu]]
    p22=-(tr2(t0,jbu)+tr2(tu,jb)+tr2(tb,ju)+tr2(tbu,j0))%prime
    p42=(tr2(np.matmul(t0,K[0])%prime,ju)+tr2(np.matmul(tu,K[0])%prime,j0)+tr2(np.matmul(t0,K[1])%prime,j0))%prime
    p24=(tr2(t0,np.matmul(ju,K[0])%prime)+tr2(tu,np.matmul(j0,K[0])%prime)+tr2(t0,np.matmul(j0,K[1])%prime))%prime
    if reg:p22=(p22+p42+p24)%prime;p42=-p42%prime;p24=-p24%prime
    return [p22,p42,p24]
checks=0;source_nonzero=0;regulator_nonzero=0
for xi,eta,E in [(2,3,2*pow(7,-1,prime)%prime),(5,7,3*pow(11,-1,prime)%prime)]:
    f=evaluator(xi,eta);Om=np.diag([f(w) for w in width]);Ml=tensor(ML,f);Lt=np.stack([arr(L[i],f) for i in range(12,45)])
    H0=np.block([[zero,ii*eye],[ii*eye,Om]])%prime
    G=E*np.block([[Om,-ii*eye],[-ii*eye,zero]])%prime
    F0=np.zeros((90,78),dtype=np.int64);F0[45:,:45]=-ii*eye;F0[:45,45:]=eye[:,12:];F0[45:,45:]=-ii*dot(Om,eye[:,12:])*pow(2,-1,prime);F0%=prime
    X0=-dot(G,F0)%prime
    for key,rows in cases.items():
        pr,fam,tn=key;V=arr(basis[tn],f);A=V if fam=='A' else zero;B=V if fam=='B' else zero
        Pi=np.diag([int(i<12 if pr==0 else i>=12) for i in range(45)]).astype(np.int64);S=dot(Om,Pi);T1=dot(Om,S)*pow(2,-1,prime)%prime
        Hu=np.block([[-2*Pi,ii*S],[ii*S,dot(Om,S)*pow(2,-1,prime)]])%prime
        Fu=np.zeros((90,78),dtype=np.int64);Fu[:45,:45]=2*Pi;Fu[45:,:45]=-ii*S;Fu%=prime
        Ub=[tensor(b,f) for b in Uops[pr]]
        # WHOLE source: source-JB kinetic cross and source-Ja products.
        hp0=np.block([[zero,-ii*dot(A.T,Om)],[-ii*dot(Om,A),zero]])%prime
        hp1=np.block([[2*(dot(A.T,S)+dot(S,A)),-3*ii*dot(A.T,dot(Om,S))*pow(2,-1,prime)],[-3*ii*dot(dot(Om,S),A)*pow(2,-1,prime),zero]])%prime
        fp0=np.zeros((90,78),dtype=np.int64);fp1=fp0.copy()
        fp0[45:,:45]=-ii*dot(Om,B);fp0[:45,45:]=-dot(A.T,dot(Om,eye[:,12:]))
        fp1[:45,:45]=2*(dot(S,B)-dot(A.T,S));fp1[45:,:45]=-3*ii*dot(dot(Om,S),B)*pow(2,-1,prime);fp1[:45,45:]=-dot(A.T,dot(T1,eye[:,12:]))
        fp0%=prime;fp1%=prime
        empty=np.zeros((45,45,45),dtype=np.int64)
        py=np.einsum('ir,ijk->rjk',dot(Om,A),Ub[2])%prime;pj=np.einsum('ir,ijk->rjk',dot(Om,B),Ub[2])%prime
        P=eval_group([hp0,hp1],[fp0,fp1],None,[[empty,empty,empty],[py,empty,pj]],[-dot(Om,A)%prime,-dot(T1,A)%prime],False,X0,Hu,Fu,G,Ub,Lt)
        # REGULATOR: affine matrix variation of the actual free quadratic form.
        hrs=[];frs=[]
        h=(pow(E,-1,prime)-1)%prime
        for Rg in [eye,S]:
            Ffield=np.block([[zero,zero],[ii*dot(Rg,A),zero]])%prime
            LJ=np.vstack([zero,ii*dot(Rg,B)])%prime
            hrs.append(h*(dot(Ffield.T,H0)+dot(H0,Ffield))%prime)
            source=np.zeros((90,78),dtype=np.int64);source[:,:45]=h*dot(H0,LJ)%prime;frs.append(source)
        RR=eval_group(hrs,frs,None,[[empty,empty,empty],[empty,empty,empty]],[-dot(Om,B)%prime,-dot(T1,B)%prime],True,X0,Hu,Fu,G,Ub,Lt)
        oldrows=oldcases[key]
        for row,oldrow in zip(rows,oldrows):
            assert (row['epsilon'],row['Ja'])==(oldrow['epsilon'],oldrow['Ja']);s,r=row['epsilon']-12,row['Ja']
            actualP=[epoly(ch,E,f) for ch in row['whole_source']];actualR=[epoly(ch,E,f) for ch in row['regulator']]
            assert actualP==[int(a[s,r]) for a in P] and actualR==[int(a[s,r]) for a in RR],('INDEPENDENT_SOURCE_REGULATOR_MATRIX_MISMATCH',key,s,r)
            C=[epoly(oldrow[ch],E,f) for ch in ['heat22','heat42','heat24']]
            assert all((a+b-c)%prime==0 for a,b,c in zip(C,actualP,actualR))
            checks+=1;source_nonzero+=any(actualP);regulator_nonzero+=any(actualR)
    print('STAGE independent regulator/source block comparison '+str(xi)+' '+str(eta),flush=True)
assert checks==166320 and source_nonzero>0 and regulator_nonzero>0
meta=read(O/'decomposition_result_v2.json');assert meta['selected_finite_heat_identity_qualified'] and meta['ordered_asymmetric_residual_positions_retained']==0
assert all(not any(r['ordered_residual']) and not r['combined_asymmetric_residual'] for r in decomp['complete_color_table'])
out={'schema':'WPT_SEPARATE_WHOLE_SOURCE_REGULATOR_REVIEW','evidence_validation':'PASS_SELECTED_FINITE_HEAT_AFFINE_TRANSPORT_IDENTITY',
 'exact_explicit_u_color_coefficients_checked':41580,'independent_block_source_regulator_color_checks':checks,
 'source_nonzero_modular_diagnostics':source_nonzero,'regulator_nonzero_modular_diagnostics':regulator_nonzero,
 'actual_R_derived_from_F_transpose_H0_plus_H0_F':True,'whole_source_not_factorized':True,
 'all83160_exact_ordered_residuals_zero':True,'fixed_primitive_commutator_companion_retained':True,
 'ordinary_j_zero_in_selected_domain':True,'Jacobian_source_derivatives_zero_not_vacuum_density':True,
 'reference_common_FP_IR_prescription_scope_only':True,'physical_measure_general_Ward_QAP_E5_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'decomposition_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
