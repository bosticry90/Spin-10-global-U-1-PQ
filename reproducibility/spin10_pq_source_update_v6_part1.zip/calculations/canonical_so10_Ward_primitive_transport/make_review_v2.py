from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'verify.py').read_text().replace("O/'review_preparation.json'","O/'review_preparation_v2.json'").replace("O/'explicit_tables.json.gz'","O/'explicit_tables_v3.json.gz'").replace("O/'validation_receipt.json'","O/'validation_receipt_v2.json'")
with(O/'verify_v2.py').open('xb') as f:f.write(src.encode())
src=(O/'run_review.py').read_text()
src=src.replace('    bindings={}','''    prerequisite=read(O/'explicit_capture_v3.json')
    assert prerequisite['exit_code']==0 and prerequisite['execution_state']=='COMPLETED' and prerequisite['calculation_completed'] and prerequisite['post_run_observations_qualified']
    complete=read(O/'explicit_result_v3.json')
    assert complete['complete_color_positions']==41580 and complete['table_sha256']==digest(O/'explicit_tables_v3.json.gz')
    bindings={}''')
src=src.replace("['REVIEW_RECORD.md','verify.py','run_review.py']","['REVIEW_V2_RECORD.md','make_review_v2.py','verify_v2.py','run_review_v2.py']")
src=src.replace("dump(O/'review_preparation.json'","dump(O/'review_preparation_v2.json'").replace("O/'verify.py'","O/'verify_v2.py'")
src=src.replace("O/'review_capture.json'","O/'review_capture_v2.json'").replace("C/'review_full_capture.json'","C/'review_full_capture_v2.json'").replace("O/'review_controller_failure.json'","O/'review_controller_failure_v2.json'")
with(O/'run_review_v2.py').open('xb') as f:f.write(src.encode())
