from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
sp=importlib.util.spec_from_file_location('raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
ONE=J.constant(1);I=J.I;gg=J.Coeff([((1,0,0,0),F(1))]);sc=lambda P,c:J.clean({w:J.times(z,c) for w,z in P.items()})
def plus(*Ps):
    z={}
    for P in Ps:J.add(z,P)
    return J.clean(z)
def grade(P,g,strip=False):return J.clean({w:J.Coeff([((0 if strip else k[0],k[1],k[2],k[3]),z) for k,z in c.terms if k[0]==g]) for w,c in P.items()})
def oddact(P,Q):
    out={};cache={}
    for word,c in P.items():
        prefix=0
        for at,(n,js) in enumerate(word):
            if Q.get(n):
                if (n,js) not in cache:cache[n,js]=J.Ds(Q[n],js)
                for w,z in cache[n,js].items():J.put(out,word[:at]+w+word[at+1:],J.times(c,z)*(-1)**prefix)
            prefix+=J.parity(n)
    return J.clean(out)
def decode_coeff(cells):return J.Coeff([(tuple(k),F(n,d)) for k,n,d in cells])
def matrix(rows):return {(i,j):decode_coeff(c) for i,j,c in rows}
def elem(n,js=()):return {((n,js),):ONE}
def to_raw(P):
    z={}
    for w,c in P.items():
        for (g,x,e,m),q in c.terms:u.put(z,(g,w),(((x,e,m),q),))
    return z
def from_raw(P):
    z={}
    for (g,w),c in P.items():J.put(z,w,J.Coeff([((g,x,e,m),q) for (x,e,m),q in c]))
    return J.clean(z)
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');Q={n:grade(J.decode(p),0) for n,p in fj['operation']}
probes=[]
for pr in [0,1]:
    U=grade(J.decode(fj['probes'][pr]['qG']),0);grad=J.euler(U,set(range(508,553))|set(range(598,643))|set(range(643,823))|set(range(1241,1286)))
    op={}
    for a in range(45):
        for mu in range(4):op[4*a+mu]=grad.get(643+4*a+mu,{})
        op[598+a]=sc(grad.get(1241+a,{}),-ONE);op[1151+a]=grad.get(508+a,{})
        op[1241+a]=sc(grad.get(598+a,{}),-ONE)
    probes.append(op)
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[matrix(z) for z in cov['symmetric_basis']+cov['skew_basis']]
assert len(basis)==14
ct=load(R/'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');AA=u.Algebra(ct['geometry']['names'],ct['geometry']['parities']);EPS=1286
D={int(n):{key:c for key,c in v.unpack(AA,p).items() if key[0]==0} for n,p in ct['D'].items()}
width=[J.Coeff([((0,0,1,0),F(1))]) if a<12 else J.Coeff([((0,1,0,0),F(1))]) for a in range(45)]
y=[{((4*a+mu,(mu,)),):ONE for mu in range(4)} for a in range(45)]
def extract_C(P):
    # Restriction commutes with Ja/epsilon differentiation only AFTER the
    # full Q action has been formed. Retain spectator source ports separately.
    keep={};spect={};shapes=Counter()
    for w,c in P.items():
        if any(n>=643 and not 1241<=n<1286 for n,js in w):spect[w]=c;continue
        gh=[(n,js) for n,js in w if 553<=n<643];other=[(n,js) for n,js in w if not 553<=n<643]
        if not gh:assert len(w)==2 and all(n<180 or 508<=n<553 or 1241<=n<1286 for n,js in w),'UNEXPECTED_C_BOSON_PORT'
        elif len(gh)==2:
            assert sum(n<598 for n,js in gh)==1,'ANOMALOUS_C_GHOST_BLOCK'
            assert len(other)<=1,'NONLINEAR_C_GHOST_BACKGROUND'
        elif len(gh)>=4:shapes['quartic_ghost_zero_Hessian_at_zero_ghost_mean']+=1;continue
        else:raise AssertionError(('UNEXPECTED_C_GHOST_DEGREE',w))
        keep[w]=c
    return J.clean(keep),J.clean(spect),dict(shapes)
rows=[];qW_remainders=[]
for pr in [0,1]:
    selected=[a<12 if pr==0 else a>=12 for a in range(45)]
    Ws=[]
    for cross in [False,True]:
        Ws.append([plus(sc(elem(1151+a),width[a] if cross and selected[a] else ONE if not cross else J.ZERO),
                          sc(elem(598+a),J.times(I,J.times(width[a],width[a])*J.constant(F(1,2))) if cross and selected[a] else J.times(I,width[a]) if not cross else J.ZERO)) for a in range(45)])
    # Show the actual nonlinear remainder instead of assuming a full doublet.
    for a in range(45):
        qw=oddact(Ws[0][a],Q);ideal=sc(plus(y[a],sc(elem(1241+a),-ONE)),I)
        rem=plus(qw,sc(ideal,-ONE))
        if rem:qW_remainders.append({'probe':pr,'color':a,'full_qW_minus_linear':J.encode(rem)})
    for fam in ['A','B']:
        for n,V in enumerate(basis):
            maps=[{} for a in range(45)]
            for (i,j),c in V.items():maps[i]=plus(maps[i],sc(y[j] if fam=='A' else elem(1241+j),c))
            Ks=[]
            for W in Ws:
                z={}
                for a in range(45):J.add(z,sc(J.mul(W[a],maps[a]),J.times(-I,gg)))
                Ks.append(J.clean(z))
            CC=[oddact(Ks[0],Q),plus(oddact(Ks[1],Q),oddact(Ks[0],probes[pr]))]
            EE=[]
            for K in Ks:
                dk=v.act(AA,to_raw(K),D,0,'primary');components=v.euler(AA,dk,set(range(EPS,EPS+33)),'primary')
                EE.append({str(a):J.encode(grade(from_raw(components[EPS+a-12]),1,True)) for a in range(12,45)})
            items=[]
            for order,P in enumerate(CC):
                p,spec,sh=extract_C(grade(P,1,True));items.append({'order':order,'selected_density':J.encode(p),'spectator_source_density':J.encode(spec),'excluded_shapes':sh})
            rows.append({'probe':pr,'family':fam,'tensor':n,'C':items,'DK_components':EE})
        print('STAGE complete QK/DK reduced factory '+str(pr)+' '+fam,flush=True)
blob=gzip.compress((json.dumps({'rows':rows,'qW_nonlinear_remainders':qW_remainders},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'factory_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPT_ACTUAL_QK_DK_COMMON_PARENT_FACTORY','generator_tensor_directions':28,'probe_cases':len(rows),
 'all_actual_Q_and_QG_used_before_projection':True,'full_qW_nonlinear_remainder_components':len(qW_remainders),
 'source_companions_retained':True,'quantum_kernels_not_yet_evaluated':True,'table_sha256':sha256(blob).hexdigest(),
 'full_Ward_QAP_E5_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'factory_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
