from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'explicit.py').read_text()
old="C=next(r for r in load(O/'factory_tables.json.gz')['rows'] if r['probe']==0 and r['family']==fam and r['tensor']==n)"
assert src.count(old)==1
src=src.replace('rows=[];nonzero=0',"factory=load(O/'factory_tables.json.gz')['rows'];indexed={(r['family'],r['tensor']):r for r in factory if r['probe']==0}\nrows=[];nonzero=0")
src=src.replace(old,'C=indexed[fam,n]')
src=src.replace("O/'explicit_preparation.json'","O/'explicit_preparation_v2.json'").replace("O/'explicit_tables.json.gz'","O/'explicit_tables_v2.json.gz'").replace("O/'explicit_result.json'","O/'explicit_result_v2.json'")
with(O/'explicit_v2.py').open('xb') as f:f.write(src.encode())
src=(O/'run_explicit.py').read_text().replace("read(O/'kernel_preparation.json')","read(O/'explicit_preparation.json')")
src=src.replace("['EXPLICIT_ORDER_RECORD.md','explicit.py','run_explicit.py']","['CONTINUATION_V2.md','make_v2.py','explicit_v2.py','run_explicit_v2.py']")
src=src.replace("dump(O/'explicit_preparation.json'","dump(O/'explicit_preparation_v2.json'").replace("O/'explicit.py'","O/'explicit_v2.py'")
src=src.replace("O/'explicit_capture.json'","O/'explicit_capture_v2.json'").replace("C/'explicit_full_capture.json'","C/'explicit_full_capture_v2.json'").replace("O/'explicit_controller_failure.json'","O/'explicit_controller_failure_v2.json'")
with(O/'run_explicit_v2.py').open('xb') as f:f.write(src.encode())
