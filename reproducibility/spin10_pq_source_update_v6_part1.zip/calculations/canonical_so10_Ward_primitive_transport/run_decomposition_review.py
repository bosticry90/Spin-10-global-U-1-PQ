from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-transport-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
    with p.open('xb') as f:f.write(blob)
try:
    cap=read(O/'decomposition_capture_v2.json');assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
    bindings={}
    for prep in O.glob('*preparation*.json'):
        for p,h in read(prep)['input_sha256'].items():assert digest(Path(p))==h,(prep.name,p);bindings[p]=h
    for name in ['DECOMPOSITION_REVIEW_RECORD.md','verify_decomposition.py','run_decomposition_review.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    for p in O.iterdir():
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'decomposition_review_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'verify_decomposition.py')]);dump(O/'decomposition_review_capture.json',cap);dump(C/'decomposition_review_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED WPT separate source/regulator identity review',flush=True)
except BaseException:
    dump(O/'decomposition_review_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
