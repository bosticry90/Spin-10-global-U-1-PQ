from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'explicit_v2.py').read_text()
start=src.index('        for s in range(12,45):');end=src.index("        print('STAGE",start)
replacement='''        vertices={}
        for r in range(45):
            v=[dict(CJ[r]),dict(CY[r]),{}]
            for i in range(45):
                for ij,c in ML[i].items():
                    accum(v[1],ij,J.times(J.times(I,c),N.get((i,r),Z)))
                    accum(v[2],ij,J.times(J.times(I,c),M.get((i,r),Z)))
            vertices[r]=v
        for s in range(12,45):
            for r in range(45):
                pol={}
                for k,mat in enumerate(vertices[r]):
                    trace=sum((J.times(c,mat.get((j,i),Z)) for (i,j),c in LL[s].items()),Z)
                    accum(pol,k,-trace);accum(pol,k+1,trace)
                pol={k:c for k,c in pol.items() if c};assert sum(pol.values(),Z)==Z
                nonzero+=bool(pol);rows.append({'family':fam,'tensor':n,'epsilon':s,'Ja':r,'heat22':[[k,[[list(key),q.numerator,q.denominator] for key,q in c.terms]] for k,c in sorted(pol.items())]})
'''
src=src[:start]+replacement+src[end:]
src=src.replace("O/'explicit_preparation_v2.json'","O/'explicit_preparation_v3.json'").replace("O/'explicit_tables_v2.json.gz'","O/'explicit_tables_v3.json.gz'").replace("O/'explicit_result_v2.json'","O/'explicit_result_v3.json'")
with(O/'explicit_v3.py').open('xb') as f:f.write(src.encode())
src=(O/'run_explicit_v2.py').read_text().replace("read(O/'explicit_preparation.json')","read(O/'explicit_preparation_v2.json')")
src=src.replace("['CONTINUATION_V2.md','make_v2.py','explicit_v2.py','run_explicit_v2.py']","['CONTINUATION_V3.md','make_v3.py','explicit_v3.py','run_explicit_v3.py']")
src=src.replace("dump(O/'explicit_preparation_v2.json'","dump(O/'explicit_preparation_v3.json'").replace("O/'explicit_v2.py'","O/'explicit_v3.py'")
src=src.replace("O/'explicit_capture_v2.json'","O/'explicit_capture_v3.json'").replace("C/'explicit_full_capture_v2.json'","C/'explicit_full_capture_v3.json'").replace("O/'explicit_controller_failure_v2.json'","O/'explicit_controller_failure_v3.json'")
with(O/'run_explicit_v3.py').open('xb') as f:f.write(src.encode())
