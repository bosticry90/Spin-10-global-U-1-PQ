from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
import ast,gzip,json,os,sys,threading,time
import numpy as np
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'tree_review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I;prime=1009;roots=[next(x for x in range(prime) if x*x%prime==z%prime) for z in [2,3,5,7,-1]];ii=roots[4]
eye=np.eye(45,dtype=np.int64);zero=np.zeros((45,45),dtype=np.int64)
tree=ast.parse((O/'verify_v2.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['evaluator','arr','dc','dot','mat']]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'qualified-decoder-arithmetic','exec'))
width=[J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))]) for i in range(45)]
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[mat(z) for z in cov['symmetric_basis']+cov['skew_basis']]
data=load(O/'tree_tables.json.gz');bycase=defaultdict(list)
for row in data['complete_color_table']:bycase[row['probe'],row['family'],row['tensor']].append(row)
def ep(rows,E,f):return sum(pow(E,k,prime)*f(dc(c)) for k,c in rows)%prime
def schur(Ft,GG,Fj,target):
    out=np.zeros((33,45),dtype=np.int64)
    for a,A in Ft.items():
        for b,B in GG.items():
            for c,C in Fj.items():
                if tuple(x+y+z for x,y,z in zip(a,b,c))==target:out=(out+dot(dot(A.T,B),C))%prime
    return out
checks=0;field_sensitive=0;source_contact_sensitive=0
for xi,eta,E in [(2,3,2*pow(7,-1,prime)%prime),(5,7,3*pow(11,-1,prime)%prime)]:
    f=evaluator(xi,eta);Om=np.diag([f(w) for w in width]);G=E*np.block([[Om,-ii*eye],[-ii*eye,zero]])%prime
    Fj0=np.vstack([zero,-ii*eye])%prime;Ft0=np.vstack([eye[:,12:],-ii*dot(Om,eye[:,12:])*pow(2,-1,prime)])%prime
    for (pr,fam,tn),rows in bycase.items():
        V=arr(basis[tn],f);A=V if fam=='A' else zero;B=V if fam=='B' else zero
        Pi=np.diag([int(i<12 if pr==0 else i>=12) for i in range(45)]).astype(np.int64);S=dot(Om,Pi)
        Hu=np.block([[-2*Pi,ii*S],[ii*S,dot(Om,S)*pow(2,-1,prime)]])%prime
        Hb=np.block([[A+A.T,zero],[zero,zero]])%prime
        Gu=-dot(dot(G,Hu),G)%prime;Gb=-dot(dot(G,Hb),G)%prime
        Gbu=(dot(dot(dot(dot(G,Hu),G),Hb),G)+dot(dot(dot(dot(G,Hb),G),Hu),G))%prime
        GG={(0,0):G,(1,0):Gb,(0,1):Gu,(1,1):Gbu}
        Fju=np.vstack([2*Pi,-ii*S])%prime;Fjb=np.vstack([B-A.T,zero])%prime
        Ftb=np.vstack([dot(A.T,dot(Om,eye[:,12:]))*pow(2,-1,prime),np.zeros((45,33),dtype=np.int64)])%prime
        direct=dot(Om,B)[12:]*pow(2,-1,prime)%prime
        Fj={(0,0):Fj0,(0,1):Fju,(1,0):Fjb};Ft={(0,0):Ft0,(1,0):Ftb}
        base=(schur(Ft,GG,Fj,(1,0))-direct)%prime;cross=schur(Ft,GG,Fj,(1,1))
        fixedbase=schur({(0,0):Ft0},GG,Fj,(1,0));fixedcross=schur({(0,0):Ft0},GG,Fj,(1,1))
        compbase=(base-fixedbase)%prime;compcross=(cross-fixedcross)%prime
        for row in rows:
            s,r=row['epsilon']-12,row['Ja']
            names=['transported_base','fixed_base','companion_base','transported_cross','fixed_cross','companion_cross']
            assert [ep(row[name],E,f) for name in names]==[int(k[s,r]) for k in [base,fixedbase,compbase,cross,fixedcross,compcross]]
            expected=dot(Om,A+B)[12:]*pow(2,-1,prime)%prime
            assert f(dc(row['fixed_base_finite_contact']))==int(expected[s,r])
            field_sensitive+=int((base[s,r]+compbase[s,r]+direct[s,r])%prime!=base[s,r])
            source_contact_sensitive+=int(direct[s,r]!=0);checks+=1
    print('STAGE independent classical Schur complement '+str(xi)+' '+str(eta),flush=True)
assert checks==166320 and field_sensitive>0 and source_contact_sensitive>0
# Exact kernel vectors and direct rectangular restriction rank.
vectors=[[dc(c) for c in v] for v in data['restriction_kernel_in14_coordinates']]
assert len(vectors)==4
for v in vectors:
    out={}
    for c,V in zip(v,basis):
        for ij,z in V.items():out[ij]=out.get(ij,Z)+J.times(c,z)
    assert not any(c for (i,j),c in out.items() if i>=12) and any(out.values())
f=evaluator(2,3)
def rank(a):
    a=[[int(x)%prime for x in row] for row in a];nr=len(a);nc=len(a[0]);rr=0
    for c in range(nc):
        p=next((i for i in range(rr,nr) if a[i][c]),None)
        if p is None:continue
        a[rr],a[p]=a[p],a[rr];iv=pow(a[rr][c],-1,prime);a[rr]=[x*iv%prime for x in a[rr]]
        for i in range(rr+1,nr):
            if a[i][c]:factor=a[i][c];a[i]=[(x-factor*y)%prime for x,y in zip(a[i],a[rr])]
        rr+=1
        if rr==nr:break
    return rr
restriction=[[f(V.get((s,r),Z)) for V in basis] for s in range(12,45) for r in range(45)]
assert rank(restriction)==10 and rank([[f(v[i]) for v in vectors] for i in range(14)])==4
core=np.zeros((32,28),dtype=np.int64)
for i in range(14):
    if i<9:core[i,i]=2;core[9+i,i]=-1;core[9+i,14+i]=1;core[23+i,14+i]=-2
    else:core[9+i,i]=-1;core[9+i,14+i]=-1
kernel=np.zeros((28,18),dtype=np.int64)
for i in range(14):kernel[i,i]=1;kernel[14+i,i]=-1
for j,v in enumerate(vectors):
    for i,c in enumerate(v):kernel[14+i,14+j]=f(c)
assert rank(kernel.tolist())==18 and rank(dot(core,kernel).tolist())==13
assert not np.any(dot(core,kernel)[:,9:14]),'FIVE_PROJECTED_NULL_DIRECTIONS_NOT_RETAINED'
meta=read(O/'tree_result.json');assert meta['actual_restricted_tensor_map_rank']==10 and not meta['condition_imposed_on_theory']
out={'schema':'WPT_SEPARATE_CLASSICAL_CONTACT_NORMALIZATION_REVIEW','evidence_validation':'PASS_CORRELATED_FINITE_CONTACT_TRANSPORT_LAW',
 'independent_classical_Schur_color_checks':checks,'omitted_primitive_field_companion_sensitive_diagnostics':field_sensitive,
 'omitted_primitive_source_contact_sensitive_diagnostics':source_contact_sensitive,'exact_kernel_vectors_checked':4,
 'direct_rectangular_restriction_rank':10,'conditional_generator_dimension':18,'conditional_selected_core_dimension':13,
 'projected_core_kernel_five_retained':True,'finite_shift':'P_M*Omega*(A+B)/2','full_DK_completion_required_not_isolated_contact':True,
 'baseline_or_condition_adopted':False,'general_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'tree_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
