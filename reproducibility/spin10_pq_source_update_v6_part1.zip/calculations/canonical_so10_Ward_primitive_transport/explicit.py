from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'explicit_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I
def dc(c):return J.Coeff([(tuple(k),F(n,d)) for k,n,d in c])
def old(c):return J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in c])
def sc(c,n):return J.times(c,J.constant(n))
def accum(out,k,c):out[k]=out.get(k,Z)+c
def pc(A,B):
    out=dict(A)
    for k,c in B.items():accum(out,k,c)
    return {k:c for k,c in out.items() if c}
qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
ML={int(i):{(a,b):old(c) for a,b,c in rows} for i,rows in qt['M_Lambda'].items()};LL={int(i):{(a,b):old(c) for a,b,c in rows} for i,rows in qt['L'].items()}
width=[J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))]) for i in range(45)]
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[{(i,j):dc(c) for i,j,c in rows} for rows in cov['symmetric_basis']+cov['skew_basis']]
rows=[];nonzero=0
for fam in ['A','B']:
    for n,V in enumerate(basis):
        A=V if fam=='A' else {};B=V if fam=='B' else {};M=dict(A)
        for (i,j),c in A.items():accum(M,(j,i),c)
        N=dict(B)
        for (i,j),c in A.items():accum(N,(j,i),-c)
        C=next(r for r in load(O/'factory_tables.json.gz')['rows'] if r['probe']==0 and r['family']==fam and r['tensor']==n)
        CY=defaultdict(dict);CJ=defaultdict(dict)
        for w,c in J.decode(C['C'][0]['selected_density']).items():
            gs=[t for t in w if 553<=t[0]<643];rest=[t for t in w if not 553<=t[0]<643]
            if len(gs)!=2 or len(rest)!=1 or any(js for i,js in gs):continue
            i=next(i-598 for i,js in gs if i>=598);j=next(i-553 for i,js in gs if i<598);tok=rest[0]
            if tok[0]<180:
                if tok[0]%4==0 and tok[1]==(0,):accum(CY[tok[0]//4],(i,j),-c)
            elif 1241<=tok[0]<1286 and not tok[1]:accum(CJ[tok[0]-1241],(i,j),-c)
        for s in range(12,45):
            for r in range(45):
                # V_bJa=i E sum_i ML_i N_ir +i E2 sum_i ML_i M_ir
                #          +E CY_r+CJ_r; theta=(1-E)L_s.
                v=[dict(CJ[r]),dict(CY[r]),{}]
                for i in range(45):
                    for ij,c in ML[i].items():
                        accum(v[1],ij,J.times(J.times(I,c),N.get((i,r),Z)))
                        accum(v[2],ij,J.times(J.times(I,c),M.get((i,r),Z)))
                pol={}
                for k,mat in enumerate(v):
                    trace=sum((J.times(c,mat.get((j,i),Z)) for (i,j),c in LL[s].items()),Z)
                    accum(pol,k,-trace);accum(pol,k+1,trace)
                pol={k:c for k,c in pol.items() if c};assert sum(pol.values(),Z)==Z
                nonzero+=bool(pol);rows.append({'family':fam,'tensor':n,'epsilon':s,'Ja':r,'heat22':[[k,[[list(key),q.numerator,q.denominator] for key,q in c.terms]] for k,c in sorted(pol.items())]})
        print('STAGE explicit-u generator map '+fam+str(n),flush=True)
blob=gzip.compress((json.dumps({'complete_color_table':rows},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'explicit_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPT_INDEPENDENT_EXPLICIT_U_GENERATOR_MAP','complete_color_positions':len(rows),'nonzero_heat22_positions':nonzero,
 'same_map_each_probe_by_degree_linearity':True,'all_UV_heat_roots_verified':True,'ghost_third_edge_and_DK_companion_zero_by_original_Ja_Hessian':True,
 'table_sha256':sha256(blob).hexdigest(),'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'explicit_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
