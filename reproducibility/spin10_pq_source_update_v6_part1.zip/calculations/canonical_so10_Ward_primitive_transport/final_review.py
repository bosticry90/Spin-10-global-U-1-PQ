from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import ast,gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/Ward-primitive-transport-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={}
for prep in O.glob('*preparation*.json'):
    for name,h in read(prep)['input_sha256'].items():
        assert digest(Path(name))==h,(prep.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'factory_capture.json':'factory.py','kernel_capture.json':'kernels.py','explicit_capture_v3.json':'explicit_v3.py',
 'review_capture_v2.json':'verify_v2.py','decomposition_capture_v2.json':'decomposition_v2.py','decomposition_review_capture.json':'verify_decomposition.py',
 'tree_capture.json':'tree_normalization.py','tree_review_capture.json':'verify_tree.py','e4_capture.json':None}
failed={'explicit_capture.json':('explicit.py',124,None),'explicit_capture_v2.json':('explicit_v2.py',124,None),
 'review_capture.json':('verify.py',1,'FileNotFoundError'),'decomposition_capture.json':('decomposition.py',1,"name 'encode' is not defined")}
samples={};seen=set()
for p in O.glob('*capture*.json'):
    cap=read(p);seen.add(p.name)
    assert cap['launch']['creation_after_observation'] and cap['post_run_observations_qualified']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    if p.name in failed:
        worker,code,signature=failed[p.name]
        assert cap['exit_code']==code and cap['execution_state']=='FAILED' and not cap['calculation_completed']
        if signature:assert signature in cap['stdout_and_stderr']
        assert cap['command'][-2:]==['-B',str(O/worker)]
    else:
        assert p.name in accepted and cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
        worker=accepted[p.name]
        assert cap['command'][-2:]==['-B',str(O/worker)] if worker else cap['command'][-3:]==['-B','tools/research_check.py','e4']
assert seen==set(accepted)|set(failed)
assert sorted(p.name for p in O.glob('*controller_failure*.json'))==['decomposition_controller_failure.json','explicit_controller_failure.json','explicit_controller_failure_v2.json','review_controller_failure.json']
assert not (O/'explicit_result.json').exists() and not (O/'explicit_result_v2.json').exists() and not (O/'validation_receipt.json').exists() and not (O/'decomposition_result.json').exists()
results=[('factory_result.json','factory_tables.json.gz'),('kernel_result.json','kernel_tables.json.gz'),('explicit_result_v3.json','explicit_tables_v3.json.gz'),('decomposition_result_v2.json','decomposition_tables_v2.json.gz'),('tree_result.json','tree_tables.json.gz')]
for result,table in results:
    v=read(O/result);assert v['table_sha256']==digest(O/table) and v['elapsed_after_imports']<180
for name,expected in [('validation_receipt_v2.json','PASS_LEADING_COMMON_PARENT_REFERENCE_TRANSPORT'),('decomposition_validation_receipt.json','PASS_SELECTED_FINITE_HEAT_AFFINE_TRANSPORT_IDENTITY'),('tree_validation_receipt.json','PASS_CORRELATED_FINITE_CONTACT_TRANSPORT_LAW')]:
    v=read(O/name);assert v['evidence_validation']==expected and v['elapsed_after_imports']<180
v=read(O/'validation_receipt_v2.json');assert v['exact_even_action_current_and_source_cases']==56 and v['spectator_source_cells_checked']==9624 and v['whole_JB_source_kinetic_cross_cases']==28
assert v['finite_Berezin_ordered_result']=='19/216' and v['finite_Berezin_third_edge_contribution']=='55/216' and not v['physical_finite_delta_or_full_Ward_QAP_E5_claim']
k=read(O/'kernel_result.json');assert k['complete_color_positions']==83160 and k['generator_probe_cases']==56 and k['all_channel_UV_heat_roots_verified']
assert k['nonzero_channel_positions']=={'companion':604,'fixed22':623,'heat22':455,'heat24':790,'heat42':790}
e=read(O/'explicit_result_v3.json');assert e['complete_color_positions']==41580 and e['nonzero_heat22_positions']==323
d=read(O/'decomposition_result_v2.json');assert d['complete_color_positions']==83160 and d['selected_finite_heat_identity_qualified'] and d['nonzero_heat22_residual_positions']==d['nonzero_combined_asymmetric_residual_positions']==d['ordered_asymmetric_residual_positions_retained']==0
dv=read(O/'decomposition_validation_receipt.json');assert dv['independent_block_source_regulator_color_checks']==166320 and dv['exact_explicit_u_color_coefficients_checked']==41580 and not dv['physical_measure_general_Ward_QAP_E5_claim']
t=read(O/'tree_result.json');tv=read(O/'tree_validation_receipt.json');assert t['complete_cross_color_positions']==83160 and t['nonzero_fixed_primitive_contact_positions']==860
assert t['actual_restricted_tensor_map_rank']==t['modular_lower_bound']==tv['direct_rectangular_restriction_rank']==10 and t['exact_restriction_kernel_dimension']==4
assert t['conditional_generator_dimensions']==18 and t['conditional_selected_core_dimensions']==13 and not t['condition_imposed_on_theory'] and not tv['baseline_or_condition_adopted']
assert tv['independent_classical_Schur_color_checks']==166320 and tv['projected_core_kernel_five_retained']
tab=load(O/'decomposition_tables_v2.json.gz');rows=tab['complete_color_table'];assert len(rows)==83160 and len({(r['probe'],r['family'],r['tensor'],r['epsilon'],r['Ja']) for r in rows})==83160
assert all(not any(r['ordered_residual']) and not r['combined_asymmetric_residual'] for r in rows)
tab=load(O/'kernel_tables.json.gz')
for r in tab['complete_color_table']:
    for name in ['heat22','heat42','heat24','primitive_companion','fixed_primitive_heat22']:
        cells={}
        for power,cs in r[name]:
            for key,n,den in cs:cells[tuple(key)]=cells.get(tuple(key),F(0))+F(n,den)
        assert not any(cells.values())
assert len(load(O/'explicit_tables_v3.json.gz')['complete_color_table'])==41580 and len(load(O/'tree_tables.json.gz')['complete_color_table'])==83160
text=(O/'PROOF.md').read_text();assert 'CLASSICAL' in text and 'NOT imposed' in text and 'No Dminus C=0' in text
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
events=read(O/'e4_events.json');steps=[x for x in events if x['event']=='step_finished'];exits=[x['exit_code'] for x in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and sum(x['seconds'] for x in steps)<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='a127437a97f8509ab94f2584682187264d07fa07' and git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes() and len((C/'old_git_tree.txt').read_bytes().splitlines())==41621
git('diff','--quiet','HEAD','--');state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'schema':'WPT_FINAL_EVIDENCE_REVIEW','evidence_validation':'PASS_BOUNDED_QUANTUM_TRANSPORT_AND_CORRELATED_CONTACT_LAW',
 'input_bindings_authenticated':len(bindings),'source_copies_equal':len(copies),'accepted_completed_captures':sorted(accepted),
 'failed_captures_preserved':sorted(failed),'resource_incomplete_captures':['explicit_capture.json','explicit_capture_v2.json'],
 'failure_counted_PASS':False,'full_Ward_QAP_E5_physical_claim':False,'normalization_baseline_or_condition_adopted':False,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,'old_tracked_tree_unchanged':True,
 'largest_accepted_private_sample':max(samples[z] for z in accepted),'largest_all_captures_private_sample':max(samples.values()),
 'memory_samples_not_true_peak':True,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
