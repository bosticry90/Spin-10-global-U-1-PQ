from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I;half=J.constant(F(1,2))
mul=J.times
def sc(c,n):return mul(c,J.constant(n))
def decode(c):return J.Coeff([(tuple(k),F(n,d)) for k,n,d in c])
def decode_old(c):return J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in c])
def encode(c):return [[list(k),z.numerator,z.denominator] for k,z in c.terms]
def mp(rows,old=False):return {(i,j):(decode_old(c) if old else decode(c)) for i,j,c in rows}
def madd(A,B):
    out=dict(A)
    for ij,c in B.items():out[ij]=out.get(ij,Z)+c
    return {ij:c for ij,c in out.items() if c}
def msm(A,c):return {ij:mul(v,c) for ij,v in A.items() if mul(v,c)}
def transpose(A):return {(j,i):c for (i,j),c in A.items()}
# Polynomials in the external E, with exact coefficient-ring entries.
def pa(a,b):
    out=dict(a)
    for k,c in b.items():out[k]=out.get(k,Z)+c
    return {k:c for k,c in out.items() if c}
def ps(a,c):return {k:mul(z,c) for k,z in a.items() if mul(z,c)}
def pm(a,b):
    out={}
    for k,c in a.items():
        for j,d in b.items():out[k+j]=out.get(k+j,Z)+mul(c,d)
    return {k:c for k,c in out.items() if c}
def pe(a):return {k+1:c for k,c in a.items()}
def pp(c):return {0:c} if c else {}
def ev1(P):return sum(P.values(),Z)
def encp(P):return [[k,encode(c)] for k,c in sorted(P.items())]
def mmadd(A,B):
    out=dict(A)
    for ij,P in B.items():out[ij]=pa(out.get(ij,{}),P)
    return {ij:P for ij,P in out.items() if P}
def mgscale(M,P):return {ij:pm(v,P) for ij,v in M.items() if pm(v,P)}
def atomM(M):return {ij:pp(c) for ij,c in M.items()}
def tr(A,B):
    out={}
    for (i,j),P in A.items():
        if (j,i) in B:out=pa(out,pm(P,B[j,i]))
    return out
def tr3(A,B,C):
    # B is a constant kinetic matrix. Preserve its place in the word.
    byrow=defaultdict(list)
    for (i,j),c in B.items():byrow[i].append((j,c))
    out={}
    for (i,j),P in A.items():
        for k,c in byrow[j]:
            if (k,i) in C:out=pa(out,ps(pm(P,C[k,i]),c))
    return out
def mv(M,V):
    out={}
    for (i,j),c in M.items():
        if j in V:out[i]=pa(out.get(i,{}),ps(V[j],c))
    return {i:P for i,P in out.items() if P}
def va(A,B):
    out=dict(A)
    for i,P in B.items():out[i]=pa(out.get(i,{}),P)
    return {i:P for i,P in out.items() if P}
width=[J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))]) for i in range(45)]
def compact(n,js):
    if n<180:return n//4 if n%4==0 and js==(0,) else None
    if 508<=n<553 and not js:return 45+n-508
    if 1241<=n<1286 and not js:return 90+n-1241
    raise AssertionError(('UNEXPECTED_COMPACT_PORT',n,js))
def expand_compact(P):
    out={}
    for w,c in P.items():
        z={():c}
        for n in w:
            fact={((4*n+mu,(mu,)),):ONE for mu in range(4)} if n<45 else {((508+n-45 if n<90 else 1241+n-90,()),):ONE}
            z=J.mul(z,fact)
        J.add(out,z)
    return J.clean(out)
def parse(P):
    bos={};bg=[defaultdict(dict) for _ in range(3)];kin={};spect={};massdensity={};kineticdensity={}
    for w,c in P.items():
        if any(n>=643 and not 1241<=n<1286 for n,js in w):spect[w]=c;continue
        gh=[(n,js) for n,js in w if 553<=n<643];oth=[(n,js) for n,js in w if not 553<=n<643]
        if not gh:
            cw=[compact(n,js) for n,js in w]
            if all(n is not None for n in cw):bos[tuple(cw)]=bos.get(tuple(cw),Z)+c
            continue
        assert len(gh)==2 and len([n for n,js in gh if n<598])==1
        cc=next(t for t in gh if t[0]<598);aa=next(t for t in gh if t[0]>=598);ij=aa[0]-598,cc[0]-553
        if not oth:
            assert not aa[1] and len(cc[1])==2 and cc[1][0]==cc[1][1],'UNEXPECTED_C_KINETIC_DERIVATIVES'
            kineticdensity[w]=c
            if cc[1]==(0,0):kin[ij]=kin.get(ij,Z)+c
        else:
            assert len(oth)==1 and not aa[1] and not cc[1],'UNEXPECTED_C_MASS_BACKGROUND'
            massdensity[w]=c;n=compact(*oth[0])
            if n is not None:
                block=n//45;idx=n%45;bg[block][idx][ij]=bg[block][idx].get(ij,Z)-c
    bos=J.clean(bos);purebos={w:c for w,c in P.items() if not any(553<=n<643 for n,js in w) and not any(n>=643 and n<1241 for n,js in w)}
    assert expand_compact(bos)==purebos,'BOSON_DIVB_RECONSTRUCTION_FAILS'
    reconstruct={}
    for ij,c in kin.items():
        for mu in range(4):J.put(reconstruct,((553+ij[1],(mu,mu)),(598+ij[0],())),c)
    assert J.clean(reconstruct)==kineticdensity,'KINETIC_LORENTZ_RECONSTRUCTION_FAILS'
    reconstruct={}
    for block,mats in enumerate(bg):
        for a,M in mats.items():
            for (i,j),c in M.items():
                factors=[(4*a+mu,(mu,)) for mu in range(4)] if block==0 else [(508+a if block==1 else 1241+a,())]
                for tok in factors:J.put(reconstruct,(tok,(553+j,()),(598+i,())),-c)
    assert J.clean(reconstruct)==massdensity,'MASS_DIVB_RECONSTRUCTION_FAILS'
    return bos,[{a:{ij:c for ij,c in M.items() if c} for a,M in mats.items()} for mats in bg],{ij:c for ij,c in kin.items() if c},spect
def parseE(P):
    bos={};L={};spect={}
    for w,c in P.items():
        if any(n>=643 and not 1241<=n<1286 for n,js in w):spect[w]=c;continue
        if len(w)==1:
            n=compact(*w[0])
            if n is not None:bos[n]=bos.get(n,Z)+c
        elif len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643 and all(not js for n,js in w):L[w[1][0]-598,w[0][0]-553]=-c
        else:raise AssertionError(('UNEXPECTED_DK_COMPONENT',w))
    expected=expand_compact({(n,):c for n,c in bos.items()})
    for (i,j),c in L.items():J.put(expected,((553+j,()),(598+i,())),-c)
    assert J.clean(expected)=={w:c for w,c in P.items() if w not in spect},'DK_LORENTZ_RECONSTRUCTION_FAILS'
    assert not any(45<=n<90 for n in bos),'DK_AFFINE_LAMBDA_UNEXPECTED'
    return bos,L,spect
qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
ML={int(a):mp(z,True) for a,z in qt['M_Lambda'].items()};L0={int(a):mp(z,True) for a,z in qt['L'].items()}
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[mp(z) for z in cov['symmetric_basis']+cov['skew_basis']]
factory=load(O/'factory_tables.json.gz');allrows=[];cases=[];matrix_factories=[];globalcounts=defaultdict(int)
for row in factory['rows']:
    pr=row['probe'];fam=row['family'];tn=row['tensor'];V=basis[tn];A=V if fam=='A' else {};B=V if fam=='B' else {};selected=[a<12 if pr==0 else a>=12 for a in range(45)]
    c0,bg0,k0,sp0=parse(J.decode(row['C'][0]['selected_density']));c1,bg1,k1,sp1=parse(J.decode(row['C'][1]['selected_density']))
    assert not c1,'BOSONIC_FIRST_U_CORE_DOES_NOT_CANCEL'
    expected={}
    for M,source in [(A,False),(B,True)]:
        for (i,j),c in M.items():
            for left,sg in [(i,1),(90+i,-1)]:
                key=tuple(sorted([left,90+j if source else j]));expected[key]=expected.get(key,Z)+c*sg
    assert c0==J.clean(expected),'ACTUAL_QK_BOSON_CORE_MISMATCH'
    M=madd(A,transpose(A));N=madd(B,msm(transpose(A),-ONE))
    expectedkin={(i,j):mul(width[i],c) for (i,j),c in madd(A,B).items()}
    assert k0==expectedkin,'ACTUAL_QK_KINETIC_CORE_MISMATCH'
    Es=[];Ems=[];Espec=[]
    for up in [0,1]:
        es={};em={};espec={}
        for ss,cells in row['DK_components'][up].items():
            bs,LL,sp=parseE(J.decode(cells));es[int(ss)]=bs;em[int(ss)]=LL;espec[int(ss)]=J.encode(sp)
        Es.append(es);Ems.append(em);Espec.append(espec)
    assert all(not z for z in Es[1].values()),'DK_FIRST_U_BOSON_CORE_UNEXPECTED'
    WY={ss:{i:c for i,c in bs.items() if i<45} for ss,bs in Es[0].items()}
    U=qt['probes'][pr];Uy={int(i):mp(z,True) for i,z in U['M_y'].items()};Ul={int(i):mp(z,True) for i,z in U['M_Lambda'].items()};Uj={int(i):mp(z,True) for i,z in U['N_direct'].items()}
    def inverse(force):
        yy,ll=force;outy={};outl={}
        for i in set(yy)|set(ll):
            q=pa(ps(yy.get(i,{}),width[i]),ps(ll.get(i,{}),-I));outy[i]=ps(pe(q),-ONE);outl[i]=ps(pe(yy.get(i,{})),I)
        return {i:P for i,P in outy.items() if P},{i:P for i,P in outl.items() if P}
    def hu(x):
        yy,ll=x;fy={};fl={}
        for i in set(yy)|set(ll):
            if not selected[i]:continue
            fy[i]=pa(ps(yy.get(i,{}),-2*ONE),ps(ll.get(i,{}),mul(I,width[i])))
            fl[i]=pa(ps(yy.get(i,{}),mul(I,width[i])),ps(ll.get(i,{}),mul(mul(width[i],width[i]),half)))
        return fy,fl
    def hb(x):return mv(M,x[0]),{}
    def means(kind,r):
        x0=({r:{1:ONE}}, {}) if kind=='J' else ({r:{1:sc(width[r],F(-1,2))}},{r:{1:I}})
        forceu=hu(x0)
        if kind=='J' and selected[r]:forceu=va(forceu[0],{r:pp(2*ONE)}),va(forceu[1],{r:pp(mul(-I,width[r]))})
        xu=inverse(forceu)
        source={i:pp(c) for (i,j),c in N.items() if j==r} if kind=='J' else {i:pp(c) for i,c in WY[r].items()}
        forceb=hb(x0);xb=inverse((va(forceb[0],source),{}))
        p=hu(xb);q=hb(xu);xbu=inverse((va(p[0],q[0]),va(p[1],q[1])))
        xdk=inverse(({i:pp(c) for i,c in WY[r].items()},{})) if kind=='T' else ({},{})
        return [x0,xu,xb,xbu,xdk]
    def bgmass(bg,x):
        out={}
        for bank,vec in zip(bg[:2],x):
            for a,P in vec.items():
                if bank.get(a):out=mmadd(out,mgscale(atomM(bank[a]),P))
        return out
    def original(x):return bgmass([{},ML,{}],x)
    thetas={};jas={};dkthetas={}
    for kind,ids in [('T',range(12,45)),('J',range(45))]:
        for r in ids:
            xs=means(kind,r);V00=original(xs[0]);Vu=mmadd(original(xs[1]),bgmass([Uy,Ul,Uj],xs[0]));Vb=mmadd(original(xs[2]),bgmass(bg0,xs[0]));Vbu=mmadd(original(xs[3]),mmadd(bgmass([Uy,Ul,Uj],xs[2]),mmadd(bgmass(bg0,xs[1]),bgmass(bg1,xs[0]))))
            if kind=='J':
                Vu=mmadd(Vu,atomM(Uj.get(r,{})));Vb=mmadd(Vb,atomM(bg0[2].get(r,{})));Vbu=mmadd(Vbu,atomM(bg1[2].get(r,{})))
                assert not V00,'ORIGINAL_JA_GHOST_HESSIAN_NOT_ZERO'
                expected=mgscale(atomM(Uj.get(r,{})),{0:ONE,1:-2*ONE,2:ONE})
                assert Vu==expected,'COMPLETE_UJA_MATRIX_NOT_QUADRATIC_HEAT_ROOT'
                jas[r]=[V00,Vu,Vb,Vbu]
            else:
                V00=mmadd(V00,atomM(L0[r]));Vb=mmadd(Vb,atomM(Ems[0][r]));Vbu=mmadd(Vbu,atomM(Ems[1][r]))
                assert V00==mgscale(atomM(L0[r]),{0:ONE,1:-ONE}) and not Vu,'ACTUAL_THETA_GHOST_ROOT_OR_U_RESPONSE_FAILS'
                thetas[r]=[V00,Vu,Vb,Vbu];dkthetas[r]=mmadd(atomM(Ems[0][r]),original(xs[4]))
    localcounts=defaultdict(int)
    for ss in range(12,45):
        ts=thetas[ss]
        for r in range(45):
            js=jas[r];p22={}
            for a,b in [(0,3),(1,2),(2,1),(3,0)]:p22=pa(p22,ps(tr(ts[a],js[b]),-ONE))
            p42=pa(tr3(ts[0],k0,js[1]),pa(tr3(ts[1],k0,js[0]),tr3(ts[0],k1,js[0])))
            p24=pa(tr3(js[1],k0,ts[0]),pa(tr3(js[0],k0,ts[1]),tr3(js[0],k1,ts[0])))
            companion=ps(tr(dkthetas[ss],js[1]),-ONE);fixed=pa(p22,ps(companion,-ONE))
            for label,P in [('heat22',p22),('heat42',p42),('heat24',p24),('companion',companion),('fixed22',fixed)]:
                assert not ev1(P),('UNSUPPRESSED_UV_COEFFICIENT',pr,fam,tn,ss,r,label)
                localcounts[label]+=bool(P)
            allrows.append({'probe':pr,'family':fam,'tensor':tn,'epsilon':ss,'Ja':r,'heat22':encp(p22),'heat42':encp(p42),'heat24':encp(p24),'primitive_companion':encp(companion),'fixed_primitive_heat22':encp(fixed)})
    cases.append({'probe':pr,'family':fam,'tensor':tn,'positions':1485,'nonzero_channel_positions':dict(localcounts)})
    for k,z in localcounts.items():globalcounts[k]+=z
    matrix_factories.append({'probe':pr,'family':fam,'tensor':tn,'boson_core':J.encode(expand_compact(c0)),
      'kinetic_base':[[i,j,encode(c)] for (i,j),c in sorted(k0.items())],
      'kinetic_u':[[i,j,encode(c)] for (i,j),c in sorted(k1.items())],
      'DK_spectator_source_components':Espec})
    print('STAGE complete ordered transport kernels '+str(pr)+' '+fam+str(tn),flush=True)
assert len(allrows)==83160
blob=gzip.compress((json.dumps({'cases':cases,'matrix_factories':matrix_factories,'complete_color_table':allrows},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'kernel_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPT_COMPLETE_ORDERED_REFERENCE_TRANSPORT_KERNELS','complete_color_positions':len(allrows),'generator_probe_cases':len(cases),
 'nonzero_channel_positions':dict(globalcounts),'all_channel_UV_heat_roots_verified':True,'both_transported_and_fixed_primitive_retained':True,
 'ghost_kinetic_third_edge_and_distinct_heats_retained':True,'general_finite_A_or_Ward_QAP_E5_physical_claim':False,
 'table_sha256':sha256(blob).hexdigest(),'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'kernel_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
