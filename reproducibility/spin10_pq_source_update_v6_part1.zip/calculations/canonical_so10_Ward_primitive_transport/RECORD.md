# WPT: common-parent finite-generator transport of the Ward primitive

Prospective ata127437a97f8509ab94f2584682187264d07fa07/main afterclean
preflight,AGENTS/highestV678/actualreceipts,no matching workers. Previous
goal turn PROGRESS:WPG complete selectedg1 reference kernel. Same full
active goal;state113/34of39,E5/A5 OPEN,custody2/sevenNOTPASS unchanged.

Question: what is the ACTUAL leading quantum transport of the primitive
under the MWN/MWX/MGT finite-generator family? This is a required bridge
between the constructed local finite family and the corrected Ward
operator. Do not invent Dminus A=0 or fit an insertion RHS.

Let K_u=-ig10[(1+uS)JL+iOmega(1+uS/2)a]^T(A y+BJa), S=Omega Pi,
with every28 actual A/B tensor direction (14 each). Define the correlated
local deformation C_u=Q_u K_u and primitive companion E_u=Dminus K_u.
The common marked parent is S+uQG+b C_u+rho(KD+b E_u), firstb andu.
This is transported-operator data; fixed KD is recovered by retaining
the independently calculated companion subtraction. No field-dependent
source product may be replaced by its mean. All original sources remain
through Q/D before the selected-source projection.

Because K already carriesg1, leading b*g1 transport uses the actualg0
action/operations. Additional originalg1 interactions first enterg2.
This justifies postponingg2/295 profiles for this target. It does not
promote a quantum Ward or multiple-product theorem.

Stage1 derive complete C/E field/source ports needed for the common
first-u,rho*epsilon_s/Ja_r coefficient (all33x45 directions,bothprobes).
Use actual full g0 Q and QG maps, not only their false doublet linear
jets. Keep the nonlinear ghost remainders, derivative order, cotangent
source signs and source-only contacts. Extract bosonic Gaussian matrices,
ghost kinetic and background matrices, and primitive affine/ghost roots.
Verify against independent open-index formulae; unexpected ports fail
the reduced Gaussian premise. The spectator JLambda*C companion must
be retained in the factory even when its target source is zero.

Then derive all b/u mean branches from the SAME quadratic bosonic parent
and calculate the ordered positive-heat ghost determinant/source-product
response. An unmarked b ghost-kinetic insertion can add a THIRD inverse
edge. Do not discard it or collapse its heat into a two-edge bubble.
Separate heat22 and heat42/24 kernels and their finite constants.
Keep the formal generic Jacobian's nonzero vacuum density: only its
rho/Ja derivatives may vanish by actual source independence. Distinguish
unit b one-loop response from an orderhbar b counterterm's orderhbar2
response. No interchange of nonuniform cutoff limits is assumed.

Expected evidence: exact full family factory with selected ports and
zeros, actual ordered kernels or precise remainder/underdefinition,
independent finite-action/Berezin/mean checks and meaningful controls,
common UV-FP-then-IR proof with1-f defects retained. Finite baselines and
arbitrary additional parent-A jets remain free; no kappa/b0/chi4 equation
or physical normalization is selected. Quantum inputs come from the
action, not the required cancellation. Fixed-operator Ward restoration
must be stated separately from transported-operator consistency.

Native180/review180s afterimports,8GiB sampled private cap,350MiB launch
floor,16MiB packet. Freeze immutable inputs/source copies before workers;
preserve exact failures/incompletes with new versions for corrections.
Noagents/newbranch/worktree/remote/adoption/promotion/protectedactivation.
E4once/nofresh,oldmodeblobs/rawnew/state preservation beforelocalcommit.
Shared action/chart/regulator/software/AIauthor limits remain explicit.
