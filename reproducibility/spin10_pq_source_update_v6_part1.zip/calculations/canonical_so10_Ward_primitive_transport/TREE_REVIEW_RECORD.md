# Independent classical Schur/contact review

Prospective after actual tree calculation:the fixed-primitive unprobed/
explicit-u finite shift is P_M Omega(A+B)/2,with860 nonzero positions
across the two probe catalogs. The restricted tensor map has proposed
rank10,kernel4; its zero-shift condition is conditional,not imposed.

Recompute tree responses by the Gaussian Schur complement
Ftheta^T H^-1 FJ minus the direct theta/Ja source contact. Differentiate
its block-matrix Woodbury inverse in b/u; do not reuse the native
stationary-response recursion. Compare all83160 source positions at two
nontrivial heat/width embeddings,including transported/fixed/companion
base and cross coefficients. Test omitted primitive field and contact
companions separately. At E=1 verify the finite matrix and unchanged
baseline freedom. A source-only contact in C may be insensitive in this
projection;do not label it validated by that control.

Independently check the actual1485x14 broken-row restriction by direct
modular rank,exact radical kernel vectors,and their independence. Check
the conditional projected-core rank directly on the18-dimensional
generator kernel,retaining the5 projected-null directions. No inverse
physical width,coupling or scheme selection. Computational prime1009
is diagnostic/certificate arithmetic,not a physical benchmark.
Review180s/8GiB sampled/350MiB launch/16MiB packet unchanged.
