# Separate regulator/source comparison review

Prospective after decomposition V2 completed41.910852s:all83160 exact
ordered-channel remainders zero,without fitting R from C/P. Verify this
is the actual affine field-change equation, not merely three UV zeros.

Independently form regulator bosonic matrices from F^T H0+H0F and
H0 L_J,where F/L_J are the actual affine field flow,then multiply the
external h=E^-1-1. Form the whole-source matrices from their open-index
source Euler products, with the correct source-JB kinetic cross. Use
the full block Gaussian/Woodbury inverse, retaining noncommuting color
order, all first-u/bu source and primitive forces. Compare every P/R
channel at all83160 positions at two computational heat/width embeddings;
the native exact remainder check remains required, not replaced by
these modular diagnostics. Reuse previously qualified finite Berezin
third-edge normalization and action/current/source checks by hashes.

Derive the explicit-u map analytically from the exact Gram matrix
i Tr(L_s ML_i),without dividing a coupling or fitting to WPC/WPG. Check
every41580 exact coefficient position against the independently measured
explicit map. The unprobed whole-source insertion vanishes in this
projection; its regulator mean response equals that explicit map. A
nonzero other-scope source product is not set zero globally.

Keep transported-vs-fixed primitive and the nonzero commutator companion
separate. The selected ordinary source j is0,so no jY term is hidden.
The formal Jacobian has zero rho/Ja derivative,not zero vacuum density.
The scope is a bounded formal one-loop identity,not a quantum measure
existence theorem,arbitrary local b/u,multiple-insertion QAP or E5.
Review180s/8GiB sampled/350MiB launch/16MiB packet unchanged.
