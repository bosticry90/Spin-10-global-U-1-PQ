from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
import gzip,json,os,sys,threading,time
import numpy as np
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
ONE=J.constant(1);I=J.I;Z=J.ZERO;half=J.constant(F(1,2))
def sc(c,n):return J.times(c,J.constant(n))
def plus(*Ps):
    out={}
    for P in Ps:J.add(out,P)
    return J.clean(out)
def scale(P,c):return J.clean({w:J.times(z,c) for w,z in P.items()})
def grade(P,g,strip=False):return J.clean({w:J.Coeff([((0 if strip else k[0],k[1],k[2],k[3]),z) for k,z in c.terms if k[0]==g]) for w,c in P.items()})
def act(P,X):
    out={};cache={}
    for w,c in P.items():
        for at,(n,js) in enumerate(w):
            if X.get(n):
                if (n,js) not in cache:cache[n,js]=J.Ds(X[n],js)
                for ww,z in cache[n,js].items():J.put(out,w[:at]+ww+w[at+1:],J.times(c,z))
    return J.clean(out)
def project(P,keepJL=False):
    return {w:c for w,c in P.items() if sum(553<=n<643 for n,js in w)<=2 and all(n<643 or 1241<=n<1286 or keepJL and 1151<=n<1196 for n,js in w)}
def dc(c):return J.Coeff([(tuple(k),F(n,d)) for k,n,d in c])
def old(c):return J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in c])
def mat(rows):return {(i,j):dc(c) for i,j,c in rows}
def mm(A,B):
    byrow=defaultdict(list)
    for (i,j),c in B.items():byrow[i].append((j,c))
    out={}
    for (i,k),c in A.items():
        for j,d in byrow[k]:out[i,j]=out.get((i,j),Z)+J.times(c,d)
    return {k:c for k,c in out.items() if c}
def wgt(M,weights):return {ij:J.times(weights[ij[0]],c) for ij,c in M.items() if J.times(weights[ij[0]],c)}
width=[J.Coeff([((0,0,1,0),F(1))]) if i<12 else J.Coeff([((0,1,0,0),F(1))]) for i in range(45)]
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[mat(z) for z in cov['symmetric_basis']+cov['skew_basis']]
flows=load(R/'calculations/canonical_so10_mixed_Ward_generator_transport/transport_tables_v2.json.gz')
flow={(r['mode'],r['family'],r['tensor']):{n:J.decode(p) for n,p in r['X']} for r in flows['cases']}
replay=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[1];S0=J.decode(replay['original'][0]['density'])
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz');Us=[grade(J.decode(p['qG']),0) for p in fj['probes']]
gf={n:grade(J.decode(p),0,True) for n,p in fj['GF_gradient']}
ML={};L={}
for a in range(45):
    ML[a]={}
    for w,c in gf[508+a].items():
        if len(w)==2 and 553<=w[0][0]<598 and 598<=w[1][0]<643 and all(not js for n,js in w):ML[a][w[1][0]-598,w[0][0]-553]=-c
    if a>=12:L[a]={ij:J.times(-I,c) for ij,c in ML[a].items()}
def ghost_operators(P):
    # LEFT auxiliary a Euler first: kinetic is -Kb box C; mass is M C.
    kin={};banks=[defaultdict(dict) for _ in range(3)]
    for a,z in J.euler(project(P),set(range(598,643))).items():
        for w,c in z.items():
            ghosts=[t for t in w if 553<=t[0]<598];bg=[t for t in w if not 553<=t[0]<598]
            assert len(ghosts)==1;cc=ghosts[0];ij=a-598,cc[0]-553
            if not bg:
                assert len(cc[1])==2 and cc[1][0]==cc[1][1]
                if cc[1]==(0,0):kin[ij]=kin.get(ij,Z)-c
            else:
                assert len(bg)==1 and not cc[1]
                n,js=bg[0]
                if n<180:
                    if n%4 or js!=(0,):continue
                    block=0;idx=n//4
                elif 508<=n<553 and not js:block=1;idx=n-508
                elif 1241<=n<1286 and not js:block=2;idx=n-1241
                else:raise AssertionError(('UNEXPECTED_REPLAY_GHOST_OPERATOR',n,js))
                banks[block][idx][ij]=banks[block][idx].get(ij,Z)+c
    return {ij:c for ij,c in kin.items() if c},[{i:{ij:c for ij,c in M.items() if c} for i,M in b.items()} for b in banks]
Uops=[ghost_operators(U)[1] for U in Us]
factory=load(O/'factory_tables.json.gz');verified={};whole_source_kinetic=0;spectators=0
for row in factory['rows']:
    pr,fam,tn=row['probe'],row['family'],row['tensor'];X0=flow['base',fam,tn];Xu=flow['Hcross' if pr==0 else 'Mcross',fam,tn]
    evS=act(S0,X0);evU=plus(act(Us[pr],X0),act(S0,Xu));Cr=[scale(grade(z,1,True),-ONE) for z in [evS,evU]]
    for order,C in enumerate(Cr):
        native=plus(J.decode(row['C'][order]['selected_density']),J.decode(row['C'][order]['spectator_source_density']))
        native=project(native,True);review=project(C,True)
        currents=[];V=basis[tn]
        for mu in range(4):
            current={}
            if fam=='A':
                for (i,j),c in V.items():
                    hit=i<12 if pr==0 else i>=12
                    rr=ONE if order==0 else width[i] if hit else Z
                    tt=width[i] if order==0 else sc(J.times(width[i],width[i]),F(1,2)) if hit else Z
                    W=plus(scale({((1151+i,()),):ONE},rr),scale({((598+i,()),):ONE},J.times(I,tt)))
                    J.add(current,scale(J.mul(W,{((553+j,(mu,)),):ONE}),J.times(I,c)))
            currents.append(current)
        div=plus(*(J.D(P,mu) for mu,P in enumerate(currents)))
        assert not plus(native,scale(review,-ONE),scale(div,-ONE)),('EVEN_ACTION_CURRENT_MISMATCH',pr,fam,tn,order)
    ops=[ghost_operators(C) for C in Cr]
    # Independent closed DK formula from DJLambda=-iOmega eps/2,
    # Da=eps,DJa=-eps L C, including the source-JLambda*C companion.
    Es=[]
    for order in [0,1]:
        Ts=[width[i] if order==0 else sc(J.times(width[i],width[i]),F(1,2)) if (i<12 if pr==0 else i>=12) else Z for i in range(45)]
        Rs=[ONE if order==0 else width[i] if (i<12 if pr==0 else i>=12) else Z for i in range(45)]
        Ebank={}
        for ss in range(12,45):
            bL=mm(V if fam=='B' else {},L[ss]);ghost=wgt(bL,Ts);expected={}
            for (i,j),c in ghost.items():J.put(expected,((553+j,()),(598+i,())),-c)
            for (i,j),c in wgt(bL,Rs).items():J.put(expected,((553+j,()),(1151+i,())),J.times(I,c))
            if order==0:
                for (i,j),c in V.items():
                    if i!=ss:continue
                    value=sc(J.times(width[ss],c),F(1,2))
                    if fam=='A':
                        for mu in range(4):J.put(expected,((4*j+mu,(mu,)),),value)
                    else:J.put(expected,((1241+j,()),),value)
            native=J.decode(row['DK_components'][order][str(ss)])
            assert J.clean(expected)==native,('DK_CLOSED_SOURCE_COMPANION_MISMATCH',pr,fam,tn,ss,order)
            Ebank[ss]=ghost;spectators+=sum(1151<=n<1196 for w in native for n,js in w)
        Es.append(Ebank)
    if fam=='A':
        Xsrc={n:p for n,p in X0.items() if 643<=n<823}
        pkin,_=ghost_operators(grade(act(S0,Xsrc),1,True));target=wgt(basis[tn],[-w for w in width]);assert pkin==target
        whole_source_kinetic+=bool(pkin)
    verified[pr,fam,tn]=(ops,Es)
print('STAGE separate even field/source action, explicit currents and all DK source companions',flush=True)
# Full block-matrix Gaussian inverse checks all color kernels. Modular
# arithmetic is a diagnostic in addition to the EXACT action proof above.
prime=1009;roots=[next(x for x in range(prime) if x*x%prime==v%prime) for v in [2,3,5,7,-1]]
assert all(x*x%prime==v%prime for x,v in zip(roots,[2,3,5,7,-1]))
ii=roots[4];eye=np.eye(45,dtype=np.int64);zero=np.zeros((45,45),dtype=np.int64)
assert 2025*(prime-1)**2<2**63 and 90*(prime-1)**2<2**63
def evaluator(xi,eta):
    @lru_cache(None)
    def f(c):
        out=0
        for (g,x,e,m),v in c.terms:
            assert g==0
            val=v.numerator*pow(v.denominator,-1,prime)*pow(xi,x,prime)*pow(eta,e,prime)
            for bit,rt in enumerate(roots):
                if m&(1<<bit):val=val*rt%prime
            out=(out+val)%prime
        return out
    return f
def arr(M,f):
    out=zero.copy()
    for (i,j),c in M.items():out[i,j]=f(c)
    return out
def tensor(bank,f):return np.stack([arr(bank.get(i,{}),f) for i in range(45)])
def dot(A,B):return (A@B)%prime
def mass(bank,X):
    y,ll=X[:45],X[45:];return (np.einsum('ir,ijk->rjk',y,bank[0])+np.einsum('ir,ijk->rjk',ll,bank[1]))%prime
def tr2(A,B):return np.einsum('sij,rji->sr',A,B)%prime
native=load(O/'kernel_tables.json.gz');bycase=defaultdict(list)
for r in native['complete_color_table']:bycase[r['probe'],r['family'],r['tensor']].append(r)
explicit=load(O/'explicit_tables_v3.json.gz');expcase=defaultdict(list)
for r in explicit['complete_color_table']:expcase[r['family'],r['tensor']].append(r)
def epoly(rows,E,f):return sum(pow(E,k,prime)*f(dc(c)) for k,c in rows)%prime
checks=0;explicit_checks=0;collapsed_heat_sensitive=0;companion_sensitive=0
for xi,eta,E in [(2,3,2*pow(7,-1,prime)%prime),(5,7,3*pow(11,-1,prime)%prime)]:
    f=evaluator(xi,eta);Om=np.diag([f(w) for w in width]);Ml=tensor(ML,f);Lt=np.stack([arr(L[i],f) for i in range(12,45)])
    G=E*np.block([[Om,-ii*eye],[-ii*eye,zero]])%prime
    F0=np.zeros((90,78),dtype=np.int64);F0[45:,:45]=-ii*eye;F0[:45,45:]=eye[:,12:];F0[45:,45:]=-ii*dot(Om,eye[:,12:])*pow(2,-1,prime);F0%=prime
    X0=-dot(G,F0)%prime
    for row in factory['rows']:
        pr,fam,tn=row['probe'],row['family'],row['tensor'];V=arr(basis[tn],f);A=V if fam=='A' else zero;B=V if fam=='B' else zero
        Pi=np.diag([int(i<12 if pr==0 else i>=12) for i in range(45)]).astype(np.int64)
        Hu=np.block([[-2*Pi,ii*dot(Om,Pi)],[ii*dot(Om,Pi),dot(dot(Om,Om),Pi)*pow(2,-1,prime)]])%prime
        Hb=np.block([[A+A.T,zero],[zero,zero]])%prime
        Fu=np.zeros((90,78),dtype=np.int64);Fu[:45,:45]=2*Pi;Fu[45:,:45]=-ii*dot(Om,Pi);Fu%=prime
        Fb=np.zeros((90,78),dtype=np.int64);Fb[:45,:45]=B-A.T;Fb[:45,45:]=dot(A.T,dot(Om,eye[:,12:]))*pow(2,-1,prime);Fb%=prime
        Xu=-dot(G,(dot(Hu,X0)+Fu)%prime)%prime;Xb=-dot(G,(dot(Hb,X0)+Fb)%prime)%prime
        # Independent expanded Woodbury/source formula, not native recursion.
        Xbu=(dot(dot(dot(G,Hu),G),(dot(Hb,X0)+Fb)%prime)+dot(dot(dot(G,Hb),G),(dot(Hu,X0)+Fu)%prime))%prime
        Fdk=np.zeros((90,78),dtype=np.int64);Fdk[:,45:]=Fb[:,45:];Xdk=-dot(G,Fdk)%prime
        ops,Es=verified[pr,fam,tn];Cb=[[tensor(b,f) for b in op[1]] for op in ops];Kb=[arr(op[0],f) for op in ops]
        Ub=[tensor(b,f) for b in Uops[pr]]
        original=lambda X:np.einsum('ir,ijk->rjk',X[45:],Ml)%prime
        v00=original(X0);v00[45:]=(v00[45:]+Lt)%prime
        vu=(original(Xu)+mass(Ub,X0))%prime;vu[:45]=(vu[:45]+Ub[2])%prime
        vb=(original(Xb)+mass(Cb[0],X0))%prime;vb[:45]=(vb[:45]+Cb[0][2])%prime
        vbu=(original(Xbu)+mass(Ub,Xb)+mass(Cb[0],Xu)+mass(Cb[1],X0))%prime;vbu[:45]=(vbu[:45]+Cb[1][2])%prime
        Ed=[np.stack([arr(e[s],f) for s in range(12,45)]) for e in Es]
        vb[45:]=(vb[45:]+Ed[0])%prime;vbu[45:]=(vbu[45:]+Ed[1])%prime
        vdk=original(Xdk);vdk[45:]=(vdk[45:]+Ed[0])%prime
        assert not np.any(v00[:45]) and not np.any(vu[45:])
        t0,tu,tb,tbu=[a[45:] for a in [v00,vu,vb,vbu]];j0,ju,jb,jbu=[a[:45] for a in [v00,vu,vb,vbu]]
        p22=-(tr2(t0,jbu)+tr2(tu,jb)+tr2(tb,ju)+tr2(tbu,j0))%prime
        p42=(tr2(np.matmul(t0,Kb[0])%prime,ju)+tr2(np.matmul(tu,Kb[0])%prime,j0)+tr2(np.matmul(t0,Kb[1])%prime,j0))%prime
        p24=(tr2(t0,np.matmul(ju,Kb[0])%prime)+tr2(tu,np.matmul(j0,Kb[0])%prime)+tr2(t0,np.matmul(j0,Kb[1])%prime))%prime
        companion=-tr2(vdk[45:],ju)%prime;fix=(p22-companion)%prime;unprobed=-tr2(t0,jb)%prime
        for r in bycase[pr,fam,tn]:
            s,rr=r['epsilon']-12,r['Ja']
            assert [epoly(r[name],E,f) for name in ['heat22','heat42','heat24','primitive_companion','fixed_primitive_heat22']]==[int(a[s,rr]) for a in [p22,p42,p24,companion,fix]]
            checks+=1
            collapsed_heat_sensitive+=int((int(p42[s,rr])*F(1,2).numerator*pow(2,-1,prime)+int(p24[s,rr])*pow(3,-1,prime))%prime!=(int(p42[s,rr])+int(p24[s,rr]))%prime)
            companion_sensitive+=int(companion[s,rr]!=0)
        if pr==0:
            for r in expcase[fam,tn]:assert epoly(r['heat22'],E,f)==int(unprobed[r['epsilon']-12,r['Ja']]);explicit_checks+=1
    print('STAGE full block Gaussian all-color modular action check '+str(xi)+' '+str(eta),flush=True)
assert checks==166320 and explicit_checks==83160 and collapsed_heat_sensitive>0 and companion_sensitive>0
# DIRECT finite Berezin Gaussian with two distinct momentum/heat nodes.
def add(a,b):
    out=dict(a)
    for k,c in b.items():out[k]=out.get(k,F(0))+c
    return {k:c for k,c in out.items() if c}
def times(a,b):
    out={}
    for (ma,ca),x in a.items():
        for (mb,cb),y in b.items():
            if ma&mb or ca&cb:continue
            sign=(-1)**sum((mb&((1<<i)-1)).bit_count() for i in range(10) if ma&(1<<i))
            k=ma|mb,ca|cb;out[k]=out.get(k,F(0))+sign*x*y
    return {k:c for k,c in out.items() if c}
def word(ids,c=F(1),marks=0):
    out={(0,marks):F(c)}
    for i in ids:out=times(out,{(1<<i,0):F(1)})
    return out
Lx=[[1,2],[-1,1]];Nx=[[2,-1],[1,3]];Rx=[[0,1],[2,-1]];Tx=[[1,-2],[3,1]];Kx=[[1,1],[0,2]]
S={}
for i in range(4):S=add(S,word([4+i,i],4 if i<2 else 9))
for i in range(2):
    for j in range(2):
        S=add(S,word([8,9,4+2+i,j],Lx[i][j]));S=add(S,word([4+i,2+j],Nx[i][j],6))
        S=add(S,word([8,9,4+2+i,j],Rx[i][j],1));S=add(S,word([4+i,2+j],Tx[i][j],7))
        S=add(S,word([4+i,j],2*Kx[i][j],1));S=add(S,word([4+2+i,2+j],3*Kx[i][j],1))
power={(0,0):F(1)};exp=power
for n in range(1,5):power=times(power,{k:-c/n for k,c in S.items()});exp=add(exp,power)
zz={(mask^255,marks):c for (mask,marks),c in exp.items() if mask&255==255};z0=zz.pop((0,0));zz={k:c/z0 for k,c in zz.items()}
power={(0,0):F(1)};log={}
for n in range(1,5):power=times(power,zz);log=add(log,{k:c*F((-1)**(n+1),n) for k,c in power.items()})
mm2=lambda A,B:[[sum(A[i][k]*B[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
trace=lambda A:sum(A[i][i] for i in range(2))
pair=F(-1,36)*(trace(mm2(Lx,Tx))+trace(mm2(Rx,Nx)))
third=F(1,72)*trace(mm2(mm2(Lx,Kx),Nx))+F(1,108)*trace(mm2(mm2(Lx,Nx),Kx))
actual=log[768,7];assert actual==pair+third and third!=0
collapsed=F(1,36)*(trace(mm2(mm2(Lx,Kx),Nx))+trace(mm2(mm2(Lx,Nx),Kx)))
assert pair+collapsed!=actual
# Asymmetric scalar heat bubble: independent x and Schwinger-ratio routes.
mp.mp.dps=38;errs=[]
for a,b in [(2,2),(4,2),(2,4)]:
    z=mp.mpf('0.3');cross=mp.mpf(a)/(a+b)
    xroute=mp.quad(lambda x:mp.e1(z*max(a*(1-x),b*x)),[0,cross,1])
    ratio=mp.quad(lambda w:(mp.exp(-z*a/(1+w))-mp.exp(-z*a/w))/ (z*a),[0,mp.mpf(a)/b])
    errs.append(str(abs(xroute-ratio)));assert abs(xroute-ratio)<mp.mpf('1e-30')
    zz=mp.mpf('1e-12');asym=mp.quad(lambda x:mp.e1(zz*max(a*(1-x),b*x)),[0,cross,1])
    assert abs(asym+mp.log(zz)+mp.euler-1+mp.log(a+b))<mp.mpf('1e-10')
out={'schema':'WPT_SEPARATE_ACTION_GAUSSIAN_BEREZIN_REVIEW','evidence_validation':'PASS_LEADING_COMMON_PARENT_REFERENCE_TRANSPORT',
 'exact_even_action_current_and_source_cases':56,'DK_full_source_components_per_case':66,'whole_JB_source_kinetic_cross_cases':whole_source_kinetic,
 'spectator_source_cells_checked':spectators,'modular_all_color_cross_checks':checks,'modular_explicit_u_checks':explicit_checks,
 'prime':prime,'prime_is_computational_not_physical':True,'numpy_int64_overflow_bound_checked':True,
 'collapsed_third_heat_controls_sensitive_modular_positions':collapsed_heat_sensitive,'primitive_companion_sensitive_modular_positions':companion_sensitive,
 'finite_Berezin_ordered_result':str(actual),'finite_Berezin_third_edge_contribution':str(third),'asymmetric_heat_route_errors':errs,
 'asymmetric_finite_shift':'Pi42-Pi22=-log(3/2)/(16*pi^2)','reference_UV_FP_then_IR_zero':True,
 'generic_field_Jacobian_not_set_zero':True,'physical_finite_delta_or_full_Ward_QAP_E5_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
