# Complete selected affine field/source/regulator equation

Review V2 completed39.545341s:exact even-action/current/source checks,
full DK source companions,166320 cross/83160 explicit modular checks,
direct Berezin third-edge normalization19/216,asymmetric heat master.
This still must not substitute a zero limit for the whole identity.

For S_rho=S+uQG+rho KD and the actual even affine field/source flow X,
C_rho=C+rho DK=-X S_rho modulo the retained current. Define the WHOLE
source product P_rho=sum(XJ)(S_rho)_J BEFORE restricting sources, and
the regulator insertion R_X=Y Sreg with Y=Xfield. At ordinary j=0,
the finite-coordinate field-change equation gives, at one loop and
rho/Ja degree, delta_C W1+delta_P W1-delta_R W1=0 because the generic
field-divergence density is source independent. It is not assumed zero
as a functional. Derive every group independently; never set R=C+P.

Compute P0/P1 from actual source flow applied to full primary S0/U0,
and its primitive companion from Xsource KD. Derive R_X independently
by applying actual YLambda/Ya to the complete fixed free regulator,
including source-affine YLambda and the u-dependent flow. The external
inverse heat h(E)=E^-1-1 must cancel against its own mean inverse.
For a ghost kinetic root h(E_q), combine the adjacent propagators FIRST:
E_q^2 h(E_q)=E_q-E_q^2. Keep the resulting heat22/42/24 words ordered.

Use a general quadratic-parent stationary recursion (including all
bu Hessian and source/primitive forces); recompute native C through
this independent general engine as a control. Evaluate all83160
positions, record complete nonzero remainders if any. Scalar heat42
and24 are equal only after an explicit convergent momentum relabeling;
do not silently commute color matrices. Qualify the full equation only
if its independently derived coefficients vanish (possibly using that
proved scalar relation), not merely because all groups have zero UV FP.

No enlarged scope of physical fields, no finite A/baseline choice or
full Ward/QAP/measure/E5 promotion. Native180/review180s,8GiB sampled/
350MiB launch/16MiB packet unchanged. Preserve exact failed remainders.
