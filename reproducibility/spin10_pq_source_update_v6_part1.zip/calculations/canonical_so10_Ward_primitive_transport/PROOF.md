# Correlated finite-generator transport of the Ward primitive

## Scope and the two different loop orders

Work at the original unshifted Euclidean A0, intrinsic degree0/1, first
probe u, first formal constant b, and leading gauge degree1 in b. The
marked source is theta_s=rho epsilon_s, s12..44; Ja has all45 directions.
rho and epsilon are odd; theta is even and Schwartz smeared. Ordinary
sources j are zero in this selected construction. No constant-vacuum,
local-b or multiple-rho limit is taken. All14 A and14 B tensor directions
of MWN/MWX are retained. Independent explicit-u A1/B1 use the unprobed
map by degree counting, not a physical parameter specialization.

Let Omega=diag(eta_H,xi), S=Omega Pi, Y=div Bfield at A0, and

    K_u=-i g10 [(1+uS)JLambda+i Omega(1+uS/2)a]^T(A Y+B Ja),
    C_u=Q_u K_u, E_u=Dminus K_u,
    S_rho,b=S+uQG+b C_u+rho(KD+b E_u).

Because K carries g10, only the actual g0 action and operations enter
this leading transport coefficient. Original g1 vector/scalar/matter
links would cost g2. This is a coupling argument for this target, not
a general removal of those sectors. The hatted-curvature qualification
from MGT remains: q^2=(Ihat,.), not global nilpotence. Its restricted
zero conjugate-port pairing with K/G is unchanged.

For UNIT b, the new quantum response is hbar*b*g10. If b C is instead
an order-hbar counterterm, that LOOP response enters hbar2*b*g10 at
fixed cutoff. Its CLASSICAL source/mean/contact response already enters
hbar*b*g10. The latter cannot be inferred from a zero loop finite part.
Neither order counting nor this calculation interchanges nonuniform
cutoff limits or selects a physical subtraction condition.

## Actual action and primitive factories

Full actual Q and QG act before source restriction. No false full
doublet identity for JLambda+iOmega a is assumed:66 nonlinear qW
remainder components are retained across the two probes. The factory
keeps the spectator source density and excluded quartic-ghost counts,
as well as all selected bosonic and ghost-background terms. Quartic
ghost Hessians vanish only at this zero ordinary-ghost mean. Sources
are external and are not integrated as Gaussian fields.

The measured bosonic part of C, with g10 extracted, is

    C_even=(Y-J)^T(A Y+B J), J=Ja,

with no first-u bosonic correction for fixed A0/B0. Its ghost kinetic
matrix is T(A+B), T=Omega(1+uS/2), and its actual ghost-background
matrices are stored rather than replaced by the linear doublet.
Complete derivative/Lorentz reconstruction checks every selected word.

The actual canonical D has Da=epsilon, DJLambda=-iOmega epsilon/2 and
DJ_a=-sum_s epsilon_s L_s C, where L_s is WPC's primitive ghost matrix.
Consequently the independently checked DK component has

    E_s,even=Omega_s (A Y+B J)_s/2,
    E_s,ghost=a^T T B L_s C,
    E_s,spectator=+i sum_(i,c) (R B L_s)_ic C_c JLambda_i,
    R=1+uS.

Its bosonic first-u cross correction is zero. The JLambda*C companion
and all zero components remain in the factory, even though the selected
Ja/epsilon derivative has JLambda=0. Discarding it would not define a
full operator completion. The primitive is dimension2 after extracting
epsilon, with the actual local auxiliary-module carriers; this does not
by itself establish every finite mixing or physical-reality condition.

## Independently constructed whole-source and regulator equation

Write X=(K,.) and Yfield=Xfield. It is affine in quantum fields, so
its second field derivative vanishes. Exact canonical action identities
give, with all sources retained,

    C_rho=-X S_rho mod div(current),
    C_rho+P_rho=-Yfield S_rho,
    P_rho=sum_J (XJ)(S_rho)_J.

P is a WHOLE product. It is not (XJ at its mean) times Gamma_J. The
separate review reconstructs C as minus the EVEN variation of the
replay action, independently of native QK. It verifies the explicit
current i g W^T A Q B_mu before the selected restriction. For example,
the source-JB cross has ghost kinetic matrix -T A, although its mean
coefficient is zero on this source plane. Factoring the source product
would miss that entire contribution. The source-Ja product and its
primitive companion are also included.

The regulator insertion is constructed independently as

    R_X=Yfield Sreg.

In the longitudinal bosonic sector, H0=[[0,iI],[iI,Omega]] and
G0_t=E H0^-1. If Yfield=F x+L_J J, its regulator quadratic and source
matrices are h(E)(F^T H0+H0F) and h(E)H0 L_J, h=E^-1-1. This is
the independent review construction, not R_X defined from C+P.
The ghost regulator kinetic matrix is -T B times h(E_q). The affine
Ja part of YLambda is retained in the source force.

At ordinary j=0, finite-coordinate change of variables gives

    delta_C W1+delta_P W1-delta_R W1=0

in the theta/Ja coefficient. The generic formal field superdivergence
g Tr(B^T T) is NOT zero; its rho/Ja derivatives are zero because its
local vacuum density is source independent. The sources are external,
so its full field-plus-source coordinate trace must not be substituted
for the field Jacobian. MGT's nonzero finite-IR vacuum diagnostic remains.
This finite-coordinate argument is transferred only to the explicitly
constructed one-loop positive-heat coefficient below, not to a general
continuum measure or Pfaffian phase.

The actual C, whole P and R are separately computed at all83160
generator/direction/color/probe positions. Their exact remainders vanish
SEPARATELY in the heat22,heat42,heat24 channels. Equality of asymmetric
scalar integrals is therefore not used to hide an ordered remainder.
No unknown quantum contact or RHS was fitted to enforce the identity.

## Ordered quantum kernels and the third edge

The common bosonic parent is quadratic in Y,Lambda and affine in each
source. Full b/u source means follow its one inverse, including bu
Hessians, source forces and primitive forces. Its mixed theta/Ja mean
is zero by these stationary equations, not by a chosen quantum tadpole.
Scalar/matter blocks are disconnected at this leading b*g1 grade.

The actual baseline ghost vertices obey the matrix identities

    M_theta=(1-E)L_s, M_Ja=0,
    M_u,theta=0,
    M_u,Ja=-2i Pi_r (1-E)^2 M_Lambda_r.

They are checked from the actual source/probe action, including the
changed auxiliary mean and direct source vertex. The b-deformed
vertices are derived from the full C/E factories and measured means;
no tensor is commuted through Omega or Pi. They are bounded polynomials
in E. All external inverse heats in R cancel against their own inverse
responses before a limit or source restriction is used.

Two marked vertices give a heat22 bubble. An UNMARKED b ghost-kinetic
insertion gives a third inverse edge. Canceling its q^2 leaves E_q^2,
not E_q. The ordered coefficients contain both

    Tr(M_theta K_b M_uJa) Pi_42,
    Tr(M_theta M_uJa K_b) Pi_24.

They cannot be combined by commuting matrices. For the regulator root,
combine adjacent inverses first: E_q^2 h(E_q)=E_q-E_q^2. This yields
Pi_22-Pi_42 (and the opposite-edge Pi_22-Pi_24), entirely in positive
heats. The independently derived source and regulator groups satisfy
the equation above, including these terms.

The actual cross catalog has455 nonzero heat22 positions,790 in each
asymmetric channel,604 nonzero primitive-companion positions and623
fixed-primitive heat22 positions. All83160 positions, including zeros,
are recorded. The independent explicit-u map has41580 positions,323
nonzero. These counts measure coverage, not physical truth.

A direct finite Berezin calculation with four ghost pairs, two unequal
loop heats, separate odd rho/epsilon and commuting b/u/J markers gives
19/216. Its third-edge part is55/216; dropping it or collapsing its
heat changes the answer. This tests the action/determinant sign and
cyclic weights rather than two uses of one Hessian convention.

## Asymmetric heat master and common limits

For positive a,b,

    Pi_ab=integral d4q/(2pi)^4 exp(-a t q^2-b t(q+p)^2)
                         /[q^2(q+p)^2]
         =integral_0^1 dx E1(t p^2 max(a(1-x),b x))/(16pi^2).

Separate Schwinger-ratio and x integrals agree for22,42,24. The UV
finite reference expression is

    [log(mu^2/p_E^2)-gamma_E+1-log(a+b)]/(16pi^2).

In particular Pi_42-Pi_22 has finite shift -log(3/2)/(16pi^2), despite
the same leading logarithm. It is retained in the calculation. All
actual channel coefficients vanish at E=1, so these logarithms and
finite constants do not leave a selected reference finite transport.
Finite heat responses remain nonzero and distinguish fixed from
transported primitive. A UV zero alone would be an insensitive check.

At fixed t the source-paired kernels have the same locally-integrable
joint bubble domain as WPC, with no uncanceled external denominators.
All heats are positive after the explicit adjacent cancellations.
Thus the selected equation is a common distributional identity on
Schwartz directions, not a value assigned at p=0.

For f_delta=(1-exp(-p^2/delta^2))^2, the auxiliary Gaussian fE G0 has
H_t(fE G0)=f I, not the physical fixed-R inverse identity. The finite
1-f source/inverse defects remain. Its regulator root uses its own
reference; converting back to physical fixed R leaves those explicit
defects. Combining their own adjacent edges removes inverse f/heats.
External defects contain1-f; loop-localized defects multiply the
baseline (1-f) primitive/source roots. After the common parent UV
subtraction, p=delta v gives the same O(delta^4(1+abs(log delta)))
Schwartz bound as the logarithmic WPC bubble. Different fixed positive
heat widths change its finite constant, not this bound. No finite-delta
physical Ward identity, arbitrary product limit or critical p^-4 IR
contact removal is claimed. Tree maps below have bounded polynomial
limits and do not add an IR normalization choice.

## The finite contact which the loop calculation alone does not settle

An order-hbar b C changes the one-loop FINITE normalization through
its classical connected source response. Derive it from

    W0_theta,Ja=Ftheta^T H^-1 FJ-(direct theta,Ja contact),

including the measured C and E and the entire mixed inverse. For the
unprobed/independent explicit-u generator coefficient, the result at
E=1 is

    transported primitive: 0,
    fixed primitive:       Delta chi= P_M Omega(A+B)/2,
    DK companion:          -P_M Omega(A+B)/2.

The first-u cross of the base generator has zero limit in both forms.
Thus the same nonzero shift law applies separately to A0/B0 and to
the independently normalized A1/B1. At finite E all mean and contact
terms are retained; the full tree table is independently checked by
a Schur-complement/Woodbury calculation rather than native recursion.

For a symbolic effective primitive normalization Z, preserving a
specified connected contact baseline would require

    Delta Z_effective=P_M Omega(A+B)/2

with the COMPLETE correlated DK completion. This is a transport law,
not a selected value for Z or a new physical scheme. The affine Y term,
direct Ja contact, ghost aC term and JLambda*C companion belong together.
Replacing them by an isolated source-only contact would not establish
the source/Slavnov compatibility of the full extension. Z is not
identified with kappa,b0,chi4 or an infrared constant.

If BOTH the primitive and that contact baseline were instead required
to remain unchanged, this selected test would impose ONLY

    P_M(A+B)=0.

It does not impose A+B=0 on all45 rows. The actual1485x14 restricted
tensor map has rank10 and a4-dimensional kernel. Exact real Gram
kernel vectors plus a direct splitting-prime lower bound certify it;
no physical width is specialized or divided. The factor xi/2 is an
injective polynomial monomial on the broken rows. The conditional
generator family therefore has18 directions. Its selected quadratic
core has13, with the existing5 projected-null directions retained as
possibly nonzero full functionals. This condition is NOT imposed on
the theory. Other finite operator mixings or simultaneous normalization
conditions can change which family is admissible.

For fixed KD the finite-heat equation must retain the commutator
companion: delta_Cfixed W1+delta_P W1-delta_R W1+delta_DK W1=0.
The companion is generally nonzero at finite heat and in the tree
finite normalization. No Dminus C=0 equation is invented.

## Verification, failures and remaining bridge

Native factory15.575982s; cross kernels16.190918s; explicit V3
15.629911s. Review V2 took39.545341s and checks exact action/current
and9624 spectator-source cells, with166320 cross and83160 explicit
computational block-matrix comparisons. The exact direct action
identities and analytic resolvent proof, not modular samples alone,
support the general statement. Prime1009 is computational, not a
physical benchmark; int64 overflow bounds are checked.

Whole-source/regulator decomposition V2 took41.910852s; its separate
review42.875841s derives R from F^T H0+H0F and checks all ordered
remainders plus the exact41580 Gram-derived explicit coefficients.
Tree computation10.855911s and separate review26.474649s verify all
166320 Schur comparisons, exact kernel vectors and independent ranks.
Controls removing the primitive field companion or its source contact
are each sensitive in860 computational comparisons. The isolated
Ja^2 term in C need not affect this particular projection; no claim
that this control validates every source-only term is made.

Explicit V1 and V2 each exhausted180s, raw FAILED/exit124, mathematical
status INCOMPLETE_RESOURCE_LIMIT. V3 reused each Ja vertex across33
epsilon colors and completed without increasing the limit. Review V1
was launched prematurely, passed only its initial action assertions,
then failed on the missing prerequisite table. Decomposition V1 failed
on a missing frozen encoder binding. All exact sources/captures/controller
records remain; none is counted PASS. Later versions do not rewrite
their contracts or byte bindings.

This constructs a bounded common reference field/source/regulator
transport identity and an explicit finite-contact compensation law.
It supplies new quantum information for the existing finite family;
it does not choose a baseline or prove the full simultaneous fixed-D
renormalization prescription. First Slavnov descendants of the marked
parent, all allowed mixing/reality conditions, broader products and
measure/phase remain. The next discriminating step is that joint
source/Slavnov compatibility test using the measured law and full DK,
not automatic g2 or295-profile expansion. Shared action/chart/regulator,
exact libraries and AI authorship remain shared-error limits. No
external verification, new experimental support, E5/A5 or physical
Spin(10) viability is claimed.
