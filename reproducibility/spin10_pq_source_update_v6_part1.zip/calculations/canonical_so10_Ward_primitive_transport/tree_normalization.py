from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,gzip,json,os,sys,threading,time
import sympy as sym
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
from coefficient_ring import expression,coefficient
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'tree_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I;half=J.constant(F(1,2));mul=J.times
names={'encode','sc','decode','decode_old','mp','madd','msm','transpose','pa','ps','pm','pe','pp','ev1','encp','mv','va','compact','expand_compact','parse','parseE'}
tree=ast.parse((O/'kernels.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert {n.name for n in nodes}==names
exec(compile(ast.Module(body=nodes,type_ignores=[]),'frozen-exact-helpers','exec'))
width=[J.Coeff([((0,0,1,0),F(1))]) if a<12 else J.Coeff([((0,1,0,0),F(1))]) for a in range(45)]
cov=load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz');basis=[mp(z) for z in cov['symmetric_basis']+cov['skew_basis']]
rows=[];shift_nonzero=0;factory=load(O/'factory_tables.json.gz')
for row in factory['rows']:
    pr,fam,tn=row['probe'],row['family'],row['tensor'];V=basis[tn];A=V if fam=='A' else {};B=V if fam=='B' else {}
    M=madd(A,transpose(A));N=madd(B,msm(transpose(A),-ONE));selected=[a<12 if pr==0 else a>=12 for a in range(45)]
    C0=parse(J.decode(row['C'][0]['selected_density']))[0];C1=parse(J.decode(row['C'][1]['selected_density']))[0];assert not C1
    E=[{int(s):parseE(J.decode(p))[0] for s,p in row['DK_components'][up].items()} for up in [0,1]]
    def inverse(force):
        yy,ll=force;oy={};ol={}
        for i in set(yy)|set(ll):oy[i]=ps(pe(pa(ps(yy.get(i,{}),width[i]),ps(ll.get(i,{}),-I))),-ONE);ol[i]=ps(pe(yy.get(i,{})),I)
        return {i:P for i,P in oy.items() if P},{i:P for i,P in ol.items() if P}
    def hu(x):
        yy,ll=x;fy={};fl={}
        for i in set(yy)|set(ll):
            if not selected[i]:continue
            fy[i]=pa(ps(yy.get(i,{}),-2*ONE),ps(ll.get(i,{}),mul(I,width[i])))
            fl[i]=pa(ps(yy.get(i,{}),mul(I,width[i])),ps(ll.get(i,{}),mul(mul(width[i],width[i]),half)))
        return fy,fl
    def addforce(x,y):return va(x[0],y[0]),va(x[1],y[1])
    def primitive(bs,x,r,sourcecontact):
        out={}
        for n,c in bs.items():
            if n<45:out=pa(out,ps(x[0].get(n,{}),c))
            elif n<90:out=pa(out,ps(x[1].get(n-45,{}),c))
            elif sourcecontact and n==90+r:out=pa(out,pp(c))
        return out
    means={}
    for r in range(45):
        x0=({r:{1:ONE}},{});xu=inverse(addforce(hu(x0),({r:pp(2*ONE)},{r:pp(mul(-I,width[r]))}) if selected[r] else ({},{})))
        xb=inverse((va(mv(M,x0[0]),{i:pp(c) for (i,j),c in N.items() if j==r}),{}))
        xbu=inverse(addforce(hu(xb),(mv(M,xu[0]),{})));means[r]=[x0,xu,xb,xbu]
    for s in range(12,45):
        for r in range(45):
            x0,xu,xb,xbu=means[r]
            comp0=ps(primitive(E[0][s],x0,r,True),-ONE)
            compu=ps(pa(primitive(E[0][s],xu,r,False),primitive(E[1][s],x0,r,True)),-ONE)
            field=lambda x:pa(x[0].get(s,{}),ps(x[1].get(s,{}),sc(mul(-I,width[s]),F(1,2))))
            tr0=pa(ps(field(xb),-ONE),comp0);tru=pa(ps(field(xbu),-ONE),compu)
            fix0=pa(tr0,ps(comp0,-ONE));fixu=pa(tru,ps(compu,-ONE))
            expected=sc(mul(width[s],A.get((s,r),Z)+B.get((s,r),Z)),F(1,2))
            assert ev1(tr0)==ev1(tru)==ev1(fixu)==Z and ev1(fix0)==expected and ev1(comp0)==-expected
            shift_nonzero+=bool(expected)
            rows.append({'probe':pr,'family':fam,'tensor':tn,'epsilon':s,'Ja':r,'transported_base':encp(tr0),'fixed_base':encp(fix0),
             'companion_base':encp(comp0),'transported_cross':encp(tru),'fixed_cross':encp(fixu),'companion_cross':encp(compu),
             'fixed_base_finite_contact':encode(expected)})
    print('STAGE classical contact transport '+str(pr)+' '+fam+str(tn),flush=True)
# Rank of the actual broken-row restriction, with no width specialization.
# The common nonzero xi/2 is a symbolic monomial, so extracting its
# coefficient does not divide a physical functional or choose xi's value.
restricted=[{(i,j):c for (i,j),c in V.items() if i>=12} for V in basis]
Gram=[]
for U in restricted:
    row=[]
    for V in restricted:row.append(sum((mul(c,V.get(ij,Z)) for ij,c in U.items()),Z))
    Gram.append(row)
Gsym=sym.Matrix([[expression(c.terms) for c in r] for r in Gram]);null=Gsym.nullspace();rank=14-len(null)
vectors=[]
for vec in null:
    co=[coefficient(sym.simplify(z)) for z in vec];actual={}
    for cc,V in zip(co,restricted):
        for ij,c in V.items():actual[ij]=actual.get(ij,Z)+mul(cc,c)
    assert not any(actual.values());vectors.append([encode(c) for c in co])
prime=1009;roots=[next(a for a in range(prime) if a*a%prime==z%prime) for z in [2,3,5,7,-1]]
def mod(c):
    out=0
    for (g,x,e,m),v in c.terms:
        assert g==x==e==0
        z=v.numerator*pow(v.denominator,-1,prime)%prime
        for bit,a in enumerate(roots):
            if m&(1<<bit):z=z*a%prime
        out=(out+z)%prime
    return out
mat=[[mod(c) for c in r] for r in Gram];rr=0
for col in range(14):
    pivot=next((i for i in range(rr,14) if mat[i][col]),None)
    if pivot is None:continue
    mat[rr],mat[pivot]=mat[pivot],mat[rr];iv=pow(mat[rr][col],-1,prime);mat[rr]=[a*iv%prime for a in mat[rr]]
    for i in range(14):
        if i!=rr and mat[i][col]:factor=mat[i][col];mat[i]=[(a-factor*b)%prime for a,b in zip(mat[i],mat[rr])]
    rr+=1
assert rr==rank
blob=gzip.compress((json.dumps({'complete_color_table':rows,'restriction_Gram':[[encode(c) for c in r] for r in Gram],
 'restriction_kernel_in14_coordinates':vectors},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'tree_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPT_CLASSICAL_FINITE_CONTACT_NORMALIZATION_MAP','complete_cross_color_positions':len(rows),'nonzero_fixed_primitive_contact_positions':shift_nonzero,
 'transported_and_fixed_cross_limits_zero':True,'fixed_unprobed_and_explicit_u_contact':'P_M*Omega*(A+B)/2',
 'baseline_not_chosen':'delta_Z_effective=P_M*Omega*(A+B)/2 with full DK companions','conditional_zero_shift_condition':'P_M*(A+B)=0 ONLY if primitive and contact baseline held fixed',
 'actual_restricted_tensor_map_rank':rank,'exact_restriction_kernel_dimension':len(null),'modular_lower_bound':rr,'prime':prime,
 'conditional_generator_dimensions':28-rank,'conditional_selected_core_dimensions':23-rank,'projected_core_kernel_five_not_quotiented_physically':True,
 'condition_imposed_on_theory':False,'full_finite_prescription_Ward_QAP_E5_claim':False,'table_sha256':sha256(blob).hexdigest(),
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'tree_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
