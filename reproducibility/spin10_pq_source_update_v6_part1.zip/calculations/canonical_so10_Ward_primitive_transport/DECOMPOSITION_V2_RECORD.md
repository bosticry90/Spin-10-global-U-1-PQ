# Decomposition V2: include the frozen coefficient encoder

The first decomposition run FAILED after its first tensor case because
the AST helper selection omitted encode, which encp needs when a
nonzero channel is serialized. No complete decomposition table/result
was written. Preserve the exact source, partial stage, capture and
controller failure. This is a missing helper binding, not a quantum
coefficient mismatch. V2 adds only that existing frozen function to the
selected helpers and new versioned input/output names. No mathematical
condition or180s/8GiB/350MiB/16MiB resource limit changes.
