from pathlib import Path
O=Path(__file__).resolve().parent
src=(O/'decomposition.py').read_text();assert src.count("names={'sc','decode'")==1
src=src.replace("names={'sc','decode'","names={'encode','sc','decode'")
src=src.replace("O/'decomposition_preparation.json'","O/'decomposition_preparation_v2.json'").replace("O/'decomposition_tables.json.gz'","O/'decomposition_tables_v2.json.gz'").replace("O/'decomposition_result.json'","O/'decomposition_result_v2.json'")
with(O/'decomposition_v2.py').open('xb') as f:f.write(src.encode())
src=(O/'run_decomposition.py').read_text().replace("['DECOMPOSITION_RECORD.md','decomposition.py','run_decomposition.py']","['DECOMPOSITION_V2_RECORD.md','make_decomposition_v2.py','decomposition_v2.py','run_decomposition_v2.py']")
src=src.replace("dump(O/'decomposition_preparation.json'","dump(O/'decomposition_preparation_v2.json'").replace("O/'decomposition.py'","O/'decomposition_v2.py'")
src=src.replace("O/'decomposition_capture.json'","O/'decomposition_capture_v2.json'").replace("C/'decomposition_full_capture.json'","C/'decomposition_full_capture_v2.json'").replace("O/'decomposition_controller_failure.json'","O/'decomposition_controller_failure_v2.json'")
with(O/'run_decomposition_v2.py').open('xb') as f:f.write(src.encode())
