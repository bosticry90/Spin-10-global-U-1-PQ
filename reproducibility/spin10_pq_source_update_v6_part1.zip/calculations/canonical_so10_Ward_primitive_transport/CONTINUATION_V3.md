# WPT V3: reuse source vertices before color contractions

Explicit V2 also exhausted180s (exit124,raw FAILED; mathematical outcome
INCOMPLETE_RESOURCE_LIMIT), with19/28 stage messages. Loading the input
once fixed redundant decoding but exposed a second repeated-work error:
the Ja vertex was recomputed for every epsilon color even though it is
independent of that color. This is a loop-organization failure, not a
scientific incompatibility. Do not enlarge the timer or truncate colors.

V3 computes each45 source vertex once per tensor, then contracts it
against all33 independent primitive roots. It preserves the identical
action-derived expression and all41580 positions, reducing that repeated
work by33. Both previous sources/captures/controller failures remain
immutable and incomplete, not PASS. This is a structural correction
under the standing delegation, not a replay with increased resources.

Review V2 is frozen/launched ONLY after explicit V3's completed capture,
hash and full output count are inspected. It changes the old review's
input/output/preparation names to new versions and adds the precondition;
all mathematical assertions remain.180s/8GiB/350MiB/16MiB unchanged.
