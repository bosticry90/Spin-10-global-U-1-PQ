# WPT separate action, source-product and Gaussian review

Prospective after native factories/kernels. Independently reconstruct C
as minus the EVEN canonical field/source variation of the replay action,
not another QK implementation. Retain field and source parts separately,
and verify their explicit IBP current against native C before restriction.
Use actual MGT field/source flow columns. The source-JB derivative cross
is a whole product even when its mean coefficient is zero; test that its
ghost kinetic contribution cannot be omitted. Do not infer a factorized
source identity from a zero mean.

Derive ghost matrices by LEFT action Euler derivatives before Fourier
reduction. Check DK affine,ghost and JLambda*C source companions against
the independent open-index expression from the actual D vector field.
Keep all14+14 tensor directions and both probe cross modes, including
noncommutation with Pi/Omega. Use the complete quadratic parent in a
separate block-matrix Woodbury inverse. Check every83160 cross and41580
explicit-u color position at two nondegenerate computational embeddings
of heat/width coefficients modulo the splitting prime1009. These are
diagnostics, not physical parameter choices or the sole proof of an
exact identity: exact action/current checks and the analytic graded
resolvent proof supply the mathematical bridge. Bound int64 arithmetic.

Test the determinant sign and third-edge normalization by DIRECT finite
Berezin integration, with separate odd rho/epsilon and commuting first-
order b,u,J markers. Preserve two unequal loop heats and noncommuting
color matrices. A collapsed-third-heat control and omitted primitive
companion/source cross must be sensitive at finite regulator. Check the
asymmetric heat bubble independently and retain its finite log(3/2)
shift; a UV pole check alone is insufficient.

Prove the common UV-FP-then-IR limit from actual external heat roots,
retaining nonzero finite-profile terms and1-f inverse/source defects.
Keep generic Jacobian vacuum density and fixed-vs-transported operator
distinction. No full finite-A mixing,QAP,measure,E5 or physical claim.
Review180s afterimports,8GiB sampled/350MiB launch/16MiB packet unchanged.
