# WPT ordered kernel calculation

Factory completed15.575982s:all56 actual generator/probe cases,full Q/QG
nonlinear remainders retained (66 qW components),C/DK/source companions
stored. This is not yet quantum compatibility.

Parse each measured C into its complete quadratic bosonic y/Lambda/Ja
form, ghost kinetic p2 matrix and ghost-background matrices; reconstruct
the original selected density to verify every derivative/Lorentz port.
Likewise parse every DK component, retaining its JLambda*C spectator.
Test rather than assume the proposed bosonic core and zero first-u core.
No arbitrary tensor is commuted through Omega or Pi.

Derive all b/u source means by the SAME free mixed inverse and measured
quadratic parent, including primitive affine shifts/source-only contacts.
At this b*g1 coefficient the even bosonic parent is quadratic:prove its
mixed theta/Ja mean zero from stationarity, not from quantum tadpoles.
Actual originalg1/scalar links cost another gauge power and are excluded
only from this leading transport coefficient.

Calculate every28x2x33x45=83160 direction/color/probe position, including
zeros. Keep distinct positive-heat22 bubble and heat42/24 kinetic-insertion
channels and the independently derived DK companion. Compute transported
and fixed-primitive responses separately. Preserve any nonzero finite
remainder; do not define a source/contact RHS to cancel it. UV root tests
must follow actual coefficient derivation. A proof based on a heat root
does not justify dropping finite-heat terms or generic formal Jacobians.

Native180s,8GiB sampled/350MiB launch/16MiB packet unchanged. Arbitrary
additional finite-parent A and operator-mixing baselines stay symbolic.
Unitb response is orderhbar*b*g1; orderhbar counterterm response starts
orderhbar2*b*g1 at fixed cutoff. No full Ward/QAP/E5/physical promotion.
