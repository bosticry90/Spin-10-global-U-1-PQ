from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'));import jets as J
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'decomposition_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
Z=J.ZERO;ONE=J.constant(1);I=J.I;half=J.constant(F(1,2));mul=J.times
# Reuse only frozen exact polynomial/parsing helpers, not either worker.
names={'sc','decode','decode_old','mp','madd','msm','transpose','pa','ps','pm','pe','pp','ev1','encp','mmadd','mgscale','atomM','tr','tr3','mv','va','compact','expand_compact','parse','parseE'}
tree=ast.parse((O/'kernels.py').read_bytes());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in selected}==names;exec(compile(ast.Module(body=selected,type_ignores=[]),'frozen-exact-polynomial-helpers','exec'))
tree=ast.parse((O/'verify_v2.py').read_bytes());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['act','project','ghost_operators']]
exec(compile(ast.Module(body=selected,type_ignores=[]),'frozen-action-Euler-helpers','exec'))
def grade(P,g,strip=False):return J.clean({w:J.Coeff([((0 if strip else k[0],k[1],k[2],k[3]),z) for k,z in c.terms if k[0]==g]) for w,c in P.items()})
def plus(*Ps):
    out={}
    for P in Ps:J.add(out,P)
    return J.clean(out)
def compact_bos(P):
    out={};target={}
    for w,c in P.items():
        if any(553<=n<643 or n>=643 and n<1241 for n,js in w):continue
        target[w]=c;ww=[compact(n,js) for n,js in w]
        if all(n is not None for n in ww):out[tuple(ww)]=out.get(tuple(ww),Z)+c
    out=J.clean(out);assert expand_compact(out)==J.clean(target),'GENERAL_BOSON_RECONSTRUCTION_FAILS'
    return out
def linear_primitive(P):
    out={};target={}
    for w,c in P.items():
        assert len(w)==1
        n=compact(*w[0]);target[w]=c
        if n is not None:out[n]=out.get(n,Z)+c
    assert expand_compact({(n,):c for n,c in out.items()})==J.clean(target)
    return out
def boson_operator(P,factor):
    H={};FJ={}
    for w,c in P.items():
        assert len(w)==2;a,b=w;val=ps(factor,c)
        if a<90 and b<90:
            H[a,b]=pa(H.get((a,b),{}),val);H[b,a]=pa(H.get((b,a),{}),val)
        elif a<90<=b:FJ[a,b-90]=pa(FJ.get((a,b-90),{}),val)
        else:assert a>=90 and b>=90
    return H,FJ
def apply(H,x):
    flat={**x[0],**{45+i:P for i,P in x[1].items()}};out={}
    for (i,j),P in H.items():
        if j in flat:out[i]=pa(out.get(i,{}),pm(P,flat[j]))
    return {i:P for i,P in out.items() if i<45 and P},{i-45:P for i,P in out.items() if i>=45 and P}
def force(source,kind,r,Eforces):
    if kind=='J':return ({i:P for (i,j),P in source.items() if j==r and i<45},{i-45:P for (i,j),P in source.items() if j==r and i>=45})
    bs=Eforces.get(r,{});return ({i:pp(c) for i,c in bs.items() if i<45},{i-45:pp(c) for i,c in bs.items() if 45<=i<90})
def addforce(a,b):return va(a[0],b[0]),va(a[1],b[1])
flows=load(R/'calculations/canonical_so10_mixed_Ward_generator_transport/transport_tables_v2.json.gz');flow={(r['mode'],r['family'],r['tensor']):{n:J.decode(p) for n,p in r['X']} for r in flows['cases']}
action=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0];S0=J.decode(action['original'][0]['density'])
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');Us=[grade(J.decode(p['qG']),0) for p in fj['probes']]
qt=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz');ML={int(a):mp(z,True) for a,z in qt['M_Lambda'].items()};L0={int(a):mp(z,True) for a,z in qt['L'].items()}
width=[J.Coeff([((0,0,1,0),F(1))]) if a<12 else J.Coeff([((0,1,0,0),F(1))]) for a in range(45)]
y=[{((4*a+mu,(mu,)),):ONE for mu in range(4)} for a in range(45)]
factory=load(O/'factory_tables.json.gz');native=load(O/'kernel_tables.json.gz');prior={(r['probe'],r['family'],r['tensor'],r['epsilon'],r['Ja']):r for r in native['complete_color_table']}
rows=[];caseinfo=[];failed22=0;failedsum=0;ordered_residual=0;control_factorization=0
for row in factory['rows']:
    pr,fam,tn=row['probe'],row['family'],row['tensor'];X=[flow['base',fam,tn],flow['Hcross' if pr==0 else 'Mcross',fam,tn]]
    XS=[{n:p for n,p in x.items() if n>=643} for x in X]
    Pfull=[grade(act(S0,XS[0]),1,True),grade(plus(act(Us[pr],XS[0]),act(S0,XS[1])),1,True)]
    Pb=[compact_bos(project(p)) for p in Pfull];Pops=[ghost_operators(p) for p in Pfull]
    PE=[{s:linear_primitive({w:-c for w,c in grade(x.get(1241+s,{}),1,True).items()}) for s in range(12,45)} for x in X]
    # Actual field-flow applied to the fixed reference gradient, independently
    # of C/P. h(E) acts on the momentum-conjugate reference gradient.
    Rb=[];Rkin=[]
    for order,x in enumerate(X):
        rb={};rk={}
        for a in range(45):
            rhs=plus({w:mul(I,c) for w,c in y[a].items()},{((508+a,()),):width[a]})
            J.add(rb,J.mul(grade(x.get(508+a,{}),1,True),rhs))
            for w,c in grade(x.get(598+a,{}),1,True).items():
                if len(w)==1 and 598<=w[0][0]<643 and not w[0][1]:rk[w[0][0]-598,a]=c
                else:assert all(1151<=n<1196 for n,js in w),'UNEXPECTED_REGULATOR_FIELD_FLOW'
        Rb.append(compact_bos(project(J.clean(rb))));Rkin.append(rk)
    Cb=[];Cops=[];CE=[];CL=[]
    for up in [0,1]:
        z=J.decode(row['C'][up]['selected_density']);cb,bg,ki,sp=parse(z);Cb.append(cb);Cops.append((ki,bg))
        es={};el={}
        for ss,p in row['DK_components'][up].items():bs,ll,sp=parseE(J.decode(p));es[int(ss)]=bs;el[int(ss)]=ll
        CE.append(es);CL.append(el)
    selected=[a<12 if pr==0 else a>=12 for a in range(45)]
    U=qt['probes'][pr];Uy={int(i):mp(z,True) for i,z in U['M_y'].items()};Ul={int(i):mp(z,True) for i,z in U['M_Lambda'].items()};Uj={int(i):mp(z,True) for i,z in U['N_direct'].items()}
    def inverse(f):
        yy,ll=f;oy={};ol={}
        for i in set(yy)|set(ll):oy[i]=ps(pe(pa(ps(yy.get(i,{}),width[i]),ps(ll.get(i,{}),-I))),-ONE);ol[i]=ps(pe(yy.get(i,{})),I)
        return {i:P for i,P in oy.items() if P},{i:P for i,P in ol.items() if P}
    def hu(x):
        yy,ll=x;fy={};fl={}
        for i in set(yy)|set(ll):
            if not selected[i]:continue
            fy[i]=pa(ps(yy.get(i,{}),-2*ONE),ps(ll.get(i,{}),mul(I,width[i])))
            fl[i]=pa(ps(yy.get(i,{}),mul(I,width[i])),ps(ll.get(i,{}),mul(mul(width[i],width[i]),half)))
        return fy,fl
    def bgmass(bg,x):
        out={}
        for bank,vec in zip(bg[:2],x):
            for i,P in vec.items():
                if bank.get(i):out=mmadd(out,mgscale(atomM(bank[i]),P))
        return out
    original=lambda x:bgmass([{},ML,{}],x)
    group_data={}
    for label,bos,ops,es,els,factor in [('C',Cb,Cops,CE,CL,pp(ONE)),('P',Pb,Pops,PE,[{},{}],pp(ONE)),('R',Rb,[(k,[{},{},{}]) for k in Rkin],[{},{}],[{},{}],{-1:ONE,0:-ONE})]:
        parsed=[boson_operator(b,factor) for b in bos];sources={}
        for kind,ids in [('T',range(12,45)),('J',range(45))]:
            for r in ids:
                x0=({r:{1:ONE}}, {}) if kind=='J' else ({r:{1:sc(width[r],F(-1,2))}},{r:{1:I}})
                fu=hu(x0)
                if kind=='J' and selected[r]:fu=addforce(fu,({r:pp(2*ONE)},{r:pp(mul(-I,width[r]))}))
                xu=inverse(fu)
                xb=inverse(addforce(apply(parsed[0][0],x0),force(parsed[0][1],kind,r,es[0])))
                xbu=inverse(addforce(addforce(hu(xb),apply(parsed[0][0],xu)),addforce(apply(parsed[1][0],x0),force(parsed[1][1],kind,r,es[1]))))
                v00=original(x0);vu=mmadd(original(xu),bgmass([Uy,Ul,Uj],x0));vb=mmadd(original(xb),bgmass(ops[0][1],x0));vbu=mmadd(original(xbu),mmadd(bgmass([Uy,Ul,Uj],xb),mmadd(bgmass(ops[0][1],xu),bgmass(ops[1][1],x0))))
                if kind=='J':
                    vu=mmadd(vu,atomM(Uj.get(r,{})));vb=mmadd(vb,atomM(ops[0][1][2].get(r,{})));vbu=mmadd(vbu,atomM(ops[1][1][2].get(r,{})))
                else:
                    v00=mmadd(v00,atomM(L0[r]));vb=mmadd(vb,atomM(els[0].get(r,{})));vbu=mmadd(vbu,atomM(els[1].get(r,{})))
                assert all(k>=0 for mat in [v00,vu,vb,vbu] for pol in mat.values() for k in pol),'UNCANCELED_EXTERNAL_INVERSE_HEAT'
                sources[kind,r]=[v00,vu,vb,vbu]
        group_data[label]=(sources,ops)
    counts=defaultdict(int)
    for ss in range(12,45):
        for r in range(45):
            channels={}
            for label,(sources,ops) in group_data.items():
                ts=sources['T',ss];js=sources['J',r];v22={}
                for a,b in [(0,3),(1,2),(2,1),(3,0)]:v22=pa(v22,ps(tr(ts[a],js[b]),-ONE))
                v42=pa(tr3(ts[0],ops[0][0],js[1]),pa(tr3(ts[1],ops[0][0],js[0]),tr3(ts[0],ops[1][0],js[0])))
                v24=pa(tr3(js[1],ops[0][0],ts[0]),pa(tr3(js[0],ops[0][0],ts[1]),tr3(js[0],ops[1][0],ts[0])))
                if label=='R':v22=pa(v22,pa(v42,v24));v42=ps(v42,-ONE);v24=ps(v24,-ONE)
                channels[label]=[v22,v42,v24]
                for i,P in enumerate(channels[label]):assert not ev1(P),('NONZERO_UV_ROOT',label,pr,fam,tn,ss,r,i)
            oldrow=prior[pr,fam,tn,ss,r]
            assert [encp(P) for P in channels['C']]==[oldrow[n] for n in ['heat22','heat42','heat24']],'GENERAL_PARENT_DOES_NOT_REPRODUCE_C'
            res=[pa(pa(channels['C'][i],channels['P'][i]),ps(channels['R'][i],-ONE)) for i in range(3)]
            combined=pa(res[1],res[2]);failed22+=bool(res[0]);failedsum+=bool(combined);ordered_residual+=bool(res[1]) or bool(res[2])
            for label in ['P','R']:
                counts[label]+=any(channels[label])
            rows.append({'probe':pr,'family':fam,'tensor':tn,'epsilon':ss,'Ja':r,'whole_source':[encp(P) for P in channels['P']],
             'regulator':[encp(P) for P in channels['R']],'ordered_residual':[encp(P) for P in res],'combined_asymmetric_residual':encp(combined)})
    caseinfo.append({'probe':pr,'family':fam,'tensor':tn,'nonzero_group_positions':dict(counts)})
    print('STAGE independent whole source/regulator '+str(pr)+' '+fam+str(tn),flush=True)
blob=gzip.compress((json.dumps({'cases':caseinfo,'complete_color_table':rows},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'decomposition_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'WPT_ACTUAL_WHOLE_SOURCE_REGULATOR_COMPARISON','complete_color_positions':len(rows),'general_parent_reproduces_C':True,
 'nonzero_heat22_residual_positions':failed22,'nonzero_combined_asymmetric_residual_positions':failedsum,'ordered_asymmetric_residual_positions_retained':ordered_residual,
 'selected_finite_heat_identity_qualified':failed22==failedsum==0,'source_Jacobian_density_derivatives_zero_not_density':True,
 'uncanceled_external_inverse_heats':0,'table_sha256':sha256(blob).hexdigest(),'full_Ward_QAP_E5_physical_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'decomposition_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
