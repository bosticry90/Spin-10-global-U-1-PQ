# WPT: quantum transport identity and finite-contact normalization law

The selected leading g10 finite-generator transport now satisfies the
complete finite-heat equation

    action/primitive response + whole-source product = regulator response.

All83160 generator/color/probe positions pass separately in the three
ordered heat channels. The source product and regulator were derived
independently. The ghost-kinetic third edge, generic nonzero formal
Jacobian vacuum density and source companions are retained. The
selected Jacobian derivatives vanish; the whole Jacobian is not zero.

The more consequential normalization result occurs one loop earlier:
an order-hbar finite counterterm with the Ward primitive held fixed
produces the finite contact shift

    Delta chi = g10 P_M Omega(A+B)/2.

The complete correlated DK companion cancels it. No baseline is fixed,
and no isolated source contact is substituted for that completion.
If primitive and baseline were both held unchanged, the conditional
constraint would be P_M(A+B)=0. The actual restricted map has rank10,
leaving18 generator directions and13 selected-core directions. This
condition has not been imposed on the theory.

[Derivation](PROOF.md), [whole-source/regulator review](decomposition_validation_receipt.json),
[contact-law review](tree_validation_receipt.json),
[complete loop kernels](kernel_tables.json.gz), [tree map](tree_tables.json.gz).

## Focused result-to-claim assessment

Evidence supports a common, action-derived leading reference transport
identity and a necessary correlated finite-contact law for the existing
generator family. It is stronger than matching UV poles or observing
zero selected limits: the generally nonzero finite-heat source and
regulator terms agree, and fixed versus transported normalization has
been distinguished explicitly. Independent action/current, Gaussian,
Berezin and rank checks corroborate these bounded claims. Failed and
resource-incomplete runs are preserved and not counted PASS.

The compensation law does not establish that every allowed product can
satisfy all Ward/Slavnov/reality conditions simultaneously. Arbitrary
additional finite A, primitive mixing baselines and physical source
reality remain open. A conditionally smaller zero-shift subfamily is
classification, not an adopted scheme or a physical no-go result.
Shared action/data/reference/software/AI authorship remain limitations;
these are not independent scientists or experimental support.

Next: derive the first Slavnov/source compatibility equations for the
marked parent and full DK completion. Use the measured contact law
rather than imposing Dminus A=0, choosing a baseline, or expanding
unrequired higher-order tensors. State113/34of39 and E5/A5 OPEN remain
unchanged; custody is exit2/seven unresolved, NOTPASS. Full goal active.
