# Explicit first-u generator coefficients

The56 base-generator/probe cross kernels completed16.190918s,all83160
positions. To cover A_u=A0+uA1,B_u=B0+uB1, also calculate the independent
A1/B1 contribution. Its explicit u consumes the probe degree, so it
uses the unprobed g0 parent. OriginalJa0 ghost Hessian is zero; the
only possible bubble is theta00 times the b-Ja vertex. A third-edge
term or DK companion would multiply that zero originalJa0 root.

Derive this vertex independently from actual C0 source/background data
and its bosonic Gaussian mean; do not infer it by division of the
cross kernel or by an expected cancellation. Calculate all28x33x45
positions including zeros. Copying that SAME linear map for each probe
is justified only by this degree argument, not another run.180s/8GiB/
350MiB/16MiB unchanged; no new normalization choice or broader claim.
