# WPT V2: remove repeated input decoding; enforce review prerequisite

Explicit-order V1 exhausted its180s timer (exit124; raw capture FAILED,
mathematical classification INCOMPLETE_RESOURCE_LIMIT) after16 of28
stage messages. It decoded the same large immutable factory inside each
tensor loop. No explicit table or result was completed. V2 moves that
read outside the loop and indexes its rows once; no calculation, input,
acceptance condition or resource limit is weakened or enlarged.

Review V1 was launched before the required explicit-order completion
was confirmed. Its exact action/current/DK assertions completed, then
it failed because explicit_tables.json.gz did not exist. The premature
dependent launch is an execution error; that review is not PASS.
Preserve all original sources, captures, preparation and controller
failures. No partial assertion output qualifies the full review.

First run explicit V2 and inspect its completed capture/output. Only
then freeze review V2, which must check that completion precondition.
The review now reads explicit V2's new table/output/preparation. All
scientific requirements and180s/8GiB/350MiB/16MiB limits unchanged.
