# Classical contact carried by an order-hbar counterterm

The independently checked loop equation is qualified within its selected
reference domain. It is NOT the entire finite-normalization response:
for an orderhbar b QK counterterm the CLASSICAL source/mean transport
already enters Gamma1/W1,whereas the loop response enters hbar2.

Calculate the actual classical theta/Ja response from the same measured
C/DK quadratic parent, including source-only contacts and all b/u means.
Keep transported primitive and fixed primitive separately. Test the
candidate unprobed/explicit-u fixed-primitive finite shift

   (P_broken Omega(A+B)/2)_sr

against all actual coefficients; do not impose a zero contact baseline.
If present,this shift gives the REQUIRED correlated operator-normalization
law,not an adopted finite scheme. The full DK completion,including its
field and JLambda*C companions,must remain rather than replacing it by
an isolated source contact.

Determine the rank of this actual BROKEN-ROW map on the14+14 generator
tensor family. Do not incorrectly replace its condition by all45 rows
or assume A+B=0 globally. Use exact real Gram kernels and an independent
splitting-prime lower bound; preserve the5-dimensional projected-core
kernel rather than identifying full counterterms by their quadratic jet.
Any conditional zero-shift subfamily is classification only; no condition
or baseline is imposed on the theory.180s/8GiB/350MiB/16MiB unchanged.
