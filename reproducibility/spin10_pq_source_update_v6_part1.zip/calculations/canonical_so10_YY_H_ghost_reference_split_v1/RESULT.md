# Reference split of the H-ghost lower product

The common first reference derivative
has four charged split operands. The
B B return splits through Maxwell and
both oriented mixed blocks. The other
charged return gives the ghost split.
The H ghost itself is center neutral.

If the lower reference derivative
and regulator dictionary stay fixed,
the three splits beyond V1100 must
supply (0,19/2672,-19/5344) per charge
in total on the tested pivots. The
minimal continuation changes only
V1100's split and fails this
conditional relative test.

The remaining split normalizations,
the possible lower change and the
complete W5 domain stay open.
