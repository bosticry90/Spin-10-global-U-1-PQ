# First reference split of the H-ghost lower product

Remove the Y spectator from the V1100
G-master graph. Its three returns are
one charged B B, one H ghost and one
charged ghost. X returns B_L,a_L,
F returns B_L,a_H, and G returns
C_H,C_L. The exterior fields are
B_L,C_X,C_F,a_G. The two returning
ghost derivatives at G are kept in
their balanced local class. This is
a different numerical T3 product
from the older H ordinary-gauge
closure used to define W.

The center generator acts trivially on
the H closure, checked on all 12
H directions in both charts. Its
first reference variation therefore
splits a charged return. A charged
B B split has three independent
ordered operands. With D=K_q-K_p
they are the B B, B Lambda, and
Lambda B blocks of -G_p D G_q.
D_LambdaLambda is zero. The charged
ghost split gives a fourth operand.
The V1100 companion uses the B Lambda
block, with X B on the left and F B
on the right. Its other mixed
orientation, the Maxwell term, and
the reverse charged ghost term are
separate paths.

All three forward terms are nonzero
at an independent-momentum control.
For p=2 e0 and q=e1 their B B matrices
are diag(0,0,3/4,3/4), diag(0,-1/4,0,0)
and diag(1,0,0,0) in ordered block
notation. Their sum is the exact
unheated B B difference. The charged
ghost difference in the same stripped
orientation is 3/4. These controls
verify returning support, not finite
values of the ordered products.

At fixed flat reference use C_p=h_p G_p.
The flat comparison includes h_p h_q
on every split term. The covariant
difference is C_q-C_p. Its difference
from the flat Born product is
-C_p(R_q-R_p)C_q. The same three-term
relation holds on the charged ghost
cut with its original ordered phase.
The regulator, all attached profiles
and independent transfers must enter
the causal comparison. This algebra
does not set their finite contacts.

Consider the relative fixed-total
reference test on this typed product.
If the T3 finite map and its reference
derivative and the regulator dictionary
are fixed, the sum of changes on the
four T4 splits must vanish. The
minimal V1099 plus V1100 continuation
changes just one of these splits.
Its verified nonzero signed value
then requires an equal opposite sum
on the remaining three. On the
displayed pivots that sum is
(0,19/2672,-19/5344) per charge.
The minimally extended map by itself
does not pass this fixed-lower test.

This conclusion is conditional on
normalized global Q0 on the V1100
preimage and the relative reference
identity on the present lower product.
The original W5 domain has to admit
this typed polarization before the
test can constrain a common map.
Other split contacts or a linked lower
reference derivative may supply the
required change. No broader
incompatibility or physical conclusion
is established.
