# V1101 execution contract

Question. What else enters the first
reference derivative of the unsplit
V1100 H-ghost numerical product?

Inputs. V1100 source and ghost placement,
V1064 ordered inverse, V1080 regulated
variation, V1077 relative comparison.

Test. Verify center neutrality, all
three ordered B split matrices and
the charged ghost split. Retain the
covariant, flat and regulator terms.
Use the exact V1100 contact to identify
the required sum at fixed lower.

Bounds. 120 s native and 180 s replay with E4 caps.
No finite normalization choice, full
W5 applicability or new amplitude.
