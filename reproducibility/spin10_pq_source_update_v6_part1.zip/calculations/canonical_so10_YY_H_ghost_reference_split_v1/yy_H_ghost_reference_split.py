"""Inventory the first reference derivative of the H-ghost lower word."""
from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def center(phase):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    f,_,S,hess,h,j,_,flat = two.inputs(phase)
    for b in flat.ideal.H:
        components = defaultdict(lambda:sp.S.Zero)
        for i,z in h.items():
            for k,v in f[i,b]:
                components[k] += z*v
        assert all(sp.simplify(x)==0 for x in components.values())
    return len(flat.ideal.H)


def split():
    src = load("split_mixed_reference_contact_v1","yy_split_mixed_reference_contact")
    p,q = sp.Matrix([2,0,0,0]),sp.Matrix([0,1,0,0])
    hp,hq = sp.symbols("h_p h_q",nonzero=True)
    Kp,Kq = src.K(p,0),src.K(q,0)
    Gp,Gq = src.G(p,0),src.G(q,0)
    D = Kq-Kp
    cov = hq*Gq-hp*Gp
    flat = -hp*hq*Gp*D*Gq
    R = (1/hq-1)*Kq-(1/hp-1)*Kp
    regulator = -hp*hq*Gp*R*Gq
    assert (cov-flat-regulator).applyfunc(sp.cancel)==sp.zeros(5)
    assert D[4,4]==0
    arms = [-Gp[:4,:4]*D[:4,:4]*Gq[:4,:4],
            -Gp[:4,:4]*D[:4,4:]*Gq[4:,:4],
            -Gp[:4,4:]*D[4:,:4]*Gq[:4,:4]]
    assert sum(arms,sp.zeros(4))==(Gq-Gp)[:4,:4]
    assert arms[0]==sp.diag(0,0,sp.Rational(3,4),sp.Rational(3,4))
    assert arms[1]==sp.diag(0,-sp.Rational(1,4),0,0)
    assert arms[2]==sp.diag(1,0,0,0)
    assert hp*hq*sum(arms,sp.zeros(4))==flat[:4,:4]
    P,Q = p.dot(p),q.dot(q)
    ghost = 1/Q-1/P
    ghost_flat = -hp*hq*(Q-P)/(P*Q)
    ghost_R = -hp*hq*((1/hq-1)*Q-(1/hp-1)*P)/(P*Q)
    assert sp.cancel(hq/Q-hp/P-ghost_flat-ghost_R)==0
    return [sum(x!=0 for x in A) for A in arms],str(ghost)


def compare():
    path = C/"canonical_so10_YY_H_ghost_composite_v2/result.json"
    known = json.loads(path.read_bytes())["checks"]["conditional_extra_H_ghost_proper_per_j"]
    s = sp.Matrix(list(map(sp.Rational,known)))
    assert s!=sp.zeros(3,1)
    return list(map(str,-s))


def check(phase):
    count,ghost = split()
    return {"center_neutral_H_colors":center(phase),
            "charged_forward_BB_and_mixed_nonzero_entries":count,
            "reverse_charged_ghost_unheated_value":ghost,
            "fixed_lower_required_other_sum_per_j":compare()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
