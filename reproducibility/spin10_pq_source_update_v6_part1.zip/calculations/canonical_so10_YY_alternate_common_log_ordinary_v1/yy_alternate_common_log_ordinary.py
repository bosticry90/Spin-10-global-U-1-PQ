"""Verify one spectator-independent ordinary Phi/Sigma coefficient solution."""
from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import ROOT, run_worker


spec = importlib.util.spec_from_file_location(
    "mixed_owner",ROOT/"calculations/canonical_so10_YY_mixed_spectral_Ward_master_v1/yy_mixed_spectral_ward_master.py")
mixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mixed)
spectral,ideal,owner,alg,ports = mixed.spectral,mixed.ideal,mixed.owner,mixed.alg,mixed.ports
r,zero = sp.Rational,sp.S.Zero
kap = ((0,0,0),(r(4,15),0,r(4,3)),(r(3,5),0,0),
       (r(1,60),r(3,4),r(4,3)),(r(5,12),r(3,4),r(4,3)))
labels = {
    "Phi":(("M",None),(0,3),(2,3),(3,3),(0,4),(2,4),(3,4)),
    "Sigma":mixed.labels}
q_weights = {
    "Phi":(1,5,-r(19,5),2,r(1,5),-r(3,5),r(4,5)),
    "Sigma":(0,-r(1,4),r(1,8),0,0,0,0)}
v_weights = {"Phi":(8,0,0),"Sigma":(0,-r(16,135),r(1,15))}
u_weights = {"Phi":v_weights["Phi"],"Sigma":(4,r(1028,135),r(1,15))}
# Keys are auxiliary sector, then exterior ghost sector.
W = {
    (1,1):(-r(34,9),0,-r(1,90)),(1,2):(-r(41,9),0,0),
    (1,3):(-r(17,3),0,r(1,6)),(1,4):(-r(64,15),0,0),
    **{(2,a):(-4,0,0) for a in range(1,5)},
    (3,1):(-4,0,0),(3,2):(-4,0,0),(3,3):(-4,-r(116,15),0),
    (3,4):(-r(112,15),-r(104,15),-r(2,3)),
    (4,1):(-r(36,5),0,0),(4,2):(-r(92,15),0,0),
    (4,3):(r(564,5),-20,0),(4,4):(-r(52,5),-r(52,15),-r(8,5))}


def orbit(E,colors):
    return ideal.plus(*((z,E[k]) for k,z in colors.items()))


def raw_inputs(phase,f):
    raw = alg.read(ports.CALC/"canonical_so10_unprobed_compact_all_coupling_v1"/
                   f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    Caa,driver = [],{}
    for g,word,cells in raw:
        ids = [i for i,_ in word]
        if g==2 and len(ids)==4 and ids[1]<180 and 553<=ids[2]<598 and 598<=ids[3]<643:
            p,q,c,a = ids
            assert c-553 in ideal.M and a-598 in ideal.M
            if p%4==0:
                assert q%4==0 and all(not jets for _,jets in word)
                Caa.append((p//4,q//4,c-553,a-598,r(4,3)*ports.decode(cells,2,False)))
        if g==1 and len(ids)==3 and 1151<=ids[-1]<1196:
            a,h,j = ids[0]-508,ids[1]-553,ids[2]-1151
            assert a in ideal.M and h in ideal.H and j in ideal.M
            driver[j,a,h] = -ports.decode(cells,1,False)
    assert len(Caa)==13254
    expected = {(j,a,h):z for a,h in product(ideal.M,ideal.H) for j,z in f[a,h]}
    assert driver==expected and len(driver)==334
    marks,_ = ports.raw_ports(phase,f)
    return Caa,marks

def literal_Q(name,rho,P,E,sectors,raw,marks):
    q = dict(zip(labels[name],q_weights[name]))
    ep = {(beta,b):orbit(E,spectral.sector_colors(sectors[beta],b))
          for beta,b in product(range(5),ideal.M)}
    colors = {(i,h):({k:P[i][k,h] for k in ideal.H if P[i][k,h]} if h in ideal.H else {})
              for i,h in product(ideal.spectra,owner.COLORS)}
    pair = {}
    for h,b in product(owner.COLORS,ideal.M):
        if h in ideal.M:
            pair[h,b] = ideal.plus((q["M",None],alg.apply(rho[h],E[b])))
        else:
            pair[h,b] = ideal.plus(*((value,owner.act(rho,colors[i,h],ep[beta,b]))
                                     for (i,beta),value in q.items() if i!="M" and value))
    T = {e:ideal.plus(*((-r(4,3)*z,pair[h,b]) for (h,b,j,mu),z in marks.items()
                       if mu==0 and j==e)) for e in ideal.M}
    N = defaultdict(owner.empty)
    for p,s,c,a,z in raw:
        for h,b in ((p,s),(s,p)):
            if b in ideal.M:
                alg.axpy(N[a,c],z,pair[h,b])
    return T,{k:owner.clean(v) for k,v in N.items()},ep


def scalar_casimirs(start,stop,rho,P):
    R = {h:sp.SparseMatrix(stop,stop,{(i,j):z for j,col in rho[h].items() if start<=j<stop
                                     for i,z in col}) for h in ideal.H}
    maps = []
    for d in ideal.spectra:
        A = -sum((P[d][h,l]*R[h]*R[l] for h,l in product(ideal.H,repeat=2) if P[d][h,l]),sp.SparseMatrix(stop,stop,{}))
        cols = defaultdict(list)
        for i,j,z in sp.SparseMatrix(A).row_list():
            if sp.expand(z):
                cols[j].append((i,sp.expand(z)))
        maps.append(cols)
    return maps


def j_affine(name,ep,A,rho,E):
    q = sp.Symbol("q")
    delta = 12 if name=="Phi" else 17
    Q = dict(zip(labels[name],q_weights[name]))
    for beta,k in enumerate(kap):
        for i,ci in enumerate(k):
            for b in ideal.M:
                assert alg.apply(A[i],ep[beta,b]) == ideal.plus((ci,ep[beta,b]))
        if not k[0]:
            assert not any(alg.apply(rho[h],ep[beta,b]) for h,b in product(ideal.H,ideal.M))
            continue
        dq = [(Q.get((i,beta),0)-Q["M",None])*q for i in ideal.spectra]
        j = ((k[0]*dq[0]-3*k[1]*dq[1]-3*k[2]*dq[2]-delta)/(2*k[0]),2*dq[1],2*dq[2])
        assert sp.expand(sum(ki*(-2*a+b) for ki,a,b in zip(k,j,dq))-delta)==0
    assert all(ideal.plus(*((1,ep[beta,b]) for beta in range(5)))==E[b] for b in ideal.M)

def check_block(name,start,stop,rho,f,P,sectors,bases,vacuum,raw,marks):
    v = {i:z for i,z in vacuum.items() if start<=i<stop}
    E = {a:alg.apply(rho[a],v) for a in owner.COLORS}
    T,N,ep = literal_Q(name,rho,P,E,sectors,raw,marks)
    A = scalar_casimirs(start,stop,rho,P)
    j_affine(name,ep,A,rho,E)
    q = dict(zip(labels[name],q_weights[name]))
    count = light = flipped = transposed = useful = 0
    for h,j in product(ideal.H,ideal.M):
        assert not ideal.plus((1,alg.apply(rho[h],T[j])),
                               (1,orbit(T,dict(f[j,h]))))
        light += 1
    for beta,alpha in product(range(5),repeat=2):
        w = W.get((beta,alpha),(0,0,0))
        wt = W.get((alpha,beta),(0,0,0))
        forced = [r(4,3)*q.get((i,beta),zero) for i in ideal.spectra]
        for j,c in product(bases[beta],bases[alpha]):
            qrow = ideal.plus((1,owner.act(rho,c,orbit(T,j))),
                                *((a*b,N.get((jj,cc),{})) for jj,a in j.items() for cc,b in c.items()))
            z = owner.act(rho,c,orbit(E,j))
            S = [ideal.plus((r(1,2)*(ka+kb),z),(-r(1,2),alg.apply(mat,z)))
                 for ka,kb,mat in zip(kap[alpha],kap[beta],A)]
            V = [ideal.plus((kb,z),(-1,s)) for kb,s in zip(kap[beta],S)]
            ghosts = ideal.plus(*zip(w,S))
            free = ideal.plus(*zip(forced,V))
            total = ideal.plus((1,qrow),(1,ghosts),(1,free),
                               *zip(u_weights[name],S),*zip(v_weights[name],V))
            assert not total,(name,beta,alpha,j,c,total)
            count += 1
            flipped += bool(free)
            transposed += bool(ideal.plus(*((a-b,s) for a,b,s in zip(wt,w,S))))
            useful += bool(ghosts)
    return count,light,flipped,transposed,useful


def check(phase):
    vacuum,_,rho,f,_,_ = owner.inputs(phase)
    ad,P = ideal.projectors(f)
    _,sectors,_ = spectral.spectral(ad,P)
    bases = [[spectral.sector_colors(Q,k+12) for k in Q.rref()[1]] for Q in sectors]
    raw,marks = raw_inputs(phase,f)
    rows = [check_block(s,a,b,rho,f,P,sectors,bases,vacuum,raw,marks)
            for s,(a,b,_) in alg.BLOCKS.items()]
    assert all(x[2] and x[3] and x[4] for x in rows)
    return {"broken_ordered_pairs_by_block":[x[0] for x in rows],
            "light_ghost_pairs_by_block":[x[1] for x in rows],
            "wrong_reverse_vector_counts":[x[2] for x in rows],
            "transposed_YFF_vector_counts":[x[3] for x in rows],
            "both_blocks_common_YFF_nonblind":True,
            "forced_reverse_retained_and_all_rows_zero":True,
            "ordinary_master_and_affine_scopes_matched":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
