# Bounded alternate common-log ordinary test V1034

Freeze the V1031 mixed spectral class, the V1032 log restriction, the V1033 tied reverse trace and the literal source exports. Fix the alternate common-log trial. Verify the explicit one shared W array and both Q/S/V tables in the full ordered broken spectral bases. Check the light ghost source sign and equivariance, actual affine Casimirs and nonblind reversed-sign and transposed-array controls.

Accept only exact native and replay agreement and the linked ordinary coefficient scopes. No independent refitting, full causal normalization or protected scientific authority. Historical custody exit 2 remains unresolved.
