# Compact transfer of the unsplit H-ghost lower product

Keep the X quartic, literal F ghost vertex and
G antighost-source Euler of V1100. Delete Y.
Orient momenta u:X to F, v:F to G, w:G to X,
with P_X=u-w, P_F=v-u, P_G=w-v. At width zero
write T(u)=I-u u^T/u^2. The literal F derivative
is on the returning a_H in all 334 entries of
both charts. The literal G Euler gives w^2,
while the balanced G expression gives v.w.
Their difference is P_G.w at independent transfer.

In the odd word C_X,a_X,C_F,a_F,C_H,C_L,a_G
the H pair is adjacent and the L Wick factor
is minus. Both ordered a,C inverses are negative.
The F derivative is +i v, and the G source minus
times the Laplacian minus gives +w^2. The exact
regulated vector in stripped color convention is

    -i h_L(u) h_H(v) h_L(w) T(u) P_F/(u^2 v^2).

The G Laplacian cancels the L ghost denominator
and leaves its profile. The balanced word is this
expression times (v.w)/w^2. Their linear hard
jets coincide because T(u)v=T(u)P_F already
supplies one transfer. Differentiating the
shifted heat profiles adds no term at this order.

The average T(u) is 3I/4, with UV clock
2 ell_L+ell_H. The finite relative shift from c0
to c in dQ/(16 pi^2) units is (3/4) log(c0/c).
At nonzero P_F the literal unheated denominator
is the same transverse two-edge tensor as V1097,
now with one H ghost and one L B B inverse.
Using its fixed-four-dimensional finite part
and the collapsed L profile sets the scalar
clock to 2 ell_L+ell_H. Contraction with P_F
gives 3 B0/4-3/8, where B0 is the inherited
scalar member at P_F^2 and that clock.
The linear expansion is on the hard part.
A difference at two nonzero P_F scales after
dividing by P_F cancels a local linear contact
and retains the logarithm.

The literal exterior C_F rotation before
antisymmetrization gives the weighted vector
K=(0,19/5010,-19/10020) per charge. Rotating
G gives zero and rotating both X fields gives
-K. Both charts replay this conservation.
A parity-even metric local derivative can use
P_X,P_F,P_G modulo the total derivative.
Only the difference of the F and X coefficients
changes the pure-center tangent on these fixtures.

Define the lower contact kappa in the convention
of +d_F on the F exterior ghost and compact
label, with the common phase absorbed. Its
covariant lift d+g A ad_h gives background
tangent kappa K per charge. At fixed regulator
the relative fixed-total identity for V1100's
minimal continuation requires kappa=-15/8.
This changes A=0 independent-transfer data.
An A-only pure gauge adjustment with unchanged
A=0 data cannot produce it in that lift.

For a compact probe set B_X=c and let the ghost c
and antighost v be constant on the B support.
Let the other ghost v=J e vary there with constant
switching. Only the exterior assignment with
C_F=v sees the P_F derivative. Its weighted
unrotated color is -19/6680 before the common
stored sign. This independently detects the
required change. The complete proper and marked
sums and normalized lower H quartet remain open.
