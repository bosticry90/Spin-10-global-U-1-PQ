"""Measure the unsplit H-ghost compact transfer and its lower-map direction."""
from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal(phase):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    f,P,S,Q,h,charge,modes,flat = two.inputs(phase)
    raw = flat.ordinary.alg.read(C/"canonical_so10_unprobed_compact_all_coupling_v1"/
                                 f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    ports = flat.ordinary.ports
    f_jets = [0,0,0]
    F,Ga,Hmaster = defaultdict(lambda:sp.S.Zero),{},{}
    for g,word,cells in raw:
        if g!=1 or len(word)!=3:
            continue
        (i,di),(j,dj),(k,dk) = word
        if 553<=i<565 and 610<=j<643 and 1253<=k<1286:
            assert not (di or dj or dk)
            Ga[i-553,j-598,k-1241] = ports.decode(cells,1,False)
        if 48<=i<180 and i%4==0 and 565<=j<598:
            if 598<=k<610:
                assert sorted(di+dj+dk)==[0]
                for slot,d in enumerate((di,dj,dk)):
                    f_jets[slot] += int(bool(d))
                F[i//4,k-598,j-553] += (int(bool(dk))-int(bool(di)))*ports.decode(cells,1,False)
            elif 643<=k<691 and (k-643)%4==0:
                assert not (di or dj or dk)
                Hmaster[i//4,(k-643)//4,j-553] = -ports.decode(cells,1,False)
    F = {k:v for k,v in F.items() if v}
    Gexpect = {(h,b,e):z for h,b in product(range(12),range(12,45)) for e,z in f[h,b]}
    Fexpect = {(u,h,c):z for u,h in product(range(12,45),range(12)) for c,z in f[u,h]}
    assert Ga==Gexpect and F==Fexpect and len(F)==len(Ga)==334
    assert Hmaster=={k:-v for k,v in F.items()}
    assert Ga=={(h,b,e):-v for (h,e,b),v in Ga.items()}
    H,M = flat.ideal.H,flat.ideal.M
    J = sp.zeros(33)
    for i,z in h.items():
        for k in M:
            for b,v in f[i,k]:
                J[b-12,k-12] += z*v/charge
    L = S[3]
    J = (L*J*L).applyfunc(sp.simplify)
    c,d,e,v = modes
    d3 = {27:sp.Rational(1,2),32:-sp.Rational(1,2)}
    d4 = {28:sp.Rational(1,2),31:sp.Rational(1,2)}
    def rotate(z):
        q = (J*flat.vec(z)).applyfunc(sp.simplify)
        return {i:q[i-12] for i in M if q[i-12]}

    def center(b,cx):
        return flat.images.matrix({
            (u-12,w-12):sum(z*t*Q[u,k,l,w] for k,z in b.items() for l,t in cx.items())
            for u,w in product(M,repeat=2)})

    def sew(A,Fport,Gport):
        if phase=="native":
            return flat.trace(P,S,A,Fport,Gport,3,3)
        X = {h:L*Fport[h] for h in H}
        Y = {h:A*L*Gport[h] for h in H}
        return sp.Matrix([sp.expand(sum(P[i][h,k]*sum(X[h][l]*Y[k][l] for l in range(33))
                          for h,k in product(H,repeat=2) if P[i][h,k]))
                          for i in flat.ideal.spectra])

    W = sp.Matrix(flat.family.representative()[0][3,3])
    W += sp.Matrix(flat.family.direction()[0][3,3])/1002
    sums = []
    for i,(b,c1,c2,a) in enumerate(((d,c,d,d),(c,c,e,v),(c,c,d3,d4),(c,c,v,v))):
        z = sp.zeros(4,1)
        for cx,cf,s in ((c1,c2,1),(c2,c1,-1)):
            T = center(b,cx)
            Fport = {h:flat.vec({u:sum(z*F.get((u,h,k),0) for k,z in cf.items())
                                 for u in M}) for h in H}
            Gport = {h:flat.vec({u:sum(z*Ga.get((h,k,u),0) for k,z in a.items())
                                 for u in M}) for h in H}
            bare = sew(T,Fport,Gport)
            if i==3:
                assert s==1
                ramp = sp.simplify(bare.dot(W))
                assert ramp == -sp.Rational(19,6680)
                break
            atF = sew(T,{h:J*V for h,V in Fport.items()},Gport)
            atG = sew(T,Fport,{h:J*V for h,V in Gport.items()})
            atX = sew(center(rotate(b),cx)+center(b,rotate(cx)),Fport,Gport)
            assert (atF+atG+atX).applyfunc(sp.simplify)==sp.zeros(3,1)
            z += s*sp.Matrix([v.dot(W) for v in (bare,atF,atG,atX)])
        if i<3:
            sums.append(z.applyfunc(sp.simplify))
    table = sp.Matrix.vstack(*(z.T for z in sums))
    K = table[:,1]
    assert K==sp.Matrix([0,sp.Rational(19,5010),-sp.Rational(19,10020)])
    assert table[:,0]==table[:,2]==sp.zeros(3,1) and table[:,3]==-K
    assert f_jets==[0,0,334]
    return K,f_jets,str(ramp)


def hard_transfer():
    I = sp.eye(4)
    p = sp.Matrix([2,1,-1,3])
    F = sp.Matrix([1,-2,3,1])
    X = sp.Matrix([2,0,-1,3])
    a = sp.symbols("a")
    u,v,w = p,p+a*F,p-a*X
    Q,V,W = u.dot(u),v.dot(v),w.dot(w)
    T = I-u*u.T/Q
    H = sp.Function("h_L")(Q)*sp.Function("h_H")(V)*sp.Function("h_L")(W)
    raw = -sp.I*H*T*(v-u)/(Q*V)
    balanced = raw*v.dot(w)/W
    first = -sp.I*H.subs(a,0)*T*F/Q**2
    for word in (raw,balanced):
        assert (word.diff(a).subs(a,0)-first).applyfunc(sp.simplify)==sp.zeros(4,1)
    assert sp.expand(W-v.dot(w)-(w-v).dot(w))==0
    assert raw.subs(a,1)!=balanced.subs(a,1)
    angular = sum((I-I[:,i]*I[:,i].T for i in range(4)),sp.zeros(4))/4
    assert angular==3*I/4
    owner = C/"canonical_so10_YY_H_lower_tensor_v1/result.json"
    coeffs = json.loads(owner.read_bytes())["checks"]
    const = sp.Rational(coeffs["broken_zero_longitudinal_difference"])+sp.Rational(1,8)
    assert const == -sp.Rational(3,8)
    return ["3/4",str(const)]


def check(phase):
    K,jets,ramp = literal(phase)
    path = C/"canonical_so10_YY_H_ghost_composite_v2/result.json"
    old = json.loads(path.read_bytes())["checks"]
    s = sp.Matrix(list(map(sp.Rational,old["conditional_extra_H_ghost_proper_per_j"])))
    kappa = -sp.Rational(15,8)
    assert s==kappa*K
    return {"literal_F_jet_counts":jets,
            "F_rotated_lower_color_per_j":list(map(str,K)),
            "selected_ordered_PF_ramp_color":ramp,
            "hard_angular_and_fixed_4d_constants":hard_transfer(),
            "required_lower_contact_per_raw_F_rotation":str(kappa)}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
