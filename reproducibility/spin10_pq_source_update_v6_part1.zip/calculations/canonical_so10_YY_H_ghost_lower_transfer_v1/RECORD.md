# V1103 execution contract

Question. Does the H-ghost lower product
have a compact one-transfer test for the
proposed change in its reference derivative?

Inputs. V1100 source/ghost carrier, V1102
color split, V1097 transverse tensor, V1059
geometric transport.

Test. Replay derivative slots, independent
transfers with collapsed profile retained,
hard angular and finite tensor pieces,
literal color rotations and ordered ramp.
Quantify the required lower local change.

Bounds. 120 s native and 180 s replay with
E4 caps. No global compact limit, admitted
normalization change or broader W3/W5 result.
