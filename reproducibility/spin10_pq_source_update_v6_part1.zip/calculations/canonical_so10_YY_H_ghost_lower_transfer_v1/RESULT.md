# Nonblind lower H-ghost transfer

The width-zero kernel has a first transfer
proportional to P_F, with hard angular factor
3/4 and clock 2 ell_L+ell_H. It retains the
collapsed L ghost profile. The balanced and
literal G words differ at independent transfer
and have the same first hard jet.

A covariant lower-only continuation of V1100
would require -15/8 in the F derivative
convention. The actual ordered compact color
is -19/6680 on a fixture detecting this change
at A=0. The plateau does not fix this data.
