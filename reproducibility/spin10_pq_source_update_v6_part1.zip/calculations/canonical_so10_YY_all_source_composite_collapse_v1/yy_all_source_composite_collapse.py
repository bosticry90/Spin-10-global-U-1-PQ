"""Audit the conditional all-source composite collapse at a first difference."""
import gzip
import json
import sys

import sympy as sp

from execute import PK,ROOT,run_worker
sys.path.insert(0,str(PK))
from source_convention_control import Exterior

C = ROOT/"calculations"


def ordered_inverse(phase):
    path = C/"canonical_so10_regulator_free_inverse_g1_recovery_v1"/f"{phase}_inverse.json.gz"
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        data = json.load(stream)
    xi = sp.Symbol("xi")
    eta = sp.Symbol("eta_H")
    momenta = dict(zip(("q0","q1","q2","q3"),(2,1,-1,3)))
    masses = {"Mref_Phi_squared":sp.Rational(7,3),"Mref_Sigma_squared":sp.Rational(11,4),
              "Mref_phi_squared":sp.Rational(13,5),"Mref_S_squared":sp.Rational(17,6)}
    subst = {**momenta,**masses,"xi":xi,"eta_H":eta}
    def matrix(name):
        return sp.SparseMatrix(643,643,{(i,j):sp.sympify(s,locals=subst) for i,j,s in data[name]})
    P,G = matrix("Preference"),matrix("Greference")
    h = sp.symbols("h_H h_M h_s")
    profile = sp.diag(*[h[0] if (i<48 or 508<=i<520 or 553<=i<565 or 598<=i<610)
                        else h[2] if 180<=i<508 else h[1] for i in range(643)])
    C_h = G*profile
    good = P*C_h if phase=="native" else C_h*P
    assert (good-profile).applyfunc(sp.cancel)==sp.SparseMatrix.zeros(643)
    tangent = P.diff(xi)*C_h+P*C_h.diff(xi) if phase=="native" else C_h.diff(xi)*P+C_h*P.diff(xi)
    assert tangent.applyfunc(sp.cancel)==sp.SparseMatrix.zeros(643)
    assert P.diff(xi)*C_h!=sp.SparseMatrix.zeros(643)
    bad = profile.copy()
    bad[520,520] = h[0]
    mismatched = sp.cancel((P*bad*G)[520,48])
    assert sp.expand(mismatched-2*xi*(h[0]-h[1])/15)==0
    return 643


def graph(phase):
    ex = Exterior()
    J,c = [ex.variable(k,1) for k in ("J","c")]
    x,y,z = [ex.variable(k,0) for k in ("x","y","z")]
    A = ex.mul(J,c,x,x)
    B = ex.mul(y,y,y)
    D = ex.mul(z,z)
    def contract(poly,pairs):
        for a,b in pairs:
            poly = ex.partial(ex.partial(poly,a),b)
        return poly
    edges = (("x","y"),("y","z"),("z","x"))
    vertex = ex.mul(A,B,D)
    out = ex.derive(contract(vertex,edges),{"J":x})
    inward = contract(ex.derive(vertex,{"J":x}),edges)
    if phase=="native":
        collapsed = [contract(ex.mul(ex.partial(A,"J"),ex.partial(V,j),W),
                              [e for e in edges if e!=omit])
                     for V,j,W,omit in ((B,"y",D,edges[0]),(D,"z",B,edges[2]))]
    else:
        collapsed = []
        for a,b in (edges[0],edges[2]):
            a,b = ("x",a if b=="x" else b)
            keep = [e for e in edges if frozenset(e)!=frozenset((a,b))]
            collapsed.append(contract(ex.partial(ex.partial(vertex,"J"),b),keep))
    assert out and inward and all(collapsed)
    assert ex.add(inward,ex.scale(out,-1))==ex.add(*collapsed)

    # Odd Euler edge with an even source. Its left ordinary derivative
    # carries the ordering of the odd target at the adjacent vertex.
    J_o = ex.variable("J_o",0)
    e,u,v = [ex.variable(k,1) for k in ("e","u","v")]
    odd_source = ex.mul(J_o,x,x)
    odd_target = ex.mul(u,v,y)
    odd_vertex = ex.mul(odd_source,odd_target,D)
    odd_edges = (("e","u"),("y","z"),("z","x"))
    ordered = contract(ex.derive(odd_vertex,{"J_o":e}),odd_edges)
    expected = contract(ex.mul(ex.partial(odd_source,"J_o"),
                               ex.partial(odd_target,"u"),D),odd_edges[1:])
    assert expected and ordered==expected
    reversed_edge = contract(ex.derive(odd_vertex,{"J_o":e}),
                             (("u","e"),*odd_edges[1:]))
    assert reversed_edge==ex.scale(expected,-1)
    return True


def check(phase):
    slots = ordered_inverse(phase)
    assert graph(phase)
    data = json.loads((C/"canonical_so10_YY_width_compact_lower_companion_v3/result.json").read_bytes())
    delta = sp.sympify(data["checks"]["alternating_PG_difference_before_common_phase_and_radial"])
    assert sp.simplify(delta+19*(1+sp.log(sp.Rational(3,2)))/4008)==0
    base,decor = sp.symbols("base decor")
    F = decor-base
    assert F.subs({base:0,decor:0})==0
    assert F.subs({base:0,decor:-delta})==-delta
    return {
        "ordered_actual_inverse_slots":slots,
        "even_and_odd_collapse_controls":True,
        "fixed_decorated_first_difference":"0",
        "fixed_ordinary_only_can_change_result":True,
        "G_shift_needed_before_common_factors":str(-delta),
    }


if __name__=="__main__":
    run_worker(check,sys.argv[1])
