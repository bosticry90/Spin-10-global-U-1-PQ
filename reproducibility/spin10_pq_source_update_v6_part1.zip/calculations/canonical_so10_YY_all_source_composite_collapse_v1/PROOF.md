# All-source first difference under the strict composite equation

Use the fixed reference R, the V876 ordered source chart and
one compact common map. Let d be the odd linearized reference
master, so dV=B'_R V. It acts only on the retained source
coordinates. Write B'_R V=integral F_i(V) E_i R in the
inherited left convention. The two factors interchange
without a Koszul sign since their parities are complementary.

At the first nonzero difference D3 of one-loop vertex maps,
the polarized t3 difference of the relative master is

    d D3(V1,V2,V3) - sum_l D3(V1,...,d Vl,...,V3).

All other terms in the master coefficient depend on lower
maps. The lower maps in this statement include their complete
source, decorated and derivative products, and the same-vertex
initial Wick and local insertion assignments. The labels can
be independent. Work before setting ordinary fields or BV
sources to zero.

An exterior Euler E_i R in the second term is the same
uncontracted spectator supplied by the first term. This
holds by source and field independence of the returning
kernel. Jet adjoints commute with this replacement by the
Action Ward identity. It cancels slot by slot for every
source. One can first move dVl past the two other even
vertices and keep its source Euler before E_i R. There is
no additional sign in that permutation.

The remaining possibilities return the one linear Euler
leg to another vertex Vm. The commutator of a single
ordered cross contraction with d is obtained by
differentiating the linear E_i R in the contracted field
slot. The result is the ordered free Hessian times the
propagator. The signs of the left derivative of Vm are
the signs of moving the returning field through its
prefix. The free ordered identity reduces this slot to
the identity in the common graded field type, with the
collapsed profile retained. No field equation is imposed
on a mean field. For source and field jet derivatives the
identity is differentiated on the two endpoints. Only
then does the product rule move the derivatives onto
compact labels and exterior tests. Commuting the Euler
operator through a compact multiplier beforehand would
lose this distinction.

On each triangle this leaves two edges and a fused
operator F_i(Vl) times the ordinary left derivative of
Vm, sewn to Vn in its remaining order. The decorated
lower product includes the collapsed-edge attachment
and its differentiated versions. At finite regulator the
profile is a kernel. It cannot be replaced by an
undecorated coincidence delta before extension. The
same ordered derivation uses P C_h or C_h P according
to orientation. At fixed matched h its charged-width
derivative has both P' C_h and P C_h' and is zero.

The strict composite premise for a first difference
identifies each internally returned E_i R with the
difference of that decorated lower product, retaining
all local coincidence and derivative-current data.
If those products are fixed through first width, all
such differences vanish. Therefore no new D3 that
obeys this premise can change the displayed leading
relative master. The conclusion covers all source
directions. It includes the V1124 external-source
cancellation and gives a sufficient condition to
exclude every similar source-only adjustment at fixed
decorated lower data.

V1122 requires a nonzero first-width G shift in the
declared H composite equation. The strict fixed-product
class supplies zero new shift. Fixing ordinary lower
T2 alone would leave a decorated or coincident
composite difference available. Neither the linear
off-shell field equation nor GQAP1's locality statement
imposes this strict composite premise. Brennecke and
Dütsch distinguish the linear equation and the anomalous
composite Ward condition in Remark 5.1 and section 5.2.
Dütsch and Boas retain derivative contacts in their
composite equation (95). We use the actual ordered
collapse as a conditional calculation, without assuming
those general results settle model-specific A4.

The code checks every ordered inverse slot on an
exact momentum and mass fixture, both symbolic
widths, opposite orientations and an unmatched
profile. The inherited V791 identities supply the
general momentum result. Independent polarized graph
checks retain even and odd Euler placements and
their signed collapse. The two routes share the
model and its symbolic implementation. The result
does not decide the complete sum of all independently
allowed composite terms, an interacting higher-order
master equation, or the causal profile limit.

[Primary causal QAP paper](https://arxiv.org/abs/0801.1408)
[Primary Master Ward paper](https://arxiv.org/abs/hep-th/0111101)
