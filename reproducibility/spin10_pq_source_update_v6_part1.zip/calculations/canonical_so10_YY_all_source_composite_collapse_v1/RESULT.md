# V1125 — All-source composite collapse at fixed lower products

At the first difference of cubic one-loop maps, the
leading relative master has two placements. The exterior
free Euler cancels between them for every retained source.
The internal free Euler reduces to an ordered decorated
two-vertex product. Its difference is zero when those
decorated products and their derivative and source
assignments are fixed through first charged width.

Under this strict composite premise a new cubic map
cannot supply the nonzero V1122 G shift. Fixing only the
ordinary two-vertex products leaves a separate composite
contact available. The linear field equation and the
locality of the anomaly do not impose the stricter premise.

The calculation checks all 643 ordered inverse slots
at a nonexceptional fixture with symbolic widths, both
sign orientations and a mismatched-profile control.
Independent even and odd graph fixtures retain the
contracted Euler and its Koszul sign. The evidence
shares the reference, action, software and AI authorship.

The result excludes the strict fixed-product strategy
on the declared relative equation. It leaves the full
common finite map and causal profile comparison open.
