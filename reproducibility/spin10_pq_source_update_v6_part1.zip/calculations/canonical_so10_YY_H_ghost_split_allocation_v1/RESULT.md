# Conditional four-cut H-ghost obstruction

With the projected grouped Euler rows
and the normalized H quartet pair on
each forward split, the sum of the
three ghost increments equals the
V1086 tag. Redistributing the individual
forward shifts cannot change that sum.

The remaining charged ghost split has
rank-one color on the three fixtures.
It vanishes at inherited weights and
cannot cancel the forward sum even
with arbitrary weights per H ideal on
that same tensor. The exact residual
left witness is -57/5344 per charge.

This excludes the specified ideal
split class at fixed lower derivative
and regulator. The lower compact
transfer, more general numerical
colors, and actual W3/W5 applicability
remain to be checked.
