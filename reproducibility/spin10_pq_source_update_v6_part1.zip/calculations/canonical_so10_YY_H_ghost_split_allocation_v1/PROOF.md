# Four H-ghost splits under the projected normalized equations

Retain the actual V1101 ordered H-ghost product.
For the three charged vector splits the Y jet
has ports BB, B Lambda, or Lambda B on X-Y-F.
The reverse split has a charged ghost vertex on
G-Y-X and the charged BB return stays unsplit.
In all four H preimages F returns d a_H and
G returns B_H. The paired substitutions of
V1100 apply at that same closure. With the
literal free Q0 action on every returning port,
only these two substitutions complete the
chosen cycle. Varying any other port leaves
the H pair uncontracted. The extra H odd
pair is adjacent, and the signed H Fourier
factors have opposite signs. The charged
spectator type does not alter that relation.

For each of the three forward cuts let h_i
be the signed H mixed increment and g_i its
H ghost partner. Under normalized global Q0
on each tagged preimage, g_i+h_i=0. These
are conditions on the local extension. Bare
quartet contraction alone does not impose
them. Both auxiliary orientations are kept
and individual h_i may vary.

Write m_L,a_L,m_H for the signed L Maxwell,
L mixed and H Maxwell increments summed
over the forward cuts. The V1099 projected
premises give

    m_L+a_L=0, m_H+sum h_i=0, m_L+m_H=0.

Keep the converted V1086 tag a_L=s. Combining
the seven rows gives sum g_i=s exactly. The
row witness uses minus the L and H Euler rows,
plus the swap, all three Q0 rows, and the tag.
This conclusion holds even if the forward
contact is redistributed among Maxwell and
the two mixed splits.

On the reverse charged ghost split the same
literal F and G endpoints each carry the
opposite sign to the old ordinary endpoint.
Their product agrees. The center skew matrix
is inserted on the returning a_X to C_G
link, giving T J instead of J T. The two
literal charts sew this color with the same
H ideal projectors and L projectors. The
reverse matrix factors as

    (-3/20,1/16,1/16)^T (1/60,3/4,4/3).

It vanishes at inherited W_LL. Even assigning
arbitrary ideal weights on this one reverse
typed color tensor gives only a rank-one
image. The left witness (0,1,-1) annihilates
it but pairs with the fixed forward sum s
to give -57/5344 per charge. Reassigning
weights on that tensor cannot cancel the
full forward sum.

Thus the selected fixed-lower reference
identity, the grouped Euler premises,
normalized Q0 on these forward preimages,
and the converted tag cannot all hold in
this split class. This adds a rank
obstruction to V1101's missing-sum test.
The conclusion is conditional on common
ideal-factorized reverse colors, the exact
normalized premises, and a fixed lower
reference derivative and regulator. It
does not decide an arbitrary local tensor
with more general color correlations, a
compensating lower transfer contact, or
the absolute W3/W5 identity.
