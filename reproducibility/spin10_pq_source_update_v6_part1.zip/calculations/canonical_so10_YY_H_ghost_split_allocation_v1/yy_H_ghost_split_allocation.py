"""Test all four splits under the projected Euler and free-Q0 premises."""
from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker

C = ROOT / "calculations"


def load(folder,worker):
    spec = spec_from_file_location(worker,C/f"canonical_so10_YY_{folder}"/f"{worker}.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal(phase):
    two = load("neutral_two_pair_ordinary_W3_v1","yy_neutral_two_pair_ordinary_W3")
    f,P,S,Q,h,charge,modes,flat = two.inputs(phase)
    raw = flat.ordinary.alg.read(C/"canonical_so10_unprobed_compact_all_coupling_v1"/
                                 f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    ports = flat.ordinary.ports
    F,Ga,Hmaster = defaultdict(lambda:sp.S.Zero),{},{}
    for g,word,cells in raw:
        if g!=1 or len(word)!=3:
            continue
        (i,di),(j,dj),(k,dk) = word
        if 553<=i<565 and 610<=j<643 and 1253<=k<1286:
            assert not (di or dj or dk)
            Ga[i-553,j-598,k-1241] = ports.decode(cells,1,False)
        if 48<=i<180 and i%4==0 and 565<=j<598:
            if 598<=k<610:
                assert sorted(di+dj+dk)==[0]
                F[i//4,k-598,j-553] += (int(bool(dk))-int(bool(di)))*ports.decode(cells,1,False)
            elif 643<=k<691 and (k-643)%4==0:
                assert not (di or dj or dk)
                Hmaster[i//4,(k-643)//4,j-553] = -ports.decode(cells,1,False)
    F = {k:v for k,v in F.items() if v}
    Gexpect = {(h,b,e):z for h,b in product(range(12),range(12,45)) for e,z in f[h,b]}
    Fexpect = {(u,h,c):z for u,h in product(range(12,45),range(12)) for c,z in f[u,h]}
    assert Ga==Gexpect and F==Fexpect and len(F)==len(Ga)==334
    assert Hmaster=={k:-v for k,v in F.items()}
    assert Ga=={(h,b,e):-v for (h,e,b),v in Ga.items()}
    H,M = flat.ideal.H,flat.ideal.M
    J = sp.zeros(33)
    for i,z in h.items():
        for k in M:
            for b,v in f[i,k]:
                J[b-12,k-12] += z*v/charge
    L = S[3]
    J = (L*J*L).applyfunc(sp.simplify)
    c,d,e,v = modes
    d3 = {27:sp.Rational(1,2),32:-sp.Rational(1,2)}
    d4 = {28:sp.Rational(1,2),31:sp.Rational(1,2)}
    rows, reverse = [], []
    for b,c1,c2,a in ((d,c,d,d),(c,c,e,v),(c,c,d3,d4)):
        value, back = sp.zeros(3,1), sp.zeros(3,1)
        for cx,cf,s in ((c1,c2,1),(c2,c1,-1)):
            T = flat.images.matrix({
                (u-12,w-12):sum(z*t*Q[u,k,l,w] for k,z in b.items() for l,t in cx.items())
                for u,w in product(M,repeat=2)})
            Fport = {h:flat.vec({u:sum(z*F.get((u,h,k),0) for k,z in cf.items())
                                 for u in M}) for h in H}
            Gport = {h:flat.vec({u:sum(z*Ga.get((h,k,u),0) for k,z in a.items())
                                 for u in M}) for h in H}
            if phase=="native":
                value += s*flat.trace(P,S,J*T,Fport,Gport,3,3)
                back += s*flat.trace(P,S,T*J,Fport,Gport,3,3)
            else:
                X = {h:L*Fport[h] for h in H}
                def sew(A):
                    Y = {h:A*L*Gport[h] for h in H}
                    return sp.Matrix([sp.expand(sum(P[i][h,k]*sum(X[h][l]*Y[k][l] for l in range(33))
                                      for h,k in product(H,repeat=2) if P[i][h,k]))
                                      for i in flat.ideal.spectra])
                value += s*sew(J*T)
                back += s*sew(T*J)
        rows.append(value.applyfunc(sp.simplify))
        reverse.append(back.applyfunc(sp.simplify))
    W = sp.Matrix(flat.family.representative()[0][3,3])
    W += sp.Matrix(flat.family.direction()[0][3,3])/1002
    measured = [sp.simplify(v.dot(W)) for v in rows]
    return measured, sp.Matrix.vstack(*(row.T for row in reverse)), W


def signs():
    I = sp.I
    k = sp.Matrix(sp.symbols("k:4"))
    Q = k.dot(k)
    H_mixed = (-I)*(I*k)*(k.T/Q)
    H_ghost = (I*k)*(-I*k.T)*(-1/Q)
    assert H_mixed == -H_ghost and H_mixed != sp.zeros(4)
    # The extra odd pair is adjacent and contributes no Wick
    # crossing. The returning L pair gains two intervening slots.
    def gap(w,a,b):
        return w.index(b)-w.index(a)-1
    old = ["s","v","f","cv","a"]
    new = ["s","v","f","ah","ch","cv","a"]
    assert gap(new,"ah","ch")==0 and gap(new,"v","cv")==gap(old,"v","cv")+2

    # At G, C_H box C_L and the balanced derivative pair have
    # opposite local symbols after the total-transfer term.
    p,q = sp.Matrix(sp.symbols("p:4")),sp.Matrix(sp.symbols("q:4"))
    lap = -q.dot(q)
    balanced = -p.dot(q)
    assert sp.expand(lap+balanced+(p+q).dot(q))==0
    assert sp.expand(lap.subs(dict(zip(q,-p)))+balanced.subs(dict(zip(q,-p))))==0
    return "-1"


def preimages():
    allowed = {("B","B"),("B","l"),("l","B"),("C","a"),("a","C")}
    rule = {"B":"C","a":"l"}
    inherited = {"Xf":"B","Xg":"a","Fx":"B","Fg":"a","Gf":"B","Gx":"C"}
    common = [("Fg","Gf")]
    counts = []
    for left,right in (("B","B"),("B","l"),("l","B"),("a","C")):
        reverse = left=="a"
        word = {**inherited,"Yleft":left,"Yright":right}
        if reverse:
            edges = [*common,("Xf","Fx"),("Gx","Yleft"),("Yright","Xg")]
        else:
            edges = [*common,("Xf","Yleft"),("Yright","Fx"),("Gx","Xg")]
        surviving = []
        for port,species in word.items():
            if species in rule:
                image = {**word,port:rule[species]}
                if all((image[u],image[v]) in allowed for u,v in edges):
                    surviving.append(port)
        assert surviving==["Fg","Gf"]
        counts.append(len(surviving))
    assert signs()=="-1"
    return counts


def certificate(forward,reverse,W):
    r = sp.Rational
    kappa = sp.Matrix([[r(1,60),r(3,4),r(4,3)]])
    factors = sp.Matrix([-r(3,20),r(1,16),r(1,16)])
    assert reverse == factors*kappa
    assert reverse.rank()==1 and reverse*W==sp.zeros(3,1)
    assert forward==[0,-r(19,5010),r(19,10020)]
    path = C/"canonical_so10_YY_H_ghost_composite_v2/result.json"
    measured = json.loads(path.read_bytes())["checks"]["conditional_extra_H_ghost_proper_per_j"]
    s = sp.Matrix(list(map(r,measured)))
    assert s == -r(-15,8)*sp.Matrix(forward)

    # Variables m_L,a_L,m_H, three H mixed values and three ghosts.
    E = sp.eye(9)
    mL,aL,mH = [E.row(i) for i in range(3)]
    h = [E.row(i) for i in range(3,6)]
    g = [E.row(i) for i in range(6,9)]
    h_sum = sum(h,sp.zeros(1,9))
    g_sum = sum(g,sp.zeros(1,9))
    pair_rows = sp.Matrix.vstack(*(a+b for a,b in zip(h,g)))
    M = sp.Matrix.vstack(mL+aL,mH+h_sum,mL+mH,pair_rows,aL)
    y = sp.Matrix([[-1,-1,1,1,1,1,1]])
    assert y*M==g_sum
    z = sp.Matrix([[0,1,-1]])
    assert z*reverse==sp.zeros(1,3)
    assert (z*s)[0]==-r(57,5344)
    assert reverse.row_join(s).rank()==2
    return {"reverse_color_rank":int(reverse.rank()),
            "reverse_color_pivot_multiples":list(map(str,factors)),
            "forward_total_row_witness":[int(t) for t in y],
            "reverse_arbitrary_ideal_left_witness_value":str((z*s)[0])}


def check(phase):
    forward,reverse,W = literal(phase)
    return {"H_pair_surviving_variations":preimages(),
            **certificate(forward,reverse,W)}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
