"""Check the relative-coordinate Action Ward balance for the YY kernel."""

import gzip
import json
import sys

import sympy as sp

from execute import HERE, run_worker


def actual_kernel(phase):
    owners = HERE.parent
    free = owners / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(free / f"{phase}_inverse.json.gz", "rt", encoding="utf-8") as file:
        inverse = json.load(file)
    G = {(i, j): sp.sympify(expr) for i, j, expr in inverse["Greference"]}
    P = {(i, j): sp.sympify(expr) for i, j, expr in inverse["Preference"]}
    Q = sum(q**2 for q in sp.symbols("q0:4"))
    for i, stop, label in ((180, 234, "Phi"), (234, 486, "Sigma")):
        M = sp.Symbol(f"Mref_{label}_squared")
        for x in range(i, stop):
            assert G[x, x] == 1/(Q+M) and P[x, x] == Q+M
    for c in range(565, 598):
        a = c + 45
        assert G[c, a] == 1/Q and G[a, c] == -1/Q
        assert P[c, a] == -Q and P[a, c] == Q
    yy = owners / "canonical_so10_YY_source_necessity_v2"
    result = json.loads((yy / "result.json").read_bytes())["checks"]
    assert result["two_species_rank_determinant"] == "-7650"
    assert result["complete_raw_E_projection_is_minus_YY"]
    return {"scalar_block_sizes": [54, 252], "M_ghost_pairs": 33,
            "YY_two_species_rank_determinant": "-7650"}


def contact_balance():
    M = sp.Symbol("M", positive=True)
    lam, a, b = sp.symbols("lambda d_A d_B", real=True)
    delta, lap = sp.symbols("delta Laplace_delta")
    xy = sp.symbols("r0:4")
    A, B = sp.Function("A")(*xy), sp.Function("B")(*xy)
    laplace = lambda f: sum(f.diff(x, 2) for x in xy)
    collapse = ((-laplace(A)+M*A)*B, -A*laplace(B))
    current = sum((A.diff(x)*B-A*B.diff(x)).diff(x) for x in xy)
    assert sp.expand(collapse[0]-collapse[1]+current-M*A*B) == 0

    difference = (b-a)*lap + M*lam*delta
    normal = sp.Poly(difference, delta, lap)
    assert normal.coeff_monomial(delta) == M*lam
    assert normal.coeff_monomial(lap) == b-a
    assert sp.solve([a+b-lam, *normal.coeffs()], [a, b, lam]) == {a: 0, b: 0, lam: 0}

    # Rank-two local tensors in the independent delta and second-derivative basis.
    H = sp.Matrix(4, 4, lambda i, j: sp.Symbol(f"H{min(i,j)}{max(i,j)}"))
    Id = sp.eye(4)*delta
    for metric, expected in ((M*lam/4, (0, -M*lam*delta)),
                             (0, (M*lam*delta, 0))):
        AA, BB = metric*Id, metric*Id
        AB = lam*H/2 - metric*Id
        assert AA+AB == lam*H/2 and BB+AB.T == lam*H/2
        assert AA+BB+AB+AB.T == lam*H
        assert (M*lam*delta-sp.trace(AA), -sp.trace(BB)) == expected

    return {"composite_difference_zero_jet": "M*lambda",
            "composite_difference_laplace_jet": "d_B-d_A",
            "both_contacts_fixed_only_if_lambda_zero": True,
            "second_derivative_AWI_allocations": ["keep_scalar_Euler", "keep_ghost_Euler"]}

def radial_check():
    e, M, mu2, s, L = sp.symbols("e M mu2 s L", positive=True)
    kappa = sp.Symbol("kappa", real=True)
    bubble = sp.gamma(e)*M**(-e)/(1-e)
    tadpole = sp.gamma(e-1)*M**(1-e)
    assert sp.simplify(sp.expand_func(tadpole + M*bubble)) == 0
    residues = [sp.limit(e*z, e, 0) for z in (bubble, tadpole)]
    assert residues == [1, -M]
    cut_bubble = sp.integrate(1/(s+M), (s, 0, L))
    cut_tadpole = sp.integrate(s/(s+M), (s, 0, L))
    assert sp.simplify(cut_tadpole + M*cut_bubble-L) == 0
    offset = kappa-1-sp.log(16*sp.pi)
    finite = sp.limit((4*sp.pi*mu2)**e*bubble-1/e, e, 0)+offset
    assert sp.simplify(finite-(sp.log(mu2/M)+kappa-sp.EulerGamma-2*sp.log(2))) == 0
    assert sp.diff(finite, kappa) == 1 and sp.diff(-M*finite, kappa) == -M
    phi, sigma = sp.symbols("M_Phi M_Sigma", positive=True)
    assert sp.simplify(finite.subs(M, phi)-finite.subs(M, sigma)
                       -sp.log(sigma/phi)) == 0
    return {"radial_pole_residues": list(map(str, residues)),
            "matched_common_kappa_slopes": ["1", "-M"],
            "two_species_difference": "log(M_Sigma/M_Phi)"}


def check(phase):
    return actual_kernel(phase) | contact_balance() | radial_check()


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
