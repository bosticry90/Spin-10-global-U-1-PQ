# V1000 · YY Euler contact balance

Completed a bounded numerical T2
Action Ward test for the V998
scalar–ghost contact. Native and
replay read their own complete
V791 reference inverses. The
literal check covers 54 Phi,
252 Sigma and 33 broken ghost
pairs with both ordered signs.

For each positive squared
reference mass M, a shift
lambda delta of the ordinary
bubble forces the difference
of its scalar and ghost
composite Euler contacts to
shift by M lambda delta plus
a second-derivative contact.
The two Euler contacts can
retain both old values only
when lambda=0. The V998
two-species matrix is
invertible and its common
normalization cokernel is
nonzero at distinct masses.
At least one composite
contact must then move.

Two explicit second-derivative
allocations obey the Action
Ward identity and local
reality and covariance.
One keeps the scalar contact
fixed and moves the ghost
contact by -M lambda delta.
The other keeps the ghost
contact fixed and moves the
scalar contact by +M lambda
delta. The independent radial
residues and common-kappa
slopes are +1 and -M.

This constrains a numerical
kernel for the reference
free operators. It leaves
open which choice belongs
to the actual physical Euler
and marked/source transports.
The scalar reference mass
insertion and the distinct
one-point tadpole must be
accounted for there. No weak
adiabatic limit or common
normalization is claimed.

See the [derivation](PROOF.md)
and [validation receipt](validation_receipt.json).
The E4 history path retains
seven unresolved custody
references. State and
scientific authority stay
at 113 and 34/39.
