# Action Ward relation for the two collapsed scalar–ghost contacts

Use the actual two-edge
numerical kernel of V998
on one reference scalar
block. Work in a Euclidean
relative coordinate r.
Write A=D_M for the
scalar inverse with
positive squared mass M
and B=D_0 for the ghost
inverse with its common
ordered sign stripped.
The zero-derivative
product AB has scaling
degree four. The proposed
real finite change is
lambda delta(r).
It is the individual
scalar–ghost T2 contact
that affects YY. It
carries the required
V998 source companion.

The inherited Action Ward
identity moves a total
derivative through the
local extension. If the
first-derivative changes
are d_A partial_mu delta
and d_B partial_mu delta,
then

    d_A+d_B=lambda.

There is no other
Lorentz vector at zero
external background.
Power counting gives
the first-derivative
order. The derivative
labels refer to the
same relative coordinate
on both numerical lines.

Define the collapsed
Euler products by

    E_s=[(-Laplace+M)A] B,
    E_g=A(-Laplace B).

These are named composite
products, with their
actual contact
normalization retained.
Their balanced derivative
relation is

    E_s-E_g
      = -partial_mu[(partial_mu A)B
                        -A(partial_mu B)]
          + M AB.

Under one common finite
normalization its change
is therefore

    delta_fin(E_s-E_g)
      = -(d_A-d_B) Laplace delta
                           + M lambda delta.

The two distributions
delta and Laplace delta
are linearly independent.
Thus when M>0 and
lambda is nonzero, the
two collapsed contacts
cannot both retain their
old values. Choosing
a different derivative
allocation can change the
Laplace contact but cannot
change the mass-weighted
zero jet. This is a
constraint on the
composite products,
separate from the fixed
linear ordinary source
equation in V918.

The obstruction is
nonblind in the actual
two-species YY test:
at distinct reference
masses at least one
required correction
lambda_s is nonzero
for every common
kappa. The positive
reference mass then
makes its Euler
difference nonzero.

## Two constructive local allocations

Use d_A=d_B=lambda/2.
Let H_mu,nu denote
partial_mu partial_nu
delta and set
I_mu,nu=delta_mu,nu
delta in four dimensions.
Use the following shifts
for the second derivative
on A, the second
derivative on B and
one on each:

    AA=BB=h I,
    AB=(lambda/2) H-h I.

The first derivative
AWI gives
AA+AB=(lambda/2) H
and BB+AB^T=(lambda/2) H.
The total second
derivative gives
AA+BB+AB+AB^T=lambda H.
A derivative at the
second endpoint has
the opposite relative
sign. The shifts are
real and O(4) covariant
and their polynomial
symbols continue as
Lorentz-covariant
local distributions
with the inherited
metric convention.

The scalar Euler shift
is (M lambda-4h) delta.
The ghost Euler shift
is -4h delta. For
h=M lambda/4 this
keeps the scalar Euler
contact fixed and
moves the ghost Euler
contact by -M lambda
delta. For h=0 it
keeps the ghost Euler
contact fixed and
moves the scalar Euler
contact by +M lambda
delta. These are
numerical T2 contact
allocations through
rank two. The choice
between them has not
been made for the
physical/source parent.

## Independent radial check

Strip 1/(16 pi²).
In d=4-2e, the
one-mass two-line
bubble at zero
transfer is

    B0=Gamma(e) M^(-e)/(1-e).

The collapsed massive
tadpole is

    J1=Gamma(e-1) M^(1-e).

The massless tadpole
is scaleless in this
radial prescription.
The Gamma recurrence
gives J1+M B0=0.
The residues are
+1 and -M. The hard
radial integrals also
satisfy J1(L)+M B0(L)=L,
where L is the squared
momentum cutoff. This
checks the relative
mass sign by a
different construction.
The V882 converted
common-kappa slopes
are +1 and -M in
the same units. Its
finite constant
difference between
the two positive
reference mass tags
is log(M_Sigma/M_Phi).

The scalar Euler
collapse here uses
the reference free
operator -Laplace+M.
The physical scalar
Euler placement
differs by the
reference mass
insertion, which
must be carried in a
full transport.
The massive
coincidence contact
above is an ordered
two-vertex
composite Euler
product. A separate
one-point tadpole,
linear field
equation, actual
marked insertion,
and global weak
adiabatic limit
each require their
own applicability
check. No change to
any of those
normalizations is
inferred here.
