# V1000 pre-execution contract

Freeze V999, V998, V916, V882
and the inherited COS1 Action
Ward identity. Use the actual
scalar–ghost numerical T2
kernel on one positive reference
mass block. Derive the relation
between its degree-zero finite
shift and the two collapsed
Euler contacts. Require a
no-go test for keeping both
contacts fixed and a real
Lorentz-covariant local
allocation through second
derivatives. Verify the
mass sign by the existing
common-kappa radial route.
No new composite contact
or common map is adopted.

Native 120 s, final 180 s
including E4 cap 120 s,
8 GiB sampled private,
350 MiB launch floor,
8 MiB artifact and
32 MiB packet.
