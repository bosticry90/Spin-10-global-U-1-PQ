# Direct aCC finite hard-heat coefficient

Continue24178e73b583db84fb2677f04dee095bc0c72c07/main,V817, currentAGENTS,
D:repo, no live matching workers and clean tree at preflight. Previous goal
turn PROGRESS: actual polarized operators/kernel diagnostics qualified. Goal
remains full investigation, not a helper. State113/34of39,E5/A5open unchanged.
No branch/worktree, agents, adoption, protectedactivation/promotion, push or
externalaction. Flavorpaused,HB1/C5blocked;educationvoluntary/nonblocking.

Question: independently derive the actual pure-heat hard external-Taylor
degree2 coefficient of the selected aCC one-loop current. This is a concrete
missing finite calculation, not another leading-power catalog. Outcomes may
be nonzero/zero coefficients, a representation failure, an analytic gap or
bounded exhaustion. No unknown coefficient is fitted. Deny V814 dependent
finite prediction and assembled known remainder through construction.

Same original Euclidean action, firstg/firstu_M, intrinsic01, all33 internalM/
all4B/231fields, two polarized ghosts and one antighost. Use frozen V817
source-first polynomials for base(C0,C14;a13), H(C13,C14;a0), M(C13,C14;a12),
and initially execute only base. Assess before further cases. All existing
same-color qualifications/limitations retained; no full finite-color claim.

For the LOCAL quadratic Taylor polynomial, SO(4) invariance means integrated
form alpha p²+beta p.r+gamma r². Put p=x e0,r=y e0 to recover those three
coefficients. Keep loop q=(v,w,0,0) with BOTH v and w, all4 quantum B
components, and s=v²+w². Residual SO(3) around the external axis lets this
represent any transverse loop orientation. This is NOT alignment q||p and
not a two-dimensional loop measure. Full V817168 operator covariance checks
justify this restriction for the scalar contraction, not a nonlocal function.
Canonical ring w²=s-v²; full S3 angular mean v^(2k)=(1/2)_k/(2)_k s^k.
Odd-w scalar terms must vanish before averaging. Odd-v averages zero.

Coefficient keys u,mask,inputS,xdegree,ydegree,vpower,wparity,spower,
heatpower,tpower. Quotient only external Taylor degree<=2, probe<=1 and
g<=1, with actual odd-marker signs and shifted subset composition. Primitive
numerators are exact substitutions of the full12variable frozen compiler.
Free propagators use shifted s+2v h+h² and heat
 E(q+h e0)=E(q)[1-2t v h-t h²+2t²v²h²] through degree2,
 h=(S_p-S_a)x+(S_r-S_a)y. Endpoint amputation removes inverseheat first.
Never omit heat derivatives or introduce a new finite subtraction.

First verification stage120s afterimports,8GiB sampled/350MiB floor,
64MiB packet/10MiB artifact. Independently differentiate actual shifted
free7block functions with SymPy, compare generic formal v,w,t,xi Taylor
patterns; prove both inverse products H G0=G0 H=Fshift I, actual primitive
free specialization, and angular/Gamma/Frullani moments. Wrong omitted heat
derivatives and wrong axial angular average must give explicit nonzero
controls. Sources/inputs frozen before computation, complete capture retained.

Separate actual contraction stage300s afterimports PER declared color case,
same memory/storage bounds, frozen before launch. Build T=G0 star N,
B=I-T+T²,Gbase=B star G0, D_H=-Gbase star H star B. Target is
 -(1-E(q)) sum_i(-1)^pi [M_F star Gbase star H star B]_ii.
Use factor L=M_F Gbase,R=H B and complementary mean/inputsubset selection
BEFORE scalar products, preserving full coefficient order and target.
Compute both F1/Hu and Fu0/Hg roots, all Taylor coefficients. Store complete
selected Laurent symbols and branch contributions; intermediates can be
reconstructed from frozen source, not silently truncated to fit a cap.
Zero external order must match the complete previously qualified constant
profile symbol, including its zero in base/H. Canonical dimensions must force
alpha_radial=2+spower+vpower/2=tpower at external degree2. Positive heat powers
only. For alpha>0 use Gamma(alpha)/n^alpha. For alpha=0 require COMPLETE
sum_n c_n=0 before Frullani -sum_n c_n log(n). Retain actual g/xi/radicals;
canonicalize log(n) by its prime factors, no coupling division or fitting.
Unexpected negative alpha, remaining log(t), odd-w scalar or failed recovery
fails the stage. Exhaustion means incomplete, preserve sources/captures and
partial results; no automatic retry or silent resource expansion.

Hard coefficient alone is NOT the physical finite reference. Need a separate
WHOLE UV-first/IR-second Schwartz remainder/soft-profile/contact proof for
F=f_delta E. The old leading O(sqrt(t)) proof does not suffice. Report
PUREHEAT_HARD_COEFFICIENT_ONLY until that bridge is earned. No common
normalization/restoration, QAP/measure/sourceproducts, E5/A5 or physical
viability claim. Shared action/ring/Python/SymPy/AIauthor limit independence;
no external endorsement/Lean/empirical test. Final validation/E4one and local
commit separate; custodyexit2/seven unresolved staysNOTPASS.
