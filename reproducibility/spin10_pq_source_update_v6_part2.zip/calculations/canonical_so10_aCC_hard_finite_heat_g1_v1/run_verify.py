from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-hard-finite-heat-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_aCC_finite_momentum_operator_g1_v1':['polarized_polynomial.py','wave_algebra.py','polarized_base.json.gz','polarized_H_antighost.json.gz','polarized_all_M.json.gz','validation_receipt.json','PROOF.md'],'canonical_so10_aCC_direct_UV_symbol_g1_v1':['symbol_ring.py','gaussian_base.json.gz','gaussian_H_antighost.json.gz','gaussian_all_M.json.gz','validation_receipt.json','UV_BRIDGE_PROOF.md']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V817.md']+['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','heat_ring.py','verify_taylor.py','run_verify.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'verify_taylor.py')]);dump(O/'Taylor_capture.json',cap);dump(C/'Taylor_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
