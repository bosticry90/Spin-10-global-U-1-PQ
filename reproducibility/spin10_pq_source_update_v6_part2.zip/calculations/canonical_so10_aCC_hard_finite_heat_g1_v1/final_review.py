from pathlib import Path
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-hard-finite-heat-g1-v1-2026-11-07')
def mod(n,p):
 s=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(s);s.loader.exec_module(z);return z
v=mod('fresh_hard_Taylor',O/'verify_taylor.py');c=mod('fresh_hard_contraction',O/'contract.py');w=mod('fresh_hard_literal',O/'literal_replay.py');r=v.r;J=r.J;read=r.read;load=r.load;digest=r.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(420,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','contraction_preparation_base.json','contraction_preparation_H_antighost.json','contraction_preparation_all_M.json','replay_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps=[]
 for cn,rn,bound in [('Taylor_capture.json','Taylor_result.json',120),('hard_capture_base.json','hard_result_base.json',300),('hard_capture_H_antighost.json','hard_result_H_antighost.json',300),('hard_capture_all_M.json','hard_result_all_M.json',300),('replay_capture.json','replay_result.json',240)]:
  cap=read(O/cn);res=read(O/rn);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['execution_state']=='COMPLETED'and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<s['private_bytes']<=8*1024**3 for s in cap['all_resource_samples']);caps.append(cap)
 assert [cap['launch']['creation_filetime']for cap in caps]==sorted(cap['launch']['creation_filetime']for cap in caps)
 artifacts=[];fresh=[]
 def compare_save(name,z):
  blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),('FRESH_ARTIFACT_DIFFERS',name);artifacts.append(name);return dict(file=name,sha256=__import__('hashlib').sha256(blob).hexdigest(),bytes=len(blob))
 def compare_dump(path,z):
  assert path.parent==O and path.name in ['Taylor_result.json','hard_result_base.json','hard_result_H_antighost.json','hard_result_all_M.json','replay_result.json'];saved=read(path);assert{k:v for k,v in saved.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'},path.name;fresh.append(dict(result=path.name,seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
 for module in [v,c,w]:module.r.save=compare_save;module.r.dump=compare_dump
 v.main();gc.collect()
 for case in ['base','H_antighost','all_M']:c.main(case);gc.collect()
 w.main();gc.collect();assert len(fresh)==5 and len(artifacts)==16 and len(set(artifacts))==16
 # Exact proof expressions checked independently in the original coefficient ring.
 from fractions import Fraction as Fr
 expected={'base':{(2,0,0):Fr(41,100),(2,0,2):Fr(-27,25),(2,0,3):Fr(18,25),(1,1,0):Fr(41,50),(1,1,2):Fr(-54,25),(1,1,3):Fr(36,25)},'H_antighost':{(a,b,n):cc*(2 if(a,b)==(1,1)else 1)for a,b in[(2,0),(1,1),(0,2)]for n,cc in[(2,Fr(54,25)),(3,Fr(-36,25))]},'all_M':{(a,b,n):cc for a,b in[(2,0),(0,2)]for n,cc in[(0,Fr(-373,225)),(2,Fr(108,25)),(3,Fr(-72,25))]}}
 expected['all_M'].update({(1,1,n):cc for n,cc in[(0,Fr(-404,225)),(2,Fr(144,25)),(3,Fr(-96,25))]})
 for case,exp in expected.items():
  actual={tuple(row[:3]):r.A.decode_coeff(row[3])for row in read(O/('hard_result_'+case+'.json'))['finite_hard_coefficients']};assert actual=={k:J.Coeff([((1,2,0,5),cc)])for k,cc in exp.items()},(case,'PROOF_EXPRESSION_DIFFERS')
  replay=load(O/('literal_replay_'+case+'.json.gz'));assert replay['all_actual_full_response_scalars_equal']and len(replay['whole_primary_scalar_routing_checks'])==2
  assert any(row['scalar_changed']for row in replay['all_modes_and_branches'])==(case!='H_antighost')
 print('STAGE all16_fresh_artifacts_identical_exact3_formulas_and_sensitive_blind_controls_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();pp=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=pp.returncode,seconds=time.perf_counter()-et,stdout=pp.stdout,stderr=pp.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert pp.returncode==0
 events=[json.loads(x)for x in pp.stdout.splitlines()if x.strip()];exits=[e['exit_code']for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(e for e in events if e['event']=='step_finished'and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V818.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='DIRECT_ACC_PUREHEAT_HARD_FINITE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_THREE_INTEGRATED_QUADRATIC_HARD_HEAT_SYMBOLS',scientific_acceptance='NOT_PERFORMED',status='PUREHEAT_HARD_COEFFICIENT_ONLY',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,failed_or_incomplete_workers=0,fresh_replays=fresh,complete_artifacts_freshly_recomputed=artifacts,all432_generic_shifted_free_Taylor_patterns=True,both_free_inverse_products_actual_frame_and_4D_moments=True,all3_actual_two_root_hard_contractions_and_complete_old_profile_recovery=True,all3_literal1848_matrix_complete_response_scalars_equal=True,all6_momentum_routing_checks_equal=True,wrong_heat_control_base_M_sensitive_H_blind=True,proof3_formulas_exact=True,prediction_and_known_remainder_read_denied=True,physical_whole_UV_IR_reference_and_full_finite_color_NOT_QUALIFIED=True,largest_sampled_private_bytes=max(s['private_bytes']for cap in caps for s in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_A5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
