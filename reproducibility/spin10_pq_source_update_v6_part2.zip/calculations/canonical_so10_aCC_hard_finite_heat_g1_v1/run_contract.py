from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-hard-finite-heat-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
case=sys.argv[1];assert case in ['base','H_antighost','all_M']
for n,h in json.loads((O/'preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'Taylor_result.json').read_bytes())['execution_state']=='COMPLETED'
if case=='base':
 for n in ['CONTRACTION_RECORD.md','contract.py','run_contract.py']:
  if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
else:
 for n,h in json.loads((O/'contraction_preparation_base.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
dump(O/('contraction_preparation_'+case+'.json'),dict(case=case,sha256={**json.loads((O/'preparation.json').read_bytes())['sha256'],**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'contract.py'),case]);dump(O/('hard_capture_'+case+'.json'),cap);dump(C/('hard_capture_'+case+'.json'),cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
