from pathlib import Path
from math import comb
import gc,importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('literal_hard_heat_data',Path(__file__).resolve().with_name('heat_ring.py'));r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r);J=r.J;O=r.O;R=r.R
# Ordinary commuting scalar key: u,x,y,vpower,wparity,spower,Epower,tpower.
def cput(out,key,c):
 u,a,b,k,l,v,e,h=key
 if u>1 or a+b>2 or not c:return
 for j in range(l//2+1):
  z=u,a,b,k+2*j,l%2,v+l//2-j,e,h;out[z]=out.get(z,J.ZERO)+c*(comb(l//2,j)*(-1)**j)
def cmul(P,Q):
 out={}
 for(u,a,b,k,l,v,e,h),c in P.items():
  for(uu,aa,bb,kk,ll,vv,ee,hh),d in Q.items():
   if u+uu>1 or a+b+aa+bb>2:continue
   z=J.Coeff([(key,val)for key,val in J.times(c,d).terms if key[0]<=1]);cput(out,(u+uu,a+aa,b+bb,k+kk,l+ll,v+vv,e+ee,h+hh),z)
 return r.clean(out)
def cadd(*ps):return r.add(*ps)
def cmm(P,Q):
 rows={};out={}
 for(k,j),d in Q.items():rows.setdefault(k,[]).append((j,d))
 for(i,k),c in P.items():
  for j,d in rows.get(k,[]):
   acc=out.setdefault((i,j),{})
   for key,v in cmul(c,d).items():acc[key]=acc.get(key,J.ZERO)+v
 return {ij:r.clean(P)for ij,P in out.items()if r.clean(P)}
def cma(*ps):
 out={}
 for P in ps:
  for ij,v in P.items():out[ij]=cadd(out.get(ij,{}),v)
 return {ij:P for ij,P in out.items()if P}
def cms(P,c):return {ij:r.scale(v,c)for ij,v in P.items()if r.scale(v,c)}
def embed(M):
 out={}
 for(i,j),P in M.items():
  for(u,m,S,a,b,k,l,v,e,h),c in P.items():
   # Direct literal concatenation of ordered exterior generators.
   left=[z for z in range(3)if m&(1<<z)];right=[z for z in range(3)if S&(1<<z)];sg=(-1)**sum(i>j for i in left for j in right);ij=8*i+(m|S),8*j+S;acc=out.setdefault(ij,{});key=u,a,b,k,l,v,e,h;acc[key]=acc.get(key,J.ZERO)+c*sg
 return {ij:r.clean(v)for ij,v in out.items()if r.clean(v)}
def closed_current(M,D):
 raw={}
 for(row,k),P in M.items():
  if row%8!=7:continue
  i=row//8;Q=D.get((k,8*i))
  if not Q:continue
  sg=-1 if i>=r.NB else 1
  for key,c in cmul(P,Q).items():
   if key[0]==1:raw[key]=raw.get(key,J.ZERO)+c*sg
 out={}
 for(u,a,b,k,l,v,e,h),c in r.clean(raw).items():
  # D already has its minus sign; outer factor is exactly 1-E(q).
  for ee,sg in [(e,1),(e+1,-1)]:key=u,7,0,a,b,k,l,v,ee,h;out[key]=out.get(key,J.ZERO)+c*sg
 return r.clean(out)
def deriv(P):
 out={}
 for(u,m,S,a,b,k,l,v,e,h),c in P.items():
  for kk,vv,ee,hh,factor in [(k-1,v,e,h,k),(k+1,v-1,e,h,2*v),(k+1,v,e,h+1,-2*e)]:
   if factor:r.put(out,(u,m,S,a,b,kk,l,vv,ee,hh),c*factor)
 return r.clean(out)
def shift_external(P,a,b):
 out={}
 for(u,m,S,aa,bb,k,l,v,e,h),c in P.items():r.put(out,(u,m,S,aa+a,bb+b,k,l,v,e,h),c)
 return r.clean(out)
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in r.read(O/'replay_preparation.json')['sha256'].items():assert r.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'FINITE_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 H0,G0,F=r.free();I={(i,i):{(0,0,0,0,0,0,0,0):r.one}for i in range(8*r.TOTAL)};results=[];heat_sensitive=False
 for case in ['base','H_antighost','all_M']:
  src=r.load(O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1'/('polarized_'+case+'.json.gz'));M={k:embed(r.from_primitive(r.p.dm(P)))for k,P in src['matrices'].items()};N=embed(r.from_primitive(r.p.dm(src['N'])));primary=r.read(O/('hard_result_'+case+'.json'));saved=r.load(O/primary['base_artifact']['file']);roots=[]
  for mode in ['actual','wrong_no_heat_derivatives']:
   fg=G0 if mode=='actual'else{ij:{key:c for key,c in P.items()if key[9]==0}for ij,P in G0.items()};fg={ij:P for ij,P in fg.items()if P};g=embed(fg);T=cmm(g,N);T2=cmm(T,T);assert not cmm(T2,T);B=cma(I,cms(T,-r.one),T2);base=cmm(B,g)
   if mode=='actual':assert base==embed(r.dm(saved['Gbase'])),'LITERAL_WHOLE_GBASE_DIFFERS'
   for row in primary['branches']:
    hl='Eu0_1'if row['branch']=='F1_Hu'else'E1';fl='F1'if row['branch']=='F1_Hu'else'Fu0_1';D=cms(cmm(cmm(base,M[hl]),B),-r.one);scalar=closed_current(M[fl],D);own=r.load(O/row['artifact']['file']);expected=r.dec(own['complete_selected_Taylor_scalar'])
    if mode=='actual':assert scalar==expected,(case,row['branch'],'FULL_LITERAL_RESPONSE_SCALAR_DIFFERS')
    difference=r.add(scalar,r.scale(expected,-r.one));heat_sensitive|=bool(difference)if mode!='actual'else False;ang=r.angular(scalar);finite,mom=r.finite_radial(ang);roots.append(dict(mode=mode,branch=row['branch'],complete_literal_scalar=r.enc(scalar),complete_difference=r.enc(difference),finite_coefficients=[[*key,r.A.encode_coeff(c)]for key,c in sorted(finite.items())],scalar_changed=bool(difference)))
   del T,T2,B,base;gc.collect()
  total=r.load(O/primary['artifact']['file']);P=r.dec(total['complete_selected_Taylor_scalar']);finite,_=r.finite_radial(r.angular(P));routing=[];d=deriv(P);dd=deriv(d)
  for a,b in [(1,0),(0,1)]:
   shifted=r.add(P,shift_external(d,a,b),r.scale(shift_external(dd,2*a,2*b),J.constant(__import__('fractions').Fraction(1,2))));measured,_=r.finite_radial(r.angular(shifted));assert measured==finite,(case,'MOMENTUM_ROUTING_CHANGED_FINITE');routing.append(dict(shift=[a,b],complete_shifted_scalar=r.enc(shifted),finite_equal=True))
  art=r.save('literal_replay_'+case+'.json.gz',dict(case=case,literal_dimension=8*r.TOTAL,all_actual_full_response_scalars_equal=True,all_modes_and_branches=roots,whole_primary_scalar_routing_checks=routing,shared_action_ring_and_AI_author=True,no_physical_IR_or_reference_limit_claim=True));results.append(dict(case=case,artifact=art,actual_both_full_scalars_equal=True,wrong_heat_scalar_sensitive=any(q['scalar_changed']for q in roots),routing_checks=2));print('STAGE literal_response_and_routing_verified '+case,flush=True)
 assert heat_sensitive
 out=dict(schema='HARD_FINITE_ACC_LITERAL_MATRIX_RESPONSE_REPLAY_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all3cases_both_roots_complete_Laurent_scalars_match=True,whole_base_reconstructed_without_primary_Gbase_input=True,primary_L_R_not_used=True,independent_ordinary1848matrix_products_no_primary_star_or_target_trace=True,all6_routing_finite_coefficients_equal=True,wrong_heat_derivative_complete_scalar_control_sensitive=True,cases=results,prediction_inputs_denied=True,whole_reference_limit_not_qualified=True,elapsed_after_imports=time.perf_counter()-tick);r.dump(O/'replay_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
