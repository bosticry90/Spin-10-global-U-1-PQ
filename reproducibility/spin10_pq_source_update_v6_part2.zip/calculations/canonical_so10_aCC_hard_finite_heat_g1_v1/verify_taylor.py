from pathlib import Path
from fractions import Fraction as Fr
from math import factorial
import importlib.util,json,os,sys,threading,time
import sympy as sy
sp=importlib.util.spec_from_file_location('verified_hard_heat_ring',Path(__file__).resolve().with_name('heat_ring.py'));r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r);J=r.J;O=r.O;R=r.R
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in r.read(O/'preparation.json')['sha256'].items():assert r.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'FINITE_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 H,G,F=r.free();ids=list(range(4))+[132,165,198];h={ij:P for ij,P in H.items()if ij[0]in ids and ij[1]in ids};g={ij:P for ij,P in G.items()if ij[0]in ids and ij[1]in ids};fullF=r.add(*F.values());expected={(i,i):fullF for i in ids};assert r.mm(h,g)==r.mm(g,h)==expected,'FORMAL_SHIFTED_FREE_INVERSE'
 own=r.load(O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1/polarized_base.json.gz');assert H==r.from_primitive(r.p.dm(own['free_A0'])),'SOURCE_FREE_FRAME_REDUCTION'
 v,w,t,z,xi=sy.symbols('v w t z xi',real=True);s=v*v+w*w;ss=(v+z)**2+w*w;phase=sy.exp(-t*(2*v*z+z*z));patterns=[((0,0),phase*(1/ss+(xi-1)*(v+z)**2/ss**2)),((1,1),phase*(1/ss+(xi-1)*w*w/ss**2)),((0,1),phase*(xi-1)*(v+z)*w/ss**2),((2,2),phase/ss),((0,132),-phase*(v+z)/ss),((132,0),phase*(v+z)/ss),((1,132),-phase*w/ss),((132,1),phase*w/ss),((165,198),phase/ss)]
 derivatives={ij:[sy.simplify(sy.diff(expr,z,d).subs(z,0)/factorial(d))for d in range(3)]for ij,expr in patterns};checks=[]
 from functools import lru_cache
 @lru_cache(None)
 def co(c):return sy.sympify(str(c),locals={'xi':xi})
 @lru_cache(None)
 def simp(x):return sy.simplify(x)
 for S in range(8):
  alpha=int(bool(S&1))-int(bool(S&4));beta=int(bool(S&2))-int(bool(S&4))
  for ij,_ in patterns:
   for aa,bb in [(0,0),(1,0),(0,1),(2,0),(1,1),(0,2)]:
    expr=0
    for(u,m,SS,a,b,k,l,vv,e,hh),c in g[ij].items():
     if SS==S and(a,b)==(aa,bb):assert u==m==0 and e==1;expr+=co(c)*v**k*w**l*s**vv*t**hh
    d=aa+bb;expected=derivatives[ij][d]*sy.binomial(d,aa)*alpha**aa*beta**bb;assert simp(expr-expected)==0,(S,ij,aa,bb,'INDEPENDENT_FREE_TAYLOR')
    checks.append([S,list(ij),aa,bb])
 assert len(checks)==432
 print('STAGE all432_generic_free_Taylor_patterns_and_both_inverse_sides_verified',flush=True)
 wrong=r.add(F[1],r.scale(r.term(S=1,e=1),-r.one));assert wrong
 angular=[];moments=[]
 for n in range(9):
  a=sy.rf(sy.Rational(1,2),n)/sy.rf(2,n);b=sy.gamma(n+sy.Rational(1,2))/(sy.sqrt(sy.pi)*sy.gamma(n+2));assert sy.simplify(a-b)==0;angular.append(dict(v_power=2*n,exact=str(a)))
 assert angular[1]['exact']=='1/4';assert sy.Rational(1,4)!=1
 for n in range(1,9):
  for a in [1,2,3]:
   x=sy.symbols('x',positive=True);actual=sy.integrate(x**(a-1)*sy.exp(-n*x),(x,0,sy.oo));assert actual==sy.factorial(a-1)/sy.Integer(n)**a;moments.append(dict(alpha=a,heat=n,exact=str(actual)))
 lam=sy.symbols('lambda',positive=True);frullani=[dict(heat=n,exact=str(sy.integrate(1/lam,(lam,1,n))))for n in range(1,9)];assert all(sy.simplify(sy.sympify(row['exact'])-sy.log(row['heat']))==0 for row in frullani)
 art=r.save('Taylor_verification_tables.json.gz',dict(all432_generic_free_patterns=checks,all9_generic_z_derivatives=[dict(entry=list(ij),coefficients=list(map(str,derivatives[ij])))for ij,_ in patterns],wrong_omitted_heat_derivative_complete_difference=r.enc(wrong),actual_angular_moments=angular,wrong_axial_v_squared_average='1 instead of 1/4',actual_Gamma_radial_moments=moments,Frullani_log_derivation='(exp(-a*x)-exp(-b*x))/x=int_a^b exp(-lambda*x)dlambda; positive a,b permit Fubini; int_a^b dlambda/lambda=log(b/a)',Frullani_log_checks=frullani,full_free_H=r.em(H),full_free_G=r.em(G),all8_profile_Taylors={str(S):r.enc(P)for S,P in F.items()},both_formal_inverse_products_exact=True,source_primitive_free_frame_exact=True))
 out=dict(schema='HARD_FINITE_ACC_SHIFTED_HEAT_TAYLOR_VERIFICATION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all432_generic_free_Taylor_comparisons=True,both_free_inverse_sides_and_actual_frame_exact=True,all4_B_components_and_4D_angular_measure=True,angular_Gamma_Frullani_moments_verified=True,prediction_inputs_denied=True,no_actual_aCC_heat_contraction_yet=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);r.dump(O/'Taylor_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
