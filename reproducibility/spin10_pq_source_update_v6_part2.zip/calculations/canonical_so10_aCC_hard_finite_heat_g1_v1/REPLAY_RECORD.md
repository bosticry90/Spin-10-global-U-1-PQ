# Literal subset-matrix response replay

After primary cases finish, independently embed source/free operators into
ordinary sparse matrices on (quantumfield,exteriorsubset), dimension1848.
The entry S->S unionm carries literal exterior sign(m,S). Then use ORDINARY
matrix multiplication of commuting Taylor/Laurent scalar polynomials,
without the primary star or complementary-body target_trace helpers.
Reconstruct B/Gbase freshly from G0/N, compare its whole embedded matrix,
then construct D_H=-Gbase H B and take actual selected M D diagonal0->7
entries with the endpoint's derived field parity. This changes association
and representation and avoids primary L/R intermediates. Compare complete
Laurent/Taylor scalar for both roots, not merely rational/log sums. Scalar
coefficient ring, action, free Fourier data and AI author remain shared.

Freeze replay240s after imports,8GiB sampled/350MiB floor,64MiB packet/
10MiB artifact. Three declared color cases, all33 internalM/all4B. Save
complete reconstructed response scalar and comparisons. Full matrices are
reconstructable, with exact equality against primary Gbase checked before
dependent scalar comparisons; no silent sampling/truncation. Also reconstruct
the full wrong-heat current using G0 with t-power>0 entries removed BEFORE
the resolvent, for both roots. Preserve all differences and whether finite
moments are sensitive or blind. At least one complete scalar difference
must be nonzero; do not invent sensitivity of a vanishing radial result.

Use complete primary scalar to test loop-momentum routing shift q->q+x e0
and q->q+y e0 through degree2, including E derivatives. All finite/radial
coefficients must be unchanged; these checks reuse scalar data and test
integration, not an independent source calculation. Odd-v terms retained.
Total-derivative boundary vanishing is reviewed for the COMBINED pureheat
profile; separate divergent terms are not assigned values. No assertion of
the physical whole IR/reference limit. Deny dependent prediction/remainder.
