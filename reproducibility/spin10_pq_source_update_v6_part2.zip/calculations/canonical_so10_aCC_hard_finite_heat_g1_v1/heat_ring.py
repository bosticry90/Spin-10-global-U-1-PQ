from pathlib import Path
from fractions import Fraction as Fr
from functools import lru_cache
from hashlib import sha256
from math import comb,factorial
import gzip,importlib.util,json
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('hard_heat_polarized_source',O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1/polarized_polynomial.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);r=p.r;J=r.J;A=r.A;FIELDS=r.FIELDS;TOTAL=r.TOTAL;NB=r.NB;one=r.one;zero=J.ZERO;read=r.read;load=r.load;digest=r.digest
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(f.stat().st_size for f in O.iterdir()if f.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
clean=r.clean;add=r.add;scale=r.scale;ma=r.ma;ms=r.ms
@lru_cache(65536)
def ct(c,d):return r.trim(J.times(c,d))
def put(out,key,c):
 u,m,S,a,b,k,l,v,e,h=key
 if not c or a+b>2 or u>1 or m&S:return
 for j in range(l//2+1):
  kk=u,m,S,a,b,k+2*j,l%2,v+l//2-j,e,h;out[kk]=out.get(kk,zero)+c*(comb(l//2,j)*(-1)**j)
def term(c=one,u=0,m=0,S=None,a=0,b=0,k=0,l=0,v=0,e=0,h=0):
 out={}
 for ss in(range(8)if S is None else[S]):put(out,(u,m,ss,a,b,k,l,v,e,h),c)
 return clean(out)
UNIT=term()
def star(P,Q):
 by={};out={}
 for key,c in P.items():by.setdefault(key[2],[]).append((key,c))
 for(vv,n,T,aa,bb,kk,ll,sv,ee,hh),d in Q.items():
  for(u,m,S,a,b,k,l,v,e,h),c in by.get(T|n,[]):
   if u+vv>1 or m&n or(m|n)&T or a+b+aa+bb>2:continue
   value=ct(c,d)*r.esign(m,n);put(out,(u+vv,m|n,T,a+aa,b+bb,k+kk,l+ll,v+sv,e+ee,h+hh),value)
 return clean(out)
def mm(P,Q):
 by={};out={}
 for(k,j),c in Q.items():by.setdefault(k,[]).append((j,c))
 for(i,k),c in P.items():
  for j,d in by.get(k,[]):
   v=star(c,d)
   if not v:continue
   acc=out.setdefault((i,j),{})
   for key,cc in v.items():acc[key]=acc.get(key,zero)+cc
 return {ij:clean(v)for ij,v in out.items()if clean(v)}
def ident(ids):return {(i,i):UNIT for i in ids}
def from_primitive(M):
 out={}
 for ij,P in M.items():
  acc={}
  for(u,m,S,ex),c in P.items():
   if any(ex[j]for j in [2,3,5,6,7,9,10,11]):continue
   put(acc,(u,m,S,ex[4],ex[8],ex[0],ex[1],0,0,0),c)
  if clean(acc):out[ij]=clean(acc)
 return out
def enc(P):return [[*key,A.encode_coeff(c)]for key,c in sorted(P.items())]
def dec(P):return {tuple(row[:10]):A.decode_coeff(row[10])for row in P}
def em(M):return [[i,j,enc(P)]for(i,j),P in sorted(M.items())]
def dm(M):return {(i,j):dec(P)for i,j,P in M}
def metrics(M):return dict(entries=len(M),terms=sum(len(P)for P in M.values()))
def free():
 H={};G={};profiles={};xi=J.Coeff([((0,1,0,0),Fr(1))])
 for S in range(8):
  alpha=int(bool(S&1))-int(bool(S&4));beta=int(bool(S&2))-int(bool(S&4));shift=add(term(J.constant(alpha),S=S,a=1),term(J.constant(beta),S=S,b=1));qs=[add(term(S=S,k=1),shift),term(S=S,l=1),{},{}];shift2=star(shift,shift);z=add(scale(star(term(S=S,k=1),shift),J.constant(2)),shift2);ss=add(term(S=S,v=1),z)
  F=star(term(S=S,e=1),add(term(S=S),scale(star(term(S=S,k=1,h=1),shift),J.constant(-2)),scale(star(term(S=S,h=1),shift2),J.constant(-1)),scale(star(term(S=S,k=2,h=2),shift2),J.constant(2))));profiles[S]=F
  def inv(d):return add(term(S=S,v=-d),scale(star(term(S=S,v=-d-1),z),J.constant(-d)),scale(star(term(S=S,v=-d-2),star(z,z)),J.constant(Fr(d*(d+1),2))))
  d1=inv(1);d2=inv(2)
  def insert(mat,ij,P):
   if P:mat[ij]=add(mat.get(ij,{}),P)
  for color in r.IC:
   bs=[r.INDEX[4*color+mu]for mu in range(4)];ll=r.INDEX[508+color];cc=r.INDEX[553+color];aa=r.INDEX[598+color]
   for mu,i in enumerate(bs):
    for nu,j in enumerate(bs):
     insert(H,(i,j),add(ss if mu==nu else{},scale(star(qs[mu],qs[nu]),-one)))
     insert(G,(i,j),star(F,add(d1 if mu==nu else{},scale(star(star(qs[mu],qs[nu]),d2),xi-one))))
    insert(H,(i,ll),qs[mu]);insert(H,(ll,i),scale(qs[mu],-one));insert(G,(i,ll),scale(star(F,star(qs[mu],d1)),-one));insert(G,(ll,i),star(F,star(qs[mu],d1)))
   insert(H,(ll,ll),term(xi,S=S));insert(H,(cc,aa),scale(ss,-one));insert(H,(aa,cc),ss);insert(G,(cc,aa),star(F,d1));insert(G,(aa,cc),scale(star(F,d1),-one))
 return H,G,profiles
def target_trace(L,RR):
 out={}
 for(i,j),P in L.items():
  Q=RR.get((j,i))
  if not Q:continue
  groups={}
  for key,d in Q.items():
   if key[2]==0:groups.setdefault((key[0],key[1]),[]).append((key,d))
  for(u,m,S,a,b,k,l,v,e,h),c in P.items():
   n=7^m
   if S!=n:continue
   for(vv,nn,T,aa,bb,kk,ll,sv,ee,hh),d in groups.get((1-u,n),[]):
    if a+b+aa+bb>2:continue
    value=ct(c,d)*r.esign(m,n)*(-1 if i>=NB else 1);put(out,(1,7,0,a+aa,b+bb,k+kk,l+ll,v+sv,e+ee,h+hh),value)
 return clean(out)
def angular(P):
 out={}
 for(u,m,S,a,b,k,l,v,e,h),c in P.items():
  assert u==1 and m==7 and S==0 and l==0 and e>0 and all(key[0]==1 for key,val in c.terms),'WRONG_HARD_SCALAR_TYPE'
  if k%2:continue
  n=k//2;weight=Fr(factorial(2*n),4**n*factorial(n)*factorial(n+1));key=a,b,v+n,e,h;out[key]=out.get(key,zero)+J.times(c,J.constant(weight))
 return clean(out)
def enc_angular(P):return [[*k,A.encode_coeff(c)]for k,c in sorted(P.items())]
def finite_radial(P):
 out={};loggroups={};rows=[]
 def accum(k,c):out[k]=out.get(k,zero)+c
 for(a,b,v,e,h),c in P.items():
  if a+b!=2:continue
  alpha=2+v;assert alpha==h and alpha>=0 and e>0,'WRONG_FINITE_HOMOGENEITY'
  if alpha:
   value=J.times(c,J.constant(Fr(factorial(alpha-1),e**alpha)));accum((a,b,0),value);rows.append(dict(x=a,y=b,alpha=alpha,heat=e,t=h,coefficient=A.encode_coeff(c),moment=str(Fr(factorial(alpha-1),e**alpha))))
  else:loggroups.setdefault((a,b),{})[e]=loggroups.setdefault((a,b),{}).get(e,zero)+c
 for(a,b),co in loggroups.items():
  assert not sum(co.values(),zero),'UNCANCELED_FRULLANI_CONSTANT_OR_LOG_T'
  for n,c in co.items():
   nn=n;prime=2
   while prime<=nn:
    count=0
    while nn%prime==0:nn//=prime;count+=1
    if count:accum((a,b,prime),c*(-count))
    prime+=1
   rows.append(dict(x=a,y=b,alpha=0,heat=n,t=0,coefficient=A.encode_coeff(c),moment='-log('+str(n)+')_COMBINED_ONLY'))
 return clean(out),dict(all_term_moments=rows,complete_Frullani_groups=[dict(x=a,y=b,coefficients=[[n,A.encode_coeff(c)]for n,c in sorted(co.items())],sum_zero=True)for(a,b),co in sorted(loggroups.items())])
