# First actual hard-heat contraction launch

Dependent on Taylor_result.json COMPLETED and its immutable sources/tables.
Execute base case ONLY first, 300s after imports/8GiB sampled/350MiB floor,
64MiB complete packet/10MiB artifact. Inspect bounded result before H/M.
The same frozen worker supports those two declared follow-ons but there is no
automatic launch on failure. Preserve unfinished/failed capture and sources.
The full scope and authority ceiling in RECORD.md remain binding.

Construct actual converted source matrices, full free G0 and N; assert literal
Lambda/ghost one-mean support, exact nilpotent cube, and primitive free frame.
Retain all shifted subset entries and actual Xi. Factor current as L=M Gbase,
R=H B, complete complementary-body trace with derived endpoint ghost weight.
Both roots are evaluated independently before addition; save full L/R and
base matrices in bounded artifacts, together with all selected scalar Taylor
terms, angular terms, moment groups, finite coefficients and odd-v terms that
integrate to zero. If artifacts exceed caps, fail without truncation.

Required old-profile recovery is the COMPLETE zero-external-order scalar
after the actual4D angular average, not just a fitted radial number. It must
equal the qualified V815 symbol for each branch and their sum. Degree1 angular
scalar must vanish; degree0 radial alpha=1,t=0; degree2 alpha=t>=0; no odd-w
scalar; all profile powers positive. Frullani constants cancel before logs.
No scientific baseline/finite counterterm is chosen. Save exact rational/log
answers, even if zero or inconvenient. This stage earns only an actual
PUREHEAT_HARD_COEFFICIENT result pending independent contraction/remainder/
whole-IR checks. No finite reference or common restoration is claimed.
