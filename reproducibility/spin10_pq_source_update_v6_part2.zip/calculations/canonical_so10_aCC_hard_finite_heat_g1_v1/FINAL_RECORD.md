# Final hard-heat evidence validation

Freeze final420s afterimports/8GiB sampled/350MiB floor/64MiB packet/10MiB
artifact. Authenticate every preparation/source/capture and owning result.
Freshly rerun Taylor verification, all3 actual primary cases and literal
response/routing/negative-control replay in comparison-only mode. Require
all16 compressed artifacts byte-identical and all5 nonruntime result records
identical. Bounds120/300percase/240 unchanged, no failure relabeling or
resource expansion. No dependent prediction/remainder read.

Check exact finite rational/log expressions in proof against owning tables,
all old profile recoveries and control sensitivities/base/M vs Hblind.
One E4 nofresh with fixed D historical context, subprocess timeout120s,
expected0,0,0,0,0,2 and exactly7 unresolved custody refs, stillNOTPASS. Save
complete E4 capture in repo and D controls. Preserve old Git mode/blob tree
and state SHA. Final receipt supports only PUREHEAT_HARD_COEFFICIENT_ONLY.
No physical reference/common restoration/E5/A5 or whole goal completion.
Local commit only after validation; no branch/worktree/push or externalaction.
