# Direct integrated quadratic hard-heat symbols

The exact result here is an integrated quadratic external Taylor symbol of
the actual selected aCC current with pure heat profiles. Calling it a full
finite UV/IR reference would require an additional remainder/soft-profile
proof, which has not been performed. The normalization prescription and
physical action remain unchanged. All33 internal M/all4B/231fields, firstg/
firstu_M and the original Euclidean domain are retained.

## Legitimate rotational reduction

The source-first12variable operators and their full SO(4) covariance were
qualified in V817. A scalar quadratic external polynomial can only have
the form alpha p²+beta p.r+gamma r². Thus p=x e0,r=y e0 recovers all three
LOCAL quadratic coefficients. This would not recover a full nonlocal
function, which is not claimed. Residual SO(3) acting on loop components
perpendicular to e0 permits q=(v,w,0,0) as a representative; w is retained,
and all four gauge-component indices are still contracted. This is not a
two-dimensional loop measure and not the restriction q parallel to p.

Set s=v²+w² and use the canonical quotient w²=s-v². For the true normalized
four-dimensional angular average,

    <v^(2k)> = (1/2)_k/(2)_k s^k,

with odd v powers averaging to zero. In particular <v²>=s/4, not s. Odd w
terms must cancel from the full scalar before angular integration. The
angular formula is independently reconciled with separable four-dimensional
Gaussian moments. Exact degree2 profiles, coupling/probe grades and complete
constant q/profile recovery provide additional checks of this reduction.

## Shifted propagators, derivatives and ordered contraction

The input subset S shifts the right quantum momentum by h_S e0, where
h_S=(S_p-S_a)x+(S_r-S_a)y. Propagators use s+2v h_S+h_S². The actual heat
Taylor expansion is

 E(q+h_S e0)=E(q)[1-2t v h_S-t h_S²+2t²v²h_S²]+O((x,y)^3).

Both free inverse products H G0=G0 H=Fshift I hold exactly in this Taylor
quotient, with the original ordered ghost blocks and full gauge width.
The actual source-derived free frame agrees. Generic SymPy differentiation
of nine nonzero free-block patterns checks432 formal v,w,t,xi comparisons
across all8 subsets/all6 external monomials, independently of the hand Taylor
inverse/profile expansion. Wrong omitted heat derivatives give an explicit
nonzero profile control. All sources and inputs were frozen before launch.

The actual N connects Lambda/ghost with one mean degree. Together with free
G0_LambdaLambda=0 this gives (G0 star N)^3=0 even with shifts. The exact
resolvent is B=I-T+T²,T=G0 star N,Gbase=B star G0. For each of the two roots
the actual selected current is

    -(1-E(q)) sum_i(-1)^p_i [M_F star Gbase star H star B]_ii.

The endpoint ghost weight was independently derived from actual free blocks
and calibrated to nonzero earlier results in V817. It is not an additional
ghostloop sign. The primary computation associates L=M_F Gbase,R=H B and
selects the complete cubic exterior coefficient0->7 with its shifted input
subset. Both F1/Hu and Fu0/Hg are computed before addition. Every old
constant profile coefficient matches, including base/H zero and the nonzero
M coefficient. No finite coefficient was selected to repair an identity.

## Radial moments without assigning divergent pieces

After the true angular average a monomial contributes, with common1/(16pi²),

    t^h int_0^infinity ds s^(1+v+k) exp(-n t s).

At quadratic external degree canonical dimensions require alpha=2+v+k=h>=0.
For alpha>0 the finite coefficient is Gamma(alpha)/n^alpha. For alpha=0,
the COMPLETE heat-power coefficients must sum to zero before integrating;
only the combined Frullani integral is taken, giving -sum_n c_n log(n).
There is no independently assigned divergent integral or chosen subtraction.
Gamma moments are checked by direct symbolic integration. Frullani follows
from (e^(-a x)-e^(-b x))/x=int_a^b e^(-lambda x)dlambda and Fubini for
positive a,b, then int_a^b dlambda/lambda=log(b/a). Log powers are put into
the prime-log basis after calculation. No log(t) remainder is silently dropped.

These COMBINED pureheat Taylor integrands are absolutely integrable. At
external degree j<=2 the non-endpoint monomials have small-q order at worst
q^(-2-j); (1-E(q)) supplies q², so the combined order is at worst q^(-j),
locally integrable in four dimensions. Heat derivatives improve that order.
At infinity every term has a positive heat power. This also makes the
combined total-derivative boundary terms vanish: for first and second routing
derivatives the small-sphere surface is bounded by a constant times radius²
or better; the large-sphere term decays exponentially. The six routing
checks q->q+x e0 and q->q+y e0, retaining E derivatives and odd-v terms,
therefore have an ordinary integration-by-parts justification. All six give
the same finite coefficients. This argument concerns these Taylor symbols;
it does not bound the original kernel's nonuniform external Taylor remainder
or its f_delta infrared defect.

## Exact answers

Suppress only the common g10*u*xi²*sqrt(10)*theta_p*theta_r*chi/(16pi²),
with the antighost momentum -p-r. Define

    K = 41/100 - (27/25)log(2) + (18/25)log(3),
    L = (54/25)log(2) - (36/25)log(3),
    A = -373/225 + (108/25)log(2) - (72/25)log(3),
    B = -404/225 + (144/25)log(2) - (96/25)log(3).

| External ghosts; antighost | Integrated quadratic hard symbol |
| --- | --- |
| C0(p),C14(r);a13 | K [p²+2p.r] |
| C13(p),C14(r);a0 | L (p+r)² |
| C13(p),C14(r);a12 | A(p²+r²)+B p.r |

All coefficients were computed from the action without reading the V814
dependent finite prediction or assembled known remainder. They have not
been compared with that prediction. The first two cases retain their known
zero leading-UV symbol but have nonzero hard quadratic terms.

## Distinct response replay and sensitive/blind controls

The replay embeds operators into ordinary sparse matrices on1848 pairs
(quantumfield,exteriorsubset). An entry S->S unionm gets the sign of literal
ordered exterior-word concatenation. Ordinary commuting Taylor/Laurent
matrix products use neither primary star nor target_trace. Gbase is rebuilt
from G0/N before comparing its COMPLETE embedded matrix to the primary;
the primary matrix is used only for that comparison. The response is then
associated as D_H=-Gbase H B, and M_F D_H is contracted via actual0->7
diagonal entries. Primary L/R are not imported. Both complete Laurent
scalars, including zero roots, agree in all three cases, not just their
integrated rational/log answers.

The replay also reconstructs the entire current after removing heat
derivatives from G0 BEFORE the resolvent. Base and M scalars change. Their
finite rational terms disappear, while the logarithmic terms remain. The
H-antighost scalar is unchanged: that case is a BLIND control for this error,
not evidence that heat derivatives are optional. All differences are saved.

The action, exact coefficient ring, free-data conventions, Python/SymPy and
AI author remain shared. These are distinct representations and algorithms,
not independent scientists or independent physical assumptions. No Lean,
empirical test, new physical benchmark or external endorsement is claimed.

## Scope still open

This qualifies the explicitly defined PUREHEAT_HARD_COEFFICIENT_ONLY result.
It does not establish that it equals the full finite reference of the
original kernel F=f_delta E. Need a whole UV-first/IR-second Schwartz proof,
including shifted soft singularities and possible source contacts. The old
leading-power O(sqrt(t)) argument does not control a finite subtraction.
The complete finite-color tensor and same-color derivative possibilities
remain unmeasured. Common restoration, source products, QAP/measure/quantum
equivalence, E5/A5 and physical viability are not established. Project state
and scientific authority remain unchanged; the final receipt owns evidence
validation, not director acceptance. Seven custody references stayNOTPASS.
