from pathlib import Path
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('actual_hard_heat_ring',Path(__file__).resolve().with_name('heat_ring.py'));r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r);J=r.J;O=r.O;R=r.R
def enc_finite(P):return [[a,b,ln,r.A.encode_coeff(c)]for(a,b,ln),c in sorted(P.items())]
def constant_profile(P):
 out={}
 for(a,b,v,e,h),c in P.items():
  if a+b==0:
   assert v==-1 and h==0,'WRONG_LEADING_RADIAL_TYPE';out[1,7,-2,e]=out.get((1,7,-2,e),J.ZERO)+c
  elif a+b==1:assert not c,'NONZERO_ODD_EXTERNAL_ANGULAR_SCALAR'
 return r.clean(out)
def old_decode(P):return {tuple(row[:4]):r.A.decode_coeff(row[4])for row in P}
def main(case):
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in r.read(O/('contraction_preparation_'+case+'.json'))['sha256'].items():assert r.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'FINITE_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 assert case in ['base','H_antighost','all_M'];src=r.load(O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1'/('polarized_'+case+'.json.gz'));M={k:r.from_primitive(r.p.dm(P))for k,P in src['matrices'].items()};N=r.from_primitive(r.p.dm(src['N']));H0,G0,F=r.free();assert M['E0']==r.ma(H0,N)
 assert all((508<=r.FIELDS[i]<553 and r.FIELDS[j]>=553)or(508<=r.FIELDS[j]<553 and r.FIELDS[i]>=553)for i,j in N);assert all(key[0]==0 and key[1].bit_count()==1 for P in N.values()for key in P)
 T=r.mm(G0,N);T2=r.mm(T,T);assert not r.mm(T2,T),'HARD_HEAT_N_CUBE';B=r.ma(r.ident(range(r.TOTAL)),r.ms(T,-r.one),T2);base=r.mm(B,G0)
 artbase=r.save('hard_base_'+case+'.json.gz',dict(case=case,actual_G0=r.em(G0),N=r.em(N),B=r.em(B),Gbase=r.em(base),nilpotent_cube_zero=True,actual_free_frame=True));print('STAGE hard_base '+case+' '+json.dumps(r.metrics(base),sort_keys=True),flush=True)
 old=r.load(O.parent/'canonical_so10_aCC_direct_UV_symbol_g1_v1'/('gaussian_'+case+'.json.gz'));branches=[];total={};totalfinite={}
 for name,flow,hl,oldkey in [('F1_Hu','F1','Eu0_1','F1_response'),('Fu0_Hg','Fu0_1','E1','Fu0_response')]:
  L=r.mm(M[flow],base);print('STAGE '+case+' '+name+' L '+json.dumps(r.metrics(L),sort_keys=True),flush=True);Right=r.mm(M[hl],B);print('STAGE '+case+' '+name+' R '+json.dumps(r.metrics(Right),sort_keys=True),flush=True)
  raw=r.target_trace(L,Right);scalar=r.scale(r.star(r.add(r.term(),r.term(-r.one,e=1)),raw),-r.one);angular=r.angular(scalar);constant=constant_profile(angular);assert constant==old_decode(old[oldkey]),(case,name,'OLD_COMPLETE_PROFILE_RECOVERY')
  finite,mom=r.finite_radial(angular);total=r.add(total,scalar);totalfinite=r.add(totalfinite,finite)
  artifact=r.save('hard_branch_'+case+'_'+name+'.json.gz',dict(case=case,branch=name,flow=flow,insertion=hl,full_L_M_Gbase=r.em(L),full_R_H_B=r.em(Right),complete_selected_Taylor_scalar=r.enc(scalar),complete_angular_scalar=r.enc_angular(angular),constant_profile_recovery=[[u,m,q,e,r.A.encode_coeff(c)]for(u,m,q,e),c in sorted(constant.items())],actual_finite_hard_coefficients=enc_finite(finite),complete_radial_moment_groups=mom,all_odd_v_scalar_terms=[[ *key,r.A.encode_coeff(c)]for key,c in sorted(scalar.items())if key[5]%2],status='PUREHEAT_HARD_COEFFICIENT_ONLY'))
  branches.append(dict(branch=name,artifact=artifact,scalar_terms=len(scalar),angular_terms=len(angular),finite_coefficients=enc_finite(finite),old_complete_profile_equal=True));print('STAGE '+case+' '+name+' FINITE '+json.dumps(enc_finite(finite)),flush=True)
 angular=r.angular(total);finite,mom=r.finite_radial(angular);assert finite==totalfinite;assert constant_profile(angular)==old_decode(old['whole_target'])
 art=r.save('hard_total_'+case+'.json.gz',dict(case=case,complete_selected_Taylor_scalar=r.enc(total),complete_angular_scalar=r.enc_angular(angular),actual_finite_hard_coefficients=enc_finite(finite),complete_radial_moment_groups=mom,branches=branches,form='alpha*x^2+beta*x*y+gamma*y^2 equivalent alpha*p^2+beta*p.r+gamma*r^2 for LOCAL_ROTATION_SCALAR_TAYLOR_ONLY',normalization='g10/u/xi/radicals retained in coefficients; only common 1/(16pi^2) suppressed',status='PUREHEAT_HARD_COEFFICIENT_ONLY'))
 out=dict(schema='DIRECT_ACTUAL_ACC_PUREHEAT_HARD_FINITE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',case=case,all33_internal_M_all4B_231fields=True,actual_two_root_Taylor_contraction=True,all_complete_old_constant_profiles_match=True,heat_derivatives_and_four_dimensional_angular_average_retained=True,all_finite_Gamma_Frullani_homogeneity_conditions=True,finite_hard_coefficients=enc_finite(finite),base_artifact=artbase,branches=branches,artifact=art,prediction_inputs_denied=True,status='PUREHEAT_HARD_COEFFICIENT_ONLY',whole_UV_IR_reference_and_independent_contraction_review_pending=True,elapsed_after_imports=time.perf_counter()-tick);r.dump(O/('hard_result_'+case+'.json'),out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main(sys.argv[1])
