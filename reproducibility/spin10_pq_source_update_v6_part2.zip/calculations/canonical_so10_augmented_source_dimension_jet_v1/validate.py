from pathlib import Path
from hashlib import sha256
import gzip,json,os,re,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-source-dimension-jet-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def typ(n):
    if n>=1286:assert n<1319;return 1,-1,0
    if n>=643:
        d,g,v=typ(n-643);return 3-d,-1-g,v
    return 1+int(508<=n<553),1 if 553<=n<598 else -1 if 598<=n<643 else 0,int(n<180)
def carriers(word,mu):
    out=[]
    for pos,(n,jets)in enumerate(word):
        dim,ghost,vector=typ(n)
        if vector and(n%643)%4==mu:out.append([pos,'VECTOR_CARRIER',n,mu])
        out.extend([pos,'ORDINARY_JET',n,at]for at,v in enumerate(jets)if v==mu)
    return out
def replay(name,table,kind,record):
    type_rows=[];vector_rows=[];epsilon=[]
    for i,raw in table:
        di,gi,vi=typ(i);target_dim=di+1 if kind=='F'else 4-di if kind=='E'else di;target_gh=gi+1 if kind=='F'else -gi if kind=='E'else gi
        vector_field=i-643 if kind=='D'and i>=643 else i;mu=vector_field%4 if vector_field<180 else None
        for at,(word,cells)in enumerate(raw):
            total_dim=sum(typ(n)[0]+len(jets)for n,jets in word);total_gh=sum(typ(n)[1]for n,jets in word);slots=sum(typ(n)[2]+len(jets)for n,jets in word);deficit=target_dim-total_dim;assert deficit>=0 and target_gh==total_gh and slots<=target_dim-target_gh;type_rows.append([i,at,target_dim,target_gh,deficit,slots])
            if mu is None:continue
            ends=carriers(word,mu);assert ends
            row=dict(output=i,word_index=at,free_mu=mu,complete_word=word,complete_coefficient_cells=cells,all_retained_free_index_endpoints=ends);vector_rows.append(row)
            if all(end[1]=='ORDINARY_JET'and end[2]>=1286 for end in ends):
                badword=[[n,[j for j in jets if j!=mu]if n>=1286 else jets]for n,jets in word];assert not carriers(badword,mu);epsilon.append(dict(original=row,erased_epsilon_jets_complete_word=badword,free_index_attachment_lost=True))
    assert record==dict(state=name,all_nonzero_type_and_slot_rows=type_rows,all_actual_free_vector_output_rows=vector_rows,all_unattached_counterexamples=[],all_sensitive_erased_epsilon_jet_controls=epsilon)
    return len(type_rows),len(vector_rows),len(epsilon)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='f468c882aaa6bacfa3f37b8b61103199b0356ee0'
    for name,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/name)==h,name
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=read(O/'preparation.json');assert prep==read(C/'preparation.json')
    for name,h in prep['sha256'].items():assert digest(saved[name]if name in saved else R/name)==h,name
    enc=read(O/'input_encoding_bindings.json');assert enc==read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        name=row['file'];live=(saved[name]if name in saved else R/name).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+name],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256'];assert row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',name],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=read(O/'result.json');assert result['elapsed_after_imports']<90
    expected=[]
    for n in range(1319):
        d,g,ell=typ(n);assert d-g-ell>=0;expected.append([n,d,g,ell,d-g-ell])
    expected+=[['u',0,0,0,0],['g10',0,0,0,0],['rho',1,1,0,0],['beta',-1,-1,0,0],['ordinary_derivative',1,0,1,0]]
    # Faithfulness of the three rank4 metric pairings already at dimension4.
    pairings=[[(0,1),(2,3)],[(0,2),(1,3)],[(0,3),(1,2)]];assignments=[(0,0,1,1),(0,1,0,1),(0,1,1,0)];matrix=s.Matrix([[s.prod(int(x[i]==x[j])for i,j in pairs)for pairs in pairings]for x in assignments]);assert matrix==s.eye(3)
    D=s.Symbol('D',real=True);sphere=2*s.pi**(D/2)/(s.gamma(D/2)*(2*s.pi)**D);assert s.simplify(s.limit((D-4)*sphere/(D-4),D,4))==1/(8*s.pi**2)
    assert not carriers([[553,[]]],0)and typ(553)[0]+1==2 and typ(553)[1]==1;assert -1-0<0
    # Attachment alone is blind to a pre-existing D coefficient and sewing.
    assert carriers([[0,[]],[553,[]]],0)
    cc=s.Symbol('C')
    for n in[3,4,5]:
        xs=s.symbols('b0:'+str(n));assert sum(s.diff(x*cc,x)for x in xs)==n*cc
    kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');summaries=[]
    for rr in result['roles']:
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes'];z=load(O/art['file']);assert z['all_generator_dimension_ghost_slot_slack']==expected and z['endpoint_test_NOT_alone_no_loop_theorem']and z['Jacobians_second_derivatives_and_quantum_sewing_NOT_covered'];dtypes,dvectors,deps=replay('full1286_D',kd['all1286_D'],'D',z['full_D_source_and_field_gate']);assert dvectors==2804
        packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));reports=z['all_current_states_and_physical_cofactors'];assert len(reports)==len(packet['states'])+len(packet['physical']);index=0;nt=0;nv=0;ne=deps
        for group in['states','physical']:
            for name,table in packet[group].items():
                t,v,e=replay(name,table,'F'if group=='states'and name.startswith('F')else'E',reports[index]);nt+=t;nv+=v;ne+=e;index+=1
        assert nt==rr['cofactor_rows']==382646 and nv==rr['vector_endpoint_rows']==209488 and ne==rr['sensitive_actual_epsilon_controls']==132;ctrl=z['executed_controls'];assert ctrl['erased_epsilon_jet_witness_count']==ne and ctrl['erased_epsilon_control']=='SENSITIVE_ACTUAL'and ctrl['wrong_beta_ghost_zero_gives_negative_slack']==-1 and s.sympify(ctrl['retained_first_jet'])==1/(8*s.pi**2)
        summaries.append(dict(role=role,cofactor_rows=nt,vector_endpoint_rows=nv,D_vector_rows=dvectors,actual_sensitive_epsilon_jet_controls=ne));print('STAGE '+role+' independent_all_source_rank_endpoint_replay',flush=True);del z
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V852.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V852.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V852.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V852.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_SCOPED_AUGMENTED_LOCAL_SOURCE_EXTERNAL_FIRST_JET_BRIDGE',base_HEAD=head,state_sha256=state,roles=summaries,fixed_constructor_one_Euler_local_substitution_graph_proof_reviewed=True,rank4_metric_pairings_faithful=True,attachment_alone_and_own_trace_controls_sensitive=True,internal_quantum_D_traces_and_Jacobians_NOT_removed=True,common_Cfin_contacts_geometric_W5_QAP_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_action_constructor_conventions_Python_Sympy_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
