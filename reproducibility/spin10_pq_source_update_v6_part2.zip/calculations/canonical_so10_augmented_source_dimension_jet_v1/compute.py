from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-source-dimension-jet-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def dim(n):return 1 if n>=1286 else 3-dim(n-643)if n>=643 else 2 if 508<=n<553 else 1
def ghost(n):return -1 if n>=1286 else -1-ghost(n-643)if n>=643 else 1 if 553<=n<598 else -1 if 598<=n<643 else 0
def vector(n):return n<180 or 643<=n<823
def degree(word):return sum(dim(n)+len(js)for n,js in word)
def gh(word):return sum(ghost(n)for n,js in word)
def slot(n,js):return len(js)+int(vector(n))
def scan(name,table,kind):
    rows=[];bad=[];typed=[];epscontrols=[]
    for i,raw in table:
        target_dim=dim(i)+1 if kind=='F'else 4-dim(i)if kind=='E'else dim(i);target_gh=ghost(i)+1 if kind=='F'else -ghost(i)if kind=='E'else ghost(i)
        field=i-643 if kind=='D'and i>=643 else i;free=field%4 if field<180 else None
        for at,(word,cells)in enumerate(raw):
            deficit=target_dim-degree(word);assert deficit>=0 and gh(word)==target_gh,(name,i,at,'TYPE',deficit,gh(word),target_gh)
            actual_slots=sum(slot(n,js)for n,js in word);assert actual_slots<=target_dim-target_gh
            typed.append([i,at,target_dim,target_gh,deficit,actual_slots])
            if free is None:continue
            endpoints=[]
            for p,(n,js)in enumerate(word):
                if vector(n)and(n if n<643 else n-643)%4==free:endpoints.append([p,'VECTOR_CARRIER',n,free])
                for j,mu in enumerate(js):
                    if mu==free:endpoints.append([p,'ORDINARY_JET',n,j])
            replay=set()
            for p,(n,js)in enumerate(word):
                carriers=({(p,'VECTOR_CARRIER',n,(n%4 if n<643 else(n-643)%4))}if vector(n)else set())|{(p,'ORDINARY_JET',n,k)for k,mu in enumerate(js)if mu==free}
                replay|={x for x in carriers if x[1]!='VECTOR_CARRIER'or x[3]==free}
            assert set(map(tuple,endpoints))==replay
            row=dict(output=i,word_index=at,free_mu=free,complete_word=word,complete_coefficient_cells=cells,all_retained_free_index_endpoints=endpoints);rows.append(row)
            if not endpoints:bad.append(row)
            if endpoints and all(e[1]=='ORDINARY_JET'and e[2]>=1286 for e in endpoints):
                erased=[[n,[mu for mu in js if mu!=free]if n>=1286 else js]for n,js in word];still=any(vector(n)and(n if n<643 else n-643)%4==free or free in js for n,js in erased);assert not still;epscontrols.append(dict(original=row,erased_epsilon_jets_complete_word=erased,free_index_attachment_lost=True))
    return dict(state=name,all_nonzero_type_and_slot_rows=typed,all_actual_free_vector_output_rows=rows,all_unattached_counterexamples=bad,all_sensitive_erased_epsilon_jet_controls=epscontrols)
def save(name,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/name).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    return dict(file=name,sha256=digest(O/name),bytes=len(blob))
def main():
    tick=time.perf_counter();watch=threading.Timer(90,lambda:os._exit(124));watch.daemon=True;watch.start()
    for name,h in read(O/'preparation.json')['sha256'].items():assert digest(R/name)==h,name
    types=[[n,dim(n),ghost(n),int(vector(n)),dim(n)-ghost(n)-int(vector(n))]for n in range(1319)]
    types+=[[name,d,g,0,d-g]for name,d,g in[('u',0,0),('g10',0,0),('rho',1,1),('beta',-1,-1),('ordinary_derivative',1,0)]]
    # The derivative carries one slot; correct that explicit row.
    types[-1]=['ordinary_derivative',1,0,1,0];assert all(row[-1]>=0 for row in types)
    kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');D=scan('full1286_D',kd['all1286_D'],'D');assert not D['all_unattached_counterexamples'];roles=[]
    dimension=s.Symbol('D',real=True);sphere=2*s.pi**(dimension/2)/(s.gamma(dimension/2)*(2*s.pi)**dimension);evanescent=(dimension-4)*sphere;derivative=s.simplify(s.diff(evanescent,dimension).subs(dimension,4));assert evanescent.subs(dimension,4)==0 and derivative==1/(8*s.pi**2)
    for role in['native','replay']:
        packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));reports=[]
        for name,table in packet['states'].items():reports.append(scan(name,table,'F'if name.startswith('F')else'E'))
        for name,table in packet['physical'].items():reports.append(scan(name,table,'E'))
        ok=all(not z['all_unattached_counterexamples']for z in reports);assert ok
        eps=sum(len(z['all_sensitive_erased_epsilon_jet_controls'])for z in reports+[D]);counter=dict(scalar_only_vector_replacement_complete_word=[[553,[]]],declared_intrinsic_mass_dimension=1,target_dim=2,target_gh=1,free_mu=0,no_real_carrier_endpoint=True);assert dim(553)+1==2 and ghost(553)==1 and not vector(553);assert -1-0<0
        artifact=save(role+'_complete_augmented_source_jet_gate.json.gz',dict(all_generator_dimension_ghost_slot_slack=types,all_current_states_and_physical_cofactors=reports,full_D_source_and_field_gate=D,executed_controls=dict(scalar_vector_replacement=counter,erased_epsilon_jet_witness_count=eps,erased_epsilon_control='SENSITIVE_ACTUAL'if eps else'BLIND_ACTUAL_SYNTHETIC_REQUIRED',wrong_beta_ghost_zero_gives_negative_slack=-1,premature_D4_evanescent_value=0,retained_first_jet=str(derivative)),endpoint_test_NOT_alone_no_loop_theorem=True,Jacobians_second_derivatives_and_quantum_sewing_NOT_covered=True))
        roles.append(dict(role=role,artifact=artifact,cofactor_rows=sum(len(z['all_nonzero_type_and_slot_rows'])for z in reports),vector_endpoint_rows=sum(len(z['all_actual_free_vector_output_rows'])for z in reports),D_vector_endpoint_rows=len(D['all_actual_free_vector_output_rows']),sensitive_actual_epsilon_controls=eps))
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ACTUAL_AUGMENTED_LOCAL_SOURCE_RANK_AND_FREE_INDEX_GATES_SUPPORTED',roles=roles,no_numeric_loop_graph_proof_and_first_jet_commutation_require_final_review=True,shared_action_conventions_Python_Sympy_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
