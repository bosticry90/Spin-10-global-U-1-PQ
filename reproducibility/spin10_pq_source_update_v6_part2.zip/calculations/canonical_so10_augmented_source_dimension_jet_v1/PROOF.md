# Local augmented source substitution and the first dimension jet

Requires the completed separate final receipt. The domain is the original
unshifted A0 polynomial Cartesian slice, g<=1,first-u H/M,rho,beta, with the
SAME V848 metric constructor and V849 convention. Sigma=S+uU+rhoKD and
B=B[Sigma] is computed before beta. Q means Q_Sigma throughout; beta is ONE
LEFT breaking-insertion strength, not a second independently deformed Q.
No nilpotence of Q_Sigma or master equation for Sigma is assumed here.

## A rank bound that includes negative-dimension beta

For every ordinary generator use project dimension d, ghost number gh and
Lorentz-slot cost ell. B and J_B cost one slot; all other field/source/mark
generators are Lorentz scalars. An ordinary derivative costs one dimension
and one slot. Actual generators satisfy d-gh-ell>=0: B,C and derivatives
saturate; x,Lambda and the antighost have nonnegative slack, as do all BV
sources with dJi=3-di,ghJi=-1-gh_i. Source J_B has slack2, not zero.
The local epsilon has(d,gh)=(1,-1),rho=(1,1),beta=(-1,-1),u/g=(0,0).
In particular beta has zero slack even though its dimension is negative.
All existing physical parameter dimensions are nonnegative and ghost0.

Slack is additive under multiplication and preserved by jets. Therefore any
admitted local polynomial has ell<=d-gh. Dimension4 ghost0 conversion
cochains have at most four external Lorentz slots. Q_Sigma raises d and gh
by1, including its rhoD part, so their dimension5 ghost1 images also have at
most four. This does not claim arbitrary inverse physical parameters are
admitted or physically identify u² with zero. Fixed coefficient extraction
alone limits the formal probe powers.

The complete actual382,646 known cofactor rows per route obey their ghost
and dimension bounds, not just selected fields. The unexpanded physical
potential/scalar Euler programs are retained: the qualified unshifted
scalar-only potential and constant-linear chart give the same homogeneity,
ghost and tensor conclusions, without choosing their unknown coefficients.
No assertion about shifted-vacuum or quantum tadpoles follows.

## Free-index attachment plus the fixed parent construction

For each nonzero actual vector-output monomial in F_B,E_B,known physical
E_B and D's vector-source outputs, record every carrier for its outputmu:
a B_mu/J_B^mu coordinate or an ordinary derivative with indexmu. The direct
scan and an independent free-slot-set construction agree in209,488 current
cofactor rows and2,804 D vector rows per route. No index is unattached.
There are132 actual witnesses in which erasing the last matching epsilon
jet loses the only attachment. The scalar-only mass*C vector replacement
has compatible degree/ghost but fails this incidence condition.

Attachment ALONE is not a no-numeric-loop theorem: D*B_mu*C passes it.
Use the SAME qualified V848 constructor: each parent tensor is a sum of
fixed rank0/2/4 metric pairings between actual field/source/jet slots, with
the prescribed source dual orientation, and no hidden closed numeric metric
loop. Internal Spin(10) contractions are independent of Lorentz dimension.
Physical kinetic terms use this same natural metric construction; potential
terms are Lorentz scalars. The source-nonlinear U and full KD are included.
Its uniqueness among all possible evanescent lifts is not asserted.

ONE Euler derivative of such a parent removes a single carrier. If it is
a vector carrier it exposes one metric line whose other end still meets a
real carrier or ordinary jet; the actual attachment audit verifies this
interface, including derivative-epsilon vector sources. Derivatives on the
variation are integrated by parts with the actual currents, preserving their
jet endpoints. A scalar Euler derivative exposes no vector index and retains
the parent contractions among the remaining slots. It cannot trace a free
vector identity by itself.

Now apply ONE local source/field substitution to a local cochain. A derivation
removes one of that cochain's carriers and inserts its complete rule. All
other old carrier endpoints remain. The exposed metric line joins to one
of the rule's real carrier/jet endpoints; it does not become an unrecorded
closed numeric metric circle. This graph argument applies also to sources,
to source-quadratic U, and to rhoD's scalar translation a->epsilon and its
full vector-source epsilon jets. Qepsilon=0. The potential contribution to
vector E_B is absent by actual scalar-only support; its scalar output is
covered by the same one-Euler argument, without expanded potential gradients.

This inference is deliberately restricted. An own-coordinate differentiation
or quantum sewing may close a line: sum_mu d(B_mu*C)/dB_mu=D*C. Jacobians,
second Hessians and quantum traces retain all such D factors. V850's empty
four-dimensional own-symbol tables do not themselves set an evanescent
Jacobian jet to zero. No measure claim is imported from this local lemma.

## External projection and the first jet

The local external metric module just proved closed has ranks0,2,4 only.
Its respective empty, single and three pairing tensors are already faithful
in four dimensions, with the prescribed vector/source variance. There is no
dimension-four-only antisymmetrization or spacetime epsilon in the constructor.
Consequently the actual one-substitution operation has the SAME coefficients
under external projection at D4; the graph proof shows it introduces no new
explicit numeric D factor. It preserves the external-component kernel of
the fixed constructor, including the ordinary-current relations.

Let a_D be such a local coefficient with its explicit analytic D-dependent
scalar coefficients retained. These coefficients may include closed QUANTUM
vector traces and the angular normalization. Q acts on fields/sources and
fixed local marks, not on D or those numerical angular factors. For this
fixed external module, projection/first derivative therefore commute with
the local substitution:

  Q_4 pi_4 a_D = pi_4 Q_D a_D,
  Q_4 pi_4(partial_D a_D)|4 = pi_4 partial_D(Q_D a_D)|4.

This is the scoped extension of the old first-jet/source lemma. It is not a
statement that every quantum operator, trace or tensor continuation is D
independent. The executed control a_D=(D-4)s_D has projection0 but derivative
s4=1/(8pi²), where s_D=area(S^(D-1))/(2pi)^D. Thus all internal loop traces
and the sphere-normalization derivative must survive until alpha'_4.

## Consequence and next decision

Together with V848's fixed lift, V849's full source-Euler insertion identity
and V850/851's selected IR/UV premises, this removes the specified LOCAL
source/projection/first-jet barrier. It permits the next construction to
differentiate a prospective single converted Cfin[Sigma+betaB[Sigma]] for
the action, marked insertion and transported beta*u*rho carrier under the
SAME clock, scale, kappa and reference. The full heat powers, first dimension
jet, reference determinant and regulator/source/mean terms remain required.

No new alpha'_4 coefficient or model amplitude is evaluated here. The
prospective family must still be constructed and checked against fixed
normalization and geometric W5 requirements. Bare DS/Ihat zeros do not define
normalized contacts. There is no full common restoration, model QAP/measure,
all-background/chiral/other-profile extension, E5/A5 or physical viability
promotion. Action, conventions, Python/SymPy and AI authorship remain shared
assumptions, not independent scientists or experimental validation.
