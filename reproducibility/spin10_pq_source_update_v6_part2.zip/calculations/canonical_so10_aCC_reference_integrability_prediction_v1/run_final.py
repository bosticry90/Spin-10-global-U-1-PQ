from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-reference-integrability-prediction-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
for pn in ['preparation.json','preparation_v2.json']:
 for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'prediction_result_v2.json').read_bytes())['homogeneous_suppressed_g0_after_actual_Q1_g1_extraction']
for n in ['PROOF.md','RESULT.md','FINAL_RECORD.md','final_review.py','run_final.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
extra=[R/'calculations'/d/n for d in ['canonical_so10_absolute_marked_quantum_g0_recovery_v1','canonical_so10_marked_proper_auxiliary_identity_g0_recovery_v1'] for n in ['PROOF.md','validation_receipt.json']]
for q in extra:assert q.read_bytes()==subprocess.check_output(['git','show','HEAD:'+q.relative_to(R).as_posix()],cwd=R)
names={**json.loads((O/'preparation.json').read_bytes())['sha256'],**{q.relative_to(R).as_posix():digest(q) for q in extra},**{q.relative_to(R).as_posix():digest(q) for q in O.iterdir() if q.is_file()}};names['docs/RESEARCH_EXECUTION_HANDOFF_V814.md']=digest(R/'docs/RESEARCH_EXECUTION_HANDOFF_V814.md');dump(O/'final_preparation.json',dict(sha256=names,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review.py')]);dump(O/'final_capture.json',cap);dump(C/'final_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
