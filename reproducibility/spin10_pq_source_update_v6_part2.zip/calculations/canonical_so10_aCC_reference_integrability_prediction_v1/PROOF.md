# A dependent reference prediction, with independent integration outstanding

Claim IDs: ACC-REF-1 (inherited known-operand distribution domain), ACC-REF-2
(dependent existence/prediction in that domain), ACC-REF-3 (exact coefficient
and IBP calculation). These do not create authority entries. The actual raw
aCC functional is the V811 two-response operator, not a freely selectable
coefficient. V813 qualifies the finite-formal identity used below. This
calculation does not establish restoration, Delta=0, a QAP, or E5/A5.

## Complete finite equation and existing operands

Keep unshifted Euclidean A0,firstg/first even constant u,intrinsic01, the
fixed physical regulator/reference normalization and formal nonnegative mean
series. In the LambdaCC projection, write Delta=QGamma and

    i R(A_t,delta) + K_t,delta = 0.

Here A is the actual M-probe aCC coefficient, R replaces its single a by
Lambda, and K is the sum of ALL other terms in
Q0Delta_gu+Q1Delta_u+Qu0Delta_g+Qu1Delta_0. V813's nonlocal field census,
not a local momentum ansatz, proves completeness of these families. Its
actual Jx independence excludes Qu1Delta_0, and Q1Delta_u needs only LambdaC.

Qu0Delta_g has only the unprobed aCC,JBCC,JLambdaCC,JaC preimages. The
unprobed proper aCC zero follows from V810's actual Ward/master proof;
unprobed proper JBCC from V808's source-grade/master proof and empty full
catalog; JLambdaCC from V809's additional actual source/master proof; JaC
from V806's new complete source-first catalog and proper bridge. These are
finite-profile zeros in their qualified domains. No unknown source-free
physical E1_x is assigned zero. The H-probe counterpart is already zero in
its qualified proper scope, and is not a new numerical prediction here.

The remaining first-u parents in K are B Lambda C,JBCC,JLambdaCC,JaC and
JaLambdaC, plus Q1 of the lower LambdaC. The JLambdaCC proper zero uses
its own proof, rather than an empty raw-regulator catalog alone. The other
nonzero reference parents are reconstructed from their OWN source packets,
not an assembled known consistency remainder. All source operations precede
the LambdaCC selection.

## ACC-REF-1: common distribution and finite-part readiness

The following are REUSED completed proofs/receipts and kernel limits, not
fresh independent loop integrations. Their bytes and owner receipts are
authenticated for this increment.

| operand | finite kernel and qualified reference evidence |
|---|---|
|B Lambda C|V803 proper normalization/transfer, retaining full physical8,ghost8,mixed30; V795/796/797-799 joint Schwartz bounds and reconciliation|
|JaLambdaC|V793 full opposite-color paired source kernels; V803 proper transfer, with the finite source interpretation corrected by V806|
|lower LambdaC|V804 actual odd Q of proper Gamma_vv; V782 heat master and V786 actual proper fixed-profile/root-defect domain|
|JaC|V806 actual-coefficient Berezin sign, exact heat master, polynomial UV and uniform IR bounds|
|JBCC|V809 actual full-color finite kernel and joint-source proof|
|finite-zero companions|V806,V808,V809,V810 proper-support/master proofs just listed|

All use the same E_t=exp(-tq2),F=f_delta E_t with
f_delta=(1-exp(-q2/delta2))2, same unshifted parent, and UV-first then IR
reference. V813 supplies the continuous classical operations on tempered
kernel distributions: transpose of derivatives/diagonal restrictions of
TEST FUNCTIONS for nonempty local replacements. No singular distribution
is pulled back and no two quantum insertions are multiplied. Constant
physical tadpole exceptions were excluded by actual source independence.

Vector physical8 has a uniform integrable Ward-reduced majorant and zero
reference. Ghost8 is a momentum multiplier of the paired source kernel,
also zero. Mixed30 uses the common I_m,J_m hard coefficients with polynomial
Schwartz tail bounds and pure-IR removal; its finite rational/logarithmic
reference is retained. The full normalized vector transfer keeps all46 paths.
These are whole-profile convergence results, without a new power subtraction.

JaLambdaC is generically NONZERO at finite profiles. The source kernels
K_Lambda-K_Ja have opposite colors. Their paired tail is O(L/q5), the bounded
region has independent pole2 coordinates, and Schwartz decay N>8 supplies
the joint majorant. V813's continuous source operations therefore carry
their reference to zero, not their finite expression. V806 corrects the
old named-current sign: actual C_Q=-C_R and proper Delta=+C_R. No old
positive compact current label is used as a finite operand here. Both
overall signs of the same paired kernel have the same zero reference, so
the corrected interpretation changes none of this convergence conclusion.

The lower n0 master has I0-2I1+I3=1/(3t)+11p2/36+O(tp4). V804 applies the
actual ODD Q operation to its proper Ca coefficient before replacing it
by a local density. V782 retains the physical inverse/source defect and
bounds it by the Gaussian/Riesz O(delta2) estimate, uniform in t,p. V786
owns the actual proper relation and same IR-root defect. Thus the lower
LambdaC power is its raw Q(Gamma_vv_n0)/(3t), and its finite reference is
the stored +i(11Q/36)Lambda boxC. Higher Lambda degrees cannot enter this
Q1 target by the exact field census, not by an auxiliary truncation guess.

For JaC, V806 gives B_E=1/(2t)+3p2/8+O(tp4),
0<=B_E-1/(2t)<=3p2/8 and remainder<=7tp4/48. The WHOLE IR difference
obeys |16pi2(B_F-B_E)|<=4delta2 uniformly in t,p and has a dominated UV
limit. Its power is T Ja C/(2t); its coordinate finite reference is
-(3/8)T Ja boxC. These powers are derived coefficients in the SAME linear
heat constant-term finite-part rule, not independent finite contacts.

JBCC's whole-profile kernel has no UV power or log(t) subtraction and
reference log(9/8) times sum K_acd(div JB_a)C_c C_d. The full ordered ghost
sum has no extra half. Its UV Schwartz majorant and IR bounds
32delta2/|p+r|2 (whole difference) and8delta2/|p+r|2 (pure-IR UV remainder)
are locally integrable in four external dimensions. They exclude an extra
delta-supported contact without assigning an exceptional pointwise value.

Each of these proofs applies to independently smeared old field/source
slots. V813's fixed continuous maps take these distributions into the SAME
LambdaCC source-test space. Finite color sums, Fourier derivatives and the
permutations in Q are continuous too. Thus K has a derived power P_K/t
and a subtracted UV S' limit at fixed delta, followed by its qualified
IR limit. No finite family is separately renormalized to enforce closure.

## ACC-REF-2: inference for an already defined unknown amplitude

At finite proof stage the actual identity says A=+i R^-1(K), as a formal
kernel functional. Since R^-1 is just the continuous field rename, the
known limits just reviewed IMPLY

    P_A = +i R^-1(P_K),
    FP_UV_then_IR A = +i R^-1(FP_UV_then_IR K).

This proves existence in the inherited selected source-test domain by a
DEPENDENT identity, rather than assuming convergence of the unknown first.
The common subtraction is the image of the measured known powers. No new
finite contact, physical parameter, counterterm or normalization is selected.
This is not a direct loop measurement. It shares the actual action, quantum
definition, source conventions, limit proofs and AI reasoning with K and
V813. An error common to these inputs could invalidate the prediction.
The direct V811 calculation remains required before source compatibility
or common-normalization claims, and is the next discriminating check.

## ACC-REF-3: arithmetic, types and representatives

Rebuild the vector reference with p=-i partial_B and ell=-i partial_Lambda;
the JaC reference with its minus-box sign; lower LambdaC from its actual
proper Q image; and JBCC from its own full ordered polynomial. Native
odd-prefix and LEFT jet operations agree on EVERY complete parent image
before projection. Full Q0/Q1 maps are used, including source coefficients
and known physical E0. Numerical assembled remainder containers are denied.

All references suppress overallg10. Actual Q1 has one explicitg10 whereas
Q0 has none. V1 omitted this extraction and combined distinct grades. Its
execution completed but its rational/power prediction is INVALID NOTPASS.
Its internal cancellation checks reproduced the same mistake and did not
validate the physics. V2 requires all parents g0, all actual Q0 images g0,
all actual lower Q1 images EXCLUSIVELYg1, then extracts that polynomial
coefficient, without dividing by a coupling value. Full graded and extracted
images are saved; the wrong-grade control is sensitive. All combined
polynomials and predictions are homogeneous in the suppressed convention.

The complete selected K is put into a Lambda-Euler/IBP normal. The Euler
route and independent literal repeated integration by parts agree, with
all four currents reconstructing K-N. For a single Lambda jet, the literal
step is (D_mu D_j Lambda)f =D_mu[(D_j Lambda)f]-(D_j Lambda)D_mu f.
It terminates after the finite number of jets; Lambda is even. At the end
N=sum Lambda_a Euler_Lambda_a(K). The predicted local representative is
+i R^-1(N). Its actual Q0 image is -N; hence K+Q0 A is precisely the saved
divergence. No EOM, p2=0 specialization or dropped term is used.

| V2 component | normal/prediction words | opposite-sign control | omit JBCC |
|---|---:|---:|---:|
|rational finite|10112|10112|not in this component|
|log(9/8) finite|10964|10964|6756|
|power1/t|444|444|not in this component|

These are exact representation sizes, not independent amplitudes or progress
percentages. V1 and V2 have the SAME word counts but different rational/power
coefficients. Counts could not diagnose the error; final review must compare
actual coefficients and grades. The log component is unaffected by that
specific correction. Frozen V1 sources/captures/outputs remain unchanged.

## Next test and authority ceiling

First directly evaluate the leading UV power of the actual two V811 response
operators, with full internal M color and Grassmann signs, independent of
this prediction as a computational input. It offers444 specific coefficient
positions to challenge before the harder full finite derivative kernels.
External-momentum zero may be used only in a justified leading-UV symbol/
Taylor subtraction calculation with an IR/remainder bound; it is NOT the
finite-reference exceptional-momentum shortcut. Then calculate the remaining
rational/log terms and compare to this dependent prediction. A mismatch
requires diagnosis of both sides, not adjustment of an unknown coefficient.

V1 completed83.940s/120 but is a semantic FAIL NOTPASS. V2 completed84.658s/
120. Final review owns fresh arithmetic replay, all complete-artifact/type/
IBP/negative-control comparisons, authenticated reused proof/receipt domain,
and one E4 with expected seven unresolved custody references NOTPASS.
8GiB sampled private/350MiB floor,64MiB packet/10MiB artifact; samples are
not true or nested-process peak. No Lean proof, independent scientists,
empirical result, new benchmark platform or authority promotion. State113,
34/39,E5/A5 unchanged. Full common restoration, source products, QAP,
measure/reality/equivalence, physical viability and full investigation open.
