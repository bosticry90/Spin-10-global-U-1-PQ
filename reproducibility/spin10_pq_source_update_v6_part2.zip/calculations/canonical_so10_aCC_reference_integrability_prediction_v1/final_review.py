from pathlib import Path
from hashlib import sha256
import gc,importlib.util,io,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-reference-integrability-prediction-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('fresh_typed_prediction_review',O/'predict_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a;read=a.read;load=a.load;digest=a.digest
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def resource(c):
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and all(0<q['private_bytes']<=8*1024**3 for q in c['all_resource_samples'])
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','preparation_v2.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes(),q.name
 base=read(O/'preparation.json');names=read(O/'final_preparation.json')['sha256'];receipts=[]
 for n in sorted(names):
  if n.startswith('calculations/') and '/validation_receipt' in n:
   r=read(R/n);assert r['execution_state']=='COMPLETED' and r['evidence_validation'].startswith('PASS') and r['scientific_acceptance']=='NOT_PERFORMED' and r['historical_custody']=='EXIT2_SEVEN_UNRESOLVED_NOTPASS';receipts.append(n)
 assert len(receipts)>=14
 caps=[]
 for suffix in ['', '_v2']:
  c=read(O/('prediction_capture'+suffix+'.json'));r=read(O/('prediction_result'+suffix+'.json'));assert c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified'] and r['execution_state']=='COMPLETED' and r['elapsed_after_imports']<120;resource(c);caps.append(c);assert digest(O/r['artifact']['file'])==r['artifact']['sha256']
 old=load(O/'prediction_tables.json.gz');new=load(O/'prediction_tables_v2.json.gz');grade=lambda P:sorted({k[0] for c in p.J.decode(P).values() for k,v in c.terms});diff=[]
 for v,u in zip(old['combinations'],new['combinations']):
  assert v['kind']==u['kind'] and grade(u['known_image'])==[0]
  if v['kind']=='log':assert v==u
  else:
   assert grade(v['known_image'])==[0,1] and v['Lambda_Euler_normal']!=u['Lambda_Euler_normal'];diff.append(v['kind'])
 assert diff==['rational','power_1_over_t']
 for row in new['reference_parent_images']:
  assert grade(row['actual_reference_parent'])==[0] and grade(row['suppressed_g_coefficient_image'])==[0]
  assert grade(row['full_graded_Q_image'])==([1] if row['parent'].startswith('lower') else [0])
 print('STAGE inherited_receipts_authenticated_V1_semantic_failure_demonstrated_V2_homogeneous_grades_verified',flush=True)
 compared=[];fresh=[];orig_open=Path.open
 class CompareBytes(io.BytesIO):
  def close(self):
   if not self.closed:
    assert self.getvalue()==(O/'prediction_tables_v2.json.gz').read_bytes(),'FRESH_FULL_ARTIFACT_DIFFERS';compared.append('prediction_tables_v2.json.gz')
   super().close()
 def controlled_open(path,mode='r',*args,**kwargs):
  if path==O/'prediction_tables_v2.json.gz' and mode=='xb':return CompareBytes()
  return orig_open(path,mode,*args,**kwargs)
 def compare_result(path,z):
  assert path==O/'prediction_result_v2.json';saved=read(path);assert {k:v for k,v in saved.items() if k!='elapsed_after_imports'}=={k:v for k,v in z.items() if k!='elapsed_after_imports'} and z['elapsed_after_imports']<120;fresh.append(z['elapsed_after_imports'])
 p.a.dump=compare_result;Path.open=controlled_open
 try:p.main()
 finally:Path.open=orig_open
 assert compared==['prediction_tables_v2.json.gz'] and len(fresh)==1;gc.collect()
 proof=(O/'PROOF.md').read_text(encoding='utf-8');assert all(s in proof for s in ['DEPENDENT','TEST FUNCTIONS','NONZERO','common','same zero reference','1/(3t)','independent','NOTPASS','not a direct loop measurement'])
 print('STAGE complete_typed_prediction_prefix_LEFT_Euler_literal_IBP_and_all_negative_controls_freshly_recomputed',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();q=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=q.returncode,seconds=time.perf_counter()-et,stdout=q.stdout,stderr=q.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert q.returncode==0
 events=[json.loads(s) for s in q.stdout.splitlines() if s.strip()];exits=[e['exit_code'] for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and next(e for e in events if e['event']=='step_finished' and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[z for z in O.iterdir() if z.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V814.md'];size=sum(z.stat().st_size for z in files);assert size<=64*1024**2 and all(z.stat().st_size<=10*1024**2 for z in files)
 out=dict(schema='DEPENDENT_ACC_REFERENCE_PREDICTION_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_DEPENDENT_INTEGRABILITY_PREDICTION_WITH_PRESERVED_MIXED_GRADE_FAILURE',scientific_acceptance='NOT_PERFORMED',base_HEAD=base['base_HEAD'],state_sha256=state,reference_parent_receipts_authenticated_not_fresh_loop_replays=receipts,common_source_limit_inheritance='WRITTEN_ACC_REF_1_WITH_REUSED_QUALIFIED_BOUNDS_NOT_FORMAL_KERNEL_CERTIFICATION',known_parent_images_freshly_reexecuted=7,full_prediction_artifact_freshly_recomputed_and_equal=True,homogeneous_grade_checks_and_full_graded_Q1_extraction_verified=True,V1='COMPLETED_EXECUTION_SEMANTIC_MIXED_GRADE_FAILURE_NOTPASS',V1_V2_actual_coefficient_differences_verified=diff,V1_and_V2_word_counts_same_not_authority=True,summary=new['summary'],independent_aCC_loop_measurement=False,direct_V811_full_color_momentum_UV_IR_check_still_required=True,no_assembled_known_remainder_read=True,no_common_restoration_or_normalization_adoption=True,execution_failures_this_increment=0,semantic_failed_calculations_this_increment=1,successful_V2_seconds=read(O/'prediction_result_v2.json')['elapsed_after_imports'],fresh_arithmetic_seconds=fresh[0],largest_sampled_private_bytes=max(s['private_bytes'] for c in caps for s in c['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={z.relative_to(R).as_posix():digest(z) for z in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_E5_A5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
