# V1 coupling-degree mismatch: completed execution, NOTPASS evidence

V1 completed83.940s/120 and its algebra/IBP controls passed. Post-run source
review found a semantic type error: the reference parent packets suppress
overallg10, whereas actual V802 Q1 coefficients retain one explicitg10.
V1 added the lower Q1 image without extracting that polynomial grade.
The other Q0 images have grade0 in the suppressed convention. This makes
V1 rational/power combinations invalid. Log-only arithmetic was unaffected
by this particular error, but the V1 calculation is NOT a qualified result.
Its sources/preparation/capture/artifact/result remain unchanged, including
its COMPLETED execution state; no evidence-validation receipt is granted.

NewV2 routine harness correction: assert all reference parents have g0
coefficients; assert all nonempty Q0 images have g0, actual Q1 lower images
have EXCLUSIVELYg1. Extract their exactg1 coefficient polynomially before
adding it to the suppressed-g parents, identically for prefix and LEFT.
No division by a coupling value or changed action/normalization. Save both
full graded and extracted images. A wrong-grade control must distinguish
the actual lower contribution. Add homogeneous-grade checks to every
combination and predicted image. All original sign/IBP/omission/domain/
resource obligations remain. Other failure modes must still fail.

One new120s after-import worker,8GiB sampled private/350MiB floor,64MiB
packet/10MiB artifact. Freeze corrected sources/new preparation before
execution; preserve failures. V2 is a justified bounded correction under
standing delegation, not a retry authorized by the old immutable allowance.
Analytic inheritance review/final validation remain separate and required.
No direct aCC loop measurement, restoration or scientific promotion follows.
