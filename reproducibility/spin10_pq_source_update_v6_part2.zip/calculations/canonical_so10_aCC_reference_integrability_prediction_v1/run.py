from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-reference-integrability-prediction-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_proper_normalization_transfer_g1_v1':['proper_reference.json.gz','transfer_result.json','validation_receipt.json','PROOF.md'],'canonical_so10_unmarked_g0_common_kinetic_recovery_v1':['derivation_tables_v2.json.gz','derivation_result_v2.json','validation_receipt.json','PROOF.md'],'canonical_so10_JaC_companion_g1_recovery_v1':['proper_reference.json.gz','analytic_result.json','validation_receipt.json','PROOF.md'],'canonical_so10_JBCC_companion_g1_recovery_v1':['proper_reference_v2.json.gz','analytic_result_v2.json','jlambda_support_result.json','validation_receipt.json','PROOF.md'],'canonical_so10_aCC_operator_reduction_g1_v1':['ward_tables.json.gz','ward_result.json','validation_receipt.json','PROOF.md'],'canonical_so10_ghost_source_companion_catalog_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_regulator_source_colors_g1_recovery_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_vector_physical_ward_g1_recovery_v1':['validation_receipt_v2.json','PROOF_V2.md'],'canonical_so10_vector_ghost_divergence_companion_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_vector_mixed30_g1_recovery_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_g0_scalar_source_independence_v1':['source_audit.py','validation_receipt.json','PROOF.md','source_independence_tables.json.gz'],'canonical_so10_selected_BV_square_g1_u1_v1':['square_v2.py','validation_receipt.json'],'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V813.md']+['calculations/'+d+'/'+n for d,nn in deps.items() for n in nn]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','predict.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={**{n:digest(R/n) for n in names},**{q.relative_to(R).as_posix():digest(q) for q in O.iterdir() if q.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'predict.py')]);dump(O/'prediction_capture.json',cap);dump(C/'prediction_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
