from pathlib import Path
from fractions import Fraction as F
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(s);s.loader.exec_module(z);return z
a=module('known_source_action_tools',O.parent/'canonical_so10_g0_scalar_source_independence_v1/source_audit.py');s=module('actual_full_BV_flows',O.parent/'canonical_so10_selected_BV_square_g1_u1_v1/square_v2.py');J=a.J;w=a.w;A=a.A
atom=lambda n,js=():{((n,tuple(js)),):J.constant(1)}
def project(P):return {ww:c for ww,c in P.items() if len(ww)==3 and sum(508<=n<553 for n,js in ww)==1 and sum(553<=n<598 for n,js in ww)==2}
def LEFT(P,Q):
 out={}
 for n,js in sorted({t for ww in P for t in ww}):J.add(out,J.mul(J.Ds(Q[n],js),J.leftjet(P,(n,js))))
 return J.clean(out)
def normal(P):
 E=J.euler(P,set(range(508,553)));N={}
 for n,p in E.items():J.add(N,J.mul(atom(n),p))
 N=J.clean(N);peer={};curr=[{} for _ in range(4)]
 for ww,c in P.items():
  at=next(i for i,(n,js) in enumerate(ww) if 508<=n<553);n,js=ww[at];rest={ww[:at]+ww[at+1:]:c}
  while js:
   mu=js[-1];js=js[:-1];J.add(curr[mu],J.mul(atom(n,js),rest));rest=w.scale(J.D(rest,mu),J.constant(-1))
  J.add(peer,J.mul(atom(n),rest))
 peer=J.clean(peer);curr=[J.clean(p) for p in curr];div={}
 for mu,p in enumerate(curr):J.add(div,J.D(p,mu))
 assert N==peer and w.plus(P,w.scale(N,J.constant(-1)))==J.clean(div)
 return N,curr
def rename(P):
 out={}
 for ww,c in P.items():J.put(out,tuple((n+90 if 508<=n<553 else n,js) for n,js in ww),J.times(J.I,c))
 return J.clean(out)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'preparation_v2.json')['sha256'].items():assert a.digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['known_consistency_images','consistency_tables.json','hard_response_v2.json']),'ASSEMBLED_REMAINDER_INPUT_DENIED'
 sys.addaudithook(guard)
 p=O.parent
 prior=a.read(p/'canonical_so10_g0_scalar_source_independence_v1/validation_receipt.json');assert prior['evidence_validation'].startswith('PASS_BOUNDED') and prior['finite_formal_WZ_only'] and prior['no_numerical_aCC_prediction_or_direct_integral_claim']
 maps,states,physical=s.full_maps(a.load(p/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz'));Q0=maps['Q0'];Q1=maps['Q1']
 vector=a.load(p/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz');vr=a.read(p/'canonical_so10_proper_normalization_transfer_g1_v1/transfer_result.json');assert a.digest(p/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz')==vr['artifact_sha256']
 jac=a.load(p/'canonical_so10_JaC_companion_g1_recovery_v1/proper_reference.json.gz');jr=a.read(p/'canonical_so10_JaC_companion_g1_recovery_v1/analytic_result.json');assert a.digest(p/'canonical_so10_JaC_companion_g1_recovery_v1/proper_reference.json.gz')==jr['artifact_sha256']
 lower=a.load(p/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_tables_v2.json.gz');lr=a.read(p/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_result_v2.json');assert a.digest(p/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_tables_v2.json.gz')==lr['artifact_sha256']
 jb=a.load(p/'canonical_so10_JBCC_companion_g1_recovery_v1/proper_reference_v2.json.gz');br=a.read(p/'canonical_so10_JBCC_companion_g1_recovery_v1/analytic_result_v2.json');assert a.digest(p/'canonical_so10_JBCC_companion_g1_recovery_v1/proper_reference_v2.json.gz')==br['artifact']['sha256']
 assert vector['source_zero_complement']['zero_ordered_reference_not_zero_finite_profile'] and jac['UV_first_then_IR'] and jb['UV_first_then_IR_joint_source_proof_written']
 parents={k:{} for k in ['vector_rational','vector_log','JaC_rational','JBCC_log','lower_rational','JaC_power','lower_power']}
 for r in vector['M_vector_all_positions']:
  aa,bb,cc=r['B'],r['Lambda'],r['C']
  for kind in ['rational','log']:
   cp=A.decode_coeff(r['p_'+kind]);ce=A.decode_coeff(r['ell_'+kind])
   if not cp and not ce:continue
   for mu in range(4):
    J.add(parents['vector_'+kind],w.scale(J.mul(J.mul(atom(4*aa+mu,(mu,)),atom(508+bb)),atom(553+cc)),J.times(-J.I,cp)))
    J.add(parents['vector_'+kind],w.scale(J.mul(J.mul(atom(4*aa+mu),atom(508+bb,(mu,))),atom(553+cc)),J.times(-J.I,ce)))
 for r in jac['source_color_rows']:
  if r['probe']!=1:continue
  n,c=r['Ja'],r['C'];v=A.decode_coeff(r['proper_QGamma_p2']);power=A.decode_coeff(r['proper_power_1_over_t'])
  J.add(parents['JaC_power'],w.scale(J.mul(atom(1241+n),atom(553+c)),power))
  for mu in range(4):J.add(parents['JaC_rational'],w.scale(J.mul(atom(1241+n),atom(553+c,(mu,mu))),-v))
 parents['JBCC_log']=J.decode(jb['coordinate_proper_reference_log']);lo=next(r for r in lower['cases'] if r['probe']==1);parents['lower_rational']=J.decode(lo['finite_unmarked_QGamma']);parents['lower_power']=w.scale(J.decode(lo['unmarked_raw_Q_prefix']),J.constant(F(1,3)))
 parents={k:J.clean(v) for k,v in parents.items()};images={};rows=[]
 for label,P in parents.items():
  assert all(key[0]==0 for c in P.values() for key,v in c.terms),('PARENT_NOT_SUPPRESSED_G0',label)
  Q=Q1 if label.startswith('lower') else Q0;native=s.v.act(P,Q,odd=True);peer=LEFT(P,Q);assert native==peer,label
  degree=1 if label.startswith('lower') else 0
  assert all(key[0]==degree for c in native.values() for key,v in c.terms),('WRONG_ACTUAL_IMAGE_GRADE',label)
  def extract(poly):
   return J.clean({word:J.Coeff([((0,*key[1:]),v) for key,v in c.terms]) for word,c in poly.items()})
  extracted=extract(native);extracted_peer=extract(peer);assert extracted==extracted_peer
  if label.startswith('lower'):assert native!=extracted and project(native)!=project(extracted),('WRONG_GRADE_CONTROL_BLIND',label)
  selected=project(extracted);images[label]=selected
  rows.append(dict(parent=label,actual_reference_parent=J.encode(P),full_graded_Q_image=J.encode(native),actual_image_g_degree=degree,suppressed_g_coefficient_image=J.encode(extracted),selected_LambdaCC=J.encode(selected),prefix_LEFT_equal=True));print('STAGE '+label+' parent='+str(len(P))+' selected='+str(len(selected)),flush=True)
 combinations={'rational':['vector_rational','JaC_rational','lower_rational'],'log':['vector_log','JBCC_log'],'power_1_over_t':['JaC_power','lower_power']};evidence=[];summary=[]
 for kind,labels in combinations.items():
  K=w.plus(*(images[n] for n in labels));N,curr=normal(K);pred=rename(N);predimage=s.v.act(pred,Q0,odd=True);assert predimage==LEFT(pred,Q0)
  assert all(key[0]==0 for poly in [K,N,pred,predimage] for c in poly.values() for key,v in c.terms),'MIXED_SUPPRESSED_COUPLING_GRADES'
  residual=project(w.plus(K,predimage));assert residual==w.plus(K,w.scale(N,J.constant(-1))) and not J.euler(residual,set(range(508,553)))
  wrong=w.scale(pred,J.constant(-1));wrongres=project(w.plus(K,s.v.act(wrong,Q0,odd=True)));wrongnorm,_=normal(wrongres);assert wrongnorm==w.scale(N,J.constant(2))
  omitdiff={}
  if kind=='log':
   omit,_=normal(images['vector_log']);omitdiff=w.plus(N,w.scale(omit,J.constant(-1)));assert omitdiff
  if kind!='power_1_over_t':assert N and wrongnorm
  evidence.append(dict(kind=kind,input_parent_labels=labels,known_image=J.encode(K),Lambda_Euler_normal=J.encode(N),four_IBP_currents=[J.encode(p) for p in curr],dependent_aCC_prediction=J.encode(pred),actual_Q0_prediction_image=J.encode(predimage),sum_residual_divergence=J.encode(residual),wrong_inverse_sign_normal=J.encode(wrongnorm),omit_JBCC_normal_difference=J.encode(omitdiff)))
  summary.append(dict(kind=kind,known_raw_words=len(K),normal_words=len(N),dependent_aCC_words=len(pred),wrong_inverse_changed_words=len(wrongnorm),omit_JBCC_changed_words=len(omitdiff)));print('STAGE '+json.dumps(summary[-1],sort_keys=True),flush=True)
 blob=gzip.compress((json.dumps(dict(reference_parent_images=rows,combinations=evidence,summary=summary),sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/'prediction_tables_v2.json.gz').open('xb') as h:h.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir() if q.is_file())<=64*1024**2
 result=dict(schema='DEPENDENT_ACC_REFERENCE_INTEGRABILITY_PREDICTION_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',analytic_inheritance_review='REQUIRES_SEPARATE_FINAL_VALIDATION',no_assembled_known_remainder_input=True,actual_parent_polynomials_and_full_BV_operations_reconstructed=True,homogeneous_suppressed_g0_after_actual_Q1_g1_extraction=True,V1_mixed_grade_semantic_failure_preserved_NOTPASS=True,prefix_LEFT_and_distinct_Euler_recursive_IBP_agree=True,dependent_prediction_not_direct_loop_measurement=True,independent_V811_color_momentum_UV_IR_check_still_required=True,summary=summary,artifact=dict(file='prediction_tables_v2.json.gz',sha256=a.digest(O/'prediction_tables_v2.json.gz'),bytes=len(blob)),elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'prediction_result_v2.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
