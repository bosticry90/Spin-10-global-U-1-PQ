from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fec2220b140e07281909cb027f86cc68d832e4af';cap=json.loads((O/'capture_a_v2.json').read_bytes());assert cap['exit_code']==0 and cap['post_run_observations_qualified']
names=set(json.loads((O/'preparation_a_v2.json').read_bytes())['sha256'])
for folder,files in{'canonical_so10_full_jet_source_master_bridge':['primary_inputs.json.gz','replay_inputs.json.gz','jets.py','final_review_validation_receipt.json'],'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json'],'canonical_so10_cartan_generator_residual_g1_v1':['audit.py','final_review_v4.py','validation_receipt.json'],'canonical_so10_Ward_primitive_canonical':['transport.py','validation_receipt_v2.json'],'canonical_so10_geometric_ward_products':['ward.py']}.items():names|={'calculations/'+folder+'/'+n for n in files}
names.add('tools/portable_dh_v1/inputs.json.gz')
for n in names:
 if not n.startswith('calculations/canonical_so10_acceptance_parent_reconciliation_v1/'):assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['PHASE_B_RECORD.md','compute_interface.py','execute_interface.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='fec2220b140e07281909cb027f86cc68d832e4af',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_b.json',prep);dump(C/'preparation_b.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_interface.py')]);dump(O/'capture_b.json',cap);dump(C/'capture_b.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
