# Historical Windows-path and policy-control correction

The first worker exited1 at its policy-substitution control before returning
its report. Exact source/copy/preparation/fullcapture remain NOTPASS. No
completed authentication or scientific replay may be inferred from it.

Two implementation assumptions were incorrect. The old receipt key strings
contain doubled Windows separators; Windows Path can open them,but a manual
backslash-to-slash prefix replacement did not recognize their repo-relative
identity. Use PureWindowsPath.as_posix() to normalize Windows PATH SEMANTICS,
while preserving original key strings and expected hashes unchanged.

Also live AGENTS already has EXACTLY historical SHA187b276c...e9c98. A
live-policy substitution is therefore BLIND as a byte test,not a required
failure. The record required reporting actual sensitivity. V2 requires six
policy rows,authenticates each from its recorded Git base,and reports that
actual blind/sensitive outcome. The deliberate in-memory wrong-digest control
remains required sensitive. No policy/hash/acceptance premise is weakened.

Same235 bindings,three original owners,original external control paths,
recorded bases,120s/8GiB limits and failure conditions. New outputs *_v2;
deterministic source transformation bound before the one continuation.
No old manifest,receipt,source or failed run edited/rebound/reclassified.
