# Acceptance-to-parent reconciliation: owner authentication

V846 prospective continuation at V845/fec2220b140e07281909cb027f86cc68d832e4af,
main,D:,goalACTIVE under live AGENTS/charter/solo/epistemic policy. Root
owns writes/runs/Git; two independent-input AI reviews are read only.
State113/34of39,flavor pause,HB1/C5 blocks,E5/A5 open and seven custody
NOTPASS unchanged. No adoption,protected promotion,branch/worktree or
external action. This evidence audit is not a new scientific status ledger.

Question: what ACTUAL accepted target and prior completed evidence should
control the next quantum investigation? V845 closed the selected bare D
regulator comparison; a homogeneous D condition has no established accepted
identification with the W5 geometric Ward target. Reconcile their actual
operators and previously completed geometric/source/parameter construction
before more amplitudes or another physical-span computation.

Owner capsules to authenticate: geometric_ward_products(GWP), actual_
normalization_assembly(ANA), physical_counterterm_span(PCS). Each receipt
has an input_sha256 map. Authenticate ALL235 declared bindings(58+77+100,
if actual schemas differ report rather than truncate). Preserve repeated
rows; dedup caching is computational only. No source/path guess or receipt
rebinding. Use original C: external control files where they exist. The
Documents repo path is the same D: junction,not a second checkout.

Historical execution policies MUST use recorded scientific bases:
GWP1f0a2347d8156f0d77895c68c4167a2c7d90d58b;
ANA84678b5e7fbf864127cc54144bcf8b7a08fa0ef8;
PCS29327f5332f68e002d5c81b82a7cbd93f59a61fe.
Retrieve AGENTS/CHARTER by git show BASE:path and compare their ORIGINAL
expected SHA. Bind live AGENTS separately for this new work. NEVER put
current policy bytes under a historical hash or edit an old manifest.

For any other differing repo binding,record the live mismatch and test the
exact recorded-base blob as historical evidence. Historical match does not
make the current operand applicable. A missing/mismatched external binding
stays unresolved; do not invent basename/source-copy fallbacks. All original
control originals have been located in preparation review. Authenticate
receipt bytes at their actual first-introduction commits too:
GWP7514f76772f4d66e30eabab66f5f8d7662fcc938;
ANAbaadb50b4d4f005e42edd59170db85bd94db75c4;
PCSf527745dbae9235c7474fd307c69a566dc695236.

Classify source/physical contracts,code/operands,policy/history,execution
controls separately in the report,without new authority scores. Check
declared execution COMPLETED and exact scope/false fullE5 flags,not a
manufactured modern receipt schema. Authenticate original results/captures
where bound; no scientific replay is inferred. Preserve known negative
F' literal-horizontal adequacy witness and global quantum assumptions.
In-memory wrong-digest and live-policy-substitution controls must be
reported with actual sensitivity; never repair the seven custody records.

Freeze exact sources,current contracts,three owner capsules,correct
StageD/E2 owners,current V828/V830/V845 interfaces,old tree/README. One
120s worker afterimports,8GiB sampled/350MiBfloor,16MiBpacket/8MiBartifact,
stream hashes,no silent skipped row or truncation. Save complete report
before any unresolved-binding gate. Outcomes: complete declared-byte
authentication in explicit historical scope,missing evidence/mismatch,or
bounded incomplete work. None proves mathematical validity or current
action/prescription equivalence. A separately frozen next phase should test
the first actual parent/source interface,not rerun completed loop tensors.
No E4/commit/statechange in this phase; combined final validation required.
