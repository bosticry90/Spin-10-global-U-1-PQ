from pathlib import Path
from hashlib import sha256
import gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2]
O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
OWNERS=[('canonical_so10_geometric_ward_products','1f0a2347d8156f0d77895c68c4167a2c7d90d58b','7514f76772f4d66e30eabab66f5f8d7662fcc938',58),('canonical_so10_actual_normalization_assembly','84678b5e7fbf864127cc54144bcf8b7a08fa0ef8','baadb50b4d4f005e42edd59170db85bd94db75c4',77),('canonical_so10_physical_counterterm_span','29327f5332f68e002d5c81b82a7cbd93f59a61fe','f527745dbae9235c7474fd307c69a566dc695236',100)]
def digest(q):
 h=sha256()
 with Path(q).open('rb')as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def read(q):return json.loads(Path(q).read_bytes())
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def gitblob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=R,stderr=subprocess.PIPE)
def repo_name(path):
 s=str(path).replace('\\','/');prefix='C:/Users/psboy/Documents/ToE-Next/'
 if s.lower().startswith(prefix.lower()):return s[len(prefix):]
 prefix=str(R).replace('\\','/')+'/'
 if s.lower().startswith(prefix.lower()):return s[len(prefix):]
 return None
def classify(rel):
 if rel in['AGENTS.md','CHARTER.md']:return'HISTORICAL_EXECUTION_POLICY'
 if rel and rel.startswith(('docs/','tools/'))and rel.endswith('.md'):return'CONTRACT_OR_DOCUMENT'
 if rel:return'REPOSITORY_SCIENTIFIC_OPERAND_OR_CODE'
 return'ORIGINAL_EXTERNAL_CONTROL'
def authenticate():
 results=[];unresolved=[];cache={};allrows=[];policycontrols=[]
 for folder,base,intro,count in OWNERS:
  root=R/'calculations'/folder;receipt=root/'validation_receipt.json';z=read(receipt)
  assert z['execution_state']=='COMPLETED'and len(z['input_sha256'])==count
  assert read(root/('preparation_v2.json'if folder.endswith('physical_counterterm_span')else'preparation.json'))['base']==base
  assert receipt.read_bytes()==gitblob(intro,receipt.relative_to(R).as_posix()),folder
  rows=[]
  for oldpath,expected in z['input_sha256'].items():
   rel=repo_name(oldpath);path=Path(oldpath);category=classify(rel)
   current=None
   if path.is_file():
    key=str(path.resolve())
    if key not in cache:cache[key]=digest(path)
    current=cache[key]
   row=dict(original_binding=oldpath,expected_sha256=expected,current_original_path_exists=path.is_file(),current_sha256=current,category=category,logical_repo_path=rel)
   if rel in['AGENTS.md','CHARTER.md']:
    blob=gitblob(base,rel);h=sha256(blob).hexdigest()
    row.update(method='RECORDED_BASE_GIT_POLICY_BYTES',recorded_base=base,historical_sha256=h,authenticated=h==expected,current_bytes_NOT_substituted=True)
    policycontrols.append(dict(owner=folder,path=rel,wrong_current_substitution_sensitive=current!=expected))
   elif current==expected:row.update(method='ORIGINAL_RECORDED_PATH_BYTES',authenticated=True)
   elif rel:
    try:blob=gitblob(base,rel);h=sha256(blob).hexdigest()
    except subprocess.CalledProcessError:h=None
    row.update(method='RECORDED_BASE_HISTORICAL_BYTES_WITH_LIVE_DIFFERENCE',recorded_base=base,historical_sha256=h,authenticated=h==expected,current_applicability_NOT_inferred=True)
   else:row.update(method='UNRESOLVED_ORIGINAL_EXTERNAL_BINDING',authenticated=False)
   rows.append(row);allrows.append(row)
   if not row['authenticated']:unresolved.append([folder,row])
  flags={k:v for k,v in z.items()if isinstance(v,(str,bool))and k not in['input_sha256']}
  results.append(dict(owner=folder,recorded_base=base,receipt_introduction_commit=intro,receipt_sha256=digest(receipt),all_declared_binding_rows=rows,declared_binding_count=len(rows),retained_original_receipt_scope_flags=flags,no_scientific_replay_or_current_parent_equivalence=True))
 control=sha256(b'PROSPECTIVELY_WRONG_IN_MEMORY_BINDING_CONTROL').hexdigest()
 wrong_control=all(control!=z['expected_sha256']for z in allrows)
 assert wrong_control and any(z['wrong_current_substitution_sensitive']for z in policycontrols if z['path']=='AGENTS.md')
 return dict(owners=results,total_declared_binding_rows=len(allrows),all_binding_rows_authenticate=not unresolved,unresolved_rows=unresolved,wrong_digest_control_sensitive=wrong_control,live_policy_substitution_controls=policycontrols,historical_policies_not_rebound=True,current_parent_equivalence_and_scientific_acceptance_NOT_performed=True)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation_a.json')['sha256'].items():assert digest(R/n)==h,n
 report=authenticate()
 blob=gzip.compress((json.dumps(report,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/'COMPLETE_AUTHENTICATION_OVERFLOW_NOTPASS.json.gz').open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/'complete_owner_binding_authentication.json.gz').open('xb')as f:f.write(blob)
 assert report['total_declared_binding_rows']==235 and report['all_binding_rows_authenticate'],'OWNER_BINDINGS_UNRESOLVED_REPORT_PRESERVED'
 out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_disposition='ALL235_DIRECT_OWNER_BINDINGS_AUTHENTICATED_IN_RECORDED_HISTORICAL_SCOPE_ONLY',owner_count=3,historical_policy_bytes_from_each_recorded_base=True,current_parent_equivalence_and_calculation_replay_NOT_established=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'result_a.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
