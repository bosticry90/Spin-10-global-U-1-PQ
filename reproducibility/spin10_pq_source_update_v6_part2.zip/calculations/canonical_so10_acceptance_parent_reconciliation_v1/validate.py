from pathlib import Path
from fractions import Fraction as Fq
from collections import defaultdict
from functools import lru_cache
from hashlib import sha256
import ast,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def module(name,q):
    sp=importlib.util.spec_from_file_location(name,q);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
h=module('APR_validation_basic_coefficients',O/'compute_interface.py')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def flat(rows):
    out={}
    for w,cs in rows:
        w=tuple((i,tuple(js))for i,js in w)
        for k,n,d in cs:out[w,tuple(k)]=Fq(n,d)
    return {k:v for k,v in out.items()if v}
def par(i):return int(i>=553)if i<643 else 1-int(i-643>=553)
def dim(i):return(2 if 508<=i<553 else 1)if i<643 else 3-dim(i-643)
def put(out,w,k,v):
    odd=[t for t in w if par(t[0])]
    if len(set(odd))!=len(odd):return
    sign=(-1)**sum(x>y for at,x in enumerate(odd)for y in odd[at+1:]);key=tuple(sorted(w)),k
    out[key]=out.get(key,Fq(0))+sign*v
def clean(q):return{k:v for k,v in q.items()if v}
def add(*qs):
    out={}
    for q in qs:
        for k,v in q.items():out[k]=out.get(k,Fq(0))+v
    return clean(out)
def scale(q,x):return clean({k:v*x for k,v in q.items()})
def mul(q,z):
    out={}
    for(w,k),v in q.items():
        for(ww,l),c in z.items():
            factor=(-1)**bool(k[3]&l[3]&16)
            for bit,prime in enumerate((2,3,5,7)):
                if k[3]&l[3]&(1<<bit):factor*=prime
            put(out,w+ww,(k[0]+l[0],k[1]+l[1],k[2]+l[2],k[3]^l[3]),v*c*factor)
    return clean(out)
def D(q,mu):
    out={}
    for(w,k),v in q.items():
        for at,(i,js)in enumerate(w):put(out,w[:at]+((i,tuple(sorted(js+(mu,)))),)+w[at+1:],k,v)
    return clean(out)
def E(q):
    partial={}
    for(w,k),v in q.items():
        for at,t in enumerate(w):
            sg=(-1)**(par(t[0])*sum(par(i)for i,js in w[:at]));out=partial.setdefault(t,{})
            put(out,w[:at]+w[at+1:],k,sg*v)
    out={}
    for(i,js),v in partial.items():
        q=clean(v)
        for mu in js:q=scale(D(q,mu),-1)
        out[i]=add(out.get(i,{}),q)
    return{i:q for i,q in out.items()if q}
def normal(q,e):
    out={k:v for k,v in q.items()if not k[0]}
    for i,z in e.items():
        for(w,k),v in z.items():put(out,((i,()),)+w,k,v/Fq(len(w)+1))
    return clean(out)
def analyze(q,stored):
    assert q==flat(stored['complete_difference'])
    e=E(q);assert len(stored['all1286_field_source_Eulers'])==1286
    assert {i:flat(z)for i,z in stored['all1286_field_source_Eulers']if z}==e
    assert sorted(e)==stored['nonzero_Euler_ports']
    n=normal(q,e);assert n==flat(stored['complete_homogeneous_Euler_normal'])
    currents=stored['four_complete_IBP_currents'];assert len(currents)==4
    assert add(q,scale(n,-1))==add(*(D(flat(z),mu)for mu,z in enumerate(currents)))
    constant=any(not w for w,k in q)
    assert constant==stored['constant_mismatch']and stored['functionals_equal']==(not e and not n and not constant)
    return e
def coeff(s):return{((),k):v for k,v in h.co(s).terms}
def phase(i):
    f=i-643 if i>=643 else i
    if 508<=f<553:return{((),(0,0,0,16)):Fq(-1)}
    if f<180 and f%4==0:return{((),(0,0,0,16)):Fq(1)}
    return{((),(0,0,0,0)):Fq(-1 if i>=643 and f<508 else 1)}
def reconstruction(role):
    old=load(R/'tools/portable_dh_v1/inputs.json.gz');frame=load(B/'canonical_so10_full_jet_source_master_bridge'/('primary_inputs.json.gz'if role=='native'else'replay_inputs.json.gz'))['frame'];names=frame['field_order'];idx={n:i for i,n in enumerate(names)}
    maps=defaultdict(dict)
    for i,j,s in frame['physical_to_raw_inverse']['entries']:
        maps[names[i]][j]=mul(coeff(s),phase(j))
    Jof={};geo=old['geometry']
    for i,j,hh,kk in geo['field_source_h_k']:Jof[geo['names'][i]]=geo['names'][j]
    for i,j,s in frame['physical_to_raw_kernel']['entries']:
        maps[Jof[names[j]]][643+i]=mul(coeff(s),phase(643+i))
    saved=load(O/(role+'_v2_complete_raw_row_dispositions.json.gz'))
    expected={n:{i:{((),tuple(k)):Fq(num,den)for k,num,den in cs}for i,cs in zz}for n,zz in saved['actual_maps']}
    assert dict(maps)==expected and len(maps)==1286
    dims={}
    for n,zz in maps.items():
        ds={dim(i)for i in zz};ps={par(i)for i in zz};assert len(ds)==len(ps)==1;dims[n]=ds.pop()
    @lru_cache(None)
    def token(n,js):
        out={}
        for i,zz in maps[n].items():
            for(ww,k),v in zz.items():assert not ww;put(out,((i,js),),k,v)
        t=js.count(0)%4
        factor={((),(0,0,0,16 if t%2 else 0)):Fq(-1 if t>=2 else 1)}
        return mul(out,factor)
    def transport(rows):
        out={};journal=[]
        for at,row in enumerate(rows):
            word=[]
            for t in row['word']:
                n,sep,js=t.partition('__');word.append((n,tuple(int(c)for c in js)))
            value={k:v for k,v in coeff(row['coefficient']).items()if k[1][0]<=1};status='RETAINED'
            if any(n.startswith('A')and n not in maps for n,js in word):status='A0_EXCLUDED'
            elif any(n not in maps for n,js in word):raise AssertionError(('FINAL_UNMAPPED_TOKEN',word))
            elif 4-sum(dims[n]+len(js)for n,js in word)not in(0,1):status='OUTSIDE_INTRINSIC01'
            elif not value:status='HIGHER_G_EXCLUDED'
            journal.append([at,status])
            if status!='RETAINED':continue
            q=scale(value,-1)
            for n,js in reversed(word):q=mul(token(n,js),q)
            for k,v in q.items():out[k]=out.get(k,Fq(0))+v
        return clean(out),journal
    gf,journal=transport(old['gauge_fixing_density']);assert journal==saved['all_GF_row_dispositions']and len(journal)==saved['all_GF_input_rows']
    source={};journals=[]
    for n,rows in old['master_field_maps'].items():
        zz=[dict(word=[Jof[n]]+row['word'],coefficient=row['coefficient'])for row in rows]
        q,journal=transport(zz)
        for k,v in q.items():source[k]=source.get(k,Fq(0))+v
        journals.append([n,journal])
    source=clean(source)
    assert journals==saved['all643_source_field_row_dispositions']and len(journals)==643
    assert gf==flat(saved['complete_GF'])and source==flat(saved['complete_source_action'])
    return gf,source
def main():
    tick=time.perf_counter();watch=threading.Timer(360,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='fec2220b140e07281909cb027f86cc68d832e4af'
    for n,v in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==v,n
    oldreadme=subprocess.check_output(['git','show',head+':README.md'],cwd=R)
    for pn in ['preparation_a.json','preparation_a_v2.json','preparation_b.json','preparation_c.json','preparation_c_v2.json']:
        z=read(O/pn);assert z==read(C/pn)
        for n,v in z['sha256'].items():assert(sha256(oldreadme).hexdigest()if n=='README.md'else digest(R/n))==v,(pn,n)
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes(),q.name
    s=(O/'compute_parent.py').read_text(encoding='utf-8');s=s.replace('A.encode_coeff(v)','[[list(k),q.numerator,q.denominator]for k,q in v.terms]').replace("role+'_complete","role+'_v2_complete").replace("'preparation_c.json'","'preparation_c_v2.json'").replace("'result_c.json'","'result_c_v2.json'")
    assert s==(O/'compute_parent_v2.py').read_text(encoding='utf-8')
    a=module('APR_final_historical_authentication',O/'compute_authentication_v2.py');auth=a.authenticate();assert auth['total_declared_binding_rows']==235 and auth['all_binding_rows_authenticate']
    assert load(O/'complete_owner_binding_authentication_v2.json.gz')['all_binding_rows_authenticate']
    samples=[]
    for capname,res,limit in[('capture_a.json',None,120),('capture_c.json',None,300),('capture_a_v2.json','result_a_v2.json',120),('capture_b.json','result_b.json',120),('capture_c_v2.json','result_c_v2.json',300)]:
        cap=read(O/capname);assert cap==read(C/capname)and cap['post_run_observations_qualified']and not cap['failed_or_incomplete_counted_as_PASS']
        assert cap['exit_code']==(0 if res else 1)and cap['calculation_completed']==bool(res)
        assert cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
        samples.extend(x['private_bytes']for x in cap['all_resource_samples'])
        if res:assert read(O/res)['elapsed_after_imports']<limit
    assert 'AssertionError'in read(O/'capture_a.json')['stdout_and_stderr']and "NameError: name 'A' is not defined"in read(O/'capture_c.json')['stdout_and_stderr']
    for role in['native','replay']:
        for g in[0,1]:
            partial=O/(role+'_complete_parent_g'+str(g)+'.json.gz')
            if partial.exists():assert partial.read_bytes()==(O/(role+'_v2_complete_parent_g'+str(g)+'.json.gz')).read_bytes()
    cases=[];oldparents=[]
    for role in['native','replay']:
        gf,source=reconstruction(role);oldparent=add(gf,source);oldparents.append(oldparent)
        sourceE=E(source);master=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(v)for n,v in master['states'].items()}
        necessary=load(O/(role+'_necessary_parent_interface.json.gz'));assert len(necessary['all180_necessary_source_Hamiltonian_field_interfaces'])==180
        for r in necessary['all180_necessary_source_Hamiltonian_field_interfaces']:
            g,n=r['g'],r['port'];expected={k:v for k,v in sourceE.get(643+n,{}).items()if k[1][0]==g};expected=scale(expected,(-1)**par(n))
            assert expected==flat(r['complete_transported_old_field_operation'])==flat(r['complete_current_operation'])==flat(states['F'+str(g)][n])
        for g in[0,1]:
            z=load(O/(role+'_v2_complete_parent_g'+str(g)+'.json.gz'));actual=flat(load(B/('canonical_so10_new_physical_returning_inventory_g1_recovery_v1'if g==0 else'canonical_so10_full_current_inventory_g1_recovery_v1')/(role+('_route_density.json.gz'if g==0 else'_route_densities.json.gz')))['original_GF'if g==0 else'S1'])
            oldslice={k:v for k,v in oldparent.items()if k[1][0]==g}
            assert oldslice==flat(z['complete_transported_portable_parent'])and actual==flat(z['complete_current_GF_source_parent'])
            delta=add(oldslice,scale(actual,-1));assert not analyze(delta,z['comparison'])
            wrong=add({k:v for k,v in gf.items()if k[1][0]==g},scale({k:v for k,v in source.items()if k[1][0]==g},-1),scale(actual,-1))
            assert analyze(wrong,z['wrong_source_dual_orientation_control'])
            cases.append(dict(role=role,g=g,all1286_Eulers_checked=True,source_control_sensitive=True,raw_difference_words=len({w for w,k in delta})))
        print('STAGE final '+role+' complete_parent_and_Eulers_reconstructed',flush=True)
    assert oldparents[0]==oldparents[1]
    assert (C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    historical=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(historical)and sha256(historical).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'
    assert b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V846.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(historical)].decode()),(R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',(R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md').read_text(encoding='utf-8')),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V846.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V846.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8')),(O/'PROOF.md',(O/'PROOF.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists(),target;links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(s)for s in e.stdout.splitlines()if s.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V846.md']
    receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_GEOMETRIC_ACCEPTANCE_RECONCILIATION_AND_COMPLETE_GF_SOURCE_PARENT_SLICE',base_HEAD=head,state_sha256=state,all235_historical_owner_bindings_authenticated_NOT_replayed=True,all180_necessary_source_operations_reconstructed=True,complete_raw_GF_source_transports_and_dispositions_reconstructed=True,cases=cases,both_transported_old_parents_equal=True,both_failures_preserved_NOTPASS=True,C2_deterministic_serialization_only_fix=True,complete_physical_background_dimensionjet_Tkappa_and_contact_applicability_NOT_established=True,maximum_sampled_primary_private_bytes=max(samples),sampled_not_continuous_peak=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_inputs_chart_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick)
    dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','cases','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
