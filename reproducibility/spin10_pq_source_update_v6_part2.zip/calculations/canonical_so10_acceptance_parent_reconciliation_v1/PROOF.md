# Acceptance target and complete classical parent slice

The owning [conditional W1-W7 specification](../../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md)
requires nonlinear Slavnov, local background Ward and a BROKEN geometric
quantum H Ward identity with whole renormalized products. W5 is

    W_q Gamma = [T_q S_R]_Gamma + M_q.

Its source realization uses all56 nonzero c_J in the complete643-column
product sum c_J EL_J S_R. Replacing this whole product by c_J(phi) EL_J Gamma
loses connected/contact terms. Current antighost translation D is a different
operation from geometric H. No accepted intertwiner equates their quantum
products or requires homogeneous D Gamma=0. V845's nonzero bare regulator
response therefore does not by itself obstruct E5. It is not discarded.

Three completed historical owners are relevant: geometric_ward_products
(GWP), actual_normalization_assembly (ANA), physical_counterterm_span (PCS).
Their235 direct receipt bindings have been authenticated in their recorded
historical scopes, including each original policy blob and external controls.
Authentication is not mathematical replay, theorem applicability or current
scheme adoption. PCS already supplies the formal bosonic physical span;
ANA's older suggestion to investigate that span is superseded by PCS.
The original nonhorizontal F' witness, universal adequacy gap and protected
HB1/C5 boundary remain. Do not replace them by a narrower successful problem.

## Parent transported, not inferred from Ward variations

Literal portable operand is

    S_old = gauge_fixing_density + sum_(643 fields i) J_i R_i.

All raw master_field_maps R_i are source-free; the separate probe actions
can contain quadratic sources. There is no original-action source double
count. GWP's Ward checks alone do not compare this action to the recovered
parent, so the complete density comparison is necessary.

Use the actual FJB inverse T and kernel F, with FT=TF=1 across643 fields.
Raw fields are T phase_field z_E; raw sources are F^transpose phase_source J_E.
The source phase is not guessed from the field phase. Each time jet contributes
i, and the inherited density Wick map contributes minus. All external A and
their jets are set zero; retain g0/g1 and intrinsic deficits0/1. Each raw GF
and source row has an explicit disposition, with no source-degree truncation.
Physical source-free cubic/potential terms are a separate action part and
are NOT added to either GF/source operand.

For Lambda/a ports, literal transported source differentiation gives
the previously fixed Hamiltonian factor -(-1)^p phase_J F on raw R_i.
Phase B compares all180 g0/g1 interfaces. Both ordered Coeff and independent
expanded Fraction/radical constructions agree exactly. This alone does not
compare the other553 source ports or the source-free GF part.

Phase C2 compares COMPLETE S_old against original_GF at g0 and S1 at g1,
separately for native/replay. The old transported densities agree between
routes. Raw current density representatives need not agree before IBP.
For each difference P, compute all1286 left Euler derivatives twice, once
in ordered Coeff arithmetic and once in expanded Fraction words. Use the
graded homogeneous variational identity to construct four explicit currents:

    P = N(P) + sum_mu partial_mu j_mu,
    N(P) = sum_(homogeneous degree n,i) z_i E_i(P_n)/n + constant(P).

Every N and Euler column vanishes; constant mismatch is absent. This proves
functional equality in the stated local quotient, rather than asserting that
different density representatives are literally identical. A deliberately
reversed complete source action has nonzero Euler images in all four cases.
Final validation must reconstruct raw transports independently and check the
full currents, Euler columns and wrong-sign evidence, not only summary flags.

## Quantum applicability is still conditional

GWP/ANA/PCS use the SAME specified converted lifted trace. The definitions in
[general trace extension](../canonical_so10_general_identity_trace_extension/DERIVATION.md)
and [dimensional Stokes primitive](../canonical_so10_dimensional_stokes_primitive/DERIVATION.md)
give

    T_kappa(A_D)=tau_h(A4)-alpha'_4(A_D)
                   +(kappa-1-log(16pi))*alpha4(A4)/2.
    C_fin=-Lheat-(i/2)alpha'_4(L_D).

Lheat includes critical logarithms, heat jets multiplied by power terms,
the common nonlocal/IR remainder, all fixed scale terms and the retained
reference determinant. The first dimension jet keeps vector multiplicities
D while internal representation ranks are fixed. A4 equality cannot supply
that jet: (D-4)/p^4 has zero4D image and nonzero alpha'_4.

GWP expressly qualifies W5 in this converted prescription. Its raw-heat
measure term is delta_Bq C_fin - T_q C_fin with the same insertion extension,
not a regulator coefficient chosen to enforce cancellation. V846 does not
compare the recovered bare positive-heat/IR family to that augmented fixed-lift
parent. It also does not compare the full physical scalar potential, all g,
all backgrounds or matter. No automatic quantum theorem transfer follows.
These are the next applicability questions, before more D-sector amplitudes.

Original A1-A5 (measure/Legendre/IR, model QAP, joint restoration, products,
quantum equivalence), physical viability and complete E5/A5 remain open.
Shared action, chart conventions, Python/SymPy and AI authorship limit the
independence. This is a bounded mathematical interface result, not empirical
validation, a new physical law or a proof-assistant formalization.
