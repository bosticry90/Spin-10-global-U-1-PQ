from pathlib import Path
O=Path(__file__).resolve().parent
def transformed(s):
 lines=s.splitlines();found=[i for i,z in enumerate(lines)if z.startswith(' s=str(path).replace(')];assert len(found)==1
 lines[found[0]]=" s=PureWindowsPath(str(path)).as_posix();prefix='C:/Users/psboy/Documents/ToE-Next/'"
 s='\n'.join(lines)+'\n'
 replacements=[('from pathlib import Path','from pathlib import Path,PureWindowsPath'),("assert wrong_control and any(z['wrong_current_substitution_sensitive']for z in policycontrols if z['path']=='AGENTS.md')","assert wrong_control and len(policycontrols)==6"),("read(O/'preparation_a.json')","read(O/'preparation_a_v2.json')"),("O/'complete_owner_binding_authentication.json.gz'","O/'complete_owner_binding_authentication_v2.json.gz'"),("dump(O/'result_a.json',out)","dump(O/'result_a_v2.json',out)")]
 for x,y in replacements:assert s.count(x)==1,x;s=s.replace(x,y)
 return s
if __name__=='__main__':
 with(O/'compute_authentication_v2.py').open('x',encoding='utf-8',newline='\n')as f:f.write(transformed((O/'compute_authentication.py').read_text(encoding='utf-8')))
