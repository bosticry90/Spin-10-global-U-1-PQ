# Complete GF/source density and Hamiltonian comparison

All180 necessary interfaces passed in6.962s in both routes. This is not
the full parent bridge. Continue at fec2220b under unchanged delegation,
state113/34of39,protected blocks and scope. Root writes/runs; AI reviews
read only. No new loop,parameter,scheme or scientific-state promotion.

Now transport the COMPLETE literal GWP parent: all portable GF rows plus
all643 source couplings J_i R_i. Actual geometry determines sources; retain
any source factor encountered,not a guessed source-degree cutoff. Use
FJB F/T,all actual field/source Wick phases,+i per timejet,densityminus,
A/alljets0,g<=1,intrinsic0/1. Check every input row disposition. No physical
sourcefree cubic term is part of either old or current GF/source density.

Compare separately g0 to current original_GF and g1 to current S1 for
native/replay. Construct both complete transported old densities by native
ordered Coeff versus Fraction/radical multiplication. They must agree.
Current route densities may differ by IBP; do NOT demand their raw equality.
For EACH difference derive ALL1286 field/source Euler columns,compare native
Euler with independent expanded-Fraction LEFT Euler,then reconstruct explicit
four homogeneous variational currents. Any field-independent constant or
nonzero Euler/normal is a real scoped parent mismatch to preserve; never
erase or fit it. Save complete differences/currents/Eulers before disposition.

If all functional comparisons pass,this closes the GF+source action interface
at A0,g<=1,intrinsic01,including the formerly untested553 source operations
FOR THIS GF/SOURCE PART. It does not compare the full physical potential,
all higherg,all backgrounds,matter,complete E2 conjugacy or quantum maps.
The GF/source action may contain physical-field source couplings but its
sourcefree physical gauge/scalar action is separate. Preserve that distinction.

Use the known wrong source-dual orientation on source-bearing words as a
negative control; retain full functional mismatch and actual sensitive/blank
cases. The original F' nonhorizontal-domain witness and three old owner
scope ceilings remain unchanged even if this parent slice agrees.

One300s afterimports,8GiB sampled/350MiBfloor,64MiBpacket/12MiBartifact.
Full records/failure/overflow preserved NOTPASS; no truncation or silent
resource expansion. Freeze sources/all actual GF/density/frame inputs and
receipts before computation. No E4/localcommit in this phase. Combined final
validation must rederive decisive full differences and currents,authenticate
all input/policy histories and keep evidence validation distinct from any
observed mathematical mismatch. Shared action/frame/software/AI limit
independence. The separate bare-heat to converted T_kappa interface remains
unproved by a classical parent comparison and must be assessed next.
