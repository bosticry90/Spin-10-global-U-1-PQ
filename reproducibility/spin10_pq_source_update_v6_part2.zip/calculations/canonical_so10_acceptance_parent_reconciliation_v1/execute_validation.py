from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fec2220b140e07281909cb027f86cc68d832e4af'
assert json.loads((O/'result_c_v2.json').read_bytes())['all_current_parent_functionals_match']
names=set(json.loads((O/'preparation_c_v2.json').read_bytes())['sha256'])
names|={'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V846.md'}
for folder in['canonical_so10_general_identity_trace_extension','canonical_so10_dimensional_stokes_primitive','canonical_so10_geometric_ward_products','canonical_so10_finite_heat_transgression']:
    for n in['DERIVATION.md','RESULT.md','validation_receipt.json']:names.add('calculations/'+folder+'/'+n)
for n in['PROOF.md','RESULT.md','FINAL_RECORD.md','validate.py','execute_validation.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
prep=dict(base_HEAD='fec2220b140e07281909cb027f86cc68d832e4af',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_validation.json',prep);dump(C/'preparation_validation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'validate.py')]);dump(O/'capture_validation.json',cap);dump(C/'capture_validation.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
