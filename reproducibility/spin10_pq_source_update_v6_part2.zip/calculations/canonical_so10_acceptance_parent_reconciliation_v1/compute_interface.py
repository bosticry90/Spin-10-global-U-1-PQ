from pathlib import Path
from fractions import Fraction as Fr
from functools import lru_cache
from hashlib import sha256
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def module(name,q):
 sp=importlib.util.spec_from_file_location(name,q);out=importlib.util.module_from_spec(sp);sp.loader.exec_module(out);return out
a=module('APR_existing_classical_algebra',B/'canonical_so10_cartan_generator_residual_g1_v1/audit.py');J=a.J;p=a.p;A=a.A;load=a.load;read=a.read;digest=a.b.digest
raw=module('APR_plain_Fraction_words',B/'canonical_so10_cartan_generator_residual_g1_v1/final_review_v4.py')
import coefficient_ring as ring
PORTS=list(range(508,553))+list(range(598,643))
@lru_cache(None)
def co(text):return ring.coefficient(ring.s.sympify(text,locals={'g10':ring.g,'xi':ring.xi,'eta_H':ring.eta}))
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
def split(token):
 name,sep,jet=token.partition('__');return name,tuple(int(x)for x in jet)
def rm(X,Y):
 out={}
 for(w,k),v in X.items():
  for(ww,kk),c in Y.items():
   factor=-1 if k[3]&kk[3]&16 else 1
   for bit,prime in enumerate([2,3,5,7]):
    if k[3]&kk[3]&(1<<bit):factor*=prime
   key=(k[0]+kk[0],k[1]+kk[1],k[2]+kk[2],k[3]^kk[3]);raw.put(out,w+ww,key,v*c*factor)
 return{k:v for k,v in out.items()if v}
def unflat(P):
 out={}
 for(w,k),v in P.items():out.setdefault(w,[]).append((k,v))
 return{w:J.Coeff(cs)for w,cs in out.items()}
def mm(X,Y):
 rows=defaultdict(list);out={}
 for(k,j),v in Y.items():rows[k].append((j,v))
 for(i,k),v in X.items():
  for j,w in rows[k]:out[i,j]=out.get((i,j),a.zero)+J.times(v,w)
 return{k:v for k,v in out.items()if v}
def run(role):
 old=load(R/'tools/portable_dh_v1/inputs.json.gz');frame=load(B/'canonical_so10_full_jet_source_master_bridge'/('primary_inputs.json.gz'if role=='native'else'replay_inputs.json.gz'))['frame'];names=frame['field_order'];assert len(names)==643 and len(set(names))==643;idx={name:i for i,name in enumerate(names)};F={(i,j):co(s)for i,j,s in frame['physical_to_raw_kernel']['entries']};T={(i,j):co(s)for i,j,s in frame['physical_to_raw_inverse']['entries']};ident={(i,i):a.one for i in range(643)};assert mm(F,T)==ident and mm(T,F)==ident;Tr=defaultdict(list);Fc=defaultdict(list)
 for(i,j),v in T.items():Tr[names[i]].append((j,v));assert all(k[0]==0 for k,z in v.terms)
 for(i,j),v in F.items():Fc[j].append((i,v));assert all(k[0]==0 for k,z in v.terms)
 geo=old['geometry'];gn=geo['names'];source_names={gn[j]for i,j,h,k in geo['field_source_h_k']};rawpars={name:geo['parities'][geo['names'].index(name)]for name in names};dims={}
 for name,terms in Tr.items():
  ds={J.dimension(i)for i,v in terms};assert len(ds)==1 and all(J.parity(i)==rawpars[name]for i,v in terms);dims[name]=next(iter(ds))
 source_rows=[]
 for name,rows in old['master_field_maps'].items():
  for at,row in enumerate(rows):
   if any(split(t)[0]in source_names for t in row['word']):source_rows.append([name,at,row])
 assert not source_rows,'PORTABLE_SOURCE_DENSITY_REQUIRES_SOURCE_DEGREE_HOMOTOPY_NOT_LINEAR_FORMULA';assert set(old['master_field_maps'])==set(names)
 @lru_cache(None)
 def token(name,js):
  phase=[a.one,J.I,-a.one,-J.I][js.count(0)%4];return{((i,js),):J.times(J.times(v,J.phase(i)),phase)for i,v in Tr[name]}
 def transport(rows,dimension):
  out={};journal=[]
  for at,row in enumerate(rows):
   word=[split(t)for t in row['word']];value=co(row['coefficient']);status='RETAINED'
   if any(name.startswith('A')and name not in idx for name,js in word):status='A0_EXCLUDED'
   elif any(name not in idx for name,js in word):raise AssertionError(('UNMAPPED_RAW_FIELD',word))
   elif dimension-sum(dims[n]+len(js)for n,js in word)not in[0,1]:status='OUTSIDE_INTRINSIC01'
   value=J.Coeff([(k,v)for k,v in value.terms if k[0]<=1])
   if not value and status=='RETAINED':status='HIGHER_G_EXCLUDED'
   journal.append([at,status])
   if status!='RETAINED':continue
   if role=='native':
    term={():value}
    for n,js in word:term=J.mul(term,token(n,js))
    J.add(out,term)
   else:
    term=raw.flat(J.encode({():value}))
    for n,js in word:term=rm(term,raw.flat(J.encode(token(n,js))))
    J.add(out,unflat(term))
  return J.clean(out),journal
 flows={n:{}for n in PORTS};journals=[];selected=[]
 for raw_i,outputs in sorted(Fc.items()):
  wanted=[(i,v)for i,v in outputs if i in PORTS]
  if not wanted:continue
  assert all(i in PORTS for i,v in outputs),'SOURCE_DUAL_FRAME_MIXES_SELECTED_AND_OTHER_GRADES';name=names[raw_i];rr,journal=transport(old['master_field_maps'][name],dims[name]+1);journals.append([name,journal]);selected.append(name)
  for i,v in wanted:
   factor=J.times(J.times(v,J.phase(643+i)),J.constant(-(-1)**J.parity(i)))
   J.add(flows[i],p.scale(rr,factor))
 flows={n:J.clean(q)for n,q in flows.items()};packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={k:dict(v)for k,v in packet['states'].items()};rows=[];mismatch=[];control=[]
 for g,state in[(0,'F0'),(1,'F1')]:
  for n in PORTS:
   expected=J.decode(states[state][n]);got=a.grade(flows[n],g);d=a.plus(got,a.neg(expected));rows.append(dict(g=g,port=n,actual_source_name_current=643+n,complete_transported_old_field_operation=J.encode(got),complete_current_operation=J.encode(expected),complete_difference=J.encode(d),match=not d))
   if d:mismatch.append([g,n])
   wrong=a.plus(a.neg(got),a.neg(expected))
   if wrong!=d:control.append([g,n,J.encode(wrong)])
 result=dict(all180_necessary_source_Hamiltonian_field_interfaces=rows,complete_mismatch_ports=mismatch,selected_raw_source_fields=selected,all_selected_raw_row_dispositions=journals,all643_portable_field_maps_sourcefree=True,full643_frame_inverse_checked=True,source_Euler_factor='-(-1)^p_i * phase_source_i * F_i_raw, derivedfromliteraltransportedsourceaction',wrong_source_derivative_orientation_differences=control,full_GF_density_other553_source_rows_and_quantum_conversion_NOT_tested=True)
 save(role+'_necessary_parent_interface.json.gz',result)
 return result
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation_b.json')['sha256'].items():assert digest(R/n)==h,n
 first=run('native');second=run('replay');assert first==second,'COMPLETE_NATIVE_FRACTION_NECESSARY_INTERFACE_DIFFERENCE';mismatches=first['complete_mismatch_ports'];out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='NECESSARY_PARENT_SOURCE_INTERFACE_MISMATCH_UNDER_DECLARED_LINEAR_WICK_MAP'if mismatches else'ALL180_NECESSARY_PARENT_SOURCE_INTERFACES_MATCH_FULL_ACTION_BRIDGE_PENDING',all180_complete_comparisons_retained=True,complete_native_Fraction_evidence_equal=True,mismatch_count=len(mismatches),mismatch_ports=mismatches,wrong_source_sign_sensitive_ports=len(first['wrong_source_derivative_orientation_differences']),no_model_obstruction_or_old_scope_retraction_or_parent_equivalence_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_b.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
