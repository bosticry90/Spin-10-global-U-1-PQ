from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fec2220b140e07281909cb027f86cc68d832e4af';z=json.loads((O/'result_b.json').read_bytes());assert z['mismatch_count']==0
names=set(json.loads((O/'preparation_b.json').read_bytes())['sha256'])
for role in['native','replay']:
 names.add('calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_route_density.json.gz');names.add('calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+role+'_route_densities.json.gz')
for folder in['canonical_so10_new_physical_returning_inventory_g1_recovery_v1','canonical_so10_full_current_inventory_g1_recovery_v1']:names.add('calculations/'+folder+'/validation_receipt.json')
names.add('calculations/canonical_so10_full_current_inventory_g1_recovery_v1/factory.py')
for n in names:
 if not n.startswith('calculations/canonical_so10_acceptance_parent_reconciliation_v1/'):assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['CONTINUATION_C2.md','build_parent_v2.py','compute_parent_v2.py','execute_parent_v2.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='fec2220b140e07281909cb027f86cc68d832e4af',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_c_v2.json',prep);dump(C/'preparation_c_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_parent_v2.py')]);dump(O/'capture_c_v2.json',cap);dump(C/'capture_c_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
