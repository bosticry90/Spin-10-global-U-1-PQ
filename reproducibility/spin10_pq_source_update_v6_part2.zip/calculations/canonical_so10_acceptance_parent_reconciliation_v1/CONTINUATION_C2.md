# Phase C2: serialization correction after explicit resumption

The director explicitly resumed the goal after the human pause. Recover actual
Git/process state first: HEAD fec2220b, no live scientific worker, state113 and
authority34/39 unchanged. Root owns all writes/execution; two agents review
sources read only. Previous pause turn is a verified stopping-point observation,
not a completed scientific increment.

Preserve compute_parent.py, its source copy, preparation_c.json, capture_c.json
and the native partial artifacts unchanged. Phase C FAILED exit1 after40s:
the raw-row journal referred to undefined A.encode_coeff. Native g0/g1 had
reported equal functionals, but replay and complete evidence never finished.
Neither those messages nor the partial files qualify Phase C.

Generate new compute_parent_v2.py deterministically from that exact failed
source. Replace only undefined coefficient serialization by the literal
Coeff.terms encoding already used by J.encode. Give all newly written artifacts,
preparation, result and capture distinct v2 names. No change to action, maps,
grading, signs, equations, complete Euler checks, currents, negative controls,
acceptance requirements or original300s/8GiB bounds. Capture all input hashes,
source copies and current policy before execution, then run once. Overflow and
failure remain NOTPASS; no automatic resource expansion.

All Phase C mathematical requirements still apply. Positive outcome closes
only the A0,g<=1,intrinsic0/1 GF+source parent interface modulo explicitly
reconstructed divergences. It does not transfer the older converted T_kappa
prescription to current bare heat finite parts, prove physical/background
parent equality, complete E2/QAP/products/equivalence, or promote E5/A5.
Final combined validation is separate and must precede any local commit.

The newer user assessment motivates this acceptance/applicability test. Reuse
the older qualified geometric-Ward, normalization and physical-span owners;
do not replace geometric W5 by homogeneous auxiliary D invariance. State,
HB1/C5/flavor boundaries, main and all original evidence remain unchanged.
