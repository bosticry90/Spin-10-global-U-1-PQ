from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='fec2220b140e07281909cb027f86cc68d832e4af'
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/RESEARCH_EXECUTION_HANDOFF_V845.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_DOMAIN_CONTRACT_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_DOMAIN_RESULT.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md','calculations/canonical_so10_restoration_probe_interface_audit_v1/RESULT.md','calculations/canonical_so10_restoration_probe_interface_audit_v1/validation_receipt.json','calculations/canonical_so10_source_homotopy_applicability_g1_v1/validation_receipt.json','calculations/canonical_so10_marked_regulator_parent_g1_v1/validation_receipt.json'}
for folder in['canonical_so10_geometric_ward_products','canonical_so10_actual_normalization_assembly','canonical_so10_physical_counterterm_span']:
 for n in['RESULT.md','validation_receipt.json','preparation.json','validation_preparation.json']:names.add('calculations/'+folder+'/'+n)
names.add('calculations/canonical_so10_physical_counterterm_span/preparation_v2.json')
for folder in['frozen_a10_bv_integration','frozen_a10_e2_transport']:
 for n in['bindings.json','validation_receipt.json']:names.add('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'+folder+'/'+n)
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n in['PHASE_A_RECORD.md','compute_authentication.py','execute_authentication.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
with(C/'README_before.md').open('xb')as f:f.write((R/'README.md').read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_a.json',prep);dump(C/'preparation_a.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_authentication.py')]);dump(O/'capture_a.json',cap);dump(C/'capture_a.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
