# Necessary complete-parent source interface, before a large density transport

PhaseA2 authenticated all235 owner bindings in1.303s; no scientific replay
or current applicability was inferred. Continue fec2220b under same live
delegation,rootwrites/runs/read-onlyAIreviews,unchanged state/blocks/ceilings.

The next target is the actual complete GF+source parent used by GWP,ANA,PCS,
not another D coefficient. GWP ward.py74 constructs portable gauge_fixing_
density+sum J_i master_field_maps[i]. Its direct Ward checks do NOT prove
whole-action equality. Portable original maps and current ORIGINAL F1 are
source-free; do not invent quadratic-source overcount. Probe source degrees
are a separate issue. Current original_GF/S1 are GF+sources ONLY; physical
sourcefree cubic terms are separate and must not be added to this comparison.

First apply the least expensive NECESSARY test. Reconstruct source Euler
field operations for all90 Lambda/a ports,at g0 and g1,A0/intrinsic0/1,
from the literal portable source action and the ACTUAL FJB linear F/T Wick
map. Compare current full source-first F0/F1 columns. A mismatch disproves
identification by THIS declared map; preserve it before any full33092-row
GF transport. A passing necessary test would NOT prove the action bridge:
then freeze a separate continuation for the full density/1286Euler/current
comparison. No chart correction is chosen to force a match.

Use the exact source-dual map template from WPC transport.py WITHOUT
importing its top-level historical worker. Raw fields=T*phase_field*zE,
raw sources=F^t*phase_source*JE,+i per time jet,overall density minus,
all A and jets0. Actual source names come from portable geometry pairs,
not labels guessed from equal integer indices. Derive current F_i by
(-1)^p_i EL_Ji of the transported SOURCE DENSITY. In source-first form
its factor is -(-1)^p_i phase_source_i F_i,raw. Do not use a naive vector
transport with an unproved current bracket orientation.

Keep all source coordinates when identifying the source action. Verify
ALL643 portable field maps are source-free before using that formula.
Check full frame inverse/grade/ghost blocks for the selected ports; no
nonlinear cotangent/N map is silently assumed. Retain all dropped A0,
higherg and out-of-intrinsic row dispositions. Other553 source operations,
whole GF density,physical potential,matter,fullE2 conjugacy and quantum
finite conversion remain outside this necessary test.

Two routes: native ordered Coeff substitution versus plain Fraction/radical
word multiplication,with full complex/source phases. Store all180 grade/
port comparisons and complete old/current/difference polynomials,not just
a witness. Wrong source-derivative orientation must be tested,report actual
sensitivity; a blind phase/jet case is not a failed physics result.

Possible dispositions: exact necessary match then larger action test;
literal necessary interface mismatch requiring a separately derived chart/
parent correction; missing input or bounded incomplete. NONE is a no-go
for the physical model or a retraction of an owner in its original scope.
Do not substitute FJB's90-port gradient packet as a complete parent owner.

Freeze portable/fullFJB/current sources and receipts before one120s/8GiB
sampled/350MiBfloor,32MiBpacket/8MiBartifact worker. Exact failure/overflow
preserved NOTPASS; a detected interface mismatch is a completed diagnostic,
not a qualified action-conjugacy PASS. No E4/commit/statechange in phaseB.
Combined final validation must separately authenticate bytes and the scientific
disposition. Shared action/maps/software/AI limit independence.
