from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fec2220b140e07281909cb027f86cc68d832e4af'
old=json.loads((O/'preparation_a.json').read_bytes());cap=json.loads((O/'capture_a.json').read_bytes());assert cap['exit_code']==1 and not cap['calculation_completed']and cap['post_run_observations_qualified']and not(O/'result_a.json').exists()
for n,h in old['sha256'].items():assert digest(R/n)==h,n
for n in['CONTINUATION_A2.md','build_authentication_v2.py','compute_authentication_v2.py','execute_authentication_v2.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names=set(old['sha256'])|{q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
prep=dict(base_HEAD='fec2220b140e07281909cb027f86cc68d832e4af',sha256={n:digest(R/n)for n in sorted(names)},initial_worker='FAILED1_BEFORE_REPORT_NOTPASS_PRESERVED',scientific_acceptance='NOT_PERFORMED')
dump(O/'preparation_a_v2.json',prep);dump(C/'preparation_a_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_authentication_v2.py')]);dump(O/'capture_a_v2.json',cap);dump(C/'capture_a_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
