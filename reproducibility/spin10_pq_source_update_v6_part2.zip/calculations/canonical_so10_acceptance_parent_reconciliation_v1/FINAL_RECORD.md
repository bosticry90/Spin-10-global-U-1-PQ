# Combined V846 evidence validation

One360s afterimports,8GiB sampled/350MiB launch floor,64MiB packet and12MiB
per artifact. Root executes; read-only AI reviews do not run duplicate workers.
Freeze this record,proof,result,new validator/controller,copies and all raw
inputs and completed/failed artifacts before execution. No action/map/scheme
change, protected promotion, branch/worktree or external operation.

Authenticate all235 original historical bindings from recorded bases and
original paths. Retain current-policy and historical-policy distinctions.
Authenticate every preparation,source copy,external capture and both failed
exits. Reproduce the deterministic C2 serialization transform without executing
the failed scientific worker. Original failure remains FAILED, never PASS.

Independently reconstruct complete source-dual/field maps and all raw row
dispositions using actual F/T/geometry/Wick data. Rebuild the full GF/source
parent in expanded Fraction/radical arithmetic without importing C2's builder,
transport,Euler or homogeneous-current functions. Compare both route operands,
all stored differences and1286 Euler columns per case, four explicit divergence
currents and homogeneous Euler normals. Recompute reversed-source controls
including their nonzero functional images. Recheck all180 necessary interfaces
from the reconstructed source action with the fixed Hamiltonian orientation.

Review the W1-W7 scope and exact three older result ceilings. This is source
and applicability analysis, not mathematical replay of those old calculations,
and not a current bare-heat/T_kappa equivalence proof. Bind the new explanation
of the evanescent-lift gap and preserve all unmeasured quantum inputs.

Check current navigation/link targets, unchanged state, old tree and historical
README suffix. The README/campaign guide are live navigation updates; old
preparations retain their original Git bytes rather than being rebound.
E4 fixedcontext once: outer0/components0,0,0,0,0,2, exactly7 custodyNOTPASS.
All full captures/overflow preserved. Local commit only after validation.
