from pathlib import Path
from fractions import Fraction as Fr
from functools import lru_cache
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/acceptance-parent-reconciliation-v1-2026-11-08')
def module(name,q):
 sp=importlib.util.spec_from_file_location(name,q);out=importlib.util.module_from_spec(sp);sp.loader.exec_module(out);return out
b=module('APR_full_density_map_helpers',O/'compute_interface.py');J=b.J;p=b.p;a=b.a;raw=b.raw;read=b.read;load=b.load;digest=b.digest
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 from hashlib import sha256
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>12*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def rawD(P,mu):
 out={}
 for(w,k),v in P.items():
  for at,(n,js)in enumerate(w):raw.put(out,w[:at]+((n,tuple(sorted(js+(mu,)))),)+w[at+1:],k,v)
 return{k:v for k,v in out.items()if v}
def raw_eulers(P):
 out={}
 for(w,k),v in P.items():
  for at,(n,js)in enumerate(w):
   sign=(-1)**(J.parity(n)*sum(J.parity(i)for i,jj in w[:at]))
   q={(w[:at]+w[at+1:],k):v*sign}
   for mu in js:q={key:-val for key,val in rawD(q,mu).items()}
   target=out.setdefault(n,{})
   for key,val in q.items():target[key]=target.get(key,Fr(0))+val
 return{n:{k:v for k,v in q.items()if v}for n,q in out.items()if any(q.values())}
def div(curr):
 out={}
 for mu,q in enumerate(curr):J.add(out,J.D(q,mu))
 return J.clean(out)
def normal(P):
 out={};cur=[{}for mu in range(4)]
 for w,c in P.items():
  if not w:J.put(out,w,c);continue
  factor=J.times(c,J.constant(Fr(1,len(w))))
  for at,(n,js)in enumerate(w):
   sg=(-1)**(J.parity(n)*sum(J.parity(i)for i,jj in w[:at]))
   rest={w[:at]+w[at+1:]:factor*sg}
   while js:
    mu=js[-1];js=js[:-1]
    J.add(cur[mu],J.mul(p.atom(n,js),rest))
    rest=a.neg(J.D(rest,mu))
   J.add(out,J.mul(p.atom(n),rest))
 N=J.clean(out);cur=[J.clean(q)for q in cur]
 assert a.plus(P,a.neg(N))==div(cur),'FULL_EULER_CURRENT_RECONSTRUCTION'
 return N,cur
def analyze(P):
 E=J.euler(P,set(range(1286)));peer=raw_eulers(raw.flat(J.encode(P)))
 assert{n:raw.flat(J.encode(q))for n,q in E.items()}==peer,'ALL1286_NATIVE_FRACTION_EULERS_DIFFER'
 N,curr=normal(P);constant=bool(P.get((),a.zero))
 assert bool(N)==(bool(E)or constant),'EULER_NORMAL_CLASSIFICATION'
 return dict(complete_difference=J.encode(P),complete_homogeneous_Euler_normal=J.encode(N),four_complete_IBP_currents=[J.encode(q)for q in curr],all1286_field_source_Eulers=[[n,J.encode(E.get(n,{}))]for n in range(1286)],nonzero_Euler_ports=sorted(E),constant_mismatch=constant,functionals_equal=not N and not E and not constant)
def build(role):
 old=load(R/'tools/portable_dh_v1/inputs.json.gz');frame=load(B/'canonical_so10_full_jet_source_master_bridge'/('primary_inputs.json.gz'if role=='native'else'replay_inputs.json.gz'))['frame'];names=frame['field_order'];Tr=defaultdict(list);Fc=defaultdict(list)
 for i,j,s in frame['physical_to_raw_inverse']['entries']:Tr[names[i]].append((j,b.co(s)))
 for i,j,s in frame['physical_to_raw_kernel']['entries']:Fc[j].append((i,b.co(s)))
 maps={};dims={};geo=old['geometry'];gn=geo['names'];rawidx={name:i for i,name in enumerate(names)};Jof={}
 for name,terms in Tr.items():
  maps[name]=[(i,J.times(v,J.phase(i)))for i,v in terms];ds={J.dimension(i)for i,v in terms};assert len(ds)==1;dims[name]=next(iter(ds))
 for f,j,h,k in geo['field_source_h_k']:
  name=gn[f];source=gn[j];assert name in rawidx;Jof[name]=source;maps[source]=[(643+i,J.times(v,J.phase(643+i)))for i,v in Fc[rawidx[name]]];dims[source]=3-dims[name]
 assert len(Jof)==643
 @lru_cache(None)
 def token(name,js):
  phase=[a.one,J.I,-a.one,-J.I][js.count(0)%4]
  return{((i,js),):J.times(v,phase)for i,v in maps[name]}
 def transport(rows):
  out={};journal=[]
  for at,row in enumerate(rows):
   word=[b.split(t)for t in row['word']];status='RETAINED';value=b.co(row['coefficient']);value=J.Coeff([(k,v)for k,v in value.terms if k[0]<=1])
   if any(n.startswith('A')and n not in maps for n,js in word):status='A0_EXCLUDED'
   elif any(n not in maps for n,js in word):raise AssertionError(('UNMAPPED_COMPLETE_PARENT_TOKEN',word))
   elif 4-sum(dims[n]+len(js)for n,js in word)not in[0,1]:status='OUTSIDE_INTRINSIC01'
   elif not value:status='HIGHER_G_EXCLUDED'
   journal.append([at,status])
   if status!='RETAINED':continue
   if role=='native':
    term={():-value}
    for n,js in word:term=J.mul(term,token(n,js))
   else:
    term=raw.flat(J.encode({():-value}))
    for n,js in word:term=b.rm(term,raw.flat(J.encode(token(n,js))))
    term=b.unflat(term)
   J.add(out,term)
  return J.clean(out),journal
 GF,gfj=transport(old['gauge_fixing_density']);source={};sourcej=[]
 for name,rows in old['master_field_maps'].items():
  withsource=[dict(word=[Jof[name]]+row['word'],coefficient=row['coefficient'])for row in rows]
  rr,journal=transport(withsource);J.add(source,rr);sourcej.append([name,journal])
 source=J.clean(source);S=a.plus(GF,source);results=[];densityrefs=[]
 folder=B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1';S0=J.decode(load(folder/(role+'_route_density.json.gz'))['original_GF']);S1=J.decode(load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'))['S1']);assert a.grade(S0,0)==S0 and a.grade(S1,1)==S1
 for g,current in[(0,S0),(1,S1)]:
  oldslice=a.grade(S,g);delta=a.plus(oldslice,a.neg(current));comparison=analyze(delta)
  # Deliberately reverse the source action while retaining the entire GF.
  wrong=a.plus(a.grade(GF,g),a.neg(a.grade(source,g)),a.neg(current));control=analyze(wrong)
  artifact=dict(g=g,complete_transported_portable_parent=J.encode(oldslice),complete_current_GF_source_parent=J.encode(current),comparison=comparison,wrong_source_dual_orientation_control=control,physical_sourcefree_cubic_NOT_added=True)
  ref=save(role+'_complete_parent_g'+str(g)+'.json.gz',artifact)
  results.append(dict(g=g,old_words=len(oldslice),current_words=len(current),density_difference_words=len(delta),nonzero_Euler_ports=len(comparison['nonzero_Euler_ports']),functionals_equal=comparison['functionals_equal'],wrong_source_control_sensitive=not control['functionals_equal'],artifact=ref))
  densityrefs.append(J.encode(oldslice));print('STAGE '+role+' g'+str(g)+' fullparent='+str(comparison['functionals_equal'])+' density_difference='+str(len(delta)),flush=True)
 ref=save(role+'_complete_raw_row_dispositions.json.gz',dict(all_GF_input_rows=len(old['gauge_fixing_density']),all_GF_row_dispositions=gfj,all643_source_field_row_dispositions=sourcej,actual_maps=[[n,[[i,A.encode_coeff(v)]for i,v in rr]]for n,rr in sorted(maps.items())],complete_GF=J.encode(GF),complete_source_action=J.encode(source),no_source_or_field_Euler_restriction=True))
 return results,densityrefs,ref
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation_c.json')['sha256'].items():assert digest(R/n)==h,n
 cases=[];parents=[]
 for role in['native','replay']:
  rows,old,ref=build(role);cases.append(dict(role=role,cases=rows,row_journal_artifact=ref));parents.append(old)
 assert parents[0]==parents[1],'COMPLETE_OLD_PARENT_NATIVE_FRACTION_TRANSPORT_DIFFERENCE'
 passed=all(row['functionals_equal']for z in cases for row in z['cases'])
 out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='COMPLETE_GF_SOURCE_PARENT_SLICE_MATCHES_MOD_EXPLICIT_DIVERGENCE'if passed else'COMPLETE_GF_SOURCE_PARENT_SLICE_MISMATCH_PRESERVED',roles=cases,all4_full1286_Euler_and_Fraction_comparisons=True,old_complete_parent_transports_equal=True,all_current_parent_functionals_match=passed,higher_g_physical_potential_matter_background_and_Tkappa_conversion_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_c.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
