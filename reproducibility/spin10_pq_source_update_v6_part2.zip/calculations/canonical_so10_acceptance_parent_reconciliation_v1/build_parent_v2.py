from pathlib import Path
import ast
O=Path(__file__).resolve().parent
def write(name,s):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'compute_parent.py').read_text(encoding='utf-8')
assert s.count('A.encode_coeff(v)')==1
s=s.replace('A.encode_coeff(v)','[[list(k),q.numerator,q.denominator]for k,q in v.terms]')
s=s.replace("role+'_complete", "role+'_v2_complete")
s=s.replace("'preparation_c.json'","'preparation_c_v2.json'").replace("'result_c.json'","'result_c_v2.json'")
ast.parse(s);write('compute_parent_v2.py',s)
s=(O/'execute_parent.py').read_text(encoding='utf-8')
s=s.replace("['PHASE_C_RECORD.md','compute_parent.py','execute_parent.py']","['CONTINUATION_C2.md','build_parent_v2.py','compute_parent_v2.py','execute_parent_v2.py']")
s=s.replace("'preparation_c.json'","'preparation_c_v2.json'").replace("'capture_c.json'","'capture_c_v2.json'").replace("O/'compute_parent.py'","O/'compute_parent_v2.py'")
ast.parse(s);write('execute_parent_v2.py',s)
