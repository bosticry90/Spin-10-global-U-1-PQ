# Late comparison and analytic review, prospective

Native/replay each completed the full2970-position source/tangent/regulator
construction without old target or peer access; complete packets have the
same SHA. A literal exterior covariance fixture passed with unequal heats,
nonzero external-mean contacts and sensitive wrong-sign/third-edge/subtraction
controls. This review may now parse the qualified MWL/WPC comparison kernels.

Check all slots, QI source jets and all source/field-zero complements; explicitly
check D's field shift, all own-field Jacobian derivatives and the q0 regulator
quadratic cancellation before accepting the structural reduced census. Compare
regulator colors to the preexisting complete three-group proper kernel only
after construction. Keep the whole source correction's formal nonlocal factor
paired until its exact subtraction. Compare both ordered groups separately.

Prove scalar heat masters by Schwinger integration and independent numerical
integrals at nonzero generic p²; use symbolic UV expansion. Record finite11/36
only if derived. Keep the exact finite-IR defect between the auxiliary-profile
inverse and physical fixed regulator, with an explicit uniform Gaussian bound.
Store full wrong coefficient arrays and zero complements. Review180s,8GiB
sampled,350MiB floor,whole packet16MiB. No scientific target weakened.

This verifies one selected modified identity, not simultaneous restoration.
No finite normalization is adopted. The next smallest test is a common local
unmarked/marked kinetic preimage, with full source/field consequences retained.
