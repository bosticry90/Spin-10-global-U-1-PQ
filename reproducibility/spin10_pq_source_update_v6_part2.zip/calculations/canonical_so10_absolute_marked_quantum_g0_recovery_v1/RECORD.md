# Absolute marked g0 one-loop identity: prospective recovery V1

Previous goal turn PROGRESS: D:-first storage verified. Read the director's
goal-objective.md in full, recovered clean f3ed2521/main, V781, current policy,
state113/34of39 and no matching workers. Full investigation remains active.
This is reconstruction from surviving operands, not adoption of the lost
October31 frontier. No agents, branch/worktree, protected activation or push.

1. Question: does the absolute marked one-loop Slavnov/source equation hold
in the lowest gauge coefficient, and is its finite response zero or nonzero?
2. Claim: calculate D Gamma1-Q I_D1 at firstu,g10^0,epsilon_s/C_c, s12..44,
c0..44,both probes (2970 positions), and derive its regulator/whole-product
side independently. Keep canonical C_c epsilon_s order; epsilon-left has the
opposite coefficient. D is even including epsilon; Q is odd; rho is odd.
The marked action is S+uQG+rho KD. No new canonical pair or normalization.
3. Ceiling: one-loop proper, original unshifted Euclidean A0, intrinsic01,
first constant-u, Schwartz external epsilon/C directions. Not full restoration,
admissible all-order QAP/measure/equivalence, E5/A5 or physical viability.
4. Inputs: exact primary/replay full GF/source action, QG and operations;
canonical KD/D and their new bare-insertion recovery; qualified MWL ghost
two-point kernel and WPC primitive data. Bind all source maps before restriction.
Physical/matter port exclusions inherit their qualified g0 support, not a
free-Gaussian replacement of the interacting Lambda-a-C sector.
5. Comparators: W1-W7 source-left functional specification; MWL three-group
kernel/IR proof; WPC canonical/primitive proof. Published algebraic restoration
methods distinguish modified identities from actual restoration (Grassi et al.,
hep-ph/0102005). Source-dependent quantum replacement remains conditional
(Anselmi1205.3862). Neither literature nor a chat formula supplies model evidence.
6. Native: derive the actual probe field tangent from full QG, primitive ghost
matrix from KD and ghost background matrices from actual action. Form the
regulator color by open-index tangent/marked-ghost contraction, before any old
kernel is parsed. Keep ghost and mixed-boson ordered contributions separately.
7. Review: independent replay action/Eulers, primitive relation from GF rather
than native KD extraction, separately ordered color joins and Schur inverse.
Compare full outputs. A literal finite Berezin/Wick covariance fixture tests
ghost signs, the third inverse edge and external-mean subtraction. Shared
action/chart/ring/software/AI author remain; no outside scientist or proof kernel.
8. Falsifiers: omitted third inverse edge, wrong external epsilon/ghost sign,
source maps omitted before differentiation, replaced unequal heat lengths,
missing whole-product mean subtraction. Store complete wrong coefficients and
honest blind cases. A mismatch is failure, not a target-fitting opportunity.
9. Known-limit obligations: QI_D1 includes B/Ja proper jets, Q1I_D0, all D-source
routes, tadpoles and Jacobian. Measure their absence/zeros from support and traces;
never infer them from the bare master divergence. Heat E_q=exp(-t q²) throughout;
WPC's alternate heat-time convention is not silently substituted. Use a common
UV power subtraction, then the inherited free-edge IR proof family. Retain
physical-fixed-regulator inverse/source defects at finite IR smoothing.
10. Bounds: serial native/replay180s each after imports, fixture60s, final180s,
8GiB sampled private,350MiB available-commit launch floor,complete16MiB packet.
Output/captures under D:; freeze sources/input hashes before workers. Exhaustion
is incomplete; never truncate, silently expand or overwrite failed evidence.
11. Stop this bounded coefficient at verified modified identity, obstruction or
explicit incomplete. A nonzero finite local term does not imply an anomaly.
Continue with the smallest common-normalization compatibility test; do not
restart nine M amplitudes or automatically expand gauge order.
12. Evidence: full source/tangent/primitive/trace/color tables, two route captures,
finite exterior-algebra fixture and all wrong expressions, ordered heat proof,
late comparison to qualified kernels, review receipt, E4 once/no fresh using
the verified D: context and complete capture. Protected state/old mode-blobs and
raw new bytes checked before local commit; custody exit2/seven NOTPASS retained.

Analytic target frozen before computation: write action ghost backgrounds M_r,
primitive ghost root L_s, and actual left antighost derivative T_r,ic of Q1 a_r.
The regulator color is R_sc=sum_(r,i) L_s[r,i] T_r[i,c], not an imported Q.
The source-paired covariance has two ordered groups. At the ghost root their
weights are (I0-I1); the mixed Z-Lambda return has weight -(I1-I3).
I3 keeps two heats on the bosonic/adjacent node, hence a third inverse edge.
Check these signs/weights by literal covariance before qualifying the result.
The external C-mean times <Z> term cancels only against its whole-product
subtraction; keep both formal terms before cancellation, not standalone inverse
heat maps on Schwartz functions. If source/tangent support does not justify
this exhaustive reduced inventory, stop the complete-identity claim.
