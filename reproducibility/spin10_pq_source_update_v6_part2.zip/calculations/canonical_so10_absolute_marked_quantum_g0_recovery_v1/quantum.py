"""Actual source/tangent and marked regulator colors, before target access."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict, Counter
import gzip, importlib.util, json, os, sys, threading, time

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_original_Ja_ghost_bubble'))
import algebra as A
J=A.J
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
enc=A.encode_coeff;em=A.encode_matrix


def scale(P,c):return J.clean({w:J.times(v,c) for w,v in P.items()})
def plus(*ps):
    out={}
    for p in ps:J.add(out,p)
    return J.clean(out)
def zero(P):return J.clean({w:J.Coeff([(k,v) for k,v in c.terms if k[0]==0]) for w,c in P.items()})
def mat_scale(M,c):return {ij:J.times(v,c) for ij,v in M.items() if J.times(v,c)}
def trace(M):return sum((v for (i,j),v in M.items() if i==j),J.ZERO)
def pair(M,N):return sum((J.times(v,N.get((j,i),J.ZERO)) for (i,j),v in M.items()),J.ZERO)
def mass(P):
    out={}
    for w,c in P.items():
        if len(w)!=2 or any(js for n,js in w):continue
        if not (553<=w[0][0]<598 and 598<=w[1][0]<643):continue
        out[w[1][0]-598,w[0][0]-553]=-c
    return out
def component_rows(rows):
    out={}
    for row in rows:
        if row['g']!=0:continue
        word=[]
        for token in row['word']:
            name,*jet=token.split('__');idx=NAMES.index(name)
            word.append((idx,tuple(map(int,jet[0])) if jet else ()))
        c=J.Coeff([((0,x,e,m),F(n,d)) for x,e,m,n,d in row['coefficient_cells']])
        # Canonical component rows already use the qualified word ordering.
        J.put(out,tuple(word),c)
    return J.clean(out)


def build(route):
    role='primary' if route=='native' else 'replay'
    fj=load(R/('calculations/canonical_so10_full_jet_source_master_bridge/'+role+'_tables.json.gz'))
    action=load(R/'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')
    S=zero(J.decode(action[0 if route=='native' else 1]['original'][0]['density']))
    q0={n:zero(J.decode(p)) for n,p in fj['operation']}
    gf={n:zero(J.decode(p)) for n,p in fj['GF_gradient']}
    # Independent source plane/Hessian reconstruction in the replay route.
    grad=gf if route=='native' else J.euler(S,set(range(508,643)))
    ML={r:{} for r in range(45)}
    for r in range(45):ML[r]=mass(grad.get(508+r,{}))
    L={}
    for s in range(12,45):
        if route=='native':L[s]=mass(component_rows(CT['components'][str(1286+s-12)]))
        else:L[s]=mat_scale(ML[s],-J.I)
    assert all(not trace(m) for m in ML.values()),'ORIGINAL_AUXILIARY_TADPOLE_NOT_ZERO'
    # Complete original field maps at g0, including zero complements.
    for n in range(643):
        expected={}
        if n<180:expected={((553+n//4,(n%4,)),):J.constant(1)}
        elif 598<=n<643:expected={((508+n-598,()),):J.I}
        assert q0.get(n,{})==expected,('UNEXPECTED_G0_FIELD_MAP',n)
    # Original JB sources are field-affine; JLambda/JC are absent. This is
    # checked on all sourceful S words, not inferred from a selected Hessian.
    for w,c in S.items():
        for n,js in w:
            if 643<=n<823:assert len(w)==2 and sum(i<643 for i,j in w)==1
            assert not 1151<=n<1241,('UNEXPECTED_JL_OR_JC_SOURCE',n)
    # At zero fields, qJa has precisely box C as its linear term.
    for r in range(45):
        linear={w:c for w,c in q0.get(1241+r,{}).items() if len(w)==1}
        assert linear=={((553+r,(mu,mu)),):J.constant(1) for mu in range(4)}
    allcases=[];probe_data=[]
    for pr in [0,1]:
        U=zero(J.decode(fj['probes'][pr]['qG']))
        # All source Euler derivatives precede restrictions.
        usrc=J.euler(U,set(range(643,1286)))
        q1={n:scale(usrc.get(643+n,{}),J.constant((-1)**J.parity(n))) for n in range(643)}
        assert all(not p for n,p in q1.items() if not 598<=n<643),'PROBE_HAS_OTHER_FIELD_FLOW'
        assert all(not any(643<=n<1241 for n,js in w) for w in U),'UNEXPECTED_PROBE_SOURCE_PORT'
        N={r:mass(usrc.get(1241+r,{})) for r in range(45)}
        Y={r:{} for r in range(45)};UL={r:{} for r in range(45)}
        for w,c in U.items():
            if len(w)!=3:continue
            ghosts=[(n,js) for n,js in w if 553<=n<643]
            other=[(n,js) for n,js in w if not 553<=n<643]
            if len(ghosts)!=2 or len(other)!=1:continue
            assert ghosts[0][0]<598 and ghosts[1][0]>=598 and all(not js for n,js in ghosts)
            ij=ghosts[1][0]-598,ghosts[0][0]-553
            n,js=other[0]
            if n<180:
                assert js==(n%4,)
                if n%4==0:Y[n//4][ij]=-c
                else:assert Y[n//4].get(ij)==-c,('UNMATCHED_VECTOR_DIVERGENCE',n,ij)
            elif 508<=n<553 and not js:UL[n-508][ij]=-c
            elif 1241<=n<1286:pass
            else:raise AssertionError(('UNACCOUNTED_CUBIC_PORT',n,js))
        T={};forces={};bosons={}
        for r in range(45):
            hit=r<12 if pr==0 else r>=12
            wgt=J.Coeff([((0,0,1,0) if r<12 else (0,1,0,0),F(1))])
            expected={}
            if hit:
                for mu in range(4):expected[((4*r+mu,(mu,)),)]=J.constant(-2)
                expected[((508+r,()),)]=J.times(J.I,wgt)
                expected[((1241+r,()),)]=J.constant(2)
                for (i,c),value in ML[r].items():
                    J.put(expected,((553+c,()),(598+i,())),J.times(-2*J.I,value))
            assert q1[598+r]==J.clean(expected),('Q1a_NOT_ACTUAL_COMPLETED_Z',pr,r)
            # Native tangent from literal left differentiation; replay from
            # the independently reconstructed Z coefficient after equality.
            if route=='native':
                dg=J.euler(q1[598+r],set(range(598,643)))
                M={}
                for aa,p in dg.items():
                    for word,value in p.items():
                        assert len(word)==1 and 553<=word[0][0]<598 and not word[0][1]
                        M[aa-598,word[0][0]-553]=value
                T[r]=M
            else:T[r]=mat_scale(ML[r],2*J.I) if hit else {}
            bosons[r]=dict(y=-2 if hit else 0,Lambda=enc(J.times(J.I,wgt)) if hit else [],
                           Z_to_Lambda_without_heat=enc(2*J.I if hit else J.ZERO))
            assert N[r]==mat_scale(ML[r],-2*J.I) if hit else not N[r]
            assert Y[r]==mat_scale(ML[r],2*J.I) if hit else not Y[r]
        for r in range(45):
            assert not trace(N[r]) and not trace(Y[r]),('PROBE_ONE_POINT_NOT_ZERO',pr,r)
        # Source counterpart is retained in full and cancels as an operator.
        qI={};reg={};TN={};TY={};external={}
        for s in range(12,45):
            for c in range(45):
                TN[s,c]=pair(L[s],N[c]);TY[s,c]=pair(L[s],Y[c])
                qI[s,c]=TN[s,c]+TY[s,c]
                if route=='native':
                    value=J.ZERO
                    for r in range(45):
                        for (i,cc),t in T[r].items():
                            if cc==c:value+=J.times(L[s].get((r,i),J.ZERO),t)
                else:
                    value=sum((J.times(l,T[r].get((i,c),J.ZERO))
                               for r in range(45) for (rr,i),l in L[s].items() if rr==r),J.ZERO)
                reg[s,c]=value
                hit=c<12 if pr==0 else c>=12
                external[s,c]=J.times(2*J.I,pair(ML[c],L[s])) if hit else J.ZERO
                assert not qI[s,c],('NONZERO_MARKED_PROPER_SOURCE_IMAGE',pr,s,c)
                allcases.append(dict(probe=pr,epsilon=s,C=c,
                    regulator_ghost=enc(value),regulator_even=enc(-value),
                    proper_I_Ja=enc(TN[s,c]),proper_I_divB=enc(TY[s,c]),
                    QI_p2_coefficient=enc(qI[s,c]),external_mean_contact=enc(external[s,c]),
                    external_whole_product_subtraction=enc(-external[s,c])))
        probe_data.append(dict(probe=pr,actual_q1a=[[r,J.encode(q1[598+r])] for r in range(45)],
                               N=[[r,em(N[r])] for r in range(45)],Y=[[r,em(Y[r])] for r in range(45)],
                               ULambda=[[r,em(UL[r])] for r in range(45)],tangent=[[r,em(T[r])] for r in range(45)],
                               boson_gradient=bosons,all45_tadpole_traces_zero=True))
        print('STAGE '+route+' complete source/tangent and independent regulator colors probe '+str(pr),flush=True)
    # D's surviving source routes: enumerate, do not impose source-free D.
    d0={int(n):[row for row in rows if row['g']==0] for n,rows in CT['D'].items()}
    Dsource={n:p for n,p in d0.items() if 643<=n<1286 and p}
    kinds=Counter()
    for n,rows in Dsource.items():
        for row in rows:
            kind='JB_affine_source_Hessian_zero' if n<823 else 'JL_absent_from_action' if 1151<=n<1196 else 'JC_contains_zero_antighost_mean' if 1196<=n<1241 else 'Ja_times_zero_one_point_trace' if 1241<=n<1286 else 'UNACCOUNTED'
            assert kind!='UNACCOUNTED',('UNACCOUNTED_D_SOURCE',n)
            if kind=='JC_contains_zero_antighost_mean':assert any(name.startswith(('a_','ub','bar')) for name in row['word']),row
            kinds[kind]+=1
    return dict(ML=[[r,em(ML[r])] for r in range(45)],L=[[r,em(L[r])] for r in range(12,45)],
                probes=probe_data,cases=allcases,D_source_routes=Dsource,D_source_dispositions=dict(kinds),
                Q1_I_unprobed_zero_by_q1Lambda_and_affine_other_source_support=True,
                field_jacobian_own_field_trace_zero=True)


def main():
    assert __debug__
    route=sys.argv[1];assert route in ['native','replay']
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
    prep=read(O/'preparation.json')
    for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
    assert digest(Path(__file__))==prep['source_sha256']['quantum.py']
    global CT,NAMES
    CT=load(R/'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');NAMES=CT['geometry']['names']
    denied={str((R/n).resolve()) for n in prep['late_comparison_only']}
    peer=O/(('replay' if route=='native' else 'native')+'_tables.json.gz')
    def guard(event,args):
        if event=='open' and args and isinstance(args[0],(str,bytes)):
            p=str(Path(os.fsdecode(args[0])).resolve())
            if p in denied or p==str(peer):raise PermissionError('MARKED_NATIVE_TARGET_OR_PEER_READ_DENIED')
    sys.addaudithook(guard)
    data=build(route)
    blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    assert len(blob)<=16*1024**2,'INCOMPLETE_PACKET_LIMIT'
    with (O/(route+'_tables.json.gz')).open('xb') as f:f.write(blob)
    out=dict(schema='ABSOLUTE_MARKED_G0_SOURCE_AND_REGULATOR_COLORS_V1',route=route,positions=len(data['cases']),
             regulator_nonzero_positions=sum(bool(z['regulator_ghost']) for z in data['cases']),
             proper_source_image_zero_positions=sum(not z['QI_p2_coefficient'] for z in data['cases']),
             external_mean_correction_nonzero_positions=sum(bool(z['external_mean_contact']) for z in data['cases']),
             D_source_dispositions=data['D_source_dispositions'],old_target_and_peer_not_read=True,
             table_bytes=len(blob),table_sha256=sha256(blob).hexdigest(),elapsed_after_imports=time.perf_counter()-tick,
             scientific_acceptance='NOT_PERFORMED',full_restoration_or_E5_claim=False)
    with (O/(route+'_result.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,sort_keys=True);f.write('\n')
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()


if __name__=='__main__':main()
