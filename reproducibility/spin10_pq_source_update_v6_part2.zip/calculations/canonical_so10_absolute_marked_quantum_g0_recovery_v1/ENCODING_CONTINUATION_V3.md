# Review output encoding correction V3

V2 completed all mathematical checks in1.018575s, but its wrapper read the
original UTF-8 source using Windows' default cp1252 text decoding. Unicode
superscripts in descriptive output labels were consequently double encoded.
Numeric coefficient cells, exact algebra, controls and comparison verdicts
were unaffected. Preserve completed V2 source/capture/results/tables intact;
do not present malformed labels as final scientific serialization.

V3 derives its source from the original review.py BYTES decoded explicitly as
UTF-8, applies the same expanded-zero correction and writes distinct V3
result/table paths. No other scientific change. Bind a new preparation and
capture before execution;180s/8GiB/350MiB limits unchanged. Compare the entire
V2/V3 complete_color_table exactly afterward, keeping metadata correction
separate from mathematical verification. No target or failed run is erased.
