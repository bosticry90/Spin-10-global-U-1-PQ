"""Literal exterior Gaussian covariance with the whole-product subtraction."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json, time
import sympy as s

O=Path(__file__).resolve().parent
tick=time.perf_counter()
prep=json.loads((O/'fixture_preparation.json').read_bytes())
assert sha256(Path(__file__).read_bytes()).hexdigest()==prep['source_sha256']


def add(*ps):
 out={}
 for p in ps:
  for k,v in p.items():out[k]=out.get(k,F(0))+v
 return {k:v for k,v in out.items() if v}
def scale(p,c):return {k:v*c for k,v in p.items() if v*c}
def mul(p,q):
 out={}
 for (a,l,z),v in p.items():
  for (b,ll,zz),w in q.items():
   if a&b:continue
   parity=sum((b&((1<<i)-1)).bit_count() for i in range(11) if a&(1<<i))
   k=(a|b,l+ll,z+zz);out[k]=out.get(k,F(0))+(-1)**parity*v*w
 return {k:v for k,v in out.items() if v}
def word(ids,c=F(1),ell=0,zeta=0):
 p={(0,ell,zeta):F(c)}
 for i in ids:p=mul(p,{(1<<i,0,0):F(1)})
 return p
def exp(p):
 out={(0,0,0):F(1)};power=out
 for n in range(1,12):
  power=scale(mul(power,p),F(-1,n));out=add(out,power)
  if not power:break
 assert not power,'EXTERIOR_EXPANSION_NOT_COMPLETE'
 return out
def integrate(p):
 out={}
 for (mask,l,z),v in p.items():
  if mask&255!=255:continue
  out[mask^255,l,z]=out.get((mask^255,l,z),F(0))+v
 return out
def coefficient(p):
 # Ghost integral first. Only E[zeta Lambda]=b and the empty moment survive.
 out=F(0)
 for (mask,l,z),v in integrate(p).items():
  if mask!=1792:continue
  moment=F(1) if (l,z)==(0,0) else b if (l,z)==(1,1) else F(0)
  out+=v*moment
 return out/z0
def encode(p):return [[list(k),v.numerator,v.denominator] for k,v in sorted(p.items())]


L=[[2,-1],[4,1]];M=[[1,2],[-1,3]];v=[2,-1]
b=F(2,5);KR=F(6,5);Kext=F(14,5)
Mv=[sum(M[i][j]*v[j] for j in range(2)) for i in range(2)]
free={}
for i in range(4):free=add(free,word([4+i,i],2 if i<2 else 3))
Zfree=exp(free);z0=integrate(Zfree)[0,0,0]
theta={};mixed={}
for i in range(2):
 for j in range(2):theta=add(theta,word([8,9,4+i,2+j],L[i][j]))
 mixed=add(mixed,word([6+i,10],Mv[i],ell=1))
full=exp(add(free,theta,mixed))
quadratic={};linear={}
for i in range(2):
 linear=add(linear,word([6+i,10],Mv[i]))
 for j in range(2):quadratic=add(quadratic,word([6+i,j],M[i][j]))
result=[]
for r in range(2):
 internalC=word([r],KR);externalC=word([10],Kext*v[r])
 ghost=coefficient(mul(mul(linear,internalC),full))
 even=coefficient(mul(mul(word([],zeta=1),internalC),full))
 contact=coefficient(mul(mul(quadratic,externalC),full))
 subtraction=contact
 actual=ghost+even+contact-subtraction
 colour=sum(L[r][i]*Mv[i] for i in range(2))
 resolvent=-KR*F(1,2)*F(1,3)*colour*(1-b)
 assert ghost==-KR*F(1,6)*colour and even==b*KR*F(1,6)*colour
 assert actual==resolvent and actual and contact
 wrong=dict(omit_mixed_route=ghost,reverse_ghost_sign=-ghost+even,
            omit_whole_product_subtraction=actual+contact,
            collapse_mixed_heat_to_one=ghost+even/b)
 assert all(z!=actual for z in wrong.values())
 result.append(dict(root=r,ghost=str(ghost),mixed=str(even),contact=str(contact),subtraction=str(-subtraction),
                    covariance=str(actual),resolvent=str(resolvent),wrong={k:str(z) for k,z in wrong.items()},
                    differences={k:str(z-actual) for k,z in wrong.items()}))
omega,E=s.symbols('Omega E');H=s.Matrix([[0,s.I],[s.I,omega]])
inv=H.inv();Z=s.Matrix([[s.I,omega/2]])
assert H*inv==inv*H==s.eye(2)
assert s.simplify((Z*(E*inv))[0,1]-E)==0
assert s.simplify((Z*(E*inv))[0,0]-s.I*E*omega/2)==0
assert time.perf_counter()-tick<60
out=dict(schema='MARKED_REGULATOR_LITERAL_COVARIANCE_FIXTURE_V1',rows=result,
         literal_exterior_integrand=encode(full),ghost_normalization=str(z0),
         literal_ghost_and_boson_Wick_vs_resolvent=True,extra_heat_Schur_identity=True,
         not_a_physical_model_point=True,elapsed_after_imports=time.perf_counter()-tick,
         scientific_acceptance='NOT_PERFORMED')
with (O/'fixture_result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,sort_keys=True);f.write('\n')
print('RESULT '+json.dumps({k:out[k] for k in ['schema','rows','extra_heat_Schur_identity','elapsed_after_imports']},sort_keys=True))
