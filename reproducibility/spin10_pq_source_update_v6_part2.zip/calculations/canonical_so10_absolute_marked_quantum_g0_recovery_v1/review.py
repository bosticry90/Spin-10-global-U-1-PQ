from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,sys,threading,time
import sympy as s
import mpmath as mp

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('marked_quantum_tools',O/'quantum.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
J=w.J;A=w.A
read=w.read;load=w.load;digest=w.digest


def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(O/'review_preparation.json')
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for n,h in read(O/'preparation.json')['input_sha256'].items():assert digest(R/n)==h,n
 raw=(O/'native_tables.json.gz').read_bytes();assert raw==(O/'replay_tables.json.gz').read_bytes()
 d=json.loads(gzip.decompress(raw));assert len(d['cases'])==2970
 ct=load(R/'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz')
 dfield={int(n):[r for r in rows if r['g']==0] for n,rows in ct['D'].items() if int(n)<643}
 dfield={n:rows for n,rows in dfield.items() if rows}
 assert set(dfield)==set(range(610,643))
 for n,rows in dfield.items():
  assert len(rows)==1 and rows[0]['word']==['epsilon_'+str(n-598)] and rows[0]['coefficient_cells']==[[0,0,0,1,1]]
 for pr in d['probes']:
  for r,rows in pr['actual_q1a']:
   own=J.euler(J.decode(rows),{598+r})
   assert not own,('NONZERO_FIELD_JACOBIAN',pr['probe'],r)
 # Actual q0 field maps have been compared against the full643-column
 # linear map. Its reference variation is -i Lambda p² C+i Lambda p² C,
 # while the physical vector part is transverse. Verify all four components.
 pp=s.symbols('p0:4');p2=sum(x*x for x in pp);P=p2*s.eye(4)-s.Matrix(pp)*s.Matrix([pp])
 assert P*s.Matrix(pp)==s.zeros(4,1)
 assert s.expand(-s.I*p2+s.I*p2)==0
 wpc=load(R/'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz')
 oldT={(r['probe'],r['epsilon'],r['Ja']):r['proper_Gamma_tensor'] for r in wpc['complete_color_table']}
 mwl=load(R/'calculations/canonical_so10_mixed_Ward_low_coupling/kernel_tables.json.gz')[0]
 kernels={r['probe']:{key:A.decode_matrix(r[key]) for key in ['Q','X','Y','Z']} for r in mwl['probes']}
 def oldcoef(cells):return J.Coeff([((0,x,e,m),F(n,den)) for x,e,m,n,den in cells])
 rows=[];controls={k:0 for k in ['reverse_regulator_phase','collapse_third_heat','omit_I_Ja','omit_I_divB','omit_whole_product_subtraction']}
 for z in d['cases']:
  pr,ss,c=z['probe'],z['epsilon'],z['C'];q=A.decode_coeff(z['regulator_ghost']);ev=A.decode_coeff(z['regulator_even']);K=kernels[pr]
  assert q==K['Q'].get((ss,c),J.ZERO)
  assert -2*q==K['X'].get((ss,c),J.ZERO) and not K['Y'].get((ss,c),J.ZERO) and q==K['Z'].get((ss,c),J.ZERO)
  assert ev==-q
  tn=A.decode_coeff(z['proper_I_Ja']);ty=A.decode_coeff(z['proper_I_divB'])
  assert not tn+ty and tn==oldcoef(oldT[pr,ss,c])
  ext=A.decode_coeff(z['external_mean_contact']);sub=A.decode_coeff(z['external_whole_product_subtraction']);assert not ext+sub
  # Fixed canonical C epsilon order. Epsilon-left is the opposite sign.
  good={'I0':q,'I1':-2*q,'I3':q,'finite_p2':J.times(q,J.constant(F(11,36)))}
  wrong={
   'reverse_regulator_phase':{'I0':-q,'I1':2*q,'I3':-q,'finite_p2':-good['finite_p2']},
   'collapse_third_heat':{'I0':q,'I1':-q,'I3':J.ZERO,'finite_p2':J.times(q,J.constant(F(3,8)))},
   'omit_I_Ja':{'uncanceled_QI_bubble_p2':ty},
   'omit_I_divB':{'uncanceled_QI_bubble_p2':tn},
   'omit_whole_product_subtraction':{'external_hEp_p2_Pi':ext}}
  for k,v in wrong.items():controls[k]+=int(any(v.values()))
  rows.append(dict(probe=pr,epsilon=ss,C=c,modified_identity={k:A.encode_coeff(v) for k,v in good.items()},
                   wrong={k:{kk:A.encode_coeff(vv) for kk,vv in v.items()} for k,v in wrong.items()}))
 assert all(v==57 for v in controls.values())
 # General Schwinger evaluation of int exp[-at r²-bt(p-r)²]/r².
 t,z,pp2=s.symbols('t z p2',positive=True)
 I0=1/t;I1=(s.exp(-z/2)-s.exp(-z))/(t*z);I3=(s.exp(-2*z/3)-s.exp(-2*z))/(4*t*z)
 expansion=s.series((I0-2*I1+I3).subs(z,t*pp2),t,0,2)
 assert s.simplify(s.limit(t*(I0-2*I1+I3).subs(z,t*pp2),t,0)-s.Rational(1,3))==0
 assert s.simplify(s.limit(((I0-2*I1+I3).subs(z,t*pp2)-1/(3*t)),t,0)-11*pp2/36)==0
 mp.mp.dps=40;errors=[]
 for zz in [mp.mpf('0.125'),mp.mpf('0.7'),mp.mpf('3'),mp.mpf('9')]:
  for aa,bb in [(1,1),(1,2)]:
   # Schwinger s>=0, t=1: numerical route does not use the closed formula.
   integral=mp.quad(lambda x:mp.exp(-(aa+x)*bb*zz/(aa+bb+x))/(aa+bb+x)**2,[0,1,mp.inf])
   closed=(mp.exp(-mp.mpf(aa*bb)*zz/(aa+bb))-mp.exp(-bb*zz))/(bb*bb*zz)
   error=abs(integral-closed);assert error<mp.mpf('1e-32');errors.append(str(error))
 f0,f1,E0,E1=s.symbols('f0 f1 E0 E1')
 F0=f0*E0;F1=f1*E1
 proper=F1*(1-F0)**2
 fixed=F1*F0*(1/E0-1)*(1-F0)
 defect=s.factor(proper-fixed)
 assert s.simplify(defect-F1*(1-F0)*(1-f0))==0
 fixture=read(O/'fixture_result.json')
 assert fixture['literal_ghost_and_boson_Wick_vs_resolvent'] and fixture['extra_heat_Schur_identity']
 assert len(fixture['rows'])==2 and all(F(r['covariance'])==F(r['resolvent']) and F(r['contact']) for r in fixture['rows'])
 packet=dict(complete_color_table=rows,heat=dict(I0=str(I0),I1=str(I1),I3=str(I3),UV_expansion=str(expansion),
             profile_fixed_regulator_defect_numerator=str(defect),all_masters_normalized_by='1/(16*pi²)',
             profile_error_bound='C delta² uniformly in t,p by Gaussian Schwinger majorant; UV-FP then IR'),
             fixture_result_sha256=digest(O/'fixture_result.json'))
 blob=gzip.compress((json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'identity_tables.json.gz').open('xb') as f:f.write(blob)
 out=dict(schema='ABSOLUTE_MARKED_G0_MODIFIED_QUANTUM_IDENTITY_REVIEW_V1',evidence_validation='PASS_SELECTED_ABSOLUTE_MARKED_ONE_LOOP_IDENTITY',
          all_color_positions=2970,nonzero_positions=57,proper_QI_selected_image_zero=True,
          inherited_ghost_kernel_and_new_regulator_equal=True,nonzero_finite_response='11*Q*p²/(36*16*pi²) in canonical C epsilon order',
          ghost_and_mixed_groups_preserved=True,whole_source_mean_subtraction_retained=True,
          controls_sensitive_positions=controls,actual_Q0_reference_regulator_variation_zero=True,
          actual_Q1_field_jacobian_zero=True,all_D_source_routes_accounted=True,
          Schwinger_numeric_errors=errors,profile_fixed_regulator_defect_kept=True,
          identity_table_sha256=sha256(blob).hexdigest(),identity_table_bytes=len(blob),
          scientific_acceptance='NOT_PERFORMED',full_restoration_or_E5_claim=False,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'review_result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,sort_keys=True);f.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()


if __name__=='__main__':main()
