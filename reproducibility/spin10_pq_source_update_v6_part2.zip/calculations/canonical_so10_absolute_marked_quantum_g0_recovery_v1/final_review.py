from pathlib import Path
from hashlib import sha256
import gzip,json,os,subprocess,sys,threading,time

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/absolute-marked-quantum-g0-recovery-v1-2026-11-06')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 fp=read(O/'final_preparation.json')
 for n,h in fp['source_sha256'].items():assert digest(O/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 kp=read(O/'kinetic_preparation.json')
 for n,h in kp['additional_input_sha256'].items():assert digest(R/n)==h,n
 for p in O.glob('*.source.txt'):
  assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 assert (O/'native_tables.json.gz').read_bytes()==(O/'replay_tables.json.gz').read_bytes()
 native=load(O/'native_tables.json.gz');assert len(native['cases'])==2970
 assert sum(bool(z['regulator_ghost']) for z in native['cases'])==57
 assert sum(bool(z['external_mean_contact']) for z in native['cases'])==57
 assert all(not z['QI_p2_coefficient'] for z in native['cases'])
 identity=load(O/'identity_tables_v3.json.gz')
 assert identity['complete_color_table']==load(O/'identity_tables.json.gz')['complete_color_table']
 assert len(identity['complete_color_table'])==2970
 review=read(O/'review_result_v3.json')
 assert review['evidence_validation']=='PASS_SELECTED_ABSOLUTE_MARKED_ONE_LOOP_IDENTITY'
 assert review['nonzero_positions']==57 and all(n==57 for n in review['controls_sensitive_positions'].values())
 assert review['profile_fixed_regulator_defect_kept']
 assert digest(O/'identity_tables_v3.json.gz')==review['identity_table_sha256']
 kinetic=read(O/'kinetic_result.json');kt=load(O/'kinetic_tables.json.gz')
 assert kinetic['all2970_selected_positions_checked'] and kinetic['finite_baseline_not_chosen']
 assert digest(O/'kinetic_tables.json.gz')==kinetic['table_sha256']
 assert all(not z['full_Q_action_residual'] and z['action_native']==z['action_closed'] for z in kt['cases'])
 assert sum(len(z['complete_selected_coefficients']) for z in kt['cases'])==2970
 assert all(z['coefficient_real'] and z['matrix_symmetric'] and all(not v for v in z['all12_bilinear_covariance_residuals']) for z in kt['H_covariance'])
 failure=read(O/'review_capture.json');assert failure['exit_code']!=0 and not failure['calculation_completed']
 assert 'assert P*s.Matrix(pp)==s.zeros(4,1)' in failure['stdout_and_stderr']
 assert read(O/'encoding_comparison_v3.json')['complete_color_tables_identical']
 resources={}
 for stem,resultname,limit in [('native','native_result.json',180),('replay','replay_result.json',180),
                                ('fixture','fixture_result.json',60),('review_v3','review_result_v3.json',180),('kinetic','kinetic_result.json',180)]:
  capname='review_capture_v3.json' if stem=='review_v3' else stem+'_capture.json'
  cap=read(O/capname);result=read(O/resultname)
  assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
  assert cap['all_resource_samples'] and all(0<q['private_bytes']<=8*1024**3 for q in cap['all_resource_samples'])
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2
  assert result['elapsed_after_imports']<=limit
  resources[stem]=dict(seconds_after_imports=result['elapsed_after_imports'],largest_private_sample=max(q['private_bytes'] for q in cap['all_resource_samples']),sampled_not_true_peak=True)
 print('STAGE complete science/source/failed-attempt/resource checks',flush=True)
 command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4']
 et=time.perf_counter();p=subprocess.run(command,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=180)
 capture=dict(command=command,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED')
 dump(O/'e4_capture.json',capture);dump(C/'e4_capture.json',capture)
 assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()]
 exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]
 assert events[-1]['execution_state']=='COMPLETED'
 custody=next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')
 assert custody['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 print('STAGE E4 expected exits on D context; seven custody NOTPASS',flush=True)
 before=(C/'old_git_tree.txt').read_bytes();assert before==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
 subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V782.md']
 total=sum(p.stat().st_size for p in files);assert total<=16*1024**2
 goal=Path('C:/Users/psboy/.codex/attachments/7a32ce84-5784-4694-89da-1cc31d513c54/goal-objective.md')
 out=dict(schema='ABSOLUTE_MARKED_QUANTUM_G0_RECOVERY_VALIDATION_V1',execution_state='COMPLETED',
          evidence_validation='PASS_SELECTED_MODIFIED_IDENTITY_AND_KINETIC_BASELINE_LAW',scientific_acceptance='NOT_PERFORMED',
          base_HEAD=prep['base_HEAD'],goal_reference_sha256=digest(goal),state_sha256=state,
          quantum_positions=2970,nonzero_positions=57,reference_finite_response='11*Q*p2/(36*16*pi2)',
          proper_source_image_zero=True,independent_regulator_match=True,third_edge_and_whole_source_subtraction_retained=True,
          common_kinetic_law='H-T=11Q/36; connected baseline shift H-T',finite_baseline_adopted=False,
          higher_source_and_full_mixing_restoration='OPEN',E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',
          native_target_access='Declared bytes hashed; old targets/peer prohibited during scientific construction',
          failed_review='V1_STRUCTURAL_ZERO_COMPARISON_FAILED_PRESERVED',completed_V2='MATH_VALID_TEXT_ENCODING_DEFECT_PRESERVED',
          final_review='V3_EXPLICIT_UTF8_EXACT_COLOR_CELLS_UNCHANGED',resources=resources,
          old_mode_blob_entries_preserved=len(before.splitlines()),old_tracked_files='GIT_DIFF_UNCHANGED; PREPARED_INPUT_HASHES_MATCH',
          new_files_excluding_pending_final_capture_and_receipt={p.relative_to(R).as_posix():digest(p) for p in files},
          packet_bytes_excluding_pending_final_capture_and_receipt=total,final_review_seconds=time.perf_counter()-tick,
          full_restoration_QAP_E5_physical_viability_claim=False)
 dump(O/'validation_receipt.json',out)
 print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True)
 timer.cancel()


if __name__=='__main__':main()
