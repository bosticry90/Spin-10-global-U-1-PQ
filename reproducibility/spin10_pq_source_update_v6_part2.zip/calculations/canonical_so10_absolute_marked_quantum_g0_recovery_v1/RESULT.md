# Selected absolute quantum identity reconstructed; normalization is coupled

The absolute marked first-u,g10^0 one-loop Slavnov/source identity passes all
2970 coefficient positions. The source/regulator side was constructed before
access to the old proper quantum kernel; two routes agree byte-for-byte.
There are57 nonzero responses, all in the broken probe.

In canonical C epsilon order,

    D Gamma1-Q I_D1=Q(I0-2I1+I3),
    reference finite part=11Qp²/(36*16pi²).

Both ordered regulator contributions, third inverse edge and nonzero external
source-mean correction are retained. A literal Berezin/Wick fixture and separate
Schwinger/Schur checks validate their signs, weights and finite coefficient.
The finite-IR fixed-regulator defect is explicit and bounded, not erased.

The next common kinetic test finds local polynomial preimages with action/
primitive coefficients H,T satisfying H-T=(11/36)Q. Their connected source
baseline shifts by the same matrix. The homogeneous H=T completion cannot
cancel this inhomogeneous response within that family. No baseline is chosen;
other primitive/source mixings and higher-field compatibility remain open.

[Full proof and scope](PROOF.md), [correctly encoded quantum review](review_result_v3.json),
[complete identity table](identity_tables_v3.json.gz), [kinetic law](kinetic_result.json).
The initial symbolic-equality failure and V2 encoding defect are preserved
explicitly; V3's exact color coefficients are unchanged. Final validation is
owned by validation_receipt.json, including one E4 authentication using D:.

This recovers a selected missing quantum prerequisite. It does not qualify
full restoration, E5/A5, the lost M-sector amplitudes or physical viability.
State113/34of39 and custody exit2/seven NOTPASS remain unchanged. The next
smallest scientific action is the higher-source g0 compatibility calculation
for the same common normalization. Scientific acceptance NOT_PERFORMED.
