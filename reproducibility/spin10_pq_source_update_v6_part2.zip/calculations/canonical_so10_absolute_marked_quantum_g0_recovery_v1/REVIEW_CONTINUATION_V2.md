# Exact symbolic comparison correction V2

Original review.py FAILED at its reference transverse-matrix assertion before
old target/color comparison. SymPy retains factored entries in (p²I-pp^T)p;
structural equality to the zero matrix does not expand them. The required
mathematical condition is unchanged: every exact polynomial entry must vanish.
V2 explicitly expands each matrix entry before comparison. No tolerance,
special momentum, parameter change or omitted component is introduced.

Preserve review.py/source copy, review_preparation.json and full FAILED
review_capture.json unchanged. Native/replay colors and the literal fixture
remain completed but not yet finally qualified. Freeze review_v2.py and a new
review_preparation_v2.json before the new serial review. The new worker keeps
all original comparisons, formulas, scientific input bindings and180s/8GiB/
350MiB limits; it writes the previously absent review result and identity
tables only on complete success. The old review is not relabeled PASS.
