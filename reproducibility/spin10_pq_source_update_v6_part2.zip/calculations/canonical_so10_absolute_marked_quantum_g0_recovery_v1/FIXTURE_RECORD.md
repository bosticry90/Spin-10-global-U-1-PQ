# Literal covariance fixture, prospective before execution

Use four ghost pairs, two unequal free inverse factors K0=2,K1=3, separate
rho/epsilon/chi odd generators and formal even Lambda,zeta. Set the Wick
covariance <zeta Lambda>=b=2/5, <Lambda Lambda>=0. Pick noncommuting real
matrices L=[[2,-1],[4,1]], M=[[1,2],[-1,3]], external C-vector(2,-1).
These are mathematical sign/normalization controls, not a physical parameter
point. E0=b=2/5, E1=3/7, q0²=4/5, q1²=9/7 give G0=1/2,G1=1/3.
The root regulator is q0²(E0^-1-1)=6/5; external-root diagnostic14/5.

Literal action is a0 K0 C0+a1 K1 C1+rho epsilon a0 L C1
plus Lambda a1 M chi*v. Integrate the four ghost pairs by complete exterior
expansion of exp(-S), then apply centered bosonic Wick moments. No determinant
or trace is used in the literal route. Compute <Z Kreg C>-<Z>Kreg<C>, with
Z=zeta+a1 M(chi*v+C0). Keep the nonzero external-mean term and its subtraction
separately. For the rho/epsilon/chi coefficient, the ghost route is
-KR*G0*G1*(L M v)_r and the mixed route+b times that magnitude. Their sum
is -(1-b)*KR*G0*G1*(L M v)_r. Conversion from epsilon-left after rho to
canonical C epsilon reverses this sign; actual2i probe factor is separate.

Distinct check: direct finite-matrix resolvent/Berezin contraction and the
Schur inverse H0=[[0,i],[i,Omega]], Z=(i,Omega/2),
Z E H0^-1 eLambda=E, with Omega symbolic. This establishes the extra E
factor rather than collapsing the third inverse edge. A missing mean
subtraction, wrong ghost sign or dropped mixed route must change the full
nonzero fixture; save exact differences.60s after imports,8GiB sampled,
350MiB launch floor,1MiB complete output. No old target input.
