"""Serial immutable launches, with full D:-resident control captures."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/absolute-marked-quantum-g0-recovery-v1-2026-11-06')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,sort_keys=True);f.write('\n')
route=sys.argv[1];assert route in ['native','replay']
assert not (O/(route+'_capture.json')).exists(),'NO_OVERWRITE'
if not (O/'preparation.json').exists():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='f3ed25213ad0e91b2f21dc66c00b0136340986ee'
    names=['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V781.md',
           'docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/LOCAL_STORAGE_LAYOUT_V1.md',
           'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz',
           'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz',
           'calculations/canonical_so10_full_jet_source_master_bridge/jets.py',
           'calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
           'calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py',
           'calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz',
           'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz',
           'calculations/canonical_so10_Ward_primitive_canonical/quantum_tables.json.gz',
           'calculations/canonical_so10_Ward_primitive_canonical/final_review_validation_receipt.json',
           'calculations/canonical_so10_mixed_Ward_low_coupling/kernel_tables.json.gz',
           'calculations/canonical_so10_mixed_Ward_low_coupling/final_review_validation_receipt.json',
           'calculations/canonical_so10_mixed_Ward_low_coupling/KERNEL_DERIVATION.md',
           'calculations/canonical_so10_mixed_Ward_low_coupling/EXTENSION_PROOF.md',
           'calculations/canonical_so10_absolute_marked_g0_recovery_v1/inventory_tables.json.gz',
           'calculations/canonical_so10_marked_descendant_recovery_v1/validation_receipt.json',
           'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']
    for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
    for folder in ['canonical_so10_Ward_primitive_canonical','canonical_so10_mixed_Ward_low_coupling']:
        d=json.loads((R/'calculations'/folder/'final_review_validation_receipt.json').read_bytes())
        for n,h in d['new_files_sha256'].items():assert digest(R/n)==h,n
    C.mkdir(parents=True,exist_ok=False)
    with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
    sources=['quantum.py','run.py','RECORD.md']
    for n in sources:
        if n.endswith('.py'):ast.parse((O/n).read_bytes())
        with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
    dump(O/'preparation.json',dict(base_HEAD='f3ed25213ad0e91b2f21dc66c00b0136340986ee',input_sha256={n:digest(R/n) for n in names},
         source_sha256={n:digest(O/n) for n in sources},late_comparison_only=[n for n in names if n.endswith('/kernel_tables.json.gz') or n.endswith('/quantum_tables.json.gz')],
         scientific_acceptance='NOT_PERFORMED'))
cap=capture([sys.executable,'-B',str(O/'quantum.py'),route])
dump(O/(route+'_capture.json'),cap);dump(C/(route+'_capture.json'),cap)
assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'],cap['execution_state']
print(cap['stdout_and_stderr'])
