# Final evidence validation and preservation

Freeze this record and final_review.py before execution. Recheck all prepared
scientific inputs and new source copies, completed native/replay/fixture/V3/
kinetic captures, actual resources and entire identity/kinetic tables. Original
review failure and completed V2 encoding-defect artifacts must remain intact
and excluded from final V3 serialization. Mathematical V2/V3 identity cells
must agree exactly. The native no-target flag means scientific-construction
access, not the preceding declared-byte hash authentication.

Run ONE E4 authentication with explicit verified D: context and no --fresh,
preserving complete stdout/stderr before displaying summaries. Expected steps
0,0,0,0,0,2; custody seven unresolved NOTPASS. Final worker180s after imports,
8GiB sampled private,350MiB launch floor,whole packet16MiB; do not claim nested
E4 continuous/private peaks. Resource exhaustion is incomplete. No second E4
retry is implicitly authorized by this record; routine correction needs a new
prospective continuation if necessary.

Check unchanged old Git mode/blob entries, tracked files and scientific state;
seal all new packet hashes excluding pending final-capture/receipt circularity,
then external stage guard and separate local main commit. No remote action.
This is bounded evidence validation, not director scientific acceptance, a
custody PASS, full normalization/restoration or E5/A5 completion.
