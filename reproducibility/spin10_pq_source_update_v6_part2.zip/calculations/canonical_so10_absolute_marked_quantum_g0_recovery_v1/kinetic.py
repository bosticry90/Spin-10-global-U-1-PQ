from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,threading,time
import sympy as s

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('kinetic_quantum_tools',O/'quantum.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
J=w.J;A=w.A


def odd(P,Q):
 out={};cache={}
 for word,c in P.items():
  prefix=0
  for at,(n,js) in enumerate(word):
   if Q.get(n):
    if (n,js) not in cache:cache[n,js]=J.Ds(Q[n],js)
    for ww,v in cache[n,js].items():J.put(out,word[:at]+ww+word[at+1:],J.times(c,v)*(-1)**prefix)
   prefix+=J.parity(n)
 return J.clean(out)
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=w.read(O/'kinetic_preparation.json')
 for n,h in prep['source_sha256'].items():assert w.digest(O/n)==h,n
 for n,h in prep['additional_input_sha256'].items():assert w.digest(R/n)==h,n
 fj=w.load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz');q0={n:w.zero(J.decode(p)) for n,p in fj['operation']}
 old=w.load(R/'calculations/canonical_so10_mixed_Ward_low_coupling/kernel_tables.json.gz')[0]
 cov=w.load(R/'calculations/canonical_so10_mixed_Ward_finite_normalization/covariance_tables_v2.json.gz')
 Hgen=[A.decode_matrix(z) for z in cov['H']];assert len(Hgen)==12
 elem=lambda n,js=():{((n,js),):J.constant(1)}
 results=[];covariance_checks=[]
 target=w.load(O/'identity_tables_v3.json.gz')['complete_color_table'];target={(z['probe'],z['epsilon'],z['C']):A.decode_coeff(z['modified_identity']['finite_p2']) for z in target}
 for pr in [0,1]:
  Q=A.decode_matrix(old['probes'][pr]['Q']);Fh={};closed={};ghost={};boson={}
  for (a,b),c in Q.items():
   for mu in range(4):
    J.add(Fh,w.scale(J.mul(elem(598+a),elem(4*b+mu,(mu,))),c))
    J.add(boson,w.scale(J.mul(elem(508+a),elem(4*b+mu,(mu,))),J.times(J.I,c)))
    J.add(ghost,w.scale(J.mul(elem(598+a),elem(553+b,(mu,mu))),-c))
  Fh=J.clean(Fh);closed=w.plus(boson,ghost);native=odd(Fh,q0)
  assert native==closed and not odd(native,q0)
  assert not any(n>=643 for word in native for n,js in word)
  assert all(sum(J.dimension(n)+len(js) for n,js in word)==3 and sum(J.parity(n) for n,js in word)%2==1 for word in Fh)
  assert all(sum(J.dimension(n)+len(js) for n,js in word)==4 and sum(J.parity(n) for n,js in word)%2==0 for word in native)
  DA=J.euler(native,set(range(610,643)))
  IT={};QIT={};wrong={}
  for ss in range(12,45):
   p={}
   for (a,b),c in Q.items():
    if a==ss:
     for mu in range(4):J.add(p,w.scale(elem(4*b+mu,(mu,)),c))
   IT[ss]=J.clean(p);QIT[ss]=odd(IT[ss],q0)
   assert not w.plus(DA.get(598+ss,{}),QIT[ss]),('HOMOGENEOUS_DESCENDANT_NOT_ZERO',pr,ss)
  rows=[]
  for ss in range(12,45):
   for cc in range(45):
    # epsilon-left DA=-Q box C; canonical C epsilon reverses it.
    c=Q.get((ss,cc),J.ZERO);particular=J.times(c,J.constant(F(11,36)))
    assert target[pr,ss,cc]==particular
    rows.append(dict(epsilon=ss,C=cc,unit_action_canonical_p2=w.enc(-c),unit_primitive_Q_canonical_p2=w.enc(-c),
                     selected_particular_H_minus_T=w.enc(particular),remaining_selected_response=w.enc(J.ZERO),
                     connected_reference_baseline_shift=w.enc(particular),
                     homogeneous_H_equal_T_leaves=w.enc(particular)))
  covs=[]
  for h in Hgen:
   residual=A.add(A.mul(A.transpose(h),Q),A.mul(Q,h))
   assert not residual,('FAILED_H_TENSOR_COVARIANCE',pr)
   covs.append(A.encode_matrix(residual))
  covariance_checks.append(dict(probe=pr,all12_bilinear_covariance_residuals=covs,
                                coefficient_real=all(not(k[3]&16) for c in Q.values() for k,v in c.terms),
                                matrix_symmetric=Q==A.transpose(Q)))
  wrong_boson=odd(ghost,q0);wrong_ghost=odd(boson,q0)
  if Q:assert wrong_boson and wrong_ghost and wrong_boson!=wrong_ghost
  results.append(dict(probe=pr,Q_matrix=w.em(Q),generator=J.encode(Fh),action_native=J.encode(native),action_closed=J.encode(closed),
                      full_Q_action_residual=J.encode(odd(native,q0)),
                      DA_epsilon_left=[[ss,J.encode(DA.get(598+ss,{}))] for ss in range(12,45)],
                      primitive_IT=[[ss,J.encode(IT[ss])] for ss in range(12,45)],
                      Q_IT_without_epsilon=[[ss,J.encode(QIT[ss])] for ss in range(12,45)],
                      complete_selected_coefficients=rows,wrong_omit_boson=J.encode(wrong_boson),wrong_omit_ghost=J.encode(wrong_ghost)))
 # Each tensor entry shares the same two-block Gaussian formula. H,T are
 # independent normalization coefficients, not numerical physical widths.
 omega,E,h,t,b=s.symbols('Omega E H T b')
 H0=s.Matrix([[0,s.I],[s.I,omega]]);G=E*H0.inv();Hb=s.Matrix([[0,s.I*h],[s.I*h,0]])
 ft=s.Matrix([[1,-s.I*omega/2]]);fjc=s.Matrix([0,-s.I]);fit=s.Matrix([[t,0]])
 inverse_route=-(ft*G*Hb*G*fjc)[0]+(fit*G*fjc)[0]
 direct=(ft*(H0/E+b*Hb).inv()*fjc)[0]+b*(fit*(H0/E+b*Hb).inv()*fjc)[0]
 direct_route=s.diff(direct,b).subs(b,0)
 assert s.simplify(inverse_route-direct_route)==0 and s.simplify(inverse_route-(E**2*h-E*t))==0
 assert s.simplify(inverse_route.subs(E,1)-(h-t))==0
 assert s.simplify(inverse_route.subs(t,h)-h*E*(E-1))==0
 out=dict(schema='SELECTED_COMMON_KINETIC_PREIMAGE_AND_BASELINE_V1',cases=results,H_covariance=covariance_checks,
          Gaussian=dict(resolvent=str(s.expand(inverse_route)),direct_inverse=str(s.expand(direct_route)),reference='H-T',
                        homogeneous='E*(E-1)*H',restoration_law='H-T=(11/36)*Q; ell,hbar,u suppressed'),
          all2970_selected_positions_checked=True,finite_baseline_not_chosen=True,other_primitive_mixings_not_classified=True,
          full_physical_source_reality_not_claimed=True,scientific_acceptance='NOT_PERFORMED',elapsed_after_imports=time.perf_counter()-tick)
 blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 assert len(blob)<16*1024**2
 with (O/'kinetic_tables.json.gz').open('xb') as f:f.write(blob)
 summary={k:out[k] for k in ['schema','Gaussian','all2970_selected_positions_checked','finite_baseline_not_chosen','other_primitive_mixings_not_classified','elapsed_after_imports']}
 summary.update(table_sha256=sha256(blob).hexdigest(),table_bytes=len(blob),H_covariance=covariance_checks,scientific_acceptance='NOT_PERFORMED')
 with (O/'kinetic_result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(summary,f,sort_keys=True);f.write('\n')
 print('RESULT '+json.dumps(summary,sort_keys=True),flush=True);timer.cancel()


if __name__=='__main__':main()
