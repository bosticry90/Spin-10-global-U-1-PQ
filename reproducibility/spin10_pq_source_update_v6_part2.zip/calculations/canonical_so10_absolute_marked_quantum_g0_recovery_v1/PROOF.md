# Absolute marked one-loop equation and its kinetic normalization constraint

## Scope and recovered inputs

At original unshifted Euclidean A0, gauge coefficient zero, intrinsic01 and
first constant u, consider the proper coefficient C_c epsilon_s (s12..44,
c0..44), with both existing probes. rho is an odd constant bookkeeping mark;
epsilon and C directions are independently Schwartz smeared. E_q=exp(-t q²).
Gamma uses the inherited source-left conventions and the actual mixed
vector/auxiliary and ghost reference. No constant-vacuum limit is taken.

The full investigation objective file was read before this calculation.
The missing October30/31 reports supplied a question, not executable inputs.
The qualified surviving MWL proper ghost kernel and WPC chart/primitive are
authenticated/reused; the marked source image and regulator contraction are
new. Native/replay completed in6.241532/6.480776s and their complete packets
are byte-identical, SHA1cd9c0844b9bed1f23d1f3ce05f6c23001b02c6b8aafd5b74405bbbed77b265a.
They authenticated declared input byte hashes, then a read guard prohibited
old-target/peer access during scientific construction. Old target contents
were not parsed as scientific operands; byte authentication is separate.

## Why this reduced calculation covers the selected quantum coefficient

Full source derivatives precede restriction. The actual g0 field maps have
q0 B=partial C, q0 a=i Lambda, q0 Lambda=q0 C=0, with all other643-column
complements checked. All probe field maps except a vanish. On the source
plane the actual map is

    q1 a_r=2i Pi_r Z_r,
    Z_r=i divB_r+Omega_r Lambda_r/2-i Ja_r+a^T M_r C.

This identity is checked against every retained action/source coefficient,
including the nonlinear ghost current. The original action is interacting:
Lambda_r a^T M_r C remains atg0. Its ghost Hessian and the mixed free inverse
are retained. Physical/scalar/matter returns cannot meet the specified g0
ports; their separate self-interactions are not asserted absent or free.

The original linear field operation preserves the entire free quadratic
regulator: its Lambda/C contributions are -i Lambda p²C+i Lambda p²C, and
(p²I-pp^T)p=0 removes the transverse vector part. This is checked as an exact
four-component identity using the actual643 field maps and inherited reference,
not a vanishing selected trace inferred from an expected answer. The marked
field flow is the constant shift Da=epsilon; its fluctuation derivative is0.
Consequently only the first-u probe field variation can contribute the marked
one-loop regulator covariance. A G_u contribution multiplying an identically
zero q0-regulator variation is not an additional independent class.

At one loop the covariance with a linear regulator field is the first
fluctuation derivative of q1 a times the full quadratic inverse at the mean.
Its nonlinear derivative contains one mean C. The only returning inverse
terms at first rho/C are a marked ghost inverse and an original Lambda-a
mixed inverse followed by the marked ghost inverse. This follows from actual
ports and degree counting, not an arbitrary Born cutoff. Higher cumulants of
the quadratic observable with an extra cubic interaction start at hbar².

The full D source routes are retained:132 JB density rows have only an affine
source coupling and zero loop Hessian;33 JLambda rows refer to a source absent
from the g0 action;600 JC rows contain the zero antighost mean;600 Ja rows
multiply separately checked zero one-point traces. The latter are not normalized
away: Tr M_r, Tr N_r and Tr Y_r vanish individually for all45 colors. All probe
own-field Jacobian derivatives vanish. No general continuum/chiral measure
or global Pfaffian phase is established by these bounded checks.

## Proper marked source image

Write O_s=Euler_epsilon_s KD, with actual ghost matrix L_s. Native extracts
L_s from the canonical primitive; replay derives L_s=-i M_s from the GF
relation and independently reconstructed action. Both complete source maps
are kept. At firstu the only proper jets entering Q I_D1 in epsilon/C are
the divB and Ja ghost bubbles. Their coefficient matrices are

    T_Y(s,r)=Tr(L_s Y_r), T_N(s,r)=Tr(L_s N_r),
    Y_r=+2i Pi_r M_r, N_r=-2i Pi_r M_r.

Thus T_Y+T_N=0 before the common ordered bubble is integrated. Each family
has57 nonzero positions; omitting either family changes57 coefficients.
q1 I_D0 vanishes by the actual q1Lambda=0 and original closed-loop support:
I_D0 depends on Lambda; a loop using original external C/a ports would require
the zero free LambdaLambda edge. Source-affine terms are retained separately.
All2970 resulting Q I_D1 coefficients are zero in this projection. This does
not claim the whole marked insertion or its other field projections is zero.

With the D-source and tadpole routes above accounted for, D Gamma1 in this
projection is the surviving qualified Ca kernel, with a replaced by epsilon.
Canonical C epsilon order gives its MWL coefficient Q; epsilon-left reverses
the sign. The bare264-term Q0KD divergence is not used to assign this quantum
answer. Its role is only the separately qualified integrated bare insertion.

## Independently rooted regulator and whole-product calculation

Let T_r,ic be the actual left antighost derivative of q1 a_r, evaluated at a
mean C_c. The independently computed color is

    R_sc=sum_(r,i) L_s[r,i] T_r[i,c].

T is extracted from full source Euler maps in native; replay reconstructs it
from the complete independently checked Z. Every2970 position is then compared
late with the old proper kernel. R=Q exactly, including2913 zeros. This is
not R defined by the required cancellation. At12,12 in the broken probe,
Q=-16 xi². No width or physical coupling is assigned a value.

At fixed means use the WHOLE covariance

    2i Pi_r {<Z_r (Kreg C)_r>-<Z_r>(Kreg Cmean)_r}.

The external-mean term is generally nonzero: its color is
2i Pi_c Tr(M_c L_s), with formal factor p²(E_p^-1-1)Pi_t(p). Its exact
whole-product subtraction has the opposite coefficient. All57 nonzero
positions are preserved before cancellation. Neither inverse-heat term is
promoted to a standalone map on arbitrary Schwartz sources.

The ghost derivative root, with adjacent regulator and inverse combined,
gives R(I0-I1). The mixed even return has

    (i,Omega/2) E H0^-1 eLambda=E,
    H0=[[0,i],[i,Omega]],

and gives -R(I1-I3). The third inverse edge therefore contributes a second
heat at that node. It cannot be collapsed into a two-edge bubble. The complete
selected modified identity is

    D Gamma1-Q I_D1 = Q (I0-2 I1+I3).

This is a proper, finite-heat source identity. It is not the older connected
Ja/j_a Ward coefficient, whose qualified zero has a different projection.

A literal four-pair Berezin expansion with separate rho/epsilon/mean-C odd
markers verifies the covariance signs and external subtraction independently
of trace conventions. Two fixture roots give -3/5,+3/5; their external-mean
contacts are196/15,-98/15 and cancel only with their own subtractions. The
mixed return has an independently checked extra heat2/5. Wrong ghost sign,
omitted mixed route, collapsed heat or omitted mean subtraction each changes
the exact nonzero fixture. These rational values test mathematics, not a
chosen physical parameter point. Symbolic Schur inversion checks Omega without
specializing it. The literal exterior integrand and full wrong values remain.

## Heat masters and common UV/IR domain

Suppress the common1/(16pi²), put z=t p²:

    I0=1/t,
    I1=(exp(-z/2)-exp(-z))/(t z),
    I3=(exp(-2z/3)-exp(-2z))/(4t z).

For general a,b>0, Schwinger integration of
int exp[-at r²-bt(p-r)²]/r² gives
[exp(-ab z/(a+b))-exp(-bz)]/(b²t z). Separate direct Schwinger quadratures
at four nonzero z and both heat pairs agree below1e-32 absolute. Exact symbolic
expansion, rather than fitting quadrature values, gives

    I0-2I1+I3 = 1/(3t)+11p²/36+O(t p⁴).

After the common power subtraction the response is therefore
11 Q p²/(36*16pi²), nonzero at57 positions. There is no logarithmic coefficient
in this selected sum. At fixed loop momentum the double heat difference tends
to0; that pointwise fact does not determine the integral or its finite part.

The inherited free-edge proof family has F_q=f_delta(q)E_q,
f_delta=(1-exp(-q²/delta²))². The auxiliary inverse with its own regulator
gives F_r(1-F_(p-r))²/r². Keeping the physical fixed regulator instead leaves
the explicit inverse/source defect. In the node assignment used in the review,

    auxiliary-fixed = F1 (1-F0)(1-f0)/r1².

It is not set to0 at finite delta. Since0<=F,f<=1 and
1-f0<=2exp(-r0²/delta²), the Gaussian Schwinger estimate
sup_p int exp(-r²/delta²)/|p-r|² <= pi²delta² bounds this defect uniformly
in t,p. The other free-edge differences satisfy the same MWL majorant.
Thus the same UV power subtraction is retained, and the UV-FP-then-IR
reference exists for this coefficient. No finite-delta physical identity,
unsubtracted interchange, independent p=0 restriction or arbitrary product
extension is claimed. The local p² reference is a tempered distribution.

## What the first common kinetic test establishes

The next calculation keeps both a common action and a marked primitive:

    F_H=u a^T H divB,
    A_H=Q0 F_H=u(i Lambda^T H divB-a^T H box C),
    I_T=u sum_s epsilon_s (T divB)_s.

The full exact density calculation and separate closed reconstruction agree;
Q0 A_H=0. The candidate uses no BV-source omission: its source derivatives are
actually zero, while its field operations are the full sourceful Q0 ones.
For the measured Q direction the matrix is symmetric, real in coefficient
cells and bilinearly invariant under all12 qualified H generators. This
supports a covariant extension using the existing Y=D_H.(B-A_H) construction;
full background/source-reality/product admissibility is not inferred.

In canonical C epsilon order, DA_H-QI_T=-(H-T)p². Thus the selected finite
restoration equation has polynomial preimages with

    H-T=(11/36)Q

after suppressing ell=1/(16pi²),hbar andu. This is a compatibility law, not
an adopted finite baseline or unique renormalization prescription.

The same parent changes the connected theta/Ja tree contact. Full Gaussian
inverse differentiation and a direct Schur inverse independently give

    delta W0_theta,Ja = E²H-E T,    reference shift=H-T.

Consequently this family's selected restoring preimage carries a finite
connected-baseline shift(11/36)Q. The homogeneous/full-DK choice H=T has
zero reference contact shift but also zero inhomogeneous contribution: it
cannot remove a nonzero absolute response merely by repeating the old
homogeneous transport. This is not an obstruction for every admissible
primitive/counterterm: other source and ghost mixings are unclassified, and
the connected baseline is currently free. It is not legitimate to choose
that baseline0 silently or introduce an isolated contact to repair it.

## Significance, failures and next discriminating action

This reconstructs the missing selected absolute modified quantum identity,
including a nonzero finite response and its independent regulator origin.
It also derives a first common action/marked kinetic preimage and the baseline
cost of using it. It does not establish simultaneous marked/unmarked
restoration, the full finite-mixing class, QAP/measure/equivalence, E5/A5 or a
physically viable Spin(10) × global U(1)PQ construction.

The initial review FAILED on unexpanded symbolic matrix equality. V2 preserves
the exact condition and expands each entry. V2's completed coefficients were
correct, but its wrapper decoded UTF-8 source with cp1252 and malformed text
labels. V3 explicitly decodes UTF-8, preserves all earlier bytes and verifies
the entire V2/V3 color table identical. These are real AI implementation/
verification failures; no failed run is relabeled PASS and no physics changed.
Native/replay/fixture/kinetic workers completed first execution. The final
receipt records resources, all captures, failed-source hashes and E4 onD:.

The strongest remaining inference gap is higher-source compatibility of one
normalization, not another kinetic fit. Next derive the actual higher-field
g0 source/primitive image and its one-loop kernels, preferably through a
finite-polynomial resolvent bound before repeated amplitudes. Determine whether
those constraints preserve or restrict the kinetic preimage/baseline law.
Do not restore the reported nine-M frontier without its missing prerequisites,
or automatically increase gauge order. Shared action/chart/software/AI author
limit independence; no outside scientist, proof-assistant or experiment has
validated these results. Scientific authority and all protected gates remain.
