from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-whole-reference-bridge-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json','PROOF.md'],'canonical_so10_aCC_finite_momentum_operator_g1_v1':['wave_algebra.py','validation_receipt.json','PROOF.md'],'canonical_so10_aCC_hard_finite_heat_g1_v1':['validation_receipt.json','PROOF.md','hard_total_base.json.gz','hard_total_H_antighost.json.gz','hard_total_all_M.json.gz'],'canonical_so10_aCC_nonminimal_resolvent_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_JBCC_companion_g1_recovery_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_aCC_direct_UV_symbol_g1_v1':['UV_BRIDGE_PROOF.md','validation_receipt.json']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V818.md']+['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','support_certificate.py','run_support.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'support_certificate.py')]);dump(O/'support_capture.json',cap);dump(C/'support_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
