# aCC whole-reference bridge: source-support and analytic bounds

Continueb25ff266163dfa5e58ab356de580d2db282b44a2/main,V818,D:repo,current
AGENTS. Preflight clean/no matching live Python,452 declared bytebindings
authenticated only. Previous goal turn PROGRESS:3 direct hardheat symbols,
not physical finite reference. State113/34of39/E5A5open unchanged. Full goal
active. No agents/branch/worktree/adoption/protectedpromotion/push/external
action. Flavorpaused/HB1C5blocked;educationvoluntary/nonblocking.

Question: prove the selected ORIGINAL F=f_delta E UV-first/IR-second joint
Schwartz reference equals the previously measured hard symbols. Needed
obligations are the unmultiplied quadratic Taylor remainder and the WHOLE
IR defect, including exceptional external momenta/source contacts. Reuse
existing source/Euler/Schur/dimension evidence; no new coefficient fitting.
Keep V814 dependentfiniteprediction and assembled remainder DENIED until
own reference result frozen. No different profile/subtraction/benchmark.

Same Euclidean A0,firstg/firstu_M,intrinsic01,all33 internalM/all4B/231fields,
two independent polarized ghost momenta p,r and antighost -p-r, including
same-color copies. Generic source support is checked before choosing mean
colors or dropping mean jets. Full finite-color amplitudes remain separate.

First stage120s afterimports,8GiB sampled private/350MiB launch floor,
64MiB complete packet/10MiB artifact. Freeze actual native/replay source
operators, existing V811/V817/V818 proofs/receipts/current policy. Census
ALL source-free T1 selections with internal quantum field and C<=2,a<=1
means of arbitrary45 colors/jets. Native/replay packets must agree. Check
actual coupling and canonical dimensions. E0 nonreference support must be
Lambda/ghost one-mean only; F1 must have positive mean degree; E1 must have
positive mean degree. Hu zero-mean must equal the actual rankone
2 W(-q)^T W(q) on every M color, W=(-q,xi/2), before any norm bound.
Verify symbolic4D G0 Hu0 G0 exactly; merged block has singularity<=|q|^-2,
including its nonzero LambdaLambda entry. Omitting this merge is NOT allowed.

Exhaust the finite OVER-APPROXIMATION of field-type/mean-mask paths in
 M (G0 N)^a G0 H (G0 N)^b, a,b<=2, totalmask7, same endpointfield,
using all actual generic source types. No numeric color coefficient is
supplied; extra grammar paths may cancel physically, so counts are only
support certificates. Record every typed path. Free-node S has linear
momentum coefficient (1,Sp-Sa,Sr-Sa). Merge ONLY the two adjacent G0 around
Hu0 at the same S by the verified rank identity. Then all remaining node
forms PLUS rootq must be independent, with root added only if not already
a SINGLE node; retain actual repeated nodes otherwise. Check SymPy rank
against exact integer minors and preserve witnesses. All singular powers
<=2 after merge. A failure defeats the proposed bound, not the model.

Controls: unmerged Hu0 duplicate must fail independence; invented nodes
S=0,1,3,7 must expose repeated rootq (no silent set dedup); wrong W/2 factor
must fail the actual Hu0 identity. Complete source selections/paths/results
and capture retained, no truncation. Failure/exhaustion incomplete, no auto
retry or silent resource expansion. Sources/contracts/captures immutable.

If the certificate holds, use it in a separately frozen analytic proof and
bounded verification: independent node variables make products of at most
three K(k)=1+|k|^-2 locally integrable jointly. Rootq either is one node or
is independent of all nodes. This is intended to give IRroot O(delta²) in
joint Schwartz pairings, and fixed-delta UV dominated convergence of all
shift-localized IR defects. Pureheat near-region contributions should be
O(t); far external Taylor order3 remainder with retained1-E root should be
O(sqrt(t)), not the inadequate old estimate for tA. These are obligations
to prove, not accepted assumptions. Include all source weights and poles.

Only after proof/verification may the selected finite reference be qualified.
No common normalization/restoration, sourceproducts/QAP/measure/equivalence,
E5A5/physical viability or goal completion claim. Shared action/ring/SymPy/
AIauthor disclosed, no Lean/empirical/externalreview. Final E4one nofresh,
seven custodyNOTPASS; localcommit separate and only after validation.
