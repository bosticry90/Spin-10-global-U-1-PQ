# Whole selected aCC one-loop reference in joint Schwartz topology

This theorem concerns the original selected massless Euclidean A0, firstg/
firstu_M, intrinsic01, all33 internal M/all4B/231fields. All45 external C/a
colors and independent polarized ghost momenta are covered by the support
bound. It does not assume generic external momentum or distinct ghost colors.
The two-response reduction, absence of other returning sectors/F0/Fu1 roots,
formal Gaussian conventions and V810 proper/current bridge are inherited
qualified assumptions. A full measure/QAP/restoration theorem is not inferred.

Write Phi(p,r) for an arbitrary Schwartz function on R8. The actual product
of three independent Schwartz means is included. All estimates are
coefficientwise in the finite g/u/width/radical ring and finite color space.
Let E_t(k)=exp(-t|k|²), f_delta(k)=(1-exp(-|k|²/delta²))² and F=f_delta E.
The original operator order is UV t->0 at fixed delta>0, then delta->0.
There is no profile replacement, chosen finite subtraction or new benchmark.

## 1. Actual-source geometric certificate

The complete source-free first-variation selection is made before choosing
mean colors or discarding mean jets. All generic source words, grades and
canonical dimensions are checked. E0 nonreference N has only one-mean
Lambda/ghost entries. F1 and Hg=E1 each have positive mean degree. Thus
the closed two-response paths M(G0N)^a G0 H(G0N)^b, a,b<=2, have at most
three free edges at total exterior degree3. The54 typed paths are a complete
OVER-ENVELOPE: forgetting internal color and Lorentz-component constraints
can add zero paths, not remove a contributing path. Counts are not amplitudes.
Generic F1 includes LambdaLambda/aa as well as BB/CC; none was discarded.

For Hu0 at zero mean the actual all33-color native matrix is exactly
2 W(-k)^T W(k), W(k)=(-k_mu,xi/2). Direct symbolic4D multiplication gives

 G0 W(-k)^T = F(k) (xi*k/(2k²),1)^T,
 W(k) G0 = F(k) (-xi*k^T/(2k²),1).

Therefore G0 Hu0 G0 is their twice outer product. Its BB norm is at most
C|k|^-2, B-Lambda norm C|k|^-1, LambdaLambda norm C, times F(k)^2.
This includes the NONZERO LambdaLambda entry2F². The eight typed paths with
this repeated adjacent node are merged before any bound or profile difference.
Treating them as two separate singular factors gives a false divergent bound.

Every other free block has norm at most C K(k), K(k)=1+|k|^-2. The merged
block obeys the same bound. Remaining vertex numerators have polynomial
growth of degree at most4 by the verified canonical dimensions. After the
merge, each reduced term has distinct nodes k=q+alpha p+beta r, with
(alpha,beta) among (0,0),(1,0),(0,1),(1,1),(-1,-1),(0,-1),(-1,0).
Its reduced rational tensor is bounded by

 C(1+|q|+|p|+|r|)^4 product_nodes K(k).

The certificate checks that the nodes together with rootq are linearly
independent as four-vector forms, adding q only if it is already exactly
ONE node. At most3 forms occur. Integer minors and independent rank checks
are saved for every typed path. The invented sequence0,1,3,7 fails because
its two root nodes must not be silently deduplicated. This geometric result
is stronger than just local integrability of separate denominators.

## 2. Joint weighted integrability lemma

For each certified family, use coordinates (q,all nonroot nodes,u), where u
is a complementary external four-vector if needed. The fixed-root map is
invertible, with a finite constant Jacobian and uniformly bounded matrix
coefficients across the finite certificate. For fixed q, Peetre's elementary
triangle inequality bounds a Schwartz weight in(p,r) by a polynomial in q
times an arbitrarily decaying weight in(nonroot nodes,u). Each nonroot
K is locally integrable in its OWN four coordinates: int_(|k|<1)|k|^-2
d4k=pi². At infinity K is bounded. Thus, for any sufficiently large N,

 int_dpdr (1+|q|+|p|+|r|)^4 product K(k) |Phi(p,r)|
       <= C p_N(Phi) (1+|q|)^P K(q),

where p_N(Phi)=sup(1+|p|+|r|)^N |Phi| and P is fixed. If q is not a
node its factor is1<=K(q). All constants are independent of t,delta and
external momenta. This is a joint estimate, including every exceptional
linear combination of external momenta; no restriction/pullback of an
already singular external distribution is used.

On |q|<=2M, M=1+|p|+|r|, split the source weight into two factors. One supplies
arbitrary q decay since M>=|q|/2; the other supplies the above independent-
node integrability. For any chosen L this gives the stronger near estimate

 int_dpdr 1_(|q|<=2M) (1+|q|+|p|+|r|)^4 product K(k)|Phi|
       <= C p_N(Phi) (1+|q|)^(-L) K(q).

For example take internal weight24, reserve48 powers for the near cutoff,
and N=100. The Peetre translation cost and numerator degree4 still leave
more than6 powers of q decay, enough below. Only finitely many maps occur.
The exact map constants/inverses and weighted radial moments are verified
in the analytic packet. These weights are test-function estimates, not
physical extra regulators or cutoffs.

## 3. Pureheat UV through the finite term

Endpoint amputation writes the actual integrand as (1-E_t(q)) J_t(q,p,r).
J is a finite sum of the certified reduced terms, with positive profiled
free edges. On |q|<=2M, 1-E<=t|q|² and the near estimate gives O(t) after
joint source pairing. All translated poles are covered by this estimate.

Let T_j be the exact homogeneous external Taylor integrand of degree j<=2.
Its non-endpoint radial order is -2-j+2h with t-power h>=0, by canonical
dimensions. The common endpoint1-E is independent of external momenta.
Consequently the combined near integrands have order at worst t|q|^-j
at q=0, and polynomial growth elsewhere in the near region. Their joint
near pairings are O(t) as well. This uses the COMBINED profile, not separately
divergent Frullani terms.

In |q|>2M all shifted nodes along the Taylor segment epsilon(p,r),0<=epsilon
<=1, have length comparable to |q|. Every external derivative lowers the
massless rational degree by one. Heat derivatives obey corresponding
|q|^-d bounds after absorbing powers of t|q|² into a positive Gaussian.
The termwise degree of J is -2; this follows by summing the verified field/
vertex canonical dimensions around the closed path. After THREE derivatives,

 |J(q,p,r)-sum_(j<=2)T_j J(q,p,r)|
       <= C M³ |q|^-5 exp(-c t|q|²).

Keep the actual endpoint1-E<=min(t|q|²,1). Four-dimensional radial integration
therefore bounds the unmultiplied far remainder by

 C M³ int_0^infinity min(t rho²,1) rho^-2 d rho
       = 2 C M³ sqrt(t).

The near O(t) and far O(sqrt(t)) estimates prove a remainder tending to zero
in S'(R8). This is the needed finite-term estimate; it is NOT the old bound
for t times the amplitude. Integrated T0 is the known full constant leading
coefficient L/t. Integrated T1 vanishes by four-dimensional rotational parity.
Integrated T2 is independent of t: Gamma moments for positive radial degree
and the combined Frullani moment with sum_n c_n=0. Its three measured color
values are V818's P2. Thus

    A_E(t) - L/t -> P2  in S'(R8).

No unknown coefficient or finite counterterm is assigned. Full-color P2
exists by this argument but its unmeasured coefficients are not supplied.

## 4. The WHOLE original IR defect

After the legitimate repeated-node merge, J is a finite polynomial in node
profiles F(k), of positive powers; no inverse profile remains. Exactly

 (1-F(q))J(F) - (1-E(q))J(E)
   = E(q)(1-f(q))J(F) + (1-E(q))[J(F)-J(E)].

For the second term, telescope the finite profile polynomial. Every summand
contains a factor bounded by2n exp(-|k|²/delta²) for some node k=q+P_S,
and otherwise profiles bounded by1. For FIXED delta, this Gaussian times
the Schwartz source and polynomial numerator gives a Schwartz weight in
(q,p,r): the map(q,p,r)->(k,p,r) has determinant1. Independent-node K products
are locally integrable and tempered. Thus an integrable joint dominator
exists uniformly0<t<=1. The explicit1-E(q) tends to zero, so dominated
convergence kills the entire second term as t->0 at fixed delta. This is
not an interchange of the stipulated limits.

The first term has 1-f(q)<=2exp(-|q|²/delta²). The fixed-root lemma gives
a uniform joint-source dominator, and its UV limit is the WHOLE pureIR kernel

    I_delta=(1-f(q))J(f).

Its source pairing is bounded by

 C p_N(Phi) int d4q exp(-|q|²/delta²)(1+|q|)^P K(q)
       <= C' p_N(Phi) (delta²+delta⁴), 0<delta<=1.

The last estimate follows by radial Gaussian moments/rescaling. Hence
I_delta->0 in the joint Schwartz topology. This excludes an additional
delta-supported source contact as well as a generic-point remainder: the
bound applies to every joint test function. The full profile, not only its
UV part, has therefore been controlled in the original UV-first/IR-second
order. No singular external value was assigned by hand.

Combining sections3/4 proves

    lim_(delta->0) lim_(t->0) [A_(f_delta E_t) - L/t] = P2 in S'(R8).

Through the separately qualified V810 selected proper/current relation,
this supplies the corresponding selected formal proper aCC reference in
the same convention. It does not prove the full quantum action principle.

## 5. Result ceiling and dependencies

The three V818 hard quadratic Fourier polynomials now equal their WHOLE
selected reference limits, conditional on the inherited action, field-support,
Gaussian and proper-current assumptions. Their rational/log values are
unchanged, not fitted. The generic analytic bridge covers all finite external
color polarizations of this family; it does not calculate the remaining
finite-color/same-color coefficients. V814's dependent prediction/remainder
was not read or compared. Shared action, coefficient ring, some helpers,
Python/SymPy and AI authorship remain. This written proof is not Lean/kernel
certification, independent scientist endorsement or empirical validation.

Common marked/unmarked restoration, composite/source products, QAP/measure/
equivalence, full E5/A5 and physical viability remain open. Scientific authority
and project_state are unchanged. Final validation of this bounded theorem
is distinct from director acceptance; seven custody references remainNOTPASS.
