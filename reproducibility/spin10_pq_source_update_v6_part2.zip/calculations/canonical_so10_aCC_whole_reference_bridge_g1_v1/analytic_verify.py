from pathlib import Path
from itertools import combinations
from fractions import Fraction as Fr
import importlib.util,json,os,sys,threading,time
import sympy as sy
sp=importlib.util.spec_from_file_location('whole_reference_certificate_tools',Path(__file__).resolve().with_name('support_certificate.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);O=a.O;R=a.R
def determinant(M):
 x,y,z=M;return x[0]*(y[1]*z[2]-y[2]*z[1])-x[1]*(y[0]*z[2]-y[2]*z[0])+x[2]*(y[0]*z[1]-y[1]*z[0])
def inverse(M):
 det=determinant(M);assert det
 out=[]
 for i in range(3):
  row=[]
  for j in range(3):
   rr=[k for k in range(3)if k!=j];cc=[k for k in range(3)if k!=i];minor=M[rr[0]][cc[0]]*M[rr[1]][cc[1]]-M[rr[0]][cc[1]]*M[rr[1]][cc[0]];row.append(Fr((-1)**(i+j)*minor,det))
  out.append(row)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'analytic_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'DEPENDENT_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 sr=a.read(O/'support_result.json');z=a.load(O/sr['artifact']['file']);assert a.digest(O/sr['artifact']['file'])==sr['artifact']['sha256'];maps={};profiles=set()
 for row in z['all_typed_overenvelope_paths']:
  nodes=[a.ell(S)for S in row['effective_nodes']];assert len(nodes)==len(set(nodes));nonroot=[p for p in nodes if p!=(1,0,0)];base=[(1,0,0)]+nonroot;chosen=None
  for extras in combinations([(0,1,0),(0,0,1)],3-len(base)):
   mat=base+list(extras)
   if determinant(mat):chosen=mat;break
  assert chosen,'NO_FIXED_ROOT_MAP';inv=inverse(chosen);assert all(sum(Fr(chosen[i][k])*inv[k][j]for k in range(3))==int(i==j)for i in range(3)for j in range(3));assert all(sum(inv[i][k]*Fr(chosen[k][j])for k in range(3))==int(i==j)for i in range(3)for j in range(3));key=tuple(tuple(x)for x in chosen);maps[key]=dict(matrix=[list(x)for x in chosen],determinant=determinant(chosen),inverse=[[str(v)for v in rr]for rr in inv],Jacobian_absolute_fourvector=str(Fr(1,abs(determinant(chosen))**4)),maximum_forward_row_norm=max(sum(abs(v)for v in rr)for rr in chosen),maximum_inverse_row_norm=str(max(sum(abs(v)for v in rr)for rr in inv)))
  powers=[]
  for S in row['effective_nodes']:powers.append(2 if any(S==row['all_right_to_left_factors'][hh]['input_subset']for xx,hh,yy in row['Hu0_merges'])else 1)
  assert sum(powers)==len(row['all_raw_free_nodes']);profiles.add(tuple(powers))
 x,y=sy.symbols('x y',real=True);f=x*(2-x);assert sy.expand(1-(1-x)**2-f)==0;assert sy.expand(2*x-f)==x*x
 tele=[]
 for powers in sorted(profiles):
  Fs=sy.symbols('F0:'+str(len(powers)));Es=sy.symbols('E0:'+str(len(powers)));full=sy.prod(v**n for v,n in zip(Fs,powers))-sy.prod(v**n for v,n in zip(Es,powers));parts=[]
  for j,n in enumerate(powers):parts.append(sy.prod(Fs[k]**powers[k]for k in range(j))*(Fs[j]**n-Es[j]**n)*sy.prod(Es[k]**powers[k]for k in range(j+1,len(powers))))
  assert sy.expand(full-sum(parts))==0;tele.append(dict(node_powers=list(powers),exact_difference=str(full),exact_localized_terms=list(map(str,parts)),localization_bound_coefficients=[2*n for n in powers]))
 # Exact radial integrals with d4q=2pi² rho³d rho.
 rho,delta,t=sy.symbols('rho delta t',positive=True);unit=2*sy.pi**2*sy.integrate(rho,(rho,0,1));assert unit==sy.pi**2
 gauss=[]
 for power in range(0,33,2):
  for singular in [0,2]:
   exact=sy.pi**2*delta**(4+power-singular)*sy.gamma(sy.Rational(4+power-singular,2));assert sy.simplify(exact.subs(delta,1)-2*sy.pi**2*sy.integrate(rho**(3+power-singular)*sy.exp(-rho*rho),(rho,0,sy.oo)))==0;gauss.append(dict(polynomial_power=power,singularity=singular,exact=str(exact),delta_power=4+power-singular))
 far=sy.integrate(t,(rho,0,1/sy.sqrt(t)))+sy.integrate(rho**-2,(rho,1/sy.sqrt(t),sy.oo));assert sy.simplify(far-2*sy.sqrt(t))==0
 inadequate=sy.integrate(sy.exp(-t*rho*rho),(rho,0,sy.oo));assert sy.simplify(inadequate-sy.sqrt(sy.pi)/(2*sy.sqrt(t)))==0
 # The profile split is algebraic at each finite regulator, before any limits.
 F0,E0,f0,JF,JE=sy.symbols('Froot Eroot froot JF JE');split=(1-f0*E0)*JF-(1-E0)*JE-E0*(1-f0)*JF-(1-E0)*(JF-JE);assert sy.expand(split)==0
 art=a.save('analytic_bound_tables.json.gz',dict(all_fixed_root_maps=list(maps.values()),all54_paths_mapped=True,all_profile_power_telescoping=tele,actual_f_delta='(1-exp(-s/delta^2))^2',one_minus_f_bound='2 exp(-s/delta^2)',unit_ball_inverse_square_integral=str(unit),Gaussian_K_moments=gauss,third_derivative_far_exact=str(far),old_first_derivative_bound_INSUFFICIENT=str(inadequate),whole_profile_split_residual=str(sy.expand(split)),source_weight_choice=dict(total_N=100,internal_N=24,reserved_near_N=48,numerator_degree_at_most=4,remaining_decay_greater_than6=True),whole_analytic_proof='WHOLE_REFERENCE_PROOF.md',no_new_amplitude_or_dependent_prediction=True))
 out=dict(schema='ACC_WHOLE_REFERENCE_JOINT_SCHWARTZ_BOUND_VERIFICATION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all54_source_paths_have_verified_fixed_root_coordinates=True,distinct_fixed_root_maps=len(maps),all_profile_powers_telescoping_and_IRlocalization=True,whole_rootIR_O_delta2_in_Schwartz=True,pureheat_near_O_t_and_unmultiplied_far_O_sqrt_t=True,exact_ordered_UV_first_IR_second_written_proof=True,all45_external_colors_same_color_polarization_covered_by_bound=True,actual_V818_three_hard_symbols_are_selected_reference_coefficients=True,full_remaining_finite_color_coefficients_not_computed=True,common_restoration_E5_A5_not_claimed=True,prediction_inputs_denied=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);a.dump(O/'analytic_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
