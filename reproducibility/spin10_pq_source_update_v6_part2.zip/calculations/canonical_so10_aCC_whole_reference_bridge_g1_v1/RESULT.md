# Whole selected aCC reference bridge

The V818 hard quadratic symbols now have a written whole-kernel reference
proof in the original UV-first/IR-second joint Schwartz topology, supported
by an exhaustive actual-source geometric certificate and exact analytic
checks. The scope is the selected formal one-loop Euclidean g1/u_M family,
with inherited action/returning-field/Gaussian/proper-current assumptions.
It is not common restoration or a full quantum construction.

The generic source census retains all45 external colors, mean jets and
polarized same-color ghosts before restriction. It verifies source grades,
canonical dimensions and the actual all33-color zero-mean Hu0 rank identity.
The complete typed over-envelope has54 paths;8 require an exact adjacent
G0 Hu0 G0 merge. After that merge, remaining propagator nodes augmented by
rootq are independent. Nine explicit fixed-root coordinate maps suffice.
Without the merge, or after silently deduplicating repeated root nodes,
the required bound would be false. Counts are support evidence, not measured
amplitudes or percentages of completion.

This structure gives joint weighted integrability across every exceptional
external-momentum subspace. The WHOLE pureIR root contribution is O(delta²),
so it vanishes as a distribution and supplies no extra source contact. All
shift-localized profile differences vanish by fixed-delta UV dominated
convergence. The unmultiplied pureheat remainder is O(t) near and O(sqrt(t))
far after quadratic Taylor, retaining1-E. These are the missing finite-term
estimates; the former leading-power bound was insufficient. The proof keeps
the original f_delta=(1-exp(-k²/delta²))² and limit order, with no new finite
counterterm or favorable coefficient choice.

Consequently the three V818 rational/log Fourier polynomials equal their
selected full reference limits. The generic bound covers all finite-color
polarizations, but the remaining finite-color/same-color VALUES are not
computed here. The dependent V814 prediction and assembled consistency
remainder remain unread; no late comparison has yet been performed.

Primary source certificate34.734s/120; analytic checks1.421s/120, after
imports. No failed workers. Complete source selections,54 paths, rank/minor
witnesses,9 map inverses, profile telescoping, Gaussian moments and correct
vs insufficient remainder bounds are saved. Final receipt owns fresh replay,
byte bindings/resource observations and the one E4 audit. The theorem itself
is written mathematical reasoning, not something established merely by
setting Boolean flags or matching hashes. No Lean certification/empirical
test/external scientist review. Shared action, ring, helpers, Python/SymPy
and AI author remain limitations.

The demonstrated AI capability is deriving and testing a joint-source limit
proof from actual operator support, including the repeated-node exception,
instead of converting pointwise or leading-power success into a finite
claim. The result changes the next action: use these now-qualified direct
references as a fixed comparison against the dependent integrability
prediction, then assess whether the generic existence/continuity theorem
and already qualified source-square identities can settle the complete
source-consistency problem without another avoidable coefficient catalog.
Any stronger inference still requires its own dependency and scope audit.

Scientific authority34/39/state113 unchanged. E5/A5, full common restoration,
source/composite products, QAP/measure/equivalence and physical viability
remain open. Seven custody references stayNOTPASS. No branch/worktree,
push/publication/adoption/protected activation or overall goal completion.
