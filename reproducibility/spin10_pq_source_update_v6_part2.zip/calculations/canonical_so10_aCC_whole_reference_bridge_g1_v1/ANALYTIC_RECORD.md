# Whole-limit proof and exact verification contract

Dependent on support_result COMPLETED/54 typed paths/8 necessary Hu0 merges.
No weaker geometric statement may substitute for this actual source result.
The theorem in WHOLE_REFERENCE_PROOF.md is a written analytic proof, not
Lean certification. It remains conditional on the explicitly inherited
selected-action/returning-field/proper-current assumptions. No QAP/measure
or common normalization claim.

Freeze proof/checker/inputs before120s afterimports,8GiB sampled/350MiB
floor/64MiB packet/10MiB artifact. Verify all distinct effective-node families
admit an invertible fixed-root map (q,nonrootnodes,complementaryexternal)
by exact rational inverses, both inverse products, determinant/Jacobian and
finite coefficient constants. Retain repeated root nodes as a failure,
not set-dedup. Verify profile telescoping/localization algebra for every
node-power vector in the typed envelope; all reduced paths have positive
profile powers and no inverse profile. Extra profile multiplicities of Hu0
merge are2 at its node. Verify elementary Gaussian/K moments and exact
third-order far bound int min(t*rho²,1)/rho² d rho=2sqrt(t). Negative
order1 bound must remain t^(-1/2), hence insufficient for a finite reference.

The proof must explicitly supply joint Schwartz estimates: repeated-node
merge FIRST; root-augmented independence; fixed-delta UV dominance for
shift-localized defects; O(delta²) for WHOLE rootIR; O(t) near Taylor/full
kernels and O(sqrt(t)) unmultiplied far remainder. No generic-point argument
or old leading-power shortcut. Bound exact inherited f_delta=(1-exp(-s/
delta²))². Existing full constant UV tensor owns the power subtraction;
no finite counterterm is adopted. Authenticate its receipt/proof and V810
proper/current scope in this new preparation. Own hard finite coefficients
are the V818 values, no dependent finite prediction read or comparison.

Failure/exhaustion preserve complete evidence, NOTPASS/incomplete, no auto
retry. On success, final validation freshly replays support/analytic checks,
audits theorem dependencies and onceE4 nofresh with fixed D context; seven
custody references stayNOTPASS. Only then qualify the selected finite
reference and localcommit. Full finite-color coefficients/samecolor values,
common restoration/E5A5/physical viability/overallgoal remain open.
