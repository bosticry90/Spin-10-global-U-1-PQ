from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Fr
from itertools import combinations,product
import gzip,importlib.util,json,os,sys,threading,time
import sympy as sy
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('whole_bridge_source_tools',O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1/wave_algebra.py');r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r);J=r.J;w=r.w;A=r.A;one=r.one;read=r.read;load=r.load;digest=r.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def group(n):return'B'if n<180 else'Lambda'if n<553 else'C'if n<598 else'a'
def ell(S):return(1,int(bool(S&1))-int(bool(S&4)),int(bool(S&2))-int(bool(S&4)))
def masks(nc,na):return [sum(1<<b for b in cs)|(4 if na else 0)for cs in combinations([0,1],nc)]
def minor_certificate(rows):
 n=len(rows);rank=sy.Matrix(rows).rank();witness=[]
 if n<=3:
  for cols in combinations(range(3),n):
   d=int(sy.Matrix([[row[c]for c in cols]for row in rows]).det())
   if d:witness.append(dict(columns=list(cols),determinant=d))
 assert(rank==n)==bool(witness)
 return rank,witness
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'DEPENDENT_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pk=load(base/'native_inputs.json.gz');assert pk==load(base/'replay_inputs.json.gz');states={k:{n:J.decode(p)for n,p in rows}for k,rows in pk['states'].items()};phys={k:{n:J.decode(p)for n,p in rows}for k,rows in pk['physical'].items()};types={};journals=[];hu={};Z=(0,)*4;totalwords=selected=0
 for label in ['E0','E1','Eu0_1','F1','Fu0_1']:
  found=set();u=int('u0'in label)
  for i,n in enumerate(r.FIELDS):
   P=states[label][n]
   if label=='E0'and n<508:P=w.plus(P,phys['P_E0'].get(n,{}))
   if label=='E1'and n<180:P=w.plus(P,phys['P_E1_gauge'].get(n,{}),phys['P_E1_scalar'].get(n,{}))
   P={ww:c for ww,c in P.items()if all(nn<643 for nn,js in ww)};rows=[];totalwords+=len(P)
   for at,(ww,c)in enumerate(sorted(P.items())):
    choices=[]
    for pos,(nn,js)in enumerate(ww):
     if nn not in r.INDEX:continue
     rest=ww[:pos]+ww[pos+1:]
     if any(not 553<=j<643 for j,jj in rest):continue
     nc=sum(553<=j<598 for j,jj in rest);na=len(rest)-nc
     if nc>2 or na>1:continue
     dj=J.dimension(nn);di=J.dimension(n);order=sum(len(jj)for j,jj in ww);assert(di+dj+nc+na+order==4)if label.startswith('E')else(dj+nc+na+order==di+1),(label,n,nn,'FULL_SOURCE_DIMENSION')
     degree=int(label in['E1','F1']);assert all(k[0]==degree for k,v in c.terms),'COUPLING_GRADE'
     ty=(group(n),group(nn),nc,na);found.add(ty);choices.append([pos,nn,list(js),nc,na,order]);selected+=1
     if label=='Eu0_1'and not rest:
      cc=c
      for mu in js:cc=J.times(cc,J.I)
      ex=tuple(js.count(mu)for mu in range(4));key=i,r.INDEX[nn],ex;hu[key]=hu.get(key,J.ZERO)+cc
    if choices:rows.append([at,choices])
   journals.append(dict(state=label,output=n,source_free_polynomial_sha256=sha256(json.dumps(J.encode(P),sort_keys=True).encode()).hexdigest(),all_selected_original_word_positions=rows))
  types[label]=sorted(found);print('STAGE generic_source_types '+label+' '+json.dumps(types[label]),flush=True)
 Ntypes=[ty for ty in types['E0']if ty[2]+ty[3]];assert Ntypes and all(nc+na==1 and((a=='Lambda'and b in['C','a'])or(b=='Lambda'and a in['C','a']))for a,b,nc,na in Ntypes)
 assert all(nc+na>=1 for a,b,nc,na in types['F1'])and all(nc+na>=1 for a,b,nc,na in types['E1'])
 expected={};xi=J.Coeff([((0,1,0,0),Fr(1))])
 for color in r.IC:
  bs=[r.INDEX[4*color+mu]for mu in range(4)];ll=r.INDEX[508+color]
  for mu,i in enumerate(bs):
   for nu,j in enumerate(bs):ee=list(Z);ee[mu]+=1;ee[nu]+=1;expected[i,j,tuple(ee)]=-one*2
   ee=list(Z);ee[mu]=1;expected[i,ll,tuple(ee)]=xi;expected[ll,i,tuple(ee)]=-xi
  expected[ll,ll,Z]=J.times(J.times(xi,xi),J.constant(Fr(1,2)))
 assert r.clean(hu)==expected,'ACTUAL_FULL_HU0_NOT_RANK_ONE'
 q=sy.Matrix(sy.symbols('q0:4',real=True));s=(q.T*q)[0];om,F=sy.symbols('xi F',real=True);H=(s*sy.eye(4)-q*q.T).row_join(q).col_join((-q.T).row_join(sy.Matrix([[om]])));G=((sy.eye(4)/s+(om-1)*q*q.T/s**2).row_join(-q/s).col_join((q.T/s).row_join(sy.zeros(1,1))))*F;W=(-q.T).row_join(sy.Matrix([[om/2]]));Wp=q.col_join(sy.Matrix([[om/2]]));Hu=2*Wp*W;merged=(G*Hu*G).applyfunc(sy.simplify);lv=q*F*om/(2*s);lv=lv.col_join(sy.Matrix([[F]]));rv=(-q.T*F*om/(2*s)).row_join(sy.Matrix([[F]]));assert(merged-2*lv*rv).applyfunc(sy.simplify)==sy.zeros(5);wrongW=(-q.T).row_join(sy.Matrix([[om]]));assert(2*Wp*wrongW-Hu).applyfunc(sy.simplify)!=sy.zeros(5)
 free=[('B','B',0),('B','Lambda',0),('Lambda','B',0),('C','a',0),('a','C',0)]
 def edges(ty):return[(a,b,m)for a,b,nc,na in ty for m in masks(nc,na)]
 ne=edges(Ntypes);records=[];raw_bad=0;cache={}
 for branch,fl,hl in [('F1_Hu','F1','Eu0_1'),('Fu0_Hg','Fu0_1','E1')]:
  for aa,bb in product(range(3),repeat=2):
   ops=[('M',edges(types[fl]))]+sum(([('G',free),('N',ne)]for j in range(aa)),[])+[('G',free),('H',edges(types[hl]))]+sum(([('G',free),('N',ne)]for j in range(bb)),[])
   for start in ['B','Lambda','C','a']:
    paths=[(start,0,[])]
    for tag,ee in reversed(ops):
     nxt=[]
     for col,S,trace in paths:
      for row,cc,m in ee:
       if cc==col and not S&m:nxt.append((row,S|m,trace+[dict(operator=tag,row=row,column=col,mask=m,input_subset=S,output_subset=S|m)]))
     paths=nxt
    for end,S,trace in paths:
     if end!=start or S!=7:continue
     raw=[(at,t['input_subset'])for at,t in enumerate(trace)if t['operator']=='G'];nodes=list(raw);merge=[]
     for at,t in enumerate(trace):
      if t['operator']=='H'and t['mask']==0:
       assert hl=='Eu0_1'and t['row']in['B','Lambda']and t['column']in['B','Lambda']
       if at and at+1<len(trace)and trace[at-1]['operator']==trace[at+1]['operator']=='G':
        x,y=at-1,at+1;assert trace[x]['input_subset']==trace[y]['input_subset'];nodes=[v for v in nodes if v[0]!=y];merge.append([x,at,y])
     rows=[ell(ss)for at,ss in nodes];assert len(rows)==len(set(rows)),'NON_HU0_REPEATED_NODE';aug=list(rows)
     if(1,0,0)not in aug:aug.append((1,0,0))
     key=tuple(aug)
     if key not in cache:cache[key]=minor_certificate(aug)
     rank,witness=cache[key];assert rank==len(aug)<=3,('ROOT_AUGMENTED_DEPENDENCE',branch,trace)
     rawrows=[ell(ss)for at,ss in raw]
     if merge:assert sy.Matrix(rawrows).rank()<len(rawrows);raw_bad+=1
     records.append(dict(branch=branch,left_N=aa,right_N=bb,trace_field=start,all_right_to_left_factors=trace,all_raw_free_nodes=[ss for at,ss in raw],Hu0_merges=merge,effective_nodes=[ss for at,ss in nodes],effective_singularity_power_per_node_at_most2=True,root_augmented_linear_forms=[list(x)for x in aug],rank=rank,nonzero_minors=witness))
 assert records and raw_bad;bad=[ell(S)for S in[0,1,3,7]];assert sy.Matrix(bad).rank()<len(bad)
 art=save('source_support_certificate.json.gz',dict(all_full_source_selections=journals,source_words_considered=totalwords,selected_positions=selected,all_generic_types=types,nonminimal_types=Ntypes,actual_all33_Hu0_polynomial=[[i,j,list(ex),A.encode_coeff(c)]for(i,j,ex),c in sorted(hu.items())],Hu0_2Wopp_W=str(Hu),actual_G_Hu0_G=str(merged),merged_factor_left=str(lv),merged_factor_right=str(rv),merged_norm_powers='BB2,B-Lambda1,LambdaLambda0 with bounded F^2',all_typed_overenvelope_paths=records,all_integer_rank_minor_certificates=[dict(rows=[list(x)for x in key],rank=val[0],witness=val[1])for key,val in sorted(cache.items())],unmerged_Hu0_failures=raw_bad,wrong_silent_root_dedup_control=dict(subsets=[0,1,3,7],rank=int(sy.Matrix(bad).rank()),claimed_independent_count=4),wrong_W_factor_nonzero=True,counts_are_candidate_support_NOT_amplitudes=True))
 out=dict(schema='ACC_WHOLE_REFERENCE_ACTUAL_SOURCE_NODE_CERTIFICATE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all45_mean_colors_and_mean_jets_before_selection=True,all33_internal_M_all4B_231fields=True,all_full_source_dimensions_and_grades=True,actual_zero_mean_Hu_rank_identity_and_merged_bound=True,all_typed_paths_root_augmented_nodes_independent=True,complete_typed_path_count=len(records),Hu0_merge_required_paths=raw_bad,maximum_root_augmented_rank=max(p['rank']for p in records),generic_type_counts={k:len(v)for k,v in types.items()},artifact=art,prediction_inputs_denied=True,analytic_whole_reference_proof_not_yet_executed=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'support_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
