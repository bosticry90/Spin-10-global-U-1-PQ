# Absolute marked g0 input recovery V1

Question: what is the actual leading bare marked-master insertion for the
next missing one-loop Slavnov/source calculation? Reconstruct the input before
attempting amplitudes or reusing a reported zero. This follows completion and
exact two-route comparison of the 84-case descendant recovery.

Claim: compute Q0 KD and Qprobe KD (both probes), at gauge grade zero, with
all external sources and epsilon jets retained. Verify two density routes:
direct variation of the full canonical KD versus variation of its 33 Euler
components and all four explicit currents. Extract each epsilon functional
component, then all 45 Ja derivatives, before restricting other sources.
Catalog all surviving field/jet/source types, including declared zero slots.

Frozen domain: original Euclidean unshifted A0, intrinsic0/1, first u,
canonical source-left convention; epsilon is odd and external, Q is odd,
Qepsilon=0. Original KD is independent of u, so its u coefficient is Qprobe KD.
This is an inventory of the bare insertion Q_u KD, not the complete quantum
master equation, a Gamma amplitude, a zero tadpole, a local-mark QAP proof or
renormalized symmetry restoration. No external-source products factorize.

Inputs: unchanged primary/replay full-jet operation and QG, canonical KD and
its independently recorded epsilon Eulers, full source alphabet/parities,
exact coefficient ring and existing differential-polynomial tools. Reuse
authenticated WPC chart/IBP evidence and the completed sourceful descendant
packet. Current AGENTS/charter apply; no physical parameter specialization,
new finite normalization, foundational adoption or state promotion.

Method: literal prefix variation of KD; separate replay operation and
left-gradient variation of sum epsilon_s O_s plus div(-epsilon_s B_s^mu).
The current identity is checked BEFORE applying Q and the entire density
difference checked AFTER Q. A mistaken odd-epsilon sign, discarded current,
omitted source maps, or premature source restriction is a falsifier; record
honest insensitive controls as such and keep full differences.

Bounds: one serial owned worker, both derivations within90s after imports,
8GiB sampled private,350MiB launch floor,complete32MiB output. Preserve exact
source/input hashes, full capture and every incomplete/failed output. No
silently enlarged timer, truncated packet or old scientific file edit.
Expected outcome is a qualified input inventory or explicit failure/incomplete.
Agreement tests chart, source and sign errors, not shared physical assumptions.

Significance: an absolute marked identity needs this insertion's actual
sourceful ports and its loop/mean/regulator partners. A passing classical
inventory cannot replace those quantum calculations. Stop this inventory at
that boundary, assess the actual required kernels, and carry the smallest
missing quantum test into the live handoff. No M-class completion is inferred.
E4 authentication is owned by the preceding packet's validation continuation;
no additional E4 launch here. State113/34of39,E5/A5 open,custody2/sevenNOTPASS.
