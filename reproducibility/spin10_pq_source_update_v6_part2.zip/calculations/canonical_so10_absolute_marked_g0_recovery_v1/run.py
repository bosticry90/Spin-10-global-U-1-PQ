from pathlib import Path
import json, subprocess, sys
from hashlib import sha256

R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
digest=lambda p:sha256(p.read_bytes()).hexdigest()
names=['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V679.md',
       'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz',
       'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz',
       'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz',
       'calculations/canonical_so10_marked_descendant_recovery_v1/worker.py',
       'calculations/canonical_so10_marked_descendant_recovery_v1/native_result.json',
       'calculations/canonical_so10_marked_descendant_recovery_v1/replay_result.json']
old=json.loads((R/'calculations/canonical_so10_marked_descendant_recovery_v1/preparation.json').read_bytes())
names=sorted(set(names)|set(old['input_sha256']))
assert not (O/'preparation.json').exists(),'NO_OVERWRITE'
sources=['inventory.py','run.py','RECORD.md']
for n in sources:
 with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
prep=dict(input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in sources},scientific_acceptance='NOT_PERFORMED')
with (O/'preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(prep,f,sort_keys=True);f.write('\n')
cap=capture([sys.executable,'-B',str(O/'inventory.py')])
with (O/'inventory_capture.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(cap,f,sort_keys=True);f.write('\n')
assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'],cap['execution_state']
print('COMPLETED actual bare marked input inventory')
