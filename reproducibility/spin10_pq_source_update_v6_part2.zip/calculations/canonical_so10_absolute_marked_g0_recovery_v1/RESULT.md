# Bare marked-master input recovered; quantum equation still required

The actual Q0 KD density has264 nonzero terms and is an exact divergence.
Both first-probe Qprobe KD densities vanish at gauge grade zero. All99 epsilon
functional components and all4455 Ja derivatives are zero, using full sources
before differentiation. The original nonzero density and explicit currents
are preserved. This is a bare integrated statement in the frozen g0 domain.

The direct full-KD variation and separate component/current variation agree
exactly. Dropping the derivative-epsilon current changes264 base density terms;
omitting source maps or restricting KD before Q changes732 base and11856 broken
probe density terms. The unbroken-probe and odd-epsilon-sign controls are
insensitive in their actual zero sectors, as recorded. The preceding packet's
nonzero graded fixture separately tests that sign convention.

[Complete inventory result](inventory_result.json),
[full density/current/source tables](inventory_tables.json.gz),
[frozen scope](RECORD.md). Runtime11.705981s after imports; largest sampled
private allocation1049010176 bytes. All work fits the90s/8GiB/32MiB bounds.
No worker failed; final verification is owned by the preceding recovery
packet's validation receipt and not by an inferred scientific promotion.

This does **not** make the corresponding quantum current or regulator breaking
zero. Heat regularization, nonlinear source/mean responses and whole composite
insertions remain in the quantum equation. The next smallest calculation is
the absolute marked g0 one-loop identity using this qualified bare insertion,
the actual full regulated action, and independently constructed regulator/
source-product terms. Reuse the surviving primitive's nonzero57-position
proper kernel only in its proven projection; do not transfer that value or a
bare zero to a complete Slavnov identity.

The result recovers an input for work previously reported but whose executable
evidence is missing. It neither authenticates those missing packets nor advances
the reported count of nine M amplitudes. Same action/chart/software/AI author
limits remain. Scientific acceptance NOT_PERFORMED; E5/A5, the common quantum
construction and physical viability remain open. State113/34of39 unchanged.
