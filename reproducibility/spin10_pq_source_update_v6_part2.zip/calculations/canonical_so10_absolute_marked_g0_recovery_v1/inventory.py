"""Actual bare marked-master insertion; no quantum amplitude inferred."""
from pathlib import Path
from hashlib import sha256
import gzip, importlib.util, json, os, sys, threading, time

R=Path(__file__).resolve().parents[2]
O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('descendant_recovery_tools',O.parent/'canonical_so10_marked_descendant_recovery_v1/worker.py')
w=importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
J=w.J;v=w.v;u=w.u


def main():
    assert __debug__
    start=time.perf_counter()
    timer=threading.Timer(90,lambda:os._exit(124));timer.daemon=True;timer.start()
    prep=w.read(O/'preparation.json')
    for name,h in prep['input_sha256'].items():assert w.digest(R/name)==h,name
    assert w.digest(Path(__file__))==prep['source_sha256']['inventory.py']
    ct=w.load(R/'calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz')
    A=u.Algebra(ct['geometry']['names'],ct['geometry']['parities']);EPS=1286
    only0=lambda P:{k:c for k,c in P.items() if k[0]==0}
    K=only0(v.unpack(A,ct['K']))
    atom=lambda n,js=():{(0,((n,js),)):u.ONE}
    components={int(n):only0(v.unpack(A,p)) for n,p in ct['components'].items()}
    P={};currents=[{} for _ in range(4)]
    for s in range(33):
        v.merge(P,A.product(atom(EPS+s),components[EPS+s]))
        for mu in range(4):v.merge(currents[mu],u.scale(A.product(atom(EPS+s),atom(4*(12+s)+mu)),-1))
    div={}
    for mu,current in enumerate(currents):v.merge(div,v.total(A,current,mu))
    assert u.combine(P,div)==K,'FULL_KD_IBP_DENSITY_CHANGED'
    ops={}
    for route in ['primary','replay']:
        fj=w.load(R/('calculations/canonical_so10_full_jet_source_master_bridge/'+route+'_tables.json.gz'))
        q={n:w.raw(w.grade0(J.decode(p))) for n,p in fj['operation']}
        qs={'base':{n:p for n,p in q.items() if p}}
        for pr,mode in enumerate(['Hprobe','Mprobe']):
            grad=J.euler(w.grade0(J.decode(fj['probes'][pr]['qG'])))
            op={}
            for n in range(643):
                sg=(-1)**J.parity(n)
                for target,p in [(n,grad.get(n+643,{})),(n+643,grad.get(n,{}))]:
                    if p:op[target]=w.raw({word:sg*c for word,c in p.items()})
            qs[mode]=op
        ops[route]=qs
    results=[];records=[]
    for mode in ['base','Hprobe','Mprobe']:
        Q=ops['primary'][mode];QR=ops['replay'][mode]
        native=v.act(A,K,Q,1,'primary')
        explicit={}
        # Q(epsilon O)=-epsilon QO. Current variation is retained separately.
        for s in range(33):
            v.merge(explicit,u.scale(A.product(atom(EPS+s),v.act(A,components[EPS+s],QR,1,'replay')),-1))
        qcurrents=[v.act(A,z,QR,1,'replay') for z in currents]
        qdiv={}
        for mu,current in enumerate(qcurrents):v.merge(qdiv,v.total(A,current,mu))
        review=u.combine(explicit,qdiv)
        assert native==review,('MARKED_DENSITY_MISMATCH',mode)
        nc=v.euler(A,native,set(range(EPS,EPS+33)),'primary')
        rc=v.euler(A,review,set(range(EPS,EPS+33)),'replay')
        assert nc==rc
        Ja=[]
        for s in range(33):
            dn=v.euler(A,nc[EPS+s],set(range(1241,1286)),'primary')
            dr=v.euler(A,rc[EPS+s],set(range(1241,1286)),'replay')
            assert dn==dr
            for r in range(45):
                full=dn[1241+r]
                restricted={k:c for k,c in full.items() if not any(643<=n<1286 for n,js in k[1])}
                Ja.append(dict(epsilon=s+12,Ja=r,full=w.encoded(full),other_sources_zero=w.encoded(restricted)))
        wrongeps=u.combine(u.scale(explicit,-1),qdiv)
        fieldQ={n:p for n,p in Q.items() if n<643}
        noQsource=v.act(A,K,fieldQ,1,'primary')
        sourcefreeK={k:c for k,c in K.items() if not any(643<=n<1286 for n,js in k[1])}
        premature=v.act(A,sourcefreeK,Q,1,'primary')
        controls=dict(wrong_odd_epsilon_sign=u.combine(wrongeps,u.scale(native,-1)),
                      drop_derivative_epsilon_current=u.combine(explicit,u.scale(native,-1)),
                      omit_Q_source_maps=u.combine(noQsource,u.scale(native,-1)),
                      restrict_K_sources_before_Q=u.combine(premature,u.scale(native,-1)))
        census={}
        for component in nc.values():
            for (g,word),co in component.items():
                shape=tuple(sorted((('source' if 643<=n<1286 else 'B' if n<180 else 'scalar' if n<508 else 'Lambda' if n<553 else 'C' if n<598 else 'a'),len(js)) for n,js in word))
                key=json.dumps(shape,separators=(',',':'));census[key]=census.get(key,0)+1
        results.append(dict(mode=mode,density=w.encoded(native),functional_components=[[n,w.encoded(p)] for n,p in sorted(nc.items())],
                            Q_currents=[w.encoded(p) for p in qcurrents],Ja_derivatives=Ja,field_jet_source_census=census,
                            negative_controls={n:w.encoded(p) for n,p in controls.items()}))
        records.append(dict(mode=mode,density_terms=len(native),epsilon_components=33,
                            nonzero_components=sum(bool(p) for p in nc.values()),
                            nonzero_full_Ja_derivatives=sum(bool(z['full']) for z in Ja),
                            nonzero_restricted_Ja_derivatives=sum(bool(z['other_sources_zero']) for z in Ja),
                            negative_control_terms={n:len(p) for n,p in controls.items()}))
        print('STAGE actual absolute marked g0 '+mode+' complete density/components/source derivatives',flush=True)
    blob=gzip.compress((json.dumps(dict(cases=results),sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    assert len(blob)<=32*1024**2,'INCOMPLETE_PACKET_LIMIT'
    with (O/'inventory_tables.json.gz').open('xb') as f:f.write(blob)
    out=dict(schema='ABSOLUTE_MARKED_G0_BARE_INSERTION_RECOVERY_V1',cases=records,all_99_components_and_4455_Ja_derivatives_checked=True,
             full_KD_and_QKD_density_IBP_currents_preserved=True,table_sha256=sha256(blob).hexdigest(),table_bytes=len(blob),
             elapsed_after_imports=time.perf_counter()-start,quantum_amplitudes_calculated=False,
             renormalized_identity_or_QAP_or_E5_claim=False,scientific_acceptance='NOT_PERFORMED')
    with (O/'inventory_result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,sort_keys=True);f.write('\n')
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()


if __name__=='__main__':main()
