# Actual nonminimal aCC resolvent V1 - sign adapter

Continue V810/1b49f5bf, main, D: under current AGENTS. Previous bounded work
qualified unprobed/H aCC zero, M proper bridge and112->72 M candidate paths.
No M coefficient is known yet. State113/34of39,E5/A5 open, unchanged ledger.
No agents, adoption, activation, branch/worktree, remote or external action.

Question: can a finite normalized quadratic-Hessian inverse reproduce the
actual nonzero JBCC Gaussian sign reference, independently of a desired aCC
remainder? This is the least expensive prerequisite to combine72 paths via
the actual nonminimal Schur blocks. Do not introduce a benchmark platform.

Use both frozen V809 four-coordinate, three-internal-color fixtures, their
full quadratic action interactions VL/VJ, ordered covariance, actual CR
observable and literal normalized Berezin/Wick reference. These are finite
diagnostic projections, not physical benchmarks, full45-color contractions
or continuum heat-profile amplitudes. No external generators are identified.

New sparse matrix entries live in the exterior algebra of three odd means,
with an even u degree<=1 and existing g degree<=1 for later aCC use. Preserve
ordered coefficient multiplication. Quantum variables are bosonic B/L and
odd C/a; LEFT derivative crosses all external odd coefficients. For quadratic
action S, extract E_i=LEFT_i S=sum_j A_ij phi_j with coefficients on the left.
The normalized Schwinger-Dyson identity <E_i phi_j>=delta_ij makes ordered
covariance G=A^-1, with NO added manual ghost trace sign. Verify homogeneous
Euler reconstruction S=(1/2)sum phi_i E_i for every interaction.

Compute G by finite Neumann expansion of full supermatrix around the actual
regulated covariance, and separately by boson block inverse plus ghost Schur
complement. Check both left/right inverses and graded covariance symmetry.
Evaluate the actual quadratic CR observable and compare ALL exterior
coefficients with the saved normalized Wick and independent Schur results.
The saved literal two-pair Berezin anchor binds those ordered signs. Wrong
odd-source derivative (omit crossing external masks) is a negative control:
record actual sensitivity/blindness; a blind or all-zero fixture cannot
certify the sign. No omitted partition normalization is used as an input.

All inverse expansions must terminate exactly by g/u bounds and external
nilpotence; a resource/degree cut is never a scientific zero. Save full
matrices, currents, comparisons, controls, exact source/preparation/capture.
One180s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB complete packet/10MiB artifact. Freeze before launch; preserve failures,
no automatic retry. Existing references are authenticated, not a fresh Wick
replay. Both matrix methods share action/ring/multiplication/AI authorship;
agreement does not validate shared physical assumptions. No E5/QAP/measure/
restoration/physical-viability or full goal-completion result follows.
