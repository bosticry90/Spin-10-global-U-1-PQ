# aCC: actual nonminimal factorization and two covariance responses

This continues V810's selected Euclidean A0,g1,firstu M,intrinsic01 source
problem. Unprobed/H-probe aCC are already zero in that qualified prescription.
The72 remaining M paths still need full color, momentum and regulator-limit
evaluation. No unknown coefficient or desired LambdaCC remainder is an input
here. State113/34of39,E5/A5 stay unchanged; full goal remains active.

## Ordered Gaussian adapter and actual action

For a quadratic even action with odd background coefficients, write its LEFT
Euler equation E_i=sum_j A_ij phi_j with every background coefficient on the
left. The normalized Schwinger-Dyson identity <E_i phi_j>=delta_ij then gives
the ORDERED covariance G=A^-1 in that coefficient algebra. This automatically
retains ghost signs; adding a manual supertrace sign would double count them.
Quantum ghost differentiation crosses the external odd coefficients.

The new sparse exterior-algebra inverse exactly reproduces ALL coefficients
of both V809 nonzero JBCC normalized Wick/Berezin and Schur references:
-38216 sqrt10 xi2/20503125 and-87584 sqrt10 xi2/474609375. Direct full inverse
and independent boson/ghost Schur elimination agree entry for entry, satisfy
both inverse sides and graded covariance symmetry. Omitting the odd-background
crossing changes both targets. The actual literal Berezin calculation is
reused from its owning evidence, not claimed a new independent physical test.

For aCC, native action matrices come from actual full ordinary quadratic
Taylor halves. Replay selects only classical words compatible with the
declared finite internal/mean space, then applies LEFT T2/2. Their quadratic
polynomials agree before inversion. The g0 replay free Hessian is checked
against the anchored free block before subtracting that reference. Full
source-first F0,F1,Fu0_M,Fu1_M maps are differentiated before restriction;
prefix/LEFT first Taylor maps agree. Sources are removed only after the
recorded source/Euler operations. All original indices have dispositions.

## Full45-color operator factorization

From the full actual source-first Fu0 map, Z_r=Fu0_a,r/(2i), with Z=0 outside
the M projector. After source0, exact polynomial multiplication verifies

    U0 = sum_(r in M) Z_r^2,
    Z_r = i div B_r + xi Lambda_r/2 + V_r,   V_r=sum_(i,c) a_i L_c[r,i] C_c.

All45 source maps and the complete source-free U0 density are compared,
including all33 nonzero projected rows. This is not inferred by defining a
new U0. It gives a compact actual interaction construction with every ghost
term retained. There is no new gauge-width choice or normalization baseline.

Using the qualified V791 free inverse with arbitrary symbolic width Omega
and scalar profile F, let W(q)=(-q_mu,Omega/2) and W(-q)^T=(q_mu,Omega/2)^T.
Exact4D identities are W G_F W_opp^T=0, W G_F eLambda=F and G_LL=0. The wrong
factor1 in place of1/2 yields Omega F, a sensitive formal control. These are
matrix identities using the actual free block; no exceptional momentum is
assigned a new pointwise value and no standalone IR heat term is dropped.

On the ghost mean plane, write Z=Vmean+WY+V1+V2, where Y are quantum B/L
and V1,V2 are linear/quadratic Taylor pieces of V in quantum ghosts. Then
U0_quad=(WY+V1)^2+2 Vmean V2. At g0, the boson source is Lambda V1 and its
conditional W mean is-F V1, with zero W covariance. Thus the first-u ghost
Schur quadratic is ((1-F)V1)^2+2 Vmean V2. In particular the second term is
not obtained by guessing a whole-background effective action and then
differentiating it. This preserves the fixed-mean Hessian construction.

## Exact two-response representation

The actual nonreferenceg0 M nonminimal Hessian N has only Lambda-ghost mixed
blocks (the two ordinary classes LM-CM and LM-aM). With Gfree_LL=0,
(Gfree N)^3=0 by block support, independently of the number of background
ghost insertions or a numerical fixture. Therefore

    Gbase=Gfree-Gfree N Gfree+Gfree N Gfree N Gfree.

The ghost-ghost block of Gbase is free. This is a structural finite polynomial
on the selected ghost plane, not a theorem for a general physical background.

Let Hg and Hu be actual S1 and U0 quadratic Hessians. Differentiating the
inverse in the declared formal g/u degrees gives

    Gg=-Gbase Hg Gbase,    Gu=-Gbase Hu Gbase.

For ordered regulator-current contraction O, the full selected g*u result is

    C_R^(g u) = O_F1(Gu) + O_Fu0(Gg).

The whole F0 quadratic root is zero before ordinary insertions in V808's
qualified finite-formal prescription. Its potentially required mixed Hu1
therefore supplies no selected current. Fu1 roots have no returning path in
this target by the actual catalog and qualified scalar support. They are not
declared globally zero. V810's BB Ward reduction remains binding.

Every one of the72 retained paths is mapped to its unique positive-grade
ordinary insertion:44 F1-root paths have one U0,28 Fu0-root paths have one S1.
All other ordinary insertions areg0/u0 and are covered by Gbase. These counts
are NOT numerical multipliers. Hessian and root coefficients already encode
the actual Taylor/Wick multiplicities. Two response operators are not two
measured amplitudes. No new quantum coefficient is supplied by this identity.

The full inverse and response formulas agree on EVERY g1-u1 exterior
coefficient of all six new actual-action fixtures. The closed Gbase and its
free ghost block are independently checked. The graded inverse derivative
identity and actual typed-path coverage supply the general operator reduction;
finite fixtures diagnose its representation and signs, not continuum physics.

## Six nonzero finite diagnostics and controls

Internal colors12/13/14, four anchored longitudinal modes and symbolic xi
are retained. Three distinct odd backgrounds are theta1,theta2,chi with
profiles A=(e0,e0,e1), B=(e0,e2,e3). The following rational coefficient
multiplies g*u*xi2*sqrt10*theta1*theta2*chi in those finite covariance units:

| external C1,C2; antighost | profile A | profile B |
|---|---:|---:|
|0,14;13| -328/455625 |7004/3796875|
|13,14;0|1946768/307546875|2037952/4271484375|
|13,14;12|430710848/38443359375|-50132816/12814453125|

All are M-PROBE fixtures. The second row's H label refers only to the
external antighost color0; it does not contradict the H-probe zero. First row
activates F1 only, second row Fu0 only, third row both. F0 vanishes exactly
as a whole quadratic root; projected Fu1 vanishes independently.

Omitting the inverse-U0 zero-mean terms changes both first-row and both
third-row fixtures, while it is blind in the second row. Omitting actual
g1 quartic ghost vertices changes only the third-row profileA fixture; it is
blind in the other five. Every quartic term remains in the full matrices.
These measured controls exclude unjustified global zero claims and anchor
both response classes without choosing a coefficient to cancel a remainder.

The finite D matrix is skew and invertible but DOES NOT satisfy pointwise
Leibniz on arbitrary finite profiles. These are exact diagnostics of an
explicit quadratic action. No continuum Euler-before-discretization identity,
CQ+CR=Jac identity, proper-master result, full45-color coefficient or loop
integral is inferred from them. Taylor of the same raw density and discrete
quadratic differentiation are legitimate; falsely interchanging continuum
integration by parts and that finite substitution would not be. V810 owns
the separate continuum proper bridge. The nonzero diagnostic values prove
neither a continuum nonzero nor a physical anomaly.

## Significance, limits and next calculation

The source-consistency inventory is now represented by two actual response
operators and a closed g0 nonminimal covariance, with full U0 factorization
and nonzero sign-sensitive fixture coverage. No new worker failed in this
increment. The methods share action, field chart, coefficient ring, helpers
and AI author; they are not independent scientists or physical validation.
No Lean kernel certification, empirical result or new benchmark platform.

Final review freshly reconstructs the actual Taylor actions, full source
flows/roots, ordered inverses, Schur matrices, all omissions and full45 U0
identity; preserves exactly one inherited E4 audit and its seven custody
NOTPASS references. Scientific authority stays34/39, E5/A5 open.

NEXT: evaluate the full33-internal-color continuum kernels in the two-response
formula, using V',the actual S1 mixed and quartic ghost Hessians, and F1/Fu0
roots with formal widths/whole profiles. Separate color contractions from
momentum kernels, derive UV-first/IR-second joint-source limits, then insert
the measured aCC result into the known LambdaCC consistency equation. The
known rational10112/log10964 normal positions remain an incomplete sum.
No missing coefficient may be assigned to force cancellation. Common
normalization, source products, QAP, measure/reality, equivalence, E5/A5,
physical viability and the overall investigation remain open.
