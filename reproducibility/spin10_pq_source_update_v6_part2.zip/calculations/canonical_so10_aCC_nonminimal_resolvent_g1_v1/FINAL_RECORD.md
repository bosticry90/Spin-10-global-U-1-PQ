# Final actual aCC nonminimal evidence validation

One240s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB complete packet/10MiB artifact. Freeze all sources, proof/result and
handoff before execution. Authenticate every stage preparation/capture/input
and source copy; all5 successful workers must retain their original bounds.

Freshly compare both ordered JBCC nonzero references, full inverse/Schur
and wrong odd-source crossing control. Reconstruct full45 U0=sumZ2 from
actual source-first maps, not saved equality alone. Rebuild all3 scenarios'
classical word projections and native prefix T2 against saved LEFT T2,
all6 actual ordinary matrices, fullT1flows/roots, graded normalized inverse,
Schur and inversebothsides, each omission control and observedblindness.
Verify complete72path response map and all coefficients of both response
formulas with closedGbase. General operator proof is scoped in PROOF; finite
values do not establish continuum master/IBP/limit or full45 amplitude.

E4 once/no-fresh/existingDcontext; savefullstdout/stderr, expectedstep
exits0,0,0,0,0,2 and exactly7custody unresolved NOTPASS. Preserve oldGit
mode/blobs/working tracked bytes and stateSHA. Receipt validates bounded
evidence only, no scientific promotion/complete restoration/fullgoal claim.
