# aCC nonminimal current reduced to two actual responses

The full selected M-probe aCC current now has a qualified operator reduction
from72 typed paths to O_F1(Gu)+O_Fu0(Gg), with44/28 path coverage and
Gg=-Gbase Hg Gbase,Gu=-Gbase Hu Gbase. Actual g0 nonminimal block support
closes Gbase after two insertions. This is a representation of the remaining
calculation, not a measured continuum coefficient or two new amplitudes.

Exact full45-color source-first reconstruction gives U0=sumM Z2. The free
bosonic Z covariance vanishes and its Lambda covariance is F; these retain
the inverse-U0 response rather than discard it. Six new actual-action finite
fixtures are nonzero. Native Taylor and LEFT classical Taylor actions,
normalized full inverse and independent Schur elimination agree. Both F1
and Fu0 responses are exercised, and a quartic-ghost omission is sensitive
in one all-M fixture. Blind controls remain explicitly classified.

The matrix sign adapter also reproduces both saved nonzero JBCC normalized
Berezin/Wick references. Finite D lacks pointwise Leibniz, so these values
are diagnostics, not continuum master/CQ/QGamma or full45-color amplitudes.
No coefficient is fitted to the known LambdaCC remainder.

Subject to the owning final validation receipt, this completes the declared
factorization/operator-reduction/sign-diagnostic increment. Full M continuum
color/momentum evaluation and limits come next. State113/34of39,E5/A5 open;
historical custody seven unresolved NOTPASS. D: main, no remote actions,
adoption or protected promotion. Shared software/action/AI author disclosed.
