# Actual aCC nonminimal quadratic action and finite resolvent V1

The new adapter matches ALL exterior coefficients of both nonzero V809 JBCC
references by full inverse and Schur elimination; wrong odd-background crossing
changes both targets. This authorizes no continuum aCC amplitude. Next test
uses actual aCC action/field maps, without the desired LambdaCC remainder.

Same original Euclidean A0,g1,firstu M,upper a<=1,C<=2,intrinsic01 target.
V810 already proves the full proper bridge and excludes unprobed/H aCC.
All72 retained M paths use only10 ordinary nonminimal classes. Frozen V808
raw ordinary Taylor halves, V789 full S1/U1, full g0 action and U0, and full
V802 field/source maps are inputs. Sources are removed only after their
recorded source operations. Preserve all retained/rejected original indices.

First derive the full45-color M-probe source-free identity U0=sum_(r in M)
Z_r^2, with Z_r=Fu0_a,r/(2i) from the actual source-first field map. Compare
the actual U0 density, not a favorable sum. This is an operator factorization,
not a new parameter choice or quantum coefficient. Nonzero differences
withhold it and stay preserved. No u/width fitted to a desired remainder.

Finite diagnostic: internal M colors12/13/14, four longitudinal coordinate
modes with exactly the previously anchored rational D/F; B_mu0 only. Means
C0=theta1 profile, C14=theta2 profile, a13=chi profile are three DISTINCT odd
generators. This choice follows the actual nonzero F1_a13 C0 a14 structure,
not an unknown aCC coefficient. Profiles A e0/e0/e1 and B e0/e2/e3 are fixed.
Widths remain symbolic. This internal projection is not a closed physical
color algebra, physical parameter point, full45-color or continuum result.

Native interactions: translate the full retained ordinary quadratic Taylor
halves of GF_original g0/g1 and GF_probe1 g0/g1. Include inverse-U zero-mean
responses and g1 quartic ghost terms. Fixed external mean profiles can kill
a word; internal fields outside this diagnostic space are explicitly excluded.
Replay: select the original classical action words whose fields can belong
to the declared internal/mean space, apply actual LEFT T2/2, then translate.
For S0 subtract its actual free quadratic action after checking it equals
the anchored unregulated free block. Native/replay quadratic polynomials
must agree EXACTLY, before Hessian extraction. No old vector/source target
exclusion is transplanted. Physical scalar and transverse/color omissions
are only this fixture's projection, with V810's qualified full-scope proof
retained separately.

Translate T1 of full source-first F0,F1,Fu0_M,Fu1_M by prefix vs LEFT after
operations, and form actual raw regulator current sum_i (T1F_i) R_ij phi_j.
R is the fixed free H0(F^-1-1), not a redefined finite operator. Keep all
root types: F0 must be tested rather than deleted, and any projected Fu1
zero recorded. Compute the normalized whole raw current with both exact
full inverse and independent boson/ghost Schur formula; both inverse sides
and graded covariance symmetry are required. Save roots separately and
complete g/u/exterior coefficients. g/u/exterior nilpotence must terminate
the full expansion exactly, never merely at a resource bound.

The finite D matrix does NOT satisfy pointwise Leibniz on arbitrary profiles.
It specifies an explicit quadratic-action diagnostic and cannot establish
a continuum IBP, master, QGamma or restoration identity. Do not equate the
discretized continuum Euler polynomial with Euler of the discretized action.
The replay uses Taylor of the same raw classical density, which is valid
without that false Leibniz assumption. Proper master remains V810's separate
continuum proof. No CQ+CR=Jac assertion is made for this finite projection.

Controls: omit zero-mean U0 quadratic terms; omit g1 quartic-ghost ordinary
terms. Preserve actual changes/blindness for each profile. A zero fixture
does not prove a continuum zero. This stage must yield a qualified actual
factorization and exact finite raw-current representation, or a precisely
classified failure/inconclusive result; M continuum amplitude stays open.

One180s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact. Freeze before computation, complete captures,
no automatic retry. Current AGENTS/authority ceilings unchanged. Two Taylor/
matrix routes share action/ring/AI author and do not validate physical inputs.
