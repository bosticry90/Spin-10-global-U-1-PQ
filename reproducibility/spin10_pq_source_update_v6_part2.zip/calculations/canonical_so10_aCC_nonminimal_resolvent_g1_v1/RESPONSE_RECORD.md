# Actual two-response reduction of the72 M paths

All six fixed aCC finite fixtures are nonzero. The H-antighost scenarios
activate Fu0 only; first-stage H/M-ghost fixtures activate F1 only; all-M
fixtures activate both. Quartic omission is sensitive in all-M profileA
and blind elsewhere; inverse-U omission is sensitive in four and blind in
H-antighost fixtures. Preserve all actual distinctions, do not infer zeros.

Question: can the complete selected M current be expressed by two actual
covariance responses, rather than72 separately expanded contraction paths?
Freeze V810's exact retained paths/root exclusions and the new actual action
factorization. Full M ordinaryg0 nonreference NM Hessian N must contain only
Lambda-ghost mixed blocks; verify actual catalog classes. With free G_LL=0,
(Gfree N)^3=0 structurally, so
 Gbase=Gfree-Gfree N Gfree+Gfree N Gfree N Gfree.
Its ghost block is free. This holds for the declared M ghost mean plane,
not arbitrary physical backgrounds or an unrestricted resummation.

For actual action Hessians Hg (S1) and Hu (U0), the inverse identity gives
 Gg=-Gbase Hg Gbase, Gu=-Gbase Hu Gbase.
At overallg*u the ordered current is O_F1(Gu)+O_Fu0(Gg). Whole F0 quadratic
root is zero before ordinary insertions in the qualified V808 prescription;
Fu1 roots cannot return in this target by its actual catalog/scalar support.
Thus neither an unknown mixed Hu1 nor a favorable subtraction is needed
here. They are not globally declared zero. Verify every retained path has
one of these roots and exactly one matching ordinary insertion:44 F1-root
paths with one U0,28 Fu0-root paths with one S1. Preserve every path mapping.
Two operator responses are not two amplitudes or a measured continuum result.

Independently of finite diagnostic D, use actual V791 symbolic4D free
inverse and Zlin W(q)=(-q_mu,Omega/2), W(-q)^T=(q_mu,Omega/2)^T. Verify
 W G_F W_opp^T=0, W G_F eLambda=F and G_LL=0 for formal width/profile.
Wrong factor1 instead1/2 is sensitive. This binds the full33-color M
bosonic Schur simplification, using inherited actual inverse qualification.
Combined with U0=sum Z2, at ghost mean plane Zmean=Vmean and
 U0_quad=(WY+V1)^2+2 Vmean V2,
where V=aLC and V1,V2 are its linear/quadratic Taylor pieces. Conditional
boson integration gives Hu's effective ghost quadratic
 ((1-F)V1)^2+2 Vmean V2.
Do not replace the second term by the Taylor expansion of a guessed
background effective action: fixed-mean Hessian and whole-field integration
are different operations. Scalar profiles stay as whole operators.

Check both response formulas against ALL g1-u1 exterior coefficients of
each saved full inverse fixture, not only a desired target. Verify closed
Gbase, its free ghost block, full inverse response matrices and omissions.
No finite D Leibniz or continuum CQ/master identity is inferred. The formal
inverse derivative proof and typed full-path coverage supply the full target
operator reduction; numerical fixtures check representation/signs only.

One120s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact. Freeze source/input hashes, preserve failures,
no automatic retry. Shared assumptions/action/ring/AI author disclosed.
M continuum color/momentum integrals, limits, common normalization and
E5/A5 remain open; authority/state unchanged.
