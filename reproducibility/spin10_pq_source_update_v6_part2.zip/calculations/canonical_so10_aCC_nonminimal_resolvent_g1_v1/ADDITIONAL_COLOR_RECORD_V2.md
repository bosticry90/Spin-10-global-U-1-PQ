# Additional fixed aCC color projections V2

First finite stage completed35.798s/180. Full45-color source-free U0=sumM Z2
holds exactly. Native ordinary Taylor and LEFT Taylor of full classical
actions agree, as do both normalized inverse methods. The C0/C14,a13
fixtures are nonzero but their g1-quartic omission control is BLIND; only
the F1 roots contribute to the selected g*u coefficient there. Do not infer
that the Fu0 or quartic families vanish in the full calculation.

This new predetermined diagnostic changes only external color roles:
H scenario C13/C14,a0 and M scenario C13/C14,a12. Internal M12/13/14,
four-coordinate D/F, independent theta1/theta2/chi and profiles A/B unchanged.
These choices exercise the actual H-M-M gauge/ghost vertex and M-M-M
structure already present in the surviving action, without consulting the
desired consistency remainder. Actual nonzero or zero outcomes are both
retained. Do not keep adjusting colors or profiles until a favored result.

All FINITE_ACC_RECORD obligations, source-operation order, native/LEFT
action equality, full inverse/Schur/graded symmetry, exact nilpotent
termination and both omission controls remain. Reuse the completed full45
U0 factorization after authenticating it rather than recomputing it twice.
Separate scenario-owned outputs/captures. Two sequential180s after-import
workers, each8GiB sampled/350MiB floor,64MiB complete packet/10MiB artifact.
Freeze both before first execution; a failed worker is preserved and never
automatically retried. Running the separately frozen second scenario is a
different declared projection, not retry of a failed result.

The diagnostic finite D lacks pointwise Leibniz, so no continuum master,
CQ identity, full45-color amplitude or restored normalization follows from
these values. Quartic control may remain blind: report it; the input term
must remain in all actual matrices. Current scientific authority unchanged.
