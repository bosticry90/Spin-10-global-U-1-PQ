from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
import sympy as s
import sys
SCENARIO=sys.argv[1] if __name__=='__main__' else 'H'
assert SCENARIO in ['H','M']
ACO=0 if SCENARIO=='H' else 12
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(n,p):
 sp=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z);return z
a=module('checked_ordered_resolvent',O/'resolvent.py');v=module('finite_aCC_native_Taylor',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py');vr=module('finite_aCC_LEFT_Taylor',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py')
J=a.J;w=v.w;A=a.A;one=a.one;zero=a.zero;N=12;NB=24;TOTAL=48;IC=[12,13,14]
def encode_p(P):return [[u,m,list(bb),list(gg),A.encode_coeff(c)] for (u,m,bb,gg),c in sorted(P.items())]
def strip_g0(P):return {k:c for k,c in P.items() if all(q[0]==0 for q,x in c.terms)}
def free(case):
 G={}
 for i,j,c in case['free_boson_covariance']:G[i,j]={(0,0):A.decode_coeff(c)}
 for i,j,c in case['free_ordered_Ca_covariance']:G[NB+i,NB+N+j]={(0,0):A.decode_coeff(c)};G[NB+N+j,NB+i]={(0,0):-A.decode_coeff(c)}
 D=s.sympify(case['D']);F=s.sympify(case['F']);K=-D*D;fi=F.inv();x=s.Symbol('xi',real=True);H={};Hreg={}
 for color in range(3):
  for u in range(4):
   for vv in range(4):
    i,j=color*4+u,color*4+vv
    for left,right,h,hf in [(i,N+j,-s.I*D[u,vv],-s.I*(D*fi)[u,vv]),(N+i,j,s.I*D[u,vv],s.I*(D*fi)[u,vv]),(N+i,N+j,x*int(u==vv),x*fi[u,vv]),(NB+i,NB+N+j,-K[vv,u],-(K*fi)[vv,u]),(NB+N+i,NB+j,K[u,vv],(K*fi)[u,vv])]:
     if h:H[left,right]={(0,0):A.co(str(h))}
     if hf:Hreg[left,right]={(0,0):A.co(str(hf))}
 assert a.mm(Hreg,G)==a.mm(G,Hreg)==a.ident(range(TOTAL))
 return D,F,H,Hreg,G,a.ma(Hreg,a.ms(H,J.constant(-1)))
def tag(n):
 if n<180:
  c,mu=divmod(n,4)
  if c in IC and mu==0:return 'b',IC.index(c)*4
 elif 508<=n<553 and n-508 in IC:return 'b',N+IC.index(n-508)*4
 elif 553<=n<598 and n-553 in IC:return 'g',IC.index(n-553)*4
 elif 598<=n<643 and n-598 in IC:return 'g',N+IC.index(n-598)*4
 return None
MEANS={566:0,567:1,598+ACO:2}
def translate(raw,profiles,D,u=0):
 dp=[s.eye(4),D,D*D,D**3,D**4];out={};kept=[];rejected=defaultdict(list)
 def atom(n,js,x):
  if any(mu!=0 for mu in js):return {}
  dd=dp[len(js)]
  if 1319<=n<1962:
   t=tag(n-1319)
   if t is None:return {}
   kind,base=t;z={}
   for y in range(4):
    val=dd[x,y]
    if val:z[0,0,(base+y,) if kind=='b' else (),() if kind=='b' else (base+y,)]=A.co(str(val))
   return z
  if n not in MEANS:return {}
  which=MEANS[n];val=sum(dd[x,y]*profiles[which][y] for y in range(4))
  return {(0,1<<which,(),()):A.co(str(val))} if val else {}
 for at,(word,coef) in enumerate(raw):
  pieces={}
  for x in range(4):
   p={(u,0,(),()):A.decode_coeff(coef)}
   for n,js in word:
    p=a.pm(p,atom(n,js,x))
    if not p:break
   pieces=a.pa(pieces,p)
  if pieces:kept.append(at);out=a.pa(out,pieces)
  else:rejected['ZERO_ON_DECLARED_INTERNAL_MEAN_JET_PROJECTION'].append(at)
 return out,dict(kept_original_indices=kept,rejected=[dict(reason=k,original_indices=v) for k,v in sorted(rejected.items())])
def classical_allowed(raw):
 keep={};ids=[];bad=[]
 for at,(ww,c) in enumerate(raw):
  if all(n<643 and (tag(n) is not None or n in MEANS) and all(mu==0 for mu in js) for n,js in ww):keep[tuple((n,tuple(js)) for n,js in ww)]=A.decode_coeff(c);ids.append(at)
  else:bad.append(at)
 return keep,dict(kept_original_indices=ids,rejected_original_indices=bad)
def observe_parts(roots,G):return {name:a.observe(p,G,NB) for name,p in roots.items()}
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'finite_additional_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 old=O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1';ref=a.load(old/'gaussian_tables.json.gz')['cases'][0];D,F,H,Hreg,G0,RR=free(ref)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=a.load(base/'native_inputs.json.gz');pr=a.load(base/'replay_inputs.json.gz');assert pn==pr;states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()}
 cb=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';native=a.load(cb/'native_aCC_catalog.json.gz');replay=a.load(cb/'replay_aCC_catalog.json.gz');assert native==replay
 common=a.load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/replay_GF_common.json.gz');factor=a.read(O/'finite_result.json')['actual_U0_full45_factorization'];assert a.digest(O/factor['file'])==factor['sha256'] and not a.load(O/factor['file'])['difference']
 actions=a.load(O.parent/'canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz');s0=next(q for q in actions if q['role']=='replay')['original'][0]['density'];dens=a.load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/replay_route_densities.json.gz');classical=[('S0',0,0,s0),('S1',1,0,dens['S1']),('U0',0,1,common['probes'][1]['U']),('U1',1,1,dens['U1'][1] if isinstance(dens['U1'],list) else dens['U1']['1'])]
 # Freeze only structural input formats; no coefficient inferred from a target.
 prepared=[]
 for label,g,u,raw in classical:
  p,pj=classical_allowed(raw);t=w.scale(vr.tangent(vr.tangent(p)),J.constant(Q(1,2)));prepared.append(dict(label=label,g=g,u=u,classical=J.encode(p),projection=pj,T2_LEFT_half=J.encode(t)))
 output=[];summaries=[];profiles=[('A',[[1,0,0,0],[1,0,0,0],[0,1,0,0]]),('B',[[1,0,0,0],[0,0,1,0],[0,0,0,1]])]
 actualmaps={};tmap={}
 for label,g,u in [('F0',0,0),('F1',1,0),('Fu0_1',0,1),('Fu1_1',1,1)]:
  maps=[]
  for color in IC:
   for n in [4*color,508+color,553+color,598+color]:
    p={ww:c for ww,c in states[label][n].items() if all(i<643 for i,js in ww)};tn=v.tangent(p);tr=vr.tangent(p);assert tn==tr;maps.append([n,J.encode(tn)])
  tmap[label]=maps;actualmaps[label]=dict(g=g,u=u,T1_native_LEFT_equal=maps)
 for label,prof in profiles:
  Vpoly={};parts={};journals=[];nativeblocks=[]
  for block in native['ordinary']:
   if block['owner'] not in ['GF_original','GF_probe1']:continue
   p,pj=translate(block['selected'],prof,D,block['u']);Vpoly=a.pa(Vpoly,p);parts[block['owner'],block['g'],block['u']]=p;journals.append(dict(owner=block['owner'],g=block['g'],u=block['u'],projection=pj,translated=encode_p(p)))
  rp={};replayblocks=[]
  for block in prepared:
   p,pj=translate(block['T2_LEFT_half'],prof,D,block['u'])
   if block['label']=='S0':
    hp=a.hessian(p,NB,TOTAL);assert a.ma(hp,a.ms(H,J.constant(-1)))==a.hessian(parts['GF_original',0,0],NB,TOTAL)
    # Native stores only the nonreference action. Compare complete Hessians
    # rather than subtracting a polynomial by a chosen IBP representative.
   else:
    owner='GF_original' if block['label']=='S1' else 'GF_probe1';assert p==parts[owner,block['g'],block['u']],('NATIVE_LEFT_ACTION_MISMATCH',block['label'])
   replayblocks.append(dict(label=block['label'],projection=pj,translated=encode_p(p)))
  V=a.hessian(Vpoly,NB,TOTAL);G,st=a.inverse_from_base(G0,V,range(TOTAL));full=a.ma(Hreg,V);assert a.mm(full,G)==a.mm(G,full)==a.ident(range(TOTAL));GS,ss=a.schur(G0,V,NB,TOTAL);assert G==GS
  for (i,j),p in G.items():assert p==a.es(G.get((j,i),{}),J.constant((-1)**(int(i>=NB)*int(j>=NB))))
  roots={}
  # Root translation at a fixed output point uses the same token algebra.
  dp=[s.eye(4),D,D*D,D**3,D**4]
  def atom_at(n,js,x):
   if any(mu!=0 for mu in js):return {}
   dd=dp[len(js)]
   if 1319<=n<1962:
    t=tag(n-1319)
    if not t:return {}
    kind,base=t;out={}
    for y in range(4):
     if dd[x,y]:out[0,0,(base+y,) if kind=='b' else (),() if kind=='b' else (base+y,)]=A.co(str(dd[x,y]))
    return out
   if n not in MEANS:return {}
   k=MEANS[n];val=sum(dd[x,y]*prof[k][y] for y in range(4));return {(0,1<<k,(),()):A.co(str(val))} if val else {}
  for state,maps in tmap.items():
   root={};u=actualmaps[state]['u']
   for n,raw in maps:
    kind,base=tag(n);index=base if kind=='b' else NB+base
    for x in range(4):
     lin={}
     for ww,c in raw:
      p={(u,0,(),()):A.decode_coeff(c)}
      for field,js in ww:p=a.pm(p,atom_at(field,js,x))
      lin=a.pa(lin,p)
     r={}
     for (ii,j),coef in RR.items():
      if ii!=index+x:continue
      for (uu,mask),c in coef.items():
       assert uu==mask==0;r=a.pa(r,a.ps(a.pv(j,NB),c))
     root=a.pa(root,a.pm(lin,r))
   roots[state]=root
  assert not roots['F0'],'WHOLE_FREE_F0_ROOT_NOT_ZERO';assert not roots['Fu1_1'],'PROJECTED_FU1_ROOT_NOT_ZERO'
  values=observe_parts(roots,G);total=a.ea(*values.values());assert total==a.observe(a.pa(*roots.values()),GS,NB)
  zeroU={k:c for k,c in parts['GF_probe1',0,1].items() if k[1]==0};quartic={k:c for k,c in parts['GF_original',1,0].items() if not k[2]};controls=[]
  for name,omit in [('omit_zero_mean_U0',zeroU),('omit_g1_quartic_ghosts',quartic)]:
   badV=a.hessian(a.pa(Vpoly,a.ps(omit,J.constant(-1))),NB,TOTAL);badG,_=a.inverse_from_base(G0,badV,range(TOTAL));bad=a.ea(*observe_parts(roots,badG).values());controls.append(dict(control=name,removed=encode_p(omit),current=a.encode_e(bad),difference=a.encode_e(a.ea(bad,a.es(total,J.constant(-1))))))
  out=dict(profile=label,means=dict(C_colors=[13,14],a_color=ACO,profiles=prof),native_blocks=journals,replay_blocks=replayblocks,interaction_hessian=a.encode_m(V),normalized_covariance=a.encode_m(G),Neumann=st,Schur=ss,root_polynomials={k:encode_p(p) for k,p in roots.items()},root_currents={k:a.encode_e(p) for k,p in values.items()},whole_current=a.encode_e(total),target=a.A.encode_coeff(total.get((1,7),zero)),controls=controls,finite_Leibniz_not_assumed=True);art=a.save('finite_aCC_'+SCENARIO+'_'+label+'.json.gz',out);output.append(art)
  row=dict(profile=label,covariance_entries=len(G),target=out['target'],nonzero=bool(total.get((1,7))),root_target={k:A.encode_coeff(p.get((1,7),zero)) for k,p in values.items()},controls_changed_positions={q['control']:len(q['difference']) for q in controls});summaries.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 inp=a.save('actual_Taylor_inputs_'+SCENARIO+'.json.gz',dict(classical_replay_selected_before_T2=prepared,all_source_first_T1_flows=actualmaps))
 result=dict(schema='ACTUAL_ACC_ADDITIONAL_COLOR_FINITE_RESOLVENT_V2',scenario=SCENARIO,execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',actual_U0_full45_factorization=factor,inputs=inp,cases=summaries,artifacts=output,native_T2_LEFT_classical_action_and_two_inverse_routes_equal=True,full_F0_root_and_projected_Fu1_root_zero=True,full45_color_and_continuum_aCC_coefficients_not_calculated=True,finite_D_Leibniz_limitation_preserved=True,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/('finite_result_'+SCENARIO+'.json'),result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
