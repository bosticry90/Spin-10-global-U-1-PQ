from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import gc,importlib.util,json,os,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-nonminimal-resolvent-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('final_aCC_response_tools',O/'response.py');r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r)
f=r.f;a=f.a;J=a.J;A=a.A;w=f.w;read=a.read;load=a.load;digest=a.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def roots_from_actual(flows,profiles,D,RR,means):
 dp=[s.eye(4),D,D*D,D**3,D**4]
 def atom(n,js,x):
  if any(mu!=0 for mu in js):return {}
  dd=dp[len(js)]
  if 1319<=n<1962:
   t=f.tag(n-1319)
   if not t:return {}
   kind,base=t;out={}
   for y in range(4):
    if dd[x,y]:out[0,0,(base+y,) if kind=='b' else (),() if kind=='b' else (base+y,)]=A.co(str(dd[x,y]))
   return out
  if n not in means:return {}
  k=means[n];val=sum(dd[x,y]*profiles[k][y] for y in range(4));return {(0,1<<k,(),()):A.co(str(val))} if val else {}
 out={}
 for state,block in flows.items():
  root={}
  for n,raw in block['T1_native_LEFT_equal']:
   kind,base=f.tag(n);index=base if kind=='b' else f.NB+base
   for x in range(4):
    lin={}
    for ww,c in raw:
     p={(block['u'],0,(),()):A.decode_coeff(c)}
     for field,js in ww:p=a.pm(p,atom(field,js,x))
     lin=a.pa(lin,p)
    reg={}
    for (i,j),coef in RR.items():
     if i==index+x:
      for (u,m),c in coef.items():assert u==m==0;reg=a.pa(reg,a.ps(a.pv(j,f.NB),c))
    root=a.pa(root,a.pm(lin,reg))
  out[state]=root
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for p in O.glob('*preparation.json'):
  for n,h in read(p)['sha256'].items():assert digest(R/n)==h,(p.name,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 caps={};seconds={}
 for capname,resname,bound in [('adapter','adapter',180),('finite','finite',180),('finite_H','finite_H',180),('finite_M','finite_M',180),('response','response',120)]:
  cf={'finite_H':'finite_capture_H.json','finite_M':'finite_capture_M.json'}.get(capname,capname+'_capture.json');rf={'finite_H':'finite_result_H.json','finite_M':'finite_result_M.json'}.get(resname,resname+'_result.json');cap=read(O/cf);res=read(O/rf)
  assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);caps[capname]=cap;seconds[capname]=res['elapsed_after_imports']
 old=O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1';olddata=load(old/'gaussian_tables.json.gz');D,F,H,Hreg,Gfree,RR=f.free(olddata['cases'][0]);adapter=load(O/'adapter_tables.json.gz')
 for prior,ev in zip(olddata['cases'],adapter['cases']):
  P=a.pa(a.poly_decode(prior['VL']),a.poly_decode(prior['VJ']));V=a.hessian(P,f.NB,f.TOTAL);assert a.encode_m(V)==ev['actual_quadratic_interaction_hessian'];G,st=a.inverse_from_base(Gfree,V,range(f.TOTAL));GS,ss=a.schur(Gfree,V,f.NB,f.TOTAL);assert G==GS and a.encode_m(G)==ev['ordered_covariance'];val=a.observe(a.poly_decode(prior['CR_observable']),G,f.NB);assert val=={(0,m):A.decode_coeff(c) for m,c in prior['CR']} and a.encode_e(val)==ev['CR'] and val[(0,7)]
  badV=a.hessian(P,f.NB,f.TOTAL,True);badG,_=a.inverse_from_base(Gfree,badV,range(f.TOTAL));bad=a.observe(a.poly_decode(prior['CR_observable']),badG,f.NB);assert a.encode_e(bad)==ev['wrong_external_crossing_CR'] and a.encode_e(a.ea(bad,a.es(val,J.constant(-1))))==ev['wrong_external_crossing_difference'] and ev['wrong_external_crossing_difference']
 print('STAGE both_nonzero_ordered_Berezin_Wick_reference_adapters_freshly_verified',flush=True)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(base/'native_inputs.json.gz');states={k:{n:J.decode(p) for n,p in rows} for k,rows in packet['states'].items()};common=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1/replay_GF_common.json.gz');U0={ww:c for ww,c in J.decode(common['probes'][1]['U']).items() if all(n<643 for n,js in ww)};Z=[];prediction={}
 for color in range(45):
  p={ww:c for ww,c in states['Fu0_1'][598+color].items() if all(n<643 for n,js in ww)};zz=w.scale(p,J.times(-J.I,J.constant(Q(1,2))));Z.append([color,J.encode(zz)]);J.add(prediction,J.mul(zz,zz))
 prediction=J.clean(prediction);fact=load(O/'actual_U0_factorization.json.gz');assert prediction==U0 and fact['actual_source_free_U0']==J.encode(U0) and fact['Z_from_actual_source_first_Fu0']==Z and fact['sum_Z_squared']==J.encode(prediction) and not fact['difference']
 cb=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';cat=load(cb/'native_aCC_catalog.json.gz');assert cat==load(cb/'replay_aCC_catalog.json.gz');dens=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/replay_route_densities.json.gz');tables=load(O.parent/'canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz');s0=next(q for q in tables if q['role']=='replay')['original'][0]['density'];classical=[('S0',0,0,s0),('S1',1,0,dens['S1']),('U0',0,1,common['probes'][1]['U']),('U1',1,1,dens['U1'][1])]
 inputsets={key:load(O/('actual_Taylor_inputs'+tail+'.json.gz')) for key,tail in [('base',''),('H','_H'),('M','_M')]};flows=inputsets['base']['all_source_first_T1_flows'];assert all(q['all_source_first_T1_flows']==flows for q in inputsets.values())
 for label,block in flows.items():
  for n,raw in block['T1_native_LEFT_equal']:
   p={ww:c for ww,c in states[label][n].items() if all(i<643 for i,js in ww)};native=f.v.tangent(p);left=f.vr.tangent(p);assert native==left and J.encode(native)==raw
 profiles_by={};casefiles=[]
 for scenario,means,names in [('base',{553:0,567:1,611:2},['finite_aCC_A.json.gz','finite_aCC_B.json.gz']),('H',{566:0,567:1,598:2},['finite_aCC_H_A.json.gz','finite_aCC_H_B.json.gz']),('M',{566:0,567:1,610:2},['finite_aCC_M_A.json.gz','finite_aCC_M_B.json.gz'])]:
  f.MEANS=means;prepared=inputsets[scenario]['classical_replay_selected_before_T2']
  for ev,(label,g,u,raw) in zip(prepared,classical):
   p,pj=f.classical_allowed(raw);assert J.encode(p)==ev['classical'] and pj==ev['projection'];tn=w.scale(f.v.tangent(f.v.tangent(p)),J.constant(Q(1,2)));assert J.encode(tn)==ev['T2_LEFT_half']
  for name in names:
   z=load(O/name);prof=z['means']['profiles'];P={};parts={};journal=[]
   for block in cat['ordinary']:
    if block['owner'] not in ['GF_original','GF_probe1']:continue
    p,pj=f.translate(block['selected'],prof,D,block['u']);parts[block['owner'],block['g'],block['u']]=p;P=a.pa(P,p);journal.append(dict(owner=block['owner'],g=block['g'],u=block['u'],projection=pj,translated=f.encode_p(p)))
   assert journal==z['native_blocks']
   for ev,saved in zip(prepared,z['replay_blocks']):
    p,pj=f.translate(ev['T2_LEFT_half'],prof,D,ev['u']);assert saved==dict(label=ev['label'],projection=pj,translated=f.encode_p(p))
    if ev['label']=='S0':assert a.ma(a.hessian(p,f.NB,f.TOTAL),a.ms(H,J.constant(-1)))==a.hessian(parts['GF_original',0,0],f.NB,f.TOTAL)
    else:owner='GF_original' if ev['label']=='S1' else 'GF_probe1';assert p==parts[owner,ev['g'],ev['u']]
   V=a.hessian(P,f.NB,f.TOTAL);assert a.encode_m(V)==z['interaction_hessian'];G,st=a.inverse_from_base(Gfree,V,range(f.TOTAL));GS,ss=a.schur(Gfree,V,f.NB,f.TOTAL);assert G==GS and a.encode_m(G)==z['normalized_covariance'] and ss==z['Schur'] and st==z['Neumann'];AA=a.ma(Hreg,V);assert a.mm(AA,G)==a.mm(G,AA)==a.ident(range(f.TOTAL))
   for (i,j),v in G.items():assert v==a.es(G.get((j,i),{}),J.constant((-1)**(int(i>=f.NB)*int(j>=f.NB))))
   roots=roots_from_actual(flows,prof,D,RR,means);assert {k:f.encode_p(v) for k,v in roots.items()}==z['root_polynomials'] and not roots['F0'] and not roots['Fu1_1'];vals=f.observe_parts(roots,G);total=a.ea(*vals.values());assert {k:a.encode_e(v) for k,v in vals.items()}==z['root_currents'] and a.encode_e(total)==z['whole_current'] and total.get((1,7))
   omissions=[('omit_zero_mean_U0',{k:c for k,c in parts['GF_probe1',0,1].items() if k[1]==0}),('omit_g1_quartic_ghosts',{k:c for k,c in parts['GF_original',1,0].items() if not k[2]})]
   for ev,(control,omit) in zip(z['controls'],omissions):
    badV=a.hessian(a.pa(P,a.ps(omit,J.constant(-1))),f.NB,f.TOTAL);badG,_=a.inverse_from_base(Gfree,badV,range(f.TOTAL));bad=a.ea(*f.observe_parts(roots,badG).values());assert ev==dict(control=control,removed=f.encode_p(omit),current=a.encode_e(bad),difference=a.encode_e(a.ea(bad,a.es(total,J.constant(-1)))))
   casefiles.append(name);print('STAGE fresh_actual_action_Taylor_flow_roots_inverse_Schur_and_controls '+name,flush=True)
 print('STAGE full45_U0_factorization_and_all6_nonzero_finite_diagnostics_verified',flush=True)
 response=load(O/'response_tables.json.gz');ward=load(O.parent/'canonical_so10_aCC_operator_reduction_g1_v1/ward_tables.json.gz');paths=ward['path_decisions'][2]['retained_paths'];assert len(paths)==72 and [v['path'] for v in response['complete72_path_response_map']]==paths
 for ev in response['complete72_path_response_map']:
  root,ro,path=ev['path'];owner=cat['classes'][root]['owner'];assert owner==('R_F1' if ev['response']=='Hu' else 'R_Fu0_1');ids=[(at,i,o) for at,(i,o) in enumerate(path) if cat['classes'][i]['u' if ev['response']=='Hu' else 'g']==1];assert len(ids)==1 and ids[0][0]==ev['unique_insertion_position'] and ids[0][1]==ev['ordinary_class']
 assert response['counts']=={'Hu':44,'Hg':28}
 for ev in response['finite_cases']:
  assert digest(O/ev['source'])==ev['source_sha256'];z=load(O/ev['source']);V=r.dm(z['interaction_hessian']);N=r.mg(V,0,0);T=a.mm(Gfree,N);T2=a.mm(T,T);assert not a.mm(T2,T);Gbase=a.ma(Gfree,a.ms(a.mm(T,Gfree),J.constant(-1)),a.mm(T2,Gfree));assert a.encode_m(Gbase)==ev['closed_Gbase'];Gu=a.ms(a.mm(a.mm(Gbase,r.mg(V,0,1)),Gbase),J.constant(-1));Gg=a.ms(a.mm(a.mm(Gbase,r.mg(V,1,0)),Gbase),J.constant(-1));assert a.encode_m(Gu)==ev['Gu'] and a.encode_m(Gg)==ev['Gg'];roots={k:r.dp(v) for k,v in z['root_polynomials'].items()};left=a.observe(roots['F1'],Gu,f.NB);right=a.observe(roots['Fu0_1'],Gg,f.NB);cur=r.grade(a.ea(left,right),1,1);assert a.encode_e(left)==ev['F1_response'] and a.encode_e(right)==ev['Fu0_response'] and a.encode_e(cur)==ev['whole_g1_u1']==a.encode_e(r.grade(a.decode_e(z['whole_current']),1,1))
 print('STAGE actual72_path_two_response_operator_coverage_and_all_coefficients_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(v) for v in p.stdout.splitlines() if v.strip()];exits=[v['exit_code'] for v in events if v['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and next(v for v in events if v['event']=='step_finished' and v['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V811.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 receipt=dict(schema='ACTUAL_ACC_NONMINIMAL_TWO_RESPONSE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_ACTUAL_U0_FACTORIZATION_TWO_RESPONSE_REDUCTION_AND_FINITE_SIGN_DIAGNOSTICS',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,full45_source_free_U0_sum_Z_squared_verified=True,old_nonzero_Wick_Berezin_anchor_adapters=2,actual_finite_action_prefix_LEFT_and_inverse_Schur_cases=6,nonzero_finite_aCC_targets=6,quartic_control_sensitive_only_M_A=True,actual72_path_response_counts={'Hu':44,'Hg':28},full_target_operator_reduction_verified=True,finite_D_Leibniz_not_assumed=True,finite_coefficients_not_continuum_or_full45_amplitudes=True,continuum_aCC_limit_common_restoration_E5_A5_and_goal_still_open=True,failed_workers=0,worker_seconds_after_imports=seconds,largest_sampled_private_bytes=max(v['private_bytes'] for cap in caps.values() for v in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick)
 dump(O/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
