from pathlib import Path
from collections import Counter
import importlib.util,json,os,threading,time
import sympy as s
sp=importlib.util.spec_from_file_location('actual_aCC_finite_response',Path(__file__).resolve().with_name('finite_acc.py'));f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f)
R=f.R;O=f.O;a=f.a;J=f.J;w=f.w;A=f.A
def dm(rows):return {(i,j):a.decode_e(z) for i,j,z in rows}
def dp(rows):return {(u,m,tuple(bb),tuple(gg)):A.decode_coeff(c) for u,m,bb,gg,c in rows}
def grade(P,g,u):
 out={}
 for (uu,m),c in P.items():
  if uu!=u:continue
  cc=J.Coeff([(k,v) for k,v in c.terms if k[0]==g])
  if cc:out[uu,m]=cc
 return out
def mg(P,g,u):return {k:grade(c,g,u) for k,c in P.items() if grade(c,g,u)}
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'response_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 cb=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';cat=a.load(cb/'native_aCC_catalog.json.gz');ward=a.load(O.parent/'canonical_so10_aCC_operator_reduction_g1_v1/ward_tables.json.gz');paths=ward['path_decisions'][2]['retained_paths'];mapped=[]
 original0=[c for c in cat['classes'] if c['owner']=='GF_original' and c['g']==0 and all(q in ['BM','LM','CM','aM'] for q in c['quantum'])]
 assert len(original0)==2 and {tuple(c['quantum']) for c in original0}=={('LM','CM'),('LM','aM')}
 for root,ro,path in paths:
  r=cat['classes'][root];response='Hu' if r['owner']=='R_F1' else 'Hg' if r['owner']=='R_Fu0_1' else None;assert response
  candidates=[(at,i,o) for at,(i,o) in enumerate(path) if cat['classes'][i]['u' if response=='Hu' else 'g']==1];assert len(candidates)==1
  at,i,o=candidates[0];cl=cat['classes'][i];assert cl['owner']==('GF_probe1' if response=='Hu' else 'GF_original')
  assert all(cat['classes'][j]['g']==cat['classes'][j]['u']==0 for j,oo in path if j!=i)
  mapped.append(dict(path=[root,ro,path],response=response,unique_insertion_position=at,ordinary_class=i))
 counts=dict(Counter(row['response'] for row in mapped));assert counts=={'Hu':44,'Hg':28}
 q=s.Matrix(s.symbols('q0:4',real=True));q2=(q.T*q)[0];om=s.Symbol('Omega');ff=s.Symbol('F');G=(s.eye(4)/q2+(om-1)*q*q.T/q2**2).row_join(-q/q2).col_join((q.T/q2).row_join(s.zeros(1,1)))*ff;W=(-q.T).row_join(s.Matrix([[om/2]]));Wp=q.col_join(s.Matrix([[om/2]]));eL=s.Matrix([0,0,0,0,1]);cov=s.simplify((W*G*Wp)[0]);mean=s.simplify((W*G*eL)[0]);assert cov==0 and mean==ff and G[4,4]==0
 badW=(-q.T).row_join(s.Matrix([[om]]));badWp=q.col_join(s.Matrix([[om]]));bad=s.simplify((badW*G*badWp)[0]);assert bad!=0
 symbolic=dict(W=str(W),G=str(G),W_opposite_transpose=str(Wp),Z_covariance=str(cov),Z_Lambda_covariance=str(mean),wrong_half_covariance=str(bad))
 old=O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1';ref=a.load(old/'gaussian_tables.json.gz')['cases'][0];D,F,H,Hreg,Gfree,RR=f.free(ref);results=[];evidence=[]
 for name in ['finite_aCC_A.json.gz','finite_aCC_B.json.gz','finite_aCC_H_A.json.gz','finite_aCC_H_B.json.gz','finite_aCC_M_A.json.gz','finite_aCC_M_B.json.gz']:
  z=a.load(O/name);V=dm(z['interaction_hessian']);N=mg(V,0,0);Hg=mg(V,1,0);Hu=mg(V,0,1);T=a.mm(Gfree,N);T2=a.mm(T,T);assert not a.mm(T2,T),'ACTUAL_G0_CUBIC_NILPOTENCE_FAILED'
  base=a.ma(Gfree,a.ms(a.mm(T,Gfree),J.constant(-1)),a.mm(T2,Gfree));fresh,st=a.inverse_from_base(Gfree,N,range(f.TOTAL));assert base==fresh
  ghosts=set(range(f.NB,f.TOTAL));assert a.block(base,ghosts,ghosts)==a.block(Gfree,ghosts,ghosts)
  Gu=a.ms(a.mm(a.mm(base,Hu),base),J.constant(-1));Gg=a.ms(a.mm(a.mm(base,Hg),base),J.constant(-1));whole=dm(z['normalized_covariance']);assert Gu==mg(whole,0,1) and Gg==mg(whole,1,0)
  roots={k:dp(p) for k,p in z['root_polynomials'].items()};left=a.observe(roots['F1'],Gu,f.NB);right=a.observe(roots['Fu0_1'],Gg,f.NB);cur=grade(a.ea(left,right),1,1);expected=grade(a.decode_e(z['whole_current']),1,1);assert cur==expected
  evidence.append(dict(source=name,source_sha256=a.digest(O/name),closed_Gbase=a.encode_m(base),Gu=a.encode_m(Gu),Gg=a.encode_m(Gg),F1_response=a.encode_e(left),Fu0_response=a.encode_e(right),whole_g1_u1=a.encode_e(cur),omit_Hu_difference=a.encode_e(a.es(left,J.constant(-1))),omit_Hg_difference=a.encode_e(a.es(right,J.constant(-1))),full_inverse_responses_equal=True))
  row=dict(source=name,all_g1_u1_exterior_coefficients_match=True,nonzero_target=A.encode_coeff(cur.get((1,7),a.zero)),g0_covariance_cubic_chain_zero=True);results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 art=a.save('response_tables.json.gz',dict(actual_original_g0_M_nonminimal_classes=original0,complete72_path_response_map=mapped,counts=counts,symbolic_free_boson_identities=symbolic,finite_cases=evidence))
 result=dict(schema='ACTUAL_ACC_TWO_RESPONSE_OPERATOR_REDUCTION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',actual_path_counts=counts,all72_paths_mapped=True,cases=results,artifact=art,full_target_formal_operator_reduction_supported=True,continuum_aCC_amplitude_not_calculated=True,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'response_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
