from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-nonminimal-resolvent-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
for n,h in json.loads((O/'preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'adapter_result.json').read_bytes())['execution_state']=='COMPLETED'
names=['calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/'+n for n in ['native_inputs.json.gz','replay_inputs.json.gz']]+['calculations/canonical_so10_ghost_source_companion_catalog_g1_v1/'+n for n in ['native_aCC_catalog.json.gz','replay_aCC_catalog.json.gz']]+['calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/replay_GF_common.json.gz','calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/replay_route_densities.json.gz','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py']
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['FINITE_ACC_RECORD.md','finite_acc.py','run_finite.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'finite_preparation.json',dict(sha256={**json.loads((O/'preparation.json').read_bytes())['sha256'],**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'finite_acc.py')]);dump(O/'finite_capture.json',cap);dump(C/'finite_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
