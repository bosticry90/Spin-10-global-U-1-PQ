from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-nonminimal-resolvent-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
for n,h in json.loads((O/'finite_additional_preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
for tail in ['','_H','_M']:assert json.loads((O/('finite_result'+tail+'.json')).read_bytes())['execution_state']=='COMPLETED'
for n in ['RESPONSE_RECORD.md','response.py','run_response.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
deps=[R/'calculations/canonical_so10_aCC_operator_reduction_g1_v1'/n for n in ['ward_tables.json.gz','validation_receipt.json']]
dump(O/'response_preparation.json',dict(sha256={**json.loads((O/'finite_additional_preparation.json').read_bytes())['sha256'],**{p.relative_to(R).as_posix():digest(p) for p in deps},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'response.py')]);dump(O/'response_capture.json',cap);dump(C/'response_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
