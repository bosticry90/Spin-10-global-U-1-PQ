from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('actual_ordered_gaussian_reference',O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1/gaussian.py');b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
J=b.J;A=b.A;one=J.constant(1);zero=J.ZERO
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def trim(c):return J.Coeff([(k,v) for k,v in c.terms if k[0]<=1])
def ec(P):return {k:c for k,c in P.items() if c}
def ea(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=out.get(k,zero)+c
 return ec(out)
def es(P,c):return ec({k:J.times(v,c) for k,v in P.items()})
def em(P,Q):
 out={}
 for (u,m),c in P.items():
  for (v,n),d in Q.items():
   if u+v>1 or m&n:continue
   k=u+v,m|n;out[k]=out.get(k,zero)+trim(J.times(c,d))*b.esign(m,n)
 return ec(out)
unit={(0,0):one}
def encode_e(P):return [[u,m,A.encode_coeff(c)] for (u,m),c in sorted(P.items())]
def decode_e(rows):return {(u,m):A.decode_coeff(c) for u,m,c in rows}
def ma(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=ea(out.get(k,{}),c)
 return {k:c for k,c in out.items() if c}
def ms(P,c):return {k:es(v,c) for k,v in P.items() if es(v,c)}
def mm(P,Q):
 by=defaultdict(list);out={}
 for (k,j),c in Q.items():by[k].append((j,c))
 for (i,k),c in P.items():
  for j,d in by.get(k,[]):
   z=em(c,d)
   if z:out[i,j]=ea(out.get((i,j),{}),z)
 return {k:c for k,c in out.items() if c}
def ident(ids):return {(i,i):unit for i in ids}
def encode_m(P):return [[i,j,encode_e(c)] for (i,j),c in sorted(P.items())]
def inverse_from_base(G0,V,ids):
 ident0=ident(ids);term=G0;out=G0;stages=[];GV=ms(mm(G0,V),J.constant(-1))
 for n in range(1,7):
  term=mm(GV,term);stages.append([n,len(term)])
  if not term:return out,stages
  out=ma(out,term)
 raise AssertionError('NON_NILPOTENT_INVERSE_EXPANSION')
def poly_decode(rows):return {(0,mask,tuple(bb),tuple(gg)):A.decode_coeff(c) for mask,bb,gg,c in rows}
def pc(P):return {k:c for k,c in P.items() if c}
def pa(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=out.get(k,zero)+c
 return pc(out)
def ps(P,c):return pc({k:J.times(v,c) for k,v in P.items()})
def pm(P,Q):
 out={}
 for (u,m,bb,gg),c in P.items():
  for (v,n,dd,hh),d in Q.items():
   if u+v>1 or m&n:continue
   ghost,sg=b.canon(gg+hh)
   if not sg:continue
   k=u+v,m|n,tuple(sorted(bb+dd)),ghost;sg*=b.esign(m,n)*((-1)**(len(gg)*n.bit_count()));out[k]=out.get(k,zero)+trim(J.times(c,d))*sg
 return pc(out)
def pd(P,i,nb,wrong=False):
 out={}
 for (u,m,bb,gg),c in P.items():
  if i<nb:
   n=bb.count(i)
   if not n:continue
   qq=list(bb);qq.remove(i);k=u,m,tuple(qq),gg;out[k]=out.get(k,zero)+c*n
  else:
   at=i-nb
   if at not in gg:continue
   j=gg.index(at);k=u,m,bb,gg[:j]+gg[j+1:];sg=(-1)**(j+(0 if wrong else m.bit_count()));out[k]=out.get(k,zero)+c*sg
 return pc(out)
def pv(i,nb):return {(0,0,(i,),()):one} if i<nb else {(0,0,(),(i-nb,)):one}
def hessian(P,nb,total,wrong=False):
 out={};reconstruction={}
 for i in range(total):
  E=pd(P,i,nb,wrong);reconstruction=pa(reconstruction,pm(pv(i,nb),E))
  for (u,m,bb,gg),c in E.items():
   assert len(bb)+len(gg)==1
   j=bb[0] if bb else nb+gg[0];out[i,j]=ea(out.get((i,j),{}),{(u,m):c})
 if not wrong:assert ps(reconstruction,J.constant(F(1,2)))==P,'QUADRATIC_LEFT_EULER_RECONSTRUCTION'
 return out
def observe(P,G,nb):
 out={}
 for (u,m,bb,gg),c in P.items():
  assert len(bb)+len(gg)==2
  ids=list(bb)+[nb+i for i in gg];out=ea(out,em({(u,m):c},G.get(tuple(ids),{})))
 return out
def block(P,left,right):return {k:c for k,c in P.items() if k[0] in left and k[1] in right}
def schur(G0,V,nb,total):
 B=set(range(nb));F=set(range(nb,total));bb=block(V,B,B);bg=block(V,B,F);gb=block(V,F,B);gg=block(V,F,F);gb0=block(G0,B,B);gf0=block(G0,F,F)
 bi,bs=inverse_from_base(gb0,bb,B);eff=ma(gg,ms(mm(mm(gb,bi),bg),J.constant(-1)));fi,fs=inverse_from_base(gf0,eff,F)
 bif=ms(mm(mm(bi,bg),fi),J.constant(-1));fib=ms(mm(mm(fi,gb),bi),J.constant(-1));bib=ma(bi,mm(mm(mm(mm(bi,bg),fi),gb),bi));return ma(bib,bif,fib,fi),dict(boson=bs,ghost=fs,effective=encode_m(eff))
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 old=O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1';data=load(old/'gaussian_tables.json.gz');own=read(old/'gaussian_result.json');assert digest(old/own['artifact']['file'])==own['artifact']['sha256'];results=[];evidence=[]
 for case in data['cases']:
  N=12;nb=2*N;total=4*N;G0={}
  for i,j,c in case['free_boson_covariance']:G0[i,j]={(0,0):A.decode_coeff(c)}
  for i,j,c in case['free_ordered_Ca_covariance']:G0[nb+i,nb+N+j]={(0,0):A.decode_coeff(c)};G0[nb+N+j,nb+i]={(0,0):-A.decode_coeff(c)}
  # Exact G0 inverse from the frozen free matrices: extract symbols rather
  # than impose a new covariance convention.
  import sympy as s
  x=s.Symbol('xi',real=True);K=s.sympify(case['K']);D=s.sympify(case['D']);Fmat=s.sympify(case['F']);ik=K*Fmat.inv();idf=D*Fmat.inv();A0={}
  def coeff(v):return A.co(str(v))
  for color in range(3):
   for u in range(4):
    for v in range(4):
     i,j=color*4+u,color*4+v
     for ii,jj,val in [(i,N+j,-s.I*idf[u,v]),(N+i,j,s.I*idf[u,v]),(N+i,N+j,x*Fmat.inv()[u,v]),(nb+i,nb+N+j,-ik[v,u]),(nb+N+i,nb+j,ik[u,v])]:
      if val:A0[ii,jj]={(0,0):coeff(val)}
  assert mm(A0,G0)==mm(G0,A0)==ident(range(total))
  Vpoly=pa(poly_decode(case['VL']),poly_decode(case['VJ']));V=hessian(Vpoly,nb,total);G,st=inverse_from_base(G0,V,range(total));AA=ma(A0,V);assert mm(AA,G)==mm(G,AA)==ident(range(total))
  for (i,j),val in G.items():assert val==es(G.get((j,i),{}),J.constant((-1)**(int(i>=nb)*int(j>=nb))))
  GS,sch=schur(G0,V,nb,total);assert G==GS
  root=poly_decode(case['CR_observable']);current=observe(root,G,nb);expected={(0,mask):A.decode_coeff(c) for mask,c in case['CR']};assert current==expected and current.get((0,7)),'ACTUAL_JBCC_SIGN_REFERENCE_MISMATCH'
  badV=hessian(Vpoly,nb,total,True);badG,_=inverse_from_base(G0,badV,range(total));bad=observe(root,badG,nb);difference=ea(bad,es(current,J.constant(-1)))
  evidence.append(dict(profile=case['profile'],actual_quadratic_interaction_hessian=encode_m(V),ordered_covariance=encode_m(G),Neumann_stages=st,Schur=sch,CR=encode_e(current),wrong_external_crossing_CR=encode_e(bad),wrong_external_crossing_difference=encode_e(difference),both_inverse_sides_and_graded_symmetry=True,whole_saved_Wick_and_Schur_CR_matched=True))
  row=dict(profile=case['profile'],covariance_entries=len(G),nonzero_target=A.encode_coeff(current[(0,7)]),wrong_external_derivative_changed_positions=len(difference));results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 art=save('adapter_tables.json.gz',dict(schema='ACTUAL_NORMALIZED_SUPER_HESSIAN_SIGN_ADAPTER_V1',cases=evidence,old_literal_Berezin_reference_reused_not_replayed=True))
 result=dict(schema='ACTUAL_NONMINIMAL_RESOLVENT_SIGN_ADAPTER_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=results,artifact=art,all_ordered_inverse_Schur_and_saved_normalized_Wick_equal=True,aCC_coefficients_not_yet_calculated=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'adapter_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
