# V981 · Affine profile regulator

The fixed-flat background and geometric proper
regulator response is the paired trace of
`G(M^t R+RM)/2`. A local H parameter gives a
nonzero ghost commutator even though its color
action preserves the quartet sector.

One left marked derivative replaces G by
`−G H_K G` in that response. The geometric
equation keeps both covariance directions and
the direct transport of K. The difference of
two profiles follows from the same relative
functional on the admitted proper domain.

Both exports verify the signed actual ghost
pair and the factor `1−F` on its contracted
edge. A finite trace fixture checks the affine
and marked signs. No new complete regulator
amplitude or covariant cutoff is claimed.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
