# Fixed-flat affine regulator transport on the marked proper parent

Keep the V869/V870 affine operations T_b and T_q
in their admitted proper compact domain. Write H
for the ordinary Hessian of P, M for the even
homogeneous ordinary-field part of T, and R_ell
for the fixed-flat quadratic cutoff. The reference,
source transformations and local parameter labels
are those of the same parent. The affine part has
zero second ordinary derivative. The source and
background variation is retained in T P. Hence

    T H = H_(T P) - M^t H - H M.

The transpose here is the ordered evaluation dual.
It includes the Lorentz and ghost pairing already
qualified in V869. Write G=(H+R_ell)^-1 as its
ordered finite Born coefficients and N_ell for the
relative Gaussian one-loop log. Its proper insertion
of U is I_U=(1/2) STr(G H_U), with the common
Euclidean phase. The regulated trace before finite
parts gives

    T N_ell - I_(T P)
      = (1/2) STr G (M^t R_ell + R_ell M).

In deriving this, the unit terms give
-STr(M^t+M)/2 and vanish by the actual
sector trace, not by regularizing an
unrestricted unit operator. The cutoff is
fixed as a flat kernel, so T has no separate
A derivative of R_ell. This does not set the
local commutator to zero. On an H- or M-color
ghost pair the Ca block is

    -[p²(F_ell(p)^-1-1)-q²(F_ell(q)^-1-1)] M(p-q).

The local parameter transfers momentum even
though its color preserves the sector. A
constant parameter is a blind control. The
paired trace reduces each R against its
adjacent free edge before any inverse-heat
interpretation. The ordered product
R_ell G_0,ell equals 1-F on the actual
gauge/ghost quartet. Thus the indicated
regulated Born comparisons retain their
ordinary heat factors and joint label
domain. No standalone inverse heat map
or cyclicity of an unsubtracted finite
four-dimensional trace is used.
At one left rho let H_K be the Hessian of
the actual switched mark. With T even and
M independent of rho, the ordered inverse
derivative is -G H_K G. The marked
regulator coefficient is consequently

    - (1/2) STr G H_K G (M^t R_ell+R_ell M).

The actual T K includes epsilon transport.
For T_q the source translation C has the
fixed-source insertion rule and C K=0.
Writing G_sigma=(T_q+C)P, the marked
geometric equation therefore keeps

    T_q I_K + V(K,CP) - I_(T_q K)
                       - V(K,G_sigma)

equal to the displayed marked regulator
coefficient. These are the two ordered
covariance directions and the direct
transport of K. The original reference
and switch currents are inside G_sigma.
This regulator differs from the auxiliary
marked covariance of V845/V979.

Subtract two profiles on the same parent.
Before cutoff removal their affine
regulator difference is
T Delta N - I_(T P)^(Delta N). The same
holds for its admitted marked derivative.
After the common ordered finite parts
this derives the relative finite
regulator contact from V977/V978, with
the pure reference part retained once.
It does not equate either raw regulator
response to zero. The formula uses a
fixed-flat cutoff. A background-dependent
cutoff would add its own ordered
T^A R derivative.

The code checks actual ghost Ca/aC and
local H rotation rows on both exports.
A finite two-momentum block with the
actual rotation entry tests the trace
and its marked inverse derivative.
That fixture checks the sign and
covariance, not a new loop amplitude.
The domain stays that of the inherited
single marked proper coefficients.
Both routes share the action and software.
