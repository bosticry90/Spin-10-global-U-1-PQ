"""Check the fixed-flat affine regulator commutator and marked derivative."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def actual(phase):
    base = ROOT / "calculations/canonical_so10_current_background_reference_bridge_v1"
    parent = json.loads((base/"result_a.json").read_bytes())["compared"]
    rows = parent["twelve_current_homogeneous_carriers"]
    assert all(i!=j for R in rows for i,j,_ in R)
    h = {(i,j):sp.sympify(z) for i,j,z in rows[1]}
    m = h[553,555]
    assert m == -sp.sqrt(10)/4 and h[598,600]==m
    assert h[555,553]==h[600,598]==-m

    base = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(base/f"{phase}_inverse.json.gz") as stream:
        data = json.load(stream)
    q = sp.symbols("q0:4")
    Q = sum(k*k for k in q)
    E,f = sp.symbols("E_profile f_profile")
    F = E*f
    for i,j,sgn in ((553,598,-1),(598,553,1),(555,600,-1),(600,555,1)):
        physical = {(a,b):z for a,b,z in data["Pphysical"]}
        regulated = {(a,b):z for a,b,z in data["full_regulator"]}
        edge = {(a,b):z for a,b,z in data["G_F"]}
        assert sp.sympify(physical[i,j])==sgn*Q
        R = sp.sympify(regulated[i,j])
        assert sp.cancel(R-sgn*Q*(1/F-1))==0
        assert sp.cancel(R*sp.sympify(edge[j,i])-(1-F))==0
    return m


def fixture(m):
    A = sp.Matrix([[0,m],[-m,0]])
    Z = sp.zeros(2)
    M = Z.row_join(A).col_join(A.row_join(Z))
    U = Z.row_join(A).col_join((-A).row_join(Z))
    H0 = sp.diag(1,1,4,4)
    H = H0+U/5
    assert M.T == -M and U.T == U

    def profile(power):
        return (1-sp.Rational(1,2)**power)**2

    responses = []
    for dilation in (1,2):
        Fq = sp.Rational(1,2)**dilation*profile(1)
        Fp = sp.Rational(1,2)**(4*dilation)*profile(4)
        Rq = 1/Fq-1
        Rp = 4*(1/Fp-1)
        R = sp.diag(Rq,Rq,Rp,Rp)
        congruence = M.T*R+R*M
        assert congruence[:2,2:] == (Rq-Rp)*A
        assert (sp.eye(4)*Rq)*M-M*(sp.eye(4)*Rq)==sp.zeros(4)
        assert congruence != sp.zeros(4)
        G = (H+R).inv()
        derivative = -G*U*G
        shift = M*H-H*M
        # One paired ghost determinant has one minus scalar trace.
        left = -sp.trace(G*shift)
        right = -sp.trace(G*congruence)
        d_left = -sp.trace(derivative*shift+G*(M*U-U*M))
        d_right = -sp.trace(derivative*congruence)
        assert sp.simplify(left-right)==0 and sp.simplify(d_left-d_right)==0
        assert sp.simplify(right)!=0 and sp.simplify(d_right)!=0
        responses.append((sp.simplify(right),sp.simplify(d_right)))
    assert responses[0]!=responses[1]


def check(phase):
    m = actual(phase)
    fixture(m)
    return {"actual_light_rotation":"-sqrt(10)/4",
            "paired_cutoff_factor":"1-F",
            "local_parameter_commutator_nonzero":True,
            "constant_parameter_control_zero":True,
            "affine_regulator_trace_and_marked_derivative_agree":True,
            "relative_profile_fixture_nonzero":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
