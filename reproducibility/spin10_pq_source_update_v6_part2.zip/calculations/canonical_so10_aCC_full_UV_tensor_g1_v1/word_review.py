from pathlib import Path
from functools import lru_cache
from itertools import combinations
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('word_review_generic_ring',Path(__file__).resolve().with_name('generic_ring.py'));r=importlib.util.module_from_spec(sp);sp.loader.exec_module(r);R=r.R;O=r.O;J=r.J
@lru_cache(None)
def bits(m):
 out=[]
 while m:bit=m&-m;out.append(bit.bit_length()-1);m^=bit
 return tuple(out)
def word_sign(word):return -1 if sum(a>b for i,a in enumerate(word) for b in word[i+1:])%2 else 1
def targetmask(m):return(m&r.C_MASK).bit_count()==2 and(m&r.A_MASK).bit_count()==1
def triple_trace(L,H,G):
 by={}
 for (a,b),p in H.items():by.setdefault(a,[]).append((b,p))
 grouped={}
 for ij,P in G.items():
  groups={}
  for k,c in P.items():groups.setdefault(k[1].bit_count(),[]).append((k,c))
  grouped[ij]=groups
 out={};wrong={};closed=retained=0
 for (j,a),lp in L.items():
  for b,hp in by.get(a,[]):
   gp=G.get((b,j))
   if not gp:continue
   closed+=1
   for (ul,ml,ql,el),cl in lp.items():
    bl=bits(ml)
    for (uh,mh,qh,eh),ch in hp.items():
     if ul+uh>1 or ml&mh:continue
     mm=ml|mh
     if not r.admissible(mm):continue
     bh=bits(mh)
     for (ug,mg,qg,eg),cg in grouped[b,j].get(3-mm.bit_count(),[]):
      if ul+uh+ug!=1 or mm&mg:continue
      union=mm|mg
      if not targetmask(union):continue
      bg=bits(mg);sg=-word_sign(bl+bh+bg);badsg=-word_sign(bh+bl+bg);key=1,union,ql+qh+qg,el+eh+eg;value=r.trim(J.times(J.times(cl,ch),cg));retained+=1
      out[key]=out.get(key,J.ZERO)+value*sg;wrong[key]=wrong.get(key,J.ZERO)+value*badsg
 return r.clean(out),r.clean(wrong),dict(closed_matrix_triples=closed,retained_Laurent_word_triples=retained)
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in r.read(O/'word_preparation.json')['sha256'].items():assert r.digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'DEPENDENT_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 basis=[0]+[1<<n for n in range(90)]+[(1<<c)|(1<<d) for c,d in combinations(range(45),2)]+[(1<<c)|(1<<(45+a)) for c in range(45) for a in range(45)]+[(1<<c)|(1<<d)|(1<<(45+a)) for c,d in combinations(range(45),2) for a in range(45)];assert len(basis)==len(set(basis))==47656;pairs=0;wrong3=[]
 for union in basis:
  word=bits(union)
  for subset in range(1<<len(word)):
   left=sum(1<<n for at,n in enumerate(word) if subset&(1<<at));right=union^left;sg=word_sign(bits(left)+bits(right));actual=r.mul(r.term(m=left),r.term(m=right));assert actual==r.term(J.constant(sg),m=union);pairs+=1
   old=-1 if sum((right&((1<<i)-1)).bit_count() for i in range(3) if left&(1<<i))%2 else 1
   if old!=sg:wrong3.append([hex(union),hex(left),hex(right),old,sg])
 assert pairs==368641 and wrong3
 for n in range(90):assert not r.mul(r.term(m=1<<n),r.term(m=1<<n))
 artbasis=r.save('word_basis_tables.json.gz',dict(all47656_basis_masks=[hex(n) for n in basis],all_nonzero_basis_products_checked=pairs,every_left_right_partition_checked=True,all_repeated_generator_squares_zero=True,wrong_legacy_three_bit_sign_complete_failures=wrong3));print('STAGE exhaustive_word_products '+str(pairs)+' wrong_three_bit='+str(len(wrong3)),flush=True)
 cr=r.read(O/'contraction_result_v2.json');base=r.load(O/cr['base_artifact']['file']);G=r.dm(base['Gbase']);compiled=r.load(O/r.read(O/'compile_result.json')['artifact']['file']);M={k:r.dm(v) for k,v in compiled['matrices'].items()};results=[];whole={}
 for row in cr['branches']:
  assert r.digest(O/row['artifact']['file'])==row['artifact']['sha256'];z=r.load(O/row['artifact']['file']);L=r.dm(z['left_K_indexT_Gbase']);actual,wrong,counts=triple_trace(L,M[z['insertion']],G);saved=r.dec(z['selected_aCC_symbol']);assert actual==saved,('EXPLICIT_WORD_REASSOCIATED_TRACE_MISMATCH',row['branch']);whole=r.add(whole,actual)
  art=r.save('word_branch_'+row['branch']+'.json.gz',dict(branch=row['branch'],explicit_word_target=r.enc(actual),wrong_L_H_coefficient_order_target=r.enc(wrong),wrong_order_difference=r.enc(r.add(wrong,r.scale(actual,J.constant(-1)))),all_full_q_profile_coefficients_equal=True,counts=counts));results.append(dict(branch=row['branch'],counts=counts,artifact=art));print('STAGE '+json.dumps(results[-1],sort_keys=True),flush=True)
 tensor=r.load(O/cr['artifact']['file']);assert whole==r.dec(tensor['full_aCC_symbol'])
 out=dict(schema='FULL_COLOR_ACC_EXHAUSTIVE_WORD_AND_REASSOCIATED_TRACE_REVIEW_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all47656_quotient_basis_monomials=True,all368641_nonzero_basis_products_literal_word_equal=True,wrong_legacy_three_bit_failures=len(wrong3),basis_artifact=artbasis,branches=results,full_tensor_scalar_polynomial_equal_at_all_profiles=True,prediction_inputs_denied=True,shared_L_matrix_and_existing_coefficient_ring_disclosed=True,generic_UV_domain_and_late_comparison_still_pending=True,elapsed_after_imports=time.perf_counter()-tick)
 r.dump(O/'word_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
