from pathlib import Path
import importlib.util,json,os,sys,threading,time
import sympy as sy
def mod(n,p):
 s=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(s);s.loader.exec_module(z);return z
O=Path(__file__).resolve().parent;R=O.parents[1];r=mod('generic_rotation_ring',O/'generic_ring.py');prior=mod('frozen_rotation_pure_functions',O.parent/'canonical_so10_aCC_direct_UV_symbol_g1_v1/rotation_uv.py');prior.r=r;J=r.J;w=r.w
def encode(M):return [[i,j,[[u,hex(m),list(q),r.A.encode_coeff(c)] for(u,m,q),c in sorted(P.items())]] for(i,j),P in sorted(M.items())]
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in r.read(O/'rotation_preparation.json')['sha256'].items():assert r.digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'DEPENDENT_PREDICTION_READ_DENIED'
 sys.addaudithook(guard)
 pk=r.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');states={k:{n:J.decode(p) for n,p in rows} for k,rows in pk['states'].items()};phys={k:{n:J.decode(p) for n,p in rows} for k,rows in pk['physical'].items()};compiled=r.load(O/r.read(O/'compile_result.json')['artifact']['file']);matrices={};checks=[];stats={};assert all(J.dimension(n)==1 for n in r.MEANS)
 for label in ['E0','E1','Eu0_1','F0','F1','Fu0_1','Fu1_1']:
  M={};u=int('u0' in label or 'u1' in label)
  for i,n in enumerate(r.FIELDS):
   P=states[label][n]
   if label=='E0' and n<508:P=w.plus(P,phys['P_E0'].get(n,{}))
   if label=='E1' and n<180:P=w.plus(P,phys['P_E1_gauge'].get(n,{}),phys['P_E1_scalar'].get(n,{}))
   P={ww:c for ww,c in P.items() if all(nn<643 for nn,js in ww)}
   for j,p in prior.first4(P,r.MEANS,u).items():M[i,j]=p
  axial={};maxdegree=0
  for(i,j),P in M.items():
   for(u,m,q),c in P.items():
    assert r.admissible(m) and m.bit_length()<=90
    if not any(q[1:]):axial.setdefault((i,j),{})[u,m,q[0],0]=c
    di,dj=J.dimension(r.FIELDS[i]),J.dimension(r.FIELDS[j]);assert(di+dj+m.bit_count()+sum(q)==4)if label.startswith('E')else(dj+m.bit_count()+sum(q)==di+1),(label,'CANONICAL_DIMENSION_MISMATCH');maxdegree=max(maxdegree,sum(q))
  assert axial==r.dm(compiled['matrices'][label]),('GENERIC_FULL_Q_AXIAL_MISMATCH',label)
  for a in range(4):
   for b in range(a+1,4):
    residual=prior.rotation(M,a,b);assert not residual,(label,a,b,'FULL_GENERIC_ROTATION_RESIDUAL');checks.append(dict(state=label,plane=[a,b],residual=[]))
  matrices[label]=M;stats[label]=dict(matrix_entries=len(M),q_exterior_terms=sum(len(P)for P in M.values()),max_q_degree=maxdegree);print('STAGE '+label+' '+json.dumps(stats[label],sort_keys=True),flush=True)
 bad={ij:p for ij,p in matrices['F0'].items() if not(r.FIELDS[ij[0]]<180 and r.FIELDS[ij[0]]%4==3)};badres=prior.rotation(bad,0,3);assert badres
 cr=r.read(O/'contraction_result_v2.json');tensor=r.load(O/cr['artifact']['file']);x=sy.Symbol('x',positive=True);moments=[]
 for n in cr['profile_powers']:
  assert n>0;exact=sy.integrate(sy.exp(-n*x),(x,0,sy.oo));assert exact==sy.Rational(1,n);moments.append(dict(profile_power=n,integral=str(exact)))
 rows=tensor['all44550_rows'];assert len(rows)==44550 and len({(q['a'],q['C_first'],q['C_second'])for q in rows})==44550
 assert all(0<=q['a']<45 and 0<=q['C_first']<q['C_second']<45 and int(q['mask'],16)==(1<<q['C_first'])|(1<<q['C_second'])|(1<<(45+q['a']))for q in rows)
 art=r.save('generic_rotation_tables.json.gz',dict(full_q_matrices={k:encode(v)for k,v in matrices.items()},all42_generator_residuals=checks,wrong_vector_component_residual=encode(badres),statistics=stats,exact_radial_moments=moments,all44550_row_domain_and_hex_masks_checked=True,written_proof='GENERIC_UV_PROOF.md'))
 out=dict(schema='FULL_COLOR_ACC_GENERIC_ROTATION_DIMENSION_UV_DOMAIN_REVIEW_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all42_full_generic_matrix_generator_checks_zero=True,all90_mean_dimensions_and_complete_canonical_matrix_types=True,all_full_q_axial_coefficients_equal=True,wrong_vector_component_nonzero_entries=len(badres),all44550_local_tensor_rows_and_zero_complement_domain_checked=True,written_UV_Taylor_fixed_IR_proof_reused_with_new_generic_covariance=True,not_Lean_certified_or_finite_reference_claim=True,prediction_inputs_denied=True,statistics=stats,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 r.dump(O/'rotation_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
