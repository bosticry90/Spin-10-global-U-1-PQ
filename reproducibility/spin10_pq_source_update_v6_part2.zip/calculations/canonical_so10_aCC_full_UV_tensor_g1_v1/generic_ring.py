from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Fr
from collections import defaultdict
import gzip,importlib.util,json
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('direct_UV_actual_tools',O.parent/'canonical_so10_g0_scalar_source_independence_v1/source_audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
J=a.J;w=a.w;A=a.A;read=a.read;load=a.load;digest=a.digest;one=J.constant(1);zero=J.ZERO
IC=list(range(12,45));FIELDS=[4*r+mu for r in IC for mu in range(4)]+[508+r for r in IC]+[553+r for r in IC]+[598+r for r in IC];INDEX={n:i for i,n in enumerate(FIELDS)};NB=165;TOTAL=231
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
C_MASK=(1<<45)-1;A_MASK=C_MASK<<45
MEANS={**{553+c:c for c in range(45)},**{598+c:45+c for c in range(45)}}
def admissible(m):return (m&C_MASK).bit_count()<=2 and (m&A_MASK).bit_count()<=1
def esign(m,n):
 count=0
 while m:
  bit=m&-m;count+=(n&(bit-1)).bit_count();m^=bit
 return -1 if count%2 else 1
def clean(P):return {k:c for k,c in P.items() if c}
def add(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=out.get(k,zero)+c
 return clean(out)
def scale(P,c):return clean({k:J.times(v,c) for k,v in P.items()})
def trim(c):return J.Coeff([(k,v) for k,v in c.terms if k[0]<=1])
def mul(P,Q):
 out={}
 for (u,m,q,e),c in P.items():
  for (v,n,r,f),d in Q.items():
   if u+v>1 or m&n or not admissible(m|n):continue
   k=u+v,m|n,q+r,e+f;out[k]=out.get(k,zero)+trim(J.times(c,d))*esign(m,n)
 return clean(out)
def term(c=one,q=0,e=0,u=0,m=0):return {(u,m,q,e):c} if c else {}
UNIT=term()
def flip(P):return {k:c*(-1 if k[2]%2 else 1) for k,c in P.items()}
def ma(*ps):
 out={}
 for p in ps:
  for k,c in p.items():out[k]=add(out.get(k,{}),c)
 return {k:c for k,c in out.items() if c}
def ms(P,c):return {k:scale(v,c) for k,v in P.items() if scale(v,c)}
def mm(P,Q):
 by=defaultdict(list);out={}
 for (k,j),c in Q.items():by[k].append((j,c))
 for (i,k),c in P.items():
  for j,d in by.get(k,[]):
   z=mul(c,d)
   if z:out[i,j]=add(out.get((i,j),{}),z)
 return {k:c for k,c in out.items() if c}
def ident(ids):return {(i,i):UNIT for i in ids}
def enc(P):return [[u,hex(m),q,e,A.encode_coeff(c)] for (u,m,q,e),c in sorted(P.items())]
def dec(P):return {(u,int(m,16) if isinstance(m,str) else m,q,e):A.decode_coeff(c) for u,m,q,e,c in P}
def em(P):return [[i,j,enc(c)] for (i,j),c in sorted(P.items())]
def dm(P):return {(i,j):dec(c) for i,j,c in P}
def mh(P):return sha256(json.dumps(em(P),sort_keys=True).encode()).hexdigest()
def free():
 xi=J.Coeff([((0,1,0,0),Fr(1))]);H={};G={}
 for c in IC:
  b=[INDEX[4*c+mu] for mu in range(4)];ll=INDEX[508+c];cc=INDEX[553+c];aa=INDEX[598+c]
  H[b[0],ll]=term(q=1);H[ll,b[0]]=term(-one,q=1);H[ll,ll]=term(xi);H[cc,aa]=term(-one,q=2);H[aa,cc]=term(q=2)
  G[b[0],b[0]]=term(xi,q=-2,e=1);G[b[0],ll]=term(-one,q=-1,e=1);G[ll,b[0]]=term(q=-1,e=1);G[cc,aa]=term(q=-2,e=1);G[aa,cc]=term(-one,q=-2,e=1)
  for i in b[1:]:H[i,i]=term(q=2);G[i,i]=term(q=-2,e=1)
 Rreg={k:mul(c,add(term(e=-1),term(-one))) for k,c in H.items()};Hreg=ma(H,Rreg)
 assert mm(Hreg,G)==mm(G,Hreg)==ident(range(TOTAL))
 return H,G,Rreg
def background(word,means):
 m=0;sg=1
 for n,js in word:
  if js or n not in means:return None
  bit=1<<means[n]
  if m&bit:return None
  sg*=esign(m,bit);m|=bit
 return (m,sg) if admissible(m) else None
def phase(c,jets,opposite=False):
 for _ in jets:c=J.times(c,-J.I if opposite else J.I)
 return c
def first(P,means,u=0,wrong=False):
 out={};positions=[];tokens=set()
 for at,(ww,c) in enumerate(sorted(P.items())):
  chosen=[]
  for pos,(n,js) in enumerate(ww):
   if n not in INDEX or any(mu!=0 for mu in js):continue
   rest=ww[:pos]+ww[pos+1:];bg=background(rest,means)
   if bg is None:continue
   mask,sg=bg;cross=sum(J.parity(i) for i,jj in ww[pos+1:]);sg*=1 if wrong or not J.parity(n)*cross%2 else -1
   j=INDEX[n];out[j]=add(out.get(j,{}),term(phase(c,js)*sg,q=len(js),u=u,m=mask));chosen.append([pos,n,list(js)]);tokens.add((n,js))
  positions.append([at,chosen])
 out={k:c for k,c in out.items() if c}
 if not wrong:
  peer={}
  for n,js in sorted(tokens):
   for ww,c in J.leftjet(P,(n,js)).items():
    bg=background(ww,means)
    if bg is None:continue
    mask,sg=bg;sg*=(-1 if J.parity(n)*sum(J.parity(i) for i,jj in ww)%2 else 1);j=INDEX[n];peer[j]=add(peer.get(j,{}),term(phase(c,js)*sg,q=len(js),u=u,m=mask))
  assert out=={k:c for k,c in peer.items() if c},'PREFIX_LEFT_FIRST_SYMBOL_MISMATCH'
 return {k:c for k,c in out.items() if c},positions
def quadratic(raw,means,u=0):
 P=J.decode(raw);out={};journal=[]
 for at,(ww,c) in enumerate(sorted(P.items())):
  qs=[pos for pos,(n,js) in enumerate(ww) if 1319<=n<1962];chosen=[]
  if len(qs)!=2:journal.append([at,chosen]);continue
  pos1,pos2=qs;n1,j1=ww[pos1];n2,j2=ww[pos2];n1-=1319;n2-=1319
  rest=tuple(t for pos,t in enumerate(ww) if pos not in qs);bg=background(rest,means)
  if n1 not in INDEX or n2 not in INDEX or bg is None or any(mu!=0 for mu in j1+j2):journal.append([at,chosen]);continue
  for left,right in [(pos1,pos2),(pos2,pos1)]:
   nn,jj=ww[left];nk,jk=ww[right];nn-=1319;nk-=1319;mask,sg=bg;sg*=(-1 if J.parity(nn)*sum(J.parity(n) for n,js in ww[:left])%2 else 1)
   remaining=ww[:left]+ww[left+1:];newpos=right-int(right>left);sg*=(-1 if J.parity(nk)*sum(J.parity(n) for n,js in remaining[newpos+1:])%2 else 1)
   coef=phase(phase(c,jj,True),jk)*sg;k=INDEX[nn],INDEX[nk];out[k]=add(out.get(k,{}),term(coef,q=len(jj)+len(jk),u=u,m=mask));chosen.append([left,right,nn,nk])
  journal.append([at,chosen])
 return {k:c for k,c in out.items() if c},journal
