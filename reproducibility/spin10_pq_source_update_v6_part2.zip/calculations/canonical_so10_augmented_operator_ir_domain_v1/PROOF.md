# Selected augmented operator and joint infrared domain

This argument concerns the original unshifted Cartesian A0 field chart,
g<=1, first u in H or M, first rho and one constant-LEFT-beta breaking
insertion. Epsilon(x) is the actual local odd mark. All ordinary means and
BV sources are Schwartz test fields. u,rho,beta are constant bookkeeping
parameters, not additional external momentum transfers. The fixed selected
Euclidean reference, positive scalar reference masses, metric constructor
and finite-coefficient expansion are retained. No physical vacuum shift,
infinite-chain convergence, other actual regulator profile or full background
applicability is inferred.

Let z_i denote643 integrated coordinates, J_i their external sources and
Sigma=S+uU+rho K_D. Write F_i=(-1)^p_i Sigma_Ji, E_i=Sigma_zi and
B=sum_i F_i E_i, with the qualified LEFT Euler/source conventions. V849
establishes T²B/2=Q_Sigma(T²Sigma/2)+sum_i(TF_i)(TE_i) for arbitrary source
degree. In particular, beta B is ONE first-Q breaking insertion, rather than
two independently inserted Q tangents. The full source-Euler leg and ordinary
currents remain. A position-dependent beta would require additional currents.

## Label preservation and physical gradients

The complete six original/probe field maps have no literal constant without
a mean, source or epsilon label. Full source-Euler operations must also keep
labels. Known GF/source and physical kinetic Eulers are checked directly.
The unexpanded potential and g1 scalar Eulers are not assigned coefficients:
all34 actual physical AST terms have field arity at least2 in EVERY Add
branch. All29 potential terms contain only Phi,Sigma,SigmaBar,phi,phiBar,S,SBar
and no ordinary derivative. canonical_state maps the real carrier by E*x;
conjugate aliases are linear views of those same real coordinates. The
implemented328 scalar raw-to-current equations are constant homogeneous
linear substitutions. Thus every unshifted classical physical Euler retains
at least one mean label. This argument makes no claim about shifted-vacuum
or quantum tadpole constants, and leaves V832's unknowns intact.

Replacing a mean/source label by F/E therefore does not erase all external
labels. Qepsilon=0. The actual D field operation is the33 marked antighost
translations D a=epsilon; its integrated-field Frechet derivative and own-jet
Jacobian vanish directly. D's nonzero source operation is still retained.

## Zero-transfer vertices and all finite constant chains

Assign soft weights w_B=w_C=w_a=1 and w_Lambda=w_x=0. Direct reconstruction
of all1498 actual reference Green entries, including ordered ghost signs,
gives pole(G_ij)<=w_i+w_j. Longitudinal BB is degree-2 despite its p^-4
denominator; scalar reference masses are positive. No physical width or
physical mass matrix is inverted in this assertion.

Extract the COMPLETE graded Euler/Fourier kernel of every sourcefree
two-field density before testing soft order. Constant u does not supply a
label. For all S0,S1,U0,U1,K_D and known physical kinetic coefficients the
zero-transfer kernel V_jk has vanishing order at least w_j+w_k. Quadratic
physical potential terms are xx with order0 and weight0; higher physical
potential terms retain labels. No individual unsummed density word is used
as the kernel, because ordinary divergences and graded cancellations matter.

Then G_ij V_jk G_kl has pole at most
(w_i+w_j)-(w_j+w_k)+(w_k+w_l)=w_i+w_l. Induction proves the same bound for
EVERY finite constant-vertex chain, with no cutoff in chain length. This is
a coefficientwise argument, not convergence of a resummed mass series.
A closed zero-label constant cycle has total bound0 after including its
last vertex; field-independent vacuum normalization remains separate.

For constant beta, B's zero-transfer quadratic part can only come from
sourcefree linear F times sourcefree linear E. Neither has an unlabeled
constant. All1968 linear F_x partners in the six maps vanish, so unknown
scalar potential/g1 E_x cannot enter this projection. Reconstructing every
643-port g0/g1 and first-u convolution gives nonzero raw densities in four
cases, but all SIX complete Euler/Fourier kernels vanish. This is not B=0,
nor a vanishing local density or renormalized contact assertion. All rho
pieces retain exactly one local epsilon by the full K_D and all1286 D
operations; field/source derivatives do not remove that external mark.

## One tangent and adjoints

For a mean/source/epsilon-independent field tangent A_ij(partial) of
derivative order d, the merged soft bound is conservatively
2+w_i+w_j-d. The complete actual derivative tables contain746 such
coefficient terms per route and none exceeds3. All other tangent terms
retain a genuine label and separate node transfer. Constant-coefficient
formal adjoints preserve d; integration by parts on a labeled coefficient
differentiates a Schwartz label rather than deleting it. Hence the same
bound covers the adjoints. The full46,140 derivative terms per route agree
with the separately qualified quantum-leg T1 construction.

The odd-Q own-coordinate symbol is the UNWEIGHTED LEFT own-jet derivative
sum. External sources are not integrated or traced. Every actual diagonal
table here is empty, so adding an incorrect separate supertrace weight is
BLIND on these model entries. Its convention is inherited from V845's
sensitive finite calibration, not newly determined by this zero. Do not
mistake zero Jacobian for zero covariance or zero full regulator response.

## Reuse of the joint-domain argument and its boundary

After collapsing constant chains, the old joint loop/independent-transfer
submersion proof applies to these structural bounds: ordinary nodes have
pole<=2, the ONE tangent node has pole<=3, hence are locally L1 in4D.
The N=1 case retains its loop coordinate. A local epsilon insertion is a
labeled vertex even when rho is constant. Erasing that distinction would
turn600 actual zero-derivative ghost-pair words into critical pole4 controls.
An introduced massless BB mass and a removed tangent derivative similarly
fail the weighted bounds; an introduced linear physical AST loses its
Euler label. Final verification executes these controls.

These facts support the scoped operator/structural joint-IR premises. They
do not alone prove that an augmented converted finite functional exists with
all required UV symbol estimates and source/contact normalizations. Reuse
of the old full trace theorem still requires its UV-subtracted r^-5 remainder,
actual free-edge IR defects, UV-FP-before-IR order and regulator-family
applicability. In particular uU0 includes constant dimension-zero kinetic
vertices: their finite first-u grading, rather than positive engineering
dimension, must justify the augmented UV argument. Keep heat-power terms,
the V847 corrected logarithmic clock, first D-jet and reference determinant.
No arbitrary inverse heat map, common renormalized contact/QAP/measure,
geometric W5, E5/A5 or physical viability conclusion follows here.

The two routes and final replay share the frozen action, conventions,
Python/SymPy and exact word normalizer as well as AI authorship. They check
distinct algebraic constructions within those premises; they are neither
independent scientists nor empirical validation of the physical assumptions.
