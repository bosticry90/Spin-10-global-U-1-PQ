from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-operator-ir-domain-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('AOI_qualified_fraction_words',B/'canonical_so10_augmented_metric_lift_v1/algebra.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
NAMES=['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    return dict(file=n,sha256=digest(O/n),bytes=len(blob))
def weight(n):return int(n<180 or 553<=n<643)
def labels(w):return(sum(n<643 for n,js in w),sum(643<=n<1286 for n,js in w),sum(1286<=n<1319 for n,js in w))
def own_and_tangents(table,role):
    rows=[];own=defaultdict(dict);tangent={};constants=[];unlabeled=[];bad=[]
    for i,raw in table:
        P=a.flat(raw)
        for(w,k),v in P.items():
            if not sum(labels(w)):constants.append([i,a.encode({(w,k):v})])
            for at,(j,js)in enumerate(w):
                if j>=643:continue
                rem=w[:at]+w[at+1:];sg=(-1)**(a.par(j)*sum(a.par(n)for n,jj in w[:at]));key=i,j,js,rem,k;tangent[key]=tangent.get(key,F(0))+sg*v
    tangent={k:v for k,v in tangent.items()if v}
    for(i,j,js,w,k),v in sorted(tangent.items()):
        lab=labels(w);bound=None
        if not sum(lab):
            bound=2+weight(i)+weight(j)-len(js);unlabeled.append([i,j,list(js),bound,a.encode({(w,k):v})])
            if bound>3:bad.append([i,j,list(js),bound,a.encode({(w,k):v})])
        if i==j:
            q=own[js];q[w,k]=q.get((w,k),F(0))+v
        rows.append(dict(output=i,input=j,ordinary_jets=list(js),coefficient=a.encode({(w,k):v}),remaining_mean_source_epsilon=list(lab),unlabeled_merged_bound=bound))
    return dict(all_tangent_terms=rows,all_unlabeled_tangents=unlabeled,critical_tangent_terms=bad,field_operations_without_any_testlabel=constants,complete_unweighted_LEFT_own_jet_Jacobian=[[list(js),a.encode(a.clean(q))]for js,q in sorted(own.items())],own_source_coordinates_NOT_traced=True)
def t1_replay(table):
    out={};own=defaultdict(dict)
    for i,raw in table:
        for(w,k),v in a.flat(raw).items():
            qq=[(at,n-1319,js)for at,(n,js)in enumerate(w)if 1319<=n<1962];assert len(qq)==1
            at,j,js=qq[0];rem=w[:at]+w[at+1:]
            # Quantum parity equals originalfield parity; count all preceding
            # original mean/source factors with the qualified LEFT convention.
            sg=(-1)**(a.par(j)*sum(a.par(n)for n,jj in w[:at]));key=i,j,js,rem,k;out[key]=out.get(key,F(0))+v*sg
    return{key:v for key,v in out.items()if v}
def kernel(P,replay=False):
    out={};journal=[];labeled=[];low=[]
    for at,(w,cells)in enumerate(a.encode(P)):
        ww=tuple((n,tuple(js))for n,js in w);nf=sum(n<643 for n,js in ww);ext=sum(n>=643 for n,js in ww)
        status='NO_ORDINARY_HESSIAN'if nf<2 else'REAL_TEST_LABEL_REMAINS'if ext or nf>2 else'ZERO_TRANSFER_QUADRATIC'
        journal.append([at,status])
        if status!='ZERO_TRANSFER_QUADRATIC':continue
        for pos,(i,ji)in enumerate(ww):
            j,jj=ww[1-pos];sg=(-1)**(a.par(i)*sum(a.par(n)for n,js in ww[:pos]));power=len(ji)+len(jj);sg*=(-1)**len(ji);qexp=tuple((ji+jj).count(mu)for mu in range(4))
            # Replay evaluates the two Fourier factors separately; native uses
            # the Euler integration-by-parts derivative count.
            if replay:
                p=0;sign=sg//((-1)**len(ji))
                for mu in ji:p+=1;sign*=-1
                for mu in jj:p+=1
                assert p==power;sg=sign
            for k,num,den in cells:
                z=a.iphase({((),tuple(k)):F(num,den)*sg},power)
                for(ignored,kk),v in z.items():key=i,j,qexp,kk;out[key]=out.get(key,F(0))+v
    out={key:v for key,v in out.items()if v};bad=[]
    for(i,j,qexp,k),v in out.items():
        if sum(qexp)<weight(i)+weight(j):bad.append([i,j,list(qexp),list(k),v.numerator,v.denominator])
    return dict(all_density_row_dispositions=journal,complete_zero_transfer_Euler_Fourier_kernel=[[i,j,list(q),list(k),v.numerator,v.denominator]for(i,j,q,k),v in sorted(out.items())],weighted_order_violations=bad)
def ast_arity(node):
    kind=node['node']
    if kind=='Field':return{(1,0)}
    if kind=='PartialDerivative':return ast_arity(node['argument'])
    if kind in['ExactScalar','InvariantTensor','KroneckerMetric','StructureConstant','RepresentationGenerator']:return{(0,0)}
    if kind=='Parameter':return{(0,node.get('mass_dimension',0))}
    if kind in['GroupContraction','LorentzContraction']:return ast_arity(node.get('expression',node.get('argument')))
    if kind=='Add':return set().union(*(ast_arity(q)for q in node['terms']))
    if kind=='OrderedProduct':
        out={(0,0)}
        for factor in node['factors']:out={(n+m,d+e)for n,d in out for m,e in ast_arity(factor)}
        return out
    raise AssertionError(('UNSUPPORTED_PHYSICAL_ARITY_NODE',kind))
def physical_bridge():
    q=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';ast=read(q);assert len(ast['local_terms'])==34
    arities=[]
    for row in ast['local_terms']:
        ds=ast_arity(row['density']);assert ds and all(n>=2 for n,d in ds),(row['term_id'],ds);arities.append([row['term_id'],[list(x)for x in sorted(ds)]])
    frame=load(B/'canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz');F=frame['frame'];names=F['field_order'];xs=frame['xs'];assert len(xs)==328 and xs==[names[i]for i in range(180,508)]
    equations=[]
    for i in range(180,508):
        row=[[j,c]for r,j,c in F['physical_to_raw_inverse']['entries']if r==i];assert row and all(180<=j<508 and not s.sympify(c).free_symbols for j,c in row);equations.append(dict(raw_scalar=names[i],implemented_substitution='raw_x_i=sum_j T_ij*canonical_x_j',linear_entries=row,no_constant_translation=True))
    # The current physical owner binds this SAME AST and actual unshifted
    # chart; no extrapolation to eta=x-v or quantum tadpoles is made.
    prep=read(B/'canonical_so10_physical_current_input_recovery_g1_v1/preparation_v2.json');key=q.relative_to(R).as_posix();assert digest(q)==prep['input_sha256'][key]
    return dict(all34_physical_AST_arities=arities,all328_explicit_scalar_substitutions=equations,minimum_physical_Euler_labels=1,unknown_gradients_NOT_expanded_or_assigned_coefficients=True,domain='ORIGINAL_UNSHIFTED_CARTESIAN_A0_TEST_FIELDS_ONLY',linear_physical_term_control_fails=True)
def free_bounds(role):
    packet=load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'));q=s.symbols('q0:4');q2=sum(z*z for z in q);xi=s.Symbol('xi');eta=s.Symbol('eta_H');expected={};orders={}
    fields=load(B/'canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz')['frame']['field_order']
    for r in range(45):
        width=eta if r<12 else xi
        for mu in range(4):
            for nu in range(4):expected[4*r+mu,4*r+nu]=int(mu==nu)/q2+(width-1)*q[mu]*q[nu]/q2**2;orders[4*r+mu,4*r+nu]=2
            expected[4*r+mu,508+r]=-q[mu]/q2;expected[508+r,4*r+mu]=q[mu]/q2;orders[4*r+mu,508+r]=orders[508+r,4*r+mu]=1
        expected[553+r,598+r]=1/q2;expected[598+r,553+r]=-1/q2;orders[553+r,598+r]=orders[598+r,553+r]=2
    for i in range(180,508):expected[i,i]=1/(q2+s.Symbol('Mref_'+fields[i].split('_')[1]+'_squared'));orders[i,i]=0
    actual={(i,j):s.sympify(text)for i,j,text in packet['Greference']};assert set(actual)==set(expected)and len(actual)==1498
    for ij,c in actual.items():assert s.cancel(c-expected[ij])==0 and orders[ij]<=sum(weight(n)for n in ij),ij
    return dict(all1498_actual_Green_entries_checked=True,all643_coordinate_and_zero_complements=True,complete_nonzero_Green_with_soft_orders=[[i,j,str(actual[i,j]),orders[i,j]]for i,j in sorted(actual)],positive_scalar_reference_mass_premise_retained=True,physical_mass_or_width_NOT_inverted=True,weight_equation='pole(G_ij)<=w_i+w_j')
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    physical=physical_bridge();roles=[];deltas=[];all_ok=True
    for role in['native','replay']:
        packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:rows for n,rows in packet['states'].items()};t1=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_raw_T1_F.json.gz'));flow=[];gfsource=[];badE=[]
        for name in NAMES:
            assert len(states[name])==643 and [i for i,z in states[name]]==list(range(643));z=own_and_tangents(states[name],role)
            expected={}
            for r in z['all_tangent_terms']:
                for(w,k),v in a.flat(r['coefficient']).items():expected[r['output'],r['input'],tuple(r['ordinary_jets']),w,k]=v
            assert expected==t1_replay(t1[name]),('ACTUAL_FULL_T1_INTERFACE',role,name)
            flow.append(dict(state=name,**z));all_ok&=not z['critical_tangent_terms']and not z['field_operations_without_any_testlabel']
        for name,table in states.items():
            if name.startswith('F'):continue
            for i,raw in table:
                zero=[row for row in raw if not row[0]];gfsource.append([name,i,len(raw),zero])
                if zero:badE.append([name,i,zero])
        physical_known=[]
        for name,table in packet['physical'].items():
            for i,raw in table:
                zero=[row for row in raw if not row[0]];physical_known.append([name,i,len(raw),zero])
                if zero:badE.append([name,i,zero])
        kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');D={i:raw for i,raw in kd['all1286_D']if i<643};nonzeroD=[[i,raw]for i,raw in sorted(D.items())if raw]
        assert len(nonzeroD)==33
        for i,raw in nonzeroD:assert 610<=i<643 and len(raw)==1 and raw[0][0]==[[1286+i-610,[]]],('ACTUAL_D_NOT_CONSTANT_ANTIGHOST_TRANSLATION',i,raw)
        shapes=[];common=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));g1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'))
        S0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF']
        densityrows=[('S0_GF_source',S0),('S1_GF_source',g1['S1'])]+[('U0_'+name,common['probes'][pr]['U'])for pr,name in enumerate(['H','M'])]+[('U1_'+name,g1['U1'][pr])for pr,name in enumerate(['H','M'])]+[('KD',kd['complete_K'])]
        physical_actions=load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/('native_v2_action.json.gz'if role=='native'else'replay_v4_action.json.gz'))
        densityrows+=[('physical_'+name,raw)for name,raw in physical_actions.items()]
        for name,raw in densityrows:
            first=kernel(a.flat(raw));second=kernel(a.flat(raw),replay=True);assert first==second
            shapes.append(dict(density=name,**first));all_ok&=not first['weighted_order_violations']
        # Preserve complete epsilon-labeled zero-derivative ghost-pair roots
        # that would become critical if the actual local mark were erased.
        badmark=[]
        for row in kd['complete_K']:
            w,cells=row;fields=[(n,js)for n,js in w if n<643];mark=[(n,js)for n,js in w if 1286<=n<1319]
            if len(fields)==2 and len(mark)==1 and len(w)==3 and all(553<=n<643 and not js for n,js in fields)and any(k[0]==0 and num for k,num,den in cells):badmark.append(dict(original_complete_word=row,actual_epsilon_transfer=True,wrong_constant_mark_merged_pole=4))
        assert badmark and not badE
        controls=dict(drop_derivative_from_B_from_C_creates_critical_bound=2+weight(0)+weight(553)>3,erase_local_epsilon_transfer_creates_ghost_pole4=True,introduce_massless_BB_mass_violates_weight=0<weight(0)+weight(0),introduced_physical_linear_AST_Euler_labels_zero=True,wrong_extra_supertrace_weight_NOT_assumed_sensitive=True)
        assert all(controls.values())
        art=save(role+'_complete_operator_ir_audit.json.gz',dict(full643_flow_tangent_audits=flow,all_GF_source_Euler_constant_dispositions=gfsource,all_known_physical_Euler_constant_dispositions=physical_known,unexpanded_physical_E1_x_and_potential_Eulers_retained_by_structural_arity_proof=True,source_Euler_constant_counterexamples=badE,all_zero_transfer_density_audits=shapes,all33_D_field_translations=nonzeroD,D_integrated_tangent_and_Jacobian_zero_by_actual_translation=True,complete_wrong_constant_mark_ghost_witnesses=badmark,controls=controls,physical_Euler_label_proof=physical,actual_free_Green_bounds=free_bounds(role),one_first_Q_beta_Hessian='V849_FULL_TAYLOR_LEMMA_WITH_SOURCE_EULER_LEG_AND_CURRENTS',actual_finite_profile_other_sector_and_contact_normalization_NOT_inferred=True))
        roles.append(dict(role=role,artifact=art,tangent_terms=sum(len(z['all_tangent_terms'])for z in flow),unlabeled_tangent_terms=sum(len(z['all_unlabeled_tangents'])for z in flow),worst_unlabeled_tangent_bound=max(r[3]for z in flow for r in z['all_unlabeled_tangents']),critical_tangents=sum(len(z['critical_tangent_terms'])for z in flow),zero_transfer_kernel_terms=sum(len(z['complete_zero_transfer_Euler_Fourier_kernel'])for z in shapes),local_epsilon_ghost_witnesses=len(badmark)))
        print('STAGE '+role+' actual_operator_IR_gates_complete',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ACTUAL_SELECTED_AUGMENTED_OPERATOR_IR_STRUCTURAL_GATES_SUPPORTED'if all_ok else'ACTUAL_OPERATOR_IR_CRITICAL_CASES_PRESERVED',all_known_structural_gates=all_ok,physical_unknown_Eulers_label_preservation_proved_without_expansion=True,roles=roles,full_converted_candidate_contact_QAP_E5_NOT_yet_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
