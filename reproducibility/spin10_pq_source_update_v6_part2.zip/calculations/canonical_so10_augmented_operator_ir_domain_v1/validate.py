from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from hashlib import sha256
import ast,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-operator-ir-domain-v1-2026-11-08')
spec=importlib.util.spec_from_file_location('V850_SHARED_FROZEN_WORD_NORMALIZER',B/'canonical_so10_augmented_metric_lift_v1/algebra.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
NAMES=['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def wgt(n):return 1 if n in range(180)or n in range(553,643)else 0
def labs(word):return[sum(i in range(643)for i,j in word),sum(i in range(643,1286)for i,j in word),sum(i in range(1286,1319)for i,j in word)]
def tidy(q):return{k:v for k,v in q.items()if v}
def derivatives(table):
    out={};constants=[]
    for i,raw in table:
        for(word,key),coefficient in a.flat(raw).items():
            if not any(labs(word)):constants.append([i,a.encode({(word,key):coefficient})])
            for column in sorted({n for n,jets in word if n<643}):
                for position,(n,jets)in enumerate(word):
                    if n!=column:continue
                    sign=(-1)**sum(a.par(n)*a.par(k)for k,js in word[:position]);address=(i,n,jets,word[:position]+word[position+1:],key)
                    out[address]=out.get(address,F(0))+sign*coefficient
    return tidy(out),constants
def quantum_derivatives(table):
    out={}
    for i,raw in table:
        for(word,key),v in a.flat(raw).items():
            positions=[p for p,(n,js)in enumerate(word)if 1319<=n<1962];assert len(positions)==1
            at=positions[0];n,js=word[at];n-=1319;sign=(-1)**sum(a.par(n)*a.par(k)for k,jj in word[:at]);address=i,n,js,word[:at]+word[at+1:],key;out[address]=out.get(address,F(0))+sign*v
    return tidy(out)
def own_symbol(tangent):
    out=defaultdict(dict)
    for(i,j,jets,word,key),v in tangent.items():
        if i==j:out[jets][word,key]=out[jets].get((word,key),F(0))+v
    return[[list(js),a.encode(tidy(q))]for js,q in sorted(out.items())]
def ikey(key,power,v):
    # Independent integer i-power table, rather than producer iphase().
    sign,odd=[(1,False),(1,True),(-1,False),(-1,True)][power%4];out=list(key)
    if odd:
        if out[3]&16:sign=-sign
        out[3]^=16
    return tuple(out),v*sign
def fourier(P):
    result={};journal=[]
    for row,(word,cells)in enumerate(a.encode(P)):
        nf=sum(n<643 for n,j in word);ext=sum(n>=643 for n,j in word)
        status='NO_ORDINARY_HESSIAN'if nf<2 else'REAL_TEST_LABEL_REMAINS'if ext or nf>2 else'ZERO_TRANSFER_QUADRATIC';journal.append([row,status])
        if status!='ZERO_TRANSFER_QUADRATIC':continue
        for removed in[0,1]:
            i,di=word[removed];j,dj=word[1-removed];sign=(-1)**(a.par(i)*sum(a.par(n)for n,js in word[:removed]));mom=[0]*4;power=0
            for mu in di:mom[mu]+=1;power+=1;sign=-sign
            for mu in dj:mom[mu]+=1;power+=1
            for k,num,den in cells:
                kk,v=ikey(k,power,F(num,den)*sign);address=i,j,tuple(mom),kk;result[address]=result.get(address,F(0))+v
    result=tidy(result);bad=[[i,j,list(p),list(k),v.numerator,v.denominator]for(i,j,p,k),v in result.items()if sum(p)<wgt(i)+wgt(j)]
    return dict(all_density_row_dispositions=journal,complete_zero_transfer_Euler_Fourier_kernel=[[i,j,list(p),list(k),v.numerator,v.denominator]for(i,j,p,k),v in sorted(result.items())],weighted_order_violations=bad)
def lin(raw):return{k:v for k,v in a.flat(raw).items()if len(k[0])==1 and k[0][0][0]<643}
def product(P,Q):
    result={}
    for(word,k),v in P.items():
        for(other,l),c in Q.items():
            if k[0]+l[0]>1:continue
            overlap=k[3]&l[3];factor=(-1 if overlap&16 else 1)
            for bit,prime in enumerate([2,3,5,7]):
                if overlap&(1<<bit):factor*=prime
            a.put(result,word+other,(k[0]+l[0],k[1]+l[1],k[2]+l[2],k[3]^l[3]),v*c*factor)
    return tidy(result)
def ast_degrees(node):
    k=node['node']
    if k=='Field':return{(1,0)}
    if k=='Parameter':return{(0,node.get('mass_dimension',0))}
    if k in['ExactScalar','InvariantTensor','KroneckerMetric','StructureConstant','RepresentationGenerator']:return{(0,0)}
    if k=='PartialDerivative':return ast_degrees(node['argument'])
    if k in['GroupContraction','LorentzContraction']:return ast_degrees(node.get('expression',node.get('argument')))
    if k=='Add':return set().union(*(ast_degrees(q)for q in node['terms']))
    if k=='OrderedProduct':
        polys=[ast_degrees(q)for q in node['factors']];total={(0,0)}
        for poly in polys:total={(i+j,d+e)for i,d in total for j,e in poly}
        return total
    raise AssertionError(k)
def field_types(node):
    todo=[node];names=set();nd=0
    while todo:
        q=todo.pop()
        if q['node']=='Field':names.add(q['name'])
        if q['node']=='PartialDerivative':nd+=1
        for v in q.values():
            if isinstance(v,dict)and'node'in v:todo.append(v)
            if isinstance(v,list):todo.extend(c for c in v if isinstance(c,dict)and'node'in c)
    return names,nd
def physical_check():
    root=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';q=root/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';physical=read(q);assert len(physical['local_terms'])==34
    ds=[[row['term_id'],[list(t)for t in sorted(ast_degrees(row['density']))]]for row in physical['local_terms']];assert all(n>=2 for name,rows in ds for n,d in rows)
    mod=ast.parse((root/'a10_cotangent_adapter.py').read_text(encoding='utf-8'));aliases=next(ast.literal_eval(n.value)for n in mod.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ALIASES'for t in n.targets));assert set(aliases)=={'Phi','Sigma','phi','S'}and{n for names in aliases.values()for n in names}=={'Phi','Sigma','SigmaBar','phi','phiBar','S','SBar'}
    types=[]
    for row in physical['local_terms'][5:]:
        names,nd=field_types(row['density']);assert names and names<={n for names in aliases.values()for n in names}and nd==0;types.append([row['term_id'],sorted(names),nd])
    executable=ast.parse((root/'a10_executable_action.py').read_text(encoding='utf-8'));state=next(n for n in executable.body if isinstance(n,ast.FunctionDef)and n.name=='canonical_state');body=ast.unparse(state)
    assert 'physical[sec] = E * x'in body and 'x = s.Matrix(values[sec])'in body and 'geometry[sec]'in body
    assert 'vec[i] + s.I * vec[10 + i]'in body and 'sing[0] + s.I * sing[1]'in body
    geometry=read(root/'frozen_action_ast_a3/A31_embeddings.json')['sectors'];count=0
    for sec,embedding in geometry.items():
        count+=embedding['domain_dimension'];assert sec in aliases
        for i,j,c in embedding['embedding_entries']:assert 0<=i<embedding['ambient_real_dimension']and 0<=j<embedding['domain_dimension']and not s.sympify(c).free_symbols
    assert count==328
    # Exact E*x and real-linear conjugate views are bound, not an affine x=v+eta chart.
    evaluator=(root/'execute_a3_parent_potential_ast.py').read_text(encoding='utf-8');assert '"SigmaBar": _sigma_full(state, conjugated=True)'in evaluator and 'sp.conjugate(state.S)'in evaluator
    frame=load(B/'canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz');names=frame['frame']['field_order'];assert frame['xs']==names[180:508]and len(frame['xs'])==328;equations=[]
    for i in range(180,508):
        entries=[[j,c]for row,j,c in frame['frame']['physical_to_raw_inverse']['entries']if row==i];assert entries and all(180<=j<508 and not s.sympify(c).free_symbols for j,c in entries);equations.append(dict(raw_scalar=names[i],implemented_substitution='raw_x_i=sum_j T_ij*canonical_x_j',linear_entries=entries,no_constant_translation=True))
    assert digest(q)==read(B/'canonical_so10_physical_current_input_recovery_g1_v1/preparation_v2.json')['input_sha256'][q.relative_to(R).as_posix()]
    assert ast_degrees(dict(node='Field',name='S',indices=[]))=={(1,0)}
    return ds,equations,types,aliases
def reference_check(role,record):
    q=s.symbols('q0:4');p2=sum(x*x for x in q);xi=s.Symbol('xi');eta=s.Symbol('eta_H');expected={};orders={};fields=load(B/'canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz')['frame']['field_order']
    for c in range(45):
        width=eta if c<12 else xi
        for mu in range(4):
            for nu in range(4):expected[4*c+mu,4*c+nu]=int(mu==nu)/p2+(width-1)*q[mu]*q[nu]/p2**2;orders[4*c+mu,4*c+nu]=2
            expected[4*c+mu,508+c]=-q[mu]/p2;expected[508+c,4*c+mu]=q[mu]/p2;orders[4*c+mu,508+c]=orders[508+c,4*c+mu]=1
        expected[553+c,598+c]=1/p2;expected[598+c,553+c]=-1/p2;orders[553+c,598+c]=orders[598+c,553+c]=2
    for i in range(180,508):expected[i,i]=1/(p2+s.Symbol('Mref_'+fields[i].split('_')[1]+'_squared'));orders[i,i]=0
    actual={(i,j):s.sympify(z)for i,j,z in load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'))['Greference']};assert set(actual)==set(expected)and len(actual)==1498
    for ij,z in actual.items():assert s.cancel(z-expected[ij])==0 and orders[ij]<=wgt(ij[0])+wgt(ij[1])
    assert record['complete_nonzero_Green_with_soft_orders']==[[i,j,str(actual[i,j]),orders[i,j]]for i,j in sorted(actual)]
def main():
    tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5'
    for name,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/name)==h,name
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    for prep in['preparation.json','preparation_b.json','preparation_b2.json']:
        z=read(O/prep);assert z==read(C/prep)
        for name,h in z['sha256'].items():assert digest(saved[name]if name in saved else R/name)==h,name
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    captures=[]
    for name,limit in[('capture.json',180),('capture_b2.json',60)]:
        cap=read(O/name);assert cap==read(C/name)and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified'];assert all(0<r['private_bytes']<=8*1024**3 for r in cap['all_resource_samples']);captures.append(cap)
    assert read(O/'result.json')['elapsed_after_imports']<180 and read(O/'result_b2.json')['elapsed_after_imports']<60
    failed=read(O/'capture_b.json');assert failed==read(C/'capture_b.json')and failed['exit_code']==1 and not failed['calculation_completed']and "AssertionError: ('potential_lambdaPhi1', {'Phi'}, 0)"in failed['stdout_and_stderr'];assert not(O/'result_b.json').exists()
    arities,equations,types,aliases=physical_check();summaries=[];controls=[]
    for role in['native','replay']:
        za=next(z for z in read(O/'result.json')['roles']if z['role']==role);zb=next(z for z in read(O/'result_b2.json')['roles']if z['role']==role)
        for rr in[za,zb]:
            assert digest(O/rr['artifact']['file'])==rr['artifact']['sha256']and(O/rr['artifact']['file']).stat().st_size==rr['artifact']['bytes']
        audit=load(O/za['artifact']['file']);breaking=load(O/zb['artifact']['file']);packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(rows)for n,rows in packet['states'].items()};physical={n:dict(rows)for n,rows in packet['physical'].items()};t1=load(B/'canonical_so10_regulator_vertices_g1_recovery_v1'/(role+'_raw_T1_F.json.gz'));total=0;unlabeled=0;worst=0
        for recorded in audit['full643_flow_tangent_audits']:
            name=recorded['state'];assert name in NAMES;table=list(states[name].items());assert sorted(states[name])==list(range(643));dd,cc=derivatives(table);assert dd==quantum_derivatives(t1[name])and not cc
            got={};un=[]
            for row in recorded['all_tangent_terms']:
                v=a.flat(row['coefficient']);assert len(v)==1
                (word,key),value=next(iter(v.items()));address=row['output'],row['input'],tuple(row['ordinary_jets']),word,key;assert address not in got;got[address]=value;label=labs(word);assert row['remaining_mean_source_epsilon']==label
                bound=None if any(label)else 2+wgt(row['output'])+wgt(row['input'])-len(row['ordinary_jets']);assert bound==row['unlabeled_merged_bound']
            assert got==dd and recorded['complete_unweighted_LEFT_own_jet_Jacobian']==own_symbol(dd)==[]
            for(i,j,js,word,key),v in sorted(dd.items()):
                if not any(labs(word)):
                    degree=2+wgt(i)+wgt(j)-len(js);assert degree<=3;worst=max(worst,degree);un.append([i,j,list(js),degree,a.encode({(word,key):v})])
            assert un==recorded['all_unlabeled_tangents']and not recorded['critical_tangent_terms']and not recorded['field_operations_without_any_testlabel'];total+=len(dd);unlabeled+=len(un)
            if name=='F0':
                witness=next(x for x in un if x[0]<180 and 553<=x[1]<598 and len(x[2])==1);assert 2+wgt(witness[0])+wgt(witness[1])==4;controls.append(dict(role=role,drop_actual_tangent_derivative=witness,resulting_bound=4,actual_extra_supertrace_control='BLIND_EMPTY_OWN_DIAGONAL'))
        assert len(audit['full643_flow_tangent_audits'])==6 and total==46140 and unlabeled==746 and worst==3
        gf=[];phys=[]
        for name,rows in packet['states'].items():
            if name.startswith('F'):continue
            for i,raw in rows:
                constants=[row for row in raw if not row[0]];assert not constants;gf.append([name,i,len(raw),constants])
        for name,rows in packet['physical'].items():
            for i,raw in rows:
                constants=[row for row in raw if not row[0]];assert not constants;phys.append([name,i,len(raw),constants])
        assert gf==audit['all_GF_source_Euler_constant_dispositions']and phys==audit['all_known_physical_Euler_constant_dispositions']and not audit['source_Euler_constant_counterexamples']
        kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');ds=[[i,raw]for i,raw in kd['all1286_D']if i<643 and raw];assert len(ds)==33 and ds==audit['all33_D_field_translations']
        for i,raw in ds:assert 610<=i<643 and len(raw)==1 and raw[0][0]==[[1286+i-610,[]]]
        for raw in[kd['complete_K']]+[rows for i,rows in kd['all1286_D']]:
            for word,cells in raw:assert sum(1286<=n<1319 for n,js in word)==1
        common=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));g1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));s0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF'];dens=[('S0_GF_source',s0),('S1_GF_source',g1['S1'])]+[('U0_'+n,common['probes'][p]['U'])for p,n in enumerate(['H','M'])]+[('U1_'+n,g1['U1'][p])for p,n in enumerate(['H','M'])]+[('KD',kd['complete_K'])];pa=load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/('native_v2_action.json.gz'if role=='native'else'replay_v4_action.json.gz'));dens+=[('physical_'+n,raw)for n,raw in pa.items()];nc=0
        assert len(dens)==len(audit['all_zero_transfer_density_audits'])
        for(name,raw),recorded in zip(dens,audit['all_zero_transfer_density_audits']):
            kernel=fourier(a.flat(raw));assert dict(density=name,**kernel)==recorded and not kernel['weighted_order_violations'];nc+=len(kernel['complete_zero_transfer_Euler_Fourier_kernel'])
        assert nc==7834
        marks=[]
        for word,cells in kd['complete_K']:
            fields=[(n,j)for n,j in word if n<643];eps=[(n,j)for n,j in word if 1286<=n<1319]
            if len(fields)==2 and len(eps)==1 and len(word)==3 and all(553<=n<643 and not j for n,j in fields)and any(k[0]==0 and v for k,v,d in cells):marks.append(dict(original_complete_word=[word,cells],actual_epsilon_transfer=True,wrong_constant_mark_merged_pole=4))
        assert len(marks)==600 and marks==audit['complete_wrong_constant_mark_ghost_witnesses']
        bridge=audit['physical_Euler_label_proof'];assert bridge['all34_physical_AST_arities']==arities and bridge['all328_explicit_scalar_substitutions']==equations
        reference_check(role,audit['actual_free_Green_bounds'])
        unknown=[]
        for name in NAMES:
            for n in range(180,508):assert not lin(states[name][n]);unknown.append([name,n,0])
        assert breaking['all1968_unknown_scalar_Euler_linear_partners']==unknown and breaking['all29_potential_scalar_support']==types and breaking['actual_bound_scalar_tensor_aliases']=={k:list(v)for k,v in aliases.items()}and breaking['executed_linear_AST_control']==[[1,0]]
        def E(name,n):
            pol=lin(states[name].get(n,[]))
            if name=='E0':pol=a.add(pol,lin(physical['P_E0'].get(n,[])))
            if name=='E1':pol=a.add(pol,lin(physical['P_E1_gauge'].get(n,[])),lin(physical['P_E1_scalar'].get(n,[])))
            return pol
        cases=[('original_g0',[('F0','E0')]),('original_g1',[('F1','E0'),('F0','E1')])]
        for pr in[0,1]:cases.extend([('probe'+str(pr)+'_g0',[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))]),('probe'+str(pr)+'_g1',[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))])])
        sizes=[]
        for(name,branches),recorded in zip(cases,breaking['all_six_cases']):
            poly={};ports=[]
            for fn,en in branches:
                for n in range(643):
                    left=lin(states[fn][n]);right=E(en,n);pq=product(left,right);poly=a.add(poly,pq);ports.append([fn,en,n,len(left),len(right),len(pq)])
            fk=fourier(poly);assert fk==recorded['complete_B_Euler_Fourier_kernel']and not fk['complete_zero_transfer_Euler_Fourier_kernel']and not fk['weighted_order_violations'];assert name==recorded['case']and[tuple(z)for z in recorded['branches']]==branches and ports==recorded['all643_branch_ports']and a.encode(poly)==recorded['complete_zero_transfer_B_density'];sizes.append(len(a.encode(poly)))
        assert sizes==[1440,0,480,0,1320,2368]and len(breaking['all_six_cases'])==6
        mass=fourier({(((0,()),(0,())),(0,0,0,0)):F(1,2)});assert mass['weighted_order_violations']
        assert all(audit['controls'].values());summaries.append(dict(role=role,tangent_terms=total,unlabeled=unlabeled,worst_bound=worst,constant_kernel_terms=nc,epsilon_ghost_witnesses=len(marks),breaking_density_words=sizes,all_six_breaking_kernels_zero=True))
        print('STAGE '+role+' independent_operator_and_breaking_validation_complete',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V850.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V850.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V850.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V850.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_SELECTED_AUGMENTED_OPERATOR_AND_STRUCTURAL_IR_GATES',base_HEAD=head,state_sha256=state,roles=summaries,executed_controls=controls,physical_alias_homogeneous_linear_embedding_and_current_chart_checked=True,failed_B_schema_run='PRESERVED_FAILED_NOTPASS',all_six_constant_beta_breaking_kernels_zero=True,weighted_all_finite_chain_and_adjoint_proof_reviewed=True,UV_converted_functional_contact_W5_QAP_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(r['private_bytes']for cap in captures for r in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_word_normalizer_conventions_Python_Sympy_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
