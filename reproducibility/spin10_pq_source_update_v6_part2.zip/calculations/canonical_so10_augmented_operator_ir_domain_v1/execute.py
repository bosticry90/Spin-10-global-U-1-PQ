from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-operator-ir-domain-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5'
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V849.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md'}
for folder in['canonical_so10_joint_born_ir_trace_domain','canonical_so10_mixed_probe_slavnov','canonical_so10_augmented_metric_lift_v1','canonical_so10_nonlinear_source_insertion_extension_v1','canonical_so10_regulator_free_inverse_g1_recovery_v1','canonical_so10_proper_slavnov_actual_operators_g1_v1','canonical_so10_regulator_vertices_g1_recovery_v1','canonical_so10_new_physical_returning_inventory_g1_recovery_v1','canonical_so10_full_current_inventory_g1_recovery_v1','canonical_so10_physical_current_input_recovery_g1_v1','canonical_so10_linear_ghost_onepoint_g1_v1','canonical_so10_marked_hatted_master_support_g1_v1','canonical_so10_marked_regulator_parent_g1_v1']:
    root=R/'calculations'/folder
    for n in['PROOF.md','DERIVATION.md','DERIVATION_V2.md','RESULT.md','validation_receipt.json','algebra.py','preparation_v2.json']:
        if(root/n).exists():names.add((root/n).relative_to(R).as_posix())
for role in['native','replay']:
    for folder,n in [('canonical_so10_proper_slavnov_actual_operators_g1_v1',role+'_inputs.json.gz'),('canonical_so10_regulator_vertices_g1_recovery_v1',role+'_raw_T1_F.json.gz'),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1',role+'_GF_common.json.gz'),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1',role+'_route_density.json.gz'),('canonical_so10_full_current_inventory_g1_recovery_v1',role+'_route_densities.json.gz'),('canonical_so10_regulator_free_inverse_g1_recovery_v1',role+'_inverse.json.gz')]:names.add('calculations/'+folder+'/'+n)
names|={'calculations/canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz','calculations/canonical_so10_cartan_generator_residual_g1_v1/validation_receipt.json','calculations/canonical_so10_full_jet_source_master_bridge/primary_inputs.json.gz','calculations/canonical_so10_full_jet_source_master_bridge/final_review_validation_receipt.json','calculations/canonical_so10_physical_current_input_recovery_g1_v1/native_v2_action.json.gz','calculations/canonical_so10_physical_current_input_recovery_g1_v1/replay_v4_action.json.gz','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json'}
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
