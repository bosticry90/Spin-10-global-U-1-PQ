from pathlib import Path
import ast
O=Path(__file__).resolve().parent
q=(O/'compute_breaking.py').read_text(encoding='utf-8')
old="fields,d=physical_types(row['density']);assert fields and all(n.startswith('x_')for n in fields)and d==0,(row['term_id'],fields,d);types.append([row['term_id'],sorted(fields),d])"
new="fields,d=physical_types(row['density']);assert fields and fields<=allowed and d==0,(row['term_id'],fields,d);types.append([row['term_id'],sorted(fields),d])"
assert q.count(old)==1;q=q.replace(old,new)
needle="    for row in ast['local_terms'][5:]:"
alias="""    import ast as pyast
    adapter=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/a10_cotangent_adapter.py'
    assignments=[n for n in pyast.parse(adapter.read_text(encoding='utf-8')).body if isinstance(n,pyast.Assign) and any(isinstance(t,pyast.Name)and t.id=='ALIASES'for t in n.targets)]
    assert len(assignments)==1
    aliases=pyast.literal_eval(assignments[0].value);allowed={n for names in aliases.values()for n in names}
    assert allowed=={'Phi','Sigma','SigmaBar','phi','phiBar','S','SBar'}
    for row in ast['local_terms'][5:]:"""
assert q.count(needle)==1;q=q.replace(needle,alias)
for old,new in [('preparation_b.json','preparation_b2.json'),('result_b.json','result_b2.json'),('_constant_beta_breaking_gate.json.gz','_constant_beta_breaking_gate_v2.json.gz')]:
    assert old in q;q=q.replace(old,new)
q=q.replace('all29_potential_scalar_support=types,','all29_potential_scalar_support=types,actual_bound_scalar_tensor_aliases=aliases,')
p=(O/'execute_breaking.py').read_text(encoding='utf-8')
p=p.replace("for n in['PHASE_B_RECORD.md','compute_breaking.py','execute_breaking.py']:","for n in['CONTINUATION_B2.md','build_b2.py','compute_breaking_v2.py','execute_breaking_v2.py']:")
p=p.replace("names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}","names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};names|={'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'+n for n in ['a10_cotangent_adapter.py','a10_executable_action.py','execute_a3_parent_potential_ast.py','frozen_action_ast_a3/A31_embeddings.json']}")
for old,new in [('preparation_b.json','preparation_b2.json'),('capture_b.json','capture_b2.json'),("str(O/'compute_breaking.py')","str(O/'compute_breaking_v2.py')")]:
    assert old in p;p=p.replace(old,new)
for n,z in [('compute_breaking_v2.py',q),('execute_breaking_v2.py',p)]:
    ast.parse(z)
    with(O/n).open('x',encoding='utf-8',newline='\n')as f:f.write(z)
print('BUILT_EXCLUSIVE_B2_SCHEMA_CORRECTION')
