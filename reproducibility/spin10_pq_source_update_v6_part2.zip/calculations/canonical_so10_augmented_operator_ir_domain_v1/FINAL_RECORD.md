# Separate V850 validation

One240s afterimports,8GiB sampled/350MiBfloor,64MiB packet/8MiBartifact.
The enlarged verification scope, compared with either producer, includes
all tangent entries, T1 comparison, every density kernel and constant-beta
breaking convolution, actual free Green blocks, homogeneous scalar chart,
all AST branches/aliases, executed negative controls, plus the single E4
check. Freeze exact inputs/sources/navigation before running; no retry or
resource expansion within this attempt. Root writes/runs/Git, AI review read only.

Do not import either producer. Independently differentiate field and quantum
legs, assemble unweighted own-jet symbols, reconstruct Euler/Fourier kernels
and all643-port breaking sums. Sharing the qualified exact word normalizer
is disclosed, as are the action, Python/SymPy and AI authorship. Unknown
physical gradients stay symbolic: independently prove their label premise
and their absent linear F_x partner in the quadratic B projection.

Compare all recorded rows and artifact hashes, all source copies and frozen
preparations, completed A/B2 captures and failed B capture. Controls must be
executed; report the actual supertrace-weight control blind. Check original
Git tree, exact historical README suffix, current navigation links and state.
Old navigation preparation hashes use their original saved bytes, not new
bytes. E4fixedcontext once with exits0,0,0,0,0,2/seven unresolvedNOTPASS.
Whole failure/overflow retained; only completed validation permits localcommit.
No fullUV/contact/QAP/measure/geometricW5/E5/A5 or physical-viability promotion.
