# B2: exact physical tensor aliases, unchanged scientific gate

Phase B terminated exit1 before producing any B kernel: its scalar-only AST
check incorrectly required names beginning x_. The actual potential uses
Phi,Sigma,SigmaBar,phi,phiBar,S,SBar. Preserve its complete source, preparation
and failed capture unchanged. This is a representation-schema correction,
not a negative physical result or qualification of the unfinished comparison.

Read the literal ALIASES assignment in the bound a10_cotangent_adapter.py;
require its exact seven-name set and use that set for all29 potential ASTs.
Retain the no-derivative and scalar-only requirements. These aliases are
linear homogeneous views of the canonical real carrier: canonical_state in
a10_executable_action.py multiplies the qualified embedding matrix by x;
conjugate views are of those SAME coordinates, not additional fields. Bind
the executable action, potential evaluator and frozen embedding as inputs.
Phase A separately checked the full328 homogeneous raw-to-current frame.
No affine vacuum shift or scalar quantum tadpole conclusion is permitted.

All other Phase B scientific tests and limits are unchanged: all six F_x
linear projections, full643-port breaking convolutions, complete graded
Euler/Fourier kernel, all rho mark degrees, executed linear-AST control.
One60s afterimports,8GiB sampled/350MiB floor,64MiB packet/8MiB artifact.
New producer/wrapper/source copies/preparation/capture/result/artifacts have
v2 or b2 names. Failed B remains FAILED; B2 has no retroactive effect on it.
Separate final validation must independently reconstruct both phases and
authenticate the failure, actual aliases and exact completed captures.
Authority34/39, E5/A5 open; no adoption or protected promotion.
