from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,os,threading,time
import compute as m
R=m.R;O=m.O;B=m.B;C=m.C;a=m.a;read=m.read;load=m.load;save=m.save;dump=m.dump;digest=m.digest
def multiply(P,Q):
    out={}
    for(w,k),v in P.items():
        for(ww,l),c in Q.items():
            if k[0]+l[0]>1:continue
            factor=-1 if k[3]&l[3]&16 else 1
            for bit,prime in enumerate([2,3,5,7]):
                if k[3]&l[3]&(1<<bit):factor*=prime
            key=(k[0]+l[0],k[1]+l[1],k[2]+l[2],k[3]^l[3]);a.put(out,w+ww,key,v*c*factor)
    return a.clean(out)
def linear(raw):return{key:v for key,v in a.flat(raw).items()if len(key[0])==1 and key[0][0][0]<643}
def physical_types(node):
    kind=node['node']
    if kind=='Field':return{node['name']},0
    if kind=='PartialDerivative':
        fields,d=physical_types(node['argument']);return fields,d+1
    fields=set();derivatives=0
    for value in node.values():
        children=[value]if isinstance(value,dict)and'node'in value else value if isinstance(value,list)else[]
        for child in children:
            if isinstance(child,dict)and'node'in child:
                f,d=physical_types(child);fields|=f;derivatives+=d
    return fields,derivatives
def main():
    tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation_b.json')['sha256'].items():assert digest(R/n)==h,n
    ast=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');types=[]
    for row in ast['local_terms'][5:]:
        fields,d=physical_types(row['density']);assert fields and all(n.startswith('x_')for n in fields)and d==0,(row['term_id'],fields,d);types.append([row['term_id'],sorted(fields),d])
    linear_control=m.ast_arity(dict(node='Field',name='x_S',indices=[]));assert linear_control=={(1,0)}and min(n-1 for n,d in linear_control)==0
    kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz')
    for rows in[kd['complete_K']]+[raw for i,raw in kd['all1286_D']]:
        for w,c in rows:assert sum(1286<=n<1319 for n,js in w)==1,'MARK_DEGREE_NOT_ONE'
    roles=[];full=[]
    for role in['native','replay']:
        pkt=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(rows)for n,rows in pkt['states'].items()};phys={n:dict(rows)for n,rows in pkt['physical'].items()};unknown=[]
        for name in m.NAMES:
            for n in range(180,508):
                q=linear(states[name][n]);unknown.append([name,n,len(q)]);assert not q,'UNKNOWN_SCALAR_EULER_LINEAR_F_PARTNER_REQUIRED'
        def E(name,n):
            q=linear(states[name].get(n,[]))
            if name=='E0':q=a.add(q,linear(phys['P_E0'].get(n,[])))
            if name=='E1':q=a.add(q,linear(phys['P_E1_gauge'].get(n,[])),linear(phys['P_E1_scalar'].get(n,[])))
            return q
        cases=[('original_g0',[('F0','E0')]),('original_g1',[('F1','E0'),('F0','E1')])]
        for pr in[0,1]:
            cases.extend([('probe'+str(pr)+'_g0',[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))]),('probe'+str(pr)+'_g1',[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))])])
        rows=[]
        for label,branches in cases:
            density={};ports=[]
            for fn,en in branches:
                for n in range(643):
                    left=linear(states[fn][n]);right=E(en,n);prod=multiply(left,right);density=a.add(density,prod);ports.append([fn,en,n,len(left),len(right),len(prod)])
            ker=m.kernel(density);peer=m.kernel(density,replay=True);assert ker==peer and not ker['weighted_order_violations'];rows.append(dict(case=label,branches=branches,all643_branch_ports=ports,complete_zero_transfer_B_density=a.encode(density),complete_B_Euler_Fourier_kernel=ker,full_classical_breaking_NOT_set_zero=True))
        full.append(rows);ref=save(role+'_constant_beta_breaking_gate.json.gz',dict(all_six_cases=rows,all1968_unknown_scalar_Euler_linear_partners=unknown,all29_potential_scalar_support=types,executed_linear_AST_control=[list(x)for x in sorted(linear_control)],rho_breaking_retains_local_epsilon_by_full_K_and_D_degree=True,beta_is_LEFT_constant_bookkeeping_NOT_a_transfer_label=True,unknown_physical_gradients_NOT_assigned_zero=True))
        roles.append(dict(role=role,artifact=ref,all_zero_transfer_B_kernels_zero=all(not r['complete_B_Euler_Fourier_kernel']['complete_zero_transfer_Euler_Fourier_kernel']for r in rows)))
    assert full[0]==full[1]
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='CONSTANT_BETA_BREAKING_ZERO_TRANSFER_AND_PHYSICAL_LABEL_GATES_SUPPORTED',all_potential_vertices_scalar_only=True,linear_AST_control_executed_and_rejected=True,all_actual_unknown_scalar_linear_partners_zero=True,roles=roles,complete_B_and_renormalized_contacts_NOT_set_zero=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_b.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
