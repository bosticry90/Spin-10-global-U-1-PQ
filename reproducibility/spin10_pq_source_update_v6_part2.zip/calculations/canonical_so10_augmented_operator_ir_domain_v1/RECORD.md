# V850: actual augmented one-first-Q operator and IR gates

Question: does the ACTUAL selected S+uU+rhoKD retain the structural operator/
joint-IR conditions needed by the admitted common finite construction?
Previous turn made progress: V848/01d3ae53 and V849/e336eaa4 qualified the
complete fixed tensor constructor and arbitrary-source Taylor/beta identity.
Fresh preflight e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5 is clean, no workers.
Main,D:,goalACTIVE. Root writes/runs/Git; two read-only AI source/proof reviews.
LiveAGENTS/charter/solo rules;state113/34of39,flavorpause,HB1/C5blocks,E5/A5open,
seven custodyNOTPASS unchanged. No adoption,protected promotion,branch/worktree,
newbenchmark/parameter,push/publication or outreach.

Freeze ALL643 current F/E GF/source columns at g0/g1,u0/u1,H/M,actualfullD,
S0/S1/U0/U1/KD densities,rawT1 owner and referenceGreen. Keep physical source
Euler programs distinct: packets do NOT contain the potential gradients or
g1 scalar Eulers. Establish their label-preservation premise from the actual
34-term unshifted physicalAST and implemented CONSTANT LINEAR scalar chart,
checking every Add branch and all328 scalar names/substitution equations.
Do not assign unknown shifted-mean/quantum tadpoles zero or rewrite V832.

Critical distinctions: u/rho are CONSTANT bookkeeping labels,not Schwartz
transfers. Epsilon(x) and ordinary means/BV sources ARE genuine test labels.
Classify every differentiated field-flow term by remaining mean/source/epsilon
degree. Derive all mean-independent tangent entries with actual derivative
order. Dfield=epsilon translation must have T D=0; its source flow remains.
Own-coordinate odd-Q Jacobian uses UNWEIGHTED LEFT own-jet derivatives,as
qualified by V845. Do not add a second supertrace factor or count external
source coordinates in the integrated trace. Keep whole differential symbol,
not only zero-jet diagonal. Report nonzero terms rather than assumeJac0.

Every sourcefree quadratic ordinary vertex at zero testfields has zero
transfer,even when proportional to u. Derive its FULL graded Euler/Fourier
kernel before testing momentum degree/cancellations. Use weights wB=wC=wa=1,
wLambda=wx=0. Qualified free edges satisfy pole(i,j)<=wi+wj. A zero-transfer
kernel Vjk of degree>=wj+wk preserves these bounds through EVERY finite chain:
Gij Vjk Gkl has pole<=wi+wl. Physical quadratic potential vertices are scalar/
degree0 and obey this bound; all higher potential terms keep field labels.
No convergence of an infinite mass-chain resummation or physical vacuum limit.

An unlabeled single field tangent Aij of derivative order d has merged bound
2+wi+wj-d. Require<=3 for all actual entries AND adjoints. Labeled tangents
retain separate node momenta. Source-only mean terms(e.gFu0a's Ja) have T0
but remain in full source/mean identities. KD's epsilon-a-C Hessian retains
epsilon transfer: erasing that label would create a critical zero-transfer
ghost mass insertion. Save that complete negative-control witness.

Use V849's complete Hessian identity for betaB; beta is constantodd and does
not supply fake momentum. B is one FIRST-Q insertion,not two independent
tangents. Preserve ordinary currents. Localbeta would require derivative-beta
currents and is outside this constant-label comparison. All novel interactions
must retain genuine labels OR satisfy the zero-transfer weighted bound.

Native uses actual input polynomials/direct left jets; replay derives own
Jacobian and tangent records from qualified complete rawT1 tables and an
independent quadratic-kernel construction. Preserve every row disposition,
complete constant kernels/Jacobian symbols/allcounterexamples. Sensitive
controls remove tangent momentum,eraseepsilontransfer,introduce a quadratic
massless mass and a physical linear AST branch. Report actual blind cases.

One180s afterimports,8GiBsampled/350MiBfloor,64MiBpacket/8MiBartifact. Freeze
sources/copies/inputs/ownerreceipts before computation. Full overflow/failure
is NOTPASS,no silent truncation or resource expansion. Outcomes: supported
structural gates in the declared unshifted A0/g<=1/u/rho family,actual critical
case or missing premise,or boundedincomplete. Separate finalvalidation/E4
beforecommit. Old joint submersion/UV-symbol/IR proof is reused after actual
gates; no fresh loop integrals. V847's finiteprofile scope stays separate.
No fullphysicalbackground/chiral/contact/QAP/A5/E5 or scheme-adoption claim.
