from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-operator-ir-domain-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5'
names=set(json.loads((O/'preparation.json').read_bytes())['sha256'])
for n in['CONTINUATION_B2.md','build_b2.py','compute_breaking_v2.py','execute_breaking_v2.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};names|={'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'+n for n in ['a10_cotangent_adapter.py','a10_executable_action.py','execute_a3_parent_potential_ast.py','frozen_action_ast_a3/A31_embeddings.json']};prep=dict(base_HEAD='e336eaa4a5bc1d30e9f2af9555477c6af4fea7f5',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_b2.json',prep);dump(C/'preparation_b2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_breaking_v2.py')]);dump(O/'capture_b2.json',cap);dump(C/'capture_b2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
