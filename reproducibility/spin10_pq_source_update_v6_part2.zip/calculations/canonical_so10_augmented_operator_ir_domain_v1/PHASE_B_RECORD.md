# Complete the constant-beta breaking-vertex gate

Phase A completed36.453s with no critical tangents/kernels and all known
label gates supported. It is not finalqualification. Before using its IR
conclusion for the SAME betaB functional, audit B's zero-transfer quadratic
part explicitly. Constant beta is not a transfer label or another Q.

For B=sumFE and no literalconstantF/E, a zero-label field-quadratic coefficient
can only arise from sourcefree LINEAR F times sourcefree LINEAR E. Reconstruct
all g0/g1 and first-u H/M convolutions using complete known GF/source E plus
known physical E. Unknown potential/scalar Eulers remain symbolic: the needed
linear F_x partners vanish in ALL sixfieldmaps; directly check this for328
ports. Physical E has minimumarity1 by PhaseA,so higher-degreeF cannot enter
this quadratic projection. No unknown coefficient is assigned zero.

Compute complete projected B density and its Euler/Fourier kernel before
the external odd beta multiplier; that multiplier changes LEFT placement
signs but not zero/soft degree. V849 owns the full beta sign calibration.
Keep all whole-kernel cancellations rather than test isolated bad-looking
terms. rho pieces retain exactly one local epsilon under all permitted
field/source derivatives; verify this in complete K and all1286D operations.
They are labeled even when beta/rho are constant. Ordinary currents remain.

Also execute the in-memory physical linear-AST control (arity1 gives Euler
arity0 and is rejected) and freshly inspect scalar-only/no-derivative support
of all29 potential ASTs. PhaseA's recorded control boolean is a prospective
logical statement; this phase supplies its executed witness. The actual AST
and every original source/capture/contract remain unchanged.

One60s afterimports,8GiBsampled/350MiBfloor,64MiBpacket/8MiBartifact; new
sources/copies/preparation/capture/result. Full failures preservedNOTPASS.
Same authority/scope ceiling; no schemeadoption,parameterchange or newamplitude.
Combined finalverification must rederive these new gate inputs/outputs too.
