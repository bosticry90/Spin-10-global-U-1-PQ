from pathlib import Path
from hashlib import sha256
import ast,gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/antighost-Ward-Hamiltonian-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={}
for prep in O.glob('*preparation*.json'):
    for name,h in read(prep)['input_sha256'].items():
        assert digest(Path(name))==h,(prep.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'hamiltonian_capture.json':'hamiltonian.py','primitive_capture.json':'primitive.py','review_capture.json':'verify.py','e4_capture.json':None}
samples={};seen=set()
for p in O.glob('*capture*.json'):
    cap=read(p);seen.add(p.name)
    assert cap['launch']['creation_after_observation'] and cap['post_run_observations_qualified']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
    if accepted[p.name]:assert cap['command'][-2:]==['-B',str(O/accepted[p.name])]
    else:assert cap['command'][-3:]==['-B','tools/research_check.py','e4']
assert seen==set(accepted) and not list(O.glob('*controller_failure*.json'))
v=read(O/'validation_receipt.json');n=read(O/'hamiltonian_result.json');p=read(O/'primitive_result.json')
assert v['evidence_validation']=='PASS_ALL33_LOCAL_HAMILTONIAN_WARD_GENERATOR_WITH_COMPLETE_PRIMITIVE'
assert n['Hamiltonian_gate_pass'] and n['coordinate_columns_checked']==1286 and n['nonzero_remainder_columns']==0
assert n['native_generator_positions']==1626 and n['source_generator_positions']==33 and n['actual_nonzero_D_columns']==512
assert n['table_sha256']==digest(O/'hamiltonian_tables.json.gz') and p['table_sha256']==digest(O/'primitive_tables.json.gz')
assert p['full_QK_DS_current_zero'] and p['QK_positions']==17168 and p['full_Ward_action_positions']==10712
assert p['field_Hessian_positions']==1992 and p['DS_current_positions']==[669]*4 and p['QK_current_positions']==[0]*4
assert v['quadratic_generator_families_and_gauge_powers']==[[['B','B'],1,720],[['C','a'],0,276]]
assert v['proper_mixed_Ihat_KD_kernel_zero_at_fixed_bosonic_mean_and_KP0'] and v['full_internal_hat_mixing_retained']
assert not v['connected_or_physical_source_or_arbitrary_finite_mixing_curvature_zero'] and not v['primitive_loop_coefficients_evaluated'] and not v['QAP_E5_A5_physical_claim']
assert all(z['elapsed_after_imports']<180 for z in [n,p,v])
text=(O/'RESULT.md').read_text();proof=(O/'DERIVATION.md').read_text()
for token in ['Focused result-to-claim assessment','not new experimental support','integrability alone','source and','No primitive loop coefficient']:
    if token=='No primitive loop coefficient':assert token in text
    else:assert token in text,token
assert 'INSENSITIVE' in proof and 'actual RAW signed BV chart' in proof and 'FIXED ordinary means' in proof
events=read(O/'e4_events.json');steps=[e for e in events if e['event']=='step_finished'];exits=[e['exit_code'] for e in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and sum(z['seconds'] for z in steps)<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='e9de9638115da61d12b5b6f9590c049a76361800' and git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'schema':'DWH_FINAL_EVIDENCE_REVIEW','evidence_validation':v['evidence_validation'],'input_bindings_authenticated':len(bindings),
 'source_copies_equal':len(copies),'accepted_completed_captures':sorted(accepted),'failed_or_incomplete_workers':[],
 'actual_all33_Hamiltonian_and_complete_primitive_qualified':True,'explicit_canonical_component_table_not_claimed':True,
 'primitive_loop_coefficients_evaluated':False,'full_quantum_Ward_measure_QAP_E5_or_physical_claim':False,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,'old_tracked_tree_unchanged':True,
 'largest_accepted_private_sample':max(samples.values()),'largest_all_captures_private_sample':max(samples.values()),
 'memory_samples_not_true_peak':True,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with(O/'final_review_result.json').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
