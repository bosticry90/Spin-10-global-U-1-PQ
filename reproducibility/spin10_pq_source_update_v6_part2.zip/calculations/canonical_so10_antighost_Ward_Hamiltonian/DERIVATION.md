# A single primitive for the actual marked antighost Ward operation

Read the completed native and separate h-polarization receipts. This is
the actual RAW signed BV chart, with the inherited pairing (-1)^p_i.
The standard canonical-chart component table has not been substituted
for it. Hamiltonianity survives the qualified Wick/cotangent coordinate
map, but an explicit canonical primitive, including all epsilon labels,
is still needed before using canonical propagator coefficients.

## Local integration of all marked kernels

For Dminus a_i=epsilon_i in the33 broken directions and Dminus J=-V,
Hamiltonianity requires

 E_phi_i K_D=(-1)^p_i Dminus J_i,
 E_Ji K_D=-(-1)^p_i Dminus phi_i.

Put E_i=(-1)^p_i Dminus J_i. With A and epsilon held external, a local
homotopy representative of the ordinary part is

 K_ord=sum_i integral_0^1 d lambda phi_i E_i(lambda phi;A,epsilon).

The source part is sum_broken Ja_i epsilon_i. Differentiating the
WHOLE candidate, including ordinary jets and derivative epsilon terms,
recovers all1286 field/source columns with zero remainder. There are
1626 density positions:1593 ordinary and33 source. All479 nonzero source
kernels and33 nonzero field shifts are retained. Field-independent
background/epsilon functions are an irrelevant generator ambiguity;
choosing this homotopy representative does not fix a physical tadpole,
vacuum energy or finite quantum normalization.

The separate review first polarizes the whole K_D with independent h
directions, then moves every h derivative to an undifferentiated slot.
It agrees with every native Euler gradient and its zero complement.
The Dplus ordinary primitive would be -K_ord with the same source part;
integrability is therefore INSENSITIVE to orientation. Independently,
the actual delta_a GF-VR=B0 relation fixes the minus sign; reversing it
leaves a nonzero2VR error. Do not call integrability a source-sign test.

## Tree breaking, currents and the true primitive Hessian

The full restricted source action is GF+sum J_i R_i. This is enough for
the required qJa Euler: the physical/matter action has no a argument.
The actual643 field maps and source Euler are differentiated before any
source restriction. They give the complete tree relationship

 QK_D+Dminus S=sum_mu partial_mu current_mu.

QK_D has17168 positions, Dminus S has10712. The four nonzero currents
each have669 positions. There is no unrecorded boundary quotient.
The physical action is not removed: D's only ordinary-field flow is
the antighost shift, so its physical variation is zero by actual support.

The full ordinary-field Hessian has1992 polarized positions. Its root
families are BB (720 quadratic generator positions, gauge power1) and
C a (276 positions,gauge power0). All other597 ordinary linear terms
and33 source terms remain in the primitive, even though their field
Hessian is zero. There are no ordinary-field jet tokens in this chosen
representative; derivative epsilon coefficients remain. This gives an
actual local one-loop insertion operator. It does NOT evaluate the
ordered primitive trace I_KD or permit full G_R interactions to be dropped.
Its overall trace factors must be inherited with the actual canonical
Wick/cotangent transport, not assigned from this raw component table.
In particular vector/scalar/ghost interactions inside G_R can matter
even though no scalar-scalar ROOT occurs in H_KD.

For an odd Hamiltonian primitive, D=X_KD. Thus graded Jacobi gives

 [D,X_K]=X_(D K).

This reduces the entire MGT generator family through one marked
primitive instead of separate unstructured component commutators. It
does not prove a singular quantum-product identity or fixed-operator
Ward restoration. The canonical source/epsilon chart and actual ordered
heat/source products still have to be used for numerical coefficients.

## Formal trace of the transported field operator

Actual D JLambda contains only epsilon (33 positions); D Ja contains
only C epsilon (276 positions). D's ordinary fields only shift a.
Apply this to MGT's complete affine X: [D,X] Lambda is proportional to
C epsilon, and [D,X] a to epsilon. Every other ordinary-field column
is zero. There is no Lambda diagonal derivative in the former or a
diagonal derivative in the latter. Hence its FIELD divergence is zero
for the full A/B tensor family, with the source transport retained.
This is a formal trace statement, not zero ordered regulator insertion.
It coexists with MGT's generally nonzero source-independent trace of X.

## Proper hatted-curvature response: a restricted exact zero

On P=S=barP=barS=KP=0 at FIXED ordinary means, the actual SMA Hessian
and its heat-regulated inverse split into nonmatter and matter blocks.
Keep the full internal P/S hatted mixing inside the matter block; it is
not a strict4D propagator replacement. H_Ihat has only matter entries
on this locus, whereas the freshly measured H_KD has only nonmatter
entries. Therefore BOTH ordered products

 G H_KD G H_Ihat=0,  G H_Ihat G H_KD=0

vanish BEFORE taking any trace, finite part, IR limit or cyclic rearrangement.
This proves the reference PROPER mixed curvature response has no such
kernel on the stated locus. Restoring a mixed propagator/physical source
or matter insertion invalidates the proof. Ihat itself is NOT zero, its
internal loops remain, and connected Legendre mean responses can add
terms that this fixed-mean result does not cover. Independent finite
operator mixing constants are not fixed by this reference zero.

## The next quantum calculation is now specific

The existing common first-probe Ward prescription is

 D Gamma1,R=I_(D S)+I_(V_J R_J)-Gamma1,R,J[V].

Its whole insertion/source-product difference must be retained. The
new primitive offers a common-functional route through S_rho=S+rho K_D
and its full first master variation. Differentiating that identity must
keep the curvature response (with the restricted proper zero above),
the COMPLETE regulated heat response, reference terms and finite local
normalization transport. Classical D=X_KD does not alone set any of
those quantum terms to zero. No unknown RHS is defined by cancellation.

The next competent computation is to transport H_KD and the marked
epsilon/source chart to the canonical propagator basis and evaluate the
ordered primitive/source derivatives for the required connected Ward
projection. Start from its two measured root families and actual coupling
grades. The29-family vector reduction may be relevant now, but only
after this target's support requires it. Do not expand295 profiles merely
because a vector root exists. Retain the complete connected mean/tadpole
terms and existing UV-first IR prescription.

Finite A,kappa,b0,chi4 and IR baselines remain separate/free. This is not
full quantum QAP, source reality, measure/phase,E5/A5, causal/physical-vacuum
or physical Spin(10) viability. Shared action, algebra, software and AI
author remain; no independent external or formal-assistant validation.
