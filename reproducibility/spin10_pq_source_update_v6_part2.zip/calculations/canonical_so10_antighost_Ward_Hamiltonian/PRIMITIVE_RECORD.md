# DWH continuation: complete primitive, tree current and proper curvature response

The native Hamiltonian gate completed with zero remainders in all1286
columns:1626 generator positions,1593 ordinary plus33 source terms.
This is not yet separately qualified. Before qualification derive its
full action/primitive consequences from the SAME GF/source functional.
Native180/review180s,8GiB sampled/350MiB launch/16MiB packet unchanged.

Construct Srestricted=GF+sum J_i R_i from the actual bundle. No physical
Euler expansion is needed: D's only ordinary-field flow is a shift of
a, and the source part of K_D contains only Ja. The physical/matter
action has no a/Lambda argument. Derive QJa=Euler_a Srestricted BEFORE
source restriction and use all actual643 field maps. Check QK_D+D S
against explicit ordinary derivative currents, retaining their complete
polynomials. Do not assume word equality modulo an unrecorded divergence.

Compute the COMPLETE ordinary-field Hessian of K_D by independent h/k
polarizations, and enumerate its actual field-arity/family and source
support. This supplies a concrete primitive for the next loop calculation,
not its evaluated quantum coefficients. The generator representative is
fixed by homotopy up to field-independent background/epsilon terms; that
ambiguity does not choose a physical vacuum or finite renormalization.

Separate review recovers every Euler column by polarizing K_D with h
directions and moving all h jets to an undifferentiated slot by explicit
IBP. Reconstruct D from the original bundle independently of the native
output. Include the source-part and all zero columns, tree orientation,
full Hessian/current data and sign controls. Dplus is canonical too if
its ordinary generator reverses sign; that test is INSENSITIVE to the
Ward orientation and must be reported as such.

Assess the one-loop PROPER mixed Ihat/K_D response only on the bosonic
ordinary-mean locus P=S=KP=0. H_KD is nonmatter; the full Hessian/inverse
and heat reference are block diagonal there, with BOTH P/S hat-mixing
inside the matter block retained. H_Ihat has only matter entries there.
Test the resulting zero ordered product BEFORE any trace/UV/IR limit,
with controls restoring a mixed propagator or matter-source insertion.
This is not Ihat=0, not a connected-product result, not a physical-K
theorem and not removal of arbitrary finite mixing constants.

Write the actual common-functional first-probe identity and preserve
the curvature-response and complete regulator/source terms when
identifying the next quantum input. Do not infer that classical
Hamiltonianity alone sets a quantum Ward breaking to zero. All phases,
finite baselines,authority/physical limits remain unchanged.
