from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/antighost-Ward-Hamiltonian-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
    with p.open('xb') as f:f.write(blob)
try:
    bindings=dict(read(O/'preparation.json')['input_sha256'])
    for name,h in bindings.items():assert digest(Path(name))==h,name
    for name in ['PRIMITIVE_RECORD.md','primitive.py','run_primitive.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    for p in O.iterdir():
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'primitive_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'primitive.py')]);dump(O/'primitive_capture.json',cap);dump(C/'primitive_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED DWH full primitive Hessian and action-current identity',flush=True)
except BaseException:
    dump(O/'primitive_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
