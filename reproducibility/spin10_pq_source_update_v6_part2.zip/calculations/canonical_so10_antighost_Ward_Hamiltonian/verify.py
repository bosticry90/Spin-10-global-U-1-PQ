from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import gzip,importlib.util,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qualified_raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=load(R/'tools/portable_dh_v1/inputs.json.gz');A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs};h_to_n={h:n for n,J,h,k in pairs};h_of={n:h for n,J,h,k in pairs}
tabs=load(O/'hamiltonian_tables.json.gz');K=v.unpack(A,tabs['generator']);source=v.unpack(A,tabs['source_generator']);ordinary=v.unpack(A,tabs['ordinary_generator'])
assert K==u.combine(source,ordinary) and all(n not in sources for g,w in ordinary for n,j in w)
# First vary the complete functional, then integrate the h-jets by parts.
delta={}
for (g,w),c in K.items():
    for at,(n,jets) in enumerate(w):
        if n not in fields:continue
        hh=h_of[n];assert A.parities[hh]==A.parities[n]
        nw=w[:at]+((hh,jets),)+w[at+1:];nw,sgn=A.canonical(nw)
        if sgn:u.put(delta,(g,nw),u.scale_coefficient(c,sgn))
E={n:{} for n in fields}
for (g,w),c in delta.items():
    slots=[(at,n,jets) for at,(n,jets) in enumerate(w) if n in h_to_n];assert len(slots)==1
    at,hh,jets=slots[0];sign=(-1)**(A.parities[hh]*sum(A.parities[n] for n,j in w[:at]))
    coefficient={(g,w[:at]+w[at+1:]):u.scale_coefficient(c,sign)}
    v.merge(E[h_to_n[hh]],u.scale(v.jets(A,coefficient,jets),(-1)**len(jets)))
D={A.index[f'ub{i}']:{(0,((A.index[f'zz_da{i:02}'],()),)):u.ONE} for i in range(12,45)}
for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=u.scale(A.rows(rows,True),-1)
for n,J,h,k in pairs:assert u.scale(E[n],(-1)**A.parities[n])==D.get(J,{})
expected_source={}
for i in range(12,45):
    J=next(J for n,J,h,k in pairs if n==A.index[f'ub{i}'])
    v.merge(expected_source,A.product({(0,((J,()),)):u.ONE},{(0,((A.index[f'zz_da{i:02}'],()),)):u.ONE}))
assert source==expected_source and len(source)==33
native=read(O/'hamiltonian_result.json');assert native['Hamiltonian_gate_pass'] and native['nonzero_remainder_columns']==0
assert native['coordinate_columns_checked']==1286 and native['actual_nonzero_D_columns']==512
assert native['table_sha256']==digest(O/'hamiltonian_tables.json.gz')
print('STAGE separate full h-polarization Euler and all1286 Ward columns',flush=True)
prim=load(O/'primitive_tables.json.gz');pr=read(O/'primitive_result.json')
assert pr['table_sha256']==digest(O/'primitive_tables.json.gz')
elem=lambda n:{(0,((n,()),)):u.ONE};hm={n:elem(h) for n,J,h,k in pairs};km={n:elem(k) for n,J,h,k in pairs}
H=v.act(A,v.act(A,K,km,0,'replay'),hm,0,'replay');assert H==v.unpack(A,prim['field_Hessian'])
QK=v.unpack(A,prim['QK']);DS=v.unpack(A,prim['DS']);curr=[u.combine(v.unpack(A,a),v.unpack(A,b)) for a,b in zip(prim['QK_currents'],prim['DS_currents'])]
div=u.combine(*(v.total(A,p,mu) for mu,p in enumerate(curr)))
assert not u.combine(QK,DS,u.scale(div,-1)) and div
assert all(not p for p in prim['QK_currents'])
assert [len(v.unpack(A,p)) for p in prim['DS_currents']]==[669]*4
old=read(R/'calculations/canonical_so10_relative_contact_transport/primary_v2_result.json')
assert len(DS)==old['actual_full_Ward_Dminus_action_breaking_positions']==10712
assert native['wrong_source_orientation_changes_action'] and native['integrability_alone_does_not_determine_source_sign']
quad=Counter()
for (g,w),c in K.items():
    ff=[n for n,j in w if n in fields]
    if len(ff)!=2:continue
    labels=[]
    for n in ff:
        name=A.names[n];labels.append('B' if name.startswith('B') else 'C' if name.startswith('C') else 'a' if name.startswith(('ub','bar')) else 'other')
    quad[tuple(sorted(labels)),g]+=1
assert {key for key,g in quad}=={('B','B'),('C','a')}
assert pr['ordinary_jet_tokens']==0 and pr['field_Hessian_positions']==1992
assert native['nonminimal_support']=={'JL':[[['epsilon'],33]],'Ja':[[['C','epsilon'],276]]}
# MGT's Lambda field flow depends only on y/Ja, its a flow on JL/a;
# D y=0,DJa~Ceps,DJL~eps,Da~eps. Thus the commutator has no diagonal
# quantum-field derivative. This is a TYPE result, not zero Ireg.
commutator_support={'Lambda':['C','epsilon'],'a':['epsilon']}
assert 'Lambda' not in commutator_support['Lambda'] and 'a' not in commutator_support['a']
# Proper mixed Ihat/KD kernel: zero block product, no trace cyclicity.
b0,b1,m0,m1,h,z0,z1=s.symbols('b0 b1 m0 m1 hat z0 z1',nonzero=True)
Gm=s.Matrix([[m0,h],[h,m1]]).inv();Gb=s.diag(1/b0,1/b1);G=s.diag(Gb,Gm)
HK=s.diag(z0,z1,0,0);Hi=s.diag(0,0,s.Symbol('c0'),s.Symbol('c1'))
assert Gm[0,1]!=0 and G*HK*G*Hi==s.zeros(4) and G*Hi*G*HK==s.zeros(4)
assert G*s.diag(0,0,z0,0)*G*Hi!=s.zeros(4)
Gmix=G.copy();Gmix[0,2]=s.Symbol('mixed_source');assert Gmix*HK*Gmix*Hi!=s.zeros(4) or Gmix*Hi*Gmix*HK!=s.zeros(4)
assert 'Every gauge and Yukawa vertex acts on P' in (R/'calculations/canonical_so10_sterile_matter_action/ACTION_V1.md').read_text()
out={'schema':'DWH_SEPARATE_POLARIZATION_PRIMITIVE_AND_CURVATURE_REVIEW',
 'evidence_validation':'PASS_ALL33_LOCAL_HAMILTONIAN_WARD_GENERATOR_WITH_COMPLETE_PRIMITIVE',
 'independent_polarized_Euler_columns_checked':643,'total_field_source_columns_checked':1286,
 'generator_positions':len(K),'source_generator_positions':33,'nonzero_Hamiltonian_remainders':0,
 'full_field_Hessian_positions':len(H),'quadratic_generator_families_and_gauge_powers':[[list(key),g,count] for (key,g),count in sorted(quad.items())],
 'full_action_QK_DS_current_identity':True,'full_Ward_action_positions':len(DS),'boundary_currents_nonzero_retained':True,
 'integrability_alone_sign_insensitive_tree_sign_separately_checked':True,
 'formal_field_trace_of_Dminus_generator_commutator_zero_by_actual_support':True,'regulator_insertion_zero_not_claimed':True,
 'proper_mixed_Ihat_KD_kernel_zero_at_fixed_bosonic_mean_and_KP0':True,'full_internal_hat_mixing_retained':True,
 'connected_or_physical_source_or_arbitrary_finite_mixing_curvature_zero':False,'primitive_loop_coefficients_evaluated':False,
 'QAP_E5_A5_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with(O/'validation_receipt.json').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
