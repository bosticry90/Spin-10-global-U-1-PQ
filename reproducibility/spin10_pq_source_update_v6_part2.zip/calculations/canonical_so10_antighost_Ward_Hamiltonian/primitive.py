from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qualified_raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'primitive_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs};elem=lambda n:{(0,((n,()),)):u.ONE}
t=json.loads(gzip.decompress((O/'hamiltonian_tables.json.gz').read_bytes()));K=v.unpack(A,t['generator']);D={A.index[name]:v.unpack(A,p) for name,p in t['actual_D'].items()}
assert read(O/'hamiltonian_result.json')['Hamiltonian_gate_pass']
Q={A.index[name]:A.rows(rows) for name,rows in data['master_field_maps'].items()};GF=A.rows(data['gauge_fixing_density']);source={}
for n,J,h,k in pairs:v.merge(source,A.product(elem(J),Q[n]))
S=u.combine(GF,source);anti={n for n,J,h,k in pairs if A.names[n].startswith(('ub','bar'))}
Eanti=v.euler(A,S,anti,'primary')
for n,J,h,k in pairs:
    if n in anti:Q[J]=Eanti[n]
assert all(n in Q or n not in fields|sources for g,w in K for n,j in w)
QK=v.act(A,K,Q,1,'primary');DS=v.act(A,S,D,0,'primary')
def currents(P,V):
    out=[{} for _ in range(4)]
    for (g,w),c in P.items():
        pref=0
        for at,(n,jets) in enumerate(w):
            if jets and V.get(n):
                partial={(g,w[:at]+w[at+1:]):u.scale_coefficient(c,(-1)**(A.parities[n]*pref))}
                for ell,mu in enumerate(jets):
                    term=A.product(v.jets(A,V[n],jets[ell+1:]),v.jets(A,partial,jets[:ell]))
                    v.merge(out[mu],u.scale(term,(-1)**ell))
            pref+=A.parities[n]
    return out
JQ=currents(K,Q);JD=currents(S,D);JJ=[u.combine(a,b) for a,b in zip(JQ,JD)]
div=u.combine(*(v.total(A,p,mu) for mu,p in enumerate(JJ)))
rem=u.combine(QK,DS,u.scale(div,-1))
assert not rem,'COMPLETE_QK_PLUS_DS_CURRENT_REMAINDER'
old=read(R/'calculations/canonical_so10_relative_contact_transport/primary_v2_result.json')
assert len(DS)==old['actual_full_Ward_Dminus_action_breaking_positions']
hmap={n:elem(h) for n,J,h,k in pairs};kmap={n:elem(k) for n,J,h,k in pairs}
dh=v.act(A,K,hmap,0,'primary');H=v.act(A,dh,kmap,0,'primary')
patterns=Counter();arity=Counter();source_arity=Counter();ordinary_jets=0
def kind(n):
    name=A.names[n]
    if n in sources:return 'J'
    if n not in fields:return 'external'
    return 'B' if name.startswith('B') else 'C' if name.startswith('C') else 'a' if name.startswith(('ub','bar')) else 'Lambda' if name.startswith(('L','b')) else 'x'
for (g,w),c in K.items():
    fs=[kind(n) for n,j in w if n in fields];arity[len(fs)]+=1;source_arity[sum(n in sources for n,j in w)]+=1
    ordinary_jets+=sum(bool(j) for n,j in w if n in fields)
    if len(fs)>=2:patterns[tuple(sorted(fs))]+=1
pack=lambda p:u.pack(A,p)
out={'schema':'DWH_FULL_PRIMITIVE_HESSIAN_AND_ACTION_TRANSPORT','full_QK_DS_current_zero':True,
 'full_Ward_action_positions':len(DS),'QK_positions':len(QK),'field_Hessian_positions':len(H),
 'QK_current_positions':[len(p) for p in JQ],'DS_current_positions':[len(p) for p in JD],
 'ordinary_field_arity':[[n,count] for n,count in sorted(arity.items())],
 'source_arity':[[n,count] for n,count in sorted(source_arity.items())],
 'quadratic_and_higher_field_patterns':[[list(k),count] for k,count in sorted(patterns.items())],
 'ordinary_jet_tokens':ordinary_jets,'primitive_loop_coefficients_evaluated':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=gzip.compress((json.dumps({'QK':pack(QK),'DS':pack(DS),'QK_currents':[pack(p) for p in JQ],
 'DS_currents':[pack(p) for p in JD],'field_Hessian':pack(H)},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'primitive_tables.json.gz').open('xb') as f:f.write(blob)
out['table_sha256']=sha256(blob).hexdigest()
with(O/'primitive_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
