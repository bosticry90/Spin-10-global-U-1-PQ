# The corrected Ward operation has one complete local Hamiltonian primitive

The native construction and [separate polarization review](validation_receipt.json)
recover the actual all33-direction Dminus operation from a single local
primitive K_D. All1286 field/source columns agree, including zeros.
The primitive has1626 positions:1593 ordinary plus33 source terms.
This is the actual raw signed BV chart; explicit canonical source and
epsilon transport remains a necessary input to the next loop calculation.

The complete tree relation QK_D+Dminus S is the divergence of four
explicit currents, each with669 positions. QK_D has17168 positions and
the full action breaking10712. The source term was retained before
differentiation. The actual action-chain relation independently fixes
Dminus; integrability alone is insensitive to reversing the source sign.

The full field Hessian of K_D has1992 polarized positions. Its measured
quadratic root families are vector-vector at gauge power1 (720 generator
positions) and ghost-antighost at gauge power0 (276). Linear ordinary
and source terms remain essential even though their field Hessians vanish.
No primitive loop coefficient has yet been evaluated. Absence of a scalar
root does not remove scalar interactions from the full inverse propagator.

## Focused result-to-claim assessment

This result replaces an unspecified source-product correction by a
concrete marked primitive and its complete insertion Hessian. For the
MGT family, [Dminus,X_K]=X_(Dminus K) now supplies a collective operator
reduction. The actual nonminimal kernel support also proves that this
commutator's formal FIELD divergence is zero. That does not make its
ordered heat-regulator contribution zero or construct a quantum measure.

A separate proper-kernel block proof gives a restricted zero for the
mixed Ihat/K_D reference response at FIXED bosonic means and KP0. The
full internal P/S hat mixing is retained. This does not set Ihat itself
to zero, license a physical-source projection, fix finite mixing, or
prove a connected-product zero. The existing common first-probe Ward
identity still requires its whole insertion/source-product difference,
regulator/reference terms and finite normalization transport.

The most informative next calculation is therefore the ACTUAL quantum
primitive response from H_KD, after canonical field/source/epsilon
transport. Derive the target's support and coupling order using its two
root families, then use the existing ordered trace and29-family vector
formula only where indispensable. Preserve nonlinear connected means,
tadpoles and the UV-first IR prescription. Classical Hamiltonianity is
not quantum restoration and no unknown coefficient may be fitted to it.

This advances the missing quantum comparison by identifying its actual
model-based operator and two root sectors, rather than another arbitrary
counterterm ansatz. It is not new experimental support or completion of
Spin(10). All finite normalizations remain symbolic; source reality,
full QAP/measure/E5/A5 and physical viability stay open. Scientific
authority remains state113/34of39. Custody exit2/seven unresolved is NOTPASS.

Native Hamiltonian3.525947s, primitive5.453084s and separate review1.227819s
after imports; no failed workers in this packet. All use180s bounds,
8GiB sampled/350MiB launch/16MiB packet. Final seal records full resource,
byte and one E4/no-fresh checks. Shared inputs/action/chart, exact
software and AI authorship limit the verification; no outside expert,
formal-assistant or empirical validation is claimed.
