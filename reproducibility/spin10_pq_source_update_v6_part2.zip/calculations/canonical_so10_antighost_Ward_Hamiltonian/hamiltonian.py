from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qualified_raw_jet_tools',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k'];fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs}
elem=lambda n:{(0,((n,()),)):u.ONE};D={A.index[f'ub{i}']:elem(A.index[f'zz_da{i:02}']) for i in range(12,45)}
for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=u.scale(A.rows(rows,True),-1)
ordinary={};source={}
for n,J,h,k in pairs:
    if D.get(n):v.merge(source,A.product(elem(J),D[n]))
    grad=u.scale(D.get(J,{}),(-1)**A.parities[n])
    for (g,w),c in grad.items():
        degree=sum(i in fields for i,js in w)
        term=A.product(elem(n),{(g,w):c});v.merge(ordinary,u.scale(term,Fraction(1,degree+1)))
K=u.combine(ordinary,source);E=v.euler(A,K,fields|sources,'primary');X={}
for n,J,h,k in pairs:
    f=u.scale(E[J],-(-1)**A.parities[n]);s=u.scale(E[n],(-1)**A.parities[n])
    if f:X[n]=f
    if s:X[J]=s
remainders={n:u.combine(X.get(n,{}),u.scale(D.get(n,{}),-1)) for n in fields|sources};remainders={n:p for n,p in remainders.items() if p}
GF=A.rows(data['gauge_fixing_density']);B0=A.rows(data['classical_sourcefree_breaking'],True)
Rmaps={A.index[name]:A.rows(rows) for name,rows in data['master_field_maps'].items()};anti={n:p for n,p in D.items() if n in fields}
deltaGF=v.act(A,GF,anti,0,'primary');VR={}
for n,J,h,k in pairs:
    if D.get(J):v.merge(VR,A.product(u.scale(D[J],-1),Rmaps[n]))
assert u.combine(deltaGF,u.scale(VR,-1))==B0 and VR
wrong=u.combine(deltaGF,VR,u.scale(B0,-1));assert wrong
support={'Ja':Counter(),'JL':Counter()}
for n,J,h,k in pairs:
    kind='Ja' if A.names[n].startswith(('ub','bar')) else 'JL' if A.names[n].startswith(('L','b')) and not A.names[n].startswith('B') else None
    if kind is None:continue
    for (g,w),c in D.get(J,{}).items():
        signature=[]
        for i,js in w:
            name=A.names[i]
            signature.append('epsilon' if name.startswith('zz_da') else 'C' if name.startswith('C') else name)
        support[kind][tuple(sorted(signature))]+=1
pack=lambda P:u.pack(A,P)
out={'schema':'DWH_ACTUAL_CORRECTED_WARD_HAMILTONIAN_INTEGRABILITY','Hamiltonian_gate_pass':not remainders,
 'disposition':'EXPLICIT_LOCAL_HAMILTONIAN_WARD_GENERATOR' if not remainders else 'ACTUAL_NONZERO_HAMILTONIAN_INTEGRABILITY_REMAINDER',
 'coordinate_columns_checked':len(fields|sources),'native_generator_positions':len(K),'ordinary_generator_positions':len(ordinary),'source_generator_positions':len(source),
 'actual_nonzero_D_columns':len([p for p in D.values() if p]),'nonzero_remainder_columns':len(remainders),
 'actual_tree_orientation_counts':[len(deltaGF),len(VR),len(B0)],'wrong_source_orientation_changes_action':True,
 'integrability_alone_does_not_determine_source_sign':True,
 'nonminimal_support':{kind:[[list(key),count] for key,count in sorted(counter.items())] for kind,counter in support.items()},
 'full_quantum_Ward_QAP_measure_E5_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
blob=gzip.compress((json.dumps({'generator':pack(K),'ordinary_generator':pack(ordinary),'source_generator':pack(source),
 'actual_D':{A.names[n]:pack(p) for n,p in sorted(D.items()) if p},'remainders':{A.names[n]:pack(p) for n,p in sorted(remainders.items())}},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'hamiltonian_tables.json.gz').open('xb') as f:f.write(blob)
out['table_sha256']=sha256(blob).hexdigest()
with(O/'hamiltonian_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
