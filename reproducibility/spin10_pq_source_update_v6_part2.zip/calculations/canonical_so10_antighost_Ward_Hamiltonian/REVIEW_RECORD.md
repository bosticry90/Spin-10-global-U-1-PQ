# DWH separate h-polarization and primitive-domain review

Freeze before review. Derive all ordinary Euler gradients by a full even
h-variation of K_D followed by moving every h jet to an undifferentiated
slot. Compare against independently parsed corrected D source kernels.
The source term must produce exactly the33 broken-antighost shifts;
all other source derivatives vanish. Native direct Euler and review
polarization are distinct routes, sharing exact coefficient/software
and physical-input limitations.

Check the complete polarized field Hessian by reversed h/k construction,
the QK_D+DS boundary-current equation and the actual source orientation
against the inherited full action breaking. Count actual quadratic
field families AND gauge-coupling powers, without declaring their loop
amplitudes zero. Integrability itself is source-sign insensitive.

Use the resulting actual nonminimal support to infer the FIELD tangent
of [D,X_K] for the entire MGT family: only Lambda<-C*epsilon and a<-
epsilon columns may occur. If those actual support premises fail, do
not claim its field trace zero. This does not imply its ordered regulator
insertion is zero.

Test the proper mixed Ihat/K_D kernel by block support before taking
any trace or limits, keeping the full internal P/S hat mixing. This is
restricted to zero ordinary matter means and physical matter source,
at FIXED ordinary means. Include controls restoring cross blocks or
matter insertion. No connected Legendre sewing, physical-K claim or
arbitrary finite operator mixing is inferred. Common-functional Ward
response still needs the actual primitive loop calculation and regulator
transport; no curvature or regulator term is silently dropped globally.
180s/8GiB sampled/350MiB launch/16MiB packet; all failures preserved.
