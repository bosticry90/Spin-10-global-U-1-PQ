# DWH: actual corrected Ward kernels as a local Hamiltonian derivation

Prospective ate9de9638115da61d12b5b6f9590c049a76361800/main afterMGT
completed. Same active goal turn continues the justified next reduction.
State113/34of39,E5/A5 OPEN,custody2/sevenNOTPASS unchanged. No agents,
newcheckout/remote/adoption/promotion or protected activation.

Question: do ALL33 marked corrected Dminus kernels satisfy the actual
field/source Hamiltonian integrability conditions? Recover them from
the authenticated portable action/source bundle, not a generic gauge
formula. Preserve its RAW signed pairing (-1)^p_i; do not substitute the
standard canonical-chart pairing without its qualified Wick/cotangent
transport. Canonical integrability is coordinate invariant under that
transport; a new explicit canonical component table is not claimed here.

D a_broken=epsilon, all other fields0, D J=-V_J. Integrate the required
ordinary Euler gradients E_phi F=(-1)^p D J by local radial homotopy,
treating background A and marked epsilon as external. Include all field
jets and derivative-epsilon terms. Add the source term sum Ja*epsilon,
then differentiate the whole generator and compare every1286 coordinate
column including zero complements. A nonzero remainder is a classified
failure of this Hamiltonian candidate, not proof of a physical anomaly.
Keep complete remainders; no fit, inverse physical parameter or new action.

Test Dminus source orientation separately by actual delta_aGF-VR=B0.
Dplus may also be Hamiltonian; integrability alone is INSENSITIVE to that
sign. The action-chain check must detect the wrong orientation. Reuse
the already qualified source action/widths and current conventions.

Separate review: vary the whole candidate by independent h-field jets
first, integrate their derivatives by parts, then recover Euler columns.
Use this polarization route instead of the native direct Euler formula.
Check the generator source term and full zero complement. Derive the
consequent canonical [D,X_K]=X_(D K) reduction only if the actual gate
passes. Keep its formal operator status separate from singular quantum
product construction and fixed-operator Ward restoration.

Also classify actual D Ja/JLambda field support before restriction.
Together with MGT's affine flow this determines whether the FIELD trace
of [D,X_K] can vanish for the entire new tensor family. Do not transfer
the earlier special zero Jacobian. Sources remain external; no measure
or global phase theorem. Native180/review180s after imports,8GiB sampled/
350MiB launch/16MiB packet. Freeze input/source bytes; preserve failed and
incomplete runs. E4once/nofresh and raw old/new/state checks beforecommit.
All baselines free; authority ceiling remains below full QAP/E5/viability.
