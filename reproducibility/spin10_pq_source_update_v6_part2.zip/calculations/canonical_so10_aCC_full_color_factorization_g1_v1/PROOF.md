# Direct complete selected aCC reference

Claim TOE-aCC-DIRECT-FULL-COLOR-G1-V1: in the inherited Euclidean A0,
first g10, first u_M, intrinsic 0/1 domain, the selected aCC proper/current
reference has been calculated from actual source operators for every ordered
(a,C_p,C_r) in 45^3. This is a calculation claim, not restoration or E5/A5
acceptance. The V810 proper/current identification and V819 UV-first,
IR-second whole-reference theorem are reused within their qualified scopes.

The full jet first-variation compiler retains all 33 internal M colors,
all four B components and 231 coordinates. Prefix variation equals LEFT
differentiation before Fourier specialization. All six rotation generators
annihilate the appropriate covariant residual for all seven operator states;
the raw quadratic source catalog, with both quantum assignments, separately
reconstructs N, Hg and Hu. Canonical dimensions and actual coupling grades
are checked. Physical E0/E1B are retained; E1x is excluded by inherited
no-return support, not assigned a convenient coefficient. Selected Fu1 T1
vanishes in the complete retained source domain. The full F0 paired root
vanishes by its actual symbolic four-dimensional block; its unsymmetrized
version is nonzero. These facts justify the two retained response roots.

Polarize ghost copies into C_p and C_r and retain a(-p-r), at most one
field from each class. This positive-degree quotient is applied after
source differentiation. It cannot remove a term that later returns to
degree (1,1,1). Equal color labels in different classes remain distinct.
Every one of the 753,571 surviving binary class-word products is checked
against literal inversions among the 135 labeled generators. The same-color
derivative control is nonzero before any actual loop summation; the measured
same-color loop zero therefore does not arise from prematurely identifying
the two ghost copies.

Exact rational-content/sign factorization reconstructs all eight primitive/N
dictionaries coefficient for coefficient with ten real numerical color
tensors and 107 kinematic terms. Couplings, xi, eta_H and i stay in the
kinematic factors. No irrational or coupling division, fitting, assumed
small color basis or free normalization is used. The free zero-mean color
factor is the identity on all 33 internal colors.

With T=G0 N, the exact cube-zero identity gives B=1-T+T^2 and Gbase=B G0.
The two actual roots F1/Hu and Fu0/Hg are contracted as
-(1-E(q)) str[(M_F Gbase) star (H B)]. The star product retains the input
subset shifts, exterior signs, all heat derivatives and noncommuting color
words. Only the numerical color trace is cyclically canonicalized, after
field contraction; no odd or kinematic operator is cyclically moved.
Nineteen color trace words remain. Every odd transverse term cancels per
word before true four-dimensional angular and Gamma/combined-Frullani
integration. The complete pre-angular Laurent symbols of both roots match
each of the three prior direct calculations after numerical specialization.

Generic source covariance plus a local scalar homogeneous quadratic in two
external momenta leaves exactly p^2, p.r and r^2. The collinear calculation
p=x e0, r=y e0 determines all three coefficients separately as x^2, xy,
y^2; q=(v,w,0,0) retains the transverse coordinate and all four B components.
No on-shell condition or two-dimensional angular approximation is used.
The generic V819 distributional bounds supply the whole-reference bridge,
not an interchange of UV/IR limits inferred from three examples.

Every numerical word trace is computed both by sparse matrix products and
literal closed internal-index walks with a different multiplication
association. Both complete arrays are retained. The resulting 91,125
ordered rows explicitly include every zero, every equal-color row, both
response roots, actual g10/xi/eta_H/i/radicals, rational/prime logarithmic
finite coefficients and the complete leading heat profile. The tensor is
saved before reading the prior full leading tensor. All ghost-exchange
identities, all previous finite cases and the complete old 44,550 canonical
leading profiles match. There are 2,610 nonzero ordered finite rows and no
nonzero equal-color rows. They are coefficients, not physical observations.

All constructor workers deny reads of the dependent finite integrability
prediction and assembled remainder. No full finite comparison has yet been
performed here. The next discriminating test is a separately frozen late
comparison of this preserved direct tensor with that prediction, including
all zeros and all independent momentum coefficients. The original direct
full-color requirement has been carried out, not waived or replaced by an
identity-derived prediction.

Shared action, conventions, exact coefficient ring, inherited code and AI
authorship limit independence. Distinct derivatives, literal word/index
calculations and sensitive negative controls check implementations, not
shared physical foundations. This is written analytic/symbolic evidence,
not Lean, outside scientific review or experimental validation. Q Delta=0
integrability would still differ from Delta=0 common restoration. Measure,
QAP, source products, equivalence, full E5/A5, physical viability and the
seven historical custody references remain open. project_state.json stays
unchanged; no scientific promotion or finite normalization is adopted.
