# Complete direct selected aCC color calculation

Starting checkpoint 97a7dd85ed0b26579b2cf0deaefa8e7b6662cecd / V820.
D:/Codex-Projects/ToE-Next; controls under D:/Codex-Research/ToE-Next/
research-control-records/aCC-full-color-factorization-g1-v1-2026-11-07.

The direct full-color finite reference is now computed for all 91,125
ordered (a,C_p,C_r) rows, including the exact zero complement. There are
2,610 nonzero finite rows: H_MM 526, M_HM 526, M_MH 526, M_MM 1,032.
All other sectors and every same-color ghost row vanish after summation.
The complete ghost-exchange and old leading-profile comparisons match;
all nineteen color traces agree with literal closed-index sums. The three
earlier finite examples and both full pre-angular scalar roots also match.

Primary executed stages: source compiler 86.984s/180, exact factorization
16.399s/120, universal kinematic contraction 8.766s/300, numerical full
color tensor 24.123s/300, after imports. All completed without a failed
scientific worker. Draft syntax/boolean reporting fixes occurred before
their affected freezes and executions. Sources, preparations, full captures
and complete artifacts are preserved. Bounds are 8GiB sampled private
allocation, 350MiB launch commit floor, 64MiB packet, 10MiB per artifact;
sampled observations are not true or nested peak measurements.

Owning artifact direct_full_color_reference.json.gz:
SHA256 0d39b330526182849222ee738623ae2c984d5f6298b85f0eb8512688f4bbeacb,
296,644 bytes. Normalization suppresses u_M/(16pi^2), retaining actual
g10, xi, eta_H, i and radical coefficients. Finite local quadratic
coefficients use p^2, p.r and r^2. Whole-reference UV-first/IR-second proof
and selected proper/current identification are reused from V819 and V810.

Ten exact source-derived color tensors and 107 kinematic terms reduced
the calculation to nineteen numerical trace words without reducing its
scientific target. All 753,571 polarized-word signs, full-source rotation
identities, Euler/raw-T2 equality and prior subset-shift specializations
pass. Omitted odd crossings/vector components, wrong commuting shifts and
premature same-color collapse have preserved sensitive controls. The
unsymmetrized F0 control is nonzero although its paired root vanishes.

The finite integrability prediction was denied to all constructor workers.
This packet does not claim its full finite comparison has passed. Preserve
and validate this own tensor, then separately compare every color/momentum/
logarithmic coefficient with V814V2. A match would address the selected
source integrability test, not by itself common symmetry restoration.
No coefficient was selected to force a consistency remainder to vanish.

Final receipt owns fresh replay coverage, resource observations, E4 exits
and validation disposition; execution completion is not scientific adoption.
Scientific authority remains state113 / 34 of 39, E5/A5 open. Seven custody
references remain NOTPASS. Shared action/software/AI authorship constrain
the demonstrated independence. The result demonstrates efficient exact
full-target factorization and adversarial implementation checking, not
empirical Spin(10) viability or completion of the overall investigation.
