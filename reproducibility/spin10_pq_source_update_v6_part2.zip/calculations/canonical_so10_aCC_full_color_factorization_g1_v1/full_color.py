from pathlib import Path
from itertools import product
from fractions import Fraction as Fr
import gc,importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('direct_full_color_word_data',Path(__file__).resolve().with_name('word_ring.py'));w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w);f=w.f;J=w.J;A=w.A;O=f.O;R=f.R
def clean(P):return{k:c for k,c in P.items()if c}
def token_matrix(library,tid,mask):
 row=library[tid];classes=[b for b in range(3)if mask&(1<<b)];assert len(classes)==row['arity'];out={}
 for colors,packed in row['all_real_color_entries']:
  ext=[-1,-1,-1]
  for cl,c in zip(classes,colors[2:]):ext[cl]=c
  coef=A.decode_coeff(packed);assert all(key[:3]==(0,0,0)and key[3]<16 for key,val in coef.terms);out[colors[0],colors[1],tuple(ext)]=coef
 return out
def merge(a,b):
 assert all(x<0 or y<0 for x,y in zip(a,b));return tuple(max(x,y)for x,y in zip(a,b))
def multiply(P,Q):
 by={};out={}
 for(s,t,ee),d in Q.items():by.setdefault(s,[]).append((t,ee,d))
 for(r,s,ex),c in P.items():
  for t,ee,d in by.get(s,[]):key=r,t,merge(ex,ee);out[key]=out.get(key,f.zero)+J.times(c,d)
 return clean(out)
def trace_pair(P,Q):
 by={};out={}
 for(s,r,ee),d in Q.items():by.setdefault((s,r),[]).append((ee,d))
 for(r,s,ex),c in P.items():
  for ee,d in by.get((s,r),[]):key=merge(ex,ee);assert min(key)>=0;out[key]=out.get(key,f.zero)+J.times(c,d)
 return clean(out)
def literal_trace(matrices):
 by=[]
 for M in matrices:
  dd={}
  for(r,s,ee),c in M.items():dd.setdefault((r,s),[]).append((ee,c))
  by.append(dd)
 out={};terms=0
 if len(by)==2:
  for r,s in product(f.r.IC,repeat=2):
   for ex,c in by[0].get((r,s),[]):
    for ee,d in by[1].get((s,r),[]):key=merge(ex,ee);out[key]=out.get(key,f.zero)+J.times(c,d);terms+=1
 elif len(by)==3:
  for r,s,t in product(f.r.IC,repeat=3):
   aa=by[0].get((r,s),[]);bb=by[1].get((s,t),[]);cc=by[2].get((t,r),[])
   if not aa or not bb or not cc:continue
   for ex,c in aa:
    for ee,d in bb:
     for ff,e in cc:key=merge(merge(ex,ee),ff);out[key]=out.get(key,f.zero)+J.times(c,J.times(d,e));terms+=1
 else:raise AssertionError('UNEXPECTED_COLOR_TRACE_WORD_LENGTH')
 return clean(out),terms
def enc_trace(P):return[[*ex,A.encode_coeff(c)]for ex,c in sorted(P.items())]
def enc_finite(P):return[[*key,A.encode_coeff(c)]for key,c in sorted(P.items())]
def accumulate(target,ext,key,value):
 if not value:return
 acc=target.setdefault(ext,{});acc[key]=acc.get(key,f.zero)+value
def finish(P):return{k:clean(v)for k,v in P.items()if clean(v)}
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in f.read(O/'full_color_preparation.json')['sha256'].items():assert f.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 fr=f.read(O/'factor_result.json');factor=f.load(O/fr['basis_artifact']['file']);library=factor['color_tensor_library'];wr=f.read(O/'word_result.json');wordpacket=f.load(O/wr['artifact']['file']);words=[tuple(tuple(token)for token in word)for word in wordpacket['all_color_words']];assert len(words)==wr['distinct_color_trace_words']==19;traces={};matrixcache={};traceart=[]
 for at,word in enumerate(words):
  ms=[]
  for token in word:
   if token not in matrixcache:matrixcache[token]=token_matrix(library,*token)
   ms.append(matrixcache[token])
  primary=trace_pair(ms[0],ms[1])if len(ms)==2 else trace_pair(multiply(ms[0],ms[1]),ms[2]);peer,terms=literal_trace(ms)
  artifact=f.save('color_trace_'+str(at).zfill(2)+'.json.gz',dict(color_word=[list(t)for t in word],complete_sparse_trace=enc_trace(primary),literal_peer_trace=enc_trace(peer),literal_closedwalk_terms=terms,full_external_domain=[45,45,45],all_unlisted_positions_exact_zero=True,all_coefficients_equal=primary==peer))
  assert primary==peer,('LITERAL_COLOR_TRACE_MISMATCH',at);traces[word]=primary;traceart.append(dict(color_word=[list(t)for t in word],artifact=artifact,nonzero_trace_positions=len(primary),literal_closedwalk_terms=terms));print('STAGE color_trace '+str(at)+' positions='+str(len(primary))+' literal_terms='+str(terms),flush=True)
 branchvalues=[];total={};leadtotal={}
 for br in wr['branches']:
  source=f.load(O/br['artifact']['file']);fin={};lead={}
  for item in source['all_word_integrals']:
   word=tuple(tuple(t)for t in item['color_word']);color=traces[word]
   for x,y,ln,packed in item['finite_hard_coefficients']:
    coeff=A.decode_coeff(packed)
    for ext,c in color.items():accumulate(fin,ext,(x,y,ln),J.times(coeff,c))
   for e,packed in item['leading_profile']:
    coeff=A.decode_coeff(packed)
    for ext,c in color.items():accumulate(lead,ext,e,J.times(coeff,c))
  fin=finish(fin);lead=finish(lead)
  for ext,P in fin.items():
   for key,c in P.items():accumulate(total,ext,key,c)
  for ext,P in lead.items():
   for e,c in P.items():accumulate(leadtotal,ext,e,c)
  branchvalues.append(dict(branch=br['branch'],full_sparse_finite=[[*ext,enc_finite(P)]for ext,P in sorted(fin.items())],full_sparse_leading_profile=[[*ext,[[e,A.encode_coeff(c)]for e,c in sorted(P.items())]]for ext,P in sorted(lead.items())],all_unlisted_45cubed_positions_exact_zero=True))
 total=finish(total);leadtotal=finish(leadtotal);rows=[];sectors={};nonzero=nonzero_same=0
 for aa,cp,cr in product(range(45),repeat=3):
  ext=cp,cr,aa;P=total.get(ext,{});L=leadtotal.get(ext,{});radial=sum((J.times(c,J.constant(Fr(1,e)))for e,c in L.items()),f.zero);rows.append([aa,cp,cr,enc_finite(P),[[e,A.encode_coeff(c)]for e,c in sorted(L.items())],A.encode_coeff(radial)]);nonzero+=bool(P);nonzero_same+=bool(P)and cp==cr;key=('H'if aa<12 else'M')+'_'+('H'if cp<12 else'M')+('H'if cr<12 else'M');dd=sectors.setdefault(key,dict(rows=0,nonzero_finite_rows=0));dd['rows']+=1;dd['nonzero_finite_rows']+=bool(P)
  assert all(x+y==2 and ln in[0,2,3]and all(key[0]==1 for key,val in c.terms)for(x,y,ln),c in P.items())
 assert len(rows)==91125
 # Freeze complete own values BEFORE the old full leading numerical comparison.
 ownartifact=f.save('direct_full_color_reference.json.gz',dict(schema='DIRECT_ALL91125_POLARIZED_ACC_REFERENCE_TENSOR_V1',all91125_ordered_rows=rows,row_columns=['a','C_p','C_r','finite_x_y_logprime_coefficients','leading_qminus2_profile','leading_radial_1_over_t'],all_branch_values=branchvalues,color_trace_artifacts=traceart,all_zero_complement_explicit=True,nonzero_finite_rows=nonzero,nonzero_same_color_rows=nonzero_same,sector_counts=sectors,normalization='u_M^1/(16pi^2) suppressed; g10/xi/eta_H/i/radicals RETAINED; finitep²/p.r/r², leading1/t',whole_reference_proof='REUSED_QUALIFIED_V819_GENERIC_SCOPE',finite_integrability_prediction_not_read=True))
 exchanged=[];leadex=[]
 for aa,cp,cr in product(range(45),repeat=3):
  ex=cp,cr,aa;other=cr,cp,aa;P=total.get(ex,{});Q=total.get(other,{})
  for key in set(P)|{(y,x,ln)for x,y,ln in Q}:
   x,y,ln=key;diff=P.get(key,f.zero)+Q.get((y,x,ln),f.zero)
   if diff:exchanged.append([aa,cp,cr,x,y,ln,A.encode_coeff(diff)])
  for e in set(leadtotal.get(ex,{}))|set(leadtotal.get(other,{})):
   diff=leadtotal.get(ex,{}).get(e,f.zero)+leadtotal.get(other,{}).get(e,f.zero)
   if diff:leadex.append([aa,cp,cr,e,A.encode_coeff(diff)])
 old=f.load(O.parent/'canonical_so10_aCC_full_UV_tensor_g1_v1/generic_full_tensor_v2.json.gz');expected={}
 for u,mask,q,e,packed in old['full_aCC_symbol']:
  mask=int(mask,16)if isinstance(mask,str)else mask;ghost=[c for c in range(45)if mask&(1<<c)];ant=[a for a in range(45)if mask&(1<<(45+a))];assert u==1 and q==-2 and len(ghost)==2 and len(ant)==1;cp,cr=ghost;aa=ant[0];c=A.decode_coeff(packed);expected[cp,cr,aa,e]=c;expected[cr,cp,aa,e]=-c
 ownlead={(cp,cr,aa,e):c for(cp,cr,aa),P in leadtotal.items()for e,c in P.items()};leading_diff=[[ *key,A.encode_coeff(ownlead.get(key,f.zero)-expected.get(key,f.zero))]for key in sorted(set(ownlead)|set(expected))if ownlead.get(key,f.zero)!=expected.get(key,f.zero)]
 calibrations=[]
 for name,ext in[('base',(0,14,13)),('H_antighost',(13,14,0)),('all_M',(13,14,12))]:
  own=f.load(O.parent/'canonical_so10_aCC_hard_finite_heat_g1_v1'/('hard_total_'+name+'.json.gz'));expect={tuple(row[:3]):A.decode_coeff(row[3])for row in own['actual_finite_hard_coefficients']};diff=f.add(total.get(ext,{}),f.scale(expect,-f.one));trace_expected={tuple(tuple(t)for t in row[0]):A.decode_coeff(row[1])for row in next(case for case in wordpacket['all3_full_preangular_calibrations']if case['case']==name)['all_source_color_traces']};assert all(traces[word].get(ext,f.zero)==c for word,c in trace_expected.items()),(name,'FIXED_TRACE_CALIBRATION');calibrations.append(dict(case=name,complete_difference=enc_finite(diff),all19_color_traces_match=True))
 passed=not exchanged and not leadex and not leading_diff and all(not row['complete_difference']for row in calibrations)
 checks=f.save('full_color_checks.json.gz',dict(all91125_ghost_exchange_finite_differences=exchanged,all91125_ghost_exchange_leading_differences=leadex,all_old_complete_leading_profile_differences=leading_diff,previous3case_calibrations=calibrations,all19_literal_closedwalk_traces_equal=True,own_full_tensor_saved_before_old_leading_read=True,scientific_disposition='GATES_MATCH'if passed else'MISMATCH_NOTPASS',finite_integrability_prediction_NOT_READ=True))
 out=dict(schema='DIRECT_COMPLETE_ACC_COLOR_REFERENCE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all91125_ordered_finite_rows_and_zero_complement=True,all19_complete_color_traces_literal_peer_equal=True,nonzero_finite_rows=nonzero,nonzero_same_color_rows=nonzero_same,all_finite_ghost_exchange=not exchanged,all_leading_ghost_exchange=not leadex,complete_old44550_leading_profile_match=not leading_diff,all3_previous_finite_and_all19_trace_calibrations=all(not row['complete_difference']for row in calibrations),scientific_disposition='GATES_MATCH'if passed else'MISMATCH_NOTPASS',full_finite_prediction_read=False,artifact=ownartifact,checks_artifact=checks,color_trace_artifacts=traceart,sector_counts=sectors,common_restoration_E5_A5_not_claimed=True,elapsed_after_imports=time.perf_counter()-tick);f.dump(O/'full_color_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
