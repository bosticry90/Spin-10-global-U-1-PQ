# Complete numerical color tensor from direct word kernels

Universal direct calculation completed8.766s/300,19 color trace words,
both roots/complete pre-angular3case calibrations exact. This stage evaluates
ALL numerical traces and assembles ALL91125 ordered(a,c_p,c_r) rows,
including same-color and zero complement. Firstg/u_M,all33 internalM/all4B,
same EuclideanA0/intrinsic01 and V819 whole-reference proof. No change to
the earlier direct FULL-COLOR scientific requirement.

Freeze300s afterimports/8GiBsampled/350MiBfloor/64MiB completepacket/
10MiBartifact. Deny entire dependentprediction folder and assembled remainder
throughout. No coefficientfit/normalizationchoice/truncation/retry or silent
resource expansion. Freeze source/inputs, preserve failed/unfinished sources
and complete captures. Existing source/factor/word work stays immutable.

For each ordered numerical color word, attach its class-slot labels to the
exact tensor library, multiply sparse33-color matrices, then close trace.
At most3 tensors, positive total external degree3. Do not add Grassmann or
supertrace signs here: they are already in the universal kinematic algebra.
Independently calculate every trace coefficient by literal closed quantum
index walks, without the primary intermediate product. Save complete sparse
word traces with domain45^3 and explicit exact-zero convention. Missing
entries mean exhaustively evaluated zero, not unknown. On disagreement save
both complete arrays before failing.

Multiply each trace by both root's exact universal rational/log coefficients
and full leading profile. Keep g/xi/eta_H/i/radicals, not only the widths seen
in three cases. Save full branch values and EVERY ordered output row BEFORE
reading the old numerical leading tensor. Check full ghost exchange
P_acd(p,r)=-P_adc(r,p), all same-color consequences, all coefficient types,
and each previous direct case. Then late-compare the COMPLETE leading
q^-2 profile against the qualified V81644550canonical tensor with both
ordered ghost assignments; no extra2 or half. Preserve all differences.

This stage still does NOT read the finite integrability prediction. A later
separate bounded comparison may read it only after the complete own finite
tensor is frozen/verified. If a scientific gate mismatches, retain completed
calculation and explicit MISMATCH_NOTPASS disposition; authentication of
failure is not scientific PASS. Finalvalidation and localcommit separate.
Commonrestoration/E5A5/physicalviability/overallgoal remain open regardless.
