# Exact numerical color basis discovery

Dependent on compile_result COMPLETED. Full generic jet/source/rawT2/
Lorentz/case checks remain frozen; no new amplitudes supplied. Freeze this
stage120s afterimports/8GiB sampled/350MiB floor/64MiBpacket/10MiBartifact.
Deny prediction/remainder inputs again. Failure/exhaustion incomplete, preserve
sources/capture, no automatic retry/expansion/truncation.

For each primitive block (state,rowtype,coltype,meanclassmask,v/w/x/y monomial)
split exact coefficientg,xi,eta_H and imaginarybit into kinematic labels.
The remaining color array is a real rational-radical tensor indexed by two
internal33 colors and0/1/2 external45 color slots. Normalize only by its
common RATIONAL content/sign using numeratorgcd/denominatorlcm; no coupling,
width or irrational division, guessed invariant basis or fitted coefficient.
Deduplicate exact arrays. Start with verified33-color identity. Reconstruct
EVERY original primitive coefficient from color library/kinematic descriptors
and compare exact dictionaries. Report every actual tensor and coefficient.
Do not omit extra zero-mean tensors if they occur. If basis>64, exact
factorization is still mathematical evidence but universal-loop cost must
be reassessed rather than silently dropping tensors. This64 is an engineering
decision threshold, not a scientific acceptance requirement or scope limit.

Prove the positive polarized class algebra: at most1 p,1 r,1 a. Source
Euler/T1/T2 happen BEFORE this restriction; subsequent operator products
cannot lower class counts. Full135generator order is p0..44,r0..44,a0..44.
Exhaust all753571 NONZERO binary products in the class quotient and compare
CLASS-bit sign to literal full-generator word inversion sign. Preserve the
complete fixed-width binary table (6bytes perrow:maskleft,maskright,
color_p+1,color_r+1,color_a+1,signpositive), not sampled cases. Within-class
degree2 is intentionally outside this target and not the full90-generator
constantmean algebra; no old sign failure is relabeled or erased.

Same-color derivative control C13 d0²C13 a12 must give x²-y² in the
polarized classes. Collapsing p/r by color alone would falsely erase it.
Retain wrong-class-order counterexample. Empty numerical color trace is33,
not1, for a later loop; color basis alone is not a Gaussian contraction.

Record basis size/arity, kinematic terms, color entries, compression, exact
reconstruction and whether zero-mean color is ONLY identity. These are
computational facts, not progress fractions or physical predictions. No
fullcolorfinite tensor/sourcecompatibility/commonrestoration/E5A5 claim.
Further universal color-word loop and full zero-complement comparison need
their own bounded freeze and complete scientific verification.
