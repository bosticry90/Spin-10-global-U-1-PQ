from pathlib import Path
import gc,importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('full_color_factor_tools',Path(__file__).resolve().with_name('factor_tools.py'));f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f);r=f.r;J=f.J;A=f.A;O=f.O;R=f.R
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in f.read(O/'preparation.json')['sha256'].items():assert f.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pk=f.load(base/'native_inputs.json.gz');assert pk==f.load(base/'replay_inputs.json.gz');states={k:{n:J.decode(P)for n,P in rows}for k,rows in pk['states'].items()};phys={k:{n:J.decode(P)for n,P in rows}for k,rows in pk['physical'].items()};matrices={};jets={};journals=[];crossing={};stats={};rotation_checks=[]
 for label in['E0','E1','Eu0_1','F0','F1','Fu0_1','Fu1_1']:
  M={};T={};bad={}
  for n in r.FIELDS:
   P=states[label][n]
   if label=='E0'and n<508:P=r.w.plus(P,phys['P_E0'].get(n,{}))
   if label=='E1'and n<180:P=r.w.plus(P,phys['P_E1_gauge'].get(n,{}),phys['P_E1_scalar'].get(n,{}))
   P={ww:c for ww,c in P.items()if all(nn<643 for nn,js in ww)};native,wrong,journal=f.full_first(P);T[n]=native;bad[n]=f.add(wrong,f.scale(native,-f.one))
   for key,part in f.project(native,n).items():
    acc=M.setdefault(key,{})
    for colors,c in part.items():acc[colors]=acc.get(colors,f.zero)+c
   journals.append(dict(state=label,output=n,source_free_math_sha256=f.sha256(json.dumps(J.encode(P),sort_keys=True).encode()).hexdigest(),all_selected_word_positions=journal))
  M=f.eclean(M)
  for a in range(4):
   for b in range(a+1,4):
    assert all(not f.covariance_residual(T,n,a,b)for n in r.FIELDS),(label,a,b,'GENERIC_JET_LORENTZ_FAILURE');rotation_checks.append(dict(state=label,plane=[a,b],all231_residuals_zero=True))
  degree=int(label in['E1','F1','Fu1_1'])
  for(rk,ck,m,ex),P in M.items():
   di=2 if rk==4 else 1;dj=2 if ck==4 else 1;assert(di+dj+m.bit_count()+sum(ex)==4)if label.startswith('E')else(dj+m.bit_count()+sum(ex)==di+1),(label,'GENERIC_CANONICAL_DIMENSION')
   assert all(key[0]==degree for c in P.values()for key,val in c.terms),'GENERIC_COUPLING_GRADE';assert all(len(colors)==2+m.bit_count()for colors in P)
  matrices[label]=M;jets[label]=T;crossing[label]=bad;stats[label]={**f.metrics(M),'full_jet_words':sum(len(P)for P in T.values()),'wrong_odd_crossing_words':sum(len(P)for P in bad.values())};print('STAGE '+label+' '+json.dumps(stats[label],sort_keys=True),flush=True)
 assert len(rotation_checks)==42 and any(q['wrong_odd_crossing_words']for q in stats.values())
 wrongF={n:P for n,P in jets['F0'].items()if not(n<180 and n%4==3)};badrot={n:f.covariance_residual(wrongF,n,0,3)for n in r.FIELDS};badrot={n:P for n,P in badrot.items()if P};assert badrot
 N={key:P for key,P in matrices['E0'].items()if key[2]};assert all(m.bit_count()==1 and((rk==4 and ck in[5,6])or(ck==4 and rk in[5,6]))for rk,ck,m,ex in N)
 cat=f.load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/native_aCC_catalog.json.gz');assert cat==f.load(O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1/replay_aCC_catalog.json.gz');raw={};rawjourn=[]
 for row in cat['ordinary']:
  if not((row['owner']=='GF_original'and row['g']in[0,1])or(row['owner']=='GF_probe1'and row['g']==0)):continue
  M,jj=f.quadratic(row['selected']);label='N'if row['owner']=='GF_original'and row['g']==0 else'Hg'if row['owner']=='GF_original'else'Hu';raw[label]=f.eadd(raw.get(label,{}),M);rawjourn.append(dict(owner=row['owner'],g=row['g'],u=row['u'],all_raw_quantum_assignments=jj))
 assert raw=={'N':N,'Hg':matrices['E1'],'Hu':matrices['Eu0_1']},'FULL_POLARIZED_EULER_RAW_T2_MISMATCH'
 print('STAGE full45_polarized_primitive_Euler_raw_T2_equal',flush=True)
 cases=[];wrongshift=[]
 for name,cs,aa in[('base',[0,14],13),('H_antighost',[13,14],0),('all_M',[13,14],12),('same_color',[13,13],12)]:
  old=f.load(O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1'/('polarized_'+name+'.json.gz'));checked=[]
  for label,M in matrices.items():
   u=int(label in['Eu0_1','Fu0_1','Fu1_1']);own=f.specialize(M,cs,aa,u);expected=f.old_plane(old['matrices'][label]);assert own==expected,(name,label,'ALL_SUBSET_OLD_PRIMITIVE_SPECIALIZATION');bad=f.specialize(M,cs,aa,u,True);difference=f.add(bad,f.scale(own,-f.one));wrongshift.append(dict(case=name,state=label,complete_wrong_commuting_shift_difference=[[*key[:-1],list(key[-1]),A.encode_coeff(c)]for key,c in sorted(difference.items())]));checked.append(label)
  cases.append(dict(case=name,all7_states_all_valid8_shifts_equal=checked));print('STAGE generic_specialization '+name,flush=True)
 assert any(row['complete_wrong_commuting_shift_difference']for row in wrongshift)
 sourceart=f.save('generic_source_jet_checks.json.gz',dict(all_generic_jet_T1={label:[[n,J.encode(P)]for n,P in sorted(T.items())]for label,T in jets.items()},all42_Lorentz_generator_checks=rotation_checks,wrong_quantum_crossing_complete_differences={label:[[n,J.encode(P)]for n,P in sorted(T.items())if P]for label,T in crossing.items()},wrong_F0_component_complete_rotation_residual=[[n,J.encode(P)]for n,P in sorted(badrot.items())],all_source_word_positions=journals,raw_T2_assignment_positions=rawjourn))
 primitiveart=f.save('generic_primitive_inputs.json.gz',dict(schema='FULL45_POLARIZED_CLASS_PRIMITIVE_SOURCE_SYMBOLS_V1',variables=['v','w','x','y'],classes=['C_p','C_r','a_minus_p_minus_r'],internal_colors=r.IC,all4_B_components=True,matrices={label:f.encode(M)for label,M in matrices.items()},N=f.encode(N),four_old_case_all_subset_specializations=cases,complete_wrong_shift_differences=wrongshift,statistics=stats,no_color_tensor_factorization_or_loop_yet=True))
 out=dict(schema='FULL45_POLARIZED_SOURCE_PRIMITIVE_COMPILER_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all45_external_colors_and_same_color_polarizations=True,all33_internal_M_all4B_231fields=True,prefix_LEFT_full_jet_T1_equal=True,all42_generic_source_jet_Lorentz_identities=True,full_Euler_and_raw_quadratic_T2_equal=True,all4_old_cases_all7_states_all_valid8_subset_shifts_equal=True,grades_dimensions_and_positive_class_filtration=True,statistics=stats,source_artifact=sourceart,artifact=primitiveart,prediction_inputs_denied=True,factorization_and_full_color_loop_not_computed=True,elapsed_after_imports=time.perf_counter()-tick);f.dump(O/'compile_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
