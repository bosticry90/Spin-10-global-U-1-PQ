from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-full-color-factorization-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(420,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','factor_preparation.json','word_preparation.json','full_color_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 primary=[];artifacts=[];fresh=[]
 for script,resname,capname,limit in[('compile_full.py','compile_result.json','compile_capture.json',180),('discover_factor.py','factor_result.json','factor_capture.json',120),('universal_kernel.py','word_result.json','word_capture.json',300),('full_color.py','full_color_result.json','full_color_capture.json',300)]:
  cap=read(O/capname);res=read(O/resname);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['execution_state']=='COMPLETED'and res['elapsed_after_imports']<limit;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);primary.append((cap,res))
  sp=importlib.util.spec_from_file_location('fresh_'+resname.replace('.','_'),O/script);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
  def compare_save(name,z):
   blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),('FRESH_ARTIFACT_DIFFERS',name);artifacts.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
  def compare_binary(name,raw):
   blob=gzip.compress(raw,mtime=0);assert blob==(O/name).read_bytes(),('FRESH_BINARY_DIFFERS',name);artifacts.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob),uncompressed_bytes=len(raw))
  def compare_dump(path,z):
   assert path==O/resname;assert{k:v for k,v in res.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'},resname;assert z['elapsed_after_imports']<limit;fresh.append(dict(result=resname,seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
  m.f.save=compare_save;m.f.dump=compare_dump
  if script=='discover_factor.py':m.save_binary=compare_binary
  m.main();gc.collect()
 assert len(fresh)==4 and len(artifacts)==len(set(artifacts))==30,(len(fresh),len(artifacts))
 full=primary[-1][1];assert full['scientific_disposition']=='GATES_MATCH'and full['all19_complete_color_traces_literal_peer_equal']and full['all_finite_ghost_exchange']and full['all_leading_ghost_exchange']and full['complete_old44550_leading_profile_match']and full['all3_previous_finite_and_all19_trace_calibrations']and not full['full_finite_prediction_read']
 packet=load(O/full['artifact']['file']);rows=packet['all91125_ordered_rows'];assert len(rows)==91125 and[(row[0],row[1],row[2])for row in rows]==[(a,c,d)for a in range(45)for c in range(45)for d in range(45)];assert sum(bool(r[3])for r in rows)==2610 and not any(r[3]for r in rows if r[1]==r[2]);assert sum(row['rows']for row in full['sector_counts'].values())==91125
 for name in['compile_full.py','discover_factor.py','universal_kernel.py','full_color.py']:
  text=(O/name).read_text(encoding='utf-8');assert'aCC_reference_integrability_prediction'in text and'sys.addaudithook(guard)'in text
 print('STAGE fresh4results_30completeartifacts_full91125tensor_and_zero_complement_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();pp=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=pp.returncode,seconds=time.perf_counter()-et,stdout=pp.stdout,stderr=pp.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert pp.returncode==0
 events=[json.loads(x)for x in pp.stdout.splitlines()if x.strip()];exits=[e['exit_code']for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(e for e in events if e['event']=='step_finished'and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V821.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='DIRECT_COMPLETE_ACC_COLOR_REFERENCE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_DIRECT_FULL_COLOR_REFERENCE',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,failed_or_incomplete_workers=0,fresh_replays=fresh,complete_artifacts_freshly_recomputed=artifacts,all91125_ordered_rows_and_zero_complement_verified=True,nonzero_finite_rows=2610,nonzero_same_color_rows=0,full_leading_profile_and_ghost_exchange_match=True,all19_literal_color_trace_peers_match=True,finite_integrability_prediction_not_read=True,qualified_V810_V819_bridges_reused_not_rederived=True,shared_action_software_AI_author_not_external_independence=True,common_restoration_E5_A5_viability_not_claimed=True,largest_primary_sampled_private_bytes=max(x['private_bytes']for cap,res in primary for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','nonzero_finite_rows','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
