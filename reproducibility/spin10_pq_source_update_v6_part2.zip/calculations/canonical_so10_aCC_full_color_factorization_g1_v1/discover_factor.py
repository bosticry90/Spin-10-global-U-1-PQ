from pathlib import Path
from fractions import Fraction as Fr
from itertools import product
from math import gcd,lcm
import gzip,importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('exact_color_factor_tools',Path(__file__).resolve().with_name('factor_tools.py'));f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f);J=f.J;A=f.A;O=f.O;R=f.R
def normalize(P):
 P=f.clean(P);den=1
 for c in P.values():
  for key,v in c.terms:den=lcm(den,v.denominator)
 num=0
 for c in P.values():
  for key,v in c.terms:num=gcd(num,abs(v.numerator)*(den//v.denominator))
 first=next(v for colors,c in sorted(P.items())for key,v in c.terms);content=Fr(num,den)*(1 if first>0 else-1);assert content
 return content,f.scale(P,J.constant(1/content))
def packed(P):return[[list(colors),A.encode_coeff(c)]for colors,c in sorted(P.items())]
def key_tensor(P,arity):return f.sha256(json.dumps([arity,packed(P)],sort_keys=True,separators=(',',':')).encode()).hexdigest()
def save_binary(name,raw):
 blob=gzip.compress(raw,mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=f.sha256(blob).hexdigest(),bytes=len(blob),uncompressed_bytes=len(raw))
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in f.read(O/'factor_preparation.json')['sha256'].items():assert f.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 cr=f.read(O/'compile_result.json');z=f.load(O/cr['artifact']['file']);assert f.digest(O/cr['artifact']['file'])==cr['artifact']['sha256'];matrices={label:f.decode(M)for label,M in z['matrices'].items()};matrices['N']=f.decode(z['N']);groups={}
 for label,M in matrices.items():
  for(rk,ck,m,ex),P in M.items():
   for colors,c in P.items():
    for(g,x,e,root),v in c.terms:
     key=label,rk,ck,m,ex,g,x,e,int(bool(root&16));acc=groups.setdefault(key,{});real=J.Coeff([((0,0,0,root&15),v)]);acc[colors]=acc.get(colors,f.zero)+real
 identity={(c,c):f.one for c in f.r.IC};lib=[identity];arities=[0];lookup={key_tensor(identity,0):0};terms={label:[]for label in matrices};group_count=0
 for(label,rk,ck,m,ex,g,x,e,imag),P in sorted(groups.items()):
  P=f.clean(P)
  if not P:continue
  content,norm=normalize(P);arity=m.bit_count();assert all(len(colors)==2+arity for colors in norm);assert all(key[:3]==(0,0,0)and key[3]<16 for c in norm.values()for key,v in c.terms);key=key_tensor(norm,arity)
  if key not in lookup:lookup[key]=len(lib);lib.append(norm);arities.append(arity)
  at=lookup[key];assert lib[at]==norm and arities[at]==arity;pref=J.Coeff([((g,x,e,16*imag),content)]);terms[label].append([rk,ck,m,list(ex),at,A.encode_coeff(pref)]);group_count+=1
 reconstruction=[];zero_mean_identity=True
 for label,M in matrices.items():
  rebuilt={}
  for rk,ck,m,ex,at,packed_pref in terms[label]:
   if m==0 and at!=0:zero_mean_identity=False
   pref=A.decode_coeff(packed_pref)
   for colors,c in lib[at].items():f.eput(rebuilt,rk,ck,m,tuple(ex),colors,J.times(pref,c))
  rebuilt=f.eclean(rebuilt);assert rebuilt==M,(label,'LOSSY_COLOR_FACTOR_RECONSTRUCTION');reconstruction.append(dict(state=label,exact_full_dictionary=True,kinematic_terms=len(terms[label]),color_coefficients=sum(len(P)for P in M.values())));print('STAGE exact_color_reconstruction '+label,flush=True)
 basis=f.save('color_kinematic_factors.json.gz',dict(schema='EXACT_POLARIZED_FULL45_COLOR_KINEMATIC_FACTORIZATION_V1',internal_color_range=[12,44],mean_color_range=[0,44],class_order=['C_p','C_r','a'],primitive_input_variables=['v','w','x','y'],color_tensor_library=[dict(id=i,arity=arity,all_real_color_entries=packed(P),sha256=key_tensor(P,arity))for i,(P,arity)in enumerate(zip(lib,arities))],kinematic_terms=terms,all_full_reconstruction_checks=reconstruction,zero_mean_identity_only=zero_mean_identity,identity_tensor_id=0,identity_color_trace=33,normalization='RATIONAL_CONTENT_AND_SIGN_ONLY; g/xi/eta_H/i retained in kinematic coefficients',no_numeric_color_loop_trace_or_heat_integration_yet=True))
 print('STAGE discovered_color_tensors='+str(len(lib))+' kinematic_terms='+str(group_count),flush=True)
 rows=bytearray();checks=0
 for m in range(8):
  for n in range(8):
   if m&n:continue
   present=[b for b in range(3)if(m|n)&(1<<b)]
   for colors in product(range(45),repeat=len(present)):
    assigned={b:c for b,c in zip(present,colors)};left=[45*b+assigned[b]for b in range(3)if m&(1<<b)];right=[45*b+assigned[b]for b in range(3)if n&(1<<b)];literal=(-1)**sum(a>b for a in left for b in right);assert literal==f.r.esign(m,n);rows.extend([m,n]+[assigned[b]+1 if b in assigned else 0 for b in range(3)]+[int(literal==1)]);checks+=1
 assert checks==753571 and len(rows)==6*checks
 control=f.background(((566,()),(566,(0,0)),(610,())));expected={(7,(13,13,12),(0,0,2,0)):f.one,(7,(13,13,12),(0,0,0,2)):-f.one};assert control==expected
 assert 13!=45+13 and f.r.esign(2,1)==-1;word=save_binary('all753571_class_word_products.bin.gz',bytes(rows));controlart=f.save('factor_controls.json.gz',dict(all_nonzero_binary_products=checks,row_width_bytes=6,binary_row_columns=['left_classmask','right_classmask','color_p_plus1_or0','color_r_plus1_or0','color_a_plus1_or0','positive_sign_1_else0'],all135_generator_literal_signs_equal_class_signs=True,same_color_derivative_control=[ [m,list(cs),list(ex),A.encode_coeff(c)]for(m,cs,ex),c in sorted(control.items())],wrong_color_only_collapse=dict(actual_p_generator=13,actual_r_generator=58,wrong_equal_color_labels=[13,13],would_drop_nonzero=True),wrong_no_class_sign=dict(left=2,right=1,correct=-1,wrong=1),old90bit_constantmean_algebra_not_replaced=True))
 out=dict(schema='EXACT_FULL_COLOR_PRIMITIVE_FACTOR_DISCOVERY_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',actual_color_tensor_count=len(lib),color_arity_counts={str(arity):arities.count(arity)for arity in[0,1,2]},kinematic_term_count=group_count,all8_primitive_N_dictionaries_reconstructed_exactly=True,zero_mean_identity_only=zero_mean_identity,engineering_basis_at_most64=len(lib)<=64,all753571_literal_full135_word_sign_products_exact=True,same_color_derivative_control_retained=True,basis_artifact=basis,word_artifact=word,controls_artifact=controlart,prediction_inputs_denied=True,full_color_finite_loop_not_computed=True,elapsed_after_imports=time.perf_counter()-tick);f.dump(O/'factor_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
