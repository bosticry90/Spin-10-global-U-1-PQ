from pathlib import Path
from functools import lru_cache
from fractions import Fraction as Fr
from math import comb
from hashlib import sha256
import gzip,importlib.util,json
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('full_color_source_tools',O.parent/'canonical_so10_aCC_finite_momentum_operator_g1_v1/polarized_polynomial.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);r=p.r;J=r.J;A=r.A;one=r.one;zero=J.ZERO;read=r.read;load=r.load;digest=r.digest;Z=(0,0,0,0)
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(f.stat().st_size for f in O.iterdir()if f.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
clean=r.clean;add=r.add;scale=r.scale
def pmul(P,Q):
 out={}
 for x,c in P.items():
  for y,d in Q.items():k=tuple(a+b for a,b in zip(x,y));out[k]=out.get(k,zero)+J.times(c,d)
 return clean(out)
def var(j):
 x=list(Z);x[j]=1;return {tuple(x):one}
def shifted_v(S):return add(var(0),scale(var(2),J.constant(int(bool(S&1))-int(bool(S&4)))),scale(var(3),J.constant(int(bool(S&2))-int(bool(S&4)))))
@lru_cache(None)
def phase(js,S=0,opposite=False):
 out={Z:one}
 for mu in js:
  if mu>1:return {}
  vv=shifted_v(S)if mu==0 else var(1);out=pmul(out,scale(vv,-J.I if opposite else J.I))
 return out
MEAN=[var(2),var(3),scale(add(var(2),var(3)),-one)]
@lru_cache(None)
def background(word):
 out={(0,(-1,-1,-1),Z):one}
 for n,js in word:
  if not is_mean(n)or any(mu!=0 for mu in js):return {}
  bits=[0,1]if n<598 else[2];color=n-(553 if n<598 else 598);new={}
  for bit in bits:
   PP={Z:one}
   for mu in js:PP=pmul(PP,scale(MEAN[bit],J.I))
   for(m,cs,ex),c in out.items():
    if m&(1<<bit):continue
    cc=list(cs);cc[bit]=color;sg=r.esign(m,1<<bit)
    for ee,d in PP.items():k=m|(1<<bit),tuple(cc),tuple(a+b for a,b in zip(ex,ee));new[k]=new.get(k,zero)+J.times(c,d)*sg
  out=clean(new)
 return out
def is_mean(n):return 553<=n<643
def kind_color(n):return(n%4,n//4)if n<180 else(4,n-508)if n<553 else(5,n-553)if n<598 else(6,n-598)
def physical(kind,color):return 4*color+kind if kind<4 else 508+color if kind==4 else 553+color if kind==5 else 598+color
def eput(out,rk,ck,m,ex,colors,c):
 if not c:return
 key=rk,ck,m,ex;acc=out.setdefault(key,{});acc[colors]=acc.get(colors,zero)+c
def eclean(M):return{k:clean(v)for k,v in M.items()if clean(v)}
def eadd(*ms):
 out={}
 for M in ms:
  for(rk,ck,m,ex),P in M.items():
   for colors,c in P.items():eput(out,rk,ck,m,ex,colors,c)
 return eclean(out)
def escale(M,c):return{k:scale(P,c)for k,P in M.items()if scale(P,c)}
def encode(M):return[[rk,ck,m,list(ex),[[list(colors),A.encode_coeff(c)]for colors,c in sorted(P.items())]]for(rk,ck,m,ex),P in sorted(M.items())]
def decode(M):return{(rk,ck,m,tuple(ex)):{tuple(colors):A.decode_coeff(c)for colors,c in P}for rk,ck,m,ex,P in M}
def metrics(M):return dict(kinematic_blocks=len(M),color_coefficients=sum(len(P)for P in M.values()))
def full_first(P):
 native={};wrong={};tokens=set();journal=[]
 for at,(ww,c)in enumerate(sorted(P.items())):
  selected=[]
  for pos,(n,js)in enumerate(ww):
   if n not in r.INDEX:continue
   rest=ww[:pos]+ww[pos+1:]
   if any(not is_mean(nn)for nn,jj in rest):continue
   if sum(nn<598 for nn,jj in rest)>2 or sum(nn>=598 for nn,jj in rest)>1:continue
   sg=(-1)**(J.parity(n)*sum(J.parity(nn)for nn,jj in ww[pos+1:]));word=rest+((1319+n,js),);J.put(native,word,c*sg);J.put(wrong,word,c);tokens.add((n,js));selected.append([pos,n,list(js)])
  if selected:journal.append([at,selected])
 native=J.clean(native);peer={}
 for n,js in sorted(tokens):
  for ww,c in J.leftjet(P,(n,js)).items():
   if any(not is_mean(nn)for nn,jj in ww)or sum(nn<598 for nn,jj in ww)>2 or sum(nn>=598 for nn,jj in ww)>1:continue
   sg=(-1)**(J.parity(n)*sum(J.parity(nn)for nn,jj in ww));J.put(peer,ww+((1319+n,js),),c*sg)
 assert native==J.clean(peer),'FULL_GENERIC_PREFIX_LEFT_T1'
 return native,J.clean(wrong),journal
def project(T,nout):
 out={};rk,rc=kind_color(nout)
 for ww,c in T.items():
  qs=[i for i,(n,js)in enumerate(ww)if 1319<=n<1962];assert len(qs)==1;at=qs[0];n,js=ww[at];nn=n-1319;assert nn in r.INDEX;ck,cc=kind_color(nn);bg=background(ww[:at]+ww[at+1:]);qq=phase(js)
  for(m,cs,ex),d in bg.items():
   for ee,v in qq.items():colors=(rc,cc)+tuple(cs[b]for b in range(3)if m&(1<<b));eput(out,rk,ck,m,tuple(a+b for a,b in zip(ex,ee)),colors,J.times(J.times(c,d),v))
 return eclean(out)
def quadratic(raw):
 out={};journal=[]
 for at,(ww,c)in enumerate(sorted(J.decode(raw).items())):
  qs=[pos for pos,(n,js)in enumerate(ww)if 1319<=n<1962]
  if len(qs)!=2:continue
  x,y=qs;n1=ww[x][0]-1319;n2=ww[y][0]-1319
  if n1 not in r.INDEX or n2 not in r.INDEX:continue
  bg=background(tuple(t for pos,t in enumerate(ww)if pos not in qs))
  if not bg:continue
  choices=[]
  for left,right in[(x,y),(y,x)]:
   nn,jj=ww[left];nk,jk=ww[right];nn-=1319;nk-=1319;rk,rc=kind_color(nn);ck,cc=kind_color(nk);sg=(-1)**(J.parity(nn)*sum(J.parity(n)for n,js in ww[:left]));remaining=ww[:left]+ww[left+1:];pos=right-int(right>left);sg*=(-1)**(J.parity(nk)*sum(J.parity(n)for n,js in remaining[pos+1:]));qq=phase(jk)
   for(m,cs,ex),d in bg.items():
    PP=pmul(phase(jj,m,True),qq)
    for ee,v in PP.items():colors=(rc,cc)+tuple(cs[b]for b in range(3)if m&(1<<b));eput(out,rk,ck,m,tuple(a+b for a,b in zip(ex,ee)),colors,J.times(J.times(c,d),v)*sg)
   choices.append([left,right,nn,nk])
  journal.append([at,choices])
 return eclean(out),journal
def rotate(T,a,b):
 out={}
 for ww,c in T.items():
  for at,(n,js)in enumerate(ww):
   for pos,mu in enumerate(js):
    if mu not in[a,b]:continue
    jj=list(js);jj[pos]=b if mu==a else a;word=ww[:at]+((n,tuple(sorted(jj))),)+ww[at+1:];J.put(out,word,c*(1 if mu==a else-1))
   if 1319<=n<1499:
    old=n-1319;mu=old%4
    if mu in[a,b]:new=n+(b-a if mu==a else a-b);J.put(out,ww[:at]+((new,js),)+ww[at+1:],c*(1 if mu==a else-1))
 return J.clean(out)
def covariance_residual(T,n,a,b):
 target=T.get(n+ b-a,{})if n<180 and n%4==a else scale(T.get(n+a-b,{}),-one)if n<180 and n%4==b else{}
 return add(rotate(T.get(n,{}),a,b),scale(target,-one))
@lru_cache(None)
def shift(ex,S):
 v,w,x,y=ex;out={};alpha=int(bool(S&1))-int(bool(S&4));beta=int(bool(S&2))-int(bool(S&4))
 for j in range(v+1):
  for k in range(v-j+1):
   power=(j,w,x+k,y+v-j-k);c=comb(v,j)*comb(v-j,k)*alpha**k*beta**(v-j-k)
   if c:out[power]=J.constant(c)
 return out
def specialize(M,cs,aa,u,wrong=False):
 out={};wanted={1:cs[0],2:cs[1],4:aa}
 for(rk,ck,m,ex),P in M.items():
  for colors,c in P.items():
   if tuple(wanted[1<<b]for b in range(3)if m&(1<<b))!=colors[2:]:continue
   i=r.INDEX[physical(rk,colors[0])];j=r.INDEX[physical(ck,colors[1])]
   for S in range(8):
    if m&S:continue
    for ee,f in shift(ex,0 if wrong else S).items():key=i,j,u,m,S,ee;out[key]=out.get(key,zero)+J.times(c,f)
 return clean(out)
def old_plane(M):
 out={}
 for(i,j),P in p.dm(M).items():
  for(u,m,S,ex),c in P.items():
   if any(ex[k]for k in[2,3,5,6,7,9,10,11]):continue
   key=i,j,u,m,S,(ex[0],ex[1],ex[4],ex[8]);out[key]=out.get(key,zero)+c
 return clean(out)
