# Final validation freeze

Validate all four completed stages by fresh sequential recomputation of
their complete artifacts and every non-runtime result field. Include the
binary full-word-sign artifact, all nineteen literal trace peer arrays,
all 91,125 rows and zero complement. No primary worker is rerun in parallel.
New aggregate bound420s after imports; original constituent180/120/300/300s
bounds unchanged. 8GiB sampled private/350MiB launch floor/64MiB packet/
10MiB artifact. Failure or resource exhaustion is incomplete, not PASS;
retain exact sources/captures and never truncate evidence.

Authenticate every frozen preparation, source copy, old dependency and
completed capture. Fresh outputs must be byte-identical except result
runtime, using the original algorithms. Distinct derivative/sign/trace
checks remain as recorded; this final replay is not an independent
scientist. Prediction/remainder reads stay denied during constructors.

Run E4 once, no fresh flag, fixed D: historical context. Expected aggregate0,
step exits0,0,0,0,0,2 and exactly seven RECORDED_DIGEST_UNRESOLVED references;
custody remains NOTPASS. Preserve all old mode/blob entries and unchanged
state SHA. No branch/worktree, push, external action, adoption, protected
promotion or overall completion. New V821 handoff only; current live AGENTS.

Local commit only after final evidence validation; a separate later frozen
full finite comparison remains the next smallest discriminating action.
