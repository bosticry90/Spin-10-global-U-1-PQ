# Direct universal kinematic color-word contraction

Actual factor result:10 numerical tensors (identity,3arity1,6arity2),107
kinematic terms; ALL primitive dictionaries exactly reconstructed. Zero-mean
color is ONLY identity. Proceed under new300s afterimports/8GiB sampled/
350MiBfloor/64MiBpacket/10MiBartifact freeze. Existing compiler/factor
sources and allowances immutable. No prediction/remainder input.

Full physical target remains91125 ordered color polarizations, including
same-color derivative ghosts. This stage computes universal momentum
coefficients, not yet the full numerical color tensor. Seven quantumfield
types B0..3,Lambda,C,a carry all4 gauge components;33-color identity free
block separated exactly. Copy the qualified shifted heat Taylor algebra,
adding a NONCOMMUTING ordered color word to each scalar coefficient. A token
is (tensorID,classmask), with its external slots ordered by present classes.
Matrix products concatenate color words while applying exact CLASS exterior
sign and input-subset shift. Do not commute/cyclically move odd or kinematic
operators. Numerical color traces may be cyclically canonicalized ONLY
after the field contraction, with class attachments unchanged.

Build actual E0-free=N, T=G0N,B=I-T+T²,Gbase=B G0; require cube0/freeghost
block and actualfreeframe. SourceFu1 is0 in this full ghost-planeT1, not
assumed globally. Independently verify actualF0 raw quadratic regulator root
zero with full symbolic4D block and graded symmetrization; unsym root is
nonzero control. This retains the qualified two-response completeness.

For BOTH roots compute L=M_F Gbase,R=H B and complete target
 -(1-E(q)) sum_i(-1)^pi (L R)_ii atclass7,input0,u1,g1.
Keep every source factor, width/eta_H,heat derivative and color word. No
coupling/width value or coefficient fit. Save complete scalar Laurent/Taylor
symbols and factors; require odd-w scalar cancellation per complete color
word before applying the true4D angular moments. A failure remains failure,
not silent projection. Positive heat powers, canonical radial homogeneity
and combined Frullani cancellation required; retain rational/prime logs.

Use cyclic canonicalization of NUMERICAL color trace words only after
contraction; empty color trace is33. For three existing cases evaluate
each color trace from the immutable numerical tensor library AFTER own
word construction, then compare every pre-angular scalar coefficient and
both roots to the qualified V818 full symbols, not just finite sums.
This is a calibration/reused result, not an independent full-color loop.

If all pass, the next stage evaluates the complete color traces and zero
complement from source data, reproduces full old leadingtensor and ghost
exchange, and only then compares the frozen whole finite tensor to the
nowvisible dependent prediction. Direct FULL-COLOR acceptance requirement
retained. No sourcecompatibility/commonrestoration/E5A5/viability claim.
Failure/exhaustion exactcapture/partials preserved, no automatic retry,
truncation or resource expansion. Shared action/ring/helpers/AIauthor.
