# Full-color aCC source factorization preparation

Continue97a7dd85ed0b26579b2cf0deaefa8e7b6662cecd/main,V820,D:repo,current
AGENTS. Preflight clean/no matching workers; declared bytes authenticated
only. Previous goal turn PROGRESS: three direct finite references matched
prediction, with DIRECT FULL-COLOR requirement retained. Goal remains full
investigation, active. State113/34of39,E5A5open unchanged. Noagents/branch/
worktree/adoption/protectedpromotion/push/externalaction. Flavorpaused,
HB1C5blocked;educationvoluntary/nonblocking.

Question: can the ACTUAL full-color source operators be factored exactly
into reusable numerical color tensors and universal kinematic polynomials,
so the complete finite tensor can be calculated directly without91125
separate231-field inversions? This is a method for the required full target,
not a narrower acceptance criterion or new proof/benchmark platform.
Do not use the nowvisible prediction as a computational input. All new
constructor workers deny its folder and assembled remainder containers.

Original EuclideanA0,firstg/firstu_M,intrinsic01,all33 internalM/all4B/231
fields, all45 external C_p,45C_r,45a. At most one mean from each polarized
class; same-color C_p,c and C_r,c remain distinct. Class-count filtration
is positive, so discarded degree2 in one class cannot feed back into the
target1/1/1. This is NOT the old90bit constantmean quotient. With generator
order allp thenallr thenalla and one/class, exterior signs use CLASS bits;
full color labels are stored separately. Literal word verification follows.

First source compiler180s afterimports/8GiB sampled private/350MiB launch
floor/64MiB completepacket/10MiB artifact. Freeze source/inputs before launch.
Retain all7 states E0,E1,Eu0_1,F0,F1,Fu0_1,Fu1_1; do not discard a global
root because three old cases were zero. PhysicalE0/E1B retained before
restriction; E1x omitted only by qualified no-return support. Source/Euler
operations occur before source0 and ghost mean restriction.

Construct FULL jet T1 polynomials with one internal quantum slot and
C<=2/a<=1 means of arbitrary45 colors/jets. Prefix variation with quantum
odd token moved right must equal independent LEFT differentiation before
Fourier/mean polarization. Verify all6 Lorentz generators on all7 full
jet operators: derivative indices and quantumB vector indices rotate;
outputB has its vector transformation. This generic check precedes any
color or momentum choice. Canonical dimensions/g/u grades must hold.

For LOCAL quadratic scalar hard Taylor, proven V818/V819 invariance permits
p=x e0,r=y e0,q=(v,w,0,0), with BOTH v,w/all4 quantumB components and the
true4D angular measure later. Keep primitive w² unreduced. Fourier-transform
all mean jets and quantum jets at INPUTq (subsetS0) before factorization.
Project out other components only after generic covariance. Independent
raw ordinaryT2 halves include both quantum assignments with left momentum
-(q+P_m), rightq; all colors/classes retained. Require exact equality to
N=E0-free,Hg=E1,Hu=Eu0_1. No coefficient fit, EOM or extra half.

Exact specializations of every primitive to all4 old V817 cases, ALL8
valid subset shifts q->q+P_S, must match full prior polynomials. Same-color
case retained. Controls: omitted quantum odd crossing, omitted F0 vector
component, and wrong commuting-q subset shift must give complete nonzero
differences where sensitive; blind cases reported. Full selected source
positions/jet operators/primitive coefficients and wrong controls retained.
Failure/exhaustion incomplete, no automatic retry/resource expansion or
evidence truncation. This stage computes no loop amplitude/reference.

If source reconstruction succeeds, freeze a separate bounded numerical color
factor discovery: split g/xi/eta/i into kinematics, keep real rational-root
color coefficients, deduplicate exact tensors up to rational content/sign
ONLY, then reconstruct EVERY primitive coefficient. No irrational/coupling
division and no assumed color basis fitted from three examples. Any further
color trace/kinematic contraction has its own freeze. Full91125 ordered
polarizations, ghost exchange and same-color derivative terms remain target.

Shared action, ring, Fourier helpers and AI author limit independence; no
external scientist/Lean/empirical result. Fullcolor/sourcecompatibility/
commonrestoration/E5A5 not claimed by a factorization helper. Finalvalidation/
E4one nofresh/localcommit separate; seven custodyNOTPASS. State unchanged.
