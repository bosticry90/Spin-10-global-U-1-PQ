from pathlib import Path
import gc,importlib.util,json,os,sys,threading,time
import sympy as sy
sp=importlib.util.spec_from_file_location('full_color_universal_words',Path(__file__).resolve().with_name('word_ring.py'));w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w);f=w.f;J=w.J;A=w.A;O=f.O;R=f.R
def full_F0_root_zero():
 source=f.load(O/'generic_source_jet_checks.json.gz');T={n:J.decode(P)for n,P in source['all_generic_jet_T1']['F0']};q=sy.symbols('q0:4',real=True);xi,F=sy.symbols('xi F',real=True);ids=[48,49,50,51,520,565,610];index={n:i for i,n in enumerate(ids)};M=sy.zeros(7)
 for n in ids:
  for ww,c in T[n].items():
   assert len(ww)==1;nn,js=ww[0];nn-=1319;assert nn in index;expr=sy.sympify(str(c),locals={'xi':xi})*sy.I**len(js)*sy.prod(q[mu]for mu in js);M[index[n],index[nn]]+=expr
 vec=sy.Matrix(q);s=(vec.T*vec)[0];H=sy.zeros(7);H[:4,:4]=s*sy.eye(4)-vec*vec.T;H[:4,4]=vec;H[4,:4]=-vec.T;H[4,4]=xi;H[5,6]=-s;H[6,5]=s;Ropp=H.subs({z:-z for z in q},simultaneous=True)*(1/F-1);K=(M.T*Ropp).applyfunc(sy.simplify);Km=K.subs({z:-z for z in q},simultaneous=True);paired=sy.zeros(7)
 for i in range(7):
  for j in range(7):paired[i,j]=sy.simplify((K[i,j]+(-1 if i>=5 and j>=5 else 1)*Km[j,i])/2)
 assert paired==sy.zeros(7)and K!=sy.zeros(7)
 return dict(actual_source_F0=str(M),actual_free_Ropposite=str(Ropp),whole_paired_root=str(paired),unsymmetrized_nonzero_control=str(K))
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in f.read(O/'word_preparation.json')['sha256'].items():assert f.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 fr=f.read(O/'factor_result.json');z=f.load(O/fr['basis_artifact']['file']);assert f.digest(O/fr['basis_artifact']['file'])==fr['basis_artifact']['sha256'];assert fr['zero_mean_identity_only']and z['identity_color_trace']==33;library=z['color_tensor_library'];M={label:w.primitive(terms,int(label in['Eu0_1','Fu0_1','Fu1_1']))for label,terms in z['kinematic_terms'].items()};H0,G0=w.free();N=M['N'];assert M['E0']==w.ma(H0,N),'UNIVERSAL_FREE_FRAME';assert not M['Fu1_1'];F0proof=full_F0_root_zero();T=w.mm(G0,N);T2=w.mm(T,T);assert not w.mm(T2,T);B=w.ma(w.ident(),w.ms(T,-f.one),T2);base=w.mm(B,G0);assert{ij:P for ij,P in base.items()if ij[0]>=5 and ij[1]>=5}=={ij:P for ij,P in G0.items()if ij[0]>=5 and ij[1]>=5}
 artbase=f.save('universal_word_base.json.gz',dict(source_F0_root_proof=F0proof,G0=w.em(G0),N=w.em(N),B=w.em(B),Gbase=w.em(base),free_frame_cube_and_free_ghost_block=True,excluded_Fu1_selected_T1=[]));print('STAGE universal_word_base '+json.dumps(w.metrics(base),sort_keys=True),flush=True);branches=[];total={};allwords=set()
 for name,flow,hl in[('F1_Hu','F1','Eu0_1'),('Fu0_Hg','Fu0_1','E1')]:
  L=w.mm(M[flow],base);Right=w.mm(M[hl],B);print('STAGE '+name+' factors '+json.dumps(dict(L=w.metrics(L),R=w.metrics(Right)),sort_keys=True),flush=True);scalar=w.trace_pair(L,Right);words=w.by_word(scalar);allwords.update(words);integrated=[]
  for word,P in sorted(words.items()):
   assert all(key[6]==0 for key in P),'ODD_W_COLOR_WORD_SCALAR_REQUIRES_REVIEW';angular=w.h.angular(P);finite,mom=w.h.finite_radial(angular);leading={}
   for(a,b,v,e,t),c in angular.items():
    if a+b==0:assert v==-1 and t==0;leading[e]=leading.get(e,f.zero)+c
    elif a+b==1:assert not c
   integrated.append(dict(color_word=[list(t)for t in word],complete_scalar=w.h.enc(P),complete_angular=w.h.enc_angular(angular),leading_profile=[[e,A.encode_coeff(c)]for e,c in sorted(f.clean(leading).items())],finite_hard_coefficients=[[*key,A.encode_coeff(c)]for key,c in sorted(finite.items())],complete_radial_moments=mom))
  artifact=f.save('universal_word_branch_'+name+'.json.gz',dict(branch=name,full_L=w.em(L),full_R=w.em(Right),complete_color_word_scalar=w.enc(scalar),all_word_integrals=integrated,numerical_color_trace_not_yet_evaluated=True));branches.append(dict(branch=name,artifact=artifact,color_word_count=len(words),scalar_terms=len(scalar)));total=w.add(total,scalar);print('STAGE '+name+' integrated_words='+str(len(words)),flush=True);del L,Right;gc.collect()
 # Calibration happens after the complete own word construction, never as a coefficient fit.
 calibrations=[]
 for name,external in[('base',(0,14,13)),('H_antighost',(13,14,0)),('all_M',(13,14,12))]:
  traces={word:w.fixed_trace(library,word,external)for word in allwords};casebranches=[]
  for row in branches:
   own=f.load(O/row['artifact']['file']);scalar=w.dec(own['complete_color_word_scalar']);collapsed={}
   for key,c in scalar.items():value=J.times(c,traces[key[10]]);k=key[:10];collapsed[k]=collapsed.get(k,f.zero)+value
   collapsed=f.clean(collapsed);old=f.load(O.parent/'canonical_so10_aCC_hard_finite_heat_g1_v1'/('hard_branch_'+name+'_'+row['branch']+'.json.gz'));assert collapsed==w.h.dec(old['complete_selected_Taylor_scalar']),(name,row['branch'],'FULL_PREANGULAR_SCALAR_CALIBRATION')
   casebranches.append(dict(branch=row['branch'],complete_collapsed_scalar=w.h.enc(collapsed),all_coefficients_match=True))
  calibrations.append(dict(case=name,all_source_color_traces=[[[list(t)for t in word],A.encode_coeff(c)]for word,c in sorted(traces.items())],both_branches=casebranches));print('STAGE universal_full_scalar_calibration '+name,flush=True)
 art=f.save('universal_word_total.json.gz',dict(complete_selected_scalar=w.enc(total),all_color_words=[[list(t)for t in word]for word in sorted(allwords)],all3_full_preangular_calibrations=calibrations,branches=branches,numerical_full_color_tensor_not_yet_computed=True))
 out=dict(schema='DIRECT_FULL_COLOR_UNIVERSAL_WORD_KINEMATIC_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all7_field_types_all4_B_and_33_color_identity=True,actual_F0_paired_root_zero_and_Fu1_selected_zero=True,base_cube_and_free_ghost_block_exact=True,both_actual_response_word_kernels_integrated=True,three_complete_preangular_scalar_calibrations_equal=True,distinct_color_trace_words=len(allwords),branches=branches,base_artifact=artbase,artifact=art,prediction_inputs_denied=True,complete91125_numerical_color_tensor_NOT_YET_EVALUATED=True,common_restoration_E5_A5_not_claimed=True,elapsed_after_imports=time.perf_counter()-tick);f.dump(O/'word_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
