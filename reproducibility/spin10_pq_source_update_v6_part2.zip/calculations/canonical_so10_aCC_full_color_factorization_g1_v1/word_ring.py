from pathlib import Path
from functools import lru_cache
from math import comb,factorial
from fractions import Fraction as Fr
import importlib.util
sp=importlib.util.spec_from_file_location('universal_word_source',Path(__file__).resolve().with_name('factor_tools.py'));f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f);r=f.r;J=f.J;A=f.A;one=f.one;zero=J.ZERO;O=f.O;R=f.R
sp=importlib.util.spec_from_file_location('qualified_universal_heat_core',O.parent/'canonical_so10_aCC_hard_finite_heat_g1_v1/heat_ring.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);assert h.J.Coeff is J.Coeff
@lru_cache(65536)
def ct(c,d):return r.trim(J.times(c,d))
def put(out,key,c):
 u,m,S,a,b,k,l,v,e,t,word=key
 if not c or u>1 or a+b>2 or m&S:return
 for j in range(l//2+1):
  z=u,m,S,a,b,k+2*j,l%2,v+l//2-j,e,t,word;out[z]=out.get(z,zero)+c*(comb(l//2,j)*(-1)**j)
def add(*ps):return r.add(*ps)
def scale(P,c):return r.scale(P,c)
def term(c=one,e=0):return{(0,0,S,0,0,0,0,0,e,0,()):c for S in range(8)}
UNIT=term()
def star(P,Q):
 by={};out={}
 for key,c in P.items():by.setdefault(key[2],[]).append((key,c))
 for(vv,n,T,aa,bb,kk,ll,sv,ee,tt,wq),d in Q.items():
  for(u,m,S,a,b,k,l,v,e,t,wp),c in by.get(T|n,[]):
   if u+vv>1 or m&n or(m|n)&T or a+b+aa+bb>2:continue
   put(out,(u+vv,m|n,T,a+aa,b+bb,k+kk,l+ll,v+sv,e+ee,t+tt,wp+wq),ct(c,d)*r.esign(m,n))
 return r.clean(out)
def mm(P,Q):
 by={};out={}
 for(k,j),c in Q.items():by.setdefault(k,[]).append((j,c))
 for(i,k),c in P.items():
  for j,d in by.get(k,[]):
   value=star(c,d)
   if not value:continue
   acc=out.setdefault((i,j),{})
   for key,v in value.items():acc[key]=acc.get(key,zero)+v
 return{ij:r.clean(P)for ij,P in out.items()if r.clean(P)}
def ma(*ps):
 out={}
 for P in ps:
  for ij,c in P.items():out[ij]=add(out.get(ij,{}),c)
 return{ij:P for ij,P in out.items()if P}
def ms(P,c):return{ij:scale(v,c)for ij,v in P.items()if scale(v,c)}
def ident():return{(i,i):UNIT for i in range(7)}
def enc(P):return[[*key[:10],[list(t)for t in key[10]],A.encode_coeff(c)]for key,c in sorted(P.items())]
def dec(P):return{tuple(row[:10])+(tuple(tuple(t)for t in row[10]),):A.decode_coeff(row[11])for row in P}
def em(M):return[[i,j,enc(P)]for(i,j),P in sorted(M.items())]
def dm(M):return{(i,j):dec(P)for i,j,P in M}
def metrics(M):return dict(entries=len(M),terms=sum(len(P)for P in M.values()))
def primitive(terms,u):
 out={}
 for rk,ck,m,ex,tid,packed in terms:
  pref=A.decode_coeff(packed);word=()if tid==0 else((tid,m),);acc=out.setdefault((rk,ck),{})
  for S in range(8):
   if m&S:continue
   for(k,l,a,b),c in f.shift(tuple(ex),S).items():put(acc,(u,m,S,a,b,k,l,0,0,0,word),J.times(pref,c))
 return{ij:r.clean(P)for ij,P in out.items()if r.clean(P)}
def free():
 H,G,F=h.free();ids=[0,1,2,3,132,165,198];ix={n:i for i,n in enumerate(ids)}
 def convert(M):return{(ix[i],ix[j]):{key+((),):c for key,c in P.items()}for(i,j),P in M.items()if i in ix and j in ix}
 return convert(H),convert(G)
def canonical_word(w):return min(w[j:]+w[:j]for j in range(len(w)))if w else()
def trace_pair(L,RR):
 out={}
 for(i,j),P in L.items():
  Q=RR.get((j,i))
  if not Q:continue
  groups={}
  for key,d in Q.items():
   if key[2]==0:groups.setdefault((key[0],key[1]),[]).append((key,d))
  for(u,m,S,a,b,k,l,v,e,t,wp),c in P.items():
   n=7^m
   if S!=n:continue
   for(vv,nn,T,aa,bb,kk,ll,sv,ee,tt,wq),d in groups.get((1-u,n),[]):
    if a+b+aa+bb>2:continue
    word=canonical_word(wp+wq);assert word and len(word)<=3 and sum(token[1].bit_count()for token in word)==3
    value=ct(c,d)*r.esign(m,n)*(-1 if i>=5 else 1)
    for pe,sg in[(e+ee,-1),(e+ee+1,1)]:put(out,(1,7,0,a+aa,b+bb,k+kk,l+ll,v+sv,pe,t+tt,word),value*sg)
 return r.clean(out)
def by_word(P):
 out={}
 for key,c in P.items():out.setdefault(key[10],{})[key[:10]]=c
 return out
def enc_words(P):return[[[list(t)for t in word],h.enc(Q)]for word,Q in sorted(P.items())]
def ordinary_mm(P,Q):
 by={};out={}
 for(k,j),d in Q.items():by.setdefault(k,[]).append((j,d))
 for(i,k),c in P.items():
  for j,d in by.get(k,[]):out[i,j]=out.get((i,j),zero)+J.times(c,d)
 return r.clean(out)
def fixed_color_matrix(library,tid,mask,external):
 row=library[tid];classes=[b for b in range(3)if mask&(1<<b)];wanted=tuple(external[b]for b in classes);assert row['arity']==len(classes);out={}
 for colors,packed in row['all_real_color_entries']:
  if tuple(colors[2:])==wanted:out[tuple(colors[:2])]=A.decode_coeff(packed)
 return out
def fixed_trace(library,word,external):
 if not word:return J.constant(33)
 current={(c,c):one for c in r.IC}
 for tid,mask in word:current=ordinary_mm(current,fixed_color_matrix(library,tid,mask,external))
 return sum((c for(i,j),c in current.items()if i==j),zero)
