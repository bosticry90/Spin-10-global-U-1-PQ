from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-full-color-factorization-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
for pn in['preparation.json','factor_preparation.json']:
 for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'factor_result.json').read_bytes())['execution_state']=='COMPLETED'
names=['calculations/canonical_so10_aCC_hard_finite_heat_g1_v1/'+n for n in['heat_ring.py','hard_branch_base_F1_Hu.json.gz','hard_branch_base_Fu0_Hg.json.gz','hard_branch_H_antighost_F1_Hu.json.gz','hard_branch_H_antighost_Fu0_Hg.json.gz','hard_branch_all_M_F1_Hu.json.gz','hard_branch_all_M_Fu0_Hg.json.gz']]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['WORD_KERNEL_RECORD.md','word_ring.py','universal_kernel.py','run_word.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'word_preparation.json',dict(sha256={**json.loads((O/'factor_preparation.json').read_bytes())['sha256'],**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'universal_kernel.py')]);dump(O/'word_capture.json',cap);dump(C/'word_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
