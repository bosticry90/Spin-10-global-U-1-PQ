from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
import algebra as a
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-metric-lift-v1-2026-11-08')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    return dict(file=n,sha256=digest(O/n),bytes=len(blob))
def eulers(q,ids):
    out={}
    for(w,k),v in q.items():
        for at,(n,js)in enumerate(w):
            if n not in ids:continue
            sg=(-1)**(a.par(n)*sum(a.par(i)for i,jj in w[:at]));term={(w[:at]+w[at+1:],k):v*sg}
            for mu in js:term=a.scale(a.D(term,mu),-1)
            out[n]=a.add(out.get(n,{}),term)
    return{n:q for n,q in out.items()if q}
def inputs():
    rows=[];z=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz')
    K=a.flat(z['complete_K']);Kn=a.flat(z['complete_K_epsilon_normal']);En=eulers(K,set(range(1286,1319)));normal={}
    for n,q in En.items():
        for(w,k),v in q.items():a.put(normal,((n,()),)+w,k,v)
    assert a.clean(normal)==Kn and a.add(K,a.scale(Kn,-1))==a.div([a.flat(q)for q in z['four_IBP_currents']])
    rows.extend([('KD_raw',K,True),('KD_epsilon_normal',Kn,True)]);extra=[]
    for role in['native','replay']:
        z0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));z1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'))
        for pr,name in enumerate(['H','M']):
            rows.append((role+'_U0_'+name,a.flat(z0['probes'][pr]['U']),True));rows.append((role+'_U1_'+name,a.flat(z1['U1'][pr]),True))
        for g in[0,1]:
            z=load(B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz'));old=a.flat(z['complete_transported_portable_parent']);current=a.flat(z['complete_current_GF_source_parent']);P=a.add(old,a.scale(current,-1));saved=[a.flat(q)for q in z['comparison']['four_complete_IBP_currents']];assert P==a.flat(z['comparison']['complete_difference'])and P==a.div(saved)
            rows.extend([(role+'_old_parent_g'+str(g),old,True),(role+'_current_parent_g'+str(g),current,True)])
            PM=a.unwick(P);oldcur=[a.unwick(q,extra=-1 if mu==0 else 0)for mu,q in enumerate(saved)];assert PM==a.div(oldcur),'OLD_CURRENTS_WICK_DIVERGENCE'
            N,newcur=a.sym_normal(PM);assert not N and PM==a.div(newcur),'SYMMETRIC_PARENT_DIFFERENCE_NORMAL_NONZERO'
            assert not a.div([a.add(x,a.scale(y,-1))for x,y in zip(newcur,oldcur)])
            rows.extend([(role+'_literal_current_g'+str(g),a.tag_current(oldcur),False),(role+'_symmetric_current_g'+str(g),a.tag_current(newcur),True)])
            extra.append(dict(role=role,g=g,complete_difference_Minkowski=a.encode(PM),four_literal_Minkowski_currents=[a.encode(q)for q in oldcur],four_symmetric_Minkowski_currents=[a.encode(q)for q in newcur],complete_symmetric_normal=a.encode(N),literal_current_not_required_to_be_individually_covariant=True))
    return rows,extra
def main():
    tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    cases,extra=inputs();cache={};reports=[];controls=dict(omitted_time_jet_phase_sensitive_cases=0,dropped_local_epsilon_jet_words=0);allmatch=True
    for name,P,required in cases:
        Q=P if '_current_g'in name else a.unwick(P)
        wrong=P if '_current_g'in name else a.unwick(P,omit_time_jets=True)
        controls['omitted_time_jet_phase_sensitive_cases']+=bool(a.add(Q,a.scale(wrong,-1)))
        if name=='KD_raw':controls['dropped_local_epsilon_jet_words']=len({w for w,k in Q if any(1286<=n<1319 and js for n,js in w)})
        blob=(json.dumps(a.encode(Q),separators=(',',':'))+'\n').encode();key=sha256(blob).hexdigest()
        if key in cache:
            original,ref,match=cache[key];assert original==Q
        else:
            first=a.reconstruct(Q,'native');second=a.reconstruct(Q,'replay');assert first==second,'FULL_RREF_GRAM_TENSOR_DISAGREEMENT'
            ref=save('tensor_'+str(len(cache))+'.json.gz',dict(input_polynomial_Minkowski=a.encode(Q),reconstruction=first,both_exact_routes_equal=True,fixed_constructor_no_new_evanescent_terms=True));match=first['match'];cache[key]=(Q,ref,match)
        reports.append(dict(case=name,required=required,match=match,canonical_input_sha256=key,artifact=ref,input_words=len({w for w,k in Q})))
        allmatch&=match or not required;print('STAGE '+name+' tensor_match='+str(match)+' words='+str(len({w for w,k in Q})),flush=True)
    currentref=save('complete_parent_divergence_transport.json.gz',dict(all_four_cases=extra,all_symmetric_normals_zero=True,old_currents_preserved_and_full_divergence_equal=True))
    totals=Counter()
    for Q,ref,match in cache.values():
        z=load(O/ref['file'])['reconstruction'];totals.update(z['controls'])
    assert controls['omitted_time_jet_phase_sensitive_cases']and controls['dropped_local_epsilon_jet_words'],'JET_CONTROL_INSENSITIVE'
    assert all(totals[n]>0 for n in totals),'METRIC_CONTROL_INSENSITIVE'
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='COMPLETE_SELECTED_AUGMENTED_FIXED_METRIC_CONSTRUCTOR_MATCHES'if allmatch else'COMPLETE_SELECTED_AUGMENTED_METRIC_CONSTRUCTOR_MISMATCH_PRESERVED',all_required_tensor_cases_match=allmatch,cases=reports,unique_polynomials=len(cache),complete_parent_currents_artifact=currentref,controls=controls,metric_controls=dict(totals),no_augmented_loop_dimensionjet_contact_QAP_E5_or_physical_viability_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps({k:result[k]for k in['scientific_disposition','all_required_tensor_cases_match','unique_polynomials','controls','metric_controls','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
