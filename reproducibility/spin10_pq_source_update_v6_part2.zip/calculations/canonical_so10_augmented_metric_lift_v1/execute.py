from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-metric-lift-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='d340b521bbec2ad57561165634252c68096f8f0d'
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names={'AGENTS.md','CHARTER.md','project_state.json','README.md','docs/RESEARCH_EXECUTION_HANDOFF_V847.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md'}
folders=['canonical_so10_dimensional_counterterm_applicability','canonical_so10_cartan_generator_residual_g1_v1','canonical_so10_Ward_primitive_canonical','canonical_so10_antighost_Ward_Hamiltonian','canonical_so10_new_physical_returning_inventory_g1_recovery_v1','canonical_so10_full_current_inventory_g1_recovery_v1','canonical_so10_full_jet_source_master_bridge','canonical_so10_acceptance_parent_reconciliation_v1','canonical_so10_heat_clock_applicability_v1']
for folder in folders:
    root=R/'calculations'/folder
    for n in['PROOF.md','DERIVATION.md','RECORD.md','RESULT.md','RESULT_V3.md','validation_receipt.json','validation_receipt_v5.json','final_review_validation_receipt.json','validation_receipt_v2.json','applicability.py']:
        if(root/n).exists():names.add((root/n).relative_to(R).as_posix())
names.add('calculations/canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz')
names.add('calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz')
for role in['native','replay']:
    names.add('calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_GF_common.json.gz');names.add('calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+role+'_route_densities.json.gz')
    for g in[0,1]:names.add('calculations/canonical_so10_acceptance_parent_reconciliation_v1/'+role+'_v2_complete_parent_g'+str(g)+'.json.gz')
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n in['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']:
    with(C/('README_before.md'if n=='README.md'else'campaign_before.md')).open('xb')as f:f.write((R/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
for n in['RECORD.md','algebra.py','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='d340b521bbec2ad57561165634252c68096f8f0d',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
