from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter
from itertools import product
from hashlib import sha256
import gzip,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-metric-lift-v1-2026-11-08')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def par(i):
    if 2000<=i<2004:return 0
    if 1286<=i<1319:return 1
    return int(i>=553)if i<643 else 1-int(i-643>=553)
def canonical(w):
    odd=[z for z in w if par(z[0])]
    if len(set(odd))!=len(odd):return(),0
    return tuple(sorted(w)),(-1)**sum(v>q for at,v in enumerate(odd)for q in odd[at+1:])
def put(out,w,k,v):
    w,sign=canonical(w)
    if sign:out[w,k]=out.get((w,k),F(0))+sign*v
def clean(q):return{k:v for k,v in q.items()if v}
def flat(rows):
    out={}
    for w,cs in rows:
        ww=tuple((n,tuple(js))for n,js in w)
        for key,num,den in cs:put(out,ww,tuple(key),F(num,den))
    return clean(out)
def encoded(q):
    grouped=defaultdict(list)
    for(w,k),v in sorted(q.items()):grouped[w].append([list(k),v.numerator,v.denominator])
    return[[[[n,list(js)]for n,js in w],cs]for w,cs in sorted(grouped.items())]
def add(*qs):
    out={}
    for q in qs:
        for k,v in q.items():out[k]=out.get(k,F(0))+v
    return clean(out)
def minus(q):return{k:-v for k,v in q.items()}
def D(q,mu):
    out={}
    for(w,k),v in q.items():
        for at,(n,js)in enumerate(w):put(out,w[:at]+((n,tuple(sorted(js+(mu,)))),)+w[at+1:],k,v)
    return clean(out)
def divergence(qs):return add(*(D(q,mu)for mu,q in enumerate(qs)))
def E(q,ids):
    partial={}
    for(w,k),v in q.items():
        for at,t in enumerate(w):
            n,js=t
            if n not in ids:continue
            sign=(-1)**(par(n)*sum(par(i)for i,jj in w[:at]));put(partial.setdefault(t,{}),w[:at]+w[at+1:],k,v*sign)
    out={}
    for(n,js),zz in partial.items():
        q=clean(zz)
        for mu in js:q=minus(D(q,mu))
        out[n]=add(out.get(n,{}),q)
    return{n:q for n,q in out.items()if q}
def unwick(q,free_mu=None,skip_timejets=False):
    out={}
    for(w,k),v in q.items():
        v=-v;mask=k[3]
        factors=[]
        for n,js in w:
            f=n-643 if 643<=n<1286 else n
            if n<1286:
                if 508<=f<553:factors.append(1) # inverse of -i
                elif f<180 and f%4==0:factors.append(-1) # inverse of i
                elif n>=643 and f<508:v=-v
            if not skip_timejets:factors.extend([-1]*js.count(0))
        if free_mu==0:factors.append(-1)
        for factor in factors:
            if mask&16:v=-v
            mask^=16;v*=factor
        put(out,w,(*k[:3],mask),v)
    return clean(out)
def tag(qs):
    out={}
    for mu,q in enumerate(qs):
        for(w,k),v in q.items():put(out,w+((2000+mu,()),),k,v)
    return clean(out)
def desc_of(w):
    out=[]
    for n,js in w:
        out.append((0,n//4,len(js))if n<180 else(1,(n-643)//4,len(js))if 643<=n<823 else(2,0,len(js))if 2000<=n<2004 else(3,n,len(js)))
    return tuple(sorted(out))
def component_word(desc,indices):
    cursor=0;result=[]
    for kind,label,jets in desc:
        if kind==3:n=label
        else:
            mu=indices[cursor];cursor+=1
            n=label*4+mu if kind==0 else 643+label*4+mu if kind==1 else 2000+mu
        result.append((n,tuple(sorted(indices[cursor:cursor+jets]))));cursor+=jets
    assert cursor==len(indices)
    return canonical(tuple(result))
def metric_components(desc,coefficients,variant='right'):
    variances=[]
    for kind,label,jets in desc:
        if kind<3:variances.append(1 if kind==1 else-1)
        variances.extend([-1]*jets)
    rank=len(variances);assert rank in[0,2,4]
    pairs=[()]if rank==0 else[((0,1),)]if rank==2 else[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
    out={};domain=set()
    for indices in product(range(4),repeat=rank):
        w,sg=component_word(desc,indices)
        if not sg:continue
        domain.add(w)
        for at,(pairing,coef)in enumerate(zip(pairs,coefficients)):
            if variant=='omit_first_rank4'and rank==4 and at==0:continue
            if any(indices[i]!=indices[j]for i,j in pairing):continue
            factor=sg
            for i,j in pairing:
                same=variances[i]==variances[j]or variant=='wrong_source'
                if same and indices[i]!=0 and variant!='wrong_metric':factor*=-1
            for key,num,den in coef:out[w,tuple(key)]=out.get((w,tuple(key)),F(0))+factor*F(num,den)
    return clean(out),domain
def case_inputs():
    out={};z=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');K=flat(z['complete_K']);Kn=flat(z['complete_K_epsilon_normal']);ee=E(K,set(range(1286,1319)));nn={}
    for n,q in ee.items():
        for(w,k),v in q.items():put(nn,((n,()),)+w,k,v)
    assert clean(nn)==Kn and add(K,minus(Kn))==divergence([flat(v)for v in z['four_IBP_currents']])
    out['KD_raw']=unwick(K);out['KD_epsilon_normal']=unwick(Kn)
    phase_count=sum(unwick(q)!=unwick(q,skip_timejets=True)for q in[K,Kn])
    joint=load(O/'complete_parent_divergence_transport.json.gz');extra={(r['role'],r['g']):r for r in joint['all_four_cases']};assert len(extra)==4
    for role in['native','replay']:
        u0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));u1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'))
        for pr,name in enumerate(['H','M']):
            for grade,raw in[(0,u0['probes'][pr]['U']),(1,u1['U1'][pr])]:
                raw=flat(raw);out[role+'_U'+str(grade)+'_'+name]=unwick(raw)
                phase_count+=unwick(raw)!=unwick(raw,skip_timejets=True)
        for g in[0,1]:
            z=load(B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz'));old=unwick(flat(z['complete_transported_portable_parent']));current=unwick(flat(z['complete_current_GF_source_parent']));P=add(old,minus(current));stored=extra[role,g]
            saved=[unwick(flat(q),free_mu=mu)for mu,q in enumerate(z['comparison']['four_complete_IBP_currents'])];new=[flat(q)for q in stored['four_symmetric_Minkowski_currents']]
            assert saved==[flat(q)for q in stored['four_literal_Minkowski_currents']]and P==flat(stored['complete_difference_Minkowski'])
            assert P==divergence(saved)==divergence(new)and not flat(stored['complete_symmetric_normal'])and not E(P,set(range(1286)))
            for key in['complete_transported_portable_parent','complete_current_GF_source_parent']:
                raw=flat(z[key]);phase_count+=unwick(raw)!=unwick(raw,skip_timejets=True)
            out[role+'_old_parent_g'+str(g)]=old;out[role+'_current_parent_g'+str(g)]=current;out[role+'_literal_current_g'+str(g)]=tag(saved);out[role+'_symmetric_current_g'+str(g)]=tag(new)
    case_inputs.phase_count=phase_count
    return out
def main():
    tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='d340b521bbec2ad57561165634252c68096f8f0d'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    prep=read(O/'preparation.json');assert prep==read(C/'preparation.json')
    historical_nav={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    for n,h in prep['sha256'].items():assert digest(historical_nav[n]if n in historical_nav else R/n)==h,n
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
    failure=read(O/'preparse_failure.json');assert not failure['scientific_worker_launched']and digest(O/'validate_preparse_failed.py.txt')==failure['source_sha256']
    try:compile((O/'validate_preparse_failed.py.txt').read_text(encoding='utf-8'),'<preserved_preparse>','exec')
    except SyntaxError as exc:assert exc.lineno==94
    else:raise AssertionError('PRESERVED_PARSE_FAILURE_NO_LONGER_FAILS')
    result=read(O/'result.json');assert result['elapsed_after_imports']<300 and len(result['cases'])==26
    expected=case_inputs();assert len(expected)==26;seen=set();checks=[];totals=Counter()
    for case in result['cases']:
        name=case['case'];ref=case['artifact'];assert digest(O/ref['file'])==ref['sha256'];Q=expected[name];assert sha256((json.dumps(encoded(Q),separators=(',',':'))+'\n').encode()).hexdigest()==case['canonical_input_sha256']
        z=load(O/ref['file']);assert Q==flat(z['input_polynomial_Minkowski'])
        if ref['file']in seen:continue
        seen.add(ref['file']);groups=defaultdict(dict)
        for(w,k),v in Q.items():groups[desc_of(w)][w,k]=v
        rec=z['reconstruction'];assert {tuple(tuple(v)for v in g['descriptor'])for g in rec['tensor_groups']}==set(groups)
        whole={};domain_count=0;control=Counter()
        for g in rec['tensor_groups']:
            desc=tuple(tuple(v)for v in g['descriptor']);got,domain=metric_components(desc,g['all_pairing_coefficients']);actual=groups[desc];residual=add(actual,minus(got));assert residual==flat(g['complete_residual'])
            assert not residual and len(domain)==g['canonical_component_domain']and len(domain)-len({w for w,k in actual})==g['zero_component_count'];whole.update(got);domain_count+=len(domain)
            for variant,key in[('wrong_metric','wrong_metric_sensitive_groups'),('wrong_source','wrong_source_variance_sensitive_groups')]:control[key]+=bool(add(actual,minus(metric_components(desc,g['all_pairing_coefficients'],variant)[0])))
            if g['rank']==4:control['missing_first_rank4_pairing_sensitive_groups']+=bool(add(actual,minus(metric_components(desc,g['all_pairing_coefficients'],'omit_first_rank4')[0])))
        assert Q==whole==flat(rec['complete_reconstructed_density'])and not flat(rec['complete_residual'])and rec['match']
        assert domain_count==rec['component_domain_count']and all(control[k]==v for k,v in rec['controls'].items());totals.update(control);checks.append(dict(artifact=ref['file'],groups=len(groups),complete_component_domain=domain_count,all_components_and_required_zeros_match=True));print('STAGE final '+ref['file']+' complete_components_match',flush=True)
    assert len(seen)==result['unique_polynomials']==12 and dict(totals)==result['metric_controls']
    assert case_inputs.phase_count==result['controls']['omitted_time_jet_phase_sensitive_cases']==16
    epsilon_jet_count=len({w for w,k in expected['KD_raw']if any(1286<=n<1319 and js for n,js in w)});assert epsilon_jet_count==result['controls']['dropped_local_epsilon_jet_words']==132
    for i in range(643):
        # Exact inherited source/field Wick dual product, independently of tensors.
        f=unwick({((((i,()),(643+i,())),(0,0,0,0))):F(1)})
        assert f and len(f)==1 and next(iter(f.values()))==F((-1)**par(i))
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'
    assert b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V848.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V848.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V848.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8')),(O/'PROOF.md',(O/'PROOF.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V848.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_COMPLETE_SELECTED_AUGMENTED_FIXED_METRIC_LIFT_AND_BOUNDARY_INTERFACE',base_HEAD=head,state_sha256=state,all26_case_bindings_checked=True,unique_polynomials=12,independent_complete_component_checks=checks,all_parent_difference_Eulers_and_divergences_zero=True,local_epsilon_jet_words_retained=epsilon_jet_count,metric_controls=dict(totals),firstDjet_loop_contact_QAP_E5_and_physical_viability_NOT_established=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_tensor_rule_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','unique_polynomials','local_epsilon_jet_words_retained','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
