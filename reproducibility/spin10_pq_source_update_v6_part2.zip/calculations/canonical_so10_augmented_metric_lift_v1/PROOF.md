# A fixed tensor lift of the actual selected augmented densities

The [existing dimensional applicability owner](../canonical_so10_dimensional_counterterm_applicability/DERIVATION.md)
defines a typed metric constructor for the approved action: keep internal
Spin(10) representations,parameters and evaluation-dual sources fixed; extend
only spacetime metric contractions. This is the constructor used here, without
additional(D-4)terms or dimension-dependent density coefficients. It is not a
claim that four-dimensional components determine every possible continuation.

V846 matched the complete GF+source A0,g<=1,intrinsic0/1 actions modulo explicit
ordinary divergences. V847 matched the selected M positive covariance after
t_new=2t_old and derived the finiteclock shift. Neither supplied the complete
currentKD/probe tensor lift. This increment tests that actual missing interface,
not a new quantum coefficient or a stronger scientific acceptance target.

## Exact coordinates and local marks

Current coordinates are643 fields,643 sources and33 local odd scalar epsilon
components. B_mu is lower; J_B^mu is its upper evaluation dual. Scalar fields,
ghosts,nonminimal fields/sources and epsilon are Lorentz scalars. Every ordinary
derivative adds a lower slot,including derivatives of epsilon. Internal epsilon
and selfduality tensors in scalar representations are unrelated to spacetime.

The component packets are Euclidean. Pull them back with the EXACT field/source
phases and +i per timejet,then densityminus. Epsilon has no extra Wick phase.
Source phases are not guessed from field phases: their product is
-(-1)^p for a conjugate pair. This preserves the qualified bracket orientation.
For currents P_E=div_E j_E, the correct pullback is
j_M^mu=-i^(-delta_mu0) W^-1 j_E^mu. A lower auxiliary testvector makes the
same factor explicit. Its timecomponent has Wickphase+i. No free index is
treated as a scalar or silently given a source phase.

## Complete metric and graded-orbit reconstruction

Erase Lorentz components while retaining each field/color/source identity and
number of commuting derivative slots. KD has rank0/2; the U0/U1 and GF/source
densities,or a dimension-three current paired with a lower testvector,have
rank0/2/4. Unexpected rank is an explicit failure,not a discarded row.

Rank2 has one pairing. Rank4 has three: (12)(34),(13)(24),(14)(23). For equal
variance each pair is the Minkowski metric; for opposite variance it is the
evaluation delta. Generate the full component columns,then canonicalize the
graded field product and commuting jets. Identical factors produce actual
integer orbit multiplicities; identical odd jets vanish. Treating factors as
distinguishable after this projection would give wrong coefficients.

The small component matrix is INTEGER. Native solves by rational RREF; replay
uses the independent column Gram matrix and exact rational projection. The
Gram matrix is only a computational device. Physical coefficients remain
symbolic rational/radical cells; only rational integers are divided. Every
raw nonzero and the complete canonical component/zero domain are compared.
The evidence retains all pairing coefficients,descriptors,reconstructed
densities and residuals. Byte-identical polynomials can share an artifact
after exact equality; all original route/case bindings are retained.

The constructor is faithful at these ranks for any index range: a paired
rank<=4 component uses at most two distinct labels. Relabel its nonzero pattern
to0/1 to see it in4D. Components with more distinct labels vanish in every
template. Graded identical-factor and jet relations are universal orbit
relations,not identities peculiar to dimension4. There are no closed numeric
metric loops or explicit D coefficients in these density/current templates.
Thus equality of the reconstructed4D tensor expressions is equality under
the FIXED constructor for arbitrary index range. Later Hessian/Born sewing
can create closed vector loops; those supplyD and must not be set4 first.

## Boundary identities remain part of the lift

Authenticate and recheck every old V846 current quadruple and its FULL
divergence. Individual currents from a derivative-order homotopy need not
be covariant; no such property is assumed. Independently construct currents
by averaging all commuting derivative orders in the homogeneous variational
formula. For each complete parent difference P,

    P = N(P)+sum_mu partial_mu j_sym^mu,
    N(P)=sum_(n,i) z_i E_i(P_n)/n + constant(P).

All normals vanish. New and original currents have the same divergence.
Reconstruct the new currents as metric tensors. Ordinary differentiation
commutes with constant metric contractions and the graded orbit projection,
so the tensor identity extends with the same constructor. In the actual
computed packets the original currents also pass,which is a measured result,
not a requirement imposed by deleting noncovariant pieces. KD's separate
epsilon-normal representative is checked against its full local Euler
derivative and original currents before either is reconstructed.

## Consequence and limits

A successful final validation establishes a classical fixed-constructor lift
for the complete selected KD,U0/U1 and GF/source parent slice WITH its currents.
The sourcefree physical action/potential is a separate qualified premise;
fullbackground,highercoupling,chiral matter and unrestricted E2 are outside
this calculation. H/M are internal color sectors,not Lorentz projections.
The density calculation does not select profiles outside V847's actual M
sector. No firstDjet of the LOOP functional,contact mixing,QAP,measure,A5,
common quantum restoration or E5/A5 acceptance follows automatically.

Next assess the actual augmented-parent word/domain and common probe extension
of Cfin,with its retained heatpower/reference/firstDjet terms. In particular
rhoKD,epsilon and U must be kept together under differentiation; a source-only
or homogeneousD simplification is not the geometric W5 requirement.

Shared action,coordinate conventions,original tensor rule,Python and AI
authorship limit independence. The exact methods can test implementation
errors,not independently establish the shared physical hypothesis. No Lean,
independent human or experimental validation is supplied. Authority remains
solely in project_state.json; all protected blocks and physicalwarnings remain.
