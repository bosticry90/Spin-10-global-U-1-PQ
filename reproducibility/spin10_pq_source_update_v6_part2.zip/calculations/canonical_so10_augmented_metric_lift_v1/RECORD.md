# V848: complete augmented-parent fixed metric constructor

Question: do the complete current KD, U0/U1 and the V846 GF/source parent
differences/currents admit the SAME fixed typed metric constructor already
qualified by dimensional_counterterm_applicability? This is the next actual
applicability bridge after the V847 positive-M heat-clock comparison, before
using the older common Cfin action/insertion conversion. No new loop integral.

Previous goal turn made progress: V846/8ef9051e and V847/d340b521 committed,
corrected a shared absolute-clock interpretation error and preserved allfailed
evidence. Current preflight d340b521bbec2ad57561165634252c68096f8f0d is clean,
no research workers. Root owns writes/execution/Git, two AI reviews read only.
Main,D:,liveAGENTS/charter/solo/epistemic policy. State113/34of39,flavorpause,
HB1/C5blocks,E5/A5open and seven custodyNOTPASS unchanged. No adoption,
physicalinputchange,branch/worktree,protectedpromotion,push or publication.

Bind complete KD2430rows and its epsilon-normal representative from V836,
both actual U0H/M and U1H/M route packets, and all four V846 old/current
GF+source densities and saved fourcurrents. Epsilon is an odd LorentzSCALAR;
retain all its ordinary jets. SourceJB is UPPER/evaluation-dual; B and
derivative slots LOWER. Nonminimal sources/scalars are LorentzSCALARS.
Undo actual Wick field/source/timejet phases and densityminus BEFORE metric
reconstruction. No spacetime epsilon/chiral/hatted tensor is imported.

KD rank<=2; U,GF/source densities and current times a lower testvector rank<=4.
The current output index is upper. Reconstruct ALL rank0/2/4 typed templates,
including three rank4 pairings, commuting jet symmetries and graded identical
factor orbit multiplicities. Native uses rational component RREF; replay uses
exact Gram projection on the independent INTEGER template columns. Physical
coefficients stay symbolic Fraction/radical cells; no physical parameter is
inverted/fitted. Retain every reconstructed tensor coefficient,complete
residual and canonical component/zero coverage; unexpected rank fails explicitly.
Gram is computational linear algebra,not a physical kinetic inner product.

Saved IBP currents are authenticated and their FULL divergence rechecked.
They need not be individually covariant because their derivation picks a
derivative order. Preserve literal carrier failures if found. Independently
construct symmetric-derivative homogeneous variational currents for each
distinct parent difference; require full P=N+divj,N=0 and metric reconstruction
of these new currents. Do not discard original currents or density differences.
The sourcefree physical action/potential remains a separate qualified premise.

Within the FIXED old constructor(no added(D-4)terms,closednumericloops or
dimension-dependent coefficients), rank<=4 metric identities are faithful
at4: each pairing involves at most two distinct index labels. Orbit relations
of identical fields/jets and Grassmann signs are universal. Whole4D equality
of these tensor expressions therefore extends to arbitrary index range by
renaming indices,not by fitting a new continuation. Formal divergence commutes
with this constructor; later Hessian/Born closedvectortraces must giveD,not4.
This does NOT compute alpha'_4(loop),prove contact normalization,QAP,equivalence,
fullphysical/background/chiral lift or fullE5. Arbitrary evanescent lifts are
not ruled out; retaining the original constructor excludes them by definition.

Sensitive controls: wrong Minkowski metric/sourcevariance, omitted timejet
phase, dropped epsilon jets and missing rank4 pairing. Report actual blind
cases honestly; require sensitivity only where support exists. Preserve whole
failure/residuals before disposition. Fixed old density constructor and actual
component definitions are mathematical anchors,not external verification.

One300s afterimports,8GiB sampled/350MiBlaunchfloor,64MiBpacket/8MiBartifact.
Freeze sources/copies/allactualinput and receipt hashes before computation.
Identical polynomials may share a reconstructed artifact ONLY after exact
canonical-byte comparison; all original case bindings remain. No silent
truncation/resource expansion; incomplete/failure remains NOTPASS. Outcomes:
complete scoped lift bridge, literal/functional mismatch or boundedinconclusive.
Separate finalvalidation/E4/navigation/exactstaging before any localcommit.
