from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-uv-grading-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b2b4c7c4f52712bcf2d087787ebc746b9d82d5c2'
names=set(json.loads((O/'preparation_v2.json').read_bytes())['sha256'])|{'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V851.md','calculations/canonical_so10_joint_born_ir_trace_domain/domain_v2.py'}
for n in['PROOF.md','RESULT.md','FINAL_RECORD.md','validate.py','execute_validation.py','CONTINUATION_FINAL_V2.md','build_final_v2.py','validate_v2.py','execute_validation_v2.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    if (O/(n+'.source.txt')).exists():assert(O/(n+'.source.txt')).read_bytes()==(O/n).read_bytes()
    else:
        with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_validation_v2.json',prep);dump(C/'preparation_validation_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'validate_v2.py')]);dump(O/'capture_validation_v2.json',cap);dump(C/'capture_validation_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
