from pathlib import Path
import ast
O=Path(__file__).resolve().parent
q=(O/'validate.py').read_text(encoding='utf-8')
old="assert row['exact_equal']==(live==stored)and live.replace(b'\\r\\n',b'\\n')==stored and row['only_CRLF_to_LF']"
new="assert row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\\r\\n',b'\\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])"
assert q.count(old)==1;q=q.replace(old,new)
q=q.replace("'preparation_validation.json'","'preparation_validation_v2.json'").replace("'validation_receipt.json'","'validation_receipt_v2.json'")
needle="    failed=read(O/'capture.json');"
assert q.count(needle)==1;q=q.replace(needle,"    old_final=read(O/'capture_validation.json');assert old_final==read(C/'capture_validation.json')and old_final['exit_code']==1 and not old_final['calculation_completed']and 'input_encoding_bindings'in (O/'validate.py').read_text(encoding='utf-8')\n    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n\n"+needle)
q=q.replace("failed_setup_and_false_base_census='PRESERVED_FAILED_NOTPASS'","failed_setup_false_base_census_and_encoding_verifier='PRESERVED_FAILED_NOTPASS'")
p=(O/'execute_validation.py').read_text(encoding='utf-8')
p=p.replace("'execute_validation.py']:","'execute_validation.py','CONTINUATION_FINAL_V2.md','build_final_v2.py','validate_v2.py','execute_validation_v2.py']:")
p=p.replace("with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())","if (O/(n+'.source.txt')).exists():assert(O/(n+'.source.txt')).read_bytes()==(O/n).read_bytes()\n    else:\n        with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())")
for old,new in [('preparation_validation.json','preparation_validation_v2.json'),('capture_validation.json','capture_validation_v2.json'),("str(O/'validate.py')","str(O/'validate_v2.py')")]:
    assert old in p;p=p.replace(old,new)
for name,body in [('validate_v2.py',q),('execute_validation_v2.py',p)]:
    ast.parse(body)
    with(O/name).open('x',encoding='utf-8',newline='\n')as f:f.write(body)
print('EXCLUSIVE_FINAL_V2_ENCODING_BRANCH_CORRECTION')
