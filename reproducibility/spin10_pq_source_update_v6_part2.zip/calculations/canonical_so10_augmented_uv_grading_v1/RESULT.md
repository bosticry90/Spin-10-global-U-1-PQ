# V851: selected UV grading and finite local Born gates

Requires the completed separate final receipt/capture. Goal ACTIVE,main,D:;
authority34/39 and project_state.json unchanged; E5/A5 remain open.

Both corrected routes completed32.143s after imports. Per route they classify
157,200 literal words,493,699 two-ordinary-port placements and382,646 known
F/E type rows. No negative parent defect or intrinsic dimension appears.
The complete1543-entry marginal base kinetic kernel equals V791's physical
reference kernel; positive reference masses stay separate. V850's six whole
beta-breaking kernel cancellations remove the otherwise possible UV order+1
unlabelled root. Every remaining marginal factor consumes a bounded formal
grade. The [proof](PROOF.md) gives conservative local UV Born length<=8.

This is a finite bound for UV symbols/conversion terms, not for the entire
nonlocal Born functional. It reuses the old fixed-word rational/Gaussian
remainder argument with the actual augmented type premises and retains all
heat-power products, finite clock constants and the full reference.

Two failures are preserved. A preparatory raw-byte Git check stopped on
checkout CRLF versus stored LF before launching a worker. Both exact hashes
and the strictly CRLF-to-LF relation are now recorded; no file or old binding
was changed. The first scientific worker then required an actual positive-cost
unlabelled g0 base term that is absent. Its assertion and capture remain
FAILED. The older432 mixed rows are g-dependent, not g0 base evidence.
The corrected run records the actual empty census and retains a synthetic
cost1 mixed-vertex control without requiring that vertex in the current base.

Separate final verification must independently rebuild all typed-port and
cofactor rows, reference comparison, grade grammar and failure/encoding checks.
This result narrows the applicability gap without another quantum integral.
It does not yet qualify the augmented source differential's first-dimension-
jet commutation, a common normalized contact prescription, geometric W5 or
restoration. That source/jet bridge is the next smallest mathematical test.
No alpha'_4 coefficient, physical normalization or benchmark is adopted.

Methodology assessment: the complete scope check corrected a coupling-order
misreading before it could enter the final proof. The correction required
one failed worker; the strict evidence and encoding checks also add overhead.
The gain is a justified finite local problem, rather than an arbitrary Born
cutoff. Shared physical inputs, software, conventions and AI authorship still
limit independence; physical perturbative and gauge-matching warnings remain.
