# Preserve false base-census premise; perform the actual census

The first scientific worker exited1 at ACTUAL_INTRINSIC1_CONSTANT_BASE_NOT_IDENTIFIED.
The assertion required a positive-cost unlabelled quadratic port in the current
UNPROBED S0_GF parent and an intrinsic1 example. Its computed list was empty.
It had already passed the complete1543-entry marginal reference comparison.
No artifact/result was written. Preserve compute.py, its source copy and full
FAILED capture; it is not a qualified calculation of the remaining family.

The expectation imported an older domain description without establishing
that its mixed base term occurs in this exact current parent. The corrected
producer records ALL current base ports and an empty/nonempty disposition;
it does not require a positive-cost term to exist. The scientific UV gates
remain: exact marginal kernel=Kref's Pphysical, no negative parent defect,
nonnegative type deficits, complete B2 cancellation and bounded grades.
Whether the residual positive-cost base is empty does not weaken those gates.

Do not infer that every allowed base vertex always improves by2. A retained
synthetic Lambda-x constant vertex with intrinsic dimension1 has defect1;
the general proof uses >=1 and remains valid when the actual base list is
empty. Record this as a synthetic admitted-type control, not an actual
unprobed measurement. Unknown scalar potential mass vertices retain cost2.

All original limits and inputs remain, with new compute_v2/execute_v3,
source copies, preparation_v2/capture_v2/result_v2 and v2 artifacts. Final
verification authenticates the failed premise and independently derives the
corrected complete census. No prior capture, preparation or input is edited.
