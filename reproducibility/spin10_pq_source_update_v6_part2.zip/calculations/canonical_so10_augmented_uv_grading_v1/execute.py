from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-uv-grading-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b2b4c7c4f52712bcf2d087787ebc746b9d82d5c2'
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names=set(json.loads((R/'calculations/canonical_so10_augmented_operator_ir_domain_v1/preparation_b2.json').read_bytes())['sha256'])
for folder in['canonical_so10_ub12_reference_symbol','canonical_so10_ordered_multiheat_uv_log','canonical_so10_heat_mellin_matching','canonical_so10_finite_heat_transgression','canonical_so10_dimensional_stokes_primitive','canonical_so10_geometric_ward_products','canonical_so10_actual_normalization_assembly','canonical_so10_augmented_operator_ir_domain_v1','canonical_so10_full_jet_source_master_bridge']:
    for p in(R/'calculations'/folder).iterdir():
        if p.name in['DERIVATION.md','DERIVATION_V2.md','PROOF.md','RESULT.md','validation_receipt.json','final_review_validation_receipt.json','native_complete_operator_ir_audit.json.gz','replay_complete_operator_ir_audit.json.gz','native_constant_beta_breaking_gate_v2.json.gz','replay_constant_beta_breaking_gate_v2.json.gz','jets.py']:names.add(p.relative_to(R).as_posix())
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for name,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/name).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={'docs/RESEARCH_EXECUTION_HANDOFF_V850.md'}|{p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
