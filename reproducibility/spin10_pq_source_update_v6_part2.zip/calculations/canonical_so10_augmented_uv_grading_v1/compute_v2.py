from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from hashlib import sha256
from itertools import combinations,product
import ast,gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-uv-grading-v1-2026-11-08')
spec=importlib.util.spec_from_file_location('V851_BOUND_WORD_CODEC',B/'canonical_so10_augmented_metric_lift_v1/algebra.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/name).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2
    return dict(file=name,sha256=digest(O/name),bytes=len(blob))
def dim(n):return 1 if 1286<=n<1319 else 3-dim(n-643)if n>=643 else 2 if 508<=n<553 else 1
def ports(raw,D,replay=False):
    records=[];hist=Counter();bad=[];marginal=[];count=0
    for at,(word,cells)in enumerate(raw):
        bare=sum(dim(n)+len(js)for n,js in word);intrinsic=D-bare
        if intrinsic<0:bad.append([at,'NEGATIVE_INTRINSIC_COEFFICIENT_DIMENSION',intrinsic,word,cells])
        positions=[p for p,(n,js)in enumerate(word)if n<643];rows=[]
        for i,j in combinations(positions,2):
            ni,di=word[i];nj,dj=word[j];remaining=[term for p,term in enumerate(word)if p not in[i,j]];cost=intrinsic+sum(dim(n)+len(js)for n,js in remaining);qorder=len(di)+len(dj)
            defect=(2-dim(ni))+(2-dim(nj))-qorder if not replay else 4-D+cost
            assert defect==4-D+cost
            label=[sum(n<643 for n,js in remaining),sum(643<=n<1286 for n,js in remaining),sum(1286<=n<1319 for n,js in remaining)]
            rr=[i,j,ni,nj,qorder,cost,defect,label];rows.append(rr);count+=1;hist[defect]+=1
            if defect<0:bad.append([at,'NEGATIVE_RELATIVE_DEFECT',rr,word,cells])
            if defect==0:marginal.append([at,rr])
        records.append(dict(density_word_index=at,complete_word=word,complete_coefficient_cells=cells,declared_density_dimension=D,intrinsic_coefficient_dimension=intrinsic,all_two_ordinary_port_positions=rows))
    return dict(all_density_words_and_ports=records,port_count=count,defect_histogram=[[d,n]for d,n in sorted(hist.items())],all_marginal_ports=marginal,all_counterexamples=bad)
def field_type_bounds(packet):
    records=[]
    for name,table in packet['states'].items():
        for i,raw in table:
            target=dim(i)+1 if name.startswith('F')else 4-dim(i)
            for at,(word,cells)in enumerate(raw):
                deficit=target-sum(dim(n)+len(js)for n,js in word);assert deficit>=0,(name,i,at,word,deficit);records.append([name,i,at,target,deficit])
    for name,table in packet['physical'].items():
        for i,raw in table:
            target=4-dim(i)
            for at,(word,cells)in enumerate(raw):
                deficit=target-sum(dim(n)+len(js)for n,js in word);assert deficit>=0;records.append([name,i,at,target,deficit])
    return records
def grammar():
    # Relaxed grammar: one unit-grade token may have cost0; ungraded cost>=1.
    # Every transition increases cost or a bounded grade. No length truncation.
    zero=(0,0,0,0);marginals=[tuple(int(j==i)for j in range(4))for i in range(4)];tables=[]
    for budget in range(5):
        dp={(0,zero):0}
        for total in range(budget+5):
            for(cost,grade),length in list(dp.items()):
                if cost+sum(grade)!=total:continue
                for addcost,addgrade in[(1,zero)]+[(0,g)for g in marginals]:
                    cc=cost+addcost;gg=tuple(x+y for x,y in zip(grade,addgrade))
                    if cc>budget or any(x>1 for x in gg):continue
                    dp[cc,gg]=max(dp.get((cc,gg),-1),length+1)
        for gg in product(range(2),repeat=4):
            measured=max(n for(c,g),n in dp.items()if g==gg);predicted=budget+sum(gg);assert measured==predicted;tables.append([budget,list(gg),measured,predicted])
    assert max(row[2]for row in tables)==8
    return tables
def zero_cost_base(role,audit):
    merged={};q=s.symbols('q0:4');xi,eta=s.symbols('xi eta_H');radicals=[s.sqrt(s.prod(p for b,p in enumerate([2,3,5,7])if mask&(1<<b)))*(s.I if mask&16 else 1)for mask in range(32)]
    for row in audit['all_zero_transfer_density_audits']:
        if row['density']not in['S0_GF_source','physical_S0_gauge','physical_S0_scalar']:continue
        for i,j,p,k,num,den in row['complete_zero_transfer_Euler_Fourier_kernel']:
            if 4-dim(i)-dim(j)-sum(p)!=0:continue
            value=s.Rational(num,den)*s.Symbol('g10')**k[0]*xi**k[1]*eta**k[2]*radicals[k[3]]*s.prod(q[mu]**power for mu,power in enumerate(p));merged[i,j]=merged.get((i,j),0)+value
    actual={(i,j):s.expand(v)for(i,j),v in merged.items()if s.expand(v)!=0};expected={(i,j):s.sympify(v)for i,j,v in load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'))['Pphysical']}
    assert set(actual)==set(expected)and len(actual)==1543
    for ij,v in actual.items():assert s.expand(v-expected[ij])==0,ij
    return[[i,j,str(actual[i,j])]for i,j in sorted(actual)]
def potential_degrees(node):
    k=node['node']
    if k=='Field':return{(1,0)}
    if k=='Parameter':return{(0,node['mass_dimension'])}
    if k in['ExactScalar','InvariantTensor','KroneckerMetric','StructureConstant','RepresentationGenerator']:return{(0,0)}
    if k in['GroupContraction','LorentzContraction']:return potential_degrees(node.get('expression',node.get('argument')))
    if k=='Add':return set().union(*(potential_degrees(c)for c in node['terms']))
    if k=='OrderedProduct':
        z={(0,0)}
        for c in node['factors']:z={(n+m,d+e)for n,d in z for m,e in potential_degrees(c)}
        return z
    raise AssertionError(('POTENTIAL_NODE',k))
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for name,h in read(O/'preparation_v2.json')['sha256'].items():assert digest(R/name)==h,name
    ast=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');potential=[]
    for row in ast['local_terms'][5:]:
        ds=potential_degrees(row['density']);assert all(n>=2 and d>=0 and n+d==4 for n,d in ds);potential.append([row['term_id'],[list(x)for x in sorted(ds)]]);assert all(d==2 for n,d in ds if n==2)
    kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');dr=[]
    for i,raw in kd['all1286_D']:
        target=dim(i)
        for at,(word,cells)in enumerate(raw):
            deficit=target-sum(dim(n)+len(js)for n,js in word);assert deficit>=0;dr.append([i,at,target,deficit])
    roles=[]
    for role in['native','replay']:
        u=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));s1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));s0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF'];dens=[('S0_GF_source',s0,4),('S1_GF_source',s1['S1'],4)]+[('U0_'+n,u['probes'][pr]['U'],4)for pr,n in enumerate(['H','M'])]+[('U1_'+n,s1['U1'][pr],4)for pr,n in enumerate(['H','M'])]+[('KD',kd['complete_K'],3)];phys=load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/('native_v2_action.json.gz'if role=='native'else'replay_v4_action.json.gz'));dens+=[('physical_'+name,raw,4)for name,raw in phys.items()];reports=[]
        for name,raw,D in dens:
            first=ports(raw,D);second=ports(raw,D,replay=True);assert first==second and not first['all_counterexamples'];reports.append(dict(density=name,**first))
        audit=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_complete_operator_ir_audit.json.gz'));breaking=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_constant_beta_breaking_gate_v2.json.gz'));assert all(not row['complete_B_Euler_Fourier_kernel']['complete_zero_transfer_Euler_Fourier_kernel']for row in breaking['all_six_cases'])
        ref=zero_cost_base(role,audit);fieldtypes=field_type_bounds(load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz')));bins=Counter(x[-1]for x in fieldtypes);base_positive=[]
        for row in reports[0]['all_density_words_and_ports']:
            for port in row['all_two_ordinary_port_positions']:
                if port[5]>0 and not any(port[7]):base_positive.append([row['density_word_index'],port])
        synthetic_mixed_cost=4-dim(508)-dim(180);assert synthetic_mixed_cost==1
        fixture_unlabeled_beta_BC=dict(density_dimension=5,ports=[0,553],quantum_derivative_order=3,remaining_test_labels=0,relative_defect=4-5);assert fixture_unlabeled_beta_BC['relative_defect']==-1
        controls=dict(introduced_ungraded_cost0_has_unbounded_selfcycle=True,erased_label_beta_BC_has_negative_defect=fixture_unlabeled_beta_BC,introduced_reference_marginal_BB_massless_kinetic_not_subtracted=True,synthetic_admitted_Lambda_x_constant_defect=synthetic_mixed_cost,actual_unprobed_base_positive_cost_ports=len(base_positive))
        artifact=save(role+'_complete_UV_grading_v2.json.gz',dict(all_literal_parent_density_ports=reports,all_GF_source_and_known_physical_cofactor_type_rows=fieldtypes,cofactor_intrinsic_histogram=[[d,n]for d,n in sorted(bins.items())],all_D_type_rows=dr,all29_physical_potential_degrees=potential,complete1543_base_zero_cost_kernel_equals_Pphysical=ref,complete_positive_cost_unlabeled_base_ports=base_positive,all6_beta_zero_transfer_kernels_zero=True,all4_dimensions_and_UV_weights=[[i,dim(i),2-dim(i)]for i in range(1319)],relaxed_all_grade_cost_grammar=grammar(),negative_controls=controls,quantum_or_nonlocal_Born_truncation_NOT_claimed=True))
        roles.append(dict(role=role,artifact=artifact,all_literal_density_words=sum(len(z['all_density_words_and_ports'])for z in reports),all_selected_port_pairs=sum(z['port_count']for z in reports),cofactor_type_rows=len(fieldtypes),positive_cost_unlabeled_base_ports=len(base_positive),reference_entries=len(ref)))
        print('STAGE '+role+' complete_UV_types_and_marginal_reference_checked',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='SELECTED_AUGMENTED_UV_GRADING_AND_FINITE_LOCAL_BORN_GATES_SUPPORTED',conservative_local_UV_Born_length_bound=8,coefficient_extraction_NOT_physical_u_squared_zero=True,UV_weights_NOT_IR_weights=True,roles=roles,actual_first_D_jet_coefficients_or_common_contacts_NOT_evaluated=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_v2.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
