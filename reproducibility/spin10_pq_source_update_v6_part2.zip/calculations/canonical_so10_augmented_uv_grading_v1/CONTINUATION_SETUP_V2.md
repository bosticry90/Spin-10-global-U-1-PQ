# Preserve setup failure; bind both stored and checkout encodings

The first execute.py stopped BEFORE preparation, source copying or any
scientific worker: its raw live==git-blob assertion rejected A31_embeddings.
Inspection shows exactly5007 CRLF pairs in the90607-byte checkout versus
the85600-byte LF Git blob, identical after ONLY CRLF-to-LF replacement.
Git reports i/lf,w/crlf,text,eol=lf. JSON objects agree. No physical input
or file was edited; original failed wrapper remains unchanged.

New execute_v2 authenticates BOTH exact checkout bytes and Git blob bytes.
Each nonidentical pair must differ ONLY by CRLF-to-LF and be declared by
Git as text. Preserve a complete per-input encoding report, both hashes,
the failed wrapper source and full observed setup traceback. The calculation
binds actual checkout bytes; no old hash or manifest is rewritten. Existing
historical encodings remain what their owners recorded. This is not a
generic semantic-equality or weakened integrity exception.

All scientific questions, computation sources, acceptance conditions and
120s/8GiB/64MiB/8MiB bounds stay unchanged. The first wrapper did not earn
a scientific capture or result. V2 uses a new source/copy. Final validation
must authenticate the raw hashes, encoding report and pre-worker failure.
