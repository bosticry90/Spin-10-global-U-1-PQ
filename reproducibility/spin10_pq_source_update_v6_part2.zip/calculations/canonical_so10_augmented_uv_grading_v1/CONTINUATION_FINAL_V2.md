# Correct the verifier's exact-byte encoding branch

The first final worker exited1 during encoding verification, before its
mathematical replay and E4. Its assertion required CRLF-to-LF equality even
when the checkout already matched the Git blob byte for byte. Some stored
files themselves contain CRLF; replacing their bytes is neither necessary
nor a valid equality test. Preserve the complete failed source/preparation/
capture and no receipt. This is a verifier logic error, not a science PASS.

New validation requires recorded exact-equality and recorded CRLF relation
booleans to equal their actual values. Admission is EITHER exact bytes OR
the already declared text-only CRLF-to-LF relation. All raw checkout and Git
hashes remain mandatory and unchanged. No general whitespace/JSON semantic
equivalence is admitted, no input is edited, and no historical hash is rebound.

Same240s/8GiB sampled/64MiBpacket/8MiBartifact; all original mathematics,
negative controls, status and E4 requirements stay unchanged. New v2 sources,
preparation/capture/receipt names; final validation also authenticates the
first failed verifier and frozen files. E4 has not run in the first attempt.
