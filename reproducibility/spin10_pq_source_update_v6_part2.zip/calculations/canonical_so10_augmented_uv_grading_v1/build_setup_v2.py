from pathlib import Path
import ast,json
from hashlib import sha256
O=Path(__file__).resolve().parent
old=(O/'execute.py').read_text(encoding='utf-8')
needle="for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n"
replacement="""encodings=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:
        assert live.replace(b'\\r\\n',b'\\n')==stored,n
        attrs=subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip();assert attrs.endswith(': text: set'),(n,attrs)
    encodings.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\\r\\n',b'\\n')==stored))"""
assert old.count(needle)==1;new=old.replace(needle,replacement)
new=new.replace("for n in['RECORD.md','compute.py','execute.py']:","for n in['RECORD.md','compute.py','execute.py','CONTINUATION_SETUP_V2.md','build_setup_v2.py','execute_v2.py']:")
new=new.replace("names|={'docs/RESEARCH_EXECUTION_HANDOFF_V850.md'}", "dump(O/'input_encoding_bindings.json',dict(bindings=encodings));dump(C/'input_encoding_bindings.json',dict(bindings=encodings))\nnames|={'docs/RESEARCH_EXECUTION_HANDOFF_V850.md'}")
ast.parse(new)
with(O/'execute_v2.py').open('x',encoding='utf-8',newline='\n')as f:f.write(new)
failure=dict(execution_state='FAILED',stage='BEFORE_PREPARATION_AND_SCIENTIFIC_WORKER',failed_wrapper_sha256=sha256((O/'execute.py').read_bytes()).hexdigest(),command='python -B calculations/canonical_so10_augmented_uv_grading_v1/execute.py',observed_exit_code=1,complete_observed_output='Traceback (most recent call last):\n  File "D:\\Codex-Projects\\ToE-Next\\calculations\\canonical_so10_augmented_uv_grading_v1\\execute.py", line 14, in <module>\n    for n in names:assert(R/n).read_bytes()==subprocess.check_output([\'git\',\'show\',\'HEAD:\'+n],cwd=R),n\nAssertionError: tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_action_ast_a3/A31_embeddings.json\n',classification='CHECKOUT_CRLF_VERSUS_GIT_LF_NOT_SCIENTIFIC_RUN_NOTPASS',output_source='COMPLETE_OBSERVED_EXEC_COMMAND_OUTPUT_PRESERVED_NOT_A_REEXECUTED_CAPTURE')
with(O/'setup_failure.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(failure,f,sort_keys=True);f.write('\n')
print('EXCLUSIVE_SETUP_V2_BUILT_FAILURE_PRESERVED')
