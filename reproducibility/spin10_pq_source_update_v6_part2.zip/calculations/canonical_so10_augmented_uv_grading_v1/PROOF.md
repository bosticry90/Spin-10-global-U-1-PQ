# Finite local UV words for the selected augmented family

The claim is coefficientwise, in the original unshifted Euclidean A0 chart,
g<=1, first-u H/M, first-rho and one LEFT beta insertion. The parent is
Sigma=S+uU+rho K_D and B=B[**Sigma before beta**]=sum FE. Do not introduce
a second Q from the beta-deformed action. V849's arbitrary-source Taylor
identity, including E*T²F and all ordinary currents, controls the one-first-Q
insertion. V850 supplies whole zero-transfer kernels and the joint-IR
structural premises. All claims require the completed separate final receipt.

## Actual UV types and marginal reference

Let d(B,x,C,a)=1,dLambda=2,dJi=3-di,depsilon=1 and ti=2-di. These are the
actual project UV dimensions; scalar x has UV weight1 and IR weight0.
The qualified weighted inverse has ord Gij<=-ti-tj. No inverse physical
coupling, width or mass occurs in the principal inverse. Positive scalar
reference masses are retained and expanded only on a hard UV shell.

For a two-ordinary-port placement (j,k) in a local density of dimension D,
let c be the nonnegative dimension of its remaining fields/sources/epsilon,
ordinary jets and intrinsic coefficient. The derivative order on its two
quantum legs is q=D-dj-dk-c, so

  delta=tj+tk-q=4-D+c,
  ord(GV)_(i,k)<=tk-ti-delta.

All157,200 literal density words and493,699 port pairs per route satisfy
the recorded parent bounds. Declared intrinsic1 components preserve their
dimension even when their numerical coefficients are rational. The382,646
known F/E type rows per route obey F_i dimension<=di+1,E_i<=4-di. Therefore
their B products have dimension<=5 without needing to expand every color
product. Unknown physical potential/scalar Eulers are not assigned zero.
All29 potential ASTs obey arity+parameter dimension=4; quadratic scalar
terms have coefficient dimension2 and their Hessians improve UV by2.

The COMPLETE dimension-zero zero-transfer S0_GF+physical kinetic kernel
matches all1543 V791 Pphysical entries. Adding the positive reference mass
difference yields Kref. Hence no independent ungraded marginal base term
remains in V=H-Kref. The actual positive-cost unlabelled S0_GF port census
is empty. This does not discard g-dependent constant terms or scalar masses.
The old432 scalar-auxiliary rows in joint_born_ir_trace_domain/domain_v2.py
are selected by coefficient−coefficient(g=0): zero-transfer is distinct from
coupling-independent. The first worker's assertion of a current g0 cost1
example was false and remains FAILED. A synthetic admitted Lambda-x
constant term has cost1, so the general proof deliberately uses >=1 rather
than an unsupported universal mass-only improvement2.

## Beta and the finite-grade word bound

S/U have D4, so delta=c>=0. KD has D3 and keeps its local epsilon, hence
delta=1+c>0. beta is constant of dimension−1; B has D5 and would permit
delta=c−1. However a zero-label quadratic beta root is the WHOLE Fourier
kernel tested in V850, and all six such kernels vanish. Every surviving
beta Hessian root retains a genuine positive-dimensional mean/source/epsilon
label; thus c>=1 and delta>=0. rho pieces retain epsilon as well. Ordinary
integration-by-parts currents are kept, not zeroed as local densities.

Outside the removed reference, each ungraded nonzero base root has cost
delta>=1. Any remaining marginal delta0 root consumes a positive bounded
g,u,rho or beta grade. At a requested coefficient with each grade<=1 there
can be at most four such roots. Around a closed word the ti cancel, giving
total order<=−sum delta. A local UV subtraction degree>=−4 has at most
four positive-defect roots. Thus n<=4+4=8 is a conservative bound for the
local UV/conversion words in this declared family. It is intentionally not
an optimized bound or a truncation of the complete nonlocal determinant.

This is an arbitrary-word proof. The relaxed finite grammar independently
enumerates all budgets0..4 and all16 grade combinations, using transitions
that always increase cost or a bounded grade. Its maximum equals budget plus
total grade; an ungraded zero-cost selfcycle destroys finiteness. Erasing a
beta root's last true label permits delta−1 and fails the stated admission
gate. A marginal kinetic term left outside Kref fails the exact reference
comparison. These are sensitive structural controls, not new model vertices.
Formal first-coefficient extraction is not the physical claim u²=0.

## Fixed-word heat, remainder and dimension-jet boundary

For each of these finitely many relevant local words, the existing weighted
symbol inverse and composition recursions use finite polynomial jets. On
the hard shell, expand the actual rational reference denominators by their
finite Taylor identity with integral remainder. Choose the shell beyond all
fixed external partial momentum sums and reference scales, as in the ordered
multiheat theorem. Polynomial derivative vertices change the finite number
of Taylor terms required; they do not change the remainder mechanism.
Complete subtraction through degree−4 leaves the inherited uniform bound
C r^-5(1+tr²)^N exp(−c'tr²), with fixed N,c'>0 for that finite coefficient.
The Gaussian polynomial is bounded, giving integrable radial r^-2. This is
neither convergence of the full Born series nor a global spectral theorem.

Retain all ordered heat factors and analytic prefactor jets. The critical
radial finite terms are −(gamma_E+log c)/2 at j0 and Gamma(j)/(2c^j) for
j>=1; power divergences multiplied by later heat jets can contribute finite
terms. The old clock has c=2n; V847's corrected selected profile aligns
t_new=2t_old and requires its finite clock shift. No absolute-clock formula
from the semantically corrected old PASS is reused. The reference determinant
is kept separately; it is canceled only in a difference when justified.

V848 supplies the SAME fixed metric constructor, but this result does not
evaluate the augmented alpha'_4 coefficients or establish the augmented
Q/projection/first-dimension-jet commutation lemma. Internal closed Lorentz
traces D and the sphere-normalization derivative must survive until the
first jet. In particular the old nonnegative-parameter/rank argument cannot
be copied without treating beta's dimension−1 and rho/epsilon ghost grades.
That augmented source/jet applicability and the common candidate/contact map
are the next checks, before any claim that the geometric W5 relation holds.

The old ordered finite-word analytic bounds are reused with these newly
checked types; they are not fresh evaluations of heat spectra, backgrounds,
other actual profiles or amplitudes. V850's scoped IR proof and all finite
IR/source/inverse defects remain separate. No physical constant-vacuum,
chiral/matter extension, QAP, measure, quantum equivalence or E5/A5 follows.

Two routes, the final replay and the proof reviews share the action,
conventions, Python/SymPy and AI authorship. Exact agreement tests internal
mathematical constructions; it cannot validate shared physical assumptions.
