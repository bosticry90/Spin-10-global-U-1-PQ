from pathlib import Path
import ast
O=Path(__file__).resolve().parent
q=(O/'compute.py').read_text(encoding='utf-8')
old="        assert base_positive and any(port[5]==1 for at,port in base_positive),'ACTUAL_INTRINSIC1_CONSTANT_BASE_NOT_IDENTIFIED'"
new="        synthetic_mixed_cost=4-dim(508)-dim(180);assert synthetic_mixed_cost==1"
assert q.count(old)==1;q=q.replace(old,new)
q=q.replace("incorrect_mass_only_improvement2_refuted_by_actual_intrinsic1=True","synthetic_admitted_Lambda_x_constant_defect=synthetic_mixed_cost,actual_unprobed_base_positive_cost_ports=len(base_positive)")
q=q.replace("role+'_complete_UV_grading.json.gz'","role+'_complete_UV_grading_v2.json.gz'")
q=q.replace("'preparation.json'","'preparation_v2.json'").replace("'result.json'","'result_v2.json'")
p=(O/'execute_v2.py').read_text(encoding='utf-8')
start=p.index('C.mkdir(exist_ok=False)');end=p.index("for n in['RECORD.md'",start)
p=p[:start]+"assert C.exists()and(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)\n"+p[end:]
needle="'execute_v2.py']:";assert p.count(needle)==1;p=p.replace(needle,"'execute_v2.py','CONTINUATION_COMPUTE_V2.md','build_compute_v2.py','compute_v2.py','execute_v3.py']:")
p=p.replace("with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())","if (O/(n+'.source.txt')).exists():assert(O/(n+'.source.txt')).read_bytes()==(O/n).read_bytes()\n    else:\n        with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())")
for old,new in [('input_encoding_bindings.json','input_encoding_bindings_v2.json'),('preparation.json','preparation_v2.json'),('capture.json','capture_v2.json'),("str(O/'compute.py')","str(O/'compute_v2.py')")]:
    assert old in p;p=p.replace(old,new)
for name,body in [('compute_v2.py',q),('execute_v3.py',p)]:
    ast.parse(body)
    with(O/name).open('x',encoding='utf-8',newline='\n')as f:f.write(body)
print('EXCLUSIVE_V2_BASE_CENSUS_CORRECTION_BUILT')
