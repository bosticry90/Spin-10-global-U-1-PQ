# Complete selected LambdaCC reference consistency

Claim TOE-LAMBDA-CC-REFERENCE-CONSISTENCY-G1-V1: the actual complete direct
first-g10/first-u_M aCC reference agrees with V814V2's separately constructed
consistency prediction, for all 45^3 ordered color polarizations and all
quadratic external momenta, in the inherited Euclidean A0 intrinsic0/1
domain. All inputs and limits remain those of V810/V813/V814/V819/V821.
No unqualified source interaction or quantum product is added here.

V821 derives the actual full-color tensor from the two physical source
response operators, with all33 internal M colors and all4 B components.
Its constructor workers deny the finite prediction. Its tensor, complete
literal color traces and validation were committed at405d5887990baee9f82844455d5200ea2bd3dff0
before this late comparison. V814V2 instead constructs a DEPENDENT
prediction from the other measured parent references and the qualified
finite-formal BV square/source-support/continuous-map identities. These
are different derivations with shared physical definitions, not independent
scientists or an experimental anchor.

For each prediction coordinate word, the primary conversion polarizes its
ghosts into C_p and C_r and its antighost into a(-p-r). Prefix exterior
multiplication includes the actual parity and every derivative i factor.
The second conversion enumerates complete class permutations, counts
literal parity inversions and expands Cartesian products of linear
momentum factors. Both complete tensors agree before any collinear or
invariant reduction. Every word assignment/contribution and both sparse
eight-variable tensors are stored, with an explicit 45^3 zero complement.
Equal-color ghost copies remain distinct throughout.

V2 prediction coefficients are grade0 in their suppressed convention;
only after that assertion is one actual g10 factor inserted polynomially.
No coupling value is divided out. All xi, eta_H, i and radical data stay.
The single log(9/8) is expanded as-3log2+2log3. For every external color,
the complete quadratic Fourier tensor equals its separate p^2,p.r,r^2
reconstruction. The direct invariant tensor is lifted to the full eight
external momentum components and compared at all36 quadratic monomials
times rational/log2/log3 times91,125 colors:9,841,500 slots. All match,
including the zero complement and every same-color row. The 91,125 power
anchors match as well. Numerical counts are representation sizes, not
independent physical amplitudes or a fraction of E5 completion.

V814V2 gives i R(A_pred)+K as a stored total divergence, using the actual
Q0a=iLambda and Q0Lambda=Q0C=0. Its K includes the complete selected
non-aCC parents; their common-reference limits and classical operations
are qualified in V813/V814. Both full Fourier constructions here annihilate
the stored divergences for every color and momentum. Since the actual
direct A equals A_pred as an integrated local reference functional, and
the V813 classical rename/jet maps are continuous in this distribution
domain, i R(A_direct)+K has that same zero integrated LambdaCC reference.
The V819 whole-reference theorem, not a Taylor-only or exceptional-momentum
shortcut, justifies using the directly measured coefficients in this step.

This establishes the complete selected reference CONSISTENCY relationship,
including rational, logarithmic and leading-power parts. It does not set
Delta=QGamma to zero. In particular Q Delta=0 is an integrability condition
on a breaking, whereas common restoration requires an admissible common
counterterm and marked insertion whose FULL variations remove it together
with lower-order breakings and their companions. No such primitive or
finite normalization is constructed or adopted in this comparison.

Wrong inverse sign and an artificial ghost half both yield preserved
nonzero full differences. Omitting every derivative i at jet degree2 has
the same effect as an overall sign and is not a separately independent
diagnostic. V814V1's rational/power mixed-grade semantic failure remains
NOTPASS; its unchanged log component never rehabilitates that version.

The direct full-color/momentum/UV-IR requirement imposed by V813/V814 is
now met for THIS selected aCC companion and its consistency comparison.
That requirement was neither waived nor replaced by prediction alone.
Inherited premises outside this scope remain premises. Full quantum action
principle, common measure and limit construction, source/composite products,
symmetry restoration, quantum equivalence, E5/A5 and physical Spin(10)
viability remain open. project_state.json remains unchanged at34/39, and
seven historical custody references remain unresolved NOTPASS.

The least expensive next discriminating action is a bounded admissible
common-normalization preimage test using these known coefficients and the
V804 coupled lower-order family. The complete images, source/marked
companions and any unmeasured spillover must be retained. A primitive in
only this projection cannot establish full restoration; a failed restricted
ansatz is not a general anomaly. Do not fit an unknown quantum contribution
or repeatedly enlarge the ansatz merely to rescue a preferred hypothesis.
