from pathlib import Path
from itertools import permutations,product
from fractions import Fraction as Fr
from hashlib import sha256
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('full_late_Fourier_tools',O.parent/'canonical_so10_aCC_finite_reference_comparison_g1_v1/compare.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);J=c.J;A=c.A;one=c.one;zero=c.zero;Z=c.Z;read=c.read;load=c.load;digest=c.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def enc(P):return[[*key,A.encode_coeff(v)]for key,v in sorted(P.items())]
def enc8(P):return[[list(key),A.encode_coeff(v)]for key,v in sorted(P.items())]
def clean(P):return{k:v for k,v in P.items()if v}
def add(out,key,val):out[key]=out.get(key,zero)+val
def compact(T):return{ex:clean(P)for ex,P in T.items()if clean(P)}
def all_fourier(P,third='a'):
 out={};journ=[];thirdbase=598 if third=='a'else 508;parities=[1,1,int(third=='a')]
 for at,(ww,coef)in enumerate(sorted(P.items())):
  assert len(ww)==3 and sum(553<=n<598 for n,js in ww)==2 and sum(thirdbase<=n<thirdbase+45 for n,js in ww)==1,'NON_TARGET_PREDICTION_WORD'
  states=[(0,(-1,-1,-1),{Z:c.raising_g(coef)},[])]
  for n,js in ww:
   bits=[0,1]if 553<=n<598 else[2];color=n-(553 if bits==[0,1]else thirdbase);nxt=[]
   for used,cs,Q,assignment in states:
    for bit in bits:
     if used&(1<<bit):continue
     sg=(-1)**sum(bool(used&(1<<b))*parities[b]*parities[bit]for b in range(bit+1,3));PP=c.scale(Q,J.constant(sg));cc=list(cs);cc[bit]=color
     for mu in js:PP=c.scale(c.pmul(PP,c.momentum(bit,mu)),J.I)
     nxt.append((used|(1<<bit),tuple(cc),PP,assignment+[bit]))
   states=nxt
  for used,cs,Q,assignment in states:
   assert used==7
   acc=out.setdefault(cs,{})
   for ex,v in Q.items():add(acc,ex,v)
   journ.append([at,list(cs),assignment,enc8(Q)])
 return compact(out),journ
def literal_all_fourier(P,third='a'):
 out={};count=0;thirdbase=598 if third=='a'else 508;parities=[1,1,int(third=='a')]
 for ww,coef in P.items():
  for perm in permutations(range(3)):
   if any((b<2)!=(553<=n<598)for(n,js),b in zip(ww,perm)):continue
   assert all(553<=n<598 or thirdbase<=n<thirdbase+45 for n,js in ww)
   cs=[-1]*3;linear=[];degrees=0
   for(n,js),b in zip(ww,perm):
    cs[b]=n-(553 if b<2 else thirdbase)
    for mu in js:linear.append([(mu,1)]if b==0 else[(4+mu,1)]if b==1 else[(mu,-1),(4+mu,-1)]);degrees+=1
   sg=(-1)**sum((perm[i]>perm[j])*parities[perm[i]]*parities[perm[j]]for i in range(3)for j in range(i+1,3));phase=one
   for k in range(degrees):phase=J.times(phase,J.I)
   val=J.times(c.raising_g(coef),phase)*sg;acc=out.setdefault(tuple(cs),{})
   for terms in product(*linear):
    ex=[0]*8;sg2=1
    for mu,s in terms:ex[mu]+=1;sg2*=s
    add(acc,tuple(ex),val*sg2)
   count+=1
 return compact(out),count
def lift_own(row):
 out={}
 for a,b,ln,packed in row[3]:
  coef=A.decode_coeff(packed);assert a+b==2 and all(k[0]==1 for k,v in coef.terms)
  for mu in range(4):ex=list(Z);ex[mu]+=a;ex[4+mu]+=b;add(out,(ln,tuple(ex)),coef)
 return clean(out)
def invariant_projection(P):
 keys=[]
 for a,b in[(2,0),(1,1),(0,2)]:ex=list(Z);ex[0]=a;ex[4]=b;keys.append(((a,b),tuple(ex)))
 inv={ab:P.get(ex,zero)for ab,ex in keys};rebuilt={}
 for(a,b),coef in inv.items():
  for mu in range(4):ex=list(Z);ex[mu]=a;ex[4+mu]=b;add(rebuilt,tuple(ex),coef)
 diff=c.difference(P,clean(rebuilt));return clean(inv),diff
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['known_consistency_images','consistency_tables.json','hard_response_v2.json']),'ASSEMBLED_REMAINDER_INPUT_DENIED'
 sys.addaudithook(guard)
 ownbase=O.parent/'canonical_so10_aCC_full_color_factorization_g1_v1';receipt=read(ownbase/'validation_receipt.json');assert receipt['evidence_validation']=='PASS_BOUNDED_DIRECT_FULL_COLOR_REFERENCE'and receipt['finite_integrability_prediction_not_read'];own=load(ownbase/'direct_full_color_reference.json.gz');assert len(own['all91125_ordered_rows'])==91125
 old=O.parent/'canonical_so10_aCC_reference_integrability_prediction_v1';v2=load(old/'prediction_tables_v2.json.gz');v1=load(old/'prediction_tables.json.gz');grades={row['kind']:sorted({k[0]for coef in J.decode(row['dependent_aCC_prediction']).values()for k,v in coef.terms})for row in v1['combinations']};assert grades=={'rational':[0,1],'log':[0],'power_1_over_t':[0,1]}
 pred={};power={};component_artifacts=[];covdiff=[];divdiff=[]
 for row in v2['combinations']:
  kind=row['kind'];P=J.decode(row['dependent_aCC_prediction']);fp,journ=all_fourier(P);peer,count=literal_all_fourier(P);assert count==len(journ);replaydiff=[]
  for ext in sorted(set(fp)|set(peer)):
   diff=c.difference(fp.get(ext,{}),peer.get(ext,{}))
   if diff:replaydiff.append([*ext,enc8(diff)])
  invariants={}
  for ext,poly in fp.items():
   if kind!='power_1_over_t':
    assert all(sum(ex)==2 for ex in poly);inv,diff=invariant_projection(poly)
    if diff:covdiff.append([kind,*ext,enc8(diff)])
    invariants[ext]=inv
    for ln,mult in([(0,1)]if kind=='rational'else[(2,-3),(3,2)]):
     acc=pred.setdefault(ext,{})
     for ex,v in poly.items():add(acc,(ln,ex),v*mult)
   else:
    assert all(ex==Z for ex in poly);power[ext]=poly.get(Z,zero)
  div=J.decode(row['sum_residual_divergence']);dv,dj=all_fourier(div,third='Lambda');dp,dc=literal_all_fourier(div,third='Lambda');assert len(dj)==dc
  if dv or dp:divdiff.append(dict(kind=kind,primary=[[*ex,enc8(pp)]for ex,pp in sorted(dv.items())],peer=[[*ex,enc8(pp)]for ex,pp in sorted(dp.items())]))
  art=save('prediction_Fourier_'+kind+'.json.gz',dict(kind=kind,all_coordinate_words=J.encode(P),all_word_assignments=journ,full_primary_sparse_tensor=[[*ex,enc8(pp)]for ex,pp in sorted(fp.items())],full_permutation_replay_sparse_tensor=[[*ex,enc8(pp)]for ex,pp in sorted(peer.items())],all_unlisted_45cubed_entries_exact_zero=True,complete_replay_differences=replaydiff,all_invariant_coefficients=[[*ex,enc(inv)]for ex,inv in sorted(invariants.items())],complete_divergence_primary=[[*ex,enc8(pp)]for ex,pp in sorted(dv.items())],complete_divergence_peer=[[*ex,enc8(pp)]for ex,pp in sorted(dp.items())],actual_g1_inserted_after_grade0_assertion=True));component_artifacts.append(dict(kind=kind,artifact=art,words=len(P),assignments=len(journ),all_Fourier_replays_equal=not replaydiff));assert not replaydiff,(kind,'FULL_PERMUTATION_REPLAY_MISMATCH');print('STAGE full_prediction_Fourier '+kind+' assignments='+str(len(journ)),flush=True)
 pred=compact(pred);quadratic=[tuple(int(i==j)+int(i==k)for i in range(8))for j in range(8)for k in range(j,8)];assert len(quadratic)==36;slots=[(ln,ex)for ln in[0,2,3]for ex in quadratic];rows=[];different=0;powerdiff=[];wrong_sign=[];wrong_half=[];same_nonzero=[]
 for row in own['all91125_ordered_rows']:
  aa,cp,cr=row[:3];ext=cp,cr,aa;actual=lift_own(row);prediction=pred.get(ext,{});assert set(actual)<=set(slots)and set(prediction)<=set(slots);diff={key:prediction.get(key,zero)-actual.get(key,zero)for key in slots};diff=clean(diff);different+=len(diff)
  actualpower=A.decode_coeff(row[5]);pd=power.get(ext,zero)-actualpower
  if pd:powerdiff.append([aa,cp,cr,A.encode_coeff(pd)])
  encpred=[[ln,list(ex),A.encode_coeff(v)]for(ln,ex),v in sorted(prediction.items())];encdiff=[[ln,list(ex),A.encode_coeff(v)]for(ln,ex),v in sorted(diff.items())];rows.append([aa,cp,cr,encpred,encdiff,len(slots)-len(diff)])
  if cp==cr and prediction:same_nonzero.append([aa,cp,cr,encpred])
  for key in set(prediction)|set(actual):
   v=prediction.get(key,zero);q=actual.get(key,zero)
   if -v-q:wrong_sign.append([aa,cp,cr,key[0],list(key[1]),A.encode_coeff(-v-q)])
   half=J.times(v,J.constant(Fr(1,2)))-q
   if half:wrong_half.append([aa,cp,cr,key[0],list(key[1]),A.encode_coeff(half)])
 assert len(rows)==91125 and len(slots)*len(rows)==9841500
 art=save('all91125_full_finite_comparisons.json.gz',dict(schema='FULL_COLOR_FULL8_QUADRATIC_FINITE_COMPARISON_V1',ordered_rows=rows,row_columns=['a','C_p','C_r','full_sparse_prediction_logprime_8powers_coefficient','full_prediction_minus_direct','equal_slots_of108'],all36_quadratic_exponents=[list(ex)for ex in quadratic],log_primes=[0,2,3],all_unlisted_108_coefficients_per_row_exact_zero=True,total_compared_slots=9841500,different_slots=different,all_power_anchor_differences=powerdiff,full_covariance_differences=covdiff,full_IBP_divergence_differences=divdiff,same_color_nonzero_prediction_rows=same_nonzero,own_reference_sha256=digest(ownbase/'direct_full_color_reference.json.gz'),proper_current_and_whole_limit_proofs_reused=['V810','V819']))
 control=save('full_comparison_controls.json.gz',dict(wrong_inverse_sign_complete_differences=wrong_sign,false_ghost_half_complete_differences=wrong_half,missing_all_derivative_i_equivalent_to_wrong_sign_at_total_jet_degree2=True,V1_actual_component_grades=grades,V1_mixed_grade_rational_power_NOTPASS_preserved=True,own_direct_full_color_checkpoint_before_late_prediction_read=True,shared_action_software_AI_author_not_external_independence=True));assert wrong_sign and wrong_half
 passed=not different and not powerdiff and not covdiff and not divdiff and not same_nonzero
 out=dict(schema='DIRECT_FULL_COLOR_ACC_LATE_FINITE_COMPARISON_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',comparison_disposition='ALL_MATCH'if passed else'MISMATCH_PRESERVED_NOTPASS',all91125_full_color_rows_match=passed,total_compared_finite_slots=9841500,different_finite_slots=different,all_power_anchors_match=not powerdiff,all_prediction_SO4_quadratic_reconstructions_match=not covdiff,all_IBP_divergence_Fourier_zero=not divdiff,all_same_color_rows_match_zero=not same_nonzero,all_full_permutation_Fourier_replays_equal=True,components=component_artifacts,artifact=art,controls_artifact=control,nonzero_direct_ordered_finite_rows=2610,finite_prediction_derived_separately_from_direct_operator=True,QDelta_consistency_not_Delta_restoration=True,common_restoration_E5_A5_not_claimed=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'comparison_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
