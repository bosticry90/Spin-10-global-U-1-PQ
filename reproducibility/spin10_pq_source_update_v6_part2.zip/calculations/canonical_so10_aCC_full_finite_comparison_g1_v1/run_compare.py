from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-full-finite-comparison-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_aCC_full_color_factorization_g1_v1':['direct_full_color_reference.json.gz','validation_receipt.json','PROOF.md','full_color_result.json','full_color.py','compile_full.py','discover_factor.py','universal_kernel.py'],'canonical_so10_aCC_reference_integrability_prediction_v1':['prediction_tables_v2.json.gz','prediction_tables.json.gz','validation_receipt.json','PROOF.md','CORRECTION_V2.md'],'canonical_so10_aCC_finite_reference_comparison_g1_v1':['compare.py','validation_receipt.json'],'canonical_so10_aCC_whole_reference_bridge_g1_v1':['validation_receipt.json','WHOLE_REFERENCE_PROOF.md'],'canonical_so10_selected_BV_square_g1_u1_v1':['validation_receipt.json','PROOF.md']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V821.md']+['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='405d5887990baee9f82844455d5200ea2bd3dff0'
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['RECORD.md','compare.py','run_compare.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD='405d5887990baee9f82844455d5200ea2bd3dff0',sha256={**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compare.py')]);dump(O/'comparison_capture.json',cap);dump(C/'comparison_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
