# Structural master continuation V2

V1 exited124 at its180s bound, after three complete case artifacts and STAGE
records: originalg0,originalg1,probe0g0. Its whole worker is INCOMPLETE NOTPASS.
No master_result or final factors file exists. The source orders actual
summation, homotopy, omission/perturbation controls and two explicit T2 maps
before saving each case. The precise phase at timeout is not captured; do not
claim any unrecorded result for probe0g1. All original bytes/capture remain.

This justified new bounded method completes ONLY the three remaining actual
classical master densities (probe0g1,probe1g0,probe1g1). Same immutable action,
domain, all643 ports, sources-after-operations, safe selector and no missing
physical input. Reuse V1's exact grouping and Euler homotopy functions. Save
each full density, all4 currents, direct-Euler remainder, port dispositions
and factors before proceeding to the next. A nonzero actual remainder is
recorded and withholds the bridge. No unknown coefficient or desired quantum
remainder enters. No adoption or authority change.

Avoid explicit expanded T2 for these remaining cases by a structural proof:
the even Taylor derivation T sends each physical jet phi_(i,alpha) to the
independent jet eta_(i,alpha), and each eta jet to zero; sources are fixed.
Ordinary D_mu shifts either jet by mu. Thus [D_mu,T]=0 on every generator.
Both operators are even derivations; their commutator is a derivation and
vanishes on all polynomials. Therefore T2/2 of an exact divergence is an
exact divergence. The field-count/dimension/mean projection also commutes
with D when the current uses total canonical dimension4 and its divergence
uses5 (the intrinsic coefficient degree is unchanged). A fixed polynomial
dimension slice is not itself invariant under D. Verify generator actions in
both actual prefix/LEFT implementations,
and Leibniz/commutator tests with odd and even words; a deliberately wrong
jet transport must fail. This derives the same required quadratic integrated
identity without executing a prohibitively large representation. It does
not retrospectively complete the earlier worker or waive its obligations.

V1 already retained sensitive omitted-branch controls (39672 unprobed g1
Euler positions and480 H g0) and single-term controls. V2 uses a literal
nonzero monomial perturbation for each nonempty actual case, with observed
sensitivity, instead of repeatedly expanding the whole omitted-branch
functional. This changes diagnostic engineering scope, not the required
actual-master identity or zero remainder. Direct LEFT Eulers and exact
four-current reconstruction still independently check each actual witness.

One180s after-import worker,8GiB sampled private/350MiB launch floor,
128MiB complete packet,10MiB artifact. New source/record/preparation freeze
before execution; no automatic retry. Shared action/ring/homotopy/AI author;
Taylor variants are not independent physical assumptions or scientists.
Physical/CPS support and final evidence validation are separate obligations.
