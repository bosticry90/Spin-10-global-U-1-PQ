# Literal free-width symbol correction V2

Support V1 FAILED exit1, at the first M-block GBB comparison: the harness
constructed an independent symbolic xi_M, while the actual frozen inverse
and its proof use xi. No physical mismatch or width choice was measured.
The exact failed source/preparation/capture remain NOTPASS. The preceding
physical witness checks ran, but the parent is not promoted to PASS.

New V2 changes only that symbolic harness name from xi_M to xi and its own
preparation/output filenames. It reruns the full physical/inverse test under
the same90s,8GiB/350MiB,128MiB/10MiB limits and SUPPORT_RECORD obligations.
No matrix entry, action, parameter, comparison or acceptance condition is
changed. The old record's xi_M was descriptive notation; actual bytes own
the literal symbol. Reuse CPS support only in its stated a,C,u target.
