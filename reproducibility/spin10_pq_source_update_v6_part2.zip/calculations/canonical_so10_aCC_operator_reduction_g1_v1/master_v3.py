from pathlib import Path
import importlib.util,os,threading,time,json
sp=importlib.util.spec_from_file_location('frozen_actual_master_v1',Path(__file__).resolve().with_name('master.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
R=a.R;O=a.O;J=a.J;w=a.w;one=a.one
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'master_v3_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 p=a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');assert p==a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/replay_inputs.json.gz')
 full={k:{n:J.decode(raw) for n,raw in rows} for k,rows in p['states'].items()}
 structural=dict(file='master_Taylor_commutation.json.gz',sha256=a.digest(O/'master_Taylor_commutation.json.gz'))
 structural_data=a.load(O/structural['file']);assert structural_data['all4_mu_prefix_LEFT_commutators_zero'] and structural_data['wrong_jet_transport_detected']
 original_Euler=J.euler
 def exact_set_Euler(poly,ids=None):return original_Euler(poly,None if ids is None else set(ids))
 parity_checks=[]
 for label in ['original_g0','original_g1','probe0_g0']:
  old=a.load(O/('master_'+label+'.json.gz'));poly=J.decode(old['source_free_eligible_density']);sample=dict(list(poly.items())[:1000]+list(poly.items())[-1000:]);ids=sorted({n for ww in sample for n,js in ww})
  assert original_Euler(sample,ids)==exact_set_Euler(sample,ids);parity_checks.append(dict(case=label,terms=len(sample),ids=len(ids),exact_list_set_Euler_equal=True))
 J.euler=exact_set_Euler
 results=[]
 cases=[('probe1_g1',[('Fu1_1','E0'),('Fu0_1','E1'),('F1','Eu0_1'),('F0','Eu1_1')])]
 for label,branches in cases:
  factors=[];cache={};total={};ports=[]
  def groups(name,n):
   key=name,n
   if key in cache:return cache[key]
   raw=full[name][n];P={ww:c for ww,c in raw.items() if all(i<643 for i,js in ww)};G={}
   for ww,c in P.items():G.setdefault(a.profile(ww),{})[ww]=c
   factors.append(dict(state=name,field=n,original=J.encode(raw),source_free=J.encode(P),groups=[dict(profile=list(k),words=J.encode(v)) for k,v in sorted(G.items())]));cache[key]=G,P;return G,P
  for left,right in branches:
   for n in range(643):
    L,P=groups(left,n);M,Q=groups(right,n);out={};journal=[]
    for lp,l in sorted(L.items()):
     for rp,r in sorted(M.items()):
      summed=tuple(x+y for x,y in zip(lp,rp));yes=a.allowed(summed)
      if yes:J.add(out,J.mul(l,r))
      journal.append(dict(left=list(lp),right=list(rp),summed=list(summed),included=yes))
    out=J.clean(out)
    if len(P)*len(Q)<=1000:assert out==a.selected(J.mul(P,Q))
    J.add(total,out);ports.append(dict(left=left,right=right,field=n,group_pair_dispositions=journal,eligible_product=J.encode(out),ungrouped_selector_checked=len(P)*len(Q)<=1000,full_pair_count=len(P)*len(Q)))
  total=J.clean(total);density=a.save('master_v3_density.json.gz',dict(case=label,source_free_eligible_density=J.encode(total)));sources=[]
  for at,branch in enumerate(branches):
   f=[r for r in factors if r['state'] in branch];units=[r for r in ports if (r['left'],r['right'])==branch];sources.append(a.save('master_v3_branch_'+str(at)+'.json.gz',dict(branch=list(branch),factors=f,all643_port_dispositions=units)))
  print('DENSITY '+label+' '+str(len(total)),flush=True);curr,norm=a.homotopy(total);print('HOMOTOPY '+label+' '+str(len(norm)),flush=True)
  sensitivity=0
  if total:
   ww,c=next(iter(sorted(total.items())));bc,bn=a.homotopy({ww:c});sensitivity=len(bn)
  art=a.save('master_v3_'+label+'.json.gz',dict(case=label,branches=branches,density=density,branch_evidence=sources,Euler_list_set_equivalence=parity_checks,currents=[J.encode(p) for p in curr],Euler_remainder=J.encode(norm),literal_term_perturbation_remainder_terms=sensitivity,quadratic_identity_by_structural_commutation=not norm,commutation_evidence=structural))
  row=dict(case=label,classical_terms=len(total),currents=[len(p) for p in curr],Euler_remainder_terms=len(norm),perturbation_remainder_terms=sensitivity,artifact=art);results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 result=dict(schema='ACTUAL_ACC_STRUCTURAL_MASTER_CONTINUATION_V3',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=results,commutation=structural,all_remaining_GF_remainders_zero=all(not r['Euler_remainder_terms'] for r in results),old_V1_worker='FAILED_TIMEOUT124_INCOMPLETE_NOTPASS',elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'master_v3_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
