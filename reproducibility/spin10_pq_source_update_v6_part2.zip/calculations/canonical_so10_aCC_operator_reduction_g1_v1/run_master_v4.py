from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-operator-reduction-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert (O/'support_v3_capture.json').exists(),'PREVIOUS_WORKER_MUST_BE_TERMINAL'
for n,h in json.loads((O/'master_v3_preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
cap=json.loads((O/'master_v3_capture.json').read_bytes());assert cap['exit_code']==124 and not cap['calculation_completed'] and cap['post_run_observations_qualified']
for n in ['master_v3_density.json.gz']+['master_v3_branch_'+str(i)+'.json.gz' for i in range(4)]:assert (O/n).is_file()
for n in ['MASTER_PROOF_FROM_CAPTURE_V4.md','master_v4.py','run_master_v4.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'master_v4_preparation.json',dict(sha256={**json.loads((O/'master_v3_preparation.json').read_bytes())['sha256'],**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'master_v4.py')]);dump(O/'master_v4_capture.json',cap);dump(C/'master_v4_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
