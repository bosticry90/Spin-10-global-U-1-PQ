# Direct first-order four-field master witness V5

Proof-only V4 exhausted180s/exit124 after completing N2 and N3 sectors:
2368 and74496 terms, zero Euler remainders, explicit currents and sensitive
controls. N4=259104 terms has no completed proof. Whole V4 remains INCOMPLETE
NOTPASS. Authenticate its saved complete sectors, never promote the parent.

New question: is the entire remaining N4 density first order in ordinary
jets, and is it exactly the divergence of its Euler scaling current?
Use only the captured immutable density, without regenerating its products.
First inventory total derivative counts for EVERY N4 word. Require exactly
one derivative jet per word. If this premise fails, record the inventory
and withhold this shortcut; do not drop zero- or higher-derivative words.

For a homogeneous N-field first-order density, the general scaling homotopy
current is simply J_mu=(1/N) sum_i phi_i LEFTpartial_(Dmu phi_i) B. With only
one differentiated token per word it can be computed by replacing that token
by its undifferentiated field in its literal position, multiplying by1/N,
and canonicalizing with the full Grassmann sign. The LEFT extraction and
reinsertion signs cancel exactly in that literal-position representation.
Use N=4 derived from the words, not a fitted factor.

Compute all4 currents and verify B=sum_mu D_mu J_mu EXACTLY. This explicit
equality itself proves an integrated zero and implies every variational
Euler derivative vanishes by the jet identity EL_i(D_mu J_mu)=0. It avoids
the unnecessary full massive Euler expansion of earlier unsuccessful
representations; it does not assume or weaken the zero requirement. Replay
the original general homotopy and direct LEFT Euler on complete concrete
field-multiset sectors (D preserves each multiset), comparing actual
currents to the direct current. A half-current and a one-term perturbation
are sensitive controls, and all differences/counts are preserved.

Same upper aCC, Euclidean A0,g1/firstu/intrinsic01 and sources-after-operations
domain. Reuse the completed Taylor-commutation theorem to transfer the exact
divergence to the two-quantum-field master kernel, with current dimension4.
Final independent full F/E product reconstruction is still required.
No unknown quantum amplitude, physical parameter or desired remainder enters.

One120s after-import worker,8GiB sampled private/350MiB launch floor,
128MiB complete packet/10MiB artifact. Sequential, frozen source/input hashes,
preserved failures, no automatic retry. This specializes to observed fixed
field degree rather than enlarging a failed generic worker. Shared action,
software and AI authorship; no new scientific acceptance/state/E5 promotion.
