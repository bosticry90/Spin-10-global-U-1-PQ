# aCC source-free actual master-density continuation V1

The qualified Ward test reduces the raw inventory but does not establish aCC's
proper bridge. V808's broader expanded-kernel worker exhausted its bound; its
unfinished M g1-u source-free sector stays incomplete. This is a NEW bounded
method, not a resume, reclassification or increase of that historical run.

Question: does the actual source-free classical gauge-fixing master density
B=sum_i F_i E_i have an explicit divergence witness in every field-content
sector that can feed the upper a<=1,C<=2, two-quantum-field target? Original
Euclidean A0, g0/g1, firstu H/M, intrinsic01; all643 source/Euler operations
already performed in the authenticated full V802 packets. BV sources may be
set zero only now. Keep all physical field species until the safe bound:
other_fields + max(a-1,0) + max(C-2,0) <=2, totalfields>=2.
Ordinary derivatives and even Taylor preserve field identities/counts and
dimensions, so this selection commutes with both; it does not guess which
internal fields disappear. Fixed sources cannot be removed by field Taylor.

For all6 classical g/u convolutions, group full source-free factors by exact
field counts/dimension; multiply every eligible pair, with full original
factors, group memberships and per-port disposition preserved. Compare the
result against ordinary ungrouped multiplication at each nonempty port before
filtering whenever its Cartesian product has <=1000 pairs; this is an exact
selector check, not an independent action. No missing physical E1_x is read.

Sum eligible classical products BEFORE T2. Construct the Euler scaling
homotopy separately at each positive field degree N. Each token's LEFT jet
derivative is weighted 1/N; integrate its derivatives by the explicit repeated
Leibniz formula. Save all4 currents and the Euler remainder. Verify exact
B=div J+remainder, and verify the remainder by the library's direct LEFT
variational Euler operator. A zero remainder is a structural integrated
classical-master result. It is NOT stipulated. A nonzero remainder withholds
this shortcut. An omitted g1 branch and a literal single-term perturbation
are controls; report actual sensitivity/blindness.

When the remainder is zero, compute T2 B/2 and T2 J/2 by prefix and LEFT
even Taylor, project the actual aCC upper means/quantum/intrinsic target,
and verify the selected quadratic density equals divergence of its4 currents.
T2 and ordinary D commute on this jet algebra, so a pre-Taylor structural
witness avoids expanding separately large Qfield/Dsource/cross operands.
This qualifies only the GF master prerequisite. Physical-action/potential,
CPS/hatted and measure/Jacobian premises still need their actual target
restriction before any proper amplitude is inferred. No global QAP or
restoration is asserted. No desired quantum remainder is an input.

One180s after-import worker,8GiB sampled private/350MiB launch floor,
128MiB complete packet including earlier Ward evidence,10MiB per artifact.
Freeze new source, this record and dependencies before execution; preserve
all failures and complete captures, no automatic retry. Sharing action,
ring, Taylor helpers and AI author limits independence. Current AGENTS and
V809 authority ceiling apply. Scientific authority unchanged; full goal active.
