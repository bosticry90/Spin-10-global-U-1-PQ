from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-operator-reduction-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'preparation.json').exists();C.mkdir(parents=True,exist_ok=True)
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V809.md','calculations/canonical_so10_ghost_source_companion_catalog_g1_v1/native_aCC_catalog.json.gz','calculations/canonical_so10_ghost_source_companion_catalog_g1_v1/replay_aCC_catalog.json.gz','calculations/canonical_so10_ghost_source_companion_catalog_g1_v1/native_result.json','calculations/canonical_so10_ghost_source_companion_catalog_g1_v1/replay_result.json','calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz','calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/replay_inputs.json.gz','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/roots.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py','calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/PROOF.md']
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['RECORD.md','ward.py','run_ward.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'ward.py')]);dump(O/'ward_capture.json',cap);dump(C/'ward_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
