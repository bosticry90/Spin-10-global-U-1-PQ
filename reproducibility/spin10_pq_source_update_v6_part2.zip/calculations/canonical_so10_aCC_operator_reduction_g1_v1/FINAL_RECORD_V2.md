# Final aCC evidence validation V2

The old final_review.py is a never-executed draft frozen into a preceding
preparation. Preserve it. New final_review_v2.py owns this final validation;
it accounts for masterV4's timeout and masterV5's first-order proof.

One420s after-import worker,8GiB sampled private/350MiB launch floor,
128MiB complete packet/10MiB artifacts. This includes independent ordinary
ungrouped reconstruction of9645 port products across6 actual cases, the
335968-term captured density, saved divergence witnesses, Ward contractions,
all longitudinal source/ordinary-leg checks, actual Taylor generator rules
and six physical witness restrictions. Do not repeat the expensive generic
Euler expansions; the exact saved divergence witnesses prove their result.
The first-order sector's Euler zero follows from exact P=divJ, with actual
general-homotopy/Euler concrete-sector and monomial controls preserved.

Authenticate all old/new preparations, source copies, inputs, complete worker
captures and per-artifact hashes. All6 failed workers stay NOTPASS, including
their original resource limits. Individually completed case/sector results
may be verified without reclassifying a parent. Report sampled memory as
sampled, not a true or nested peak. No unknown M aCC amplitude is evaluated
or fitted here, no physical input or authority changed.

E4 exactly once, no --fresh, existing D context. Preserve full stdout/stderr;
expected step exits0,0,0,0,0,2, seven unresolved historical custody NOTPASS.
Check original Git tree, old tracked bytes, state SHA, packet bounds. Preserve
all checks omitted and shared assumptions in PROOF/RESULT/handoff. The receipt
qualifies bounded evidence only; no E5/A5, restoration or full goal completion.
