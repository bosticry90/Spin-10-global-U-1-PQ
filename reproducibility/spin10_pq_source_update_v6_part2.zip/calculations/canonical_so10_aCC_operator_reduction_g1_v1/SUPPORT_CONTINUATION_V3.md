# Memoized exact inverse comparison V3

Corrected support V2 exhausted90s/exit124 with no final artifact; it remains
INCOMPLETE NOTPASS. V1 literal-symbol failure also remains FAILED NOTPASS.
The repeated45-color inverse checks call the same symbolic simplifications
for identical expressions at each color within H or M. A new V3 memoizes
the exact SymPy simplify function by expression. Every original all-color
comparison still executes, but an identical expression reuses that function's
exact result. No representative-only sampling, matrix change, simplification
replacement or physical premise is introduced.

Same SUPPORT_RECORD and V2 xi correction; same90s/8GiB/350MiB,128MiB/10MiB
bound. Freeze new source/preparation after the master V3 worker is terminal,
run sequentially. New own output filenames; preserve all old sources,
preparations and captures. A timeout remains incomplete; no automatic retry.
Exact actual matrices and all six physical witnesses must still pass.
