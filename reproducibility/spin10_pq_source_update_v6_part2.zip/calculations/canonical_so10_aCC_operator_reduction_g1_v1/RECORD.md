# Actual aCC operator reduction V1

Question: can actual Lorentz support reduce V808's four unprobed and 112
M-probe candidate returning paths before any unknown amplitude is evaluated?
Use V809 checkpoint 1c6ee082 on main, current AGENTS, D: only. State113,
34/39 and all protected scientific boundaries remain unchanged. No adoption,
normalization fit, E5/A5 promotion, remote action or separate authority ledger.

Domain is the existing original Euclidean A0, first g10, at most first u,
intrinsic degree 0/1, upper means a<=1,C<=2, two quantum endpoints. Source
derivatives/Euler operations already precede the V808 projection. Authenticate
native/replay full selected catalogs and classical V802 F/E packets. Reuse
their qualified derivations; matching packets is not new independent physics.

Least expensive test: contract the COMPLETE selected F1 Preference BB root
on its right B index with its right momentum l. Retain right color and every
other word/momentum/coefficient. Also test left k, wrong right k, and a
diagonal-only root. Preserve exact nonzero contractions and all input indices.
Nonminimal F1 maps are not zero globally. Do not transfer a B-output-only
transversality statement to the complete BB root. Reference-defect BB roots
are checked separately. A failed transversality hypothesis is a valid result.

Separately test actual sourceful Eu0_B + D Fu0_a=0 for both probes/all180
B components, before mean restriction. Verify ordinary g0 GF has no B Euler
and probe ordinary B Euler equals T1(Eu0_B), with aCC means and one quantum
leg, by both prefix and LEFT Taylor. This is a leg-longitudinality test,
not an assumption that a literal density is uniquely fixed by integration by
parts. Verify the exact reference free inverse transverse/longitudinal
identities for arbitrary symbolic Omega, retaining its scope and profiles.

Only if the COMPLETE root right contraction is zero and adjacent actual
ordinary endpoints are B or Lambda with these longitudinal properties may
that entire typed returning path be removed. Otherwise retain that path.
No raw-to-proper transfer is supplied by this test: aCC still needs its own
actual-master prerequisite. Neither an empty raw family nor Ward evidence
alone establishes a proper quantum coefficient or common restoration.

One worker,120 seconds after imports,8GiB sampled private memory,350MiB
launch commit floor,64MiB complete packet,10MiB individual artifact. Freeze
sources/input hashes before launch. Preserve all failures/unfinished captures;
no automatic retry. Exact ring arithmetic, actual operator contraction and
symbolic inverse identities share action, software and AI authorship. Controls
must report sensitivity or blindness as observed. Possible outcomes: qualified
scoped reduction, failed shortcut, or bounded incomplete. No desired remainder
or unknown aCC amplitude is an input. Full research goal remains active.
