from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('aCC_ward_helpers',O/'ward.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
J=z.J;w=z.w;m=z.m;vr=z.vr;load=z.load;read=z.read;digest=z.digest;dump=z.dump;one=J.constant(1)
def save(name,data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'INDIVIDUAL_ARTIFACT_LIMIT'
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2,'COMPLETE_PACKET_LIMIT'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def profile(ww):
 assert all(n<643 for n,js in ww)
 na=sum(598<=n<643 for n,js in ww);nc=sum(553<=n<598 for n,js in ww)
 return na,nc,len(ww)-na-nc,len(ww),sum(J.dimension(n)+len(js) for n,js in ww)
def allowed(p):
 a,c,o,n,d=p
 return n>=2 and o+max(a-1,0)+max(c-2,0)<=2 and 5-d in [0,1]
def selected(P):return {ww:c for ww,c in P.items() if allowed(profile(ww))}
def project(P):
 out={}
 for ww,c in P.items():
  qq=na=nc=0;dim=0;bad=False
  for n,js in ww:
   if 1319<=n<1962:qq+=1;dim+=J.dimension(n-1319)+len(js)
   else:
    dim+=J.dimension(n)+len(js)
    if 598<=n<643:na+=1
    elif 553<=n<598:nc+=1
    else:bad=True;break
  if not bad and qq==2 and na<=1 and nc<=2 and 5-dim in [0,1]:out[ww]=c
 return out
def homotopy(P):
 currents=[{} for _ in range(4)];normal={};degrees=defaultdict(dict)
 for ww,c in P.items():degrees[len(ww)][ww]=c
 for N,p in degrees.items():
  assert N>0;factor=J.constant(F(1,N))
  for ww,c in p.items():
   for at,(n,jets) in enumerate(ww):
    sign=(-1)**(J.parity(n)*sum(J.parity(i) for i,js in ww[:at]));rest={ww[:at]+ww[at+1:]:J.times(c*sign,factor)}
    for r,mu in enumerate(jets):
     J.add(currents[mu],J.mul({((n,tuple(jets[r+1:])),):one},w.scale(rest,J.constant((-1)**r))));rest=J.D(rest,mu)
    J.add(normal,J.mul({((n,()),):one},w.scale(rest,J.constant((-1)**len(jets)))))
 normal=J.clean(normal);currents=[J.clean(p) for p in currents];div={}
 for mu,p in enumerate(currents):J.add(div,J.D(p,mu))
 assert w.plus(J.clean(div),normal)==P,'HOMOTOPY_RECONSTRUCTION'
 direct={}
 for N,p in degrees.items():
  for n,e in J.euler(p,sorted({n for ww in p for n,js in ww})).items():J.add(direct,w.scale(J.mul({((n,()),):one},e),J.constant(F(1,N))))
 assert J.clean(direct)==normal,'DIRECT_LEFT_EULER_REMAINDER'
 return currents,normal
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'master_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(base/'native_inputs.json.gz');assert packet==load(base/'replay_inputs.json.gz')
 full={k:{n:J.decode(raw) for n,raw in rows} for k,rows in packet['states'].items()};cache={};factors=[]
 def groups(label,n):
  key=label,n
  if key in cache:return cache[key]
  P=full[label][n];src0={ww:c for ww,c in P.items() if all(i<643 for i,js in ww)};grp=defaultdict(dict)
  for ww,c in src0.items():grp[profile(ww)][ww]=c
  factors.append(dict(state=label,field=n,original=J.encode(P),source_free=J.encode(src0),groups=[dict(profile=list(k),words=J.encode(p)) for k,p in sorted(grp.items())]));cache[key]=grp,src0;return grp,src0
 cases=[('original_g0',[('F0','E0')]),('original_g1',[('F1','E0'),('F0','E1')])]
 for pr in [0,1]:
  cases += [('probe'+str(pr)+'_g0',[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))]),('probe'+str(pr)+'_g1',[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))])]
 results=[]
 for label,branches in cases:
  total={};omit={};ports=[]
  for b,(left,right) in enumerate(branches):
   for n in range(643):
    L,P=groups(left,n);M,Q=groups(right,n);out={};journal=[]
    for lp,l in sorted(L.items()):
     for rp,r in sorted(M.items()):
      summed=tuple(a+b for a,b in zip(lp,rp));yes=allowed(summed)
      if yes:J.add(out,J.mul(l,r))
      journal.append(dict(left=list(lp),right=list(rp),summed=list(summed),included=yes))
    out=J.clean(out);direct=False
    if len(P)*len(Q)<=1000:assert out==selected(J.mul(P,Q));direct=True
    J.add(total,out)
    if b!=len(branches)-1:J.add(omit,out)
    ports.append(dict(left=left,right=right,field=n,group_pair_dispositions=journal,eligible_product=J.encode(out),ungrouped_selector_checked=direct,full_pair_count=len(P)*len(Q)))
  total=J.clean(total);omit=J.clean(omit);curr,norm=homotopy(total);oc,on=homotopy(omit)
  if total:
   ww,c=next(iter(sorted(total.items())));bad=w.plus(total,{ww:c});bc,bn=homotopy(bad);sensitive=len(bn)
  else:sensitive=0
  quadratic={};tcur=[];taylor_equal=True
  if not norm:
   tn=w.scale(m.v.tangent(m.v.tangent(total)),J.constant(F(1,2)));tr=w.scale(vr.tangent(vr.tangent(total)),J.constant(F(1,2)));assert tn==tr;quadratic=project(tn)
   div={}
   for mu,p in enumerate(curr):
    a=w.scale(m.v.tangent(m.v.tangent(p)),J.constant(F(1,2)));b=w.scale(vr.tangent(vr.tangent(p)),J.constant(F(1,2)));assert a==b;a=project(a);tcur.append(a);J.add(div,J.D(a,mu))
   assert J.clean(div)==quadratic,'ACTUAL_QUADRATIC_MASTER_WITNESS'
  art=save('master_'+label+'.json.gz',dict(case=label,branches=branches,all643_port_dispositions=ports,source_free_eligible_density=J.encode(total),currents=[J.encode(p) for p in curr],Euler_remainder=J.encode(norm),selected_T2_half=J.encode(quadratic),T2_currents=[J.encode(p) for p in tcur],omit_last_branch_density=J.encode(omit),omit_last_branch_remainder=J.encode(on),literal_term_perturbation_remainder_terms=sensitive))
  row=dict(case=label,classical_terms=len(total),currents=[len(p) for p in curr],Euler_remainder_terms=len(norm),quadratic_terms=len(quadratic),omit_branch_remainder_terms=len(on),perturbation_remainder_terms=sensitive,artifact=art);results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 art=save('master_factors.json.gz',dict(all_source_derivatives_before_source_free_restriction=True,complete_grouped_F_E=factors))
 result=dict(schema='ACTUAL_ACC_PRE_TAYLOR_MASTER_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=results,factors=art,all_GF_Euler_remainders_zero=all(not r['Euler_remainder_terms'] for r in results),physical_and_CPS_prerequisites_not_inferred=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'master_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
