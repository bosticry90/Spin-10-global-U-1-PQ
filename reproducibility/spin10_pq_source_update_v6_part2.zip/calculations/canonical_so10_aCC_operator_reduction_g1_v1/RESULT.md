# aCC reduction: unprobed zero and a scoped M proper bridge

The actual right-Lorentz Ward contraction removes all4 unprobed aCC raw
candidates and40 of112 M candidates. Wrong-momentum and diagonal-only
controls leave40176 and20088 positions. The remaining72 M candidates
are not presumed nonzero or assigned amplitudes.

The new actual source-free classical-master proof covers all6 original/H/M
g0/g1 cases in the selected Euclidean A0/firstu/intrinsic01 domain. The
largest density has335968 terms; all sectors have exact divergence witnesses.
Its259104-term first-order sector reconstructs from four16194-term currents.
Actual physical witness restrictions, all45 free inverse colors and CPS
antighost support supply the additional finite-formal proper premises.

Subject to the owning final validation receipt, this qualifies unprobed
aCC=0 and H aCC=0, and the M relation QGamma1=-CQ=CR in this prescription.
It does not supply the remaining M coefficients or common restoration.
Final review independently rebuilds all9645 full F/E port products and
checks every saved current witness; hashes alone are not calculation proofs.

Four master timeouts, one inverse harness-symbol failure and one inverse
timeout remain NOTPASS with exact sources/captures. Structural specialization
completed the missing proof without erasing failed attempts or expanding
the scope of old receipts. All work stays on D:, main; no push/activation/
normalization adoption or project_state change. State113/34of39, E5/A5 open.
Shared action/software/AI authorship limit independence; no empirical claim.

Next: combine the actual nonminimal Gaussian/resolvent blocks for the72 M
paths and derive their signs/profiles independently of the desired LambdaCC
remainder. The known partial rational/logarithmic sum is unchanged. The
broader Spin(10) x U(1)PQ investigation remains active and incomplete.
