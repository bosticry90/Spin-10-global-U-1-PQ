# Proof from preserved M g1 density V4

V3 exhausted240s/exit124 after saving the exact335968-term density and all
four full branch/product/factor artifacts. No homotopy conclusion was saved;
the whole parent stays INCOMPLETE NOTPASS. Generating/serializing those
operands consumed most of that worker. Rebuilding them again is unnecessary.

This new bounded proof authenticates those completed immutable artifacts,
then performs only the still-missing homotopy/direct-Euler work. Partition
the density by positive field degree N. Ordinary derivatives preserve N,
so distinct N sectors cannot cancel one another; every sector must have
zero Euler remainder and an exact four-current witness. Save each completed
sector before moving on. Actual list-to-set Euler membership optimization
is identical to V3; no operation or summand is dropped. Retain a sensitive
single-monomial control at each nonempty N. T2 commutation is the completed
V2 structural proof with the correct current canonical dimension4.

One180s after-import proof-only worker,8GiB sampled private/350MiB launch
floor,128MiB complete packet/10MiB artifact, sequential after support V3.
Failure remains incomplete; no automatic retry. Final review must independently
reconstruct all four captured classical branch products from authenticated
full F/E inputs, as well as the saved currents, before qualifying this GF
bridge. This proof worker does not authenticate its own input calculation
merely by hashing it. Nonzero remainder withholds the affected proper bridge;
do not fit a coefficient, presume cancellation or call it a quantum anomaly.
No physical input, acceptance obligation, state or authority is changed.
