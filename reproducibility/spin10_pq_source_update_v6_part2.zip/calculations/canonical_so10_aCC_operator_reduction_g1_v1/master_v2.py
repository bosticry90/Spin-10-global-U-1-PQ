from pathlib import Path
import importlib.util,os,threading,time,json
sp=importlib.util.spec_from_file_location('frozen_actual_master_v1',Path(__file__).resolve().with_name('master.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
R=a.R;O=a.O;J=a.J;w=a.w;one=a.one
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'master_v2_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 # The generator rule, including arbitrary derivative jets, is the proof's
 # premise. Exhaust all field generators and the jet types present in inputs.
 p=a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');assert p==a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/replay_inputs.json.gz')
 full={k:{n:J.decode(raw) for n,raw in rows} for k,rows in p['states'].items()};jets={(n,js) for rows in full.values() for poly in rows.values() for ww in poly for n,js in ww if n<643};jets|={(n,()) for n in range(643)}
 commutators=[]
 for n,js in sorted(jets):
  atom={((n,js),):one};expected={((1319+n,js),):one}
  assert a.m.v.tangent(atom)==a.vr.tangent(atom)==expected
  for mu in range(4):
   lhs=a.m.v.tangent(J.D(atom,mu));rhs=J.D(expected,mu);assert lhs==rhs==a.vr.tangent(J.D(atom,mu))
  assert not a.m.v.tangent(expected) and not a.vr.tangent(expected)
 tests=[]
 for ww in [((0,(1,)),(553,()),(598,(2,))),((553,(0,)),(554,(1,)),(598,())),((508,()),(598,(0,)))]:
  atom={ww:one};atom=J.clean(J.mul(atom,{():one}));native=a.m.v.tangent(atom);assert native==a.vr.tangent(atom)
  for mu in range(4):assert a.m.v.tangent(J.D(atom,mu))==J.D(native,mu)
  tests.append(J.encode(atom))
 wrong_atom={((0,(1,)),):one};wrong={((1319,()),):one};assert wrong!=a.m.v.tangent(wrong_atom)
 structural=a.save('master_Taylor_commutation.json.gz',dict(all_input_field_jet_generators=[[n,list(js)] for n,js in sorted(jets)],all4_mu_prefix_LEFT_commutators_zero=True,quantum_generators_T_zero=True,odd_even_Leibniz_examples=tests,wrong_jet_transport_detected=True,proof='Even derivations commute on all generators, hence on the polynomial jet algebra; sources fixed; D preserves field counts and dimension plus its own derivative degree.'))
 results=[]
 cases=[('probe0_g1',[('Fu1_0','E0'),('Fu0_0','E1'),('F1','Eu0_0'),('F0','Eu1_0')]),('probe1_g0',[('Fu0_1','E0'),('F0','Eu0_1')]),('probe1_g1',[('Fu1_1','E0'),('Fu0_1','E1'),('F1','Eu0_1'),('F0','Eu1_1')])]
 for label,branches in cases:
  factors=[];cache={};total={};ports=[]
  def groups(name,n):
   key=name,n
   if key in cache:return cache[key]
   raw=full[name][n];P={ww:c for ww,c in raw.items() if all(i<643 for i,js in ww)};G={}
   for ww,c in P.items():G.setdefault(a.profile(ww),{})[ww]=c
   factors.append(dict(state=name,field=n,original=J.encode(raw),source_free=J.encode(P),groups=[dict(profile=list(k),words=J.encode(v)) for k,v in sorted(G.items())]));cache[key]=G,P;return G,P
  for left,right in branches:
   for n in range(643):
    L,P=groups(left,n);M,Q=groups(right,n);out={};journal=[]
    for lp,l in sorted(L.items()):
     for rp,r in sorted(M.items()):
      summed=tuple(x+y for x,y in zip(lp,rp));yes=a.allowed(summed)
      if yes:J.add(out,J.mul(l,r))
      journal.append(dict(left=list(lp),right=list(rp),summed=list(summed),included=yes))
    out=J.clean(out)
    if len(P)*len(Q)<=1000:assert out==a.selected(J.mul(P,Q))
    J.add(total,out);ports.append(dict(left=left,right=right,field=n,group_pair_dispositions=journal,eligible_product=J.encode(out),ungrouped_selector_checked=len(P)*len(Q)<=1000,full_pair_count=len(P)*len(Q)))
  total=J.clean(total);print('DENSITY '+label+' '+str(len(total)),flush=True);curr,norm=a.homotopy(total);print('HOMOTOPY '+label+' '+str(len(norm)),flush=True)
  sensitivity=0
  if total:
   ww,c=next(iter(sorted(total.items())));bc,bn=a.homotopy({ww:c});sensitivity=len(bn)
  art=a.save('master_v2_'+label+'.json.gz',dict(case=label,branches=branches,all643_port_dispositions=ports,full_factors=factors,source_free_eligible_density=J.encode(total),currents=[J.encode(p) for p in curr],Euler_remainder=J.encode(norm),literal_term_perturbation_remainder_terms=sensitivity,quadratic_identity_by_structural_commutation=not norm,commutation_evidence=structural))
  row=dict(case=label,classical_terms=len(total),currents=[len(p) for p in curr],Euler_remainder_terms=len(norm),perturbation_remainder_terms=sensitivity,artifact=art);results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 result=dict(schema='ACTUAL_ACC_STRUCTURAL_MASTER_CONTINUATION_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=results,commutation=structural,all_remaining_GF_remainders_zero=all(not r['Euler_remainder_terms'] for r in results),old_V1_worker='FAILED_TIMEOUT124_INCOMPLETE_NOTPASS',elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'master_v2_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
