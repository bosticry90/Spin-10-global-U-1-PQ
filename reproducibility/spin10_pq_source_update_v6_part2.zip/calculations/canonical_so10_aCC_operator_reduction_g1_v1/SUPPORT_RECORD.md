# Actual physical/inverse support for the aCC proper bridge

New bounded support test, original Euclidean A0, g0/g1, firstu H/M,
intrinsic01, same action and finite formal prescription. Source derivatives
precede restriction. Full V802 F/E packets, six completed physical source
master witnesses and actual V791 free inverse matrices are frozen inputs.
No new physical parameter or normalization is selected.

Physical kernel coverage: actual F0/F1 at all508 physical ports must be
source-free, have no antighost and at most one ghost. Probe physical flows
all vanish, E0 is linear, and retained E1_B gauge/scalar is quadratic in
physical fields only. Actual F0_x=0 bypasses uncomputed physical E1_x;
never assign it zero. Thus all physical kernels under the new upper aCC
mean projection have no mean a and at most one total C, and are exactly
the source-free/C-only restriction of the completed old source-channel
physical witnesses. Reproject all4 explicit old currents and residuals,
verify their owning hashes/receipts and exact divergence reconstruction.
This is reuse of a qualified physical proof, not a fresh loop amplitude.

Potential scope: Q0x=0; at g1 a quadratic potential produces intrinsic
mass degree2, outside01. A cubic potential times F1x leaves at least one
scalar mean after two Taylor replacements; quartic leaves at least two.
A possible linear term has coefficient degree3. Retain only the previously
qualified zero-scalar-mean/intrinsic01 exclusion. This gives no global
potential zero or chosen vacuum/mass adoption.

Actual V791 matrices must match PBB=q2I-qqT,PB_L=q,P_LB=-q and
GBB=I/q2+(Omega-1)qqT/q4,GB_L=-q/q2,G_LB=q/q2,G_LL=0 at all45 colors,
all4 Lorentz components; widths eta_H/xi_M remain symbolic. Check native
and replay packets agree. These inherited actual inverse directions make
the Ward contraction applicable also through B-B covariance and the
longitudinal B-L leg, with common scalar regulator profiles. No standalone
inverse heat kernel or exceptional-momentum value is introduced.

CPS support theorem is reused at the new target: external a,C,u preserve
the physical-fermion ideal P=S=K=0 after source operations. Mixed Hessian
blocks vanish there; surviving fermion block and actual Ihat second block
have no nonminimal a or u dependence. An aCC derivative therefore kills
the hatted trace, also in the unprobed case. This is a target support zero,
not global anomaly/measure/phase zero. Actual CPS derivation and counterexample
remain binding; no physical matter source is included in the target.

Together with a completed actual GF master witness, these support checks,
V801 proper LEFT chain and V790 full own-jet Jacobian zero can transfer
raw CR to proper QGamma=-CQ=CR only in this finite formal prescription.
No continuum QAP, common restoration, source-product equivalence, physical
viability or E5/A5 result follows. The remaining72 raw M candidates still
require evaluation; no coefficient is chosen to cancel the known remainder.

One90s after-import worker,8GiB sampled private/350MiB launch floor,
128MiB complete packet,10MiB artifact. Sequential after master worker stops.
Freeze sources/inputs first. Exact reconstruction and matrix comparisons
share action/software/AI author; disclose this limitation. Preserve all
failed/unfinished evidence; no automatic retry. Current AGENTS governs.
