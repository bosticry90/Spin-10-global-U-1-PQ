from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('aCC_root_algebra',O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/roots.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('aCC_LEFT_Taylor',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py');vr=importlib.util.module_from_spec(sp);sp.loader.exec_module(vr)
J=m.J;w=m.w;A=m.A;load=m.load;read=m.read;digest=m.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def contract(rows,side,mom,diagonal=False):
 out={};kept=[]
 for at,(ww,mon,cc) in enumerate(rows):
  ff=[(j,n-1319) for j,(n,js) in enumerate(ww) if 1319<=n<1499];rr=[(j,n-1962) for j,(n,js) in enumerate(ww) if 1962<=n<2142]
  if len(ff)!=1 or len(rr)!=1:continue
  assert all(not js for n,js in ww)
  if diagonal and ff[0][1]%4!=rr[0][1]%4:continue
  atq,field=(ff if side=='F' else rr)[0];color,mu=divmod(field,4);powers=list(mon);powers[mom+mu]+=1
  key=color,tuple((n,tuple(js)) for j,(n,js) in enumerate(ww) if j!=atq),tuple(powers)
  out[key]=out.get(key,J.ZERO)+A.decode_coeff(cc);kept.append(at)
 out={k:c for k,c in out.items() if c}
 return out,dict(input_indices=kept,contraction=[[color,[[n,list(js)] for n,js in ww],list(mon),w.enc(c)] for (color,ww,mon),c in sorted(out.items())])
def project_one(P):
 out={}
 for ww,c in P.items():
  qq=na=nc=0;bad=False
  for n,js in ww:
   if 1319<=n<1962:qq+=1
   elif 598<=n<643:na+=1
   elif 553<=n<598:nc+=1
   else:bad=True;break
  if not bad and qq==1 and na<=1 and nc<=2:out[ww]=c
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 base=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';cn=load(base/'native_aCC_catalog.json.gz');cr=load(base/'replay_aCC_catalog.json.gz');assert cn==cr
 contractions=[];fullzero=False
 for row in cn['roots']:
  if row['state']!='F1':continue
  tests=[]
  for label,side,mom,diag in [('right_l','R',4,False),('left_k','F',0,False),('wrong_right_k','R',0,False),('diagonal_right_l','R',4,True)]:
   out,ev=contract(row['selected'],side,mom,diag);tests.append(dict(test=label,terms=len(out),evidence=ev))
   if row['family']=='preference' and label=='right_l':fullzero=not out
  contractions.append(dict(state=row['state'],family=row['family'],tests=tests))
  print('STAGE '+json.dumps(dict(family=row['family'],counts={x['test']:x['terms'] for x in tests})),flush=True)
 pn=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');pr=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/replay_inputs.json.gz');assert pn==pr
 states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()};identities=[]
 for probe in [0,1]:
  F=states['Fu0_'+str(probe)];E=states['Eu0_'+str(probe)];diffs=[]
  for n in range(180):
   d=w.plus(E[n],J.D(F[598+n//4],n%4));diffs.append(dict(field=n,difference=J.encode(d)))
  identities.append(dict(probe=probe,all_full_sourceful_differences=diffs,zero=all(not r['difference'] for r in diffs)))
 ordinary=[]
 for row in cn['ordinary']:
  if row['g'] or row['owner'] not in ['GF_original','GF_probe0','GF_probe1']:continue
  P=J.decode(row['selected']);eulers=J.euler(P,range(1319,1499));diffs=[]
  for n in range(180):
   if row['owner']=='GF_original':expected={};rt={}
   else:
    probe=int(row['owner'][-1]);p=states['Eu0_'+str(probe)][n];expected=project_one(m.v.tangent(p));rt=project_one(vr.tangent(p));assert expected==rt
   actual=eulers.get(1319+n,{});diff=w.plus(actual,w.scale(expected,J.constant(-1)));diffs.append(dict(field=n,actual=J.encode(actual),expected=J.encode(expected),difference=J.encode(diff)))
  ordinary.append(dict(owner=row['owner'],full_selected_ordinary=J.encode(P),all_B_quantum_Euler_comparisons=diffs,zero_differences=all(not q['difference'] for q in diffs)))
 q=s.Matrix(s.symbols('q0:4',real=True));q2=(q.T*q)[0];om=s.Symbol('Omega');pt=q2*s.eye(4)-q*q.T;gg=s.eye(4)/q2+(om-1)*q*q.T/q2**2
 symbols=dict(right=[s.simplify(t) for t in pt*q],inverse_longitudinal=[s.simplify(t) for t in pt*gg*q],wrong_diagonal=[s.expand(t) for t in s.diag(*[pt[i,i] for i in range(4)])*q])
 assert symbols['right']==[0]*4 and symbols['inverse_longitudinal']==[0]*4 and any(symbols['wrong_diagonal'])
 decisions=[]
 for case in cn['cases']:
  removed=[];retained=[]
  for path in case['complete_cycles']:
   root,ro,chain=path;c=cn['classes'][root]
   eligible=(c['owner']=='R_F1' and c['quantum']==['BM','BM'] and fullzero and all(x['zero'] for x in identities) and all(x['zero_differences'] for x in ordinary))
   if eligible:
    i,ori=chain[0] if ro==0 else chain[-1];endpoint=cn['classes'][i]['quantum'][ori if ro==0 else 1-ori]
    eligible=endpoint in ['BM','LM']
   (removed if eligible else retained).append(path)
  decisions.append(dict(case=case['case'],removed_paths=removed,retained_paths=retained,proper_amplitude_not_inferred=True))
 art=save('ward_tables.json.gz',dict(root_contractions=contractions,full_source_longitudinality=identities,ordinary_B_legs=ordinary,symbolic_reference_inverse={k:[str(t) for t in v] for k,v in symbols.items()},path_decisions=decisions))
 result=dict(schema='ACTUAL_ACC_OPERATOR_REDUCTION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',full_F1_BB_right_l_zero=fullzero,source_longitudinality_zero=all(x['zero'] for x in identities),ordinary_B_leg_comparisons_zero=all(x['zero_differences'] for x in ordinary),cases=[dict(case=d['case'],removed=len(d['removed_paths']),retained=len(d['retained_paths'])) for d in decisions],artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'ward_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
