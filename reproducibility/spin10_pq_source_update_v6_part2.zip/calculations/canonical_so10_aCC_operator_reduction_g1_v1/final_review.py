from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-operator-reduction-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('final_actual_aCC_master',O/'master.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
J=a.J;w=a.w;z=a.z;load=a.load;read=a.read;digest=a.digest
def dump(p,data):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(data,h,sort_keys=True);h.write('\n')
def direct_select(P):
 out={}
 for ww,c in P.items():
  na=sum(598<=i<643 for i,js in ww);nc=sum(553<=i<598 for i,js in ww);other=len(ww)-na-nc
  d=sum(J.dimension(i)+len(js) for i,js in ww)
  if len(ww)>=2 and other+max(na-1,0)+max(nc-2,0)<=2 and 5-d in [0,1]:out[ww]=c
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for p in sorted(O.glob('*preparation.json')):
  for n,h in read(p)['sha256'].items():assert digest(R/n)==h,(p.name,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 success={};failed={}
 for name,bound in [('ward',120),('support_v3',90),('master_v4',180)]:
  cap=read(O/(name+'_capture.json'));res=read(O/(name+'_result.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  success[name]=cap
 for name,code in [('master',124),('master_v2',124),('master_v3',124),('support',1),('support_v2',124)]:
  cap=read(O/(name+'_capture.json'));assert cap['exit_code']==code and not cap['calculation_completed'] and cap['post_run_observations_qualified'];failed[name]=cap
 for cap in list(success.values())+list(failed.values()):
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples'] and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
 base=O.parent/'canonical_so10_ghost_source_companion_catalog_g1_v1';assert (base/'native_aCC_catalog.json.gz').read_bytes()==(base/'replay_aCC_catalog.json.gz').read_bytes();cat=load(base/'native_aCC_catalog.json.gz');ward=load(O/'ward_tables.json.gz');wr=read(O/'ward_result.json');assert digest(O/'ward_tables.json.gz')==wr['artifact']['sha256']
 actual=[]
 for row in cat['roots']:
  if row['state']!='F1':continue
  tests=[]
  for label,side,mom,diag in [('right_l','R',4,False),('left_k','F',0,False),('wrong_right_k','R',0,False),('diagonal_right_l','R',4,True)]:
   out,ev=z.contract(row['selected'],side,mom,diag);tests.append(dict(test=label,terms=len(out),evidence=ev))
  actual.append(dict(state=row['state'],family=row['family'],tests=tests))
 assert actual==ward['root_contractions'];assert [d['removed'] for d in wr['cases']]==[4,0,40] and [d['retained'] for d in wr['cases']]==[0,0,72]
 for case,decision in zip(cat['cases'],ward['path_decisions']):
  removed=decision['removed_paths'];retained=decision['retained_paths'];assert sorted(removed+retained)==sorted(case['complete_cycles']) and not any(p in retained for p in removed)
  for root,ro,path in removed:
   q=cat['classes'][root];assert q['owner']=='R_F1' and q['quantum']==['BM','BM'];i,o=path[0] if ro==0 else path[-1];endpoint=cat['classes'][i]['quantum'][o if ro==0 else 1-o];assert endpoint in ['BM','LM'] and cat['classes'][i]['g']==0
 old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(old/'native_inputs.json.gz');assert packet==load(old/'replay_inputs.json.gz');states={k:{n:J.decode(raw) for n,raw in rows} for k,rows in packet['states'].items()}
 for probe,row in enumerate(ward['full_source_longitudinality']):
  diffs=[]
  for n in range(180):diffs.append(dict(field=n,difference=J.encode(w.plus(states['Eu0_'+str(probe)][n],J.D(states['Fu0_'+str(probe)][598+n//4],n%4)))))
  assert diffs==row['all_full_sourceful_differences'] and row['zero'] and all(not d['difference'] for d in diffs)
 for row in ward['ordinary_B_legs']:
  P=J.decode(row['full_selected_ordinary']);E=J.euler(P,set(range(1319,1499)))
  for d in row['all_B_quantum_Euler_comparisons']:
   n=d['field'];expected={} if row['owner']=='GF_original' else z.project_one(a.m.v.tangent(states['Eu0_'+row['owner'][-1]][n]));assert J.encode(E.get(1319+n,{}))==d['actual'] and J.encode(expected)==d['expected'] and not d['difference'] and E.get(1319+n,{})==expected
 print('STAGE complete_actual_Ward_contractions_longitudinal_vertices_and_path_decisions_verified',flush=True)
 # Independent ungrouped actual product reconstruction for all643 ports of
 # all6 cases. Parent failures remain failures; saved complete cases get only
 # their exact case-level verification, not a fabricated parent PASS.
 cache={}
 def src0(name,n):
  k=name,n
  if k not in cache:cache[k]={ww:c for ww,c in states[name][n].items() if all(i<643 for i,js in ww)}
  return cache[k]
 cases=[]
 for label in ['original_g0','original_g1','probe0_g0']:
  q=load(O/('master_'+label+'.json.gz'));assert '"case": "'+label+'"' in failed['master']['stdout_and_stderr'];cases.append((label,q,q['all643_port_dispositions'],None))
 for label in ['probe0_g1','probe1_g0']:
  q=load(O/('master_v2_'+label+'.json.gz'));assert '"case": "'+label+'"' in failed['master_v2']['stdout_and_stderr'];cases.append((label,q,q['all643_port_dispositions'],None))
 density=load(O/'master_v3_density.json.gz');M=J.decode(density['source_free_eligible_density']);ports=[];branches=[]
 for i in range(4):
  q=load(O/('master_v3_branch_'+str(i)+'.json.gz'));branches.append(q['branch']);ports.extend(q['all643_port_dispositions'])
  for f in q['factors']:assert J.encode(states[f['state']][f['field']])==f['original'] and J.encode(src0(f['state'],f['field']))==f['source_free']
 cases.append(('probe1_g1',dict(branches=branches,source_free_eligible_density=density['source_free_eligible_density']),ports,read(O/'master_v4_result.json')))
 summaries=[];portcount=0
 for label,q,ports,mresult in cases:
  assert len(ports)==643*len(q['branches']);seen=set();total={}
  for row in ports:
   left,right,n=row['left'],row['right'],row['field'];assert [left,right] in [list(b) for b in q['branches']];assert (left,right,n) not in seen;seen.add((left,right,n));P=src0(left,n);Q=src0(right,n);product=direct_select(J.mul(P,Q));assert J.encode(product)==row['eligible_product'];J.add(total,product);portcount+=1
   L={a.profile(ww) for ww in P};B={a.profile(ww) for ww in Q};journal=[]
   for lp in sorted(L):
    for rp in sorted(B):
     summed=tuple(x+y for x,y in zip(lp,rp));journal.append(dict(left=list(lp),right=list(rp),summed=list(summed),included=a.allowed(summed)))
   assert journal==row['group_pair_dispositions'] and row['full_pair_count']==len(P)*len(Q)
  total=J.clean(total);assert J.encode(total)==q['source_free_eligible_density']
  if mresult:
   sectors=mresult['sectors'];assert sum(r['terms'] for r in sectors)==len(total);allnorm={}
   for row in sectors:
    assert digest(O/row['artifact']['file'])==row['artifact']['sha256'];ev=load(O/row['artifact']['file']);N=row['field_degree'];part={ww:c for ww,c in total.items() if len(ww)==N};div={}
    for mu,raw in enumerate(ev['currents']):J.add(div,J.D(J.decode(raw),mu))
    normal=J.decode(ev['Euler_remainder']);assert w.plus(J.clean(div),normal)==part and len(normal)==row['Euler_remainder_terms'];J.add(allnorm,normal)
    atom=J.decode(ev['single_monomial_control']);cc,nn=a.homotopy(atom);assert J.encode(nn)==ev['control_Euler_remainder']
   normal=J.clean(allnorm)
  else:
   div={}
   for mu,raw in enumerate(q['currents']):J.add(div,J.D(J.decode(raw),mu))
   normal=J.decode(q['Euler_remainder']);assert w.plus(J.clean(div),normal)==total and not normal
   if q.get('T2_currents'):
    div={}
    for mu,raw in enumerate(q['T2_currents']):J.add(div,J.D(J.decode(raw),mu))
    assert J.clean(div)==J.decode(q['selected_T2_half'])
   if total:
    ww,c=next(iter(sorted(total.items())));cc,nn=a.homotopy({ww:c});assert len(nn)==q['literal_term_perturbation_remainder_terms']
  summaries.append(dict(case=label,all643_ports_per_branch_independently_reconstructed=True,classical_terms=len(total),Euler_remainder_terms=len(normal),exact_saved_four_current_reconstruction=True));print('STAGE '+json.dumps(summaries[-1],sort_keys=True),flush=True)
  del total;gc.collect()
 assert portcount==9645
 comm=load(O/'master_Taylor_commutation.json.gz');assert comm['all4_mu_prefix_LEFT_commutators_zero'] and comm['quantum_generators_T_zero'] and comm['wrong_jet_transport_detected']
 for n,js in comm['all_input_field_jet_generators']:
  atom={((n,tuple(js)),):J.constant(1)};expected={((1319+n,tuple(js)),):J.constant(1)};assert a.m.v.tangent(atom)==a.vr.tangent(atom)==expected
  for mu in range(4):assert a.m.v.tangent(J.D(atom,mu))==a.vr.tangent(J.D(atom,mu))==J.D(expected,mu)
 # Physical witness restriction is a reuse of its owning completed proof.
 sr=read(O/'support_v3_result.json');assert digest(O/sr['artifact']['file'])==sr['artifact']['sha256'];support=load(O/sr['artifact']['file']);assert len(support['physical_witness_restrictions'])==6 and len(support['actual_inverse_all45_colors'])==45
 for ev in support['physical_witness_restrictions']:
  own=ev['source'];assert digest(old/own['file'])==own['sha256'] and own['case_calculation_completed_and_reconstruction_checked'];div={}
  for mu,raw in enumerate(ev['restricted_currents']):J.add(div,J.D(J.decode(raw),mu))
  assert J.clean(div)==J.decode(ev['restricted_residual'])
 print('STAGE actual_classical_products_all_cases_commutation_and_physical_witnesses_verified',flush=True)
 # Exactly one inherited audit. Custody exit2 is retained as NOTPASS.
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(line) for line in p.stdout.splitlines() if line.strip()];exits=[e['exit_code'] for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED';assert next(e for e in events if e['event']=='step_finished' and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 oldtree=(C/'old_git_tree.txt').read_bytes();assert oldtree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V810.md'];size=sum(p.stat().st_size for p in files);assert size<=128*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 allzero=all(not r['Euler_remainder_terms'] for r in summaries)
 receipt=dict(schema='ACTUAL_ACC_OPERATOR_REDUCTION_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_WARD_REDUCTION_AND_ACTUAL_MASTER_EVIDENCE_WITH_FAILED_PARENTS_PRESERVED',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base'],state_sha256=state,raw_original_H_M_candidate_counts_before=[4,0,112],raw_candidate_counts_after=[0,0,72],all_complete_classical_cases=summaries,all9645_actual_source_free_port_products_independently_reconstructed=True,all_GF_master_remainders_zero=allzero,proper_unprobed_aCC_zero_supported_this_prescription=True,proper_M_aCC_bridge_supported_this_prescription=allzero,marked_M_aCC_coefficients_not_calculated=True,physical_witness_restrictions=6,actual_inverse_all45_colors_verified=True,failed_workers={k:v['exit_code'] for k,v in failed.items()},failed_parent_cases_not_reclassified=True,successful_worker_seconds={k:read(O/(k+'_result.json'))['elapsed_after_imports'] for k in success},largest_sampled_private_bytes=max(v['private_bytes'] for cap in list(success.values())+list(failed.values()) for v in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(oldtree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_restoration_QAP_E5_physical_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k] for k in ['execution_state','evidence_validation','all_GF_master_remainders_zero','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
