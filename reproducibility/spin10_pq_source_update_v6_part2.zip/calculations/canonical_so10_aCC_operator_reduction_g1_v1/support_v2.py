from pathlib import Path
import importlib.util,json,os,threading,time
import sympy as s
sp=importlib.util.spec_from_file_location('aCC_frozen_master_tools',Path(__file__).resolve().with_name('master.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
R=a.R;O=a.O;J=a.J;w=a.w
def project(P):
 out={}
 for ww,c in P.items():
  q=nc=na=0;bad=False
  for n,js in ww:
   if 1319<=n<1962:q+=1
   elif 553<=n<598:nc+=1
   elif 598<=n<643:na+=1
   else:bad=True;break
  if not bad and q==2 and nc<=2 and na<=1:out[ww]=c
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(90,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'support_v2_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=a.load(base/'native_inputs.json.gz');states={k:{n:J.decode(p) for n,p in rows} for k,rows in pn['states'].items()}
 for k in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[k][n] for n in range(508))
 for k in ['F0','F1']:
  for n in range(508):assert all(all(i<643 and not 598<=i<643 for i,js in ww) and sum(553<=i<598 for i,js in ww)<=1 for ww in states[k][n])
 assert all(not states['F0'][n] for n in range(180,508))
 for n,raw in pn['physical']['P_E0']:assert all(len(ww)<=1 and all(i<508 for i,js in ww) for ww in J.decode(raw))
 for k in ['P_E1_gauge','P_E1_scalar']:
  for n,raw in pn['physical'][k]:assert n<180 and all(len(ww)<=2 and all(i<508 for i,js in ww) for ww in J.decode(raw))
 owning=a.read(base/'collect_result.json');witness=[r for r in owning['artifacts'] if '_source_physical_' in r['file']];assert len(witness)==6;physical=[]
 for row in witness:
  assert a.digest(base/row['file'])==row['sha256'] and row['case_calculation_completed_and_reconstruction_checked'];old=a.load(base/row['file']);assert old['normal_form']==[] and old['exact_full_reconstruction']
  P=project(J.decode(old['raw_residual']));curr=[];div={}
  for mu,raw in enumerate(old['boundary_currents']):
   p=project(J.decode(raw));curr.append(J.encode(p));J.add(div,J.D(p,mu))
  assert J.clean(div)==P;physical.append(dict(case=old['case'],source=row,restricted_residual=J.encode(P),restricted_currents=curr,exact_reconstruction=True))
 inverse=O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1';ni=a.load(inverse/'native_inverse.json.gz');ri=a.load(inverse/'replay_inverse.json.gz')
 for key in ['Preference','Greference']:assert ni[key]==ri[key]
 q=s.Matrix(s.symbols('q0:4',real=True));q2=(q.T*q)[0];xi=s.Symbol('xi',real=True);eta=s.Symbol('eta_H',real=True);loc={str(z):z for z in [*q,xi,eta]};P={(i,j):s.sympify(v,locals=loc) for i,j,v in ni['Preference']};G={(i,j):s.sympify(v,locals=loc) for i,j,v in ni['Greference']};checks=[]
 for color in range(45):
  om=eta if color<12 else xi;b=4*color;la=508+color
  for mu in range(4):
   assert s.simplify(P.get((b+mu,la),0)-q[mu])==0 and s.simplify(P.get((la,b+mu),0)+q[mu])==0
   assert s.simplify(G.get((b+mu,la),0)+q[mu]/q2)==0 and s.simplify(G.get((la,b+mu),0)-q[mu]/q2)==0
   for nu in range(4):
    assert s.simplify(P.get((b+mu,b+nu),0)-(q2*int(mu==nu)-q[mu]*q[nu]))==0
    assert s.simplify(G.get((b+mu,b+nu),0)-(int(mu==nu)/q2+(om-1)*q[mu]*q[nu]/q2**2))==0
  assert G.get((la,la),0)==0;checks.append(dict(color=color,width=str(om),all4x4_entries_and_BL_LB_LL_verified=True))
 art=a.save('support_v2_tables.json.gz',dict(physical_witness_restrictions=physical,actual_inverse_all45_colors=checks,physical_support_premises_checked=True,unknown_physical_E1_x_bypassed_not_zeroed=True,CPS_new_target_support='External a,C,u preserve P=S=K ideal; surviving fermion/Ihat blocks independent a/u; no global zero claim.'))
 result=dict(schema='ACTUAL_ACC_PHYSICAL_INVERSE_SUPPORT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',physical_witnesses_restricted=6,actual_inverse_colors_verified=45,artifact=art,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'support_v2_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
