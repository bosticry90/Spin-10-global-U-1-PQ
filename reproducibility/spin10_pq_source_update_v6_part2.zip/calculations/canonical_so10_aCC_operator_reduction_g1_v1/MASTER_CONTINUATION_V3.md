# Exact Euler membership correction and single remaining case V3

V2 FAILED timeout124/180s. Its H g1 and M g0 case artifacts are complete;
its M g1 stage reports335968 density terms but no homotopy/result artifact.
The whole parent remains INCOMPLETE NOTPASS. Do not infer an unrecorded zero.
Five complete cases now have explicit divergence witnesses, subject to final
validation of their actual products/currents. Old sources/captures unchanged.

Inspection of the actual Euler implementation shows one exact avoidable cost:
for each token it tests `t[0] not in ids`. V1's homotopy supplies a long list
of all field IDs. A set of those same integers has precisely the same
membership predicate and removes repeated linear scans. V3 locally wraps
the frozen Euler function with `set(ids)`; no term, derivative, summand,
parameter or physical input is changed. Exact list/set Euler comparisons on
actual first/last1000-word samples of the three V1 cases diagnose the wrapper;
equivalence follows algebraically for every word from identical membership.
The FULL remaining M g1 density still gets direct variational Euler checks
and four-current reconstruction. No sparse sample supplies its conclusion.

Recompute only the one remaining case under the same classical grouping,
selector and source-operation order. Save full density and complete643-port
products/factors in four branch artifacts BEFORE the homotopy, so a future
failure cannot erase the executed intermediate evidence. The same structural
Taylor commutation proof completed in V2 is authenticated and reused; this
does not complete its failed parent. Single-term negative control retained.

Known335968-term size justifies one240s after-import single-case worker,
8GiB sampled private/350MiB launch floor,128MiB complete packet/10MiB artifact.
This is an explicitly frozen new bounded continuation after reassessing two
different incomplete representations, not retroactive resource expansion.
No automatic retry. Preserve failure and exact stages. Physical/inverse/CPS
support and final validation remain separate. State/authority/E5/A5 unchanged.
