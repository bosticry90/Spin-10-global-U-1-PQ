from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-operator-reduction-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert (O/'master_v3_capture.json').exists(),'PREVIOUS_WORKER_MUST_BE_TERMINAL'
for n,h in json.loads((O/'master_v2_preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
base=R/'calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1';rows=[r for r in json.loads((base/'collect_result.json').read_bytes())['artifacts'] if '_source_physical_' in r['file']]
names=[base/'collect_result.json']+[base/r['file'] for r in rows]+[R/'calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1'/n for n in ['native_inverse.json.gz','replay_inverse.json.gz']]+[R/'calculations/canonical_so10_chiral_probe_support/DERIVATION.md']
# The actual CPS directory name is authenticated below; a missing dependency
# is a preparation failure and never a scientific zero.
for p in names:
 n=p.relative_to(R).as_posix();assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['SUPPORT_CONTINUATION_V3.md','support_v3.py','run_support_v3.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'support_v3_preparation.json',dict(sha256={**json.loads((O/'master_v2_preparation.json').read_bytes())['sha256'],**{p.relative_to(R).as_posix():digest(p) for p in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'support_v3.py')]);dump(O/'support_v3_capture.json',cap);dump(C/'support_v3_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
