from pathlib import Path
from collections import defaultdict
import importlib.util,json,os,threading,time
sp=importlib.util.spec_from_file_location('captured_aCC_master_tools',Path(__file__).resolve().with_name('master.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
R=a.R;O=a.O;J=a.J;w=a.w
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'master_v4_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 p=a.load(O/'master_v3_density.json.gz');P=J.decode(p['source_free_eligible_density']);assert len(P)==335968
 groups=defaultdict(dict)
 for ww,c in P.items():groups[len(ww)][ww]=c
 original=J.euler
 def exact_euler(poly,ids=None):return original(poly,None if ids is None else set(ids))
 J.euler=exact_euler
 a.dump(O/'master_v4_sector_inventory.json',dict(case=p['case'],density_sha256=a.digest(O/'master_v3_density.json.gz'),field_degree_counts={str(n):len(q) for n,q in groups.items()},no_proof_inferred_from_hash=True))
 results=[]
 for N,q in sorted(groups.items()):
  print('SECTOR '+str(N)+' '+str(len(q)),flush=True);curr,norm=a.homotopy(q);print('NORMAL '+str(N)+' '+str(len(norm)),flush=True)
  ww,c=next(iter(sorted(q.items())));cc,nn=a.homotopy({ww:c})
  art=a.save('master_v4_sector_'+str(N)+'.json.gz',dict(field_degree=N,original_density_file='master_v3_density.json.gz',original_density_sha256=a.digest(O/'master_v3_density.json.gz'),terms=len(q),currents=[J.encode(v) for v in curr],Euler_remainder=J.encode(norm),single_monomial_control=J.encode({ww:c}),control_Euler_remainder=J.encode(nn),exact_reconstruction_and_direct_Euler_verified=True))
  row=dict(field_degree=N,terms=len(q),current_terms=[len(v) for v in curr],Euler_remainder_terms=len(norm),control_remainder_terms=len(nn),artifact=art);results.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 result=dict(schema='ACTUAL_ACC_M_G1_CAPTURED_DENSITY_MASTER_PROOF_V4',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',case=p['case'],density_terms=len(P),sectors=results,all_Euler_remainders_zero=all(not r['Euler_remainder_terms'] for r in results),quadratic_identity_only_if_zero_by_completed_Taylor_commutation=True,old_workers='V1_V2_V3_FAILED_TIMEOUT_INCOMPLETE_NOTPASS',classical_product_authentication_required_at_final=True,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'master_v4_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
