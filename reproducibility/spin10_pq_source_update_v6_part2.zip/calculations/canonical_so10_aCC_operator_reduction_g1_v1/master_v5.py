from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import importlib.util,json,os,threading,time
sp=importlib.util.spec_from_file_location('aCC_first_order_master_tools',Path(__file__).resolve().with_name('master.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
R=a.R;O=a.O;J=a.J;w=a.w
def current(P):
 out=[{} for _ in range(4)]
 for ww,c in P.items():
  assert len(ww)==4;pos=[(at,n,js) for at,(n,js) in enumerate(ww) if js];assert len(pos)==1 and len(pos[0][2])==1
  at,n,js=pos[0];J.put(out[js[0]],ww[:at]+((n,()),)+ww[at+1:],J.times(c,J.constant(F(1,4))))
 return [J.clean(p) for p in out]
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'master_v5_preparation.json')['sha256'].items():assert a.digest(R/n)==h,n
 raw=a.load(O/'master_v3_density.json.gz');P={ww:c for ww,c in J.decode(raw['source_free_eligible_density']).items() if len(ww)==4};assert len(P)==259104
 inventory=Counter(sum(len(js) for n,js in ww) for ww in P);a.dump(O/'master_v5_jet_inventory.json',dict(N=4,all_word_derivative_counts=dict(inventory),premise_pass=inventory=={1:len(P)}));assert inventory=={1:len(P)},'ACTUAL_FIRST_ORDER_PREMISE_FAILED'
 curr=current(P);div={}
 for mu,q in enumerate(curr):J.add(div,J.D(q,mu))
 div=J.clean(div);normal=w.plus(P,w.scale(div,J.constant(-1)));assert not normal,'ACTUAL_FIRST_ORDER_CURRENT_NOT_CLOSED'
 keys=sorted({tuple(n for n,js in ww) for ww in P});replays=[]
 for key in keys[:2]+keys[-2:]:
  q={ww:c for ww,c in P.items() if tuple(n for n,js in ww)==key};cc,nn=a.homotopy(q);assert cc==current(q) and not nn;replays.append(dict(concrete_fields=list(key),terms=len(q),general_homotopy_currents=[J.encode(v) for v in cc],direct_Euler_remainder=J.encode(nn)))
 ww,c=next(iter(sorted(P.items())));atom={ww:c};cc,nn=a.homotopy(atom);half=w.plus(P,w.scale(div,J.constant(F(-1,2))));assert half and nn
 art=a.save('master_v5_sector_4.json.gz',dict(field_degree=4,original_density_file='master_v3_density.json.gz',original_density_sha256=a.digest(O/'master_v3_density.json.gz'),terms=len(P),currents=[J.encode(q) for q in curr],Euler_remainder=[],Euler_zero_method='Exact full P=div J, hence EL(P)=EL(div J)=0; general-homotopy/direct-Euler concrete-sector replays.',direct_general_homotopy_replays=replays,single_monomial_control=J.encode(atom),control_Euler_remainder=J.encode(nn),half_current_difference=J.encode(half),all_terms_first_order=True,exact_reconstruction=True))
 sectors=[]
 for N in [2,3]:
  path=O/('master_v4_sector_'+str(N)+'.json.gz');q=a.load(path);assert not q['Euler_remainder'];sectors.append(dict(field_degree=N,terms=q['terms'],Euler_remainder_terms=0,artifact=dict(file=path.name,sha256=a.digest(path),bytes=path.stat().st_size)))
 sectors.append(dict(field_degree=4,terms=len(P),Euler_remainder_terms=0,artifact=art));assert sum(row['terms'] for row in sectors)==335968
 result=dict(schema='ACTUAL_ACC_FIRST_ORDER_MASTER_COMPLETION_V5',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',case='probe1_g1',sectors=sectors,all_Euler_remainders_zero=True,N4_full_first_order_current_exact=True,N4_current_terms=[len(q) for q in curr],N4_half_current_sensitive_positions=len(half),old_V1_V2_V3_V4_workers='FAILED_TIMEOUT_INCOMPLETE_NOTPASS',classical_input_products_require_final_independent_reconstruction=True,elapsed_after_imports=time.perf_counter()-tick)
 a.dump(O/'master_v5_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
