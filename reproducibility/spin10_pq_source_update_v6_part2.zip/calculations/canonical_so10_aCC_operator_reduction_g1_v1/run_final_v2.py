from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/aCC-operator-reduction-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert json.loads((O/'master_v5_result.json').read_bytes())['all_Euler_remainders_zero']
for p in O.glob('*preparation.json'):
 for n,h in json.loads(p.read_bytes())['sha256'].items():assert digest(R/n)==h,(p.name,n)
for n in ['PROOF.md','RESULT.md','FINAL_RECORD_V2.md','final_review_v2.py','run_final_v2.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
names={p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()};names['docs/RESEARCH_EXECUTION_HANDOFF_V810.md']=digest(R/'docs/RESEARCH_EXECUTION_HANDOFF_V810.md')
dump(O/'final_preparation.json',dict(sha256=names,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v2.py')]);dump(O/'final_capture.json',cap);dump(C/'final_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
