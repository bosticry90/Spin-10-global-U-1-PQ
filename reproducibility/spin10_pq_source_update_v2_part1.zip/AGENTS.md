# ToE-Next research execution

Recover actual state from Git, live processes and repository evidence before
starting work. Use `python -B tools/research_session_preflight.py` for a compact
read-only snapshot, then read the current handoff (the highest numbered
`docs/RESEARCH_EXECUTION_HANDOFF_V*.md`) and relevant versioned contracts and
actual receipts. A snapshot authenticates bytes; it does not execute or
scientifically accept their calculations.

This AGENTS.md is the authoritative live research-execution policy. The
director's standing delegation of 2026-10-16 is incorporated here; do not create
a separate override or superseding policy. `project_state.json` remains the
sole machine-readable scientific authority. Neither operating instructions nor
handoffs are an alternate scientific status ledger.

The director retains authority over overarching objectives, accepted
foundational assumptions, consequential scientific promotions, publication and
external actions. Ordinary scientific discretion is delegated: select questions
and priorities, review literature, choose methods, define bounded experiments,
write and execute code, derive and verify results, correct implementation
errors, investigate provisional hypotheses and action-permitted parameter
regions, reject failed candidates, and redirect unproductive exploratory work.
Do not ask the director to choose routine technical alternatives or approve
each calculation, correction or next increment.

After a bounded result, verify it, assess its significance and continue the most
informative justified next step. A milestone, local commit, negative result or
exhausted historical run allowance is not an automatic stopping point. Do not
manufacture activity when no competent next step exists; report the scientific
limitation and pursue other valuable authorized work when possible.

Exploration is not foundational adoption. A provisional parameter point is not
an accepted physical benchmark. Keep prior exclusions and closed failed routes
in their qualified scopes. Do not repeatedly release parameters or fit unknown
contributions merely to rescue a favored hypothesis. Do not transfer
parameter-specific results to changed inputs without justification.

Explicit authorization remains necessary for foundational adoption/replacement,
changed overarching goals, protected scientific promotion outside an approved
acceptance process, explicitly blocked-stage activation, human-paused research,
publication, outreach, remote push, deployment, spending, restricted access, and
destructive or irreversible changes to protected evidence/data. Ask only when
a reserved decision is unavoidable and no valuable authorized alternative
remains. Environment permissions and binding safety/resource limits still apply.

Apply the [charter's three-track operating model](CHARTER.md#three-parallel-tracks):
scientific investigation and AI scientific-capability evaluation are equally
important research objectives. The director's education is concurrent,
voluntary and nonblocking; never require lessons, examinations, teach-back or
technical mastery before otherwise justified, authorized work. A director's
knowledge gap is distinct from missing scientific justification or verification.
The latter still blocks the affected calculation or claim when required.

Before substantial new work, reuse existing evidence to identify the scientific
or AI-capability question, relevance, plausible outcomes and least expensive
competent test. Apply the charter's scientific-foundations review proportionally.
Use existing calculation records to report demonstrated AI capabilities,
failures, reference standards and shared-error limits; do not create a separate
benchmark platform. Agreement between AI implementations cannot validate a
shared physical assumption. Explain consequential choices accessibly while
preserving the director's authority and every scientific acceptance obligation.

Reuse the existing [epistemic ladder](docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md)
and [solo-review policy](docs/SOLO_REVIEW_POLICY_V1.md). No personal outreach,
recruitment or mandatory outside reviewer. Disclose shared assumptions, data,
software and authorship; multiple AI instances are not independent scientists.

For each bounded increment, freeze types, assumptions, immutable inputs,
expected evidence, failure conditions and authority ceiling before computation.
Keep proposals, calculations, evidence validation and director acceptance
distinct. Preserve exact failed and unfinished runs with explicit classifications.
Use distinct derivations and negative controls where scientifically meaningful.

Routine parsing, encoding, serialization, numerical, assertion and verification
harness corrections are delegated. Preserve failed sources and complete
captures; never weaken scientific requirements, silently change physical
inputs, erase failures or relabel incomplete work as PASS. Historical contracts
and run allowances remain immutable. When needed, establish a justified new
versioned bounded continuation under this standing delegation rather than
requesting another routine execution allowance. This does not retroactively
authorize an old execution. Freeze proportionate resource limits, observe actual
usage, report exhaustion as incomplete and reassess repeated failures. Do not
silently expand resources or truncate evidence.

Before parallel execution, establish independent inputs, write ownership and
dependency order. Prefer read-only independent calculations; compare completed
outputs before dependent checks or mutations. Parallelism is optional. Do not
launch agent organizations or repeat expensive qualified work without need.
Use suitable existing tools and structural proofs with explicit dependencies;
resource limits must report incomplete work, never silently truncate evidence.

Preserve uncommitted work and running calculations. No reset, evidence editing,
unrelated process termination, activation, remote push or unapproved publication.
Preserve main; no new branch/worktree without authorization. Keep original
contracts, receipts, calculations and historical decisions unchanged. Live
policy revisions do not rewrite the policy under which old work was performed:
authenticate historical policy bytes from their recorded Git checkpoint when
reproducing that evidence, and bind the current AGENTS.md for new work. Never
substitute new policy bytes for a historical hash, rebind old manifests or
bypass an integrity check. The removed override/directive and prior AGENTS.md
remain available at scientific checkpoint
`82ef1a771b9f4f3b401af4ab28ced0313ea750ec`.

This standing delegation supersedes routine per-increment approval, priority,
next-run and automatic-retry restrictions in older operating guidance; all
scientific, provenance, resource and solo-review obligations still apply.
Explicit blocked-stage and human-pause boundaries remain binding. Do not
resume flavor, unlock HB1/C5 or promote E5/A5 by interpreting delegation as
scientific acceptance. Do not change project_state.json for an editorial or
governance revision. No remote alignment/push is authorized by local completion.

Do not treat historical custody exit 2 as PASS. Validate completed bounded work
before a local commit, and record checks omitted, limitations and the next
smallest authorized scientific action. A failed scientific gate may have
successfully authenticated failure evidence; keep those statuses separate.

Use [local research conventions](docs/LOCAL_RESEARCH_CONVENTIONS_V1.md) for
the delegated validation command and execution states. Effort boundaries may
reduce engineering scope; they never reduce scientific acceptance obligations.
