# Recognize the actual indexed scalar aliases

V1 primary exited1 at its physical-AST field-name assertion. It incorrectly
accepted only B and x_sector while the qualified potential AST uses the
existing Phi,Sigma,SigmaBar,phi,phiBar,S,SBar tensor aliases as well. The same
sealed Hessian records their constant canonical pullback x=v+eta and J-frame
directions. No evidence for antighost/source dependence was found.

Keep V1 code,source copy,preparation and complete failed capture. V2 accepts
exactly the qualified scalar aliases plus the real-coordinate kinetic names
and their h/k directions. Unknown field names still fail. Authenticate the
literal pullback descriptor. This corrects the field-name premise checker;
no action,field,pair,source,reference,pole or physical assumption is changed.
One corrected primary and remaining replay under standing delegation,
same120seconds/8GiB,all other checks retained. Freeze revised bytes first.
