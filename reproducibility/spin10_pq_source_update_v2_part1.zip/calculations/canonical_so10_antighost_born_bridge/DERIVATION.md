# Restricted Born-family identity, before qualification

Use precisely the ALI1 even test operation

    D S = delta_bar S - sum_J integral V_J E_J^L S.

Its test functions are odd,so delta_bar is even;V_J has the parity ofJ.
ALI1 checks the pairing against the literal gauge-fixing action,not a desired
loop cancellation. In its twelve unbroken directions the V_J coefficients
depend only on external A,test functions and their ordinary jets. They have
no integrated-field or source dependence. The physical action is independent
of bar and J. The original master has no unbroken bar dependence. Hence
D annihilates the full gauge-fixed action as a local functional.

Let h,k be two independent fixed fluctuation families. Because D is even and
its coefficients are field independent,[D,delta_h]=[D,delta_k]=0,including
jet prolongations. Ordinary spacetime differentiation commutes with every
evolutionary variation. Therefore

    D H[h,k] = delta_k delta_h (D S) = 0.

All source variables stay external during these two variations;they are
still varied by D. A field-dependent V would invalidate this commutation.
The retained polynomial Hessian and all34 physical indexed Hessian programs
are covered by this argument without expanding their component matrix.

The actual reference matrices/constant chart maps have no bar,J dependence.
The fixed external-background heat kernel is F_Lambda[A],so D F=0 and
D G_Lambda=0. The separately retained reference determinant depends on A
and fixed reference inputs only,so D Gamma_ref=0. Thus for
X=G_Lambda(H-H_ref),D X=0. For every finite ordered product,

    D(X^n) = sum_(i=0)^(n-1) X^i (D X) X^(n-1-i) = 0.

The formula holds by the product-rule induction from n to n+1. It applies
before taking any supertrace or integration. It therefore uses neither
cyclicity of an infinite trace nor a vanishing Jacobian. Each retained formal
Born coefficient and Gamma_ref obey D Gamma_1,Lambda=0 within the existing
prescription. This is not a path-integral construction,an arbitrary IR
projection theorem or the full regulated Q Slavnov identity.

For the quartic dimension-zero logarithmic target,the leading angularly
contracted term is proportional to k_E^-4. In the existing UV shell,

    integral_(|k|>R) d^4k/(2*pi)^4 exp(-a*k^2/Lambda^2)/k^4
       = E1(a*R^2/Lambda^2)/(16*pi^2),  a>0.

Its derivative with respect to log Lambda^2 tends to1/(16*pi^2).
The dimensional UV-shell radial integral has coefficient
mu^(2epsilon) R^(-2epsilon)/(16*pi^2*epsilon),with the same residue.
The word weight a changes a finite constant,not this logarithmic coefficient.
The common one-loop determinant factor and graded signs are already retained
in both source and antighost inputs;no new factor is chosen to match them.
External-background multiplication/differentiation and the test operation
are independent of loop momentum and UV epsilon,so commute with extraction
of this local logarithmic coefficient. This assertion does not identify
power-sensitive or finite terms in the two prescriptions.

Consequently the measured one-loop source poles and the proved linear kernel
determine the unbroken-antighost quartic pole:its D-antighost variation must
equal the source image. The ALI1 table explicitly inverts that variation on
words with exactly one unbroken antighost and no jets,so it is unique in
this sector. A term independent of those antighosts is unconstrained here.
No broken-antighost coefficient or full Ward identity is inferred.

The claim is deliberately restricted to the authenticated ordinary Born/log
prescription. General renormalized insertions,QAP,finite contacts,measure,
Legendre construction,physical IR removal and full quantum equivalence remain
separate. No finite counterterm is adopted to impose this equation.
