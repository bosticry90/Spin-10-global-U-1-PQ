"""Actual-premise bridge to a restricted regulated Born/log-pole identity."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,os,re,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def sealed(folder,role):
    p=PKG/folder/(role+'.json');b=read(p.parent/'bindings.json');assert b['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p)
def walk(x):
    if isinstance(x,dict):
        yield x
        for v in x.values():yield from walk(v)
    elif isinstance(x,list):
        for v in x:yield from walk(v)
def add(*P):
    d=Counter()
    for p in P:
        for w,z in p.items():d[w]+=z
    return {w:z for w,z in d.items() if z}
def mul(P,Q):return add(*({w+v:a*b} for w,a in P.items() for v,b in Q.items()))
def substitute(P):return add(*({tuple('B' if n=='Y' else n for n in w):a} for w,a in P.items()))
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BORN_BRIDGE_WRITE')
        if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
    sys.addaudithook(guard);aliDir=OUT.parent/'canonical_so10_antighost_linear_identity';rc=read(aliDir/'validation_receipt.json');p=aliDir/(role+'_v2_result.json');assert rc['execution_state']=='COMPLETED' and rc['input_sha256'][str(p)]==digest(p);a=read(p);assert a['unbroken12_kernel_field_independent'] and a['all_measured_lower_orders_match_mod_currents'] and not a['tree_chain_rule_raw_difference'] and not a['tree_chain_rule_anchor'] and not any(a['tree_four_currents'])
    core=sealed('frozen_a10_e5_full_hessian',role);e2=sealed('frozen_a10_e2_transport',role);ref=core['retained_reference'];fields=set(ref['field_order']);sources=set(e2['source_shifts']);assert len(fields)==len(sources)==643
    kernels={};dependencies=set()
    for J,rows in a['all643_shift_Frechet_images'].items():
        Hrows=[]
        for r in rows:
            names=[n.split('__')[0] for n in r['word']];eps=[n for n in names if n.startswith('zz_da')];assert len(eps)==1
            if int(eps[0][-2:])>=12:continue
            for n in names:
                assert n not in fields|sources
                if not n.startswith('zz_da'):assert re.fullmatch(r'A\d+_[0-3]',n) and int(n[1:].split('_')[0])<12;dependencies.add(n)
            assert not ({str(x) for x in s.sympify(r['coefficient']).free_symbols}&(fields|sources));Hrows.append(r)
        if Hrows:kernels[J]=Hrows
    assert len(kernels)==60 and all(n.startswith(('JB','Jb')) for n in kernels)
    assert core['physical_Hessian_program']['canonical_scalar_pullback']=='x=v+eta; ordered aliases=qualified constant J x; directions J h,J k';physical=core['physical_Hessian_program']['all_34_literal_terms'];assert len(physical)==34;types=set();count=0
    for term in physical:
        for node in walk(term['mixed_second_variation_AST']):
            if node.get('node')=='Field':
                n=node['name'];base=n[2:] if n.startswith(('h_','k_')) else n;assert base in {'B','Phi','Sigma','SigmaBar','phi','phiBar','S','SBar','x_Phi','x_Sigma','x_phi','x_S'};types.add(base);count+=1
    poly=core['complete_source_and_GF_Hessian'];assert poly['all643_field_directions_retained'] and poly['external643_sources_frozen_only_in_fluctuation_derivative'] and poly['complete_second_variation']['complete_coefficients']==354321
    forbidden=fields|sources
    for key in ['reference_Hessian_raw_C3','reference_Green_raw_C3','physical_to_raw_kernel','physical_to_raw_inverse']:
        for row in ref[key]['entries']:assert not ({str(x) for x in s.sympify(row[2]).free_symbols}&forbidden)
    loop=core['finite_cutoff_loop_program'];assert loop['cutoff']=='F_Lambda=exp[-(-Dbar_H^2)/Lambda^2] on each actual H carrier; dual action on the right; source independent' and loop['Green_program']=='G_Lambda=F_Lambda G_ref F_Lambda^ST; fixed evaluation pairing, exact graded transpose' and 'Gamma_ref,Lambda[A]' in loop['reference_background_normalization'];assert core['complete_Hessian_and_reference_qualified'] and core['complete_one_loop_finite_UV_Born_family_defined']
    X={('G','H'):1};DX={('G','B'):1,('G','Y'):-1};words=[];P={():1};DP={}
    for n in range(1,17):
        if role=='primary':
            raw=add(*({('G','H')*i+('G','B')+('G','H')*(n-i-1):1,('G','H')*i+('G','Y')+('G','H')*(n-i-1):-1} for i in range(n)))
        else:DP=add(mul(DP,X),mul(P,DX));P=mul(P,X);raw=DP
        assert len(raw)==2*n and not substitute(raw);wrong=add(*({tuple('B' if k=='Y' else k for k in w):abs(c)} for w,c in raw.items()));assert wrong
        words.append({'n':n,'uncancelled_ordered_product_terms':len(raw),'D_H_equal_zero_after_model_bridge':True,'wrong_pairing_detected_without_cyclic_quotient':True})
    assert substitute(mul({('U','H'):1},X))
    z,J,bar,k=s.symbols('z J bar k');F=(J+k*bar)*(1+z+z**2+z**3)/3;D=lambda A:s.expand(s.diff(A,bar)-k*s.diff(A,J));assert not D(F) and not D(s.diff(F,z,2));nonlinear=J*z**2/2+bar*z**3/2;DN=lambda A:s.expand(s.diff(A,bar)-z*s.diff(A,J));assert not DN(nonlinear) and DN(s.diff(nonlinear,z,2))==2*z
    aa,R,t,mu,ep=s.symbols('aa R t mu ep',positive=True);heat=s.expint(1,aa*R**2/t)/(16*s.pi**2);dlog=s.simplify(t*s.diff(heat,t));assert s.simplify(dlog-s.exp(-aa*R**2/t)/(16*s.pi**2))==0 and s.limit(dlog,t,s.oo)==1/(16*s.pi**2);dim=mu**(2*ep)*R**(-2*ep)/(16*s.pi**2*ep);assert s.limit(ep*dim,ep,0,dir='+')==1/(16*s.pi**2)
    table=a['conditional_unbroken_g4_antighost_prediction'];types4=Counter()
    for r in table:
        names=[n.split('__')[0] for n in r['word']];assert r['g']==4 and all('__' not in n for n in r['word']);anti=[n for n in names if n.startswith('bar')];assert len(anti)==1 and int(anti[0][3:])<12 and not any(n.startswith('ub') for n in names);types4[tuple(sorted(n[0] for n in names))]+=1
    assert dict(types4)=={('A','A','C','b'):676,('A','B','C','b'):3360}
    result={'schema':'ANTIGHOST_RETAINED_BORN_BRIDGE_V1','route':role,'scientific_disposition':'RESTRICTED_BORN_LOG_IDENTITY_DERIVES_UNBROKEN_G4_TABLE_ONLY','qualified_antecedent_result_sha256':digest(p),'actual_linear_kernel_columns':len(kernels),'actual_linear_kernel_entries':sum(map(len,kernels.values())),'actual_kernel_background_coordinates':sorted(dependencies),'physical_indexed_Hessian_terms':34,'physical_AST_field_nodes':count,'physical_field_types':sorted(types),'inherited_polynomial_Hessian_coefficients_not_reexpanded':354321,'ordered_Born_product_checks':words,'all_order_proof':'Product-rule induction;D commutes with fixed field variations because every kernel coefficient is external-only. DH=0,DG=0 imply D(X^n)=0 before any trace;no cyclic quotient needed.','heat_log_coefficient':'1/(16*pi**2)','dimensional_UV_shell_pole_coefficient':'1/(16*pi**2)','negative_controls':{'field_dependent_kernel_DS_zero_but_DH_equals_2z':True,'Green_variation_leaves_uncancelled_ordered_word':True,'wrong_source_pairing_detected_at_all16_orders':True},'derived_unbroken_g4_log_pole':table,'derived_positions':len(table),'derived_AA_AB_BB_counts':[676,3360,0],'direct_new_diagram_measurement':False,'table_integrated':False,'restricted_Born_family_identity_proved':True,'full_continuum_regulated_antighost_measure_identity_proved':False,'arbitrary_IR_projection_or_physical_removal_proved':False,'full_model_QAP_or_renormalized_contact_framework_proved':False,'full_sourcefree_Slavnov_E5_A5_or_authority_change':False,'current_full_Gamma_changed':False,'new_failed_executions':1,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
