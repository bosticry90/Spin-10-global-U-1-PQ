# Preserve the failed noncommutative-power differentiation fixture

The first independent verifier exited1 at the ordered product derivative
assertion. In the installed SymPy,for noncommuting G,H,B,Y and scalar t,

    diff((G*(H+t*(B-Y)))**2,t).subs(t,0)

expands to2*G*H*G*H*G*(B-Y)*H**(-1)*G**(-1),rather than the actual
G*(B-Y)*G*H+G*H*G*(B-Y). The n=2 term-count and product-rule comparison
exposed this unsupported shortcut. No coefficient table was accepted by it.

Keep verify.py,its source copy,the initial validation preparation and full
failed capture unchanged. Corrected verify_v2.py differentiates a product
of DISTINCT noncommuting factor families G_i*(H_i+t*(B_i-Y_i));only AFTER
differentiation does it identify G_i=G,H_i=H,B_i=B,Y_i=Y. Distinct factors
prevent the faulty repeated-power derivative. Every ordered coefficient,
all16 orders,negative controls,actual-model premises,radial residue and4036
rows remain required. The misleading repeated-power derivative is retained
as an explicit nonzero-difference control;no scientific test is weakened.

One corrected independent execution under standing delegation,same120seconds/
8GiB. Freeze all new code/controllers and these failed bytes before launch.
RESULT/DERIVATION remain prospective until the corrected receipt and committed
bytes qualify them. Metadata:one failed primary and one failed verifier in
this increment. Native V2 results and every physical input remain unchanged.
This failure also documents a shared-software limitation for TrackB;an
expression that evaluates to zero after a substitution can still have used
an invalid noncommutative derivative beforehand.
