# Restricted Born/logarithmic-pole antighost identity

Qualification requires completed paired V2 captures,independent receipt and
committed-byte verification. This prospective report alone is not a receipt.

The twelve-direction operation from ALI1 has 60 active source columns and286
kernel entries. All its coefficients are external-background/test-function
dependent only. The actual literal tree residual is zero. The full physical
Hessian's 34 indexed terms contain gauge/scalar fields only,including the
qualified constant scalar aliases. The inherited354321-position polynomial
Hessian fixes sources during field differentiation. These premises imply
that the even antighost/source operation commutes with both field variations
and annihilates the complete fluctuation Hessian as a local bilinear.

The actual reference matrices and chart coefficients have no integrated-field
or source dependence. The specified heat kernel depends on fixed external H
backgrounds. Thus the operation also annihilates the regulated Green function
and separately retained reference determinant. Product-rule induction gives
zero on every finite ordered Born word BEFORE taking a trace. No cyclicity
of a divergent trace,vanishing Jacobian or full Quantum Action Principle is
assumed. DERIVATION.md states this argument and its scope explicitly.

For the quartic dimension-zero target,the heat-word and dimensional UV-shell
radial integrals have the same1/(16*pi^2) logarithmic coefficient. External
field/test differentiation commutes with that local residue extraction.
Therefore the ALI1 table is now DERIVED in this particular ordinary one-loop
Born/log-pole prescription:4036 positions,676AAaC+3360ABaC,noBBaC,with one
of the twelve unbroken antighosts. It is unchanged from the conditional table
and is not a fresh direct diagram measurement or a fitted Ward completion.
No table is integrated and no g4 Ward cancellation is claimed here.

This is a restricted determinant identity,not a complete continuum antighost
measure identity. The thirty-three broken antighost directions have field
dependent kernels;the proof does not extend to them. Arbitrary IR projectors,
physical IR removal,finite contacts,regulated Legendre construction,full QAP
and quantum equivalence remain unproved. The full regulated Q identity still
retains its breaking insertion,source correction and heat divergence.

Primary ordered insertion expansion and replay power recurrence agree.
Independent ordinary-SymPy differentiation must verify all model premises,
noncommuting products,radial residues and4036 unchanged coefficient rows.
Finite-order checks accompany the written product-rule induction;they are
not claimed to prove all orders by themselves. Controls show that a
field-dependent kernel may give DS=0 while DH is nonzero,and that Green
variation or a reversed source sign destroys the ordered-word argument.

The first primary failed because its name check omitted already qualified
complex scalar aliases used in the potential Hessian. V2 explicitly accepts
those aliases with their constant pullback and still rejects unknown names.
The failed code/capture are preserved;no field or action was changed.

Current Gamma remains153378words/hash11940c31cdeffc61c21b074c6d4bb51245860082c1a86d395dedf879f2c87ccb.
Sourcefree36273,38-source theorem,selected prior identities,all seven false
quantum-construction flags,34/39,HB1/C5 block,flavor pause,quartet/scalar
warnings,closed recovery routes and custodyexit2/seven remain unchanged.

TrackB:the actual premises of a restricted operator identity can reduce a
coefficient problem without building another loop compiler or assuming full
QAP. The setup assertion error remains evidence of imperfect model-to-code
translation. Methods share action,charts,source poles,heat/reference scheme,
software and AI author;agreement does not independently validate those inputs.
No fresh byte-identical replay pair or external endorsement is claimed.

Next smallest action:assess the complete local-H predecessor set restricted
to these twelve antighosts,and check the derived g4 table with all measured
g3 companions and boundary currents. Only after exact coefficient/source
mapping and coverage verification should a separately bounded increment
integrate it once. Do not infer the broken sector,all210profile coverage,
full sourcefree Slavnov,E5/A5 or physical GUT viability.
