# Restricted linear antighost equation in the retained Born family V1

Baseline0ab8c6624ec4f9007466d766412002ec651834dc. Question ABB1:does the
qualified twelve-direction linear antighost/source operation annihilate the
actual prescribed one-loop Born functional,without invoking general QAP or
cyclicity of an unregularized trace? ABB2:does its logarithmic coefficient
therefore determine the previously conditional unbroken g4 quartic table?
This is a derivation from the prescribed action/determinant,not a Ward fit.

Freeze/reuse the completed ALI1 receipt and own-role coefficients. Verify that
the literal tree residual and currents are zero,all active kernel coefficients
contain only external H backgrounds/ordinary test jets,all sources are frozen
during the inherited field Hessian,and all34 physical Hessian ASTs contain
only gauge/scalar fields and their independent fluctuation directions. Do not
re-expand354321 qualified polynomial Hessian coefficients or the full Gamma.

Use an even test operation D=delta_bar-sum_J V_J EL_J,with the actual odd test
functions and left pairing of ALI1. Field-independent V makes D commute with
both field variations;D therefore annihilates the full Hessian as an integrated
bilinear. Backgrounds,test functions and fluctuation directions are fixed byD.
Check the actual643 reference matrices and constant coordinate-map coefficients
for excluded antighost/source dependence,and bind the specified cutoff
F=exp[-(-Dbar_H^2)/Lambda^2]. It depends only on fixed external backgrounds,
not on quantum fields or BV sources. Retain Gamma_ref[A]. No claim for an
unspecified field-dependent IR projector or for physical IR removal.

Derive by ordered product differentiation that each finite Born word is
annihilated when DGreen=0 and DH=0. Prove the extension by the product-rule
induction,not by a finite test alone;do not need trace cyclicity at all. Replay
by an independent inverse/power recurrence. Test negative controls with a
field-dependent shift kernel and a reference/Green variation. The former
must exhibit noncommutation with a field Hessian despite DS=0.

Check UV residue correspondence only for the dimension-zero quartic target:
the homogeneous degree-minus-four Euclidean radial term gives the same
1/(16*pi^2) logarithmic coefficient with any positive heat-word weight as
with the existing UV-shell dimensional pole. Pole extraction is linear and
commutes with the external-field/test operation,which carries no UV epsilon
or loop integration variable. Power-sensitive finite-cutoff amplitudes,
finite contact normalizations,nonlocal contributions and physical IR limits
are not being identified. The existing full Q-regulated breaking identity is
unchanged;D is a separate,field-independent operation.

If a premise fails,keep the table conditional and preserve the smallest gap.
If the restricted Born/log-pole bridge holds,report4036 unbroken-antighost
positions as DERIVED within that prescription,not directly measured by a
fresh diagram calculation. Authenticate the old table unchanged,include
all12 directions and its AA/AB/BB classification. Do not integrate it in
this increment or claim coverage of the broken33 directions or210profiles.

Two sequential120-second-after-import/8GiB sampled-private workers;independent
validator120seconds/8GiB,minimum350MiB available commit. Freeze all code,
records,controllers,input hashes before launch. Primary product expansion
versus replay recurrence;separate ordinary-SymPy structural/pole check.
Preserve every failure,no truncation or silent retry. Exact own-role JSON
access only. TrackB tests a theorem's actual premises and residue bridge,
not just another zero. Shared action,E1/E2/reference/heat prescription,
measured source poles,software and AI author limit independence.

No new full QAP,continuum antighost measure,quantum scheme,subtraction
adoption,parameter,benchmark,foundation,policy,authority or remote action.
All seven sealed quantum flags remain false. Full sourcefree Slavnov/E5/A5
and physical viability unqualified. Preserve38source/selectedH/bilinear
proofs,Jacobian,32products,128jets,508programs,quartet/scalarwarnings,
34/39,HB1/C5block,flavorpause,C1_GS,closedroutes,custody2/seven.
