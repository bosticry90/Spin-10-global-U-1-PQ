"""Compare immutable measured inputs with the actual current functional recipe."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,canonical,decode_typed,rows,act,s,g,xi
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def primary(entries):
    out={}
    for word,z in decode_typed(entries).items():
        if len(word)!=2:continue
        jb=[v for v in word if re.fullmatch(r'JB\d+_[0-3]',v[0])];cc=[v for v in word if re.fullmatch(r'C\d+',v[0])]
        if len(jb)!=1 or len(cc)!=1:continue
        assert jb[0][1]==() and cc[0][1]==(int(jb[0][0][-1]),)
        coefficient=s.Poly(z,g,xi).coeff_monomial(g*xi)
        if coefficient:out[word]=s.expand(coefficient)
    return out

def replay(entries):
    out={}
    for row in entries:
        if len(row['word'])!=2:continue
        jb=[];cc=[]
        for encoded in row['word']:
            n,mark,jet=encoded.partition('__')
            if n in {f'JB{i}_{mu}' for i in range(45) for mu in range(4)}:jb.append((n,mark,jet))
            if n in {f'C{i}' for i in range(45)}:cc.append((n,mark,jet))
        if len(jb)!=1 or len(cc)!=1:continue
        assert jb[0][1:]==('','') and cc[0][1]=='__' and cc[0][2]==jb[0][0][-1]
        z=s.expand(s.sympify(row['coefficient'],locals={'g10':g,'xi':xi}))
        z=s.expand(z).coeff(g,1).coeff(xi,1)
        if z:
            word=tuple((encoded.partition('__')[0],tuple(map(int,encoded.partition('__')[2]))) for encoded in row['word'])
            assert word not in out;out[word]=z
    return out

def add(*As):
    out={}
    for A in As:
        for key,z in A.items():out[key]=out.get(key,0)+z
    return {k:s.expand(z) for k,z in out.items() if s.expand(z)!=0}

def manual_ward(P,w,images):
    out={}
    for word,z in P.items():
        for i,(n,jets) in enumerate(word):
            image=images[n]
            for mu in jets:image=w.D(image,mu)
            term=w.mul({word[:i]:s.S.One},image,{word[i+1:]:s.S.One})
            for key,value in term.items():out[key]=out.get(key,0)+z*value
    return canonical(out)

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('LORENTZ_AUDIT_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('LORENTZ_AUDIT_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);method=primary if role=='primary' else replay
    original=read(PKG/f'frozen_a10_e5_source_vertex/{role}.json');measured=method(original['canonical_normalization']['gauge_source_derivative_projection'])
    prior=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_pole/dependent_result.json');recipe=prior['updated_known_recipe'];pair=recipe['prior_source_pair_recipe'];base=pair['prior_recipe']
    baseline=read(PKG/base['base_path']);assembled=method(baseline[base['base_key']])
    additions=[base['add_once'],pair['add_source_pair_once'],recipe['add_actual_source_quartet_once'],read(ROOT/f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json')['new_actual_g4_node']]
    selected=[method(v) for v in additions];current=add(assembled,*selected);delta=add(measured,{k:-z for k,z in current.items()})
    counts=lambda P:dict(sorted(Counter(int(next(n for n,j in word if n.startswith('JB'))[-1]) for word in P).items()))
    assert len(measured)==132 and len(current)==132 and counts(measured)==counts(current)=={0:33,1:33,2:33,3:33}
    assert not any(selected),'LATER_ADDITION_CHANGED_SELECTED_SOURCE_ORDER'
    sign_flipped={word:z*(1 if next(n for n,j in word if n.startswith('JB')).endswith('_0') else -1) for word,z in measured.items()}
    old=read(PKG/f'frozen_a10_e5_measured_functional/{role}_v3.json')
    historical=method(old['sectors']['gauge_source_g1']);historical_delta=add(measured,{k:-z for k,z in historical.items()})
    assert sign_flipped==historical and sign_flipped!=current
    assert not delta and len(historical_delta)==99 and counts(historical_delta)=={1:33,2:33,3:33}
    assert not add(historical,historical_delta,{k:-z for k,z in measured.items()})
    assert add(historical,{k:2*z for k,z in historical_delta.items()},{k:-z for k,z in measured.items()})
    temporal={word:z for word,z in measured.items() if next(n for n,j in word if n.startswith('JB')).endswith('_0')}
    assert len(temporal)==33 and not add(temporal,{word:-current[word] for word in temporal})
    missing={word:z for word,z in measured.items() if word not in temporal};assert len(missing)==99
    w=alphabet();P={word:g*xi*z for word,z in delta.items()};e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');tb=e3['operators']['Tb_geometric_and_transported']
    names={n for word in P for n,j in word};images={n:decode_typed(tb[n]) for n in names}
    ward=(act(P,w,images,role,0) if role=='primary' else manual_ward(P,w,images));ward=canonical(ward)
    dropped={n:({} if n.startswith('JB') else A) for n,A in images.items()}
    missing_source=canonical(act(P,w,dropped,role,0) if role=='primary' else manual_ward(P,w,dropped))
    hist=read(ROOT/f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json')
    assert hist['updated_known_Ward']==[] and hist['known_partial_functional_background_Ward_zero'] and hist['updated_known_terms']==92236
    result={'schema':'GAUGE_SOURCE_LORENTZ_PROVENANCE_AUDIT_V2','route':role,'original_pole_rows':rows(measured),'assembled_current_pole_rows':rows(current),'difference_rows':rows(delta),'historical_assembly_rows':rows(historical),'historical_difference_rows':rows(historical_delta),
      'original_count':len(measured),'current_count':len(current),'different_coefficients':len(delta),'difference_by_mu':counts(delta),'later_addition_target_counts':[len(v) for v in selected],
      'base_path':base['base_path'],'base_key':base['base_key'],'opposite_spatial_metric_reproduces_only_historical_assembly':True,'current_recipe_preserves_original_input':not bool(delta),'historical_difference_count':len(historical_delta),'temporal_only_comparison_misses_historical_discrepancy':True,
      'double_correction_rejected':True,'V1_current_discrepancy_hypothesis_refuted':True,'known_original_terms':92236,'known_original_Ward_zero_preserved':True,
      'diagnostic_replacement_Ward':rows(ward),'diagnostic_replacement_Ward_terms':len(ward),'diagnostic_replacement_Ward_zero':not bool(ward),
      'source_variation_omission_changes_diagnostic':missing_source!=ward,'diagnostic_replacement_adopted':False,'original_physics_or_full_functional_replayed':False,
      'new_loop_or_actual_g2_color_pole_computed':False,'full_E5_A5_or_physical_inconsistency_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
