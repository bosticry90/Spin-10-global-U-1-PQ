# The suspected current error was already repaired

V1 failed at its assertion that the current recipe has the old spatial-sign
error. Its hypothesis was wrong: the current recipe agrees with the original
qualified source pole. No result was exported. Source/preparation/native
capture are preserved as a failed investigation, not relabeled success.

The historical discrepancy was already diagnosed and repaired at handoffV32
and docs/A10_E5_GHOST_SOURCE_CURRENT.md. The old MF V3 executable remains
historical evidence; reusing it as the current assembly was an analyst error.
The current recipe starts from the subsequently corrected functional.

V2 makes the complete three-way check explicit: original paired pole,
historical MF V3 assembly and current recipe. Require zero original/current
difference and99 historical spatial differences, with negative controls. This
preserves, rather than weakens, the substantive question of input fidelity.
No unknown coefficient or physical input changes. A zero current difference
has zero diagnostic Ward effect and an insensitive source-omission control;
no old Ward calculation need be repeated. Two120-second/8GiB workers only.

Track B limitation: this detour could have been avoided by searching existing
current-result pointers before treating a familiar error as a new finding.
Record recovery/priority failure alongside the useful tensor-method controls.
