# Current source-input fidelity confirmed; historical error not rediscovered

Both audit routes confirm that all132 gauge-source/ghost first-derivative
coefficients in the current92236-term recipe agree with the original qualified
g*xi pole. There are33 nonzero coefficients for each of the four polarizations.
None of the four later additions changes that coupling/type/jet scope.
No current source correction or new pole is required by this comparison.

The historical MF V3 assembly has99 spatial-sign differences. The exact
sign-flip control reproduces that old artifact, while a temporal-only
comparison misses every difference. The original input and current recipe
already have the same index convention. The zero current difference has zero
Ward effect; omitting source variation from this empty diagnostic is correctly
insensitive. No current functional was replaced or adopted.

This was already resolved at
[handoff V32](../../docs/RESEARCH_EXECUTION_HANDOFF_V32.md) and the
[current ghost-source pointer](../../docs/A10_E5_GHOST_SOURCE_CURRENT.md).
The original MF V3 executable remains historical evidence. Reusing its
assembly routine as the current scientific recipe would reintroduce a known
error; use the subsequent corrected recipe instead.

Track B: the initial audit incorrectly asserted that the current recipe still
contained that old error. Its native failure is preserved. The
[V2 disposition](DISPOSITION_AND_CONTINUATION_V2.md) records the refuted
hypothesis and changes to a complete three-way comparison. Corrected primary
and replay use different parsers; both authenticate the shared historical
recipe. They completed in7.629 and1.750 seconds after imports, respectively.
This detour could have been avoided by consulting the existing current pointer
earlier. It supplies evidence of a state-recovery/prioritization failure, not
a new physical discovery or independent reproduction of the original loop.

The existing background Ward zero remains valid for its saved partial
functional. No Ward restoration, full source closure or E5/A5 promotion follows
from this input-fidelity check. Authorityv113/34of39,HB1/C5 block,C1_GS null,
flavor pause,prior failures,scalar warning and custodyexit2/seven unchanged.
Education remains voluntary, concurrent and nonblocking. Shared data, symbolic
software and AI authorship limit independence.

Next return to the qualified general-momentum g2 unit factors and freeze the
actual45² color contraction. The measured g*xi input audited here is distinct.
Preserve both the original source convention and the corrected current recipe;
do not rerun or repair the already resolved historical error.
