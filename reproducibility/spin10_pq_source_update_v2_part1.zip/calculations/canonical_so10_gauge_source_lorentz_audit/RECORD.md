# Gauge-source Lorentz provenance audit V1

Baseline d4bca22b3e2be559af72bda046752a5521cac5cf. During preparation of
the ordinary g2 color contraction, a discrepancy was found between the
original qualified g*xi JB*partial C record and the later assembled functional.
They appear to differ by the spatial metric signs. This audit takes priority
over adding the g2 node: it tests preservation of an existing measured input.

Claim: compare every retained first-derivative gauge-source coefficient from
the original paired source-vertex results with the exact current92236-term
recipe's corresponding support. Trace each later addition and detect any
compensating change. No old physics integration or unknown coefficient fit.
Use canonical rows as stored; source JB is the dual of B, with its original
index convention. Do not insert a metric factor merely because it looks
Lorentz invariant. Check the actual source/GF definitions when interpreting
the outcome. Equal temporal components alone cannot establish all4 copies.

Primary decodes typed jet words and subtracts their polynomial coefficients.
Replay independently classifies the raw serialized names/jets and reduces
their coupling coefficients before assembling the comparison. Read own
original role only; the common historical recipe is disclosed. Compare all
rows, all4 polarization counts, later-addition supports and any differences.
Opposite spatial sign, omitted polarization and doubled corrective-difference
controls must distinguish a real discrepancy from an empty comparison.

If a difference exists, calculate only its local background Ward variation
from the actual E3 source/ghost transformations. Primary uses the existing
even derivation; replay expands the graded word product and differentiated
field images directly. This is a diagnostic replacement of that input, not
adoption of a corrected functional or inference that the original expression
is a complete physical answer. Record whether its Ward effect is zero or
nonzero. Preserve the historical92236-functional's exact zero Ward result as
a result about its original bytes, distinct from fidelity to measured inputs.

Two sequential read-only workers,120 seconds after imports, sampled8GiB and
>=350MiB available commit. Freeze source/controller and input bytes first;
preserve captures and failures. Peer results and undeclared JSON denied.
No source, frozen evidence, physical input, benchmark, project_state or
historical classification may be edited. Any repair requires a new qualified
version with the full affected acceptance obligations, not rebinding old bytes.

Ceiling: provenance/assembly discrepancy and its exact local Ward consequence.
Not a recalculated loop, accepted physical correction, anomaly, full Slavnov
restoration or E5/A5. HB1/C5 blocked,C1_GS uncalculated,flavor paused; v113/
34of39 unchanged. Earlier failures, scalar warning,custodyexit2/seven remain.
Track B must disclose shared assembly assumptions that paired AI checks may
have missed; Track C remains voluntary, concurrent and nonblocking. No new
benchmark platform, external action or remote push.
