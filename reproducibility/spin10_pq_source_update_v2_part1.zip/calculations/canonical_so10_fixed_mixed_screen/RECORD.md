# Authorized fixed z4/zK screen V1 — prospective execution contract

The director selected “Authorize bounded z4/zK screening” for the committed
proposal in docs/FIXED_MIXED_SCATTERING_SCOPE_PROPOSAL_V1.md. Base HEAD is
b9d3259c10fc95fd4cc7ef74cb7cbecdf999929f. Actual preflight is clean, no
matching A10/M08 workers, state v113 and formal authority 34/39.

Question: do the frozen z4/zK quartics supply an unavoidable obstruction
before another real-eta scalar feasibility investigation? Keep the eight
formal quartics, 0<eta<=pi*sqrt(7/930), actual action/kinetics/PQ/VEV ratios
and all other inputs unchanged. No point, family, eta value or benchmark
is selected. Prior fixed eta=3/10 failure remains final in its scope.

Primary: construct the complete T(Sigma,Sigma) coefficient map from all
8001 unordered pairs of the 126 canonical complex self-dual coordinates,
including diagonals and measured zeros. Use input-pair polarization of the
literal four-index contraction. Construct all 55 complex-vector coordinate
pairs and project onto the real symmetric-traceless Phi basis with exact
metric. Retain Hermitian completion and canonical identical-pair weights.
Calculate the direct Gram matrices and both crossed-map Gram matrices.
The common Phi S* output requires horizontal concatenation of z4 and
conjugate zK maps, not interference between orthogonal incoming sectors.
Audit all three pair partitions, conjugates and adjoints. No full scalar
scattering compiler or new spectrum. Compare exact block norms or rigorous
bounds to the stipulated asymptotic tree a0=M/(16*pi), norm<=1/2 screen.

Independent: K-first bilinear contractions, independent trace/covariance
and canonical real-to-complex Fock toy transformations. Compare every pair
norm, all relevant trace/Gram constants and complex/identical factors.
Use literal symmetric-traceless completeness and inherited 54/126
irreducibility only with covariance justified. Shared action, group premises,
some arithmetic, Python/SymPy and analyst remain limitations, not external
scientific endorsement. These are selected z4+zK operators, not the full
tree operator with all diagonal or other offdiagonal interactions.

An unprojected upper bound on the complete selected Hermitian operator
bounds every physical orthogonal compression and cannot produce a false
physical exclusion. If it is below 1/2, report only absence of an obstruction
from that selected operator. An unprojected lower bound above 1/2 is NOT
physical exclusion: then require a justified actual non-Goldstone projection
within the same budget, otherwise report a qualification gap/inconclusive
result. Do not identify potential orbit zeros with massive particles.

Verify complete-action field content for every selected map, retaining the
eta links to other pair sectors and zero zD. If another term shares a map,
combine it before a claim. A shadow-vertex negative control must invalidate
a false uniqueness inference. Gauge exchange must be absent by actual
species currents and the singlet S action at each of the three pairings;
do not discard gauge terms by a preferred answer. Scalar cubic exchange is
omitted only in the inherited fixed-coupling hard contact limit, with fixed
masses/IR regulator before massless limits. No finite-energy, RG, cutoff,
exact quantum unitarity or new physical prescription conclusion.

Transport the two existing mixed-field witnesses using their complete
29-monomial ledgers, retaining 2 Re(cI), and verify old eta=3/10 recovery and
eta=0 reference. Derive their necessary affine conditions, not the unchanged
old s floor. Reuse continuous-slice monomials if within the same budget and
preserve its x>0, branch, boundary and flat-direction qualifications. No new
field/parameter search or claim reduced eta restores global stability.

Controls: wrong kinetic rescaling, missing h.c./offdiagonal Phi entries,
wrong identical-pair or crossing factors, erased common-output branch,
false extra-vertex uniqueness, wrong source phase, and inherited failure
misclassification. Code/data/report UTF-8 and syntax checks precede launch.

TWO sequential native roles only; each 120 seconds after imports, sampled
private allocation at most 8 GiB and directly observed prelaunch available
commit at least 350 MiB. No automatic retry. First unresolved mathematical
discrepancy stops qualification; exceeding limits is incomplete and never
silent truncation. Freeze hashes, read-only workers, complete captures,
independent receipt and raw staged/committed byte checks. Engineering
syntax/byte checks are not new physics runs. No fresh byte-identical pair.

Output exact selected bound and its scope, combined/crossed inventory,
transported stability conditions, actual evidence and next smallest action.
If another fixed interaction excludes the domain, do not free it silently;
return the direction to the director. A selected bound below 1/2 does not
establish joint mass/Higgs/stability feasibility, a benchmark or full
scattering. Preserve project_state.json, sealed README, 34/39 authority,
custody exit 2/seven, prior successes/failures, quartet failure, E5/A5 gaps,
HB1/C5 blocks and flavor pause. No loops/matching, new compiler, branch,
worktree, remote action or outreach. Equal science/AI objectives; education
voluntary/nonblocking. Broad Spin(10) investigation remains incomplete.
