# Selected fixed z4/zK operator: no tree-screen obstruction

The complete Hermitian contact operator made from the frozen z4 and zK
quartics, including their shared-output block, crossed channels, conjugates
and adjoints, has canonical partial-wave norm

```
||a0[z4+zK]|| = sqrt(4849913042327/10000000000000)/(16*pi)
              = 0.0138546998175904... < 1/2.
```

This is a result for the SELECTED two-interaction operator, not full scalar
scattering, joint scalar feasibility or a new benchmark. It supplies an upper
bound on its non-Goldstone orthogonal compressions; no unphysical lower bound
is used for exclusion. Qualification requires the actual
[independent receipt](validation_receipt.json), resource captures and raw Git
checks under the [authorized contract](RECORD.md).

In plain language: these two fixed interactions do not reproduce the earlier
eta-only exclusion by themselves. We must still test their combination with
the rest of the potential. The eta-dependent stability conditions have also
been recovered, and they must be used with the mass/Higgs equations rather
than assuming that a smaller eta repairs the theory.

## Complete selected maps and normalization

The source is the unchanged [parent action](../canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md)
with the declared kinetic metrics. In physical canonical tensor conventions

```
z4=-26467/1000000-640369*i/20000000,
zK=3/100,
Vselected=z4*(Phi:T)*S + zK*(Phi_ij*phi_i*phi_j)*S* + h.c.
```

All126 canonical complex Sigma basis forms have N=2 and kinetic |dz|^2.
The54 real Phi tensors have Frobenius-orthonormal kinetic normalization;
the implementation retains an explicit unnormalized basis with metric.
Complex phi and S have their standard kinetic normalization. Actual raw
rescalings b^2*sS for z4 and sS for zK are undone, not silently reused as
physical interaction values.

The primary evaluates every one of8001 unordered Sigma pairs and55 vector
pairs, including identical and zero channels. The exact pair ledgers are in
[primary_result.json](primary_result.json). Identical incoming pairs carry
sqrt(2) times their polynomial coefficient; distinct pairs carry that
coefficient. T is checked symmetric and traceless for every pair.

Let A4 and AK be the direct pair maps with coefficients z4,zK stripped.
Their squared Frobenius traces and output Grams are

| Map | Pair count | Squared Frobenius trace | Canonical output Gram |
| --- | ---: | ---: | --- |
| Sigma Sigma to Phi S* | 8001 | 15120 | A4*A4^H=280 I54 |
| phi* phi* to Phi S* | 55 | 108 | AK*AK^H=2 I54 |

The crossed maps have output Grams240 I126 and(108/5) I10, respectively.
The primary checks every entry of both direct and both crossed Gram matrices,
including zeros. The independent K-first contraction checks all8056 pair
norm rows; covariance and the established irreducibility fix the same Gram
constants from their traces. Symmetric-traceless completeness independently
checks the vector result. These group/covariance premises are disclosed
dependencies, not assumptions established by a few samples.

The direct z4 and zK maps have the SAME Phi S* output and orthogonal incoming
species sectors. Their combined horizontal map therefore has Gram

```
(280*|z4|^2+2*|zK|^2) I54.
```

Their crossed channels live in different species pair spaces. All pair
partitions and conjugates give the three squared singular-value candidates

```
280*|z4|^2+2*|zK|^2 = 4849913042327/10000000000000,
240*|z4|^2           = 2070819875283/5000000000000,
(108/5)*|zK|^2      = 243/12500.
```

The first is strictly largest. All54 output singular values in the shared
channel have that squared value. No dense328-field scattering compiler is
needed. The full selected real operator has squared Frobenius norm
12*(15120*|z4|^2+108*|zK|^2), an additional crossing/multiplicity check.
An exact rational bound gives its largest squared singular value below1;
pi>3 then gives ||a0||<1/48<1/2. The reported decimal is illustrative;
the accepted sign does not depend on rounding.

Canonical real-to-complex Fock transformations of identical, distinct and
shared-output toy vertices verify all factors. A control has two opposite
amplitudes in DIFFERENT incoming columns: treating them as scalar amplitudes
that cancel would falsely erase a nonzero row norm. Missing h.c., wrong
identical factors and wrong Phi normalization are also controlled.

## Complete-action and physical interpretation boundary

The action's22 quartic monomials are inventoried by field content. Only z4
has Phi Sigma^2 S content and only zK has Phi phi^2 S content. This justifies
the selected pair-map inventory. Eta connects some of their incoming sectors
to other outputs; it is not absent from the full theory and cannot be fitted
to cancel an orthogonal selected output. Other portals and diagonal blocks
remain outside this two-interaction operator. A shadow same-content vertex
control defeats a false uniqueness inference.

Every selected external field pattern contains the gauge-singlet S. All45
actual Lie-generator actions on S vanish, while a Phi action is nonzero as
a control. Each of the three gauge-exchange pairings therefore contains a
zero S current. Scalar cubic exchange is subleading only in the stipulated
fixed-coupling hard limit with masses/IR regulator held fixed before massless
limits. Use [Goodsell–Staub, equations2–5](https://arxiv.org/pdf/1805.07306) for
the general normalization; their software examples do not supply this model's
colored group calculation. No finite-energy/RG/cutoff or exact quantum
unitarity result is established.

The selected operator was bounded on the full canonical scalar pair space.
Any metric-orthogonal non-Goldstone compression has no larger norm. This
upper-bound argument includes mixed Phi/Sigma gauge orbits without assigning
them ordinary massive propagators or importing the Sigma-only projection to
Phi. It would NOT justify a physical exclusion from an unprojected lower
bound. No such exclusion is made. Adding other interactions can increase
the full operator norm even though this selected part is small.

## Existing mixed-field witnesses with variable eta

Reuse the complete29-monomial ledgers, not new searches or fresh tensor
reconstructions. Define x=8*lambdaSigma1,s=lambdaSigma2+lambdaSigma3,
z=s+4*lambdaSigma4 and D as in the earlier comparison. The two known actual
field directions require the following quartics to be nonnegative:

```
W1=(361/2)*x+933*s+33*z+(35/4)*D
   +497030229/2000000-3960*eta >=0,

W2=(8281/162)*x+(1199/3)*s+33*z+(35/4)*D
   +2821340701/28125000-(4384/3)*eta >=0.
```

These follow from Vw(eta)=Vw(3/10)+2*(eta-3/10)*Re(E.phi) with the qualified
values-1980 and-2192/3. Exact eta=3/10 recovery and eta=0 references are
checked. Neither reference is an adopted model input.

Using the same contact envelope and rational x bound as the old uniform
obstruction gives the necessary inequality

```
(1325/3)*s-9*z > delta(eta),
delta(eta)=(4384/3)*eta-102569870468443/234646875000.
```

At eta=3/10 this reproduces the old positive delta exactly. In the new range
eta<=pi*sqrt(7/930)<11/40, delta(eta) is negative. Consequently this particular
envelope no longer supplies the old uniform positive numerical floor on s.
That is a changed necessary condition, not evidence that s->0 is viable,
that either ray is positive, or that all other stability constraints pass.
The full W1,W2 and continuous-slice conditions still need joint evaluation.

## Transported continuous-slice condition

For the existing real slice Phi=S=0,Sigma=a*vacuum+b*doublet6,
phi6=-c,phi7=-i*c, the homogeneous quartic is

```
V4=128*x*a^4
  +a^2*((48*x+960*s)*b^2+h*c^2-768*eta*b*c)
  +(9*x/2-27*s+33*z+35*D/4)*b^4
  +k*b^2*c^2-24*eta*b^3*c+g*c^4,
h=199571/1562500,k=-9356043/50000000,g=2/5.
```

For x>0 and eta>0 the worst real signs still have b,c>=0. At b>0 set
r=c/b,y=a^2/b^2>=0. The exact branch condition is

```
A=h*r^2-768*eta*r+48*x+960*s,
B=g*r^4+k*r^2-24*eta*r+9*x/2-27*s+33*z+35*D/4,
for every r>=0:
 B>=0 if A>=0; 512*x*B-A^2>=0 if A<0.
```

The b=0 boundary remains positive for a nonzero(a,c). A zero quartic along
a flat direction is not full-potential BFB when lower-degree terms remain.
The previous finite-candidate D-required construction retains the same
branch structure; its active stationary cubic has nonzero r^2 coefficient
-2304*h*eta throughout eta>0. This covers the declared real field slice,
not arbitrary complex mixtures or full328 stability. No remaining parameter
domain was searched or proved feasible.

## Scientific decision and validation limits

The frozen z4/zK pair does not independently close the variable-eta recovery
route through this selected contact operator. No other coupling is freed.
The next smallest scientific question is the remaining fixed portal/self
scattering contribution and its overlap with variable Sigma/Phi blocks,
followed by joint use of the now explicit mass/Higgs/mixed-stability equations.
The ten other fixed quartics inventory is not a full scattering certificate;
z4/zK are only two of those fixed terms. Do not start a numerical candidate
search or quantum matching from this result. Any next execution needs its
bounded scope; no further role is granted by this completed two-role screen.

One primary plus one independent verifier, each120seconds/8GiB and direct
350MiB launch observation, with source/input hashes and complete captures.
Inherited witnesses and representation facts are not new replays. No fresh
byte-identical pair or independent expert validation is claimed. Shared
action,kinetics/representation assumptions,Python/SymPy,some arithmetic and
analyst remain common-error risks. Track B demonstrates combined-channel
reasoning and honest distinction between a selected bound and full viability.
It does not demonstrate general autonomous scientific reliability.

Preserve all earlier failures and bounded successes, fixed eta=3/10 exclusion,
qualified eta formulas, project_state.json and sealed README, authority34/39,
custody exit2/seven references, quartet failure,E5/A5 gaps,HB1/C5 boundaries,
C1_GS gap and flavor pause. Equal science/AI objectives and voluntary
nonblocking education persist. Broad investigation completion remains unproved.
