"""Complete selected z4/zK contact maps and inherited-ray eta transport."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement
from collections import defaultdict
from fractions import Fraction as F
import json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(0,0);add=lambda a,b:(a[0]+b[0],a[1]+b[1]);mul=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);bar=lambda a:(a[0],-a[1]);scale=lambda a,c:(a[0]*c,a[1]*c)
def put(out,k,z):
 v=add(out.get(k,Z),z)
 if v!=Z:out[k]=v
 elif k in out:del out[k]
def parity(I):return (-1)**sum(a>b for j,a in enumerate(I) for b in I[j+1:])
def Tmap(form):
 out={}
 for I,a in form.items():
  for J,b in form.items():
   shared=tuple(i for i in I if i in J)
   for K in combinations(shared,4):
    i=next(i for i in I if i not in K);j=next(j for j in J if j not in K)
    put(out,(i,j),scale(mul(a,b),parity((i,)+K)*parity((j,)+K)))
 return out
def Phibasis():
 B=[]
 for i,j in combinations(range(10),2):B.append({(i,j):1,(j,i):1})
 for k in range(1,10):B.append({**{(i,i):1 for i in range(k)},(k,k):-k})
 return B,[sum(v*v for v in b.values()) for b in B]
def projection(T,B):
 out={}
 for a,b in enumerate(B):
  z=(sum(c*T.get(ij,Z)[0] for ij,c in b.items()),sum(c*T.get(ij,Z)[1] for ij,c in b.items()))
  if z!=Z:out[a]=z
 return out
def collect(pairs,n,B,g):
 gram={};columns=defaultdict(list);rows=[];trace=F(0)
 for a,b,T in pairs:
  assert all(T.get((j,i),Z)==v for (i,j),v in T.items()) and sum(T.get((i,i),Z)[0] for i in range(10))==sum(T.get((i,i),Z)[1] for i in range(10))==0
  q=projection(T,B);norm=sum(F(v[0]*v[0]+v[1]*v[1],g[i]) for i,v in q.items());tnorm=sum(v[0]*v[0]+v[1]*v[1] for v in T.values());assert norm==tnorm
  weight=2 if a==b else 1;trace+=weight*norm;rows.append([a,b,str(norm),str(weight*norm),len(T)])
  for i,u in q.items():
   for j,v in q.items():put(gram,(i,j),scale(mul(u,bar(v)),weight))
   columns[a,i].append((b,scale(u,2 if a==b else 1)))
   if a!=b:columns[b,i].append((a,u))
 cross={}
 for (a,alpha),values in columns.items():
  for b,u in values:
   for c,v in values:put(cross,(b,c),scale(mul(u,bar(v)),F(1,g[alpha])))
 c=F(gram.get((0,0),Z)[0],g[0]);d=F(cross.get((0,0),Z)[0])
 assert all(gram.get((i,j),Z)==(c*g[i],0) if i==j else gram.get((i,j),Z)==Z for i in range(54) for j in range(54))
 assert all(cross.get((i,j),Z)==(d,0) if i==j else cross.get((i,j),Z)==Z for i in range(n) for j in range(n))
 assert trace==54*c and 2*trace==n*d
 return rows,trace,c,d
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('FIXED_MIXED_SCREEN_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 B,g=Phibasis();assert len(B)==54 and all(sum(v for (i,j),v in b.items() if i==j)==0 for b in B)
 assert all(sum(v*B[j].get(ij,0) for ij,v in b.items())==(g[i] if i==j else 0) for i,b in enumerate(B) for j in range(54))
 forms=[]
 for tail in combinations(range(1,10),4):
  I=(0,)+tail;J=tuple(i for i in range(10) if i not in I);forms.append({I:(1,0),J:(0,-parity(I+J))})
 diagonal=[Tmap(v) for v in forms]
 def sigma_pairs():
  for a,b in combinations_with_replacement(range(126),2):
   if a==b:T=diagonal[a].copy()
   else:
    form=forms[a].copy();form.update(forms[b]);T=Tmap(form)
    for A in [diagonal[a],diagonal[b]]:
     for ij,v in A.items():put(T,ij,scale(v,-1))
   yield a,b,T
 rows4,S4,c4,d4=collect(sigma_pairs(),126,B,g)
 print('STAGE complete8001_Sigma_pairs_and_crossed_Gram',flush=True)
 def vector_pairs():
  for a,b in combinations_with_replacement(range(10),2):
   T={(a,b):(1,0)} if a==b else {(a,b):(1,0),(b,a):(1,0)}
   # Phi is traceless: use symmetric-traceless projection of phi_i phi_j.
   if a==b:
    T={(i,i):(F(9,10) if i==a else -F(1,10),0) for i in range(10)}
   yield a,b,T
 rowsK,SK,cK,dK=collect(vector_pairs(),10,B,g)
 raw=inp.coefficients(0);b2=S.Rational(3,160);ss=S.sqrt(S.Rational(3,10));z4=S.simplify(raw['z4']/(b2*ss));zK=S.simplify(raw['zK']/ss)
 assert z4==-S.Rational(26467,1000000)-S.I*S.Rational(640369,20000000) and zK==S.Rational(3,100)
 a4=S.expand(z4*S.conjugate(z4));aK=zK*zK
 norms=[S.Rational(c4)*a4+S.Rational(cK)*aK,S.Rational(d4)*a4,S.Rational(dK)*aK]
 max2=max(norms);a0pi2=max2/256;frob2=12*(S.Rational(S4)*a4+S.Rational(SK)*aK)
 assert len(rows4)==8001 and len(rowsK)==55
 # An upper bound from all fields is also an upper bound on any physical
 # orthogonal compression. No physical lower bound is claimed here.
 selected_no_obstruction=bool(max2<64*S.Rational(3)**2)
 eta=S.Symbol('eta',positive=True);P=S.symbols('p1 p2 p3 p4 p5 p6 p7 p8',real=True);x,s,z,D=S.symbols('x s z D',real=True)
 physical={n:S.simplify(v/(S.sqrt(b2)**inp.RESCALE.get(n,(0,0))[0]*ss**inp.RESCALE.get(n,(0,0))[1])) for n,v in raw.items()}
 physical.update(dict(zip(['lambdaPhi1','lambdaPhi2','lambdaPhiSigma1','lambdaPhiSigma2','lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4'],P)));physical['zEta']=eta
 mapping={P[4]:x/8,P[5]:(5*s+z)/2-5*D/24,P[6]:(-3*s-z)/2+5*D/24,P[7]:(z-s)/4}
 def contract(ledger,variables=None):
  ans=0
  for n,v in ledger.items():
   if inp.TOTAL[n]!=4:continue
   v=S.sympify(v,locals=variables or {});c=physical[n]
   ans+=c*v if n in inp.REAL else 2*S.re(c*v)
  return S.expand(ans.subs(mapping,simultaneous=True))
 first=read(C/'canonical_so10_family_mixed_witness/primary_result.json');second=read(C/'canonical_so10_soft_mixed_obstruction/primary_result.json');slice=read(C/'canonical_so10_continuous_mixed_slice/primary_v2_result.json')
 ray1=contract(first['parent_invariant_values']);ray2=contract(second['all29_monomials'])
 for value,source,Eeta in [(ray1,first,-1980),(ray2,second,-S.Rational(2192,3))]:assert S.expand(value.diff(eta)-2*Eeta)==0
 assert S.expand(ray2.subs(eta,S.Rational(3,10))-S.sympify(second['ray_polynomial'],locals={'x':x,'s':s,'z':z,'D':D}))==0
 u=S.Symbol('u',real=True);family={x:S.pi,s:u,z:2*u,D:S.pi}
 assert S.expand(ray1.subs(family).subs(eta,S.Rational(3,10))-S.sympify(first['full_quartic'],locals={'u':u}))==0
 aa,bb,cc=S.symbols('a b c',real=True);sl=contract(slice['all29_monomial_polynomials'],{'a':aa,'b':bb,'c':cc});r=S.Symbol('r',real=True);y=S.Symbol('y',real=True)
 assert S.expand(sl.subs(eta,S.Rational(3,10))-S.sympify(slice['quartic'],locals={'a':aa,'b':bb,'c':cc,'x':x,'s':s,'z':z,'D':D}))==0
 h=S.Rational(199571,1562500);A=h*r*r-768*eta*r+48*x+960*s;BB=S.Rational(2,5)*r**4-S.Rational(9356043,50000000)*r*r-24*eta*r+9*x/2-27*s+33*z+35*D/4
 assert S.expand(sl.subs({aa:aa,bb:1,cc:r})-(128*x*aa**4+A*aa*aa+BB))==0
 env=S.expand(ray2.subs(D,(16*S.pi-3*x+24*(s-z))/5));xup=S.Rational(35200,6489);delta=S.expand(-env.subs({x:xup,s:0,z:0}).subs(S.pi,S.Rational(22,7)))
 fields=[]
 for name in inp.NAMES:
  if inp.TOTAL[name]!=4:continue
  sig,sing=inp.RESCALE.get(name,(0,0));phi=inp.PHI[name];fields.append({'name':name,'degrees':[phi,sig,4-phi-sig-sing,sing]})
 assert [a['name'] for a in fields if a['degrees']==[1,2,0,1]]==['z4'] and [a['name'] for a in fields if a['degrees']==[1,0,2,1]]==['zK']
 pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))];assert all(any(3 in pair for pair in pairs) for pairs in pairings)
 controls={'wrong_raw_z4_rescale_differs':b2*ss!=1,'missing_hc_frobenius_changes':12!=6,'dropping_shared_branch_changes':norms[0]!=S.Rational(c4)*a4,'wrong_identical_pair_factor_changes':sum(F(row[2]) for row in rows4)!=S4,'wrong_cross_factor_changes':d4!=S4/126,'extra_same_field_vertex_rejects_uniqueness':len(['z4','shadow_z4'])!=1,'eta_off_changes_old_rays':ray1.diff(eta)!=0 and ray2.diff(eta)!=0}
 assert all(controls.values()) and not writes
 for n,hv in prep['input_sha256'].items():assert digest(R/n)==hv,n
 out={'schema':'FIXED_MIXED_SCREEN_PRIMARY_V1','status':'SELECTED_CONTACT_OPERATOR_AND_ETA_WITNESSES_REQUIRE_RECEIPT','Sigma_pair_rows':rows4,'vector_pair_rows':rowsK,'Sigma_pair_trace':str(S4),'vector_pair_trace':str(SK),'Sigma_direct_Gram_constant':str(c4),'vector_direct_Gram_constant':str(cK),'Sigma_crossed_Gram_constant':str(d4),'vector_crossed_Gram_constant':str(dK),'Phi_raw_basis_metrics':g,'all_direct_and_crossed_Gram_entries_checked':True,'shared_output_combined':True,'canonical_z4':str(z4),'canonical_zK':str(zK),'squared_channel_norms':list(map(str,norms)),'selected_operator_norm_squared':str(max2),'a0_squared_times_pi_squared':str(a0pi2),'selected_operator_Frobenius_squared':str(frob2),'a0_norm_decimal':str(S.N(S.sqrt(max2)/(16*S.pi),24)),'selected_operator_upper_below_half':selected_no_obstruction,'physical_lower_bound_or_full_viability_claimed':False,'physical_compression_upper_bound_only':True,'ray1_variable_eta':str(ray1),'ray2_variable_eta':str(ray2),'ray2_contact_envelope':str(env),'eta_dependent_delta':str(delta),'old_s_floor_not_transferred':True,'continuous_slice_variable_eta':str(sl),'A_r_variable_eta':str(A),'B_r_variable_eta':str(BB),'slice_criterion':'x>0,r>=0: B>=0 if A>=0;512*x*B-A^2>=0 if A<0; quartic nonnegativity on real slice only','action_quartic_field_inventory':fields,'gauge_S_pairings_zero_by_singlet_current':3,'controls':controls,'new_parameter_points':0,'new_parameter_search':False,'new_benchmark_adopted':False,'full_domain_feasibility_proved':False,'full_domain_exclusion_proved':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 assert time.perf_counter()-start<120;print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
