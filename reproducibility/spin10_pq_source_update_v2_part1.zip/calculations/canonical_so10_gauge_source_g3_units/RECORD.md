# Ordinary g3 gauge-source/vector unit factors V1

Baseline64b5656e2ab10ed6b2dd0d4b24dd88ee7c83b800. The qualified frontier
admits SB*D,SB*F*F,SB*F*U for externalA_H/B and SB*F*G3 for B only. Their
ordinary g3 coefficients remain uncomputed. The affine identity constrains
only an A_H+B_H sum and must not supply these unit values.

Question: establish complete signed ultraviolet unit kernels and Lorentz
factors for these bubbles/triangles before action color contraction. Reuse
the existing exact polynomial/Grassmann machinery and full reference from
a10_e5_gauge_source_partner_control.py; its previously calculated g2*xi
amplitudes are not imported. No group tensor, old pole, desired completion,
known Gamma or peer JSON may be interpreted by the unit workers.

All backgrounds: Je odd(d2,gh-1),Ce odd(d1,gh+1),Be even(d1,gh0).
Quantum BX/BY vectors, LX/LY auxiliaries and two oriented ghost pairs
CA/aA,CB/aB retain both graded inverse directions. Q=k eta k,t=1/Q;
G_BB=-eta*t+(1-W)kk*t²,G_BL=+i*k*t,G_LB=-i*k*t,G_LL=0;
G_Ca=t,G_aC=-t. Widths W_X/W_Y are symbolic and not physical gauge values.
All vertices are even dimension4,gh0; Je carries no extra spatial metric.

Freeze these ordered unit vertices for source polarization nu and Be component
mu, with dot derivatives summed over all four rho and ETA_rhorho:

- D: S=Je*BX_nu*CA; D=ETA_mumu*Be*aA*BX_mu*Ce.
- FF: S=Je*BX_nu*CA; Fg=sum ETA*d(aB)*BX*Ce;
  Fv=ETA_mumu*d(aA)*Be*CB (a), or aA*Be*d(CB) (c), or
  aA*d(Be)*CB (Be). A fourth control differentiates the external Ce in Fg.
- FU source-mixed: S=Je*BY_nu*CA,Fg=sum ETA*d(aA)*BX*Ce,
  U=ETA_mumu*LY*BX_mu*Be.
- FU ghost-mixed: S=Je*BX_nu*CA,Fg=sum ETA*d(aA)*BY*Ce,
  the same U. Keep the two orientations distinct.
- YM: S=Je*BY_nu*CA,Fg=sum ETA*d(aA)*BX*Ce. The third vertex is the
  full literal -sum_epsilon ETA_rho ETA_sigma*d(Va_sigma)*Vb_rho*Vc_sigma
  over six permutations of (externalBe,BY,BX), per unit f^(external)_(Y X).

The D coefficient is the complete action vertex for one specified external
vector and one quantum vector; actual identical-vector multiplicities belong
to action differentiation, not an invented unit factorial. Distinct external
background assignments of the two F vertices give all six Born words.

Primary uses full graded Hessians and every ordered Born word, -i/4 for the
two-vertex bubble and +i/6 for triangles. Replay independently enumerates
proper Gaussian pairings, exact external-odd extraction and conserved loop
routings for every vertex order, with -i*i^n/n!. Compare full unintegrated
homogeneous kernels, not only their angular residues. Primary Lorentz Wick
moments versus replay Gaussian gamma moments apply the qualified radial
2i multiplier in hbar/(32pi² epsilon_UV) units. Compute all16 Lorentz pairs
for all8 unit variants (128 kernels). No actual color pole is claimed.

This is the zeroth external-momentum ultraviolet Taylor coefficient of a
zero-jet logarithm, on the existing positive UV annulus. It is not a whole
scaleless integral or an infrared/finite amplitude. External differentiated
Ce/Be terms are evaluated at this Taylor order; they are not discarded from
the action. Check FF_a+FF_c+FF_Be=0 before/after integration. Off-diagonal
intermediate kernels must be retained until angular projection.

Controls: wrong source grade; wrong angular metric; omitted transverse,
mixed or reverse-odd inverse; one-word normalization; all-current sum and
external-derivative zeros. Report genuinely insensitive mutations and any
different invalid values from the two corrupted methods. No assertion may
force an unknown unit coefficient to match the affine diagnostic.

Two sequential read-only workers,120seconds after imports,sampled8GiB and
>=350MiB available commit. Freeze source/controller/inputs, preserve complete
native failures, validate complete paired objects before commit. Stop before
actual colors or a canonical/known-functional export. No generic compiler,
parameter search,new input/benchmark,old evidence edit,blocked activation or
remote action. Authorityv113/34of39 unchanged; full source/Slavnov,E5/A5,
QAP,finite/IR,measure/anomaly freedom open; HB1/C5 blocked,C1_GS uncalculated,
flavor paused,prior failures/scalar warning/custodyexit2/seven preserved.
Shared unit action/reference/helpers/UV assumptions/AI authorship limit
independence; education remains voluntary, concurrent and nonblocking.
