# Invalid-covariance control handling V2

The original primary completed. The original replay passed its128 unit
positions and current/zero checks, then failed while applying vertex-order
independence to the deliberately deleted reverse-ghost propagator. Full
native capture/source/preparation are preserved; no replay result exported.

Removing only G_aC violates graded covariance. Different Wick vertex orderings
are then a detected defect, not evidence that the physical unit has failed.
V2 retains order equality for every physical kernel and every covariance-
preserving mutation. For this one invalid mutation it records all ordered
kernels' equality status and pole values instead of demanding equality. It
also retains their explicit permutation average. No propagator, unit vertex,
physical acceptance assertion or expected result is fitted or changed.

Only the corrected replay is run, at the same120-second/8GiB caps. Reuse the
complete primary V1. Compare all128 physical kernels/residues and all applicable
controls. Different invalid values may occur by method and are disclosed.
This is an engineering/control-design failure, not a new physical assumption.
