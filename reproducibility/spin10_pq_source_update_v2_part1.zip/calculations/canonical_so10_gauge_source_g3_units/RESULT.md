# Ordinary g3 source/vector unit factors qualified

Full graded-Hessian/Born and routed Gaussian/Wick calculations agree on all128
unintegrated kernels and their128 Lorentz residues. The eight variants include
external-derivative zeros and both auxiliary propagation orientations. Every
matrix is diagonal in the declared source/vector indices, with the same factor
for all four diagonal positions. Nonzero off-diagonal intermediate kernels
were retained through the angular projection.

| Unit vertex family | Diagonal pole factor |
| --- | --- |
| S*D quartic bubble | -(W_X+3)/2 |
| S*Fg*Fv, derivative on internal antighost | -W_X/2 |
| S*Fg*Fv, derivative on internal ghost | +W_X/2 |
| External Be derivative at this Taylor order | 0 |
| External Ce derivative at this Taylor order | 0 |
| S*F*U, source vector propagates to auxiliary | -W_X/2 |
| S*F*U, ghost-vertex vector propagates to auxiliary | +(W_X+3)/2 |
| S*F*G3, full vector self-interaction | +3W_X/2 |

These factors use the exact ordered unit vertices in the [record](RECORD.md),
external order Je*Be*Ce and common hbar/(32pi² epsilon_UV) units. Couplings,
actual color tensors and action differentiation multiplicities have yet to be
inserted. They are not actual Spin(10) g3 amplitudes.

For D/FF, X labels the sole ordinary B/B line. For the auxiliary families,
X labels the ordinary B/B line and Y the mixed B/L line. For G3, X is the
vector line incident on the ghost derivative and Y the source vector line.
W_Y cancels from the final qualified residues. No physical gauge width was
chosen. The G3 vertex is normalized per unit f^(external)_(Y X), including all
six derivative/color permutations of the literal gauge kinetic cubic.

In plain language, the remaining source/vector calculation needs different
momentum factors for its different diagrams. The transverse vector components
produce the3 terms in the bubble and one auxiliary orientation. Subsequent
color contraction must retain these family-specific factors and their signs.
The vector self-interaction contribution is also nonzero and required.

The two-vertex bubble retains both Born words; each triangle retains all six.
Replay separately routes every proper Gaussian pairing at each vertex order,
with the external odd factors and -i*i^n/n! normalization. Primary Lorentz
pairing moments and replay gamma moments agree. A third Lorentz-Laplacian
projection in the separate validator checks every retained kernel's residue.

FF_a+FF_c+FF_Be vanishes as a complete unintegrated kernel and after projection.
External derivatives are evaluated at the zero-jet UV Taylor order, not deleted
from the action. The positive ultraviolet annulus separates this logarithm
from the infrared; no whole scaleless integral or finite amplitude is inferred.

Omitting transverse propagation changes every tested nonzero family and sets
the G3 unit residue to zero. Omitting mixed propagation changes the two FU
families to zero and is correctly insensitive for D,FF and G3. Omitting a
contributing ordered word changes normalization. A wrong Euclidean angular
metric changes the spatial D factor to W_X/2-5/2; the source-parity control
also detects its defect.

The original replay failed when vertex-order independence was demanded after
deleting only the reverse ghost inverse. That mutation violates graded
covariance. The [V2 correction](CORRECTION_REPLAY_V2.md) preserves the failed
capture/source and requires order equality for all physical and covariance-
preserving cases. It records ordering failure for the deliberately invalid
case. The complete primary V1 is reused; only the corrected replay is run.

All five reverse-ghost controls detect their mutation. For FF_a, the corrupted
Born factor is -W_X/4, while the corrupted permutation-averaged Wick factor is
-W_X/12. Both differ from the valid -W_X/2, and the Wick orderings disagree.
Those invalid values are preserved; agreement was not imposed on a broken
covariance. This is a control-design/engineering failure, not a physical-unit
disagreement. Primary/corrected replay completed in4.646 and6.247 seconds
after imports, below the120-second/8GiB caps. No actual group, old pole,
known functional, required affine target or peer JSON was interpreted.

Next reconstruct the complete actual S,F,D,U and G3 color inputs in the
same real source-dual convention, for external A_H and B. Reuse qualified
source/GF cubics and physical10 commutators; retain all A/B quartics and
their identical-vector differentiation factors. Contract with the qualified
unit factors before accessing the required affine sum. A completed subset
must not be called the complete g3 source/vector pole.

Track B: full momentum treatment distinguishes propagation orientations and
exposes a control that violated its own covariance premise. Primary/replay
share the unit vertices, inverse conventions, exact helpers, radial UV
assumptions, software and AI authorship. The third projection checks angular
arithmetic; it cannot validate a shared physical assumption. Education remains
voluntary, concurrent and nonblocking.

No actual g3 color pole or functional node was added. Current known partial
functional92280 retains its920-term nonzero local Ward. Authorityv113/34of39
unchanged; full source/Slavnov,E5/A5,QAP,finite/IR,measure/anomaly freedom open.
HB1/C5 blocked,C1_GS uncalculated,flavor paused; prior failures/exclusions,
scalar warning,custodyexit2/seven preserved. No accepted input/benchmark/
foundation,protected evidence,publication or remote change.
