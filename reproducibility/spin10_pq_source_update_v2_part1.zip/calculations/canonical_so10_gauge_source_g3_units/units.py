"""Ordinary source/vector bubbles and triangles: exact Born versus routed Wick."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
from math import factorial
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
import a10_e5_gauge_source_partner_control as lib
s=lib.s;ETA=lib.ETA;R=lib.R;II=lib.II;c=lib.c;K=lib.K;t=lib.t
read=lambda f:json.loads(f.read_bytes());digest=lambda f:sha256(f.read_bytes()).hexdigest()
FAMILIES=['D','FF:a','FF:c','FF:Be','FF:Ce','FU:source_mixed','FU:ghost_mixed','YM']

def model(family,nu,mu):
    w=lib.alphabet();w.fields={**{f'B{a}{rho}':(1,0,0) for a in ['X','Y'] for rho in range(4)},'LX':(2,0,0),'LY':(2,0,0),'CA':(1,1,1),'aA':(1,-1,1),'CB':(1,1,1),'aB':(1,-1,1)}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    for n,z in [('Je',(2,-1,1)),('Be',(1,0,0)),('Ce',(1,1,1))]:lib.register(w,n,z)
    v=w.var
    if family=='D':
        V=[w.mul(v('Je'),v(f'BX{nu}'),v('CA')),w.scale(w.mul(v('Be'),v('aA'),v(f'BX{mu}'),v('Ce')),ETA[mu])]
    elif family.startswith('FF:'):
        case=family[3:];S=w.mul(v('Je'),v(f'BX{nu}'),v('CA'))
        G=w.add(*(w.scale(w.mul(v('aB') if case=='Ce' else w.D(v('aB'),rho),v(f'BX{rho}'),w.D(v('Ce'),rho) if case=='Ce' else v('Ce')),ETA[rho]) for rho in range(4)))
        Vv=w.scale(w.mul(w.D(v('aA'),mu) if case in ['a','Ce'] else v('aA'),w.D(v('Be'),mu) if case=='Be' else v('Be'),w.D(v('CB'),mu) if case=='c' else v('CB')),ETA[mu]);V=[S,G,Vv]
    elif family.startswith('FU:'):
        source_group,ghost_group=('Y','X') if family=='FU:source_mixed' else ('X','Y')
        S=w.mul(v('Je'),v(f'B{source_group}{nu}'),v('CA'))
        G=w.add(*(w.scale(w.mul(w.D(v('aA'),rho),v(f'B{ghost_group}{rho}'),v('Ce')),ETA[rho]) for rho in range(4)))
        U=w.scale(w.mul(v('LY'),v(f'BX{mu}'),v('Be')),ETA[mu]);V=[S,G,U]
    else:
        assert family=='YM';S=w.mul(v('Je'),v(f'BY{nu}'),v('CA'))
        G=w.add(*(w.scale(w.mul(w.D(v('aA'),rho),v(f'BX{rho}'),v('Ce')),ETA[rho]) for rho in range(4)))
        fields=[[v('Be') if rho==mu else {} for rho in range(4)],[v(f'BY{rho}') for rho in range(4)],[v(f'BX{rho}') for rho in range(4)]];Y={}
        for a,b,d in permutations(range(3)):
            sign=(-1)**sum(x>y for i,x in enumerate((a,b,d)) for y in (a,b,d)[i+1:])
            for rho,sigma in product(range(4),repeat=2):Y=w.add(Y,w.scale(w.mul(w.D(fields[a][sigma],rho),fields[b][rho],fields[d][sigma]),-sign*ETA[rho]*ETA[sigma]))
        V=[S,G,Y]
    assert all(w.grade(P,(4,0,0)) for P in V)
    return w,V

def born(family,nu,mu,**opts):
    w,V=model(family,nu,mu);n=len(V);G=lib.green(w,**opts);p=[w.p[name] for name in w.fields];H=[lib.hessian(P,w) for P in V];parts=[]
    for order in permutations(H):
        full=G
        for i,A in enumerate(order):
            full=lib.mm(full,A)
            if i<n-1:full=lib.mm(full,G)
        parts.append(lib.trace(full,p).get((0,1,2),R.zero)*II*c(s.Rational((-1)**(n+1),2*n)))
    return sum(parts,R.zero),parts

def wick(family,nu,mu,**opts):
    w,V=model(family,nu,mu);n=len(V);ext={'Je':0,'Be':1,'Ce':2};parts=[]
    for order in permutations(V):
        out=R.zero
        for terms in product(*(list(P.items()) for P in order)):
            full=[];legs=[];external=[];value=R.one
            for vertex,(word,z) in enumerate(terms):
                value*=c(z)
                for pos,(name,jets) in enumerate(word):
                    token=(vertex,name,jets,w.p[name],pos);full.append(token)
                    if name in ext:
                        external.append(ext[name])
                        if jets:value=R.zero
                    else:legs.append(token)
            if not value:continue
            assert len(legs)==2*n and sorted(external)==[0,1,2]
            crossing=(-1)**sum(a[3]*b[3] for i,a in enumerate(full) if a[1] not in ext for b in full[i+1:] if b[1] in ext)
            sorting=(-1)**sum(x>y and x in [0,2] and y in [0,2] for i,x in enumerate(external) for y in external[i+1:])
            for pairs in lib.pairings(legs):
                routes=[]
                for tail in product([-1,1],repeat=len(pairs)-1):
                    epsilon=(1,*tail)
                    if all(sum(e*(int(a[0]==v)-int(b[0]==v)) for e,(a,b,sgn) in zip(epsilon,pairs))==0 for v in range(n)):routes.append(epsilon)
                assert len(routes)==1
                term=value*crossing*sorting
                for e,(a,b,sgn) in zip(routes[0],pairs):
                    term*=sgn*II*lib.inverse(a[1],b[1],e,**opts)
                    for rho in a[2]:term*=II*e*K[rho]
                    for rho in b[2]:term*=-II*e*K[rho]
                out+=term
        parts.append(out*(-II)*II**n*c(s.Rational(1,factorial(n))))
    assert all(P==parts[0] for P in parts)
    return sum(parts,R.zero),parts

def serial(P):return str(s.expand(P.as_expr()))
def wrong_metric(P):
    out=R.zero
    for mon,z in P.items():
        assert sum(mon[:4])-2*mon[4]==-4
        if any(p%2 for p in mon[:4]):continue
        m=sum(mon[:4])//2;value=s.gamma(2)/s.gamma(2+m)*s.prod(s.gamma(s.Rational(p+1,2))/s.gamma(s.Rational(1,2)) for p in mon[:4])
        out+=R.from_dict({(0,0,0,0,0,mon[5],mon[6]):z*lib.QQ_I.from_sympy(s.simplify(value))})
    return s.simplify((2*II*out).as_expr())

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for name,z in prep['input_sha256'].items():assert digest(Path(name))==z,name
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('G3_UNIT_WRITE')
        if p.suffix=='.json':raise PermissionError('G3_UNIT_GROUP_POLE_GAMMA_COMPLETION_PEER_READ')
    sys.addaudithook(guard);method=born if route=='primary' else wick;table={};kernels={};algebra={};nonzero_offdiag=False
    for family in FAMILIES:
        print('STAGE '+route+' '+family,flush=True);entries=[];raw=[];polynomials=[]
        for nu,mu in product(range(4),repeat=2):
            P,parts=method(family,nu,mu);value=lib.residue(P,route);entries.append([nu,mu,str(value)]);raw.append([nu,mu,serial(P)]);polynomials.append(P)
            if nu!=mu and P:nonzero_offdiag=True
            assert all(not z.has(s.Float) for z in [value])
            assert len(parts)==(2 if family=='D' else 6)
        assert len({text for nu,mu,text in entries if nu==mu})==1 and all(text=='0' for nu,mu,text in entries if nu!=mu)
        table[family]=entries;kernels[family]=raw;algebra[family]=polynomials
    for index in range(16):
        total=R.zero
        for family in ['FF:a','FF:c','FF:Be']:total+=algebra[family][index]
        assert not total
    assert all(text=='0' for family in ['FF:Be','FF:Ce'] for nu,mu,text in table[family])
    controls={}
    for family in ['D','FF:a','FU:source_mixed','FU:ghost_mixed','YM']:
        base=lib.residue(algebra[family][0],route);P,parts=method(family,0,0)
        contributing=[i for i,Q in enumerate(parts) if lib.residue(Q,route)!=0]
        partial=lib.residue(sum((Q for i,Q in enumerate(parts) if i!=contributing[0]),R.zero),route) if contributing else None
        if contributing:assert s.simplify(partial-base)!=0
        tests={}
        for name,options in [('omit_transverse',{'omit_transverse':True}),('omit_mixed',{'omit_mixed':True}),('omit_reverse_odd',{'omit_reverse_odd':True})]:
            Q,unused=method(family,0,0,**options);value=lib.residue(Q,route);tests[name]={'pole':str(value),'changes_result':s.simplify(value-base)!=0}
        controls[family]={'omit_one_ordered_word_pole':str(partial),'omitted_contributing_word_index':contributing[0] if contributing else None,'changes_nonzero_normalization':bool(contributing),'inverse_mutations':tests}
    spatial,unused=method('D',1,1);bad=wrong_metric(spatial);assert s.simplify(bad-lib.residue(algebra['D'][0],route))!=0
    w,V=model('D',0,0);w.p['Je']=0;w.external['Je']=(2,-1,0);assert not w.grade(V[0],(4,0,0))
    result={'schema':'ORDINARY_G3_GAUGE_SOURCE_VECTOR_UNIT_V1','route':route,'unit_Lorentz_poles':table,'complete_unintegrated_kernels':kernels,
      'all128_kernels_and_Lorentz_positions_retained':True,'offdiagonal_intermediate_kernel_nonzero_retained':nonzero_offdiag,'FF_current_complete_kernel_sum_zero':True,
      'external_vector_and_ghost_derivative_zeros_evaluated':True,'word_counts':{'D':2,'triangles':6},'negative_controls':controls,'wrong_Euclidean_metric_D_spatial_pole':str(bad),'wrong_source_parity_rejected':True,
      'radial_Minkowski_multiplier':'2*I','UV_scope':'zeroth external Taylor coefficient on positive UV annulus; not whole scaleless integral','actual_group_pole_or_required_identity_or_peer_read':False,
      'actual_Spin10_g3_color_pole_computed':False,'full_source_Slavnov_E5_A5_or_finite_IR_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
