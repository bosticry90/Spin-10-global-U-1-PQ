# Check the exact row-normalization bridge without weakening the hash gate

V2 completed the previously timed-out sum in about60.3s, then failed the prior
functional count/hash assertion. Its native exit1/source/controller/preparation/
full capture are preserved. No qualification receipt exists. Do not infer that
the difference is harmless from worker agreement or assume it is a physics
failure. The original V1 timeout also remains preserved.

Code inspection identifies a concrete missing serialization operation. The
established Words.add expands each summed coefficient before canonical clean;
canonical applies the cached s.simplify; rows applies clean once again before
serializing. V2 instead simplified the unexpanded Add and wrote that result
directly. Algebraically equivalent SymPy expressions need not have identical
serialized forms under different normalization paths.

V3 tests this specific explanation using independent ordinary-word arithmetic:
expand the complete sum, verify expand(expanded-original)==0, simplify, then
apply the established final simplify at row serialization. It must still
reproduce the unchanged prior and updated full row hashes/counts, complete
tensor/physical/graded/Ward controls and all vacuum projections. Print the
actual prior count/hash before asserting, so another mismatch is diagnosable.
Check that changing a nonzero known coefficient changes the hash; the
normalization may not hide a genuine coefficient mutation. If the unchanged
hash still fails, stop and inspect the discrepancy; do not fit it or replace
the expected hash by the new value.

This correction aligns an independent derivation with the existing byte
normalization; it does not alter the action, measured poles, parent recipe,
coefficient values or acceptance obligation. No science workers are repeated.
Freeze V3 separately under standing AGENTS delegation, same180s/8GiB and
minimum350MiB available commit. All earlier sources/captures remain immutable.
The V3 result/next handoff are prospective until a completed receipt exists.
Every scientific and authority ceiling in RECORD remains unchanged.
