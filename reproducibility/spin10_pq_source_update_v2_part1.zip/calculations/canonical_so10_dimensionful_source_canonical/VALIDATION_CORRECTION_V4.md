# Finish complete validation without repeated exact serialization

V3 reproduced the original145546-word prior hash
3991c9ce15e41c7acd3f0d3dba447aa676aded09fc2bfc5c3c13809b813d911c.
Its complete updated-hash, add-once and coefficient-mutation assertions also
passed before the printed vacuum-check stage. It then reached180s without a
final result/receipt (FAILED/exit124). This resolves the V2 normalization
diagnostic but does not qualify an unfinished validation. Preserve the full
V3 source/controller/preparation/capture, original timeout and hash failure.

V4 caches str(clean(z)) on the exact immutable coefficient expression and
stores the actual prior/updated hashes once they have been computed. V3 made
over742000 cached simplification calls, followed by repeated serialization of
the same small coefficient set across145546 words. Removing that repetition
changes neither coefficient values, word coverage nor the generated hash
stream. The complete mutant hash is still computed; it must differ from the
actual stored prior hash. No object-identity hash cache, sample, numerical
tolerance, changed expected hash or omitted vacuum term is allowed.

Reuse the two completed science workers. All scientific and validation
obligations in RECORD remain, including all14760 tensor positions, complete
H actions, prior/new row hashes, exact add-once and full vacuum projections.
Retain180s/sampled8GiB/minimum350MiB available commit under AGENTS standing
delegation, with new V4 frozen source/controller/preparation/full capture.
The completed V4 default validation_receipt.json, if produced, supersedes the
prospective V3 receipt requirement; none of the three failed runs is PASS.
No old loops or known coefficients are changed.

The scientific conclusions in RESULT/RESULT_V3 remain conditional until this
full gate and committed-byte checks complete. This continuation records a
third avoidable verifier cost, repeated serialization, without changing the
scientific authority ceiling or erasing earlier defects. Source/E5/A5 and
physical viability remain unqualified; blocked/paused boundaries,authority
34/39,quartet/scalar warnings and custodyexit2/seven remain unchanged.
