# Dimensionful source canonical integration and vacuum pullbacks V1

Baseline cb4ea9307da93aed5dfff7c243fb4e437cffc81a; AGENTS standing delegation.
V201 qualifies the complete intrinsic g10^3*xi Jx*C pole (432 nonzero/14760
positions); V204 qualifies the complete intrinsic g10^4*xi JL*C*x zero. The
question is whether these actual results admit the same real/canonical charts
and local H covariance as the existing source functional, and how their
full-Cartesian classification differs from inherited vacuum translations.
Possible outcomes: qualified integration, a real chart/covariance obstruction,
or bounded inconclusiveness. No target cancellation is assumed or fitted.

Keep all328 real scalar coordinates and evaluation-dual sources unchanged.
Only the ghost frame changes: raw C=Cinv*Cp, Cp=Cphys*C. Ordered density is
sum P[i,a]*Jx_i*C_a in common hbar*g10^3*xi/(32*pi^2*epsilon_UV).
Jx and C are odd; canonical word insertion supplies their actual sign. The
field word has dimension3 and its orbit coefficient dimension1. Do not reject
or falsely grade it as dimension-zero. Require all701 scalar/source/ghost
chart checks, full tensor/polynomial roundtrip and physical real coefficients.
Check the antilinear raw-C3 involution, not componentwise raw reality.

Primary uses full graded polynomial substitution raw->physical->raw. Replay
uses explicit Cinv/Cphys index contractions. Both use the qualified exact
matrices, different substitution routes and full tables/zero complements.
Calculate the full local H variation from actual E3 images of Jx/C with both
position action and left-gradient action. Keep all12 parameters; require
no jets before interpreting as local covariance. Record any nonzero remainder.
Omitting the source or ghost action, wrong ghost map, source-order reversal,
halving/doubling and omission of the actual node are controls. Report genuine
insensitivity rather than use a zero Ward equation as a normalization oracle.

Only after these node checks, reconstruct the current145546-word functional
from its exact V196 own-role recipe and checked predecessor hashes. Combine
its already-qualified constituent tables in one materialization; do not rerun
old loops, old Q or the full old Ward. Authenticate row hash
3991c9ce15e41c7acd3f0d3dba447aa676aded09fc2bfc5c3c13809b813d911c.
Prove the new intrinsic g^3*xi Jx*C class is absent, add the measured node once,
check all-word inverse addition and a nonzero double-count witness, and save
the new complete row hash/count with a compact prior-recipe/add-once pointer.
Carry the prior Ward zero only by linearity with the actually computed node
variation. The qualified zero JL*C*x adds no coefficient.

Recover the unchanged328-coordinate VEV from the qualified physical record.
Derive the Jx*C (and any JL*C) constant source projections obtained from
already-qualified source-linear Jx*C*x/JL*C*x terms by x=v+eta. Primary uses
graded replacement, replay explicit scalar-index evaluation. Export those
pullbacks separately by coupling order and combine with intrinsic constants
only as a SOURCE PROJECTION of a future consistent shift. They must not be
added to the full-x functional as another loop correction. Check v=0 and
inverse replacement on all328 elementary coordinates. No partial action shift
is promoted to a full shifted-functional/Slavnov identity. This distinction
is the scientific dependency check, not new physical input or a new benchmark.

Two sequential300-second-after-import/sampled8GiB workers, minimum350MiB
available commit. The existing full-functional integration takes over130s;
the300s bound covers that mandatory hash check without increasing its prior
integration limit. Freeze sources/controller/inputs/own-role JSON access
before execution. Separate180-second/8GiB validation with independently
parsed ordered words, ordinary SymPy transport/reality, full family/hash
links, source-class absence/addition and vacuum projection checks. Preserve
failed/unfinished sources and captures; version corrections, no silent growth.

The next remaining task is positive-dimensional Slavnov predecessor coverage,
including physical Euler and OrbitPullback exceptions and JL*C power-sensitive
groups. This integration is not that completeness theorem. Shared action,
source inventory, charts, inherited units, software and AI authorship limit
independence. No outside endorsement or universal Lean prerequisite.
No full source restoration,E5/A5,QAP,measure,contact,finite/IR, anomaly or
physical-viability claim. Statev113/34of39 unchanged; HB1/C5 blocked,flavor
paused,C1_GS uncomputed,scalar quantum warning,quartet failure,custodyexit2/seven
preserved. No foundational/input/benchmark/remote change. Education concurrent,
voluntary,nonblocking; this is delegated bounded scientific work.
