"""Actual intrinsic source node, canonical integration and separate VEV projections."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from functools import lru_cache
import importlib.util,json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
spec=importlib.util.spec_from_file_location('qualified_quartet_recipe',ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_canonical/canonical_v2.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
from a10_e5_nonminimal_source import s,g,xi,canonical,decode_typed,rows,act,zero
from a10_e5_measured_functional_v3 import frames
from a10_e2_transport_common import partials
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
SEC=[('Phi',0,54),('Sigma',54,252),('phi',306,20),('S',326,2)]
etaH=s.Symbol('eta_H',real=True)
@lru_cache(None)
def num(z):return s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':etaH})
def scalar(i,prefix='x_'):
    for sec,start,dim in SEC:
        if start<=i<start+dim:return prefix+sec+'_'+str(i-start)
    raise AssertionError(('SCALAR_OUTSIDE_DOMAIN',i))
def density(P,w,physical=False):
    out={}
    for (i,a),z in P.items():
        for word,sign in w.mul(w.var(scalar(i,'Jx_')),w.var(('Cp' if physical else 'C')+str(a))).items():out[word]=sign*g**3*xi*z
    return canonical(out)
def tensor(P,M):
    terms=defaultdict(list)
    for (i,a),z in P.items():
        for b in range(45):
            if M[a,b]:terms[i,b].append(z*M[a,b])
    return {k:v for k,z in terms.items() if (v:=s.expand(s.Add(*z)))!=0}
def ordered(P,physical=False):
    out={}
    for word,z in P.items():
        assert len(word)==2 and all(not j for n,j in word)
        J=next(n for n,j in word if n.startswith('Jx_'));C=next(n for n,j in word if re.fullmatch(('Cp' if physical else 'C')+r'\d+',n));sec=J.split('_')[1];start=next(start for sn,start,dim in SEC if sn==sec);i=start+int(J.rsplit('_',1)[1]);a=int(C[2:] if physical else C[1:]);sign=-1 if word[0][0]==C else 1
        assert (i,a) not in out;out[i,a]=s.expand(sign*num(str(z))/(g**3*xi))
    return out
def odd_or_even_action(P,w,images,role):
    if role=='primary':return canonical(act(P,w,images,role,0))
    out={}
    for (n,jets),Q in partials(P,w,set(images)).items():
        for key,z in w.mul(w.dword(images[n],jets),Q).items():out[key]=out.get(key,0)+z
    return canonical(out)
def current_tables(role):
    d=ROOT/'calculations';quartet=prior.auth(d/'canonical_so10_auxiliary_quartet_g4_canonical',role+'_v2_result.json');pair_path=Path(quartet['updated_known_recipe']['previous_recipe_path']);assert digest(pair_path)==quartet['updated_known_recipe']['previous_recipe_sha256'];pair=prior.auth(pair_path.parent,pair_path.name)
    scalar_path=Path(pair['updated_known_recipe']['previous_recipe_path']);assert digest(scalar_path)==pair['updated_known_recipe']['previous_recipe_sha256'];sc=prior.auth(scalar_path.parent,scalar_path.name)
    vector_path=Path(sc['updated_known_recipe']['previous_recipe_path']);assert digest(vector_path)==sc['updated_known_recipe']['previous_recipe_sha256'];vec=read(vector_path)
    derivative_path=Path(vec['updated_known_recipe']['previous_recipe_path']);assert digest(derivative_path)==vec['updated_known_recipe']['previous_recipe_sha256'];der=read(derivative_path)
    oldquartet_path=Path(der['updated_known_recipe']['previous_recipe_path']);assert digest(oldquartet_path)==der['updated_known_recipe']['previous_recipe_sha256'];oldq=read(oldquartet_path)
    rec=oldq['updated_known_recipe'];oldpair=rec['prior_source_pair_recipe'];base=oldpair['prior_recipe'];initial=read(PKG/base['base_path'])
    g4path=Path(der['updated_known_recipe']['previous_actual_g4_path']);assert digest(g4path)==der['updated_known_recipe']['previous_actual_g4_sha256'];g4=read(g4path)
    tables=[initial[base['base_key']],base['add_once'],oldpair['add_source_pair_once'],rec['add_actual_source_quartet_once'],g4['new_actual_g4_node'],der['new_actual_g2_node'],vec['new_actual_g3_node'],sc['new_actual_g3_scalar_node'],pair['new_actual_g2_xi_pair_node'],quartet['new_actual_g4_quartet_node']]
    assert quartet['updated_known_terms']==145546 and quartet['updated_known_sha256']=='3991c9ce15e41c7acd3f0d3dba447aa676aded09fc2bfc5c3c13809b813d911c' and quartet['updated_known_Ward']==[]
    return tables,quartet,d/'canonical_so10_auxiliary_quartet_g4_canonical'/(role+'_v2_result.json')
def selected(P,withx=False,source='Jx'):
    out={}
    for word,z in P.items():
        if len(word)!=2+withx or any(j for n,j in word):continue
        ns=[n for n,j in word]
        if sum(n.startswith('Jx_') if source=='Jx' else bool(re.fullmatch(r'(Jb|JL)\d+',n)) for n in ns)!=1 or sum(bool(re.fullmatch(r'C\d+',n)) for n in ns)!=1:continue
        if sum(n.startswith('x_') for n in ns)!=withx:continue
        out[word]=num(z) if isinstance(z,str) else z
    return canonical(out)
def vacuum_pullback(P,w,v,role):
    if role=='primary':
        substitutions={scalar(i):{():v[i]} for i in range(328)}
        return canonical(w.replace(P,substitutions))
    out={}
    for word,z in P.items():
        X=[(p,n) for p,(n,j) in enumerate(word) if n.startswith('x_')];assert len(X)==1;p,n=X[0];sec=n.split('_')[1];i=next(start for sn,start,dim in SEC if sn==sec)+int(n.rsplit('_',1)[1]);key=word[:p]+word[p+1:];out[key]=out.get(key,0)+z*v[i]
    return canonical(out)
def power_counts(P):
    counts=Counter()
    for z in P.values():
        for gp,coef in s.Poly(z,g).terms():
            if coef:counts[gp[0]]+=1
    return {str(k):v for k,v in sorted(counts.items())}
def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('DIMENSIONFUL_CANONICAL_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('DIMENSIONFUL_CANONICAL_UNDECLARED '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();out=fn();dt=time.perf_counter()-t;stages.append({'name':n,'seconds':dt});print('DONE '+n+' '+str(dt),flush=True);return out
    pole=prior.auth(ROOT/'calculations/canonical_so10_dimensionful_scalar_source_pole',role+'_v3_result.json');P={(i,a):num(z) for i,a,z in pole['complete_pole']};assert len(P)==432 and pole['zero_complement']==14328
    az=prior.auth(ROOT/'calculations/canonical_so10_dimensionful_auxiliary_scalar_pole',role+'_result.json');assert az['complete_pole']==[] and az['zero_complement']==664200
    w,forward,back,source,anti,Cinv,Cphys=stage('actual_frames',lambda:frames(role));fwd={f'C{i}':forward[f'C{i}'] for i in range(45)};rev={f'Cp{i}':back[f'Cp{i}'] for i in range(45)}
    for i in range(45):
        zero(w.add(w.replace(rev[f'Cp{i}'],fwd),w.scale(w.var('Cp'+str(i)),-1)),'GHOST_FORWARD');zero(w.add(w.replace(fwd[f'C{i}'],rev),w.scale(w.var('C'+str(i)),-1)),'GHOST_INVERSE')
    for i in range(328):
        for pre,grade in [('x_',(1,0,0)),('Jx_',(2,-1,1))]:
            n=scalar(i,pre);assert w.grades[n]==grade and w.replace(w.var(n),fwd)==w.var(n)==w.replace(w.var(n),rev)
    node=density(P,w)
    for i,a in P:
        J=scalar(i,'Jx_');C='C'+str(a);assert w.mul(w.var(J),w.var(C))==w.scale(w.mul(w.var(C),w.var(J)),-1)
    assert canonical(w.scale(node,-1))!=node and canonical(w.scale(node,s.Rational(1,2)))!=node and canonical(w.scale(node,2))!=node and node!={}
    if role=='primary':
        physical=stage('full_graded_raw_to_physical',lambda:canonical(w.replace(node,fwd)));physicalP=ordered(physical,True);assert physicalP==tensor(P,Cinv);assert canonical(w.replace(physical,rev))==node
    else:
        physicalP=stage('complete_ghost_index_transform',lambda:tensor(P,Cinv));physical=density(physicalP,w,True);assert tensor(physicalP,Cphys)==P and canonical(w.replace(physical,rev))==node
    assert all(s.expand(z-s.conjugate(z))==0 for z in physical.values()),'PHYSICAL_REALITY_FAILURE'
    active={n for word in node for n,j in word};starimages={n:canonical(w.replace({word:s.conjugate(z) for word,z in fwd.get(n,w.var(n)).items()},rev)) for n in active};assert canonical(w.replace({word:s.conjugate(z) for word,z in node.items()},starimages))==node
    assert w.grade(node,(3,0,0)) and all(len(word)==2 and not any(j for n,j in word) for word in node)
    wrong=density(tensor(P,Cphys),w,True);assert wrong!=physical and canonical(w.replace(wrong,rev))!=node
    tb=read(PKG/f'frozen_a10_e3_symmetry/{role}.json')['operators']['Tb_geometric_and_transported'];images={n:decode_typed(tb[n]) for n in active};assert all(not j for Q in images.values() for word in Q for n,j in word)
    ward=stage('complete_local_H_Ward',lambda:odd_or_even_action(node,w,images,role));noJ=stage('source_omission_Ward',lambda:odd_or_even_action(node,w,{n:({} if n.startswith('Jx_') else Q) for n,Q in images.items()},role));noC=stage('ghost_omission_Ward',lambda:odd_or_even_action(node,w,{n:({} if n.startswith('C') else Q) for n,Q in images.items()},role))
    print('STAGE '+role+' release_prior_recipe_after_actual_node_checks',flush=True);tables,prev,previous=current_tables(role);known=stage('single_exact_current_functional_materialization',lambda:prior.old.materialize(tables,w));oldhash=prior.old.rowhash(prior.old.rawrows(known));assert len(known)==145546 and oldhash==prev['updated_known_sha256']
    intrinsic_before=selected(known);assert not intrinsic_before,'INTRINSIC_JX_C_CLASS_ALREADY_PRESENT'
    node_rows=rows(node);updated=stage('add_intrinsic_node_once',lambda:prior.old.materialize([prior.old.rawrows(known),node_rows],w));after=selected(updated);assert after==node
    exact={word:z for word,z in node.items()};domain=known.keys()|updated.keys()|exact.keys()
    for key in domain:assert s.expand(num(updated.get(key,'0'))-num(known.get(key,'0'))-exact.get(key,0))==0
    witness=next(iter(node));assert s.expand(num(updated[witness])+node[witness]-num(updated[witness]))==node[witness]!=0
    evidence=read(PKG/f'frozen_a10_physical_reconciliation/full_{role}.json');V=evidence['vacuum']['VEV'];assert V['shape']==[328,1];v=[s.S.Zero]*328
    for i,j,z in V['entries']:assert j==0;v[i]=num(z)
    for i in range(328):
        n=scalar(i);shift=w.add(w.var(n),{():v[i]});assert canonical(w.replace(shift,{n:w.add(w.var(n),{():-v[i]})}))==w.var(n)
    linear={source:selected(updated,True,source) for source in ['Jx','JL']};pullbacks={source:stage('separate_existing_VEV_projection_'+source,lambda source=source:vacuum_pullback(linear[source],w,v,role)) for source in linear};zero_v=[s.S.Zero]*328
    assert all(not vacuum_pullback(Q,w,zero_v,role) for Q in linear.values())
    projected=canonical(w.add(node,pullbacks['Jx']));assert canonical(w.add(projected,w.scale(pullbacks['Jx'],-1)))==node
    result={'schema':'DIMENSIONFUL_SOURCE_CANONICAL_V1','route':role,'new_actual_g3_xi_dimensionful_node':node_rows,'new_actual_physical_node':rows(physical),'raw_intrinsic_terms':len(P),'canonical_node_terms':len(node),'physical_node_terms':len(physical),'all701_scalar_source_ghost_charts_checked':True,'complete_density_roundtrip':True,'physical_reality_and_antilinear_C3_involution':True,'field_word_dimension':3,'coefficient_dimension':1,'wrong_ghost_map_rejected':True,'source_order_reversal_halving_doubling_and_omission_change_node':bool(node),'all12_local_H_parameter_components_retained':True,'actual_H_images_have_no_jets':True,'new_local_H_Ward':rows(ward),'source_omission_Ward':rows(noJ),'ghost_omission_Ward':rows(noC),'source_omission_sensitive':noJ!=ward,'ghost_omission_sensitive':noC!=ward,'Ward_zero_insensitive_to_overall_scale':not bool(ward),'intrinsic_class_absent_before_addition':True,'prior_known_terms':len(known),'prior_known_sha256':oldhash,'updated_known_terms':len(updated),'updated_known_sha256':prior.old.rowhash(prior.old.rawrows(updated)),'updated_known_Ward':rows(ward),'updated_known_Ward_zero':not bool(ward),'exact_all_word_inverse_and_nonzero_double_count_checked':True,'updated_known_recipe':{'previous_recipe_path':str(previous),'previous_recipe_sha256':digest(previous),'previous_terms':145546,'add_actual_node_key_once':'new_actual_g3_xi_dimensionful_node'},'VEV_sha256':sha256(json.dumps(V,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'VEV_nonzero_coordinates':sum(bool(z) for z in v),'all328_elementary_shift_inverses_checked':True,'inherited_source_VEV_pullbacks':{source:rows(Q) for source,Q in pullbacks.items()},'inherited_source_VEV_pullback_g_counts':{source:power_counts(Q) for source,Q in pullbacks.items()},'source_projection_after_consistent_future_shift':{'Jx_C':rows(projected),'JL_C_from_known_linear_scalar_terms':rows(pullbacks['JL'])},'VEV_pullbacks_not_added_to_full_x_functional':True,'zero_VEV_control_removes_inherited_pullbacks':True,'intrinsic_JL_C_x_zero_retained':True,'JL_C_power_sensitive_groups_still_unqualified':True,'full_shifted_functional_or_positive_dimensional_Slavnov_not_calculated':True,'old_loop_old_Q_or_full_old_Ward_replayed':False,'full_source_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
