# Exact coefficient comparison of the complete vacuum-source projection

V4 finished both full-functional hash/addition checks and the inherited vacuum
pullbacks, then failed a Python dictionary/Expr structural-equality assertion
for the combined Jx*C source projection. It exited1 in about40s; preserve its
entire source/controller/preparation/full capture. No accepted receipt exists.
Do not assume this is merely notation until every coefficient is compared.

V5 replaces only that final structural test by a stronger explicit mathematical
test: subtract the independently calculated and recorded combined coefficients
at all14760 scalar-source/ghost positions, expand exactly with symbolic g10/xi,
and require every residual to be zero. Require the same support set and report
the number of structurally different expressions separately. Print nonzero
residual examples/count and stop if any remain. Mutating a nonzero recorded
coefficient by1 must be detected by the same residual checker. This is not a
numerical tolerance or permission to change a coefficient/expected row hash.

All prior and updated full byte hashes, measured-node/chart/H controls and
inherited vacuum checks remain mandatory and unchanged. Reuse the two
completed science workers. Freeze V5 separately with the same180s/8GiB/
minimum350MiB available commit, preserve all four failed validators and their
classifications. A completed V5 default receipt, if achieved, supersedes earlier
prospective validation-version references; no failed run becomes PASS.
No new physical calculation, action/input/authority change or desired Slavnov
coefficient is introduced. Every limitation in RECORD/RESULT_V3 remains.
