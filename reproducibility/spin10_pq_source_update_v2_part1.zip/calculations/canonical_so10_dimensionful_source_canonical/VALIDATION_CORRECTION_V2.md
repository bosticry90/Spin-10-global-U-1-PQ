# Exact-simplification memoization for complete validation

The V1 validator reached its180-second after-import timer during the complete
plain-word known-functional sum. Its captured native exit is124/execution
FAILED/calculation_completed=false; the scientific classification is resource-
inconclusive, not a wrong coefficient or a completed gate. No validation receipt
was produced. Original validator/controller/snapshots, preparation and complete
native capture remain unchanged. Process inspection found its PID no longer
live before this continuation. Both completed scientific workers are reused.

The independent implementation repeatedly simplifies identical immutable
SymPy expressions across145546 word positions. V2 memoizes exactly that
s.simplify(expression) operation, with no changed expression, precision,
normalization, field domain or hash obligation. All14760 tensor positions,
both full-functional hashes, ordered signs, complete local H variation and
omission controls, all328 vacuum coordinates and separate source projections
remain mandatory. It does not use the workers' word algebra or replace a
full check by a sample. Cache keys are exact symbolic expressions.

New versioned validator/controller/preparation/capture under AGENTS standing
delegation; unchanged180-second/8GiB limit/minimum350MiB available commit.
Preserve incomplete/failing evidence; no automatic resource growth or old
quantum-loop rerun. This is a correction of avoidable repeated algebra, not
new physical assumptions, director acceptance or a new scientific promotion.
RECORD's full scope/limitations remain. The V205 prospective handoff and
RESULT.md predate the validation timeout; use RESULT_V2 and the completed
V2 receipt if qualification succeeds. No qualified result is presumed here.
