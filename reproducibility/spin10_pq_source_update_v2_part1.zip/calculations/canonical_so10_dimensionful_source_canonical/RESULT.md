# Dimensionful source node integrated; vacuum projections kept distinct

Qualification requires completed paired captures and the independent validation
receipt; this report is not a receipt. The actual intrinsic g10^3*xi Jx*C
pole has432 canonical positions and296 positions in the normalized real ghost
frame. Complete14760-position transport, all701 scalar/source/ghost charts,
physical reality and the raw-C3 antilinear involution agree. The scalar fields
and their evaluation-dual sources are unchanged; only the ghost chart changes.
The field word has dimension3 with a dimension1 orbit coefficient.

The complete local H variation is zero. Omitting either the scalar-source
action or the ghost action gives2272 nonzero words, so these controls detect
an incomplete variation. Wrong ghost transport fails the measured-density
roundtrip; source-order reversal and omission/half/double normalization change
the actual node. Its separately zero Ward variation is insensitive to overall
rescaling and cannot by itself verify the loop normalization.

The authenticated145546-word known functional had no intrinsic Jx*C class.
Adding the measured432-position node once gives145978 words and row SHA256
0d7dfab391eaff50c398f97fee7953359d35f60cee007c44fb4485e0182138ef.
The full-domain addition identity recovers the previous functional exactly;
double addition changes a nonzero coefficient. The V204 intrinsic JL*C*x
zero adds no coefficient. Prior local-H covariance is carried by linearity
with the actually computed new-node variation; old loops, the full old Ward
and old Q are not rerun. This is still a known PARTIAL quantum functional.

The unchanged frozen VEV has21 nonzero coordinates among328. Evaluating the
already-qualified Jx*C*x source terms on it produces432 inherited constant
source positions, each with g^2 and g^3 contributions. The corresponding
known JL*C*x projection is zero. These are coordinate translations of existing
coefficients, not additional loop calculations. They are stored separately
from the new intrinsic pole and are not added to the full-x functional.
All328 elementary shift inverses and the zero-VEV control are retained.

For example, the canonical C12*Jx_Sigma_152 inherited projection is
sqrt(30)*g10^2*xi*(g10-1), while the new intrinsic coefficient is
-25*sqrt(30)*g10^3*xi/8. The corresponding SOURCE PROJECTION of a consistently
shifted future functional is -sqrt(30)*g10^2*xi*(17*g10+8)/8. This is not a
complete shifted action or a new selected Slavnov identity. Shifting only
the source terms while leaving the remaining action/operator unchanged would
not establish that identity.

Primary uses full graded substitution; replay uses explicit inverse/direct
ghost-index products. Actual E3 source/ghost images are checked by position
action versus left gradients. The separate validator uses manually ordered
words, ordinary SymPy matrices and independent plain-word summation of every
prior recipe table, checking both the old and updated full hashes and the
separate vacuum projections. Limits are300s/8GiB for each sequential worker
and180s/8GiB for validation. Actual runtimes and execution states are in the
receipt/captures; no new failed worker is presumed away.

Shared action, charts, qualified pole/unit results, source inventory, libraries
and AI authorship limit independence; these are computational checks, not
outside endorsement or a new Lean theorem. Track A supplies a missing actual
functional input and prevents duplicate vacuum terms. Track B tests typed
coefficient dimensions, dual-coordinate signs, normalization/covariance
distinctions and exact dependency reuse. Education remains nonblocking.

Next establish the complete positive-dimensional Slavnov predecessor census
from actual E2 columns, including OrbitPullback and physical-Euler programs.
Classify JL*C power-sensitive groups using an explicit UV prescription rather
than a scaleless-integral shortcut. A derivative-sector zero is not their
qualification. No full source closure,E5/A5,QAP,measure,contact,finite/IR,
anomaly freedom or physical viability follows from this integration.
Statev113/34of39 unchanged; HB1/C5 blocked,flavor paused,C1_GS uncomputed,
scalar quantum warning,quartet failure,custodyexit2/seven preserved. No accepted
input,benchmark,foundation or remote change; no universal Lean gate.
