"""Actual-action double-longitudinal test of the remaining lower source box."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import permutations,product
import json,os,re,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
ETA=(1,-1,-1,-1);mom=[s.symbols(f'q{a}_0:4',real=True) for a in range(3)];E=[s.symbols(f'e{a}_0:4',real=True) for a in range(3)];eflat=sum((list(v) for v in E),[])
k=s.symbols('k0:4',real=True);p=s.symbols('p0:4',real=True);routing=dict(zip(sum((list(v) for v in mom),[]),[*k,*[-k[i]-p[i] for i in range(4)],*p]));pzero={v:0 for v in p}
@lru_cache(None)
def exact(text):return s.sympify(text)
def packed(P):return [[*key,str(s.expand(z))] for key,z in sorted(P.items())]
def add(P,Q):
    out=dict(P)
    for degree,z in Q.items():out[degree]=out.get(degree,0)+z
    return out
def mul(P,Q):
    out={}
    for a,x in P.items():
        for b,y in Q.items():
            if a+b<=1:out[a+b]=out.get(a+b,0)+x*y
    return out
def sign(seq):return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))
def ast_value(node,env):
    tag=node['node']
    if tag=='ExactScalar':return {0:exact(node['value'])}
    if tag=='Parameter':assert node['name']=='g10' and node['mass_dimension']==0;return {1:s.S.One}
    if tag=='Field':
        assert node['name']=='B';a,mu=(env[n] for n in node['indices']);return {0:E[a][mu]}
    if tag=='PartialDerivative':
        field=node['argument'];assert field['node']=='Field' and field['name']=='B';a,mu=(env[n] for n in field['indices']);return {0:s.I*mom[a][env[node['index']]]*E[a][mu]}
    if tag=='StructureConstant':assert node['name']=='f_plane';return {0:s.LeviCivita(*(env[n] for n in node['indices']))}
    if tag=='Add':
        out={}
        for term in node['terms']:out=add(out,ast_value(term,env))
        return out
    if tag=='OrderedProduct':
        out={0:s.S.One}
        for term in node['factors']:out=mul(out,ast_value(term,env))
        return out
    if tag=='LocalActionTerm':return ast_value(node['density'],env)
    assert tag in ['LorentzContraction','GroupContraction'],tag
    if tag=='LorentzContraction':assert node['metric']=='diag(1,-1,-1,-1)'
    ids=node['contracted_indices'];out={}
    for values in product(range(4) if tag=='LorentzContraction' else range(3),repeat=len(ids)):
        new=env|dict(zip(ids,values));term=ast_value(node['expression'],new)
        factor=s.prod(ETA[v] for v in values) if tag=='LorentzContraction' else 1
        out=add(out,{degree:factor*z for degree,z in term.items()})
    return out
def literal_tensor(action):
    gauges=[n for n in action['local_terms'] if n['sector']=='GAUGE_KINETIC'];assert len(gauges)==1
    cubic=s.expand(ast_value(gauges[0],{}).get(1,0));poly=s.Poly(cubic,*eflat);V={key:s.S.Zero for key in product(range(4),repeat=3)}
    for powers,z in poly.terms():
        assert sum(powers)==3 and all(sum(powers[4*a:4*a+4])==1 for a in range(3))
        key=tuple(next(mu for mu in range(4) if powers[4*a+mu]) for a in range(3));V[key]+=z
    return {key:s.expand(z) for key,z in V.items()},cubic
def bose_tensor(omit=None,flip=None):
    V={key:s.S.Zero for key in product(range(4),repeat=3)}
    for a,b,c in permutations(range(3)):
        if omit==(a,b,c):continue
        sg=sign((a,b,c))*(-1 if flip==(a,b,c) else 1)
        for polar in V:
            if polar[a]==polar[c]:V[polar]+=-s.I*sg*ETA[polar[b]]*ETA[polar[a]]*mom[a][polar[b]]
    return {key:s.expand(z) for key,z in V.items()}
def contraction(V,external=2,deform=False):
    # Relabel all three legs: the first internal leg carries k, the second
    # -k-p and the chosen external leg carries p. Actual mixed Green supplies
    # those covariant momentum components, with no inserted Lorentz metric.
    internal=[a for a in range(3) if a!=external];a,b=internal
    sub={mom[a][mu]:k[mu] for mu in range(4)}|{mom[b][mu]:-k[mu]-p[mu] for mu in range(4)}|{mom[external][mu]:p[mu] for mu in range(4)}
    out={}
    for rho in range(4):
        out[rho]=s.expand(sum(k[mu]*(-k[nu]-p[nu])*((-1) if deform and mu==0 else 1)*V[tuple(rho if n==external else mu if n==a else nu for n in range(3))].subs(sub,simultaneous=True) for mu,nu in product(range(4),repeat=2)))
    return out
def references(role):
    folder=PKG/'frozen_a10_e5_full_hessian';binding=read(folder/'bindings.json');f=folder/(role+'.json');assert binding['complete_retained_Hessian_qualified'] and binding['byte_sha256'][f.relative_to(ROOT).as_posix()]==digest(f)
    ref=read(f)['retained_reference'];assert ref['all643_inverse_directions_both_checked'] and ref['literal_GF_all_413449_entries_matched'] and ref['auxiliary_auxiliary_Green_zero'] and not ref['auxiliary_or_ghost_field_eliminated']
    names=ref['field_order'];assert len(names)==643;v=s.symbols('p0_ref0:4');Q=sum(ETA[mu]*v[mu]**2 for mu in range(4));mix=defaultdict(dict);ghost={};ll=[]
    for i,j,text in ref['reference_Green_raw_C3']['entries']:
        ni,nj=names[i],names[j];z=exact(text)
        bi=re.fullmatch(r'B(\d+)_([0-3])',ni);bj=re.fullmatch(r'B(\d+)_([0-3])',nj);li=re.fullmatch(r'(?:L|b)(\d+)',ni);lj=re.fullmatch(r'(?:L|b)(\d+)',nj)
        if (bi and lj) or (li and bj):
            bm,lm,orientation=(bi,lj,1) if bi else (bj,li,-1);color,mu=int(bm[1]),int(bm[2]);aux=int(lm[1]);factor=s.cancel(z*Q/(orientation*s.I*v[mu]));assert not factor.free_symbols
            mix[(color,aux,orientation)][mu]=factor
        if li and lj:ll.append((ni,nj,text))
        ci=re.fullmatch(r'C(\d+)',ni);cj=re.fullmatch(r'C(\d+)',nj);ai=re.fullmatch(r'(?:ub|bar)(\d+)',ni);aj=re.fullmatch(r'(?:ub|bar)(\d+)',nj)
        if (ci and aj) or (ai and cj):
            cm,am,orientation=(ci,aj,1) if ci else (cj,ai,-1);factor=s.cancel(z*Q/orientation);assert not factor.free_symbols;ghost[(int(cm[1]),int(am[1]),orientation)]=factor
    assert not ll and len(mix)==94 and sum(map(len,mix.values()))==376
    for (i,j,o),components in mix.items():assert set(components)==set(range(4)) and len(set(components.values()))==1 and mix[i,j,-o]==components
    assert {i for i,j,o in mix}=={j for i,j,o in mix}==set(range(45))
    assert len(ghost)==94
    for (i,j,o),z in ghost.items():assert ghost[i,j,-o]==z
    return {'mixed_entries':376,'mixed_color_pairs_both_orientations':[[i,j,o,str(v[0])] for (i,j,o),v in sorted(mix.items())],'ghost_entries':len(ghost),'ghost_color_pairs_both_orientations':[[i,j,o,str(z)] for (i,j,o),z in sorted(ghost.items())],'all45_colors_and4_components':True,'auxiliary_auxiliary_entries_zero':True,'ordinary_BB_reference_not_discarded':True,'no_width_in_mixed_or_ghost_factors':True}
def evidence(role):
    folder=ROOT/'calculations/canonical_so10_single_source_uv_frontier';f=folder/(role+'_result.json');r=read(folder/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(f)]==digest(f)
    old=read(f);target=old['targets']['B_B_C_JL__j0'];candidates={name:v for name,v in target['candidate_families'].items() if v['g']==3 and v['xi']==1 and v['profiles']};assert set(candidates)=={'SL*F*G3*X'}
    v=candidates['SL*F*G3*X'];assert {tuple(p['external_roles']) for p in v['profiles']}=={('BH','BM','CM','JM'),('BM','BM','CM','JM')}
    for profile in v['profiles']:assert profile['explicit_external_jets']==profile['required_UV_Taylor_order']==0 and not profile['uses_BB']
    witnesses=target['witnesses']['SL*F*G3*X']
    for W in witnesses:
        ports=sum(W['internal_ports'],[]);edges=Counter(tuple(sorted((ports[a][0][0],ports[b][0][0]))) for a,b in W['pairs']);assert edges=={('B','L'):2,('C','a'):2}
        idx=W['ordered_vertices'].index('G3');assert all(a[0][0]=='B' for a in W['internal_ports'][idx]) and W['external_ports'][idx][0][0][0]=='B'
    folder=ROOT/'calculations/canonical_so10_source_vector_g3_inputs';f=folder/(role+'_result.json');r=read(folder/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(f)]==digest(f)
    F={}
    for row in read(f)['cubic_inputs']['S']:
        ns=row['word'];J=next(n for n in ns if n.startswith('JBp'));B=next(n for n in ns if n.startswith('Bp'));C=next(n for n in ns if n.startswith('Cp'));i,b,c=int(J[3:]),int(B[2:]),int(C[2:]);z=exact(row['coefficient'])*(-1 if ns.index(C)<ns.index(J) else 1);assert (i,b,c) not in F;F[i,b,c]=z
    assert len(F)==1674
    for triple,z in F.items():
        for order in permutations(range(3)):assert s.expand(F.get(tuple(triple[j] for j in order),0)-sign(order)*z)==0
    return {'family':candidates,'routing_witnesses':witnesses,'source_L_and_X_are_derivative_free':old['vertices']['SL']['jets']==old['vertices']['X']['jets']==0,'F_derivative_order':old['vertices']['F']['jets'],'actual_color_coefficients':len(F),'actual45_color_tensor_totally_antisymmetric':True,'retained_F_literal_jet_patterns':old['vertices']['F']['literal_role_monomials']}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('LOWER_SOURCE_VECTOR_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('LOWER_SOURCE_VECTOR_PEER_POLE_OR_UNDECLARED_READ')
    sys.addaudithook(guard)
    print('STAGE '+role+' authenticated_complete_family_and_actual_color_algebra',flush=True);ev=evidence(role)
    print('STAGE '+role+' every_actual_mixed_and_ghost_inverse',flush=True);ref=references(role)
    action=read(PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    print('STAGE '+role+' full_literal_AST_cubic' if role=='primary' else 'STAGE '+role+' curvature_cross_term_Bose_tensor',flush=True)
    if role=='primary':V,cubic=literal_tensor(action)
    else:V=bose_tensor();cubic=None
    full={str(ext):contraction(V,ext) for ext in range(3)};leading={ext:{rho:s.expand(z.subs(pzero)) for rho,z in D.items()} for ext,D in full.items()}
    loop_degrees={ext:[s.Poly(z,*k).total_degree() if z else -1 for rho,z in sorted(D.items())] for ext,D in full.items()}
    external_degrees={ext:sorted({sum(mon) for z in D.values() for mon,c in s.Poly(z,*p).terms() if c}) for ext,D in full.items()}
    zero=all(not z for D in leading.values() for z in D.values());remainder_safe=all(degree<=1 for values in loop_degrees.values() for degree in values)
    mutants={}
    for label,T in [('omit_one_Bose',bose_tensor(omit=(0,1,2))),('flip_one_Bose',bose_tensor(flip=(0,1,2)))]:
        D=contraction(T);lead={rho:s.expand(z.subs(pzero)) for rho,z in D.items()};assert any(lead.values());mutants[label]={'full_contraction':[[rho,str(z)] for rho,z in sorted(D.items())],'leading_contraction':[[rho,str(z)] for rho,z in sorted(lead.items())]}
    D=contraction(V,deform=True);lead={rho:s.expand(z.subs(pzero)) for rho,z in D.items()};assert any(lead.values());mutants['deform_one_longitudinal_component']={'full_contraction':[[rho,str(z)] for rho,z in sorted(D.items())],'leading_contraction':[[rho,str(z)] for rho,z in sorted(lead.items())]}
    one_external=bose_tensor(omit=(2,0,1));deletion=contraction(one_external);insensitive=all(s.expand((deletion[r]-full['2'][r]).subs(pzero))==0 for r in range(4));assert insensitive and any(s.expand(deletion[r]-full['2'][r]) for r in range(4))
    regulators={'positive_auxiliary_IR_scale_retained':True,'leading_numerator_zero_before_integration':zero,'regulator_is_not_a_physical_input':True,'no_scaleless_integral_zero_used':True,'denominator_scaling_degree':8,'remaining_F_numerator_degree_at_most':1,'remainder_total_loop_degree_at_most':max(z for v in loop_degrees.values() for z in v)+1-8,'finite_nonzero_momentum_contraction_retained':any(z for D in full.values() for z in D.values()),'finite_amplitude_calculated':False}
    # Record every external F-vector component multiplying the prospective
    # zero. Both external B assignments merely permute these16 positions.
    qIR=s.symbols('mIR2',positive=True);ke=s.symbols('ke0:4',real=True);den=(sum(t*t for t in ke)+qIR)**4
    regulated=[[mu,rho,str(s.cancel(ke[mu]*leading['2'][rho]/den))] for mu,rho in product(range(4),repeat=2)]
    result={'schema':'LOWER_AUXILIARY_SOURCE_VECTOR_UV_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_G3_XI_NOJET_LOCAL_LOG_POLE_ZERO' if zero and remainder_safe else 'INCOMPLETE_DOUBLE_LONGITUDINAL_ZERO_NOT_ESTABLISHED','family_evidence':ev,'actual_reference':ref,'all64_cubic_Lorentz_coefficients':packed(V),'full_offshell_double_longitudinal':{ext:[[rho,str(z)] for rho,z in sorted(D.items())] for ext,D in full.items()},'zero_external_momentum_leading':{ext:[[rho,str(z)] for rho,z in sorted(D.items())] for ext,D in leading.items()},'loop_degrees':loop_degrees,'external_momentum_degrees':external_degrees,'negative_controls':mutants,'external_derivative_Bose_omission_insensitive_only_to_zero_jet_target':insensitive,'whole_zero_family_omission_cannot_fix_normalization':zero,'regulator_boundary':regulators,'all16_external_Lorentz_regulated_leading_kernels':regulated,'both_external_B_assignments_covered_by_vertex_tensor':True,'generic_color_identity_uses_qualified_total_antisymmetry':True,'known_Gamma_changed_or_old_loop_rerun':False,'full_source_Slavnov_E5_A5_QAP_IR_finite_or_anomaly_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
