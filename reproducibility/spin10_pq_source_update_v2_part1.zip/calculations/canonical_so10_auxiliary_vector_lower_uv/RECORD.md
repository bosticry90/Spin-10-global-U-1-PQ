# Lower auxiliary-source/vector UV coefficient V1

Baselinebec888445a4a957a87291ff2fa8e184094577e80, AGENTS standing delegation;
statev113/34of39 unchanged. Question: is the complete coefficient-dimension0,
no-jet g10^3*xi JLambda*C*B*B logarithmic pole zero? A zero/nonzero answer is
not inferred from the previously verified source identities or g4 coefficient.

Reuse/authenticate V170's complete conservative source-linear frontier and its
own-role receipts. Exactly one family is permitted at this coupling order:
SL*F*G3*X. Its source/ghost/vector profiles are JM,CM,BM,BH or JM,CM,BM,BM.
Both gauge legs of G3 connect to auxiliary legs through mixed inverses; two
ghost edges complete the proper loop. Any unmatched alternative means this
zero proof is incomplete. All other colors, including unbroken source/ghost
complements, are excluded only by that complete inventory, not deleted by hand.

Test the actual Lorentz prerequisite. Authenticate the full643 reference;
factor every B/L inverse entry into a color constant times the corresponding
momentum component/Q and retain both orientations, all45 colors and all4
Lorentz components. Check all ghost inverses and L/L zeros. No B/B term is
dropped from a routing that contains it; this family has none. Width independence
must follow from these actual entries, not an earlier target's simplification.

Primary evaluates the frozen physical-action gauge AST in the exact g<=1
quotient, substitutes three arbitrary distinct color plane waves and extracts
all64 cubic Lorentz coefficients. Replay derives them through the explicit
six Bose assignments of the curvature's linear/nonlinear cross term. Reuse
qualified actual45-color structure constants and check total antisymmetry;
the generic alternating three-color contraction then covers every color
tensor. Repeated colors have zero antisymmetric factor. No physical field,
coupling, coordinate normalization or accepted gauge is changed.

At momenta k,-k-p,p contract both internal Lorentz legs with their actual
longitudinal momenta. Retain the full polynomial at nonzero external p, all
derivative placements and all choices of the external vector. Test its zeroth
external-momentum Taylor coefficient before integration. Two mixed and two
ghost denominators give loop degree-8; the original two derivative vertices
give degree4 before the prospective cancellation. If the contracted vertex
has loop degree<=1, multiplying any actual first-order F numerator leaves
degree<=2, hence degree<=-6 and UV convergence for the remainder. Otherwise
retain the result as nonzero/inconclusive and do not infer a pole from power
counting alone. Positive-dimensional/finite/other-order targets stay separate.

Avoid a scaleless-integral zero: retain a positive auxiliary infrared scale
in an illustrative Euclidean denominator (k_E^2+m_IR^2)^4. It is a diagnostic
UV/IR separator, not a new physical input. A zero leading numerator must vanish
before either integration or removing that scale. Do not claim the full finite
amplitude vanishes: a nonzero momentum-dependent contraction may survive.

Controls delete one Bose term, flip one such sign, and deform one longitudinal
propagator component. Retain complete mutant polynomials and require nonzero
zeroth-order witnesses. An external-derivative-only term and whole zero-family
omission can be insensitive at this target; report that rather than claiming
normalization tests they cannot provide. Preserve every orientation, all16
external B/F Lorentz pairs, and both external-vector assignments. A separate
frozen validator checks the closed tensor, all symbols/coefficients, reference
factorization, routing, power counting, regulator boundary and controls.

Two sequential read-only120-second/sampled8GiB workers with>=350MiB available
commit, then scoped validation. Freeze code/controller/inputs/allowlists before
execution; retain complete captures and exact failures. No large color tensor,
old pole/full Gamma replay, general compiler or new parameter search is needed.
Ceiling: this complete selected local logarithmic zero only if all premises
hold. Known Gamma145546 stays unchanged. Full source Slavnov,E5/A5,QAP,measure,
finite/IR physics and anomaly freedom remain unqualified. HB1/C5 blocked,
C1_GS uncomputed,flavor paused,scalar warning,custodyexit2/seven preserved.
Track A tests a missing coefficient; Track B tests whether an inexpensive
action-derived identity can replace unnecessary integrations. Shared action,
reference,SymPy and AI authorship limit independence. Education remains
voluntary,concurrent,nonblocking. No accepted benchmark/foundation or outreach.
