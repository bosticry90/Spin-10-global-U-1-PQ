"""Actual local-Ward map and its kernel; diagnostic tensors are not loop poles."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations_with_replacement
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,canonical,decode_typed,rows,act,s,g,zero
from a10_e5_measured_functional_control_v2 import TYPES,kind
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def label(n,role):
    if role=='primary':return kind(n)
    if n.startswith('omega'):return 'omega'
    for prefix,role_name in [('JB','JB'),('Jx_','Jx'),('JC','JC'),('Jub','Ja'),('Jbar','Ja'),('JL','JL'),('Jb','JL'),('ub','a'),('bar','a'),('L','L'),('b','L'),('x_','x'),('A','A'),('B','B'),('C','C')]:
        if n.startswith(prefix):return role_name
    raise AssertionError(n)

def manual(P,w,images):
    out={}
    for word,z in P.items():
        for i,(n,jets) in enumerate(word):
            Q=images[n]
            for mu in jets:Q=w.D(Q,mu)
            one=w.mul({word[:i]:s.S.One},Q,{word[i+1:]:s.S.One})
            for key,value in one.items():out[key]=out.get(key,0)+z*value
    return canonical(out)

def preimage(R,w,connection,role):
    if role=='primary':
        mapping={f'omega{h}':w.var(f'{connection}{h}_0') for h in range(12)}
        # Jet replacement is explicit: a differentiated parameter becomes a
        # connection component, not a differentiated connection field.
        out={}
        for word,z in R.items():
            replacements={v:({((f'{connection}{int(v[0][5:])}_{v[1][0]}',()),):s.S.One}) for v in word if v[0].startswith('omega')}
            terms=[replacements.get(v,{(v,):s.S.One}) for v in word]
            for key,value in w.mul(*terms).items():out[key]=out.get(key,0)-z*value
        return canonical(out)
    out={}
    for word,z in R.items():
        changed=[]
        for n,jets in word:
            if re.fullmatch(r'omega\d+',n):
                assert len(jets)==1;changed.append((connection+n[5:]+'_'+str(jets[0]),()))
            else:changed.append((n,jets))
        # Only an even parameter is replaced by an even connection; the two
        # odd factors retain their order. Canonical multiplication checks it.
        term=w.mul(*({(v,):s.S.One} for v in changed))
        for key,value in term.items():out[key]=out.get(key,0)-z*value
    return canonical(out)

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('AFFINE_WORKER_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('AFFINE_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);w=alphabet();data=read(ROOT/f'calculations/canonical_so10_gauge_source_g2_canonical/{role}_result.json');R=decode_typed(data['new_local_Ward']);assert len(R)==920
    e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');T={n:decode_typed(P) for n,P in e3['operators']['Tb_geometric_and_transported'].items()}
    frontier=read(ROOT/f'calculations/canonical_so10_single_source_uv_frontier/{role}_result.json');patterns=frontier['type_patterns'];assert len(patterns)==33
    independent=[]
    for size in range(1,5):
        for word in combinations_with_replacement(sorted(TYPES),size):
            dim=sum(TYPES[n][0] for n in word)
            if dim<=4 and sum(TYPES[n][1] for n in word)==0 and sum(TYPES[n][2] for n in word)%2==0 and sum(n.startswith('J') for n in word)==1:independent.append([list(word),4-dim,0])
    assert sorted(independent)==patterns
    predecessors=set();checked_columns=0;source_words=0
    for n,P in T.items():
        typ=label(n,role);assert typ in TYPES or typ=='omega'
        for word,z in P.items():
            output=[label(m,role) for m,j in word if label(m,role)!='omega'];params=[j for m,j in word if label(m,role)=='omega']
            assert len(params)==1
            assert sum(a.startswith('J') for a in output)==int(typ.startswith('J'));source_words+=int(typ.startswith('J'))
            for types,jets,cd in patterns:
                if typ not in types:continue
                rest=list(types);rest.remove(typ)
                if sorted(rest+output)!=['C','JB']:continue
                image_jets=sum(len(j) for m,j in word)
                if jets+image_jets!=1 or len(params[0])>1:continue
                if len(params[0])==0 and jets!=1:continue
                for (power,),value in s.Poly(z,g).terms():
                    if value:predecessors.add((tuple(types),jets,3-power))
        checked_columns+=1
    expected={(('C','JB'),1,2),(('A','C','JB'),0,3),(('B','C','JB'),0,3)};assert predecessors==expected,predecessors
    affine_rows=[]
    for connection,ids in [('A',range(12)),('B',range(45))]:
        for h in ids:
            for mu in range(4):
                P=T[f'{connection}{h}_{mu}'];affine={word:z for word,z in P.items() if any(j for n,j in word if n.startswith('omega'))}
                expected_affine={((f'omega{h}',(mu,)),):s.S.One} if h<12 else {}
                assert affine==expected_affine;affine_rows.append([connection,h,mu,1 if affine else 0])
    KA=preimage(R,w,'A',role);KB=preimage(R,w,'B',role);assert len(KA)==len(KB)==920 and w.grade(KA,(4,0,0)) and w.grade(KB,(4,0,0))
    method=(lambda P:canonical(act(P,w,T,role,0))) if role=='primary' else (lambda P:manual(P,w,T))
    WA=method(KA);WB=method(KB);zero(w.add(WA,R),'A_DIAGNOSTIC_PREIMAGE');zero(w.add(WB,R),'B_DIAGNOSTIC_PREIMAGE')
    kernel=canonical(w.add(KA,w.scale(KB,-1)));assert kernel
    WK=method(kernel);zero(WK,'LOCAL_B_MINUS_A_KERNEL')
    wrong_sign=canonical(w.add(method(w.scale(KA,-1)),R));assert wrong_sign
    wrong_affine={n:canonical({word:(-z if n.startswith('B') and any(j for m,j in word if m.startswith('omega')) else z) for word,z in P.items()}) for n,P in T.items()}
    broken=canonical(act(kernel,w,wrong_affine,role,0)) if role=='primary' else manual(kernel,w,wrong_affine);assert broken
    no_parameter_jets={n:canonical({word:z for word,z in P.items() if not any(j for m,j in word if m.startswith('omega'))}) for n,P in T.items()}
    lost=canonical(act(KA,w,no_parameter_jets,role,0)) if role=='primary' else manual(KA,w,no_parameter_jets);assert not lost and R
    families={key:frontier['targets'][key]['candidate_families'] for key in ['A_C_JB__j0','B_C_JB__j0']}
    result={'schema':'G3_GAUGE_SOURCE_AFFINE_DIAGNOSTIC_V1','route':role,'all_background_columns_scanned':checked_columns,'source_word_preservation_checks':source_words,
      'complete33_type_predecessors':[[list(types),jets,gp] for types,jets,gp in sorted(predecessors)],'affine_coefficients_all_components':affine_rows,
      'full_affine_target_domain_per_connection':45*45*12*16,'nonzero_required_target_coefficients':920,'required_target_minus_remainder':rows(w.scale(R,-1)),
      'diagnostic_A_preimage':rows(KA),'diagnostic_B_H_preimage':rows(KB),'diagnostic_A_Ward':rows(WA),'diagnostic_B_Ward':rows(WB),'nonzero_local_kernel':rows(kernel),'kernel_Ward':rows(WK),
      'both_actual_affine_signs_plus_one':True,'B_M_affine_derivative_absent':True,'wrong_affine_sign_detected':True,'parameter_jet_omission_loses_nonzero_target':True,
      'wrong_preimage_sign_detected':True,'full_homogeneous_variations_checked':True,'existing_graph_families':families,
      'required_relation_is_sum_not_individual_poles':True,'actual_g3_pole_computed_or_adopted':False,'diagnostic_added_to_known_Gamma':False,'known_terms':92280,'known_raw_Ward_terms':920,
      'full_source_Slavnov_E5_A5_or_anomaly_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
