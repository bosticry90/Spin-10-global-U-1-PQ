# The Ward condition fixes a sum, not the individual source/vector poles

The paired diagnostics establish that the new920-term local background Ward
remainder constrains the combined A_H and B_H source/vector contribution.
It does not determine either pole separately. No new quantum amplitude was
calculated or added to the partial functional.

Every one of the1334 actual background columns was scanned. All8738 source
image monomials preserve source count. Within the retained eleven-type,
dimension-zero local system, a complete33-pattern check leaves exactly three
predecessor structures for C*JB*partial omega atg3:

| Local predecessor | Coupling order | Role |
| --- | --- | --- |
| JB*partial C | g2 | The measured derivative node already included |
| JB*A_H*C | g3 | An uncomputed affine source/vector companion |
| JB*B*C | g3 | Its uncomputed B_H affine part; B_M has no affine shift |

Both A_h,mu and B_h,mu have affine variation +partial_mu omega_h for all12
H directions and four components. None of the33 B_M directions has that
shift. Thus, after identifying connection labels with their parameter jets,
the necessary condition on the still-uncomputed cubic coefficients is

\[
T_{A_H}+T_{B_H}=-R,
\]

where R is the measured derivative node's local Ward remainder. The affine
target space has45²*12*4²=388800 positions per connection. The actual R has920
nonzero coefficient positions; off-diagonal Lorentz positions have not been
discarded by the domain definition. This is a necessary coefficient relation,
not a predicted value assigned to either unknown loop contribution.

Two explicit algebraic preimages test the ambiguity. Replace differentiated
omega by A_H in -R to obtain K_A; replace it by B_H to obtain K_B. Each has920
local terms. Their complete local variations, including homogeneous terms,
are both exactly -R. The nonzero1840-term difference K_A-K_B has exactly zero
local background Ward variation. Hence even the complete local identity in
this test cannot choose between those two preimages or fix the unconstrained
combination. It also does not determine the heavy B_M cubic contribution.

Neither preimage is a measured pole, adopted counterterm or accepted physical
completion. Membership in the full Spin(10)/Slavnov-admissible counterterm
class has not been established by this background-polynomial calculation.
The explicit preimages show only that this selected background remainder has
a local algebraic preimage in the tested space. They do not establish full
quantum restoration or absence of an anomaly.

Primary typed substitution/even derivation and replay raw-name relabeling/
word Leibniz methods agree on every preimage, variation, affine component and
predecessor. Reversing the preimage sign fails; corrupting B_H's affine sign
breaks the kernel; dropping parameter derivatives erases the nonzero target.
Primary/replay completed in7.293 and11.674 seconds after imports, below their
120-second/8GiB caps. No failed execution occurred. No original loop or
topology calculation was rerun.

The [qualified frontier](../canonical_so10_single_source_uv_frontier/RESULT.md)
already identifies the complete ordinaryg3 graph families in this scope:

| Target | Ordinaryg3 families |
| --- | --- |
| JB*A_H*C | SB*D, SB*F*F, SB*F*U |
| JB*B*C | Those three plus SB*F*G3 |

All surviving ordinary profiles use an ordinary B/B propagator. The old
mixed-only width independence cannot be reused. The additional G3 route in
the B target contains the physical vector self-interaction; it must not be
dropped to make the two targets look alike. Existing g2*xi source/vector
evidence is a different coupling scope.

Next qualify the shared bubble/triangle momentum and graded combinatorial
units for these ordinaryg3 families, including the B-only vector-self-
interaction family. Reuse the existing full reference, vertex/IBP inventories
and finite ultraviolet controls; calculate coefficients from the action before
comparing them with this affine diagnostic. This avoids fitting a convenient
preimage and avoids constructing another general quantum compiler.

Track B: this test recognizes the information an identity cannot supply and
exhibits its nonuniqueness explicitly. Action/poles/type definitions, arithmetic
helpers, software and AI authorship are shared-error risks. The separate
validator checks complete paired objects, exact affine relabeling, the sparse
target, kernel, graph references, captures and hashes. The director's education
remains voluntary, concurrent and nonblocking.

The updated partial functional remains92280 terms with its920-term nonzero
local Ward. Authorityv113/34of39 unchanged; full source/Slavnov,E5/A5,QAP,
finite/IR,measure/anomaly freedom unqualified. HB1/C5 blocked,C1_GS
uncalculated,flavor paused. Prior failures/exclusions,scalar warning and
custodyexit2/seven preserved. No accepted input/benchmark/foundation,protected
evidence,publication or remote action changed.
