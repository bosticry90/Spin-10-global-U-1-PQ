# Ordinary g3 source/vector affine obligation V1

Baseline49b6ec362fa80dabad94c25452a791e3ea3d5325. The qualified new g2
source derivative node produces920 orderg3 local Ward terms,1840 anchored
terms and12 nonzero parameter Eulers. Determine precisely what source/vector
information that identity requires before choosing another loop calculation.

Claims: scan all actual E3 background columns and the complete33-pattern
dimension-zero single-source envelope for predecessors of C*JB*partial omega
atg3. Check source-count preservation so unexamined multi-source types cannot
silently reduce to this target. Retain actual coupling orders and parameter
jets; no type resemblance may substitute for the full action's transformations.

Recover affine coefficients for every A_H/B_H component and verify that heavy
B_M has no affine parameter derivative. Map a generic no-jet JB*C*A_H/B_H
coefficient to its parameter-jet coefficient with the actual signs and full
Lorentz/source/ghost domain. There are45²*12*16=388800 positions per affine
connection; keep off-diagonal Lorentz targets rather than assuming them absent.
The actual920 nonzero rows specify a sparse necessary target in this space.

Construct two DIAGNOSTIC local preimages by replacing differentiated omega
with A_H or B_H in minus the measured remainder. These are algebraic tests
of the linear Ward map, not assigned physical pole values or counterterms.
Calculate their complete local variations including homogeneous terms. Test
whether their difference lies in the local Ward kernel. If so, the identity
cannot distinguish the two contributions. Do not add either to known Gamma,
declare restoration, or infer an uncomputed amplitude from this diagnostic.

Primary uses typed polynomial substitution/established even derivation; replay
uses independent raw-name classification, coefficient relabeling and direct
word Leibniz differentiation. Compare complete preimages, variations and
predecessors. Parameter-jet omission, wrong affine sign and omitted connection
must detect the relevant failure; preserve any true insensitivity. Authenticate
and reuse the existing graph family evidence for the surviving targets, not
another topology enumeration or old loop integration.

Two sequential read-only workers,120seconds after imports,sampled8GiB and
>=350MiB available commit. Freeze inputs/controller/source; own-role reads
only except disclosed common classical metadata/receipts. Preserve full native
failures. Stop at missing premises or resource exhaustion. No parameter search,
new gauge/input/benchmark,blocked-stage activation,source evidence edit,remote
push or new quantum calculation. No generic scattering/quantum compiler.

Ceiling: necessary affine identity relation and demonstrated nonuniqueness or
failure of this particular local preimage. Actual ordinary g3 source/vector
poles remain uncomputed. The updated partial functional stays92280 with its
920-term nonzero Ward. Full source/Slavnov,E5/A5,QAP,finite/IR,measure/anomaly
freedom unqualified; authorityv113/34of39 unchanged,HB1/C5 blocked,C1_GS
uncalculated,flavor paused. Prior failures,scalar warning,custodyexit2/seven
preserved. Shared action/poles/type definitions/helpers/software/AI authorship
limit independence; education stays voluntary, concurrent and nonblocking.
