"""Actual finite-point radial response; inherited operators, no old loop values."""
from pathlib import Path
from hashlib import sha256
import sys,json,time,threading,os
import sympy as S
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
P=S.symbols('p1:9',real=True);eta=S.Symbol('eta',real=True);m=S.Symbol('m',real=True)
loc={**dict(zip(map(str,P),P)),'eta':eta,'m':m};parse=lambda z:S.sympify(z,locals=loc)
matrix=lambda A:S.Matrix([[parse(z) for z in row] for row in A])
def specialize():
 pt=read(C/'canonical_so10_coherent_joint_witness/POINT.json');p1,p2,x,s,z,D,t,delta,e=[S.Rational(pt[n]) for n in ['p1','p2','x','s','z','D','t','Delta','eta']]
 vals=[p1,p2,delta+t/4,t,x/8,(5*s+z)/2-5*D/24,(-3*s-z)/2+5*D/24,(z-s)/4];sub=dict(zip(P,vals));sub[eta]=e
 src=read(C/'canonical_so10_eta_variable_inputs/primary_result.json');b=src['blocks']['weak'];SW=matrix(b['Sigma_principal']).subs(sub);BW=e*matrix(b['eta_stripped_mixing']).subs(sub);FW=matrix(b['phi_constant']).subs(sub);K=S.simplify(BW.H*SW.inv()*BW-FW)
 root=S.trace(K)/2+S.sqrt(S.expand(((K[0,0]-K[1,1])/2)**2+K[0,1]*K[1,0]));sub[m]=root
 raw={n:parse(v).subs(sub) for n,v in src['raw_coefficients'].items()};physical={n:S.simplify(v/(S.sqrt(S.Rational(3,160))**inp.RESCALE.get(n,(0,0))[0]*S.sqrt(S.Rational(3,10))**inp.RESCALE.get(n,(0,0))[1])) for n,v in raw.items()}
 H10=matrix(src['raw_H10']).subs(sub);H=H10.extract([0,1,3],[0,1,3]);G=[S.Integer(60),S.Rational(3,5),S.Rational(3,5)];assert H==H.T and all(H[i,j]==0 for i in range(3) for j in range(3) if i!=j)
 return sub,raw,physical,H,G,src
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('FINITE_RADIAL_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 sub,raw,physical,H,G,src=specialize();cache=read(C/'canonical_so10_singlet_tadpole/original_v2_result.json');slots=cache['slots'];assert len(slots)==34
 degrees=[inp.PHI,{n:inp.RESCALE.get(n,(0,0))[0] for n in inp.NAMES},inp.SDEG]
 count=lambda sector,n:int(sector=='Phi') if n==0 else int(sector in ['Sigma','SigmaBar']) if n==1 else int(sector in ['S','SBar'])
 blocks=[]
 for b in cache['block_inputs']:
  n=len(b['metric']);mats=[S.zeros(n) for _ in slots]
  for k,i,j,z in b['raw_H34_sparse']:mats[k][i,j]=S.sympify(z)
  blocks.append((b,mats))
 filters=read(C/'canonical_so10_joint_scalar_filters/primary_result.json');types={tuple(b['label']):b['type'] for b in filters['records']};pv={S.Symbol('s',real=True):sub[P[5]]+sub[P[6]],S.Symbol('z',real=True):sub[P[5]]+sub[P[6]]+4*sub[P[7]],S.Symbol('x',real=True):8*sub[P[4]],S.Symbol('D',real=True):S.Rational(1,50),S.Symbol('t',real=True):sub[P[3]],S.Symbol('p1',real=True):sub[P[0]],S.Symbol('p2',real=True):sub[P[1]],S.Symbol('p3',real=True):sub[P[2]],S.Symbol('m',real=True):sub[m]}
 protos={name:S.Matrix([[S.sympify(a,locals={str(k):k for k in pv}).subs(pv) for a in row] for row in A]) for name,A in filters['prototypes'].items()}
 for name in ['weak','colored']:
  bb=src['blocks'][name];SS=matrix(bb['Sigma_principal']).subs(sub);XX=sub[eta]*matrix(bb['eta_stripped_mixing']).subs(sub);FF=matrix(bb['phi_constant']).subs(sub);protos[name]=SS.row_join(XX).col_join(XX.H.row_join(sub[m]*S.eye(2)+FF))
 probes=[]
 for digits in [80,110]:
  mp.mp.dps=digits;num=lambda z:mp.mpc(str(S.N(S.re(z),digits+10)),str(S.N(S.im(z),digits+10)))
  real=lambda z:mp.re(num(z));text=lambda z:mp.nstr(mp.re(z),60)
  gm=list(map(real,G));rg=list(map(mp.sqrt,gm));HH=mp.matrix([[real(H[i,j]) for j in range(3)] for i in range(3)]);hc=[HH[i,i]/gm[i] for i in range(3)]
  co=[num(S.im(raw[n]) if part=='im' else S.re(raw[n])) for slot in slots for n,_,part in [slot.partition(':')]]
  expected={name:mp.eighe(mp.matrix([[num(z) for z in row] for row in A.tolist()]),eigvals_only=True) for name,A in protos.items()}
  T=[mp.mpf(0)]*3;B=[mp.mpf(0)]*3;nodim=[mp.mpf(0)]*3;noconj=[mp.mpf(0)]*3;wrong=[mp.mpf(0)]*3;records=[];positive=[];zeros=0
  for bb,rawm in blocks:
   n=len(bb['metric']);roots=[mp.sqrt(real(S.Rational(g))) for g in bb['metric']];mat=[mp.matrix([[num(A[i,j])/(roots[i]*roots[j]) for j in range(n)] for i in range(n)]) for A in rawm];M=sum((a*A for a,A in zip(co,mat)),mp.zeros(n));ev,U=mp.eighe(M);label=tuple(bb['label']);target=expected[types[label]]
   assert len(ev)==len(target) and max(abs(a-b) for a,b in zip(ev,target))<mp.mpf('1e-60');nz=sum(abs(a)<mp.mpf('1e-60') for a in ev)
   assert all(abs(a)<mp.mpf('1e-60') or a>mp.mpf('1e-40') for a in ev);zeros+=bb['dimension']*nz
   positive.extend([a for a in ev if a>mp.mpf('1e-40')]);deriv=[];local=[];diagall=[]
   for r in range(3):
    DD=mp.matrix([[sum(co[k]*mat[k][i,j]*(degrees[r][slot.partition(':')[0]]-count(bb['sectors'][i],r)-count(bb['sectors'][j],r)) for k,slot in enumerate(slots)) for j in range(n)] for i in range(n)]);diag=U.H*DD*U;diagall.append([text(diag[i,i]) for i in range(n)])
    part=sum(a*diag[i,i]*(mp.log(a/60)-1) for i,a in enumerate(ev) if a>mp.mpf('1e-40'));slope=sum(a*diag[i,i] for i,a in enumerate(ev));T[r]+=bb['dimension']*part;B[r]+=bb['dimension']*slope;nodim[r]+=part
    if label[-1]>=0:noconj[r]+=bb['dimension']*part
    bad=mp.matrix([[sum(co[k]*mat[k][i,j]*degrees[r][slot.partition(':')[0]] for k,slot in enumerate(slots)) for j in range(n)] for i in range(n)]);bd=U.H*bad*U;wrong[r]+=bb['dimension']*sum(a*bd[i,i]*(mp.log(a/60)-1) for i,a in enumerate(ev) if a>mp.mpf('1e-40'))
    local.append(text(bb['dimension']*part/(32*mp.pi**2)))
   # Weak phi fraction is the Hellmann derivative d(m_light²)/d(mphi²).
   if label==(0,0,1,-3):
    zero=next(i for i,a in enumerate(ev) if abs(a)<mp.mpf('1e-60'));fraction=sum(abs(U[i,zero])**2 for i,nm in enumerate(bb['sectors']) if nm in ['phi','phiBar'])
   records.append({'label':bb['label'],'type':types[label],'dimension':bb['dimension'],'mass_squared':list(map(text,ev)),'D_radial_in_mass_basis_diagonals':diagall,'raw_tadpole_with_loop_factor':local,'zero_copies':nz})
  assert zeros==38 and sum(bb['dimension']*len(bb['metric']) for bb,_ in blocks)-zeros==290
  assert mp.mpf(0)<fraction<1
  Traw=mp.matrix([mp.re(a)/(32*mp.pi**2) for a in T]);Braw=mp.matrix([mp.re(a)/(32*mp.pi**2) for a in B]);Tcan=[Traw[i]/rg[i] for i in range(3)];response=mp.lu_solve(HH,-Traw)
  grid=[]
  for ratio in [mp.mpf('.5'),mp.mpf(1),mp.mpf(2)]:
   tq=Traw-2*mp.log(ratio)*Braw;dr=mp.lu_solve(HH,-tq);grid.append({'Q_over_Q0':text(ratio),'raw_tadpole':list(map(text,tq)),'raw_linear_response':list(map(text,dr))})
  inc=[-Traw[i]/den for i,den in enumerate([120,mp.mpf(6)/5,mp.mpf(3)/5])];masses=[real(physical[n]) for n in ['mPhi2','mSigma2','mS2']];rel=[abs(a/b) for a,b in zip(inc,masses)]
  assert all(abs(a-b)>mp.mpf('1e-10') for a,b in zip(T,nodim)) and all(abs(a-b)>mp.mpf('1e-10') for a,b in zip(T,noconj)) and all(abs(a-b)>mp.mpf('1e-10') for a,b in zip(T,wrong))
  probes.append({'precision':digits,'physical_mphi2':text(real(sub[m])),'radial_canonical_mass2':list(map(text,hc)),'radial_condition_number':text(max(hc)/min(hc)),'least_positive_scalar_mass2':text(min(positive)),'least_mass2_over_omega2':text(min(positive)/60),'maximum_scalar_mass2':text(max(positive)),'positive_real_directions':290,'zero_real_directions':zeros,'weak_light_phi_fraction':text(fraction),'T_raw':list(map(text,Traw)),'T_canonical':list(map(text,Tcan)),'B_raw':list(map(text,Braw)),'raw_linear_response':list(map(text,response)),'scale_grid':grid,'pure_mass_increments':list(map(text,inc)),'frozen_physical_radial_masses':list(map(text,masses)),'mass_increment_absolute_ratios':list(map(text,rel)),'blocks':records,'max_absolute_raw_response':text(max(abs(a) for a in response))})
  print('STAGE all35_recomputed_scalar_reference_'+str(digits),flush=True)
 for key in ['T_raw','T_canonical','raw_linear_response','pure_mass_increments']:
  assert max(abs(mp.mpf(a)-mp.mpf(b)) for a,b in zip(probes[0][key],probes[1][key]))<mp.mpf('1e-50')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 out={'schema':'FINITE_RADIAL_CONTROL_PRIMARY_V1','status':'COMPLETED_SCALAR_REFERENCE_REQUIRE_INDEPENDENT_RECEIPT','exact_raw_radial_Hessian':[[str(v) for v in row] for row in H.tolist()],'radial_metrics':list(map(str,G)),'physical_parameters':{n:str(v) for n,v in physical.items()},'raw_coefficients':{n:str(v) for n,v in raw.items()},'slots':slots,'probes':probes,'all35_match12_spectral_types':True,'fixed_parent_parameters_under_derivative':True,'old_tadpole_values_reused':False,'fermion_or_gauge_terms_included':False,'full_quantum_control_proved':False,'new_benchmark_adopted':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'seconds_after_import':time.perf_counter()-start,'write_attempts':writes}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
