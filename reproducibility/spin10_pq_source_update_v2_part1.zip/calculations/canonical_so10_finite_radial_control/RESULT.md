# Scalar-reference quantum response at the classically feasible finite point

The SAME [finite exploratory point](../canonical_so10_coherent_joint_witness/POINT.json)
has a substantial scalar-reference vacuum-displacement warning despite its
qualified complete-contact and full328 quartic certificates. The calculated
first-order raw radial response at Q=omega is approximately

```text
Phi     +0.021536808
Sigma   +2.784239977
S       +0.842067763
```

Each starting raw radial scale is1. The Sigma response exceeds its starting
scale and the singlet response is comparable to it. These are FORMAL LINEAR
RESPONSES, not new vacuum positions. A small displacement of this tree vacuum
is unsupported in the declared potential-scalar reference. This is not a
rejection of the complete quantum model, or evidence that all loop corrections
in every input prescription must be large. Qualification requires the actual
independent receipt, complete native captures and raw Git checks.

## What was recomputed and what was inherited

The already qualified34 coefficient operators in all35 small SM mass blocks
were specialized at the NEW point, including its eta=1/10000 and larger weak
root mphi2=0.3995487272668561842. No328-field Hessian was rebuilt; no old
tadpole number was transported. Every new block spectrum agrees with the12
spectral types, with the eta-dependent weak/colored mixing updated. The
qualified290 positive and38 expected zero directions are retained.

The least positive scalar squared mass is0.004791376776868008, in the same
internal units omega²=60. It is positive; that fact alone does not justify
integrating it out as heavy at an unspecified EFT scale. The complete three
radial canonical Hessian is diagonal here, with squared masses

```text
Phi     5.738129272182448
Sigma   0.072
S       1.2
```

Its condition number is79.69624. The Sigma curvature is relatively soft, so
it amplifies its loop slope. The canonical potential-scalar tadpoles, including
the loop factor, are approximately

```text
Phi    -0.9572542182263464
Sigma  -0.1552797368906209
S      -0.7827154613641297
```

Thus neither the loop slopes nor the classical curvatures alone tell the full
response story. The weak light-state phi weight is0.999646041884556, the
Hellmann derivative d(m_light²)/d(mphi²). It is nonzero: the exact light-root
condition is deliberate tuning, not a demonstrated protective symmetry. No
relative fine-tuning statistic divided by the zero tree Higgs mass is defined.

## Fixed inputs, finite first derivatives and incomplete physics

Use the existing DR/MSbar potential-scalar Coleman–Weinberg reference at
Q0²=60. Stationarity fixes the three masses ONCE. Every parent coefficient
is then held fixed during the background derivatives. The complete traces are

\[
T_r=\frac1{32\pi^2}\sum_b d_b\operatorname{tr}
 [M_b(\log(M_b/Q_0^2)-1)D_{b,r}],\qquad
\delta r=-H_{\rm raw}^{-1}T.
\]

The eigenvalues of M are squared masses. The limit m² log(m²)->0 is used
only for this finite FIRST derivative at the qualified zero modes. It does
not define massless orbit box propagators or complete the gauge/IR problem.
The external raw metrics are60,3/5,3/5. Gauge/ghost/vector and fermion/Yukawa
terms are absent from this scalar reference; their cancellation is not assumed.

The primary derives radial responses through partial Euler degrees minus both
external field counts. The independent route reconstructs stationary masses
and the weak root separately, derives the radial Hessian directly from its
tree polynomial, and realifies each complex block before using a real symmetric
eigensolver. Finite differences of the complete regulated CW potential at
fixed coefficients check all three derivatives for b/Q0²=1e-8 and1e-12.
The regulator is a numerical limit control, not a physical mass assignment.
Retuning stationarity under displacement is explicitly rejected: for example
it changes the singlet mass derivative from3.6 to2.4.

## Input-translation burden and predetermined scale checks

The algebraic pure-mass increments that would cancel these scalar-reference
slopes while keeping the raw vacuum coordinates fixed are

| Parameter | Frozen physical value | Conditional increment | Absolute ratio |
| --- | ---: | ---: | ---: |
| mPhi² | -1.3890646361 | +0.0617904941 | 0.04448 |
| mSigma² | -0.018 | +0.1002326392 | 5.56848 |
| mS² | -0.6 | +1.0104813156 | 1.68414 |

These are finite cancellation targets, not adopted renormalized parameters or
a complete input prescription. Sigma and singlet translations are larger than
their tree input magnitudes. That is a burden for THIS input convention;
counterterm solvability does not make the same underlying theory perturbatively
controlled. Compatible same-bare translations and all other input conditions
would still be needed. The general input-prescription issue is discussed in
[Braathen et al., Expectation management](https://link.springer.com/article/10.1140/epjc/s10052-021-09285-4);
that paper does not supply a rescue for this model.

The fixed explicit-log identity T(Q)=T(Q0)-log(Q²/Q0²)B, with no parameter
running or optimization, yields

| Q/Q0 | Phi response | Sigma response | S response |
| --- | ---: | ---: | ---: |
| 1/2 | 0.01498035 | 2.02027097 | 0.59401081 |
| 1 | 0.02153681 | 2.78423998 | 0.84206776 |
| 2 | 0.02809327 | 3.54820899 | 1.09012472 |

The Sigma warning persists across this predetermined reference grid. These are
not RG-improved predictions or an uncertainty interval for an observable.

## Disposition and next scientific priority

The point remains a valid CLASSICAL scalar feasibility example. Its positive
Higgs quartic, full328 quartic certificate, complete-contact bound and local
mass results are preserved. It has not earned a controlled physical quantum
benchmark classification. Full quantum control is UNDERDETERMINED without
the missing contributions and a compatible physical input definition; the
scalar-reference small-shift warning remains explicit.

Before a new determinant expansion or parameter recovery, assess the existing
gauge/vector/orbit reference formulas at the new radial Hessian, keeping their
coupling/gauge-width dependence symbolic or expressly diagnostic. Determine
whether they can alleviate or strengthen the warning in a declared domain.
Do not invent fermion cancellation, resume flavor or choose a scheme to obtain
prettier numbers. Input conditioning and physical relevance take priority over
another mathematically correct partial Higgs threshold.

Track B credits cheap reuse of complete operator data with changed coefficients,
and checking quantum sensitivity immediately after classical coverage. Shared
action/cache, representations, software and analyst remain limitations; this
is bounded solo corroboration, not external scientific endorsement. Education
remains voluntary and nonblocking. Statev113/authority34of39, custodyexit2/seven,
prior failed benchmarks/closed curves, E5/A5, HB1/C5 block, C1_GS gap and human
flavor pause remain unchanged. No scheme, benchmark, physical input or authority
is adopted. The overall investigation is incomplete.
