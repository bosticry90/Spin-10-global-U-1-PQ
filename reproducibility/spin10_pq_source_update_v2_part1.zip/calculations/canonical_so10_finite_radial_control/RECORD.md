# Finite-point radial conditioning and scalar-reference quantum control

Standing AGENTS.md delegation, baseline c3b7d711c5c21bbe2d2ec9ae462734dabd6db03f.
The SAME frozen coherent-joint-witness POINT now passes classical full328
quartic BFB, complete-contact and listed mass/Higgs conditions. Test whether
its three-radial small-displacement approximation is controlled in the
established potential-scalar Coleman–Weinberg reference, before physical
matching. No new point, parameter search, input adoption, flavor resumption
or blocked-stage activation. Reuse all35 qualified coefficient blocks; do not
reconstruct the328-field Hessian or transport old tadpole numbers.

Scientific alternatives: a small scalar-reference response supports only that
test; a response comparable with/exceeding the raw radial backgrounds warns
against a small-shift expansion; missing gauge/fermion/physical input definitions
leave complete quantum control underdetermined. Do not reject the model from
an off-shell scalar subset or turn counterterm reachability into naturalness.

Freeze all eight actual quartics and eta from POINT, solve its already qualified
larger weak root mphi2, and specialize stationary mPhi2,mSigma2,mS2 once.
Then HOLD EVERY parent parameter fixed under the radial derivatives. Use the
actual three-radial Hessian and metrics60,3/5,3/5; do not invert orbit zeros.
Compare all35 specialized block spectra with the12 qualified spectral types
(weak/colored eta mixing updated), and retain290 positive/38 expected zero.
Report the least positive mass, radial eigenvalues, conditioning, weak-root
phi weight and finite mass-input ratios. A mass-sign pass does not establish
that a soft state is heavy enough for an EFT. No tuning measure divided by a
zero tree Higgs mass is defined.

Existing reference: DR/MSbar potential-scalar V1=(1/64pi²) sum_dim m^4
[log(m²/Q²)-3/2], Q0²=omega²=60. First derivatives use m² log(m²)->0
for qualified zero modes; no ordinary massless orbit box or physical
gauge/IR prescription is inferred. For radial scale r and operator M,
D=dM/dr follows monomial field degree minus the two external field counts.
T_raw=(1/32pi²)sum_dim tr[M(log(M/Q²)-1)D].
T_canonical=T_raw/sqrt(G); delta_r=-Hraw^-1*Traw is FORMAL LINEAR RESPONSE,
not a remote quantum vacuum. Recompute all three slopes at the new point.

Use exact matrices with80/110-digit spectral evaluations. Include all
multiplicities/conjugate blocks and normalization. Independent verifier uses
realified symmetric matrices and central differences of the finite regulated
CW potential at fixed coefficients; degree information comes separately from
the29-term field-content ledger. Test regulators b/Q0²=1e-8,1e-12 and a
fixed step1e-20, reporting regulator error rather than physical regulator
adoption. Check positive masses before logs and every expected zero; do not
silently drop small nonzero eigenvalues.

Predetermined scale ratios1/2,1,2 use the explicit log coefficient
B_raw=(1/32pi²)sum_dim tr(M D), holding parameters fixed. This is not an
RG-improved uncertainty or an optimized scale. Pure-mass cancellation targets
are -Traw/(120,6/5,3/5), compared with the NEW stationary physical masses;
the same-bare parameter translation remains required and no finite scheme is
adopted. Missing gauge/fermion terms are neither fitted nor assumed to cancel.
[Braathen et al., Expectation management](https://link.springer.com/article/10.1140/epjc/s10052-021-09285-4)
supplies input-prescription context, not a rescue theorem for this model.

Negative controls: omitted multiplicities/conjugates, external metric, radial
field-count subtraction, and reimposed stationarity under displacement. Preserve
failed/incomplete attempts. Two sequential bounded roles,120seconds after
imports, sampled private8GiB, directly observed350MiB available commit; workers
deny writes. No fresh byte-identical pair or independent physical endorsement.
Shared action/cache/representation, assumptions, software and analyst disclosed.
No new physical scheme, gauge coupling or gauge width. Authority34/39 and
statev113, custodyexit2/seven, all prior failures and human pauses remain.
Scientific and AI-capability objectives equal; education voluntary/nonblocking.
