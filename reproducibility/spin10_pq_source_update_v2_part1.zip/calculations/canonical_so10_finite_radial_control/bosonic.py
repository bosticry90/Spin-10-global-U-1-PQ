"""Known vector/orbit reference, reevaluated at the finite radial Hessian."""
from pathlib import Path
from hashlib import sha256
import json,sys,time,threading,os
import sympy as S
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'bosonic_preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('BOSONIC_REFERENCE_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 old=read(C/'canonical_so10_radial_bosonic_tadpoles/original_v2_result.json');rad=read(O/'primary_result.json');receipt=read(O/'validation_receipt.json');assert receipt['scalar_reference_small_displacement_assumption_failed']
 GP=S.SparseMatrix(old['gauge_Gamma_Phi']);GS=S.SparseMatrix(old['gauge_Gamma_Sigma']);G=GP+GS;assert G==S.SparseMatrix(old['gauge_Gamma']) and GP*GS==GS*GP
 HH=S.Matrix(rad['exact_raw_radial_Hessian']);metrics=list(map(S.Rational,rad['radial_metrics']));assert HH==S.diag(*[HH[i,i] for i in range(3)]) and all(HH[i,i]>0 for i in range(3))
 values=[S.S.Zero,S.Rational(3,5),S.Integer(3),S.Integer(50),S.Rational(253,5)];projectors=[];tables=[]
 for gamma in values:
  P=S.eye(45)
  for v in values:
   if v!=gamma:P=P*(G-v*S.eye(45))/(gamma-v)
  P=P.applyfunc(S.expand);assert P*P==P and G*P==gamma*P;projectors.append(P)
  if gamma==0:continue
  derivatives=[2*S.trace(P*GP),2*S.trace(P*GS),S.S.Zero]
  orbit=[S.simplify(S.trace(P*(HH[0,i]/metrics[0]*GP+HH[1,i]/metrics[1]*GS))/gamma) for i in range(3)]
  assert all(v>=0 for v in derivatives+orbit)
  tables.append({'gamma':str(gamma),'multiplicity':int(S.trace(P)),'Gamma_derivative_trace':list(map(str,derivatives)),'new_orbit_derivative_trace':list(map(str,orbit))})
 assert sum(projectors,S.zeros(45))==S.eye(45) and [int(S.trace(P)) for P in projectors]==[12,8,1,12,12]
 assert sum(S.Rational(r['Gamma_derivative_trace'][0]) for r in tables)==2400 and sum(S.Rational(r['Gamma_derivative_trace'][1]) for r in tables)==30
 # Full unphysical one-derivative reference, not a deleted orbit sector.
 z,v,L,g,xi,t=S.symbols('z v L g xi t',positive=True);K=S.Matrix([[z/xi+g*g*(v+t)**2,-S.I*g*t*S.sqrt(z)],[S.I*g*t*S.sqrt(z),z+L*((v+t)**2-v*v)+xi*g*g*v*v]]);fp=z+xi*g*g*v*(v+t)
 actual=S.cancel(S.diff(K.det(),t).subs(t,0)/(2*K.det().subs(t,0))-S.diff(fp,t)/fp.subs(t,0));assert S.cancel(actual-L*v/(z+xi*g*g*v*v))==0
 ep,m,log=S.symbols('ep m log');bare=(3-2*ep)*m*(-1/ep+log-1);assert S.expand(S.expand(bare).coeff(ep,0)-m*(3*log-1))==0
 assert S.Rational(253,300)<1 and all(S.Rational(r['gamma'])>0 for r in tables)
 mp.mp.dps=90;num=lambda z:mp.mpf(str(S.N(S.sympify(z),100)));text=lambda z:mp.nstr(z,60);scalar=list(map(mp.mpf,rad['probes'][-1]['T_canonical']));examples=[]
 for gg,width in [(mp.mpf('.5'),mp.mpf(1)),(mp.mpf('.5'),mp.mpf(2))]:
  vector=[];orbit=[]
  for i in range(3):
   vt=sum(3*gg**4*num(r['gamma'])*num(r['Gamma_derivative_trace'][i])*(mp.log(gg*gg*num(r['gamma'])/60)-mp.mpf(1)/3) for r in tables)/(32*mp.pi**2*mp.sqrt(num(metrics[i])))
   ot=sum(width*gg*gg*num(r['gamma'])*num(r['new_orbit_derivative_trace'][i])*(mp.log(width*gg*gg*num(r['gamma'])/60)-1) for r in tables)/(32*mp.pi**2*mp.sqrt(num(metrics[i])))
   assert (vt<0 and ot<0) if i<2 else vt==ot==0
   vector.append(vt);orbit.append(ot)
  total=[a+b+c for a,b,c in zip(scalar,vector,orbit)];response=[-total[i]/(mp.sqrt(num(metrics[i]))*num(HH[i,i]/metrics[i])) for i in range(3)];assert response[1]>mp.mpf(rad['probes'][-1]['raw_linear_response'][1])>1
  examples.append({'g_not_adopted':text(gg),'xi_not_adopted':text(width),'vector_canonical':list(map(text,vector)),'orbit_canonical':list(map(text,orbit)),'bosonic_canonical':list(map(text,total)),'raw_linear_response':list(map(text,response))})
 assert any(tables[i]['new_orbit_derivative_trace'][:2]!=old['gauge_spectral_coefficients'][i]['orbit_potential_derivative_trace'] for i in range(4))
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 out={'schema':'FINITE_BOSONIC_REFERENCE_PRIMARY_V2','status':'CONDITIONAL_BOSONIC_NONRESCUE_REQUIRE_INDEPENDENT_RECEIPT','new_gauge_spectral_coefficients':tables,'conditional_domain':'0<g<=1,xi>0,xi*g^2<=1,Q^2=60','all_log_arguments_strictly_below_one':True,'vector_and_orbit_additions_Phi_Sigma_strict_negative':True,'S_gauge_and_orbit_additions_zero':True,'conditional_Sigma_response_greater_than_scalar_reference':True,'examples':examples,'full_unphysical_first_derivative_checked':True,'orbit_curvature_not_omitted':True,'new_orbit_not_old_point_transport':True,'fermion_or_physical_input_completion':False,'physical_gauge_or_scheme_input_adopted':False,'full_model_refuted':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'seconds_after_import':time.perf_counter()-start,'write_attempts':writes}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
