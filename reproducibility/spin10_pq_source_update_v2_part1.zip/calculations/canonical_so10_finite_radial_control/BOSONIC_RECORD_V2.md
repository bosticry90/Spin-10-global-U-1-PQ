# Bounded vector/orbit continuation at the SAME finite point

Standing AGENTS.md delegation after scalar-reference checkpoint
649247a549ea9c8ec8406b2c09aa75617d10b3ba. No scalar input, vacuum ratio,
scheme, physical gauge coupling or width is adopted/changed. Reuse qualified
45-generator Gram geometry and fixed-vacuum gauge-fixing Gaussian relation;
reevaluate every potential-orbit derivative with the NEW radial Hessian.
This is a bounded bosonic reference, not E5 restoration or full quantum control.

Question: can these known bosonic terms reduce the Sigma radial warning in
the explicitly declared diagnostic domain0<g<=1,xi>0,xi*g²<=1 at Q²=60?
This domain is a conditional test, not a measured coupling or a universal
definition of perturbativity. Retain arbitrary g,xi in the formulas. The old
examples g=1/2,xi=1,2 may illustrate them, without adopting physical inputs.

Primary constructs all five Gamma projectors directly from GP+GS, checks all
45 slots, ranks and partial traces, then computes
O_gamma,i=Tr[Pgamma*((Hraw[0,i]/60)GP+(Hraw[1,i]/(3/5))GS)]/gamma.
The scalar-reference Hraw is diagonal at this point. Longitudinal/ghost first
derivatives cancel but orbit curvature remains, as established by the complete
2x2 fixed-gauge Gaussian. Verify that relation and the dimensional vector
finite constant; do not drop ghosts or prematurely set d=4.

Add canonical vector terms
3g^4*sum gamma*Tr(P dGamma_i)*(log(g²gamma/60)-1/3)/(32pi²sqrt(Gi))
and orbit terms
xi*g²*sum gamma*O_gamma,i*(log(xi*g²gamma/60)-1)/(32pi²sqrt(Gi)).
No new momentum integrals or328-field operator compiler. Since all gamma<=
253/5<60, the logarithm arguments are<1 throughout the stated domain. Check
the new O and vector derivative coefficients are nonnegative and relevant
ones nonzero before inferring signs. With positive diagonal radial Hessian,
negative additions worsen, rather than cancel, the positive linear responses.
S contributions vanish only if both its gauge derivative and radial mixing
columns vanish; check these conditions, not merely its gauge-singlet label.

Independent verifier uses joint GP/GS projectors, rather than Gamma-only
projectors, and differentiates the reference vector effective potential with
its5/6 finite constant. Reconstruct orbit weights from simultaneous-sector
ranks; compare both diagnostic examples and strict conditional signs. Negative
controls omit orbit curvature, ghost or finite-dimensional correction, and
compare old/new orbit coefficients to catch old-point transport. Shared
geometry, Ward identity, scalar receipt, software and analyst are explicit.

Two sequential120-second/8-GiB roles, direct350MiB available commit observation,
frozen inputs/sources and write-denying workers. No fresh replay pair promised.
A failure of a premise yields incomplete qualification, never a fitted gauge
choice. Preserve scalar/classical results and all failures. Gauge/IR dependence
of off-shell coordinates and missing fermion/physical input definitions remain;
do not reject the full theory or adopt a benchmark. Authority34/39, custody
exit2/seven, blocked stages and human-paused flavor unchanged. Education
voluntary/nonblocking; scientific and AI capability objectives equal.
