# Complete selected inhomogeneous relation

Keep the qualified even test operation D12=delta_ub12-sum_J V_J E_J^L,
where V_J=delta_ub12 A_J and delta ub12=epsilon12. In this direction the
classical breaking vanishes. The actual kernel is field dependent, so the
mixed Hessian insertion C12 is retained. D12 annihilates the reference Green,
fixed background heat operator and reference determinant. Differentiating
each finite ordered Born product supplies the actual insertion, without
cyclic rearrangement or a quantum-measure assumption.

In the declared g1, zero-jet epsilon12 C Lambda target, all61 nonzero kernel
entries exhaust five cases:

| Entries | Source | Complete exclusion/test |
| --- | --- | --- |
| 4 | JB12 | derivative of epsilon; total jet degree cannot become zero |
| 20 | JC | residual antighost cannot disappear under polynomial multiplication |
| 16 | Jx | kernel has g1; all source-dependent Born coefficients start at g1 |
| 1 | JL12 | source absent from literal master/transported action |
| 20 | Jub | g1 Ja-L proper ghost cycle forbidden by actual H/M propagation |

The Jx statement follows from the actual g0 source action being affine in
integrated fields, so its fluctuation Hessian is zero. The reference/heat
prescription introduces no inverse g. It is not inferred from missing rows.
JL12 absence holds before loops: Q L12=0 and the entire action contains no
JL12. A source not present in the retained action cannot enter its Born terms.

For Jub the affine -Lambda term has zero fluctuation Hessian. Its only proper
g1 source vertex contains CH and aM internally. The only g0 ordinary cubic
supplying the requested external Lambda is X, with CM and aM internally.
Both proper pairings fail: reference odd blocks connect CH-aH and CM-aM,
with no CH-aM. The complete inherited Ja-L family enumeration has no profile.
External-field count excludes additional cubic vertices; dimensionful or
reference-mass insertions cannot make a dimension-zero local coefficient.
The actual source and X components are checked, not just vertex labels.
Adding a forbidden CH-aM propagator admits a routing, a sensitive control.

The current measured source image yields four terms in the unprojected source
correction, all outside this target. They are retained; the whole correction
is not declared zero. Projection onto epsilon12 C Lambda, g1, totaljet0 is zero
by the exhaustive preceding proof. Ordinary IBP preserves total jet degree;
no equation of motion is used to turn a derivative into a mass or auxiliary.

The sourcefree predecessor is exactly the complete measured auxiliary_g1
sector. Its ub12 variation has20 nonzero coefficients among all2025 targets.
The independently calculated normalized insertion has the same coefficients.
Consequently within the retained one-loop local-logarithmic ring,

    [D12 Gamma1]_g1,epsilon-C-Lambda,j0 = [Insertion12]_same target,

with zero difference. Both sides are nonzero. The homogeneous equation
D12 Gamma1=0 is false in this target and is not the scientific requirement.
No new node, counterterm, normalization choice or fitted coefficient is added.

This is a complete selected inhomogeneous identity, not full antighost
dependence, full sourcefree Slavnov, continuum QAP/measure, renormalized
contact-insertion equivalence or E5/A5. The inherited catalogue/action/chart
and one-loop prescription remain shared premises of all checks.
