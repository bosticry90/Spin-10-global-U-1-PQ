"""Complete selected eps12 C Lambda identity, including source exclusions."""
from pathlib import Path
from collections import Counter
from itertools import permutations
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_broken_operator_helpers',OUT.parent/'canonical_so10_broken_antighost_operator/operator_v2.py');m=a.m;b=a.b;h=a.h;l=a.l;s=a.s;read=a.read;digest=a.digest;PKG=a.PKG
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();rte=sys.argv[1];prep=read(OUT/'preparation.json');assert rte in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][rte]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CL_IDENTITY_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);m.setup();tests=[]
 for i in range(45):n='zz_da'+str(i).zfill(2);m.index[n]=len(m.names);tests.append(m.index[n]);m.names.append(n);m.par.append(1)
 E=tests[12];act=lambda P,I:m.action(P,I,'primary',True) if rte=='primary' else m.action(P,I,'replay')
 def types(word):return sorted('e' if n==E else 'C' if m.names[n].startswith('C') else 'L' if m.names[n].startswith(('b','L')) else 'other' for n,j in word)
 def project(P):return {key:z for key,z in P.items() if key[0]==1 and types(key[1])==['C','L','e'] and not any(j for n,j in key[1])}
 ali=b.auth('canonical_so10_antighost_linear_identity',rte+'_v2_result.json');V={m.index[n]:{key:z for key,z in h.from_result(rows).items() if any(i==E for i,j in key[1])} for n,rows in ali['all643_shift_Frechet_images'].items()};V={J:P for J,P in V.items() if P};assert len(V)==61 and sum(map(len,V.values()))==61
 master,mb=b.sealed('frozen_a10_bv_master',rte);e2,eb=b.sealed('frozen_a10_e2_transport',rte);core,cb=b.sealed('frozen_a10_e5_full_hessian',rte);assert core['complete_source_and_GF_Hessian']['g0_source_Hessian_zero'] and core['complete_source_and_GF_Hessian']['all_source_correction_minimum_g_power_at_least_one'] and not core['retained_reference']['physical_width_or_g_inverted'];assert not master['source_only_columns']['L12'] and not e2['complete_columns']['L12']['source_polynomial'] and not any('JL12' in [m.names[m.token(n)[0]] for n in r['word']] for r in master['source_polynomial'])
 classification={};counts=Counter();ja=[]
 for J,P in V.items():
  n=m.names[J];(gp,word),z=next(iter(P.items()))
  if n.startswith('JB'):
   assert gp==0 and len(word)==1 and word[0][0]==E and len(word[0][1])==1;why='POSITIVE_JET_DEGREE_EXCLUDES_NOJET_TARGET'
  elif n.startswith('JC'):
   assert gp==0 and any(m.names[i].startswith('ub') for i,j in word);why='SURVIVING_ANTIGHOST_EXCLUDES_TARGET'
  elif n.startswith('Jx_'):
   assert gp==1 and word==((E,()),);why='SOURCE_G0_ZERO_FROM_ACTUAL_HESSIAN_AND_BORN_G_POWER'
  elif n=='JL12':
   assert gp==0 and word==((E,()),);why='SOURCE_ABSENT_FROM_LITERAL_ACTION'
  elif n.startswith('Jub'):
   assert gp==0 and len(word)==2 and any(m.names[i].startswith('C') for i,j in word) and not any(j for i,j in word);why='JA_L_G1_PROPER_GHOST_CYCLE_FORBIDDEN';ja.append(J)
  else:raise AssertionError(('UNCLASSIFIED_KERNEL',n))
  classification[n]={'kernel':l.rows(P),'reason':why};counts[why]+=1
 assert sorted(counts.values())==[1,4,16,20,20]
 frontier=b.auth('canonical_so10_single_source_uv_frontier',rte+'_result.json');coverage=b.auth('canonical_so10_source_coverage_reconciliation',rte+'_result.json');assert not coverage['incomplete_profiles'] and not coverage['catalogue_extra_scopes'] and len(coverage['profiles'])==177;assert any(r['target']=='Ja_L__j0' and r['status']=='STRUCTURAL_OR_TAYLOR_ZERO' for r in coverage['excluded_patterns']);target=frontier['targets']['Ja_L__j0'];assert target['status']=='STRUCTURAL_OR_TAYLOR_ZERO' and not target['supported_families'] and not target['candidate_families']['SA*X']['profiles'] and target['candidate_families']['SA*X']['g']==1
 # Reproduce the actual proper-cycle obstruction, not a scope-label assertion.
 actual_source_terms=[]
 for J in ja:
  field=m.names[J][1:];R=m.decode(master['source_only_columns'][field]);cubic={key:z for key,z in R.items() if key[0]==1};affine={key:z for key,z in R.items() if key[0]==0};assert cubic and len(affine)==1
  for gp,word in cubic:assert len(word)==2 and all(not j for i,j in word) and sum(m.names[i].startswith('C') and int(m.names[i][1:])<12 for i,j in word)==1 and sum(m.names[i].startswith('ub') for i,j in word)==1
  actual_source_terms.append([m.names[J],len(cubic)])
 X=[r for r in e2['gauge_fixing_density'] if set(('C' if n.partition('__')[0].startswith('C') else 'a' if n.partition('__')[0].startswith('ub') else 'L' if n.partition('__')[0].startswith('L') else 'other') for n in r['word'])=={'C','a','L'} and all(not m.token(n)[1] for n in r['word'])];X0=m.decode(X);X0={key:z for key,z in X0.items() if key[0]==0};assert X0
 for gp,word in X0:assert len(word)==3 and all((not m.names[i].startswith('C') or int(m.names[i][1:])>=12) for i,j in word)
 names=core['retained_reference']['field_order'];ghost_edges={(('CH' if int(names[i][1:])<12 else 'CM') if names[i].startswith('C') else ('aH' if names[i].startswith('bar') else 'aM'),('CH' if int(names[j][1:])<12 else 'CM') if names[j].startswith('C') else ('aH' if names[j].startswith('bar') else 'aM')) for i,j,z in core['retained_reference']['reference_Green_raw_C3']['entries'] if ((names[i].startswith('C') and names[j].startswith(('bar','ub'))) or (names[j].startswith('C') and names[i].startswith(('bar','ub'))))};assert ghost_edges=={('CH','aH'),('aH','CH'),('CM','aM'),('aM','CM')}
 def routings(edges):return [list(p) for p in permutations(('CM','aM')) if ('CH',p[0]) in edges and ('aM',p[1]) in edges]
 allowed=routings(ghost_edges);forbidden=routings(ghost_edges|{('CH','aM'),('aM','CH')});assert not allowed and forbidden
 primitive=b.auth('canonical_so10_local_source_primitive',rte+'_v2_result.json');assert primitive['all643_source_maps_match'] and primitive['current_source_positions']==146663;rows=[r for r in primitive['normalized_source_image'] if r['g']<=1 and any(m.token(n)[0] in V for n in r['word'])];Psource=h.from_result(rows);EL=m.EL_all(Psource,set(V));correction=m.add(*(m.mul(P,EL[J]) for J,P in V.items()));projected=project(correction);assert not projected
 previous=b.auth('canonical_so10_broken_antighost_CL_correspondence',rte+'_result.json');assert previous['scientific_disposition']=='NORMALIZED_SELECTED_INSERTION_MATCHES_EXISTING_AUXILIARY_POLE_VARIATION' and previous['all_later_additions_have_zero_g1_CLa_projection'];A=h.from_result(previous['inherited_auxiliary_g1_sector']);actual=project(act(A,{m.index['ub12']:m.elementary(E)}));insertion=h.from_result(previous['normalized_selected_insertion']);res=m.add(actual,m.scale(projected,-1),m.scale(insertion,-1));assert len(actual)==len(insertion)==20 and not res
 controls={'forbidden_HM_ghost_edge_allows_source_cycle':bool(forbidden),'omit_actual_nonzero_insertion_exposes20_position_remainder':len(actual)==20,'homogeneous_DGamma_zero_fails_selected_target':bool(m.add(actual,m.scale(projected,-1)))}
 for label,J,word in [('fake_Ja_L','Jub13',['Jub13','L13']),('fake_JL_CL','JL12',['C13','JL12','L13'])]:
  fixture=m.decode([{'word':word,'coefficient':'g10'}]);Efake=m.EL_all(fixture,{m.index[J]});mut=project(m.mul(V[m.index[J]],Efake[m.index[J]]));controls[label+'_changes_selected_source_correction']=bool(mut)
 assert all(controls.values())
 result={'schema':'BROKEN_UB12_COMPLETE_SELECTED_CL_IDENTITY_V1','route':rte,'scientific_disposition':'COMPLETE_SELECTED_INHOMOGENEOUS_ANTIGHOST_LOG_RELATION','all61_kernel_classifications':classification,'classification_counts':dict(counts),'actual_Ja_cubic_counts':actual_source_terms,'actual_reference_ghost_edges':sorted(ghost_edges),'proper_Ja_X_routings':allowed,'forbidden_HM_control_routings':forbidden,'qualified177_source_profiles_authenticated':True,'all643_source_Hessian_g0_zero_used_not_empty_table_inference':True,'literal_JL12_absence_proved':True,'selected_known_g0_g1_source_image':l.rows(Psource),'full_selected_source_correction_before_target_projection':l.rows(correction),'complete_projected_source_correction':l.rows(projected),'sourcefree_antighost_variation':l.rows(actual),'independently_normalized_insertion':l.rows(insertion),'complete_relation_difference':l.rows(res),'all2025_target_positions_included':True,'no_source_jet_or_EOM_boundary_shortcut_used':True,'controls':controls,'no_new_loop_functional_source_input_or_authority_change':True,'full_sourcefreeSlavnov_QAP_contacts_measure_IR_E5_A5_proved':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
