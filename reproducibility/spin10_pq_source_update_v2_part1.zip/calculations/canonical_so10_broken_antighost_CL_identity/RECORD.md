# Complete selected inhomogeneous antighost relation V1

Base fb787dfbd07a9b22e06583ad8cac8c742d3d3a52, live AGENTS delegation.
Question BCI.1: close the actual source-predecessor coverage for the eps12
C_j Lambda_k g1/no-jet local logarithmic target, then compare D Gamma1 with
the independently measured/normalized insertion. All45x45 positions, full
Cartesian chart and retained one-loop Born/log prescription. This is one
complete selected INHOMOGENEOUS relation, not homogeneous D Gamma1=0.

Freeze action/source/receipt/code/controller bytes and own-role JSON inputs
before two sequential native routes and independent ordinary-algebra validation.
Each120s afterimports/8GiB sampled private/min350MiB available commit.
No new pole, coefficient fit, full Gamma or generic210-profile compilation.

Use all61 eps12 shift kernels from qualified actual Frechet maps. Enumerate
every possible predecessor by exact coupling, residual fields and jets.
JB derivatives cannot make the zero-jet target; JC kernels retain antighost;
Jx kernels have g1 and source loops have no g0 coefficient by the actual
source-Hessian/no-inverse-g Born theorem. JL12 is absent from the literal
master and transported action, not a zero inferred from an empty loop table.
For Jub candidates authenticate the Ja-L structural-zero frontier and reproduce
the complete g1 proper-loop exclusion from actual CH-aM source and CM-aM-LM
X vertices/reference ghost blocks. Sources/backgrounds external. Dimensionful
or quadratic reference insertions cannot supply this dimension-zero target.
No EOM, inverse coupling/mass, omitted current or forbidden H/M propagation.

Only after these proofs may zero projected source correction be accepted.
Compare actual source-image contraction and all measured sourcefree CLa g1
variation with normalized insertion, retaining the current functional/hash.
Independent route uses ordinary source-left Eulers and explicit proper Wick
matching. Controls: forbidden cross-ghost edges, synthetic nonzero source
coefficients, lost insertion, normalization and homogeneous-zero shortcut.
Synthetic fixtures are never adopted scientific coefficients.

Success is this complete selected local-pole identity in the retained ring,
not full sourcefreeSlavnov/QAP/renormalized contacts/measure/IR/E5/A5.
Seven quantum flags remain false, authority34/39, source38/unbroken proofs,
blocks/pauses/closed routes/custody2-seven unchanged. Shared action/catalogue/
chart/source conventions/software/AI author; not independent expert validation.
