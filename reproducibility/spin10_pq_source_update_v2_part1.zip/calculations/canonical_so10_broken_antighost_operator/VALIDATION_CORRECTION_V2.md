# Validation input declaration correction V2

The independent V1 read guard stopped before mathematical checks because its
external full-capture copies were omitted from the declared JSON inputs.
Preserve complete failed capture and frozen source. Explicitly bind both
external capture files as well as the identical repository copies. Same
mathematical checks,120s/8GiB limits,one corrected validator,one preserved
failed verifier. Do not rerun the completed native routes.
