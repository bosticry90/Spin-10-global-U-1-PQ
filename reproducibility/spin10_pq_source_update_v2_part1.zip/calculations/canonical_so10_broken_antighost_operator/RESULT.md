# Broken-antighost operator result V1

Prospective qualification: require completed independent receipt, actual
resource captures and post-commit exact bytes. Paired native routes agree;
no quantum coefficient or sourcefree restoration has been inferred.

All643 master source-left Eulers match. The33-direction shift kernel has
479 active source columns and2589 g-resolved rows:597 field-independent,
1992 linear. All second field variations vanish. Its242 field-dependent
source columns generate the complete mixed Hessian insertion:99272 exact
positions, including all source summands with their Grassmann order.

The actual master antighost derivative has64 active source columns/1016
positions. Classical breaking consists of1016 source positions and9696
sourcefree positions. Literal gauge-fixing chain rule holds as a raw density.
The broken direction ub12 has zero classical breaking but824 nonzero mixed
Hessian insertion positions. Thus zero classical breaking alone cannot
justify D H=0. These are classical ordered insertion coefficients, not
measured loop poles, anomalies or physical processes. Cancellation after
actual UV contraction remains possible and unmeasured.

The exact general Hessian formula in DERIVATION retains the two mixed terms;
its double-kernel derivative is zero only because actual kernels are affine.
Reference G is unaffected. Differentiate ordered Born factors with these
insertions; do not use divergent trace cyclicity or the unbroken zero-insertion
argument. Independent validation must check every mixed coefficient, actual
complete action components and a curved-kernel fixture.

The32 prior nonlinear source-primitive L13..L44 maps are retained and explicitly
not identified with these gauge-fermion kernels. Renormalized product/contact
and quantum-action assumptions remain unresolved. Seven quantum flags false.
Current functional155110/hashce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1,
sourcefree40309/hashad385556b964a8a3d32511d578ba6e2ad20209a148f2c835c29599bcacbc6c7a,
source inputs and authority34/39 unchanged. No benchmark/input/scheme/policy,
blocked-stage/flavor/remote change. Custody2/seven remains unresolved.

Engineering: one failed native primary preserved (compound-key classifier),
corrected V2 preserves all checks. One unfrozen preparation script syntax
failure preserved externally. Report actual independent failures separately.
Shared action/chart/source conventions/software/AI author; paired algebra is
not independent expert validation. No fresh byte-identical replay pair.

Next smallest action: derive a minimal ordered UV-symbol insertion question
using the complete actual kernels, first the ub12 sector with zero classical
breaking. Establish which mixed contributions survive actual retained Green
contraction and what insertion/contact subtraction is required. Do not infer
that the nonzero classical insertion is a nonzero UV pole or automatically
compile all broken-sector profiles. Full QAP, measure, contact/IR, sourcefree
Slavnov and E5/A5 remain unqualified; Lean remains selective/nonblocking.
