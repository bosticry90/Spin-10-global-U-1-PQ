# Broken operator tuple handling correction V2

Primary V1 failed after constructing the complete mixed insertion: a classifier
iterated the compound (g,word) key instead of its word member. No result or
qualification receipt was emitted. Preserve operator.py, original preparation
and complete primary capture unchanged. Correct only both eps12 classifiers.
Same action, all643/all33 checks, complete contractions, methods and120s/8GiB
limits. One corrected primary and own-role replay, then independent validation.
Unfrozen preparation script syntax error also preserved externally; no worker
ran under that script. This is an engineering failure, not a physics result.
