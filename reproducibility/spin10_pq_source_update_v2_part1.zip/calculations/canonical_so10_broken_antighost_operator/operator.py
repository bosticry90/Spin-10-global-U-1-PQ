"""Actual broken-antighost classical breaking and Hessian insertion maps."""
from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_antighost_helpers',OUT.parent/'canonical_so10_antighost_linear_identity/test_v2.py');b=a.b;m=a.m;h=a.h;l=a.l;s=a.s;ex=a.ex;read=a.read;digest=a.digest;PKG=a.PKG
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('BROKEN_OPERATOR_WRITE')
        if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
    sys.addaudithook(guard);m.setup();stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    def new(n,p):m.index[n]=len(m.names);m.names.append(n);m.par.append(p);return m.index[n]
    tests=[new('zz_da'+str(i).zfill(2),1) for i in range(45)];E=set(tests[12:]);anti=[m.index['ub'+str(i)] for i in range(12,45)];I={n:m.elementary(e) for n,e in zip(anti,tests[12:])};fields=sorted(m.fields);H={n:m.elementary(new('zz_h_'+m.names[n],m.par[n])) for n in fields};K={n:m.elementary(new('zz_k_'+m.names[n],m.par[n])) for n in fields}
    def act(P,I):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
    master,mb=b.sealed('frozen_a10_bv_master',role);e2,eb=b.sealed('frozen_a10_e2_transport',role);ali=b.auth('canonical_so10_antighost_linear_identity',role+'_v2_result.json');A={m.index[n]:m.decode(rows) for n,rows in e2['source_shifts'].items()};R={J:m.decode(master['source_only_columns'][m.names[n]]) for n,J in m.pairs};S=m.decode(master['source_polynomial']);EL=m.EL_all(S,m.sources);assert R==EL and S==m.add(*(m.mul(m.elementary(J),R[J]) for J in R))
    V=stage('all33_actual_shift_Frechet_maps',lambda:{J:act(AJ,I) for J,AJ in A.items()});V={J:P for J,P in V.items() if P};saved={m.index[n]:{key:z for key,z in h.from_result(rows).items() if any(n in E for n,j in key[1])} for n,rows in ali['all643_shift_Frechet_images'].items()};assert V=={J:P for J,P in saved.items() if P}
    degrees=Counter(sum(n in m.fields for n,j in key) for P in V.values() for gp,key in P);assert set(degrees)<= {0,1};nonlinear={J:P for J,P in V.items() if any(n in m.fields for gp,key in P for n,j in key)};dVh={J:act(P,H) for J,P in nonlinear.items()};dVk={J:act(P,K) for J,P in nonlinear.items()};assert all(not act(P,K) for P in dVh.values())
    dR=stage('all643_actual_master_antighost_derivatives',lambda:{J:act(P,I) for J,P in R.items()});dR={J:P for J,P in dR.items() if P};Bsrc=m.add(*(m.mul(m.elementary(J),P) for J,P in dR.items()));B0=m.add(*(m.mul(A[J],P) for J,P in dR.items()));B=m.add(Bsrc,B0)
    actual_deltaS=act(S,I);assert actual_deltaS==Bsrc
    def tree():
        actual=act(m.decode(e2['gauge_fixing_density']),I);chain=m.add(*(m.mul(P,R[J]) for J,P in V.items()),B0);assert actual==chain;return actual
    treeImage=stage('literal_complete_gauge_fixing_chain_rule',tree)
    dRh={J:act(R[J],H) for J in nonlinear};dRk={J:act(R[J],K) for J in nonlinear}
    def mixed():return m.add(*(m.mul(dVh[J],dRk[J]) for J in nonlinear),*(m.mul(dVk[J],dRh[J]) for J in nonlinear))
    C=stage('complete_actual_mixed_Hessian_insertion',mixed);C12={key:z for key,z in C.items() if any(n==tests[12] for n,j in key)};B12={key:z for key,z in B.items() if any(n==tests[12] for n,j in key)}
    transport=b.auth('canonical_so10_source_primitive_transport',role+'_result.json');oldproducts=transport['auxiliary_nonlinear_product_insertions'];assert set(oldproducts)=={'L'+str(i) for i in range(13,45)} and transport['field_maps_nonlinear_count']==32
    ref,rb=b.sealed('frozen_a10_e5_full_hessian',role);import re
    forbidden={m.names[n] for n in anti}|{m.names[J] for J in m.sources};symbols={n for row in ref['retained_reference']['reference_Green_raw_C3']['entries'] for n in re.findall(r'[A-Za-z_]\w*',str(row[2]))};assert not(forbidden&symbols)
    qc,qb=b.sealed('frozen_a10_e5_quantum_contract',role);flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
    # Exact actual-action identity on a fixed complete field pair, all source
    # summands retained. It tests commutator signs without a full Hessian.
    ih={m.index['ub13']:H[m.index['ub13']]};ik={m.index['C13']:K[m.index['C13']]};allI={**I,**{J:m.scale(P,-1) for J,P in V.items()}}
    Shk=act(act(m.add(S,m.decode(e2['gauge_fixing_density'])),ih),ik);lhs=act(Shk,allI);rhs=act(act(B,ih),ik);CS=m.add(*(m.mul(act(V[J],ih),act(R[J],ik)) for J in V),*(m.mul(act(V[J],ik),act(R[J],ih)) for J in V));assert lhs==m.add(rhs,CS)
    fixture=m.mul(m.elementary(m.index['C0']),m.elementary(m.index['ub13']));wrong=m.action(fixture,I,'primary',False);right=act(fixture,I)
    # Removing the second mixed term must be detectable in this complete tensor.
    first=m.add(*(m.mul(dVh[J],dRk[J]) for J in nonlinear));u,v,hb,cov=s.symbols('mean_h mean_k hbar covariance');connected=s.expand((u*v+hb*cov)-u*v);controls={'wrong_odd_prefix_for_even_variation_changes_fixture':wrong!=right,'omit_one_mixed_term_changes_complete_insertion':first!=C,'zero_insertion_shortcut_contradicts_actual_complete_mixed_tensor':bool(C),'nonlinear_mean_product_can_miss_connected_part':connected==hb*cov and connected!=0};assert all(controls.values())
    result={'schema':'BROKEN_ANTIGHOST_OPERATOR_INSERTIONS_V1','route':role,'scientific_disposition':'QUALIFIED_CLASSICAL_BREAKING_AND_FACTORIZED_HESSIAN_INSERTIONS_NOT_QUANTUM_POLE','all643_source_left_Eulers_match_actual_master':True,'all33_kernel_maps':{m.names[J]:l.rows(P) for J,P in V.items()},'kernel_field_degree_counts':dict(degrees),'field_dependent_source_columns':sorted(m.names[J] for J in nonlinear),'delta_master_maps':{m.names[J]:l.rows(P) for J,P in dR.items()},'classical_source_breaking':l.rows(Bsrc),'classical_sourcefree_breaking':l.rows(B0),'literal_gauge_fixing_variation':l.rows(treeImage),'all643_tree_chain_rule_exact_density':True,'all_kernel_second_field_variations_zero':True,'delta_h_kernel_maps':{m.names[J]:l.rows(P) for J,P in dVh.items()},'delta_h_master_maps':{m.names[J]:l.rows(P) for J,P in dRh.items()},'complete_mixed_Hessian_insertion':l.rows(C),'mixed_insertion_positions':len(C),'eps12_classical_breaking_positions':len(B12),'eps12_mixed_insertion_positions':len(C12),'actual_complete_fixed_pair_commutator':{'field_pair':['ub13','C13'],'lhs_source_hessian':l.rows(lhs),'hessian_source_breaking':l.rows(rhs),'complete_mixed_term':l.rows(CS),'exact':True},'old32_flow_products_are_distinct_map':{'fields':sorted(oldproducts),'maps_not_identified_with_gauge_fermion_kernel':True,'all_retained':True},'reference_Green_coefficients_broken_antighost_source_independent':True,'quantum_flags_unchanged':flags,'controls':controls,'actual_quantum_UV_insertion_or_continuum_identity_measured':False,'no_full_Gamma_or_full_Hessian_or_loop_profiles_replayed':True,'source_functional_authority_input_scheme_or_benchmark_change':False,'full_sourcefree_Slavnov_QAP_measure_IR_E5_A5_proved':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
