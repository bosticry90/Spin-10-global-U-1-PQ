# Exact broken-antighost Hessian identity V1

Use the qualified raw-density E2 identity
S = Sphys + sum_J (J+A_J) R_J, with source on the left and
R_J = E_J^L S. All A_J come from the actual gauge fermion, all R_J
from the actual master action. The physical action has no antighost dependence.
Let delta be the EVEN variation delta bar_M = epsilon_M (epsilon odd),
V_J=delta A_J, and D=delta-sum_J V_J E_J^L. No integration by parts
is needed in this source contraction. Then

B = D S = sum_J (J+A_J) delta R_J.

Unlike the unbroken case, delta R_J cannot be presumed zero. Retain the
source and sourcefree parts of this classical breaking separately. The E2
boundary between Q Psi and its gauge-fixing density is not silently dropped;
the identity above uses the already qualified exact source substitution.

For constant even fluctuation variations h,k at fixed sources/backgrounds,
write H[h,k]=delta_k delta_h S. Ordinary even Leibniz, with actual internal
Grassmann ordering, gives

D H[h,k] = delta_k delta_h B
 + sum_J ((delta_k delta_h V_J) R_J
          +(delta_h V_J)(delta_k R_J)
          +(delta_k V_J)(delta_h R_J)).

Proof: [D,delta_h]F=sum_J(delta_h V_J)E_J^L F. Commute D past
the two constant variations in turn; differentiate the first commutator.
This finite-jet identity holds before any divergent trace. Sources stay fixed
in H; D is not a fluctuation variation. Products remain in displayed order.
If actual V is affine in fields, delta_k delta_h V=0, but the two mixed
terms do not thereby vanish. Verify their complete contracted polynomial;
nonzero individual source summands alone do not establish a nonzero sum.

With reference Green operator G independent of these variables, D G=0.
For the retained ordered Born products one may insert D H using ordinary
product differentiation: D(G H)^n=sum_r (G H)^r G(D H)(G H)^(n-1-r).
This is an ordered insertion program, not trace cyclicity, a numerical UV
coefficient, or a proof that renormalized insertions/contacts are defined.
No claim that a zero B alone makes D H vanish. No claim of absence of
cancellations after UV contraction. The 32 prior nonlinear source-primitive
flow maps describe another transformation and must be compared explicitly.

Literature comparator only: Criado and Perez-Victoria, Field redefinitions in
effective theories at higher orders, arXiv:1811.09413v2
(https://arxiv.org/abs/1811.09413). Its distinction between classical and
quantum transformations does not establish the model-specific identity or
renormalization premises. The equations above are derived here from the
actual source-left action and verified exact polynomial rules.
