# Broken-antighost operator and insertion applicability V1

Base 9fcac55e56ffa795efa9fe4bd757619885162b46. Live AGENTS.md delegation;
ordinary bounded research, not a director acceptance or scientific promotion.
Question BAO.1: what actual classical breaking and Hessian insertions prevent
extending the qualified unbroken-antighost zero-insertion proof to the 33
broken directions? Least expensive competent test: exact finite-jet Frechet
algebra of the already qualified E2 shifts and master source maps. Do not
compile 210 loop profiles, materialize Gamma or evaluate a new loop integral.

Types: full 643-field/source Cartesian chart, source-left convention, exact
graded local polynomial ring over existing widths, g10 and fixed backgrounds.
All 33 odd antighost test functions and two independent even variations of
the fields (variation components have their respective field parities).
Sources and backgrounds fixed under those fluctuation variations. No EOM,
auxiliary elimination, discarded current, regulator change or fitted coefficient.

Reuse qualified ALI Frechet maps, actual source-only master columns, E2 exact
source substitution and source-primitive transport/quantum-contract evidence.
Before execution preparation.json binds input, worker and controller bytes,
own-role JSON reads, base commit, types and this derivation. Native routes
sequential: insertion-slot Frechet rule versus left-partial contraction.
Independent validator: ordinary SymPy graded products and direct replacement,
all returned maps and complete mixed insertion, general identity fixtures and
actual-action bridge. Shared action/chart/software/AI author disclosed.

Each native route and independent validation: 120 seconds after imports,
8 GiB sampled private memory, minimum 350 MiB available commit. Preserve
complete captures and every failed run; no auto qualification on exhaustion.
Verify all643 source maps, all33 directions, affine classification, complete
classical breaking and actual mixed Hessian insertion, not one chosen ray.
Controls must expose lost Grassmann sign, missing mixed term and forbidden
replacement of connected products by products of means. Explicitly compare
the prior 32 nonlinear field-redefinition products: they are different maps,
not automatically these gauge-fermion kernels.

Meaningful outcomes: qualified factorized insertion identity and exact actual
coefficients; refuted zero-insertion shortcut; or bounded inconclusive with
precise missing premise. A nonzero insertion is not a measured nonzero UV
pole/anomaly. No claim of full sourcefree Slavnov, QAP, measure, continuum IR,
contact renormalization, E5/A5 or quantum equivalence. Keep seven quantum
flags false, current functional/source bytes, authority34/39 and all blocks.
Do not rerun historical custody or call its exit2/seven PASS.
