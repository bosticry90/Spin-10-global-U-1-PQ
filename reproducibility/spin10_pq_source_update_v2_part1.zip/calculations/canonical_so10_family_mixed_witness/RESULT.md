# An actual mixed-field instability excludes the analytic family

The unchanged analytic family has a negative homogeneous tree quartic on
one explicit allowed Sigma/vector direction throughout0<u<1/10. This is an
actual parent-field witness, unlike the previous failed sufficient bound.
It excludes this family's tree-global-boundedness claim throughout its
contact-allowed range. It does not exclude the whole eight-quartic domain
or Spin(10),and does not overturn the qualified local mass/Higgs results.

Qualification requires the [prospective record](RECORD.md),actual
[independent receipt](validation_receipt.json) and raw Git checks. The overall
model's physical viability remains **INCONCLUSIVE**;authority34/39 unchanged.

In plain language:the energy decreases without bound if these allowed fields
grow together in a particular direction. Positive masses and a positive
relaxed Higgs quartic near the chosen vacuum do not prevent that distant
instability. This is a reason to stop seeking a global stability proof for
this family. It is not a reason to discard the action or every parameter choice.

## Exact field configuration and unchanged inputs

Set Phi=0,S=0,choose Sigma=vacuum_form()+doublet_form(6),and set the complex
10-vector tophi6=-5,phi7=-5i,all other components zero (zero-based indices).
The complete38 nonzero sorted Sigma components are retained in
[primary_result.json](primary_result.json). Hodge +i self-duality is checked.
This is a field direction,not a new numerical model-parameter point.

The actual parent [action](../canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md)
and the existing [family](../canonical_so10_higgs_profile/ANALYTIC_WITNESS_TEST_V3.md)
are unchanged. In physical tensor conventions its Sigma couplings are

```
lambdaSigma1=pi/8,lambdaSigma2=7u/2-5pi/24,
lambdaSigma3=-5u/2+5pi/24,lambdaSigma4=u/4.
```

The fixed nonfamily coefficients remainlambdaSigmaphi1=0.00199571,
lambdaSigmaphi2=-0.03517823,lambdaPhiVector1=lambdaPhiVector2=1/10,
zEta=3/10,zD=0. Canonical rescaling is explicitly undone/rechecked; no
old benchmark's Sigma coefficients or zero eta value are substituted.

All29 parent monomials are evaluated,retaining zero entries. Nonzero quartic
values relevant to the sum are

| Parent monomial | Exact value |
| --- | --- |
| (Q0,Q1,Q2,X131) | (1444,1050,1092,216) |
| N*phi^dagger phi | 1900 |
| phi^dagger K phi | 150 |
| (phi^dagger phi)^2 | 2500 |
| abs(phi.phi)^2 | 0 |
| E.phi | -1980 |
| T_ij phi_i phi_j | 150;its frozen coefficient zD is zero |

Here N=38,phi^dagger phi=50,and the full eta vector hasE6=204,E7=-192i
with the other8 components zero. Thus the actual eta contribution is-1188.
Phi and S set the other quartic monomials to zero by their field content;
they were still retained in the complete evaluation. The negative K term
is included in the full answer and can independently be dropped to form
a conservative upper bound because K is a Hermitian Gram matrix.

## Uniform negative sign; no fitted u or decimal sign decision

The complete quartic is exactly

```
V4 = (757/4)*pi +999*u -1878969771/2000000.
```

Dropping its negative K contribution gives

```
V4 <= (757/4)*pi+999*u-934208151/1000000
   < -1676657057/7000000 < -239,
```

using onlypi<22/7 and0<u<1/10. The inherited contact ellipse implies this
u range; its positive-u quadratic term givesu<85pi/2752<1/10. The pi upper
is anchored by exact rational alternating Machin bounds in the verifier.
The actual quartic,including K,is strictly more negative than this upper.

For each fixed finiteu>0 in this range,the family's dependent masses are
finite even though some diverge asu approaches zero. Under common field
scaling by r,the polynomial isr^4 V4+r^3 V3+r^2 V2;the negative r^4 term
dominates asr grows. Hence the tree potential is unbounded below on this ray.
No claim about the singularu=0 parameter point is needed. No field search,
finite-u selection,optimizer,quantum loop or change of eta was performed.

The same witness supplies an inexpensive necessary condition for tree BFB
throughout the fixed-nonfamily-input eight-quartic comparison:

```
1444*lambdaSigma1+1050*lambdaSigma2+1092*lambdaSigma3
 +216*lambdaSigma4 >=1878969771/2000000.
```

This is one necessary affine constraint,not a sufficient certificate or
proof that the remaining comparison domain is empty. The other four varied
couplings do not enter this ray because Phi=0. The exact source/phase and
fixed-input scope are essential if using this condition elsewhere.

## Consequences and next scientific decision

The prior positive pure-Sigma theorem and308-direction certificate remain
valid:both omit the interacting10-vector on this ray. The local290-positive/
38-zero mass pattern and positive relaxed Higgs theorem remain valid within
their original assumptions. Their coexistence never implied global BFB.
The old positive-point eta-profile tests also remain valid at their own
couplings;they cannot be transported to the new analytic family.

Stop further attempts to certify global tree stability or complete finite
matching for this family as an acceptable globally stable benchmark. There
is no adopted replacement benchmark to revoke. A metastable effective theory,
quantum improvement,cutoff or new operators would require a distinct physical
question and justification;none is assumed or authorized by this result.
This bounded tree failure does not settle all possible quantum behavior.

Before any further finite candidate search,include this cheap necessary
mixed-field condition alongside the existing mass/contact/Higgs conditions.
Determine whether structural compatibility remains in the already authorized
comparison;do not automatically invent another family or vary fixed eta to
evade the result. If that question exceeds current scope or needs new inputs,
bring the concrete scientific choice to the director. Full scattering and
quantum control remain separate obligations,not reasons to ignore this failure.

## Verification and AI-capability assessment

The primary literal29-monomial oracle is compared with independent K-first
quartics,target-joined X131,an explicit Pauli/Kronecker eta calculation using
the previously qualified normalizationf=-4E,and interior-form K/T contractions.
All29 monomial values,four Sigma quartics and all10 eta components must match.
Wrong chirality,conjugation/eta phase,eta-off and homogeneous scaling controls
check the failure interpretation. The eta-off comparator is diagnostic only;
its coefficient is not changed in the tested model. The complete Clifford
map theorem and old contact proof are reused,not counted as fresh reproductions.

Both native roles have120-second/8GiB limits with direct350MiB prelaunch
commit observations. Source/input integrity,current read-only preflight and
raw staged/HEAD bytes are checked. No fresh byte-identical replay pair or
external expert verification is claimed. Evidence validation succeeds only
if it authenticates the actual failed scientific gate without relabeling it PASS.

Track B:the useful step was rechecking a known interacting shape with the
changed family,rather than interpreting a loose norm bound as either proof
or instability. The earlier failure to prioritize this elementary exact
mixed-ray test before the Clifford bound is a research-efficiency limitation.
Using sophisticated representation machinery did not make that earlier
question the most decisive one. Shared action,normalizations,inherited map,
some arithmetic,Python/SymPy and analyst remain common-error risks. This is
bounded computational corroboration,no experimental confirmation or general
demonstration of autonomous scientific reliability. Education remains voluntary
and nonblocking;science and AI-capability objectives remain equally important.

Preserveproject_state.json,sealed README,authority34/39,historical custody
exit2/seven references,original benchmark perturbativity failures,earlier
unstable trials,quartetFAIL,E5/A5unqualified,HB1/C5block,C1_GSgap and flavor
pause. No foundational change,new benchmark,remote push,publication,outreach
or scientific-authority promotion. The overall investigation remains active.
