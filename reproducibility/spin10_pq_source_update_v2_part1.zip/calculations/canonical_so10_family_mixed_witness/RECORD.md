# Mixed Sigma/vector witness for the unchanged analytic family V1

Previous goal turn:PROGRESS,aface76 qualified a global eta norm bound but
its fixed full328 sufficient certificate failed. That was not an instability.
Current preflight:clean main,unchanged statev113/34of39,no active A10/M08 jobs.

Scientific question: does the same fixed analytic family actually fail tree
global boundedness on a cheap explicit mixed field direction? Existing exact
data already includes Sigma=vacuum_form()+doublet_form(6),N=38 and eta source
components E6=204,E7=-192i. Its source norm is large relative to the new
family's quartic. Reusing the old positive-point profile's PASS would be
invalid because the Sigma couplings changed. This test can decide whether
further stability-proof work on this family is justified.

Freeze ONE field shape,not a scalar parameter point or optimization:
Phi=0,S=0,Sigma=vacuum_form()+doublet_form(6),phi6=-5,phi7=-5i,other phi=0.
The rounded equal magnitudes preserve the eta-lowering phase and make
phi.phi=0. No amplitude adjustment after seeing the result. Types are the
parent real54,complex selfdual126,complex10 and complex singlet. Use the same
parent action,field normalization and analytic family asff00e64,c8d55ef.
All four mixed/vector coefficients and eta,zD stay at their actual values.

Compute all29 parent invariant values through the literal tensor oracle,
including zeros and nonzero monomials with zero frozen coefficients. Rebuild
the current physical coefficients from the canonical source and its exact
rescaling; change only the existing eight-quartic analytic family. Obtain the
exact affine expression in pi and u. Do not assign finite u or use decimals
to determine its sign. K is a Hermitian Gram matrix,so its negative coefficient
can also be dropped for a rigorous upper bound. Use pi<22/7 and0<u<1/10,
the inherited contact-allowed necessary range. A uniform strictly negative
upper is an actual unbounded-below ray for every finite member in that range:
under common field scaling,r^4V4 dominates the quadratic/cubic terms.

If that sign is not established,report INCONCLUSIVE for this fixed witness;
do not replace it with another shape. A contradiction between independent
evaluations stops qualification. A negative result excludes this analytic
family's tree-global-stability claim,not the whole eight-quartic domain,
Spin(10),the invariant action,local mass/Higgs theorems or all quantum theories.
Finite metastability,loop improvement and ultraviolet completion are separate
uncomputed questions; do not silently invoke them to erase a tree failure.

Independent route:K-first quartic contractions and target-joined X131;
Pauli/Kronecker eta vector using the qualified Clifford normalizationf=-4E;
direct Gram contraction for K. Compare every retained invariant/source value,
the exact full quartic and rational uniform sign bound. Reuse complete map
and invariant proofs rather than rerun6120 identities or8001-pair spectrum.
Controls:wrong eta phase/conjugation,eta removed,homogeneous scaling and
chirality. Do not claim a finite replay or global positive certificate.

Two sequential native roles,each120seconds after imports,8GiB sampled private
limit and350MiB directly observed prelaunch commit. Freeze inputs/sources;
capture failures/incompleteness,require actual receipt,current read-only
preflight and raw index/HEAD/worktree byte checks before local commit. No
automatic retries,no parameter search,no new benchmark,no loops or flavor
resume. The current question is a necessary classical constraint authorized
within the existing bounded analytical continuation.

Equal science/AI-capability objectives:assess relevance and failure detection,
not favorable numbers or calculation volume. Education voluntary/nonblocking.
Preserveproject_state.json,sealed README,authority34/39,custody exit2/seven,
all previous successful/failed evidence,quartetFAIL,E5/A5unqualified,HB1/C5block,
C1_GSgap and flavor pause. Director acceptance remains separate. No outreach,
publication,remote push,branch/worktree or foundational changes.
