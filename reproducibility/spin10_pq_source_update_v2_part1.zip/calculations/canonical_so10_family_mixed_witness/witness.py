"""One exact mixed parent-field direction; no search or model parameter fit."""
from pathlib import Path
from hashlib import sha256
import json,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_full_hessian'));from parent_bilinear_oracle import State,invariant_values,REAL_NAMES,COMPLEX_NAMES
sys.path.insert(0,str(C/'canonical_so10_scalar_reconstruction'));from verify_eta1_doublet_mixing import vacuum_form,doublet_form,hodge_eigencheck
from certify_sigma_quartics import add_forms
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('MIXED_WITNESS_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 F=add_forms(vacuum_form(),doublet_form(6));hodge_eigencheck(F);frozen=read(C/'canonical_so10_sigma_ray_screen/primary_result.json')['rows'][2];assert F=={tuple(I):tuple(z) for I,z in frozen['form']}
 phi=(0,)*6+(-5,-5*s.I,0,0);state=State(s.zeros(10),F,phi,0);inv={n:s.expand(v) for n,v in invariant_values(state).items()};assert len(inv)==29
 print('STAGE complete_literal_parent29',flush=True)
 raw=inputs.coefficients(0);b=s.sqrt(s.Rational(3,160));ss=s.sqrt(s.Rational(3,10));c={n:s.simplify(raw[n]/b**inputs.RESCALE.get(n,(0,0))[0]/ss**inputs.RESCALE.get(n,(0,0))[1]) for n in raw}
 assert c['zEta']==s.Rational(3,10) and c['zD']==0 and c['lambdaSigmaphi2']<0 and c['lambdaPhiVector1']==s.Rational(1,10)
 u=s.symbols('u',positive=True);t=(s.sqrt(s.Rational(2070819875283,10**13)+s.Rational(324,25)*u*u)-6*u+u*u)/25
 family={'lambdaPhi1':s.pi/8,'lambdaPhi2':s.pi,'lambdaPhiSigma1':t/4,'lambdaPhiSigma2':t,'lambdaSigma1':s.pi/8,'lambdaSigma2':7*u/2-5*s.pi/24,'lambdaSigma3':-5*u/2+5*s.pi/24,'lambdaSigma4':u/4};c.update(family)
 q4=lambda val:s.expand(sum(c[n]*val[n] for n in REAL_NAMES[6:])+sum(2*s.re(c[n]*val[n]) for n in ['z4','zK','zEta','zD']))
 q=q4(inv);assert not q.has(s.sqrt(s.Rational(2070819875283,10**13)+s.Rational(324,25)*u*u))
 U=s.expand(q-c['lambdaSigmaphi2']*inv['lambdaSigmaphi2']);A=U.coeff(s.pi);B=U.coeff(u);D=s.expand(U-A*s.pi-B*u);assert A>0 and B>0 and D.is_Rational and inv['lambdaSigmaphi2']>=0
 upper=s.expand(A*s.Rational(22,7)+B/s.Integer(10)+D);negative=bool(upper<0)
 eta=2*s.re(c['zEta']*inv['zEta']);flipped=invariant_values(State(s.zeros(10),F,tuple(-z for z in phi),0));assert s.expand(flipped['zEta']+inv['zEta'])==0
 qflip=q4(flipped);assert s.expand(qflip-q+2*eta)==0 and eta!=0
 scaledF={I:(2*a,2*d) for I,(a,d) in F.items()};scaled=invariant_values(State(s.zeros(10),scaledF,tuple(2*z for z in phi),0));assert all(s.expand(scaled[n]-16*inv[n])==0 for n in REAL_NAMES[6:]+('z4','zK','zEta','zD')) and s.expand(q4(scaled)-16*q)==0
 print('STAGE phase_and_full_parent_scaling_controls',flush=True)
 Q=[inv['lambdaSigma'+str(j)] for j in range(1,5)];assert Q==list(map(s.Rational,frozen['raw_quartics']))
 polynomial=s.Poly(q,s.pi,u);co=[q.coeff(s.pi),q.coeff(u),s.expand(q-q.coeff(s.pi)*s.pi-q.coeff(u)*u)];assert all(z.is_Rational for z in co)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-started<120
 result={'schema':'FAMILY_MIXED_WITNESS_PRIMARY_V1','status':'EXACT_PARENT_RAY_REQUIRES_INDEPENDENT_RECEIPT','base_commit':prep['base_commit'],'Sigma':[[list(I),list(z)] for I,z in sorted(F.items())],'phi':[[str(s.re(z)),str(s.im(z))] for z in phi],'Phi_zero':True,'S_zero':True,'parent_invariant_values':{n:str(v) for n,v in inv.items()},'current_fixed_quartic_coefficients':{n:str(v) for n,v in c.items() if n in list(REAL_NAMES[6:])+['z4','zK','zEta','zD'] and n not in family},'Sigma_quartics':list(map(str,Q)),'full_quartic_pi_u_constant':list(map(str,co)),'full_quartic':str(q),'upper_drop_negative_K_pi_u_constant':list(map(str,[A,B,D])),'uniform_rational_upper':str(upper),'u_range':'0<u<1/10','actual_negative_parent_field_witness':negative,'analytic_family_tree_BFB_excluded':negative,'field_shape_count':1,'new_parameter_search':False,'new_numerical_model_points':0,'new_benchmark_adopted':False,'whole_eight_quartic_domain_excluded':False,'Spin10_refuted':False,'scientific_authority_changed':False,'physical_viability_of_whole_model_decided':False,'whole_goal_complete':False,'same_field_homogeneity_controls':True,'eta_flip_control':True,'new_flavor_work':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 timer.cancel();print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}),flush=True)
if __name__=='__main__':main()
