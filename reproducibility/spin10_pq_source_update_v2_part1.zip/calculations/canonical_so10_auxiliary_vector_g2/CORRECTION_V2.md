# Zero-polynomial residue correction V2

The primary worker completed. The original replay stopped in its first
Feynman-parameter UV unit: an exactly zero differentiated polynomial was
passed to the homogeneous nonzero-monomial check. It has zero residue and
no nonzero monomial. Preserve the failed replay source and complete capture.

V2 skips exactly zero summands before checking every nonzero homogeneous
term. It changes no nonzero kernel, normalization, physical premise or
acceptance condition. Reuse the completed primary and run only the corrected
replay with the same180-second/8-GiB limits. Routine correction under live
AGENTS; no new physics/search or altered resource ceiling.
