# Actual ordinary auxiliary-vector mixing pole V1

Baseline1afb41c963c37ef03bf6bcf781983c0bd3cb9a27. The preceding increment
integrated the measured ghost pole and isolated an actual unmeasured input,
not a failure of the full theory. Question AV2: determine the ordinary g10^2
coefficient of Lambda^T M partial_mu B^mu in common
hbar/(32*pi^2*epsilon_UV) units, for all45x45 ordered physical positions.
Keep both reference widths symbolic. No required cancellation supplies M.

The authenticated full source-free cycle census admits five coefficient-
dimension-zero/one-jet profiles, in U*U and G3*U. First check this complete
set and retain its actual roles/derivative placements. A_H is an external
background without a reference edge; its sole Lambda_H interaction is
linear in quantum B_H, so the two-quantum Hessian vanishes. Positive-
dimensional insertions cannot contribute to this dimension-zero target.
Do not transfer zeros to finite, power-sensitive, other-jet or other-field
amplitudes. No old508-Euler or whole-QGamma replay.

Freeze code, action, GF, reference, charts, classical color evidence,
controllers and bounded assumptions before computation. Two sequential
read-only workers:180 seconds after imports, sampled8GiB private memory,
minimum350MiB available commit. Independent validation:180seconds/8GiB.
Resource exhaustion is incomplete; preserve every failure and source version.

Derive the universal two-cubic-vertex bosonic units before releasing actual
group data. Primary uses the quadratic-Hessian Born trace including both
cyclic orders and internal starts. Replay uses explicit Wick pairings.
The G3 tensor comes from the literal curvature action versus all Bose
permutations of its cross term. Retain every derivative placement. Routing:
Lambda(-p), B(p); first internal vectors carry k and p-k. The reverse mixed
Green has reversed momentum; do not mistake its fixed-momentum antisymmetry
for a sign on the routed contraction. Prove the actual full vector/auxiliary
kinetic inverse, both orders, zero Lambda-Lambda edge and its literal GF
sign. Reuse the qualified lower-g result as prior evidence, not a new replay.

Primary extracts every first Taylor/Lorentz position of the homogeneous
degree-minus4 UV term. Replay independently shifts a Feynman parameter,
including one-denominator cases. Use positive UV annulus/nonexceptional p
and a positive auxiliary IR scale only as a mathematical separation. No
whole scaleless, finite, physical IR or cutoff amplitude zero is inferred.
Retain the actual Minkowski 2i radial normalization and divide by the
ordered local i*p_rho*eta_rho factor. Check all16 Lorentz positions/family.

Then reconstruct the actual g Lambda B B interaction from all4 literal GF
copies, with exact field metrics/dual charts and no internal A. Retain its
full symmetric two-vector Hessian; check the qualified classical adjoint
tensor rather than inventing a normalization. Contract actual color tensors
by sparse component sums versus matrix products, not a Ward prediction.
Check all2025 positions/zero complement, physical reality, all12 constant-H
covariance identities, canonical raw/inverse charts and family components.

Controls omit a cyclic order, reverse a mixed Green orientation, omit either
complete family or a longitudinal part, and perturb a cubic derivative term
where sensitive. Disclose insensitive controls. The workers must not read
current Gamma, primitive, needed mixing matrix, peer output or a desired
Slavnov cancellation. Classical color archives also contain unrelated old
source-pole columns; only their authenticated classical tensors may be used.
Do not claim this is independent of their shared derivation assumptions.

Independent validation must reconstruct the routed unit kernels and UV
moments, literal cubic/kinetic/color signs, both family contractions and
normalizations, and controls. Paired coefficient agreement is necessary,
not independent expert validation. Shared action, charts, UV prescription,
prior evidence, software and AI authorship limit independence. Track B tests
efficient reduction and sign discipline after recent implementation failures.

Only after qualification may a separately frozen dependent comparison or
canonical integration use the new actual pole. This record does not fit,
adopt or integrate it. No protected promotion:fullE5/A5,QAP,contacts,
Legendre/measure/IR,anomaly freedom,physical viability unqualified;34/39,
HB1/C5 block,flavor pause,C1_GS gap,quartet failure,scalar warning,closed
routes,custodyexit2/seven remain. No input,scheme,benchmark,foundation,
policy or remote change. Education voluntary/nonblocking;Lean selective.
