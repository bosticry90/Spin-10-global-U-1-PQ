"""Action-derived ordinary auxiliary/vector pole; no identity prediction read."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,ETA,cm,canonical,decode_typed
from a10_e5_measured_functional_v3 import frames
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(z);z.loader.exec_module(m);return m
low=load('qualified_literal_YM_AST',OUT.parent/'canonical_so10_auxiliary_vector_lower_uv/lower.py')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
k=list(s.symbols('av_k0:4',real=True));p=list(s.symbols('av_p0:4',real=True));K,R=s.symbols('av_K av_R',nonzero=True);WH,WM=s.symbols('reference_width_H reference_width_M',real=True);ZERO=dict.fromkeys(p,0);r=[p[i]-k[i] for i in range(4)]
def compact(z):return s.cancel(s.expand(z))
def D(q,Q,W):return s.Matrix(4,4,lambda a,b:-ETA[a]*int(a==b)/Q+(1-W)*q[a]*q[b]/Q**2)
def pack(A):return [[i,j,str(s.expand(z))] for (i,j),z in sorted(A.todok().items()) if s.expand(z)!=0]
def unpack(A):return s.SparseMatrix(45,45,{(i,j):s.sympify(z) for i,j,z in A})
def principal():
    q=s.Matrix(k);metric=s.diag(*ETA);up=metric*q;Q=(q.T*up)[0];W=s.Symbol('av_width',real=True)
    H=(-Q*metric+up*up.T).row_join(s.I*up).col_join((-s.I*up.T).row_join(s.Matrix([[W]])))
    G=D(q,Q,W).row_join(s.I*q/Q).col_join((-s.I*q.T/Q).row_join(s.zeros(1)))
    assert all(compact(z)==0 for z in H*G-s.eye(5)) and all(compact(z)==0 for z in G*H-s.eye(5));return True
def trace4(A,B,C,E):
    b=defaultdict(list);c=defaultdict(list)
    for (i,j),z in B.items():b[i].append((j,z))
    for (i,j),z in C.items():c[i].append((j,z))
    return s.Add(*(v*w*x*E.get((l,i),0) for (i,j),v in A.items() for kk,w in b[j] for l,x in c[kk]))
def kernel(V,rho,family,role):
    X=s.symbols('av_X0:4');Y=s.symbols('av_Y0:4');U=s.symbols('av_U0:4');Z=s.symbols('av_Z0:4');L=s.Symbol('av_L');Dx=D(k,K,WH);Dy=D(r,R,WM)
    names=[*X,*Y,*U,*Z] if family=='GU' else [*X,*Y,*U,L];pos={v:i for i,v in enumerate(names)};A=sum(ETA[a]*X[a]*Y[a] for a in range(4));B=sum(V[mu,nu,rho]*U[mu]*Z[nu] for mu,nu in product(range(4),repeat=2)) if family=='GU' else ETA[rho]*U[rho]*L
    Green={}
    for a,b in product(range(4),repeat=2):
        Green[pos[X[a]],pos[U[b]]]=Dx[a,b];Green[pos[U[b]],pos[X[a]]]=Dx[a,b]
        if family=='GU':Green[pos[Y[a]],pos[Z[b]]]=Dy[a,b];Green[pos[Z[b]],pos[Y[a]]]=Dy[a,b]
    if family=='UU':
        for a in range(4):Green[pos[Y[a]],pos[L]]=Green[pos[L],pos[Y[a]]]=s.I*r[a]/R
    Green={ij:z for ij,z in Green.items() if z}
    if role=='primary':
        H1=s.hessian(A,names).todok();H2=s.hessian(B,names).todok();parts=[-s.I*trace4(Green,H1,Green,H2)/4,-s.I*trace4(Green,H2,Green,H1)/4]
    else:
        # Two connected Gaussian contractions, one for each vertex order.
        pair=sum(ETA[a]*Dx[a,mu]*Dy[a,nu]*V[mu,nu,rho] for a,mu,nu in product(range(4),repeat=3)) if family=='GU' else sum(ETA[a]*ETA[rho]*Dx[a,rho]*s.I*r[a]/R for a in range(4))
        parts=[-s.I*pair/2,-s.I*pair/2]
    parts=list(map(compact,parts));assert compact(parts[0]-parts[1])==0;return compact(sum(parts)),parts
def average(P,ell,radial):
    out=0
    for term in s.Add.make_args(s.expand(P)):
        if not term:continue
        powers=term.as_powers_dict();a=[int(powers.get(q,0)) for q in ell];b=int(powers.get(radial,0));assert min(a)>=0 and sum(a)+2*b==-4,(a,b,term)
        if any(j%2 for j in a):continue
        half=sum(a)//2;factor=s.S.One
        for j in range(half):factor/=4+2*j
        for mu,n in enumerate(a):factor*=(s.factorial2(n-1) if n else 1)*ETA[mu]**(n//2)
        out+=term/s.prod(q**n for q,n in zip(ell,a))/radial**b*factor
    return s.expand(2*s.I*out)
def residue(P,mu,role):
    if role=='primary':return average(s.expand((s.diff(P,p[mu])-2*ETA[mu]*(k[mu]-p[mu])*s.diff(P,R)).subs(ZERO).subs(R,K)),k,K)
    grouped=defaultdict(lambda:s.S.Zero)
    for term in s.Add.make_args(s.expand(P)):
        if not term:continue
        powers=term.as_powers_dict();a=-int(powers.get(K,0));b=-int(powers.get(R,0));assert a>=0 and b>=0 and a+b>0;grouped[a,b]+=term*K**a*R**b
    t=s.Symbol('av_t',real=True);out=0
    for (a,b),N in grouped.items():
        shift=0 if b==0 else 1 if a==0 else 1-t;shifted=s.expand(N.subs({k[j]:k[j]+shift*p[j] for j in range(4)},simultaneous=True));A=s.diff(shifted,p[mu]).subs(ZERO)/K**(a+b);v=average(A,k,K)
        if a and b:v=s.integrate(s.gamma(a+b)/s.gamma(a)/s.gamma(b)*t**(a-1)*(1-t)**(b-1)*v,(t,0,1))
        out+=v
    return s.expand(out)
def literal_group(role):
    w,fwd,back,source,anti,Cinv,Cphys=frames(role);raw=decode_typed(read(PKG/f'frozen_a10_e2_transport/{role}.json')['gauge_fixing_density']);Traw=[[s.zeros(45) for _ in range(45)] for mu in range(4)];mix=[s.zeros(45) for _ in range(4)];counts=[0]*4
    def li(n):return int(n[1:]) if n[:1] in ('L','b') and n[1:].isdigit() else None
    for word,z in raw.items():
        ls=[(n,j) for n,j in word if li(n) is not None];bs=[(n,j) for n,j in word if n.startswith('B')]
        if len(word)==2 and len(ls)==len(bs)==1 and sum(len(j) for n,j in word)==1:
            n,j=bs[0];color,mu=map(int,n[1:].split('_'));assert j==(mu,) and not ls[0][1];mix[mu][li(ls[0][0]),color]+=s.Poly(z,g).coeff_monomial(1)/ETA[mu]
        if len(word)!=3 or len(ls)!=1 or len(bs)!=2:continue
        c=s.Poly(z,g).coeff_monomial(g)
        if not c:continue
        assert all(not j for n,j in word);b,mu=map(int,bs[0][0][1:].split('_'));d,nu=map(int,bs[1][0][1:].split('_'));assert mu==nu;A=li(ls[0][0]);Traw[mu][A][b,d]+=c/ETA[mu];Traw[mu][A][d,b]+=c/ETA[mu];counts[mu]+=1
    assert all(mix[mu]==mix[0] for mu in range(4)) and all(Traw[mu]==Traw[0] for mu in range(4));assert cm(anti.T*mix[0]*Cinv)==-s.eye(45)
    rotated=[cm(Cinv.T*A*Cinv) for A in Traw[0]];T=[cm(sum((anti[i,a]*rotated[i] for i in range(45) if anti[i,a]),s.zeros(45))) for a in range(45)]
    fpath=OUT.parent/'canonical_so10_gauge_source_g2_color'/(role+'_result.json');rec=read(fpath.parent/'validation_receipt.json');assert rec['execution_state']=='COMPLETED' and rec['input_sha256'][str(fpath)]==digest(fpath);data=read(fpath);f=list(map(unpack,data['source_tensors']))
    assert all(cm(F+F.T)==s.zeros(45) and all(s.expand(z-s.conjugate(z))==0 for z in F) for F in f)
    for A in range(45):
        for b,c in product(range(45),repeat=2):
            desired=-f[b][A,c] if A>=12 and b<12 and c>=12 else -f[c][A,b] if A>=12 and c<12 and b>=12 else 0
            assert s.expand(T[A][b,c]-desired)==0
    refs=low.references(role);metric=s.SparseMatrix(45,45,{(a,b):s.sympify(z) for a,b,o,z in refs['mixed_color_pairs_both_orientations'] if o==1});assert cm(Cphys*metric*source)==s.eye(45)
    return w,source,anti,Cinv,Cphys,T,f,{'all4_literal_U_and_minus_Lambda_divB_copies_checked':True,'raw_U_terms_by_mu':counts,'actual_U_equals_minus_adjoint_HM_projection':True,'both_routed_mixed_orientations_from_actual_reference':True,'all2025_physical_mixed_Green_metric_entries_checked':True}
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AUX_VECTOR_POLE_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('AUX_VECTOR_POLE_PREDICTION_PEER_OR_UNDECLARED '+str(f))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return z
    assert principal();action=read(PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');V=stage('literal_curvature_cubic' if role=='primary' else 'all_Bose_cross_term_cubic',lambda:low.literal_tensor(action)[0] if role=='primary' else low.bose_tensor());routing={low.mom[0][mu]:-k[mu] for mu in range(4)}|{low.mom[1][mu]:k[mu]-p[mu] for mu in range(4)}|{low.mom[2][mu]:p[mu] for mu in range(4)};V={ij:s.expand(z.subs(routing,simultaneous=True)) for ij,z in V.items()};units={};kernels={};orders={};tensors={}
    for fam in ['UU','GU']:
        def calculate():
            tensor=[];ps=[];oset=[]
            for rho in range(4):
                z,cyclic=kernel(V,rho,fam,role);ps.append(str(z));oset.append(list(map(str,cyclic)))
                for mu in range(4):tensor.append([rho,mu,s.factor(residue(z,mu,role))])
            base=s.factor(tensor[0][2]/s.I);assert all(s.expand(z-(s.I*ETA[rho]*base if rho==mu else 0))==0 for rho,mu,z in tensor);return base,[[a,b,str(z)] for a,b,z in tensor],ps,oset
        u,ts,ps,cyclic=stage('complete_'+fam+'_unit_and_all16_UV_positions',calculate);units[fam]=u;tensors[fam]=ts;kernels[fam]=ps;orders[fam]=cyclic
    badV={ij:s.expand(z.subs(routing,simultaneous=True)) for ij,z in low.bose_tensor(omit=(0,1,2)).items()};bad_kernel=kernel(badV,0,'GU',role)[0];bad_unit=s.factor(residue(bad_kernel,0,role)/s.I);derivative_control={'omitted_Bose_permutation':[0,1,2],'routed_kernel':str(bad_kernel),'unit':str(bad_unit),'changes_actual_GU_unit':s.expand(bad_unit-units['GU'])!=0}
    print('UNITS '+json.dumps({'units':{a:str(z) for a,z in units.items()},'all32_Lorentz':tensors,'derivative_control':derivative_control},sort_keys=True),flush=True)
    invp=OUT.parent/'canonical_so10_sourcefree_cycle_inventory'/(role+'_v2_result.json');ir=read(invp.parent/'validation_receipt.json');assert ir['input_sha256'][str(invp)]==digest(invp);inv=read(invp);profiles=[r for r in inv['all_profiles'] if sorted(q[0] for q,j in r['external_ports'])==['B','L'] and r['total_external_jets']==1 and r['g']==2];assert len(profiles)==5 and {tuple(r['vertex_family']) for r in profiles}=={('G3_g1_e0_c0_n3_j1','U_g1_e0_c0_n3_j0'),('U_g1_e0_c0_n3_j0','U_g1_e0_c0_n3_j0')};assert not any('AH' in edge for edge in inv['actual_reference_edges'])
    w,source,anti,Cinv,Cphys,T,f,geometry=stage('literal_GF_reference_charts_and_all45_classical_color_tensors',lambda:literal_group(role));Cuu=s.zeros(45);Cgu=s.zeros(45)
    if role=='primary':
        for a in range(12,45):
            for (h,m),z in T[a].todok().items():
                if h>=12 or m<12:continue
                for (row,b),v in T[m].todok().items():
                    if row==h:Cuu[a,b]+=z*v
                for (row,b),v in f[m].todok().items():
                    if row==h:Cgu[a,b]+=z*v
    else:
        for h in range(12):
            Th=s.Matrix(33,33,lambda a,m:T[a+12][h,m+12]);Cuu[12:,12:]+=Th*Th;Cgu[12:,:]+=-Th*f[h][12:,:]
    Cuu=cm(Cuu);Cgu=cm(Cgu);parts={name:cm(units[name]*A) for name,A in [('UU',Cuu),('GU',Cgu)]};pole=cm(parts['UU']+parts['GU']);assert any(pole) and all(s.expand(z-s.conjugate(z))==0 and not z.has(s.Float) for z in pole);assert all(cm(f[h]*pole-pole*f[h])==s.zeros(45) for h in range(12));raw=cm(source*pole*Cphys);assert cm(anti.T*raw*Cinv-pole)==s.zeros(45)
    controls={'omit_one_cyclic_order_halves_nonzero_pole':any(pole/2),'reverse_routed_mixed_Green_changes_UU':cm(-parts['UU']+parts['GU']-pole)!=s.zeros(45),'omit_UU_family_changes_pole':parts['GU']!=pole,'omit_GU_family_changes_pole':parts['UU']!=pole,'omit_all_longitudinal_terms_changes_GU':s.expand(units['GU']-units['GU'].subs({WH:1,WM:1}))!=0,'all_longitudinal_equal_width_GU_zero':s.expand(units['GU'].subs(WH,WM))==0}
    assert all(controls.values());result={'schema':'ACTUAL_ORDINARY_G2_AUXILIARY_VECTOR_POLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_SELECTED_ORDINARY_G2_AUXILIARY_VECTOR_LOG_POLE','universal_units':{a:str(z) for a,z in units.items()},'all32_Lorentz_UV_positions':tensors,'all_routed_unit_kernels':kernels,'both_cyclic_order_kernels':orders,'all64_actual_YM_routed_coefficients':[[*ij,str(z)] for ij,z in sorted(V.items())],'actual_geometry':geometry,'physical_U_tensors':list(map(pack,T)),'actual_UU_color_contraction':pack(Cuu),'actual_GU_color_contraction':pack(Cgu),'physical_pole_parts':{n:pack(A) for n,A in parts.items()},'physical_pole_matrix':pack(pole),'canonical_raw_pole_matrix':pack(raw),'all2025_physical_positions_covered':True,'zero_complement':2025-len(pole.todok()),'ordinary_light_auxiliary_complete_pole_zero':not any(pole[:12,:]),'all12_constant_H_covariance_and_physical_reality':True,'complete_five_existing_profile_descriptors':[{k:z for k,z in r.items() if k!='witness'} for r in profiles],'full_vector_auxiliary_principal_inverse_both_orders':True,'normalization':'hbar*g10^2/(32*pi^2*epsilon_UV) integral Lambda^T M partial_mu B^mu; local ordered Fourier factor i*p_rho*eta_rho','UV_domain':'homogeneous degree-minus4 residue on positive UV annulus; nonexceptional external momentum; no whole scaleless/finite/physical IR inference','Minkowski_radial_multiplier':'2*I','width_substitution':{'reference_width_H':'eta_H','reference_width_M':'xi'},'known_Gamma_primitive_required_identity_or_peer_answer_read':False,'canonical_integration_or_Slavnov_comparison_performed':False,'full_E5_A5_QAP_measure_IR_or_physical_claim':False,'authority_changed':False,'controls':controls,'Bose_derivative_negative_control':derivative_control,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
