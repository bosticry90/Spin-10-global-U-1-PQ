# Actual ordinary auxiliary-vector logarithmic pole

Prospective report: qualification requires completed paired primary/V2 replay,
independent validation receipt and committed-byte checks. Baseline1afb41c963c37ef03bf6bcf781983c0bd3cb9a27.

The missing ordinary g10^2 Lambda-vector one-jet local UV pole is nonzero.
For canonically normalized real fields its density is
hbar*g10^2/(32*pi^2*epsilon_UV) times Lambda^T M partial_mu B^mu.
The exact complete45x45 matrix has56 nonzero positions and1969 zeros.
No source-free Slavnov cancellation or counterterm is used to determine it.

The universal bosonic units, after the actual Minkowski radial factor2i and
ordered local Fourier factor i*p_rho*eta_rho, are

    U*U:  (W_H-3)/2
    G3*U: 3*(W_H-W_M)/2.

Primary evaluates both quadratic-Hessian Born orders and their internal
starts, then all16 first-Taylor/Lorentz positions per family. Replay uses
the explicit Gaussian pairings and an independent shifted Feynman parameter,
retaining one-denominator cases. Both independently retain all derivative
placements in the actual curvature cubic, obtained from its literal AST
versus the six Bose permutations. The reverse mixed Green also reverses
momentum; its routed sign is fixed by the actual quadratic action/inverse.

All four literal g Lambda B B Lorentz copies are checked, with the exact
kinetic/color/dual charts. The full symmetric two-vector Hessian gives both
color contractions as -C_H*P_M. Here C_H=-sum_h ad_h^2 is constructed from
the actual qualified classical tensors, and P_M projects to the33 heavy
gauge directions. Thus the final compact form is

    M = (3+3*W_M-4*W_H)*C_H*P_M/2.

This is a calculated coefficient, not a value inferred from a desired Ward
identity. W_H=eta_H and W_M=xi remain symbolic reference conventions; no
physical gauge is selected. Every ordered matrix position, physical reality,
all12 constant-H commutators and the canonical raw/inverse map are checked.

Completeness uses the previously qualified proper-cycle census: five
coefficient-dimension-zero one-jet profiles are exactly U*U and G3*U.
Positive-dimensional mass/orbit insertions cannot contribute to this target.
The only light-auxiliary interaction is A_H B_H Lambda_H: A_H is an external
background without a reference edge, and at fixed A_H this vertex is linear
in quantum B_H with zero two-quantum Hessian. The pure-background reference
normalization likewise cannot supply this bilinear. Light-auxiliary rows
therefore vanish in the declared local-pole sector. No wider zero follows.

Independent validation must derive the full routed kernels and all32 UV
moments by differentiating the transverse/longitudinal projectors and using
recursive tensor pairings, reconstruct literal U/classical source tensors,
and check every actual vector/mixed reference entry and family contraction.
The declared UV object is the homogeneous degree-minus4 residue on a
positive UV annulus with nonexceptional external momentum. A positive
auxiliary IR scale separates the radial pole. No whole scaleless integral,
finite cutoff amplitude or physical IR limit is set to zero.

Controls remove a Born order, reverse the routed mixed sign, remove either
family or all longitudinal terms, and omit an actual cubic derivative
permutation. They detect changes. Equal vector widths make this selected
G3*U residue zero; that is a diagnostic identity, not an adopted gauge choice
or a justification for deleting either vector propagator.

Primary took32.7342 seconds after imports; corrected replay45.0096 seconds.
Limits are180 seconds after imports and8GiB sampled private memory, with
350MiB minimum available commit. Actual peaks/process observations are in
the complete captures. Original replay stopped on an exactly zero polynomial
sent to its nonzero-monomial homogeneity assertion. Its source/capture are
preserved. V2 skips exactly zero summands while retaining every nonzero
check, and reuses the completed primary. This is one failed worker, not a
physics obstruction. Receipt records any validation failures separately.

Agreement is bounded computational corroboration. Action, charts, old
classical/color evidence, graph catalogue, UV interpretation, software and
AI authorship are shared. The archive of classical matrices also contains
unrelated historical source-pole columns; those columns do not enter this
calculation. Neither worker reads current Gamma, the local primitive, a
required mixing matrix, a Slavnov target or peer output. No fresh
byte-identical replay pair, old lower-g loop or508 physical Euler-value
replay is claimed. Track B records useful tensor reduction and sign control,
plus the preserved avoidable zero-polynomial harness failure.

NEXT:after qualification, freeze canonical integration and the complete
bilinear Lambda*C consistency comparison using this actual pole and the
unchanged prior inputs/currents. Do not regard the new pole as already in
the current146162-word functional. No full simultaneous source-free or
regulated identity is yet proved. FullE5/A5,QAP,contacts/Legendre,measure/IR,
anomaly freedom and physical viability remain unqualified. Preserve34/39,
HB1/C5 block,flavor pause,C1_GS gap,quartet failure,scalar quantum warning,
nonzero Jacobian,32 product maps,128 source jets,508 programs,prior residuals,
closed scalar routes,custodyexit2/seven. No scheme,input,benchmark,
foundation,policy or remote change. Education remains nonblocking.
