# Complete source-dual chart correction V2

The first independent verifier passed the routed kernels, all32 projector
UV residues and derivative control. It stopped reconstructing the classical
JB B C tensor because the GF helper's field-only chart does not include the
JB source dual. No validation receipt was produced. Preserve the source and
complete failed capture.

V2 obtains the qualified full field/source chart for that source extraction,
checks all four linear maps against the GF chart, and retains every tensor,
reference and normalization gate. Native results are reused unchanged.
The same180-second/8-GiB limits apply; this routine verification correction
uses live AGENTS delegation and changes no physical assumption or scope.
