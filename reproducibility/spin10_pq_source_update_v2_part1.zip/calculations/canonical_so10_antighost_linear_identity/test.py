"""Actual source-shift Frechet kernel, odd current identity and lower-pole test."""
from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
b=load('qualified_current_frontier_helpers',OUT.parent/'canonical_so10_sourcefree_coverage_frontier/audit.py');m=b.m;h=b.h;q=b.q;l=b.base.l;ex=b.ex;s=b.s;read=q.read;digest=q.digest;PKG=q.PKG
def auth(folder,name):return b.auth(folder,name)
def sealed(folder,role):return b.sealed(folder,role)
def typ(key):return tuple(sorted(h.kind(n) for n,j in key))
def odd_anchor(P,E,omit_sign=False):
    e=m.EL_all(P,E);N=m.add(*(m.mul(m.elementary(n),A) for n,A in e.items()));J=[{} for _ in range(4)]
    for (gp,key),z in P.items():
        pos,n,j=next((p,n,j) for p,(n,j) in enumerate(key) if n in E);assert sum(v in E for v,k in key)==1;sg=1 if omit_sign else (-1)**sum(m.par[v] for v,k in key[:pos]);F={(gp,key[:pos]+key[pos+1:]):m.cscale(z,sg)}
        for cut,mu in enumerate(j):m.merge_into(J[mu],m.scale(m.mul({(0,((n,j[cut+1:]),)):ex.coefficient(s.S.One)},m.Ds(F,j[:cut])),(-1)**cut))
    if not omit_sign:assert P==m.add(N,*(m.D(A,mu) for mu,A in enumerate(J)))
    return N,J
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('ANTIGHOST_IDENTITY_WRITE')
        if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
    sys.addaudithook(guard);m.setup();stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();r=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return r
    anti=[m.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];tests=[]
    for i in range(45):n='zz_da'+str(i).zfill(2);m.index[n]=len(m.names);tests.append(m.index[n]);m.names.append(n);m.par.append(1)
    E=set(tests);EH=set(tests[:12]);images={a:m.elementary(e) for a,e in zip(anti,tests)};imagesH={a:images[a] for a in anti[:12]}
    def act(P,I):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
    e1,e1b=sealed('frozen_a10_e1_fermion',role);e2,e2b=sealed('frozen_a10_e2_transport',role);master,mb=sealed('frozen_a10_bv_master',role);shifts={m.index[n]:m.decode(rows) for n,rows in e2['source_shifts'].items()};assert len(shifts)==643 and sum(map(len,shifts.values()))==4396
    for field,source in m.pairs:
        expected=m.scale(m.decode(e1['Euler_columns'][m.names[field]]),-(-1)**m.par[field]);assert shifts[source]==expected
    V=stage('all45_odd_test_function_Frechet_images',lambda:{J:act(A,images) for J,A in shifts.items()});VH={J:{key:z for key,z in P.items() if any(n in EH for n,j in key[1])} for J,P in V.items()};classification={};nonlinear=set();kernel_counts=Counter()
    for J,P in V.items():
        for (gp,key),z in P.items():
            n,j=next((n,j) for n,j in key if n in E);assert sum(v in E for v,k in key)==1;others=[(v,k) for v,k in key if v not in E];qfields=[v for v,k in others if v in m.fields];kernel_counts[tests.index(n),len(qfields)]+=1
            if qfields:nonlinear.add(tests.index(n))
    for i in range(45):classification[('bar' if i<12 else 'ub')+str(i)]={'test_function':m.names[tests[i]],'quantum_field_dependent_entries':sum(n for (a,k),n in kernel_counts.items() if a==i and k),'background_or_constant_entries':kernel_counts[i,0],'field_independent_shift_kernel':i not in nonlinear}
    Hlinear=not any(i in nonlinear for i in range(12));S=m.decode(master['source_polynomial']);masterH=act(S,imagesH);assert not masterH,'ORIGINAL_MASTER_DEPENDS_ON_UNBROKEN_ANTIGHOST';SJ=m.EL_all(S,{J for J,P in VH.items() if P});GF=m.decode(e2['gauge_fixing_density']);actualtree=stage('literal_unbroken_gauge_fixing_variation',lambda:act(GF,imagesH));predtree=m.add(*(m.mul(VH[J],SJ.get(J,{})) for J in VH));treeResidual=m.add(actualtree,m.scale(predtree,-1));treeAnchor,treeJ=odd_anchor(treeResidual,EH);assert not treeAnchor,'TREE_SOURCE_SHIFT_CHAIN_RULE_FAILED'
    older=auth('canonical_so10_e5_remaining_obligations',role+'_result.json');v225=auth('canonical_so10_sourcefree_reconciliation',role+'_result.json');aux=auth('canonical_so10_auxiliary_companion_canonical',role+'_result.json');current=auth('canonical_so10_ghost_companion_integration',role+'_result.json');frontier=auth('canonical_so10_sourcefree_coverage_frontier',role+'_result.json');P=m.add(h.from_result(older['complete_sourcefree_polynomial']),h.from_result(v225['sourcefree_lossless_delta_from_V217']),m.decode(aux['new_actual_g3_auxiliary_companion_node']),m.decode(current['new_actual_g3_ghost_companion_node']));assert len(P)==36273 and m.fingerprint(P)==frontier['current_sourcefree_projection']['sha256_exact_cells']
    primitive=auth('canonical_so10_local_source_primitive',role+'_v2_result.json');active={J for J,VJ in VH.items() if VJ};sourceRows=[r for r in primitive['normalized_source_image'] if any(m.token(n)[0] in active for n in r['word'])];S1=h.from_result(sourceRows);assert all(sum(n in m.sources for n,j in key)==1 and not any(j for n,j in key if n in m.sources) for gp,key in S1);loops=m.EL_all(S1,active)
    g2=auth('canonical_so10_gauge_source_g2_canonical',role+'_result.json');g3=auth('canonical_so10_source_vector_g3_canonical',role+'_result.json');known=m.add(m.decode(g2['new_actual_g2_node']),m.decode(g3['new_actual_g3_node']));selected={key:z for key,z in known.items() if any(n in active for n,j in key[1])};assert selected=={key:z for key,z in S1.items() if key[0] in [2,3]},'SELECTED_MEASURED_SOURCE_NODE_COVERAGE_MISMATCH'
    actual=stage('measured_unbroken_antighost_pole_variation',lambda:act(P,imagesH));prediction=stage('fixed_shift_times_measured_source_left_Eulers',lambda:m.add(*(m.mul(VH[J],loops.get(J,{})) for J in active)));checks={};lowerPass=Hlinear
    for gp in [1,2,3]:
        A={key:z for key,z in actual.items() if key[0]==gp};B={key:z for key,z in prediction.items() if key[0]==gp};R=m.add(A,m.scale(B,-1));N,J=odd_anchor(R,EH);lowerPass=lowerPass and not N;checks[str(gp)]={'actual':l.rows(A),'predicted':l.rows(B),'raw_difference':l.rows(R),'anchor':l.rows(N),'four_currents':list(map(l.rows,J)),'zero_mod_current':not N}
    pred4={key:z for key,z in prediction.items() if key[0]==4};assert all(sum(n in EH for n,j in key)==1 and not any(j for n,j in key) for gp,key in pred4);candidate=act(pred4,{e:m.elementary(a) for a,e in zip(anti[:12],tests[:12])});assert act(candidate,imagesH)==pred4 and all(typ(key) in [('A','A','C','a'),('A','B','C','a'),('B','B','C','a')] and sum(n in set(anti[:12]) for n,j in key)==1 for gp,key in candidate)
    controls={};g3EL=m.EL_all(m.decode(g3['new_actual_g3_node']),active);without=stage('lower_source_omission_control',lambda:m.add(*(m.mul(VH[J],g3EL.get(J,{})) for J in active)));low=lambda A:{key:z for key,z in A.items() if key[0]<=3};controls['omit_actual_g2_source_changes_lower_pole_anchor']=bool(odd_anchor(m.add(actual,m.scale(low(without),-1)),EH)[0]);controls['source_left_pairing_reversal_changes_lower_anchor']=bool(odd_anchor(m.add(actual,low(prediction)),EH)[0]);fixture=m.mul(m.elementary(m.index['C0']),{(0,((tests[0],(0,)),)):ex.coefficient(s.S.One)});N,JJ=odd_anchor(fixture,EH,True);controls['omit_odd_IBP_prefix_fails_density_identity']=fixture!=m.add(N,*(m.D(A,mu) for mu,A in enumerate(JJ)));assert all(controls.values())
    HB=s.symbols('hbar_berezin',real=True);c11,c12,c22,b1,b2=s.symbols('c11 c12 c22 b1 b2',real=True);connected=s.expand((b1*b2+HB*c12)-b1*b2);assert connected==HB*c12 and connected!=0
    # Actual quadratic reference has no background antighost or BV source in
    # its coefficients;this does not construct a regulator or continuum limit.
    ref,rb=sealed('frozen_a10_e5_full_hessian',role);reference=ref['retained_reference'];assert reference['all643_inverse_directions_both_checked'];forbidden=[m.names[n] for n in set(anti)|m.sources];import re
    coefficient_symbols={n for z in {str(row[2]) for row in reference['reference_Green_raw_C3']['entries']} for n in re.findall(r'[A-Za-z_]\w*',z)};assert not(set(forbidden)&coefficient_symbols)
    result={'schema':'ANTIGHOST_LINEAR_IDENTITY_APPLICABILITY_V1','route':role,'scientific_disposition':'UNBROKEN_LINEAR_KERNEL_AND_MEASURED_LOWER_POLES_AGREE_CONDITIONAL_G4_ONLY' if lowerPass else 'LINEAR_ANTIGHOST_SHORTCUT_NOT_QUALIFIED_BY_CURRENT_INPUTS','all45_shift_kernel_classification':classification,'all643_shift_Frechet_images':{m.names[J]:l.rows(VJ) for J,VJ in V.items() if VJ},'unbroken12_kernel_field_independent':Hlinear,'original_master_unbroken_antighost_variation_zero':not masterH,'tree_chain_rule_raw_difference':l.rows(treeResidual),'tree_chain_rule_anchor':l.rows(treeAnchor),'tree_four_currents':list(map(l.rows,treeJ)),'selected_actual_source_node':l.rows(S1),'all_lower_pole_comparisons':checks,'all_measured_lower_orders_match_mod_currents':lowerPass,'conditional_unbroken_g4_antighost_prediction':l.rows(candidate),'conditional_g4_positions':len(candidate),'conditional_candidate_not_a_measured_or_integrated_pole':True,'quadratic_reference_coefficients_independent_of_antighost_and_BV_sources':True,'actual_continuum_regulated_antighost_identity_proved':False,'finite_Gaussian_connected_product_counterexample':{'expected_B1B2':'b1*b2+hbar*c12','mean_product':'b1*b2','connected_defect':'hbar*c12','not_actual_model_loop':True},'controls':controls,'current_functional_or_authority_change':False,'full_QAP_sourcefree_Slavnov_E5_A5_measure_IR_claim':False,'new_loop_or_full_Gamma_or508_value_replayed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
