# Antighost/source linear-identity applicability and measured-pole test V1

Baseline2379fc8b0b987df4eb789d284be58120e16fc734. Question ALI1:can an
exact linear antighost equation reduce any of the next ordinaryg4 ghost/
vector input classes without fitting a Slavnov remainder? Test the actual
action/source-shift premise and already measured lower poles first. No new
loop,wholeQGamma,quantum scheme or input adoption.

Use the qualified E1 odd gauge fermion and E2 source shift
A_Jz=-(-1)^p_z EL_z Psi. Differentiate all643 shifts with respect to ALL45
antighosts,using45 independent odd test functions with their ordinary jets.
Classify each resulting Frechet coefficient as integrated-field dependent
or background/constant only. Do not assume all45 satisfy a linear equation.
Check the12 unbroken antighost directions against the actual master density's
antighost dependence and the full source-free gauge-fixing density. Verify
the exact source-shift chain rule with left source Eulers and explicit four
IBP currents. No EOM quotient or implicit odd-sign convention.

For a direction with field-independent shift kernel and no original master
antighost dependence,a Grassmann translation plus that external-source shift
has unit finite-mode Berezin Jacobian. With an antighost-independent quadratic
reference/regulator,its extra variation is linear in integrated fields;
formal Legendre transformation therefore leaves no loop correction to that
linear breaking. This is a possible route to a linear pole identity,NOT a
proof of the complete model QAP,continuum measure or subtraction scheme.
Require explicit reference compatibility or preserve it as a hypothesis.

Compare the field-independent unbroken prediction with ALL actually measured
current local-log source-free antighost coefficients atg1,g2,g3,retaining
source evaluation duals,all12 antighost directions and derivative currents.
Use the qualified146663-position normalized measured source image,not a
newly fitted primitive,and reconstruct the36273-position source-free
projection by its existing lossless additions. Current fullGamma remains
153378/hash11940c31...,not rematerialized. Check the already measured g2/g3
source nodes against the relevant selected source image.

If the premise or lower-order correspondence fails,preserve the exact
obstruction and do not fill the missing g4 inputs. If they pass,extract a
CONDITIONAL unbroken-antighost g4 table implied by the linear identity and
fixed measured source coefficients. Prove its antighost variation equals
that prediction. It is not a directly measured pole and is not inserted into
Gamma or counted as complete210-profile evidence. Qualification of the
actual regulated quantum identity remains a distinct obligation.

Retain a finite Gaussian connected-product counterexample for genuinely
field-dependent kernels;linearity must not be extended to those directions.
Controls alter source pairing,remove a measured lower source node,omit an
external-background kernel and remove the odd integration-by-parts sign.
Report insensitive controls honestly. Primary prefix substitution versus
replay jet-gradient contraction;independent ordinary-SymPy reconstruction.
Shared action,charts,inputs,software and AI author limit independence.

Freeze records,code/controllers,own-role inputs and qualified receipts before
two sequential120-second-after-import/8GiB sampled-private workers,minimum
350MiB available commit;independent validator120seconds/8GiB. Preserve all
failed/unfinished captures;no silent resource growth or evidence truncation.
Possible outcomes:qualified bounded linear-identity applicability/lower-pole
agreement,precise nonlinear or normalization obstruction,or inconclusive.

Foundations review:the primary QAP references establish local breaking
insertions under their hypotheses,not vanishing breakings or this model's
scheme. Brennecke-Duetsch,Theorem5.2,uses causal time-ordered products and
translation invariance (with extra conditions for scaling bounds):
https://arxiv.org/pdf/0801.1408 . D'Attanasio-Morris,sections3-4,uses a
specific cutoff flow and inductive restoration/UV-limit argument:
https://arxiv.org/pdf/hep-th/9602156 . Neither construction has been matched
to the present full mixed reference and renormalized insertion system.
This test isolates a possible linear identity instead of assuming that bridge.

No fullE5/A5,QAP,measure/contact/IR/Legendre or physical claim. Keep34/39,
38-source/selectedH/bilinear results,nonzeroJacobian,32products,128sourcejets,
508programs,HB1/C5block,flavorpause,C1_GS,quartet/scalar warnings,closed
routes,custodyexit2/seven. No new benchmark,scheme,foundation,policy,
authority or remote action. Education nonblocking;Lean selective.
