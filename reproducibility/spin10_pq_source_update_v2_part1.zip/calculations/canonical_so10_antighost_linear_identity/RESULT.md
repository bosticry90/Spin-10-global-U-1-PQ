# Antighost linear-identity premise and lower-pole correspondence

Qualification requires completed paired V2 captures, the independent validation
receipt and committed-byte verification. This report alone is not that receipt.

The actual E1/E2 source-shift kernel is field independent for the twelve
unbroken antighost directions, and field dependent for all thirty-three broken
directions. All 643 shifts were differentiated with 45 independent odd test
functions. There are 491 nonzero Frechet columns and 2,875 entries, including
1,992 with integrated-field dependence. The literal master is independent of
the twelve unbroken antighosts. Its source-shift chain rule reproduces their
variation of the actual gauge-fixing density, with zero Euler remainder.

For these twelve directions, the linear prediction using the existing measured
source poles agrees with every current source-free antighost pole at coupling
orders g, g^2 and g^3, modulo four explicitly recorded boundary currents. The
g^2 and g^3 raw density differences need not vanish. Their respective currents
contain 13 and 288 positions per Lorentz direction; their odd Euler anchors
vanish. No equations of motion are used.

This gives a CONDITIONAL g^4 prediction containing 4,036 canonical positions:
676 AAaC and 3,360 ABaC, with no BBaC term in this unbroken-antighost sector.
Its antighost variation equals the predicted source-shift contribution exactly.
It is not a measured loop pole, not integrated, not evidence for all 210 graph
profiles, and not a g^4 Ward result. The 33 broken antighost directions remain
outside this linear shortcut. A finite Gaussian connected-product example
shows why replacing their field-dependent kernels by classical means would
discard quantum contributions; this example is not a model loop calculation.

The measured source comparison includes the separately qualified legacy
g^2 explicit-xi source partner. Omitting that cohort caused the original
primary to fail; V2 preserves the failure and restores the complete comparison
without changing any measured coefficient. Prefix substitution and jet-gradient
routes agree. Independent ordinary-SymPy verification must reconstruct every
kernel, lower-order coefficient, odd boundary current and conditional entry.
It also supplies the planned external-background-kernel omission control,
which was absent from the native workers, in addition to their source-order,
source-cohort omission and odd-IBP-sign controls. No native control is claimed
for that missing fixture.

The actual quadratic reference coefficients contain no antighost or BV source.
That necessary compatibility check does not construct a regulated generating
functional, its continuum limit, compatible subtraction or a renormalized
linear antighost identity. The latter remains explicitly UNPROVED. A finite-mode
Grassmann translation argument motivates the conditional relation; it is not
used to fill missing quantum coefficients or to assert full QAP applicability.
General QAP theorems do not supply the missing model-specific bridge merely by
being cited; their limited relevance is recorded in RECORD.md.

Current full Gamma remains 153,378 words with hash
11940c31cdeffc61c21b074c6d4bb51245860082c1a86d395dedf879f2c87ccb.
Its source-free projection remains 36,273 coupling-resolved positions. No
coefficient, physical input, source convention, quantum prescription, benchmark,
authority or policy is changed. Full source-free Slavnov, all seven quantum
construction flags, E5/A5 and physical viability remain unqualified; 34/39 and
historical custody exit 2/seven references are unchanged.

Track B: a structured identity can test a proposed reduction against measured
inputs without a new loop compiler. The first comparison nevertheless missed
a qualified explicit-xi cohort; its exact failure is retained. The methods
share the action, E1/E2/reference, source data, software and AI author. Their
agreement does not prove those premises or provide independent expert review.
No fresh byte-identical replay pair is claimed.

Next smallest action: examine whether a regulator and subtraction preserving
this particular linear translation identity can actually be justified in the
existing prescription, or calculate a representative dependency-critical g^4
coefficient directly. Do not integrate the conditional table, infer the broken
sector, run a whole-functional expansion or launch a 210-profile compiler.
Keep coefficient evidence separate from QAP/measure/contact/Legendre/IR gaps.
