# Reconcile the additional qualified g2 explicit-xi source cohort

V1 primary exited1 at SELECTED_MEASURED_SOURCE_NODE_COVERAGE_MISMATCH,
after the full Frechet extraction and exact classical chain-rule check.
No pole-comparison result was issued. Preserve code/preparation/capture.

The selected ordinaryg2 derivative-source and ordinaryg3 vector-source
nodes do not exhaust the same coupling orders. The already qualified
frozen_a10_e5_gauge_source_partner supplies the distinct canonical
g2*explicit-xi vector/ghost/source density. It is already present in the
complete measured source image;it was omitted only from this proposed
cross-check. Do not fit or change that image.

V2 authenticates that sealed density and adds it once to the comparison
of actual source inputs. Equality against the complete selected image
remains required. Every Frechet/tree/pole/odd-current and reference check
is unchanged. One corrected primary plus the remaining replay under
standing delegation,same120seconds/8GiB. Freeze revised source/controller,
the extra legacy bindings and the failed evidence before launch. No new
loop,physical input,source coefficient or acceptance requirement changed.
