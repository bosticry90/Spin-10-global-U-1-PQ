# Actual higher-quartet classical inputs and carrier bridge V1

Baseline0a0c4321d91badfc58deb7a6d147e83167acf498; AGENTS standing delegation,
statev113/34of39 unchanged. Before actual g4/g4*xi pole contraction, recover
the complete S,K,Fa,Fc,D,R classical coefficients and the normalized inverse
which the48 qualified unit factors assume. No required source/Slavnov pole,
unknown breaking or fitted parameter is an input to this calculation.

Reuse qualified own-role classical exports: V168 S/K, V177 full derivative
ghost and two-vector ghost quartics, plus its actual45-color Lie tensor.
Preparation exports only those classical subtrees with original receipt/hash
bindings; workers cannot read old physical pole tables or peers. Reuse is not
a new independent derivation of those earlier calculations. Keep all45 colors,
canonical evaluation-dual source maps and the two ordered ghost extractions.

Conventions: S(i,u,h) multiplies JL_i L_u C_h; K(i,j,a,b),a<b multiplies
JL_i a_j C_a C_b, no additional1/2. Fa/Fc(b,j,k) multiply derivative-on-a/C
in a_j B_b C_k after the qualified full IBP current, with no derivative on B.
D(j,k,u,v),u<=v multiplies a_j C_k B_u.B_v; an identical B derivative has
factor2. R(i,j,a,b),i<j,a<b multiplies a_i a_j C_a C_b. All displayed
coefficients are coupling-stripped, exact and real in the physical frame.

Primary exports the qualified literal S/K/F/D arrays and freshly pulls the
actual g²*xi ghost quartic from its own frozen GF density through its chart.
Replay uses its qualified Lie tensor to rebuild S,K,Fa,Fc and D=Qg(Psi_g),
Psi_g=sum_h,i,j f_h[i,j] a_i B_h B_j; Qg B_i=sum_b,k f_b[i,k]B_b C_k and
Qg a_i=sum_h,j f_h[i,j]a_j C_h, retaining full internal indices before
cancellations. Rebuild R=-1/4 sum_h f_h[i,a]f_h[j,b]a_i a_j C_a C_b from H
commutators and compare to its own literal pullback. No projected-heavy
Jacobi identity, arbitrary antighost sign or missing channel is assumed.

Authenticate the complete643 reference and all original B/B,mixed and ghost
entries. Freshly establish carrier normalization: Cphys*G_B,L*source and
Cphys*G_C,a*source have unit color core, while Cphys*G_B,B*Cphys.T has unit
transverse metric and the correct light/heavy longitudinal projectors. Retain
all4x4 Lorentz components,both mixed/odd orientations and L/L0. Check exact
source.T*anti=I and Cinv*Cphys=I without inserting an extra source metric.

The frozen reference explicitly identifies light width eta_H and heavy width
xi. Preserve that bridge rather than treating the unit calculation's formal
widths as newly free physical inputs. The ordinary explicit-xi0 g4 diagrams
can therefore carry xi through their heavy B/B line; keep them distinct from
the explicit g4*xi R bubble until they are combined exactly once. No value of
eta_H or xi is chosen. Omitting this bridge would misclassify coupling terms.

Freeze all coefficients,logical ordering,raw zero complements,reference
factors and exact tensor hashes. Controls use the wrong primal-source carrier,
remove required heavy-vector ghost projection,and change the R normalization;
retain nonzero witnesses. Check actual Fc_M=0 and describe its consequence
for external-antighost F vertices, not a zero for unmeasured diagrams. Preserve
the known K=-SF certificate as reused evidence, not a newly discovered result.

Two sequential read-only120-second/sampled8GiB workers,>=350MiB available
commit. Exact sparse coefficients avoid needless large symbolic polynomials.
Freeze source/controller/classical projections/allowlists before math; preserve
complete captures,failures and resource incompleteness. A separate frozen
validator checks every coefficient/metric/normalization and original binding
before local commit. Do not rerun qualified old loops or a full known Gamma.

Ceiling: complete classical input and carrier certificate for a subsequent
bounded actual pole calculation, not that pole or full source restoration.
Gamma145546/recipe/hash unchanged. E5/A5,QAP,measure,finite/IR and anomaly
claims unqualified; HB1/C5 blocked,C1_GS uncomputed,flavor paused,scalar
warnings,custodyexit2/seven preserved. Science and AI capability remain equal
tracks; education voluntary/concurrent/nonblocking. Shared exports,action,
charts,arithmetic and AI authorship limit independence. No accepted physical
input,benchmark,foundation,protected promotion,publication or remote change.
