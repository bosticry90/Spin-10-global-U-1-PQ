# Higher-quartet inputs and carrier normalization are explicit

The complete classical inputs needed for the remaining g4/g4*xi auxiliary-source
quartet are recovered and agree between qualified literal exports and adjoint
reconstruction. The corrected curvature quartic also matches the unchanged
literal GF action. Qualification requires the completed validation receipt;
this is not yet an actual higher-order quantum color pole.

| Coupling-stripped logical tensor | Nonzero entries |
| --- | --- |
| S: JL_i L_u C_h | 334 |
| K: JL_i a_j C_a C_b,a<b | 3344 |
| Fa: derivative on antighost in a_j B_b C_k | 1340 |
| Fc: derivative on ghost in a_j B_b C_k | 334 |
| D: a_j C_k B_u.B_v,u<=v | 13254 |
| R: a_i a_j C_a C_b,i<j,a<b | 1672 |

S/K/F/D are reused qualified classical coefficients, not fresh independent
derivations of earlier work. Each worker receives only its own classical
subtree projection with original receipt/hash bindings. The fresh audit
compares their complete logical tensors to S,K,F and D=Qg(Psi_g) computed
from the actual45-color Lie tensor, retaining full H/M intermediate colors.
No required quantum pole or Slavnov answer is read or fitted.

The literal g²*xi R term has418 raw C3 monomials and1672 real-frame entries.
Its correct ordered coefficient is

    R(i,j,a,b) = -sum_h f_h[i,j] f_h[a,b], i<j,a<b.

The factor1/4 in the ordered-pair sum is canceled by its four antisymmetric
orientations. The source coefficient K is exactly the left antighost
derivative of R after stripping its explicit xi and the common g². Every
coefficient,including all45-direction zero complements, is checked. This
is an actual classical-action relationship; it does not impose quantum closure.

The first primary failed because I reconstructed a crossed-index invariant
instead of the action's pair-contracted R. Its source/inputs/capture remain
unqualified and unchanged. CORRECTION_V2 preserves the original formula and
derives the replacement from the existing curvature expression. The complete
crossed-minus-literal residual has3796 nonzero entries. The original replay
never launched. No action,parameter,charge,normalization or failed record was
changed to obtain agreement. This is a rejected AI reconstruction caught by
the action comparator, not a physical model failure.

All752 B/B,376 mixed and94 ghost inverse entries are retained in the carrier
audit, with four Lorentz components,both mixed/ghost orientations and L/L0.
The physical transverse B/B metric is I; its light/heavy longitudinal metrics
are the exact H/M projectors. Cphys*G_B,L*source and Cphys*G_C,a*source have
unit color core. There is no extra source metric. Source.T*anti=I and
Cinv*Cphys=I. Replacing the evaluation-dual source carrier by its primal
counterpart leaves51 nonzero residual entries and is rejected.

The frozen reference identifies reference_width_H=eta_H and
reference_width_M=xi. No width value is selected. Consequently an ordinary
explicit-xi0 g4 graph can already contain xi through its heavy B/B inverse.
It must remain separately labeled from the explicit g4*xi R bubble until the
completed contributions are combined once. The independent formal widths
in the48 unit factors are bookkeeping tools, not additional physical knobs.

Fc for a heavy internal vector is exactly0. Thus a derivative-on-ghost F
vertex carrying the external antighost can attach only to an H vector; this
narrows the K_F and S_F B/B contractions. It is not a general diagram zero.
Failing to project the heavy-vector F ghost column adds334 spurious entries.
The actual identical-B derivative factor2 and nonzero R normalization control
are retained. The old K=-SF cancellation certificate is reused, not presented
as a new pole result.

V2 primary/replay took22.19/22.13seconds after imports, within120seconds and
sampled8GiB. The separate validator checks the original subtree bindings,
all logical coefficients,an independent C3 tensor-axis pullback of R,closed D
matrix formulas,source derivative identity,full rejected residual and all
carrier/width factors. Its180-second/sampled8GiB bound is frozen separately.
Zero fresh same-command replay pairs are claimed. Shared source,action,charts,
arithmetic and AI authorship remain shared-error risks; this is not independent
expert or experimental validation. Education remains voluntary/concurrent/
nonblocking alongside the scientific and AI-capability tracks.

The next meaningful step is an actual sparse g4 quartet contraction using these
inputs and the complete48 unit factors, preserving every external-antighost
partition and the width identification above. First exploit the proved source
and block identities to avoid a dense2004750-slot construction. Keep ordinary
H/M B/B and explicit R terms separate until the final exact sum. A predicted
coefficient must come from these action/diagram inputs, never from a desired
source consistency equation.

Gamma145546 and its V189 recipe/hash are unchanged. Full source Slavnov,E5/A5,
QAP,measure,finite contacts/physical IR and anomaly freedom remain unqualified.
Authorityv113/34of39,HB1/C5 blocked,C1_GS uncomputed,flavor paused,scalar warnings,
prior failures and custodyexit2/seven remain unchanged. No accepted physical
input,benchmark,foundation,publication/push or protected promotion occurs.
