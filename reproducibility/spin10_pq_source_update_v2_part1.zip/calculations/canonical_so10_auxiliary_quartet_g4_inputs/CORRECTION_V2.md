# Curvature-index reconstruction correction V2

The original primary failed the literal-R comparison before carrier export or
any pole. Its S,K,Fa,Fc,D comparisons had completed; no result was qualified.
Preserve exact source,preparation and native capture. The proposed R formula
in RECORD.md contracted f_h[i,a] f_h[j,b] a_i a_j C_a C_b. That is a crossed
index contraction and is not the curvature term of the frozen GF action.

The qualified literal/physical reconstruction in a10_e5_auxiliary_next.py
instead contracts the two antisymmetric pairs separately:

    R = -1/4 sum_h,i,j,a,b f_h[i,j] f_h[a,b] a_i a_j C_a C_b.

Its ordered i<j,a<b coefficient is -sum_h f_h[i,j]f_h[a,b], since the four
antisymmetric pair orientations cancel the1/4. This follows from the declared
H curvature two-form and agrees with that unchanged classical implementation;
it is not a coefficient selected from the desired quantum pole. No action,
charge,coupling,normalization,input or historical receipt is modified.

V2 retains the crossed construction as a rejected hypothesis and exports its
complete nonzero residual against the literal pullback. Require the correctly
paired formula to agree on every coefficient in both roles. Also check the
action-derived identity K=sum_i JL_i*(left derivative of R with respect to a_i)
after stripping g² and the explicit xi. It fixes the classical source relation
without imposing any quantum Slavnov cancellation. Keep all other V1 checks
and the same120-second/sampled8GiB limits. The failed run remains unqualified;
the original replay never launched. This is a failed AI reconstruction caught
by the actual-action comparator, not a failure of the physical model.
