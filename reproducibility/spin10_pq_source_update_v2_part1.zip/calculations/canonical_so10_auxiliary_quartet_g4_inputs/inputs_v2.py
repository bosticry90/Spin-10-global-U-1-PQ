"""Qualified classical subtrees plus literal/adjoint reconstruction of g4 inputs."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import product
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,ETA,canonical,decode_typed,rows,cm,zero
from a10_e5_measured_functional_v3 import frames
import a10_e5_quartic_algebra as ex
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();Z=ex.D.zero
@lru_cache(None)
def num(text):return ex.coefficient(s.sympify(text))
printed_cache={}
def printed(z):
    key=tuple(sorted(z.cells.items()))
    if key not in printed_cache:printed_cache[key]=str(ex.D.to_sympy(z))
    return printed_cache[key]
def put(P,key,z):
    P[key]=P.get(key,Z)+z
    if not P[key]:del P[key]
def pack(P):return [[*key,printed(z)] for key,z in sorted(P.items())]
def tablehash(P):return sha256(json.dumps(pack(P),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode_name(text):
    n,mark,j=text.partition('__');assert not mark or all(c in '0123' for c in j)
    return n,tuple(map(int,j)) if mark else ()
def logical_archive(archive):
    S={};K={};full={};f={};Fa={};Fc={};D={}
    for i,A in archive['source_tensors']['S']:
        for u,h,z in A:put(S,(i,u,h),num(z))
    for (i,k),A in archive['source_tensors']['K']:
        for a,b,z in A:
            full[i,a,b,k]=num(z)
            if b<k:K[i,a,b,k]=num(z)
    assert len(S)==334 and len(K)==3344 and len(full)==6688
    for (i,a,b,k),z in full.items():assert b!=k and full[i,a,k,b]==-z
    for row in archive['gauge_source_cubic']:
        ns=row['word'];J=next(n for n in ns if n.startswith('JBp'));B=next(n for n in ns if n.startswith('Bp'));C=next(n for n in ns if n.startswith('Cp'));f[int(B[2:]),int(J[3:]),int(C[2:])]=num(row['coefficient'])*(-1 if ns.index(C)<ns.index(J) else 1)
    for row in archive['B_ghost_cubic']:
        word=[decode_name(n) for n in row['word']];a=next(x for x in word if x[0].startswith('ap'));B=next(x for x in word if x[0].startswith('Bp'));C=next(x for x in word if x[0].startswith('Cp'));assert not B[1]
        z=num(row['coefficient'])*(-1 if word.index(a)>word.index(C) else 1);key=(int(B[0][2:]),int(a[0][2:]),int(C[0][2:]))
        if a[1]:assert a[1]==(0,) and not C[1];put(Fa,key,z)
        else:assert C[1]==(0,);put(Fc,key,z)
    for row in archive['B_B_ghost_quartic']:
        ns=row['word'];assert all('__' not in n and not n.startswith('Ap') for n in ns);a=next(n for n in ns if n.startswith('ap'));C=next(n for n in ns if n.startswith('Cp'));Bs=sorted(int(n[2:]) for n in ns if n.startswith('Bp'));assert len(Bs)==2
        put(D,(int(a[2:]),int(C[2:]),*Bs),num(row['coefficient'])*(-1 if ns.index(a)>ns.index(C) else 1))
    assert len(f)==1674 and len(Fa)+len(Fc)==1674 and len(D)==13254
    return {'S':S,'K':K,'Fa':Fa,'Fc':Fc,'D':D},f
def geometry(f):
    S={};K={};Fa={};Fc={};D={};R={};Hf=defaultdict(list);qB=defaultdict(list);qa=defaultdict(list)
    for (b,i,k),z in f.items():
        qB[i].append((b,k,z))
        if b<12 or k>=12:Fa[b,i,k]=z
        if b<12 and i>=12 and k>=12:
            Fc[b,i,k]=-z;Hf[b].append((i,k,z));qa[i].append((b,k,z));S[i,k,b]=-z
    quarter=num('-1/4')
    for h,A in Hf.items():
        for i,j,z in A:
            for a,b,v in A:
                if a<b:put(K,(i,j,a,b),-z*v)
                if i!=j and a!=b:put(R,(*sorted((i,j)),*sorted((a,b))),quarter*z*v*(1 if i<j else -1)*(1 if a<b else -1))
            # Qg(a_i B_h B_j), including all H/M intermediate colors.
            for l,a,c in qa[i]:put(D,(a,l,*sorted((h,j))),z*c)
            for b,c,v in qB[h]:put(D,(i,c,*sorted((b,j))),-z*v)
            for b,c,v in qB[j]:put(D,(i,c,*sorted((h,b))),-z*v)
    return {'S':S,'K':K,'Fa':Fa,'Fc':Fc,'D':D,'R':R}
def crossed_R(f):
    byH=defaultdict(list);P={};quarter=num('-1/4')
    for (h,i,j),z in f.items():
        if h<12 and i>=12 and j>=12:byH[h].append((i,j,z))
    for h,A in byH.items():
        for i,j,z in A:
            for a,b,v in A:
                if i!=a and j!=b:put(P,(*sorted((i,a)),*sorted((j,b))),quarter*z*v*(1 if i<a else -1)*(1 if j<b else -1))
    return P
def literal_R(role,w,sub):
    P=decode_typed(read(PKG/f'frozen_a10_e2_transport/{role}.json')['gauge_fixing_density']);raw={}
    for word,z in P.items():
        if len(word)!=4:continue
        value=s.Poly(z,g,xi).coeff_monomial(g**2*xi)
        if value:assert all(not jets and n.startswith(('ub','C')) for n,jets in word);raw[word]=value
    assert len(raw)==418;physical=canonical(w.replace(raw,sub));R={}
    for word,z in physical.items():
        aa=sorted(int(n[2:]) for n,j in word if n.startswith('ap'));cc=sorted(int(n[2:]) for n,j in word if n.startswith('Cp'));assert len(aa)==len(cc)==2 and aa[0]<aa[1] and cc[0]<cc[1] and all(i>=12 for i in [*aa,*cc])
        target=w.mul(*(w.var(f'ap{i}') for i in aa),*(w.var(f'Cp{i}') for i in cc));assert set(target)=={word};R[(*aa,*cc)]=num(str(z/target[word]))
    assert R and w.grade(physical,(4,0,0));return R,{'raw_g2_xi_terms':418,'physical_terms':len(physical),'all_zero_complements_by_full_literal_extraction':True}
def carriers(role,Cphys,source,anti,Cinv):
    data=read(PKG/f'frozen_a10_e5_full_hessian/{role}.json')['retained_reference'];names=data['field_order'];assert len(names)==643 and data['all643_inverse_directions_both_checked'] and data['literal_GF_all_413449_entries_matched']
    p=s.symbols('p0_ref0:4');eta=s.Symbol('eta_H');Q=sum(ETA[i]*p[i]**2 for i in range(4));BB={};mixed={};ghost={}
    @lru_cache(None)
    def expr(text):return s.sympify(text,locals={'xi':xi,'eta_H':eta})
    for i,j,text in data['reference_Green_raw_C3']['entries']:
        a,b=names[i],names[j];Ba=re.fullmatch(r'B(\d+)_([0-3])',a);Bb=re.fullmatch(r'B(\d+)_([0-3])',b);La=re.fullmatch(r'(?:L|b)(\d+)',a);Lb=re.fullmatch(r'(?:L|b)(\d+)',b);Ca=re.fullmatch(r'C(\d+)',a);Cb=re.fullmatch(r'C(\d+)',b);aa=re.fullmatch(r'(?:ub|bar)(\d+)',a);ab=re.fullmatch(r'(?:ub|bar)(\d+)',b)
        if Ba and Bb:BB[int(Ba[1]),int(Bb[1]),int(Ba[2]),int(Bb[2])]=expr(text)
        if (Ba and Lb) or (La and Bb):
            B,L,o=(Ba,Lb,1) if Ba else (Bb,La,-1);z=s.cancel(expr(text)*Q/(o*s.I*p[int(B[2])]))
            assert not z.free_symbols;mixed[int(B[1]),int(L[1]),int(B[2]),o]=z
        if (Ca and ab) or (aa and Cb):
            C,A,o=(Ca,ab,1) if Ca else (Cb,aa,-1);z=s.cancel(expr(text)*Q/o);assert not z.free_symbols;ghost[int(C[1]),int(A[1]),o]=z
        assert not (La and Lb)
    assert len(BB)==752 and len(mixed)==376 and len(ghost)==94
    pairs={(i,j) for i,j,mu,nu in BB};K0=s.zeros(45);KH=s.zeros(45);KM=s.zeros(45)
    for i,j in pairs:
        A=s.cancel(BB.get((i,j,0,1),0)*Q**2/(p[0]*p[1]));B=s.Poly(s.cancel(BB.get((i,j,0,0),0)*Q**2),*p).coeff_monomial(p[1]**2);K0[i,j]=B
        poly=s.Poly(A,eta,xi);KH[i,j]=-poly.coeff_monomial(eta);KM[i,j]=-poly.coeff_monomial(xi);assert s.expand(A-B+eta*KH[i,j]+xi*KM[i,j])==0
        assert not B.free_symbols and not KH[i,j].free_symbols and not KM[i,j].free_symbols
        for mu,nu in product(range(4),repeat=2):assert s.cancel(BB.get((i,j,mu,nu),0)+ETA[mu]*int(mu==nu)*B/Q-p[mu]*p[nu]*(B-eta*KH[i,j]-xi*KM[i,j])/Q**2)==0
    PH=s.diag(*([1]*12+[0]*33));PM=s.eye(45)-PH
    assert cm(Cphys*K0*Cphys.T)==s.eye(45) and cm(Cphys*KH*Cphys.T)==PH and cm(Cphys*KM*Cphys.T)==PM
    G=s.zeros(45);L=s.zeros(45)
    for i,j,mu,o in mixed:
        z=mixed[i,j,mu,o];assert all(mixed.get((i,j,nu,sg),0)==z for nu in range(4) for sg in [-1,1]);L[i,j]=z
    for i,j,o in ghost:assert ghost.get((i,j,-o),0)==ghost[i,j,o];G[i,j]=ghost[i,j,o]
    assert cm(Cphys*G*source)==cm(Cphys*L*source)==s.eye(45) and cm(source.T*anti)==s.eye(45) and cm(Cinv*Cphys)==s.eye(45)
    bad=cm(Cphys*L*anti-s.eye(45));assert bad!=s.zeros(45)
    sparse=lambda A:[[i,j,str(z)] for (i,j),z in sorted(A.todok().items())]
    return {'all752_BB_and376_mixed_and94_ghost_entries_checked':True,'bare_BB_color_metric':sparse(K0),'light_BB_color_metric':sparse(KH),'heavy_BB_color_metric':sparse(KM),'mixed_color_core':sparse(L),'ghost_color_core':sparse(G),'Cphys':sparse(Cphys),'source':sparse(source),'anti':sparse(anti),'Cinv':sparse(Cinv),'normalized_BB_metric_identity_and_HM_projectors':True,'mixed_and_ghost_cores_identity_without_extra_source_metric':True,'formal_width_identification':{'reference_width_H':'eta_H','reference_width_M':'xi'},'wrong_primal_source_metric_residual':sparse(bad),'no_width_value_adopted':True}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('HIGHER_QUARTET_INPUT_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('HIGHER_QUARTET_POLE_GAMMA_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);print('STAGE '+role+' qualified_classical_subtrees',flush=True);arch=read(OUT/('classical_'+role+'.json'));tables,f=logical_archive(arch)
    print('STAGE '+role+' full_adjoint_reconstruction',flush=True);geo=geometry(f)
    for label in tables:assert tables[label]==geo[label],('CLASSICAL_LITERAL_ADJOINT_DISAGREEMENT',label)
    print('STAGE '+role+' actual_charts_and_literal_R',flush=True);w,sub,back,source,anti,Cinv,Cphys=frames(role);RL,info=literal_R(role,w,sub);assert RL==geo['R'],'ACTUAL_R_FACTOR_OR_ORDER_DISAGREEMENT';tables['R']=RL if role=='primary' else geo['R']
    rejected=crossed_R(f);badR=dict(rejected)
    for idx,z in RL.items():put(badR,idx,-z)
    assert badR,'CROSSED_INDEX_HYPOTHESIS_WAS_NOT_DISCRIMINATED'
    derivativeK={}
    for (i,j,a,b),z in RL.items():put(derivativeK,(i,j,a,b),z);put(derivativeK,(j,i,a,b),-z)
    assert derivativeK==tables['K'],'CLASSICAL_R_ANTIGHOST_DERIVATIVE_SOURCE_RELATION'
    print('STAGE '+role+' complete_reference_carrier_bridge',flush=True);metric=carriers(role,Cphys,source,anti,Cinv)
    assert not {(b,j,k):z for (b,j,k),z in tables['Fc'].items() if b>=12}
    wrong_projection={(b,j,k):z for (b,j,k),z in f.items() if b>=12 and k<12};assert wrong_projection
    assert all(i>=12 and u>=12 and h<12 for i,u,h in tables['S']) and all(min(ij)>=12 for ij in tables['K'])
    identical=next(([*idx,printed(z),printed(2*z)] for idx,z in sorted(tables['D'].items()) if idx[2]==idx[3]),None);assert identical
    doubled_R={idx:2*z for idx,z in tables['R'].items()};assert doubled_R!=tables['R']
    result={'schema':'HIGHER_AUXILIARY_QUARTET_CLASSICAL_INPUTS_V1','route':role,'scientific_disposition':'COMPLETE_CLASSICAL_TENSORS_AND_REFERENCE_CARRIER_BRIDGE_ONLY','classical_tensors':{label:pack(P) for label,P in tables.items()},'tensor_sha256':{label:tablehash(P) for label,P in tables.items()},'tensor_nonzero_counts':{label:len(P) for label,P in tables.items()},'literal_R':info,'rejected_crossed_R_minus_literal_full_residual':pack(badR),'classical_K_is_left_antighost_derivative_of_R':True,'source_classical_relation_not_quantum_closure_used':True,'carriers':metric,'reused_qualified_classical_subtrees_not_new_independent_derivations':True,'all_geometric_S_K_Fa_Fc_D_and_R_equal_literal_or_qualified_exports':True,'known_K_equals_minus_SF_certificate_reused_not_new_pole_proof':True,'Fc_heavy_vector_zero_external_antighost_F_BB_line_must_be_H':True,'wrong_heavy_ghost_projection_added_entries':pack(wrong_projection),'identical_B_derivative_anchor':identical,'R_double_normalization_changes_input':True,'ordinary_explicit_xi0_g4_can_carry_reference_xi':True,'actual_g4_or_g4_xi_pole_calculated':False,'known_Gamma_changed_or_old_loop_repeated':False,'full_source_Slavnov_E5_A5_or_anomaly_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
