"""Two-source type envelope; actual coefficient calculation is deliberately separate."""
from collections import Counter
from functools import lru_cache
from itertools import combinations_with_replacement,permutations,product
from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
spec=importlib.util.spec_from_file_location('qualified_vertex_inventory',ROOT/'calculations/canonical_so10_source_vector_quartic_inventory/inventory.py')
lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
PROFILE=('JH','JM','CH','CM');lib.PROFILE=PROFILE
def bounded(p):return sum(p[:2])<=2 and sum(p[2:])<=2
lib.bounded=bounded
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def families(vertices):
    out=[]
    for sources in combinations_with_replacement(['SL','KL'],2):
        for n in range(3):
            for rest in combinations_with_replacement(sorted(set(vertices)-{'SL','KL'}),n):
                tags=(*sources,*rest)
                if sum(vertices[t]['degree']-2 for t in tags)==4:out.append(tags)
    return sorted(out)

def profile(config):
    p=tuple(sum(q[1][i] for q in config) for i in range(4))
    return p if sum(p[:2])==sum(p[2:])==2 else None

def log_degree(config,pairs,flat):
    return 4+sum(j for inner,ext in config for r,j in inner)+sum(lib.DIM[flat[a][0][0]]+lib.DIM[flat[b][0][0]]-4 for a,b in pairs)

def cycle(tags,vertices,edges):
    result=set();witness={};bb=set()
    for order in sorted(set((tags[0],*rest) for rest in permutations(tags[1:]))):
        for cfg in product(*(vertices[t]['options'] for t in order)):
            prof=profile(cfg)
            if prof is None:continue
            for flips in product([False,True],repeat=len(tags)):
                ports=[q[0][::-1] if reverse else q[0] for q,reverse in zip(cfg,flips)]
                pairs=[(2*i+1,2*((i+1)%len(tags))) for i in range(len(tags))];flat=[p for row in ports for p in row]
                if all((flat[a][0],flat[b][0]) in edges for a,b in pairs):
                    assert log_degree(cfg,pairs,flat)==0
                    result.add(prof);witness.setdefault(prof,{'order':order,'internal_ports':ports,'pairs':pairs})
                    bb.add(any(flat[a][0][0]==flat[b][0][0]=='B' for a,b in pairs))
    return result,witness,bb

def pairings(items):
    if not items:yield ();return
    for j in range(1,len(items)):
        for rest in pairings(items[1:j]+items[j+1:]):yield ((items[0],items[j]),*rest)

def connected(pairs,n):
    if any(a//2==b//2 for a,b in pairs):return False
    reached={0}
    for _ in range(n):reached|={b//2 for a,b in pairs if a//2 in reached}|{a//2 for a,b in pairs if b//2 in reached}
    return len(reached)==n

@lru_cache(None)
def proper(n):
    allpairs=list(pairings(tuple(range(2*n))));good=[p for p in allpairs if connected(p,n)]
    assert (len(allpairs),len(good))=={2:(3,2),3:(15,8),4:(105,48)}[n]
    return good

def wick(tags,vertices,edges):
    result=set();witness={};bb=set()
    for cfg in product(*(vertices[t]['options'] for t in tags)):
        prof=profile(cfg)
        if prof is None:continue
        flat=[p for row in cfg for p in row[0]]
        for pairs in proper(len(tags)):
            if all((flat[a][0],flat[b][0]) in edges for a,b in pairs):
                assert log_degree(cfg,pairs,flat)==0
                result.add(prof);witness.setdefault(prof,{'order':tags,'internal_ports':[q[0] for q in cfg],'pairs':pairs})
                bb.add(any(flat[a][0][0]==flat[b][0][0]=='B' for a,b in pairs))
    return result,witness,bb

def calculate(vertices,edges,route):
    table={};witnesses={};bb={};compute=cycle if route=='primary' else wick
    for tags in families(vertices):
        name='*'.join(tags);profiles,w,uses=compute(tags,vertices,edges)
        table[name]={'profiles':[list(p) for p in sorted(profiles)],'g':sum(vertices[t]['g'] for t in tags),'xi':sum(vertices[t]['xi'] for t in tags)}
        witnesses[name]=[{'profile':list(p),**w[p]} for p in sorted(w)]
        bb[name]=sorted(uses)
    return table,witnesses,bb

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json')
    assert digest(Path(__file__))==prep['source_sha256']
    for name,z in prep['input_sha256'].items():assert digest(Path(name))==z,name
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][route]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('DOUBLE_SOURCE_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('DOUBLE_SOURCE_UNDECLARED_OR_PEER_READ')
    sys.addaudithook(guard)
    raw=read(PKG/f'frozen_a10_bv_master/{route}.json')['source_polynomial'];linear=0;selected=0
    for row in raw:
        names=[text.partition('__')[0] for text in row['word']]
        sources=[n for n in names if n.startswith('J')]
        assert len(sources)==1
        if any(n.startswith(('JL','Jb')) for n in sources):
            selected+=1
            if len(names)==2:linear+=1;assert sum(not n.startswith('J') and not n.startswith('A') for n in names)==1
    vertices,edges,inventory=lib.census(route)
    table,witnesses,bb=calculate(vertices,edges,route)
    controls={}
    for name,changed in [('omit_mixed', {e for e in edges if set(r[0] for r in e)!={'B','L'}}),('omit_odd',{e for e in edges if not any(r[0] in ['C','a'] for r in e)}),('allow_forbidden_HM',edges|{('CH','aM'),('aM','CH'),('CM','aH'),('aH','CM')}),('omit_BB',{e for e in edges if not all(r[0]=='B' for r in e)})]:
        new,unused,bb_new=calculate(vertices,changed,route)
        controls[name]={'changes_profiles':new!=table,'supported_families':[n for n,v in new.items() if v['profiles']]}
    assert all(controls[n]['changes_profiles'] for n in ['omit_mixed','omit_odd','allow_forbidden_HM'])
    assert not connected(((0,2),(1,3),(4,6),(5,7)),4)
    ref=read(PKG/f'frozen_a10_e5_full_hessian/{route}.json')['retained_reference'];names=ref['field_order']
    mixed=[];ghost=[]
    for i,j,z in ref['reference_Green_raw_C3']['entries']:
        a,b=lib.role1(names[i]),lib.role1(names[j])
        if set([a[0],b[0]])=={'B','L'}:mixed.append(z)
        elif set([a[0],b[0]])=={'a','C'}:ghost.append(z)
    widths=set().union(*(lib.s.sympify(z).free_symbols for z in mixed+ghost))
    width_free=not any(str(z) in ['xi','eta_H','etaH'] or str(z).startswith('width') for z in widths)
    result={'schema':'DOUBLE_AUXILIARY_SOURCE_GRAPH_INVENTORY_V1','route':route,'profile_order':PROFILE,'vertices':vertices,'inventory':inventory,
      'all_source_terms_single_BV_source':True,'explicit_two_source_vertex_absent':True,'selected_JLambda_literal_terms':selected,'linear_source_terms_zero_integrated_Hessian':linear,
      'candidate_families':table,'supported_families':[n for n,v in table.items() if v['profiles']],'witnesses':witnesses,'supported_BB_usage':bb,'controls':controls,
      'proper_matching_counts':{str(n):len(proper(n)) for n in [2,3,4]},'mixed_and_ghost_reference_entries_width_free':width_free,
      'raw_antisymmetric_pair_color_slots':980100,'actual_coefficients_calculated':False,'no_old_poles_or_measured_functional_read':True,
      'color_Lorentz_correlations_relaxed':True,'unknown_quantum_breaking_set_zero':False,'full_E5_A5_or_anomaly_freedom':False,
      'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
