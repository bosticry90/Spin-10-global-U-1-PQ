# Exact auxiliary-source name classification V2

The V1 metadata filter used startswith(('JL','Jb')), which mistakenly included
the twelve linear antighost-source words Jbar_h*b_h. Those words belong to Ja,
not JLambda. V1's 1028 selected-term count and claim of twelve linear JLambda
terms are incorrect. The exact source-name language gives 1016 JLambda terms:
180 cubic plus836 quartic, and zero linear terms in the literal source action.

The graph census was parsed separately using an exact J(?:L|b)digits regex;
it never included Jbar. All actual vertex-role tables, 27 families, profiles,
coupling orders and routing/propagator controls are therefore unaffected,
subject to a new exact comparison. V1 sources, captures, receipt and report
remain unchanged, including the incorrect metadata assertion. Do not use that
assertion as evidence. Native execution success is distinct from this error.

V2 changes only the metadata name classifier, adds explicit positive/negative
name controls for Jb0/JL13 versus Jbar0/Jub13, and asserts the actual cubic/
quartic inventory. Two separately frozen sequential V2 runs retain the same
120second/8GiB/350MiB limits. Compare every unchanged mathematical field and
each own routing witness with V1, plus paired corrected metadata. No old
physics loop or new color/pole calculation is performed.

Track B: primary and replay shared the loose metadata filter, and the initial
validator repeated its expected count. Their agreement did not detect that
shared classification error. The exact source-language check exposed it.
The V166 general-momentum unit models/results do not use this metadata and
remain valid within their scope. Every authority and physical boundary in
RECORD.md remains unchanged; AGENTS.md standing delegation permits this repair.
