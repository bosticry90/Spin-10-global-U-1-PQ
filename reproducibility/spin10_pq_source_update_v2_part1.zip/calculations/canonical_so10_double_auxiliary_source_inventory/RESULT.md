# Two families remain for the double-source pole

The complete conservative proper-cycle inventory leaves two possible families
for the no-jet, dimension-zero JLambda*JLambda*C*C one-loop coefficient:

| Family | g10 order | Explicit xi order | Surviving external roles |
| --- | --- | --- | --- |
| KL*KL bubble | 4 | 0 | two JLambda_M, two C_M |
| SL*SL*F*F box | 4 | 0 | two JLambda_M, two C_M |

Here SL=JLambda*Lambda*C is the cubic source interaction, KL=JLambda*a*C*C
the quartic source interaction, and F the full derivative gauge/ghost cubic.
Twenty-five other valence-compatible families are structurally excluded.
This determines the complete conservative family/coupling envelope, not the
two amplitudes, their signs, their possible cancellation or the total pole.

Primary oriented cycles and replay connected Wick matching agree on all
27 candidate families, their profiles and coupling degrees. Both derive new
target-specific ports from the literal source/GF inventory and physical AST;
they reuse qualified parsing helpers, not an old target's exclusions. The
source action has one source per monomial: no two-source contact exists at
tree level. Twelve linear JLambda source terms have zero integrated Hessian;
180 cubic and 836 quartic terms remain. Quantum quadratic-source terms are
not thereby forbidden.

Both source indices and both ghost indices are conservatively restricted to
the 33-dimensional M complement. Thus at most binomial(33,2)^2=278,784 of the
980,100 independent pair-color slots survive this envelope; 701,316 are
structurally absent. These are bounds, not nonzero coefficient counts. Actual
color correlations, exterior signs and derivative coefficients can further
reduce the result. Equal-color source or ghost pairs vanish by their actual
odd grading; distinct pairs remain in scope.

The box uses two mixed gauge/auxiliary propagators and two ghost propagators;
the bubble uses ghosts only. Every supported routing has logarithmic leading
UV degree zero. No ordinary vector/vector propagator survives in this target,
despite its presence in the complete reference and other source calculations.
Both mixed and ghost inverse orientations are authenticated width free. There
is no explicit xi vertex in either surviving family, so the selected UV pole
has no reference-width dependence within this declared principal UV setup.
This is not a finite/IR or full-theory gauge-independence result.

Removing mixed propagation leaves only the bubble; removing odd propagation
leaves none. A forbidden H/M ghost edge spuriously admits SL*KL*F. Deleting
ordinary vector/vector propagation is insensitive and is not claimed as a
successful falsifier. Complete proper-matching counts 2/8/48 at two/three/four
vertices reject disconnected double bubbles and self-contractions.

The literal GF/source counts and complete vertex-role supports agree. The
physical AST walkers deliberately have different branch-count conventions:
primary counts 51 raw dimension-zero branches and replay 44 deduplicated
branches (quadratic counts 12/9; retained H/M assignments 114/82). These are
not conflicting amplitude counts. Validation must establish normalized support
equality separately for every physical action term; no differing count is
silently compared as equal or used to weight a loop.

The [record](RECORD.md) fixes the scope and controls before computation.
Primary/replay complete in 2.62/2.52 seconds after imports under 120-second,
sampled 8-GiB limits. The completed validation receipt is required for this
qualification; it checks exact inputs/captures, all family/profile tables,
individual routing witnesses, physical-AST support reconciliation, controls
and authority preservation. No failed scientific worker, fresh same-command
pair or old expensive pole replay is claimed. Shared action/reference,
parsers, Python/SymPy and AI authorship limit independence.

Next calculate general-momentum graded unit factors for the bubble and box,
retaining both odd source and ghost interchanges, derivative placements,
identical-source-vertex expansion factors and both inverse orientations. Use
an independent Gaussian/Wick comparator before an actual color contraction.
Prefer a universal matrix trace or symmetry reduction to a dense 278,784-slot
expansion. Do not normalize from the desired Slavnov relation.

Known Gamma92236 and its qualified selected cancellations are unchanged.
No actual double-source pole, full source closure, QAP, finite-contact/measure/
IR theorem, E5/A5 or anomaly freedom is established. Authorityv113/34of39,
HB1/C5 blocked, C1_GS uncalculated, paused flavor, earlier quartet/g2 failures,
scalar warning and custodyexit2/seven remain unchanged. No physical-input,
accepted benchmark, foundation, protected evidence or remote change. Track B
records a useful complete structural reduction with its limits; education
remains voluntary, concurrent and nonblocking.
