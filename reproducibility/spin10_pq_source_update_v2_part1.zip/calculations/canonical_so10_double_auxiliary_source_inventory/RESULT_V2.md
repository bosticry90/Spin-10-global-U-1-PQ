# Corrected source metadata; two-family result preserved

The qualified corrected inventory contains **1016 actual JLambda source
terms: 180 cubic, 836 quartic, zero linear**. V1's twelve purported linear
JLambda terms were Jbar_h*b_h antighost-source terms, admitted by a loose
prefix match. The [correction](CORRECTION_V2.md) preserves the exact mistake
and its shared-error significance. V1's source-count/linear-source statements
must not be reused.

Both V2 methods still agree on all27 families and leave only KL*KL and
SL*SL*F*F at g4/explicit-xi0, with two M-source and two M-ghost external
directions. All unchanged vertices, family/profile/coupling tables, controls
and each method's routing witnesses exactly reproduce V1. Its exact graph
parser had excluded Jbar correctly. The upper bound278784 of980100 pair-color
slots, mixed/ghost width-free UV reduction and exclusion of scalar/B/B
alternatives are preserved within the [original result's](RESULT.md) scopes.

The positive name controls accept Jb0 and JL13; negative controls reject
Jbar0 and Jub13. The new completed validation_v2_receipt.json is required to
qualify this correction. It checks captured corrected runs, all paired data,
unchanged mathematical bytes/tables, exact literal counts and authority.
The original successful native runs are preserved; their metadata error is
not relabeled correct. No physical pole is computed by this correction.

V166's separate ten general-q unit kernels remain qualified: ordered bubble
+2 and box -2, with the recorded derivative/parity/factorial controls. Next
derive and verify the general color-trace formula on a noncommuting fixture,
then test the actual SL/KL/F identities before expanding a large tensor.
Opposite unit signs alone do not establish an actual cancellation.

Known Gamma92236 and the selected V162/V163 cancellations remain unchanged.
Authorityv113/34of39, E5/A5 unqualified, HB1/C5 blocked, C1_GS uncalculated,
paused flavor, earlier failures, scalar warning and custodyexit2/seven are
preserved. No input/benchmark/foundation adoption or remote change. Shared
software/assumptions/AI authorship limit independence; education remains
voluntary, concurrent and nonblocking.
