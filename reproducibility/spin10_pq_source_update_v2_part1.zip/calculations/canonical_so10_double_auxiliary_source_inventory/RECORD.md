# Double auxiliary-source proper-loop inventory V1

Baseline db1d2c1325045271a89f8cc1968423481c5bfd27. AGENTS.md standing delegation
permits this bounded structural prerequisite. Target is the local no-jet,
coefficient-dimension-zero JLambda_i*JLambda_j*C_k*C_l one-loop term in the
unchanged retained-source action. JLambda(d1,gh-1) and C(d1,gh+1) are both
odd. Distinct source and ghost colors remain exterior pairs; the raw domain
is binomial(45,2)^2 = 980100, with equal-color zeros retained conceptually.
Do not infer a pole from classical source linearity or a desired identity.

Recover the complete literal source/GF inventory and physical executable
action, both full 643-direction reference inverses and actual H/M support.
Reuse qualified parsers/AST expansion from the source-vector inventory;
the new target and families are separate. Do not reuse its target-specific
exclusions, graph list, residues or measured functional as this result.

Each source/background is external, with no inverse. Linear JLambda*C-jet
terms have zero integrated Hessian. A proper loop has two internal incidences
per vertex; n3+2*n4=4 for these four external legs. Literal source linearity
means exactly two source-containing vertices, selected from all actual cubic
and quartic terms. Enumerate every ordinary cubic/quartic combination satisfying
valence, without assuming a g order. A one-vertex two-source quartic must be
explicitly absent in the actual inventory. Retain all derivative placements:
an external derivative cannot contribute to the declared no-jet projection.

Primary traces oriented Boolean cycles. Replay independently enumerates all
connected proper Wick matchings (including rejection of disconnected double
bubbles and self-contractions). Compare complete profiles for all candidate
families, including excluded families, g/xi powers and zero complement.
H/M roles relax color correlations and Lorentz coefficients: a permitted
profile is not a nonzero diagram. Verify superficial log degree for every
supported routing. No graded coefficient, sign or pole is calculated here.

Controls remove mixed propagation and odd propagation, and insert an actual
forbidden H/M ghost edge. Record sensitivity honestly. Track B/B use in every
surviving profile; test B/B deletion and report insensitivity if appropriate.
If every supported vector edge is mixed, independently authenticate that
both orientations carry no reference widths; distinguish explicit xi vertices
from reference-width dependence. No finite, IR or global gauge claim follows.

Two sequential read-only workers: 120 seconds after imports, sampled private
memory <=8GiB, >=350MiB available commit before launch. Freeze sources,
controller and immutable input hashes first. Native captures precede result
qualification. Preserve failures; no silent retry/resource expansion/truncation.
Validate completed paired outputs and controls before local commit.

Possible outcomes: smaller complete conservative envelope; structural absence;
disagreement; explicitly incomplete. Authority ceiling is graph/type/coupling
support, never an actual zero/nonzero pole, full source closure or E5/A5.
Known Gamma92236 and V163 selected zeros stay unchanged. All unresolved QAP,
finite-contact, quantum measure/IR and anomaly premises remain unresolved.
Statev113/34of39 unchanged, HB1/C5 blocked, C1_GS uncalculated, flavor paused;
prior failures, scalar warning and custodyexit2/seven preserved. No accepted
benchmark/input/foundation, protected evidence or remote changes. Shared
action, reference, parsers, software and AI authorship limit independence.
Education remains voluntary, concurrent and nonblocking.
