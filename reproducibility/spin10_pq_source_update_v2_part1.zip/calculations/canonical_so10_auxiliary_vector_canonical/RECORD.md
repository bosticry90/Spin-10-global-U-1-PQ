# Actual mixing integration and complete bilinear local-pole relation V1

Baseline6e096c0129e600d9c5bae946697fac6530dd7adb. The previous goal turn made
verified progress:actual ordinary g2 Lambda-vector pole, with complete five-
profile support, two residue methods and independent validation. Question
AVC1:can this measured coefficient be integrated once, and does the now
complete Lambda*C/two-jet local logarithmic Slavnov relation vanish modulo
its actual ordinary currents, at g1 and g2 for all45 directions?

Freeze source/controllers,live policy,qualified prior recipe/receipts,E2,
measured mixing,source-completeness proof and exact chart inputs before two
sequential workers capped180seconds after imports/8GiB sampled private memory,
minimum350MiB available commit. Independent validation:180seconds/8GiB.
No new loop,physical input,parameter fit or giant QGamma expansion. Preserve
all failed/unfinished executions and classify bounded inconclusiveness.

Pull the full physical g2 Lambda^T M div B density into the raw chart and
compare every ordered coefficient/all4 Lorentz copies with the measured raw
matrix. Verify inverse maps,reality,grade4/ghost0/even,symbolic widths and
actual g2 degree. Check its IBP alternative -(partial Lambda)^T M B with
the explicit four Lambda^T M B currents and all643 left Euler differences.
Do not insert an extra metric,half or negative sign.

Recover the exact prior146162-word/hash functional from the accepted V222
recipe,never an unfinished cache. Prove that its g2 Lambda*B/one-jet class
is absent; lower-g terms in the same word remain unchanged. Add the node
once. Compare every changed word/g/width component and zero complement,
all unmodified words,exact inverse removal and actual omission/doubling.
Authenticate a compact new recipe;do not rewrite old evidence. Source
projection and all classical source-free field Q columns stay unchanged,
preserving the38-class source local-pole theorem only in its original scope.

Use one identical completed Gamma throughout the bilinear comparison. The
qualified complete predecessors are a*C/two jets,Lambda*B/one jet,JB*C/one
jet,JLambda*C/two jets,and Ja*Lambda/no jets. Reconcile the finite type/jet
census with actual linear E2 columns and V222's receipt. Match its immutable
action,operator,Ja-cycle-zero and physical508 dimension/support exclusions.
Do not infer Ja*Lambda zero merely from absence in Gamma or set508 Euler
programs globally to zero. Nonphysical Q has no constants;one-letter
derivative densities are currents,multiple-source words cannot become
source-free in one variation,and higher-word inputs cannot yield a bilinear.

Primary applies the odd derivation by prefix signs;replay uses left gradients.
Project the complete declared Lambda*C/two-jet target and retain all boundary
currents. Normalize by moving derivatives off Lambda and check literal
raw=anchor+div(current),all643 Euler derivatives,and all20250 possible
anchored component/ordinary-jet positions. No EOM quotient. Preserve the
lower-g control and assess the ordinary g2 result without imposing its sign
or inferring a needed coefficient. A complete nonzero remainder is a valid
outcome requiring interpretation,not an automatic anomaly declaration.

Separate contributions from each predecessor class. Controls omit/double
the actual new pole,reverse its sign,use an incorrect chart or IBP current,
and omit measured ghost/JB/JLambda inputs where sensitive. Record any
insensitivity honestly;do not weaken checks. Independent validation uses
ordinary-SymPy graded derivatives,finite types and currents,measured matrices,
exact full-functional serialization and explicit perturbation checks.
Agreement shares action,charts,prior poles,catalogue,software and AI author;
it is bounded computational corroboration,not independent expert validation.

Possible outcomes:qualified complete selected zero modulo current;qualified
complete nonzero local remainder;or explicit incomplete dependency/resource
limit. No selected success substitutes for source-free simultaneous/QAP,
finite contact/Legendre,measure/IR,anomaly freedom or fullE5/A5 restoration.
No scheme,benchmark,foundation or protected promotion. Preserve34/39,
HB1/C5 block,flavor pause,C1_GS gap,quartet failure,scalar quantum warning,
nonzero Jacobian,32 product maps,128 source jets,508 programs,prior residuals,
closed routes,custodyexit2/seven. No remote action. Education nonblocking.
