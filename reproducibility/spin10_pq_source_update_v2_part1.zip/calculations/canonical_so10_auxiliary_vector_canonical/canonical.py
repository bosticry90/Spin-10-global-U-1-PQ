"""Exact measured mixing integration and complete selected bilinear pole test."""
from pathlib import Path
from collections import defaultdict
from itertools import combinations_with_replacement,product
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);v=importlib.util.module_from_spec(z);z.loader.exec_module(v);return v
q=load('qualified_ghost_integration_recipe',OUT.parent/'canonical_so10_ghost_kinetic_canonical/canonical_v4.py');m=q.m;l=q.l;h=q.h;ex=q.ex;s=q.s;read=q.read;digest=q.digest;PKG=q.PKG;g=q.g;xi=q.xi;eta=q.eta
from a10_e5_nonminimal_source import canonical,rows
def auth(folder,name):return q.auth(folder,name)
def prior_tables(role):return q.current_tables(role)
def current_tables(role):
    tables,old,path=prior_tables(role);d=auth('canonical_so10_auxiliary_vector_canonical',role+'_result.json');tables.append(d['new_actual_g2_auxiliary_vector_node']);return tables,d,OUT/(role+'_result.json')
def raw_node(P):
    return q.rawrows({key:q.sumtext((str(g**gp*ex.D.to_sympy(z).subs({ex.widthM:xi,ex.widthH:eta})),)) for (gp,key),z in P.items()})
def exact_matrix(A):return s.SparseMatrix(45,45,{(i,j):q.num(z) for i,j,z in A})
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,k in prep['input_sha256'].items():assert digest(Path(n))==k,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('MIXING_CANONICAL_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('MIXING_CANONICAL_PEER_OR_UNDECLARED '+str(f))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();z=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return z
    w=m.setup();d=auth('canonical_so10_auxiliary_vector_g2','primary_result.json' if role=='primary' else 'replay_v2_result.json');wf,fwd,back,source,anti,Cinv,Cphys=m.old.frames(role);M=exact_matrix(d['physical_pole_matrix']);Mr=exact_matrix(d['canonical_raw_pole_matrix']);assert q.cm(source*M*Cphys-Mr)==s.zeros(45) and q.cm(anti.T*Mr*Cinv-M)==s.zeros(45)
    physical={};direct={};alternative={};currents=[{} for _ in range(4)]
    for i,j in product(range(45),repeat=2):
        ln=('b' if i<12 else 'L')+str(i)
        for mu in range(4):
            metric=1 if mu==0 else -1
            if M[i,j]:physical=wf.add(physical,wf.scale(wf.mul(wf.var('Lp'+str(i)),wf.var('Bp'+str(j)+'_'+str(mu),(mu,))),g**2*metric*M[i,j]))
            if Mr[i,j]:
                direct=wf.add(direct,wf.scale(wf.mul(wf.var(ln),wf.var(f'B{j}_{mu}',(mu,))),g**2*metric*Mr[i,j]));alternative=wf.add(alternative,wf.scale(wf.mul(wf.var(ln,(mu,)),wf.var(f'B{j}_{mu}')),-g**2*metric*Mr[i,j]));currents[mu]=wf.add(currents[mu],wf.scale(wf.mul(wf.var(ln),wf.var(f'B{j}_{mu}')),g**2*metric*Mr[i,j]))
    physical=canonical(physical);direct=canonical(direct);pull=stage('all2025_physical_raw_density_and_inverse_charts',lambda:canonical(wf.replace(physical,back)));assert not canonical(wf.add(pull,wf.scale(direct,-1))) and canonical(wf.replace(direct,fwd))==physical and wf.grade(direct,(4,0,0))
    node=m.decode(rows(pull if role=='primary' else direct));alt=m.decode(rows(canonical(alternative)));J=list(map(lambda A:m.decode(rows(canonical(A))),currents));assert not m.add(node,m.scale(alt,-1),*(m.scale(m.D(A,mu),-1) for mu,A in enumerate(J)));assert not any(m.EL_all(m.add(node,m.scale(alt,-1)),m.fields).values());node_rows=raw_node(node);assert all(gp==2 and q.types(key)==('B','L') and sum(len(j) for n,j in key)==1 for gp,key in node)
    tables,previous,path=prior_tables(role);old=stage('protected_prior146162_word_hash',lambda:q.combine(tables));assert len(old)==previous['updated_known_terms']==146162 and q.hashrows(q.rawrows(old))==previous['updated_known_sha256']=='71d4546d3954ac2a461db3e7d8e235416ba3d4745033f85d8426639e762b412a'
    oldclass=m.decode([r for r in q.rawrows(old) if q.types(tuple(m.token(n) for n in r['word']))==('B','L') and sum(len(m.token(n)[1]) for n in r['word'])==1]);assert not any(gp==2 for gp,key in oldclass),'ORDINARY_G2_MIXING_ALREADY_PRESENT'
    updated=stage('exact_once_addition_inverse_and_source_preservation',lambda:q.combine([q.rawrows(old),node_rows]));changed={key for key in set(old)|set(updated) if old.get(key)!=updated.get(key)};assert changed=={key for gp,key in node};assert q.combine([q.rawrows(updated),[{'word':r['word'],'coefficient':str(-q.num(r['coefficient']))} for r in node_rows]])==old
    assert {key:z for key,z in old.items() if key not in changed}=={key:z for key,z in updated.items() if key not in changed};assert {key:z for key,z in old.items() if any(n in m.sources for n,j in key)}=={key:z for key,z in updated.items() if any(n in m.sources for n,j in key)}
    selected=m.decode([r for r in q.rawrows(updated) if q.types(tuple(m.token(n) for n in r['word']))==('B','L') and sum(len(m.token(n)[1]) for n in r['word'])==1]);assert m.add(selected,m.scale(oldclass,-1))==node
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');L={i for i in m.fields if h.kind(i)=='L'};C={i for i in m.fields if h.kind(i)=='C'};linear={m.index[n]:m.decode([r for r in A['source_polynomial'] if len(r['word'])==1 and m.token(r['word'][0])[0] in L|C]) for n,A in e2['complete_columns'].items()};assert not any(not r['word'] for A in e2['complete_columns'].values() for r in A['source_polynomial'])
    for i in range(45):
        for mu in range(4):assert linear[m.index[f'B{i}_{mu}']]==m.D(m.elementary(m.index['C'+str(i)]),mu)
        assert linear[m.index[('bar' if i<12 else 'ub')+str(i)]]==m.scale(m.elementary(m.index[('b' if i<12 else 'L')+str(i)]),-1)
    T={'B':(1,0,0,1),'x':(1,0,0,0),'A':(1,0,0,1),'C':(1,1,1,0),'a':(1,-1,1,0),'L':(2,0,0,0),'JB':(2,-1,1,1),'Jx':(2,-1,1,0),'JC':(2,-2,0,0),'Ja':(2,0,0,0),'JL':(1,-1,1,0)};sig=set()
    for i,A in linear.items():
        for (gp,key),z in A.items():
            n,js=key[0];cd=T[h.kind(i)][0]+1-T[h.kind(n)][0]-len(js);assert cd>=0;sig.add((h.kind(i),h.kind(n),len(js),gp,cd))
    routes=[]
    for a,b in combinations_with_replacement(sorted(T),2):
        da,ga,pa,va=T[a];db,gb,pb,vb=T[b];j=4-da-db
        if j<0 or ga+gb or (pa+pb)%2 or (va+vb+j)%2:continue
        for varied,other in [(a,b),(b,a)]:
            for before,output_kind,jq,gq,cd in sig:
                if before==varied and cd==0 and j+jq==2 and sorted([output_kind,other])==['C','L']:routes.append([sorted([a,b]),j,varied,output_kind,jq,gq])
    assert sorted(routes)==previous['finite_all_type_jet_predecessor_routes'];prior_receipt=read(path.parent/'validation_receipt.json');assert all(prior_receipt['per_role_independent_checks'][role].values());e2path=PKG/f'frozen_a10_e2_transport/{role}.json';assert prior_receipt['input_sha256'][str(e2path)]==digest(e2path);assert previous['Ja_Lambda_g2_has_no_matching_cycle'] and previous['physical508_Eulers_excluded_only_for_Lambda_C_target_by_dimension_support']
    bilinear=m.decode([r for r in q.rawrows(updated) if len(r['word'])==2]);action=stage('complete_small_bilinear_derivation',lambda:m.action(bilinear,linear,role))
    def project(A,gp):return {key:z for key,z in A.items() if key[0]==gp and q.types(key[1])==('C','L') and sum(len(j) for n,j in key[1])==2}
    sector={};boundaries={};pieces={};anchors={}
    for gp in [1,2]:
        P=project(action,gp);N,theta=q.anchor(P,L);anchors[gp]=N;assert not any(m.EL_all(m.add(P,m.scale(N,-1)),m.fields).values());A=q.matrix(N);sector[str(gp)]={'raw':l.rows(P),'anchored':l.rows(N),'matrix':q.pack(A),'all20250_anchored_slots_zero':not N};boundaries[str(gp)]=list(map(l.rows,theta))
        for ts in [('C','a'),('B','L'),('C','JB'),('C','JL'),('Ja','L')]:
            subset={key:z for key,z in bilinear.items() if q.types(key[1])==ts};Psub=project(m.action(subset,linear,role),gp);Acur,Kcur=q.anchor(Psub,L);pieces[str((gp,ts))]={'raw':l.rows(Psub),'anchor':l.rows(Acur)}
    new_action=project(m.action(node,linear,role),2);old_action=m.add(project(action,2),m.scale(new_action,-1));doubled=q.combine([q.rawrows(updated),node_rows]);assert m.add(selected,node)!=selected and doubled!=updated
    omit={};insensitive=[]
    for ts in [('C','a'),('C','JB'),('C','JL')]:
        P=project(m.action({key:z for key,z in bilinear.items() if q.types(key[1])==ts},linear,role),2);residual=q.anchor(m.add(project(action,2),m.scale(P,-1)),L)[0];omit[str(ts)]=bool(residual)
        if not residual:insensitive.append(str(ts))
    wrong_chart_sensitive=q.cm(anti*M*Cinv-Mr)!=s.zeros(45);chart_witness=None
    for a,b in product(range(45),repeat=2):
        E=s.SparseMatrix(45,45,{(a,b):1})
        if q.cm(source*E*Cphys-anti*E*Cinv)!=s.zeros(45):chart_witness=[a,b];break
    assert chart_witness is not None
    controls={'omitting_actual_new_node_has_nonzero_anchor':bool(q.anchor(old_action,L)[0]),'doubling_actual_new_node_has_nonzero_anchor':bool(q.anchor(m.add(project(action,2),new_action),L)[0]),'reversing_new_node_has_nonzero_anchor':bool(q.anchor(m.add(project(action,2),m.scale(new_action,-2)),L)[0]),'actual_double_compilation_changes_coefficients':doubled!=updated,'wrong_chart_detected_by_tensor_unit':chart_witness is not None,'reverse_IBP_current_breaks_density':bool(m.add(node,m.scale(alt,-1),*(m.D(A,mu) for mu,A in enumerate(J))))};assert all(controls.values())
    sourcefree_fields=all(not any(m.token(v)[0] in m.sources for r in e2['complete_columns'][m.names[n]]['source_polynomial'] for v in r['word']) for n in {a for gp,key in node for a,j in key});assert sourcefree_fields
    result={'schema':'ACTUAL_MIXING_CANONICAL_AND_COMPLETE_BILINEAR_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_BILINEAR_LOG_POLE_ZERO_MOD_CURRENT' if not any(anchors.values()) else 'COMPLETE_SELECTED_BILINEAR_LOG_POLE_NONZERO_REMAINDER','new_actual_g2_auxiliary_vector_node':node_rows,'physical_density':rows(physical),'IBP_alternative':l.rows(alt),'four_mixing_IBP_currents':list(map(l.rows,J)),'all643_mixing_density_Euler_differences_zero':True,'new_node_positions':len(node),'changed_existing_word_positions':len(changed),'new_word_positions':len(set(updated)-set(old)),'prior_known_terms':len(old),'prior_known_sha256':q.hashrows(q.rawrows(old)),'updated_known_terms':len(updated),'updated_known_sha256':q.hashrows(q.rawrows(updated)),'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'add_once_key':'new_actual_g2_auxiliary_vector_node'},'source_projection_identical_and_field_Q_sourcefree':True,'complete_type_jet_predecessor_routes':sorted(routes),'qualified_Ja_cycle_zero_and_physical508_exclusion_reconciled':True,'all_bilinear_relations':sector,'relation_boundary_currents':boundaries,'individual_predecessor_pieces':pieces,'complete_g1_and_g2_relations_zero_mod_current':not any(anchors.values()),'all_possible_anchor_positions_per_order':20250,'all_possible_raw_jet_positions_per_order':72900,'omitted_other_predecessor_controls':omit,'insensitive_omission_controls':insensitive,'wrong_chart_actual_matrix_sensitive':wrong_chart_sensitive,'wrong_chart_tensor_unit_witness':chart_witness,'controls':controls,'new_or_old_loop_or508_Euler_value_replayed':False,'coefficients_fitted_or_new_scheme_adopted':False,'full_sourcefree_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
