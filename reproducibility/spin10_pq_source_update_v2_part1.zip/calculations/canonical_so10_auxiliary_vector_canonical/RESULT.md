# Integrated measured mixing and complete selected bilinear consistency

Prospective until paired results/captures,independent validation receipt and
committed bytes qualify. Baseline6e096c0129e600d9c5bae946697fac6530dd7adb.

The actual ordinary g10^2 auxiliary-vector mixing pole is integrated once
into the same canonical functional. Its128 raw positions change128 existing
field-word coefficients:the count stays146162 words. The authenticated hash
changes from71d4546d3954ac2a461db3e7d8e235416ba3d4745033f85d8426639e762b412a
to f0b650d6a343a98e105c7aee8894fca84a70dad17d64620b9ee3181488fceee1.
An unchanged word count does not mean unchanged quantum content.

In common hbar/(32*pi^2*epsilon_UV) units the added density is
g10^2 Lambda^T M div B,where M is the previously measured symbolic-width
matrix. No coefficient is inferred from an intended cancellation. The
full45x45 physical/raw chart comparison,all4 Lorentz copies,grade,coupling,
zero complement,exact inverse removal,changed/unmodified words and actual
double addition are checked. Existing lower-g coefficients stay unchanged.
The IBP alternative -g10^2(partial Lambda)^T M B differs by the displayed
four g10^2 Lambda^T M B currents. All643 left Euler differences vanish.
There is no EOM quotient,extra ghost half or spatial metric.

The now-complete selected source-free Slavnov relation has field content
Lambda*C,two ordinary jets,ghost number one and density dimension five.
At both tested orders g10 and g10^2 its normalized remainder is exactly zero
for the unchanged symbolic widths and full45-direction domain. The raw
densities need not vanish:they equal the recorded total derivatives. Their
integrals vanish for compact support or boundary conditions annihilating
these explicit currents;no unrestricted physical boundary claim is made. Each
order covers20250 possible anchored ordinary-jet/component positions;the
raw two-field/two-jet space has72900 positions. These are index-space counts,
not independent amplitudes,experiments or a percentage of E5 completion.

All five predecessor classes are included:
a*C/two jets,Lambda*B/one jet,JB*C/one jet,JLambda*C/two jets,and
Ja*Lambda/no jets. Actual linear E2 columns reproduce the complete finite
type/jet census. V222's Ja-cycle support zero and physical508 dimension/
support exclusion are reused only after matching their unchanged operator,
action and qualified receipt bindings. Absence of a stored term is not used
as a zero proof. No constants in nonphysical Q exclude higher-word inputs;
multiple-source inputs cannot become source-free in one variation,and
one-letter differentiated densities are explicit currents. Physical508
Euler programs remain present and unevaluated,not globally discarded.

The g10^2 relation combines genuine nonzero measured contributions,including
the newly measured mixing and ghost kinetic poles,without fitting any value.
Contributions are retained separately by predecessor class. Removing,
doubling or reversing the new pole produces a nonzero anchor. Omitting the
ghost,JB or JLambda predecessor also breaks this selected cancellation.
An incorrect dual chart and reversed IBP current are detected. The four
relation currents have33 entries each at g10 and46 each at g10^2.

Every source coefficient remains identical,and actual field Q columns on
the new node are source-free. Thus the38-class source local-pole theorem
is preserved in its original domain. This new source-free relation is an
additional complete selected theorem,not the simultaneous source-free
identity. In particular,constant-H covariance of the measured matrix does
not itself prove the local-H/background completion of its derivative term.

Primary applies the graded derivation by prefix signs;replay uses left
gradients. Independent validation uses ordinary-SymPy charts,coefficient
serialization,graded derivatives,finite types,all individual pieces and
explicit currents/perturbations. Limits:two sequential180-second-after-
import workers,8GiB sampled private memory each,minimum350MiB available
commit;independent validation180seconds/8GiB. Captures record actual
timings,peaks and process observations. Old loops and508 Euler values are
not replayed,and no fresh byte-identical replay pair is claimed.

Shared action,charts,prior measured poles,operator,catalogue,software and
AI authorship limit independence. This is bounded computational
corroboration,not independent expert validation. Track B evaluates complete
dependency reconciliation and economical modular assembly instead of
another giant QGamma expansion. Any failures belong in their exact captures
and receipt,not silently relabeled as mathematical success.

NEXT:reconcile remaining source-free/nonminimal obligations against the
updated recipe and existing cycle/primitive evidence before selecting a
new amplitude. In particular,check the background-covariant companion of
the newly integrated derivative term and remaining auxiliary-sector inputs;
do not infer their measured values from the identities. Separate genuinely
missing coefficients from regulated-insertion/QAP/measure/contact premises.
Use no full QGamma replay unless a new structural reduction justifies it.

FullE5/A5,QAP,finite contacts/Legendre,regulated insertion/measure/IR,
anomaly freedom and physical viability remain unqualified. Preserve34/39,
HB1/C5 block,flavor pause,C1_GS gap,quartet failure,scalar quantum warning,
nonzero Jacobian,32 product maps,128 source jets,508 programs,prior residuals,
closed routes,custodyexit2/seven. No scheme,input,benchmark,foundation,
policy or remote action. Education voluntary/nonblocking;Lean selective.
