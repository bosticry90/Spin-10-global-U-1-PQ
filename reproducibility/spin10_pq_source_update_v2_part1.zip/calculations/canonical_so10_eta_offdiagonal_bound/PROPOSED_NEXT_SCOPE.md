# Director scope decision after the fixed-eta exclusion — NOT ACTIVE

Evidence condition:this proposal is reviewable only after the actual eta
offdiagonal validation receipt and raw Git checks qualify the result. The
current fixed-input eight-quartic domain then fails its stipulated tree
perturbativity condition. This document grants no execution authority.

Option1 — authorize a bounded SYMBOLIC eta-variable extension. Keep the same
action,representations,PQ charges,VEV ratios and all other fixed inputs. Add
ONE real input eta to the existing eight-quartic formal comparison,initially
0<eta<=pi*sqrt(7/930),the necessary bound just derived. This is an exploratory
restricted real-eta domain,not all complex phases or an adopted eta value.
No numerical parameter point,optimizer,new model family,loop,matching,flavor
resume or benchmark adoption. The old eta=3/10 failure remains final in scope.

Scientific justification:eta is an existing symmetry-allowed free action
coefficient whose frozen3/10 value was a mathematical input,not an independent
experimental determination. The present result excludes that fixed value;
it does not show every value fails. Broadening is justified only as a new
falsifiable comparison,not a way to relabel the old domain successful.

Concrete permitted increment if authorized:two sequential native roles,
each120seconds after imports,8GiB sampled private allocation and350MiB
directly observed prelaunch commit. Reuse the literal34-slot/29-monomial
source data to reconstruct eta dependence of weak/colored matrices and
the Higgs sources/quartic. Require the eta=3/10 specialization to reproduce
the qualified old data exactly and an eta=0 zero-mixing reference control.
Retain source/representation/gauge/phase normalizations and negative controls.
Output symbolic necessary conditions and an explicit accounting of the
remaining fixed offdiagonal interactions needing cheap screens. Stop at a
contradiction,resource limit or missing physical prerequisite. No automatic
extra attempts or consequential input selection. Any subsequent point search
or adoption remains a separate director decision.

Option2 — close the current eight-quartic recovery and reassess direction.
Retain the evidence and classify its failure under the declared criterion;
do not alter eta. Prepare a concise comparison of the unresolved broader
physical assumptions/alternatives before any new recovery domain. No resumed
blocked stage,flavor calculation,public engagement or authority promotion.

Decision reserved to the director by AGENTS.md:the human director sets scope,
foundational assumptions,priorities,acceptance,publication and external actions.
Technical proficiency or a lesson is not required. Neither option establishes
model viability,novel physics or AI reliability. Equal science/AI objectives
and concurrent voluntary education remain. project_state.json and all
scientific-authority bytes remain unchanged unless their separate contract
and director acceptance require a future update.
