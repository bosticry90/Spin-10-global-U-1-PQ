# Fixed eta offdiagonal scattering: complete coefficient trace V1

Previous goal turn:PROGRESS,738260a established the rigorous D contact lift.
Recover actual Git/process/read-only preflight state. Before more joint
feasibility work,test a potentially decisive fixed-input necessary condition:
does eta=3/10 alone violate the usual fixed-coupling high-energy tree scalar
perturbativity bound? No numerical parameter search,new input or benchmark.

The actual parent eta vertex has3 Sigma and1 phi fields. Other parent
quartics have different field content and cannot cancel this offdiagonal
block. Gauge kinetic vertices are species-block diagonal,so leading gauge
exchange cannot have3 Sigma/1 phi external legs. Fixed dimensionful scalar
exchange is subleading in the declared asymptotic contact screen,with the
usual physical-mass/IR limiting qualification. Use Goodsell/Staub1805.07306
eqs2--5 normalization;do not claim a finite-energy,RG or exact S-matrix no-go.

Canonical complex Sigma coordinates:126 raw selfdual basis formsF_I have
normN=2 and kinetic(1/2)N=|dz_I|^2. phi has standard complex kinetic term.
Undo the actual b^3 raw eta rescaling consistently;physical eta stays3/10.
Enumerate ALL8001 unordered incoming Sigma pairs,including126 diagonals.
Use the literal qualified B[I5,n] quadratic tensor and project withconj(F_c)
onto the full target126x10. Diagonal incoming columns have sqrt2 times their
polynomial coefficient;offdiagonal columns have the coefficient itself.
Do not omit channels using predicted zeros or a preferred result.

Compute exact Frobenius trace S0 of this charged map with eta stripped.
Verify B is selfdual on EVERY coefficient row,projection norm factors and
the full126x10 harmonic trace of the cubic E. Retain each pair's norm and
all per-leg traces. The independent route uses differently routed paired
contractions and Schur irreducibility to obtain the trace from two complete
fixed-leg inventories. Signed-coordinate SO(10) covariance can independently
classify every pair norm by overlap,with no zero channel omitted originally.

Determine the actual complex rank k of the45 Sigma gauge-orbit directions
at the frozen vacuum,not a rank assumed from dimensions. The Hermitian
orthogonal complement P has126-k complex directions;P Sigma and all10 phi
directions are physical (phi VEV=0). This is a conservative physical subspace,
not use of potential Goldstones as physical scalars. It is complex-linear,
so asymptotic PQ-charge sectors remain separate. Full local-mass assumptions
are inherited conditional prerequisites,not a new spectrum calculation.

Fresh exact D5 products and Slansky table42 comparator must establish the
neutral common irrep:126x10=210+1050,126xbar126=1+45+210+770+5940+8910.
Thus the neutral offblock rank is at most210. Prove normalization/crossing:
harmonic cubic E gives total real offblock Frobenius6|eta|^2*S0;the two
charged sectors each contribute|eta|^2*S0,leaving neutral4|eta|^2*S0.
Validate these factors with canonical-real positive/identical-pair toy
vertices and a nonharmonic control. This transfer requires the physical
two-particle Hilbert map,not only equal tensor dimensions or rank.

Spin(10) covariance and irreducibility make each neutral Sigma-leg partial
Gram scalar. Projecting each of three Sigma legs to P loses at mostk/126
of its Frobenius norm squared;commuting projection union bound retains at
least1-3k/126. Check this coefficient is positive. Dividing retained norm by
rank210 yields a lower bound on the operator norm of the PHYSICAL offblock.
The full Hermitian tree partial-wave norm is at least this offblock norm;
unmeasured diagonal quartics cannot cancel it. Usea0=M/(16pi),criterion
max|Re a0|<=1/2. Prove the final sign with rational pi bounds,not decimals.

If the bound exceeds1/2 after all premises/controls pass,the entire declared
fixed-nonfamily-input eight-quartic comparison fails this necessary tree
perturbativity screen. It is not refutation of Spin(10),the full parameter
space,nonperturbative theory,quantum unitarity or the invariant action.
If it does not exceed1/2,report only this bound,not full scattering PASS.
If a physical/source/normalization premise fails,stop and report the precise
qualification gap instead of claiming exclusion. Do not lower eta to fit.

Two sequential native roles,each120seconds after imports,8GiB sampled private
limit,direct350MiB prelaunch commit. Primary full8001 coefficients and small
character/rank calculation;independent compressed exact trace/normalization
and physical-projection proof. No full quartic compiler,spectrum,loop,old
8001 wedge proof or parameter optimizer. Freeze sources/inputs and preserve
all failed/incomplete evidence. No automatic retries. Require receipt,current
preflight and raw staged/committed bytes. Published comparators supply
normalization/representation context,not independent endorsement of this model.

Preserveproject_state.json,README,authority34/39,custody exit2/seven references,
all prior local/BFB successes and failures,quartetFAIL,E5/A5unqualified,
HB1/C5block,C1_GSgap and flavor pause. Equal science/AI objectives;education
voluntary/nonblocking. Director owns consequential input/scope changes and
acceptance. No new family,point,benchmark,gauge choice,flavor resume,outreach,
publication,push or authority promotion. Preserve negative outcomes honestly.
