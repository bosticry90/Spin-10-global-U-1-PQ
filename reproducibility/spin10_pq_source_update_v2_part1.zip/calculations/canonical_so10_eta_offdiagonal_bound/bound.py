"""Complete canonical eta pair inventory and physical neutral-block trace bound."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from collections import Counter
from fractions import Fraction as F
import sys,json,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_scalar_reconstruction'));import count_d5_singlets as reps
from verify_eta1_doublet_mixing import vacuum_form
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(0,0);add=lambda a,b:(a[0]+b[0],a[1]+b[1]);mul=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);conj=lambda a:(a[0],-a[1])
def parity(I):return (-1)**sum(a>b for i,a in enumerate(I) for b in I[i+1:])
def put(P,k,z):
 z=add(P.get(k,Z),z)
 if z!=Z:P[k]=z
 elif k in P:del P[k]
def Btensor(form):
 out={}
 for ia,za in form.items():
  for ib,zb in form.items():
   shared=tuple(i for i in ia if i in ib)
   for K in combinations(shared,2):
    A=tuple(i for i in ia if i not in K);D=tuple(i for i in ib if i not in K);z=mul(za,zb);base=parity(K+A)*parity(K+D)
    for n in A:
     rest=tuple(i for i in A if i!=n)
     if set(rest)&set(D):continue
     sign=base*parity(rest+(n,))*parity(rest+D);put(out,(tuple(sorted(rest+D)),n),(sign*z[0],sign*z[1]))
 return out
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('ETA_OFFBLOCK_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 basis=[];top=[];lookup={}
 for tail in combinations(range(1,10),4):
  I=(0,)+tail;J=tuple(i for i in range(10) if i not in I);sg=parity(I+J);idx=len(basis);basis.append({I:(1,0),J:(0,-sg)});top.append(I);lookup[I]=(idx,(1,0));lookup[J]=(idx,(0,-sg))
 assert len(basis)==126 and len(lookup)==252 and all(sum(a*a+b*b for a,b in v.values())==2 for v in basis)
 diagonal=[Btensor(v) for v in basis];rows=[];leg=[0]*126;harmonic=[[Z for n in range(10)] for a in range(126)];S0=0;chiral=True
 for a in range(126):
  for b in range(a,126):
   if a==b:B=diagonal[a].copy()
   else:
    form=basis[a].copy();form.update(basis[b]);B=Btensor(form)
    for old in [diagonal[a],diagonal[b]]:
     for k,z in old.items():put(B,k,(-z[0],-z[1]))
   q={}
   for (I,n),v in B.items():
    J=tuple(i for i in range(10) if i not in I);sg=parity(I+J);assert B.get((J,n),Z)==(sg*v[1],-sg*v[0]),('B_HODGE',a,b,I,n)
    idx,phase=lookup[I];put(q,(idx,n),mul(v,conj(phase)))
   Rnorm=sum(x*x+y*y for x,y in B.values());qnorm=sum(x*x+y*y for x,y in q.values());assert qnorm==2*Rnorm
   weight=2 if a==b else 1;S0+=weight*qnorm;rows.append([a,b,Rnorm,qnorm,weight*qnorm,len(B)])
   if a==b:
    leg[a]+=4*qnorm
    for n in range(10):harmonic[a][n]=add(harmonic[a][n],tuple(2*z for z in q.get((a,n),Z)))
   else:
    leg[a]+=qnorm;leg[b]+=qnorm
    for n in range(10):harmonic[b][n]=add(harmonic[b][n],q.get((a,n),Z));harmonic[a][n]=add(harmonic[a][n],q.get((b,n),Z))
  if a%21==0:print('STAGE complete_pair_first_index_'+str(a),flush=True)
 assert len(rows)==8001 and sum(leg)==2*S0 and all(z==Z for row in harmonic for z in row) and len(set(leg))==1
 # Actual gauge orbit in canonical complex coordinates; no full GUT basis assumed.
 vac=vacuum_form();orbit=[]
 for p,q in combinations(range(10),2):
  form={}
  for I,z in vac.items():
   if (p in I)==(q in I):continue
   old,new,sign=(p,q,-1) if p in I else (q,p,1);J=tuple(new if i==old else i for i in I);sign*=parity(J);put(form,tuple(sorted(J)),(sign*z[0],sign*z[1]))
  for I,z in form.items():
   J=tuple(i for i in range(10) if i not in I);sg=parity(I+J);assert form.get(J,Z)==(sg*z[1],-sg*z[0])
  orbit.append([form.get(I,Z) for I in top])
 G=S.Matrix([[x+S.I*y for x,y in row] for row in orbit]);k=G.rank();realrank=S.Matrix([[z for pair in row for z in pair] for row in orbit]).rank();assert 126-k>0
 productA=reps.multiply(reps.SIGMA,reps.VEC);productB=reps.multiply(reps.SIGMA,reps.BAR_SIGMA);decA=reps.decomposition_dimensions(productA);decB=reps.decomposition_dimensions(productB)
 common={w:d*m for w,d,m in decA if any(v==w for v,dd,mm in decB)};rankbound=sum(common.values());assert rankbound>0
 eta=F(3,10);retain=1-F(3*k,126);assert retain>0
 neutral_frobenius=4*eta*eta*S0;physical_operator2=retain*neutral_frobenius/rankbound;a0pi2=physical_operator2/256;failure=bool(a0pi2>F(1,4)*F(22,7)**2)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 result={'schema':'ETA_OFFDIAGONAL_BOUND_PRIMARY_V1','status':'COMPLETE_FIXED_VERTEX_TRACE_REQUIRES_INDEPENDENT_RECEIPT','base_commit':prep['base_commit'],'canonical_Sigma_complex_dimension':126,'basis_top_indices':list(map(list,top)),'pair_rows':rows,'all8001_pairs_including_diagonal':True,'diagonal_nonzero_count':sum(bool(B) for B in diagonal),'charged_Fock_trace_eta_stripped':S0,'per_incoming_leg_trace':leg,'all1260_harmonic_trace_slots_zero':True,'all_B_coefficient_rows_selfdual':True,'gauge_orbit_complex_rank':k,'gauge_orbit_real_rank':realrank,'gauge_orbit_canonical_complex':[[[str(x),str(y)] for x,y in row] for row in orbit],'physical_P_complex_dimension':126-k,'decomposition_126_times_10':[[list(w),d,m] for w,d,m in decA],'decomposition_126_times_bar126':[[list(w),d,m] for w,d,m in decB],'neutral_map_rank_upper':rankbound,'physical_projection_retained_fraction':str(retain),'physical_eta':'3/10','neutral_Frobenius_squared':str(neutral_frobenius),'physical_operator_norm_squared_lower':str(physical_operator2),'a0_squared_times_pi_squared_lower':str(a0pi2),'exact_pi_upper_tree_criterion_failure':failure,'fixed_input_eight_quartic_tree_screen_excluded':failure,'full_Spin10_parameter_space_excluded':False,'nonperturbative_theory_refuted':False,'new_parameter_search':False,'new_model_parameter_points':0,'new_benchmark_or_family_adopted':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 timer.cancel();print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True)
if __name__=='__main__':main()
