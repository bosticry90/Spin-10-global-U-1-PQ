# Fixed eta excludes the declared eight-quartic tree-perturbative comparison

The unchanged eta=3/10 interaction gives a rigorous lower bound

```
||a0|| >= sqrt(837/280)/pi >1/2
```

for the project's fixed-coupling,asymptotic tree scalar perturbativity screen.
The bound retains only non-Goldstone scalar directions and uses canonical
two-particle normalization. Other eight varied quartics cannot cancel this
offdiagonal block. Consequently no member of the DECLARED frozen-VEV,
fixed-nonfamily-input eight-quartic comparison passes that necessary screen.

This is a domain-wide failure under the stipulated TREE criterion,not a
refutation of Spin(10),the invariant action,all its parameter choices,
nonperturbative descriptions or exact quantum unitarity. Full-model physical
viability remains **INCONCLUSIVE**. Authority34/39 unchanged. Qualification
requires the[prospective record](RECORD.md),actual[receipt](validation_receipt.json)
and raw Git checks. Stop further candidate/matching work inside this excluded
comparison;any expanded input domain needs a director scope decision.

In plain language:the problem is now a fixed interaction that the eight
adjustable quartics cannot repair. Their earlier mathematical compatibility
results remain valid,but cannot provide a tree-perturbative benchmark while
this interaction stays at its frozen value. No coupling was changed to evade
the result. The[proposed next scope](PROPOSED_NEXT_SCOPE.md) is not authorized
or executed by this checkpoint.

## Canonical coefficient trace,with complete zero channels

The[parent definition](../canonical_so10_scalar_reconstruction/RECORD.md) gives
L_Sigma=(1/(2*5!))|D Sigma|^2. Each complementary-pair selfdual basis form
F_I hasN=2,so its independent complex coordinate has kinetic|dz_I|^2.
All126 basis forms and their phases are explicit. The raw coefficient
eta*(sqrt(3/160))^3 cancels the same canonical field rescaling;the physical
eta in this calculation is the current3/10 override,not the obsolete zero
in STAGE1. phi has standard complex kinetic normalization.

Write the actual eta source as

```
E_n=sum_c q_c,n(z)*conjugate(z_c),
q_c,n(z)=sum_(a<=b) q_ab;c,n*z_a*z_b.
```

The literalB[I5,n] map is projected byconjugate(F_c). The calculation retains
all8001 unordered incoming pairs,including126 diagonal rows. It evaluates
their coefficients before inspecting zeros;none are omitted by prediction.
Every coefficient row obeys the correct Hodge condition. Projection gives
sum|q_ab;c,n|^2=2sum|B_ab[I,n]|^2. Canonical identical incoming pairs have
sqrt2 timesq_aa;distinct pairs haveq_ab. The exact charged-block Frobenius
trace with eta stripped is

```
S0=604800.
```

All diagonal coefficient rows vanish by actual calculation. Offdiagonal
norms depend on index overlap:overlap2/3 gives||B||^2=48,overlap1/4 gives0.
Each complete fixed-leg trace is9600. The independent route reconstructs
two fixed-leg inventories by a K-first paired contraction instead of the
primary incoming-pair routing. Schur irreducibility givesS0=126*9600/2.
Signed-coordinate SO(10) covariance classifies all8001 primary norm rows:
map the four index-set intersection regions by a coordinate permutation,
correct its orientation with an axis sign,and retain the resulting unit
selfdual phases. This is a global covariance argument,not extrapolation
from a few arbitrary fields. The full1260 harmonic-trace slots also vanish;
two independent fixed-leg harmonic controls reproduce their zero.

## Neutral block and normalization/rank proof

In canonical real fieldsz=(x+iy)/sqrt2,the full three-Sigma/one-phi contact
offblock splits by asymptotic PQ charge. Each of the two charged blocks
contributes|eta|^2*S0;the neutral block contributes4|eta|^2*S0. These factors
follow directly by reshuffling the symmetric two-Sigma coefficient tensor:
one neutral output branch has twice the charged Frobenius trace,and its
Hermitian-conjugate branch is orthogonal. The total real offblock has trace
6|eta|^2*S0. Explicit real/Fock unitary transformations for distinct and
identical incoming toy vertices check every factor. A nonharmonic cubic
control shows why a Gaussian-moment shortcut would need an extra trace
hypothesis;the direct Fock proof does not rely on that shortcut.

Fresh exact D5 characters give

```
126 x10=210+1050,
126 xbar126=1+45+210+770+5940+8910.
```

The only common irrep is one210. Hence the neutral mixed map has rank at
most210,even though its initial/final pair spaces are much larger. A separate
exterior4 character plus Weyl-character inner-product calculation obtains
m210=1,m1050=0 and verifies Sigma irreducibility. These products agree with
[Slansky,table42](https://math.soimeme.org/~arunram/Teaching/RepThy2008/slansky.pdf#page=105).
They are established representation facts,not claimed new AI discoveries.

## Conservative physical projection

Actual45 generator actions on the frozen Sigma vacuum have real rank21
and complex span rank11. Both ranks are calculated,with independent exterior
actions and exact Gaussian elimination. The Hermitian orthogonal complement
P therefore has115 complex Sigma directions. A pureSigma vector in P is
orthogonal to every FULL gauge-orbit direction,including orbits with Phi
components. phi has zero VEV and all10 complex phi directions are orthogonal
to the gauge orbit. These are non-Goldstone perturbative scalar directions.
The extra radial direction discarded when complexifying the21-real orbit
is conservative;no potential zero mode is assigned a physical propagator.

P is complex-linear,so it preserves the asymptotic contact charge splitting.
For the neutral coefficient tensor,each Sigma-leg partial Gram commutes with
the irreducible126 action and is a scalar identity. Projecting one complex
leg loses exactly11/126 of the squared Frobenius norm. The three commuting
leg projections retain at least1-33/126=31/42 by the projection union bound.
Pre/post projection cannot increase matrix rank,so the physical neutral
offblock still has rank at most210. Therefore

```
||M_physical||^2 >= (31/42)*(4|eta|^2*S0)/210
                  =26784/35              at eta=3/10.
```

The full Hermitian tree operator norm is at least this offblock norm:
applying it to a vector supported on one pair sector already produces the
offblock output. Unknown diagonal couplings cannot cancel that lower bound.
No eight-quartic value or parameter search enters this argument.

## High-energy interpretation and exact failure

Use[Goodsell and Staub,equations2--5](https://arxiv.org/pdf/1805.07306) for
the canonical pair factors and partial-wave normalization. In the declared
fixed-coupling large-energy contact limit,a0=M/(16pi). This gives

```
||a0||^2 >=837/(280pi^2)>1/4,
```

with the strict sign following frompi<22/7 by integer arithmetic. This is
a lower bound,not the largest eigenvalue itself. It is about0.550,above1/2.
Keeping eta symbolic,the same necessary screen requires

```
|eta|^2 <=(7/930)*pi^2, i.e. |eta|<=pi*sqrt(7/930),about0.273.
```

This is a necessary upper bound,not a permitted fitted value or proof that
any smaller eta works. Full scattering can require a stronger restriction.
The current input3/10 fails without changing any of the eight varied quartics.

Only eta has the required3Sigma/1phi quartic field content in the qualified
complete action. Gauge kinetic vertices pair scalars within one species;
every s/t/u pairing of these four external legs has one mixedSigma/phi vertex,
so leading gauge exchange in this offblock is zero. Scalar cubic exchange
is subleading in the same fixed-coupling asymptotic screen used previously.
Identify the hard limit with fixed physical masses/IR regulator before any
massless limit;do not interpret it as a completed infrared-safe finite-energy
amplitude. No new physical regulator,gauge parameter or benchmark prescription
is adopted. This calculation does not prove a running-coupling,finite-cutoff
or nonperturbative no-go. The cited software's restricted examples do not
supply this model's group calculation;only its general normalization is used.

The mathematical bound is on a non-Goldstone scalar subspace of the
perturbative high-energy problem. It is not an assertion that colored fields
are independently observable asymptotic particles in the exact confined theory.
The scientific disposition is FAIL of the project's stipulated asymptotic
tree perturbativity acceptance condition,not an exact S-matrix inconsistency.

## Disposition and director decision

The fixed-input eight-quartic recovery cannot provide the sought benchmark
under the existing tree-perturbativity criterion. Stop further feasibility
repairs/searches or expensive matching inside that domain. Preserve the
positive local mass/Higgs theorems,pure-Sigma identity/positivity,308 certificate,
continuous-slice reduction and D-lift;they never established full scattering.
Their mathematical content is not invalidated by this stronger exclusion.

Changing eta would change a previously frozen nonfamily input and the weak
mixing/source/mass conditions. The negative result must not be fitted away
by assigning eta a new value. Any expanded symbolic comparison requires
the director's authorization under[AGENTS.md](../../AGENTS.md). The concrete
[next-scope proposal](PROPOSED_NEXT_SCOPE.md) limits such work and is inactive.
Publication,benchmark adoption and scientific acceptance remain separate.

## Verification and AI capability

One complete8001-pair coefficient trace is checked by independent compressed
trace/covariance classification,alternate character inner products,actual
orbit ranks and canonical-real/Fock controls. The physical projection argument
uses unitary kinetic structure,covariance and irreducibility;rank alone would
not justify it. Wrong identical-pair,real/complex dimension,projection loss,
nonharmonic Gaussian,rank-versus-trace and species-pairing controls are explicit.
Resources:two120-second/8GiB native roles with direct350MiB launch observation,
full source/input capture,current read-only preflight and raw index/HEAD bytes.
No fresh byte-identical replay pair or old8001 wedge/spectrum replay is claimed.

Track B records an efficient fixed-input exclusion and a serious prioritization
limitation:substantial scalar/Higgs algebra preceded this simpler uncancelable
interaction screen. The earlier results are valid within scope,but did not
answer full perturbativity. Shared action,kinetics/VEV/eta,asymptotic assumptions,
D5/tensor conventions,some arithmetic,Python/SymPy and analyst limit independence.
Published reference standards are not external endorsement of this model.
No experimental support or general AI scientific reliability is established.
Science and AI capability remain equal objectives;education nonblocking.

Preserveproject_state.json,sealed README,authority34/39,custody exit2/seven,
quartetFAIL,E5/A5unqualified,HB1/C5block,C1_GSgap,flavor pause and all earlier
evidence. No parameter,input,new family,benchmark,physical scale,authority,
blocked stage,publication,outreach or remote action changes. The broad
Spin(10) investigation remains active and incomplete pending next direction.
