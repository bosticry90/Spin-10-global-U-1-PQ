# Exact angular arithmetic correction V4

V3 passed its symbolic comparisons and corrected15-profile check,then the
actual exact-ring fixture rejected a floating coefficient. Python division
in the angular-moment helper introduced floats from two integer products.
V4 constructs that quotient with SymPy Rational and explicitly rejects all
Float coefficients before actual color data. Preserve the failed V3 source
and capture;no V3 result exists. No physics,normalization,acceptance or
resource change. The universal comparison is rerun with exact rationals.
