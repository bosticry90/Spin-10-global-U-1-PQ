# Preexecution comparison correction V2

The frozen V1 worker was not executed. Source review found that its positive
comparison mixed the full inverse orders0,1,2 with a Born expression for
order2 only. The replay also tried to read the reference order from that
order2 expression. This is an assertion/setup error,not a measured failure
or a physics change. Preserve V1 source/preparation. V2 projects both routes
to order2 for their comparison and checks order0 from the reduced formula
separately. All prescribed Gaussian,color,Lorentz,UV,profile and independent
validation requirements and180-second/8GiB limits remain unchanged.
