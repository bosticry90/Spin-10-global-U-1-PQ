# Ordinary g3 auxiliary companion trace V1

Baseline059a932a87a3ad668a8ae621a267a8165db0eeca. Question ACT1:calculate
the actual ordinary g3,no-jet,coefficient-dimension-zero Lambda-A_H-B and
Lambda-B-B logarithmic UV density as one exact ordered color trace,without
expanding its full component tensor. This is a measured coefficient formula,
not a Ward completion or a newly adopted counterterm. Component integration
and the dependent Ward comparison remain a later increment.

Reuse the qualified225-coordinate ordered inverse and actual classical
N1,D1,U tensors. Freeze source,record,method,controllers,policy and inputs
before two sequential180-second-after-import/8GiB sampled-private workers
and an independent180-second/8GiB validator;minimum350MiB available commit.
No old large Hessian/loop replay,no truncation or automatic resource increase.
Preserve failures with immutable captures/versioned corrections.

External A_H/total B are independent arbitrary colors along a common Lorentz
axis;quantum auxiliary/ghost backgrounds vanish before the single-Lambda
derivative. The principal flat Gaussian contains all180 vector+45 auxiliary
coordinates. Both widths remain symbolic/noncommuting matrices. C=N D is
not ghost P=N D+E. Scalars/masses/explicit-xi ghost vertices are excluded
ONLY by the complete actual15-profile marginal ordinaryg3 census. Retain
all3 ABL and12 BBL profiles,including UUU,UG3U,UG3G3 andUG4 cycles.
All local rank-two Lorentz coefficients are eta_mu_nu by the qualified
no-jet argument;retain the full4-dimensional angular average,not a1D loop.

Derive the actual one-Lambda insertion from the unchanged GF Hessian:
K_Lambda=g*T_Lambda*eta_mu_nu in the vector block only. Show why linear
A_H B_H Lambda_H terms have no two-quantum Hessian. Derive i/2 Tr(G K_L)
by the finite Gaussian determinant and check complete cyclic multiplicities
against explicit distinct-source ring permutations. No regularized trace
cyclicity or operator-residue theorem is assumed. Matrix cyclicity is only
finite color/Lorentz trace at each fixed loop momentum.

Primary expands the ordered projected inverse into a universal free-word
color polynomial. Replay independently expands the full5-block Lorentz/
auxiliary Born inverse,keeping arbitrary noncommuting F=ad_B,X=N1,X^T,W.
Its5 entries are blocks of color matrices,not a one-color approximation.
Prove the underlying universal4-Lorentz polynomial from curvature
polarization and actual N/D conventions;do not infer it from a desired pole.
Compare before averaging and retain separated G3G3,G3U,UU,G4 contributions.

Use a positive UV annulus or positive auxiliary IR mass to isolate the
homogeneous degree-minus4 logarithmic term. Derive all angular moments in
4 dimensions and the existing Minkowski radial2i normalization in common
hbar/(32*pi^2*epsilon_UV) units. No whole scaleless,finite,power-sensitive or
physical IR amplitude zero follows. Show D=4 angular evaluation suffices
for the simple local UV pole;evanescent finite terms are outside scope.

Authenticate all actual57-background N/D coefficients and all45 symmetric
U tensors in4 Lorentz copies. The trace polynomial plus these literal
matrices losslessly specifies all color coefficients;no finite fixture
alone proves universal color coverage. Use an actual noncommuting field
fixture only to give a nonzero coefficient witness and ordering controls.
Check universal transposition/Lorentz relabeling,zero-background/no-A-D,
symbolic width degree and independent A/B polarization. Report individual
operator controls honestly when a trace may be insensitive.

Independent validation must derive the full Born symbol by direct curvature
polarization,check the universal free-word coefficients/UV moments,finite
Gaussian cyclic factors,all actual N/D/U normalizations and the complete
profile applicability. Separate arithmetic and matrix checks are required;
no native coefficient polynomial is a premise. Workers must not read the
known Gamma,primitive,conditional Ward completions,a needed companion or
peer output. Existing g2 evidence is reused for classical U/UV conventions,
not rerun or used as a fitted normalization target.

Meaningful result:qualified exact pole density in ordered trace form,or
precise applicability/inconclusive failure. No dense tensor/count claim,
canonical insertion,Slavnov/Ward cancellation,full source-free completeness
or E5 promotion. Keep38-source/selected-bilinear scopes,508 programs,
128 source jets,32 product maps,nonzero Jacobian,QC.A1-A5/QAP/contact/
Legendre/measure/IR gaps. Authority34/39,HB1/C5 block,flavor pause,C1_GS,
quartet/scalar warnings,closed routes,custodyexit2/seven preserved. No
scheme,input,benchmark,foundation,policy or remote action. Shared action,
old proofs/software/AI author limit independence. Education nonblocking.
