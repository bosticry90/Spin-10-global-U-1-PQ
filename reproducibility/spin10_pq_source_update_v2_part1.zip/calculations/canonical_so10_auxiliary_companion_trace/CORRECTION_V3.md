# Profile-label correction V3

The V2 primary completed its universal inverse,Gaussian,UV-moment and
transposition checks but failed its profile assertion. Its port loop already
unpacked the label string,then incorrectly inspected its first character
when counting AH. Preserve primary_v2_capture and source;no V2 result exists.
V3 compares the complete unpacked labels and keeps the required3+12 counts.
The replay controller also points to its actual versioned primary capture.
No mathematical requirement,physical input or180-second/8GiB limit changes.
