# Ordinary g3 auxiliary companion pole in exact ordered trace form

Prospective until the paired captures/results,independent validation receipt
and committed-byte checks qualify. Baseline059a932a87a3ad668a8ae621a267a8165db0eeca.

The actual ordinaryg3,no-jet Lambda-A_H-B and Lambda-B-B UV-log density has
been calculated as a lossless finite color trace,without a dense component
expansion or a Ward fit. In common hbar*g10^3/(32*pi^2*epsilon_UV) units it is

    -Tr_color(T_Lambda P2),

with Y=X^T,F=ad_B,X=N1(A_H,B),W=W_H P_H+W_M P_M and

    P2 = 3/4*(F F+F W F+F X-W F Y+X F W-X Y-Y F)
         +1/4*(W Y Y-X W Y+X X W).

Products are ordered. T_Lambda is the literal symmetric two-vector Hessian
of the original GF interaction,not an invented group normalization. F has
no external-A term and B is the total field. Arbitrary independent A/B
colors enter X and F. The formula specifies every color coefficient by
ordinary matrix products and polarization;it is not a claim to have printed
the complete canonical component tensor or integrated it into Gamma.

The background on each Lorentz axis contributes eta_mu times this quadratic
expression. The qualified no-jet Lorentz argument permits only eta_mu_nu;
the independent validator must use all4 momentum components and the full
UV projector. A one-axis background is not a one-dimensional loop integral.

The actual one-Lambda insertion follows from i*Tr log H/2 and is i/2 times
Tr(T_Lambda E_eta G2_BB). Finite positive-Gaussian and explicit cyclic-ring
checks retain all6 distinct triangle permutations and both bubble positions.
The homogeneous UV logarithm has radial2i in the recorded Minkowski32*pi2
normalization,so the resulting density has the displayed minus sign. This
uses finite color/Lorentz traces at fixed momentum;no regularized-functional
trace cyclicity or Wodzicki theorem is assumed. Positive auxiliary IR mass
or a UV annulus separates the log. Finite,power-sensitive,physical IR and
mass/VEV-dependent amplitudes are outside this calculation.

Primary uses the qualified ordered projected inverse. Replay uses the full
4+1 Lorentz/auxiliary block Born expansion with arbitrary noncommuting
color symbols. Both retain the two transverse Lorentz components. The
separate pure gauge triangle and quartic-bubble terms are

    G3G3: 3 F F+3/4 F W F+3/4 W F F W,
    G4:  -9/4 F F-3/4 W F F W.

Their width-squared terms cancel only in the complete sum. The other
families G3U and UUU supply the remaining terms in P2. The final formula is
affine linear in W,not width-independent. Neither W nor X is commuted
through F. The ghost kernel P=N D+E is never substituted for N D.

All3 ABL and12 BBL profiles are retained from the actual complete marginal
census. They contain precisely these four U/G3/G4 families,no explicit-xi
ghost vertex and no scalar/mass insertion. The all45 U tensors and57 N/D
matrices are authenticated. T for light Lambda_H vanishes in the two-quantum
Hessian. A-only X is HH and T is H/M-offdiagonal,so the AA trace vanishes
structurally. These are target-specific exclusions,not blanket amplitude
zeros. Both symbolic reference widths remain independent.

For the diagnostic A_H0=B_H0=B_M13=1,the actual unexpanded trace gives one
nonzero auxiliary coefficient,Lambda14:

    sqrt(10)*(12 W_H-9 W_M-9)/25.

The other44 auxiliary coordinates vanish in that fixture. It is an exact
normalization/ordering diagnostic,not adopted physical data and not the
proof of general color coverage. General coverage comes from the free-word
identity and the complete literal matrices.

The unexecuted frozenV1 was corrected after preexecution review of an
order0/1/2 comparison. V2 then failed an AH-label count after its universal
checks. V3 failed because Python division introduced floats into angular
moments. V4 uses exact Rational arithmetic with explicit Float rejection.
Both failed captures/sources and the unexecuted source remain immutable;
requirements were not relaxed. PrimaryV4 took2.6146 seconds;replay and
validator captures own actual timings/peaks. No fresh byte-identical replay
pair is claimed. Shared action,catalogue,old proofs,software,UV conventions
and AI author limit independence;corroboration is not expert validation.

Independent validation must reconstruct the actual4-momentum curvature
Hessian and Born coefficients with ordinary noncommutative SymPy arithmetic,
check every UV angular term and all four family polynomials,rederive
Gaussian/cyclic/radial factors,reconstruct all45 literal U tensors and57
N/D matrices,and match the profile restrictions/fixture/controls. A selected
nonzero operator control need not change every actual color trace;that
sensitivity limitation is explicit. Limits180seconds after imports/8GiB
sampled private/minimum350MiB available commit per sequential run.

NEXT:expand this measured trace into the canonical ABL/BBL coefficient
tables with complete zero complements,field/source dual maps and separate
AB/BB Bose conventions. Only after independent coefficient qualification
compare the complete selected local-H relation using the same known mixing
and both measured companions. Never fill a coefficient from V225's nonunique
conditional completions. If the complete relation leaves a remainder,inspect
actual inputs/regulated-reference obligations;do not label it an anomaly.

Gamma remains146162 words/hashf0b650d6a343a98e105c7aee8894fca84a70dad17d64620b9ee3181488fceee1.
Current partial Ward gaps and fixed-primitive72826 residual are unchanged.
38-source/selected-bilinear claims retain their domains. Nonzero Jacobian,
32 product maps,128 source jets,508 programs,QC.A1-A5/QAP/contact/Legendre/
measure/IR and quartet gaps remain. FullE5/A5/physical viability unqualified;
authority34/39,HB1/C5 blocked,flavor paused,C1_GS gap,scalar warnings,closed
routes,custodyexit2/seven unchanged. No scheme,input,benchmark,foundation,
policy,protected status or remote change. Education nonblocking;Lean selective.
