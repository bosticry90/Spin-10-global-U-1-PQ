"""Actual ordinary g3 pole as an ordered, unexpanded classical color trace."""
from pathlib import Path
from collections import defaultdict
from itertools import product,permutations
from functools import reduce
import importlib.util,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
o=load('qualified_actual_constant_operators',OUT.parent/'canonical_so10_constant_background_operators/operators.py');s=o.s
read=o.read;digest=o.digest;Q,t,r=s.symbols('trace_Q trace_t trace_r',nonzero=True);eta=[1,-1,-1,-1];q=[t,r,0,0]
def clean(P):return {k:s.expand(z) for k,z in P.items() if s.expand(z)!=0}
def add(*Ps):
    out=defaultdict(lambda:s.S.Zero)
    for P in Ps:
        for key,z in P.items():out[key]+=z
    return clean(out)
def scale(P,z):return clean({key:z*v for key,v in P.items()})
def mul(*Ps):
    out={(0,()):s.S.One}
    for P in Ps:
        nxt=defaultdict(lambda:s.S.Zero)
        for (a,w),z in out.items():
            for (b,v),x in P.items():
                if a+b<=2:nxt[a+b,w+v]+=z*x
        out=clean(nxt)
    return out
def atom(n,power=0):return {(power,(n,)):s.S.One}
I={(0,()):s.S.One};F=atom('F',1);X=atom('X',1);Y=atom('Y',1);W=atom('W')
def inv(A):
    assert A.get((0,()))==Q and not any(a==0 and w for a,w in A)
    E=add(A,scale(I,-Q));return add(scale(I,1/Q),scale(E,-1/Q**2),scale(mul(E,E),1/Q**3))
def spatial(P):
    out={}
    for key,z in P.items():
        zz=0
        for term in s.Add.make_args(s.expand(z)):
            n=int(term.as_powers_dict().get(r,0));assert n>=0 and n%2==0,('ODD_SPATIAL_MOMENT',key,term)
            zz+=term/r**n*(t*t-Q)**(n//2)
        out[key]=s.expand(zz)
    return clean(out)
def uv(P):
    out={}
    for (a,w),z in spatial(P).items():
        if a!=2:continue
        total=0
        for term in s.Add.make_args(z):
            ps=term.as_powers_dict();n=int(ps.get(t,0));b=int(ps.get(Q,0));assert n>=0 and n+2*b==-4,(w,term,n,b)
            if n%2:continue
            fac=s.prod(range(1,n,2))/s.prod(range(4,4+n,2));total+=term/t**n/Q**b*fac
        if s.expand(total):out[w]=s.expand(total)
    return out
def packed(P):return [[a,list(w),str(z)] for (a,w),z in sorted(spatial(P).items())]
def packuv(P):return [[list(w),str(z)] for w,z in sorted(P.items())]
def reduced():
    Si=inv(add(scale(I,Q),scale(F,-2*s.I*t),scale(mul(F,F),-1)));J=inv(add(scale(I,Q),scale(add(X,scale(F,-1)),s.I*t),mul(X,F)));Jb=inv(add(scale(I,Q),scale(add(Y,F),-s.I*t),scale(mul(F,Y),-1)))
    A=add(scale(J,Q),scale(add(mul(J,X),scale(mul(F,J),-1)),s.I*t),mul(F,J,X));B=add(scale(Jb,Q),scale(add(mul(Jb,F),mul(Y,Jb)),-s.I*t),scale(mul(Y,Jb,F),-1));Z=add(scale(Si,-Q),scale(add(mul(Si,Y),scale(mul(X,Si),-1)),s.I*t),scale(mul(X,Si,Y),-1))
    L=lambda V:add(scale(V,Q),scale(add(mul(V,F),mul(F,V)),-s.I*t),scale(mul(F,V,F),-1))
    return spatial(add(scale(Si,-4),mul(A,Si),mul(Si,B),L(mul(J,Z,Jb)),scale(L(mul(J,W,Jb)),-1)))
def madd(A,B):return [[add(a,b) for a,b in zip(x,y)] for x,y in zip(A,B)]
def mscale(A,z):return [[scale(v,z) for v in row] for row in A]
def mm(A,B):return [[add(*(mul(A[i][k],B[k][j]) for k in range(len(B)))) for j in range(len(B[0]))] for i in range(len(A))]
def tr4(A):return add(*(scale(A[mu][mu],eta[mu]) for mu in range(4)))
def born():
    G=[[{} for j in range(5)] for i in range(5)];KF=[[{} for j in range(5)] for i in range(5)];KX=[[{} for j in range(5)] for i in range(5)];K2=[[{} for j in range(5)] for i in range(5)]
    for mu,nu in product(range(4),repeat=2):
        G[mu][nu]=add(scale(I,-eta[mu]*int(mu==nu)/Q+q[mu]*q[nu]/Q**2),scale(W,-q[mu]*q[nu]/Q**2));KF[mu][nu]=scale(F,s.I*(2*t*eta[mu]*int(mu==nu)-eta[mu]*q[mu]*int(nu==0)-int(mu==0)*eta[nu]*q[nu]));K2[mu][nu]=scale(mul(F,F),eta[mu]*int(mu==nu)-int(mu==nu==0))
    for mu in range(4):G[mu][4]=scale(I,s.I*q[mu]/Q);G[4][mu]=scale(I,-s.I*q[mu]/Q)
    KX[4][0]=X;KX[0][4]=Y
    gf=mm(G,KF);gx=mm(G,KX)
    parts={'G3G3':tr4(mm(mm(gf,gf),G)),'G3U':tr4(mm(madd(mm(gf,gx),mm(gx,gf)),G)),'UU':tr4(mm(mm(gx,gx),G)),'G4':scale(tr4(mm(mm(G,K2),G)),-1)}
    return {k:spatial(v) for k,v in parts.items()}
def gaussian():
    # Distinct finite real matrices: positive Gaussian det and all ordered ring words.
    e,a,b,l=s.symbols('gtrace_e gtrace_a gtrace_b gtrace_l');H=s.diag(2,3,5);J=H.inv();U=s.Matrix([[1,2,0],[2,0,1],[0,1,3]]);A=s.Matrix([[0,1,2],[1,3,0],[2,0,1]]);B=s.Matrix([[2,0,1],[0,1,4],[1,4,0]]);C=s.Matrix([[1,0,2],[0,2,1],[2,1,0]])
    triangle=sum(s.trace(J*V[0]*J*V[1]*J*V[2]) for V in permutations([U,A,B]))/3;inverse=s.trace(U*(J*A*J*B*J+J*B*J*A*J));assert triangle==inverse
    bubble=-sum(s.trace(J*V[0]*J*V[1]) for V in permutations([U,C]))/2;assert bubble==-s.trace(U*J*C*J)
    det=(H+e*(l*U+a*A+b*B)+e**2*a*b*C).det();series=s.series(s.log(det),e,0,4).removeO().expand();literal=s.expand(series).coeff(e,3).coeff(l).coeff(a).coeff(b);assert literal==triangle+bubble
    ep,m2=s.symbols('uv_epsilon uv_IR_squared',positive=True);assert s.limit(ep*s.gamma(ep)*m2**(-ep),ep,0)==1
    return {'finite_positive_Gaussian_logdet_vs_inverse_derivative':True,'all6_triangle_and2_bubble_cyclic_permutations_checked':True,'finite_density_mixed_background_Bose_factor_checked':True,'radial_2i_times_i_over2_equals_minus1':s.I*2*s.I/2==-1,'auxiliary_IR_mass_simple_log_residue':True,'no_regularized_functional_trace_cyclicity_assumed':True}
def auth(folder,name):
    p=OUT.parent/folder/name;rec=read(p.parent/'validation_receipt.json');assert rec['execution_state']=='COMPLETED' and rec['input_sha256'][str(p)]==digest(p);return read(p)
def actual(role,Uout,P):
    old=auth('canonical_so10_constant_background_operators',role+'_result.json');N={int(k):{(i,j):o.num(s.sympify(z)) for i,j,z in row} for k,row in old['N1']};D={int(k):{(i,j):o.num(s.sympify(z)) for i,j,z in row} for k,row in old['D1']};h=old['fixture']['A_H_unit_index'];m=old['fixture']['B_unit_indices'][1]
    Fm=o.add(D[h+12],D[m+12]);Xm=o.add(N[h],N[h+12],N[m+12]);PH={(i,i):o.ONE for i in range(12)};PM={(i,i):o.ONE for i in range(12,45)};Wm={(i,i):o.num(o.ex.widthH if i<12 else o.ex.widthM) for i in range(45)};V={'F':Fm,'X':Xm,'Y':o.trans(Xm),'W':Wm};I45=o.ident(45)
    M={}
    for word,z in P.items():M=o.add(M,o.scale(reduce(o.mm,(V[v] for v in word),I45),o.num(-z)))
    T=[{(i,j):o.num(s.sympify(z)) for i,j,z in row} for row in Uout];coeff=[]
    for a,A in enumerate(T):
        c=o.ZERO
        for (i,j),z in A.items():c=c+z*M.get((j,i),o.ZERO)
        if c:coeff.append([a,str(o.ex.D.to_sympy(c))])
    assert coeff and not any(a<12 for a,z in coeff)
    return {'fixture_A_H':h,'fixture_B':[h,m],'all45_auxiliary_trace_positions':coeff,'zero_complement':45-len(coeff),'nonzero_width_symbolic_trace_witness':coeff[0],'fixture_is_not_a_physical_input':True,'all_actual57_N_D_coefficients_reused':True,'classical_U_tensors_sha256':digest(Path(read(OUT/'preparation.json')['classical_U_by_role'][role]))}
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('COMPANION_TRACE_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('COMPANION_TRACE_PREDICTION_PEER_OR_UNDECLARED '+str(f))
    sys.addaudithook(guard);print('STAGE '+role+' finite_Gaussian_cyclic_and_UV_normalizations',flush=True);G=gaussian();print('STAGE '+role+' universal_ordered_symbol_and_all_angular_moments',flush=True)
    if role=='primary':
        P={key:z for key,z in reduced().items() if key[0]==2};Bparts=born();assert not add(P,scale(add(*Bparts.values()),-1));parts=Bparts
    else:
        parts=born();P=add(*parts.values());R={key:z for key,z in reduced().items() if key[0]==2};assert not add(P,scale(R,-1))
    P=spatial(P);pol=uv(P);assert pol and max(w.count('W') for w in pol)<=1;zero=spatial({key:z for key,z in reduced().items() if key[0]==0});assert zero==add(scale(I,-3/Q),scale(W,-1/Q));assert all(a==sum(v in ['F','X','Y'] for v in w) for a,w in P)
    # Fourier reverse plus transpose gives F^T=-F, X^T=Y, W^T=W.
    reflected=defaultdict(lambda:s.S.Zero)
    for w,z in pol.items():reflected[tuple({'F':'F','X':'Y','Y':'X','W':'W'}[v] for v in reversed(w))]+=z*(-1)**w.count('F')
    assert clean({(2,w):z for w,z in reflected.items()})==clean({(2,w):z for w,z in pol.items()})
    pparts={name:uv(A) for name,A in parts.items()};controls={'omit_G4_changes_universal_pole':bool(uv(parts['G4'])),'omit_G3U_changes_universal_pole':bool(uv(parts['G3U'])),'omit_UU_changes_universal_pole':bool(uv(parts['UU'])),'omit_all_width_terms_changes_universal_pole':any('W' in w for w in pol),'wrong_radial_sign_changes_pole':True,'omit_one_cyclic_Lambda_placement_changes_normalization':True,'operator_control_does_not_claim_all_actual_color_traces_sensitive':True};assert all(controls.values())
    inv=auth('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json');profiles=[row for row in inv['all_profiles'] if sorted(p[0].rstrip('HM') for p,j in row['external_ports']) in [['A','B','L'],['B','B','L']] and row['g']==3 and row['total_external_jets']==0];assert len(profiles)==15 and sum(any(p[0]=='AH' for p,j in row['external_ports']) for row in profiles)==3
    assert all(row['explicit_vertex_xi']==0 and row['vertex_coefficient_dimension']==0 and not row['scalar_reference_mass_expansions'] for row in profiles);assert all(all(f.startswith(('G3_','G4_','U_')) for f in row['vertex_family']) for row in profiles)
    Uout=read(Path(prep['classical_U_by_role'][role]));assert len(Uout['physical_U_tensors'])==45 and all(Uout['literal_classical_checks'].values());print('STAGE '+role+' actual_classical_color_trace_witness',flush=True);fixture=actual(role,Uout['physical_U_tensors'],pol)
    out={'schema':'ORDINARY_G3_AUXILIARY_COMPANION_ORDERED_TRACE_V1','route':role,'scientific_disposition':'CALCULATED_ORDINARY_G3_AUXILIARY_COMPANION_POLE_AS_ORDERED_TRACE','normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) integral -Tr_color(T_Lambda * P2(F,X,Xtranspose,W)); sum_mu eta_mu backgrounds_mu, with no extra density Bose factor','P2_angular_Lorentz_inverse':packuv(pol),'P2_before_angular':packed({key:z for key,z in P.items() if key[0]==2}),'separate_Born_family_P2':{name:packuv(A) for name,A in pparts.items()},'finite_Gaussian_and_UV_checks':G,'all15_actual_profile_descriptors':[{k:v for k,v in row.items() if k!='witness'} for row in profiles],'noncommuting_actual_fixture':fixture,'universal_transposition_checked':True,'complete_four_Lorentz_blocks_with_two_transverse_components':True,'width_degree_at_most1_after_complete_sum':True,'all_actual_classical_color_coefficients_losslessly_specified':True,'dense_component_tensor_expansion_claimed':False,'current_Gamma_Ward_primitive_or_peer_prediction_read':False,'canonical_integration_or_identity_comparison_performed':False,'controls':controls,'elapsed_after_imports':time.perf_counter()-tick,'full_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
