# Frozen Gaussian and ordered-symbol method

For real uneliminated bosons phi,the quadratic action is phi^T H phi/2.
The connected one-loop density is i*hbar*Tr log H/2. Differentiate in a
single external Lambda at zero Lambda;the actual GF contributes only
g*T_Lambda*eta_mu_nu in H_BB. The linear Lambda_H A_H B_H term does not
produce a two-quantum Hessian because A_H has no reference edge.

Write H=H0+g H1+g2 H2+g T_Lambda E_eta. The coefficient of one Lambda and
two vector backgrounds is i*g3*Tr[T_Lambda E_eta G2_BB]/2,where

    G2=G0 H1 G0 H1 G0-G0 H2 G0.

The log series gives3 cyclic Lambda placements times1/3 for the triangle,
and2 times(-1/2) for the quartic bubble,both with overalli/2. Distinct
background polarization retains both H1 orderings;repeated fields are
density coefficients,not differentiated vertices with an extra factor2.
The full Hessian contains both mixed orientations,so no additional hidden
orientation factor is introduced. A finite positive Gaussian check and
explicit ring-permutation check will test this before group data is used.

Let temporal backgrounds give D_mu=i q_mu+g F delta_mu0,
N_mu=-i eta_mu q_mu+g X delta_mu0,barD_mu=-i q_mu-g F delta_mu0,
barN_mu=i eta_mu q_mu+g X^T delta_mu0. Define Q=q^2,t=q0,

    S=Q-2i*g*t*F-g2*F2,
    C=Q+i*g*t*(X-F)+g2*X*F,
    barC=Q-i*g*t*(X^T+F)-g2*F*X^T.

Their ordered formal inverses have leading1/Q. With J=C^-1,Jb=barC^-1,
Si=S^-1,R=-E_eta Si,the qualified vector inverse is
(I-D J N)R(I-barN Jb barD)-D J W Jb barD. Define ordered

    A=Q J+i*g*t*(J X-F J)+g2*F J X,
    B=Q Jb-i*g*t*(Jb F+X^T Jb)-g2*X^T Jb F,
    Z=-Q Si+i*g*t*(Si X^T-X Si)-g2*X Si X^T,
    L(Y)=Q Y-i*g*t*(Y F+F Y)-g2*F Y F.

The Lorentz trace E_eta G_BB equals

    -4 Si+A Si+Si B+L(J Z Jb)-L(J W Jb).

Every product remains ordered;X^T,F,W generally do not commute. The replay
does not assume this trace formula:it uses the literal full4+1 block Born
series. Its universal K_BB comes from the actual curvature polarization.

The degree-minus4 angular operation maps t^(2r)/Q^(r+2) to
(2r-1)!!/[4*6*...*(4+2r-2)] and odd terms to0. One may set the momentum to
(t,s,0,0) while doing the spatially rotationally invariant Lorentz trace,
then use s2=t2-Q;this retains all4 components,including2 transverse blocks.
The independent validator uses full angular projector contractions.

In the inherited Minkowski/Fourier convention the simple homogeneous UV
radial pole is2i in32*pi2 units. Thus i/2 times2i=-1,and the requested
ordinaryg3 local density is minus the finite color trace of T_Lambda times
the angular average of the displayedg2 Lorentz trace. Auxiliary positive
IR mass/UV annulus separates the log;no whole scaleless or finite/IR claim.
The g3 polynomial is quadratic in the arbitrary backgrounds and is the
lossless coefficient representation. A/B color polarization defines the
two selected classes without adopting a Ward completion.
