# Four-leg source pole: general-momentum unit kernels V1

Baseline25c39f0ac4b90a35c4f583aa3ab46f4014b61edd. The qualified inventory
leaves SL*F*F*X, KL*F*X and KL*Q as conservative candidates for the selected
dimension-zero g10³ JLambda*a*C*C local logarithmic pole. This increment
calculates the general-q graded/Lorentz unit factors needed before the actual
color tensor. It does not calculate that tensor or a complete Slavnov relation.

Keep the parent action, reference conventions, frozen H/M split, source-left
pairing, all previous failure dispositions and statev113/34of39 unchanged.
AGENTS.md delegates this ordinary bounded prerequisite, not blocked-stage or
physical-input adoption. No benchmark search or point-specific matching occurs.

Inputs: the qualified classical source/GF/reference helpers and inventory,
exact file bytes in preparation.json. Unit quantum variables label distinct
internal lines; they are comparator variables, not new physical particles.
JLambda,a,C are odd with grades(1,-1),(1,-1),(1,+1). External sources have no
propagator. Vertices are even,d4,gh0. Target order is JLambda*a*C0*C1 without
an extra1/2; ghost interchange is handled by exterior multiplication.

Mixed B/L inverse entries are+i*q_mu/K and-i*q_mu/K; ghost orientations are
1/K and-1/K, K=q0²-q1²-q2²-q3². Retain the complete width-dependent B/B
inverse as an exclusion/control, not a contributing assumption. Use four
symbolic momentum components throughout. Zero external jets select only the
leading UV Taylor coefficient above k_E²>R_UV²>0. No whole scaleless integral,
finite amplitude, physical gauge independence or IR conclusion is inferred.

The toy source-cubic box has two external-antighost placements compatible
with the source's internal H ghost, all3x3 derivative placements in F vertices;
the source-quartic triangle has three external-antighost placements and three
F derivative placements; the bubble has two source external-leg patterns.
These29 cases include coefficients that should vanish. Model definitions
are frozen in the runtime source before execution. Direct actual color/GF
coefficients and their cancellations remain a later mandatory calculation.

Primary: literal graded Fourier Hessians and all ordered supertrace words,
with i/2 log expansion factors -i/8,+i/6,-i/4 for box/triangle/bubble. For
two occurrences of the same full F vertex, compare the12 multiset words of
S,F,F,X with the24 distinct-component S,F0,F1,X words. Preserve every order.
Replay: independent labeled Wick pairings, external Grassmann extraction,
connected-cycle filtering and unique momentum routing derived from vertex
conservation. Derive its factors from -i log Z and the vertex expansion,
not from the primary factors. Each route is a separate blind worker.

Acceptance requires equality of all29 complete kernels after both workers
finish; exact general-q pole constants; derivative IBP-current row/column
sums; zero external-derivative checks; nonzero diagnostic anchors; sensitivity
to omitted mixed propagation and reverse odd propagation; forbidden ghost
pair control for bubbles; correct odd-source grading; and actual identical-F
grouping equality. Width/transverse removal should be nondiscriminating here
and must not be advertised as a successful omission falsifier. No known
Slavnov residual, required tensor or physical pole coefficient is read or fitted.

Freeze runtime/input/controller sources before two sequential scientific
workers, each120seconds after imports,8GiB sampled private memory and350MiB
minimum available commit. Preserve full native captures and all failed/
unfinished runs. No retry or resource expansion inside this V1. Standing
delegation permits a separately justified preserved correction if necessary.
Validation is read-only and proportionate; no old expensive physics replay
or new same-command fresh pair is required merely for this kernel increment.

The exact graded Gaussian/logarithm and Wick expansion identities are the
reference standards; the inherited helpers are not independent human authority.
Shared toy model, conventions, Python/SymPy and analyst limit independence.
Agreement tests signs, routing and factors within these declared inputs,
not the physical correctness of an unverified shared assumption.

Outcome ceiling: qualified general-q unit factors, their controls, or an
explicit disagreement/incomplete result. Actual color contractions, derivative
coefficient/IBP cancellations in the parent vertices, complete source pole,
full quantum restoration and physical viability remain unproved. Keep the
source-pair1840 partial projection and Ward18416 unbound until actual partner
measurement. Preserve quartetFAIL3960/648, E5/A5unqualified, HB1/C5blocked,
C1_GSuncalculated, paused flavor and custodyexit2/seven. No authority change,
remote action, publication or new policy. Science and AI capability are equally
important; education remains voluntary, concurrent and nonblocking.
