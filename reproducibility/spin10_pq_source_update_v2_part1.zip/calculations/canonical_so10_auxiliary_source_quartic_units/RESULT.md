# General-momentum unit factors for the missing four-leg source pole

The corrected graded-supertrace and independently routed Wick workers agree
on all29 nominal unit kernels. They supply the momentum, Grassmann-sign and
vertex-counting factors needed before the actual Spin(10) color calculation.
Qualification requires the actual validation_receipt.json, complete captures
and raw Git checks under [RECORD.md](RECORD.md) and the preserved
[V2 correction](CORRECTION_V2.md).

No actual color tensor, model-specific source pole or completed Slavnov
relation is calculated. The following numbers are coefficients of explicitly
defined TOY monomials with unit vertex coefficients. They are not physical
couplings, measured amplitudes or values to insert without the actual color
and derivative-vertex contractions.

## What the factors mean

The unit target is JLambda*a*C0*C1, in that order, without an extra1/2.
Each coefficient below multiplies hbar/(32pi² epsilon_UV). Both methods keep
q0,q1,q2,q3 symbolic, with K=q0²-q1²-q2²-q3². The unit pole extraction is
2i*K² times the homogeneous integrand coefficient. Restoring the actual
g³*xi and group vertices is a subsequent calculation.

The primary uses -i/8,+i/6,-i/4 from i/2 STr log for four-, three- and
two-vertex words. The replay derives its normalization from -i log Z,
the n vertex factors i and the exponential's1/n!, with external odd-field
extraction and momentum conservation enforced on each connected pairing.
It reads neither primary results nor the known Slavnov remainder.

For the source-cubic box, F0 has an external ghost. There are two relevant
external-antighost placements: X (B_X), or F1 (B_F). The rows below specify
the derivative on F0's antighost, vector or ghost; columns do the same for F1.

| B_X | a | B | C |
| --- | ---: | ---: | ---: |
| a | -2 | +2 | 0 |
| B | +2 | -2 | 0 |
| C | 0 | 0 | 0 |

| B_F | a | B | C |
| --- | ---: | ---: | ---: |
| a | 0 | +2 | -2 |
| B | 0 | -2 | +2 |
| C | 0 | 0 | 0 |

For the source-quartic triangle, the subscript gives the vertex carrying
the external antighost. The columns give the derivative position in F.

| Placement | a | B | C |
| --- | ---: | ---: | ---: |
| K, the source quartic | -2 | +2 | 0 |
| X, the auxiliary/ghost vertex | +2 | -2 | 0 |
| F, the derivative vertex | 0 | -2 | +2 |

The source-quartic/ordinary-quartic bubble is-2 when its external antighost
belongs to K, and+2 when it belongs to Q. Runtime model definitions retain
all field/ghost labels and ordering; this summary is not a replacement for
those definitions when transferring a factor to actual color contractions.

All box row/column sums and triangle derivative sums vanish. These are the
ordinary derivative-current/IBP checks at zero external jets. Derivatives
on an external field vanish explicitly in their cases. No whole integral
is declared scaleless. The selected radial logarithm is only above R_UV>0;
finite, IR and mass-dependent terms remain outside scope.

## Factorial, propagation and representation checks

Each box case retains24 distinct-component supertrace words; each triangle
six, each bubble two. The Wick route retains the corresponding complete
vertex-order/pairing sets and obtains the same answer in every nominal order.
For the nonzero box anchor,12 words with a single full F=F0+F1 reproduce
the24 distinct-component words. An extra factor1/2 would spoil that match.

Removing mixed B/Lambda propagation makes the box and triangle anchors zero.
Removing the needed ghost pair makes the bubble anchor zero. Removing B/B
propagation leaves all three anchors unchanged, as the earlier inventory
requires; this is an invariance check, not a discriminating omission control.
The wrong even assignment for JLambda fails the source-vertex grading.

Deleting only the reverse odd propagator breaks graded covariance. Both
routes detect it. Their diagnostic numbers differ: the box becomes-1 in the
supertrace calculation and-1/2 in the Wick enumeration; corresponding invalid
triangle diagnostics are0 and-2/3, and bubble diagnostics0 and-1. These are
not alternative valid amplitudes or a nominal-route disagreement. The invalid
propagator does not retain the hypotheses making the two Gaussian derivations
equivalent; it is used only as a defect detector. The accepted29 kernels agree.

The optimized primary retains every monomial in the four-generator exterior
algebra. Both workers check all16 basis elements and256 basis products against
the inherited exterior implementation. A formal denominator R delays repeated
simplification; R=K is imposed exactly on every final kernel. No numerical
momentum, angular sample or approximation enters this representation change.

## Preserved failures, evidence and limits

An initial preparation assumed every imported helper appears in one old
receipt's protected map. One transitive imported file was absent from that
map. No native worker or unit kernel ran. The preserved corrected preparation
checks that file's exact bytes at the qualified historical Git checkpoint,
keeps its provenance distinct from receipt coverage, and leaves all actual
kernel code and requirements unchanged.

The first generic native primary then exited124 at its120second deadline,
without exporting a RESULT. Its source, preparation and full capture remain
unqualified. No original replay ran. The separately frozen V2 uses sparse
exterior matrices and the exact denominator lift with the same29 cases and
limits. Its primary/replay complete in about8.13s/8.80s after imports, under
120seconds/8GiB/350MiB. This is successful engineering repair; no calibrated
speedup benchmark or physics rescue is inferred from the timings.

The methods share the toy comparator vertices, inherited Fourier/exterior
helpers, reference conventions, Python/SymPy and analyst. They test meaningful
loop/sign/routing errors but do not independently establish that the actual
model's coefficients map correctly to these toy patterns. That next bridge
must be derived from the actual action, including its derivative currents,
all source/ghost placements and independent physical group reconstruction.
No independent expert or experimental validation is claimed.

Next: calculate the actual three-family color tensor, using the qualified
unit factors only after verifying its literal-vertex correspondence. Potential
cancellations of H/M profiles or external-antighost derivative terms require
the actual action; do not infer them from toy zeros alone. Compare completed
actual routes before releasing a required tensor or the1840-term partial
Slavnov relation. Preserve possible quantum breakings as unknowns.

E5/A5, HB1/C5, finiteC1_GS and physical matching remain unqualified/blocked
as previously recorded. State34/39, quartet failures, paused flavor, historical
custodyexit2/seven and the scalar point's quantum-control warning are unchanged.
No physical input, benchmark, foundational assumption or normalization is
adopted. Science and AI capability remain equally important; education stays
voluntary, concurrent and nonblocking. The overall investigation is incomplete.
