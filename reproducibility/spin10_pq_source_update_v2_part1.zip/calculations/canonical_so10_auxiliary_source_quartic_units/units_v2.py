"""General-q units for the auxiliary-source quartet; no physical color tensor."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations, product
import json
import os
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s, ETA, alphabet, register
from a10_e5_ghost_companion import Fourier_vertex, mp, trace

q=list(s.symbols('uk_q0:4',real=True))
K=sum(ETA[mu]*q[mu]**2 for mu in range(4))
R=s.Symbol('uk_denominator',nonzero=True)
width=s.symbols('uk_width0:2',real=True)


def model(kind,first='a',second='a'):
    w=alphabet()
    w.fields={**{f'uk_B{t}_{mu}':(1,0,0) for t in range(2) for mu in range(4)},
              **{f'uk_L{t}':(2,0,0) for t in range(2)},
              **{f'uk_{p}{i}':(1,1 if p=='c' else -1,1) for p in ['a','c'] for i in range(2)}}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    for n,z in [('uk_J',(1,-1,1)),('uk_aE',(1,-1,1)),('uk_C0',(1,1,1)),('uk_C1',(1,1,1))]:register(w,n,z)
    v=w.var
    def F(a,c,t,where):
        return w.add(*(w.scale(w.mul(w.D(v(a),mu) if where=='a' else v(a),
            w.D(v(f'uk_B{t}_{mu}'),mu) if where=='B' else v(f'uk_B{t}_{mu}'),
            w.D(v(c),mu) if where=='c' else v(c)),ETA[mu]) for mu in range(4)))
    if kind.startswith('B_'):
        S=w.mul(v('uk_J'),v('uk_L0'),v('uk_c0'))
        F0=F('uk_a0','uk_C0',1,first)
        if kind=='B_X':
            F1=F('uk_a1','uk_C1',0,second)
            X=w.mul(v('uk_L1'),v('uk_aE'),v('uk_c1'))
        else:
            assert kind=='B_F'
            F1=F('uk_aE','uk_c1',0,second)
            X=w.mul(v('uk_L1'),v('uk_a1'),v('uk_C1'))
        V=[S,F0,F1,X]
    elif kind.startswith('T_'):
        if kind=='T_K':
            S=w.mul(v('uk_J'),v('uk_aE'),v('uk_c0'),v('uk_c1'))
            F0=F('uk_a0','uk_C0',0,first)
            X=w.mul(v('uk_L0'),v('uk_a1'),v('uk_C1'))
        elif kind=='T_X':
            S=w.mul(v('uk_J'),v('uk_a1'),v('uk_c0'),v('uk_C0'))
            F0=F('uk_a0','uk_C1',0,first)
            X=w.mul(v('uk_L0'),v('uk_aE'),v('uk_c1'))
        else:
            assert kind=='T_F'
            S=w.mul(v('uk_J'),v('uk_a1'),v('uk_c0'),v('uk_C0'))
            F0=F('uk_aE','uk_c1',0,first)
            X=w.mul(v('uk_L0'),v('uk_a0'),v('uk_C1'))
        V=[S,F0,X]
    else:
        if kind=='Q_K':
            S=w.mul(v('uk_J'),v('uk_aE'),v('uk_c0'),v('uk_c1'))
            Q=w.mul(v('uk_a0'),v('uk_a1'),v('uk_C0'),v('uk_C1'))
        else:
            assert kind=='Q_Q'
            S=w.mul(v('uk_J'),v('uk_a0'),v('uk_c1'),v('uk_C0'))
            Q=w.mul(v('uk_aE'),v('uk_a1'),v('uk_c0'),v('uk_C1'))
        V=[S,Q]
    assert all(w.grade(P,(4,0,0)) for P in V)
    return w,V,w.mul(v('uk_J'),v('uk_aE'),v('uk_C0'),v('uk_C1'))


def green(a,b,p,omit_mixed=False,omit_reverse_odd=False,block_ghost1=False,omit_BB=False):
    if a.startswith('uk_B') and b.startswith('uk_B'):
        if omit_BB or a[4]!=b[4]:return s.S.Zero
        t,mu,nu=int(a[4]),int(a[-1]),int(b[-1])
        return -ETA[mu]*int(mu==nu)/R+(1-width[t])*p[mu]*p[nu]/R**2
    if a.startswith('uk_B') and b=='uk_L'+a[4]:return 0 if omit_mixed else s.I*p[int(a[-1])]/R
    if b.startswith('uk_B') and a=='uk_L'+b[4]:return 0 if omit_mixed else -s.I*p[int(b[-1])]/R
    if a in ['uk_c0','uk_c1'] and b=='uk_a'+a[-1]:return 0 if block_ghost1 and a[-1]=='1' else 1/R
    if a in ['uk_a0','uk_a1'] and b=='uk_c'+a[-1]:return 0 if omit_reverse_odd or block_ghost1 and a[-1]=='1' else -1/R
    return s.S.Zero


def pack(P,order):
    out={};pos={n:i for i,n in enumerate(order)}
    for word,z in P.items():
        assert all(not jets and n in pos for n,jets in word)
        ids=[pos[n] for n,jets in word]
        if len(ids)!=len(set(ids)):continue
        mask=sum(1<<i for i in ids);sign=(-1)**sum(a>b for i,a in enumerate(ids) for b in ids[i+1:])
        out[mask]=out.get(mask,0)+sign*z
    return {mask:s.expand(z) for mask,z in out.items() if s.expand(z)!=0}


def pmul(P,Q):
    out={}
    for a,u in P.items():
        for b,v in Q.items():
            if a&b:continue
            sign=(-1)**sum(1 for i in range(4) if a&(1<<i) for j in range(i) if b&(1<<j))
            mask=a|b;out[mask]=out.get(mask,0)+sign*u*v
    return {mask:s.expand(z) for mask,z in out.items() if s.expand(z)!=0}


def sparse_mm(A,B):
    right={};out={}
    for (k,j),Q in B.items():right.setdefault(k,[]).append((j,Q))
    for (i,k),P in A.items():
        for j,Q in right.get(k,[]):
            cell=out.setdefault((i,j),{})
            for mask,z in pmul(P,Q).items():cell[mask]=cell.get(mask,0)+z
    return {ij:{mask:s.expand(z) for mask,z in P.items() if s.expand(z)!=0}
            for ij,P in out.items() if any(s.expand(z)!=0 for z in P.values())}


def exterior_basis_checks():
    w,V,target=model('B_X');order=sorted(w.external);basis={}
    for mask in range(16):
        basis[mask]=w.mul(*(w.var(n) for i,n in enumerate(order) if mask&(1<<i)))
        assert pack(basis[mask],order)=={mask:s.S.One}
    for a in range(16):
        for b in range(16):assert pack(w.mul(basis[a],basis[b]),order)==pmul({a:s.S.One},{b:s.S.One})
    return {'basis_elements':16,'complete_basis_products':256,'repeated_generators_zero':True}


def born(kind,first='a',second='a',grouped_F=False,**opts):
    w,V,target=model(kind,first,second);names=list(w.fields);external_order=sorted(w.external);target_coefficient=pack(target,external_order)[15]
    G={(i,j):{0:z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=green(a,b,q,**opts))}
    rawH=[Fourier_vertex(P,w,'primary',q,q,{n:[0]*4 for n in w.external}) for P in V]
    H=[{(i,j):pack(P,external_order) for i,row in enumerate(A) for j,P in enumerate(row) if P} for A in rawH]
    n=len(H);factor=s.I*(-1)**(n+1)/(2*n)
    if grouped_F:
        assert kind.startswith('B_')
        S,F0,F1,X=H;F={ij:{mask:s.expand(F0.get(ij,{}).get(mask,0)+F1.get(ij,{}).get(mask,0))
            for mask in set(F0.get(ij,{}))|set(F1.get(ij,{}))} for ij in set(F0)|set(F1)}
        tag_to_H={'S':S,'F':F,'X':X}
        orders=[[tag_to_H[t] for t in tags] for tags in sorted(set(permutations(('S','F','F','X'))))]
    else:orders=list(permutations(H))
    kernels=[]
    for order in orders:
        A=G
        for j,Vj in enumerate(order):
            A=sparse_mm(A,Vj)
            if j<n-1:A=sparse_mm(A,G)
        value=sum((-1)**w.p[names[i]]*P.get(15,0) for (i,j),P in A.items() if i==j)
        kernels.append(s.factor(factor*value/target_coefficient))
    return s.factor(sum(kernels)),{'ordered_supertrace_kernels':[str(v) for v in kernels],
                                  'words':len(orders),'factor':str(factor),'F_grouped':grouped_F}


def pairings(legs,opts):
    if not legs:
        yield ()
        return
    a=legs[0]
    for i,b in enumerate(legs[1:],1):
        if a[0]==b[0] or not green(a[1],b[1],q,**opts):continue
        sign=(-1)**(a[3]*sum(v[3] for v in legs[1:i]))
        for rest in pairings(legs[1:i]+legs[i+1:],opts):yield ((a,b,sign),*rest)


def connected(pairs,n):
    reached={0}
    for repeat in range(n):
        reached|={b[0] for a,b,sign in pairs if a[0] in reached}|{a[0] for a,b,sign in pairs if b[0] in reached}
    return len(reached)==n


def wick(kind,first='a',second='a',**opts):
    w,V,target=model(kind,first,second);ext=set(w.external);word,sign=next(iter(target.items()))
    values=[];counts=[];route_count=0
    for ordered in permutations(V):
        total=0;count=0
        for selected in product(*(list(P.items()) for P in ordered)):
            coefficient=1;full=[];legs=[]
            for vertex,(monomial,z) in enumerate(selected):
                coefficient*=z
                for pos,(name,jets) in enumerate(monomial):
                    token=(vertex,name,jets,w.p[name],pos);full.append(token)
                    if name not in ext:legs.append(token)
                    elif jets:coefficient=0
            if not coefficient:continue
            if len(legs)!=2*len(ordered):continue
            coefficient*=(-1)**sum(a[3]*b[3] for i,a in enumerate(full) if a[1] not in ext for b in full[i+1:] if b[1] in ext)
            coefficient*=w.mul(*(w.var(name) for v,name,j,p,pos in full if name in ext)).get(word,0)/sign
            if not coefficient:continue
            for pairs in pairings(legs,opts):
                if not connected(pairs,len(ordered)):continue
                solutions=[]
                for tail in product((-1,1),repeat=len(pairs)-1):
                    eps=(1,*tail)
                    if all(sum((int(a[0]==v)-int(b[0]==v))*e for (a,b,sgn),e in zip(pairs,eps))==0 for v in range(len(ordered))):solutions.append(eps)
                assert len(solutions)==1,'UNIT_CYCLE_MOMENTUM_NOT_UNIQUE'
                value=coefficient;count+=1;route_count+=1
                for (a,b,sgn),e in zip(pairs,solutions[0]):
                    p=[e*x for x in q]
                    value*=sgn*s.I*green(a[1],b[1],p,**opts)
                    value*=s.prod(s.I*p[mu] for mu in a[2])*s.prod(-s.I*p[mu] for mu in b[2])
                total+=value
        # -i log Z, n factors i from vertices, and the exponential's 1/n!.
        values.append(s.factor(-s.I*s.I**len(ordered)*total));counts.append(count)
    independent=all(s.factor(v-values[0])==0 for v in values)
    assert independent or opts.get('omit_reverse_odd'),'UNIT_WICK_VERTEX_ORDER_DEPENDENCE'
    return s.factor(sum(values)/len(values)),{'vertex_order_values':[str(v) for v in values],
         'proper_pairing_counts':counts,'momentum_routings':route_count,'vertex_order_independent':independent,
         'exponential_order_factor':'1/'+str(len(values))}


def pole(value):
    z=s.factor((2*s.I*K**2*value).subs(R,K))
    assert not z.has(*q,s.Float,*width),('UNIT_NOT_CONSTANT_OR_WIDTH_DEPENDENT',z)
    return z


def main():
    started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    route=sys.argv[1];assert route in ['primary','replay']
    read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
    prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
    allowed={str((ROOT/n).resolve()) for n in prep['input_sha256']};writes=[];denied=[]
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        name=os.fsdecode(args[0])
        if len(args)>1 and isinstance(args[1],str) and any(t in args[1] for t in 'wax+'):
            writes.append(name);raise PermissionError('SOURCE_QUARTIC_UNIT_WRITE_DENIED')
        if Path(name).suffix=='.json' and str(Path(name).resolve()) not in allowed:
            denied.append(name);raise PermissionError('SOURCE_QUARTIC_GROUP_POLE_REQUIRED_OR_PEER_READ_DENIED')
    sys.addaudithook(guard)
    basis=exterior_basis_checks();calculate=born if route=='primary' else wick
    cases=[(kind,a,b) for kind in ['B_X','B_F'] for a,b in product(['a','B','c'],repeat=2)]
    cases += [(kind,a,'a') for kind in ['T_K','T_X','T_F'] for a in ['a','B','c']]
    cases += [(kind,'a','a') for kind in ['Q_K','Q_Q']]
    assert len(cases)==29
    table={};details={}
    for kind,a,b in cases:
        name=kind+'_'+a+b;print('STAGE '+route+'_'+name,flush=True)
        value,info=calculate(kind,a,b);table[name]=str(pole(value));details[name]={'kernel':str(value),**info}
    number=lambda name:s.sympify(table[name])
    for kind in ['B_X','B_F']:
        for b in ['a','B','c']:assert sum(number(kind+'_'+a+b) for a in ['a','B','c'])==0
        for a in ['a','B','c']:assert sum(number(kind+'_'+a+b) for b in ['a','B','c'])==0
    for kind in ['T_K','T_X','T_F']:assert sum(number(kind+'_'+a+'a') for a in ['a','B','c'])==0
    anchors={'box':('B_X','a','a'),'triangle':('T_K','a','a'),'bubble':('Q_K','a','a')}
    controls={}
    for label,(kind,a,b) in anchors.items():
        base=number(kind+'_'+a+b);assert base!=0
        for mutation in ['omit_reverse_odd','omit_BB']+(['omit_mixed'] if label!='bubble' else ['block_ghost1']):
            value,_=calculate(kind,a,b,**{mutation:True});changed=pole(value)
            assert (changed==base) if mutation=='omit_BB' else (changed!=base),('UNIT_CONTROL_NOT_AS_DECLARED',label,mutation,base,changed)
            controls[label+'_'+mutation]={'pole':str(changed),'changes_result':bool(changed!=base)}
    w,V,T=model('B_X');register(w,'uk_J',(1,-1,0));assert not w.grade(V[0],(4,0,0))
    grouping=None
    if route=='primary':
        value,info=born('B_X',grouped_F=True)
        assert pole(value)==number('B_X_aa') and info['words']==12 and details['B_X_aa']['words']==24
        grouping={'actual12_multiset_words_equal24_distinct_component_words':True,'pole':str(pole(value)),'wrong_extra_half_changes_nonzero_anchor':True}
    for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
    assert not writes and not denied and time.perf_counter()-started<120
    result={'schema':'AUXILIARY_SOURCE_QUARTIC_UNIT_KERNELS_V2','route':route,
        'status':'CALCULATED_29_GENERAL_Q_UNITS_REQUIRE_PAIRED_VALIDATION','poles':table,'details':details,'controls':controls,
        'all29_cases_calculated':True,'all_derivative_IBP_sums_zero':True,'odd_source_grade_control_rejected':True,'identical_F_grouping':grouping,
        'exterior_basis_checks':basis,'exact_denominator_relation':'uk_denominator=uk_q0**2-uk_q1**2-uk_q2**2-uk_q3**2',
        'general_four_component_momentum':True,'unit_pole_multiplier':'2*I*K**2','finite_IR_or_scaleless_inference':False,
        'actual_group_coefficients_or_required_tensor_read':False,'actual_physical_source_pole_calculated':False,
        'input_sha256':prep['input_sha256'],'source_sha256':prep['source_sha256'],'write_attempts':writes,'denied_unbound_reads':denied,
        'seconds_after_import':time.perf_counter()-started,'scientific_authority_changed':False,'whole_goal_complete':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}),flush=True);timer.cancel()


if __name__=='__main__':main()
