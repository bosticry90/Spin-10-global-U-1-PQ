# Exact polynomial kernels after the preserved V1 deadline

V1 primary reached its120second-after-import deadline before completing the
29-case gate. Its units.py, source snapshot, preparation, controller and full
primary_capture.json remain exact. No RESULT was exported and no partial unit
value is qualified. The V1 replay was not launched. The earlier preparation
failure was also unlaunched and is separately preserved.

This new bounded continuation is delegated by current AGENTS.md. It does not
retroactively authorize or relabel V1. Two NEW sequential roles, each120seconds/
8GiB/350MiB, are frozen in preparation_v2.json. No extra resources, discarded
cases, fitted signs, numerical momentum sampling or scientific relaxation.

Replace the expensive generic coefficient simplification by sparse exterior
matrices with four external odd generators. The finite mask algebra retains
every external monomial; repeated generators vanish exactly and the crossing
sign is the ordered Grassmann sign. Compare the primary mask conversion and
products with the inherited exterior algebra on a complete finite basis.

Use a separate nonzero symbol R for the common propagator denominator while
retaining all four q components. This is the exact rational-expression lift
R=q0²-q1²-q2²-q3²; impose that relation when extracting each final homogeneous
pole. No component or angular average is replaced by a numerical value. R has
formal degree two. General-q Born and independently routed Wick answers must
agree after this substitution. Full B/B entries and their width-removal
control remain; no old incomplete answer is used as an oracle.

All29 original unit cases, every ordered supertrace/Wick word, IBP-current
sums, external-derivative zeros, source parity, mixed/reverse-odd/ghost controls
and identical-F grouping still apply. Both routes use the same denominator
lift but different loop/sign derivations. The shared representation change is
explicit; basis/exterior checks and the independent Wick comparison constrain
its errors. It is not independent expert or empirical validation.

The result ceiling remains unit kernels only. Actual color contractions and
the physical source pole are still uncomputed. Preserve every failure and all
scientific/authority boundaries in RECORD.md. Do not read a required Slavnov
tensor or normalizer while calculating these units.
