# Bounded feasibility: two rejected trials; full comparison INCONCLUSIVE

No necessary-condition survivor was found in the authorized search. The
selected trials both have six negative real colored-scalar mass directions
after light-Higgs tuning:284 positive,38 zero,six negative out of328.
This rejects the trials, not the full eight-quartic domain or Spin(10).
No replacement benchmark is adopted; formal authority remains34/39.

| Trial | Dependent mphi2 | Minimum canonical squared mass | Outcome |
| --- | ---: | ---: | --- |
| Frozen Sigma quartics divided by10 | 0.4453038512 | -0.5807525620 | Rejected |
| First convex trial, rounded and light-retuned | 0.4439811554 | -0.5290296262 | Rejected |

The unstable modes are conjugate colored-triplet, weak-singlet records,
labels(0,1,0,-2)/(1,0,0,2): one complex triplet, six real directions.
Both trials satisfy the declared Sigma contact/radial/Phi-ray tests. The
negative mass gate stops the calculation before any new Higgs quartic or
loop. The convex trial's freely searched mphi2 was approximately1.86247;
retuning it to the declared light root exposed the colored instability.
The subsequent restricted light-face problem reported infeasible. Its
restricted plane and numerical margins prohibit a full-domain no-go claim.
See the complete [primary data](primary_result.json), [prospective contract](RECORD.md)
and [original result](RESULT.md) for conventions and preserved solver records.

The corrected independent verifier derives the tuning polynomial from real8
weak derivative data, separately from the primary complex4 Schur route. It
checks all35 unreduced raw Hermitian blocks by exact signed congruences with
outward rational signs, their physical multiplicities and kinetic metrics,
stationarity, weak rank6,100-digit mass spectra, necessary contact/radial
conditions and wrong-root/mass/Hermitian/metric/indefinite-reference controls.
The actual completed [receipt](validation_receipt.json) supplies the exact
sign bounds and completion status. Neither numerical solver status nor
execution-stage messages substitute for that receipt.

The original verifier failed a self-referential report-link check before
emitting a certificate. Its [full failed capture](independent_verifier_capture.json),
source/copy and preparation remain intact. The director explicitly authorized
one corrected verifier in the [V3 correction](VALIDATION_CORRECTION_V3.md).
Three physics launches therefore include one primary, one failed verifier
and one corrected verifier; no fresh primary replay or new parameter search
is asserted. The [pause record](RESULT_V2.md) describes the intervening
unqualified state. The correction changes the receipt path check and
administrative version/counter bindings; every mathematical assertion remains.
Actual resource observations and standard read-only preflight are preserved
with raw Git/index/HEAD custody; an engineering failure is never a scientific PASS.

The primary took6.23seconds after imports,10.02seconds captured wall time,
with sampled peak private2,458,603,520bytes and immediate available commit
9,419,632,640bytes. Both verifier captures retain their own limits/observations.
Independent routes share the physical assumptions, inherited action/Hessian
data, some arithmetic/software and analyst. They are bounded computational
corroboration, not independent scientific endorsement, experimental support,
full328 BFB, full scalar unitarity or quantum-vacuum/naturalness proof.

The next useful scientific question is analytic compatibility of colored
positivity with the light-root condition across the allowed eight quartics.
It has greater decision value than another blind search or expensive Higgs
determinant at either failed point. No further physics process or rebuild
is granted by unused runtime. A new increment needs its bounded contract and
any consequential director decision; adoption remains separate from exploration.

Project_state.json v113 and sealed README are unchanged. Preserve
quartetFAIL3960/648,E5/A5unqualified,HB1/C5blocked,C1_GSuncalculated,full328
BFB/naturalness/physical matching unresolved, paused flavor and historical
custodyexit2/seven. Old benchmark masses/loops/certificates do not transfer.
AI evaluation records the unsuccessful search, exact rejection checks and
avoidable validation-link defect. Scientific and AI-capability objectives
remain equally important; education is voluntary/nonblocking and solo review
unchanged. The overall investigation is incomplete.
