"""One bounded deterministic witness search; independent verification is separate."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import sys,json,time
import sympy as s
import numpy as np
import mpmath as mp
import cvxpy as cp
import model as md
from model import al,inp,R,C,FREE
sys.path.insert(0,str(C/'canonical_so10_full_hessian'));import parent_bilinear_oracle as oracle
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();O=Path(__file__).resolve().parent
class BudgetStop(Exception):pass
def mpq(z):
    f=F(str(z));return mp.mpf(f.numerator)/f.denominator
def main():
    start=time.perf_counter();prep=read(O/'preparation.json');writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('BOUNDED_SCALAR_STUDY_WRITE_DENIED')
    sys.addaudithook(readonly)
    for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
    model=md.Model();pold=np.array([float(md.OLD[n]) for n in FREE]);rt=read(C/'canonical_so10_positive_higgs/POINT.json')['determinant_polynomial'];mp.mp.dps=100;a=mpq(rt['A']);b=mpq(rt['B0'])+mpq(rt['B1'])*mp.sqrt(15);c=mpq(rt['C0'])+mpq(rt['C1'])*mp.sqrt(15);w=(-b+mp.sqrt(b*b-4*a*c))/(2*a);oldx=np.r_[pold,float(w+mp.mpf('.002'))]
    observed=model.mats(oldx);ref=next(z for z in model.source['probes'] if z['precision']==100)['blocks'];errors=[]
    for block,M in zip(model.blocks,observed):
        old=next(z for z in ref if z['label']==block['label']);v=np.linalg.eigvalsh(M);errors.append(float(np.max(np.abs(v-np.array(list(map(float,old['mass_squared'])))))))
    assert max(errors)<1e-8,'OLD_AFFINE_INPUT_RECONSTRUCTION_FAILED'
    print('STAGE frozen_affine35_normalization_control',flush=True)
    attempts=[];candidate=None
    def diagnose(values,label):
        p=np.array([float(f'{x:.12f}') for x in values]);rec={'label':label,'quartics_decimal':[f'{x:.12f}' for x in p]}
        try:m=model.tune(p)
        except (AssertionError,np.linalg.LinAlgError):rec['status']='REJECT_SIGMA_WEAK_PRINCIPAL_OR_LIGHT_ROOT';attempts.append(rec);return None
        mats=model.mats(np.r_[p,m/60]);zeros=positive=0;mn=1e99;ledger=[]
        for block,M in zip(model.blocks,mats):
            ev=np.linalg.eigvalsh(M);z=int(np.sum(np.abs(ev)<1e-7));pcount=int(np.sum(ev>1e-7));zeros+=block['dimension']*z;positive+=block['dimension']*pcount;mn=min(mn,float(ev[0]));ledger.append({'label':block['label'],'eigenvalues':list(map(float,ev))})
        l=p[4:];A=np.dot([8,16,16,64],l);B=np.dot([8,24,24,32],l);D=np.array([[24,0,0,0],[24,24,24,96],[24,48,72,144]])@l;lp=p[0]+7*p[1]/60;lm=p[2]-p[3]/4
        ray=[p[0]+p[1]/10,p[0]+73*p[1]/90];mixed=lm+2*np.sqrt(max(0,lp*l[0]));ok=mn>=-1e-7 and zeros==38 and positive==290 and 50*A*A+36*B*B<=256*np.pi**2 and np.max(np.abs(D))<=16*np.pi and lp>=0 and l[0]>=0 and min(ray)>=0 and mixed>=-1e-10
        rec.update({'status':'NUMERICAL_NECESSARY_SURVIVOR' if ok else 'REJECT_NUMERICAL_NECESSARY_TEST','mphi2':float(m),'minimum_eigenvalue':mn,'positive_real_directions':positive,'zero_real_directions':zeros,'Sigma_ellipse_value':float(50*A*A+36*B*B),'Sigma_D':list(map(float,D)),'Phi_ray_values':list(map(float,ray)),'radial_copositivity_margin':float(mixed),'mass_ledger':ledger});attempts.append(rec)
        return (p,m,mats) if ok else None
    seed=pold.copy();seed[4:]/=10;candidate=diagnose(seed,'frozen_Sigma_one_tenth_seed')
    solver_records=[]
    if candidate is None:
        faces={};current=None
        for step in range(3):
            if time.perf_counter()-start>550:break
            x=cp.Variable(9);constraints=[]
            for k,(block,aa) in enumerate(zip(model.blocks,model.affine)):
                M=aa[0]+sum(x[j]*aa[j+1] for j in range(9));M=(M+M.H)/2
                stack=np.vstack([A/max(1,np.linalg.norm(A)) for A in aa]);_,sing,Vh=np.linalg.svd(stack,full_matrices=False);U=Vh.conj().T[:,sing>1e-11]
                if k in faces:
                    vv=faces[k];_,_,vvh=np.linalg.svd(vv.conj()[None,:]);U=vvh.conj().T[:,1:];constraints.extend([cp.real(M@vv)==0,cp.imag(M@vv)==0])
                if U.shape[1]:constraints.append(U.conj().T@M@U >> 1e-4*np.eye(U.shape[1]))
            l=x[4:8];A=np.array([8,16,16,64])@l;B=np.array([8,24,24,32])@l;D=np.array([[24,0,0,0],[24,24,24,96],[24,48,72,144]])@l
            constraints.extend([cp.norm(cp.hstack([np.sqrt(50)*A,6*B]))<=.95*16*np.pi,cp.abs(D)<=.95*16*np.pi])
            lp=x[0]+7*x[1]/60;lm=x[2]-x[3]/4;neg=cp.Variable(nonneg=True);constraints.extend([x[0]+x[1]/10>=0,x[0]+73*x[1]/90>=0,lp>=0,l[0]>=0,neg>=-lm,cp.SOC(lp+l[0],cp.hstack([neg,lp-l[0]]))])
            problem=cp.Problem(cp.Minimize(cp.norm1(x-oldx)),constraints);t0=time.perf_counter();status='NOT_RUN'
            try:
                problem.solve(solver='CLARABEL',max_iter=150,time_limit=min(180,790-(time.perf_counter()-start)),tol_gap_abs=1e-9,tol_feas=1e-9);status=problem.status
            except cp.error.SolverError as err:status='SOLVER_ERROR_DIAGNOSTIC';solver_records.append({'step':step,'status':status,'error':str(err),'seconds':time.perf_counter()-t0});break
            sr={'step':step,'status':status,'seconds':time.perf_counter()-t0,'objective':float(problem.value) if problem.value is not None and np.isfinite(problem.value) else None,'light_face_restrictions':len(faces)};solver_records.append(sr);print('STAGE convex_feasibility_'+str(step)+' '+status,flush=True)
            if x.value is None:break
            sr['raw_numerical_variables']=list(map(float,x.value));candidate=diagnose(x.value[:8],'convex_step_'+str(step))
            if candidate is not None:break
            try:
                mm=model.tune(x.value[:8]);current=model.mats(np.r_[x.value[:8],mm/60]);faces={}
                for i,bb in enumerate(model.blocks):
                    if bb['label'] in [[0,0,1,-3],[0,0,1,3]]:faces[i]=np.linalg.eigh(current[i])[1][:,0]
            except (AssertionError,np.linalg.LinAlgError):break
    out={'schema':'BOUNDED_EIGHT_QUARTIC_SCALAR_FEASIBILITY_V1','status':'INCONCLUSIVE_NO_NECESSARY_WITNESS_OR_EXCLUSION_CERTIFICATE','authorization':'explicit director reply authorizing RESEARCH_DIRECTION_PROPOSAL_V1.md','old_affine_mass_max_error':max(errors),'attempts':attempts,'solver_records':solver_records,'candidate':None,'quartic':None,'new_benchmark_adopted':False,'new_domain_beyond_authorized_comparison':False,'numerical_solver_status_is_scientific_certificate':False,'full328_BFB_or_full_unitarity_proved':False,'quantum_vacuum_or_naturalness_or_physical_matching_proved':False,'old_numerical_loop_or_vertex_transferred':False,'physical_gauge_input_selected':False,'flavor_fit_resumed':False,'scientific_authority_changed':False,'whole_goal_complete':False,'write_attempts':writes,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256']}
    if candidate is not None:
        pp=[s.Rational(f'{z:.12f}') for z in candidate[0]];rr=model.root_ring(pp);H8=model.exact_H8(pp,rr);q,N,anchor=md.kernel(H8,rr);roots=[]
        for digits in [100,140]:
            m=md.root_value(rr,digits);numeric=rr.numeric(H8,m);ev=mp.eigsy(numeric,eigvals_only=True);assert max(abs(ev[i]) for i in range(2))<mp.mpf('1e-60') and ev[2]>0;roots.append({'precision':digits,'mphi2':mp.nstr(m,80),'weak8_eigenvalues':[mp.nstr(z,65) for z in ev],'q_norm':mp.nstr(rr.value(N,m),65)})
        assert abs(float(m)-candidate[1])<1e-7
        qids=[rr.dump(z) for z in q];nid=rr.dump(N);basec=md.rawcoeff(md.physical(pp,0));oldbasis=list(map(inp.g.state,model.data['raw_neutral8_basis']));metrics=model.data['raw_neutral8_metric'];co=[F(mp.nstr(rr.value(z,m)/mp.sqrt(rr.value(N,m))/mp.sqrt(mpq(g)),24)) for z,g in zip(q,metrics)];hstate=inp.g.combine(oldbasis,co);nh=F(inp.g.inner(hstate,hstate));assert abs(float(nh)-1)<1e-15
        def pstate(a):
            return oracle.State(s.Matrix(10,10,list(map(s.Rational,a[0]))),{k:(s.Rational(z[0]),s.Rational(z[1])) for k,z in a[1].items()},tuple(s.Rational(z[0])+s.I*s.Rational(z[1]) for z in a[2]),s.Rational(a[3][0])+s.I*s.Rational(a[3][1]))
        hp=pstate(hstate);neutral,valley=md.neutral(basec);basis=list(map(lambda z:pstate(inp.g.state(z)),valley['SM_basis']));heavy=valley['positive_indices'];Hp=mp.matrix([[mp.mpf(str(s.N(neutral[i,j],155))) for j in heavy] for i in heavy]);G=[s.Rational(valley['SM_Gram'][i][i]) for i in heavy];Hc=mp.matrix([[Hp[i,j]/mp.sqrt(mpq(G[i])*mpq(G[j])) for j in range(8)] for i in range(8)]);gap=mp.eigsy(Hc,eigvals_only=True)[0];assert gap>0
        out['candidate']={'quartics':dict(zip(FREE,map(str,pp))),'root_branch':'larger_real_root_of_mphi2_squared_plus_c1_mphi2_plus_c0','root_probes':roots,'algebra':None,'exact_H8':rr.matrix_dump(H8),'q_exact':qids,'q_norm_exact':nid,'phase_anchor_index':anchor,'rounded_raw_Higgs_coordinates':list(map(str,co)),'rounded_Higgs_norm_squared':str(nh),'neutral_heavy_gap_numerical':mp.nstr(gap,65)}
        out['status']='NECESSARY_HESSIAN_LIGHT_AND_SELECTED_SCATTERING_WITNESS_PENDING_INDEPENDENT_VERIFICATION'
        print('STAGE exploratory_candidate_exact_light_root_and_full_affine_mass_inputs',flush=True)
        saved={n:getattr(oracle,n) for n in ['quartics','t_entry','exact_mixed_l']};key=lambda a:tuple(sorted(a.items()))
        @lru_cache(None)
        def qc(a):return saved['quartics'](dict(a))
        @lru_cache(None)
        def tc(a,i,j):return saved['t_entry'](dict(a),i,j)
        @lru_cache(None)
        def lc(P,a):return saved['exact_mixed_l'](s.Matrix(10,10,P),dict(a))
        oracle.quartics=lambda a:qc(key(a));oracle.t_entry=lambda a,i,j:tc(key(a),i,j);oracle.exact_mixed_l=lambda P,a:lc(tuple(P),key(a));cache={};calls=0
        from fractions import Fraction
        def scale(a,t):return oracle.State(a.Phi*t,{k:(z[0]*t,z[1]*t) for k,z in a.Sigma.items()},tuple(z*t for z in a.phi),a.S*t)
        def evaluate(direction):
            nonlocal calls
            if time.perf_counter()-start>810:raise BudgetStop('QUARTIC_ATOMIC_EVALUATION_BOUNDARY')
            state=oracle.state_add(oracle.vacuum_state(),direction);k=oracle.state_key(state)
            if k not in cache:cache[k]=oracle.invariant_values(state);calls+=1
            return cache[k]
        def combo(terms):return {n:s.expand(sum(weight*values[n] for weight,values in terms)) for n in inp.NAMES}
        def contract(raw):
            z=sum(basec[n]*raw[n] for n in inp.REAL)+sum(2*s.re(basec[n]*raw[n]) for n in inp.COMPLEX);return mp.mpf(str(s.N(s.expand(z),155)))
        raw4=None;rawj=[]
        try:
            vals={t:evaluate(scale(hp,t)) for t in [0,1,-1,2,-2]};raw4=combo([(s.Rational(1,24),vals[2]),(s.Rational(1,24),vals[-2]),(-s.Rational(1,6),vals[1]),(-s.Rational(1,6),vals[-1]),(s.Rational(1,4),vals[0])])
            for i,X in enumerate(basis):
                value=[]
                for t,z,weight in [(1,1,1),(1,-1,-1),(-1,1,1),(-1,-1,-1),(0,1,-2),(0,-1,2)]:value.append((s.Rational(weight,4),evaluate(oracle.state_add(scale(hp,t),scale(X,z)))))
                rawj.append(combo(value));print('STAGE new_candidate_hh_source_'+str(i),flush=True)
            nn=mp.mpf(nh.numerator)/nh.denominator;j=[contract(a)/nn for a in rawj];jj=mp.matrix([j[i] for i in heavy]);direct=4*contract(raw4)/nn**2;energy=(jj.T*mp.lu_solve(Hp,jj))[0];lam=direct-2*energy
            out['quartic']={'status':'NUMERICAL_NEW_PARENT_QUARTIC_PENDING_INDEPENDENT_BOUND','raw_h4':{n:str(z) for n,z in raw4.items()},'raw_hh_neutral_sources':[{n:str(z) for n,z in row.items()} for row in rawj],'direct_lambda':mp.nstr(direct,70),'heavy_subtraction':mp.nstr(2*energy,70),'relaxed_lambda':mp.nstr(lam,70),'null_source_components':[mp.nstr(j[i],70) for i in valley['null_indices']],'parent_oracle_calls':calls,'rounded_Higgs_not_exactly_null':True}
            if lam<0:out['status']='SELECTED_CANDIDATE_RELAXED_HIGGS_QUARTIC_NEGATIVE_PENDING_VERIFICATION'
        except BudgetStop as err:out['quartic']={'status':'INCOMPLETE_QUARTIC_RESOURCE_BOUNDARY','reason':str(err),'completed_source_rows':len(rawj),'parent_oracle_calls':calls}
        finally:
            for n,fn in saved.items():setattr(oracle,n,fn)
        out['candidate']['algebra']=rr.record()
    for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
    assert not writes and time.perf_counter()-start<900,'PRIMARY_RESOURCE_BOUNDARY_INCOMPLETE'
    print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start,'atomic_physics_role':'primary','no_fresh_native_replay_authorized':True}),flush=True)
if __name__=='__main__':main()
