"""Frozen affine comparison inputs; no optimizer or scientific acceptance here."""
from pathlib import Path
import sys,json
import sympy as s
import numpy as np
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations'
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
sys.path.insert(0,str(C/'canonical_so10_higgs_counterterm_subsets'));from subsets import load_ring
import algebra as al
FREE=['lambdaPhi1','lambdaPhi2','lambdaPhiSigma1','lambdaPhiSigma2','lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4']
read=lambda p:json.loads(p.read_bytes())
def factors():
    b,ss=s.sqrt(s.Rational(3,160)),s.sqrt(s.Rational(3,10))
    return {n:b**inp.RESCALE.get(n,(0,0))[0]*ss**inp.RESCALE.get(n,(0,0))[1] for n in inp.NAMES}
FACTOR=factors();OLD={n:s.simplify(z/FACTOR[n]) for n,z in inp.coefficients(0).items()}
def physical(values,mphi):
    c=OLD.copy();c.update(dict(zip(FREE,values)));c['mphi2']=mphi
    c['mPhi2']=-s.Rational(3,2)*c['muPhi']-120*(c['lambdaPhi1']+s.Rational(7,60)*c['lambdaPhi2'])-s.Rational(3,5)*(c['lambdaPhiSigma1']-c['lambdaPhiSigma2']/4)-s.Rational(3,10)*c['lambdaPhiS']
    c['mSigma2']=-60*(c['lambdaPhiSigma1']-c['lambdaPhiSigma2']/4)-s.Rational(6,5)*c['lambdaSigma1']-s.Rational(3,10)*c['lambdaSigmaS']
    c['mS2']=-60*c['lambdaPhiS']-s.Rational(3,5)*c['lambdaSigmaS']-s.Rational(3,5)*c['lambdaS'];return c
def rawcoeff(c):return {n:s.expand(z*FACTOR[n]) for n,z in c.items()}
def slots(c):return [s.re(c[n]) if part!='im' else s.im(c[n]) for slot in inp.REAL+tuple(n+':re' for n in inp.COMPLEX)+tuple(n+':im' for n in inp.COMPLEX) for n,_,part in [slot.partition(':')]]
def num(z):return complex(s.N(z,28))
class Model:
    def __init__(self):
        self.source=read(C/'canonical_so10_singlet_tadpole/original_v2_result.json');self.names=self.source['slots'];self.blocks=self.source['block_inputs'];self.data=read(C/'canonical_so10_higgs_exact_light_ct_map/original_result.json');self.r,self.atoms=load_ring(self.data)
        self.raw=[]
        for b in self.blocks:
            n=len(b['sectors']);a=[s.zeros(n) for _ in range(34)]
            for k,i,j,z in b['raw_H34_sparse']:a[k][i,j]=s.sympify(z)
            assert all(z==z.H for z in a);self.raw.append(a)
        x=s.symbols('p0:9',real=True);v=slots(rawcoeff(physical(x[:8],60*x[8])));at0={z:0 for z in x};self.constants=[s.expand(z.subs(at0)) for z in v];self.columns=[[s.diff(z,p) for z in v] for p in x]
        assert all(not any(q in z.free_symbols for q in x) for vec in [self.constants]+self.columns for z in vec)
        self.affine=[]
        for b,raw in zip(self.blocks,self.raw):
            g=np.sqrt(np.array([float(s.Rational(z)) for z in b['metric']]));a=[]
            for co in [self.constants]+self.columns:
                M=sum((num(z)*np.array(H.tolist(),dtype=complex) for z,H in zip(co,raw)),np.zeros((len(g),len(g)),complex));M=M/g[:,None]/g[None,:];assert np.max(np.abs(M-M.conj().T))<1e-10;a.append(M)
            self.affine.append(a)
        self.weak=next(i for i,b in enumerate(self.blocks) if b['label']==[0,0,1,-3]);b=self.blocks[self.weak];self.si=[i for i,n in enumerate(b['sectors']) if n in ['Sigma','SigmaBar']];self.pi=[i for i,n in enumerate(b['sectors']) if n in ['phi','phiBar']];assert len(self.si)==len(self.pi)==2
        expected=np.diag([int(i in self.pi) for i in range(4)]);assert np.max(np.abs(self.affine[self.weak][-1]/60-expected))<1e-12
    def mats(self,x):return [a[0]+sum((z*A for z,A in zip(x,a[1:])),np.zeros_like(a[0])) for a in self.affine]
    def tune(self,p):
        M=self.mats(list(p)+[0])[self.weak];S=M[np.ix_(self.si,self.si)];X=M[np.ix_(self.si,self.pi)];F=M[np.ix_(self.pi,self.pi)];assert np.linalg.eigvalsh(S)[0]>0
        K=F-X.conj().T@np.linalg.solve(S,X);m=-np.linalg.eigvalsh(K)[0];return m
    def exact_raw(self,p,mphi):
        co=slots(rawcoeff(physical(p,mphi)));return [sum((z*A for z,A in zip(co,raw)),s.zeros(raw[0].rows)) for raw in self.raw]
    def root_ring(self,p):
        M=self.exact_raw(p,0)[self.weak];si,pi=self.si,self.pi
        pair=lambda z:(al.base(s.re(s.expand(z))),al.base(s.im(s.expand(z))))
        add=lambda a,b:(a[0]+b[0],a[1]+b[1]);neg=lambda a:(-a[0],-a[1]);conj=lambda a:(a[0],-a[1]);mul=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);div=lambda a,d:(a[0]/d,a[1]/d)
        S=[[pair(M[i,j]) for j in si] for i in si];X=[[pair(M[i,j]) for j in pi] for i in si];F=[[pair(M[i,j]) for j in pi] for i in pi]
        assert not S[0][0][1] and not S[1][1][1];det=S[0][0][0]*S[1][1][0]-mul(S[0][1],conj(S[0][1]))[0];assert det
        inv=[[div(S[1][1],det),div(neg(S[0][1]),det)],[div(neg(S[1][0]),det),div(S[0][0],det)]];eff=[]
        for i in range(2):
            row=[]
            for j in range(2):
                z=(al.K.zero,al.K.zero)
                for a in range(2):
                    for b in range(2):z=add(z,mul(mul(conj(X[a][i]),inv[a][b]),X[b][j]))
                row.append(add(F[i][j],neg(z)))
            eff.append(row)
        g=[al.base(s.Rational(self.blocks[self.weak]['metric'][i])) for i in pi];assert not eff[0][0][1] and not eff[1][1][1]
        rr=al.Ring(0,0);rr.c1=(g[0]*eff[1][1][0]+g[1]*eff[0][0][0])/(g[0]*g[1]);rr.c0=(eff[0][0][0]*eff[1][1][0]-mul(eff[0][1],conj(eff[0][1]))[0])/(g[0]*g[1]);return rr
    def exact_H8(self,p,rr):
        oldr=self.r;ex=self.data['exact'];H=[[self.atoms[k] for k in row] for row in ex['H8_exact']];names=self.data['potential_counterterm_names'];old=physical([OLD[n] for n in FREE],60*oldr.w+s.Rational(3,25));new=physical(p,0)
        for k,n in enumerate(names):
            name,_,part=n.partition(':');a=new[name];z=old[name]
            aa=oldr.expr(s.im(a) if part=='im' else s.re(a),s.Symbol('dummy'))
            if name=='mphi2':zz=z
            else:zz=oldr.expr(s.im(z) if part=='im' else s.re(z),s.Symbol('dummy'))
            delta=aa-zz
            if delta:
                D=[[self.atoms[j] for j in row] for row in ex['counterterm_H8_basis_exact'][k]];H=[[a+delta*b for a,b in zip(row,col)] for row,col in zip(H,D)]
        assert all(not z.b for row in H for z in row)
        out=[[al.Q(rr,z.a,al.K.zero) for z in row] for row in H]
        for i in range(4,8):out[i][i]+=rr.w
        return out
def root_value(rr,digits):
    mp.mp.dps=digits;a=rr.value(al.Q(rr,rr.c1,al.K.zero),0);b=rr.value(al.Q(rr,rr.c0,al.K.zero),0);disc=a*a-4*b;assert disc>0;return(-a+mp.sqrt(disc))/2
def kernel(H,rr):
    A,piv=al.rref(H);assert len(piv)==6;free=[j for j in range(8) if j not in piv];B=[[rr.zero]*2 for _ in range(8)]
    for k,j in enumerate(free):
        B[j][k]=rr.one
        for i,col in enumerate(piv):B[col][k]=-A[i][j]
    G=al.mul(al.transpose(B),B);det=G[0][0]*G[1][1]-G[0][1]*G[1][0];assert det
    for anchor in range(4,8):
        y=[(G[1][1]*B[anchor][0]-G[0][1]*B[anchor][1])/det,(G[0][0]*B[anchor][1]-G[1][0]*B[anchor][0])/det];q=[al.dot(row,y) for row in B]
        if q[anchor]:q=[z/q[anchor] for z in q];break
    assert all(not al.dot(row,q) for row in H);return q,al.dot(q,q),anchor
def neutral(craw):
    valley=read(C/'canonical_so10_higgs_neutral_valley/original_result.json');H=s.zeros(10);H[:5,:5]=inp.singlet(craw)[0]
    for rec in valley['five_independent_Hessian_entries']:
        v=sum(craw[n]*s.sympify(rec['raw'][n]) for n in inp.REAL)+sum(2*s.re(craw[n]*s.sympify(rec['raw'][n])) for n in inp.COMPLEX);i,j=rec['indices'];H[i,j]=H[j,i]=s.expand(v)
    H[7,7]=H[6,6];H[9,9]=H[8,8];H[7,9]=H[9,7]=H[6,8];H[7,8]=H[8,7]=-H[6,9]
    return H,valley
