# Additional corrected-verifier allowance V3

After the original two-process limit was exhausted, the director explicitly
answered "Authorize one corrected verifier (Recommended)" to the question
describing the prepared fix, same900second/8GiB caps, preserved failed run,
unchanged mathematics and no new parameter search. This authorizes exactly
one additional verifier, not an additional primary or fourth physics process.

The frozen original failed at its report-link assertion. The correction
compares the resolved receipt path, permitting the verifier's own future
receipt without treating a different relative spelling as an unrelated file.
Every mathematical assertion, action, inherited input, candidate and physical
acceptance condition stays unchanged. New versioned preparation/capture/source
bind the correction; the failed original/source copy/preparation/capture and
first two reports remain preserved. Counters explicitly retain one failed
verifier and three total launches including that failure, no fresh primary pair.

The corrected worker must finish the original real8 light-root, full35 exact
signed-congruence, spectrum, contact/radial, negative-control, byte/preflight
and source checks. A completed certificate may qualify only those bounded
rejected-candidate facts, never full-domain exclusion or physical viability.
Another failure remains incomplete; do not silently retry. Apply the same
350MiB immediately observed available-commit minimum and8GiB sampled private
cap,900seconds after imports, preserving terminal failures and full outputs.
The added allowance does not change scientific authority, a model input or
the human-paused flavor boundary. Metadata/Git checks execute no new physics.
