# Authorized bounded eight-quartic scalar feasibility study V1

Director authorization: explicit reply "Authorize bounded scalar feasibility
(Recommended)" to the question naming RESEARCH_DIRECTION_PROPOSAL_V1.md.
This resolves the previous scope-choice blocker; it is exploration, not a
new accepted benchmark, physical scheme, gauge input or resumed flavor fit.
Baseline ff0cf0ed4a821041281b11fd44a0f96708b4090d. Actual standard preflight
clean/no matching workers; statev113/34of39 unchanged. Prior turn PROGRESS:
published global-anomaly applicability review, no new physics computation.

Question: does the authorized eight-quartic comparison contain a candidate
passing the declared inexpensive necessary scalar conditions? A witness
shows nonempty necessary-condition space, not physical viability. A failed
seed or numerical solver cannot exclude the full comparison. Only an exact
certificate could establish infeasibility; otherwise report INCONCLUSIVE.
No model repair, new interaction or extra adjustable parameter is allowed.

Fix all fields/charges/invariants, SM vacuum orientation, omega^2=60 and
sigma^2=v^2=3/5. Vary exactly lambdaPhi1,lambdaPhi2,lambdaPhiSigma1,
lambdaPhiSigma2,lambdaSigma1..4 over real values. Other physical couplings
and phases retain the qualified positive-Higgs values. Derive mPhi2,mSigma2,
mS2 by stationarity. The dependent mphi2 is fixed by the following light
condition, not freely fitted to a desired quartic or loop correction.

At the fixed vacuum the weak doublet block has two Sigma and two phi copies.
Require its Sigma principal block S>0. Eliminate S to obtain a2x2 Hermitian
phi Schur matrix F_eff+mphi2*G_phi in raw coordinates. The determinant is
a quadratic in mphi2. Choose the larger real root, so the Schur matrix is
positive semidefinite with exactly one zero complex eigenvalue. Check the
discriminant and remaining positive eigenvalue, reconstruct the exact neutral
light plane, and compare with the independent real8 derivative-matrix route.
If S is not positive or this condition fails, that candidate fails the
declared light branch; do not change the condition after observing it.

Necessary conditions assessed:
* Exact stationarity and full35 affine Hermitian Hessian blocks, using the
  inherited complete34-slot raw matrices and actual positive kinetic metrics.
  Preserve all blocks/conjugates; expected positive290/zero38 real directions
  means33 gauge orbit,1 PQ and4 Higgs zeros, no unexplained extra zero.
* The measured Sigma contact ellipse50A^2+36B^2<=256pi^2 and the three
  primitive diagonal channels abs(D_i)<=16pi. These cover the qualified20
  diagonal directions but are not full scalar scattering/perturbativity.
* Positive radial directions, two explicit pure-Phi quartic ray tests with
  p4/p2^2=1/10 and73/90, and the necessary Phi/Sigma radial quartic condition
  lPhi>=0,lambdaSigma1>=0,lmix+2sqrt(lPhi*lambdaSigma1)>=0. Other S portals
  remain zero andlambdaS=1. These are not a full328-dimensional BFB proof.
* Light-doublet tuning as above. If the finite source calculation fits within
  the same atomic budget, evaluate the direct and neutral-heavy-relaxed tree
  Higgs quartic from the unchanged parent oracle at the new light direction.
  A completed positive-quartic witness requires a certified positive bound.
  Missing/uncontrolled quartic evaluation leaves that requirement INCOMPLETE;
  do not label a Hessian/scattering witness as a viable replacement.

Least expensive construction: one frozen rational seed scales the four
Sigma quartics by1/10, holding the other four allowed quartics at their old
values, then imposes stationarity/light tuning. A passing witness is also a
witness in the full eight-quartic comparison. A failed seed never excludes
that comparison. Preserve every rejected seed and diagnostic, including signs.
If this seed fails the numerical necessary conditions, use the existing
CVXPY/CLARABEL CPU solver for one deterministic9-variable affine PSD/SOC
feasibility problem (eight quartics plus mphi2/60), with minimum L1 distance
to the frozen point as a representative-selection rule, not a physical fit.
There are no random starts or new parameter box. At most two further
convex light-face refinements are allowed, fixing the preceding light vector
only as a search strategy; retune mphi2 exactly and test the full matrices
after rounding the eight quartics to12 decimal places. Failure on a fixed
light face is not a full-domain exclusion. Numerical common-kernel compression
may aid the solver; the verifier must certify all original unreduced blocks.

Search safeguards: use an interior95% Sigma contact bound and1e-4 internal
mass-squared margin on positive search faces for numerical robustness. They
are witness-construction margins only; acceptance uses the actual necessary
bounds and exact ranks. Solver status is diagnostic, never an infeasibility
proof. Each solve has180second time limit/150iterations; at most three solves.
No other coupling, scale, Yukawa input or gauge width is optimized. Preserve
the V95 weak-input term; do not impose the old fixed-other-input Sigma cap.

Primary method: deterministic convex feasibility if needed, exact2x2 Schur
polynomial,100/140digit field/mass checks and rationalized candidate. Direct
parent-potential interpolation at the new rounded tangent supplies quartic
and h^2X sources; old numerical vertices/loops are never transferred. The
existing neutral10 basis contains the two orbit/PQ null directions and eight
positive heavy directions. Retain/check null sources, the raw covector metric
and heavy relaxation. Stop on the first measured negative relaxed quartic
for the selected candidate, rather than tuning further parameters to hide it.

Independent verifier: direct real8 affine weak matrix and exact quadratic
quotient, full unreduced raw Hermitian PSD by exact Schur congruences with
outward rational sign enclosures, rank/multiplicity counts, stationarity and
rigorous pi/contact/radial bounds. For a completed quartic check use separate
polynomial interpolation/assembled valley evaluation and certified transport
to the exact light direction with the inherited action norm bounds and a
new positive neutral-heavy gap. If an interval/pivot cannot be certified,
leave the affected result unqualified. Detect wrong mass substitution,
wrong root, omitted complex conjugates/kinetic factors and a deliberately
negative Hermitian reference. Shared action, raw-Hessian inputs, parent oracle,
Python/SymPy and analyst remain explicit limits of corroboration.

Exactly two sequential atomic physics processes are authorized: primary and
independent verifier. Each has350MiB immediate available-commit prelaunch
observation,8GiB sampled private cap and900seconds after imports; total compute
at most30minutes. Import/setup and parent byte/Git bookkeeping are recorded
separately and do not permit additional native/fresh physics runs. The primary
has a540second convex-solve allowance and must stop safely before the global
900second boundary. Oracle calls check the remaining boundary between atomic
evaluations. Resource limits mean INCOMPLETE, never truncated acceptance.
No third physics launch or silent retry after a failed worker.

Freeze sources and immutable inputs before primary execution. Preserve full
captures and every failed/incomplete run. Completed independent receipt,
actual standard preflight, protected README/state and raw Git custody are
required before local commit. No source activation, new broad optimizer,
global BFB search, two-loop threshold, physical Higgs matching or quantum
compiler expansion. No new loop/tadpole calculation. The old loop results,
global stability certificates and phenomenology do not transfer to a candidate.

The overall study may complete with a verified bounded witness, exact
restricted exclusion, or explicit inconclusiveness. All are legitimate
physics/AI outcomes. Director controls adoption and further rebuild. Education
voluntary/nonblocking; solo policy unchanged. Preserve34/39,quartetFAIL3960/648,
E5/A5unqualified,HB1/C5blocked,C1_GSuncalculated,full328BFB/naturalness,
matter/flavorpause,custodyexit2/seven. No branch/worktree/reset, remote action,
publication or outreach. Overall investigation remains incomplete.
