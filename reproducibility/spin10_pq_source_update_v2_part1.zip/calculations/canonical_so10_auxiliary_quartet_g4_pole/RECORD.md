# Actual higher-order auxiliary-source quartet pole V1

Baseline79ac584f831129a30976cf7a0fb59c69fe28cb89; AGENTS standing delegation,
statev113/34of39 unchanged. Calculate the complete CD0,no-jet g4 auxiliary-
source quartet from the actual S,K,Fa,Fc,D,R inputs and qualified48 units.
Retain all45 directions and2004750 independent ordered-source/antighost and
exterior-ghost slots. A zero or nonzero answer is acceptable; neither a
required Slavnov tensor nor a fitted normalization is available to workers.

Preserve the three ordinary families KL*F*F,SL*D*F,SL*F*F*F and explicit-xi
KL*R. Source K ghosts use a<b, R both antisymmetric pairs use i<j,a<b, and
D vector pairs u<=v require factor2 for an identical-vector Hessian. Fa is
the external-ghost derivative coefficient; the effective external-antighost
F coefficient is -Fc. Do not silently project away permitted H/M indices.

Primary reconstructs full graded temporal Hessians on90 even/90 odd quantum
coordinates. The qualified general-four-momentum units license this scalar
Lorentz contraction, including full B/B longitudinal width and transverse
contribution. Let X/Y be even-odd/odd-even Hessian blocks, Ge the even inverse,
Go the odd inverse. Use mixed-only Ge_m and unweighted B/B projectors Ge_H/M.

    A = YS Ge_m XF + YF Ge_m XS
    B_w = YF Ge_w XF
    C_w = YS Ge_m DE Ge_w XF + YF Ge_w DE Ge_m XS

The ordinary common-pole polynomials are +Tr(Go K Go B_w),
-Tr(Go A Go B_w), and +Tr(Go C_w). The explicit R bubble is
-Tr(Go K Go R). Split K's exterior antighost/ghost components to retain both
external-antighost partitions. Evaluate closed finite traces with exact
Grassmann order; do not move odd rectangular factors cyclically without a
derived sign. Check the otherwise graph-excluded +Tr(Go A Go R) contribution
explicitly: a nonzero result is an unresolved premise, not an omitted term.
These formulas follow from the odd Schur logarithm, not Slavnov closure.

Use the previously qualified scaled-integer/root/exterior arithmetic as a
backend, with full conversion roundtrips and256 root/exterior products. Close
cycles before degree-four off-diagonal expansion. Establish the new Schur
formula against all48 unit patterns at declared nonzero width fixtures and
the two reused bubble patterns before any actual contraction. Fixtures are
verification data, not physical width adoption. Preserve all unit factors.

Replay derives actual coefficients by sparse indexed Wick color paths. With
K_full antisymmetric in its ghost pair and R_full in both pairs, its pieces
in ordered JL_i a_j C_a C_b convention are accumulated with exterior sign:

    K_K: +2 W_u K(i,j;m,n) Fa(u,m,a) Fa(u,n,b), m<n
    K_F: -2 W_u K_full(i,m;n,a) Fc(u,j,m) Fa(u,n,b)
    S_D: +2 W_u S(i,l,h) D_derivative(j,a;l,u) Fa(u,h,b)
    S_F: +2 W_u S(i,l,h) Fa(u,h,a) Fc(u,j,m) Fa(l,m,b)
    R_K: -2 K(i,j;m,n) R(m,n;a,b), m<n,a<b
    R_R: +2 K_full(i,m;n,a) R_full(j,n;m,b).

D_derivative is the two-B Hessian,including the identical-vector factor.
Do not double the ordered internal pair in K_K/R_K. Compare complete separate
pieces,H/M widths,total and implicit zero complements. Replay nonzero typed
fixtures verify each contraction and D multiplicity before actual inputs.

Keep H/M ordinary and explicit curvature terms distinct. Only at the final
sum apply the qualified frozen bridge W_H=eta_H,W_M=xi, and restore the R
vertex's explicit xi once. The result has common unit hbar*g10^4/(32*pi²
epsilon_UV),with no extra ghost-pair1/2. Retain family omission/doubling,
wrong width assignment and source-normalization controls,reporting insensitive
cases. Width values are never selected to force cancellation.

Two sequential read-only300-second/sampled8GiB actual workers,>=350MiB
available commit; the larger bound covers new four-vertex and13254-coefficient
D contractions versus earlier selectedg3 work. Freeze exact sources,backend,
classical-only inputs,receipts and role allowlists before computation. Preserve
every native failure/incompleteness; no truncation or automatic cap increase.
Separate scoped validation compares every family/total and independent
coefficient controls before local commit. No full old Gamma,old quantum loop,
parameter search or new compiler. Canonical transport and any subsequent
Slavnov assessment remain separate until actual paired coefficients qualify.

Ceiling: complete selected actual local logarithmic pole and its exact
scope/limitations. No finite/IR,QAP,measure,anomaly freedom,full source closure
or E5/A5 acceptance. Gamma145546 is unchanged in this coefficient phase;
HB1/C5 blocked,C1_GS uncomputed,flavor paused,scalar warnings,custodyexit2/seven
and all old successes/failures preserved. Shared action,qualified units,
classical inputs,arithmetic/helpers and AI authorship limit independence.
Science and AI capability remain equal objectives; education voluntary,
concurrent,nonblocking. No benchmark,input,foundation,protected or remote change.
