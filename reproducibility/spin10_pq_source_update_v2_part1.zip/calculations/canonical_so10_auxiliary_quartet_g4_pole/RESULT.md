# The actual higher-order auxiliary-source quartet pole is nonzero

Two distinct methods agree on the complete selected CD0,no-jet g10^4
JLambda*a*C*C logarithmic pole, including all family and width components.
Qualification requires the completed validation receipt. This is a formal
one-loop local coefficient, not a physical amplitude or completed E5 result.

The result is

    hbar*g10^4/(32*pi²*epsilon_UV) * JL_i a_j C_a C_b
        * [eta_H A(i,j,a,b) + xi B(i,j,a,b)], a<b.

There is no extra ghost-pair divisor. Each of A and B has4880 nonzero color
positions, with the same support. All2004750 independent positions are covered,
including the complete implicit-zero complement. Final nonzero indices are in
the heavy sector; light-index zeros were obtained from the full calculation,
not imposed as a prior restriction. For example,

    A(13,14,13,14) = -48/25;
    B(13,14,13,14) = -192/25.

These are source/pole coefficients in the declared internal convention. They
are not measured particle interactions, a gauge anomaly or a physical GUT
prediction. No width value has been chosen to obtain a favorable answer.

| Separate unweighted contribution | H B/B entries | M B/B entries |
| --- | --- | --- |
| K_K: external antighost on K | 4880 | 4880 |
| K_F: external antighost on F | 2514 | 0 |
| S_D: source cubic + ordinary quartic | 3690 | 11468 |
| S_F: source cubic + three F vertices | 3690 | 0 |

The explicit-curvature bubble has3344 R_K and10940 R_R entries; their sum has
11912. The ordinary M sum has12104 entries. Only after combining that sum
with the explicit R bubble does the final xi coefficient reduce to4880.
The complete ordinary H sum likewise has4880. Full individual arrays and
intermediate sums are retained; cancellation does not erase their evidence.

The width bridge is inherited from the actual reference: W_H=eta_H,W_M=xi.
Thus the ordinary explicit-xi0 diagrams can contribute to the final xi term.
Their heavy propagator width and the explicit R-vertex factor are restored
once each. Swapping the width assignments or doubling R changes the result.
Every nonzero family omission is detected. K_F_M and S_F_M are actual zeros;
their omissions are correctly insensitive and are not normalization controls.

Primary reconstructs all180 temporal quantum Hessians from the qualified
classical tensors. Exact scaled-integer/root/exterior matrices evaluate the
odd Schur logarithm without constructing unused degree-four off-diagonal
matrices. The new formula reproduces all48 full-vector unit cases, the two
pure-ghost bubble patterns and denominator-scale controls before actual input
release. All256 root/exterior basis products and atomic conversion roundtrips
are checked. Closed finite traces preserve Grassmann order; no infinite
regularized-trace cyclicity or ungraded odd-factor rotation is assumed.

Replay independently contracts the actual indexed Wick color paths, retaining
all internal indices and both external-antighost partitions. It combines
ordered internal pairs once, keeps the source quartic's two ghost extractions
and includes the identical-B Hessian factor2. Seven nonzero typed fixtures
check every piece and D multiplicity. Precontracting Fc*Fa only changes the
order of finite sums. Complete family,intermediate and total arrays agree
exactly with the primary, including all zeros. The otherwise graph-excluded
source-F-R trace is explicitly zero in the full primary contraction.

Primary/replay took24.58/10.82seconds after imports under sequential300-second/
sampled8GiB limits. The actual integer scale is120 in both routes. No failed
calculation or old-loop/full-Gamma replay occurred in this increment. A
separate validator authenticates all inputs/captures,compares every coefficient,
reconstructs total/controls and checks complete independently contracted source
faces with ordinary SymPy matrix/Gram arithmetic. Those extra faces are a
bounded comparator; the full two-method comparison supplies full coverage.
No fresh same-command pair or external expert/experimental validation is claimed.

Track A gains the actual missing higher-order pole rather than an inferred
completion tensor. Track B gains successful reuse of low-dimensional structure,
explicit width bookkeeping and two different full calculations; shared action,
reference/UV assumptions,units,classical inputs,arithmetic helpers and AI
authorship remain shared-error limits. Education stays voluntary,concurrent
and nonblocking. A nonzero pole still needs its legitimate counterterm and
consistency interpretation; it does not by itself refute the theory.

Next pull the actual density back to canonical source/field coordinates,check
full reality and chart roundtrips,and add it once using the current V189
recipe. Assess its local H Ward identity and a complete actual predecessor
census before selecting any affected Slavnov relation. Do not infer that
relation vanishes or fit an unknown breaking to force it.

Gamma145546 remains unchanged in this coefficient phase. Full source closure,
E5/A5,QAP,measure,finite contacts/physical IR and anomaly freedom remain
unqualified. Authorityv113/34of39,HB1/C5 blocked,C1_GS uncomputed,flavor paused,
scalar warnings,prior failures and custodyexit2/seven are preserved. No accepted
input,benchmark,foundation,protected promotion,publication or remote change.
