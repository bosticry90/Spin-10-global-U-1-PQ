"""Actual g4 source quartet: integer graded Schur versus indexed Wick paths."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from fractions import Fraction
from itertools import product
from math import lcm
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,alphabet,register,canonical
from a10_e2_transport_common import partials
import a10_e5_quartic_algebra as ex
BACKEND=Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/source-quartic-pole-v1-2026-10-16/integer_backend_v4.py')
sp=importlib.util.spec_from_file_location('qualified_integer_exterior',BACKEND);ib=importlib.util.module_from_spec(sp);sp.loader.exec_module(ib)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();Z=ex.D.zero;N=ex.coefficient
LABELS=['K_K','K_F','S_D','S_F','R_K','R_R'];SIDES=['H','M'];PRINTED={}
def textcoef(z):
    key=tuple(sorted(z.cells.items()))
    if key not in PRINTED:
        value=ex.D.to_sympy(z);assert s.expand(value-s.conjugate(value))==0 and not value.free_symbols
        PRINTED[key]=str(value)
    return PRINTED[key]
def parse_tables(rows):return {tag:{tuple(r[:-1]):N(s.sympify(r[-1])) for r in table} for tag,table in rows.items()}
def native(P,w):
    # P is an already coupling-stripped logical action tensor.
    out={}
    for factors,z in P:
        for word,sg in w.mul(*(w.var(n,j) for n,j in factors)).items():out[word]=out.get(word,0)+ex.D.to_sympy(z)*sg
    return out
def physical_polynomials(T):
    w=alphabet()
    for i in range(45):
        for pre,grade in [('Cp',(1,1,1)),('ap',(1,-1,1)),('Lp',(2,0,0)),('JLp',(1,-1,1)),('Bp',(1,0,0))]:register(w,pre+str(i),grade)
    V={}
    V['S']=native([([(f'JLp{i}',()),(f'Lp{u}',()),(f'Cp{h}',())],z) for (i,u,h),z in T['S'].items()],w)
    V['K']=native([([(f'JLp{i}',()),(f'ap{j}',()),(f'Cp{a}',()),(f'Cp{b}',())],z) for (i,j,a,b),z in T['K'].items()],w)
    V['F']=native([([(f'ap{j}',(0,)),(f'Bp{u}',()),(f'Cp{k}',())],z) for (u,j,k),z in T['Fa'].items()]+[([(f'ap{j}',()),(f'Bp{u}',()),(f'Cp{k}',(0,))],z) for (u,j,k),z in T['Fc'].items()],w)
    V['D']=native([([(f'ap{j}',()),(f'Cp{k}',()),(f'Bp{u}',()),(f'Bp{v}',())],z) for (j,k,u,v),z in T['D'].items()],w)
    V['R']=native([([(f'ap{i}',()),(f'ap{j}',()),(f'Cp{a}',()),(f'Cp{b}',())],z) for (i,j,a,b),z in T['R'].items()],w)
    assert all(w.grade(P,(4,0,0)) for P in V.values())
    names=[pre+str(i) for pre in ['Bp','Lp','Cp','ap'] for i in range(45)];ext={**{f'Cp{i}':i for i in range(45)},**{f'ap{i}':45+i for i in range(45)},**{f'JLp{i}':90+i for i in range(45)}}
    return w,V,names,ext
def encode(P,ext):
    out={}
    for word,z in P.items():
        if any(j or n not in ext for n,j in word):continue
        ordered,sg=ib.exterior(tuple(ext[n] for n,j in word))
        if sg:out[ordered]=out.get(ordered,Z)+sg*N(s.expand(z))
    return {w:z for w,z in out.items() if z}
def Hessian(P,w,names,ext):
    pos={n:i for i,n in enumerate(names)};out={}
    for (a,alpha),first in partials(P,w,set(names)).items():
        for (b,beta),second in partials(first,w,set(names)).items():
            if any(mu!=0 for mu in [*alpha,*beta]):continue
            factor=(-1)**(w.p[b]*(w.p[a]+1))*(-s.I)**len(alpha)*s.I**len(beta);packed=encode({word:z*factor for word,z in second.items()},ext)
            if packed:out[pos[a],pos[b]]=ex.add(out.get((pos[a],pos[b]),{}),packed)
    return out
def closed3(A,B,C):
    rows=defaultdict(list);out={}
    for (a,b),Q in B.items():rows[a].append((b,Q))
    for (i,a),P in A.items():
        for b,Q in rows.get(a,[]):
            if (b,i) not in C:continue
            V=ib.mul(ib.mul(P,Q),C[b,i])
            for key,z in V.items():out[key]=out.get(key,0)+z
    return {key:z for key,z in out.items() if z}
def evaluate(Hs,Ge_m,Ge_w,Go,p_ev,p_od,scale_extra=1):
    # All Hessian blocks are already local to their parity spaces.
    D=1
    for A in Hs.values():
        for P in A.values():
            for z in P.values():
                for (a,b,mask),v in z.cells.items():assert a==b==0;D=lcm(D,v.denominator)
    D*=scale_extra
    for A in Hs.values():
        for P in A.values():assert ib.restore(ib.convert(P,D),D)==P
    X={tag:ib.matrix(ex.block(Hs.get(tag,{}),p_ev,p_od),D) for tag in ['S','F']};Y={tag:ib.matrix(ex.block(Hs.get(tag,{}),p_od,p_ev),D) for tag in ['S','F']}
    DE=ib.matrix(ex.block(Hs.get('D',{}),p_ev,p_ev),D);KO=ib.matrix(ex.block(Hs.get('K',{}),p_od,p_od),D);RO=ib.matrix(ex.block(Hs.get('R',{}),p_od,p_od),D);GI=ib.matrix(Go,1);GM=ib.matrix(Ge_m,1);GW=ib.matrix(Ge_w,1)
    for tag in ['S','F']:assert not ex.block(Hs.get(tag,{}),p_ev,p_ev) and not ex.block(Hs.get(tag,{}),p_od,p_od)
    for tag in ['K','R']:assert not ex.block(Hs.get(tag,{}),p_ev,p_ev) and not ex.block(Hs.get(tag,{}),p_ev,p_od) and not ex.block(Hs.get(tag,{}),p_od,p_ev)
    assert not ex.block(Hs.get('D',{}),p_od,p_od) and not ex.block(Hs.get('D',{}),p_ev,p_od) and not ex.block(Hs.get('D',{}),p_od,p_ev)
    Kparts={'K_K':{},'K_F':{}}
    for ij,P in KO.items():
        for key,z in P.items():
            word,mask=key;label='K_K' if any(45<=n<90 for n in word) else 'K_F';Kparts[label].setdefault(ij,{})[key]=z
    M=lambda a,b,E:ib.mm(ib.mm(Y[a],E),X[b])
    A=ib.msum(M('S','F',GM),M('F','S',GM));B=M('F','F',GW);GA=ib.mm(GI,A);GB=ib.mm(GI,B);GR=ib.mm(GI,RO)
    gK={tag:ib.mm(GI,A) for tag,A in Kparts.items()};out={}
    for tag in ['K_K','K_F']:out[tag]=ib.restore(ib.closed(gK[tag],GB),D**3)
    out['S_F']=ib.restore(ib.closed(GA,GB),D**4,-1)
    L1=ib.mm(ib.mm(GI,Y['S']),GM);R1=ib.mm(GW,X['F']);L2=ib.mm(ib.mm(GI,Y['F']),GW);R2=ib.mm(GM,X['S'])
    out['S_D']=ib.restore(ib.add(closed3(L1,DE,R1),closed3(L2,DE,R2)),D**3)
    out['R_K']=ib.restore(ib.closed(gK['K_K'],GR),D**2,-1);out['R_R']=ib.restore(ib.closed(gK['K_F'],GR),D**2,-1)
    unexpected=ib.restore(ib.closed(GA,GR),D**3)
    return out,unexpected,{'D':D,'A_cells':len(A),'B_cells':len(B),'DE_cells':len(DE),'no_degree4_offdiagonal_matrix_constructed':True}
def actual_primary(T,stage):
    w,V,names,ext=stage('reconstruct_actual_coupling_stripped_polynomials',lambda:physical_polynomials(T));Hs={tag:stage('graded_Hessian_'+tag,lambda P=P:Hessian(P,w,names,ext)) for tag,P in V.items()}
    ev=list(range(90));od=list(range(90,180));Go={(i,45+i):{():N(1)} for i in range(45)}|{(45+i,i):{():N(-1)} for i in range(45)}
    GM={(i,45+i):{():N(s.I)} for i in range(45)}|{(45+i,i):{():N(-s.I)} for i in range(45)};pieces={};stats={};AR={}
    for side,ids in [('H',range(12)),('M',range(12,45))]:
        GW={(i,i):{():N(-1)} for i in ids};P,A,st=stage('closed_integer_Schur_'+side,lambda:evaluate(Hs,GM,GW,Go,ev,od));stats[side]=st
        for label in ['K_K','K_F','S_D','S_F']:pieces[label+'_'+side]=P[label]
        if not AR:AR=A
        if side=='H':
            pieces['R_K']=P['R_K'];pieces['R_R']=P['R_R']
        else:assert P['R_K']==pieces['R_K'] and P['R_R']==pieces['R_R']
    return {tag:logical(P) for tag,P in pieces.items()},logical(AR),stats
def logical(P):
    out={}
    for word,z in P.items():
        assert len(word)==4 and 0<=word[0]<word[1]<45 and 45<=word[2]<90 and 90<=word[3]<135
        out[word[3]-90,word[2]-45,word[0],word[1]]=-z
    return out
def scalar_root(z,D):
    out={}
    for (a,b,mask),v in z.cells.items():assert a==b==0 and (v*D).denominator==1;out[mask]=(v*D).numerator
    return out
def rootmul(*As):
    out={0:1}
    for A in As:
        new={}
        for a,x in out.items():
            for b,y in A.items():new[a^b]=new.get(a^b,0)+x*y*ib.FACT[a&b]
        out={mask:z for mask,z in new.items() if z}
    return out
def index_contract(T,channel,stage=lambda n,f:f()):
    D=1
    for P in T.values():
        for z in P.values():
            for a in z.cells.values():D=lcm(D,a.denominator)
    V={tag:{idx:scalar_root(z,D) for idx,z in P.items()} for tag,P in T.items()};S,K,Fa,Fc,DD,RR=(V[tag] for tag in ['S','K','Fa','Fc','D','R']);KF={};RF={}
    neg=lambda P:{m:-z for m,z in P.items()}
    for (i,j,a,b),z in K.items():KF[i,j,a,b]=z;KF[i,j,b,a]=neg(z)
    for (i,j,a,b),z in RR.items():RF[i,j,a,b]=z;RF[j,i,a,b]=neg(z);RF[i,j,b,a]=neg(z);RF[j,i,b,a]=z
    Farr=defaultdict(dict);Fpair=defaultdict(list);Fcr=defaultdict(list)
    for (u,m,a),z in Fa.items():Farr[m].setdefault(u,[]).append((a,z));Fpair[u,m].append((a,z))
    for (u,j,m),z in Fc.items():Fcr[m].append((u,j,z))
    Dpair=defaultdict(list)
    for (j,a,l,u),z in DD.items():Dpair[l,u].append((j,a,z,2 if l==u else 1))
    Rpair=defaultdict(list);Rcross=defaultdict(list)
    for (m,n,a,b),z in RR.items():Rpair[m,n].append((a,b,z))
    for (j,n,m,b),z in RF.items():Rcross[n,m].append((j,b,z))
    out={label+'_'+side:{} for label in ['K_K','K_F','S_D','S_F'] for side in ['H','M']}|{'R_K':{},'R_R':{}}
    def put(label,i,j,a,b,P,factor):
        if a==b:return
        if a>b:a,b,factor=b,a,-factor
        B=out[label]
        for mask,z in P.items():key=(i,j,a,b,mask);B[key]=B.get(key,0)+factor*z
    def KK():
        for (i,j,m,n),z in K.items():
            for u in Farr[m].keys()&Farr[n].keys():
                side,weight=channel(u)
                for a,f in Farr[m][u]:
                    for b,c in Farr[n][u]:put('K_K_'+side,i,j,a,b,rootmul(z,f,c),2*weight)
    def KFfn():
        for (i,m,n,a),z in KF.items():
            for u,j,c in Fcr[m]:
                side,weight=channel(u)
                for b,f in Fpair[u,n]:put('K_F_'+side,i,j,a,b,rootmul(z,c,f),-2*weight)
    def SD():
        for (i,l,h),z in S.items():
            for u,entries in Farr[h].items():
                side,weight=channel(u)
                for j,a,c,mult in Dpair[tuple(sorted((l,u)))]:
                    for b,f in entries:put('S_D_'+side,i,j,a,b,rootmul(z,c,f),2*weight*mult)
    def SF():
        product_cache={}
        for (i,l,h),z in S.items():
            for u,entries in Farr[h].items():
                ck=(u,l)
                if ck not in product_cache:
                    P={}
                    for (uu,j,m),c in Fc.items():
                        if uu!=u:continue
                        for b,f in Fpair[l,m]:
                            for mask,v in rootmul(c,f).items():P[j,b,mask]=P.get((j,b,mask),0)+v
                    collapsed=defaultdict(dict)
                    for (j,b,mask),v in P.items():
                        if v:collapsed[j,b][mask]=v
                    product_cache[ck]=collapsed
                side,weight=channel(u)
                for a,f in entries:
                    for (j,b),P in product_cache[ck].items():put('S_F_'+side,i,j,a,b,rootmul(z,f,P),2*weight)
    def RB():
        for (i,j,m,n),z in K.items():
            for a,b,r in Rpair[m,n]:put('R_K',i,j,a,b,rootmul(z,r),-2)
        for (i,m,n,a),z in KF.items():
            for j,b,r in Rcross[n,m]:put('R_R',i,j,a,b,rootmul(z,r),2)
    for label,fn in [('indexed_K_K',KK),('indexed_K_F',KFfn),('indexed_S_D',SD),('indexed_S_F',SF),('indexed_R_bubble',RB)]:stage(label,fn)
    restored={}
    for label,P in out.items():
        denom=D**(4 if label.startswith('S_F') else 2 if label.startswith('R_') else 3);byword=defaultdict(dict)
        for (*idx,mask),z in P.items():
            if z:byword[tuple(idx)][0,0,mask]=Fraction(z,denom)
        restored[label]={idx:ex.Coefficient(cells) for idx,cells in byword.items()}
    return restored,{'D':D,'full_internal_indices_retained':True,'precontracted_Fc_Fa_only_associative_finite_sums':True}
def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
def unit_bridge():
    u=module('qualified_g4_units',ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_units/units.py');old=module('qualified_g3_units',ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/units_v2.py');answers={};scales={}
    for kind,ds in u.CASES:
        w,V,target=u.model(kind,ds);ext={'uv_C0':0,'uv_C1':1,'uv_aE':45,'uv_J':90};tags=['K','F','F'] if kind.startswith('K') else ['S','D','F'] if kind=='S_D' else ['S','F','F','F'];name=kind+'_'+''.join(ds)
        answers[name],stats=unit_value(w,V,tags,target,ext,lambda a,b:s.expand(u.inverse(a,b).as_expr().subs(dict(zip([v.as_expr() for v in u.K],[1,0,0,0]))|{u.t.as_expr():1,u.W0.as_expr():2,u.W1.as_expr():3})))
        if name in ['K_K_aa','K_F_ca','S_D_a','S_F_aca']:
            scaled,_=unit_value(w,V,tags,target,ext,lambda a,b:s.expand(u.inverse(a,b).as_expr().subs(dict(zip([v.as_expr() for v in u.K],[1,0,0,0]))|{u.t.as_expr():1,u.W0.as_expr():2,u.W1.as_expr():3})),2);assert scaled==answers[name];scales[name]=str(scaled)
    for kind in ['Q_K','Q_Q']:
        w,V,target=old.model(kind);ext={'uk_C0':0,'uk_C1':1,'uk_aE':45,'uk_J':90};answers[kind],_=unit_value(w,V,['K','R'],target,ext,lambda a,b:s.sympify(old.green(a,b,[1,0,0,0])).subs({old.R:1,old.width[0]:2,old.width[1]:3}))
    return {'all48_width_fixture_2_3':{k:str(v) for k,v in answers.items() if k not in ['Q_K','Q_Q']},'bubble_units':{k:str(answers[k]) for k in ['Q_K','Q_Q']},'denominator_scale2_controls':scales}
def unit_value(w,V,tags,target,ext,green,scale_extra=1):
    names=list(w.fields);par=[w.p[n] for n in names];ev=[i for i,z in enumerate(par) if not z];od=[i for i,z in enumerate(par) if z];eri={i:n for n,i in enumerate(ev)};ori={i:n for n,i in enumerate(od)};Hs={tag:{} for tag in ['S','K','F','D','R']}
    for tag,P in zip(tags,V):Hs[tag]=ex.msum(Hs[tag],Hessian(P,w,names,ext))
    GM={};GW={};Go={}
    for i,a in enumerate(names):
        for j,b in enumerate(names):
            z=green(a,b)
            if not z:continue
            if i in ori and j in ori:Go[ori[i],ori[j]]={():N(z)}
            elif i in eri and j in eri:
                (GW if 'B' in a and 'B' in b else GM)[eri[i],eri[j]]={():N(z)}
    P,extra,stats=evaluate(Hs,GM,GW,Go,ev,od,scale_extra);assert not extra;full=ex.add(*P.values());targetpoly=encode(target,ext);assert len(targetpoly)==1;word,normal=next(iter(targetpoly.items()));assert normal in [N(1),N(-1)]
    assert not set(full)-{word};return s.expand(ex.D.to_sympy(full.get(word,Z)*normal)),stats
def indexed_fixtures():
    def tables(**kw):return {label:{idx:N(z) for idx,z in kw.get(label,{}).items()} for label in ['S','K','Fa','Fc','D','R']}
    cases={
      'K_K':(tables(K={(20,13,12,16):1},Fa={(17,12,14):1,(17,16,15):1}),4),
      'K_F':(tables(K={(20,12,14,16):-1},Fc={(17,13,12):1},Fa={(17,16,15):1}),-4),
      'S_D':(tables(S={(20,17,12):1},D={(13,14,17,18):1},Fa={(18,12,15):1}),6),
      'S_F':(tables(S={(20,17,12):1},Fa={(18,12,14):1,(17,16,15):1},Fc={(18,13,16):1}),6),
      'R_K':(tables(K={(20,13,12,16):1},R={(12,16,14,15):1}),-2),
      'R_R':(tables(K={(20,12,14,16):-1},R={(13,16,12,15):1}),2),
      'identical_D':(tables(S={(20,17,12):1},D={(13,14,17,17):1},Fa={(17,12,15):1}),8)}
    out={}
    for label,(T,expected) in cases.items():
        parts,_=index_contract(T,lambda u:('H',2 if u==17 else 3));total={}
        for P in parts.values():
            for idx,z in P.items():total[idx]=total.get(idx,Z)+z
        total={idx:z for idx,z in total.items() if z};assert total=={(20,13,14,15):N(expected)},('INDEXED_FIXTURE',label,[(k,textcoef(v)) for k,v in total.items()]);out[label]=expected
    return out
def pack(P):
    rows=[]
    for idx,z in sorted(P.items()):
        if z:rows.append([*idx,textcoef(z)])
    return rows
def summary(P):
    rows=pack(P);return {'terms':len(rows),'sha256':sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'first_witness':rows[:1]}
def add(*Ps):
    out={}
    for P in Ps:
        for idx,z in P.items():out[idx]=out.get(idx,Z)+z
    return {idx:z for idx,z in out.items() if z}
def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256'] and digest(BACKEND)==prep['backend_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('ACTUAL_G4_QUARTET_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('ACTUAL_G4_QUARTET_REQUIRED_POLE_GAMMA_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);start=time.perf_counter();result=fn();stages.append({'name':name,'seconds':time.perf_counter()-start});return result
    basis=stage('integer_root_and_exterior_basis_controls',ib.checks)
    bridge=stage('complete_new_Schur_unit_bridge',unit_bridge) if role=='primary' else stage('all_indexed_nonzero_and_identical_D_fixtures',indexed_fixtures)
    if role=='primary':
        units=read(ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_units'/('primary_result.json'))['all48_general_q_units'];assert bridge['all48_width_fixture_2_3']=={label:str(s.expand(s.sympify(z).subs({'width0':2,'width1':3}))) for label,z in units.items()} and bridge['bubble_units']=={'Q_K':'-2','Q_Q':'2'}
    classical=read(OUT/('classical_'+role+'.json'));assert classical['width_identification']=={'reference_width_H':'eta_H','reference_width_M':'xi'};T=parse_tables(classical['classical_tensors'])
    if role=='primary':pieces,AR,method=actual_primary(T,stage)
    else:pieces,method=index_contract(T,lambda u:('H' if u<12 else 'M',1),stage);AR={};method['unlisted_AR_zero_by_complete_frontier_and_actual_HM_support']=True
    A=add(*(P for label,P in pieces.items() if label.endswith('_H')));Bordinary=add(*(P for label,P in pieces.items() if label.endswith('_M')));BR=add(pieces['R_K'],pieces['R_R']);B=add(Bordinary,BR)
    controls={}
    for label,P in pieces.items():
        side='H' if label.endswith('_H') else 'xi';total=A if side=='H' else B;mutant=add(total,{idx:-z for idx,z in P.items()});controls['omit_'+label]={'changes_'+side:mutant!=total,**summary(mutant)}
    controls['wrong_width_swap']={'changes_total':A!=Bordinary,'H_minus_M':summary(add(A,{idx:-z for idx,z in Bordinary.items()}))};controls['double_R']={'changes_xi':bool(BR),'xi_mutant':summary(add(B,BR))}
    result={'schema':'ACTUAL_HIGHER_AUXILIARY_QUARTET_POLE_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_ACTUAL_LOCAL_LOG_POLE_PENDING_PAIRED_VALIDATION' if not AR else 'INCOMPLETE_UNLISTED_AR_TRACE_NONZERO','separate_family_coefficients':{label:pack(P) for label,P in pieces.items()},'ordinary_H_total':pack(A),'ordinary_M_total':pack(Bordinary),'explicit_R_total':pack(BR),'actual_eta_H_coefficient':pack(A),'actual_xi_coefficient':pack(B),'unlisted_AR_trace':pack(AR),'controls':controls,'unit_or_indexed_bridge':bridge,'integer_basis':basis,'method':method,'raw_independent_color_slots':2004750,'units':'hbar*g10**4/(32*pi**2*epsilon_UV),ordered JLambda*a*C_a*C_b,a<b,no extra1/2','frozen_widths_restored_once':{'W_H':'eta_H','W_M':'xi','explicit_R_vertex':'xi'},'all45_color_zero_complements_retained':True,'known_Gamma_or_old_quantum_loop_recomputed':False,'canonical_pole_export_or_new_Slavnov_claim':False,'full_source_closure_E5_A5_QAP_IR_finite_or_anomaly_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
