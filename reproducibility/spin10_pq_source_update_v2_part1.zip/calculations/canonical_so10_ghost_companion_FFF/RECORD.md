# Complete actual FFF ghost triangle V1

Baseline3580bdc691a3c882d62a68393e49d895e14596ef. Question FFF1: what
is the complete ordinaryg3 one-jet FFF contribution to both independent
AaC/BaC ghost companions? The qualified domain has3AaC/23BaC profiles
and8/104 directed cycles. FFF has one BB and two oriented ghost propagators.
Closing it leaves FFG3 and FFU; no full ghost/Ward/E5 conclusion follows.

Freeze this record,code/controllers,protected policy,complete routed domain,
literal all57 F/IBP tensors,qualified physical adjoints/F_a/F_c/P1 and
principal inverse evidence before computation. Two sequential120-second-
after-import/8GiB workers,350MiB minimum available commit,then one120-
second/8GiB independent validator. Preserve failures,complete captures and
immutable inputs;no automatic resource expansion or evidence truncation.
No Gamma,primitive,desired ghost Ward coefficient or peer answer as input.

Derive the finite graded triangle factor once using abstract Fourier
vertex coefficients and arbitrary scalar propagators,retaining all six
Born orders. Replay uses explicit proper connected Wick contractions.
Independently test the finite ghost Schur complement with external odd
backgrounds. This finite normalization is not functional-trace cyclicity or
a quantum field-equivalence theorem. Directed support counts are not weights.

Use incoming external V momentum r,antighost -r-q,ghost q and loop k.
External-a vertex has internal B(k),C(r+q-k);external-C vertex has B(-k),
a(k-q);middle vertex has V(r),a(k-r-q),C(q-k). Check every vertex and
internal orientation. All quantum scalar masses/orbit insertions are excluded
only by the qualified dimension-zero census. A_H is external,not integrated.

Use the actual IBP-complete derivative F_a/F_c,with their boundary-current
bridge. Evaluate all eight left/middle/right derivative choices,all4 Lorentz
copies and both r=0/q=0 probes:256 unit positions. The two choices with
both outer derivatives on external ghosts have two external jets and must
be proved absent at one-jet order,not silently dropped or made into a
whole-amplitude zero. Retain arbitrary quantum-line width W and full4D
moments. Primary first Taylor/UV annulus;replay shifted three-denominator
Feynman simplex. Separate UV/IR with annulus or auxiliary IR mass;no
whole scaleless,finite amplitude or physical-IR inference.

Contract all actual45 quantum colors and57 external backgrounds. Primary
explicit exact-field indexed paths. Replay uses ordinary-SymPy ordered
matrix products and the H-Casimir reduction:
 sum_h F_h E_v F_h=(C_H E_v+E_v C_H-sum_u C_H[u,v] E_u)/2,
 C_H=sum_h F_h^2,
only after checking the actual F projector forms,H-invariance of projectors
and inherited actual adjoint Jacobi conventions. M sum remains explicit.
This is an algebraic sum reduction,not a symmetry fit or guessed pole.
Keep H/M and derivative-piece data for a complete independent comparison.

Check full literal all4 F copies and all57 principal P1 coefficients,
both complete115425-position derivative tensors/zero complements,reality
and all12 H-covariance identities. Controls remove an order,derivative
placement,H/M sector or BB component/change signs/angular metric;disclose
structural zero/insensitive cases. Independent validation must derive
Gaussian/Schur normalization,kernels,all color coefficients and Casimir
premises by different contractions,not merely compare the two result files.

Outcome:complete actual FFF local pole/zero,a normalization/input discrepancy
or bounded inconclusiveness. No insertion before complete family coverage,
canonical extraction and exact-once/inverse-addition qualification. No Ward
fit,whole-functional expansion,new input/scheme/benchmark/foundation/policy/
authority/remote action. Keep Gamma147266/hashc445c2...,38-source/auxiliary-H/
bilinear scopes,nonzeroJacobian,32products,128sourcejets,508programs,
QAP/contact/Legendre/measure/IR/Legacy gaps,34/39,HB1/C5block,flavorpause,
C1_GS,quartet/scalar warnings,closedroutes,custodyexit2/seven. FullE5/A5
and physicalviability unqualified. Sharedpremises/software/AIauthor limit
independence;educationvoluntary/nonblocking,Leanselective.
