# Exact first-jet continuation V2

The original primary reached its120-second bound after printing all unit
factors and entering actual color contraction. It produced no accepted
result tensor. Preserve the original source,preparation and full capture;
this is a bounded incomplete calculation,not a failed physical identity.

The original implementation repeatedly expanded higher powers of both
external momenta even though only the complete first Taylor jet is needed.
V2 constructs the exact zeroth and first numerator jets by the product
rule. Primary differentiates both ghost denominators;replay uses the
normalized first moments of the three-denominator Dirichlet simplex.
Both methods retain every one of the256 vector/probe components,all eight
derivative choices and the two structural two-external-jet zeros. The
finite graded normalization and actual full color problem are unchanged.

This is exact first-order algebra in the declared one-jet coefficient
domain,not a truncation of required evidence or a claim about higher jets.
The corrected primary and replay use separately frozen V2 source/captures
under the same120-second/8GiB/350MiB bounds. No resource increase,action
change,coefficient fit or lowered verification requirement is permitted.
The final receipt must retain one failed/incomplete original primary.
