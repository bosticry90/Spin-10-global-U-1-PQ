# The complete FFF ghost triangle is explicit

Prospective until both V2 worker results/captures, the independent receipt
and committed-byte checks qualify. Baseline3580bdc691a3c882d62a68393e49d895e14596ef.

The ordinaryg3 one-jet FFF triangle contribution is calculated over its
complete3AaC/23BaC profile domain,with8/104 directed rooted cycles. These
counts are support descriptors,not diagram symmetry factors or physical
processes. FFF has one ordinary BB line and two oriented ghost lines.
FFG3 and FFU remain unmeasured;this is not the complete ghost Ward result.

In units hbar*g10^3/(32*pi^2*epsilon_UV), the physical density is

    (partial_mu V_v^mu) a_j R[v,j,l] C_l
      + V_v^mu a_j Q[v,j,l] partial_mu C_l,

modulo the qualified four F integration-by-parts currents. V=0..11 is A_H,
and12..56 is B. Both R and Q have2088 nonzero entries and113337 zeros
over their full115425-position domains. Equal support counts do not mean
the two tensors are interchangeable. All4 Lorentz components and both
independent momentum probes are retained.

The three-letter unit label identifies the differentiated ghost field at
the left external-antighost vertex,middle external-vector vertex,and
right external-ghost vertex. The unit coefficients are

| Derivatives | Divergence-vector r coefficient | Ghost-derivative q coefficient |
| --- | ---: | ---: |
| aaa | W/2 | W/2 |
| aac | 0 | 0 |
| aca | -W/2 | -W/2 |
| acc | 0 | 0 |
| caa | -3W/2 | -W |
| cac | 0 | W/2 |
| cca | -W/2 | W |
| ccc | 0 | -W/2 |

All256 unit positions are checked. The aac/acc zeros follow because both
outer derivatives act on external ghosts,producing at least two external
jets. They are zeros of this one-jet projection,not a full amplitude
statement. Their unweighted color sums were not calculated:the empty
basis tables for those two labels mean the UV unit is outside the target,
not that its abstract color contraction vanishes.

The units are proportional to the quantum B-line width W. Thus a formal
W=0 control makes these local unit poles zero. This is not a chosen gauge
or a width-independent physical result. The actual calculation retains
the independent W_H/W_M symbols throughout both final tensors. No width
cancellation from a different family is transferred into FFF.

Finite Gaussian normalization keeps all six graded Born orders. Each has
coefficient i*G_B/(6*P_L*P_M);the sum is i*G_B/(P_L*P_M). Replay obtains
the same total from connected Wick contractions and external odd-order
signs. An independent finite ghost Schur complement gives the same result.
This finite algebra does not assume cyclicity of a divergent functional
trace,and it does not establish quantum field/source equivalence.

Left,middle and right Fourier factors have incoming ghost momenta
[-r-q,r+q-k], [k-r-q,q-k], [k-q,q],respectively. The BB loop momentum is k.
Every vertex sum and opposite internal orientation is checked. Primary
differentiates both ghost denominators. Replay combines K^a,L,M using
the normalized Feynman simplex and its first moments,with a=1,2. The
loop remains four-dimensional,and its logarithmic residue is separated
from IR/finite terms by the qualified UV-annulus/auxiliary-mass method.
No whole scaleless zero or exceptional physical amplitude is inferred.

The full color contraction uses all45 quantum colors and all57 external
backgrounds,with both F_a/F_c and their actual boundary-current bridge.
All four literal F copies and all57 principal P1 coefficients are checked.
Primary uses exact-field indexed paths. Replay uses ordinary-SymPy matrix
products and the H-Casimir double-commutator reduction. The reduction
requires the actual H-covariance of E_v and the actual adjoint/projector
conventions;independent validation must check these premises,not assume
them because the matrix formula is attractive. The M sum remains explicit.

The output retains the complete H/M unweighted bases for the six active
units. Independent validation must rederive the Schur/Gram unit factors,
reconstruct the color bases with Kronecker superoperators,compare all
coefficients and zero complements,and check all12 H-covariance identities.
Controls include omitted orders,sectors and derivative pieces,wrong angular
metric and the formal zero-width substitution. Structurally absent units
remain insensitive controls;no nonzero response is invented.

The original primary reached120seconds after deriving the unit factors but
before completing the color tensor. It has no accepted result. Its full
source/preparation/capture remain unchanged. V2 replaces repeated full
external-momentum expansions with exact first-jet product-rule algebra.
Every required one-jet component is preserved,without a resource increase.
Corrected primary completed in15.420947seconds after imports. Captures and
receipt own replay/validator runtime,peaks and any failures. Limits remain
120seconds,8GiB sampled private and350MiB minimum available commit. No
fresh byte-identical replay pair is claimed.

Track B records both an avoidable full-expansion resource failure and a
successful structural correction. Validation shares exact-field arithmetic
with primary;replay uses ordinary SymPy and the Casimir reduction. The
Schur/Gram and Kronecker checks supply distinct mathematical corroboration,
but all methods share the action,reference,charts,IBP/support assumptions,
software and AI author. They do not independently validate those physical
premises or replace expert review.

NEXT:actual FFG3/FFU two-probe kernels,retaining the two ordinary BB lines
or mixed orientations,ordered widths and complete graded factors. Reuse
the exact first-jet reduction and universal matrix/Lorentz structure before
component contraction. Do not fit a coefficient from a desired Ward zero.
After complete family coverage,combine poles,qualify canonical extraction/
exact-once integration and then test the complete selected ghost relation.

No node is inserted into Gamma here. Current147266/hashc445c2...,38-source,
auxiliary-H and bilinear scopes remain. Full ghost/source-freeSlavnov,
E5/A5,QAP,regulated Jacobian/measure,32products,128sourcejets,508programs,
finite contacts/Legendre,IR/Legacy and physical viability are unqualified.
Keep34/39,HB1/C5block,flavorpause,C1_GS,quartet/scalar warnings,closedroutes
and custodyexit2/seven. No input,scheme,benchmark,foundation,policy,
authority or remoteaction. Educationnonblocking;Leanselective.
