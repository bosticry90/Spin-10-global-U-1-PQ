"""Full FFF triangle: finite graded normalization, both UV probes, actual color."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product,permutations
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,canonical
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
f=load('qualified_DF_exact_field',Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-companion-DF-v1-2026-10-17/verify.py'))
E=(1,-1,-1,-1);k=list(s.symbols('fff_k0:4',real=True));r=list(s.symbols('fff_r0:4',real=True));q=list(s.symbols('fff_q0:4',real=True));K,L,M,W=s.symbols('fff_K fff_L fff_M fff_W',nonzero=True);WH,WM=s.symbols('reference_width_H reference_width_M',real=True);ZERO={z:0 for z in r+q}
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def num(z):return s.sympify(z,locals={str(v):v for v in [K,L,M,W,WH,WM,*k,*r,*q]})
def clean(z):return s.expand(z)
def matrix(rows):return s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in rows})
def finite_triangle(role):
    w=alphabet();w.fields={'fbL':(1,0,0),'fbR':(1,0,0),'fc1':(1,1,1),'fa1':(1,-1,1),'fc2':(1,1,1),'fa2':(1,-1,1)};w.grades=w.fields;w.external={};w.pairs=[];w.p={n:g[2] for n,g in w.fields.items()}
    for n,t in [('fae',(1,-1,1)),('fce',(1,1,1)),('fVe',(1,0,0))]:register(w,n,t)
    v=w.var;A=w.mul(v('fae'),v('fbL'),v('fc1'));B=w.mul(v('fa1'),v('fVe'),v('fc2'));C=w.mul(v('fa2'),v('fbR'),v('fce'));target=w.mul(v('fae'),v('fVe'),v('fce'));word,sign=next(iter(target.items()));gb,pl,pm=s.symbols('finite_GB finite_PL finite_PM',nonzero=True)
    green={('fbL','fbR'):gb,('fbR','fbL'):gb,('fc1','fa1'):1/pl,('fa1','fc1'):-1/pl,('fc2','fa2'):1/pm,('fa2','fc2'):-1/pm};orders=[]
    if role=='primary':
        names=list(w.fields);par=[w.p[n] for n in names];G={(i,j):{():z} for i,n in enumerate(names) for j,m in enumerate(names) if (z:=green.get((n,m),0))};H=[]
        for P in [A,B,C]:
            V=Fourier_vertex(P,w,'primary',k,k,{});H.append({(i,j):cell for i,row in enumerate(V) for j,cell in enumerate(row) if cell})
        for perm in permutations(range(3)):
            P=G
            for i in perm:P=multiply(P,H[i],w);P=multiply(P,G,w) if i!=perm[-1] else P
            z=s.cancel(s.I*trace(P,w,par).get(word,0)/(6*sign));orders.append(z)
    else:
        ext={'fae','fce','fVe'}
        def pair(inside):
            if not inside:return s.S.One
            a=inside[0];out=0
            for i,b in enumerate(inside[1:],1):
                g=green.get((a,b),0)
                if g:out+=(-1)**(w.p[a]*sum(w.p[n] for n in inside[1:i]))*s.I*g*pair(inside[1:i]+inside[i+1:])
            return out
        for perm in permutations([A,B,C]):
            result=0
            for wa,a in perm[0].items():
                for wb,b in perm[1].items():
                    for wc,c in perm[2].items():
                        full=wa+wb+wc;outer=[n for n,j in full if n in ext];inside=[n for n,j in full if n not in ext];cross=(-1)**sum(w.p[n]*w.p[m] for i,(n,j) in enumerate(full) if n not in ext for m,jj in full[i+1:] if m in ext);sg=w.mul(*(v(n) for n in outer)).get(word,0)/sign;result+=a*b*c*cross*sg*pair(inside)
            orders.append(s.cancel((-s.I)*s.I**3*result/6))
    total=s.cancel(sum(orders));assert total!=0 and len(orders)==6;factor=s.cancel(total/(s.I*gb/(pl*pm)));assert not factor.free_symbols
    # Independent finite Schur expression in nilpotent even epsilon=a_ext*C_ext.
    eps,V,P0=s.symbols('finite_eps finite_V finite_P0');J=s.Matrix([[pl,V],[0,pm]]).inv();effective=P0-2*eps*J[0,1];schur=s.diff(s.I*s.log(effective)/2,eps,V).subs({eps:0,V:0,P0:1/gb});assert s.simplify(total-schur)==0
    return factor,{'six_order_coefficients':list(map(str,orders)),'full_coefficient':str(total),'finite_ghost_Schur_result':str(s.simplify(schur)),'no_regularized_functional_trace_cyclicity_used':True}
def routing():
    vL=[a+b-c for a,b,c in zip(r,q,k)];aR=[a-b for a,b in zip(k,q)];aM=[a-b-c for a,b,c in zip(k,r,q)];cM=[a-b for a,b in zip(q,k)];ae=[-a-b for a,b in zip(r,q)]
    assert all(clean(sum(v[mu] for v in row))==0 for row in [[ae,k,vL],[aR,[-v for v in k],q],[aM,r,cM]] for mu in range(4)) and all(clean(a+b)==0 for a,b in zip(vL,aM)) and all(clean(a+b)==0 for a,b in zip(aR,cM))
def dot(a,b):return sum(E[i]*a[i]*b[i] for i in range(4))
def kernel(tag,rho):
    left=[-a-b for a,b in zip(r,q)] if tag[0]=='a' else [a+b-c for a,b,c in zip(r,q,k)];middle=[a-b-c for a,b,c in zip(k,r,q)] if tag[1]=='a' else [a-b for a,b in zip(q,k)];right=[a-b for a,b in zip(k,q)] if tag[2]=='a' else q
    return s.expand(E[rho]*middle[rho]*(-dot(left,right)/K+(1-W)*dot(left,k)*dot(right,k)/K**2)/(L*M))
def average(P,wrong=False):
    if P==0:return s.S.Zero
    result=0
    for term in s.Add.make_args(s.expand(P)):
        d=term.as_powers_dict();ns=[int(d.get(v,0)) for v in k];a=int(d.get(K,0));assert sum(ns)+2*a==-4
        if any(n%2 for n in ns):continue
        weight=s.S.One
        for j in range(sum(ns)//2):weight/=4+2*j
        for mu,n in enumerate(ns):weight*=s.factorial2(n-1) if n else 1;weight*=1 if wrong else E[mu]**(n//2)
        result+=term/s.prod(v**n for v,n in zip(k,ns))/K**a*weight
    return s.expand(2*s.I*result)
def taylor(P,nu,probe,wrong=False):
    if probe=='r':d=s.diff(P,r[nu])-2*E[nu]*(k[nu]-r[nu]-q[nu])*s.diff(P,L)
    else:d=s.diff(P,q[nu])-2*E[nu]*(k[nu]-r[nu]-q[nu])*s.diff(P,L)-2*E[nu]*(k[nu]-q[nu])*s.diff(P,M)
    return average(s.expand(d.subs(ZERO).subs({L:K,M:K})),wrong)
def parameter(P,nu,probe):
    x,y=s.symbols('fff_x fff_y',real=True);groups=defaultdict(lambda:s.S.Zero)
    for term in s.Add.make_args(P):
        d=term.as_powers_dict();a=-int(d.get(K,0));assert a in [1,2] and d.get(L,0)==d.get(M,0)==-1;groups[a]+=term*K**a*L*M
    total=0
    for a,N in groups.items():
        shifted=s.expand(N.subs({k[i]:k[i]+y*r[i]+(1-x)*q[i] for i in range(4)},simultaneous=True));P=s.expand(s.diff(shifted,(r if probe=='r' else q)[nu]).subs(ZERO)/K**(a+2));val=average(P);poly=s.Poly(s.expand(a*(a+1)*x**(a-1)*val),x,y)
        total+=sum(c*s.factorial(i)*s.factorial(j)/s.factorial(i+j+2) for (i,j),c in poly.terms())
    return s.expand(total)
def units(role):
    method=taylor if role=='primary' else parameter;out={};controls={}
    for bits in product('ac',repeat=3):
        tag=''.join(bits);rows={probe:[] for probe in ['r','q']};wrong=False
        for rho in range(4):
            P=kernel(tag,rho)
            for probe in rows:
                for nu in range(4):rows[probe].append([rho,nu,str(s.factor(method(P,nu,probe)/(s.I*E[rho])))])
                wrong|=s.expand(taylor(P,rho,probe,True)/(s.I*E[rho])-num(rows[probe][-4+rho][2]))!=0
        for probe,v in rows.items():
            base=num(v[0][2]);assert all(clean(num(z)-base*int(rho==nu))==0 for rho,nu,z in v)
        out[tag]={'r':rows['r'][0][2],'q':rows['q'][0][2],'all32_probe_components':rows,'external_jet_two_structural_zero':tag[0]=='a' and tag[2]=='c'}
        if tag[0]=='a' and tag[2]=='c':assert num(out[tag]['r'])==num(out[tag]['q'])==0
        controls[tag]={'wrong_angular_metric_changes_at_least_one_component':bool(wrong),'nonzero_onejet_unit':bool(num(out[tag]['r']) or num(out[tag]['q']))}
    return out,controls
def literal_F(rows):
    copies=[]
    for mu in range(4):
        arrays={key:defaultdict(lambda:s.S.Zero) for key in ['a','c','v']}
        for row in rows:
            decoded=[(n.partition('__')[0],tuple(map(int,n.partition('__')[2].split('_'))) if '__' in n else ()) for n in row['word']];V=[v for v in decoded if v[0].startswith(('Ap','Bp'))];aa=[v for v in decoded if v[0].startswith('ap')];CC=[v for v in decoded if v[0].startswith('Cp')]
            if len(decoded)!=3 or len(V)!=len(aa) or len(V)!=len(CC) or len(V)!=1:continue
            vn,vj=V[0];an,aj=aa[0];cn,cj=CC[0]
            if not vn.endswith('_'+str(mu)):continue
            assert tuple(j for n,js in decoded for j in js)==(mu,);index=int(vn[2:].split('_')[0])+(12 if vn.startswith('Bp') else 0);key=(index,int(an[2:]),int(cn[2:]));arrays['a' if aj else 'c' if cj else 'v'][key]+=-num(row['coefficient'])/E[mu]
        for key,z in arrays['v'].items():arrays['a'][key]-=z;arrays['c'][key]-=z
        copies.append({kind:{key:clean(z) for key,z in arrays[kind].items() if clean(z)!=0} for kind in 'ac'})
    assert all(v==copies[0] for v in copies);return copies[0]
def exact_bases(F,U):
    left={};right={}
    for kind in 'ac':
        a=defaultdict(list);b=defaultdict(list)
        for (v,i,j),z in F[kind].items():
            if v<12:continue
            zz=f.field(str(z));a[v-12,j].append((i,zz));b[v-12,i].append((j,zz))
        left[kind]=a;right[kind]=b
    result={tag:{sector:{} for sector in ['H','M']} for tag in U}
    for tag in U:
        if num(U[tag]['r'])==num(U[tag]['q'])==0:continue
        for (v,i,j),z in F[tag[1]].items():
            zz=f.field(str(z))
            for b in range(45):
                dst=result[tag]['H' if b<12 else 'M']
                for a,x in left[tag[0]].get((b,i),[]):
                    first=f.mul(x,zz)
                    for C,y in right[tag[2]].get((b,j),[]):f.accumulate(dst,(v,a,C),f.mul(first,y))
    return result
def sympy_bases(F,U,adj):
    PH=s.diag(*([1]*12+[0]*33));PM=s.eye(45)-PH;I=s.eye(45);mats={kind:[s.SparseMatrix(45,45,{(i,j):z for (V,i,j),z in F[kind].items() if V==v}) for v in range(57)] for kind in 'ac'}
    for v in range(57):
        if v<12:a=s.zeros(45);c=-PH*adj[v]*PH
        elif v-12<12:a=adj[v-12];c=-PM*adj[v-12]*PM
        else:a=adj[v-12]*PM;c=s.zeros(45)
        assert s.simplify(mats['a'][v]-a)==s.simplify(mats['c'][v]-c)==s.zeros(45)
    assert all(adj[h]*PH-PH*adj[h]==s.zeros(45) for h in range(12));CH=sum((adj[h]*adj[h] for h in range(12)),s.zeros(45));result={tag:{sector:{} for sector in ['H','M']} for tag in U};cache={}
    for tag in U:
        if num(U[tag]['r'])==num(U[tag]['q'])==0:continue
        pl=PM if tag[0]=='c' else I;pr=PM if tag[2]=='c' else I;sign=(-1)**(int(tag[0]=='c')+int(tag[2]=='c'))
        for v,A in enumerate(mats[tag[1]]):
            if not any(A):continue
            key=(tag[1],v)
            if key not in cache:
                c=v if v<12 else v-12;off=0 if v<12 else 12;weighted=sum((CH[u,c]*mats[tag[1]][u+off] for u in range(12 if off==0 else 45) if CH[u,c]),s.zeros(45));H=(CH*A+A*CH-weighted)/2
                # Actual projector forms and inherited adjoint Jacobi give the H covariance premise.
                Msum=sum((mats['a'][b+12]*A*mats['a'][b+12] for b in range(12,45)),s.zeros(45));cache[key]=(H,Msum)
            HH,MM=cache[key];H=s.simplify(sign*pl*HH*pr);B=MM if tag[0]==tag[2]=='a' else s.zeros(45)
            for sector,A in [('H',H),('M',B)]:
                for (i,j),z in A.todok().items():
                    z=clean(z)
                    if z:result[tag][sector][v,i,j]=f.field(str(z))
    return result
def unpack_field(z):return sum(s.Rational(v.numerator,v.denominator)*WH**a*WM**b*s.sqrt(f.rad[m]) for (a,b,m),v in z)
def pack(P):return [[v,a,C,str(clean(unpack_field(z)))] for (v,a,C),z in sorted(P.items()) if z]
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('FFF_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('FFF_PEER_OR_UNDECLARED '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' finite_graded_triangle_and_complete_two_probe_units',flush=True);routing();factor,G=finite_triangle(role);assert factor==1;U,controls=units(role);print('UNITS '+json.dumps({tag:{key:row[key] for key in ['r','q']} for tag,row in U.items()},sort_keys=True),flush=True)
    ex=read(Path(prep['pure_classical_export']));F=literal_F(ex['vertices']['F_ghost_and_auxiliary']);cp=ROOT/'calculations/canonical_so10_gauge_source_g2_color'/(role+'_result.json');cr=read(cp.parent/'validation_receipt.json');assert cr['input_sha256'][str(cp)]==digest(cp);col=read(cp)
    for kind,label in [('a','Fa_tensors'),('c','Fc_tensors')]:assert {(v-12,i,j):z for (v,i,j),z in F[kind].items() if v>=12}=={(b,i,j):num(z) for b,rows in enumerate(col[label]) for i,j,z in rows}
    op=ROOT/'calculations/canonical_so10_constant_background_operators'/(role+'_result.json');rr=read(op.parent/'validation_receipt.json');assert rr['input_sha256'][str(op)]==digest(op);old=read(op);principal={(v,i,j):clean(F['c'].get((v,i,j),0)-F['a'].get((v,i,j),0)) for v in range(57) for i,j in {(a,b) for (V,a,b) in set(F['a'])|set(F['c']) if V==v}};principal={key:z for key,z in principal.items() if z};assert principal=={(v,i,j):num(z) for v,rows in old['P1_over_i_qrho'] for i,j,z in rows}
    print('STAGE '+role+' complete_actual_H_M_color_bases_and_all_coefficients',flush=True);bases=exact_bases(F,U) if role=='primary' else sympy_bases(F,U,list(map(matrix,ex['all45_physical_adjoint_matrices'])));Rs={};Qs={}
    for tag,regions in bases.items():
        for region,B in regions.items():
            for target,probe in [(Rs,'r'),(Qs,'q')]:
                weight=f.field(str(num(U[tag][probe]).subs(W,WH if region=='H' else WM)))
                for key,z in B.items():f.accumulate(target,key,f.mul(weight,z))
    R,Q=pack(Rs),pack(Qs);encoded={tag:{region:pack(B) for region,B in regions.items()} for tag,regions in bases.items()};assert all(not num(z).has(s.Float) and s.simplify(num(z)-s.conjugate(num(z)))==0 for rows in [R,Q] for v,a,C,z in rows)
    dp=ROOT/'calculations/canonical_so10_ghost_companion_kernel_domain'/(role+'_v2_result.json');rec=read(dp.parent/'validation_receipt.json');assert rec['input_sha256'][str(dp)]==digest(dp);dom=read(dp);coverage={target:next(row for row in dom['targets'][target]['family_summary'] if row['family']==['F','F','F']) for target in ['A','B']};assert coverage['A']['cycles']==8 and coverage['B']['cycles']==104
    result={'schema':'ACTUAL_COMPLETE_FFF_GHOST_TRIANGLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_FFF_FAMILY_ONLY','finite_Gaussian':G,'units':U,'unit_controls':controls,'unweighted_H_M_color_bases':encoded,'physical_divergence_vector_aC':R,'physical_vector_a_derivative_C':Q,'full_positions_per_placement':115425,'divergence_zero_complement':115425-len(R),'ghost_derivative_zero_complement':115425-len(Q),'all57_literal_F_IBP_and_principal_P1_checked':True,'coverage':coverage,'all256_two_probe_Lorentz_positions_checked':True,'two_external_jet_units_zero_at_onejet_only':True,'actual_Gamma_primitive_desired_Ward_or_peer_read':False,'functional_or_authority_change':False,'full_ghost_Ward_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) [ (partial V_v) a R[v] C + V_v a Q[v] partial C ]; v=0..11 A_H,12..56 B; modulo qualified F IBP currents,no extra ghost1/2','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
