"""Complete DG3/DU UV kernels and literal/independently indexed color tensors."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product,permutations
from functools import lru_cache
import json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
E=(1,-1,-1,-1);k=list(s.symbols('db_k0:4',real=True));r=list(s.symbols('db_r0:4',real=True));K,L,Wi,Wj=s.symbols('db_K db_L db_Wi db_Wj',nonzero=True);WH,WM=s.symbols('reference_width_H reference_width_M',real=True);ZERO={p:0 for p in r}
def clean(z):return s.expand(z)
def matrix(rows):return s.SparseMatrix(45,45,{(i,j):s.sympify(z) for i,j,z in rows})
def sym(z):return s.sympify(z,locals={str(v):v for v in [Wi,Wj,WH,WM]})
def G(q,Q,W):return s.Matrix(4,4,lambda a,b:-E[a]*int(a==b)/Q+(1-W)*q[a]*q[b]/Q**2)
def H(rho):return s.Matrix(4,4,lambda a,b:s.I*(E[rho]*(2*k[rho]-r[rho])*E[a]*int(a==b)-E[a]*(k[a]-2*r[a])*E[b]*int(b==rho)-E[a]*int(a==rho)*E[b]*(k[b]+r[b])))
def YM_from_action():
    # Six color assignments of -1/2*(dB-dB)*f*B*B in the actual -F^2/4 action.
    momenta={0:[-v for v in k],1:r,2:[a-b for a,b in zip(k,r)]}
    for a,b,rho in product(range(4),repeat=3):
        components={0:a,1:rho,2:b};value=0
        for colors in permutations(range(3)):
            x,y,z=colors;f=(-1)**sum(i>j for p,i in enumerate(colors) for j in colors[p+1:]);A,B,C=map(components.get,colors);value+=-s.I*s.Rational(1,2)*f*(int(A==C)*E[B]*E[A]*momenta[x][B]-int(A==B)*E[A]*E[C]*momenta[x][C])
        assert clean(value-H(rho)[a,b])==0,(a,b,rho)
    return True
def Gaussian():
    a,b=s.symbols('db_a db_b');Q=s.diag(2,3);D=s.Matrix([[2,1],[1,4]]);U=s.Matrix([[1,3],[3,-2]]);J=Q.inv();cross=-s.I*(s.trace(J*D*J*U)+s.trace(J*U*J*D))/4
    det=(Q+a*D+b*U).det();literal=s.series(s.I*s.log(det)/2,a,0,2).removeO();literal=s.series(literal,b,0,2).removeO().expand().coeff(a).coeff(b);assert s.simplify(cross-literal)==0 and cross!=0 and cross/2!=cross
    return {'real_boson_i_over2_logdet_cross_equals_two_Born_words':True,'minus_i_over2_times_radial2i_equals1':(-s.I/2)*(2*s.I)==1,'no_rooted_cycle_count_used_as_weight':True}
def avg(P,wrong=False):
    if P==0:return s.S.Zero
    result=0
    for term in s.Add.make_args(s.expand(P)):
        powers=term.as_powers_dict();ns=[int(powers.get(q,0)) for q in k];rad=int(powers.get(K,0));assert sum(ns)+2*rad==-4,(term,ns,rad)
        if any(n%2 for n in ns):continue
        n=sum(ns)//2;weight=s.S.One
        for j in range(n):weight/=4+2*j
        for a,v in enumerate(ns):weight*=s.factorial2(v-1) if v else 1;weight*=1 if wrong else E[a]**(v//2)
        result+=term/s.prod(q**v for q,v in zip(k,ns))/K**rad*weight
    return s.expand(result)
def integrands(rho,role):
    v=[a-b for a,b in zip(k,r)];Gi=G(k,K,Wi);Gj=G(v,L,Wj);HM=H(rho)
    if role=='primary':p=sum(E[mu]*Gi[mu,a]*HM[a,b]*Gj[b,mu] for mu,a,b in product(range(4),repeat=3))
    else:p=s.trace(s.diag(*E)*Gi*HM*Gj)
    u1=E[rho]*sum(E[mu]*s.I*k[mu]/K*Gj[rho,mu] for mu in range(4));u2=-E[rho]*sum(E[mu]*G(k,K,Wj)[mu,rho]*s.I*v[mu]/L for mu in range(4))
    return {'DG3':s.expand(p),'DU':s.expand(u1+u2),'DU_BL':s.expand(u1),'DU_LB':s.expand(u2)}
def taylor(P,nu,wrong=False):
    d=s.diff(P,r[nu])-2*E[nu]*(k[nu]-r[nu])*s.diff(P,L);return avg(s.expand(d.subs(ZERO).subs(L,K)),wrong)
def parameter(P,nu):
    t=s.Symbol('db_t',real=True);groups=defaultdict(lambda:s.S.Zero)
    for term in s.Add.make_args(P):
        d=term.as_powers_dict();a=-int(d.get(K,0));b=-int(d.get(L,0));assert a>=1 and b>=1;groups[a,b]+=term*K**a*L**b
    total=0
    for (a,b),N in groups.items():
        shifted=s.expand(N.subs({k[i]:k[i]+(1-t)*r[i] for i in range(4)},simultaneous=True));linear=s.expand(s.diff(shifted,r[nu]).subs(ZERO)/K**(a+b));moment=avg(linear);weight=s.factorial(a+b-1)/s.factorial(a-1)/s.factorial(b-1)*t**(a-1)*(1-t)**(b-1);P=s.Poly(s.expand(moment*weight),t);total+=sum(c/s.Integer(n[0]+1) for n,c in P.terms())
    return s.expand(total)
def unit_kernels(role):
    units=defaultdict(list);wrong={};method=taylor if role=='primary' else parameter
    for rho in range(4):
        ps=integrands(rho,role)
        for family,P in ((name,ps[name]) for name in ['DG3','DU']):
            for nu in range(4):
                z=s.factor(method(P,nu)/(s.I*E[rho]));assert z==0 if nu!=rho else True;units[family].append([rho,nu,str(z)])
            if rho==0:wrong[family]=str(s.factor(taylor(P,0,True)/s.I))
        if rho==0:
            for family in ['DU_BL','DU_LB']:wrong[family]=str(s.factor(method(ps[family],0)/s.I))
    for family,rows in units.items():
        base=sym(rows[0][2]);assert all(clean(sym(z)-base*int(rho==nu))==0 for rho,nu,z in rows)
    eps,m=s.symbols('db_eps db_IR_squared',positive=True);assert s.limit(eps*s.gamma(eps)*m**(-eps),eps,0)==1
    return dict(units),wrong
def literal_D(rows):
    out=defaultdict(lambda:s.S.Zero);count=0
    for row in rows:
        word=row['word'];bs=[n for n in word if n.startswith('Bp')]
        if len(bs)!=2 or any(not n.endswith('_0') for n in bs) or any(n.startswith('Ap') for n in word):continue
        a=next(n for n in word if n.startswith('ap'));C=next(n for n in word if n.startswith('Cp'));i,j=[int(n[2:].split('_')[0]) for n in bs];aa,cc=int(a[2:]),int(C[2:]);z=-s.sympify(row['coefficient']);count+=1
        # Literal canonical ordering has C before a; its ordered a*C sign is minus.
        if i==j:out[i,j,aa,cc]+=2*z
        else:out[i,j,aa,cc]+=z;out[j,i,aa,cc]+=z
    return {key:clean(z) for key,z in out.items() if clean(z)!=0},count
def indexed_D(P2):
    out={}
    for (a,b),rows in P2:
        if a<12 or b<12:continue
        i,j=a-12,b-12
        for aa,cc,value in rows:
            z=s.sympify(value);out[i,j,aa,cc]=(2 if i==j else 1)*z
            if i!=j:out[j,i,aa,cc]=z
    return out
def literal_N(rows):
    out=defaultdict(lambda:s.S.Zero)
    for row in rows:
        ns=row['word'];L=[n for n in ns if n.startswith('Lp')]
        if not L:continue
        vs=[n for n in ns if n.startswith(('Ap','Bp'))]
        if len(L)!=1 or len(vs)!=2 or not all(n.endswith('_0') for n in vs):continue
        for e,V in enumerate(vs):
            other=vs[1-e]
            if not other.startswith('Bp'):continue
            key=(int(V[2:].split('_')[0])+(12 if V.startswith('Bp') else 0),int(L[0][2:]),int(other[2:].split('_')[0]));out[key]+=s.sympify(row['coefficient'])
    return {key:clean(z) for key,z in out.items() if clean(z)!=0}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('D_BUBBLE_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('D_BUBBLE_PEER_OR_UNDECLARED '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' real_Gaussian_YM_action_and_all_two_probe_units',flush=True);gauss=Gaussian();YM=YM_from_action();units,wrong=unit_kernels(role);print('UNITS '+json.dumps(units,sort_keys=True,separators=(',',':')),flush=True)
    ex=read(Path(prep['pure_classical_export']));p=ROOT/'calculations/canonical_so10_constant_background_operators'/(role+'_result.json');receipt=read(p.parent/'validation_receipt.json');assert receipt['input_sha256'][str(p)]==digest(p);old=read(p);F=list(map(matrix,ex['all45_physical_adjoint_matrices']));D,count=literal_D(ex['vertices']['D_vectorpair_ghost']);Nd=literal_N(ex['vertices']['F_ghost_and_auxiliary']);Dr=indexed_D(old['P2']);Nr={(b,i,j):s.sympify(z) for b,rows in old['N1'] for i,j,z in rows};assert D==Dr and Nd==Nr
    assert len(ex['physical_YM_AST']['density']['expression']['expression']['factors'])==3
    if role=='replay':D,Nd=Dr,Nr
    print('STAGE '+role+' full_actual_DG3_DU_color_and_zero_complements',flush=True);zi=defaultdict(lambda:s.S.Zero);zu=defaultdict(lambda:s.S.Zero);Dby=defaultdict(list)
    for (i,j,a,C),z in D.items():Dby[i,j].append((a,C,z))
    jG=sym(units['DG3'][0][2]);jU=sym(units['DU'][0][2])
    for b in range(45):
        for (i,j),f in F[b].todok().items():
            w=jG.subs({Wi:WH if i<12 else WM,Wj:WH if j<12 else WM})
            if w:
                for a,C,z in Dby[j,i]:zi[b,a,C]+=w*f*z
    for (b,i,j),n in Nd.items():
        w=jU.subs({Wi:WH if i<12 else WM,Wj:WH if j<12 else WM})
        for a,C,z in Dby[j,i]:zu[b,a,C]+=w*n*z
    def packed(Z):return [[b,a,C,str(clean(z))] for (b,a,C),z in sorted(Z.items()) if clean(z)!=0]
    zG=packed(zi);zU=packed(zu);combined=defaultdict(lambda:s.S.Zero)
    for b,a,C,z in zG:combined[b+12,a,C]+=sym(z)
    for b,a,C,z in zU:combined[b,a,C]+=sym(z)
    total=packed(combined);assert all(not sym(z).has(s.Float) and s.simplify(sym(z)-s.conjugate(sym(z)))==0 for row in [zG,zU,total] for b,a,C,z in row)
    p=ROOT/'calculations/canonical_so10_ghost_companion_kernel_domain'/(role+'_v2_result.json');rr=read(p.parent/'validation_receipt.json');assert rr['input_sha256'][str(p)]==digest(p);dom=read(p);coverage={}
    for target in ['A','B']:
        for fam in [('D','G3'),('D','U')]:
            rows=[x for x in dom['targets'][target]['family_summary'] if x['family']==list(fam)];coverage[target+''.join(fam)]=rows[0] if rows else {'cycles':0,'profiles':0}
    assert coverage['BDG3']['cycles']==24 and coverage['BDU']['cycles']==4 and coverage['ADU']['cycles']==2 and coverage['ADG3']['cycles']==0
    diag_sensitive=any(F[b][i,i] for b in range(45) for i in range(45)) or any(n for (b,i,j),n in Nd.items() if i==j)
    controls={'DG3_omission_changes_sum':bool(zG),'DU_omission_changes_sum':bool(zU),'half_Gaussian_factor_changes_nonzero_sum':bool(total),'wrong_angular_metric_changes_DG3_unit':clean(sym(wrong['DG3'])-jG)!=0,'wrong_angular_metric_changes_DU_unit':clean(sym(wrong['DU'])-jU)!=0,'longitudinal_piece_omission_changes_universal_DG3':clean(jG-jG.subs({Wi:1,Wj:1}))!=0,'longitudinal_piece_omission_changes_universal_DU':clean(jU-jU.subs(Wj,1))!=0,'omit_one_mixed_orientation_changes_DU_unit':all(clean(jU-sym(wrong[name]))!=0 for name in ['DU_BL','DU_LB']),'separate_mixed_orientation_units':{name:wrong[name] for name in ['DU_BL','DU_LB']},'identical_B_Hessian_slots':sum(i==j for i,j,a,C in D),'identical_B_factor_control_sensitive_actual_tensor':bool(diag_sensitive),'diagonal_D_slots_have_zero_actual_F_N_multipliers':not diag_sensitive}
    result={'schema':'ACTUAL_DG3_DU_GHOST_COMPANION_POLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_DG3_DU_FAMILIES_ONLY','unit_components':units,'rzero_probe_all16_zero_both_families':True,'Gaussian_checks':gauss,'all64_YM_vertex_slots_reconstructed_from_action':YM,'physical_DG3_B_divergence_aC':zG,'physical_DU_A_and_B_divergence_aC':zU,'physical_combined_A_and_B_divergence_aC':total,'all_V_a_derivative_C_positions_zero':57*45**2,'full_divergence_positions':57*45**2,'zero_combined_divergence_complement':57*45**2-len(total),'D_literal_temporal_terms':count,'D_BB_Hessian_positions':len(D),'U_mixed_Hessian_positions':len(Nd),'literal_D_N_equals_full_independently_qualified_P2_N1':True,'coverage':coverage,'controls':controls,'widths_kept_symbolic_no_affine_assumption':True,'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) * partial_mu V_b^mu a_j Z[b,j,l] C_l; b=0..11 A_H,b=12..56 B; D=literal_BB_Hessian,no extra Bose1/2','not_full_ghost_pole_or_Ward_or_E5_A5':True,'no_insertion_or_authority_change':True,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
