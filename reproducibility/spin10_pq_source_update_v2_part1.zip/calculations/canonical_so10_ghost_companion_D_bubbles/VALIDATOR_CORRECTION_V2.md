# Exact polynomial equality for the mixed-orientation check

The original independent verifier completed the primary full classical
Lorentz-copy checks, coefficient tensors and H-covariance checks, then
failed its final mixed-orientation list comparison. It compared SymPy
expression-tree equality: the saved (Wj-3)/4 reconstructed as Wj/4-3/4,
whereas the Gram proof returned a factored tree. Both exact polynomial
differences are zero with the same nonzero Wj symbol.

V2 replaces this structural comparison with exact expanded differences,
retaining both orientations and every mathematical check for both roles.
It reruns under the same120-second/8GiB limits. Preserve the failed source,
preparation and full capture. No worker result, coefficient, physical
assumption, normalization or scientific criterion changes. The accepted
receipt must disclose one failed verifier and zero failed native workers.
