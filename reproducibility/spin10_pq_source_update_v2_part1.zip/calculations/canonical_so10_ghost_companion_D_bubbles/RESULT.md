# Two more complete ghost-companion loop families

Prospective until both native results/captures, the independent receipt and
committed-byte checks qualify. Baseline277c30ec4c98ca4260da4e8831d2cd29ddaa8ff8.

The complete DG3 and DU families give nonzero ordinaryg3 one-jet ghost
companion poles. Both external ghosts attach to the same D quartic; the
other vertex is the Yang-Mills three-vector interaction or the auxiliary/
two-vector interaction. These are measured family contributions, not the
full ghost pole or a fitted Ward completion.

| Family and target | Profiles | Directed rooted support cycles |
| --- | ---: | ---: |
| DG3, BaC | 12 | 24 |
| DU, AaC | 1 | 2 |
| DU, BaC | 2 | 4 |
| Total | 15 | 30 |

The rooted support counts do not supply Gaussian, Wick or Bose factors.
The real-boson i/2 logdet gives the two ordered cross terms with coefficient
-i/4 each. The independently checked radial multiplier2i leaves one times
the homogeneous trace. D is the literal second B derivative, including the
factor2 for identical B fields. U is its actual mixed Lambda/B Hessian.

For ordered internal color lines i,j with reference widths W_i,W_j, the
complete unit coefficients multiplying the divergence of the external
vector are

    DG3: 3*(W_j-W_i)/4
    DU:  (W_j-3)/2.

These formulas follow from all16 vector/momentum Taylor positions, including
four-dimensional longitudinal/transverse contractions. Replay combines the
two denominators with shifted Feynman parameters. The independent check
uses metric/rank-one Gram contractions and reconstructs the three-vector
vertex directly from the actual -F^2/4 curvature. All64 vertex slots agree.
The two mixed-propagator orientations each give (W_j-3)/4. Dropping either
would halve DU. No width is chosen or set equal in the actual result.
DG3 has two BB propagators, but its width-quadratic terms cancel in this
particular kernel; no such cancellation is assumed for other families.

Define D[j,i,a,C] by the complete literal quantum-B Hessian and N[V,i,j]
by the actual Lambda/B mixed Hessian, with V=0..11 for A_H and12..56 for B.
The physical coefficients are

    Z_DG3[B_b,a,C] = sum_ij F_b[i,j]*D[j,i,a,C]*3*(W_j-W_i)/4
    Z_DU[V,a,C]   = sum_ij N[V,i,j]*D[j,i,a,C]*(W_j-3)/2.

The color calculation compares all25902 D Hessian coefficients, from13254
temporal literal density terms, with the independently qualified full P2.
All740 mixed-U coefficients agree with the full N1. Independent validation
also checks all four literal Lorentz copies and all12 H-covariance relations
for the complete coefficient tensors. No diagnostic field value replaces
these full comparisons.

Each family has776 nonzero physical divergence-vector coefficients. Their
sum also has776. Over the full57*45*45=115425-position A_H/B tensor, the
combined zero complement is114649. The coefficients of the independent
V*a*(partial C) placement vanish at all115425 positions for both families.
The nonzero sum has only external B support; the allowed DU/A_H profiles
cancel in the actual color contraction. The complete physical tables retain
both symbolic reference widths and exact roots/rationals, with no floats.

The external ghosts at D have total momentum -r, where r is the vector
momentum. There is no separate q dependence. Both formal probes are
accounted for: r=0 yields zero, while q=0 determines the divergence-vector
coefficient. This is a UV/Taylor statement on a positive UV annulus or with
a separate auxiliary IR mass, not a whole scaleless or finite/IR amplitude.

Controls detect removing either family, halving the Gaussian factor,
omitting a mixed orientation, dropping longitudinal pieces or replacing
the Lorentz angular metric. The606 identical-B Hessian slots are retained,
but their actual F/N diagonal multipliers vanish. Consequently dropping
their factor2 is an insensitive control for this particular pole. A generic
quadratic derivative/Gaussian check establishes that factor instead; the
report does not invent sensitivity in the actual tensor.

Primary completed in24.803705seconds after imports. Replay and validation
captures own all actual timings/peaks and any failures. Limits are120seconds
after imports,8GiB sampled private memory and350MiB minimum available commit.
No fresh byte-identical replay pair is claimed. Qualified older P2/N1,
reference and classical action evidence is authenticated, not recomputed as
an independent expert physics assessment.

Track B demonstrates a compact full-family reduction: explicit Taylor,
shifted parameter and Gram methods avoid a whole-functional expansion.
Shared action, catalogue, kinetic/chart proofs, exported classical data,
software and AI author remain shared-error limits. The new full color and
covariance checks do not validate those shared physical premises.

NEXT: derive the actual two-probe mixed ghost/vector kernels for DF, FFF,
FFG3 and FFU. Those four families remain unmeasured. Their graded weights
must be derived from the Hessian or explicit connected contractions, not
from the rooted support counts. Retain differentiated-vector F terms or
their qualified boundary-current bridge, both widths, mixed orientations
and the full4D loop. Do not transfer DG3/DU or FR cancellations into them.
After complete family coverage, combine the measured poles, qualify the
canonical extraction/exact-once integration and then test the complete
selected ghost Ward relation without choosing coefficients to cancel it.

No contribution is inserted into Gamma here. Current147266/hashc445c2...
and the qualified38-source/auxiliary-H/bilinear scopes remain unchanged.
The full ghost/source-free Slavnov identity,E5/A5,QAP,regulated Jacobian/
measure,32 nonlinear products,128 source jets,508 programs,finite contacts/
Legendre,IR/Legacy and physical viability remain unqualified. Keep34/39,
HB1/C5 blocked,flavor paused,C1_GS,quartet/scalar warnings,closed routes
and custodyexit2/seven. No input,scheme,benchmark,foundation,policy,
authority or remote action. Education voluntary/nonblocking,Lean selective.
