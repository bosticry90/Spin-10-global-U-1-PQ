# Actual two-vertex bosonic D-bubble ghost companions V1

Baseline277c30ec4c98ca4260da4e8831d2cd29ddaa8ff8. Question DB1: what
are the complete DG3 and DU contributions to the ordinaryg3 one-jet AaC/
BaC logarithmic UV pole? Both external ghosts attach to the D quartic.
These are two of the six remaining families, not a full ghost pole. The
qualified domain has24 DG3 and4 DU BaC cycles and2 DU AaC cycles. Reuse
the exact catalogue; support counts never set Wick or Bose factors.

Freeze record, source, controllers, current policy, domain and pure actual
classical export, qualified N1/P2/adjoints and principal inverse evidence.
Two sequential120-second-after-import/8GiB private workers,350MiB minimum
available commit; one120-second/8GiB independent validator. No silent
resource increase or truncation. Preserve failed sources and complete runs.
Do not read a desired ghost Ward coefficient, primitive or peer answer.

Derive the ordinary real-boson Gaussian cross term from i/2 logdet and
the two ordered Born words. D is the second B derivative of the full
literal ordered a*P2(B,A)*C action, with identical-B factors retained.
Only the actual two-quantum-B part enters these families. Obtain U's
mixed Lambda/B Hessian from the literal cubic and check every coefficient
against the qualified N1. Check the three-vector Hessian from the actual
-1/4 Yang-Mills action, not a guessed vertex normalization. The mixed
inverse is G_BL=+i*k/k^2, G_LB=-i*k/k^2, G_LL=0; full BB transverse and
longitudinal widths remain. A_H is not an integrated vector.

Use vector momentum r and external ghost momenta q,-q-r. Both attach to
D, so check the absence of separate q dependence. Evaluate both formal
UV probes and all16 vector/derivative slots with full4D loop momentum.
Primary uses first external Taylor/UV-annulus moments; replay uses a
shifted Feynman-parameter homogeneous residue. Preserve ordered widths
on the two color lines, possible quadratic width dependence and the
separate DG3/DU answers even if their sum simplifies. Keep the coefficient
of B*a*partial C distinct from the divergence-vector coefficient. Auxiliary
IR mass/UV annulus separates the pole; no whole scaleless/finite/IR zero.

Contract the actual D Hessian with all45 adjoints and all57 actual N1
backgrounds. Primary literal D/cubic parsing; replay the independently
qualified full P2/N1 matrix coefficients. Compare the entire literal
classical tensors, all physical coefficients and zero complements, not
diagnostic backgrounds. Check reality and actual H covariance where
applicable. Explicit-xi FR remains separately qualified and uninserted.

Controls omit each bosonic family, a mixed orientation or longitudinal
piece, replace the physical angular metric, change the Born factor and
drop the identical-B factor. Report insensitive controls rather than
requiring nonzero evidence. Independent validation must reconstruct
Gaussian/YM signs, both momentum residues, all color contractions and
exact profile coverage by distinct formulas. Shared catalogue/action,
charts/software/AI author limit independence, not independent scientists.

Outcome: complete measured DG3/DU family poles, including a possible exact
zero, an input/normalization discrepancy or bounded inconclusiveness.
No insertion into Gamma until complete family coverage and canonical
extraction. No coefficient fitting, full ghost/Ward/Slavnov/E5/A5/QAP/
finite-contact/measure/Legendre/IR or physical claim. Keep current147266/
hashc445c2...,38-source/auxiliary-H/bilinear scopes,nonzero Jacobian,
32 products,128 source jets,508 programs,Legacy/quartet/scalar warnings,
closed routes,34/39,HB1/C5 block,flavor pause,C1_GS,custodyexit2/seven.
No input,scheme,benchmark,foundation,policy,authority or remote action;
education voluntary/nonblocking,Lean selective.
