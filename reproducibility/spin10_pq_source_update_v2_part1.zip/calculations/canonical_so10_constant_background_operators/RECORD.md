# Constant-background gauge/ghost operator bridge V1

Baseline48dfab2e324c12ee60998925d73fffe0594a9308. AGENTS.md standing
delegation authorizes this bounded investigation, not a scientific promotion.
Question: can the actual nonlinear gauge fixing reduce the remaining no-jet,
dimension-zero source/vector g10^4 UV calculation without losing gauge,
auxiliary, ghost or width contributions?

Work in the qualified principal Gaussian/Wick UV reference: full643 origin,
315 gauge/auxiliary/ghost coordinates after the already qualified scalar
support exclusion. Positive-dimensional mass/orbit effects are excluded only
from this marginal local UV coefficient. No physical IR removal or finite
matching interpretation. External backgrounds and sources are not integrated.

All constant vector backgrounds lie along one Lorentz axis rho. B is the
actual TOTAL gauge field; A is the separate external H background. Do not
replace B by A+B in the gauge generator. Preserve all4 loop components and
all4 Lorentz copies of the actual vertices. Let PH/PM be the physical color
projectors and F_b the qualified real adjoints. Define D as the actual Q(B)
linear ghost generator, N as the actual auxiliary/vector Hessian row, and P
as the actual ordered antighost/ghost Hessian. At zero backgrounds,

    D_mu=i*q_mu, N_mu=-i*q^mu, P=q^2 I.

Recover all coefficients from sealed classical vertices: gauge-source cubic
for D1, bosonic auxiliary cubic for N1, derivative ghost cubic for P1, ghost
quartic for P2, and the antighost-source cubic for its nonlinear Q(a) term.
No previous pole or formal Ward completion is an input. Require primary/replay
classical subtree agreement and actual receipts/committed bytes.

Test P=N*D. If it fails, preserve the exact discrepancy rather than suppress
it. A separately motivated comparator is the nonminimal contribution
E=(Q(a)+Lambda) dotted into the background gauge-fixing condition f, with
N=-df/dB. Thus test P=N*D+E using the ACTUAL source and gauge-fixing tensors.
The expected E has orderg^2 and can be nonzero when f_M(B,A) is nonzero.
Establish its support and sign from data, not by fitting a residual. This is
not a counterterm or physical parameter. Do not set f=0 to rescue a universal
claim on off-shell backgrounds.

Primary: independent literal parsing with exact roots and all4 Lorentz-copy
checks. Replay: indexed physical adjoint/projector formulas, including
N_Ah=-PH F_h PH, N_Bh=-PM F_h PM, N_Bm=PM F_m PH, D_Bb=F_b,D_Ah=0.
Derive E from the nonminimal source variation and the nonlinear condition.
Compare all57 linear background coefficients and all1653 unordered quadratic
background pairs (A_H/B45), retaining complete45x45 matrices and exact sparse
zeros. Record failure of the naive equality separately from success of a
corrected identity. Test noncommuting N/D and unequal width matrices.

Independently prove and test the mixed inverse. At zero auxiliary background,
the bosonic block is [[K_YM,N(-q)^T],[N(q),W]]. A constant single-axis B has
zero Yang-Mills curvature, so K_YM*D=0 and its transposed left identity hold.
With ND formally invertible about q^2 I, block equations give

    G_LL=0, G_BL=D*(ND)^(-1).

This does NOT require P=ND, N/D commutation or W commutation. No inverse of g
or W and no auxiliary elimination. Test the orderg0..g2 mixed columns on a
deterministically selected actual noncommuting H/M color pair, with independent
formal unit A_h,B_h,B_m and nonzero q=(1,2,3,5). These are algebraic controls,
not adopted physical backgrounds. Primary uses the ordered inverse formula;
replay uses full225-dimensional bosonic Born inverse columns with ordinary
B/B and symbolic unequal W_H/W_M. Keep complete scalar-loop momentum in the
general proof; one rational momentum fixture is not that proof.

Controls: replacing ND by the actual ghost P in the mixed inverse must expose
the E discrepancy when nonzero; dropping ordinary B/B must be tested rather
than inferred harmless; adding A to D contrary to the action must be detected.
Any nondiscriminating control is reported honestly. Fail at a missing required
operator, normalization/sign discrepancy or unproved extension.

If these premises hold, establish whether the full NO-JET dimension-zero g4
JLambda*C*VV UV coefficient can be independent of reference widths: the actual
source Hessians join only ghosts to auxiliaries (SL) or ghosts to ghosts (KL);
their one-external-C inverse correction uses G_BL or G_LL, not an independently
omitted B/B block. Check the actual source and C-insertion port types. Width
independence would be structural, not a calculated full tensor or restoration.

Two sequential read-only workers120s after imports/8GiB sampled private memory/
350MiB available commit, plus proportionate dependent validation. Freeze code,
proof and hashes first. Preserve all failures; corrections use separate frozen
continuations under standing delegation. No new parameter search, quantum
matching, old expensive replay, general compiler or independent reviewer.

Authorityv113/34of39 unchanged; E5/A5 and anomaly freedom unqualified,
Ward18416/nonzero, quartet and earlierg2 failures preserved. HB1/C5 blocked,
flavor paused, finiteC1_GS uncalculated, scalar warnings/closed routes intact.
Custodyexit2/seven unresolved never PASS. Science/AI capability equal goals;
education voluntary/concurrent/nonblocking. No physical input, benchmark,
foundation, publication, push, branch or worktree change.
