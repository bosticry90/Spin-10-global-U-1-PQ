# General operator bridge: a false shortcut and a valid reduction

The actual ghost kernel is **not** the simple product N*D on general constant
backgrounds. The complete comparison instead establishes

    P = N*D + E.

E is fixed by the existing nonlinear antighost transformation and gauge-fixing
condition. It was derived from those vertices, not fitted to a discrepancy.
The separate mixed-inverse identity survives:

    G_LL=0,    G_BL=D*(N*D)^(-1).

It uses N*D, not P. Confusing those two operators produces an exact error.
These are principal classical/operator results supporting the next quantum
calculation, not a new full UV tensor or quantum-restoration result.

In plain language: a proposed simplification had two parts. One part was false
because it omitted a real interaction. The other part remains useful and can
remove gauge-width complexity from the specified UV calculation. We have kept
the missing interaction instead of changing the model to recover the shortcut.

## Actual operators and negative result

B is the total gauge field in the unchanged action. The external A_H enters
gauge fixing, not Q(B) as an additional gauge field. All180 actual gauge
columns were screened:180 unit ghost derivatives,3,544 nonlinear raw rows,
and no A terms. The physical gauge-source vertices independently supply all45
adjoint generators. Substituting A+B for B fails this check.

For arbitrary constant A_H/B45 values along a common Lorentz axis, the two
methods agree on the complete45x45 operator coefficients:57 linear background
positions and1,653 unordered quadratic background pairs. Exact sparse zeros
cover the complement. The literal route checks all four Lorentz copies.
The retained nonzero coefficients are740 in N1,1,674 in D1,1,412 in P1 and
15,062 in P2. No external background or source receives a quantum propagator.

Let f_M=g*[B_H,B_M] be the heavy gauge-fixing condition on these constant
fields, and Q(a_i)=-Lambda_i+g*F_h(i,j)*a_j*C_h. Then

    E_(j,h)=g^2*sum_i F_h(i,j)*[B_H,B_M]_i
           =g^2*(PM*ad_[B_H,B_M]*PH)_(j,h).

E contains3,534 nonzero coefficients across286 background pairs. For example,
the coefficient of g10^2*Bp0_0*Bp13_0 in (P-ND)_(13,0) is9/40. The naive
identity P=ND therefore FAILS exactly. It holds on appropriate restricted
backgrounds where E vanishes; imposing that condition would restrict the
scientific question and is not done here.

Direct literal gauge-fixing/antighost-source extraction and an indexed adjoint
replay agree on the corrected relation, including its sign. The latter uses
the actual projectors and their ordered products; it assumes no commutation
between N and D. The correction is not evidence of a gauge anomaly or an
inconsistent theory. It exposes an omitted term in the proposed operator
identification.

The actual P is upper triangular in H/M color blocks: the M,H block vanishes,
while the H,M block is nonzero (334 linear and1,304 quadratic coefficients).
The heavy diagonal block is independent of A_H in this constant-background
scope. These are measured support statements, not permission to drop the
nonzero off-diagonal block in a subsequent inverse.

## Mixed inverse and reference widths

[PROOF.md](PROOF.md) retains the bosonic block
[[K_YM,N(-q)^T],[N(q),W]] at zero auxiliary background. A constant single-axis
B has zero Yang-Mills curvature. Its actual -1/4 F^2 Hessian has the gauge
null vector D, and ND has leading term q^2 I. The block equations then give
G_LL=0 and G_BL=D*(ND)^(-1) as a formal series. This argument does not require
P=ND, equal widths, commuting color matrices, inverse g or inverse W.
It does not eliminate auxiliaries.

Both routes test an actual noncommuting color fixture: A0=B0=B13=1 along
Lorentz0 and q=(1,2,3,5), q^2=-37. These are algebraic unit controls, not
adopted physical inputs. The direct ordered inverse and full225-coordinate
ordinary-vector Born columns agree through g^2 on every mixed entry. Both
reference inverse orders and the full block equations pass. G_LL remains0,
and symbolic unequal W_H/W_M cancel after summation. The general proof, not
this one momentum fixture, establishes the stated formal identity.

N and D do not commute in the fixture (a commutator entry is9/40). The width
matrix also does not commute with D. Replacing ND by P leaves an auxiliary
block defect9/1480 in the first reported entry. Dropping ordinary B/B changes
the order-g mixed column; a reported entry changes by-57*sqrt(10)/13690.
Thus width independence does not license deletion of vector propagators.

The actual source Hessians and C-linear insertions have the required ports:
SL joins a ghost to an auxiliary, KL joins ghosts, and a C-linear correction
joins an antighost to a vector or auxiliary. Four-ghost vertices cannot supply
that single-C Hessian at zero other ghosts. The complete restricted no-jet,
dimension-zero g10^4 JLambda*C*VV UV coefficient consequently has no reference
width dependence: its resummed bosonic lines are the proved mixed inverse or
zero G_LL. This is a STRUCTURAL statement about the completed restricted
coefficient, not its calculated numerical value or a finite/full-theory claim.
The former V155 warning has now been addressed within this precise scope;
the historical record remains unchanged.

## Validation, limitations and research tracks

The primary finishes in34.17s and replay in9.08s after imports, within the
frozen120s/8GiB/350MiB limits. No new execution failed. The scientific naive
identity did fail, and that status is distinct from successful evidence
validation. Require validation_receipt.json and exact committed-byte checks.
No old large loop was replayed and no fresh same-command pair is claimed.
Shared action, representation conventions, exact coefficient engine,
Python/SymPy and analyst limit independence.

Track A gains complete classical operator symbols and a usable mixed-inverse
reduction. Track B records rejection of an elegant but false identification
and preservation of the valid part without fitting away its defect. The
plain explanation supports voluntary, concurrent, nonblocking education.
Neither method agreement nor this structural result validates the physical
assumptions or establishes reliable autonomous original physics research.

Next: derive and verify the actual source-linear Gaussian expression using
the measured N,D,P (including E), SL/KL and C-linear F/D insertions. Fix its
graded signs and UV normalization with an explicit contraction comparator,
then use these45-dimensional operators for the remaining g4 color tensor.
Do not substitute P for ND or use a formal Ward completion as a prediction.
Keep the nonzero H,M ghost inverse block. This should target the outstanding
calculation rather than another general verification framework.

The full g4 tensor remains uncalculated. Ward18416/nonzero, quartet3960/648
and earlierg2 failures persist; full E5/A5/anomaly freedom unqualified. HB1/C5
blocked, finiteC1_GS uncalculated, flavor paused, scalar quantum warnings and
closed routes intact. Authorityv113/34of39 unchanged. Custodyexit2/seven
unresolved, not rerun and never PASS. No accepted physical benchmark/input,
foundation, external action, publication, push, branch or worktree change.
