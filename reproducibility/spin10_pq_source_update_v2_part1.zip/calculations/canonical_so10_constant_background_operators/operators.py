"""Actual nonlinear gauge-fixing/ghost symbols, not a pole fit."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import combinations_with_replacement
import json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
import a10_e5_quartic_algebra as ex
num=ex.coefficient;ZERO=ex.D.zero;ONE=num(1);II=num(s.I)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def put(A,key,z):
    A[key]=A.get(key,ZERO)+z
    if not A[key]:del A[key]
def add(*As):
    out={}
    for A in As:
        for key,z in A.items():put(out,key,z)
    return out
def scale(A,z):return {key:v*z for key,v in A.items() if v*z}
def mm(A,B):
    rows=defaultdict(list);out={}
    for (k,j),z in B.items():rows[k].append((j,z))
    for (i,k),z in A.items():
        for j,v in rows[k]:put(out,(i,j),z*v)
    return out
def trans(A):return {(j,i):z for (i,j),z in A.items()}
def block(A,rs,cs):return {(i,j):z for (i,j),z in A.items() if i in rs and j in cs}
def pack(A):return [[i,j,str(ex.D.to_sympy(z))] for (i,j),z in sorted(A.items())]
def operators_pack(A):return [[list(key) if isinstance(key,tuple) else key,pack(v)] for key,v in sorted(A.items()) if v]
def ident(n):return {(i,i):ONE for i in range(n)}
H=set(range(12));M=set(range(12,45));ALL=set(range(45))
def bg(n):return int(n[2:].split('_')[0])+(0 if n.startswith('Ap') else 12)
def label(i):return ('A'+str(i)) if i<12 else ('B'+str(i-12))
def tok(n):
    name,mark,j=n.partition('__');return name,tuple(map(int,j))

def literal(data):
    N=[defaultdict(dict) for _ in range(4)];L=[defaultdict(dict) for _ in range(4)]
    P=[defaultdict(dict) for _ in range(4)];fbg=[defaultdict(dict) for _ in range(4)]
    for row in data['vertices']['F_ghost_and_auxiliary']:
        ts=[tok(n) for n in row['word']];z=num(s.sympify(row['coefficient']));vs=[v for v in ts if v[0].startswith(('Bp','Ap'))]
        axes={int(n.rsplit('_',1)[1]) for n,j in vs}|{mu for n,j in ts for mu in j}
        assert len(axes)==1;mu=next(iter(axes));eta=1 if mu==0 else -1
        if any(n.startswith('Lp') for n,j in ts):
            assert len(vs)==2 and not any(j for n,j in ts)
            aux=int(next(n[2:] for n,j in ts if n.startswith('Lp')))
            pair=tuple(sorted(bg(n) for n,j in vs));put(fbg[mu][pair],(aux,0),-eta*z)
            for pos,(n,j) in enumerate(vs):
                other=vs[1-pos][0]
                if other.startswith('Bp'):put(N[mu][bg(n)],(aux,int(other[2:].split('_')[0])),eta*z)
        else:
            assert len(vs)==1
            a=next(v for v in ts if v[0].startswith('ap'));c=next(v for v in ts if v[0].startswith('Cp'))
            assert sum(len(j) for n,j in ts)==1
            if vs[0][1]:continue # Constant external vector, not a discarded quantum derivative.
            weight=len(c[1])-len(a[1]);assert abs(weight)==1
            put(L[mu][bg(vs[0][0])],(int(a[0][2:]),int(c[0][2:])),-eta*weight*z)
    for row in data['vertices']['D_vectorpair_ghost']:
        ts=[tok(n) for n in row['word']];assert not any(j for n,j in ts)
        vs=[n for n,j in ts if n.startswith(('Bp','Ap'))];assert len(vs)==2
        axes={int(n.rsplit('_',1)[1]) for n in vs};assert len(axes)==1;mu=next(iter(axes));eta=1 if mu==0 else -1
        a=int(next(n[2:] for n,j in ts if n.startswith('ap')));c=int(next(n[2:] for n,j in ts if n.startswith('Cp')))
        put(P[mu][tuple(sorted(bg(n) for n in vs))],(a,c),-eta*num(s.sympify(row['coefficient'])))
    norm=lambda A:{k:v for k,v in A.items() if v}
    N,L,P,fbg=[[norm(A) for A in group] for group in [N,L,P,fbg]]
    assert all(group[mu]==group[0] for group in [N,L,P,fbg] for mu in range(1,4))
    D=defaultdict(dict)
    for row in data['gauge_source_cubic']:
        ns=row['word'];assert len(ns)==3 and all('__' not in n for n in ns)
        assert not any(n.startswith('Ap') for n in ns)
        i=int(next(n[3:] for n in ns if n.startswith('JBp')));c=int(next(n[2:] for n in ns if n.startswith('Cp')))
        b=int(next(n[2:] for n in ns if n.startswith('Bp')))
        put(D[b+12],(i,c),-num(s.sympify(row['coefficient']))) # J_B and C are both odd.
    Ra=defaultdict(dict)
    for row in data['antighost_source_cubic']:
        ns=row['word'];i=int(next(n[2:] for n in ns if n.startswith('Jp')))
        j=int(next(n[2:] for n in ns if n.startswith('ap')));h=int(next(n[2:] for n in ns if n.startswith('Cp')))
        assert i in M and j in M and h in H
        put(Ra[i],(j,h),-num(s.sympify(row['coefficient']))) # J_a even; a before C.
    E={}
    for pair,vector in fbg[0].items():
        mat={}
        for (i,dummy),z in vector.items():
            for key,v in Ra.get(i,{}).items():put(mat,key,z*v)
        if mat:E[pair]=mat
    return N[0],dict(D),L[0],P[0],E,{'all4_literal_Lorentz_copies_equal':True,'antighost_source_terms':len(data['antighost_source_cubic'])}

def physical(data):
    F=[{(i,j):num(s.sympify(z)) for i,j,z in rows} for rows in data['all45_physical_adjoint_matrices']]
    for A in F:assert trans(A)==scale(A,-1)
    D={b+12:A for b,A in enumerate(F)};N={}
    for h in range(12):
        N[h]=scale(block(F[h],H,H),-1);N[h+12]=scale(block(F[h],M,M),-1)
    for m in range(12,45):N[m+12]=block(F[m],M,H)
    N={k:v for k,v in N.items() if v};L={k:add(N.get(k,{}),scale(D.get(k,{}),-1)) for k in range(57)}
    L={k:v for k,v in L.items() if v};E={}
    for h in range(12):
        for m in range(12,45):
            value=block(add(mm(F[h],F[m]),scale(mm(F[m],F[h]),-1)),M,H)
            if value:E[h+12,m+12]=value
    P={}
    for x,y in combinations_with_replacement(range(57),2):
        value=mm(N.get(x,{}),D.get(y,{}))
        if x!=y:value=add(value,mm(N.get(y,{}),D.get(x,{})))
        value=add(value,E.get((x,y),{}))
        if value:P[x,y]=value
    return N,D,L,P,E,F

def actual_QB(route):
    d=read(PKG/f'frozen_a10_e2_transport/{route}.json');g=s.Symbol('g10');linear=0;terms=0
    for i in range(45):
        for mu in range(4):
            c=d['complete_columns'][f'B{i}_{mu}'];assert c['physical_program'] is None
            derivative=[]
            for row in c['source_polynomial']:
                ts=[tok(n) for n in row['word']];z=s.sympify(row['coefficient'])
                assert not any(n.startswith('A') for n,j in ts),'B_IS_NOT_A_PLUS_B'
                if len(ts)==1:
                    assert ts==[(f'C{i}',(mu,))] and z==1;derivative.append(row);linear+=1
                else:
                    assert len(ts)==2 and all(not j for n,j in ts) and s.Poly(z,g).monoms()==[(1,)]
                    assert sum(n.startswith('B') and n.endswith('_'+str(mu)) for n,j in ts)==1
                    assert sum(n.startswith('C') for n,j in ts)==1;terms+=1
            assert len(derivative)==1
    return {'actual_gauge_columns':180,'unit_ghost_derivatives':linear,'nonlinear_raw_rows':terms,'A_terms':0}

def quadratic(N,D):
    out={}
    for x,y in combinations_with_replacement(range(57),2):
        value=mm(N.get(x,{}),D.get(y,{}))
        if x!=y:value=add(value,mm(N.get(y,{}),D.get(x,{})))
        if value:out[x,y]=value
    return out

def fixture(N,D,E,role):
    pair=next(pair for pair in sorted(E) if pair[0]>=12 and pair[1]>=24)
    h,m=pair[0]-12,pair[1]-12;assert h in H and m in M
    # Independent formal unit backgrounds, not a physical input point.
    NX=add(N.get(h,{}),N.get(h+12,{}),N.get(m+12,{}));FX=add(D[h+12],D[m+12]);I=ident(45)
    diff=add(mm(NX,FX),scale(mm(FX,NX),-1));assert diff
    W={(i,i):num(ex.widthH if i in H else ex.widthM) for i in range(45)}
    wd=add(mm(W,FX),scale(mm(FX,W),-1));assert wd
    q=[1,2,3,5];eta=[1,-1,-1,-1];up=[eta[a]*q[a] for a in range(4)];R=sum(a*b for a,b in zip(q,up));assert R==-37
    K=[{}, {}, {}];G={};T2=mm(FX,FX)
    def B(i,mu):return 4*i+mu
    for i in range(45):
        wi=ex.widthH if i in H else ex.widthM
        for mu in range(4):
            for nu in range(4):
                put(K[0],(B(i,mu),B(i,nu)),num(-R*eta[mu]*int(mu==nu)+up[mu]*up[nu]))
                put(G,(B(i,mu),B(i,nu)),num(-s.Rational(eta[mu]*int(mu==nu),R)+(1-wi)*s.Rational(q[mu]*q[nu],R**2)))
            put(K[0],(B(i,mu),180+i),num(s.I*up[mu]));put(K[0],(180+i,B(i,mu)),num(-s.I*up[mu]))
            put(G,(B(i,mu),180+i),num(s.I*s.Rational(q[mu],R)));put(G,(180+i,B(i,mu)),num(-s.I*s.Rational(q[mu],R)))
        put(K[0],(180+i,180+i),num(wi))
    for mu in range(4):
        for nu in range(4):
            y=s.I*(2*q[0]*eta[mu]*int(mu==nu)-up[mu]*int(nu==0)-int(mu==0)*up[nu])
            z=eta[mu]*int(mu==nu)-int(mu==nu==0)
            for (i,j),v in FX.items():put(K[1],(B(i,mu),B(j,nu)),num(y)*v)
            for (i,j),v in T2.items():put(K[2],(B(i,mu),B(j,nu)),num(z)*v)
    for (i,j),v in NX.items():put(K[1],(180+i,B(j,0)),v);put(K[1],(B(j,0),180+i),v)
    assert mm(K[0],G)==ident(225) and mm(G,K[0])==ident(225)
    col0={(i,j-180):z for (i,j),z in G.items() if j>=180}
    if role=='primary':
        L=add(NX,scale(FX,-1));C1=scale(L,num(s.I*q[0]));C2=mm(NX,FX)
        inv1=scale(C1,num(-s.Rational(1,R**2)))
        inv2=add(scale(mm(C1,C1),num(s.Rational(1,R**3))),scale(C2,num(-s.Rational(1,R**2))))
        cols=[col0,{},{}]
        for mu in range(4):
            c1=add(scale(inv1,num(s.I*q[mu])),scale(FX,num(s.Rational(int(mu==0),R))))
            c2=add(scale(inv2,num(s.I*q[mu])),scale(mm(FX,inv1),int(mu==0)))
            for (i,j),z in c1.items():put(cols[1],(B(i,mu),j),z)
            for (i,j),z in c2.items():put(cols[2],(B(i,mu),j),z)
    else:
        col1=scale(mm(G,mm(K[1],col0)),-1)
        col2=scale(mm(G,add(mm(K[1],col1),mm(K[2],col0))),-1);cols=[col0,col1,col2]
    target={(180+i,i):ONE for i in range(45)}
    for power in range(3):
        product_=add(*(mm(K[j],cols[power-j]) for j in range(power+1)))
        assert product_==(target if power==0 else {}),('MIXED_COLUMN_BLOCK_EQUATION',power)
        assert not [(i,j) for i,j in cols[power] if i>=180]
        assert all(all(a==b==0 for a,b,mask in v.cells) for v in cols[power].values()),'WIDTH_NOT_CANCELED'
    eg=E[pair]
    wrong2=dict(cols[2])
    for mu in range(4):
        for (i,j),v in eg.items():put(wrong2,(B(i,mu),j),num(-s.I*s.Rational(q[mu],R**2))*v)
    defect=add(mm(K[0],wrong2),mm(K[1],cols[1]),mm(K[2],cols[0]));assert defect
    expected={(180+i,j):num(-s.Rational(1,R))*v for (i,j),v in eg.items()};assert defect==expected
    noBB={ij:v for ij,v in G.items() if not(ij[0]<180 and ij[1]<180)}
    wrong1=scale(mm(noBB,mm(K[1],col0)),-1);loss=add(wrong1,scale(cols[1],-1));assert loss
    witness=lambda A:pack(A)[:1]
    return {'A_H_unit_index':h,'B_unit_indices':[h,m],'Lorentz_axis':0,'q_covariant':q,'q_squared':R,
            'noncommuting_N_D_witness':witness(diff),'noncommuting_width_D_witness':witness(wd),
            'mixed_columns':[pack(A) for A in cols],'G_LL_zero':True,'reference_both_inverse_orders':True,
            'widths_cancel_after_full_Born_sum':True,'wrong_ghost_inverse_defect':witness(defect),
            'wrong_ghost_inverse_defect_count':len(defect),'ordinary_BB_omission_changes_order1':True,
            'ordinary_BB_omission_witness':witness(loss)}

def ports(data):
    out={};v=data['vertices']
    for tag in ['source_cubic','source_quartic','F_ghost_and_auxiliary','D_vectorpair_ghost','Xi','Q_g_xi','R_g_squared_xi']:
        profiles=Counter()
        for row in v[tag]:
            ns=[n.partition('__')[0] for n in row['word']]
            kinds=tuple(sorted('J' if n.startswith('JLp') else 'a' if n.startswith('ap') else 'C' if n.startswith('Cp') else 'L' if n.startswith('Lp') else 'A' if n.startswith('Ap') else 'B' for n in ns))
            profiles['*'.join(kinds)]+=1
        out[tag]=dict(profiles)
    assert set(out['source_cubic'])=={'C*J*L'} and set(out['source_quartic'])=={'C*C*J*a'}
    assert set(out['F_ghost_and_auxiliary'])<=set(['B*C*a','A*C*a','B*B*L','A*B*L'])
    assert set(out['D_vectorpair_ghost'])<=set(['B*B*C*a','A*B*C*a'])
    assert set(out['Xi'])=={'C*L*a'}
    assert set(out['Q_g_xi'])==set(out['R_g_squared_xi'])=={'C*C*a*a'}
    return out

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json')
    assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['input_sha256']}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):raise PermissionError('OPERATORS_WORKER_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('OPERATORS_POLE_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard)
    data=read(Path(prep['classical_export']));assert data['primary_replay_classical_subtrees_equal']
    print('STAGE '+role+' source_and_ports',flush=True);qb=actual_QB(role);support=ports(data)
    print('STAGE '+role+' full_operator_coefficients',flush=True)
    if role=='primary':N,D,L,P,E,extra=literal(data)
    else:N,D,L,P,E,F=physical(data);extra={'physical_adjoints':45,'exact_projector_replay':True}
    assert all(add(N.get(x,{}),scale(D.get(x,{}),-1))==L.get(x,{}) for x in range(57))
    nd=quadratic(N,D);difference={}
    for pair in combinations_with_replacement(range(57),2):
        delta=add(P.get(pair,{}),scale(nd.get(pair,{}),-1))
        assert delta==E.get(pair,{}),('UNEXPLAINED_GHOST_JACOBIAN_DISCREPANCY',pair)
        if delta:difference[pair]=delta
    assert difference and all(x>=12 and y>=24 for x,y in difference)
    witnesspair=min(difference);witness=pack(difference[witnesspair])[:1]
    # Incorrect A+B gauge generator fails already at first order.
    firstA=next(x for x in range(12) if D.get(x+12));assert D.get(firstA,{})=={}
    assert add(L.get(firstA,{}),D[firstA+12])!=L.get(firstA,{})
    print('STAGE '+role+' auxiliary_preserving_mixed_inverse',flush=True);mixed=fixture(N,D,E,role)
    out={'schema':'CONSTANT_BACKGROUND_OPERATORS_V1','route':role,'QB_audit':qb,'port_inventory':support,
         'linear_background_domain':57,'quadratic_background_pair_domain':1653,'ghost_matrix_dimension':45,
         'N1':operators_pack(N),'D1':operators_pack(D),'P1_over_i_qrho':operators_pack(L),
         'P2':operators_pack(P),'nonminimal_E':operators_pack(E),
         'naive_P_equals_ND':False,'corrected_P_equals_ND_plus_E':True,
         'E_background_pair_count':len(E),'E_coefficient_count':sum(len(A) for A in E.values()),
         'naive_failure_witness':{'background_pair':[label(x) for x in witnesspair],'matrix_entry':witness},
         'wrong_A_plus_B_generator_detected':True,'fixture':mixed,'method':extra,
         'formal_width_independence_claim':'ONLY_COMPLETED_NO_JET_DIMENSION_ZERO_SOURCE_VECTOR_G4_UV',
         'actual_full_g4_tensor_or_E5_A5_calculated':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
