# Operator identities to be tested on the actual action

Use a real orthonormal physical adjoint frame; PH projects onto H colors0..11
and PM onto12..44. A contains only H colors. For a single-axis constant
background, write U=sum_h B_h F_h, V=sum_m B_m F_m, Z=sum_h A_h F_h. The
total gauge generator is D_mu=i*q_mu+g*(U+V)*delta_mu_rho. It has no A term.
The actual auxiliary row N=-df/dB has nonlinear color coefficient

    N1=-PH*Z*PH-PM*U*PM+PM*V*PH

along rho, with the corresponding Lorentz weight. Its principal term is
-i*q^mu. This formula is a comparator; RECORD requires literal verification.
The heavy condition is f_M=g*[B_H,B_M] for constant fields; the light
condition is f_H=g*[A,B_H]. The nonminimal source variation is
Q(a_i)=-Lambda_i+g*sum_(h in H,j in M) F_h(i,j)*a_j*C_h for heavy i,
with the ordinary doublet for light i. Direct variation of a*f therefore gives
the ordered ghost Hessian

    P=N*D+E,  E_(j,h)=g^2*sum_i F_h(i,j)*[B_H,B_M]_i.

Equivalently E=PM*ad_[B_H,B_M]*PH. This term need not vanish off the
gauge-fixing surface; it has no derivative or A term. The antighost-source
and auxiliary vertices must verify its sign and normalization independently.
The gauge-fermion cubic ghost terms have no antighost/ghost quadratic Hessian
at zero ghost and auxiliary backgrounds. Positive-dimensional orbit terms
are outside this marginal UV comparison, not zero in the physical theory.

Let K_YM be the actual -1/4 F^2 Hessian at the constant one-axis B. All its
covariant momentum components commute, since only one Lie-algebra element
occurs and background curvature is zero. Gauge invariance gives K_YM D=0;
the left identity follows by Fourier transpose q -> -q, including color
transpose. The auxiliary background is retained at zero, so no f*f'' term
from eliminating auxiliaries has been introduced. The full bosonic Hessian
is [[K_YM,N(-q)^T],[N(q),W]]. The reference at g=0 is qualified invertible
for q^2 !=0 even for arbitrary W, and defines a unique formal inverse in g.

For its auxiliary column, multiply the upper equation by D(-q)^T. Since
(N(-q)D(-q))^T has leading coefficient q^2 I, it is formally invertible and
G_LL=0. Then G_BL=D*(ND)^(-1) solves both block equations. W did not need
to commute with D or N; it was not inverted. This identity holds as a formal
operator series on the stated flat backgrounds. It is not an inverse of the
complete massive quantum fluctuation operator or a physical IR prescription.
Replacing ND by P is justified only when the measured E vanishes.

For the marginal no-jet source/vector pole, one-loop 1PI counting fixes two
quantum ports at each cycle vertex. The actual source action has only SL
(JLambda*Lambda*C) and KL (JLambda*a*C*C). At source-linear order with one
constant external C, the Gaussian expression has a ghost-only KL insertion,
and an SL insertion joined through one C-linear inverse correction. At zero
antighost background that correction joins an antighost to a vector or an
auxiliary. SL therefore selects a bosonic G_BL/G_LB or G_LL, while all other
lines are ghost inverses. The W-dependent ordinary B/B lines have been
resummed into the proved mixed inverse, not removed. P contains no W at the
zero-auxiliary/ghost background. Hence the completed restricted local UV
coefficient is W independent if the actual Hessian port and operator checks
pass. Background A can enter N and P and does not change the flat physical
Yang-Mills condition because the physical action uses B, not A+B.

Lorentz invariance and the zero-jet target imply a rank-two vector coefficient
proportional to eta_mu_nu. There is no second independent Lorentz tensor or
two-index epsilon term. A single-axis calculation with arbitrary independent
A_H/B color variables therefore determines all AA/AB/BB coefficients by
polarization. This is restricted to the declared local dimension-zero UV
sector; finite, massive, nonzero-jet and physical scattering quantities are
not covered. The residue/UV bridge is inherited from V156, not a finite
regularized-trace cyclicity claim.
