# Normalized insertion matches inherited measured evidence

Prospective until independent receipt and committed-byte checks complete.
The fixed determinant i/2 and retained Minkowski logarithmic residue
i/(16pi^2 epsilon) imply multiplier -1 in common hbar/(32pi^2 epsilon)
units. This sign is derived before coefficient comparison, not fitted.
There are no Lorentz-indexed external fields in this selected target; only
loop momentum is Wick rotated in the inherited raw canonical convention.

The normalized20-position insertion equals exactly the ub12 variation of the
existing measured276-position auxiliary_g1 pole. All2025 ghost/auxiliary
slots agree. Authenticated subsequent lossless additions have zero projection
on the g1/no-jet C-L-a cohort. Existing functional155110/hashce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1
is unchanged. No new node should be inserted: that would double count evidence.

This gives a selected coefficient correspondence between independently
constructed ordered insertion and inherited measured loop evidence. It does
not yet qualify a complete D Gamma antighost identity: source predecessors
and complete target coverage must be reconciled before that broader claim.
The nonzero insertion is not an anomaly. General QAP/contact/measure/IR,
sourcefreeSlavnov/E5/A5 remain unqualified;authority34/39 unchanged.

Wrong sign,factor2 and either omitted family fail against measured data.
Shared action,conventions,insertion,reference,source maps,software and AIauthor
remain common premises; no independent expert/experimental confirmation.
Native routes preserve the old auxiliary candidate's actual failure and all
other blocks/pauses/custody2-seven. No new physical input/scheme adopted.

Next: prove the exact remaining source-predecessor classification for this
target, then determine whether the complete selected antighost equation is
already covered. Reuse source graph coverage and measured source image;
do not infer zeros from absent rows or fit a missing coefficient.
