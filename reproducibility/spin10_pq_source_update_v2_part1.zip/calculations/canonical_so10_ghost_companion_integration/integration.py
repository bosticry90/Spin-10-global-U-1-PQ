"""Full current recipe authentication and exact-once measured ghost insertion."""
from pathlib import Path
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
old=load('qualified_current_auxiliary_recipe',OUT.parent/'canonical_so10_auxiliary_companion_canonical/integration.py');a=old.a;q=old.q;m=old.m;l=old.l;h=old.h;s=old.s;read=q.read;digest=q.digest
def measured(role):
    d=OUT.parent/'canonical_so10_ghost_companion_canonical';p=d/(role+'_v2_result.json');r=read(d/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p) and r['complete_relation_zero_mod_current'] and r['complete_raw_density_zero'];return read(p)
def current_tables(role):
    tables,previous,path=old.current_tables(role);p=OUT/(role+'_result.json');r=read(OUT/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);d=read(p);tables.append(d['new_actual_g3_ghost_companion_node']);return tables,d,p
def typ(key):return tuple(sorted(h.kind(n) for n,j in key))
def selected(P):return {key:z for key,z in P.items() if key[0]==3 and typ(key[1]) in [('A','C','a'),('B','C','a')] and sum(len(j) for n,j in key[1])==1}
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('GHOST_INTEGRATION_WRITE')
        if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();r=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return r
    m.setup();d=measured(role);nodeRows=d['actual_g3_ghost_companion_node'];P=m.decode(nodeRows);assert len(P)==7136 and selected(P)==P
    tables,previous,path=old.current_tables(role);prior=stage('reproduce_incoming147266_word_recipe_and_hash',lambda:q.combine(tables));assert len(prior)==previous['updated_known_terms']==147266 and q.hashrows(q.rawrows(prior))==previous['updated_known_sha256']=='c445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4';assert not selected(m.decode([r for r in q.rawrows(prior) if typ(tuple(m.token(n) for n in r['word'])) in [('A','C','a'),('B','C','a')] and sum(len(m.token(n)[1]) for n in r['word'])==1]))
    additions={tuple(m.token(n) for n in r['word']):r['coefficient'] for r in nodeRows};assert len(additions)==7136
    def insert():
        if role=='primary':return q.combine([q.rawrows(prior),nodeRows])
        new=dict(prior)
        for key,z in additions.items():
            c=q.sumtext(tuple(sorted([new.get(key,'0'),z])))
            if c!='0':new[key]=c
            else:new.pop(key,None)
        return new
    new=stage('actual_once_addition_inverse_doubling_and_source_projection',insert);changed={k for k in set(prior)|set(new) if prior.get(k)!=new.get(k)};assert changed==set(additions);inverse=dict(new);double=dict(new)
    for key,z in additions.items():inverse[key]=q.sumtext(tuple(sorted([new.get(key,'0'),str(-q.num(z))])));double[key]=q.sumtext(tuple(sorted([new.get(key,'0'),z])))
    inverse={k:z for k,z in inverse.items() if z!='0'};double={k:z for k,z in double.items() if z!='0'};assert inverse==prior and double!=new
    assert {k:z for k,z in prior.items() if k not in changed}=={k:z for k,z in new.items() if k not in changed};assert {k:z for k,z in prior.items() if any(n in m.sources for n,j in k)}=={k:z for k,z in new.items() if any(n in m.sources for n,j in k)}
    current=selected(m.decode([r for r in q.rawrows(new) if typ(tuple(m.token(n) for n in r['word'])) in [('A','C','a'),('B','C','a')] and sum(len(m.token(n)[1]) for n in r['word'])==1]));assert current==P
    kinetic=m.decode(q.auth('canonical_so10_ghost_kinetic_canonical',role+'_v4_result.json')['new_actual_g2_ghost_kinetic_node']);assert m.add(kinetic,current)==h.from_result(d['complete_selected_input'])
    result={'schema':'ACTUAL_GHOST_COMPANION_EXACT_ONCE_INTEGRATION_V1','route':role,'scientific_disposition':'QUALIFIED_EXACT_ONCE_MEASURED_GHOST_INTEGRATION_ONLY','new_actual_g3_ghost_companion_node':nodeRows,'new_node_positions':len(P),'prior_known_terms':len(prior),'prior_known_sha256':q.hashrows(q.rawrows(prior)),'updated_known_terms':len(new),'updated_known_sha256':q.hashrows(q.rawrows(new)),'new_word_positions':len(set(new)-set(prior)),'changed_existing_word_positions':len(changed&set(prior)),'removed_existing_word_positions':len(set(prior)-set(new)),'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'add_once_key':'new_actual_g3_ghost_companion_node'},'source_projection_and_all_untouched_coefficients_identical':True,'complete_ordinary_g3_selected_predecessor_absent_before_and_measured_after':True,'qualified_selected_H_input_reconciled_without_rerun':True,'inverse_addition_recovers_exact_prior_and_double_detected':True,'new_loop_full_QGamma_physical_Euler_or_Ward_rerun':False,'complete_sourcefree_Slavnov_E5_A5_or_authority_change':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
