# Exact-once integration of the complete measured ghost companions V1

Baselineebd03508a4a0897a600352b1cc307d28e8a24fb8. Question GGI1:can the
qualified7136-position ordinaryg3 ghost node be inserted exactly once in
the actual current Gamma recipe without changing any unrelated coefficient
or source projection? Reproduce incoming147266words/hashc445c2... first.
This is authenticated coefficient assembly,no new amplitude or identity.

Freeze code,record,controllers,livepolicy,qualified complete ghost receipt,
current auxiliary-companion recipe and all inherited inputs before two
sequential180-second-after-import/8GiB private workers,minimum350MiB
available commit. Existing whole-recipe reconstruction used about100seconds;
180seconds is declared here for this separate integration task,not an
extension of the prior120-second coefficient/Ward contract. Independent
ordinary-SymPy validator180seconds/8GiB. Preserve failures/captures;no
truncation or automatic zero on exhaustion. No peer output read by workers.

Primary grouped exact sums;replay explicit per-word insertion. Reconstruct
same old functional,compare old hash/all coefficients,show exact inverse
addition,detect doubling,report newly present/changed old words and retain
the lossless recipe. Verify every current ordinaryg3AaC/BaC onejet
predecessor was absent before insertion and equals the actual measured
node afterward. Reconcile current selectedg3 local-H input with the
qualified prior theorem;do not rerun its loop or full H calculation.
Check all source coefficients/untouched words unchanged. Independent
ordinary-SymPy full recipe,hash/addition/inverse and selected input checks.
Multiple methods share action/inputs/software/AI author,not independent
scientists. No authority,physical input,benchmark,scheme or remote action.

Possible outcomes:qualified exact-once assembly,proven duplicate/input
discrepancy,or bounded inconclusive. Updating the partial functional is
not source-free profile completeness,simultaneous Slavnov or fullE5/A5.
Keep38-source and qualifiedselectedH/bilinear scopes,all quantum measure,
nonzeroJacobian,32products,128sourcejets,508Euler,QAP/contact/Legendre/IR,
quartet/scalar warnings,34/39,HB1/C5block,flavorpause,C1_GS,closedroutes,
custodyexit2/seven. No fresh custody adjudication or old loop replay.
NEXT:source-free obligation reconciliation using the updated lossless
recipe;prioritize genuine missing inputs versus mathematical prerequisites.
