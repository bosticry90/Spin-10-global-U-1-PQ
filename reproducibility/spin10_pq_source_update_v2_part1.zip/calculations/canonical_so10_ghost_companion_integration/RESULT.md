# Complete ordinary ghost companions integrated exactly once

Prospective until both captures,the independent receipt and committed-byte
verification complete. This assembles qualified coefficients;it performs
no new loop or Ward calculation and grants no new scientific authority.

The incoming recipe reproduces147266 canonical words and exact hash
c445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4.
The actual7136-position measuredg3AaC/BaC node supplies6112 new words and
changes1024 existing-word coefficients;no old word is removed. The updated
known partial functional contains153378words with hash
11940c31cdeffc61c21b074c6d4bb51245860082c1a86d395dedf879f2c87ccb.
Word counts are coordinate bookkeeping,not amplitude counts or E5 progress.

Subtracting the actual added node recovers every incoming coefficient
exactly. Adding it a second time changes the result. Every unrelated
coefficient and the entire source projection remain unchanged. The old
ordinaryg3 onejet AaC/BaC projection was zero;the updated projection is
exactly the independently measured node,without a fitted completion.
The current selectedg3 H-test input reproduces the already qualified
kinetic-plus-companion input. Its theorem is reused,not re-executed or
extended to a new target. The node's source-free/minimum-Q-field-count
qualifications are likewise inherited with their original scope.

Primary uses grouped exact sums;replay inserts by canonical word.
Independent ordinary-SymPy reconstruction verifies the complete old/new
hashes,all changed and untouched coefficients,inverse addition,doubling,
source projection and current selected input. The old functional is
materialized once in the independent route and its proof is reused across
the authenticated paired role data;this is not two fresh byte-identical
replays. Exact resources/failures are in captures/receipt. Shared action,
measured coefficients,recipe IO,software and AI author limit independence.

TrackB:value is a full coefficient-preserving assembly with explicit
omission/duplication controls after a complete small identity,rather than
another giant quantum variation. No existing qualified loop was repeated.
The earlier coefficient/Ward checkpoint's failed control and timeout
remain preserved there;this integration does not erase or reclassify them.

The next task is source-free coverage and dependency reconciliation using
integration.py current_tables(role). Distinguish measured complete poles,
complete zeros,conditional covariant completions,partial inputs,and
mathematical restoration prerequisites. Do not interpret a present field
word as complete loop-profile coverage or absent coefficients as zeros.
Do not assume derivativeghostg4 invariance or repeat wholeQGamma.

Source-dependent38-class theorem,selected ghost-H/auxiliary-H/bilinear
results retain their scopes. Simultaneous source-free Slavnov,E5/A5,QAP,
regulated measure,nonzeroJacobian,32products,128sourcejets,508Euler,
finite contacts,Legendre/IR/Legacy obligations remain. Authority34/39,
HB1/C5block,flavorpause,C1_GS,quartet/scalar physical warnings,closed
recovery domains and inherited custodyexit2/seven remain unchanged.
No fresh historical custody replay,Lean certificate,new physical inputs,
benchmark,scheme,foundation or remote action. Physical GUT viability and
the overall Spin(10) investigation are unfinished.
