# Seven-family ghost pole: canonical coefficients and complete selected H relation

Qualification requires the completed paired V2 captures,independent receipt
and committed-byte check. A primary output alone does not qualify this report.
This is a bounded ordinary one-loop local-log-pole result,not full E5/A5.

All seven measured families were combined in their actual common units.
FR's explicit vertex xi was included once;referenceH/M widths specialize
to eta_H/xi with separate provenance. No extra ghost or Bose half,no double
addition of DG3+DU or the two U orientations. Each complete physical R/Q
tensor has2514 nonzero entries and112911 zeros out of115425positions.
These are coefficient slots,not independent experiments or amplitudes.

The source-dual antighost chart,ghost chart and both A_H/B vector charts
give892 temporal coefficients per derivative placement. Four Lorentz
copies yield7136 canonical positions:1616AaC and5520BaC. All inverse
roundtrips and fixed-order real-chart antilinear maps are checked;this
does not introduce an unproved odd-field Hilbert-adjoint convention.
Primary contracts three indices directly;replay uses successive reversed
axis contractions. Independent ordinary-SymPy contractions and even-H
action check actual complete tensors and coefficients,not a probe only.

The selected g3 Omega-a-C two-jet local-H relation is exactly zero as a
raw density. Its Omega Euler anchor and all four aggregate currents are
zero as well. Individual kinetic/A/B variations are nonzero and their
anchors/current terms are retained. Both affine connections matter.
The actual classical operator and qualified local envelope reproduce
every admitted predecessor:Ca twojet g2,AaC onejet g3,BaC onejet g3.
All96 affine columns and parameter derivatives are retained. No EOM,
new loop or coefficient fit supplies this cancellation.

The first primary failed at an incorrect assertion requiring FR xi
omission to affect this selected Ward anchor. FR,DG3 and DU separately
have zero selected affine anchors,so their omission controls here are
insensitive. Their full coefficients are still independently checked.
V2 preserves the failure and proves the direct coefficient-level FR-xi
control instead. DF,FFF,FFG3,FFU,kinetic and either affine connection
omissions change the anchor;doubling/reversing the new node does too.
Do not use the selected zero as a normalization proof for insensitive
families. Completed captures/receipt give exact resources and failures.

No Gamma integration or whole-functional expansion was performed.
Gamma remains147266 words/hashc445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4.
The next smallest action is qualified exact-once/inverse-addition integration
of this measured node,then a source-free coverage reassessment. Do not
claim the derivative node's homogeneousg4 Ward variation vanishes;g4
can require independent quartic companions. The current selectedg3
result does not close those companions or simultaneous source-free Slavnov.

The node contains no sources and its field-Q image has minimum field
count3 with no physical Euler program,so existing38-source,bilinear
and auxiliary-H scopes are preserved. FullQGamma/508Euler values were
not evaluated. Quantum equivalence,QAP,regulated measure,nonzero Jacobian,
32products,128sourcejets,finite contacts,Legendre/IR/Legacy obligations
remain. Formal authority34/39,HB1/C5block,flavorpause,C1_GS,quartet/scalar
quantum-control warnings,closed recovery routes,custodyexit2/seven remain.

TrackB:the finite coefficient assembly and complete small local test
reuse qualified loops without a large functional expansion. Verification
caught an overstrong negative-control oracle;the failure is preserved.
Routes share measured action/conventions,charts,source catalogue,software
and AI authorship. Their agreement corroborates arithmetic and assembly,
not shared physical premises,independent expert validation or nature.
No current Lean certificate or new benchmark/physical-theory claim.
