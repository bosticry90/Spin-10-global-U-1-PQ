"""Complete measured seven-family sum, exact chart pullback and selected even-H test."""
from pathlib import Path
from collections import defaultdict
from functools import lru_cache
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_actual_canonical_helpers',OUT.parent/'canonical_so10_auxiliary_vector_canonical/canonical.py');q=a.q;m=a.m;l=a.l;h=a.h;s=a.s;ex=m.ex;read=q.read;digest=q.digest;PKG=q.PKG
from a10_e5_measured_functional_v3 import frames
@lru_cache(None)
def num(z):return ex.coefficient(s.sympify(z,locals={'reference_width_H':ex.widthH,'reference_width_M':ex.widthM,'xi':ex.widthM,'eta_H':ex.widthH}))
def put(P,k,z):
    if not z:return
    v=P.get(k,ex.ZERO)+z
    if v:P[k]=v
    else:P.pop(k,None)
def add(*Ps):
    Z={}
    for P in Ps:
        for k,z in P.items():put(Z,k,z)
    return Z
def pack(P):return [[*k,str(ex.D.to_sympy(z))] for k,z in sorted(P.items())]
def unpack(rows,offset=0,factor=None):
    P={}
    for v,i,j,z in rows:
        assert 0<=v+offset<57 and 0<=i<45 and 0<=j<45
        put(P,(v+offset,i,j),num(z)*(factor if factor is not None else num('1')))
    assert len(P)==len(rows)
    return P
def auth(folder,name):
    p=OUT.parent/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def families(role):
    fr=auth('canonical_so10_ghost_companion_FR',role+'_result.json');db=auth('canonical_so10_ghost_companion_D_bubbles',role+'_result.json');df=auth('canonical_so10_ghost_companion_DF',role+'_result.json');fff=auth('canonical_so10_ghost_companion_FFF',role+'_v2_result.json');ffb=auth('canonical_so10_ghost_companion_FF_bosonic',role+'_result.json')
    assert 'g10^3*xi/' in fr['normalization'] and fr['explicit_vertex_xi_retained']
    F={'FR':(unpack(fr['physical_B_dV_ordered_aC_tensor'],12,num('xi')),{}),'DG3':(unpack(db['physical_DG3_B_divergence_aC'],12),{}),'DU':(unpack(db['physical_DU_A_and_B_divergence_aC']),{}),'DF':(unpack(df['physical_divergence_vector_aC']),unpack(df['physical_vector_a_derivative_C'])),'FFF':(unpack(fff['physical_divergence_vector_aC']),unpack(fff['physical_vector_a_derivative_C']))}
    for n,k in [('FFG3','G3'),('FFU','U_sum')]:F[n]=(unpack(ffb['physical_tensors'][k]['r']),unpack(ffb['physical_tensors'][k]['q']))
    assert add(F['DG3'][0],F['DU'][0])==unpack(db['physical_combined_A_and_B_divergence_aC'])
    assert F['DF'][0]==add(*(unpack(v) for k,v in df['four_assignment_derivative_pieces'].items() if k[0]=='a')) and F['DF'][1]==add(*(unpack(v) for v in df['four_assignment_derivative_pieces'].values()))
    assert F['FFU']==tuple(add(unpack(ffb['physical_tensors']['UBL'][k]),unpack(ffb['physical_tensors']['ULB'][k])) for k in ['r','q'])
    return F,unpack(fr['physical_B_dV_ordered_aC_tensor'],12)
def matrix(A):return {(i,j):num(str(s.expand(z))) for (i,j),z in A.todok().items() if s.expand(z)}
def charts(role):
    w,sub,back,source,anti,Cinv,Cphys=frames(role);assert (source.T*anti).applyfunc(s.expand)==s.eye(45) and (Cphys*Cinv).applyfunc(s.expand)==s.eye(45)
    V=s.diag(Cphys[:12,:12],Cphys);Vi=s.diag(Cinv[:12,:12],Cinv);Cstar=Cinv.conjugate()*Cphys
    return list(map(matrix,[V,source.T,Cphys,Vi,anti,Cinv,s.diag(Cstar[:12,:12],Cstar),anti.conjugate()*source.T,Cstar]))
def transform(P,matrices,role):
    rows=[]
    for A in matrices:
        D=defaultdict(list)
        for (i,j),z in A.items():D[i].append((j,z))
        rows.append(D)
    if role=='primary':
        Z={}
        for (v,i,j),z in P.items():
            for x,c in rows[0][v]:
                for y,d in rows[1][i]:
                    for t,e in rows[2][j]:put(Z,(x,y,t),z*c*d*e)
        return Z
    Z=P
    for axis in [2,1,0]:
        W={}
        for key,z in Z.items():
            for k,c in rows[axis][key[axis]]:
                new=list(key);new[axis]=k;put(W,tuple(new),z*c)
        Z=W
    return Z
def conj(z):return num(str(s.conjugate(ex.D.to_sympy(z))))
def node(R,Q):
    Z={}
    for tag,P in [('R',R),('Q',Q)]:
        for (v,i,j),z in P.items():
            na=m.index[('bar' if i<12 else 'ub')+str(i)];nc=m.index['C'+str(j)]
            for mu in range(4):
                nv=m.index[('A'+str(v) if v<12 else 'B'+str(v-12))+'_'+str(mu)];word=((na,()),(nv,(mu,) if tag=='R' else ()),(nc,(mu,) if tag=='Q' else ()));key,sg=m.word_product((),word);m.put(Z,(3,key),m.cscale(z,sg*(1 if mu==0 else -1)))
    return Z
def typ(key):return tuple(sorted(h.kind(n) for n,j in key))
def H_inputs(role):
    tb=read(PKG/f'frozen_a10_e3_symmetry/{role}.json')['operators']['Tb_geometric_and_transported'];O={m.index[f'omega{i}'] for i in range(12)};free=m.fields|{m.index[f'A{i}_{mu}'] for i in range(12) for mu in range(4)};TI={i:m.decode(tb[m.names[i]]) for i in free if not m.names[i].startswith('x_')};sig=set();aff=set()
    for n,rows in tb.items():
        if m.index.get(n) in m.sources:assert all(any(m.token(k)[0] in m.sources for k in r['word']) for r in rows);continue
        if m.index.get(n) not in free:continue
        for r in rows:
            key=tuple(m.token(k) for k in r['word']);om=[(v,j) for v,j in key if v in O];other=[(v,j) for v,j in key if v not in O];assert len(om)==1 and len(other)<=1
            for gp,z in m.coefficient_terms(r['coefficient']):
                if other:assert not om[0][1] and not other[0][1] and h.kind(other[0][0])==h.kind(m.index[n]) and gp==1;sig.add((h.kind(m.index[n]),h.kind(other[0][0]),0,1))
                else:assert h.kind(m.index[n]) in ['A','B'] and gp==0 and len(om[0][1])==1;sig.add((h.kind(m.index[n]),None,1,0));aff.add(n)
    env=auth('canonical_so10_e5_remaining_obligations',role+'_result.json')['coarse_sourcefree_type_envelope'];routes=set()
    for ts,j,cd in env:
        if cd:continue
        ts=tuple(ts)
        for before,after,jq,gq in sig:
            for pos,t in enumerate(ts):
                if t==before and tuple(sorted(ts[:pos]+ts[pos+1:]+((after,) if after else ())))==('C','a') and j+jq==2:routes.add((ts,j,3-gq,before,after,jq,gq))
    proof=auth('canonical_so10_sourcefree_reconciliation',role+'_result.json');expected=proof['current_selected_Ward_gaps']['ghost']['predecessor_routes'];assert sorted(routes,key=str)==sorted([(tuple(ts),*rest) for ts,*rest in expected],key=str) and sorted(aff)==proof['actual_affine_connection_columns'] and len(aff)==96
    return TI,O,expected,sorted(aff)
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation_v2.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]};opened=set()
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('GHOST_CANONICAL_WRITE')
        if p.suffix=='.json':
            assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p));opened.add(str(p.resolve()))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();r=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return r
    m.setup();F,bareFR=stage('actual_seven_family_sum_and_normalizations',lambda:families(role));R=add(*(v[0] for v in F.values()));Q=add(*(v[1] for v in F.values()));assert all(conj(z)==z for P in [R,Q] for z in P.values());V,A,C,Vi,Ai,Ci,SV,SA,SC=stage('actual_complete_A_B_antighost_and_ghost_charts',lambda:charts(role))
    rawR=stage('complete_R_pullback',lambda:transform(R,[V,A,C],role));rawQ=stage('complete_Q_pullback',lambda:transform(Q,[V,A,C],role))
    for physical,raw in [(R,rawR),(Q,rawQ)]:assert transform(raw,[Vi,Ai,Ci],role)==physical and transform({k:conj(z) for k,z in raw.items()},[SV,SA,SC],role)==raw
    P=node(rawR,rawQ);assert P and all(typ(key) in [('A','C','a'),('B','C','a')] and sum(len(j) for n,j in key)==1 for gp,key in P);nodeRows=a.raw_node(P);assert m.decode(nodeRows)==P
    core=auth('canonical_so10_ghost_kinetic_canonical',role+'_v4_result.json');K=m.decode(core['new_actual_g2_ghost_kinetic_node']);assert K and all(gp==2 and typ(key)==('C','a') and sum(len(j) for n,j in key)==2 for gp,key in K)
    TI,O,routes,aff=stage('actual_H_operator_and_exhaustive_selected_predecessors',lambda:H_inputs(role));T0={i:{key:z for key,z in p.items() if key[0]==0} for i,p in TI.items()};T1={i:{key:z for key,z in p.items() if key[0]==1} for i,p in TI.items()}
    def act(P,I):return m.action(P,I,'primary',True) if role=='primary' else m.action(P,I,'replay')
    def project(P):return {key:z for key,z in P.items() if key[0]==3 and tuple(sorted(h.kind(n) for n,j in key[1] if n not in O))==('C','a') and sum(len(j) for n,j in key[1])==2}
    AK=stage('kinetic_homogeneous_H',lambda:project(act(K,T1)));AP=stage('new_node_affine_H',lambda:project(act(P,T0)));total=m.add(AK,AP);anchor,J=q.anchor(total,O);assert total==m.add(anchor,*(m.D(p,mu) for mu,p in enumerate(J))) and not any(m.EL_all(m.add(total,m.scale(anchor,-1)),O).values())
    pieces={}
    for label,W in [('kinetic',AK),('A',project(act({key:z for key,z in P.items() if typ(key[1])==('A','C','a')},T0))),('B',project(act({key:z for key,z in P.items() if typ(key[1])==('B','C','a')},T0)))]:
        N,I=q.anchor(W,O);pieces[label]={'raw':l.rows(W),'anchor':l.rows(N),'four_currents':list(map(l.rows,I))}
    assert total==m.add(*(h.from_result(p['raw']) for p in pieces.values()))
    controls={};familyAnchors={}
    for label,(r,qq) in F.items():
        pr=node(transform(r,[V,A,C],role),transform(qq,[V,A,C],role));W=project(act(pr,T0));N,I=q.anchor(W,O);familyAnchors[label]=l.rows(N);controls['omit_'+label+'_changes_selected_anchor']=bool(N)
    controls['omit_kinetic_changes_selected_anchor']=bool(q.anchor(AK,O)[0]);controls['omit_A_affine_changes_selected_anchor']=bool(h.from_result(pieces['A']['anchor']));controls['omit_B_affine_changes_selected_anchor']=bool(h.from_result(pieces['B']['anchor']));controls['duplicate_node_changes_selected_anchor']=bool(q.anchor(AP,O)[0]);controls['reverse_node_changes_selected_anchor']=controls['duplicate_node_changes_selected_anchor']
    wrongFR=node(transform(bareFR,[V,A,C],role),{});controls['drop_explicit_FR_xi_changes_selected_anchor']=bool(q.anchor(project(act(m.add(wrongFR,m.scale(node(transform(F['FR'][0],[V,A,C],role),{}),-1)),T0)),O)[0]);controls['drop_explicit_FR_xi_changes_actual_coefficients']=wrongFR!=node(transform(F['FR'][0],[V,A,C],role),{});assert controls['drop_explicit_FR_xi_changes_actual_coefficients'] and controls['omit_kinetic_changes_selected_anchor']
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');used={n for gp,key in P for n,j in key if n in m.fields};assert all(e2['complete_columns'][m.names[i]]['physical_program'] is None and all(len(r['word'])>=1 and not any(m.token(t)[0] in m.sources for t in r['word']) for r in e2['complete_columns'][m.names[i]]['source_polynomial']) for i in used)
    result={'schema':'COMPLETE_GHOST_CANONICAL_AND_SELECTED_H_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_GHOST_H_ZERO_MOD_CURRENT' if not anchor else 'COMPLETE_SELECTED_GHOST_H_NONZERO_REMAINDER','physical_R':pack(R),'physical_Q':pack(Q),'raw_chart_R':pack(rawR),'raw_chart_Q':pack(rawQ),'full_positions_per_derivative':115425,'physical_zero_complements':{'R':115425-len(R),'Q':115425-len(Q)},'all_charts_inverse_roundtrip_and_formal_antilinear_reality':True,'seven_families':{n:{'R_nonzero':len(r),'Q_nonzero':len(qq)} for n,(r,qq) in F.items()},'FR_explicit_vertex_xi_multiplied_once':True,'width_reference_specialization':{'H':'eta_H','M':'xi','FR_vertex':'explicit xi,not a propagator factor'},'actual_g3_ghost_companion_node':nodeRows,'new_node_positions':len(P),'complete_predecessor_routes':routes,'actual96_affine_columns':aff,'complete_selected_input':l.rows(m.add(K,P)),'complete_selected_raw_Ward':l.rows(total),'complete_selected_Omega_anchor':l.rows(anchor),'four_explicit_IBP_currents':list(map(l.rows,J)),'complete_relation_zero_mod_current':not anchor,'complete_raw_density_zero':not total,'individual_predecessor_pieces':pieces,'individual_family_anchors':familyAnchors,'controls':controls,'insensitive_controls':[k for k,v in controls.items() if not v],'parameter_jets_and_Euler_current_identity_checked':True,'sourcefree_Q_minimum_field_count3_preserves_prior_scopes':True,'homogeneous_g4_ghost_relation_claimed':False,'Gamma_integration_or_full_expansion_or_new_loop':False,'full_E5_A5_QAP_IR_physical_claim_or_authority_change':False,'read_JSON':sorted(opened),'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
