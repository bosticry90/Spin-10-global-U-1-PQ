# Structural reduction of repeated independent affine controls

The first ordinary-SymPy verifier exhausted120seconds after entering the
full even-H check;no receipt was issued. Preserve exact code/preparation,
complete capture and exit124. This is incomplete verification,not a
scientific failure or a qualified zero. Native paired evidence remains.

The validator repeated full57-background pullbacks for each family merely
to evaluate its affine variation. ActualH has affine columns only inA_H
andB_H;the qualified vector chart and its inverse are block diagonal in
H/M. Therefore physical vector indices0..23 exhaust that affine image.
V2 proves that support from the actual operator/chart before restricting
these individual-family controls. Full combined R/Q,all raw coefficients,
inverse/conjugation,complete raw Ward/anchor/currents and full predecessor
coverage remain required. No coefficient or assumption is changed.

The FR factor control uses the established injective chart to compare
the physical coefficient tensor with and without explicitxi;its affine
anchor is zero. Do not redo irrelevant coset pullbacks to establish it.
Add stage markers. One corrected independent verifier,same120s/8GiB,
under standing delegation. No native or loop reruns,no resource increase,
no truncated evidence. A second exhaustion requires reassessment.
