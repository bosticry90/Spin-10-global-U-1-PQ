# Complete measured ghost companions: canonical extraction and selected H test V1

Baseline 602528af4af2aa2c4703237fe527778f49b4b429. Question GCH1: do the
seven independently measured ordinary g3 AaC/BaC one-jet families, with
their actual normalizations, satisfy the complete selected g3 Omega-a-C
two-jet local-H relation together with the measured g2 ghost kinetic pole?
First qualify the full canonical tensors rather than reconstructing Gamma.

Freeze this record, sources/controllers, live policy, role-separated five
family records/receipts (seven families,119 profiles/524 rooted cycles),
g2 canonical kinetic inputs and actual classical coordinate/H/E2 operators
before execution. Two sequential workers:120 seconds after imports,8GiB
sampled private memory,350MiB minimum available commit. Independent validator
same limits. No peer answers or desired Ward coefficients as worker input.
Preserve failures and captures. Exhaustion is incomplete, never a zero.

R represents (partial V) a C; Q represents V a partial C; all four Lorentz
copies use eta=(1,-1,-1,-1). All tables use hbar*g10^3/(32*pi^2*epsilonUV),
except FR which additionally needs its explicit vertex xi. Retain this
provenance separately before identifying reference_width_M with actual xi
and reference_width_H with eta_H. FR/DG3 B indices require a12 offset;
other tensors already use57 backgrounds. Add DU once and U_sum once.
No extra ghost/Bose half. Do not add combined tables a second time.

Primary:direct exact-field three-index pullback. Replay:successive axis
contractions in reverse order. Check all115425 slots per derivative tensor,
zero complements,physical reality,complete source-dual antighost/ghost/
A_H/B charts,inverse roundtrip and fixed-order antilinear real-chart map.
This last map is not a new odd-field Hilbert adjoint convention. Independent
ordinary-SymPy coefficient contractions and even derivation must reproduce
the actual canonical coefficients,raw Ward remainder,Euler anchor and
four currents. Shared measured inputs,action,charts,catalogue,software and
AI authorship limit independence;no independent scientist claim.

Use actual transported even H operator,all96 affine connection columns,
parameter jets and previously qualified local operator envelope to prove
complete selected predecessor classes:Ca two jets atg2,AaC/BaC one jet atg3.
Use the actual -a H Box C kinetic representative and retain current data.
No EOM or fitted coefficients. A complete zero modulo explicit currents or
a complete nonzero remainder are both valid scientific outcomes. A nonzero
remainder is not automatically an anomaly. Do not demand homogeneousg4
invariance of this derivative node;that is a different target with possible
quartic companions. Preserve all measured family evidence unchanged.

Controls omit families/predecessors,either affine connection,explicit FR
xi,or reverse/double the new coefficients. Report insensitive controls.
Check source-free field variation/minimum field count to preserve existing
38-source,bilinear and auxiliary-H scopes. No full Gamma materialization,
integration,new loop,508 Euler values,whole-QGamma or new curve in this
increment. Exact-once/inverse-addition Gamma integration is a later bounded
action after this input check. Gamma147266/hashc445c2... remains unchanged.

No promotion beyond bounded coefficient/selected local-pole statement.
Full source-free Slavnov,E5/A5,QAP,measure/contact/Legendre/IR,nonzero
Jacobian,32 products,128 source jets,quartet and scalar quantum-control
warnings remain. Authority34/39,HB1/C5 block,flavor pause,C1_GS,custody
exit2/seven and closed recovery domains remain. No physical input,scheme,
benchmark,foundation,policy,authority or remote action;education nonblocking,
Lean selective. Validate before local commit;no branch/worktree.
