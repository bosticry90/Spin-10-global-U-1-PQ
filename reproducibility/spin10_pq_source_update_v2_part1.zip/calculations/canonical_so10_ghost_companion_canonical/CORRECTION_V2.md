# Correct the insensitive FR Ward control

V1 primary exited1 at the last control assertion after completing coefficient
pullback and the selected variation. No result/qualification was produced.
The code incorrectly demanded that removing explicit FR xi change the
selected Omega-a-C anchor. The FR tensor has no affine local-H support,so
that selected target is insensitive. RECORD already requires reporting
insensitive controls. Preserve the complete original code/capture.

V2 retains every coefficient,chart,predecessor and Ward check and reports
the insensitive control honestly. Add the proper direct normalization
control:the canonical FR coefficients differ when its explicit xi is
omitted. This does not infer FR correctness from a Ward cancellation.
One corrected primary under standing delegation,same120s/8GiB limits;
the original replay remains. Freeze both revised code/controller and all
failed evidence before launch. No physical changes or weakened evidence
obligation;no automatic Ward-zero assumption.
