# Intrinsic g10^3*xi Jx*C pole V1

Baseline2d034c85d98e0d4dd9b91e605e9c40bdd50306dc; standing AGENTS delegation.
Question: actual complete one-loop intrinsic dimension-one no-jet scalar-source
pole in the full Cartesian x ring. V199 fixes both proper families and all328
scalar/45 ghost slots; V200 fixes bubble/triangle units -2,+2,-2,0. No omitted
color or Lorentz correlation is used to assume a nonzero result. Possible
outcomes: measured pole, complete zero, or a failed applicability/input check.

Keep actual scalar source q (Qx=g*q(C)x), nonminimal antighost transformation
Qa=L+g*A(a,C), quantum gauge source f (QB=partial C+g*f(B,C)+...), principal
gauge-fixing metric H, orbit quadratic O (g*xi*L*O*x), orbit ghost/scalar B
(g^2*xi*a*C*x), all three derivative placements F of a*C*B and full retained
ghost/mixed/scalar reference inverses. Ghost/antighost and vector/Lambda
indices are not Euclidean Kronecker deltas in the C3 chart. Scalar inverse
is checked on all328 coordinates. Include Qanti's nonminimal term: it can
cancel the H-ghost part of orbit and ordinary gauge-fixing vertices. Never
reconstruct those vertices from Qx or QB alone.

Primary extracts ordered coefficients from the full source/GF polynomials,
contracts actual R=Q*G(C,a), K=Q*G(B,L)/(i*q_mu), scalar identity, B,F,O with
the measured units. Replay extracts actual source columns and reconstructs
the GF interaction using both Qanti and Qx/QB. Require complete exact identities
B[n,m,j]=sum_l A[l,n,m]*O[l,j]-sum_k O[n,k]*q[m,k,j], and
sum_b R[a,b]*(F_a-F_B)[b,m,p]
 =f[a,p,m]-sum_{i,b}R[a,b]*A[i,b,m]*H[i,p].
These are precontraction action checks, not a pole inferred from restoration.
Verify H*R,R*H,H*K,K*H=I, both inverse orientations, all4 Lorentz placements,
all fixed scalar-source/evaluation-dual signs. Derivative on external ghost
has zero no-jet unit but its literal tensor remains retained. Each route
contracts its independently organized sparse indices and compares complete
family tables and zero complements, not selected examples.

Source ordered unit is -J*c*chi, so A_source=-q. Bubble coefficient is
-2*sum A_source*R*B; triangle is +2*sum A_source*R*(F_a-F_B)*K*O.
Common hbar*g10^3*xi/(32*pi^2*epsilon_UV), coefficient mass dimension1 inherited
from frozen orbit/vacuum tensors. No extra half, gauge/color multiplicity or
assumed physical source chart. Export the complete C3 evaluation-dual Jx,C
coefficient table and all14760 positions by nonzero rows plus explicit zero
domain. Any physical-real chart/canonical integration is a separate check.

Controls omit either nonzero family (if it is nonzero), reverse source order,
halve a vertex, replace R/K with a false identity and omit the Qanti correction.
Report insensitive controls honestly; do not require every mutation to affect
every sector. Check sqrt(2,3,5,7),I arithmetic and exact table roundtrips. Reuse
the positive scalar reference log residue without rerunning old integrals.
Full-x versus x=v+eta specialization and known dimension-zero pole translations
stay separate. Do not update Gamma or calculate a Slavnov remainder here.

Two sequential120-second/8GiB workers and separate120-second/8GiB validator,
minimum350MiB available commit. Freeze sources/controllers/inputs/allowlists
before computation; preserve failures/version corrections, no silent retries
or resource growth. Authenticate historical bounded columns without promoting
the old failed master gate or rebinding its policies. No input, benchmark,
foundation, authority or remote change. Shared classical action, software,
conventions and AI authorship limit independence; no external validation.

Ceiling: this one complete intrinsic local UV coefficient, not all source
closure, E5/A5, QAP/measure/contact/IR, anomaly freedom or physical viability.
HB1/C5 blocked, flavor paused,C1_GS uncomputed,scalar warning,quartet failure
and custodyexit2/seven remain. Education voluntary/concurrent/nonblocking.
Track A closes a dependency-critical coefficient; Track B tests whether actual
nonminimal transformations and reference metrics are respected, not fitted.
