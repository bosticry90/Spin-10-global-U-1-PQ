# Full antighost affine-sign reconstruction V3

V2 primary passed the actual negative principal-metric identities, then stopped
before pole contraction at ORBIT_VERTEX_RECONSTRUCTION. Preserve its complete
source/snapshot/preparation/capture. The proposed reconstruction still assumed
Qa=+L+g*A. Actual immutable source columns give Qa=-L+g*A in every one of45
directions. That sign must be checked rather than imported from a textbook or
an abstract loop vertex. The old pole kernels are unchanged.

For the literal orbit quadratic +g*xi*L*O*x, the corresponding gauge fermion
is -g*xi*a*O*x. Graded Q with Qa=-L+g*A therefore gives
B=O*q-A*O, not its negative. For principal L*H*partial B, gauge fermion is
-a*H*partial B; its no-jet F reconstruction is
R*(F_a-F_B)=f+R*A*H, using H*R=-I.
These are fixed precontraction action identities. Check all45 actual affine
columns exactly as -L, both full polynomials/column extractions, every tensor
entry and both reference orientations before evaluating any pole. Print exact
residual signatures/examples if the assertion fails, then stop; do not select
signs by requiring a desired loop cancellation. Actual B,F contractions and
unit values remain identical to V1/V2.

New bounded V3 primary/replay: two sequential120-second/8GiB runs plus a
separate120-second/8GiB validator under standing delegation, minimum350MiB
available commit. No resources or scientific scope expanded. Repeated failures
here exposed incorrect reconstruction assumptions, not physics exclusions.
Retain both as Track B evidence of convention-checking failures. Every other
scientific acceptance obligation/ceiling in RECORD remains in force; neither
failed version produced a quantum coefficient.
