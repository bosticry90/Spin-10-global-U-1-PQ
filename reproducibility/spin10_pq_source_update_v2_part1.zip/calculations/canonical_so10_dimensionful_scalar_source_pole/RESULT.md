# Intrinsic dimension-one scalar-source pole is nonzero

Qualification requires the completed validation receipt, not this prospective
report. Both actual g10^3*xi Jx*C proper-loop families give432 nonzero C3
coefficient positions and their sum also has432. All14760 scalar-source/ghost
positions are included, with14328 computed zeros. No coefficient was inferred
from a desired Ward or Slavnov cancellation.

The common factor is hbar*g10^3*xi/(32*pi^2*epsilon_UV); coefficients have mass
dimension1 through the frozen orbit/vacuum input. For example the source at
global scalar index5 and ghost15 has total coefficient -100 in these declared
coordinates/units. This is a UV source coefficient, not a measured coupling,
particle mass or physical threshold. C3 coefficients can be complex; a physical
real chart and canonical functional integration are not qualified here.

The two routes use full literal source/GF polynomials versus actual source
columns and a graded gauge-fermion reconstruction. They agree on every input
tensor signature, separate family coefficient, complete sum and zero domain.
Input tensors include29754 scalar-source entries,886 quantum-gauge entries,
180 nonminimal antighost entries,432 orbit quadratics,6688 orbit ghost/scalar
entries, all three derivative placements,47-entry ghost/mixed metrics and all
328 scalar reference inverses. All4 Lorentz copies and both inverse orientations
are checked; the same qualified -2,+2,-2,0 loop units are used.

Two failed primaries preceded the accepted V3 calculation. V1 imported a
positive principal-metric assumption; the literal gauge-fixing H instead obeys
H*R=H*K=-I. V2 corrected that but still assumed Qa=+Lambda+...; actual columns
give Qa=-Lambda+g*A in every one of45 directions. V3 checks that affine term
and reconstructs B=O*q-A*O and R*(F_a-F_B)=f+R*A*H exactly before contraction.
Neither failed version reached a pole calculation. All original contracts,
sources, preparations and complete captures remain preserved. These were
convention-recovery failures by the analyst, not quantum anomalies.

Omitting either measured family, reversing source order, halving the bubble
or replacing the nontrivial C3 reference metrics with false identities changes
the total. Omitting the nonminimal Qanti part changes BOTH interaction tensors
but is insensitive at the total pole: its two induced changes cancel because
H*K=-I. This explains why a right-looking final sum alone cannot validate a
vertex construction. The independent precontraction identities remain required.

V3 workers take about10.83 and12.70 seconds after imports. No old loop,
large Gamma/Q/Ward replay, canonical node or selected Slavnov test was run.
The two routes share action, conventions, exact arithmetic and AI authorship;
validation is bounded computational corroboration, not independent expert or
empirical validation. The unchanged scalar reference is temporary; no finite,
cutoff-power, scaleless UV-zero or physical IR-removal statement follows.

Next: retain this complete intrinsic coefficient, calculate the remaining
g10^4*xi JL*C*x group, then convert/integrate the missing dimensionful nodes
and known x=v+eta translations once. A complete relevant consistency relation
also needs its positive-dimensional Q/Euler predecessors; do not infer them
from the cancellation desired. QAP, measure, insertion/contact normalization,
power subtraction and physical IR prerequisites remain distinct open questions.

Authority34of39, full source/Slavnov/E5/A5 unqualified, HB1/C5 blocked, flavor
paused,C1_GS uncomputed, scalar warning, quartet failure,custodyexit2/seven
unchanged. No accepted input, benchmark, foundation, protected promotion or
remote change. Education remains voluntary/concurrent/nonblocking.
