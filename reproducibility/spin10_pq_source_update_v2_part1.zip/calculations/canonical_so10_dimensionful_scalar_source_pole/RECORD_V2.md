# Literal principal-sign correction V2

V1 primary stopped before any pole contraction: its required H*R=I assertion
was false. The extracted literal GF coefficient H in L*partial B has the
negative sign of the gauge fermion. Actual reference inverse signs are
unchanged: H*R=R*H=H*K=K*H=-I. V1's failure is an incorrect principal-sign
assumption in the proposed reconstruction, not a new quantum inconsistency.
Preserve V1 source/snapshot/preparation/complete failed capture permanently.

Retain every V1 input, dimension, full-domain, unit, orientation, control and
comparison requirement. Correct only the signed identity to -I and the
corresponding source reconstruction to
R*(F_a-F_B)=-f-R*A*H.
The actual bubble/triangle contraction uses literal B,F,R,K,O and the same
qualified units; it is unchanged. The independently reconstructed GF vertices
must still agree exactly at every position, including the Qanti correction.
No fitted sign or modified reference is allowed. Both V2 routes must run and
match; V1 produced no pole value to reuse. Two new sequential120-second/8GiB
workers plus separate120-second/8GiB validation under standing delegation,
no resource increase. Every scientific ceiling in RECORD remains binding.
