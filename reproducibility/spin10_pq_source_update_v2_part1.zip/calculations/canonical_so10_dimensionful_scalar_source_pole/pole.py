"""Complete intrinsic dimension-one scalar-source pole, explicit C3 metrics."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import importlib.util,json,os,re,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('qualified_scalar_exact',ROOT/'calculations/canonical_so10_scalar_source_g3_color/scalar_exact.py');ex=importlib.util.module_from_spec(sp);sp.loader.exec_module(ex)
put,add,ZERO=ex.put,ex.add,ex.ZERO
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
g,xi=s.symbols('g10 xi');mom=s.symbols('p0_ref0:4');Q=mom[0]**2-sum(p*p for p in mom[1:]);ETA=(1,-1,-1,-1)
SEC={'Phi':(0,54),'Sigma':(54,252),'phi':(306,20),'S':(326,2)}
def scalar(n):
    m=re.fullmatch(r'J?x_(Phi|Sigma|phi|S)_(\d+)',n);assert m,n;offset,dim=SEC[m[1]];assert int(m[2])<dim;return offset+int(m[2])
def anti(i):return ('bar' if i<12 else 'ub')+str(i)
def aux(i):return ('b' if i<12 else 'L')+str(i)
def unjet(n):a,sep,j=n.partition('__');return a,tuple(map(int,j))
@lru_cache(None)
def coefficient(text,gp,xp):
    p=s.Poly(s.sympify(text),g,xi);assert set(p.monoms())=={(gp,xp)},(text,gp,xp);return ex.coefficient(p.coeff_monomial(g**gp*xi**xp))
def pack(P):return [list(key)+[str(ex.D.to_sympy(z))] for key,z in sorted(P.items())]
def signature(P):return {'entries':len(P),'sha256':sha256(json.dumps(pack(P),separators=(',',':')).encode()).hexdigest()}
def columns(route):
    d=read(PKG/f'frozen_a10_bv_master/{route}.json');qs={};f={};A={};counts=Counter()
    def absorb(output,word,z):
        names=[n for n,j in word];jets=[j for n,j in word]
        if output.startswith('x_'):
            assert len(word)==2 and not any(jets);C=next(n for n in names if re.fullmatch(r'C\d+',n));x=next(n for n in names if n.startswith('x_'));put(qs,(scalar(output),int(C[1:]),scalar(x)),z);counts['SX']+=1
        elif re.fullmatch(r'B\d+_[0-3]',output):
            if len(word)!=2 or any(jets) or not any(n.startswith('B') for n in names):return
            B=next(n for n in names if n.startswith('B'));C=next(n for n in names if re.fullmatch(r'C\d+',n));p,mu=map(int,B[1:].split('_'));out,nu=map(int,output[1:].split('_'));assert mu==nu
            key=(out,p,int(C[1:]));counts['QB_mu'+str(mu)]+=1
            return ('f',mu,key,z)
        elif output in {anti(i) for i in range(45)}:
            if len(word)!=2 or any(jets):return
            C=next(n for n in names if re.fullmatch(r'C\d+',n));a=next(n for n in names if n.startswith(('bar','ub')));i=int(re.search(r'\d+',output)[0]);n=int(re.search(r'\d+',a)[0]);sign=-1 if names.index(C)<names.index(a) else 1;put(A,(i,n,int(C[1:])),sign*z);counts['QA']+=1
    fs=[{} for mu in range(4)]
    if route=='primary':
        for row in d['source_polynomial']:
            word=[unjet(n) for n in row['word']];sources=[n for n,j in word if n.startswith('J')];assert len(sources)==1;J=sources[0]
            if not J.startswith(('Jx_','JB','Jbar','Jub')):continue
            other=[p for p in word if p[0]!=J]
            if len(other)!=2:continue
            names=[n for n,j in word];ghosts=[n for n,j in word if re.fullmatch(r'C\d+',n)]
            if len(ghosts)!=1:continue
            C=ghosts[0];sg=-1 if J.startswith(('Jx_','JB')) and names.index(C)<names.index(J) else 1
            result=absorb(J[1:],other,sg*coefficient(row['coefficient'],1,0))
            if result:label,mu,k,z=result;put(fs[mu],k,z)
    else:
        for output,rows in d['source_only_columns'].items():
            if not output.startswith(('x_','B','bar','ub')):continue
            for row in rows:
                word=[unjet(n) for n in row['word']]
                if len(word)!=2 or not any(re.fullmatch(r'C\d+',n) for n,j in word):continue
                result=absorb(output,word,coefficient(row['coefficient'],1,0))
                if result:label,mu,k,z=result;put(fs[mu],k,z)
    assert all(v==fs[0] for v in fs);f=fs[0]
    return qs,f,A,dict(counts)
def fix_and_reference(route):
    d=read(PKG/f'frozen_a10_e2_transport/{route}.json');O={};B={};H=[{} for i in range(4)];F={where:[{} for i in range(4)] for where in ['a','B','c']};counts=Counter()
    for row in d['gauge_fixing_density']:
        fields=[unjet(n) for n in row['word']];names=[n for n,j in fields];a=[n for n in names if n.startswith(('bar','ub'))];L=[n for n in names if re.fullmatch(r'(L|b)\d+',n)];C=[n for n in names if re.fullmatch(r'C\d+',n)];X=[n for n in names if n.startswith('x_')];V=[n for n in names if re.fullmatch(r'B\d+_[0-3]',n)]
        if len(fields)==2 and L and X:
            assert not any(j for n,j in fields);put(O,(int(re.search(r'\d+',L[0])[0]),scalar(X[0])),coefficient(row['coefficient'],1,1));counts['O']+=1
        elif len(fields)==3 and a and C and X:
            assert not any(j for n,j in fields);sg=-1 if names.index(C[0])<names.index(a[0]) else 1;put(B,(int(re.search(r'\d+',a[0])[0]),int(C[0][1:]),scalar(X[0])),sg*coefficient(row['coefficient'],2,1));counts['B']+=1
        elif len(fields)==2 and L and V:
            p,mu=map(int,V[0][1:].split('_'));assert fields[names.index(V[0])][1]==(mu,);put(H[mu],(int(re.search(r'\d+',L[0])[0]),p),ETA[mu]*coefficient(row['coefficient'],0,0));counts['H_mu'+str(mu)]+=1
        elif len(fields)==3 and a and C and V:
            p,mu=map(int,V[0][1:].split('_'));differentiated=[n for n,j in fields if j];assert len(differentiated)==1 and fields[names.index(differentiated[0])][1]==(mu,);where='a' if differentiated[0]==a[0] else 'c' if differentiated[0]==C[0] else 'B';sg=-1 if names.index(C[0])<names.index(a[0]) else 1;key=(int(re.search(r'\d+',a[0])[0]),int(C[0][1:]),p);put(F[where][mu],key,sg*ETA[mu]*coefficient(row['coefficient'],1,0));counts['F_'+where+'_mu'+str(mu)]+=1
    assert all(v==H[0] for v in H)
    for where in F:assert all(v==F[where][0] for v in F[where]);F[where]=F[where][0]
    H=H[0];refdata=read(PKG/f'frozen_a10_e5_full_hessian/{route}.json');ref=refdata['retained_reference'];assert refdata['complete_Hessian_and_reference_qualified'] and ref['all643_inverse_directions_both_checked'] and ref['literal_GF_all_413449_entries_matched'] and ref['auxiliary_auxiliary_Green_zero']==45
    names=ref['field_order'];R={};reverse={};Ks=[{} for i in range(4)];Krev=[{} for i in range(4)];scalar_entries={}
    @lru_cache(None)
    def refcoef(text,factor):return ex.coefficient(s.cancel(s.sympify(text)*factor))
    for i,j,text in ref['reference_Green_raw_C3']['entries']:
        n,m=names[i],names[j]
        if n.startswith('x_') or m.startswith('x_'):
            assert n==m;sec=n.split('_')[1];M2=s.Symbol('Mref_'+sec+'_squared');z=refcoef(text,Q-M2);assert z==1;scalar_entries[scalar(n)]=z
        elif re.fullmatch(r'C\d+',n) and m.startswith(('bar','ub')):R[int(n[1:]),int(re.search(r'\d+',m)[0])]=refcoef(text,Q)
        elif n.startswith(('bar','ub')) and re.fullmatch(r'C\d+',m):reverse[int(m[1:]),int(re.search(r'\d+',n)[0])]=-refcoef(text,Q)
        elif re.fullmatch(r'B\d+_[0-3]',n) and re.fullmatch(r'(L|b)\d+',m):
            a,mu=map(int,n[1:].split('_'));Ks[mu][a,int(re.search(r'\d+',m)[0])]=refcoef(text,Q/(s.I*mom[mu]))
        elif re.fullmatch(r'(L|b)\d+',n) and re.fullmatch(r'B\d+_[0-3]',m):
            a,mu=map(int,m[1:].split('_'));Krev[mu][a,int(re.search(r'\d+',n)[0])]=refcoef(text,-Q/(s.I*mom[mu]))
    assert len(scalar_entries)==328 and R==reverse and all(v==Ks[0] for v in Ks+Krev);K=Ks[0];I={(i,i):ex.coefficient(s.S.One) for i in range(45)}
    assert ex.mm(H,R)==ex.mm(R,H)==ex.mm(H,K)==ex.mm(K,H)==I
    return O,B,F,H,R,K,dict(counts)
def recon(q,f,A,O,H,R):
    OO=defaultdict(list);qq=defaultdict(list);AA=defaultdict(list);ff=defaultdict(list);HH=defaultdict(list);RR=defaultdict(list)
    for (n,k),z in O.items():OO[n].append((k,z))
    for (i,m,j),z in q.items():qq[i].append((m,j,z))
    B={}
    for (n,k),z in O.items():
        for m,j,v in qq[k]:put(B,(n,m,j),-z*v)
    for (i,n,m),z in A.items():
        for j,v in OO[i]:put(B,(n,m,j),z*v)
    RF={(a,m,p):z for (a,p,m),z in f.items()}
    for (i,p),z in H.items():HH[i].append((p,z))
    for (a,n),z in R.items():RR[n].append((a,z))
    for (i,n,m),z in A.items():
        for a,r in RR[n]:
            for p,h in HH[i]:put(RF,(a,m,p),-r*z*h)
    return B,RF
def left_ghost(R,B):
    rr=defaultdict(list);out={}
    for (a,b),z in R.items():rr[b].append((a,z))
    for (b,m,j),z in B.items():
        for a,r in rr[b]:put(out,(a,m,j),r*z)
    return out
def effective(F):return add(F['a'],{key:-z for key,z in F['B'].items()})
def compose_O(RF,K,O):
    KO=ex.mm(K,O);ko=defaultdict(list);out={}
    for (p,j),z in KO.items():ko[p].append((j,z))
    for (a,m,p),z in RF.items():
        for j,v in ko[p]:put(out,(a,m,j),z*v)
    return out
def contract(q,Z,route):
    out={}
    if route=='primary':
        right=defaultdict(list)
        for (a,m,j),z in Z.items():right[a,j].append((m,z))
        for (i,a,j),z in q.items():
            for m,v in right[a,j]:put(out,(i,m),-z*v)
    else:
        matrices=defaultdict(dict);vectors=defaultdict(dict)
        for (i,a,j),z in q.items():put(matrices[a],(i,j),-z)
        for (a,m,j),z in Z.items():put(vectors[a],(j,m),z)
        for a in range(45):out=add(out,ex.mm(matrices[a],vectors[a]))
    return out
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][route]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('DIMENSIONFUL_SCALAR_POLE_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('DIMENSIONFUL_SCALAR_POLE_UNDECLARED '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+route+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    q,f,A,scounts=stage('actual_complete_source_transformations',lambda:columns(route));O,B,F,H,R,K,gcounts=stage('literal_GF_and_complete_reference_metrics',lambda:fix_and_reference(route))
    BB,RF=stage('independent_classical_source_reconstruction',lambda:recon(q,f,A,O,H,R));literalRF=left_ghost(R,effective(F));assert BB==B,'ORBIT_VERTEX_RECONSTRUCTION';assert RF==literalRF,'ORDINARY_F_VERTEX_RECONSTRUCTION'
    unitfolder=ROOT/'calculations/canonical_so10_dimensionful_scalar_source_units';ur=read(unitfolder/'validation_receipt.json');up=unitfolder/(route+'_result.json');assert ur['execution_state']=='COMPLETED' and ur['input_sha256'][str(up)]==digest(up);units=read(up)['units'];assert units=={'bubble':'-2','triangle_a':'2','triangle_B':'-2','triangle_c':'0'}
    bz=left_ghost(R,B if route=='primary' else BB);tz=compose_O(literalRF if route=='primary' else RF,K,O)
    bubble=stage('all14760_bubble_positions',lambda:{key:-2*z for key,z in contract(q,bz,route).items()});triangle=stage('all14760_triangle_positions',lambda:{key:2*z for key,z in contract(q,tz,route).items()});total=add(bubble,triangle)
    one={(i,i):ex.coefficient(s.S.One) for i in range(45)};wrong=add({k:-2*z for k,z in contract(q,left_ghost(one,B),route).items()},{k:2*z for k,z in contract(q,compose_O(left_ghost(one,effective(F)),one,O),route).items()})
    plainB,plainRF=recon(q,f,{},O,H,R);badA=add({k:-2*z for k,z in contract(q,left_ghost(R,plainB),route).items()},{k:2*z for k,z in contract(q,compose_O(plainRF,K,O),route).items()})
    controls={'omit_bubble_changes_total':triangle!=total,'omit_triangle_changes_total':bubble!=total,'reverse_source_order_changes_total':{k:-z for k,z in total.items()}!=total,'halve_bubble_changes_total':add({k:z*ex.coefficient(s.Rational(1,2)) for k,z in bubble.items()},triangle)!=total,'wrong_identity_R_K_changes_total':wrong!=total,'omit_Qanti_changes_orbit_vertex':plainB!=B,'omit_Qanti_changes_F_vertex':plainRF!=RF,'omit_Qanti_changes_total':badA!=total}
    assert controls['omit_Qanti_changes_orbit_vertex'] and controls['omit_Qanti_changes_F_vertex'];assert all(0<=i<328 and 0<=m<45 for i,m in total)
    tensors={'q_scalar':q,'f_gauge':f,'A_antighost':A,'O_orbit':O,'B_literal':B,'F_a':F['a'],'F_B':F['B'],'F_c':F['c'],'H':H,'R':R,'K':K,'RF_effective':RF}
    result={'schema':'INTRINSIC_DIMENSION_ONE_SCALAR_SOURCE_POLE_V1','route':route,'domain':{'scalar_sources':328,'ghosts':45,'all_slots':14760,'implicit_zeros_are_computed':True,'no_jets':True,'coefficient_dimension':1,'common_factor':'hbar*g10^3*xi/(32*pi^2*epsilon_UV)','coordinates':'C3_evaluation_dual_Jx_and_C_full_Cartesian_x'},'source_input_counts':scounts,'GF_input_counts':gcounts,'input_tensor_signatures':{n:signature(P) for n,P in tensors.items()},'all4_Lorentz_copies_and_both_reference_orientations_checked':True,'all328_scalar_reference_entries_checked':True,'actual_source_reconstruction_matches_literal_orbit_and_F_vertices':True,'nonminimal_Qanti_terms_retained':True,'bubble':pack(bubble),'triangle':pack(triangle),'complete_pole':pack(total),'zero_complement':14760-len(total),'controls':controls,'new_Gamma_node_or_Slavnov_identity_calculated':False,'physical_real_chart_or_canonical_integration_qualified':False,'full_source_E5_A5_QAP_IR_or_physical_claim':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
