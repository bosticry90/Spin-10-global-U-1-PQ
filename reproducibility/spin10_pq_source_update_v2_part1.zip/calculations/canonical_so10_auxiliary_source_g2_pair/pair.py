"""Actual g2 xi source/auxiliary/ghost bubble; two contraction routes."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import permutations
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
import a10_e5_gauge_source_partner_control as lib
import a10_e5_quartic_algebra as ex
from a10_e5_auxiliary_next import vertices
s=lib.s;ZERO=ex.D.zero;num=ex.coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def put(P,k,z):
    P[k]=P.get(k,ZERO)+z
    if not P[k]:del P[k]

def packed(P):return [[*k,str(ex.D.to_sympy(z))] for k,z in sorted(P.items())]

def unit_born(omit_reverse=False,omit_word=False):
    w=lib.alphabet();w.fields={n:(1,1 if n.startswith('C') else -1,1) for n in ['CA','aA','CB','aB']};w.grades=w.fields;w.pairs=[];w.external={};w.p={n:1 for n in w.fields}
    for n,z in [('Je',(1,-1,1)),('Be',(2,0,0)),('Ce',(1,1,1))]:lib.register(w,n,z)
    v=w.var;S=w.mul(v('Je'),v('aA'),v('CB'),v('Ce'));X=w.mul(v('Be'),v('aB'),v('CA'))
    assert w.grade(S,(4,0,0)) and w.grade(X,(4,0,0))
    G={(i,j):{():z} for i,a in enumerate(w.fields) for j,b in enumerate(w.fields) if (z:=lib.inverse(a,b,omit_reverse_odd=omit_reverse))}
    H=[lib.hessian(P,w) for P in [S,X]];parts=[]
    for order in permutations(H):
        P=lib.mm(lib.mm(lib.mm(G,order[0]),G),order[1]);parts.append(-lib.II*lib.c(s.Rational(1,4))*lib.trace(P,[1]*4).get((0,1,2),lib.R.zero))
    if omit_word:parts=parts[:1]
    return lib.residue(sum(parts,lib.R.zero),'primary'),[str(z.as_expr()) for z in parts]

def wick_coefficient(first,second,omit_reverse=False,one_order=False):
    """Ordered vertices are lists of (name,parity); J,L,E are external."""
    out=s.S.Zero;parts=[]
    for order in list(permutations([first,second]))[:1 if one_order else 2]:
        full=[(vi,n,p) for vi,word in enumerate(order) for n,p in word];ext=[n for vi,n,p in full if n in ['J','L','E']];legs=[(vi,n,p) for vi,n,p in full if n not in ['J','L','E']]
        assert sorted(ext)==['E','J','L'] and len(legs)==4
        crossing=(-1)**sum(p*q for i,(vi,n,p) in enumerate(full) if n not in ['J','L','E'] for vj,m,q in full[i+1:] if m in ['J','L','E'])
        rank={'J':0,'L':1,'E':2};sorting=(-1)**sum(rank[a]>rank[b] and a!='L' and b!='L' for i,a in enumerate(ext) for b in ext[i+1:])
        def inverse(a,b):
            if a.startswith('C') and b.startswith('a') and a[1:]==b[1:]:return s.I
            if a.startswith('a') and b.startswith('C') and a[1:]==b[1:]:return 0 if omit_reverse else -s.I
            return 0
        a=legs[0];value=0
        for j,b in enumerate(legs[1:],1):
            if a[0]==b[0]:continue
            prop=inverse(a[1],b[1]);rest=legs[1:j]+legs[j+1:]
            if not prop or rest[0][0]==rest[1][0]:continue
            sign=(-1)**sum(z[2] for z in legs[1:j]);value+=sign*prop*inverse(rest[0][1],rest[1][1])
        # -i log Z, two i action vertices, both orders with 1/2!.
        piece=s.I*s.Rational(1,2)*crossing*sorting*value;parts.append(piece);out+=piece
    return s.expand(2*s.I*out),list(map(str,parts))

def units(role):
    first=[('J',1),('a0',1),('C1',1),('E',1)];second=[('L',0),('a1',1),('C0',1)]
    base,parts=unit_born() if role=='primary' else wick_coefficient(first,second)
    assert base!=0
    omitted,_=unit_born(omit_reverse=True) if role=='primary' else wick_coefficient(first,second,omit_reverse=True)
    half,_=unit_born(omit_word=True) if role=='primary' else wick_coefficient(first,second,one_order=True)
    assert omitted!=base and half!=base
    # Standard odd Gaussian determinant. E stands for ordered Je*Ce, not Le.
    q,E,L=s.symbols('q E L');det=q*q-E*L;gaussian=s.diff(-s.I*s.log(det),E,L).subs({E:0,L:0})
    expected=s.simplify(2*s.I*q*q*gaussian);assert expected==base
    w=lib.alphabet();lib.register(w,'Je',(1,-1,1));lib.register(w,'Le',(2,0,0));lib.register(w,'Ce',(1,1,1))
    P=w.mul(w.var('Je'),w.var('Le'),w.var('Ce'));assert P==w.scale(w.mul(w.var('Ce'),w.var('Le'),w.var('Je')),-1)
    assert w.mul(w.var('Le'),w.var('Le'))
    return {'unit_pole':str(base),'ordered_parts':parts,'reverse_odd_omission_pole':str(omitted),'one_Born_or_Wick_word_pole':str(half),'finite_odd_Gaussian_coefficient':str(gaussian),'unit_matches_finite_2x2_determinant':True,'even_auxiliary_not_nilpotent':True,'external_odd_order_sign_checked':True}

def source_K(role):
    p=ROOT/f'calculations/canonical_so10_double_auxiliary_source_pole/actual_{role}_v2_result.json';d=read(p);receipt=read(p.parent/'validation_receipt.json')
    assert receipt['complete_paired_actual_tensors_equal'] and receipt['input_sha256'][str(p)]==digest(p)
    K={(i,k):{(a,b):num(s.sympify(z)) for a,b,z in rows} for (i,k),rows in d['actual_tensors']['K']}
    for (i,k),A in K.items():
        for (a,b),z in A.items():assert z==-K.get((i,b),{}).get((a,k),ZERO)
    return K,d['raw_source_counts'],d['physical_source_counts']

def xi_tensors(w,P):
    X=defaultdict(dict)
    for word,z in P.items():
        assert len(word)==3 and all(not j for n,j in word)
        ns=[n for n,j in word];l=int(next(n[2:] for n in ns if n.startswith('Lp')));a=int(next(n[2:] for n in ns if n.startswith('ap')));b=int(next(n[2:] for n in ns if n.startswith('Cp')))
        assert 12<=l<45 and 12<=a<45 and 12<=b<45
        target=w.mul(w.var(f'Lp{l}'),w.var(f'ap{a}'),w.var(f'Cp{b}'));put(X[l],(a,b),num(z/target[word]))
    return dict(X)

def primary(K,X,unit):
    out={}
    for (i,k),A in K.items():
        for l,B in X.items():
            v=sum((z*B.get((b,a),ZERO) for (a,b),z in A.items()),ZERO)*num(unit)
            if v:put(out,(i,l,k),v)
    return out

@lru_cache(None)
def routed_weight(external_first):
    # Source density ordered J,a,C_b,C_k. The external ghost can be either.
    names=[('J',1),('a0',1),('E',1),('C1',1)] if external_first else [('J',1),('a0',1),('C1',1),('E',1)]
    value,parts=wick_coefficient(names,[('L',0),('a1',1),('C0',1)]);assert len(set(parts))==1
    return num(value)

def replay(K,X):
    out={};proper_source_monomials=0
    byentry=defaultdict(list)
    for l,B in X.items():
        for (a,b),z in B.items():byentry[a,b].append((l,z))
    for (i,k),A in K.items():
        for (a,b),z in A.items():
            if b>=k:continue # Rebuild each antisymmetric physical ghost pair once.
            proper_source_monomials+=1
            for l,y in byentry.get((b,a),[]):put(out,(i,l,k),z*y*routed_weight(False))
            for l,y in byentry.get((k,a),[]):put(out,(i,l,b),z*y*routed_weight(True))
    return out,proper_source_monomials

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
    prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AUX_PAIR_WORKER_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AUX_PAIR_KNOWN_GAMMA_TARGET_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t0=time.perf_counter();v=fn();stages.append({'name':name,'seconds':time.perf_counter()-t0});return v
    U=stage('nonzero_source_bubble_and_finite_odd_Gaussian',lambda:units(role));K,raw_counts,phys_counts=stage('qualified_own_role_action_K_and_full_ghost_skew',lambda:source_K(role))
    data=read(ROOT/f'calculations/canonical_so10_single_source_uv_frontier/{role}_result.json');target=data['targets']['C_JL_L__j0']
    eligible={n for n,v in target['candidate_families'].items() if v['profiles'] and v['g']==2};assert eligible=={'KL*X'}
    assert target['candidate_families']['KL*X']['xi']==1 and all(not v['uses_BB'] and v['required_UV_Taylor_order']==v['explicit_external_jets']==0 for v in target['candidate_families']['KL*X']['profiles'])
    w,V,maps,info=stage('fresh_own_literal_X_and_physical10_replay',lambda:vertices(role,stage));X=stage('complete_canonical_metric_xi_vertex_coefficients',lambda:xi_tensors(w,V[1]))
    if role=='primary':out=stage('all2025_external_source_ghost_matrix_traces',lambda:primary(K,X,s.sympify(U['unit_pole'])));rebuilt=sum(1 for (i,k),A in K.items() for a,b in A if b<k)
    else:out,rebuilt=stage('ordered_pairwise_source_ghost_extractions_and_routed_Wick',lambda:replay(K,X))
    # Delete a source action coefficient, preserving the required ghost skew.
    mutant=None;deletion=None
    for (i,k),A in sorted(K.items()):
        for (a,b),z in sorted(A.items()):
            if b>=k:continue
            if any(B.get((b,a),ZERO) or B.get((k,a),ZERO) for B in X.values()):
                bad={key:dict(B) for key,B in K.items()};del bad[i,k][a,b];del bad[i,b][a,k]
                mutant=primary(bad,X,s.sympify(U['unit_pole'])) if role=='primary' else replay(bad,X)[0];deletion=[i,a,b,k,str(ex.D.to_sympy(z))];break
        if mutant is not None:break
    assert mutant is not None and mutant!=out,'SOURCE_ACTION_DELETION_MUST_CHANGE_COMPLETE_TENSOR'
    assert all(12<=v<45 for ijk in out for v in ijk)
    assert all(s.simplify(ex.D.to_sympy(z)-s.conjugate(ex.D.to_sympy(z)))==0 for z in out.values())
    # Literal source parity cannot be changed while retaining its type.
    v=w.var;name='Je_control';lib.register(w,name,(1,-1,0));P=w.mul(v(name),v('ap12'),v('Cp13'),v('Cp14'));assert not w.grade(P,(4,0,0))
    result={'schema':'ACTUAL_G2_XI_AUXILIARY_SOURCE_PAIR_V1','route':role,'unit_controls':U,'literal_X_info':{k:v for k,v in info.items() if k not in ['retained_IBP_current']},
      'source_raw_counts_reused':raw_counts,'source_physical_counts_reused':phys_counts,'K_action_matrices':[[list(key),packed(A)] for key,A in sorted(K.items())],'X_action_matrices':[[l,packed(A)] for l,A in sorted(X.items())],
      'complete_physical_pole':packed(out),'nonzero_physical_coefficients':len(out),'all_raw_source_aux_ghost_positions':45**3,'all_heavy_positions':33**3,'reconstructed_source_monomials':rebuilt,
      'ghost_skew_checked_complete':True,'wrong_source_parity_rejected':True,'complete_H_complement_zero':True,'finite_IR_amplitude_claim':False,'only_KL_X_at_g2_xi_confirmed':True,
      'deleted_source_action_entry':deletion,'complete_deleted_entry_pole':packed(mutant),'actual_nonzero_disposition':bool(out),'canonical_node_exported_or_Gamma_changed':False,
      'known_Gamma_required_pole_or_peer_read':False,'full_source_Slavnov_E5_A5_or_anomaly_claim':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
