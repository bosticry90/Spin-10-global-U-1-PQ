# Lower-order auxiliary-source pair pole V1

Baseline5ca4ba0acfc394d763eac7ec6eb1f85e4449ed57; standing AGENTS delegation,
statev113/34of39 unchanged. Reconciliation of V170's28 supported type/jet/
coupling profiles exposes a lower-order gap: the qualified source-pair contract
calculates g3 JLambda*Lambda*C, not g2*xi. The old measured-support table has
no g2*xi node of this type. Absence is neither measured zero nor full evidence
of nonexistence in every historical record. This increment calculates the
actual lower-order pole before returning to the higher-leg vector candidate.

Question: what is the complete coefficient-dimension0,no-jet,g2*xi
JLambda_i*Lambda_l*C_k one-loop logarithmic pole, in the displayed order,
with no extra symmetry factor and common hbar/(32*pi^2*epsilon_UV)? Retain
all45^3=91125 positions, including H/M zero complements. JLambda=(1,-1,odd),
Lambda=(2,0,even), C=(1,1,odd); density=(4,0,even). A nonzero, zero or incomplete
result is acceptable. Do not infer it from a desired Slavnov relation.

V170 admits exactly KL*X at this order; SL*F*U is g3 and stays separate.
KL is the literal g2 source quartic, X the literal xi Lambda*a*C cubic.
Proper one-loop degree requires two internal legs per vertex. The external
ghost comes from KL; putting it on X produces a bridge. The bubble uses
both ordered ghost inverses; ordinary BB/mixed/scalar propagators cannot
participate after this proven support restriction. Sources remain external,
auxiliaries integrated. Dimensionful insertions lower the selected UV degree.

Reuse qualified own-role actual KL coefficient matrices K_i,k[a,b], defined
in order JLambda_i*a_a*C_b*C_k, from the double-source calculation. These
are action-derived vertex inputs, not a previous value of this new pole.
Reconstruct X freshly from the full own-role literal E2 GF and its physical
evaluation-dual chart; replay independently reconstructs physical10 tensors
and compares literal vertices before contraction using the established helper.
Retain all actual H/M restrictions and both ghost extractions. K's previous
two derivations and its exact antisymmetry remain authenticated dependencies,
not fresh independent extraction in this increment.

First derive the nonzero stripped bubble unit by full graded Hessian/Born
(primary) and ordered connected Wick (replay). Compare with the finite2x2
Grassmann determinant/logarithm. External Lambda is even, not nilpotent;
Je and Ce are odd and order matters. Keep both vertex orders/odd orientations,
correct identical-field factors and 2i UV-annulus normalization. The source
quartic's two ghost roles require both external assignments, not an extra1/2.

Primary contracts the complete sparse matrices via tr(K_i,k X_l).
Replay rebuilds each source ghost pair once and independently routes its two
external-ghost assignments through ordered Wick signs and indexed X entries.
Keep the full physical coefficient table, source/X vertex tables and an exact
source/ghost skew check. No previous pole, Gamma, required tensor or peer data
may determine the result. Authenticated bytes alone are not fresh mathematics.

Controls: nonzero unit, reverse-odd omission, wrong source parity, reverse
source/ghost order and omitted bubble word. If the actual result is nonzero,
delete one contributing action entry and retain the complete changed tensor.
If it vanishes, a synthetic unmatched vertex must still produce nonzero unit
data. Explicitly disclose zero-only controls' normalization limitations.
Check the complete finite radical arithmetic and exact reality. Qualified
invertible charts imply a nonzero physical tensor cannot be a zero canonical
tensor; no new canonical node or current-Gamma addition is authorized by a
mere assertion of that implication. Canonical export/add-once verification
and a complete dependent consistency census are separate next work.

Two sequential read-only300second/8GiB workers;350MiB minimum available commit,
full native capture before qualification. Freeze source/controller/dependencies
and own-role read allowlists first. Separate frozen validator independently
recontracts all coefficients, checks units/captures/bytes and protected authority
before scoped local commit. Preserve every failure. No parameter search,
input/benchmark adoption, full Q replay, quantum-stage activation or framework.

Ceiling: this complete selected physical-frame logarithmic coefficient and
its actual vertex inputs. Current known Gamma145310/zero saved background
Ward remains unchanged until later canonical add-once qualification. Full
source/Slavnov,E5/A5,QAP,finite/IR,measure/anomaly freedom unqualified; HB1/C5
blocked,C1_GS uncomputed,flavor paused, old failures/scalar warning and custody
exit2/seven preserved. No new policy or scientific authority. Track A closes
a missing lower order; Track B tests evidence-scope reconciliation and source
grading, with shared action/charts/arithmetic/AI authorship disclosed. Education
remains concurrent,voluntary,nonblocking.
