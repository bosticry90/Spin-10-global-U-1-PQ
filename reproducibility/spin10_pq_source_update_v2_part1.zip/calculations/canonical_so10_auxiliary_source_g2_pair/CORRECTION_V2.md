# Invalid odd inverse controls are different mutations

The first validator failed before the new Lie-matrix checks. It incorrectly
required the reverse-odd-omission unit to equal-1 in both formalisms. The actual
primary reports-1 and ordered Wick reports0; both valid units are-2 and every
actual K,X,pole and source-deletion coefficient agrees.

Dropping G_(a,C) while retaining G_(C,a) violates the graded-skew identity
needed for an odd Gaussian covariance. The Born matrix mutation leaves one
of its two trace orientations; the displayed ordered Wick words start with
an antighost and lose every contraction. There is no valid odd Gaussian to
which both mutated rules refer. These are distinct falsifiers, not two
implementations of the same physical modified theory.

V2 independently constructs the4x4 odd matrices to require the Born mutation
-1 and proves the Wick mutation0 from each ordered word's first antighost.
Both must differ from the separately normalized valid unit-2. It retains all
actual mathematical assertions and separately checks the full Lie expression.
No physical input, graph, actual coefficient, tolerance or resource cap changes.
All original sources, preparation and complete failed validation capture remain.
Reuse the completed primary/replay; no new pole calculation. RESULT_V2.md
corrects the original report's overgeneralized-1 sentence and records this
verification failure. Qualification is prospective on the completed V2 receipt.
