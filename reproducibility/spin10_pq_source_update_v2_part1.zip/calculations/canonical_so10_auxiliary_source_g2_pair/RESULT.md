# A nonzero lower-order auxiliary-source pair pole

The complete selected no-jet,coefficient-dimension0,g10^2*xi
JLambda_i*Lambda_l*C_k logarithmic UV pole has776 nonzero physical coefficients
in91125 positions. This is a newly measured source coefficient, not a physical
observable, a gauge anomaly or a model exclusion. Qualification requires both
completed captures/results, the separately frozen validation receipt and exact
committed-byte proof; this report alone cannot establish execution.

In displayed field order JLambda_i*Lambda_l*C_k, with no extra1/2, define

    Gamma_pole includes hbar*g10^2*xi/(32*pi^2*epsilon_UV)
                        * sum_(i,l,k) P_i,l,k JLambda_i Lambda_l C_k.

For example P_(13,12,14)=16*sqrt(10)/25 and P_(14,12,13)=-16*sqrt(10)/25.
All indices outside the actual33-dimensional heavy support have zero
coefficients. The remaining35937 all-heavy positions include the complete
implicit zero complement. There are no external jets or boundary ambiguities
in this selected density. The full exact table is retained in both results.

## Why this was the next calculation

V170's complete conservative source-linear inventory has18 supported type/jet
patterns and28 distinct g/explicit-xi profiles. These are not28 unmeasured or
nonzero amplitudes. Earlier and later receipts cover many of them. In
particular, ordinary g2/g3 JB and g3 Jx poles and the g4 scalar-source zero
are now qualified, while the old g2 JC pole was already included. Repeating
that old ghost-source absence mistake would have targeted the wrong question.

The source-pair contract explicitly calculated g3 JLambda*Lambda*C and left
lower Xi families separate. V170 also permits KL*X atg2*xi. The known-support
table at92236 has only g3 for this source/auxiliary/ghost type. Subsequent
canonical additions contain JB or Jx, not JLambda*Lambda*C; the zero V186 node
adds nothing. Thus the current145310-term measured functional has not yet
included this new g2*xi coefficient. Its saved zero background Ward remainder
must not be promoted into evidence of complete source coverage.

The proposed g3*xi JLambda*C*B*B test is deferred in favor of this lower-order
gap. Its double-longitudinal Yang-Mills reduction remains a proposal, not a
qualified zero. Two higher-order quartet profiles g4 andg4*xi also remain
separate from the qualified g3*xi JLambda*a*C*C calculation. This record is
not a completed status mapping of all28 profiles.

## Actual calculation and verification boundary

The exact inventory permits only one family atg2*xi: the source quartic KL
with the xi Lambda*a*C cubic X. Both proper vertices have two quantum ghost
legs. The external ghost is extracted from KL in both possible ways. Putting
it on X instead gives a source bridge, not this proper one-loop bubble.
Full reference support is retained before restriction; BB,mixed and scalar
edges cannot occur in the resulting closed odd cycle. Width independence
is derived for this bubble, not copied from the preceding scalar result.

The stripped bubble unit is-2 in the inherited2i UV-annulus normalization.
Both graded Born words give equal nonzero contributions; deleting one leaves
-1. Removing the reverse odd inverse also leaves-1. Ordered connected Wick
contractions reproduce the unit, with explicit odd external-source crossings.
The finite2x2 Grassmann determinant supplies a further normalization check:
-i log(Q^2-E*L) has coefficient+i/Q^2 in E*L, with E the ordered Je*Ce product.
L is even and not nilpotent. No whole scaleless integral or finite/IR zero
is inferred from this UV extraction.

Each worker reuses its own qualified action-derived K_i,k[a,b] matrices,
6688 entries, from the earlier double-source calculation. These are not old
values of the present pole. All3344 source ghost-pair monomials and complete
ghost skew are retained. X is freshly reconstructed from own-role full E2 GF
and physical charts; replay separately reconstructs physical10 commutators
and demands equality with the literal X before contraction. It has600 physical
entries. The same charts/arithmetic/action and AI author still limit independence.

Primary computes the complete sparse traces P_i,l,k=-2 tr(K_i,k X_l).
Replay reconstructs each source ghost pair once and uses separately routed
Wick signs for its two possible external ghosts. All K,X,776 final coefficients
and the full single-action-entry-deletion counterfactual agree. Wrong source
parity is rejected; source/ghost order changes the unit sign. No candidate,
required Slavnov tensor, current Gamma or peer result is read as a pole input.

The separate validator additionally reconstructs the actual Lie matrices from
the qualified gauge-source vertex data, checks every K and X entry and the
complete matrix expression -2*sum_h(f_h*f_l*f_h) on the heavy subspace. Its
manual odd ordering and ordinary SymPy contractions do not import this new
diagram engine. These are internal cross-checks, not independent scientific
or experimental confirmation of the common physical assumptions.

Primary25.4713274seconds; replay26.7923926seconds after imports, within300s/
sampled8GiB and350MiB launch-commit limits. No failed native calculation in
this increment. The commands have different role arguments; no fresh identical-
command pair or old loop replay is claimed. All actual coefficients are real
in the orthonormal physical frame. No canonical node has yet been exported.

## Consequence and next action

Do not add a zero or duplicate the old g3 node to stand in for this coefficient.
Next export the776-term physical pole through the qualified field/evaluation-
dual maps, check full roundtrip/reality/local-H invariance, establish literal
g2 source-class absence, and add the actual canonical node exactly once.
Then recover the complete predecessor census for the affected source identities.
A new nonzero coefficient may require ordinary renormalization; it does not
alone establish quantum inconsistency. Prior selected equations keep their
literal scope, not an assumed extension to the enlarged functional.

Current Gamma145310/zero saved background Ward is unchanged by this physical-
frame result. Full source/Slavnov,E5/A5,QAP,finite contacts,measure/IR/anomaly
freedom remain unqualified. Statev113/34of39 unchanged; HB1/C5 blocked,C1_GS
uncomputed,flavor paused,quartet and benchmark failures,scalar quantum-control
warning and custodyexit2/seven preserved. No physical input/benchmark/foundation,
policy override or remote action. Track B records another late lower-order
coverage discovery as a prioritization limitation, together with successful
scope reconciliation and nonzero-source calculation. Education is voluntary,
concurrent and nonblocking. The overall investigation remains incomplete.
