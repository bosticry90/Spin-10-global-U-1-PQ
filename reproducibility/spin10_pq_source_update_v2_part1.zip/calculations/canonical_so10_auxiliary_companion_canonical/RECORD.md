# Measured auxiliary companions integration and complete selected Ward test V1

Baselinebe49d037f604019eddd64efbf69f063ce74ef91d. Question ACI1:integrate
the independently qualified1824-position ordinaryg3 ABL/BBL node exactly
once into the authenticated functional,then evaluate the complete local-H
Omega*Lambda*B/one-jet g3 coefficient using its actual predecessors.
Unlike V225's partial-known projection,this increment has measured inputs
for all three required classes. No Ward target supplies a coefficient.

Freeze source,contract,controllers,policy,qualified coefficient/loop/operator/
predecessor evidence and previous exact recipe before two sequential180-
second-after-import/8GiB sampled-private workers and a180-second/8GiB
independent validator;minimum350MiB available commit. Preserve failures and
unfinished runs. No whole-QGamma,old loop,508-Euler or unrestricted search.

Use the same unchanged g2 Lambda*M*partial B matrix and BOTH measuredg3
ABL/BBL nodes with both symbolic reference widths and actual raw charts.
Reproduce the prior146162/hashf0b650... bytes,check every changed coefficient,
exact inverse addition,active doubling and unaffected source projection.
Ordinaryg3 companions must not already be present in their exact classes.
Do not confuse coefficient positions/word counts with scientific completion.

Recover the complete predecessor routes from actual E3 H transformation
types and qualified exhaustive local dimension/Lorentz envelope. For the
selected B*Lambda/one-jet g3 target these must be(B,L)/one-jet g2,
(A,B,L)/no-jet g3 and(B,B,L)/no-jet g3. Retain source-count preservation,
absence of unbroken-H scalar affine shifts and both96 A/B affine columns.
Authenticate the complete5 mixing and15 companion profile qualifications.
Shape presence alone is never complete coefficient evidence.

Primary uses the exact even derivation with its correct parity convention;
replay uses even left derivatives. Retain differentiated Omega,derivative
placements,all color/Lorentz coefficients and the full parameter ring.
Project only after applying the actual operator. Compute the Omega-Euler
anchor and four explicit IBP currents,checking density=anchor+divergence
and Euler differences. No EOM quotient. If the density itself cancels,
report that stronger fact without inventing nonzero boundary terms.

Check each of the three predecessor contributions and normalization/
omission controls. Test removal of either affine connection and both
measured companion classes;report insensitive controls honestly. Check the
new node's homogeneous g4 H variation separately,without claiming all
other local-H sectors complete. Source-free Q of the new field monomials
preserves the38-source and selected-bilinear proofs in their scopes.

Independent ordinary-SymPy validation must reconstruct the full updated
recipe/hash,unchanged source projection,complete predecessor census and
actual even variation/current coefficient tables. Validate all individual
pieces and controls,not merely a final zero. Distinct exact arithmetic and
derivation implementations share action,evidence,software and AI authorship;
their agreement is computational corroboration,not independent scientists.

Possible outcomes:qualified complete selected Ward zero(mod currents),
qualified nonzero remainder with completed inputs,or precise bounded
inconclusive result. A remainder is not automatically an anomaly. No full
source-free Slavnov/E5/A5,QAP,measure/IR,contact/Legendre or physical viability
claim. Keep nonzero Jacobian,32 product maps,128 source jets,508 physical
programs,Legacy quartet/equivalence obligations,authority34/39,HB1/C5 block,
flavor pause,C1_GS gap,scalar warnings,closed routes,custodyexit2/seven.
No input,scheme,benchmark,foundation,policy,authority or remote change.
Education voluntary/nonblocking;Lean selective. Next choose the remaining
dependency-critical ordinary ghost companions or a genuine restoration
premise;do not accumulate selected zeros as a substitute for completeness.
