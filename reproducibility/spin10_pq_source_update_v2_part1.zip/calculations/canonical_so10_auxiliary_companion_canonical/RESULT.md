# Measured auxiliary companions close the complete selected local-H pole

Prospective until both native captures/results,the independent validation
receipt and committed-byte checks qualify. Baselinebe49d037f604019eddd64efbf69f063ce74ef91d.

The previously measured ordinaryg3 auxiliary/vector companions are now
integrated exactly once. The complete selected Omega*Lambda*B/one-jet g3
local logarithmic-pole Ward relation cancels exactly. Its raw canonical
density is zero,so no integration by parts is required for the final sum.
The Omega-Euler anchor and all four retained total-derivative currents are
also zero. Individual predecessor pieces retain nontrivial currents/anchors.
No EOM quotient or fitted coefficient is used.

The complete predecessors are the unchanged ordinaryg2 Lambda*M*partial B
term,the actualg3 A_H*B*Lambda term,and the actualg3 B*B*Lambda term. Their
exhaustiveness is reconstructed from the actual E3 transformation types,
source-count filtration and qualified local dimension/Lorentz envelope.
Both A_H and B_H transform affinely;all96 affine columns are retained.
Scalar unbroken-H affine shifts are absent,and source-preserving H cannot
bring a source-dependent term into this source-free target. The measured
five mixing and15 companion graph-profile qualifications are authenticated.

| Contributing predecessor | Raw variation positions | Omega-anchor positions |
| --- | ---: | ---: |
| Actualg2 mixing | 720 | 1440 |
| Actualg3 ABL | 592 | 1184 |
| Actualg3 BBL | 720 | 1440 |
| Complete sum | 0 | 0 |

These are coefficient supports of nonzero polynomial contributions,not
numbers to add as physical observables. All color,Lorentz,derivative and
reference-width dependence is retained in the exact graded ring. Primary
uses the correct even derivation;replay uses even left derivatives. The
new node's homogeneous g4 H variation also vanishes within its stated scope.

Controls remove any one of the three predecessor contributions,remove
either affine connection,duplicate the new node or reverse its sign. All
change the anchor. Thus a selected zero is not being obtained by ignoring
the actual measured additions or treating the two connections interchangeably.

The new measured node has1824 canonical positions:592 ABL and1232 BBL.
It introduces1104 new words and changes720 existing word coefficients.
The authenticated known functional changes as follows:

    prior words:146162
    prior SHA:f0b650d6a343a98e105c7aee8894fca84a70dad17d64620b9ee3181488fceee1
    updated words:147266
    updated SHA:c445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4

The old ordinaryg3 companion classes were absent at that coupling order.
Exact inverse addition recovers the entire prior functional,doubling changes
it,and every unaffected coefficient/source projection is preserved. The
recipe is previous actual-mixing recipe plus add_once_key
new_actual_g3_auxiliary_companion_node. Word count alone is not completeness.

The new terms contain only source-free field monomials;their actual quantum
field images are source-free and do not lower the field count into the
selected bilinear target. Consequently the38-source and selected-bilinear
results retain their original scopes. This is not a new full-sourcefree
Slavnov theorem or an extension to finite amplitudes/contact terms.

Primary took103.4480seconds after imports. Its complete selected even-H
variation took0.4430seconds;full-functional byte reconstruction and exact
addition dominate the runtime. Replay/validator captures own actual peaks,
timings and any failures. Sequential worker/validator limits are180seconds
after imports,8GiB sampled private and350MiB minimum available commit. No
new or old loop,whole-QGamma or508-Euler-value computation is performed.
No fresh byte-identical replay pair is claimed.

Independent validation must reconstruct the full updated recipe/hash and
all changed coefficients with ordinary-SymPy arithmetic,rederive the actual
finite predecessor routes/affine columns,and compute every raw variation,
anchor,current,individual piece and control. The prior measured loop/trace/
component proofs are authenticated,not rerun. Shared action,measured data,
operator,local envelope,software and AI author limit independence;passing
computations do not validate a shared physical assumption or replace experts.

NEXT:reconcile the remaining ordinary AaC/BaC ghost companion sector against
the measured g2 ghost kinetic pole,actual derivative placements and complete
15/104-profile inventory before choosing a bounded actual calculation.
Do not derive unknown ghost coefficients from the desired Ward cancellation.
Prefer a structural unit/one-loop reduction over a whole functional expansion.
If derivative/ghost/explicit-xi graph assumptions prevent a competent bounded
calculation,identify the precise missing premise rather than inventing a zero.

The earlier partial auxiliary/vector Ward gap is closed in this exact scope.
The separate ghost Ward gap remains;the wider source-free functional and
simultaneous quantum restoration are still incomplete. The historical72826
fixed-primitive residual refers to the pre-addition functional;it is not a
current recomputed residual. No generator/normalization or scheme is adopted.
Source-independent gauge-fermion/invariant freedoms remain untested there.

FullE5/A5,QAP,finite contacts,Legendre/coincident products,measure/IR,Legacy
quartet/equivalence and physical viability remain unqualified. Keep the
nonzero Jacobian,32 product maps,128 source jets,508 programs,authority34/39,
HB1/C5 block,flavor pause,C1_GS gap,scalar warnings,closed routes,custody
exit2/seven. No protected authority,input,scheme,benchmark,foundation,policy
or remote action. Education remains voluntary/nonblocking;Lean selective.
Track B supports modular exact assembly after earlier full-expansion limits,
while preserving the shared-premise and research-completeness limitations.
