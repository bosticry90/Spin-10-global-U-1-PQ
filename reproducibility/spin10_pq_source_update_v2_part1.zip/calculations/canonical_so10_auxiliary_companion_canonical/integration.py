"""Measured companions exact-once recipe and complete selected even H relation."""
from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_actual_mixing_recipe',OUT.parent/'canonical_so10_auxiliary_vector_canonical/canonical.py');q=a.q;m=a.m;l=a.l;h=a.h;s=a.s;read=q.read;digest=q.digest;PKG=q.PKG
def auth(folder,name):return a.auth(folder,name)
def coefficient_input(role):
    d=OUT.parent/'canonical_so10_auxiliary_companion_coefficients';p=d/('primary_v2_result.json' if role=='primary' else 'replay_v3_result.json');r=read(d/'validation_v4_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def current_tables(role):
    tables,previous,path=a.current_tables(role);cur=auth('canonical_so10_auxiliary_companion_canonical',role+'_result.json');tables.append(cur['new_actual_g3_auxiliary_companion_node']);return tables,cur,OUT/(role+'_result.json')
def typ(key):return tuple(sorted(h.kind(n) for n,j in key))
def stripsig(key):return tuple(sorted(h.kind(n) for n,j in key if not m.names[n].startswith('omega')))
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('AUX_COMPANION_INTEGRATION_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AUX_COMPANION_INTEGRATION_UNDECLARED_OR_PEER '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();r=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return r
    m.setup();d=coefficient_input(role);node_rows=d['actual_g3_ABL_BBL_canonical_node'];node=m.decode(node_rows);assert len(node)==1824 and all(gp==3 and not any(j for n,j in key) and typ(key) in [('A','B','L'),('B','B','L')] for gp,key in node);AB={key:z for key,z in node.items() if typ(key[1])==('A','B','L')};BB={key:z for key,z in node.items() if typ(key[1])==('B','B','L')};assert AB and BB
    tables,previous,path=a.current_tables(role);old=stage('protected_prior146162_recipe',lambda:q.combine(tables));assert len(old)==previous['updated_known_terms']==146162 and q.hashrows(q.rawrows(old))==previous['updated_known_sha256']=='f0b650d6a343a98e105c7aee8894fca84a70dad17d64620b9ee3181488fceee1'
    classes={('B','L'):1,('A','B','L'):0,('B','B','L'):0};old_selected=m.decode([r for r in q.rawrows(old) if typ(tuple(m.token(n) for n in r['word'])) in classes and sum(len(m.token(n)[1]) for n in r['word'])==classes[typ(tuple(m.token(n) for n in r['word']))]]);assert not any(gp==3 and typ(key) in [('A','B','L'),('B','B','L')] for gp,key in old_selected)
    updated=stage('exact_once_addition_inverse_doubling_and_source_projection',lambda:q.combine([q.rawrows(old),node_rows]));changed={key for key in set(old)|set(updated) if old.get(key)!=updated.get(key)};assert changed=={key for gp,key in node};inverse=q.combine([q.rawrows(updated),[{'word':r['word'],'coefficient':str(-q.num(r['coefficient']))} for r in node_rows]]);assert inverse==old;double=q.combine([q.rawrows(updated),node_rows]);assert double!=updated
    assert {key:z for key,z in old.items() if key not in changed}=={key:z for key,z in updated.items() if key not in changed};assert {key:z for key,z in old.items() if any(n in m.sources for n,j in key)}=={key:z for key,z in updated.items() if any(n in m.sources for n,j in key)}
    proof=auth('canonical_so10_sourcefree_reconciliation',role+'_result.json');routes=proof['current_selected_Ward_gaps']['mixing']['predecessor_routes'];required={(tuple(ts),jets,gp) for ts,jets,gp,*rest in routes};assert required=={(('B','L'),1,2),(('A','B','L'),0,3),(('B','B','L'),0,3)}
    e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');tb=e3['operators']['Tb_geometric_and_transported'];names=m.fields|{m.index[f'A{i}_{mu}'] for i in range(12) for mu in range(4)};O={m.index[f'omega{i}'] for i in range(12)};TI={i:m.decode(tb[m.names[i]]) for i in names if not m.names[i].startswith('x_')};affine=[];Hsig=set()
    for n,rows in tb.items():
        if m.index.get(n) in m.sources:assert all(any(m.token(t)[0] in m.sources for t in r['word']) for r in rows);continue
        if m.index.get(n) not in names:continue
        for r in rows:
            word=tuple(m.token(t) for t in r['word']);params=[(v,j) for v,j in word if v in O];other=[(v,j) for v,j in word if v not in O];assert len(params)==1 and len(other)<=1
            for gp,z in m.coefficient_terms(r['coefficient']):
                if other:assert not params[0][1] and not other[0][1] and h.kind(other[0][0])==h.kind(m.index[n]) and gp==1;Hsig.add((h.kind(m.index[n]),h.kind(other[0][0]),0,1))
                else:assert h.kind(m.index[n]) in ['A','B'] and gp==0 and len(params[0][1])==1;affine.append(n);Hsig.add((h.kind(m.index[n]),None,1,0))
    assert sorted(set(affine))==proof['actual_affine_connection_columns'] and len(set(affine))==96
    env=auth('canonical_so10_e5_remaining_obligations',role+'_result.json')['coarse_sourcefree_type_envelope'];reconstructed=set()
    for ts,j,cd in env:
        if cd:continue
        ts=tuple(ts)
        for before,after,jq,gq in Hsig:
            for pos,t in enumerate(ts):
                if t!=before:continue
                target=tuple(sorted(ts[:pos]+ts[pos+1:]+((after,) if after else ())))
                if target==('B','L') and j+jq==1:reconstructed.add((ts,j,3-gq,before,after,jq,gq))
    assert sorted(reconstructed,key=str)==sorted([(tuple(ts),*rest) for ts,*rest in routes],key=str)
    current=m.add(old_selected,node);sector={key:z for key,z in current.items() if (typ(key[1]),sum(len(j) for n,j in key[1]),key[0]) in required};core={key:z for key,z in sector.items() if key[0]==2};assert core==m.decode(previous['new_actual_g2_auxiliary_vector_node']) and m.add(core,AB,BB)==sector
    measured=auth('canonical_so10_auxiliary_vector_g2','primary_result.json' if role=='primary' else 'replay_v2_result.json');assert len(measured['complete_five_existing_profile_descriptors'])==5
    def T(P,TI=TI):return m.action(P,TI,'primary',True) if role=='primary' else m.action(P,TI,'replay')
    def project(P):return {key:z for key,z in P.items() if key[0]==3 and stripsig(key[1])==('B','L') and sum(len(j) for n,j in key[1])==1}
    variation=stage('complete_actual_g3_auxiliary_vector_even_H_variation',lambda:T(sector));selected=project(variation);anchor,currents=q.anchor(selected,O);assert selected==m.add(anchor,*(m.D(A,mu) for mu,A in enumerate(currents)));assert not any(m.EL_all(m.add(selected,m.scale(anchor,-1)),O).values());pieces={};piece_anchors={}
    for label,P in [('mixing',core),('ABL',AB),('BBL',BB)]:
        V=project(T(P));A,J=q.anchor(V,O);pieces[label]={'input':l.rows(P),'variation':l.rows(V),'anchor':l.rows(A),'four_currents':list(map(l.rows,J))};piece_anchors[label]=A
    assert selected==m.add(*(h.from_result(v['variation']) for v in pieces.values()));assert anchor==m.add(*piece_anchors.values())
    controls={}
    for label,A in piece_anchors.items():controls['omit_'+label+'_changes_anchor']=m.add(anchor,m.scale(A,-1))!=anchor
    for kind in ['A','B']:
        mutated={i:({key:z for key,z in P.items() if key[0]!=0} if h.kind(i)==kind else P) for i,P in TI.items()};bad=q.anchor(project(T(sector,mutated)),O)[0];controls['omit_'+kind+'_affine_channel_changes_anchor']=bad!=anchor
    controls['duplicate_new_node_changes_anchor']=q.anchor(project(m.add(variation,T(node))),O)[0]!=anchor;controls['reverse_new_node_changes_anchor']=q.anchor(project(m.add(variation,m.scale(T(node),-2))),O)[0]!=anchor;controls['doubled_actual_recipe_changes_coefficients']=double!=updated;assert all(controls.values())
    g4={key:z for key,z in T(node).items() if key[0]==4};assert not g4,'HOMOGENEOUS_H_VARIATION_OF_ACTUAL_NEW_DENSITY_NONZERO'
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');forfields={i for gp,key in node for i,j in key if i in m.fields};assert all(e2['complete_columns'][m.names[i]]['physical_program'] is None and not any(m.token(t)[0] in m.sources for r in e2['complete_columns'][m.names[i]]['source_polynomial'] for t in r['word']) for i in forfields);assert all(len(r['word'])>=1 for i in forfields for r in e2['complete_columns'][m.names[i]]['source_polynomial'])
    result={'schema':'ACTUAL_AUXILIARY_COMPANION_CANONICAL_AND_WARD_V1','route':role,'scientific_disposition':'COMPLETE_SELECTED_AUXILIARY_VECTOR_WARD_LOG_POLE_ZERO_MOD_CURRENT' if not anchor else 'COMPLETE_SELECTED_AUXILIARY_VECTOR_WARD_LOG_POLE_NONZERO_REMAINDER','new_actual_g3_auxiliary_companion_node':node_rows,'new_node_positions':len(node),'new_ABL_positions':len(AB),'new_BBL_positions':len(BB),'prior_known_terms':len(old),'prior_known_sha256':q.hashrows(q.rawrows(old)),'updated_known_terms':len(updated),'updated_known_sha256':q.hashrows(q.rawrows(updated)),'new_word_positions':len(set(updated)-set(old)),'changed_existing_word_positions':len(changed & set(old)),'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'add_once_key':'new_actual_g3_auxiliary_companion_node'},'source_projection_identical_and_new_field_Q_sourcefree':True,'selected_bilinear_unaffected_by_new_Q_field_count':True,'complete_predecessor_routes':routes,'actual96_affine_columns':sorted(set(affine)),'complete_selected_input':l.rows(sector),'complete_selected_raw_Ward':l.rows(selected),'complete_selected_Omega_anchor':l.rows(anchor),'four_explicit_IBP_currents':list(map(l.rows,currents)),'complete_relation_zero_mod_current':not anchor,'complete_raw_density_zero':not selected,'homogeneous_g4_new_node_H_variation_zero':not g4,'individual_predecessor_pieces':pieces,'all_parameter_jets_and_Euler_current_identity_checked':True,'controls':controls,'new_loop_or_full_QGamma_or_508_Euler_value_replayed':False,'coefficient_fitting_or_scheme_adoption':False,'full_sourcefree_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
