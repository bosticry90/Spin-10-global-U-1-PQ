"""Exact one-reference supertrace of actual complete ub12 Hessian insertion."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
import importlib.util,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('qualified_operator_helpers',OUT.parent/'canonical_so10_broken_antighost_operator/operator_v2.py');m=a.m;b=a.b;read=a.read;digest=a.digest;PKG=a.PKG
@lru_cache(None)
def num(z):return s.sympify(z,locals={'g10':a.m.g,'xi':a.m.xi,'reference_width_M':a.m.xi,'eta_H':a.m.etaH,'reference_width_H':a.m.etaH})
def serialize(P):return [{'word':[n+('__'+''.join(map(str,j)) if j else '') for n,j in key],'coefficient':str(s.factor(z))} for key,z in sorted(P.items()) if z]
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256'] and role in ['primary','replay']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('REFERENCE_TRACE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);m.setup();p=OUT.parent/'canonical_so10_broken_antighost_operator'/(role+'_v2_result.json');rr=read(p.parent/'validation_v2_receipt.json');assert rr['execution_state']=='COMPLETED' and rr['input_sha256'][str(p)]==digest(p);d=read(p);assert d['eps12_classical_breaking_positions']==0 and d['eps12_mixed_insertion_positions']==824
 ref,rb=b.sealed('frozen_a10_e5_full_hessian',role);f=ref['retained_reference']['field_order'];F={n:i for i,n in enumerate(f)};G={(i,j):num(z) for i,j,z in ref['retained_reference']['reference_Green_raw_C3']['entries']};assert len(f)==643
 rows=[r for r in d['complete_mixed_Hessian_insertion'] if 'zz_da12' in r['word']];assert len(rows)==824;C={};uns={};blockcounts=Counter()
 for r in rows:
  word=[(n.partition('__')[0],tuple(map(int,n.partition('__')[2]))) for n in r['word']];assert all(not j for n,j in word);hs=[(i,n[5:]) for i,(n,j) in enumerate(word) if n.startswith('zz_h_')];ks=[(i,n[5:]) for i,(n,j) in enumerate(word) if n.startswith('zz_k_')];assert len(hs)==len(ks)==1;hi,hn=hs[0];ki,kn=ks[0];remain=tuple(t for i,t in enumerate(word) if i not in {hi,ki});par=lambda n:(1 if n=='zz_da12' else m.par[m.index[n]]);sg=(-1)**(m.par[m.index[hn]]*sum(par(n) for n,j in word[:hi])+m.par[m.index[kn]]*sum(par(n) for n,j in word[ki+1:]));key=(F[hn],F[kn],remain);z=num(r['coefficient'])*m.g**r['g'];C[key]=C.get(key,0)+sg*z;uns[key]=uns.get(key,0)+z;blockcounts[hn[0],kn[0]]+=1
 C={k:s.expand(z) for k,z in C.items() if s.expand(z)};pieces=[];out=defaultdict(lambda:s.S.Zero);wrong=defaultdict(lambda:s.S.Zero);badorder=defaultdict(lambda:s.S.Zero)
 if role=='primary':
  candidates=[(i,j,key,z,G.get((j,i),s.S.Zero)) for (i,j,key),z in C.items()]
 else:
  grouped=defaultdict(list)
  for (i,j,key),z in C.items():grouped[i,j].append((key,z))
  candidates=[(j,i,key,z,gij) for (i,j),gij in G.items() for key,z in grouped.get((j,i),[])]
 for i,j,key,z,gji in candidates:
  if not gji:continue
  weight=(-1)**m.par[m.index[f[j]]];v=s.factor(weight*gji*z);pieces.append({'row':f[i],'column':f[j],'word':[n for n,j in key],'coefficient':str(v)});out[key]+=v;wrong[key]+=s.factor(gji*z);badorder[key]+=s.factor(weight*gji*uns[i,j,key])
 out={key:s.factor(z) for key,z in out.items() if s.factor(z)};wrong={key:s.factor(z) for key,z in wrong.items() if s.factor(z)};badorder={key:s.factor(z) for key,z in badorder.items() if s.factor(z)};delete=dict(out)
 if pieces:
  pp=pieces[0];key=tuple((n,()) for n in pp['word']);delete[key]=s.factor(delete.get(key,0)-num(pp['coefficient']));delete={k:z for k,z in delete.items() if z}
 assert pieces and delete!=out
 result={'schema':'BROKEN_UB12_FIRST_REFERENCE_TRACE_V1','route':role,'scientific_disposition':'FIRST_REFERENCE_SUPERTRACE_ZERO_HIGHER_BORN_INSERTIONS_UNRESOLVED' if not out else 'NONZERO_FIRST_REFERENCE_SUPERTRACE_NOT_YET_UV_POLE','complete_ub12_insertion_positions':len(C),'participating_nonzero_Green_contractions':sorted(pieces,key=lambda r:(r['row'],r['column'],r['word'],r['coefficient'])),'participating_positions':len(pieces),'complete_first_reference_supertrace':serialize(out),'ordinary_trace_control':serialize(wrong),'omit_odd_hk_reordering_control':serialize(badorder),'actual_entry_omission_changes_trace':delete!=out,'one_half_normalization_preserved_by_Gaussian_fixture_in_validator':True,'all643_reference_fields_kept':True,'external_jets_absent_verified':True,'no_loop_integral_UV_IR_zero_or_cyclicity_used':True,'higher_ordered_Born_insertions_not_evaluated':True,'complete_antighost_QAP_Slavnov_E5_A5_or_authority_change':False,'current_functional_or_source_changed':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
