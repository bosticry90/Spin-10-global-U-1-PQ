# First ub12 reference contraction

Prospective until completed independent receipt and committed-byte checks.
Paired routes obtain nonzero STr(Gref C12)=16 g10 xi C12 epsilon12/P,
P=p0^2-p1^2-p2^2-p3^2, before common determinant normalization.
All824 insertion positions retained;40 reference edges close nontrivially.
No ghost/auxiliary/scalar directions eliminated and no widths specialized.

This disproves a zero-first-contraction shortcut. It does not calculate a
nonzero UV log. DERIVATION and independent validation distinguish the nonzero
power-sensitive flat Gaussian shell from its zero logarithmic coefficient.
Full heat-background/higher Born contributions remain unevaluated. Wrong
ordinary trace and actual-entry omission controls sensitive; odd h/k
reordering control insensitive for this particular trace, disclosed.

Independent check must reconstruct all matrix entries by left Eulers,
contract the actual complete Green inverse, compare all participating edges
and evaluate even/odd Gaussian normalization fixtures plus radial shell.
No new functional/source/input/scheme/benchmark/policy/authority change.
SourcefreeSlavnov/QAP/measure/contact/IR/E5/A5 remain unqualified; seven flags
false, authority34/39, blocks/paused work/closed routes/custody2-seven retained.
Shared action/chart/insertion/reference/software/AI author; no expert claim.

Next: isolate logarithmic-support ordered insertions and necessary contact
subtraction before a bounded actual coefficient evaluation. No210-profile
or whole-Gamma expansion justified by this first contraction alone.
