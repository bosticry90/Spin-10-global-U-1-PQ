# Reference symbol versus logarithmic ultraviolet coefficient

The actual complete824-row insertion is interpreted as h_i C_ij k_j, moving
h to the left and k to the right with Grassmann signs. The inverse indices
and supertrace weights are those of the qualified643-field reference. The
one-loop determinant convention is i/2 STr log; the factor1/2 is not absorbed
into C. Finite even and odd Gaussian fixtures check this convention.

The paired symbol contraction is nonzero:

    STr(Gref C12) = 16 g10 xi C12 epsilon12 /
                   (p0^2-p1^2-p2^2-p3^2).

This is a rational symbol, before the common determinant/loop normalization.
It is not a measured local logarithmic pole. Forty nonzero closed reference
edges contribute; other insertion entries do not close on this propagator.
The ordinary-trace control reverses its sign. Dropping h/k odd reordering is
insensitive for these participating coefficients and must not be advertised
as a successful sensitive control. Actual participating-entry deletion is
sensitive. Independent extraction by two left Euler derivatives, adjusted for
the coefficient parity, verifies the full tensor-to-matrix bridge.

For the flat Wick-rotated radial symbol only, P=p0^2-|p|^2=-q_E^2.
With a>0 and fixed R>0, its q^-2 factor has Gaussian UV-shell integral

    int_(|q|>R) d4q/(2pi)^4 exp(-a q^2/Lambda^2)/q^2
      = Lambda^2 exp(-a R^2/Lambda^2)/(16 pi^2 a).

Expansion is Lambda^2/(16pi^2 a)-R^2/(16pi^2)+O(Lambda^-2):
there is no log Lambda term. This keeps the nonzero power sensitivity and
does not set a scaleless UV+IR integral to zero. It is only the flat rational
symbol with this explicit shell. It does not qualify the full covariant heat
expansion, higher Born words, subleading symbols, finite parts, arbitrary
cutoffs or physical IR removal. Those can require additional contributions.

Thus neither the earlier nonzero Hessian insertion nor this nonzero first
contraction establishes a nonzero logarithmic breaking or anomaly. The next
justified task concerns the logarithmic-support ordered words and their
actual color/propagator contractions, with composite/contact assumptions
retained. Do not fit that result from a desired antighost identity.
