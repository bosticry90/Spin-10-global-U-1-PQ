# ub12 first reference contraction V1

Base44a719d4fa7ec29e3786bb22003f5973b5f5ca80, liveAGENTS delegation.
Question BRT.1: does the complete actual ub12 mixed Hessian insertion have
a nonzero one-reference-Green supertrace? The classical breaking is exactly
zero in this direction, but its Hessian insertion has824 positions. Nonzero
matrix entries do not determine their trace or UV pole. This is the least
expensive first ordered Born insertion test, not another full loop compiler.

Freeze worker/controller/input bytes before two sequential own-role routes,
120s afterimports/8GiB private/minimum350MiB commit each. Distinct matrix
assembly versus propagator-first closed-edge contraction. Independent ordinary
graded polynomial and finite even/odd Gaussian normalization checks, same caps.
Use actual full643 reference inverse; no ghost/auxiliary elimination, EOM,
width choice, new reference mass, regulator, IR removal or scalar Laplacian.

From qualified complete mixed tensor select all eps12 rows, verify no jets,
exactly one h and one k per row. Move h to the left and k to the right with
actual Grassmann signs to form C_ij; retain all source sums. Contract
STr(Gref C)=sum_ij(-1)^p_i G_ij C_ji, actual inverse indices and coefficients.
All entries of C and both orientations included. Distinguish cancellations
from forbidden/zero Green entries. A zero first contraction closes only the
one-insertion reference term, not terms with interaction Hessian factors.
No trace cyclicity, scaleless UV/IR-zero inference or inferred loop coefficient.
Negative controls: actual participating entry deletion, wrong ghost weighting,
or wrong odd-order sign when sensitive. Disclose insensitive controls.

Validate actual contractions and resource captures before local commit. Preserve
all failures and statuses. Outputs may be exact zero, nonzero rational symbol
or inconclusive; none alone qualifies full antighost/Slavnov/QAP/E5/A5.
Seven quantum flags, functional/source/input/authority34/39 and blocks unchanged.
Methods share qualified action, chart, insertion and reference, software and AI
author; not independent scientists or validation of those physical premises.
