"""Neutral-Higgs charge closure and a conditional primitive-box IR diagnostic."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement,product
import json,sys,time
import sympy as s
import mpmath as mp

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'canonical_so10_higgs_colored_positive_cubics'))
import positive_cubics as pc
oc=pc.oc;hp=pc.hp
mp.mp.dps=80
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
trace=lambda a:sum(a[i,i] for i in range(a.rows))
txt=hp.text
matrix_text=lambda a:[[txt(a[i,j]) for j in range(a.cols)] for i in range(a.rows)]

def weight_add(*ws):return tuple(sum(z) for z in zip(*ws))
def weight_char():
    vectors=[]
    for j in range(5):
        for sign in [-1,1]:vectors.append(tuple(sign if k==j else 0 for k in range(5)))
    zero=(0,)*5
    symmetric=Counter(weight_add(vectors[i],vectors[j]) for i,j in combinations_with_replacement(range(10),2));symmetric[zero]-=1
    form=Counter(weight_add(*(vectors[i] for i in chosen)) for chosen in combinations(range(10),5))
    adjoint=Counter(weight_add(vectors[i],vectors[j]) for i,j in combinations(range(10),2))
    full=symmetric+form+Counter(vectors)+Counter(vectors)+Counter({zero:2})
    assert sum(symmetric.values())==54 and sum(form.values())==252 and sum(adjoint.values())==45 and sum(full.values())==328
    def mapped(char):
        out=Counter()
        for w,m in char.items():out[w[0]-w[1],w[1]-w[2],2*sum(w[:3])-6*w[4]]+=m
        return out
    return mapped(full),mapped(adjoint)

def highest(char,p,q,charge6):
    roots=[(2,-1),(-1,2),(1,1)];answer=0
    for flags in product([0,1],repeat=3):
        a=sum(flags[i]*roots[i][0] for i in range(3));b=sum(flags[i]*roots[i][1] for i in range(3))
        answer+=(-1)**sum(flags)*char[p+a,q+b,charge6]
    return answer

def main():
    assert __debug__
    prep=read(HERE/'preparation.json')
    for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
    writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('CHARGE_SECTOR_WRITE_DENIED')
    sys.addaudithook(readonly);started=time.perf_counter()
    census=read(HERE.parent/'canonical_so10_higgs_scalar_census/original_result.json')
    print('STAGE SM_ledger_charge_selection_then_independent_D5_Weyl_projection',flush=True)
    rows=[]
    for row in census['scalar_ledger']:
        p,q,n,y=row['label']
        if (p,q)!=(1,0):continue
        for m in range(-n,n+1,2):
            if 3*m+y==2:rows.append(dict(row,weak_weight=m,electric_charge='1/3'))
    total=sum(r['total_copies'] for r in rows);positive=sum(r['positive_copies'] for r in rows);orbit=sum(r['gauge_orbit_zero_copies'] for r in rows)
    assert total==10 and positive==8 and orbit==2 and all(r['PQ_zero_copies']==r['Higgs_zero_copies']==0 for r in rows)
    full,adj=weight_char();assert highest(full,1,0,2)==total and highest(adj,1,0,2)==orbit and highest(full,0,1,-2)==total
    raw_count=full[1,0,2];wrong_hypercharge=sum((r['label'][2]+1)*r['total_copies'] for r in census['scalar_ledger'] if r['label'][:2]==[1,0] and r['label'][3]==2)
    assert raw_count!=total and wrong_hypercharge!=total
    triplet=[(1,0),(-1,1),(0,-1)];antitriplet=[(0,1),(1,-1),(-1,0)]
    toy=Counter((a,b,2) for a,b in triplet)
    toy.update((antitriplet[i][0]+antitriplet[j][0],antitriplet[i][1]+antitriplet[j][1],2) for i,j in combinations_with_replacement(range(3),2))
    assert toy[1,0,2]==2 and highest(toy,1,0,2)==1
    point=read(HERE.parent/'canonical_so10_higgs_projected_vertices/original_v2_result.json');h=oc.from_json(point['precisions'][1]['h']);vac=hp.oracle.vacuum_state()
    Q=(pc.J(0,1)+pc.J(2,3)+pc.J(4,5))/3-pc.J(8,9)
    colors=[pc.J(0,1)-pc.J(2,3),pc.J(2,3)-pc.J(4,5)]
    for i,j in combinations(range(3),2):
        a=oc.VECTORS[2*i][1];b=oc.VECTORS[2*j+1][1];E=(a*b.T-b*a.T)/2
        colors.extend([E.applyfunc(s.re),E.applyfunc(s.im)])
    assert len(colors)==8
    for G in [Q]+colors:assert oc.equal(oc.transform(G,h),hp.oracle.zero_state()) and oc.equal(oc.transform(G,vac),hp.oracle.zero_state())
    labels={tuple(row['label']) for row in rows};even={k for k in labels if k[2]%2==0};odd=labels-even
    supports={kind:{(tuple(z['from']),tuple(z['to'])) for z in census['candidate_support'][kind]['blocks'] if tuple(z['from']) in labels and tuple(z['to']) in labels} for kind in ['A','B']}
    assert supports['A']=={(a,b) for a in labels for b in labels if (a in even)!=(b in even)}
    assert supports['B']=={(a,b) for a in labels for b in labels if (a in even)==(b in even)}
    e=sum(r['total_copies'] for r in rows if tuple(r['label']) in even);o=total-e;po=sum(r['positive_copies'] for r in rows if tuple(r['label']) in odd)
    assert (e,o,po)==(6,4,2)
    component_bounds={'even_complex_dimension':e,'odd_complex_dimension':o,'positive_odd_complex_dimension':po,
        'full_A_real_components':2*e*o,'full_B_real_components':e*e+o*o,'known_R_all_partner_A_real_components':2*5*o,
        'known_RR_and_RT_B_real_components':25+10,'remaining_full_A_real_components':2*o,'remaining_full_B_real_components':1+o*o,
        'remaining_positive_A_real_components':2*po,'remaining_positive_B_real_components':1+po*po,
        'remaining_positive_total_real_components':2*po+1+po*po,'remaining_full_total_real_components':2*o+1+o*o,
        'component_counts_are_free_parameters_or_progress_scores':False}
    print('STAGE actual_orbit_charge_selection_and_conditional_primitive_box_IR',flush=True)
    oldo=read(HERE.parent/'canonical_so10_higgs_colored_orbit_cubics/original_result.json');oldr=read(HERE.parent/'canonical_so10_higgs_colored_block/original_result.json')
    orbits=list(map(oc.from_json,oldo['orbit_basis']));selected=[]
    for i,a in enumerate(orbits):
        if oc.equal(oc.transform(Q,oc.transform(Q,a)),oc.sc(a,-s.Rational(1,9))):selected.append(i)
    assert len(selected)==4
    assert max(abs(mp.mpf(z)) for i,row in enumerate(oldo['canonical_orbit_A']) if i not in selected for z in row)<mp.mpf('1e-48')
    A=mp.matrix([[mp.mpf(z) for z in oldo['canonical_orbit_A'][i]] for i in selected]);M=mp.matrix(oldr['M']);eig,_=mp.eigsy(M);mu=eig[0]
    assert mu>0
    S=A*(M**-1)*A.T;norm2=sum(z*z for z in A);tr2=trace(S*S);bound=(norm2/eig[eig.rows-1])**2/4
    assert tr2>=bound*(1-mp.mpf('1e-50')) and bound>0
    leading=-mp.mpf(3)/4*tr2
    AF=mp.zeros(14);AF[:10,10:]=A.T;AF[10:,:10]=A
    samples=[]
    for text_z in ['.01','.0001','.000001','.00000001']:
        z=mp.mpf(text_z);D=mp.zeros(14);D[:10,:10]=(M+z*mp.eye(10))**-1;D[10:,10:]=mp.eye(4)/z
        density=-mp.mpf(3)/8*trace((D*AF)**4);Sz=A*(M+z*mp.eye(10))**-1*A.T
        reduced=-mp.mpf(3)/4*trace(Sz*Sz);ratio=z*z*density/leading;lower=(mu/(mu+z))**2
        assert abs(z*z*density-reduced)<mp.mpf('1e-50') and lower-mp.mpf('1e-50')<=ratio<=1+mp.mpf('1e-50')
        samples.append({'k_squared':text_z,'k_fourth_times_h4_integrand':txt(z*z*density),'ratio_to_IR_limit':txt(ratio),'Loewner_lower_ratio_bound':txt(lower)})
    z,hvar=s.symbols('z h',positive=True);ks=s.Matrix([[z+2,3*hvar],[3*hvar,z]])
    direct=s.simplify(s.diff(s.log(ks.det()),hvar,4).subs(hvar,0)/48)
    ds=s.diag(1/(z+2),1/z);asym=s.Matrix([[0,3],[3,0]]);born=s.simplify(-s.trace((ds*asym)**4)/8)
    assert s.simplify(direct-born)==0 and s.limit(z*z*born,z,0)==-s.Rational(81,16)
    artificial=s.diag(1/(z+2),1/(z+1));assert s.limit(-z*z*s.trace((artificial*asym)**4)/8,z,0)==0
    for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
    assert not writes
    result={'schema':'NEUTRAL_HIGGS_COLORED_CHARGE_SECTOR_V1','status':'COMPLETE_CHARGE_CLOSURE_AND_CONDITIONAL_PRIMITIVE_IR_DIAGNOSTIC_ONLY',
        'selected_SM_components':rows,'complex_dimension_per_color':total,'positive_complex_dimension_per_color':positive,'orbit_complex_dimension_per_color':orbit,
        'real_dimension_including_color_and_conjugates':6*total,'positive_real_dimension_including_color_and_conjugates':6*positive,'orbit_real_dimension_including_color_and_conjugates':6*orbit,
        'independent_D5_Weyl_total':highest(full,1,0,2),'independent_D5_Weyl_adjoint':highest(adj,1,0,2),'conjugate_multiplicity':highest(full,0,1,-2),
        'actual_neutral_generators':{'Q':[str(z) for z in Q],'color':[[str(z) for z in G] for G in colors]},
        'allowed_A_label_blocks':[[list(a),list(b)] for a,b in sorted(supports['A'])],'allowed_B_label_blocks':[[list(a),list(b)] for a,b in sorted(supports['B'])],
        'component_upper_bounds':component_bounds,'potential_M_inputs_complete_at_frozen_vacuum':True,'all_A_and_B_inputs_complete':False,
        'selected_orbit_basis_indices':selected,'IR_S_zero':matrix_text(S),'IR_trace_S_squared':txt(tr2),'IR_trace_positive_lower_bound':txt(bound),
        'conditional_box_h4_integrand_IR_coefficient':txt(leading),'IR_samples':samples,'primitive_box_has_log_IR_under_potential_zero_propagator_shortcut':True,
        'two_species_control':{'direct_logdet_h4':str(direct),'trace_box_h4':str(born),'zero_orbit_IR_coefficient':'-81/16','arbitrary_positive_orbit_test_mass_IR_coefficient':'0'},
        'negative_controls':{'raw_color_weight_count':raw_count,'wrong_Q_equals_hypercharge_count':wrong_hypercharge,'synthetic_triplet_plus_antisextet_raw_count':2,'synthetic_correct_triplet_count':1,
            'delete_orbit_box_IR_coefficient':'0','omit_one_orientation_IR_coefficient':txt(leading/2),'arbitrary_positive_orbit_test_mass_limit':'0'},
        'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes,
        'full_IR_sum_evaluated':False,'finite_Higgs_threshold_calculated':False,'physical_gauge_EFT_IR_adopted':False,'scientific_authority_changed':False,'whole_goal_complete':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started},sort_keys=True),flush=True)

if __name__=='__main__':main()
