# Complete colored charge block and a conditional infrared obstruction

The neutral-Higgs potential can mix a closed60-real-dimensional colored
charge sector:48 positive scalar directions and12 potential gauge-orbit
directions, including color and conjugates. Its potential mass inputs are
already available. At most nine additional real A/B coefficient values are
needed to specify the projection onto the positive scalar subspace.
These are fixed-action coefficient values to calculate, not new adjustable
model parameters or a measure of physical completion.

A second result identifies a concrete limit of a tempting shortcut. Using
potential orbit zeros as massless propagators at zero external momentum
makes one already nonzero primitive box graph logarithmically infrared
sensitive. The full infrared sum has not been evaluated. This is not a
failure of the physical model or a new finite Higgs correction; it establishes
why a full calculation cannot leave its gauge/infrared prescription implicit.

The frozen scope is in [RECORD.md](RECORD.md); qualification requires completed
captures, the [validation receipt](validation_receipt.json) and exact Git custody.

The electric charge condition is Q=T3+Y=1/3. Selecting actual weak components
from the complete qualified scalar SM ledger gives the following complex
directions per color. Labels are(SU3 Dynkin p,q,SU2 highest weight n,6Y).

| Label | Weak T3 | Total copies | Positive | Potential orbit |
| --- | ---: | ---: | ---: | ---: |
| (1,0,0,2), R | 0 | 5 | 5 | 0 |
| (1,0,1,-1) | +1/2 | 3 | 2 | 1 |
| (1,0,1,5) | -1/2 | 1 | 0 | 1 |
| (1,0,2,2), T | 0 | 1 | 1 | 0 |

Ten complex directions times three colors and reality give60 real directions,
with no extra conjugate factor. No PQ or tuned-Higgs zero belongs to this
block. The conjugate color/charge block has the matching multiplicity.

An independent construction rebuilds the full328-weight character from
traceless Sym^2(10), Lambda^5(10), two vectors and two singlets. A Weyl
denominator projection extracts SU3 triplet highest multiplicity at fixed
electric charge:10. The same calculation on Lambda^2(10) gives two broken
adjoint copies in this sector. Using raw color weights instead gives12;
equating Q with hypercharge gives8. Both shortcuts are incorrect. A fixed
triplet-plus-antisextet example separately detects the raw-weight overcount.

Actual field transformations show that Q and all eight real color generators
annihilate both the vacuum and saved rational Higgs. Together with the
qualified invariant parent action and complete character, this establishes
closure of the potential fluctuation operator under color and charge.
It does not define a gauge-fixed quantum operator. The rational Higgs is
not silently replaced by an exact Hessian null vector.

Let E contain R's five copies and T's middle component, complex dimension6.
Let O contain the two positive doublet partners and two orbit components,
complex dimension4. Existing necessary support rules imply

```text
M = diag(M_E,M_O)
A = [ 0   X  ]       B = diag(B_E,B_O)
    [ X†  0  ]
K(h) = M + h A + h^2 B
```

These are complex multiplicity matrices; realification and color are already
accounted for above. A has at most48 real component values, and B at most52.
The component rules permit entries; they do not prove those entries nonzero
or independent as functions of the parent couplings.

The existing R mass, triplet mass, positive-partner mass and potential orbit
zero classifications supply M at the frozen vacuum. R-to-positive A is
measured; R-to-orbit A retains its qualified classical Ward assumptions and
the full rational-Higgs residual correction. R/R B and R/T B are measured.
The remaining requirements are:

| Subspace | Missing A values | Missing B values | Total upper bound |
| --- | ---: | ---: | ---: |
| Positive projection,8 complex directions per color | 4(T to positive partners) | 1(T/T)+4(positive partner B) | 9 |
| Full potential sector,10 complex directions per color | 8(T to all partners) | 1(T/T)+16(all partner B) | 25 |

The full partner B block includes positive/orbit and orbit/orbit mixing.
The positive projection has48 real directions including color/conjugates.
Its determinant defines a restricted scalar graph contribution. It omits
mixed orbit/light graphs and is not a physical Higgs matching condition.

For the conditional infrared test, exact Q action selects saved orbit basis
indices0,1,6,7. The other-charge rows are excluded by symmetry and agree
with the inherited zeros. Use the actual selected4x10 orbit-to-R cubic A,
including the old rational-Higgs Ward correction, and the positive R mass M.
Define z=k_E^2 and S(z)=A(M+zI)^-1 A^T. The primitive box with a zero
potential orbit mass obeys

```text
Tr[(D A_full)^4] = 2 Tr[S(z)^2]/z^2
z^2 f_box,h4(z) -> -3 Tr[S(0)^2]/4
Tr[S(0)^2] = 0.0000486352318876393432
limit coefficient = -0.0000364764239157295074
```

Here f is the unintegrated h^4 potential-density coefficient, including
color3, with the momentum integration measure factored out. The displayed
number is not delta_lambda. The two trace orientations are retained.
Since the four-dimensional radial measure is proportional to z dz, a
nonzero1/z^2 integrand produces a logarithmic small-momentum integral.

Positivity of M gives a strict lower bound on the nonzero trace:
Tr[S(0)^2]>=||A||_F^4/(4*m_max^4)=7.69638294706522e-7, where m_max^2 is
the largest R squared mass. This notation keeps the mass dimensions explicit.
For mu=min eigenvalue(M), the exact matrix-order argument gives
[mu/(mu+z)]^2<=Tr[S(z)^2]/Tr[S(0)^2]<=1.
The full14x14 matrix trace and reduced expression agree at
z=10^-2,10^-4,10^-6,10^-8 and satisfy the bound. At10^-8 the ratio to the
nonzero limit is0.999999920469806.

An exact two-species determinant and ordered trace independently yield
-81/[4*z^2*(z+2)^2], with limit z^2 f=-81/16. Deleting the orbit line or
assigning an arbitrary positive test mass changes that limit to zero;
omitting an orientation halves the actual coefficient. These are negative
controls for invalid shortcuts, not authorizations for a propagator choice.
Other primitive terms or consistent field shifts/subtractions may cancel
infrared pieces in a complete calculation. No claim about that sum is made.

The original/fresh calculations take0.635/0.600seconds after imports, and
produce identical result SHA256
34a2ac5a587fcc13145827e4c4b2879300d7a4e31ccccbd77ff0fc9a0b5492c9.
Highest sampled private allocations are2,351,890,432 and842,567,680bytes;
short-run sampling does not certify the instantaneous peak. Both observed
launches and captured samples meet the established resource contract.
No tensor derivatives or old expensive physics calculations are repeated.

Final validation uses a different generating-function/exterior-algebra
character construction and the Weyl permutation sum, Fraction output-index
field transformations, and NumPy full/reduced actual-box calculations.
It checks counts, support, missing-input bounds, infrared limits/inequalities,
negative controls, sources/resources/state and prior receipts. The numerical
matrices inherit their qualified precision; this is not a new interval
certificate. Raw staged and committed blob checks remain separate.

The smallest useful continuation is to determine the nine positive-subspace
coefficient values, using the existing cubic stencil and homogeneous quartic
polarization with selected independent literal derivatives. Reuse the known
bases and coefficients. Earlier profiles suggest a bounded run measured in
minutes; freeze an actual source/resource contract before launch. No general
328-component compiler is required. Once qualified, the complete projected
BB/AAB/AAAA scalar1PI contribution could be calculated under its explicitly
restricted prescription. Reassess cost before expanding to other sectors.

The full charge-sector calculation additionally requires the missing orbit
blocks and an explicit gauge-fixing/EFT/infrared definition. Potential orbit
zero modes cannot be deleted or treated as ordinary massive particles. Heavy
exchange, field normalization, tadpoles, light subtraction and gauge/fermion
contributions remain necessary for physical Higgs matching. The earlier
incident-R BB=-0.00923851965645282671 remains partial and cannot alone be
added to the relaxed tree quartic as a physical prediction.

The bounded AI-capability evidence is the identification of a complete charge
sector, a much smaller input requirement, and a concrete flaw in an undefined
propagator shortcut. The outcome does not demonstrate that AI has validated
the full theory. Shared action, data, representations, software and analyst
remain possible shared errors. Education stays voluntary and nonblocking.

Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.
All prior successes/failures, E5/A5 qualifications, HB1/C5 blocks, uncalculated
C1_GS, flavor pause, fullBFB/naturalness/phenomenology limits and custodyexit2/
seven unresolved references remain. No foundational assumption, scientific
authority, benchmark, frozen evidence or remote state changes. Broad goal
remains active/incomplete.
