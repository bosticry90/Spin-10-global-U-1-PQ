# Neutral-Higgs colored charge sector: prospective contract V1

Baseline41e4d15586419babcdfc234c845a4db7c6b63ad8. Previous goal turn PROGRESS:
actual R/T cross-B, positive triplet mass and finite BB component validated
and committed. Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.

Question: what complete color-triplet/electric-charge1/3 scalar block can a
neutral-Higgs potential fluctuation mix, which qualified inputs are missing,
and why is an unqualified orbit-propagator prescription insufficient? This
is a bounded feasibility and infrared-shortcut assessment before more tensor
extraction. It does not authorize a physical gauge choice or full matching.

Recover the block from the existing complete scalar SM ledger. For label
(p,q,n,y), require(p,q)=(1,0) and an actual weak weight m with
Q=m/2+y/6=1/3. Include positive and all zero-mode copies, and separately
account for the conjugate block and color degeneracy. Do not confuse color
Cartan weights with irreducible representations, or hypercharge with Q.

Independently rebuild the full328-weight character from traceless Sym^2(10),
Lambda^5(10), two10s and two singlet weights. This combined126+126bar needs
no Hodge split. Build the adjoint character from Lambda^2(10). At fixed Q,
extract SU3 highest multiplicity by the Weyl-denominator finite difference
over the three positive roots(2,-1),(-1,2),(1,1). Require agreement with the
SM-ledger total and gauge-orbit counts. Use synthetic triplet+antisextet and
wrong-Q controls; record actual raw-weight overcount if present.

Check actual neutral Higgs and vacuum invariance under Q and eight real
color generators, with exact field transformations. Freeze the parent
invariance and complete character as qualified dependencies. This proves
potential M,A,B cannot leave the complete selected color/Q block. Use the
existing necessary A/B support rules within the selected labels to derive
the even/odd weak-parity block pattern; allowed support is not a measured
nonzero vertex. Count coefficients as component upper bounds, not free
parameters, amplitudes, evidence volume or progress percentages.

Reconcile the existing R mass/B, T mass/cross-B, positive-partner mass,
R-positive-A and conditional R-orbit-A records with this block. State exact
remaining A/B component requirements, distinguishing the full potential
block from projection onto the positive scalar subspace. A positive-only
determinant can define a restricted graph contribution; it misses mixed
orbit/light graphs and is not a physical threshold or adopted EFT.

Use the already qualified actual R/orbit A and positive R mass matrix for a
conditional IR test. Determine the orbit basis directions with Q^2=-1/9 by
actual exact Q action, retain their full rational-Higgs Ward correction and
check structural exclusion of other-charge rows. Let A be the selected
orbit-to-R cubic matrix, S(z)=A(M_R+zI)^-1 A^T, z=k_E^2>0. For the primitive
box using potential zero masses as orbit propagators, derive
Tr[(D A_full)^4]=2 Tr[S(z)^2]/z^2 and
z^2 times its color3 h^4 integrand -> -3 Tr[S(0)^2]/4.
Measure the actual coefficient and require agreement by distinct full-matrix
and reduced calculations. If nonzero, this particular zero-momentum graph
has logarithmic IR sensitivity. Do not infer the sum of all IR terms fails:
other graphs, field shifts, EFT subtraction and gauge fixing remain absent.

Use positivity of M_R to justify
[mu/(mu+z)]^2 <= Tr[S(z)^2]/Tr[S(0)^2] <= 1, mu=min eigenvalue(M_R),
and check z=10^-2,10^-4,10^-6,10^-8. Obtain the two-species trace/determinant
identity independently with exact symbolic polynomials. Negative controls
delete the orbit line, assign it an arbitrary positive test mass, or omit
one orientation; require the changed IR result. These controls test invalid
shortcuts, not new physical propagator definitions. Preserve any discrepancy.

Original/fresh observed read-only workers must reproduce deterministic result
bytes with immediate350MiB available-commit observation and8GiB private cap.
Use independently routed Fraction character enumeration, exact generator
actions, NumPy full-matrix IR limits and trace/bound checks in final validation.
Authenticate qualified predecessors rather than repeat expensive physics or
whole-workspace metadata. Bind report/handoff and source/state bytes, then
check exact staged/committed Git blobs before local commit. First failure
stops qualification; failed/incomplete work is preserved, never truncated.

Authority ceiling: charge-sector closure, bounded missing-input requirements,
and one conditional potential-only primitive-box IR diagnostic. No new
finite Higgs threshold, physical gauge/EFT/IR adoption, benchmark/model change,
state promotion or blocked-stage activation. Preserve E5/quartet failures,
HB1/C5/C1_GS boundaries, globalBFB/naturalness/phenomenology limitations,
flavor pause and custodyexit2/seven unresolved references. No branch/worktree,
reset, unrelated process termination, remote push, publication or outreach.

Physics and AI-capability objectives remain equally important. Education is
voluntary, concurrent and nonblocking. Record whether AI identifies the
scientifically relevant missing assumptions and avoids an invalid shortcut.
Shared action, representation/evidence inputs, software and analyst limit
independence; no external endorsement or experimental support is inferred.
