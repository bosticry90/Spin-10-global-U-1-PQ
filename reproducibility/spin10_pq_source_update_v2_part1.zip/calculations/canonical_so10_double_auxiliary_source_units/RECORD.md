# Double-source general-momentum unit kernels V1

Baseline c47651dad9715316f47e976ebfdff918bdd6b10d. The qualified complete
inventory leaves only KL*KL and SL*SL*F*F for the dimension-zero no-jet g4
JLambda*JLambda*C*C pole. This increment fixes their graded Gaussian/Wick
factors, not the actual Spin(10) color tensor or Slavnov relation.

Use four distinct external odd generators J0,J1,C0,C1; target order is
J0*J1*C0*C1 without any extra pair divisor. J(d1,gh-1), C(d1,gh+1).
Retain two ordinary vector copies B_t, auxiliaries L_t(d2), ghosts c_t
and antighosts a_t. These label independent internal lines, not new physical
particles or adopted inputs. The full principal inverse has ordinary B/B,
both mixed B/L and ghost orientations and L/L=0.

Freeze unit box vertices S0=J0*L0*c0, S1=J1*L1*c1,
F0=sum_mu eta_mu_mu derivative(a0)*B1_mu*C0 and
F1=sum_mu eta_mu_mu derivative(a1)*B0_mu*C1. Independently move each F
derivative to its internal a, internal B or external C: all nine combinations,
including expected zero external-derivative cases, remain required.
Freeze bubble vertices K0=J0*a0*c1*C0, K1=J1*a1*c0*C1. Ordered vertices
are even/d4/gh0; their coefficients are unity and are unrelated to model
couplings. Actual source-vertex order must be mapped explicitly later.

Keep four symbolic momentum components q, K=q0^2-q1^2-q2^2-q3^2 and a
separate denominator R until R=K is applied after contraction. Mixed inverse
entries are +i*q_mu/R and -i*q_mu/R; odd entries 1/R and -1/R. Retain the
full formal-width B/B inverse. Reuse the qualified UV annulus convention:
pole multiplier 2*i*K^2 after homogeneous contraction, relative to common
hbar/(32*pi^2*epsilon_UV). No whole-scaleless, finite or IR inference.

Primary: complete graded Fourier Hessians and every Born supertrace word,
with -i/4 at two vertices and -i/8 at four. Replay: ordered connected Wick
pairings, external odd extraction, momentum conservation and -i log Z with
vertex i factors and exponential factorial. Reuse frozen low-level unit
engines; do not read old physical or required poles, known Gamma, or peers.
Compare all ten kernels and poles after both workers finish.

Controls: both source and ghost interchange must flip the nonzero anchor;
wrong source parity must be rejected; repeated identical odd generators must
vanish while distinct pairs survive. Mixed deletion loses the box; blocking
one ghost edge and deleting reverse odd propagation must change sensitive
anchors. B/B deletion should be insensitive and recorded honestly. Verify
all derivative IBP row/column sums, the 16-element exterior basis and all256
products. Check full-source/full-F grouping: six S,S,F,F Born words equal
24 distinct-component words, and one grouped K,K word equals two distinct
component words. An extra pair factorial must change a nonzero coefficient.

Two sequential blind read-only workers: 120seconds after imports, sampled
8GiB, >=350MiB available commit. Freeze sources/controller/input bytes first;
complete captures precede qualification. Preserve all failed/unfinished runs;
no silent resource increase, changed model or removed requirement. Scoped
validation before local commit; old expensive loops authenticate only.

Authority ceiling: ten mathematical unit kernels and graded/factor controls.
No actual double-source pole, full quantum restoration, anomaly freedom or
E5/A5. Statev113/34of39 unchanged; HB1/C5 blocked, C1_GS uncalculated, flavor
paused. Prior failures, scalar warning and custodyexit2/seven preserved. No
physical-input/benchmark/foundation, protected evidence or remote change.
Shared toy model, helper software, UV convention and AI authorship limit
independence. Education is voluntary, concurrent and nonblocking.
