# Opposite unit factors, with the actual color contraction still open

Both mathematical routes agree on all ten complete general-momentum kernels
for the frozen two-source models. Relative to the declared target order
J0*J1*C0*C1 and common hbar/(32*pi^2*epsilon_UV), their nonzero factors are:

| Unit | Homogeneous kernel | Pole factor |
| --- | --- | --- |
| KL*KL bubble | -i/R^2 | +2 |
| SL*SL*F*F, both derivatives on internal antighosts | i*K^2/R^4 | -2 |
| Box, one antighost derivative and one vector derivative | -i*K^2/R^4 | +2 |
| Box, both derivatives on internal vectors | i*K^2/R^4 | -2 |
| Any box derivative on an external ghost | 0 | 0 |

K=q0^2-q1^2-q2^2-q3^2; R stays separate until contraction and R=K. These
are exact toy-kernel factors, not Spin(10) pole coefficients. The opposing
bubble/box signs do not establish a physical cancellation: their actual color
tensors must still be extracted, ordered and contracted from the unchanged
action. No desired identity or measured functional generated these values.

Primary uses graded Fourier Hessians and every ordered Born supertrace word;
replay uses independent connected Wick pairings, external odd extraction,
momentum conservation and -i log Z/exponential factors. All four momentum
components, both mixed and ghost orientations, and the full width-dependent
ordinary-vector inverse are available. No physical propagator prescription
or input is changed. This is a UV-annulus coefficient, not a whole scaleless
integral or finite/IR result.

All derivative integration-by-parts row/column sums vanish. Both source and
ghost interchanges flip the nonzero factor. Wrong source parity fails the
vertex grade; identical odd repetitions vanish while distinct source/ghost
pairs survive. The full 16-element exterior basis and its 256 products pass.
One grouped K,K word equals the two distinct-component words. Six grouped
S,S,F,F words equal the 24 distinct-component words. An extra half changes
bubble +2 to +1 and box -2 to -1.

Blocking either required ghost edge kills the anchors; deleting mixed
propagation kills the box. Deleting ordinary B/B propagation changes neither
anchor and is explicitly insensitive. Deleting only the reverse odd inverse
also changes both anchors, but that deliberately inconsistent inverse is not
a graded Gaussian covariance: the Born diagnostics are bubble +1/box -1,
whereas ordered-Wick diagnostics are bubble 0/box -1/2. These unequal corrupted
diagnostic numbers are preserved, not compared as a valid pole. The required
control is rejection/change, not a shared numerical value for an invalid
propagator. Every unmodified kernel agrees exactly; all other controls agree.

Primary/replay complete in 3.58/2.45 seconds after imports, within the frozen
120-second/sampled-8-GiB limits. No worker failed. The completed validation
receipt authenticates source/input/native captures, all ten paired kernels,
controls/grouping and authority bytes. Low-level helpers, toy model, action
conventions, Python/SymPy and AI authorship are shared; agreement does not
validate their physical applicability or constitute independent expert review.

Next derive the general color-trace expression from these factors, test it
on a small noncommuting matrix fixture, then extract the actual SL, KL and
the complete internal-antighost derivative F tensors from each route's own
literal action. Exact symmetry/exterior-pair reductions should precede any
dense pair-color expansion. Verify any proposed SL/KL relation from actual
tensors rather than assuming that +2 and -2 cancel.

Known Gamma92236 and selected background-Ward/Slavnov results stay unchanged.
No actual double-source pole, complete source closure, quantum restoration,
QAP/finite contact/measure/IR theorem, E5/A5 or anomaly freedom is established.
Statev113/34of39, blocked HB1/C5, uncalculated C1_GS, paused flavor, preserved
quartet/g2 failures, scalar warning and custodyexit2/seven are unchanged. No
physical-input/benchmark/foundation, protected evidence or remote changes.
Track B gains verified sign/factor reduction and honest invalid-control limits;
education remains voluntary, concurrent and nonblocking.
