"""Actual signs of two-source unit models; physical color coefficients excluded."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
sp=importlib.util.spec_from_file_location('qualified_unit_engine',ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/units_v2.py')
u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
s=u.s;q=u.q;K=u.K;R=u.R;MODE=None
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def model(kind,first='a',second='a'):
    w=u.alphabet();w.fields={**{f'uk_B{t}_{mu}':(1,0,0) for t in range(2) for mu in range(4)},
      **{f'uk_L{t}':(2,0,0) for t in range(2)},**{f'uk_{p}{i}':(1,1 if p=='c' else -1,1) for p in ['a','c'] for i in range(2)}}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    for n,z in [(f'uk_J{i}',(1,-1,1)) for i in range(2)]+[(f'uk_C{i}',(1,1,1)) for i in range(2)]:u.register(w,n,z)
    v=w.var
    def F(a,c,t,where):
        return w.add(*(w.scale(w.mul(w.D(v(a),mu) if where=='a' else v(a),
            w.D(v(f'uk_B{t}_{mu}'),mu) if where=='B' else v(f'uk_B{t}_{mu}'),
            w.D(v(c),mu) if where=='c' else v(c)),u.ETA[mu]) for mu in range(4)))
    if kind=='bubble':
        V=[w.mul(v('uk_J0'),v('uk_a0'),v('uk_c1'),v('uk_C0')),w.mul(v('uk_J1'),v('uk_a1'),v('uk_c0'),v('uk_C1'))]
    else:
        assert kind in ['box','B_X']
        V=[w.mul(v('uk_J0'),v('uk_L0'),v('uk_c0')),F('uk_a0','uk_C0',1,first),F('uk_a1','uk_C1',0,second),w.mul(v('uk_J1'),v('uk_L1'),v('uk_c1'))]
    assert all(w.grade(P,(4,0,0)) for P in V)
    if MODE:
        names=['uk_J0','uk_J1'] if MODE=='swap_sources' else ['uk_C0','uk_C1']
        V=[w.replace(P,{names[0]:v(names[1]),names[1]:v(names[0])}) for P in V]
    return w,V,w.mul(v('uk_J0'),v('uk_J1'),v('uk_C0'),v('uk_C1'))
u.model=model

def grouped(kind):
    w,V,target=model(kind);names=list(w.fields);ext=sorted(w.external);tc=u.pack(target,ext)[15]
    G={(i,j):{0:z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=u.green(a,b,q))}
    if kind=='bubble':blocks={'K':w.add(*V)};orders=[('K','K')]
    else:
        S0,F0,F1,S1=V;blocks={'S':w.add(S0,S1),'F':w.add(F0,F1)};orders=sorted(set(permutations(('S','S','F','F'))))
    H={}
    for tag,P in blocks.items():
        raw=u.Fourier_vertex(P,w,'primary',q,q,{n:[0]*4 for n in w.external})
        H[tag]={(i,j):u.pack(cell,ext) for i,row in enumerate(raw) for j,cell in enumerate(row) if cell}
    n=len(orders[0]);factor=s.I*(-1)**(n+1)/(2*n);kernels=[]
    for order in orders:
        A=G
        for j,tag in enumerate(order):
            A=u.sparse_mm(A,H[tag])
            if j<n-1:A=u.sparse_mm(A,G)
        value=sum((-1)**w.p[names[i]]*P.get(15,0) for (i,j),P in A.items() if i==j)
        kernels.append(s.factor(factor*value/tc))
    return s.factor(sum(kernels)),len(orders)

def main():
    global MODE
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('DOUBLE_SOURCE_UNIT_WRITE')
        if p.suffix=='.json':raise PermissionError('DOUBLE_SOURCE_UNIT_PHYSICAL_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard)
    calc=u.born if role=='primary' else u.wick;cases=[('bubble','a','a')]+[('box',a,b) for a,b in product(['a','B','c'],repeat=2)]
    table={};details={}
    for kind,a,b in cases:
        name=kind+'_'+a+b;print('STAGE '+role+' '+name,flush=True);value,info=calc(kind,a,b)
        table[name]={'kernel':str(value),'pole':str(u.pole(value))};details[name]=info
    number=lambda name:s.sympify(table[name]['pole'])
    for b in ['a','B','c']:assert sum(number('box_'+a+b) for a in ['a','B','c'])==0
    for a in ['a','B','c']:assert sum(number('box_'+a+b) for b in ['a','B','c'])==0
    controls={}
    for kind in ['bubble','box']:
        base=number(kind+'_aa');assert base!=0
        for mutation in ['omit_reverse_odd','block_ghost1','omit_BB']+(['omit_mixed'] if kind=='box' else []):
            value,unused=calc(kind,**{mutation:True});pole=u.pole(value)
            assert (pole==base) if mutation=='omit_BB' else (pole!=base),(kind,mutation,pole,base)
            controls[kind+'_'+mutation]={'pole':str(pole),'changes_result':bool(pole!=base)}
        for swap in ['swap_sources','swap_ghosts']:
            MODE=swap;value,unused=calc(kind);MODE=None
            pole=u.pole(value);assert pole==-base
            controls[kind+'_'+swap]={'pole':str(pole),'sign_reversed':True}
    w,V,T=model('box');u.register(w,'uk_J0',(1,-1,0));assert not w.grade(V[0],(4,0,0))
    w,V,T=model('box');assert not w.mul(w.var('uk_J0'),w.var('uk_J0')) and not w.mul(w.var('uk_C0'),w.var('uk_C0')) and T
    basis=u.exterior_basis_checks();groups=None
    if role=='primary':
        groups={}
        for kind,count,distinct in [('bubble',1,2),('box',6,24)]:
            value,words=grouped(kind);assert words==count and u.pole(value)==number(kind+'_aa')
            groups[kind]={'grouped_words':words,'distinct_component_words':distinct,'pole':str(u.pole(value)),'wrong_extra_half_pole':str(number(kind+'_aa')/2)}
    result={'schema':'DOUBLE_AUXILIARY_SOURCE_UNITS_V1','route':role,'all10_cases':table,'details':details,'controls':controls,
      'all_derivative_IBP_sums_zero':True,'odd_source_grade_control_rejected':True,'distinct_odd_pairs_retained_identical_repetitions_zero':True,
      'exterior_basis_checks':basis,'grouped_full_vertex_checks':groups,'general_four_component_momentum':True,'pole_multiplier':'2*I*K**2',
      'finite_IR_or_scaleless_inference':False,'actual_physical_color_tensor_or_required_pole_read':False,'actual_physical_source_pole_calculated':False,
      'unknown_quantum_breaking_set_zero':False,'full_E5_A5_or_anomaly_freedom':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
