# Scientific criticism and necessary-constraint screening V1

The construction remains incomplete. The current benchmark has a deliberately
tuned light doublet, a positive relaxed tree quartic and locally positive heavy
scalars. It has no certified global vacuum, radiative hierarchy protection,
complete gauge match or validated physical prediction. The criticisms justify
prioritizing cheap physical constraints before another substantial quantum run;
they do not establish a no-go for this benchmark, this construction or Spin(10).

This record is a bounded mathematical/diagnostic assessment. Qualification of
the new checks requires `validation_receipt.json`, the frozen preparations and
the complete original/fresh captures. They cannot promote `project_state.json`.
Baseline `1e19ab6aedb92a9d874424a151a7425bfc19c5e6`, state v113/34of39,
SHA256 `d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8`.
The read-only recovery found a clean checkout and no leftover workers. The
already-running source-pair validation finished before this review and is
preserved in that commit; no subsequent quantum amplitude was started.

## Criticism disposition

| Concern | Disposition against actual evidence | Research consequence |
| --- | --- | --- |
| Numerous scalar parameters lack a principle fixing their values. | **Partly valid.** The allowed operator basis is complete and symmetry-derived; numerical values are freely chosen, not symmetry predictions. A large parameter count alone is neither inconsistency nor proof of absent predictions. | Separate operator justification from parameter selection; assess observables before claiming predictivity. |
| Hashes, replays or fits may be mistaken for physical validation. | **Valid caution; stronger interpretation incorrect.** They establish integrity or reproducibility. Existing scope limits expressly withhold physical viability. The V46 source-coverage mistake nevertheless demonstrates that many passing tests can share a false premise. | Verify claim coverage and assumptions as well as arithmetic; do not count symbolic volume as physical progress. |
| Meaningful falsifiable predictions are missing. | **Valid about present completion; not proof of unfalsifiability in principle.** Gauge matching, flavor, proton decay and axion phenomenology are unfinished. Restricted interactions and common-coupling requirements are testable structures. | Keep the model incomplete/underdetermined; no numerical GUT prediction is currently earned. |
| What protects the favorable Higgs configuration? | **Unresolved, scientifically valid question.** Exact determinant tuning and selected portal coefficients establish the tree witness; no full-theory protection or radiative stability has been demonstrated. New mass sensitivity below is nonzero. | Carry the hierarchy/tuning burden explicitly; a positive quartic does not solve it. |
| Unknown finite thresholds prevent adjudicating unification. | **Valid and already recorded.** Known running plus one-loop thresholds has no common root, but missing finite terms have neither been computed nor rigorously bounded. | Derive a correction target; do not fit unknown coefficients or call the benchmark excluded. |
| Screen the positive light quartic and scalar stability first. | **Correct; substantially done already, still incomplete globally.** Current relaxed quartic is positive; an earlier quadratically acceptable point failed this exact test. Pure-sector and restricted mixed bounds exist. | Reuse successes and failures. The new full three-field bound narrows the remaining mixed-field problem. |
| Require a realistic intermediate spectrum. | **Conditional.** A controlled PS EFT is required for a PS-running calculation. It is not an extra prerequisite for the separately admitted direct broken-phase matching route. | Preserve the PS block and saddle witness without rejecting direct matching by association. |

The reviews are inputs, not independent verification. Their agreement with a
limitation does not itself establish that limitation; the cited records and
new calculations supply the evidence.

## Scalar structure, selection and fine-tuning

The frozen [parent action](../canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md)
is an exploratory source-derived variant, not the printed
[Babu–Khan scalar benchmark](https://arxiv.org/html/1507.06712v2).
The [basis qualification](../canonical_so10_scalar_reconstruction/RESULT_V2.md)
counts 34 real coefficient directions: 24 real self-adjoint coefficients and
five complex coefficients, before two permissible scalar rephasings. Generic
nonzero couplings therefore have 32 real directions after that quotient,
including three invariant relative phases. This generic count is not an
identifiability result on a tuned zero-coupling slice. Canonical kinetic
normalization is fixed; changing an invariant normalization is a convention
change, not a physical prediction.

Symmetry requires the allowed forms and Hermitian completion. It does not
require every allowed coupling to be nonzero or specify its value. At the
current point the VEV ratios `sigma/omega=v/omega=0.1`, vanishing portals
`lambdaPhiS=lambdaSigmaS=0`, `zD=0`, and chosen phases are benchmark selections.
The three tadpole masses follow from stationarity at those selected VEVs;
that is not independent experimental input. `mphi2` is adjusted by an exact
determinant condition. `lambdaPhiphi1=-0.002` was selected on a documented
post-pilot path to reduce the heavy-relaxation subtraction. Other coefficients
are finite-search witnesses, not measured quantities. Even the quoted overall
scale and gauge coupling remain unsuccessful-fit diagnostics.

The [current Higgs result](../canonical_so10_positive_higgs/RESULT.md) gives
`lambda_direct=0.1984523507`, heavy subtraction `0.0935941078`, hence
`lambda_eff=0.1048582429` for `V_eff=lambda_eff(H†H)^2`.
Its Hessian has 290 positive real directions, 33 gauge zeros, one PQ zero
and four tuned Higgs zeros. The inherited smallest positive mass squared is
`0.0865615578` when `omega²=60`; the changed-block minimum is
`0.1030988930` in those same units (divide by60 for `m²/omega²`). These are
local tree curvatures, not pole masses.
The colored floor was a scalar-screen choice, not a proton-decay bound.
The [earlier Stage2 point](../canonical_so10_light_higgs_quartic/RESULT.md)
has `lambda_eff=-56.4898354` despite positive fixed-heavy quartic and acceptable
quadratic spectrum. Its local-minimum failure is preserved.

The new four-by-four doublet calculation fixes all other couplings and finds

\[
p=m_\phi^2/\omega^2,\qquad
\frac{\partial(m_{\rm light}^2/\omega^2)}{\partial p}
=0.998035966278\ldots.
\]

The parent unit mass operator equals 60 times the canonical `10_H` projector.
The Hellmann–Feynman derivative equals the light `10_H` kinetic fraction.
Two-sided perturbations `delta p=10^-6,10^-8` and a separate NumPy Hermitian
eigensolver reproduce it. Thus generic changes of this mass parameter move
the tuned zero; they do not preserve a hierarchy automatically. To target a
small curvature `m_*²`, the conditional first-order requirement is
`|delta p| <= m_*²/(0.998036 omega²)`. No physical `omega` or electroweak mass
has been matched, so this is not a numerical physical tuning probability.
A logarithmic fine-tuning index at the exactly zero mass is undefined. A
nonzero response alone does not disprove every possible protection mechanism;
the missing interacting-symmetry and quantum evidence is a separate issue.

An exact opposite shift of `mphi2/omega²` and `lambdaPhiphi1` leaves this
doublet quadratic block unchanged; the inherited calculation shows the same
shift changes Higgs-heavy cubic sources and the relaxed quartic. This is
non-identifiability from quadratic data alone, not redundancy of the full
action. A vanishing isolated Hessian eigenvalue is not an interacting shift
symmetry. The [existing symmetry analysis](../canonical_so10_ps_multispurion/RESULT.md)
found only PQ in its connected fieldwise-commuting class and no enhanced
continuous protection of the selected small combinations; it did not exhaust
all discrete or nonlinear possibilities. Positive quartic and a heavy gap
support continuity locally in a suitable retuned neighborhood, but no uniform
parameter-radius certificate or quantum protection follows. Loop mass and
quartic corrections, kinetic matching and full matter data remain missing.

## Necessary-constraint screen

`PASS` below always names its scope. It is not a global model verdict.

| Condition and applicability | Evidence/status | Consequence and smallest missing step |
| --- | --- | --- |
| Complete invariant basis, Hermiticity and stated PQ charges | **PASS**, inherited scalar reconstruction | Defines the action. Does not fix parameter values or prove quantum/global consistency. |
| One light complex doublet, other physical tree curvatures positive at current vacuum | **PASS**, inherited complete Hessian/current point | Local scalar witness; electroweak mass generation and loop spectrum **INCOMPLETE**. |
| Relaxed light quartic positive at tuned current point | **PASS**, `+0.10485824`, inherited valley/Schur controls | No tree light-direction quartic instability there; not Higgs-mass matching or naturalness. |
| Old Stage2 relaxed quartic positive | **FAIL**, `-56.4898354`, historical point | That point is rejected locally; no transfer to current point or whole action. |
| Pure `54`, `126`, `10`, singlet and `54+10` quartics | **PASS**, [prior exact bounds](../canonical_so10_bfb_orbit/RESULT.md) | Reuse them; no need to repeat the 8,001-pair proof. |
| All `54+10+S` quartic directions with `126=0` | **PASS**, new exact sufficient bound below | Excludes runaways in this entire 76-real-dimensional sector, not in the full field space. |
| Full 328-real-field quartic boundedness | **INCOMPLETE** | Prior 200 rays/11 mixed strata found no negative witness, not a certificate. Next screen mixed `126` couplings/relative phases. |
| Globally preferred physical vacuum or acceptable metastability | **NOT TESTED** completely | Positive local Hessian does not compare all vacua or establish lifetime. |
| Higgs technical naturalness/radiative stability | **INCOMPLETE** | New nonzero mass sensitivity plus deliberate tuning; no protective mechanism or quantum error bound established. |
| Locally stable same-coefficient PS configuration | **FAIL** for the tested PS saddle: 120 triplet tachyonic directions | This can represent intended lower breaking; it is not a tachyon of the current SM vacuum. |
| Controlled PS interval EFT, if PS running is used | **INCOMPLETE**, PS interval blocked/multispurion unresolved | Need an admissible covariant field/operator ledger and certified truncation error. |
| PS interval required for admitted direct matching | **NOT APPLICABLE** | Direct route integrates the actual SM-vacuum heavy spectrum without inventing an interval EFT. |
| Direct one-loop field ledger, beta jump, normalization and scale checks | **PASS**, inherited [direct kernel](../canonical_so10_direct_gauge_matching/RESULT.md) | 290 heavy scalar directions and 33 vector/Goldstone/ghost sets included once. |
| Common root with known two-loop SM running and one-loop thresholds | **FAIL** at that specified approximation | Full gauge-unification verdict **INCOMPLETE**, because the omitted boundary is unbounded. |
| Uniform perturbative error smaller than gauge mismatch | **INCOMPLETE** | Small diagnostic alpha and finite coefficient box do not bound all loop amplitudes. No scalar scattering-unitarity certificate exists. |
| Model-specific Yukawa selection and symbolic normalization | **PASS** in scope | Two symmetric matrices; conjugate-10 operator forbidden. Numerical flavor/neutrino spectrum remains **INCOMPLETE**. |
| Proton/axion experimental compatibility | **NOT TESTED** for a completed physical benchmark | Need physical scales, amplitudes/flavor, PQ global identification and cosmological assumptions; no imported published lifetime or axion claim. |

The PS [quadratic/intercept evidence](../canonical_so10_ps_interval_eft/RESULT.md)
accounts for all 328 directions; its `-0.02496354 omega²` triplet curvature is
at a stationary saddle. A formal different-theory scaling family passes
through the physical point, but its numerical 132-direction heavy bound is
not a complete controlled EFT. The later
[route decision](../canonical_so10_gauge_route_selection/RESULT.md) separately
admitted direct feasibility: largest physical mass log `3.3964`, mass ratio
`29.8567`, weighted one-loop log diagnostic `0.09424`. These justify trying
fixed-order matching, not declaring its missing higher order small.

### New exact restricted-sector bound

For `Sigma=0`, put `x=tr(Phi²)`, `u=phi†phi`, `t=|S|`, and
`r=||Phi phi||`. The trace inequality and complex Cauchy–Schwarz inequality
give `tr(Phi⁴)>=x²/10` and `|phi^T Phi phi|<=sqrt(u) r`.
The nonnegative `lambdaPhiVector2 |phi·phi|²` can be dropped. With frozen
coefficients,

\[
V_4\ge a x^2+m x u+\ell r^2+c u^2+vut^2+et^4
-2|z_K|\sqrt u\,rt,
\]

where `a=13067/250000000`, `m=-1/500`, `ell=0.01943742`,
`c=0.1`, `v=0.00099786`, `e=1`, `|zK|=0.03`.
Completing the `x` and `r` squares leaves

\[
b u^2+dut^2+et^4,\quad
b=c-\frac{m^2}{4a}=0.0808678350\ldots,\quad
d=v-\frac{|z_K|^2}{\ell}=-0.0453045814\ldots.
\]

Its symmetric matrix has positive leading entry and exact determinant
`1101950177953885343186890862533/13713573172728830000000000000000`
`=0.0803547087...>0`. Together with the retained squares this proves strict
quartic positivity for every nonzero field configuration in this sector.
The general positivity/copositivity comparator is
[Kannike, Eqs.1–2](https://arxiv.org/html/1205.3781v3); the model-specific bound
is derived here, not imported from that paper. Six exact parent-oracle samples
check the tensor normalization and complex phases. A negative singlet quartic
gives an explicit negative ray, and omission of the Hermitian-completed `zK`
term gives a discrepancy. These are controls, not changes to the benchmark.
No conclusion about mixed nonzero `Sigma` follows.

## Gauge-threshold feasibility and convention audit

The [current frozen running calculation](../canonical_so10_direct_gauge_next_order/RESULT.md)
uses `MSbar`, `g1=sqrt(5/3) gY`, and direct background-field Feynman matching.
Its frozen inputs at `MZ=91.1876 GeV` are
`alphaEM^-1=127.93`, `sin²thetaW=0.23122`, `alphaS=0.118`, giving
`(alpha1^-1,alpha2^-1,alpha3^-1)=(59.01001524,29.5799746,8.47457627)`.
Two-loop SM gauge evolution includes the required one-loop top/bottom/tau
running; the scalar shape and VEV ratios stay fixed, and only `g10,omega`
are refitted by unweighted least squares in the three inverse couplings.
At `mu=omega`, define

\[
R_i=\alpha_U^{-1}-\lambda_i/(12\pi)-\alpha_{i,SM}^{-1}(\mu).
\]

Its diagnostic refit has `g10=0.5231256382`,
`omega=1.63737316e15 GeV`, and
`R=(0.2609147183,-0.7454764131,0.4847948100)`.
These are not accepted physical scales/couplings. With
`T R=(R1-R2,R2-R3)`, the nonuniversal mismatch is
`(1.0063911314,-1.2302712232)`. `P=I-11^T/3` is an alternative centered
representation; a common component is not a third independent difference.

Use the [Martens Eq.46 convention](https://arxiv.org/html/1011.2927v2):
`alpha_i=alpha_U zeta_i` and, at zero reference log,
`zeta_i=1-(alpha_U/pi) C0_i+(alpha_U/pi)^2 C1_i`.
The inverse series gives

\[
\delta\alpha_i^{-1}=k(C_{0i}^2-C_{1i}),\qquad
k=\alpha_U/\pi^2,\qquad C_{0i}=-\lambda_i/12.
\]

Therefore the fixed-point correction target is

\[
T C_1=T(C_0^2+R/k).
\]

The previous centered `(118.2134,-337.8911,219.6777)` is correctly a
**C1-equivalent inverse-coupling target**, `P R/k`, with
`C1_equiv=C1_raw-C0²`. It is not directly the raw coefficient of `zeta`.
The known centered square is `(267.1732,-145.7130,-121.4601)`, so the raw
fixed-point target would be `(385.3866,-483.6041,98.2175)` in this explicit
convention. Original boundary/comparison files remain unchanged. Any future
comparison must state which coefficient it calculates, account for known
reducible/inverse-expansion pieces once, and satisfy the already required
full convention-consistent refit. A centered magnitude/alignment score alone
cannot pass a gauge gate.

Refitting also matters. For `p=(ln g10,ln omega)`, the exact diagnostic
residual Jacobian columns at the old fit are approximately
`(-87.3828,-88.4969,-89.0539)` and `(0.656828,-0.498826,-1.120554)`.
Their unit normal is `(0.2815419,-0.8044117,0.5231213)`; its residual projection
is `0.9267349031`, with tangential residue below `4e-9`.
Thus locally one scalar obstruction remains after the two fitted parameters,
not three independent required constants. The nonuniversal coupling
dependence in the first column comes from vector masses proportional to
`g10 omega`. Changing the physical scale `omega` is distinct from varying
the unphysical matching ratio `mu/omega`. Changes to frozen scalar parameters
would be a different benchmark, not another nuisance adjustment here.
The full through-order condition is
`R(p)+k(p)[C0(p)^2-C1_total(p)]=0`. No new refit was performed, and no component
of `C1_total` was assigned to satisfy it. Linearized geometry is not a
certificate of a distant corrected solution.

There is no defensible finite-threshold bound from present inputs. RG
identities fix logarithms, not finite constants. The small scale envelope
`0.00759` and weak-boundary effect `<5.8e-5` cannot bound them. The parent
Yukawa-independent two-loop/one-loop beta ratio is already `0.26517` at the
diagnostic coupling: group multiplicities matter. The required correction is
not automatically nonperturbative, but neither its sign nor magnitude is
predicted. The full split spectrum, cubic/quartic vertices, counterterms,
tadpoles, hard subtraction and finite mass functions are needed.
The restricted published finite formula assumes conditions this multi-VEV,
trilinear, nondegenerate theory violates; its use would change the calculation.

Moreover, `C1_GS` is a subset, not automatically the entire missing boundary.
Mixed gauge/light-fermion graphs must be dispositioned, and Yukawa-dependent
terms require numerical matrices and neutrino spectral data. The later
[symbolic Yukawa convention](../canonical_so10_direct_two_loop_heavy_threshold/YUKAWA_CONVENTION_V1.md)
is fixed; older statements that its normalization is wholly unfrozen are
superseded in that limited respect. Numerical `Y10,Y126` and a physical flavor
point remain absent. Gram-matrix positivity gives no useful upper threshold
bound without those inputs.

There is also a distinct Higgs matching gap: the inherited SM quartic monitor
at this diagnostic scale is `-0.0345942128`, whereas the tree relaxed quartic
is `+0.1048582429`. Their difference is `0.1394524557`. This is a comparison
of incomplete diagnostics, not a computed quartic threshold or an exclusion.
Field/kinetic matching and quantum scalar/Yukawa corrections have not been
done. The SM boundary is the frozen historical
[Buttazzo et al. comparator](https://arxiv.org/abs/1307.3536), not a new fit to
current data.

## Predictivity, verification and priority

Mathematical consistency requires valid symmetries, vacuum/Goldstone
accounting and a coherent quantum restoration. Reproducible implementations
can test these conditionally. Physical compatibility additionally requires
matched Higgs/gauge data, realistic matter/neutrinos and accepted cosmology.
Explanatory or predictive power requires restrictive relations among those
observables after allowed parameters are fixed. None follows from potential
invariance or matching one selected scalar property.

Possible decisive outcomes remain model-specific: a valid negative quartic
ray rejects this benchmark's tree global stability; a complete gauge boundary
with controlled uncertainty could accept or exclude its coupling relations;
no matter solution with the permitted interactions could reject the specified
construction/assumptions. Proton amplitudes and axion couplings could give
experimental tests once the missing physical inputs exist. Published-model
lifetimes, axion windows and fitted Yukawas cannot be inherited automatically
by this variant. No validated restrictive numerical physical prediction is
established by the evidence reviewed here. That leaves incompleteness and
underdetermination, not a theorem that Spin(10) is unfalsifiable.

Integrity hashes authenticate bytes; fresh execution tests reproducibility;
distinct mathematical derivations and negative controls test specified error
modes; assumption completeness and physical relevance require their own
arguments; empirical confirmation requires observations. These are separate.
The preserved source-coverage correction in
[the g2 lineage result](../../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_SOURCE_LINEAGE_RESULT_V1.md)
is a concrete AI failure: algebra/replays were correct but an already measured
term was labeled missing. It warns against accepting mirrored tests as a
coverage proof. Conversely, the old negative relaxed quartic is a successful
physical-screen failure detection. Neither is external scientific endorsement.

| Next-action alternative | Assessment |
| --- | --- |
| Continue quantum/finite-threshold sequence immediately | Scientifically relevant to consistency and eventual matching, but costly and incapable alone of settling BFB, flavor or the hierarchy. Preserve the source-pair result; defer another substantial launch until the physical screen is dispositioned. No C5/HB1 permission follows. |
| Complete an inexpensive necessary-condition screen | **Recommended first.** This review executes the available bounded tests. Next target mixed nonzero `126` directions and relative phases, especially `z4` and `zEta`, using existing pure-sector bounds and exact low-dimensional witnesses/inequalities. A negative witness can stop work on this point cheaply. Do not repeat broad numerical optimization. |
| Resolve a foundational physical assumption | Separate decisions remain necessary for PQ global identification, numerical matter inputs and any claimed naturalness mechanism. No new representation or protective symmetry should be invented to rescue the benchmark. A bounded Higgs matching feasibility assessment is more directly physical than more isolated source identities. |
| Pause/reject this benchmark | Keep it provisional; present evidence does not justify global acceptance or rejection. Reject only the stated approximation/old failed point where evidence does. Do not replace it automatically because finite thresholds are missing. |

The resource/authority boundary is unchanged: no new large search, two-loop
boundary, full quantum compiler stage, flavor fit or source activation is
authorized by this review. A further test must freeze its actual scope and
stopping rules. E5/A5 is unqualified; HB1/C5 blocked; `C1_GS` uncalculated;
the quartet normalization failure, flavor pause and custody exit2/seven
unresolved references remain. Formal authority stays34/39.

Track A gains physically relevant exclusion criteria and a restricted-sector
certificate. Track B demonstrates bounded error detection/diagnostics while
recording shared-action/helper/SymPy/analyst risks and the preserved launch-path
mistake. A fresh run is not a second scientist. Education stays concurrent,
voluntary and nonblocking; consequential acceptance remains the director's.
No outreach, publication, remote push, branch/worktree or benchmark edit.

## Execution and validation

`preparation_2.json` expands the unexecuted preparation1's local Python
dependency bindings before any evaluation. The source is frozen in both
snapshots. The first runner command used a nonexistent placeholder path;
`unlaunched_path_failure.json` preserves it as no worker/no coefficients,
excluded from qualification. The corrected path comes from the exact execution
plan. Complete captures preserve the original and fresh runs, including
prelaunch commit observation, nonzero2second memory samples and the8GiB cap.
The original peaked near2.36GiB because inherited representative construction
has overhead despite evaluating only one4x4 block; no full Hessian or old loop
replay was run. This is an engineering cost, not independent physics evidence.

The final receipt must verify identical RESULT bytes; all144 frozen input
hashes, source snapshots and state; no worker writes; negative controls;
the existing read-only research checks; exact final file bindings and local
Git byte checks. It records omitted global searches, full scalar/quantum
replays, uncomputed thresholds and empirical tests explicitly. The old
successful/failed evidence is reused within its scope, not presented as newly
independent reproduction. No adoption of this report validates the theory or
demonstrates reliable independent AI physics discovery.
