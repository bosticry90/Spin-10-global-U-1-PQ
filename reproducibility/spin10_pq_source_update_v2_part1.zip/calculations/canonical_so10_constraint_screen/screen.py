"""Small read-only screens; no scan, threshold fit, or scientific promotion."""
import json, math, sys
from hashlib import sha256
from pathlib import Path
import numpy as np
import sympy as s

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
CALC=HERE.parent


def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()


def scalar_sector():
    """All Phi/phi/S directions, with Sigma=0; sufficient quartic certificate."""
    base=read(CALC/'canonical_so10_scalar_benchmark/STAGE1_POINT.json')['free_coefficients']
    point=read(CALC/'canonical_so10_positive_higgs/POINT.json')
    c={n:s.Rational(z) for n,z in base.items() if ':' not in n}
    for n in ['z4','zK','zEta','zD']:
        c[n]=s.Rational(base[n+':re'])+s.I*s.Rational(base[n+':im'])
    for n,z in point['changed_free_coefficients'].items():
        if ':' not in n:c[n]=s.Rational(z)
        elif n.endswith(':re'):c[n[:-3]]=s.Rational(z)+s.I*s.im(c.get(n[:-3],0))
    assert c['lambdaPhiS']==0 and c['lambdaPhi2']>0 and c['lambdaPhiVector2']>=0
    a=c['lambdaPhi1']+c['lambdaPhi2']/10
    m=c['lambdaPhiphi1'];ell=c['lambdaPhiphi2'];z2=s.expand(c['zK']*s.conjugate(c['zK']))
    assert a>0 and ell>0
    b=c['lambdaPhiVector1']-m*m/(4*a)
    d=c['lambdaVectorS']-z2/ell;e=c['lambdaS'];det=s.factor(b*e-d*d/4)
    assert b>0 and e>0 and det>0,'SCREEN_SUFFICIENT_CERTIFICATE_NOT_ESTABLISHED_NO_GLOBAL_FAIL_INFERENCE'
    # p=tr(Phi^2), y=||phi||, r=||Phi phi||, t=|S|.
    p,y,r,t=s.symbols('p y r t',real=True);z=s.sqrt(z2)
    lower=a*p*p+m*p*y*y+ell*r*r+c['lambdaPhiVector1']*y**4+c['lambdaVectorS']*y*y*t*t+e*t**4-2*z*y*r*t
    squares=a*(p+m*y*y/(2*a))**2+ell*(r-z*y*t/ell)**2+b*y**4+d*y*y*t*t+e*t**4
    assert s.expand(lower-squares)==0
    sys.path.insert(0,str(CALC/'canonical_so10_full_hessian'))
    from parent_bilinear_oracle import State,invariant_values,REAL_NAMES
    def value(st,coef=c):
        inv=invariant_values(st)
        return s.simplify(sum(coef[n]*inv[n] for n in REAL_NAMES[6:])+sum(2*s.re(coef[n]*inv[n]) for n in ['z4','zK','zEta','zD']))
    def explicit(st):
        P,x,S=st.Phi,s.Matrix(st.phi),st.S
        p2=s.trace(P*P);u=(s.conjugate(x).T*x)[0];v=(x.T*x)[0]
        return s.expand(c['lambdaPhi1']*p2**2+c['lambdaPhi2']*s.trace(P**4)+m*p2*u+ell*(s.conjugate(x).T*P**2*x)[0]
            +c['lambdaPhiVector1']*u**2+c['lambdaPhiVector2']*v*s.conjugate(v)+c['lambdaVectorS']*u*S*s.conjugate(S)
            +e*(S*s.conjugate(S))**2+2*s.re(c['zK']*(x.T*P*x)[0]*s.conjugate(S)))
    Z=s.zeros(10);D=s.diag(1,-1,*([0]*8));off=s.zeros(10);off[0,1]=off[1,0]=s.Rational(1,2)
    vectors=[(1,)+(0,)*9,(1,s.I)+(0,)*8,(0,1,-2*s.I)+(0,)*7]
    samples=[State(D,{},vectors[0],-1),State(s.diag(*([1]*5+[-1]*5)),{},vectors[1],1+s.I),
        State(off,{},vectors[2],-2*s.I),State(s.diag(*([-2]*6+[3]*4)),{},vectors[1],2+3*s.I),
        State(Z,{},vectors[1],1),State(D,{},(0,)*10,2)]
    checks=[]
    for st in samples:
        q=value(st);assert s.simplify(q-explicit(st))==0
        P,x,S=st.Phi,s.Matrix(st.phi),st.S;p2=s.trace(P**2);u=(s.conjugate(x).T*x)[0]
        rr=s.sqrt((s.conjugate(x).T*P**2*x)[0]);tt=s.sqrt(S*s.conjugate(S))
        low=s.simplify(lower.subs({p:p2,y:s.sqrt(u),r:rr,t:tt}))
        assert s.N(q-low,50)>=0 and q>0
        checks.append({'quartic':str(q),'lower_bound':str(low)})
    bad=dict(c,lambdaS=-1);pureS=State(Z,{},(0,)*10,1)
    assert value(pureS,bad)==-1 and value(pureS)==1
    omitted=explicit(samples[0])-2*s.re(c['zK']*(s.Matrix(samples[0].phi).T*D*s.Matrix(samples[0].phi))[0]*s.conjugate(samples[0].S))
    assert s.simplify(value(samples[0])-omitted)!=0
    return {'scope':'ALL_Phi_phi_S_QUARTIC_DIRECTIONS_WITH_SIGMA_ZERO_ONLY','sufficient_bound_pass':True,
        'a':str(a),'b':str(b),'d':str(d),'e':str(e),'determinant':str(det),
        'decimal_b_d_determinant':[str(s.N(z,20)) for z in [b,d,det]],'parent_oracle_samples':checks,
        'negative_singlet_and_omitted_hc_controls_detected':True,'full_BFB_certified':False}


def higgs_sensitivity():
    sys.path.insert(0,str(CALC/'canonical_so10_positive_higgs'))
    from verify_exact_point import tuning,parent_coefficients,direct_block,mp,mpval
    from evaluate_sm_hessian_blocks import block,rational_representatives
    mp.mp.dps=80;_,root=tuning();coef,B,S=parent_coefficients(s.Rational(mp.nstr(root,72)))
    label=(0,0,1,-3);eig,U,metric=direct_block(label,coef,B,S);assert abs(eig[0])<mp.mpf('1e-55')
    unit={n:s.Integer(0) for n in coef};unit['mphi2']=s.Integer(60)
    raw=block(label,unit);n=raw.rows
    D=mp.matrix(n)
    sectors=[item[0] for item in rational_representatives()[label]]
    for i in range(n):
        for j in range(n):
            D[i,j]=mpval(raw[i,j])/mp.sqrt(metric[i]*metric[j])
            expected=60 if i==j and sectors[i] in ['phi','phiBar'] else 0
            assert abs(D[i,j]-expected)<mp.mpf('1e-55'),'SCREEN_UNIT_MASS_PROJECTOR_NORMALIZATION'
    unit2={name:s.Integer(0) for name in coef};unit2['lambdaPhiphi1']=s.Integer(1)
    assert block(label,unit2)==raw,'SCREEN_CORRELATED_MASS_PORTAL_SHIFT_NOT_FLAT'
    v=U[:,0];slope=mp.re((v.H*D*v)[0])/60
    fraction=sum(abs(v[i])**2 for i,z in enumerate(sectors) if z in ['phi','phiBar'])
    assert abs(slope-fraction)<mp.mpf('1e-55') and slope>mp.mpf('0.9')
    H=mp.matrix(n)
    hraw=block(label,coef)
    for i in range(n):
        for j in range(n):H[i,j]=mpval(hraw[i,j])/mp.sqrt(metric[i]*metric[j])
    controls=[]
    for text in ['1e-6','1e-8']:
        delta=mp.mpf(text)
        pos=mp.eighe(H+delta*D,eigvals_only=True)[0]/60
        neg=mp.eighe(H-delta*D,eigvals_only=True)[0]/60
        finite=(pos-neg)/(2*delta)
        assert pos>0 and neg<0 and abs(finite-slope)<mp.mpf('1e-7')
        controls.append({'delta_p':text,'positive_m2_over_omega2':mp.nstr(pos,24),'negative_m2_over_omega2':mp.nstr(neg,24),'centered_derivative':mp.nstr(finite,24)})
    # A separate numpy Hermitian eigenproblem checks numerical representation.
    nf=np.array([[complex(H[i,j]) for j in range(n)] for i in range(n)])
    nd=np.array([[complex(D[i,j]) for j in range(n)] for i in range(n)])
    de=1e-6;numerical=(np.linalg.eigvalsh(nf+de*nd)[0]-np.linalg.eigvalsh(nf-de*nd)[0])/(120*de)
    assert abs(numerical-float(slope))<1e-7
    return {'parameter':'p=mphi2/omega^2 with all other frozen coefficients fixed','light_block_complex_dimension':n,
        'slope_d_mlight2_over_omega2_d_p':mp.nstr(slope,30),'numpy_centered_derivative':float(numerical),
        'light_10_fraction':mp.nstr(fraction,30),'perturbations':controls,'correlated_delta_portal_plus_delta_p_minus_exactly_flat_in_doublet_block':True,
        'technical_naturalness_proved':False,'radiative_stability_proved':False,'logarithmic_sensitivity_at_exact_zero':'UNDEFINED',
        'conditional_precision_relation':'abs(delta_p) <= m_star^2/(slope*omega^2); neither physical omega nor EW mass matched'}


def gauge_geometry():
    q=read(CALC/'canonical_so10_direct_gauge_next_order/next_order.json')
    old=read(CALC/'canonical_so10_direct_two_loop_heavy_threshold/two_loop_boundary.json')
    central=q['central_refit'];g=central['g10'];alpha=g*g/(4*math.pi);k=alpha/math.pi**2
    r=np.array(central['residual_inverse_couplings']);C0=np.array(old['part_A_gauge_scalar']['one_loop_C0_at_mu_eq_omega'])
    P=np.eye(3)-np.ones((3,3))/3;T=np.array([[1.,-1.,0.],[0.,1.,-1.]])
    assert np.linalg.norm(P@P-P)<1e-14 and np.linalg.norm(P@np.ones(3))<1e-14
    assert np.linalg.norm(T@(r+3.25*np.ones(3))-T@r)<1e-14
    eq=P@r/k;raw=P@(C0*C0+r/k)
    assert np.max(abs(eq-np.array(old['finite_threshold_demand']['C1_equivalent_centered_required'])))<1e-9
    assert np.linalg.norm(T@(r+k*(C0*C0-(C0*C0+r/k))))<1e-12
    # Wrong sign and omitted inverse-expansion square must not pass this diagnostic.
    assert np.linalg.norm(T@(r+k*(C0*C0-(C0*C0-r/k))))>1
    assert np.linalg.norm(P@(r+k*(C0*C0-r/k)))>1e-5
    x,c0,c1=s.symbols('x c0 c1')
    assert s.expand((1-x*c0+x*x*c1)*(1+x*c0+x*x*(c0*c0-c1))).coeff(x,2)==0
    assert s.series(1/(1-x*c0+x*x*c1),x,0,3).removeO()==1+x*c0+x*x*(c0*c0-c1)
    from numpy.linalg import norm
    state=np.array(q['rge']['central_scale_state_g1_g2_g3_yt_yb_ytau_lambda'])
    a=state[:3]**2/(4*math.pi);yt,yb,ytau=state[3:6]
    B=np.array([[199/50,27/10,44/5],[9/10,35/6,12],[11/10,9/2,-26.]])
    betaA=-np.array([41/10,-19/6,-7.])/(2*math.pi)-B@a/(8*math.pi**2)+(np.array([17/10,3/2,2.])*yt*yt+np.array([1/2,3/2,2.])*yb*yb+np.array([3/2,1/2,0.])*ytau*ytau)/(32*math.pi**3)
    Jg=-8*math.pi/g**2*np.ones(3)+21*np.array([8.,6.,5.])/(12*math.pi)
    Jw=-betaA;n=np.cross(Jg,Jw);n=n/norm(n)
    if n@r<0:n=-n
    tangential=r-n*(n@r);assert norm(tangential)<1e-6,'SCREEN_FROZEN_LEAST_SQUARES_NOT_STATIONARY'
    assert abs(n@Jg)<1e-12 and abs(n@Jw)<1e-12
    # Independent difference-space construction of common/scale quotient.
    common_normal=np.cross(np.ones(3),Jw);common_normal/=norm(common_normal)
    if common_normal@r<0:common_normal=-common_normal
    lam_tree=0.104858242929587;lam_sm=float(state[6])
    return {'scheme':'MSbar, g1=sqrt(5/3)*gY, background-field Feynman matching, kappa=mu/omega=1',
        'residual_definition':'R_i=A_U-lambda_i/(12*pi)-A_i_SM(mu)',
        'central_g10_diagnostic':g,'central_omega_diagnostic_GeV':central['omega_GeV'],'residual':r.tolist(),
        'nonuniversal_differences_T_r':(T@r).tolist(),'centered_r':(P@r).tolist(),'alpha_over_pi2':k,'C0':C0.tolist(),
        'old_centered_C1_equivalent':eq.tolist(),'fixed_point_centered_raw_zeta_C1_required':raw.tolist(),
        'known_square_centered':(P@(C0*C0)).tolist(),
        'fixed_point_relation':'T C1_raw = T(C0^2+R/k); C1_equiv=C1_raw-C0^2; k=alpha_U/pi^2',
        'full_relation_before_refit':'R(p)+k(p)*(C0(p)^2-C1_total(p))=0 through this order; C1_total must be action-derived',
        'jacobian_log_g':Jg.tolist(),'jacobian_log_omega':Jw.tolist(),'local_refit_unit_normal':n.tolist(),
        'local_refit_normal_residual':float(n@r),'tangential_residual_norm':float(norm(tangential)),
        'common_scale_quotient_normal':common_normal.tolist(),'common_scale_projected_residual':float(common_normal@r),
        'refit_done':False,'unknown_coefficients_fitted':False,'rigorous_threshold_bound':None,
        'lambda_tree_rounded_inherited':lam_tree,'lambda_SM_monitor_at_diagnostic_scale':lam_sm,'quartic_boundary_diagnostic_gap':lam_tree-lam_sm,
        'Higgs_quartic_matching_performed':False,'wrong_sign_and_missing_square_controls_detected':True,
        'parent_two_loop_over_one_loop_diagnostic':old['part_A_gauge_scalar']['parent_two_loop_over_one_loop_at_diagnostic_g10']}


def main():
    assert __debug__
    prep=read(HERE/sys.argv[1])
    assert digest(ROOT/'project_state.json')==prep['state_sha256']
    for name,h in prep['input_sha256'].items():assert digest(ROOT/name)==h,name
    assert digest(Path(__file__))==prep['source_sha256']
    writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('CONSTRAINT_SCREEN_WRITE_DENIED')
    sys.addaudithook(readonly)
    print('STAGE exact_three_field_quartic_certificate',flush=True);bfb=scalar_sector()
    print('STAGE small_Higgs_mass_sensitivity',flush=True);higgs=higgs_sensitivity()
    print('STAGE nonuniversal_threshold_geometry',flush=True);gauge=gauge_geometry()
    assert not writes and digest(ROOT/'project_state.json')==prep['state_sha256']
    for name,h in prep['input_sha256'].items():assert digest(ROOT/name)==h,name
    print('RESULT '+json.dumps({'schema':'CANONICAL_SO10_BOUNDED_CONSTRAINT_SCREEN_V1','authority':'DIAGNOSTICS_AND_RESTRICTED_TREE_SECTOR_ONLY',
        'source_sha256':prep['source_sha256'],'input_sha256':prep['input_sha256'],'scalar_sector':bfb,'Higgs_sensitivity':higgs,'gauge_geometry':gauge,
        'write_attempts':writes,'scientific_authority_changed':False,'full_model_viability':False,'full_E5':False,'whole_goal_complete':False},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
