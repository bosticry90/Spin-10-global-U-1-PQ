# Continuous mixed-field slice: exact necessary quartic condition V1

Previous goal turn:PROGRESS,c5e3405 excluded every s->0+ route under the
existing local-mass/contact/fixed-input assumptions. Recover current Git,
live processes and the read-only preflight. The wider eight-quartic domain
is unresolved;repeating discrete rays cannot certify all mixed directions.

Question:what is the EXACT nonnegative-quartic condition on the continuous
real-amplitude slicePhi=S=0,Sigma=a*vacuum_form()+b*doublet_form(6),
phi6=-c,phi7=-ic,other vector components zero,wherea,b,c are ANY real values?
The amplitudes are test fields,not model parameters or new benchmark choices.
Use the actual unchanged parent action,+i selfdual convention,normalization,
fixed nonfamily couplings includingeta=3/10,zD=0,and already authorized
eight-quartic coordinatesx,s,z,D. Requirex>0 as the local-mass theorem does.

Derive all29 parent monomial POLYNOMIALS and all10 eta components directly,
retaining zeros. Do not infer polynomial completeness from sampled fields.
Check that sign choices reduce the worst real amplitudes tob,c>=0 and that
b=0 has positive quartic for nonzeroa,c. Forb>0,usey=a^2/b^2>=0,r=c/b>=0.
Complete the positive y square;derive the exact branch-conditioned quartic
criterion for EVERYr,including boundaries and zeros. Nonnegative quartic
on this slice is necessary,not sufficient,for full tree BFB. A flat quartic
does not establish full-potential boundedness when lower-degree terms remain.

Exploit the positive linear D coefficient to derive its exact required
lower-envelope function over r. Show how its maximum reduces to endpoints,
quadratic branch boundaries and two cubic stationary equations. Prove the
large-r tail cannot host the maximum. Return the explicit polynomial/root
criteria;do not run a numerical parameter optimizer or choose a surviving
point. If a structural identity fails,preserve it and stop qualification.

Independent route:K-first/target-joined symbolic Sigma contractions,
Pauli/Kronecker cubic source with the inherited faithful map andf=-4E,
interior-form K/T,and separately verified symbolic square/derivative identities.
Reuse rather than rerun the full mass/contact,6120-intertwiner or8001 proofs.
Check both previous actual-ray specializations from authenticated evidence,
not as new fresh replay pairs. References/negative controls must distinguish
nonnegative from strict positivity,conditional from unconditional quartic
discriminants,branch sign,missing endpoint and wrong conjugation/homogeneity.
Abstract positive/negative/tangent polynomial controls are not model points.

Two sequential native roles,each120seconds after imports,8GiB sampled private
allocation and350MiB directly observed available commit. Freeze source/input
bytes before calculation,verifier/report before validation. Preserve failed
or incomplete runs;no automatic retries. Require separate receipt,current
read-only preflight and raw staged/HEAD/worktree byte checks before local commit.

Scope ceiling:exact continuum-slice criterion and structural feasibility input,
not a whole328 certificate,full-domain no-go/survivor,full scattering,quantum
result or physical prediction. No new model family,point,parameter search,
coupling fit,physical input,loop,flavor resume or blocked-stage activation.
Director authority on consequential choices/acceptance remains separate.
Science and AI capability equally important;education voluntary/nonblocking.
Preserveproject_state.json,sealed README,34/39,custody exit2/seven references,
all earlier results/failures,quartetFAIL,E5/A5unqualified,HB1/C5block,C1_GSgap
and flavor pause. Shared action,normalizations,software,proofs and analyst
limit independence. No outside endorsement,outreach,publication or remote push.
