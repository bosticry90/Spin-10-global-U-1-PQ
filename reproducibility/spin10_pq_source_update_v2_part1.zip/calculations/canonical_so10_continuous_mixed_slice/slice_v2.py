"""Exact symbolic continuous real-amplitude mixed quartic; no model search."""
from pathlib import Path
from hashlib import sha256
import json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_full_hessian'));from parent_bilinear_oracle import State,invariant_values,REAL_NAMES
sys.path.insert(0,str(C/'canonical_so10_scalar_reconstruction'));from verify_eta1_doublet_mixing import vacuum_form,doublet_form,hodge_eigencheck
from certify_sigma_quartics import add_forms
from test_eta1_invariant import contraction_vector_on_a,conjugate
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation_v2.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('CONTINUOUS_MIXED_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 a,b,c=S.symbols('a b c',real=True);x,s,z,D=S.symbols('x s z D',positive=True);r,y=S.symbols('r y',nonnegative=True)
 v=vacuum_form();w=doublet_form(6);form=add_forms({I:(a*p,a*q) for I,(p,q) in v.items()},{I:(b*p,b*q) for I,(p,q) in w.items()});hodge_eigencheck(form)
 phi=(0,)*6+(-c,-S.I*c,0,0)
 nodes=[(i,j,4-i-j) for i in range(5) for j in range(5-i)]
 monomials=[a**i*b**j*c**(4-i-j) for i in range(5) for j in range(5-i)]
 T=S.Matrix([[m.subs(dict(zip([a,b,c],node)),simultaneous=True) for m in monomials] for node in nodes]);det=T.det();assert len(nodes)==15 and det!=0
 values=[];names=list(inputs.NAMES)
 for idx,node in enumerate(nodes):
  mapping=dict(zip([a,b,c],node));fn={I:tuple(S.expand(q.subs(mapping)) for q in pair) for I,pair in form.items()};fn={I:pair for I,pair in fn.items() if pair!=(0,0)}
  pv=tuple(S.expand(q.subs(mapping)) if hasattr(q,'subs') else q for q in phi);vv=invariant_values(State(S.zeros(10),fn,pv,0));values.append([S.expand(vv[n]) for n in names]);print('STAGE exact_homogeneous_node_'+str(idx),flush=True)
 coefficients=T.inv()*S.Matrix(values);inv={}
 for j,n in enumerate(names):
  H=S.expand(sum(m*coefficients[i,j] for i,m in enumerate(monomials)));d=inputs.TOTAL[n];pol=S.cancel(4**(4-d)*H/(a+b+c)**(4-d));assert S.Poly(pol,a,b,c).is_multivariate and all(sum(p)==d for p,v in S.Poly(pol,a,b,c).terms() if v!=0)
  inv[n]=S.expand(pol);assert S.expand(H-inv[n]*(a+b+c)**(4-d)/4**(4-d))==0
 assert len(inv)==29 and T*coefficients==S.Matrix(values)

 eta=[tuple(map(S.expand,contraction_vector_on_a(form,form,conjugate(form),i))) for i in range(10)]
 assert S.expand(sum((p+S.I*q)*u for (p,q),u in zip(eta,phi))-inv['zEta'])==0
 print('STAGE complete_symbolic_parent29_and_eta10',flush=True)
 raw=inputs.coefficients(0);bb=S.sqrt(S.Rational(3,160));ss=S.sqrt(S.Rational(3,10));co={n:S.simplify(q/bb**inputs.RESCALE.get(n,(0,0))[0]/ss**inputs.RESCALE.get(n,(0,0))[1]) for n,q in raw.items()}
 sig=[x/8,(5*s+z)/2-5*D/24,(-3*s-z)/2+5*D/24,(z-s)/4];co.update({'lambdaSigma'+str(i+1):q for i,q in enumerate(sig)})
 q=S.expand(sum(co[n]*inv[n] for n in REAL_NAMES[6:])+sum(2*S.re(co[n]*inv[n]) for n in ['z4','zK','zEta','zD']))
 P=S.Poly(q,a,b,c);assert all(sum(p)==4 and p[0]%2==0 for p,v in P.terms())
 aq=S.Poly(q,a);assert aq.coeff_monomial(a**4)==128*x
 Ar=S.expand(aq.coeff_monomial(a*a).subs({b:1,c:r}));Br=S.expand(aq.coeff_monomial(1).subs({b:1,c:r}));Pr=S.expand(512*x*Br-Ar*Ar)
 F=128*x*y*y+Ar*y+Br;assert S.expand(F-(128*x*(y+Ar/(256*x))**2+Pr/(512*x)))==0
 assert S.expand(q.subs(c,-c)-q)==S.Rational(2304,5)*a*a*b*c+S.Rational(72,5)*b**3*c
 boundary=S.expand(q.subs(b,0));assert boundary==128*x*a**4+S.Rational(199571,1562500)*a*a*c*c+S.Rational(2,5)*c**4
 base=S.expand(Br-S.Rational(35,4)*D);G0=-base;G1=S.expand(-base+Ar*Ar/(512*x));C0=S.expand(S.diff(base,r));C1=S.expand(Ar*S.diff(Ar,r)-256*x*S.diff(base,r))
 assert S.Poly(Ar,r).degree()==2 and S.Poly(C0,r).degree()==3 and S.Poly(C1,r).degree()<=3
 assert S.diff(Br,D)==S.Rational(35,4) and S.expand(S.diff(G1,r)-C1/(256*x))==0
 assert S.Poly(G0,r).LC()==-S.Rational(2,5) and S.Poly(Ar,r).LC()>0
 # Recover earlier fixed actual witnesses without rerunning their workers.
 old=read(C/'canonical_so10_family_mixed_witness/primary_result.json');assert S.expand(q.subs({a:1,b:1,c:5})-(S.Rational(361,2)*x+933*s+33*z+S.Rational(35,4)*D-S.Rational(1878969771,2000000)))==0 and old['actual_negative_parent_field_witness']
 previous=read(C/'canonical_so10_soft_mixed_obstruction/primary_result.json');special=S.expand(q.subs({a:S.Rational(2,3),b:1,c:4}));assert S.expand(special-S.sympify(previous['ray_polynomial'],locals={'x':x,'s':s,'z':z,'D':D}))==0
 assert S.expand(q.subs({a:2*a,b:2*b,c:2*c},simultaneous=True)-16*q)==0
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 result={'schema':'CONTINUOUS_MIXED_SLICE_PRIMARY_V1','status':'EXACT_CONTINUUM_CRITERION_REQUIRES_INDEPENDENT_RECEIPT','base_commit':prep['base_commit'],'field_slice':'Phi=S=0;Sigma=a*vacuum+b*doublet6;phi6=-c,phi7=-ic;a,b,c real','coefficient_reconstruction_field_nodes':15,'degree4_polynomial_dimension':15,'unisolvent_determinant':str(det),'typed_degree_premise':dict(inputs.TOTAL),'all29_monomial_polynomials':{n:str(q) for n,q in inv.items()},'eta_components':[[str(p),str(q)] for p,q in eta],'quartic':str(q),'boundary_b_zero':str(boundary),'A_r':str(Ar),'B_r':str(Br),'P_r':str(Pr),'B_without_D':str(base),'G_inactive':str(G0),'G_active':str(G1),'stationary_inactive_cubic':str(C0),'stationary_active_cubic':str(C1),'candidate_count_upper':9,'criterion':'forall r>=0:B(r)>=0 if A(r)>=0;512*x*B(r)-A(r)^2>=0 if A(r)<0','D_required':'(4/35)*max_{r>=0}[-B_without_D(r)+min(A(r),0)^2/(512*x)]','x_positive_required':True,'new_parameter_search':False,'new_model_parameter_points':0,'new_benchmark_or_family_adopted':False,'full328_quartic_nonnegativity_proved':False,'whole_parameter_domain_solved':False,'scientific_authority_changed':False,'physical_viability_decided':False,'whole_goal_complete':False,'write_attempts':writes,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256']}
 timer.cancel();print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True)
if __name__=='__main__':main()
