# Exact coefficient reconstruction after inherited symbolic-type failure V2

The original primary FAILED before producing a mathematical result:the
inherited quartics helper compared unexpanded symbolic expressions by
structural equality. Its numerical exact-arithmetic contract was improperly
extended to symbolic amplitudes. Preserve its full source,preparation and
capture;do not edit the frozen helper or count that attempt as qualification.

Replace that call with exact homogeneous coefficient reconstruction using
the numerical oracle within its supported input type. This supplements the
original execution plan with ONE corrected primary and ONE independent
verifier,each120seconds/8GiB/direct350MiB prelaunch commit. No automatic retry.
The original failed attempt and both corrected roles must be accounted for.

Polynomial-space proof:the typed parent monomials have degree d=2,3 or4 in
the fields. On the declared linear REAL three-amplitude slice,their conjugates
are also linear,so each is a homogeneous polynomial of degree d. Homogeneous
quartics in3 variables have exactly15 monomials. Freeze all15 nonnegative
integer triples(a,b,c)witha+b+c=4. Evaluate the unchanged literal oracle at
each triple,construct the exact15x15 monomial evaluation matrix and require
nonzero determinant. This is an unisolvent coefficient map,not empirical
sampling as proof of an arbitrary function's global behavior.

For d<4,the unique homogeneous4 reconstruction equals
F_d(a,b,c)*(a+b+c)^(4-d)/4^(4-d). Divide by that known factor exactly and
require a polynomial with degree d. Check the15 evaluations and the complete
coefficient identities. Zero polynomials remain zero. The parent action's
degree/type premise is essential;rank or interpolation alone cannot prove it.
The frozen action,typed inputs.TOTAL map and independent direct SYMBOLIC
tensor contractions anchor that premise and every resulting coefficient.

The corrected primary still derives all29 polynomials,all10 eta components,
the same continuous slice,exact square/branch and D-envelope identities.
No coefficient,tolerance,field ratio,model parameter or acceptance standard
is altered. Independent symbolic K-first/target-joined and Clifford/Gram
routes must match every coefficient. Preserve all original controls and
scope limits.15 oracle FIELD nodes are disclosed;zero model parameter
points,no parameter search,new family or benchmark are introduced.

This is a typed arithmetic repair. No foundational change,scientific-authority
promotion,publication or blocked-stage activation. Prior project state and
all scientific successes/failures remain unchanged. Science/AI evaluation
objectives equal;education voluntary/nonblocking. Qualification still needs
the actual complete receipt,current preflight and raw Git checks.
