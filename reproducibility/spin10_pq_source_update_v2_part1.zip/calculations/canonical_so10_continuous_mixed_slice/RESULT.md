# Exact continuous mixed-field slice criterion

The actual quartic on the three-real-amplitude slice
Phi=S=0,Sigma=a*vacuum_form()+b*doublet_form(6),phi6=-c,phi7=-ic
has been reconstructed exactly. Its nonnegativity for ALL reala,b,c reduces
to branch-conditioned quartic inequalities in one nonnegative field ratio.
The corresponding required D can be obtained from at most nine algebraic
candidates. This replaces discrete-ray tests on this declared slice.

This is necessary and sufficient for HOMOGENEOUS QUARTIC nonnegativity on
that slice,conditional onx>0. It is only a necessary test of full328 tree
BFB. It does not solve the remaining parameter domain or supply a surviving
benchmark. Whole-model viability remains **INCONCLUSIVE**;authority34/39
unchanged. Qualification requires the[record](RECORD.md),[typed repair](RECORD_V2.md),
actual[receipt](validation_receipt.json) and exact Git checks.

In plain language:we now know the complete mathematical test for every
mixture of these selected fields,not just a few chosen directions. The next
problem is whether the remaining model parameters can pass it together with
the other requirements. Passing this slice could still miss instabilities
elsewhere or quantum failures.

## Exact parent polynomials and typed reconstruction

Use the unchanged[parent action](../canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md),
fixed nonfamily couplings includingzEta=3/10,zD=0,and existing coordinates
x=8lambdaSigma1,s=lambdaSigma2+lambdaSigma3,z=s+4lambdaSigma4,
D=12(4s-(lambdaSigma2-lambdaSigma3)+z)/5. No finite model point,family,
coupling value,VEV or matching convention is selected or changed.

All29 monomial polynomials and10 eta-component polynomials are retained in
[the corrected primary output](primary_v2_result.json). In particular,

```
N=32a^2+6b^2,phi^dagger phi=2c^2,phi.phi=0,
Q0=1024a^4+384a^2b^2+36b^4,
Q1=960a^2b^2+90b^4,Q2=960a^2b^2+132b^4,X131=216b^4,
phi^dagger K phi=T_ij phi_i phi_j=6b^2c^2,
E6=192a^2b+12b^3,E7=-192ia^2b,other8 E components zero.
```

The resulting COMPLETE parent quartic is

```
V4=128x*a^4+a^2*((48x+960s)b^2+h*c^2-e*b*c)
   +(9x/2-27s+33z+35D/4)b^4+k*b^2*c^2-f*b^3*c+g*c^4,
h=199571/1562500,e=1152/5,
k=-9356043/50000000,f=36/5,g=2/5.
```

The original primary failed inside a frozen numerical helper on a symbolic
structural-equality assertion;it produced no mathematical result. That
source,capture and preparation remain FAILED and immutable. No frozen
helper was edited. The correction uses15 exact numerical FIELD triples
a+b+c=4,with the15-dimensional homogeneous quartic evaluation determinant
52529986053649465344. The typed degree2/3/4 premise follows from the actual
action and linear real slice;conjugation preserves real-polynomial degree.
Degree-lower monomials are homogenized and divided exactly,with no hole at
a+b+c=0 after polynomial cancellation. Membership plus unisolvence justifies
coefficient reconstruction;fifteen samples alone would not justify a global
statement about an arbitrary function.

The separate verifier contracts the tensors SYMBOLICALLY instead of
interpolating. It compares every coefficient of all29 polynomials and all10
eta components. Thus the reconstruction is independently checked against
the action,including zeros,conjugation and actual normalization. The previous
two negative-ray formulas are recovered as specializations,not new replays.

## Complete square and real-sign boundaries

V4 is even ina and invariant under(b,c)->(-b,-c). Changing onlyc's sign
adds(2304/5)a^2bc+(72/5)b^3c,which is nonnegative forb,c>=0. Consequently
the lowest value among real sign choices hasb,c>=0. This does NOT cover
arbitrary complex relative amplitudes of the two Sigma shapes;those are
additional directions outside this declared slice.

Atb=0 the quartic is128x*a^4+h*a^2c^2+g*c^4,strictly positive for a
nonzero(a,c)whenx>0. Forb>0 sety=a^2/b^2>=0,r=c/b>=0. ThenV4/b^4 is

```
F(y,r)=128x*y^2+A(r)*y+B(r),
A(r)=h*r^2-e*r+48x+960s,
B(r)=g*r^4+k*r^2-f*r+9x/2-27s+33z+35D/4.
```

The exact minimum overy>=0 isB(r)ifA(r)>=0;otherwise it is
B(r)-A(r)^2/(512x),at y=-A(r)/(256x)>0. Therefore the required criterion is

```
for EVERY r>=0:
  B(r)>=0                         when A(r)>=0,
  P(r)=512x*B(r)-A(r)^2>=0          when A(r)<0.
```

The branch condition is essential. RequiringP>=0 whereA>=0 can falsely
reject a positive quartic. The boundaryA=0 has the same answer from both
formulas. Zeros are allowed for homogeneous nonnegativity;they do not prove
strict positivity or full-potential boundedness when lower-degree terms act
along a flat direction. The actual negative rays remain genuine failures.

## Exact required D and finite algebraic candidates

LetB0(r)=B(r)-35D/4. The slice is nonnegative exactly when

```
D >= D_required(x,s,z)
  =(4/35)*max_(r>=0) G(r),
G(r)=-B0(r)+min(A(r),0)^2/(512x).
```

G is continuous and its branches agree atA=0. Sinceh>0,A eventually is
positive,soG eventually equals-B0 and tends to minus infinity with leading
coefficient-g. A finite maximum exists. Its candidates are

1. r=0;
2. at most2 nonnegative roots ofA;
3. at most3 nonnegative roots ofB0',retainingA>=0;
4. at most3 nonnegative roots ofA*A'-256x*B0',retainingA<0.

Repeated/overlapping roots count once. The active cubic may lose its leading
coefficient at specialx,but its r^2 coefficient-3he is nonzero,so it cannot
vanish identically. There are at most9 candidates before deduplication.
Exact root isolation/sign comparison can use the existing univariate tools;
no model-parameter optimization is needed to define or evaluate this test
once admissible algebraic inputs are supplied. No such new inputs are chosen
in this checkpoint. Equality remains a possible nonnegative/flat boundary.

In the existing comparison,this D requirement must coexist with the contact
upperD<=(16pi-3x+24(s-z))/5 and all mass/Higgs conditions. This is an explicit
new structural feasibility input,not a proof that the residual domain is
empty or nonempty.

## Safe lifts,decision and remaining scope

At fixedD,s,z,the new condition improves whenx increases because
partialV4/partialx=Q0/8>=0. It therefore does not invalidate the existing
[x contact-maximum lift](../canonical_so10_higgs_profile/RESULT_V3.md) used in
the selected mass/Higgs reduction. The new
slice is independent ofPhi quartics,Delta andt;their existing scientific
obligations remain. This does not makeDelta irrelevant to full mixed BFB.

Do not combine independent maximum lifts without respecting coupled contact
constraints. Although increasingD at fixedx improves this slice too,on the
diagonal contact ridgeD=(16pi-3x+24(s-z))/5,its pureb^4 coefficient decreases
withx at rate-3/4. Thus an unsupported simultaneous-max shortcut can fail.
No claim that the contact-maximum D preserves every Higgs/global condition
is made here.

Next apply this continuous condition with the already derivedx lift and the
remaining mass/Higgs/contact equations,away from the excluded s->0 region.
The explicit missing question is joint feasibility of that residual domain.
Do not resume numerical parameter searches,choose another family,fit eta,
or expand quantum matching merely because the slice test is now defined.
Consequential scope/input changes remain director-controlled.

## Verification and AI-capability limitations

The exact coefficient route and independent K-first/target-joined,Clifford
and interior-Gram routes check all29 polynomials,all10 eta components,the
degree/rank premise,square identities,branch signs,b=0,homogeneity and both
stationary equations. Abstract positive,negative,tangent and interior-maximum
controls distinguish branch conditioning,nonnegativity,strictness and missing
endpoints. They are mathematical references,not actual model-parameter points.

One failed original primary,one completed corrected primary andone completed
independent verifier must be retained. Bounded roles use120seconds/8GiB and
direct350MiB prelaunch observations. Source/input/current preflight and raw
staged/HEAD bytes are checked. No fresh byte-identical replay pair,old mass
spectrum,6120-intertwiner proof or8001-pair calculation is rerun or claimed.

Track B gains a precise continuous necessary test and coefficient-space
reconstruction justified by action typing. The repeated extension of a
numerical helper to symbolic inputs without a type precheck is an engineering
failure;it remains recorded. The comparison shares the action,linear real
slice,normalizations,inherited map/mass/contact premises,some arithmetic,
Python/SymPy and analyst. It is bounded corroboration,no expert endorsement,
experimental support or proof of autonomous scientific reliability. Education
is voluntary/nonblocking and both research objectives remain equal.

Preserveproject_state.json,sealed README,authority34/39,custody exit2/seven,
all prior scientific results/failures,quartetFAIL,E5/A5unqualified,HB1/C5block,
C1_GSgap and flavor pause. No benchmark,new family,physical input,publication,
outreach,remote push or scientific-authority promotion. Whole investigation
remains active and incomplete.
