# Corrective exact polynomial verifier V2

The original primary completed; the first independent verifier FAILED at
sample3 on a structural SymPy equality for the complex Frobenius norm. Its
complete source, prospective preparation, launch/capture and failure remain
immutable. That run does not qualify the result. The frozen full328 sufficient
matrix already fails; no physical negative witness has been obtained.

Diagnosed engineering issue: (1-I)*(1+I)==2 is false under SymPy structural
equality, while exact polynomial expansion equals2. The complete basis
isometry already checked by both algorithms entails the norm identity; this
does not justify skipping its direct complex-field control.

Purposefully correct the verifier in a new version. Expand exact Gaussian
polynomials after matrix multiplication and before trace equality. Preserve
all comparisons,140 components,6120 intertwinings,negative controls,inputs,
fixed certificate and authority ceiling. No tolerance or fit is introduced.
This is a source-corrected bounded repair, not an automatic rerun of unchanged
code and not a new physical search. The original two-role plan is exhausted;
this explicit supplemental plan adds ONE120-second/8GiB verification role
with directly observed350MiB prelaunch commit. No automatic further retries.

Acceptance requires the complete corrected check, preserved failed run,
source/preparation bindings,resource compliance,current read-only preflight
and exact raw Git bytes. The mathematical verdict remains the one computed,
including a failed sufficient certificate if independently reproduced.
Publication,benchmark adoption,foundational changes and scientific-authority
promotion remain director-controlled; none is proposed by this repair.
