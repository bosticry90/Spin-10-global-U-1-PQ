# An exact global eta bound; the fixed full-stability certificate fails

The faithful Clifford-matrix encoding of the existing self-dual Sigma tensor
gives the global inequality `|E|^2 <= 128*N^3`, with N=sum_sorted_I |Sigma_I|^2
and E the eta source defined by the unchanged parent action. The fixed
full328 sufficient-condition matrix fails positivity. This is a failure of
that lower-bound method, **not an unstable parent-field witness**. Full
stability and physical viability remain **INCONCLUSIVE**; authority34/39 is
unchanged. Qualification requires the [receipt](validation_receipt.json),
[prospective record](RECORD.md) and raw Git checks.

In plain language: the tensor can be encoded exactly as a smaller matrix,
but the general matrix norm estimate discards too much information to settle
stability. We have not shown that the actual potential becomes negative.
The [previous global pure-Sigma and308-sector certificates](../canonical_so10_sigma_norm_bound/RESULT.md)
remain valid. No physical coefficient, analytic family, proof weight or
neighborhood was changed after seeing this failure.

## Structure-preserving encoding and global bound

The published symmetric10/126 spinor-coupling construction is established
representation machinery; see [Bajc and Smirnov](https://arxiv.org/abs/1605.07955).
No fermion fields, Yukawa model, flavor input or new physical assumption is
introduced here. Chiral matrices encode the existing tensor only. All action
normalizations are derived here, rather than imported from that literature.

Use Hermitian Euclidean32-dimensional Gamma matrices from five Pauli factors,
C=Gamma1 Gamma3 Gamma5 Gamma7 Gamma9 (zero-based indices), and restrict
M(Sigma)=sum_sorted_I Sigma_I C Gamma_I to the even chiral16-dimensional block.
The other block vanishes on every element of the complete126-complex basis
with the frozen +i Hodge convention. The126 images are symmetric, mutually
orthogonal and orthogonal to the10 vector matrices G_i=C Gamma_i. Their norms
give `||M||_F^2=32N` and `<G_i,G_j>=16delta_ij`;126+10 exhaust Sym^2(16).

All45 Lie generators are checked on all126+10 basis elements:6120 exact
intertwinings, using the actual tensor rotation and unitary spinor congruence.
These complete-basis linear identities establish covariance on the entire
representation. Dimension and rank alone would not establish it.

Define `B=M M^dagger M` and `f_i=Tr(G_i^dagger B)/16`. Unitary congruence makes
B and its orthogonal10 projection covariant. f has bidegree(2,1) in Sigma
and Sigma*. The [qualified unique eta invariant](../canonical_so10_scalar_reconstruction/RESULT_V2.md)
therefore implies f=alpha E globally. This step depends on the inherited
complete multiplicity theorem, not finite sample fitting. The fixed
WITNESS_F component E0=-48 gives alpha=-4. All140 components of14 inherited
exact E vectors, including zero entries, match this normalization.

Orthogonal projection and nonnegative singular values d_j then give

```
16 sum_i |f_i|^2 = ||P_10 B||_F^2 <= ||B||_F^2
                 =sum_j d_j^6 <= (sum_j d_j^2)^3=(32N)^3,
f=-4E, hence |E|^2 <= 128N^3.
```

This is a sufficient global norm bound, not a claim that128 is optimal or
attainable on the allowed126 subspace. It is independent of the vanishing
small-u Q1 stiffness, unlike the earlier coarse R=4Q1-X131 bound. The action's
physical eta coefficient remains3/10. Canonical rescaling changes N and E
homogeneously and preserves this bound in their corresponding normalization.

## Fixed full-field test and what failed

Keep the existing analytic family and proof choices frozen before computation:
tau=1/5,0<u<1/1000,pi>157/50,t=lambdaPhiSigma2>111/6250. Young's inequality pays
the eta interaction with tau*N^2 plus the penalty eta^2*128*N*v/tau, where
v=phi^dagger phi. The lost mixed coefficient is57.6, while the actual frozen
Sigma/vector norm coefficient is -0.03318252. This bound is very conservative.

The remaining terms use already qualified pure-Sigma and correlated z4
inequalities, the exterior-form bound0<=K<=N I, and completion of the positive
lambdaPhiphi2 square to pay the zK interaction. Nonnegative quartics are
discarded only as lower bounds. No propagator, quantum scheme or light-field
prescription is needed for this homogeneous classical-potential test.

In the nonnegative norm variables(x=trPhi^2,N,v,s=|S|^2), the uniform rational
lower matrix is

```
[[1413/2000, 0, -1/1000, 0],
 [0, 77/400, -1440829563/50000000, -690273291761/7104000000000],
 [-1/1000, -1440829563/50000000, 1/10, -733836813399/32395700000000],
 [0, -690273291761/7104000000000, -733836813399/32395700000000, 1]].
```

Its first two leading minors are positive; the third and fourth are negative.
Even the lower polynomial at the abstract nonnegative norms(0,1,1,0) is
negative. Those norms and discarded Cauchy equality conditions do not supply
a negative physical field configuration. A negative lower bound does not
determine the sign of the actual potential. No upper bound/no-go theorem or
new benchmark rejection follows. No alternative tau or neighborhood was tried.

## Verification, scientific decision and limitations

One exact sparse Gaussian-integer monomial calculation is compared with a
separately assembled Pauli/Kronecker matrix derivation. It checks the full
Gram/isometry, all6120 generator identities, all140 cubic components, the
current physical coefficients and exact rational minors. Wrong chirality,
phase/dagger behavior, projection normalization and positive-diagonal but
negative-determinant controls test failure detection. The pi lower is checked
through rational alternating Machin bounds. K<=N I follows globally from the
creation/interior anticommutator on exterior forms, not finite field tests.

The two120-second native roles require directly observed prelaunch commit and
sampled8GiB resource compliance, immutable source/input checks, current
read-only preflight and exact staged/committed bytes. No fresh byte-identical
replay pair, old invariant recount, scalar spectrum, optimizer or loop is
claimed. The failed sufficient bound is a completed scientific outcome;
successful evidence validation must not be relabeled a full-stability PASS.

The next smallest scientific question is whether the eta projection has a
substantially sharper global bound on the constrained126 matrix subspace,
possibly correlated with the positive Q4 exchange norm. Generic singular-value
estimates ignore these constraints. Seek an exact identity or bounded
counterexample before another parameter search; do not repeat arbitrary rays
or adjust physical inputs to conceal this failed certificate. If no competent
cheap bound is available, state that uncertainty rather than launch a large
252-dimensional search. No such extra calculation is part of this checkpoint.

Track B shows a successful action-normalized representation change and honest
recognition that a correct theorem can be too weak for the scientific question.
It does not demonstrate autonomous physics reliability. The inherited eta
multiplicity, action/family conventions, Clifford representation formula, some
arithmetic, Python/SymPy and analyst remain shared dependencies. Distinct
implementations give bounded corroboration, not independent expert endorsement
or experimental support. Both research objectives remain equal; education is
concurrent, voluntary and nonblocking.

Preserveproject_state.json,sealed README,authority34/39,custody exit2/seven
unresolved references,the old benchmark perturbativity failure,earlier unstable
trials,quartetFAIL,E5/A5unqualified,HB1/C5blocked,C1_GSuncalculated and flavor
pause. Full scattering, full328 BFB, preferred vacuum, quantum control,
naturalness and physical Higgs/gauge matching remain unresolved. No finite u,
benchmark, foundational change, publication, remote action or authority
promotion is adopted. The overall research goal remains incomplete.
