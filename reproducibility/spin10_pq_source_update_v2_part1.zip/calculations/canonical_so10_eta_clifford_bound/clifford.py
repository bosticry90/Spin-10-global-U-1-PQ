"""Exact Clifford monomials, full intertwiner and cubic eta bound."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,permutations
import sys,json,time,threading,os
R=Path(__file__).resolve().parents[2];CROOT=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(CROOT/'canonical_so10_scalar_reconstruction'));import certify_sigma_quartics as qs
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(0,0);phases=[(1,0),(0,1),(-1,0),(0,-1)]
add=lambda a,b:(a[0]+b[0],a[1]+b[1]);neg=lambda a:(-a[0],-a[1]);conj=lambda a:(a[0],-a[1]);mul=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def putval(D,k,z):
 z=add(D.get(k,Z),z)
 if z!=Z:D[k]=z
 elif k in D:del D[k]
def plus(A,B):
 D=A.copy()
 for k,z in B.items():putval(D,k,z)
 return D
def scaled(A,z):return {k:mul(v,z) for k,v in A.items() if mul(v,z)!=Z}
def trans(A):return {(j,i):z for (i,j),z in A.items()}
def dag(A):return {(j,i):conj(z) for (i,j),z in A.items()}
def mm(A,B):
 rows={}
 for (i,j),z in B.items():rows.setdefault(i,[]).append((j,z))
 D={}
 for (i,k),a in A.items():
  for j,b in rows.get(k,[]):putval(D,(i,j),mul(a,b))
 return D
def inner(A,B):
 z=Z
 for k,a in A.items():z=add(z,mul(conj(a),B.get(k,Z)))
 return z
def mono(A,B):return tuple((A[r][0],(p+A[r][1])%4) for r,p in B)
def product(seq,gamma):
 D=tuple((i,0) for i in range(32))
 for k in seq:D=mono(D,gamma[k])
 return D
def block(M,parity):
 ids=[i for i in range(32) if i.bit_count()%2==parity];lookup={z:i for i,z in enumerate(ids)};out={}
 for j,col in enumerate(ids):
  row,p=M[col];assert row in lookup;out[lookup[row],j]=phases[p]
 return out
def linear(form,H):
 D={}
 for I,z in form.items():D=plus(D,scaled(H[I],z))
 return D
def tensor_action(form,p,q):
 D={}
 for I,z in form.items():
  if (p in I)==(q in I):continue
  old,new,sign=(p,q,-1) if p in I else (q,p,1);J=tuple(new if i==old else i for i in I);sg=sign*qs.parity(J);putval(D,tuple(sorted(J)),(sg*z[0],sg*z[1]))
 return D
def spin_action(A,L2):return scaled(plus(mm(trans(L2),A),mm(A,L2)),(-1,0))
def determinant(A):return sum((F(qs.parity(p))*__import__('math').prod(A[i][p[i]] for i in range(len(A))) for p in permutations(range(len(A)))),F())
def main():
 started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('ETA_CLIFFORD_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 gamma=[]
 for i in range(10):
  k=i//2;gamma.append(tuple((b^(1<<k),(2*((b&((1<<k)-1)).bit_count())+(1+2*((b>>k)&1) if i%2 else 0))%4) for b in range(32)))
 identity=tuple((i,0) for i in range(32))
 for i in range(10):
  assert mono(gamma[i],gamma[i])==identity
  for j in range(i):
   A,B=mono(gamma[i],gamma[j]),mono(gamma[j],gamma[i]);assert all(a==b and (p-q)%4==2 for (a,p),(b,q) in zip(A,B))
 charge=product([1,3,5,7,9],gamma)
 Cfull={(row,col):phases[phase] for col,(row,phase) in enumerate(charge)}
 assert trans(Cfull)==scaled(Cfull,(-1,0)) and mm(dag(Cfull),Cfull)=={(i,i):(1,0) for i in range(32)}
 for g in gamma:
  Gfull={(row,col):phases[phase] for col,(row,phase) in enumerate(mono(charge,g))};assert trans(Gfull)==Gfull
 forms=[]
 for I in combinations(range(10),5):
  J=tuple(i for i in range(10) if i not in I)
  if I<J:forms.append({I:(1,0),J:(0,-qs.parity(I+J))})
 Hs=[{I:block(mono(charge,product(I,gamma)),p) for I in combinations(range(10),5)} for p in [0,1]]
 first=[linear(forms[0],H) for H in Hs];nonzero=[p for p,A in enumerate(first) if A];assert len(nonzero)==1;chirality=nonzero[0];H=Hs[chirality];G=[block(mono(charge,g),chirality) for g in gamma]
 matrices=[linear(f,H) for f in forms];assert len(matrices)==126 and all(not linear(f,Hs[1-chirality]) for f in forms)
 for i,A in enumerate(matrices):
  assert A==trans(A)
  for j,B in enumerate(matrices):assert inner(A,B)==(64*int(i==j),0)
  assert all(inner(V,A)==Z for V in G)
 for i,A in enumerate(G):
  assert A==trans(A)
  for j,B in enumerate(G):assert inner(A,B)==(16*int(i==j),0)
 count=0
 for p,q in combinations(range(10),2):
  L=block(mono(gamma[p],gamma[q]),chirality);assert plus(dag(L),L)=={}
  for f,A in zip(forms,matrices):assert scaled(linear(tensor_action(f,p,q),H),(2,0))==spin_action(A,L);count+=1
  for i,A in enumerate(G):
   target=scaled(G[q],(-2,0)) if i==p else scaled(G[p],(2,0)) if i==q else {};assert target==spin_action(A,L);count+=1
 print('STAGE complete_Clifford_isometry_and_'+str(count)+'_generator_identities',flush=True)
 rays=read(CROOT/'canonical_so10_sigma_ray_screen/primary_result.json')['rows'];samples=[{tuple(k):tuple(map(F,z)) for k,z in row['form']} for row in rays];samples.append(qs.rotate_form(samples[4]));old=read(CROOT/'canonical_so10_mixed_bfb/primary2_result.json');assert old['complete_B_two_routes_agree_before_couplings'] and old['all10_eta_literal_routes_agree']
 def evaluate(form):
  A=linear(form,H);B=mm(mm(A,dag(A)),A);f=[tuple(F(z)/16 for z in inner(V,B)) for V in G];N=sum(a*a+b*b for a,b in form.values());assert inner(A,A)==(32*N,0)
  P={}
  for z,V in zip(f,G):P=plus(P,scaled(V,z))
  assert all(inner(V,plus(B,scaled(P,(-1,0))))==Z for V in G) and inner(P,P)==(16*sum(a*a+b*b for a,b in f),0)
  assert inner(B,B)[0]<=inner(A,A)[0]**3
  return f,N
 rows=[];alpha=None;proportional=True
 for i,(form,record) in enumerate(zip(samples,old['tensor_records'])):
  f,N=evaluate(form);expected=[tuple(map(F,z)) for z in record['E']]
  if i==3:
   assert expected[0]==(-48,0);alpha=(f[0][0]/(-48),f[0][1]/(-48))
  rows.append({'sample':i,'N':str(N),'matrix_f':[[str(a),str(b)] for a,b in f],'inherited_E':record['E']});print('STAGE cubic_vector_'+str(i),flush=True)
 assert len(rows)==len(samples)==len(old['tensor_records'])==14 and alpha is not None
 for row in rows:
  for f,e in zip(row['matrix_f'],row['inherited_E']):proportional&=tuple(map(F,f))==mul(alpha,tuple(map(F,e)))
 alpha2=alpha[0]**2+alpha[1]**2;Ce=F(2048)/alpha2 if alpha2 else None
 if proportional and alpha2:
  theta=(F(3,5),F(4,5));phased={I:mul(z,theta) for I,z in samples[3].items()};f,_=evaluate(phased);original=[tuple(map(F,z)) for z in rows[3]['matrix_f']];assert f==[mul(z,theta) for z in original] and f!=[mul(z,mul(theta,mul(theta,theta))) for z in original]
 # Actual current physical inputs, not the old benchmark's mixed matrix.
 raw=read(CROOT/'canonical_so10_scalar_benchmark/STAGE1_POINT.json')['free_coefficients'];z4sq=F(raw['z4:re'])**2+F(raw['z4:im'])**2;ell=F(raw['lambdaPhiphi2']);nu=F(raw['lambdaSigmaphi1'])+min(F(raw['lambdaSigmaphi2']),F());vs=F(raw['lambdaVectorS']);tau=F(1,5);tlow=F(111,6250)
 lower=None;minors=[];passed=False
 if proportional and alpha2:
  lower=[[F(1413,2000),F(),-F(1,1000),F()],[F(),F(77,400),(nu-F(9,100)*Ce/tau)/2,-z4sq/tlow],[-F(1,1000),(nu-F(9,100)*Ce/tau)/2,F(1,10),(vs-F(9,10000)/ell)/2],[F(),-z4sq/tlow,(vs-F(9,10000)/ell)/2,F(1)]]
  minors=[determinant([row[:k] for row in lower[:k]]) for k in range(1,5)];passed=all(v>0 for v in minors)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-started<120
 result={'schema':'ETA_CLIFFORD_BOUND_PRIMARY_V1','status':'EXACT_MAP_AND_FIXED_CERTIFICATE_REQUIRE_INDEPENDENT_RECEIPT','base_commit':prep['base_commit'],'selected_chirality':chirality,'Clifford_dimension':32,'chiral_dimension':16,'complete_Sigma_basis_dimension':126,'matrix_isometry_norm_ratio':'32','G_Gram_diagonal':'16','all_generator_intertwinings':count,'all_140_E_components_proportional':bool(proportional),'alpha':[str(z) for z in alpha],'alpha_absolute_square':str(alpha2),'C_eta':str(Ce) if Ce else None,'cubic_records':rows,'full_uniform_lower_matrix':[[str(z) for z in row] for row in lower] if lower else None,'leading_minors':list(map(str,minors)),'full328_quartic_certificate':bool(passed),'certificate_neighborhood':'0<u<1/1000','proof_weight_tau':'1/5','pi_rational_lower':'157/50','portal_t_lower':'111/6250','new_parameter_search':False,'new_numerical_model_points':0,'new_benchmark_adopted':False,'flavor_work_resumed':False,'scientific_authority_changed':False,'physical_viability_proved':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 timer.cancel();print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}),flush=True)
if __name__=='__main__':main()
