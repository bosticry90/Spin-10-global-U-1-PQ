# Phase2 freeze after exact source profile

The original/fresh phase1 profile agrees byte-for-byte, source rank7 including
rho(J01)v. Six additional source values are needed. This is an exact reduction
of all32 directions, not a cutoff or a replacement of the scalar action.

Use the saved raw h, even E=R10+Tmiddle2, odd O=P0,P1,P4,P5,orbit0,1,6,7.
M_E is inherited R/T, M_P is inherited positive-partner mass and orbit potential
M is zero by the inherited stationary-potential Ward theorem. Actual gauge-
fixing masses are separate, not inserted into potential M. Use the weak16
Hessian/basis and its saved rational-Higgs residual, not an exact-null shortcut.
The four missing independent T/orbit cubic values reconstruct the full4x2
odd-orbit/T block by the actual Ward action, not a phase guess.

First qualify an exact two-real-scalar rotational quartic at its stationary
vacuum, with a general nonkernel h. Differentiate the invariant polynomial and
verify all Ward orders. Removing M h or doubling j or B must leave a nonzero
symbolic residual. This supplies an independent normalization/sign reference.

Known source0 is -M(h,rho(J01)h). Calculate each of the other six raw source
values j(x)=V'''[h,h,x]/2 with the existing literal third-direction stencil,
all29 monomials. Complete A and B reconstruction before reference calls.
Restore uncached invariant primitives. Each of six independent source values
must agree exactly per monomial with univariate polarization:
q3(d)=[V(v+2d)-2V(v+d)+2V(v-d)-V(v-2d)]/12,
j(x)=[q3(h+x)-q3(h-x)-2q3(x)]/2.
Prove this on all cubic monomials and the q3 stencil through degree4.

Direct attacks selected solely from the completed Ward prediction:
for each of the two orbit families, largest absolute T/orbit A entry;
add the phase descendant of the global largest (paired indices XOR1).
For B select largest absolute P/orbit entry, largest absolute orbit diagonal,
largest absolute orbit off-diagonal and the fixed phase-forbidden orbit0/1
entry. Also measure the known J01 source directly. Require physical agreement
1e-48, retaining small numerical residues rather than imposing guessed zeros.
For one global-largest A and the P/orbit B control, directly test all29 raw
Ward monomial identities with independent literal mass/cubic/fourth derivatives.
This checks the full action identity, not only a contracted numerical value.

Reuse the already qualified actual nonkernel-Higgs cubic control: reconstruct
its saved bad direction and evaluate the Ward formula with its inherited
literal result. Require1e-48 agreement and nonzero omitted-residual error;
this is reuse, not fresh action differentiation. No expensive old loop runs.
Source factor1/2, Ward sign and orbit/kinetic normalization controls must also
give explicit nonzero differences on measured nonzero components.

Assemble real20 M/A/B, all1,200 matrix slots, and check symmetry/covariance
under actual L=J01-J23. Recover the real complex structure from the actual
paired L action, without changing saved field bases. Verify complex10
Hermitian compression and potential mass spectrum16 positive/4 orbit zeros
per color. Any needed phase reorientation is a diagnostic similarity only.
Symmetry, precision and inherited-block agreement tolerances are1e-48.
No scalar determinant, orbit propagator or full quantum operator is qualified.

Freeze phase2 sources, inputs, original/fresh observed resource runs and
source snapshots before execution. Final validation must check both exact
profile and complete numerical reconstruction, all independent source routes,
selected direct/negative controls, prior evidence and unchanged authority.
No loosening of the prospective RECORD.md or first-failure requirement occurs.
