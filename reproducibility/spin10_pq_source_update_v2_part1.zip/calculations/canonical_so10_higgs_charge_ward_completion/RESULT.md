# Complete scalar-potential inputs for the colored charge sector

The unchanged benchmark now supplies complete M,A,B potential matrices for
the neutral-Higgs color-triplet Q=1/3 sector:20 real directions per color,
60 real including color and conjugates. Classical Ward identities reconstruct
the remaining4 independent T/orbit A and12 independent partner/orbit B values.
Exact symmetry reduction requires only six new source values, each checked
through a second extraction. Selected literal action derivatives agree.

This completes the potential input problem. It does not qualify the coupled
gauge fluctuation operator, a finite60-field determinant, actual infrared
cancellation or physical Higgs matching. The12 potential orbit directions
remain zero modes of M; they are not assigned propagators here.

Use the [prospective contract](RECORD.md), [phase2 freeze](PHASE2_V1.md), native
captures, [validation receipt](validation_receipt.json) and separate exact
Git custody. No action, mass, parameter, vacuum or Higgs direction was fitted.
The table uses the benchmark's internal omega^2=60 convention: A has one
power of mass and B is dimensionless. These are mathematical coupling inputs,
not experimentally measured interactions.

| Newly completed block | Independent real positions | Largest canonical magnitude |
| --- | ---: | ---: |
| One-Higgs T/orbit A | 4 | 0.02862473281810625 |
| Two-Higgs positive-partner/orbit B | 8 | 0.006764805159003035 |
| Two-Higgs orbit/orbit B | 4 | 0.004804216728252976 |

The counts concern matrix components, not new adjustable parameters, separate
physical amplitudes or a progress percentage. The full arrays and all source
coefficients are in [the deterministic result](original_result.json).

The real20 ordering is R10,Tmiddle2,P0/P1/P4/P5,orbit0/1/6/7. Positive M/A/B
inputs are inherited without alteration. Potential M has16 positive and4
orbit-zero directions per color; a complex10 representation gives the same
paired spectrum. The actual L action supplies the complex structure, and the
assembled matrices obey its covariance and real symmetry within1e-48.
Tiny numerical reconstruction residues are retained, not silently set to0.
Some B entries are at the1e-68 to1e-72 rounding level although the selected
literal phase-forbidden entry is exactly0. Future exact-structure compression
must declare and bound its normal-form projection rather than editing these
frozen numerical inputs or treating roundoff as a new interaction.

For raw saved h and generator T, put O=T v,Y=T h. Invariance and the canonical
kinetic pairing give

```text
K(t)(O+tY)=T gradV(v+t h), K(t)=M+tA+t^2B,
A O=-M Y+T M h,
B O=-A Y+T j, j=V3[h,h]/2.
```

The rational Higgs is not exactly null. Its M h term is retained, including
the measured weak16 Hessian and all metric factors. The new T/orbit A uses
the known R/T mass block and these actual transformed vectors. The maximum
retained rational-Higgs correction in that new block is
5.533101791395412e-25.
The earlier actual nonkernel control independently demonstrates why the
term cannot be deleted merely because it is small at this benchmark.

The existing positive-quartic calculation derives its neutral heavy sources
internally but does not serialize the complete covector. This investigation
does not pretend that missing typed input is already supplied. Instead it
forms all32 required T_i p directions for the odd8 basis and four generators.
Because the vacuum and h are fixed by electric Q and color, the source
functional j annihilates generator images. Exact projections

```text
P_Q0=I+9 rho(Q)^2/4,
P_color1=I-C_color/3,
C_color=-sum_ab (Tr(G_a^T G_b)^-1)_ab rho(G_a)rho(G_b)
```

preserve every required source value. The3 is independently derived as the
adjoint color Casimir in the actual trace-normalized matrices. Every projected
state is checked to be annihilated by Q and all eight color generators.
Thus discarded terms are explicitly generator images, not predicted zeros
used to omit calculations.

All new source data are covector evaluations j(x) on explicitly serialized
field directions. Exact linear coordinates transport those evaluations; no raw
Euler tensor template is silently interpreted as a canonical Riesz vector.

The complete source span has rank7 after including rho(J01)v. Its source is
fixed by -M(h,rho(J01)h), giving0 at the saved
direction, and is directly checked. Six additional independent raw source
values determine all32 target projections exactly. This replaces a larger
set of raw derivative targets without omitting any target. The frozen
rank bound was not reached; no computation was truncated.

One of the six measured source values contracts to0 at the frozen point
while its zD/zEta raw coefficients are nonzero and imaginary. It is not a
generic symmetry-forbidden source. All raw29 coefficients remain recorded;
neither this benchmark zero nor small values are used to omit a channel.

Primary sources are literal third derivatives/2, preserving all29 monomials
and Hermitian completions. After the full Ward prediction is complete, all
primary invariant caches are removed. The second extraction uses a univariate
cubic polarization and proves its stencil through degree4:
j(x)=[q3(h+x)-q3(h-x)-2q3(x)]/2. Every one of the six independent source
values agrees exactly per monomial. These routes share the invariant oracle;
their agreement does not validate its physical assumptions independently.

Direct full-action attacks test three T/orbit cubic positions and four B
positions covering positive/orbit, orbit diagonal, orbit off-diagonal and a
phase-forbidden zero. The known J01 source is also directly evaluated. The
selections were frozen as maxima/phase rules before model execution, rather
than chosen after discrepancies appeared. Duplicate positions, if selected
by two rules, are not independent amplitudes. On a largest cubic and the
positive/orbit B test, the entire29-monomial Ward identity is checked with
literal mass/cubic/fourth derivatives before physical contraction.

An exact rotational quartic reference proves all four Ward orders for a
general nonkernel direction and detects omission of M h, doubled j and
doubled B. Actual normalization/sign/source-factor controls give nonzero
differences. The existing bad-Higgs literal cubic is authenticated and the
new Ward formula reproduces it within1e-48; its omitted-residual error is
0.0001018177592863179.
That old literal derivative is reused, not claimed as freshly recalculated.

The profile original/fresh results are byte-identical, SHA256
3b4bf308bf46f1d1831ac8511955e4023fb39b978b98b32dfdc55dc06e837711. Full Ward original/fresh results agree, SHA256
34d21b552a0f739b72c413d0ae8b99e9105c42250f45e272f9c65a970ac83ac8. Full calculation times after imports are
668.222/680.962seconds;
highest sampled private allocations are2,390,163,456/2,389,757,952bytes,
not certified instantaneous peaks. All native launches/resource samples must
meet the350MiB available-commit and8GiB private contract. No failed run
occurred in this increment.

Final validation uses independent moving-slot source projections, exact
rank/reconstruction and a separate rotational reference, Decimal physical
coefficients and all1,200 M/A/B slots, direct-control normalization and
NumPy real20/complex10 spectrum/structure checks. It authenticates the four
native captures, two fresh pairs, sources, prior receipt, state and reports.
Raw staged/committed blobs are checked separately. No old expensive physics
or whole-workspace metadata inventory is repeated. This is bounded structural
Ward corroboration with selected direct attacks, not two complete direct
derivative ledgers or independent expert endorsement.

Next, assemble and qualify the charged coupled quadratic operator using these
complete potential inputs and the previously measured gauge-orbit/Y_i maps.
For a constant neutral Higgs background, scalar-vector derivative mixing is
longitudinal, so separate the transverse vector block from the coupled
longitudinal-scalar/ghost blocks. Derive the fixed-vacuum gauge-fixing and
ghost Hessians from E1/E2, with symbolic g10/xi; do not guess masses or discard
the nonzero Y_i. Compare its known-limit Gaussian cancellation before any
new finite integral.

In parallel with that construction, recover a typed tree-heavy-valley/source
interface in the same coordinates. The tree h2 relaxation and positive
quartic are already qualified; their use in a full matching functional is
not. Reuse these six source projections and the existing radial-S source
rather than repeating the old tree quartic. Identify any genuinely missing
neutral component. A heavy-gauge/soft-subtraction comparator and explicit
light/PQ, tadpole/mass/field definitions are still required before physical
matching. No large general compiler or new physical scheme follows.

The competing full328BFB eta/Sigma/vector question remains unresolved;
existing308BFB and finite profiles do not settle it. Completing the small
coupled operator/source interface is now justified because its potential
inputs are complete, its derivative mixing is measured, and its wrong-
simplification falsifier is available. Reassess cost before integration.

Track A gains complete potential inputs and a cheaper action-derived route.
Track B demonstrates exact functional projection, Ward reconstruction,
distinct extraction checks and preservation of a missing source-interface
limitation. Shared action, representation data, primitive arithmetic,
Python/SymPy and analyst remain common-error risks. Physics/AI objectives
remain equal; education voluntary/concurrent/nonblocking.

The earlier fixed-positive Delta_lambda=-0.01025445303194505 is unchanged
and is not a physical threshold. Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.
All failures/successes, quartet mismatch, fullE5/A5 unqualified, HB1/C5 blocked,
C1_GS uncalculated, flavor pause, fullBFB/naturalness/matter/phenomenology
obligations and custodyexit2/seven unresolved are preserved. No activation,
model/authority/scheme promotion, branch/worktree/reset, remote action or
outreach. Whole investigation remains active/incomplete.
