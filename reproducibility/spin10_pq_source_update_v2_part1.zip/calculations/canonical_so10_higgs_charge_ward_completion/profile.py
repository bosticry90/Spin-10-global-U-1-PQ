"""Exact source-functional reduction before any new invariant evaluation."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,sys,time
import sympy as s
import geometry as g
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
F=g.F;ZERO=g.ZERO
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def mat(values):return s.Matrix(10,10,list(map(s.Rational,values)))
def frac_matrix(a):return [[F(a[i,j]) for j in range(10)] for i in range(10)]
def action(T,a):return g.transform(frac_matrix(T),a)
def add(a,b):return g.plus(a,b)
def scale(a,z):return g.times(a,F(z))
def lin(basis,coeff):
    out=ZERO
    for a,c in zip(basis,coeff):
        if c:out=add(out,scale(a,c))
    return out
def gram(basis):return s.Matrix([[s.Rational(g.inner(a,b)) for b in basis] for a in basis])
def serial(a):return {'Phi':list(map(str,a[0])),'Sigma':[[list(i),str(z[0]),str(z[1])] for i,z in sorted(a[1].items())],
                      'phi':[str(z[0])+('+'+str(z[1])+'*I' if z[1] else '') for z in a[2]],'S':str(a[3][0])+('+'+str(a[3][1])+'*I' if a[3][1] else '')}
writes=[]
def readonly(event,args):
    if event=='open' and len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):
        writes.append(str(args[0]));raise PermissionError('SOURCE_PROFILE_WRITE_DENIED')
sys.addaudithook(readonly)
started=time.perf_counter();prep=read(OUT/'profile_preparation.json')
for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
old=read(ROOT/'calculations/canonical_so10_higgs_colored_orbit_cubics/original_result.json')
charge=read(ROOT/'calculations/canonical_so10_higgs_charge_sector/original_result.json')
h=g.state(read(ROOT/'calculations/canonical_so10_higgs_projected_vertices/original_v2_result.json')['precisions'][1]['h'])
pi=[0,1,4,5];oi=[0,1,6,7];odd=[g.state(old['positive_complement_basis'][i]) for i in pi]+[g.state(old['orbit_basis'][i]) for i in oi]
generators=[mat(old['generators'][i]) for i in oi]
Q=mat(charge['actual_neutral_generators']['Q']);colors=[mat(z) for z in charge['actual_neutral_generators']['color']]
form={}
for bits in product([0,1],repeat=5):form[tuple(2*k+(0 if b else 1) for k,b in enumerate(bits))]=[(F(1),F(0)),(F(0),F(1)),(-F(1),F(0)),(F(0),-F(1))][sum(bits)%4]
vac=(tuple(F(-2 if i<6 else 3) if i==j else F(0) for i in range(10) for j in range(10)),form,(g.Z,)*10,(F(1),F(0)))
print('STAGE exact_unbroken_source_functional_and_color_Casimir_normalization',flush=True)
for T in [Q]+colors:assert action(T,h)==ZERO and action(T,vac)==ZERO
assert all(Q*T==T*Q for T in colors)
K=s.Matrix([[s.trace(a.T*b) for b in colors] for a in colors]);Ki=K.inv();adj=[]
for a in colors:
    cols=[]
    for b in colors:
        comm=a*b-b*a;cols.append(Ki*s.Matrix([s.trace(t.T*comm) for t in colors]))
    adj.append(s.Matrix.hstack(*cols))
cas=-sum((Ki[i,j]*adj[i]*adj[j] for i in range(8) for j in range(8)),s.zeros(8));assert cas==3*s.eye(8)
def color_casimir(a):
    out=ZERO
    for i in range(8):
        for j in range(8):
            if Ki[i,j]:out=add(out,scale(action(colors[i],action(colors[j],a)),-Ki[i,j]))
    return out
def project(a):
    q=add(a,scale(action(Q,action(Q,a)),F(9,4)));assert action(Q,q)==ZERO
    c=add(q,scale(color_casimir(q),-F(1,3)))
    assert action(Q,c)==ZERO and all(action(T,c)==ZERO for T in colors)
    return c
print('STAGE all32_projected_source_directions_and_exact_greedy_span',flush=True)
tz=s.zeros(10);tz[0,1]=-1;tz[1,0]=1;oz=action(tz,vac)
assert g.inner(oz,oz)>0 and project(oz)==oz
basis=[oz];metadata=[{'known_J01_orbit_source':True}];targets=[]
for p,a in enumerate(odd):
    for i,T in enumerate(generators):
        raw=action(T,a);one=project(raw)
        G=gram(basis);b=s.Matrix([s.Rational(g.inner(z,one)) for z in basis]);coords=G.inv()*b;res=add(one,scale(lin(basis,list(coords)),-1))
        if g.inner(res,res)>0:basis.append(one);metadata.append({'odd_index':p,'generator_index':i,'known_J01_orbit_source':False})
        targets.append({'odd_index':p,'generator_index':i,'projected_state':serial(one),'raw_norm_squared':str(g.inner(raw,raw)),'projected_norm_squared':str(g.inner(one,one))})
G=gram(basis);Gi=G.inv()
for target in targets:
    one=g.state(target['projected_state']);coords=Gi*s.Matrix([s.Rational(g.inner(z,one)) for z in basis]);assert lin(basis,list(coords))==one
    target['source_coordinates']=list(map(str,coords))
badR=g.state(read(ROOT/'calculations/canonical_so10_higgs_colored_block/original_result.json')['basis'][0]);bad=add(h,scale(badR,F(1,1000)));badQ=g.inner(action(Q,bad),action(Q,bad));assert badQ>0
for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
assert not writes
result={'schema':'CHARGE_WARD_SOURCE_PROFILE_V1','status':'COMPLETE_EXACT_SOURCE_SPAN_PROFILE_ONLY','odd_original_positive_indices':pi,'odd_original_orbit_indices':oi,
        'color_generator_Gram':[[str(z) for z in row] for row in K.tolist()],'color_adjoint_Casimir':'3','actual_neutrality_and_generator_image_functional_proof':True,
        'source_basis':list(map(serial,basis)),'source_basis_metadata':metadata,'source_basis_Gram':[[str(z) for z in row] for row in G.tolist()],
        'source_rank_including_known_orbit':len(basis),'new_independent_source_values_required':len(basis)-1,'targets':targets,'all32_source_targets_reconstructed_exactly':True,
        'rank_within_declared_bound':len(basis)<=10,'phase2_source_evaluation_allowed':len(basis)<=10,'known_J01_generator':list(map(str,tz)),
        'negative_controls':{'charged_Higgs_guard_norm_squared':str(badQ)},'new_action_derivatives_executed':False,'physical_Higgs_matching_complete':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,
        'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes,'whole_goal_complete':False}
print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started},sort_keys=True),flush=True)
