"""Complete remaining potential blocks through classical Ward/source identities."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,sys,time
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_higgs_colored_positive_cubics'))
import positive_cubics as pc
oc=pc.oc;hp=pc.hp;NAMES=hp.ALL
mp.mp.dps=80
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
txt=hp.text
mtxt=lambda a:[[txt(a[i,j]) for j in range(a.cols)] for i in range(a.rows)]
def norm(a):return oc.mn(oc.inner(a,a))
def proj(a,basis):return mp.matrix([oc.mn(oc.inner(x,a))/mp.sqrt(norm(x)) for x in basis])

def reference_identity():
    v,lam=s.symbols('v lam',positive=True);a,b,t=s.symbols('a b t',real=True);x,y=s.symbols('x y',real=True)
    V=lam*(x*x+y*y-v*v)**2/4;T=s.Matrix([[0,-1],[1,0]]);u=s.Matrix([a,b]);vac=s.Matrix([v,0]);O=T*vac;Y=T*u
    grad=s.Matrix([s.diff(V,z) for z in [x,y]]);H=s.hessian(V,[x,y]);sub={x:v+t*a,y:t*b};K=H.subs(sub)
    M=K.subs(t,0);A=K.diff(t).subs(t,0);B=K.diff(t,2).subs(t,0)/2;j=grad.subs(sub).diff(t,2).subs(t,0)/2;k=grad.subs(sub).diff(t,3).subs(t,0)/6
    identities=[M*O,A*O+M*Y-T*M*u,B*O+A*Y-T*j,B*Y-T*k]
    assert all(z.applyfunc(s.simplify)==s.zeros(2,1) for z in identities)
    bad_res=(A*O+M*Y).applyfunc(s.simplify);bad_source=(B*O+A*Y-2*T*j).applyfunc(s.simplify);bad_B=(2*B*O+A*Y-T*j).applyfunc(s.simplify)
    assert bad_res!=s.zeros(2,1) and bad_source!=s.zeros(2,1) and bad_B!=s.zeros(2,1)
    for n in range(5):assert sum(w*k**n for k,w in [(2,s.Rational(1,12)),(1,-s.Rational(1,6)),(-1,s.Rational(1,6)),(-2,-s.Rational(1,12))])==(1 if n==3 else 0)
    for i in range(4):
        poly=lambda h,x:h**i*x**(3-i)
        out=s.Rational(poly(1,1)-poly(1,-1)-2*poly(0,1),2)
        assert out==(1 if i==2 else 0)
    return {'all_four_Ward_orders_exact':True,'nonkernel_omitted_Mh_residual':list(map(str,bad_res)),'double_j_residual':list(map(str,bad_source)),'double_B_residual':list(map(str,bad_B)),'univariate_source_polarization_proved':True}

def source_reference(h,x,inv):
    result=dict.fromkeys(NAMES,s.S.Zero);base=hp.oracle.vacuum_state()
    for d,mult in [(oc.add(h,x),s.Rational(1,2)),(oc.add(h,oc.sc(x,-1)),-s.Rational(1,2)),(x,-s.S.One)]:
        for node,w in [(2,s.Rational(1,12)),(1,-s.Rational(1,6)),(-1,s.Rational(1,6)),(-2,-s.Rational(1,12))]:
            vals=inv(oc.add(base,oc.sc(d,node)))
            for n in NAMES:result[n]+=mult*w*vals[n]
    return {n:s.simplify(z) for n,z in result.items()}

def main():
    started=time.perf_counter();prep=read(OUT/'preparation.json');writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('CHARGE_WARD_WORKER_WRITE_DENIED')
    sys.addaudithook(readonly)
    for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
    print('STAGE exact_rotational_Ward_and_source_stencil_reference',flush=True);anchor=reference_identity()
    profile=read(OUT/'profile_original_result.json');assert profile['source_rank_including_known_orbit']==7 and profile['new_independent_source_values_required']==6 and profile['phase2_source_evaluation_allowed']
    old=read(ROOT/'calculations/canonical_so10_higgs_colored_orbit_cubics/original_result.json');positive=read(ROOT/'calculations/canonical_so10_higgs_positive_charge_inputs/original_result.json')
    hd=read(ROOT/'calculations/canonical_so10_higgs_projected_vertices/original_v2_result.json');rd=read(ROOT/'calculations/canonical_so10_higgs_colored_block/original_result.json');td=read(ROOT/'calculations/canonical_so10_higgs_colored_triplet_cross/original_result.json');pa=read(ROOT/'calculations/canonical_so10_higgs_colored_positive_cubics/original_result.json')
    h=oc.from_json(hd['precisions'][1]['h']);E=[oc.from_json(z) for z in rd['basis']]+[oc.from_json(z) for z in td['triplet_basis'][2:4]]
    pi=[0,1,4,5];oi=[0,1,6,7];P=[oc.from_json(old['positive_complement_basis'][i]) for i in pi];G=[oc.from_json(old['orbit_basis'][i]) for i in oi];O=P+G
    Ts=[s.Matrix(10,10,list(map(s.Rational,old['generators'][i]))) for i in oi];W=list(map(oc.from_json,old['weak_basis']));HW=mp.matrix(old['weak_Hessian']);qh=proj(h,W);rh=HW*qh
    nh=norm(h);ME=mp.zeros(12);ME[:10,:10]=mp.matrix(rd['M']);ME[10,10]=ME[11,11]=mp.mpf(td['mass_T_squared'])
    coeff,_,_=hp.parent_coefficients(s.Rational(hd['point_w']));Y=[oc.transform(T,h) for T in Ts];py=[proj(y,E) for y in Y]
    print('STAGE reconstruct_complete_T_orbit_A_with_Mh_residual',flush=True)
    newA=mp.zeros(4,2);Alead=mp.zeros(4,2);Acorr=mp.zeros(4,2)
    for i,(T,o) in enumerate(zip(Ts,G)):
        for j,e in enumerate(E[10:]):
            first=mp.sqrt(norm(e))*(ME*py[i])[10+j];second=(rh.T*proj(oc.transform(T,e),W))[0];den=mp.sqrt(nh*norm(e)*norm(o))
            newA[i,j]=-(first+second)/den;Alead[i,j]=-first/den;Acorr[i,j]=-second/den
    AE=mp.zeros(8,12)
    for p in range(4):
        for r in range(10):AE[p,r]=mp.mpf(pa['canonical_A'][pi[p]][r]);AE[4+p,r]=mp.mpf(old['canonical_orbit_A'][oi[p]][r])
        for j in range(2):AE[p,10+j]=mp.mpf(positive['A_PT'][p][j]);AE[4+p,10+j]=newA[p,j]
    sb=list(map(oc.from_json,profile['source_basis']));tz=s.Matrix(10,10,list(map(s.Rational,profile['known_J01_generator'])));known=-(rh.T*proj(oc.transform(tz,h),W))[0]
    sources=[known];raw_sources=[];restore,caches=pc.install_exact_caches();original=hp.oracle.invariant_values;cache={};count=[0]
    def cached(a):
        key=pc.parent.state_key(a)
        if key not in cache:cache[key]=original(a);count[0]+=1
        return cache[key]
    hp.oracle.invariant_values=cached;tick=time.perf_counter()
    for i,x in enumerate(sb[1:],1):
        print('STAGE independent_source_'+str(i)+'_of6',flush=True)
        raw={n:s.simplify(z/2) for n,z in hp.oracle.directional_vertex_coefficients([h,h,x]).items()};raw_sources.append(raw);sources.append(hp.hermitian(raw,coeff))
    source_seconds=time.perf_counter()-tick
    print('STAGE all_primary_sources_complete_reconstruct_all_B_orbit_columns',flush=True)
    target_coords={(t['odd_index'],t['generator_index']):list(map(s.Rational,t['source_coordinates'])) for t in profile['targets']}
    targets=mp.zeros(8,4);source_errors=[]
    for p,a in enumerate(O):
        for i,o in enumerate(G):
            jsum=sum(hp.number(c)*value for c,value in zip(target_coords[p,i],sources));assert abs(mp.im(jsum))<mp.mpf('1e-65');jsum=mp.re(jsum)
            first=mp.sqrt(nh*norm(a))*(AE[p,:]*py[i])[0];den=nh*mp.sqrt(norm(a)*norm(o));targets[p,i]=-(first+jsum)/den;source_errors.append(abs(jsum/den))
    assert max(abs(z) for z in targets[4:,:]-targets[4:,:].T)<mp.mpf('1e-48')
    M=mp.zeros(20);A=mp.zeros(20);B=mp.zeros(20)
    M[:12,:12]=ME;M[12:16,12:16]=mp.matrix(positive['real_M'])[12:16,12:16]
    A[:12,12:]=AE.T;A[12:,:12]=AE
    B[:12,:12]=mp.matrix(positive['real_B'])[:12,:12];B[12:16,12:16]=mp.matrix(positive['B_PP']);B[12:16,16:]=targets[:4,:];B[16:,12:16]=targets[:4,:].T;B[16:,16:]=targets[4:,:]
    basis=E+O;L=pc.J(0,1)-pc.J(2,3);JL=mp.matrix([[oc.mn(oc.inner(a,oc.transform(L,b)))/mp.sqrt(norm(a)*norm(b)) for b in basis] for a in basis])
    assert max(abs(z) for z in JL*JL+mp.eye(20))<mp.mpf('1e-65')
    orientation=mp.eye(20)
    for k in range(10):
        assert abs(abs(JL[2*k,2*k+1])-1)<mp.mpf('1e-65');orientation[2*k+1,2*k+1]=JL[2*k,2*k+1]
    for mat in [M,A,B]:
        assert max(abs(z) for z in mat-mat.T)<mp.mpf('1e-48') and max(abs(z) for z in mat*JL-JL*mat)<mp.mpf('1e-48')
        std=orientation*mat*orientation;cm=mp.matrix([[mp.mpc(std[2*i,2*j],-std[2*i,2*j+1]) for j in range(10)] for i in range(10)])
        assert max(abs(z) for z in cm-cm.conjugate().T)<mp.mpf('1e-48')
    eig,_=mp.eigsy(M);assert sum(abs(v)<mp.mpf('1e-48') for v in eig)==4 and sum(v>mp.mpf('1e-20') for v in eig)==16
    print('STAGE complete_Ward_prediction_then_restore_uncached_source_references',flush=True);restore();hp.oracle.invariant_values=original;tick=time.perf_counter();refs=[]
    for i,x in enumerate(sb[1:],1):
        print('STAGE univariate_source_reference_'+str(i)+'_of6',flush=True);raw=source_reference(h,x,original);assert all(s.simplify(raw[n]-raw_sources[i-1][n])==0 for n in NAMES)
        refs.append({'basis_index':i,'raw_source':{n:str(z) for n,z in raw.items()}})
    known_raw={n:s.simplify(z/2) for n,z in hp.oracle.directional_vertex_coefficients([h,h,sb[0]]).items()};known_actual=hp.hermitian(known_raw,coeff);assert abs(known_actual-known)<mp.mpf('1e-48')
    print('STAGE selected_literal_cubic_and_quartic_attacks',flush=True);direct=[];acases=[]
    for fam in range(2):acases.append(max(((i,j) for i in range(2*fam,2*fam+2) for j in range(2)),key=lambda ij:abs(newA[ij[0],ij[1]])))
    largest=max(((i,j) for i in range(4) for j in range(2)),key=lambda ij:abs(newA[ij[0],ij[1]]));acases.append((largest[0]^1,largest[1]^1))
    for pos,(i,j) in enumerate(acases):
        print('STAGE direct_A_'+str(i)+'_'+str(j),flush=True);raw=hp.oracle.directional_vertex_coefficients([h,G[i],E[10+j]]);value=hp.hermitian(raw,coeff)/mp.sqrt(nh*norm(G[i])*norm(E[10+j]));assert abs(value-newA[i,j])<mp.mpf('1e-48')
        if (i,j)==largest:
            left=hp.oracle.directional_vertex_coefficients([E[10+j],Y[i]]);right=hp.oracle.directional_vertex_coefficients([h,oc.transform(Ts[i],E[10+j])]);assert all(s.simplify(raw[n]+left[n]+right[n])==0 for n in NAMES)
        direct.append({'kind':'A_T_orbit','indices':[i,j],'value':txt(value),'raw':{n:str(z) for n,z in raw.items()},'per_monomial_Ward_checked':(i,j)==largest})
    bcase1=max(((p,i) for p in range(4) for i in range(4)),key=lambda ij:abs(targets[ij[0],ij[1]]));bcase2=max(((4+i,i) for i in range(4)),key=lambda ij:abs(targets[ij[0],ij[1]]));bcase3=max(((4+p,i) for p in range(4) for i in range(4) if p!=i),key=lambda ij:abs(targets[ij[0],ij[1]]))
    for p,i in [bcase1,bcase2,bcase3,(4,1)]:
        print('STAGE direct_B_'+str(p)+'_'+str(i),flush=True);raw4=hp.oracle.directional_vertex_coefficients([h,h,O[p],G[i]]);raw={n:s.simplify(z/2) for n,z in raw4.items()};value=hp.hermitian(raw,coeff)/(nh*mp.sqrt(norm(O[p])*norm(G[i])));assert abs(value-targets[p,i])<mp.mpf('1e-48')
        if (p,i)==bcase1:
            left=hp.oracle.directional_vertex_coefficients([h,O[p],Y[i]]);right=hp.oracle.directional_vertex_coefficients([h,h,oc.transform(Ts[i],O[p])]);assert all(s.simplify(raw[n]+left[n]+right[n]/2)==0 for n in NAMES)
        if (p,i)==(4,1):assert all(z==0 for z in raw.values())
        direct.append({'kind':'B_odd_orbit','indices':[p,i],'value':txt(value),'raw':{n:str(z) for n,z in raw.items()},'per_monomial_Ward_checked':(p,i)==bcase1})
    # Reuse the preserved literal nonkernel control without rerunning that derivative.
    ctrl=old['negative_controls']['nonkernel_direction'];gi,rj=ctrl['indices'];badphi=[0]*10;badphi[6]=s.Rational(1,1000);bad=oc.add(h,hp.State(s.zeros(10),{},tuple(badphi),0));tg=s.Matrix(10,10,list(map(s.Rational,old['generators'][gi])));orb=oc.from_json(old['orbit_basis'][gi]);rr=E[rj]
    first=mp.sqrt(norm(rr))*(ME*proj(oc.transform(tg,bad),E))[rj];second=(proj(bad,W).T*HW*proj(oc.transform(tg,rr),W))[0];den=mp.sqrt(norm(orb)*norm(bad)*norm(rr));badfull=-(first+second)/den;baderror=abs(second/den)
    assert abs(badfull-mp.mpf(ctrl['actual_cubic']))<mp.mpf('1e-48') and baderror>mp.mpf('1e-10')
    normerr=max(abs(AE[4+i,j]*(mp.sqrt(norm(G[i]))-1)) for i in range(4) for j in range(12));signerr=2*max(abs(AE[4+i,j]) for i in range(4) for j in range(12));factorerr=max(source_errors)
    assert normerr>0 and signerr>0
    if max(abs(z) for z in sources)>0:assert factorerr>0
    for n,hsh in prep['input_sha256'].items():assert digest(ROOT/n)==hsh,n
    assert not writes
    result={'schema':'COMPLETE_CHARGE_POTENTIAL_WARD_INPUTS_V1','status':'COMPLETE_CLASSICAL_CHARGE_POTENTIAL_MAB_WARD_RECONSTRUCTION_ONLY','exact_Ward_reference':anchor,'source_rank_including_known_orbit':7,'new_measured_source_values':6,'known_orbit_source':txt(known),'known_orbit_source_direct':txt(known_actual),'known_orbit_raw':{n:str(z) for n,z in known_raw.items()},
      'source_values':list(map(txt,sources)),'raw_measured_sources':[{n:str(z) for n,z in raw.items()} for raw in raw_sources],'independent_source_references':refs,
      'A_orbit_T':mtxt(newA),'A_orbit_T_leading':mtxt(Alead),'A_orbit_T_rational_Higgs_correction':mtxt(Acorr),'B_all_odd_orbit_columns':mtxt(targets),'real_M':mtxt(M),'real_A':mtxt(A),'real_B':mtxt(B),'real_L_generator':mtxt(JL),'potential_mass_eigenvalues':list(map(txt,eig)),
      'direct_checks':direct,'negative_controls':{'omit_orbit_normalization_max_difference':txt(normerr),'wrong_Ward_sign_max_difference':txt(signerr),'double_source_factor_max_difference':txt(factorerr),'inherited_nonkernel_actual':txt(badfull),'inherited_nonkernel_omitted_residual_error':txt(baderror)},'inherited_nonkernel_literal_replayed':False,
      'complete_charge_potential_MAB':True,'real_dimension_per_color':20,'real_dimension_including_color_and_conjugates':60,'missing_potential_component_values':0,'new_independent_A_values':4,'new_independent_B_values':12,'primary_unique_invariant_evaluations':count[0],
      'coupled_gauge_operator_qualified':False,'finite_integrals_executed':False,'physical_Higgs_matching_complete':False,'actual_Spin10_IR_cancellation_proved':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes,'whole_goal_complete':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'primary_source_seconds':source_seconds,'references_and_direct_seconds':time.perf_counter()-tick,'total_seconds':time.perf_counter()-started},sort_keys=True),flush=True)

if __name__=='__main__':main()
