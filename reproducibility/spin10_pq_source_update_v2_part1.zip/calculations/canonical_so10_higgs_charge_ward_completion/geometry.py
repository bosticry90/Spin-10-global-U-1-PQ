"""Exact raw-coordinate tensor geometry; output-index construction."""
from fractions import Fraction as F
from decimal import Decimal as D
from itertools import combinations
import ast
Z=(F(0),F(0))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def scale(a,z):return a[0]*z,a[1]*z
def conj(a):return a[0],-a[1]
def parse(text):
 def go(n):
  if isinstance(n,ast.Constant):assert type(n.value) is int;return F(n.value),F(0)
  if isinstance(n,ast.Name):assert n.id=='I';return F(0),F(1)
  if isinstance(n,ast.UnaryOp):assert isinstance(n.op,ast.USub);return scale(go(n.operand),-1)
  assert isinstance(n,ast.BinOp);a,b=go(n.left),go(n.right)
  if isinstance(n.op,ast.Add):return add(a,b)
  if isinstance(n.op,ast.Sub):return add(a,scale(b,-1))
  if isinstance(n.op,ast.Mult):return mul(a,b)
  if isinstance(n.op,ast.Div):return scale(mul(a,conj(b)),1/(b[0]**2+b[1]**2))
  assert isinstance(n.op,ast.Pow) and b[1]==0 and b[0]==int(b[0]) and b[0]>=0
  z=F(1),F(0)
  for _ in range(int(b[0])):z=mul(z,a)
  return z
 return go(ast.parse(text,mode='eval').body)
def dec(z):return D(z.numerator)/D(z.denominator)
def dp(z):return dec(z[0]),dec(z[1])
def state(a):return tuple(map(F,a['Phi'])),{tuple(i):(F(u),F(v)) for i,u,v in a['Sigma']},tuple(map(parse,a['phi'])),parse(a['S'])
def plus(a,b):
 f={i:add(a[1].get(i,Z),b[1].get(i,Z)) for i in set(a[1])|set(b[1])}
 return tuple(x+y for x,y in zip(a[0],b[0])),{i:z for i,z in f.items() if z!=Z},tuple(add(x,y) for x,y in zip(a[2],b[2])),add(a[3],b[3])
def times(a,z):return tuple(x*z for x in a[0]),{i:scale(x,z) for i,x in a[1].items() if scale(x,z)!=Z},tuple(scale(x,z) for x in a[2]),scale(a[3],z)
def inner(a,b):return sum(x*y for x,y in zip(a[0],b[0]))+F(3,160)*sum(mul(conj(z),b[1].get(i,Z))[0] for i,z in a[1].items())+2*sum(mul(conj(z),w)[0] for z,w in zip(a[2],b[2]))+F(3,5)*mul(conj(a[3]),b[3])[0]
ZERO=((F(0),)*100,{},(Z,)*10,Z)
def combine(basis,coords):
 out=ZERO
 for a,z in zip(basis,coords):
  if z:out=plus(out,times(a,z))
 return out
def parity(idx):return -1 if sum(idx[i]>idx[j] for i in range(len(idx)) for j in range(i+1,len(idx)))%2 else 1
def component(form,idx):return Z if len(set(idx))!=5 else scale(form.get(tuple(sorted(idx)),Z),parity(idx))
def transform(G,a):
 # Output-index contraction, distinct from the primary moving-index loop.
 P=tuple(sum(G[i][k]*a[0][10*k+j]+a[0][10*i+k]*G[j][k] for k in range(10)) for i in range(10) for j in range(10))
 form={}
 for idx in combinations(range(10),5):
  total=Z
  for slot,i in enumerate(idx):
   for k in range(10):
    if G[i][k]:total=add(total,scale(component(a[1],idx[:slot]+(k,)+idx[slot+1:]),G[i][k]))
  if total!=Z:form[idx]=total
 v=tuple(tuple(sum((G[i][k]*a[2][k][part] for k in range(10)),F(0)) for part in range(2)) for i in range(10))
 return P,form,v,Z
