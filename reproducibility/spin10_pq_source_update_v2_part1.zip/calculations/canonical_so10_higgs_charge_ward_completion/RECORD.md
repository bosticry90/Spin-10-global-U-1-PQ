# Full charge-sector potential Ward completion: prospective contract V1

Baseline d664d1b352a9acdedf6899b79bdd3654f482a2b6. Previous goal turn PROGRESS:
actual gauge-fixing orbit masses and nonzero derivative mixing qualified.
Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.

Question: can the remaining4 independent T/orbit A and12 independent partner/
orbit B values be reconstructed from classical gauge invariance, existing
M/A/B inputs and the smallest necessary source projections? These are fixed-
action coefficients, not adjustable parameters. The full potential charge
sector has60 real directions,20 real per color including conjugates. It is
not the complete coupled gauge-theory fluctuation operator or Higgs matching.

For raw saved h,T,O=T v,Y=T h, the canonical-metric Ward identity gives
K(t)(O+tY)=T gradV(v+t h), K=M+tA+t^2 B. Consequently
A O=-M Y+T M h and B O=-A Y+T j,j=V'''[h,h]/2.
In raw test directions p this is
A(p,O)=-M(p,T h)-M(h,T p),
B(p,O)=-A(p,T h)-V'''[h,h,T p]/2.
Retain the actual rational-Higgs M h residual. Divide A by
sqrt(norm_h norm_p norm_O), B by norm_h sqrt(norm_p norm_O).
B is half the fourth derivative. Preserve all mixing/metrics/complex phases.

Phase1 is an exact read-only source-span profile, frozen before derivatives.
Use odd basis P0,P1,P4,P5 plus orbit0,1,6,7, and their four saved raw orbit
generators. Form all32 T_i p projections. Since v and h are fixed by actual
electric Q and all eight color generators, j is invariant under them.
Project Q-neutral with I+9Q^2/4 and color-singlet with I-C_color/3,
C_color=-sum_ab(K_color^-1)_ab rho(G_a)rho(G_b),K_ab=Tr(G_a^T G_b).
Verify resulting states are annihilated by Q/color, rather than assuming
representation labels suffice. The discarded terms are generator images,
so the invariant source functional annihilates them. Prove charge/color
normalization on the actual matrices. Start a greedy exact source basis
with rho(J01)v, whose source is fixed by -M(h,rho(J01)h), then add independent
projected directions in lexicographic p/generator order. Preserve every32
coordinate vector and exact reconstruction. Profile all slots; if rank>10
stop source evaluation as explicitly incomplete, without truncation.
The known positive tree quartic does not serialize its whole source vector;
do not treat an internal old calculation as a supplied current covector.

Freeze phase2 source/preparation after the complete profile and before any
new derivative. Measure only the remaining independent source projections
with the literal central third derivative/2, all29 parent monomials and
Hermitian completions. Each independent source needs an exact second
extraction after primary completion with caches removed: univariate cubic
polarization or an explicitly proved alternate bivariate coefficient stencil.
Retain the J01 source residual and check it directly. No vector/potential
action, parameter, vacuum, Higgs basis or numerical root is changed.

Complete A's T/orbit block using existing E=R10+Tmiddle2 mass and weak16 M h
data. Reuse measured R/orbit and positive A. Recover every missing B orbit
column from the complete A, actual T h and profiled j(T p). Check symmetry,
all phase/charge covariance and inherited positive block. Assemble complete
real20 M/A/B per color ordered R10,T2,P4,orbit4, with inherited potential
orbit zeros (not propagators). Selected direct literal cubic/fourth derivatives
must test T/orbit A and both positive/orbit and orbit/orbit B, including phase
or forbidden zeros where applicable. Freeze the exact selection rule and
numerical tolerances with phase2 code before model execution. Require physical
agreement1e-48 and exact per-monomial Ward identities on selected direct tests.
This is a structural Ward reconstruction plus distinct source extractions and
selected full-action attacks, not a claim of two full direct derivative ledgers.

Controls must detect omission of the weak residual on a deliberately nonkernel
Higgs direction, source factor1/2, orbit/kinetic normalization and wrong Ward
sign. An exact rotationally invariant quartic reference verifies all Ward
orders for a general nonkernel direction before actual source evaluation.
Do not hide discrepancies by assuming predicted zeros or fitting coefficients.
First mismatch stops qualification; failed and incomplete evidence is retained.

Original/fresh profile and phase2 native results must be byte-identical under
the observed350MiB available-commit launch/8GiB private cap and write denial.
Final independent exact source-projection/metric/normalization and matrix
assembly checks, source/resource/state/prior receipt/report authentication and
raw staged/committed Git bytes are required. Authenticate old evidence without
expensive old physics replays or whole-workspace metadata inventory. Resource
or rank boundaries report incomplete work, not a truncated PASS.

Authority ceiling: complete potential inputs under the inherited classical
Ward assumptions, if all checks pass. No finite integral, coupled gauge-
operator qualification, actual IR cancellation, physical gauge/EFT scheme or
Higgs threshold. The prior fixed-positive Delta_lambda and IR warning retain
scope. Preserve failures, quartet mismatch, fullE5/A5 unqualified, HB1/C5
blocked, C1_GS uncalculated, flavor pause, fullBFB/naturalness/matter limits,
custodyexit2/seven unresolved and sole project_state.json authority. No state
edit, activation, refit, branch/worktree/reset, remote action or outreach.
Physics/AI-capability objectives equal; education voluntary/nonblocking.
Shared physical assumptions, invariant primitives, software and analyst limit
independence. Whole investigation remains active/incomplete.
