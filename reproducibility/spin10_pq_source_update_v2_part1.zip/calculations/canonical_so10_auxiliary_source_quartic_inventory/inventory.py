"""Conservative port/type envelope; never computes a pole coefficient."""
from collections import Counter, defaultdict
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, permutations, product
from pathlib import Path
from hashlib import sha256
import json
import os
import re
import sys
import threading
import time
import sympy as S

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
PKG = ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
g, xi = S.symbols('g10 xi')
TARGET = {'J': 1, 'a': 1, 'C': 2}
PROFILE = ('JH', 'JM', 'aH', 'aM', 'CH', 'CM')
DIM = {'B': 1, 'L': 2, 'C': 1, 'a': 1, 'X': 1, 'A': 1, 'J': 1}
write_attempts = []
denied_reads = []


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def token_primary(text):
    pieces = text.split('__')
    assert len(pieces) <= 2
    return pieces[0], tuple(map(int, pieces[1])) if len(pieces) == 2 else ()


def token_replay(text):
    base, marker, jets = text.partition('__')
    assert not marker or jets.isdigit()
    return base, tuple(int(mu) for mu in jets)


def role_primary(n):
    if n.startswith('x_'):
        return 'X'
    m = re.fullmatch(r'(B|A)(\d+)_[0-3]', n)
    if m:
        return m[1] + ('H' if int(m[2]) < 12 else 'M')
    m = re.fullmatch(r'(C|ub|bar|L|b|JL|Jb)(\d+)', n)
    assert m, ('UNSUPPORTED_FIELD', n)
    prefix, i = m[1], int(m[2])
    assert 0 <= i < 45
    kind = {'C': 'C', 'ub': 'a', 'bar': 'a', 'L': 'L', 'b': 'L', 'JL': 'J', 'Jb': 'J'}[prefix]
    return kind + ('H' if i < 12 else 'M')


def role_replay(n):
    if n[:2] == 'x_':
        return 'X'
    if n[0] in ('B', 'A'):
        idx, mu = n[1:].split('_')
        assert int(mu) in range(4)
        return n[0] + ('H' if int(idx) in range(12) else 'M')
    table = {}
    for i in range(45):
        h = 'H' if i in range(12) else 'M'
        table['C'+str(i)] = 'C'+h
        table[('bar' if i < 12 else 'ub')+str(i)] = 'a'+h
        table[('b' if i < 12 else 'L')+str(i)] = 'L'+h
        table['J'+('b' if i < 12 else 'L')+str(i)] = 'J'+h
    assert n in table, ('UNSUPPORTED_REPLAY_FIELD', n)
    return table[n]


role_replay = lru_cache(None)(role_replay)
role_primary = lru_cache(None)(role_primary)


@lru_cache(None)
def powers_primary(text):
    return tuple((a, b) for (a, b), z in S.Poly(S.sympify(text), g, xi).terms() if z != 0)


@lru_cache(None)
def powers_replay(text):
    out = set()
    for term in S.Add.make_args(S.expand(S.sympify(text))):
        if term == 0:
            continue
        powers = term.as_powers_dict()
        a, b = powers.get(g, S.S.Zero), powers.get(xi, S.S.Zero)
        assert a.is_Integer and b.is_Integer and a >= 0 and b >= 0
        out.add((int(a), int(b)))
    return tuple(sorted(out, reverse=True))


def tag_of(roles, gp, xp, jets):
    kinds = sorted(r[0] for r in roles)
    if 'J' in kinds:
        return 'SL' if len(kinds) == 3 else 'KL'
    table = {('B', 'C', 'a'): 'F', ('B', 'B', 'L'): 'U', ('C', 'L', 'a'): 'X',
             ('B', 'B', 'C', 'a'): 'D'}
    if tuple(kinds) == ('C', 'C', 'a', 'a'):
        return 'Q' if gp == 1 else 'R'
    assert tuple(kinds) in table, ('NEW_DIMENSION_ZERO_VERTEX', kinds, gp, xp, jets)
    return table[tuple(kinds)]


def census(route):
    token, role, power = (token_primary, role_primary, powers_primary) if route == 'primary' else (token_replay, role_replay, powers_replay)
    src = load(PKG/f'frozen_a10_bv_master/{route}.json')['source_polynomial']
    gf = load(PKG/f'frozen_a10_e2_transport/{route}.json')['gauge_fixing_density']
    counts = Counter()
    entries = defaultdict(set)
    literal = Counter()
    for origin, rows in [('source', src), ('GF', gf)]:
        for row in rows:
            parsed = [token(n) for n in row['word']]
            if origin == 'source' and not any(re.fullmatch(r'J(?:L|b)\d+', n) for n, j in parsed):
                counts['other_source_terms'] += 1
                continue
            roles = [role(n) for n, j in parsed]
            jets = [len(j) for n, j in parsed]
            counts[origin+'_screened'] += 1
            assert len(roles) <= 4
            if any(r[0] == 'A' for r in roles):
                counts['external_background_terms'] += 1
                continue
            if len(roles) < 3:
                counts['quadratic_reference_terms'] += 1
                continue
            cd = 4 - sum(DIM[r[0]] for r in roles) - sum(jets)
            assert cd >= 0, ('NEGATIVE_COEFFICIENT_DIMENSION', row)
            if cd:
                counts['positive_dimension_'+str(cd)] += 1
                continue
            for gp, xp in power(row['coefficient']):
                tag = tag_of(roles, gp, xp, sum(jets))
                attrs = (gp, xp, len(roles), sum(jets))
                entries[tag].add(attrs)
                ports = tuple(sorted(zip(roles, jets)))
                literal[(tag, gp, xp, ports)] += 1
    vertices = {}
    for tag, values in sorted(entries.items()):
        assert len(values) == 1, ('AMBIGUOUS_TAG', tag, values)
        gp, xp, degree, njets = next(iter(values))
        options = set()
        for t, a, b, fields in literal:
            if t != tag:
                continue
            for pair in combinations(range(degree), 2):
                inner = tuple(fields[i] for i in pair)
                outer = tuple(fields[i] for i in range(degree) if i not in pair)
                if any(r[0] == 'J' for r, j in inner):
                    continue
                if any(j or r[0] not in TARGET for r, j in outer):
                    continue
                external = Counter(r[0] for r, j in outer)
                if any(external[k] > TARGET[k] for k in external):
                    continue
                options.add((inner, tuple(r for r, j in outer)))
        vertices[tag] = {'g': gp, 'xi': xp, 'degree': degree, 'jets': njets,
                         'ports': sorted(options), 'literal_terms': sum(v for (t, a, b, f), v in literal.items() if t == tag)}
    ref = load(PKG/f'frozen_a10_e5_full_hessian/{route}.json')['retained_reference']
    names = ref['field_order']
    assert len(names) == 643 and ref['all643_inverse_directions_both_checked']
    assert ref['literal_GF_all_413449_entries_matched'] and ref['auxiliary_auxiliary_Green_zero']
    types = [role(n) for n in names]
    assert Counter(r[0] for r in types) == {'B': 180, 'L': 45, 'C': 45, 'a': 45, 'X': 328}
    edges = {(types[i], types[j]) for i, j, z in ref['reference_Green_raw_C3']['entries'] if z != '0'}
    expected = {('BH', 'BH'), ('BM', 'BM'), ('BH', 'LH'), ('LH', 'BH'), ('BM', 'LM'), ('LM', 'BM'),
                ('CH', 'aH'), ('aH', 'CH'), ('CM', 'aM'), ('aM', 'CM'), ('X', 'X')}
    assert edges == expected, ('REFERENCE_SUPPORT', edges)
    action = load(PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    fields = set()
    def visit(q):
        if isinstance(q, dict):
            if q.get('node') == 'Field':
                fields.add(q['name'])
            for v in q.values():
                visit(v)
        elif isinstance(q, list):
            for v in q:
                visit(v)
    visit(action['local_terms'])
    assert fields == {'B','Phi','S','SBar','Sigma','SigmaBar','phi','phiBar','x_Phi','x_S','x_Sigma','x_phi'}
    return vertices, edges, {'GF_total': len(gf), 'source_total': len(src),
            'term_census': dict(sorted(counts.items())), 'reference_role_edges': sorted(edges),
            'physical_action_fields': sorted(fields), 'reference_total': len(names), 'scalar_complement': 328}


def families(vertices):
    out = []
    for src in ['SL', 'KL']:
        for n in range(2, 5):
            for rest in combinations_with_replacement(sorted(set(vertices)-{'SL', 'KL'}), n-1):
                tags = (src, *rest)
                if sum(vertices[t]['degree']-2 for t in tags) != 4:
                    continue
                if sum(vertices[t]['g'] for t in tags) != 3:
                    continue
                out.append(tags)
    return sorted(out)


def profile(config):
    outer = Counter(r for inner, ext in config for r in ext)
    kinds = Counter()
    for r, n in outer.items():
        kinds[r[0]] += n
    return tuple(outer[r] for r in PROFILE) if kinds == TARGET else None


def log_degree(config, pairs, flat):
    return 4 + sum(j for roles in config for r, j in roles[0]) + sum(DIM[flat[a][0][0]]+DIM[flat[b][0][0]]-4 for a, b in pairs)


def boolean_cycles(tags, vertices, edges):
    profiles = set()
    witness = {}
    for ordered in sorted(set((tags[0], *rest) for rest in permutations(tags[1:]))):
        for cfg in product(*(vertices[t]['ports'] for t in ordered)):
            prof = profile(cfg)
            if prof is None:
                continue
            for flip in product((False, True), repeat=len(tags)):
                ports = [q[0][::-1] if reverse else q[0] for q, reverse in zip(cfg, flip)]
                if all((ports[i][1][0], ports[(i+1)%len(tags)][0][0]) in edges for i in range(len(tags))):
                    flat = [p for v in ports for p in v]
                    pairs = [(2*i+1, 2*((i+1)%len(tags))) for i in range(len(tags))]
                    assert log_degree(cfg, pairs, flat) == 0
                    profiles.add(prof)
                    witness.setdefault(prof, {'ordered_vertices': ordered, 'internal_ports': ports})
    return profiles, witness


def pairings(xs):
    if not xs:
        yield ()
    else:
        for j in range(1, len(xs)):
            for rest in pairings(xs[1:j]+xs[j+1:]):
                yield ((xs[0], xs[j]), *rest)


def connected(pairs, n):
    if any(a//2 == b//2 for a, b in pairs):
        return False
    reached = {0}
    for step in range(n):
        reached |= {b//2 for a, b in pairs if a//2 in reached} | {a//2 for a, b in pairs if b//2 in reached}
    return len(reached) == n


@lru_cache(None)
def proper(n):
    ps = list(pairings(tuple(range(2*n))))
    good = [p for p in ps if connected(p, n)]
    assert (len(ps), len(good)) == {2: (3, 2), 3: (15, 8), 4: (105, 48)}[n]
    return good


def wick_pairs(tags, vertices, edges):
    profiles = set()
    witness = {}
    for cfg in product(*(vertices[t]['ports'] for t in tags)):
        prof = profile(cfg)
        if prof is None:
            continue
        flat = [p for q in cfg for p in q[0]]
        for p in proper(len(tags)):
            if all((flat[a][0], flat[b][0]) in edges for a, b in p):
                assert log_degree(cfg, p, flat) == 0
                profiles.add(prof)
                witness.setdefault(prof, {'vertex_ports': [q[0] for q in cfg], 'proper_pairing': p})
    return profiles, witness


def table(vertices, edges, route):
    compute = boolean_cycles if route == 'primary' else wick_pairs
    result, witnesses = {}, {}
    for tags in families(vertices):
        profiles, witness = compute(tags, vertices, edges)
        name = '*'.join(tags)
        result[name] = [list(p) for p in sorted(profiles)]
        witnesses[name] = [{'profile': list(p), **witness[p]} for p in sorted(witness)]
    return result, witnesses


def main():
    started = time.perf_counter()
    timer = threading.Timer(120, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    route = sys.argv[1]
    assert route in ['primary', 'replay']
    prep = load(OUT/'preparation.json')
    for n, h in prep['input_sha256'].items():
        assert digest(ROOT/n) == h, n
    assert digest(Path(__file__)) == prep['source_sha256']
    allowed = {str((ROOT/n).resolve()) for n in prep['input_sha256']}
    def guard(event, args):
        if event != 'open' or not args or not isinstance(args[0], (str, bytes)):
            return
        name = os.fsdecode(args[0])
        if len(args) > 1 and isinstance(args[1], str) and any(c in args[1] for c in 'wax+'):
            write_attempts.append(name)
            raise PermissionError('SOURCE_QUARTIC_INVENTORY_WRITE_DENIED')
        p = Path(name)
        if p.suffix == '.json' and str(p.resolve()) not in allowed:
            denied_reads.append(name)
            raise PermissionError('SOURCE_QUARTIC_MEASURED_PEER_OR_UNBOUND_JSON_READ_DENIED')
    sys.addaudithook(guard)
    vertices, edges, inventory = census(route)
    assert vertices['SL']['g'] == 1 and vertices['KL']['g'] == 2
    assert vertices['U']['ports'] == []
    answer, witnesses = table(vertices, edges, route)
    supported = {n for n, ps in answer.items() if ps}
    mixed = {e for e in edges if set(r[0] for r in e) != {'B', 'L'}}
    odd = {e for e in edges if not any(r[0] in ('a', 'C') for r in e)}
    forbidden = edges | {('CH','aM'),('aM','CH'),('CM','aH'),('aH','CM')}
    controls = {}
    for name, modified in [('omit_mixed_BL', mixed), ('omit_odd_propagation', odd), ('allow_forbidden_HM_ghost', forbidden)]:
        changed, unused = table(vertices, modified, route)
        controls[name] = {'changes_envelope': changed != answer, 'supported_families': [n for n, ps in changed.items() if ps]}
        assert controls[name]['changes_envelope'], ('NONDISCRIMINATING_REQUIRED_CONTROL', name)
    assert not connected(((0,2),(1,3),(4,6),(5,7)), 4)
    assert [len(proper(n)) for n in [2,3,4]] == [2,8,48]
    for n, h in prep['input_sha256'].items():
        assert digest(ROOT/n) == h, n
    assert not write_attempts and not denied_reads and time.perf_counter()-started < 120
    result = {'schema':'AUXILIARY_SOURCE_QUARTIC_TYPE_INVENTORY_V1', 'route':route,
              'status':'COMPLETED_CONSERVATIVE_TYPE_ENVELOPE_REQUIRES_PAIRED_VALIDATION',
              'vertices':vertices, 'inventory':inventory, 'family_profiles':answer,
              'supported_families':sorted(supported), 'witnesses':witnesses, 'controls':controls,
              'profile_order':PROFILE, 'proper_pair_counts':{'2':2,'3':8,'4':48},
              'actual_coefficients_or_color_cancellations_calculated':False,
              'all45_directions_retained_in_raw_domain':2004750,
              'color_correlations_and_Lorentz_contractions_relaxed':True,
              'scalar_complement_and_no_physical_odd_vertex_checked':True,
              'no_finite_IR_or_complete_restoration_claim':True,
              'source_sha256':prep['source_sha256'], 'input_sha256':prep['input_sha256'],
              'write_attempts':write_attempts, 'denied_unbound_reads':denied_reads,
              'seconds_after_import':time.perf_counter()-started}
    print('RESULT '+json.dumps(result, sort_keys=True, separators=(',',':')), flush=True)
    print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}), flush=True)
    timer.cancel()


if __name__ == '__main__':
    main()
