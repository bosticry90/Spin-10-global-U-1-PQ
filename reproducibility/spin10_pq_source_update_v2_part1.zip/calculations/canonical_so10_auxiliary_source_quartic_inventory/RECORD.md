# Four-leg auxiliary-source pole: bounded inventory V1

Baseline6c863dc32462842ba9f049ab6cc75581f647cac8. Live AGENTS.md delegates
this bounded prerequisite; no blocked stage, scalar point, input prescription
or normalization is adopted. project_state.json v113/34of39 is unchanged.

Question: which proper one-loop graph families can supply the dimension-zero
local g10^3 JLambda*a*C*C logarithmic pole under the qualified classical
action/reference rules? This is the actual missing source class recovered in
handoffV150. A complete amplitude is NOT calculated in this increment.

Types: JLambda odd(d1,gh-1), a odd(d1,gh-1), C odd(d1,gh+1). All45 source,
antighost and ghost directions remain; the raw antisymmetric-C index domain
is2004750. Sources/backgrounds have no quantum inverse. Zero external jets
select the local coefficient, not a physical zero-momentum/scaleless integral.
No relation is solved from the partial Slavnov remainder or a candidate image.

Inputs: the separately qualified primary/replay classical source polynomials,
gauge-fixing densities, full643-field reference inverses and physical-action
AST, exact bytes frozen in preparation.json with this record and runtime source.
The known source-pair result is background motivation only; workers must not
decode measured poles, normalization candidates, peer outputs or the partial
Slavnov tensor. Upstream action/reference derivations are inherited, not fresh
reproduction. No change to the action or its H/M split is permitted.

Primary: parse the complete literal source/GF polynomials, including discarded
background, quadratic and positive-dimensional sectors. Extract every eligible
two-quantum-leg vertex port configuration and propagate Boolean inverse support
around ordered proper cycles with complete external-type/coupling accounting.
Replay: independently parse the other classical route and enumerate connected
perfect Wick pairings of the vertex ports, retaining all permutations allowed
by the external roles. Compare complete eligible/excluded family tables and
external H/M signatures only after both workers finish.

Both methods deliberately forget individual color correlations and coefficients
after the literal census. They give a conservative COMPLETE type-level envelope:
an absent supported routing proves a structural zero, while a surviving routing
does not prove a nonzero color tensor or a logarithmic residue. Neither route
tests graded loop signs, factorials, Lorentz contractions or coefficient-level
cancellations. These remain mandatory for a subsequent actual calculation.
Do not mistake H/M role aggregation for a representation-preserving amplitude.

Completeness: for a connected proper one-loop graph each vertex has two internal
incidences and sum(degree-2)=4. Include four cubics, two cubics/one quartic,
two quartics. A physical-action vertex cannot supply an external member of this
all-odd source/ghost target; screen its actual AST field content. External
background or other-source terms cannot be contracted away. Positive-dimensional
mass/orbit coefficients are excluded ONLY from this dimension-zero leading UV
pole in the polynomial high-momentum expansion without inverse parameters.
The full scalar complement and mixed gauge/auxiliary reference support must be
accounted for. Do not infer finite, IR, anomaly or full-restoration conclusions.

Independent anchors: connected-cycle degree counting and Wick's finite pairing
identity; the qualified full reference inverse and actual literal action. Check
proper pair counts at two/three/four vertices. Controls must discriminate a
missing mixed B/L propagator, absent odd propagation and a forbidden H/M ghost
edge. Keep nondiscriminating controls explicit. Check exterior-field gradings,
reference parity/H-M blocks and isolated scalar support before the routing test.
Shared input assumptions, role abstraction, Python/SymPy and analyst limit
independence. No external scientific endorsement or new physics discovery claim.

Two sequential owned roles, primary and replay, each capped at120seconds after
imports and8GiB sampled private memory; minimum350MiB available commit before
launch. Retain complete source snapshots, input digests, native captures and
failures; no automatic retry or resource increase inside this version. Any
correction needs a preserved new bounded version under standing delegation.
Resource exhaustion, missing input, unsupported signature, method disagreement
or nondiscriminating required controls blocks the positive inventory claim.

Validation: authenticate all frozen inputs/sources and complete captures;
verify actual resource observations, method agreement on the whole role-level
family/signature domain, no peer/pole reads or worker writes, all controls,
protected state/policy/previous evidence invariance and exact raw Git bytes.
Fresh byte-identical replays of qualified old loops are not justified here.
The new workers have distinct algorithms; no fresh same-command pair is claimed.
No broad E5 replay is required for this new read-only structural envelope.

Outcome ceiling: qualified conservative graph/type inventory, proved structural
exclusions and a bounded implementation decision; or preserved inconclusiveness.
An actual source amplitude, completed Slavnov relation, full E5/A5, HB1/C5,
C1_GS, physical matching, benchmark adoption and the full investigation remain
unqualified. Preserve previous quartet failures, custodyexit2/seven, paused
flavor and the current scalar quantum-control warning. No search, parameter
release, remote operation or publication. Science and AI-capability evaluation
are equal; education stays voluntary, concurrent and nonblocking.
