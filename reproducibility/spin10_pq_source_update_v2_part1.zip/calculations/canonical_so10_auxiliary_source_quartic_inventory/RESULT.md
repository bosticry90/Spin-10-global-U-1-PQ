# Three candidate graph families remain for the four-leg source pole

The primary Boolean-cycle construction and separate connected-Wick-pairing
construction agree on the complete conservative TYPE envelope for the missing
g10^3 JLambda*a*C*C local UV coefficient. Three families remain possible;
seven other coupling-compatible families have no permitted routing.
Qualification requires the actual validation_receipt.json, complete captures,
input/source integrity and raw Git checks under [the record](RECORD.md).

This is a graph inventory, not a calculated pole. Individual color correlations,
graded coefficient signs, Lorentz contractions and cancellations can make a
remaining family smaller or zero. A permitted role-level cycle does not prove
a nonzero amplitude. No coefficient was inferred from the Slavnov remainder.

## Literal inventory and graph envelope

Each route screens35162 source terms and33092 gauge-fixing terms, retains the
full643-field reference, and accounts for its328-scalar complement. The source
screen finds180 cubic and836 quartic terms involving JLambda. The ordinary
dimension-zero action supplies5640 derivative-ghost terms,720 auxiliary/vector
terms,276 xi-dependent auxiliary/ghost terms,648 g*xi quartic-ghost terms,
418 g²*xi curvature-ghost terms and14120 ordinary g² B²*a*C terms.
These are literal coupling-component counts, not particle counts or nonzero
pole entries. One literal word can contribute at more than one coupling order.

Notation for the table:
SL=JLambda*Lambda*C atg; KL=JLambda*a*C*C atg²;
F=B*a*C with one derivative atg; X=Lambda*a*C atxi;
Q=a*a*C*C atg*xi; R=a*a*C*C atg²*xi;
D=B*B*a*C atg²; U=Lambda*B*B atg.
Full derivative placements are retained when deciding which legs can be
internal. An external derivative cannot enter this no-jet coefficient.

| Family | Conservative routing status | Possible external ghost sectors |
| --- | --- | --- |
| SL*F*F*X box | POSSIBLE | M/M or H/M |
| KL*F*X triangle | POSSIBLE | M/M or H/M |
| KL*Q bubble | POSSIBLE | M/M |
| SL*F*Q; SL*D*X; SL*R*X | EXCLUDED BY REFERENCE SUPPORT | None |
| KL*U*X; SL*F*U*X; SL*Q*U; SL*U*U*X | EXCLUDED BY EXTERNAL TYPES | None |

Here H/M refer to the frozen residual/complement split. The cubic SL has an
internal heavy auxiliary and light ghost. These cannot both attach to the
three excluded triangle families under the actual mixed and ghost inverse
blocks. U has no possible target external leg at all. The algorithms test
all port assignments, rather than declaring these diagram classes absent.

Every possible profile has a heavy JLambda and heavy antighost, with at most
one H ghost. Thus the role envelope permits at most
33²[binomial(33,2)+12*33]=1006236 of the2004750 raw independent component
slots. The other998514 slots are structurally absent for this selected pole.
This upper bound is not a count of actual nonzero coefficients or a proposal
to evaluate a dense million-entry tensor.

## A useful reduction of the required reference calculation

Every allowed F port configuration contains one internal B and one internal
odd field. Every allowed X contains one internal Lambda and one internal odd
field. SL has one internal Lambda and C_H; KL and Q have only internal odd
fields. Consequently the box has two B and two Lambda ports, the triangle
one of each, and the bubble none. Since Lambda propagates only into B and
the Lambda/Lambda inverse is zero, ALL vector lines are mixed B/Lambda lines.
No B/B propagator occurs in a supported routing.

The independent validation checks both complete rational reference inverses:
their mixed B/Lambda and ghost entries contain neither xi nor eta_H. The
eligible nonquadratic action vertices contain no eta_H either. Each surviving
family contains exactly one explicit xi vertex, X or Q. Therefore the selected
g³ pole, if nonzero, must be proportional to xi and independent of the formal
reference widths. This structural restriction does not calculate its sign or
coefficient. It does not extend to other g orders, amplitudes, finite terms or
the IR limit, and it is not a choice of physical gauge width.

A subsequent actual calculation can exploit these mixed longitudinal lines,
but must still derive the general-momentum Lorentz and graded-Gaussian factors,
all source/ghost signs, identical-particle factors and color contractions.
No coefficient-level cancellation or transverse-reduction theorem is claimed
merely from this type proof.

## Validation, limitations and next action

The native routes completed in about6.50s and4.11s after imports under the
declared120second/8GiB bounds. Both use the separate upstream classical
primary/replay records. No old loop is rerun and no fresh same-command pair
is claimed. All complete captures and immutable source/input snapshots remain.

Both algorithms detect deletion of mixed B/Lambda propagation, deletion of
odd propagation and insertion of a forbidden H/M ghost edge. Without mixed
propagation only the possible bubble remains; without odd propagation none
remains. The forbidden edge spuriously admits SL*D*X and SL*F*Q. Connected
pairing counts2,8,48 at two/three/four vertices agree with the finite cycle
count; disconnected double bubbles are rejected. These are structural controls,
not tests of the uncomputed graded loop coefficients.

The methods share qualified action/reference assumptions, H/M role abstraction,
Python/SymPy and analyst. They test different enumeration/parsing errors while
retaining shared-error risks. This is internal mathematical corroboration,
not independent expert endorsement or demonstrated empirical success.

Next: freeze a bounded actual calculation of these three families, including
general-q unit controls and independently constructed color contractions.
Compare completed actual routes before releasing the partial Slavnov tensor.
Do not fit a normalizer or declare the unknown breaking zero. Resource or
method failure must remain an explicit incomplete outcome.

No actual four-leg pole, completed auxiliary Slavnov relation, full E5/A5,
HB1/C5, finiteC1_GS or physical matching is qualified here. The current scalar
point's quantum-control warning remains; no benchmark/input is adopted.
State34/39, earlier quartet failures, paused flavor and custodyexit2/seven
remain unchanged. Track A gains a smaller justified calculation; Track B gains
a bounded completeness/negative-control result with its limits disclosed.
Education remains voluntary, concurrent and nonblocking. The whole project
remains incomplete.
