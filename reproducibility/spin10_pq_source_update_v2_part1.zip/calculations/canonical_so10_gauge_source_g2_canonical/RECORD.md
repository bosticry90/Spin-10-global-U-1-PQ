# Actual g2 gauge-source canonical integration and local Ward V1

Baselinefd0eb07dca2bcd3a7fbcf52ebbbd5ec7044b37cb. The completed paired
color-pole receipt6630290f13307466c1bf45ccabbc6f4bcc5422fa7659696fa17f94cbaa19cb07
qualifies all45² positions and all4 source conventions. Its constant H
covariance does not establish local background Ward closure. Integrating that
measured result is the smallest necessary next consistency calculation.

Claim: pull back the complete bound g2 pole to the canonical chart, retain
every Lorentz copy and jet, prove the full primal/dual roundtrip, add this
coupling/type/jet order exactly once to the current partial functional, and
calculate its complete local background Ward variation. Do not infer a zero
or a missing companion coefficient from a desired identity. Nonzero remainders
are unresolved obligations, not an anomaly or inconsistency theorem.

Use the original source index convention: sum_mu JB_mu partial_mu C has no
additional ETA_mu multiplier. Primary applies the qualified polynomial chart
substitution to the physical density. Replay directly contracts the source
dual and ghost matrices, restoring the four components from that complete
matrix. Both use own completed color results only and compare full canonical
nodes and physical roundtrips before any scientific interpretation.

Use actual E3 local background transformations including source images and
parameter jets. Primary uses the established even derivation; replay expands
the word-by-word Leibniz rule and differentiated field images. Retain the
complete raw remainder, the anchored parameter expression, all12 parameter
Euler derivatives and four exact IBP currents. No EOM, gauge choice, physical
normalization or quantum breaking is set by this check. Test omission of
source variation, extra spatial metric, reversed odd order and double addition;
record insensitive Ward controls if the actual answer makes them so.

Reuse the current corrected recipe, not MF V3 assemble(): previous measured
base plus its existing three additions and the actual g4 source/vector node
gives92236 terms. Authenticate its saved zero Ward and receipt. Prove this
ordinary g2 JB/one-jet/C order is absent before adding the new node. Reuse
linearity for the updated Ward rather than rerun the old complete variation.
Store a compact hash-bound versioned recipe, not another full92236-term copy.

Two sequential read-only workers,300seconds after imports, sampled8GiB and
>=350MiB available commit. Freeze source/controller, inputs, prior receipts
and allowed own-role reads before execution. No new loop, pole fit, benchmark,
physical input, blocked-stage activation, old evidence edit or remote action.
Preserve complete native failures and dependent limitations. Qualify only
after complete paired agreement and separate validation.

Ceiling: this selected measured node, its exact local background Ward and the
versioned partial-functional sum. Full source/Slavnov restoration,E5/A5,QAP,
finite/IR,measure and anomaly freedom remain unqualified. Authorityv113/34of39
unchanged; HB1/C5 blocked,C1_GS uncalculated,flavor paused. Preserve prior
exclusions/failures,scalar warning,custodyexit2/seven. Track B reports shared
chart/action/derivation/software/AI-authorship risks; Track C voluntary,
concurrent and nonblocking. No new benchmarking or policy infrastructure.
