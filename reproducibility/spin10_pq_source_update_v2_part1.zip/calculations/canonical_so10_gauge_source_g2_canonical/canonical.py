"""Exact dependent pullback and local Ward; no new loop or fitted companion."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,canonical,decode_typed,rows,act,cm,register,zero
from a10_e5_measured_functional_v3 import frames,omega_reduce
etaH=s.Symbol('eta_H',real=True)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def direct_ward(P,w,images):
    out={}
    for word,z in P.items():
        for i,(n,jets) in enumerate(word):
            image=images[n]
            for mu in jets:image=w.D(image,mu)
            one=w.mul({word[:i]:s.S.One},image,{word[i+1:]:s.S.One})
            for key,value in one.items():out[key]=out.get(key,0)+z*value
    return canonical(out)

def replay_anchor(P,w):
    anchored={};currents=[{} for mu in range(4)]
    def add(A,P):
        for word,z in P.items():A[word]=A.get(word,0)+z
    for word,z in P.items():
        slots=[i for i,(n,jets) in enumerate(word) if re.fullmatch(r'omega\d+',n)];assert len(slots)==1
        i=slots[0];name,jets=word[i];assert len(jets)<=1
        if not jets:add(anchored,{word:z});continue
        mu=jets[0];rest={word[:i]+word[i+1:]:z}
        add(currents[mu],w.mul(w.var(name),rest));add(anchored,w.scale(w.mul(w.var(name),w.D(rest,mu)),-1))
    return canonical(anchored),list(map(canonical,currents))

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('G2_CANONICAL_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('G2_CANONICAL_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return value
    color_path=ROOT/f'calculations/canonical_so10_gauge_source_g2_color/{role}_result.json';data=read(color_path)
    receipt=read(ROOT/'calculations/canonical_so10_gauge_source_g2_color/validation_receipt.json');assert receipt['execution_state']=='COMPLETED' and receipt['input_sha256'][str(color_path)]==digest(color_path)
    w,forward,back,source,anti,Cinv,Cphys=stage('real_source_dual_and_ghost_charts',lambda:frames(role))
    P=s.zeros(45)
    for i,k,text in data['bound_pole']:P[i,k]=s.sympify(text,locals={'xi':xi,'eta_H':etaH})
    physical=canonical(w.add(*(w.scale(w.mul(w.var(f'JBp{i}_{mu}'),w.D(w.var(f'Cp{k}'),mu)),g**2*z) for (i,k),z in P.todok().items() for mu in range(4))))
    if role=='primary':node=stage('complete_polynomial_dual_pullback',lambda:canonical(w.replace(physical,back)))
    else:
        raw=stage('direct_source_dual_matrix_contraction',lambda:cm(Cinv*P*Cphys))
        node=canonical(w.add(*(w.scale(w.mul(w.var(f'JB{i}_{mu}'),w.D(w.var(f'C{k}'),mu)),g**2*z) for (i,k),z in raw.todok().items() for mu in range(4))))
    roundtrip=stage('full_four_Lorentz_polynomial_roundtrip',lambda:canonical(w.replace(node,forward)))
    zero(w.add(roundtrip,w.scale(physical,-1)),'ALL_PHYSICAL_SOURCE_DERIVATIVE_COEFFICIENTS')
    for mu in range(4):
        assert all((int(next(n for n,j in word if n.startswith('JB'))[-1]),next(j for n,j in word if re.fullmatch(r'C\d+',n)))==(mu,(mu,)) for word in node if next(n for n,j in word if n.startswith('JB')).endswith('_'+str(mu)))
    assert w.grade(node,(4,0,0))
    extra_metric=canonical({word:z*(1 if next(n for n,j in word if n.startswith('JB')).endswith('_0') else -1) for word,z in node.items()});assert extra_metric!=node
    odd_reversed=w.scale(node,-1);assert odd_reversed!=node
    active={n for word in node for n,j in word};e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');tb=e3['operators']['Tb_geometric_and_transported'];assert active<=set(tb)
    images={n:decode_typed(tb[n]) for n in active};method=(lambda A,I:canonical(act(A,w,I,role,0))) if role=='primary' else (lambda A,I:direct_ward(A,w,I))
    ward=stage('complete_local_background_Ward',lambda:method(node,images))
    anchored,currents=stage('parameter_anchor_and_all_IBP_currents',lambda:omega_reduce(ward,w) if role=='primary' else replay_anchor(ward,w))
    zero(w.add(ward,w.scale(anchored,-1),w.scale(w.add(*(w.D(T,mu) for mu,T in enumerate(currents))),-1)),'COMPLETE_LOCAL_PARAMETER_IBP')
    eulers={f'omega{h}':canonical(w.EL(ward,f'omega{h}')) for h in range(12)}
    zero(w.add(anchored,w.scale(w.add(*(w.mul(w.var(n),Q) for n,Q in eulers.items())),-1)),'ALL12_PARAMETER_EULERS')
    no_source={n:({} if n.startswith('JB') else Q) for n,Q in images.items()};bad=stage('source_variation_omission_control',lambda:method(node,no_source))
    wrong_metric=stage('extra_spatial_metric_control',lambda:method(extra_metric,images))
    prior=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_pole/dependent_result.json');rec=prior['updated_known_recipe'];pair=rec['prior_source_pair_recipe'];base=pair['prior_recipe']
    base_path=PKG/base['base_path'];initial=read(base_path)
    color4_path=ROOT/f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json';color4=read(color4_path)
    assert color4['updated_known_terms']==92236 and color4['updated_known_Ward']==[]
    def previous():return canonical(w.add(decode_typed(initial[base['base_key']]),decode_typed(base['add_once']),decode_typed(pair['add_source_pair_once']),decode_typed(rec['add_actual_source_quartet_once']),decode_typed(color4['new_actual_g4_node'])))
    known=stage('authenticate_and_reconstruct_prior92236_recipe',previous);assert len(known)==92236
    already={}
    for word,z in known.items():
        if len(word)==2 and sum(bool(re.fullmatch(r'JB\d+_[0-3]',n)) for n,j in word)==1 and sum(bool(re.fullmatch(r'C\d+',n)) for n,j in word)==1:
            q=s.Poly(z,g).coeff_monomial(g**2)
            if q:already[word]=q
    assert not already,'ORDINARY_G2_DERIVATIVE_SOURCE_ALREADY_IN_PRIOR'
    updated=stage('add_actual_node_exactly_once',lambda:canonical(w.add(known,node)))
    removed=canonical(w.add(updated,w.scale(node,-1)));assert removed==known
    doubled=canonical(w.add(known,w.scale(node,2)));assert doubled!=updated
    census=Counter()
    for word,z in ward.items():
        omega=next(j for n,j in word if n.startswith('omega'));jets=sum(len(j) for n,j in word)
        for power,c in s.Poly(z,g).terms():
            if c:census[power[0],jets,len(omega)]+=1
    previous_receipt=ROOT/'calculations/canonical_so10_source_vector_color_tensor/canonical_validation_receipt.json';old_receipt=read(previous_receipt)
    assert old_receipt['execution_state']=='COMPLETED' and old_receipt['input_sha256'][str(color4_path)]==digest(color4_path)
    result={'schema':'ACTUAL_G2_GAUGE_SOURCE_CANONICAL_WARD_V1','route':role,'actual_color_before_Ward_and_recipe_read':True,
      'physical_node_terms':len(physical),'canonical_node_terms':len(node),'all4_component_roundtrip':True,'new_actual_g2_node':rows(node),'physical_node':rows(physical),
      'extra_spatial_metric_changes_node':True,'odd_reversal_changes_node':True,'source_variation_omission_changes_Ward':bad!=ward,'extra_spatial_metric_changes_Ward':wrong_metric!=ward,
      'new_local_Ward':rows(ward),'new_local_Ward_terms':len(ward),'anchored_Ward':rows(anchored),'all12_parameter_Eulers':{n:rows(Q) for n,Q in eulers.items()},'IBP_currents':list(map(rows,currents)),
      'Ward_census':[{'g':gp,'total_jets':jets,'omega_jets':oj,'monomials':n} for (gp,jets,oj),n in sorted(census.items())],
      'local_Ward_zero':not bool(ward),'all12_parameter_Eulers_zero':not any(eulers.values()),'raw_minus_anchor_is_exact_divergence':True,
      'prior_known_terms':92236,'prior_saved_Ward_zero':True,'ordinary_g2_order_absent_from_prior':True,'updated_known_terms':len(updated),
      'updated_known_sha256':sha256(json.dumps(rows(updated),sort_keys=True,separators=(',',':')).encode()).hexdigest(),'updated_known_Ward':rows(ward),'updated_known_Ward_zero':not bool(ward),
      'add_once_invertible_and_doublecount_rejected':True,'doublecount_changes_Ward':canonical(w.scale(ward,2))!=ward,
      'updated_known_recipe':{'previous_recipe_path':str(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_pole/dependent_result.json'),'previous_recipe_sha256':digest(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_pole/dependent_result.json'),
        'previous_actual_g4_path':str(color4_path),'previous_actual_g4_sha256':digest(color4_path),'prior_terms':92236,'add_actual_node_key_once':'new_actual_g2_node'},
      'unknown_companion_or_quantum_breaking_fitted':False,'full_source_Slavnov_E5_A5_or_anomaly_freedom':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
