# Actual g2 source pole integrated; local Ward remains open

The measured ordinary g2 gauge-source derivative pole is now expressed in the
canonical chart and added exactly once to a new partial-functional recipe.
Two methods agree on the complete node, physical roundtrip, local Ward,
parameter Euler derivatives, IBP currents and updated-functional hash.

| Quantity | Qualified result |
| --- | --- |
| Real physical node | 300 terms, all4 components |
| Canonical node | 176 terms,44 per component |
| Prior saved partial functional | 92236 terms, saved background Ward zero |
| Updated partial functional | 92280 terms |
| New raw local Ward remainder | 920 terms |
| Anchored Ward expression | 1840 terms |
| Parameter Euler derivatives | All12 nonzero |
| Four boundary currents | 230 terms each |

In plain language, the previously missing loop contribution has been inserted
with its original index convention. The enlarged partial calculation no
longer satisfies the local background identity by itself. Its new remainder
identifies an obligation for further source/vector contributions. It does not
establish a gauge anomaly or a failure of the full theory.

All raw remainder terms are order g10³, contain one ordinary derivative and
one differentiated local H parameter. The exact relation is
W_raw=W_anchored+sum_mu partial_mu K_mu. Independent parameter Euler
derivatives reproduce the anchor. Since all12 are nonzero, this particular
remainder is not a pure total derivative. No EOM or discarded parameter jets
were used to turn it into zero.

The original saved92236-functional and its zero background Ward remain
unchanged as historical objects. The new176-term node changes coefficients
on132 existing words and introduces44 additional words. The resulting count
is92280, not92412. Proving that the ordinary g2 derivative-source order was
absent prevents double counting; removing the new node recovers the prior
functional exactly. The updated canonical row hash is
`a5a26252c3f5998dc8863cd186daec4537cf9eca11901d626a5847afd8157c65`.

The primary substitutes the complete real density through the source-dual
and ghost chart. The replay directly contracts Cinv*P*Cphys before restoring
the four components. Both check the full physical polynomial roundtrip.
The canonical matrix is diagonal in the existing chart; implicit zeros and
all44 nonzero directions per component are retained. No extra spatial metric
is inserted. Primary even-derivation and replay word-by-word Leibniz methods
give identical local Ward expressions. Their parameter reductions and all12
Euler checks agree.

Omitting source variation, inserting an extra spatial metric, or doubling the
node changes the Ward result. Reversing the two odd external factors changes
the node sign. The four IBP currents reconstruct the full difference between
raw and anchored expressions. These controls test the declared algebra; they
do not prove completeness of uncomputed quantum contributions.

No loop was rerun. The workers reused the
[qualified actual color pole](../canonical_so10_gauge_source_g2_color/RESULT.md)
and the [corrected current recipe](../canonical_so10_gauge_source_lorentz_audit/RESULT.md).
Primary/replay completed in45.924 and47.375 seconds after imports, below their
300-second/8GiB caps. No failed execution occurred. The separate validation
checks captures, complete paired objects, the exact parameter-current/Euler
relations, metadata, UTF-8 links, protected files and input hashes.

The machine-readable updated_known_recipe in each completed result references
the prior recipe and actual g4 node by path/hash and adds new_actual_g2_node
once. It does not store another complete92280-term copy or become an alternate
scientific authority ledger.

Next use the actual local transformations and the qualified source-linear
frontier to identify the allowed affine A_H/B_H source-vector predecessor
relation for this g3 one-jet remainder. That is a diagnostic requirement,
not a measured companion pole. Establish which vertex combination the identity
would require, then select the smallest action-derived calculation capable of
testing it. Do not fit an uncomputed coefficient to restore the identity.

Track B: complete measured-input integration exposes an obligation hidden by
the previous partial sum. Agreement of charts and independent local derivations
supports this bounded algebraic result. Action, input poles, frame definitions,
symbolic software and AI authorship are shared-error risks. The director's
education stays voluntary, concurrent and nonblocking.

Authorityv113/34of39 is unchanged. Full source/Slavnov restoration,E5/A5,QAP,
finite/IR,measure and anomaly freedom remain unqualified. HB1/C5 blocked,
C1_GS uncalculated,flavor paused. Preserve prior failures/exclusions,scalar
quantum-control warning,custodyexit2/seven. No accepted input/benchmark/
foundation,protected evidence or remote action changed.
