# Ordinary g2 gauge-source color pole V1

Baseline09bee191c8ff4c14ea9ec40c94f2d90402f36ccc. The complete single-source
frontier leaves only SB*F at ordinary g2 for JB*partial C. The paired
general-momentum units are qualified at d4bca22. The V172 lineage check
preserves the original source convention: no extra spatial metric.

Question: calculate all45² ordered real-source/ghost color coefficients of
this ordinary g2 ultraviolet pole, retaining the full H/M reference widths.
Target is J_B,mu partial_mu C in common hbar*g10²/(32pi² epsilon_UV) units,
with no extra factorial. This is an off-shell reference pole, not an observable.
Keep the distinction from the already measured g*xi source pole. No desired
Ward or Slavnov identity may supply the answer.

Freeze source, declared inputs and the completed unit receipt before execution.
Reconstruct all4 Lorentz copies of the literal source, including its real dual
chart; prove the linear source has no quantum Hessian in this bubble. Extract
the complete qualified GF derivative matrices after preserving the original
IBP current and all4 Lorentz checks. Primary uses literal action pullback and
geometry; replay rebuilds the physical10 commutators and GF interactions and
checks its own literal source. Compare complete source/Fa/Fc tensors and the
entire45² coefficient matrix, not just a favorable subblock.

Use U_a=(3-W)/2,U_C=-(3+W)/2 with the current-reduced Fa/Fc; the qualified
all-placement identity U_a+U_B+U_C=0 justifies that exact IBP reduction. W_H
and W_M are formal reference widths. Check the full4-Lorentz vector/auxiliary
quadratic principal symbol and inverse including both mixed directions and
zero auxiliary self-edge. Retain all45 ghost directions. Existing declared
real-width substitution W_M=xi,W_H=eta_H is a convention reuse, not selection
of physical gauge values; keep the formal matrix too. The result must not
read an old pole/candidate, known Gamma, required identity or peer result.

Check skew/reality/dual maps, all45² source slots, a Casimir decomposition
derived from the actual matrices and all12 constant H covariance identities.
Controls omit either vector sector, omit external-ghost derivative terms,
and halve the two-word normalization; report any insensitivity honestly.
Do not assume any width cancels: report exact coefficient support. An
unavailable or failed premise stops the affected interpretation.

Two sequential read-only workers,300seconds after imports, sampled8GiB and
>=350MiB available commit. This cap allows literal all4 source pullbacks and
two independently constructed physical/GF tensor sets; no dense643-field
compiler or old integration rerun. Preserve complete native failures. Only
after paired agreement may a separately frozen dependent canonical export or
identity assessment proceed. This record does not adopt either operation.

Ceiling: complete selected action-derived color pole in the declared reference.
Not full source closure, quantum restoration, finite/IR/measure/QAP, anomaly
freedom or E5/A5. project_statev113/34of39 unchanged; HB1/C5 blocked,C1_GS
uncalculated,flavor paused. Earlier failures, scalar warning,custodyexit2/seven
preserved. No accepted input/benchmark/foundation or remote change. Shared
action/representations/helpers/UV assumptions/AI authorship limit independence;
the director's education stays voluntary, concurrent and nonblocking.
