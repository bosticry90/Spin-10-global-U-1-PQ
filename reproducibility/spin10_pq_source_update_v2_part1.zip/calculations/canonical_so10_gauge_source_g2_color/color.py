"""Literal source/GF tensors versus physical10 commutators; no target pole read."""
from pathlib import Path
from hashlib import sha256
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,ETA,canonical,decode_typed,cm,clean,IDS,H,M,adjoints,linear
from a10_e5_measured_functional_v3 import frames
from a10_e5_auxiliary_next import vertices as gf_inputs
from a10_e5_derivative_gauge import matrices,literal_f
WH,WM=s.symbols('reference_width_H reference_width_M',real=True)
read=lambda f:json.loads(f.read_bytes());digest=lambda f:sha256(f.read_bytes()).hexdigest()

def pack(A):return [[i,j,str(s.expand(z))] for (i,j),z in sorted(A.todok().items()) if s.expand(z)!=0]
def packed(As):return [pack(A) for A in As]

def source(w,sub,role):
    raw=decode_typed(read(PKG/f'frozen_a10_bv_master/{role}.json')['source_polynomial']);parts=[{} for mu in range(4)];linear_count=0
    for word,z in raw.items():
        J=[n for n,j in word if re.fullmatch(r'JB\d+_[0-3]',n)]
        if not J:continue
        assert len(J)==1;mu=int(J[0][-1])
        if len(word)==2:
            assert sum(len(j) for n,j in word)==1 and sum(n.startswith('C') for n,j in word)==1;linear_count+=1;continue
        assert len(word)==3 and all(not j for n,j in word) and s.Poly(z,g).monoms()==[(1,)]
        parts[mu][word]=s.Poly(z,g).coeff_monomial(g)
    assert linear_count==180 and sum(map(len,parts))==3544
    full=[];physical_counts=[]
    for mu,P in enumerate(parts):
        physical=canonical(w.replace(P,sub));physical_counts.append(len(physical));As=[s.zeros(45) for b in IDS]
        for word,z in physical.items():
            J=next(n for n,j in word if n.startswith('JBp'));B=next(n for n,j in word if n.startswith('Bp'));C=next(n for n,j in word if n.startswith('Cp'))
            assert J.endswith('_'+str(mu)) and B.endswith('_'+str(mu)) and all(not j for n,j in word)
            i=int(J[3:].split('_')[0]);b=int(B[2:].split('_')[0]);k=int(C[2:]);sign=w.mul(w.var(J),w.var(B),w.var(C))[word]
            As[b][i,k]+=z/sign
        full.append([cm(A) for A in As])
    assert all(v==full[0] for v in full)
    return full[0],{'linear_source_no_two_quantum_legs':linear_count,'raw_cubic_all4':sum(map(len,parts)),'physical_cubic_counts_by_mu':physical_counts,'all4_group_tensors_identical':True}

def reference():
    q=s.Matrix(s.symbols('gs_color_q0:4',real=True));eta=s.diag(*ETA);up=eta*q;Q=(q.T*up)[0];width=s.Symbol('gs_color_W',real=True)
    K=(-Q*eta+up*up.T).row_join(s.I*up).col_join((-s.I*up.T).row_join(s.Matrix([[width]])))
    D=(-eta/Q+(1-width)*q*q.T/Q**2).row_join(s.I*q/Q).col_join((-s.I*q.T/Q).row_join(s.zeros(1)))
    assert cm(K*D)==cm(D*K)==s.eye(5) and D[4,4]==0
    for W in [WH,WM]:assert not any(s.cancel(v) for v in (K*D-s.eye(5)).subs(width,W))
    return {'full4_vector_auxiliary_symbol_inverse':True,'both_mixed_edges_retained':True,'auxiliary_self_edge_zero':True,'formal_widths_not_gauge_values':True}

def contract(S,Fa,Fc,indices):
    result=s.zeros(45)
    for b in indices:
        W=WH if b in H else WM
        result+=S[b]*((3-W)*Fa[b]-(3+W)*Fc[b])/2
    return cm(result)

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):raise PermissionError('ACTUAL_GAUGE_SOURCE_COLOR_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('ACTUAL_GAUGE_SOURCE_POLE_GAMMA_PREDICTION_PEER_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return value
    w,sub,back,src,anti,Cinv,Cphys=stage('real_fields_source_dual_maps',lambda:frames(role))
    S,si=stage('all4_literal_JB_B_C_pullbacks',lambda:source(w,sub,role))
    other,V,maps,gi=gf_inputs(role,stage);assert maps[:4]==(src,anti,Cinv,Cphys)
    Fa,Fc,unusedX,unusedL=stage('qualified_complete_GF_derivative_placements',lambda:matrices(other,V))
    assert gi['all4_derivative_Lorentz_copies_checked'] and len(gi['retained_IBP_current'])==4
    if role=='primary':f=stage('literal_geometry_pullback',lambda:literal_f(role,maps,other))
    else:
        parent=stage('physical10_parent_commutators',adjoints);EM,EH=maps[4:6];E=s.Matrix.hstack(EH,EM)
        f=stage('orthonormal_adjoint_representation',lambda:[cm(E.T*linear(E[:,b],parent)*E) for b in IDS])
    assert S==f
    for b in IDS:
        assert cm(f[b]+f[b].T)==s.zeros(45) and all(clean(z-s.conjugate(z))==0 and not z.has(s.Float) for z in f[b])
        assert Fa[b]==(f[b] if b in H else s.Matrix.hstack(s.zeros(45,12),f[b][:,12:]))
        exp=s.zeros(45)
        if b in H:exp[12:,12:]=-f[b][12:,12:]
        assert Fc[b]==exp
    ref=stage('full_reference_inverse',reference)
    if role=='primary':pole=stage('all45_by45_ordered_color_matrix',lambda:contract(S,Fa,Fc,IDS))
    else:
        pole=s.zeros(45)
        for i in IDS:
            for k in IDS:
                pole[i,k]=s.expand(sum(S[b][i,a]*((3-(WH if b in H else WM))*Fa[b][a,k]-(3+(WH if b in H else WM))*Fc[b][a,k])/2 for b in IDS for a in IDS if S[b][i,a]))
        pole=cm(pole)
    PH=s.diag(*([1]*12+[0]*33));PM=s.eye(45)-PH
    CH=cm(-sum((f[b]*f[b] for b in H),s.zeros(45)));CM=cm(-sum((f[b]*f[b] for b in M),s.zeros(45)));CF=cm(CH+CM)
    casimir=CF[0,0];assert CF==casimir*s.eye(45) and casimir>0
    comparator=cm(-((3-WH)*CH*PH/2+3*CH*PM+(3-WM)*CM*PM/2));assert comparator==pole
    assert all(cm(f[h]*pole-pole*f[h])==s.zeros(45) for h in H)
    h_only=contract(S,Fa,Fc,H);m_only=contract(S,Fa,Fc,M);zeros=[s.zeros(45) for b in IDS]
    no_external_derivative=contract(S,Fa,zeros,IDS)
    controls={'omit_H_vector_sector':m_only!=pole,'omit_M_vector_sector':h_only!=pole,'omit_external_ghost_derivative':no_external_derivative!=pole,'one_word_only':cm(pole/2)!=pole}
    assert all(controls.values())
    etaH=s.Symbol('eta_H',real=True);bound=cm(pole.subs({WM:xi,WH:etaH},simultaneous=True))
    coefficient_support={name:len(cm(pole.diff(var)).todok()) for name,var in [('H',WH),('M',WM)]}
    result={'schema':'ACTUAL_ORDINARY_G2_GAUGE_SOURCE_COLOR_POLE_V1','route':role,'source_inventory':si,'GF_inventory':gi,'source_GF_real_maps_equal':True,
      'actual_S_equals_adjoint_f':True,'source_tensors':packed(S),'Fa_tensors':packed(Fa),'Fc_tensors':packed(Fc),'formal_pole':pack(pole),'bound_pole':pack(bound),
      'complete_ordered_source_ghost_positions':2025,'nonzero_formal_positions':len(pole.todok()),'formal_width_coefficient_support':coefficient_support,
      'CH':pack(CH),'CM':pack(CM),'full_adjoint_Casimir':str(casimir),'Casimir_formula_agrees_all2025':True,'all12_constant_H_covariance':True,'reference':ref,'negative_controls':controls,
      'width_substitution':{'reference_width_M':'xi','reference_width_H':'eta_H'},'new_physical_gauge_chosen':False,'source_extra_spatial_metric_inserted':False,
      'canonical_node_exported':False,'known_Gamma_or_desired_identity_or_peer_read':False,'full_source_Slavnov_E5_A5_or_finite_IR_claim':False,
      'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
