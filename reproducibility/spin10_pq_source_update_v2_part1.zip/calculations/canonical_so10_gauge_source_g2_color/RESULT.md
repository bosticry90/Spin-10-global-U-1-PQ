# Complete selected ordinary g2 gauge-source color pole

The literal-action and physical10-commutator routes agree on the complete
45-by45 ordered gauge-source/ghost coefficient matrix and all source/Fa/Fc
tensors. There are75 nonzero formal-width positions and1950 exact zeros in
this selected order. All four Lorentz copies of the source are checked;
their color tensors coincide. No extra spatial metric is inserted.

This supplies a previously missing action-derived ultraviolet coefficient.
It is distinct from the older g*xi source pole. It is an off-shell reference
calculation, not a physical gauge-independent observable or a complete
quantum-consistency result.

For an orthonormal real adjoint basis, define f_b by [T_b,T_k]=f_b,ik T_i,
C_H=-sum_(b in H) f_b² and C_M=-sum_(b in M) f_b². P_H/P_M are the12/33
projectors in this basis. The measured matrices obey C_H+C_M=8 I_45. The
complete calculated matrix can be written

\[
\mathcal P=-\frac{3-W_H}{2}C_HP_H-3C_HP_M
             -\frac{3-W_M}{2}C_MP_M.
\]

The density is hbar*g10²/(32pi² epsilon_UV) times
sum_(mu,i,k) JB_i,mu P_ik partial_mu C_k. The compact formula is checked
against every component, rather than used to choose an answer. The full
serialized matrices in primary_result.json and replay_result.json retain
the exact radicals, signs and implicit zeros.

The source matrix for each internal vector is the actual f_b. The GF matrices
are reconstructed with the qualified current reduction: Fa_b=f_b for b in H
and f_b P_M for b in M; Fc_b=-f_b P_M for b in H and zero for b in M. The
pole follows from sum_b S_b[U_a(W_b)Fa_b+U_C(W_b)Fc_b], using the independently
qualified general-momentum factors in the
[unit result](../canonical_so10_gauge_source_derivative_units/RESULT.md).
Its full derivative-placement identity justifies the retained IBP reduction.

Width dependence survives. W_H has18 nonzero coefficient positions and W_M
has57; the W_H dependence cancels on the M columns in the compact expression.
The inherited declared real substitutions W_M=xi,W_H=eta_H are applied
symbolically and preserved beside the formal matrix. No gauge value or
accepted physical input has been selected. The full4-Lorentz vector/auxiliary
principal symbol and inverse are checked, including both mixed directions
and the zero auxiliary self-propagator.

The raw source has3544 nonlinear cubic terms over all4 Lorentz copies; the
real pullback has1674 per copy. The180 linear source terms have fewer than
two quantum legs and no bubble Hessian. The complete GF construction checks
all4 Lorentz copies and retains the original four IBP currents. All12 constant
H covariance identities hold for the resulting matrix. These are constant
color-covariance checks, not the complete local Ward/Slavnov identities.

Omitting H vector propagation, M vector propagation, the external-ghost
derivative term, or one of the two Born/Wick words each changes the answer.
Both workers were denied peer results, old poles/candidates, known Gamma and
required identities. The replay independently constructs physical commutators
and GF interactions and checks its own literal source. The classical primary
BV architecture used to define the chart is a disclosed shared dependency.

The primary and replay completed in43.572 and52.692 seconds after imports,
with sampled private peaks113905664 and149729280 bytes. No failed execution
occurred in this increment; both are below the300-second/8GiB caps. The
separate validation checks all2025 positions, tensor agreement, compact
identity, covariance, controls, UTF-8 links, hashes and protected files. It
does not rerun the old loops or establish experimental validity.

Track B: the calculation transfers qualified momentum factors into actual
action tensors and checks the complete result through a different group
construction. Shared action/representation definitions, helpers, UV reference
assumptions, software and AI authorship remain common-error risks. The
earlier avoidable Lorentz-history detour is preserved in its
[audit](../canonical_so10_gauge_source_lorentz_audit/RESULT.md), rather than
presented as a new physical error. Education remains voluntary, concurrent
and nonblocking.

Next freeze a dependent canonical pullback and exact local background-Ward
assessment of this new node. Preserve all4 source index conventions and
primal/dual roundtrips, prove absence of this g2 derivative node from the
current recipe, then add it once in a new version. Do not infer local Ward
closure from the constant H checks or fit a companion to cancel a remainder.

No canonical node or new known functional was exported here. The saved
Gamma92236 and its qualified zero background Ward remain unchanged as saved
objects. Full source/Slavnov restoration,E5/A5,QAP,finite/IR,measure and anomaly
freedom remain unqualified; HB1/C5 blocked,C1_GS uncalculated,flavor paused.
Authorityv113/34of39,old failures,scalar warning,custodyexit2/seven preserved.
No accepted benchmark/input/foundation,protected evidence or remote change.
