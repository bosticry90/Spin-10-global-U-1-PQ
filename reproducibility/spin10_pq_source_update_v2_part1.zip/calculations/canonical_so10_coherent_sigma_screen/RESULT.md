# Coherent Sigma contact failure; complete gauged amplitude unqualified

The primary finds a canonically normalized coherent state in an ACTUAL
physical scalar subspace for which

```
|<Omega|a0_contact|Omega>| >=7 >1/2.
```

This is a lower bound on a particular contact expectation and hence on the
full scalar CONTACT operator norm, not its largest eigenvalue. It applies
to the SAME eta=eps^3 curve for0<eps<1/10, intersected with its previously
qualified sufficiently small-eps local-mass regime. No parameter point or
new family was selected. Qualification requires the actual
[independent receipt](validation_receipt.json), resource records and raw
Git checks under the [authorized contract](RECORD.md).

The contact screen FAILS by at least a factor14 relative to1/2. The actual
unbroken massless gauge current is also nonzero, leaving the unregulated
full J=0 amplitude infrared unsafe. Therefore this result does NOT establish
a full gauged physical exclusion. No g=0, gauge choice, IR subtraction or
new physical input is adopted to close that gap.

The [joint necessary-set theorem](../canonical_so10_joint_necessary_region/RESULT.md)
remains valid for its listed filters. This additional test was absent from
those filters; its contact failure does not falsify their derivation. The
old eta=3/10 domain exclusion and every previous negative result are retained.

## From a global potential bound to one coherent expectation

The [qualified pure-Sigma certificate](../canonical_so10_sigma_norm_bound/RESULT.md)
gives V_Sigma>=(pi/8)N^2 on the curve for0<eps<1/10. Its Sigma coefficients
are unchanged by the new eta scaling because phi=0 removes that interaction.
All four quartics enter the inherited proof; this is not an uncancelable
Sigma1 term inferred while ignoring the other three coefficients.

In independent canonical complex coordinates N=2sum|z|^2. In real canonical
coordinates X, N=X^T X; raw coordinates carry the actual b^2=3/160 factor.
For a d-dimensional real physical subspace with orthogonal projector Q,
the normalized Fock state is

```
|Omega_Q>=(1/sqrt(2d))*sum Q_ij a_i^dagger a_j^dagger|0>,
<Omega_Q|Omega_Q>=Tr(Q^2)/d=1.
```

Let Delta_Q be its field-space Laplacian and let the sphere average have
unit radius in that subspace. Full symmetric polarization gives

```
sphere_average(V)=Delta_Q^2 V/[8d(d+2)],
<Omega_Q|a0_contact|Omega_Q>
 =-Delta_Q^2 V/(32pi*d)
 =-(d+2)*sphere_average(V)/(4pi).
```

Thus the GLOBAL potential lower bound implies a negative coherent contact
expectation of magnitude at least(d+2)/32. It says nothing about every
scattering eigenvalue. In particular the positive quartic(X^2-Y^2)^2 has
an indefinite pair matrix; that explicit adverse reference rejects the
false general positivity-to-unitarity inference.

## Physical projection is explicit

All45 Lie-generator actions on the actual vacuum are constructed. The real
Sigma orbit rank is21, its conservative complex span has rank11, and the
ACTUAL full Phi/Sigma mixed orbit has real rank33. Phi's nonzero vacuum is
included, not silently replaced by zero.

The4 neutral Sigma basis vectors of the actual Higgs problem generate a
4-complex-dimensional closed SO(4) weak space. Remove it together with the
complex gauge span. The total removed complex rank is15, leaving111 complex
or222 real directions. The Hermitian/idempotent projector annihilates every
actual gauge image, the Sigma vacuum/PQ component and the full weak space.
It therefore excludes the Sigma components of ALL tuned Higgs modes,
independently of eps. With all other field components zero it embeds in
the full kinetic physical scalar space, orthogonal to the whole mixed orbit.
The qualified local-mass theorem supplies positive curvature there for its
sufficiently small eps>0 regime. No dimension-only Goldstone removal is used.

For d=222 the lower bound is exactly7. No dense328-field pair matrix or
repeated old invariant/spectrum calculation is required.

The action's29 monomials are inventoried by degree and field content.
Only lambdaSigma1..4 contribute to four external Sigma legs; all four
are already included in the complete potential bound. Cubic/lower-degree
terms have zero fourth derivative, and eta,z4,zK and portals have other
external field content. They can connect other pair sectors but cannot
change this CONTACT expectation. A shadow cancellation control prevents
extending that statement to an incomplete action or omitted gauge operator.

## The gauge/IR gate does not pass

The actual generator T=J01-J23 annihilates the FULL vacuum and hence is
unbroken. Its projected real current has squared Frobenius norm268 with
Tr(T^T T)=4. This states the convention; it is not an adopted value of g.
Every identical-state diagonal current vanishes by antisymmetry, while
offdiagonal elastic currents survive. Both t/u exchanges must be kept.

The leading conserved real-current kinetic vertex, using a consistent
all-incoming Fourier convention, produces a crossed kernel proportional to

```
-(q+3)/(q-1-2rho), q=cos(theta), rho>0.
```

Here rho is an ABSTRACT positive mass-ratio control, not an assigned mass
or regulator for the actual massless generator. Its single crossed angular
integral is

```
I(rho)=(4+2rho)*log((1+rho)/rho)-2,
I(rho)/log(1/rho) ->4 as rho->0+.
```

The u channel follows by q->-q. The leading isolated vector contribution
is nonzero and has the opposite sign to the negative scalar-contact
expectation in this convention. No cancellation of the COMPLETE amplitude
is demonstrated. The massless boundary of the unregulated angular integral
diverges; silently using a finite rho or dropping the gauge term would
change the physical problem.

[Goodsell–Staub, equations2–5 and appendix B](https://arxiv.org/pdf/1805.07306)
anchor pair normalization and distinguish gauge exchange from the scalar
contact approximation. Their neglect of gauge couplings is an additional
assumption, not a consequence of high energy. Their simplified software
setting also does not supply this model's colored scattering calculation.
No complete gauge/Goldstone, inclusive observable, long-range subtraction
or infrared-safe partial-wave prescription is established here. Physical
qualification stops at this precise missing premise.

## Verification, scientific decision and authority

The primary uses moving-index actions and a complex Gram projector.
The independent route uses output-index actions, exact rational real rank
and uniqueness of the orthogonal projector. It checks actual weak closure,
all45 mixed orbit images, kinetic factors and the complete action inventory.
Gaussian moments and all55 degree-four reference monomials in2,3,4 variables
check the sphere/derivative relation independently of the primary O(N)
pair controls. The kinetic-current expansion, crossed terms and IR behavior
are checked separately. No agreement of AI implementations supplies missing
physical assumptions or external endorsement.

One setup-only attempt referenced a nonexistent predecessor receipt. It
launched NO native scientific worker. Its failed source and diagnostic are
preserved externally; corrected preparation binds the actual existing
record. The two approved scientific roles remain primary and verifier.
The final receipt must count that preparation failure separately and require
complete successful native/resource/byte checks. No fresh replay pair exists.

Do not promote this curve to a perturbative benchmark. It has a strong
scalar-contact failure even though the earlier selected conditions coexist.
Before any further parameter recovery, make an explicit research decision
about the perturbativity test and its physical/IR interpretation. Treating
scalar-contact perturbativity as a separate benchmark requirement would
reject this curve under THAT requirement; it would not prove inconsistency
of the full gauged theory. A complete physical scattering claim needs its
missing input/prescription justified. Neither a new family nor another
adjustable coefficient is automatically authorized by this warning.

Full variable-eta feasibility, full328 BFB, quantum control and physical
predictions remain unresolved. Preserve state/README,authority34/39,custody
exit2/seven,all prior successes/failures,eta=3/10 exclusion,quartet failure,
E5/A5/HB1/C5/C1_GS boundaries and flavor pause. No parameter search,
benchmark,physical input,quantum work,remote action or outreach. Shared
action/representation/global-bound premises,data,software and analyst are
limits. Science/AI objectives equal; education voluntary/nonblocking.
The broad investigation remains incomplete.
