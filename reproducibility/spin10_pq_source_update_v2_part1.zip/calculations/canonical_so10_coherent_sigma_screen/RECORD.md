# Authorized coherent Sigma screen V1 — prospective frozen contract

The director selected “Authorize bounded coherent Sigma screen” for the
committed COHERENT_SIGMA_SCATTERING_SCOPE_PROPOSAL_V1.md. Actual baseline
2ff007a33a2ee5fb9263efb1d364ac041ced0c15 is clean, no matching workers,
statev113/34of39. TWO sequential native roles,120seconds after imports and
8GiB sampled private allocation each; directly observed available commit
at least350MiB before launch. No extra retry or new parameter/field search.

Question: does a coherent canonical two-particle channel impose a new
necessary scattering obstruction on the SAME eta=eps^3 curve? Do not
modify that curve or choose eps. Reuse the qualified global pure-Sigma
bound V>=pi*N^2/8 for0<eps<1/10 after checking exact family membership.
Derive, do not assume, its relation to a specific scattering expectation.
Potential positivity does not imply a positive scattering matrix.

Primary: construct all45 actual Sigma gauge images and mixed Phi/Sigma
orbit rank from the fixed vacuum. Build a conservative complex orthogonal
complement, removing the complex gauge span AND the full Sigma weak space
generated from the actual4 neutral Sigma basis vectors under SO(4).
Verify closure, actual orbit annihilation, the PQ/vacuum component, kinetic
normalization, projector idempotence/Hermiticity and actual dimension. This
fixed representation subspace is independent of eps and orthogonal to every
tuned light-Higgs Sigma component. It embeds in the full physical scalar
space because its other field components vanish. No dimension-only removal.

Derive coherent pair normalization, the double trace and spherical fourth
moments in this canonical physical subspace. Include identical factors and
N=2sum|z|^2=sum X_a^2. Prove a bound on that ONE expectation; do not infer
that every scattering eigenvalue or every field direction shares it. Check
O(N) references and a positive quartic with an indefinite pair matrix.
Inventory all29 action terms and retain every pure-Sigma contribution;
absence of mixed terms must follow from actual degree/support data.

Gauge/IR audit: exhibit an ACTUAL unbroken generator with nonzero projected
elastic current, retaining both crossed channels even though identical
s-channel currents vanish. Derive its leading conserved-vector kinematic
kernel from the real kinetic current with a consistent amplitude sign.
An abstract positive mass-ratio symbol may test the angular integral and
massless boundary; it is not an adopted regulator or gauge boson mass.
Do not choose g,xi,IR subtraction or a gauge prescription. Compare the
normalization/gauge assumptions with Goodsell–Staub1805.07306 eqs2–5,
appendix B18/B21; do not import their gauge-neglect assumption.

If an unregulated massless current leaves the physical J=0 amplitude
undefined, STOP physical qualification there. A large CONTACT expectation
then remains a bounded scalar-contact perturbativity failure/warning,
NOT a proof of full gauged exclusion. A cancellation or IR treatment must
not be invented. No new gauge/Goldstone compiler or quantum calculation.

Independent role: reconstruct all actual45 images with output-index rather
than moving-index actions. Prove the real complement/projector through
independent exact rank and uniqueness, not matching a dimension. Check weak
closure/light support, all canonical factors, full29-term membership and
every claimed lower bound. Derive sphere moments by independent Gaussian
moments or complete polynomial contraction and check normalized pair maps.
Verify the gauge current and both crossed angular terms independently.

Controls must detect incorrect Sigma metric, lost identical/coherent
multiplicity, omitted mixed support, unsupported suboperator exclusion,
dimension-only projection, positivity-versus-unitarity confusion and omitted
massless elastic current. A false large contribution can be canceled by a
shadow term; the complete action inventory must rule out that assumption
only for the contact contribution actually bounded. No full-amplitude lower
bound without all physical prerequisites.

Expected outcomes: gauge-qualified decisive physical bound, contact-only
failure with explicit physical gap, or inconclusive. The actual computation
determines the dimension and coefficient. Preserve any mathematical failure
or resource limit; no silent truncation/repair. Freeze source/input hashes,
UTF-8/AST before primary; reports and independent source before verifier.
Read-only workers, complete captures, independent receipt and raw staged/
committed checks required. Zero fresh byte-identical pairs. Old global
invariant and mass results are inherited, not rerun or external endorsement.

Preserve the qualified joint necessary-set theorem even if this additional
screen fails. No full variable-eta/Spin(10) exclusion, finite point, adopted
benchmark, new input, expanded search, quantum work or automatic next family.
Keep state/README,34/39,custody exit2/seven,old eta=3/10 exclusion,all evidence,
quartet failure,E5/A5 and HB1/C5/C1_GS gaps and flavor pause. Equal science/AI
objectives; education voluntary/nonblocking. Shared physical assumptions,
inherited tensors,software and analyst limit independence. Goal incomplete.
