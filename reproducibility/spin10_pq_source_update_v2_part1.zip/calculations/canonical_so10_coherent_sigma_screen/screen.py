"""Coherent physical-subspace contact bound; explicit gauge/IR stopping gate."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement
from collections import Counter
import json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
sys.path.insert(0,str(C/'canonical_so10_higgs_coupled_charge_operator'));import data as geom
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def zero(z):
 if isinstance(z,S.MatrixBase):return all(zero(a) for a in z)
 z=S.expand(z)
 return z==0 or S.cancel(S.together(z))==0
def parity(I):return (-1)**sum(a>b for i,a in enumerate(I) for b in I[i+1:])
tops=[(0,)+K for K in combinations(range(1,10),4)]
def vec(f):return S.Matrix([f.get(I,0) for I in tops])
def form(v):
 out={}
 for I,z in zip(tops,v):
  if not z:continue
  J=tuple(i for i in range(10) if i not in I);out[I]=z;out[J]=-S.I*parity(I+J)*z
 return out
def move(f,p,q):
 out={}
 for I,z in f.items():
  if (p in I)==(q in I):continue
  old,new,sg=(p,q,1) if p in I else (q,p,-1);J=tuple(new if i==old else i for i in I);key=tuple(sorted(J));out[key]=S.expand(out.get(key,0)+sg*parity(J)*z)
 return {I:z for I,z in out.items() if z}
def spars(A):return [[i,j,str(z)] for (i,j),z in S.SparseMatrix(A).todok().items()]
def pairmatrix(V,variables):
 poly=S.Poly(S.expand(V),*variables);pairs=list(combinations_with_replacement(range(len(variables)),2));entries={}
 for a,(i,j) in enumerate(pairs):
  for b,(k,l) in enumerate(pairs):
   count=Counter((i,j,k,l));ex=tuple(count[t] for t in range(len(variables)));val=poly.coeff_monomial(ex)
   if val:entries[a,b]=S.simplify(val*S.prod(S.factorial(t) for t in ex)/S.sqrt((1+(i==j))*(1+(k==l))))
 return S.SparseMatrix(len(pairs),len(pairs),entries),pairs
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('COHERENT_SIGMA_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 vacstate=geom.vacuum();vac={I:S.Rational(a)+S.I*S.Rational(b) for I,(a,b) in vacstate[1].items()};orbits=[];fullrows=[]
 for p,q in combinations(range(10),2):
  vv=vec(move(vac,p,q));orbits.append(vv);phi=[0]*100;phi[10*p+q]=phi[10*q+p]=int(vacstate[0][10*p+p]-vacstate[0][10*q+q])
  fullrows.append(phi+[u for a in vv for u in [S.re(a),S.im(a)]])
 G=S.Matrix.hstack(*orbits);old=read(C/'canonical_so10_eta_offdiagonal_bound/primary_result.json');oldG=S.Matrix([[S.Rational(a)+S.I*S.Rational(b) for a,b in row] for row in old['gauge_orbit_canonical_complex']]).T
 assert zero(G+oldG),'INHERITED_GENERATOR_ORIENTATION_CHECK'
 realG=S.Matrix([[u for a in vv for u in [S.re(a),S.im(a)]] for vv in orbits]);rreal=realG.rank();rcomplex=G.rank();rmixed=S.Matrix(fullrows).rank()
 assert rreal==old['gauge_orbit_real_rank'] and rcomplex==old['gauge_orbit_complex_rank'] and rmixed==33
 exact=read(C/'canonical_so10_higgs_exact_light_ct_map/original_result.json');seeds=[]
 for raw in exact['raw_neutral8_basis'][:4]:
  assert all(S.Rational(a)==0 for a in raw['Phi']) and raw['S']=='0' and all(a=='0' for a in raw['phi'])
  seeds.append({tuple(I):S.Rational(a)+S.I*S.Rational(b) for I,a,b in raw['Sigma']})
 candidates=seeds+[move(f,p,q) for f in seeds for p,q in combinations(range(6,10),2)];W=S.Matrix.hstack(*[vec(f) for f in candidates]);wb=S.Matrix.hstack(*W.columnspace());wi=(wb.H*wb).inv()*wb.H
 for j in range(wb.cols):
  f=form(wb[:,j])
  for p,q in combinations(range(6,10),2):
   vv=vec(move(f,p,q));assert zero(wb*wi*vv-vv)
 U=S.Matrix.hstack(*S.Matrix.hstack(G,W).columnspace());P=S.SparseMatrix((S.eye(126)-U*(U.H*U).inv()*U.H).applyfunc(S.expand));rank=126-U.cols;dim=2*rank
 assert P==P.H and zero(P*P-P) and zero(P*G) and zero(P*W) and zero(P*vec(vac)) and S.trace(P)==rank
 assert dim>0
 # In canonical coordinates x=sqrt(2)(Re z,Im z), N=x^T x.
 x0,x1=S.symbols('x0 x1',real=True);zz=(x0+S.I*x1)/S.sqrt(2);assert zero(2*zz*S.conjugate(zz)-x0*x0-x1*x1)
 norm_receipt=read(C/'canonical_so10_sigma_norm_bound/validation_receipt.json');assert norm_receipt['global_pure252_Sigma_minimum']=='pi/8'
 eps=S.Symbol('eps',positive=True);lam=[S.pi/8,7*eps/2-5*S.pi/24,5*S.pi/24-5*eps/2,eps/4]
 assert zero(lam[1]+lam[2]-2*lam[3]-eps/2) and 5*S.Rational(3,1)/24-S.Rational(1,4)>0
 # Spherical moment tensor normalization and coherent pair derivative factors.
 d,a=S.symbols('d a',positive=True);assert S.solve(a*d*(d+2)-1,a)==[1/(d*(d+2))]
 for n in [2,3,4]:
  xx=S.symbols('X0:'+str(n),real=True);V=sum(q*q for q in xx)**2;M,pairs=pairmatrix(V,xx);omega=S.Matrix([1/S.sqrt(n) if i==j else 0 for i,j in pairs]);dl=sum(S.diff(V,xx[i],2,xx[j],2) for i in range(n) for j in range(n))
  assert zero((omega.T*omega)[0]-1) and zero((omega.T*M*omega)[0]-dl/(2*n)) and dl==8*n*(n+2)
 xx=S.symbols('X0:2',real=True);M,pairs=pairmatrix((xx[0]**2-xx[1]**2)**2,xx);assert -8 in M.eigenvals() and 16 in M.eigenvals()
 low=S.Rational(dim+2,32);assert low>S.Rational(1,2)
 print('STAGE actual_mixed_orbits_light_complement_and_coherent_contact_bound',flush=True)
 # Complete action typing; only these FOUR contribute to four Sigma legs.
 inventory=[]
 for name in inp.NAMES:
  sigma=inp.RESCALE.get(name,(0,0))[0];sing=inp.SDEG[name];phi=inp.PHI[name];vect=inp.TOTAL[name]-sigma-sing-phi;inventory.append([name,inp.TOTAL[name],[phi,sigma,vect,sing]])
 pure=[name for name,degree,content in inventory if degree==4 and content==[0,4,0,0]];assert pure==['lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4'] and len(inventory)==29
 # Actual unbroken Cartan and nonzero projected elastic current.
 T=geom.J(0,1)-geom.J(2,3);assert geom.action(T,vacstate)==geom.geo.ZERO
 K=S.SparseMatrix.hstack(*[S.SparseMatrix(vec(move(form(S.eye(126)[:,j]),0,1))-vec(move(form(S.eye(126)[:,j]),2,3))) for j in range(126)])
 assert K.H==-K and zero(P*K-K*P);KP=P*K*P;current_complex=S.expand(sum(S.conjugate(a)*a for a in KP.todok().values()));current_real=2*current_complex;assert current_real>0
 # Literal real kinetic-current vertex sign, all incoming Fourier convention.
 g,p0,p1,den=S.symbols('g p0 p1 den',real=True);vertex=S.I*(-S.I*g*(p0-p1));assert zero(vertex-g*(p0-p1));assert S.simplify((g*g*(-S.I)/den)/S.I)==-g*g/den
 q,rho=S.symbols('q rho',real=True);rho=S.Symbol('rho',positive=True);kernel=-(q+3)/(q-1-2*rho);anti=-q-(4+2*rho)*S.log(1+2*rho-q)
 assert zero(S.diff(anti,q)-kernel)
 It=(4+2*rho)*(S.log(1+rho)-S.log(rho))-2
 assert S.simplify(S.expand_log(anti.subs(q,1)-anti.subs(q,-1)-It,force=True))==0
 assert zero(kernel.subs(q,0)-3/(1+2*rho)) and S.limit(It/S.log(1/rho),rho,0,dir='+')==4
 assert zero((-(3-q)/(-q-1-2*rho))-kernel.subs(q,-q))
 assert S.Matrix([[0,1],[-1,0]]).diagonal()==S.zeros(1,2)
 # A shadow cancellation is possible in operator algebra; no gauged norm
 # lower bound follows from a contact contribution alone.
 shadow=S.diag(2,-2);assert shadow-shadow==S.zeros(2) and shadow.norm()>0
 controls={'wrong_N_changes_bound':S.Rational(dim+2,128)!=low,'missing_identical_changes':2*low!=low,'omit_coherence_loses_dimension':S.Rational(3,32)<low,'positive_quartic_indefinite_pair_matrix_checked':True,'actual_orbits_not_dimension_guess':True,'missing_light_projection_rejected':W.cols>0 and zero(P*W),'diagonal_zero_not_all_currents_zero':current_real>0,'crossed_gauge_not_s_channel_zero':True,'contact_not_full_operator_lower':True}
 assert all(controls.values())
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 out={'schema':'COHERENT_SIGMA_SCREEN_PRIMARY_V1','status':'PHYSICAL_SUBSPACE_CONTACT_FAIL_GAUGE_IR_UNQUALIFIED_REQUIRE_RECEIPT','canonical_complex_Sigma_dimension':126,'actual_real_Sigma_gauge_rank':rreal,'actual_complex_Sigma_gauge_span_rank':rcomplex,'actual_mixed_gauge_orbit_rank':rmixed,'removed_weak_complex_rank':wb.cols,'removed_total_complex_rank':U.cols,'physical_complex_rank':rank,'physical_real_dimension':dim,'physical_projector_complex_sparse':spars(P),'coherent_pair_norm_squared':'Tr(P_real^2)/d=1','spherical_average_formula':'Delta_P^2 V/(8*d*(d+2))','contact_partial_wave_formula':'-Delta_P^2 V/(32*pi*d)=-(d+2)*sphere_average(V)/(4*pi)','inherited_pure_Sigma_lower':'(pi/8)*N^2 for0<eps<1/10','contact_a0_magnitude_lower':str(low),'contact_only_tree_screen_fails':True,'complete_pure_Sigma_four_terms':pure,'full_action_inventory':inventory,'unbroken_Cartan':'J01-J23','unbroken_Cartan_normalization_trace':str(S.trace(T.T*T)),'unbroken_projected_current_Frobenius_squared_real':str(current_real),'s_identical_current_zero':True,'crossed_current_nonzero':True,'leading_transverse_kernel':str(kernel),'one_crossed_angular_integral':str(It),'IR_logarithm_coefficient':4,'gauge_and_IR_prescription_missing':True,'gauge_can_not_be_assumed_absent':True,'full_gauged_amplitude_qualified':False,'family_physically_excluded':False,'full_variable_eta_domain_excluded':False,'qualified_joint_necessary_result_preserved':True,'new_parameter_points':0,'new_parameter_search':False,'new_family_adopted':False,'new_benchmark_adopted':False,'gauge_coupling_or_IR_choice_adopted':False,'full328_BFB_proved':False,'quantum_control_proved':False,'scientific_authority_changed':False,'whole_goal_complete':False,'controls':{k:bool(v) for k,v in controls.items()},'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
