# Distinguish the momentum tuple from a validator file path

The independent V1 validator passed its actual-input and separated UV/IR/
mass checks, then exited1 at the full kernel momentum check: its main routine
had reused p for a Path, shadowing the module's momentum tuple. The TypeError
occurred before a complete validation receipt. Preserve the original source,
snapshot, preparation, controller and full capture. Both completed scientific
workers are unchanged and reused; no physics result is accepted by that failure.

V2 uses a distinct momentum-tuple alias in those polynomial checks. No
coefficient, domain, kernel, old pole, hash requirement, tolerance or resource
bound changes. Keep the full invariant and all10 momentum tests,2025-position
zero proof, complete input/prescription audits and source-coverage comparison.
New V2 frozen validator/controller/preparation under AGENTS delegation;
unchanged120s/8GiB/minimum350MiB available commit. No old loops or actual
workers are rerun. This is an avoidable programming failure, not a scientific
contradiction; retain it as Track B evidence rather than erase the cost.

RESULT.md remains the unchanged mathematical report; its no-failed-worker
statement applies to the two scientific routes. There is now one failed
validator. Qualification requires the completed V2 default receipt and local
committed-byte checks. All scientific/physical/authority limitations remain.
