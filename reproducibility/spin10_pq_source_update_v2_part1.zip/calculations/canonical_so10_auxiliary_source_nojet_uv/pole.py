"""Separated UV residues for complete massless JL*C power-support families."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from functools import lru_cache
import json,os,re,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
eps=s.Symbol('epsilon_UV',real=True);R2,M2,P2,UV2,mu2=s.symbols('R2 Maux2 P_E2 Lambda2 mu_DR2',positive=True);x=s.Symbol('x',positive=True)
g,xi=s.symbols('g10 xi');k=s.symbols('k0_ag0:4');p=s.symbols('p0_ag0:4');Q,Rp,Rm=s.symbols('K2_ag Rp2_ag Rm2_ag',nonzero=True);S=s.Symbol('p_M2');A,B,C=s.symbols('A B C');D=s.Symbol('k_dot_p');sig=s.Symbol('sigma');eta=[1,-1,-1,-1]
qpoly=sum(e*a*a for e,a in zip(eta,k));dot=sum(e*a*b for e,a,b in zip(eta,k,p));spoly=sum(e*a*a for e,a in zip(eta,p));FOLDER=PKG/'frozen_a10_e5_auxiliary_ghost'
locals1={str(v):v for v in [g,xi,Q,Rp,Rm,*k,*p]}
@lru_cache(None)
def num(z):return s.sympify(z,locals=locals1)
@lru_cache(None)
def reduced(z):return s.cancel(z)
@lru_cache(None)
def pole(z):
    assert s.limit(eps**2*z,eps,0)==0,'HIGHER_POLE_NOT_ADMITTED'
    return s.simplify(s.limit(eps*z,eps,0))
def scalar_num(z,gp):
    poly=s.Poly(num(z),g,xi);assert set(poly.monoms())=={(gp,0)};out=poly.coeff_monomial(g**gp);assert not out.free_symbols and not out.has(s.Float);return out
def actual_inputs(role):
    invpath=ROOT/'calculations/canonical_so10_dimensionful_source_inventory'/('primary_result.json' if role=='primary' else 'replay_v2_result.json');qr=read(invpath.parent/'validation_receipt.json');assert qr['execution_state']=='COMPLETED' and qr['input_sha256'][str(invpath)]==digest(invpath);inventory=read(invpath);target=inventory['targets']['C_JL'];assert target['log_profiles']==0 and target['power_profiles']==2 and len(target['supported_families'])==2
    for label,v in target['supported_families'].items():
        assert v['g']==2 and v['explicit_xi']==0
        for row in v['profiles']:assert row['vertex_cd']==0 and row['raw_UV_degree']==row['remaining_UV_degree']==2 and row['propagator_mass_expansion']=='NONE' and not row['BB_edges'] and not row['scalar_edge_sectors']
    bv=read(PKG/f'frozen_a10_bv_master/{role}.json');counts=Counter();nonzero=set()
    if role=='primary':
        arrays=[]
        for row in bv['source_polynomial']:
            J=[n for n in row['word'] if re.fullmatch(r'J(b|L)\d+',n)]
            if J:arrays.append((int(re.search(r'\d+',J[0])[0]),[n for n in row['word'] if n!=J[0]],row['coefficient']))
    else:arrays=[(i,row['word'],row['coefficient']) for i in range(45) for row in bv['source_only_columns'][('b' if i<12 else 'L')+str(i)]]
    for i,ns,z in arrays:
        assert not any('__' in n for n in ns);nonzero.add(i);ghost=[n for n in ns if re.fullmatch(r'C\d+',n)]
        if len(ns)==2:assert len(ghost)==1 and any(re.fullmatch(r'(b|L)\d+',n) for n in ns);scalar_num(z,1);counts['SL']+=1
        else:assert len(ns)==3 and len(ghost)==2 and any(re.fullmatch(r'(bar|ub)\d+',n) for n in ns);scalar_num(z,2);counts['KL']+=1
    gf=read(PKG/f'frozen_a10_e2_transport/{role}.json');F=Counter()
    for row in gf['gauge_fixing_density']:
        ns=[n.partition('__')[0] for n in row['word']]
        if len(ns)!=3 or sum(bool(re.fullmatch(r'(bar|ub)\d+',n)) for n in ns)!=1 or sum(bool(re.fullmatch(r'C\d+',n)) for n in ns)!=1 or sum(bool(re.fullmatch(r'B\d+_[0-3]',n)) for n in ns)!=1:continue
        assert sum(len(n.partition('__')[2]) for n in row['word'])==1;scalar_num(row['coefficient'],1);Bname=next(n for n in ns if n.startswith('B'));mu=int(Bname[-1]);where=next(n.partition('__')[0] for n in row['word'] if '__' in n);tag='a' if re.fullmatch(r'(bar|ub)\d+',where) else ('c' if where.startswith('C') else 'B');F[tag+str(mu)]+=1
    data=read(PKG/f'frozen_a10_e5_full_hessian/{role}.json');assert data['complete_Hessian_and_reference_qualified'];ref=data['retained_reference'];names=ref['field_order'];assert len(names)==643 and ref['all643_inverse_directions_both_checked'];rp=s.symbols('p0_ref0:4');q2=rp[0]**2-sum(z*z for z in rp[1:]);R={};RR={};K=[{} for mu in range(4)];KK=[{} for mu in range(4)]
    for a,b,z in ref['reference_Green_raw_C3']['entries']:
        u,v=names[a],names[b]
        if re.fullmatch(r'C\d+',u) and re.fullmatch(r'(bar|ub)\d+',v):R[int(u[1:]),int(re.search(r'\d+',v)[0])]=reduced(s.sympify(z)*q2)
        elif re.fullmatch(r'C\d+',v) and re.fullmatch(r'(bar|ub)\d+',u):RR[int(v[1:]),int(re.search(r'\d+',u)[0])]=reduced(-s.sympify(z)*q2)
        elif re.fullmatch(r'B\d+_[0-3]',u) and re.fullmatch(r'(b|L)\d+',v):i,mu=map(int,u[1:].split('_'));K[mu][i,int(re.search(r'\d+',v)[0])]=reduced(s.sympify(z)*q2/(s.I*rp[mu]))
        elif re.fullmatch(r'B\d+_[0-3]',v) and re.fullmatch(r'(b|L)\d+',u):i,mu=map(int,v[1:].split('_'));KK[mu][i,int(re.search(r'\d+',u)[0])]=reduced(-s.sympify(z)*q2/(s.I*rp[mu]))
    assert R==RR and all(z==K[0] for z in K+KK) and all(not z.free_symbols and not z.has(s.Float) for z in list(R.values())+list(K[0].values()))
    return {'inventory_target':target,'source_counts':dict(counts),'source_H_zero_directions':sorted(set(range(45))-nonzero),'F_derivative_placements_all4_counts':dict(sorted(F.items())),'massless_ghost_metric_entries':len(R),'massless_mixed_metric_entries_each_mu':len(K[0]),'both_ghost_and_mixed_orientations_checked':True,'all4_mixed_Lorentz_directions_checked':True,'no_scalar_BB_or_mass_expansion_route':True}
def radial_proofs():
    uv_power=R2**(1-eps)/(eps-1);uv_log=R2**(-eps)/eps;ir_log=-R2**(-eps)/eps
    assert s.simplify(s.diff(uv_power,R2)+R2**(-eps))==0 and s.simplify(s.diff(uv_log,R2)+R2**(-1-eps))==0
    normal=(4*s.pi*mu2)**eps/s.gamma(2-eps)
    assert pole(normal*uv_power)==0 and pole(normal*uv_log)==1 and pole(normal*ir_log)==-1 and s.simplify(uv_log+ir_log)==0
    heat={}
    t=s.Symbol('inverse_Lambda2',positive=True)
    for profile in [2,4]:
        value=normal*(UV2/profile)**(1-eps)*s.gamma(1-eps);assert pole(value)==0;leading=s.series(s.exp(-profile*R2*t)/(profile*t),t,0,1).removeO();assert s.expand(leading-1/(profile*t)+R2)==0
        heat[str(profile)]={'d4_log_residue':str(pole(value)),'leading_heat_power_coefficient':str(s.Rational(1,profile)),'UV_lower_split_large_cutoff':str(leading)}
    return {'UV_quadratic_radial':str(uv_power),'quadratic_d4_residue':str(pole(normal*uv_power)),'UV_log_radial':str(uv_log),'UV_log_residue':str(pole(normal*uv_log)),'IR_log_residue':str(pole(normal*ir_log)),'whole_log_sum_zero_but_UV_pole_nonzero':True,'heat_profiles':heat}
def mass_and_parameter_proofs():
    z=s.Symbol('z',positive=True);assert s.cancel(1/z-1/(z+M2)-M2/(z*(z+M2)))==0
    common=(4*s.pi*mu2)**eps;massive=common*s.gamma(eps-1)*M2**(1-eps);compensating=common*s.gamma(eps)*M2**(1-eps)/(1-eps)
    masspole=pole(massive);compole=pole(compensating);assert s.simplify(masspole+compole)==0 and masspole==-M2 and compole==M2
    bubble=common*s.gamma(eps)*P2**(-eps)*s.gamma(1-eps)**2/s.gamma(2-2*eps);assert pole(bubble)==1
    delta=s.Symbol('Delta',positive=True);J1=common*s.gamma(eps-1)*delta**(1-eps);J2=common*s.gamma(eps)*delta**(-eps);res1=pole(J1);res2=pole(J2);assert res1==-delta and res2==1
    metric=s.integrate(((res1-delta*res2)/4).subs(delta,x*(1-x)*P2),(x,0,1));vector=-s.integrate(x*res2,(x,0,1));pp=s.integrate(x*x*res2,(x,0,1));assert s.simplify(4*metric+pp*P2)==0
    return {'massive_tadpole_residue':str(masspole),'compensating_mass_residue':str(compole),'sum_nojet_residue':str(s.simplify(masspole+compole)),'nonexceptional_scalar_bubble_residue':str(pole(bubble)),'vector_p_mu_residue_factor':str(vector),'tensor_delta_mu_nu_residue':str(metric),'tensor_p_mu_p_nu_residue_factor':str(pp),'trace_k_squared_residue':str(s.simplify(4*metric+pp*P2))}
def kernel_decomposition(text):
    kernel=num(text);poly=s.Poly(s.cancel(kernel*Q*Rp*Rm),Rp,Rm);assert set(poly.monoms())<=set([(1,0),(0,1)])
    result={}
    for sigma,monomial in [(1,Rm),(-1,Rp)]:
        N=s.expand(poly.coeff_monomial(monomial));pol=s.Poly(N,*k,*p);aa=pol.coeff_monomial(k[0]**2);bb=pol.coeff_monomial(k[0]*p[0]);cc=pol.coeff_monomial(p[0]**2);assert s.expand(N-aa*qpoly-bb*dot-cc*spoly)==0
        assert not any(z.free_symbols or z.has(s.Float) for z in [aa,bb,cc]);result[sigma]=(aa,bb,cc)
    rebuilt=sum((aa*qpoly+bb*dot+cc*spoly)/(Q*(Rp if sigma==1 else Rm)) for sigma,(aa,bb,cc) in result.items());assert s.cancel(rebuilt-kernel)==0
    return result
def bubble_log(abc,sigma,route,param):
    aa,bb,cc=abc
    if route=='primary':
        t=s.Symbol('external_momentum_scale');value=(aa*Q+t*bb*D+t*t*cc*S)/(Q*(Q+2*sigma*t*D+t*t*S));jet=s.series(value,t,0,3).removeO().expand();second=jet.coeff(t,2);angular=s.expand(second).subs(D**2,Q*S/4);return s.simplify(angular*Q**2)
    # Wick rotate k_M^2=-k_E^2,k_M.p_M=-k_E.P,p_M^2=-P_E^2.
    trace=num(param['trace_k_squared_residue']);vec=num(param['vector_p_mu_residue_factor']);scalar=num(param['nonexceptional_scalar_bubble_residue']);value=-aa*trace-bb*sigma*vec*P2-cc*scalar*P2
    return s.simplify(value.subs(P2,-S))
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        q=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('NOJET_UV_WRITE')
        if q.suffix=='.json' and str(q.resolve()) not in allowed:raise PermissionError('NOJET_UV_UNDECLARED '+str(q))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    actual=stage('actual_massless_reference_vertices_and_complete_two_family_envelope',lambda:actual_inputs(role));bindings=read(FOLDER/'bindings.json');cp=FOLDER/'controls.json';assert bindings['byte_sha256'][cp.relative_to(ROOT).as_posix()]==digest(cp) and bindings['new_actual_auxiliary_source_ghost_loop_calculated'];units=read(cp);assert units['bubble_heat_profile']==4 and units['tadpole_heat_profile']==2 and not units['mass_and_cutoff_power_no_jet_amplitudes_qualified']
    radial=stage('explicit_UV_IR_radial_and_heat_power_separation',radial_proofs);param=stage('exact_compensated_auxiliary_mass_and_nonexceptional_tensor_integrals',mass_and_parameter_proofs);kernels={};symbols={}
    for where,record in units['full_unit_kernels'].items():
        abc=kernel_decomposition(record[role]);log=s.simplify(sum(bubble_log(vals,sigma,role,param) for sigma,vals in abc.items()));symbol=s.expand(2*s.I*log).subs(S,spoly);assert s.expand(symbol-num(units['unit_residues'][where]['full_quadratic_Fourier_symbol']))==0
        assert not s.Poly(symbol,*p).coeff_monomial(1);symbols[where]=str(s.expand(symbol));kernels[where]={'leading_nojet_kernel_factor':str(sum(v[0] for v in abc.values())),'twojet_Fourier_symbol':str(s.expand(symbol)),'all10_coefficients':{f'{mu},{nu}':str(-s.Poly(symbol,*p).coeff_monomial(p[mu]*p[nu])) for mu in range(4) for nu in range(mu,4)}};assert kernels[where]['all10_coefficients']==units['unit_residues'][where]['all10_derivative_coefficients']
    assert symbols['a']!='0' and symbols['c']!='0' and s.expand(sum(num(z) for z in symbols.values()))==0
    positive=read(ROOT/'calculations/canonical_so10_positive_source_slavnov'/('primary_v3_result.json' if role=='primary' else 'replay_v3_result.json'));receipt=read(ROOT/'calculations/canonical_so10_positive_source_slavnov/validation_receipt.json');pp=ROOT/'calculations/canonical_so10_positive_source_slavnov'/('primary_v3_result.json' if role=='primary' else 'replay_v3_result.json');assert receipt['execution_state']=='COMPLETED' and receipt['input_sha256'][str(pp)]==digest(pp);newcoverage=[]
    for item in positive['coverage']:
        output=json.loads(json.dumps(item))
        for row in output['inputs']:
            if row['evidence']=='POWER_SENSITIVE_LOCAL_LOG_QUALIFICATION_MISSING':row['evidence']='QUALIFIED_FULL_X_NOJET_D4_LOCAL_LOG_ZERO_BY_SEPARATED_UV'
        output['complete']=all(row['evidence']!='UNMEASURED' for row in output['inputs']);newcoverage.append(output)
    assert len(newcoverage)==5 and all(v['complete'] for v in newcoverage)
    scale=s.Symbol('finite_color_prefactor',finite=True)
    controls={'UV_log_not_zero_despite_IR_cancellation':radial['UV_log_residue']=='1','uncompensated_auxiliary_mass_is_spurious_nonzero':param['massive_tadpole_residue']!='0','compensating_mass_restores_original_UV':param['sum_nojet_residue']=='0','inserted_genuine_mass_over_k4_would_have_nonzero_residue':pole(M2*R2**(-eps)/eps)==M2,'cutoff_power_coefficients_nonzero':all(v['leading_heat_power_coefficient']!='0' for v in radial['heat_profiles'].values()),'nonzero_twojet_log_retained':symbols['a']!='0' and symbols['c']!='0','source_color_sign_rescaling_nojet_zero_insensitive':pole(scale*R2**(1-eps)/(eps-1))==0}
    assert all(controls.values())
    result={'schema':'AUXILIARY_SOURCE_NOJET_D4_LOG_UV_V1','route':role,'actual_massfree_scope':actual,'radial_UV_IR_and_heat':radial,'auxiliary_mass_and_tensor_parameters':param,'actual_kernel_nojet_and_twojet_checks':kernels,'nojet_local_UV':{'all_source_ghost_positions':2025,'nonzero_positions':0,'zero_positions':2025,'complete_nojet_pole':[],'scope':'FULL_CARTESIAN_RETAINED_ONE_LOOP_D4_LOCAL_LOG_ONLY','finite_cutoff_power_or_finite_amplitude_qualified':False,'mass_or_shifted_vacuum_amplitudes_qualified':False},'positive_source_coverage_after_this_input':newcoverage,'newly_completed_zero_relations':['Ja_C_coefficient_dimension2','JL_C_C_coefficient_dimension2'],'controls':controls,'old_loops_color_power_amplitudes_full_Gamma_Q_Ward_or_shift_recomputed':False,'source_count_reduction_or_dimzero_graph_catalogue_reproved':False,'known_Gamma_words':145978,'known_Gamma_sha256':'0d7dfab391eaff50c398f97fee7953359d35f60cee007c44fb4485e0182138ef','full_source_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
