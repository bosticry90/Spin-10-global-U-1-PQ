# Physical-input bridge and leading gauge test at the finite point

Three bounded conclusions emerge at the SAME exploratory scalar point:

1. The exact gauge convention bridge is gstar=g10/sqrt2. Earlier tadpole
   examples gstar=.5 are not examples at g10=.5.
2. The new mass spectrum still does not give a common solution to the known
   one-loop direct gauge equations. A diagnostic stationary fit has residual
   approximately(0.305629,-0.884572,0.579175) in inverse gauge couplings.
3. The scalar-reference mass-only tadpole translation is too large to insert
   naively into the positive tree propagators of this point: a physical charged
   Sigma mode has relative mass insertion20.8818 and crosses zero under that
   same-bare translation before hbar=1.

Qualification requires the actual completed independent receipt, full native
captures and committed raw-byte checks. No gauge-unification PASS/FAIL,
physical coupling/scale, input prescription or benchmark is adopted. Neither
the full theory nor every counterterm prescription is excluded.

## Conventions must agree before physics can be compared

The tadpole reference uses raw plane generators J with -Tr(J²)/2=1. The
gauge-matching vector convention uses T=iJ/sqrt2, Tr(T²)=1. Checking all45
generators and the four vector mass windows gives

\[
 M_V^2=g_\star^2\Gamma=\frac{g_{10}^2}{2}\Gamma,
 \qquad g_\star=\frac{g_{10}}{\sqrt2}.
\]

Equivalently M_V²/(g10² omega²)=gamma/120 with omega²=60. This verifies
the correspondence between two existing conventions; it does not change
either earlier calculation. Their gstar=.5 example corresponds to g10 about
0.707107. The bosonic conditional domain becomes0<g10<=sqrt2 and
xi*g10²<=2. Previous DR/MSbar notation means dimensional REGULARIZATION,
not dimensional reduction. No new physical scheme or gauge choice is made.

## Action-derived mass thresholds at the new point

For each SM irrep the exact real-scalar beta weights follow its SU3/SU2
indices and GUT-normalized hypercharge. All35 blocks account for290 positive
real directions;33 gauge,1PQ and4Higgs zeros are excluded. Light UV/EFT
contributions cancel in the hard matching. Heavy right-handed neutrinos
are SM singlets, so this particular one-loop gauge comparison needs no
numerical canonical Yukawa fit and does not resume paused flavor.

Using the NEW masses gives at mu=omega

\[
\lambda^S=3\sum_{\rm heavy}b_i\log(m^2/60)
\simeq(-269.0100982,-283.1619681,-275.6829529).
\]

The scalar beta sum is exactly(377/30,77/6,79/6). Together with vector
indices(8,6,5), bSM=(41/10,-19/6,-7), it reproduces parent beta-34/3
and exact one-loop matching-scale cancellation. The already qualified
MSbar background-field Feynman kernel counts all33 vector/Goldstone/ghost
sets once, with lambdaV=sum T[1-21log(g10*sqrt(gamma/120))]. No old-point
scalar mass logarithm, PS interval assignment or two-loop threshold is reused.

These reference formulas have established matching context in
[Schwichtenberg2019](https://link.springer.com/article/10.1140/epjc/s10052-019-6878-1).
That paper's model-specific conclusions are not imported here.

## Frozen measured-coupling comparison and correction target

Use the SAME historical MSbar reference inputs alphaEM^-1=127.93,
sin²theta=.23122,alphaS=.118,MZ=91.1876GeV, without claiming they are updated
experimental central values. The known equations are

\[
A_i(M_Z)=\frac{4\pi}{g_{10}^2}
 -\frac{\lambda_i^S+\lambda_i^V(g_{10})}{12\pi}
 +\frac{b_i^{SM}}{2\pi}L,\qquad L=\log(\omega/M_Z).
\]

The two relative equations are linear in(log g10,L) with nonzero determinant.
Their unique solution has log g10 about-68.7953 and L about95.5002; the
common normalization then fails by about7.15e60. Thus the completed known
one-loop system has no common root. The diagnostic least-squares stationary
point is

```text
g10                  0.558577473561093
omega                2.21164414130e15 GeV
inverse-coupling r    (0.305628878,-0.884572242,0.579174833)
```

These are not physical parameter determinations. No complete higher-order
heavy-threshold/error bound is available, especially in view of the quantum
input warning. The one-loop miss therefore earns neither full gauge-unification
acceptance nor physical exclusion. Scale variation alone cannot bound unknown
finite terms, and old-point next-order numbers cannot be transported.

The sign and correction space are explicit. Define r=predicted minus frozen
inverse couplings. At FIXED diagnostic fit, delta_lambda enters as
-delta_lambda/(12pi), so required differences are

```text
delta_lambda1-delta_lambda2    +44.86952512
delta_lambda1-delta_lambda3    -10.31243956
delta_lambda2-delta_lambda3    -55.18196467
```

These are DIAGNOSTIC TARGETS, not predicted finite thresholds. A common
shift is removed in the reported centered vector. For linear refitting of
(log g10,L), the full Jacobian includes the gauge-mass logarithm dependence.
Its unit left-normal vector is approximately(0.27769294,-0.80371813,0.52623550).
The required normal lambda component is41.49164573. The independent projection
I-J(J^T J)^-1 J^T checks this instead of assuming that simply negating three
residuals supplies a refitted physical correction. C1_GS remains uncalculated.

## Quantum interpretation at the correctly converted diagnostic coupling

At the diagnostic fit, gstar=g10/sqrt2 about0.3949739194. Reusing the known
bosonic reference at xi=1 gives formal raw responses approximately
(0.24342225,12.76357161,0.84206776). No value is adopted; the gauge system
does not match all three inputs. These remain off-shell linear responses,
not physical vacuum coordinates or gauge-independent observables.

The measured SCALAR pure-mass counterterm target is already problematic on
its own. A one-copy positively massive charged Sigma mode, label(0,0,0,-12),
has tree m²=0.0096. Its canonical derivative with respect to physical
mSigma² is2, independently checked from the coefficient and kinetic metric.
The scalar-only target gives delta M²=0.2004652783, ratio20.88179983.
The same-bare translation p_new=p_old-hbar*d would give the NAIVE translated
tree squared mass-0.1908652783 at hbar=1. Keeping the old numbers while changing
finite counterterms instead changes the underlying perturbative inputs.

This invalidates the shortcut of treating that mass-only translation as a
small tree-propagator update. It does not establish a quantum tachyon, a
failure of every allowed finite counterterm map or a no-go for a reorganized
calculation. The old subset maps belong to their own point/light kernel and
cannot simply be imported. Alternative prescriptions require actual physical
inputs, all companion terms and same-bare translations; solvability is not
control. [Braathen et al.2021](https://link.springer.com/article/10.1140/epjc/s10052-021-09285-4)
provides general tadpole-prescription context, not a rescue of this model.

## Verification and research disposition

Primary uses the newly qualified eigenmasses and Casimir index formula.
Independent verification reconstructs generalized G^-1H pseudodeterminants
using Newton trace identities, without reusing the eigenvalues; it derives
SU3 indices from tableau weights and SU2 indices from weight sums. A projected
one-variable stationary solve checks the two-variable fit, full refit projector,
threshold sign and unique relative solution. The charged-mode mass insertion
and opposite translation sign are explicit controls. Shared action/cache,
group assignments, reference kernels, software and analyst remain limitations.

The new point remains a CLASSICAL feasibility example with an unresolved
physical quantum description. Its full328 BFB/contact/mass/Higgs results are
preserved. Further expensive finite Higgs matching or another scalar search
has low priority until physical input compatibility or a cheaper decisive
constraint can change that assessment. Do not fit missing thresholds or
fermion effects to obtain a desired result.

Science and AI capability remain equal objectives; education voluntary and
nonblocking. No protected authority, benchmark, scheme, new physical input,
blocked stage or human-paused flavor is changed. Statev113/34of39 and
custodyexit2/seven, all prior successes and failures remain. The investigation
is incomplete; these checks are not independent endorsement of the theory.
