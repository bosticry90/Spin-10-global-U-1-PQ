"""Physical-input normalization bridge and new-point one-loop gauge diagnostic."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from fractions import Fraction as F
import sys,json,time,threading,os
import sympy as S
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def weights(label):
 p,q,n,y6=label;d3=F((p+1)*(q+1)*(p+q+2),2);d2=n+1;c3=F(p*p+q*q+p*q+3*p+3*q,3);c2=F(n*(n+2),4)
 return [F(3,5)*F(y6,6)**2*d3*d2/6,F(d2,3)*c2*d3/6,d3*c3*d2/48]
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(t in args[1] for t in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('PHYSICAL_SCREEN_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for i,j in combinations(range(10),2):
  J=S.zeros(10);J[i,j]=1;J[j,i]=-1;T=S.I*J/S.sqrt(2);assert -S.trace(J*J)/2==S.trace(T*T)==1
 vector=read(C/'canonical_so10_gauge_matching/vector_ledger.json');assert vector['omega_squared']==60 and vector['unbroken_SM_vectors']==12
 assert all(abs(F(str(v['mass_squared_over_g10_squared_omega_squared']))-F(str(v['raw_gram_eigenvalue']))/120)<F(1,10**14) for v in vector['mass_sets'])
 mp.mp.dps=90;num=lambda z:mp.mpf(str(z.numerator))/z.denominator if isinstance(z,F) else mp.mpf(str(z));text=lambda z:mp.nstr(z,65)
 scalar=read(C/'canonical_so10_finite_radial_control/primary_result.json');probe=scalar['probes'][-1];beta=[F(0)]*3;lam=mp.matrix([0,0,0]);counts=[0,0];rows=[]
 for b in probe['blocks']:
  w=weights(b['label']);mass=list(map(mp.mpf,b['mass_squared']));positive=[x for x in mass if abs(x)>mp.mpf('1e-40')];assert all(x>0 for x in positive) and len(mass)-len(positive)==b['zero_copies']
  counts[0]+=b['dimension']*len(positive);counts[1]+=b['dimension']*b['zero_copies'];logs=sum(mp.log(x/60) for x in positive)
  for i in range(3):lam[i]+=3*num(w[i])*logs;beta[i]+=len(positive)*w[i]
  rows.append({'label':b['label'],'beta_per_real_eigenstate':list(map(str,w)),'heavy_copies':len(positive),'log_pseudodeterminant_over_omega':text(logs)})
 assert counts==[290,38] and beta==[F(377,30),F(77,6),F(79,6)]
 bs=list(map(F,['41/10','-19/6','-7']));V=list(map(F,[8,6,5]));parent=F(-34,3);assert all(bs[i]+beta[i]-F(7,2)*V[i]==parent for i in range(3))
 vsets=[(F(3,5)/120,[F(14,5),F(0),F(1)]),(F(3)/120,[F(0)]*3),(F(50)/120,list(map(F,[5,3,2]))),(F(253,5)/120,[F(1,5),F(3),F(2)])]
 frozen=read(C/'canonical_so10_direct_gauge_matching/direct_matching.json')['frozen_inputs_MZ'];ae=num(F(str(frozen['alpha_em_MSbar_inverse_MZ'])));sw=num(F(str(frozen['sin2theta_MSbar_MZ'])));alphas=num(F(str(frozen['alpha_s_MSbar_MZ'])));A0=mp.matrix([mp.mpf(3)/5*(1-sw)*ae,sw*ae,1/alphas]);MZ=num(F(str(frozen['MZ_GeV'])))
 B=mp.matrix([num(a)/(2*mp.pi) for a in bs]);vcoef=mp.matrix([21*num(a)/(12*mp.pi) for a in V]);one=mp.matrix([1,1,1])
 def vl(u):return mp.matrix([sum(num(w[i])*(1-21*(u+mp.log(num(m2))/2)) for m2,w in vsets) for i in range(3)])
 def residual(u,L):return 4*mp.pi*mp.exp(-2*u)*one-(lam+vl(u))/(12*mp.pi)+B*L-A0
 origin=residual(mp.mpf(0),mp.mpf(0));D=mp.matrix([[vcoef[0]-vcoef[j],B[0]-B[j]] for j in [1,2]]);rhs=mp.matrix([-(origin[0]-origin[j]) for j in [1,2]]);relative=mp.lu_solve(D,rhs);relr=residual(*relative);exact_common=max(abs(x) for x in relr)<mp.mpf('1e-40')
 assert abs(mp.det(D))>mp.mpf('1e-10') and not exact_common
 def grad(u,L):
  r=residual(u,L);ju=-8*mp.pi*mp.exp(-2*u)*one+vcoef;return mp.fdot(r,ju),mp.fdot(r,B)
 fit=mp.findroot(grad,(mp.log(mp.mpf('.52')),mp.mpf(31)),tol=mp.mpf('1e-70'),maxsteps=40);u,L=fit;r=residual(u,L);g=mp.exp(u);assert mp.mpf('.1')<g<1 and 0<L<50
 ju=-8*mp.pi*mp.exp(-2*u)*one+vcoef;n=mp.matrix([ju[1]*B[2]-ju[2]*B[1],ju[2]*B[0]-ju[0]*B[2],ju[0]*B[1]-ju[1]*B[0]]);n/=mp.sqrt(mp.fdot(n,n));n*=1 if n[0]>0 else -1
 assert abs(mp.fdot(n,ju))<mp.mpf('1e-70') and abs(mp.fdot(n,B))<mp.mpf('1e-70')
 dlam=12*mp.pi*r;centered=dlam-sum(dlam)/3*one;assert max(abs(x) for x in (r-dlam/(12*mp.pi)))<mp.mpf('1e-80')
 pairdiff=[[i,j,text(dlam[i]-dlam[j])] for i,j in combinations(range(3),2)]
 # Explicit normalization bridge into the retained bosonic reference.
 gstar=g/mp.sqrt(2);bose=read(C/'canonical_so10_finite_radial_control/bosonic_primary_result.json');HH=S.Matrix(scalar['exact_raw_radial_Hessian']);Gs=list(map(S.Rational,scalar['radial_metrics']));sn=lambda z:mp.mpf(str(S.N(S.sympify(z),100)));total=[]
 for i in range(3):
  val=mp.mpf(probe['T_canonical'][i])
  for row in bose['new_gauge_spectral_coefficients']:
   gamma=sn(row['gamma']);val+=(3*gstar**4*gamma*sn(row['Gamma_derivative_trace'][i])*(mp.log(gstar*gstar*gamma/60)-mp.mpf(1)/3)+gstar*gstar*gamma*sn(row['new_orbit_derivative_trace'][i])*(mp.log(gstar*gstar*gamma/60)-1))/(32*mp.pi**2*mp.sqrt(sn(Gs[i])))
  total.append(val)
 dr=[-total[i]*mp.sqrt(sn(Gs[i]))/sn(HH[i,i]) for i in range(3)]
 pure=next(b for b in probe['blocks'] if b['type']=='Z' and b['label'][-1]!=0 and len(b['mass_squared'])==1);tree=mp.mpf(pure['mass_squared'][0]);delta=2*mp.mpf(probe['pure_mass_increments'][1]);ratio=delta/tree;assert tree>0 and ratio>1 and tree-delta<0
 for n0,h in prep['input_sha256'].items():assert digest(R/n0)==h,n0
 assert not writes and time.perf_counter()-start<120
 out={'schema':'FINITE_PHYSICAL_INPUT_PRIMARY_V1','status':'COMPLETE_LEADING_GAUGE_AND_INPUT_DIAGNOSTICS_REQUIRE_RECEIPT','scalar_lambda_SM_1_2_3':list(map(text,lam)),'heavy_scalar_beta':list(map(str,beta)),'scalar_heavy_zero_directions':counts,'threshold_block_rows':rows,'gstar_over_g10':'1/sqrt(2)','all45_generator_norms_checked':True,'all_four_vector_mass_ratios_checked':True,'frozen_A0':list(map(text,A0)),'fixed_reference_MZ_GeV':text(MZ),'exact_common_one_loop_solution':bool(exact_common),'relative_solution_log_g10_L':list(map(text,relative)),'relative_solution_common_normalization_residual':list(map(text,relr)),'diagnostic_g10':text(g),'diagnostic_log_omega_over_MZ':text(L),'diagnostic_omega_GeV':text(MZ*mp.exp(L)),'residual_inverse_couplings':list(map(text,r)),'max_residual':text(max(abs(a) for a in r)),'refit_normal_vector':list(map(text,n)),'normal_required_delta_lambda':text(12*mp.pi*mp.fdot(n,r)),'fixed_fit_required_delta_lambda':list(map(text,dlam)),'centered_required_delta_lambda':list(map(text,centered)),'fixed_fit_required_delta_lambda_pair_differences':pairdiff,'diagnostic_gstar':text(gstar),'diagnostic_xi':1,'bosonic_raw_response_at_diagnostic_g10':list(map(text,dr)),'scalar_mass_only_translation_control':{'physical_label':pure['label'],'tree_mass2':text(tree),'scalar_conditional_delta_mass2':text(delta),'relative_insertion':text(ratio),'naive_same_bare_translated_tree_mass2':text(tree-delta),'not_all_prescriptions_excluded':True},'higher_order_uncertainty_bound':None,'gauge_unification_passed':False,'gauge_unification_failed':False,'unknown_thresholds_fitted':False,'physical_inputs_or_benchmark_adopted':False,'scientific_authority_changed':False,'whole_goal_complete':False,'seconds_after_import':time.perf_counter()-start,'input_sha256':prep['input_sha256'],'write_attempts':writes}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
