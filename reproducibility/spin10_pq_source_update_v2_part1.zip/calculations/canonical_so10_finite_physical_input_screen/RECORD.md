# Finite-point physical-input bridge and leading gauge diagnostic

Standing AGENTS.md delegation. Baseline1a6c49473a6707ee86b21f90a3f174cd2c3407ad.
Previous increment was progress: new scalar/bosonic radial warning, with
classical full328 BFB and complete-contact proofs preserved. No workers live.
Compare a cheap observable-related gauge test with further off-shell diagram
work before investing in quantum matching at this exploratory point.

Freeze the SAME coherent-joint-witness POINT, all35 newly qualified mass
blocks, existing normalized one-loop Spin10->SM kernel and historical low
MSbar input set(MZ91.1876GeV,alphaEM^-1=127.93,sin²theta=.23122,alphaS=.118).
These are frozen reference inputs, not a new claim about current experimental
central values. No scalar search, changed inputs, benchmark/scale adoption,
two-loop heavy threshold, flavor fit or blocked-stage activation.

First bridge gauge conventions exactly. Tadpole gstar multiplies raw plane
J with -Tr(J²)/2=1. Direct matching uses T=iJ/sqrt2 with Tr(T²)=1.
Equal covariant products/masses require gstar=g10/sqrt2. Check all45 generators
and all four vector mass windows; old gstar=.5 diagnostics are NOT g10=.5.
Earlier DR/MSbar scalar notation denotes dimensional regularization, never
dimensional reduction. Reuse named reference schemes without physical adoption.

For each SM label(p,q,n,y6), derive exact real-scalar beta weights from the
SU3/SU2 dimensions/Casimirs and canonical hypercharge. Include both conjugate
blocks once, all290 positive states; exclude33 gauge+1PQ+4Higgs zero modes.
At mu=omega, lambdaS_i=3 sum_heavy b_i log(m²/60). Sum beta weights must
be(377/30,77/6,79/6); vector indices(8,6,5) and all33 vector/Goldstone/ghost
sets yield projected parent beta-34/3 and the exact scale derivative. Light
UV/EFT fields cancel; unfitted heavy right-handed neutrinos are SM singlets
and need no numerical Yukawa fit for this ONE-loop gauge test.

Use the already established MSbar background-field Feynman kernel
lambdaV_i=sum_gamma T_i[1-21log(g10*sqrt(gamma/120))]. This is a conditional
reference calculation, not a new physical gauge choice. Do not rerun old
scripts that overwrite their results or retain old-point mass logarithms.
At MZ predict A_i=4pi/g10²-(lambdaS_i+lambdaV_i)/(12pi)+bSM_i*L/(2pi),
L=log(omega/MZ). Solve only these two diagnostic scale/coupling variables;
no scalar parameter optimization. Prove absence/presence of an exact common
one-loop root using the TWO relative equations linear in(log g10,L), then
test the common normalization. A least-squares stationary fit is a diagnostic,
not proof of physical unification or global viability. No higher-order
uncertainty bound is invented; a one-loop miss alone cannot reject the model.

Define required corrections in the proper space: at fixed fitted inputs an
extra lambda correction enters inverse couplings with MINUS1/(12pi), hence
delta_lambda_i-delta_lambda_j=12pi*(r_i-r_j). Report the common-orthogonal
projection and the normal component under linear refitting of(log g10,L),
using the full Jacobian including gauge-mass log dependence. This is a target,
not an action-predicted finite correction. Do not tune missing constants.

Use the diagnostically fitted g10 only to reevaluate the existing bosonic
reference at gstar=g10/sqrt2,xi=1; retain its unphysical/coordinate limitations.
Separately test the already measured SCALAR pure-mass finite cancellation
targets: for a genuine one-copy positive pure-Sigma mode, delta M²=2delta
mSigma². If larger than its tree mass², the naive SAME-BARE translation
p_new=p_old-hbar*d crosses a positive tree gap before hbar=1. This rejects
that unresummed MASS-ONLY bookkeeping shortcut, not all counterterm choices,
the same underlying theory, or physical quantum viability. Do not adopt it.

Primary uses frozen newly computed eigenmasses and exact label weights;
independent verifier recomputes generalized operator pseudodeterminants via
Newton trace identities, independent index/ledger comparison and a projected
one-variable stationary solve. Controls: gstar/g10 factor, vector finite
constant, hypercharge, zero/conjugate/multiplicity accounting, threshold sign,
normalization/refit projection and wrong same-bare translation sign. Literature
comparators are Schwichtenberg2019 and Braathen et al.2021, not independent
endorsement. Published knowledge is inherited human expertise.

Two sequential120-second/8GiB native roles, direct350MiB available commit,
frozen sources/inputs and write-denying workers. Distinct methods, no fresh
byte-identical pair promised. All failures/incompletes preserved. No scope
promotion from repeated AI agreement. Authority34/39,statev113,custodyexit2/
seven, all prior failures/blocked stages and human-paused flavor unchanged.
Scientific/AI objectives equal; education voluntary, concurrent, nonblocking.
