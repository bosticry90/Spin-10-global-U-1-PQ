# Verifier V2 — exact frozen decimal inputs

The first independent verifier completed all35 pseudodeterminant/index checks
and stopped at its compound stationary-fit comparison assertion. Preserve its
source, preparation and complete FAILED native capture. It supplies no final
qualification receipt. The primary result is unchanged and not rerun.

Code inspection identifies a precision defect: independent parsing used
SymPy sympify on decimal boundary strings, creating default53-bit Float atoms
before evaluating them at90 digits. The primary correctly used exact decimal
rationals. Increasing display precision cannot recover lost input digits.

V2 changes ONLY those three decimal boundary parsers to explicit Rational
construction and adds a guard detecting the old Float conversion. All35
matrix/index controls, independent stationary solve,1e-40 fit agreement,
refit projection, threshold signs, generator bridge and translation tests
remain mandatory. No observed value, model parameter, numerical tolerance,
acceptance condition or frozen primary byte is altered.

This is one new bounded verifier continuation under standing AGENTS.md
delegation:120seconds after imports, sampled private8GiB, direct350MiB
available commit. No scalar search, new point, physics calculation or
retroactive qualification of the failed attempt. Shared-error limits remain.
