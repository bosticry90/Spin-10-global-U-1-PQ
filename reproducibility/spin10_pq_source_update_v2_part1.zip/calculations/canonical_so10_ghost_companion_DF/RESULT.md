# The complete DF bubble has two nonzero derivative coefficients

Prospective until the paired native captures/results, independent receipt
and committed-byte checks qualify. Baseline98c4ef9212c36a8e4b5cc1bf6c7b28b6c51c8104.

The actual ordinaryg3 DF mixed ghost/vector bubble is calculated over its
entire declared domain:7AaC/16BaC profiles and18/40 directed rooted cycles.
This closes the last unmeasured two-vertex family. It does not calculate
the remaining FFF,FFG3,FFU triangles or the complete ghost Ward relation.

Unlike FR,DG3 and DU, DF contributes to both independent derivative
coefficients. In units hbar*g10^3/(32*pi^2*epsilon_UV), its physical density
is

    (partial_mu V_v^mu) a_j R[v,j,l] C_l
      + V_v^mu a_j Q[v,j,l] partial_mu C_l,

modulo the qualified four F integration-by-parts currents. V=0..11 is A_H
and12..56 is B. A_H is an external connection, not an integrated vector.

| Complete physical tensor | Nonzero positions | Zero complement |
| --- | ---: | ---: |
| Divergence-vector coefficient R | 2016 | 113409 |
| Ghost-derivative coefficient Q | 2160 | 113265 |

Each tensor has57*45*45=115425 possible positions. All four Lorentz copies
and both independent probes are retained. Counts are coefficient supports,
not physical processes or independent loop integrals.

The external ghost at F may be a or C, and the F derivative may be on a
or C. Their four unit coefficients are

| External ghost at F | Differentiated field at F | Unit coefficient |
| --- | --- | --- |
| a | a | (W+3)/2 |
| a | C | (W-3)/2 |
| C | a | (3-W)/2 |
| C | C | -(W+3)/2 |

For the first two assignments the bubble momentum is p=r+q; for the last
two it is p=q. Thus the first two contribute equally to R and Q, while
the last two contribute only to Q. Each row is checked at all16 vector/
momentum positions for both probes,128 positions in total. One probe alone
would lose information. W is the width of the actual quantum B line,
later specialized symbolically to W_H or W_M, without choosing a gauge.

Primary constructs both graded-Hessian Born words with the full supertrace.
Replay uses connected Gaussian Wick contractions, the external odd-order
signs, and shifted Feynman-parameter homogeneous residues. The oriented
principal ghost inverse is +1/p^2 for C,a and -1/p^2 for a,C. The full BB
inverse includes transverse and longitudinal terms. Their signs and both
Born words are necessary; no extra ghost1/2 or rooted-cycle factor appears.

The actual mixed V/B derivative of the quartic D has27710 coefficients.
Literal ordered-field differentiation agrees with all corresponding
independently qualified P2 matrix coefficients, including identical-B
factors and A_H/B mixed terms. All45 quantum vector/ghost colors are
contracted. Explicit sparse index products and sparse matrix products
give the same four pieces and both complete final tensors. F_a and F_c
come from the qualified actual derivative/IBP bridge; neither is dropped.

The independent validator must additionally parse all four Lorentz copies
of the literal F and D, check their bridge and kinetic conventions,
rederive the full analytic kernels and graded Wick factor, reproduce every
coefficient and zero complement with exact multiquadratic arithmetic,
and check all12 constant-H covariance identities and physical reality.
This is a finite local-pole calculation, not a full local Ward theorem.

Controls omit either external assignment or either F derivative,halve
the graded weight,reverse the external odd order,drop transverse or
longitudinal propagation,or replace the Lorentz angular metric. Both
assignments and both derivative placements affect the actual result. The
accepted receipt owns any qualifications/insensitivity or failed checks.

UV residues are obtained on a positive UV annulus,or with an independently
separated auxiliary IR mass. No whole scaleless integral, exceptional
physical amplitude or finite/IR limit is used to infer a UV coefficient.
Primary completed in107.153024seconds after imports,within its120-second
bound. Captures/receipt own replay/validation runtime, sampled memory and
any failed runs. All limits are120seconds after imports,8GiB sampled private
memory and350MiB minimum available commit. No fresh byte-identical replay
pair is claimed.

Track B supports moving from the two-probe method to a complete actual
coefficient tensor through distinct graded and momentum methods. The
independent exact-field route checks arithmetic and covariance without
another full-functional expansion. It shares the action,physical charts,
reference,IBP/support premises,software and AI author. These computations
do not independently validate those physical premises or replace experts.

NEXT: calculate the three remaining triangle families FFF,FFG3,FFU with
both probes and the actual graded weights. Retain ordinary and mixed
propagation,ordered symbolic widths and the full4D loop. Exploit universal
Lorentz/color reductions before expanding components;do not infer unknown
coefficients from a desired Ward cancellation. After complete family
coverage,combine the actual poles,qualify canonical extraction/exact-once
integration and then evaluate the complete selected ghost Ward relation.

No family is inserted into Gamma here. Current147266/hashc445c2... and
the38-source,selected auxiliary-H and bilinear scopes remain unchanged.
Full ghost/source-free Slavnov,E5/A5,QAP,regulated Jacobian/measure,
32 nonlinear products,128sourcejets,508programs,finite contacts/Legendre,
IR/Legacy and physical viability remain unqualified. Keep34/39,HB1/C5block,
flavorpause,C1_GS,quartet/scalar warnings,closedroutes,custodyexit2/seven.
No input,scheme,benchmark,foundation,policy,authority or remoteaction.
Education voluntary/nonblocking;Leanselective.
