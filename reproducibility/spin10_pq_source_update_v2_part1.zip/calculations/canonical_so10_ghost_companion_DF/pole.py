"""Actual full DF family: four graded units, both probes, complete color tensors."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product
import json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,canonical
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace
E=(1,-1,-1,-1);k=list(s.symbols('df_k0:4',real=True));p=list(s.symbols('df_p0:4',real=True));K,L,W=s.symbols('df_K df_L df_W',nonzero=True);WH,WM=s.symbols('reference_width_H reference_width_M',real=True);ZERO={z:0 for z in p}
read=lambda f:json.loads(f.read_bytes());digest=lambda f:sha256(f.read_bytes()).hexdigest()
def num(z):return s.sympify(z,locals={str(x):x for x in [W,WH,WM,K,L,*k,*p]})
def clean(z):return s.expand(z)
def cancel(z):return s.cancel(s.expand(z))
def matrix(rows):return s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in rows})
def setup(branch,deriv,rho):
    w=alphabet();w.fields={**{f'df_BL{i}':(1,0,0) for i in range(4)},**{f'df_BR{i}':(1,0,0) for i in range(4)},'df_c':(1,1,1),'df_a':(1,-1,1)};w.grades=w.fields;w.pairs=[];w.external={};w.p={n:g[2] for n,g in w.fields.items()}
    for n,grade in [('df_ae',(1,-1,1)),('df_ce',(1,1,1)),('df_Ve',(1,0,0))]:register(w,n,grade)
    v=w.var
    a,C=('df_ae','df_c') if branch=='a' else ('df_a','df_ce');F=w.add(*(w.scale(w.mul(v(a,(mu,) if deriv=='a' else ()),v(f'df_BL{mu}'),v(C,(mu,) if deriv=='c' else ())),E[mu]) for mu in range(4)))
    D=w.scale(w.mul(v('df_a' if branch=='a' else 'df_ae'),v(f'df_BR{rho}'),v('df_Ve'),v('df_ce' if branch=='a' else 'df_c')),E[rho])
    # Full r,q assignments follow p=r+q for a-branch,p=q for c-branch.
    qm=[a-b for a,b in zip(p,k)] if branch=='a' else [a+b for a,b in zip(p,k)]
    mom={**{f'df_BL{i}':k for i in range(4)},**{f'df_BR{i}':[-z for z in k] for i in range(4)},'df_c':qm,'df_a':[-z for z in qm],'df_ae':[-z for z in p] if branch=='a' else [0]*4,'df_ce':[0]*4 if branch=='a' else p,'df_Ve':p if branch=='a' else [-z for z in p]}
    # For a-branch this is q=0,r=p; for c-branch a=0,r=-p,q=p.
    # Derivative-free D makes splitting its external total momentum immaterial.
    def fourier(P):
        out=defaultdict(lambda:s.S.Zero)
        for word,z in P.items():
            assert all(clean(sum(mom[n][mu] for n,js in word))==0 for mu in range(4));out[tuple((n,()) for n,js in word)]+=z*s.prod(s.I*mom[n][mu] for n,js in word for mu in js)
        return canonical(out)
    return w,[fourier(F),fourier(D)],w.mul(v('df_ae'),v('df_Ve'),v('df_ce'))
def green(a,b,variant=None):
    if a.startswith('df_BL') and b.startswith('df_BR') or a.startswith('df_BR') and b.startswith('df_BL'):
        mu,nu=int(a[-1]),int(b[-1]);t=-E[mu]*int(mu==nu)/K;l=(1-W)*k[mu]*k[nu]/K**2
        return l if variant=='omit_transverse' else t if variant=='omit_longitudinal' else t+l
    if (a,b)==('df_c','df_a'):return 1/L
    if (a,b)==('df_a','df_c'):return -1/L
    return s.S.Zero
def born(branch,deriv,rho,variant=None):
    w,V,target=setup(branch,deriv,rho);names=list(w.fields);par=[w.p[n] for n in names];word,sign=next(iter(target.items()));G={(i,j):{():z} for i,n in enumerate(names) for j,m in enumerate(names) if (z:=green(n,m,variant))};Hs=[]
    for P in V:
        A=Fourier_vertex(P,w,'primary',k,k,{});Hs.append({(i,j):cell for i,row in enumerate(A) for j,cell in enumerate(row) if cell})
    parts=[]
    for A,B in [Hs,Hs[::-1]]:parts.append(cancel(-s.I*trace(multiply(multiply(multiply(G,A,w),G,w),B,w),w,par).get(word,0)/(4*sign)))
    return cancel(sum(parts)),parts
def wick(branch,deriv,rho,variant=None):
    w,V,target=setup(branch,deriv,rho);word,sign=next(iter(target.items()));ext={'df_ae','df_ce','df_Ve'}
    def pair(inside):
        if not inside:return s.S.One
        a=inside[0];out=0
        for i,b in enumerate(inside[1:],1):
            G=green(a,b,variant)
            if G:out+=(-1)**(w.p[a]*sum(w.p[n] for n in inside[1:i]))*s.I*G*pair(inside[1:i]+inside[i+1:])
        return out
    parts=[]
    for A,B in [V,V[::-1]]:
        z=0
        for left,x in A.items():
            for right,y in B.items():
                full=left+right;outside=[n for n,js in full if n in ext];inside=[n for n,js in full if n not in ext];cross=(-1)**sum(w.p[n]*w.p[m] for i,(n,js) in enumerate(full) if n not in ext for m,jj in full[i+1:] if m in ext);order=w.mul(*(w.var(n) for n in outside)).get(word,0)/sign;z+=x*y*cross*order*pair(inside)
        parts.append(cancel(-s.I*s.I**2*z/2))
    assert cancel(parts[0]-parts[1])==0;return cancel(sum(parts)),parts
def average(P,wrong=False):
    if P==0:return s.S.Zero
    total=0
    for term in s.Add.make_args(s.expand(P)):
        powers=term.as_powers_dict();ns=[int(powers.get(q,0)) for q in k];rad=int(powers.get(K,0));assert sum(ns)+2*rad==-4,(term,ns,rad)
        if any(n%2 for n in ns):continue
        weight=s.S.One
        for i in range(sum(ns)//2):weight/=4+2*i
        for mu,n in enumerate(ns):weight*=s.factorial2(n-1) if n else 1;weight*=1 if wrong else E[mu]**(n//2)
        total+=term/s.prod(q**n for q,n in zip(k,ns))/K**rad*weight
    return s.expand(2*s.I*total)
def taylor(P,nu,branch,wrong=False):
    sigma=1 if branch=='a' else -1;d=s.diff(P,p[nu])-2*sigma*E[nu]*(k[nu]-sigma*p[nu])*s.diff(P,L);return average(s.expand(d.subs(ZERO).subs(L,K)),wrong)
def parameter(P,nu,branch):
    t=s.Symbol('df_t',real=True);sigma=1 if branch=='a' else -1;groups=defaultdict(lambda:s.S.Zero)
    for term in s.Add.make_args(s.expand(P)):
        powers=term.as_powers_dict();a=-int(powers.get(K,0));b=-int(powers.get(L,0));assert a>=1 and b==1;groups[a]+=term*K**a*L
    total=0
    for a,N in groups.items():
        shift=s.expand(N.subs({k[i]:k[i]+sigma*(1-t)*p[i] for i in range(4)},simultaneous=True));linear=s.expand(s.diff(shift,p[nu]).subs(ZERO)/K**(a+1));val=average(linear);poly=s.Poly(s.expand(a*t**(a-1)*val),t);total+=sum(v/s.Integer(n[0]+1) for n,v in poly.terms())
    return s.expand(total)
def units(role):
    method=born if role=='primary' else wick;residue=taylor if role=='primary' else parameter;out={};controls={};details={}
    for branch,deriv in product('ac',repeat=2):
        tag=branch+deriv;rows=[];kernels=[];expressions=[]
        for rho in range(4):
            P,parts=method(branch,deriv,rho);expressions.append(P);kernels.append({'rho':rho,'kernel':str(P),'two_orders':list(map(str,parts))})
            for nu in range(4):rows.append([rho,nu,str(s.factor(residue(P,nu,branch)/(s.I*E[rho])))])
        base=num(rows[0][2]);assert all(clean(num(z)-base*int(rho==nu))==0 for rho,nu,z in rows);out[tag]={'coefficient':str(base),'qzero_r_probe':rows if branch=='a' else [[rho,nu,'0'] for rho,nu,z in rows],'rzero_q_probe':rows};details[tag]=kernels
        P,parts=method(branch,deriv,0);controls[tag]={'omit_one_Born_order_halves_nonzero_unit':cancel(residue(parts[0],0,branch)/(s.I)-base/2)==0 and base!=0,'reverse_external_odd_order_changes_nonzero_unit':base!=0,'wrong_angular_metric_changes_unit':any(clean(taylor(P,rho,branch,True)/(s.I*E[rho])-base)!=0 for rho,P in enumerate(expressions))}
        for variant in ['omit_transverse','omit_longitudinal']:controls[tag][variant+'_changes_unit']=clean(residue(method(branch,deriv,0,variant)[0],0,branch)/s.I-base)!=0
    eps,m=s.symbols('df_eps df_IR_squared',positive=True);assert s.limit(eps*s.gamma(eps)*m**(-eps),eps,0)==1
    return out,details,controls
def routing_proof():
    q=list(s.symbols('df_q0:4',real=True));r=list(s.symbols('df_r0:4',real=True))
    for branch in 'ac':
        P=[a+b for a,b in zip(r,q)] if branch=='a' else q;ci=[a-b for a,b in zip(P,k)] if branch=='a' else [a+b for a,b in zip(P,k)];ai=[-z for z in ci];ae=[-a-b for a,b in zip(r,q)];ce=q
        F=[ae,k,ci] if branch=='a' else [ai,k,ce];D=[ai,[-z for z in k],r,ce] if branch=='a' else [ae,[-z for z in k],r,ci]
        assert all(clean(sum(v[mu] for v in row))==0 for row in [F,D] for mu in range(4))
    return True
def literal_D(rows):
    out=defaultdict(lambda:s.S.Zero)
    for row in rows:
        word=row['word'];vs=[n for n in word if n.startswith(('Ap','Bp'))]
        if len(vs)!=2 or not all(n.endswith('_0') for n in vs):continue
        a=int(next(n[2:] for n in word if n.startswith('ap')));C=int(next(n[2:] for n in word if n.startswith('Cp')));z=-num(row['coefficient'])
        for i,B in enumerate(vs):
            if not B.startswith('Bp'):continue
            V=vs[1-i];b=int(V[2:].split('_')[0])+(12 if V.startswith('Bp') else 0);j=int(B[2:].split('_')[0]);out[b,j,a,C]+=z
    return {key:clean(z) for key,z in out.items() if clean(z)!=0}
def indexed_D(P2):
    out=defaultdict(lambda:s.S.Zero)
    for (i,j),rows in P2:
        for B,V in [(i,j),(j,i)]:
            if B<12:continue
            for a,C,z in rows:out[V,B-12,a,C]+=num(z)
    return {key:clean(z) for key,z in out.items() if clean(z)!=0}
def pack(P):return [[v,a,C,str(clean(z))] for (v,a,C),z in sorted(P.items()) if clean(z)!=0]
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for pth,h in prep['input_sha256'].items():assert digest(Path(pth))==h,pth
    allowed={str(Path(pth).resolve()) for pth in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        path=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('DF_POLE_WRITE')
        if path.suffix=='.json' and str(path.resolve()) not in allowed:raise PermissionError('DF_POLE_PEER_OR_UNDECLARED '+str(path))
    sys.addaudithook(guard);print('STAGE '+role+' all_four_graded_units_two_probe_128_components',flush=True);route_ok=routing_proof();U,kernels,unitcontrols=units(role);print('UNITS '+json.dumps({k:v['coefficient'] for k,v in U.items()},sort_keys=True),flush=True)
    cp=ROOT/'calculations/canonical_so10_gauge_source_g2_color'/(role+'_result.json');cr=read(cp.parent/'validation_receipt.json');assert cr['input_sha256'][str(cp)]==digest(cp);col=read(cp);Fa=list(map(matrix,col['Fa_tensors']));Fc=list(map(matrix,col['Fc_tensors']));assert col['GF_inventory']['all4_derivative_Lorentz_copies_checked']
    oldp=ROOT/'calculations/canonical_so10_constant_background_operators'/(role+'_result.json');rr=read(oldp.parent/'validation_receipt.json');assert rr['input_sha256'][str(oldp)]==digest(oldp);old=read(oldp);ex=read(Path(prep['pure_classical_export']));D=literal_D(ex['vertices']['D_vectorpair_ghost']);Dr=indexed_D(old['P2']);assert D==Dr
    print('STAGE '+role+' full_actual_mixed_D_and_complete_color_derivative_tensors',flush=True);pieces={tag:defaultdict(lambda:s.S.Zero) for tag in U}
    if role=='primary':
        left={};right={}
        for kind,F in [('a',Fa),('c',Fc)]:
            Lm=defaultdict(list);Rm=defaultdict(list)
            for b in range(45):
                for (i,j),z in F[b].todok().items():Lm[b,j].append((i,z));Rm[b,i].append((j,z))
            left[kind]=Lm;right[kind]=Rm
        for (v,b,a,C),z in D.items():
            for kind in 'ac':
                wa=num(U['a'+kind]['coefficient']).subs(W,WH if b<12 else WM);wc=num(U['c'+kind]['coefficient']).subs(W,WH if b<12 else WM)
                for i,f in left[kind][b,a]:pieces['a'+kind][v,i,C]+=wa*f*z
                for j,f in right[kind][b,C]:pieces['c'+kind][v,a,j]+=wc*f*z
    else:
        grouped=defaultdict(dict)
        for (v,b,a,C),z in Dr.items():grouped[v,b][a,C]=z
        for (v,b),cells in grouped.items():
            Q=s.SparseMatrix(45,45,cells)
            for kind,F in [('a',Fa),('c',Fc)]:
                for branch,A in [('a',F[b]*Q),('c',Q*F[b])]:
                    weight=num(U[branch+kind]['coefficient']).subs(W,WH if b<12 else WM)
                    for (a,C),z in A.todok().items():pieces[branch+kind][v,a,C]+=weight*z
    parts={tag:pack(P) for tag,P in pieces.items()};rpart=defaultdict(lambda:s.S.Zero);qpart=defaultdict(lambda:s.S.Zero)
    for tag,rows in parts.items():
        for v,a,C,z in rows:
            qpart[v,a,C]+=num(z)
            if tag[0]=='a':rpart[v,a,C]+=num(z)
    R,Q=pack(rpart),pack(qpart);assert all(not num(z).has(s.Float) and s.simplify(num(z)-s.conjugate(num(z)))==0 for rows in [R,Q] for v,a,C,z in rows)
    dp=ROOT/'calculations/canonical_so10_ghost_companion_kernel_domain'/(role+'_v2_result.json');vr=read(dp.parent/'validation_receipt.json');assert vr['input_sha256'][str(dp)]==digest(dp);dom=read(dp);coverage={target:next(row for row in dom['targets'][target]['family_summary'] if row['family']==['D','F']) for target in ['A','B']};assert coverage['A']['cycles']==18 and coverage['B']['cycles']==40 and coverage['A']['profiles']==7 and coverage['B']['profiles']==16
    controls={'omit_assignment_a_changes_r_coefficient':bool(R),'omit_assignment_c_changes_q_coefficient':pack({key:pieces['ca'].get(key,0)+pieces['cc'].get(key,0) for key in set(pieces['ca'])|set(pieces['cc'])})!=[],'omit_derivative_Fa_changes_one_coefficient':bool(parts['aa']) or bool(parts['ca']),'omit_derivative_Fc_changes_one_coefficient':bool(parts['ac']) or bool(parts['cc']),'halve_graded_weight_changes_nonzero_result':bool(R) or bool(Q)}
    result={'schema':'ACTUAL_COMPLETE_DF_GHOST_COMPANION_POLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_DF_FAMILY_ONLY','units':U,'unit_kernels_and_Born_or_Wick_orders':kernels,'unit_controls':unitcontrols,'physical_divergence_vector_aC':R,'physical_vector_a_derivative_C':Q,'four_assignment_derivative_pieces':parts,'D_mixed_Hessian_positions':len(D),'literal_D_equals_full_qualified_P2':True,'full_positions_per_placement':57*45**2,'divergence_zero_complement':57*45**2-len(R),'ghost_derivative_zero_complement':57*45**2-len(Q),'coverage':coverage,'controls':controls,'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) [ (partial_mu V_v^mu) a_j R[v,j,l] C_l + V_v^mu a_j Q[v,j,l] partial_mu C_l ]; v=0..11 A_H,12..56 B; modulo the qualified F IBP currents; no extra ghost1/2','all128_probe_Lorentz_unit_positions_checked':True,'principal_BB_width_and_oriented_ghost_propagators_retained':True,'no_whole_scaleless_or_finite_IR_claim':True,'actual_complete_ghost_or_Ward_or_E5_A5_claimed':False,'current_Gamma_or_desired_Ward_or_primitive_or_peer_read':False,'functional_or_authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
