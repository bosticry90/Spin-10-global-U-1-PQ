# Complete actual DF mixed ghost/vector bubble V1

Baseline98c4ef9212c36a8e4b5cc1bf6c7b28b6c51c8104. Question DF1: what
is the complete ordinaryg3 DF contribution to both independent one-jet
AaC/BaC ghost companions? The qualified domain contains7AaC/16BaC
profiles and18/40 directed cycles. This closes the remaining two-vertex
family, not the three triangle families or complete ghost Ward relation.
Previous successful FR/DG3/DU poles do not determine this coefficient.

Freeze record/code/controllers/policy,actual F derivative/IBP tensors,
physical principal ghost/vector metric,complete P2 and literal quartic D,
their qualification receipts and full routed domain before computation.
Two sequential120-second-after-import/8GiB workers,350MiB minimum
available commit; one120-second/8GiB independent validator. Preserve
failures and complete captures. No automatic expansion/truncation,old
expensive replay,physical input change or fitted Ward coefficient.

Both quantum lines are an ordinary BB propagator and an oriented ghost
propagator. Build elementary vertices from the actual field order
  (partial a)*F_a*B*C + a*F_c*B*(partial C)
and D=a*P2(V,B)*C. The latter's mixed V/B derivative retains all equal-B
factors and all12 A_H plus45 B backgrounds. A_H is external,not integrated.
All four F Lorentz copies and the qualified boundary-current bridge remain.
Do not omit F_c or use an antighost-only derivative representation.

Calculate four elementary units before actual group tensors are released:
the external antighost or ghost is at F, and its derivative is on a or C.
Primary derives both graded-Hessian Born orders with the full supertrace;
replay uses explicit connected Wick pairings, external odd permutations
and shifted Feynman-parameter UV residues. The actual kinetic symbol is
+p^2 I in ordered a(-p)C(p),G_Ca=+1/p^2,G_aC=-1/p^2. BB retains its
transverse and symbolic longitudinal part. Do not infer weights from
directed-cycle counts or add an extra ghost1/2.

All-incoming external momenta are r for V,-r-q for a,q for C. If a is at
F the bubble depends on p=r+q; if C is at F it depends on p=q. Prove these
vertex equations and evaluate both r=0/q=0 formal probes with all16 vector/
momentum components each and a full4D loop. Retain both independent local
coefficients (partial V)*a*C and V*a*(partial C),modulo the one qualified
total-derivative relation. Use UV annulus or a separate auxiliary IR mass;
never infer a UV zero from the whole scaleless/exceptional integral.

Contract all actual45 quantum vector/ghost colors with the full mixed D
Hessian for57 external backgrounds. Primary literal quartic differentiation
and explicit sparse index products; replay independently qualified P2
coefficients and sparse matrix products. Match all D entries, both full
115425-position coefficient tensors and zero complements. Verify reality,
all12 constant-H covariance,all four Lorentz copies and actual support.
Canonical extraction/integration and the complete Ward test remain separate.

Controls omit either external assignment or derivative placement,change
the graded factor/odd order,drop transverse/longitudinal propagation or use
a false angular metric. Preserve insensitive cases, including a graph-
specific zero, rather than manufacturing sensitivity. Independent validation
must reconstruct the Gaussian/graded factors,UV units,full literal F/D
normalizations and actual color tensors by distinct contractions.

Outcome:actual full DF family pole or zero,input/normalization discrepancy,
or bounded inconclusiveness. No Gamma/primitive/desired ghost Ward or peer
answer is a calculation input. Preserve currentGamma147266/hashc445c2...,
38-source/auxiliary-H/bilinear scopes,nonzeroJacobian,32products,128source
jets,508programs,QAP/contact/Legendre/measure/IR/Legacy gaps,34/39,
HB1/C5block,flavorpause,C1_GS,quartet/scalar warnings,closedroutes,custody
exit2/seven. Fullghost/source-freeSlavnov/E5/A5/physicalviability unqualified.
No input,scheme,benchmark,foundation,policy,authority or remoteaction.
Sharedpremises/software/AIauthor limit independence;educationnonblocking,
Leanselective. No branch/worktree or external action.
