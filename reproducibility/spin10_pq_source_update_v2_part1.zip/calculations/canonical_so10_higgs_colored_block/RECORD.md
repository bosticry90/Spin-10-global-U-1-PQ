# Complete five-copy colored scalar submatrices: prospective contract V1

Baseline7031376471fc2a819f9bea6664b257f02828ad52, statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
Previous goal turn: PROGRESS, selected actual inputs and validation committed.
Scientific question: what do the complete mass and Higgs-squared coupling
submatrices of the colored vector-containing sector require beyond a single
component? This determines mixing and the cost of a later scalar ledger.
It is not a finite threshold, global viability verdict or blocked-stage run.

Select SM label(1,0,0,2), its conjugate, and all five copies. Reconstruct only
the highest-weight space at D5 weight(1,0,0,0,0): filter the252 possible wedge
selections before forming tensors, project both Hodge chiralities and solve
the three raising kernels. Check completeness against the existing characters
and independent dimensions, all raising operators and exact kinetic Gram.
Do not invoke the full328-field representative compiler. Rationally
orthogonalize within sectors, preserving all copies and both real tangents.

Reuse the saved18-denominator Higgs direction and physical point, with its
measured kinetic norm. Do not pretend it is exactly null. Extract the complete
10x10 real mass M and B=V''''[h,h,.,.]/2 on this highest-weight realification.
SU(3) invariance gives three identical color copies (30 real dimensions), not
three new independent amplitudes. This is a complete five-copy submatrix;
Higgs A/B couplings to other SM representations are outside it, so it is not
a closed fluctuation determinant suitable for a full finite match.

Primary route: retain all29 parent monomials in the t² coefficient of
V(v+t*x), and h²t² coefficient of its homogeneous quartic. Linearize the
existing paired five-form tensors and crossed graph before contraction.
Retain every mixed eta, K/T, complex and zero-coupled monomial. Evaluate all
55 real quadratic-form directions without selecting entries from predicted
zeros. Polarization gives all100 entries of each symmetric matrix.

Reference route: after the complete primary, select two diagonals and the
largest mixed entry for each matrix by the frozen deterministic rule; compare
all29 monomial coefficients against the unchanged on-demand derivative oracle.
Require exact equality, including zeros. Check exact unbroken-color Cartan
action on vacuum/Higgs/tangents and the resulting matrix complex structure.
Check paired positive eigenvalues, minimum0.103098893044171 within1e-12,
and recovery of both previous phi0 B diagonals and their exact zero mixing.
The older mass floor is a comparator, not a fitted matrix input.

Negative controls omit kinetic factors or physical eta mixing and must change
the selected matrix. Measure [M,B] without assuming it nonzero; if nonzero,
record that a simultaneous diagonal approximation loses actual couplings.
First discrepancy stops qualification. Freeze corrected attempts separately;
preserve all failed/incomplete records, never adjust parent physics to pass.

Original/fresh read-only workers require identical result bytes and the existing
350MiB immediate commit observation/8GiB private cap. No silent truncation.
Final validation independently checks Fraction basis metrics/coefficients,
numerical matrix/eigenstructure and projection arithmetic, source/input/state
integrity, fresh captures, predecessor receipts and exact local Git bytes.
Reuse prior authority/custody audits; no whole-workspace metadata inventory,
old full-Hessian replay or new physical gauge/EFT/IR/tadpole prescription.

Authority ceiling: this actual scalar submatrix only. Preserve all qualified,
failed, blocked and unresolved results; no state promotion, model refit, flavor
restart, branch/worktree/reset, push, publication or outreach. Physics and AI
capability are equal; education is voluntary and nonblocking. Shared action,
tensor primitives, software/data/analyst limit independence. This experiment
tests implementation and assumptions within the frozen construction, not
experimental support or independent expert endorsement.
