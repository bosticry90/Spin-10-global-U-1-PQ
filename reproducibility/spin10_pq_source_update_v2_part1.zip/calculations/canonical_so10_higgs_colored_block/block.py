"""Complete selected colored multiplicity submatrices, not a loop determinant."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from fractions import Fraction as F
import json,sys,time
import sympy as s
import mpmath as mp

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'canonical_so10_higgs_projected_vertices'))
import projected_v2 as prior
from compile_sm_multiplicity_representatives import VECTORS,RAISING,wedge,projected,choose_independent,highest_weights,kinetic_inner,add_obj,scale_obj,form_action
from decompose_sm_tangent import PHI,SIGMA,BAR_SIGMA,VEC,decompose
from evaluate_sm_hessian_blocks import rationalized_object,realified_representative
import coefficients as c
mp.mp.dps=80
NAMES=prior.ALL;LABEL=(1,0,0,2);WEIGHT=(1,0,0,0,0)

def digest(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def frac(z):return F(str(z))
def pair(z):
 a,b=s.sympify(z).as_real_imag();return frac(a),frac(b)
def unpack(a):
 assert a.Phi==s.zeros(10) and a.S==0
 return {i:(frac(u),frac(v)) for i,(u,v) in a.Sigma.items()},tuple(pair(z) for z in a.phi)
def pack(data):
 f,v=data
 return prior.State(s.zeros(10),{i:(s.Rational(z[0].numerator,z[0].denominator),s.Rational(z[1].numerator,z[1].denominator)) for i,z in f.items()},tuple(s.Rational(z[0].numerator,z[0].denominator)+s.I*s.Rational(z[1].numerator,z[1].denominator) for z in v),0)
def add(a,b):return c.formadd(a[0],b[0]),tuple(c.add(u,v) for u,v in zip(a[1],b[1]))
def sym(z):return s.Rational(z[0].numerator,z[0].denominator)+s.I*s.Rational(z[1].numerator,z[1].denominator)
def physical(raw,coef):return prior.hermitian({n:sym(raw[n]) for n in NAMES},coef)
def inner(a,b):return F(3,160)*c.dot(a[0],b[0])+2*c.vector_dot(a[1],b[1])[0]
def state_from_json(z):
 return prior.State(s.zeros(10),{tuple(i):(s.Rational(u),s.Rational(v)) for i,u,v in z['Sigma']},tuple(s.sympify(v) for v in z['phi']),0)

def representatives():
 raw=[]
 for selected in combinations(range(10),5):
  w=tuple(sum(VECTORS[k][0][j] for k in selected) for j in range(5))
  if w==WEIGHT:raw.append(wedge([VECTORS[k][1] for k in selected]))
 assert len(raw)==6
 result=[];counts={}
 for sector,char,eigen in [('Sigma',SIGMA,s.I),('SigmaBar',BAR_SIGMA,-s.I)]:
  target_weights=[w for w in char if w[0]>=w[1]>=w[2] and w[3]>=w[4] and (w[0]-w[1],w[1]-w[2],w[3]-w[4],2*sum(w[:3])-3*sum(w[3:]))==LABEL]
  assert target_weights==[WEIGHT]
  basis=choose_independent([projected(z,eigen) for z in raw],'form')
  found=highest_weights({WEIGHT:basis},'form')[LABEL];assert len(found)==decompose(char)[LABEL]
  orthogonal=[]
  for weight,obj in found:
   for old in orthogonal:obj=add_obj(obj,old,-kinetic_inner(old,obj,'form')/kinetic_inner(old,old,'form'))
   obj=rationalized_object(sector,obj);orthogonal.append(obj);result.append((sector,obj))
  counts[sector]=len(found)
 assert decompose(PHI).get(LABEL,0)==0 and decompose(VEC)[LABEL]==1
 for sector in ['phi','phiBar']:result.append((sector,VECTORS[0][1]));counts[sector]=1
 assert len(result)==5
 states=[]
 for sector,obj in result:
  a=realified_representative(sector,obj);states.extend([a.real,a.imag])
 data=[unpack(z) for z in states];gram=[[inner(a,b) for b in data] for a in data]
 assert all(gram[i][j]==0 if i!=j else gram[i][j]>0 for i in range(10) for j in range(10))
 return states,data,gram,counts

def action(data,G):
 f,v=data;fexpr={i:sym(z) for i,z in f.items()};fo=form_action(G,fexpr)
 return {i:pair(z) for i,z in fo.items()},tuple(pair(z) for z in G*s.Matrix([sym(z) for z in v]))

def clean(data):return {i:z for i,z in data[0].items() if z!=c.ZERO},tuple(data[1])
def negative(data):return {i:c.scale(z,-1) for i,z in data[0].items()},tuple(c.scale(z,-1) for z in data[1])

def matrix(func,data,label):
 diagonal=[func(a) for a in data];raw={n:[[c.ZERO for _ in data] for _ in data] for n in NAMES}
 for i in range(len(data)):
  print('STAGE '+label+'_quadratic_row_'+str(i),flush=True)
  for n in NAMES:raw[n][i][i]=c.scale(diagonal[i][n],2)
  for j in range(i):
   mixed=func(add(data[i],data[j]))
   for n in NAMES:
    z=c.add(c.add(mixed[n],c.scale(diagonal[i][n],-1)),c.scale(diagonal[j][n],-1));raw[n][i][j]=raw[n][j][i]=z
 return raw

def main():
 assert __debug__
 P=read(HERE/'preparation.json')
 for n,h in P['input_sha256'].items():assert digest(ROOT/n)==h,n
 writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('COLORED_BLOCK_WRITE_DENIED')
 sys.addaudithook(readonly)
 started=time.perf_counter()
 print('STAGE targeted_six_wedge_candidates_and_all_five_copies',flush=True)
 states,data,gram,counts=representatives();g=[gram[i][i] for i in range(10)]
 old=read(HERE.parent/'canonical_so10_higgs_projected_vertices/original_v2_result.json')
 h=unpack(state_from_json(old['precisions'][1]['h']));nh=inner(h,h)
 assert nh==F(old['precisions'][1]['norm_h_exact'])
 vacstate=prior.oracle.vacuum_state();vac=({i:(frac(u),frac(v)) for i,(u,v) in vacstate.Sigma.items()},(c.ZERO,)*10)
 G=s.zeros(10);G[0,1]=-1;G[1,0]=1;G[2,3]=1;G[3,2]=-1
 assert clean(action(h,G))==({},(c.ZERO,)*10) and clean(action(vac,G))==({},(c.ZERO,)*10)
 for i in range(0,10,2):
  assert clean(action(data[i],G))==clean(negative(data[i+1]))
  assert clean(action(data[i+1],G))==clean(data[i])
 print('STAGE complete55_quadratic_directions_mass_then_Higgs_B',flush=True)
 tick=time.perf_counter()
 Mraw=matrix(lambda x:c.quadratic_mass(x,vac,NAMES),data,'mass')
 mass_seconds=time.perf_counter()-tick;tick=time.perf_counter()
 Braw=matrix(lambda x:c.quadratic_higgs(x,h,NAMES),data,'B')
 B_seconds=time.perf_counter()-tick
 # Exact complex structure for every raw monomial, including zero couplings.
 for raw in [Mraw,Braw]:
  for n in NAMES:
   a=raw[n]
   for i in range(5):
    for j in range(5):
     assert a[2*i][2*j]==a[2*i+1][2*j+1] and a[2*i][2*j+1]==c.scale(a[2*i+1][2*j],-1),(n,i,j)
 coeff,b,ss=prior.parent_coefficients(s.Rational(old['point_w']))
 def numeric(raw,hnorm):
  return mp.matrix([[physical({n:raw[n][i][j] for n in NAMES},coeff)/(prior.number(s.Rational(g[i].numerator*g[j].numerator,g[i].denominator*g[j].denominator)).real**mp.mpf('.5')*hnorm) for j in range(10)] for i in range(10)])
 M=numeric(Mraw,1);B=numeric(Braw,mp.mpf(nh.numerator)/nh.denominator)
 eig,U=mp.eigsy(M);assert eig[0]>0 and abs(eig[0]-mp.mpf('0.103098893044171'))<mp.mpf('1e-12')
 assert max(abs(eig[2*i]-eig[2*i+1]) for i in range(5))<mp.mpf('1e-55')
 print('STAGE completed_primary_then_direct_oracle_selected_entries',flush=True)
 controls=[]
 for kind,raw,num in [('M',Mraw,M),('B',Braw,B)]:
  choices=[(0,0),(6,6)]
  cross=max(((i,j) for i in range(6) for j in range(6,10)),key=lambda ij:abs(num[ij[0],ij[1]]))
  choices.append(cross)
  for i,j in choices:
   directions=[states[i],states[j]] if kind=='M' else [pack(h),pack(h),states[i],states[j]]
   actual=prior.oracle.directional_vertex_coefficients(directions)
   factor=1 if kind=='M' else 2
   for n in NAMES:assert s.simplify(actual[n]-factor*sym(raw[n][i][j]))==0,(kind,i,j,n)
   controls.append({'kind':kind,'indices':[i,j],'all29_monomial_differences':'0','canonical_entry':prior.text(num[i,j]),'raw_coefficients':{n:str(sym(raw[n][i][j])) for n in NAMES}})
 # Recover both earlier real phi0 slice entries by exact projection, including mixing.
 projections=[]
 for z in [1,s.I]:
  v=[0]*10;v[0]=z;x=unpack(prior.State(s.zeros(10),{},tuple(v),0));coords=[inner(a,x)/g[i] for i,a in enumerate(data)]
  rebuilt=pack(({},(c.ZERO,)*10))
  for ci,st in zip(coords,states):rebuilt=prior.oracle.add_state(rebuilt,prior.oracle.scale_state(st,s.Rational(ci.numerator,ci.denominator)))
  assert unpack(rebuilt)==x
  projections.append([mp.mpf(ci.numerator)/ci.denominator*mp.sqrt(mp.mpf(g[i].numerator)/g[i].denominator)/mp.sqrt(2) for i,ci in enumerate(coords)])
 recovered=[[sum(projections[i][k]*B[k,l]*projections[j][l] for k in range(10) for l in range(10)) for j in range(2)] for i in range(2)]
 for i in range(2):
  for j in range(2):assert abs(recovered[i][j]-mp.mpf(old['precisions'][1]['canonical_colored_B_slice'][i][j]))<mp.mpf('1e-55')
 eta=mp.matrix([[physical({n:Mraw[n][i][j] if n=='zEta' else c.ZERO for n in NAMES},coeff)/mp.sqrt(mp.mpf(g[i].numerator)/g[i].denominator*mp.mpf(g[j].numerator)/g[j].denominator) for j in range(10)] for i in range(10)])
 omit_eta=max(abs(z) for z in eta);omit_metric=max(abs(physical({n:Mraw[n][i][j] for n in NAMES},coeff)-M[i,j]) for i in range(10) for j in range(10))
 assert omit_eta>mp.mpf('1e-10') and omit_metric>mp.mpf('1e-10')
 comm=M*B-B*M;commnorm=mp.sqrt(sum(z*z for z in comm));Beig=U.T*B*U;offnorm=mp.sqrt(sum(Beig[i,j]**2 for i in range(10) for j in range(10) if i!=j))
 for n,hsh in P['input_sha256'].items():assert digest(ROOT/n)==hsh,n
 assert not writes
 result={'schema':'HIGGS_COLORED_FIVE_COPY_SUBMATRICES_V1','status':'COMPLETE_SELECTED_MASS_AND_B_SUBMATRICES_ONLY','label':list(LABEL),'weight':list(WEIGHT),'sector_copies':counts,'real_representative_dimension':10,'SU3_color_degeneracy':3,'real_full_multiplet_dimension':30,'Gram_diagonal':[str(z) for z in g],
 'basis':[prior.serialize(z) for z in states],'h_norm_exact':str(nh),'M':[[prior.text(M[i,j]) for j in range(10)] for i in range(10)],'B':[[prior.text(B[i,j]) for j in range(10)] for i in range(10)],'mass_eigenvalues':[prior.text(z) for z in eig],'mass_basis_B':[[prior.text(Beig[i,j]) for j in range(10)] for i in range(10)],'mass_basis_B_off_diagonal_Frobenius':prior.text(offnorm),'mass_B_commutator_Frobenius':prior.text(commnorm),'selected_oracle_comparisons':controls,'previous_phi0_B_recovered':[[prior.text(z) for z in row] for row in recovered],
 'raw_M_monomials':{n:[[str(sym(z)) for z in row] for row in mat] for n,mat in Mraw.items()},'raw_B_monomials':{n:[[str(sym(z)) for z in row] for row in mat] for n,mat in Braw.items()},'negative_controls':{'omit_eta_mass_max_difference':prior.text(omit_eta),'omit_kinetic_metric_mass_max_difference':prior.text(omit_metric)},'all55_quadratic_directions_per_matrix':True,'all29_monomials_included':True,'color_Cartan_and_exact_complex_structure_checked':True,'input_sha256':P['input_sha256'],'state_sha256':P['state_sha256'],'write_attempts':writes,'finite_threshold_calculated':False,'closed_Higgs_fluctuation_determinant':False,'scientific_authority_changed':False,'whole_goal_complete':False}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
 print('METRICS '+json.dumps({'mass_seconds':mass_seconds,'B_seconds':B_seconds,'total_seconds':time.perf_counter()-started,'paired_tensor_cache':str(c.pairs.cache_info()),'linearized_pair_cache':str(c.cross_pairs.cache_info()),'trilinear_cache':str(c.tri.cache_info())},sort_keys=True),flush=True)

if __name__=='__main__':main()
