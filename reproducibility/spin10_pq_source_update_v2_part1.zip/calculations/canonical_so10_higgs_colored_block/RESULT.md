# Complete colored five-copy mass and Higgs-coupling submatrices

The vector-containing colored sector has five interacting copies, and its
Higgs couplings are appreciably off diagonal in the mass basis. A future loop
calculation cannot replace them with five separate diagonal couplings.
This is an actual scalar-input result; no finite threshold is calculated.
Qualification requires the completed [validation receipt](validation_receipt.json).

The calculation reconstructs only the SM highest-weight space(1,0,0,2),
namely(3,1,Y=1/3), and its physical realification. Six candidate wedge tensors
at D5 weight(1,0,0,0,0), Hodge projection and three raising kernels give
two Sigma copies, one SigmaBar, one phi and one phiBar. Rational orthogonalization
and the actual kinetic metric retain all five copies. Ten real representative
directions give the full5x5 Hermitian multiplicity matrices; unbroken SU(3)
symmetry supplies three identical color copies, totaling30 real dimensions.
No full328-field basis was rebuilt. The conjugate is included by realification,
not counted as another30 independent real fields.

At the unchanged positive benchmark the five distinct squared masses are:

| m², internal omega²=60 | m²/omega² |
| --- | --- |
| 0.103098893044170696 | 0.001718314884069512 |
| 0.538112662221187013 | 0.008968544370353117 |
| 4.762703678639478071 | 0.079378394643991301 |
| 74.28295944361785460 | 1.23804932406029758 |
| 77.16284243709361576 | 1.28604737395156026 |

Each occurs twice in the real representative matrix and six times including
color. The minimum reproduces the previously qualified colored floor, without
using that floor to construct or adjust any entry. This does not requalify
the entire spectrum, global scalar stability, or a physical pole-mass prediction.

With canonical real fields, write the selected scalar Hessian submatrix as
M+h²B, B=V''''[h,h,.,.]/2. The saved rational Higgs direction's measured norm
is retained. The full M and B, exact29-monomial decompositions, selected
reference entries and mass-basis B are in original_result.json. Their exact
unbroken-color Cartan/complex-structure identities hold separately for every
monomial, including zero-coupled terms. Both earlier real/imaginary phi0 B
diagonals0.00026282076033999246717 and0.19928312054884654201, and their
zero mixing, are recovered by explicit projection into this larger space.

The canonical representative commutator has
||M B-B M||_F=4.91108479424601156 in the internal mass-squared units.
In the mass basis, ||B_off||_F=0.146320121560362460, versus
||B||_F approximately0.2918518288. Thus a diagonal approximation removes
actual interactions. These matrix norms are diagnostics, not an estimated
percentage of a physical threshold. A negative B entry is a mixed quartic
coefficient, not a tachyon: the frozen M eigenvalues above remain positive.

The primary calculation evaluates all55 real quadratic-form directions for
each matrix, retaining all29 parent monomials before Hermitian completion.
Linearized paired tensors give the quadratic scalar forms directly, rather
than repeatedly sampling the complete potential. Only after the complete
primary does the existing derivative oracle check two diagonals and the
largest Sigma/vector mixed entry of each matrix. All174 selected monomial
coefficients agree exactly, including zeros. These are coefficient comparisons,
not174 independent physical amplitudes. Omitting eta mixing changes a mass
entry by1.01823376491; omitting the kinetic metric changes one by75.3982303007.

The original required about5.30sec for the full mass coefficients and6.85sec
for B; total111.85sec includes basis construction, exact checks and the
selected direct-oracle comparisons. Peak observed private allocation was
2.388GB, below8GiB. This establishes a cheaper route for this restricted
subspace, not a runtime guarantee for a full scalar compiler. Original/fresh
result bytes must match. Separate validation uses Fraction basis metrics,
Decimal reconstruction of all200 real canonical matrix slots and NumPy
eigenvalue/pair-projector checks. Existing completed authority/custody receipts
are authenticated, without replaying expensive prior physics.

The two routes share the action, lower tensor contractions, representation
conventions, data, software and analyst. Different coefficient extraction and
arithmetic can expose implementation errors; they cannot independently validate
the physical assumptions or constitute external scientific endorsement.
For AI capability, this demonstrates bounded use of a complete representation
space and detection of substantial noncommuting mixing, with those limits.
Director education remains voluntary and nonblocking.

This submatrix is not a closed Higgs-dependent fluctuation operator. Cubic
one-Higgs A vertices connect these singlets to colored weak doublets, including
potential gauge-orbit zero modes. Other B blocks, tree heavy relaxation,
finite kinetic/mixing/tadpole terms, gauge/fermion effects and physical EFT/IR
prescriptions remain needed for a full finite Higgs match. No prediction,
naturalness mechanism or benchmark rescue follows from the present result.

Next smallest useful test: evaluate the finite scalar BB bubble associated
with these positive masses and full B, under a separately frozen contract,
as a restricted MSbar one-particle-irreducible diagnostic at a declared scale.
Compare spectral divided differences with an independent matrix/integral route
and quantify the error from dropping off-diagonal B. This can connect the
new inputs to an actual bounded loop contribution cheaply. It is not the
matched Higgs threshold and cannot close the known quartic gap. Preserve the
missing A/relaxation/Z/tadpole/EFT/gauge/fermion obligations; no stage unlock.

Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.
FullE5/A5 unqualified; HB1/C5 blocked; C1_GS uncalculated; quartetFAIL,
flavor pause, fullBFB limitation and custodyexit2/seven unresolved preserved.
Broad goal active/incomplete. No refit, old physics replay, workspace-wide
metadata inventory, branch/worktree/reset, push, publication or outreach.
