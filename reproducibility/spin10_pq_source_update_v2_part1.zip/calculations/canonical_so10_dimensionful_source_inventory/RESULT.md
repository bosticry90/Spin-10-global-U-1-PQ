# Dimensionful source frontier: two coefficient groups remain

Execution/qualification is conditional on the completed validation receipt,
not this prospective report. Baseline ed29f42; authority v113/34of39 unchanged.

The literal full-Cartesian proper-loop envelope gives:

| No-jet target | Coefficient dimension | Conservative graph classification |
|---|---:|---|
| Ja | 2 | No proper graph support |
| Ja*x | 1 | No proper graph support |
| JL*C | 2 | Two power-degree2 families retained; no mass-dependent log route |
| JL*C*x | 1 | Two log families / four H-M-and-sector profiles, g10^4*xi |
| Jx*C | 1 | Two log families / six H-M-and-sector profiles, g10^3*xi |

These are support statements in the frozen full-x reference expansion, not
measured coefficients or complete fluctuation-vacuum amplitudes. Generator,
color and Lorentz correlations are relaxed outward. Surviving profiles need
actual contractions; some may subsequently vanish. The two routes examine127
candidate families and agree on all supported profiles. Counts are catalogue
sizes, not numbers of measured processes or independent quantum integrals.

Recovered inputs include35162 source rows,33092 GF rows and all34 physical
AST terms. There are225 source rows with zero integrated Hessian; all stored
scalar-source columns are bilinear C*x. Positive GF inputs are432 quadratic
L_M*x terms and6688 cubic a_M*C_M*x terms, supported only in Phi/Sigma.
Physical dimensionful inputs include all four mass-squared parameters and
the cubic muPhi, muPhiPhi, z6_Re and z6_Im terms. The latter are not discarded
because of their names. All643 inverse directions and scalar-sector support
are retained. Principal quadratics are in the reference; negative reference
mass subtractions and subleading mass expansions are explicitly represented.
Neither reference-mass terms nor physical masses/cubics have a compatible
route into the surviving logarithmic profiles in this envelope.

Remaining logarithmic families, with each source counted once:

- JL*C*x: source KL plus the orbit ghost/scalar vertex; or source SL,
  ghost/vector F, orbit quadratic L*x, and scalar kinetic B*x*x.
- Jx*C: source SX plus the orbit ghost/scalar vertex; or source SX,
  ghost/vector F and orbit quadratic L*x.

Both groups involve one explicit xi orbit vertex, not a width inferred from
ordinary B/B propagation; no surviving graph uses a B/B reference edge.
This fact is confined to this inventory and is not general width independence.

JL*C retains the KL one-vertex ghost tadpole and SL-F bubble, both g10^2,
with superficial degree2 and no scalar reference edge. These are not declared
zero finite-cutoff amplitudes or scaleless UV zeros. The earlier qualified
JL*Box C calculation explicitly leaves mass/cutoff-power no-jet amplitudes
unqualified. No Taylor exclusion is transferred to this target.

Coordinate and evidence boundary: x is the full Cartesian field in the
serialized BV, GF and physical AST. Rewriting x=v+eta also produces VEV terms
from already-qualified dimension-zero source operators, including the leading
g10^2*xi scalar-source pole and ordinary g10^3 scalar-source pole. Those known
translations must be combined exactly once with new intrinsic coefficients;
they do not measure the new g10^3*xi Jx*C or g10^4*xi JL*C*x contributions.
No mixed convention or automatic full source-completeness claim is permitted.

The first replay failed before enumeration because it lacked primary-only
architecture prose. V2 preserves the failure and makes only that metadata
read optional; actual columns/reference/action checks remain mandatory.
The completed V1 primary is reused. Primary and corrected replay take about
2.68 and2.37 seconds after imports. No old pole, Gamma, Q or Ward was replayed.
Independent cycle/pairing routes share inputs, some support utilities and AI
authorship; validation is computational corroboration, not expert validation.

Orbit-cubic and orbit-quadratic omissions change both outstanding target
groups. Removing KL exposes the retained tadpole and its logarithmic companion.
Forbidden H/M ghost propagation opens otherwise excluded support. Reference-
subtraction omission is insensitive for these targets, and mass expansion is
inapplicable to the retained power graphs because they have no scalar edge.
Do not describe those insensitive controls as normalization tests.

Next smallest action: recover the actual orbit quadratic/cubic tensors and
their graded signs, source tensors, scalar kinetic tensor and mixed reference
bridges, then calculate the two complete candidate groups using independent
unit integrals and color contractions. Start with the smaller Jx*C group;
do not infer it from a desired Slavnov cancellation. First preserve full-x
versus fluctuation specialization and the existing positive-dimensional Q
terms. Power subtraction, QAP, measure, finite contacts, IR removal and full
simultaneous source/Slavnov/E5/A5 closure remain separate prerequisites.

No benchmark, accepted physical input, foundation, authority or remote changes.
HB1/C5 blocked; flavor paused; C1_GS uncomputed; scalar quantum-control warning,
quartet failure and historical custody exit2/seven preserved. Track A narrows
the actual next coefficient problem; Track B demonstrates useful inventory
and UV/IR/coordinate discrimination with a preserved metadata-schema failure.
Education remains concurrent, voluntary and nonblocking.
