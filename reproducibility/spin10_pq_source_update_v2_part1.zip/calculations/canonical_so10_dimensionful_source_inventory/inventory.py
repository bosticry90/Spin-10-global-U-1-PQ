"""Conservative full-Cartesian dimensionful source support; no pole values."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import combinations_with_replacement,product,permutations
import importlib.util,json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
front=module('qualified_source_frontier',ROOT/'calculations/canonical_so10_single_source_uv_frontier/frontier.py')
lib=front.lib;PKG=front.PKG;D=front.DIMENSION;T=front.ROLE_TYPE
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
TARGETS=[(['Ja'],2),(['Ja','x'],1),(['C','JL'],2),(['C','JL','x'],1),(['C','Jx'],1)]
SECTORS=('Phi','Sigma','phi','S')
@lru_cache(None)
def role1(n):
    m=re.fullmatch(r'(J?x)_(Phi|Sigma|phi|S)_(\d+)',n)
    return ('Y_' if m[1]=='Jx' else 'X_')+m[2] if m else front.role_primary(n)
MEM=front.membership()
for sec in SECTORS:
    for i in range(front.DIM[sec]):MEM['x_'+sec+'_'+str(i)]='X_'+sec;MEM['Jx_'+sec+'_'+str(i)]='Y_'+sec
def role2(n):assert n in MEM,n;return MEM[n]
def key(types):return '_'.join(sorted(types))
def coarse(ports):return Counter(T[r[0]] for r,j in ports)

def census(route):
    parse,role,powers=(lib.parse1,role1,lib.powers1) if route=='primary' else (lib.parse2,role2,lib.powers2)
    vertices={};counts=Counter();quadratic=Counter();rawpositive=Counter();source_lengths=Counter();physical_params=set();physical_nodes=Counter()
    def retain(fields,gp,xp,origin,params=()):
        fields=tuple(sorted(fields));cd=4-sum(D[r[0]]+j for r,j in fields);assert cd>=0,(origin,fields)
        counts[origin+'_cd'+str(cd)]+=1
        integrated=sum(r[0] in front.QUANTUM_LETTERS for r,j in fields)
        if origin=='source':
            source_lengths[len(fields)]+=1
            if integrated<2:counts['source_zero_integrated_Hessian']+=1;return
            src=[r[0] for r,j in fields if r[0] in front.SOURCE_LETTERS];assert len(src)==1
            name={'V':'SB','Y':'SX','R':'SC','E':'SA','J':'KL' if len(fields)==4 else 'SL'}[src[0]]
        elif len(fields)==2 and cd==0:quadratic[origin]+=1;return
        elif cd:
            rawpositive[(origin,cd,len(fields))]+=1
            name={('GF',2):'O_LX',('GF',3):'O_aCX',('physical',2):'P2',('physical',3):'P3',('reference_subtraction',2):'REF_SUB'}[(origin,len(fields))]
        else:name=lib.tag(fields,gp,xp)
        tag=f'{name}_g{gp}_e{xp}_c{cd}_n{len(fields)}_j{sum(j for r,j in fields)}'
        if tag not in vertices:vertices[tag]={'base':name,'g':gp,'xi':xp,'cd':cd,'degree':len(fields),'source_type':next((T[r[0]] for r,j in fields if r[0] in front.SOURCE_LETTERS),None),'origin':origin,'ports':set(),'parameters':set()}
        v=vertices[tag];assert v['origin']==origin;v['ports'].add(fields);v['parameters'].add(tuple(sorted(params)))
    for origin,suffix,k in [('source','bv_master','source_polynomial'),('GF','e2_transport','gauge_fixing_density')]:
        data=read(PKG/f'frozen_a10_{suffix}/{route}.json');rows=data[k];counts[origin+'_rows']=len(rows)
        if origin=='source':
            architecture=data['architecture'];assert 'x=v+eta' in architecture['scalar_split']
            scalar_columns=data['source_only_columns'];assert all(len(row['word'])==2 for n,rows1 in scalar_columns.items() if n.startswith('x_') for row in rows1)
        for row in rows:
            fields=[(role(n),len(j)) for n,j in map(parse,row['word'])]
            for gp,xp in powers(row['coefficient']):retain(fields,gp,xp,origin)
    action=read(PKG/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');assert len(action['local_terms'])==34
    def checknode(n):
        if isinstance(n,list):
            for x in n:checknode(x)
        elif isinstance(n,dict):
            if 'node' in n:physical_nodes[n['node']]+=1
            assert n.get('node')!='FrozenBackground','EXPLICIT_PHYSICAL_VEV_REQUIRES_NEW_TYPED_HANDLING'
            for x in n.values():checknode(x)
    checknode(action['local_terms'])
    walk=lib.physical1 if route=='primary' else lib.physical2
    alias={n:'X_'+sec for sec in SECTORS for n in [sec,sec+'Bar','x_'+sec]}
    support=set()
    for term in action['local_terms']:
        for params,fields,cd in walk(term):
            physical_params.update(params);assert cd==4-sum(1+j for n,j in fields),(fields,cd)
            support.add((tuple(sorted(params)),tuple(sorted(fields)),cd))
    # Deduplicate expanded AST branches after recording support, so parser multiplicity
    # is not mistaken for a distinct vertex. It is never used as a Feynman factor.
    for params,fields,cd in sorted(support):
        for assignment in product(*([('BH',j),('BM',j)] if n=='B' else [(alias[n],j)] for n,j in fields)):
            retain(assignment,params.count('g10'),0,'physical',params)
    refdata=read(PKG/f'frozen_a10_e5_full_hessian/{route}.json');ref=refdata['retained_reference'];assert refdata['complete_Hessian_and_reference_qualified'] and ref['all643_inverse_directions_both_checked'] and ref['literal_GF_all_413449_entries_matched'] and ref['auxiliary_auxiliary_Green_zero']==45
    assert not ref['scalar_reference_masses_are_adopted_physical_parameters']
    program=refdata['finite_cutoff_loop_program'];assert program['mass_reference_differences']=='subtract their reference quadratic terms from interactions exactly; the original34 potential parameters remain symbolic and unchanged'
    names=ref['field_order'];roles=[role(n) for n in names];assert Counter(r[0] for r in roles)=={'B':180,'L':45,'a':45,'C':45,'X':328}
    edges={(roles[i],roles[j]) for i,j,z in ref['reference_Green_raw_C3']['entries'] if z!='0'}
    expected={('BH','BH'),('BM','BM'),('BH','LH'),('LH','BH'),('BM','LM'),('LM','BM'),('CH','aH'),('aH','CH'),('CM','aM'),('aM','CM')}|{('X_'+sec,'X_'+sec) for sec in SECTORS};assert edges==expected
    for sec in SECTORS:retain([('X_'+sec,0)]*2,0,0,'reference_subtraction',('Mref_'+sec+'_squared',))
    for v in vertices.values():v['ports']=sorted(v['ports']);v['parameters']=sorted(v['parameters'])
    return vertices,edges,{'literal_counts':dict(counts),'absorbed_principal_quadratic_rows':dict(quadratic),'positive_input_counts':[{'origin':a,'cd':b,'degree':c,'rows':v} for (a,b,c),v in sorted(rawpositive.items())],'source_lengths':dict(source_lengths),'physical_support':[list(v) for v in sorted(support)],'physical_parameter_names':sorted(physical_params),'physical_AST_node_counts':dict(physical_nodes),'reference_edges':sorted(edges),'architecture':architecture,'reference_program':{k:program[k] for k in ['interaction_one_loop_program','mass_reference_differences','IR_domain']},'full_x_scalar_columns_bilinear':True}

def families(vertices,types,cd):
    src=next(t for t in types if t.startswith('J'));ordinary=sorted(t for t,v in vertices.items() if v['source_type'] is None)
    for s,v in vertices.items():
        if v['source_type']!=src:continue
        for n in range(4):
            for rest in combinations_with_replacement(ordinary,n):
                tags=(s,*rest)
                if sum(vertices[t]['degree']-2 for t in tags)==len(types) and sum(vertices[t]['cd'] for t in tags)<=cd:yield tags

def loops(tags,opts,types,cd,vertices,edges,route,keep_witness=True):
    profiles=set();witness={};n=len(tags);vc=sum(vertices[t]['cd'] for t in tags)
    orders=sorted(set((tags[0],*p) for p in permutations(tags[1:]))) if route=='primary' else [tags]
    for order in orders:
        for cfg in front.configs(order,opts,types,0):
            ports0=[c[0] for c in cfg]
            arrangements=(([(p[::-1] if f else p) for p,f in zip(ports0,flips)],[(2*i+1,2*((i+1)%n)) for i in range(n)]) for flips in product([False,True],repeat=n)) if route=='primary' else ((ports0,pairs) for pairs in front.proper(n))
            for ports,pairs in arrangements:
                flat=[p for row in ports for p in row]
                if not all((flat[a][0],flat[b][0]) in edges for a,b in pairs):continue
                uv=4+sum(j for r,j in flat)+sum(D[flat[a][0][0]]+D[flat[b][0][0]]-4 for a,b in pairs);assert uv==cd-vc,(order,uv,cd,vc)
                outer=tuple(sorted(r for inner,out in cfg for r,j in out));scalar_edges=tuple(sorted({flat[a][0][2:] for a,b in pairs if flat[a][0].startswith('X_')}));BB=tuple(sorted(flat[a][0] for a,b in pairs if flat[a][0][0]==flat[b][0][0]=='B'))
                # Only cd2 remains available; at most one mass-squared expansion.
                labels=[('NONE',uv)]
                if uv>=2:labels += [('REF_EXPAND_'+sec,uv-2) for sec in scalar_edges]
                for expansion,u in labels:
                    p=(outer,vc,uv,expansion,u,BB,scalar_edges);profiles.add(p)
                    if keep_witness:witness.setdefault(p,{'vertices':order,'internal_ports':ports,'external_ports':[c[1] for c in cfg],'pairs':pairs})
    def encode(p):return {'external_roles':p[0],'vertex_cd':p[1],'raw_UV_degree':p[2],'propagator_mass_expansion':p[3],'remaining_UV_degree':p[4],'BB_edges':p[5],'scalar_edge_sectors':p[6],'classification':'LOG_SUPPORT_UNKNOWN_COEFFICIENT' if p[4]==0 else 'POWER_SUPPORT_NOT_A_LOG_ZERO_THEOREM'}
    return [encode(p) for p in sorted(profiles)],[{'profile':encode(p),**witness[p]} for p in sorted(witness)]

def evaluate(vertices,edges,types,cd,route,controls=False):
    opts=front.options({t:{**v,'literal_role_monomials':v['ports']} for t,v in vertices.items()},types,0);result={};witnesses={};candidates=0
    for tags in families(vertices,types,cd):
        candidates+=1;p,w=loops(tags,opts,types,cd,vertices,edges,route,not controls)
        if p:
            name='*'.join(tags);result[name]={'g':sum(vertices[t]['g'] for t in tags),'explicit_xi':sum(vertices[t]['xi'] for t in tags),'profiles':p};witnesses[name]=w
    return result,witnesses,candidates

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][route]}|{str((OUT/'preparation.json').resolve())}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('DIMENSIONFUL_INVENTORY_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('UNDECLARED_JSON '+str(p))
    sys.addaudithook(guard)
    print('STAGE '+route+' literal_positive_dimension_inputs',flush=True);vertices,edges,inputs=census(route)
    answers={}
    for types,cd in TARGETS:
        name=key(types);print('STAGE '+route+' '+name,flush=True);table,w,candidates=evaluate(vertices,edges,types,cd,route)
        logs=sum(p['classification']=='LOG_SUPPORT_UNKNOWN_COEFFICIENT' for v in table.values() for p in v['profiles']);powers=sum(p['classification']!='LOG_SUPPORT_UNKNOWN_COEFFICIENT' for v in table.values() for p in v['profiles'])
        answers[name]={'types':types,'cd':cd,'candidate_families':candidates,'supported_families':table,'witnesses':w,'log_profiles':logs,'power_profiles':powers,'status':'MISSING_LOG_COEFFICIENT_INPUTS' if logs else ('NO_LOG_SUPPORT_POWER_PROFILES_RETAINED' if powers else 'STRUCTURAL_ZERO_IN_FULL_X_REFERENCE_ENVELOPE')}
    print('STAGE '+route+' negative_controls',flush=True);controls={}
    variants={'omit_orbit_cubic':({t:v for t,v in vertices.items() if v['base']!='O_aCX'},edges),'omit_orbit_quadratic':({t:v for t,v in vertices.items() if v['base']!='O_LX'},edges),'omit_KL_tadpoles':({t:v for t,v in vertices.items() if v['base']!='KL'},edges),'omit_reference_subtraction':({t:v for t,v in vertices.items() if v['base']!='REF_SUB'},edges),'forbidden_HM_ghost':(vertices,edges|{('CH','aM'),('aM','CH'),('CM','aH'),('aH','CM')})}
    for label,(vs,es) in variants.items():
        changes={}
        for types,cd in TARGETS:
            table,unused,c=evaluate(vs,es,types,cd,route,True);base=answers[key(types)]['supported_families'];changes[key(types)]=table!=base
        controls[label]=changes
    assert any(controls['omit_orbit_cubic'].values()) and any(controls['omit_KL_tadpoles'].values())
    print('RESULT '+json.dumps({'schema':'DIMENSIONFUL_SOURCE_GRAPH_INVENTORY_V1','route':route,'vertices':vertices,'inputs':inputs,'targets':answers,'controls':controls,'proper_matching_counts':{str(n):len(front.proper(n)) for n in range(1,5)},'physical_color_and_Lorentz_correlations_relaxed_outward':True,'coordinate_domain':'FULL_CARTESIAN_X_WITH_SEPARATE_LATER_VEV_SPECIALIZATION','new_pole_computed':False,'old_Gamma_Q_Ward_replayed':False,'full_source_E5_A5_QAP_IR_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
