# Replay metadata correction V2

The V1 primary completed. V1 replay failed before enumeration: the inherited
BV replay JSON omits primary-only `architecture` prose. Preserve inventory.py,
its snapshot/preparation and both captures unchanged. This is a metadata-schema
assumption failure, not a graph result. No retry was automatically authorized
under V1; this frozen bounded continuation uses current standing delegation.

V2 checks architecture prose when present and records its absence on replay.
Both routes still directly check every actual scalar-source column is C*x,
all full-x physical AST terms, all source/GF terms, reference inverses and every
graph/dimension/control requirement. Compare mathematical inventories completely;
authenticate role-specific metadata separately rather than require nonexistent
prose. Reuse the completed V1 primary and run only corrected replay, same
120-second/8GiB/minimum350MiB limits. No physical input or calculation claim changes.
