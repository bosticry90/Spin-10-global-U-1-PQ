# Mass/VEV source proper-graph inventory V1

Baseline ed29f42824c87638c766c46136194bb0ef70dacb. Standing AGENTS delegation;
authority v113/34of39 unchanged. Question: which proper one-loop mass-dependent
local logarithmic source coefficients remain unsupported after the completed
dimension-zero catalogue? Least expensive competent test: recover literal
positive-dimensional inputs and enumerate support before evaluating any pole.
Possible outcomes are structural exclusions, allowed unknown coefficients, or
an explicit prescription/input boundary. No coefficient is fitted to an identity.

Targets in the retained dim<=4, ghost-zero, even local ring, no jets:
Ja(cd2), Ja*x(cd1), JL*C(cd2), JL*C*x(cd1), Jx*C(cd1). Full Cartesian x is the
variable in the serialized BV/GF/physical polynomials. Keep all four scalar
sectors, H/M ghost and vector support and all 643 reference directions.
Specializing x=v+eta also translates known dimension-zero operators into
VEV-dependent lower-degree terms; those are distinct from intrinsic positive-
coefficient-dimension operators. Do not shift only one action block or call
this full-x inventory a completed fluctuation-vacuum amplitude.

Recover all source/GF rows and all34 physical-action AST terms, including
quadratic masses, cubic dimensionful couplings and OrbitPullback vertices.
Dimension-zero principal quadratics are in the qualified reference. Explicitly
include the negative scalar-reference quadratic subtraction and tagged
subleading scalar-reference mass expansion, each dimension2. They are not new
physical inputs. No inverse mass or coupling is allowed. Source rows with fewer
than two integrated legs have zero source Hessian, not a new loop amplitude.
One-vertex source-quartic tadpoles remain in the proper graph inventory.

For a proper one-loop graph every vertex has two internal ports. The external
count is sum(valence-2). At most target coefficient dimension worth of positive
insertions is allowed; all remaining vertices have positive external count.
This bounds the graph length by four for these five targets. Independent
oriented-cycle and connected Wick-pairing routes must agree on complete
family/HM/sector/g/explicit-xi/UV-degree profiles. Physical color/generator and
Lorentz correlations may only be relaxed outward: surviving graphs are
candidates, not proved nonzero. Missing graphs in this enlarged support are
structural exclusions within the declared full-x reference expansion.

Track superficial degree explicitly. A logarithmic no-jet mass-dependent
profile requires total vertex/propagator-expansion coefficient dimension equal
to the target's. Retain lower-dimension power profiles separately; do not equate
a scaleless integral's total zero with its UV pole, nor reuse JL*Box C Taylor
zeros for JL*C. Reference expansion/subtraction are separate labels, never
assumed to cancel merely from support. No IR removal, finite-cutoff power
amplitude, finite tadpole or full physical pole is calculated here.

Controls remove the positive cubic/quadratic orbit vertices, add forbidden H/M
ghost propagation, remove source-quartic tadpoles and omit reference mass
terms. Report insensitive controls honestly. A manual validator checks input
authentication, full paired tables, graph witnesses and dimensional budgets;
it does not independently establish the shared action or regulator premises.

Two sequential workers capped at120 seconds after imports and sampled8GiB,
minimum350MiB available commit; separate120-second/8GiB validation. Freeze
source/controller/inputs/own-role JSON allowlists first. Preserve every failed
or incomplete run and version corrections; no automatic resource expansion.
No old pole, large Gamma, Q or Ward replay. Existing BV failure is not promoted:
authenticate its literal columns and later qualified Hessian/reference scopes,
not a full master theorem. Reuse historical policy at its recorded checkpoint.

Ceiling: a conservative dimensionful proper-graph/input coverage classification,
not numerical coefficients, full source closure, E5/A5, QAP/measure/contact/IR,
anomaly freedom or physical viability. Full foundations and computational gaps
remain separate. HB1/C5 blocked, flavor paused, C1_GS uncomputed, scalar quantum
warning, quartet failure and custody exit2/seven remain. No scientific authority,
benchmark, accepted input, foundational or remote change. Track B tests complete
inventory, shared-premise disclosure and UV/IR/coordinate discipline; education
remains concurrent, voluntary and nonblocking.
