# Validator row/branch count correction V2

The first validator authenticated and compared the paired mathematical tables,
then failed its manual GF count fixture. It confused25972 literal dimension-zero
GF rows (33092 total minus7120 dimension-one rows) with26072 coupling branches:
some row coefficients contain more than one g/xi monomial. Preserve all failed
validator sources, preparation and complete captures. No worker is rerun.

V2 requires both the actual literal row counts and independently counted
coupling-branch totals, retaining every prior graph, dimension, reference,
metadata, negative-control and evidence check. Same120-second/8GiB limits.
This is a classification/counting correction, not a relaxed physics check.
The prospective RESULT's literal33092 GF total and supported graph table remain
unchanged. Failed new executions are one metadata-schema worker and one
validation fixture, not two failed physics derivations.
