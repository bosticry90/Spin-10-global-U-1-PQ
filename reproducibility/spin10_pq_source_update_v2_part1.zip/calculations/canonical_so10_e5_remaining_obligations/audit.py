"""Evidence scope reconciliation and a conservative source-free type census."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations_with_replacement,product
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    sp=importlib.util.spec_from_file_location(n,p);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);return v
h=load('qualified_source_closure_helpers',OUT.parent/'canonical_so10_nonminimal_source_closure/closure.py');m=h.m;l=h.l;read=m.read;digest=m.digest;PKG=m.PKG
T={'B':(1,0,0),'x':(1,0,0),'A':(1,0,0),'C':(1,1,1),'a':(1,-1,1),'L':(2,0,0)}
def keytypes(key):return h.h.types(key)
def envelope(role):
    names=sorted(T);words=[]
    if role=='primary':
        for size in range(5):words.extend(combinations_with_replacement(names,size))
    else:
        for counts in product(range(5),repeat=len(names)):
            if sum(counts)<=4:words.append(tuple(n for n,k in zip(names,counts) for unused in range(k)))
    out=set()
    for ts in words:
        dim=sum(T[t][0] for t in ts)
        if dim>4 or sum(T[t][1] for t in ts)!=0 or sum(T[t][2] for t in ts)%2:continue
        for j in range(5-dim):
            if not ts and j:continue
            if (ts.count('B')+ts.count('A')+j)%2:continue
            out.add((ts,j,4-dim-j))
    return sorted(out)
def sealed(folder,filename):
    f=PKG/folder;p=f/filename;b=read(f/'bindings.json');assert b['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p),b
def canon_hash(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('E5_AUDIT_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('E5_AUDIT_UNDECLARED_OR_PEER '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    qc,qb=sealed('frozen_a10_e5_quantum_contract',role+'.json');regular,rb=sealed('frozen_a10_e5_regularity',role+'.json');reg,regb=sealed('frozen_a10_e5_regulated_slavnov',role+'.json');normal,nb=sealed('frozen_a10_e5_joint_normalization',role+'.json');measured,mb=sealed('frozen_a10_e5_measured_functional',role+'_v3.json');quartet,kb=sealed('frozen_a10_e5_quartic_companion','comparison.json')
    assert qb['conditional_framework_qualified'] and not qb['theorem_qualified'];assert rb['polynomial_regularity_Noether_KT_normality_prerequisite_qualified'];assert regular['polynomial_regular_sequence_and_complete_Noether_resolution'] and not regular['A1_A5_discharged']
    assert regb['regulated_source_operator_identity_qualified'] and regb['specified_heat_Jacobian_qualified'] and not reg['actual_one_loop_local_restoration_proved'] and not reg['quantum_A5_equivalence_proved'] and not reg['physical_IR_or_continuum_measure_proved']
    assert not normal['normalization']['candidate_adopted'] and not normal['full_quantum_A5_proved'];assert quartet['scientific_gate']=='STOP_E5_INACTIVE_NORMALIZATION_MISSES_ACTUAL_QUARTIC' and not quartet['full_E5_PASS']
    flags={k:qc[k] for k in ['QAP_proved_for_model','actual_renormalization_prescription_constructed','all_order_class_nonempty_proved','joint_restoration_proved','quantum_insertions_renormalized','quantum_canonical_equivalence_proved','measure_or_anomaly_freedom_proved']};assert not any(flags.values())
    closed,_=h.h.h.auth('canonical_so10_nonminimal_source_closure',role+'_result.json');assert closed['complete_retained_simultaneous_source_local_pole_identity'] and closed['total_closed_of38']==38 and not closed['full_quantum_source_Slavnov_E5_A5_QAP_measure_finite_contact_IR_anomaly_or_physical_claim']
    source_receipt=read(OUT.parent/'canonical_so10_nonminimal_source_closure/validation_receipt.json');assert source_receipt['execution_state']=='COMPLETED' and source_receipt['all38_current_refined_classes_closed']
    m.setup();tables,unused,path=m.old.current_tables(role);current,cr=h.h.h.auth('canonical_so10_dimensionful_source_canonical',role+'_result.json');tables.append(current['new_actual_g3_xi_dimensionful_node']);counts=[];P={}
    def combine():
        for index,table in enumerate(tables):
            zero=[];one=0
            for r in table:
                ns=sum(m.token(n)[0] in m.sources for n in r['word']);assert ns<=1
                if ns:one+=1
                else:zero.append(r)
            counts.append({'table':index,'raw_sourcefree_rows':len(zero),'raw_source_rows':one});m.merge_into(P,m.decode(zero))
    stage('exact_current_sourcefree_polynomial_projection',combine);env=stage('coarse_counterterm_type_envelope',lambda:envelope(role));signatures=Counter()
    for (gp,key),z in P.items():
        ts=keytypes(key);j=sum(len(k) for n,k in key);cd=4-sum(T[t][0] for t in ts)-j;assert (ts,j,cd) in env
        for wp in {(a,b) for a,b,mask in z.cells}:signatures[ts,j,gp,cd,wp]+=1
    observed={(ts,j,cd) for ts,j,gp,cd,wp in signatures};absent=[{'types':list(ts),'total_jets':j,'coefficient_dimension':cd,'classification':'UNOBSERVED_COARSE_SHAPE_NOT_A_ZERO_OR_MISSING_AMPLITUDE_CLAIM','indexed_scalar_carrier_may_contribute':not j and all(t=='x' for t in ts)} for ts,j,cd in env if (ts,j,cd) not in observed]
    separate=measured['separate_indexed_or_regulated_nodes'];scalar=separate['scalar_g0_indexed'];ghost=separate['ghost_g1_power_and_finite'];hp=scalar['hessian_program'];assert not scalar['merged_into_Minkowski_polynomial_sum'] and not hp['all_coupling_beta_coefficients_freshly_expanded'] and hp['all_34_independent_parameter_coefficients_retained'] and not ghost['merged_into_local_logarithmic_sum']
    carriers={'scalar':{'status':scalar['status'],'graph_coefficients':hp['graph_coefficients'],'all34_parameters_retained':True,'dense_beta_coefficients_expanded':False,'merged_into_polynomial':False,'indexed_program_sha256':canon_hash(hp),'physical_IR_limit_taken':scalar['loop_sign']['physical_IR_limit_taken']},'ghost_nonlog':{'status':ghost['status'],'merged_into_local_logarithmic_sum':False,'power_coefficient':ghost['power_coefficient'],'finite_remainder':ghost['finite_remainder']}}
    obligations=[{'id':'SOURCE.LOCAL_UV','status':'QUALIFIED_WITHIN_DECLARED_SCOPE','evidence':'V216:38/38 source-dependent local-pole classes modulo explicit current','does_not_imply':'regulated finite insertion identity or full restoration'}, {'id':'SOURCEFREE.LOCAL_UV','status':'NOT_ESTABLISHED','evidence':'partial exact polynomial plus separate indexed/regulated carriers','does_not_imply':'unobserved shapes are zero;508 principal columns are full quantum equations'}, {'id':'CLASSICAL.REGULARITY','status':'QUALIFIED_PREREQUISITE_ONLY','evidence':regular['status'],'does_not_imply':'QC.A1-A5 or Ward/basic restricted cohomology equivalence'}]
    mapping={'A1':'measure,propagator,Legendre,boundary/IR construction','A2':'model-specific QAP,subtraction and parameter-ring stability','A3':'simultaneous restoration,cohomology and compatible normalization','A4':'actual renormalized composite/contact insertion mixing','A5':'quantum canonical replacement,Jacobian and insertion/operator transport'}
    obligations.extend({'id':'QC.'+key,'status':'EXPLICIT_CONDITIONAL_INPUT_NOT_DISCHARGED','evidence':qc['assumptions'][key],'missing':mapping[key]} for key in sorted(mapping))
    obligations.extend([{'id':'LEGACY.A4_A5','status':'HISTORICAL_EQUIVALENCE_NOT_ESTABLISHED','evidence':'E1 replacement is not a proved translation of historical A4/A5;quantum contract baseline preserves this distinction'}, {'id':'QUARTET.NORMALIZATION','status':'SELECTED_INACTIVE_CANDIDATE_FAILURE_PRESERVED','evidence':quartet['scientific_gate'],'does_not_imply':'physical-theory no-go or removal by the source-pole theorem'}, {'id':'REGULATED.IDENTITY','status':'QUALIFIED_OPERATOR_IDENTITY_ONLY','evidence':reg['status'],'required_equation':'Q Gamma1=insertion1(B_Lambda)-(V,Gamma1)-i div_heat R','does_not_imply':'drop source correction,finite breakings or background-only responses'}])
    first=next(iter(P));controls={'remove_nonzero_measured_polynomial_changes_census':bool(m.add(P,m.scale({first:P[first]},-1),m.scale(P,-1))),'omit_scalar_program_loses_qualified_separate_carrier':hp['graph_coefficients']>0 and not scalar['merged_into_Minkowski_polynomial_sum'],'source_closure_does_not_discharge_QC_A1_A5':closed['complete_retained_simultaneous_source_local_pole_identity'] and not any(flags.values()),'homogeneous_finite_identity_rejected':not reg['actual_one_loop_local_restoration_proved'],'quartet_failure_cannot_be_promoted':quartet['scientific_gate'].startswith('STOP_'),'empty_constant_derivative_not_admitted':not any(not ts and j for ts,j,cd in env)}
    result={'schema':'E5_REMAINING_OBLIGATIONS_AUDIT_V1','route':role,'scientific_disposition':'QUALIFIED_EVIDENCE_GAP_RECONCILIATION_AND_COARSE_SOURCEFREE_CENSUS_ONLY','obligations':obligations,'quantum_assumption_flags':flags,'complete_sourcefree_polynomial':l.rows(P),'sourcefree_polynomial_terms_g_resolved':len(P),'table_source_censuses':counts,'coarse_sourcefree_type_envelope':env,'observed_sourcefree_signatures':[[list(ts),j,gp,cd,list(wp),ct] for (ts,j,gp,cd,wp),ct in sorted(signatures.items())],'unobserved_coarse_shapes':absent,'separate_carriers':carriers,'negative_controls':controls,'coarse_envelope_is_not_invariant_graph_or_derivative_placement_completion':True,'current_known_terms':current['updated_known_terms'],'current_known_sha256':current['updated_known_sha256'],'next_scientific_test':'bounded actual local source-normalization primitive applicability before source-free Euler expansion;carry full source-free companion and regulated insertion/Jacobian obligations,no adoption or universal source removal','all508_physical_Euler_values_remain_deferred':True,'full_E5_A5_QAP_IR_anomaly_or_physical_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
