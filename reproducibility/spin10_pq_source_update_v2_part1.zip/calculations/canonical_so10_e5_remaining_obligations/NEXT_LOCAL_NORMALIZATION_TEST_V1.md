# Next bounded test: actual local source-pole normalization applicability

This is a concrete prospective scientific test under standing delegation,
not an adopted scheme or execution receipt. Freeze a separate increment
against its actual Git baseline and qualified current bytes before running.
Do not infer Q-exactness,source removability or quantum equivalence from
V216's Q-closedness. Scope is the actual measured one-loop LOCAL source pole.

Construct/test an inactive source-left generator of grade(3,-1,odd),finite
ordinary jets,polynomial physical couplings,nonnegative dimensional parameters,
no inverse physical coupling/mass. Use the following action-derived candidate
components;do not optimize free coefficients to make a desired identity pass.

1. Retain V213's fixed33-term leading K_C=g*xi*JC^T*N*C in its actual chart.
   For ordinary order,testg^2*JC_phys^T*L*C_phys,with the qualified V182
   L=-eta_H*C_H^ad-xi*(8P_M-C_H^ad*P_M). Authenticate current ghost poles and
   source-dual charts before constructing its image. No extra ghost1/2.

2. Testg^2*JB_phys^T*(D_B*B_phys+Z_A*A_H_phys),in all four Lorentz copies.
   With the measured ordinary derivative pole D and the SAME ghost L,the
   candidate is D_B=-D-L. Test its FULL B-source image against actual P_a.
   The old A-source primitive suggests Z_A=-(eta_H+3)*incl_H*K_H/2.
   These are candidate formulas fixed by measured derivative and qualified
   cochain data,not a proof that the actual image or local Ward passes.
   Preserve all source/evaluation metrics;do not insert a spatial ETA.

3. Testg^2*sum_R Jx_R^T*D_R*x_R,where D_R=(eta_H-xi)*C_H^R and
   C_H^R=-sum_h rho_h^2 in the qualified physical ghost frame. Reuse the
   full328-direction P_a=L_(d a)rho_d+[D_R,rho_a] decomposition;do not
   repeat its enormous four-field Slavnov expansion. Check current raw
   canonical coefficients and any background covariance/reality assumptions.

4. The intrinsic dimensionful source node must not be omitted. Extract its
   ACTUAL normalized T_a from R_x=g^3*xi*T_a. Test a constant generator
   g^2*xi*Jx^T*t with T_a=-rho_a*t. A possible fixed contracting construction
   is t=C_R^-1*sum_a rho_a*T_a,where -sum_a rho_a^2=C_R*I is verified in
   each nontrivial sector. Only a nonzero REPRESENTATION CONSTANT may be
   inverted. Check the singlet zero-Casimir case explicitly and reconstruct
   every source coefficient and zero complement. This is an inactive UV
   field-translation primitive,not a finite vacuum shift or tadpole scheme.

5. Let K_S be those components and let R_a[QK_S] be its actual antighost
   source map. Test K_Lambda=-sum_i JLambda_i*(R_a_measured-R_a[QK_S])_i.
   The actual minus-identity Qa auxiliary term motivates this homotopy.
   Check the complete source image,including all39420 auxiliary positions,
   against current measured poles. No missing auxiliary coefficient is fitted.
   Keep every possible nonzero difference and grading/domain failure.

Normalize source jets with explicit boundary theta and test

    Gamma_source = project_source(QK)-div(theta).

The theta must reproduce V216's source-pole current through the corresponding
Q variation with the correct sign. Reconcile ALL643 source maps and the same
current input/38-target table. Do not accept selected entries or use the
closure theorem as a substitute for matching the actual full source image.

Carry the FULL source-free companion. The508 physical Euler pieces may be
retained as authenticated action-direction programs with their actual
coefficient maps;they are not zero. Compute explicit nonphysical polynomial
pieces and compare the known27001-position collection only where a complete
projector proof excludes unknown physical/program contributions. Preserve
the quartet candidate's historical failure and every new residual. No
automatic new source-free primitive,parameter release or normalization fit.

Check local H Ward/reality/parameter-domain applicability proportionally;
if a generator is nonhorizontal or requires transported operations,preserve
that fact. Do not impose an unproved strict classical quantum-H kernel or
claim a universal source-removal theorem. The physical and geometric quantum
insertion identities remain distinct.

Classical canonicality is not QC.A5. Carry the field/source maps,regulated
Berezinian and product insertions. A triangular field shift can have zero
diagonal trace in one block without making the entire regulated Jacobian
zero. Even constant field rescalings require their specified heat-profile
trace;it may contain retained background responses. Field-dependent external
source changes cannot silently be treated as scalar 1PI composition. No
quantum scheme,finite counterterm,physical input or benchmark is adopted.

Proposed bound: two sequential120s-after-import/8GiB workers and one180s/8GiB
independent validator,350MiB minimum available commit,complete captures and
frozen inputs. Use matrix/source-map structure and exact comparisons,not
another full QGamma expansion. Outcomes: qualified inactive local witness,
exact obstruction to THIS candidate/admissibility class,or bounded incomplete
requirements. Full E5/A5,QAP/measure/contact/IR and physical viability remain
unqualified regardless. Authority34/39,HB1/C5 block,flavor pause,C1_GS gap,
scalar warning,quartet failure,custodyexit2/seven and all earlier evidence stay.
