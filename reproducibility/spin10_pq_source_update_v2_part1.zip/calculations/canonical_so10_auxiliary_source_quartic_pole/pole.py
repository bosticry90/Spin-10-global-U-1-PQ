"""Actual source-quartet pole: literal graded traces versus indexed Wick colors."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import importlib.util
import json,os,sys,threading,time

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,IDS,H,M,canonical,decode_typed,cm,zero,adjoints,linear
from a10_e5_mixed_contact import inputs as source_inputs
from a10_e5_auxiliary_next import vertices as gf_inputs
from a10_e5_derivative_gauge import matrices,replay_quartic
from a10_e2_transport_common import partials
from a10_e5_measured_restoration import physical_action_screen
import a10_e5_quartic_algebra as ex

read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
num=ex.coefficient


def collect(P,Q):
    for word,z in Q.items():P[word]=P.get(word,0)+z


def strip(P,n):
    assert all(s.Poly(z,g).monoms()==[(n,)] for z in P.values())
    return canonical({word:s.Poly(z,g).coeff_monomial(g**n) for word,z in P.items()})


def inputs(route,stage):
    w,sub,back,source,anti,Cinv,Cphys,raw,physical,si=source_inputs(route,stage)
    other,V,maps,gi=gf_inputs(route,stage)
    assert maps[:4]==(source,anti,Cinv,Cphys)
    F=canonical({word:z for word,z in V[0].items() if any(n.startswith('ap') for n,j in word)})
    rawgf=decode_typed(read(PKG/f'frozen_a10_e2_transport/{route}.json')['gauge_fixing_density'])
    Qraw={word:s.Poly(z,g,xi).coeff_monomial(g*xi) for word,z in rawgf.items() if len(word)==4 and s.Poly(z,g,xi).coeff_monomial(g*xi)!=0}
    assert len(Qraw)==648
    Q=stage('literal_g_xi_quartic_physical_pullback',lambda:canonical(w.replace(Qraw,maps[-1])))
    Ps={'S':strip(physical['JL3'],1),'K':strip(physical['JL4'],2),'F':F,'X':V[1],'Q':Q}
    assert all(w.grade(P,(4,0,0)) for P in Ps.values())
    Fa,Fc,X,L=matrices(other,V)
    assert all(Fc[u]==s.zeros(45) and Fa[u][:,:12]==s.zeros(45,12) for u in M)
    ref=read(PKG/f'frozen_a10_e5_full_hessian/{route}.json')['retained_reference'];names=ref['field_order']
    scalar={i for i,n in enumerate(names) if n.startswith('x_')};assert len(names)==643 and len(scalar)==328
    assert not [(i,j) for i,j,z in ref['reference_Green_raw_C3']['entries'] if (i in scalar)!=(j in scalar)]
    assert not physical_action_screen()['ghost_or_BV_source_in_physical_action']
    return w,Ps,back,(source,anti,Cinv,Cphys,maps[4],maps[5]),V,{
      'source':si,'GF_and_all4_Lorentz_IBP_currents':gi,'literal_g_xi_terms':648,
      'all643_reference_and328_scalar_complement_accounted':True,
      'actual_Fc_heavy_vector_zero':True,'actual_Fa_heavy_vector_light_ghost_columns_zero':True,
      'no_finite_IR_or_other_g_zero_inferred':True}


def encode(P,external):
    out={}
    for word,z in P.items():
        assert all(not jets and n in external for n,jets in word)
        ids=tuple(external[n] for n,jets in word);ordered,sign=ex.ordered(ids)
        if sign:out[ordered]=out.get(ordered,ex.D.zero)+sign*num(z)
    return {word:z for word,z in out.items() if z}


def hessian(P,w,names,external):
    pos={n:i for i,n in enumerate(names)};out={}
    for (a,alpha),first in partials(P,w,set(names)).items():
        for (b,beta),second in partials(first,w,set(names)).items():
            if any(mu!=0 for mu in (*alpha,*beta)):continue
            factor=(-1)**(w.p[b]*(w.p[a]+1))*(-s.I)**len(alpha)*s.I**len(beta)
            selected={word:z*factor for word,z in second.items() if all(not jets and n in external for n,jets in word)}
            if selected:
                value=encode(selected,external);cell=out.setdefault((pos[a],pos[b]),{})
                ex.accumulate(cell,value)
    return {ij:P for ij,P in out.items() if P}


def reference():
    G={};p=[0]*90+[1]*90
    for i in IDS:
        G[i,i]={():num(-ex.widthH if i in H else -ex.widthM)}
        G[i,45+i]={():num(s.I)};G[45+i,i]={():num(-s.I)}
        G[90+i,135+i]={():num(1)};G[135+i,90+i]={():num(-1)}
    return G,p


def gaussian_families(Hs,G,p):
    pipes={tag:ex.mm(G,A) for tag,A in Hs.items()}
    assert not ex.mm(pipes['S'],pipes['X']) and not ex.mm(pipes['X'],pipes['S']),'ACTUAL_S_X_ADJACENCY_NOT_ZERO'
    for A in pipes.values():
        for (i,j),P in A.items():assert all(len(word)%2==(p[i]+p[j])%2 for word in P)
    tr=lambda tags:ex.trace_product([pipes[tag] for tag in tags],p)
    return {'box':tr(['S','F','X','F']),
            'triangle':ex.scale(ex.add(tr(['K','F','X']),tr(['K','X','F'])),num(-1)),
            'bubble':tr(['K','Q'])}


def unit_bridge(stage):
    path=ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/units_v2.py'
    spec=importlib.util.spec_from_file_location('source_quartet_qualified_units',path);u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
    expected=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/validation_receipt.json')['poles'];out={}
    cases=[(kind,a,b) for kind in ['B_X','B_F'] for a in ['a','B','c'] for b in ['a','B','c']]
    cases += [(kind,a,'a') for kind in ['T_K','T_X','T_F'] for a in ['a','B','c']]+[(kind,'a','a') for kind in ['Q_K','Q_Q']]
    for kind,a,b in cases:
        w,V,target=u.model(kind,a,b);names=list(w.fields)
        external={'uk_C0':0,'uk_C1':1,'uk_aE':45,'uk_J':90}
        G={(i,j):{():num(s.expand(z.subs({u.R:1,u.width[0]:ex.widthM,u.width[1]:ex.widthH})))}
            for i,x in enumerate(names) for j,y in enumerate(names) if (z:=s.sympify(u.green(x,y,[1,0,0,0])))}
        p=[w.p[n] for n in names];Hs=[hessian(P,w,names,external) for P in V]
        if kind.startswith('B_'):
            source,F0,F1,X=Hs;F=ex.msum(F0,F1)
            P=gaussian_families({'S':source,'F':F,'X':X,'K':{},'Q':{}},G,p)['box']
        elif kind.startswith('T_'):
            source,F,X=Hs
            P=gaussian_families({'S':{},'F':F,'X':X,'K':source,'Q':{}},G,p)['triangle']
        else:
            source,Q=Hs
            P=gaussian_families({'S':{},'F':{},'X':{},'K':source,'Q':Q},G,p)['bubble']
        normalization=next(iter(encode(target,external).values()));assert normalization in [num(1),num(-1)]
        value=s.simplify(ex.D.to_sympy(P.get((0,1,45,90),ex.D.zero))*ex.D.to_sympy(normalization))
        key=kind+'_'+a+b;assert value==s.Rational(expected[key]),('ACTUAL_MATRIX_BACKEND_UNIT_BRIDGE',key,value,expected[key]);out[key]=str(value)
    return out


def primary(w,Ps,stage):
    names=[f'Bp{i}_0' for i in IDS]+[f'Lp{i}' for i in IDS]+[f'Cp{i}' for i in IDS]+[f'ap{i}' for i in IDS]
    ext={**{f'Cp{i}':i for i in IDS},**{f'ap{i}':45+i for i in IDS},**{f'JLp{i}':90+i for i in IDS}}
    Hs={tag:stage('literal_graded180_Hessian_'+tag,lambda P=P:hessian(P,w,names,ext)) for tag,P in Ps.items()}
    G,p=reference();families=stage('full_exact_three_family_closed_Born_contractions',lambda:gaussian_families(Hs,G,p))
    return families,{'quantum_coordinates':180,'full_reference_including_BB_widths':True,
        'Hessian_cells':{tag:len(A) for tag,A in Hs.items()},'S_X_adjacent_products_exact_zero':True,
        'even_superoperator_cyclicity_and_order_preserved':True,'box_cyclic_words':12,'triangle_words':6,'bubble_words':2}


def ordered_slots(P,w):
    out={}
    for word,z in P.items():
        js=[int(n[3:]) for n,j in word if n.startswith('JLp')]
        aa=[int(n[2:]) for n,j in word if n.startswith('ap')]
        cc=sorted(int(n[2:]) for n,j in word if n.startswith('Cp'))
        ll=[int(n[2:]) for n,j in word if n.startswith('Lp')]
        if js and ll:
            assert len(js)==len(ll)==len(cc)==1 and not aa
            target=w.mul(w.var(f'JLp{js[0]}'),w.var(f'Lp{ll[0]}'),w.var(f'Cp{cc[0]}'));key=(js[0],ll[0],cc[0])
        elif js:
            assert len(js)==len(aa)==1 and len(cc)==2 and cc[0]<cc[1]
            target=w.mul(w.var(f'JLp{js[0]}'),w.var(f'ap{aa[0]}'),*(w.var(f'Cp{k}') for k in cc));key=(js[0],aa[0],*cc)
        else:
            assert len(aa)==len(cc)==2;aa=sorted(aa);assert aa[0]<aa[1] and cc[0]<cc[1]
            target=w.mul(*(w.var(f'ap{k}') for k in aa),*(w.var(f'Cp{k}') for k in cc));key=(*aa,*cc)
        assert set(target)=={word};out[key]=num(s.simplify(z/target[word]))
    return out


def fullK(K):
    out={}
    for (i,j,a,b),z in K.items():out[i,j,a,b]=z;out[i,j,b,a]=-z
    return out


def fullQ(Q):
    out={}
    for (i,j,a,b),z in Q.items():
        out[i,j,a,b]=z;out[j,i,a,b]=-z;out[i,j,b,a]=-z;out[j,i,b,a]=z
    return out


def accumulate_slot(P,i,j,a,b,z):
    if a==b or not z:return
    if a>b:a,b,z=b,a,-z
    key=(i,j,a,b);P[key]=P.get(key,ex.D.zero)+z
    if not P[key]:del P[key]


def contract_colors(S0,K0,F0,X0,Q0,weights):
    K=fullK(K0);Q=fullQ(Q0);Frow=defaultdict(list);Fpair=defaultdict(list);Xpair=defaultdict(list);Xghost=defaultdict(list);XL=defaultdict(list)
    for (u,m,a),z in F0.items():Frow[m].append((u,a,z));Fpair[u,m].append((a,z))
    for (u,j,m),z in X0.items():XL[u].append((j,m,z));Xpair[u,j].append((m,z));Xghost[u,m].append((j,z))
    out={tag:{} for tag in ['box','triangle_K','triangle_X','bubble_K','bubble_Q']}
    for (i,l,h),z in S0.items():
        for u,a,f in Frow[h]:
            for j,m,x in XL[u]:
                for b,k in Fpair[l,m]:accumulate_slot(out['box'],i,j,a,b,weights['B_X_aa']*z*f*x*k)
    for (i,j,m,n),z in K.items():
        for u,a,f in Frow[m]:
            for b,x in Xpair[u,n]:accumulate_slot(out['triangle_K'],i,j,a,b,weights['T_K_aa']*z*f*x)
    for (i,m,n,a),z in K.items():
        for u,b,f in Frow[n]:
            for j,x in Xghost[u,m]:accumulate_slot(out['triangle_X'],i,j,a,b,weights['T_X_aa']*z*f*x)
    Qpair=defaultdict(list);Qcross=defaultdict(list)
    for (m,n,a,b),z in Q0.items():Qpair[m,n].append((a,b,z))
    for (j,n,m,b),z in Q.items():Qcross[n,m].append((j,b,z))
    for (i,j,m,n),z in K0.items():
        for a,b,k in Qpair[m,n]:accumulate_slot(out['bubble_K'],i,j,a,b,weights['Q_K_aa']*z*k)
    for (i,m,n,a),z in K.items():
        for j,b,k in Qcross[n,m]:accumulate_slot(out['bubble_Q'],i,j,a,b,weights['Q_Q_aa']*z*k)
    return out


def indexed_unit_controls(weights):
    N=num;cases={
      'B_X_aa':({(20,17,0):N(1)},{},{(18,0,14):N(1),(17,12,15):N(1)},{(18,13,12):N(1)},{}),
      'T_K_aa':({},{(20,13,12,16):N(1)},{(17,12,14):N(1)},{(17,16,15):N(1)},{}),
      'T_X_aa':({},{(20,16,12,14):N(1)},{(17,12,15):N(1)},{(17,13,16):N(1)},{}),
      'Q_K_aa':({},{(20,13,12,16):N(1)},{},{},{(12,16,14,15):N(1)}),
      'Q_Q_aa':({},{(20,12,14,16):N(-1)},{},{},{(13,16,12,15):N(1)})}
    out={}
    for label,tensors in cases.items():
        parts=contract_colors(*tensors,weights);total={}
        for P in parts.values():
            for key,z in P.items():total[key]=total.get(key,ex.D.zero)+z
        total={key:z for key,z in total.items() if z}
        assert total=={(20,13,14,15):weights[label]},('INDEXED_UNIT_PATTERN_BRIDGE',label,ex.serial({tuple(k):z for k,z in total.items()}))
        out[label]=str(ex.D.to_sympy(total[20,13,14,15]))
    return out


def replay(w,Ps,maps,V,stage):
    source,anti,Cinv,Cphys,EM,EH=maps;E=s.Matrix.hstack(EH,EM)
    parent=stage('independent_physical10_parent_commutators',adjoints)
    f=stage('all45_independent_physical_frame_adjoint_matrices',lambda:[cm(E.T*linear(E[:,u],parent)*E) for u in IDS])
    Fa,Fc,X,L=matrices(w,V)
    for u in IDS:
        expected=f[u] if u in H else s.Matrix.hstack(s.zeros(45,12),f[u][:,12:])
        assert Fa[u]==expected
        expectedc=s.zeros(45)
        if u in H:expectedc[12:,12:]=-f[u][12:,12:]
        assert Fc[u]==expectedc
    for u in M:assert X[u-12]==f[u][12:,12:]
    ownQ=stage('independent_projected_commutator_quartic',lambda:replay_quartic(w,[f[u][12:,12:] for u in M]))
    zero(w.add(Ps['Q'],w.scale(ownQ,-1)),'OWN_LITERAL_Q_MATCH_BEFORE_POLE')
    S0,K0,Q0=[ordered_slots(P,w) for P in [Ps['S'],Ps['K'],ownQ]]
    F0={(u,j,k):num(z) for u in M for (j,k),z in f[u].todok().items() if k in M}
    X0={(u,12+j,12+k):num(z) for u in M for (j,k),z in f[u][12:,12:].todok().items()}
    assert all(i in M and l in M and h in H for i,l,h in S0)
    assert all(i in M and j in M and a in M and b in M for i,j,a,b in K0)
    units=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/validation_receipt.json')['poles']
    weights={n:num(s.Rational(units[n])) for n in ['B_X_aa','T_K_aa','T_X_aa','Q_K_aa','Q_Q_aa']}
    controls=stage('five_indexed_color_pattern_controls_against_general_q_units',lambda:indexed_unit_controls(weights))
    pieces=stage('independent_indexed_Wick_color_contractions',lambda:contract_colors(S0,K0,F0,X0,Q0,weights))
    families={}
    for tag,parts in [('box',['box']),('triangle',['triangle_K','triangle_X']),('bubble',['bubble_K','bubble_Q'])]:
        P={}
        for name in parts:
            for (i,j,a,b),z in pieces[name].items():
                word=(a,b,45+j,90+i);P[word]=P.get(word,ex.D.zero)-z
        families[tag]={word:z for word,z in P.items() if z}
    return families,{'indexed_pattern_controls':controls,'independent_physical10_vertices_compared_before_poles':True,
                    'F_external_antighost_requires_Fc_heavy_zero_proved':True,'projected_heavy_Jacobi_assumed':False,
                    'separate_piece_nonzero_counts':{tag:len(P) for tag,P in pieces.items()}}


def slots(P):
    out=[]
    for word,z in sorted(P.items()):
        assert len(word)==4 and 0<=word[0]<word[1]<45 and 45<=word[2]<90 and 90<=word[3]<135
        value=s.simplify(-ex.D.to_sympy(z));assert not value.has(s.Float,ex.widthH,ex.widthM) and s.simplify(value-s.conjugate(value))==0
        if value:out.append([word[3]-90,word[2]-45,word[0],word[1],str(value)])
    return sorted(out)


def main():
    started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
    allowed={str((ROOT/n).resolve()) for n in prep['input_sha256']};writes=[];denied=[]
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        name=os.fsdecode(args[0])
        if len(args)>1 and isinstance(args[1],str) and any(t in args[1] for t in 'wax+'):
            writes.append(name);raise PermissionError('ACTUAL_SOURCE_QUARTET_WRITE_DENIED')
        if Path(name).suffix=='.json' and str(Path(name).resolve()) not in allowed:
            denied.append(name);raise PermissionError('ACTUAL_SOURCE_QUARTET_PRIOR_POLE_REQUIRED_OR_PEER_READ_DENIED')
    sys.addaudithook(guard)
    stages=[]
    def stage(name,fn):
        print('STAGE '+name,flush=True);tick=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-tick});return value
    bridge=stage('all29_new_graded_backend_general_q_unit_bridges',lambda:unit_bridge(stage)) if route=='primary' else None
    w,Ps,back,maps,V,inventory=inputs(route,stage)
    families,method=primary(w,Ps,stage) if route=='primary' else replay(w,Ps,maps,V,stage)
    total=ex.add(*families.values());familyrows={tag:slots(P) for tag,P in families.items()};answer=slots(total)
    assert all(all(index in M for index in row[:4]) for table in familyrows.values() for row in table)
    assert all(all(index in M for index in row[:4]) for row in answer),'ACTUAL_LIGHT_PROFILE_DID_NOT_VANISH'
    densities={}
    for tag,table in [*familyrows.items(),('total',answer)]:
        P=canonical(w.add(*(w.scale(w.mul(w.var(f'JLp{i}'),w.var(f'ap{j}'),w.var(f'Cp{k}'),w.var(f'Cp{l}')),s.sympify(z)*g**3*xi) for i,j,k,l,z in table)))
        densities[tag]=[{'word':[n+('__'+''.join(map(str,j)) if j else '') for n,j in word],'coefficient':str(z)} for word,z in sorted(P.items())]
    for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
    assert not writes and not denied and time.perf_counter()-started<120
    result={'schema':'ACTUAL_AUXILIARY_SOURCE_QUARTET_POLE_V1','route':route,'status':'CALCULATED_ACTUAL_THREE_FAMILY_SOURCE_POLE_REQUIRE_PAIRED_VALIDATION',
       'family_poles':familyrows,'actual_total':answer,'physical_densities':densities,'inventory':inventory,'method':method,
       'new_backend_unit_bridge':bridge,'raw_domain':2004750,'outside_heavy_source_antighost_ghost_pairs_zero_from_actual_action':True,
       'explicit_g3_xi_restored_once':True,'formal_reference_widths_cancelled':True,'units':'hbar*g10**3*xi/(32*pi**2*epsilon_UV), ordered JLambda*a*C_k*C_l,k<l,no extra1/2',
       'prior_required_Slavnov_or_peer_decoded':False,'actual_paired_agreement_or_restoration_claimed':False,
       'input_sha256':prep['input_sha256'],'source_sha256':prep['source_sha256'],'stages':stages,'seconds_after_import':time.perf_counter()-started,
       'write_attempts':writes,'denied_unbound_reads':denied,'scientific_authority_changed':False,'whole_goal_complete':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}),flush=True);timer.cancel()


if __name__=='__main__':main()
