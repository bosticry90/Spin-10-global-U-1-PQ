"""Release the measured functional only after actual source-quartet agreement."""
from pathlib import Path
from hashlib import sha256
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,IDS,ANTI,AUX,canonical,decode_typed,rows,zero,act
CONTROL=Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/source-quartic-pole-v1-2026-10-16')
sys.path.insert(0,str(CONTROL))
import canonical_transform as transform
from a10_e5_measured_functional_v3 import frames,projected_Q,TARGETS,kind
from a10_e5_ghost_source_required import reduce_antighost,actual_data
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()


def main():
 started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(OUT/'dependent_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
 for n,z in prep['external_sha256'].items():assert digest(Path(n))==z,n
 allowed={str((ROOT/n).resolve()) for n in prep['input_sha256']}|{str(Path(n).resolve()) for n in prep['external_sha256']};writes=[];denied=[]
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  name=os.fsdecode(args[0])
  if len(args)>1 and isinstance(args[1],str) and any(t in args[1] for t in 'wax+'):
   writes.append(name);raise PermissionError('SOURCE_QUARTET_COMPARISON_WRITE_DENIED')
  if Path(name).suffix=='.json' and str(Path(name).resolve()) not in allowed:
   denied.append(name);raise PermissionError('SOURCE_QUARTET_UNBOUND_COMPARISON_READ_DENIED')
 sys.addaudithook(guard)
 stages=[]
 def stage(name,fn):
  print('STAGE '+name,flush=True);tick=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-tick});return value
 def agreement():
  a,b=[read(OUT/name) for name in ['primary_v4_result.json','replay_v3_result.json']]
  for key in ['family_poles','actual_total','physical_densities','raw_domain','formal_reference_widths_cancelled']:
   assert a[key]==b[key],('ACTUAL_SOURCE_POLE_DISAGREEMENT_STOP_BEFORE_KNOWN_FUNCTIONAL',key)
  for name,table in [*a['family_poles'].items(),('total',a['actual_total'])]:
   keys=[tuple(row[:4]) for row in table];assert len(keys)==len(set(keys))
   assert all(0<=i<45 and 0<=j<45 and 0<=k<l<45 for i,j,k,l in keys)
  assert a['raw_domain']==2004750
  return a,b
 a,b=stage('actual_paired_tensor_agreement_BEFORE_known_data_release',agreement)
 prior=stage('release_qualified_source_pair_recipe_AFTER_actual_agreement',lambda:read(PKG/'frozen_a10_e5_source_pair_g3/comparison.json'))
 recipe=prior['updated_known_recipe'];base_recipe=recipe['prior_recipe']
 base=actual_data(PKG/base_recipe['base_path'])
 w=None
 known=decode_typed(base[base_recipe['base_key']])
 for piece in [decode_typed(base_recipe['add_once']),decode_typed(recipe['add_source_pair_once'])]:
  for word,z in piece.items():
   known[word]=s.expand(known.get(word,0)+z)
   if known[word]==0:del known[word]
 assert len(known)==prior['updated_known_terms']==58836
 oldpartial=decode_typed(prior['updated_known_partial_auxiliary_projection']);assert len(oldpartial)==1840
 oldward=decode_typed(prior['updated_known_Ward']);assert len(oldward)==18416
 already={word:s.Poly(z,g).coeff_monomial(g**3) for word,z in known.items()
          if tuple(sorted(kind(n) for n,j in word))==('C','C','JL','a') and all(not j for n,j in word)}
 assert not canonical(already),'NEW_SOURCE_G3_CLASS_ALREADY_INCLUDED_STOP_LINEAGE'
 physical=transform.from_slots(a['actual_total']);answers={};node=None;ward_delta=None;transform_checks={}
 for route in ['primary','replay']:
  ww,forward,reverse,*unused=frames(route)
  if w is None:w=ww
  rev,direct,raw_names,physical_names=stage('constant_graded_source_dual_maps_'+route,lambda:transform.maps(ww,forward,reverse,ANTI,AUX))
  pulled,check=stage('new_actual_node_exact_integer_pullback_'+route,lambda:transform.pull(physical,rev))
  roundtrip,unused_check=stage('full_actual_polynomial_roundtrip_'+route,lambda:transform.pull(pulled,direct))
  assert roundtrip==physical,'FULL_ACTUAL_NODE_SOURCE_DUAL_ROUNDTRIP_'+route
  transform_checks[route]=check
  current=transform.density(pulled,raw_names,ww,g**3*xi)
  assert ww.grade(current,(4,0,0))
  if node is None:node=current
  else:zero(ww.add(node,ww.scale(current,-1)),'PAIRED_CANONICAL_NODE_EQUALITY')
  e2=read(PKG/f'frozen_a10_e2_transport/{route}.json');columns=e2['complete_columns'];assert len(columns)==1286
  active={n for word in current for n,j in word};assert active<=set(columns)
  assert all(columns[n]['physical_program'] is None for n in active)
  q={n:decode_typed(columns[n]['source_polynomial']) for n in active}
  delta=stage('new_actual_node_selected_auxiliary_Slavnov_'+route,lambda:projected_Q(current,q,ww,TARGETS['auxiliary_no_jet'],route))
  result=canonical(ww.add(oldpartial,delta));anchor,curr,E=reduce_antighost(result,ww)
  assert len(E)==45 and not any(curr) and all(not jets for word in result for n,jets in word)
  zero(projected_Q(current,q,ww,TARGETS['ghost_two_jet'],route),'LOWER_G2_GHOST_RELATION_UNCHANGED_'+route)
  rawTb=read(PKG/f'frozen_a10_e3_symmetry/{route}.json')['operators']['Tb_geometric_and_transported'];assert len(rawTb)==1334 and active<=set(rawTb)
  Tb={n:decode_typed(rawTb[n]) for n in active}
  ward=stage('new_actual_node_FULL_local_background_Ward_'+route,lambda:canonical(act(current,ww,Tb,route,0)))
  if ward_delta is None:ward_delta=ward
  else:zero(ww.add(ward_delta,ww.scale(ward,-1)),'PAIRED_FULL_NEW_WARD_EQUALITY')
  answers[route]={'new_node_auxiliary_projection':rows(delta),'updated_selected_auxiliary_projection':rows(result),
    'updated_anchor':rows(anchor),'all45_antighost_Eulers':{n:rows(P) for n,P in E.items()},
    'nonzero_antighost_Eulers':sum(bool(P) for P in E.values()),'new_full_local_Ward':rows(ward),
    'new_source_node_canonical':rows(current),'new_source_node_terms':len(current),
    'omission_or_doublecount_changes_projection':bool(delta)}
 assert answers['primary']==answers['replay'],'PAIRED_DEPENDENT_ASSESSMENT_DISAGREEMENT'
 updated=dict(known)
 for word,z in node.items():
  updated[word]=s.expand(updated.get(word,0)+z)
  if updated[word]==0:del updated[word]
 newWard=dict(oldward)
 for word,z in ward_delta.items():
  newWard[word]=s.expand(newWard.get(word,0)+z)
  if newWard[word]==0:del newWard[word]
 coverage=[];changed=0
 for item in prior['auxiliary_coverage']:
  item=dict(item)
  if item['coverage']=='UNMEASURED':
   assert item['input_types']==['C','C','JL','a'] and item['input_g']==3
   item.update(coverage='MEASURED',evidence_sector='actual_source_quartet',evidence_scope='all2004750 source/antighost/antisymmetric-ghost slots,qualified literal/physical10 methods');changed+=1
  coverage.append(item)
 assert changed==1 and not any(item['coverage']=='UNMEASURED' for item in coverage)
 for n,z in prep['input_sha256'].items():assert digest(ROOT/n)==z,n
 assert not writes and not denied and time.perf_counter()-started<120
 answer=answers['primary']
 result={'schema':'ACTUAL_SOURCE_QUARTET_DEPENDENT_ASSESSMENT_V1','status':'COMPLETED_ACTUAL_PAIRED_POLE_AND_SELECTED_RELATION_ASSESSMENT_REQUIRE_VALIDATION',
  'actual_paired_agreement_before_known_data':True,'exact_full_polynomial_roundtrip_checks':transform_checks,'complete_raw_component_slots':2004750,
  'family_nonzero_counts':{k:len(v) for k,v in a['family_poles'].items()},'actual_total_nonzero':len(a['actual_total']),
  'known_prior_terms':58836,'updated_known_terms':len(updated),'old_partial_auxiliary_terms':1840,**answer,
  'complete_selected_auxiliary_pole_left_side_zero':not bool(answer['updated_selected_auxiliary_projection']),
  'complete_selected_auxiliary_input_census_measured':True,'auxiliary_coverage':coverage,
  'updated_known_recipe':{'prior_source_pair_recipe':recipe,'add_actual_source_quartet_once':rows(node)},
  'known_prior_Ward_terms':18416,'updated_known_Ward':rows(newWard),'updated_known_Ward_terms':len(newWard),
  'unknown_quantum_breaking_set_zero':False,'full_restoration_or_anomaly_claim':False,'normalization_adopted':False,
  'old_large_Q_or_loop_replayed':False,'scientific_authority_changed':False,'whole_goal_complete':False,
  'input_sha256':prep['input_sha256'],'stages':stages,'seconds_after_import':time.perf_counter()-started,'write_attempts':writes,'denied_unbound_reads':denied}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
 print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started}),flush=True);timer.cancel()


if __name__=='__main__':main()
