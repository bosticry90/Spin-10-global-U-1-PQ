# Exact Schur contraction after the preserved V1 deadline

V1 primary reached its120second deadline at the generic closed Born contraction,
exit124, without a RESULT or exported tensor. Source, preparation, complete
capture and all inputs remain exact. V1 replay did not launch. This is resource
incompleteness, not a failed physical relation or a qualified partial amplitude.

Under current AGENTS.md establish two NEW sequential120second/8GiB/350MiB
actual roles with preparation_v2.json. Preserve V1 without retroactive PASS;
do not increase resources or discard fields, components, families or controls.

Use the exact even/odd Schur identity, retaining all Grassmann ordering. For
S,F,X the selected Hessians have only mixed blocks; K,Q have only odd/odd
blocks. Write M_ab=Y_a G_even X_b. The two source/auxiliary combinations
M_SX=M_XS=0 because their even internal ports are auxiliaries and G_LL=0.
Let A=M_SF+M_FS and B=M_FX+M_XF. The odd effective operator is
O=O0+K+Q-sum(M_ab). Expanding -i/2 Tr log O and applying the same2i pole
factor gives the EXACT three families

    box      = -Tr(G_odd A G_odd B),
    triangle = +Tr(G_odd K G_odd B),
    bubble   = -Tr(G_odd K G_odd Q).

The cross terms have both orders; their ordinary traces agree by cyclicity of
even matrix polynomials. No odd coefficient is reversed. Terms containing
M_FF could carry B/B propagation, but their required source/auxiliary partner
M_SX or M_XS is zero; the full B/B reference is retained to establish this.
The source-type/coupling selection excludes multiple-source terms. This is
an algebraic reorganization of all admitted cycles, not a new quantum input.

Use direct closed pairing of degree-two matrices rather than building unused
off-diagonal degree-four entries. Check the block types, vanished M_SX/M_XS,
all29 general-q-to-radial unit bridges and the unchanged independently indexed
Wick contractions. Each original family and zero complement remains required.
The current actual derivative/carrier identities still need their own checks.

All RECORD.md scientific ceilings, blind-read barriers, failure controls and
later comparison boundaries remain. A new actual method discrepancy must be
preserved and investigated without opening the required Slavnov tensor. Full
restoration, scientific authority and physical matching remain unqualified.
