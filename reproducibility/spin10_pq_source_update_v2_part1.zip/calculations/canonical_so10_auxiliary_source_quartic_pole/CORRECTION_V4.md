# Exact integer Schur backend with reused classical vertex evidence

The indexed V3 route completes in110.38seconds and exports one full candidate
tensor; it is still pending a distinct primary and final validation. Its
timings show55.45seconds rebuilding classical inputs and11.59seconds in indexed
contractions. The two primary deadline failures remain unqualified. No
candidate coefficient values or required Slavnov tensor are used to implement
this generic primary correction.

Authorize ONE new bounded primary under standing AGENTS.md delegation:
120seconds after imports,8GiB sampled private memory,350MiB minimum available
commit. No resource increase, primary/Slavnov fit or replay reclassification.

Reuse the ALREADY QUALIFIED literal physical vertex subtrees from the sealed
source-pair and source-free quartet evidence. A custody projection extracts
only S,K,F,X,Q classical vertices, with original producer paths/hashes and
primary/replay subtree equality; no old pole is exported to the primary.
The primary worker may read only that classical artifact, not the full old
producer payloads. Recheck all four Lorentz copies of F and the inherited
full643 reference/scalar exclusion. This is inherited classical evidence,
not a fresh derivation. The V3 indexed method freshly reconstructed its own
literal and physical10 vertices before calculating its candidate tensor.

Keep the exact V2 Schur identity, blocks, all45 indices and source/ghost
ordering. Replace repeated rational arithmetic inside matrix products by an
exact integer lattice in the16-element sqrt(2),sqrt(3),sqrt(5),I basis. A common
denominator D is the LCM of the actual atomic Hessian coefficient denominators.
Hessians are stored multiplied by D. The reference mixed/ghost entries are
integral in this basis. Box/triangle/bubble results divide by D^4,D^3,D^2.
Python integers are unbounded; there is no numerical rounding or overflow cap.

Prove the reference entries reachable by each needed rectangular block carry
no width powers before converting them. The full B/B reference remains in
the support proof; no propagator is dropped merely for speed. Check all256
root-basis products and256 exterior-basis products against the inherited exact
algebra, every atomic coefficient conversion, all29 new-backend unit bridges,
and denominator rescaling invariance. Direct closed pairing avoids unneeded
degree-four off-diagonal entries without reducing the coefficient space.

Preserve the separate indexed candidate and prohibit its decode in this primary.
Compare completed family and total tensors only AFTER the new primary exports.
If they disagree, stop and preserve the discrepancy before releasing known
Slavnov data. A further resource failure remains incomplete. All prior
scientific ceilings, failure evidence and authority boundaries remain.
