# Bounded indexed route before another primary retry

V1 and V2 primary both reached their120second deadlines during their closed
contractions, exit124/noRESULT. Sources, preparations and full captures remain
unaltered. Neither replay ran. The Schur reorganization remains an unqualified
calculation until its full result and verification complete; small unit checks
do not establish the actual color tensor.

Do not automatically repeat either generic matrix contraction. Establish ONE
new120second/8GiB/350MiB indexed-Wick run under standing AGENTS.md delegation.
Its only purpose is to complete the already specified independent physical10/
indexed contraction or localize its own remaining resource limitation. No
primary retry, known-Slavnov/required-tensor read, new input or physical
acceptance is authorized by this V3 increment.

The mathematical replay functions in frozen pole_v2.py are unchanged. A small
external driver binds that source and the exact prior classical inputs, runs
only the replay functions, preserves full stage timings in stdout and exports
its complete family tensors if successful. It cannot decode prior poles or
peers. Synthetic indexed-pattern controls and literal/physical-vertex matches
remain mandatory. All fields, zero complements, units and scientific ceilings
in RECORD.md remain; no coefficient is fitted to an expected relation.

A completed result would still be ONE actual derivation, pending the distinct
primary and final evidence validation. A timeout would be resource
incompleteness. Either must be preserved honestly; neither is full E5/A5 or
physical model acceptance/refutation. Reassess the contraction representation
using the observed timings before further actual runs.
