# Actual g3 auxiliary-source quartet pole V1

Baselineaed9301cfe79baec45f31d05073e0ca02d53fc5d. Live AGENTS.md delegates
this bounded actual partner measurement. project_state.json v113/34of39 and
all blocked-stage, physical-input and human flavor-pause boundaries remain.

Question: calculate the actual dimension-zero one-loop local logarithmic
g10³*JLambda_i*a_j*C_k*C_l coefficient, k<l, without reading a required
tensor or the known partial Slavnov relation. Target order has no extra1/2;
the common unit is hbar/(32pi²epsilon_UV). All45 directions and2004750 raw
independent slots remain covered. No candidate normalizer or input is fitted.

Reuse the qualified ten-family conservative inventory and29 general-q unit
kernels, preserving their explicit limits and failed attempts. Reconstruct
literal source-cubic S, source-quartic K, derivative ghost F, xi auxiliary X
and g*xi ghost quartic Q. Account for the seven structural zeros, full643
reference/328 scalar complement, background/source restrictions and positive-
dimensional UV exclusions. They do not establish finite/IR or other-g zeros.

Primary: physical pullback of the unchanged literal source/GF polynomials,
complete two-quantum-leg graded Hessians on the full180 temporal gauge/
auxiliary/ghost frame and the full reference, including B/B widths. The
qualified all-Lorentz/IBP identities and general-q units justify radial scalar
reduction: there is no external Lorentz vector in this no-jet coefficient.
Prove the S-X adjacent products vanish from actual support. Supertrace
cyclicity for even superoperators then gives, after the common pole factor,
Tr(S F X F), -(Tr(K F X)+Tr(K X F)) and Tr(K Q). Retain exact Grassmann
coefficient order; use associative sparse closed contractions, not dense
off-diagonal degree-four expansion. Verify the even-superoperator condition.

Replay: independently reconstruct physical10 commutators, source couplings,
derivative matrices and quartic Q, and compare each to its own literal input
BEFORE a pole. Derive sparse indexed color contractions using the qualified
unit factors and exterior ordering. No primary Hessian/trace/pole is imported.
With S(i,L,h), K(i,j;k,l) ghost-antisymmetric, F(L,j;k), X(L,j;k), and Q(j,m;k,l)
antisymmetric in both pairs, the separate terms are:

- box: -2*S(i,L,h)*F(U,h;a)*X(U,j;m)*F(L,m;b);
- triangle K-external-antighost: -2*K(i,j;m,n)*F(U,m;a)*X(U,n;b);
- triangle X-external-antighost: +2*K(i,m;n,a)*F(U,n;b)*X(U,j;m);
- bubble K-external-antighost: -2*K(i,j;m,n)*Q(m,n;a,b), m<n and a<b;
- bubble Q-external-antighost: +2*K(i,m;n,a)*Q(j,n;m,b).

Sum internal indices and canonicalize the external ordered ghosts a,b with
the exterior sign, not an additional manual factor2. Use the full internal
ghost-antisymmetric K for triangle/Q-external terms, and ordered m<n for the
K-external bubble to avoid double-counting. The potential F-external-antighost
terms require the actual derivative-on-ghost matrices; exclude them only after
proving their required heavy-vector block vanishes. Do not infer action zeros
from toy kernels. No projected-heavy Jacobi identity is assumed.

Recheck the physical derivative/source carrier metrics and reverse-frame
maps. Any further H/M-profile restriction must follow from the actual matrices,
not the earlier over-approximate role screen. Compare all family and total
tensors, complete zero complements, reality and canonical roundtrips only after
both actual routes complete. Preserve first disagreement; no fitting/relabeling.
Unit-kernel/derivative controls and deliberate family/source-normalization
defects must be assessed; a genuinely zero family has no omission sensitivity
and must not be claimed as a discriminating control.

Freeze exact classical input/source/controller bytes before two sequential
actual workers, each120seconds after imports,8GiB sampled private memory and
350MiB available commit minimum. Workers are read-only and deny prior measured
poles, candidates, external raw records and peers. They may read only their
classical inputs and the qualified new unit/inventory records. No old large
loop is repeated. Preserve all failed/incomplete work and resource exhaustion.
Corrections require a separate preserved bounded continuation under standing
delegation; no silent cap increase, truncation or automatic retry within V1.

After actual paired tensor agreement, a separately frozen bounded dependent
assessment may release the known58836-term functional recipe and1840-term
partial auxiliary relation. Add the new node ONCE; derive its complete selected
Slavnov contribution from actual E2 images, retain all45 Euler checks, and
evaluate the full local-H Ward variation. Do not assume the relation or an
unknown quantum breaking zero. No full restored scheme or normalizer is adopted.

Validation must authenticate frozen source/input/resource/capture evidence,
compare every family/total including implicit zero domains, establish the
actual unit-to-vertex correspondence, check all12 H identities and exact
primal/dual/canonical conversion, and preserve prior/current byte invariance.
Fresh same-command pairs or old expensive E5 replays are not automatic.
Independent algorithms share some action/frame/exact arithmetic/Python/SymPy
and analyst; this is internal corroboration, not independent expert endorsement.

Possible outcomes: a qualified actual pole plus bounded relation assessment;
qualified pole with an unresolved later obligation; actual method disagreement;
or resource/method incompleteness. None establishes full E5/A5, anomaly freedom,
HB1/C5, finiteC1_GS, physical matching or viability. Preserve quartetFAIL3960/
648 and earlier g2 failure, Ward18416 until actually updated, paused flavor,
custodyexit2/seven and all scalar results/control warnings. No foundational,
benchmark/input, authority, remote or publication change. Science and AI
capability are equal objectives; education remains voluntary and nonblocking.
