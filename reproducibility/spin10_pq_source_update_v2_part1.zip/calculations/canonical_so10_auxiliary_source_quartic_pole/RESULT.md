# Actual auxiliary-source quartet pole and selected relation

Require validation_receipt.json and the raw Git checks; this report alone is
not qualification. The unchanged [record](RECORD.md) and preserved V2/V3/V4
continuations define the question, conventions, resource limits and failures.

The integer graded Schur calculation and independently reconstructed physical10
indexed Wick calculation agree exactly on the three actual one-loop families,
their sum and physical densities over all2,004,750 ordered source/antighost/
antisymmetric-ghost slots. Nonzero coefficients: box12,892; triangle10,096;
bubble12,892; total10,096. The remaining slots are exact implicit zeros.
Actual derivative matrices further restrict every nonzero index to the33
heavy directions; the earlier type inventory only supplied a conservative
envelope. The common unit is hbar*g10³*xi/(32pi²epsilon_UV), ordered
JLambda_i*a_j*C_k*C_l with k<l and no extra1/2. Reference widths drop out;
no finite or IR conclusion follows from this dimension-zero local UV result.

After completed actual tensor agreement, the dependent assessment releases the
qualified known-functional recipe. Exact constant graded primal/dual pullbacks
and complete polynomial roundtrips in BOTH coordinate frames turn the new
physical tensor into1,840 canonical terms. Adding the node exactly once changes
the known-functional count58,836 to60,676. Its selected auxiliary/no-jet Slavnov
contribution cancels the old1,840-term projection exactly. All45 antighost
Euler derivatives vanish; no jet/boundary remainder is discarded. The selected
auxiliary input census now has no unmeasured class. The lower-g2 two-jet relation
is unchanged. Omitting or double-counting the new node leaves a nonzero selected
relation; this is a discriminating control, not a fitted normalization.

The full actual local background Ward variation of the new node is zero in
both frames. All12 H identities remain required by final validation. The
existing known-functional Ward remainder stays18,416 terms and is nonzero.
The measured left side of ONE selected local logarithmic relation is zero;
the unknown quantum breaking has not been assumed zero. Full E5/A5 restoration,
anomaly freedom and a complete UV functional are not established. Quartet
normalizer failure3960physical/648canonical and the earlier g2 failure survive.

The primary uses inherited qualified CLASSICAL vertices only, sealed into a
classical-only projection; it does not freshly derive them. The replay freshly
reconstructs its own literal source/GF vertices and physical10 commutators and
compares them before poles. The primary rechecks all4 Lorentz copies, the
full643 reference/328 scalar complement, source-X adjacency zeros, all29 unit
bridges and denominator-rescaling controls. Its exact16-radical integer lattice
checks256 root and256 exterior products; unbounded integers avoid rounding and
overflow. D=60 scales the actual Hessians; no coefficient space is truncated.
The replay checks five indexed unit patterns and does not assume a projected-
heavy Jacobi identity. Bubble-K is genuinely zero; its omission is not a
discriminating control. Every complete family is nonzero.

Preserve two failed native primary attempts, each exit124/noRESULT at the120s
deadline. V1 used generic Born products; V2 used a rational Schur backend.
Their replays never launched. V3 permits only the indexed replay; V4 separately
freezes the integer primary. Successful primary/replay/dependent runtimes are
46.18/110.38/50.33seconds after imports, each within120seconds,8GiB sampled
private memory and350MiB available-commit launch limits. Native observations
can be qualified while a calculation fails. No fresh same-command pair or
old expensive physics replay is claimed.

Track B: sparse exact arithmetic resolves the primary resource failure while
retaining two mathematically different contractions; blind agreement precedes
dependent comparison. Shared action/frame conventions, qualified unit inputs,
exact-algebra helpers, Python/SymPy and analyst limit independence. These are
bounded internal checks, not independent expert reproduction or evidence that
AI can reliably conduct unrestricted original physics research. Education
remains voluntary/concurrent/nonblocking; no technical proficiency gate.

AGENTS.md remains the authoritative live operating policy and project_state.json
v113/34of39 the sole scientific ledger. No scientific promotion, accepted
benchmark/input/normalizer, physical matching, blocked HB1/C5 activation,
flavor resumption, publication, push or foundational change occurs. Custody
exit2/seven unresolved references is preserved, not rerun or called PASS.
Scalar perturbative-control warnings and all qualified successes/failures
remain. Full scientific and AI-capability objectives are still incomplete.

Next cheapest action: inventory the existing18,416 Ward terms by coupling,
field/jet/source types and known-functional lineage before selecting another
actual quantum calculation. Determine the missing scientific obligation from
that census; do not infer it from this selected zero or fit a Ward completion.
