# Higher-order source-quartet diagram factors are complete

The primary graded-Hessian calculation and connected-Wick replay agree on all
48 ordinaryg4,zero-jet unit kernels, with full four-component momentum and
independent vector-reference widths retained. Eighteen are nonzero;30 vanish
with a derivative on an external field. Qualification requires the completed
validation_receipt.json, not this prose alone. No actual Spin(10) color pole
has been calculated in this increment.

The authenticated complete frontier has three ordinary families, KL*F*F,
SL*D*F and SL*F*F*F, and one g4*xi family, KL*R. The latter reuses the
qualified pure-ghost bubble units -2/+2 for the external antighost on K/R.
That is a kinematic correspondence, not permission to reuse Q's physical
coefficients as R. Its coupling and actual R tensor must be inserted separately.

For each ordinary F vertex, let u=(1,-1,0) for derivatives on(a,B,C) when its
ghost is external, and v=(0,1,-1) when its antighost is external. The compact
qualified unit factors in ordered JLambda,a,C0,C1 convention are:

| Pattern | Unit factor | Nonzero placements |
| --- | --- | --- |
| K_K: external antighost on K | 2 W0 u1 u2 | 4/9 |
| K_F: external antighost on F | 2 W0 v1 u2 | 4/9 |
| S_D: external antighost on D | 2 W1 u1 | 2/3 |
| S_F: external antighost on middle F | -2 W1 u1 v2 u3 | 8/27 |

W0/W1 label the relevant internal B/B line's formal reference width, not a
new physical gauge choice. Actual color contraction must assign the correct
unbroken/heavy width to that line; it cannot set the width merely to erase an
unfavorable coefficient. Other H/M and representation constraints still need
the action-derived color matrices.

The full kernels are known before using the denominator relation. Writing
Q=q²,t=1/Q only at the UV extraction, and

    L(W) = -Q t + (1-W) Q² t² = q.BB(W).q,

the two K patterns have kernel i t² L(W0) times their u/v weights; S_D has
i t² L(W1) u; S_F has -i Q t³ L(W1) u v u. All48 exact raw kernels, including
zero complements, match these contractions. The common logarithmic multiplier
is the inherited2*i*Q², yielding the table above. Every nonzero term has
loop homogeneity-4. This is an explicit denominator lift, not an integration
of a scaleless expression or a finite/IR claim.

Removing B/B or all ghost propagation kills each nonzero anchor. Removing
mixed propagation kills the S patterns and is correctly insensitive for K
patterns. Omitting the transverse B/B term changes W to W-1 in these factors;
the transverse term therefore cannot be silently dropped. All control kernels
and width-dependent values are retained. Forty complete derivative-current
sums vanish. The primary's3 grouped K_K words equal6 distinct-component words;
4 grouped S_F words equal24. A further factorial/half would change the result.
Both routes check all256 products of the16-element exterior basis and reject
an even auxiliary-source grade. Proper Wick connectivity and unique momentum
routing are checked; no disconnected cycles are assigned a common loop flow.

Primary/replay took6.38/20.16seconds after imports under sequential120-second/
sampled8GiB limits. No failed native calculation occurred. The separate frozen
validator compares all full kernels, permutation sums, widths, homogeneity,
current identities and mutants with closed Lorentz contractions and checks
both sides of the full vector/auxiliary and ghost inverse identities. There
are zero fresh same-command replay pairs; distinct-method agreement and byte
authentication are not represented as independent expert or physical validation.

Track A now has complete diagram-normalization inputs for the remaining
higher-order quartet. Track B demonstrates exact-arithmetic reduction of the
48 full-vector cases without a large color compiler, while retaining the
necessary propagator widths. Shared prototypes,action/reference conventions,
helpers,SymPy and AI authorship remain shared-error risks. Track C is
voluntary,concurrent and nonblocking.

Next freeze a bounded actual classical-input extraction for the full S,K,F,D,R
tensors and carrier metrics. Reuse qualified inputs where present, and verify
literal versus physical-adjoint reconstructions before a pole. Then combine
these units through graded closed contractions; preserve source/ghost order,
all external-antighost partitions and zero complements. First assess whether
Schur/low-rank identities can avoid a full2004750-slot tensor. Do not fill an
unknown coefficient by imposing a desired Slavnov cancellation.

Known Gamma145546 and its V189 hash/recipe are unchanged. Previous selected
zeros and historical failures survive. Full source closure,E5/A5,QAP,measure,
finite contacts/physical IR and anomaly freedom remain unqualified. Authority
v113/34of39,HB1/C5 blocked,C1_GS uncomputed,flavor human-paused,scalar quantum
warnings and custodyexit2/seven remain unchanged. No accepted input,benchmark,
foundation,publication or remote action is introduced.
