"""Higher-order source quartet: exact general-q Born versus connected Wick."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from itertools import permutations,product
from math import factorial
import json,os,sys,threading,time
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ_I
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register
from a10_e2_transport_common import partials
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
R,k0,k1,k2,k3,t,W0,W1=ring('q0,q1,q2,q3,t,width0,width1',QQ_I);K=[k0,k1,k2,k3];II=R.from_expr(s.I);ETA=(1,-1,-1,-1)
num=lambda z:R.from_expr(s.sympify(z));ZERO=R.zero;ONE=R.one;qs=[v.as_expr() for v in K];Q=sum(ETA[mu]*qs[mu]**2 for mu in range(4))
CASES=[(kind,ds) for kind,n in [('K_K',2),('K_F',2),('S_D',1),('S_F',3)] for ds in product(['a','B','c'],repeat=n)]
def key(kind,ds):return kind+'_'+''.join(ds)
def model(kind,ds):
    w=alphabet();w.fields={**{f'uv_B{a}_{mu}':(1,0,0) for a in range(2) for mu in range(4)},**{f'uv_L{a}':(2,0,0) for a in range(2)},**{f'uv_{tag}{a}':(1,1 if tag=='c' else -1,1) for a in range(2) for tag in ['a','c']}}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:v[2] for n,v in w.fields.items()}
    for n,grade in [('uv_J',(1,-1,1)),('uv_aE',(1,-1,1)),('uv_C0',(1,1,1)),('uv_C1',(1,1,1))]:register(w,n,grade)
    v=w.var
    def F(a,c,b,where):return w.add(*(w.scale(w.mul(w.D(v(a),mu) if where=='a' else v(a),w.D(v(f'uv_B{b}_{mu}'),mu) if where=='B' else v(f'uv_B{b}_{mu}'),w.D(v(c),mu) if where=='c' else v(c)),ETA[mu]) for mu in range(4)))
    if kind=='K_K':V=[w.mul(v('uv_J'),v('uv_aE'),v('uv_c0'),v('uv_c1')),F('uv_a0','uv_C0',0,ds[0]),F('uv_a1','uv_C1',0,ds[1])]
    elif kind=='K_F':V=[w.mul(v('uv_J'),v('uv_a0'),v('uv_c1'),v('uv_C0')),F('uv_aE','uv_c0',0,ds[0]),F('uv_a1','uv_C1',0,ds[1])]
    elif kind=='S_D':V=[w.mul(v('uv_J'),v('uv_L0'),v('uv_c0')),w.add(*(w.scale(w.mul(v('uv_aE'),v('uv_C0'),v(f'uv_B0_{mu}'),v(f'uv_B1_{mu}')),ETA[mu]) for mu in range(4))),F('uv_a0','uv_C1',1,ds[0])]
    else:
        assert kind=='S_F';V=[w.mul(v('uv_J'),v('uv_L0'),v('uv_c0')),F('uv_a0','uv_C0',1,ds[0]),F('uv_aE','uv_c1',1,ds[1]),F('uv_a1','uv_C1',0,ds[2])]
    assert all(w.grade(P,(4,0,0)) for P in V)
    return w,V,w.mul(v('uv_J'),v('uv_aE'),v('uv_C0'),v('uv_C1'))
def inverse(a,b,epsilon=1,omit_BB=False,omit_mixed=False,omit_ghost=False,omit_transverse=False):
    if a.startswith('uv_B') and b.startswith('uv_B') and a[4]==b[4]:
        if omit_BB:return ZERO
        mu,nu=int(a[-1]),int(b[-1]);width=[W0,W1][int(a[4])]
        return (ZERO if omit_transverse else -num(ETA[mu]*int(mu==nu))*t)+(ONE-width)*K[mu]*K[nu]*t**2
    if a.startswith('uv_B') and b=='uv_L'+a[4]:return ZERO if omit_mixed else II*epsilon*K[int(a[-1])]*t
    if b.startswith('uv_B') and a=='uv_L'+b[4]:return ZERO if omit_mixed else -II*epsilon*K[int(b[-1])]*t
    if a in ['uv_c0','uv_c1'] and b=='uv_a'+a[-1]:return ZERO if omit_ghost else t
    if a in ['uv_a0','uv_a1'] and b=='uv_c'+a[-1]:return ZERO if omit_ghost else -t
    return ZERO
def exterior(P,Q):
    out={}
    for a,z in P.items():
        for b,c in Q.items():
            if a&b:continue
            sign=(-1)**sum(1 for i in range(4) if a&(1<<i) for j in range(i) if b&(1<<j));mask=a|b;out[mask]=out.get(mask,ZERO)+sign*z*c
    return {mask:z for mask,z in out.items() if z}
def mm(A,B):
    rows={};out={}
    for (h,j),Q in B.items():rows.setdefault(h,[]).append((j,Q))
    for (i,h),P in A.items():
        for j,Q in rows.get(h,[]):
            cell=out.setdefault((i,j),{})
            for mask,z in exterior(P,Q).items():cell[mask]=cell.get(mask,ZERO)+z
    return {ij:{mask:z for mask,z in P.items() if z} for ij,P in out.items() if any(P.values())}
def extpack(P,order):
    pos={n:i for i,n in enumerate(order)};out={}
    for word,z in P.items():
        if any(jets for n,jets in word):continue
        assert all(n in pos for n,jets in word);ids=[pos[n] for n,jets in word]
        if len(set(ids))!=len(ids):continue
        mask=sum(1<<i for i in ids);sign=(-1)**sum(a>b for i,a in enumerate(ids) for b in ids[i+1:]);out[mask]=out.get(mask,ZERO)+sign*num(z)
    return {mask:z for mask,z in out.items() if z}
def Hessian(P,w,order):
    names=list(w.fields);pos={n:i for i,n in enumerate(names)};out={}
    for (a,alpha),first in partials(P,w,set(names)).items():
        for (b,beta),second in partials(first,w,set(names)).items():
            factor=num((-1)**(w.p[b]*(w.p[a]+1)))
            for mu in alpha:factor*=-II*K[mu]
            for mu in beta:factor*=II*K[mu]
            selected={word:z for word,z in second.items() if all(n in w.external for n,j in word)};packed=extpack(selected,order)
            cell=out.setdefault((pos[a],pos[b]),{})
            for mask,z in packed.items():cell[mask]=cell.get(mask,ZERO)+factor*z
    return {ij:{mask:z for mask,z in P.items() if z} for ij,P in out.items() if any(P.values())}
def born(kind,ds,grouped=False,**opts):
    w,V,target=model(kind,ds);names=list(w.fields);order=sorted(w.external);normal=extpack(target,order)[15];assert normal in [ONE,-ONE]
    G={(i,j):{0:z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=inverse(a,b,**opts))};Hs=[Hessian(P,w,order) for P in V];n=len(Hs)
    if grouped:
        assert kind in ['K_K','K_F','S_F'];F={}
        for A in Hs[1:]:
            for ij,P in A.items():
                cell=F.setdefault(ij,{})
                for mask,z in P.items():cell[mask]=cell.get(mask,ZERO)+z
        patterns=sorted(set(permutations(('S',*['F']*(n-1)))));orders=[[Hs[0] if tag=='S' else F for tag in pattern] for pattern in patterns]
    else:orders=list(permutations(Hs))
    values=[]
    for order in orders:
        A=G
        for j,H in enumerate(order):
            A=mm(A,H)
            if j<n-1:A=mm(A,G)
        z=sum(((-1)**w.p[names[i]]*P.get(15,ZERO) for (i,j),P in A.items() if i==j),ZERO)*II*num(s.Rational((-1)**(n+1),2*n))*normal
        values.append(z)
    return sum(values,ZERO),{'ordered_Born_kernels':[str(z.as_expr()) for z in values],'word_count':len(values),'grouped_identical_F':grouped}
def pairings(legs,opts):
    if not legs:yield ();return
    a=legs[0]
    for i,b in enumerate(legs[1:],1):
        if a[0]==b[0] or not inverse(a[1],b[1],**opts):continue
        sign=(-1)**(a[3]*sum(z[3] for z in legs[1:i]))
        for rest in pairings(legs[1:i]+legs[i+1:],opts):yield ((a,b,sign),*rest)
def connected(pairs,n):
    found={0}
    for _ in range(n):found|={b[0] for a,b,sg in pairs if a[0] in found}|{a[0] for a,b,sg in pairs if b[0] in found}
    return len(found)==n
def wick(kind,ds,**opts):
    w,V,target=model(kind,ds);external=set(w.external);targetword,normal=next(iter(target.items()));n=len(V);values=[];counts=[];disconnected=0
    for ordered in permutations(V):
        total=ZERO;count=0
        for terms in product(*(list(P.items()) for P in ordered)):
            coefficient=ONE;full=[];legs=[]
            for vertex,(word,z) in enumerate(terms):
                coefficient*=num(z)
                for pos,(name,jets) in enumerate(word):
                    token=(vertex,name,jets,w.p[name],pos);full.append(token)
                    if name not in external:legs.append(token)
                    elif jets:coefficient=ZERO
            if not coefficient or len(legs)!=2*n:continue
            coefficient*=num((-1)**sum(a[3]*b[3] for i,a in enumerate(full) if a[1] not in external for b in full[i+1:] if b[1] in external))
            coefficient*=num(w.mul(*(w.var(nm) for v,nm,j,par,pos in full if nm in external)).get(targetword,0)/normal)
            if not coefficient:continue
            for pairs in pairings(legs,opts):
                if not connected(pairs,n):disconnected+=1;continue
                routes=[eps for tail in product([-1,1],repeat=n-1) for eps in [(1,*tail)] if all(sum((int(a[0]==v)-int(b[0]==v))*e for (a,b,sg),e in zip(pairs,eps))==0 for v in range(n))]
                assert len(routes)==1,'UNIQUE_PROPER_CYCLE_FLOW';z=coefficient;count+=1
                for (a,b,sg),e in zip(pairs,routes[0]):
                    z*=num(sg)*II*inverse(a[1],b[1],e,**opts)
                    for mu in a[2]:z*=II*e*K[mu]
                    for mu in b[2]:z*=-II*e*K[mu]
                total+=z
        values.append(-II*II**n*total);counts.append(count)
    assert all(z==values[0] for z in values),'WICK_VERTEX_ORDER_INDEPENDENCE'
    return sum(values,ZERO)*num(s.Rational(1,factorial(n))),{'permutation_Wick_kernels':[str(z.as_expr()) for z in values],'proper_pairing_counts':counts,'word_count':len(values),'all_vertex_orders_agree':True,'disconnected_matchings_rejected':disconnected,'exponential_factor':'1/'+str(factorial(n))}
def pole(z):
    lifted=s.factor(s.cancel(2*s.I*Q**2*z.as_expr().subs(t.as_expr(),1/Q)));assert not lifted.has(*qs,t.as_expr(),s.Float) and s.Poly(lifted,W0.as_expr(),W1.as_expr()).total_degree()<=1
    return lifted
def basis():
    w,V,target=model('S_F',('a','c','a'));order=sorted(w.external);B={mask:w.mul(*(w.var(n) for i,n in enumerate(order) if mask&(1<<i))) for mask in range(16)}
    for a in range(16):
        assert extpack(B[a],order)=={a:ONE}
        for b in range(16):assert extpack(w.mul(B[a],B[b]),order)==exterior({a:ONE},{b:ONE})
    return {'elements':16,'products':256,'repeated_odd_generators_zero':True}
def main():
    started=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('HIGHER_QUARTET_UNITS_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('HIGHER_QUARTET_GROUP_POLE_GAMMA_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard)
    folder=ROOT/'calculations/canonical_so10_single_source_uv_frontier';r=read(folder/'validation_receipt.json');path=folder/(role+'_result.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(path)]==digest(path)
    front=read(path)['targets']['C_C_JL_a__j0'];active={name:v for name,v in front['candidate_families'].items() if v['g']==4 and v['profiles']};assert set(active)=={'KL*F*F','SL*D*F','SL*F*F*F','KL*R'}
    for name,v in active.items():assert v['xi']==int(name=='KL*R')
    old=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_units/validation_receipt.json');assert old['status']=='COMPLETED_PAIRED_29_GENERAL_Q_UNIT_KERNELS_ONLY' and old['all29_nominal_kernels_agree'];assert old['poles']['Q_K_aa']=='-2' and old['poles']['Q_Q_aa']=='2'
    b=basis();calculate=born if role=='primary' else wick;table={};details={};assert len(CASES)==48
    for kind,ds in CASES:
        label=key(kind,ds);print('STAGE '+role+' '+label,flush=True);z,info=calculate(kind,ds);table[label]=str(pole(z));details[label]={'full_general_q_kernel':str(z.as_expr()),**info}
    ibp=[]
    for kind,n in [('K_K',2),('K_F',2),('S_D',1),('S_F',3)]:
        for slot in range(n):
            for rest in product(['a','B','c'],repeat=n-1):
                choices=[tuple([*rest[:slot],where,*rest[slot:]]) for where in ['a','B','c']];assert s.expand(sum(s.sympify(table[key(kind,ds)]) for ds in choices))==0;ibp.append([kind,slot,list(rest)])
    anchors={'K_K':('a','a'),'K_F':('c','a'),'S_D':('a',),'S_F':('a','c','a')};controls={};grouping={}
    for kind,ds in anchors.items():
        base=s.sympify(table[key(kind,ds)]);assert base!=0
        for mutation in ['omit_BB','omit_mixed','omit_ghost','omit_transverse']:
            z,info=calculate(kind,ds,**{mutation:True});value=pole(z);changes=s.expand(value-base)!=0
            assert changes==(mutation!='omit_mixed' or kind in ['S_D','S_F'])
            controls[kind+'_'+mutation]={'pole':str(value),'changes_result':changes,'full_general_q_kernel':str(z.as_expr())}
        if role=='primary' and kind in ['K_K','S_F']:
            z,info=born(kind,ds,grouped=True);assert pole(z)==base and info['word_count']==(3 if kind=='K_K' else 4);grouping[kind]={'pole':str(base),'grouped_words':info['word_count'],'distinct_component_words':details[key(kind,ds)]['word_count'],'wrong_extra_half_changes_anchor':s.expand(base/2-base)!=0}
    w,V,T=model('S_F',('a','c','a'));w.external['uv_J']=(1,-1,0);w.p['uv_J']=0;assert not w.grade(V[0],(4,0,0))
    result={'schema':'HIGHER_AUXILIARY_QUARTET_UNIT_KERNELS_V1','route':role,'complete_g4_family_envelope_reused':active,'all48_general_q_units':table,'full_kernel_details':details,'all_derivative_IBP_sums_checked':ibp,'controls':controls,'identical_F_grouping':grouping,'basis':b,'JLambda_odd_grade_control_rejected':True,'g4_xi_bubble_unit_reused_not_recalculated':{'K_external_antighost':'-2','R_external_antighost':'2'},'reference_widths_retained':True,'denominator_relation':'t=1/(q0**2-q1**2-q2**2-q3**2)','unit_multiplier':'2*I*(q^2)^2','actual_group_coefficient_or_physical_pole_calculated':False,'finite_IR_or_scaleless_zero_inferred':False,'known_Gamma_updated':False,'full_source_Slavnov_E5_A5_or_anomaly_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-started}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
