# Symbolic inverse-check correction V2

Both calculation workers completed. The first validator failed at its ghost
inverse assertion because direct SymPy Matrix equality compared unsimplified
rational expressions structurally. It did not establish a nonzero residual.
Preserve that validator,preparation and complete native exit1 capture, without
a qualification receipt. Use entrywise exact rational cancellation of H*G-I
and G*H-I, as already required for the even block. No matrix entry,sign,
normalization or acceptance condition changes. Every remaining check stays.

Freeze V2 under the same120-second/sampled8GiB bound. Reuse the completed
primary/replay; do not rerun either calculation or old physics. The standard
validation receipt, if V2 completes, must bind the corrected validator and
explicitly preserve the original failed execution. It does not qualify V1.
The prospective RESULT/V192 statement of no failed new run concerns the two
calculation workers only; there is now one failed validator. V193 makes this
qualification explicit. This is an engineering mistake in a verification
oracle, not a demonstrated physical failure or a passing scientific gate.
