# Complete higher-order auxiliary-source quartet unit factors V1

Baselined8132ca247e9832050311a40e96b36a478d3d921; AGENTS standing delegation,
statev113/34of39 unchanged. Question: what are the complete diagram factors
needed to measure the remaining CD0,no-jet g4 andg4*xi JLambda*a*C*C pole?
Do not derive a missing pole from a desired source/Slavnov identity.

Authenticate/reuse the complete V170 frontier. Ordinaryg4 has KL*F*F,
SL*D*F and SL*F*F*F. The g4*xi contribution has only KL*R. The latter's
two pure-ghost bubble unit patterns are identical to the qualified Q_K/Q_Q
patterns (-2,+2) after stripping their explicit coupling. Reuse those factors
with their exact receipt; do not rerun or call that reuse fresh evidence.
No actual R coefficient is supplied by a Q coefficient.

Compute all48 general-four-momentum ordinary unit patterns. K_K and K_F
denote whether the external antighost is on the source quartic or an F vertex;
each has two F vertices and9 derivative placements. S_D has its external
antighost/one ghost on D, the other ghost on F:3 placements. S_F has external
ghosts on two F vertices and an antighost on the third:27 placements. For each
F retain derivative on a,B or C, including explicit external-derivative zeros.
Sources/backgrounds have no inverse. Every loop vertex has two quantum legs;
other external partitions cannot make a proper one-loop graph in this valence
and field domain. The complete frontier remains the color/HM envelope.

Use ordered JLambda,a,C0,C1 with all four odd generators and no extra pair
divisor. Two quantum vector colors and two ghost pairs separate the required
contractions. Preserve the full4-component B/B inverse including transverse
part and independent widths; retain mixed B/L, both ghost orientations and
L/L0. These kinematic units do not impose an actual color matrix or H/M
restriction. Keep a formal inverse denominator until isolating the logarithmic
coefficient in the qualified 2*i*(q²)^2 convention; no scaleless IR zero.

Primary: complete graded Hessian/Born expansion with the exact supertrace
logarithm factor, sparse exterior masks and rational polynomial arithmetic.
Replay: explicit connected proper Wick pairings, external Grassmann signs,
unique momentum routing, all vertex permutations and exponential factor.
Compare full general-q kernels and separate permutation data, not only poles.
Polynomial-ring arithmetic changes no coefficient or integration prescription.
All48 cases and implicit zeros must complete inside the resource boundary.

For each F, its three derivative placements sum to an IBP current and must
give zero in this no-jet target. Primary groups identical F components and
compares the multiset words with all distinct-component words for nonzero
triangle/box anchors. A wrong extra factorial/half must change the anchor.
Controls omit B/B,mixed or all ghost propagation and remove the transverse
B/B part. Require nonzero anchors and report insensitive cases explicitly.
Verify all256 exterior-basis products and reject an even JLambda grading.
No invalid one-orientation propagator is required to agree between methods.

Two sequential read-only120-second/sampled8GiB workers,>=350MiB available
commit; freeze sources,controllers,inputs and own-role JSON allowlists first.
Capture complete native failures/incompleteness, never truncate or silently
increase limits. Separate bounded verification of exact kernels, dimensions,
derivative patterns, signs,widths,grouping and controls precedes local commit.
No actual large color pole,old expensive loop/full Gamma,parameter search,
physical input,benchmark or scheme is introduced. A disagreement or exhaustion
stays unqualified; reassess the exact failed method before a versioned repair.

Expected deliverable: complete unit inputs for a separately bounded actual
color contraction, or a precise mathematical/resource limitation. This is not
the higher-order physical color pole, full source closure,E5/A5,QAP,measure,
finite/IR validity or anomaly freedom. Gamma145546/hash and prior source zeros
unchanged; HB1/C5 blocked,C1_GS uncomputed,flavor paused,scalar warnings and
custodyexit2/seven preserved. Shared action/types/reference/SymPy/helpers/AI
authorship limit independence. Science and AI capability remain equal tracks;
education voluntary,concurrent,nonblocking. No protected or remote changes.
