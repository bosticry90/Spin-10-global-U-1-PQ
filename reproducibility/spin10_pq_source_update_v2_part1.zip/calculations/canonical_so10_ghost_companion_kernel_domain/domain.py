"""Complete typed two-momentum ghost-companion cycle plans, no pole fitting."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import permutations,combinations,product
from functools import lru_cache
import json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
from hashlib import sha256
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def freeze(x):return tuple(freeze(v) for v in x) if isinstance(x,list) else x
def typ(n):return 'x' if n.startswith('X_') else n[0]
def dim(n):return 2 if typ(n)=='L' else 1
def allowed(outside,target):
    counts=Counter(typ(n) for n,j in outside);return all(n in [target,'a','C'] and count<=1 for n,count in counts.items())
def options(vertices,role):
    out=set()
    for tag,v in vertices.items():
        if v['cd'] or v['degree'] not in [3,4] or v['g']>3:continue
        for row in v['ports']:
            row=freeze(row)
            pairs=permutations(range(len(row)),2) if role=='primary' else (p for i,j in combinations(range(len(row)),2) for p in [(j,i),(i,j)])
            for i,j in pairs:
                if typ(row[i][0])=='A' or typ(row[j][0])=='A':continue
                out.add((tag,row[i],row[j],tuple(sorted(row[k] for k in range(len(row)) if k not in [i,j]))))
    return sorted(out)
def descriptor(seq,vertices,edges):
    n=len(seq);outside=tuple(sorted(p for row in seq for p in row[3]));degree=4+sum(row[1][1]+row[2][1] for row in seq);BB=[]
    for i,row in enumerate(seq):
        right=seq[(i+1)%n][1][0];left=row[2][0];assert (left,right) in edges;degree+=dim(left)+dim(right)-4
        if typ(left)==typ(right)=='B':BB.append(left)
    assert degree==1-sum(j for name,j in outside) and degree in [0,1]
    return (outside,1,sum(vertices[row[0]]['g'] for row in seq),sum(vertices[row[0]]['xi'] for row in seq),0,(),tuple(sorted(set(BB))),tuple(sorted(row[0] for row in seq))),degree,len(BB)
def profilekey(row):return (freeze(row['external_ports']),row['total_external_jets'],row['g'],row['explicit_vertex_xi'],row['vertex_coefficient_dimension'],freeze(row['scalar_reference_mass_expansions']),freeze(row['BB_width_roles']),freeze(row['vertex_family']))
def enumerate_cycles(vertices,edges,target,role):
    opts=[row for row in options(vertices,role) if allowed(row[3],target)];roots=[row for row in opts if any(typ(n)==target for n,j in row[3])];extras=[row for row in opts if not any(typ(n)==target for n,j in row[3])];cycles=set();calls=0
    def visit(seq):
        nonlocal calls;calls+=1;outside=tuple(p for row in seq for p in row[3]);gp=sum(vertices[row[0]]['g'] for row in seq)
        if len(outside)>3 or gp>3 or not allowed(outside,target):return
        if len(outside)==3:
            if gp!=3 or len(seq) not in [2,3] or (seq[-1][2][0],seq[0][1][0]) not in edges:return
            pos=next(i for i,row in enumerate(seq) if any(typ(n)==target for n,j in row[3]));cyc=seq[pos:]+seq[:pos];descriptor(cyc,vertices,edges);cycles.add(cyc);return
        for row in extras:
            if role=='primary':
                if (seq[-1][2][0],row[1][0]) in edges:visit(seq+(row,))
            else:
                if (row[2][0],seq[0][1][0]) in edges:visit((row,)+seq)
    for root in roots:visit((root,))
    return sorted(cycles),calls
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
EXT={'A':(0,1,0),'B':(0,1,0),'a':(0,-1,-1),'C':(0,0,1)}
def routing(seq):
    edge=(1,0,0);legs=[]
    for tag,inp,out,external in seq:
        E=(0,0,0)
        for n,j in external:E=add(E,EXT[typ(n)])
        incoming=neg(edge);outgoing=add(edge,neg(E));assert add(add(incoming,outgoing),E)==(0,0,0);legs.append({'internal_in':incoming,'internal_out':outgoing,'external':[[n,j,EXT[typ(n)]] for n,j in external]});edge=outgoing
    assert edge==(1,0,0)
    for i,row in enumerate(legs):assert add(row['internal_out'],legs[(i+1)%len(legs)]['internal_in'])==(0,0,0)
    return legs
def kinematics(role):
    # Ordered local placements [dV*a*C,V*da*C,V*a*dC].
    boundary=s.Matrix([[1,1,1]]);sampling=s.Matrix([[0,-1,1],[1,-1,0]]);basis=s.Matrix([[1,-1,0],[0,-1,1]])
    if role=='primary':assert sampling.rank()==2 and sampling.nullspace()==[s.ones(3,1)]
    else:assert sampling[:,[0,2]].det()!=0 and sampling*s.ones(3,1)==s.zeros(2,1)
    assert sampling*s.Matrix([1,0,0])==s.Matrix([0,1]) and sampling*s.Matrix([0,0,1])==s.Matrix([1,0]);a,b,c=s.symbols('cV ca cC');assert basis*s.Matrix([a,b,c])==s.Matrix([a-b,c-b]);assert all(s.diag(1,-1,-1,-1)[mu,nu]==(1 if mu==0 else -1)*int(mu==nu) for mu,nu in product(range(4),repeat=2))
    # Finite complex Grassmann Gaussian determinant and matching2x2 STr.
    P,u,v,e,f=s.symbols('P u v e f',nonzero=True);K=s.Matrix([[0,-P],[P,0]]);G=K.inv();U=s.Matrix([[0,-u],[u,0]]);V=s.Matrix([[0,-v],[v,0]]);STr=-s.trace(G*U*G*V);assert s.expand(STr+2*u*v/P**2)==0
    determinant_log=s.series(-s.I*s.log(P+e*u+f*v),e,0,2).removeO();determinant_log=s.series(determinant_log,f,0,2).removeO().expand();coefficient=s.expand(determinant_log).coeff(e).coeff(f);trace_coefficient=-s.I*STr/2;assert s.simplify(coefficient-trace_coefficient)==0 and s.simplify(coefficient+s.I*s.trace(G*U*G*V)/2)!=0
    return {'local_placement_dimension':3,'IBP_relation':[1,1,1],'quotient_dimension':2,'sampling_matrix_rzero_then_qzero':[[0,-1,1],[1,-1,0]],'anchor_no_da_coefficients':['cV-ca','cC-ca'],'either_single_probe_rank':1,'both_probe_rank':2,'constant_vector_invisible_nonzero_quotient_witness':[1,0,0],'constant_ghost_invisible_nonzero_quotient_witness':[0,0,1],'all4_metric_components_and32_unit_slots_required':True,'finite_Grassmann_determinant_equals_STr_coefficient':str(s.simplify(coefficient)),'naive_boson_trace_sign_control_sensitive':True,'actual_graded_Wick_multiplicities_or_new_pole_not_inferred':True}
def auth(folder,name):
    p=ROOT/'calculations'/('canonical_so10_'+folder)/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed_json={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('GHOST_DOMAIN_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed_json:raise PermissionError('GHOST_DOMAIN_UNDECLARED_OR_PEER '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' complete_actual_typed_cyclic_domains_and_momentum_routings',flush=True);inv=auth('sourcefree_cycle_inventory',role+'_v2_result.json');vertices=inv['actual_sourcefree_vertices'];edges={tuple(e) for e in inv['actual_reference_edges']};targets={};allfamilies=set()
    for target,count in [('A',15),('B',104)]:
        old=[row for row in inv['all_profiles'] if sorted(typ(n) for n,j in row['external_ports'])==[target,'C','a'] and row['g']==3 and row['total_external_jets']==1];assert len(old)==count and all(row['vertex_coefficient_dimension']==0 and not row['scalar_reference_mass_expansions'] for row in old);cycles,calls=enumerate_cycles(vertices,edges,target,role);by=defaultdict(list);families=defaultdict(lambda:{'cycles':0,'profiles':set(),'max_BB_edges':0,'all_ghost_cycles':0});encoded=[]
        for seq in cycles:
            key,degree,nBB=descriptor(seq,vertices,edges);by[key].append(seq);family=tuple(sorted(vertices[row[0]]['base'] for row in seq));info=families[family];info['cycles']+=1;info['profiles'].add(key);info['max_BB_edges']=max(info['max_BB_edges'],nBB);info['all_ghost_cycles']+=all(typ(row[1][0]) in ['a','C'] and typ(row[2][0]) in ['a','C'] for row in seq);encoded.append({'vertices':seq,'routing_k_r_q':routing(seq),'profile':list(key),'raw_UV_and_Taylor_degree':degree,'ordinary_BB_width_degree_upper':nBB})
        assert set(by)==set(map(profilekey,old));summary=[{'family':family,**{k:(len(v) if isinstance(v,set) else v) for k,v in value.items()}} for family,value in sorted(families.items())];allfamilies.update(families);controls={}
        for name,vs,es in [('omit_R',{k:v for k,v in vertices.items() if v['base']!='R'},edges),('omit_mixed_edges',vertices,{e for e in edges if set([typ(e[0]),typ(e[1])])!={'B','L'}}),('omit_BB_edges',vertices,{e for e in edges if not (typ(e[0])==typ(e[1])=='B')})]:
            alt,unused=enumerate_cycles(vs,es,target,role);altkeys={descriptor(seq,vs,es)[0] for seq in alt};controls[name]={'lost_profiles':len(set(by)-altkeys),'changes_support':altkeys!=set(by)}
        targets[target]={'qualified_profiles':count,'complete_oriented_rooted_cycles':len(cycles),'enumeration_states':calls,'family_summary':summary,'all_routed_cycles':encoded,'controls':controls,'every_qualified_profile_has_all_its_typed_cycles':True}
    assert len(allfamilies)==7 and targets['B']['controls']['omit_R']['lost_profiles']==2 and not targets['A']['controls']['omit_R']['changes_support'];assert any(info['max_BB_edges']==2 for target in targets.values() for info in target['family_summary'])
    print('STAGE '+role+' complete_two_momentum_IBP_and_closed_ghost_sign_proof',flush=True);kin=kinematics(role)
    current=auth('auxiliary_companion_canonical',role+'_result.json');prior=auth('sourcefree_reconciliation',role+'_result.json');assert current['updated_known_terms']==147266 and current['updated_known_sha256']=='c445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4' and current['prior_known_sha256']==prior['current_known_sha256'];assert all(row['known_positions']==0 for row in prior['predecessor_evidence_and_unmeasured_profiles']['ghost'] if row['g']==3);tb=read(ROOT/f'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry/{role}.json')['operators']['Tb_geometric_and_transported']
    for name in {n for row in current['new_actual_g3_auxiliary_companion_node'] for n in row['word']}:
        assert not name.startswith(('bar','ub','C'))
        for row in tb[name]:assert all(t.split('__')[0].startswith(('omega','A','B','L','b')) for t in row['word'])
    result={'schema':'GHOST_COMPANION_COMPLETE_ROUTED_KERNEL_DOMAIN_V1','route':role,'scientific_disposition':'QUALIFIED_COMPLETE119_PROFILE_ROUTED_DOMAIN_AND_TWO_PROBE_METHOD_ONLY','targets':targets,'two_derivative_structure_and_graded_sign_proof':kin,'complete_family_count':len(allfamilies),'ordinary_ghost_g3_poles_still_unmeasured':True,'current_functional_terms':147266,'current_functional_sha256':current['updated_known_sha256'],'new_auxiliary_node_cannot_change_ghost_Ward_gap_by_actual_H_type_filtration':True,'current_AaC_BaC_g3_known_positions':0,'ghost_partial_Ward_gap_preserved_not_anomaly':True,'all_width_vs_explicit_xi_and_profile_count_not_Feynman_factor_warnings_retained':True,'new_pole_or_current_functional_or_Ward_fit_computed':False,'full_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
