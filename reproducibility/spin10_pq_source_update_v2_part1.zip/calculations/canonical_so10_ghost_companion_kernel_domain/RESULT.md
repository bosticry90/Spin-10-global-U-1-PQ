# Complete routed domain for the remaining ghost companions

Prospective until the paired V2 results/captures, independent receipt and
committed-byte checks qualify. Baseline e75f6b3a1c44b6847bac124b33b625bbc48195b7.
This is a support and method result, not a measured ultraviolet pole.

The ordinary g3 AaC/BaC one-jet calculation has a complete routed domain
relative to the inherited actual marginal vertex/reference-edge catalogue.
Forward and backward growth agree with all 119 qualified outward profiles.
A third route matches external-leg partitions and solves the momentum
incidence equations rather than growing a cycle.

| Target | Qualified profiles | Directed cycles rooted at external vector |
| --- | ---: | ---: |
| AaC | 15 | 44 |
| BaC | 104 | 480 |
| Total | 119 | 524 |

Only cyclic starting-point redundancy is removed. Opposite orientations
remain distinct. These are typed routing specifications, not graded Wick,
Bose or color multiplicities and not Feynman diagram symmetry factors.
There are seven vertex families in total: DF, DG3, DU, FFF, FFG3, FFU and
FR. The AaC domain uses DF, DU, FFF and FFU. The BaC domain uses all seven.
Every cycle has two or three vertices and coefficient dimension zero; the
qualified census excludes scalar/mass insertions in this target only.

Every plan retains its differentiated legs, H/M roles, reference-edge
orientations, explicit vertex xi degree and ordinary BB propagator count.
All vertex momentum equations and closed-edge conditions are checked with
incoming vector r, antighost -r-q, ghost q and independent loop momentum k.
The raw UV and Taylor degree is 1 minus the external-jet sum, either zero
or one. No UV/IR identification or whole scaleless integral is used.

The local derivative placements, in fixed field order, are

    (partial V) a C, V (partial a) C, V a (partial C).

Their one total-derivative relation has coefficients (1,1,1). The two
independent coefficients in the representative without a differentiated
antighost are cV-ca and cC-ca. The r=0 and q=0 formal Taylor probes have
sampling rows (0,-1,1) and (1,-1,0). Together their rank is two and their
kernel is exactly the boundary relation. Either alone has rank one and
misses an explicit nonzero quotient witness. Thus a constant-vector probe
alone cannot determine the entire one-jet pole. Actual kernel evaluation
needs both probes and all four vector/derivative components: 32 Lorentz
slots per color/attachment unit, with a full four-dimensional loop.

These are probes of a separately defined UV/Taylor coefficient after UV/IR
separation, not exceptional-momentum physical amplitudes or permission to
declare a scaleless integral's UV part zero.

Some DG3 and FFG3 cycles have two ordinary BB propagators. Their width
degree can reach two before summation. The final affine-width cancellation
in the auxiliary/vector trace cannot be imported into this calculation.
Both reference widths and the explicit xi vertex must remain distinct.

Removing R loses two BaC profiles and no AaC profile; the latter control is
explicitly insensitive. Removing mixed BL/LB edges loses five AaC and
thirteen BaC profiles. Removing BB edges loses all fifteen AaC profiles and
102 BaC profiles; the two FR profiles survive. The finite complex Grassmann
Gaussian determinant also agrees with the closed-ghost supertrace sign,
whereas a naive boson trace fails. This finite check does not determine
actual R/F color coefficients or the graded Wick factors of these cycles.

The authenticated current functional remains 147266 words with SHA
c445c2e61f56b9df90cf904bf30b39458cdfec8e6d95e0588a3b6a8fb3ff0bf4.
Its new ABL/BBL node and actual H images contain no ghost/antighost pair,
so they cannot change the separate ghost Ward projection. The ordinary
g3 AaC/BaC poles remain unmeasured. The old partial ghost Ward gap is
preserved, not diagnosed as an anomaly. The selected auxiliary/vector H
closure and source-dependent theorem keep their original scopes.

The original primary failed its UV-degree assertion because the new
enumerator admitted external-jet sums above one. Its exact source and
capture remain. V2 prunes that out-of-domain case, without changing the
119 required profiles or any acceptance check. Primary V2 and replay V2
took 1.926056 and 1.926423 seconds after imports, with sampled private
peaks 58068992 and 57905152 bytes. The independent receipt owns its actual
runtime and any validator failures. All runs use the frozen 120-second,
8 GiB private-memory and 350 MiB minimum available-commit limits. No fresh
byte-identical replay pair is claimed.

Track B shows a useful completeness and algorithm-design reduction before
the expensive contraction. It also records an avoidable target-domain
pruning failure. All methods share the vertex catalogue, action, inherited
coefficient evidence, software and AI author; they do not independently
validate those premises or replace an expert physical review.

NEXT: derive the actual graded Hessian/Wick weights and the seven-family
universal UV kernels for both probes, retaining differentiated vector
vertices, ordinary BB and mixed propagation and R. Then contract the actual
color tensors. Do not use the desired Ward cancellation to supply unknown
coefficients. The 524 support plans are insufficient to supply those weights.
Freeze a bounded mathematical contract before that calculation; no repeat
of the whole functional expansion is justified.

No new pole, functional insertion, Slavnov theorem, scheme or normalization
is adopted here. Full source-free consistency, E5/A5, QAP, regulated
Jacobian/measure, finite/contact/Legendre products, IR and physical viability
remain unqualified. Preserve the nonzero Jacobian, 32 product maps, 128
source jets, 508 programs, quartet and scalar warnings, authority 34/39,
HB1/C5 block, flavor pause, C1_GS gap, closed routes and custody exit2/seven.
The old 72826 fixed-primitive count is historical, not a current residual.
No protected input, policy, authority, foundation, benchmark or remote action.
Education remains voluntary and nonblocking; Lean remains selective.
