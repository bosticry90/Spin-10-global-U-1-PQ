# Complete ghost-companion routed kernel domain V1

Baselinee75f6b3a1c44b6847bac124b33b625bbc48195b7. Question GKD1:does the
remaining ordinaryg3 A*a*C/B*a*C one-jet problem admit a bounded complete
two-momentum proper-cycle calculation,and which inputs must that calculation
retain? This is a method/support theorem,not a new loop pole or Ward fit.
The purpose is to prepare both complete ghost companions,not another
arbitrarily selected cancellation. Reuse qualified actual vertices/reference
and all15/104 outward profiles;do not rerun the2353-profile global inventory.

Freeze record,source,controllers,immutable graph/current/operator evidence
and policy before two sequential120-second-after-import/8GiB sampled-private
workers and a120-second/8GiB independent validator;minimum350MiB available
commit. Preserve failures/unfinished runs. No resource increase,truncation,
full functional expansion,parameter search or physical input change.

Enumerate every oriented typed proper cycle with these external letters
and totalg3 from the actual marginal source-free vertices and reference
edges. Primary grows forward;replay grows backward. Root at the unique
vertex carrying the single external vector to remove only cyclic starting
duplication;do not identify opposite orientations or turn counts into
Feynman factors. Keep all external derivative placements,internal H/M
roles,mixed orientations,ghost flow,explicit-vertex xi versus propagator
width labels. Validate every witness and exact agreement with119 qualified
profile descriptors. All admissible targets must have two or three vertices;
mass/scalar exclusions follow the actual coefficient-dimension-zero census.

Assign generic all-incoming external momenta r to vector,-r-q to antighost,
q to ghost and one independent loop k. Check every vertex and closed-edge
momentum equation;retain each derivative's actual leg and momentum.
Derive UV degree/Taylor degree and count ordinary B/B width-carrying edges
without assuming the auxiliary trace's final affine-width property.
The current pole remains unmeasured even if the routed plan is complete.

Prove that the three local one-jet placements have one total-derivative
relation and two independent quotient coefficients. Determine whether
r=0 and q=0 together identify both coefficients;give a nonzero ambiguity
witness for either probe alone. Retain all4 Lorentz components and ghost
ordering. A constant-vector shortcut alone must not be declared complete.
These are formal UV/Taylor probes after separating UV/IR,not full physical
exceptional-momentum amplitudes or a scaleless-zero prescription.

Check the finite Grassmann Gaussian's closed-ghost-cycle supertrace sign
against its determinant expansion,with a naive boson-trace negative control.
This does not fix actual color tensors,graded Wick multiplicities or a
new pole normalization. Cyclic support counts never supply those factors.
Controls remove mixed edges,quartic R,vector propagators or one kinematic
probe;disclose insensitivity rather than inventing a required contribution.

Authenticate updated Gamma147266/hashc445c2... and show its newly integrated
ABL/BBL node cannot contribute to the separate ghost Ward projection by
actual H field-type filtration. Retain the known ghost gap and unmeasured
AaC/BaC coefficients;do not fit them from the gap. Reassess whether the
next actual universal-kernel calculation has all specified prerequisites,
or identify its smallest missing mathematical input before execution.

Independent validation must use a different cyclic matching/enumeration or
explicit port checks,verify complete descriptor equality,routed momenta,
IBP/kinematic ranks,finite graded sign and controls. Shared action,relaxed
catalogue/old coefficient evidence,software and AI author limit independence.
No full E5/A5,Slavnov,QAP,finite/contact/Legendre/measure/IR or physical
viability claim. Keep38-source/selected-bilinear/auxiliary-H scopes,nonzero
Jacobian,32 products,128 source jets,508 programs,Legacy issues,authority
34/39,HB1/C5 block,flavor pause,C1_GS,scalar warnings,closed routes and
custodyexit2/seven. Old72826 fixed-primitive count is historical. No scheme,
benchmark,foundation,policy,authority or remote action. Education nonblocking.
