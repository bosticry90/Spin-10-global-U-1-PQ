# External-jet domain pruning correction V2

The first primary stopped before accepting any cycle table. Its new rooted
enumerator allowed external jet sums above1,then correctly failed the UV
degree guard for the one-jet target. Such over-differentiated configurations
are outside this target,as already enforced by the inherited full inventory.
V2 prunes external jet sums above1 before closing cycles and adds explicit
degree diagnostics. Preserve the failed source/capture;all119 profiles,
momentum/IBP/graded checks and120-second/8GiB bounds remain required.
