# Frozen H/M reduction and density coordinate conventions

On the actual projector domain introduce rectangular U and its transpose Ut:

    F=[[H,U],[-Ut,K+V]], X=[[-A,0],[-Ut,-K]],
    Y=X^T=[[A,U],[0,K]], W=diag(WH,WM).

A=ad_AH restrictedHH,H=ad_BH restrictedHH,K=ad_BH restrictedMM,
U=ad_BM restrictedHM,V=ad_BM restrictedMM. A,H,K,V are skew;Ut=U^T.
The qualified ten-word polynomial must imply,by ordered block products,

    P2_HM=[3 H U+(3 WM-2 WH-3) U K+3 WM U V
           +(2 WH-3 WM) A U]/4.

No commutation of H,K,U,V or A is allowed. Scalar WH/WM are identity
coefficients only within the indicated blocks. T_Lambda is symmetric and
H/M-offdiagonal. Its contracted density is therefore
-2 sum_(h,m) T_Lambda[m,h] P2_HM[h,m]. The replay uses the original full
45x45 ten-term trace and does not assume this compact formula.

The resulting density table is indexed by(auxiliary,unordered bg1,bg2),
background0..11=A and12..56=B. Both ordered cross terms from a quadratic
matrix product contribute when bg1 differs from bg2. For a repeated B,
the density is differentiated with factor2 to obtain the two-vector vertex;
the density coefficient itself receives no extra factor. Raw transformation
uses Lambda_phys=source^T Lambda_raw,V_phys=Cphys V_raw and A_phys=Cphys_H A_raw.
Inverse maps use anti,Cinv,Cinv_H. All fields here are commuting bosons.
The4 Lorentz copies multiply by eta_mu and have no jets. Component counts
refer to mathematical coefficient positions,not physical measurements.
