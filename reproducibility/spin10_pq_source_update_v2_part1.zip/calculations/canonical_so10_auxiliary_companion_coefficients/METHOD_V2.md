# Corrected block transpose and extraction method V2

The first primary failed its universal MH-transpose check before extracting
any color coefficient. The conjectured block expression in METHOD.md used
the wrong offdiagonal sign in X^T. The actual X has lower-left -U^T,so

    F=[[H,U],[-Ut,K+V]], X=[[-A,0],[-Ut,-K]],
    Y=X^T=[[A,-U],[0,K]], W=diag(WH,WM).

Preserve the rejected method/source/capture. The unchanged measured trace
therefore gives

    P2_HM=[3(1+2 WH) H U+(3+3 WM-4 WH) U K
           +3(2+WM) U V-(6+3 WM+2 WH) A U]/4.

This is a correction to the proposed algebraic simplification,not a change
of the action,trace coefficient or any input. V2 must prove both the HM
formula and MH transpose,then compare with the original full ten-word trace.
The replay still uses the original ten words;all charts,complete domains,
reality,independent validation and180-second/8GiB bounds remain mandatory.

No acceptance condition presumes that an actual repeated-B component is
nonzero. The factor2 density-to-vertex identity is checked on every actual
coefficient and a generic repeated-field unit. If the actual table has no
repeated-B coefficient,the associated actual omission control is reported
insensitive;it is not a reason to manufacture a nonzero component.
