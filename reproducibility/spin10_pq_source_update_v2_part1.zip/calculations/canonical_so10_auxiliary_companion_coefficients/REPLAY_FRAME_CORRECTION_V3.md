# Classical shared-frame dependency declaration V3

ReplayV2 completed full trace extraction but was correctly stopped by the
JSON-read guard:the inherited replay chart reads its plane_to_C3 matrix
from frozen_a10_bv_master/primary.json. This is immutable classical master
data,not the new primary answer or a Ward target. Its hash is already bound
in the frozen inputs but its read was omitted from the replay allowlist.
Preserve the failed capture/source. ReplayV3 declares that one classical
read explicitly and keeps every mathematical gate and180-second/8GiB limit.
Reuse completed primaryV2;do not grant access to its new answer.
