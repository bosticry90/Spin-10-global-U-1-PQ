# Separate-family width control correction V4

The first mathematical validator matched the complete ten-word physical
tensor and all74385 slots/zero complements. It then stopped at the G4
omission control because its contraction helper allowed at most one W.
The complete sum is affine in W,but the separately qualified G4 family has
W F F W. V4 evaluates every ordered W factor at its actual color index;
it does not remove or weaken the complete-family control. Preserve the
failed validator/capture and reuse both native outputs. All coordinate,
reality,Bose and resource requirements remain unchanged.
