# Complete coefficient extraction of the actual ordinaryg3 auxiliary companions

Prospective until paired primaryV2/replayV3 outputs/captures,independent
validation receipt and committed-byte checks qualify. Baseline8cf467a11309974b8d4c0ff6937aed66a9f969ed.

The actual trace pole from V227 has been expanded in physical and canonical
coordinates. Both ABL and BBL are included;no coefficient was fitted from
the Ward relation. Gamma insertion and the dependent Ward comparison have
not been performed by this extraction.

| Physical color class | Possible density positions | Nonzero | Zero complement |
| --- | ---: | ---: | ---: |
| A_H B Lambda | 24300 | 282 | 24018 |
| B B Lambda,unordered vectors | 46575 | 944 | 45631 |
| A_H A_H Lambda | 3510 | 0 | 3510 |

These74385 positions are mathematical coefficient slots,not independent
loop integrals or physical observations. All45 auxiliary,12 A and45 totalB
directions enter the complete domain. Physical Lambda_H coefficients vanish.
The complete canonical temporal table has456 nonzero positions;its four
eta_mu Lorentz copies contain1824 canonical words. Cross-Lorentz positions
are zero by the inherited qualified local no-jet tensor theorem.

Primary uses the proved corrected H/M block identity in METHOD_V2.md;
replay multiplies the original complete45x45 ten-word trace polynomial.
The first primary rejected the proposed METHOD.md simplification through
its MH-transpose check:the offdiagonal sign in X^T was wrong. The action
and measured trace were unchanged. The corrected ordered formula is

    P2_HM=[3(1+2 WH) H U+(3+3 WM-4 WH) U K
           +3(2+WM) U V-(6+3 WM+2 WH) A U]/4.

T_Lambda is symmetric/offdiagonal,so the density contracts this block with
-2 T_Lambda[m,h]. No background blocks commute. The rejected method/source/
capture remain immutable. This control caught a false algebraic reduction
before any coefficient was accepted.

The physical-to-raw pullback uses source^T for the auxiliary and Cphys for
both vectors,including the explicitly extended A_H chart. Inverse anti/
Cinv maps recover every physical coefficient. Physical coefficients are
real;raw coordinates use their qualified antilinear conjugation rather than
an unjustified elementwise-real requirement. Wrong auxiliary chart and
omitted A chart change the actual output. Full frame matrices are retained.

Both ordered background contributions are combined into density coefficients.
The corresponding two-vector vertex table retains the factor2 for a repeated
field. The actual physical table contains no repeated-B coefficient;omitting
that factor is therefore insensitive there. A generic repeated-field unit
checks the factor2 rule,and every actual vertex is verified. Canonical raw
coordinates are checked separately. No nonzero repeated-B value is invented.

ReplayV2 completed its color trace but the read guard stopped an undeclared
classical frame dependency. The inherited chart reads frozen BV-master
primary plane_to_C3 data even on replay. Its hash was already frozen;replayV3
explicitly declares that shared classical read and never reads the new
primary answer. Preserve both failed executions/captures. PrimaryV2 is reused.
No acceptance requirement or physical input changed. Primary took25.3166
seconds;replay and validation captures own their actual timings and peaks.
Sequential run/validator limits180seconds after imports,8GiB sampled private,
minimum350MiB available commit. No byte-identical replay pair is claimed.

Independent validation must reconstruct all45 actual adjoint and U tensors,
all57 N/D matrices,and contract all ten original trace words directly with
ordinary-SymPy arithmetic. It must compare all74385 slots/zero complements,
the ordered vertices,staged raw/physical maps,antilinear reality,all1824
canonical positions and complete-family/chart/width controls. The trace's
loop/profile/UV proof is authenticated,not rerun. Shared action,trace,charts,
software and AI author limit independence;this is not expert endorsement.

NEXT:use these independently qualified measured nodes in one bounded
canonical integration and complete selected g3 Lambda/B/one-jet local-H
test. Include unchanged ordinaryg2 mixing and both affine A_H/B_H
predecessors,parameter jets and explicit total-derivative currents. Prove
predecessor exhaustiveness at that target. Do not fill values from conditional
Ward completions;calculate the assembled result after qualification.
Other ordinary ghost AaC/BaC companions remain a separate unmeasured sector.

The known functional remains146162/hashf0b650d6a343a98e105c7aee8894fca84a70dad17d64620b9ee3181488fceee1.
Its previous partial Ward gaps/fixed72826 primitive residual remain unchanged.
No full source-free or simultaneous restoration claim. Keep38-source/selected
bilinear scopes,nonzero Jacobian,32 products,128 source jets,508 programs,
QC.A1-A5/QAP/contact/Legendre/measure/IR/Legacy obligations,authority34/39,
HB1/C5 block,flavor pause,C1_GS gap,quartet/scalar warnings,closed routes,
custodyexit2/seven. No input,scheme,benchmark,foundation,policy,authority or
remote action. Education voluntary/nonblocking;Lean selective.
