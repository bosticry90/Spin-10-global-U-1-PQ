"""Measured trace extraction; no Ward prediction or functional integration."""
from pathlib import Path
from collections import defaultdict
from functools import lru_cache
from itertools import product,combinations_with_replacement
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
o=load('qualified_constant_matrix_ring',OUT.parent/'canonical_so10_constant_background_operators/operators.py');s=o.s;read=o.read;digest=o.digest;ex=o.ex;num=o.num;ZERO=o.ZERO;ONE=o.ONE
from a10_e5_measured_functional_v3 import frames
def add(*As):return o.add(*As)
def scale(A,z):return o.scale(A,z)
def trans(A):return {(j,i,v):z for (i,j,v),z in A.items()}
def block(A,rows,cols):return {key:z for key,z in A.items() if key[0] in rows and key[1] in cols}
def pmul(A,B):
    rows=defaultdict(list);out={}
    for (k,j,v),z in B.items():rows[k].append((j,v,z))
    for (i,k,u),z in A.items():
        for j,v,c in rows[k]:
            key=(i,j,tuple(sorted(u+v)));assert len(key[2])<=2,'UNSUPPORTED_POLYNOMIAL_DEGREE';o.put(out,key,z*c)
    return out
def conjugate(z):return ex.Coefficient({key:v*(-1 if key[2]&8 else 1) for key,v in z.cells.items()})
@lru_cache(None)
def text(cells):return str(ex.D.to_sympy(ex.Coefficient(dict(cells))))
def txt(z):return text(tuple(sorted(z.cells.items())))
def pack(A):return [[a,b,c,txt(z)] for (a,b,c),z in sorted(A.items())]
def packmatrix(A):return [[i,j,txt(z)] for (i,j),z in sorted(A.items())]
def auth(folder,name):
    p=OUT.parent/folder/name;rec=read(p.parent/'validation_receipt.json');assert rec['execution_state']=='COMPLETED' and rec['input_sha256'][str(p)]==digest(p);return read(p)
def traceinput(role):
    p=OUT.parent/'canonical_so10_auxiliary_companion_trace';rec=read(p/'validation_v2_receipt.json');f=p/(role+'_v4_result.json');assert rec['execution_state']=='COMPLETED' and rec['input_sha256'][str(f)]==digest(f);return read(f)
def proof():
    A,H,K,U,Ut,V=s.symbols('A H K U Ut V',commutative=False);WH,WM=ex.widthH,ex.widthM;F=s.Matrix([[H,U],[-Ut,K+V]]);X=s.Matrix([[-A,0],[-Ut,-K]]);Y=s.Matrix([[A,U],[0,K]]);W=s.diag(WH,WM)
    P=(s.Rational(3,4)*(F*F+F*W*F+F*X-W*F*Y+X*F*W-X*Y-Y*F)+s.Rational(1,4)*(W*Y*Y-X*W*Y+X*X*W)).applyfunc(s.expand);want=(3*H*U+(3*WM-2*WH-3)*U*K+3*WM*U*V+(2*WH-3*WM)*A*U)/4;assert s.expand(P[0,1]-want)==0
    def transpose_nc(z):
        out=0
        for term in s.Add.make_args(s.expand(z)):
            c,ns=term.args_cnc();sg=1;rev=[]
            for n in reversed(ns):
                if n in [A,H,K,V]:sg=-sg;rev.append(n)
                elif n==U:rev.append(Ut)
                elif n==Ut:rev.append(U)
                elif n.is_Pow and n.base in [A,H,K,V]:sg*=(-1)**int(n.exp);rev.extend([n.base]*int(n.exp))
                else:raise AssertionError(('UNKNOWN_TRANSPOSE_FACTOR',n))
            out+=s.Mul(*c)*sg*s.Mul(*rev)
        return s.expand(out)
    assert s.expand(P[1,0]-transpose_nc(P[0,1]))==0
    return {'universal_ordered_HM_block_identity':True,'universal_MH_transpose_and_factor2_trace':True,'no_commutation_of_rectangular_background_blocks':True}
def operators(role):
    d=auth('canonical_so10_constant_background_operators',role+'_result.json');F={};X={}
    for name,dest in [('D1',F),('N1',X)]:
        for bg,rows in d[name]:
            for i,j,z in rows:o.put(dest,(i,j,(bg,)),num(s.sympify(z)))
    assert all(v[0]>=12 for i,j,v in F);Y=trans(X);W={(i,i,()):num(ex.widthH if i<12 else ex.widthM) for i in range(45)};H=set(range(12));M=set(range(12,45));U=block(F,H,M);V=add(block(F,M,M),block(X,M,M));A=scale({key:z for key,z in X.items() if key[2][0]<12},-1);K=scale(block(X,M,M),-1);HH=block(F,H,H)
    assert not any(key[2][0]>=12 for key in A) and not any(key[2][0]>=24 for key in HH) and not any(key[2][0]<24 for key in U) and not any(key[2][0]<24 for key in V)
    return F,X,Y,W,A,HH,K,U,V
def coefficients(role,T,trace):
    F,X,Y,W,A,H,K,U,V=operators(role)
    if role=='primary':
        P=add(scale(pmul(H,U),num(s.Rational(3,4))),scale(pmul(U,K),num((3*ex.widthM-2*ex.widthH-3)/4)),scale(pmul(U,V),num(3*ex.widthM/4)),scale(pmul(A,U),num((2*ex.widthH-3*ex.widthM)/4)));factor=-2
    else:
        vals={'F':F,'X':X,'Y':Y,'W':W};P={};I={(i,i,()):ONE for i in range(45)}
        for word,z in trace['P2_angular_Lorentz_inverse']:
            Z=I
            for n in word:Z=pmul(Z,vals[n])
            P=add(P,scale(Z,num(s.sympify(z))))
        factor=-1
    Ts=defaultdict(list)
    for a,rows in enumerate(T):
        for i,j,z in rows:Ts[j,i].append((a,num(s.sympify(z))))
    out={}
    for (i,j,v),z in P.items():
        assert len(v)==2
        for a,c in Ts.get((i,j),[]):o.put(out,(a,*v),factor*z*c)
    assert out and not any(i<12 or c<12 for (i,b,c) in out) and not any(z!=conjugate(z) for z in out.values())
    return out
def maps(role):
    w,sub,back,source,anti,Cinv,Cphys=frames(role);assert o.s.expand(1)==1
    assert all(s.expand(z)==0 for z in source.T*anti-s.eye(45)) and all(s.expand(z)==0 for z in Cphys*Cinv-s.eye(45));assert not any(Cphys[:12,12:]) and not any(Cphys[12:,:12])
    conv=lambda A:{(i,j):num(s.expand(z)) for (i,j),z in A.todok().items() if s.expand(z)}
    bg=s.diag(Cphys[:12,:12],Cphys);bgback=s.diag(Cinv[:12,:12],Cinv);lam=source.T;lamback=anti;starL=anti.conjugate()*source.T;starBg=s.diag((Cinv.conjugate()*Cphys)[:12,:12],Cinv.conjugate()*Cphys)
    return list(map(conv,[lam,bg,lamback,bgback,starL,starBg]))
def transform(P,L,V):
    ll=defaultdict(list);vv=defaultdict(list);out={}
    for (i,j),z in L.items():ll[i].append((j,z))
    for (i,j),z in V.items():vv[i].append((j,z))
    for (a,b,c),z in P.items():
        for i,x in ll[a]:
            for j,y in vv[b]:
                for k,v in vv[c]:o.put(out,(i,*sorted([j,k])),z*x*y*v)
    return out
def vertex(P):
    out={}
    for (a,b,c),z in P.items():
        o.put(out,(a,b,c),2*z if b==c else z)
        if b!=c:o.put(out,(a,c,b),z)
    return out
def rawrows(P):
    out=[];g=s.Symbol('g10');eta=s.Symbol('eta_H',real=True);xi=s.Symbol('xi',real=True)
    for (a,b,c),z in sorted(P.items()):
        ln=('b' if a<12 else 'L')+str(a)
        for mu in range(4):
            ns=[ln,('A'+str(b) if b<12 else 'B'+str(b-12))+'_'+str(mu),('A'+str(c) if c<12 else 'B'+str(c-12))+'_'+str(mu)];v=ex.D.to_sympy(z).subs({ex.widthH:eta,ex.widthM:xi});out.append({'word':sorted(ns),'coefficient':str(s.expand(g**3*(1 if mu==0 else -1)*v))})
    return sorted(out,key=lambda d:d['word'])
def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('COMPANION_COEFFICIENT_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('COMPANION_COEFFICIENT_UNDECLARED_PEER_OR_WARD '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' universal_block_reduction_and_actual_color_extraction',flush=True);pr=proof();trace=traceinput(role);T=read(Path(prep['classical_U_by_role'][role]))['physical_U_tensors'];P=coefficients(role,T,trace);assert not any(z for (a,b,c),z in P.items() if b<12 and c<12);counts={label:sum((b<12<=c if label=='AB' else b>=12 if label=='BB' else c<12) for a,b,c in P) for label in ['AB','BB','AA']};assert counts['AB'] and counts['BB'] and counts['AA']==0
    print('STAGE '+role+' complete_raw_charts_primitive_dual_roundtrips_and_antilinear_reality',flush=True);L,V,Li,Vi,SL,SV=maps(role);raw=transform(P,L,V);back=transform(raw,Li,Vi);assert back==P;assert transform({key:conjugate(z) for key,z in raw.items()},SL,SV)==raw
    VP=vertex(P);VR=vertex(raw);assert all(VP[a,b,c]==(2*z if b==c else z) and VP[a,c,b]==(2*z if b==c else z) for (a,b,c),z in P.items());assert any(b==c for a,b,c in P),'IDENTICAL_B_CONTROL_NOT_EXERCISED';badvertex={key:z for key,z in P.items() if key[1]==key[2]};assert any(VP[key]!=z for key,z in badvertex.items())
    wrongL=transform(P,Li,V);IdA={(i,i):ONE for i in range(12)};badV={key:z for key,z in V.items() if key[0]>=12};badV.update(IdA);wrongA=transform(P,L,badV);controls={'wrong_Lambda_primal_vs_inverse_chart_sensitive':wrongL!=raw,'omit_A_physical_chart_sensitive':wrongA!=raw,'omit_repeated_B_vertex_factor2_sensitive':True,'double_density_changes_coefficients':scale(P,2)!=P,'drop_width_terms_changes_coefficients':any(a or b for z in P.values() for a,b,mask in z.cells),'physical_AA_zero_not_inferred_from_fixture':True};assert all(controls.values())
    rows=rawrows(raw);assert len(rows)==4*len(raw) and not any('__' in n for row in rows for n in row['word']);fixture=trace['noncommuting_actual_fixture'];ids={fixture['fixture_A_H'],12+fixture['fixture_B'][0],12+fixture['fixture_B'][1]};fx={}
    for (a,b,c),z in P.items():
        if b in ids and c in ids:o.put(fx,a,z)
    assert [[a,txt(z)] for a,z in sorted(fx.items())]==fixture['all45_auxiliary_trace_positions']
    result={'schema':'ACTUAL_AUXILIARY_COMPANION_CANONICAL_COEFFICIENTS_V1','route':role,'scientific_disposition':'EXTRACTED_COMPLETE_SELECTED_ACTUAL_ORDINARY_G3_ABL_BBL_COEFFICIENTS','universal_block_proof':pr,'physical_density_coefficients':pack(P),'canonical_density_coefficients':pack(raw),'physical_ordered_two_vector_vertex':pack(VP),'canonical_ordered_two_vector_vertex':pack(VR),'actual_g3_ABL_BBL_canonical_node':rows,'color_domain':{'AB':24300,'BB':46575,'AA':3510},'physical_nonzero_counts':counts,'physical_zero_complement':{k:n-counts[k] for k,n in [('AB',24300),('BB',46575),('AA',3510)]},'canonical_temporal_positions':len(raw),'canonical_four_Lorentz_positions':len(rows),'all4_eta_copies_cross_Lorentz_zero':True,'all_real_physical_and_antilinear_raw_reality_checked':True,'frame_matrices':{k:packmatrix(A) for k,A in zip(['lambda_inverse','vector_inverse_including_A','lambda_forward','vector_forward_including_A','lambda_raw_conjugation','vector_raw_conjugation_including_A'],[L,V,Li,Vi,SL,SV])},'physical_raw_inverse_density_roundtrip':True,'actual_fixture_reconstructed_from_full_coefficients':True,'controls':controls,'Gamma_Ward_primitive_conditional_prediction_or_peer_read':False,'canonical_Gamma_integration_or_dependent_Ward_comparison_performed':False,'full_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
