# Canonical extraction of measured ordinaryg3 auxiliary companions V1

Baseline8cf467a11309974b8d4c0ff6937aed66a9f969ed. Question ACC1:expand the
qualified actual trace density into complete physical and canonical ABL/BBL
coefficient tables,with correct Bose density factors,charts and reality.
This is extraction of a measured pole,not a new loop or Ward completion.
Qualify these inputs before any dependent Ward comparison or Gamma insertion.

Freeze code,record,method,controllers,qualified trace/actual N,D,U,all frame
matrices,policy and resource bounds before two sequential180-second-after-
import/8GiB sampled-private workers and a180-second/8GiB independent
validator;minimum350MiB available commit. Preserve exact failed/unfinished
versions. No old loop,whole-functional variation or508-Euler replay.

Use all45 auxiliary colors,12 externalA and45 totalB physical colors.
All57 background variables commute;two B fields use unordered density
coefficients,not an ordered vertex with a hidden identical-particle factor.
Cover45*12*45=24300 AB,45*1035=46575 BB and45*78=3510 AA color positions,
including every exact zero. AA must vanish from the actual projectors,not
from sample rays. Lambda_H has zero two-quantum Hessian. All4 equal-axis
Lorentz copies carry eta_mu;cross-axis coefficients are zero by the qualified
local no-jet Lorentz theorem. No finite,massive,physical IR or extra target.

Primary proves the H/M2x2 block reduction in METHOD.md and contracts its
HM block. Replay evaluates all ten original ordered terms using complete
45-color sparse polynomial matrices. Retain unrestricted rational/radical/
width arithmetic;reject floats and unsupported degrees. The matrix identity
is universal on the actual projector domain;one fixture is not the proof.
Do not fit coefficients to a Ward identity or a conditional completion.

Pull physicalLambda via anti^-1=source^T and both physical vectors via
Cphys. Extend the dynamical-field chart explicitly to physical A_H using
the H block of Cphys;do not silently leave rawA unchanged. Independently
push raw coefficients back using anti/Cinv. Derive canonical field
conjugation from the same real physical frame;raw coefficients need not
be elementwise real. Check all frame inverses,zero cross-blocks,physical
reality,canonical antilinear reality,grading and all4 copies. Wrong primal/
dual or A-chart mutations must be tested,with insensitivity disclosed.

Distinct route comparison and independent ordinary-SymPy direct color
contractions/coordinate transforms are required. Check every coefficient,
zero complement and derivative vertex obtained from the density,including
the repeated-B factor2. Verify a basis-spanning reconstruction of the
original trace polynomial,not selected decimal points. Controls omit a
complete family,alter a Bose factor,mis-map A or Lambda and lose a width
term where sensitive. No new scheme/input/foundational assumption.

The qualified trace's complete15-profile and UV/Gaussian proof is inherited
and authenticated,not freshly replayed. Current Gamma146162/hashf0b650...
and its Ward gaps remain unchanged during extraction. No simultaneous
source-free or full restoration result follows. Keep38-source/selected
bilinear scopes,nonzero Jacobian,32 product maps,128 source jets,508 programs,
QC.A1-A5/QAP/contact/Legendre/measure/IR and quartet obligations. Authority
34/39,HB1/C5 blocked,flavor paused,C1_GS gap,scalar warnings,closed routes,
custodyexit2/seven preserved. Shared action,trace,charts,software and AI
author limit independence. Education voluntary/nonblocking;Lean selective.
