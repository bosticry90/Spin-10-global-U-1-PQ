# Complete selected ub12 ghost/auxiliary ordered symbol

Prospective until completed independent receipt and committed-byte checks.
Complete rooted support selects five role profiles/two families, C1-X bubble
and C0-F-X triangle. All actual mixed edges and other bare candidates retained
in the support test. All eight ordered placements evaluated from actual action
coefficients; no Ward fitting or divergent-trace cyclicity.

The bubble and triangle reduced coefficients are equal and nonzero, giving
20 nonzero epsilon12 C_j Lambda_k g10 xi^2 coefficients out of2025 positions.
Triangle numerator is exactly P times its reduced coefficient at all Lorentz
slots. Example total48 sqrt(2) i g10 xi^2/25 for C13 L13 epsilon12/P^2.
Independent validation must check the entire coefficient domain, predecessor
census, Euler/Fourier kernel signs, matrix paths, momentum polynomials and
family omission/sign controls before qualification.

This refutes a zero-insertion assumption for this selected ordered-log symbol.
Canonical pole normalization, Wick/subtraction bridge and integration remain
pending. It is not an anomaly classification or full quantum restoration.
No functional/source/input/scheme/benchmark/policy/authority change. Keep seven
quantum flags false, authority34/39, prior qualified source/unbroken theorems,
HB1/C5 block, flavor pause, quartet/scalar warnings and custody2/seven.
Shared action/catalogue/insertion/reference/conventions/software/AI author.

Next: qualify the normalization bridge against an actually measured companion
or direct determinant convention before using this insertion in a complete
selected antighost comparison. Preserve power-sensitive first-reference terms
separately from this homogeneous logarithmic target. No full Gamma expansion.
