# ub12 ghost/auxiliary logarithmic-support test V1

Base b1d3db09de23d6654d14e59ce7f558a91da8e75e. Live AGENTS delegation.
Question BCL.1: evaluate the complete ordered Born-symbol contribution to
epsilon12 C_j Lambda_k at g10^1, no external jets, coefficient dimension zero,
all45 ghosts/all45 auxiliaries (2025 positions). No Ward fitting. This is a
small complete target, not a full antighost/Slavnov/quantum-restoration theorem.

Freeze all source/controller/input bytes and own-role JSON reads before two
sequential native routes, each120s afterimports/8GiB sampled private/minimum
350MiB available commit. Independent ordinary-polynomial validation has same
limits. Preserve all failures. Native insertion-slot/left-partial Hessians and
forward/backward closed-matrix paths; independent color/Grassmann contraction.

First enumerate rooted insertion cycles from the actual824-row C12, retained
reference edges and qualified complete bare-vertex catalogue. External target
epsilon,C,L, coupling1, coefficient dimension0 excludes dimensionful vertices,
reference mass differences and scalar-mass expansions. External field count
allows at most two ordinary cubic vertices or one quartic. No source partner,
new scalar parameter, heat background A (target A degree0), EOM or eliminated
field. If the complete census contains an unimplemented family, stop incomplete.

Compute every ordered insertion placement with determinant weights
(-1)^(n+1)/n before common i/2 normalization. No divergent trace cyclicity.
Use actual g0 xi ghost/auxiliary X and g1 one-derivative ghost/vector F action
coefficients, and retain/check other candidate vertices in the census. Form
the actual Fourier Hessians at zero external jets with (-i p) for h derivatives
and (+i p) for k derivatives, preserving all odd reorderings. Reference inverse
must be the actual one; no chosen gauge widths. Excluded matrix blocks require
the complete support proof, not absence from a selected numerical configuration.

Keep full momentum numerator until exact Lorentz coefficient comparison.
Bubble has P^-2; triangle P^-3 with degree2 numerator. Establish whether its
numerator equals P times a local coefficient at all10 symmetric Lorentz slots.
The resulting ordered homogeneous q^-4 symbol is a selected UV-log precursor;
no canonical pole is adopted without the normalization/Wick/subtraction bridge.
If the complete symbol is zero, classify only this selected retained Born
target as zero. Nonzero is not automatically an anomaly or full physical pole.
Use existing radial shell/DR residue bridge only for this dimension-zero log.

Independent validation covers all2025 coefficient slots including zeros,
complete predecessors/ordered placements, actual momenta and Grassmann signs,
sensitive family omissions or sign/normalization changes (disclose insensitive
controls). Reuse even/odd Gaussian normalization evidence, not just a few colors.
Shared action, catalogue, conventions, software and AI author remain limits.

No full Gamma materialization,210-profile compiler, functional integration,
new physical input/scheme/benchmark, scientific authority change or external
action. Seven quantum flags remain false; source38 theorem, authority34/39,
HB1/C5 block, flavor pause, quartet/quantum warnings/custody2-seven preserved.
