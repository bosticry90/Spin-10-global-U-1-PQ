# Selected complete ordered logarithmic symbol

The target is epsilon12 C_j Lambda_k, coefficient dimension zero, g10^1,
no external jets and no sources/background A. The literal C12 insertion
contains 40 g0 epsilon-C-L entries, 576 g1 epsilon-C-C-a entries with a
ghost/antighost internal pair, and208 with two internal ghosts and external
antighost. The last group cannot supply this target: external legs are never
contracted back into the same proper-cycle matrix program.

The complete qualified bare-vertex catalogue, actual insertion roles and
reference edges give five ordered role profiles in two families:

* one C1 insertion plus the g0 xi ghost/auxiliary X Hessian;
* one C0 insertion plus F (g1 one-derivative ghost/vector) and X.

The C0 auxiliary leg uses the actual mixed vector/auxiliary propagator.
The U auxiliary/vector candidate is included in the census and fails actual
H/M edge closure; it is not deleted by an interaction-label assumption.
Dimensionful/orbit/reference mass differences cannot contribute to a
coefficient-dimension-zero target. Pure scalars, background heat vertices
(positive A degree), higher coupling vertices and all other field sectors
are excluded by the complete target/support calculation. At most two
ordinary cubic vertices fit the external field count. This is coverage
relative to the qualified bare catalogue and retained ordered Born program,
not a separate proof of QAP or a full sourcefree diagram inventory.

Evaluate both bubble placements, weight -1/2 each, and all six triangle
placements, weight +1/3 each. These are the derivatives of the retained
(-1)^(n+1)/n Born coefficients, before common i/2 and loop normalization.
No cyclic rearrangement of a divergent trace is needed.

Each internal reference denominator is P=p0^2-|p|^2. The bubble numerator
has degree zero, denominator P^2. The triangle has degree two, denominator
P^3. Its full numerator is proved equal to P times a local coefficient,
including all ten symmetric Lorentz slots, not one selected momentum.
The independent route integrates h derivatives by parts through its left
Euler operator, retains the resulting k derivatives and Fourier transforms
them. The native routes instead Fourier transform h and k derivative slots
directly. All external differentiated fields are excluded by the declared
zero-jet target, not by equations of motion.

The complete symbol has20 nonzero coefficients out of2025 C/L positions.
The weighted bubble and triangle are equal and nonzero; they add. For example
the coefficient of C13 L13 epsilon12 / P^2 is

    48 sqrt(2) i g10 xi^2 /25.

This is a homogeneous ordered logarithmic symbol precursor. A Wick rotation
and the inherited common i/2, radial residue and source/field normalization
must be related to the canonical pole convention before integrating any new
node. Do not silently call the coefficient a normalized quantum pole or
anomaly. It is a computed insertion, not a coefficient fitted to make a Ward
relation vanish. General insertion/contact subtraction, measure, physical IR,
full sourcefree Slavnov and E5/A5 remain outside the result.
