"""Complete ub12 C Lambda target: rooted support then ordered Born symbols."""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import permutations
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);a=importlib.util.module_from_spec(z);z.loader.exec_module(a);return a
a=load('actual_broken_operator_helpers',OUT.parent/'canonical_so10_broken_antighost_operator/operator_v2.py');m=a.m;b=a.b;s=a.s;ex=a.ex;l=a.l;read=a.read;digest=a.digest;PKG=a.PKG
ZERO=(0,0,0,0)
def ty(n):
 if n=='zz_da12':return 'e'
 if n.startswith('C'):return 'C'
 if n.startswith(('ub','bar')):return 'a'
 if n.startswith(('L','b')):return 'L'
 if n.startswith('B'):return 'B'
 if n.startswith('A'):return 'A'
 return 'x'
def role(n):
 if n.startswith('ub'):return 'aM'
 if n.startswith('bar'):return 'aH'
 if n.startswith('b'):return 'LH'
 if n.startswith('L'):return 'LM'
 if n.startswith('C'):return 'CH' if int(n[1:])<12 else 'CM'
 if n.startswith('B'):return 'BH' if int(n[1:].split('_')[0])<12 else 'BM'
 raise AssertionError(n)
def put(P,key,z):m.put(P,key,z)
def add(*Ps):
 Q={}
 for P in Ps:
  for key,z in P.items():put(Q,key,z)
 return Q
def scale(P,z):return {key:m.cscale(c,z) for key,c in P.items() if z}
def mul(P,Q):
 T={}
 for (gp,w,pp),z in P.items():
  for (gq,v,pq),c in Q.items():
   word,sg=m.word_product(w,v)
   if sg:put(T,(gp+gq,word,tuple(x+y for x,y in zip(pp,pq))),m.cscale(m.cmul(z,c),sg))
 return T
def rows(P):return [{'g':gp,'word':[m.serialize_token(t) for t in w],'p_powers':list(pp),'coefficient':str(ex.D.to_sympy(z))} for (gp,w,pp),z in sorted(P.items())]
def census(Crows,vertices,edges):
 insert=set()
 for r in Crows:
  internal=[role(n[5:]) for n in r['word'] if n.startswith(('zz_h_','zz_k_'))];outside=tuple(role(n) for n in r['word'] if not n.startswith('zz_'));assert len(internal)==2
  if all(t[0] in 'CL' for t in outside):insert.add((r['g'],internal[0],internal[1],outside))
 opts=[]
 for tag,v in vertices.items():
  if v['cd'] or v['g']>1:continue
  for ports in v['ports']:
   for i,j in permutations(range(len(ports)),2):
    p,q=ports[i],ports[j]
    if p[0].startswith('A') or q[0].startswith('A'):continue
    out=tuple(sorted(ports[k][0] for k in range(len(ports)) if k not in [i,j]))
    if all(t[0] in 'CL' for t in out):opts.append((tag,p[0],q[0],out))
 opts=sorted(set(opts));profiles=set();ordered=set()
 for gp,start,end,outside in sorted(insert):
  states=[(start,end,outside,(),gp)]
  for count in range(3):
   nxt=[]
   for start,end,ext,tags,g in states:
    if (end,start) in edges and g==1 and sorted(t[0] for t in ext)==['C','L']:
     profiles.add((gp,tuple(sorted(vertices[t]['base'] for t in tags))));ordered.add((gp,tags,tuple(ext)))
    if count==2:continue
    for tag,p,q,extra in opts:
     full=ext+extra;types=[t[0] for t in full]
     if (end,p) in edges and types.count('C')<=1 and types.count('L')<=1 and len(full)<=2 and g+vertices[tag]['g']<=1:nxt.append((start,q,full,tags+(tag,),g+vertices[tag]['g']))
   states=list(set(nxt))
 return sorted(profiles),sorted(ordered),len(insert)
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();rte=sys.argv[1];prep=read(OUT/'preparation.json');assert rte in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
 allow={str(Path(p).resolve()) for p in prep['read_json_by_role'][rte]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('LOG_CL_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);m.setup();stages=[]
 def stage(n,fn):
  print('STAGE '+rte+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
 def new(n,p):m.index[n]=len(m.names);m.names.append(n);m.par.append(p);return m.index[n]
 for i in range(45):new('zz_da'+str(i).zfill(2),1)
 fields=sorted(m.fields);H={n:m.elementary(new('zz_h_'+m.names[n],m.par[n])) for n in fields};K={n:m.elementary(new('zz_k_'+m.names[n],m.par[n])) for n in fields}
 def act(P,I):return m.action(P,I,'primary',True) if rte=='primary' else m.action(P,I,'replay')
 prior=OUT.parent/'canonical_so10_broken_antighost_operator';receipt=read(prior/'validation_v2_receipt.json');p=prior/(rte+'_v2_result.json');assert receipt['execution_state']=='COMPLETED' and receipt['input_sha256'][str(p)]==digest(p);prev=read(p);Crows=[r for r in prev['complete_mixed_Hessian_insertion'] if 'zz_da12' in r['word']];assert len(Crows)==824 and prev['eps12_classical_breaking_positions']==0
 inv=b.auth('canonical_so10_sourcefree_cycle_inventory',rte+'_v2_result.json');edges={tuple(e) for e in inv['actual_reference_edges']};families,profiles,itypes=stage('complete_rooted_insertion_support',lambda:census(Crows,inv['actual_sourcefree_vertices'],edges));assert families==[(0,('F','X')),(1,('X',))],('UNIMPLEMENTED_COMPLETE_TARGET_FAMILY',families)
 e2,eb=b.sealed('frozen_a10_e2_transport',rte);GF=m.decode(e2['gauge_fixing_density']);F={};X={}
 for key,z in GF.items():
  gp,w=key;ts=sorted(ty(m.names[n]) for n,j in w);jets=sum(len(j) for n,j in w)
  if gp==0 and ts==['C','L','a'] and jets==0:X[key]=z
  if gp==1 and ts==['B','C','a'] and jets==1:F[key]=z
 assert F and X
 def hessian(P):return act(act(P,H),K)
 FH=stage('actual_full_F_Fourier_Hessian',lambda:hessian(F));XH=stage('actual_full_X_Hessian',lambda:hessian(X));CP=a.h.from_result(Crows);ref,rb=b.sealed('frozen_a10_e5_full_hessian',rte);names=ref['retained_reference']['field_order'];idx={n:i for i,n in enumerate(names)};ps=s.symbols('p0_ref0 p0_ref1 p0_ref2 p0_ref3');P=ps[0]**2-sum(z*z for z in ps[1:]);ploc={str(p):p for p in ps}|{'eta_H':m.etaH,'xi':m.xi}
 def mat(poly,bodytypes):
  A={}
  for (gp,word),z in poly.items():
   hp=[(i,n,j) for i,(n,j) in enumerate(word) if m.names[n].startswith('zz_h_')];kp=[(i,n,j) for i,(n,j) in enumerate(word) if m.names[n].startswith('zz_k_')];assert len(hp)==len(kp)==1;hi,hn,hj=hp[0];ki,kn,kj=kp[0];rest=tuple(t for i,t in enumerate(word) if i not in [hi,ki])
   if any(j for n,j in rest) or sorted(ty(m.names[n]) for n,j in rest)!=sorted(bodytypes):continue
   hname=m.names[hn][5:];kname=m.names[kn][5:];sg=(-1)**(m.par[hn]*sum(m.par[n] for n,j in word[:hi])+m.par[kn]*sum(m.par[n] for n,j in word[ki+1:]));pp=tuple((hj+kj).count(mu) for mu in range(4));zz=m.cmul(z,ex.coefficient(sg*(-s.I)**len(hj)*s.I**len(kj)));put(A.setdefault((idx[hname],idx[kname]),{}),(gp,rest,pp),zz)
  return A
 C0=mat({key:z for key,z in CP.items() if key[0]==0},['e']);C1=mat({key:z for key,z in CP.items() if key[0]==1},['C','e']);FM=mat(FH,['C']);XM=mat(XH,['L']);assert C0 and C1 and FM and XM
 # Only these supported words occur. Every retained Green entry has one P
 # denominator; zero/BB/scalar edges may not be replaced by a convenient form.
 G={}
 for i,j,text in ref['retained_reference']['reference_Green_raw_C3']['entries']:
  ts=sorted([ty(names[i]),ty(names[j])])
  if ts not in [['C','a'],['B','L']]:continue
  zz=s.cancel(P*s.sympify(text,locals=ploc));poly=s.Poly(zz,*ps)
  Q={}
  for pp,z in poly.terms():
   for gp,c in m.coefficient_terms(str(z)):put(Q,(gp,(),tuple(pp)),c)
  G[i,j]=Q
 def leftG(A):
  by=defaultdict(list)
  for (j,k),Q in A.items():by[j].append((k,Q))
  out={}
  for (i,j),gp in G.items():
   for k,Q in by[j]:out[i,k]=add(out.get((i,k),{}),mul(gp,Q))
  return {key:Q for key,Q in out.items() if Q}
 mats={'C0':leftG(C0),'C1':leftG(C1),'F':leftG(FM),'X':leftG(XM)}
 def tr(seq):
  if rte=='primary':
   W=mats[seq[0]]
   for label in seq[1:]:
    V=mats[label];by=defaultdict(list)
    for (j,k),Q in V.items():by[j].append((k,Q))
    out={}
    for (i,j),Q in W.items():
     for k,R in by[j]:out[i,k]=add(out.get((i,k),{}),mul(Q,R))
    W={key:Q for key,Q in out.items() if Q}
   return add(*(scale(Q,(-1)**m.par[m.index[names[i]]]) for (i,j),Q in W.items() if i==j))
  # Independent backward path closure; multiplication remains in original order.
  by=[]
  for label in seq:
   tab=defaultdict(list)
   for (i,j),Q in mats[label].items():tab[j].append((i,Q))
   by.append(tab)
  result={}
  for (first,last),Q in mats[seq[-1]].items():
   paths=[(first,Q)]
   for pos in range(len(seq)-2,-1,-1):paths=[(i,mul(R,T)) for j,T in paths for i,R in by[pos].get(j,[])]
   for i,T in paths:
    if i==last:result=add(result,scale(T,(-1)**m.par[m.index[names[i]]]))
  return result
 words=[('C1','X'),('X','C1')]+list(permutations(('C0','F','X')));parts={}
 for seq in words:parts['.'.join(seq)]=stage('ordered_'+'_'.join(seq),lambda seq=seq:tr(seq))
 bubble=add(*(scale(parts['.'.join(seq)],s.Rational(-1,2)) for seq in words[:2]));triangle=add(*(scale(parts['.'.join(seq)],s.Rational(1,3)) for seq in words[2:]));assert all(sum(pp)==0 for gp,w,pp in bubble) and all(sum(pp)==2 for gp,w,pp in triangle)
 # Match all degree2 Lorentz slots, including the six off-diagonal ones.
 T={};basis=[(2,0,0,0),(0,2,0,0),(0,0,2,0),(0,0,0,2)];keys={(gp,w) for gp,w,pp in triangle}
 for gp,w in keys:
  c=triangle.get((gp,w,basis[0]),ex.coefficient(s.S.Zero));put(T,(gp,w,ZERO),c)
  for pp in [tuple(int(i==mu)+int(i==nu) for i in range(4)) for mu in range(4) for nu in range(mu,4)]:
   sign=1 if pp==basis[0] else -1 if pp in basis[1:] else 0;assert triangle.get((gp,w,pp),ex.coefficient(s.S.Zero))==m.cscale(c,sign),('NONSCALAR_LORENTZ_NUMERATOR',gp,w,pp)
 total=add(bubble,T);assert all(gp==1 and sorted(ty(m.names[n]) for n,j in w)==['C','L','e'] and pp==ZERO for gp,w,pp in total)
 controls={'omit_bubble_changes_total':T!=total,'omit_triangle_changes_total':bubble!=total,'reverse_triangle_sign_changes_total':add(bubble,scale(T,-1))!=total,'omit_auxiliary_vector_candidate_checked_by_full_support':not any('U' in tags for gp,tags in families)}
 result={'schema':'BROKEN_UB12_LOG_C_LAMBDA_BORN_SYMBOL_V1','route':rte,'scientific_disposition':'SELECTED_COMPLETE_ORDERED_LOG_SYMBOL_ZERO' if not total else 'SELECTED_COMPLETE_ORDERED_LOG_SYMBOL_NONZERO_NORMALIZATION_BRIDGE_PENDING','complete_rooted_families':families,'rooted_role_profiles':profiles,'actual_insertion_type_options':itypes,'bare_F_density':l.rows(F),'bare_X_density':l.rows(X),'all_ordered_numerators':{k:rows(Q) for k,Q in parts.items()},'weighted_bubble_Pminus2':rows(bubble),'weighted_triangle_Pminus3':rows(triangle),'triangle_divided_by_exact_P':rows(T),'complete_Pminus2_symbol':rows(total),'all10_Lorentz_coefficients_match_P':True,'all2025_ghost_auxiliary_targets_included':True,'no_auxiliary_scalar_heat_or_Green_assumption_silently_dropped':True,'controls':controls,'new_canonical_pole_or_functional_or_source_integration':False,'full_QAP_contact_measure_Slavnov_E5_A5_or_authority_change':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
