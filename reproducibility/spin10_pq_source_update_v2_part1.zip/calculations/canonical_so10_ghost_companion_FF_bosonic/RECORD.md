# Complete actual FFG3 and FFU triangles V1

Baseline587a15286e7c63f8737007b482c6eaa3a590b7c4. Question FFB1: what
are the complete ordinaryg3 one-jet FFG3/FFU contributions to both
AaC/BaC ghost companions? These are the last two unmeasured families
of the qualified119-profile domain. FFG3 has38BaC profiles/240cycles;
FFU has4AaC/11BaC profiles and16/62cycles. Support counts are not weights.

Freeze record,code/controllers,policy,complete routed domain,qualified F
derivative/IBP and principal inverse bridges,actual adjoints/YM action,
literal U and full N1 evidence before computation. Two sequential120-
second-after-import/8GiB private workers,350MiB minimum available commit;
one120-second/8GiB independent validator. Preserve failures/complete
captures;no silent resource increase,truncation or whole-functional run.
No Gamma,primitive,desired ghost Ward coefficient or peer answer as input.

Derive the six-order finite graded Gaussian triangle factor and compare
proper connected Wick contractions and a finite boson/ghost Schur formula.
Apply it to a correction of the bosonic inverse,not the different FFF
ghost-inverse insertion. Actual outer F vertices retain F_a/F_c and their
four boundary currents. A_H is external;B is the actual total vector.
The two quantum bosons are BB/BB for G3,or BB/mixed for U. Preserve
G_BL=+i*k/k^2,G_LB=-i*k/k^2,G_LL=0 and ordered W_i/W_j.

Use incoming external V(r),a(-r-q),C(q). The left F has B(k+r),C(q-k),
the right F has B(-k),a(k-q),and the middle has B(-k-r),B(k),V(r),with
one B replaced by Lambda for the two U orientations. Check every sum.
Extract all four left/right derivative choices,three middle blocks
G3/U_BL/U_LB,and both probes/all16 Lorentz positions:384 unit positions.
The outer a/c choice has two external jets and is absent at one-jet order
only. Do not infer a full amplitude or an abstract color zero from it.

Use exact numerator first jets and denominator Taylor for primary;replay
uses explicit Lorentz-matrix contractions and normalized Feynman-simplex
first moments. For L^a K^b M with L=(k+r)^2,M=(k-q)^2,the loop shift is
k=ell-x_L*r+x_M*q. Retain a,b=1,2 as actually present. Keep the full4D
loop and both independent derivative coefficients. Prove any double-
longitudinal Yang-Mills first-jet zero before using it;do not assume
quadratic width terms cancel. Separate UV annulus/auxiliary IR mass;
no whole scaleless,finite-amplitude or physical IR inference.

All45 quantum colors/all57 external backgrounds must be contracted.
G3 uses F_v[i,j] for external B only;U_BL uses actual N[V,i,j],U_LB
uses N[V,j,i]. Retain HH/HM/MH/MM unweighted pieces until applying
the ordered width factors. Primary exact-field indexed products;replay
ordinary-SymPy sparse ordered products. Reconstruct literal all4 F/U
copies and match every actual U/N1 coefficient,including Bose factors.
Compare both complete115425-position derivative tensors and zero
complements,reality and all12 H-covariance identities. Do not insert
any family into Gamma in this increment.

Controls remove a finite order,an orientation/family,derivative choices,
propagator components or H/M sectors,and alter signs/angular metric.
Disclose structural zeros/insensitive controls. Independent validation
must reconstruct Gaussian/YM normalization,both-probe units,all color
pieces and complete coefficients using different contractions. Shared
action,charts/reference,IBP/catalogue,software/AI author limit independence.

Outcome:actual complete FFG3/FFU poles or zeros,input/normalization
discrepancy,or bounded inconclusiveness. Passing all seven families is
input coverage,not an automatic Ward or source-free Slavnov theorem.
Next combine actual poles,qualify canonical extraction/exact-once/inverse
addition and test the complete selected ghost relation without fitting.
Keep Gamma147266/hashc445c2...,38-source/auxiliary-H/bilinear scopes,
nonzeroJacobian,32products,128sourcejets,508programs,QAP/contact/Legendre/
measure/IR/Legacy gaps,34/39,HB1/C5block,flavorpause,C1_GS,quartet/scalar
warnings,closedroutes,custodyexit2/seven. FullE5/A5/physicalviability
unqualified. No input,scheme,benchmark,foundation,policy,authority or
remoteaction;educationnonblocking,Leanselective. No branch/worktree.
