# The final FFG3 and FFU ghost-triangle inputs are explicit

Prospective until paired native captures/results,independent receipt and
committed-byte checks qualify. Baseline587a15286e7c63f8737007b482c6eaa3a590b7c4.

The complete ordinaryg3 one-jet FFG3 and FFU contributions have been
calculated in the declared AaC/BaC domain. FFG3 covers38BaC profiles and
240directed cycles. FFU covers4AaC/11BaC profiles and16/62cycles. These
are the last two unmeasured families of that bounded ghost-companion
inventory,not the entire source-free quantum theory.

The physical density convention is

    hbar*g10^3/(32*pi^2*epsilon_UV) *
      [ (partial_mu V_v^mu) a_j R[v,j,l] C_l
        + V_v^mu a_j Q[v,j,l] partial_mu C_l ],

modulo the qualified four F boundary currents. V=0..11 is A_H,12..56 is B.

| Complete piece | Nonzero R | Nonzero Q | Zero complement per tensor |
| --- | ---: | ---: | ---: |
| FFG3 | 2160 | 2160 | 113265 |
| FFU,left mixed B-Lambda orientation | 2184 | 2184 | 113241 |
| FFU,right mixed Lambda-B orientation | 1938 | 1938 | 113487 |
| Complete FFU sum | 2384 | 2384 | 113041 |

Each full tensor has115425positions. Equal support counts do not imply
equal coefficients,and the orientation counts are not added arithmetically.
No partial orientation is substituted for FFU. All384 two-probe/Lorentz
unit positions are retained,including explicit one-jet structural zeros.

Let i,j label the left/right quantum color lines. Their independently
retained reference widths are W_i,W_j. The two-letter label denotes the
ghost differentiated at the left external-a and right external-C vertices.
The measured universal units are

| Block | Derivatives | r coefficient | q coefficient |
| --- | --- | ---: | ---: |
| G3 | aa | 3W_j/2 | 3W_j/2 |
| G3 | ca | -3W_j/2 | -3(W_i+W_j)/2 |
| G3 | cc | 0 | 3W_i/2 |
| U_BL | aa | W_j/2 | W_j/2 |
| U_BL | ca | -W_j/2 | -3/2 |
| U_BL | cc | 0 | (W_j+3)/2 |
| U_LB | aa | -(W_i+3)/2 | -(W_i+3)/2 |
| U_LB | ca | -(W_i-3)/2 | 3/2 |
| U_LB | cc | 0 | -W_i/2 |

The ac choice has two derivatives on external ghosts and is zero in this
one-jet projection for all three blocks. Its empty color-base tables mean
those irrelevant unweighted contractions were not calculated;they are not
abstract color zeros or statements about the full amplitude.

The G3 result was derived allowing two ordinary BB propagators and width-
quadratic terms. The exact Yang-Mills double-longitudinal contraction is
proportional to k_rho*r^2-r_rho*(k.r),which starts at second external order.
It therefore eliminates the double-longitudinal first jet. The actual G3
units become affine in the ordered widths as a result,not an assumption.
This does not establish width independence. U_BL depends only on its BB
line's W_j,and U_LB only on W_i;the other line is a mixed propagator.

All six finite graded Born orders give i*G1*G2/(6*P) each. Their sum agrees
with connected Wick contractions and a finite boson/ghost Schur complement.
The principal inverse retains G_BL=+i*k/k^2,G_LB=-i*k/k^2 and G_LL=0.
The independent validator must check the complete5x5 one-color symbol
and every three-vector vertex component from the unchanged -F^2/4 action.
No divergent functional-trace cyclicity or quantum-equivalence shortcut
is used to obtain this normalization.

Primary uses exact numerator first jets and both denominator derivatives.
Replay uses explicit Lorentz-matrix contraction and the normalized simplex
moments for L^a K^b M,with L=(k+r)^2 and M=(k-q)^2. The full four-dimensional
loop remains. The two r=0/q=0 probes determine separate R and Q coefficients.
Positive UV-annulus/auxiliary-mass treatment separates the UV pole from IR;
no whole scaleless zero,finite amplitude or physical IR limit is claimed.

Actual G3 color entries are F_v[i,j] for external B only. Actual U_BL uses
N[V,i,j];U_LB uses N[V,j,i]. The full740 mixed-U coefficients and all four
literal Lorentz copies agree with the independently qualified N1. Both
F_a/F_c and their qualified derivative-current bridge are retained. All45
quantum colors and57 external backgrounds are contracted. HH/HM/MH/MM
pieces remain separate until their ordered width factors are applied.

Primary exact-field indexed products and replay ordinary-SymPy sparse
products agree on every base and final coefficient. Independent validation
must reconstruct them in quantum-vector index space,check both complete
family tensors and zero complements,reality and all12 H-covariance
identities,and test omitted orientations,sectors and angular/sign factors.
Structural zeros and insensitive controls remain explicitly classified.

Primary completed in41.007008seconds after imports;replay in37.852421seconds.
Captures/receipt own actual peaks,validator runtime and any failures. Bounds
remain120seconds after imports,8GiB sampled private memory and350MiB minimum
available commit. No fresh byte-identical replay pair is claimed.

Track B demonstrates reuse of the first-jet reduction before another full
momentum expansion could exhaust resources. The distinct Lorentz/color
routes corroborate the actual coefficients. They share the action,reference,
charts,IBP/catalogue,software and AI author,and validation shares exact-field
arithmetic with primary. Their agreement does not independently validate
those physical assumptions or replace expert assessment.

NEXT:reconcile and sum all seven actually measured family poles with the
correct common normalization and width/explicit-xi distinction. Qualify
the complete canonical coefficient extraction,then exact-once integration/
inverse addition and the complete selected ghost local-H relation. A cheap
complete physical/frame check may precede full-functional reconstruction;
no unknown coefficient may be fitted from the desired cancellation. Input
coverage alone is not the Ward theorem,and a partial remainder is not an
anomaly. Wider source-free coverage/QAP/measure/contact obligations remain.

No node is inserted into Gamma here. Current147266/hashc445c2...,38-source,
auxiliary-H/bilinear scopes,nonzeroJacobian,32products,128sourcejets,508programs,
QAP/contact/Legendre/measure/IR/Legacy gaps,34/39,HB1/C5block,flavorpause,C1_GS,
quartet/scalar warnings,closedroutes and custodyexit2/seven are preserved.
Full ghost/source-freeSlavnov,E5/A5 and physicalviability remain unqualified.
No input,scheme,benchmark,foundation,policy,authority or remoteaction.
Educationvoluntary/nonblocking;Leanselective.
