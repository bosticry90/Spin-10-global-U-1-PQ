"""Complete FFG3/FFU triangles with exact first jets and actual ordered colors."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product,permutations
from functools import lru_cache
import importlib.util,json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,canonical
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
f=load('qualified_DF_field',Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/ghost-companion-DF-v1-2026-10-17/verify.py'))
old=load('qualified_FFF_classical_parser',OUT.parent/'canonical_so10_ghost_companion_FFF/pole_v2.py')
E=(1,-1,-1,-1);k=list(s.symbols('ffb_k0:4',real=True));K,Wi,Wj=s.symbols('ffb_K ffb_Wi ffb_Wj',nonzero=True);WH,WM=s.symbols('reference_width_H reference_width_M',real=True)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def num(z):return s.sympify(z,locals={str(v):v for v in [K,Wi,Wj,WH,WM,*k]})
def clean(z):return s.expand(z)
def matrix(rows):return s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in rows})
def field2(z):
    out={}
    for (a,b),c in s.Poly(clean(num(z)),WH,WM).terms():
        assert a+b<=2
        for (i,j,m),v in f.field(str(c)):assert i==j==0;out[a,b,m]=v
    return tuple(sorted((key,v) for key,v in out.items() if v))
def finite_triangle(role):
    w=alphabet();w.fields={'bL':(1,0,0),'bHL':(1,0,0),'bHR':(1,0,0),'bR':(1,0,0),'cc':(1,1,1),'aa':(1,-1,1)};w.grades=w.fields;w.pairs=[];w.external={};w.p={n:t[2] for n,t in w.fields.items()}
    for n,t in [('ae',(1,-1,1)),('ce',(1,1,1)),('Ve',(1,0,0))]:register(w,n,t)
    v=w.var;Vs=[w.mul(v('ae'),v('bL'),v('cc')),w.mul(v('bHL'),v('Ve'),v('bHR')),w.mul(v('aa'),v('bR'),v('ce'))];target=w.mul(v('ae'),v('Ve'),v('ce'));word,sg=next(iter(target.items()));g1,g2,P=s.symbols('finite_G1 finite_G2 finite_P',nonzero=True);green={('bL','bHL'):g1,('bHL','bL'):g1,('bHR','bR'):g2,('bR','bHR'):g2,('cc','aa'):1/P,('aa','cc'):-1/P};orders=[]
    if role=='primary':
        names=list(w.fields);par=[w.p[n] for n in names];G={(i,j):{():z} for i,n in enumerate(names) for j,m in enumerate(names) if (z:=green.get((n,m),0))};Hs=[]
        for V in Vs:
            H=Fourier_vertex(V,w,'primary',k,k,{});Hs.append({(i,j):cell for i,row in enumerate(H) for j,cell in enumerate(row) if cell})
        for perm in permutations(range(3)):
            A=G
            for n,i in enumerate(perm):A=multiply(A,Hs[i],w);A=multiply(A,G,w) if n<2 else A
            orders.append(s.cancel(s.I*trace(A,w,par).get(word,0)/(6*sg)))
    else:
        ext={'ae','ce','Ve'}
        def pair(inside):
            if not inside:return s.S.One
            a=inside[0];out=0
            for i,b in enumerate(inside[1:],1):
                G=green.get((a,b),0)
                if G:out+=(-1)**(w.p[a]*sum(w.p[n] for n in inside[1:i]))*s.I*G*pair(inside[1:i]+inside[i+1:])
            return out
        for perm in permutations(Vs):
            z=0
            for a,ca in perm[0].items():
                for b,cb in perm[1].items():
                    for c,cc in perm[2].items():
                        full=a+b+c;inside=[n for n,j in full if n not in ext];outside=[n for n,j in full if n in ext];cross=(-1)**sum(w.p[n]*w.p[m] for i,(n,j) in enumerate(full) if n not in ext for m,jj in full[i+1:] if m in ext);sign=w.mul(*(v(n) for n in outside)).get(word,0)/sg;z+=ca*cb*cc*cross*sign*pair(inside)
            orders.append(s.cancel(-s.I*s.I**3*z/6))
    total=s.cancel(sum(orders));assert s.simplify(total-s.I*g1*g2/P)==0
    V,eps=s.symbols('finite_V finite_eps');H=s.Matrix([[1/g1,V-eps/P],[V-eps/P,1/g2]]);schur=s.diff(s.I*s.log(H.det())/2,eps,V).subs({eps:0,V:0});assert s.simplify(total-schur)==0
    return {'six_order_coefficients':list(map(str,orders)),'full_coefficient':str(total),'Schur_result':str(s.simplify(schur)),'no_functional_trace_cyclicity_assumed':True}
def ja(A,B):return (A[0]+B[0],A[1]+B[1])
def js(A,z):return (z*A[0],z*A[1])
def jm(A,B):
    if A==(0,0) or B==(0,0):return (s.S.Zero,s.S.Zero)
    return (A[0]*B[0],A[1]*B[0]+A[0]*B[1])
def jdot(A,B):
    out=(s.S.Zero,s.S.Zero)
    for i in range(4):out=ja(out,js(jm(A[i],B[i]),E[i]))
    return out
def vecadd(A,B,z=1):return [ja(a,js(b,z)) for a,b in zip(A,B)]
def zeros():return [(s.S.Zero,s.S.Zero)]*4
@lru_cache(None)
def jets(tag,rho,nu,probe,role):
    d=[(s.S.Zero,s.Integer(i==nu)) for i in range(4)];kk=[(v,s.S.Zero) for v in k];rv=d if probe=='r' else zeros();qv=d if probe=='q' else zeros();pL=vecadd(kk,rv)
    U=vecadd(jsvec(rv,-1),jsvec(qv,-1)) if tag[0]=='a' else vecadd(qv,kk,-1);V=vecadd(kk,qv,-1) if tag[1]=='a' else qv
    X={1:jsvec(U,-1),2:[js(jm(jdot(U,pL),z),1-Wi) for z in pL]};Y={1:jsvec(V,-1),2:[js(jm(jdot(V,kk),z),1-Wj) for z in kk]};out={}
    for a,b in product([1,2],repeat=2):
        if role=='primary':N=ja(ja(jm(ja(js(kk[rho],2),rv[rho]),jdot(X[a],Y[b])),js(jm(jdot(X[a],vecadd(kk,rv,-1)),Y[b][rho]),-1)),js(jm(X[a][rho],jdot(Y[b],vecadd(kk,rv,2))),-1));N=js(N,E[rho])
        else:
            N=(s.S.Zero,s.S.Zero)
            for alpha,beta in product(range(4),repeat=2):
                H=ja(ja(js(ja(js(kk[rho],2),rv[rho]),E[rho]*E[alpha]*int(alpha==beta)),js(vecadd(kk,rv,-1)[alpha],-E[alpha]*E[beta]*int(beta==rho))),js(vecadd(kk,rv,2)[beta],-E[alpha]*int(alpha==rho)*E[beta]));N=ja(N,jm(jm(X[a][alpha],H),Y[b][beta]))
        out['G3',a,b]=(clean(N[0]),clean(N[1]))
    for b in [1,2]:N=js(jm(jdot(U,pL),Y[b][rho]),E[rho]);out['UBL',1,b]=(clean(N[0]),clean(N[1]))
    for a in [1,2]:N=js(jm(X[a][rho],jdot(V,kk)),-E[rho]);out['ULB',a,1]=(clean(N[0]),clean(N[1]))
    return out
def jsvec(A,z):return [js(a,z) for a in A]
def average(P,wrong=False):
    if P==0:return s.S.Zero
    result=0
    for term in s.Add.make_args(s.expand(P)):
        powers=term.as_powers_dict();ns=[int(powers.get(z,0)) for z in k];rad=int(powers.get(K,0));assert sum(ns)+2*rad==-4,(term,ns,rad)
        if any(n%2 for n in ns):continue
        w=s.S.One
        for j in range(sum(ns)//2):w/=4+2*j
        for i,n in enumerate(ns):w*=s.factorial2(n-1) if n else 1;w*=1 if wrong else E[i]**(n//2)
        result+=term/s.prod(v**n for v,n in zip(k,ns))/K**rad*w
    return clean(2*result)
def residues(tag,rho,nu,probe,role,wrong=False):
    out=defaultdict(lambda:s.S.Zero);longzero=True
    for (family,a,b),(N,dN) in jets(tag,rho,nu,probe,role).items():
        n=a+b+1
        if role=='primary':P=dN/K**n+N*(-2*a if probe=='r' else 2)*E[nu]*k[nu]/K**(n+1)
        else:P=(dN+s.Rational(-a if probe=='r' else 1,n)*s.diff(N,k[nu]))/K**n
        z=average(clean(P),wrong)/E[rho];out[family]+=z
        if family=='G3' and a==b==2:longzero&=z==0
    return {key:s.factor(z) for key,z in out.items()},longzero
def proof():
    x,y=s.symbols('ffb_x ffb_y',real=True)
    for a,b in product([1,2],repeat=2):
        weight=s.factorial(a+b)/s.factorial(a-1)/s.factorial(b-1)*x**(a-1)*y**(b-1);integrate=lambda P:s.integrate(s.integrate(P,(y,0,1-x)),(x,0,1));assert integrate(weight)==1 and integrate(-x*weight)==s.Rational(-a,a+b+1) and integrate((1-x-y)*weight)==s.Rational(1,a+b+1)
    r=s.symbols('route_r0:4');q=s.symbols('route_q0:4');L=[a+b for a,b in zip(k,r)];ci=[a-b for a,b in zip(q,k)];ai=[-v for v in ci];ae=[-a-b for a,b in zip(r,q)];assert all(clean(sum(v[i] for v in row))==0 for row in [[ae,L,ci],[ai,[-z for z in k],q],[[-z for z in L],k,r]] for i in range(4))
    eps,m=s.symbols('uv_epsilon positive_IR_mass_squared',positive=True);assert s.limit(eps*s.gamma(eps)*m**(-eps),eps,0)==1
    return {'all_actual_vertex_and_internal_momentum_equations':True,'all_a_b_Dirichlet_normalizations_and_ordered_first_moments':True,'positive_IR_mass_UV_residue_separated':True}
def units(role):
    result={family:{} for family in ['G3','UBL','ULB']};controls={};longzero=True
    for left,right in product('ac',repeat=2):
        tag=left+right;rows={family:{probe:[] for probe in ['r','q']} for family in result};wrong={family:False for family in result}
        for rho,probe in product(range(4),['r','q']):
            for nu in range(4):
                Z,LZ=residues(tag,rho,nu,probe,role);longzero&=LZ
                for family in result:rows[family][probe].append([rho,nu,str(Z[family])])
            bad,_=residues(tag,rho,rho,probe,'primary',True)
            for family in result:wrong[family]|=clean(bad[family]-num(rows[family][probe][-4+rho][2]))!=0
        for family in result:
            for probe in ['r','q']:
                base=num(rows[family][probe][0][2]);assert all(clean(num(z)-base*int(rho==nu))==0 for rho,nu,z in rows[family][probe])
            result[family][tag]={'r':rows[family]['r'][0][2],'q':rows[family]['q'][0][2],'all32_probe_components':rows[family],'two_external_jet_zero':tag=='ac'}
            if tag=='ac':assert num(result[family][tag]['r'])==num(result[family][tag]['q'])==0
            controls[family+tag]={'wrong_angular_metric_changes_a_component':bool(wrong[family]),'nonzero_onejet_unit':bool(num(result[family][tag]['r']) or num(result[family][tag]['q']))}
    assert longzero
    return result,controls,{'G3_double_longitudinal_first_jet_zero_all_components':bool(longzero),'quadratic_width_not_assumed':True}
def literal_N(rows):
    copies=[]
    for mu in range(4):
        N=defaultdict(lambda:s.S.Zero)
        for row in rows:
            word=row['word'];ls=[n for n in word if n.startswith('Lp')];vs=[n for n in word if n.startswith(('Ap','Bp'))]
            if len(ls)!=1 or len(vs)!=2 or not all(n.endswith('_'+str(mu)) for n in vs):continue
            for j,B in enumerate(vs):
                if not B.startswith('Bp'):continue
                V=vs[1-j];N[int(V[2:].split('_')[0])+(12 if V.startswith('Bp') else 0),int(ls[0][2:]),int(B[2:].split('_')[0])]+=num(row['coefficient'])/E[mu]
        copies.append({key:clean(z) for key,z in N.items() if clean(z)!=0})
    assert all(v==copies[0] for v in copies);return copies[0]
def operators(F,N,adj):
    return {'G3':{(12+v,i,j):num(z) for v,A in enumerate(adj) for i,j,z in A},'UBL':dict(N),'ULB':{(v,j,i):z for (v,i,j),z in N.items()}}
def bases(F,C,U,role):
    mats={kind:{b:s.SparseMatrix(45,45,{(i,j):z for (v,i,j),z in F[kind].items() if v==b+12}) for b in range(45)} for kind in 'ac'}
    elements={kind:{b:list(A.todok().items()) for b,A in values.items()} for kind,values in mats.items()};cache={};result={family:{tag:{reg:{} for reg in ['HH','HM','MH','MM']} for tag in U[family]} for family in U}
    def prod(tag,i,j):
        key=(tag,i,j)
        if key in cache:return cache[key]
        if role=='primary':
            right=defaultdict(list)
            for (l,c),z in elements[tag[1]][j]:right[l].append((c,f.field(str(z))))
            P={}
            for (a,l),x in elements[tag[0]][i]:
                xx=f.field(str(x))
                for c,y in right[l]:f.accumulate(P,(a,c),f.mul(xx,y))
        else:P={(a,c):f.field(str(clean(z))) for (a,c),z in (mats[tag[0]][i]*mats[tag[1]][j]).todok().items() if clean(z)!=0}
        cache[key]=P;return P
    for family in result:
        for tag in result[family]:
            if num(U[family][tag]['r'])==num(U[family][tag]['q'])==0:continue
            for (v,i,j),z in C[family].items():
                region=('H' if i<12 else 'M')+('H' if j<12 else 'M');out=result[family][tag][region];zz=f.field(str(z))
                for (a,c),x in prod(tag,i,j).items():f.accumulate(out,(v,a,c),f.mul(zz,x))
    return result
def unpack(z):return sum(s.Rational(c.numerator,c.denominator)*WH**a*WM**b*s.sqrt(f.rad[m]) for (a,b,m),c in z)
def pack(P):return [[v,a,C,str(clean(unpack(z)))] for (v,a,C),z in sorted(P.items()) if z]
def combined(B,U):
    result={family:{probe:{} for probe in ['r','q']} for family in B}
    for family,tags in B.items():
        for tag,regions in tags.items():
            for region,P in regions.items():
                for probe in ['r','q']:
                    z=num(U[family][tag][probe]).subs({Wi:WH if region[0]=='H' else WM,Wj:WH if region[1]=='H' else WM});weight=field2(str(z))
                    for key,x in P.items():f.accumulate(result[family][probe],key,f.mul(weight,x))
    return result
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('FF_BOSONIC_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('FF_BOSONIC_PEER_OR_UNDECLARED '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' complete_graded_normalization_first_jet_and384_components',flush=True);G=finite_triangle(role);P=proof();U,controls,longzero=units(role);print('UNITS '+json.dumps({family:{tag:{key:z[key] for key in ['r','q']} for tag,z in ts.items()} for family,ts in U.items()},sort_keys=True),flush=True)
    ex=read(Path(prep['pure_classical_export']));F=old.literal_F(ex['vertices']['F_ghost_and_auxiliary']);N=literal_N(ex['vertices']['F_ghost_and_auxiliary']);cp=ROOT/'calculations/canonical_so10_gauge_source_g2_color'/(role+'_result.json');cr=read(cp.parent/'validation_receipt.json');assert cr['input_sha256'][str(cp)]==digest(cp);col=read(cp)
    for kind,label in [('a','Fa_tensors'),('c','Fc_tensors')]:assert {(v-12,i,j):z for (v,i,j),z in F[kind].items() if v>=12}=={(b,i,j):num(z) for b,A in enumerate(col[label]) for i,j,z in A}
    op=ROOT/'calculations/canonical_so10_constant_background_operators'/(role+'_result.json');rr=read(op.parent/'validation_receipt.json');assert rr['input_sha256'][str(op)]==digest(op);actual=read(op);assert N=={(v,i,j):num(z) for v,A in actual['N1'] for i,j,z in A};assert len(N)==740
    print('STAGE '+role+' all_actual_ordered_color_products_and_full_tensors',flush=True);C=operators(F,N,ex['all45_physical_adjoint_matrices']);B=bases(F,C,U,role);Z=combined(B,U);UU={probe:{} for probe in ['r','q']}
    for family in ['UBL','ULB']:
        for probe in UU:
            for key,z in Z[family][probe].items():f.accumulate(UU[probe],key,z)
    tensors={family:{probe:pack(P) for probe,P in probes.items()} for family,probes in Z.items()};tensors['U_sum']={probe:pack(P) for probe,P in UU.items()};encoded={family:{tag:{reg:pack(P) for reg,P in regions.items()} for tag,regions in tags.items()} for family,tags in B.items()};assert all(not num(z).has(s.Float) and s.simplify(num(z)-s.conjugate(num(z)))==0 for fam in tensors.values() for rows in fam.values() for v,a,C,z in rows)
    dp=ROOT/'calculations/canonical_so10_ghost_companion_kernel_domain'/(role+'_v2_result.json');rr=read(dp.parent/'validation_receipt.json');assert rr['input_sha256'][str(dp)]==digest(dp);dom=read(dp);coverage={}
    for target in ['A','B']:
        for family,tags in [('G3',['F','F','G3']),('U',['F','F','U'])]:
            found=[row for row in dom['targets'][target]['family_summary'] if row['family']==tags];coverage[target+family]=found[0] if found else {'cycles':0,'profiles':0}
    assert coverage['BG3']['profiles']==38 and coverage['BG3']['cycles']==240 and coverage['AU']['cycles']==16 and coverage['BU']['cycles']==62 and coverage['AG3']['cycles']==0
    result={'schema':'ACTUAL_COMPLETE_FFG3_FFU_GHOST_TRIANGLES_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_FFG3_FFU_FAMILIES_ONLY','finite_Gaussian':G,'first_jet_proof':P,'units':U,'unit_controls':controls,'double_longitudinal':longzero,'all_ordered_HH_HM_MH_MM_bases':encoded,'physical_tensors':tensors,'full_positions_per_derivative_placement':115425,'zero_complements':{family:{probe:115425-len(rows) for probe,rows in probes.items()} for family,probes in tensors.items()},'all384_probe_components_retained':True,'all4_literal_F_U_and740_N1_entries_checked':True,'zero_unit_color_bases_not_computed':{family:[tag for tag,z in tags.items() if num(z['r'])==num(z['q'])==0] for family,tags in U.items()},'coverage':coverage,'normalization':'hbar*g10^3/(32*pi^2*epsilon_UV) [ (partial V) a R C + V a Q partial C ]; v=0..11 A_H,12..56 B; UBL uses N[v,i,j],ULB N[v,j,i]; modulo qualified F IBP currents; no extra ghost1/2','actual_Gamma_primitive_desired_Ward_or_peer_read':False,'functional_or_authority_changed':False,'full_ghost_Ward_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
