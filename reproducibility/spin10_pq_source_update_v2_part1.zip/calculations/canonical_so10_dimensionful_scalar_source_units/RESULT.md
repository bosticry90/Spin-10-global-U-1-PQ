# Smaller source group: loop normalization established

Prospective qualification requires the completed validation receipt. The
g10^3*xi intrinsic Jx*C group has two candidate families. Its universal units
are now derived with graded Born traces and direct proper Wick contractions:

| Abstract ordered unit | Factor in hbar/(32*pi^2*epsilon_UV) |
|---|---:|
| (-J*c*chi) with (a*Cext*chi) bubble | -2 |
| (-J*c*chi), (L*chi), derivative on antighost in a*Cext*B | +2 |
| Same triangle, derivative on vector | -2 |
| Same triangle, derivative on external ghost | 0 |

These factors refer to the explicit abstract vertex signs in RECORD, not to
already assembled action tensors. Full generic-q kernels agree, with metric
diag(1,-1,-1,-1), both mixed/ghost orientations and all four Lorentz components.
The derivative units sum to zero as required by integration by parts. The
external derivative zero is specific to the no-jet Taylor coefficient.

The common positive-reference-mass Euclidean integral has residue1/(16*pi^2).
Radial heat and dimensional Feynman-parameter routes agree. After the radial
measure its IR behavior is 1/(z+Mref^2), finite for Mref^2>0. This does not justify
setting Mref=0 before integration or removing the physical IR prescription.

Scalar or ghost omission destroys every nonzero unit. Mixed-propagator omission
destroys the triangles but is insensitive to the bubble. B/B omission is
insensitive throughout because no selected graph uses a B/B edge; all omission
controls on the external-derivative zero are insensitive. Source/external-ghost
ordering and the complete two-generator exterior algebra are checked separately.

Workers take about0.45 and0.34 seconds after imports, no failed worker. No actual
Spin(10) tensor contraction, canonical node, known Gamma or Slavnov relation is
calculated. Shared inherited algebra/conventions/AI authorship limit independence.
No old coefficient is rerun. Authority34of39 and every blocked/paused boundary
remain unchanged; full source/E5/A5/QAP/contact/IR/physical viability are open.

Next: extract the actual SX, O_aCX, F and O_LX tensors with the reference ghost,
mixed and scalar metrics; contract using these explicit unit conventions and
an independent representation identity. Preserve the separate known x=v+eta
translations. Do not choose a coefficient to cancel a consistency equation.
