"""Dimension-one scalar-source universal units; no actual color coefficients."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations
import importlib.util,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('qualified_graded_unit_algebra',ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_units/units.py');ex=importlib.util.module_from_spec(sp);sp.loader.exec_module(ex)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
oldinverse=ex.inverse
def inverse(a,b,epsilon=1,**opts):
    if a==b=='uv_chi':return ex.ZERO if opts.get('omit_scalar',False) else ex.t
    return oldinverse(a,b,epsilon,**{k:v for k,v in opts.items() if k!='omit_scalar'})
def model(kind,ds):
    w=ex.alphabet();w.fields={**{f'uv_B0_{mu}':(1,0,0) for mu in range(4)},'uv_L0':(2,0,0),'uv_c0':(1,1,1),'uv_a0':(1,-1,1),'uv_chi':(1,0,0)};w.grades=w.fields;w.pairs=[];w.external={};w.p={n:v[2] for n,v in w.fields.items()}
    for n,gr in [('uv_J',(2,-1,1)),('uv_Ce',(1,1,1))]:ex.register(w,n,gr)
    v=w.var;SJ=w.scale(w.mul(v('uv_J'),v('uv_c0'),v('uv_chi')),-1)
    if kind=='bubble':V=[SJ,w.mul(v('uv_a0'),v('uv_Ce'),v('uv_chi'))]
    else:
        assert kind=='triangle' and len(ds)==1;where=ds[0];assert where in ['a','B','c']
        F=w.add(*(w.scale(w.mul(w.D(v('uv_a0'),mu) if where=='a' else v('uv_a0'),w.D(v('uv_Ce'),mu) if where=='c' else v('uv_Ce'),w.D(v(f'uv_B0_{mu}'),mu) if where=='B' else v(f'uv_B0_{mu}')),ex.ETA[mu]) for mu in range(4)))
        V=[SJ,F,w.mul(v('uv_L0'),v('uv_chi'))]
    return w,V,w.mul(v('uv_J'),v('uv_Ce'))
ex.inverse=inverse;ex.model=model
def born(kind,ds,**opts):
    w,V,target=model(kind,ds);names=list(w.fields);order=sorted(w.external);normal=ex.extpack(target,order)[3]
    G={(i,j):{0:z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=inverse(a,b,**opts))};Hs=[ex.Hessian(P,w,order) for P in V];n=len(Hs);values=[]
    for order in permutations(Hs):
        A=G
        for i,H in enumerate(order):
            A=ex.mm(A,H)
            if i<n-1:A=ex.mm(A,G)
        z=sum(((-1)**w.p[names[i]]*P.get(3,ex.ZERO) for (i,j),P in A.items() if i==j),ex.ZERO)*ex.II*ex.num(s.Rational((-1)**(n+1),2*n))*normal;values.append(z)
    return sum(values,ex.ZERO),{'ordered_Born_kernels':[str(z.as_expr()) for z in values],'word_count':len(values)}
def integrals(route):
    e,c=s.symbols('epsilon c',positive=True);M2,mu2=s.symbols('Mref_squared mu_squared',positive=True)
    if route=='primary':
        radial=s.exp(c)*s.expint(1,c)/(16*s.pi**2);residue=s.simplify(s.limit(-c*s.diff(radial,c),c,0,dir='+'));expression=str(radial)
    else:
        dimensional=(mu2/M2)**e*s.gamma(e)/((1-e)*(4*s.pi)**(2-e));residue=s.simplify(s.limit(e*dimensional,e,0,dir='+'));expression=str(dimensional)
    assert residue==1/(16*s.pi**2)
    # After the radial measure z dz, the IR integrand is 1/(z+M2).
    z=s.symbols('z',nonnegative=True);assert s.limit(1/(z+M2),z,0)==1/M2
    return {'residue':str(residue),'own_regulated_expression':expression,'kernel':'1/[k_E_squared*(k_E_squared+Mref_squared)]','IR_finite_for_temporary_Mref_squared_positive':True,'physical_IR_removal_proved':False}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][route]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SCALAR_SOURCE_UNITS_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('UNDECLARED_UNIT_INPUT '+str(p))
    sys.addaudithook(guard)
    folder=ROOT/'calculations/canonical_so10_dimensionful_source_inventory';p=folder/('primary_result.json' if route=='primary' else 'replay_v2_result.json');receipt=read(folder/'validation_receipt.json');assert receipt['execution_state']=='COMPLETED' and receipt['input_sha256'][str(p)]==digest(p);domain=read(p)['targets']['C_Jx'];assert domain['log_profiles']==6 and domain['power_profiles']==0
    calculate=born if route=='primary' else ex.wick;cases=[('bubble',()),('triangle',('a',)),('triangle',('B',)),('triangle',('c',))];units={};details={};controls={}
    for kind,ds in cases:
        label=kind+('_'+ds[0] if ds else '');print('STAGE '+route+' '+label,flush=True);z,info=calculate(kind,ds);units[label]=str(ex.pole(z));details[label]={'full_general_q_kernel':str(z.as_expr()),**info}
        for mutation in ['omit_scalar','omit_ghost','omit_mixed','omit_BB']:
            q,unused=calculate(kind,ds,**{mutation:True});controls[label+'_'+mutation]={'unit':str(ex.pole(q)),'changes_unit':q!=z}
    assert s.simplify(sum(s.sympify(units['triangle_'+d]) for d in ['a','B','c']))==0 and units['triangle_c']=='0'
    assert units['bubble']!='0' and units['triangle_a']!='0'
    for label in ['bubble','triangle_a','triangle_B']:
        assert controls[label+'_omit_scalar']['changes_unit'] and controls[label+'_omit_ghost']['changes_unit'] and not controls[label+'_omit_BB']['changes_unit']
        assert controls[label+'_omit_mixed']['changes_unit']==label.startswith('triangle')
    # Exhaust the two-generator exterior algebra independently of unit support.
    w,V,target=model('bubble',());order=sorted(w.external);basis={m:w.mul(*(w.var(n) for i,n in enumerate(order) if m&(1<<i))) for m in range(4)}
    for a in range(4):
        assert ex.extpack(basis[a],order)=={a:ex.ONE}
        for b in range(4):assert ex.extpack(w.mul(basis[a],basis[b]),order)==ex.exterior({a:ex.ONE},{b:ex.ONE})
    integral=integrals(route)
    print('RESULT '+json.dumps({'schema':'DIMENSIONFUL_SCALAR_SOURCE_UNIT_KERNELS_V1','route':route,'units':units,'kernel_details':details,'controls':controls,'derivative_IBP_sum_zero':True,'all4_Lorentz_components_retained':True,'two_generator_exterior_all16_products_checked':True,'radial_integral':integral,'unit_multiplier':'2*I*(q_squared)^2','target_order':'Jx*C','actual_action_color_tensors_or_coefficient_computed':False,'known_Gamma_updated':False,'finite_IR_full_source_E5_A5_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
