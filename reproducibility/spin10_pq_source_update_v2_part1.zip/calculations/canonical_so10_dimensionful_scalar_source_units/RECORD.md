# Intrinsic dimension-one scalar-source loop units V1

Baseline108bc597e7f50a200f70e75e36e4958ef553bdfb; standing AGENTS delegation.
Question: what are the complete graded loop-unit factors for the two surviving
g10^3*xi Jx*C families before actual color tensors are assembled? This is the
smallest normalization prerequisite for a missing coefficient, not a new graph
catalogue or another selected Slavnov check. No coefficient is fitted.

Reuse the qualified full-x envelope: SX-O_aCX and SX-F-O_LX, both Phi/Sigma,
no B/B reference edge. Retain generic four-momentum q with Minkowski metric,
both ghost and mixed vector/auxiliary orientations, zero L/L inverse, real
scalar inverse and odd source/ghost order. Abstract ordered interactions are
-J*c*chi; a*Cext*chi; L*chi; and sum_mu eta_mu derivative(a*Cext*B_mu),
where the derivative may be placed on a, Cext or B separately. The orbit
vertices carry one implicit dimension-one coefficient. All source/ghost signs
are part of the calculation. Derivatives on the external ghost are zero only
for this specified no-jet UV target; preserve them as zero units, not absent
amplitudes at nonzero momentum.

Compute the bubble and all three triangle placements using graded Hessian
Born traces versus direct proper Wick matchings with their exponential and
cyclic factors. The helpers from the qualified quartet unit calculation may
be reused as algebra/Grassmann tools, not its family-specific results. Scalar
UV inverse t is added explicitly; t=1/q^2. Require full generic-q agreement,
IBP sum, independent exterior products, signs and mixed/ghost omission controls.
Report any insensitive controls. Never obtain a physical pole by multiplying
a guessed color factor. No ordinary B/B width is discarded from a graph that
needs it; these selected graphs have none by the recovered inventory.

The common Euclidean radial integral is 1/[k_E^2(k_E^2+Mref^2)], Mref^2>0.
Retain the established temporary scalar reference, check IR integrability and
derive the log residue by radial/Schwinger versus Feynman-parameter dimensional
routes. No massless zero-momentum scaleless integral or physical IR removal.
The unit convention is common hbar/(32*pi^2*epsilon_UV), with actual action
couplings/tensors not yet inserted. Do not confuse ultraviolet unit signs with
the as-yet uncontracted physical tensor signs or claim a completed coefficient.

Two sequential120-second/8GiB workers plus separate120-second/8GiB validation,
minimum350MiB available commit. Freeze sources/controllers/inputs/own-role
allowlists first; preserve failures and version corrections. No old loop,
Gamma/Q/Ward replay, physical input or authority change. Independent methods
share action/conventions, algebra helpers and AI authorship; no expert or
empirical validation is implied. Ceiling: universal loop-unit normalization
only. Full source,E5/A5,QAP/measure/contact/IR/physical viability remain open;
HB1/C5 blocked, flavor paused,C1_GS uncomputed,custodyexit2/seven and scalar
warnings preserved. Education remains voluntary/concurrent/nonblocking.
