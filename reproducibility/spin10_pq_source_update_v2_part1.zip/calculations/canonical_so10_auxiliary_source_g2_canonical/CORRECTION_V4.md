# Use the frozen coefficient normalizer V4

V3 recovered145310 terms but failed the required previous-functional row hash.
The cached merger serialized expanded coefficients; the actual immutable
a10_bv_integration_common.clean uses sympy.simplify, including factored g/xi
expressions. A mathematically equivalent expression is not byte-identical
evidence. V3 source/preparation/full capture remain failed and unqualified.

V4 replaces only the cached sum normalizer's expand by the frozen simplify.
The original exact145310 count and full13c63bd3... row hash remain mandatory;
there is no hash rebinding or tolerance. The merged input rows otherwise stay
unchanged. Move recovery of the old recipe before the independent new-node
work so this engineering prerequisite fails cheaply if still incorrect.
No new coefficient or operator is chosen; old loops are not rerun. This
reordering does not affect the already measured pole or either transport
method. The inherited orbit split and compact jet parser remain required.

Two sequential300second/sampled8GiB workers under standing delegation. If
this hash still fails, stop the cached merger and report its unresolved
normalization rather than asserting scientific agreement. Three original
primary failures/no results/no replays are retained. No scientific PASS is
inferred from reaching a later stage in any failed run.
