# Abandon the unqualified cached merger; use the original engine

V4 again failed the unchanged old-functional hash. Its failure disproves the
claim that changing only the cached sum formatter resolved the discrepancy.
The optimization is therefore abandoned, not certified equivalent. No new
functional or scientific result has been accepted. All four failed primaries
and their exact sources/preparations/captures remain; no replays launched.

V5 reconstitutes each recipe sum using the same qualified decode_typed,
GaugeWords.add,canonical and rows path that produced the checkpoint. No old
loop is repeated. The existing count145310 and exact old digest remain
mandatory before use. New-node add/subtract/double operations use this same
established engine; the cached merger is not used. Both independent new-node
transport/Q methods, exact OrbitPullback split, full roundtrip/reality/local-H
tests, blind peer barriers and scientific ceilings stay required.

This is a bounded engineering-method replacement after explicit failure review,
not a hash rebind, resource increase or smaller scientific target. Two
sequential300second/sampled8GiB workers; incomplete execution stays incomplete.
The original frozen recipe remains authoritative even if a new optimization
can reproduce its term count. Track B must retain this optimization failure.
