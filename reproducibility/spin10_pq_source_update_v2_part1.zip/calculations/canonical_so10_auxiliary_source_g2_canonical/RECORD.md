# Canonical integration of the lower auxiliary-source pair pole V1

Baselinea57671753cc47f2d73f6a6a074780a157835024b; standing AGENTS delegation,
statev113/34of39 unchanged. Actual physical g2*xi JLambda*Lambda*C pole has
776 coefficients; its loop is qualified in the previous versioned receipt.
This increment does not recalculate it or adopt a normalization/physical input.

Question: can that complete node be transported faithfully, shown absent
atg2 in the actual current functional, and added exactly once? What is its
full local-H Ward variation and its contribution to the E2 odd consistency
operator? Preserve a nonzero result; no required identity may fix coefficients.

Retain displayed JLambda_i*Lambda_l*C_k order, grades(1,-1,odd),(2,0,even),
(1,1,odd), density(4,0,even), g10^2*xi hbar/(32*pi^2*epsilon_UV), no extra1/2.
Use all45 source/auxiliary/ghost coordinates and the actual evaluation-dual
maps. With the existing frames, physical source_i=sum_j anti[j,i]*rawSource_j,
physical auxiliary_l=sum_b source[b,l]*rawAux_b, physical ghost_k=sum_r
Cphys[k,r]*rawGhost_r. Do not apply the same primal map to both source and
field or insert a Lorentz metric. Check all chart roundtrips and the inherited
antilinear real structure; individually complex C3 coefficients are allowed.

Primary performs full graded polynomial substitution. Replay separately
contracts the three tensor axes. Both complete physical roundtrips, canonical
nodes and literal scalar coefficients must agree. Reverse odd source order,
wrong source chart and source-variation omission are controls. Record any
normalization control invisible to a separately invariant node's Ward image.

Use the complete actual E3 Tb images for all active raw variables, retaining
any image jets; compare ordinary polynomial action with explicit component
replacement. Since this node has no jets, test whether images are homogeneous
and no local-parameter derivative is generated; do not assume a rigid-H test
alone proves local-H invariance. Retain all12 parameter components.

Recover the current145310-term functional from its exact nested V183 recipe,
including every earlier actual node once. Authenticate all links and the saved
row hash13c63bd3efac36a12334b1928e4b9ac51e6017eed5c852911c98d7c219248878.
An exact raw-row merger may cache equal coefficient additions; it must match
that complete digest before use. This reuses old mathematics, not a fresh
full Gamma or Ward calculation. Explicitly scan the full g2 JLambda*Lambda*C
class; old g3 source-pair entries are different. Add only the actual new node,
check subtraction restores the prior row hash and doubling changes the node.
Export a compact exact recipe rather than another full copy of Gamma.

Additionally inspect every active complete E2 column and require its
physical_program=None before explicit use. Calculate the entire new-node
Qprime contribution with actual source_polynomial images, primary graded
prefix action versus replay's independent left-gradient action. Retain raw
terms, role/g/jet signatures and separate source/auxiliary/ghost pieces.
No full old Q replay, unknown breaking, physical-Euler substitution, IBP
quotient or completed Slavnov-failure claim. If an active physical program
appears, stop the affected branch rather than omit it. The contribution has
grade(5,1,odd). Its census guides the next complete predecessor assessment.

Two sequential read-only300second/sampled8GiB workers with350MiB minimum
available commit; freeze source/controller/own-role allowlists first. Keep
full native captures and preserve failures. Separate frozen validator checks
the full coefficient transport using independent SymPy indexing, source-dual
pairing/reality, exact node/recipe hashes, Ward/Q agreement and named controls.
No loops, searches, benchmark adoption, blocked-stage activation or framework.

Ceiling: complete canonical node/add-once and its full E3/E2 contributions,
not complete quantum restoration or physical validation. Shared action/charts,
word/arithmetic helpers and AI authorship limit independence. E5/A5,QAP,finite/
IR,measure/anomaly freedom remain unqualified; HB1/C5 blocked,C1_GS uncomputed,
flavor paused,old failures/scalar warning,custodyexit2/seven preserved. Track A
integrates missing evidence; Track B tests coverage and primal/dual/odd-sign
reasoning; education concurrent,voluntary,nonblocking. No alternate authority.
