# Replay both exact serialization checkpoints V6

V5 also failed the unchanged previous hash. No assertion that its proposed
method fixed reconstruction is accepted. It used canonical coefficients
stringified directly, while the checkpoint's rows() applies the frozen
normalizer again; it also flattened the prior93864 sum and later scalar
addition into one step. Those are not the literal checkpoint procedure.

V6 follows V183's exact two-step procedure: reconstruct93864 with the original
engine and check its complete saved hash, then add the scalar node and check
the145310 hash using the actual rows() serializer. All row materialization
uses rows(Q), including add/subtract/double checks. Diagnostic counts/hashes
are emitted before each assertion so any remaining failure is observable,
not another guessed formatting repair. Both exact saved digests are required;
neither is rebound. No new loop, coefficient, operator or cap changes.

Five failed primary runs remain preserved; none has a qualified result/replay.
Two sequential300second/sampled8GiB workers. This is custody/serialization
reconstruction of previously qualified mathematics, not physical progress by
itself. If the exact intermediate replay fails, report that precise checkpoint
failure and stop the integration claim before any new functional is adopted.
