# Common classical typing metadata; own replay orbit polynomial

V6 primary completed all requirements and is reused unchanged. V6 replay
reproduced both exact old hashes and completed its node transport/local-H/Q
pieces, then failed because replay E1 geometry does not duplicate primary's
coefficient_mass_dimensions field. Its own heavy_orbit polynomial is present.
The full failed replay source/preparation/capture remains unqualified.

V7 changes only that metadata lookup: read the qualified common E1 primary
typing record to check OrbitPullback dimension1, while continuing to use the
own-role heavy_orbit polynomial and own operator/transport calculations.
The shared metadata read is explicitly allowed,bound and disclosed. It is
not an independent rederivation of physical mass dimensions. All exact orbit
coefficient,grade,roundtrip,checkpoint and node checks remain required.

One read-only replay300seconds/sampled8GiB, reusing completed V6 primary.
No new primary, old loop, physical coefficient or assumption. Five failed
primaries and this failed replay are preserved. No failed stage is promoted.
