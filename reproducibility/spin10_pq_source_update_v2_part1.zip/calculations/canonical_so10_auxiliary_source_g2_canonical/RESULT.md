# The missing lower-order source node is integrated canonically

The776-term physical g10^2*xi JLambda*Lambda*C pole transports to236 canonical
terms with complete physical roundtrip and inherited antilinear reality.
It is absent from the previous145310-term measured functional at this order.
Adding the actual node exactly once gives145546 terms, with complete row hash
5a559c6b0e7b8ac20ff0f4be5be9b9edd89d227569727755a4adf2d459184417.

Qualification requires completed V6 primary/V7 replay results/captures, separately frozen
validation_receipt.json and exact committed-byte checks. A report, term count
or partial stage completion alone cannot qualify an execution. No loop was
recalculated, coefficient fitted, source activated or physical input adopted.

## Coordinate and symmetry findings

Primary substitutes the complete graded physical density through the actual
inverse charts. Replay independently contracts its source,auxiliary and ghost
tensor axes with anti,source,Cphys respectively. All135 chart roundtrips and
both complete physical/canonical densities agree. The raw source uses the
evaluation-dual map, not the field's primal map. The wrong source chart changes
the result and fails its physical roundtrip. No Lorentz factor is inserted.

Twenty canonical coefficients are individually complex. That is allowed:
the full polynomial is fixed by the inherited antilinear real structure and
maps back to the exact real physical coefficient table. Componentwise-real
C3 coefficients would be an invalid acceptance test.

The complete local-H Ward variation of this node is zero. Every active E3
image is homogeneous with no parameter or field jets, so this is a local-H
calculation retaining all12 parameter components, rather than a rigid-only
check silently extended to varying parameters. Omitting source variation gives
a nonzero result. Omitting or doubling the entire separately invariant node
remains invisible to its Ward zero; physical roundtrip and add-once tests
provide the normalization evidence instead. The previous saved known-partial
Ward zero plus this exact zero gives the enlarged known-partial Ward zero by
linearity. Full unknown-functional Ward restoration is not established.

## Exact old lineage and the retained engineering failures

Both exact previous serialization checkpoints are required:93864 terms/hash
2c6be2cb545bf41ad563f969d9ccde3e65df26ff5d28b024947bfb14591884d5,
then145310 terms/hash
13c63bd3efac36a12334b1928e4b9ac51e6017eed5c852911c98d7c219248878.
The actual old decode,polynomial add,canonical and rows normalizers reproduce
them using the literal two-stage recipe. New actual row data are added once;
subtraction restores the previous complete row hash, while doubling changes
the functional. Only a compact reconstruction recipe/new node is exported,
not another full stored copy of Gamma. This reuses old qualified mathematics;
no old loop,full old Q or full old Ward is freshly executed.

Five primary attempts are preserved without qualified results or replays.
The first overgeneralized the field-degree assertion and missed the inherited
dimension-one OrbitPullback. V2 retained that exact exception but failed the
compact second-jet parser. V3/V4's cached mergers and V5's incomplete emulation
of canonical serialization failed the unchanged old-functional hash despite
recovering its term count. Those attempted optimizations are not qualified
equivalents. V6 follows the actual intermediate checkpoints and rows serializer.
No expected digest was rebound. See CORRECTION_V2 through CORRECTION_V6 and
the full native captures. Repeated formatter repairs were an avoidable AI
engineering/prioritization failure; reaching a later stage was never PASS.

V6 replay separately failed a missing metadata field: its E1 geometry omits
the primary record's mass-dimension annotation. V7 reads that qualified common
typing record while retaining its own orbit polynomial and independent action.
The shared metadata is disclosed, not claimed as another dimension derivation.
Its failed V6 replay capture is preserved; completed primary is reused unchanged.

V6 primary243.6655178seconds after imports, within300seconds/sampled8GiB;
the paired replay and validator resource observations are recorded in the
completed receipt. Distinct role commands are not fresh identical-command
replay pairs. Scientific custody exit2/seven was preserved, not rerun.

## What the new term contributes to consistency

All97 active canonical variables have explicit E2 source_polynomial images
and physical_program=None. No physical Euler program was substituted or
discarded. The other508 physical Euler programs remain deferred. Both graded
prefix variation and independent left-gradient replacement retain the whole
new-node Qprime contribution:17208 raw terms in eight type/g/jet signatures.

| Types | g power | Ordinary jets | Raw terms |
| --- | --- | --- | --- |
| B,B,C,Lambda | 3 | 0 | 4992 |
| B,C,Lambda | 2 | 1 | 944 |
| C,C,C,JLambda,a | 4 | 0 | 4968 |
| C,C,JLambda,Lambda | 3 | 0 | 1004 |
| C,C,Lambda,a | 2 | 0 | 1688 |
| C,Ja,Lambda | 2 | 0 | 236 |
| C,Lambda,Lambda | 2 | 0 | 128 |
| C,Lambda,x | 3 | 0 | 3248 |

Explicit xi factors and all coefficients remain in the actual tables; this
census groups only types,ordinary jets and g power. These are contributions
from the new node, not a completed remainder for the enlarged functional.
They are not the historical18416-term background-Ward remainder, which belongs
to different older data and a different calculation.

The3248 scalar terms are exactly the inherited dimension-one OrbitPullback
image reconstructed from the own-role frozen E1 heavy_orbit gauge fermion.
Their field dimension is4 and coefficient dimension1. The remaining13960
terms have field dimension5 with dimension-zero coefficients. Both have ghost
number1 and odd parity. The exact exception and all classical columns are
checked rather than dropping the lower-field-degree terms. No other grading
exception is admitted. Full raw Q and its source/auxiliary/ghost pieces are
preserved; no IBP or field equation quotient is taken.

The independent validator manually reconstructs every transported coefficient,
the antilinear tensor relation and full odd/even word replacements, without
calling this new action engine. Its unchanged chart inputs,normalization,
Python/SymPy and AI authorship still limit independence. A wrong-even variation
and omitted source variation are nonzero controls. Mathematical agreement does
not validate shared physical assumptions or prove autonomous scientific reliability.

## Consequence and next action

The current measured-functional recipe is now this V6 result: the exact V183
145310 recipe plus new_actual_g2_xi_pair_node once. Do not use the previous
recipe as if this coefficient remained zero or had already been included.
The original g3 source-pair node is different and remains included once.

Next recover a complete predecessor census for the affected low-order source
relations, starting with the no-jet Ja*Lambda*C channel and the
JLambda*Lambda*C*C channel. Existing nonminimal-source,ghost-source and
quartet poles may now suffice in selected coupling slices; verify their exact
orders before evaluating. Do not interpret the17208-term node contribution
as an anomaly or as a complete consistency failure. Missing higher-order
quartet profiles and positive-dimensional scalar obligations remain separate.
The proposed lower-g3 vector double-longitudinal zero is still uncalculated.

Authorityv113/34of39 unchanged. Full source/Slavnov,E5/A5,QAP,finite/IR,measure/
anomaly freedom remain unqualified; HB1/C5 blocked,C1_GS uncomputed,flavor
paused. Old quartet/benchmark failures,scalar quantum warning and custody
exit2/seven retained. No scientific promotion,accepted benchmark/foundation,
new policy or remote action. Track A integrates a real missing coefficient;
Track B records successful tensor/coverage tests and five failed primaries
plus one failed replay. Education remains concurrent,voluntary,nonblocking.
Whole goal incomplete.
