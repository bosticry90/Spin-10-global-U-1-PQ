"""Full rank-three canonical pullback, exact recipe and node-only E2/E3."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from functools import lru_cache
import json,os,re,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,xi,canonical,decode_typed,rows,act,cm,zero
from a10_e5_measured_functional_v3 import frames
from a10_e2_transport_common import partials
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
etaH=s.Symbol('eta_H',real=True)
def rowhash(table):return sha256(json.dumps(table,sort_keys=True,separators=(',',':')).encode()).hexdigest()
@lru_cache(None)
def token(n):
    name,sep,jets=n.partition('__');assert '__' not in jets and all(v in '0123' for v in jets)
    return name,tuple(map(int,jets))
@lru_cache(None)
def parse(z):return s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':etaH})
@lru_cache(None)
def summed(a,b):return str(s.simplify(parse(a)+parse(b)))
def merge(*tables):
    out={}
    for table in tables:
        for row in table:
            key=tuple(token(n) for n in row['word']);z=row['coefficient']
            if key in out:z=summed(out[key],z)
            if z=='0':out.pop(key,None)
            else:out[key]=z
    return out
def rawrows(P):return [{'word':[n+('__'+''.join(map(str,jets)) if jets else '') for n,jets in word],'coefficient':z} for word,z in sorted(P.items())]
def auth(folder,name,receipt='validation_receipt.json'):
    p=folder/name;r=read(folder/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p),str(p);return read(p)

def materialize(tables,w):
    Q=canonical(w.add(*(decode_typed(table) for table in tables)))
    return {word:str(z) for word,z in Q.items()}

def load_known(role,w):
    scalar_path=ROOT/f'calculations/canonical_so10_scalar_source_g3_canonical/{role}_v3_result.json';scalar=auth(scalar_path.parent,scalar_path.name)
    vector_path=Path(scalar['updated_known_recipe']['previous_recipe_path']);assert digest(vector_path)==scalar['updated_known_recipe']['previous_recipe_sha256'];vector=read(vector_path)
    derivative_path=Path(vector['updated_known_recipe']['previous_recipe_path']);assert digest(derivative_path)==vector['updated_known_recipe']['previous_recipe_sha256'];derivative=read(derivative_path)
    quartet_path=Path(derivative['updated_known_recipe']['previous_recipe_path']);assert digest(quartet_path)==derivative['updated_known_recipe']['previous_recipe_sha256'];quartet=read(quartet_path)
    rec=quartet['updated_known_recipe'];pair=rec['prior_source_pair_recipe'];base=pair['prior_recipe'];initial=read(PKG/base['base_path'])
    g4path=Path(derivative['updated_known_recipe']['previous_actual_g4_path']);assert digest(g4path)==derivative['updated_known_recipe']['previous_actual_g4_sha256'];g4=read(g4path)
    tables=[initial[base['base_key']],base['add_once'],pair['add_source_pair_once'],rec['add_actual_source_quartet_once'],g4['new_actual_g4_node'],derivative['new_actual_g2_node'],vector['new_actual_g3_node'],scalar['new_actual_g3_scalar_node']]
    known=materialize(tables,w);assert len(known)==scalar['updated_known_terms']==145310
    assert rowhash(rawrows(known))==scalar['updated_known_sha256']=='13c63bd3efac36a12334b1928e4b9ac51e6017eed5c852911c98d7c219248878'
    assert scalar['updated_known_Ward']==[]
    return known,scalar_path

def tensor_pull(P,A,B,C):
    out={};left=defaultdict(list);middle=defaultdict(list);right=defaultdict(list)
    for (j,i),z in A.todok().items():left[i].append((j,z))
    for (b,l),z in B.todok().items():middle[l].append((b,z))
    for (k,r),z in C.todok().items():right[k].append((r,z))
    for (i,l,k),z in P.items():
        for j,a in left[i]:
            for b,v in middle[l]:
                for r,c in right[k]:out[j,b,r]=out.get((j,b,r),0)+z*a*v*c
    return {key:s.expand(z) for key,z in out.items() if s.expand(z)!=0}
def density(P,w,physical):
    out={}
    for (i,l,k),z in P.items():
        J=f'JLp{i}' if physical else ('Jb'+str(i) if i<12 else 'JL'+str(i));L=f'Lp{l}' if physical else ('b'+str(l) if l<12 else 'L'+str(l));C=('Cp' if physical else 'C')+str(k)
        for word,sign in w.mul(w.var(J),w.var(L),w.var(C)).items():out[word]=sign*g**2*xi*z
    return canonical(out)
def even_action(P,w,images):
    out={}
    for word,z in P.items():
        for pos,(n,jets) in enumerate(word):
            for key,c in w.mul({word[:pos]:s.S.One},w.dword(images[n],jets),{word[pos+1:]:s.S.One}).items():out[key]=out.get(key,0)+z*c
    return canonical(out)
def odd_gradient(P,w,images):
    out={}
    for (n,jets),Q in partials(P,w,set(images)).items():
        for key,c in w.mul(w.dword(images[n],jets),Q).items():out[key]=out.get(key,0)+c
    return canonical(out)
def kind(n):
    if re.fullmatch(r'C\d+',n):return 'C'
    if re.fullmatch(r'(Jb|JL)\d+',n):return 'JL'
    if re.fullmatch(r'(b|L)\d+',n):return 'L'
    if re.fullmatch(r'(bar|ub)\d+',n):return 'a'
    if re.fullmatch(r'(Jbar|Jub)\d+',n):return 'Ja'
    if re.fullmatch(r'B\d+_[0-3]',n):return 'B'
    if re.fullmatch(r'A\d+_[0-3]',n):return 'A'
    if n.startswith('JC'):return 'JC'
    if n.startswith('JB'):return 'JB'
    if n.startswith('x_'):return 'x'
    if n.startswith('Jx_'):return 'Jx'
    raise AssertionError(('UNKNOWN_Q_ROLE',n))
def census(P):
    out=Counter()
    for word,z in P.items():
        types=tuple(sorted(kind(n) for n,j in word));jets=sum(len(j) for n,j in word)
        for (power,),c in s.Poly(z,g).terms():
            if c:out[types,jets,power]+=1
    return [{'types':list(types),'jets':jets,'g':power,'raw_terms':ct} for (types,jets,power),ct in sorted(out.items())]

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v5.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PAIR_CANONICAL_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('PAIR_CANONICAL_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();v=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return v
    folder=ROOT/'calculations/canonical_so10_auxiliary_source_g2_pair';data=auth(folder,role+'_result.json','validation_v2_receipt.json');P={(i,l,k):parse(z) for i,l,k,z in data['complete_physical_pole']};assert len(P)==776
    w,forward,back,source,anti,Cinv,Cphys=stage('actual_primal_dual_ghost_frames',lambda:frames(role));physical=density(P,w,True)
    known,previous=stage('original_qualified_engine_current145310_recipe',lambda:load_known(role,w))
    for i in range(45):
        for pre in ['JLp','Lp','Cp']:
            name=pre+str(i);zero(w.add(w.replace(back[name],forward),w.scale(w.var(name),-1)),'COMPLETE_CHART_ROUNDTRIP')
    if role=='primary':node=stage('complete_graded_polynomial_pullback',lambda:canonical(w.replace(physical,back)))
    else:node=stage('three_separate_tensor_axis_contractions',lambda:density(tensor_pull(P,anti,source,Cphys),w,False))
    assert w.grade(node,(4,0,0));roundtrip=stage('full_physical_density_roundtrip',lambda:canonical(w.replace(node,forward)));assert roundtrip==physical
    badchart=density(tensor_pull(P,source,source,Cphys),w,False);assert badchart!=node and canonical(w.replace(badchart,forward))!=physical
    active={n for word in node for n,j in word};assert all(not jets and kind(n) in ['JL','L','C'] for word in node for n,jets in word)
    starimages={n:canonical(w.replace({word:s.conjugate(z) for word,z in forward[n].items()},back)) for n in active}
    star=stage('complete_C3_antilinear_involution',lambda:canonical(w.replace({word:s.conjugate(z) for word,z in node.items()},starimages)));assert star==node
    e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');tb=e3['operators']['Tb_geometric_and_transported'];images={n:decode_typed(tb[n]) for n in active};nojets=all(not j for Q in images.values() for word in Q for n,j in word)
    method=(lambda Q,I:canonical(act(Q,w,I,role,0))) if role=='primary' else (lambda Q,I:even_action(Q,w,I))
    ward=stage('complete_local_H_Ward_variation',lambda:method(node,images));no_source=stage('omit_source_variation_control',lambda:method(node,{n:({} if kind(n)=='JL' else Q) for n,Q in images.items()}));assert no_source!=ward
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');cols=e2['complete_columns'];assert len(cols)==1286 and all(cols[n]['physical_program'] is None for n in active)
    qimages={n:decode_typed(cols[n]['source_polynomial']) for n in active};qmethod=(lambda Q,I:canonical(act(Q,w,I,role,1))) if role=='primary' else (lambda Q,I:odd_gradient(Q,w,I))
    qparts={tag:stage('new_node_complete_odd_Q_'+tag,lambda tag=tag:qmethod(node,{n:(Q if kind(n)==tag else {}) for n,Q in qimages.items()})) for tag in ['JL','L','C']}
    qtotal=canonical(w.add(*qparts.values()))
    e1=read(PKG/f'frozen_a10_e1_fermion/{role}.json');assert e1['geometry']['coefficient_mass_dimensions']['OrbitPullback']==1
    psi=decode_typed(e1['polynomial_parts']['heavy_orbit']);orbit_images={}
    for n in active:
        if kind(n)=='JL':
            anti_name=('bar'+n[2:]) if n.startswith('Jb') else ('ub'+n[2:])
            orbit_images[n]=canonical(w.scale(w.EL(psi,anti_name),-1))
        else:orbit_images[n]={}
        d,gh,p=(w.grades|w.external)[n]
        normal_image=canonical(w.add(qimages[n],w.scale(orbit_images[n],-1)))
        assert w.grade(normal_image,(d+1,gh+1,(p+1)%2)),'NO_OTHER_CLASSICAL_GRADE_EXCEPTION'
    orbit=stage('exact_inherited_dimension_one_orbit_contribution',lambda:qmethod(node,orbit_images))
    nonorbit=canonical(w.add(qtotal,w.scale(orbit,-1)))
    assert orbit and w.grade(orbit,(4,1,1)) and w.grade(nonorbit,(5,1,1)),'EXACT_TYPED_ORBIT_EXCEPTION_ONLY'
    qdirect=stage('whole_new_node_odd_Q_control',lambda:qmethod(node,qimages));assert qdirect==qtotal
    existing={}
    for word,z in known.items():
        if len(word)==3 and not any(j for n,j in word) and sorted(kind(n) for n,j in word)==['C','JL','L']:
            c=s.Poly(parse(z),g).coeff_monomial(g**2)
            if c:existing[word]=c
    assert not existing,'NEW_G2_PAIR_CLASS_ALREADY_PRESENT'
    actualrows=rows(node);updated=stage('add_actual_g2_pair_node_once',lambda:materialize([rawrows(known),actualrows],w));minus=rows(w.scale(node,-1))
    restored=materialize([rawrows(updated),minus],w);assert rowhash(rawrows(restored))==rowhash(rawrows(known))
    doubled=materialize([rawrows(known),actualrows,actualrows],w);assert rowhash(rawrows(doubled))!=rowhash(rawrows(updated))
    # Ordinary independent matrix reconstruction of the complete raw tensor is
    # performed again by the separate validator, not treated as a third loop.
    result={'schema':'AUXILIARY_SOURCE_G2_CANONICAL_V1','route':role,'physical_node_terms':len(physical),'canonical_node_terms':len(node),'new_actual_g2_xi_pair_node':actualrows,'physical_node':rows(physical),
      'full135_chart_roundtrips':True,'physical_density_roundtrip':True,'wrong_source_primal_chart_rejected':True,'antilinear_C3_reality':True,'componentwise_complex_canonical_coefficients':sum(s.simplify(z-s.conjugate(z))!=0 for z in node.values()),
      'new_local_background_Ward':rows(ward),'new_local_background_Ward_terms':len(ward),'actual_Tb_images_have_no_jets':nojets,'source_omission_Ward':rows(no_source),'all12_local_H_components_retained':True,
      'typed_dimension_one_OrbitPullback_image':rows(orbit),'nonorbit_new_node_odd_Q':rows(nonorbit),'orbit_Q_census':census(orbit),'all_other_Q_images_have_standard_grade':True,'new_node_odd_Q':rows(qtotal),'new_node_odd_Q_parts':{tag:rows(Q) for tag,Q in qparts.items()},'new_node_odd_Q_census':census(qtotal),'active_E2_columns_without_physical_programs':sorted(active),
      'whole_new_node_Q_equals_part_sum':True,'all508_other_physical_Eulers_deferred':True,'current_g2_source_pair_class_absent_before_addition':True,'prior_known_terms':len(known),'prior_known_sha256':rowhash(rawrows(known)),
      'updated_known_terms':len(updated),'updated_known_sha256':rowhash(rawrows(updated)),'updated_known_Ward':rows(ward),'updated_known_Ward_zero':not bool(ward),'add_once_inverse_and_doublecount_checked':True,
      'Ward_zero_insensitive_to_omission_or_doubling_when_separately_invariant':not bool(ward),'updated_known_recipe':{'previous_recipe_path':str(previous),'previous_recipe_sha256':digest(previous),'previous_terms':145310,'add_actual_node_key_once':'new_actual_g2_xi_pair_node'},
      'old_loops_or_full_old_Q_or_full_old_Ward_recomputed':False,'full_source_Slavnov_E5_A5_QAP_finite_IR_or_anomaly_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
