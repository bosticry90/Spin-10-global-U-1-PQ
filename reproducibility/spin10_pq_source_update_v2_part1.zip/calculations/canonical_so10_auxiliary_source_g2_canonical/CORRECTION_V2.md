# Preserve the inherited dimension-one orbit image

Original primary stopped after the full new-node E2 variation at an overly
broad field-degree assertion. No result/replay qualified. Source, preparation,
controller and full failure capture remain unchanged.

The established E1 action explicitly assigns mass dimension1 to OrbitPullback.
Its heavy_orbit gauge-fermion term contributes -EL_antighost(Psi_orbit) to
Qprime(JLambda). The exact same field-degree exception is qualified in
a10_e5_auxiliary_derivative.py and its auditor. A full unprojected E2 action
cannot silently treat that coefficient as dimension0.

V2 reconstructs this image from own-role frozen heavy_orbit, checks every
active classical column after subtracting only that image, and requires the
new-node variation to split EXACTLY into a field-dimension4 orbit contribution
with coefficient dimension1 and a field-dimension5 remainder. Both retain
ghost number1 and odd parity. All terms, coefficient tables and Q parts are
preserved, with an explicit orbit census. Nothing is dropped to satisfy the
original assertion. Any other grading exception stops qualification.

Canonical transport, actual pole and acceptance obligations are unchanged.
Two fresh sequential300second/sampled8GiB workers are frozen under standing
delegation, binding the additional E1 inputs and this correction. This is not
a retroactive PASS or a new physical assumption. It records an AI scope/
dimensional-bookkeeping failure caught by the explicit assertion.
