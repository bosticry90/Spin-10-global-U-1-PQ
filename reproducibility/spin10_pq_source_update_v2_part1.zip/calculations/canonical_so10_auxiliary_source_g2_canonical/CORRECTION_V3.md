# Preserve compact jet serialization V3

V2 completed the exact orbit split and whole-new-node Q comparison, then
stopped while reconstructing the old functional. The small row merger assumed
one '__' per derivative. The established serializer uses a single '__' followed
by all jet digits; e.g C0__01 means derivatives(0,1). It misparsed second jets.
No V2 result/replay qualified; all source/preparation/capture bytes remain.

V3 changes only that parser and its inverse serializer, with explicit compact
zero/one/two-jet roundtrip fixtures before freezing. The complete old145310
term/hash equality remains mandatory. No scientific coefficient, operator,
chart, orbit condition, grade, cap or acceptance test changes. Two sequential
300second/sampled8GiB workers; no old loop or full old Q rerun. This is an
engineering serialization failure, distinct from a scientific zero or failure.
