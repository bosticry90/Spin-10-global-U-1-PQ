# Authorized general coherent-Sigma assessment V1

The director selected “Authorize bounded general coherent assessment” for the
committed [proposal](../../docs/SCALAR_RECOVERY_REASSESSMENT_AND_COHERENT_SCOPE_V1.md).
Baseline 2d38e29c9d6767fede2e06ed4f6388855f72edea is clean; preflight found
no matching workers, state v113, authority 34/39. Two sequential roles only,
primary then independent verifier, each 120 seconds after imports and 8 GiB
sampled private allocation. Observe at least 350 MiB available commit directly
before each launch. Resource exhaustion is incomplete; no automatic retry.

Question: obtain the exact coherent expectation in the previously qualified
physical Sigma complement for GENERAL pure-Sigma quartics, then derive only
inexpensive consequences for the existing joint conditions. No new curve,
parameter point/search, input variation beyond the existing formal p1..p8
and real eta range, benchmark adoption, gauge/IR choice or quantum work.

Keep all representations, action monomials, kinetics, charges, VEV ratios,
phases and fixed coefficients. Restrict applicability to the existing
stationary larger-simple-weak-root domain with 290 positive physical modes,
33 gauge, one PQ and four tuned Higgs zeros. Prove that the SAME projector
annihilates the actual fixed mixed orbit/PQ and every Sigma component of the
weak Higgs space irrespective of the quartics/eta. Use the full weak support,
not a curve-specific eigenvector or a dimension-only removal. Mass positivity
outside the old curve is a retained hypothesis, not newly assumed proven.

The target is ell = mu0*p5+mu1*p6+mu2*p7+muX*p8, with mu the exact canonical
unit-sphere averages of Q0,Q1,Q2,X131 in 222 real directions. Derive all four
coefficients, retaining cancellations and signs. Inherited coherent identity:
<Omega|a0_contact|Omega> = -56*ell/pi. The adopted requirement implies
|ell| <= pi/112, necessary only. No full contact pass follows from this test.

Primary: construct complete sparse holomorphic bilinear polynomials for the
literal sorted-index P_k tensors, k=1,2, and their crossed X131 contraction.
Use exact Gaussian-integer Wick covariance from the actual Hermitian complex
projector, divided by the canonical sphere fourth moment. Obtain Q0 through
the exact norm identity; evaluate k=4 independently to check Q2-Q1=Q4.
No sampled fields, omitted zero channels or dense four-index tensor.

Verifier: independently construct ordered polarized Hessians by K-first
index enumeration, transport them through the projector and contract their
traces. Derive the real double-Laplacian trace factors; do not import the
primary coefficients or its polynomial/Wick implementation. Reuse qualified
geometry only with explicit actual orbit/weak checks and source disclosure.
Compare the final four exact values only after independent extraction.

Controls: canonical N=2*sum|z|^2=X^T X, mu0=1, raw b^2=3/160 correctly
canceled by the kinetic map, identical/coherent pair factors, all four
invariants, Q2-Q1=Q4>=0, -2Q1<=X131<=4Q1, Hermiticity and complete 29-term
inventory. Wrong metric/identical factors, altered projector and omitted
quartic must be rejected. O(N) references and positive-potential/indefinite
scattering plus canceling operators prevent false physical promotion.
Substitution of the CLOSED eta=eps^3 curve must recover its lower bound >=7,
not presume that seven is the exact expectation. This is regression, not
reopening the curve or selecting finite eps.

Inexpensive implications: transform ell exactly to x,s,z,D, audit previous
monotone eliminations against the new upper/lower bound, and combine with
the inherited pure-Sigma sufficient cone only conditionally. Do not treat
failure of that sufficient cone as a necessary stability failure. Attempt
no optimizer, new family or general quantifier elimination. If no complete
joint contradiction/compatibility proof is obtained, retain joint feasibility
as unresolved and supply the exact remaining condition.

Freeze all dependency/source/helper hashes before launch, UTF-8/AST-check
preparation, use read-only native workers and full captures. Freeze the
independent source/reports before its launch. Require actual independent
receipt, resources and raw Git index/HEAD/worktree checks. Preserve failed
and incomplete attempts. Zero fresh byte-identical replay pairs; inherited
full spectrum, basis, wedge theorem and massless-gauge warning are not rerun.

Possible outcomes: qualified four-coefficient necessary condition, a proved
contradiction only in a precisely covered domain, reduced necessary-set
compatibility, or explicit incompleteness. A missing projector premise or
mathematical discrepancy stops the affected claim. Full gauged scattering
remains unqualified; no massless exchange is discarded or regulated here.

Physics decision: stronger cheap screening before benchmark recovery. Missing
blocker: the general coherent functional. Existing tools provide geometry,
invariant definitions and a curve bound, not these four contractions. Minimum
new surface: the contractions and independent exact trace check. Maps must
preserve actual pairing, symmetry/weak support and constraints. Stop after
this bounded assessment; deactivate an unjustified test while preserving
evidence, deleting no old code. No automatic next execution or released input.

Preserve project_state.json/README, authority 34/39, custody exit 2/seven,
closed curve, fixed-eta exclusion, all prior successes/failures and quartet
failure. E5/A5 unqualified, HB1/C5 blocked, C1_GS uncalculated, flavor paused.
Shared action, representation/geometry, inherited proofs, arithmetic software
and analyst limit independence. Science and AI capability are equal objectives;
education remains voluntary/nonblocking. Broad investigation incomplete.
