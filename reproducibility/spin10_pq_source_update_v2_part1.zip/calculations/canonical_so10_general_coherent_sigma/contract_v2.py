"""Four exact invariant sphere averages by sparse holomorphic Wick contraction."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from collections import defaultdict
from fractions import Fraction
from math import lcm
import json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_coherent_sigma_screen'));import screen as geo
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(0,0)
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def conj(a):return (a[0],-a[1])
def scaled(a,n):return (n*a[0],n*a[1])
def parity(I):return (-1)**sum(a>b for i,a in enumerate(I) for b in I[i+1:])
def put(row,key,val):
 v=add(row.get(key,Z),val)
 if v!=Z:row[key]=v
 elif key in row:del row[key]
def build_rows(k,forms):
 rows=defaultdict(dict)
 for I,a,pa in forms:
  for J,b,pb in forms:
   common=tuple(i for i in I if i in J)
   for K in combinations(common,k):
    A=tuple(i for i in I if i not in K);B=tuple(i for i in J if i not in K)
    sign=parity(K+A)*parity(K+B)
    put(rows[A,B],tuple(sorted((a,b))),scaled(mul(pa,pb),sign))
 return {key:row for key,row in rows.items() if row}
def inner(r,s,P):
 out=Z
 for (a,b),v in r.items():
  for (c,d),w in s.items():
   ac=P.get((a,c),Z);bd=P.get((b,d),Z);ad=P.get((a,d),Z);bc=P.get((b,c),Z)
   cov=add(mul(ac,bd),mul(ad,bc))
   if cov!=Z:out=add(out,mul(mul(v,conj(w)),cov))
 return out
def cross_targets(I,J):
 for A in combinations(I,3):
  D=tuple(i for i in I if i not in A)
  for B in combinations(J,1):
   E=tuple(i for i in J if i not in B)
   if set(A)&set(B) or set(D)&set(E):continue
   yield (tuple(sorted(A+B)),tuple(sorted(D+E))),parity(A+D)*parity(B+E)*parity(A+B)*parity(D+E)
def geometry(old):
 P=S.SparseMatrix(126,126,{(i,j):S.sympify(z) for i,j,z in old['physical_projector_complex_sparse']})
 assert P==P.H and geo.zero(P*P-P) and S.trace(P)==111
 vacstate=geo.geom.vacuum();vac={I:S.Rational(a)+S.I*S.Rational(b) for I,(a,b) in vacstate[1].items()}
 G=S.Matrix.hstack(*[geo.vec(geo.move(vac,p,q)) for p,q in combinations(range(10),2)])
 exact=read(C/'canonical_so10_higgs_exact_light_ct_map/original_result.json');seeds=[]
 for raw in exact['raw_neutral8_basis'][:4]:
  assert all(S.Rational(a)==0 for a in raw['Phi']) and raw['S']=='0' and all(z=='0' for z in raw['phi'])
  seeds.append({tuple(I):S.Rational(a)+S.I*S.Rational(b) for I,a,b in raw['Sigma']})
 W=S.Matrix.hstack(*[geo.vec(f) for f in seeds]+[geo.vec(geo.move(f,p,q)) for f in seeds for p,q in combinations(range(6,10),2)])
 assert geo.zero(P*G) and geo.zero(P*W) and geo.zero(P*geo.vec(vac))
 seed_vectors=[geo.vec(f) for f in seeds]
 assert W.rank()==4 and geo.zero(seed_vectors[1]-S.I*seed_vectors[0]) and geo.zero(seed_vectors[3]-S.I*seed_vectors[2])
 assert S.Matrix.hstack(seed_vectors[0],seed_vectors[2]).rank()==2
 real_seeds=S.Matrix.hstack(*[S.Matrix([v for a in vv for v in (S.re(a),S.im(a))]) for vv in seed_vectors])
 assert real_seeds.rank()==4
 assert S.Matrix.hstack(G,W).rank()==15
 assert old['actual_mixed_gauge_orbit_rank']==33 and old['removed_weak_complex_rank']==4
 return P
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(O/'preparation_v2.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('GENERAL_COHERENT_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 old=read(C/'canonical_so10_coherent_sigma_screen/primary_result.json');PP=geometry(old)
 dd=1
 for v in PP.values():dd=lcm(dd,int(S.denom(S.re(v))),int(S.denom(S.im(v))))
 P={(i,j):(int(S.re(v)*dd),int(S.im(v)*dd)) for (i,j),v in PP.todok().items()}
 forms=[]
 for a,I in enumerate(geo.tops):
  J=tuple(i for i in range(10) if i not in I);forms.extend([(I,a,(1,0)),(J,a,(0,-parity(I+J)))])
 assert len(forms)==252 and len({I for I,a,z in forms})==252
 rows={k:build_rows(k,forms) for k in [1,2,4]};print('STAGE complete_sparse_bilinear_rows',flush=True)
 nums={};counts={}
 for k in [1,2,4]:
  total=Z
  for row in rows[k].values():total=add(total,inner(row,row,P))
  assert total[1]==0 and total[0]>=0;nums[k]=total[0]
  counts[str(k)]={'output_rows':len(rows[k]),'coefficient_entries':sum(map(len,rows[k].values()))}
  print('STAGE exact_Wick_norm_'+str(k),flush=True)
 total=Z;cross_count=0
 for (I,J),row in rows[1].items():
  for target,sign in cross_targets(I,J):
   other=rows[1].get(target)
   if other is not None:total=add(total,scaled(inner(row,other,P),sign));cross_count+=1
 assert total[1]==0;nx=total[0]
 m=111;d=2*m;den=4*m*(m+1)*dd*dd
 mu=[S.Integer(1),S.Rational(nums[1],den),S.Rational(nums[2],den),S.Rational(nx,den)]
 mu4=S.Rational(nums[4],den)
 assert mu[2]-mu[1]==mu4 and -2*mu[1]<=mu[3]<=4*mu[1] and mu4>0
 trace=S.trace(PP);norm_q0=4*(trace**2+S.trace(PP*PP))/(4*m*(m+1));assert norm_q0==1
 # Canonical unit sphere has E[z_a z_b z_c* z_d*]
 # =(P_ac P_bd+P_ad P_bc)/(4*m*(m+1)); N=2*z^dagger*z.
 p5,p6,p7,p8,x,s,z,D=S.symbols('p5 p6 p7 p8 x s z D',real=True)
 ell=sum(a*b for a,b in zip(mu,[p5,p6,p7,p8]))
 reduced=S.expand(ell.subs({p5:x/8,p6:(5*s+z)/2-5*D/24,p7:(-3*s-z)/2+5*D/24,p8:(z-s)/4}))
 assert S.diff(reduced,x)==S.Rational(1,8) and S.diff(reduced,D)==5*mu4/24
 eps=S.Symbol('eps',positive=True)
 family=S.expand(ell.subs({p5:S.pi/8,p6:7*eps/2-5*S.pi/24,p7:5*S.pi/24-5*eps/2,p8:eps/4}))
 lower_certificate=eps*mu[1]/2+(5*S.pi/24-5*eps/2)*mu4+eps*(mu[3]+2*mu[1])/4
 assert geo.zero(family-S.pi/8-lower_certificate)
 assert 5*S.Rational(3,1)/24-S.Rational(1,4)>0 and S.Rational(d+2,32)==7
 pure=[name for name,degree,content in old['full_action_inventory'] if degree==4 and content==[0,4,0,0]]
 assert pure==['lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4'] and len(old['full_action_inventory'])==29
 # Adverse controls: wrong metric, changed projector and omitted quartic.
 bad=PP.copy();bad[0,0]+=S.Rational(1,2);assert not geo.zero(bad*bad-bad)
 assert mu[2]!=0 and geo.zero(S.diff(ell,p7)-mu[2])
 b2=S.Rational(3,160);assert (b2*b2)/(b2*b2)==1 and b2*b2!=1
 for n in [2,3,4]:
  v=S.symbols('X0:'+str(n),real=True);V=sum(a*a for a in v)**2
  M,pairs=geo.pairmatrix(V,v);omega=S.Matrix([1/S.sqrt(n) if a==b else 0 for a,b in pairs])
  lap=sum(S.diff(V,a,2,b,2) for a in v for b in v)
  assert lap==8*n*(n+2) and (omega.T*M*omega)[0]==lap/(2*n)
 v=S.symbols('Y0:2',real=True);M,_=geo.pairmatrix((v[0]**2-v[1]**2)**2,v)
 assert -8 in M.eigenvals() and S.diag(1,-1)-S.diag(1,-1)==S.zeros(2)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 out={'schema':'GENERAL_COHERENT_SIGMA_PRIMARY_V2','status':'EXACT_FOUR_COEFFICIENTS_REQUIRE_INDEPENDENT_RECEIPT','coefficients_mu':list(map(str,mu)),'mu_Q4':str(mu4),'scaled_projector_denominator':dd,'Wick_numerators':{str(k):str(v) for k,v in nums.items()},'X131_Wick_numerator':str(nx),'sphere_denominator':den,'row_counts':counts,'crossed_output_terms':cross_count,'ell_general':str(ell),'ell_x_s_z_D':str(reduced),'closed_curve_ell':str(family),'closed_curve_lower_bound_recovered':'7','coherent_expectation':'-56*ell/pi','necessary_condition':'abs(ell)<=pi/112','conditional_cone_p5_upper':'pi/112','conditional_cone_x_upper':'pi/14','x_lift_preserves_new_upper_bound':False,'physical_real_dimension':d,'physical_projector_parameter_independent_under_declared_hypotheses':True,'outside_curve_mass_positivity':'retained conditional hypothesis;not newly established','all_four_quartics_and_29_terms':True,'old_invariant_and_mass_proofs_rerun':False,'full_variable_eta_domain_excluded':False,'joint_feasibility_resolved':False,'full_contact_operator_pass':False,'full_gauged_amplitude_qualified':False,'new_parameter_points':0,'new_parameter_search':False,'new_curve':False,'new_benchmark_adopted':False,'gauge_or_IR_choice_adopted':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True)
 print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
