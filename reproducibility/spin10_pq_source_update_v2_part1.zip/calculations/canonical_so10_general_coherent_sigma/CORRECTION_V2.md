# Proposed corrected primary V2 — additional execution authorization required

The original primary FAILED before invariant contraction. Its frozen source,
source copy and full primary_capture.json remain unchanged and unqualified.
One scientific role was used; the original independent-verifier role remains
unused. A preparation-only stale predecessor filename failure is preserved
separately and used no native role.

The failed assertion demanded complex rank four from the four REAL neutral
Sigma coordinate seeds. Their frozen literal entries instead satisfy
seed1 = i*seed0 and seed3 = i*seed2. They have complex rank two and real
rank four. The full SO(4)-closed weak support has complex rank four, as the
earlier qualified screen established; these are different spaces.

Prepared contract_v2.py corrects only this added seed-rank assertion. It
explicitly requires both i relations, complex rank two, real rank four and
the complete weak-support rank four, while retaining projector Hermiticity,
idempotence, rank, actual gauge/PQ/light annihilation and every invariant,
normalization, negative-control, resource and byte check. No physical input,
projector, action, parameter, expected coefficient or acceptance criterion is
changed. The false complex-rank-four premise is recorded as an implementation
error, not silently dropped or treated as a property of the theory.

The original contract says “No automatic retry.” Request ONE additional
corrected-primary execution under the same 120-second/8-GiB and immediate
350-MiB launch-observation requirements. If approved and completed, use the
one originally authorized independent-verifier role after it. Total attempts
would be two primary and one verifier, including the preserved failed primary.
Neither this prepared source nor this note authorizes that extra execution.
No further retry, parameter search, new curve, benchmark or quantum work.

Qualification still requires successful corrected primary and independent
derivation, agreement on all four exact coefficients, resource records and
raw Git checks. No result or scientific PASS exists at this preparation stage.
State/README, authority 34/39, custody exit 2/seven, closed curve and every
other scientific boundary remain unchanged. AI evaluation retains this
real-versus-complex rank error; director education remains nonblocking.
