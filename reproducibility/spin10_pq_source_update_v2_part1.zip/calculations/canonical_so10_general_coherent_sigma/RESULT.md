# General coherent Sigma condition — exact primary; verification gate

The corrected primary obtains the four exact canonical sphere averages

```
(mu0,mu1,mu2,muX) = (1,7417/3108,24439/9324,1255/259),
mu_Q4 = mu2-mu1 = 547/2331.
```

Qualification requires the actual [independent receipt](validation_receipt.json),
both accepted native/resource records and raw Git checks under the
[contract](RECORD.md) and [approved correction](CORRECTION_V2.md). This report
is prepared before the independent run; it alone does not establish PASS.

For GENERAL p5..p8, ell = mu0*p5+mu1*p6+mu2*p7+muX*p8.
In the established mass notation the exact result is

```
ell = x/8 + (1279/1554)s + (10201/9324)z + (2735/55944)D,
<Omega|a0_contact|Omega> = -56*ell/pi,
necessary contact condition: abs(ell) <= pi/112.
```

In plain language, the large-representation collective channel can now be
screened directly from the four Sigma couplings before building another
candidate. All four terms and their interference are retained. Passing this
one channel does not qualify the complete contact operator or a physical GUT.

## Physical applicability and normalization

Use the SAME 111-complex/222-real complement of the fixed actual vacuum's
gauge/PQ span and entire Sigma weak support. The actual full Phi/Sigma gauge
orbit has rank 33; the conservative complex Sigma orbit spans 22 real
directions, and adding the full weak support removes 30 real directions.
The projector is Hermitian/idempotent, orthogonal to those actual vectors,
and independent of the parameter-dependent Higgs mixture inside that support.

The neutral seeds are four REAL directions, comprising two complex directions.
Their SO(4)-closed weak support is four complex directions. These counts must
not be confused. The first native primary failed on the incorrect additional
assertion that the neutral seeds themselves have complex rank four. The
literal basis has seed1=i*seed0 and seed3=i*seed2. The approved corrected
primary checks both relations, real rank four, complex seed rank two and
the unchanged full weak rank four. The failed source and capture are retained.

For a broader comparison, applicability is CONDITIONAL on the already
specified stationary larger simple weak root and required local spectrum:
290 positive modes, 33 gauge, one PQ and four light-Higgs zeros. Fixed vacuum
and representation support justify the common subspace; new mass positivity
at arbitrary couplings is not proved or inferred from the closed curve.

N=2*sum|z|^2=X^T X, with each complementary selfdual basis form having N=2
and kinetic |dz|^2. Raw b^2=3/160 is transported with its kinetic map, not
applied again to the physical couplings. Unit canonical sphere gives mu0=1.
All 29 action monomials are typed; precisely the four Sigma quartics have
four external Sigma legs and enter this contact expectation. Other terms
can connect to other pair sectors but do not change this expectation.

## Exact extraction and independent test

The primary enumerates all ordered tensor components before collecting the
holomorphic bilinear coefficients. For k=1,2,4 respectively it retains
40,950 / 14,400 / 100 nonzero output rows and
152,460 / 128,520 / 4,410 polynomial coefficients. Proven zero outputs are
included by the complete enumeration, not omitted by a predicted result.
The X131 sum retains 302,400 nonzero-output crossed contraction terms.

With m=111 and projector covariance P,

```
average(z_a*z_b*conj(z_c)*conj(z_d))
 = (P_ac*P_bd+P_ad*P_bc)/(4*m*(m+1)).
```

Every contraction uses Gaussian integers with a common exact rational
denominator. No Monte Carlo, approximate eigenvalue, parameter sample or
dense four-index tensor is used. Direct k=4 contraction checks Q2-Q1=Q4;
the inherited wedge bounds check -2mu1<=muX<=4mu1.

The independent route is frozen before comparing coefficients. It enumerates
contracted indices K first, constructs ordered polarized Hessians H and
transports P^T*H*P. For real Q and real-coordinate Hessians G,

```
Delta_Q^2(q_r*conj(q_s))
 =2*tr(Q*G_r)*tr(Q*conj(G_s))+4*tr(Q*G_r*Q*conj(G_s)).
```

Holomorphic quadratic q has tr(QG)=0 on the complex-linear subspace. Its
remaining trace equals tr(P^T*H_r*P*conj(H_s)). Dividing by 8*d*(d+2)
gives the sphere average. Small exact reference polynomials check the real
derivatives, nonzero factors and the essential transpose. The independent
orbit construction uses output-index actions, rational real ranks and
uniqueness of the orthogonal projector, rather than the primary Gram route.

Wrong metric, identical/coherent factors, altered projector, lost quartic,
positive-potential/indefinite-scattering and canceling-operator controls are
required. The action, representation data, inherited proofs, Python/SymPy
and analyst are shared; this is not external scientific endorsement.

## Inexpensive joint consequences and remaining question

All four coefficients in the x,s,z,D form are STRICTLY positive. The inherited
local-mass conditions require x,s,z,D>0. Thus ell>0 and the adopted necessary
condition becomes this explicit positive linear upper bound on the SAME
couplings. In particular x<pi/14, equivalently p5<pi/112, throughout that
conditional local-mass domain. This follows from dropping strictly positive
s,z,D terms; it does not require assuming the sufficient BFB cone is necessary.
Within that sufficient cone the inherited bound ell>=p5 provides a separate
consistency check. Failure of the cone itself excludes nothing generally.

Previously increasing x was useful for the selected mass/Higgs/mixed-slice
filters. Now partial ell/partial x=1/8>0: increasing x can violate the new
contact ceiling. The earlier existential x-maximum lift cannot be reused
without retaining this extra upper bound. Likewise partial ell/partial D
=5*mu_Q4/24>0; D cannot be increased without checking the new condition.

As a regression only, the CLOSED eta=eps^3 curve gives

```
ell_curve = 1216*pi/6993 + (7019/2331)eps.
```

The inherited quartic certificate and exact coefficient identities reproduce
the earlier magnitude lower bound >=7; seven was not its exact expectation.
The curve remains closed. No finite eps or new family is investigated.

These new linear restrictions must still be combined with the actual weak
and colored Schur conditions, positive heavy-relaxed Higgs criterion and
complete known mixed-slice conditions. No complete joint contradiction or
compatibility certificate is established. The whole variable-eta domain
remains unresolved; a point search or additional free input is not authorized.
The next director decision should assess the value of bounded analytical
intersection of these conditions, rather than automatically proposing a curve.

## Execution history and authority ceiling

One preparation-only stale predecessor filename error used no native role.
The first primary FAILED at the seed-rank assertion before contraction.
The director authorized one corrected primary under the same caps; it
completed in about 14.54 seconds after imports. The original independent
verifier allowance remains the next required role at this report's preparation.
Require two primary attempts, one preserved failed primary and one accepted
verifier, with all memory/launch observations and source/evidence hashes.
No fresh byte-identical replay pair exists; the original invariant/spectrum
proofs are inherited, not reexecuted. No failed run is scientific PASS.

This is a necessary scalar-CONTACT condition under the adopted benchmark
filter. Full gauged scattering remains unqualified; no massless exchange,
gauge choice, coupling or IR prescription is removed or invented. Full328
BFB, complete contact norm, quantum control and physical matching remain
unproved. No benchmark, physical prediction, experimental confirmation or
general AI reliability is established.

Preserve state/README, authority 34/39, custody exit 2/seven, fixed-eta exclusion,
closed curve, all successes/failures, quartet discrepancy, E5/A5 unqualified,
HB1/C5 blocked, C1_GS uncalculated and flavor pause. Track A gains a general
necessary screen if validated; Track B retains the real/complex rank mistake
and tests structural reduction/independence. Education remains voluntary and
nonblocking. No new scope, remote action or outreach. Broad goal incomplete.
