# Validation V2: authenticate each route's own provenance link

The quick parent comparison and first native validator both mistakenly
required updated_known_recipe dictionaries to be identical across routes.
The native failure is preserved in validation_capture.json,with its exact
source,preparation and controller; it has no qualification receipt.

The actual difference is expected: primary points to qualified V189
primary_v6_result.json and replay to qualified replay_v7_result.json,with
their respective byte hashes. Every shared mathematical field,including
the complete node,Ward,controls and current/updated functional hashes,agrees.
The calculations are not rerun or changed. Corrected verifier V2 excludes
only this route-specific provenance dictionary from literal cross-route
equality and independently authenticates its exact own-role path/hash,
145546 prior terms and add-once key for BOTH routes. Every mathematical,
physical projection,resource and negative-control requirement is retained.

The separate validator retains180seconds/sampled8GiB/350MiB available commit.
Its completed receipt,if all required checks succeed,is validation_receipt.json;
validation_v2_capture.json records this corrected execution. A failure or
resource exhaustion remains unqualified. One timed-out mathematical primary
and one failed native verifier are preserved; the quick parent assertion
was a duplicated metadata comparison,not a new scientific calculation.
