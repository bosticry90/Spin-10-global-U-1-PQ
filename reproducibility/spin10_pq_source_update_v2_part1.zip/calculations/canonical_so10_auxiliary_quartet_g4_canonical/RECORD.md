# Actual higher auxiliary quartet canonical integration V1

Baseline0b76a1663b5da82345a57064fe3f26225ba0f429; standing AGENTS delegation,
authorityv113/34of39 unchanged. The actual complete CD0,no-jet g4 JLambda*a*C*C
local pole is qualified by the preceding paired calculation and receipt.
This increment transports it; no loop or required consistency tensor is used.

Question: does its full canonical transport preserve the actual density,
antilinear reality and local H variation, and can it be added exactly once to
the current145546-term known partial functional? A nonzero Ward variation is
an admissible scientific outcome, not a reason to alter measured coefficients.
Common unit hbar*g10^4/(32*pi^2*epsilon_UV); coefficient eta_H*A+xi*B,
4880 entries each,2004750 independent slots, ordered JLambda_i*a_j*C_a*C_b,
a<b and no extra1/2. Density grade(4,0,even).

Use all45 source,antighost,ghost coordinates. Physical source_i equals
sum_j anti[j,i]*rawSource_j; physical antighost_l equals
sum_b source[b,l]*rawAntighost_b; physical ghost_k equals
sum_r Cphys[k,r]*rawGhost_r. Two ghost axes retain their antisymmetric
exterior order. No Lorentz metric or source primal-map substitution.
Check all135 chart roundtrips, the complete density roundtrip and inherited
antilinear real structure. Componentwise complex coefficients are permitted.

Primary substitutes the whole graded polynomial. Replay separately contracts
the four tensor axes, then restores exterior order. Compare the entire
canonical node and all implicit zeros, the full12-parameter local H Ward
variation and omission controls. Use complete frozen E3 Tb images including
their jets; homogeneous no-jet images must be checked rather than assumed.
Primary uses the qualified action; replay explicit component replacement.
Wrong source chart, source-variation omission, ghost-pair half and double-add
are controls; report insensitive controls accurately.

Recover the current exact145546-term functional using the authenticated V189
compact recipe, with its staged93864/145310/145546 hashes. Reuse its qualified
serializer and cache; do not replay old loops or full old Ward/Q calculations.
Scan the entire no-jet g4 JLambda*a*C*C class before addition. Add the measured
node once, check subtraction restores the prior exact hash and doubling changes
the new result. Export a compact linked recipe, not another full Gamma copy.
The previous full Ward is qualified zero; the updated Ward is its sum with
the actual new variation. Ward invariance alone cannot detect omission or
doubling of a separately invariant node.

Two sequential read-only300-second/sampled8GiB workers,350MiB minimum available
commit. Freeze source,controller,own-role JSON allowlists and dependencies
first. Preserve full captures and every failure. Separate scoped validation
checks complete coefficient transport with independent matrix/exterior sums,
paired Ward,typing,reality,exact recipe and named controls. No new Q action is
included here: choose an affected Slavnov target only after a full predecessor
census. No physical Euler,missing pole or unknown breaking is inferred.

Ceiling: faithful actual canonical pole and add-once/local-Ward evidence.
Not complete source restoration,E5/A5,QAP,measure,finite/IR or anomaly freedom.
HB1/C5 blocked,C1_GS uncomputed,flavor paused,scalar warnings,old failures and
custodyexit2/seven preserved. Shared action,charts,unit/UV assumptions,helpers
and AI authorship limit independence. Track A integrates actual evidence;
Track B tests dual maps,exterior signs and completeness. Education remains
voluntary,concurrent,nonblocking. No accepted benchmark,input,foundation,
protected authority or remote action changes.
