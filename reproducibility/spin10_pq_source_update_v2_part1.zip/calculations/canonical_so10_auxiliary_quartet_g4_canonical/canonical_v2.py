"""Actual rank-four quartet transport and exact compact known-functional recipe."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
spec=importlib.util.spec_from_file_location('qualified_g2_canonical',ROOT/'calculations/canonical_so10_auxiliary_source_g2_canonical/canonical_v7.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
from a10_e5_nonminimal_source import s,g,xi,canonical,decode_typed,rows,act,zero
from a10_e5_measured_functional_v3 import frames
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
etaH=old.etaH
@lru_cache(None)
def num(z):return s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':etaH})
def auth(folder,name,receipt='validation_receipt.json'):
    p=folder/name;r=read(folder/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p),str(p);return read(p)
def entries(data):
    A={tuple(row[:4]):num(row[4]) for row in data['actual_eta_H_coefficient']};B={tuple(row[:4]):num(row[4]) for row in data['actual_xi_coefficient']}
    assert len(A)==len(B)==4880 and set(A)==set(B)
    return {k:s.expand(etaH*A[k]+xi*B[k]) for k in A}
def density(P,w,physical):
    out={}
    for (i,j,a,b),z in P.items():
        J=f'JLp{i}' if physical else ('Jb'+str(i) if i<12 else 'JL'+str(i))
        anti=f'ap{j}' if physical else ('bar'+str(j) if j<12 else 'ub'+str(j))
        C=lambda k:('Cp' if physical else 'C')+str(k)
        for word,sign in w.mul(w.var(J),w.var(anti),w.var(C(a)),w.var(C(b))).items():out[word]=out.get(word,0)+sign*g**4*z
    return canonical(out)
def axis(P,matrix,axisnum):
    slots=defaultdict(list)
    for (raw,phys),z in matrix.todok().items():slots[phys].append((raw,z))
    out={}
    for key,z in P.items():
        for raw,c in slots[key[axisnum]]:
            other=key[:axisnum]+(raw,)+key[axisnum+1:];out[other]=out.get(other,0)+c*z
    return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def tensor_pull(P,anti,source,Cphys):
    for j,A in enumerate([anti,source,Cphys.T,Cphys.T]):P=axis(P,A,j)
    return P
def load_current(role,w):
    folder=ROOT/'calculations/canonical_so10_auxiliary_source_g2_canonical';name=role+('_v6_result.json' if role=='primary' else '_v7_result.json');previous=folder/name
    record=auth(folder,name);base,path=old.load_known(role,w)
    assert record['updated_known_recipe']['previous_recipe_path']==str(path) and record['updated_known_recipe']['previous_recipe_sha256']==digest(path)
    current=old.materialize([old.rawrows(base),record['new_actual_g2_xi_pair_node']],w)
    assert len(current)==record['updated_known_terms']==145546
    assert old.rowhash(old.rawrows(current))==record['updated_known_sha256']=='5a559c6b0e7b8ac20ff0f4be5be9b9edd89d227569727755a4adf2d459184417'
    assert record['updated_known_Ward']==[] and record['updated_known_Ward_zero']
    return current,previous
def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('QUARTET_CANONICAL_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('QUARTET_CANONICAL_PEER_OR_UNDECLARED_READ '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();v=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return v
    data=auth(ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_pole',role+'_result.json');P=entries(data)
    w,forward,back,source,anti,Cinv,Cphys=stage('actual_three_field_frames',lambda:frames(role));physical=density(P,w,True)
    for i in range(45):
        for pre in ['JLp','ap','Cp']:
            n=pre+str(i);zero(w.add(w.replace(back[n],forward),w.scale(w.var(n),-1)),'ALL135_ROUNDTRIPS')
    if role=='primary':node=stage('full_graded_polynomial_substitution',lambda:canonical(w.replace(physical,back)))
    else:node=stage('four_separate_tensor_axis_contractions',lambda:density(tensor_pull(P,anti,source,Cphys),w,False))
    assert w.grade(node,(4,0,0));assert stage('complete_density_roundtrip',lambda:canonical(w.replace(node,forward)))==physical
    bad=stage('wrong_source_primal_map_control',lambda:density(tensor_pull(P,source,source,Cphys),w,False));bad_sensitive=bad!=node
    if bad_sensitive:assert canonical(w.replace(bad,forward))!=physical
    active={n for word in node for n,jets in word};assert all(not j and old.kind(n) in ['JL','a','C'] for word in node for n,j in word)
    starimages={n:canonical(w.replace({word:s.conjugate(z) for word,z in forward[n].items()},back)) for n in active}
    star=stage('complete_antilinear_reality',lambda:canonical(w.replace({word:s.conjugate(z) for word,z in node.items()},starimages)));assert star==node
    e3=read(PKG/f'frozen_a10_e3_symmetry/{role}.json');tb=e3['operators']['Tb_geometric_and_transported'];images={n:decode_typed(tb[n]) for n in active};nojets=all(not j for Q in images.values() for word in Q for n,j in word)
    method=(lambda Q,I:canonical(act(Q,w,I,role,0))) if role=='primary' else (lambda Q,I:old.even_action(Q,w,I))
    ward=stage('complete_local_H_Ward',lambda:method(node,images));no_source=stage('source_variation_omission',lambda:method(node,{n:({} if old.kind(n)=='JL' else Q) for n,Q in images.items()}))
    known,previous=stage('qualified_exact_current145546_recipe',lambda:load_current(role,w))
    existing={}
    for word,z in known.items():
        if len(word)==4 and not any(j for n,j in word) and sorted(old.kind(n) for n,j in word)==['C','C','JL','a']:
            c=s.Poly(num(z),g).coeff_monomial(g**4)
            if c:existing[word]=c
    assert not existing,'ACTUAL_G4_QUARTET_CLASS_ALREADY_PRESENT'
    node_rows=rows(node);updated=stage('exact_add_actual_node_once',lambda:old.materialize([old.rawrows(known),node_rows],w))
    exact_node={tuple(old.token(n) for n in row['word']):num(row['coefficient']) for row in node_rows}
    def exact_inverse_and_double():
        domain=updated.keys()|known.keys()|exact_node.keys()
        for key in domain:assert s.expand(num(updated.get(key,'0'))-num(known.get(key,'0'))-exact_node.get(key,0))==0,('EXACT_ADD_IDENTITY',key)
        restored=old.rowhash(old.rawrows(known))
        witness=next((key,z) for key,z in exact_node.items() if z!=0)
        assert s.expand((num(updated.get(witness[0],'0'))+witness[1])-num(updated.get(witness[0],'0')))==s.expand(witness[1])!=0
        return {'all_word_positions':len(domain),'inverse_exact_prior_sha256':restored,'double_addition_nonzero_word':[n for n,j in witness[0]],'double_minus_single_coefficient':str(witness[1])}
    addition_controls=stage('exact_all_word_inverse_and_double_controls',exact_inverse_and_double)
    result={'schema':'ACTUAL_G4_QUARTET_CANONICAL_V1','route':role,'physical_node_terms':len(physical),'physical_node':rows(physical),'canonical_node_terms':len(node),'new_actual_g4_quartet_node':node_rows,
        'full135_chart_roundtrips':True,'complete_density_roundtrip':True,'antilinear_C3_reality':True,'componentwise_complex_canonical_coefficients':sum(s.expand(z-s.conjugate(z))!=0 for z in node.values()),
        'wrong_source_primal_map_sensitive':bad_sensitive,'wrong_source_primal_map_node':rows(bad),'ghost_half_changes_actual_node':canonical(w.scale(node,s.Rational(1,2)))!=node,
        'all12_local_H_parameter_components_retained':True,'actual_Tb_images_have_no_jets':nojets,'new_local_H_Ward':rows(ward),'new_local_H_Ward_terms':len(ward),'source_variation_omission':rows(no_source),'source_omission_sensitive':no_source!=ward,
        'no_jet_images_make_test_local_not_only_rigid':nojets,'prior_known_terms':len(known),'prior_known_sha256':old.rowhash(old.rawrows(known)),'current_g4_quartet_class_absent_before_addition':True,
        'updated_known_terms':len(updated),'updated_known_sha256':old.rowhash(old.rawrows(updated)),'updated_known_Ward':rows(ward),'updated_known_Ward_zero':not bool(ward),'add_once_inverse_and_doublecount_checked':True,'exact_addition_controls':addition_controls,'preserved_incomplete_primaries':1,
        'Ward_zero_insensitive_to_omission_or_doubling_when_separately_invariant':not bool(ward),'updated_known_recipe':{'previous_recipe_path':str(previous),'previous_recipe_sha256':digest(previous),'previous_terms':145546,'add_actual_node_key_once':'new_actual_g4_quartet_node'},
        'old_loops_full_old_Ward_Q_or_new_Q_recomputed':False,'full_source_Slavnov_E5_A5_QAP_IR_finite_or_anomaly_claim':False,'authority_changed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
