# Canonical integration V2: preserve timeout, avoid repeated global controls

The V1 primary was killed by its300-second after-import timer during the
double-addition phase, with no complete RESULT. Its source,preparation,
controller and complete FAILED/exit124 capture remain immutable/unqualified.
No replay was launched. Intermediate stage messages do not qualify a result.

V2 retains the same actual coefficients,full transport/reality/local H checks,
exact staged prior recipe and full-engine updated functional. Resource limits
remain300seconds/sampled8GiB/350MiB available commit for each of two sequential
workers. This is a delegated engineering correction, not changed physics.

Replace repeated materialization of the entire functional for inverse/double
controls with exact polynomial identities on the union of all word positions:
updated-prior-node=0 everywhere. Once that identity is verified, subtraction
has exactly the prior canonical serialization and its authenticated hash.
Adding twice differs from adding once by the nonzero actual node; retain an
explicit nonzero word/coefficient witness. No cancellation is inferred from
byte equality alone. The main add-once result is still serialized by the same
qualified full engine. This avoids two redundant global simplifications.
Use expanded exact algebra for componentwise conjugation differences; every
coefficient is in the frozen radical polynomial field,with real g/widths.
No numeric tolerance or physical acceptance condition is changed.
