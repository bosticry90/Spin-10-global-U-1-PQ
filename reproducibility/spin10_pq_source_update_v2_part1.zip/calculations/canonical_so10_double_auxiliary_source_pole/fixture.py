"""Noncommuting finite-color comparator before any model tensor is released."""
from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
sp=importlib.util.spec_from_file_location('qualified_double_source_units',ROOT/'calculations/canonical_so10_double_auxiliary_source_units/units.py')
u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
s=u.s;engine=u.u;S=[s.Matrix([[1,2],[0,-1]]),s.Matrix([[2,-1],[3,1]])]
F=[s.Matrix([[1,0],[2,-1]]),s.Matrix([[0,3],[-2,1]])]
GENERIC={(0,0):s.Matrix([[1,2],[3,-1]]),(0,1):s.Matrix([[0,-2],[1,4]]),(1,0):s.Matrix([[-1,3],[2,0]]),(1,1):s.Matrix([[2,1],[-3,1]])}
KM=GENERIC;original_model=u.model
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def model(kind,first='a',second='a'):
    w,unused,target=original_model(kind,first,second);v=w.var
    if kind=='bubble':
        vertices=[w.add(*(w.scale(w.mul(v(f'uk_J{i}'),v(f'uk_a{a}'),v(f'uk_c{b}'),v(f'uk_C{k}')),KM[i,k][a,b]) for k in range(2) for a in range(2) for b in range(2) if KM[i,k][a,b])) for i in range(2)]
    else:
        sources=[w.add(*(w.scale(w.mul(v(f'uk_J{i}'),v(f'uk_L{a}'),v(f'uk_c{h}')),S[i][a,h]) for a in range(2) for h in range(2) if S[i][a,h])) for i in range(2)]
        ghosts=[w.add(*(w.scale(w.mul(w.D(v(f'uk_a{h}'),mu),v(f'uk_B{b}_{mu}'),v(f'uk_C{k}')),engine.ETA[mu]*F[k][h,b]) for h in range(2) for b in range(2) for mu in range(4) if F[k][h,b])) for k in range(2)]
        vertices=[sources[0],ghosts[0],ghosts[1],sources[1]]
    assert all(w.grade(P,(4,0,0)) for P in vertices)
    return w,vertices,target
engine.model=model

def predicted(Ks):
    bubble=2*s.trace(Ks[0,0]*Ks[1,1]-Ks[0,1]*Ks[1,0])
    box=-2*s.trace(S[0]*F[0]*S[1]*F[1]-S[0]*F[1]*S[1]*F[0])
    return {'bubble':bubble,'box':box,'total':bubble+box}

def main():
    global KM
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'fixture_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('COLOR_FIXTURE_WRITE')
        if p.suffix=='.json':raise PermissionError('COLOR_FIXTURE_MODEL_POLE_OR_PEER_READ')
    sys.addaudithook(guard);calc=engine.born if role=='primary' else engine.wick
    assert S[0]*F[0]!=F[0]*S[0]
    wrong_box=-2*s.trace(S[0]*S[1]*F[0]*F[1]-S[0]*S[1]*F[1]*F[0])
    assert wrong_box!=predicted(GENERIC)['box']
    cases={'generic':GENERIC,'identity':{(i,k):-S[i]*F[k] for i in range(2) for k in range(2)}}
    altered={key:A.copy() for key,A in cases['identity'].items()};altered[0,0][0,0]+=1;cases['altered_identity']=altered
    answers={};box_cache=None
    for name,Ks in cases.items():
        KM=Ks;ans={};details={}
        for kind in ['bubble','box']:
            print('STAGE '+role+' '+name+'_'+kind,flush=True)
            if kind=='box' and box_cache is not None:kernel,info=box_cache
            else:
                kernel,info=calc(kind)
                if kind=='box':box_cache=(kernel,info)
            ans[kind]=engine.pole(kernel);details[kind]={'kernel':str(kernel),**info}
        ans['total']=ans['bubble']+ans['box'];assert ans==predicted(Ks),(name,ans,predicted(Ks))
        answers[name]={'actual_poles':{k:str(z) for k,z in ans.items()},'trace_prediction':{k:str(z) for k,z in predicted(Ks).items()},'details':details}
    assert answers['generic']['actual_poles']=={'bubble':'-2','box':'28','total':'26'}
    assert answers['identity']['actual_poles']=={'bubble':'-28','box':'28','total':'0'}
    assert s.sympify(answers['altered_identity']['actual_poles']['total'])!=0
    result={'schema':'DOUBLE_SOURCE_NONCOMMUTING_TRACE_FIXTURE_V1','route':role,'cases':answers,'noncommuting_reordering_wrong_box':str(wrong_box),
      'extra_half_changes_nonzero_family':True,'all_actual_kernel_trace_predictions_equal':True,'generic_total_nonzero':True,'altered_identity_total_nonzero':True,'box_kernel_reused_only_under_K_variations':True,
      'physical_model_or_required_pole_read':False,'actual_Spin10_pole_calculated':False,'unknown_quantum_breaking_set_zero':False,'full_E5_A5':False,
      'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
