# Exact coefficient quarter-control interface repair

The original actual primary completed its source/GF extraction and then
terminated with exit1 at half_b=b/num(4). The exact Coefficient class supports
multiplication, not division by another Coefficient. No RESULT was exported;
the original actual run remains unqualified. Its source, preparation and full
native capture are preserved, and no original actual replay launched. The
successful DP1 fixture pair is unchanged and is not rerun.

actual_v2.py replaces that operation with b*num(Rational(1,4)), its exact
algebraic equivalent. No tensor, source/ghost order, matrix identity, pole
factor, control, physical input or target is changed. All actual matrix and
source support checks remain required. Freeze two sequential corrected actual
workers at the same300second/8GiB/350MiB limits under standing delegation;
use separately named preparations, captures and results. Preserve this failed
engineering attempt rather than treating its partial progress as qualification.

The question and authority ceiling in RECORD.md remain unchanged. A correction
to serialization/control arithmetic is not evidence for the cancellation
conjecture. Require completed paired corrected results and scoped validation.
