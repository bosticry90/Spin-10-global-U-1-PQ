# Actual double auxiliary-source pole: trace reduction and action test V1

Baseline133d233a9b4c7445694cd288e6f6078ba559d7be, clean; statev113/34of39.
Standing delegation authorizes this bounded continuation. V167's corrected
inventory has1016 actual auxiliary-source terms, no linear JLambda term,
27 candidate families and two survivors KL*KL/SL*SL*F*F atg4/explicit-xi0.
V166 establishes their ordered unit factors+2/-2, not actual cancellation.

Claim DP1: derive the finite-color trace formula for ordered J_i J_j C_k C_l,
i<j,k<l, common hbar*g10^4/(32*pi^2*epsilon_UV), no extra pair divisor.
S_i(j,h) is coefficient of J_i*Lambda_j*C_h after strippingg;
F_k(h,b) is coefficient of derivative(a_h)*B_b*C_k after strippingg, with
the full qualified gauge-fixing IBP current and all Lorentz copies retained;
K_ik(a,b) is coefficient of J_i*a_a*C_b*C_k after strippingg² and extracting
either ghost. Propose

  bubble = +2 Tr(K_ik K_jl - K_il K_jk),
  box    = -2 Tr(S_i F_k S_j F_l - S_i F_l S_j F_k).

PROOF.md derives index order by polarization of complete graded unit cycles.
Only finite color traces of ordinary coefficient matrices are cycled; no
regularized spacetime trace or commutation of matrices is assumed.

Before actual action data, test DP1 by full graded Hessians/Born and connected
Wick methods on the fixed two-color fixture:
S0=[[1,2],[0,-1]], S1=[[2,-1],[3,1]],
F0=[[1,0],[2,-1]], F1=[[0,3],[-2,1]],
K00=[[1,2],[3,-1]], K01=[[0,-2],[1,4]],
K10=[[-1,3],[2,0]], K11=[[2,1],[-3,1]].
The predicted bubble/box/total are -2,+28,+26. This nonzero comparator must
not accidentally validate only a desired zero. Then independently impose
K_ik=-S_i F_k in the fixture (predicted -28,+28,0), and change K00[0,0] by+1
as a nonzero-control perturbation. Keep the original generic matrices too.
Test a forbidden commuting reordering and an extra1/2 against actual kernels.
Fixture vertices use exactly the source/ghost ordering in the qualified units.

Two sequential DP1 workers:120seconds after imports,8GiB sampled private,
>=350MiB available commit. They may read no physical/group/known-pole or peer
JSON. Compare completed complete kernels/controls before releasing classical
action data. If DP1 fails, preserve it and stop the dependent branch.

Claim DP2, contingent on DP1 agreement: extract actual S,K,F from each own
qualified literal E2/BV action and real primal/dual charts. Primary uses literal
pullback; replay reconstructs source/GF vertices from physical10 commutators
and checks its own literals before the test. Include both external ghost
extractions, exact source names, all H/M source/ghost directions and complete
four-Lorentz/current qualification. No measured pole, required Slavnov tensor,
formal Ward completion or unknown breaking may generate these tensors.

Test the candidate identity K_ik+S_i F_k=0 at every45² ordered source/ghost
matrix position with exact sparse zero complements. It is a conjecture until
the literal tensors pass. If true, finite trace substitution proves the actual
sum zero in all980100 pair-color slots without dense enumeration. If false,
preserve the residual and report the actual pole unqualified unless a complete
direct trace calculation is separately frozen; never adjust a coefficient.

Seek an actual nonzero family anchor from diagonal pair projections and test
omission/double-count and half-K normalization there. If insensitive, report
that limitation rather than invent a nonzero control. Output complete S/K/F
matrices and the identity residual, plus explicit source/ghost domain and
canonical-chart consequence. Reuse graph/unit results by authenticated bytes,
not by rerunning their expensive predecessors. Keep actual family anchors
separate from the general all-slot proof and from fresh component integrations.

Freeze up to two sequential DP2 workers only after DP1 gate, each300seconds
after imports/8GiB (own exact chart/pullback and physical10 reconstruction),
>=350MiB available commit, then scoped validation. Complete native captures
precede qualification; preserve failed/unfinished sources and outputs. No
silent retry/resource expansion, source omission or truncated evidence.

Outcome ceiling: actual selected local logarithmic double-source coefficient,
or a preserved conjecture/method failure, not full source closure or quantum
restoration. Known Gamma92236 is not an input and changes only if a qualified
new nonzero node requires a separately scoped assessment. Unknown quantum
breaking, finite contacts, QAP/measure/IR, anomaly freedom and E5/A5 stay open.
Authorityv113/34of39, HB1/C5 blocked, C1_GS uncalculated, flavor paused; prior
failures, scalar warning and custodyexit2/seven preserved. No accepted physical
input/benchmark/foundation, protected evidence or remote change. Shared action,
chart/contraction helpers, UV assumptions and AI authorship limit independence.
Science/AI-capability objectives remain equal; education voluntary/nonblocking.
