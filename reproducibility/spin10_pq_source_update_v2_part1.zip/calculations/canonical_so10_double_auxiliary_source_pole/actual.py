"""Own literal action tensors and an exact all-support identity, no required pole."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import combinations
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import s,g,canonical,IDS,H,M
from a10_e5_mixed_contact import inputs as source_inputs
from a10_e5_auxiliary_next import vertices as gf_inputs
import a10_e5_quartic_algebra as ex
ZERO=ex.D.zero;num=ex.coefficient;TWO=num(2)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def put(A,key,z):
    A[key]=A.get(key,ZERO)+z
    if not A[key]:del A[key]

def add(*As):
    out={}
    for A in As:
        for ij,z in A.items():put(out,ij,z)
    return out

def mm(A,B):
    rows=defaultdict(list);out={}
    for (h,b),z in B.items():rows[h].append((b,z))
    for (a,h),z in A.items():
        for b,v in rows[h]:put(out,(a,b),z*v)
    return out

def indexed_product(A,B):
    rows=defaultdict(dict);cols=defaultdict(dict);out={}
    for (a,h),z in A.items():rows[a][h]=z
    for (h,b),z in B.items():cols[b][h]=z
    for a,left in rows.items():
        for b,right in cols.items():
            z=sum((left[h]*right[h] for h in left.keys()&right.keys()),ZERO)
            if z:out[a,b]=z
    return out

def trace2(A,B):return sum((z*B.get((b,a),ZERO) for (a,b),z in A.items()),ZERO)
def pack(A):return [[a,b,str(ex.D.to_sympy(z))] for (a,b),z in sorted(A.items())]
def family_value(A,i,j,k,l):return TWO*(trace2(A.get((i,k),{}),A.get((j,l),{}))-trace2(A.get((i,l),{}),A.get((j,k),{})))

def tensors(w,physical,PG):
    S=defaultdict(dict);K=defaultdict(dict);F=defaultdict(dict)
    for word,z in physical['JL3'].items():
        names=[n for n,j in word];assert all(not j for n,j in word)
        i=int(next(n[3:] for n in names if n.startswith('JLp')));a=int(next(n[2:] for n in names if n.startswith('Lp')));h=int(next(n[2:] for n in names if n.startswith('Cp')))
        assert i in M and a in M and h in H and s.Poly(z,g).monoms()==[(1,)]
        target=w.mul(w.var(f'JLp{i}'),w.var(f'Lp{a}'),w.var(f'Cp{h}'))
        put(S[i],(a,h),num(s.Poly(z,g).coeff_monomial(g)/target[word]))
    for word,z in physical['JL4'].items():
        names=[n for n,j in word];assert all(not j for n,j in word)
        i=int(next(n[3:] for n in names if n.startswith('JLp')));a=int(next(n[2:] for n in names if n.startswith('ap')));cc=[int(n[2:]) for n in names if n.startswith('Cp')]
        assert i in M and a in M and len(cc)==2 and len(set(cc))==2 and all(k in M for k in cc)
        assert s.Poly(z,g).monoms()==[(2,)]
        for k in cc:
            b=next(v for v in cc if v!=k);target=w.mul(w.var(f'JLp{i}'),w.var(f'ap{a}'),w.var(f'Cp{b}'),w.var(f'Cp{k}'))
            put(K[i,k],(a,b),num(s.Poly(z,g).coeff_monomial(g**2)/target[word]))
    counted_ghost_derivatives=0
    for word,z in PG.items():
        if not any(n.startswith('ap') for n,j in word):continue
        a=next(v for v in word if v[0].startswith('ap'));B=next(v for v in word if v[0].startswith('Bp'));C=next(v for v in word if v[0].startswith('Cp'))
        h=int(a[0][2:]);b=int(B[0][2:].split('_')[0]);k=int(C[0][2:])
        if h not in H or b not in M or k not in M:continue
        assert not B[1]
        if C[1]:counted_ghost_derivatives+=1;continue
        assert a[1]==(0,) and not C[1] and B[0].endswith('_0')
        target=w.mul(w.D(w.var(f'ap{h}'),0),w.var(f'Bp{b}_0'),w.var(f'Cp{k}'))
        put(F[k],(h,b),num(z/target[word]))
    assert counted_ghost_derivatives==0
    return dict(S),dict(K),dict(F)

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'actual_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('DOUBLE_SOURCE_ACTUAL_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('DOUBLE_SOURCE_ACTUAL_POLE_GAMMA_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);t=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-t});return value
    w,sub,back,source,anti,Cinv,Cphys,raw,physical,si=source_inputs(role,stage)
    other,V,maps,gi=gf_inputs(role,stage)
    assert maps[:4]==(source,anti,Cinv,Cphys)
    assert si['raw_counts']['JL3']==180 and si['raw_counts']['JL4']==836
    assert gi['all4_derivative_Lorentz_copies_checked']
    S,K,F=stage('actual_ordered_source_and_complete_internal_antighost_F',lambda:tensors(w,physical,V[0]))
    prod=mm if role=='primary' else indexed_product
    products={};residual={}
    for i in IDS:
        for k in IDS:
            SF=prod(S.get(i,{}),F.get(k,{}))
            if SF:products[i,k]=SF
            bad=add(K.get((i,k),{}),SF)
            if bad:residual[i,k]=bad
    identity=not bool(residual)
    anchor=None
    for i,j in combinations(M,2):
        b=family_value(K,i,j,i,j)
        if b:
            x=-family_value(products,i,j,i,j)
            half_b=b/num(4);anchor={'i':i,'j':j,'k':i,'l':j,'bubble':str(ex.D.to_sympy(b)),'box':str(ex.D.to_sympy(x)),
              'total':str(ex.D.to_sympy(b+x)),'omit_bubble':str(ex.D.to_sympy(x)),'omit_box':str(ex.D.to_sympy(b)),
              'double_bubble_total':str(ex.D.to_sympy(TWO*b+x)),'half_K_total':str(ex.D.to_sympy(half_b+x))}
            break
    packed={'S':[[i,pack(A)] for i,A in sorted(S.items())],
      'K':[[list(key),pack(A)] for key,A in sorted(K.items())],
      'F':[[k,pack(A)] for k,A in sorted(F.items())]}
    result={'schema':'ACTUAL_DOUBLE_AUXILIARY_SOURCE_POLE_CERTIFICATE_V1','route':role,
      'fixture_pair_agreement_before_action_release':True,'raw_source_counts':si['raw_counts'],'physical_source_counts':si['physical_counts'],
      'source_GF_maps_equal':True,'all4_F_Lorentz_and_IBP_current_qualification_retained':True,
      'actual_tensors':packed,'tensor_sha256':{tag:sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest() for tag,rows in packed.items()},
      'tensor_nonzero_coefficients':{tag:sum(len(rows) for key,rows in entries) for tag,entries in packed.items()},
      'all2025_source_ghost_matrix_positions_checked':True,'K_plus_SF_residual':[[list(key),pack(A)] for key,A in sorted(residual.items())],
      'actual_action_identity_K_equals_minus_SF':identity,'nonzero_actual_family_anchor':anchor,
      'raw_antisymmetric_pair_color_slots':980100,'structurally_permitted_upper_bound':278784,
      'all_pair_color_slots_zero_by_complete_trace_identity':identity,'actual_total_pole':[] if identity else None,
      'all_slots_individually_integrated':False,'zero_canonical_pole_follows_by_qualified_invertible_linear_charts':identity,
      'known_Gamma_required_pole_or_formal_completion_read':False,'unknown_quantum_breaking_set_zero':False,
      'finite_contact_normalization_adopted':False,'full_source_closure_or_E5_A5_or_anomaly_freedom':False,
      'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
