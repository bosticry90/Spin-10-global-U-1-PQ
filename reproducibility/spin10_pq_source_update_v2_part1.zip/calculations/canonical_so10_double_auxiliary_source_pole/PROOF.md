# Ordered color-trace reduction to be tested against the actual action

All external sources J_i and ghosts C_k are odd. Internal coefficient matrices
have ordinary commuting scalar entries, but different matrices need not
commute. Fix the external monomial J_i J_j C_k C_l, i<j,k<l, with no additional
pair divisor. The graph inventory leaves only the two complete proper-cycle
families; all other valence/coupling profiles are structurally excluded.

In a quartic source vertex select one of its ghosts as external. Define K_ik
in the literal order J_i a_a c_b C_k. This is also J_i C_k a_a c_b: moving
C_k across both odd internal fields gives two sign changes. The closed bubble
color walk for external pairing (i,k),(j,l) is

  sum_(a,b) K_ik(a,b) K_jl(b,a) = Tr(K_ik K_jl).

The V166 unit model with only K00(0,1)=K11(1,0)=1 has pole+2. Relabeling the
external ghosts gives the negative paired contraction. Reversing the two
source vertices is the cyclic counterpart, already counted in the unit's
full two-word Born/exponential normalization. Thus polarization gives

  B_ij;kl = 2[Tr(K_ik K_jl)-Tr(K_il K_jk)].

For the box, S_i(j,h) labels J_i Lambda_j c_h, and F_k(h,b) labels
derivative(a_h) B_b C_k, with its Lorentz metric coefficient removed. A cycle
has two mixed and two odd lines. Its color walk is

  sum_(a,h,b,r) S_i(a,h) F_k(h,b) S_j(b,r) F_l(r,a)
       = Tr(S_i F_k S_j F_l).

The V166 general-q model has exactly this walk nonzero and pole-2. Ghost
interchange supplies the opposite walk. Its complete four-vertex factor has
already counted all source/F vertex permutations; grouped S,S,F,F agrees with
the24 distinct-component words. Therefore

  X_ij;kl = -2[Tr(S_i F_k S_j F_l)-Tr(S_i F_l S_j F_k)].

Both expressions are antisymmetric under either external-pair interchange;
equal-index pairs vanish. Finite color cyclicity proves this statement without
moving odd external generators through unexpanded operator expressions.
The general-q unit proof supplies the mixed-propagator/Lorentz contraction
and UV factor, not a time-axis assumption for an untested integral.

Linearity in each source/ghost coefficient extends the oriented basis walks
to arbitrary finite matrices. A noncommuting fixture with overlapping internal
color supports must check this extension and normalization through actual
graded Hessian and Wick kernels before applying it to the physical action.

The candidate action relation K_ik=-S_i F_k would make the two color traces
identical: each K product has two minus signs. If, and only if, complete literal
extraction verifies that identity on the full stated support, B+X vanishes
for every pair-color slot. This is not an adopted constraint on couplings or
a pole fitted to restoration. A residual in the literal identity must remain
a residual. A nonzero family witness is compatible with a zero summed pole.
