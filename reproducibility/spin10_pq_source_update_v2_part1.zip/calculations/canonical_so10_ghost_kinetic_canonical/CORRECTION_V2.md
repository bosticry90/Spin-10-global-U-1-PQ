# V2 original coefficient-normalization pipeline

V1's complete physical/raw density and integration-by-parts checks completed,
then its prior-functional hash gate stopped. The source/controller/preparation
and full failed capture are preserved;it emitted no qualified result.

The proposed cache omitted the expansion step used by the qualified word
algebra before simplification. SymPy's resulting expression tree/string can
depend on that step. V2 reproduces the ORIGINAL pipeline:expand the complete
coefficient sum,canonical simplification,then the serializer's simplification.
It caches this exact pipeline by coefficient expression,not a different
scientific normal form. Print the prior word count/actual/expected hash before
the unchanged strict comparison. A remaining mismatch is still a stop.

No old hash,input,expected count or mathematical obligation is changed. Freeze
V2 and its exact inputs before a corrected120s-after-import/8GiB primary and
unused replay,with180s independent validation under standing delegation.
The unqualified V1 materialization cannot serve as prior evidence.
