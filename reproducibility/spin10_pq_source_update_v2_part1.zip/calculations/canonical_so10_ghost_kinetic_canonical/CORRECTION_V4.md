# Canonical integration correction V4

V3 completed the protected hash, one-addition/inverse, finite predecessor,
small g1/g2 projection, and graph-zero checks, but failed while evaluating
its final doubling control. The type-enumeration loop reused `after`, replacing
the compiled-node polynomial with a field-type string. No result was exported.

Preserve V3 source and its full failed capture. V4 renames that loop variable
and updates only its own versioned bindings. The actual doubled addition and
all previous gates remain required. Repeated failures are implementation and
planning evidence, not physics contradictions or successes. No unfinished
cache is resumed. Two fresh sequential workers retain 120 seconds after
imports/8 GiB each; independent validation retains 180 seconds/8 GiB.
