# Validation correction V2

The first independent verifier stopped before mathematical evaluation because
it required identical representative graph witnesses across both routes.
The qualified inventory deliberately uses different cyclic representatives;
the five profile descriptors agree, while their witness vertex order differs.
The complete failed validation capture and source are preserved.

V2 compares the full profile descriptors as a multiset, without requiring the
same witness representative. It still requires each route's full witness to
match its own authenticated inventory exactly and independently checks the
actual action/edges, source cycles, projection and every coefficient. No
profile or mathematical gate is removed. Native V4 results are reused; no
physics calculation is repeated. Retain 180-second/8-GiB validation limits.
