"""Exact ghost node integration and dependency-complete bilinear projection."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import combinations_with_replacement,product
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def load(n,p):
    sp=importlib.util.spec_from_file_location(n,p);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);return v
h=load('qualified_nonminimal_source_helpers',OUT.parent/'canonical_so10_nonminimal_source_closure/closure.py');m=h.m;l=h.l;ex=m.ex;s=m.s;read=m.read;digest=m.digest;PKG=m.PKG
from a10_e5_nonminimal_source import canonical,rows
g=m.g;xi=m.xi;eta=m.etaH
def auth(folder,name):
    p=OUT.parent/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def prior_tables(role):
    tables,unused,path=m.old.current_tables(role);d=auth('canonical_so10_dimensionful_source_canonical',role+'_result.json');tables.append(d['new_actual_g3_xi_dimensionful_node']);return tables,d,OUT.parent/'canonical_so10_dimensionful_source_canonical'/(role+'_result.json')
def current_tables(role):
    tables,prior,path=prior_tables(role);d=auth('canonical_so10_ghost_kinetic_canonical',role+'_v4_result.json');tables.append(d['new_actual_g2_ghost_kinetic_node']);return tables,d,OUT/(role+'_v4_result.json')
@lru_cache(None)
def num(z):return s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_H':eta,'reference_width_M':xi})
@lru_cache(None)
def sumtext(z):return str(s.simplify(s.simplify(s.expand(s.Add(*(num(v) for v in z))))))
def cm(A):return A.applyfunc(s.expand)
def combine(tables):
    by=defaultdict(list)
    for A in tables:
        for r in A:by[tuple(m.token(n) for n in r['word'])].append(r['coefficient'])
    return {key:v for key,z in by.items() if (v:=sumtext(tuple(sorted(z))))!='0'}
def rawrows(P):return [{'word':[m.serialize_token(t) for t in key],'coefficient':z} for key,z in sorted(P.items())]
def hashrows(A):return sha256(json.dumps(A,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def types(key):return tuple(sorted(h.kind(n) for n,j in key))
def ordered(P,i,j,mu):return m.mul({(0,((i,(mu,)),)):ex.coefficient(s.S.One)},{(0,((j,(mu,)),)):ex.coefficient(s.S.One)})
def anchor(P,L):
    E=m.EL_all(P,L);N={};theta=[{} for mu in range(4)]
    for i,A in E.items():m.merge_into(N,m.mul(m.elementary(i),A))
    for (gp,key),z in P.items():
        pos,n,js=next((p,n,j) for p,(n,j) in enumerate(key) if n in L);F={(gp,key[:pos]+key[pos+1:]):z}
        for cut,mu in enumerate(js):m.merge_into(theta[mu],m.scale(m.mul({(0,((n,js[cut+1:]),)):ex.coefficient(s.S.One)},m.Ds(F,js[:cut])),(-1)**cut))
    assert not m.add(P,m.scale(N,-1),*(m.scale(m.D(A,mu),-1) for mu,A in enumerate(theta)));return N,theta
def matrix(P):
    M={}
    for (gp,key),z in P.items():
        L=next((n,j) for n,j in key if h.kind(n)=='L');C=next((n,j) for n,j in key if h.kind(n)=='C');assert not L[1] and len(C[1])==2 and C[1][0]==C[1][1];ln=m.names[L[0]];i=int(ln[1:]);j=int(m.names[C[0]][1:]);mu=C[1][0]
        ex.put(M.setdefault(mu,{}),(i,j),m.cscale(z,1 if mu==0 else -1))
    assert all(M.get(mu,{})==M.get(0,{}) for mu in range(4));return M.get(0,{})
def pack(A):return [[i,j,l.text(z)] for (i,j),z in sorted(A.items())]
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v4.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,k in prep['input_sha256'].items():assert digest(Path(p))==k,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('GHOST_CANONICAL_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('GHOST_CANONICAL_UNDECLARED_OR_PEER '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    w=m.setup();d=auth('canonical_so10_ghost_kinetic_g2',role+'_v3_result.json');wframe,forward,back,source,anti,Cinv,Cphys=m.old.frames(role);M=s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in d['physical_pole_matrix']});rawM=s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in d['canonical_raw_pole_matrix']});assert all(s.expand(z)==0 for z in source*M*Cphys-rawM)
    ANTI=[('bar' if i<12 else 'ub')+str(i) for i in range(45)];physical={};direct={}
    for i,j in product(range(45),repeat=2):
        if M[i,j]:
            for mu in range(4):physical=wframe.add(physical,wframe.scale(wframe.mul(wframe.var('ap'+str(i),(mu,)),wframe.var('Cp'+str(j),(mu,))),g**2*M[i,j]*(1 if mu==0 else -1)))
        if rawM[i,j]:
            for mu in range(4):direct=wframe.add(direct,wframe.scale(wframe.mul(wframe.var(ANTI[i],(mu,)),wframe.var('C'+str(j),(mu,))),g**2*rawM[i,j]*(1 if mu==0 else -1)))
    physical=canonical(physical);direct=canonical(direct);pull=stage('complete_physical_density_and_raw_tensor_chart_comparison',lambda:canonical(wframe.replace(physical,back)));assert canonical(wframe.add(pull,wframe.scale(direct,-1)))=={};assert canonical(wframe.replace(direct,forward))==physical
    D=m.decode(rows(pull if role=='primary' else direct));node={};theta=[{} for mu in range(4)]
    for i,j in product(range(45),repeat=2):
        if not rawM[i,j]:continue
        z=ex.coefficient(rawM[i,j].subs({xi:ex.widthM,eta:ex.widthH}))
        for mu in range(4):
            A=m.index[ANTI[i]];C=m.index['C'+str(j)];value=m.cscale(z,1 if mu==0 else -1);unit=m.mul(m.elementary(A),{(0,((C,(mu,mu)),)):ex.coefficient(s.S.One)});cur=m.mul(m.elementary(A),{(0,((C,(mu,)),)):ex.coefficient(s.S.One)});m.merge_into(node,{(gp+2,key):m.cscale(m.cmul(v,value),-1) for (gp,key),v in unit.items()});m.merge_into(theta[mu],{(gp+2,key):m.cmul(v,value) for (gp,key),v in cur.items()})
    relation=m.add(D,m.scale(node,-1),*(m.scale(m.D(P,mu),-1) for mu,P in enumerate(theta)));assert not relation
    E=m.EL_all(m.add(D,m.scale(node,-1)),m.fields);assert not any(E.values());assert all(gp==2 and types(key)==('C','a') and sum(len(j) for n,j in key)==2 for gp,key in node);node_rows=rawrows({key:sumtext((str(g**gp*ex.D.to_sympy(z).subs({ex.widthM:xi,ex.widthH:eta})),)) for (gp,key),z in node.items()})
    tables,previous,path=prior_tables(role);old=stage('exact_cached_current_functional_materialization',lambda:combine(tables));oldhash=hashrows(rawrows(old));print('PRIOR_HASH '+json.dumps({'words':len(old),'actual':oldhash,'expected':previous['updated_known_sha256']},sort_keys=True),flush=True);assert len(old)==previous['updated_known_terms']==145978 and oldhash==previous['updated_known_sha256'],'PRIOR_FULL_FUNCTIONAL_HASH_OR_TYPE_MISMATCH'
    old_selected={key:z for key,z in old.items() if types(key)==('C','a') and sum(len(j) for n,j in key)==2};assert not old_selected,'ORDINARY_GHOST_KINETIC_CLASS_ALREADY_PRESENT'
    updated=stage('one_exact_addition_and_all_word_inverse',lambda:combine([rawrows(old),node_rows]));after=m.decode([r for r in rawrows(updated) if types(tuple(m.token(n) for n in r['word']))==('C','a') and sum(len(m.token(n)[1]) for n in r['word'])==2]);assert after==node and len(updated)==len(old)+len(node);assert combine([rawrows(updated),[{'word':r['word'],'coefficient':str(-num(r['coefficient']))} for r in node_rows]])==old
    assert {k:v for k,v in old.items() if any(n in m.sources for n,j in k)}=={k:v for k,v in updated.items() if any(n in m.sources for n,j in k)}
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');L={i for i in m.fields if h.kind(i)=='L'};C={i for i in m.fields if h.kind(i)=='C'};linear={};constant_terms=[]
    for n,data in e2['complete_columns'].items():
        for r in data['source_polynomial']:
            if not r['word']:constant_terms.append([n,r])
        linear[m.index[n]]=m.decode([r for r in data['source_polynomial'] if len(r['word'])==1 and m.token(r['word'][0])[0] in L|C])
    assert not constant_terms
    for a in range(45):
        for mu in range(4):assert linear[m.index[f'B{a}_{mu}']]==m.D(m.elementary(m.index['C'+str(a)]),mu)
        an=('bar' if a<12 else 'ub')+str(a);ln=('b' if a<12 else 'L')+str(a);assert linear[m.index[an]]==m.scale(m.elementary(m.index[ln]),-1)
    T={'B':(1,0,0,1),'x':(1,0,0,0),'A':(1,0,0,1),'C':(1,1,1,0),'a':(1,-1,1,0),'L':(2,0,0,0),'JB':(2,-1,1,1),'Jx':(2,-1,1,0),'JC':(2,-2,0,0),'Ja':(2,0,0,0),'JL':(1,-1,1,0)};Qsig=set()
    for i,P in linear.items():
        for (gp,key),z in P.items():
            n,js=key[0];cd=T[h.kind(i)][0]+1-T[h.kind(n)][0]-len(js);assert cd>=0
            Qsig.add((h.kind(i),h.kind(n),len(js),gp,cd))
    predecessor_types=set();type_routes=[]
    for a,b in combinations_with_replacement(sorted(T),2):
        da,ga,pa,va=T[a];db,gb,pb,vb=T[b];j=4-da-db
        if j<0 or ga+gb or (pa+pb)%2 or (va+vb+j)%2:continue
        for varied,other in [(a,b),(b,a)]:
            for before,output_kind,jq,gq,cd in Qsig:
                if before==varied and cd==0 and j+jq==2 and tuple(sorted([output_kind,other]))==('C','L'):
                    predecessor_types.add((tuple(sorted([a,b])),j));type_routes.append([list(sorted([a,b])),j,varied,output_kind,jq,gq])
    expected={(('C','a'),2),(('B','L'),1),(('C','JB'),1),(('C','JL'),2),(('Ja','L'),0)};assert predecessor_types==expected
    bilinear=m.decode([r for r in rawrows(updated) if len(r['word'])==2]);action=stage('small_complete_known_bilinear_Lambda_C_pole_projection',lambda:m.action(bilinear,linear,role));target=lambda gp:{key:z for key,z in action.items() if key[0]==gp and types(key[1])==('C','L') and sum(len(js) for n,js in key[1])==2};sector={};phys={};currents={}
    for gp in [1,2]:
        normalized,J=anchor(target(gp),L);A=matrix(normalized);Ap=cm(anti.T*s.SparseMatrix(45,45,{key:num(l.text(z)) for key,z in A.items()})*Cinv);sector[str(gp)]={'raw':l.rows(target(gp)),'anchored':l.rows(normalized),'matrix':pack(A),'physical_matrix':[[i,j,str(s.expand(z))] for (i,j),z in sorted(Ap.todok().items()) if s.expand(z)!=0]};currents[str(gp)]=list(map(l.rows,J));phys[gp]=Ap
    invp=OUT.parent/'canonical_so10_sourcefree_cycle_inventory'/(role+'_v2_result.json');rr=read(invp.parent/'validation_receipt.json');assert rr['input_sha256'][str(invp)]==digest(invp);inv=read(invp);vertices=inv['actual_sourcefree_vertices'];no_light=not any(r=='LH' for v in vertices.values() for whole in v['ports'] for r,j in whole);mixing=[r for r in inv['all_profiles'] if tuple(sorted('x' if q.startswith('X_') else q[0] for q,j in r['external_ports']))==('B','L') and r['total_external_jets']==1 and r['g']==2]
    # The actual antighost source has only its linear -Lambda and g*a*C terms.
    master=read(PKG/f'frozen_a10_bv_master/{role}.json');ja_couplings=set();ja_sources=0;SA=set()
    for r in master['source_polynomial']:
        ns=[m.token(n)[0] for n in r['word']]
        if any(h.kind(n)=='Ja' for n in ns):
            ja_sources+=1
            if len(ns)>2:
                assert types(tuple(m.token(n) for n in r['word']))==('C','Ja','a');ja_couplings|={gp for gp,z in m.coefficient_terms(r['coefficient'])}
                roles=[]
                for n in ns:
                    if h.kind(n)=='Ja':continue
                    name=m.names[n];idx=int(name[3:] if name.startswith('bar') else name[2:] if name.startswith('ub') else name[1:]);roles.append(h.kind(n)+('H' if idx<12 else 'M'))
                SA.add(tuple(sorted(roles)))
    assert ja_couplings=={1};jaLambda_g2_supported=[]
    # At coefficient dimension0 only two cubic vertices can support Ja*Lambda.
    # Source Ja ghost ports cannot connect to the g1 Lambda B B vertex.
    edges={tuple(e) for e in inv['actual_reference_edges']};ja_cycles=[]
    for name,v in vertices.items():
        if v['degree']!=3 or v['cd']!=0:continue
        for ports in v['ports']:
            if sum(r[0]=='L' for r,j in ports)!=1:continue
            inner=tuple(r for r,j in ports if r[0]!='L')
            for aa in SA:
                matched=any(all((aa[k],inner[1-k if swap else k]) in edges for k in range(2)) for swap in [False,True])
                ja_cycles.append({'source_ghost_ports':aa,'other_vertex':name,'other_internal_ports':inner,'total_g':1+v['g'],'matching':matched})
                if matched and 1+v['g']==2:jaLambda_g2_supported.append([aa,name,inner])
    assert not jaLambda_g2_supported and not any(r['matching'] for r in ja_cycles)
    missing_shape={'types':['B','L'],'jets':1,'g':2,'qualified_current_coefficient_present':any(types(key)==('B','L') and sum(len(js) for n,js in key)==1 and any(gp==2 for gp,z in m.coefficient_terms(ztext)) for key,ztext in old.items()),'supported_bare_profiles':mixing}
    assert not missing_shape['qualified_current_coefficient_present'];assert not sector['1']['anchored'],'COMPLETE_LOWER_G_COMPANION_CONTROL_FAILED';light=cm(phys[2][:12,:]);lightzero=not any(s.expand(z) for z in light);candidate=['a C /2 jets','Lambda B /1 jet','JB C /1 jet','JLambda C /2 jets','Ja Lambda /0 jets']
    controls={'reverse_derivative_current_breaks_density':bool(m.add(D,m.scale(node,-1),*(m.D(P,mu) for mu,P in enumerate(theta)))),'double_addition_changes_actual_class':combine([rawrows(updated),node_rows])!=updated and m.add(after,node)!=node,'omit_new_node_changes_bilinear_known_part':bool(m.action(node,linear,role)),'wrong_antighost_ghost_frame_changes_raw_matrix':cm(anti*M*Cinv-rawM)!=s.zeros(45),'source_projection_unchanged':True}
    result={'schema':'GHOST_KINETIC_CANONICAL_AND_BILINEAR_FRONTIER_V1','route':role,'scientific_disposition':'QUALIFIED_CANONICAL_GHOST_NODE_AND_BOUNDED_BILINEAR_DEPENDENCY_ASSESSMENT','new_actual_g2_ghost_kinetic_node':node_rows,'derivative_density':l.rows(D),'four_IBP_currents':list(map(l.rows,theta)),'all643_density_difference_Eulers_zero':True,'new_node_positions':len(node),'prior_known_terms':len(old),'prior_known_sha256':oldhash,'updated_known_terms':len(updated),'updated_known_sha256':hashrows(rawrows(updated)),'updated_known_recipe':{'previous_recipe_path':str(path),'previous_recipe_sha256':digest(path),'previous_terms':len(old),'add_once_key':'new_actual_g2_ghost_kinetic_node'},'source_projection_identical_all38_source_theorems_preserved':True,'bilinear_current_predecessor_classes':candidate,'finite_all_type_jet_predecessor_routes':sorted(type_routes),'physical508_Eulers_excluded_only_for_Lambda_C_target_by_dimension_support':True,'nonphysical_Q_has_no_constants':True,'actual_Ja_source_columns_checked':ja_sources,'Ja_Lambda_g2_has_no_matching_cycle':True,'Ja_Lambda_complete_two_vertex_matches':ja_cycles,'known_Lambda_C_relations':sector,'relation_boundary_currents':currents,'complete_lower_g_bilinear_control_zero':not sector['1']['anchored'],'ordinary_g2_light_auxiliary_mixing_structurally_absent':no_light,'ordinary_g2_light_auxiliary_complete_local_relation_zero':no_light and lightzero,'ordinary_g2_missing_mixing_input':missing_shape,'missing_mixing_contributes_plus_its_matrix_from_qB_equals_dC':True,'ordinary_g2_full_relation_not_qualified_without_missing_mixing':True,'required_mixing_not_fitted_or_adopted':True,'known_g2_heavy_remainder_not_a_quantum_anomaly_claim':True,'full_sourcefree_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'old_loops_or508_physical_Euler_values_evaluated':False,'controls':controls,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
