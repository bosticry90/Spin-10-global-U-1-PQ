# Canonical integration correction V3

V2 reproduced the protected 145978-word hash exactly, verified the frame
and derivative-current checks, and reached the small bilinear projection.
It failed at 102.63 seconds because its matrix expansion helper `cm` was
not defined. No result was exported or scientifically qualified.

Preserve both failed versions and complete captures. V3 supplies the
missing entrywise exact expansion helper, binds its prospective recipe
to the actual versioned result paths, and strengthens the doubling control
by compiling the extra addition. No measured coefficient, input, mathematical
requirement or resource bound changes. Two sequential workers retain the
120-second-after-import/8-GiB bounds; the unused independent validation
retains 180 seconds/8 GiB. This routine correction uses live AGENTS delegation.
