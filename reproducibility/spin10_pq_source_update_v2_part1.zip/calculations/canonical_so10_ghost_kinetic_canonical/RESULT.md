# Measured ghost pole integration and bilinear consistency frontier

This report is prospective until the paired V4 captures/results and the
independent validation receipt have completed. A report or byte hash alone
does not qualify its mathematics. Baseline: 9f27c445146800c16bac49f06ca9bbe2a6cd32be.

The actual ordinary g10^2 ghost kinetic logarithmic pole from V221 is now
represented by a compact additional canonical node. No new loop amplitude
is calculated in this increment. Its normalization remains
hbar/(32*pi^2*epsilon_UV), with g10^2 included in the node and reference
widths eta_H and xi retained as symbols.

Let H denote the already measured raw ordered ghost matrix. Integration by
parts gives D=g10^2*(partial a)^T H*(partial C),
N=-g10^2*a^T H*Box(C), and
theta_mu=g10^2*eta_mu*a^T H*(partial_mu C), with D=N+div(theta).
Both graded frame directions, all 2025 ordered matrix positions, all four
Lorentz copies and all 643 left Euler derivatives of D-N are checked.
No equations of motion, extra spatial metric or ghost half is introduced.

The added node contains 184 canonical positions. The original 145978-word
functional is reproduced in its original serializer with hash
0d7dfab391eaff50c398f97fee7953359d35f60cee007c44fb4485e0182138ef.
The new complete known recipe has 146162 words and hash
71d4546d3954ac2a461db3e7d8e235416ba3d4745033f85d8426639e762b412a.
The class was absent before integration; one exact inverse removal recovers
the prior functional. Actual omission/doubling controls detect changes.
Every source coefficient is identical, preserving the qualified 38-class
source local-pole result within its original scope. This does not establish
the source-free or complete regulated identity.

The dependency assessment concerns the source-free Lambda*C target with two
ordinary jets, ghost number one and density dimension five, at g10 and
g10^2, modulo displayed currents. A finite type/jet census of the literal
linear E2 columns gives exactly five predecessor classes:

- a*C with two jets;
- Lambda*B with one jet;
- JB*C with one jet;
- JLambda*C with two jets;
- Ja*Lambda without jets.

The actual nonphysical polynomial Q has no constant columns, excluding
higher-word inputs. Multiple-source terms cannot become source-free in one
variation. One-letter differentiated densities are total divergences.
The 508 physical Euler programs are retained: their physical field support
and a minimum input dimension of five exclude them only for this target.
Their values are not replayed or set globally to zero. The actual Ja source,
Lambda vertices and reference edges admit no two-cubic-vertex Ja*Lambda
cycle at this coefficient dimension; this is a support zero rather than
an inference from absence in the stored polynomial.

At lower order g10 the complete known bilinear relation vanishes modulo
its explicit four currents. Omitting the required JB predecessor breaks
that control. At ordinary g10^2 the known normalized matrix has 56 nonzero
physical positions, all in heavy auxiliary rows. The full relation is
unqualified because the actual ordinary g10^2 Lambda*B one-jet mixing pole
has not been measured. Five existing outward-log graph profiles support
it, from U*U and G3*U, retaining mixed propagators and both vector widths.
Its coefficient must be calculated from the action, not inferred from
the value that would cancel the known matrix. The sign with which this
missing ordered mixing matrix enters the relation is independently checked
on all 2025 tensor units.

The native blanket light-mixing absence test returns false: the literal
action contains A_H*B_H*Lambda_H. Its result therefore conservatively leaves
the complete light-row verdict unqualified, even though the known light
matrix is zero. The independent structural refinement must check the
actual reason this vertex cannot generate the missing bilinear loop:
A_H is an external background with no reference edge, and at fixed A_H
the vertex is linear in quantum B_H and has zero two-quantum Hessian.
The existing complete cycle inventory has no light-auxiliary mixing profile.
Only when these conditions and the known zero rows pass may the receipt
qualify the light rows in this bounded local-pole sector. The native false
flag remains unchanged and is not presented as an absent interaction.

Three unsuccessful primary executions are preserved. V1 failed the original
functional hash because the optimized serializer omitted an expansion step;
V2 reproduced that hash but failed on an undefined matrix helper; V3 reached
the completed small projections but failed its final control after a loop
variable shadowed a polynomial. None exported a qualified result. V4 retains
the original gates and strengthens the actual doubled-addition control.
These failures demonstrate avoidable implementation/planning weaknesses,
not quantum contradictions. No unfinished cache is resumed.

Workers are capped at 120 seconds after imports and 8 GiB sampled private
memory each; independent validation at 180 seconds and 8 GiB. Complete
captures record actual timings, process creation and available commit.
Distinct exact-radical/graded and ordinary-SymPy calculations check the
coefficients, currents, finite census and controls. They share action,
charts, prior measurements, software and AI authorship; they are not
independent scientists or expert validation. No fresh byte-identical replay
pair is claimed. Old loops and 508 physical Euler values are not rerun.

The smallest justified next action is an actual ordinary g10^2 auxiliary-
vector mixing calculation in the five existing profiles, followed by the
complete heavy-row relation if its prerequisites qualify. No full QGamma
expansion is justified here. Preserve the nonzero regulated Jacobian,
32 coincident-product maps, 128 source jets, physical programs and prior
residuals. Full E5/A5, QAP, finite contacts/Legendre, measure/IR and physical
viability remain unqualified. No input, scheme, benchmark, foundation or
scientific authority changes: 34/39, HB1/C5 blocked, flavor paused,
C1_GS uncomputed, quartet failure and scalar quantum warning retained,
historical custody exit 2/seven unresolved references. Education remains
voluntary and nonblocking; selective Lean work is no universal prerequisite.
