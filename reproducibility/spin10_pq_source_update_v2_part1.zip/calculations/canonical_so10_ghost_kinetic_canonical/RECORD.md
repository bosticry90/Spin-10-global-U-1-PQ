# Ordinary ghost canonical integration and bilinear dependency test V1

Question GKC1:can the qualified g2 ghost pole be integrated once into the
same canonical functional,and what does it enable in the local auxiliary-
ghost bilinear consistency sector? Baseline9f27c445146800c16bac49f06ca9bbe2a6cd32be.
Previous goal turn was verified progress:actual75-entry ghost pole plus
kinetic/UV normalization checks. No new loop or input is authorized by this
record;use the measured pole exactly,never fit its companion.

Freeze this record,worker/controller/source copies,own-role measured pole,
complete current recipe/receipts,E2/operator and frame data,and V220's actual
vertices/edge profiles before two sequential120s-after-import/8GiB workers,
350MiB minimum available commit,and one180s/8GiB independent validator.
Preserve complete captures/failures;resource exhaustion is incomplete.

Canonicalize physical g2 (d a)^T H (d C) in all4 Lorentz copies and all2025
ordered positions. Primary uses a full graded physical-density pullback;
replay uses the ordered raw matrix. Verify inverse charts,physical reality,
grade(4,0,even),symbolic widths and coupling degree. Use the explicit
current to identify it with -g2*a^T*H*Box(C),with no EOM. Check every left
Euler derivative of the density difference/current relation. Do not insert
another eta or ghost half. Original finite/power carriers stay separate.

Recover the exact current145978-word functional/hash from the immutable
recipe,add the intrinsic432-node once,and prove the ghost-kinetic class is
absent before adding it. Normalize repeated coefficient expressions once
instead of replaying the expensive whole symbolic compiler. The prior hash
must match in its original serializer. Add the new node once,validate every
changed word/zero complement,an exact inverse removal,and an active doubling
control. Retain an authenticated compact new recipe rather than editing old
evidence or storing another full functional. Source projection must remain
identical,so the38 source local-pole theorem remains a dependency,not a new
claim about the source-free identity.

Then examine the source-free target Lambda*C with two jets at ordersg1,g2,
modulo explicit ordinary currents,in the full-Cartesian local ring. Use
actual E2 coefficients and derive complete predecessors before any verdict.
Nonphysical polynomial Q columns have no constants;higher-word inputs cannot
produce a bilinear. Multiple-source inputs cannot become source free in one
variation. The508 physical Euler programs depend on physical B/A/x only;
a physical-source input already containing Lambda*C has dimension>=5 and
is excluded. Do not set those programs globally to zero or evaluate them.
One-letter derivative densities are total divergences,not new amplitudes.

The candidate predecessor classes are a*C(two jets),Lambda*B(one jet),
JB*C(one jet),JLambda*C(two jets),and Ja*Lambda(no jets). Confirm this by
finite type/jet enumeration and the literal linear Q columns. Prove the
Ja*Lambda g2 input has no proper-cycle support using its actual source
vertex and the Lambda-vertex/reference-edge census;absence from a polynomial
alone is insufficient. Retain any additional admissible predecessor found.

Use the actual measured lower-g mixing and source terms as a control. At g2,
the ordinary Lambda*B mixing coefficient is an UNMEASURED INPUT unless
qualified evidence is recovered. Report the known coefficient and its
linear dependence on that missing matrix,never adopt a value required for
cancellation. Check whether the light auxiliary rows have structural-zero
mixing from the actual bare vertices/Hessian;only then can those rows receive
a complete bounded local-pole verdict. A nonzero remainder is not an anomaly
or a complete regulated quantum contradiction. Keep all currents.

Independent routes compare exact full coefficients and use separate type/
derivative checks and actual cyclic witnesses. Controls flip derivative
current/orientation,omit/double the new node,misuse the ghost/antighost chart,
and omit a required predecessor. Shared action,old calculations,software
and AI author limit independence. No large QGamma expansion or508 Euler
value replay. Track B evaluates integration/completeness discipline.

Ceiling:qualified canonical coefficient integration and a precise bilinear
coverage/consistency result within the declared local pole ring. No scheme,
physical input,benchmark,foundation or protected promotion. Full E5/A5,QAP,
contacts/Legendre,regulated insertion/measure/IR and physical viability remain
unqualified. Preserve34/39,HB1/C5 block,flavor pause,C1_GS gap,scalar warning,
quartet failure,nonzero Jacobian,32 product maps,508 programs,prior residuals,
closed scalar routes,custodyexit2/seven. Education voluntary/nonblocking.
