# Actual ordinary ghost kinetic ultraviolet pole: prospective V1

Qualification requires the completed paired V3 captures,independent validation
and exact committed-byte checks. Two failed primaries,a failed preparation
with no child launch,and the successful non-loop kinetic diagnostic remain
preserved. This text alone is not acceptance or an adopted counterterm.

The selected ordinary g10^2 two-jet ghost pole is NONZERO. Its physical matrix
has75 nonzero entries and1950 zero positions in the complete ordered45x45
domain. All64 Lorentz/derivative-unit positions,all45 external directions,
both formal reference widths and both cyclic words are retained. The12
V220 role/derivative profiles all belong to this complete F*F family. The
leading g10*xi F*X logarithmic zero remains unchanged and was not reused here.

The measured ordered-density normalization is

    Gamma1_pole = hbar*g10^2/(32*pi^2*epsilon_UV)
                  * integral (d_mu a)^T H (d^mu C).

For one internal vector of width W,the four derivative-placement factors are

    u_aa = u_cc = (3-W)/2,
    u_ac = -(3+W)/2,
    u_ca = 3*(W-1)/2.

Here a/c label differentiation of the antighost/ghost at each literal vertex.
The actual color contraction is the sum over internal b of
u_aa F_a^b F_a^b+u_ac F_a^b F_c^b+u_ca F_c^b F_a^b+u_cc F_c^b F_c^b.
It is not a normalization fitted from the inactive local generator or a
Slavnov remainder. Primary graded Born and replay routed Wick/parameter
calculations agree;the independent validator derives the routed kernels and
UV moments and re-extracts literal F tensors from current gauge fixing.

With C_H=-sum_(h in H) f_h^2,and projectors P_H,P_M in the qualified physical
ghost frame,the same action-derived matrix has the compact representation

    H = (W_H-3)/2 C_H P_H
        + [(2 W_H-W_M-3) C_H +4(W_M-3)I] P_M.

The validator must check this reduction against every actual matrix entry.
W_H/W_M are retained reference-width symbols;writing them eta_H/xi is the
existing declared substitution,not a newly adopted gauge. The canonical raw
matrix uses the antighost and ghost kinetic charts and has an exact inverse
roundtrip. All12 constant-H commutators and physical coefficient reality pass
within this projection. This is not a complete local quantum Ward identity.

The tree-level bridge matters for the overall sign. Literal gauge fixing
gives the physical ordered density +d_mu a d^mu C. Its antighost Euler
derivative is -Box C and its a(-p)C(p) Fourier coefficient is +p_squared I.
The graded Hessian has K[C,a]=-p_squared,K[a,C]=+p_squared and inverse
G[C,a]=+1/p_squared,G[a,C]=-1/p_squared. These are different descriptions
of the same qualified convention. V1 conflated the differential/Fourier
signs;V2's corrected bridge then failed a structural SymPy matrix comparison.
The frozen diagnostic showed exact zero residuals;V3 uses exact residuals.
Neither failure altered the physical action or supplied a qualified pole.

The pole is isolated using homogeneous degree-4 UV terms on k_E^2>R_UV^2>0
and independently shifted parameter moments at nonexceptional momentum.
For example,the p_squared UV logarithm of the one-denominator massless
integral cancels in the angular expansion;its power/finite parts are not
declared zero. The Minkowski radial multiplier is2I in the stated1/(32pi^2)
units. No whole scaleless integral,zero-momentum value or finite IR amplitude
is substituted for the kinetic pole.

Controls omit H/M vector sectors,ghost derivative placement,one cyclic word,
or transverse/longitudinal propagator terms,and use an inconsistent Euclidean
moment. Each exposes a change. Reversing ordered external odd variables
reverses a nonzero unit. No extra ghost half was inserted. Actual widths,
kinetic metrics and source evaluation conventions stay fixed.

Shared old action/kinetic/tensor proofs,software and AI author limit
independence. The native tensor archive also stores unrelated gauge-source
pole columns;the contraction selects its actual F_a/F_c and classical
geometry,not those columns. Independent literal-F recovery checks that
input link. No current known Gamma or primitive companion is used to choose
the new coefficient. This is bounded computational corroboration,not external
expert validation or a fresh same-command byte-identical replay pair.

Next:canonically integrate this measured coefficient only after all word,
coupling,frame,derivative-current and double-count checks. Then update the
source-free evidence frontier and identify the next complete consistency
relation it enables. This result is not the full source-free functional.
It does not repair the prior quartet normalization or the exploratory
scalar point's large quantum corrections.

No scheme,physical input,benchmark or foundation adopted. All source/local
primitive/real-map results,nonzero Jacobian,32 nonlinear product obligations,
508 physical Euler programs,prior residuals/failures and closed scalar routes
preserved. Full E5/A5,QAP,contacts/Legendre,measure/IR and physical viability
unqualified. Authority34/39,HB1/C5 blocked,flavor paused,C1_GS uncomputed,
custodyexit2/seven unchanged. Completed receipts own commands,resources,
hashes and failure classifications. Track B tests cheap kinetic bridges,
UV/IR discipline and avoidance of transferring a zero across coupling orders.
