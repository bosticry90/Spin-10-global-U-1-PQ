# Ordinary g2 ghost kinetic pole V1

Question GKG2:what is the actual source-free two-jet ghost ultraviolet pole
at orderg10^2? Baseline7e95cec5d20277722b361442f3be895811c7087f. Previous
goal turn was verified progress:complete outward bare cycle envelope and
one F*F ordinary-ghost family,not a new coefficient. Current recipe/V220,
the leading ghost-companion contract,source-vertex record and targeted rg
search in calculations/docs/M08 Python and Markdown identify no qualified
ordinary g2 kinetic coefficient. The old g*xi zero and mixed-contact classical
g0 kinetic map are different scopes. This is an evidence search,not a proof
that no historical copy exists anywhere.

Freeze worker/controller/source copies,actual role-specific F tensors and
frame/kinetic bridges,the12 supported V220 profiles and qualified literal
action/E2/reference inputs before computation. Two sequential120s-after-
import/8GiB workers,350MiB minimum available commit,and one180s/8GiB
independent validator. Full captures and failures,no truncation or silent
resource expansion. No Gamma,primitive companion,required Slavnov coefficient
or peer answer may be read by the calculation. Calculate elementary units
before releasing actual group tensors.

Scope:unchanged bosonic gauge-fixed action,full-Cartesian x,zero external
backgrounds/sources only for this two-point projection,nonexceptional
external momentum. All45 antighost/ghost coordinates and four Lorentz copies;
formal independent reference widths W_H,W_M later written eta_H,xi. No
physical gauge,input or scheme adopted. Positive-dimensional insertions and
single-external-vertex derivative tadpoles are excluded by V220's actual UV/
momentum proof;their power/finite sectors remain distinct. The ordinary
F*F family must not inherit the lower g*xi mixed-propagator zero.

Use the literal IBP-complete vertex
 (d_mu a)^T F_a^b B_b^mu C + a^T F_c^b B_b^mu d_mu C.
Qualified all4-copy/current proof supplies F_a,F_c,not a desired pole. Retain
the physical ghost principal metric/inverse and ordinary B-B propagator,
including its longitudinal width term. Build four left/right derivative
units aa,ac,ca,cc. Primary uses graded Hessian/Born words and second-order
external Taylor/UV-annulus angular moments. Replay uses routed Wick pairings
and independently shifted Feynman-parameter homogeneous residues. Keep both
vertex orders,odd signs,external ordering and all16 Lorentz Taylor entries.

Contract actual F tensors on all2025 ordered external positions. Compare
sparse matrix multiplication with explicit internal index contraction.
Transport the actual density to canonical raw coordinates with the correct
antighost/ghost kinetic charts. Verify the negative-unit physical kinetic
symbol from the literal g0 gauge fixing;do not assume a bare unit canonical
metric or insert an extra ghost1/2. Local constant H covariance and physical
coefficient reality are checks,not full quantum Ward identities.

Normalization:hbar/(32*pi^2*epsilon_UV),Minkowski bubble I/(16*pi^2).
Extract the local p_mu p_nu coefficient in ordered a(-p) C(p),equivalently
the d_mu a d^mu C density. Separate UV annulus k_E^2>R_UV^2>0/IR handling;
no whole scaleless integral or zero external momentum supplies the pole.
Only the logarithmic coefficient is claimed,not finite/physical IR matching.

Meaningful controls omit one cyclic word,reverse odd order,remove transverse
or longitudinal pieces,use an inconsistent Euclidean moment,and omit H/M
vector sectors/ghost derivative placement. Preserve any insensitive control.
Independent validation reconstructs the units,signs,UV moments,all color
entries and actual metric/frame/profiles from frozen data. Shared action,
old tensor/kinetic proofs,software and AI author limit independence.

Outcome:qualified actual ordinary kinetic pole or qualified zero,an exact
input/normalization discrepancy,or bounded incomplete work. No coefficient
fit or automatic physical interpretation. Canonical functional integration
requires its own byte/double-count/current checks;do not silently merge it.
No new normalization primitive or scheme is adopted. Preserve sourcefree
residual72642,508 physical programs,nonzero Jacobian/product obligations,
all source/primitive results,historical quartet/scalar failures,authority34/39,
HB1/C5 block,flavor pause,C1_GS gap,custodyexit2/seven. Full E5/A5,QAP,
contacts/Legendre,measure/IR and physical viability remain unqualified.
