"""Actual ordinary ghost self-energy: full graded units then literal color."""
from pathlib import Path
from hashlib import sha256
from itertools import product
from functools import lru_cache
import importlib.util,json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,s,ETA,canonical,cm,clean,decode_typed
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace
from a10_e5_measured_functional_v3 import frames
q=list(s.symbols('gkg_k0:4',real=True));p=list(s.symbols('gkg_p0:4',real=True));W=s.Symbol('gkg_W',real=True);K,R=s.symbols('gkg_Kden gkg_Rden',nonzero=True);Q=sum(ETA[i]*q[i]**2 for i in range(4));r=[q[i]-p[i] for i in range(4)];ZERO={v:0 for v in p};WH,WM=s.symbols('reference_width_H reference_width_M',real=True)
read=lambda f:json.loads(f.read_bytes());digest=lambda f:sha256(f.read_bytes()).hexdigest()
def cancel(z):return s.cancel(s.expand(z))
def setup(a,b):
    w=alphabet();w.fields={**{f'gk_BL{i}':(1,0,0) for i in range(4)},**{f'gk_BR{i}':(1,0,0) for i in range(4)},'gk_c':(1,1,1),'gk_a':(1,-1,1)};w.grades=w.fields;w.external={};w.p={n:t[2] for n,t in w.fields.items()};w.pairs=[]
    register(w,'gk_ae',(1,-1,1));register(w,'gk_ce',(1,1,1));v=w.var
    A=w.add(*(w.scale(w.mul(v('gk_ae',(mu,) if a=='a' else ()),v(f'gk_BL{mu}'),v('gk_c',(mu,) if a=='c' else ())),ETA[mu]) for mu in range(4)))
    B=w.add(*(w.scale(w.mul(v('gk_a',(mu,) if b=='a' else ()),v(f'gk_BR{mu}'),v('gk_ce',(mu,) if b=='c' else ())),ETA[mu]) for mu in range(4)))
    momenta={**{f'gk_BL{i}':q for i in range(4)},**{f'gk_BR{i}':[-x for x in q] for i in range(4)},'gk_c':[-x for x in r],'gk_a':r,'gk_ae':[-x for x in p],'gk_ce':p}
    def fourier(P):
        out={}
        for word,z in P.items():
            assert all(s.expand(sum(momenta[n][mu] for n,j in word))==0 for mu in range(4));key=tuple((n,()) for n,j in word);phase=s.prod(s.I*momenta[n][mu] for n,j in word for mu in j);out[key]=out.get(key,0)+z*phase
        return canonical(out)
    return w,[fourier(A),fourier(B)],w.mul(v('gk_ae'),v('gk_ce'))
def green(a,b,variant=None):
    if a.startswith('gk_B') and b.startswith('gk_B') and a[:5]!=b[:5]:
        mu,nu=int(a[-1]),int(b[-1]);trans=-ETA[mu]*int(mu==nu)/K;long=(1-W)*q[mu]*q[nu]/K**2
        return long if variant=='omit_transverse' else trans if variant=='omit_longitudinal' else trans+long
    if (a,b)==('gk_c','gk_a'):return 1/R
    if (a,b)==('gk_a','gk_c'):return -1/R
    return s.S.Zero
def born(a,b,variant=None):
    w,V,target=setup(a,b);names=list(w.fields);par=[w.p[n] for n in names];word,sg=next(iter(target.items()));G={(i,j):{():z} for i,n in enumerate(names) for j,k in enumerate(names) if (z:=green(n,k,variant))};H=[]
    for P in V:
        A=Fourier_vertex(P,w,'primary',q,q,{});H.append({(i,j):cell for i,row in enumerate(A) for j,cell in enumerate(row) if cell})
    parts=[]
    for A,B in [H,H[::-1]]:parts.append(cancel(-s.I*trace(multiply(multiply(multiply(G,A,w),G,w),B,w),w,par).get(word,0)/(4*sg)))
    return cancel(sum(parts)),parts
def wick(a,b,variant=None):
    w,V,target=setup(a,b);word,sg=next(iter(target.items()));ext={'gk_ae','gk_ce'}
    def pair(legs):
        if not legs:return s.S.One
        first=legs[0];out=0
        for i,other in enumerate(legs[1:],1):
            G=green(first,other,variant)
            if G:out+=(-1)**(w.p[first]*sum(w.p[n] for n in legs[1:i]))*s.I*G*pair(legs[1:i]+legs[i+1:])
        return out
    parts=[]
    for L,T in [V,V[::-1]]:
        out=0
        for left,z in L.items():
            for right,v in T.items():
                full=left+right;outer=[n for n,j in full if n in ext];inside=[n for n,j in full if n not in ext];cross=(-1)**sum(w.p[n]*w.p[k] for i,(n,j) in enumerate(full) if n not in ext for k,js in full[i+1:] if k in ext);outer_sign=w.mul(*(w.var(n) for n in outer)).get(word,0)/sg;out+=z*v*cross*outer_sign*pair(inside)
        parts.append(cancel(-s.I*s.I**2*out/2))
    assert cancel(parts[0]-parts[1])==0;return cancel(sum(parts)),parts
def average(P,k,radial,wrong=False):
    total=0
    for term in s.Add.make_args(s.expand(P)):
        powers=term.as_powers_dict();ks=[int(powers.get(v,0)) for v in k];rp=int(powers.get(radial,0));assert sum(ks)+2*rp==-4,(ks,rp,term)
        if any(n%2 for n in ks):continue
        n=sum(ks)//2;weight=s.S.One
        for j in range(n):weight/=4+2*j
        for mu,a in enumerate(ks):weight*=s.factorial2(a-1) if a else 1;weight*=1 if wrong else ETA[mu]**(a//2)
        total+=term/s.prod(v**a for v,a in zip(k,ks))/radial**rp*weight
    return s.expand(2*s.I*total)
def derivative(P,mu):return s.diff(P,p[mu])-2*ETA[mu]*(q[mu]-p[mu])*s.diff(P,R)
def taylor(P,wrong=False):
    out=[]
    for mu,nu in product(range(4),repeat=2):
        A=cancel((derivative(derivative(P,mu),nu)/2).subs(ZERO).subs(R,K));out.append([mu,nu,s.factor(average(s.expand(A),q,K,wrong))])
    return out
def parameter(P,wrong=False):
    t=s.Symbol('gkg_t',real=True);ell=list(s.symbols('gkg_l0:4',real=True));L2=s.Symbol('gkg_Lden',nonzero=True);N=s.expand(cancel(P*K**2*R).subs(K,Q));assert not N.has(R,K);shift=s.expand(N.subs({q[i]:ell[i]+(1-t)*p[i] for i in range(4)},simultaneous=True));N0=s.expand(shift.subs(ZERO));out=[]
    for mu,nu in product(range(4),repeat=2):
        A=s.diff(shift,p[mu],p[nu]).subs(ZERO)/2/L2**3
        if mu==nu:A-=3*t*(1-t)*ETA[mu]*N0/L2**4
        val=average(s.expand(A),ell,L2,wrong);out.append([mu,nu,s.factor(s.integrate(2*t*val,(t,0,1)))])
    return out
def unpack(A):return s.SparseMatrix(45,45,{(i,j):s.sympify(z) for i,j,z in A})
def pack(A):return [[i,j,str(s.expand(z))] for (i,j),z in sorted(A.todok().items()) if s.expand(z)!=0]
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v3.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('ORDINARY_GHOST_POLE_WRITE')
        if f.suffix=='.json' and str(f.resolve()) not in allowed:raise PermissionError('ORDINARY_GHOST_POLE_PREDICTION_PEER_OR_UNDECLARED '+str(f))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    w,forward,back,source,anti,Cinv,Cphys=stage('actual_ghost_kinetic_charts',lambda:frames(role));e2=read(PKG/f'frozen_a10_e2_transport/{role}.json');raw=decode_typed(e2['gauge_fixing_density']);P0=canonical({word:s.Poly(z,s.Symbol('g10',real=True)).coeff_monomial(1) for word,z in raw.items() if len(word)==2 and sum(len(j) for n,j in word)==2 and any(n.startswith(('bar','ub')) for n,j in word) and any(n.startswith('C') for n,j in word)});physical=canonical(w.replace(P0,forward));kin=s.zeros(45)
    for word,z in physical.items():
        a=next(v for v in word if v[0].startswith('ap'));C=next(v for v in word if v[0].startswith('Cp'));i,j=int(a[0][2:]),int(C[0][2:]);assert sum(len(js) for n,js in word)==2;ordered=w.mul(w.var(a[0],a[1]),w.var(C[0],C[1]));phase=s.prod(-s.I*p[mu] for mu in a[1])*s.prod(s.I*p[mu] for mu in C[1]);kin[i,j]+=z/ordered[word]*phase
    p2=sum(ETA[mu]*p[mu]**2 for mu in range(4));assert cm(kin-p2*s.eye(45))==s.zeros(45),'ACTUAL_ORDERED_FOURIER_GHOST_DENSITY_NOT_PLUS_IDENTITY'
    for i in range(45):
        E=canonical(w.EL(physical,'ap'+str(i)));expected=w.add(*(w.scale(w.var('Cp'+str(i),(mu,mu)),-ETA[mu]) for mu in range(4)));assert canonical(w.add(E,w.scale(expected,-1)))=={}
    toy=alphabet();toy.fields={'kg_c':(1,1,1),'kg_a':(1,-1,1)};toy.grades=toy.fields;toy.pairs=[];toy.external={};toy.p={n:t[2] for n,t in toy.fields.items()};V=toy.add(*(toy.scale(toy.mul(toy.var('kg_a',(mu,)),toy.var('kg_c',(mu,))),ETA[mu]) for mu in range(4)));HH=Fourier_vertex(V,toy,role,p,p,{});HH=s.Matrix([[cell.get((),0) for cell in row] for row in HH]);assert cm(HH-s.Matrix([[0,-p2],[p2,0]]))==s.zeros(2);GG=s.Matrix([[0,1/p2],[-1/p2,0]]);assert cm(HH*GG-s.eye(2))==cm(GG*HH-s.eye(2))==s.zeros(2)
    method=born if role=='primary' else wick;residue=taylor if role=='primary' else parameter;units={};kernels={};orders={};tensors={}
    for a,b in product('ac',repeat=2):
        key=a+b;P,parts=stage('complete_graded_FF_unit_'+key,lambda a=a,b=b:method(a,b));T=stage('all16_second_Taylor_or_parameter_residues_'+key,lambda P=P:residue(P));u=T[0][2];assert all(s.expand(z-(ETA[mu]*u if mu==nu else 0))==0 for mu,nu,z in T);units[key]=u;kernels[key]=str(P);orders[key]=list(map(str,parts));tensors[key]=[[mu,nu,str(z)] for mu,nu,z in T]
    assert any(units.values());P,_=method('a','a');base=units['aa'];controls={'omit_one_order_halves_aa':s.expand(residue(s.sympify(orders['aa'][0],locals={str(x):x for x in [K,R,W,*q,*p]}))[0][2]-base/2)==0,'reverse_external_odd_order_changes_nonzero_aa':base!=0,'wrong_Euclidean_angular_average_detected':residue(P,True)!=residue(P)}
    for variant in ['omit_transverse','omit_longitudinal']:
        z=residue(method('a','a',variant)[0])[0][2];controls[variant]={'pole':str(z),'changes_result':s.expand(z-base)!=0}
    print('UNITS '+json.dumps({'units':{k:str(z) for k,z in units.items()},'kernels':kernels,'orders':orders,'all64':tensors},sort_keys=True,separators=(',',':')),flush=True)
    # Release actual group data only after all elementary units are calculated.
    ip=OUT.parent/'canonical_so10_sourcefree_cycle_inventory'/(role+'_v2_result.json');ir=read(ip.parent/'validation_receipt.json');assert ir['input_sha256'][str(ip)]==digest(ip);profiles=read(ip)['ordinary_ghost_twojet_g2_unreconciled_profiles'];assert len(profiles)==12 and all(row['g']==2 and row['explicit_vertex_xi']==0 and row['total_external_jets']==2 and row['vertex_family']==['F_g1_e0_c0_n3_j1']*2 for row in profiles)
    cp=OUT.parent/'canonical_so10_gauge_source_g2_color'/(role+'_result.json');cr=read(cp.parent/'validation_receipt.json');assert cr['input_sha256'][str(cp)]==digest(cp);oldprep=read(cp.parent/'preparation.json')
    for name in [PKG/f'frozen_a10_e2_transport/{role}.json',PKG/f'frozen_a10_bv_master/{role}.json',PKG/f'frozen_a10_physical_reconciliation/full_{role}.json']:assert oldprep['input_sha256'][str(name)]==digest(name)
    data=read(cp);Fa=list(map(unpack,data['Fa_tensors']));Fc=list(map(unpack,data['Fc_tensors']));assert data['GF_inventory']['all4_derivative_Lorentz_copies_checked'];H=s.zeros(45);subparts={}
    for name,ids in [('H',range(12)),('M',range(12,45))]:
        local=s.zeros(45);wb=WH if name=='H' else WM
        for b in ids:
            U={k:s.expand(z.subs(W,wb)) for k,z in units.items()};A,B=Fa[b],Fc[b]
            if role=='primary':local+=U['aa']*A*A+U['ac']*A*B+U['ca']*B*A+U['cc']*B*B
            else:
                for i,k in product(range(45),repeat=2):local[i,k]+=sum(U['aa']*A[i,j]*A[j,k]+U['ac']*A[i,j]*B[j,k]+U['ca']*B[i,j]*A[j,k]+U['cc']*B[i,j]*B[j,k] for j in range(45) if A[i,j] or B[i,j])
        local=cm(local);subparts[name]=pack(local);H+=local
    H=cm(H);assert any(H);assert all(s.expand(z-s.conjugate(z))==0 and not z.has(s.Float) for z in H)
    f=list(map(unpack,data['source_tensors']));assert all(cm(f[h]*H-H*f[h])==s.zeros(45) for h in range(12))
    canonicalH=cm(source*H*Cphys);inverse=cm(anti.T*canonicalH*Cinv);assert inverse==H
    controls['omit_H_vector_sector_changes_matrix']=unpack(subparts['M'])!=H;controls['omit_M_vector_sector_changes_matrix']=unpack(subparts['H'])!=H;controls['omit_external_ghost_derivative_changes_matrix']=cm(sum((units['aa'].subs(W,WH if b<12 else WM)*Fa[b]*Fa[b] for b in range(45)),s.zeros(45)))!=H
    eps=s.Symbol('gkg_eps',positive=True);mass=s.Symbol('gkg_IR_squared',positive=True);assert s.limit(eps*s.gamma(eps)*mass**(-eps),eps,0)==1
    result={'schema':'ACTUAL_ORDINARY_G2_GHOST_KINETIC_POLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_SELECTED_ORDINARY_G2_GHOST_KINETIC_UV_POLE','four_derivative_units':{k:str(v) for k,v in units.items()},'all64_Lorentz_Taylor_positions':tensors,'all_unit_kernels':kernels,'both_ordered_kernels':orders,'actual_Fa_Fc_from_unchanged_GF_authenticated':True,'all4_literal_GF_Lorentz_copies_checked':True,'physical_ghost_principal_symbol':'+p_squared * I_45 in ordered a(-p)C(p); EL_a=-Box C; graded K[C,a]=-p_squared; G[C,a]=+1/p_squared; literal all2025 entries','physical_pole_matrix':pack(H),'canonical_raw_pole_matrix':pack(canonicalH),'H_and_M_pole_parts':subparts,'complete_ordered_ghost_positions':2025,'zero_complement':2025-len(H.todok()),'all12_constant_H_covariance_and_physical_reality':True,'canonical_antighost_ghost_inverse_roundtrip':True,'normalization':'hbar*g10^2/(32*pi^2*epsilon_UV) * (d_mu a)^T H (d^mu C); physical ordered ghost inverse symbol is +I/p_squared','width_substitution':{'reference_width_H':'eta_H','reference_width_M':'xi'},'UV_domain':'homogeneous degree-4 residue on positive UV annulus k_E_squared>R_UV_squared>0; nonexceptional external momentum','Minkowski_radial_multiplier':'2*I in 1/(32*pi^2*epsilon_UV) units','positive_IR_reference_radial_residue':1,'finite_IR_or_whole_scaleless_zero_inferred':False,'known_Gamma_primitive_required_identity_or_peer_answer_read':False,'current_functional_modified_or_new_scheme_adopted':False,'full_sourcefree_Slavnov_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'controls':controls,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
