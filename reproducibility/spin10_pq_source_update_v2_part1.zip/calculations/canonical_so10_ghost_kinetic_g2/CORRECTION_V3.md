# V3 exact graded-reference matrix comparison

V2 passed the literal all2025 Fourier-density and45 Euler-operator checks,
then stopped at the tiny graded-reference comparison before rerunning any
loop. Its sources/preparation/controller/full failure remain unchanged.

The separately frozen30s diagnostic completed in both derivative routes.
It prints the full2x2 Hessian and confirms that its exact difference from
[[0,-p2],[p2,0]] is zero and its product with the stated Green matrix minus
identity is zero. Python structural matrix equality had compared expanded
and factored SymPy entries. V3 uses expanded exact residuals for these two
identities;the physical signs and expected matrices are unchanged.

Freeze V3 and diagnostic artifacts before one corrected primary plus the
unused replay,each120s-after-import/8GiB;independent validation180s. Both
failed primaries and the successful non-loop interface diagnostic are
classified separately. No loop coefficient was inferred from a failed gate,
and no scientific requirement or old qualified evidence was modified.
