# V2 differential/Fourier/graded-kinetic bridge

V1 primary completed its four elementary units and color contraction,but
stopped at the physical tree kinetic gate. Its exact sources/controller,
preparation and full failed capture remain;no result was qualified. Replay
was not launched. The frozen record's phrase negative-unit principal metric
conflated several different mathematical objects.

V2 checks them together from the actual g0 gauge fixing BEFORE loop units:
the physical density +d_mu a d^mu C;its left antighost Euler derivative
-Box C;the ordered Fourier a(-p)C(p) coefficient +p_squared I;and the
graded Hessian block K[C,a]=-p_squared,K[a,C]=+p_squared,whose inverse
G[C,a]=+1/p_squared,G[a,C]=-1/p_squared. This is the existing qualified
reference convention,not a changed ghost sign or physical action. All2025
color entries and four Lorentz directions remain required. If the literal
bridge fails,stop before another loop calculation.

The elementary propagator is unchanged. All original units,odd signs,
two orders,UV/IR,actual F tensors and full matrix checks remain. Emit the
complete unit table into the capture before group release so a subsequent
failure cannot conceal completed intermediate arithmetic;partial output
still earns no final receipt. A replacement primary plus unused replay
retain120s-after-import/8GiB limits;independent validator180s. Freeze V2
sources and role inputs under standing delegation;V1 is not rewritten.
