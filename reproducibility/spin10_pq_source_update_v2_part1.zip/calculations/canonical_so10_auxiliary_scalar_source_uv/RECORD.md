# Auxiliary-source scalar kinetic UV test V1

Baseline8da8d2b5c4104999ece676694dbe483677048579. Standing AGENTS delegation;
statev113/34of39 unchanged. The historical g2 JC pole is already included
(V150 lineage correction); it is not an unmeasured lower-order alternative.

Question: does the complete coefficient-dimension0,g4,no-jet JLambda*C*x*x
one-loop UV pole vanish under the actual qualified reference? Reuse V170's
complete relaxed support census, checking its exact two supported families:
SL*F*S4 and SL*F*S3*S3. Each permits ordinary BB propagation. All four scalar
kinetic terms are the frozen canonical 1/2(Dx)^T(Dx), already checked in V181;
reuse their qualification rather than re-extracting large representations.
GF/source vertices have no scalar dependence in this dimension-zero scope.
All source and ghost coefficients remain arbitrary common prefactors. Do not
solve a tensor from a desired Slavnov cancellation or read known Gamma.

At constant external x, let tau_a=R_a*x and Q=q^T eta q. The seagull and
scalar-exchange Hessian insertions must combine into
g^2(tau_a dot tau_b)[eta-u*(eta*q)*(eta*q)^T], with scalar reference inverse
u=1/(Q-Mref_sector^2). Contract the actual longitudinal mixed B/Lambda
propagator on its source side. Prove or refute leading-UV transversality;
retain the finite-reference remainder proportional to 1-Q*u. This is not a
massless physical scalar prescription, a finite-trace identity or an IR
cancellation. Reference masses are not adopted physical inputs. Positive-
dimension mass/potential/VEV insertions lower UV degree; no inverse masses
are admitted. Zeroth external Taylor order follows from target dimension4.

Primary: ordered graded Born expansion of literal synthetic source SL=Je*L*C,
F=(partial a)*B*Ce and scalar kinetic vertices, with all Lorentz sums, both
distinct/coincident internal gauge labels and two polarized external scalars.
Replay: connected routed Wick contractions, all vertex orders and orientations,
independent odd permutations and momentum routing. Disconnected two-cycles
must be excluded, not assigned one loop momentum. Evaluate external derivative
placements explicitly at zero Taylor order. Extend only the tiny existing
unit helper to four external tags (two odd, two commuting even); no compiler.
Match both nonzero individual family units, not only their potentially zero
sum. Keep full ordinary BB widths, mixed/ghost orientations and 2i UV-annulus
normalization. The representative units factor arbitrary color/Gram tensors;
the algebraic identity, not sampled color entries, supplies full coverage.

Independently solve the finite mixed Gaussian block longitudinal response,
with separate scalar reference denominator, and compare its order-g^2
two-scalar response to the summed diagrams after reference substitution.
Verify a nonzero finite-reference kernel when appropriate. Synthetic
nonidentity metric/inverse control tests the kinetic Gram matching. Show
the wrong inverse fails. Do not assume residue cyclicity on mixed operators.

Controls: omit either family; half the seagull; omit transverse BB; omit BB,
mixed or ghost propagation; wrong source parity. Record which controls are
insensitive to the zero sum instead of claiming normalization from zero.
All eight F/scalar derivative-placement patterns and coincident identical-
field factors must be accounted for. Shared frozen action, normalization,
helpers/arithmetic and AI authorship limit independence.

Two sequential read-only workers300seconds after imports/sampled8GiB,
minimum350MiB available commit. Freeze source/controller/dependencies first;
deny peer results and known Gamma. Preserve all failed/incomplete runs.
Separate frozen validator checks exact route agreement, captures, Gaussian
and UV identities, controls, receipt bindings and authority preservation
before a scoped local commit. Fresh same-command pairs0 unless actually run.

Possible result: qualified selected zero, nonzero coefficient requiring
actual group contractions, or incomplete/inapplicable reduction. Full raw
domain45*45*328*329/2=109260900 scalar-pair positions, not loop integrations.
Sector-diagonal leading scalar inverse and kinetic action imply cross-sector
zeros. No full E5/A5, finite/IR, full Slavnov, QAP, anomaly or physical-GUT
claim. HB1/C5 blocked, flavor paused, C1_GS uncomputed, old failures, quantum
warning and custodyexit2/seven preserved. Track A tests a missing source pole;
Track B tests completeness and limits of a structural shortcut. Track C is
concurrent, voluntary, nonblocking. No new accepted benchmark/input or policy.
