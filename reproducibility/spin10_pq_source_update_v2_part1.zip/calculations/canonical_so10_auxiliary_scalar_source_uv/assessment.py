"""Two auxiliary-source scalar graph units: graded Born / connected Wick."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PKG))
import a10_e5_gauge_source_partner_control as lib
from sympy.polys.rings import ring
from sympy.polys.domains import QQ_I
s=lib.s; ETA=lib.ETA
R,*rr=ring('k0,k1,k2,k3,t,u,width_X,width_Y',QQ_I)
K=rr[:4]; t,u,wx,wy=rr[4:]; II=R.from_expr(s.I)
c=lambda z:R.from_expr(s.sympify(z))
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
EXT={'Je':0,'X1':1,'X2':2,'Ce':3}; ODD={0,3}; TARGET=(0,1,2,3)

def multiply(P,Q):
    out={}
    for a,z in P.items():
        for b,y in Q.items():
            word=a+b
            # Multilinear coefficient extraction, NOT nilpotent even fields.
            if len(set(word))!=len(word):continue
            sign=(-1)**sum(x>y and x in ODD and y in ODD for i,x in enumerate(word) for y in word[i+1:])
            key=tuple(sorted(word));out[key]=out.get(key,R.zero)+sign*z*y
    return {k:z for k,z in out.items() if z}

def add(*Ps):
    out={}
    for P in Ps:
        for k,z in P.items():out[k]=out.get(k,R.zero)+z
    return {k:z for k,z in out.items() if z}

def mm(A,B):
    right={};out={}
    for (k,j),Q in B.items():right.setdefault(k,[]).append((j,Q))
    for (i,k),P in A.items():
        for j,Q in right.get(k,[]):
            Z=multiply(P,Q)
            if Z:out[i,j]=add(out.get((i,j),{}),Z)
    return {k:Z for k,Z in out.items() if Z}

def trace(A,w):return add(*({a:(-1)**w.p[list(w.fields)[i]]*z for a,z in P.items()} for (i,j),P in A.items() if i==j))

def model(mode,family,indices,placement=(False,False,False)):
    w=lib.alphabet();labels=['X','Y'] if mode=='distinct' else ['X']
    w.fields={**{f'B{a}{mu}':(1,0,0) for a in labels for mu in range(4)},**{'L'+a:(2,0,0) for a in labels},'CA':(1,1,1),'aA':(1,-1,1),'chi':(1,0,0)}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    for n,z in [('Je',(1,-1,1)),('X1',(1,0,0)),('X2',(1,0,0)),('Ce',(1,1,1))]:lib.register(w,n,z)
    v=w.var;rho=indices[0];Y='Y' if mode=='distinct' else 'X';ge,xe,ye=placement
    S=w.mul(v('Je'),v('LX'),v('CA'))
    F=w.scale(w.mul(v('aA') if ge else w.D(v('aA'),rho),v(f'B{Y}{rho}'),w.D(v('Ce'),rho) if ge else v('Ce')),ETA[rho])
    if family=='seagull':
        mu=indices[1];V=w.scale(w.mul(v(f'BX{mu}'),v(f'B{Y}{mu}'),v('X1'),v('X2')),ETA[mu]);Ps=[S,F,V]
    elif family=='box':
        a,b=indices[1:]
        A=w.scale(w.mul(v(f'BX{a}'),v('chi') if xe else w.D(v('chi'),a),w.D(v('X1'),a) if xe else v('X1')),ETA[a]*(-1 if xe else 1))
        B=w.scale(w.mul(v(f'B{Y}{b}'),v('chi') if ye else w.D(v('chi'),b),w.D(v('X2'),b) if ye else v('X2')),ETA[b]*(-1 if ye else 1));Ps=[S,F,A,B]
    else:assert family=='base';Ps=[S,F]
    assert all(w.grade(P,(4,0,0)) for P in Ps),'LITERAL_UNIT_GRADE'
    return w,Ps

def inverse(a,b,epsilon=1,omit_scalar=False,omit_vector=False,omit_ghost=False,**opts):
    if a==b=='chi':return R.zero if omit_scalar else u
    if omit_vector and a.startswith('B') and b.startswith('B'):return R.zero
    if omit_ghost and (a,b) in [('CA','aA'),('aA','CA')]:return R.zero
    z=lib.inverse(a,b,epsilon,**opts)
    return R.from_expr(z.as_expr())

def hessian(P,w):
    names=list(w.fields);pos={n:i for i,n in enumerate(names)};out={}
    for (i,alpha),first in lib.partials(P,w,set(names)).items():
        for (j,beta),Q in lib.partials(first,w,set(names)).items():
            f=c((-1)**(w.p[j]*(w.p[i]+1)))
            for mu in alpha:f*=-II*K[mu]
            for mu in beta:f*=II*K[mu]
            for word,z in Q.items():
                assert all(n in EXT for n,jets in word)
                if any(jets for n,jets in word):continue
                raw=[EXT[n] for n,jets in word];sign=(-1)**sum(x>y and x in ODD and y in ODD for k,x in enumerate(raw) for y in raw[k+1:]);key=tuple(sorted(raw))
                cell=out.setdefault((pos[i],pos[j]),{});cell[key]=cell.get(key,R.zero)+sign*c(z)*f
    return {k:{a:z for a,z in P.items() if z} for k,P in out.items() if any(P.values())}

def born(mode,family,indices,placement=(False,False,False),**opts):
    w,Ps=model(mode,family,indices,placement);G={(i,j):{():z} for i,a in enumerate(w.fields) for j,b in enumerate(w.fields) if (z:=inverse(a,b,**opts))};Hs=[hessian(P,w) for P in Ps];parts=[];n=len(Ps);target=(0,3) if family=='base' else TARGET
    for order in permutations(Hs):
        A=G
        for i,H in enumerate(order):
            A=mm(A,H)
            if i<n-1:A=mm(A,G)
        parts.append(II*c(s.Rational((-1)**(n+1),2*n))*trace(A,w).get(target,R.zero))
    return sum(parts,R.zero),parts,0

def pairings(legs):
    if not legs:yield [];return
    a=legs[0]
    for i,b in enumerate(legs[1:],1):
        if a[0]==b[0] or not inverse(a[1],b[1]):continue
        sign=(-1)**(a[3]*sum(z[3] for z in legs[1:i]))
        for rest in pairings(legs[1:i]+legs[i+1:]):yield [(a,b,sign)]+rest

def connected(pairs,n):
    seen={0}
    while True:
        nxt=seen|{b[0] for a,b,_ in pairs if a[0] in seen}|{a[0] for a,b,_ in pairs if b[0] in seen}
        if nxt==seen:return len(seen)==n
        seen=nxt

def wick(mode,family,indices,placement=(False,False,False),**opts):
    w,Ps=model(mode,family,indices,placement);n=len(Ps);target=[0,3] if family=='base' else list(TARGET);parts=[];disconnected=0
    for order in permutations(Ps):
        out=R.zero
        for terms in product(*(list(P.items()) for P in order)):
            full=[];legs=[];external=[];value=R.one
            for vertex,(word,z) in enumerate(terms):
                value*=c(z)
                for pos,(name,jets) in enumerate(word):
                    token=(vertex,name,jets,w.p[name],pos);full.append(token)
                    if name in EXT:
                        external.append(EXT[name])
                        if jets:value=R.zero
                    else:legs.append(token)
            if not value:continue
            assert len(legs)==2*n and sorted(external)==target
            crossing=(-1)**sum(a[3]*b[3] for i,a in enumerate(full) if a[1] not in EXT for b in full[i+1:] if b[1] in EXT)
            sorting=(-1)**sum(x>y and x in ODD and y in ODD for i,x in enumerate(external) for y in external[i+1:])
            for pairs in pairings(legs):
                if not connected(pairs,n):disconnected+=1;continue
                routes=[]
                for tail in product([-1,1],repeat=n-1):
                    signs=(1,*tail)
                    if all(sum(e*(int(a[0]==v)-int(b[0]==v)) for e,(a,b,sgn) in zip(signs,pairs))==0 for v in range(n)):routes.append(signs)
                assert len(routes)==1,'ONE_CONNECTED_ONE_LOOP_MOMENTUM';term=value*crossing*sorting
                for e,(a,b,sgn) in zip(routes[0],pairs):
                    term*=sgn*II*inverse(a[1],b[1],e,**opts)
                    for mu in a[2]:term*=II*e*K[mu]
                    for mu in b[2]:term*=-II*e*K[mu]
                out+=-II**(n+1)*c(s.Rational(1,s.factorial(n)))*term
        parts.append(out)
    assert all(P==parts[0] for P in parts),'ALL_ORDERED_CONNECTED_WICK_UNITS_AGREE'
    return sum(parts,R.zero),parts,disconnected

def serial(P):return str(s.expand(P.as_expr()))
def leading(P):return lib.R.from_expr(P.as_expr().subs(s.Symbol('u'),s.Symbol('t')))
def pole(P,role):return lib.residue(leading(P),role)

def actual_inputs(prep,role):
    I=read(ROOT/f'calculations/canonical_so10_single_source_uv_frontier/{role}_result.json');T=I['targets']['C_JL_x_x__j0']
    assert T['types']==['C','JL','x','x'] and T['jets']==0 and T['supported_families']==['SL*F*S3*S3','SL*F*S4']
    for family in T['supported_families']:
        row=T['candidate_families'][family];assert row['g']==4 and row['xi']==0
        assert {tuple(v['external_roles']) for v in row['profiles']}=={('CH','JM','X','X'),('CM','JM','X','X')}
        assert all(v['uses_BB'] and v['explicit_external_jets']==v['required_UV_Taylor_order']==0 for v in row['profiles'])
    V=I['vertices'];assert V['SL']['source_type']=='JL'
    assert all(not any(name=='X' for name,j in term) for tag in ['SL','KL','F','D','U','X','Q','R'] for term in V[tag]['literal_role_monomials'])
    A=read(ROOT/('calculations/canonical_so10_scalar_source_g3_color/'+('primary_v2_result.json' if role=='primary' else 'replay_v3_result.json')))
    assert A['four_frozen_kinetic_ASTs_and_identity_metrics_checked'] and A['complete180_source_kinetic_matrices_agree']
    assert A['all328_scalar_directions']==328 and A['cross_sector_blocks_zero_from_separate_source_and_kinetic_terms']
    H=read(PKG/f'frozen_a10_e5_full_hessian/{role}.json')['retained_reference']
    assert not H['scalar_reference_masses_are_adopted_physical_parameters'] and not H['whole_mixed_Hessian_positive_Laplace_operator_claimed']
    return {'two_families_exact':T['supported_families'],'all_width_profiles_retained':True,'all4_kinetic_AST_identity_metrics_reused':True,'reference_scalar_masses_not_physical_inputs':True,'source_Gf_scalar_independence_checked_from_literal_inventory':True}

def schur():
    Q,m,W,g,r1,r2=s.symbols('Q m2 W g r1 r2',nonzero=True);U=1/(Q-m)
    # Direct longitudinal equations from the complete mixed quadratic matrix.
    cx,cy,dx,dy,e=s.symbols('cx cy dx dy e')
    eq=[g*g*r1*(r1*cx+r2*cy)+s.I*dx+s.I*g*r1*e,
        g*g*r2*(r1*cx+r2*cy)+s.I*dy+s.I*g*r2*e,
        -s.I*Q*cx+W*dx-1,-s.I*Q*cy+W*dy,
        -s.I*g*Q*(r1*cx+r2*cy)+(Q-m)*e]
    sol=s.solve(eq,[cx,cy,dx,dy,e]);assert all(s.cancel(z.subs(sol))==0 for z in eq)
    distinct=s.cancel(s.diff(-sol[cy],r1,r2).subs({r1:0,r2:0})/g**2)
    eq2=[g*g*(r1+r2)**2*cx+s.I*dx+s.I*g*(r1+r2)*e,-s.I*Q*cx+W*dx-1,-s.I*g*(r1+r2)*Q*cx+(Q-m)*e]
    sol2=s.solve(eq2,[cx,dx,e]);assert all(s.cancel(z.subs(sol2))==0 for z in eq2)
    coincident=s.cancel(s.diff(-sol2[cx],r1,r2).subs({r1:0,r2:0})/g**2)
    assert distinct!=0 and coincident!=0 and s.cancel(coincident-2*distinct)==0
    assert s.limit(Q**2*distinct,Q,s.oo)==0
    metric=s.diag(2,3);a=s.Matrix(s.symbols('a0:2'));b=s.Matrix(s.symbols('b0:2'))
    assert (a.T*metric*metric.inv()*metric*b)[0]==(a.T*metric*b)[0]
    assert s.expand((a.T*metric*metric*b-a.T*metric*b)[0])!=0
    q=s.Matrix(s.symbols('q0:4'));eta=s.diag(*ETA);qq=(q.T*eta*q)[0]
    P=eta-(eta*q)*(eta*q).T/qq
    assert all(s.cancel(z)==0 for z in P*q)
    full=eta-U*(eta*q)*(eta*q).T
    assert all(s.cancel(z)==0 for z in full*q-(eta*q)*(1-U*qq))
    return {'distinct_Gaussian_kernel':str(distinct),'coincident_Gaussian_kernel':str(coincident),'exact_scalar_reference_factor':str(s.factor(1-Q*U)),
            'arbitrary4vector_leading_transversality':True,'finite_reference_kernel_nonzero_UV_suppressed':True,'synthetic_nonidentity_metric_checked_wrong_inverse_fails':True}

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    inputs=actual_inputs(prep,role)
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(a in args[1] for a in 'wax+'):raise PermissionError('AUX_SCALAR_WORKER_WRITE')
        if p.suffix=='.json':raise PermissionError('AUX_SCALAR_POLE_GAMMA_OR_PEER_READ')
    sys.addaudithook(guard);method=born if role=='primary' else wick;tables={};complete={};parts={};counts={}
    for mode in ['distinct','coincident']:
        tables[mode]={};complete[mode]={};parts[mode]={};counts[mode]={}
        for family,nind in [('base',1),('seagull',2),('box',3)]:
            if family=='base' and mode=='distinct':continue
            print('STAGE '+role+' '+mode+' '+family,flush=True);entries=[];full=R.zero;word_sums=None;bad=0
            for indices in product(range(4),repeat=nind):
                P,ps,rejected=method(mode,family,indices);full+=P;bad+=rejected;entries.append([list(indices),serial(P)])
                word_sums=ps if word_sums is None else [a+b for a,b in zip(word_sums,ps)]
            complete[mode][family]=full;parts[mode][family]=word_sums;counts[mode][family]=bad;tables[mode][family]=entries
        # All derivative placements are actually applied, not removed as vertices.
        for placement in product([False,True],repeat=3):
            if not any(placement):continue
            for indices in product(range(4),repeat=3):
                P,_,_=method(mode,'box',indices,placement);assert not P
        for indices in product(range(4),repeat=2):
            P,_,_=method(mode,'seagull',indices,(True,False,False));assert not P
    S=schur();totals={};controls={};Q=s.Symbol('Q');m=s.Symbol('m2');exprsubs={s.Symbol('t'):1/Q,s.Symbol('u'):1/(Q-m)}
    for mode in ['distinct','coincident']:
        A=complete[mode]['seagull'];B=complete[mode]['box'];pa= pole(A,role);pb=pole(B,role);assert pa!=0 and s.expand(pa+pb)==0
        total=s.cancel((A+B).as_expr().subs(exprsubs));expected=s.sympify(S[mode+'_Gaussian_kernel']).subs(s.Symbol('W',nonzero=True),s.Symbol('width_Y' if mode=='distinct' else 'width_X'))
        expected=expected.subs({s.Symbol('Q',nonzero=True):Q,s.Symbol('m2',nonzero=True):m})
        assert s.cancel(total-expected)==0,'FULL_REFERENCE_GAUSSIAN_VS_DIAGRAM_UNITS'
        assert s.limit(Q**2*total,Q,s.oo)==0 and total!=0
        controls[mode]={'omit_box':str(pa),'omit_seagull':str(pb),'half_seagull':str(pa/2+pb)}
        assert all(s.sympify(z)!=0 for z in controls[mode].values())
        for name,opts in [('omit_transverse',{'omit_transverse':True}),('omit_vector',{'omit_vector':True}),('omit_mixed',{'omit_mixed':True}),('omit_ghost',{'omit_ghost':True})]:
            Aa=sum((method(mode,'seagull',ind,**opts)[0] for ind in product(range(4),repeat=2)),R.zero)
            Bb=sum((method(mode,'box',ind,**opts)[0] for ind in product(range(4),repeat=3)),R.zero)
            aa,bb=pole(Aa,role),pole(Bb,role);controls[mode][name]={'family_poles':[str(aa),str(bb)],'sum':str(aa+bb),'sum_insensitive':s.expand(aa+bb)==0,'individual_units_change':s.expand(aa-pa)!=0 or s.expand(bb-pb)!=0}
            assert controls[mode][name]['individual_units_change'] and controls[mode][name]['sum_insensitive']
        totals[mode]={'seagull':serial(A),'box':serial(B),'sum':serial(A+B),'UV_poles':[str(pa),str(pb)],'sum_pole':str(pole(A+B,role)),'finite_reference_sum':str(total)}
    base=complete['coincident']['base'];assert s.cancel(base.as_expr().subs(exprsubs)+s.I/Q)==0
    w,Ps=model('distinct','seagull',(0,0));w.p['Je']=0;w.external['Je']=(1,-1,0);assert not w.grade(Ps[0],(4,0,0))
    if role=='replay':assert counts['coincident']['box']>0 and counts['distinct']['box']==0
    result={'schema':'AUXILIARY_SCALAR_SOURCE_UV_V1','route':role,'input_checks':inputs,'complete_Lorentz_kernels':tables,'complete_units':totals,
        'all_ordered_unit_kernels':{mode:{f:list(map(serial,ps)) for f,ps in fs.items()} for mode,fs in parts.items()},'disconnected_pairings_rejected':counts,
        'all8_derivative_patterns_checked':True,'coincident_source_base_kernel':serial(base),'source_base_Gaussian_match':True,'wrong_source_parity_rejected':True,
        'negative_controls':controls,'Schur_and_finite_Gaussian_checks':S,'full_raw_scalar_pair_positions':45*45*328*329//2,'same_sector_scalar_pairs':33576,'cross_sector_scalar_pairs':20380,
        'arbitrary_Gram_color_source_prefactors_cancel_in_selected_UV_coefficient':True,'complete_selected_g4_JL_C_x_x_dimension0_nojet_pole_zero':True,
        'known_Gamma_or_peer_read':False,'finite_amplitude_zero_or_full_E5_A5_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
