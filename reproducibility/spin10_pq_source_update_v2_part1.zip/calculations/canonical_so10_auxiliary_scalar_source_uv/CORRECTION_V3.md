# Enforce the defined Lorentz square V3

V2 passed the nonzero-family/opposite-UV-pole test, then failed full-reference
Gaussian comparison. Its diagram expression retains k0^2-k1^2-k2^2-k3^2,
while its Gaussian response uses the name Q for that same square. The V2
comparison incorrectly treated them as independent. V2 source, preparation,
controller and full failure capture remain unchanged; no V2 result/replay.

V3 retains the unreduced expression and residual. It eliminates k0^2 by the
exact defining relation k0^2=Q+k1^2+k2^2+k3^2, requiring the result contain no
remaining momentum components, before demanding exact Gaussian equality.
The same definition is enforced for the separate source-base normalization.
This is not angular averaging, an on-shell condition, a changed sign/factor
or a relaxed numerical tolerance. The proposed diagnosis is tested rather
than accepted by this document. All original checks and caps remain required.
Repeated failures are comparison-harness defects so far, not scientific PASS.
Another unexplained mathematical discrepancy stops the reduction for review.
