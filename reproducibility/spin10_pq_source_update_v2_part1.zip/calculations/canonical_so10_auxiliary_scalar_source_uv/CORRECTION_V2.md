# Explicit symbol parsing V2

The original primary completed both modes' Born expansions and derivative
placement checks, then failed parsing its Gaussian expression: SymPy reserves
the bare name Q as AssumptionKeys. The failed source, preparation, controller
and complete capture remain unchanged. No original result or replay exists.

V2 explicitly supplies Q,m2,W in sympify's locals. No action, graph, equation,
normalization, control, assumption or acceptance assertion changes. Two fresh
sequential read-only300second/sampled8GiB workers are frozen under standing
delegation; this does not retroactively accept the failed execution.
