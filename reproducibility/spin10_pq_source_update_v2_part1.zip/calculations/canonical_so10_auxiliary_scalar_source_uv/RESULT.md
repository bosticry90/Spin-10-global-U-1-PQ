# Selected auxiliary-source scalar UV pole is zero

The coefficient-dimension0,g4,no-jet JLambda*C*x*x UV pole vanishes under
the qualified reference and complete V170 support census. This is a selected
logarithmic-pole result, not a zero finite amplitude or complete E5 proof.
Qualification requires the completed V3 paired captures/results, separately
frozen validation receipt and exact committed-byte proof; this prose alone
does not authenticate any run.

Both permitted families were retained: SL*F*S4 and SL*F*S3*S3. The first has
a two-scalar seagull; the second contains an internal scalar between two
cubic kinetic vertices. Each has ordinary BB propagation with symbolic width.
The graded Born expansion and connected routed Wick calculation agree on
every unintegrated Lorentz kernel and nonzero individual family pole.

| Polarized unit | Seagull pole | Scalar-exchange box pole | Sum |
| --- | --- | --- | --- |
| Distinct internal gauge labels | 2 W_Y | -2 W_Y | 0 |
| Coincident internal gauge label | 4 W_X | -4 W_X | 0 |

These are stripped diagram units in the inherited 2i UV-annulus convention,
not nonzero model component values. Arbitrary source, ghost and representation
coefficients factor the cancellation. The coincident-label test checks the
identical-field multiplicity, rather than importing distinct-label factors.

## Why the reduction applies

For each canonical real scalar sector, the actual kinetic density is
1/2(Dx)^T(Dx). V181's completed checks of all four literal kinetic ASTs,
identity metrics and all180 generator/source matrices are reused. They are
not newly reconstructed or independently remeasured here. GF/source scalar
independence and the exact two-family inventory are checked against actual
V170 data. Its CH/CM external ghost and ordinary-vector profiles are retained.

At constant external scalars, with tau_a=R_a*x and Q=q^T eta q, the combined
bosonic insertion is

    g^2 (tau_a dot tau_b) [eta - u (eta q)(eta q)^T],
    u = 1/(Q-Mref_sector^2).

The source-side mixed B/Lambda propagator is longitudinal. Its contraction
gives (eta q)(1-Q*u), zero at leading UV order u=1/Q. This identity holds
before contracting arbitrary gauge/source/Gram tensors. Separate scalar
sectors have a block-diagonal leading inverse and no cross kinetic term;
their cross-sector contribution is zero. The singlet is included.

The complete symmetric-scalar component domain is109260900 raw positions:
45 source directions*45 ghost directions*53956 scalar pairs. The pairs split
33576 same-sector and20380 cross-sector. This is coverage by a universal
tensor identity and qualified inventory, not109260900 fresh integrations or
sampled component tests. Source-inactive directions remain structural zeros.
No unresolved jet placement is silently imported from the inventory: the
new unit workers apply all eight ghost/scalar derivative placement patterns
and evaluate the seven external-derivative variants at zeroth Taylor order.

## Finite-reference boundary and controls

Retaining the nonzero scalar reference mass gives, for the distinct-label
stripped source unit,

    -i W_Y (1-Q*u)/Q^2 = i W_Y Mref^2/[Q^2(Q-Mref^2)].

The coincident unit is twice this expression. These are unintegrated reference
kernels, not finite matching coefficients. They are generally nonzero and
fall as Q^-3. Thus the UV logarithm cancels without declaring a whole scaleless
integral zero, discarding masses in a physical propagator, or solving an IR
problem. Positive-dimension insertions are excluded only from this selected
dimension-zero pole. No cyclic regularized-trace theorem is assumed.

Both workers solve the finite longitudinal Gaussian equations and compare
with the explicit graph sum; the separate source-base kernel is -i/Q. The
validator independently checks full finite mixed matrices and polynomial UV
moments without importing the diagram engine. Both workers share that engine's
underlying word/arithmetic helpers and the same frozen action/conventions.
Agreement does not independently establish their physical assumptions.

Omitting either family or halving the seagull produces a nonzero UV remainder.
Omitting transverse BB changes each individual family pole but leaves their
sum zero. Removing BB, mixed or ghost propagation removes both units, again
leaving a zero sum. These are explicitly insensitive total-zero controls:
the nonzero individual units and Gaussian source base are required separately.
Wrong source parity fails the literal grade test. A synthetic nonidentity
kinetic metric works only with its matched inverse. Wick rejects1536
disconnected coincident-label pairings before routing; they are two loops,
not another one-loop contribution. All ordered connected Wick units agree.

## Execution and retained failures

Original primary failed symbolic parsing of the reserved name Q. V2 fixed
the symbol mapping, then exposed a comparison that omitted Q=q^T eta q.
V3 enforces that exact defining relation and retains the unreduced expression
and residual, which contains the omitted relation as a factor. No sign,
coefficient, physical input, graph or tolerance was adjusted. All original
sources, preparations and complete failure captures are preserved. Neither
failed run has a qualified result or replay. See the two correction records.

Completed V3 primary41.8394363seconds/56672256 sampled private bytes;
replay39.2278946seconds/57303040 bytes. Both caps300seconds/8GiB with350MiB
minimum available commit. They are distinct role commands; fresh byte-identical
same-command replay pairs0. Old loops, full Gamma and custody were not rerun.

Track A removes a complete selected scalar-source UV obligation economically.
Track B demonstrates a useful structural reduction and sensitive omission
controls, but records two comparison-harness failures and the inability of a
zero sum to normalize missing propagators. Education remains voluntary,
concurrent and nonblocking. No special AI benchmark platform or outreach.

Known Gamma remains145310 terms with its saved background Ward zero; a zero
new pole adds no node. Full source/Slavnov,E5/A5,QAP,measure/IR/anomaly freedom
remain unqualified. Statev113/34of39 unchanged; HB1/C5 blocked,C1_GS uncomputed,
flavor paused, quartet and benchmark failures, scalar quantum warning and
custodyexit2/seven preserved. No accepted physical input/benchmark is changed.

Next reconcile the remaining V170 source/jet/coupling classes against actual
later receipts and the current Gamma recipe. Prefer a complete coefficient
census for the next missing source identity over another isolated coefficient.
Do not infer complete source restoration from the accumulated selected zeros.
