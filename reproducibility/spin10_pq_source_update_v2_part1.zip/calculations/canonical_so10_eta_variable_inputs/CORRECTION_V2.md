# Proposed UTF-8 verifier correction V2 — additional execution NOT AUTHORIZED

The two authorized native roles have executed. The primary completed. The
independent verifier passed its mathematical assertions through the mass,
Higgs, Ward, normalization, inventory and fixed-eta-failure controls, then
failed at its report-text audit with UnicodeDecodeError from Windows cp1252.
There is no accepted validation receipt. This is an engineering failure,
not an eta feasibility verdict or a newly qualified scientific checkpoint.

Preserve original verify.py and its source copy externally, original
validation_preparation.json, complete independent_verifier_capture.json and
all original report/input/source bytes. Do not edit the old report to hide
its UTF-8 text, manufacture a receipt, or classify the failed worker COMPLETED.

Concrete correction: a separately frozen verify_v2.py reads report text with
explicit encoding='utf-8'. It uses a new validation-preparation binding and
adds accurate failed-attempt accounting and preservation checks. Its
mathematical assertions, source inputs, old-reference/eta=0 controls and
120-second/8-GiB limit are unchanged. A new runner uses a distinct capture
name and refuses duplicate launch. Primary output is reused, not recomputed.

Proposed additional allowance: exactly ONE corrected independent verifier,
120 seconds after imports, at most 8 GiB sampled private allocation and a
direct prelaunch available-commit observation of at least 350 MiB. No new
point, parameter search, model/input adoption, fixed-interaction scattering
screen or quantum calculation. Any failure remains terminal and preserved;
no automatic further attempt. Approval must come from the human director.

The previous [contract](RECORD.md) specified “Two sequential native roles
only” and “no automatic additional attempt.” The director's explicit
authorization of that proposal supplies two executions, not an unlimited
retry budget. This file prepares the reviewable correction; it does not
itself authorize a third native role. Education or technical proficiency is
not a condition of approval. All state/evidence/authority boundaries remain.
