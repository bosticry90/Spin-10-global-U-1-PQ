"""Authorized symbolic eta transport of qualified scalar input tensors."""
from pathlib import Path
from hashlib import sha256
import sys,json,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_weak_colored_compatibility'));import pencils as base
P=base.P;m=base.m;eta=S.Symbol('eta',real=True);h=S.symbols('h0:8',real=True)
inp=base.inp
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
expand=lambda z:S.expand(z)
zero=lambda z:all(expand(v)==0 for v in z) if isinstance(z,S.MatrixBase) else expand(z)==0
matrix=lambda A:S.Matrix([[S.sympify(v,locals={**dict(zip(map(str,P),P)),'m':m,'eta':eta,**dict(zip(map(str,h),h))}) for v in row] for row in A])
text=lambda A:[[str(expand(v)) for v in row] for row in A.tolist()]

def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('ETA_TRANSPORT_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,v in prep['input_sha256'].items():assert digest(R/n)==v,n
 old=read(C/'canonical_so10_joint_higgs_inputs/primary_result.json');src=read(C/'canonical_so10_singlet_tadpole/original_v2_result.json')
 physical,raw,factors=base.coefficients();physical['zEta']=eta;raw['zEta']=eta*factors['zEta']
 assert factors['zEta']==S.sqrt(S.Rational(3,160))**3
 co={n:(S.re(raw[n]),S.im(raw[n])) for n in inp.NAMES};ledgers=old['raw_target_ledgers']
 assert set(ledgers)==set(inp.NAMES) and len(src['slots'])==34
 tags=['hh','nn','h4','h2n','n'];tables={}
 for tag in tags:
  table={}
  for name,book in ledgers.items():
   re,im=co[name]
   for ex,a,b in book[tag]:
    v=re*S.Rational(a) if name in inp.REAL else 2*(re*S.Rational(a)-im*S.Rational(b))
    key=tuple(ex);table[key]=table.get(key,0)+v
  tables[tag]={ex:expand(v) for ex,v in table.items() if not zero(v)}
 def hessian(table,offset,size):
  A=S.zeros(size)
  for ex,v in table.items():
   ids=[i-offset for i,n in enumerate(ex) for _ in range(n)];assert len(ids)==2 and min(ids)>=0 and max(ids)<size
   i,j=ids;A[i,j]+=v*(2 if i==j else 1)
   if i!=j:A[j,i]+=v
  return A.applyfunc(expand)
 H=hessian(tables['hh'],0,8);N=hessian(tables['nn'],8,10)
 V4=expand(sum(v*S.prod(t**n for t,n in zip(h,ex[:8])) for ex,v in tables['h4'].items()))
 sources=[S.zeros(8) for _ in range(10)]
 for ex,v in tables['h2n'].items():
  j=next(i for i,n in enumerate(ex[8:]) if n);e=list(ex);e[8+j]=0;sources[j]+=hessian({tuple(e):v},0,8)
 sources=[A.applyfunc(expand) for A in sources]
 assert not tables['n'] and N.diff(eta)==S.zeros(10)
 assert all(zero(v.diff(eta)) for n,v in physical.items() if n in ['mPhi2','mSigma2','mS2'])
 for name,A,expected in [('H8',H,matrix(old['raw_H8'])),('H10',N,matrix(old['raw_H10']))]:assert zero(A.subs(eta,S.Rational(3,10))-expected),name
 oldloc={**dict(zip(map(str,P),P)),'m':m,**dict(zip(map(str,h),h))}
 assert zero(V4.subs(eta,S.Rational(3,10))-S.sympify(old['direct_V4'],locals=oldloc))
 for j,A in enumerate(sources):assert zero(A.subs(eta,S.Rational(3,10))-matrix(old['raw_hh_neutral_cubic_matrices'][j])),j
 allvalues=list(H)+list(N)+list(sources[0])+[V4]
 allvalues+= [v for A in sources[1:] for v in A]
 assert all(zero(S.diff(v,eta,2)) for v in allvalues)
 assert zero(H[:4,4:].subs(eta,0)) and not zero(H[:4,4:].diff(eta))
 for prefix in ['gauge','PQ']:
  Q=matrix(old[prefix+'_action_H8']);orb=list(map(S.sympify,old[prefix+'_orbit_neutral10']))
  assert zero(sum((orb[j]*sources[j] for j in range(10)),S.zeros(8))+H*Q+Q.T*H),prefix
 positive=old['positive_neutral_indices'];assert positive==[0,1,3,5,6,7,8,9]
 assert zero(N[:,2]) and zero(N[:,4]);Hp=N.extract(positive,positive)
 assert not zero(sources[4]),'PHASE_SOURCE_MUST_NOT_BE_DELETED_OFF_KERNEL'
 print('STAGE exact_eta_transport_and_Ward_identities',flush=True)
 slots=[]
 for slot in src['slots']:
  name,_,part=slot.partition(':');slots.append(S.im(raw[name]) if part=='im' else S.re(raw[name]))
 oldblocks=read(C/'canonical_so10_weak_colored_compatibility/primary_result.json')['blocks'];blocks={}
 for name,label in [('weak',[0,0,1,-3]),('colored',[0,1,0,-2]),('conjugate_colored',[1,0,0,2])]:
  b=next(b for b in src['block_inputs'] if b['label']==label);n=len(b['sectors']);A=S.zeros(n)
  for k,i,j,v in b['raw_H34_sparse']:A[i,j]+=slots[k]*S.sympify(v)
  A=A.applyfunc(expand);G=list(map(S.Rational,b['metric']));K=S.Matrix(n,n,lambda i,j:S.simplify(A[i,j]/S.sqrt(G[i]*G[j])))
  ns=n-2;SS=K[:ns,:ns];B=K[:ns,ns:];F=K[ns:,ns:]-m*S.eye(2)
  assert zero(A-A.H) and zero(A.subs(eta,S.Rational(3,10))-matrix(oldblocks[name]['raw_matrix']))
  assert zero(B.subs(eta,0)) and zero(B-eta*B.diff(eta)) and not zero(B)
  assert zero(SS.diff(eta)) and zero(F.diff(eta)) and zero(K.diff(m)-S.diag(*([0]*ns+[1,1])))
  assert zero(B.H*B-eta**2*(B.diff(eta).H*B.diff(eta)))
  blocks[name]={'label':label,'metric':b['metric'],'sectors':b['sectors'],'raw_matrix':text(A),'canonical_matrix':text(K),'Sigma_principal':text(SS),'mixing':text(B),'eta_stripped_mixing':text(B.diff(eta)),'phi_constant':text(F),'eta_stripped_mixing_Gram':text(B.diff(eta).H*B.diff(eta))}
 BC=matrix(blocks['colored']['mixing']);BW=matrix(blocks['weak']['mixing'])
 assert zero((BC.H*BC)[0,0]-S.Rational(432,25)*eta**2)
 assert zero((BW.H*BW)[1,1]-S.Rational(432,25)*eta**2)
 assert zero((BC[2,:].H*BC[2,:])[0,0]-S.Rational(288,25)*eta**2)
 # The third Sigma colored diagonal is 24*s/5, s=p6+p7.
 assert zero(matrix(blocks['colored']['Sigma_principal'])[2,2]-S.Rational(24,5)*(P[5]+P[6]))
 # Inventory actual current quartics from typed field degrees, not old STAGE1 values.
 inventory=[]
 for name in inp.NAMES:
  if inp.TOTAL[name]!=4 or name in base.FREE:continue
  sigma,sing=inp.RESCALE.get(name,(0,0));phi=inp.PHI[name];vec=4-sigma-sing-phi
  assert min(sigma,sing,phi,vec)>=0
  inventory.append({'name':name,'physical_coefficient':str(physical[name]),'degrees_Phi_Sigma_phi_S':[phi,sigma,vec,sing],'nonzero':not zero(physical[name]),'screen':'eta necessary bound inherited' if name=='zEta' else 'zero input' if zero(physical[name]) else 'no complete offdiagonal screen certified here'})
 assert [r['name'] for r in inventory if r['degrees_Phi_Sigma_phi_S']==[0,3,1,0]]==['zEta']
 eta_support={tag:len(ledgers['zEta'][tag]) for tag in tags}
 controls={'missing_hc_changes_eta_vertex':not zero(H.diff(eta)/2-H.diff(eta)),
 'wrong_raw_eta_rescaling_changes_mixing':factors['zEta']!=1 and not zero(BW),
 'wrong_quadratic_derivative_factor':H[0,0]!=H[0,0]/2,
 'wrong_eta_linear_Schur_scaling_rejected':not zero(eta**2-eta),
 'wrong_weak_metric_rejected':S.Rational(9,80)!=S.Rational(9,40),
 'phase_source_nonzero_before_kernel':not zero(sources[4]),
 'eta_zero_retains_noneta_source':not zero(sources[0].subs(eta,0)),
 'fixed_eta_exclusion_preserved':read(C/'canonical_so10_eta_offdiagonal_bound/validation_receipt.json')['fixed_input_eight_quartic_tree_screen_excluded']}
 assert all(controls.values())
 for n,v in prep['input_sha256'].items():assert digest(R/n)==v,n
 assert not writes and time.perf_counter()-start<120
 output={'schema':'ETA_VARIABLE_SYMBOLIC_INPUTS_V1','status':'EXACT_SYMBOLIC_TRANSPORT_REQUIRES_RECEIPT','domain':'eight real quartics plus real eta; 0<eta<=pi*sqrt(7/930); no point selected','eta_reference':'3/10','stationary_physical_masses':{n:str(physical[n]) for n in ['mPhi2','mSigma2','mS2']},'raw_coefficients':{n:str(expand(v)) for n,v in raw.items()},'blocks':blocks,'raw_H8':text(H),'raw_H10':text(N),'raw_positive_H8':text(Hp),'direct_V4':str(V4),'raw_hh_neutral_cubic_matrices':list(map(text,sources)),'raw_j_forms':[str(expand((S.Matrix(h).T*A*S.Matrix(h))[0]/2)) for A in sources],'raw_neutral8_metric':old['raw_neutral8_metric'],'raw_neutral10_metric':old['raw_neutral10_metric'],'positive_neutral_indices':positive,'eta_derivative_H8':text(H.diff(eta)),'eta_derivative_direct_V4':str(expand(V4.diff(eta))),'eta_derivative_source_matrices':[text(A.diff(eta)) for A in sources],'eta_ledger_support':eta_support,'fixed_quartic_inventory':inventory,'conditions':{'mass':'SW>0,SC>0; mW=lambda_max(eta^2*BW1^H*SW^-1*BW1-FW); mC=lambda_max(eta^2*BC1^H*SC^-1*BC1-FC); require mW>mC for strictly positive colored modes','colored_principal':'s=p6+p7>0; m>=lambda_max(diag(12*eta^2/(5*s),0)-FC)','contact_projected_colored':'s<=pi/6 implies m>=lambda_max(diag(72*eta^2/(5*pi),0)-FC)','Higgs':'H8*h=0,h!=0; Hp>0; [[Hp,b],[b^T,8*V4(h)]]>0; b_j=h^T*C_j*h; N=h^T*G8*h; lambda=(4*V4-b^T*Hp^-1*b/2)/N^2','phase':'phase sources j=2,4 vanish only on exact light kernel by gauge/PQ Ward identities'},'all_old_specializations_exact':True,'eta_zero_mixing_exact':True,'Ward_identities_symbolic_eta':True,'neutral_Hessian_and_stationarity_eta_independent':True,'controls':controls,'new_parameter_points':0,'new_parameter_search':False,'new_benchmark_adopted':False,'full_feasibility_proved':False,'full_domain_exclusion_proved':False,'scientific_authority_changed':False,'whole_goal_complete':False,'state_sha256':prep['state_sha256'],'input_sha256':prep['input_sha256'],'write_attempts':writes}
 print('RESULT '+json.dumps(output,sort_keys=True,separators=(',',':')),flush=True)
 print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
