# Symbolic eta transport — validation incomplete after text-decoding failure

The [original result](RESULT.md) states the intended bounded mathematical
classification. The primary output and mathematical checks completed, but
the actual independent worker failed while decoding the UTF-8 report using
Windows cp1252. No accepted validation receipt exists at this checkpoint.
Do not promote the symbolic result before the corrected execution and byte
checks actually pass. Feasibility of the eta-variable domain remains
UNDERDETERMINED, not PASS or excluded.

The preserved [failed capture](independent_verifier_capture.json) includes
the exact traceback and resource observations. The original source and
preparation bytes remain unchanged. The [concrete correction](CORRECTION_V2.md)
adds explicit UTF-8 reads and honest attempt accounting; it changes no
mathematical acceptance condition, calculation input or primary tensor.

The authorized two-role allowance is exhausted. A prepared corrected verifier
requires one additional director-approved 120-second/8-GiB execution. It has
not been launched. No parameter search, new physical value, point, benchmark,
quantum loop or further scattering screen is authorized by that correction.

The fixed eta=3/10 exclusion and all earlier evidence remain intact.
project_state.json and sealed README are unchanged; formal authority stays
34/39. All existing scientific failures, custody exit 2/seven references,
blocked stages and flavor pause remain. The broad investigation is incomplete.
