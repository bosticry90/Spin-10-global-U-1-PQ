# Authorized symbolic eta extension V1 — prospective contract

Director authorization: the human selected “Authorize bounded eta-variable
analysis” in response to the fixed-eta proposal after checkpoint 0ca6ed7.
This authorizes option 1 of the preserved PROPOSED_NEXT_SCOPE.md, not a
parameter search, benchmark adoption or quantum calculation. Previous goal
turns awaited this scope decision; current preflight is clean, no matching
A10/M08 workers, HEAD 0ca6ed796fdcfe6e2b44e3a0af42371e8e64e115.

Question: what exact classical weak/colored mass and Higgs-input conditions
change if the existing real eta is variable? Domain: the same eight real
quartics p1..p8, frozen action/representations/PQ/VEV ratios/other inputs,
m=mphi2 on the larger simple weak light-root branch, and one real eta with
0<eta<=pi*sqrt(7/930). The old eta=3/10 comparison remains excluded. Eta=0
and 3/10 are algebraic reference specializations, not adopted candidate values.

Reuse the qualified literal 34-slot Hessian and 29-monomial h4,h2n,hh,nn,n
ledgers. These inherited tensors are not freshly rederived. Stationarity,
canonical rescalings, actual weak/neutral metrics, complex Hermitian
completion, gauge/PQ Ward identities and the two neutral phase zeros must
be retained. The primary independently assembles variable-eta polynomial
tensors and weak/colored blocks. Compare every entry with the qualified
old tensors at eta=3/10, including zero entries. Prove affine eta dependence,
the eta=0 vanishing of eta-induced Sigma/phi mixing, and no eta dependence
of the neutral Hessian or stationary masses. Do not infer eta=0 removes all
interactions or all sources. Verify the complete gauge/PQ source identities
at symbolic eta before restricting to the actual light kernel.

Extract canonical weak/colored mixing, its exact eta-squared Schur scaling,
the conditional larger-root mass comparison, the updated small colored
principal necessary bound, and the conditional positive-Higgs Schur matrix.
No inversion or integration of phase-zero/gauge-orbit modes. A positive
direct quartic alone is not the relaxed quartic. Do not transport the old
light direction, positive limit, trial values or naturalness claims.

Independent verification: reconstruct physical coefficients directly from
the frozen point plus explicit current overrides and stationarity; use a
separate slot-dictionary differentiation/old-plus-eta-increment route to
check all retained polynomial coefficients and matrices. Check all three
weak/colored/conjugate blocks, source matrices, kinetic factors, Ward
identities and exact old specialization. This is verification of symbolic
transport from inherited tensors, not a fresh full-action tensor extraction
or external scientific endorsement. Shared action, ledgers, representation
premises, Python/SymPy and analyst remain explicit limitations.

Controls: omitted complex completion, wrong raw b^3 eta rescaling, wrong
identical differentiation factor, missing neutral source, wrong eta-squared
Schur scaling, incorrect kinetic metric and premature phase-source deletion.
The fixed-eta exclusion must remain true. Eta=0 recovery must test actual
zero mixing rather than predicted zeros used to omit terms. All outputs are
symbolic; no new numerical point, optimization, family or viability claim.

Inventory the remaining fixed quartic interactions by actual field content,
current coefficients and known screening coverage. Identify uncancelable
offdiagonal patterns and untested mixed blocks without computing a new full
scattering operator. Do not assert those interactions pass or fail without
their own evidence. Existing global/mixed stability and full scattering
gaps remain; the new necessary eta bound is not sufficient for viability.

Two sequential native roles only, each 120 seconds after imports, sampled
private allocation at most 8 GiB and directly observed prelaunch available
commit at least 350 MiB. A limit, failed check or missing prerequisite stops
qualification; no automatic additional attempt. Freeze source/input hashes
before execution. Audit workers read-only, preserve complete captures, and
require independent receipt plus raw staged/committed byte checks. Engineering
syntax/byte checks do not execute physics roles. No new replay pair claimed.

Output: exact symbolic input/condition result, concise disposition and next
smallest action. Capability finding is correctness/limits of symbolic
problem reformulation, not general autonomous physics reliability. Science
and AI-capability objectives remain equal; education voluntary/nonblocking.
Preserve project_state.json, sealed README, authority 34/39, custody exit 2
and seven references, all successes/failures including fixed-eta exclusion,
quartet failure, E5/A5 unqualified, HB1/C5 blocks, C1_GS gap and flavor pause.
No input adopted, blocked stage activated, remote action, publication or
outside personal participation. Any subsequent point search or benchmark
decision needs its separate director authority. Whole investigation incomplete.
