# Symbolic eta inputs V3 — qualification requires the corrected receipt

The mathematical result is the [original bounded symbolic transport](RESULT.md):
the weak/colored mixing is linear in eta, the Schur exchange is quadratic,
the neutral Hessian is unchanged, and direct Higgs/source interactions change.
Eta-variable feasibility remains **UNDERDETERMINED**. The old eta=3/10
comparison remains excluded. No new point, family or benchmark is selected.

This final gate is prospective. Qualification requires an actual
validation_receipt.json with schema ETA_VARIABLE_INPUT_VALIDATION_V2 and
status COMPLETED_AUTHORIZED_SYMBOLIC_ETA_TRANSPORT_AFTER_UTF8_CORRECTION,
the accepted independent_verifier_v2_capture.json, and exact raw staged and
committed byte checks. Without them, the result is unqualified. An intended
successful receipt is not evidence that the corrected worker has executed.

The [failed first verifier](independent_verifier_capture.json) and
[decoding disposition](RESULT_V2.md) remain preserved, together with all
original sources and bindings. The [V2 correction](CORRECTION_V2.md) changes
report reads to explicit UTF-8, preserves every mathematical assertion and
records one failed verifier plus one proposed corrected verifier. At the
preparation of this gate, the extra run is not authorized or launched.

The scientific interpretation, authority limits and remaining fixed z4/zK
screening priority are unchanged from the original result. No extra science
is performed to fix report decoding. Both the failed and corrected verifier
attempts must be counted; no fresh byte-identical pair is claimed.

State/README bytes, authority 34/39, custody exit 2/seven, all successful and
failed prior evidence, blocked stages and flavor pause remain unchanged.
Equal science/AI objectives and nonblocking education persist. The broad
investigation, physical viability and general AI reliability remain unproved.
