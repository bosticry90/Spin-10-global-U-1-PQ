# Symbolic eta extension: exact inputs recovered, feasibility unresolved

The director-authorized eta-variable extension has complete symbolic weak,
colored and local tree-Higgs inputs. Qualification requires the actual
[validation receipt](validation_receipt.json) and raw Git checks under the
[prospective contract](RECORD.md). The scientific disposition is
**UNDERDETERMINED**: these inputs do not establish a viable eta value or a
new positive-Higgs family. No parameter point, search or quantum loop was run.

In plain language: reducing the fixed interaction removes the previous
automatic exclusion only as a possibility. It also changes how the Higgs
mixes and interacts. We cannot keep the favorable parts of the old family
while changing eta and assume the combined result still works.

## Authorization, domain and preserved failure

The human selected “Authorize bounded eta-variable analysis” after reviewing
the [frozen-input exclusion and proposal](../canonical_so10_eta_offdiagonal_bound/PROPOSED_NEXT_SCOPE.md).
The existing action, representations, PQ charges, vacuum ratios and other
fixed inputs remain. The eight real quartics p1..p8 gain one real formal
coefficient eta, initially restricted to

```
0 < eta <= pi*sqrt(7/930).
```

That bound is necessary, not sufficient, for the stipulated asymptotic tree
screen. The old eta=3/10 comparison remains excluded. Eta=0 and eta=3/10
are exact reference specializations, not chosen replacement benchmarks.
No complex eta phase, input convention, quantum prescription or scientific
authority was adopted. The former analytic family also retains its separate
mixed-field instability; its old positive Higgs limit is not transferred.

## Exact mass dependence

Let s=p6+p7, and use the canonical weak and colored Sigma principal matrices
SW,SC and fixed phi matrices FW,FC from the qualified tensors. They do not
depend on eta. The reconstructed canonical mixing matrices are

```
BW = eta * [[0, -12*sqrt(3)*i/5],
            [0, 0]],
BC = eta * [[0, 0],
            [12*i/5, 0],
            [12*sqrt(2)*i/5, 0]].
```

The complete raw and canonical weak, colored and conjugate-colored matrices
are retained in [the symbolic output](primary_result.json), with their actual
kinetic metrics. Every old matrix entry is recovered exactly at eta=3/10,
including zero entries. At eta=0 the mixing vanishes by calculation. Other
interactions, neutral sources and phase identities do not disappear.

For positive SW and SC, the Schur complements give

```
mW = lambda_max(eta^2 * BW1^H * SW^-1 * BW1 - FW),
mC = lambda_max(eta^2 * BC1^H * SC^-1 * BC1 - FC),
BW1=BW/eta, BC1=BC/eta.
```

The declared simple light-Higgs branch has m=mphi2=mW. Strictly positive
colored masses require mW>mC. Equality would introduce an additional zero;
the branch and other spectrum conditions must be checked before using it.
The former eta=3/10 mass bounds cannot be copied unchanged.

The third colored Sigma direction has diagonal 24*s/5 and mixing squared
norm 288*eta^2/25. A small principal block therefore supplies the inexpensive
necessary condition

```
s>0,
m >= lambda_max(diag(12*eta^2/(5*s),0) - FC).
```

The unchanged selected contact ellipse implies s<=pi/6, hence the weaker
uniform lower bound replaces its first diagonal by 72*eta^2/(5*pi). These
are symbolic inequalities, not evidence that a common acceptable point exists.
The three stationarity-fixed mass coefficients and neutral Hessian remain
eta-independent. Phi has zero vacuum value, and the same representation
selection rules and qualified stationarity assumptions still apply.

## Higgs interactions must change consistently

All ten raw neutral source matrices, direct Higgs quartic, raw weak Hessian
and neutral Hessian are reconstructed from the retained action monomials.
Their dependence on eta is affine before choosing the actual light direction.
The eta monomial has 40 retained h4 rows, 48 h2n rows and 16 hh rows; its
neutral nn and n rows vanish. These counts refer to inherited complex
polynomial coefficient positions, not independent physical amplitudes.

Only neutral source matrices 1,8,9 change with eta in the declared basis.
The full eta derivative of the direct quartic is a nonzero polynomial;
the [output](primary_result.json) retains every coefficient. The actual
light direction also changes through H8(eta)*h=0. Holding the old h fixed
would not test the new light Higgs.

The same two neutral phase directions, indices 2 and 4, are not inverted.
At symbolic eta both actual gauge and PQ source Ward identities hold. They
force the phase sources to vanish on the exact light kernel; an off-kernel
phase source is nonzero and is explicitly retained as a control.

For positive neutral modes indexed [0,1,3,5,6,7,8,9], write their raw Hessian
as Hp, b_j(h)=h^T*C_j*h and N=h^T*G8*h. The exact conditional test remains

```
Hp>0 and [[Hp,b],[b^T,8*V4(h)]]>0,
lambda_relaxed = (4*V4(h) - b^T*Hp^-1*b/2)/N^2.
```

Completing the square checks the coefficient and eta-squared exchange
dependence. Positivity of V4 alone is insufficient. These are local classical
conditions, not quantum matching, global boundedness or naturalness.

## Remaining fixed interactions: screen before another search

The complete typed inventory contains 14 quartic monomials outside the eight
varied quartics. Eta is now variable; three inputs are zero; ten other fixed
quartics are nonzero. Full coefficients and field degrees are in the output.

| Field content | Current nonzero fixed coefficients | Screening implication |
| --- | --- | --- |
| Phi^2 phi^2 | lambdaPhiphi1=-1/500, lambdaPhiphi2=0.01943742 | Fixed mixed pair channels remain; not certified here |
| Sigma^2 phi^2 | lambdaSigmaphi1=0.00199571, lambdaSigmaphi2=-0.03517823 | Fixed mixed channels remain; zD=0 does not remove these |
| phi^4 | lambdaPhiVector1=lambdaPhiVector2=1/10 | Scalar-vector self channels require their normalization/completion |
| phi^2 S^2; S^4 | lambdaVectorS=0.00099786; lambdaS=1 | Singlet and portal channels remain |
| Phi Sigma^2 S | z4=-0.026467-0.03201845*i | Unique field content; fixed offdiagonal screen still needed |
| Phi phi^2 S | zK=0.03 | Unique field content; fixed offdiagonal screen still needed |

The three zero quartics are lambdaPhiS,lambdaSigmaS,zD. They are not omitted
from the inventory. No other quartic can cancel the complete z4 or zK
offdiagonal field-content block at the potential level. That observation is
not an operator-norm calculation or a perturbativity verdict. The two same-
content portals in other rows can interfere and must be combined correctly.
Gauge exchange, physical projection, normalization and any high-energy
limiting assumptions need their own explicit justification before a screen.

The smallest useful next calculation is a bounded canonical screen of the
still-fixed z4 and zK offdiagonal interactions, before a new parameter search
or a costly positive-Higgs feasibility proof. If another fixed interaction
already fails, eta variation cannot supply the sought perturbative benchmark.
If those selected screens pass, they still do not certify the full coupled
scattering operator. Mixed global stability, mass positivity and the combined
Higgs condition remain necessary unresolved questions. This increment's
two-role allowance does not execute that next screen or a point search.

## Validation and capability limits

One primary assembles all qualified monomials with the new symbolic raw eta
coefficient. The independent route reconstructs current physical coefficients
directly, separates the eta slot, and differentiates the old full tensors plus
their literal eta increment. It checks the three weak/color matrix blocks,
all 804 neutral-Higgs matrix component positions, quartic coefficients,
kinetics, exact reference recovery, Ward identities and completion of the
square. Counts include zeros and symmetry-related components.

The action ledgers are inherited qualified inputs. They are not a fresh
full-action extraction, a replay of the 328-field spectrum, or independent
physical verification of their assumptions. Both methods share the action,
VEV/representation/kinetic premises, some arithmetic, Python/SymPy and analyst.
Agreement is bounded computational corroboration, not outside endorsement.
No fresh byte-identical execution pair is claimed.

The two native roles have 120-second/8-GiB limits and directly observed
350-MiB prelaunch available commit. Exact source/input captures, actual
validation receipt and staged/committed bytes are required. Controls detect
missing Hermitian completion, wrong field rescaling, derivative/metric errors,
incorrect eta power and premature deletion of phase sources.

Track B demonstrates consistent symbolic transport and recognition that an
input change affects several linked conditions. It does not demonstrate a
successful model repair or general autonomous research capability. The earlier
prioritization failure motivates checking remaining fixed interactions first.
Science and AI-capability objectives remain equal; education is nonblocking.

All prior successes and failures, project_state.json, sealed README, authority
34/39, historical custody exit 2/seven references, quartet failure, E5/A5 gaps,
HB1/C5 blocks, C1_GS gap and flavor pause remain unchanged. Full investigation
completion, physical GUT viability and experimental support remain unproved.
