# Published global gauge-anomaly results and their applicability

**Disposition: inherited literature result with conditional applicability;
no new cobordism proof, global completion or scientific promotion.**

The pure Spin10 gauge/fermion anomaly question has an established answer in
specified spacetime/gauge classes. Reuse that knowledge rather than building
a new anomaly compiler. It does not repair the frozen benchmark or establish
the project's full quantum prescription.

## Question, evidence and scope

Baseline c0e66c847c5e8d54069d9619b54bd495900af81b. Actual preflight clean,
no matching A10/M08 workers, statev113/34of39 unchanged. The preceding
[local screen](../canonical_so10_local_gauge_anomaly/RESULT.md) was PROGRESS.
This review asks whether primary literature covers a remaining potential
global gauge obstruction for the declared3left16, without changing scalar
parameters or resuming flavor. The pending numerical proposal is separate.

Method: read the authors' versioned papers, match their hypotheses to the
frozen matter/statistics and distinguish them from the actual E5 integral.
Acceptance is correct attribution and explicit applicability, not a fresh
topological calculation. An unmatched global structure or extra symmetry
remains unresolved. No new physics computation is proposed or executed.
The local validation receipt authenticates this review and repository custody;
it cannot independently verify the published theorems.

[Wang, Wen and Witten, A New SU(2) Anomaly, v4](https://arxiv.org/pdf/1810.00844v4),
section5.1.3, treats Spin10 spinor fermions and tensor bosons using
(Spin(4)xSpin(10))/Z2. The possible w2*w3 obstruction has zero coefficient
for16: its Spin3 restriction comprises eight doublets. Three copies preserve
that result. This is a published argument, not a project reproduction of
zero modes or the cobordism classification.

[Wan and Wang, v4](https://arxiv.org/html/1910.14668v4),
section5.1/tables21-22, gives Omega5=0 and TP5=0 for ordinary spin spacetime
with honest Spin(n) gauge bundles, n>=7. Section5.3/tables25-26 distinguishes
the spin-charge quotient class, which permits a Z2 w2*w3 term. A classification
allowing that term does not mean every fermion representation realizes it.
The preceding16 result determines its coefficient in the cited case.

## Applicability to this project

| Item | Evidence and disposition |
| --- | --- |
| Three left-handed16s | Frozen Yukawa convention and local anomaly screen; matches the cited matter representation without a numerical fit |
| Bosons54,126,10,S | Tensor/singlet representations, even under the Spin10 two-pi central rotation; the inherited center-character record is compatible with the spin-charge assignment |
| Ordinary spin spacetime with Spin10 bundles | Pure gauge/fermion sector is covered by the cited classification under these hypotheses; the local Minkowski program is contained in this setting |
| Non-spin spin-charge extension | Published comparator is available; no project-wide global extension is adopted by this review |
| Global PQ and possible faithful combined quotient | Not a nonanomalous gauged U1. Its nonzero mixed traces and ordinary-field kernel remain as qualified; neither paper supplies this project's full PQ-background/bundle/defect classification |
| Additional time-reversal, unoriented or topological sectors | Not supplied or qualified here; do not import their conclusions from a different symmetry class |

Here Z2 identifies spacetime fermion parity with the two-pi Spin10 rotation;
it is not the ordinary-field Z4 center/PQ identification of the
[PQ calculation](../canonical_so10_pq_anomaly_screen/RESULT.md).
The latter deliberately did not choose allowed bundles or line operators.
No new faithful quotient, cosmology or global symmetry is selected.

The publications therefore provide inherited coverage for the stated pure
gauge/fermion question. It would be misleading both to claim a new project
global-anomaly proof and to pretend this standard case has no established
answer. The assumptions and the broader construction remain separate.

## Why full E5 and physical viability remain open

The actual [W1-W7 specification](../../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md)
integrates643 gauge/scalar/ghost/nonminimal fields, not physical16 matter.
Its E1 'gauge-fixing fermion' is an odd functional. The3*16 matter declaration
and published anomaly results are not an implemented matter determinant in
that functional integral. Adding matter to a future calculation needs its
own action, sources and acceptance; flavor remains human-paused.

| W1-W7 input | What this review does not establish |
| --- | --- |
| A1 | Gauge-fixed propagation, boundary/IR prescription and integration calculus |
| A2 | Project-specific local subtraction/QAP with all retained sources |
| A3 | Simultaneous restoration and triviality of every admitted breaking |
| A4 | Composite/contact insertion renormalization and mixing |
| A5 | Quantum field/source equivalence with Jacobian and operator transport |

The quartet-normalization mismatch is not removed by citing an anomaly theorem.
No scalar stability, scattering, tadpole, finite threshold, physical input or
experimental comparison changes. Anomaly compatibility is necessary consistency
information, not evidence that the selected benchmark describes nature.

## Continuation and verification limits

Do not spend resources re-proving the cited pure gauge theorem solely because
the earlier local screen correctly left globals unqualified. Further global
work needs a consequential unresolved structure and an explicit hypothesis
match. No additional generic anomaly calculation is currently justified by
this review. The next prioritized decision remains the
[bounded scalar feasibility proposal](../../docs/RESEARCH_DIRECTION_PROPOSAL_V1.md).
It has not launched and is not authorized by repeated automatic continuations.
Further independent work must remove a real dependency rather than accumulate
secondary checks around the same failed numerical point.

Verification: primary-source section/table review, frozen field/integral
comparison, link and byte checks, actual standard preflight and raw Git custody.
No new native/fresh calculation or independent reproof is claimed. Published
expertise is acknowledged; literature reuse and applicability assessment are
the bounded AI capability demonstrated, not general reliability or endorsement
of this model. Physics/AI objectives equal; education voluntary/nonblocking.
State34/39,quartetFAIL3960/648,E5/A5unqualified,HB1/C5blocked,C1_GSuncalculated,
full328BFB/naturalness,matter/flavorpause,custodyexit2/seven references preserved.
No frozen evidence change, blocked activation, domain/scheme adoption,
branch/worktree/reset, remote action/publication/outreach. Goal incomplete.
