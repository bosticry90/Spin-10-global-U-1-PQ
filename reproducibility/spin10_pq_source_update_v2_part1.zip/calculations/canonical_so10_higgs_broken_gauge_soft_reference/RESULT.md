# Broken-gauge/PQ reference: derivative terms required by soft matching

This reference tests the soft quadratic matching step for a broken Abelian
gauge theory with a light charged scalar and a physical PQ phase. It compares
a literal fixed-vacuum gauge-fixed Fourier Hessian with an EFT derived by
eliminating the same heavy fields. Qualification requires the final receipt
and raw custody checks, not this narrative alone.

The required tree EFT contains three derivative contributions: heavy-vector
current exchange, radial-relaxation kinetic energy, and a Higgs-dependent PQ
metric. A potential-only EFT omits all three. Matching is through two
derivatives on constant backgrounds; a nonzero four-derivative remainder is
retained. This is a reference calculation, not the actual Spin10 matching
functional, a finite one-loop threshold or a gauge-independence proof.

Use the [prospective contract](RECORD.md), [V3 implementation](reference_v3.py),
[V2 correction](IMPLEMENTATION_CORRECTION_V2.md),
[V3 runtime correction](IMPLEMENTATION_CORRECTION_V3.md), [exact data](original_result.json),
[validation receipt](validation_receipt.json), native captures and separate
raw Git custody. The failed original V1 ghost comparison and all its inputs
remain preserved.

The reference fields are Phi=(v+rho+i chi)/sqrt2, H=(x+i y)/sqrt2, and
S=r exp(i a/f)/sqrt2. Phi and H have Abelian gauge charges1 and q; S is
neutral. Global charges2,-2,-4 give a physical PQ phase in S after the gauge
phase is removed at the vacuum. The reference's unbroken gauge remnant is
trivial. It therefore does not test the actual non-Abelian residual-H BF
connection or its source identities.

Use D=partial-i g charge A and the fixed-vacuum gauge condition
F=div A-xi*g*v*chi, with Lfix=F2/(2xi). The FP operator is
-Box+xi*g2*v*(v+rho). It is independent of the H background in this gauge;
replacing it with a background-updated ghost mass changes the reference.
The same F is used in both tree heavy equations and the quantum Hessian.

The potential is

```text
V=lambdaPhi/4*(2|Phi|2-v2)^2
 +lambdaS/4*(r2-f2+beta*(x2+y2))^2
 +m2*(x2+y2)/2+lambdaH*(x2+y2)^2/4.
```

For positive reference parameters and R2=x2+y2<f2/beta, the zero-derivative
heavy branch is rho=chi=A=0, r_c=sqrt(f2-beta R2). There is no inverse mass
assigned to the physical phase a. The scalar potential on that branch is
m2 R2/2+lambdaH R2^2/4.

The leading heavy-vector response is determined by its current:

```text
J_mu=x partial_mu y-y partial_mu x,
A_mu,c=q*J_mu/[g*(v2+q2 R2)]+higher derivatives.
```

Substitution gives -q2 J2/[2(v2+q2 R2)]. Radial relaxation also contributes
( partial r_c )2/2, and the PQ term inherits r_c2/f2. Together,

```text
L_EFT,2= [(partial x)2+(partial y)2]/2
 +beta2*(x partial x+y partial y)^2/[2(f2-beta R2)]
 -q2*J2/[2(v2+q2 R2)]
 +(1-beta R2/f2)*(partial a)2/2.
```

Derivative corrections to the heavy radial solutions first change the
four-derivative action: their leading potential EOM already vanish. Maxwell
and gauge-fixing contributions to the leading A_c likewise enter at higher
derivative order here. This reasoning does not remove the gauge fixing from
the quantum operator.

At x=h,y=a=0 and r0^2=f2-beta h2, the three light kinetic coefficients are

```text
Z_x=1+beta2*h2/r0^2,
Z_y=v2/(v2+q2*h2),
Z_a=r0^2/f2.
```

The literal two-orientation14-real Hessian contains A_long,rho,chi,delta_r,
delta_x,delta_y,delta_a. Its Hermitian7-position representation retains the
imaginary longitudinal/light-phase mixing +/-i g q h k and real radial/light
mixing2lambdaS beta r0 h. The two representations must preserve the real
quadratic pairing, conjugation and orientation count. The transverse vector
operator is k2+g2(v2+q2h2), with d-1 multiplicity retained symbolically;
no finite vector integral is evaluated at d=4.

Write z=k2, Ms2=2lambdaS r0^2 and Dv=v2+q2h2. Exact elimination gives

```text
Q_x=m2+3lambdaH*h2+z*Z_x
 -beta2*h2*z2/[r0^2*(z+Ms2)],
Q_y=m2+lambdaH*h2+z*Z_y
 +q2*h2*z2/[Dv*(z+xi*g2*Dv)],
Q_a=z*Z_a.
```

Thus the EFT Hessian and soft Schur complement agree through z. The displayed
remainders begin at z2 and are retained, including the xi dependence. The
expansion assumes momentum below the heavy gaps; it is not uniform as g or
xi approaches0 or r0 approaches0. The calculation does not claim finite-momentum equality, a full arbitrary-background
one-loop soft functional or cancellation of all gauge-dependent observables.
It establishes a concrete prerequisite for the matching argument at this order.

At the declared control point h=1,v=2,f=3,beta=1/2,q=1, removing the radial,
current or PQ kinetic operators changes the respective metric by -1/34,+1/5,
+1/18. Reversing the current term gives a2/5 discrepancy. All are actual
nonzero reference errors, not allowed simplifications.

For m2=lambdaH=0, the mixed longitudinal/light-phase determinant reduces to
z*(z/xi+g2v2), independent of h. Goldstone and one complex FP ghost pair
have the correct relative Gaussian weights. Because this ghost is independent
of h, its omission is tested by a derivative with respect to the vacuum
vector mass rather than an h4 test. At the specified unit-momentum control,
that derivative is +1/5 if the ghost is omitted and -1/5 if doubled. Omitting
the longitudinal mixing creates a -1/100 h4 mode-density error; assigning the
background-updated ghost gives +1/50. The ghost control changes only that operator while retaining the fixed-vacuum
bosonic Gaussian; it is not a comparison of two consistently changed gauges.
These controls are unintegrated reference quantities, not Spin10 pole
coefficients or finite thresholds.

The S polar-coordinate measure matters to this comparison. For the same
local coordinate prescription in UV and EFT,

```text
phase Gaussian normalization: +(1/2) log(r0^2/f2),
local polar Jacobian:         -log(r0/f),
sum:                         0.
```

Omitting the Jacobian leaves an h4 mode coefficient -1/1296 in the control.
Its integral is proportional to the scaleless integral of1 in dimensional
regularization. It is not a physical potential correction. This local Gaussian
check is not a global gauge/measure or anomaly calculation for Spin10.

The methodological comparator is
[Thomsen2404.11640v2](https://arxiv.org/html/2404.11640v2), section4.2,
which uses the same heavy partial fixing in tree EOM and fluctuations before
identifying the soft Schur operator with EFT loops. This reference tests that
necessary relation in a deliberately explicit broken-U1 case. It does not
supply the missing non-Abelian, quantum/source or measure assumptions for
the actual Spin10 model.

Accepted V3 original/fresh outputs are byte-identical, SHA256
490a877f90c050f2ee19bcf062e678b23b543fe28fcc8766f6a0481e4bc1e9c2,
21964bytes each. After-import times1.815/1.880sec;
maximum sampled private52174848/50606080bytes are samples, not certified
instantaneous peaks. Both immediate350MiB launch and8GiB sampled caps passed.
The frozen900sec after-import ceiling is unchanged. The earlier V2 original
completed in497.260sec, but its fresh worker exceeded the ceiling and was
stopped only after exact process/creation/command verification. Its complete
capture is classified resource-incomplete, not a coefficient mismatch. V1
original was an engineering failure. Thus two raw FAILED worker captures
are preserved: one failed FP assertion and one resource-incomplete fresh run;
no final validation run has failed. V2 is not an accepted fresh pair.
V3 uses rational cancellation in place of expensive generic factorization.
It changes no mathematical condition, physical input, gauge, resource cap,
precision or tolerance. Final validation compares every serialized rational
matrix/expression to the completed V2 original by exact residuals, in addition
to the distinct rational-energy tests.
Final validation must independently reconstruct all14 Fourier positions by
rational quadratic-energy stencils after delta_r=r0*tau congruence, eliminate
heavy fields with Fraction arithmetic at27 exact points, check general metric/
remainder identities, gauge variation, ghost/measure and wrong-operator
controls,54 high-precision probes, source/input/resource/report/state/prior
receipts and raw Git bytes. No old physics loops or whole metadata audit.
The read-only stack diagnosis on the fresh worker identifies costly SymPy
multivariate factorization in Schur reconstruction. The first trace request
found the original process already terminal; the same original handle then
confirmed completion. The profiler was installed only in the external control
directory and is not imported by either science worker or a required
reproduction dependency. Preserve its installation/trace records as diagnostic
evidence, not scientific validation.

The original V1 worker failed on structural FP equality; its exact expanded
residuals were both0. V2 changes that assertion to an exact residual check; V3 replaces generic
factorization with rational cancellation. Both retain the same action,
operator, signs, controls and tolerances.

The existing [mixed stability screen](../canonical_so10_mixed_bfb/RESULT.md)
was recovered for this priority decision. It proves the308-dimensional sector
and preserves the unsuccessful full sufficient bound; its fixed eta/joint-phase
ray families found no negative witness. Repeating those same profiles or
auxiliary weights would add little. A tighter full328 correlation remains an
open alternative, with no newly justified cheap exclusion identified here.
This is reuse of earlier evidence, not a new BFB test or global pass.

The reference is useful only if it leads back to the actual theory. The next
smallest actual-model calculation is the leading Higgs-current derivative
operator from heavy-vector exchange. Use the exact light plane, all45 actual
generator currents and the broken/unbroken projection with the physical
metric; retain the12 light gauge directions rather than inverting their zero
masses. This can provide an action-derived tree EFT input without a finite
loop integral or new model parameter. Freeze its tensor/coordinate obligations
before execution. Scalar/PQ higher response and exact-u input transport remain
separate where needed. Reassess full328 stability and gauge-mismatch cost/
information before substantial loop expansion; do not add reference models
indefinitely because unfinished implementation tasks exist.

Track A gains a tested broken-gauge soft-operator interface and explicit
missing derivative terms. Track B gains a reference anchored to a published
matching criterion, actual negative controls and recognition of coordinate/
measure scope limits. Shared action, software, derivation choices and analyst
remain common-error risks, not external expert endorsement or general AI
reliability. The known structural-equality failure is preserved as an
implementation limitation. Scientific/AI objectives remain equal; education
voluntary, concurrent and nonblocking. Director controls consequential schemes.

Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.
Prior finite/tree/PQ/IR qualifications and failures preserved. Full328BFB/
naturalness,matter/phenomenology,quartetFAIL3960/648,E5/A5unqualified,HB1/C5
blocked,C1_GSuncalculated,flavor pause,custodyexit2/seven unresolved unchanged.
No actual action,benchmark,gauge,scheme,authority or state promotion; no
activation,branch/worktree/reset,remote action,publication or outreach.
Whole goal active/incomplete.
