# Reference implementation correction V3: rational cancellation and runtime

V2 original completed with exact reference checks,497.260seconds after imports,
maximum sampled private174219264bytes, RESULT SHA256
7aeba05bf8e4186700f75c6756b9072cf26dc6f34ded3956ad851c40ce8af42a.
Its full capture and output remain original_v2_capture.json/original_v2_result.json.
Its fresh reproduction remained in SymPy multivariate factorization and exceeded
the frozen900second limit. At939.893wallseconds/935.531CPUseconds the parent
verified PID2976, exact creation filetime134365903010929408 and the full declared
reference_v2.py command before stopping only that worker. The runtime record and
fresh_v2_incomplete_capture.json remain preserved. The capture's FAILED exit
after external termination is classified scientifically INCOMPLETE_RESOURCE,
not a coefficient mismatch. No RESULT or fresh acceptance came from that run.

Read-only py-spy0.4.2 stack observation identified factor() at the Schur
reconstruction. The profiler is installed only in the external control directory
and is not a scientific runtime dependency. Preserve installation, both stack
attempt records, and the CPU/runtime record. The first stack request found the
original worker terminal; the same handle subsequently confirmed its completed
output. The second observed the live fresh worker. No duplicate old worker was
launched, and no incomplete expression was promoted.

reference_v3.py replaces s.factor by s.cancel at rational-expression reduction
and formatting sites. The prior V2 FP residual correction remains. All affected
expressions are rational at reduction (logarithms are differentiated and h=0
substituted before reduction). Cancellation proves the same exact rational
identities without asking for irreducible multivariate factors. The action,
variables, signs, gauge, branch, Schur target, derivative order, resource cap,
negative controls, numeric precision and1e-80 tolerances are unchanged. The
reference is not changed to fit a failure. Frozen V1/V2 sources, preparations,
plans, failed/incomplete/complete captures and pre-V3 draft reports remain.

Freeze new V3 source/copy, runner and inputs before execution. Require a complete
byte-identical V3 original/fresh pair. Compare every serialized V3 mathematical
matrix and rational expression with the completed V2 original by exact residuals;
formatting and input-binding bytes may differ. Numeric probe residual strings
may differ under equivalent evaluation order, but their original requirements
remain. Do not call V2 a fresh byte-identical pair. Final independent Fraction
stencil/elimination, general identities and controls remain mandatory. No actual
Spin10 calculation or authority/gauge/scheme is promoted. See RECORD.md.
