# Reference implementation correction V2: exact ghost identity

The first original worker ended FAILED with exit1 at its FP matrix comparison.
It had already established the literal potential Hessian and exact equality
between14-real and7-Hermitian Gaussian matrices. The ghost expression was
expanded while the expected expression was factored, so structural Matrix ==
returned false. The preserved diagnostic expands their difference to [0,0].
No RESULT was emitted and no scientific comparison was accepted.

Preserve reference.py, reference.py.source.txt, preparation_v1_failed.json,
execution_plan_v1_failed.json and failed_original_attempt_1_capture.json.
The external original_full_capture.json is the same complete failed capture;
run.py and its source copy are unchanged. External failure_diagnostic_1.json
records the exact zero residuals. The failed original is not a fresh pass.

reference_v2.py changes only the FP assertion to
(varfix+fp*ghostpar).applyfunc(expand)==zeros(2,1).
The expected operator, sign, action, gauge, derivative order, controls,
precision and tolerances are unchanged. Versioned V2 worker/runner copies,
new preparation and execution plan are frozen before execution. Original and
fresh accepted roles use separate external v2 capture filenames, preserving
the failed original. Report one failed calculation worker in addition to any
later outcomes. This is an implementation correction, not a fitted scientific
repair, new gauge choice, waived test or theory result.
