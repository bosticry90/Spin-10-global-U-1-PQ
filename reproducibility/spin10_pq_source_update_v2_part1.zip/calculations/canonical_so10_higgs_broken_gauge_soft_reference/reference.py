"""Literal broken-U1 Fourier Gaussian versus tree EFT with a physical PQ mode."""
from pathlib import Path
from hashlib import sha256
import sys,json,time,platform
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
textmat=lambda A:[[str(s.factor(z)) for z in row] for row in A.tolist()]

def calculate():
    k,z,g,q,v,f,r,xi,lp,ls,lh,beta,m2=s.symbols('k z g q v f r xi lp ls lh beta m2',positive=True);h=s.symbols('h',real=True)
    rho,chi,ss,xx,yy,aa=s.symbols('rho chi ss xx yy aa',real=True);fields=[rho,chi,ss,xx,yy,aa]
    R=(h+xx)**2+yy**2
    V=lp*((v+rho)**2+chi**2-v*v)**2/4+ls*((r+ss)**2-f*f+beta*R)**2/4+m2*R/2+lh*R**2/4
    zero=dict.fromkeys(fields,s.S.Zero);V2=s.hessian(V,fields).subs(zero).subs(f*f,r*r+beta*h*h).applyfunc(s.simplify)
    assert s.diff(V,rho).subs(zero)==0 and s.diff(V,ss).subs(zero).subs(f*f,r*r+beta*h*h).simplify()==0
    mphi=2*lp*v*v;ms=2*ls*r*r;mix=2*ls*beta*r*h;ux=m2+3*lh*h*h+2*ls*beta*beta*h*h;uy=m2+lh*h*h
    want=s.diag(mphi,0,ms,ux,uy,0);want[2,3]=want[3,2]=mix;assert (V2-want).applyfunc(s.simplify)==s.zeros(6)
    variables=s.symbols('Ac As rhoc rhos chic chis sc ss xc xs yc ys ac aas',real=True);vec=[s.Matrix(variables[2*j:2*j+2]) for j in range(7)];A,rr,ch,sr,x,y,a=vec;D=s.Matrix([[0,k],[-k,0]])
    kin=[D*rr,D*ch-g*v*A,D*sr,D*x,D*y-g*q*h*A];density=sum(b.dot(b) for b in kin)/2+r*r/(2*f*f)*(D*a).dot(D*a)
    fix=D*A-xi*g*v*ch;density+=fix.dot(fix)/(2*xi)
    scalar=[rr,ch,sr,x,y,a]
    density+=sum(V2[i,j]*scalar[i].dot(scalar[j]) for i in range(6) for j in range(6))/2
    KR=s.hessian(s.expand(density),variables).applyfunc(s.simplify)
    M0=g*g*v*v;MV=g*g*(v*v+q*q*h*h);KL=k*k/xi+MV;fp=k*k+xi*M0
    KC=s.diag(KL,k*k+mphi,k*k+xi*M0,k*k+ms,k*k+ux,k*k+uy,r*r/f**2*k*k);KC[0,5]=s.I*g*q*h*k;KC[5,0]=-s.I*g*q*h*k;KC[3,4]=KC[4,3]=mix
    real=s.zeros(14)
    for i in range(7):
        for j in range(7):
            u,w=s.re(KC[i,j]),s.im(KC[i,j]);real[2*i:2*i+2,2*j:2*j+2]=s.Matrix([[u,-w],[w,u]])
    assert (KR-real).applyfunc(s.simplify)==s.zeros(14) and KC==KC.conjugate().T and KC[:4,:4]==s.diag(*[KC[i,i] for i in range(4)])
    ghostpar=s.Matrix(s.symbols('wc ws'));varfix=D*(D*ghostpar)-xi*g*v*(g*v*ghostpar);assert varfix==-fp*ghostpar
    Schur=(KC[4:,4:]-KC[4:,:4]*KC[:4,:4].inv()*KC[:4,4:]).applyfunc(lambda x:s.factor(x.subs(k*k,z)))
    rh2=f*f-beta*h*h;Schur=Schur.applyfunc(lambda x:s.factor(x.subs(r*r,rh2)));assert Schur==s.diag(*[Schur[i,i] for i in range(3)])
    X,Y,dx,dy,da,B=s.symbols('X Y dx dy da B',real=True);R2=X*X+Y*Y;rc=s.sqrt(f*f-beta*R2);J=X*dy-Y*dx;vector=g*g*(v*v+q*q*R2)*B*B/2-g*q*B*J;Bc=s.solve(s.diff(vector,B),B)[0]
    assert s.factor(Bc-q*J/(g*(v*v+q*q*R2)))==0
    induced=vector.subs(B,Bc);dr=s.diff(rc,X)*dx+s.diff(rc,Y)*dy;Leff=(dx*dx+dy*dy+dr*dr)/2+induced+rc*rc*da*da/(2*f*f)
    Zeff=s.hessian(Leff,[dx,dy,da]).subs({X:h,Y:0}).applyfunc(s.factor);Zwant=s.diag(1+beta*beta*h*h/rh2,v*v/(v*v+q*q*h*h),rh2/(f*f));assert (Zeff-Zwant).applyfunc(s.factor)==s.zeros(3)
    Veff=m2*R2/2+lh*R2*R2/4;mass=s.hessian(Veff,[X,Y]).subs({X:h,Y:0});EFT=z*Zeff+s.diag(mass[0,0],mass[1,1],0)
    low=Schur.applyfunc(lambda x:s.factor(x.subs(z,0)+z*s.diff(x,z).subs(z,0)));assert (low-EFT).applyfunc(s.factor)==s.zeros(3)
    remainder=(Schur-EFT).applyfunc(s.factor);expected_remainder=s.diag(-beta**2*h**2*z**2/(rh2*(z+2*ls*rh2)),q*q*h*h*z*z/((v*v+q*q*h*h)*(z+xi*g*g*(v*v+q*q*h*h))),0)
    assert (remainder-expected_remainder).applyfunc(s.factor)==s.zeros(3)
    detAL=s.factor(KC.extract([0,5],[0,5]).det().subs(k*k,z));detSX=s.factor(KC.extract([3,4],[3,4]).det().subs(k*k,z))
    assert s.factor(detAL-(z/xi+MV)*(z+uy)+g*g*q*q*h*h*z)==0 and s.factor(detAL.subs({m2:0,lh:0})-z*(z/xi+M0))==0
    m0=s.symbols('m0',positive=True);fg=z+xi*m0;unphysical=s.log(z*(z/xi+m0))/2+s.log(fg)/2-s.log(fg);assert s.factor(s.diff(unphysical,m0))==0
    omitghost=s.factor(s.diff(unphysical+s.log(fg),m0));doubleghost=s.factor(s.diff(unphysical-s.log(fg),m0));unit={z:1,xi:1,m0:4}
    assert omitghost.subs(unit)==s.Rational(1,5) and doubleghost.subs(unit)==-s.Rational(1,5)
    h4=lambda expr:s.factor(s.diff(expr,h,4).subs(h,0)/24)
    drop=h4(s.log((z/xi+m0+g*g*q*q*h*h)*z)/2-s.log(z*(z/xi+m0))/2).subs({**unit,g:1,q:1});updated=h4(-s.log(fg+xi*g*g*q*q*h*h)+s.log(fg)).subs({**unit,g:1,q:1})
    assert drop==-s.Rational(1,100) and updated==s.Rational(1,50)
    metric=s.log(1-beta*h*h/(f*f))/2;jacobian=-s.log(1-beta*h*h/(f*f))/2;assert s.expand(metric+jacobian)==0
    measure_control=h4(metric).subs({beta:s.Rational(1,2),f:3});assert measure_control==-s.Rational(1,1296)
    point={g:1,q:1,v:2,f:3,beta:s.Rational(1,2),lp:s.Rational(3,2),ls:2,lh:s.Rational(1,3),m2:s.Rational(1,100)};control={**point,h:1};zz=[s.factor(Zeff[i,i].subs(control)-1) for i in range(3)]
    assert zz==[s.Rational(1,34),-s.Rational(1,5),-s.Rational(1,18)]
    args=[k,g,q,v,f,r,xi,lp,ls,lh,beta,m2,h];realnum=s.lambdify(args,KR,'mpmath');eftnum=s.lambdify([z,g,q,v,f,xi,lp,ls,lh,beta,m2,h],EFT,'mpmath');remnum=s.lambdify([z,g,q,v,f,xi,lp,ls,lh,beta,m2,h],remainder,'mpmath');checks=[]
    for precision in [120,160]:
        mp.mp.dps=precision
        for hh in [mp.mpf(0),mp.mpf(1)/3,mp.mpf(2)/3]:
            for gauge in [mp.mpf(1)/2,mp.mpf(1),mp.mpf(2)]:
                for momentum in ['1e-3','1e-6','1e-9']:
                    zn=mp.mpf(momentum);rn=mp.sqrt(9-hh*hh/2);kr=realnum(mp.sqrt(zn),1,1,2,3,rn,gauge,mp.mpf(3)/2,2,mp.mpf(1)/3,mp.mpf(1)/2,mp.mpf(1)/100,hh);H=kr[:8,:8];light=kr[8:,8:]-kr[8:,:8]*(H**-1)*kr[:8,8:]
                    en=eftnum(zn,1,1,2,3,gauge,mp.mpf(3)/2,2,mp.mpf(1)/3,mp.mpf(1)/2,mp.mpf(1)/100,hh);rn2=remnum(zn,1,1,2,3,gauge,mp.mpf(3)/2,2,mp.mpf(1)/3,mp.mpf(1)/2,mp.mpf(1)/100,hh);target=mp.zeros(6)
                    for i in range(3):target[2*i,2*i]=target[2*i+1,2*i+1]=en[i,i]+rn2[i,i]
                    error=max(abs(x) for x in light-target)/(1+max(abs(x) for x in target));assert error<mp.mpf('1e-80') and min(H[i,i] for i in range(8))>0
                    checks.append({'precision':precision,'h':mp.nstr(hh,80),'xi':mp.nstr(gauge,10),'z':momentum,'normalized_full_matrix_vs_EFT_plus_remainder_error':mp.nstr(error,30),'minimum_heavy_diagonal':mp.nstr(min(H[i,i] for i in range(8)),30)})
    return {'field_order':['A_long','rho','chi','delta_r','delta_x','delta_y','delta_a'],'potential_Hessian':textmat(V2),'real_Fourier_Hessian14':textmat(KR),'Hermitian_Gaussian7':textmat(KC),'FP_operator':str(fp),'transverse_vector_operator':str(k*k+MV),'transverse_multiplicity':'d-1','light_Schur':textmat(Schur),'tree_EFT_kinetic':str(s.factor(Leff)),'tree_vector_solution':str(s.factor(Bc)),'tree_EFT_kinetic_metric':textmat(Zeff),'tree_EFT_quadratic_operator':textmat(EFT),'exact_higher_derivative_remainder':textmat(remainder),'soft_correspondence_through_two_derivatives_exact':True,'complete_one_loop_soft_functional_proved':False,'flat_longitudinal_light_determinant':str(s.factor(detAL.subs({m2:0,lh:0}))),'radial_light_determinant':str(detSX),'negative_controls':{'omit_radial_kinetic_metric_difference':'-1/34','omit_current_metric_difference':'1/5','omit_PQ_metric_difference':'1/18','wrong_sign_current_metric_difference':'2/5','omit_gauge_light_mixing_h4_mode':'-1/100','background_updated_ghost_h4_mode':'1/50','omit_ghost_mass_derivative':'1/5','double_ghost_mass_derivative':'-1/5','omit_PQ_Jacobian_h4_mode':'-1/1296'},'PQ_Gaussian_metric_plus_local_Jacobian_exact_zero':True,'Jacobian_control_is_scaleless_mode_density_not_physical_threshold':True,'reference_parameters':{str(key):str(value) for key,value in point.items()},'numeric_probes':checks,'no_reference_finite_integral_executed':True,'reference_remnant_gauge_group':'trivial','actual_nonAbelian_H_or_Spin10_soft_correspondence_proved':False}

def main():
    started=time.perf_counter();prep=read(OUT/'preparation.json');writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('BROKEN_GAUGE_SOFT_REFERENCE_WRITE_DENIED')
    sys.addaudithook(readonly)
    for n,h in prep['input_sha256'].items():assert digest(ROOT/n)==h,n
    print('STAGE literal_fixed_vacuum_Fourier_Hessian_ghost_and_tree_EFT_soft_comparison',flush=True);data=calculate()
    for n,h in prep['input_sha256'].items():assert digest(ROOT/n)==h,n
    assert not writes and time.perf_counter()-started<900,'EFFORT_BOUNDARY_INCOMPLETE'
    result={'schema':'BROKEN_GAUGE_SOFT_REFERENCE_CALCULATION_V1','status':'COMPLETE_REFERENCE_SOFT_QUADRATIC_CORRESPONDENCE_THROUGH_TWO_DERIVATIVES','reference':data,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'new_Spin10_action_derivatives':0,'actual_Spin10_finite_integrals_executed':False,'actual_Spin10_soft_matching_proved':False,'physical_scheme_adopted':False,'actual_gauge_fixing_changed':False,'full_quantum_restoration_proved':False,'physical_Higgs_matching_complete':False,'scientific_authority_changed':False,'write_attempts':writes,'whole_goal_complete':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-started,'python':platform.python_version(),'sympy':s.__version__,'mpmath':mp.__version__},sort_keys=True),flush=True)
if __name__=='__main__':main()
