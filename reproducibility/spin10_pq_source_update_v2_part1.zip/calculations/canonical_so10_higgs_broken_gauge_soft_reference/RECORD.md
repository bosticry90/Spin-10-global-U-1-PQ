# Broken-gauge/light-PQ soft-operator reference V1

Baseline3480edf3fbe8db30ebc70ee437ea455a6cab54d3. Previous goal turn PROGRESS:
actual local PQ quotient and scalar mixed-loop subtraction. Read-only preflight
clean,no matching workers. Statev113/34of39 SHA256
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.

Physics decision enabled: does fixed-vacuum heavy gauge fixing yield the same
soft quadratic operator as tree elimination when light charged and physical
PQ fields remain? Current blocker: the previous scalar reference does not
exercise broken-vector/Goldstone/ghost propagation or derivative EFT terms.
Existing tools: SymPy literal Fourier Hessians and exact rational stencils;
no existing reference includes this entire combination. Minimum new surface:
one bounded reference worker, existing capture/validation machinery.
No actual Spin10 action change, scheme adoption or threshold integration.

Use Euclidean U1, coupling g>0, complex Phi=(v+rho+i chi)/sqrt2 with gauge
charge1, complex H=(x+i y)/sqrt2 with gauge charge q, and gauge-neutral
S=r exp(i a/f)/sqrt2. Global charges2,-2,-4 for Phi,H,S give a broken PQ
symmetry whose vacuum quotient tangent is the S phase. These are reference
fields, not substituted Spin10 representations. Gauge D=partial-i g charge A.
Potential
V=lambdaPhi/4*(2|Phi|2-v2)^2
 +lambdaS/4*(r2-f2+beta*(x2+y2))^2
 +m2/2*(x2+y2)+lambdaH/4*(x2+y2)^2.
Positive couplings, v,f>0,beta>0, branch x2+y2<f2/beta.
Fixed-vacuum F=div A-xi*g*v*chi, Lfix=F2/(2xi), xi>0.
Ghost from -deltaF is -Box+xi*g2*v*(v+rho), independent of H background.
Keep this same F in tree heavy EOM and full Fourier operator. Use canonical
Phi,H and polar S metric; include the local r/f Jacobian explicitly.

At constant x=h,y=a=0, rho=chi=A=0 and r0=sqrt(f2-beta*h2), derive the
potential Hessian before imposing the radial EOM. It has heavy radial mass
Ms2=2lambdaS*r02, mixed radial-H coupling2lambdaS*beta*r0*h, heavy Phi
radial mass2lambdaPhi*v2, light masses m2+3lambdaH*h2 and m2+lambdaH*h2
after Schur elimination. Derive, rather than assume, all entries.
Use real cosine/sine derivative D=[[0,k],[-k,0]]. Hessian over14real positions
(A,rho,chi,delta_r,delta_x,delta_y,delta_a) each with2 Fourier orientations.
Compare to an independently assembled Hermitian7x7 operator by exact
realification; retain longitudinal mixing +/-i g q h k. Transverse vectors
have k2+g2(v2+q2h2), multiplicity d-1 retained symbolically. No vector finite
integral or d=4 finite subtraction is claimed. Auxiliary elimination contributes
only its declared field-independent normalization in this Gaussian reference.

Compute exact heavy Schur complement (A,rho,chi,delta_r heavy, x,y,a light).
Derive the tree action through two derivatives from the same heavy EOM:
R2=x2+y2, J=x partial y-y partial x,
r_c=sqrt(f2-beta R2),
A_c=q J/[g(v2+q2 R2)]+higher derivatives,
L_EFT2=1/2[(partial x)2+(partial y)2]
 +beta2/(2*(f2-beta R2))*(x partial x+y partial y)^2
 -q2/(2*(v2+q2 R2))*J2
 +1/2*(1-beta R2/f2)*(partial a)2.
V_EFT=m2 R2/2+lambdaH R2^2/4.
Leading radial Phi=0; derivative-induced corrections affect four-derivative
terms, because the zeroth-order heavy potential EOM vanish. Do not omit the
radial gradient, current-current or PQ metric operator. Compute the EFT
quadratic Hessian from this action, not by defining it to equal the Schur block.

Require exact Schur/EFT equality through k2 at arbitrary constant h on the
branch. Serialize the full rational remainders starting at k4; do not claim
exact finite-momentum equality. This tests the prerequisite soft quadratic
correspondence on constant backgrounds through two derivatives. It does not
prove the complete one-loop soft functional, arbitrary varying backgrounds,
higher operators, non-Abelian residual-H BF/source identities or full hard
matching. Gauge parameter dependence in the higher remainder is preserved.
No demand to force it to zero or fit it away.

Check the flat-light-potential m2=lambdaH=0 longitudinal+Hphase determinant:
full mixing must remove its h dependence. Retain Goldstone and one complex
FP ghost pair with their actual weights. Check ghost omission/doubling by a
mass-derivative test, since this fixed-vacuum ghost has no h dependence.
Dropping longitudinal mixing or replacing its ghost by a background-updated
mass must fail selected mode-density controls. These are reference controls,
not Spin10 poles or finite physical coefficients.

For polar S at constant h, the Gaussian phase metric factor and local Jacobian
satisfy 1/2 log(r02/f2)-log(r0/f)=0. Compare radial/phase measure consistently
between UV/EFT in this local coordinate convention. Do not promote an omitted
Jacobian mode-counting artifact to a potential threshold; the associated
integral of1 is scaleless in dimensional regularization. A global gauge/quantum
measure proof for Spin10 is not inferred.

Freeze reference g=q=1,v=2,f=3,beta=1/2,lambdaPhi=3/2,lambdaS=2,
lambdaH=1/3,m2=1/100. Background h=0,1/3,2/3; xi=1/2,1,2;
probe z=k2=1e-3,1e-6,1e-9 at120/160digits. Independently invert the full
heavy matrix and compare the light operator and exact rational remainder
with normalized error<1e-80. Check all heavy eigenvalues positive at probes.
Exact control point h=1,xi=g=q=1,v=2,f=3,beta=1/2 may be used for compact
operator/mode coefficients. No expected nonzero coefficient is silently
replaced by zero. Resource limits classify incomplete, not truncation.

Independent final validation: exact rational quadratic-energy stencils on
both Fourier orientations after delta_r=r0*tau congruence (r02 rational),
Fraction Gaussian elimination, direct current/radial/PQ EFT kinetic Hessian,
Schur remainders, literal gauge variation, determinant/multiplicity controls,
measure cancellation and input/source/resource/report/state/prior receipts.
Meaningful wrong-sign/omitted-operator controls required. Original/fresh
read-only -B native outputs byte-identical; freeze sources/input hashes before
execution. Immediate available commit350MiB, sampled private cap8GiB,
900sec after imports, preserve every failure/incomplete run. Raw Git bytes
before local commit; no old expensive physics replay/whole metadata audit.

Comparator: Thomsen2404.11640v2, section4.2 (tree gauge-fixed EOM and soft
Schur correspondence). In this reference the unbroken remnant is trivial;
there is no test of the actual non-Abelian H BF connection. Use the paper's
conditional identity, not a claim of extending its theorem or independent
external endorsement. Prior scalar-reference finite subtraction stays scoped.

Structure preservation: exact real Fourier to Hermitian map preserves quadratic
pairing, conjugation and orientation counting. Tree elimination preserves the
reference EOM and kinetic/potential tensors through the declared derivative
order only; nonzero higher remainders are retained. Do not transfer full gauge
or source authority from an invertible matrix or a reference cancellation.
Shared reference action, software and analyst remain common-error limits.

Stopping condition: bounded reference correspondence through two derivatives
or preserved failure/inconclusive result. If it fails, no repair by changing
reference action, gauge or target; nothing deleted/deactivated. If it passes,
return to actual-model dependency/priority assessment rather than indefinitely
adding reference models. Gauge/scalar actual integral still needs exact-u
transport, compatible light/PQ operators, finite inputs/field normalization,
UV/EFT/source/measure obligations and authorizations. Compare cost/information
with full328 stability and direct gauge mismatch before expensive expansion.

Keep equal physics/AI objectives, voluntary concurrent nonblocking education,
director authority, statev113/34of39, prior qualifications/failed evidence,
full328BFB/naturalness,quartetFAIL3960/648,E5/A5unqualified,HB1/C5blocked,
C1_GSuncalculated,flavor pause,matter/phenomenology,custodyexit2/seven unresolved.
No state,action,benchmark,gauge,scheme or authority promotion; no activation,
branch/worktree/reset,remote action,publication or outreach. Goalactive/incomplete.
