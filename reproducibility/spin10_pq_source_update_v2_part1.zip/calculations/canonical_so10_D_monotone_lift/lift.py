"""Exact T norm Gram for D monotonicity; sparse rational coefficients only."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import ast,json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_scalar_reconstruction'));import certify_sigma_quartics as qs
from verify_eta1_doublet_mixing import vacuum_form
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(F(),F());add=lambda a,b:(a[0]+b[0],a[1]+b[1]);sub=lambda a,b:(a[0]-b[0],a[1]-b[1])
def merge(a,b):
 d=a.copy()
 for I,z in b.items():d[I]=add(d.get(I,Z),z)
 return {I:z for I,z in d.items() if z!=Z}
def sigma(frame):return {tuple(I):(F(a),F(b)) for I,a,b in frame['Sigma']}
def tensor(form):
 P=qs.paired_tensor(form,4);return [P.get(((i,),(j,)),Z) for i in range(10) for j in range(10)]
def poladd(P,e,z):
 v=P.get(e,F())+z
 if v:P[e]=v
 elif e in P:del P[e]
def pack(P):return [[list(e),str(v)] for e,v in sorted(P.items())]
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('D_LIFT_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 exact=read(C/'canonical_so10_higgs_exact_light_ct_map/original_result.json');valley=read(C/'canonical_so10_higgs_neutral_valley/original_result.json');old=read(C/'canonical_so10_joint_higgs_inputs/primary_result.json')
 H=list(map(sigma,exact['raw_neutral8_basis']));N=list(map(sigma,valley['SM_basis']));v=vacuum_form();tv=tensor(v);assert tv==[Z]*100
 TH=[tensor(h) for h in H];TN=[tensor(n) for n in N]
 LH=[[sub(sub(a,b),c) for a,b,c in zip(tensor(merge(v,h)),tv,th)] for h,th in zip(H,TH)]
 LN=[[sub(sub(a,b),c) for a,b,c in zip(tensor(merge(v,n)),tv,tn)] for n,tn in zip(N,TN)]
 assert all(z==Z for row in LH for z in row) and all(z==Z for i in [2,4] for z in LN[i])
 Q=[{} for _ in range(100)]
 for i in range(8):
  e=tuple(2*int(k==i) for k in range(8))
  for k,z in enumerate(TH[i]):
   if z!=Z:Q[k][e]=z
 for i,j in combinations(range(8),2):
  e=tuple(int(k==i)+int(k==j) for k in range(8));cross=[sub(sub(a,b),c) for a,b,c in zip(tensor(merge(H[i],H[j])),TH[i],TH[j])]
  for k,z in enumerate(cross):
   if z!=Z:Q[k][e]=z
 print('STAGE actual_weak8_neutral10_T_linear_and_quadratic_maps',flush=True)
 # Rational raw conversion from the actual physical coefficient definitions.
 assert inputs.RESCALE['lambdaSigma2']==inputs.RESCALE['lambdaSigma3']==(4,0)
 kappa=F(5,24)*F(3,160)**2;assert kappa==F(3,40960)
 W={}
 for k in range(100):
  entries=[]
  for i in range(10):
   if LN[i][k]!=Z:entries.append((tuple([0]*8+[int(j==i) for j in range(10)]),LN[i][k]))
  entries +=[(e+tuple([0]*10),z) for e,z in Q[k].items()]
  for e,(a,b) in entries:
   for f,(c,d) in entries:poladd(W,tuple(i+j for i,j in zip(e,f)),kappa*(a*c+b*d))
 target={}
 for name,sign in [('lambdaSigma3',1),('lambdaSigma2',-1)]:
  for tag,rows in old['raw_target_ledgers'][name].items():
   for e,re,im in rows:assert F(im)==0;poladd(target,tuple(e),sign*kappa*F(re))
 assert W==target,'FULL_D_VARIATION_LEDGER_MISMATCH'
 nH=[[F() for j in range(10)] for i in range(10)];bforms=[{} for _ in range(10)];direct={}
 for e,z in W.items():
  dh,dn=sum(e[:8]),sum(e[8:])
  if dn==2:
   inds=[i for i,p in enumerate(e[8:]) for _ in range(p)];i,j=inds;nH[i][j]+=z*(2 if i==j else 1)
   if i!=j:nH[j][i]+=z
  elif dn==1:
   assert dh==2;i=next(i for i,p in enumerate(e[8:]) if p);poladd(bforms[i],e[:8],2*z)
  else:assert dh==4;poladd(direct,e[:8],z)
 assert any(direct.values()) and nH==list(map(list,zip(*nH)))
 # All gauge and PQ variations lie in the added Hessian kernel.
 def Jform(p,q):
  out={}
  for I,z in v.items():
   if (p in I)==(q in I):continue
   oldi,newi,sg=(p,q,-1) if p in I else (q,p,1);J=tuple(newi if i==oldi else i for i in I);sg*=qs.parity(J);out[tuple(sorted(J))]=(sg*z[0],sg*z[1])
  return out
 controls=0
 for p,q in combinations(range(10),2):
  g=Jform(p,q);L=[sub(sub(a,b),c) for a,b,c in zip(tensor(merge(v,g)),tv,tensor(g))];assert L==[Z]*100;controls+=1
 pq={I:(-b,a) for I,(a,b) in v.items()};assert [sub(sub(a,b),c) for a,b,c in zip(tensor(merge(v,pq)),tv,tensor(pq))]==[Z]*100
 # Actual source stationarity definitions,without instantiating Model or a point.
 text=(C/'canonical_so10_bounded_scalar_feasibility/model.py').read_text();tree=ast.parse(text);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='physical');free=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='FREE' for z in n.targets))
 raw=inputs.coefficients(0);bb=S.sqrt(S.Rational(3,160));ss=S.sqrt(S.Rational(3,10));OLD={n:S.simplify(z/bb**inputs.RESCALE.get(n,(0,0))[0]/ss**inputs.RESCALE.get(n,(0,0))[1]) for n,z in raw.items()};ns={'s':S,'OLD':OLD,'FREE':free};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<frozen physical source>','exec'),ns)
 x,s,z,D=S.symbols('x s z D',positive=True);p=S.symbols('p1:5',real=True);m=S.Symbol('m',real=True);co=ns['physical']([*p,x/8,(5*s+z)/2-5*D/24,(-3*s-z)/2+5*D/24,(z-s)/4],m)
 assert all(S.diff(co[n],D)==0 for n in ['mPhi2','mSigma2','mphi2','mS2']) and S.diff(co['lambdaSigma2'],D)==-S.Rational(5,24) and S.diff(co['lambdaSigma3'],D)==S.Rational(5,24)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 assert not writes and time.perf_counter()-start<120
 result={'schema':'D_MONOTONE_LIFT_PRIMARY_V1','status':'EXACT_NORM_GRAM_REQUIRES_INDEPENDENT_RECEIPT','base_commit':prep['base_commit'],'kappa_raw':str(kappa),'T_vacuum':[[str(a),str(b)] for a,b in tv],'L_weak8':[[[str(a),str(b)] for a,b in row] for row in LH],'L_neutral10':[[[str(a),str(b)] for a,b in row] for row in LN],'Q_weak8':[[[list(e),[str(a),str(b)]] for e,(a,b) in sorted(P.items())] for P in Q],'complete_D_increment_polynomial':pack(W),'neutral10_Hessian_increment':[[str(z) for z in row] for row in nH],'raw_b_increments':list(map(pack,bforms)),'raw_direct_quartic_increment':pack(direct),'weighted_norm_matches_all_ledger_tags':True,'positive_neutral_indices':old['positive_neutral_indices'],'raw_neutral10_metric':old['raw_neutral10_metric'],'raw_weak8_metric':old['raw_neutral8_metric'],'gauge_generators_checked':controls,'PQ_Hessian_kernel_checked':True,'stationarity_masses_D_independent':True,'extended_Higgs_increment':'2*kappa*deltaD*Gram_R[L_positive8,2Q(h)]','proposed_contact_lift':'Dtop=(16*pi-3*x+24*(s-z))/5 at fixed x,s,z,t','no_simultaneous_x_D_lift_claimed':True,'full_domain_feasibility_decided':False,'full_scattering_preserved_proved':False,'new_parameter_search':False,'new_model_parameter_points':0,'new_benchmark_or_family_adopted':False,'scientific_authority_changed':False,'physical_viability_decided':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 timer.cancel();print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True)
if __name__=='__main__':main()
