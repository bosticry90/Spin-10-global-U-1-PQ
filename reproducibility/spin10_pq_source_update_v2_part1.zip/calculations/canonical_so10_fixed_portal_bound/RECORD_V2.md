# Corrected portal verifier V2 — pending additional director authorization

The approved two executions are exhausted: one completed primary and one
FAILED independent verifier. The failed capture, source, preparation and
prospective V1 reports are immutable evidence, not qualified results.

Propose ONE corrected verifier only,120seconds after imports,8GiB sampled
private memory and350MiB directly observed available commit before launch.
No primary rerun, parameter search, new physical input,benchmark or loops.
The primary result and every tensor,normalization,overlap,gauge and authority
check are retained. No relaxed mathematical acceptance or changed physics.

The first verifier passed the15876-pair Sigma coefficient and independent
pair-normalization stages, then failed an assertion requiring the inequality
solver's return object to be the literal SymPy False. That routine can return
a conjunction of separate polynomial and rational conditions without
intersecting their intervals. The source/traceback establish this failure
location; no additional diagnostic physics execution has been performed.

V2 retains the same inequality call and requires its solution SET to be empty.
It additionally proves the general rho>0 sign through the positive endpoint
values of the linear numerator and negative denominator on[-1,1]. This
explicit interval certificate preserves and strengthens the intended control.
The original failure remains FAILED; two verifier attempts will be reported.

The implementation and source copies are frozen before requesting the extra
execution. Expected artifacts: corrected native capture, final independent
receipt, raw index and committed byte checks. The receipt must bind both the
failed attempt and the corrected source, and preserve all protected inputs.
No qualification until every required check passes. A new failure must stop;
this extension would not authorize a fourth execution or altered assertion.

The complete fixed CONTACT upper bound remains a primary calculation until
qualified:597/1600<1/2. Full gauged scattering,joint feasibility,global BFB,
quantum control and physical viability remain unproved. Preserve eta=3/10
exclusion,all prior successes/failures,state/README,authority34/39,custody
exit2/seven,E5/A5 and HB1/C5/C1_GS boundaries and the flavor pause. Equal
science/AI objectives and voluntary nonblocking education remain in force.
