# Complete fixed contact contribution admits a bound below one half

The eight remaining fixed portal/self quartics R, together with the
previously qualified z4+zK contribution Z, obey the conservative bound

```
||M_contact[R+Z]|| <1791/100,
||a0_contact[R+Z]|| <597/1600 =0.373125 <1/2.
```

Qualification requires the actual [independent receipt](validation_receipt.json),
resource captures and raw Git checks under the [authorized contract](RECORD.md).
The tighter triangle expression is about0.33998419 after division by16*pi;
neither decimal is an eigenvalue calculation of the full model.

In plain language: the complete NON-ETA fixed scalar-contact contribution is
not itself an unavoidable large contribution under this bound. This removes
a reason to reject the variable-eta recovery before examining it jointly.
The eight adjustable quartics, eta and gauge contributions remain outside
this bound. Full scattering, joint feasibility and a viable benchmark remain
unproved. Nothing rescues the excluded eta=3/10 comparison retroactively.

## Complete operator coverage and pair normalization

R contains exactly the eight nonzero fixed coefficients listed in the
[approved proposal](../../docs/FIXED_PORTAL_SCATTERING_SCOPE_PROPOSAL_V1.md).
The action still has22 quartic monomials:8 varied,eta,10 nonzero fixed terms
including z4/zK,and3 fixed zeros. No interaction is switched off to define
a different model; R and Z are additive contributions to the same potential.

Write a real mixed quartic in canonical coordinates as

```
V=1/4 sum L_abij X_a X_b Y_i Y_j,
L_abij=L_baij=L_abji.
```

The normalized XX-to-YY pair map has squared Frobenius norm ||L||^2/4;
the crossed XY-to-XY map has squared Frobenius norm ||L||^2. Including the
adjoint direct map therefore gives the COMPLETE real contact operator
Frobenius norm squared(3/2)||L||^2. The factors follow by summing unordered
pairs with1/sqrt(1+delta) normalization, not by counting only distinct legs.
Thus its spectral norm is at most that Frobenius norm.

For products of complex Hermitian bilinears, realification multiplies the
coefficient squared norm by4. Complex selfdual Sigma has126 independent
canonical coordinates,N=2sum|z|^2; as252 canonical real fields,N=X^T X.
Phi is54 real canonical fields. phi is10 complex/20 real and S is1 complex/
2 real. Real/complex factors, all crossed channels and same-content portal
interference are retained. Wrong factors are explicit negative controls.

## Exact Phi portal bound

Use a complete54-element symmetric-traceless Phi basis with its raw metric.
The primary checks the10000 entries of the completeness projector and all
2916 ordered basis anticommutator pairs, including zeros. With normalized
matrices E_alpha,

```
sum ||E_alpha E_beta+E_beta E_alpha||_F^2 =3132/5,
sum_alpha tr(2 E_alpha^2)=108.
```

The independent reverse-diagonal basis gives the same projector. Its identity
sum E_alpha X E_alpha=X^T/2+tr(X)I/2-X/10 yields these traces independently.
For a=lambdaPhiphi1=-1/500 and b=lambdaPhiphi2=971871/50000000,

```
||M_Phi,phi||_F^2
 =3*(2160*a^2+432*a*b+(3132/5)*b^2)
 =2142265480265709/3125000000000000 <1.
```

Both Phi portals are combined before the norm is taken. Dropping their
interference or the offdiagonal Phi basis would change the bound.

## Exact Sigma portal bound

The literal canonical four-index interiors form a complete210-column matrix
whose Gram is6 I210. The primary checks every Gram position. Consequently
the K coefficient tensor has trace1260 and squared norm7560. The independent
route contracts EVERY ordered126^2 Sigma coefficient pair directly, covering
1587600 possible K output positions including implicit proven zeros. It
does not merely sample field values or copy the Gram factorization.

For c=lambdaSigmaphi1=199571/100000000 and
d=lambdaSigmaphi2=-3517823/100000000, the complete complex bilinear tensor is
A=2*c*delta_ab*delta_ij+d*K_abij. Therefore

```
||A||_F^2=5040*c^2+5040*c*d+7560*d^2,
||M_Sigma,phi||_F^2=6*||A||_F^2
 =6766347843020367/125000000000000 <64.
```

The factor2 multiplying c follows from the actual kinetic convention. It is
not an independently adjustable rescaling. All annihilation and crossed
Sigma/phi sectors and complex conjugates enter this coefficient-norm bound.

## Self interactions, singlet portal and combined bound

For lambdaPhiVector1*u^2, the O(20) pair operator has largest magnitude
22*|lambdaPhiVector1|=11/5. Its singlet eigenvalue and traceless eigenvalues
follow from the identity plus a coherent rank-one pair projector.
For lambdaPhiVector2*abs(phi.phi)^2, the charged rank-one and neutral transpose
blocks have norms20*|lambdaPhiVector2| and4*|lambdaPhiVector2|. An upper bound
for this entire operator is therefore2. Independent small real-polynomial
pair matrices check both projector formulas and identical factors.

The vector/S portal has complete Frobenius bound sqrt(60)*|lambdaVectorS|<
1/100. The complex singlet self interaction has norm4*|lambdaS|=4. These
cover every remaining fixed self/portal term, not selected scattering entries.

Taking the triangle inequality among these complete operators gives

```
||R|| <1+8+11/5+2+1/100+4 =1721/100.
```

The inherited Z operator has norm squared4849913042327/10000000000000,
hence ||Z||<7/10. No new replay of its8056-pair proof is claimed. Thus
||R+Z||<1791/100. Since pi>3, a0=M/(16*pi) gives the strict rational bound
597/1600<1/2. Exact square comparisons certify all outward bounds. The sum
does not assume independent operators commute, share eigenvectors or occupy
different pair blocks; triangle bounds remain valid when they overlap.

This deliberately loose bound suffices for the declared question. There is
no scientific need to diagonalize larger matrices just to improve its decimal.

## Gauge and overlap limitations are substantive

Unlike the earlier z4/zK channels, these portals need not have zero gauge
exchange. Actual generator action on a phi vector is nonzero. An annihilation
s-channel leading vector numerator proportional to cos(theta) has zero J=0
angular integral in the applicable hard limit; this does not remove crossed
elastic exchange. The explicit dimensionless reference integrand

```
(q+3)/(q-1-2*rho), -1<=q<=1,rho>0,
```

is strictly negative and gives a nonzero crossed angular contribution. This
is a kinematic control, not an adopted mass, coupling or regulator value.
Kinetic species-diagonal currents forbid mixed-species vertices; they do not
forbid gauge exchange between two allowed elastic currents.

[Goodsell–Staub, equations2–5 and appendix B](https://arxiv.org/pdf/1805.07306)
provide the normalization and explain their additional gauge-neglect
assumptions. High energy alone does not authorize dropping gauge terms.
No gauge coupling is set to zero, no gauge/IR prescription is selected, and
no complete gauged amplitude is qualified here. The bound applies to the
CONTACT contribution and its physical orthogonal compressions only.

Variable Sigma/Phi quartics and eta can share pair sectors with these fixed
terms. A large R-only eigenvalue would not automatically be a lower bound
on the full operator. A canceling-operator control rejects that inference;
another control shows an omitted operator can increase the norm. No new
physical lower-bound exclusion is asserted, so no dimension-only Goldstone
projection or assumed gauge cancellation enters the accepted result.

## Research decision and authority ceiling

All ten non-eta fixed quartics now have a complete combined scalar-contact
upper bound below1/2. Further isolated fixed-contact screening is not the
immediate priority. The remaining scientific question is JOINT feasibility
of the eight variable quartics and eta using the qualified mass/Higgs inputs,
mixed-stability constraints and scattering conditions, with the gauge-
amplitude interpretation kept explicit. Passing each piece separately is
insufficient. A separate bounded analytical scope is required before another
execution; this result does not authorize a point search or new benchmark.

The [eta formulas](../canonical_so10_eta_variable_inputs/RESULT_V3.md) and
[eta-dependent mixed-stability constraints](../canonical_so10_fixed_mixed_screen/RESULT.md)
are inherited, not repeated. Their missing full328 global BFB, full coupled
scattering, controlled quantum vacuum, naturalness and physical predictions
remain. Do not free another coefficient in response to a later failure.

One primary and one independent verifier,120seconds/8GiB each and direct
350MiB launch observations. All records/source hashes, independent receipt
and raw Git checks must pass. Zero fresh byte-identical pairs; no full old
spectrum,quantum loop or matching calculation. Shared action/kinetics/group
and approximation premises,some arithmetic,Python/SymPy and analyst limit
independence. This is not external endorsement or general AI reliability.
Track B records complete-bound reasoning, preservation of interference and
recognition of the unqualified gauge amplitude. Education is nonblocking.

Preserve project_state.json,sealed README,authority34/39,custody exit2/seven,
all prior bounded successes/failures,eta=3/10 exclusion,quartet failure,
E5/A5 gaps,HB1/C5/C1_GS boundaries and flavor pause. No parameter point,
benchmark,physical input,branch/worktree,remote action or outreach. Broad
Spin(10) investigation completion and physical model viability remain unproved.
