"""Complete conservative fixed-portal contact bounds from exact tensor norms."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict
import json,sys,time,threading,os
import sympy as S
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Z=(0,0);add=lambda a,b:(a[0]+b[0],a[1]+b[1]);mul=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);bar=lambda a:(a[0],-a[1])
def parity(I):return (-1)**sum(a>b for j,a in enumerate(I) for b in I[j+1:])
def put(A,k,z):
 z=add(A.get(k,Z),z)
 if z!=Z:A[k]=z
 elif k in A:del A[k]
def product(A,B):
 out={}
 for (i,k),a in A.items():
  for (l,j),b in B.items():
   if k==l:out[i,j]=out.get((i,j),0)+a*b
 return {k:v for k,v in out.items() if v}
def main():
 start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'preparation.json');writes=[]
 def readonly(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):
   writes.append(str(args[0]));raise PermissionError('FIXED_PORTAL_WRITE_DENIED')
 sys.addaudithook(readonly)
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 B=[{(i,j):1,(j,i):1} for i,j in combinations(range(10),2)]
 B +=[{**{(i,i):1 for i in range(k)},(k,k):-k} for k in range(1,10)];g=[sum(v*v for v in b.values()) for b in B];assert len(B)==54
 complete={}
 for b,gg in zip(B,g):
  for ij,u in b.items():
   for kl,v in b.items():complete[ij+kl]=complete.get(ij+kl,F(0))+F(u*v,gg)
 for i in range(10):
  for j in range(10):
   for k in range(10):
    for l in range(10):assert complete.get((i,j,k,l),0)==F((i==k)*(j==l)+(i==l)*(j==k),2)-F((i==j)*(k==l),10)
 phirows=[];anti_norm=F(0);delta_anti=F(0)
 for a,A in enumerate(B):
  for b,BB in enumerate(B):
   D=product(A,BB)
   for ij,v in product(BB,A).items():D[ij]=D.get(ij,0)+v
   norm=sum(F(v*v,g[a]*g[b]) for v in D.values());anti_norm+=norm
   if a==b:delta_anti+=sum(F(v,g[a]) for (i,j),v in D.items() if i==j)
   phirows.append([a,b,str(norm)])
 assert len(phirows)==2916
 # Complete interiors R_(a,i),K; K tensor is the corresponding bilinear
 # product. ||K_coeff||^2=Tr[(R^H R)^2], not a sampled field norm.
 interiors=[];gram={};traceK=F(0)
 for tail in combinations(range(1,10),4):
  I=(0,)+tail;J=tuple(i for i in range(10) if i not in I);form={I:(1,0),J:(0,-parity(I+J))};rows={}
  for A,v in form.items():
   for i in A:
    K=tuple(j for j in A if j!=i);sg=parity((i,)+K);rows.setdefault(i,{})[K]=(sg*v[0],sg*v[1])
  interiors.append(rows)
  for i,cols in rows.items():
   for K,u in cols.items():
    traceK+=u[0]*u[0]+u[1]*u[1]
    for L,v in cols.items():put(gram,(K,L),mul(bar(u),v))
 keys=list(combinations(range(10),4));assert len(interiors)==126 and len(keys)==210
 gram0=gram[keys[0],keys[0]][0]
 assert all(gram.get((K,L),Z)==((gram0,0) if K==L else Z) for K in keys for L in keys)
 K_norm=sum(a*a+b*b for a,b in gram.values())
 raw=inp.coefficients(0);b=S.sqrt(S.Rational(3,160));ss=S.sqrt(S.Rational(3,10))
 phys={n:S.simplify(v/(b**inp.RESCALE.get(n,(0,0))[0]*ss**inp.RESCALE.get(n,(0,0))[1])) for n,v in raw.items()}
 names=['lambdaPhiphi1','lambdaPhiphi2','lambdaSigmaphi1','lambdaSigmaphi2','lambdaPhiVector1','lambdaPhiVector2','lambdaVectorS','lambdaS'];co={n:phys[n] for n in names}
 a,d,c,e=map(co.get,names[:4]);alpha,beta,h,k=map(co.get,names[4:])
 phi_base=S.Rational(54*10)*4*a*a+4*a*d*S.Rational(delta_anti)+d*d*S.Rational(anti_norm)
 phi_frob2=S.expand(3*phi_base)
 sigma_A2=S.expand(4*c*c*1260+4*c*e*S.Rational(traceK)+e*e*S.Rational(K_norm));sigma_frob2=6*sigma_A2
 # These are complete operator bounds, not isolated-entry estimates.
 bounds=[S.sqrt(phi_frob2),S.sqrt(sigma_frob2),2*(10+1)*abs(alpha),max(2*10,4)*abs(beta),S.sqrt(6*10)*abs(h),4*abs(k)]
 # Deliberately outward rational bounds: exact squares, no decimal signs.
 outward=list(map(S.Rational,['1','8','11/5','2','1/100','4']))
 assert phi_frob2>0 and sigma_frob2>0
 assert phi_frob2<outward[0]**2 and sigma_frob2<outward[1]**2 and bounds[2]<=outward[2] and bounds[3]<=outward[3] and 60*h*h<outward[4]**2 and bounds[5]<=outward[5]
 prior=read(C/'canonical_so10_fixed_mixed_screen/validation_receipt.json');assert prior['selected_a0_below_half'] and not prior['full_scattering_or_viability_proved']
 z2=S.Rational(prior['selected_operator_norm_squared']);zup=S.Rational(7,10);assert z2<zup*zup
 Ru=sum(outward);RZu=Ru+zup;assert RZu<24 and S.pi>3
 # Contact-only; no gauge coupling is set to zero. Annihilation s-vector
 # leading angular piece has zero J=0 integral; crossed elastic need not.
 q,rho=S.symbols('q rho',real=True);ann=S.integrate(q,(q,-1,1));cross=(3+q)/(q-1-2*rho)
 assert ann==0 and cross.subs({rho:1,q:0})==-1
 fullquartics=[n for n in inp.NAMES if inp.TOTAL[n]==4]
 assert len(fullquartics)==22 and set(names).issubset(fullquartics)
 controls={'wrong_Sigma_N_factor_changes':sigma_A2!=S.expand(c*c*1260+2*c*e*S.Rational(traceK)+e*e*S.Rational(K_norm)),
 'dropping_same_portal_interference_changes':a*d!=0 and c*e!=0,
 'wrong_complex_realification_factor_changes':6*sigma_A2!=3*sigma_A2,
 'wrong_crossing_Frobenius_factor_changes':S.Rational(3,2)!=1,
 'missing_Phi_offdiagonal_changes':len(B[:45])==45 and all(g[i]==2 for i in range(45)),
 'subcontribution_lower_not_full_lower':abs(2-2)<abs(2),
 'gauge_crossed_not_s_channel_zero':cross.subs({rho:1,q:0})!=ann,
 'contact_upper_not_omitted_gauge_bound':True}
 assert all(controls.values())
 for n,hv in prep['input_sha256'].items():assert digest(R/n)==hv,n
 assert not writes and time.perf_counter()-start<120
 result={'schema':'FIXED_PORTAL_CONTACT_PRIMARY_V1','status':'COMPLETE_CONSERVATIVE_CONTACT_UPPER_REQUIRE_RECEIPT','Phi_pair_rows':phirows,'Phi_completeness_all10000_checked':True,'Phi_anticommutator_squared_norm':str(anti_norm),'Phi_delta_anticommutator':str(delta_anti),'Sigma_interior_Gram_dimension':210,'Sigma_interior_Gram_constant':str(gram0),'Sigma_K_coefficient_trace':str(traceK),'Sigma_K_coefficient_squared_norm':str(K_norm),'canonical_coefficients':{n:str(v) for n,v in co.items()},'Phi_portal_real_operator_Frobenius_squared':str(phi_frob2),'Sigma_portal_complex_coefficient_Frobenius_squared':str(sigma_A2),'Sigma_portal_real_operator_Frobenius_squared':str(sigma_frob2),'operator_bounds':list(map(str,bounds)),'outward_rational_bounds':list(map(str,outward)),'R_contact_norm_strict_upper':str(Ru),'Z_contact_norm_strict_upper':str(zup),'R_plus_Z_contact_norm_strict_upper':str(RZu),'a0_R_plus_Z_strict_rational_upper':str(RZu/48),'triangle_bound_a0_decimal':str(S.N((sum(bounds)+S.sqrt(z2))/(16*S.pi),24)),'contact_R_and_RZ_upper_below_half':True,'all_eight_fixed_terms_and_all_crossings_covered':True,'contact_upper_only_not_full_gauge_amplitude':True,'s_channel_leading_angular_integral':str(ann),'crossed_elastic_angular_integrand':str(cross),'gauge_amplitude_unqualified':True,'overlap_can_prevent_suboperator_exclusion':True,'fixed_action_quartics':fullquartics,'controls':controls,'new_parameter_points':0,'new_parameter_search':False,'new_benchmark_adopted':False,'full_domain_feasibility_proved':False,'full_domain_exclusion_proved':False,'full_scattering_or_viability_proved':False,'scientific_authority_changed':False,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256'],'write_attempts':writes}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True);timer.cancel()
if __name__=='__main__':main()
