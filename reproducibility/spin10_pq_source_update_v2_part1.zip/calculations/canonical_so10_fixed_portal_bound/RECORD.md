# Authorized remaining fixed-contact bound V1 — prospective contract

Human authorization: “Authorize bounded portal screening” for the committed
FIXED_PORTAL_SCATTERING_SCOPE_PROPOSAL_V1.md. Actual baseline is
82e792f28350b689346fd5c24eaa84851c0bf7f7, clean preflight/no matching workers,
statev113/34of39. The two approved roles cover a primary and independent
verifier, not a numerical search or physical input change.

Question: is the COMPLETE remaining fixed contact contribution already too
large, or does it admit a rigorous small bound, before joint scalar work?
R consists of the eight nonzero portal/self quartics in the proposal. Z is
the already qualified z4+zK operator. Keep the eight variable quartics and
real0<eta<=pi*sqrt(7/930) formal. All other inputs/kinetics/VEVs fixed.

Prefer a complete sufficient upper bound. For canonical real groups X,Y,
write V=1/4 L_abij X_a X_b Y_i Y_j with L symmetric in both pairs. The
FULL pair operator has Frobenius norm squared (3/2)||L||_F^2: include direct
XX<->YY maps and crossed XY->XY, all identical-pair factors. For separately
Hermitian complex bilinear products, realification gives ||L||^2=4||A||^2.
These identities require independent real-polynomial/Fock checks and explicit
coefficient membership, not merely equal dimensions.

Primary: derive the combined Phi/phi and Sigma/phi coefficient norms exactly.
Use a full54 symmetric-traceless Phi basis with metric; compute every ordered
Phi-basis anticommutator pair. Construct the complete canonical126 Sigma
basis and all210 four-index interiors. Derive their full Gram and K tensor
trace/norm from exact factorization; do not assume a Casimir normalization.
Keep interference between the two same-content portals. Bound self terms
with justified O(N) and complex vector-pair projectors, including all phases
and multiplicities. Bound the vector/S portal completely. Combine these
operator bounds by the triangle inequality, and add the inherited Z norm.
No full328-field pair compiler or expensive old spectrum/scattering replay.

Independent: reconstruct all ordered Sigma coefficient pairs directly with
literal conjugated contractions rather than only the interior Gram identity;
verify the complete coefficient norm/trace and Phi completeness separately.
Check realification and the3/2 pair factor by independent polynomial
differentiation and normalized pair matrices, O(N) and complex self-quartic
controls. All claimed upper bounds must cover their entire operators.

Gauge/overlap audit: the bound is for CONTACT operators R and R+Z. Physical
orthogonal compression cannot increase such a bound but adding omitted
gauge/variable/eta contributions can. Prove mixed-species kinetic currents
vanish, leading annihilation s-channel J=0 angular projection where applicable,
and exhibit an actual nonzero elastic gauge current and a nonzero crossed
angular contribution as controls. Do not set gauge couplings to zero, choose
a gauge/IR prescription or call a contact upper bound a full-amplitude bound.
If an exclusion is contemplated, require an actual uncancelable map with all
overlapping terms, a non-Goldstone lower bound and gauge prerequisites; absent
these, report a precise gap. A large R eigenvalue or failed upper bound alone
is inconclusive. A shadow-canceling operator must defeat that false inference.

Success: exact complete fixed-contact upper bounds with a rigorously checked
classification relative to1/2 under a0=M/(16*pi), or bounded inconclusive
evidence. A bound below1/2 only removes this fixed-contact obstruction. It
does not establish full scattering, joint feasibility, global BFB, quantum
control or a viable benchmark. Reuse qualified eta-dependent mass/Higgs and
mixed-stability conditions for the next scientific decision, without replay.

TWO sequential native roles only, each120seconds after imports,8GiB sampled
private limit and350MiB directly observed available commit before launch.
Freeze source/input hashes; UTF-8/syntax checks precede launch. Read-only
workers, complete captures, first discrepancy stops qualification, resource
limits mean incomplete. No automatic retries or silent tensor truncation.
Require independent receipt and raw staged/committed byte checks. No fresh
byte-identical pair. Shared action, kinetics/group/approximation premises,
some arithmetic,Python/SymPy and analyst remain common-error risks.

Preserve project_state.json,sealed README,authority34/39,custody exit2/seven,
eta=3/10 exclusion, all prior successes/failures,quartet failure,E5/A5 gaps,
HB1/C5/C1_GS boundaries and flavor pause. No point/search/family/adoption,
new coupling/gauge/phase choice,loop/matching,compiler,branch/worktree,
remote action or outreach. Equal science/AI objectives and voluntary
nonblocking education persist. The broad investigation remains incomplete.
