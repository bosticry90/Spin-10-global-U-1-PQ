# Preparation metadata correction

The first preparation command failed before freezing any worker launch.
It treated the inherited classical_export path string as a dictionary.
The corrected preparation reads its SHA from the inherited input_sha256
map and requires the same independent receipt authentication. The failed
preparation source/output are retained. No worker has run and no scientific
requirement, action, result or resource bound was changed by this correction.
