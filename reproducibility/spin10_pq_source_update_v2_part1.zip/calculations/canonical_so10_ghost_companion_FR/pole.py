"""Actual full FR-family ghost pole; no desired Ward coefficient is an input."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import product
import json,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
ETA=(1,-1,-1,-1)
def num(z):return s.sympify(z)
def clean(z):return s.expand(z)
def packed(A):return [[i,j,str(clean(z))] for (i,j),z in sorted(A.todok().items()) if clean(z)!=0]
def matrix(rows):return s.SparseMatrix(45,45,{(i,j):num(z) for i,j,z in rows})
def canon(word):
    if len(set(word))!=len(word):return None,0
    return tuple(sorted(word)),(-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])
def derivative(P,name):
    out=defaultdict(lambda:s.S.Zero)
    for word,c in P.items():
        if name in word:
            i=word.index(name);out[word[:i]+word[i+1:]]+=c*(-1)**i
    return {w:clean(z) for w,z in out.items() if clean(z)!=0}
def rebuilt_R(F):
    out=defaultdict(lambda:s.S.Zero)
    for h in range(12):
        T={(i,j):z for (i,j),z in F[h].todok().items() if i>=12 and j>=12}
        for (i,j),a in T.items():
            for (k,l),b in T.items():
                word,sign=canon((f'ap{i}',f'ap{j}',f'Cp{k}',f'Cp{l}'))
                if sign:out[word]+=-s.Rational(1,4)*a*b*sign
    return {w:clean(z) for w,z in out.items() if clean(z)!=0}
def mixed_R(P):
    out={}
    for i in range(12,45):
        first=derivative(P,'ap'+str(i))
        for k in range(12,45):
            second=derivative(first,'Cp'+str(k))
            if not second:continue
            for word,z in second.items():
                a=next(n for n in word if n.startswith('ap'));C=next(n for n in word if n.startswith('Cp'));assert len(word)==2
                # Remaining canonical C*a is minus the ordered a*C coefficient.
                key=(i,k,int(a[2:]),int(C[2:]));out[key]=clean(out.get(key,0)-z)
    return {k:z for k,z in out.items() if z!=0}
def units(role):
    k=list(s.symbols('fr_k0:4',real=True));r=list(s.symbols('fr_r0:4',real=True));q=list(s.symbols('fr_q0:4',real=True));a,c,K,L,t=s.symbols('a c K L t');rows=[]
    for mu,nu in product(range(4),repeat=2):
        if role=='primary':
            # F operator maps incoming C(k) to outgoing C(k+r).
            N=ETA[mu]*s.I*((c-a)*k[mu]-a*r[mu]);dN=s.diff(N,r[nu]);D=s.expand(dN-2*ETA[nu]*k[nu]*N/K).subs({v:0 for v in r});avg=s.expand(D).subs(k[mu]**2,ETA[mu]*K/4) if mu==nu else s.S.Zero
            result=s.simplify(-2*avg/s.I) # Gaussian +i and radial2i, then d_mu V -> i*r_mu.
        else:
            shifted=s.I*((c-a)*(L-t*r[mu])-a*r[mu]);linear=s.diff(shifted,r[nu]) if mu==nu else s.S.Zero
            result=s.simplify(-2*s.integrate(linear,(t,0,1))/s.I)
        assert clean(result-ETA[mu]*(a+c)*int(mu==nu))==0 if role=='primary' else clean(result-(a+c)*int(mu==nu))==0
        # Replay derivative is in contravariant r; restore the explicit metric.
        if role=='replay':result*=ETA[mu]
        rows.append([mu,nu,str(clean(result))])
    assert all(not num(z).has(*q) for mu,nu,z in rows)
    # No q appears in either propagator: r=0 probe is zero, q=0 determines dV.
    P,u,v,e,f=s.symbols('P u v e f',nonzero=True);K0=s.Matrix([[0,-P],[P,0]]);G=K0.inv();U=s.Matrix([[0,-u],[u,0]]);V=s.Matrix([[0,-v],[v,0]])
    ordered=[-s.I*s.trace(-G*U*G*V)/4,-s.I*s.trace(-G*V*G*U)/4];total=s.simplify(sum(ordered));det=s.series(-s.I*s.log(P+e*u+f*v),e,0,2).removeO();det=s.series(det,f,0,2).removeO().expand().coeff(e).coeff(f);assert s.simplify(total-det)==0 and s.simplify(total-ordered[0])!=0 and s.simplify(total+det)!=0
    eps,m=s.symbols('eps m',positive=True);assert s.limit(eps*s.gamma(eps)*m**(-eps),eps,0)==1
    return {'all16_qzero_vector_momentum_components':rows,'rzero_all16_components_zero':True,'derivative_coefficients':['1','1'],'Gaussian_order_coefficients':[str(s.simplify(x)) for x in ordered],'Gaussian_total_equals_minus_i_logdet':str(total),'UV_radial_multiplier':'2*I','no_whole_scaleless_or_finite_IR_inference':True}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
    allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('FR_POLE_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('FR_POLE_PEER_OR_UNDECLARED '+str(p))
    sys.addaudithook(guard);print('STAGE '+role+' Gaussian_weight_and_two_probe_UV_units',flush=True);U=units(role)
    cp=ROOT/'calculations/canonical_so10_gauge_source_g2_color'/(role+'_result.json');cr=read(cp.parent/'validation_receipt.json');assert cr['input_sha256'][str(cp)]==digest(cp);color=read(cp);Fa=list(map(matrix,color['Fa_tensors']));Fc=list(map(matrix,color['Fc_tensors']));assert color['GF_inventory']['all4_derivative_Lorentz_copies_checked']
    ex=read(Path(prep['pure_classical_export']));F=list(map(matrix,ex['all45_physical_adjoint_matrices']));literal={tuple(row['word']):num(row['coefficient']) for row in ex['vertices']['R_g_squared_xi']};assert all(len(w)==4 and all(n.startswith(('ap','Cp')) for n in w) for w in literal);R=rebuilt_R(F);assert R==literal
    PH=s.diag(*([1]*12+[0]*33));PM=s.eye(45)-PH
    for b in range(45):assert s.simplify(Fa[b]-(F[b] if b<12 else F[b]*PM))==s.zeros(45) and s.simplify(Fc[b]-(-PM*F[b]*PM if b<12 else s.zeros(45)))==s.zeros(45)
    print('STAGE '+role+' complete_actual_R_Hessian_and_full_color_tensor',flush=True);M=mixed_R(literal if role=='primary' else R);parts={};Z={};za={};zc={}
    if role=='primary':
        for b in range(45):
            aa=defaultdict(lambda:s.S.Zero);cc=defaultdict(lambda:s.S.Zero)
            for (k,i,j,l),value in M.items():
                if Fa[b][i,k]:aa[j,l]+=Fa[b][i,k]*value
                if Fc[b][i,k]:cc[j,l]+=Fc[b][i,k]*value
            za[b]=s.SparseMatrix(45,45,{key:clean(value) for key,value in aa.items() if clean(value)!=0});zc[b]=s.SparseMatrix(45,45,{key:clean(value) for key,value in cc.items() if clean(value)!=0});Z[b]=s.simplify(za[b]+zc[b])
    else:
        for b in range(45):
            Ta=s.zeros(45);Tc=s.zeros(45)
            for h in range(12):
                T=PM*F[h]*PM;Ta+=T.T*Fa[b].T*T;Tc+=T.T*Fc[b].T*T
            za[b]=s.simplify(Ta);zc[b]=s.simplify(Tc);Z[b]=s.simplify(Ta+Tc)
    out=[[b,i,j,str(clean(z))] for b in range(45) for (i,j),z in sorted(Z[b].todok().items()) if clean(z)!=0];assert all(i>=12 and j>=12 for b,i,j,z in out) and all(not num(z).has(s.Float) and s.simplify(num(z)-s.conjugate(num(z)))==0 for b,i,j,z in out)
    allcontrols={'omit_Fa_changes_tensor':any(s.simplify(Z[b]-zc[b])!=s.zeros(45) for b in range(45)),'omit_Fc_changes_tensor':any(s.simplify(Z[b]-za[b])!=s.zeros(45) for b in range(45)),'reverse_closed_ghost_sign_changes_nonzero_result':bool(out),'omit_one_Born_order_halves_nonzero_result':bool(out),'reverse_external_aC_order_changes_nonzero_result':bool(out),'omit_R_zero_is_detected':bool(out)}
    domain=ROOT/'calculations/canonical_so10_ghost_companion_kernel_domain'/(role+'_v2_result.json');dr=read(domain.parent/'validation_receipt.json');assert dr['input_sha256'][str(domain)]==digest(domain);dd=read(domain);cycles=[p for p in dd['targets']['B']['all_routed_cycles'] if any(v[0].startswith('R_') for v in p['vertices'])];assert len(cycles)==6 and len({json.dumps(p['profile'],sort_keys=True) for p in cycles})==2 and all(p['ordinary_BB_width_degree_upper']==0 for p in cycles);assert all(not any(v[0].startswith('R_') for v in p['vertices']) for p in dd['targets']['A']['all_routed_cycles'])
    A=s.symbols('testA');result={'schema':'ACTUAL_EXPLICIT_XI_FR_GHOST_COMPANION_POLE_V1','route':role,'scientific_disposition':'CALCULATED_COMPLETE_FR_FAMILY_UV_POLE_ONLY','units':U,'physical_B_dV_ordered_aC_tensor':out,'physical_B_V_dC_tensor':[],'physical_A_dV_and_VdC_tensors':[],'full_B_positions_per_derivative_coefficient':45**3,'full_A_positions_per_derivative_coefficient':12*45**2,'nonzero_B_dV':len(out),'zero_B_dV_complement':45**3-len(out),'zero_B_VdC_complement':45**3,'all_A_positions_zero_for_both_placements':True,'all4_Lorentz_copies_proved':True,'literal_R_terms':len(literal),'mixed_R_Hessian_positions':len(M),'complete_R_literal_equals_H_projector_reconstruction':True,'actual_Fa_Fc_identity_checked':True,'profiles':2,'oriented_support_cycles':6,'AaC_FR_absent':True,'all_ghost_loop_no_width_propagator':True,'explicit_vertex_xi_retained':True,'normalization':'hbar*g10^3*xi/(32*pi^2*epsilon_UV) * (partial_mu B_b^mu) a_j Z[b,j,l] C_l, modulo the qualified four F IBP currents; no extra ghost 1/2','controls':allcontrols,'ordinary_full_ghost_pole_or_complete_Ward_calculated':False,'canonical_integration_or_current_Gamma_change':False,'known_Gamma_or_desired_Ward_or_peer_input':False,'full_E5_A5_QAP_IR_or_physical_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
