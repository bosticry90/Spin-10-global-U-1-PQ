# Actual explicit-xi FR ghost companion pole V1

Baseline0c69345ccb3931b10fbcb9f30cfe47e156b5d176. Question FR1: what is
the actual ordinaryg3*xi contribution of the complete FR bubble family to
the one-jet AaC/BaC logarithmic UV pole? This is the unique explicit-xi
family in the qualified ordinaryg3 domain, not the complete ghost pole.
It has two supported BaC profiles and six oriented typed cycles, all
internal ghosts; AaC has no FR support. Closing this separable family
tests actual graded weights before the six vector-propagator families.

Freeze this record, code, controllers, qualified domain, actual F_a/F_c,
physical ghost metric/IBP bridge, pure classical full R and adjoint export,
their authentication records and protected policy before computation.
Two sequential workers120seconds after imports/8GiB sampled private,
350MiB minimum available commit; one dependent independent validator at
the same limits. Preserve failures and sources; no silent resource change.
No prior desired ghost Ward coefficient, primitive or peer result input.

Use the unchanged physical ordered ghost density a P C, P0=+p^2 I45.
F is the actual IBP-complete derivative vertex with F_a,F_c and four
recorded boundary currents; R is the actual g^2*xi a*a*C*C vertex.
Primary obtains its mixed ghost Hessian by literal graded differentiation
of every classical R term. Replay reconstructs the physical H-adjoint
projector quartic and uses indexed matrix contractions. Require equality
of the complete classical R and F tensors, not a diagnostic substitution.
The general Hessian coefficient must include all choices of its two
quantum legs; rooted support counts never determine a symmetry factor.

First derive the finite complex-Grassmann Gaussian determinant versus
doubled graded Hessian coefficient of F*R, retaining both Born orders.
Then calculate the first-order UV Taylor residue for all sixteen vector/
momentum components and both r=0,q=0 probes. Replay uses an independently
shifted Feynman-parameter integral. All loop components remain four-
dimensional. The ghost pair at R has combined momentum -r, so q dependence
must be checked rather than fit. Retain ghost ordering and Minkowski radial
2i in hbar/(32*pi^2*epsilon_UV) units. UV annulus or positive auxiliary
IR mass separates the UV residue; no whole scaleless zero or finite/IR claim.

Contract the actual45-color matrices on the entire admitted external
tensor, with zero complements and both derivative quotient coefficients.
Check all H/M external sectors, all four Lorentz copies and reality.
Gauge width independence, if obtained, must follow from the actual absence
of BB edges; explicit vertex xi remains. Do not equate this partial family
to the full ghost companion or insert it into Gamma separately.

Controls reverse the closed-ghost sign, halve the two-order coefficient,
omit either F derivative placement and reverse the external odd order.
Disclose insensitive controls, including a kinematic/color cancellation.
Independent validation must derive the Gaussian sign/factor, UV units,
full R Hessian and actual color tensor by a distinct indexed method, match
all two profiles and six cycles, and authenticate every input/capture.

Outcome: actual complete FR-family local pole (possibly a qualified zero),
an exact input/normalization discrepancy, or bounded inconclusiveness.
No coefficient fitted from a Ward remainder. No full ghost or source-free
Slavnov/E5/A5,QAP,contact/measure/Legendre/IR/physical interpretation. Keep
currentGamma147266/hashc445c2...,38-source and selected auxiliary/bilinear
scopes,nonzero Jacobian,32 products,128 source jets,508 programs,Legacy/
quartet/scalar warnings,closed routes,34/39,HB1/C5 block,flavor pause,C1_GS
gap and custodyexit2/seven. No input,benchmark,scheme,foundation,policy,
authority or remote action. Shared data/software/AI author limit independence;
education voluntary/nonblocking and Lean selective.
