# A measured nonzero explicit-xi ghost contribution

Prospective until both native captures/results, the independent receipt and
committed-byte checks qualify. Baseline0c69345ccb3931b10fbcb9f30cfe47e156b5d176.

The complete FR bubble family contributes a nonzero ordinaryg3*xi local
logarithmic UV pole. This covers both supported BaC profiles and all six
directed typed cycles of this family. AaC has no FR support. The other six
families are outside this result; their coefficients remain unmeasured.

In units hbar*g10^3*xi/(32*pi^2*epsilon_UV), the physical ordered density is

    (partial_mu B_b^mu) a_j Z[b,j,l] C_l.

The 45x45x45 tensor Z has 776 nonzero entries and 90349 zero entries.
All external antighost and ghost indices of nonzero entries are in M, as
required by R. The external B index is also in M after summing the two F
derivative placements. The coefficient of B*a*(partial C) in the chosen
two-dimensional derivative quotient is zero at all 91125 positions. Both
AaC derivative tensors are zero at all 24300 positions each. All four
Lorentz copies, including spatial metric signs, are retained.

Let Fa,Fc denote the qualified actual derivative vertex and let

    M[i,k] = partial_left_Ck partial_left_ai R

be expressed in the ordered remaining a*C fields. The result is

    Z[b] = coefficients of Tr((Fa[b]+Fc[b])*M).

Primary differentiates the entire literal 1672-term physical R, obtaining
6688 mixed-Hessian coefficients and contracting sparse indices. Replay
reconstructs R from the H-adjoint projectors and contracts the indexed
formula sum_h T_h^T*(Fa[b]+Fc[b])^T*T_h. Their complete tensors agree.
They also agree on the full literal R and actual Fa,Fc identities, not just
one chosen field configuration. No coefficient is inferred from a Ward gap.

The Gaussian normalization is obtained from -i log det of a complex
Grassmann pair and the two ordered doubled-Hessian Born words. Each word
has coefficient i*u*v/(2*P^2); their sum is i*u*v/P^2. No extra ghost1/2
is inserted. Independent connected Wick and Berezin checks are required.

With vector momentum r, ghost q and antighost -r-q, R sees the sum -r of
the external ghost pair. The loop denominators and numerator have no
separate q dependence. Both formal UV probes are evaluated: r=0 gives
zero, while q=0 determines the vector-derivative coefficient. First-order
UV Taylor moments and shifted Feynman parameters independently give one
unit for Fa and one for Fc, at every Lorentz/momentum position. The pole
uses a positive UV annulus or separate auxiliary IR mass; it is not a
claim that a whole scaleless integral, finite amplitude or IR part vanishes.

There is no ordinary BB propagator in this family. Accordingly no reference
propagator width occurs, but the explicit R-vertex xi factor remains. This
does not establish width independence of the remaining vector families.
The Fa/Fc representation differs from the literal derivative-vector F by
the already qualified four boundary currents; no EOM quotient is used.

Controls reversing the closed-ghost sign/external odd order, dropping one
Born order or omitting R alter the nonzero result. Omitting Fa or Fc also
changes the tensor. In particular their nonzero H-sector pieces cancel
in the sum; omitting Fc would spuriously leave an H contribution. The
complete independent check also requires all12 constant-H covariance
identities and reality, distinct from a full local Ward identity.

Primary took5.875760seconds after imports; the paired captures and receipt
own all actual runtime and memory observations. Limits are120seconds after
imports,8GiB sampled private and350MiB minimum available commit. One
preparation command failed before launch by treating an inherited path
string as a dictionary; its source/output and correction are preserved.
No failed worker or verifier is claimed unless recorded in the receipt.
No fresh byte-identical replay pair is claimed.

This is useful Track B evidence for moving from a complete support inventory
to an actual separable loop contribution, retaining the derivative quotient
and graded factors. Shared action, charts, IBP/kinetic bridge, classical
export, software and AI author limit independence. Agreement does not
validate shared physical premises or establish the whole ghost pole.

NEXT: compute the six remaining width-carrying/mixed families DF,DG3,DU,
FFF,FFG3,FFU through the same two-probe derivative domain. Derive their
graded Hessian factors rather than using rooted-cycle counts as weights.
Do not import the auxiliary trace's width-squared cancellation. Combine
the actual family contributions only after complete coverage, then qualify
canonical extraction/exact-once integration and the complete ghost Ward
test. No value should be fitted from its partial remainder.

No new node is inserted into Gamma here; current147266/hashc445c2... and
the qualified source/auxiliary-H/bilinear scopes remain. The full ghost
and source-free Slavnov problem, E5/A5, QAP, regulated measure/Jacobian,
32 nonlinear products,128 source jets,508 programs,finite contact/Legendre
and IR/Legacy obligations remain open. Authority34/39,HB1/C5 blocked,
flavor paused,C1_GS,quartet/scalar warnings,closed routes,custodyexit2/seven
unchanged. No scheme,input,benchmark,foundation,policy or remote action.
Education voluntary/nonblocking; Lean selective.
