# Exact symbol reconstruction in the independent verifier

The first verifier completed the literal quantum/external split, full color
comparison and all12 H-covariance checks for primary, then failed the finite
Gaussian coefficient comparison. Its serialized P was reconstructed without
the declared nonzero assumption, creating a distinct SymPy symbol with the
same printed name. The unqualified subtraction is i*u*v/P_nonzero^2 minus
i*u*v/P_unassumed^2. Supplying the frozen symbol table makes it exactly zero.

V2 uses that explicit symbol table when reading the saved Gaussian coefficient.
It reruns every validation requirement on both completed worker outputs with
the same120-second/8GiB bounds. The failed verifier source/capture and old
preparation remain unchanged. No action, coefficient, sign, factor, criterion
or worker output changes. The receipt must report one failed verifier and
one prelaunch metadata failure, with zero failed native workers.
