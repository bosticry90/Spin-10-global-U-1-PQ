# Complete intrinsic g10^4*xi JL*C*x UV coefficient V1

Baseline49e235eaacc1c1052c87530977f25c28298c35e6. AGENTS standing delegation;
authorityv113/34of39 unchanged. Question: actual last outstanding intrinsic
dimension-one single-source local log group in the V199 full-x inventory.
Outcome may be nonzero, exact zero or an explicit input/normalization failure.
No result is assumed or fitted from a desired Slavnov/Ward equation.

Targets are no-jet JL_i*C_m*x_n over45*45*328=664200 positions, coefficient
mass dimension1 via the unchanged orbit tensor. Keep the complete source
S(i,u,h) JL_i L_u C_h and K(i,j,a,b),a<b JL_i a_j C_a C_b, no extra1/2.
For internal ghost a and external m, use full antisymmetrization
Kfull(i,j,a,m)=-Kfull(i,j,m,a), not a single chosen ghost slot. Actual source
affine Qa=-L and negative principal metric H*R=H*Kmetric=-I stay mandatory.

Reuse V201's literal input parsers/actual R,Kmetric,O,B,F,q, all328 scalar
inverse checks, four Lorentz copies and both propagator orientations. That is
input recovery, not a repeat of its pole. Use the V203 ten universal units,
including nonexceptional massless bubble and positive scalar-reference box
domains. No scaleless zero/IR removal or finite-cutoff power claim.

Let T(c,k,n)=-q(k,c,n) be the scalar-kinetic internal-derivative tensor. This
precise source/kinetic bridge (all180 matrices/four literal kinetic ASTs,
identity scalar metrics and source=-rho) is qualified in scalar_source_g3_color.
Preparation exposes only its checked flags and unchanged BV/action input hashes,
not old scalar pole values. Reusing that bridge is not a fresh180-matrix proof.

Primary extracts S/K from all source-polynomial rows and contracts actual
indices directly. Replay transports the separately qualified geometric physical
S/K from auxiliary_quartet_g4_inputs through its exact evaluation-dual carriers,
then contracts by a different grouping. Compare both complete S/K to own literal
source columns before contraction. Physical JL_i=anti[j,i]*rawJL_j,
Lphys_u=source[v,u]*rawL_v,aphys_j=source[v,j]*rawa_v,
Cphys_a=Cphys[a,c]*rawC_c. Full antisymmetric K transport needs no extrahalf.
Export selected classical subtrees with their original qualification/hash links.

With every repeated index summed, common hbar*g10^4*xi/(32*pi^2*epsilon_UV):

 bubble(i,m,n)=-2 Kfull(i,j,a,m) R(a,l) R(b,j) B(l,b,n),
 box(i,m,n)=+2 S(i,u,h) R(h,j) [F_a-F_B](j,m,b)
                    Kmetric(b,l) O(l,k) Kmetric(c,u) T(c,k,n).

The derivative-on-external-C/x units are zero for this no-jet coefficient;
their literal fields are not dropped from other sectors. No color, orientation,
Lorentz or identical-pair factor is guessed. Primary uses the ghost/vector
chain first; replay uses matrix traces and source/kinetic chains first.
Require full separate-family and total tables, exact zero complements and
input signatures to match. All scalar sectors remain in the domain, not only
those with nonzero orbit entries. C3 coefficients need not look real before
the separately required physical chart/functional integration.

Controls omit each measured family, halve/double K, retain only one external
ghost slot, discard the internal H ghost channel and substitute false identity
metrics; source-order sign is checked at family and total level. Disclose
insensitivity or vanishing families rather than force a control to pass.
Validate the complete tensors, contraction and zero domain with a distinct
SymPy route, original qualification and byte links. Shared action, conventions,
inherited tensor/kinetic theorems, software and AI authorship limit independence.

Two sequential120-second/sampled8GiB workers, minimum350MiB available commit;
separate120-second/8GiB validation. Freeze source/controller/projections/own-role
allowlists first; preserve failures/version corrections, no automatic resource
growth. No old loop, known Gamma, Q or Ward replay. No new physical input,
benchmark,foundation,scientific authority or remote change. Full-x and later
x=v+eta translations remain distinct. Ceiling: this complete intrinsic local
UV coefficient, not all source closure/E5/A5/QAP/measure/contact/IR, anomaly
freedom or viability. HB1/C5 blocked,flavor paused,C1_GS uncomputed,scalar
warning,quartet failure,custodyexit2/seven unchanged. Education nonblocking;
selective Lean audit supplies no universal compilation gate.
