"""Complete JL*C*x coefficient, literal versus transported classical tensors."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import importlib.util,json,os,re,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('qualified_dimensionful_input_recovery',ROOT/'calculations/canonical_so10_dimensionful_scalar_source_pole/pole_v3.py');inp=importlib.util.module_from_spec(sp);sp.loader.exec_module(inp)
ex=inp.ex;put,add,ZERO=ex.put,ex.add,ex.ZERO;PKG=inp.PKG;pack,signature=inp.pack,inp.signature
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def source_tensors(route,poly=True):
    data=read(PKG/f'frozen_a10_bv_master/{route}.json');S={};K={}
    def absorb(i,ns,coefficient,source=None):
        ghosts=[n for n in ns if re.fullmatch(r'C\d+',n)];antis=[n for n in ns if re.fullmatch(r'(ub|bar)\d+',n)];Ls=[n for n in ns if re.fullmatch(r'(L|b)\d+',n)]
        if len(ghosts)==1 and len(Ls)==1 and len(ns)==(3 if source else 2):
            logical=([source] if source else [])+[Ls[0],ghosts[0]];odd=[n for n in logical if n==source or n.startswith('C')];sg=(-1)**sum(ns.index(a)>ns.index(b) for j,a in enumerate(odd) for b in odd[j+1:]);put(S,(i,int(re.search(r'\d+',Ls[0])[0]),int(ghosts[0][1:])),sg*inp.coefficient(coefficient,1,0))
        elif len(ghosts)==2 and len(antis)==1 and len(ns)==(4 if source else 3):
            a,b=sorted(int(n[1:]) for n in ghosts);assert a<b;logical=([source] if source else [])+[antis[0],'C'+str(a),'C'+str(b)];sg=(-1)**sum(ns.index(u)>ns.index(v) for j,u in enumerate(logical) for v in logical[j+1:]);z=sg*inp.coefficient(coefficient,2,0);j=int(re.search(r'\d+',antis[0])[0]);put(K,(i,j,a,b),z);put(K,(i,j,b,a),-z)
    if poly:
        for row in data['source_polynomial']:
            if any('__' in n for n in row['word']):continue
            source=next((n for n in row['word'] if re.fullmatch(r'J(L|b)\d+',n)),None)
            if source:absorb(int(re.search(r'\d+',source)[0]),row['word'],row['coefficient'],source)
    else:
        for i in range(45):
            for row in data['source_only_columns'][inp.aux(i)]:
                if not any('__' in n for n in row['word']):absorb(i,row['word'],row['coefficient'])
    assert all(a!=b and K[i,j,b,a]==-z for (i,j,a,b),z in K.items());return S,K
def decode(rows):return {tuple(r[:-1]):ex.coefficient(s.sympify(r[-1])) for r in rows}
def transform(P,axis,matrix,transpose=False):
    by=defaultdict(list);out={}
    for (a,b),z in matrix.items():
        old,new=(a,b) if transpose else (b,a);by[old].append((new,z))
    for key,z in P.items():
        for new,v in by[key[axis]]:put(out,key[:axis]+(new,)+key[axis+1:],z*v)
    return out
def transported(archive):
    S=decode(archive['classical_tensors']['S']);unordered=decode(archive['classical_tensors']['K']);K=dict(unordered)
    for (i,j,a,b),z in unordered.items():assert a<b;K[i,j,b,a]=-z
    carrier={name:decode(archive['carriers'][name]) for name in ['source','anti','Cphys']}
    for axis,name,tr in [(0,'anti',False),(1,'source',False),(2,'Cphys',True)]:S=transform(S,axis,carrier[name],tr)
    for axis,name,tr in [(0,'anti',False),(1,'source',False),(2,'Cphys',True),(3,'Cphys',True)]:K=transform(K,axis,carrier[name],tr)
    return S,K
def foldS(S,Kmetric):
    rows=defaultdict(list);out={}
    for (c,u),z in Kmetric.items():rows[u].append((c,z))
    for (i,u,h),z in S.items():
        for c,v in rows[u]:put(out,(i,c,h),z*v)
    return out
def bubble_direct(K,R,B):
    rr=defaultdict(list);br=defaultdict(list);out={}
    for (a,l),z in R.items():rr[a].append((l,z))
    # Tr(K_{i,m} R B_n R), with the two odd source-ghost choices explicit.
    RB=inp.left_ghost(R,B)
    for (a,b,n),z in RB.items():
        for j,v in rr[b]:put(br,(a,j,n),z*v)
    index=defaultdict(list)
    for (a,j,n),z in br.items():index[a,j].append((n,z))
    for (i,j,a,m),z in K.items():
        for n,v in index[a,j]:put(out,(i,m,n),-2*z*v)
    return out
def bubble_trace(K,R,B):
    RR=defaultdict(list);left=defaultdict(dict);right=defaultdict(dict);out={}
    for (a,b),z in R.items():RR[a].append((b,z))
    for (i,j,a,m),z in K.items():
        for l,r in RR[a]:put(left[i,m],(j,l),z*r)
    for (l,b,n),z in B.items():
        for j,r in RR[b]:put(right[n],(l,j),z*r)
    for (i,m),A in left.items():
        for n,Bn in right.items():
            z=sum((v*Bn.get((l,j),ZERO) for (j,l),v in A.items()),ZERO)
            if z:out[i,m,n]=-2*z
    return out
def box_chain(SK,RF,Kmetric,O,q,keepH=True):
    W=inp.compose_O(RF,Kmetric,O);byh=defaultdict(list);T=defaultdict(list);out={}
    for (h,m,k),z in W.items():byh[h].append((m,k,z))
    for (k,c,n),z in q.items():T[c,k].append((n,-z))
    for (i,c,h),z in SK.items():
        if not keepH and h<12:continue
        for m,k,w in byh[h]:
            for n,v in T[c,k]:put(out,(i,m,n),2*z*w*v)
    return out
def box_source_kinetic(SK,RF,Kmetric,O,q):
    F=defaultdict(list);X={};Y={};T=defaultdict(list);out={}
    for (h,m,b),z in RF.items():F[h].append((m,b,z))
    for (i,c,h),z in SK.items():
        for m,b,v in F[h]:put(X,(i,c,m,b),z*v)
    for (k,c,n),z in q.items():T[c,k].append((n,-z))
    for (b,k),z in ex.mm(Kmetric,O).items():
        for c in range(45):
            for n,v in T[c,k]:put(Y,(c,b,n),z*v)
    by=defaultdict(list)
    for (c,b,n),z in Y.items():by[c,b].append((n,z))
    for (i,c,m,b),z in X.items():
        for n,v in by[c,b]:put(out,(i,m,n),2*z*v)
    return out
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('AUX_SCALAR_POLE_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AUX_SCALAR_POLE_UNDECLARED '+str(p))
    sys.addaudithook(guard);stages=[]
    def stage(n,fn):
        print('STAGE '+role+' '+n,flush=True);t=time.perf_counter();v=fn();stages.append({'name':n,'seconds':time.perf_counter()-t});return v
    archive=read(OUT/('classical_'+role+'.json'));SL,KL=stage('literal_source_SL_KL_and_two_ghost_choices',lambda:source_tensors(role,role=='primary'));SG,KG=stage('qualified_geometric_source_transport',lambda:transported(archive));assert SL==SG and KL==KG,'SOURCE_TENSOR_TRANSPORT_DISAGREEMENT';S,K=(SL,KL) if role=='primary' else (SG,KG)
    q,f,A,unused=stage('actual_scalar_source_and_Qanti_affine',lambda:inp.columns(role));O,B,F,H,R,Kmetric,unused=stage('actual_GF_and_reference_inputs',lambda:inp.fix_and_reference(role));RB,RFe=inp.recon(q,f,A,O,H,R);RF=inp.left_ghost(R,inp.effective(F));assert RB==B and RFe==RF
    bridge=archive['kinetic_bridge'];assert bridge['complete180_source_kinetic_matrices_agree'] and bridge['four_frozen_kinetic_ASTs_and_identity_metrics_checked'] and bridge['actual_source_matrix_is_minus_rho'] and bridge['current_BV_and_kinetic_AST_bytes_match_qualified_bridge']
    uf=ROOT/'calculations/canonical_so10_dimensionful_auxiliary_scalar_units';up=uf/(role+'_result.json');ur=read(uf/'validation_receipt.json');assert ur['execution_state']=='COMPLETED' and ur['input_sha256'][str(up)]==digest(up);u=read(up)['units'];assert u['bubble']=='-2' and u['box_as']=='2' and u['box_Bs']=='-2'
    SK=foldS(S,Kmetric);bubble=stage('all664200_bubble_positions',lambda:bubble_direct(K,R,B) if role=='primary' else bubble_trace(K,R,B));box=stage('all664200_box_positions',lambda:box_chain(SK,RF,Kmetric,O,q) if role=='primary' else box_source_kinetic(SK,RF,Kmetric,O,q));total=add(bubble,box)
    I={(i,i):ex.coefficient(s.S.One) for i in range(45)};wrong=add(bubble_direct(K,I,B),box_chain(foldS(S,I),inp.left_ghost(I,inp.effective(F)),I,O,q));oneghost={key:z for key,z in K.items() if key[2]<key[3]};badghost=add(bubble_direct(oneghost,R,B),box)
    noH=add(bubble,box_chain(SK,RF,Kmetric,O,q,False));controls={'omit_bubble_changes_total':box!=total,'omit_box_changes_total':bubble!=total,'halve_K_changes_total':add({k:z*ex.coefficient(s.Rational(1,2)) for k,z in bubble.items()},box)!=total,'double_K_changes_total':add({k:2*z for k,z in bubble.items()},box)!=total,'single_external_ghost_slot_changes_total':badghost!=total,'omit_internal_H_ghosts_changes_total':noH!=total,'wrong_identity_metrics_change_total':wrong!=total,'reverse_source_order_changes_each_nonzero_family':(not bubble or {k:-z for k,z in bubble.items()}!=bubble) and (not box or {k:-z for k,z in box.items()}!=box),'reverse_source_order_changes_total':{k:-z for k,z in total.items()}!=total}
    assert all(0<=i<45 and 0<=m<45 and 0<=n<328 for i,m,n in total)
    result={'schema':'INTRINSIC_DIMENSION_ONE_AUXILIARY_SCALAR_SOURCE_POLE_V1','route':role,'domain':{'source_directions':45,'ghosts':45,'scalars':328,'all_slots':664200,'implicit_zeros_are_computed':True,'no_jets':True,'coefficient_dimension':1,'common_factor':'hbar*g10^4*xi/(32*pi^2*epsilon_UV)','coordinates':'C3_evaluation_dual_JLambda_ghost_C_full_Cartesian_x'},'input_tensor_signatures':{n:signature(P) for n,P in {'S':S,'K_full':K,'SK':SK,'q':q,'O':O,'B':B,'F_a':F['a'],'F_B':F['B'],'F_c':F['c'],'R':R,'Kmetric':Kmetric,'RF':RF}.items()},'all_actual_SL_KL_match_qualified_geometric_transports':True,'both_ghost_slots_in_full_antisymmetric_K_without_extra_half':True,'qualified_kinetic_bridge_reused_not_new180_matrix_replay':True,'actual_Qanti_minus_L_and_negative_principal_metric_checked':True,'bubble':pack(bubble),'box':pack(box),'complete_pole':pack(total),'zero_complement':664200-len(total),'controls':controls,'new_Gamma_or_Slavnov_identity_calculated':False,'physical_real_chart_or_canonical_integration_qualified':False,'full_source_E5_A5_QAP_IR_or_physical_claim':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
