# Final qualification: family exclusion with historical README bytes preserved

The [scientific decision and derivation](RESULT.md) remain unchanged. The
earlier Higgs-only tuning family fixes all four pure-Sigma quartics and cannot
pass the selected tree perturbative-unitarity channel. Its original/fresh
calculation pair remains byte identical. No physics calculation is repeated.

Final qualification requires [validation_receipt_v2.json](validation_receipt_v2.json),
the original native pair, both validation preparations/captures, the
[custody correction](README_CUSTODY_CORRECTION.json), the preserved unapplied
README edit and separate raw Git verification. The earlier validation receipt
alone is insufficient for this final checkpoint.

## Custody correction

An added README notice caused the established read-only preflight to fail:
`BOUND_BYTE_CHANGED: README.md`. README is transitively bound by the historical
evidence chain. The first final validator checked its declared local inputs,
but its intended README exception did not cover that stronger obligation.
That acceptance-coverage mistake is preserved, not reclassified as a PASS.

There were two preflight failure observations: the initial tool call and one
explicitly captured reproduction. The latter's full stdout/stderr and bytes
are retained externally with an in-repository descriptor. The unaccepted
README edit is retained verbatim as README_EDIT_NOT_APPLIED.source.txt. It is
failed-attempt evidence, not a second active README or policy.

README was restored from the exact current HEAD blob after checking both the
edited-file hash and the baseline hash, so no intervening user edit was
discarded. No Git reset, historical manifest, result, benchmark or scientific
authority was changed. Its restored SHA256 is
4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792.
The warning belongs in this new result and handoff, not the sealed README.

V2 final validation requires the actual standard preflight to pass in addition
to the independent family, rational and norm checks. It checks the archived
edit against the first preparation, its recorded preflight failure, the exact
restoration, the new file set and both source/preparation chains. Scientific
criteria are unchanged; the omitted custody obligation is restored. Native
calculation failures remain0; the two failed preflight observations are
separately disclosed. No source or failed record is overwritten.

This is a second AI-capability limitation alongside the previously identified
delayed perturbativity screen: locally successful validation did not cover
the complete protected evidence chain. The established preflight detected it.
The correction preserves that chain rather than weakening authentication.

## Disposition

Retain the current point as a mathematical/reference benchmark. Do not resume
its old Higgs-only rescue search or costly physical matching under the failed
tree criterion. Continue necessary constraints on the unchanged action before
any director-controlled new input domain. The required single-channel change
is at least0.1250324354 in the maximum absolute Sigma-quartic coordinate, or
0.2324777285 in Euclidean norm. Those bounds are not a new parameter point or
a guarantee of admissibility. Full quantum vacuum, RG/finite-energy and
nonperturbative conclusions remain outside qualification.

Authority34/39,statev113,quartetFAIL3960/648,E5/A5unqualified,HB1/C5blocked,
C1_GSuncalculated,full328BFB/naturalness,matter gaps,flavor pause and
custodyexit2/seven unresolved references remain intact. The director's
education stays voluntary/nonblocking. The investigation remains active.
