# Frozen-quartic benchmark-family admissibility

Baseline2dd91c235e910f9a0e5680b8ab706d11a9eccf92. Previous turn PROGRESS:
direct coherent scattering failure, measured input burden and radial/scale
assessment. Read-only preflight clean, no matching workers. Statev113/34of39
SHA256 d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.

Physics decision enabled: determine whether the earlier Higgs-only search
family could pass the new tree perturbative-unitarity screen, before any
further tuning or expensive matching. Current blocker removed: uncertainty
over whether that existing parameter domain can repair the failing channel.
No quantum-restoration or model-viability gate is removed. Existing tools
suffice; minimum surface is one exact support/inequality calculation and
compact decision record. Structure-preserving map obligations: no new map;
reuse the qualified canonical field normalization and coherent channel.
Stopping condition: exact independence/failure certificate or inconclusive
if an input/assumption is missing. Nothing is deleted or deactivated on failure;
preserve every earlier calculation. No replacement search is authorized here.

The qualified channel has K=sum_a c_a lambdaSigma_a, c=(8,24,24,32), and
|a0|=sqrt6*abs(K)/(32pi). Reuse the direct tensor/module/current proofs from
V84; authenticate them, do not repeat the derivatives. A tree criterion fails
when6*K2>(16pi)^2; the earlier rational pi<22/7 certificate is sufficient.

Recover the literal parent field multidegrees for all29 invariant names and
all34 real parameter directions. A fourth derivative with four pure Sigma
directions can survive only degree(Phi,Sigma,phi,S)=(0,4,0,0). Require exactly
the four pure-Sigma quartics and reproduce the canonical coefficients from
the prior raw derivative factors times the fixed b4 rescaling.

The original positive-Higgs search varies real z6/omega,zK,zEta, the two pure
10 quartics and solved mphi2. Its explicit amendment also varies lambdaPhiphi1.
All four Sigma quartics remain at Stage1 values. Read/bind the actual contract
and point. Prove K is independent of every allowed variation, with no finite
grid or extrapolated sampling. Also check that the tested S0 tadpole/mixing
directions contain no surviving pure-Sigma quartic direction. This establishes
only that those tree-level changes cannot alter this channel at the fixed
canonical field orientation, not that every finite scheme is physically invalid.

Report the family exclusion against THIS fixed-input tree criterion, not
nonexistence of tree-positive points, failure of all physical parameter space,
RG-improved/finite-energy scattering or a nonperturbative no-go. For candidates
with other classical instabilities, those remain separate failures. The
selected radial/real6 positive states and coupling-independent zero gauge
currents are qualified dependencies. Do not alter the domain to avoid failure.

For any changed four-quartic vector delta, the necessary single-channel bound
requires abs(c.delta)>=gap=K0-16pi/sqrt6>0. Derive the norm lower bounds
||delta||infinity>=gap/88 and ||delta||2>=gap/(8sqrt35), without choosing a
direction, fitting new coefficients or claiming the new point is admissible.
Provide exact expressions and conservative rational certificates using pi<22/7
and2449489/1e6<sqrt6 (squared check). These are necessary distances to one
inequality, not a replacement benchmark or naturalness measure.

Use exact symbolic differentiation/support and a separate rational polynomial
coefficient check. Negative controls must detect dropping any coefficient,
incorrect conjugate multiplicity, inclusion of a Sigma quartic as a supposedly
irrelevant parameter, and treating a passing one-channel control as a global
admissibility certificate. Symbolic zero coupling is an algebra control only,
not an adopted or tested alternative physical benchmark.

Freeze source/input before original/fresh sequential read-only -B workers,
100/140-digit diagnostic distances with identical outputs,350MiB immediate
available commit,8GiB sampled private,900sec after imports. Preserve failures;
limits do not truncate. Independent arithmetic/source/resource/state/link and
raw Git checks required before local commit. No old expensive replay, scan,
full spectrum/scattering matrix or new quantum compiler.

Assemble existing constraint dispositions without promoting partial PASS to
physical viability. Distinguish current point, excluded fixed-quartic family,
specific construction and Spin10 generally. Record the delayed cheap
perturbativity screen as an AI research-prioritization limitation. Education
is voluntary/nonblocking; director retains consequential input/benchmark
choices. No point, scheme, physical scale or search scope is selected here.

Preserve34/39,quartetFAIL3960/648,E5/A5unqualified,HB1/C5blocked,
C1_GSuncalculated,full328BFB/naturalness,matter/phenomenology gaps,flavor pause,
custodyexit2/seven unresolved references and all historical authority/evidence.
No branch/worktree/reset/remote action/publication/outreach. Goal active.
