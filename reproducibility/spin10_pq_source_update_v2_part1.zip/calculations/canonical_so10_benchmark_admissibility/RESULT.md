# Admissibility decision for the fixed-quartic benchmark family

The earlier Higgs-only tuning family cannot pass the measured tree
perturbative-unitarity channel. This is an exact exclusion of that family
against this particular criterion, not an unsuccessful finite search.
Further Higgs retuning within the old domain cannot repair the failure.

Retain the current point as a mathematical/reference benchmark. Defer its
expensive physical matching until a changed input domain or a controlled
alternative description has been justified. No replacement point, search,
finite scheme or authority change is selected by this record.

Use the [prospective contract](RECORD.md), [source](screen.py),
[calculation data](original_result.json), original/fresh captures and
[final receipt](validation_receipt.json). Prior direct derivatives, module
closure and gauge-current evidence are authenticated dependencies, not freshly
repeated calculations. The original tree-positive result remains true.

## Why the whole historical family fails this screen

The previously qualified coherent channel gives

```text
K = 8*lambdaSigma1 + 24*lambdaSigma2
    + 24*lambdaSigma3 + 32*lambdaSigma4,
|a0| = sqrt6*abs(K)/(32*pi).
```

At the frozen quartics K=31.5236516 and |a0|=0.768090322366>1/2. Its complete
real-six module, normalized identical-pair factors, two literal parent
quartic derivatives and all relevant zero vector-exchange currents were
qualified in the [previous calculation](../canonical_so10_radial_input_control/RESULT.md).
This is a fixed-input high-energy tree perturbativity screen. It is not a
complete finite-energy/RG/loop-unitarity calculation or nonperturbative no-go.

Four pure-Sigma external directions select exactly four quartics from the
29 parent invariants. A literal field-multiset check and independent polynomial
restriction establish that every other parameter has zero derivative in K.
The [original Higgs-search contract and explicit amendment](../canonical_so10_positive_higgs/RECORD.md)
vary z6/omega,zK,zEta, the two pure10 quartics, solved mphi2, and subsequently
lambdaPhiphi1. They hold all four Sigma quartics fixed. Each varying interaction
contains phi, whose VEV is zero, so these changes also leave the selected
pure-Sigma mass and radial-Hessian support unchanged. No candidate grid is
used to infer the result for this continuum of inputs.

Consequently, every member of that declared family retains the same failing
channel. Members with additional classical failures do not evade it. This
does not contradict the family's successful local tree-positive Higgs point;
that earlier acceptance ceiling explicitly excluded perturbativity.

The tested S0 tadpole/mixing counterterm subset likewise contains none of the
four pure-Sigma quartics. Its large conditional increments leave K unchanged
at this fixed canonical field orientation. This does not rule out every
finite scheme, field/input definition or loop-improved description. It does
rule out treating those particular tree parameter changes as a repair of this
particular tree channel.

## Necessary change before another input domain could pass even this channel

The necessary condition is abs(K)<=16*pi/sqrt6=20.52079728.... Thus a changed
four-quartic vector must change K by at least11.00285432 in magnitude.
Triangle and Cauchy--Schwarz inequalities imply

```text
max_i abs(delta lambdaSigma_i) >= 0.1250324354...,
sqrt(sum_i delta lambdaSigma_i^2) >= 0.2324777285....
```

These are distances to one inequality, in the frozen invariant normalization.
They are not a proposed direction, a fitted point, a tuning probability or a
guarantee of viability. Conservative rational lower certificates are included
alongside the exact expressions. Passing this condition could still fail
other scattering channels, stability, vacuum, gauge or phenomenological tests.
A decoupled scalar reference explicitly demonstrates why one passing channel
cannot establish global admissibility; it is not an alternative model point.

## Combined scientific disposition

| Requirement | Current bounded evidence | Consequence |
| --- | --- | --- |
| Specified invariant action and representations | Qualified in the source-derived variant | Reuse; no foundational change |
| Local tree scalar vacuum and positive relaxed Higgs quartic | Qualified; exact-u quartic about0.10485824293 | Mathematical/reference point retained |
| Restricted76/308-real quartic stability | Qualified within those restrictions | No global328 certificate |
| Full328 boundedness/preferred vacuum | Unresolved | Global stability unearned |
| Small scalar/bosonic-reference radial correction | Fails; very large linear shifts | No assumed small quantum vacuum displacement |
| Local finite potential target reachability | Qualified, but measured shifts large | A solution to counterterm equations is insufficient |
| Fixed-input tree perturbativity | Fails; whole historical fixed-quartic Higgs family excluded by one channel | No further Higgs-only rescue search |
| Complete quantum vacuum and controlled input prescription | Underdetermined | Missing fermions/input definitions remain explicit |
| Complete gauge unification/finiteC1_GS | Uncalculated/incomplete | Unknown thresholds are not fitted |
| Matter/flavor and physical predictions | Incomplete; flavor paused | No empirical GUT qualification |

The two quantum-response questions remain separate from the exact tree screen.
An off-shell tadpole is gauge/input dependent; the earlier explicit-log grid
is not complete RG uncertainty. A different physical input prescription has
not been demonstrated to yield a controlled same-theory prediction. Missing
fermions are not assumed to cancel the warning, and paused work is not resumed.

## Research decision and authorization boundary

Continue model-level necessary-constraint analysis under the unchanged action.
Any proposed new search should first define an input domain that can satisfy
the known tree channel inequality, cheap stability conditions and local mass/
Higgs tests, then check remaining perturbative channels before costly quantum
matching. Passing these screens would admit further testing, not a physical
prediction. No new point is generated here.

A replacement input domain must permit changes beyond the old Higgs-only
contract, including at least one pure-Sigma quartic. Its ranges, physical
motivation, resource limits, stopping rules and acceptance conditions must be
made concrete before execution. The director retains the consequential
benchmark/input decision under [AGENTS.md](../../AGENTS.md) and the
[three-track charter](../../CHARTER.md). Education remains voluntary and
nonblocking; technical mastery is not an authorization prerequisite.

There is an AI-capability limitation as well as a useful new proof: this
inexpensive perturbativity screen was delayed until after many finite-loop
calculations. Earlier scope statements correctly withheld physical viability,
but bounded mathematical correctness and repeated reproduction did not ensure
efficient physical prioritization. The new sequencing addresses that specific
failure without presenting the AI as an independent scientific authority.

## Verification and retained authority

Original/fresh outputs are byte identical. Independent checks use literal
parent multidegrees, rational coefficient arithmetic, a separate polynomial
restriction, a Machin-series pi enclosure, hypercube extrema and a symbolic
Cauchy sum-of-squares identity. Controls detect missing coefficients, a wrongly
classified Sigma variation, conjugate-count changes and a false global PASS.
Sources, resource observations, state and raw Git bytes are checked. No failed
new execution or old expensive replay. Shared prior action/derivative data and
analyst are disclosed limits, not external endorsement.

Scientific authority remains34/39 and statev113 unchanged. Preserve quartet
FAIL3960/648, E5/A5unqualified, HB1/C5blocked, finiteC1_GS gap, full328BFB/
naturalness and matter gaps, flavor pause, custodyexit2/seven unresolved
references and every earlier successful, failed or incomplete result. The
specific construction and general Spin10 hypothesis are not excluded. The
full investigation remains active and incomplete.
