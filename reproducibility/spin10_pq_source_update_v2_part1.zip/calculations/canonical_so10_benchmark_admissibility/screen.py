"""Exact exclusion of the historical fixed-Sigma-quartic tuning family."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import sys,json,time
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations';O=Path(__file__).resolve().parent
sys.path.insert(0,str(C/'canonical_so10_higgs_neutral_valley'));import inputs as inp
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
    start=time.perf_counter();prep=read(O/'preparation.json');writes=[]
    def readonly(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('BENCHMARK_ADMISSIBILITY_WRITE_DENIED')
    sys.addaudithook(readonly)
    for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
    previous=read(C/'canonical_so10_radial_input_control/original_result.json');coherent=read(C/'canonical_so10_radial_input_control/coherent_original_result.json');receipt=read(C/'canonical_so10_radial_input_control/validation_receipt.json')
    assert receipt['tree_perturbative_screen']=='FAIL_SELECTED_COHERENT_CHANNEL' and receipt['independent_two_direct_quartic_tensor_convolutions_checked'] and receipt['independent_module_commutant_and_all_currents_checked']
    assert coherent['module_dimension']==6 and coherent['all_identical_state_currents_zero'] and all(F(x)==0 for row in coherent['all270_cross_currents'] for x in row)
    qnames=['lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4'];rows=[];support=[]
    for n in inp.NAMES:
        sig=inp.RESCALE.get(n,(0,0))[0];P=inp.PHI[n];ss=inp.SDEG[n];phi=inp.TOTAL[n]-P-sig-ss;assert min(P,sig,ss,phi)>=0
        degree=[P,sig,phi,ss];survives=degree==[0,4,0,0];rows.append({'invariant':n,'field_degree_Phi_Sigma_phi_S':degree,'four_Sigma_derivative_can_survive':survives})
        if survives:support.append(n)
    assert support==qnames
    coefficients=[s.Rational(z)*s.Rational(3,160)**2 for z in previous['scattering_witness']['canonical_quartic_by_invariant']];assert coefficients==[8,24,24,32]
    symbols={n:s.Symbol(n.replace(':','_'),real=True) for n in inp.NAMES};K=sum(c*symbols[n] for c,n in zip(coefficients,qnames));assert all(s.diff(K,symbols[n])==0 for n in inp.NAMES if n not in qnames)
    stage=read(C/'canonical_so10_scalar_benchmark/STAGE1_POINT.json')['free_coefficients'];frozen=[s.Rational(stage[n]) for n in qnames];co=inp.coefficients(0);assert all(s.simplify(co[n]/s.Rational(3,160)**2-z)==0 for n,z in zip(qnames,frozen));K0=sum(c*z for c,z in zip(coefficients,frozen));assert K0==s.Rational(coherent['K_exact'])
    varied=['z6','zK','zEta','lambdaPhiVector1','lambdaPhiVector2','mphi2','lambdaPhiphi1'];assert not set(varied)&set(support)
    degrees={r['invariant']:r['field_degree_Phi_Sigma_phi_S'] for r in rows};assert all(degrees[n][2]>=1 for n in varied)
    # Every change in the historical family retains the same pure-Sigma restriction.
    deltas=s.symbols('d0:'+str(len(varied)));shifted=K.subs({symbols[n]:symbols[n]+z for n,z in zip(varied,deltas)},simultaneous=True);assert s.expand(shifted-K)==0
    subset=read(C/'canonical_so10_higgs_counterterm_subsets/original_result.json');s0=next(a for a in subset['cases'] if a['label']=='S0_target9')['parameter_names'];assert not set(n.partition(':')[0] for n in s0)&set(support)
    assert all(s.diff(K,symbols[n.partition(':')[0]])==0 for n in s0)
    exactfail=bool(6*K0*K0>s.Rational(352,7)**2);assert exactfail
    sqlo=s.Rational(2449489,1000000);assert sqlo>0 and sqlo*sqlo<6
    upper=s.Rational(352,7)/sqlo;gaplo=K0-upper;assert gaplo>0
    n1=sum(abs(x) for x in coefficients);n2sq=sum(x*x for x in coefficients);assert n1==88 and n2sq==2240
    distances=[]
    for precision in [100,140]:
        mp.mp.dps=precision;k=mp.mpf(K0.p)/K0.q;limit=16*mp.pi/mp.sqrt(6);gap=k-limit
        assert gap>mp.mpf(gaplo.p)/gaplo.q
        distances.append({'precision':precision,'channel_K_limit':mp.nstr(limit,70),'required_absolute_K_change_at_least':mp.nstr(gap,70),'necessary_linf_change_at_least':mp.nstr(gap/88,70),'necessary_l2_change_at_least':mp.nstr(gap/mp.sqrt(2240),70)})
    # A wrongly declared irrelevant Sigma direction changes K, unlike the real family.
    x=s.symbols('wrong_delta');wrong=s.expand(K.subs(symbols[qnames[0]],symbols[qnames[0]]+x)-K);assert wrong==8*x
    assert all(s.diff(K,symbols[n])!=0 for n in qnames)
    assert 3*K0*K0!=6*K0*K0 and all((K0-c*z)!=K0 for c,z in zip(coefficients,frozen))
    assert K.subs({symbols[n]:0 for n in qnames})==0
    # Decoupled one-real-scalar reference: a different channel can fail when K=0.
    toy_normalized_contact=30;assert toy_normalized_contact>s.Rational(176,7)
    for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
    assert not writes and time.perf_counter()-start<900
    result={'schema':'FROZEN_QUARTIC_FAMILY_ADMISSIBILITY_V1','status':'COMPLETE_EXACT_FAMILY_EXCLUSION_FOR_TREE_CHANNEL_CRITERION','monomial_support':rows,'surviving_quartic_names':qnames,'physical_channel_coefficients':list(map(str,coefficients)),'frozen_Sigma_quartics':list(map(str,frozen)),'K_exact':str(K0),'historical_Higgs_family_varied_invariants':varied,'historical_Higgs_family_K_independence_exact':True,'tested_S0_K_independence_exact':True,'entire_historical_Higgs_family_passes_tree_channel':False,'family_failure_is_not_no_tree_positive_point_theorem':True,'exact_pi_upper_bound_failure':exactfail,'distances':distances,'conservative_gap_lower_bound_exact':str(gaplo),'conservative_linf_distance_lower_bound_exact':str(gaplo/88),'conservative_l2_distance_squared_lower_bound_exact':str(gaplo**2/2240),'distance_to_one_inequality_not_admissible_benchmark':True,'one_channel_pass_implies_global_viability':False,'decoupled_toy_counterexample_to_global_pass':{'K':0,'other_normalized_contact':toy_normalized_contact,'classification':'REFERENCE_NOT_ALTERNATIVE_BENCHMARK'},'new_candidate_or_search_or_scheme_adopted':False,'old_expensive_calculations_rerun':False,'full_model_or_nonperturbative_exclusion_proved':False,'scientific_authority_changed':False,'write_attempts':writes,'whole_goal_complete':False,'input_sha256':prep['input_sha256'],'state_sha256':prep['state_sha256']}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);print('METRICS '+json.dumps({'total_seconds':time.perf_counter()-start}),flush=True)
if __name__=='__main__':main()
