# Dimension-one auxiliary-source/scalar loop units V1

Baselinee3830537ad31bb1d81fc12058e014f6ff80a3953. Current AGENTS delegation;
authorityv113/34of39 unchanged. Question: universal normalized local UV units
for the final two intrinsic g10^4*xi JL*C*x families identified by V199.
This prerequisite supports a complete missing coefficient, not another selected
identity. Outcomes: qualified units, disagreement or explicit regulator boundary.
No physical input, action, source convention, width or benchmark changes.

Keep source JL odd(dim1,gh-1), external C odd(dim1,gh1), external x even(dim1).
All four scalar sectors/all45 colors stay in the inherited graph domain; these
abstract units carry no chosen color coefficient. Ordered vertices:

- bubble: JL*a0*c0*Cext and a0*c0*xext;
- box: JL*L0*c0, a0*Cext*B1, L1*chi, chi*B0*xext.

The a*C*B derivative is placed separately on a,B,C; the scalar kinetic
derivative separately on internal chi,internal B or external x. All9 box
combinations are evaluated, including zero no-jet units for external derivatives.
Both mixed carrier orientations and ghost signs are retained; L/L inverse0,
scalar inverse1/Q and full general four-momentum/metric. Actual KL is an
antisymmetric ghost-pair polynomial without an extra1/2: later group contraction
must include both choices of the external ghost with their exterior signs.
No current width independence is transferred to a graph with B/B propagation.

Primary graded Hessian Born traces and replay proper Wick contractions retain
all2! or4! vertex orders, exponential factors and source/external ghost order.
The even external scalar occurs exactly once in every complete graph; the Born
exterior algebra tracks only the two odd external variables after extracting
that common linear scalar factor. Check this scalar commutes and the complete
two-generator product table; do not treat x as another Grassmann generator.
Require full generic-q kernels, all4 Lorentz components, both derivative IBP
relations and the complete unit table. Disclose all insensitive controls.

The pure-ghost bubble uses the qualified nonexceptional massless bubble UV
domain (Euclidean external P^2>0) or retained temporary IR restriction. It may
not be set to a fully scaleless zero-momentum integral. Reuse the qualified
full-Hessian heat/nonexceptional bubble evidence and check the dimensional
Feynman-parameter residue. The box reduces to the positive temporary scalar
reference integral already qualified in V200, 1/[Q(Q-Mref^2)]; reuse its UV
residue/IR qualification, not a new physical mass. No finite amplitude,
cutoff-power subtraction, physical IR removal or full QAP claim is made.

Units use common hbar/(32*pi^2*epsilon_UV), multiplier2i(Q)^2. Actual g10^4*xi
and source/kinetic/orbit tensors are not yet inserted. A number from this table
is not the physical source pole. Freeze source/controller/own-role inputs and
receipts first. Two sequential120-second/8GiB workers, minimum350MiB available
commit, separate120-second/8GiB validation. Preserve failures/versioned fixes;
no silent resource expansion or expensive old loop/Gamma/Q/Ward replay.

Validate independent kernels, explicit small matrix/Grassmann signs, all
normalizations, derivative sums and named omissions. Independence is bounded:
shared inputs, algebra utilities, conventions and AI authorship remain. Lean
coverage audit does not introduce a compilation gate or proof claim. Ceiling:
universal units only, not a coefficient or canonical integration. Full source,
Slavnov,E5/A5,QAP/measure/contact/IR/physical viability remain unqualified;
HB1/C5 blocked, flavor paused,C1_GS uncomputed,scalar warning,quartet failure,
custodyexit2/seven and authority34of39 preserved. Education nonblocking.
