"""All derivative units for JL*C*x, with an even external scalar."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
import importlib.util,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('qualified_graded_units',ROOT/'calculations/canonical_so10_auxiliary_quartet_g4_units/units.py');ex=importlib.util.module_from_spec(sp);sp.loader.exec_module(ex)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
oldinverse=ex.inverse;oldpack=ex.extpack
def inverse(a,b,epsilon=1,**opts):
    if a==b=='uv_chi':return ex.ZERO if opts.get('omit_scalar',False) else ex.t
    return oldinverse(a,b,epsilon,**{k:v for k,v in opts.items() if k!='omit_scalar'})
def extpack(P,order):
    terms={}
    for word,z in P.items():
        assert sum(n=='uv_xE' for n,j in word)<=1
        if any(n=='uv_xE' and j for n,j in word):continue
        rest=tuple((n,j) for n,j in word if n!='uv_xE');terms[rest]=terms.get(rest,0)+z
    return oldpack(terms,[n for n in order if n!='uv_xE'])
def model(kind,ds):
    w=ex.alphabet();w.fields={**{f'uv_B{b}_{mu}':(1,0,0) for b in range(2) for mu in range(4)},'uv_L0':(2,0,0),'uv_L1':(2,0,0),'uv_c0':(1,1,1),'uv_a0':(1,-1,1),'uv_chi':(1,0,0)};w.grades=w.fields;w.pairs=[];w.external={};w.p={n:v[2] for n,v in w.fields.items()}
    for n,grade in [('uv_J',(1,-1,1)),('uv_Ce',(1,1,1)),('uv_xE',(1,0,0))]:ex.register(w,n,grade)
    v=w.var
    if kind=='bubble':V=[w.mul(v('uv_J'),v('uv_a0'),v('uv_c0'),v('uv_Ce')),w.mul(v('uv_a0'),v('uv_c0'),v('uv_xE'))]
    else:
        assert kind=='box' and len(ds)==2;dF,dS=ds;assert dF in ['a','B','c'] and dS in ['s','B','x']
        F=w.add(*(w.scale(w.mul(w.D(v('uv_a0'),mu) if dF=='a' else v('uv_a0'),w.D(v('uv_Ce'),mu) if dF=='c' else v('uv_Ce'),w.D(v(f'uv_B1_{mu}'),mu) if dF=='B' else v(f'uv_B1_{mu}')),ex.ETA[mu]) for mu in range(4)))
        S=w.add(*(w.scale(w.mul(w.D(v('uv_chi'),mu) if dS=='s' else v('uv_chi'),w.D(v(f'uv_B0_{mu}'),mu) if dS=='B' else v(f'uv_B0_{mu}'),w.D(v('uv_xE'),mu) if dS=='x' else v('uv_xE')),ex.ETA[mu]) for mu in range(4)))
        V=[w.mul(v('uv_J'),v('uv_L0'),v('uv_c0')),F,w.mul(v('uv_L1'),v('uv_chi')),S]
    assert sum(sum(n=='uv_xE' for n,j in word) for P in V for word in P)==(1 if kind=='bubble' else 4)
    assert all(sum(n=='uv_xE' for n,j in word)==1 for word in V[-1]) and all(not any(n=='uv_xE' for n,j in word) for P in V[:-1] for word in P)
    return w,V,w.mul(v('uv_J'),v('uv_Ce'),v('uv_xE'))
ex.inverse=inverse;ex.extpack=extpack;ex.model=model
def born(kind,ds,**opts):
    w,V,target=model(kind,ds);names=list(w.fields);order=sorted(w.external);normal=extpack(target,order)[3];G={(i,j):{0:z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=inverse(a,b,**opts))};Hs=[ex.Hessian(P,w,order) for P in V];n=len(Hs);values=[]
    for order in permutations(Hs):
        A=G
        for j,H in enumerate(order):
            A=ex.mm(A,H)
            if j<n-1:A=ex.mm(A,G)
        z=sum(((-1)**w.p[names[i]]*P.get(3,ex.ZERO) for (i,j),P in A.items() if i==j),ex.ZERO)*ex.II*ex.num(s.Rational((-1)**(n+1),2*n))*normal;values.append(z)
    return sum(values,ex.ZERO),{'ordered_Born_kernels':[str(z.as_expr()) for z in values],'word_count':len(values),'common_even_external_scalar_extracted':True}
def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][route]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('AUX_SCALAR_UNITS_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AUX_SCALAR_UNDECLARED '+str(p))
    sys.addaudithook(guard);folder=ROOT/'calculations/canonical_so10_dimensionful_source_inventory';p=folder/('primary_result.json' if route=='primary' else 'replay_v2_result.json');r=read(folder/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);target=read(p)['targets']['C_JL_x'];assert target['log_profiles']==4 and target['power_profiles']==0
    cases=[('bubble',())]+[('box',ds) for ds in product(['a','B','c'],['s','B','x'])];calculate=born if route=='primary' else ex.wick;table={};details={};controls={}
    for kind,ds in cases:
        label=kind+('_'+''.join(ds) if ds else '');print('STAGE '+route+' '+label,flush=True);z,info=calculate(kind,ds);table[label]=str(ex.pole(z));details[label]={'full_general_q_kernel':str(z.as_expr()),**info}
        for mutation in ['omit_ghost','omit_mixed','omit_scalar','omit_BB']:
            q,unused=calculate(kind,ds,**{mutation:True});controls[label+'_'+mutation]={'unit':str(ex.pole(q)),'changes_result':q!=z}
    assert table['bubble']!='0' and table['box_as']!='0'
    for d in ['a','B','c']:assert s.expand(sum(s.sympify(table['box_'+d+v]) for v in ['s','B','x']))==0
    for d in ['s','B','x']:assert s.expand(sum(s.sympify(table['box_'+v+d]) for v in ['a','B','c']))==0
    for d in ['a','B','c']:assert table['box_'+d+'x']=='0'
    for d in ['s','B','x']:assert table['box_c'+d]=='0'
    w,V,target=model('bubble',());assert w.mul(w.var('uv_xE'),w.var('uv_J'))==w.mul(w.var('uv_J'),w.var('uv_xE')) and w.mul(w.var('uv_xE'),w.var('uv_Ce'))==w.mul(w.var('uv_Ce'),w.var('uv_xE'))
    assert w.mul(w.var('uv_J'),w.var('uv_Ce'))==w.scale(w.mul(w.var('uv_Ce'),w.var('uv_J')),-1)
    # A massless bubble is evaluated at nonexceptional P, never as a scaleless
    # zero-momentum integral. Retain the inherited exact heat-domain evidence.
    hp=ex.PKG/f'frozen_a10_e5_full_hessian/heat_{route}.json';hb=read(hp.parent/'bindings.json');assert hb['byte_sha256'][hp.relative_to(ROOT).as_posix()]==digest(hp);heat=read(hp);assert heat['exact_nonexceptional_bubble'] and heat['UV_log_coefficient']=='1/(16*pi**2)'
    e,M2,P2,mu2=s.symbols('eps Mref_squared P_squared mu_squared',positive=True)
    dimensional=(mu2/P2)**e*s.gamma(e)*s.gamma(1-e)**2/(s.gamma(2-2*e)*(4*s.pi)**(2-e));assert s.limit(e*dimensional,e,0,dir='+')==1/(16*s.pi**2)
    sf=ROOT/'calculations/canonical_so10_dimensionful_scalar_source_units';sp=sf/(route+'_result.json');sr=read(sf/'validation_receipt.json');assert sr['execution_state']=='COMPLETED' and sr['input_sha256'][str(sp)]==digest(sp);scalar=read(sp)['radial_integral'];assert scalar['IR_finite_for_temporary_Mref_squared_positive'] and scalar['residue']=='1/(16*pi**2)'
    print('RESULT '+json.dumps({'schema':'DIMENSIONFUL_AUXILIARY_SCALAR_UNITS_V1','route':route,'units':table,'full_kernel_details':details,'controls':controls,'both_derivative_IBP_sums_checked':True,'even_external_scalar_commutes_and_occurs_once':True,'odd_source_external_ghost_order_checked':True,'all4_Lorentz_components_retained':True,'unit_multiplier':'2*I*(q_squared)^2','massless_bubble_requires_nonexceptional_P_squared_positive':True,'massless_bubble_dimensionally_regulated_expression':str(dimensional),'massless_bubble_residue':'1/(16*pi**2)','inherited_heat_nonexceptional_bubble':heat['exact_nonexceptional_bubble'],'box_positive_scalar_reference_kernel':scalar,'no_scaleless_or_physical_IR_claim':True,'actual_Spin10_coefficient_or_Gamma_calculated':False,'full_source_Slavnov_E5_A5_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
