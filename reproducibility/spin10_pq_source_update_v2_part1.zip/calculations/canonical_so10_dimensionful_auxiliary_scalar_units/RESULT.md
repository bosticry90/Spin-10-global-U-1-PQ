# Complete auxiliary-source/scalar loop-unit table

Prospective qualification requires the completed validation receipt. The
remaining intrinsic g10^4*xi JL*C*x group has one bubble and one box family.
For the exact ordered vertices in RECORD, both independent loop methods give
the following units in common hbar/(32*pi^2*epsilon_UV):

| F derivative / scalar-kinetic derivative | chi internal | B internal | x external |
|---|---:|---:|---:|
| antighost internal | +2 | -2 | 0 |
| vector internal | -2 | +2 | 0 |
| ghost external | 0 | 0 | 0 |

The ordered KL-O_aCX ghost bubble unit is -2. There is no extra1/2 for its
antisymmetric source ghost pair; actual contraction must include both external
ghost choices with their exterior signs. Units are not the Spin(10) coefficient.

Primary graded Born traces and direct proper Wick contractions agree on full
generic four-momentum kernels, all2!/4! vertex orders and derivative IBP sums.
The box kernel for two internal derivatives is proportional to(Q)^2*t^4,
not a numerical temporal-momentum substitute. All4 Lorentz components and both
mixed orientations are retained. The scalar x is even and appears once;
extracting that common factor leaves only the two odd external variables in
the Born exterior algebra. No anticommuting scalar is assumed.

The massless bubble is assigned its local UV coefficient at nonexceptional
Euclidean external P^2>0, with the inherited full-Hessian heat evidence and a
dimensional Feynman-parameter residue1/(16*pi^2). It is not set to a scaleless
zero-momentum integral. The box uses the previously qualified positive temporary
scalar-reference domain, with the same UV residue and IR-finite radial kernel.
No finite amplitude, physical IR removal or gauge-invariant observable is claimed.

Ghost omission destroys the nonzero bubble and box units. Scalar or mixed-line
omission destroys nonzero box units but is insensitive to the pure-ghost bubble.
B/B omission is insensitive because no selected family uses such an edge;
all controls on the zero external-derivative units are insensitive. The two
workers take about1.77 and5.61 seconds after imports; no failed new worker.
Shared algebra helpers, action conventions and AI authorship limit independence.

Next: contract the actual S/K source, orbit, gauge-ghost, kinetic and reference
tensors over all45*45*328 positions, retaining actual Qa=-L and H*K=-I. Reuse
the qualified source/kinetic representation bridge, not a guessed sign or a
coefficient required by a desired Slavnov identity. Combine the two intrinsic
dimensionful nodes and known vacuum translations only after qualification.
No Gamma or scientific authority change. Full source/E5/A5/QAP/contact/IR and
physical viability remain open; blocked/paused boundaries and custodyexit2/seven
are unchanged. Lean compilation is not a universal prerequisite.
