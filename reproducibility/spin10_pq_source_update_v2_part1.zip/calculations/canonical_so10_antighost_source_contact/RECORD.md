# Two-antighost-source contact and selected source Slavnov assessment V1

Baseline 81955b0e3dfd7cb90d5f7a9970607b8b3b3d73b7. Standing delegation in
AGENTS.md authorizes this bounded continuation. The V162 result closed the
known partial background-Ward remainder; it did not close the Slavnov system.
Protected authority remains project_state.json v113/34 of 39.

Claim AS2: determine the actual one-loop dimension-zero local g10^2 Ja_i Ja_j
pole, with both Ja sources even, dimension 2 and ghost number 0. There are
1,035 symmetric coefficient slots, including identical even sources, and
2,025 ordered matrix positions. Do not infer its value from a desired identity.

For a proper one-loop two-leg source graph, n3+2*n4=2. Recover the complete
literal Ja inventory: linear Ja*Lambda has zero second integrated derivative;
the cubic Ja*a*C supplies the source Hessian; no classical two-Ja quartic
exists. Keep auxiliaries in the Legendre mean fields. A connected expression
with a linear source edge is not automatically a proper Gamma loop. Retain
all 45 source/ghost/antighost colors, the full principal reference before
support reduction, both odd orientations and the scalar/even complement.
Prove any forbidden cycle from actual source and inverse support. Positive-
dimensional insertions lower the superficial degree of this dimension-zero
UV logarithm; do not infer finite or IR zeros from that argument.

Primary uses the qualified literal physical Ja cubic, raw master-source
inventory and complete graded odd Hessians/reference products. Replay
reconstructs the H representation from physical ten-dimensional Spin(10)
commutators and independently enumerates proper Wick pairings/vertex pairs.
Compare complete source matrices and zero or nonzero tensors after both
finish. Actual workers must not read prior contact poles, measured Gamma,
required tensors, peer results or formal Ward completions for their values.

Use a nonzero mathematical control: two ghost colors h/m, even source J of
dimension 2, source interaction J*a_m*C_h, and reference ghost operator
R*(I-t*E_hm). t is an artificial kinetic-mixing control, not a physical input.
The actual block-diagonal reference is t=0. The normalized finite Grassmann
Gaussian gives Z(J)/Z(0)=1-t*J/R. Thus the quadratic Gamma kernel is
i*t^2/(2*R^2), with pole -t^2 relative to hbar/(32*pi^2*epsilon_UV).
Check this through graded Hessians and direct finite Gaussian expansion.
Wrong Ja parity, erased odd orientation and wrong identical-source factor
must be detected where sensitive. Repeated even sources must remain nonzero.
The UV annulus convention is reused; no whole-scaleless-integral zero.

Claim ASV-S: recover all classical Q' source-polynomial signatures and complete
forward/backward predecessor censuses for g10^4 Ja*C*AA, *AB and *BB with no
jets and coefficient dimension zero. Use the existing local type language;
all 1,286 columns and 508 deferred physical Euler programs remain accounted
for. The actual physical action is ghost/source free. A physical Euler term
cannot introduce Ja or C; a dimension-four input retaining Ja(d2), C(d1)
and a varied JB/Jx(d2) would have dimension at least 5. This excludes these
deferred programs from these targets only, rather than setting them to zero.
Quantum A_H is fixed; its Q' column is zero under the qualified split.

Only after actual AS2 agreement may the dependent assessment release the
qualified 92,236-term measured-functional recipe. Reuse existing measured
Ja*VV(g3), JLambda*C*VV(g4), mixed JLambda*Ja*C(g3) contact and all other
necessary classes identified by the census. Authenticate their actual scopes
and zeros, including AA; absence in a polynomial is not a measured zero.
If another unmeasured class occurs, report incomplete coverage and do not
call a selected known projection a complete pole relation.

Calculate the three selected Q' projections with prefix Leibniz and jet-
gradient methods, retaining source variations. Their full raw Lorentz/color
domain has 52,864,650 positions; covariance may compress it, but do not claim
fresh component integrations. Compare complete polynomials, zero complements,
all 45 Ja Eulers and meaningful omission/double-count controls. A g2*Jub13^2
control is admissible but unadopted and should expose the otherwise-zero
two-source class if its actual Q' image is visible. Record an insensitive
control honestly. Unknown quantum breakings and finite contacts stay unknown.

Two sequential read-only AS2/census workers: 120 seconds after imports,
8 GiB sampled private allocation, minimum available commit 350 MiB. If they
complete and agree, separately freeze up to two dependent assessment workers,
300 seconds/8 GiB each, plus scoped validation. Freeze exact source/controller
and input hashes before each phase. Write full native captures before any
qualification. Preserve failures; exhaustion is incomplete, never PASS or
a physical verdict. No silent resource increase, coefficient fit or reduced
target domain is permitted.

Authority ceiling: an actual selected logarithmic two-source pole and an
explicit selected measured Slavnov assessment, with completeness only where
its census/evidence warrants it. No full QAP, finite contact normalization,
measure/IR, quantum canonical equivalence, anomaly freedom or E5/A5 promotion.
HB1/C5 remain blocked, C1_GS uncalculated, flavor paused, quartet/g2 failures
and scalar quantum-control warning preserved. Custody exit 2/seven unresolved
is not PASS. No foundation, accepted benchmark/input, protected evidence,
branch, worktree, external action or remote changes. Science and AI-capability
objectives remain equal; shared assumptions/software/AI authorship are
disclosed. Education remains voluntary, concurrent and nonblocking.
