# Dense Hessian interface correction V2

The original primary run terminated with exit 1 in the nonzero unit control:
Fourier_vertex returns a dense list of rows, while contact.py attempted to
iterate it as a sparse dictionary. The original source, preparation and full
native capture remain immutable and unqualified. No original replay launched.

contact_v2.py traverses the actual dense matrix, checks its 4-by-4 dimensions,
and extracts each nonempty polynomial entry. All source inventory, full
reference, nilpotent-product/Wick checks, fixed unit kernel and pole, parity,
identical-source and odd-orientation controls, Q signatures and predecessor
requirements remain unchanged. No action, physical input or target value is
altered. The expected nonzero control was fixed analytically before V1.

Standing delegation authorizes two separately frozen sequential read-only V2
workers, each under the same 120-second/8-GiB/350-MiB limits. Use distinct
primary_v2/replay_v2 outputs; do not relabel or overwrite the original failed
run. Preserve code snapshots and captures before qualification. Agreement
must precede release of measured-functional data to a dependent assessment.
All authority and physical boundaries in RECORD.md remain binding.
