"""Actual two-Ja proper pole and full classical predecessor census; no pole fit."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import combinations_with_replacement
from functools import lru_cache
import importlib.util,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,canonical,decode_typed,SOURCE,AUX,ANTI,g,xi
from a10_e5_measured_functional_v3 import signatures,census
from a10_e5_measured_functional_control_v2 import TYPES,kind
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_ghost_normalization import input_chart,adjoints,linear,cm
from a10_e5_vector_ghost_v2 import full_alphabet,reference
from a10_e5_measured_restoration import physical_action_screen
import a10_e5_quartic_algebra as ex
spec=importlib.util.spec_from_file_location('sealed_operator_utils',ROOT/'calculations/canonical_so10_constant_background_operators/operators.py')
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
num=ex.coefficient;Z=ex.D.zero
TARGETS={tag:{'types':tuple(sorted(['Ja','C',*vectors])),'jets':0,'g':4}
         for tag,vectors in [('AA',['A','A']),('AB',['A','B']),('BB',['B','B'])]}

def inventory(role):
    raw=read(PKG/f'frozen_a10_bv_master/{role}.json')['source_polynomial'];lin={};nonlin={};counts=Counter();w=alphabet()
    for row in raw:
        ns=[n.partition('__')[0] for n in row['word']];js=[n for n in ns if n in SOURCE]
        if not js:continue
        assert len(js)==1 and sum(n.startswith('J') for n in ns)==1
        assert all('__' not in n for n in row['word']);i=SOURCE.index(js[0]);counts[i]+=1
        P=decode_typed([row]);word,z=next(iter(P.items()))
        if len(ns)==2:
            assert sorted(ns)==sorted([SOURCE[i],AUX[i]]) and z==-1;lin[word]=z
        else:
            assert len(ns)==3 and i>=12 and s.Poly(z,g,xi).monoms()==[(1,0)]
            assert sum(n in ANTI[12:] for n in ns)==1 and sum(n in [f'C{h}' for h in range(12)] for n in ns)==1
            nonlin[word]=z
    assert len(lin)==45 and len(nonlin)==180 and set(counts)==set(range(45))
    assert all(w.grades[n]==(2,0,0) for n in SOURCE)
    assert all(sum(n in w.fields for n,j in word)==1 for word in lin)
    for i in range(45):assert canonical(w.add(w.EL(lin,AUX[i]),w.var(SOURCE[i])))=={}
    assert len(w.fields)==643 and sum(n.startswith('x_') for n in w.fields)==328 and sum(w.p[n] for n in w.fields)==90
    return {'all45_sources_screened':True,'linear_terms':45,'nonlinear_terms':180,
      'linear_source_second_integrated_derivative_zero':True,'explicit_two_Ja_vertex_absent':True,
      'all643_integrated_fields_retained':True,'scalar_even_complement':328,'odd_quantum_fields':90}

def literal(data):
    out={i:{} for i in range(45)}
    for row in data['antighost_source_cubic']:
        ns=row['word'];i=int(next(n[2:] for n in ns if n.startswith('Jp')))
        a=int(next(n[2:] for n in ns if n.startswith('ap')));c=int(next(n[2:] for n in ns if n.startswith('Cp')))
        assert a>=12 and c<12
        u.put(out[i],(a,c),-num(s.sympify(row['coefficient'])))
    assert sum(map(len,out.values()))==334
    return out

def physical(role):
    unused,QM,FM,GM,GI,EM,EH,PM=input_chart(role);parent=adjoints();out={i:{} for i in range(45)}
    for h in range(12):
        A=cm(EM.T*linear(EH[:,h],parent)*EM)
        for (i,j),z in A.todok().items():u.put(out[12+i],(12+j,h),num(z))
    return out

def full_odd_reference():
    w=full_alphabet();G,p=reference(w);ns=list(w.fields);small={};orientations=Counter()
    assert len(ns)==315 and all(p[i]==p[j] for i,j in G)
    for (i,j),poly in G.items():
        if not p[i]:continue
        a,b=ns[i],ns[j];assert a.startswith(('Cp','ap')) and b.startswith(('Cp','ap'))
        assert set(poly)=={(0,0)}
        row=int(a[2:])+(0 if a.startswith('Cp') else 45);col=int(b[2:])+(0 if b.startswith('Cp') else 45)
        small[row,col]=poly[0,0];orientations[a[:2]+'-'+b[:2]]+=1
    assert orientations=={'Cp-ap':45,'ap-Cp':45} and len(small)==90
    assert all(small.get((h,45+m),Z)==Z and small.get((45+m,h),Z)==Z for h in range(12) for m in range(12,45))
    return small,{'full315_reference_constructed_before_reduction':True,'both45_odd_orientations':dict(orientations),
      'even_odd_principal_cross_blocks_zero':True,'arbitrary553_even_block_cannot_close_two_Ja_bubble':True}

def actual_primary(R,G):
    HS={}
    for i,A in R.items():
        H={}
        for (a,c),z in A.items():u.put(H,(45+a,c),z);u.put(H,(c,45+a),-z)
        assert all(a>=45 and b<45 or a<45 and b>=45 for a,b in H)
        HS[i]=u.mm(G,H)
    count=0
    for i in range(45):
        for j in range(45):assert not u.mm(HS[i],HS[j]);count+=1
    return {'ordered_full90_Hessian_products_zero':count,'nonempty_source_Hessians':sum(bool(A) for A in HS.values()),
      'zero_integrand_before_integration':True}

def actual_replay(R,G):
    vertices=[(i,a,c,z) for i,A in R.items() for (a,c),z in A.items()];count=0
    for i,a,c,z in vertices:
        for j,b,d,v in vertices:
            # Three four-port matchings: within-vertex is disconnected;
            # aa/CC is forbidden by ghost number; the proper cross cycle
            # requires BOTH absent H-ghost/M-antighost inverse entries.
            assert not G.get((c,45+b),Z) and not G.get((45+a,d),Z)
            assert not G.get((45+a,45+b),Z) and not G.get((c,d),Z)
            count+=1
    assert count==334**2
    return {'ordered_vertex_pairs_screened':count,'proper_cross_cycle_forbidden_edges':2,
      'all_three_Gaussian_port_matchings_classified':True,'zero_integrand_before_integration':True}

def unit(role):
    w=alphabet();names=['unit_C0','unit_C1','unit_a0','unit_a1']
    w.fields={n:(1,1 if '_C' in n else -1,1) for n in names};w.grades=w.fields;w.external={};w.p={n:1 for n in names};w.pairs=[]
    register(w,'unit_Ja',(2,0,0));v=w.var
    S=w.mul(v('unit_Ja'),v('unit_a1'),v('unit_C0'));assert w.grade(S,(4,0,0)) and w.mul(v('unit_Ja'),v('unit_Ja'))
    register(w,'unit_Ja',(2,0,1));assert not w.grade(S,(4,0,0));register(w,'unit_Ja',(2,0,0))
    r,t,J=s.symbols('unit_R unit_t unit_J',real=True);A=s.Matrix([[0,0],[1,0]]);P0=r*s.Matrix([[1,-t],[0,1]])
    detail={}
    if role=='primary':
        q=list(s.symbols('unit_q0:4',real=True));raw=Fourier_vertex(S,w,'primary',q,q,{})
        word=next(iter(v('unit_Ja')));H=s.zeros(4)
        assert len(raw)==4 and all(len(row)==4 for row in raw)
        for i,row in enumerate(raw):
            for j,poly in enumerate(row):
                if poly:
                    assert set(poly)=={word};H[i,j]=poly[word]
        inv=P0.inv();G=s.zeros(4);G[:2,2:]=inv;G[2:,:2]=-inv.T
        kernel=s.factor(s.I*s.trace(G*H*G*H)/4)
        bad=s.Matrix(G);bad[2:,:2]=s.zeros(2);badkernel=s.factor(s.I*s.trace(bad*H*bad*H)/4)
        detail['opposite_odd_orientation_omitted_pole']=str(s.factor(2*s.I*r**2*badkernel))
        assert s.factor(2*s.I*r**2*badkernel)==-t**2/2
    else:
        action=w.add(*(w.scale(w.mul(v(f'unit_a{i}'),v(f'unit_C{j}')),-P0[i,j]) for i in range(2) for j in range(2)),S)
        top=tuple(sorted((n,()) for n in names));z=0
        for word,c in w.scale(w.mul(action,action),-s.Rational(1,2)).items():
            quantum=tuple(a for a in word if a[0] in names)
            if quantum==top:z+=c*J**sum(n=='unit_Ja' for n,j in word)
        norm=s.factor(z/z.subs(J,0));assert s.simplify(norm-(1-t*J/r))==0
        kernel=s.factor((-s.I*s.log(norm)).series(J,0,3).removeO().coeff(J,2))
        detail['finite_Gaussian_normalized_Z']=str(norm)
    pole=s.factor(2*s.I*r**2*kernel);assert kernel==s.I*t**2/(2*r**2) and pole==-t**2
    return {'kernel':str(kernel),'pole':str(pole),'actual_block_t0_pole':str(pole.subs(t,0)),
      'altered_HM_edge_t1_pole':str(pole.subs(t,1)),'wrong_identical_factor_t1_pole':str((2*pole).subs(t,1)),
      'wrong_odd_Ja_grade_rejected':True,'repeated_even_source_retained':True},detail

@lru_cache(None)
def degrees(text):return tuple(k[0] for k,v in s.Poly(s.sympify(text,locals={'g10':g}),g).terms() if v)
def fast_signatures(e2):
    result=defaultdict(set);positive=Counter();terms=0;physical=0
    for name,data in e2['complete_columns'].items():
        tag=kind(name);expected=TYPES[tag][0]+1;physical+=data['physical_program'] is not None
        for row in data['source_polynomial']:
            terms+=1;parts=[n.partition('__') for n in row['word']];types=tuple(sorted(kind(n) for n,sep,j in parts));jets=sum(len(j) for n,sep,j in parts)
            cd=expected-sum(TYPES[t][0] for t in types)-jets;assert cd>=0
            for power in degrees(row['coefficient']):
                assert power>=0
                if cd:positive[tag,cd]+=1
                else:result[tag].add((types,jets,power))
    return result,{'all1286_columns':len(e2['complete_columns']),'source_polynomial_terms_screened':terms,
      'positive_dimension_terms_excluded_only_from_zero_dimension_projectors':{str(k):v for k,v in sorted(positive.items())},
      'physical_Euler_program_slots_retained_as_deferred':physical}

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json')
    assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):raise PermissionError('AS2_WORKER_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AS2_PRIOR_POLE_PEER_OR_UNDECLARED_READ')
    sys.addaudithook(guard)
    stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);a=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-a});return value
    inv=stage('complete_literal_Ja_source_inventory',lambda:inventory(role))
    data=read(Path(prep['classical_export']));R=stage('literal_source' if role=='primary' else 'physical10_source',lambda:literal(data) if role=='primary' else physical(role))
    assert R==literal(data),'OWN_CLASSICAL_SOURCE_MATRICES_BEFORE_POLE'
    assert all(a>=12 and h<12 for A in R.values() for a,h in A)
    G,ref=stage('full_reference_then_odd_support',full_odd_reference)
    proof=stage('actual_all_ordered_Hessian_products' if role=='primary' else 'actual_all_proper_Wick_ports',lambda:actual_primary(R,G) if role=='primary' else actual_replay(R,G))
    controls,unit_detail=stage('graded_Hessian_unit' if role=='primary' else 'finite_Grassmann_Gaussian_unit',lambda:unit(role))
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json')
    sig,screen=stage('all_Q_column_signatures',lambda:signatures(e2,alphabet()) if role=='primary' else fast_signatures(e2))
    screen={k:v for k,v in screen.items() if k!='physical_Euler_projector_zero_proof' and k!='full_physical_Euler_set_to_zero'}
    assert screen['all1286_columns']==1286 and screen['physical_Euler_program_slots_retained_as_deferred']==508
    action=stage('actual_physical_action_content',physical_action_screen)
    assert TYPES['JB'][0]+TYPES['Ja'][0]+TYPES['C'][0]==5>4 and TYPES['Jx'][0]+TYPES['Ja'][0]+TYPES['C'][0]==5>4
    pred=stage('complete_forward_predecessors' if role=='primary' else 'complete_backward_predecessors',lambda:{name:census(sig,target,role) for name,target in TARGETS.items()})
    stable_sig={tag:[[list(types),jets,power] for types,jets,power in sorted(values)] for tag,values in sorted(sig.items())}
    source=[[i,u.pack(A)] for i,A in sorted(R.items())]
    result={'schema':'ANTIGHOST_SOURCE_CONTACT_AND_CENSUS_V1','route':role,'source_inventory':inv,'source_matrices':source,
      'source_matrices_sha256':sha256(json.dumps(source,separators=(',',':')).encode()).hexdigest(),
      'reference_support':ref,'actual_symmetric_JaJa_pole_without_g_squared':[[i,j,'0'] for i,j in combinations_with_replacement(range(45),2)],
      'symmetric_coefficient_slots':1035,'ordered_matrix_slots':2025,'actual_integrand_zero_before_integration':True,
      'unit_controls':controls,'Q_signature_table':stable_sig,'Q_column_screen':screen,'target_specs':{n:{**v,'types':list(v['types'])} for n,v in TARGETS.items()},
      'complete_type_predecessors':pred,'physical_action_content':action,'deferred_programs_set_zero':False,
      'deferred_exclusion':'Ja(d2) and C(d1) cannot be created by physical gauge/scalar Eulers; retaining both with varied JB/Jx(d2) requires input dimension>=5>4.',
      'method_details':{'actual_pole_proof':proof,'unit':unit_detail,'stages':stages},
      'known_Gamma_or_required_pole_read':False,'finite_contact_normalization_adopted':False,'full_E5_A5_or_anomaly_freedom':False,
      'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
