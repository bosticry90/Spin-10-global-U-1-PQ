# Two-antighost-source pole and selected Slavnov relations

The actual dimension-zero one-loop g10^2 Ja_i Ja_j ultraviolet pole is zero
in all 1,035 symmetric source slots, including identical even sources. With
this last input measured, the complete selected logarithmic-pole left sides
for g10^4 Ja*C*AA, Ja*C*AB and Ja*C*BB also vanish. These statements concern
the declared source sectors and UV prescription; they do not establish full
Slavnov restoration, anomaly freedom or E5/A5 acceptance.

## Actual contact calculation

The [frozen record](RECORD.md) fixes the question before computation. The
complete literal source inventory contains 45 linear and 180 nonlinear Ja
terms. The linear Ja*Lambda term has zero integrated-field Hessian and cannot
supply a proper one-loop two-source graph. The cubic Ja*a*C vertices contain
334 physical coefficients. Their support requires an unbroken ghost to join
a broken antighost; the actual principal inverse has no such edge. Thus the
two-vertex proper integrand vanishes before integration. This is not an
assignment of zero to a whole scaleless integral.

Primary constructs the full graded odd Hessians and checks all 2,025 ordered
products. Replay reconstructs the source matrices from physical Spin(10)
commutators and screens all 111,556 ordered vertex pairs and the three Wick
pairing classes. Both retain the complete reference before reduction, both
odd orientations, all 45 sources and the even/scalar complement. Their source
matrices, 1,035 coefficient slots and complete type censuses agree exactly.

The independently specified two-color control has quadratic kernel
i*t^2/(2*R^2) and pole -t^2 in units hbar/(32*pi^2*epsilon_UV). The actual
block-diagonal case t=0 vanishes; the artificial forbidden-edge case t=1
returns -1. Wrong identical-source normalization returns -2; dropping one
odd orientation returns -1/2. Incorrect odd Ja parity is rejected, while
repeated even sources survive. The control is unphysical and is not an input
change or adopted counterterm.

## Selected relation and completeness

Forward and backward censuses screen all 1,286 Q' columns and 214,340 explicit
source-polynomial rows. They retain all 508 deferred physical Euler programs
as deferred. The ghost/source-free physical action cannot introduce Ja or C;
retaining both with a varied dimension-two physical antifield would require
an input of dimension at least five. This excludes those programs from these
targets only. Quantum A_H remains fixed under the qualified split.

The censuses yield twelve routes through eight distinct input classes:
Ja*VV at g3, JLambda*C*VV at g4 (AA, AB, BB separately), JLambda*Ja*C at g3,
and Ja*Ja at g2. All eight have actual measured evidence. In particular,
zero AA components and the mixed contact are authenticated measured zeros,
not absence mistaken for evidence. Historical selected outputs and receipts
are authenticated without rerunning their expensive loops.

Only after paired contact agreement does the dependent calculation release
the current 92,236-term measured-functional recipe. Its 33,384 relevant terms
give the following exact no-jet results through prefix Leibniz and jet-gradient
methods:

| Target | Complete selected pole left side | New g4 node's variation terms | All 45 Ja Eulers |
| --- | --- | --- | --- |
| AA | 0 | 0 | 0 |
| AB | 0 | 10,304 | 0 |
| BB | 0 | 21,256 | 0 |

The raw target domain has 52,864,650 Lorentz/color positions; this increment
uses qualified covariance and complete polynomial projections rather than
fresh integration at every position. Omitting or double-counting the actual
new node changes AB and BB. Omitting source variations also changes AB/BB;
AA is insensitive. An unadopted g2*Jub13^2 negative control changes BB and is
insensitive in AA/AB. These insensitive cases are not counted as successful
controls. There is no remaining local total-derivative ambiguity in the
identically zero no-jet result.

## Execution, verification and limits

The original V1 primary failed with a dense-list/sparse-dictionary interface
error in the nonzero unit fixture. Its code, preparation and full exit-1
capture remain unqualified. The [V2 correction](CORRECTION_V2.md) changes only
that interface and preserves every mathematical assertion and physical input.
No original replay ran. Qualified V2 contact/census runtimes are 40.08/5.10
seconds; dependent primary/replay are 57.25/58.78 seconds after imports,
within their respective 120/300-second and sampled 8-GiB limits.

The completed validation_receipt.json authenticates sources, frozen inputs,
native captures, complete paired mathematical outputs, controls and authority
preservation. It separately checks the small injected-source control against
the actual Q' column. This is scoped validation, not a fresh historical physics
replay or a byte-identical same-command replay pair. All derivations share the
action, charts, arithmetic libraries, UV prescription and AI authorship. Their
agreement cannot independently validate those assumptions or experimental
relevance.

Known Gamma remains 92,236 terms: the newly measured contact is zero. The
previous qualified zero background-Ward remainder is preserved. Unknown
quantum breakings, finite contact normalization, measure/IR premises, QAP,
other source sectors and full restoration remain open. Formal authority stays
v113/34 of 39; project_state.json is unchanged. HB1/C5 remain blocked, C1_GS
uncalculated and flavor paused. Quartet/g2 failures, scalar quantum-control
warning and custody exit 2/seven unresolved remain preserved; custody was not
rerun. No foundation, physical input, accepted benchmark or remote changed.

Track B records successful source-support reduction, complete dependency
census, and a preserved/corrected implementation failure; it does not claim
independent scientific confirmation. Education is concurrent, voluntary and
nonblocking. The next justified increment is a bounded remaining-source-sector
inventory, using actual qualified scopes before choosing another pole tensor.
