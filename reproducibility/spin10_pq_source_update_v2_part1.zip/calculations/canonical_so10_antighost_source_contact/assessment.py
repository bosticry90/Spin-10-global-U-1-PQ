"""Release qualified measured inputs only after paired actual contact agreement."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,canonical,decode_typed,rows,SOURCE,g,s
from a10_e5_measured_functional_v3 import projected_Q
from a10_e5_measured_functional_control_v2 import kind,TYPES
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def typ(word):return tuple(sorted(kind(n) for n,j in word)),sum(len(j) for n,j in word)
def summary(P):
    table=rows(P)
    return {'terms':len(P),'sha256':sha256(json.dumps(table,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'first_witness':table[:4]}
def selected(P,classes):
    choices=defaultdict(set)
    for types,jets,power in classes:choices[types,jets].add(power)
    out={}
    for word,z in P.items():
        powers=choices.get(typ(word))
        if powers:
            poly=s.Poly(z,g);c=sum((poly.coeff_monomial(g**power)*g**power for power in powers),s.Integer(0))
            if c:out[word]=c
    return canonical(out)

def filtered_Q(e2,names,pred):
    needed=defaultdict(set)
    for table in pred.values():
        for row in table:needed[row['varied_type']].add((tuple(row['Q_image_types']),row['Q_image_jets'],row['Q_g']))
    q={};seen=0;retained=0;fixed=0
    for name in sorted(names):
        if kind(name)=='A':q[name]={};fixed+=1;continue
        column=e2['complete_columns'][name];assert column['physical_program'] is None
        allowed=needed.get(kind(name),set());P={}
        for row in column['source_polynomial']:
            seen+=1;pieces=[v.partition('__') for v in row['word']];types=tuple(sorted(kind(n) for n,sep,j in pieces));jets=sum(len(j) for n,sep,j in pieces)
            cd=TYPES[kind(name)][0]+1-sum(TYPES[t][0] for t in types)-jets
            powers={power for image,beta,power in allowed if image==types and beta==jets}
            if cd or not powers:continue
            word,z=next(iter(decode_typed([row]).items()));poly=s.Poly(z,g)
            c=sum((poly.coeff_monomial(g**power)*g**power for power in powers),s.Integer(0))
            if c:P[word]=P.get(word,0)+c;retained+=1
        q[name]=canonical(P)
    return q,{'active_names':len(names),'source_polynomial_rows_screened':seen,'retained_target_rows':retained,
      'fixed_external_A_components':fixed,'active_deferred_physical_programs':0,'census_projection_not_full_Q_truncation':True}

def authenticate_old(folder,role,file,flag):
    binding=read(folder/'bindings.json');receipt=read(folder/'validation_receipt.json')
    assert digest(folder/'validation_receipt.json')==binding['validation_receipt_sha256'] and receipt[flag]
    path=folder/file;rel=path.relative_to(ROOT).as_posix();assert digest(path)==binding['byte_sha256'][rel]
    return read(path),{'path':rel,'sha256':digest(path),'receipt_sha256':digest(folder/'validation_receipt.json'),
      'scope':'authenticate_needed_qualified_output_and_receipt_only_no_old_gate_or_loop_replay'}

def main():
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'assessment_preparation.json')
    assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    allowed={str(Path(n).resolve()) for n in prep['read_json_by_role'][role]}
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        p=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):raise PermissionError('AS2_ASSESSMENT_WRITE')
        if p.suffix=='.json' and str(p.resolve()) not in allowed:raise PermissionError('AS2_ASSESSMENT_UNDECLARED_OR_PEER_READ')
    sys.addaudithook(guard);stages=[]
    def stage(name,fn):
        print('STAGE '+role+' '+name,flush=True);a=time.perf_counter();value=fn();stages.append({'name':name,'seconds':time.perf_counter()-a});return value
    actual=read(OUT/(role+'_v2_result.json'))
    assert actual['actual_integrand_zero_before_integration'] and len(actual['actual_symmetric_JaJa_pole_without_g_squared'])==1035
    assert all(z=='0' for i,j,z in actual['actual_symmetric_JaJa_pole_without_g_squared'])
    pred=actual['complete_type_predecessors'];spec=actual['target_specs'];w=alphabet()
    assert actual['Q_column_screen']['physical_Euler_program_slots_retained_as_deferred']==508 and not actual['deferred_programs_set_zero']
    def recover():
        prior=read(ROOT/'calculations/canonical_so10_auxiliary_source_quartic_pole/dependent_result.json');rec=prior['updated_known_recipe'];pair=rec['prior_source_pair_recipe'];base=pair['prior_recipe']
        initial=read(PKG/base['base_path'])
        old=canonical(w.add(decode_typed(initial[base['base_key']]),decode_typed(base['add_once']),decode_typed(pair['add_source_pair_once']),decode_typed(rec['add_actual_source_quartet_once'])))
        assert len(old)==60676
        new=decode_typed(read(ROOT/f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json')['new_actual_g4_node'])
        known=canonical(w.add(old,new));assert len(known)==92236 and len(new)==31560
        return known,new
    known,new=stage('release_exact_current_measured_recipe_AFTER_actual_agreement',recover)
    ja,ja_auth=stage('authenticate_existing_complete_Ja_vector_pole',lambda:authenticate_old(PKG/'frozen_a10_e5_antighost_vector',role,role+'.json','actual_antighost_vector_poles_qualified'))
    mixed,mix_auth=stage('authenticate_existing_zero_mixed_contact',lambda:authenticate_old(PKG/'frozen_a10_e5_mixed_contact',role,role+'_v2.json','actual_mixed_contact_zero_pole_qualified'))
    assert ja['domain']['total_symmetric_slots']==1174770 and ja['actual_pole']['AA']==[]
    assert mixed['actual_contact_pole']==[] and mixed['complete_actual_contact_slots']==91125 and mixed['actual_contact_integrand_zero_before_integration']
    catalog={};ja_classes=set();new_classes=set()
    for tag,vectors in [('AA',['A','A']),('AB',['A','B']),('BB',['B','B'])]:
        a=(tuple(sorted(['Ja',*vectors])),0,3);b=(tuple(sorted(['C','JL',*vectors])),0,4)
        ja_classes.add(a);new_classes.add(b)
        catalog[a]={'status':'MEASURED_ZERO' if tag=='AA' else 'MEASURED','evidence':ja_auth,'scope':'complete_'+tag+'_Ja_vector_pair_g3'}
        catalog[b]={'status':'MEASURED_ZERO' if tag=='AA' else 'MEASURED','evidence':{'path':f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json','sha256':digest(ROOT/f'calculations/canonical_so10_source_vector_color_tensor/canonical_{role}_result.json')},'scope':'complete_'+tag+'_JLambda_C_vector_pair_g4'}
    contact_class=(tuple(sorted(['C','JL','Ja'])),0,3);as2_class=(('Ja','Ja'),0,2)
    catalog[contact_class]={'status':'MEASURED_ZERO','evidence':mix_auth,'scope':'all91125_mixed_contact_g3_slots'}
    catalog[as2_class]={'status':'MEASURED_ZERO','evidence':{'path':f'calculations/canonical_so10_antighost_source_contact/{role}_v2_result.json','sha256':digest(OUT/(role+'_v2_result.json'))},'scope':'all1035_symmetric_two_Ja_g2_slots'}
    assert selected(known,ja_classes)==decode_typed(ja['canonical_full_g_cubed_density'])
    assert selected(known,new_classes)==new
    assert not selected(known,{contact_class,as2_class})
    classes={(tuple(row['input_types']),row['input_jets'],row['input_g']) for table in pred.values() for row in table}
    chosen=stage('select_complete_census_admitted_known_inputs',lambda:selected(known,classes))
    names={n for word in chosen for n,j in word}|{'Jub13'}
    e2=read(PKG/f'frozen_a10_e2_transport/{role}.json')
    q,screen=stage('exact_target_Q_images_with_physical_Euler_exclusion',lambda:filtered_Q(e2,names,pred))
    qfields={n:P for n,P in q.items() if n in w.fields or not n.startswith('J')}
    control=w.scale(w.mul(w.var('Jub13'),w.var('Jub13')),g**2);assert w.grade(control,(4,0,0)) and control
    answers={}
    for name,target in spec.items():
        target={**target,'types':tuple(target['types'])}
        P=stage('selected_g4_'+name,lambda:projected_Q(chosen,q,w,target,role))
        contribution=stage('new_measured_source_node_'+name,lambda:projected_Q(new,q,w,target,role))
        no_sources=stage('source_omission_control_'+name,lambda:projected_Q(chosen,qfields,w,target,role))
        injected=stage('two_Ja_type_control_'+name,lambda:projected_Q(control,q,w,target,role))
        eulers={n:canonical(w.EL(P,n)) for n in SOURCE}
        coverage=[]
        for row in pred[name]:
            key=(tuple(row['input_types']),row['input_jets'],row['input_g'])
            coverage.append({**row,**catalog.get(key,{'status':'UNMEASURED','evidence':None})})
        complete=all(row['status']!='UNMEASURED' for row in coverage)
        answers[name]={'coverage':coverage,'complete_pole_input_coverage':complete,
          'known_projection_without_g4':rows(P),'new_g4_node_projection_without_g4':rows(contribution),
          'all45_Ja_Eulers':{n:rows(E) for n,E in eulers.items()},'nonzero_Ja_Eulers':sum(bool(E) for E in eulers.values()),
          'known_pole_left_side_zero':not bool(P),'complete_selected_log_pole_left_side_zero':complete and not bool(P),
          'omitting_new_node_changes_projection':bool(contribution),'doublecount_changes_projection':bool(contribution),
          'source_variation_omission':{'changed':no_sources!=P,**summary(no_sources)},
          'type_admissible_unadopted_Jub13_squared_control':{'nonzero':bool(injected),'projection_without_g4':rows(injected)}}
    result={'schema':'ANTIGHOST_SOURCE_CONTACT_SELECTED_SLAVNOV_ASSESSMENT_V1','route':role,
      'actual_contact_agreement_before_measured_data':True,'known_measured_functional_terms':92236,
      'chosen_census_input_terms':len(chosen),'unique_input_classes':len(classes),'targets':answers,
      'all_target_pole_inputs_measured':all(v['complete_pole_input_coverage'] for v in answers.values()),
      'all_selected_complete_log_pole_left_sides_zero':all(v['complete_selected_log_pole_left_side_zero'] for v in answers.values()),
      'Q_target_screen':screen,'deferred_physical_Euler_programs_set_zero':False,
      'unknown_quantum_breaking_set_zero':False,'finite_contact_normalization_adopted':False,'full_E5_A5_or_anomaly_freedom':False,
      'old_expensive_physics_replayed':False,'stages':stages,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
