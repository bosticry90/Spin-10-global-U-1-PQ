# Ordinary g2 gauge-source/ghost derivative units V1

Baselineb8095e1cdae6853ff797b98554a6f24ff5ccd8c1. The complete source-linear
frontier admits only SB*F for the ordinary g2 JB*partial C UV coefficient;
the lower g*xi SB*X result is distinct. This increment fixes its general-
momentum signs and logarithmic Taylor factors before actual color contraction.
Standing delegation; no physical input, normalization or benchmark adoption.

Target is ordered J_mu*partial_mu C without extra factorial, J odd(d2,gh-1),
C odd(d1,gh+1), common hbar/(32*pi^2*epsilon_UV). Use the unit source
S=J_mu B_left,mu c and three ordinary ghost derivative placements
F_a=sum_nu eta_nunu partial_nu(a) B_right,nu C,
F_B=sum_nu eta_nunu a partial_nu(B_right,nu) C,
F_C=sum_nu eta_nunu a B_right,nu partial_nu C.
All vertices are even,d4,gh0 before Fourier transformation.

q is the vector-line momentum, p enters at the external C, r=q-p. Incoming
Fourier-mode momenta are B_left:q,B_right:-q,c:-r,a:r,J:-p,C:p. They conserve
momentum at both vertices. Left/right vector labels distinguish ends of one
line, not new particles: their only cross covariance is the actual full B/B
symbol D_munu(q)=-eta_mumu delta_munu/Q+(1-W)q_mu q_nu/Q^2, Q=q eta q.
The odd inverse is G_ca=1/(r eta r),G_ac=-1/(r eta r). Keep both vector and
odd inverse orientations. Full643 reference support was screened in the
frontier; no auxiliary endpoint appears in this selected bubble.

Primary uses full graded Fourier Hessians after explicit mode substitution,
both Born words with -i/4, and the first external-momentum UV Taylor coefficient
with exact Lorentz/sphere moments. Replay independently expands ordered Wick
contractions, external odd extraction, vertex/exponential factors, then combines
denominators by Feynman parameters and shifts the loop variable before its
linear-p projection. Keep all4 source polarizations and all4 p components.
Compare all12 full rational kernels and48 density-coefficient positions.

After removing the external derivative's i, the inherited Minkowski UV pole
factor gives twice the scalar-I0 coefficient in32pi² units. The candidate
diagonal density factors to test are U_a=(3-W)/2, U_B=W, U_C=-(3+W)/2;
offdiagonal factors zero. These are analytical hypotheses from contraction,
not normalization values to fit. A disagreement must be preserved.

Feynman/Schwinger controls retain a positive temporary IR reference and prove
the normalized scalar bubble UV residue1 and the finite three-denominator
mass term's zero residue. This is not a whole scaleless integral or a finite
amplitude. Zeroth-p odd kernels integrate to zero, but their discarded linear
term need not. Establish that omitting Taylor would lose the nonzero signal.

Controls: all derivative IBP sums F_a+F_B+F_C=0 before and after integration;
random fixed coefficients(2,3,5) equal the current-reduced(-1,2) combination;
dropping one distinct Born/Wick order changes a nonzero factor; wrong source
parity rejected; incorrect momentum routing fails vertex conservation; omitting
transverse B/B changes the a/C cases (B case should be insensitive); dropping
the longitudinal correction changes generic W dependence; wrong Euclidean
angular metric breaks four-Lorentz equality. Report insensitive cases honestly.
Also check a permissible loop-momentum shift leaves the UV logarithm unchanged.

Two sequential blind read-only workers,120seconds after imports/sampled8GiB,
>=350MiB available commit; freeze sources/controller/input bytes first.
Actual group tensors,poles,required identities,known Gamma and peers are denied.
Preserve full native captures and failures. Validate paired complete kernels,
UV factors and controls before commit, then freeze a separate actual color
calculation if justified. No old expensive integration or method rewrite.

Ceiling: unit factors only, not an actual Spin(10) pole, full source/Slavnov
restoration,QAP/finite contacts/measure/IR,anomaly freedom or E5/A5. State
v113/34of39 unchanged; HB1/C5 blocked,C1_GS uncalculated,flavor paused; prior
failures/scalar warning/custodyexit2/seven preserved. No accepted input/
benchmark/foundation, protected evidence or remote changes. Shared toy model,
helper arithmetic, UV assumptions and AI authorship limit independence.
Education remains voluntary, concurrent and nonblocking.
