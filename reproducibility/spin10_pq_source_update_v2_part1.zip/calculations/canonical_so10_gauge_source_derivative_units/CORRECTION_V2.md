# Symbol-binding correction V2

The original primary completed all12 kernels and48 density coefficients, then
failed the B-placement transverse-deletion control. Its source, preparation
and native failed capture remain unchanged; it exported no qualified result.

The control parsed its stored gs_W string without the declared real-symbol
binding. SymPy therefore compared two distinct symbols with the same printed
name. A direct parser control confirms unequal symbols before binding and
zero difference with locals={str(W):W}. V2 changes only that parsing binding,
its version/schema and preparation path. No physics hypothesis or assertion
is removed. The B-only transverse-deletion control must remain insensitive;
all other declared requirements remain binding.

A fresh sequential primary/replay pair has the original120-second-after-import
and8GiB sampled-private caps. No actual Spin(10) pole or peer-result reading.
Both routes use the same declared unit action/propagator and shared helpers;
this correction is an engineering failure, not independent physical evidence.
