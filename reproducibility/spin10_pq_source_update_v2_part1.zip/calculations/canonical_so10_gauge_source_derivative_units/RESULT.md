# Ordinary g2 gauge-source derivative units

The full graded-Hessian/Born and independently ordered Wick calculations agree
on all12 general-momentum kernels and48 first-momentum density positions.
Their different ultraviolet projections, Taylor expansion and Feynman-parameter
integration respectively, give the same three factors:

| Derivative placement | Factor in ordered J_mu partial_mu C |
| --- | --- |
| Antighost, F_a | (3-W)/2 |
| Vector, F_B | W |
| External ghost, F_C | -(3+W)/2 |

W remains a formal reference width. Each of the four source polarizations has
the same diagonal factor; all off-diagonal momentum components vanish. The
common pole convention is hbar/(32 pi^2 epsilon_UV), with the two action
couplings and actual color tensors still to be inserted. No actual Spin(10)
pole has been calculated in this increment.

In plain language, this fixes how the loop's momentum dependence contributes
to the missing source calculation. The older width-independent simplification
does not apply to these unit factors. Whether the actual color contraction
retains or cancels that dependence remains a separate calculation.

The [record](RECORD.md) freezes the target, signs, full vector propagator,
ghost orientation, external grading, momentum routing and authority ceiling.
The complete unintegrated kernel is
sum_nu eta_nunu D_munu(q) v_nu / (q-p)^2, with v=q-p,-q,p in the three cases.
The two distinct ordered words each supply half the complete factor. The
radial residue uses a positive temporary infrared reference; no whole
scaleless integral or finite infrared amplitude has been interpreted.

All derivative-placement sums vanish before and after integration, including
the fixed (2,3,5) current example after integration by parts. The first-momentum
term is essential: setting external momentum to zero at the start loses it.
A permissible loop-momentum shift leaves the logarithmic pole unchanged.

Dropping the transverse vector propagator changes the a/C factors to -W/2.
The B factor remains W and is correctly insensitive to that mutation.
Dropping the longitudinal correction changes the a/B/C factors to 1,1,-2.
Odd-source grading, wrong routing and one-word omission controls detect their
respective defects. A deliberately wrong Euclidean angular metric breaks
Lorentz equality in both methods: the spatial a factor becomes (W-1)/2 in
the Taylor route and (W-3)/6 in the parameter route. These invalid calculations
need not agree; their different corrupted values are preserved, not fitted.

The original primary failed its control comparison after all48 density checks.
Its parser created a second gs_W symbol with different assumptions. The
[V2 correction](CORRECTION_V2.md) binds that symbol explicitly; it changes no
physical input, expected factor or assertion. Original source, preparation
and native failed capture remain immutable. No original result was exported.
The corrected primary and replay completed in48.723 and64.239 seconds after
imports, respectively, below their120-second/8GiB limits. They are distinct
methods, not a byte-identical same-command replay pair.

Track B: general-momentum contraction and a separate ultraviolet method agree;
controls distinguish needed propagator structure from an insensitive case.
The parser failure and method-dependent corrupted outputs limit stronger
reliability claims. The unit action, tensor conventions, arithmetic helpers,
radial ultraviolet assumptions and AI authorship are shared. Agreement does
not establish the physical completeness of those assumptions. Education is
voluntary, concurrent and nonblocking.

Next: freeze the actual45-by45 gauge-source/ghost color contraction. Recover
the action-derived source and derivative vertices, their real dual chart,
the full H/M reference-width meaning, and all integration-by-parts terms.
Compare literal and independently rebuilt physical tensors before any
dependent canonical export or identity test. Do not infer that pole from a
desired Ward relation or transfer the old g*xi result to this g2 contribution.

Known Gamma remains92236 terms with its previously qualified zero background
Ward remainder. This result adds no functional node. Full source/Slavnov
restoration, anomaly freedom, finite/IR/measure obligations and E5/A5 remain
unqualified; HB1/C5 blocked, C1_GS uncalculated, flavor paused. Authority
v113/34of39, earlier failures, scalar quantum-control warning, custody exit2
and seven unresolved references are unchanged. No accepted input, benchmark,
foundation, protected evidence or remote action changed.

The separate validation receipt authenticates the full captures and input
bytes, checks all kernels against the direct propagator formula, all48 factors,
controls and protected files. Its completion qualifies only this unit scope.
