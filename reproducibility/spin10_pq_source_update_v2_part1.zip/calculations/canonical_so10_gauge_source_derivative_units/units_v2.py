"""General-p B/B bubble: graded Hessians versus routed Wick and parameter poles."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations
import json,os,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(PKG))
from a10_e5_nonminimal_source import alphabet,register,s,ETA,canonical
from a10_e5_ghost_companion import Fourier_vertex
from a10_e5_mixed_contact import multiply,trace
q=list(s.symbols('gs_q0:4',real=True));p=list(s.symbols('gs_p0:4',real=True));W=s.Symbol('gs_W',real=True)
Q=sum(ETA[i]*q[i]**2 for i in range(4));r=[q[i]-p[i] for i in range(4)];R2=sum(ETA[i]*r[i]**2 for i in range(4));ZERO={v:0 for v in p}
DQ,DR=s.symbols('gs_Qden gs_Rden',nonzero=True)
read=lambda f:json.loads(f.read_bytes());digest=lambda f:sha256(f.read_bytes()).hexdigest()

def clean(z):return s.cancel(s.expand(z))
def physical(z):return clean(z.subs({DQ:Q,DR:R2},simultaneous=True))

def setup(mu,placement):
    w=alphabet();w.fields={**{f'gs_BL{i}':(1,0,0) for i in range(4)},**{f'gs_BR{i}':(1,0,0) for i in range(4)},'gs_c':(1,1,1),'gs_a':(1,-1,1)}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    register(w,'gs_J',(2,-1,1));register(w,'gs_C',(1,1,1));v=w.var
    source=w.mul(v('gs_J'),v(f'gs_BL{mu}'),v('gs_c'))
    ghost=w.add(*(w.scale(w.mul(w.D(v('gs_a'),nu) if placement=='a' else v('gs_a'),
        w.D(v(f'gs_BR{nu}'),nu) if placement=='B' else v(f'gs_BR{nu}'),
        w.D(v('gs_C'),nu) if placement=='C' else v('gs_C')),ETA[nu]) for nu in range(4)))
    assert w.grade(source,(4,0,0)) and w.grade(ghost,(4,0,0))
    momenta={**{f'gs_BL{i}':q for i in range(4)},**{f'gs_BR{i}':[-z for z in q] for i in range(4)},'gs_c':[-z for z in r],'gs_a':r,'gs_J':[-z for z in p],'gs_C':p}
    def fourier(P):
        out={}
        for word,z in P.items():
            assert all(s.expand(sum(momenta[n][nu] for n,j in word))==0 for nu in range(4))
            phase=s.prod(s.I*momenta[n][nu] for n,j in word for nu in j);plain=tuple((n,()) for n,j in word)
            out[plain]=out.get(plain,0)+z*phase
        return canonical(out)
    return w,[fourier(source),fourier(ghost)],w.mul(v('gs_J'),v('gs_C'))

def green(a,b,variant=None):
    if a.startswith('gs_B') and b.startswith('gs_B') and a[:5]!=b[:5]:
        mu=int(a[-1]);nu=int(b[-1])
        if variant=='omit_transverse':return -W*q[mu]*q[nu]/DQ**2
        if variant=='omit_longitudinal_correction':return -ETA[mu]*int(mu==nu)/DQ
        return -ETA[mu]*int(mu==nu)/DQ+(1-W)*q[mu]*q[nu]/DQ**2
    if (a,b)==('gs_c','gs_a'):return 1/DR
    if (a,b)==('gs_a','gs_c'):return -1/DR
    return s.S.Zero

def born(mu,placement,variant=None):
    w,V,target=setup(mu,placement);names=list(w.fields);parities=[w.p[n] for n in names];word,sign=next(iter(target.items()))
    G={(i,j):{():z} for i,a in enumerate(names) for j,b in enumerate(names) if (z:=green(a,b,variant))}
    H=[]
    for P in V:
        A=Fourier_vertex(P,w,'primary',q,q,{})
        H.append({(i,j):cell for i,row in enumerate(A) for j,cell in enumerate(row) if cell})
    parts=[]
    for A,B in [H,H[::-1]]:
        full=multiply(multiply(multiply(G,A,w),G,w),B,w)
        T=trace(full,w,parities);parts.append(clean(-s.I*T.get(word,0)/(4*sign)))
    return clean(sum(parts)),{'ordered_kernel_parts':[str(v) for v in parts],'two_distinct_words':2}

def wick(mu,placement,variant=None):
    w,V,target=setup(mu,placement);word,sign=next(iter(target.items()));external={'gs_J','gs_C'};parts=[];counts=[]
    def pair(legs):
        if not legs:return s.S.One
        first=legs[0];value=0
        for i,other in enumerate(legs[1:],1):
            prop=green(first,other,variant)
            if prop:
                parity=(-1)**(w.p[first]*sum(w.p[n] for n in legs[1:i]))
                value+=parity*s.I*prop*pair(legs[1:i]+legs[i+1:])
        return value
    for order in [V,V[::-1]]:
        total=0;terms=0
        for left,z in order[0].items():
            for right,u in order[1].items():
                full=left+right;ext=[n for n,j in full if n in external];inside=[n for n,j in full if n not in external]
                assert len(inside)==4
                cross=(-1)**sum(w.p[n]*w.p[m] for i,(n,j) in enumerate(full) if n not in external for m,k in full[i+1:] if m in external)
                ext_sign=w.mul(*(w.var(n) for n in ext)).get(word,0)/sign
                total+=z*u*cross*ext_sign*pair(inside);terms+=1
        # -i log Z, two i vertices, and the exponential's2!.
        parts.append(clean(-s.I*s.I**2*total/2));counts.append(terms)
    assert clean(parts[0]-parts[1])==0
    return clean(sum(parts)),{'ordered_kernel_parts':[str(v) for v in parts],'ordered_monomial_counts':counts,'two_distinct_orders':2}

def gaussian_rank2(poly,variables,wrong_metric=False):
    out=0
    for powers,z in s.Poly(s.expand(poly),*variables).terms():
        if not z:continue
        assert sum(powers)==2,(powers,z)
        if 2 in powers:
            i=powers.index(2);out+=z*(1 if wrong_metric else ETA[i])/4
    return s.expand(out)

def taylor_poles(kernel,wrong_metric=False):
    abbreviated=kernel.has(DQ,DR);out=[]
    for nu,pv in enumerate(p):
        if abbreviated:
            # The ghost denominator is R2=(q-p)^2; its derivative is required.
            term=s.diff(kernel,pv)-2*ETA[nu]*q[nu]*s.diff(kernel,DR)
            linear=clean(term.subs(ZERO).subs({DQ:Q,DR:Q},simultaneous=True))
        else:linear=clean(s.diff(kernel,pv).subs(ZERO))
        poly=clean(linear*Q**3)
        out.append(s.factor(2*gaussian_rank2(poly,q,wrong_metric)))
    return out

def parameter_poles(kernel,wrong_metric=False):
    t=s.Symbol('gs_t',real=True);ell=list(s.symbols('gs_l0:4',real=True))
    if kernel.has(DQ,DR):numerator=s.expand(clean(kernel*DQ**2*DR).subs({DQ:Q,DR:R2},simultaneous=True))
    else:numerator=clean(kernel*Q**2*R2)
    s.Poly(numerator,*q,*p,W)
    shifted=s.expand(numerator.subs({q[i]:ell[i]+(1-t)*p[i] for i in range(4)},simultaneous=True));out=[]
    for pv in p:
        linear=s.expand(s.diff(shifted,pv).subs(ZERO));moment=gaussian_rank2(linear,ell,wrong_metric)
        out.append(s.factor(2*s.integrate(2*t*moment,(t,0,1))))
    return out

def main():
    tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    route=sys.argv[1];assert route in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
    for n,z in prep['input_sha256'].items():assert digest(Path(n))==z,n
    def guard(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
        f=Path(os.fsdecode(args[0]))
        if len(args)>1 and isinstance(args[1],str) and any(v in args[1] for v in 'wax+'):raise PermissionError('GAUGE_SOURCE_UNIT_WRITE')
        if f.suffix=='.json':raise PermissionError('GAUGE_SOURCE_UNIT_GROUP_POLE_GAMMA_PEER_READ')
    sys.addaudithook(guard)
    calc=born if route=='primary' else wick;pole=taylor_poles if route=='primary' else parameter_poles
    expected={'a':(3-W)/2,'B':W,'C':-(3+W)/2};table={};details={};controls={}
    for mu in range(4):
        kernels=[];densities=[]
        for placement in ['a','B','C']:
            key=placement+'_'+str(mu);print('STAGE '+route+' '+key,flush=True)
            kernel,info=calc(mu,placement);density=pole(kernel)
            assert density==[s.factor(expected[placement]) if nu==mu else 0 for nu in range(4)],(key,density)
            zero=clean(physical(kernel).subs(ZERO));assert clean(zero+zero.subs({v:-v for v in q},simultaneous=True))==0
            table[key]={'kernel':str(physical(kernel)),'abbreviated_kernel':str(kernel),'density_first_p_coefficients':[str(z) for z in density],'zeroth_p_odd_or_zero':True};details[key]=info
            kernels.append(kernel);densities.append(density)
        assert clean(sum(kernels))==0 and all(s.simplify(sum(v[nu] for v in densities))==0 for nu in range(4))
        assert clean(2*kernels[0]+3*kernels[1]+5*kernels[2]-(-kernels[0]+2*kernels[2]))==0
    for placement in ['a','B','C']:
        base=s.sympify(table[placement+'_0']['density_first_p_coefficients'][0],locals={str(W):W})
        for variant in ['omit_transverse','omit_longitudinal_correction']:
            kernel,unused=calc(0,placement,variant);value=pole(kernel)[0];sensitive=s.simplify(value-base)!=0
            assert sensitive if variant!='omit_transverse' or placement!='B' else not sensitive
            controls[placement+'_'+variant]={'density_factor':str(value),'changes_result':sensitive}
    k0=s.sympify(table['a_0']['kernel'],locals={str(z):z for z in [*q,*p,W]})
    shifted=k0.subs({q[i]:q[i]+p[i] for i in range(4)},simultaneous=True)
    assert taylor_poles(shifted)==taylor_poles(k0)
    part=s.sympify(details['a_0']['ordered_kernel_parts'][0],locals={str(z):z for z in [*q,*p,W,DQ,DR]})
    assert s.simplify(pole(part)[0]-expected['a']/2)==0
    spatial=s.sympify(table['a_1']['kernel'],locals={str(z):z for z in [*q,*p,W]});bad=pole(spatial,True)
    assert bad!=[0,s.factor(expected['a']),0,0]
    w,V,target=setup(0,'a');register(w,'gs_J',(2,-1,0));assert not w.grade(w.mul(w.var('gs_J'),w.var('gs_BL0'),w.var('gs_c')),(4,0,0))
    assert any(s.expand((q[i]+p[i])-q[i]+p[i])!=0 for i in range(4))
    eps=s.Symbol('gs_eps',positive=True);mass=s.Symbol('gs_IR_mass_squared',positive=True)
    assert s.limit(eps*s.gamma(eps)*mass**(-eps),eps,0)==1
    assert s.limit(eps*s.gamma(1+eps)*mass**(-1-eps)/2,eps,0)==0
    result={'schema':'ORDINARY_G2_GAUGE_SOURCE_DERIVATIVE_UNITS_V2','route':route,'all12_kernels':table,'details':details,'propagator_controls':controls,
      'all48_density_components_checked':True,'all_IBP_kernel_and_pole_sums_zero':True,'random_current_coefficients_equivalent':True,
      'one_word_omission_halves_nonzero_factor':True,'wrong_even_source_grade_rejected':True,'wrong_momentum_routing_rejected':True,
      'UV_log_loop_shift_check_pass':True,'wrong_Euclidean_metric_density':list(map(str,bad)),
      'positive_IR_reference_bubble_residue':1,'mass_times_three_denominator_residue':0,'zeroth_p_does_not_supply_derivative_pole':True,
      'denominator_relations':{'gs_Qden':str(Q),'gs_Rden':str(R2)},
      'actual_group_or_required_pole_read':False,'actual_Spin10_pole_calculated':False,'finite_IR_or_full_E5_A5_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
