# Exact-algebra validation comparator V2

Both corrected calculation routes completed and agree on all12 kernels and48
coefficients. The first separate validator failed at line43 because SymPy
structural equality distinguishes an expanded linear expression from its
factored form. Exact simplification gives zero difference in every affected
position. Preserve that validator, preparation and failed native capture.

V2 checks all48 exact differences for zero; no tolerance, expected value or
scientific requirement changes. It authenticates the failed validation too.
No physics worker is rerun. The same120-second/8GiB validation cap applies.
The completed record, if all checks pass, is validation_v2_receipt.json.
